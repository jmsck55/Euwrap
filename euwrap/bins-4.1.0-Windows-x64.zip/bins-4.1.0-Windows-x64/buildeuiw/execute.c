// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _67new_arg_assign()
{
    object _0, _1, _2;
    

    /** execute.e:81		arg_assign += 1*/
    _0 = _67arg_assign_65274;
    if (IS_ATOM_INT(_67arg_assign_65274)) {
        _67arg_assign_65274 = _67arg_assign_65274 + 1;
        if (_67arg_assign_65274 > MAXINT){
            _67arg_assign_65274 = NewDouble((eudouble)_67arg_assign_65274);
        }
    }
    else
    _67arg_assign_65274 = binary_op(PLUS, 1, _67arg_assign_65274);
    DeRef(_0);

    /** execute.e:82		return arg_assign*/
    Ref(_67arg_assign_65274);
    return _67arg_assign_65274;
    ;
}


void _67open_err_file()
{
    object _32177 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:187		err_file = open(err_file_name, "w")*/
    _67err_file_65380 = EOpen(_67err_file_name_65381, _22363, 0LL);

    /** execute.e:188		if err_file = -1 then*/
    if (_67err_file_65380 != -1LL)
    goto L1; // [14] 36

    /** execute.e:189			puts(2, "Can't open " & err_file_name & '\n')*/
    {
        object concat_list[3];

        concat_list[0] = 10LL;
        concat_list[1] = _67err_file_name_65381;
        concat_list[2] = _32176;
        Concat_N((object_ptr)&_32177, concat_list, 3);
    }
    EPuts(2LL, _32177); // DJP 
    DeRefDS(_32177);
    _32177 = NOVALUE;

    /** execute.e:190			abort(1)*/
    UserCleanup(1LL);
L1: 

    /** execute.e:192	end procedure*/
    return;
    ;
}


void _67both_puts(object _s_65394)
{
    object _0, _1, _2;
    

    /** execute.e:198		if screen_err_out then*/
    if (_67screen_err_out_65391 == 0)
    {
        goto L1; // [5] 14
    }
    else{
    }

    /** execute.e:199			puts(2, s)*/
    EPuts(2LL, _s_65394); // DJP 
L1: 

    /** execute.e:201		puts(err_file, s)*/
    EPuts(_67err_file_65380, _s_65394); // DJP 

    /** execute.e:202	end procedure*/
    DeRef(_s_65394);
    return;
    ;
}


void _67both_printf(object _format_65398, object _items_65399)
{
    object _0, _1, _2;
    

    /** execute.e:206		if screen_err_out then*/
    if (_67screen_err_out_65391 == 0)
    {
        goto L1; // [9] 19
    }
    else{
    }

    /** execute.e:207			printf(2, format, items)*/
    EPrintf(2LL, _format_65398, _items_65399);
L1: 

    /** execute.e:209		printf(err_file, format, items)*/
    EPrintf(_67err_file_65380, _format_65398, _items_65399);

    /** execute.e:210	end procedure*/
    DeRefDSi(_format_65398);
    DeRefDS(_items_65399);
    return;
    ;
}


object _67find_line(object _sub_65404, object _pc_65405)
{
    object _linetab_65406 = NOVALUE;
    object _line_65407 = NOVALUE;
    object _gline_65408 = NOVALUE;
    object _32201 = NOVALUE;
    object _32200 = NOVALUE;
    object _32199 = NOVALUE;
    object _32198 = NOVALUE;
    object _32197 = NOVALUE;
    object _32196 = NOVALUE;
    object _32194 = NOVALUE;
    object _32193 = NOVALUE;
    object _32192 = NOVALUE;
    object _32190 = NOVALUE;
    object _32189 = NOVALUE;
    object _32188 = NOVALUE;
    object _32187 = NOVALUE;
    object _32185 = NOVALUE;
    object _32184 = NOVALUE;
    object _32182 = NOVALUE;
    object _32181 = NOVALUE;
    object _32180 = NOVALUE;
    object _32178 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:217		linetab = SymTab[sub][S_LINETAB]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32178 = (object)*(((s1_ptr)_2)->base + _sub_65404);
    DeRef(_linetab_65406);
    _2 = (object)SEQ_PTR(_32178);
    if (!IS_ATOM_INT(_27S_LINETAB_20244)){
        _linetab_65406 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_LINETAB_20244)->dbl));
    }
    else{
        _linetab_65406 = (object)*(((s1_ptr)_2)->base + _27S_LINETAB_20244);
    }
    Ref(_linetab_65406);
    _32178 = NOVALUE;

    /** execute.e:218		line = 1*/
    _line_65407 = 1LL;

    /** execute.e:219		for i = 1 to length(linetab) do*/
    if (IS_SEQUENCE(_linetab_65406)){
            _32180 = SEQ_PTR(_linetab_65406)->length;
    }
    else {
        _32180 = 1;
    }
    {
        object _i_65414;
        _i_65414 = 1LL;
L1: 
        if (_i_65414 > _32180){
            goto L2; // [31] 119
        }

        /** execute.e:220			if linetab[i] >= pc or linetab[i] = -2 then*/
        _2 = (object)SEQ_PTR(_linetab_65406);
        _32181 = (object)*(((s1_ptr)_2)->base + _i_65414);
        if (IS_ATOM_INT(_32181)) {
            _32182 = (_32181 >= _pc_65405);
        }
        else {
            _32182 = binary_op(GREATEREQ, _32181, _pc_65405);
        }
        _32181 = NOVALUE;
        if (IS_ATOM_INT(_32182)) {
            if (_32182 != 0) {
                goto L3; // [48] 65
            }
        }
        else {
            if (DBL_PTR(_32182)->dbl != 0.0) {
                goto L3; // [48] 65
            }
        }
        _2 = (object)SEQ_PTR(_linetab_65406);
        _32184 = (object)*(((s1_ptr)_2)->base + _i_65414);
        if (IS_ATOM_INT(_32184)) {
            _32185 = (_32184 == -2LL);
        }
        else {
            _32185 = binary_op(EQUALS, _32184, -2LL);
        }
        _32184 = NOVALUE;
        if (_32185 == 0) {
            DeRef(_32185);
            _32185 = NOVALUE;
            goto L4; // [61] 112
        }
        else {
            if (!IS_ATOM_INT(_32185) && DBL_PTR(_32185)->dbl == 0.0){
                DeRef(_32185);
                _32185 = NOVALUE;
                goto L4; // [61] 112
            }
            DeRef(_32185);
            _32185 = NOVALUE;
        }
        DeRef(_32185);
        _32185 = NOVALUE;
L3: 

        /** execute.e:221				line = i-1*/
        _line_65407 = _i_65414 - 1LL;

        /** execute.e:222				while line > 1 and linetab[line] = -1 do*/
L5: 
        _32187 = (_line_65407 > 1LL);
        if (_32187 == 0) {
            goto L2; // [80] 119
        }
        _2 = (object)SEQ_PTR(_linetab_65406);
        _32189 = (object)*(((s1_ptr)_2)->base + _line_65407);
        if (IS_ATOM_INT(_32189)) {
            _32190 = (_32189 == -1LL);
        }
        else {
            _32190 = binary_op(EQUALS, _32189, -1LL);
        }
        _32189 = NOVALUE;
        if (_32190 <= 0) {
            if (_32190 == 0) {
                DeRef(_32190);
                _32190 = NOVALUE;
                goto L2; // [93] 119
            }
            else {
                if (!IS_ATOM_INT(_32190) && DBL_PTR(_32190)->dbl == 0.0){
                    DeRef(_32190);
                    _32190 = NOVALUE;
                    goto L2; // [93] 119
                }
                DeRef(_32190);
                _32190 = NOVALUE;
            }
        }
        DeRef(_32190);
        _32190 = NOVALUE;

        /** execute.e:223					line -= 1*/
        _line_65407 = _line_65407 - 1LL;

        /** execute.e:224				end while*/
        goto L5; // [104] 76

        /** execute.e:225				exit*/
        goto L2; // [109] 119
L4: 

        /** execute.e:227		end for*/
        _i_65414 = _i_65414 + 1LL;
        goto L1; // [114] 38
L2: 
        ;
    }

    /** execute.e:228		gline = SymTab[sub][S_FIRSTLINE] + line - 1*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32192 = (object)*(((s1_ptr)_2)->base + _sub_65404);
    _2 = (object)SEQ_PTR(_32192);
    if (!IS_ATOM_INT(_27S_FIRSTLINE_20249)){
        _32193 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FIRSTLINE_20249)->dbl));
    }
    else{
        _32193 = (object)*(((s1_ptr)_2)->base + _27S_FIRSTLINE_20249);
    }
    _32192 = NOVALUE;
    if (IS_ATOM_INT(_32193)) {
        _32194 = _32193 + _line_65407;
        if ((object)((uintptr_t)_32194 + (uintptr_t)HIGH_BITS) >= 0){
            _32194 = NewDouble((eudouble)_32194);
        }
    }
    else {
        _32194 = binary_op(PLUS, _32193, _line_65407);
    }
    _32193 = NOVALUE;
    if (IS_ATOM_INT(_32194)) {
        _gline_65408 = _32194 - 1LL;
    }
    else {
        _gline_65408 = binary_op(MINUS, _32194, 1LL);
    }
    DeRef(_32194);
    _32194 = NOVALUE;
    if (!IS_ATOM_INT(_gline_65408)) {
        _1 = (object)(DBL_PTR(_gline_65408)->dbl);
        DeRefDS(_gline_65408);
        _gline_65408 = _1;
    }

    /** execute.e:229		return {known_files[slist[gline][LOCAL_FILE_NO]], slist[gline][LINE]}*/
    _2 = (object)SEQ_PTR(_27slist_20662);
    _32196 = (object)*(((s1_ptr)_2)->base + _gline_65408);
    _2 = (object)SEQ_PTR(_32196);
    _32197 = (object)*(((s1_ptr)_2)->base + 3LL);
    _32196 = NOVALUE;
    _2 = (object)SEQ_PTR(_28known_files_11573);
    if (!IS_ATOM_INT(_32197)){
        _32198 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32197)->dbl));
    }
    else{
        _32198 = (object)*(((s1_ptr)_2)->base + _32197);
    }
    _2 = (object)SEQ_PTR(_27slist_20662);
    _32199 = (object)*(((s1_ptr)_2)->base + _gline_65408);
    _2 = (object)SEQ_PTR(_32199);
    _32200 = (object)*(((s1_ptr)_2)->base + 2LL);
    _32199 = NOVALUE;
    Ref(_32200);
    Ref(_32198);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _32198;
    ((intptr_t *)_2)[2] = _32200;
    _32201 = MAKE_SEQ(_1);
    _32200 = NOVALUE;
    _32198 = NOVALUE;
    DeRef(_linetab_65406);
    _32197 = NOVALUE;
    DeRef(_32182);
    _32182 = NOVALUE;
    DeRef(_32187);
    _32187 = NOVALUE;
    return _32201;
    ;
}


void _67show_var(object _x_65449)
{
    object _32215 = NOVALUE;
    object _32212 = NOVALUE;
    object _32211 = NOVALUE;
    object _32210 = NOVALUE;
    object _32209 = NOVALUE;
    object _32208 = NOVALUE;
    object _32206 = NOVALUE;
    object _32205 = NOVALUE;
    object _32204 = NOVALUE;
    object _32203 = NOVALUE;
    object _32202 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:235		puts(err_file, "    " & SymTab[x][S_NAME] & " = ")*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32202 = (object)*(((s1_ptr)_2)->base + _x_65449);
    _2 = (object)SEQ_PTR(_32202);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _32203 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _32203 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _32202 = NOVALUE;
    {
        object concat_list[3];

        concat_list[0] = _29768;
        concat_list[1] = _32203;
        concat_list[2] = _25160;
        Concat_N((object_ptr)&_32204, concat_list, 3);
    }
    _32203 = NOVALUE;
    EPuts(_67err_file_65380, _32204); // DJP 
    DeRefDS(_32204);
    _32204 = NOVALUE;

    /** execute.e:236		if equal(val[x], NOVALUE) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _32205 = (object)*(((s1_ptr)_2)->base + _x_65449);
    if (_32205 == _27NOVALUE_20426)
    _32206 = 1;
    else if (IS_ATOM_INT(_32205) && IS_ATOM_INT(_27NOVALUE_20426))
    _32206 = 0;
    else
    _32206 = (compare(_32205, _27NOVALUE_20426) == 0);
    _32205 = NOVALUE;
    if (_32206 == 0)
    {
        _32206 = NOVALUE;
        goto L1; // [42] 55
    }
    else{
        _32206 = NOVALUE;
    }

    /** execute.e:237			puts(err_file, "<no value>")*/
    EPuts(_67err_file_65380, _32207); // DJP 
    goto L2; // [52] 102
L1: 

    /** execute.e:239			pretty_print(err_file, val[x],*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _32208 = (object)*(((s1_ptr)_2)->base + _x_65449);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32209 = (object)*(((s1_ptr)_2)->base + _x_65449);
    _2 = (object)SEQ_PTR(_32209);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _32210 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _32210 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _32209 = NOVALUE;
    if (IS_SEQUENCE(_32210)){
            _32211 = SEQ_PTR(_32210)->length;
    }
    else {
        _32211 = 1;
    }
    _32210 = NOVALUE;
    _32212 = _32211 + 7LL;
    _32211 = NOVALUE;
    _1 = NewS1(9);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    ((intptr_t*)_2)[3] = _32212;
    ((intptr_t*)_2)[4] = 78LL;
    RefDS(_32213);
    ((intptr_t*)_2)[5] = _32213;
    RefDS(_32214);
    ((intptr_t*)_2)[6] = _32214;
    ((intptr_t*)_2)[7] = 32LL;
    ((intptr_t*)_2)[8] = 127LL;
    ((intptr_t*)_2)[9] = 500LL;
    _32215 = MAKE_SEQ(_1);
    _32212 = NOVALUE;
    Ref(_32208);
    _10pretty_print(_67err_file_65380, _32208, _32215);
    _32208 = NOVALUE;
    _32215 = NOVALUE;
L2: 

    /** execute.e:242		puts(err_file, '\n')*/
    EPuts(_67err_file_65380, 10LL); // DJP 

    /** execute.e:243	end procedure*/
    _32210 = NOVALUE;
    return;
    ;
}


void _67save_private_block(object _rtn_idx_65479, object _block_65480)
{
    object _saved_65481 = NOVALUE;
    object _saved_list_65482 = NOVALUE;
    object _eentry_65483 = NOVALUE;
    object _task_65484 = NOVALUE;
    object _spot_65485 = NOVALUE;
    object _tn_65486 = NOVALUE;
    object _32242 = NOVALUE;
    object _32238 = NOVALUE;
    object _32237 = NOVALUE;
    object _32236 = NOVALUE;
    object _32235 = NOVALUE;
    object _32234 = NOVALUE;
    object _32233 = NOVALUE;
    object _32231 = NOVALUE;
    object _32229 = NOVALUE;
    object _32228 = NOVALUE;
    object _32225 = NOVALUE;
    object _32223 = NOVALUE;
    object _32221 = NOVALUE;
    object _32219 = NOVALUE;
    object _32218 = NOVALUE;
    object _32216 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:259		task = SymTab[rtn_idx][S_RESIDENT_TASK]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32216 = (object)*(((s1_ptr)_2)->base + _rtn_idx_65479);
    _2 = (object)SEQ_PTR(_32216);
    _task_65484 = (object)*(((s1_ptr)_2)->base + 25LL);
    if (!IS_ATOM_INT(_task_65484)){
        _task_65484 = (object)DBL_PTR(_task_65484)->dbl;
    }
    _32216 = NOVALUE;

    /** execute.e:261		eentry = {task, tcb[task][TASK_TID], block, 0}*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32218 = (object)*(((s1_ptr)_2)->base + _task_65484);
    _2 = (object)SEQ_PTR(_32218);
    _32219 = (object)*(((s1_ptr)_2)->base + 2LL);
    _32218 = NOVALUE;
    _0 = _eentry_65483;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _task_65484;
    Ref(_32219);
    ((intptr_t*)_2)[2] = _32219;
    RefDS(_block_65480);
    ((intptr_t*)_2)[3] = _block_65480;
    ((intptr_t*)_2)[4] = 0LL;
    _eentry_65483 = MAKE_SEQ(_1);
    DeRef(_0);
    _32219 = NOVALUE;

    /** execute.e:262		saved = SymTab[rtn_idx][S_SAVED_PRIVATES]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32221 = (object)*(((s1_ptr)_2)->base + _rtn_idx_65479);
    DeRef(_saved_65481);
    _2 = (object)SEQ_PTR(_32221);
    _saved_65481 = (object)*(((s1_ptr)_2)->base + 26LL);
    Ref(_saved_65481);
    _32221 = NOVALUE;

    /** execute.e:264		if length(saved) = 0 then*/
    if (IS_SEQUENCE(_saved_65481)){
            _32223 = SEQ_PTR(_saved_65481)->length;
    }
    else {
        _32223 = 1;
    }
    if (_32223 != 0LL)
    goto L1; // [61] 78

    /** execute.e:266			saved = {1, -- index of first item*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_eentry_65483);
    ((intptr_t*)_2)[1] = _eentry_65483;
    _32225 = MAKE_SEQ(_1);
    DeRefDS(_saved_65481);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1LL;
    ((intptr_t *)_2)[2] = _32225;
    _saved_65481 = MAKE_SEQ(_1);
    _32225 = NOVALUE;
    goto L2; // [75] 219
L1: 

    /** execute.e:270			saved_list = saved[2]*/
    DeRef(_saved_list_65482);
    _2 = (object)SEQ_PTR(_saved_65481);
    _saved_list_65482 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_saved_list_65482);

    /** execute.e:271			spot = 0*/
    _spot_65485 = 0LL;

    /** execute.e:272			for i = 1 to length(saved_list) do*/
    if (IS_SEQUENCE(_saved_list_65482)){
            _32228 = SEQ_PTR(_saved_list_65482)->length;
    }
    else {
        _32228 = 1;
    }
    {
        object _i_65506;
        _i_65506 = 1LL;
L3: 
        if (_i_65506 > _32228){
            goto L4; // [96] 169
        }

        /** execute.e:273				tn = saved_list[i][SP_TASK_NUMBER]*/
        _2 = (object)SEQ_PTR(_saved_list_65482);
        _32229 = (object)*(((s1_ptr)_2)->base + _i_65506);
        _2 = (object)SEQ_PTR(_32229);
        _tn_65486 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (!IS_ATOM_INT(_tn_65486)){
            _tn_65486 = (object)DBL_PTR(_tn_65486)->dbl;
        }
        _32229 = NOVALUE;

        /** execute.e:274				if tn = -1 or*/
        _32231 = (_tn_65486 == -1LL);
        if (_32231 != 0) {
            goto L5; // [121] 152
        }
        _2 = (object)SEQ_PTR(_saved_list_65482);
        _32233 = (object)*(((s1_ptr)_2)->base + _i_65506);
        _2 = (object)SEQ_PTR(_32233);
        _32234 = (object)*(((s1_ptr)_2)->base + 2LL);
        _32233 = NOVALUE;
        _2 = (object)SEQ_PTR(_67tcb_65374);
        _32235 = (object)*(((s1_ptr)_2)->base + _tn_65486);
        _2 = (object)SEQ_PTR(_32235);
        _32236 = (object)*(((s1_ptr)_2)->base + 2LL);
        _32235 = NOVALUE;
        if (IS_ATOM_INT(_32234) && IS_ATOM_INT(_32236)) {
            _32237 = (_32234 != _32236);
        }
        else {
            _32237 = binary_op(NOTEQ, _32234, _32236);
        }
        _32234 = NOVALUE;
        _32236 = NOVALUE;
        if (_32237 == 0) {
            DeRef(_32237);
            _32237 = NOVALUE;
            goto L6; // [148] 162
        }
        else {
            if (!IS_ATOM_INT(_32237) && DBL_PTR(_32237)->dbl == 0.0){
                DeRef(_32237);
                _32237 = NOVALUE;
                goto L6; // [148] 162
            }
            DeRef(_32237);
            _32237 = NOVALUE;
        }
        DeRef(_32237);
        _32237 = NOVALUE;
L5: 

        /** execute.e:277					spot = i*/
        _spot_65485 = _i_65506;

        /** execute.e:278					exit*/
        goto L4; // [159] 169
L6: 

        /** execute.e:280			end for*/
        _i_65506 = _i_65506 + 1LL;
        goto L3; // [164] 103
L4: 
        ;
    }

    /** execute.e:282			eentry[SP_NEXT] = saved[1] -- new eentry points to previous first*/
    _2 = (object)SEQ_PTR(_saved_65481);
    _32238 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_32238);
    _2 = (object)SEQ_PTR(_eentry_65483);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _eentry_65483 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32238;
    if( _1 != _32238 ){
        DeRef(_1);
    }
    _32238 = NOVALUE;

    /** execute.e:283			if spot = 0 then*/
    if (_spot_65485 != 0LL)
    goto L7; // [181] 199

    /** execute.e:285				saved_list = append(saved_list, eentry)*/
    RefDS(_eentry_65483);
    Append(&_saved_list_65482, _saved_list_65482, _eentry_65483);

    /** execute.e:286				spot = length(saved_list)*/
    if (IS_SEQUENCE(_saved_list_65482)){
            _spot_65485 = SEQ_PTR(_saved_list_65482)->length;
    }
    else {
        _spot_65485 = 1;
    }
    goto L8; // [196] 206
L7: 

    /** execute.e:288				saved_list[spot] = eentry*/
    RefDS(_eentry_65483);
    _2 = (object)SEQ_PTR(_saved_list_65482);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_list_65482 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _spot_65485);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _eentry_65483;
    DeRef(_1);
L8: 

    /** execute.e:291			saved[1] = spot -- it becomes the first on the list*/
    _2 = (object)SEQ_PTR(_saved_65481);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_65481 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _spot_65485;
    DeRef(_1);

    /** execute.e:292			saved[2] = saved_list*/
    RefDS(_saved_list_65482);
    _2 = (object)SEQ_PTR(_saved_65481);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_65481 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _saved_list_65482;
    DeRef(_1);
L2: 

    /** execute.e:295		SymTab[rtn_idx][S_SAVED_PRIVATES] = saved*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_rtn_idx_65479 + ((s1_ptr)_2)->base);
    RefDS(_saved_65481);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 26LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _saved_65481;
    DeRef(_1);
    _32242 = NOVALUE;

    /** execute.e:296	end procedure*/
    DeRefDS(_block_65480);
    DeRefDS(_saved_65481);
    DeRef(_saved_list_65482);
    DeRef(_eentry_65483);
    DeRef(_32231);
    _32231 = NOVALUE;
    return;
    ;
}


object _67load_private_block(object _rtn_idx_65531, object _task_65532)
{
    object _saved_65533 = NOVALUE;
    object _saved_list_65534 = NOVALUE;
    object _block_65535 = NOVALUE;
    object _p_65536 = NOVALUE;
    object _prev_p_65537 = NOVALUE;
    object _first_65538 = NOVALUE;
    object _32266 = NOVALUE;
    object _32264 = NOVALUE;
    object _32263 = NOVALUE;
    object _32262 = NOVALUE;
    object _32260 = NOVALUE;
    object _32258 = NOVALUE;
    object _32255 = NOVALUE;
    object _32253 = NOVALUE;
    object _32251 = NOVALUE;
    object _32249 = NOVALUE;
    object _32248 = NOVALUE;
    object _32244 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:304		saved = SymTab[rtn_idx][S_SAVED_PRIVATES]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32244 = (object)*(((s1_ptr)_2)->base + _rtn_idx_65531);
    DeRef(_saved_65533);
    _2 = (object)SEQ_PTR(_32244);
    _saved_65533 = (object)*(((s1_ptr)_2)->base + 26LL);
    Ref(_saved_65533);
    _32244 = NOVALUE;

    /** execute.e:305		first = saved[1]*/
    _2 = (object)SEQ_PTR(_saved_65533);
    _first_65538 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_first_65538))
    _first_65538 = (object)DBL_PTR(_first_65538)->dbl;

    /** execute.e:306		p = first -- won't be 0*/
    _p_65536 = _first_65538;

    /** execute.e:307		prev_p = -1*/
    _prev_p_65537 = -1LL;

    /** execute.e:308		saved_list = saved[2]*/
    DeRef(_saved_list_65534);
    _2 = (object)SEQ_PTR(_saved_65533);
    _saved_list_65534 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_saved_list_65534);

    /** execute.e:309		while TRUE do*/
L1: 
    if (_9TRUE_441 == 0)
    {
        goto L2; // [52] 200
    }
    else{
    }

    /** execute.e:310			if saved_list[p][SP_TASK_NUMBER] = task then*/
    _2 = (object)SEQ_PTR(_saved_list_65534);
    _32248 = (object)*(((s1_ptr)_2)->base + _p_65536);
    _2 = (object)SEQ_PTR(_32248);
    _32249 = (object)*(((s1_ptr)_2)->base + 1LL);
    _32248 = NOVALUE;
    if (binary_op_a(NOTEQ, _32249, _task_65532)){
        _32249 = NOVALUE;
        goto L3; // [65] 178
    }
    _32249 = NOVALUE;

    /** execute.e:312				block = saved_list[p][SP_BLOCK]*/
    _2 = (object)SEQ_PTR(_saved_list_65534);
    _32251 = (object)*(((s1_ptr)_2)->base + _p_65536);
    DeRef(_block_65535);
    _2 = (object)SEQ_PTR(_32251);
    _block_65535 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_block_65535);
    _32251 = NOVALUE;

    /** execute.e:313				saved_list[p][SP_TASK_NUMBER] = -1 -- mark it as deleted*/
    _2 = (object)SEQ_PTR(_saved_list_65534);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_list_65534 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_65536 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1LL;
    DeRef(_1);
    _32253 = NOVALUE;

    /** execute.e:314				saved_list[p][SP_BLOCK] = {}*/
    _2 = (object)SEQ_PTR(_saved_list_65534);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_list_65534 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_65536 + ((s1_ptr)_2)->base);
    RefDS(_22218);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22218;
    DeRef(_1);
    _32255 = NOVALUE;

    /** execute.e:315				if prev_p = -1 then*/
    if (_prev_p_65537 != -1LL)
    goto L4; // [105] 124

    /** execute.e:316					first = saved_list[p][SP_NEXT]*/
    _2 = (object)SEQ_PTR(_saved_list_65534);
    _32258 = (object)*(((s1_ptr)_2)->base + _p_65536);
    _2 = (object)SEQ_PTR(_32258);
    _first_65538 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_first_65538)){
        _first_65538 = (object)DBL_PTR(_first_65538)->dbl;
    }
    _32258 = NOVALUE;
    goto L5; // [121] 144
L4: 

    /** execute.e:318					saved_list[prev_p][SP_NEXT] = saved_list[p][SP_NEXT]*/
    _2 = (object)SEQ_PTR(_saved_list_65534);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_list_65534 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_p_65537 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_saved_list_65534);
    _32262 = (object)*(((s1_ptr)_2)->base + _p_65536);
    _2 = (object)SEQ_PTR(_32262);
    _32263 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32262 = NOVALUE;
    Ref(_32263);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32263;
    if( _1 != _32263 ){
        DeRef(_1);
    }
    _32263 = NOVALUE;
    _32260 = NOVALUE;
L5: 

    /** execute.e:320				saved[1] = first*/
    _2 = (object)SEQ_PTR(_saved_65533);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_65533 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _first_65538;
    DeRef(_1);

    /** execute.e:321				saved[2] = saved_list*/
    RefDS(_saved_list_65534);
    _2 = (object)SEQ_PTR(_saved_65533);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_65533 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _saved_list_65534;
    DeRef(_1);

    /** execute.e:322				SymTab[rtn_idx][S_SAVED_PRIVATES] = saved*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_rtn_idx_65531 + ((s1_ptr)_2)->base);
    RefDS(_saved_65533);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 26LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _saved_65533;
    DeRef(_1);
    _32264 = NOVALUE;

    /** execute.e:323				return block*/
    DeRefDS(_saved_65533);
    DeRefDS(_saved_list_65534);
    return _block_65535;
L3: 

    /** execute.e:325			prev_p = p*/
    _prev_p_65537 = _p_65536;

    /** execute.e:326			p = saved_list[p][SP_NEXT]*/
    _2 = (object)SEQ_PTR(_saved_list_65534);
    _32266 = (object)*(((s1_ptr)_2)->base + _p_65536);
    _2 = (object)SEQ_PTR(_32266);
    _p_65536 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_p_65536)){
        _p_65536 = (object)DBL_PTR(_p_65536)->dbl;
    }
    _32266 = NOVALUE;

    /** execute.e:327		end while*/
    goto L1; // [197] 50
L2: 
    ;
}


void _67restore_privates(object _this_routine_65575)
{
    object _arg_65577 = NOVALUE;
    object _private_block_65578 = NOVALUE;
    object _base_65579 = NOVALUE;
    object _32333 = NOVALUE;
    object _32331 = NOVALUE;
    object _32329 = NOVALUE;
    object _32326 = NOVALUE;
    object _32324 = NOVALUE;
    object _32322 = NOVALUE;
    object _32320 = NOVALUE;
    object _32319 = NOVALUE;
    object _32318 = NOVALUE;
    object _32317 = NOVALUE;
    object _32316 = NOVALUE;
    object _32315 = NOVALUE;
    object _32314 = NOVALUE;
    object _32313 = NOVALUE;
    object _32312 = NOVALUE;
    object _32311 = NOVALUE;
    object _32310 = NOVALUE;
    object _32309 = NOVALUE;
    object _32308 = NOVALUE;
    object _32307 = NOVALUE;
    object _32306 = NOVALUE;
    object _32304 = NOVALUE;
    object _32301 = NOVALUE;
    object _32299 = NOVALUE;
    object _32296 = NOVALUE;
    object _32294 = NOVALUE;
    object _32292 = NOVALUE;
    object _32290 = NOVALUE;
    object _32289 = NOVALUE;
    object _32288 = NOVALUE;
    object _32287 = NOVALUE;
    object _32286 = NOVALUE;
    object _32285 = NOVALUE;
    object _32284 = NOVALUE;
    object _32283 = NOVALUE;
    object _32282 = NOVALUE;
    object _32281 = NOVALUE;
    object _32280 = NOVALUE;
    object _32279 = NOVALUE;
    object _32278 = NOVALUE;
    object _32277 = NOVALUE;
    object _32276 = NOVALUE;
    object _32274 = NOVALUE;
    object _32272 = NOVALUE;
    object _32271 = NOVALUE;
    object _32269 = NOVALUE;
    object _32268 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_this_routine_65575)) {
        _1 = (object)(DBL_PTR(_this_routine_65575)->dbl);
        DeRefDS(_this_routine_65575);
        _this_routine_65575 = _1;
    }

    /** execute.e:334		sequence private_block*/

    /** execute.e:335		integer base*/

    /** execute.e:337		if SymTab[this_routine][S_RESIDENT_TASK] != current_task then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32268 = (object)*(((s1_ptr)_2)->base + _this_routine_65575);
    _2 = (object)SEQ_PTR(_32268);
    _32269 = (object)*(((s1_ptr)_2)->base + 25LL);
    _32268 = NOVALUE;
    if (binary_op_a(EQUALS, _32269, _67current_task_65347)){
        _32269 = NOVALUE;
        goto L1; // [23] 535
    }
    _32269 = NOVALUE;

    /** execute.e:340			if SymTab[this_routine][S_RESIDENT_TASK] != 0 then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32271 = (object)*(((s1_ptr)_2)->base + _this_routine_65575);
    _2 = (object)SEQ_PTR(_32271);
    _32272 = (object)*(((s1_ptr)_2)->base + 25LL);
    _32271 = NOVALUE;
    if (binary_op_a(EQUALS, _32272, 0LL)){
        _32272 = NOVALUE;
        goto L2; // [41] 274
    }
    _32272 = NOVALUE;

    /** execute.e:346				arg = SymTab[this_routine][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32274 = (object)*(((s1_ptr)_2)->base + _this_routine_65575);
    _2 = (object)SEQ_PTR(_32274);
    _arg_65577 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_arg_65577)){
        _arg_65577 = (object)DBL_PTR(_arg_65577)->dbl;
    }
    _32274 = NOVALUE;

    /** execute.e:347				private_block = {}*/
    RefDS(_22218);
    DeRef(_private_block_65578);
    _private_block_65578 = _22218;

    /** execute.e:349				while arg != 0 */
L3: 
    _32276 = (_arg_65577 != 0LL);
    if (_32276 == 0) {
        goto L4; // [77] 209
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32278 = (object)*(((s1_ptr)_2)->base + _arg_65577);
    _2 = (object)SEQ_PTR(_32278);
    _32279 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32278 = NOVALUE;
    if (IS_ATOM_INT(_32279)) {
        _32280 = (_32279 <= 3LL);
    }
    else {
        _32280 = binary_op(LESSEQ, _32279, 3LL);
    }
    _32279 = NOVALUE;
    if (IS_ATOM_INT(_32280)) {
        if (_32280 != 0) {
            DeRef(_32281);
            _32281 = 1;
            goto L5; // [99] 125
        }
    }
    else {
        if (DBL_PTR(_32280)->dbl != 0.0) {
            DeRef(_32281);
            _32281 = 1;
            goto L5; // [99] 125
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32282 = (object)*(((s1_ptr)_2)->base + _arg_65577);
    _2 = (object)SEQ_PTR(_32282);
    _32283 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32282 = NOVALUE;
    if (IS_ATOM_INT(_32283)) {
        _32284 = (_32283 == 2LL);
    }
    else {
        _32284 = binary_op(EQUALS, _32283, 2LL);
    }
    _32283 = NOVALUE;
    DeRef(_32281);
    if (IS_ATOM_INT(_32284))
    _32281 = (_32284 != 0);
    else
    _32281 = DBL_PTR(_32284)->dbl != 0.0;
L5: 
    if (_32281 != 0) {
        DeRef(_32285);
        _32285 = 1;
        goto L6; // [125] 151
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32286 = (object)*(((s1_ptr)_2)->base + _arg_65577);
    _2 = (object)SEQ_PTR(_32286);
    _32287 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32286 = NOVALUE;
    if (IS_ATOM_INT(_32287)) {
        _32288 = (_32287 == 9LL);
    }
    else {
        _32288 = binary_op(EQUALS, _32287, 9LL);
    }
    _32287 = NOVALUE;
    if (IS_ATOM_INT(_32288))
    _32285 = (_32288 != 0);
    else
    _32285 = DBL_PTR(_32288)->dbl != 0.0;
L6: 
    if (_32285 == 0)
    {
        _32285 = NOVALUE;
        goto L4; // [152] 209
    }
    else{
        _32285 = NOVALUE;
    }

    /** execute.e:354					if SymTab[arg][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32289 = (object)*(((s1_ptr)_2)->base + _arg_65577);
    _2 = (object)SEQ_PTR(_32289);
    _32290 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32289 = NOVALUE;
    if (binary_op_a(EQUALS, _32290, 9LL)){
        _32290 = NOVALUE;
        goto L7; // [171] 188
    }
    _32290 = NOVALUE;

    /** execute.e:355						private_block = append(private_block, val[arg])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _32292 = (object)*(((s1_ptr)_2)->base + _arg_65577);
    Ref(_32292);
    Append(&_private_block_65578, _private_block_65578, _32292);
    _32292 = NOVALUE;
L7: 

    /** execute.e:357					arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32294 = (object)*(((s1_ptr)_2)->base + _arg_65577);
    _2 = (object)SEQ_PTR(_32294);
    _arg_65577 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_arg_65577)){
        _arg_65577 = (object)DBL_PTR(_arg_65577)->dbl;
    }
    _32294 = NOVALUE;

    /** execute.e:358				end while*/
    goto L3; // [206] 73
L4: 

    /** execute.e:361				arg = SymTab[this_routine][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32296 = (object)*(((s1_ptr)_2)->base + _this_routine_65575);
    _2 = (object)SEQ_PTR(_32296);
    if (!IS_ATOM_INT(_27S_TEMPS_20254)){
        _arg_65577 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TEMPS_20254)->dbl));
    }
    else{
        _arg_65577 = (object)*(((s1_ptr)_2)->base + _27S_TEMPS_20254);
    }
    if (!IS_ATOM_INT(_arg_65577)){
        _arg_65577 = (object)DBL_PTR(_arg_65577)->dbl;
    }
    _32296 = NOVALUE;

    /** execute.e:362				while arg != 0 do*/
L8: 
    if (_arg_65577 == 0LL)
    goto L9; // [230] 267

    /** execute.e:363					private_block = append(private_block, val[arg])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _32299 = (object)*(((s1_ptr)_2)->base + _arg_65577);
    Ref(_32299);
    Append(&_private_block_65578, _private_block_65578, _32299);
    _32299 = NOVALUE;

    /** execute.e:364					arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32301 = (object)*(((s1_ptr)_2)->base + _arg_65577);
    _2 = (object)SEQ_PTR(_32301);
    _arg_65577 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_arg_65577)){
        _arg_65577 = (object)DBL_PTR(_arg_65577)->dbl;
    }
    _32301 = NOVALUE;

    /** execute.e:365				end while*/
    goto L8; // [264] 230
L9: 

    /** execute.e:367				save_private_block(this_routine, private_block)*/
    RefDS(_private_block_65578);
    _67save_private_block(_this_routine_65575, _private_block_65578);
L2: 

    /** execute.e:371			private_block = load_private_block(this_routine, current_task)*/
    _0 = _private_block_65578;
    _private_block_65578 = _67load_private_block(_this_routine_65575, _67current_task_65347);
    DeRef(_0);

    /** execute.e:374			base = 1*/
    _base_65579 = 1LL;

    /** execute.e:375			arg = SymTab[this_routine][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32304 = (object)*(((s1_ptr)_2)->base + _this_routine_65575);
    _2 = (object)SEQ_PTR(_32304);
    _arg_65577 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_arg_65577)){
        _arg_65577 = (object)DBL_PTR(_arg_65577)->dbl;
    }
    _32304 = NOVALUE;

    /** execute.e:376			while arg != 0 */
LA: 
    _32306 = (_arg_65577 != 0LL);
    if (_32306 == 0) {
        goto LB; // [315] 453
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32308 = (object)*(((s1_ptr)_2)->base + _arg_65577);
    _2 = (object)SEQ_PTR(_32308);
    _32309 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32308 = NOVALUE;
    if (IS_ATOM_INT(_32309)) {
        _32310 = (_32309 <= 3LL);
    }
    else {
        _32310 = binary_op(LESSEQ, _32309, 3LL);
    }
    _32309 = NOVALUE;
    if (IS_ATOM_INT(_32310)) {
        if (_32310 != 0) {
            DeRef(_32311);
            _32311 = 1;
            goto LC; // [337] 363
        }
    }
    else {
        if (DBL_PTR(_32310)->dbl != 0.0) {
            DeRef(_32311);
            _32311 = 1;
            goto LC; // [337] 363
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32312 = (object)*(((s1_ptr)_2)->base + _arg_65577);
    _2 = (object)SEQ_PTR(_32312);
    _32313 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32312 = NOVALUE;
    if (IS_ATOM_INT(_32313)) {
        _32314 = (_32313 == 2LL);
    }
    else {
        _32314 = binary_op(EQUALS, _32313, 2LL);
    }
    _32313 = NOVALUE;
    DeRef(_32311);
    if (IS_ATOM_INT(_32314))
    _32311 = (_32314 != 0);
    else
    _32311 = DBL_PTR(_32314)->dbl != 0.0;
LC: 
    if (_32311 != 0) {
        DeRef(_32315);
        _32315 = 1;
        goto LD; // [363] 389
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32316 = (object)*(((s1_ptr)_2)->base + _arg_65577);
    _2 = (object)SEQ_PTR(_32316);
    _32317 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32316 = NOVALUE;
    if (IS_ATOM_INT(_32317)) {
        _32318 = (_32317 == 9LL);
    }
    else {
        _32318 = binary_op(EQUALS, _32317, 9LL);
    }
    _32317 = NOVALUE;
    if (IS_ATOM_INT(_32318))
    _32315 = (_32318 != 0);
    else
    _32315 = DBL_PTR(_32318)->dbl != 0.0;
LD: 
    if (_32315 == 0)
    {
        _32315 = NOVALUE;
        goto LB; // [390] 453
    }
    else{
        _32315 = NOVALUE;
    }

    /** execute.e:381				if SymTab[arg][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32319 = (object)*(((s1_ptr)_2)->base + _arg_65577);
    _2 = (object)SEQ_PTR(_32319);
    _32320 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32319 = NOVALUE;
    if (binary_op_a(EQUALS, _32320, 9LL)){
        _32320 = NOVALUE;
        goto LE; // [409] 432
    }
    _32320 = NOVALUE;

    /** execute.e:382					val[arg] = private_block[base]*/
    _2 = (object)SEQ_PTR(_private_block_65578);
    _32322 = (object)*(((s1_ptr)_2)->base + _base_65579);
    Ref(_32322);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _arg_65577);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32322;
    if( _1 != _32322 ){
        DeRef(_1);
    }
    _32322 = NOVALUE;

    /** execute.e:383					base += 1*/
    _base_65579 = _base_65579 + 1;
LE: 

    /** execute.e:385				arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32324 = (object)*(((s1_ptr)_2)->base + _arg_65577);
    _2 = (object)SEQ_PTR(_32324);
    _arg_65577 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_arg_65577)){
        _arg_65577 = (object)DBL_PTR(_arg_65577)->dbl;
    }
    _32324 = NOVALUE;

    /** execute.e:386			end while*/
    goto LA; // [450] 311
LB: 

    /** execute.e:389			arg = SymTab[this_routine][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32326 = (object)*(((s1_ptr)_2)->base + _this_routine_65575);
    _2 = (object)SEQ_PTR(_32326);
    if (!IS_ATOM_INT(_27S_TEMPS_20254)){
        _arg_65577 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TEMPS_20254)->dbl));
    }
    else{
        _arg_65577 = (object)*(((s1_ptr)_2)->base + _27S_TEMPS_20254);
    }
    if (!IS_ATOM_INT(_arg_65577)){
        _arg_65577 = (object)DBL_PTR(_arg_65577)->dbl;
    }
    _32326 = NOVALUE;

    /** execute.e:390			while arg != 0 do*/
LF: 
    if (_arg_65577 == 0LL)
    goto L10; // [474] 517

    /** execute.e:391				val[arg] = private_block[base]*/
    _2 = (object)SEQ_PTR(_private_block_65578);
    _32329 = (object)*(((s1_ptr)_2)->base + _base_65579);
    Ref(_32329);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _arg_65577);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32329;
    if( _1 != _32329 ){
        DeRef(_1);
    }
    _32329 = NOVALUE;

    /** execute.e:392				base += 1*/
    _base_65579 = _base_65579 + 1;

    /** execute.e:393				arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32331 = (object)*(((s1_ptr)_2)->base + _arg_65577);
    _2 = (object)SEQ_PTR(_32331);
    _arg_65577 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_arg_65577)){
        _arg_65577 = (object)DBL_PTR(_arg_65577)->dbl;
    }
    _32331 = NOVALUE;

    /** execute.e:394			end while*/
    goto LF; // [514] 474
L10: 

    /** execute.e:396			SymTab[this_routine][S_RESIDENT_TASK] = current_task*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_this_routine_65575 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67current_task_65347;
    DeRef(_1);
    _32333 = NOVALUE;
L1: 

    /** execute.e:398	end procedure*/
    DeRef(_private_block_65578);
    DeRef(_32280);
    _32280 = NOVALUE;
    DeRef(_32314);
    _32314 = NOVALUE;
    DeRef(_32306);
    _32306 = NOVALUE;
    DeRef(_32318);
    _32318 = NOVALUE;
    DeRef(_32288);
    _32288 = NOVALUE;
    DeRef(_32284);
    _32284 = NOVALUE;
    DeRef(_32276);
    _32276 = NOVALUE;
    DeRef(_32310);
    _32310 = NOVALUE;
    return;
    ;
}


object _67is_slice(object _op_65724)
{
    object _32337 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:426		return find( op, SLICE_OPS )*/
    _32337 = find_from(_op_65724, _67SLICE_OPS_65715, 1LL);
    return _32337;
    ;
}


object _67is_subs(object _op_65728)
{
    object _32339 = NOVALUE;
    object _32338 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:430		if find( op, SUB_OPS ) then*/
    _32338 = find_from(_op_65728, _67SUB_OPS_65701, 1LL);
    if (_32338 == 0)
    {
        _32338 = NOVALUE;
        goto L1; // [12] 24
    }
    else{
        _32338 = NOVALUE;
    }

    /** execute.e:431			return 1*/
    return 1LL;
    goto L2; // [21] 35
L1: 

    /** execute.e:433			return is_slice( op )*/
    _32339 = _67is_slice(_op_65728);
    return _32339;
L2: 
    ;
}


object _67subs_opsize(object _op_65735)
{
    object _32371 = NOVALUE;
    object _32369 = NOVALUE;
    object _32368 = NOVALUE;
    object _32367 = NOVALUE;
    object _32366 = NOVALUE;
    object _32365 = NOVALUE;
    object _32364 = NOVALUE;
    object _32363 = NOVALUE;
    object _32362 = NOVALUE;
    object _32361 = NOVALUE;
    object _32360 = NOVALUE;
    object _32359 = NOVALUE;
    object _32358 = NOVALUE;
    object _32357 = NOVALUE;
    object _32356 = NOVALUE;
    object _32355 = NOVALUE;
    object _32354 = NOVALUE;
    object _32352 = NOVALUE;
    object _32351 = NOVALUE;
    object _32350 = NOVALUE;
    object _32349 = NOVALUE;
    object _32348 = NOVALUE;
    object _32347 = NOVALUE;
    object _32346 = NOVALUE;
    object _32345 = NOVALUE;
    object _32344 = NOVALUE;
    object _32343 = NOVALUE;
    object _32342 = NOVALUE;
    object _32341 = NOVALUE;
    object _32340 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:438		if op = RHS_SUBS or op = RHS_SUBS_CHECK or op = PASSIGN_SUBS or op = ASSIGN_SUBS*/
    _32340 = (_op_65735 == 25LL);
    if (_32340 != 0) {
        _32341 = 1;
        goto L1; // [11] 25
    }
    _32342 = (_op_65735 == 92LL);
    _32341 = (_32342 != 0);
L1: 
    if (_32341 != 0) {
        _32343 = 1;
        goto L2; // [25] 39
    }
    _32344 = (_op_65735 == 162LL);
    _32343 = (_32344 != 0);
L2: 
    if (_32343 != 0) {
        _32345 = 1;
        goto L3; // [39] 53
    }
    _32346 = (_op_65735 == 16LL);
    _32345 = (_32346 != 0);
L3: 
    if (_32345 != 0) {
        _32347 = 1;
        goto L4; // [53] 67
    }
    _32348 = (_op_65735 == 149LL);
    _32347 = (_32348 != 0);
L4: 
    if (_32347 != 0) {
        _32349 = 1;
        goto L5; // [67] 81
    }
    _32350 = (_op_65735 == 84LL);
    _32349 = (_32350 != 0);
L5: 
    if (_32349 != 0) {
        _32351 = 1;
        goto L6; // [81] 95
    }
    _32352 = (_op_65735 == 118LL);
    _32351 = (_32352 != 0);
L6: 
    if (_32351 != 0) {
        goto L7; // [95] 110
    }
    _32354 = (_op_65735 == 164LL);
    if (_32354 == 0)
    {
        DeRef(_32354);
        _32354 = NOVALUE;
        goto L8; // [106] 119
    }
    else{
        DeRef(_32354);
        _32354 = NOVALUE;
    }
L7: 

    /** execute.e:442			return 4*/
    DeRef(_32352);
    _32352 = NOVALUE;
    DeRef(_32350);
    _32350 = NOVALUE;
    DeRef(_32346);
    _32346 = NOVALUE;
    DeRef(_32344);
    _32344 = NOVALUE;
    DeRef(_32348);
    _32348 = NOVALUE;
    DeRef(_32342);
    _32342 = NOVALUE;
    DeRef(_32340);
    _32340 = NOVALUE;
    return 4LL;
    goto L9; // [116] 256
L8: 

    /** execute.e:443		elsif op = LHS_SUBS1 or op = LHS_SUBS or op = LHS_SUBS1_COPY*/
    _32355 = (_op_65735 == 161LL);
    if (_32355 != 0) {
        _32356 = 1;
        goto LA; // [127] 141
    }
    _32357 = (_op_65735 == 95LL);
    _32356 = (_32357 != 0);
LA: 
    if (_32356 != 0) {
        _32358 = 1;
        goto LB; // [141] 155
    }
    _32359 = (_op_65735 == 166LL);
    _32358 = (_32359 != 0);
LB: 
    if (_32358 != 0) {
        _32360 = 1;
        goto LC; // [155] 169
    }
    _32361 = (_op_65735 == 45LL);
    _32360 = (_32361 != 0);
LC: 
    if (_32360 != 0) {
        _32362 = 1;
        goto LD; // [169] 183
    }
    _32363 = (_op_65735 == 163LL);
    _32362 = (_32363 != 0);
LD: 
    if (_32362 != 0) {
        _32364 = 1;
        goto LE; // [183] 197
    }
    _32365 = (_op_65735 == 46LL);
    _32364 = (_32365 != 0);
LE: 
    if (_32364 != 0) {
        _32366 = 1;
        goto LF; // [197] 211
    }
    _32367 = (_op_65735 == 150LL);
    _32366 = (_32367 != 0);
LF: 
    if (_32366 != 0) {
        _32368 = 1;
        goto L10; // [211] 225
    }
    _32369 = (_op_65735 == 165LL);
    _32368 = (_32369 != 0);
L10: 
    if (_32368 != 0) {
        goto L11; // [225] 240
    }
    _32371 = (_op_65735 == 163LL);
    if (_32371 == 0)
    {
        DeRef(_32371);
        _32371 = NOVALUE;
        goto L12; // [236] 249
    }
    else{
        DeRef(_32371);
        _32371 = NOVALUE;
    }
L11: 

    /** execute.e:448			return 5*/
    DeRef(_32357);
    _32357 = NOVALUE;
    DeRef(_32365);
    _32365 = NOVALUE;
    DeRef(_32355);
    _32355 = NOVALUE;
    DeRef(_32361);
    _32361 = NOVALUE;
    DeRef(_32363);
    _32363 = NOVALUE;
    DeRef(_32352);
    _32352 = NOVALUE;
    DeRef(_32369);
    _32369 = NOVALUE;
    DeRef(_32350);
    _32350 = NOVALUE;
    DeRef(_32346);
    _32346 = NOVALUE;
    DeRef(_32359);
    _32359 = NOVALUE;
    DeRef(_32344);
    _32344 = NOVALUE;
    DeRef(_32348);
    _32348 = NOVALUE;
    DeRef(_32342);
    _32342 = NOVALUE;
    DeRef(_32340);
    _32340 = NOVALUE;
    DeRef(_32367);
    _32367 = NOVALUE;
    return 5LL;
    goto L9; // [246] 256
L12: 

    /** execute.e:450			return 1*/
    DeRef(_32357);
    _32357 = NOVALUE;
    DeRef(_32365);
    _32365 = NOVALUE;
    DeRef(_32355);
    _32355 = NOVALUE;
    DeRef(_32361);
    _32361 = NOVALUE;
    DeRef(_32363);
    _32363 = NOVALUE;
    DeRef(_32352);
    _32352 = NOVALUE;
    DeRef(_32369);
    _32369 = NOVALUE;
    DeRef(_32350);
    _32350 = NOVALUE;
    DeRef(_32346);
    _32346 = NOVALUE;
    DeRef(_32359);
    _32359 = NOVALUE;
    DeRef(_32344);
    _32344 = NOVALUE;
    DeRef(_32348);
    _32348 = NOVALUE;
    DeRef(_32342);
    _32342 = NOVALUE;
    DeRef(_32340);
    _32340 = NOVALUE;
    DeRef(_32367);
    _32367 = NOVALUE;
    return 1LL;
L9: 
    ;
}


object _67sub_dest_offset(object _op_65790)
{
    object _offset_65791 = NOVALUE;
    object _32376 = NOVALUE;
    object _32374 = NOVALUE;
    object _32372 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:455		integer offset = subs_opsize( op ) - 1*/
    _32372 = _67subs_opsize(_op_65790);
    if (IS_ATOM_INT(_32372)) {
        _offset_65791 = _32372 - 1LL;
    }
    else {
        _offset_65791 = binary_op(MINUS, _32372, 1LL);
    }
    DeRef(_32372);
    _32372 = NOVALUE;
    if (!IS_ATOM_INT(_offset_65791)) {
        _1 = (object)(DBL_PTR(_offset_65791)->dbl);
        DeRefDS(_offset_65791);
        _offset_65791 = _1;
    }

    /** execute.e:456		if op = LHS_SUBS1_COPY or op = LHS_SUBS1 then*/
    _32374 = (_op_65790 == 166LL);
    if (_32374 != 0) {
        goto L1; // [23] 38
    }
    _32376 = (_op_65790 == 161LL);
    if (_32376 == 0)
    {
        DeRef(_32376);
        _32376 = NOVALUE;
        goto L2; // [34] 45
    }
    else{
        DeRef(_32376);
        _32376 = NOVALUE;
    }
L1: 

    /** execute.e:457			offset -= 1*/
    _offset_65791 = _offset_65791 - 1LL;
L2: 

    /** execute.e:459		return offset*/
    DeRef(_32374);
    _32374 = NOVALUE;
    return _offset_65791;
    ;
}


void _67LookBackForSubscriptSymbol(object _pc_65803, object _sublevel_65804, object _has_slice_65805)
{
    object _op_65806 = NOVALUE;
    object _start_pc_65809 = NOVALUE;
    object _sym_65811 = NOVALUE;
    object _subtext_65827 = NOVALUE;
    object _32417 = NOVALUE;
    object _32416 = NOVALUE;
    object _32415 = NOVALUE;
    object _32414 = NOVALUE;
    object _32413 = NOVALUE;
    object _32412 = NOVALUE;
    object _32411 = NOVALUE;
    object _32410 = NOVALUE;
    object _32409 = NOVALUE;
    object _32406 = NOVALUE;
    object _32405 = NOVALUE;
    object _32404 = NOVALUE;
    object _32403 = NOVALUE;
    object _32402 = NOVALUE;
    object _32401 = NOVALUE;
    object _32400 = NOVALUE;
    object _32399 = NOVALUE;
    object _32398 = NOVALUE;
    object _32397 = NOVALUE;
    object _32396 = NOVALUE;
    object _32395 = NOVALUE;
    object _32394 = NOVALUE;
    object _32393 = NOVALUE;
    object _32392 = NOVALUE;
    object _32388 = NOVALUE;
    object _32387 = NOVALUE;
    object _32386 = NOVALUE;
    object _32385 = NOVALUE;
    object _32384 = NOVALUE;
    object _32383 = NOVALUE;
    object _32381 = NOVALUE;
    object _32379 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sublevel_65804)) {
        _1 = (object)(DBL_PTR(_sublevel_65804)->dbl);
        DeRefDS(_sublevel_65804);
        _sublevel_65804 = _1;
    }

    /** execute.e:464		integer op = Code[pc]*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    _op_65806 = (object)*(((s1_ptr)_2)->base + _pc_65803);
    if (!IS_ATOM_INT(_op_65806)){
        _op_65806 = (object)DBL_PTR(_op_65806)->dbl;
    }

    /** execute.e:465		integer start_pc = pc*/
    _start_pc_65809 = _pc_65803;

    /** execute.e:466		symtab_pointer sym = Code[pc+1]*/
    _32379 = _pc_65803 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _sym_65811 = (object)*(((s1_ptr)_2)->base + _32379);
    if (!IS_ATOM_INT(_sym_65811)){
        _sym_65811 = (object)DBL_PTR(_sym_65811)->dbl;
    }

    /** execute.e:467		has_slice = has_slice or is_slice( op )*/
    _32381 = _67is_slice(_op_65806);
    if (IS_ATOM_INT(_32381)) {
        _has_slice_65805 = (_has_slice_65805 != 0 || _32381 != 0);
    }
    else {
        _has_slice_65805 = binary_op(OR, _has_slice_65805, _32381);
    }
    DeRef(_32381);
    _32381 = NOVALUE;
    if (!IS_ATOM_INT(_has_slice_65805)) {
        _1 = (object)(DBL_PTR(_has_slice_65805)->dbl);
        DeRefDS(_has_slice_65805);
        _has_slice_65805 = _1;
    }

    /** execute.e:469		if length( SymTab[sym] ) >= S_NAME and length( sym_name( sym ) ) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32383 = (object)*(((s1_ptr)_2)->base + _sym_65811);
    if (IS_SEQUENCE(_32383)){
            _32384 = SEQ_PTR(_32383)->length;
    }
    else {
        _32384 = 1;
    }
    _32383 = NOVALUE;
    if (IS_ATOM_INT(_27S_NAME_20209)) {
        _32385 = (_32384 >= _27S_NAME_20209);
    }
    else {
        _32385 = binary_op(GREATEREQ, _32384, _27S_NAME_20209);
    }
    _32384 = NOVALUE;
    if (IS_ATOM_INT(_32385)) {
        if (_32385 == 0) {
            goto L1; // [65] 204
        }
    }
    else {
        if (DBL_PTR(_32385)->dbl == 0.0) {
            goto L1; // [65] 204
        }
    }
    _32387 = _53sym_name(_sym_65811);
    if (IS_SEQUENCE(_32387)){
            _32388 = SEQ_PTR(_32387)->length;
    }
    else {
        _32388 = 1;
    }
    DeRef(_32387);
    _32387 = NOVALUE;
    if (_32388 == 0)
    {
        _32388 = NOVALUE;
        goto L1; // [77] 204
    }
    else{
        _32388 = NOVALUE;
    }

    /** execute.e:470			sequence subtext*/

    /** execute.e:471			if has_slice then*/
    if (_has_slice_65805 == 0)
    {
        goto L2; // [84] 97
    }
    else{
    }

    /** execute.e:472				subtext = "slice/subscript"*/
    RefDS(_32389);
    DeRefi(_subtext_65827);
    _subtext_65827 = _32389;
    goto L3; // [94] 105
L2: 

    /** execute.e:474				subtext = "subscript"*/
    RefDS(_32390);
    DeRefi(_subtext_65827);
    _subtext_65827 = _32390;
L3: 

    /** execute.e:476			both_printf(" - in %s #%d of '%s'", { subtext, sublevel, sym_name( sym ) } )*/
    _32392 = _53sym_name(_sym_65811);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_subtext_65827);
    ((intptr_t*)_2)[1] = _subtext_65827;
    ((intptr_t*)_2)[2] = _sublevel_65804;
    ((intptr_t*)_2)[3] = _32392;
    _32393 = MAKE_SEQ(_1);
    _32392 = NOVALUE;
    RefDS(_32391);
    _67both_printf(_32391, _32393);
    _32393 = NOVALUE;
    DeRefDSi(_subtext_65827);
    _subtext_65827 = NOVALUE;
    goto L4; // [125] 276

    /** execute.e:480			while pc > 1*/
    goto L1; // [130] 204
L5: 
    _32394 = (_pc_65803 > 1LL);
    if (_32394 == 0) {
        DeRef(_32395);
        _32395 = 0;
        goto L6; // [137] 198
    }
    _32396 = _67is_subs(_op_65806);
    if (IS_ATOM_INT(_32396)) {
        if (_32396 == 0) {
            DeRef(_32397);
            _32397 = 0;
            goto L7; // [145] 171
        }
    }
    else {
        if (DBL_PTR(_32396)->dbl == 0.0) {
            DeRef(_32397);
            _32397 = 0;
            goto L7; // [145] 171
        }
    }
    _32398 = _67sub_dest_offset(_op_65806);
    if (IS_ATOM_INT(_32398)) {
        _32399 = _pc_65803 + _32398;
    }
    else {
        _32399 = binary_op(PLUS, _pc_65803, _32398);
    }
    DeRef(_32398);
    _32398 = NOVALUE;
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!IS_ATOM_INT(_32399)){
        _32400 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32399)->dbl));
    }
    else{
        _32400 = (object)*(((s1_ptr)_2)->base + _32399);
    }
    if (IS_ATOM_INT(_32400)) {
        _32401 = (_32400 == _sym_65811);
    }
    else {
        _32401 = binary_op(EQUALS, _32400, _sym_65811);
    }
    _32400 = NOVALUE;
    DeRef(_32397);
    if (IS_ATOM_INT(_32401))
    _32397 = (_32401 != 0);
    else
    _32397 = DBL_PTR(_32401)->dbl != 0.0;
L7: 
    _32402 = (_32397 == 0);
    _32397 = NOVALUE;
    if (_32402 != 0) {
        _32403 = 1;
        goto L8; // [174] 194
    }
    _32404 = _67subs_opsize(_op_65806);
    if (IS_ATOM_INT(_32404)) {
        _32405 = _pc_65803 + _32404;
        if ((object)((uintptr_t)_32405 + (uintptr_t)HIGH_BITS) >= 0){
            _32405 = NewDouble((eudouble)_32405);
        }
    }
    else {
        _32405 = binary_op(PLUS, _pc_65803, _32404);
    }
    DeRef(_32404);
    _32404 = NOVALUE;
    if (IS_ATOM_INT(_32405)) {
        _32406 = (_start_pc_65809 <= _32405);
    }
    else {
        _32406 = binary_op(LESSEQ, _start_pc_65809, _32405);
    }
    DeRef(_32405);
    _32405 = NOVALUE;
    if (IS_ATOM_INT(_32406))
    _32403 = (_32406 != 0);
    else
    _32403 = DBL_PTR(_32406)->dbl != 0.0;
L8: 
    DeRef(_32395);
    _32395 = (_32403 != 0);
L6: 
    if (_32395 == 0)
    {
        _32395 = NOVALUE;
        goto L9; // [198] 225
    }
    else{
        _32395 = NOVALUE;
    }

    /** execute.e:487			entry*/
L1: 

    /** execute.e:488				pc -= 1*/
    _pc_65803 = _pc_65803 - 1LL;

    /** execute.e:489				op = Code[pc]*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    _op_65806 = (object)*(((s1_ptr)_2)->base + _pc_65803);
    if (!IS_ATOM_INT(_op_65806)){
        _op_65806 = (object)DBL_PTR(_op_65806)->dbl;
    }

    /** execute.e:490			end while*/
    goto L5; // [222] 133
L9: 

    /** execute.e:492			if is_subs( op ) and (Code[pc + sub_dest_offset( op )] = sym) then*/
    _32409 = _67is_subs(_op_65806);
    if (IS_ATOM_INT(_32409)) {
        if (_32409 == 0) {
            goto LA; // [231] 275
        }
    }
    else {
        if (DBL_PTR(_32409)->dbl == 0.0) {
            goto LA; // [231] 275
        }
    }
    _32411 = _67sub_dest_offset(_op_65806);
    if (IS_ATOM_INT(_32411)) {
        _32412 = _pc_65803 + _32411;
    }
    else {
        _32412 = binary_op(PLUS, _pc_65803, _32411);
    }
    DeRef(_32411);
    _32411 = NOVALUE;
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!IS_ATOM_INT(_32412)){
        _32413 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32412)->dbl));
    }
    else{
        _32413 = (object)*(((s1_ptr)_2)->base + _32412);
    }
    if (IS_ATOM_INT(_32413)) {
        _32414 = (_32413 == _sym_65811);
    }
    else {
        _32414 = binary_op(EQUALS, _32413, _sym_65811);
    }
    _32413 = NOVALUE;
    if (_32414 == 0) {
        DeRef(_32414);
        _32414 = NOVALUE;
        goto LA; // [254] 275
    }
    else {
        if (!IS_ATOM_INT(_32414) && DBL_PTR(_32414)->dbl == 0.0){
            DeRef(_32414);
            _32414 = NOVALUE;
            goto LA; // [254] 275
        }
        DeRef(_32414);
        _32414 = NOVALUE;
    }
    DeRef(_32414);
    _32414 = NOVALUE;

    /** execute.e:493				LookBackForSubscriptSymbol( pc, sublevel + 1, has_slice )*/
    _32415 = _sublevel_65804 + 1;
    if (_32415 > MAXINT){
        _32415 = NewDouble((eudouble)_32415);
    }
    DeRef(_32416);
    _32416 = _pc_65803;
    DeRef(_32417);
    _32417 = _has_slice_65805;
    _67LookBackForSubscriptSymbol(_32416, _32415, _32417);
    _32416 = NOVALUE;
    _32415 = NOVALUE;
    _32417 = NOVALUE;
LA: 
L4: 

    /** execute.e:496	end procedure*/
    DeRef(_32412);
    _32412 = NOVALUE;
    DeRef(_32409);
    _32409 = NOVALUE;
    DeRef(_32401);
    _32401 = NOVALUE;
    DeRef(_32402);
    _32402 = NOVALUE;
    DeRef(_32406);
    _32406 = NOVALUE;
    DeRef(_32394);
    _32394 = NOVALUE;
    DeRef(_32396);
    _32396 = NOVALUE;
    _32383 = NOVALUE;
    DeRef(_32379);
    _32379 = NOVALUE;
    _32387 = NOVALUE;
    DeRef(_32399);
    _32399 = NOVALUE;
    DeRef(_32385);
    _32385 = NOVALUE;
    return;
    ;
}


void _67CheckSubsError()
{
    object _op_65868 = NOVALUE;
    object _32419 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:499		integer op = Code[pc]*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    _op_65868 = (object)*(((s1_ptr)_2)->base + _67pc_65330);
    if (!IS_ATOM_INT(_op_65868)){
        _op_65868 = (object)DBL_PTR(_op_65868)->dbl;
    }

    /** execute.e:500		if is_subs( op ) then*/
    _32419 = _67is_subs(_op_65868);
    if (_32419 == 0) {
        DeRef(_32419);
        _32419 = NOVALUE;
        goto L1; // [19] 32
    }
    else {
        if (!IS_ATOM_INT(_32419) && DBL_PTR(_32419)->dbl == 0.0){
            DeRef(_32419);
            _32419 = NOVALUE;
            goto L1; // [19] 32
        }
        DeRef(_32419);
        _32419 = NOVALUE;
    }
    DeRef(_32419);
    _32419 = NOVALUE;

    /** execute.e:501			LookBackForSubscriptSymbol( pc, 1, 0 )*/
    _67LookBackForSubscriptSymbol(_67pc_65330, 1LL, 0LL);
L1: 

    /** execute.e:503	end procedure*/
    return;
    ;
}


void _67trace_back(object _msg_65875)
{
    object _sub_65877 = NOVALUE;
    object _v_65878 = NOVALUE;
    object _levels_65879 = NOVALUE;
    object _prev_file_no_65880 = NOVALUE;
    object _task_65881 = NOVALUE;
    object _dash_count_65882 = NOVALUE;
    object _routine_name_65883 = NOVALUE;
    object _title_65884 = NOVALUE;
    object _show_message_65886 = NOVALUE;
    object _32571 = NOVALUE;
    object _32570 = NOVALUE;
    object _32568 = NOVALUE;
    object _32565 = NOVALUE;
    object _32563 = NOVALUE;
    object _32562 = NOVALUE;
    object _32561 = NOVALUE;
    object _32560 = NOVALUE;
    object _32559 = NOVALUE;
    object _32558 = NOVALUE;
    object _32557 = NOVALUE;
    object _32556 = NOVALUE;
    object _32555 = NOVALUE;
    object _32554 = NOVALUE;
    object _32553 = NOVALUE;
    object _32552 = NOVALUE;
    object _32551 = NOVALUE;
    object _32550 = NOVALUE;
    object _32548 = NOVALUE;
    object _32546 = NOVALUE;
    object _32542 = NOVALUE;
    object _32540 = NOVALUE;
    object _32538 = NOVALUE;
    object _32537 = NOVALUE;
    object _32536 = NOVALUE;
    object _32535 = NOVALUE;
    object _32534 = NOVALUE;
    object _32533 = NOVALUE;
    object _32532 = NOVALUE;
    object _32531 = NOVALUE;
    object _32530 = NOVALUE;
    object _32529 = NOVALUE;
    object _32527 = NOVALUE;
    object _32524 = NOVALUE;
    object _32523 = NOVALUE;
    object _32521 = NOVALUE;
    object _32520 = NOVALUE;
    object _32519 = NOVALUE;
    object _32517 = NOVALUE;
    object _32516 = NOVALUE;
    object _32515 = NOVALUE;
    object _32514 = NOVALUE;
    object _32513 = NOVALUE;
    object _32512 = NOVALUE;
    object _32511 = NOVALUE;
    object _32510 = NOVALUE;
    object _32509 = NOVALUE;
    object _32508 = NOVALUE;
    object _32506 = NOVALUE;
    object _32504 = NOVALUE;
    object _32503 = NOVALUE;
    object _32502 = NOVALUE;
    object _32501 = NOVALUE;
    object _32500 = NOVALUE;
    object _32499 = NOVALUE;
    object _32498 = NOVALUE;
    object _32497 = NOVALUE;
    object _32496 = NOVALUE;
    object _32495 = NOVALUE;
    object _32494 = NOVALUE;
    object _32493 = NOVALUE;
    object _32492 = NOVALUE;
    object _32491 = NOVALUE;
    object _32490 = NOVALUE;
    object _32488 = NOVALUE;
    object _32486 = NOVALUE;
    object _32485 = NOVALUE;
    object _32484 = NOVALUE;
    object _32483 = NOVALUE;
    object _32482 = NOVALUE;
    object _32474 = NOVALUE;
    object _32473 = NOVALUE;
    object _32471 = NOVALUE;
    object _32470 = NOVALUE;
    object _32469 = NOVALUE;
    object _32468 = NOVALUE;
    object _32457 = NOVALUE;
    object _32456 = NOVALUE;
    object _32455 = NOVALUE;
    object _32452 = NOVALUE;
    object _32450 = NOVALUE;
    object _32449 = NOVALUE;
    object _32448 = NOVALUE;
    object _32447 = NOVALUE;
    object _32443 = NOVALUE;
    object _32441 = NOVALUE;
    object _32438 = NOVALUE;
    object _32437 = NOVALUE;
    object _32436 = NOVALUE;
    object _32433 = NOVALUE;
    object _32432 = NOVALUE;
    object _32431 = NOVALUE;
    object _32430 = NOVALUE;
    object _32429 = NOVALUE;
    object _32425 = NOVALUE;
    object _32422 = NOVALUE;
    object _32421 = NOVALUE;
    object _32420 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:508		integer levels, prev_file_no, task, dash_count*/

    /** execute.e:509		sequence routine_name, title*/

    /** execute.e:512		if atom(slist[$]) then*/
    if (IS_SEQUENCE(_27slist_20662)){
            _32420 = SEQ_PTR(_27slist_20662)->length;
    }
    else {
        _32420 = 1;
    }
    _2 = (object)SEQ_PTR(_27slist_20662);
    _32421 = (object)*(((s1_ptr)_2)->base + _32420);
    _32422 = IS_ATOM(_32421);
    _32421 = NOVALUE;
    if (_32422 == 0)
    {
        _32422 = NOVALUE;
        goto L1; // [21] 35
    }
    else{
        _32422 = NOVALUE;
    }

    /** execute.e:513			slist = s_expand(slist)*/
    RefDS(_27slist_20662);
    _0 = _61s_expand(_27slist_20662);
    DeRefDS(_27slist_20662);
    _27slist_20662 = _0;
L1: 

    /** execute.e:518		show_message = TRUE*/
    _show_message_65886 = _9TRUE_441;

    /** execute.e:520		screen_err_out = atom(crash_msg)*/
    _67screen_err_out_65391 = IS_ATOM(_67crash_msg_65256);

    /** execute.e:522		while TRUE do*/
L2: 
    if (_9TRUE_441 == 0)
    {
        goto L3; // [56] 978
    }
    else{
    }

    /** execute.e:523			if length(tcb) > 1 then*/
    if (IS_SEQUENCE(_67tcb_65374)){
            _32425 = SEQ_PTR(_67tcb_65374)->length;
    }
    else {
        _32425 = 1;
    }
    if (_32425 <= 1LL)
    goto L4; // [66] 208

    /** execute.e:526				if current_task = 1 then*/
    if (_67current_task_65347 != 1LL)
    goto L5; // [74] 88

    /** execute.e:527					routine_name = "initial task"*/
    RefDS(_32428);
    DeRef(_routine_name_65883);
    _routine_name_65883 = _32428;
    goto L6; // [85] 127
L5: 

    /** execute.e:529					routine_name = SymTab[e_routine[1+tcb[current_task][TASK_RID]]][S_NAME]*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32429 = (object)*(((s1_ptr)_2)->base + _67current_task_65347);
    _2 = (object)SEQ_PTR(_32429);
    _32430 = (object)*(((s1_ptr)_2)->base + 1LL);
    _32429 = NOVALUE;
    if (IS_ATOM_INT(_32430)) {
        _32431 = _32430 + 1;
    }
    else
    _32431 = binary_op(PLUS, 1, _32430);
    _32430 = NOVALUE;
    _2 = (object)SEQ_PTR(_67e_routine_65379);
    if (!IS_ATOM_INT(_32431)){
        _32432 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32431)->dbl));
    }
    else{
        _32432 = (object)*(((s1_ptr)_2)->base + _32431);
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32433 = (object)*(((s1_ptr)_2)->base + _32432);
    DeRef(_routine_name_65883);
    _2 = (object)SEQ_PTR(_32433);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _routine_name_65883 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _routine_name_65883 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    Ref(_routine_name_65883);
    _32433 = NOVALUE;
L6: 

    /** execute.e:532				title = sprintf(" TASK ID %d: %s ",*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32436 = (object)*(((s1_ptr)_2)->base + _67current_task_65347);
    _2 = (object)SEQ_PTR(_32436);
    _32437 = (object)*(((s1_ptr)_2)->base + 2LL);
    _32436 = NOVALUE;
    RefDS(_routine_name_65883);
    Ref(_32437);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _32437;
    ((intptr_t *)_2)[2] = _routine_name_65883;
    _32438 = MAKE_SEQ(_1);
    _32437 = NOVALUE;
    DeRefi(_title_65884);
    _title_65884 = EPrintf(-9999999, _32435, _32438);
    DeRefDS(_32438);
    _32438 = NOVALUE;

    /** execute.e:534				dash_count = 60*/
    _dash_count_65882 = 60LL;

    /** execute.e:535				if length(title) < dash_count then*/
    if (IS_SEQUENCE(_title_65884)){
            _32441 = SEQ_PTR(_title_65884)->length;
    }
    else {
        _32441 = 1;
    }
    if (_32441 >= 60LL)
    goto L7; // [161] 175

    /** execute.e:536					dash_count = 52 - length(title)*/
    if (IS_SEQUENCE(_title_65884)){
            _32443 = SEQ_PTR(_title_65884)->length;
    }
    else {
        _32443 = 1;
    }
    _dash_count_65882 = 52LL - _32443;
    _32443 = NOVALUE;
L7: 

    /** execute.e:538				if dash_count < 1 then*/
    if (_dash_count_65882 >= 1LL)
    goto L8; // [177] 187

    /** execute.e:539					dash_count = 1*/
    _dash_count_65882 = 1LL;
L8: 

    /** execute.e:541				both_puts(repeat('-', 22) & title & repeat('-', dash_count) & "\n")*/
    _32447 = Repeat(45LL, 22LL);
    _32448 = Repeat(45LL, _dash_count_65882);
    {
        object concat_list[4];

        concat_list[0] = _22425;
        concat_list[1] = _32448;
        concat_list[2] = _title_65884;
        concat_list[3] = _32447;
        Concat_N((object_ptr)&_32449, concat_list, 4);
    }
    DeRefDS(_32448);
    _32448 = NOVALUE;
    DeRefDS(_32447);
    _32447 = NOVALUE;
    _67both_puts(_32449);
    _32449 = NOVALUE;
L4: 

    /** execute.e:544			levels = 1*/
    _levels_65879 = 1LL;

    /** execute.e:546			while length(call_stack) > 0 do*/
L9: 
    if (IS_SEQUENCE(_67call_stack_65348)){
            _32450 = SEQ_PTR(_67call_stack_65348)->length;
    }
    else {
        _32450 = 1;
    }
    if (_32450 <= 0LL)
    goto LA; // [223] 812

    /** execute.e:547				sub = call_stack[$]*/
    if (IS_SEQUENCE(_67call_stack_65348)){
            _32452 = SEQ_PTR(_67call_stack_65348)->length;
    }
    else {
        _32452 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_65348);
    _sub_65877 = (object)*(((s1_ptr)_2)->base + _32452);
    if (!IS_ATOM_INT(_sub_65877)){
        _sub_65877 = (object)DBL_PTR(_sub_65877)->dbl;
    }

    /** execute.e:548				if levels = 1 then*/
    if (_levels_65879 != 1LL)
    goto LB; // [242] 254

    /** execute.e:549					puts(2, '\n')*/
    EPuts(2LL, 10LL); // DJP 
    goto LC; // [251] 283
LB: 

    /** execute.e:551				elsif sub != call_back_routine and sub != delete_code_routine then*/
    _32455 = (_sub_65877 != _67call_back_routine_65264);
    if (_32455 == 0) {
        goto LD; // [262] 282
    }
    _32457 = (_sub_65877 != _67delete_code_routine_65265);
    if (_32457 == 0)
    {
        DeRef(_32457);
        _32457 = NOVALUE;
        goto LD; // [273] 282
    }
    else{
        DeRef(_32457);
        _32457 = NOVALUE;
    }

    /** execute.e:552					both_puts("... called from ")*/
    RefDS(_32458);
    _67both_puts(_32458);
LD: 
LC: 

    /** execute.e:556				if sub = call_back_routine then*/
    if (_sub_65877 != _67call_back_routine_65264)
    goto LE; // [287] 327

    /** execute.e:557					if crash_count > 0 then*/
    if (_67crash_count_65267 <= 0LL)
    goto LF; // [295] 311

    /** execute.e:558						both_puts("^^^ called to handle run-time crash\n")*/
    RefDS(_32461);
    _67both_puts(_32461);

    /** execute.e:559						exit*/
    goto LA; // [306] 812
    goto L10; // [308] 757
LF: 

    /** execute.e:561						both_puts("^^^ call-back from ")*/
    RefDS(_32462);
    _67both_puts(_32462);

    /** execute.e:562						ifdef WINDOWS then*/

    /** execute.e:563							both_puts("Windows\n")*/
    RefDS(_32463);
    _67both_puts(_32463);
    goto L10; // [324] 757
LE: 

    /** execute.e:568				elsif sub = delete_code_routine then*/
    if (_sub_65877 != _67delete_code_routine_65265)
    goto L11; // [331] 343

    /** execute.e:569					both_puts("^^^ delete routine\n")*/
    RefDS(_32466);
    _67both_puts(_32466);
    goto L10; // [340] 757
L11: 

    /** execute.e:572					both_printf("%s:%d", find_line(sub, pc))*/
    _32468 = _67find_line(_sub_65877, _67pc_65330);
    RefDS(_32467);
    _67both_printf(_32467, _32468);
    _32468 = NOVALUE;

    /** execute.e:574					if not equal(SymTab[sub][S_NAME], "<TopLevel>") then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32469 = (object)*(((s1_ptr)_2)->base + _sub_65877);
    _2 = (object)SEQ_PTR(_32469);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _32470 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _32470 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _32469 = NOVALUE;
    if (_32470 == _24841)
    _32471 = 1;
    else if (IS_ATOM_INT(_32470) && IS_ATOM_INT(_24841))
    _32471 = 0;
    else
    _32471 = (compare(_32470, _24841) == 0);
    _32470 = NOVALUE;
    if (_32471 != 0)
    goto L12; // [374] 462
    _32471 = NOVALUE;

    /** execute.e:575						switch SymTab[sub][S_TOKEN] do*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32473 = (object)*(((s1_ptr)_2)->base + _sub_65877);
    _2 = (object)SEQ_PTR(_32473);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _32474 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _32474 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _32473 = NOVALUE;
    if (IS_SEQUENCE(_32474) ){
        goto L13; // [391] 431
    }
    if(!IS_ATOM_INT(_32474)){
        if( (DBL_PTR(_32474)->dbl != (eudouble) ((object) DBL_PTR(_32474)->dbl) ) ){
            goto L13; // [391] 431
        }
        _0 = (object) DBL_PTR(_32474)->dbl;
    }
    else {
        _0 = _32474;
    };
    _32474 = NOVALUE;
    switch ( _0 ){ 

        /** execute.e:576							case PROC then*/
        case 27:

        /** execute.e:577								both_puts(" in procedure ")*/
        RefDS(_32477);
        _67both_puts(_32477);
        goto L14; // [405] 439

        /** execute.e:579							case FUNC then*/
        case 501:

        /** execute.e:580								both_puts(" in function ")*/
        RefDS(_32478);
        _67both_puts(_32478);
        goto L14; // [416] 439

        /** execute.e:582							case TYPE then*/
        case 504:

        /** execute.e:583								both_puts(" in type ")*/
        RefDS(_32479);
        _67both_puts(_32479);
        goto L14; // [427] 439

        /** execute.e:585							case else*/
        default:
L13: 

        /** execute.e:586								RTInternal("SymTab[sub][S_TOKEN] is not a routine")*/
        RefDS(_32480);
        _67RTInternal(_32480);
    ;}L14: 

    /** execute.e:590						both_printf("%s()", {SymTab[sub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32482 = (object)*(((s1_ptr)_2)->base + _sub_65877);
    _2 = (object)SEQ_PTR(_32482);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _32483 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _32483 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _32482 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_32483);
    ((intptr_t*)_2)[1] = _32483;
    _32484 = MAKE_SEQ(_1);
    _32483 = NOVALUE;
    RefDS(_32481);
    _67both_printf(_32481, _32484);
    _32484 = NOVALUE;
L12: 

    /** execute.e:593					both_puts("\n")*/
    RefDS(_22425);
    _67both_puts(_22425);

    /** execute.e:595					if show_message then*/
    if (_show_message_65886 == 0)
    {
        goto L15; // [469] 515
    }
    else{
    }

    /** execute.e:596						if sequence(crash_msg) then*/
    _32485 = IS_SEQUENCE(_67crash_msg_65256);
    if (_32485 == 0)
    {
        _32485 = NOVALUE;
        goto L16; // [479] 493
    }
    else{
        _32485 = NOVALUE;
    }

    /** execute.e:597							clear_screen()*/
    ClearScreen();

    /** execute.e:598							puts(2, crash_msg)*/
    EPuts(2LL, _67crash_msg_65256); // DJP 
L16: 

    /** execute.e:600						both_puts(msg)*/
    RefDS(_msg_65875);
    _67both_puts(_msg_65875);

    /** execute.e:601						CheckSubsError()*/
    _67CheckSubsError();

    /** execute.e:602						both_puts(" \n")*/
    RefDS(_24546);
    _67both_puts(_24546);

    /** execute.e:603						show_message = FALSE*/
    _show_message_65886 = _9FALSE_439;
L15: 

    /** execute.e:606					if length(call_stack) < 2 then*/
    if (IS_SEQUENCE(_67call_stack_65348)){
            _32486 = SEQ_PTR(_67call_stack_65348)->length;
    }
    else {
        _32486 = 1;
    }
    if (_32486 >= 2LL)
    goto L17; // [522] 536

    /** execute.e:607						both_puts('\n')*/
    _67both_puts(10LL);

    /** execute.e:608						exit*/
    goto LA; // [533] 812
L17: 

    /** execute.e:612					v = SymTab[sub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32488 = (object)*(((s1_ptr)_2)->base + _sub_65877);
    _2 = (object)SEQ_PTR(_32488);
    _v_65878 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_v_65878)){
        _v_65878 = (object)DBL_PTR(_v_65878)->dbl;
    }
    _32488 = NOVALUE;

    /** execute.e:614					while v != 0 and*/
L18: 
    _32490 = (_v_65878 != 0LL);
    if (_32490 == 0) {
        goto L19; // [561] 686
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32492 = (object)*(((s1_ptr)_2)->base + _v_65878);
    _2 = (object)SEQ_PTR(_32492);
    _32493 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32492 = NOVALUE;
    if (IS_ATOM_INT(_32493)) {
        _32494 = (_32493 == 3LL);
    }
    else {
        _32494 = binary_op(EQUALS, _32493, 3LL);
    }
    _32493 = NOVALUE;
    if (IS_ATOM_INT(_32494)) {
        if (_32494 != 0) {
            DeRef(_32495);
            _32495 = 1;
            goto L1A; // [583] 609
        }
    }
    else {
        if (DBL_PTR(_32494)->dbl != 0.0) {
            DeRef(_32495);
            _32495 = 1;
            goto L1A; // [583] 609
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32496 = (object)*(((s1_ptr)_2)->base + _v_65878);
    _2 = (object)SEQ_PTR(_32496);
    _32497 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32496 = NOVALUE;
    if (IS_ATOM_INT(_32497)) {
        _32498 = (_32497 == 2LL);
    }
    else {
        _32498 = binary_op(EQUALS, _32497, 2LL);
    }
    _32497 = NOVALUE;
    DeRef(_32495);
    if (IS_ATOM_INT(_32498))
    _32495 = (_32498 != 0);
    else
    _32495 = DBL_PTR(_32498)->dbl != 0.0;
L1A: 
    if (_32495 != 0) {
        DeRef(_32499);
        _32499 = 1;
        goto L1B; // [609] 635
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32500 = (object)*(((s1_ptr)_2)->base + _v_65878);
    _2 = (object)SEQ_PTR(_32500);
    _32501 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32500 = NOVALUE;
    if (IS_ATOM_INT(_32501)) {
        _32502 = (_32501 == 9LL);
    }
    else {
        _32502 = binary_op(EQUALS, _32501, 9LL);
    }
    _32501 = NOVALUE;
    if (IS_ATOM_INT(_32502))
    _32499 = (_32502 != 0);
    else
    _32499 = DBL_PTR(_32502)->dbl != 0.0;
L1B: 
    if (_32499 == 0)
    {
        _32499 = NOVALUE;
        goto L19; // [636] 686
    }
    else{
        _32499 = NOVALUE;
    }

    /** execute.e:618						if SymTab[v][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32503 = (object)*(((s1_ptr)_2)->base + _v_65878);
    _2 = (object)SEQ_PTR(_32503);
    _32504 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32503 = NOVALUE;
    if (binary_op_a(EQUALS, _32504, 9LL)){
        _32504 = NOVALUE;
        goto L1C; // [655] 665
    }
    _32504 = NOVALUE;

    /** execute.e:619							show_var(v)*/
    _67show_var(_v_65878);
L1C: 

    /** execute.e:622						v = SymTab[v][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32506 = (object)*(((s1_ptr)_2)->base + _v_65878);
    _2 = (object)SEQ_PTR(_32506);
    _v_65878 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_v_65878)){
        _v_65878 = (object)DBL_PTR(_v_65878)->dbl;
    }
    _32506 = NOVALUE;

    /** execute.e:623					end while*/
    goto L18; // [683] 557
L19: 

    /** execute.e:625					if length(SymTab[sub][S_SAVED_PRIVATES]) > 0 and*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32508 = (object)*(((s1_ptr)_2)->base + _sub_65877);
    _2 = (object)SEQ_PTR(_32508);
    _32509 = (object)*(((s1_ptr)_2)->base + 26LL);
    _32508 = NOVALUE;
    if (IS_SEQUENCE(_32509)){
            _32510 = SEQ_PTR(_32509)->length;
    }
    else {
        _32510 = 1;
    }
    _32509 = NOVALUE;
    _32511 = (_32510 > 0LL);
    _32510 = NOVALUE;
    if (_32511 == 0) {
        goto L1D; // [707] 756
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32513 = (object)*(((s1_ptr)_2)->base + _sub_65877);
    _2 = (object)SEQ_PTR(_32513);
    _32514 = (object)*(((s1_ptr)_2)->base + 26LL);
    _32513 = NOVALUE;
    _2 = (object)SEQ_PTR(_32514);
    _32515 = (object)*(((s1_ptr)_2)->base + 1LL);
    _32514 = NOVALUE;
    if (IS_ATOM_INT(_32515)) {
        _32516 = (_32515 != 0LL);
    }
    else {
        _32516 = binary_op(NOTEQ, _32515, 0LL);
    }
    _32515 = NOVALUE;
    if (_32516 == 0) {
        DeRef(_32516);
        _32516 = NOVALUE;
        goto L1D; // [732] 756
    }
    else {
        if (!IS_ATOM_INT(_32516) && DBL_PTR(_32516)->dbl == 0.0){
            DeRef(_32516);
            _32516 = NOVALUE;
            goto L1D; // [732] 756
        }
        DeRef(_32516);
        _32516 = NOVALUE;
    }
    DeRef(_32516);
    _32516 = NOVALUE;

    /** execute.e:627						SymTab[sub][S_RESIDENT_TASK] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sub_65877 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _32517 = NOVALUE;

    /** execute.e:628						restore_privates(sub)*/
    _67restore_privates(_sub_65877);
L1D: 
L10: 

    /** execute.e:632				puts(err_file, '\n')*/
    EPuts(_67err_file_65380, 10LL); // DJP 

    /** execute.e:635				pc = call_stack[$-1] - 1*/
    if (IS_SEQUENCE(_67call_stack_65348)){
            _32519 = SEQ_PTR(_67call_stack_65348)->length;
    }
    else {
        _32519 = 1;
    }
    _32520 = _32519 - 1LL;
    _32519 = NOVALUE;
    _2 = (object)SEQ_PTR(_67call_stack_65348);
    _32521 = (object)*(((s1_ptr)_2)->base + _32520);
    if (IS_ATOM_INT(_32521)) {
        _67pc_65330 = _32521 - 1LL;
    }
    else {
        _67pc_65330 = binary_op(MINUS, _32521, 1LL);
    }
    _32521 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_65330)) {
        _1 = (object)(DBL_PTR(_67pc_65330)->dbl);
        DeRefDS(_67pc_65330);
        _67pc_65330 = _1;
    }

    /** execute.e:636				call_stack = call_stack[1..$-2]*/
    if (IS_SEQUENCE(_67call_stack_65348)){
            _32523 = SEQ_PTR(_67call_stack_65348)->length;
    }
    else {
        _32523 = 1;
    }
    _32524 = _32523 - 2LL;
    _32523 = NOVALUE;
    rhs_slice_target = (object_ptr)&_67call_stack_65348;
    RHS_Slice(_67call_stack_65348, 1LL, _32524);

    /** execute.e:637				levels += 1*/
    _levels_65879 = _levels_65879 + 1;

    /** execute.e:638			end while*/
    goto L9; // [809] 218
LA: 

    /** execute.e:640			tcb[current_task][TASK_STATE] = ST_DEAD -- mark as "deleted"*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65374 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_65347 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _32527 = NOVALUE;

    /** execute.e:643			task = current_task*/
    _task_65881 = _67current_task_65347;

    /** execute.e:644			for i = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_65374)){
            _32529 = SEQ_PTR(_67tcb_65374)->length;
    }
    else {
        _32529 = 1;
    }
    {
        object _i_66064;
        _i_66064 = 1LL;
L1E: 
        if (_i_66064 > _32529){
            goto L1F; // [841] 955
        }

        /** execute.e:645				if tcb[i][TASK_STATE] != ST_DEAD and*/
        _2 = (object)SEQ_PTR(_67tcb_65374);
        _32530 = (object)*(((s1_ptr)_2)->base + _i_66064);
        _2 = (object)SEQ_PTR(_32530);
        _32531 = (object)*(((s1_ptr)_2)->base + 4LL);
        _32530 = NOVALUE;
        if (IS_ATOM_INT(_32531)) {
            _32532 = (_32531 != 2LL);
        }
        else {
            _32532 = binary_op(NOTEQ, _32531, 2LL);
        }
        _32531 = NOVALUE;
        if (IS_ATOM_INT(_32532)) {
            if (_32532 == 0) {
                goto L20; // [864] 948
            }
        }
        else {
            if (DBL_PTR(_32532)->dbl == 0.0) {
                goto L20; // [864] 948
            }
        }
        _2 = (object)SEQ_PTR(_67tcb_65374);
        _32534 = (object)*(((s1_ptr)_2)->base + _i_66064);
        _2 = (object)SEQ_PTR(_32534);
        _32535 = (object)*(((s1_ptr)_2)->base + 16LL);
        _32534 = NOVALUE;
        if (IS_SEQUENCE(_32535)){
                _32536 = SEQ_PTR(_32535)->length;
        }
        else {
            _32536 = 1;
        }
        _32535 = NOVALUE;
        _32537 = (_32536 > 0LL);
        _32536 = NOVALUE;
        if (_32537 == 0)
        {
            DeRef(_32537);
            _32537 = NOVALUE;
            goto L20; // [886] 948
        }
        else{
            DeRef(_32537);
            _32537 = NOVALUE;
        }

        /** execute.e:647					current_task = i*/
        _67current_task_65347 = _i_66064;

        /** execute.e:648					call_stack = tcb[i][TASK_STACK]*/
        _2 = (object)SEQ_PTR(_67tcb_65374);
        _32538 = (object)*(((s1_ptr)_2)->base + _i_66064);
        DeRef(_67call_stack_65348);
        _2 = (object)SEQ_PTR(_32538);
        _67call_stack_65348 = (object)*(((s1_ptr)_2)->base + 16LL);
        Ref(_67call_stack_65348);
        _32538 = NOVALUE;

        /** execute.e:649					pc = tcb[i][TASK_PC]*/
        _2 = (object)SEQ_PTR(_67tcb_65374);
        _32540 = (object)*(((s1_ptr)_2)->base + _i_66064);
        _2 = (object)SEQ_PTR(_32540);
        _67pc_65330 = (object)*(((s1_ptr)_2)->base + 14LL);
        if (!IS_ATOM_INT(_67pc_65330)){
            _67pc_65330 = (object)DBL_PTR(_67pc_65330)->dbl;
        }
        _32540 = NOVALUE;

        /** execute.e:650					Code = tcb[i][TASK_CODE]*/
        _2 = (object)SEQ_PTR(_67tcb_65374);
        _32542 = (object)*(((s1_ptr)_2)->base + _i_66064);
        DeRef(_27Code_20660);
        _2 = (object)SEQ_PTR(_32542);
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + 15LL);
        Ref(_27Code_20660);
        _32542 = NOVALUE;

        /** execute.e:651					screen_err_out = FALSE  -- just show offending task on screen*/
        _67screen_err_out_65391 = _9FALSE_439;

        /** execute.e:652					exit*/
        goto L1F; // [945] 955
L20: 

        /** execute.e:654			end for*/
        _i_66064 = _i_66064 + 1LL;
        goto L1E; // [950] 848
L1F: 
        ;
    }

    /** execute.e:655			if task = current_task then*/
    if (_task_65881 != _67current_task_65347)
    goto L21; // [959] 968

    /** execute.e:656				exit*/
    goto L3; // [965] 978
L21: 

    /** execute.e:658			both_puts("\n")*/
    RefDS(_22425);
    _67both_puts(_22425);

    /** execute.e:659		end while*/
    goto L2; // [975] 54
L3: 

    /** execute.e:661		puts(2, "\n--> see " & err_file_name & '\n')*/
    {
        object concat_list[3];

        concat_list[0] = 10LL;
        concat_list[1] = _67err_file_name_65381;
        concat_list[2] = _32545;
        Concat_N((object_ptr)&_32546, concat_list, 3);
    }
    EPuts(2LL, _32546); // DJP 
    DeRefDS(_32546);
    _32546 = NOVALUE;

    /** execute.e:663		puts(err_file, "\n\nGlobal & Local Variables\n")*/
    EPuts(_67err_file_65380, _32547); // DJP 

    /** execute.e:664		prev_file_no = -1*/
    _prev_file_no_65880 = -1LL;

    /** execute.e:665		v = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32548 = (object)*(((s1_ptr)_2)->base + _27TopLevelSub_20578);
    _2 = (object)SEQ_PTR(_32548);
    _v_65878 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_v_65878)){
        _v_65878 = (object)DBL_PTR(_v_65878)->dbl;
    }
    _32548 = NOVALUE;

    /** execute.e:666		while v do*/
L22: 
    if (_v_65878 == 0)
    {
        goto L23; // [1026] 1193
    }
    else{
    }

    /** execute.e:667			if SymTab[v][S_TOKEN] = VARIABLE and*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32550 = (object)*(((s1_ptr)_2)->base + _v_65878);
    _2 = (object)SEQ_PTR(_32550);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _32551 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _32551 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _32550 = NOVALUE;
    if (IS_ATOM_INT(_32551)) {
        _32552 = (_32551 == -100LL);
    }
    else {
        _32552 = binary_op(EQUALS, _32551, -100LL);
    }
    _32551 = NOVALUE;
    if (IS_ATOM_INT(_32552)) {
        if (_32552 == 0) {
            DeRef(_32553);
            _32553 = 0;
            goto L24; // [1049] 1075
        }
    }
    else {
        if (DBL_PTR(_32552)->dbl == 0.0) {
            DeRef(_32553);
            _32553 = 0;
            goto L24; // [1049] 1075
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32554 = (object)*(((s1_ptr)_2)->base + _v_65878);
    _2 = (object)SEQ_PTR(_32554);
    _32555 = (object)*(((s1_ptr)_2)->base + 3LL);
    _32554 = NOVALUE;
    if (IS_ATOM_INT(_32555)) {
        _32556 = (_32555 == 1LL);
    }
    else {
        _32556 = binary_op(EQUALS, _32555, 1LL);
    }
    _32555 = NOVALUE;
    DeRef(_32553);
    if (IS_ATOM_INT(_32556))
    _32553 = (_32556 != 0);
    else
    _32553 = DBL_PTR(_32556)->dbl != 0.0;
L24: 
    if (_32553 == 0) {
        goto L25; // [1075] 1172
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32558 = (object)*(((s1_ptr)_2)->base + _v_65878);
    _2 = (object)SEQ_PTR(_32558);
    _32559 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32558 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 5LL;
    ((intptr_t*)_2)[2] = 6LL;
    ((intptr_t*)_2)[3] = 4LL;
    _32560 = MAKE_SEQ(_1);
    _32561 = find_from(_32559, _32560, 1LL);
    _32559 = NOVALUE;
    DeRefDS(_32560);
    _32560 = NOVALUE;
    if (_32561 == 0)
    {
        _32561 = NOVALUE;
        goto L25; // [1109] 1172
    }
    else{
        _32561 = NOVALUE;
    }

    /** execute.e:670				if SymTab[v][S_FILE_NO] != prev_file_no then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32562 = (object)*(((s1_ptr)_2)->base + _v_65878);
    _2 = (object)SEQ_PTR(_32562);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _32563 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _32563 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _32562 = NOVALUE;
    if (binary_op_a(EQUALS, _32563, _prev_file_no_65880)){
        _32563 = NOVALUE;
        goto L26; // [1126] 1166
    }
    _32563 = NOVALUE;

    /** execute.e:671					prev_file_no = SymTab[v][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32565 = (object)*(((s1_ptr)_2)->base + _v_65878);
    _2 = (object)SEQ_PTR(_32565);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _prev_file_no_65880 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _prev_file_no_65880 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    if (!IS_ATOM_INT(_prev_file_no_65880)){
        _prev_file_no_65880 = (object)DBL_PTR(_prev_file_no_65880)->dbl;
    }
    _32565 = NOVALUE;

    /** execute.e:672					puts(err_file, "\n " & known_files[prev_file_no] & ":\n")*/
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _32568 = (object)*(((s1_ptr)_2)->base + _prev_file_no_65880);
    {
        object concat_list[3];

        concat_list[0] = _32569;
        concat_list[1] = _32568;
        concat_list[2] = _32567;
        Concat_N((object_ptr)&_32570, concat_list, 3);
    }
    _32568 = NOVALUE;
    EPuts(_67err_file_65380, _32570); // DJP 
    DeRefDS(_32570);
    _32570 = NOVALUE;
L26: 

    /** execute.e:674				show_var(v)*/
    _67show_var(_v_65878);
L25: 

    /** execute.e:676			v = SymTab[v][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32571 = (object)*(((s1_ptr)_2)->base + _v_65878);
    _2 = (object)SEQ_PTR(_32571);
    _v_65878 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_v_65878)){
        _v_65878 = (object)DBL_PTR(_v_65878)->dbl;
    }
    _32571 = NOVALUE;

    /** execute.e:677		end while*/
    goto L22; // [1190] 1026
L23: 

    /** execute.e:678		puts(err_file, '\n')*/
    EPuts(_67err_file_65380, 10LL); // DJP 

    /** execute.e:679		close(err_file)*/
    EClose(_67err_file_65380);

    /** execute.e:680	end procedure*/
    DeRefDS(_msg_65875);
    DeRef(_routine_name_65883);
    DeRefi(_title_65884);
    DeRef(_32455);
    _32455 = NOVALUE;
    DeRef(_32524);
    _32524 = NOVALUE;
    DeRef(_32532);
    _32532 = NOVALUE;
    _32509 = NOVALUE;
    DeRef(_32556);
    _32556 = NOVALUE;
    DeRef(_32490);
    _32490 = NOVALUE;
    DeRef(_32511);
    _32511 = NOVALUE;
    DeRef(_32552);
    _32552 = NOVALUE;
    DeRef(_32498);
    _32498 = NOVALUE;
    DeRef(_32494);
    _32494 = NOVALUE;
    _32432 = NOVALUE;
    DeRef(_32431);
    _32431 = NOVALUE;
    DeRef(_32502);
    _32502 = NOVALUE;
    _32535 = NOVALUE;
    DeRef(_32520);
    _32520 = NOVALUE;
    return;
    ;
}


void _67call_crash_routines()
{
    object _quit_66141 = NOVALUE;
    object _32582 = NOVALUE;
    object _32580 = NOVALUE;
    object _32579 = NOVALUE;
    object _32578 = NOVALUE;
    object _32577 = NOVALUE;
    object _32576 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:688		if crash_count > 0 then*/
    if (_67crash_count_65267 <= 0LL)
    goto L1; // [5] 15

    /** execute.e:689			return*/
    DeRef(_quit_66141);
    return;
L1: 

    /** execute.e:692		crash_count += 1*/
    _67crash_count_65267 = _67crash_count_65267 + 1;

    /** execute.e:695		err_file_name = "ex_crash.err"*/
    RefDS(_32575);
    DeRef(_67err_file_name_65381);
    _67err_file_name_65381 = _32575;

    /** execute.e:697		for i = length(crash_list) to 1 by -1 do*/
    if (IS_SEQUENCE(_67crash_list_65266)){
            _32576 = SEQ_PTR(_67crash_list_65266)->length;
    }
    else {
        _32576 = 1;
    }
    {
        object _i_66147;
        _i_66147 = _32576;
L2: 
        if (_i_66147 < 1LL){
            goto L3; // [37] 94
        }

        /** execute.e:699			quit = call_func(forward_general_callback,*/
        _2 = (object)SEQ_PTR(_67crash_list_65266);
        _32577 = (object)*(((s1_ptr)_2)->base + _i_66147);
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = 0LL;
        Ref(_32577);
        ((intptr_t*)_2)[2] = _32577;
        ((intptr_t*)_2)[3] = 1LL;
        _32578 = MAKE_SEQ(_1);
        _32577 = NOVALUE;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = 0LL;
        _32579 = MAKE_SEQ(_1);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _32578;
        ((intptr_t *)_2)[2] = _32579;
        _32580 = MAKE_SEQ(_1);
        _32579 = NOVALUE;
        _32578 = NOVALUE;
        _1 = (object)SEQ_PTR(_32580);
        _2 = (object)((s1_ptr)_1)->base;
        _0 = (object)_00[_67forward_general_callback_66137].addr;
        Ref( *(( (intptr_t*)_2) + 1) );
        Ref( *(( (intptr_t*)_2) + 2) );
        _1 = (*(intptr_t (*)())_0)(
                            *( ((intptr_t *)_2) + 1), 
                            *( ((intptr_t *)_2) + 2)
                             );
        DeRef(_quit_66141);
        _quit_66141 = _1;
        DeRefDS(_32580);
        _32580 = NOVALUE;

        /** execute.e:701			if not equal(quit, 0) then*/
        if (_quit_66141 == 0LL)
        _32582 = 1;
        else if (IS_ATOM_INT(_quit_66141) && IS_ATOM_INT(0LL))
        _32582 = 0;
        else
        _32582 = (compare(_quit_66141, 0LL) == 0);
        if (_32582 != 0)
        goto L4; // [78] 87
        _32582 = NOVALUE;

        /** execute.e:702				return -- don't call the others*/
        DeRef(_quit_66141);
        return;
L4: 

        /** execute.e:704		end for*/
        _i_66147 = _i_66147 + -1LL;
        goto L2; // [89] 44
L3: 
        ;
    }

    /** execute.e:705	end procedure*/
    DeRef(_quit_66141);
    return;
    ;
}


void _67quit_after_error()
{
    object _35402 = NOVALUE;
    object _32588 = NOVALUE;
    object _32586 = NOVALUE;
    object _32585 = NOVALUE;
    object _32584 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:709		write_coverage_db()*/
    _35402 = _50write_coverage_db();
    DeRef(_35402);
    _35402 = NOVALUE;

    /** execute.e:711		ifdef WINDOWS then*/

    /** execute.e:712			if not batch_job and not test_only then*/
    _32584 = (_27batch_job_20584 == 0);
    if (_32584 == 0) {
        goto L1; // [17] 41
    }
    _32586 = (_27test_only_20583 == 0);
    if (_32586 == 0)
    {
        DeRef(_32586);
        _32586 = NOVALUE;
        goto L1; // [27] 41
    }
    else{
        DeRef(_32586);
        _32586 = NOVALUE;
    }

    /** execute.e:713				puts(2, "\nPress Enter...\n")*/
    EPuts(2LL, _32587); // DJP 

    /** execute.e:714				getc(0)*/
    if (0LL != last_r_file_no) {
        last_r_file_ptr = which_file(0LL, EF_READ);
        last_r_file_no = 0LL;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _32588 = getKBchar();
        }
        else{
            _32588 = getc(last_r_file_ptr);
        }
    }
    else{
        _32588 = getc(last_r_file_ptr);
    }
L1: 

    /** execute.e:718		abort(1)*/
    UserCleanup(1LL);

    /** execute.e:719	end procedure*/
    DeRef(_32584);
    _32584 = NOVALUE;
    return;
    ;
}


void _67RTFatalType(object _x_66170)
{
    object _msg_66171 = NOVALUE;
    object _v_66172 = NOVALUE;
    object _vname_66173 = NOVALUE;
    object _32621 = NOVALUE;
    object _32617 = NOVALUE;
    object _32616 = NOVALUE;
    object _32615 = NOVALUE;
    object _32614 = NOVALUE;
    object _32612 = NOVALUE;
    object _32611 = NOVALUE;
    object _32610 = NOVALUE;
    object _32609 = NOVALUE;
    object _32607 = NOVALUE;
    object _32606 = NOVALUE;
    object _32604 = NOVALUE;
    object _32603 = NOVALUE;
    object _32601 = NOVALUE;
    object _32599 = NOVALUE;
    object _32597 = NOVALUE;
    object _32593 = NOVALUE;
    object _32591 = NOVALUE;
    object _32590 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_66170)) {
        _1 = (object)(DBL_PTR(_x_66170)->dbl);
        DeRefDS(_x_66170);
        _x_66170 = _1;
    }

    /** execute.e:726		open_err_file()*/
    _67open_err_file();

    /** execute.e:727		a = Code[x]*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _x_66170);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:728		if length(SymTab[a]) >= S_NAME then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32590 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_SEQUENCE(_32590)){
            _32591 = SEQ_PTR(_32590)->length;
    }
    else {
        _32591 = 1;
    }
    _32590 = NOVALUE;
    if (binary_op_a(LESS, _32591, _27S_NAME_20209)){
        _32591 = NOVALUE;
        goto L1; // [32] 57
    }
    _32591 = NOVALUE;

    /** execute.e:729			vname = SymTab[a][S_NAME]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32593 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    DeRef(_vname_66173);
    _2 = (object)SEQ_PTR(_32593);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _vname_66173 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _vname_66173 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    Ref(_vname_66173);
    _32593 = NOVALUE;
    goto L2; // [54] 65
L1: 

    /** execute.e:732			vname = "inlined variable"*/
    RefDS(_32595);
    DeRef(_vname_66173);
    _vname_66173 = _32595;
L2: 

    /** execute.e:734		msg = sprintf("type_check failure, %s is ", {vname})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_vname_66173);
    ((intptr_t*)_2)[1] = _vname_66173;
    _32597 = MAKE_SEQ(_1);
    DeRefi(_msg_66171);
    _msg_66171 = EPrintf(-9999999, _32596, _32597);
    DeRefDS(_32597);
    _32597 = NOVALUE;

    /** execute.e:735		v = sprint(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _32599 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    Ref(_32599);
    _0 = _v_66172;
    _v_66172 = _12sprint(_32599);
    DeRef(_0);
    _32599 = NOVALUE;

    /** execute.e:736		if length(v) > 70 - length(vname) then*/
    if (IS_SEQUENCE(_v_66172)){
            _32601 = SEQ_PTR(_v_66172)->length;
    }
    else {
        _32601 = 1;
    }
    if (IS_SEQUENCE(_vname_66173)){
            _32603 = SEQ_PTR(_vname_66173)->length;
    }
    else {
        _32603 = 1;
    }
    _32604 = 70LL - _32603;
    _32603 = NOVALUE;
    if (_32601 <= _32604)
    goto L3; // [105] 180

    /** execute.e:737			v = v[1..70 - length(vname)]*/
    if (IS_SEQUENCE(_vname_66173)){
            _32606 = SEQ_PTR(_vname_66173)->length;
    }
    else {
        _32606 = 1;
    }
    _32607 = 70LL - _32606;
    _32606 = NOVALUE;
    rhs_slice_target = (object_ptr)&_v_66172;
    RHS_Slice(_v_66172, 1LL, _32607);

    /** execute.e:738			while length(v) and not find(v[$], ",}")  do*/
L4: 
    if (IS_SEQUENCE(_v_66172)){
            _32609 = SEQ_PTR(_v_66172)->length;
    }
    else {
        _32609 = 1;
    }
    if (_32609 == 0) {
        goto L5; // [131] 173
    }
    if (IS_SEQUENCE(_v_66172)){
            _32611 = SEQ_PTR(_v_66172)->length;
    }
    else {
        _32611 = 1;
    }
    _2 = (object)SEQ_PTR(_v_66172);
    _32612 = (object)*(((s1_ptr)_2)->base + _32611);
    _32614 = find_from(_32612, _32613, 1LL);
    _32612 = NOVALUE;
    _32615 = (_32614 == 0);
    _32614 = NOVALUE;
    if (_32615 == 0)
    {
        DeRef(_32615);
        _32615 = NOVALUE;
        goto L5; // [151] 173
    }
    else{
        DeRef(_32615);
        _32615 = NOVALUE;
    }

    /** execute.e:739				v = v[1..$-1]*/
    if (IS_SEQUENCE(_v_66172)){
            _32616 = SEQ_PTR(_v_66172)->length;
    }
    else {
        _32616 = 1;
    }
    _32617 = _32616 - 1LL;
    _32616 = NOVALUE;
    rhs_slice_target = (object_ptr)&_v_66172;
    RHS_Slice(_v_66172, 1LL, _32617);

    /** execute.e:740			end while*/
    goto L4; // [170] 128
L5: 

    /** execute.e:741			v = v & " ..."*/
    Concat((object_ptr)&_v_66172, _v_66172, _32619);
L3: 

    /** execute.e:743		trace_back(msg & v)*/
    Concat((object_ptr)&_32621, _msg_66171, _v_66172);
    _67trace_back(_32621);
    _32621 = NOVALUE;

    /** execute.e:744		call_crash_routines()*/
    _67call_crash_routines();

    /** execute.e:745		quit_after_error()*/
    _67quit_after_error();

    /** execute.e:746	end procedure*/
    DeRefDSi(_msg_66171);
    DeRefDS(_v_66172);
    DeRef(_vname_66173);
    DeRef(_32604);
    _32604 = NOVALUE;
    DeRef(_32607);
    _32607 = NOVALUE;
    DeRef(_32617);
    _32617 = NOVALUE;
    _32590 = NOVALUE;
    return;
    ;
}


void _67RTFatal(object _msg_66219)
{
    object _0, _1, _2;
    

    /** execute.e:750		open_err_file()*/
    _67open_err_file();

    /** execute.e:751		trace_back(msg)*/
    RefDS(_msg_66219);
    _67trace_back(_msg_66219);

    /** execute.e:752		call_crash_routines()*/
    _67call_crash_routines();

    /** execute.e:753		quit_after_error()*/
    _67quit_after_error();

    /** execute.e:754	end procedure*/
    DeRefDS(_msg_66219);
    return;
    ;
}


void _67RTInternal(object _msg_66222)
{
    object _0, _1, _2;
    

    /** execute.e:761		machine_proc(67, msg)*/
    machine(67LL, _msg_66222);

    /** execute.e:762	end procedure*/
    DeRefDSi(_msg_66222);
    return;
    ;
}


void _67wait(object _t_66225)
{
    object _t1_66226 = NOVALUE;
    object _t2_66227 = NOVALUE;
    object _32627 = NOVALUE;
    object _32625 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:771		t1 = floor(t)*/
    DeRef(_t1_66226);
    if (IS_ATOM_INT(_t_66225))
    _t1_66226 = e_floor(_t_66225);
    else
    _t1_66226 = unary_op(FLOOR, _t_66225);

    /** execute.e:772		if t1 >= 1 then*/
    if (binary_op_a(LESS, _t1_66226, 1LL)){
        goto L1; // [8] 24
    }

    /** execute.e:773			sleep(t1)*/
    Ref(_t1_66226);
    _3sleep(_t1_66226);

    /** execute.e:774			t -= t1*/
    _0 = _t_66225;
    if (IS_ATOM_INT(_t_66225) && IS_ATOM_INT(_t1_66226)) {
        _t_66225 = _t_66225 - _t1_66226;
        if ((object)((uintptr_t)_t_66225 +(uintptr_t) HIGH_BITS) >= 0){
            _t_66225 = NewDouble((eudouble)_t_66225);
        }
    }
    else {
        if (IS_ATOM_INT(_t_66225)) {
            _t_66225 = NewDouble((eudouble)_t_66225 - DBL_PTR(_t1_66226)->dbl);
        }
        else {
            if (IS_ATOM_INT(_t1_66226)) {
                _t_66225 = NewDouble(DBL_PTR(_t_66225)->dbl - (eudouble)_t1_66226);
            }
            else
            _t_66225 = NewDouble(DBL_PTR(_t_66225)->dbl - DBL_PTR(_t1_66226)->dbl);
        }
    }
    DeRef(_0);
L1: 

    /** execute.e:777		t2 = time() + t*/
    DeRef(_32625);
    _32625 = NewDouble(current_time());
    DeRef(_t2_66227);
    if (IS_ATOM_INT(_t_66225)) {
        _t2_66227 = NewDouble(DBL_PTR(_32625)->dbl + (eudouble)_t_66225);
    }
    else
    _t2_66227 = NewDouble(DBL_PTR(_32625)->dbl + DBL_PTR(_t_66225)->dbl);
    DeRefDS(_32625);
    _32625 = NOVALUE;

    /** execute.e:778		while time() < t2 do*/
L2: 
    DeRef(_32627);
    _32627 = NewDouble(current_time());
    if (binary_op_a(GREATEREQ, _32627, _t2_66227)){
        DeRefDS(_32627);
        _32627 = NOVALUE;
        goto L3; // [39] 48
    }
    DeRef(_32627);
    _32627 = NOVALUE;

    /** execute.e:779		end while*/
    goto L2; // [45] 37
L3: 

    /** execute.e:780	end procedure*/
    DeRef(_t_66225);
    DeRef(_t1_66226);
    DeRef(_t2_66227);
    return;
    ;
}


void _67scheduler()
{
    object _earliest_time_66243 = NOVALUE;
    object _start_time_66244 = NOVALUE;
    object _now_66245 = NOVALUE;
    object _ts_found_66247 = NOVALUE;
    object _tp_66248 = NOVALUE;
    object _p_66249 = NOVALUE;
    object _earliest_task_66250 = NOVALUE;
    object _32704 = NOVALUE;
    object _32703 = NOVALUE;
    object _32700 = NOVALUE;
    object _32699 = NOVALUE;
    object _32698 = NOVALUE;
    object _32697 = NOVALUE;
    object _32696 = NOVALUE;
    object _32694 = NOVALUE;
    object _32693 = NOVALUE;
    object _32691 = NOVALUE;
    object _32689 = NOVALUE;
    object _32687 = NOVALUE;
    object _32685 = NOVALUE;
    object _32683 = NOVALUE;
    object _32681 = NOVALUE;
    object _32678 = NOVALUE;
    object _32676 = NOVALUE;
    object _32675 = NOVALUE;
    object _32673 = NOVALUE;
    object _32672 = NOVALUE;
    object _32669 = NOVALUE;
    object _32667 = NOVALUE;
    object _32661 = NOVALUE;
    object _32657 = NOVALUE;
    object _32656 = NOVALUE;
    object _32654 = NOVALUE;
    object _32652 = NOVALUE;
    object _32650 = NOVALUE;
    object _32649 = NOVALUE;
    object _32648 = NOVALUE;
    object _32647 = NOVALUE;
    object _32646 = NOVALUE;
    object _32645 = NOVALUE;
    object _32644 = NOVALUE;
    object _32642 = NOVALUE;
    object _32637 = NOVALUE;
    object _32633 = NOVALUE;
    object _32631 = NOVALUE;
    object _32630 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:789		sequence tp*/

    /** execute.e:790		integer p, earliest_task*/

    /** execute.e:795		earliest_task = rt_first*/
    _earliest_task_66250 = _67rt_first_65377;

    /** execute.e:797		if clock_stopped or earliest_task = 0 then*/
    if (_67clock_stopped_66239 != 0) {
        goto L1; // [16] 29
    }
    _32630 = (_earliest_task_66250 == 0LL);
    if (_32630 == 0)
    {
        DeRef(_32630);
        _32630 = NOVALUE;
        goto L2; // [25] 42
    }
    else{
        DeRef(_32630);
        _32630 = NOVALUE;
    }
L1: 

    /** execute.e:799			start_time = 1*/
    DeRef(_start_time_66244);
    _start_time_66244 = 1LL;

    /** execute.e:800			now = -1*/
    DeRef(_now_66245);
    _now_66245 = -1LL;
    goto L3; // [39] 232
L2: 

    /** execute.e:804			earliest_time = tcb[earliest_task][TASK_MAX_TIME]*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32631 = (object)*(((s1_ptr)_2)->base + _earliest_task_66250);
    DeRef(_earliest_time_66243);
    _2 = (object)SEQ_PTR(_32631);
    _earliest_time_66243 = (object)*(((s1_ptr)_2)->base + 9LL);
    Ref(_earliest_time_66243);
    _32631 = NOVALUE;

    /** execute.e:806			p = tcb[rt_first][TASK_NEXT]*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32633 = (object)*(((s1_ptr)_2)->base + _67rt_first_65377);
    _2 = (object)SEQ_PTR(_32633);
    _p_66249 = (object)*(((s1_ptr)_2)->base + 12LL);
    if (!IS_ATOM_INT(_p_66249)){
        _p_66249 = (object)DBL_PTR(_p_66249)->dbl;
    }
    _32633 = NOVALUE;

    /** execute.e:807			while p != 0 do*/
L4: 
    if (_p_66249 == 0LL)
    goto L5; // [75] 122

    /** execute.e:808				tp = tcb[p]*/
    DeRef(_tp_66248);
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _tp_66248 = (object)*(((s1_ptr)_2)->base + _p_66249);
    RefDS(_tp_66248);

    /** execute.e:809				if tp[TASK_MAX_TIME] < earliest_time then*/
    _2 = (object)SEQ_PTR(_tp_66248);
    _32637 = (object)*(((s1_ptr)_2)->base + 9LL);
    if (binary_op_a(GREATEREQ, _32637, _earliest_time_66243)){
        _32637 = NOVALUE;
        goto L6; // [95] 111
    }
    _32637 = NOVALUE;

    /** execute.e:810					earliest_task = p*/
    _earliest_task_66250 = _p_66249;

    /** execute.e:811					earliest_time = tp[TASK_MAX_TIME]*/
    DeRef(_earliest_time_66243);
    _2 = (object)SEQ_PTR(_tp_66248);
    _earliest_time_66243 = (object)*(((s1_ptr)_2)->base + 9LL);
    Ref(_earliest_time_66243);
L6: 

    /** execute.e:813				p = tp[TASK_NEXT]*/
    _2 = (object)SEQ_PTR(_tp_66248);
    _p_66249 = (object)*(((s1_ptr)_2)->base + 12LL);
    if (!IS_ATOM_INT(_p_66249))
    _p_66249 = (object)DBL_PTR(_p_66249)->dbl;

    /** execute.e:814			end while*/
    goto L4; // [119] 75
L5: 

    /** execute.e:817			now = time()*/
    DeRef(_now_66245);
    _now_66245 = NewDouble(current_time());

    /** execute.e:819			start_time = tcb[earliest_task][TASK_MIN_TIME]*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32642 = (object)*(((s1_ptr)_2)->base + _earliest_task_66250);
    DeRef(_start_time_66244);
    _2 = (object)SEQ_PTR(_32642);
    _start_time_66244 = (object)*(((s1_ptr)_2)->base + 8LL);
    Ref(_start_time_66244);
    _32642 = NOVALUE;

    /** execute.e:821			if earliest_task = current_task and*/
    _32644 = (_earliest_task_66250 == _67current_task_65347);
    if (_32644 == 0) {
        goto L7; // [146] 173
    }
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32646 = (object)*(((s1_ptr)_2)->base + _67current_task_65347);
    _2 = (object)SEQ_PTR(_32646);
    _32647 = (object)*(((s1_ptr)_2)->base + 10LL);
    _32646 = NOVALUE;
    if (IS_ATOM_INT(_32647)) {
        _32648 = (_32647 > 0LL);
    }
    else {
        _32648 = binary_op(GREATER, _32647, 0LL);
    }
    _32647 = NOVALUE;
    if (_32648 == 0) {
        DeRef(_32648);
        _32648 = NOVALUE;
        goto L7; // [167] 173
    }
    else {
        if (!IS_ATOM_INT(_32648) && DBL_PTR(_32648)->dbl == 0.0){
            DeRef(_32648);
            _32648 = NOVALUE;
            goto L7; // [167] 173
        }
        DeRef(_32648);
        _32648 = NOVALUE;
    }
    DeRef(_32648);
    _32648 = NOVALUE;
    goto L8; // [170] 231
L7: 

    /** execute.e:825				if tcb[current_task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32649 = (object)*(((s1_ptr)_2)->base + _67current_task_65347);
    _2 = (object)SEQ_PTR(_32649);
    _32650 = (object)*(((s1_ptr)_2)->base + 3LL);
    _32649 = NOVALUE;
    if (binary_op_a(NOTEQ, _32650, 1LL)){
        _32650 = NOVALUE;
        goto L9; // [187] 207
    }
    _32650 = NOVALUE;

    /** execute.e:826					tcb[current_task][TASK_RUNS_LEFT] = 0*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65374 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_65347 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _32652 = NOVALUE;
L9: 

    /** execute.e:828				tcb[earliest_task][TASK_RUNS_LEFT] = tcb[earliest_task][TASK_RUNS_MAX]*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65374 = MAKE_SEQ(_2);
    }
    _3 = (object)(_earliest_task_66250 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32656 = (object)*(((s1_ptr)_2)->base + _earliest_task_66250);
    _2 = (object)SEQ_PTR(_32656);
    _32657 = (object)*(((s1_ptr)_2)->base + 11LL);
    _32656 = NOVALUE;
    Ref(_32657);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32657;
    if( _1 != _32657 ){
        DeRef(_1);
    }
    _32657 = NOVALUE;
    _32654 = NOVALUE;
L8: 
L3: 

    /** execute.e:832		if start_time > now then*/
    if (binary_op_a(LESSEQ, _start_time_66244, _now_66245)){
        goto LA; // [238] 416
    }

    /** execute.e:836			ts_found = FALSE*/
    _ts_found_66247 = _9FALSE_439;

    /** execute.e:837			p = ts_first*/
    _p_66249 = _67ts_first_65378;

    /** execute.e:838			while p != 0 do*/
LB: 
    if (_p_66249 == 0LL)
    goto LC; // [261] 313

    /** execute.e:839				tp = tcb[p]*/
    DeRef(_tp_66248);
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _tp_66248 = (object)*(((s1_ptr)_2)->base + _p_66249);
    RefDS(_tp_66248);

    /** execute.e:840				if tp[TASK_RUNS_LEFT] > 0 then*/
    _2 = (object)SEQ_PTR(_tp_66248);
    _32661 = (object)*(((s1_ptr)_2)->base + 10LL);
    if (binary_op_a(LESSEQ, _32661, 0LL)){
        _32661 = NOVALUE;
        goto LD; // [281] 302
    }
    _32661 = NOVALUE;

    /** execute.e:841					  earliest_task = p*/
    _earliest_task_66250 = _p_66249;

    /** execute.e:842					  ts_found = TRUE*/
    _ts_found_66247 = _9TRUE_441;

    /** execute.e:843					  exit*/
    goto LC; // [299] 313
LD: 

    /** execute.e:845				p = tp[TASK_NEXT]*/
    _2 = (object)SEQ_PTR(_tp_66248);
    _p_66249 = (object)*(((s1_ptr)_2)->base + 12LL);
    if (!IS_ATOM_INT(_p_66249))
    _p_66249 = (object)DBL_PTR(_p_66249)->dbl;

    /** execute.e:846			end while*/
    goto LB; // [310] 261
LC: 

    /** execute.e:848			if not ts_found then*/
    if (_ts_found_66247 != 0)
    goto LE; // [315] 378

    /** execute.e:851				p = ts_first*/
    _p_66249 = _67ts_first_65378;

    /** execute.e:852				while p != 0 do*/
LF: 
    if (_p_66249 == 0LL)
    goto L10; // [330] 377

    /** execute.e:853					tp = tcb[p]*/
    DeRef(_tp_66248);
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _tp_66248 = (object)*(((s1_ptr)_2)->base + _p_66249);
    RefDS(_tp_66248);

    /** execute.e:854					earliest_task = p*/
    _earliest_task_66250 = _p_66249;

    /** execute.e:855					tcb[p][TASK_RUNS_LEFT] = tp[TASK_RUNS_MAX]*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65374 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_66249 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_tp_66248);
    _32669 = (object)*(((s1_ptr)_2)->base + 11LL);
    Ref(_32669);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32669;
    if( _1 != _32669 ){
        DeRef(_1);
    }
    _32669 = NOVALUE;
    _32667 = NOVALUE;

    /** execute.e:856					p = tp[TASK_NEXT]*/
    _2 = (object)SEQ_PTR(_tp_66248);
    _p_66249 = (object)*(((s1_ptr)_2)->base + 12LL);
    if (!IS_ATOM_INT(_p_66249))
    _p_66249 = (object)DBL_PTR(_p_66249)->dbl;

    /** execute.e:857				end while*/
    goto LF; // [374] 330
L10: 
LE: 

    /** execute.e:860			if earliest_task = 0 then*/
    if (_earliest_task_66250 != 0LL)
    goto L11; // [380] 389

    /** execute.e:863				abort(0)*/
    UserCleanup(0LL);
L11: 

    /** execute.e:866			if tcb[earliest_task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32672 = (object)*(((s1_ptr)_2)->base + _earliest_task_66250);
    _2 = (object)SEQ_PTR(_32672);
    _32673 = (object)*(((s1_ptr)_2)->base + 3LL);
    _32672 = NOVALUE;
    if (binary_op_a(NOTEQ, _32673, 1LL)){
        _32673 = NOVALUE;
        goto L12; // [401] 415
    }
    _32673 = NOVALUE;

    /** execute.e:868				wait(start_time - now)*/
    if (IS_ATOM_INT(_start_time_66244) && IS_ATOM_INT(_now_66245)) {
        _32675 = _start_time_66244 - _now_66245;
        if ((object)((uintptr_t)_32675 +(uintptr_t) HIGH_BITS) >= 0){
            _32675 = NewDouble((eudouble)_32675);
        }
    }
    else {
        if (IS_ATOM_INT(_start_time_66244)) {
            _32675 = NewDouble((eudouble)_start_time_66244 - DBL_PTR(_now_66245)->dbl);
        }
        else {
            if (IS_ATOM_INT(_now_66245)) {
                _32675 = NewDouble(DBL_PTR(_start_time_66244)->dbl - (eudouble)_now_66245);
            }
            else
            _32675 = NewDouble(DBL_PTR(_start_time_66244)->dbl - DBL_PTR(_now_66245)->dbl);
        }
    }
    _67wait(_32675);
    _32675 = NOVALUE;
L12: 
LA: 

    /** execute.e:873		tcb[earliest_task][TASK_START] = time()*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65374 = MAKE_SEQ(_2);
    }
    _3 = (object)(_earliest_task_66250 + ((s1_ptr)_2)->base);
    DeRef(_32678);
    _32678 = NewDouble(current_time());
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32678;
    if( _1 != _32678 ){
        DeRef(_1);
    }
    _32678 = NOVALUE;
    _32676 = NOVALUE;

    /** execute.e:875		if earliest_task = current_task then*/
    if (_earliest_task_66250 != _67current_task_65347)
    goto L13; // [435] 450

    /** execute.e:876			pc += 1  -- continue with current task*/
    _67pc_65330 = _67pc_65330 + 1;
    goto L14; // [447] 663
L13: 

    /** execute.e:881			tcb[current_task][TASK_CODE] = Code*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65374 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_65347 + ((s1_ptr)_2)->base);
    RefDS(_27Code_20660);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27Code_20660;
    DeRef(_1);
    _32681 = NOVALUE;

    /** execute.e:882			tcb[current_task][TASK_PC] = pc*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65374 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_65347 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67pc_65330;
    DeRef(_1);
    _32683 = NOVALUE;

    /** execute.e:883			tcb[current_task][TASK_STACK] = call_stack*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65374 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_65347 + ((s1_ptr)_2)->base);
    RefDS(_67call_stack_65348);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 16LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67call_stack_65348;
    DeRef(_1);
    _32685 = NOVALUE;

    /** execute.e:886			Code = tcb[earliest_task][TASK_CODE]*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32687 = (object)*(((s1_ptr)_2)->base + _earliest_task_66250);
    DeRefDS(_27Code_20660);
    _2 = (object)SEQ_PTR(_32687);
    _27Code_20660 = (object)*(((s1_ptr)_2)->base + 15LL);
    Ref(_27Code_20660);
    _32687 = NOVALUE;

    /** execute.e:887			pc = tcb[earliest_task][TASK_PC]*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32689 = (object)*(((s1_ptr)_2)->base + _earliest_task_66250);
    _2 = (object)SEQ_PTR(_32689);
    _67pc_65330 = (object)*(((s1_ptr)_2)->base + 14LL);
    if (!IS_ATOM_INT(_67pc_65330)){
        _67pc_65330 = (object)DBL_PTR(_67pc_65330)->dbl;
    }
    _32689 = NOVALUE;

    /** execute.e:888			call_stack = tcb[earliest_task][TASK_STACK]*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32691 = (object)*(((s1_ptr)_2)->base + _earliest_task_66250);
    DeRefDS(_67call_stack_65348);
    _2 = (object)SEQ_PTR(_32691);
    _67call_stack_65348 = (object)*(((s1_ptr)_2)->base + 16LL);
    Ref(_67call_stack_65348);
    _32691 = NOVALUE;

    /** execute.e:890			current_task = earliest_task*/
    _67current_task_65347 = _earliest_task_66250;

    /** execute.e:892			if tcb[current_task][TASK_PC] = 0 then*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32693 = (object)*(((s1_ptr)_2)->base + _67current_task_65347);
    _2 = (object)SEQ_PTR(_32693);
    _32694 = (object)*(((s1_ptr)_2)->base + 14LL);
    _32693 = NOVALUE;
    if (binary_op_a(NOTEQ, _32694, 0LL)){
        _32694 = NOVALUE;
        goto L15; // [562] 639
    }
    _32694 = NOVALUE;

    /** execute.e:895				pc = 1*/
    _67pc_65330 = 1LL;

    /** execute.e:896				val[t_id] = tcb[current_task][TASK_RID]*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32696 = (object)*(((s1_ptr)_2)->base + _67current_task_65347);
    _2 = (object)SEQ_PTR(_32696);
    _32697 = (object)*(((s1_ptr)_2)->base + 1LL);
    _32696 = NOVALUE;
    Ref(_32697);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_id_65261);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32697;
    if( _1 != _32697 ){
        DeRef(_1);
    }
    _32697 = NOVALUE;

    /** execute.e:897				val[t_arglist] = tcb[current_task][TASK_ARGS]*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32698 = (object)*(((s1_ptr)_2)->base + _67current_task_65347);
    _2 = (object)SEQ_PTR(_32698);
    _32699 = (object)*(((s1_ptr)_2)->base + 13LL);
    _32698 = NOVALUE;
    Ref(_32699);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_arglist_65262);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32699;
    if( _1 != _32699 ){
        DeRef(_1);
    }
    _32699 = NOVALUE;

    /** execute.e:898				new_arg_assign()*/
    _32700 = _67new_arg_assign();

    /** execute.e:899				Code = {CALL_PROC, t_id, t_arglist}*/
    _0 = _27Code_20660;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 136LL;
    ((intptr_t*)_2)[2] = _67t_id_65261;
    ((intptr_t*)_2)[3] = _67t_arglist_65262;
    _27Code_20660 = MAKE_SEQ(_1);
    DeRefDS(_0);
    goto L16; // [636] 662
L15: 

    /** execute.e:902				pc += 1*/
    _67pc_65330 = _67pc_65330 + 1;

    /** execute.e:903				restore_privates(call_stack[$])*/
    if (IS_SEQUENCE(_67call_stack_65348)){
            _32703 = SEQ_PTR(_67call_stack_65348)->length;
    }
    else {
        _32703 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_65348);
    _32704 = (object)*(((s1_ptr)_2)->base + _32703);
    Ref(_32704);
    _67restore_privates(_32704);
    _32704 = NOVALUE;
L16: 
L14: 

    /** execute.e:906	end procedure*/
    DeRef(_earliest_time_66243);
    DeRef(_start_time_66244);
    DeRef(_now_66245);
    DeRef(_tp_66248);
    DeRef(_32644);
    _32644 = NOVALUE;
    DeRef(_32700);
    _32700 = NOVALUE;
    return;
    ;
}


object _67task_insert(object _first_66353, object _task_66354)
{
    object _32705 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:910		tcb[task][TASK_NEXT] = first*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65374 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66354 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _first_66353;
    DeRef(_1);
    _32705 = NOVALUE;

    /** execute.e:911		return task*/
    return _task_66354;
    ;
}


object _67task_delete(object _first_66359, object _task_66360)
{
    object _p_66361 = NOVALUE;
    object _prev_p_66362 = NOVALUE;
    object _32716 = NOVALUE;
    object _32715 = NOVALUE;
    object _32714 = NOVALUE;
    object _32712 = NOVALUE;
    object _32711 = NOVALUE;
    object _32710 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:918		prev_p = -1*/
    _prev_p_66362 = -1LL;

    /** execute.e:919		p = first*/
    _p_66361 = _first_66359;

    /** execute.e:920		while p != 0 do*/
L1: 
    if (_p_66361 == 0LL)
    goto L2; // [20] 110

    /** execute.e:921			if p = task then*/
    if (_p_66361 != _task_66360)
    goto L3; // [26] 86

    /** execute.e:922				if prev_p = -1 then*/
    if (_prev_p_66362 != -1LL)
    goto L4; // [32] 55

    /** execute.e:924					return tcb[p][TASK_NEXT]*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32710 = (object)*(((s1_ptr)_2)->base + _p_66361);
    _2 = (object)SEQ_PTR(_32710);
    _32711 = (object)*(((s1_ptr)_2)->base + 12LL);
    _32710 = NOVALUE;
    Ref(_32711);
    return _32711;
    goto L5; // [52] 85
L4: 

    /** execute.e:927					tcb[prev_p][TASK_NEXT] = tcb[p][TASK_NEXT]*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65374 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_p_66362 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32714 = (object)*(((s1_ptr)_2)->base + _p_66361);
    _2 = (object)SEQ_PTR(_32714);
    _32715 = (object)*(((s1_ptr)_2)->base + 12LL);
    _32714 = NOVALUE;
    Ref(_32715);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32715;
    if( _1 != _32715 ){
        DeRef(_1);
    }
    _32715 = NOVALUE;
    _32712 = NOVALUE;

    /** execute.e:928					return first*/
    _32711 = NOVALUE;
    return _first_66359;
L5: 
L3: 

    /** execute.e:931			prev_p = p*/
    _prev_p_66362 = _p_66361;

    /** execute.e:932			p = tcb[p][TASK_NEXT]*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32716 = (object)*(((s1_ptr)_2)->base + _p_66361);
    _2 = (object)SEQ_PTR(_32716);
    _p_66361 = (object)*(((s1_ptr)_2)->base + 12LL);
    if (!IS_ATOM_INT(_p_66361)){
        _p_66361 = (object)DBL_PTR(_p_66361)->dbl;
    }
    _32716 = NOVALUE;

    /** execute.e:933		end while*/
    goto L1; // [107] 20
L2: 

    /** execute.e:935		return first*/
    _32711 = NOVALUE;
    return _first_66359;
    ;
}


void _67opTASK_YIELD()
{
    object _now_66380 = NOVALUE;
    object _32766 = NOVALUE;
    object _32765 = NOVALUE;
    object _32764 = NOVALUE;
    object _32762 = NOVALUE;
    object _32761 = NOVALUE;
    object _32760 = NOVALUE;
    object _32759 = NOVALUE;
    object _32757 = NOVALUE;
    object _32756 = NOVALUE;
    object _32755 = NOVALUE;
    object _32754 = NOVALUE;
    object _32752 = NOVALUE;
    object _32751 = NOVALUE;
    object _32750 = NOVALUE;
    object _32749 = NOVALUE;
    object _32747 = NOVALUE;
    object _32746 = NOVALUE;
    object _32745 = NOVALUE;
    object _32743 = NOVALUE;
    object _32740 = NOVALUE;
    object _32739 = NOVALUE;
    object _32738 = NOVALUE;
    object _32737 = NOVALUE;
    object _32736 = NOVALUE;
    object _32735 = NOVALUE;
    object _32734 = NOVALUE;
    object _32733 = NOVALUE;
    object _32732 = NOVALUE;
    object _32729 = NOVALUE;
    object _32728 = NOVALUE;
    object _32727 = NOVALUE;
    object _32726 = NOVALUE;
    object _32724 = NOVALUE;
    object _32722 = NOVALUE;
    object _32721 = NOVALUE;
    object _32719 = NOVALUE;
    object _32718 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:943		if tcb[current_task][TASK_STATE] = ST_ACTIVE then*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32718 = (object)*(((s1_ptr)_2)->base + _67current_task_65347);
    _2 = (object)SEQ_PTR(_32718);
    _32719 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32718 = NOVALUE;
    if (binary_op_a(NOTEQ, _32719, 0LL)){
        _32719 = NOVALUE;
        goto L1; // [15] 312
    }
    _32719 = NOVALUE;

    /** execute.e:944			if tcb[current_task][TASK_RUNS_LEFT] > 0 then*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32721 = (object)*(((s1_ptr)_2)->base + _67current_task_65347);
    _2 = (object)SEQ_PTR(_32721);
    _32722 = (object)*(((s1_ptr)_2)->base + 10LL);
    _32721 = NOVALUE;
    if (binary_op_a(LESSEQ, _32722, 0LL)){
        _32722 = NOVALUE;
        goto L2; // [33] 61
    }
    _32722 = NOVALUE;

    /** execute.e:945				tcb[current_task][TASK_RUNS_LEFT] -= 1*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65374 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_65347 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _32726 = (object)*(((s1_ptr)_2)->base + 10LL);
    _32724 = NOVALUE;
    if (IS_ATOM_INT(_32726)) {
        _32727 = _32726 - 1LL;
        if ((object)((uintptr_t)_32727 +(uintptr_t) HIGH_BITS) >= 0){
            _32727 = NewDouble((eudouble)_32727);
        }
    }
    else {
        _32727 = binary_op(MINUS, _32726, 1LL);
    }
    _32726 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32727;
    if( _1 != _32727 ){
        DeRef(_1);
    }
    _32727 = NOVALUE;
    _32724 = NOVALUE;
L2: 

    /** execute.e:947			if tcb[current_task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32728 = (object)*(((s1_ptr)_2)->base + _67current_task_65347);
    _2 = (object)SEQ_PTR(_32728);
    _32729 = (object)*(((s1_ptr)_2)->base + 3LL);
    _32728 = NOVALUE;
    if (binary_op_a(NOTEQ, _32729, 1LL)){
        _32729 = NOVALUE;
        goto L3; // [75] 311
    }
    _32729 = NOVALUE;

    /** execute.e:948				now = time()*/
    DeRef(_now_66380);
    _now_66380 = NewDouble(current_time());

    /** execute.e:949				if tcb[current_task][TASK_RUNS_MAX] > 1 and*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32732 = (object)*(((s1_ptr)_2)->base + _67current_task_65347);
    _2 = (object)SEQ_PTR(_32732);
    _32733 = (object)*(((s1_ptr)_2)->base + 11LL);
    _32732 = NOVALUE;
    if (IS_ATOM_INT(_32733)) {
        _32734 = (_32733 > 1LL);
    }
    else {
        _32734 = binary_op(GREATER, _32733, 1LL);
    }
    _32733 = NOVALUE;
    if (IS_ATOM_INT(_32734)) {
        if (_32734 == 0) {
            goto L4; // [101] 247
        }
    }
    else {
        if (DBL_PTR(_32734)->dbl == 0.0) {
            goto L4; // [101] 247
        }
    }
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32736 = (object)*(((s1_ptr)_2)->base + _67current_task_65347);
    _2 = (object)SEQ_PTR(_32736);
    _32737 = (object)*(((s1_ptr)_2)->base + 5LL);
    _32736 = NOVALUE;
    _32738 = binary_op(EQUALS, _32737, _now_66380);
    _32737 = NOVALUE;
    if (_32738 == 0) {
        DeRef(_32738);
        _32738 = NOVALUE;
        goto L4; // [122] 247
    }
    else {
        if (!IS_ATOM_INT(_32738) && DBL_PTR(_32738)->dbl == 0.0){
            DeRef(_32738);
            _32738 = NOVALUE;
            goto L4; // [122] 247
        }
        DeRef(_32738);
        _32738 = NOVALUE;
    }
    DeRef(_32738);
    _32738 = NOVALUE;

    /** execute.e:952					if tcb[current_task][TASK_RUNS_LEFT] = 0 then*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32739 = (object)*(((s1_ptr)_2)->base + _67current_task_65347);
    _2 = (object)SEQ_PTR(_32739);
    _32740 = (object)*(((s1_ptr)_2)->base + 10LL);
    _32739 = NOVALUE;
    if (binary_op_a(NOTEQ, _32740, 0LL)){
        _32740 = NOVALUE;
        goto L5; // [139] 310
    }
    _32740 = NOVALUE;

    /** execute.e:954						now += clock_period*/
    _0 = _now_66380;
    if (IS_ATOM_INT(_now_66380)) {
        _now_66380 = NewDouble((eudouble)_now_66380 + DBL_PTR(_67clock_period_65350)->dbl);
    }
    else {
        _now_66380 = NewDouble(DBL_PTR(_now_66380)->dbl + DBL_PTR(_67clock_period_65350)->dbl);
    }
    DeRef(_0);

    /** execute.e:955						tcb[current_task][TASK_RUNS_LEFT] = tcb[current_task][TASK_RUNS_MAX]*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65374 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_65347 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32745 = (object)*(((s1_ptr)_2)->base + _67current_task_65347);
    _2 = (object)SEQ_PTR(_32745);
    _32746 = (object)*(((s1_ptr)_2)->base + 11LL);
    _32745 = NOVALUE;
    Ref(_32746);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32746;
    if( _1 != _32746 ){
        DeRef(_1);
    }
    _32746 = NOVALUE;
    _32743 = NOVALUE;

    /** execute.e:956						tcb[current_task][TASK_MIN_TIME] = now +*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65374 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_65347 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32749 = (object)*(((s1_ptr)_2)->base + _67current_task_65347);
    _2 = (object)SEQ_PTR(_32749);
    _32750 = (object)*(((s1_ptr)_2)->base + 6LL);
    _32749 = NOVALUE;
    _32751 = binary_op(PLUS, _now_66380, _32750);
    _32750 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 8LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32751;
    if( _1 != _32751 ){
        DeRef(_1);
    }
    _32751 = NOVALUE;
    _32747 = NOVALUE;

    /** execute.e:958						tcb[current_task][TASK_MAX_TIME] = now +*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65374 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_65347 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32754 = (object)*(((s1_ptr)_2)->base + _67current_task_65347);
    _2 = (object)SEQ_PTR(_32754);
    _32755 = (object)*(((s1_ptr)_2)->base + 7LL);
    _32754 = NOVALUE;
    _32756 = binary_op(PLUS, _now_66380, _32755);
    _32755 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32756;
    if( _1 != _32756 ){
        DeRef(_1);
    }
    _32756 = NOVALUE;
    _32752 = NOVALUE;
    goto L5; // [240] 310
    goto L5; // [244] 310
L4: 

    /** execute.e:965					tcb[current_task][TASK_MIN_TIME] = now +*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65374 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_65347 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32759 = (object)*(((s1_ptr)_2)->base + _67current_task_65347);
    _2 = (object)SEQ_PTR(_32759);
    _32760 = (object)*(((s1_ptr)_2)->base + 6LL);
    _32759 = NOVALUE;
    if (IS_ATOM_INT(_now_66380) && IS_ATOM_INT(_32760)) {
        _32761 = _now_66380 + _32760;
        if ((object)((uintptr_t)_32761 + (uintptr_t)HIGH_BITS) >= 0){
            _32761 = NewDouble((eudouble)_32761);
        }
    }
    else {
        _32761 = binary_op(PLUS, _now_66380, _32760);
    }
    _32760 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 8LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32761;
    if( _1 != _32761 ){
        DeRef(_1);
    }
    _32761 = NOVALUE;
    _32757 = NOVALUE;

    /** execute.e:967					tcb[current_task][TASK_MAX_TIME] = now +*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65374 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_65347 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32764 = (object)*(((s1_ptr)_2)->base + _67current_task_65347);
    _2 = (object)SEQ_PTR(_32764);
    _32765 = (object)*(((s1_ptr)_2)->base + 7LL);
    _32764 = NOVALUE;
    if (IS_ATOM_INT(_now_66380) && IS_ATOM_INT(_32765)) {
        _32766 = _now_66380 + _32765;
        if ((object)((uintptr_t)_32766 + (uintptr_t)HIGH_BITS) >= 0){
            _32766 = NewDouble((eudouble)_32766);
        }
    }
    else {
        _32766 = binary_op(PLUS, _now_66380, _32765);
    }
    _32765 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32766;
    if( _1 != _32766 ){
        DeRef(_1);
    }
    _32766 = NOVALUE;
    _32762 = NOVALUE;
L5: 
L3: 
L1: 

    /** execute.e:972		scheduler()*/
    _67scheduler();

    /** execute.e:973	end procedure*/
    DeRef(_now_66380);
    DeRef(_32734);
    _32734 = NOVALUE;
    return;
    ;
}


void _67kill_task(object _task_66439)
{
    object _32772 = NOVALUE;
    object _32768 = NOVALUE;
    object _32767 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:977		if tcb[task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32767 = (object)*(((s1_ptr)_2)->base + _task_66439);
    _2 = (object)SEQ_PTR(_32767);
    _32768 = (object)*(((s1_ptr)_2)->base + 3LL);
    _32767 = NOVALUE;
    if (binary_op_a(NOTEQ, _32768, 1LL)){
        _32768 = NOVALUE;
        goto L1; // [15] 33
    }
    _32768 = NOVALUE;

    /** execute.e:978			rt_first = task_delete(rt_first, task)*/
    _0 = _67task_delete(_67rt_first_65377, _task_66439);
    _67rt_first_65377 = _0;
    if (!IS_ATOM_INT(_67rt_first_65377)) {
        _1 = (object)(DBL_PTR(_67rt_first_65377)->dbl);
        DeRefDS(_67rt_first_65377);
        _67rt_first_65377 = _1;
    }
    goto L2; // [30] 45
L1: 

    /** execute.e:980			ts_first = task_delete(ts_first, task)*/
    _0 = _67task_delete(_67ts_first_65378, _task_66439);
    _67ts_first_65378 = _0;
    if (!IS_ATOM_INT(_67ts_first_65378)) {
        _1 = (object)(DBL_PTR(_67ts_first_65378)->dbl);
        DeRefDS(_67ts_first_65378);
        _67ts_first_65378 = _1;
    }
L2: 

    /** execute.e:982		tcb[task][TASK_STATE] = ST_DEAD*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65374 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66439 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _32772 = NOVALUE;

    /** execute.e:984	end procedure*/
    return;
    ;
}


object _67which_task(object _tid_66451)
{
    object _32776 = NOVALUE;
    object _32775 = NOVALUE;
    object _32774 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:989		for i = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_65374)){
            _32774 = SEQ_PTR(_67tcb_65374)->length;
    }
    else {
        _32774 = 1;
    }
    {
        object _i_66453;
        _i_66453 = 1LL;
L1: 
        if (_i_66453 > _32774){
            goto L2; // [8] 45
        }

        /** execute.e:990			if tcb[i][TASK_TID] = tid then*/
        _2 = (object)SEQ_PTR(_67tcb_65374);
        _32775 = (object)*(((s1_ptr)_2)->base + _i_66453);
        _2 = (object)SEQ_PTR(_32775);
        _32776 = (object)*(((s1_ptr)_2)->base + 2LL);
        _32775 = NOVALUE;
        if (binary_op_a(NOTEQ, _32776, _tid_66451)){
            _32776 = NOVALUE;
            goto L3; // [27] 38
        }
        _32776 = NOVALUE;

        /** execute.e:991				return i*/
        DeRef(_tid_66451);
        return _i_66453;
L3: 

        /** execute.e:993		end for*/
        _i_66453 = _i_66453 + 1LL;
        goto L1; // [40] 15
L2: 
        ;
    }

    /** execute.e:994		RTFatal("invalid task id")*/
    RefDS(_32778);
    _67RTFatal(_32778);
    ;
}


void _67opTASK_STATUS()
{
    object _r_66462 = NOVALUE;
    object _tid_66463 = NOVALUE;
    object _32792 = NOVALUE;
    object _32791 = NOVALUE;
    object _32789 = NOVALUE;
    object _32788 = NOVALUE;
    object _32786 = NOVALUE;
    object _32785 = NOVALUE;
    object _32784 = NOVALUE;
    object _32781 = NOVALUE;
    object _32779 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1003		a = Code[pc+1]*/
    _32779 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _32779);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:1004		target = Code[pc+2]*/
    _32781 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _32781);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:1005		tid = val[a]*/
    DeRef(_tid_66463);
    _2 = (object)SEQ_PTR(_67val_65340);
    _tid_66463 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    Ref(_tid_66463);

    /** execute.e:1006		r = -1*/
    _r_66462 = -1LL;

    /** execute.e:1007		for t = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_65374)){
            _32784 = SEQ_PTR(_67tcb_65374)->length;
    }
    else {
        _32784 = 1;
    }
    {
        object _t_66472;
        _t_66472 = 1LL;
L1: 
        if (_t_66472 > _32784){
            goto L2; // [55] 137
        }

        /** execute.e:1008			if tcb[t][TASK_TID] = tid then*/
        _2 = (object)SEQ_PTR(_67tcb_65374);
        _32785 = (object)*(((s1_ptr)_2)->base + _t_66472);
        _2 = (object)SEQ_PTR(_32785);
        _32786 = (object)*(((s1_ptr)_2)->base + 2LL);
        _32785 = NOVALUE;
        if (binary_op_a(NOTEQ, _32786, _tid_66463)){
            _32786 = NOVALUE;
            goto L3; // [74] 130
        }
        _32786 = NOVALUE;

        /** execute.e:1009				if tcb[t][TASK_STATE] = ST_ACTIVE then*/
        _2 = (object)SEQ_PTR(_67tcb_65374);
        _32788 = (object)*(((s1_ptr)_2)->base + _t_66472);
        _2 = (object)SEQ_PTR(_32788);
        _32789 = (object)*(((s1_ptr)_2)->base + 4LL);
        _32788 = NOVALUE;
        if (binary_op_a(NOTEQ, _32789, 0LL)){
            _32789 = NOVALUE;
            goto L4; // [90] 102
        }
        _32789 = NOVALUE;

        /** execute.e:1010					r = 1*/
        _r_66462 = 1LL;
        goto L2; // [99] 137
L4: 

        /** execute.e:1011				elsif tcb[t][TASK_STATE] = ST_SUSPENDED then*/
        _2 = (object)SEQ_PTR(_67tcb_65374);
        _32791 = (object)*(((s1_ptr)_2)->base + _t_66472);
        _2 = (object)SEQ_PTR(_32791);
        _32792 = (object)*(((s1_ptr)_2)->base + 4LL);
        _32791 = NOVALUE;
        if (binary_op_a(NOTEQ, _32792, 1LL)){
            _32792 = NOVALUE;
            goto L2; // [114] 137
        }
        _32792 = NOVALUE;

        /** execute.e:1012					r = 0*/
        _r_66462 = 0LL;

        /** execute.e:1014				exit*/
        goto L2; // [127] 137
L3: 

        /** execute.e:1016		end for*/
        _t_66472 = _t_66472 + 1LL;
        goto L1; // [132] 62
L2: 
        ;
    }

    /** execute.e:1017		val[target] = r*/
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_66462;
    DeRef(_1);

    /** execute.e:1018		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:1019	end procedure*/
    DeRef(_tid_66463);
    DeRef(_32779);
    _32779 = NOVALUE;
    DeRef(_32781);
    _32781 = NOVALUE;
    return;
    ;
}


void _67opTASK_LIST()
{
    object _list_66489 = NOVALUE;
    object _32802 = NOVALUE;
    object _32801 = NOVALUE;
    object _32799 = NOVALUE;
    object _32798 = NOVALUE;
    object _32797 = NOVALUE;
    object _32795 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1025		target = Code[pc+1]*/
    _32795 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _32795);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:1026		list = {}*/
    RefDS(_22218);
    DeRef(_list_66489);
    _list_66489 = _22218;

    /** execute.e:1027		for i = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_65374)){
            _32797 = SEQ_PTR(_67tcb_65374)->length;
    }
    else {
        _32797 = 1;
    }
    {
        object _i_66494;
        _i_66494 = 1LL;
L1: 
        if (_i_66494 > _32797){
            goto L2; // [31] 78
        }

        /** execute.e:1028			if tcb[i][TASK_STATE] != ST_DEAD then*/
        _2 = (object)SEQ_PTR(_67tcb_65374);
        _32798 = (object)*(((s1_ptr)_2)->base + _i_66494);
        _2 = (object)SEQ_PTR(_32798);
        _32799 = (object)*(((s1_ptr)_2)->base + 4LL);
        _32798 = NOVALUE;
        if (binary_op_a(EQUALS, _32799, 2LL)){
            _32799 = NOVALUE;
            goto L3; // [50] 71
        }
        _32799 = NOVALUE;

        /** execute.e:1029				list = append(list, tcb[i][TASK_TID])*/
        _2 = (object)SEQ_PTR(_67tcb_65374);
        _32801 = (object)*(((s1_ptr)_2)->base + _i_66494);
        _2 = (object)SEQ_PTR(_32801);
        _32802 = (object)*(((s1_ptr)_2)->base + 2LL);
        _32801 = NOVALUE;
        Ref(_32802);
        Append(&_list_66489, _list_66489, _32802);
        _32802 = NOVALUE;
L3: 

        /** execute.e:1031		end for*/
        _i_66494 = _i_66494 + 1LL;
        goto L1; // [73] 38
L2: 
        ;
    }

    /** execute.e:1032		val[target] = list*/
    RefDS(_list_66489);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _list_66489;
    DeRef(_1);

    /** execute.e:1033		pc += 2*/
    _67pc_65330 = _67pc_65330 + 2LL;

    /** execute.e:1034	end procedure*/
    DeRefDS(_list_66489);
    DeRef(_32795);
    _32795 = NOVALUE;
    return;
    ;
}


void _67opTASK_SELF()
{
    object _32808 = NOVALUE;
    object _32807 = NOVALUE;
    object _32805 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1038		target = Code[pc+1]*/
    _32805 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _32805);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:1039		val[target] = tcb[current_task][TASK_TID]*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32807 = (object)*(((s1_ptr)_2)->base + _67current_task_65347);
    _2 = (object)SEQ_PTR(_32807);
    _32808 = (object)*(((s1_ptr)_2)->base + 2LL);
    _32807 = NOVALUE;
    Ref(_32808);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32808;
    if( _1 != _32808 ){
        DeRef(_1);
    }
    _32808 = NOVALUE;

    /** execute.e:1040		pc += 2*/
    _67pc_65330 = _67pc_65330 + 2LL;

    /** execute.e:1041	end procedure*/
    _32805 = NOVALUE;
    return;
    ;
}


void _67opTASK_CLOCK_STOP()
{
    object _0, _1, _2;
    

    /** execute.e:1048		if not clock_stopped then*/
    if (_67clock_stopped_66239 != 0)
    goto L1; // [5] 20

    /** execute.e:1049			save_clock = time()*/
    DeRef(_67save_clock_66512);
    _67save_clock_66512 = NewDouble(current_time());

    /** execute.e:1050			clock_stopped = TRUE*/
    _67clock_stopped_66239 = _9TRUE_441;
L1: 

    /** execute.e:1052		pc += 1*/
    _67pc_65330 = _67pc_65330 + 1;

    /** execute.e:1053	end procedure*/
    return;
    ;
}


void _67opTASK_CLOCK_START()
{
    object _shift_66522 = NOVALUE;
    object _32827 = NOVALUE;
    object _32826 = NOVALUE;
    object _32824 = NOVALUE;
    object _32823 = NOVALUE;
    object _32822 = NOVALUE;
    object _32820 = NOVALUE;
    object _32819 = NOVALUE;
    object _32817 = NOVALUE;
    object _32816 = NOVALUE;
    object _32815 = NOVALUE;
    object _32814 = NOVALUE;
    object _32813 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1059		if clock_stopped then*/
    if (_67clock_stopped_66239 == 0)
    {
        goto L1; // [5] 114
    }
    else{
    }

    /** execute.e:1060			if save_clock >= 0 and save_clock < time() then*/
    if (IS_ATOM_INT(_67save_clock_66512)) {
        _32813 = (_67save_clock_66512 >= 0LL);
    }
    else {
        _32813 = (DBL_PTR(_67save_clock_66512)->dbl >= (eudouble)0LL);
    }
    if (_32813 == 0) {
        goto L2; // [16] 106
    }
    _32815 = NewDouble(current_time());
    if (IS_ATOM_INT(_67save_clock_66512)) {
        _32816 = ((eudouble)_67save_clock_66512 < DBL_PTR(_32815)->dbl);
    }
    else {
        _32816 = (DBL_PTR(_67save_clock_66512)->dbl < DBL_PTR(_32815)->dbl);
    }
    DeRefDS(_32815);
    _32815 = NOVALUE;
    if (_32816 == 0)
    {
        DeRef(_32816);
        _32816 = NOVALUE;
        goto L2; // [29] 106
    }
    else{
        DeRef(_32816);
        _32816 = NOVALUE;
    }

    /** execute.e:1061				shift = time() - save_clock*/
    DeRef(_32817);
    _32817 = NewDouble(current_time());
    DeRef(_shift_66522);
    if (IS_ATOM_INT(_67save_clock_66512)) {
        _shift_66522 = NewDouble(DBL_PTR(_32817)->dbl - (eudouble)_67save_clock_66512);
    }
    else
    _shift_66522 = NewDouble(DBL_PTR(_32817)->dbl - DBL_PTR(_67save_clock_66512)->dbl);
    DeRefDS(_32817);
    _32817 = NOVALUE;

    /** execute.e:1062				for i = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_65374)){
            _32819 = SEQ_PTR(_67tcb_65374)->length;
    }
    else {
        _32819 = 1;
    }
    {
        object _i_66532;
        _i_66532 = 1LL;
L3: 
        if (_i_66532 > _32819){
            goto L4; // [49] 105
        }

        /** execute.e:1063					tcb[i][TASK_MIN_TIME] += shift*/
        _2 = (object)SEQ_PTR(_67tcb_65374);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67tcb_65374 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_66532 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _32822 = (object)*(((s1_ptr)_2)->base + 8LL);
        _32820 = NOVALUE;
        if (IS_ATOM_INT(_32822) && IS_ATOM_INT(_shift_66522)) {
            _32823 = _32822 + _shift_66522;
            if ((object)((uintptr_t)_32823 + (uintptr_t)HIGH_BITS) >= 0){
                _32823 = NewDouble((eudouble)_32823);
            }
        }
        else {
            _32823 = binary_op(PLUS, _32822, _shift_66522);
        }
        _32822 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 8LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _32823;
        if( _1 != _32823 ){
            DeRef(_1);
        }
        _32823 = NOVALUE;
        _32820 = NOVALUE;

        /** execute.e:1064					tcb[i][TASK_MAX_TIME] += shift*/
        _2 = (object)SEQ_PTR(_67tcb_65374);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67tcb_65374 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_66532 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _32826 = (object)*(((s1_ptr)_2)->base + 9LL);
        _32824 = NOVALUE;
        if (IS_ATOM_INT(_32826) && IS_ATOM_INT(_shift_66522)) {
            _32827 = _32826 + _shift_66522;
            if ((object)((uintptr_t)_32827 + (uintptr_t)HIGH_BITS) >= 0){
                _32827 = NewDouble((eudouble)_32827);
            }
        }
        else {
            _32827 = binary_op(PLUS, _32826, _shift_66522);
        }
        _32826 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 9LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _32827;
        if( _1 != _32827 ){
            DeRef(_1);
        }
        _32827 = NOVALUE;
        _32824 = NOVALUE;

        /** execute.e:1065				end for*/
        _i_66532 = _i_66532 + 1LL;
        goto L3; // [100] 56
L4: 
        ;
    }
L2: 

    /** execute.e:1067			clock_stopped = FALSE*/
    _67clock_stopped_66239 = _9FALSE_439;
L1: 

    /** execute.e:1069		pc += 1*/
    _67pc_65330 = _67pc_65330 + 1;

    /** execute.e:1070	end procedure*/
    DeRef(_shift_66522);
    DeRef(_32813);
    _32813 = NOVALUE;
    return;
    ;
}


void _67opTASK_SUSPEND()
{
    object _task_66546 = NOVALUE;
    object _32838 = NOVALUE;
    object _32837 = NOVALUE;
    object _32835 = NOVALUE;
    object _32833 = NOVALUE;
    object _32831 = NOVALUE;
    object _32829 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1076		a = Code[pc+1]*/
    _32829 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _32829);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:1077		task = which_task(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _32831 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    Ref(_32831);
    _task_66546 = _67which_task(_32831);
    _32831 = NOVALUE;
    if (!IS_ATOM_INT(_task_66546)) {
        _1 = (object)(DBL_PTR(_task_66546)->dbl);
        DeRefDS(_task_66546);
        _task_66546 = _1;
    }

    /** execute.e:1078		tcb[task][TASK_STATE] = ST_SUSPENDED*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65374 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66546 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _32833 = NOVALUE;

    /** execute.e:1079		tcb[task][TASK_MAX_TIME] = TASK_NEVER*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65374 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66546 + ((s1_ptr)_2)->base);
    RefDS(_67TASK_NEVER_65341);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67TASK_NEVER_65341;
    DeRef(_1);
    _32835 = NOVALUE;

    /** execute.e:1080		if tcb[task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32837 = (object)*(((s1_ptr)_2)->base + _task_66546);
    _2 = (object)SEQ_PTR(_32837);
    _32838 = (object)*(((s1_ptr)_2)->base + 3LL);
    _32837 = NOVALUE;
    if (binary_op_a(NOTEQ, _32838, 1LL)){
        _32838 = NOVALUE;
        goto L1; // [71] 89
    }
    _32838 = NOVALUE;

    /** execute.e:1081			rt_first = task_delete(rt_first, task)*/
    _0 = _67task_delete(_67rt_first_65377, _task_66546);
    _67rt_first_65377 = _0;
    if (!IS_ATOM_INT(_67rt_first_65377)) {
        _1 = (object)(DBL_PTR(_67rt_first_65377)->dbl);
        DeRefDS(_67rt_first_65377);
        _67rt_first_65377 = _1;
    }
    goto L2; // [86] 101
L1: 

    /** execute.e:1083			ts_first = task_delete(ts_first, task)*/
    _0 = _67task_delete(_67ts_first_65378, _task_66546);
    _67ts_first_65378 = _0;
    if (!IS_ATOM_INT(_67ts_first_65378)) {
        _1 = (object)(DBL_PTR(_67ts_first_65378)->dbl);
        DeRefDS(_67ts_first_65378);
        _67ts_first_65378 = _1;
    }
L2: 

    /** execute.e:1085		pc += 2*/
    _67pc_65330 = _67pc_65330 + 2LL;

    /** execute.e:1086	end procedure*/
    DeRef(_32829);
    _32829 = NOVALUE;
    return;
    ;
}


void _67opTASK_CREATE()
{
    object _sub_66567 = NOVALUE;
    object _new_entry_66568 = NOVALUE;
    object _recycle_66570 = NOVALUE;
    object _32878 = NOVALUE;
    object _32877 = NOVALUE;
    object _32876 = NOVALUE;
    object _32874 = NOVALUE;
    object _32873 = NOVALUE;
    object _32872 = NOVALUE;
    object _32870 = NOVALUE;
    object _32866 = NOVALUE;
    object _32865 = NOVALUE;
    object _32864 = NOVALUE;
    object _32862 = NOVALUE;
    object _32861 = NOVALUE;
    object _32859 = NOVALUE;
    object _32856 = NOVALUE;
    object _32855 = NOVALUE;
    object _32853 = NOVALUE;
    object _32852 = NOVALUE;
    object _32850 = NOVALUE;
    object _32849 = NOVALUE;
    object _32848 = NOVALUE;
    object _32846 = NOVALUE;
    object _32845 = NOVALUE;
    object _32843 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1091		sequence new_entry*/

    /** execute.e:1094		a = Code[pc+1] -- routine id*/
    _32843 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _32843);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:1095		if val[a] < 0 or val[a] >= length(e_routine) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _32845 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_ATOM_INT(_32845)) {
        _32846 = (_32845 < 0LL);
    }
    else {
        _32846 = binary_op(LESS, _32845, 0LL);
    }
    _32845 = NOVALUE;
    if (IS_ATOM_INT(_32846)) {
        if (_32846 != 0) {
            goto L1; // [33] 59
        }
    }
    else {
        if (DBL_PTR(_32846)->dbl != 0.0) {
            goto L1; // [33] 59
        }
    }
    _2 = (object)SEQ_PTR(_67val_65340);
    _32848 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_SEQUENCE(_67e_routine_65379)){
            _32849 = SEQ_PTR(_67e_routine_65379)->length;
    }
    else {
        _32849 = 1;
    }
    if (IS_ATOM_INT(_32848)) {
        _32850 = (_32848 >= _32849);
    }
    else {
        _32850 = binary_op(GREATEREQ, _32848, _32849);
    }
    _32848 = NOVALUE;
    _32849 = NOVALUE;
    if (_32850 == 0) {
        DeRef(_32850);
        _32850 = NOVALUE;
        goto L2; // [55] 65
    }
    else {
        if (!IS_ATOM_INT(_32850) && DBL_PTR(_32850)->dbl == 0.0){
            DeRef(_32850);
            _32850 = NOVALUE;
            goto L2; // [55] 65
        }
        DeRef(_32850);
        _32850 = NOVALUE;
    }
    DeRef(_32850);
    _32850 = NOVALUE;
L1: 

    /** execute.e:1096			RTFatal("invalid routine id")*/
    RefDS(_32851);
    _67RTFatal(_32851);
L2: 

    /** execute.e:1098		sub = e_routine[val[a]+1]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _32852 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_ATOM_INT(_32852)) {
        _32853 = _32852 + 1;
    }
    else
    _32853 = binary_op(PLUS, 1, _32852);
    _32852 = NOVALUE;
    _2 = (object)SEQ_PTR(_67e_routine_65379);
    if (!IS_ATOM_INT(_32853)){
        _sub_66567 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32853)->dbl));
    }
    else{
        _sub_66567 = (object)*(((s1_ptr)_2)->base + _32853);
    }

    /** execute.e:1099		if SymTab[sub][S_TOKEN] != PROC then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32855 = (object)*(((s1_ptr)_2)->base + _sub_66567);
    _2 = (object)SEQ_PTR(_32855);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _32856 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _32856 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _32855 = NOVALUE;
    if (binary_op_a(EQUALS, _32856, 27LL)){
        _32856 = NOVALUE;
        goto L3; // [103] 113
    }
    _32856 = NOVALUE;

    /** execute.e:1100			RTFatal("specify the routine id of a procedure, not a function or type")*/
    RefDS(_32858);
    _67RTFatal(_32858);
L3: 

    /** execute.e:1102		b = Code[pc+2] -- args*/
    _32859 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _32859);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:1105		new_entry = {val[a], next_task_id, T_REAL_TIME, ST_SUSPENDED, 0,*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _32861 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _32862 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _0 = _new_entry_66568;
    _1 = NewS1(16);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_32861);
    ((intptr_t*)_2)[1] = _32861;
    Ref(_67next_task_id_65349);
    ((intptr_t*)_2)[2] = _67next_task_id_65349;
    ((intptr_t*)_2)[3] = 1LL;
    ((intptr_t*)_2)[4] = 1LL;
    ((intptr_t*)_2)[5] = 0LL;
    ((intptr_t*)_2)[6] = 0LL;
    ((intptr_t*)_2)[7] = 0LL;
    ((intptr_t*)_2)[8] = 0LL;
    RefDS(_67TASK_NEVER_65341);
    ((intptr_t*)_2)[9] = _67TASK_NEVER_65341;
    ((intptr_t*)_2)[10] = 1LL;
    ((intptr_t*)_2)[11] = 1LL;
    ((intptr_t*)_2)[12] = 0LL;
    Ref(_32862);
    ((intptr_t*)_2)[13] = _32862;
    ((intptr_t*)_2)[14] = 0LL;
    RefDSn(_22218, 2);
    ((intptr_t*)_2)[15] = _22218;
    ((intptr_t*)_2)[16] = _22218;
    _new_entry_66568 = MAKE_SEQ(_1);
    DeRef(_0);
    _32862 = NOVALUE;
    _32861 = NOVALUE;

    /** execute.e:1108		recycle = FALSE*/
    _recycle_66570 = _9FALSE_439;

    /** execute.e:1109		for i = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_65374)){
            _32864 = SEQ_PTR(_67tcb_65374)->length;
    }
    else {
        _32864 = 1;
    }
    {
        object _i_66601;
        _i_66601 = 1LL;
L4: 
        if (_i_66601 > _32864){
            goto L5; // [182] 232
        }

        /** execute.e:1110			if tcb[i][TASK_STATE] = ST_DEAD then*/
        _2 = (object)SEQ_PTR(_67tcb_65374);
        _32865 = (object)*(((s1_ptr)_2)->base + _i_66601);
        _2 = (object)SEQ_PTR(_32865);
        _32866 = (object)*(((s1_ptr)_2)->base + 4LL);
        _32865 = NOVALUE;
        if (binary_op_a(NOTEQ, _32866, 2LL)){
            _32866 = NOVALUE;
            goto L6; // [201] 225
        }
        _32866 = NOVALUE;

        /** execute.e:1113				tcb[i] = new_entry*/
        RefDS(_new_entry_66568);
        _2 = (object)SEQ_PTR(_67tcb_65374);
        _2 = (object)(((s1_ptr)_2)->base + _i_66601);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _new_entry_66568;
        DeRefDS(_1);

        /** execute.e:1114				recycle = TRUE*/
        _recycle_66570 = _9TRUE_441;

        /** execute.e:1115				exit*/
        goto L5; // [222] 232
L6: 

        /** execute.e:1117		end for*/
        _i_66601 = _i_66601 + 1LL;
        goto L4; // [227] 189
L5: 
        ;
    }

    /** execute.e:1119		if not recycle then*/
    if (_recycle_66570 != 0)
    goto L7; // [234] 246

    /** execute.e:1121			tcb = append(tcb, new_entry)*/
    RefDS(_new_entry_66568);
    Append(&_67tcb_65374, _67tcb_65374, _new_entry_66568);
L7: 

    /** execute.e:1124		target = Code[pc+3]*/
    _32870 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _32870);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:1125		val[target] = next_task_id*/
    Ref(_67next_task_id_65349);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67next_task_id_65349;
    DeRef(_1);

    /** execute.e:1126		if not id_wrap and next_task_id < TASK_ID_MAX then*/
    _32872 = (_67id_wrap_65345 == 0);
    if (_32872 == 0) {
        goto L8; // [281] 306
    }
    if (IS_ATOM_INT(_67next_task_id_65349)) {
        _32874 = ((eudouble)_67next_task_id_65349 < DBL_PTR(_67TASK_ID_MAX_65342)->dbl);
    }
    else {
        _32874 = (DBL_PTR(_67next_task_id_65349)->dbl < DBL_PTR(_67TASK_ID_MAX_65342)->dbl);
    }
    if (_32874 == 0)
    {
        DeRef(_32874);
        _32874 = NOVALUE;
        goto L8; // [292] 306
    }
    else{
        DeRef(_32874);
        _32874 = NOVALUE;
    }

    /** execute.e:1127			next_task_id += 1*/
    _0 = _67next_task_id_65349;
    if (IS_ATOM_INT(_67next_task_id_65349)) {
        _67next_task_id_65349 = _67next_task_id_65349 + 1;
        if (_67next_task_id_65349 > MAXINT){
            _67next_task_id_65349 = NewDouble((eudouble)_67next_task_id_65349);
        }
    }
    else
    _67next_task_id_65349 = binary_op(PLUS, 1, _67next_task_id_65349);
    DeRef(_0);
    goto L9; // [303] 396
L8: 

    /** execute.e:1130			id_wrap = TRUE -- id's have wrapped*/
    _67id_wrap_65345 = _9TRUE_441;

    /** execute.e:1131			for i = 1 to TASK_ID_MAX do*/
    {
        object _i_66622;
        _i_66622 = 1LL;
LA: 
        if (binary_op_a(GREATER, _i_66622, _67TASK_ID_MAX_65342)){
            goto LB; // [315] 395
        }

        /** execute.e:1132				next_task_id = i*/
        Ref(_i_66622);
        DeRef(_67next_task_id_65349);
        _67next_task_id_65349 = _i_66622;

        /** execute.e:1133				for j = 1 to length(tcb) do*/
        if (IS_SEQUENCE(_67tcb_65374)){
                _32876 = SEQ_PTR(_67tcb_65374)->length;
        }
        else {
            _32876 = 1;
        }
        {
            object _j_66624;
            _j_66624 = 1LL;
LC: 
            if (_j_66624 > _32876){
                goto LD; // [334] 376
            }

            /** execute.e:1134					if next_task_id = tcb[j][TASK_TID] then*/
            _2 = (object)SEQ_PTR(_67tcb_65374);
            _32877 = (object)*(((s1_ptr)_2)->base + _j_66624);
            _2 = (object)SEQ_PTR(_32877);
            _32878 = (object)*(((s1_ptr)_2)->base + 2LL);
            _32877 = NOVALUE;
            if (binary_op_a(NOTEQ, _67next_task_id_65349, _32878)){
                _32878 = NOVALUE;
                goto LE; // [355] 369
            }
            _32878 = NOVALUE;

            /** execute.e:1135						next_task_id = 0*/
            DeRef(_67next_task_id_65349);
            _67next_task_id_65349 = 0LL;

            /** execute.e:1136						exit -- this id is still in use*/
            goto LD; // [366] 376
LE: 

            /** execute.e:1138				end for*/
            _j_66624 = _j_66624 + 1LL;
            goto LC; // [371] 341
LD: 
            ;
        }

        /** execute.e:1139				if next_task_id then*/
        if (_67next_task_id_65349 == 0) {
            goto LF; // [380] 388
        }
        else {
            if (!IS_ATOM_INT(_67next_task_id_65349) && DBL_PTR(_67next_task_id_65349)->dbl == 0.0){
                goto LF; // [380] 388
            }
        }

        /** execute.e:1140					exit -- found unused id for next time*/
        goto LB; // [385] 395
LF: 

        /** execute.e:1142			end for*/
        _0 = _i_66622;
        if (IS_ATOM_INT(_i_66622)) {
            _i_66622 = _i_66622 + 1LL;
            if ((object)((uintptr_t)_i_66622 +(uintptr_t) HIGH_BITS) >= 0){
                _i_66622 = NewDouble((eudouble)_i_66622);
            }
        }
        else {
            _i_66622 = binary_op_a(PLUS, _i_66622, 1LL);
        }
        DeRef(_0);
        goto LA; // [390] 322
LB: 
        ;
        DeRef(_i_66622);
    }
L9: 

    /** execute.e:1145		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:1146	end procedure*/
    DeRef(_new_entry_66568);
    DeRef(_32870);
    _32870 = NOVALUE;
    DeRef(_32859);
    _32859 = NOVALUE;
    DeRef(_32843);
    _32843 = NOVALUE;
    DeRef(_32853);
    _32853 = NOVALUE;
    DeRef(_32846);
    _32846 = NOVALUE;
    DeRef(_32872);
    _32872 = NOVALUE;
    return;
    ;
}


void _67opTASK_SCHEDULE()
{
    object _task_66634 = NOVALUE;
    object _now_66635 = NOVALUE;
    object _s_66636 = NOVALUE;
    object _32970 = NOVALUE;
    object _32968 = NOVALUE;
    object _32966 = NOVALUE;
    object _32965 = NOVALUE;
    object _32964 = NOVALUE;
    object _32962 = NOVALUE;
    object _32961 = NOVALUE;
    object _32960 = NOVALUE;
    object _32957 = NOVALUE;
    object _32956 = NOVALUE;
    object _32955 = NOVALUE;
    object _32954 = NOVALUE;
    object _32952 = NOVALUE;
    object _32951 = NOVALUE;
    object _32950 = NOVALUE;
    object _32948 = NOVALUE;
    object _32946 = NOVALUE;
    object _32944 = NOVALUE;
    object _32942 = NOVALUE;
    object _32939 = NOVALUE;
    object _32938 = NOVALUE;
    object _32937 = NOVALUE;
    object _32935 = NOVALUE;
    object _32932 = NOVALUE;
    object _32930 = NOVALUE;
    object _32929 = NOVALUE;
    object _32928 = NOVALUE;
    object _32926 = NOVALUE;
    object _32923 = NOVALUE;
    object _32922 = NOVALUE;
    object _32920 = NOVALUE;
    object _32919 = NOVALUE;
    object _32917 = NOVALUE;
    object _32916 = NOVALUE;
    object _32914 = NOVALUE;
    object _32913 = NOVALUE;
    object _32911 = NOVALUE;
    object _32910 = NOVALUE;
    object _32907 = NOVALUE;
    object _32905 = NOVALUE;
    object _32903 = NOVALUE;
    object _32902 = NOVALUE;
    object _32901 = NOVALUE;
    object _32899 = NOVALUE;
    object _32898 = NOVALUE;
    object _32897 = NOVALUE;
    object _32894 = NOVALUE;
    object _32893 = NOVALUE;
    object _32891 = NOVALUE;
    object _32888 = NOVALUE;
    object _32885 = NOVALUE;
    object _32883 = NOVALUE;
    object _32881 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1156		a = Code[pc+1]*/
    _32881 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _32881);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:1157		task = which_task(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _32883 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    Ref(_32883);
    _task_66634 = _67which_task(_32883);
    _32883 = NOVALUE;
    if (!IS_ATOM_INT(_task_66634)) {
        _1 = (object)(DBL_PTR(_task_66634)->dbl);
        DeRefDS(_task_66634);
        _task_66634 = _1;
    }

    /** execute.e:1158		b = Code[pc+2]*/
    _32885 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _32885);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:1159		s = val[b]*/
    DeRef(_s_66636);
    _2 = (object)SEQ_PTR(_67val_65340);
    _s_66636 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    Ref(_s_66636);

    /** execute.e:1161		if atom(s) then*/
    _32888 = IS_ATOM(_s_66636);
    if (_32888 == 0)
    {
        _32888 = NOVALUE;
        goto L1; // [64] 187
    }
    else{
        _32888 = NOVALUE;
    }

    /** execute.e:1163			if s <= 0 then*/
    if (binary_op_a(GREATER, _s_66636, 0LL)){
        goto L2; // [69] 79
    }

    /** execute.e:1164				RTFatal("number of executions must be greater than 0")*/
    RefDS(_32890);
    _67RTFatal(_32890);
L2: 

    /** execute.e:1167			tcb[task][TASK_RUNS_MAX] = s   -- max execution count*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65374 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66634 + ((s1_ptr)_2)->base);
    Ref(_s_66636);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_66636;
    DeRef(_1);
    _32891 = NOVALUE;

    /** execute.e:1168			if tcb[task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32893 = (object)*(((s1_ptr)_2)->base + _task_66634);
    _2 = (object)SEQ_PTR(_32893);
    _32894 = (object)*(((s1_ptr)_2)->base + 3LL);
    _32893 = NOVALUE;
    if (binary_op_a(NOTEQ, _32894, 1LL)){
        _32894 = NOVALUE;
        goto L3; // [104] 120
    }
    _32894 = NOVALUE;

    /** execute.e:1169				rt_first = task_delete(rt_first, task)*/
    _0 = _67task_delete(_67rt_first_65377, _task_66634);
    _67rt_first_65377 = _0;
    if (!IS_ATOM_INT(_67rt_first_65377)) {
        _1 = (object)(DBL_PTR(_67rt_first_65377)->dbl);
        DeRefDS(_67rt_first_65377);
        _67rt_first_65377 = _1;
    }
L3: 

    /** execute.e:1171			if tcb[task][TASK_TYPE] = T_REAL_TIME or*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32897 = (object)*(((s1_ptr)_2)->base + _task_66634);
    _2 = (object)SEQ_PTR(_32897);
    _32898 = (object)*(((s1_ptr)_2)->base + 3LL);
    _32897 = NOVALUE;
    if (IS_ATOM_INT(_32898)) {
        _32899 = (_32898 == 1LL);
    }
    else {
        _32899 = binary_op(EQUALS, _32898, 1LL);
    }
    _32898 = NOVALUE;
    if (IS_ATOM_INT(_32899)) {
        if (_32899 != 0) {
            goto L4; // [136] 159
        }
    }
    else {
        if (DBL_PTR(_32899)->dbl != 0.0) {
            goto L4; // [136] 159
        }
    }
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32901 = (object)*(((s1_ptr)_2)->base + _task_66634);
    _2 = (object)SEQ_PTR(_32901);
    _32902 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32901 = NOVALUE;
    if (IS_ATOM_INT(_32902)) {
        _32903 = (_32902 == 1LL);
    }
    else {
        _32903 = binary_op(EQUALS, _32902, 1LL);
    }
    _32902 = NOVALUE;
    if (_32903 == 0) {
        DeRef(_32903);
        _32903 = NOVALUE;
        goto L5; // [155] 171
    }
    else {
        if (!IS_ATOM_INT(_32903) && DBL_PTR(_32903)->dbl == 0.0){
            DeRef(_32903);
            _32903 = NOVALUE;
            goto L5; // [155] 171
        }
        DeRef(_32903);
        _32903 = NOVALUE;
    }
    DeRef(_32903);
    _32903 = NOVALUE;
L4: 

    /** execute.e:1173				ts_first = task_insert(ts_first, task)*/
    _0 = _67task_insert(_67ts_first_65378, _task_66634);
    _67ts_first_65378 = _0;
    if (!IS_ATOM_INT(_67ts_first_65378)) {
        _1 = (object)(DBL_PTR(_67ts_first_65378)->dbl);
        DeRefDS(_67ts_first_65378);
        _67ts_first_65378 = _1;
    }
L5: 

    /** execute.e:1175			tcb[task][TASK_TYPE] = T_TIME_SHARE*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65374 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66634 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _32905 = NOVALUE;
    goto L6; // [184] 542
L1: 

    /** execute.e:1179			if length(s) != 2 then*/
    if (IS_SEQUENCE(_s_66636)){
            _32907 = SEQ_PTR(_s_66636)->length;
    }
    else {
        _32907 = 1;
    }
    if (_32907 == 2LL)
    goto L7; // [192] 202

    /** execute.e:1180				RTFatal("second argument must be {min-time, max-time}")*/
    RefDS(_32909);
    _67RTFatal(_32909);
L7: 

    /** execute.e:1182			if sequence(s[1]) or sequence(s[2]) then*/
    _2 = (object)SEQ_PTR(_s_66636);
    _32910 = (object)*(((s1_ptr)_2)->base + 1LL);
    _32911 = IS_SEQUENCE(_32910);
    _32910 = NOVALUE;
    if (_32911 != 0) {
        goto L8; // [211] 227
    }
    _2 = (object)SEQ_PTR(_s_66636);
    _32913 = (object)*(((s1_ptr)_2)->base + 2LL);
    _32914 = IS_SEQUENCE(_32913);
    _32913 = NOVALUE;
    if (_32914 == 0)
    {
        _32914 = NOVALUE;
        goto L9; // [223] 233
    }
    else{
        _32914 = NOVALUE;
    }
L8: 

    /** execute.e:1183				RTFatal("min and max times must be atoms")*/
    RefDS(_32915);
    _67RTFatal(_32915);
L9: 

    /** execute.e:1185			if s[1] < 0 or s[2] < 0 then*/
    _2 = (object)SEQ_PTR(_s_66636);
    _32916 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_32916)) {
        _32917 = (_32916 < 0LL);
    }
    else {
        _32917 = binary_op(LESS, _32916, 0LL);
    }
    _32916 = NOVALUE;
    if (IS_ATOM_INT(_32917)) {
        if (_32917 != 0) {
            goto LA; // [243] 260
        }
    }
    else {
        if (DBL_PTR(_32917)->dbl != 0.0) {
            goto LA; // [243] 260
        }
    }
    _2 = (object)SEQ_PTR(_s_66636);
    _32919 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_32919)) {
        _32920 = (_32919 < 0LL);
    }
    else {
        _32920 = binary_op(LESS, _32919, 0LL);
    }
    _32919 = NOVALUE;
    if (_32920 == 0) {
        DeRef(_32920);
        _32920 = NOVALUE;
        goto LB; // [256] 266
    }
    else {
        if (!IS_ATOM_INT(_32920) && DBL_PTR(_32920)->dbl == 0.0){
            DeRef(_32920);
            _32920 = NOVALUE;
            goto LB; // [256] 266
        }
        DeRef(_32920);
        _32920 = NOVALUE;
    }
    DeRef(_32920);
    _32920 = NOVALUE;
LA: 

    /** execute.e:1186				RTFatal("min and max times must be greater than or equal to 0")*/
    RefDS(_32921);
    _67RTFatal(_32921);
LB: 

    /** execute.e:1188			if s[1] > s[2] then*/
    _2 = (object)SEQ_PTR(_s_66636);
    _32922 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_s_66636);
    _32923 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (binary_op_a(LESSEQ, _32922, _32923)){
        _32922 = NOVALUE;
        _32923 = NOVALUE;
        goto LC; // [276] 286
    }
    _32922 = NOVALUE;
    _32923 = NOVALUE;

    /** execute.e:1189				RTFatal("task min time must be <= task max time")*/
    RefDS(_32925);
    _67RTFatal(_32925);
LC: 

    /** execute.e:1191			tcb[task][TASK_MIN_INC] = s[1]*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65374 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66634 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_s_66636);
    _32928 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_32928);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32928;
    if( _1 != _32928 ){
        DeRef(_1);
    }
    _32928 = NOVALUE;
    _32926 = NOVALUE;

    /** execute.e:1193			if s[1] < clock_period/2 then*/
    _2 = (object)SEQ_PTR(_s_66636);
    _32929 = (object)*(((s1_ptr)_2)->base + 1LL);
    _32930 = binary_op(DIVIDE, _67clock_period_65350, 2);
    if (binary_op_a(GREATEREQ, _32929, _32930)){
        _32929 = NOVALUE;
        DeRefDS(_32930);
        _32930 = NOVALUE;
        goto LD; // [315] 372
    }
    _32929 = NOVALUE;
    DeRef(_32930);
    _32930 = NOVALUE;

    /** execute.e:1195				if s[1] > 1.0e-9 then*/
    _2 = (object)SEQ_PTR(_s_66636);
    _32932 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(LESSEQ, _32932, _32933)){
        _32932 = NOVALUE;
        goto LE; // [325] 355
    }
    _32932 = NOVALUE;

    /** execute.e:1196					tcb[task][TASK_RUNS_MAX] =  floor(clock_period / s[1])*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65374 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66634 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_s_66636);
    _32937 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = binary_op(DIVIDE, _67clock_period_65350, _32937);
    _32938 = unary_op(FLOOR, _2);
    DeRef(_2);
    _32937 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32938;
    if( _1 != _32938 ){
        DeRef(_1);
    }
    _32938 = NOVALUE;
    _32935 = NOVALUE;
    goto LF; // [352] 386
LE: 

    /** execute.e:1199					tcb[task][TASK_RUNS_MAX] =  1000000000 -- arbitrary, large*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65374 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66634 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1000000000LL;
    DeRef(_1);
    _32939 = NOVALUE;
    goto LF; // [369] 386
LD: 

    /** execute.e:1202				tcb[task][TASK_RUNS_MAX] = 1*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65374 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66634 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _32942 = NOVALUE;
LF: 

    /** execute.e:1204			tcb[task][TASK_MAX_INC] = s[2]*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65374 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66634 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_s_66636);
    _32946 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_32946);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 7LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32946;
    if( _1 != _32946 ){
        DeRef(_1);
    }
    _32946 = NOVALUE;
    _32944 = NOVALUE;

    /** execute.e:1205			now = time()*/
    DeRef(_now_66635);
    _now_66635 = NewDouble(current_time());

    /** execute.e:1206			tcb[task][TASK_MIN_TIME] = now + s[1]*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65374 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66634 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_s_66636);
    _32950 = (object)*(((s1_ptr)_2)->base + 1LL);
    _32951 = binary_op(PLUS, _now_66635, _32950);
    _32950 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 8LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32951;
    if( _1 != _32951 ){
        DeRef(_1);
    }
    _32951 = NOVALUE;
    _32948 = NOVALUE;

    /** execute.e:1207			tcb[task][TASK_MAX_TIME] = now + s[2]*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65374 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66634 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_s_66636);
    _32954 = (object)*(((s1_ptr)_2)->base + 2LL);
    _32955 = binary_op(PLUS, _now_66635, _32954);
    _32954 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32955;
    if( _1 != _32955 ){
        DeRef(_1);
    }
    _32955 = NOVALUE;
    _32952 = NOVALUE;

    /** execute.e:1209			if tcb[task][TASK_TYPE] = T_TIME_SHARE then*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32956 = (object)*(((s1_ptr)_2)->base + _task_66634);
    _2 = (object)SEQ_PTR(_32956);
    _32957 = (object)*(((s1_ptr)_2)->base + 3LL);
    _32956 = NOVALUE;
    if (binary_op_a(NOTEQ, _32957, 2LL)){
        _32957 = NOVALUE;
        goto L10; // [461] 477
    }
    _32957 = NOVALUE;

    /** execute.e:1210				ts_first = task_delete(ts_first, task)*/
    _0 = _67task_delete(_67ts_first_65378, _task_66634);
    _67ts_first_65378 = _0;
    if (!IS_ATOM_INT(_67ts_first_65378)) {
        _1 = (object)(DBL_PTR(_67ts_first_65378)->dbl);
        DeRefDS(_67ts_first_65378);
        _67ts_first_65378 = _1;
    }
L10: 

    /** execute.e:1212			if tcb[task][TASK_TYPE] = T_TIME_SHARE or*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32960 = (object)*(((s1_ptr)_2)->base + _task_66634);
    _2 = (object)SEQ_PTR(_32960);
    _32961 = (object)*(((s1_ptr)_2)->base + 3LL);
    _32960 = NOVALUE;
    if (IS_ATOM_INT(_32961)) {
        _32962 = (_32961 == 2LL);
    }
    else {
        _32962 = binary_op(EQUALS, _32961, 2LL);
    }
    _32961 = NOVALUE;
    if (IS_ATOM_INT(_32962)) {
        if (_32962 != 0) {
            goto L11; // [493] 516
        }
    }
    else {
        if (DBL_PTR(_32962)->dbl != 0.0) {
            goto L11; // [493] 516
        }
    }
    _2 = (object)SEQ_PTR(_67tcb_65374);
    _32964 = (object)*(((s1_ptr)_2)->base + _task_66634);
    _2 = (object)SEQ_PTR(_32964);
    _32965 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32964 = NOVALUE;
    if (IS_ATOM_INT(_32965)) {
        _32966 = (_32965 == 1LL);
    }
    else {
        _32966 = binary_op(EQUALS, _32965, 1LL);
    }
    _32965 = NOVALUE;
    if (_32966 == 0) {
        DeRef(_32966);
        _32966 = NOVALUE;
        goto L12; // [512] 528
    }
    else {
        if (!IS_ATOM_INT(_32966) && DBL_PTR(_32966)->dbl == 0.0){
            DeRef(_32966);
            _32966 = NOVALUE;
            goto L12; // [512] 528
        }
        DeRef(_32966);
        _32966 = NOVALUE;
    }
    DeRef(_32966);
    _32966 = NOVALUE;
L11: 

    /** execute.e:1214				rt_first = task_insert(rt_first, task)*/
    _0 = _67task_insert(_67rt_first_65377, _task_66634);
    _67rt_first_65377 = _0;
    if (!IS_ATOM_INT(_67rt_first_65377)) {
        _1 = (object)(DBL_PTR(_67rt_first_65377)->dbl);
        DeRefDS(_67rt_first_65377);
        _67rt_first_65377 = _1;
    }
L12: 

    /** execute.e:1216			tcb[task][TASK_TYPE] = T_REAL_TIME*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65374 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66634 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _32968 = NOVALUE;
L6: 

    /** execute.e:1218		tcb[task][TASK_STATE] = ST_ACTIVE*/
    _2 = (object)SEQ_PTR(_67tcb_65374);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65374 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66634 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _32970 = NOVALUE;

    /** execute.e:1219		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:1220	end procedure*/
    DeRef(_now_66635);
    DeRef(_s_66636);
    DeRef(_32899);
    _32899 = NOVALUE;
    DeRef(_32917);
    _32917 = NOVALUE;
    DeRef(_32885);
    _32885 = NOVALUE;
    DeRef(_32962);
    _32962 = NOVALUE;
    DeRef(_32881);
    _32881 = NOVALUE;
    return;
    ;
}


void _67one_trace_line(object _line_66751)
{
    object _32975 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1231		ifdef UNIX then*/

    /** execute.e:1234			printf(trace_file, "%-77.77s\r\n", {line})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_line_66751);
    ((intptr_t*)_2)[1] = _line_66751;
    _32975 = MAKE_SEQ(_1);
    EPrintf(_67trace_file_66747, _32974, _32975);
    DeRefDS(_32975);
    _32975 = NOVALUE;

    /** execute.e:1236	end procedure*/
    DeRefDS(_line_66751);
    return;
    ;
}


void _67opCOVERAGE_LINE()
{
    object _35401 = NOVALUE;
    object _32977 = NOVALUE;
    object _32976 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1239		cover_line( Code[pc+1] )*/
    _32976 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _32977 = (object)*(((s1_ptr)_2)->base + _32976);
    Ref(_32977);
    _35401 = _50cover_line(_32977);
    _32977 = NOVALUE;
    DeRef(_35401);
    _35401 = NOVALUE;

    /** execute.e:1240		pc += 2*/
    _67pc_65330 = _67pc_65330 + 2LL;

    /** execute.e:1241	end procedure*/
    _32976 = NOVALUE;
    return;
    ;
}


void _67opCOVERAGE_ROUTINE()
{
    object _35400 = NOVALUE;
    object _32980 = NOVALUE;
    object _32979 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1244		cover_routine( Code[pc+1] )*/
    _32979 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _32980 = (object)*(((s1_ptr)_2)->base + _32979);
    Ref(_32980);
    _35400 = _50cover_routine(_32980);
    _32980 = NOVALUE;
    DeRef(_35400);
    _35400 = NOVALUE;

    /** execute.e:1245		pc += 2*/
    _67pc_65330 = _67pc_65330 + 2LL;

    /** execute.e:1246	end procedure*/
    _32979 = NOVALUE;
    return;
    ;
}


void _67opSTARTLINE()
{
    object _line_66771 = NOVALUE;
    object _w_66772 = NOVALUE;
    object _33014 = NOVALUE;
    object _33013 = NOVALUE;
    object _33012 = NOVALUE;
    object _33008 = NOVALUE;
    object _33003 = NOVALUE;
    object _33002 = NOVALUE;
    object _33001 = NOVALUE;
    object _33000 = NOVALUE;
    object _32999 = NOVALUE;
    object _32998 = NOVALUE;
    object _32997 = NOVALUE;
    object _32994 = NOVALUE;
    object _32993 = NOVALUE;
    object _32991 = NOVALUE;
    object _32990 = NOVALUE;
    object _32989 = NOVALUE;
    object _32987 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1253		if TraceOn then*/
    if (_67TraceOn_65328 == 0)
    {
        goto L1; // [5] 279
    }
    else{
    }

    /** execute.e:1254			if trace_file = -1 then*/
    if (_67trace_file_66747 != -1LL)
    goto L2; // [12] 40

    /** execute.e:1255				trace_file = open("ctrace.out", "wb")*/
    _67trace_file_66747 = EOpen(_32983, _24089, 0LL);

    /** execute.e:1256				if trace_file = -1 then*/
    if (_67trace_file_66747 != -1LL)
    goto L3; // [29] 39

    /** execute.e:1257					RTFatal("Couldn't open ctrace.out")*/
    RefDS(_32986);
    _67RTFatal(_32986);
L3: 
L2: 

    /** execute.e:1261			a = Code[pc+1]*/
    _32987 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _32987);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:1263			if atom(slist[$]) then*/
    if (IS_SEQUENCE(_27slist_20662)){
            _32989 = SEQ_PTR(_27slist_20662)->length;
    }
    else {
        _32989 = 1;
    }
    _2 = (object)SEQ_PTR(_27slist_20662);
    _32990 = (object)*(((s1_ptr)_2)->base + _32989);
    _32991 = IS_ATOM(_32990);
    _32990 = NOVALUE;
    if (_32991 == 0)
    {
        _32991 = NOVALUE;
        goto L4; // [70] 84
    }
    else{
        _32991 = NOVALUE;
    }

    /** execute.e:1264				slist = s_expand(slist)*/
    RefDS(_27slist_20662);
    _0 = _61s_expand(_27slist_20662);
    DeRefDS(_27slist_20662);
    _27slist_20662 = _0;
L4: 

    /** execute.e:1266			line = fetch_line(slist[a][SRC])*/
    _2 = (object)SEQ_PTR(_27slist_20662);
    _32993 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_32993);
    _32994 = (object)*(((s1_ptr)_2)->base + 1LL);
    _32993 = NOVALUE;
    Ref(_32994);
    _0 = _line_66771;
    _line_66771 = _61fetch_line(_32994);
    DeRef(_0);
    _32994 = NOVALUE;

    /** execute.e:1267			line = sprintf("%s:%d\t%s",*/
    _2 = (object)SEQ_PTR(_27slist_20662);
    _32997 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_32997);
    _32998 = (object)*(((s1_ptr)_2)->base + 3LL);
    _32997 = NOVALUE;
    _2 = (object)SEQ_PTR(_28known_files_11573);
    if (!IS_ATOM_INT(_32998)){
        _32999 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32998)->dbl));
    }
    else{
        _32999 = (object)*(((s1_ptr)_2)->base + _32998);
    }
    Ref(_32999);
    _33000 = _53name_ext(_32999);
    _32999 = NOVALUE;
    _2 = (object)SEQ_PTR(_27slist_20662);
    _33001 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_33001);
    _33002 = (object)*(((s1_ptr)_2)->base + 2LL);
    _33001 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _33000;
    Ref(_33002);
    ((intptr_t*)_2)[2] = _33002;
    RefDS(_line_66771);
    ((intptr_t*)_2)[3] = _line_66771;
    _33003 = MAKE_SEQ(_1);
    _33002 = NOVALUE;
    _33000 = NOVALUE;
    DeRefDS(_line_66771);
    _line_66771 = EPrintf(-9999999, _32996, _33003);
    DeRefDS(_33003);
    _33003 = NOVALUE;

    /** execute.e:1271			trace_line += 1*/
    _67trace_line_66748 = _67trace_line_66748 + 1;

    /** execute.e:1272			if trace_line >= trace_lines then*/
    if (_67trace_line_66748 < _27trace_lines_65059)
    goto L5; // [170] 210

    /** execute.e:1274				trace_line = 0*/
    _67trace_line_66748 = 0LL;

    /** execute.e:1275				one_trace_line("")*/
    RefDS(_22218);
    _67one_trace_line(_22218);

    /** execute.e:1276				one_trace_line("               ")*/
    RefDS(_33007);
    _67one_trace_line(_33007);

    /** execute.e:1277				flush(trace_file)*/
    _18flush(_67trace_file_66747);

    /** execute.e:1278				if seek(trace_file, 0) then*/
    _33008 = _18seek(_67trace_file_66747, 0LL);
    if (_33008 == 0) {
        DeRef(_33008);
        _33008 = NOVALUE;
        goto L6; // [205] 209
    }
    else {
        if (!IS_ATOM_INT(_33008) && DBL_PTR(_33008)->dbl == 0.0){
            DeRef(_33008);
            _33008 = NOVALUE;
            goto L6; // [205] 209
        }
        DeRef(_33008);
        _33008 = NOVALUE;
    }
    DeRef(_33008);
    _33008 = NOVALUE;
L6: 
L5: 

    /** execute.e:1282			one_trace_line(line)*/
    RefDS(_line_66771);
    _67one_trace_line(_line_66771);

    /** execute.e:1283			one_trace_line("")*/
    RefDS(_22218);
    _67one_trace_line(_22218);

    /** execute.e:1284			one_trace_line("=== THE END ===")*/
    RefDS(_33009);
    _67one_trace_line(_33009);

    /** execute.e:1285			one_trace_line("")*/
    RefDS(_22218);
    _67one_trace_line(_22218);

    /** execute.e:1286			one_trace_line("")*/
    RefDS(_22218);
    _67one_trace_line(_22218);

    /** execute.e:1287			one_trace_line("")*/
    RefDS(_22218);
    _67one_trace_line(_22218);

    /** execute.e:1288			flush(trace_file)*/
    _18flush(_67trace_file_66747);

    /** execute.e:1289			w = where(trace_file)*/
    _w_66772 = _18where(_67trace_file_66747);
    if (!IS_ATOM_INT(_w_66772)) {
        _1 = (object)(DBL_PTR(_w_66772)->dbl);
        DeRefDS(_w_66772);
        _w_66772 = _1;
    }

    /** execute.e:1290			if seek(trace_file, w-79*5) then -- back up 5 (fixed-width) lines*/
    _33012 = 395LL;
    _33013 = _w_66772 - 395LL;
    if ((object)((uintptr_t)_33013 +(uintptr_t) HIGH_BITS) >= 0){
        _33013 = NewDouble((eudouble)_33013);
    }
    _33012 = NOVALUE;
    _33014 = _18seek(_67trace_file_66747, _33013);
    _33013 = NOVALUE;
    if (_33014 == 0) {
        DeRef(_33014);
        _33014 = NOVALUE;
        goto L7; // [274] 278
    }
    else {
        if (!IS_ATOM_INT(_33014) && DBL_PTR(_33014)->dbl == 0.0){
            DeRef(_33014);
            _33014 = NOVALUE;
            goto L7; // [274] 278
        }
        DeRef(_33014);
        _33014 = NOVALUE;
    }
    DeRef(_33014);
    _33014 = NOVALUE;
L7: 
L1: 

    /** execute.e:1293		pc += 2*/
    _67pc_65330 = _67pc_65330 + 2LL;

    /** execute.e:1294	end procedure*/
    DeRef(_line_66771);
    DeRef(_32987);
    _32987 = NOVALUE;
    _32998 = NOVALUE;
    return;
    ;
}


void _67opPROC_TAIL()
{
    object _arg_66836 = NOVALUE;
    object _sub_66837 = NOVALUE;
    object _33032 = NOVALUE;
    object _33031 = NOVALUE;
    object _33030 = NOVALUE;
    object _33029 = NOVALUE;
    object _33028 = NOVALUE;
    object _33026 = NOVALUE;
    object _33025 = NOVALUE;
    object _33024 = NOVALUE;
    object _33023 = NOVALUE;
    object _33022 = NOVALUE;
    object _33021 = NOVALUE;
    object _33020 = NOVALUE;
    object _33018 = NOVALUE;
    object _33016 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1299		sub = Code[pc+1] -- subroutine*/
    _33016 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _sub_66837 = (object)*(((s1_ptr)_2)->base + _33016);
    if (!IS_ATOM_INT(_sub_66837)){
        _sub_66837 = (object)DBL_PTR(_sub_66837)->dbl;
    }

    /** execute.e:1300		arg = SymTab[sub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33018 = (object)*(((s1_ptr)_2)->base + _sub_66837);
    _2 = (object)SEQ_PTR(_33018);
    _arg_66836 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_arg_66836)){
        _arg_66836 = (object)DBL_PTR(_arg_66836)->dbl;
    }
    _33018 = NOVALUE;

    /** execute.e:1303		for i = 1 to SymTab[sub][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33020 = (object)*(((s1_ptr)_2)->base + _sub_66837);
    _2 = (object)SEQ_PTR(_33020);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _33021 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _33021 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _33020 = NOVALUE;
    {
        object _i_66846;
        _i_66846 = 1LL;
L1: 
        if (binary_op_a(GREATER, _i_66846, _33021)){
            goto L2; // [47] 107
        }

        /** execute.e:1304			val[arg] = val[Code[pc+1+i]]*/
        _33022 = _67pc_65330 + 1;
        if (_33022 > MAXINT){
            _33022 = NewDouble((eudouble)_33022);
        }
        if (IS_ATOM_INT(_33022) && IS_ATOM_INT(_i_66846)) {
            _33023 = _33022 + _i_66846;
        }
        else {
            if (IS_ATOM_INT(_33022)) {
                _33023 = NewDouble((eudouble)_33022 + DBL_PTR(_i_66846)->dbl);
            }
            else {
                if (IS_ATOM_INT(_i_66846)) {
                    _33023 = NewDouble(DBL_PTR(_33022)->dbl + (eudouble)_i_66846);
                }
                else
                _33023 = NewDouble(DBL_PTR(_33022)->dbl + DBL_PTR(_i_66846)->dbl);
            }
        }
        DeRef(_33022);
        _33022 = NOVALUE;
        _2 = (object)SEQ_PTR(_27Code_20660);
        if (!IS_ATOM_INT(_33023)){
            _33024 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33023)->dbl));
        }
        else{
            _33024 = (object)*(((s1_ptr)_2)->base + _33023);
        }
        _2 = (object)SEQ_PTR(_67val_65340);
        if (!IS_ATOM_INT(_33024)){
            _33025 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33024)->dbl));
        }
        else{
            _33025 = (object)*(((s1_ptr)_2)->base + _33024);
        }
        Ref(_33025);
        _2 = (object)SEQ_PTR(_67val_65340);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_65340 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _arg_66836);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _33025;
        if( _1 != _33025 ){
            DeRef(_1);
        }
        _33025 = NOVALUE;

        /** execute.e:1305			arg = SymTab[arg][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _33026 = (object)*(((s1_ptr)_2)->base + _arg_66836);
        _2 = (object)SEQ_PTR(_33026);
        _arg_66836 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_arg_66836)){
            _arg_66836 = (object)DBL_PTR(_arg_66836)->dbl;
        }
        _33026 = NOVALUE;

        /** execute.e:1306		end for*/
        _0 = _i_66846;
        if (IS_ATOM_INT(_i_66846)) {
            _i_66846 = _i_66846 + 1LL;
            if ((object)((uintptr_t)_i_66846 +(uintptr_t) HIGH_BITS) >= 0){
                _i_66846 = NewDouble((eudouble)_i_66846);
            }
        }
        else {
            _i_66846 = binary_op_a(PLUS, _i_66846, 1LL);
        }
        DeRef(_0);
        goto L1; // [102] 54
L2: 
        ;
        DeRef(_i_66846);
    }

    /** execute.e:1309		while arg and SymTab[arg][S_SCOPE] <= SC_PRIVATE do*/
L3: 
    if (_arg_66836 == 0) {
        goto L4; // [112] 169
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33029 = (object)*(((s1_ptr)_2)->base + _arg_66836);
    _2 = (object)SEQ_PTR(_33029);
    _33030 = (object)*(((s1_ptr)_2)->base + 4LL);
    _33029 = NOVALUE;
    if (IS_ATOM_INT(_33030)) {
        _33031 = (_33030 <= 3LL);
    }
    else {
        _33031 = binary_op(LESSEQ, _33030, 3LL);
    }
    _33030 = NOVALUE;
    if (_33031 <= 0) {
        if (_33031 == 0) {
            DeRef(_33031);
            _33031 = NOVALUE;
            goto L4; // [135] 169
        }
        else {
            if (!IS_ATOM_INT(_33031) && DBL_PTR(_33031)->dbl == 0.0){
                DeRef(_33031);
                _33031 = NOVALUE;
                goto L4; // [135] 169
            }
            DeRef(_33031);
            _33031 = NOVALUE;
        }
    }
    DeRef(_33031);
    _33031 = NOVALUE;

    /** execute.e:1310			val[arg] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _arg_66836);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);

    /** execute.e:1311			arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33032 = (object)*(((s1_ptr)_2)->base + _arg_66836);
    _2 = (object)SEQ_PTR(_33032);
    _arg_66836 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_arg_66836)){
        _arg_66836 = (object)DBL_PTR(_arg_66836)->dbl;
    }
    _33032 = NOVALUE;

    /** execute.e:1312		end while*/
    goto L3; // [166] 112
L4: 

    /** execute.e:1315		pc = 1*/
    _67pc_65330 = 1LL;

    /** execute.e:1316	end procedure*/
    DeRef(_33023);
    _33023 = NOVALUE;
    _33024 = NOVALUE;
    DeRef(_33016);
    _33016 = NOVALUE;
    _33021 = NOVALUE;
    return;
    ;
}


void _67opPROC()
{
    object _n_66875 = NOVALUE;
    object _arg_66876 = NOVALUE;
    object _sub_66877 = NOVALUE;
    object _p_66878 = NOVALUE;
    object _private_block_66879 = NOVALUE;
    object _33099 = NOVALUE;
    object _33094 = NOVALUE;
    object _33093 = NOVALUE;
    object _33091 = NOVALUE;
    object _33089 = NOVALUE;
    object _33087 = NOVALUE;
    object _33086 = NOVALUE;
    object _33085 = NOVALUE;
    object _33084 = NOVALUE;
    object _33083 = NOVALUE;
    object _33082 = NOVALUE;
    object _33080 = NOVALUE;
    object _33078 = NOVALUE;
    object _33075 = NOVALUE;
    object _33073 = NOVALUE;
    object _33071 = NOVALUE;
    object _33069 = NOVALUE;
    object _33068 = NOVALUE;
    object _33067 = NOVALUE;
    object _33066 = NOVALUE;
    object _33065 = NOVALUE;
    object _33064 = NOVALUE;
    object _33063 = NOVALUE;
    object _33062 = NOVALUE;
    object _33061 = NOVALUE;
    object _33060 = NOVALUE;
    object _33059 = NOVALUE;
    object _33058 = NOVALUE;
    object _33057 = NOVALUE;
    object _33056 = NOVALUE;
    object _33055 = NOVALUE;
    object _33053 = NOVALUE;
    object _33052 = NOVALUE;
    object _33051 = NOVALUE;
    object _33050 = NOVALUE;
    object _33049 = NOVALUE;
    object _33047 = NOVALUE;
    object _33046 = NOVALUE;
    object _33044 = NOVALUE;
    object _33043 = NOVALUE;
    object _33041 = NOVALUE;
    object _33040 = NOVALUE;
    object _33038 = NOVALUE;
    object _33036 = NOVALUE;
    object _33034 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1324		sub = Code[pc+1] -- subroutine*/
    _33034 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _sub_66877 = (object)*(((s1_ptr)_2)->base + _33034);
    if (!IS_ATOM_INT(_sub_66877)){
        _sub_66877 = (object)DBL_PTR(_sub_66877)->dbl;
    }

    /** execute.e:1325		arg = SymTab[sub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33036 = (object)*(((s1_ptr)_2)->base + _sub_66877);
    _2 = (object)SEQ_PTR(_33036);
    _arg_66876 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_arg_66876)){
        _arg_66876 = (object)DBL_PTR(_arg_66876)->dbl;
    }
    _33036 = NOVALUE;

    /** execute.e:1327		n = SymTab[sub][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33038 = (object)*(((s1_ptr)_2)->base + _sub_66877);
    _2 = (object)SEQ_PTR(_33038);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _n_66875 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _n_66875 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    if (!IS_ATOM_INT(_n_66875)){
        _n_66875 = (object)DBL_PTR(_n_66875)->dbl;
    }
    _33038 = NOVALUE;

    /** execute.e:1329		if SymTab[sub][S_RESIDENT_TASK] != 0 then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33040 = (object)*(((s1_ptr)_2)->base + _sub_66877);
    _2 = (object)SEQ_PTR(_33040);
    _33041 = (object)*(((s1_ptr)_2)->base + 25LL);
    _33040 = NOVALUE;
    if (binary_op_a(EQUALS, _33041, 0LL)){
        _33041 = NOVALUE;
        goto L1; // [63] 413
    }
    _33041 = NOVALUE;

    /** execute.e:1333			private_block = repeat(0, SymTab[sub][S_STACK_SPACE])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33043 = (object)*(((s1_ptr)_2)->base + _sub_66877);
    _2 = (object)SEQ_PTR(_33043);
    if (!IS_ATOM_INT(_27S_STACK_SPACE_20269)){
        _33044 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_STACK_SPACE_20269)->dbl));
    }
    else{
        _33044 = (object)*(((s1_ptr)_2)->base + _27S_STACK_SPACE_20269);
    }
    _33043 = NOVALUE;
    DeRef(_private_block_66879);
    _private_block_66879 = Repeat(0LL, _33044);
    _33044 = NOVALUE;

    /** execute.e:1334			p = 1*/
    _p_66878 = 1LL;

    /** execute.e:1335			for i = 1 to n do*/
    _33046 = _n_66875;
    {
        object _i_66903;
        _i_66903 = 1LL;
L2: 
        if (_i_66903 > _33046){
            goto L3; // [95] 173
        }

        /** execute.e:1336				private_block[p] = val[arg]*/
        _2 = (object)SEQ_PTR(_67val_65340);
        _33047 = (object)*(((s1_ptr)_2)->base + _arg_66876);
        Ref(_33047);
        _2 = (object)SEQ_PTR(_private_block_66879);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _private_block_66879 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _p_66878);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _33047;
        if( _1 != _33047 ){
            DeRef(_1);
        }
        _33047 = NOVALUE;

        /** execute.e:1337				p += 1*/
        _p_66878 = _p_66878 + 1;

        /** execute.e:1338				val[arg] = val[Code[pc+1+i]]*/
        _33049 = _67pc_65330 + 1;
        if (_33049 > MAXINT){
            _33049 = NewDouble((eudouble)_33049);
        }
        if (IS_ATOM_INT(_33049)) {
            _33050 = _33049 + _i_66903;
        }
        else {
            _33050 = NewDouble(DBL_PTR(_33049)->dbl + (eudouble)_i_66903);
        }
        DeRef(_33049);
        _33049 = NOVALUE;
        _2 = (object)SEQ_PTR(_27Code_20660);
        if (!IS_ATOM_INT(_33050)){
            _33051 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33050)->dbl));
        }
        else{
            _33051 = (object)*(((s1_ptr)_2)->base + _33050);
        }
        _2 = (object)SEQ_PTR(_67val_65340);
        if (!IS_ATOM_INT(_33051)){
            _33052 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33051)->dbl));
        }
        else{
            _33052 = (object)*(((s1_ptr)_2)->base + _33051);
        }
        Ref(_33052);
        _2 = (object)SEQ_PTR(_67val_65340);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_65340 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _arg_66876);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _33052;
        if( _1 != _33052 ){
            DeRef(_1);
        }
        _33052 = NOVALUE;

        /** execute.e:1339				arg = SymTab[arg][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _33053 = (object)*(((s1_ptr)_2)->base + _arg_66876);
        _2 = (object)SEQ_PTR(_33053);
        _arg_66876 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_arg_66876)){
            _arg_66876 = (object)DBL_PTR(_arg_66876)->dbl;
        }
        _33053 = NOVALUE;

        /** execute.e:1340			end for*/
        _i_66903 = _i_66903 + 1LL;
        goto L2; // [168] 102
L3: 
        ;
    }

    /** execute.e:1343			while arg != 0 */
L4: 
    _33055 = (_arg_66876 != 0LL);
    if (_33055 == 0) {
        goto L5; // [182] 330
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33057 = (object)*(((s1_ptr)_2)->base + _arg_66876);
    _2 = (object)SEQ_PTR(_33057);
    _33058 = (object)*(((s1_ptr)_2)->base + 4LL);
    _33057 = NOVALUE;
    if (IS_ATOM_INT(_33058)) {
        _33059 = (_33058 <= 3LL);
    }
    else {
        _33059 = binary_op(LESSEQ, _33058, 3LL);
    }
    _33058 = NOVALUE;
    if (IS_ATOM_INT(_33059)) {
        if (_33059 != 0) {
            DeRef(_33060);
            _33060 = 1;
            goto L6; // [204] 230
        }
    }
    else {
        if (DBL_PTR(_33059)->dbl != 0.0) {
            DeRef(_33060);
            _33060 = 1;
            goto L6; // [204] 230
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33061 = (object)*(((s1_ptr)_2)->base + _arg_66876);
    _2 = (object)SEQ_PTR(_33061);
    _33062 = (object)*(((s1_ptr)_2)->base + 4LL);
    _33061 = NOVALUE;
    if (IS_ATOM_INT(_33062)) {
        _33063 = (_33062 == 2LL);
    }
    else {
        _33063 = binary_op(EQUALS, _33062, 2LL);
    }
    _33062 = NOVALUE;
    DeRef(_33060);
    if (IS_ATOM_INT(_33063))
    _33060 = (_33063 != 0);
    else
    _33060 = DBL_PTR(_33063)->dbl != 0.0;
L6: 
    if (_33060 != 0) {
        DeRef(_33064);
        _33064 = 1;
        goto L7; // [230] 256
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33065 = (object)*(((s1_ptr)_2)->base + _arg_66876);
    _2 = (object)SEQ_PTR(_33065);
    _33066 = (object)*(((s1_ptr)_2)->base + 4LL);
    _33065 = NOVALUE;
    if (IS_ATOM_INT(_33066)) {
        _33067 = (_33066 == 9LL);
    }
    else {
        _33067 = binary_op(EQUALS, _33066, 9LL);
    }
    _33066 = NOVALUE;
    if (IS_ATOM_INT(_33067))
    _33064 = (_33067 != 0);
    else
    _33064 = DBL_PTR(_33067)->dbl != 0.0;
L7: 
    if (_33064 == 0)
    {
        _33064 = NOVALUE;
        goto L5; // [257] 330
    }
    else{
        _33064 = NOVALUE;
    }

    /** execute.e:1348				if SymTab[arg][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33068 = (object)*(((s1_ptr)_2)->base + _arg_66876);
    _2 = (object)SEQ_PTR(_33068);
    _33069 = (object)*(((s1_ptr)_2)->base + 4LL);
    _33068 = NOVALUE;
    if (binary_op_a(EQUALS, _33069, 9LL)){
        _33069 = NOVALUE;
        goto L8; // [276] 309
    }
    _33069 = NOVALUE;

    /** execute.e:1349					private_block[p] = val[arg]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33071 = (object)*(((s1_ptr)_2)->base + _arg_66876);
    Ref(_33071);
    _2 = (object)SEQ_PTR(_private_block_66879);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _private_block_66879 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _p_66878);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33071;
    if( _1 != _33071 ){
        DeRef(_1);
    }
    _33071 = NOVALUE;

    /** execute.e:1350					p += 1*/
    _p_66878 = _p_66878 + 1;

    /** execute.e:1351					val[arg] = NOVALUE  -- necessary?*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _arg_66876);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
L8: 

    /** execute.e:1353				arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33073 = (object)*(((s1_ptr)_2)->base + _arg_66876);
    _2 = (object)SEQ_PTR(_33073);
    _arg_66876 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_arg_66876)){
        _arg_66876 = (object)DBL_PTR(_arg_66876)->dbl;
    }
    _33073 = NOVALUE;

    /** execute.e:1354			end while*/
    goto L4; // [327] 178
L5: 

    /** execute.e:1357			arg = SymTab[sub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33075 = (object)*(((s1_ptr)_2)->base + _sub_66877);
    _2 = (object)SEQ_PTR(_33075);
    if (!IS_ATOM_INT(_27S_TEMPS_20254)){
        _arg_66876 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TEMPS_20254)->dbl));
    }
    else{
        _arg_66876 = (object)*(((s1_ptr)_2)->base + _27S_TEMPS_20254);
    }
    if (!IS_ATOM_INT(_arg_66876)){
        _arg_66876 = (object)DBL_PTR(_arg_66876)->dbl;
    }
    _33075 = NOVALUE;

    /** execute.e:1358			while arg != 0 do*/
L9: 
    if (_arg_66876 == 0LL)
    goto LA; // [351] 404

    /** execute.e:1359				private_block[p] = val[arg]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33078 = (object)*(((s1_ptr)_2)->base + _arg_66876);
    Ref(_33078);
    _2 = (object)SEQ_PTR(_private_block_66879);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _private_block_66879 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _p_66878);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33078;
    if( _1 != _33078 ){
        DeRef(_1);
    }
    _33078 = NOVALUE;

    /** execute.e:1360				p += 1*/
    _p_66878 = _p_66878 + 1;

    /** execute.e:1361				val[arg] = NOVALUE -- necessary?*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _arg_66876);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);

    /** execute.e:1362				arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33080 = (object)*(((s1_ptr)_2)->base + _arg_66876);
    _2 = (object)SEQ_PTR(_33080);
    _arg_66876 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_arg_66876)){
        _arg_66876 = (object)DBL_PTR(_arg_66876)->dbl;
    }
    _33080 = NOVALUE;

    /** execute.e:1363			end while*/
    goto L9; // [401] 351
LA: 

    /** execute.e:1366			save_private_block(sub, private_block)*/
    RefDS(_private_block_66879);
    _67save_private_block(_sub_66877, _private_block_66879);
    goto LB; // [410] 479
L1: 

    /** execute.e:1370			for i = 1 to n do*/
    _33082 = _n_66875;
    {
        object _i_66968;
        _i_66968 = 1LL;
LC: 
        if (_i_66968 > _33082){
            goto LD; // [418] 478
        }

        /** execute.e:1371				val[arg] = val[Code[pc+1+i]]*/
        _33083 = _67pc_65330 + 1;
        if (_33083 > MAXINT){
            _33083 = NewDouble((eudouble)_33083);
        }
        if (IS_ATOM_INT(_33083)) {
            _33084 = _33083 + _i_66968;
        }
        else {
            _33084 = NewDouble(DBL_PTR(_33083)->dbl + (eudouble)_i_66968);
        }
        DeRef(_33083);
        _33083 = NOVALUE;
        _2 = (object)SEQ_PTR(_27Code_20660);
        if (!IS_ATOM_INT(_33084)){
            _33085 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33084)->dbl));
        }
        else{
            _33085 = (object)*(((s1_ptr)_2)->base + _33084);
        }
        _2 = (object)SEQ_PTR(_67val_65340);
        if (!IS_ATOM_INT(_33085)){
            _33086 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33085)->dbl));
        }
        else{
            _33086 = (object)*(((s1_ptr)_2)->base + _33085);
        }
        Ref(_33086);
        _2 = (object)SEQ_PTR(_67val_65340);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_65340 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _arg_66876);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _33086;
        if( _1 != _33086 ){
            DeRef(_1);
        }
        _33086 = NOVALUE;

        /** execute.e:1372				arg = SymTab[arg][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _33087 = (object)*(((s1_ptr)_2)->base + _arg_66876);
        _2 = (object)SEQ_PTR(_33087);
        _arg_66876 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_arg_66876)){
            _arg_66876 = (object)DBL_PTR(_arg_66876)->dbl;
        }
        _33087 = NOVALUE;

        /** execute.e:1373			end for*/
        _i_66968 = _i_66968 + 1LL;
        goto LC; // [473] 425
LD: 
        ;
    }
LB: 

    /** execute.e:1376		SymTab[sub][S_RESIDENT_TASK] = current_task*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sub_66877 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67current_task_65347;
    DeRef(_1);
    _33089 = NOVALUE;

    /** execute.e:1378		pc = pc + 2 + n*/
    _33091 = _67pc_65330 + 2LL;
    if ((object)((uintptr_t)_33091 + (uintptr_t)HIGH_BITS) >= 0){
        _33091 = NewDouble((eudouble)_33091);
    }
    if (IS_ATOM_INT(_33091)) {
        _67pc_65330 = _33091 + _n_66875;
    }
    else {
        _67pc_65330 = NewDouble(DBL_PTR(_33091)->dbl + (eudouble)_n_66875);
    }
    DeRef(_33091);
    _33091 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_65330)) {
        _1 = (object)(DBL_PTR(_67pc_65330)->dbl);
        DeRefDS(_67pc_65330);
        _67pc_65330 = _1;
    }

    /** execute.e:1379		if SymTab[sub][S_TOKEN] != PROC then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33093 = (object)*(((s1_ptr)_2)->base + _sub_66877);
    _2 = (object)SEQ_PTR(_33093);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _33094 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _33094 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _33093 = NOVALUE;
    if (binary_op_a(EQUALS, _33094, 27LL)){
        _33094 = NOVALUE;
        goto LE; // [526] 539
    }
    _33094 = NOVALUE;

    /** execute.e:1380			pc += 1*/
    _67pc_65330 = _67pc_65330 + 1;
LE: 

    /** execute.e:1383		call_stack = append(call_stack, pc)*/
    Append(&_67call_stack_65348, _67call_stack_65348, _67pc_65330);

    /** execute.e:1384		call_stack = append(call_stack, sub)*/
    Append(&_67call_stack_65348, _67call_stack_65348, _sub_66877);

    /** execute.e:1386		Code = SymTab[sub][S_CODE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33099 = (object)*(((s1_ptr)_2)->base + _sub_66877);
    DeRef(_27Code_20660);
    _2 = (object)SEQ_PTR(_33099);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    Ref(_27Code_20660);
    _33099 = NOVALUE;

    /** execute.e:1387		pc = 1*/
    _67pc_65330 = 1LL;

    /** execute.e:1388	end procedure*/
    DeRef(_private_block_66879);
    DeRef(_33059);
    _33059 = NOVALUE;
    DeRef(_33063);
    _33063 = NOVALUE;
    DeRef(_33067);
    _33067 = NOVALUE;
    _33051 = NOVALUE;
    DeRef(_33055);
    _33055 = NOVALUE;
    DeRef(_33084);
    _33084 = NOVALUE;
    DeRef(_33034);
    _33034 = NOVALUE;
    _33085 = NOVALUE;
    DeRef(_33050);
    _33050 = NOVALUE;
    return;
    ;
}


void _67exit_block(object _block_67005)
{
    object _a_67006 = NOVALUE;
    object _33104 = NOVALUE;
    object _33101 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_block_67005)) {
        _1 = (object)(DBL_PTR(_block_67005)->dbl);
        DeRefDS(_block_67005);
        _block_67005 = _1;
    }

    /** execute.e:1395		integer a = SymTab[block][S_NEXT_IN_BLOCK]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33101 = (object)*(((s1_ptr)_2)->base + _block_67005);
    _2 = (object)SEQ_PTR(_33101);
    if (!IS_ATOM_INT(_27S_NEXT_IN_BLOCK_20201)){
        _a_67006 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NEXT_IN_BLOCK_20201)->dbl));
    }
    else{
        _a_67006 = (object)*(((s1_ptr)_2)->base + _27S_NEXT_IN_BLOCK_20201);
    }
    if (!IS_ATOM_INT(_a_67006)){
        _a_67006 = (object)DBL_PTR(_a_67006)->dbl;
    }
    _33101 = NOVALUE;

    /** execute.e:1396		while a do*/
L1: 
    if (_a_67006 == 0)
    {
        goto L2; // [24] 60
    }
    else{
    }

    /** execute.e:1398			ifdef DEBUG then*/

    /** execute.e:1407			val[a] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _a_67006);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);

    /** execute.e:1409			a = SymTab[a][S_NEXT_IN_BLOCK]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33104 = (object)*(((s1_ptr)_2)->base + _a_67006);
    _2 = (object)SEQ_PTR(_33104);
    if (!IS_ATOM_INT(_27S_NEXT_IN_BLOCK_20201)){
        _a_67006 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NEXT_IN_BLOCK_20201)->dbl));
    }
    else{
        _a_67006 = (object)*(((s1_ptr)_2)->base + _27S_NEXT_IN_BLOCK_20201);
    }
    if (!IS_ATOM_INT(_a_67006)){
        _a_67006 = (object)DBL_PTR(_a_67006)->dbl;
    }
    _33104 = NOVALUE;

    /** execute.e:1410		end while*/
    goto L1; // [57] 24
L2: 

    /** execute.e:1411	end procedure*/
    return;
    ;
}


void _67opEXIT_BLOCK()
{
    object _33107 = NOVALUE;
    object _33106 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1414		exit_block( Code[pc+1] )*/
    _33106 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33107 = (object)*(((s1_ptr)_2)->base + _33106);
    Ref(_33107);
    _67exit_block(_33107);
    _33107 = NOVALUE;

    /** execute.e:1415		pc += 2*/
    _67pc_65330 = _67pc_65330 + 2LL;

    /** execute.e:1416	end procedure*/
    _33106 = NOVALUE;
    return;
    ;
}


void _67opRETURNP()
{
    object _arg_67027 = NOVALUE;
    object _sub_67028 = NOVALUE;
    object _caller_67029 = NOVALUE;
    object _op_67030 = NOVALUE;
    object _block_67037 = NOVALUE;
    object _sub_block_67042 = NOVALUE;
    object _local_result_67047 = NOVALUE;
    object _local_result_val_67048 = NOVALUE;
    object _33132 = NOVALUE;
    object _33130 = NOVALUE;
    object _33128 = NOVALUE;
    object _33127 = NOVALUE;
    object _33125 = NOVALUE;
    object _33123 = NOVALUE;
    object _33122 = NOVALUE;
    object _33120 = NOVALUE;
    object _33119 = NOVALUE;
    object _33117 = NOVALUE;
    object _33114 = NOVALUE;
    object _33112 = NOVALUE;
    object _33110 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1421		integer op = Code[pc]*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    _op_67030 = (object)*(((s1_ptr)_2)->base + _67pc_65330);
    if (!IS_ATOM_INT(_op_67030)){
        _op_67030 = (object)DBL_PTR(_op_67030)->dbl;
    }

    /** execute.e:1422		sub = Code[pc+1]*/
    _33110 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _sub_67028 = (object)*(((s1_ptr)_2)->base + _33110);
    if (!IS_ATOM_INT(_sub_67028)){
        _sub_67028 = (object)DBL_PTR(_sub_67028)->dbl;
    }

    /** execute.e:1425		symtab_index block = Code[pc+2]*/
    _33112 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _block_67037 = (object)*(((s1_ptr)_2)->base + _33112);
    if (!IS_ATOM_INT(_block_67037)){
        _block_67037 = (object)DBL_PTR(_block_67037)->dbl;
    }

    /** execute.e:1426		symtab_index sub_block = SymTab[sub][S_BLOCK]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33114 = (object)*(((s1_ptr)_2)->base + _sub_67028);
    _2 = (object)SEQ_PTR(_33114);
    if (!IS_ATOM_INT(_27S_BLOCK_20229)){
        _sub_block_67042 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_BLOCK_20229)->dbl));
    }
    else{
        _sub_block_67042 = (object)*(((s1_ptr)_2)->base + _27S_BLOCK_20229);
    }
    if (!IS_ATOM_INT(_sub_block_67042)){
        _sub_block_67042 = (object)DBL_PTR(_sub_block_67042)->dbl;
    }
    _33114 = NOVALUE;

    /** execute.e:1428		integer local_result = result*/
    _local_result_67047 = _67result_67000;

    /** execute.e:1429		object local_result_val*/

    /** execute.e:1430		if local_result then*/
    if (_local_result_67047 == 0)
    {
        goto L1; // [72] 95
    }
    else{
    }

    /** execute.e:1431			result = 0*/
    _67result_67000 = 0LL;

    /** execute.e:1432			local_result_val = result_val*/
    Ref(_67result_val_67001);
    DeRef(_local_result_val_67048);
    _local_result_val_67048 = _67result_val_67001;

    /** execute.e:1433			result_val = NOVALUE*/
    Ref(_27NOVALUE_20426);
    DeRef(_67result_val_67001);
    _67result_val_67001 = _27NOVALUE_20426;
L1: 

    /** execute.e:1436		while block != sub_block do*/
L2: 
    if (_block_67037 == _sub_block_67042)
    goto L3; // [100] 136

    /** execute.e:1437			if local_result then*/
    if (_local_result_67047 == 0)
    {
        goto L4; // [106] 115
    }
    else{
    }

    /** execute.e:1438				exit_block( block )*/
    _67exit_block(_block_67037);
L4: 

    /** execute.e:1440			block = SymTab[block][S_BLOCK]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33117 = (object)*(((s1_ptr)_2)->base + _block_67037);
    _2 = (object)SEQ_PTR(_33117);
    if (!IS_ATOM_INT(_27S_BLOCK_20229)){
        _block_67037 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_BLOCK_20229)->dbl));
    }
    else{
        _block_67037 = (object)*(((s1_ptr)_2)->base + _27S_BLOCK_20229);
    }
    if (!IS_ATOM_INT(_block_67037)){
        _block_67037 = (object)DBL_PTR(_block_67037)->dbl;
    }
    _33117 = NOVALUE;

    /** execute.e:1441		end while*/
    goto L2; // [133] 100
L3: 

    /** execute.e:1443		exit_block( sub_block )*/
    _67exit_block(_sub_block_67042);

    /** execute.e:1451		pc = call_stack[$-1]*/
    if (IS_SEQUENCE(_67call_stack_65348)){
            _33119 = SEQ_PTR(_67call_stack_65348)->length;
    }
    else {
        _33119 = 1;
    }
    _33120 = _33119 - 1LL;
    _33119 = NOVALUE;
    _2 = (object)SEQ_PTR(_67call_stack_65348);
    _67pc_65330 = (object)*(((s1_ptr)_2)->base + _33120);
    if (!IS_ATOM_INT(_67pc_65330))
    _67pc_65330 = (object)DBL_PTR(_67pc_65330)->dbl;

    /** execute.e:1452		call_stack = call_stack[1..$-2]*/
    if (IS_SEQUENCE(_67call_stack_65348)){
            _33122 = SEQ_PTR(_67call_stack_65348)->length;
    }
    else {
        _33122 = 1;
    }
    _33123 = _33122 - 2LL;
    _33122 = NOVALUE;
    rhs_slice_target = (object_ptr)&_67call_stack_65348;
    RHS_Slice(_67call_stack_65348, 1LL, _33123);

    /** execute.e:1454		SymTab[sub][S_RESIDENT_TASK] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sub_67028 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _33125 = NOVALUE;

    /** execute.e:1456		if length(call_stack) then*/
    if (IS_SEQUENCE(_67call_stack_65348)){
            _33127 = SEQ_PTR(_67call_stack_65348)->length;
    }
    else {
        _33127 = 1;
    }
    if (_33127 == 0)
    {
        _33127 = NOVALUE;
        goto L5; // [194] 256
    }
    else{
        _33127 = NOVALUE;
    }

    /** execute.e:1457			caller = call_stack[$]*/
    if (IS_SEQUENCE(_67call_stack_65348)){
            _33128 = SEQ_PTR(_67call_stack_65348)->length;
    }
    else {
        _33128 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_65348);
    _caller_67029 = (object)*(((s1_ptr)_2)->base + _33128);
    if (!IS_ATOM_INT(_caller_67029)){
        _caller_67029 = (object)DBL_PTR(_caller_67029)->dbl;
    }

    /** execute.e:1458			Code = SymTab[caller][S_CODE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33130 = (object)*(((s1_ptr)_2)->base + _caller_67029);
    DeRef(_27Code_20660);
    _2 = (object)SEQ_PTR(_33130);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    Ref(_27Code_20660);
    _33130 = NOVALUE;

    /** execute.e:1459			restore_privates(caller)*/
    _67restore_privates(_caller_67029);

    /** execute.e:1460			if local_result then*/
    if (_local_result_67047 == 0)
    {
        goto L6; // [233] 268
    }
    else{
    }

    /** execute.e:1461				val[Code[local_result]] = local_result_val*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33132 = (object)*(((s1_ptr)_2)->base + _local_result_67047);
    Ref(_local_result_val_67048);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33132))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33132)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33132);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _local_result_val_67048;
    DeRef(_1);
    goto L6; // [253] 268
L5: 

    /** execute.e:1464			kill_task(current_task)*/
    _67kill_task(_67current_task_65347);

    /** execute.e:1465			scheduler()*/
    _67scheduler();
L6: 

    /** execute.e:1469	end procedure*/
    DeRef(_local_result_val_67048);
    _33132 = NOVALUE;
    DeRef(_33110);
    _33110 = NOVALUE;
    DeRef(_33123);
    _33123 = NOVALUE;
    DeRef(_33120);
    _33120 = NOVALUE;
    DeRef(_33112);
    _33112 = NOVALUE;
    return;
    ;
}


void _67opRETURNF()
{
    object _33138 = NOVALUE;
    object _33137 = NOVALUE;
    object _33136 = NOVALUE;
    object _33134 = NOVALUE;
    object _33133 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1473		result_val = val[Code[pc+3]]*/
    _33133 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33134 = (object)*(((s1_ptr)_2)->base + _33133);
    DeRef(_67result_val_67001);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!IS_ATOM_INT(_33134)){
        _67result_val_67001 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33134)->dbl));
    }
    else{
        _67result_val_67001 = (object)*(((s1_ptr)_2)->base + _33134);
    }
    Ref(_67result_val_67001);

    /** execute.e:1474		result = call_stack[$-1] - 1*/
    if (IS_SEQUENCE(_67call_stack_65348)){
            _33136 = SEQ_PTR(_67call_stack_65348)->length;
    }
    else {
        _33136 = 1;
    }
    _33137 = _33136 - 1LL;
    _33136 = NOVALUE;
    _2 = (object)SEQ_PTR(_67call_stack_65348);
    _33138 = (object)*(((s1_ptr)_2)->base + _33137);
    if (IS_ATOM_INT(_33138)) {
        _67result_67000 = _33138 - 1LL;
    }
    else {
        _67result_67000 = binary_op(MINUS, _33138, 1LL);
    }
    _33138 = NOVALUE;
    if (!IS_ATOM_INT(_67result_67000)) {
        _1 = (object)(DBL_PTR(_67result_67000)->dbl);
        DeRefDS(_67result_67000);
        _67result_67000 = _1;
    }

    /** execute.e:1475		opRETURNP()*/
    _67opRETURNP();

    /** execute.e:1476	end procedure*/
    _33133 = NOVALUE;
    _33134 = NOVALUE;
    _33137 = NOVALUE;
    return;
    ;
}


void _67opCALL_BACK_RETURN()
{
    object _0, _1, _2;
    

    /** execute.e:1480		keep_running = FALSE*/
    _67keep_running_65337 = _9FALSE_439;

    /** execute.e:1481	end procedure*/
    return;
    ;
}


void _67opBADRETURNF()
{
    object _0, _1, _2;
    

    /** execute.e:1485		RTFatal("attempt to exit a function without returning a value")*/
    RefDS(_33140);
    _67RTFatal(_33140);

    /** execute.e:1486	end procedure*/
    return;
    ;
}


void _67opRETURNT()
{
    object _33142 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1490		pc += 1*/
    _67pc_65330 = _67pc_65330 + 1;

    /** execute.e:1491		if pc > length(Code) then*/
    if (IS_SEQUENCE(_27Code_20660)){
            _33142 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _33142 = 1;
    }
    if (_67pc_65330 <= _33142)
    goto L1; // [18] 32

    /** execute.e:1492			keep_running = FALSE  -- we've reached the end of the code*/
    _67keep_running_65337 = _9FALSE_439;
L1: 

    /** execute.e:1494	end procedure*/
    return;
    ;
}


void _67opRHS_SUBS()
{
    object _sub_67107 = NOVALUE;
    object _x_67108 = NOVALUE;
    object _33165 = NOVALUE;
    object _33164 = NOVALUE;
    object _33163 = NOVALUE;
    object _33162 = NOVALUE;
    object _33160 = NOVALUE;
    object _33159 = NOVALUE;
    object _33157 = NOVALUE;
    object _33154 = NOVALUE;
    object _33152 = NOVALUE;
    object _33148 = NOVALUE;
    object _33146 = NOVALUE;
    object _33144 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1501		a = Code[pc+1]*/
    _33144 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33144);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:1502		b = Code[pc+2]*/
    _33146 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _33146);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:1503		target = Code[pc+3]*/
    _33148 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33148);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:1504		x = val[a]*/
    DeRef(_x_67108);
    _2 = (object)SEQ_PTR(_67val_65340);
    _x_67108 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    Ref(_x_67108);

    /** execute.e:1505		sub = val[b]*/
    DeRef(_sub_67107);
    _2 = (object)SEQ_PTR(_67val_65340);
    _sub_67107 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    Ref(_sub_67107);

    /** execute.e:1506		if atom(x) then*/
    _33152 = IS_ATOM(_x_67108);
    if (_33152 == 0)
    {
        _33152 = NOVALUE;
        goto L1; // [74] 83
    }
    else{
        _33152 = NOVALUE;
    }

    /** execute.e:1507			RTFatal("attempt to subscript an atom\n(reading from it)")*/
    RefDS(_33153);
    _67RTFatal(_33153);
L1: 

    /** execute.e:1509		if sequence(sub) then*/
    _33154 = IS_SEQUENCE(_sub_67107);
    if (_33154 == 0)
    {
        _33154 = NOVALUE;
        goto L2; // [88] 97
    }
    else{
        _33154 = NOVALUE;
    }

    /** execute.e:1510			RTFatal("subscript must be an atom\n(reading an element of a sequence)")*/
    RefDS(_33155);
    _67RTFatal(_33155);
L2: 

    /** execute.e:1512		sub = floor(sub)*/
    _0 = _sub_67107;
    if (IS_ATOM_INT(_sub_67107))
    _sub_67107 = e_floor(_sub_67107);
    else
    _sub_67107 = unary_op(FLOOR, _sub_67107);
    DeRef(_0);

    /** execute.e:1513		if sub < 1 or sub > length(x) then*/
    if (IS_ATOM_INT(_sub_67107)) {
        _33157 = (_sub_67107 < 1LL);
    }
    else {
        _33157 = binary_op(LESS, _sub_67107, 1LL);
    }
    if (IS_ATOM_INT(_33157)) {
        if (_33157 != 0) {
            goto L3; // [108] 124
        }
    }
    else {
        if (DBL_PTR(_33157)->dbl != 0.0) {
            goto L3; // [108] 124
        }
    }
    if (IS_SEQUENCE(_x_67108)){
            _33159 = SEQ_PTR(_x_67108)->length;
    }
    else {
        _33159 = 1;
    }
    if (IS_ATOM_INT(_sub_67107)) {
        _33160 = (_sub_67107 > _33159);
    }
    else {
        _33160 = binary_op(GREATER, _sub_67107, _33159);
    }
    _33159 = NOVALUE;
    if (_33160 == 0) {
        DeRef(_33160);
        _33160 = NOVALUE;
        goto L4; // [120] 141
    }
    else {
        if (!IS_ATOM_INT(_33160) && DBL_PTR(_33160)->dbl == 0.0){
            DeRef(_33160);
            _33160 = NOVALUE;
            goto L4; // [120] 141
        }
        DeRef(_33160);
        _33160 = NOVALUE;
    }
    DeRef(_33160);
    _33160 = NOVALUE;
L3: 

    /** execute.e:1514			RTFatal(*/
    if (IS_SEQUENCE(_x_67108)){
            _33162 = SEQ_PTR(_x_67108)->length;
    }
    else {
        _33162 = 1;
    }
    Ref(_sub_67107);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _sub_67107;
    ((intptr_t *)_2)[2] = _33162;
    _33163 = MAKE_SEQ(_1);
    _33162 = NOVALUE;
    _33164 = EPrintf(-9999999, _33161, _33163);
    DeRefDS(_33163);
    _33163 = NOVALUE;
    _67RTFatal(_33164);
    _33164 = NOVALUE;
L4: 

    /** execute.e:1519		val[target] = x[sub]*/
    _2 = (object)SEQ_PTR(_x_67108);
    if (!IS_ATOM_INT(_sub_67107)){
        _33165 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_sub_67107)->dbl));
    }
    else{
        _33165 = (object)*(((s1_ptr)_2)->base + _sub_67107);
    }
    Ref(_33165);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33165;
    if( _1 != _33165 ){
        DeRef(_1);
    }
    _33165 = NOVALUE;

    /** execute.e:1520		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:1521	end procedure*/
    DeRef(_sub_67107);
    DeRef(_x_67108);
    DeRef(_33157);
    _33157 = NOVALUE;
    DeRef(_33148);
    _33148 = NOVALUE;
    DeRef(_33144);
    _33144 = NOVALUE;
    DeRef(_33146);
    _33146 = NOVALUE;
    return;
    ;
}


void _67opGOTO()
{
    object _33167 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1524		pc = Code[pc+1]*/
    _33167 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65330 = (object)*(((s1_ptr)_2)->base + _33167);
    if (!IS_ATOM_INT(_67pc_65330)){
        _67pc_65330 = (object)DBL_PTR(_67pc_65330)->dbl;
    }

    /** execute.e:1525	end procedure*/
    _33167 = NOVALUE;
    return;
    ;
}


void _67opGLABEL()
{
    object _33169 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1527		pc = Code[pc+1]*/
    _33169 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65330 = (object)*(((s1_ptr)_2)->base + _33169);
    if (!IS_ATOM_INT(_67pc_65330)){
        _67pc_65330 = (object)DBL_PTR(_67pc_65330)->dbl;
    }

    /** execute.e:1528	end procedure*/
    _33169 = NOVALUE;
    return;
    ;
}


void _67opIF()
{
    object _33175 = NOVALUE;
    object _33173 = NOVALUE;
    object _33171 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1531		a = Code[pc+1]*/
    _33171 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33171);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:1532		if val[a] = 0 then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33173 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (binary_op_a(NOTEQ, _33173, 0LL)){
        _33173 = NOVALUE;
        goto L1; // [27] 50
    }
    _33173 = NOVALUE;

    /** execute.e:1533			pc = Code[pc+2]*/
    _33175 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65330 = (object)*(((s1_ptr)_2)->base + _33175);
    if (!IS_ATOM_INT(_67pc_65330)){
        _67pc_65330 = (object)DBL_PTR(_67pc_65330)->dbl;
    }
    goto L2; // [47] 59
L1: 

    /** execute.e:1535			pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;
L2: 

    /** execute.e:1537	end procedure*/
    DeRef(_33175);
    _33175 = NOVALUE;
    DeRef(_33171);
    _33171 = NOVALUE;
    return;
    ;
}


void _67opINTEGER_CHECK()
{
    object _33183 = NOVALUE;
    object _33181 = NOVALUE;
    object _33180 = NOVALUE;
    object _33178 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1540		a = Code[pc+1]*/
    _33178 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33178);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:1541		if not integer(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33180 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_ATOM_INT(_33180))
    _33181 = 1;
    else if (IS_ATOM_DBL(_33180))
    _33181 = IS_ATOM_INT(DoubleToInt(_33180));
    else
    _33181 = 0;
    _33180 = NOVALUE;
    if (_33181 != 0)
    goto L1; // [30] 45
    _33181 = NOVALUE;

    /** execute.e:1542			RTFatalType(pc+1)*/
    _33183 = _67pc_65330 + 1;
    if (_33183 > MAXINT){
        _33183 = NewDouble((eudouble)_33183);
    }
    _67RTFatalType(_33183);
    _33183 = NOVALUE;
L1: 

    /** execute.e:1544		pc += 2*/
    _67pc_65330 = _67pc_65330 + 2LL;

    /** execute.e:1545	end procedure*/
    DeRef(_33178);
    _33178 = NOVALUE;
    return;
    ;
}


void _67opATOM_CHECK()
{
    object _33190 = NOVALUE;
    object _33188 = NOVALUE;
    object _33187 = NOVALUE;
    object _33185 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1548		a = Code[pc+1]*/
    _33185 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33185);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:1549		if not atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33187 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _33188 = IS_ATOM(_33187);
    _33187 = NOVALUE;
    if (_33188 != 0)
    goto L1; // [30] 45
    _33188 = NOVALUE;

    /** execute.e:1550			RTFatalType(pc+1)*/
    _33190 = _67pc_65330 + 1;
    if (_33190 > MAXINT){
        _33190 = NewDouble((eudouble)_33190);
    }
    _67RTFatalType(_33190);
    _33190 = NOVALUE;
L1: 

    /** execute.e:1552		pc += 2*/
    _67pc_65330 = _67pc_65330 + 2LL;

    /** execute.e:1553	end procedure*/
    DeRef(_33185);
    _33185 = NOVALUE;
    return;
    ;
}


void _67opSEQUENCE_CHECK()
{
    object _33197 = NOVALUE;
    object _33195 = NOVALUE;
    object _33194 = NOVALUE;
    object _33192 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1556		a = Code[pc+1]*/
    _33192 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33192);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:1557		if not sequence(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33194 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _33195 = IS_SEQUENCE(_33194);
    _33194 = NOVALUE;
    if (_33195 != 0)
    goto L1; // [30] 45
    _33195 = NOVALUE;

    /** execute.e:1558			RTFatalType(pc+1)*/
    _33197 = _67pc_65330 + 1;
    if (_33197 > MAXINT){
        _33197 = NewDouble((eudouble)_33197);
    }
    _67RTFatalType(_33197);
    _33197 = NOVALUE;
L1: 

    /** execute.e:1560		pc += 2*/
    _67pc_65330 = _67pc_65330 + 2LL;

    /** execute.e:1561	end procedure*/
    DeRef(_33192);
    _33192 = NOVALUE;
    return;
    ;
}


void _67opASSIGN()
{
    object _a_67196 = NOVALUE;
    object _33204 = NOVALUE;
    object _33203 = NOVALUE;
    object _33201 = NOVALUE;
    object _33199 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1565		integer a = Code[pc+1]*/
    _33199 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _a_67196 = (object)*(((s1_ptr)_2)->base + _33199);
    if (!IS_ATOM_INT(_a_67196)){
        _a_67196 = (object)DBL_PTR(_a_67196)->dbl;
    }

    /** execute.e:1566		target = Code[pc+2]*/
    _33201 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33201);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:1567		val[target] = val[a]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33203 = (object)*(((s1_ptr)_2)->base + _a_67196);
    Ref(_33203);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33203;
    if( _1 != _33203 ){
        DeRef(_1);
    }
    _33203 = NOVALUE;

    /** execute.e:1568		if sym_mode( a ) = M_TEMP then*/
    _33204 = _53sym_mode(_a_67196);
    if (binary_op_a(NOTEQ, _33204, 3LL)){
        DeRef(_33204);
        _33204 = NOVALUE;
        goto L1; // [57] 72
    }
    DeRef(_33204);
    _33204 = NOVALUE;

    /** execute.e:1569			val[a] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _a_67196);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
L1: 

    /** execute.e:1571		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:1572	end procedure*/
    DeRef(_33201);
    _33201 = NOVALUE;
    DeRef(_33199);
    _33199 = NOVALUE;
    return;
    ;
}


void _67opELSE()
{
    object _33207 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1576		pc = Code[pc+1]*/
    _33207 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65330 = (object)*(((s1_ptr)_2)->base + _33207);
    if (!IS_ATOM_INT(_67pc_65330)){
        _67pc_65330 = (object)DBL_PTR(_67pc_65330)->dbl;
    }

    /** execute.e:1577	end procedure*/
    _33207 = NOVALUE;
    return;
    ;
}


void _67opRIGHT_BRACE_N()
{
    object _x_67218 = NOVALUE;
    object _33224 = NOVALUE;
    object _33222 = NOVALUE;
    object _33221 = NOVALUE;
    object _33220 = NOVALUE;
    object _33218 = NOVALUE;
    object _33217 = NOVALUE;
    object _33215 = NOVALUE;
    object _33214 = NOVALUE;
    object _33213 = NOVALUE;
    object _33212 = NOVALUE;
    object _33211 = NOVALUE;
    object _33209 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1583		len = Code[pc+1]*/
    _33209 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67len_65336 = (object)*(((s1_ptr)_2)->base + _33209);
    if (!IS_ATOM_INT(_67len_65336)){
        _67len_65336 = (object)DBL_PTR(_67len_65336)->dbl;
    }

    /** execute.e:1584		x = {}*/
    RefDS(_22218);
    DeRef(_x_67218);
    _x_67218 = _22218;

    /** execute.e:1585		for i = pc+len+1 to pc+2 by -1 do*/
    _33211 = _67pc_65330 + _67len_65336;
    if ((object)((uintptr_t)_33211 + (uintptr_t)HIGH_BITS) >= 0){
        _33211 = NewDouble((eudouble)_33211);
    }
    if (IS_ATOM_INT(_33211)) {
        _33212 = _33211 + 1;
        if (_33212 > MAXINT){
            _33212 = NewDouble((eudouble)_33212);
        }
    }
    else
    _33212 = binary_op(PLUS, 1, _33211);
    DeRef(_33211);
    _33211 = NOVALUE;
    _33213 = _67pc_65330 + 2LL;
    if ((object)((uintptr_t)_33213 + (uintptr_t)HIGH_BITS) >= 0){
        _33213 = NewDouble((eudouble)_33213);
    }
    {
        object _i_67223;
        Ref(_33212);
        _i_67223 = _33212;
L1: 
        if (binary_op_a(LESS, _i_67223, _33213)){
            goto L2; // [44] 111
        }

        /** execute.e:1587			x = append(x, val[Code[i]])*/
        _2 = (object)SEQ_PTR(_27Code_20660);
        if (!IS_ATOM_INT(_i_67223)){
            _33214 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_67223)->dbl));
        }
        else{
            _33214 = (object)*(((s1_ptr)_2)->base + _i_67223);
        }
        _2 = (object)SEQ_PTR(_67val_65340);
        if (!IS_ATOM_INT(_33214)){
            _33215 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33214)->dbl));
        }
        else{
            _33215 = (object)*(((s1_ptr)_2)->base + _33214);
        }
        Ref(_33215);
        Append(&_x_67218, _x_67218, _33215);
        _33215 = NOVALUE;

        /** execute.e:1588			if sym_mode( Code[i] ) = M_TEMP then*/
        _2 = (object)SEQ_PTR(_27Code_20660);
        if (!IS_ATOM_INT(_i_67223)){
            _33217 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_67223)->dbl));
        }
        else{
            _33217 = (object)*(((s1_ptr)_2)->base + _i_67223);
        }
        Ref(_33217);
        _33218 = _53sym_mode(_33217);
        _33217 = NOVALUE;
        if (binary_op_a(NOTEQ, _33218, 3LL)){
            DeRef(_33218);
            _33218 = NOVALUE;
            goto L3; // [83] 104
        }
        DeRef(_33218);
        _33218 = NOVALUE;

        /** execute.e:1589				val[Code[i]] = NOVALUE*/
        _2 = (object)SEQ_PTR(_27Code_20660);
        if (!IS_ATOM_INT(_i_67223)){
            _33220 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_67223)->dbl));
        }
        else{
            _33220 = (object)*(((s1_ptr)_2)->base + _i_67223);
        }
        Ref(_27NOVALUE_20426);
        _2 = (object)SEQ_PTR(_67val_65340);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_65340 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_33220))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33220)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _33220);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _27NOVALUE_20426;
        DeRef(_1);
L3: 

        /** execute.e:1591		end for*/
        _0 = _i_67223;
        if (IS_ATOM_INT(_i_67223)) {
            _i_67223 = _i_67223 + -1LL;
            if ((object)((uintptr_t)_i_67223 +(uintptr_t) HIGH_BITS) >= 0){
                _i_67223 = NewDouble((eudouble)_i_67223);
            }
        }
        else {
            _i_67223 = binary_op_a(PLUS, _i_67223, -1LL);
        }
        DeRef(_0);
        goto L1; // [106] 51
L2: 
        ;
        DeRef(_i_67223);
    }

    /** execute.e:1592		target = Code[pc+len+2]*/
    _33221 = _67pc_65330 + _67len_65336;
    if ((object)((uintptr_t)_33221 + (uintptr_t)HIGH_BITS) >= 0){
        _33221 = NewDouble((eudouble)_33221);
    }
    if (IS_ATOM_INT(_33221)) {
        _33222 = _33221 + 2LL;
    }
    else {
        _33222 = NewDouble(DBL_PTR(_33221)->dbl + (eudouble)2LL);
    }
    DeRef(_33221);
    _33221 = NOVALUE;
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!IS_ATOM_INT(_33222)){
        _67target_65335 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33222)->dbl));
    }
    else{
        _67target_65335 = (object)*(((s1_ptr)_2)->base + _33222);
    }
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:1593		val[target] = x*/
    RefDS(_x_67218);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _x_67218;
    DeRef(_1);

    /** execute.e:1594		pc += 3 + len*/
    _33224 = 3LL + _67len_65336;
    if ((object)((uintptr_t)_33224 + (uintptr_t)HIGH_BITS) >= 0){
        _33224 = NewDouble((eudouble)_33224);
    }
    if (IS_ATOM_INT(_33224)) {
        _67pc_65330 = _67pc_65330 + _33224;
    }
    else {
        _67pc_65330 = NewDouble((eudouble)_67pc_65330 + DBL_PTR(_33224)->dbl);
    }
    DeRef(_33224);
    _33224 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_65330)) {
        _1 = (object)(DBL_PTR(_67pc_65330)->dbl);
        DeRefDS(_67pc_65330);
        _67pc_65330 = _1;
    }

    /** execute.e:1595	end procedure*/
    DeRefDS(_x_67218);
    DeRef(_33222);
    _33222 = NOVALUE;
    _33220 = NOVALUE;
    DeRef(_33209);
    _33209 = NOVALUE;
    _33214 = NOVALUE;
    DeRef(_33213);
    _33213 = NOVALUE;
    DeRef(_33212);
    _33212 = NOVALUE;
    return;
    ;
}


void _67opRIGHT_BRACE_2()
{
    object _33246 = NOVALUE;
    object _33245 = NOVALUE;
    object _33243 = NOVALUE;
    object _33242 = NOVALUE;
    object _33241 = NOVALUE;
    object _33240 = NOVALUE;
    object _33239 = NOVALUE;
    object _33237 = NOVALUE;
    object _33236 = NOVALUE;
    object _33235 = NOVALUE;
    object _33234 = NOVALUE;
    object _33233 = NOVALUE;
    object _33232 = NOVALUE;
    object _33231 = NOVALUE;
    object _33230 = NOVALUE;
    object _33229 = NOVALUE;
    object _33228 = NOVALUE;
    object _33226 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1599		target = Code[pc+3]*/
    _33226 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33226);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:1601		val[target] = {val[Code[pc+2]], val[Code[pc+1]]}*/
    _33228 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33229 = (object)*(((s1_ptr)_2)->base + _33228);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!IS_ATOM_INT(_33229)){
        _33230 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33229)->dbl));
    }
    else{
        _33230 = (object)*(((s1_ptr)_2)->base + _33229);
    }
    _33231 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33232 = (object)*(((s1_ptr)_2)->base + _33231);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!IS_ATOM_INT(_33232)){
        _33233 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33232)->dbl));
    }
    else{
        _33233 = (object)*(((s1_ptr)_2)->base + _33232);
    }
    Ref(_33233);
    Ref(_33230);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _33230;
    ((intptr_t *)_2)[2] = _33233;
    _33234 = MAKE_SEQ(_1);
    _33233 = NOVALUE;
    _33230 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33234;
    if( _1 != _33234 ){
        DeRef(_1);
    }
    _33234 = NOVALUE;

    /** execute.e:1602		if sym_mode( Code[pc+2] ) = M_TEMP then*/
    _33235 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33236 = (object)*(((s1_ptr)_2)->base + _33235);
    Ref(_33236);
    _33237 = _53sym_mode(_33236);
    _33236 = NOVALUE;
    if (binary_op_a(NOTEQ, _33237, 3LL)){
        DeRef(_33237);
        _33237 = NOVALUE;
        goto L1; // [87] 114
    }
    DeRef(_33237);
    _33237 = NOVALUE;

    /** execute.e:1603			val[Code[pc+2]] = NOVALUE*/
    _33239 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33240 = (object)*(((s1_ptr)_2)->base + _33239);
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33240))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33240)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33240);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
L1: 

    /** execute.e:1605		if sym_mode( Code[pc+1] ) = M_TEMP then*/
    _33241 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33242 = (object)*(((s1_ptr)_2)->base + _33241);
    Ref(_33242);
    _33243 = _53sym_mode(_33242);
    _33242 = NOVALUE;
    if (binary_op_a(NOTEQ, _33243, 3LL)){
        DeRef(_33243);
        _33243 = NOVALUE;
        goto L2; // [134] 161
    }
    DeRef(_33243);
    _33243 = NOVALUE;

    /** execute.e:1606			val[Code[pc+1]] = NOVALUE*/
    _33245 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33246 = (object)*(((s1_ptr)_2)->base + _33245);
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33246))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33246)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33246);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
L2: 

    /** execute.e:1608		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:1609	end procedure*/
    DeRef(_33228);
    _33228 = NOVALUE;
    _33229 = NOVALUE;
    DeRef(_33241);
    _33241 = NOVALUE;
    DeRef(_33226);
    _33226 = NOVALUE;
    _33240 = NOVALUE;
    DeRef(_33245);
    _33245 = NOVALUE;
    DeRef(_33235);
    _33235 = NOVALUE;
    _33232 = NOVALUE;
    DeRef(_33231);
    _33231 = NOVALUE;
    DeRef(_33239);
    _33239 = NOVALUE;
    _33246 = NOVALUE;
    return;
    ;
}


void _67opPLUS1()
{
    object _33253 = NOVALUE;
    object _33252 = NOVALUE;
    object _33250 = NOVALUE;
    object _33248 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1613		a = Code[pc+1]*/
    _33248 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33248);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:1615		target = Code[pc+3]*/
    _33250 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33250);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:1616		val[target] = val[a] + 1*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33252 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_ATOM_INT(_33252)) {
        _33253 = _33252 + 1;
        if (_33253 > MAXINT){
            _33253 = NewDouble((eudouble)_33253);
        }
    }
    else
    _33253 = binary_op(PLUS, 1, _33252);
    _33252 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33253;
    if( _1 != _33253 ){
        DeRef(_1);
    }
    _33253 = NOVALUE;

    /** execute.e:1617		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:1618	end procedure*/
    _33250 = NOVALUE;
    _33248 = NOVALUE;
    return;
    ;
}


void _67opGLOBAL_INIT_CHECK()
{
    object _33263 = NOVALUE;
    object _33261 = NOVALUE;
    object _33260 = NOVALUE;
    object _33258 = NOVALUE;
    object _33257 = NOVALUE;
    object _33255 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1622		a = Code[pc+1]*/
    _33255 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33255);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:1623		if equal(val[a], NOVALUE) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33257 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (_33257 == _27NOVALUE_20426)
    _33258 = 1;
    else if (IS_ATOM_INT(_33257) && IS_ATOM_INT(_27NOVALUE_20426))
    _33258 = 0;
    else
    _33258 = (compare(_33257, _27NOVALUE_20426) == 0);
    _33257 = NOVALUE;
    if (_33258 == 0)
    {
        _33258 = NOVALUE;
        goto L1; // [33] 62
    }
    else{
        _33258 = NOVALUE;
    }

    /** execute.e:1624			RTFatal("variable " & SymTab[a][S_NAME] & " has not been assigned a value")*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33260 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_33260);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _33261 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _33261 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _33260 = NOVALUE;
    {
        object concat_list[3];

        concat_list[0] = _33262;
        concat_list[1] = _33261;
        concat_list[2] = _33259;
        Concat_N((object_ptr)&_33263, concat_list, 3);
    }
    _33261 = NOVALUE;
    _67RTFatal(_33263);
    _33263 = NOVALUE;
L1: 

    /** execute.e:1626		pc += 2*/
    _67pc_65330 = _67pc_65330 + 2LL;

    /** execute.e:1627	end procedure*/
    DeRef(_33255);
    _33255 = NOVALUE;
    return;
    ;
}


void _67opWHILE()
{
    object _33269 = NOVALUE;
    object _33267 = NOVALUE;
    object _33265 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1631		a = Code[pc+1]*/
    _33265 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33265);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:1632		if val[a] = 0 then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33267 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (binary_op_a(NOTEQ, _33267, 0LL)){
        _33267 = NOVALUE;
        goto L1; // [27] 50
    }
    _33267 = NOVALUE;

    /** execute.e:1633			pc = Code[pc+2]*/
    _33269 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65330 = (object)*(((s1_ptr)_2)->base + _33269);
    if (!IS_ATOM_INT(_67pc_65330)){
        _67pc_65330 = (object)DBL_PTR(_67pc_65330)->dbl;
    }
    goto L2; // [47] 59
L1: 

    /** execute.e:1635			pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;
L2: 

    /** execute.e:1637	end procedure*/
    DeRef(_33265);
    _33265 = NOVALUE;
    DeRef(_33269);
    _33269 = NOVALUE;
    return;
    ;
}


void _67opSWITCH_SPI()
{
    object _33294 = NOVALUE;
    object _33292 = NOVALUE;
    object _33291 = NOVALUE;
    object _33290 = NOVALUE;
    object _33289 = NOVALUE;
    object _33288 = NOVALUE;
    object _33287 = NOVALUE;
    object _33286 = NOVALUE;
    object _33285 = NOVALUE;
    object _33284 = NOVALUE;
    object _33283 = NOVALUE;
    object _33282 = NOVALUE;
    object _33280 = NOVALUE;
    object _33279 = NOVALUE;
    object _33278 = NOVALUE;
    object _33277 = NOVALUE;
    object _33276 = NOVALUE;
    object _33275 = NOVALUE;
    object _33274 = NOVALUE;
    object _33273 = NOVALUE;
    object _33272 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1645		if integer( val[Code[pc+1]] ) then*/
    _33272 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33273 = (object)*(((s1_ptr)_2)->base + _33272);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!IS_ATOM_INT(_33273)){
        _33274 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33273)->dbl));
    }
    else{
        _33274 = (object)*(((s1_ptr)_2)->base + _33273);
    }
    if (IS_ATOM_INT(_33274))
    _33275 = 1;
    else if (IS_ATOM_DBL(_33274))
    _33275 = IS_ATOM_INT(DoubleToInt(_33274));
    else
    _33275 = 0;
    _33274 = NOVALUE;
    if (_33275 == 0)
    {
        _33275 = NOVALUE;
        goto L1; // [24] 149
    }
    else{
        _33275 = NOVALUE;
    }

    /** execute.e:1646			a = val[Code[pc+1]] - Code[pc+2]*/
    _33276 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33277 = (object)*(((s1_ptr)_2)->base + _33276);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!IS_ATOM_INT(_33277)){
        _33278 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33277)->dbl));
    }
    else{
        _33278 = (object)*(((s1_ptr)_2)->base + _33277);
    }
    _33279 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33280 = (object)*(((s1_ptr)_2)->base + _33279);
    if (IS_ATOM_INT(_33278) && IS_ATOM_INT(_33280)) {
        _67a_65331 = _33278 - _33280;
    }
    else {
        _67a_65331 = binary_op(MINUS, _33278, _33280);
    }
    _33278 = NOVALUE;
    _33280 = NOVALUE;
    if (!IS_ATOM_INT(_67a_65331)) {
        _1 = (object)(DBL_PTR(_67a_65331)->dbl);
        DeRefDS(_67a_65331);
        _67a_65331 = _1;
    }

    /** execute.e:1647			if a > 0 and a <= length( val[Code[pc+3]] ) then*/
    _33282 = (_67a_65331 > 0LL);
    if (_33282 == 0) {
        goto L2; // [73] 148
    }
    _33284 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33285 = (object)*(((s1_ptr)_2)->base + _33284);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!IS_ATOM_INT(_33285)){
        _33286 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33285)->dbl));
    }
    else{
        _33286 = (object)*(((s1_ptr)_2)->base + _33285);
    }
    if (IS_SEQUENCE(_33286)){
            _33287 = SEQ_PTR(_33286)->length;
    }
    else {
        _33287 = 1;
    }
    _33286 = NOVALUE;
    _33288 = (_67a_65331 <= _33287);
    _33287 = NOVALUE;
    if (_33288 == 0)
    {
        DeRef(_33288);
        _33288 = NOVALUE;
        goto L2; // [105] 148
    }
    else{
        DeRef(_33288);
        _33288 = NOVALUE;
    }

    /** execute.e:1648				pc += val[Code[pc+3]][a]*/
    _33289 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33290 = (object)*(((s1_ptr)_2)->base + _33289);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!IS_ATOM_INT(_33290)){
        _33291 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33290)->dbl));
    }
    else{
        _33291 = (object)*(((s1_ptr)_2)->base + _33290);
    }
    _2 = (object)SEQ_PTR(_33291);
    _33292 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _33291 = NOVALUE;
    if (IS_ATOM_INT(_33292)) {
        _67pc_65330 = _67pc_65330 + _33292;
    }
    else {
        _67pc_65330 = binary_op(PLUS, _67pc_65330, _33292);
    }
    _33292 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_65330)) {
        _1 = (object)(DBL_PTR(_67pc_65330)->dbl);
        DeRefDS(_67pc_65330);
        _67pc_65330 = _1;
    }

    /** execute.e:1649				return*/
    DeRef(_33282);
    _33282 = NOVALUE;
    _33277 = NOVALUE;
    _33289 = NOVALUE;
    DeRef(_33279);
    _33279 = NOVALUE;
    _33285 = NOVALUE;
    _33286 = NOVALUE;
    DeRef(_33272);
    _33272 = NOVALUE;
    _33273 = NOVALUE;
    DeRef(_33276);
    _33276 = NOVALUE;
    _33290 = NOVALUE;
    DeRef(_33284);
    _33284 = NOVALUE;
    return;
L2: 
L1: 

    /** execute.e:1652		pc = Code[pc+4]*/
    _33294 = _67pc_65330 + 4LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65330 = (object)*(((s1_ptr)_2)->base + _33294);
    if (!IS_ATOM_INT(_67pc_65330)){
        _67pc_65330 = (object)DBL_PTR(_67pc_65330)->dbl;
    }

    /** execute.e:1653	end procedure*/
    _33294 = NOVALUE;
    DeRef(_33282);
    _33282 = NOVALUE;
    _33277 = NOVALUE;
    DeRef(_33289);
    _33289 = NOVALUE;
    DeRef(_33279);
    _33279 = NOVALUE;
    _33285 = NOVALUE;
    _33286 = NOVALUE;
    DeRef(_33272);
    _33272 = NOVALUE;
    _33273 = NOVALUE;
    DeRef(_33276);
    _33276 = NOVALUE;
    _33290 = NOVALUE;
    DeRef(_33284);
    _33284 = NOVALUE;
    return;
    ;
}


void _67opSWITCH()
{
    object _33308 = NOVALUE;
    object _33306 = NOVALUE;
    object _33305 = NOVALUE;
    object _33304 = NOVALUE;
    object _33303 = NOVALUE;
    object _33301 = NOVALUE;
    object _33300 = NOVALUE;
    object _33299 = NOVALUE;
    object _33298 = NOVALUE;
    object _33297 = NOVALUE;
    object _33296 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1660		a = find( val[Code[pc+1]], val[Code[pc+2]] )*/
    _33296 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33297 = (object)*(((s1_ptr)_2)->base + _33296);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!IS_ATOM_INT(_33297)){
        _33298 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33297)->dbl));
    }
    else{
        _33298 = (object)*(((s1_ptr)_2)->base + _33297);
    }
    _33299 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33300 = (object)*(((s1_ptr)_2)->base + _33299);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!IS_ATOM_INT(_33300)){
        _33301 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33300)->dbl));
    }
    else{
        _33301 = (object)*(((s1_ptr)_2)->base + _33300);
    }
    _67a_65331 = find_from(_33298, _33301, 1LL);
    _33298 = NOVALUE;
    _33301 = NOVALUE;

    /** execute.e:1661		if a then*/
    if (_67a_65331 == 0)
    {
        goto L1; // [48] 88
    }
    else{
    }

    /** execute.e:1662			pc += val[Code[pc+3]][a]*/
    _33303 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33304 = (object)*(((s1_ptr)_2)->base + _33303);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!IS_ATOM_INT(_33304)){
        _33305 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33304)->dbl));
    }
    else{
        _33305 = (object)*(((s1_ptr)_2)->base + _33304);
    }
    _2 = (object)SEQ_PTR(_33305);
    _33306 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _33305 = NOVALUE;
    if (IS_ATOM_INT(_33306)) {
        _67pc_65330 = _67pc_65330 + _33306;
    }
    else {
        _67pc_65330 = binary_op(PLUS, _67pc_65330, _33306);
    }
    _33306 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_65330)) {
        _1 = (object)(DBL_PTR(_67pc_65330)->dbl);
        DeRefDS(_67pc_65330);
        _67pc_65330 = _1;
    }
    goto L2; // [85] 105
L1: 

    /** execute.e:1664			pc = Code[pc + 4]*/
    _33308 = _67pc_65330 + 4LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65330 = (object)*(((s1_ptr)_2)->base + _33308);
    if (!IS_ATOM_INT(_67pc_65330)){
        _67pc_65330 = (object)DBL_PTR(_67pc_65330)->dbl;
    }
L2: 

    /** execute.e:1666	end procedure*/
    DeRef(_33303);
    _33303 = NOVALUE;
    _33297 = NOVALUE;
    DeRef(_33296);
    _33296 = NOVALUE;
    _33300 = NOVALUE;
    _33304 = NOVALUE;
    DeRef(_33299);
    _33299 = NOVALUE;
    DeRef(_33308);
    _33308 = NOVALUE;
    return;
    ;
}


void _67opSWITCH_RT()
{
    object _values_67385 = NOVALUE;
    object _all_ints_67390 = NOVALUE;
    object _max_67391 = NOVALUE;
    object _min_67393 = NOVALUE;
    object _sym_67398 = NOVALUE;
    object _sign_67400 = NOVALUE;
    object _new_value_67415 = NOVALUE;
    object _jump_67432 = NOVALUE;
    object _switch_table_67437 = NOVALUE;
    object _offset_67445 = NOVALUE;
    object _33360 = NOVALUE;
    object _33359 = NOVALUE;
    object _33358 = NOVALUE;
    object _33357 = NOVALUE;
    object _33356 = NOVALUE;
    object _33353 = NOVALUE;
    object _33352 = NOVALUE;
    object _33351 = NOVALUE;
    object _33350 = NOVALUE;
    object _33349 = NOVALUE;
    object _33347 = NOVALUE;
    object _33346 = NOVALUE;
    object _33345 = NOVALUE;
    object _33344 = NOVALUE;
    object _33343 = NOVALUE;
    object _33340 = NOVALUE;
    object _33339 = NOVALUE;
    object _33338 = NOVALUE;
    object _33337 = NOVALUE;
    object _33336 = NOVALUE;
    object _33334 = NOVALUE;
    object _33333 = NOVALUE;
    object _33332 = NOVALUE;
    object _33331 = NOVALUE;
    object _33330 = NOVALUE;
    object _33326 = NOVALUE;
    object _33324 = NOVALUE;
    object _33323 = NOVALUE;
    object _33322 = NOVALUE;
    object _33321 = NOVALUE;
    object _33320 = NOVALUE;
    object _33318 = NOVALUE;
    object _33317 = NOVALUE;
    object _33313 = NOVALUE;
    object _33311 = NOVALUE;
    object _33310 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1677		sequence values = val[Code[pc+2]]*/
    _33310 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33311 = (object)*(((s1_ptr)_2)->base + _33310);
    DeRef(_values_67385);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!IS_ATOM_INT(_33311)){
        _values_67385 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33311)->dbl));
    }
    else{
        _values_67385 = (object)*(((s1_ptr)_2)->base + _33311);
    }
    Ref(_values_67385);

    /** execute.e:1678		integer all_ints = 1*/
    _all_ints_67390 = 1LL;

    /** execute.e:1679		integer max = MININT*/
    Ref(_27MININT_20396);
    _max_67391 = _27MININT_20396;
    if (!IS_ATOM_INT(_max_67391)) {
        _1 = (object)(DBL_PTR(_max_67391)->dbl);
        DeRefDS(_max_67391);
        _max_67391 = _1;
    }

    /** execute.e:1680		integer min = MAXINT*/
    Ref(_27MAXINT_20395);
    _min_67393 = _27MAXINT_20395;
    if (!IS_ATOM_INT(_min_67393)) {
        _1 = (object)(DBL_PTR(_min_67393)->dbl);
        DeRefDS(_min_67393);
        _min_67393 = _1;
    }

    /** execute.e:1681		for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_67385)){
            _33313 = SEQ_PTR(_values_67385)->length;
    }
    else {
        _33313 = 1;
    }
    {
        object _i_67396;
        _i_67396 = 1LL;
L1: 
        if (_i_67396 > _33313){
            goto L2; // [51] 209
        }

        /** execute.e:1682			integer sym = values[i]*/
        _2 = (object)SEQ_PTR(_values_67385);
        _sym_67398 = (object)*(((s1_ptr)_2)->base + _i_67396);
        if (!IS_ATOM_INT(_sym_67398))
        _sym_67398 = (object)DBL_PTR(_sym_67398)->dbl;

        /** execute.e:1683			integer sign = 1*/
        _sign_67400 = 1LL;

        /** execute.e:1684			if sym < 0 then*/
        if (_sym_67398 >= 0LL)
        goto L3; // [71] 88

        /** execute.e:1685				sign = -1*/
        _sign_67400 = -1LL;

        /** execute.e:1686				sym = -sym*/
        _sym_67398 = - _sym_67398;
L3: 

        /** execute.e:1688			if equal(val[sym], NOVALUE) then*/
        _2 = (object)SEQ_PTR(_67val_65340);
        _33317 = (object)*(((s1_ptr)_2)->base + _sym_67398);
        if (_33317 == _27NOVALUE_20426)
        _33318 = 1;
        else if (IS_ATOM_INT(_33317) && IS_ATOM_INT(_27NOVALUE_20426))
        _33318 = 0;
        else
        _33318 = (compare(_33317, _27NOVALUE_20426) == 0);
        _33317 = NOVALUE;
        if (_33318 == 0)
        {
            _33318 = NOVALUE;
            goto L4; // [102] 131
        }
        else{
            _33318 = NOVALUE;
        }

        /** execute.e:1689				RTFatal( sprintf( "'%s' has not been assigned a value", {SymTab[sym][S_NAME]} ) )*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _33320 = (object)*(((s1_ptr)_2)->base + _sym_67398);
        _2 = (object)SEQ_PTR(_33320);
        if (!IS_ATOM_INT(_27S_NAME_20209)){
            _33321 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
        }
        else{
            _33321 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
        }
        _33320 = NOVALUE;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_33321);
        ((intptr_t*)_2)[1] = _33321;
        _33322 = MAKE_SEQ(_1);
        _33321 = NOVALUE;
        _33323 = EPrintf(-9999999, _33319, _33322);
        DeRefDS(_33322);
        _33322 = NOVALUE;
        _67RTFatal(_33323);
        _33323 = NOVALUE;
L4: 

        /** execute.e:1691			object new_value = sign * val[sym]*/
        _2 = (object)SEQ_PTR(_67val_65340);
        _33324 = (object)*(((s1_ptr)_2)->base + _sym_67398);
        DeRef(_new_value_67415);
        if (IS_ATOM_INT(_33324)) {
            {
                int128_t p128 = (int128_t)_sign_67400 * (int128_t)_33324;
                if( p128 != (int128_t)(_new_value_67415 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                    _new_value_67415 = NewDouble( (eudouble)p128 );
                }
            }
        }
        else {
            _new_value_67415 = binary_op(MULTIPLY, _sign_67400, _33324);
        }
        _33324 = NOVALUE;

        /** execute.e:1692			values[i] = new_value*/
        Ref(_new_value_67415);
        _2 = (object)SEQ_PTR(_values_67385);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _values_67385 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_67396);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _new_value_67415;
        DeRef(_1);

        /** execute.e:1693			if not integer( new_value ) then*/
        if (IS_ATOM_INT(_new_value_67415))
        _33326 = 1;
        else if (IS_ATOM_DBL(_new_value_67415))
        _33326 = IS_ATOM_INT(DoubleToInt(_new_value_67415));
        else
        _33326 = 0;
        if (_33326 != 0)
        goto L5; // [154] 165
        _33326 = NOVALUE;

        /** execute.e:1694				all_ints = 0*/
        _all_ints_67390 = 0LL;
        goto L6; // [162] 200
L5: 

        /** execute.e:1696			elsif all_ints then*/
        if (_all_ints_67390 == 0)
        {
            goto L7; // [167] 199
        }
        else{
        }

        /** execute.e:1697				if new_value < min then*/
        if (binary_op_a(GREATEREQ, _new_value_67415, _min_67393)){
            goto L8; // [172] 184
        }

        /** execute.e:1698					min = new_value*/
        Ref(_new_value_67415);
        _min_67393 = _new_value_67415;
        if (!IS_ATOM_INT(_min_67393)) {
            _1 = (object)(DBL_PTR(_min_67393)->dbl);
            DeRefDS(_min_67393);
            _min_67393 = _1;
        }
L8: 

        /** execute.e:1701				if new_value > max then*/
        if (binary_op_a(LESSEQ, _new_value_67415, _max_67391)){
            goto L9; // [186] 198
        }

        /** execute.e:1702					max = new_value*/
        Ref(_new_value_67415);
        _max_67391 = _new_value_67415;
        if (!IS_ATOM_INT(_max_67391)) {
            _1 = (object)(DBL_PTR(_max_67391)->dbl);
            DeRefDS(_max_67391);
            _max_67391 = _1;
        }
L9: 
L7: 
L6: 
        DeRef(_new_value_67415);
        _new_value_67415 = NOVALUE;

        /** execute.e:1705		end for*/
        _i_67396 = _i_67396 + 1LL;
        goto L1; // [204] 58
L2: 
        ;
    }

    /** execute.e:1707		if all_ints and max - min < 1024 then*/
    if (_all_ints_67390 == 0) {
        goto LA; // [211] 412
    }
    _33331 = _max_67391 - _min_67393;
    if ((object)((uintptr_t)_33331 +(uintptr_t) HIGH_BITS) >= 0){
        _33331 = NewDouble((eudouble)_33331);
    }
    if (IS_ATOM_INT(_33331)) {
        _33332 = (_33331 < 1024LL);
    }
    else {
        _33332 = (DBL_PTR(_33331)->dbl < (eudouble)1024LL);
    }
    DeRef(_33331);
    _33331 = NOVALUE;
    if (_33332 == 0)
    {
        DeRef(_33332);
        _33332 = NOVALUE;
        goto LA; // [224] 412
    }
    else{
        DeRef(_33332);
        _33332 = NOVALUE;
    }

    /** execute.e:1708			Code[pc] = SWITCH_SPI*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67pc_65330);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 192LL;
    DeRef(_1);

    /** execute.e:1710			sequence jump = val[Code[pc+3]]*/
    _33333 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33334 = (object)*(((s1_ptr)_2)->base + _33333);
    DeRef(_jump_67432);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!IS_ATOM_INT(_33334)){
        _jump_67432 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33334)->dbl));
    }
    else{
        _jump_67432 = (object)*(((s1_ptr)_2)->base + _33334);
    }
    Ref(_jump_67432);

    /** execute.e:1711			sequence switch_table = repeat( Code[pc+4] - pc, max - min + 1 )*/
    _33336 = _67pc_65330 + 4LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33337 = (object)*(((s1_ptr)_2)->base + _33336);
    if (IS_ATOM_INT(_33337)) {
        _33338 = _33337 - _67pc_65330;
        if ((object)((uintptr_t)_33338 +(uintptr_t) HIGH_BITS) >= 0){
            _33338 = NewDouble((eudouble)_33338);
        }
    }
    else {
        _33338 = binary_op(MINUS, _33337, _67pc_65330);
    }
    _33337 = NOVALUE;
    _33339 = _max_67391 - _min_67393;
    if ((object)((uintptr_t)_33339 +(uintptr_t) HIGH_BITS) >= 0){
        _33339 = NewDouble((eudouble)_33339);
    }
    if (IS_ATOM_INT(_33339)) {
        _33340 = _33339 + 1;
    }
    else
    _33340 = binary_op(PLUS, 1, _33339);
    DeRef(_33339);
    _33339 = NOVALUE;
    DeRef(_switch_table_67437);
    _switch_table_67437 = Repeat(_33338, _33340);
    DeRef(_33338);
    _33338 = NOVALUE;
    DeRef(_33340);
    _33340 = NOVALUE;

    /** execute.e:1712			integer offset = min - 1*/
    _offset_67445 = _min_67393 - 1LL;

    /** execute.e:1713			for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_67385)){
            _33343 = SEQ_PTR(_values_67385)->length;
    }
    else {
        _33343 = 1;
    }
    {
        object _i_67448;
        _i_67448 = 1LL;
LB: 
        if (_i_67448 > _33343){
            goto LC; // [304] 336
        }

        /** execute.e:1714				switch_table[values[i] - offset] = jump[i]*/
        _2 = (object)SEQ_PTR(_values_67385);
        _33344 = (object)*(((s1_ptr)_2)->base + _i_67448);
        if (IS_ATOM_INT(_33344)) {
            _33345 = _33344 - _offset_67445;
            if ((object)((uintptr_t)_33345 +(uintptr_t) HIGH_BITS) >= 0){
                _33345 = NewDouble((eudouble)_33345);
            }
        }
        else {
            _33345 = binary_op(MINUS, _33344, _offset_67445);
        }
        _33344 = NOVALUE;
        _2 = (object)SEQ_PTR(_jump_67432);
        _33346 = (object)*(((s1_ptr)_2)->base + _i_67448);
        Ref(_33346);
        _2 = (object)SEQ_PTR(_switch_table_67437);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _switch_table_67437 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_33345))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33345)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _33345);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _33346;
        if( _1 != _33346 ){
            DeRef(_1);
        }
        _33346 = NOVALUE;

        /** execute.e:1715			end for*/
        _i_67448 = _i_67448 + 1LL;
        goto LB; // [331] 311
LC: 
        ;
    }

    /** execute.e:1716			Code[pc+2] = offset*/
    _33347 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _33347);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _offset_67445;
    DeRef(_1);

    /** execute.e:1718			val = append( val, switch_table )*/
    RefDS(_switch_table_67437);
    Append(&_67val_65340, _67val_65340, _switch_table_67437);

    /** execute.e:1719			Code[pc+3] = length(val)*/
    _33349 = _67pc_65330 + 3LL;
    if ((object)((uintptr_t)_33349 + (uintptr_t)HIGH_BITS) >= 0){
        _33349 = NewDouble((eudouble)_33349);
    }
    if (IS_SEQUENCE(_67val_65340)){
            _33350 = SEQ_PTR(_67val_65340)->length;
    }
    else {
        _33350 = 1;
    }
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33349))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33349)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33349);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33350;
    if( _1 != _33350 ){
        DeRef(_1);
    }
    _33350 = NOVALUE;

    /** execute.e:1721			SymTab[call_stack[$]][S_CODE] = Code*/
    if (IS_SEQUENCE(_67call_stack_65348)){
            _33351 = SEQ_PTR(_67call_stack_65348)->length;
    }
    else {
        _33351 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_65348);
    _33352 = (object)*(((s1_ptr)_2)->base + _33351);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33352))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33352)->dbl));
    else
    _3 = (object)(_33352 + ((s1_ptr)_2)->base);
    RefDS(_27Code_20660);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27Code_20660;
    DeRef(_1);
    _33353 = NOVALUE;

    /** execute.e:1722			opSWITCH_SPI()*/
    _67opSWITCH_SPI();
    DeRef(_jump_67432);
    _jump_67432 = NOVALUE;
    DeRefDS(_switch_table_67437);
    _switch_table_67437 = NOVALUE;
    goto LD; // [409] 482
LA: 

    /** execute.e:1724			Code[pc] = SWITCH*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67pc_65330);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 185LL;
    DeRef(_1);

    /** execute.e:1725			val = append( val, values )*/
    RefDS(_values_67385);
    Append(&_67val_65340, _67val_65340, _values_67385);

    /** execute.e:1726			Code[pc+2] = length(val)*/
    _33356 = _67pc_65330 + 2LL;
    if ((object)((uintptr_t)_33356 + (uintptr_t)HIGH_BITS) >= 0){
        _33356 = NewDouble((eudouble)_33356);
    }
    if (IS_SEQUENCE(_67val_65340)){
            _33357 = SEQ_PTR(_67val_65340)->length;
    }
    else {
        _33357 = 1;
    }
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33356))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33356)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33356);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33357;
    if( _1 != _33357 ){
        DeRef(_1);
    }
    _33357 = NOVALUE;

    /** execute.e:1728			SymTab[call_stack[$]][S_CODE] = Code*/
    if (IS_SEQUENCE(_67call_stack_65348)){
            _33358 = SEQ_PTR(_67call_stack_65348)->length;
    }
    else {
        _33358 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_65348);
    _33359 = (object)*(((s1_ptr)_2)->base + _33358);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33359))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33359)->dbl));
    else
    _3 = (object)(_33359 + ((s1_ptr)_2)->base);
    RefDS(_27Code_20660);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27Code_20660;
    DeRef(_1);
    _33360 = NOVALUE;

    /** execute.e:1729			opSWITCH()*/
    _67opSWITCH();
LD: 

    /** execute.e:1732	end procedure*/
    DeRef(_values_67385);
    DeRef(_33310);
    _33310 = NOVALUE;
    DeRef(_33356);
    _33356 = NOVALUE;
    _33334 = NOVALUE;
    DeRef(_33349);
    _33349 = NOVALUE;
    _33311 = NOVALUE;
    _33359 = NOVALUE;
    DeRef(_33345);
    _33345 = NOVALUE;
    DeRef(_33333);
    _33333 = NOVALUE;
    DeRef(_33336);
    _33336 = NOVALUE;
    _33352 = NOVALUE;
    DeRef(_33347);
    _33347 = NOVALUE;
    return;
    ;
}


void _67opCASE()
{
    object _0, _1, _2;
    

    /** execute.e:1736	end procedure*/
    return;
    ;
}


void _67opNOPSWITCH()
{
    object _0, _1, _2;
    

    /** execute.e:1740	end procedure*/
    return;
    ;
}


object _67var_subs(object _x_67486, object _subs_67487)
{
    object _si_67488 = NOVALUE;
    object _33375 = NOVALUE;
    object _33374 = NOVALUE;
    object _33373 = NOVALUE;
    object _33372 = NOVALUE;
    object _33371 = NOVALUE;
    object _33369 = NOVALUE;
    object _33368 = NOVALUE;
    object _33365 = NOVALUE;
    object _33363 = NOVALUE;
    object _33362 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1746		if atom(x) then*/
    _33362 = IS_ATOM(_x_67486);
    if (_33362 == 0)
    {
        _33362 = NOVALUE;
        goto L1; // [8] 17
    }
    else{
        _33362 = NOVALUE;
    }

    /** execute.e:1747			RTFatal("attempt to subscript an atom\n(reading from it)")*/
    RefDS(_33153);
    _67RTFatal(_33153);
L1: 

    /** execute.e:1749		for i = 1 to length(subs) do*/
    if (IS_SEQUENCE(_subs_67487)){
            _33363 = SEQ_PTR(_subs_67487)->length;
    }
    else {
        _33363 = 1;
    }
    {
        object _i_67492;
        _i_67492 = 1LL;
L2: 
        if (_i_67492 > _33363){
            goto L3; // [22] 110
        }

        /** execute.e:1750			si = subs[i]*/
        DeRef(_si_67488);
        _2 = (object)SEQ_PTR(_subs_67487);
        _si_67488 = (object)*(((s1_ptr)_2)->base + _i_67492);
        Ref(_si_67488);

        /** execute.e:1751			if sequence(si) then*/
        _33365 = IS_SEQUENCE(_si_67488);
        if (_33365 == 0)
        {
            _33365 = NOVALUE;
            goto L4; // [40] 49
        }
        else{
            _33365 = NOVALUE;
        }

        /** execute.e:1752				RTFatal("A subscript must be an atom")*/
        RefDS(_33366);
        _67RTFatal(_33366);
L4: 

        /** execute.e:1754			si = floor(si)*/
        _0 = _si_67488;
        if (IS_ATOM_INT(_si_67488))
        _si_67488 = e_floor(_si_67488);
        else
        _si_67488 = unary_op(FLOOR, _si_67488);
        DeRef(_0);

        /** execute.e:1755			if si > length(x) or si < 1 then*/
        if (IS_SEQUENCE(_x_67486)){
                _33368 = SEQ_PTR(_x_67486)->length;
        }
        else {
            _33368 = 1;
        }
        if (IS_ATOM_INT(_si_67488)) {
            _33369 = (_si_67488 > _33368);
        }
        else {
            _33369 = binary_op(GREATER, _si_67488, _33368);
        }
        _33368 = NOVALUE;
        if (IS_ATOM_INT(_33369)) {
            if (_33369 != 0) {
                goto L5; // [63] 76
            }
        }
        else {
            if (DBL_PTR(_33369)->dbl != 0.0) {
                goto L5; // [63] 76
            }
        }
        if (IS_ATOM_INT(_si_67488)) {
            _33371 = (_si_67488 < 1LL);
        }
        else {
            _33371 = binary_op(LESS, _si_67488, 1LL);
        }
        if (_33371 == 0) {
            DeRef(_33371);
            _33371 = NOVALUE;
            goto L6; // [72] 93
        }
        else {
            if (!IS_ATOM_INT(_33371) && DBL_PTR(_33371)->dbl == 0.0){
                DeRef(_33371);
                _33371 = NOVALUE;
                goto L6; // [72] 93
            }
            DeRef(_33371);
            _33371 = NOVALUE;
        }
        DeRef(_33371);
        _33371 = NOVALUE;
L5: 

        /** execute.e:1756				RTFatal(*/
        if (IS_SEQUENCE(_x_67486)){
                _33372 = SEQ_PTR(_x_67486)->length;
        }
        else {
            _33372 = 1;
        }
        Ref(_si_67488);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _si_67488;
        ((intptr_t *)_2)[2] = _33372;
        _33373 = MAKE_SEQ(_1);
        _33372 = NOVALUE;
        _33374 = EPrintf(-9999999, _33161, _33373);
        DeRefDS(_33373);
        _33373 = NOVALUE;
        _67RTFatal(_33374);
        _33374 = NOVALUE;
L6: 

        /** execute.e:1760			x = x[subs[i]]*/
        _2 = (object)SEQ_PTR(_subs_67487);
        _33375 = (object)*(((s1_ptr)_2)->base + _i_67492);
        _0 = _x_67486;
        _2 = (object)SEQ_PTR(_x_67486);
        if (!IS_ATOM_INT(_33375)){
            _x_67486 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33375)->dbl));
        }
        else{
            _x_67486 = (object)*(((s1_ptr)_2)->base + _33375);
        }
        Ref(_x_67486);
        DeRef(_0);

        /** execute.e:1761		end for*/
        _i_67492 = _i_67492 + 1LL;
        goto L2; // [105] 29
L3: 
        ;
    }

    /** execute.e:1762		return x*/
    DeRefDS(_subs_67487);
    DeRef(_si_67488);
    DeRef(_33369);
    _33369 = NOVALUE;
    _33375 = NOVALUE;
    return _x_67486;
    ;
}


void _67opLENGTH()
{
    object _33382 = NOVALUE;
    object _33381 = NOVALUE;
    object _33379 = NOVALUE;
    object _33377 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1767		a = Code[pc+1]*/
    _33377 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33377);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:1768		target = Code[pc+2]*/
    _33379 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33379);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:1769		val[target] = length(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33381 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_SEQUENCE(_33381)){
            _33382 = SEQ_PTR(_33381)->length;
    }
    else {
        _33382 = 1;
    }
    _33381 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33382;
    if( _1 != _33382 ){
        DeRef(_1);
    }
    _33382 = NOVALUE;

    /** execute.e:1770		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:1771	end procedure*/
    _33379 = NOVALUE;
    _33377 = NOVALUE;
    _33381 = NOVALUE;
    return;
    ;
}


void _67opPLENGTH()
{
    object _33395 = NOVALUE;
    object _33394 = NOVALUE;
    object _33393 = NOVALUE;
    object _33391 = NOVALUE;
    object _33390 = NOVALUE;
    object _33388 = NOVALUE;
    object _33386 = NOVALUE;
    object _33384 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1780		a = Code[pc+1]*/
    _33384 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33384);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:1781		target = Code[pc+2]*/
    _33386 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33386);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:1782		lhs_seq_index = val[a][1]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33388 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_33388);
    _67lhs_seq_index_65338 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_67lhs_seq_index_65338)){
        _67lhs_seq_index_65338 = (object)DBL_PTR(_67lhs_seq_index_65338)->dbl;
    }
    _33388 = NOVALUE;

    /** execute.e:1783		lhs_subs = val[a][2..$]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33390 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_SEQUENCE(_33390)){
            _33391 = SEQ_PTR(_33390)->length;
    }
    else {
        _33391 = 1;
    }
    rhs_slice_target = (object_ptr)&_67lhs_subs_65339;
    RHS_Slice(_33390, 2LL, _33391);
    _33390 = NOVALUE;

    /** execute.e:1784		val[target] = length(var_subs(val[lhs_seq_index], lhs_subs))*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33393 = (object)*(((s1_ptr)_2)->base + _67lhs_seq_index_65338);
    Ref(_33393);
    RefDS(_67lhs_subs_65339);
    _33394 = _67var_subs(_33393, _67lhs_subs_65339);
    _33393 = NOVALUE;
    if (IS_SEQUENCE(_33394)){
            _33395 = SEQ_PTR(_33394)->length;
    }
    else {
        _33395 = 1;
    }
    DeRef(_33394);
    _33394 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33395;
    if( _1 != _33395 ){
        DeRef(_1);
    }
    _33395 = NOVALUE;

    /** execute.e:1785		lhs_subs = {}*/
    RefDS(_22218);
    DeRefDS(_67lhs_subs_65339);
    _67lhs_subs_65339 = _22218;

    /** execute.e:1786		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:1787	end procedure*/
    _33394 = NOVALUE;
    _33386 = NOVALUE;
    _33384 = NOVALUE;
    return;
    ;
}


void _67opLHS_SUBS()
{
    object _33405 = NOVALUE;
    object _33404 = NOVALUE;
    object _33403 = NOVALUE;
    object _33401 = NOVALUE;
    object _33399 = NOVALUE;
    object _33397 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1792		a = Code[pc+1] -- base var sequence, or a temp that contains*/
    _33397 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33397);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:1794		b = Code[pc+2] -- subscript*/
    _33399 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _33399);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:1795		target = Code[pc+3] -- temp for storing result*/
    _33401 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33401);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:1798		val[target] = append(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33403 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _33404 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    Ref(_33404);
    Append(&_33405, _33403, _33404);
    _33403 = NOVALUE;
    _33404 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33405;
    if( _1 != _33405 ){
        DeRef(_1);
    }
    _33405 = NOVALUE;

    /** execute.e:1799		pc += 5*/
    _67pc_65330 = _67pc_65330 + 5LL;

    /** execute.e:1800	end procedure*/
    _33401 = NOVALUE;
    _33399 = NOVALUE;
    _33397 = NOVALUE;
    return;
    ;
}


void _67opLHS_SUBS1()
{
    object _33414 = NOVALUE;
    object _33413 = NOVALUE;
    object _33411 = NOVALUE;
    object _33409 = NOVALUE;
    object _33407 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1804		a = Code[pc+1] -- base var sequence, or a temp that contains*/
    _33407 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33407);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:1806		b = Code[pc+2] -- subscript*/
    _33409 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _33409);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:1807		target = Code[pc+3] -- temp for storing result*/
    _33411 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33411);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:1810		val[target] = {a, val[b]}*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33413 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    Ref(_33413);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _67a_65331;
    ((intptr_t *)_2)[2] = _33413;
    _33414 = MAKE_SEQ(_1);
    _33413 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33414;
    if( _1 != _33414 ){
        DeRef(_1);
    }
    _33414 = NOVALUE;

    /** execute.e:1811		pc += 5*/
    _67pc_65330 = _67pc_65330 + 5LL;

    /** execute.e:1812	end procedure*/
    _33411 = NOVALUE;
    _33409 = NOVALUE;
    _33407 = NOVALUE;
    return;
    ;
}


void _67opLHS_SUBS1_COPY()
{
    object _33426 = NOVALUE;
    object _33425 = NOVALUE;
    object _33424 = NOVALUE;
    object _33422 = NOVALUE;
    object _33420 = NOVALUE;
    object _33418 = NOVALUE;
    object _33416 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1819		a = Code[pc+1] -- base var sequence*/
    _33416 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33416);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:1821		b = Code[pc+2] -- subscript*/
    _33418 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _33418);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:1823		target = Code[pc+3] -- temp for storing result*/
    _33420 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33420);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:1825		c = Code[pc+4] -- temp to hold base sequence while it's manipulated*/
    _33422 = _67pc_65330 + 4LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65333 = (object)*(((s1_ptr)_2)->base + _33422);
    if (!IS_ATOM_INT(_67c_65333)){
        _67c_65333 = (object)DBL_PTR(_67c_65333)->dbl;
    }

    /** execute.e:1827		val[c] = val[a]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33424 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    Ref(_33424);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67c_65333);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33424;
    if( _1 != _33424 ){
        DeRef(_1);
    }
    _33424 = NOVALUE;

    /** execute.e:1830		val[target] = {c, val[b]}*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33425 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    Ref(_33425);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _67c_65333;
    ((intptr_t *)_2)[2] = _33425;
    _33426 = MAKE_SEQ(_1);
    _33425 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33426;
    if( _1 != _33426 ){
        DeRef(_1);
    }
    _33426 = NOVALUE;

    /** execute.e:1832		pc += 5*/
    _67pc_65330 = _67pc_65330 + 5LL;

    /** execute.e:1833	end procedure*/
    _33420 = NOVALUE;
    _33418 = NOVALUE;
    _33416 = NOVALUE;
    _33422 = NOVALUE;
    return;
    ;
}


void _67lhs_check_subs(object _seq_67586, object _subs_67587)
{
    object _33442 = NOVALUE;
    object _33441 = NOVALUE;
    object _33440 = NOVALUE;
    object _33438 = NOVALUE;
    object _33437 = NOVALUE;
    object _33435 = NOVALUE;
    object _33433 = NOVALUE;
    object _33432 = NOVALUE;
    object _33430 = NOVALUE;
    object _33428 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1837		if atom(seq) then*/
    _33428 = IS_ATOM(_seq_67586);
    if (_33428 == 0)
    {
        _33428 = NOVALUE;
        goto L1; // [6] 15
    }
    else{
        _33428 = NOVALUE;
    }

    /** execute.e:1838			RTFatal("attempt to subscript an atom\n(assigning to it)")*/
    RefDS(_33429);
    _67RTFatal(_33429);
L1: 

    /** execute.e:1840		if sequence(subs) then*/
    _33430 = IS_SEQUENCE(_subs_67587);
    if (_33430 == 0)
    {
        _33430 = NOVALUE;
        goto L2; // [20] 36
    }
    else{
        _33430 = NOVALUE;
    }

    /** execute.e:1841			RTFatal(*/
    if (IS_SEQUENCE(_seq_67586)){
            _33432 = SEQ_PTR(_seq_67586)->length;
    }
    else {
        _33432 = 1;
    }
    _33433 = EPrintf(-9999999, _33431, _33432);
    _33432 = NOVALUE;
    _67RTFatal(_33433);
    _33433 = NOVALUE;
L2: 

    /** execute.e:1846		subs = floor(subs)*/
    _0 = _subs_67587;
    if (IS_ATOM_INT(_subs_67587))
    _subs_67587 = e_floor(_subs_67587);
    else
    _subs_67587 = unary_op(FLOOR, _subs_67587);
    DeRef(_0);

    /** execute.e:1847		if subs < 1 or subs > length(seq) then*/
    if (IS_ATOM_INT(_subs_67587)) {
        _33435 = (_subs_67587 < 1LL);
    }
    else {
        _33435 = binary_op(LESS, _subs_67587, 1LL);
    }
    if (IS_ATOM_INT(_33435)) {
        if (_33435 != 0) {
            goto L3; // [47] 63
        }
    }
    else {
        if (DBL_PTR(_33435)->dbl != 0.0) {
            goto L3; // [47] 63
        }
    }
    if (IS_SEQUENCE(_seq_67586)){
            _33437 = SEQ_PTR(_seq_67586)->length;
    }
    else {
        _33437 = 1;
    }
    if (IS_ATOM_INT(_subs_67587)) {
        _33438 = (_subs_67587 > _33437);
    }
    else {
        _33438 = binary_op(GREATER, _subs_67587, _33437);
    }
    _33437 = NOVALUE;
    if (_33438 == 0) {
        DeRef(_33438);
        _33438 = NOVALUE;
        goto L4; // [59] 80
    }
    else {
        if (!IS_ATOM_INT(_33438) && DBL_PTR(_33438)->dbl == 0.0){
            DeRef(_33438);
            _33438 = NOVALUE;
            goto L4; // [59] 80
        }
        DeRef(_33438);
        _33438 = NOVALUE;
    }
    DeRef(_33438);
    _33438 = NOVALUE;
L3: 

    /** execute.e:1848			RTFatal(*/
    if (IS_SEQUENCE(_seq_67586)){
            _33440 = SEQ_PTR(_seq_67586)->length;
    }
    else {
        _33440 = 1;
    }
    Ref(_subs_67587);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _subs_67587;
    ((intptr_t *)_2)[2] = _33440;
    _33441 = MAKE_SEQ(_1);
    _33440 = NOVALUE;
    _33442 = EPrintf(-9999999, _33439, _33441);
    DeRefDS(_33441);
    _33441 = NOVALUE;
    _67RTFatal(_33442);
    _33442 = NOVALUE;
L4: 

    /** execute.e:1853	end procedure*/
    DeRef(_seq_67586);
    DeRef(_subs_67587);
    DeRef(_33435);
    _33435 = NOVALUE;
    return;
    ;
}


void _67check_slice(object _seq_67608, object _lower_67609, object _upper_67610)
{
    object _len_67611 = NOVALUE;
    object _33473 = NOVALUE;
    object _33471 = NOVALUE;
    object _33470 = NOVALUE;
    object _33469 = NOVALUE;
    object _33468 = NOVALUE;
    object _33466 = NOVALUE;
    object _33465 = NOVALUE;
    object _33464 = NOVALUE;
    object _33460 = NOVALUE;
    object _33458 = NOVALUE;
    object _33457 = NOVALUE;
    object _33448 = NOVALUE;
    object _33443 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1859		if sequence(lower) then*/
    _33443 = IS_SEQUENCE(_lower_67609);
    if (_33443 == 0)
    {
        _33443 = NOVALUE;
        goto L1; // [6] 15
    }
    else{
        _33443 = NOVALUE;
    }

    /** execute.e:1860			RTFatal("slice lower index is not an atom")*/
    RefDS(_33444);
    _67RTFatal(_33444);
L1: 

    /** execute.e:1862		lower = floor(lower)*/
    _0 = _lower_67609;
    if (IS_ATOM_INT(_lower_67609))
    _lower_67609 = e_floor(_lower_67609);
    else
    _lower_67609 = unary_op(FLOOR, _lower_67609);
    DeRef(_0);

    /** execute.e:1863		if lower < 1 then*/
    if (binary_op_a(GREATEREQ, _lower_67609, 1LL)){
        goto L2; // [22] 32
    }

    /** execute.e:1864			RTFatal("slice lower index is less than 1")*/
    RefDS(_33447);
    _67RTFatal(_33447);
L2: 

    /** execute.e:1867		if sequence(upper) then*/
    _33448 = IS_SEQUENCE(_upper_67610);
    if (_33448 == 0)
    {
        _33448 = NOVALUE;
        goto L3; // [37] 46
    }
    else{
        _33448 = NOVALUE;
    }

    /** execute.e:1868			RTFatal("slice upper index is not an atom")*/
    RefDS(_33449);
    _67RTFatal(_33449);
L3: 

    /** execute.e:1870		upper = floor(upper)*/
    _0 = _upper_67610;
    if (IS_ATOM_INT(_upper_67610))
    _upper_67610 = e_floor(_upper_67610);
    else
    _upper_67610 = unary_op(FLOOR, _upper_67610);
    DeRef(_0);

    /** execute.e:1871		if upper > #FFFF_FFFF then*/
    if (binary_op_a(LESSEQ, _upper_67610, 4294967295LL)){
        goto L4; // [53] 63
    }

    /** execute.e:1872			upper = -2147483645*/
    DeRef(_upper_67610);
    _upper_67610 = -2147483645LL;
L4: 

    /** execute.e:1874		if upper < 0 then*/
    if (binary_op_a(GREATEREQ, _upper_67610, 0LL)){
        goto L5; // [65] 79
    }

    /** execute.e:1875			RTFatal(sprintf("slice upper index is less than 0 (%d)", upper ) )*/
    _33457 = EPrintf(-9999999, _33456, _upper_67610);
    _67RTFatal(_33457);
    _33457 = NOVALUE;
L5: 

    /** execute.e:1878		if atom(seq) then*/
    _33458 = IS_ATOM(_seq_67608);
    if (_33458 == 0)
    {
        _33458 = NOVALUE;
        goto L6; // [84] 93
    }
    else{
        _33458 = NOVALUE;
    }

    /** execute.e:1879			RTFatal("attempt to slice an atom")*/
    RefDS(_33459);
    _67RTFatal(_33459);
L6: 

    /** execute.e:1882		len = upper - lower + 1*/
    if (IS_ATOM_INT(_upper_67610) && IS_ATOM_INT(_lower_67609)) {
        _33460 = _upper_67610 - _lower_67609;
        if ((object)((uintptr_t)_33460 +(uintptr_t) HIGH_BITS) >= 0){
            _33460 = NewDouble((eudouble)_33460);
        }
    }
    else {
        _33460 = binary_op(MINUS, _upper_67610, _lower_67609);
    }
    DeRef(_len_67611);
    if (IS_ATOM_INT(_33460)) {
        _len_67611 = _33460 + 1;
        if (_len_67611 > MAXINT){
            _len_67611 = NewDouble((eudouble)_len_67611);
        }
    }
    else
    _len_67611 = binary_op(PLUS, 1, _33460);
    DeRef(_33460);
    _33460 = NOVALUE;

    /** execute.e:1884		if len < 0 then*/
    if (binary_op_a(GREATEREQ, _len_67611, 0LL)){
        goto L7; // [105] 115
    }

    /** execute.e:1885			RTFatal("slice length is less than 0")*/
    RefDS(_33463);
    _67RTFatal(_33463);
L7: 

    /** execute.e:1888		if lower > length(seq) + 1 or (len > 0 and lower > length(seq)) then*/
    if (IS_SEQUENCE(_seq_67608)){
            _33464 = SEQ_PTR(_seq_67608)->length;
    }
    else {
        _33464 = 1;
    }
    _33465 = _33464 + 1;
    _33464 = NOVALUE;
    if (IS_ATOM_INT(_lower_67609)) {
        _33466 = (_lower_67609 > _33465);
    }
    else {
        _33466 = binary_op(GREATER, _lower_67609, _33465);
    }
    _33465 = NOVALUE;
    if (IS_ATOM_INT(_33466)) {
        if (_33466 != 0) {
            goto L8; // [128] 156
        }
    }
    else {
        if (DBL_PTR(_33466)->dbl != 0.0) {
            goto L8; // [128] 156
        }
    }
    if (IS_ATOM_INT(_len_67611)) {
        _33468 = (_len_67611 > 0LL);
    }
    else {
        _33468 = (DBL_PTR(_len_67611)->dbl > (eudouble)0LL);
    }
    if (_33468 == 0) {
        DeRef(_33469);
        _33469 = 0;
        goto L9; // [136] 151
    }
    if (IS_SEQUENCE(_seq_67608)){
            _33470 = SEQ_PTR(_seq_67608)->length;
    }
    else {
        _33470 = 1;
    }
    if (IS_ATOM_INT(_lower_67609)) {
        _33471 = (_lower_67609 > _33470);
    }
    else {
        _33471 = binary_op(GREATER, _lower_67609, _33470);
    }
    _33470 = NOVALUE;
    if (IS_ATOM_INT(_33471))
    _33469 = (_33471 != 0);
    else
    _33469 = DBL_PTR(_33471)->dbl != 0.0;
L9: 
    if (_33469 == 0)
    {
        _33469 = NOVALUE;
        goto LA; // [152] 162
    }
    else{
        _33469 = NOVALUE;
    }
L8: 

    /** execute.e:1889			RTFatal("slice starts past end of sequence")*/
    RefDS(_33472);
    _67RTFatal(_33472);
LA: 

    /** execute.e:1892		if upper > length(seq) then*/
    if (IS_SEQUENCE(_seq_67608)){
            _33473 = SEQ_PTR(_seq_67608)->length;
    }
    else {
        _33473 = 1;
    }
    if (binary_op_a(LESSEQ, _upper_67610, _33473)){
        _33473 = NOVALUE;
        goto LB; // [167] 177
    }
    _33473 = NOVALUE;

    /** execute.e:1893			RTFatal("slice ends past end of sequence")*/
    RefDS(_33475);
    _67RTFatal(_33475);
LB: 

    /** execute.e:1895	end procedure*/
    DeRef(_seq_67608);
    DeRef(_lower_67609);
    DeRef(_upper_67610);
    DeRef(_len_67611);
    DeRef(_33466);
    _33466 = NOVALUE;
    DeRef(_33468);
    _33468 = NOVALUE;
    DeRef(_33471);
    _33471 = NOVALUE;
    return;
    ;
}


void _67lhs_check_slice(object _seq_67656, object _lower_67657, object _upper_67658, object _rhs_67659)
{
    object _len_67660 = NOVALUE;
    object _33483 = NOVALUE;
    object _33482 = NOVALUE;
    object _33481 = NOVALUE;
    object _33480 = NOVALUE;
    object _33478 = NOVALUE;
    object _33477 = NOVALUE;
    object _33476 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1901		check_slice(seq, lower, upper)*/
    Ref(_seq_67656);
    Ref(_lower_67657);
    Ref(_upper_67658);
    _67check_slice(_seq_67656, _lower_67657, _upper_67658);

    /** execute.e:1903		len = floor(upper) - floor(lower) + 1*/
    if (IS_ATOM_INT(_upper_67658))
    _33476 = e_floor(_upper_67658);
    else
    _33476 = unary_op(FLOOR, _upper_67658);
    if (IS_ATOM_INT(_lower_67657))
    _33477 = e_floor(_lower_67657);
    else
    _33477 = unary_op(FLOOR, _lower_67657);
    if (IS_ATOM_INT(_33476) && IS_ATOM_INT(_33477)) {
        _33478 = _33476 - _33477;
        if ((object)((uintptr_t)_33478 +(uintptr_t) HIGH_BITS) >= 0){
            _33478 = NewDouble((eudouble)_33478);
        }
    }
    else {
        _33478 = binary_op(MINUS, _33476, _33477);
    }
    DeRef(_33476);
    _33476 = NOVALUE;
    DeRef(_33477);
    _33477 = NOVALUE;
    DeRef(_len_67660);
    if (IS_ATOM_INT(_33478)) {
        _len_67660 = _33478 + 1;
        if (_len_67660 > MAXINT){
            _len_67660 = NewDouble((eudouble)_len_67660);
        }
    }
    else
    _len_67660 = binary_op(PLUS, 1, _33478);
    DeRef(_33478);
    _33478 = NOVALUE;

    /** execute.e:1905		if sequence(rhs) and length(rhs) != len then*/
    _33480 = IS_SEQUENCE(_rhs_67659);
    if (_33480 == 0) {
        goto L1; // [29] 50
    }
    if (IS_SEQUENCE(_rhs_67659)){
            _33482 = SEQ_PTR(_rhs_67659)->length;
    }
    else {
        _33482 = 1;
    }
    if (IS_ATOM_INT(_len_67660)) {
        _33483 = (_33482 != _len_67660);
    }
    else {
        _33483 = ((eudouble)_33482 != DBL_PTR(_len_67660)->dbl);
    }
    _33482 = NOVALUE;
    if (_33483 == 0)
    {
        DeRef(_33483);
        _33483 = NOVALUE;
        goto L1; // [41] 50
    }
    else{
        DeRef(_33483);
        _33483 = NOVALUE;
    }

    /** execute.e:1906			RTFatal("lengths do not match on assignment to slice")*/
    RefDS(_33484);
    _67RTFatal(_33484);
L1: 

    /** execute.e:1908	end procedure*/
    DeRef(_seq_67656);
    DeRef(_lower_67657);
    DeRef(_upper_67658);
    DeRef(_rhs_67659);
    DeRef(_len_67660);
    return;
    ;
}


object _67var_slice(object _x_67673, object _subs_67674, object _lower_67675, object _upper_67676)
{
    object _33503 = NOVALUE;
    object _33501 = NOVALUE;
    object _33500 = NOVALUE;
    object _33499 = NOVALUE;
    object _33498 = NOVALUE;
    object _33497 = NOVALUE;
    object _33496 = NOVALUE;
    object _33495 = NOVALUE;
    object _33493 = NOVALUE;
    object _33492 = NOVALUE;
    object _33491 = NOVALUE;
    object _33488 = NOVALUE;
    object _33487 = NOVALUE;
    object _33486 = NOVALUE;
    object _33485 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1912		if atom(x) then*/
    _33485 = IS_ATOM(_x_67673);
    if (_33485 == 0)
    {
        _33485 = NOVALUE;
        goto L1; // [8] 17
    }
    else{
        _33485 = NOVALUE;
    }

    /** execute.e:1913			RTFatal("attempt to subscript an atom\n(reading from it)")*/
    RefDS(_33153);
    _67RTFatal(_33153);
L1: 

    /** execute.e:1915		for i = 1 to length(subs) do*/
    if (IS_SEQUENCE(_subs_67674)){
            _33486 = SEQ_PTR(_subs_67674)->length;
    }
    else {
        _33486 = 1;
    }
    {
        object _i_67680;
        _i_67680 = 1LL;
L2: 
        if (_i_67680 > _33486){
            goto L3; // [22] 122
        }

        /** execute.e:1916			if sequence(subs[i]) then*/
        _2 = (object)SEQ_PTR(_subs_67674);
        _33487 = (object)*(((s1_ptr)_2)->base + _i_67680);
        _33488 = IS_SEQUENCE(_33487);
        _33487 = NOVALUE;
        if (_33488 == 0)
        {
            _33488 = NOVALUE;
            goto L4; // [38] 47
        }
        else{
            _33488 = NOVALUE;
        }

        /** execute.e:1917				RTFatal("subscript must be an atom")*/
        RefDS(_33489);
        _67RTFatal(_33489);
L4: 

        /** execute.e:1919			subs = floor(subs)*/
        _0 = _subs_67674;
        _subs_67674 = unary_op(FLOOR, _subs_67674);
        DeRefDS(_0);

        /** execute.e:1920			if subs[i] > length(x) or subs[i] < 1 then*/
        _2 = (object)SEQ_PTR(_subs_67674);
        _33491 = (object)*(((s1_ptr)_2)->base + _i_67680);
        if (IS_SEQUENCE(_x_67673)){
                _33492 = SEQ_PTR(_x_67673)->length;
        }
        else {
            _33492 = 1;
        }
        if (IS_ATOM_INT(_33491)) {
            _33493 = (_33491 > _33492);
        }
        else {
            _33493 = binary_op(GREATER, _33491, _33492);
        }
        _33491 = NOVALUE;
        _33492 = NOVALUE;
        if (IS_ATOM_INT(_33493)) {
            if (_33493 != 0) {
                goto L5; // [67] 84
            }
        }
        else {
            if (DBL_PTR(_33493)->dbl != 0.0) {
                goto L5; // [67] 84
            }
        }
        _2 = (object)SEQ_PTR(_subs_67674);
        _33495 = (object)*(((s1_ptr)_2)->base + _i_67680);
        if (IS_ATOM_INT(_33495)) {
            _33496 = (_33495 < 1LL);
        }
        else {
            _33496 = binary_op(LESS, _33495, 1LL);
        }
        _33495 = NOVALUE;
        if (_33496 == 0) {
            DeRef(_33496);
            _33496 = NOVALUE;
            goto L6; // [80] 105
        }
        else {
            if (!IS_ATOM_INT(_33496) && DBL_PTR(_33496)->dbl == 0.0){
                DeRef(_33496);
                _33496 = NOVALUE;
                goto L6; // [80] 105
            }
            DeRef(_33496);
            _33496 = NOVALUE;
        }
        DeRef(_33496);
        _33496 = NOVALUE;
L5: 

        /** execute.e:1921				RTFatal(*/
        _2 = (object)SEQ_PTR(_subs_67674);
        _33497 = (object)*(((s1_ptr)_2)->base + _i_67680);
        if (IS_SEQUENCE(_x_67673)){
                _33498 = SEQ_PTR(_x_67673)->length;
        }
        else {
            _33498 = 1;
        }
        Ref(_33497);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _33497;
        ((intptr_t *)_2)[2] = _33498;
        _33499 = MAKE_SEQ(_1);
        _33498 = NOVALUE;
        _33497 = NOVALUE;
        _33500 = EPrintf(-9999999, _33161, _33499);
        DeRefDS(_33499);
        _33499 = NOVALUE;
        _67RTFatal(_33500);
        _33500 = NOVALUE;
L6: 

        /** execute.e:1925			x = x[subs[i]]*/
        _2 = (object)SEQ_PTR(_subs_67674);
        _33501 = (object)*(((s1_ptr)_2)->base + _i_67680);
        _0 = _x_67673;
        _2 = (object)SEQ_PTR(_x_67673);
        if (!IS_ATOM_INT(_33501)){
            _x_67673 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33501)->dbl));
        }
        else{
            _x_67673 = (object)*(((s1_ptr)_2)->base + _33501);
        }
        Ref(_x_67673);
        DeRef(_0);

        /** execute.e:1926		end for*/
        _i_67680 = _i_67680 + 1LL;
        goto L2; // [117] 29
L3: 
        ;
    }

    /** execute.e:1927		check_slice(x, lower, upper)*/
    Ref(_x_67673);
    Ref(_lower_67675);
    Ref(_upper_67676);
    _67check_slice(_x_67673, _lower_67675, _upper_67676);

    /** execute.e:1928		return x[lower..upper]*/
    rhs_slice_target = (object_ptr)&_33503;
    RHS_Slice(_x_67673, _lower_67675, _upper_67676);
    DeRef(_x_67673);
    DeRefDS(_subs_67674);
    DeRef(_lower_67675);
    DeRef(_upper_67676);
    DeRef(_33493);
    _33493 = NOVALUE;
    _33501 = NOVALUE;
    return _33503;
    ;
}


object _67assign_subs(object _x_67703, object _subs_67704, object _rhs_val_67705)
{
    object _33514 = NOVALUE;
    object _33513 = NOVALUE;
    object _33512 = NOVALUE;
    object _33511 = NOVALUE;
    object _33510 = NOVALUE;
    object _33509 = NOVALUE;
    object _33508 = NOVALUE;
    object _33507 = NOVALUE;
    object _33505 = NOVALUE;
    object _33504 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1933		lhs_check_subs(x, subs[1])*/
    _2 = (object)SEQ_PTR(_subs_67704);
    _33504 = (object)*(((s1_ptr)_2)->base + 1LL);
    RefDS(_x_67703);
    Ref(_33504);
    _67lhs_check_subs(_x_67703, _33504);
    _33504 = NOVALUE;

    /** execute.e:1934		if length(subs) = 1 then*/
    if (IS_SEQUENCE(_subs_67704)){
            _33505 = SEQ_PTR(_subs_67704)->length;
    }
    else {
        _33505 = 1;
    }
    if (_33505 != 1LL)
    goto L1; // [20] 37

    /** execute.e:1935			x[subs[1]] = rhs_val*/
    _2 = (object)SEQ_PTR(_subs_67704);
    _33507 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_rhs_val_67705);
    _2 = (object)SEQ_PTR(_x_67703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _x_67703 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33507))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33507)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33507);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _rhs_val_67705;
    DeRef(_1);
    goto L2; // [34] 73
L1: 

    /** execute.e:1937			x[subs[1]] = assign_subs(x[subs[1]], subs[2..$], rhs_val)*/
    _2 = (object)SEQ_PTR(_subs_67704);
    _33508 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_subs_67704);
    _33509 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_x_67703);
    if (!IS_ATOM_INT(_33509)){
        _33510 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33509)->dbl));
    }
    else{
        _33510 = (object)*(((s1_ptr)_2)->base + _33509);
    }
    if (IS_SEQUENCE(_subs_67704)){
            _33511 = SEQ_PTR(_subs_67704)->length;
    }
    else {
        _33511 = 1;
    }
    rhs_slice_target = (object_ptr)&_33512;
    RHS_Slice(_subs_67704, 2LL, _33511);
    Ref(_rhs_val_67705);
    DeRef(_33513);
    _33513 = _rhs_val_67705;
    Ref(_33510);
    _33514 = _67assign_subs(_33510, _33512, _33513);
    _33510 = NOVALUE;
    _33512 = NOVALUE;
    _33513 = NOVALUE;
    _2 = (object)SEQ_PTR(_x_67703);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _x_67703 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33508))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33508)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33508);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33514;
    if( _1 != _33514 ){
        DeRef(_1);
    }
    _33514 = NOVALUE;
L2: 

    /** execute.e:1939		return x*/
    DeRefDS(_subs_67704);
    DeRef(_rhs_val_67705);
    _33508 = NOVALUE;
    _33507 = NOVALUE;
    _33509 = NOVALUE;
    return _x_67703;
    ;
}


object _67assign_slice(object _x_67721, object _subs_67722, object _lower_67723, object _upper_67724, object _rhs_val_67725)
{
    object _33531 = NOVALUE;
    object _33530 = NOVALUE;
    object _33529 = NOVALUE;
    object _33528 = NOVALUE;
    object _33527 = NOVALUE;
    object _33526 = NOVALUE;
    object _33525 = NOVALUE;
    object _33524 = NOVALUE;
    object _33523 = NOVALUE;
    object _33521 = NOVALUE;
    object _33520 = NOVALUE;
    object _33519 = NOVALUE;
    object _33518 = NOVALUE;
    object _33516 = NOVALUE;
    object _33515 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1946		lhs_check_subs(x, subs[1])*/
    _2 = (object)SEQ_PTR(_subs_67722);
    _33515 = (object)*(((s1_ptr)_2)->base + 1LL);
    RefDS(_x_67721);
    Ref(_33515);
    _67lhs_check_subs(_x_67721, _33515);
    _33515 = NOVALUE;

    /** execute.e:1947		if length(subs) = 1 then*/
    if (IS_SEQUENCE(_subs_67722)){
            _33516 = SEQ_PTR(_subs_67722)->length;
    }
    else {
        _33516 = 1;
    }
    if (_33516 != 1LL)
    goto L1; // [20] 59

    /** execute.e:1948			lhs_check_slice(x[subs[1]],lower,upper,rhs_val)*/
    _2 = (object)SEQ_PTR(_subs_67722);
    _33518 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_x_67721);
    if (!IS_ATOM_INT(_33518)){
        _33519 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33518)->dbl));
    }
    else{
        _33519 = (object)*(((s1_ptr)_2)->base + _33518);
    }
    Ref(_33519);
    Ref(_lower_67723);
    Ref(_upper_67724);
    Ref(_rhs_val_67725);
    _67lhs_check_slice(_33519, _lower_67723, _upper_67724, _rhs_val_67725);
    _33519 = NOVALUE;

    /** execute.e:1949			x[subs[1]][lower..upper] = rhs_val*/
    _2 = (object)SEQ_PTR(_subs_67722);
    _33520 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_x_67721);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _x_67721 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33520))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33520)->dbl));
    else
    _3 = (object)(_33520 + ((s1_ptr)_2)->base);
    assign_slice_seq = (s1_ptr *)_3;
    AssignSlice(_lower_67723, _upper_67724, _rhs_val_67725);
    goto L2; // [56] 103
L1: 

    /** execute.e:1951			x[subs[1]] = assign_slice(x[subs[1]], subs[2..$], lower, upper, rhs_val)*/
    _2 = (object)SEQ_PTR(_subs_67722);
    _33523 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_subs_67722);
    _33524 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_x_67721);
    if (!IS_ATOM_INT(_33524)){
        _33525 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33524)->dbl));
    }
    else{
        _33525 = (object)*(((s1_ptr)_2)->base + _33524);
    }
    if (IS_SEQUENCE(_subs_67722)){
            _33526 = SEQ_PTR(_subs_67722)->length;
    }
    else {
        _33526 = 1;
    }
    rhs_slice_target = (object_ptr)&_33527;
    RHS_Slice(_subs_67722, 2LL, _33526);
    Ref(_lower_67723);
    DeRef(_33528);
    _33528 = _lower_67723;
    Ref(_upper_67724);
    DeRef(_33529);
    _33529 = _upper_67724;
    Ref(_rhs_val_67725);
    DeRef(_33530);
    _33530 = _rhs_val_67725;
    Ref(_33525);
    _33531 = _67assign_slice(_33525, _33527, _33528, _33529, _33530);
    _33525 = NOVALUE;
    _33527 = NOVALUE;
    _33528 = NOVALUE;
    _33529 = NOVALUE;
    _33530 = NOVALUE;
    _2 = (object)SEQ_PTR(_x_67721);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _x_67721 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33523))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33523)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33523);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33531;
    if( _1 != _33531 ){
        DeRef(_1);
    }
    _33531 = NOVALUE;
L2: 

    /** execute.e:1953		return x*/
    DeRefDS(_subs_67722);
    DeRef(_lower_67723);
    DeRef(_upper_67724);
    DeRef(_rhs_val_67725);
    DeRef(_33521);
    _33521 = NOVALUE;
    _33523 = NOVALUE;
    _33524 = NOVALUE;
    _33518 = NOVALUE;
    _33520 = NOVALUE;
    return _x_67721;
    ;
}


void _67opASSIGN_SUBS()
{
    object _x_67747 = NOVALUE;
    object _subs_67748 = NOVALUE;
    object _33545 = NOVALUE;
    object _33542 = NOVALUE;
    object _33539 = NOVALUE;
    object _33537 = NOVALUE;
    object _33536 = NOVALUE;
    object _33534 = NOVALUE;
    object _33532 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1960		a = Code[pc+1]  -- the sequence*/
    _33532 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33532);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:1961		b = Code[pc+2]  -- the subscript*/
    _33534 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _33534);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:1962		if sequence(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33536 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _33537 = IS_SEQUENCE(_33536);
    _33536 = NOVALUE;
    if (_33537 == 0)
    {
        _33537 = NOVALUE;
        goto L1; // [46] 55
    }
    else{
        _33537 = NOVALUE;
    }

    /** execute.e:1963			RTFatal("subscript must be an atom\n(assigning to subscript of a sequence)")*/
    RefDS(_33538);
    _67RTFatal(_33538);
L1: 

    /** execute.e:1966		c = Code[pc+3]  -- the RHS value*/
    _33539 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65333 = (object)*(((s1_ptr)_2)->base + _33539);
    if (!IS_ATOM_INT(_67c_65333)){
        _67c_65333 = (object)DBL_PTR(_67c_65333)->dbl;
    }

    /** execute.e:1967		x = val[a] -- avoid lingering ref count on val[a]*/
    DeRef(_x_67747);
    _2 = (object)SEQ_PTR(_67val_65340);
    _x_67747 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    Ref(_x_67747);

    /** execute.e:1968		lhs_check_subs(x, val[b])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33542 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    Ref(_x_67747);
    Ref(_33542);
    _67lhs_check_subs(_x_67747, _33542);
    _33542 = NOVALUE;

    /** execute.e:1969		x = val[c]*/
    DeRef(_x_67747);
    _2 = (object)SEQ_PTR(_67val_65340);
    _x_67747 = (object)*(((s1_ptr)_2)->base + _67c_65333);
    Ref(_x_67747);

    /** execute.e:1970		subs = val[b]*/
    DeRef(_subs_67748);
    _2 = (object)SEQ_PTR(_67val_65340);
    _subs_67748 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    Ref(_subs_67748);

    /** execute.e:1971		val[a][subs] = x  -- single LHS subscript*/
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67a_65331 + ((s1_ptr)_2)->base);
    Ref(_x_67747);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_subs_67748))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_subs_67748)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _subs_67748);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _x_67747;
    DeRef(_1);
    _33545 = NOVALUE;

    /** execute.e:1972		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:1973	end procedure*/
    DeRef(_x_67747);
    DeRef(_subs_67748);
    DeRef(_33534);
    _33534 = NOVALUE;
    DeRef(_33532);
    _33532 = NOVALUE;
    _33539 = NOVALUE;
    return;
    ;
}


void _67opPASSIGN_SUBS()
{
    object _33565 = NOVALUE;
    object _33564 = NOVALUE;
    object _33563 = NOVALUE;
    object _33562 = NOVALUE;
    object _33561 = NOVALUE;
    object _33559 = NOVALUE;
    object _33558 = NOVALUE;
    object _33556 = NOVALUE;
    object _33554 = NOVALUE;
    object _33553 = NOVALUE;
    object _33552 = NOVALUE;
    object _33550 = NOVALUE;
    object _33548 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1978		a = Code[pc+1]*/
    _33548 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33548);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:1979		b = Code[pc+2]  -- subscript*/
    _33550 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _33550);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:1980		if sequence(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33552 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _33553 = IS_SEQUENCE(_33552);
    _33552 = NOVALUE;
    if (_33553 == 0)
    {
        _33553 = NOVALUE;
        goto L1; // [46] 55
    }
    else{
        _33553 = NOVALUE;
    }

    /** execute.e:1981			RTFatal("subscript must be an atom\n(assigning to subscript of a sequence)")*/
    RefDS(_33538);
    _67RTFatal(_33538);
L1: 

    /** execute.e:1983		c = Code[pc+3]  -- RHS value*/
    _33554 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65333 = (object)*(((s1_ptr)_2)->base + _33554);
    if (!IS_ATOM_INT(_67c_65333)){
        _67c_65333 = (object)DBL_PTR(_67c_65333)->dbl;
    }

    /** execute.e:1986		lhs_seq_index = val[a][1]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33556 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_33556);
    _67lhs_seq_index_65338 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_67lhs_seq_index_65338)){
        _67lhs_seq_index_65338 = (object)DBL_PTR(_67lhs_seq_index_65338)->dbl;
    }
    _33556 = NOVALUE;

    /** execute.e:1987		lhs_subs = val[a][2..$]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33558 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_SEQUENCE(_33558)){
            _33559 = SEQ_PTR(_33558)->length;
    }
    else {
        _33559 = 1;
    }
    rhs_slice_target = (object_ptr)&_67lhs_subs_65339;
    RHS_Slice(_33558, 2LL, _33559);
    _33558 = NOVALUE;

    /** execute.e:1988		val[lhs_seq_index] = assign_subs(val[lhs_seq_index],*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33561 = (object)*(((s1_ptr)_2)->base + _67lhs_seq_index_65338);
    _2 = (object)SEQ_PTR(_67val_65340);
    _33562 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_SEQUENCE(_67lhs_subs_65339) && IS_ATOM(_33562)) {
        Ref(_33562);
        Append(&_33563, _67lhs_subs_65339, _33562);
    }
    else if (IS_ATOM(_67lhs_subs_65339) && IS_SEQUENCE(_33562)) {
    }
    else {
        Concat((object_ptr)&_33563, _67lhs_subs_65339, _33562);
    }
    _33562 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    _33564 = (object)*(((s1_ptr)_2)->base + _67c_65333);
    Ref(_33561);
    Ref(_33564);
    _33565 = _67assign_subs(_33561, _33563, _33564);
    _33561 = NOVALUE;
    _33563 = NOVALUE;
    _33564 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67lhs_seq_index_65338);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33565;
    if( _1 != _33565 ){
        DeRef(_1);
    }
    _33565 = NOVALUE;

    /** execute.e:1991		lhs_subs = {}*/
    RefDS(_22218);
    DeRefDS(_67lhs_subs_65339);
    _67lhs_subs_65339 = _22218;

    /** execute.e:1992		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:1993	end procedure*/
    DeRef(_33550);
    _33550 = NOVALUE;
    _33554 = NOVALUE;
    DeRef(_33548);
    _33548 = NOVALUE;
    return;
    ;
}


void _67opASSIGN_OP_SUBS()
{
    object _x_67796 = NOVALUE;
    object _33576 = NOVALUE;
    object _33575 = NOVALUE;
    object _33574 = NOVALUE;
    object _33571 = NOVALUE;
    object _33569 = NOVALUE;
    object _33567 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1999		a = Code[pc+1]*/
    _33567 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33567);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2000		b = Code[pc+2]*/
    _33569 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _33569);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2001		target = Code[pc+3]*/
    _33571 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33571);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2003		lhs_subs = {}*/
    RefDS(_22218);
    DeRef(_67lhs_subs_65339);
    _67lhs_subs_65339 = _22218;

    /** execute.e:2004		x = val[a]*/
    DeRef(_x_67796);
    _2 = (object)SEQ_PTR(_67val_65340);
    _x_67796 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    Ref(_x_67796);

    /** execute.e:2005		val[target] = var_subs(x, lhs_subs & val[b])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33574 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_SEQUENCE(_67lhs_subs_65339) && IS_ATOM(_33574)) {
        Ref(_33574);
        Append(&_33575, _67lhs_subs_65339, _33574);
    }
    else if (IS_ATOM(_67lhs_subs_65339) && IS_SEQUENCE(_33574)) {
    }
    else {
        Concat((object_ptr)&_33575, _67lhs_subs_65339, _33574);
    }
    _33574 = NOVALUE;
    Ref(_x_67796);
    _33576 = _67var_subs(_x_67796, _33575);
    _33575 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33576;
    if( _1 != _33576 ){
        DeRef(_1);
    }
    _33576 = NOVALUE;

    /** execute.e:2006		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:2007	end procedure*/
    DeRef(_x_67796);
    _33567 = NOVALUE;
    _33571 = NOVALUE;
    _33569 = NOVALUE;
    return;
    ;
}


void _67opPASSIGN_OP_SUBS()
{
    object _33595 = NOVALUE;
    object _33594 = NOVALUE;
    object _33593 = NOVALUE;
    object _33592 = NOVALUE;
    object _33591 = NOVALUE;
    object _33590 = NOVALUE;
    object _33589 = NOVALUE;
    object _33587 = NOVALUE;
    object _33586 = NOVALUE;
    object _33584 = NOVALUE;
    object _33582 = NOVALUE;
    object _33580 = NOVALUE;
    object _33578 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2011		a = Code[pc+1]*/
    _33578 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33578);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2012		b = Code[pc+2]*/
    _33580 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _33580);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2013		target = Code[pc+3]*/
    _33582 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33582);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2015		lhs_seq_index = val[a][1]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33584 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_33584);
    _67lhs_seq_index_65338 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_67lhs_seq_index_65338)){
        _67lhs_seq_index_65338 = (object)DBL_PTR(_67lhs_seq_index_65338)->dbl;
    }
    _33584 = NOVALUE;

    /** execute.e:2016		lhs_subs = val[a][2..$]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33586 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_SEQUENCE(_33586)){
            _33587 = SEQ_PTR(_33586)->length;
    }
    else {
        _33587 = 1;
    }
    rhs_slice_target = (object_ptr)&_67lhs_subs_65339;
    RHS_Slice(_33586, 2LL, _33587);
    _33586 = NOVALUE;

    /** execute.e:2017		Code[pc+9] = Code[pc+1] -- patch upcoming op*/
    _33589 = _67pc_65330 + 9LL;
    if ((object)((uintptr_t)_33589 + (uintptr_t)HIGH_BITS) >= 0){
        _33589 = NewDouble((eudouble)_33589);
    }
    _33590 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33591 = (object)*(((s1_ptr)_2)->base + _33590);
    Ref(_33591);
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33589))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33589)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33589);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33591;
    if( _1 != _33591 ){
        DeRef(_1);
    }
    _33591 = NOVALUE;

    /** execute.e:2018		val[target] = var_subs(val[lhs_seq_index], lhs_subs & val[b])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33592 = (object)*(((s1_ptr)_2)->base + _67lhs_seq_index_65338);
    _2 = (object)SEQ_PTR(_67val_65340);
    _33593 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_SEQUENCE(_67lhs_subs_65339) && IS_ATOM(_33593)) {
        Ref(_33593);
        Append(&_33594, _67lhs_subs_65339, _33593);
    }
    else if (IS_ATOM(_67lhs_subs_65339) && IS_SEQUENCE(_33593)) {
    }
    else {
        Concat((object_ptr)&_33594, _67lhs_subs_65339, _33593);
    }
    _33593 = NOVALUE;
    Ref(_33592);
    _33595 = _67var_subs(_33592, _33594);
    _33592 = NOVALUE;
    _33594 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33595;
    if( _1 != _33595 ){
        DeRef(_1);
    }
    _33595 = NOVALUE;

    /** execute.e:2019		lhs_subs = {}*/
    RefDS(_22218);
    DeRefDS(_67lhs_subs_65339);
    _67lhs_subs_65339 = _22218;

    /** execute.e:2020		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:2021	end procedure*/
    DeRef(_33589);
    _33589 = NOVALUE;
    _33590 = NOVALUE;
    _33580 = NOVALUE;
    _33578 = NOVALUE;
    _33582 = NOVALUE;
    return;
    ;
}


void _67opASSIGN_OP_SLICE()
{
    object _x_67839 = NOVALUE;
    object _33620 = NOVALUE;
    object _33619 = NOVALUE;
    object _33618 = NOVALUE;
    object _33616 = NOVALUE;
    object _33614 = NOVALUE;
    object _33613 = NOVALUE;
    object _33612 = NOVALUE;
    object _33611 = NOVALUE;
    object _33610 = NOVALUE;
    object _33609 = NOVALUE;
    object _33608 = NOVALUE;
    object _33607 = NOVALUE;
    object _33605 = NOVALUE;
    object _33604 = NOVALUE;
    object _33603 = NOVALUE;
    object _33602 = NOVALUE;
    object _33600 = NOVALUE;
    object _33597 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2027		a = Code[pc+1]*/
    _33597 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33597);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2028		x = val[a]*/
    DeRef(_x_67839);
    _2 = (object)SEQ_PTR(_67val_65340);
    _x_67839 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    Ref(_x_67839);

    /** execute.e:2029		b = Code[pc+2]*/
    _33600 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _33600);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2030		if floor(val[b]) > length(x) or floor(val[b]) < 1 then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33602 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_ATOM_INT(_33602))
    _33603 = e_floor(_33602);
    else
    _33603 = unary_op(FLOOR, _33602);
    _33602 = NOVALUE;
    if (IS_SEQUENCE(_x_67839)){
            _33604 = SEQ_PTR(_x_67839)->length;
    }
    else {
        _33604 = 1;
    }
    if (IS_ATOM_INT(_33603)) {
        _33605 = (_33603 > _33604);
    }
    else {
        _33605 = binary_op(GREATER, _33603, _33604);
    }
    DeRef(_33603);
    _33603 = NOVALUE;
    _33604 = NOVALUE;
    if (IS_ATOM_INT(_33605)) {
        if (_33605 != 0) {
            goto L1; // [63] 87
        }
    }
    else {
        if (DBL_PTR(_33605)->dbl != 0.0) {
            goto L1; // [63] 87
        }
    }
    _2 = (object)SEQ_PTR(_67val_65340);
    _33607 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_ATOM_INT(_33607))
    _33608 = e_floor(_33607);
    else
    _33608 = unary_op(FLOOR, _33607);
    _33607 = NOVALUE;
    if (IS_ATOM_INT(_33608)) {
        _33609 = (_33608 < 1LL);
    }
    else {
        _33609 = binary_op(LESS, _33608, 1LL);
    }
    DeRef(_33608);
    _33608 = NOVALUE;
    if (_33609 == 0) {
        DeRef(_33609);
        _33609 = NOVALUE;
        goto L2; // [83] 112
    }
    else {
        if (!IS_ATOM_INT(_33609) && DBL_PTR(_33609)->dbl == 0.0){
            DeRef(_33609);
            _33609 = NOVALUE;
            goto L2; // [83] 112
        }
        DeRef(_33609);
        _33609 = NOVALUE;
    }
    DeRef(_33609);
    _33609 = NOVALUE;
L1: 

    /** execute.e:2031			RTFatal(*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33610 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_SEQUENCE(_x_67839)){
            _33611 = SEQ_PTR(_x_67839)->length;
    }
    else {
        _33611 = 1;
    }
    Ref(_33610);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _33610;
    ((intptr_t *)_2)[2] = _33611;
    _33612 = MAKE_SEQ(_1);
    _33611 = NOVALUE;
    _33610 = NOVALUE;
    _33613 = EPrintf(-9999999, _33161, _33612);
    DeRefDS(_33612);
    _33612 = NOVALUE;
    _67RTFatal(_33613);
    _33613 = NOVALUE;
L2: 

    /** execute.e:2035		c = Code[pc+3]*/
    _33614 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65333 = (object)*(((s1_ptr)_2)->base + _33614);
    if (!IS_ATOM_INT(_67c_65333)){
        _67c_65333 = (object)DBL_PTR(_67c_65333)->dbl;
    }

    /** execute.e:2036		target = Code[pc+4]*/
    _33616 = _67pc_65330 + 4LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33616);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2037		val[target] = var_slice(x, {}, val[b], val[c])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33618 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _2 = (object)SEQ_PTR(_67val_65340);
    _33619 = (object)*(((s1_ptr)_2)->base + _67c_65333);
    Ref(_x_67839);
    RefDS(_22218);
    Ref(_33618);
    Ref(_33619);
    _33620 = _67var_slice(_x_67839, _22218, _33618, _33619);
    _33618 = NOVALUE;
    _33619 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33620;
    if( _1 != _33620 ){
        DeRef(_1);
    }
    _33620 = NOVALUE;

    /** execute.e:2038		pc += 5*/
    _67pc_65330 = _67pc_65330 + 5LL;

    /** execute.e:2039	end procedure*/
    DeRef(_x_67839);
    DeRef(_33600);
    _33600 = NOVALUE;
    DeRef(_33597);
    _33597 = NOVALUE;
    _33616 = NOVALUE;
    DeRef(_33605);
    _33605 = NOVALUE;
    _33614 = NOVALUE;
    return;
    ;
}


void _67opPASSIGN_OP_SLICE()
{
    object _x_67872 = NOVALUE;
    object _33640 = NOVALUE;
    object _33639 = NOVALUE;
    object _33638 = NOVALUE;
    object _33637 = NOVALUE;
    object _33636 = NOVALUE;
    object _33635 = NOVALUE;
    object _33634 = NOVALUE;
    object _33632 = NOVALUE;
    object _33629 = NOVALUE;
    object _33627 = NOVALUE;
    object _33625 = NOVALUE;
    object _33622 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2045		a = Code[pc+1]*/
    _33622 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33622);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2046		x = val[a]*/
    DeRef(_x_67872);
    _2 = (object)SEQ_PTR(_67val_65340);
    _x_67872 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    Ref(_x_67872);

    /** execute.e:2047		b = Code[pc+2]*/
    _33625 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _33625);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2048		c = Code[pc+3]*/
    _33627 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65333 = (object)*(((s1_ptr)_2)->base + _33627);
    if (!IS_ATOM_INT(_67c_65333)){
        _67c_65333 = (object)DBL_PTR(_67c_65333)->dbl;
    }

    /** execute.e:2049		target = Code[pc+4]*/
    _33629 = _67pc_65330 + 4LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33629);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2050		lhs_seq_index = x[1]*/
    _2 = (object)SEQ_PTR(_x_67872);
    _67lhs_seq_index_65338 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_67lhs_seq_index_65338)){
        _67lhs_seq_index_65338 = (object)DBL_PTR(_67lhs_seq_index_65338)->dbl;
    }

    /** execute.e:2051		lhs_subs = x[2..$]*/
    if (IS_SEQUENCE(_x_67872)){
            _33632 = SEQ_PTR(_x_67872)->length;
    }
    else {
        _33632 = 1;
    }
    rhs_slice_target = (object_ptr)&_67lhs_subs_65339;
    RHS_Slice(_x_67872, 2LL, _33632);

    /** execute.e:2052		Code[pc+10] = Code[pc+1]*/
    _33634 = _67pc_65330 + 10LL;
    if ((object)((uintptr_t)_33634 + (uintptr_t)HIGH_BITS) >= 0){
        _33634 = NewDouble((eudouble)_33634);
    }
    _33635 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33636 = (object)*(((s1_ptr)_2)->base + _33635);
    Ref(_33636);
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33634))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33634)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33634);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33636;
    if( _1 != _33636 ){
        DeRef(_1);
    }
    _33636 = NOVALUE;

    /** execute.e:2053		val[target] = var_slice(val[lhs_seq_index], lhs_subs, val[b], val[c])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33637 = (object)*(((s1_ptr)_2)->base + _67lhs_seq_index_65338);
    _2 = (object)SEQ_PTR(_67val_65340);
    _33638 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _2 = (object)SEQ_PTR(_67val_65340);
    _33639 = (object)*(((s1_ptr)_2)->base + _67c_65333);
    Ref(_33637);
    RefDS(_67lhs_subs_65339);
    Ref(_33638);
    Ref(_33639);
    _33640 = _67var_slice(_33637, _67lhs_subs_65339, _33638, _33639);
    _33637 = NOVALUE;
    _33638 = NOVALUE;
    _33639 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33640;
    if( _1 != _33640 ){
        DeRef(_1);
    }
    _33640 = NOVALUE;

    /** execute.e:2054		lhs_subs = {}*/
    RefDS(_22218);
    DeRefDS(_67lhs_subs_65339);
    _67lhs_subs_65339 = _22218;

    /** execute.e:2055		pc += 5*/
    _67pc_65330 = _67pc_65330 + 5LL;

    /** execute.e:2056	end procedure*/
    DeRef(_x_67872);
    _33625 = NOVALUE;
    _33627 = NOVALUE;
    _33635 = NOVALUE;
    DeRef(_33634);
    _33634 = NOVALUE;
    _33629 = NOVALUE;
    _33622 = NOVALUE;
    return;
    ;
}


void _67opASSIGN_SLICE()
{
    object _x_67901 = NOVALUE;
    object _33658 = NOVALUE;
    object _33657 = NOVALUE;
    object _33655 = NOVALUE;
    object _33653 = NOVALUE;
    object _33652 = NOVALUE;
    object _33651 = NOVALUE;
    object _33648 = NOVALUE;
    object _33646 = NOVALUE;
    object _33644 = NOVALUE;
    object _33642 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:2062		a = Code[pc+1]  -- sequence*/
    _33642 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33642);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2063		b = Code[pc+2]  -- 1st index*/
    _33644 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _33644);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2064		c = Code[pc+3]  -- 2nd index*/
    _33646 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65333 = (object)*(((s1_ptr)_2)->base + _33646);
    if (!IS_ATOM_INT(_67c_65333)){
        _67c_65333 = (object)DBL_PTR(_67c_65333)->dbl;
    }

    /** execute.e:2065		d = Code[pc+4]  -- rhs value to assign*/
    _33648 = _67pc_65330 + 4LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67d_65334 = (object)*(((s1_ptr)_2)->base + _33648);
    if (!IS_ATOM_INT(_67d_65334)){
        _67d_65334 = (object)DBL_PTR(_67d_65334)->dbl;
    }

    /** execute.e:2067		x = val[a] -- avoid lingering ref count on val[a]*/
    DeRef(_x_67901);
    _2 = (object)SEQ_PTR(_67val_65340);
    _x_67901 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    Ref(_x_67901);

    /** execute.e:2068		lhs_check_slice(x, val[b], val[c], val[d])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33651 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _2 = (object)SEQ_PTR(_67val_65340);
    _33652 = (object)*(((s1_ptr)_2)->base + _67c_65333);
    _2 = (object)SEQ_PTR(_67val_65340);
    _33653 = (object)*(((s1_ptr)_2)->base + _67d_65334);
    Ref(_x_67901);
    Ref(_33651);
    Ref(_33652);
    Ref(_33653);
    _67lhs_check_slice(_x_67901, _33651, _33652, _33653);
    _33651 = NOVALUE;
    _33652 = NOVALUE;
    _33653 = NOVALUE;

    /** execute.e:2069		x = val[d]*/
    DeRef(_x_67901);
    _2 = (object)SEQ_PTR(_67val_65340);
    _x_67901 = (object)*(((s1_ptr)_2)->base + _67d_65334);
    Ref(_x_67901);

    /** execute.e:2070		val[a][val[b]..val[c]] = x*/
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67a_65331 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67val_65340);
    _33657 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _2 = (object)SEQ_PTR(_67val_65340);
    _33658 = (object)*(((s1_ptr)_2)->base + _67c_65333);
    assign_slice_seq = (s1_ptr *)_3;
    AssignSlice(_33657, _33658, _x_67901);
    _33657 = NOVALUE;
    _33658 = NOVALUE;

    /** execute.e:2071		pc += 5*/
    _67pc_65330 = _67pc_65330 + 5LL;

    /** execute.e:2072	end procedure*/
    DeRef(_x_67901);
    _33655 = NOVALUE;
    _33642 = NOVALUE;
    _33644 = NOVALUE;
    _33646 = NOVALUE;
    _33648 = NOVALUE;
    return;
    ;
}


void _67opPASSIGN_SLICE()
{
    object _33677 = NOVALUE;
    object _33676 = NOVALUE;
    object _33675 = NOVALUE;
    object _33674 = NOVALUE;
    object _33673 = NOVALUE;
    object _33671 = NOVALUE;
    object _33670 = NOVALUE;
    object _33668 = NOVALUE;
    object _33666 = NOVALUE;
    object _33664 = NOVALUE;
    object _33662 = NOVALUE;
    object _33660 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2076		a = Code[pc+1]  -- sequence*/
    _33660 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33660);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2077		b = Code[pc+2]  -- 1st index*/
    _33662 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _33662);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2078		c = Code[pc+3]  -- 2nd index*/
    _33664 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65333 = (object)*(((s1_ptr)_2)->base + _33664);
    if (!IS_ATOM_INT(_67c_65333)){
        _67c_65333 = (object)DBL_PTR(_67c_65333)->dbl;
    }

    /** execute.e:2079		d = Code[pc+4]  -- rhs value to assign*/
    _33666 = _67pc_65330 + 4LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67d_65334 = (object)*(((s1_ptr)_2)->base + _33666);
    if (!IS_ATOM_INT(_67d_65334)){
        _67d_65334 = (object)DBL_PTR(_67d_65334)->dbl;
    }

    /** execute.e:2081		lhs_seq_index = val[a][1]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33668 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_33668);
    _67lhs_seq_index_65338 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_67lhs_seq_index_65338)){
        _67lhs_seq_index_65338 = (object)DBL_PTR(_67lhs_seq_index_65338)->dbl;
    }
    _33668 = NOVALUE;

    /** execute.e:2082		lhs_subs = val[a][2..$]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33670 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_SEQUENCE(_33670)){
            _33671 = SEQ_PTR(_33670)->length;
    }
    else {
        _33671 = 1;
    }
    rhs_slice_target = (object_ptr)&_67lhs_subs_65339;
    RHS_Slice(_33670, 2LL, _33671);
    _33670 = NOVALUE;

    /** execute.e:2083		val[lhs_seq_index] = assign_slice(val[lhs_seq_index],*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33673 = (object)*(((s1_ptr)_2)->base + _67lhs_seq_index_65338);
    _2 = (object)SEQ_PTR(_67val_65340);
    _33674 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _2 = (object)SEQ_PTR(_67val_65340);
    _33675 = (object)*(((s1_ptr)_2)->base + _67c_65333);
    _2 = (object)SEQ_PTR(_67val_65340);
    _33676 = (object)*(((s1_ptr)_2)->base + _67d_65334);
    Ref(_33673);
    RefDS(_67lhs_subs_65339);
    Ref(_33674);
    Ref(_33675);
    Ref(_33676);
    _33677 = _67assign_slice(_33673, _67lhs_subs_65339, _33674, _33675, _33676);
    _33673 = NOVALUE;
    _33674 = NOVALUE;
    _33675 = NOVALUE;
    _33676 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67lhs_seq_index_65338);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33677;
    if( _1 != _33677 ){
        DeRef(_1);
    }
    _33677 = NOVALUE;

    /** execute.e:2086		lhs_subs = {}*/
    RefDS(_22218);
    DeRefDS(_67lhs_subs_65339);
    _67lhs_subs_65339 = _22218;

    /** execute.e:2087		pc += 5*/
    _67pc_65330 = _67pc_65330 + 5LL;

    /** execute.e:2088	end procedure*/
    _33664 = NOVALUE;
    _33666 = NOVALUE;
    _33660 = NOVALUE;
    _33662 = NOVALUE;
    return;
    ;
}


void _67opRHS_SLICE()
{
    object _x_67951 = NOVALUE;
    object _33692 = NOVALUE;
    object _33691 = NOVALUE;
    object _33690 = NOVALUE;
    object _33689 = NOVALUE;
    object _33688 = NOVALUE;
    object _33685 = NOVALUE;
    object _33683 = NOVALUE;
    object _33681 = NOVALUE;
    object _33679 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2094		a = Code[pc+1]  -- sequence*/
    _33679 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33679);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2095		b = Code[pc+2]  -- 1st index*/
    _33681 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _33681);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2096		c = Code[pc+3]  -- 2nd index*/
    _33683 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65333 = (object)*(((s1_ptr)_2)->base + _33683);
    if (!IS_ATOM_INT(_67c_65333)){
        _67c_65333 = (object)DBL_PTR(_67c_65333)->dbl;
    }

    /** execute.e:2097		target = Code[pc+4]*/
    _33685 = _67pc_65330 + 4LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33685);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2098		x = val[a]*/
    DeRef(_x_67951);
    _2 = (object)SEQ_PTR(_67val_65340);
    _x_67951 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    Ref(_x_67951);

    /** execute.e:2099		check_slice(x, val[b], val[c])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33688 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _2 = (object)SEQ_PTR(_67val_65340);
    _33689 = (object)*(((s1_ptr)_2)->base + _67c_65333);
    Ref(_x_67951);
    Ref(_33688);
    Ref(_33689);
    _67check_slice(_x_67951, _33688, _33689);
    _33688 = NOVALUE;
    _33689 = NOVALUE;

    /** execute.e:2100		val[target] = x[val[b]..val[c]]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33690 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _2 = (object)SEQ_PTR(_67val_65340);
    _33691 = (object)*(((s1_ptr)_2)->base + _67c_65333);
    rhs_slice_target = (object_ptr)&_33692;
    RHS_Slice(_x_67951, _33690, _33691);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33692;
    if( _1 != _33692 ){
        DeRef(_1);
    }
    _33692 = NOVALUE;

    /** execute.e:2101		pc += 5*/
    _67pc_65330 = _67pc_65330 + 5LL;

    /** execute.e:2102	end procedure*/
    DeRef(_x_67951);
    _33681 = NOVALUE;
    _33685 = NOVALUE;
    _33683 = NOVALUE;
    _33691 = NOVALUE;
    _33679 = NOVALUE;
    _33690 = NOVALUE;
    return;
    ;
}


void _67opTYPE_CHECK()
{
    object _33698 = NOVALUE;
    object _33696 = NOVALUE;
    object _33695 = NOVALUE;
    object _33694 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2107		if val[Code[pc-1]] = 0 then*/
    _33694 = _67pc_65330 - 1LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33695 = (object)*(((s1_ptr)_2)->base + _33694);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!IS_ATOM_INT(_33695)){
        _33696 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33695)->dbl));
    }
    else{
        _33696 = (object)*(((s1_ptr)_2)->base + _33695);
    }
    if (binary_op_a(NOTEQ, _33696, 0LL)){
        _33696 = NOVALUE;
        goto L1; // [21] 37
    }
    _33696 = NOVALUE;

    /** execute.e:2108			RTFatalType(pc-2)*/
    _33698 = _67pc_65330 - 2LL;
    if ((object)((uintptr_t)_33698 +(uintptr_t) HIGH_BITS) >= 0){
        _33698 = NewDouble((eudouble)_33698);
    }
    _67RTFatalType(_33698);
    _33698 = NOVALUE;
L1: 

    /** execute.e:2110		pc += 1*/
    _67pc_65330 = _67pc_65330 + 1;

    /** execute.e:2111	end procedure*/
    DeRef(_33694);
    _33694 = NOVALUE;
    _33695 = NOVALUE;
    return;
    ;
}


void _67kill_temp(object _sym_67984)
{
    object _33700 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2114		if sym_mode( sym ) = M_TEMP then*/
    _33700 = _53sym_mode(_sym_67984);
    if (binary_op_a(NOTEQ, _33700, 3LL)){
        DeRef(_33700);
        _33700 = NOVALUE;
        goto L1; // [11] 26
    }
    DeRef(_33700);
    _33700 = NOVALUE;

    /** execute.e:2115			val[sym] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _sym_67984);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
L1: 

    /** execute.e:2117	end procedure*/
    return;
    ;
}


void _67opIS_AN_INTEGER()
{
    object _33707 = NOVALUE;
    object _33706 = NOVALUE;
    object _33704 = NOVALUE;
    object _33702 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2120		a = Code[pc+1]*/
    _33702 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33702);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2121		target = Code[pc+2]*/
    _33704 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33704);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2122		val[target] = integer(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33706 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_ATOM_INT(_33706))
    _33707 = 1;
    else if (IS_ATOM_DBL(_33706))
    _33707 = IS_ATOM_INT(DoubleToInt(_33706));
    else
    _33707 = 0;
    _33706 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33707;
    if( _1 != _33707 ){
        DeRef(_1);
    }
    _33707 = NOVALUE;

    /** execute.e:2123		kill_temp( a )*/
    _67kill_temp(_67a_65331);

    /** execute.e:2124		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:2125	end procedure*/
    _33704 = NOVALUE;
    _33702 = NOVALUE;
    return;
    ;
}


void _67opIS_AN_ATOM()
{
    object _33714 = NOVALUE;
    object _33713 = NOVALUE;
    object _33711 = NOVALUE;
    object _33709 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2128		a = Code[pc+1]*/
    _33709 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33709);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2129		target = Code[pc+2]*/
    _33711 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33711);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2130		val[target] = atom(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33713 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _33714 = IS_ATOM(_33713);
    _33713 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33714;
    if( _1 != _33714 ){
        DeRef(_1);
    }
    _33714 = NOVALUE;

    /** execute.e:2131		kill_temp( a )*/
    _67kill_temp(_67a_65331);

    /** execute.e:2132		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:2133	end procedure*/
    _33711 = NOVALUE;
    _33709 = NOVALUE;
    return;
    ;
}


void _67opIS_A_SEQUENCE()
{
    object _33721 = NOVALUE;
    object _33720 = NOVALUE;
    object _33718 = NOVALUE;
    object _33716 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2136		a = Code[pc+1]*/
    _33716 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33716);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2137		target = Code[pc+2]*/
    _33718 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33718);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2138		val[target] = sequence(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33720 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _33721 = IS_SEQUENCE(_33720);
    _33720 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33721;
    if( _1 != _33721 ){
        DeRef(_1);
    }
    _33721 = NOVALUE;

    /** execute.e:2139		kill_temp( a )*/
    _67kill_temp(_67a_65331);

    /** execute.e:2140		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:2141	end procedure*/
    _33718 = NOVALUE;
    _33716 = NOVALUE;
    return;
    ;
}


void _67opIS_AN_OBJECT()
{
    object _33730 = NOVALUE;
    object _33729 = NOVALUE;
    object _33728 = NOVALUE;
    object _33727 = NOVALUE;
    object _33725 = NOVALUE;
    object _33723 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2144		a = Code[pc+1]*/
    _33723 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33723);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2145		target = Code[pc+2]*/
    _33725 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33725);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2146		if equal( val[a], NOVALUE ) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33727 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (_33727 == _27NOVALUE_20426)
    _33728 = 1;
    else if (IS_ATOM_INT(_33727) && IS_ATOM_INT(_27NOVALUE_20426))
    _33728 = 0;
    else
    _33728 = (compare(_33727, _27NOVALUE_20426) == 0);
    _33727 = NOVALUE;
    if (_33728 == 0)
    {
        _33728 = NOVALUE;
        goto L1; // [49] 65
    }
    else{
        _33728 = NOVALUE;
    }

    /** execute.e:2147			val[target] = 0*/
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    goto L2; // [62] 87
L1: 

    /** execute.e:2149			val[target] = object( val[a] )*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33729 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if( NOVALUE == _33729 ){
        _33730 = 0;
    }
    else{
        if (IS_ATOM_INT(_33729))
        _33730 = 1;
        else if (IS_ATOM_DBL(_33729)) {
             if (IS_ATOM_INT(DoubleToInt(_33729))) {
                 _33730 = 1;
                 } else {
                     _33730 = 2;
                } } else if (IS_SEQUENCE(_33729))
                _33730 = 3;
                else
                _33730 = 0;
            }
            _33729 = NOVALUE;
            _2 = (object)SEQ_PTR(_67val_65340);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _67val_65340 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _33730;
            if( _1 != _33730 ){
                DeRef(_1);
            }
            _33730 = NOVALUE;
L2: 

            /** execute.e:2152		kill_temp( a )*/
            _67kill_temp(_67a_65331);

            /** execute.e:2153		pc += 3*/
            _67pc_65330 = _67pc_65330 + 3LL;

            /** execute.e:2154	end procedure*/
            DeRef(_33723);
            _33723 = NOVALUE;
            DeRef(_33725);
            _33725 = NOVALUE;
            return;
    ;
}


void _67opSQRT()
{
    object _33737 = NOVALUE;
    object _33736 = NOVALUE;
    object _33734 = NOVALUE;
    object _33732 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2160		a = Code[pc+1]*/
    _33732 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33732);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2161		target = Code[pc+2]*/
    _33734 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33734);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2162		val[target] = sqrt(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33736 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_ATOM_INT(_33736))
    _33737 = e_sqrt(_33736);
    else
    _33737 = unary_op(SQRT, _33736);
    _33736 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33737;
    if( _1 != _33737 ){
        DeRef(_1);
    }
    _33737 = NOVALUE;

    /** execute.e:2163		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:2164	end procedure*/
    _33734 = NOVALUE;
    _33732 = NOVALUE;
    return;
    ;
}


void _67opSIN()
{
    object _33744 = NOVALUE;
    object _33743 = NOVALUE;
    object _33741 = NOVALUE;
    object _33739 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2167		a = Code[pc+1]*/
    _33739 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33739);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2168		target = Code[pc+2]*/
    _33741 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33741);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2169		val[target] = sin(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33743 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_ATOM_INT(_33743))
    _33744 = e_sin(_33743);
    else
    _33744 = unary_op(SIN, _33743);
    _33743 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33744;
    if( _1 != _33744 ){
        DeRef(_1);
    }
    _33744 = NOVALUE;

    /** execute.e:2170		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:2171	end procedure*/
    _33741 = NOVALUE;
    _33739 = NOVALUE;
    return;
    ;
}


void _67opCOS()
{
    object _33751 = NOVALUE;
    object _33750 = NOVALUE;
    object _33748 = NOVALUE;
    object _33746 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2174		a = Code[pc+1]*/
    _33746 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33746);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2175		target = Code[pc+2]*/
    _33748 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33748);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2176		val[target] = cos(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33750 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_ATOM_INT(_33750))
    _33751 = e_cos(_33750);
    else
    _33751 = unary_op(COS, _33750);
    _33750 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33751;
    if( _1 != _33751 ){
        DeRef(_1);
    }
    _33751 = NOVALUE;

    /** execute.e:2177		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:2178	end procedure*/
    _33748 = NOVALUE;
    _33746 = NOVALUE;
    return;
    ;
}


void _67opTAN()
{
    object _33758 = NOVALUE;
    object _33757 = NOVALUE;
    object _33755 = NOVALUE;
    object _33753 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2181		a = Code[pc+1]*/
    _33753 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33753);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2182		target = Code[pc+2]*/
    _33755 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33755);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2183		val[target] = tan(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33757 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_ATOM_INT(_33757))
    _33758 = e_tan(_33757);
    else
    _33758 = unary_op(TAN, _33757);
    _33757 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33758;
    if( _1 != _33758 ){
        DeRef(_1);
    }
    _33758 = NOVALUE;

    /** execute.e:2184		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:2185	end procedure*/
    _33755 = NOVALUE;
    _33753 = NOVALUE;
    return;
    ;
}


void _67opARCTAN()
{
    object _33765 = NOVALUE;
    object _33764 = NOVALUE;
    object _33762 = NOVALUE;
    object _33760 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2188		a = Code[pc+1]*/
    _33760 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33760);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2189		target = Code[pc+2]*/
    _33762 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33762);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2190		val[target] = arctan(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33764 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_ATOM_INT(_33764))
    _33765 = e_arctan(_33764);
    else
    _33765 = unary_op(ARCTAN, _33764);
    _33764 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33765;
    if( _1 != _33765 ){
        DeRef(_1);
    }
    _33765 = NOVALUE;

    /** execute.e:2191		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:2192	end procedure*/
    _33762 = NOVALUE;
    _33760 = NOVALUE;
    return;
    ;
}


void _67opLOG()
{
    object _33772 = NOVALUE;
    object _33771 = NOVALUE;
    object _33769 = NOVALUE;
    object _33767 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2195		a = Code[pc+1]*/
    _33767 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33767);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2196		target = Code[pc+2]*/
    _33769 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33769);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2197		val[target] = log(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33771 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_ATOM_INT(_33771))
    _33772 = e_log(_33771);
    else
    _33772 = unary_op(LOG, _33771);
    _33771 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33772;
    if( _1 != _33772 ){
        DeRef(_1);
    }
    _33772 = NOVALUE;

    /** execute.e:2198		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:2199	end procedure*/
    _33767 = NOVALUE;
    _33769 = NOVALUE;
    return;
    ;
}


void _67opNOT_BITS()
{
    object _33779 = NOVALUE;
    object _33778 = NOVALUE;
    object _33776 = NOVALUE;
    object _33774 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2202		a = Code[pc+1]*/
    _33774 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33774);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2203		target = Code[pc+2]*/
    _33776 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33776);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2204		val[target] = not_bits(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33778 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_ATOM_INT(_33778))
    _33779 = not_bits(_33778);
    else
    _33779 = unary_op(NOT_BITS, _33778);
    _33778 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33779;
    if( _1 != _33779 ){
        DeRef(_1);
    }
    _33779 = NOVALUE;

    /** execute.e:2205		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:2206	end procedure*/
    _33776 = NOVALUE;
    _33774 = NOVALUE;
    return;
    ;
}


void _67opFLOOR()
{
    object _33786 = NOVALUE;
    object _33785 = NOVALUE;
    object _33783 = NOVALUE;
    object _33781 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2209		a = Code[pc+1]*/
    _33781 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33781);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2210		target = Code[pc+2]*/
    _33783 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33783);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2211		val[target] = floor(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33785 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_ATOM_INT(_33785))
    _33786 = e_floor(_33785);
    else
    _33786 = unary_op(FLOOR, _33785);
    _33785 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33786;
    if( _1 != _33786 ){
        DeRef(_1);
    }
    _33786 = NOVALUE;

    /** execute.e:2212		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:2213	end procedure*/
    _33781 = NOVALUE;
    _33783 = NOVALUE;
    return;
    ;
}


void _67opNOT_IFW()
{
    object _33793 = NOVALUE;
    object _33790 = NOVALUE;
    object _33788 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2216		a = Code[pc+1]*/
    _33788 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33788);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2217		if val[a] = 0 then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33790 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (binary_op_a(NOTEQ, _33790, 0LL)){
        _33790 = NOVALUE;
        goto L1; // [27] 42
    }
    _33790 = NOVALUE;

    /** execute.e:2218			pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;
    goto L2; // [39] 59
L1: 

    /** execute.e:2220			pc = Code[pc+2]*/
    _33793 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65330 = (object)*(((s1_ptr)_2)->base + _33793);
    if (!IS_ATOM_INT(_67pc_65330)){
        _67pc_65330 = (object)DBL_PTR(_67pc_65330)->dbl;
    }
L2: 

    /** execute.e:2222	end procedure*/
    DeRef(_33788);
    _33788 = NOVALUE;
    DeRef(_33793);
    _33793 = NOVALUE;
    return;
    ;
}


void _67opNOT()
{
    object _33800 = NOVALUE;
    object _33799 = NOVALUE;
    object _33797 = NOVALUE;
    object _33795 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2225		a = Code[pc+1]*/
    _33795 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33795);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2226		target = Code[pc+2]*/
    _33797 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33797);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2227		val[target] = not val[a]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33799 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_ATOM_INT(_33799)) {
        _33800 = (_33799 == 0);
    }
    else {
        _33800 = unary_op(NOT, _33799);
    }
    _33799 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33800;
    if( _1 != _33800 ){
        DeRef(_1);
    }
    _33800 = NOVALUE;

    /** execute.e:2228		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:2229	end procedure*/
    _33797 = NOVALUE;
    _33795 = NOVALUE;
    return;
    ;
}


void _67opUMINUS()
{
    object _33807 = NOVALUE;
    object _33806 = NOVALUE;
    object _33804 = NOVALUE;
    object _33802 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2232		a = Code[pc+1]*/
    _33802 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33802);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2233		target = Code[pc+2]*/
    _33804 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33804);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2234		val[target] = -val[a]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33806 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_ATOM_INT(_33806)) {
        if ((uintptr_t)_33806 == (uintptr_t)HIGH_BITS){
            _33807 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _33807 = - _33806;
        }
    }
    else {
        _33807 = unary_op(UMINUS, _33806);
    }
    _33806 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33807;
    if( _1 != _33807 ){
        DeRef(_1);
    }
    _33807 = NOVALUE;

    /** execute.e:2235		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:2236	end procedure*/
    _33802 = NOVALUE;
    _33804 = NOVALUE;
    return;
    ;
}


void _67opRAND()
{
    object _33814 = NOVALUE;
    object _33813 = NOVALUE;
    object _33811 = NOVALUE;
    object _33809 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2239		a = Code[pc+1]*/
    _33809 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33809);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2240		target = Code[pc+2]*/
    _33811 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33811);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2241		val[target] = rand(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33813 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_ATOM_INT(_33813)) {
        _33814 = good_rand() % ((uint32_t)_33813) + 1;
    }
    else {
        _33814 = unary_op(RAND, _33813);
    }
    _33813 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33814;
    if( _1 != _33814 ){
        DeRef(_1);
    }
    _33814 = NOVALUE;

    /** execute.e:2242		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:2243	end procedure*/
    _33811 = NOVALUE;
    _33809 = NOVALUE;
    return;
    ;
}


void _67opDIV2()
{
    object _33821 = NOVALUE;
    object _33820 = NOVALUE;
    object _33818 = NOVALUE;
    object _33816 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2247		a = Code[pc+1]*/
    _33816 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33816);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2249		target = Code[pc+3]*/
    _33818 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33818);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2250		val[target] = val[a] / 2*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33820 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_ATOM_INT(_33820)) {
        if (_33820 & 1) {
            _33821 = NewDouble((_33820 >> 1) + 0.5);
        }
        else
        _33821 = _33820 >> 1;
    }
    else {
        _33821 = binary_op(DIVIDE, _33820, 2);
    }
    _33820 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33821;
    if( _1 != _33821 ){
        DeRef(_1);
    }
    _33821 = NOVALUE;

    /** execute.e:2251		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:2252	end procedure*/
    _33818 = NOVALUE;
    _33816 = NOVALUE;
    return;
    ;
}


void _67opFLOOR_DIV2()
{
    object _33828 = NOVALUE;
    object _33827 = NOVALUE;
    object _33825 = NOVALUE;
    object _33823 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2255		a = Code[pc+1]*/
    _33823 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33823);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2257		target = Code[pc+3]*/
    _33825 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33825);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2258		val[target] = floor(val[a] / 2)*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33827 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_ATOM_INT(_33827)) {
        _33828 = _33827 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _33827, 2);
        _33828 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    _33827 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33828;
    if( _1 != _33828 ){
        DeRef(_1);
    }
    _33828 = NOVALUE;

    /** execute.e:2259		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:2260	end procedure*/
    _33823 = NOVALUE;
    _33825 = NOVALUE;
    return;
    ;
}


void _67opGREATER_IFW()
{
    object _33838 = NOVALUE;
    object _33835 = NOVALUE;
    object _33834 = NOVALUE;
    object _33832 = NOVALUE;
    object _33830 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2265		a = Code[pc+1]*/
    _33830 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33830);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2266		b = Code[pc+2]*/
    _33832 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _33832);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2267		if val[a] > val[b] then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33834 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _33835 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (binary_op_a(LESSEQ, _33834, _33835)){
        _33834 = NOVALUE;
        _33835 = NOVALUE;
        goto L1; // [51] 66
    }
    _33834 = NOVALUE;
    _33835 = NOVALUE;

    /** execute.e:2268			pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;
    goto L2; // [63] 83
L1: 

    /** execute.e:2270			pc = Code[pc+3]*/
    _33838 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65330 = (object)*(((s1_ptr)_2)->base + _33838);
    if (!IS_ATOM_INT(_67pc_65330)){
        _67pc_65330 = (object)DBL_PTR(_67pc_65330)->dbl;
    }
L2: 

    /** execute.e:2272	end procedure*/
    DeRef(_33830);
    _33830 = NOVALUE;
    DeRef(_33838);
    _33838 = NOVALUE;
    DeRef(_33832);
    _33832 = NOVALUE;
    return;
    ;
}


void _67opNOTEQ_IFW()
{
    object _33848 = NOVALUE;
    object _33845 = NOVALUE;
    object _33844 = NOVALUE;
    object _33842 = NOVALUE;
    object _33840 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2275		a = Code[pc+1]*/
    _33840 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33840);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2276		b = Code[pc+2]*/
    _33842 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _33842);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2277		if val[a] != val[b] then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33844 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _33845 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (binary_op_a(EQUALS, _33844, _33845)){
        _33844 = NOVALUE;
        _33845 = NOVALUE;
        goto L1; // [51] 66
    }
    _33844 = NOVALUE;
    _33845 = NOVALUE;

    /** execute.e:2278			pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;
    goto L2; // [63] 83
L1: 

    /** execute.e:2280			pc = Code[pc+3]*/
    _33848 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65330 = (object)*(((s1_ptr)_2)->base + _33848);
    if (!IS_ATOM_INT(_67pc_65330)){
        _67pc_65330 = (object)DBL_PTR(_67pc_65330)->dbl;
    }
L2: 

    /** execute.e:2282	end procedure*/
    DeRef(_33848);
    _33848 = NOVALUE;
    DeRef(_33842);
    _33842 = NOVALUE;
    DeRef(_33840);
    _33840 = NOVALUE;
    return;
    ;
}


void _67opLESSEQ_IFW()
{
    object _33858 = NOVALUE;
    object _33855 = NOVALUE;
    object _33854 = NOVALUE;
    object _33852 = NOVALUE;
    object _33850 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2285		a = Code[pc+1]*/
    _33850 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33850);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2286		b = Code[pc+2]*/
    _33852 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _33852);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2287		if val[a] <= val[b] then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33854 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _33855 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (binary_op_a(GREATER, _33854, _33855)){
        _33854 = NOVALUE;
        _33855 = NOVALUE;
        goto L1; // [51] 66
    }
    _33854 = NOVALUE;
    _33855 = NOVALUE;

    /** execute.e:2288			pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;
    goto L2; // [63] 83
L1: 

    /** execute.e:2290			pc = Code[pc+3]*/
    _33858 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65330 = (object)*(((s1_ptr)_2)->base + _33858);
    if (!IS_ATOM_INT(_67pc_65330)){
        _67pc_65330 = (object)DBL_PTR(_67pc_65330)->dbl;
    }
L2: 

    /** execute.e:2292	end procedure*/
    DeRef(_33858);
    _33858 = NOVALUE;
    DeRef(_33850);
    _33850 = NOVALUE;
    DeRef(_33852);
    _33852 = NOVALUE;
    return;
    ;
}


void _67opGREATEREQ_IFW()
{
    object _33868 = NOVALUE;
    object _33865 = NOVALUE;
    object _33864 = NOVALUE;
    object _33862 = NOVALUE;
    object _33860 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2295		a = Code[pc+1]*/
    _33860 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33860);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2296		b = Code[pc+2]*/
    _33862 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _33862);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2297		if val[a] >= val[b] then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33864 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _33865 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (binary_op_a(LESS, _33864, _33865)){
        _33864 = NOVALUE;
        _33865 = NOVALUE;
        goto L1; // [51] 66
    }
    _33864 = NOVALUE;
    _33865 = NOVALUE;

    /** execute.e:2298			pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;
    goto L2; // [63] 83
L1: 

    /** execute.e:2300			pc = Code[pc+3]*/
    _33868 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65330 = (object)*(((s1_ptr)_2)->base + _33868);
    if (!IS_ATOM_INT(_67pc_65330)){
        _67pc_65330 = (object)DBL_PTR(_67pc_65330)->dbl;
    }
L2: 

    /** execute.e:2302	end procedure*/
    DeRef(_33868);
    _33868 = NOVALUE;
    DeRef(_33860);
    _33860 = NOVALUE;
    DeRef(_33862);
    _33862 = NOVALUE;
    return;
    ;
}


void _67opEQUALS_IFW()
{
    object _33884 = NOVALUE;
    object _33881 = NOVALUE;
    object _33880 = NOVALUE;
    object _33878 = NOVALUE;
    object _33877 = NOVALUE;
    object _33875 = NOVALUE;
    object _33874 = NOVALUE;
    object _33872 = NOVALUE;
    object _33870 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2305		a = Code[pc+1]*/
    _33870 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33870);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2306		b = Code[pc+2]*/
    _33872 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _33872);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2308		if sequence( val[a] ) or sequence( val[b] ) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33874 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _33875 = IS_SEQUENCE(_33874);
    _33874 = NOVALUE;
    if (_33875 != 0) {
        goto L1; // [46] 66
    }
    _2 = (object)SEQ_PTR(_67val_65340);
    _33877 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _33878 = IS_SEQUENCE(_33877);
    _33877 = NOVALUE;
    if (_33878 == 0)
    {
        _33878 = NOVALUE;
        goto L2; // [62] 72
    }
    else{
        _33878 = NOVALUE;
    }
L1: 

    /** execute.e:2309			RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33879);
    _67RTFatal(_33879);
L2: 

    /** execute.e:2311		if val[a] = val[b] then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33880 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _33881 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (binary_op_a(NOTEQ, _33880, _33881)){
        _33880 = NOVALUE;
        _33881 = NOVALUE;
        goto L3; // [90] 105
    }
    _33880 = NOVALUE;
    _33881 = NOVALUE;

    /** execute.e:2312			pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;
    goto L4; // [102] 122
L3: 

    /** execute.e:2314			pc = Code[pc+3]*/
    _33884 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65330 = (object)*(((s1_ptr)_2)->base + _33884);
    if (!IS_ATOM_INT(_67pc_65330)){
        _67pc_65330 = (object)DBL_PTR(_67pc_65330)->dbl;
    }
L4: 

    /** execute.e:2316	end procedure*/
    DeRef(_33872);
    _33872 = NOVALUE;
    DeRef(_33870);
    _33870 = NOVALUE;
    DeRef(_33884);
    _33884 = NOVALUE;
    return;
    ;
}


void _67opLESS_IFW()
{
    object _33894 = NOVALUE;
    object _33891 = NOVALUE;
    object _33890 = NOVALUE;
    object _33888 = NOVALUE;
    object _33886 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2319		a = Code[pc+1]*/
    _33886 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33886);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2320		b = Code[pc+2]*/
    _33888 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _33888);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2321		if val[a] < val[b] then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33890 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _33891 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (binary_op_a(GREATEREQ, _33890, _33891)){
        _33890 = NOVALUE;
        _33891 = NOVALUE;
        goto L1; // [51] 66
    }
    _33890 = NOVALUE;
    _33891 = NOVALUE;

    /** execute.e:2322			pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;
    goto L2; // [63] 83
L1: 

    /** execute.e:2324			pc = Code[pc+3]*/
    _33894 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65330 = (object)*(((s1_ptr)_2)->base + _33894);
    if (!IS_ATOM_INT(_67pc_65330)){
        _67pc_65330 = (object)DBL_PTR(_67pc_65330)->dbl;
    }
L2: 

    /** execute.e:2326	end procedure*/
    DeRef(_33886);
    _33886 = NOVALUE;
    DeRef(_33888);
    _33888 = NOVALUE;
    DeRef(_33894);
    _33894 = NOVALUE;
    return;
    ;
}


void _67opMULTIPLY()
{
    object _33904 = NOVALUE;
    object _33903 = NOVALUE;
    object _33902 = NOVALUE;
    object _33900 = NOVALUE;
    object _33898 = NOVALUE;
    object _33896 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2331		a = Code[pc+1]*/
    _33896 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33896);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2332		b = Code[pc+2]*/
    _33898 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _33898);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2333		target = Code[pc+3]*/
    _33900 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33900);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2334		val[target] = val[a] * val[b]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33902 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _33903 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_ATOM_INT(_33902) && IS_ATOM_INT(_33903)) {
        {
            int128_t p128 = (int128_t)_33902 * (int128_t)_33903;
            if( p128 != (int128_t)(_33904 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _33904 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _33904 = binary_op(MULTIPLY, _33902, _33903);
    }
    _33902 = NOVALUE;
    _33903 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33904;
    if( _1 != _33904 ){
        DeRef(_1);
    }
    _33904 = NOVALUE;

    /** execute.e:2335		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:2336	end procedure*/
    _33900 = NOVALUE;
    _33896 = NOVALUE;
    _33898 = NOVALUE;
    return;
    ;
}


void _67opPLUS()
{
    object _33914 = NOVALUE;
    object _33913 = NOVALUE;
    object _33912 = NOVALUE;
    object _33910 = NOVALUE;
    object _33908 = NOVALUE;
    object _33906 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2340		a = Code[pc+1]*/
    _33906 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33906);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2341		b = Code[pc+2]*/
    _33908 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _33908);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2342		target = Code[pc+3]*/
    _33910 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33910);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2343		val[target] = val[a] + val[b]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33912 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _33913 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_ATOM_INT(_33912) && IS_ATOM_INT(_33913)) {
        _33914 = _33912 + _33913;
        if ((object)((uintptr_t)_33914 + (uintptr_t)HIGH_BITS) >= 0){
            _33914 = NewDouble((eudouble)_33914);
        }
    }
    else {
        _33914 = binary_op(PLUS, _33912, _33913);
    }
    _33912 = NOVALUE;
    _33913 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33914;
    if( _1 != _33914 ){
        DeRef(_1);
    }
    _33914 = NOVALUE;

    /** execute.e:2344		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:2345	end procedure*/
    _33906 = NOVALUE;
    _33910 = NOVALUE;
    _33908 = NOVALUE;
    return;
    ;
}


void _67opMINUS()
{
    object _33924 = NOVALUE;
    object _33923 = NOVALUE;
    object _33922 = NOVALUE;
    object _33920 = NOVALUE;
    object _33918 = NOVALUE;
    object _33916 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2349		a = Code[pc+1]*/
    _33916 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33916);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2350		b = Code[pc+2]*/
    _33918 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _33918);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2351		target = Code[pc+3]*/
    _33920 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33920);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2352		val[target] = val[a] - val[b]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33922 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _33923 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_ATOM_INT(_33922) && IS_ATOM_INT(_33923)) {
        _33924 = _33922 - _33923;
        if ((object)((uintptr_t)_33924 +(uintptr_t) HIGH_BITS) >= 0){
            _33924 = NewDouble((eudouble)_33924);
        }
    }
    else {
        _33924 = binary_op(MINUS, _33922, _33923);
    }
    _33922 = NOVALUE;
    _33923 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33924;
    if( _1 != _33924 ){
        DeRef(_1);
    }
    _33924 = NOVALUE;

    /** execute.e:2353		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:2354	end procedure*/
    _33918 = NOVALUE;
    _33920 = NOVALUE;
    _33916 = NOVALUE;
    return;
    ;
}


void _67opOR()
{
    object _33934 = NOVALUE;
    object _33933 = NOVALUE;
    object _33932 = NOVALUE;
    object _33930 = NOVALUE;
    object _33928 = NOVALUE;
    object _33926 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2357		a = Code[pc+1]*/
    _33926 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33926);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2358		b = Code[pc+2]*/
    _33928 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _33928);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2359		target = Code[pc+3]*/
    _33930 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33930);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2360		val[target] = val[a] or val[b]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33932 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _33933 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_ATOM_INT(_33932) && IS_ATOM_INT(_33933)) {
        _33934 = (_33932 != 0 || _33933 != 0);
    }
    else {
        _33934 = binary_op(OR, _33932, _33933);
    }
    _33932 = NOVALUE;
    _33933 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33934;
    if( _1 != _33934 ){
        DeRef(_1);
    }
    _33934 = NOVALUE;

    /** execute.e:2361		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:2362	end procedure*/
    _33930 = NOVALUE;
    _33926 = NOVALUE;
    _33928 = NOVALUE;
    return;
    ;
}


void _67opXOR()
{
    object _33944 = NOVALUE;
    object _33943 = NOVALUE;
    object _33942 = NOVALUE;
    object _33940 = NOVALUE;
    object _33938 = NOVALUE;
    object _33936 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2365		a = Code[pc+1]*/
    _33936 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33936);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2366		b = Code[pc+2]*/
    _33938 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _33938);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2367		target = Code[pc+3]*/
    _33940 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33940);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2368		val[target] = val[a] xor val[b]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33942 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _33943 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_ATOM_INT(_33942) && IS_ATOM_INT(_33943)) {
        _33944 = ((_33942 != 0) != (_33943 != 0));
    }
    else {
        _33944 = binary_op(XOR, _33942, _33943);
    }
    _33942 = NOVALUE;
    _33943 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33944;
    if( _1 != _33944 ){
        DeRef(_1);
    }
    _33944 = NOVALUE;

    /** execute.e:2369		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:2370	end procedure*/
    _33936 = NOVALUE;
    _33940 = NOVALUE;
    _33938 = NOVALUE;
    return;
    ;
}


void _67opAND()
{
    object _33954 = NOVALUE;
    object _33953 = NOVALUE;
    object _33952 = NOVALUE;
    object _33950 = NOVALUE;
    object _33948 = NOVALUE;
    object _33946 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2373		a = Code[pc+1]*/
    _33946 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33946);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2374		b = Code[pc+2]*/
    _33948 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _33948);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2375		target = Code[pc+3]*/
    _33950 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33950);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2376		val[target] = val[a] and val[b]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33952 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _33953 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_ATOM_INT(_33952) && IS_ATOM_INT(_33953)) {
        _33954 = (_33952 != 0 && _33953 != 0);
    }
    else {
        _33954 = binary_op(AND, _33952, _33953);
    }
    _33952 = NOVALUE;
    _33953 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33954;
    if( _1 != _33954 ){
        DeRef(_1);
    }
    _33954 = NOVALUE;

    /** execute.e:2377		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:2378	end procedure*/
    _33948 = NOVALUE;
    _33946 = NOVALUE;
    _33950 = NOVALUE;
    return;
    ;
}


void _67opDIVIDE()
{
    object _33967 = NOVALUE;
    object _33966 = NOVALUE;
    object _33965 = NOVALUE;
    object _33963 = NOVALUE;
    object _33962 = NOVALUE;
    object _33960 = NOVALUE;
    object _33958 = NOVALUE;
    object _33956 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2381		a = Code[pc+1]*/
    _33956 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33956);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2382		b = Code[pc+2]*/
    _33958 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _33958);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2383		target = Code[pc+3]*/
    _33960 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33960);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2384		if equal(val[b], 0) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33962 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (_33962 == 0LL)
    _33963 = 1;
    else if (IS_ATOM_INT(_33962) && IS_ATOM_INT(0LL))
    _33963 = 0;
    else
    _33963 = (compare(_33962, 0LL) == 0);
    _33962 = NOVALUE;
    if (_33963 == 0)
    {
        _33963 = NOVALUE;
        goto L1; // [63] 72
    }
    else{
        _33963 = NOVALUE;
    }

    /** execute.e:2385			RTFatal("attempt to divide by 0")*/
    RefDS(_33964);
    _67RTFatal(_33964);
L1: 

    /** execute.e:2387		val[target] = val[a] / val[b]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33965 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _33966 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_ATOM_INT(_33965) && IS_ATOM_INT(_33966)) {
        _33967 = (_33965 % _33966) ? NewDouble((eudouble)_33965 / _33966) : (_33965 / _33966);
    }
    else {
        _33967 = binary_op(DIVIDE, _33965, _33966);
    }
    _33965 = NOVALUE;
    _33966 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33967;
    if( _1 != _33967 ){
        DeRef(_1);
    }
    _33967 = NOVALUE;

    /** execute.e:2388		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:2389	end procedure*/
    DeRef(_33956);
    _33956 = NOVALUE;
    DeRef(_33960);
    _33960 = NOVALUE;
    DeRef(_33958);
    _33958 = NOVALUE;
    return;
    ;
}


void _67opREMAINDER()
{
    object _33980 = NOVALUE;
    object _33979 = NOVALUE;
    object _33978 = NOVALUE;
    object _33976 = NOVALUE;
    object _33975 = NOVALUE;
    object _33973 = NOVALUE;
    object _33971 = NOVALUE;
    object _33969 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2392		a = Code[pc+1]*/
    _33969 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33969);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2393		b = Code[pc+2]*/
    _33971 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _33971);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2394		target = Code[pc+3]*/
    _33973 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33973);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2395		if equal(val[b], 0) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33975 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (_33975 == 0LL)
    _33976 = 1;
    else if (IS_ATOM_INT(_33975) && IS_ATOM_INT(0LL))
    _33976 = 0;
    else
    _33976 = (compare(_33975, 0LL) == 0);
    _33975 = NOVALUE;
    if (_33976 == 0)
    {
        _33976 = NOVALUE;
        goto L1; // [63] 72
    }
    else{
        _33976 = NOVALUE;
    }

    /** execute.e:2396			RTFatal("Can't get remainder of a number divided by 0")*/
    RefDS(_33977);
    _67RTFatal(_33977);
L1: 

    /** execute.e:2398		val[target] = remainder(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33978 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _33979 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_ATOM_INT(_33978) && IS_ATOM_INT(_33979)) {
        _33980 = (_33978 % _33979);
    }
    else {
        _33980 = binary_op(REMAINDER, _33978, _33979);
    }
    _33978 = NOVALUE;
    _33979 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33980;
    if( _1 != _33980 ){
        DeRef(_1);
    }
    _33980 = NOVALUE;

    /** execute.e:2399		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:2400	end procedure*/
    DeRef(_33973);
    _33973 = NOVALUE;
    DeRef(_33969);
    _33969 = NOVALUE;
    DeRef(_33971);
    _33971 = NOVALUE;
    return;
    ;
}


void _67opFLOOR_DIV()
{
    object _33992 = NOVALUE;
    object _33991 = NOVALUE;
    object _33990 = NOVALUE;
    object _33989 = NOVALUE;
    object _33988 = NOVALUE;
    object _33986 = NOVALUE;
    object _33984 = NOVALUE;
    object _33982 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2403		a = Code[pc+1]*/
    _33982 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33982);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2404		b = Code[pc+2]*/
    _33984 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _33984);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2405		target = Code[pc+3]*/
    _33986 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33986);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2406		if equal(val[b], 0) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33988 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (_33988 == 0LL)
    _33989 = 1;
    else if (IS_ATOM_INT(_33988) && IS_ATOM_INT(0LL))
    _33989 = 0;
    else
    _33989 = (compare(_33988, 0LL) == 0);
    _33988 = NOVALUE;
    if (_33989 == 0)
    {
        _33989 = NOVALUE;
        goto L1; // [63] 72
    }
    else{
        _33989 = NOVALUE;
    }

    /** execute.e:2407			RTFatal("attempt to divide by 0")*/
    RefDS(_33964);
    _67RTFatal(_33964);
L1: 

    /** execute.e:2409		val[target] = floor(val[a] / val[b])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _33990 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _33991 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_ATOM_INT(_33990) && IS_ATOM_INT(_33991)) {
        if (_33991 > 0 && _33990 >= 0) {
            _33992 = _33990 / _33991;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_33990 / (eudouble)_33991);
            if (_33990 != MININT)
            _33992 = (object)temp_dbl;
            else
            _33992 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _33990, _33991);
        _33992 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _33990 = NOVALUE;
    _33991 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33992;
    if( _1 != _33992 ){
        DeRef(_1);
    }
    _33992 = NOVALUE;

    /** execute.e:2410		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:2411	end procedure*/
    DeRef(_33984);
    _33984 = NOVALUE;
    DeRef(_33986);
    _33986 = NOVALUE;
    DeRef(_33982);
    _33982 = NOVALUE;
    return;
    ;
}


void _67opAND_BITS()
{
    object _34002 = NOVALUE;
    object _34001 = NOVALUE;
    object _34000 = NOVALUE;
    object _33998 = NOVALUE;
    object _33996 = NOVALUE;
    object _33994 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2414		a = Code[pc+1]*/
    _33994 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _33994);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2415		b = Code[pc+2]*/
    _33996 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _33996);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2416		target = Code[pc+3]*/
    _33998 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _33998);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2417		val[target] = and_bits(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34000 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34001 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_ATOM_INT(_34000) && IS_ATOM_INT(_34001)) {
        {uintptr_t tu;
             tu = (uintptr_t)_34000 & (uintptr_t)_34001;
             _34002 = MAKE_UINT(tu);
        }
    }
    else {
        _34002 = binary_op(AND_BITS, _34000, _34001);
    }
    _34000 = NOVALUE;
    _34001 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34002;
    if( _1 != _34002 ){
        DeRef(_1);
    }
    _34002 = NOVALUE;

    /** execute.e:2418		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:2419	end procedure*/
    _33994 = NOVALUE;
    _33996 = NOVALUE;
    _33998 = NOVALUE;
    return;
    ;
}


void _67opOR_BITS()
{
    object _34012 = NOVALUE;
    object _34011 = NOVALUE;
    object _34010 = NOVALUE;
    object _34008 = NOVALUE;
    object _34006 = NOVALUE;
    object _34004 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2422		a = Code[pc+1]*/
    _34004 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34004);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2423		b = Code[pc+2]*/
    _34006 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34006);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2424		target = Code[pc+3]*/
    _34008 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34008);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2425		val[target] = or_bits(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34010 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34011 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_ATOM_INT(_34010) && IS_ATOM_INT(_34011)) {
        {uintptr_t tu;
             tu = (uintptr_t)_34010 | (uintptr_t)_34011;
             _34012 = MAKE_UINT(tu);
        }
    }
    else {
        _34012 = binary_op(OR_BITS, _34010, _34011);
    }
    _34010 = NOVALUE;
    _34011 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34012;
    if( _1 != _34012 ){
        DeRef(_1);
    }
    _34012 = NOVALUE;

    /** execute.e:2426		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:2427	end procedure*/
    _34008 = NOVALUE;
    _34004 = NOVALUE;
    _34006 = NOVALUE;
    return;
    ;
}


void _67opXOR_BITS()
{
    object _34022 = NOVALUE;
    object _34021 = NOVALUE;
    object _34020 = NOVALUE;
    object _34018 = NOVALUE;
    object _34016 = NOVALUE;
    object _34014 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2430		a = Code[pc+1]*/
    _34014 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34014);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2431		b = Code[pc+2]*/
    _34016 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34016);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2432		target = Code[pc+3]*/
    _34018 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34018);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2433		val[target] = xor_bits(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34020 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34021 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_ATOM_INT(_34020) && IS_ATOM_INT(_34021)) {
        {uintptr_t tu;
             tu = (uintptr_t)_34020 ^ (uintptr_t)_34021;
             _34022 = MAKE_UINT(tu);
        }
    }
    else {
        _34022 = binary_op(XOR_BITS, _34020, _34021);
    }
    _34020 = NOVALUE;
    _34021 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34022;
    if( _1 != _34022 ){
        DeRef(_1);
    }
    _34022 = NOVALUE;

    /** execute.e:2434		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:2435	end procedure*/
    _34014 = NOVALUE;
    _34018 = NOVALUE;
    _34016 = NOVALUE;
    return;
    ;
}


void _67opPOWER()
{
    object _34032 = NOVALUE;
    object _34031 = NOVALUE;
    object _34030 = NOVALUE;
    object _34028 = NOVALUE;
    object _34026 = NOVALUE;
    object _34024 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2438		a = Code[pc+1]*/
    _34024 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34024);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2439		b = Code[pc+2]*/
    _34026 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34026);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2440		target = Code[pc+3]*/
    _34028 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34028);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2441		val[target] = power(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34030 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34031 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_ATOM_INT(_34030) && IS_ATOM_INT(_34031)) {
        _34032 = power(_34030, _34031);
    }
    else {
        _34032 = binary_op(POWER, _34030, _34031);
    }
    _34030 = NOVALUE;
    _34031 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34032;
    if( _1 != _34032 ){
        DeRef(_1);
    }
    _34032 = NOVALUE;

    /** execute.e:2442		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:2443	end procedure*/
    _34028 = NOVALUE;
    _34026 = NOVALUE;
    _34024 = NOVALUE;
    return;
    ;
}


void _67opLESS()
{
    object _34042 = NOVALUE;
    object _34041 = NOVALUE;
    object _34040 = NOVALUE;
    object _34038 = NOVALUE;
    object _34036 = NOVALUE;
    object _34034 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2446		a = Code[pc+1]*/
    _34034 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34034);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2447		b = Code[pc+2]*/
    _34036 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34036);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2448		target = Code[pc+3]*/
    _34038 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34038);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2449		val[target] = val[a] < val[b]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34040 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34041 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_ATOM_INT(_34040) && IS_ATOM_INT(_34041)) {
        _34042 = (_34040 < _34041);
    }
    else {
        _34042 = binary_op(LESS, _34040, _34041);
    }
    _34040 = NOVALUE;
    _34041 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34042;
    if( _1 != _34042 ){
        DeRef(_1);
    }
    _34042 = NOVALUE;

    /** execute.e:2450		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:2451	end procedure*/
    _34038 = NOVALUE;
    _34034 = NOVALUE;
    _34036 = NOVALUE;
    return;
    ;
}


void _67opGREATER()
{
    object _34052 = NOVALUE;
    object _34051 = NOVALUE;
    object _34050 = NOVALUE;
    object _34048 = NOVALUE;
    object _34046 = NOVALUE;
    object _34044 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2454		a = Code[pc+1]*/
    _34044 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34044);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2455		b = Code[pc+2]*/
    _34046 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34046);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2456		target = Code[pc+3]*/
    _34048 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34048);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2457		val[target] = val[a] > val[b]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34050 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34051 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_ATOM_INT(_34050) && IS_ATOM_INT(_34051)) {
        _34052 = (_34050 > _34051);
    }
    else {
        _34052 = binary_op(GREATER, _34050, _34051);
    }
    _34050 = NOVALUE;
    _34051 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34052;
    if( _1 != _34052 ){
        DeRef(_1);
    }
    _34052 = NOVALUE;

    /** execute.e:2458		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:2459	end procedure*/
    _34044 = NOVALUE;
    _34046 = NOVALUE;
    _34048 = NOVALUE;
    return;
    ;
}


void _67opEQUALS()
{
    object _34062 = NOVALUE;
    object _34061 = NOVALUE;
    object _34060 = NOVALUE;
    object _34058 = NOVALUE;
    object _34056 = NOVALUE;
    object _34054 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2462		a = Code[pc+1]*/
    _34054 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34054);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2463		b = Code[pc+2]*/
    _34056 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34056);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2464		target = Code[pc+3]*/
    _34058 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34058);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2465		val[target] = val[a] = val[b]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34060 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34061 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_ATOM_INT(_34060) && IS_ATOM_INT(_34061)) {
        _34062 = (_34060 == _34061);
    }
    else {
        _34062 = binary_op(EQUALS, _34060, _34061);
    }
    _34060 = NOVALUE;
    _34061 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34062;
    if( _1 != _34062 ){
        DeRef(_1);
    }
    _34062 = NOVALUE;

    /** execute.e:2466		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:2467	end procedure*/
    _34058 = NOVALUE;
    _34054 = NOVALUE;
    _34056 = NOVALUE;
    return;
    ;
}


void _67opNOTEQ()
{
    object _34072 = NOVALUE;
    object _34071 = NOVALUE;
    object _34070 = NOVALUE;
    object _34068 = NOVALUE;
    object _34066 = NOVALUE;
    object _34064 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2470		a = Code[pc+1]*/
    _34064 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34064);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2471		b = Code[pc+2]*/
    _34066 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34066);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2472		target = Code[pc+3]*/
    _34068 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34068);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2473		val[target] = val[a] != val[b]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34070 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34071 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_ATOM_INT(_34070) && IS_ATOM_INT(_34071)) {
        _34072 = (_34070 != _34071);
    }
    else {
        _34072 = binary_op(NOTEQ, _34070, _34071);
    }
    _34070 = NOVALUE;
    _34071 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34072;
    if( _1 != _34072 ){
        DeRef(_1);
    }
    _34072 = NOVALUE;

    /** execute.e:2474		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:2475	end procedure*/
    _34068 = NOVALUE;
    _34066 = NOVALUE;
    _34064 = NOVALUE;
    return;
    ;
}


void _67opLESSEQ()
{
    object _34082 = NOVALUE;
    object _34081 = NOVALUE;
    object _34080 = NOVALUE;
    object _34078 = NOVALUE;
    object _34076 = NOVALUE;
    object _34074 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2478		a = Code[pc+1]*/
    _34074 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34074);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2479		b = Code[pc+2]*/
    _34076 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34076);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2480		target = Code[pc+3]*/
    _34078 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34078);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2481		val[target] = val[a] <= val[b]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34080 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34081 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_ATOM_INT(_34080) && IS_ATOM_INT(_34081)) {
        _34082 = (_34080 <= _34081);
    }
    else {
        _34082 = binary_op(LESSEQ, _34080, _34081);
    }
    _34080 = NOVALUE;
    _34081 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34082;
    if( _1 != _34082 ){
        DeRef(_1);
    }
    _34082 = NOVALUE;

    /** execute.e:2482		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:2483	end procedure*/
    _34078 = NOVALUE;
    _34074 = NOVALUE;
    _34076 = NOVALUE;
    return;
    ;
}


void _67opGREATEREQ()
{
    object _34092 = NOVALUE;
    object _34091 = NOVALUE;
    object _34090 = NOVALUE;
    object _34088 = NOVALUE;
    object _34086 = NOVALUE;
    object _34084 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2486		a = Code[pc+1]*/
    _34084 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34084);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2487		b = Code[pc+2]*/
    _34086 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34086);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2488		target = Code[pc+3]*/
    _34088 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34088);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2489		val[target] = val[a] >= val[b]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34090 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34091 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_ATOM_INT(_34090) && IS_ATOM_INT(_34091)) {
        _34092 = (_34090 >= _34091);
    }
    else {
        _34092 = binary_op(GREATEREQ, _34090, _34091);
    }
    _34090 = NOVALUE;
    _34091 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34092;
    if( _1 != _34092 ){
        DeRef(_1);
    }
    _34092 = NOVALUE;

    /** execute.e:2490		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:2491	end procedure*/
    _34086 = NOVALUE;
    _34088 = NOVALUE;
    _34084 = NOVALUE;
    return;
    ;
}


void _67opSC1_AND()
{
    object _34102 = NOVALUE;
    object _34100 = NOVALUE;
    object _34099 = NOVALUE;
    object _34098 = NOVALUE;
    object _34096 = NOVALUE;
    object _34094 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2496		a = Code[pc+1]*/
    _34094 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34094);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2497		b = Code[pc+2]*/
    _34096 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34096);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2498		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34098 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _34099 = IS_ATOM(_34098);
    _34098 = NOVALUE;
    if (_34099 == 0)
    {
        _34099 = NOVALUE;
        goto L1; // [46] 98
    }
    else{
        _34099 = NOVALUE;
    }

    /** execute.e:2499			if val[a] = 0 then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34100 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (binary_op_a(NOTEQ, _34100, 0LL)){
        _34100 = NOVALUE;
        goto L2; // [59] 104
    }
    _34100 = NOVALUE;

    /** execute.e:2500				val[b] = 0*/
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67b_65332);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** execute.e:2501				pc = Code[pc+3]*/
    _34102 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65330 = (object)*(((s1_ptr)_2)->base + _34102);
    if (!IS_ATOM_INT(_67pc_65330)){
        _67pc_65330 = (object)DBL_PTR(_67pc_65330)->dbl;
    }

    /** execute.e:2502				return*/
    _34094 = NOVALUE;
    _34096 = NOVALUE;
    _34102 = NOVALUE;
    return;
    goto L2; // [95] 104
L1: 

    /** execute.e:2505			RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33879);
    _67RTFatal(_33879);
L2: 

    /** execute.e:2507		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:2508	end procedure*/
    DeRef(_34094);
    _34094 = NOVALUE;
    DeRef(_34096);
    _34096 = NOVALUE;
    DeRef(_34102);
    _34102 = NOVALUE;
    return;
    ;
}


void _67opSC1_AND_IF()
{
    object _34113 = NOVALUE;
    object _34111 = NOVALUE;
    object _34110 = NOVALUE;
    object _34109 = NOVALUE;
    object _34107 = NOVALUE;
    object _34105 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2512		a = Code[pc+1]*/
    _34105 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34105);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2513		b = Code[pc+2]*/
    _34107 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34107);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2514		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34109 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _34110 = IS_ATOM(_34109);
    _34109 = NOVALUE;
    if (_34110 == 0)
    {
        _34110 = NOVALUE;
        goto L1; // [46] 88
    }
    else{
        _34110 = NOVALUE;
    }

    /** execute.e:2515			if val[a] = 0 then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34111 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (binary_op_a(NOTEQ, _34111, 0LL)){
        _34111 = NOVALUE;
        goto L2; // [59] 94
    }
    _34111 = NOVALUE;

    /** execute.e:2516				pc = Code[pc+3]*/
    _34113 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65330 = (object)*(((s1_ptr)_2)->base + _34113);
    if (!IS_ATOM_INT(_67pc_65330)){
        _67pc_65330 = (object)DBL_PTR(_67pc_65330)->dbl;
    }

    /** execute.e:2517				return*/
    _34113 = NOVALUE;
    _34107 = NOVALUE;
    _34105 = NOVALUE;
    return;
    goto L2; // [85] 94
L1: 

    /** execute.e:2520			RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33879);
    _67RTFatal(_33879);
L2: 

    /** execute.e:2522		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:2523	end procedure*/
    DeRef(_34113);
    _34113 = NOVALUE;
    DeRef(_34107);
    _34107 = NOVALUE;
    DeRef(_34105);
    _34105 = NOVALUE;
    return;
    ;
}


void _67opSC1_OR()
{
    object _34124 = NOVALUE;
    object _34122 = NOVALUE;
    object _34121 = NOVALUE;
    object _34120 = NOVALUE;
    object _34118 = NOVALUE;
    object _34116 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2526		a = Code[pc+1]*/
    _34116 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34116);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2527		b = Code[pc+2]*/
    _34118 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34118);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2528		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34120 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _34121 = IS_ATOM(_34120);
    _34120 = NOVALUE;
    if (_34121 == 0)
    {
        _34121 = NOVALUE;
        goto L1; // [46] 98
    }
    else{
        _34121 = NOVALUE;
    }

    /** execute.e:2529			if val[a] != 0 then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34122 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (binary_op_a(EQUALS, _34122, 0LL)){
        _34122 = NOVALUE;
        goto L2; // [59] 104
    }
    _34122 = NOVALUE;

    /** execute.e:2530				val[b] = 1*/
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67b_65332);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);

    /** execute.e:2531				pc = Code[pc+3]*/
    _34124 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65330 = (object)*(((s1_ptr)_2)->base + _34124);
    if (!IS_ATOM_INT(_67pc_65330)){
        _67pc_65330 = (object)DBL_PTR(_67pc_65330)->dbl;
    }

    /** execute.e:2532				return*/
    _34124 = NOVALUE;
    _34118 = NOVALUE;
    _34116 = NOVALUE;
    return;
    goto L2; // [95] 104
L1: 

    /** execute.e:2535			RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33879);
    _67RTFatal(_33879);
L2: 

    /** execute.e:2537		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:2538	end procedure*/
    DeRef(_34124);
    _34124 = NOVALUE;
    DeRef(_34118);
    _34118 = NOVALUE;
    DeRef(_34116);
    _34116 = NOVALUE;
    return;
    ;
}


void _67opSC1_OR_IF()
{
    object _34135 = NOVALUE;
    object _34133 = NOVALUE;
    object _34132 = NOVALUE;
    object _34131 = NOVALUE;
    object _34129 = NOVALUE;
    object _34127 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2542		a = Code[pc+1]*/
    _34127 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34127);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2543		b = Code[pc+2]*/
    _34129 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34129);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2544		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34131 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _34132 = IS_ATOM(_34131);
    _34131 = NOVALUE;
    if (_34132 == 0)
    {
        _34132 = NOVALUE;
        goto L1; // [46] 98
    }
    else{
        _34132 = NOVALUE;
    }

    /** execute.e:2545			if val[a] != 0 then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34133 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (binary_op_a(EQUALS, _34133, 0LL)){
        _34133 = NOVALUE;
        goto L2; // [59] 104
    }
    _34133 = NOVALUE;

    /** execute.e:2546				val[b] = 1*/
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67b_65332);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);

    /** execute.e:2547				pc = Code[pc+3]*/
    _34135 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65330 = (object)*(((s1_ptr)_2)->base + _34135);
    if (!IS_ATOM_INT(_67pc_65330)){
        _67pc_65330 = (object)DBL_PTR(_67pc_65330)->dbl;
    }

    /** execute.e:2548				return*/
    _34127 = NOVALUE;
    _34129 = NOVALUE;
    _34135 = NOVALUE;
    return;
    goto L2; // [95] 104
L1: 

    /** execute.e:2551			RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33879);
    _67RTFatal(_33879);
L2: 

    /** execute.e:2553		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:2554	end procedure*/
    DeRef(_34127);
    _34127 = NOVALUE;
    DeRef(_34129);
    _34129 = NOVALUE;
    DeRef(_34135);
    _34135 = NOVALUE;
    return;
    ;
}


void _67opSC2_OR()
{
    object _34144 = NOVALUE;
    object _34143 = NOVALUE;
    object _34142 = NOVALUE;
    object _34140 = NOVALUE;
    object _34138 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2559		a = Code[pc+1]*/
    _34138 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34138);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2560		b = Code[pc+2]*/
    _34140 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34140);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2561		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34142 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _34143 = IS_ATOM(_34142);
    _34142 = NOVALUE;
    if (_34143 == 0)
    {
        _34143 = NOVALUE;
        goto L1; // [46] 70
    }
    else{
        _34143 = NOVALUE;
    }

    /** execute.e:2562			val[b] = val[a]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34144 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    Ref(_34144);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67b_65332);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34144;
    if( _1 != _34144 ){
        DeRef(_1);
    }
    _34144 = NOVALUE;
    goto L2; // [67] 76
L1: 

    /** execute.e:2564			RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33879);
    _67RTFatal(_33879);
L2: 

    /** execute.e:2566		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:2567	end procedure*/
    DeRef(_34140);
    _34140 = NOVALUE;
    DeRef(_34138);
    _34138 = NOVALUE;
    return;
    ;
}


void _67opFOR()
{
    object _increment_68693 = NOVALUE;
    object _limit_68694 = NOVALUE;
    object _initial_68695 = NOVALUE;
    object _loopvar_68696 = NOVALUE;
    object _jump_68697 = NOVALUE;
    object _34174 = NOVALUE;
    object _34172 = NOVALUE;
    object _34171 = NOVALUE;
    object _34169 = NOVALUE;
    object _34168 = NOVALUE;
    object _34166 = NOVALUE;
    object _34163 = NOVALUE;
    object _34162 = NOVALUE;
    object _34160 = NOVALUE;
    object _34159 = NOVALUE;
    object _34157 = NOVALUE;
    object _34156 = NOVALUE;
    object _34154 = NOVALUE;
    object _34152 = NOVALUE;
    object _34150 = NOVALUE;
    object _34148 = NOVALUE;
    object _34146 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2576		increment = Code[pc+1]*/
    _34146 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _increment_68693 = (object)*(((s1_ptr)_2)->base + _34146);
    if (!IS_ATOM_INT(_increment_68693)){
        _increment_68693 = (object)DBL_PTR(_increment_68693)->dbl;
    }

    /** execute.e:2577		limit = Code[pc+2]*/
    _34148 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _limit_68694 = (object)*(((s1_ptr)_2)->base + _34148);
    if (!IS_ATOM_INT(_limit_68694)){
        _limit_68694 = (object)DBL_PTR(_limit_68694)->dbl;
    }

    /** execute.e:2578		initial = Code[pc+3]*/
    _34150 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _initial_68695 = (object)*(((s1_ptr)_2)->base + _34150);
    if (!IS_ATOM_INT(_initial_68695)){
        _initial_68695 = (object)DBL_PTR(_initial_68695)->dbl;
    }

    /** execute.e:2581		loopvar = Code[pc+5]*/
    _34152 = _67pc_65330 + 5LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _loopvar_68696 = (object)*(((s1_ptr)_2)->base + _34152);
    if (!IS_ATOM_INT(_loopvar_68696)){
        _loopvar_68696 = (object)DBL_PTR(_loopvar_68696)->dbl;
    }

    /** execute.e:2582		jump = Code[pc+6]*/
    _34154 = _67pc_65330 + 6LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _jump_68697 = (object)*(((s1_ptr)_2)->base + _34154);
    if (!IS_ATOM_INT(_jump_68697)){
        _jump_68697 = (object)DBL_PTR(_jump_68697)->dbl;
    }

    /** execute.e:2584		if sequence(val[initial]) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34156 = (object)*(((s1_ptr)_2)->base + _initial_68695);
    _34157 = IS_SEQUENCE(_34156);
    _34156 = NOVALUE;
    if (_34157 == 0)
    {
        _34157 = NOVALUE;
        goto L1; // [92] 101
    }
    else{
        _34157 = NOVALUE;
    }

    /** execute.e:2585			RTFatal("for-loop variable is not an atom")*/
    RefDS(_34158);
    _67RTFatal(_34158);
L1: 

    /** execute.e:2587		if sequence(val[limit]) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34159 = (object)*(((s1_ptr)_2)->base + _limit_68694);
    _34160 = IS_SEQUENCE(_34159);
    _34159 = NOVALUE;
    if (_34160 == 0)
    {
        _34160 = NOVALUE;
        goto L2; // [112] 121
    }
    else{
        _34160 = NOVALUE;
    }

    /** execute.e:2588			RTFatal("for-loop limit is not an atom")*/
    RefDS(_34161);
    _67RTFatal(_34161);
L2: 

    /** execute.e:2590		if sequence(val[increment]) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34162 = (object)*(((s1_ptr)_2)->base + _increment_68693);
    _34163 = IS_SEQUENCE(_34162);
    _34162 = NOVALUE;
    if (_34163 == 0)
    {
        _34163 = NOVALUE;
        goto L3; // [132] 141
    }
    else{
        _34163 = NOVALUE;
    }

    /** execute.e:2591			RTFatal("for-loop increment is not an atom")*/
    RefDS(_34164);
    _67RTFatal(_34164);
L3: 

    /** execute.e:2594		pc += 7 -- to enter into the loop*/
    _67pc_65330 = _67pc_65330 + 7LL;

    /** execute.e:2596		if val[increment] >= 0 then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34166 = (object)*(((s1_ptr)_2)->base + _increment_68693);
    if (binary_op_a(LESS, _34166, 0LL)){
        _34166 = NOVALUE;
        goto L4; // [157] 188
    }
    _34166 = NOVALUE;

    /** execute.e:2598			if val[initial] > val[limit] then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34168 = (object)*(((s1_ptr)_2)->base + _initial_68695);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34169 = (object)*(((s1_ptr)_2)->base + _limit_68694);
    if (binary_op_a(LESSEQ, _34168, _34169)){
        _34168 = NOVALUE;
        _34169 = NOVALUE;
        goto L5; // [175] 213
    }
    _34168 = NOVALUE;
    _34169 = NOVALUE;

    /** execute.e:2599				pc = jump -- quit immediately, 0 iterations*/
    _67pc_65330 = _jump_68697;
    goto L5; // [185] 213
L4: 

    /** execute.e:2603			if val[initial] < val[limit] then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34171 = (object)*(((s1_ptr)_2)->base + _initial_68695);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34172 = (object)*(((s1_ptr)_2)->base + _limit_68694);
    if (binary_op_a(GREATEREQ, _34171, _34172)){
        _34171 = NOVALUE;
        _34172 = NOVALUE;
        goto L6; // [202] 212
    }
    _34171 = NOVALUE;
    _34172 = NOVALUE;

    /** execute.e:2604				pc = jump -- quit immediately, 0 iterations*/
    _67pc_65330 = _jump_68697;
L6: 
L5: 

    /** execute.e:2608		val[loopvar] = val[initial] -- initialize loop var*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34174 = (object)*(((s1_ptr)_2)->base + _initial_68695);
    Ref(_34174);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _loopvar_68696);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34174;
    if( _1 != _34174 ){
        DeRef(_1);
    }
    _34174 = NOVALUE;

    /** execute.e:2610	end procedure*/
    DeRef(_34152);
    _34152 = NOVALUE;
    DeRef(_34150);
    _34150 = NOVALUE;
    DeRef(_34154);
    _34154 = NOVALUE;
    DeRef(_34146);
    _34146 = NOVALUE;
    DeRef(_34148);
    _34148 = NOVALUE;
    return;
    ;
}


void _67opENDFOR_GENERAL()
{
    object _loopvar_68741 = NOVALUE;
    object _increment_68742 = NOVALUE;
    object _limit_68743 = NOVALUE;
    object _next_68744 = NOVALUE;
    object _34192 = NOVALUE;
    object _34188 = NOVALUE;
    object _34183 = NOVALUE;
    object _34181 = NOVALUE;
    object _34179 = NOVALUE;
    object _34178 = NOVALUE;
    object _34176 = NOVALUE;
    object _34175 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2619		limit = val[Code[pc+2]]*/
    _34175 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _34176 = (object)*(((s1_ptr)_2)->base + _34175);
    DeRef(_limit_68743);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!IS_ATOM_INT(_34176)){
        _limit_68743 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34176)->dbl));
    }
    else{
        _limit_68743 = (object)*(((s1_ptr)_2)->base + _34176);
    }
    Ref(_limit_68743);

    /** execute.e:2620		increment = val[Code[pc+4]]*/
    _34178 = _67pc_65330 + 4LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _34179 = (object)*(((s1_ptr)_2)->base + _34178);
    DeRef(_increment_68742);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!IS_ATOM_INT(_34179)){
        _increment_68742 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34179)->dbl));
    }
    else{
        _increment_68742 = (object)*(((s1_ptr)_2)->base + _34179);
    }
    Ref(_increment_68742);

    /** execute.e:2621		loopvar = Code[pc+3]*/
    _34181 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _loopvar_68741 = (object)*(((s1_ptr)_2)->base + _34181);
    if (!IS_ATOM_INT(_loopvar_68741)){
        _loopvar_68741 = (object)DBL_PTR(_loopvar_68741)->dbl;
    }

    /** execute.e:2622		next = val[loopvar] + increment*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34183 = (object)*(((s1_ptr)_2)->base + _loopvar_68741);
    DeRef(_next_68744);
    if (IS_ATOM_INT(_34183) && IS_ATOM_INT(_increment_68742)) {
        _next_68744 = _34183 + _increment_68742;
        if ((object)((uintptr_t)_next_68744 + (uintptr_t)HIGH_BITS) >= 0){
            _next_68744 = NewDouble((eudouble)_next_68744);
        }
    }
    else {
        _next_68744 = binary_op(PLUS, _34183, _increment_68742);
    }
    _34183 = NOVALUE;

    /** execute.e:2624		if increment >= 0 then*/
    if (binary_op_a(LESS, _increment_68742, 0LL)){
        goto L1; // [71] 120
    }

    /** execute.e:2626			if next > limit then*/
    if (binary_op_a(LESSEQ, _next_68744, _limit_68743)){
        goto L2; // [77] 92
    }

    /** execute.e:2627				pc += 5 -- exit loop*/
    _67pc_65330 = _67pc_65330 + 5LL;
    goto L3; // [89] 163
L2: 

    /** execute.e:2629				val[loopvar] = next*/
    Ref(_next_68744);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _loopvar_68741);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _next_68744;
    DeRef(_1);

    /** execute.e:2630				pc = Code[pc+1] -- loop again*/
    _34188 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65330 = (object)*(((s1_ptr)_2)->base + _34188);
    if (!IS_ATOM_INT(_67pc_65330)){
        _67pc_65330 = (object)DBL_PTR(_67pc_65330)->dbl;
    }
    goto L3; // [117] 163
L1: 

    /** execute.e:2634			if next < limit then*/
    if (binary_op_a(GREATEREQ, _next_68744, _limit_68743)){
        goto L4; // [122] 137
    }

    /** execute.e:2635				pc += 5 -- exit loop*/
    _67pc_65330 = _67pc_65330 + 5LL;
    goto L5; // [134] 162
L4: 

    /** execute.e:2637				val[loopvar] = next*/
    Ref(_next_68744);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _loopvar_68741);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _next_68744;
    DeRef(_1);

    /** execute.e:2638				pc = Code[pc+1] -- loop again*/
    _34192 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65330 = (object)*(((s1_ptr)_2)->base + _34192);
    if (!IS_ATOM_INT(_67pc_65330)){
        _67pc_65330 = (object)DBL_PTR(_67pc_65330)->dbl;
    }
L5: 
L3: 

    /** execute.e:2641	end procedure*/
    DeRef(_increment_68742);
    DeRef(_limit_68743);
    DeRef(_next_68744);
    DeRef(_34192);
    _34192 = NOVALUE;
    _34176 = NOVALUE;
    DeRef(_34188);
    _34188 = NOVALUE;
    DeRef(_34181);
    _34181 = NOVALUE;
    DeRef(_34178);
    _34178 = NOVALUE;
    DeRef(_34175);
    _34175 = NOVALUE;
    _34179 = NOVALUE;
    return;
    ;
}


void _67opENDFOR_INT_UP1()
{
    object _loopvar_68777 = NOVALUE;
    object _limit_68778 = NOVALUE;
    object _next_68779 = NOVALUE;
    object _34203 = NOVALUE;
    object _34199 = NOVALUE;
    object _34197 = NOVALUE;
    object _34195 = NOVALUE;
    object _34194 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2651		limit = val[Code[pc+2]]*/
    _34194 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _34195 = (object)*(((s1_ptr)_2)->base + _34194);
    DeRef(_limit_68778);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!IS_ATOM_INT(_34195)){
        _limit_68778 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34195)->dbl));
    }
    else{
        _limit_68778 = (object)*(((s1_ptr)_2)->base + _34195);
    }
    Ref(_limit_68778);

    /** execute.e:2652		loopvar = Code[pc+3]*/
    _34197 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _loopvar_68777 = (object)*(((s1_ptr)_2)->base + _34197);
    if (!IS_ATOM_INT(_loopvar_68777)){
        _loopvar_68777 = (object)DBL_PTR(_loopvar_68777)->dbl;
    }

    /** execute.e:2653		next = val[loopvar] + 1*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34199 = (object)*(((s1_ptr)_2)->base + _loopvar_68777);
    DeRef(_next_68779);
    if (IS_ATOM_INT(_34199)) {
        _next_68779 = _34199 + 1;
        if (_next_68779 > MAXINT){
            _next_68779 = NewDouble((eudouble)_next_68779);
        }
    }
    else
    _next_68779 = binary_op(PLUS, 1, _34199);
    _34199 = NOVALUE;

    /** execute.e:2656		if next > limit then*/
    if (binary_op_a(LESSEQ, _next_68779, _limit_68778)){
        goto L1; // [51] 66
    }

    /** execute.e:2657			pc += 5 -- exit loop*/
    _67pc_65330 = _67pc_65330 + 5LL;
    goto L2; // [63] 91
L1: 

    /** execute.e:2659			val[loopvar] = next*/
    Ref(_next_68779);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _loopvar_68777);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _next_68779;
    DeRef(_1);

    /** execute.e:2660			pc = Code[pc+1] -- loop again*/
    _34203 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65330 = (object)*(((s1_ptr)_2)->base + _34203);
    if (!IS_ATOM_INT(_67pc_65330)){
        _67pc_65330 = (object)DBL_PTR(_67pc_65330)->dbl;
    }
L2: 

    /** execute.e:2662	end procedure*/
    DeRef(_limit_68778);
    DeRef(_next_68779);
    DeRef(_34197);
    _34197 = NOVALUE;
    DeRef(_34203);
    _34203 = NOVALUE;
    _34195 = NOVALUE;
    DeRef(_34194);
    _34194 = NOVALUE;
    return;
    ;
}


object _67RTLookup(object _name_68798, object _file_68799, object _proc_68801, object _stlen_68802)
{
    object _s_68804 = NOVALUE;
    object _global_found_68805 = NOVALUE;
    object _ns_68806 = NOVALUE;
    object _colon_68807 = NOVALUE;
    object _ns_file_68808 = NOVALUE;
    object _found_in_path_68809 = NOVALUE;
    object _found_outside_path_68810 = NOVALUE;
    object _s_in_include_path_68811 = NOVALUE;
    object _scope_68908 = NOVALUE;
    object _34432 = NOVALUE;
    object _34431 = NOVALUE;
    object _34430 = NOVALUE;
    object _34429 = NOVALUE;
    object _34427 = NOVALUE;
    object _34425 = NOVALUE;
    object _34424 = NOVALUE;
    object _34423 = NOVALUE;
    object _34422 = NOVALUE;
    object _34421 = NOVALUE;
    object _34420 = NOVALUE;
    object _34419 = NOVALUE;
    object _34418 = NOVALUE;
    object _34417 = NOVALUE;
    object _34416 = NOVALUE;
    object _34415 = NOVALUE;
    object _34414 = NOVALUE;
    object _34412 = NOVALUE;
    object _34411 = NOVALUE;
    object _34410 = NOVALUE;
    object _34409 = NOVALUE;
    object _34408 = NOVALUE;
    object _34407 = NOVALUE;
    object _34406 = NOVALUE;
    object _34405 = NOVALUE;
    object _34404 = NOVALUE;
    object _34403 = NOVALUE;
    object _34402 = NOVALUE;
    object _34401 = NOVALUE;
    object _34396 = NOVALUE;
    object _34395 = NOVALUE;
    object _34394 = NOVALUE;
    object _34393 = NOVALUE;
    object _34392 = NOVALUE;
    object _34391 = NOVALUE;
    object _34390 = NOVALUE;
    object _34389 = NOVALUE;
    object _34388 = NOVALUE;
    object _34387 = NOVALUE;
    object _34386 = NOVALUE;
    object _34385 = NOVALUE;
    object _34384 = NOVALUE;
    object _34383 = NOVALUE;
    object _34382 = NOVALUE;
    object _34381 = NOVALUE;
    object _34380 = NOVALUE;
    object _34379 = NOVALUE;
    object _34377 = NOVALUE;
    object _34375 = NOVALUE;
    object _34374 = NOVALUE;
    object _34373 = NOVALUE;
    object _34372 = NOVALUE;
    object _34371 = NOVALUE;
    object _34370 = NOVALUE;
    object _34369 = NOVALUE;
    object _34368 = NOVALUE;
    object _34367 = NOVALUE;
    object _34366 = NOVALUE;
    object _34365 = NOVALUE;
    object _34364 = NOVALUE;
    object _34363 = NOVALUE;
    object _34362 = NOVALUE;
    object _34361 = NOVALUE;
    object _34360 = NOVALUE;
    object _34359 = NOVALUE;
    object _34358 = NOVALUE;
    object _34357 = NOVALUE;
    object _34356 = NOVALUE;
    object _34355 = NOVALUE;
    object _34354 = NOVALUE;
    object _34353 = NOVALUE;
    object _34352 = NOVALUE;
    object _34351 = NOVALUE;
    object _34350 = NOVALUE;
    object _34349 = NOVALUE;
    object _34348 = NOVALUE;
    object _34347 = NOVALUE;
    object _34346 = NOVALUE;
    object _34345 = NOVALUE;
    object _34344 = NOVALUE;
    object _34343 = NOVALUE;
    object _34341 = NOVALUE;
    object _34339 = NOVALUE;
    object _34338 = NOVALUE;
    object _34337 = NOVALUE;
    object _34336 = NOVALUE;
    object _34335 = NOVALUE;
    object _34334 = NOVALUE;
    object _34333 = NOVALUE;
    object _34332 = NOVALUE;
    object _34331 = NOVALUE;
    object _34330 = NOVALUE;
    object _34329 = NOVALUE;
    object _34328 = NOVALUE;
    object _34326 = NOVALUE;
    object _34323 = NOVALUE;
    object _34322 = NOVALUE;
    object _34321 = NOVALUE;
    object _34320 = NOVALUE;
    object _34319 = NOVALUE;
    object _34318 = NOVALUE;
    object _34317 = NOVALUE;
    object _34316 = NOVALUE;
    object _34315 = NOVALUE;
    object _34314 = NOVALUE;
    object _34313 = NOVALUE;
    object _34312 = NOVALUE;
    object _34311 = NOVALUE;
    object _34310 = NOVALUE;
    object _34309 = NOVALUE;
    object _34308 = NOVALUE;
    object _34307 = NOVALUE;
    object _34306 = NOVALUE;
    object _34305 = NOVALUE;
    object _34304 = NOVALUE;
    object _34303 = NOVALUE;
    object _34302 = NOVALUE;
    object _34301 = NOVALUE;
    object _34300 = NOVALUE;
    object _34299 = NOVALUE;
    object _34298 = NOVALUE;
    object _34297 = NOVALUE;
    object _34296 = NOVALUE;
    object _34295 = NOVALUE;
    object _34294 = NOVALUE;
    object _34293 = NOVALUE;
    object _34292 = NOVALUE;
    object _34291 = NOVALUE;
    object _34290 = NOVALUE;
    object _34289 = NOVALUE;
    object _34288 = NOVALUE;
    object _34287 = NOVALUE;
    object _34286 = NOVALUE;
    object _34285 = NOVALUE;
    object _34284 = NOVALUE;
    object _34283 = NOVALUE;
    object _34282 = NOVALUE;
    object _34281 = NOVALUE;
    object _34280 = NOVALUE;
    object _34279 = NOVALUE;
    object _34278 = NOVALUE;
    object _34277 = NOVALUE;
    object _34276 = NOVALUE;
    object _34275 = NOVALUE;
    object _34273 = NOVALUE;
    object _34272 = NOVALUE;
    object _34271 = NOVALUE;
    object _34270 = NOVALUE;
    object _34269 = NOVALUE;
    object _34268 = NOVALUE;
    object _34267 = NOVALUE;
    object _34266 = NOVALUE;
    object _34264 = NOVALUE;
    object _34262 = NOVALUE;
    object _34261 = NOVALUE;
    object _34260 = NOVALUE;
    object _34259 = NOVALUE;
    object _34258 = NOVALUE;
    object _34257 = NOVALUE;
    object _34256 = NOVALUE;
    object _34255 = NOVALUE;
    object _34251 = NOVALUE;
    object _34250 = NOVALUE;
    object _34249 = NOVALUE;
    object _34248 = NOVALUE;
    object _34247 = NOVALUE;
    object _34246 = NOVALUE;
    object _34245 = NOVALUE;
    object _34244 = NOVALUE;
    object _34243 = NOVALUE;
    object _34242 = NOVALUE;
    object _34241 = NOVALUE;
    object _34240 = NOVALUE;
    object _34237 = NOVALUE;
    object _34236 = NOVALUE;
    object _34234 = NOVALUE;
    object _34233 = NOVALUE;
    object _34231 = NOVALUE;
    object _34230 = NOVALUE;
    object _34229 = NOVALUE;
    object _34228 = NOVALUE;
    object _34227 = NOVALUE;
    object _34226 = NOVALUE;
    object _34225 = NOVALUE;
    object _34224 = NOVALUE;
    object _34222 = NOVALUE;
    object _34221 = NOVALUE;
    object _34220 = NOVALUE;
    object _34219 = NOVALUE;
    object _34218 = NOVALUE;
    object _34217 = NOVALUE;
    object _34216 = NOVALUE;
    object _34215 = NOVALUE;
    object _34214 = NOVALUE;
    object _34213 = NOVALUE;
    object _34212 = NOVALUE;
    object _34210 = NOVALUE;
    object _34209 = NOVALUE;
    object _34207 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2673		sequence ns*/

    /** execute.e:2674		integer colon*/

    /** execute.e:2675		integer ns_file*/

    /** execute.e:2676		integer found_in_path*/

    /** execute.e:2677		integer found_outside_path*/

    /** execute.e:2678		integer s_in_include_path*/

    /** execute.e:2680		stlen = length( SymTab )*/
    if (IS_SEQUENCE(_28SymTab_11572)){
            _stlen_68802 = SEQ_PTR(_28SymTab_11572)->length;
    }
    else {
        _stlen_68802 = 1;
    }

    /** execute.e:2681		colon = find(':', name)*/
    _colon_68807 = find_from(58LL, _name_68798, 1LL);

    /** execute.e:2683		if colon then*/
    if (_colon_68807 == 0)
    {
        goto L1; // [37] 827
    }
    else{
    }

    /** execute.e:2685			ns = name[1..colon-1]*/
    _34207 = _colon_68807 - 1LL;
    rhs_slice_target = (object_ptr)&_ns_68806;
    RHS_Slice(_name_68798, 1LL, _34207);

    /** execute.e:2686			name = name[colon+1..$]*/
    _34209 = _colon_68807 + 1;
    if (IS_SEQUENCE(_name_68798)){
            _34210 = SEQ_PTR(_name_68798)->length;
    }
    else {
        _34210 = 1;
    }
    rhs_slice_target = (object_ptr)&_name_68798;
    RHS_Slice(_name_68798, _34209, _34210);

    /** execute.e:2689			while length(ns) and (ns[$] = ' ' or ns[$] = '\t') do*/
L2: 
    if (IS_SEQUENCE(_ns_68806)){
            _34212 = SEQ_PTR(_ns_68806)->length;
    }
    else {
        _34212 = 1;
    }
    if (_34212 == 0) {
        goto L3; // [73] 130
    }
    if (IS_SEQUENCE(_ns_68806)){
            _34214 = SEQ_PTR(_ns_68806)->length;
    }
    else {
        _34214 = 1;
    }
    _2 = (object)SEQ_PTR(_ns_68806);
    _34215 = (object)*(((s1_ptr)_2)->base + _34214);
    if (IS_ATOM_INT(_34215)) {
        _34216 = (_34215 == 32LL);
    }
    else {
        _34216 = binary_op(EQUALS, _34215, 32LL);
    }
    _34215 = NOVALUE;
    if (IS_ATOM_INT(_34216)) {
        if (_34216 != 0) {
            DeRef(_34217);
            _34217 = 1;
            goto L4; // [88] 107
        }
    }
    else {
        if (DBL_PTR(_34216)->dbl != 0.0) {
            DeRef(_34217);
            _34217 = 1;
            goto L4; // [88] 107
        }
    }
    if (IS_SEQUENCE(_ns_68806)){
            _34218 = SEQ_PTR(_ns_68806)->length;
    }
    else {
        _34218 = 1;
    }
    _2 = (object)SEQ_PTR(_ns_68806);
    _34219 = (object)*(((s1_ptr)_2)->base + _34218);
    if (IS_ATOM_INT(_34219)) {
        _34220 = (_34219 == 9LL);
    }
    else {
        _34220 = binary_op(EQUALS, _34219, 9LL);
    }
    _34219 = NOVALUE;
    DeRef(_34217);
    if (IS_ATOM_INT(_34220))
    _34217 = (_34220 != 0);
    else
    _34217 = DBL_PTR(_34220)->dbl != 0.0;
L4: 
    if (_34217 == 0)
    {
        _34217 = NOVALUE;
        goto L3; // [108] 130
    }
    else{
        _34217 = NOVALUE;
    }

    /** execute.e:2690				ns = ns[1..$-1]*/
    if (IS_SEQUENCE(_ns_68806)){
            _34221 = SEQ_PTR(_ns_68806)->length;
    }
    else {
        _34221 = 1;
    }
    _34222 = _34221 - 1LL;
    _34221 = NOVALUE;
    rhs_slice_target = (object_ptr)&_ns_68806;
    RHS_Slice(_ns_68806, 1LL, _34222);

    /** execute.e:2691			end while*/
    goto L2; // [127] 70
L3: 

    /** execute.e:2694			while length(ns) and (ns[1] = ' ' or ns[1] = '\t') do*/
L5: 
    if (IS_SEQUENCE(_ns_68806)){
            _34224 = SEQ_PTR(_ns_68806)->length;
    }
    else {
        _34224 = 1;
    }
    if (_34224 == 0) {
        goto L6; // [138] 185
    }
    _2 = (object)SEQ_PTR(_ns_68806);
    _34226 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_34226)) {
        _34227 = (_34226 == 32LL);
    }
    else {
        _34227 = binary_op(EQUALS, _34226, 32LL);
    }
    _34226 = NOVALUE;
    if (IS_ATOM_INT(_34227)) {
        if (_34227 != 0) {
            DeRef(_34228);
            _34228 = 1;
            goto L7; // [150] 166
        }
    }
    else {
        if (DBL_PTR(_34227)->dbl != 0.0) {
            DeRef(_34228);
            _34228 = 1;
            goto L7; // [150] 166
        }
    }
    _2 = (object)SEQ_PTR(_ns_68806);
    _34229 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_34229)) {
        _34230 = (_34229 == 9LL);
    }
    else {
        _34230 = binary_op(EQUALS, _34229, 9LL);
    }
    _34229 = NOVALUE;
    DeRef(_34228);
    if (IS_ATOM_INT(_34230))
    _34228 = (_34230 != 0);
    else
    _34228 = DBL_PTR(_34230)->dbl != 0.0;
L7: 
    if (_34228 == 0)
    {
        _34228 = NOVALUE;
        goto L6; // [167] 185
    }
    else{
        _34228 = NOVALUE;
    }

    /** execute.e:2695				ns = ns[2..$]*/
    if (IS_SEQUENCE(_ns_68806)){
            _34231 = SEQ_PTR(_ns_68806)->length;
    }
    else {
        _34231 = 1;
    }
    rhs_slice_target = (object_ptr)&_ns_68806;
    RHS_Slice(_ns_68806, 2LL, _34231);

    /** execute.e:2696			end while*/
    goto L5; // [182] 135
L6: 

    /** execute.e:2698			if length(ns) = 0 or equal( ns, "eu") then*/
    if (IS_SEQUENCE(_ns_68806)){
            _34233 = SEQ_PTR(_ns_68806)->length;
    }
    else {
        _34233 = 1;
    }
    _34234 = (_34233 == 0LL);
    _34233 = NOVALUE;
    if (_34234 != 0) {
        goto L8; // [194] 207
    }
    if (_ns_68806 == _23930)
    _34236 = 1;
    else if (IS_ATOM_INT(_ns_68806) && IS_ATOM_INT(_23930))
    _34236 = 0;
    else
    _34236 = (compare(_ns_68806, _23930) == 0);
    if (_34236 == 0)
    {
        _34236 = NOVALUE;
        goto L9; // [203] 214
    }
    else{
        _34236 = NOVALUE;
    }
L8: 

    /** execute.e:2699				return 0 -- bad syntax*/
    DeRefDS(_name_68798);
    DeRef(_ns_68806);
    DeRef(_34209);
    _34209 = NOVALUE;
    DeRef(_34227);
    _34227 = NOVALUE;
    DeRef(_34220);
    _34220 = NOVALUE;
    DeRef(_34234);
    _34234 = NOVALUE;
    DeRef(_34222);
    _34222 = NOVALUE;
    DeRef(_34207);
    _34207 = NOVALUE;
    DeRef(_34230);
    _34230 = NOVALUE;
    DeRef(_34216);
    _34216 = NOVALUE;
    return 0LL;
L9: 

    /** execute.e:2703			s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34237 = (object)*(((s1_ptr)_2)->base + _27TopLevelSub_20578);
    _2 = (object)SEQ_PTR(_34237);
    _s_68804 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_68804)){
        _s_68804 = (object)DBL_PTR(_s_68804)->dbl;
    }
    _34237 = NOVALUE;

    /** execute.e:2704			while s != 0 do*/
LA: 
    if (_s_68804 == 0LL)
    goto LB; // [237] 335

    /** execute.e:2705				if file = SymTab[s][S_FILE_NO] and*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34240 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34240);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _34241 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _34241 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _34240 = NOVALUE;
    if (IS_ATOM_INT(_34241)) {
        _34242 = (_file_68799 == _34241);
    }
    else {
        _34242 = binary_op(EQUALS, _file_68799, _34241);
    }
    _34241 = NOVALUE;
    if (IS_ATOM_INT(_34242)) {
        if (_34242 == 0) {
            DeRef(_34243);
            _34243 = 0;
            goto LC; // [259] 285
        }
    }
    else {
        if (DBL_PTR(_34242)->dbl == 0.0) {
            DeRef(_34243);
            _34243 = 0;
            goto LC; // [259] 285
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34244 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34244);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _34245 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _34245 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _34244 = NOVALUE;
    if (IS_ATOM_INT(_34245)) {
        _34246 = (_34245 == 523LL);
    }
    else {
        _34246 = binary_op(EQUALS, _34245, 523LL);
    }
    _34245 = NOVALUE;
    DeRef(_34243);
    if (IS_ATOM_INT(_34246))
    _34243 = (_34246 != 0);
    else
    _34243 = DBL_PTR(_34246)->dbl != 0.0;
LC: 
    if (_34243 == 0) {
        goto LD; // [285] 314
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34248 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34248);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _34249 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _34249 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _34248 = NOVALUE;
    if (_ns_68806 == _34249)
    _34250 = 1;
    else if (IS_ATOM_INT(_ns_68806) && IS_ATOM_INT(_34249))
    _34250 = 0;
    else
    _34250 = (compare(_ns_68806, _34249) == 0);
    _34249 = NOVALUE;
    if (_34250 == 0)
    {
        _34250 = NOVALUE;
        goto LD; // [306] 314
    }
    else{
        _34250 = NOVALUE;
    }

    /** execute.e:2708					exit*/
    goto LB; // [311] 335
LD: 

    /** execute.e:2710				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34251 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34251);
    _s_68804 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_68804)){
        _s_68804 = (object)DBL_PTR(_s_68804)->dbl;
    }
    _34251 = NOVALUE;

    /** execute.e:2711			end while*/
    goto LA; // [332] 237
LB: 

    /** execute.e:2713			if s = 0 then*/
    if (_s_68804 != 0LL)
    goto LE; // [337] 348

    /** execute.e:2714				return 0 -- couldn't find ns*/
    DeRefDS(_name_68798);
    DeRef(_ns_68806);
    DeRef(_34242);
    _34242 = NOVALUE;
    DeRef(_34209);
    _34209 = NOVALUE;
    DeRef(_34246);
    _34246 = NOVALUE;
    DeRef(_34227);
    _34227 = NOVALUE;
    DeRef(_34220);
    _34220 = NOVALUE;
    DeRef(_34234);
    _34234 = NOVALUE;
    DeRef(_34222);
    _34222 = NOVALUE;
    DeRef(_34207);
    _34207 = NOVALUE;
    DeRef(_34230);
    _34230 = NOVALUE;
    DeRef(_34216);
    _34216 = NOVALUE;
    return 0LL;
LE: 

    /** execute.e:2717			ns_file = val[s]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _ns_file_68808 = (object)*(((s1_ptr)_2)->base + _s_68804);
    if (!IS_ATOM_INT(_ns_file_68808))
    _ns_file_68808 = (object)DBL_PTR(_ns_file_68808)->dbl;

    /** execute.e:2720			while length(name) and (name[1] = ' ' or name[1] = '\t') do*/
LF: 
    if (IS_SEQUENCE(_name_68798)){
            _34255 = SEQ_PTR(_name_68798)->length;
    }
    else {
        _34255 = 1;
    }
    if (_34255 == 0) {
        goto L10; // [364] 411
    }
    _2 = (object)SEQ_PTR(_name_68798);
    _34257 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_34257)) {
        _34258 = (_34257 == 32LL);
    }
    else {
        _34258 = binary_op(EQUALS, _34257, 32LL);
    }
    _34257 = NOVALUE;
    if (IS_ATOM_INT(_34258)) {
        if (_34258 != 0) {
            DeRef(_34259);
            _34259 = 1;
            goto L11; // [376] 392
        }
    }
    else {
        if (DBL_PTR(_34258)->dbl != 0.0) {
            DeRef(_34259);
            _34259 = 1;
            goto L11; // [376] 392
        }
    }
    _2 = (object)SEQ_PTR(_name_68798);
    _34260 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_34260)) {
        _34261 = (_34260 == 9LL);
    }
    else {
        _34261 = binary_op(EQUALS, _34260, 9LL);
    }
    _34260 = NOVALUE;
    DeRef(_34259);
    if (IS_ATOM_INT(_34261))
    _34259 = (_34261 != 0);
    else
    _34259 = DBL_PTR(_34261)->dbl != 0.0;
L11: 
    if (_34259 == 0)
    {
        _34259 = NOVALUE;
        goto L10; // [393] 411
    }
    else{
        _34259 = NOVALUE;
    }

    /** execute.e:2721				name = name[2..$]*/
    if (IS_SEQUENCE(_name_68798)){
            _34262 = SEQ_PTR(_name_68798)->length;
    }
    else {
        _34262 = 1;
    }
    rhs_slice_target = (object_ptr)&_name_68798;
    RHS_Slice(_name_68798, 2LL, _34262);

    /** execute.e:2722			end while*/
    goto LF; // [408] 361
L10: 

    /** execute.e:2725			s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34264 = (object)*(((s1_ptr)_2)->base + _27TopLevelSub_20578);
    _2 = (object)SEQ_PTR(_34264);
    _s_68804 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_68804)){
        _s_68804 = (object)DBL_PTR(_s_68804)->dbl;
    }
    _34264 = NOVALUE;

    /** execute.e:2726			while s != 0 and (s <= stlen or SymTab[s][S_SCOPE] = SC_PRIVATE) do*/
L12: 
    _34266 = (_s_68804 != 0LL);
    if (_34266 == 0) {
        goto L13; // [438] 818
    }
    _34268 = (_s_68804 <= _stlen_68802);
    if (_34268 != 0) {
        DeRef(_34269);
        _34269 = 1;
        goto L14; // [446] 472
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34270 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34270);
    _34271 = (object)*(((s1_ptr)_2)->base + 4LL);
    _34270 = NOVALUE;
    if (IS_ATOM_INT(_34271)) {
        _34272 = (_34271 == 3LL);
    }
    else {
        _34272 = binary_op(EQUALS, _34271, 3LL);
    }
    _34271 = NOVALUE;
    if (IS_ATOM_INT(_34272))
    _34269 = (_34272 != 0);
    else
    _34269 = DBL_PTR(_34272)->dbl != 0.0;
L14: 
    if (_34269 == 0)
    {
        _34269 = NOVALUE;
        goto L13; // [473] 818
    }
    else{
        _34269 = NOVALUE;
    }

    /** execute.e:2727				integer scope = SymTab[s][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34273 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34273);
    _scope_68908 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_scope_68908)){
        _scope_68908 = (object)DBL_PTR(_scope_68908)->dbl;
    }
    _34273 = NOVALUE;

    /** execute.e:2728				if (((scope = SC_PUBLIC) and*/
    _34275 = (_scope_68908 == 13LL);
    if (_34275 == 0) {
        _34276 = 0;
        goto L15; // [500] 584
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34277 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34277);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _34278 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _34278 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _34277 = NOVALUE;
    if (IS_ATOM_INT(_34278)) {
        _34279 = (_34278 == _ns_file_68808);
    }
    else {
        _34279 = binary_op(EQUALS, _34278, _ns_file_68808);
    }
    _34278 = NOVALUE;
    if (IS_ATOM_INT(_34279)) {
        if (_34279 != 0) {
            DeRef(_34280);
            _34280 = 1;
            goto L16; // [520] 580
        }
    }
    else {
        if (DBL_PTR(_34279)->dbl != 0.0) {
            DeRef(_34280);
            _34280 = 1;
            goto L16; // [520] 580
        }
    }
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _34281 = (object)*(((s1_ptr)_2)->base + _ns_file_68808);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34282 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34282);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _34283 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _34283 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _34282 = NOVALUE;
    _2 = (object)SEQ_PTR(_34281);
    if (!IS_ATOM_INT(_34283)){
        _34284 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34283)->dbl));
    }
    else{
        _34284 = (object)*(((s1_ptr)_2)->base + _34283);
    }
    _34281 = NOVALUE;
    if (IS_ATOM_INT(_34284)) {
        {uintptr_t tu;
             tu = (uintptr_t)4LL & (uintptr_t)_34284;
             _34285 = MAKE_UINT(tu);
        }
    }
    else {
        _34285 = binary_op(AND_BITS, 4LL, _34284);
    }
    _34284 = NOVALUE;
    if (IS_ATOM_INT(_34285)) {
        if (_34285 == 0) {
            DeRef(_34286);
            _34286 = 0;
            goto L17; // [552] 576
        }
    }
    else {
        if (DBL_PTR(_34285)->dbl == 0.0) {
            DeRef(_34286);
            _34286 = 0;
            goto L17; // [552] 576
        }
    }
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _34287 = (object)*(((s1_ptr)_2)->base + _file_68799);
    _2 = (object)SEQ_PTR(_34287);
    _34288 = (object)*(((s1_ptr)_2)->base + _ns_file_68808);
    _34287 = NOVALUE;
    if (IS_ATOM_INT(_34288)) {
        {uintptr_t tu;
             tu = (uintptr_t)6LL & (uintptr_t)_34288;
             _34289 = MAKE_UINT(tu);
        }
    }
    else {
        _34289 = binary_op(AND_BITS, 6LL, _34288);
    }
    _34288 = NOVALUE;
    DeRef(_34286);
    if (IS_ATOM_INT(_34289))
    _34286 = (_34289 != 0);
    else
    _34286 = DBL_PTR(_34289)->dbl != 0.0;
L17: 
    DeRef(_34280);
    _34280 = (_34286 != 0);
L16: 
    _34276 = (_34280 != 0);
L15: 
    if (_34276 != 0) {
        _34290 = 1;
        goto L18; // [584] 646
    }
    _34291 = (_scope_68908 == 11LL);
    if (_34291 == 0) {
        _34292 = 0;
        goto L19; // [594] 618
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34293 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34293);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _34294 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _34294 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _34293 = NOVALUE;
    if (IS_ATOM_INT(_34294)) {
        _34295 = (_34294 == _ns_file_68808);
    }
    else {
        _34295 = binary_op(EQUALS, _34294, _ns_file_68808);
    }
    _34294 = NOVALUE;
    if (IS_ATOM_INT(_34295))
    _34292 = (_34295 != 0);
    else
    _34292 = DBL_PTR(_34295)->dbl != 0.0;
L19: 
    if (_34292 == 0) {
        _34296 = 0;
        goto L1A; // [618] 642
    }
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _34297 = (object)*(((s1_ptr)_2)->base + _file_68799);
    _2 = (object)SEQ_PTR(_34297);
    _34298 = (object)*(((s1_ptr)_2)->base + _ns_file_68808);
    _34297 = NOVALUE;
    if (IS_ATOM_INT(_34298)) {
        {uintptr_t tu;
             tu = (uintptr_t)2LL & (uintptr_t)_34298;
             _34299 = MAKE_UINT(tu);
        }
    }
    else {
        _34299 = binary_op(AND_BITS, 2LL, _34298);
    }
    _34298 = NOVALUE;
    if (IS_ATOM_INT(_34299))
    _34296 = (_34299 != 0);
    else
    _34296 = DBL_PTR(_34299)->dbl != 0.0;
L1A: 
    _34290 = (_34296 != 0);
L18: 
    if (_34290 != 0) {
        _34300 = 1;
        goto L1B; // [646] 660
    }
    _34301 = (_scope_68908 == 6LL);
    _34300 = (_34301 != 0);
L1B: 
    if (_34300 == 0) {
        _34302 = 0;
        goto L1C; // [660] 738
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34303 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34303);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _34304 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _34304 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _34303 = NOVALUE;
    if (IS_ATOM_INT(_34304)) {
        _34305 = (_34304 == _ns_file_68808);
    }
    else {
        _34305 = binary_op(EQUALS, _34304, _ns_file_68808);
    }
    _34304 = NOVALUE;
    if (IS_ATOM_INT(_34305)) {
        if (_34305 != 0) {
            DeRef(_34306);
            _34306 = 1;
            goto L1D; // [680] 734
        }
    }
    else {
        if (DBL_PTR(_34305)->dbl != 0.0) {
            DeRef(_34306);
            _34306 = 1;
            goto L1D; // [680] 734
        }
    }
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _34307 = (object)*(((s1_ptr)_2)->base + _ns_file_68808);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34308 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34308);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _34309 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _34309 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _34308 = NOVALUE;
    _2 = (object)SEQ_PTR(_34307);
    if (!IS_ATOM_INT(_34309)){
        _34310 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34309)->dbl));
    }
    else{
        _34310 = (object)*(((s1_ptr)_2)->base + _34309);
    }
    _34307 = NOVALUE;
    if (IS_ATOM_INT(_34310)) {
        if (_34310 == 0) {
            DeRef(_34311);
            _34311 = 0;
            goto L1E; // [706] 730
        }
    }
    else {
        if (DBL_PTR(_34310)->dbl == 0.0) {
            DeRef(_34311);
            _34311 = 0;
            goto L1E; // [706] 730
        }
    }
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _34312 = (object)*(((s1_ptr)_2)->base + _file_68799);
    _2 = (object)SEQ_PTR(_34312);
    _34313 = (object)*(((s1_ptr)_2)->base + _ns_file_68808);
    _34312 = NOVALUE;
    if (IS_ATOM_INT(_34313)) {
        {uintptr_t tu;
             tu = (uintptr_t)6LL & (uintptr_t)_34313;
             _34314 = MAKE_UINT(tu);
        }
    }
    else {
        _34314 = binary_op(AND_BITS, 6LL, _34313);
    }
    _34313 = NOVALUE;
    DeRef(_34311);
    if (IS_ATOM_INT(_34314))
    _34311 = (_34314 != 0);
    else
    _34311 = DBL_PTR(_34314)->dbl != 0.0;
L1E: 
    DeRef(_34306);
    _34306 = (_34311 != 0);
L1D: 
    _34302 = (_34306 != 0);
L1C: 
    if (_34302 != 0) {
        _34315 = 1;
        goto L1F; // [738] 764
    }
    _34316 = (_scope_68908 == 5LL);
    if (_34316 == 0) {
        _34317 = 0;
        goto L20; // [748] 760
    }
    _34318 = (_ns_file_68808 == _file_68799);
    _34317 = (_34318 != 0);
L20: 
    _34315 = (_34317 != 0);
L1F: 
    if (_34315 == 0) {
        goto L21; // [764] 795
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34320 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34320);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _34321 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _34321 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _34320 = NOVALUE;
    if (_34321 == _name_68798)
    _34322 = 1;
    else if (IS_ATOM_INT(_34321) && IS_ATOM_INT(_name_68798))
    _34322 = 0;
    else
    _34322 = (compare(_34321, _name_68798) == 0);
    _34321 = NOVALUE;
    if (_34322 == 0)
    {
        _34322 = NOVALUE;
        goto L21; // [785] 795
    }
    else{
        _34322 = NOVALUE;
    }

    /** execute.e:2744					return s*/
    DeRefDS(_name_68798);
    DeRef(_ns_68806);
    DeRef(_34258);
    _34258 = NOVALUE;
    _34309 = NOVALUE;
    DeRef(_34289);
    _34289 = NOVALUE;
    DeRef(_34242);
    _34242 = NOVALUE;
    DeRef(_34261);
    _34261 = NOVALUE;
    DeRef(_34266);
    _34266 = NOVALUE;
    DeRef(_34316);
    _34316 = NOVALUE;
    DeRef(_34305);
    _34305 = NOVALUE;
    _34310 = NOVALUE;
    DeRef(_34209);
    _34209 = NOVALUE;
    DeRef(_34318);
    _34318 = NOVALUE;
    DeRef(_34246);
    _34246 = NOVALUE;
    DeRef(_34227);
    _34227 = NOVALUE;
    DeRef(_34220);
    _34220 = NOVALUE;
    DeRef(_34234);
    _34234 = NOVALUE;
    DeRef(_34268);
    _34268 = NOVALUE;
    DeRef(_34222);
    _34222 = NOVALUE;
    DeRef(_34207);
    _34207 = NOVALUE;
    DeRef(_34291);
    _34291 = NOVALUE;
    DeRef(_34279);
    _34279 = NOVALUE;
    DeRef(_34230);
    _34230 = NOVALUE;
    DeRef(_34272);
    _34272 = NOVALUE;
    DeRef(_34216);
    _34216 = NOVALUE;
    _34283 = NOVALUE;
    DeRef(_34275);
    _34275 = NOVALUE;
    DeRef(_34285);
    _34285 = NOVALUE;
    DeRef(_34295);
    _34295 = NOVALUE;
    DeRef(_34301);
    _34301 = NOVALUE;
    DeRef(_34314);
    _34314 = NOVALUE;
    DeRef(_34299);
    _34299 = NOVALUE;
    return _s_68804;
L21: 

    /** execute.e:2746				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34323 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34323);
    _s_68804 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_68804)){
        _s_68804 = (object)DBL_PTR(_s_68804)->dbl;
    }
    _34323 = NOVALUE;

    /** execute.e:2747			end while*/
    goto L12; // [815] 434
L13: 

    /** execute.e:2749			return 0 -- couldn't find name in ns file*/
    DeRefDS(_name_68798);
    DeRef(_ns_68806);
    DeRef(_34258);
    _34258 = NOVALUE;
    _34309 = NOVALUE;
    DeRef(_34289);
    _34289 = NOVALUE;
    DeRef(_34242);
    _34242 = NOVALUE;
    DeRef(_34261);
    _34261 = NOVALUE;
    DeRef(_34266);
    _34266 = NOVALUE;
    DeRef(_34316);
    _34316 = NOVALUE;
    DeRef(_34305);
    _34305 = NOVALUE;
    _34310 = NOVALUE;
    DeRef(_34209);
    _34209 = NOVALUE;
    DeRef(_34318);
    _34318 = NOVALUE;
    DeRef(_34246);
    _34246 = NOVALUE;
    DeRef(_34227);
    _34227 = NOVALUE;
    DeRef(_34220);
    _34220 = NOVALUE;
    DeRef(_34234);
    _34234 = NOVALUE;
    DeRef(_34268);
    _34268 = NOVALUE;
    DeRef(_34222);
    _34222 = NOVALUE;
    DeRef(_34207);
    _34207 = NOVALUE;
    DeRef(_34291);
    _34291 = NOVALUE;
    DeRef(_34279);
    _34279 = NOVALUE;
    DeRef(_34230);
    _34230 = NOVALUE;
    DeRef(_34272);
    _34272 = NOVALUE;
    DeRef(_34216);
    _34216 = NOVALUE;
    _34283 = NOVALUE;
    DeRef(_34275);
    _34275 = NOVALUE;
    DeRef(_34285);
    _34285 = NOVALUE;
    DeRef(_34295);
    _34295 = NOVALUE;
    DeRef(_34301);
    _34301 = NOVALUE;
    DeRef(_34314);
    _34314 = NOVALUE;
    DeRef(_34299);
    _34299 = NOVALUE;
    return 0LL;
    goto L22; // [824] 1636
L1: 

    /** execute.e:2754			if proc != TopLevelSub then*/
    if (_proc_68801 == _27TopLevelSub_20578)
    goto L23; // [831] 958

    /** execute.e:2756				s = SymTab[proc][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34326 = (object)*(((s1_ptr)_2)->base + _proc_68801);
    _2 = (object)SEQ_PTR(_34326);
    _s_68804 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_68804)){
        _s_68804 = (object)DBL_PTR(_s_68804)->dbl;
    }
    _34326 = NOVALUE;

    /** execute.e:2757				while s and (SymTab[s][S_SCOPE] = SC_PRIVATE or*/
L24: 
    if (_s_68804 == 0) {
        goto L25; // [856] 957
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34329 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34329);
    _34330 = (object)*(((s1_ptr)_2)->base + 4LL);
    _34329 = NOVALUE;
    if (IS_ATOM_INT(_34330)) {
        _34331 = (_34330 == 3LL);
    }
    else {
        _34331 = binary_op(EQUALS, _34330, 3LL);
    }
    _34330 = NOVALUE;
    if (IS_ATOM_INT(_34331)) {
        if (_34331 != 0) {
            DeRef(_34332);
            _34332 = 1;
            goto L26; // [878] 904
        }
    }
    else {
        if (DBL_PTR(_34331)->dbl != 0.0) {
            DeRef(_34332);
            _34332 = 1;
            goto L26; // [878] 904
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34333 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34333);
    _34334 = (object)*(((s1_ptr)_2)->base + 4LL);
    _34333 = NOVALUE;
    if (IS_ATOM_INT(_34334)) {
        _34335 = (_34334 == 2LL);
    }
    else {
        _34335 = binary_op(EQUALS, _34334, 2LL);
    }
    _34334 = NOVALUE;
    DeRef(_34332);
    if (IS_ATOM_INT(_34335))
    _34332 = (_34335 != 0);
    else
    _34332 = DBL_PTR(_34335)->dbl != 0.0;
L26: 
    if (_34332 == 0)
    {
        _34332 = NOVALUE;
        goto L25; // [905] 957
    }
    else{
        _34332 = NOVALUE;
    }

    /** execute.e:2759					if equal(name, SymTab[s][S_NAME]) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34336 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34336);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _34337 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _34337 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _34336 = NOVALUE;
    if (_name_68798 == _34337)
    _34338 = 1;
    else if (IS_ATOM_INT(_name_68798) && IS_ATOM_INT(_34337))
    _34338 = 0;
    else
    _34338 = (compare(_name_68798, _34337) == 0);
    _34337 = NOVALUE;
    if (_34338 == 0)
    {
        _34338 = NOVALUE;
        goto L27; // [926] 936
    }
    else{
        _34338 = NOVALUE;
    }

    /** execute.e:2760						return s*/
    DeRefDS(_name_68798);
    DeRef(_ns_68806);
    DeRef(_34258);
    _34258 = NOVALUE;
    DeRef(_34335);
    _34335 = NOVALUE;
    _34309 = NOVALUE;
    DeRef(_34289);
    _34289 = NOVALUE;
    DeRef(_34242);
    _34242 = NOVALUE;
    DeRef(_34261);
    _34261 = NOVALUE;
    DeRef(_34266);
    _34266 = NOVALUE;
    DeRef(_34331);
    _34331 = NOVALUE;
    DeRef(_34316);
    _34316 = NOVALUE;
    DeRef(_34305);
    _34305 = NOVALUE;
    _34310 = NOVALUE;
    DeRef(_34209);
    _34209 = NOVALUE;
    DeRef(_34318);
    _34318 = NOVALUE;
    DeRef(_34246);
    _34246 = NOVALUE;
    DeRef(_34227);
    _34227 = NOVALUE;
    DeRef(_34220);
    _34220 = NOVALUE;
    DeRef(_34234);
    _34234 = NOVALUE;
    DeRef(_34268);
    _34268 = NOVALUE;
    DeRef(_34222);
    _34222 = NOVALUE;
    DeRef(_34207);
    _34207 = NOVALUE;
    DeRef(_34291);
    _34291 = NOVALUE;
    DeRef(_34279);
    _34279 = NOVALUE;
    DeRef(_34230);
    _34230 = NOVALUE;
    DeRef(_34272);
    _34272 = NOVALUE;
    DeRef(_34216);
    _34216 = NOVALUE;
    _34283 = NOVALUE;
    DeRef(_34275);
    _34275 = NOVALUE;
    DeRef(_34285);
    _34285 = NOVALUE;
    DeRef(_34295);
    _34295 = NOVALUE;
    DeRef(_34301);
    _34301 = NOVALUE;
    DeRef(_34314);
    _34314 = NOVALUE;
    DeRef(_34299);
    _34299 = NOVALUE;
    return _s_68804;
L27: 

    /** execute.e:2762					s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34339 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34339);
    _s_68804 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_68804)){
        _s_68804 = (object)DBL_PTR(_s_68804)->dbl;
    }
    _34339 = NOVALUE;

    /** execute.e:2763				end while*/
    goto L24; // [954] 856
L25: 
L23: 

    /** execute.e:2767			s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34341 = (object)*(((s1_ptr)_2)->base + _27TopLevelSub_20578);
    _2 = (object)SEQ_PTR(_34341);
    _s_68804 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_68804)){
        _s_68804 = (object)DBL_PTR(_s_68804)->dbl;
    }
    _34341 = NOVALUE;

    /** execute.e:2768			found_in_path = 0*/
    _found_in_path_68809 = 0LL;

    /** execute.e:2769			found_outside_path = 0*/
    _found_outside_path_68810 = 0LL;

    /** execute.e:2771			while s != 0 and (s <= stlen or SymTab[s][S_SCOPE] = SC_PRIVATE) do*/
L28: 
    _34343 = (_s_68804 != 0LL);
    if (_34343 == 0) {
        goto L29; // [995] 1221
    }
    _34345 = (_s_68804 <= _stlen_68802);
    if (_34345 != 0) {
        DeRef(_34346);
        _34346 = 1;
        goto L2A; // [1003] 1029
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34347 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34347);
    _34348 = (object)*(((s1_ptr)_2)->base + 4LL);
    _34347 = NOVALUE;
    if (IS_ATOM_INT(_34348)) {
        _34349 = (_34348 == 3LL);
    }
    else {
        _34349 = binary_op(EQUALS, _34348, 3LL);
    }
    _34348 = NOVALUE;
    if (IS_ATOM_INT(_34349))
    _34346 = (_34349 != 0);
    else
    _34346 = DBL_PTR(_34349)->dbl != 0.0;
L2A: 
    if (_34346 == 0)
    {
        _34346 = NOVALUE;
        goto L29; // [1030] 1221
    }
    else{
        _34346 = NOVALUE;
    }

    /** execute.e:2773				if SymTab[s][S_FILE_NO] = file and*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34350 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34350);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _34351 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _34351 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _34350 = NOVALUE;
    if (IS_ATOM_INT(_34351)) {
        _34352 = (_34351 == _file_68799);
    }
    else {
        _34352 = binary_op(EQUALS, _34351, _file_68799);
    }
    _34351 = NOVALUE;
    if (IS_ATOM_INT(_34352)) {
        if (_34352 == 0) {
            DeRef(_34353);
            _34353 = 0;
            goto L2B; // [1051] 1169
        }
    }
    else {
        if (DBL_PTR(_34352)->dbl == 0.0) {
            DeRef(_34353);
            _34353 = 0;
            goto L2B; // [1051] 1169
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34354 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34354);
    _34355 = (object)*(((s1_ptr)_2)->base + 4LL);
    _34354 = NOVALUE;
    if (IS_ATOM_INT(_34355)) {
        _34356 = (_34355 == 5LL);
    }
    else {
        _34356 = binary_op(EQUALS, _34355, 5LL);
    }
    _34355 = NOVALUE;
    if (IS_ATOM_INT(_34356)) {
        if (_34356 != 0) {
            DeRef(_34357);
            _34357 = 1;
            goto L2C; // [1073] 1099
        }
    }
    else {
        if (DBL_PTR(_34356)->dbl != 0.0) {
            DeRef(_34357);
            _34357 = 1;
            goto L2C; // [1073] 1099
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34358 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34358);
    _34359 = (object)*(((s1_ptr)_2)->base + 4LL);
    _34358 = NOVALUE;
    if (IS_ATOM_INT(_34359)) {
        _34360 = (_34359 == 6LL);
    }
    else {
        _34360 = binary_op(EQUALS, _34359, 6LL);
    }
    _34359 = NOVALUE;
    DeRef(_34357);
    if (IS_ATOM_INT(_34360))
    _34357 = (_34360 != 0);
    else
    _34357 = DBL_PTR(_34360)->dbl != 0.0;
L2C: 
    if (_34357 != 0) {
        _34361 = 1;
        goto L2D; // [1099] 1125
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34362 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34362);
    _34363 = (object)*(((s1_ptr)_2)->base + 4LL);
    _34362 = NOVALUE;
    if (IS_ATOM_INT(_34363)) {
        _34364 = (_34363 == 11LL);
    }
    else {
        _34364 = binary_op(EQUALS, _34363, 11LL);
    }
    _34363 = NOVALUE;
    if (IS_ATOM_INT(_34364))
    _34361 = (_34364 != 0);
    else
    _34361 = DBL_PTR(_34364)->dbl != 0.0;
L2D: 
    if (_34361 != 0) {
        _34365 = 1;
        goto L2E; // [1125] 1165
    }
    _34366 = (_proc_68801 == _27TopLevelSub_20578);
    if (_34366 == 0) {
        _34367 = 0;
        goto L2F; // [1135] 1161
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34368 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34368);
    _34369 = (object)*(((s1_ptr)_2)->base + 4LL);
    _34368 = NOVALUE;
    if (IS_ATOM_INT(_34369)) {
        _34370 = (_34369 == 4LL);
    }
    else {
        _34370 = binary_op(EQUALS, _34369, 4LL);
    }
    _34369 = NOVALUE;
    if (IS_ATOM_INT(_34370))
    _34367 = (_34370 != 0);
    else
    _34367 = DBL_PTR(_34370)->dbl != 0.0;
L2F: 
    _34365 = (_34367 != 0);
L2E: 
    DeRef(_34353);
    _34353 = (_34365 != 0);
L2B: 
    if (_34353 == 0) {
        goto L30; // [1169] 1200
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34372 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34372);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _34373 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _34373 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _34372 = NOVALUE;
    if (_name_68798 == _34373)
    _34374 = 1;
    else if (IS_ATOM_INT(_name_68798) && IS_ATOM_INT(_34373))
    _34374 = 0;
    else
    _34374 = (compare(_name_68798, _34373) == 0);
    _34373 = NOVALUE;
    if (_34374 == 0)
    {
        _34374 = NOVALUE;
        goto L30; // [1190] 1200
    }
    else{
        _34374 = NOVALUE;
    }

    /** execute.e:2782					return s*/
    DeRefDS(_name_68798);
    DeRef(_ns_68806);
    DeRef(_34258);
    _34258 = NOVALUE;
    DeRef(_34335);
    _34335 = NOVALUE;
    DeRef(_34364);
    _34364 = NOVALUE;
    _34309 = NOVALUE;
    DeRef(_34366);
    _34366 = NOVALUE;
    DeRef(_34289);
    _34289 = NOVALUE;
    DeRef(_34242);
    _34242 = NOVALUE;
    DeRef(_34356);
    _34356 = NOVALUE;
    DeRef(_34261);
    _34261 = NOVALUE;
    DeRef(_34266);
    _34266 = NOVALUE;
    DeRef(_34331);
    _34331 = NOVALUE;
    DeRef(_34316);
    _34316 = NOVALUE;
    DeRef(_34305);
    _34305 = NOVALUE;
    _34310 = NOVALUE;
    DeRef(_34209);
    _34209 = NOVALUE;
    DeRef(_34318);
    _34318 = NOVALUE;
    DeRef(_34246);
    _34246 = NOVALUE;
    DeRef(_34227);
    _34227 = NOVALUE;
    DeRef(_34220);
    _34220 = NOVALUE;
    DeRef(_34360);
    _34360 = NOVALUE;
    DeRef(_34234);
    _34234 = NOVALUE;
    DeRef(_34370);
    _34370 = NOVALUE;
    DeRef(_34268);
    _34268 = NOVALUE;
    DeRef(_34222);
    _34222 = NOVALUE;
    DeRef(_34207);
    _34207 = NOVALUE;
    DeRef(_34345);
    _34345 = NOVALUE;
    DeRef(_34352);
    _34352 = NOVALUE;
    DeRef(_34349);
    _34349 = NOVALUE;
    DeRef(_34291);
    _34291 = NOVALUE;
    DeRef(_34279);
    _34279 = NOVALUE;
    DeRef(_34230);
    _34230 = NOVALUE;
    DeRef(_34272);
    _34272 = NOVALUE;
    DeRef(_34216);
    _34216 = NOVALUE;
    _34283 = NOVALUE;
    DeRef(_34275);
    _34275 = NOVALUE;
    DeRef(_34285);
    _34285 = NOVALUE;
    DeRef(_34343);
    _34343 = NOVALUE;
    DeRef(_34295);
    _34295 = NOVALUE;
    DeRef(_34301);
    _34301 = NOVALUE;
    DeRef(_34314);
    _34314 = NOVALUE;
    DeRef(_34299);
    _34299 = NOVALUE;
    return _s_68804;
L30: 

    /** execute.e:2784				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34375 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34375);
    _s_68804 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_68804)){
        _s_68804 = (object)DBL_PTR(_s_68804)->dbl;
    }
    _34375 = NOVALUE;

    /** execute.e:2785			end while*/
    goto L28; // [1218] 991
L29: 

    /** execute.e:2787			global_found = FALSE*/
    _global_found_68805 = _9FALSE_439;

    /** execute.e:2788			s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34377 = (object)*(((s1_ptr)_2)->base + _27TopLevelSub_20578);
    _2 = (object)SEQ_PTR(_34377);
    _s_68804 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_68804)){
        _s_68804 = (object)DBL_PTR(_s_68804)->dbl;
    }
    _34377 = NOVALUE;

    /** execute.e:2789			while s != 0 and (s <= stlen or SymTab[s][S_SCOPE] = SC_PRIVATE) do*/
L31: 
    _34379 = (_s_68804 != 0LL);
    if (_34379 == 0) {
        goto L32; // [1257] 1600
    }
    _34381 = (_s_68804 <= _stlen_68802);
    if (_34381 != 0) {
        DeRef(_34382);
        _34382 = 1;
        goto L33; // [1265] 1291
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34383 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34383);
    _34384 = (object)*(((s1_ptr)_2)->base + 4LL);
    _34383 = NOVALUE;
    if (IS_ATOM_INT(_34384)) {
        _34385 = (_34384 == 3LL);
    }
    else {
        _34385 = binary_op(EQUALS, _34384, 3LL);
    }
    _34384 = NOVALUE;
    if (IS_ATOM_INT(_34385))
    _34382 = (_34385 != 0);
    else
    _34382 = DBL_PTR(_34385)->dbl != 0.0;
L33: 
    if (_34382 == 0)
    {
        _34382 = NOVALUE;
        goto L32; // [1292] 1600
    }
    else{
        _34382 = NOVALUE;
    }

    /** execute.e:2790				if SymTab[s][S_SCOPE] = SC_GLOBAL and*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34386 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34386);
    _34387 = (object)*(((s1_ptr)_2)->base + 4LL);
    _34386 = NOVALUE;
    if (IS_ATOM_INT(_34387)) {
        _34388 = (_34387 == 6LL);
    }
    else {
        _34388 = binary_op(EQUALS, _34387, 6LL);
    }
    _34387 = NOVALUE;
    if (IS_ATOM_INT(_34388)) {
        if (_34388 == 0) {
            goto L34; // [1315] 1413
        }
    }
    else {
        if (DBL_PTR(_34388)->dbl == 0.0) {
            goto L34; // [1315] 1413
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34390 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34390);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _34391 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _34391 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _34390 = NOVALUE;
    if (_name_68798 == _34391)
    _34392 = 1;
    else if (IS_ATOM_INT(_name_68798) && IS_ATOM_INT(_34391))
    _34392 = 0;
    else
    _34392 = (compare(_name_68798, _34391) == 0);
    _34391 = NOVALUE;
    if (_34392 == 0)
    {
        _34392 = NOVALUE;
        goto L34; // [1336] 1413
    }
    else{
        _34392 = NOVALUE;
    }

    /** execute.e:2793					s_in_include_path = include_matrix[file][SymTab[s][S_FILE_NO]] != 0*/
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _34393 = (object)*(((s1_ptr)_2)->base + _file_68799);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34394 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34394);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _34395 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _34395 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _34394 = NOVALUE;
    _2 = (object)SEQ_PTR(_34393);
    if (!IS_ATOM_INT(_34395)){
        _34396 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34395)->dbl));
    }
    else{
        _34396 = (object)*(((s1_ptr)_2)->base + _34395);
    }
    _34393 = NOVALUE;
    if (IS_ATOM_INT(_34396)) {
        _s_in_include_path_68811 = (_34396 != 0LL);
    }
    else {
        _s_in_include_path_68811 = binary_op(NOTEQ, _34396, 0LL);
    }
    _34396 = NOVALUE;
    if (!IS_ATOM_INT(_s_in_include_path_68811)) {
        _1 = (object)(DBL_PTR(_s_in_include_path_68811)->dbl);
        DeRefDS(_s_in_include_path_68811);
        _s_in_include_path_68811 = _1;
    }

    /** execute.e:2794					if s_in_include_path then*/
    if (_s_in_include_path_68811 == 0)
    {
        goto L35; // [1371] 1390
    }
    else{
    }

    /** execute.e:2795						global_found = s*/
    _global_found_68805 = _s_68804;

    /** execute.e:2796						found_in_path += 1*/
    _found_in_path_68809 = _found_in_path_68809 + 1;
    goto L36; // [1387] 1579
L35: 

    /** execute.e:2798						if not found_in_path then*/
    if (_found_in_path_68809 != 0)
    goto L37; // [1392] 1403

    /** execute.e:2799							global_found = s*/
    _global_found_68805 = _s_68804;
L37: 

    /** execute.e:2801						found_outside_path += 1*/
    _found_outside_path_68810 = _found_outside_path_68810 + 1;
    goto L36; // [1410] 1579
L34: 

    /** execute.e:2803				elsif (sym_scope( s ) = SC_PUBLIC and equal( name, SymTab[s][S_NAME] ) and*/
    _34401 = _53sym_scope(_s_68804);
    if (IS_ATOM_INT(_34401)) {
        _34402 = (_34401 == 13LL);
    }
    else {
        _34402 = binary_op(EQUALS, _34401, 13LL);
    }
    DeRef(_34401);
    _34401 = NOVALUE;
    if (IS_ATOM_INT(_34402)) {
        if (_34402 == 0) {
            DeRef(_34403);
            _34403 = 0;
            goto L38; // [1425] 1449
        }
    }
    else {
        if (DBL_PTR(_34402)->dbl == 0.0) {
            DeRef(_34403);
            _34403 = 0;
            goto L38; // [1425] 1449
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34404 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34404);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _34405 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _34405 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _34404 = NOVALUE;
    if (_name_68798 == _34405)
    _34406 = 1;
    else if (IS_ATOM_INT(_name_68798) && IS_ATOM_INT(_34405))
    _34406 = 0;
    else
    _34406 = (compare(_name_68798, _34405) == 0);
    _34405 = NOVALUE;
    DeRef(_34403);
    _34403 = (_34406 != 0);
L38: 
    if (_34403 == 0) {
        _34407 = 0;
        goto L39; // [1449] 1485
    }
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _34408 = (object)*(((s1_ptr)_2)->base + _file_68799);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34409 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34409);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _34410 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _34410 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _34409 = NOVALUE;
    _2 = (object)SEQ_PTR(_34408);
    if (!IS_ATOM_INT(_34410)){
        _34411 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34410)->dbl));
    }
    else{
        _34411 = (object)*(((s1_ptr)_2)->base + _34410);
    }
    _34408 = NOVALUE;
    if (IS_ATOM_INT(_34411)) {
        {uintptr_t tu;
             tu = (uintptr_t)6LL & (uintptr_t)_34411;
             _34412 = MAKE_UINT(tu);
        }
    }
    else {
        _34412 = binary_op(AND_BITS, 6LL, _34411);
    }
    _34411 = NOVALUE;
    if (IS_ATOM_INT(_34412))
    _34407 = (_34412 != 0);
    else
    _34407 = DBL_PTR(_34412)->dbl != 0.0;
L39: 
    if (_34407 != 0) {
        goto L3A; // [1485] 1564
    }
    _34414 = _53sym_scope(_s_68804);
    if (IS_ATOM_INT(_34414)) {
        _34415 = (_34414 == 11LL);
    }
    else {
        _34415 = binary_op(EQUALS, _34414, 11LL);
    }
    DeRef(_34414);
    _34414 = NOVALUE;
    if (IS_ATOM_INT(_34415)) {
        if (_34415 == 0) {
            DeRef(_34416);
            _34416 = 0;
            goto L3B; // [1499] 1523
        }
    }
    else {
        if (DBL_PTR(_34415)->dbl == 0.0) {
            DeRef(_34416);
            _34416 = 0;
            goto L3B; // [1499] 1523
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34417 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34417);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _34418 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _34418 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _34417 = NOVALUE;
    if (_name_68798 == _34418)
    _34419 = 1;
    else if (IS_ATOM_INT(_name_68798) && IS_ATOM_INT(_34418))
    _34419 = 0;
    else
    _34419 = (compare(_name_68798, _34418) == 0);
    _34418 = NOVALUE;
    DeRef(_34416);
    _34416 = (_34419 != 0);
L3B: 
    if (_34416 == 0) {
        DeRef(_34420);
        _34420 = 0;
        goto L3C; // [1523] 1559
    }
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _34421 = (object)*(((s1_ptr)_2)->base + _file_68799);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34422 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34422);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _34423 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _34423 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _34422 = NOVALUE;
    _2 = (object)SEQ_PTR(_34421);
    if (!IS_ATOM_INT(_34423)){
        _34424 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34423)->dbl));
    }
    else{
        _34424 = (object)*(((s1_ptr)_2)->base + _34423);
    }
    _34421 = NOVALUE;
    if (IS_ATOM_INT(_34424)) {
        {uintptr_t tu;
             tu = (uintptr_t)2LL & (uintptr_t)_34424;
             _34425 = MAKE_UINT(tu);
        }
    }
    else {
        _34425 = binary_op(AND_BITS, 2LL, _34424);
    }
    _34424 = NOVALUE;
    if (IS_ATOM_INT(_34425))
    _34420 = (_34425 != 0);
    else
    _34420 = DBL_PTR(_34425)->dbl != 0.0;
L3C: 
    if (_34420 == 0)
    {
        _34420 = NOVALUE;
        goto L3D; // [1560] 1578
    }
    else{
        _34420 = NOVALUE;
    }
L3A: 

    /** execute.e:2808					global_found = s*/
    _global_found_68805 = _s_68804;

    /** execute.e:2809					found_in_path += 1*/
    _found_in_path_68809 = _found_in_path_68809 + 1;
L3D: 
L36: 

    /** execute.e:2811				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34427 = (object)*(((s1_ptr)_2)->base + _s_68804);
    _2 = (object)SEQ_PTR(_34427);
    _s_68804 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_68804)){
        _s_68804 = (object)DBL_PTR(_s_68804)->dbl;
    }
    _34427 = NOVALUE;

    /** execute.e:2812			end while*/
    goto L31; // [1597] 1253
L32: 

    /** execute.e:2814			if found_in_path != 1 and (( found_in_path + found_outside_path ) != 1 ) then*/
    _34429 = (_found_in_path_68809 != 1LL);
    if (_34429 == 0) {
        goto L3E; // [1606] 1629
    }
    _34431 = _found_in_path_68809 + _found_outside_path_68810;
    if ((object)((uintptr_t)_34431 + (uintptr_t)HIGH_BITS) >= 0){
        _34431 = NewDouble((eudouble)_34431);
    }
    if (IS_ATOM_INT(_34431)) {
        _34432 = (_34431 != 1LL);
    }
    else {
        _34432 = (DBL_PTR(_34431)->dbl != (eudouble)1LL);
    }
    DeRef(_34431);
    _34431 = NOVALUE;
    if (_34432 == 0)
    {
        DeRef(_34432);
        _34432 = NOVALUE;
        goto L3E; // [1619] 1629
    }
    else{
        DeRef(_34432);
        _34432 = NOVALUE;
    }

    /** execute.e:2815				return 0*/
    DeRefDS(_name_68798);
    DeRef(_ns_68806);
    DeRef(_34258);
    _34258 = NOVALUE;
    DeRef(_34335);
    _34335 = NOVALUE;
    DeRef(_34364);
    _34364 = NOVALUE;
    _34309 = NOVALUE;
    DeRef(_34366);
    _34366 = NOVALUE;
    DeRef(_34289);
    _34289 = NOVALUE;
    DeRef(_34242);
    _34242 = NOVALUE;
    DeRef(_34356);
    _34356 = NOVALUE;
    DeRef(_34261);
    _34261 = NOVALUE;
    DeRef(_34266);
    _34266 = NOVALUE;
    DeRef(_34331);
    _34331 = NOVALUE;
    DeRef(_34415);
    _34415 = NOVALUE;
    DeRef(_34316);
    _34316 = NOVALUE;
    DeRef(_34305);
    _34305 = NOVALUE;
    _34310 = NOVALUE;
    DeRef(_34209);
    _34209 = NOVALUE;
    DeRef(_34402);
    _34402 = NOVALUE;
    DeRef(_34318);
    _34318 = NOVALUE;
    DeRef(_34246);
    _34246 = NOVALUE;
    DeRef(_34227);
    _34227 = NOVALUE;
    DeRef(_34220);
    _34220 = NOVALUE;
    DeRef(_34360);
    _34360 = NOVALUE;
    DeRef(_34234);
    _34234 = NOVALUE;
    DeRef(_34370);
    _34370 = NOVALUE;
    DeRef(_34268);
    _34268 = NOVALUE;
    DeRef(_34385);
    _34385 = NOVALUE;
    DeRef(_34222);
    _34222 = NOVALUE;
    DeRef(_34207);
    _34207 = NOVALUE;
    DeRef(_34429);
    _34429 = NOVALUE;
    DeRef(_34345);
    _34345 = NOVALUE;
    DeRef(_34381);
    _34381 = NOVALUE;
    DeRef(_34352);
    _34352 = NOVALUE;
    DeRef(_34349);
    _34349 = NOVALUE;
    DeRef(_34291);
    _34291 = NOVALUE;
    _34410 = NOVALUE;
    DeRef(_34279);
    _34279 = NOVALUE;
    DeRef(_34412);
    _34412 = NOVALUE;
    DeRef(_34230);
    _34230 = NOVALUE;
    DeRef(_34388);
    _34388 = NOVALUE;
    DeRef(_34272);
    _34272 = NOVALUE;
    DeRef(_34216);
    _34216 = NOVALUE;
    _34283 = NOVALUE;
    DeRef(_34275);
    _34275 = NOVALUE;
    DeRef(_34285);
    _34285 = NOVALUE;
    _34395 = NOVALUE;
    DeRef(_34343);
    _34343 = NOVALUE;
    _34423 = NOVALUE;
    DeRef(_34295);
    _34295 = NOVALUE;
    DeRef(_34301);
    _34301 = NOVALUE;
    DeRef(_34379);
    _34379 = NOVALUE;
    DeRef(_34314);
    _34314 = NOVALUE;
    DeRef(_34425);
    _34425 = NOVALUE;
    DeRef(_34299);
    _34299 = NOVALUE;
    return 0LL;
L3E: 

    /** execute.e:2817			return global_found*/
    DeRefDS(_name_68798);
    DeRef(_ns_68806);
    DeRef(_34258);
    _34258 = NOVALUE;
    DeRef(_34335);
    _34335 = NOVALUE;
    DeRef(_34364);
    _34364 = NOVALUE;
    _34309 = NOVALUE;
    DeRef(_34366);
    _34366 = NOVALUE;
    DeRef(_34289);
    _34289 = NOVALUE;
    DeRef(_34242);
    _34242 = NOVALUE;
    DeRef(_34356);
    _34356 = NOVALUE;
    DeRef(_34261);
    _34261 = NOVALUE;
    DeRef(_34266);
    _34266 = NOVALUE;
    DeRef(_34331);
    _34331 = NOVALUE;
    DeRef(_34415);
    _34415 = NOVALUE;
    DeRef(_34316);
    _34316 = NOVALUE;
    DeRef(_34305);
    _34305 = NOVALUE;
    _34310 = NOVALUE;
    DeRef(_34209);
    _34209 = NOVALUE;
    DeRef(_34402);
    _34402 = NOVALUE;
    DeRef(_34318);
    _34318 = NOVALUE;
    DeRef(_34246);
    _34246 = NOVALUE;
    DeRef(_34227);
    _34227 = NOVALUE;
    DeRef(_34220);
    _34220 = NOVALUE;
    DeRef(_34360);
    _34360 = NOVALUE;
    DeRef(_34234);
    _34234 = NOVALUE;
    DeRef(_34370);
    _34370 = NOVALUE;
    DeRef(_34268);
    _34268 = NOVALUE;
    DeRef(_34385);
    _34385 = NOVALUE;
    DeRef(_34222);
    _34222 = NOVALUE;
    DeRef(_34207);
    _34207 = NOVALUE;
    DeRef(_34429);
    _34429 = NOVALUE;
    DeRef(_34345);
    _34345 = NOVALUE;
    DeRef(_34381);
    _34381 = NOVALUE;
    DeRef(_34352);
    _34352 = NOVALUE;
    DeRef(_34349);
    _34349 = NOVALUE;
    DeRef(_34291);
    _34291 = NOVALUE;
    _34410 = NOVALUE;
    DeRef(_34279);
    _34279 = NOVALUE;
    DeRef(_34412);
    _34412 = NOVALUE;
    DeRef(_34230);
    _34230 = NOVALUE;
    DeRef(_34388);
    _34388 = NOVALUE;
    DeRef(_34272);
    _34272 = NOVALUE;
    DeRef(_34216);
    _34216 = NOVALUE;
    _34283 = NOVALUE;
    DeRef(_34275);
    _34275 = NOVALUE;
    DeRef(_34285);
    _34285 = NOVALUE;
    _34395 = NOVALUE;
    DeRef(_34343);
    _34343 = NOVALUE;
    _34423 = NOVALUE;
    DeRef(_34295);
    _34295 = NOVALUE;
    DeRef(_34301);
    _34301 = NOVALUE;
    DeRef(_34379);
    _34379 = NOVALUE;
    DeRef(_34314);
    _34314 = NOVALUE;
    DeRef(_34425);
    _34425 = NOVALUE;
    DeRef(_34299);
    _34299 = NOVALUE;
    return _global_found_68805;
L22: 
    ;
}


void _67do_call_proc(object _sub_69186, object _args_69187, object _advance_69188)
{
    object _n_69189 = NOVALUE;
    object _arg_69190 = NOVALUE;
    object _private_block_69205 = NOVALUE;
    object _p_69211 = NOVALUE;
    object _34474 = NOVALUE;
    object _34469 = NOVALUE;
    object _34467 = NOVALUE;
    object _34466 = NOVALUE;
    object _34465 = NOVALUE;
    object _34463 = NOVALUE;
    object _34461 = NOVALUE;
    object _34458 = NOVALUE;
    object _34456 = NOVALUE;
    object _34454 = NOVALUE;
    object _34453 = NOVALUE;
    object _34452 = NOVALUE;
    object _34451 = NOVALUE;
    object _34450 = NOVALUE;
    object _34449 = NOVALUE;
    object _34447 = NOVALUE;
    object _34446 = NOVALUE;
    object _34444 = NOVALUE;
    object _34443 = NOVALUE;
    object _34441 = NOVALUE;
    object _34440 = NOVALUE;
    object _34438 = NOVALUE;
    object _34437 = NOVALUE;
    object _34435 = NOVALUE;
    object _34433 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_advance_69188)) {
        _1 = (object)(DBL_PTR(_advance_69188)->dbl);
        DeRefDS(_advance_69188);
        _advance_69188 = _1;
    }

    /** execute.e:2825		n = SymTab[sub][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34433 = (object)*(((s1_ptr)_2)->base + _sub_69186);
    _2 = (object)SEQ_PTR(_34433);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _n_69189 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _n_69189 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    if (!IS_ATOM_INT(_n_69189)){
        _n_69189 = (object)DBL_PTR(_n_69189)->dbl;
    }
    _34433 = NOVALUE;

    /** execute.e:2826		arg = SymTab[sub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34435 = (object)*(((s1_ptr)_2)->base + _sub_69186);
    _2 = (object)SEQ_PTR(_34435);
    _arg_69190 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_arg_69190)){
        _arg_69190 = (object)DBL_PTR(_arg_69190)->dbl;
    }
    _34435 = NOVALUE;

    /** execute.e:2827		if SymTab[sub][S_RESIDENT_TASK] != 0 then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34437 = (object)*(((s1_ptr)_2)->base + _sub_69186);
    _2 = (object)SEQ_PTR(_34437);
    _34438 = (object)*(((s1_ptr)_2)->base + 25LL);
    _34437 = NOVALUE;
    if (binary_op_a(EQUALS, _34438, 0LL)){
        _34438 = NOVALUE;
        goto L1; // [53] 314
    }
    _34438 = NOVALUE;

    /** execute.e:2831			sequence private_block = repeat(0, SymTab[sub][S_STACK_SPACE])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34440 = (object)*(((s1_ptr)_2)->base + _sub_69186);
    _2 = (object)SEQ_PTR(_34440);
    if (!IS_ATOM_INT(_27S_STACK_SPACE_20269)){
        _34441 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_STACK_SPACE_20269)->dbl));
    }
    else{
        _34441 = (object)*(((s1_ptr)_2)->base + _27S_STACK_SPACE_20269);
    }
    _34440 = NOVALUE;
    DeRef(_private_block_69205);
    _private_block_69205 = Repeat(0LL, _34441);
    _34441 = NOVALUE;

    /** execute.e:2832			integer p = 1*/
    _p_69211 = 1LL;

    /** execute.e:2833			for i = 1 to n do*/
    _34443 = _n_69189;
    {
        object _i_69213;
        _i_69213 = 1LL;
L2: 
        if (_i_69213 > _34443){
            goto L3; // [85] 145
        }

        /** execute.e:2834				private_block[p] = val[arg]*/
        _2 = (object)SEQ_PTR(_67val_65340);
        _34444 = (object)*(((s1_ptr)_2)->base + _arg_69190);
        Ref(_34444);
        _2 = (object)SEQ_PTR(_private_block_69205);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _private_block_69205 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _p_69211);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _34444;
        if( _1 != _34444 ){
            DeRef(_1);
        }
        _34444 = NOVALUE;

        /** execute.e:2835				p += 1*/
        _p_69211 = _p_69211 + 1;

        /** execute.e:2836				val[arg] = args[i]*/
        _2 = (object)SEQ_PTR(_args_69187);
        _34446 = (object)*(((s1_ptr)_2)->base + _i_69213);
        Ref(_34446);
        _2 = (object)SEQ_PTR(_67val_65340);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_65340 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _arg_69190);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _34446;
        if( _1 != _34446 ){
            DeRef(_1);
        }
        _34446 = NOVALUE;

        /** execute.e:2837				arg = SymTab[arg][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _34447 = (object)*(((s1_ptr)_2)->base + _arg_69190);
        _2 = (object)SEQ_PTR(_34447);
        _arg_69190 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_arg_69190)){
            _arg_69190 = (object)DBL_PTR(_arg_69190)->dbl;
        }
        _34447 = NOVALUE;

        /** execute.e:2838			end for*/
        _i_69213 = _i_69213 + 1LL;
        goto L2; // [140] 92
L3: 
        ;
    }

    /** execute.e:2841			while arg != 0 and SymTab[arg][S_SCOPE] <= SC_PRIVATE do*/
L4: 
    _34449 = (_arg_69190 != 0LL);
    if (_34449 == 0) {
        goto L5; // [154] 229
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34451 = (object)*(((s1_ptr)_2)->base + _arg_69190);
    _2 = (object)SEQ_PTR(_34451);
    _34452 = (object)*(((s1_ptr)_2)->base + 4LL);
    _34451 = NOVALUE;
    if (IS_ATOM_INT(_34452)) {
        _34453 = (_34452 <= 3LL);
    }
    else {
        _34453 = binary_op(LESSEQ, _34452, 3LL);
    }
    _34452 = NOVALUE;
    if (_34453 <= 0) {
        if (_34453 == 0) {
            DeRef(_34453);
            _34453 = NOVALUE;
            goto L5; // [177] 229
        }
        else {
            if (!IS_ATOM_INT(_34453) && DBL_PTR(_34453)->dbl == 0.0){
                DeRef(_34453);
                _34453 = NOVALUE;
                goto L5; // [177] 229
            }
            DeRef(_34453);
            _34453 = NOVALUE;
        }
    }
    DeRef(_34453);
    _34453 = NOVALUE;

    /** execute.e:2842				private_block[p] = val[arg]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34454 = (object)*(((s1_ptr)_2)->base + _arg_69190);
    Ref(_34454);
    _2 = (object)SEQ_PTR(_private_block_69205);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _private_block_69205 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _p_69211);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34454;
    if( _1 != _34454 ){
        DeRef(_1);
    }
    _34454 = NOVALUE;

    /** execute.e:2843				p += 1*/
    _p_69211 = _p_69211 + 1;

    /** execute.e:2844				val[arg] = NOVALUE -- necessary?*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _arg_69190);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);

    /** execute.e:2845				arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34456 = (object)*(((s1_ptr)_2)->base + _arg_69190);
    _2 = (object)SEQ_PTR(_34456);
    _arg_69190 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_arg_69190)){
        _arg_69190 = (object)DBL_PTR(_arg_69190)->dbl;
    }
    _34456 = NOVALUE;

    /** execute.e:2846			end while*/
    goto L4; // [226] 150
L5: 

    /** execute.e:2849			arg = SymTab[sub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34458 = (object)*(((s1_ptr)_2)->base + _sub_69186);
    _2 = (object)SEQ_PTR(_34458);
    if (!IS_ATOM_INT(_27S_TEMPS_20254)){
        _arg_69190 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TEMPS_20254)->dbl));
    }
    else{
        _arg_69190 = (object)*(((s1_ptr)_2)->base + _27S_TEMPS_20254);
    }
    if (!IS_ATOM_INT(_arg_69190)){
        _arg_69190 = (object)DBL_PTR(_arg_69190)->dbl;
    }
    _34458 = NOVALUE;

    /** execute.e:2850			while arg != 0 do*/
L6: 
    if (_arg_69190 == 0LL)
    goto L7; // [250] 303

    /** execute.e:2851				private_block[p] = val[arg]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34461 = (object)*(((s1_ptr)_2)->base + _arg_69190);
    Ref(_34461);
    _2 = (object)SEQ_PTR(_private_block_69205);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _private_block_69205 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _p_69211);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34461;
    if( _1 != _34461 ){
        DeRef(_1);
    }
    _34461 = NOVALUE;

    /** execute.e:2852				p += 1*/
    _p_69211 = _p_69211 + 1;

    /** execute.e:2853				val[arg] = NOVALUE -- necessary?*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _arg_69190);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);

    /** execute.e:2854				arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34463 = (object)*(((s1_ptr)_2)->base + _arg_69190);
    _2 = (object)SEQ_PTR(_34463);
    _arg_69190 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_arg_69190)){
        _arg_69190 = (object)DBL_PTR(_arg_69190)->dbl;
    }
    _34463 = NOVALUE;

    /** execute.e:2855			end while*/
    goto L6; // [300] 250
L7: 

    /** execute.e:2858			save_private_block(sub, private_block)*/
    RefDS(_private_block_69205);
    _67save_private_block(_sub_69186, _private_block_69205);
    DeRefDS(_private_block_69205);
    _private_block_69205 = NOVALUE;
    goto L8; // [311] 362
L1: 

    /** execute.e:2862			for i = 1 to n do*/
    _34465 = _n_69189;
    {
        object _i_69253;
        _i_69253 = 1LL;
L9: 
        if (_i_69253 > _34465){
            goto LA; // [319] 361
        }

        /** execute.e:2863				val[arg] = args[i]*/
        _2 = (object)SEQ_PTR(_args_69187);
        _34466 = (object)*(((s1_ptr)_2)->base + _i_69253);
        Ref(_34466);
        _2 = (object)SEQ_PTR(_67val_65340);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_65340 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _arg_69190);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _34466;
        if( _1 != _34466 ){
            DeRef(_1);
        }
        _34466 = NOVALUE;

        /** execute.e:2864				arg = SymTab[arg][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _34467 = (object)*(((s1_ptr)_2)->base + _arg_69190);
        _2 = (object)SEQ_PTR(_34467);
        _arg_69190 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_arg_69190)){
            _arg_69190 = (object)DBL_PTR(_arg_69190)->dbl;
        }
        _34467 = NOVALUE;

        /** execute.e:2865			end for*/
        _i_69253 = _i_69253 + 1LL;
        goto L9; // [356] 326
LA: 
        ;
    }
L8: 

    /** execute.e:2868		SymTab[sub][S_RESIDENT_TASK] = current_task*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sub_69186 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67current_task_65347;
    DeRef(_1);
    _34469 = NOVALUE;

    /** execute.e:2870		pc += advance*/
    _67pc_65330 = _67pc_65330 + _advance_69188;

    /** execute.e:2872		call_stack = append(call_stack, pc)*/
    Append(&_67call_stack_65348, _67call_stack_65348, _67pc_65330);

    /** execute.e:2873		call_stack = append(call_stack, sub)*/
    Append(&_67call_stack_65348, _67call_stack_65348, _sub_69186);

    /** execute.e:2875		Code = SymTab[sub][S_CODE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34474 = (object)*(((s1_ptr)_2)->base + _sub_69186);
    DeRef(_27Code_20660);
    _2 = (object)SEQ_PTR(_34474);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    Ref(_27Code_20660);
    _34474 = NOVALUE;

    /** execute.e:2876		pc = 1*/
    _67pc_65330 = 1LL;

    /** execute.e:2877	end procedure*/
    DeRefDS(_args_69187);
    DeRef(_34449);
    _34449 = NOVALUE;
    return;
    ;
}


void _67opCALL_PROC()
{
    object _cf_69274 = NOVALUE;
    object _sub_69276 = NOVALUE;
    object _34523 = NOVALUE;
    object _34522 = NOVALUE;
    object _34521 = NOVALUE;
    object _34520 = NOVALUE;
    object _34519 = NOVALUE;
    object _34518 = NOVALUE;
    object _34517 = NOVALUE;
    object _34516 = NOVALUE;
    object _34515 = NOVALUE;
    object _34514 = NOVALUE;
    object _34511 = NOVALUE;
    object _34510 = NOVALUE;
    object _34509 = NOVALUE;
    object _34508 = NOVALUE;
    object _34506 = NOVALUE;
    object _34505 = NOVALUE;
    object _34504 = NOVALUE;
    object _34503 = NOVALUE;
    object _34502 = NOVALUE;
    object _34499 = NOVALUE;
    object _34498 = NOVALUE;
    object _34497 = NOVALUE;
    object _34496 = NOVALUE;
    object _34495 = NOVALUE;
    object _34492 = NOVALUE;
    object _34491 = NOVALUE;
    object _34489 = NOVALUE;
    object _34487 = NOVALUE;
    object _34486 = NOVALUE;
    object _34485 = NOVALUE;
    object _34484 = NOVALUE;
    object _34483 = NOVALUE;
    object _34481 = NOVALUE;
    object _34480 = NOVALUE;
    object _34478 = NOVALUE;
    object _34476 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2884		cf = Code[pc] = CALL_FUNC*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    _34476 = (object)*(((s1_ptr)_2)->base + _67pc_65330);
    if (IS_ATOM_INT(_34476)) {
        _cf_69274 = (_34476 == 137LL);
    }
    else {
        _cf_69274 = binary_op(EQUALS, _34476, 137LL);
    }
    _34476 = NOVALUE;
    if (!IS_ATOM_INT(_cf_69274)) {
        _1 = (object)(DBL_PTR(_cf_69274)->dbl);
        DeRefDS(_cf_69274);
        _cf_69274 = _1;
    }

    /** execute.e:2886		a = Code[pc+1]  -- routine id*/
    _34478 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34478);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2887		if val[a] < 0 or val[a] >= length(e_routine) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34480 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_ATOM_INT(_34480)) {
        _34481 = (_34480 < 0LL);
    }
    else {
        _34481 = binary_op(LESS, _34480, 0LL);
    }
    _34480 = NOVALUE;
    if (IS_ATOM_INT(_34481)) {
        if (_34481 != 0) {
            goto L1; // [49] 75
        }
    }
    else {
        if (DBL_PTR(_34481)->dbl != 0.0) {
            goto L1; // [49] 75
        }
    }
    _2 = (object)SEQ_PTR(_67val_65340);
    _34483 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_SEQUENCE(_67e_routine_65379)){
            _34484 = SEQ_PTR(_67e_routine_65379)->length;
    }
    else {
        _34484 = 1;
    }
    if (IS_ATOM_INT(_34483)) {
        _34485 = (_34483 >= _34484);
    }
    else {
        _34485 = binary_op(GREATEREQ, _34483, _34484);
    }
    _34483 = NOVALUE;
    _34484 = NOVALUE;
    if (_34485 == 0) {
        DeRef(_34485);
        _34485 = NOVALUE;
        goto L2; // [71] 81
    }
    else {
        if (!IS_ATOM_INT(_34485) && DBL_PTR(_34485)->dbl == 0.0){
            DeRef(_34485);
            _34485 = NOVALUE;
            goto L2; // [71] 81
        }
        DeRef(_34485);
        _34485 = NOVALUE;
    }
    DeRef(_34485);
    _34485 = NOVALUE;
L1: 

    /** execute.e:2888			RTFatal("invalid routine id")*/
    RefDS(_32851);
    _67RTFatal(_32851);
L2: 

    /** execute.e:2891		sub = e_routine[val[a]+1]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34486 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_ATOM_INT(_34486)) {
        _34487 = _34486 + 1;
    }
    else
    _34487 = binary_op(PLUS, 1, _34486);
    _34486 = NOVALUE;
    _2 = (object)SEQ_PTR(_67e_routine_65379);
    if (!IS_ATOM_INT(_34487)){
        _sub_69276 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34487)->dbl));
    }
    else{
        _sub_69276 = (object)*(((s1_ptr)_2)->base + _34487);
    }

    /** execute.e:2892		b = Code[pc+2]  -- argument list*/
    _34489 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34489);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2894		if cf then*/
    if (_cf_69274 == 0)
    {
        goto L3; // [121] 169
    }
    else{
    }

    /** execute.e:2895			if SymTab[sub][S_TOKEN] = PROC then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34491 = (object)*(((s1_ptr)_2)->base + _sub_69276);
    _2 = (object)SEQ_PTR(_34491);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _34492 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _34492 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _34491 = NOVALUE;
    if (binary_op_a(NOTEQ, _34492, 27LL)){
        _34492 = NOVALUE;
        goto L4; // [140] 212
    }
    _34492 = NOVALUE;

    /** execute.e:2896				RTFatal(sprintf("%s() does not return a value", SymTab[sub][S_NAME]))*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34495 = (object)*(((s1_ptr)_2)->base + _sub_69276);
    _2 = (object)SEQ_PTR(_34495);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _34496 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _34496 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _34495 = NOVALUE;
    _34497 = EPrintf(-9999999, _34494, _34496);
    _34496 = NOVALUE;
    _67RTFatal(_34497);
    _34497 = NOVALUE;
    goto L4; // [166] 212
L3: 

    /** execute.e:2899			if SymTab[sub][S_TOKEN] != PROC then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34498 = (object)*(((s1_ptr)_2)->base + _sub_69276);
    _2 = (object)SEQ_PTR(_34498);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _34499 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _34499 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _34498 = NOVALUE;
    if (binary_op_a(EQUALS, _34499, 27LL)){
        _34499 = NOVALUE;
        goto L5; // [185] 211
    }
    _34499 = NOVALUE;

    /** execute.e:2900				RTFatal(sprintf("the value returned by %s() must be assigned or used",*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34502 = (object)*(((s1_ptr)_2)->base + _sub_69276);
    _2 = (object)SEQ_PTR(_34502);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _34503 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _34503 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _34502 = NOVALUE;
    _34504 = EPrintf(-9999999, _34501, _34503);
    _34503 = NOVALUE;
    _67RTFatal(_34504);
    _34504 = NOVALUE;
L5: 
L4: 

    /** execute.e:2904		if atom(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34505 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _34506 = IS_ATOM(_34505);
    _34505 = NOVALUE;
    if (_34506 == 0)
    {
        _34506 = NOVALUE;
        goto L6; // [225] 234
    }
    else{
        _34506 = NOVALUE;
    }

    /** execute.e:2905			RTFatal("argument list must be a sequence")*/
    RefDS(_34507);
    _67RTFatal(_34507);
L6: 

    /** execute.e:2908		if SymTab[sub][S_NUM_ARGS] != length(val[b]) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34508 = (object)*(((s1_ptr)_2)->base + _sub_69276);
    _2 = (object)SEQ_PTR(_34508);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _34509 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _34509 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _34508 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    _34510 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_SEQUENCE(_34510)){
            _34511 = SEQ_PTR(_34510)->length;
    }
    else {
        _34511 = 1;
    }
    _34510 = NOVALUE;
    if (binary_op_a(EQUALS, _34509, _34511)){
        _34509 = NOVALUE;
        _34511 = NOVALUE;
        goto L7; // [259] 314
    }
    _34509 = NOVALUE;
    _34511 = NOVALUE;

    /** execute.e:2909			RTFatal(sprintf("call to %s() via routine-id should pass %d arguments, not %d",*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34514 = (object)*(((s1_ptr)_2)->base + _sub_69276);
    _2 = (object)SEQ_PTR(_34514);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _34515 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _34515 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _34514 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34516 = (object)*(((s1_ptr)_2)->base + _sub_69276);
    _2 = (object)SEQ_PTR(_34516);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _34517 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _34517 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _34516 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    _34518 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_SEQUENCE(_34518)){
            _34519 = SEQ_PTR(_34518)->length;
    }
    else {
        _34519 = 1;
    }
    _34518 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_34515);
    ((intptr_t*)_2)[1] = _34515;
    Ref(_34517);
    ((intptr_t*)_2)[2] = _34517;
    ((intptr_t*)_2)[3] = _34519;
    _34520 = MAKE_SEQ(_1);
    _34519 = NOVALUE;
    _34517 = NOVALUE;
    _34515 = NOVALUE;
    _34521 = EPrintf(-9999999, _34513, _34520);
    DeRefDS(_34520);
    _34520 = NOVALUE;
    _67RTFatal(_34521);
    _34521 = NOVALUE;
L7: 

    /** execute.e:2914		do_call_proc( sub, val[b], 3 + cf )*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34522 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _34523 = 3LL + _cf_69274;
    if ((object)((uintptr_t)_34523 + (uintptr_t)HIGH_BITS) >= 0){
        _34523 = NewDouble((eudouble)_34523);
    }
    Ref(_34522);
    _67do_call_proc(_sub_69276, _34522, _34523);
    _34522 = NOVALUE;
    _34523 = NOVALUE;

    /** execute.e:2915	end procedure*/
    _34510 = NOVALUE;
    _34518 = NOVALUE;
    DeRef(_34481);
    _34481 = NOVALUE;
    DeRef(_34487);
    _34487 = NOVALUE;
    DeRef(_34489);
    _34489 = NOVALUE;
    DeRef(_34478);
    _34478 = NOVALUE;
    return;
    ;
}


void _67opROUTINE_ID()
{
    object _sub_69354 = NOVALUE;
    object _fn_69355 = NOVALUE;
    object _p_69356 = NOVALUE;
    object _stlen_69357 = NOVALUE;
    object _name_69358 = NOVALUE;
    object _34550 = NOVALUE;
    object _34549 = NOVALUE;
    object _34547 = NOVALUE;
    object _34545 = NOVALUE;
    object _34544 = NOVALUE;
    object _34543 = NOVALUE;
    object _34542 = NOVALUE;
    object _34541 = NOVALUE;
    object _34540 = NOVALUE;
    object _34538 = NOVALUE;
    object _34536 = NOVALUE;
    object _34533 = NOVALUE;
    object _34531 = NOVALUE;
    object _34529 = NOVALUE;
    object _34528 = NOVALUE;
    object _34526 = NOVALUE;
    object _34524 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2923		sub = Code[pc+1]   -- CurrentSub*/
    _34524 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _sub_69354 = (object)*(((s1_ptr)_2)->base + _34524);
    if (!IS_ATOM_INT(_sub_69354)){
        _sub_69354 = (object)DBL_PTR(_sub_69354)->dbl;
    }

    /** execute.e:2924		stlen = Code[pc+2]  -- s.t. length*/
    _34526 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _stlen_69357 = (object)*(((s1_ptr)_2)->base + _34526);
    if (!IS_ATOM_INT(_stlen_69357)){
        _stlen_69357 = (object)DBL_PTR(_stlen_69357)->dbl;
    }

    /** execute.e:2925		name = val[Code[pc+3]]  -- routine name sequence*/
    _34528 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _34529 = (object)*(((s1_ptr)_2)->base + _34528);
    DeRef(_name_69358);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!IS_ATOM_INT(_34529)){
        _name_69358 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34529)->dbl));
    }
    else{
        _name_69358 = (object)*(((s1_ptr)_2)->base + _34529);
    }
    Ref(_name_69358);

    /** execute.e:2926		fn = Code[pc+4]    -- file number*/
    _34531 = _67pc_65330 + 4LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _fn_69355 = (object)*(((s1_ptr)_2)->base + _34531);
    if (!IS_ATOM_INT(_fn_69355)){
        _fn_69355 = (object)DBL_PTR(_fn_69355)->dbl;
    }

    /** execute.e:2927		target = Code[pc+5]*/
    _34533 = _67pc_65330 + 5LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34533);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2928		pc += 6*/
    _67pc_65330 = _67pc_65330 + 6LL;

    /** execute.e:2929		if atom(name) then*/
    _34536 = IS_ATOM(_name_69358);
    if (_34536 == 0)
    {
        _34536 = NOVALUE;
        goto L1; // [98] 117
    }
    else{
        _34536 = NOVALUE;
    }

    /** execute.e:2930			val[target] = -1*/
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1LL;
    DeRef(_1);

    /** execute.e:2931			return*/
    DeRef(_name_69358);
    _34533 = NOVALUE;
    _34531 = NOVALUE;
    _34524 = NOVALUE;
    _34526 = NOVALUE;
    _34528 = NOVALUE;
    _34529 = NOVALUE;
    return;
L1: 

    /** execute.e:2934		p = RTLookup(name, fn, sub, stlen)*/
    Ref(_name_69358);
    _p_69356 = _67RTLookup(_name_69358, _fn_69355, _sub_69354, _stlen_69357);
    if (!IS_ATOM_INT(_p_69356)) {
        _1 = (object)(DBL_PTR(_p_69356)->dbl);
        DeRefDS(_p_69356);
        _p_69356 = _1;
    }

    /** execute.e:2935		if p = 0 or not find(SymTab[p][S_TOKEN], RTN_TOKS) then*/
    _34538 = (_p_69356 == 0LL);
    if (_34538 != 0) {
        goto L2; // [134] 165
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34540 = (object)*(((s1_ptr)_2)->base + _p_69356);
    _2 = (object)SEQ_PTR(_34540);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _34541 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _34541 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _34540 = NOVALUE;
    _34542 = find_from(_34541, _29RTN_TOKS_12277, 1LL);
    _34541 = NOVALUE;
    _34543 = (_34542 == 0);
    _34542 = NOVALUE;
    if (_34543 == 0)
    {
        DeRef(_34543);
        _34543 = NOVALUE;
        goto L3; // [161] 181
    }
    else{
        DeRef(_34543);
        _34543 = NOVALUE;
    }
L2: 

    /** execute.e:2936			val[target] = -1  -- name is not a routine*/
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1LL;
    DeRef(_1);

    /** execute.e:2937			return*/
    DeRef(_name_69358);
    DeRef(_34533);
    _34533 = NOVALUE;
    DeRef(_34531);
    _34531 = NOVALUE;
    DeRef(_34524);
    _34524 = NOVALUE;
    DeRef(_34538);
    _34538 = NOVALUE;
    DeRef(_34526);
    _34526 = NOVALUE;
    DeRef(_34528);
    _34528 = NOVALUE;
    _34529 = NOVALUE;
    return;
L3: 

    /** execute.e:2939		for i = 1 to length(e_routine) do*/
    if (IS_SEQUENCE(_67e_routine_65379)){
            _34544 = SEQ_PTR(_67e_routine_65379)->length;
    }
    else {
        _34544 = 1;
    }
    {
        object _i_69390;
        _i_69390 = 1LL;
L4: 
        if (_i_69390 > _34544){
            goto L5; // [188] 234
        }

        /** execute.e:2940			if e_routine[i] = p then*/
        _2 = (object)SEQ_PTR(_67e_routine_65379);
        _34545 = (object)*(((s1_ptr)_2)->base + _i_69390);
        if (_34545 != _p_69356)
        goto L6; // [203] 227

        /** execute.e:2941				val[target] = i - 1  -- routine was already assigned an id*/
        _34547 = _i_69390 - 1LL;
        _2 = (object)SEQ_PTR(_67val_65340);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_65340 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _34547;
        if( _1 != _34547 ){
            DeRef(_1);
        }
        _34547 = NOVALUE;

        /** execute.e:2942				return*/
        DeRef(_name_69358);
        DeRef(_34533);
        _34533 = NOVALUE;
        DeRef(_34531);
        _34531 = NOVALUE;
        DeRef(_34524);
        _34524 = NOVALUE;
        DeRef(_34538);
        _34538 = NOVALUE;
        _34545 = NOVALUE;
        DeRef(_34526);
        _34526 = NOVALUE;
        DeRef(_34528);
        _34528 = NOVALUE;
        _34529 = NOVALUE;
        return;
L6: 

        /** execute.e:2944		end for*/
        _i_69390 = _i_69390 + 1LL;
        goto L4; // [229] 195
L5: 
        ;
    }

    /** execute.e:2945		e_routine = append(e_routine, p)*/
    Append(&_67e_routine_65379, _67e_routine_65379, _p_69356);

    /** execute.e:2946		val[target] = length(e_routine) - 1*/
    if (IS_SEQUENCE(_67e_routine_65379)){
            _34549 = SEQ_PTR(_67e_routine_65379)->length;
    }
    else {
        _34549 = 1;
    }
    _34550 = _34549 - 1LL;
    _34549 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34550;
    if( _1 != _34550 ){
        DeRef(_1);
    }
    _34550 = NOVALUE;

    /** execute.e:2947	end procedure*/
    DeRef(_name_69358);
    DeRef(_34533);
    _34533 = NOVALUE;
    DeRef(_34531);
    _34531 = NOVALUE;
    DeRef(_34524);
    _34524 = NOVALUE;
    DeRef(_34538);
    _34538 = NOVALUE;
    _34545 = NOVALUE;
    DeRef(_34526);
    _34526 = NOVALUE;
    DeRef(_34528);
    _34528 = NOVALUE;
    _34529 = NOVALUE;
    return;
    ;
}


void _67opAPPEND()
{
    object _34559 = NOVALUE;
    object _34558 = NOVALUE;
    object _34557 = NOVALUE;
    object _34555 = NOVALUE;
    object _34553 = NOVALUE;
    object _34551 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2950		a = Code[pc+1]*/
    _34551 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34551);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2951		b = Code[pc+2]*/
    _34553 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34553);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2952		target = Code[pc+3]*/
    _34555 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34555);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2953		val[target] = append(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34557 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34558 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    Ref(_34558);
    Append(&_34559, _34557, _34558);
    _34557 = NOVALUE;
    _34558 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34559;
    if( _1 != _34559 ){
        DeRef(_1);
    }
    _34559 = NOVALUE;

    /** execute.e:2954		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:2955	end procedure*/
    _34553 = NOVALUE;
    _34555 = NOVALUE;
    _34551 = NOVALUE;
    return;
    ;
}


void _67opPREPEND()
{
    object _34569 = NOVALUE;
    object _34568 = NOVALUE;
    object _34567 = NOVALUE;
    object _34565 = NOVALUE;
    object _34563 = NOVALUE;
    object _34561 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2958		a = Code[pc+1]*/
    _34561 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34561);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2959		b = Code[pc+2]*/
    _34563 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34563);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2960		target = Code[pc+3]*/
    _34565 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34565);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2961		val[target] = prepend(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34567 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34568 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    Ref(_34568);
    Prepend(&_34569, _34567, _34568);
    _34567 = NOVALUE;
    _34568 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34569;
    if( _1 != _34569 ){
        DeRef(_1);
    }
    _34569 = NOVALUE;

    /** execute.e:2962		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:2963	end procedure*/
    _34561 = NOVALUE;
    _34563 = NOVALUE;
    _34565 = NOVALUE;
    return;
    ;
}


void _67opCONCAT()
{
    object _34579 = NOVALUE;
    object _34578 = NOVALUE;
    object _34577 = NOVALUE;
    object _34575 = NOVALUE;
    object _34573 = NOVALUE;
    object _34571 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2966		a = Code[pc+1]*/
    _34571 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34571);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2967		b = Code[pc+2]*/
    _34573 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34573);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2968		target = Code[pc+3]*/
    _34575 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34575);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2969		val[target] = val[a] & val[b]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34577 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34578 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_SEQUENCE(_34577) && IS_ATOM(_34578)) {
        Ref(_34578);
        Append(&_34579, _34577, _34578);
    }
    else if (IS_ATOM(_34577) && IS_SEQUENCE(_34578)) {
        Ref(_34577);
        Prepend(&_34579, _34578, _34577);
    }
    else {
        Concat((object_ptr)&_34579, _34577, _34578);
        _34577 = NOVALUE;
    }
    _34577 = NOVALUE;
    _34578 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34579;
    if( _1 != _34579 ){
        DeRef(_1);
    }
    _34579 = NOVALUE;

    /** execute.e:2970		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:2971	end procedure*/
    _34575 = NOVALUE;
    _34571 = NOVALUE;
    _34573 = NOVALUE;
    return;
    ;
}


void _67opCONCAT_N()
{
    object _n_69446 = NOVALUE;
    object _x_69447 = NOVALUE;
    object _34595 = NOVALUE;
    object _34593 = NOVALUE;
    object _34592 = NOVALUE;
    object _34590 = NOVALUE;
    object _34589 = NOVALUE;
    object _34588 = NOVALUE;
    object _34587 = NOVALUE;
    object _34586 = NOVALUE;
    object _34584 = NOVALUE;
    object _34583 = NOVALUE;
    object _34581 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2978		n = Code[pc+1] -- number of items*/
    _34581 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _n_69446 = (object)*(((s1_ptr)_2)->base + _34581);
    if (!IS_ATOM_INT(_n_69446)){
        _n_69446 = (object)DBL_PTR(_n_69446)->dbl;
    }

    /** execute.e:2980		x = val[Code[pc+2]] -- last one*/
    _34583 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _34584 = (object)*(((s1_ptr)_2)->base + _34583);
    DeRef(_x_69447);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!IS_ATOM_INT(_34584)){
        _x_69447 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34584)->dbl));
    }
    else{
        _x_69447 = (object)*(((s1_ptr)_2)->base + _34584);
    }
    Ref(_x_69447);

    /** execute.e:2981		for i = pc+3 to pc+n+1 do*/
    _34586 = _67pc_65330 + 3LL;
    if ((object)((uintptr_t)_34586 + (uintptr_t)HIGH_BITS) >= 0){
        _34586 = NewDouble((eudouble)_34586);
    }
    _34587 = _67pc_65330 + _n_69446;
    if ((object)((uintptr_t)_34587 + (uintptr_t)HIGH_BITS) >= 0){
        _34587 = NewDouble((eudouble)_34587);
    }
    if (IS_ATOM_INT(_34587)) {
        _34588 = _34587 + 1;
        if (_34588 > MAXINT){
            _34588 = NewDouble((eudouble)_34588);
        }
    }
    else
    _34588 = binary_op(PLUS, 1, _34587);
    DeRef(_34587);
    _34587 = NOVALUE;
    {
        object _i_69456;
        Ref(_34586);
        _i_69456 = _34586;
L1: 
        if (binary_op_a(GREATER, _i_69456, _34588)){
            goto L2; // [55] 87
        }

        /** execute.e:2982			x = val[Code[i]] & x*/
        _2 = (object)SEQ_PTR(_27Code_20660);
        if (!IS_ATOM_INT(_i_69456)){
            _34589 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_69456)->dbl));
        }
        else{
            _34589 = (object)*(((s1_ptr)_2)->base + _i_69456);
        }
        _2 = (object)SEQ_PTR(_67val_65340);
        if (!IS_ATOM_INT(_34589)){
            _34590 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34589)->dbl));
        }
        else{
            _34590 = (object)*(((s1_ptr)_2)->base + _34589);
        }
        if (IS_SEQUENCE(_34590) && IS_ATOM(_x_69447)) {
            Ref(_x_69447);
            Append(&_x_69447, _34590, _x_69447);
        }
        else if (IS_ATOM(_34590) && IS_SEQUENCE(_x_69447)) {
            Ref(_34590);
            Prepend(&_x_69447, _x_69447, _34590);
        }
        else {
            Concat((object_ptr)&_x_69447, _34590, _x_69447);
            _34590 = NOVALUE;
        }
        _34590 = NOVALUE;

        /** execute.e:2983		end for*/
        _0 = _i_69456;
        if (IS_ATOM_INT(_i_69456)) {
            _i_69456 = _i_69456 + 1LL;
            if ((object)((uintptr_t)_i_69456 +(uintptr_t) HIGH_BITS) >= 0){
                _i_69456 = NewDouble((eudouble)_i_69456);
            }
        }
        else {
            _i_69456 = binary_op_a(PLUS, _i_69456, 1LL);
        }
        DeRef(_0);
        goto L1; // [82] 62
L2: 
        ;
        DeRef(_i_69456);
    }

    /** execute.e:2984		target = Code[pc+n+2]*/
    _34592 = _67pc_65330 + _n_69446;
    if ((object)((uintptr_t)_34592 + (uintptr_t)HIGH_BITS) >= 0){
        _34592 = NewDouble((eudouble)_34592);
    }
    if (IS_ATOM_INT(_34592)) {
        _34593 = _34592 + 2LL;
    }
    else {
        _34593 = NewDouble(DBL_PTR(_34592)->dbl + (eudouble)2LL);
    }
    DeRef(_34592);
    _34592 = NOVALUE;
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!IS_ATOM_INT(_34593)){
        _67target_65335 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34593)->dbl));
    }
    else{
        _67target_65335 = (object)*(((s1_ptr)_2)->base + _34593);
    }
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2985		val[target] = x*/
    Ref(_x_69447);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _x_69447;
    DeRef(_1);

    /** execute.e:2986		pc += n+3*/
    _34595 = _n_69446 + 3LL;
    if ((object)((uintptr_t)_34595 + (uintptr_t)HIGH_BITS) >= 0){
        _34595 = NewDouble((eudouble)_34595);
    }
    if (IS_ATOM_INT(_34595)) {
        _67pc_65330 = _67pc_65330 + _34595;
    }
    else {
        _67pc_65330 = NewDouble((eudouble)_67pc_65330 + DBL_PTR(_34595)->dbl);
    }
    DeRef(_34595);
    _34595 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_65330)) {
        _1 = (object)(DBL_PTR(_67pc_65330)->dbl);
        DeRefDS(_67pc_65330);
        _67pc_65330 = _1;
    }

    /** execute.e:2987	end procedure*/
    DeRef(_x_69447);
    DeRef(_34581);
    _34581 = NOVALUE;
    DeRef(_34583);
    _34583 = NOVALUE;
    DeRef(_34588);
    _34588 = NOVALUE;
    _34589 = NOVALUE;
    DeRef(_34586);
    _34586 = NOVALUE;
    _34584 = NOVALUE;
    DeRef(_34593);
    _34593 = NOVALUE;
    return;
    ;
}


void _67opREPEAT()
{
    object _34615 = NOVALUE;
    object _34614 = NOVALUE;
    object _34613 = NOVALUE;
    object _34610 = NOVALUE;
    object _34607 = NOVALUE;
    object _34604 = NOVALUE;
    object _34603 = NOVALUE;
    object _34601 = NOVALUE;
    object _34599 = NOVALUE;
    object _34597 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2990		a = Code[pc+1]*/
    _34597 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34597);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:2991		b = Code[pc+2]*/
    _34599 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34599);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:2992		target = Code[pc+3]*/
    _34601 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34601);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:2993		if not atom(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34603 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _34604 = IS_ATOM(_34603);
    _34603 = NOVALUE;
    if (_34604 != 0)
    goto L1; // [62] 71
    _34604 = NOVALUE;

    /** execute.e:2994			RTFatal("repetition count must be an atom")*/
    RefDS(_34606);
    _67RTFatal(_34606);
L1: 

    /** execute.e:2996		if val[b] < 0 then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34607 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (binary_op_a(GREATEREQ, _34607, 0LL)){
        _34607 = NOVALUE;
        goto L2; // [81] 91
    }
    _34607 = NOVALUE;

    /** execute.e:2997			RTFatal("repetition count must not be negative")*/
    RefDS(_34609);
    _67RTFatal(_34609);
L2: 

    /** execute.e:2999		if val[b] > 1073741823 then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34610 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (binary_op_a(LESSEQ, _34610, 1073741823LL)){
        _34610 = NOVALUE;
        goto L3; // [101] 111
    }
    _34610 = NOVALUE;

    /** execute.e:3000			RTFatal("repetition count is too large")*/
    RefDS(_34612);
    _67RTFatal(_34612);
L3: 

    /** execute.e:3002		val[target] = repeat(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34613 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34614 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _34615 = Repeat(_34613, _34614);
    _34613 = NOVALUE;
    _34614 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34615;
    if( _1 != _34615 ){
        DeRef(_1);
    }
    _34615 = NOVALUE;

    /** execute.e:3003		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:3004	end procedure*/
    DeRef(_34597);
    _34597 = NOVALUE;
    DeRef(_34599);
    _34599 = NOVALUE;
    DeRef(_34601);
    _34601 = NOVALUE;
    return;
    ;
}


void _67opDATE()
{
    object _34619 = NOVALUE;
    object _34617 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3007		target = Code[pc+1]*/
    _34617 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34617);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3008		val[target] = date()*/
    _34619 = Date();
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34619;
    if( _1 != _34619 ){
        DeRef(_1);
    }
    _34619 = NOVALUE;

    /** execute.e:3009		pc += 2*/
    _67pc_65330 = _67pc_65330 + 2LL;

    /** execute.e:3010	end procedure*/
    _34617 = NOVALUE;
    return;
    ;
}


void _67opTIME()
{
    object _34623 = NOVALUE;
    object _34621 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3013		target = Code[pc+1]*/
    _34621 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34621);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3014		val[target] = time()*/
    _34623 = NewDouble(current_time());
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34623;
    if( _1 != _34623 ){
        DeRef(_1);
    }
    _34623 = NOVALUE;

    /** execute.e:3015		pc += 2*/
    _67pc_65330 = _67pc_65330 + 2LL;

    /** execute.e:3016	end procedure*/
    _34621 = NOVALUE;
    return;
    ;
}


void _67opSPACE_USED()
{
    object _0, _1, _2;
    

    /** execute.e:3019		pc += 2*/
    _67pc_65330 = _67pc_65330 + 2LL;

    /** execute.e:3020	end procedure*/
    return;
    ;
}


void _67opNOP2()
{
    object _0, _1, _2;
    

    /** execute.e:3024		pc+= 2*/
    _67pc_65330 = _67pc_65330 + 2LL;

    /** execute.e:3025	end procedure*/
    return;
    ;
}


void _67opPOSITION()
{
    object _34632 = NOVALUE;
    object _34631 = NOVALUE;
    object _34629 = NOVALUE;
    object _34627 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3028		a = Code[pc+1]*/
    _34627 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34627);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3029		b = Code[pc+2]*/
    _34629 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34629);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:3030		position(val[a], val[b])  -- error checks*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34631 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34632 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    Position(_34631, _34632);
    _34631 = NOVALUE;
    _34632 = NOVALUE;

    /** execute.e:3031		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:3032	end procedure*/
    _34627 = NOVALUE;
    _34629 = NOVALUE;
    return;
    ;
}


void _67opEQUAL()
{
    object _34642 = NOVALUE;
    object _34641 = NOVALUE;
    object _34640 = NOVALUE;
    object _34638 = NOVALUE;
    object _34636 = NOVALUE;
    object _34634 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3035		a = Code[pc+1]*/
    _34634 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34634);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3036		b = Code[pc+2]*/
    _34636 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34636);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:3037		target = Code[pc+3]*/
    _34638 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34638);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3038		val[target] = equal(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34640 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34641 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (_34640 == _34641)
    _34642 = 1;
    else if (IS_ATOM_INT(_34640) && IS_ATOM_INT(_34641))
    _34642 = 0;
    else
    _34642 = (compare(_34640, _34641) == 0);
    _34640 = NOVALUE;
    _34641 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34642;
    if( _1 != _34642 ){
        DeRef(_1);
    }
    _34642 = NOVALUE;

    /** execute.e:3039		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:3040	end procedure*/
    _34636 = NOVALUE;
    _34634 = NOVALUE;
    _34638 = NOVALUE;
    return;
    ;
}


void _67opHASH()
{
    object _34652 = NOVALUE;
    object _34651 = NOVALUE;
    object _34650 = NOVALUE;
    object _34648 = NOVALUE;
    object _34646 = NOVALUE;
    object _34644 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3043		a = Code[pc+1]*/
    _34644 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34644);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3044		b = Code[pc+2]*/
    _34646 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34646);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:3045		target = Code[pc+3]*/
    _34648 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34648);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3046		val[target] = hash(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34650 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34651 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _34652 = calc_hash(_34650, _34651);
    _34650 = NOVALUE;
    _34651 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34652;
    if( _1 != _34652 ){
        DeRef(_1);
    }
    _34652 = NOVALUE;

    /** execute.e:3047		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:3048	end procedure*/
    _34644 = NOVALUE;
    _34648 = NOVALUE;
    _34646 = NOVALUE;
    return;
    ;
}


void _67opCOMPARE()
{
    object _34662 = NOVALUE;
    object _34661 = NOVALUE;
    object _34660 = NOVALUE;
    object _34658 = NOVALUE;
    object _34656 = NOVALUE;
    object _34654 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3051		a = Code[pc+1]*/
    _34654 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34654);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3052		b = Code[pc+2]*/
    _34656 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34656);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:3053		target = Code[pc+3]*/
    _34658 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34658);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3054		val[target] = compare(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34660 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34661 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_ATOM_INT(_34660) && IS_ATOM_INT(_34661)){
        _34662 = (_34660 < _34661) ? -1 : (_34660 > _34661);
    }
    else{
        _34662 = compare(_34660, _34661);
    }
    _34660 = NOVALUE;
    _34661 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34662;
    if( _1 != _34662 ){
        DeRef(_1);
    }
    _34662 = NOVALUE;

    /** execute.e:3055		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:3056	end procedure*/
    _34654 = NOVALUE;
    _34656 = NOVALUE;
    _34658 = NOVALUE;
    return;
    ;
}


void _67opFIND()
{
    object _34676 = NOVALUE;
    object _34675 = NOVALUE;
    object _34674 = NOVALUE;
    object _34671 = NOVALUE;
    object _34670 = NOVALUE;
    object _34668 = NOVALUE;
    object _34666 = NOVALUE;
    object _34664 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3059		a = Code[pc+1]*/
    _34664 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34664);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3060		b = Code[pc+2]*/
    _34666 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34666);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:3061		target = Code[pc+3]*/
    _34668 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34668);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3062		if not sequence(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34670 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _34671 = IS_SEQUENCE(_34670);
    _34670 = NOVALUE;
    if (_34671 != 0)
    goto L1; // [62] 71
    _34671 = NOVALUE;

    /** execute.e:3063			RTFatal("second argument of find() must be a sequence")*/
    RefDS(_34673);
    _67RTFatal(_34673);
L1: 

    /** execute.e:3065		val[target] = find(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34674 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34675 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _34676 = find_from(_34674, _34675, 1LL);
    _34674 = NOVALUE;
    _34675 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34676;
    if( _1 != _34676 ){
        DeRef(_1);
    }
    _34676 = NOVALUE;

    /** execute.e:3066		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:3067	end procedure*/
    DeRef(_34666);
    _34666 = NOVALUE;
    DeRef(_34668);
    _34668 = NOVALUE;
    DeRef(_34664);
    _34664 = NOVALUE;
    return;
    ;
}


void _67opMATCH()
{
    object _34698 = NOVALUE;
    object _34697 = NOVALUE;
    object _34696 = NOVALUE;
    object _34693 = NOVALUE;
    object _34692 = NOVALUE;
    object _34689 = NOVALUE;
    object _34688 = NOVALUE;
    object _34685 = NOVALUE;
    object _34684 = NOVALUE;
    object _34682 = NOVALUE;
    object _34680 = NOVALUE;
    object _34678 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3070		a = Code[pc+1]*/
    _34678 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34678);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3071		b = Code[pc+2]*/
    _34680 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34680);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:3072		target = Code[pc+3]*/
    _34682 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34682);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3073		if not sequence(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34684 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _34685 = IS_SEQUENCE(_34684);
    _34684 = NOVALUE;
    if (_34685 != 0)
    goto L1; // [62] 71
    _34685 = NOVALUE;

    /** execute.e:3074			RTFatal("first argument of match() must be a sequence")*/
    RefDS(_34687);
    _67RTFatal(_34687);
L1: 

    /** execute.e:3076		if not sequence(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34688 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _34689 = IS_SEQUENCE(_34688);
    _34688 = NOVALUE;
    if (_34689 != 0)
    goto L2; // [84] 93
    _34689 = NOVALUE;

    /** execute.e:3077			RTFatal("second argument of match() must be a sequence")*/
    RefDS(_34691);
    _67RTFatal(_34691);
L2: 

    /** execute.e:3079		if length(val[a]) = 0 then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34692 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_SEQUENCE(_34692)){
            _34693 = SEQ_PTR(_34692)->length;
    }
    else {
        _34693 = 1;
    }
    _34692 = NOVALUE;
    if (_34693 != 0LL)
    goto L3; // [106] 116

    /** execute.e:3080			 RTFatal("first argument of match() must be a non-empty sequence")*/
    RefDS(_34695);
    _67RTFatal(_34695);
L3: 

    /** execute.e:3082		val[target] = match(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34696 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34697 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _34698 = e_match_from(_34696, _34697, 1LL);
    _34696 = NOVALUE;
    _34697 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34698;
    if( _1 != _34698 ){
        DeRef(_1);
    }
    _34698 = NOVALUE;

    /** execute.e:3083		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:3084	end procedure*/
    _34692 = NOVALUE;
    DeRef(_34682);
    _34682 = NOVALUE;
    DeRef(_34678);
    _34678 = NOVALUE;
    DeRef(_34680);
    _34680 = NOVALUE;
    return;
    ;
}


void _67opFIND_FROM()
{
    object _s_69626 = NOVALUE;
    object _34721 = NOVALUE;
    object _34719 = NOVALUE;
    object _34718 = NOVALUE;
    object _34717 = NOVALUE;
    object _34715 = NOVALUE;
    object _34714 = NOVALUE;
    object _34713 = NOVALUE;
    object _34712 = NOVALUE;
    object _34708 = NOVALUE;
    object _34707 = NOVALUE;
    object _34706 = NOVALUE;
    object _34705 = NOVALUE;
    object _34703 = NOVALUE;
    object _34701 = NOVALUE;
    object _34700 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3089			c = val[Code[pc+3]]*/
    _34700 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _34701 = (object)*(((s1_ptr)_2)->base + _34700);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!IS_ATOM_INT(_34701)){
        _67c_65333 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34701)->dbl));
    }
    else{
        _67c_65333 = (object)*(((s1_ptr)_2)->base + _34701);
    }
    if (!IS_ATOM_INT(_67c_65333))
    _67c_65333 = (object)DBL_PTR(_67c_65333)->dbl;

    /** execute.e:3090			target = Code[pc+4]*/
    _34703 = _67pc_65330 + 4LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34703);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3091			if not sequence(val[Code[pc+2]]) then*/
    _34705 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _34706 = (object)*(((s1_ptr)_2)->base + _34705);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!IS_ATOM_INT(_34706)){
        _34707 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34706)->dbl));
    }
    else{
        _34707 = (object)*(((s1_ptr)_2)->base + _34706);
    }
    _34708 = IS_SEQUENCE(_34707);
    _34707 = NOVALUE;
    if (_34708 != 0)
    goto L1; // [60] 82
    _34708 = NOVALUE;

    /** execute.e:3092					RTFatal("second argument of find_from() must be a sequence")*/
    RefDS(_34710);
    _67RTFatal(_34710);

    /** execute.e:3093					pc += 5*/
    _67pc_65330 = _67pc_65330 + 5LL;

    /** execute.e:3094					return*/
    DeRef(_s_69626);
    _34706 = NOVALUE;
    _34700 = NOVALUE;
    _34705 = NOVALUE;
    _34701 = NOVALUE;
    _34703 = NOVALUE;
    return;
L1: 

    /** execute.e:3096			s = val[Code[pc+2]][c..$]*/
    _34712 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _34713 = (object)*(((s1_ptr)_2)->base + _34712);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!IS_ATOM_INT(_34713)){
        _34714 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34713)->dbl));
    }
    else{
        _34714 = (object)*(((s1_ptr)_2)->base + _34713);
    }
    if (IS_SEQUENCE(_34714)){
            _34715 = SEQ_PTR(_34714)->length;
    }
    else {
        _34715 = 1;
    }
    rhs_slice_target = (object_ptr)&_s_69626;
    RHS_Slice(_34714, _67c_65333, _34715);
    _34714 = NOVALUE;

    /** execute.e:3097			b = find( val[Code[pc+1]], s )*/
    _34717 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _34718 = (object)*(((s1_ptr)_2)->base + _34717);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!IS_ATOM_INT(_34718)){
        _34719 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34718)->dbl));
    }
    else{
        _34719 = (object)*(((s1_ptr)_2)->base + _34718);
    }
    _67b_65332 = find_from(_34719, _s_69626, 1LL);
    _34719 = NOVALUE;

    /** execute.e:3098			if b then*/
    if (_67b_65332 == 0)
    {
        goto L2; // [141] 161
    }
    else{
    }

    /** execute.e:3099					b += c - 1*/
    _34721 = _67c_65333 - 1LL;
    if ((object)((uintptr_t)_34721 +(uintptr_t) HIGH_BITS) >= 0){
        _34721 = NewDouble((eudouble)_34721);
    }
    if (IS_ATOM_INT(_34721)) {
        _67b_65332 = _67b_65332 + _34721;
    }
    else {
        _67b_65332 = NewDouble((eudouble)_67b_65332 + DBL_PTR(_34721)->dbl);
    }
    DeRef(_34721);
    _34721 = NOVALUE;
    if (!IS_ATOM_INT(_67b_65332)) {
        _1 = (object)(DBL_PTR(_67b_65332)->dbl);
        DeRefDS(_67b_65332);
        _67b_65332 = _1;
    }
L2: 

    /** execute.e:3101			val[target] = b*/
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67b_65332;
    DeRef(_1);

    /** execute.e:3102			pc += 5*/
    _67pc_65330 = _67pc_65330 + 5LL;

    /** execute.e:3103	end procedure*/
    DeRef(_s_69626);
    _34706 = NOVALUE;
    DeRef(_34700);
    _34700 = NOVALUE;
    DeRef(_34717);
    _34717 = NOVALUE;
    DeRef(_34705);
    _34705 = NOVALUE;
    _34701 = NOVALUE;
    _34718 = NOVALUE;
    _34713 = NOVALUE;
    DeRef(_34703);
    _34703 = NOVALUE;
    DeRef(_34712);
    _34712 = NOVALUE;
    return;
    ;
}


void _67opMATCH_FROM()
{
    object _s_69660 = NOVALUE;
    object _34764 = NOVALUE;
    object _34763 = NOVALUE;
    object _34761 = NOVALUE;
    object _34760 = NOVALUE;
    object _34759 = NOVALUE;
    object _34758 = NOVALUE;
    object _34757 = NOVALUE;
    object _34756 = NOVALUE;
    object _34755 = NOVALUE;
    object _34754 = NOVALUE;
    object _34753 = NOVALUE;
    object _34752 = NOVALUE;
    object _34750 = NOVALUE;
    object _34744 = NOVALUE;
    object _34740 = NOVALUE;
    object _34739 = NOVALUE;
    object _34735 = NOVALUE;
    object _34734 = NOVALUE;
    object _34732 = NOVALUE;
    object _34730 = NOVALUE;
    object _34729 = NOVALUE;
    object _34727 = NOVALUE;
    object _34725 = NOVALUE;
    object _34724 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3108			c = val[Code[pc+3]]*/
    _34724 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _34725 = (object)*(((s1_ptr)_2)->base + _34724);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!IS_ATOM_INT(_34725)){
        _67c_65333 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34725)->dbl));
    }
    else{
        _67c_65333 = (object)*(((s1_ptr)_2)->base + _34725);
    }
    if (!IS_ATOM_INT(_67c_65333))
    _67c_65333 = (object)DBL_PTR(_67c_65333)->dbl;

    /** execute.e:3109			target = Code[pc+4]*/
    _34727 = _67pc_65330 + 4LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34727);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3110			s = val[Code[pc+2]]*/
    _34729 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _34730 = (object)*(((s1_ptr)_2)->base + _34729);
    DeRef(_s_69660);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!IS_ATOM_INT(_34730)){
        _s_69660 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34730)->dbl));
    }
    else{
        _s_69660 = (object)*(((s1_ptr)_2)->base + _34730);
    }
    Ref(_s_69660);

    /** execute.e:3111			a = Code[pc+1]*/
    _34732 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34732);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3112			if not sequence(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34734 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _34735 = IS_SEQUENCE(_34734);
    _34734 = NOVALUE;
    if (_34735 != 0)
    goto L1; // [86] 108
    _34735 = NOVALUE;

    /** execute.e:3113					RTFatal("first argument of match_from() must be a sequence")*/
    RefDS(_34737);
    _67RTFatal(_34737);

    /** execute.e:3114					pc += 5*/
    _67pc_65330 = _67pc_65330 + 5LL;

    /** execute.e:3115					return*/
    DeRef(_s_69660);
    _34732 = NOVALUE;
    _34724 = NOVALUE;
    _34729 = NOVALUE;
    _34727 = NOVALUE;
    _34725 = NOVALUE;
    _34730 = NOVALUE;
    return;
L1: 

    /** execute.e:3117			if length(val[a]) = 0 then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34739 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_SEQUENCE(_34739)){
            _34740 = SEQ_PTR(_34739)->length;
    }
    else {
        _34740 = 1;
    }
    _34739 = NOVALUE;
    if (_34740 != 0LL)
    goto L2; // [121] 144

    /** execute.e:3118					RTFatal("first argument of match_from() must be a non-empty sequence")*/
    RefDS(_34742);
    _67RTFatal(_34742);

    /** execute.e:3119					pc += 5*/
    _67pc_65330 = _67pc_65330 + 5LL;

    /** execute.e:3120					return*/
    DeRef(_s_69660);
    DeRef(_34732);
    _34732 = NOVALUE;
    DeRef(_34724);
    _34724 = NOVALUE;
    DeRef(_34729);
    _34729 = NOVALUE;
    DeRef(_34727);
    _34727 = NOVALUE;
    _34725 = NOVALUE;
    _34730 = NOVALUE;
    _34739 = NOVALUE;
    return;
L2: 

    /** execute.e:3122			if not sequence(s) then*/
    _34744 = IS_SEQUENCE(_s_69660);
    if (_34744 != 0)
    goto L3; // [149] 171
    _34744 = NOVALUE;

    /** execute.e:3123					RTFatal("second argument of match_from() must be a sequence")*/
    RefDS(_34746);
    _67RTFatal(_34746);

    /** execute.e:3124					pc += 5*/
    _67pc_65330 = _67pc_65330 + 5LL;

    /** execute.e:3125					return*/
    DeRef(_s_69660);
    DeRef(_34732);
    _34732 = NOVALUE;
    DeRef(_34724);
    _34724 = NOVALUE;
    DeRef(_34729);
    _34729 = NOVALUE;
    DeRef(_34727);
    _34727 = NOVALUE;
    _34725 = NOVALUE;
    _34730 = NOVALUE;
    _34739 = NOVALUE;
    return;
L3: 

    /** execute.e:3127			if c < 1 then*/
    if (_67c_65333 >= 1LL)
    goto L4; // [175] 204

    /** execute.e:3128					RTFatal(sprintf("index (%d) out of bounds in match_from()", c ))*/
    _34750 = EPrintf(-9999999, _34749, _67c_65333);
    _67RTFatal(_34750);
    _34750 = NOVALUE;

    /** execute.e:3129					pc += 5*/
    _67pc_65330 = _67pc_65330 + 5LL;

    /** execute.e:3130					return*/
    DeRef(_s_69660);
    DeRef(_34732);
    _34732 = NOVALUE;
    DeRef(_34724);
    _34724 = NOVALUE;
    DeRef(_34729);
    _34729 = NOVALUE;
    DeRef(_34727);
    _34727 = NOVALUE;
    _34725 = NOVALUE;
    _34730 = NOVALUE;
    _34739 = NOVALUE;
    return;
L4: 

    /** execute.e:3132			if not (length(s) = 0 and c = 1) and c > length(s) + 1 then*/
    if (IS_SEQUENCE(_s_69660)){
            _34752 = SEQ_PTR(_s_69660)->length;
    }
    else {
        _34752 = 1;
    }
    _34753 = (_34752 == 0LL);
    _34752 = NOVALUE;
    if (_34753 == 0) {
        DeRef(_34754);
        _34754 = 0;
        goto L5; // [213] 227
    }
    _34755 = (_67c_65333 == 1LL);
    _34754 = (_34755 != 0);
L5: 
    _34756 = (_34754 == 0);
    _34754 = NOVALUE;
    if (_34756 == 0) {
        goto L6; // [230] 276
    }
    if (IS_SEQUENCE(_s_69660)){
            _34758 = SEQ_PTR(_s_69660)->length;
    }
    else {
        _34758 = 1;
    }
    _34759 = _34758 + 1;
    _34758 = NOVALUE;
    _34760 = (_67c_65333 > _34759);
    _34759 = NOVALUE;
    if (_34760 == 0)
    {
        DeRef(_34760);
        _34760 = NOVALUE;
        goto L6; // [248] 276
    }
    else{
        DeRef(_34760);
        _34760 = NOVALUE;
    }

    /** execute.e:3133					RTFatal(sprintf("index (%d) out of bounds in match_from()", c ))*/
    _34761 = EPrintf(-9999999, _34749, _67c_65333);
    _67RTFatal(_34761);
    _34761 = NOVALUE;

    /** execute.e:3134					pc += 5*/
    _67pc_65330 = _67pc_65330 + 5LL;

    /** execute.e:3135					return*/
    DeRef(_s_69660);
    DeRef(_34732);
    _34732 = NOVALUE;
    DeRef(_34724);
    _34724 = NOVALUE;
    DeRef(_34755);
    _34755 = NOVALUE;
    DeRef(_34756);
    _34756 = NOVALUE;
    DeRef(_34729);
    _34729 = NOVALUE;
    DeRef(_34727);
    _34727 = NOVALUE;
    _34725 = NOVALUE;
    DeRef(_34753);
    _34753 = NOVALUE;
    _34730 = NOVALUE;
    _34739 = NOVALUE;
    return;
L6: 

    /** execute.e:3137			val[target] = match( val[a], s, c )*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34763 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _34764 = e_match_from(_34763, _s_69660, _67c_65333);
    _34763 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34764;
    if( _1 != _34764 ){
        DeRef(_1);
    }
    _34764 = NOVALUE;

    /** execute.e:3138			pc += 5*/
    _67pc_65330 = _67pc_65330 + 5LL;

    /** execute.e:3139	end procedure*/
    DeRef(_s_69660);
    DeRef(_34732);
    _34732 = NOVALUE;
    DeRef(_34724);
    _34724 = NOVALUE;
    DeRef(_34755);
    _34755 = NOVALUE;
    DeRef(_34756);
    _34756 = NOVALUE;
    DeRef(_34729);
    _34729 = NOVALUE;
    DeRef(_34727);
    _34727 = NOVALUE;
    _34725 = NOVALUE;
    DeRef(_34753);
    _34753 = NOVALUE;
    _34730 = NOVALUE;
    _34739 = NOVALUE;
    return;
    ;
}


void _67opPEEK2U()
{
    object _34771 = NOVALUE;
    object _34770 = NOVALUE;
    object _34768 = NOVALUE;
    object _34766 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3142		a = Code[pc+1]*/
    _34766 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34766);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3143		target = Code[pc+2]*/
    _34768 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34768);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3144		val[target] = peek2u(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34770 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_ATOM_INT(_34770)) {
        _34771 = *(uint16_t *)_34770;
    }
    else if (IS_ATOM(_34770)) {
        _34771 = *(uint16_t *)(uintptr_t)(DBL_PTR(_34770)->dbl);
    }
    else {
        _1 = (object)SEQ_PTR(_34770);
        peek2_addr = (uint16_t *)get_pos_int("peek2s/peek2u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _34771 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)*peek2_addr++;
        }
    }
    _34770 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34771;
    if( _1 != _34771 ){
        DeRef(_1);
    }
    _34771 = NOVALUE;

    /** execute.e:3145		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:3146	end procedure*/
    _34766 = NOVALUE;
    _34768 = NOVALUE;
    return;
    ;
}


void _67opPEEK2S()
{
    object _34778 = NOVALUE;
    object _34777 = NOVALUE;
    object _34775 = NOVALUE;
    object _34773 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3149		a = Code[pc+1]*/
    _34773 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34773);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3150		target = Code[pc+2]*/
    _34775 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34775);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3151		val[target] = peek2s(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34777 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_ATOM_INT(_34777)) {
        _34778 = *(int16_t *)_34777;
    }
    else if (IS_ATOM(_34777)) {
        _34778 = *(int16_t *)(uintptr_t)(DBL_PTR(_34777)->dbl);
    }
    else {
        _1 = (object)SEQ_PTR(_34777);
        peek2_addr = (uint16_t *)get_pos_int("peek2s/peek2u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _34778 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)(int16_t)*peek2_addr++;
        }
    }
    _34777 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34778;
    if( _1 != _34778 ){
        DeRef(_1);
    }
    _34778 = NOVALUE;

    /** execute.e:3152		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:3153	end procedure*/
    _34773 = NOVALUE;
    _34775 = NOVALUE;
    return;
    ;
}


void _67opPEEK4U()
{
    object _34785 = NOVALUE;
    object _34784 = NOVALUE;
    object _34782 = NOVALUE;
    object _34780 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3156		a = Code[pc+1]*/
    _34780 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34780);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3157		target = Code[pc+2]*/
    _34782 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34782);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3158		val[target] = peek4u(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34784 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_ATOM_INT(_34784)) {
        _34785 = (object)*(uint32_t *)_34784;
        if ((uintptr_t)_34785 > (uintptr_t)MAXINT){
            _34785 = NewDouble((eudouble)(uintptr_t)_34785);
        }
    }
    else if (IS_ATOM(_34784)) {
        _34785 = (object)*(uint32_t *)(uintptr_t)(DBL_PTR(_34784)->dbl);
        if ((uintptr_t)_34785 > (uintptr_t)MAXINT){
            _34785 = NewDouble((eudouble)(uintptr_t)_34785);
        }
    }
    else {
        _1 = (object)SEQ_PTR(_34784);
        peek4_addr = (uint32_t *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _34785 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            _1 = (object)*peek4_addr++;
            if ((uintptr_t)_1 > (uintptr_t)MAXINT){
                _1 = NewDouble((eudouble)(uintptr_t)_1);
            }
            *pokeptr_addr = _1;
        }
    }
    _34784 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34785;
    if( _1 != _34785 ){
        DeRef(_1);
    }
    _34785 = NOVALUE;

    /** execute.e:3159		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:3160	end procedure*/
    _34780 = NOVALUE;
    _34782 = NOVALUE;
    return;
    ;
}


void _67opPEEK4S()
{
    object _34792 = NOVALUE;
    object _34791 = NOVALUE;
    object _34789 = NOVALUE;
    object _34787 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3163		a = Code[pc+1]*/
    _34787 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34787);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3164		target = Code[pc+2]*/
    _34789 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34789);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3165		val[target] = peek4s(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34791 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_ATOM_INT(_34791)) {
        _34792 = (object)*(int32_t *)_34791;
        if (_34792 < MININT || _34792 > MAXINT){
            _34792 = NewDouble((eudouble)(object)_34792);
        }
    }
    else if (IS_ATOM(_34791)) {
        _34792 = (object)*(int32_t *)(uintptr_t)(DBL_PTR(_34791)->dbl);
        if (_34792 < MININT || _34792 > MAXINT){
            _34792 = NewDouble((eudouble)(object)_34792);
        }
    }
    else {
        _1 = (object)SEQ_PTR(_34791);
        peek4_addr = (uint32_t *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _34792 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            _1 = (object)(int32_t)*peek4_addr++;
            if (_1 < MININT || _1 > MAXINT){
                _1 = NewDouble((eudouble)_1);
            }
            *pokeptr_addr = _1;
        }
    }
    _34791 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34792;
    if( _1 != _34792 ){
        DeRef(_1);
    }
    _34792 = NOVALUE;

    /** execute.e:3166		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:3167	end procedure*/
    _34789 = NOVALUE;
    _34787 = NOVALUE;
    return;
    ;
}


void _67opPEEK8U()
{
    object _34799 = NOVALUE;
    object _34798 = NOVALUE;
    object _34796 = NOVALUE;
    object _34794 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3170		a = Code[pc+1]*/
    _34794 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34794);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3171		target = Code[pc+2]*/
    _34796 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34796);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3172		val[target] = peek8u(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34798 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    {
        int64_t peek8_longlong;
        if (IS_ATOM_INT(_34798)) {
            peek8_longlong = *(int64_t *)_34798;
            if (peek8_longlong > (uint64_t)MAXINT){
                _34799 = NewDouble((eudouble)(uint64_t)peek8_longlong);
            }
            else{
                _34799 = (object) peek8_longlong;
            }
        }
        else if (IS_ATOM(_34798)) {
            peek8_longlong = *(int64_t *)(uintptr_t)(DBL_PTR(_34798)->dbl);
            if (peek8_longlong > (uint64_t)MAXINT){
                _34799 = NewDouble((eudouble)(uint64_t)peek8_longlong);
            }
            else{
                _34799 = (object) peek8_longlong;
            }
        }
        else {
            _1 = (object)SEQ_PTR(_34798);
            peek8_addr = (uint64_t *)get_pos_int("peek8s/peek8u", *(((s1_ptr)_1)->base+1));
            _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
            pokeptr_addr = (uintptr_t *)NewS1(_2);
            _34799 = MAKE_SEQ(pokeptr_addr);
            pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
            while (--_2 >= 0) {
                pokeptr_addr++;
                peek8_longlong = *peek8_addr++;
                if ((uint64_t)peek8_longlong > (uint64_t)MAXINT){
                    _1 = NewDouble((eudouble) (uint64_t) peek8_longlong);
                }
                else{
                    _1 = (object)peek8_longlong;
                }
                *pokeptr_addr = _1;
            }
        }
    }
    _34798 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34799;
    if( _1 != _34799 ){
        DeRef(_1);
    }
    _34799 = NOVALUE;

    /** execute.e:3173		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:3174	end procedure*/
    _34794 = NOVALUE;
    _34796 = NOVALUE;
    return;
    ;
}


void _67opPEEK8S()
{
    object _34806 = NOVALUE;
    object _34805 = NOVALUE;
    object _34803 = NOVALUE;
    object _34801 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3177		a = Code[pc+1]*/
    _34801 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34801);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3178		target = Code[pc+2]*/
    _34803 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34803);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3179		val[target] = peek8s(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34805 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    {
        int64_t peek8_longlong;
        if (IS_ATOM_INT(_34805)) {
            peek8_longlong = *(int64_t *)_34805;
            if (peek8_longlong < (int64_t)MININT || peek8_longlong > (int64_t) MAXINT){
                _34806 = NewDouble((eudouble) peek8_longlong);
            }
            else{
                _34806 = (object) peek8_longlong;
            }
        }
        else if (IS_ATOM(_34805)) {
            peek8_longlong = *(int64_t *)(uintptr_t)(DBL_PTR(_34805)->dbl);
            if (peek8_longlong < (int64_t)MININT || peek8_longlong > (int64_t) MAXINT){
                _34806 = NewDouble((eudouble) peek8_longlong);
            }
            else{
                _34806 = (object) peek8_longlong;
            }
        }
        else {
            _1 = (object)SEQ_PTR(_34805);
            peek8_addr = (uint64_t *)get_pos_int("peek8s/peek8u", *(((s1_ptr)_1)->base+1));
            _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
            pokeptr_addr = (uintptr_t *)NewS1(_2);
            _34806 = MAKE_SEQ(pokeptr_addr);
            pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
            while (--_2 >= 0) {
                pokeptr_addr++;
                peek8_longlong = *peek8_addr++;
                if (peek8_longlong < (int64_t) MININT || peek8_longlong > (int64_t) MAXINT){
                    _1 = NewDouble((eudouble)peek8_longlong);
                }
                else{
                    _1 = (object)(int64_t) peek8_longlong;
                }
                *pokeptr_addr = _1;
            }
        }
    }
    _34805 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34806;
    if( _1 != _34806 ){
        DeRef(_1);
    }
    _34806 = NOVALUE;

    /** execute.e:3180		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:3181	end procedure*/
    _34801 = NOVALUE;
    _34803 = NOVALUE;
    return;
    ;
}


void _67opPEEK_STRING()
{
    object _34813 = NOVALUE;
    object _34812 = NOVALUE;
    object _34810 = NOVALUE;
    object _34808 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3183		a = Code[pc+1]*/
    _34808 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34808);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3184		target = Code[pc+2]*/
    _34810 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34810);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3185		val[target] = peek_string(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34812 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_ATOM_INT(_34812)) {
        _34813 =  NewString((char *)_34812);
    }
    else if (IS_ATOM(_34812)) {
        _34813 = NewString((char *)(uintptr_t)(DBL_PTR(_34812)->dbl));
    }
    else {
        _1 = (object)SEQ_PTR(_34812);
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _34813 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
        }
    }
    _34812 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34813;
    if( _1 != _34813 ){
        DeRef(_1);
    }
    _34813 = NOVALUE;

    /** execute.e:3186		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:3187	end procedure*/
    _34810 = NOVALUE;
    _34808 = NOVALUE;
    return;
    ;
}


void _67opPEEK()
{
    object _34820 = NOVALUE;
    object _34819 = NOVALUE;
    object _34817 = NOVALUE;
    object _34815 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3190		a = Code[pc+1]*/
    _34815 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34815);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3191		target = Code[pc+2]*/
    _34817 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34817);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3192		val[target] = peek(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34819 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_ATOM_INT(_34819)) {
        _34820 = *(uint8_t *)_34819;
    }
    else if (IS_ATOM(_34819)) {
        _34820 = *(uint8_t *)(uintptr_t)(DBL_PTR(_34819)->dbl);
    }
    else {
        _1 = (object)SEQ_PTR(_34819);
        peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _34820 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)*peek_addr++;
        }
    }
    _34819 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34820;
    if( _1 != _34820 ){
        DeRef(_1);
    }
    _34820 = NOVALUE;

    /** execute.e:3193		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:3194	end procedure*/
    _34817 = NOVALUE;
    _34815 = NOVALUE;
    return;
    ;
}


void _67opPEEKS()
{
    object _34827 = NOVALUE;
    object _34826 = NOVALUE;
    object _34824 = NOVALUE;
    object _34822 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3197		a = Code[pc+1]*/
    _34822 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34822);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3198		target = Code[pc+2]*/
    _34824 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34824);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3199		val[target] = peeks(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34826 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_ATOM_INT(_34826)) {
        _34827 = *(int8_t *)_34826;
    }
    else if (IS_ATOM(_34826)) {
        _34827 = *(int8_t *)(uintptr_t)(DBL_PTR(_34826)->dbl);
    }
    else {
        _1 = (object)SEQ_PTR(_34826);
        peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _34827 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)(int8_t)*peek_addr++;
        }
    }
    _34826 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34827;
    if( _1 != _34827 ){
        DeRef(_1);
    }
    _34827 = NOVALUE;

    /** execute.e:3200		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:3201	end procedure*/
    _34822 = NOVALUE;
    _34824 = NOVALUE;
    return;
    ;
}


void _67opSIZEOF()
{
    object _34834 = NOVALUE;
    object _34833 = NOVALUE;
    object _34831 = NOVALUE;
    object _34829 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3204		a = Code[pc+1]*/
    _34829 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34829);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3205		b = Code[pc+2]*/
    _34831 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34831);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:3206		val[b] = sizeof( val[a] )*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34833 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _34834 = eu_sizeof( _34833 );
    _34833 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67b_65332);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34834;
    if( _1 != _34834 ){
        DeRef(_1);
    }
    _34834 = NOVALUE;

    /** execute.e:3207		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:3208	end procedure*/
    _34829 = NOVALUE;
    _34831 = NOVALUE;
    return;
    ;
}


void _67opPOKE()
{
    object _34841 = NOVALUE;
    object _34840 = NOVALUE;
    object _34838 = NOVALUE;
    object _34836 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3211		a = Code[pc+1]*/
    _34836 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34836);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3212		b = Code[pc+2]*/
    _34838 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34838);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:3213		poke(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34840 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34841 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_ATOM_INT(_34840)){
        poke_addr = (uint8_t *)_34840;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_34840)->dbl);
    }
    if (IS_ATOM_INT(_34841)) {
        *poke_addr = (uint8_t)_34841;
    }
    else if (IS_ATOM(_34841)) {
        *poke_addr = (uint8_t)DBL_PTR(_34841)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_34841);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke_addr++ = (uint8_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    _34840 = NOVALUE;
    _34841 = NOVALUE;

    /** execute.e:3214		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:3215	end procedure*/
    _34836 = NOVALUE;
    _34838 = NOVALUE;
    return;
    ;
}


void _67opPOKE4()
{
    object _34848 = NOVALUE;
    object _34847 = NOVALUE;
    object _34845 = NOVALUE;
    object _34843 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3218		a = Code[pc+1]*/
    _34843 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34843);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3219		b = Code[pc+2]*/
    _34845 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34845);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:3220		poke4(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34847 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34848 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_ATOM_INT(_34847)){
        poke4_addr = (uint32_t *)_34847;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_34847)->dbl);
    }
    if (IS_ATOM_INT(_34848)) {
        *poke4_addr = (uint32_t)_34848;
    }
    else if (IS_ATOM(_34848)) {
        *poke4_addr = (uint32_t)DBL_PTR(_34848)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_34848);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke4_addr++ = (int32_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *(object *)poke4_addr++ = (uint32_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    _34847 = NOVALUE;
    _34848 = NOVALUE;

    /** execute.e:3221		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:3222	end procedure*/
    _34845 = NOVALUE;
    _34843 = NOVALUE;
    return;
    ;
}


void _67opPOKE8()
{
    object _34855 = NOVALUE;
    object _34854 = NOVALUE;
    object _34852 = NOVALUE;
    object _34850 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3225		a = Code[pc+1]*/
    _34850 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34850);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3226		b = Code[pc+2]*/
    _34852 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34852);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:3227		poke8(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34854 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34855 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_ATOM_INT(_34854)){
        poke8_addr = (uint64_t *)_34854;
    }
    else {
        poke8_addr = (uint64_t *)(uintptr_t)(DBL_PTR(_34854)->dbl);
    }
    if (IS_ATOM_INT(_34855)) {
        *poke8_addr = (uint64_t)_34855;
    }
    else if (IS_ATOM(_34855)) {
        *poke8_addr = (uint64_t)DBL_PTR(_34855)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_34855);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke8_addr++ = (uint64_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *poke8_addr++ = (uint64_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    _34854 = NOVALUE;
    _34855 = NOVALUE;

    /** execute.e:3228		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:3229	end procedure*/
    _34852 = NOVALUE;
    _34850 = NOVALUE;
    return;
    ;
}


void _67opPOKE2()
{
    object _34862 = NOVALUE;
    object _34861 = NOVALUE;
    object _34859 = NOVALUE;
    object _34857 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3232		a = Code[pc+1]*/
    _34857 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34857);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3233		b = Code[pc+2]*/
    _34859 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34859);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:3234		poke2(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34861 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34862 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_ATOM_INT(_34861)){
        poke2_addr = (uint16_t *)_34861;
    }
    else {
        poke2_addr = (uint16_t *)(uintptr_t)(DBL_PTR(_34861)->dbl);
    }
    if (IS_ATOM_INT(_34862)) {
        *poke2_addr = (uint16_t)_34862;
    }
    else if (IS_ATOM(_34862)) {
        *poke2_addr = (uint16_t)DBL_PTR(_34862)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_34862);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke2_addr++ = (uint16_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *poke2_addr++ = (uint16_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    _34861 = NOVALUE;
    _34862 = NOVALUE;

    /** execute.e:3235		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:3236	end procedure*/
    _34857 = NOVALUE;
    _34859 = NOVALUE;
    return;
    ;
}


void _67opMEM_COPY()
{
    object _34872 = NOVALUE;
    object _34871 = NOVALUE;
    object _34870 = NOVALUE;
    object _34868 = NOVALUE;
    object _34866 = NOVALUE;
    object _34864 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3240		a = Code[pc+1]*/
    _34864 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34864);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3241		b = Code[pc+2]*/
    _34866 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34866);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:3242		c = Code[pc+3]*/
    _34868 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65333 = (object)*(((s1_ptr)_2)->base + _34868);
    if (!IS_ATOM_INT(_67c_65333)){
        _67c_65333 = (object)DBL_PTR(_67c_65333)->dbl;
    }

    /** execute.e:3243		mem_copy(val[a], val[b], val[c])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34870 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34871 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34872 = (object)*(((s1_ptr)_2)->base + _67c_65333);
    memory_copy(_34870, _34871, _34872);
    _34870 = NOVALUE;
    _34871 = NOVALUE;
    _34872 = NOVALUE;

    /** execute.e:3244		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:3245	end procedure*/
    _34866 = NOVALUE;
    _34864 = NOVALUE;
    _34868 = NOVALUE;
    return;
    ;
}


void _67opMEM_SET()
{
    object _34882 = NOVALUE;
    object _34881 = NOVALUE;
    object _34880 = NOVALUE;
    object _34878 = NOVALUE;
    object _34876 = NOVALUE;
    object _34874 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3248		a = Code[pc+1]*/
    _34874 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34874);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3249		b = Code[pc+2]*/
    _34876 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34876);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:3250		c = Code[pc+3]*/
    _34878 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65333 = (object)*(((s1_ptr)_2)->base + _34878);
    if (!IS_ATOM_INT(_67c_65333)){
        _67c_65333 = (object)DBL_PTR(_67c_65333)->dbl;
    }

    /** execute.e:3251		mem_set(val[a], val[b], val[c])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34880 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34881 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34882 = (object)*(((s1_ptr)_2)->base + _67c_65333);
    memory_set(_34880, _34881, _34882);
    _34880 = NOVALUE;
    _34881 = NOVALUE;
    _34882 = NOVALUE;

    /** execute.e:3252		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:3253	end procedure*/
    _34874 = NOVALUE;
    _34878 = NOVALUE;
    _34876 = NOVALUE;
    return;
    ;
}


void _67opCALL()
{
    object _34886 = NOVALUE;
    object _34884 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3256		a = Code[pc+1]*/
    _34884 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34884);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3257		call(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34886 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_ATOM_INT(_34886))
    _0 = (object)_34886;
    else
    _0 = (object)(uintptr_t)(DBL_PTR(_34886)->dbl);
    (*(void(*)())_0)();
    _34886 = NOVALUE;

    /** execute.e:3258		pc += 2*/
    _67pc_65330 = _67pc_65330 + 2LL;

    /** execute.e:3259	end procedure*/
    _34884 = NOVALUE;
    return;
    ;
}


void _67opSYSTEM()
{
    object _34899 = NOVALUE;
    object _34898 = NOVALUE;
    object _34896 = NOVALUE;
    object _34895 = NOVALUE;
    object _34893 = NOVALUE;
    object _34892 = NOVALUE;
    object _34890 = NOVALUE;
    object _34888 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3262		a = Code[pc+1]*/
    _34888 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34888);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3263		b = Code[pc+2]*/
    _34890 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34890);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:3264		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34892 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _34893 = IS_ATOM(_34892);
    _34892 = NOVALUE;
    if (_34893 == 0)
    {
        _34893 = NOVALUE;
        goto L1; // [46] 55
    }
    else{
        _34893 = NOVALUE;
    }

    /** execute.e:3265			RTFatal("first argument of system() must be a sequence")*/
    RefDS(_34894);
    _67RTFatal(_34894);
L1: 

    /** execute.e:3267		if sequence(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34895 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _34896 = IS_SEQUENCE(_34895);
    _34895 = NOVALUE;
    if (_34896 == 0)
    {
        _34896 = NOVALUE;
        goto L2; // [68] 77
    }
    else{
        _34896 = NOVALUE;
    }

    /** execute.e:3268			RTFatal("second argument of system() must be an atom")*/
    RefDS(_34897);
    _67RTFatal(_34897);
L2: 

    /** execute.e:3270		system(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34898 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34899 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    system_call(_34898, _34899);
    _34898 = NOVALUE;
    _34899 = NOVALUE;

    /** execute.e:3271		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:3272	end procedure*/
    DeRef(_34890);
    _34890 = NOVALUE;
    DeRef(_34888);
    _34888 = NOVALUE;
    return;
    ;
}


void _67opSYSTEM_EXEC()
{
    object _34913 = NOVALUE;
    object _34912 = NOVALUE;
    object _34911 = NOVALUE;
    object _34910 = NOVALUE;
    object _34909 = NOVALUE;
    object _34908 = NOVALUE;
    object _34907 = NOVALUE;
    object _34905 = NOVALUE;
    object _34903 = NOVALUE;
    object _34901 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3275		a = Code[pc+1]*/
    _34901 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34901);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3276		b = Code[pc+2]*/
    _34903 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34903);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:3277		target = Code[pc+3]*/
    _34905 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34905);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3278		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34907 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _34908 = IS_ATOM(_34907);
    _34907 = NOVALUE;
    if (_34908 == 0)
    {
        _34908 = NOVALUE;
        goto L1; // [62] 71
    }
    else{
        _34908 = NOVALUE;
    }

    /** execute.e:3279			RTFatal("first argument of system() must be a sequence")*/
    RefDS(_34894);
    _67RTFatal(_34894);
L1: 

    /** execute.e:3281		if sequence(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34909 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _34910 = IS_SEQUENCE(_34909);
    _34909 = NOVALUE;
    if (_34910 == 0)
    {
        _34910 = NOVALUE;
        goto L2; // [84] 93
    }
    else{
        _34910 = NOVALUE;
    }

    /** execute.e:3282			RTFatal("second argument of system() must be an atom")*/
    RefDS(_34897);
    _67RTFatal(_34897);
L2: 

    /** execute.e:3284		val[target] = system_exec(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34911 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34912 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _34913 = system_exec_call(_34911, _34912);
    _34911 = NOVALUE;
    _34912 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34913;
    if( _1 != _34913 ){
        DeRef(_1);
    }
    _34913 = NOVALUE;

    /** execute.e:3285		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:3286	end procedure*/
    DeRef(_34903);
    _34903 = NOVALUE;
    DeRef(_34901);
    _34901 = NOVALUE;
    DeRef(_34905);
    _34905 = NOVALUE;
    return;
    ;
}


void _67opOPEN()
{
    object _34940 = NOVALUE;
    object _34939 = NOVALUE;
    object _34938 = NOVALUE;
    object _34937 = NOVALUE;
    object _34934 = NOVALUE;
    object _34933 = NOVALUE;
    object _34931 = NOVALUE;
    object _34930 = NOVALUE;
    object _34928 = NOVALUE;
    object _34927 = NOVALUE;
    object _34926 = NOVALUE;
    object _34924 = NOVALUE;
    object _34923 = NOVALUE;
    object _34921 = NOVALUE;
    object _34919 = NOVALUE;
    object _34917 = NOVALUE;
    object _34915 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3291		a = Code[pc+1]*/
    _34915 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34915);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3292		b = Code[pc+2]*/
    _34917 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34917);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:3293		c = Code[pc+3]*/
    _34919 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65333 = (object)*(((s1_ptr)_2)->base + _34919);
    if (!IS_ATOM_INT(_67c_65333)){
        _67c_65333 = (object)DBL_PTR(_67c_65333)->dbl;
    }

    /** execute.e:3294		target = Code[pc+4]*/
    _34921 = _67pc_65330 + 4LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34921);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3296		if atom(val[b]) or length(val[b]) > 2 then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34923 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _34924 = IS_ATOM(_34923);
    _34923 = NOVALUE;
    if (_34924 != 0) {
        goto L1; // [78] 102
    }
    _2 = (object)SEQ_PTR(_67val_65340);
    _34926 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    if (IS_SEQUENCE(_34926)){
            _34927 = SEQ_PTR(_34926)->length;
    }
    else {
        _34927 = 1;
    }
    _34926 = NOVALUE;
    _34928 = (_34927 > 2LL);
    _34927 = NOVALUE;
    if (_34928 == 0)
    {
        DeRef(_34928);
        _34928 = NOVALUE;
        goto L2; // [98] 108
    }
    else{
        DeRef(_34928);
        _34928 = NOVALUE;
    }
L1: 

    /** execute.e:3297		   RTFatal("invalid open mode")*/
    RefDS(_34929);
    _67RTFatal(_34929);
L2: 

    /** execute.e:3299		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34930 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _34931 = IS_ATOM(_34930);
    _34930 = NOVALUE;
    if (_34931 == 0)
    {
        _34931 = NOVALUE;
        goto L3; // [121] 130
    }
    else{
        _34931 = NOVALUE;
    }

    /** execute.e:3300		   RTFatal("device or file name must be a sequence")*/
    RefDS(_34932);
    _67RTFatal(_34932);
L3: 

    /** execute.e:3302		if not atom(val[c]) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34933 = (object)*(((s1_ptr)_2)->base + _67c_65333);
    _34934 = IS_ATOM(_34933);
    _34933 = NOVALUE;
    if (_34934 != 0)
    goto L4; // [143] 152
    _34934 = NOVALUE;

    /** execute.e:3303			RTFatal("cleanup must be an atom")*/
    RefDS(_34936);
    _67RTFatal(_34936);
L4: 

    /** execute.e:3305		val[target] = open(val[a], val[b], val[c])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34937 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34938 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34939 = (object)*(((s1_ptr)_2)->base + _67c_65333);
    _34940 = EOpen(_34937, _34938, _34939);
    _34937 = NOVALUE;
    _34938 = NOVALUE;
    _34939 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34940;
    if( _1 != _34940 ){
        DeRef(_1);
    }
    _34940 = NOVALUE;

    /** execute.e:3306		pc += 5*/
    _67pc_65330 = _67pc_65330 + 5LL;

    /** execute.e:3307	end procedure*/
    _34926 = NOVALUE;
    DeRef(_34921);
    _34921 = NOVALUE;
    DeRef(_34917);
    _34917 = NOVALUE;
    DeRef(_34915);
    _34915 = NOVALUE;
    DeRef(_34919);
    _34919 = NOVALUE;
    return;
    ;
}


void _67opCLOSE()
{
    object _34944 = NOVALUE;
    object _34942 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3310		a = Code[pc+1]*/
    _34942 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34942);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3311		close(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34944 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (IS_ATOM_INT(_34944))
    EClose(_34944);
    else
    EClose((object)DBL_PTR(_34944)->dbl);
    _34944 = NOVALUE;

    /** execute.e:3312		pc += 2*/
    _67pc_65330 = _67pc_65330 + 2LL;

    /** execute.e:3313	end procedure*/
    _34942 = NOVALUE;
    return;
    ;
}


void _67opABORT()
{
    object _34948 = NOVALUE;
    object _34947 = NOVALUE;
    object _34946 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3316		Cleanup(val[Code[pc+1]])*/
    _34946 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _34947 = (object)*(((s1_ptr)_2)->base + _34946);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!IS_ATOM_INT(_34947)){
        _34948 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34947)->dbl));
    }
    else{
        _34948 = (object)*(((s1_ptr)_2)->base + _34947);
    }
    Ref(_34948);
    _49Cleanup(_34948);
    _34948 = NOVALUE;

    /** execute.e:3317	end procedure*/
    _34947 = NOVALUE;
    _34946 = NOVALUE;
    return;
    ;
}


void _67opGETC()
{
    object _34954 = NOVALUE;
    object _34953 = NOVALUE;
    object _34951 = NOVALUE;
    object _34949 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3320		a = Code[pc+1]*/
    _34949 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34949);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3321		target = Code[pc+2]*/
    _34951 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34951);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3322		val[target] = getc(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34953 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (_34953 != last_r_file_no) {
        last_r_file_ptr = which_file(_34953, EF_READ);
        if (IS_ATOM_INT(_34953)){
            last_r_file_no = _34953;
        }
        else{
            last_r_file_no = NOVALUE;
        }
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _34954 = getKBchar();
        }
        else{
            _34954 = getc(last_r_file_ptr);
        }
    }
    else{
        _34954 = getc(last_r_file_ptr);
    }
    _34953 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34954;
    if( _1 != _34954 ){
        DeRef(_1);
    }
    _34954 = NOVALUE;

    /** execute.e:3323		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:3324	end procedure*/
    _34951 = NOVALUE;
    _34949 = NOVALUE;
    return;
    ;
}


void _67opGETS()
{
    object _34961 = NOVALUE;
    object _34960 = NOVALUE;
    object _34958 = NOVALUE;
    object _34956 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3328		a = Code[pc+1]*/
    _34956 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34956);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3329		target = Code[pc+2]*/
    _34958 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34958);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3330		val[target] = gets(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34960 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _34961 = EGets(_34960);
    _34960 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34961;
    if( _1 != _34961 ){
        DeRef(_1);
    }
    _34961 = NOVALUE;

    /** execute.e:3331		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:3332	end procedure*/
    _34956 = NOVALUE;
    _34958 = NOVALUE;
    return;
    ;
}


void _67opGET_KEY()
{
    object _34965 = NOVALUE;
    object _34963 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3337		target = Code[pc+1]*/
    _34963 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _34963);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3338		val[target] = get_key()*/
    show_console();
    _34965 = get_key(0);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34965;
    if( _1 != _34965 ){
        DeRef(_1);
    }
    _34965 = NOVALUE;

    /** execute.e:3339		pc += 2*/
    _67pc_65330 = _67pc_65330 + 2LL;

    /** execute.e:3340	end procedure*/
    _34963 = NOVALUE;
    return;
    ;
}


void _67opCLEAR_SCREEN()
{
    object _0, _1, _2;
    

    /** execute.e:3343		clear_screen()*/
    ClearScreen();

    /** execute.e:3344		pc += 1*/
    _67pc_65330 = _67pc_65330 + 1;

    /** execute.e:3345	end procedure*/
    return;
    ;
}


void _67opPUTS()
{
    object _34973 = NOVALUE;
    object _34972 = NOVALUE;
    object _34970 = NOVALUE;
    object _34968 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3348		a = Code[pc+1]*/
    _34968 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34968);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3349		b = Code[pc+2]*/
    _34970 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34970);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:3350		puts(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34972 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34973 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    EPuts(_34972, _34973); // DJP 
    _34972 = NOVALUE;
    _34973 = NOVALUE;

    /** execute.e:3351		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:3352	end procedure*/
    _34968 = NOVALUE;
    _34970 = NOVALUE;
    return;
    ;
}


void _67opQPRINT()
{
    object _34977 = NOVALUE;
    object _34975 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3356		a = Code[pc+2]*/
    _34975 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34975);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3357		? val[a]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34977 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    StdPrint(1LL, _34977, 1);
    _34977 = NOVALUE;

    /** execute.e:3358		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:3359	end procedure*/
    _34975 = NOVALUE;
    return;
    ;
}


void _67opPRINT()
{
    object _34984 = NOVALUE;
    object _34983 = NOVALUE;
    object _34981 = NOVALUE;
    object _34979 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3362		a = Code[pc+1]*/
    _34979 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34979);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3363		b = Code[pc+2]*/
    _34981 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34981);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:3364		print(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34983 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34984 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    StdPrint(_34983, _34984, 0);
    _34983 = NOVALUE;
    _34984 = NOVALUE;

    /** execute.e:3365		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:3366	end procedure*/
    _34979 = NOVALUE;
    _34981 = NOVALUE;
    return;
    ;
}


void _67opPRINTF()
{
    object _34994 = NOVALUE;
    object _34993 = NOVALUE;
    object _34992 = NOVALUE;
    object _34990 = NOVALUE;
    object _34988 = NOVALUE;
    object _34986 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3370		a = Code[pc+1]*/
    _34986 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34986);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3371		b = Code[pc+2]*/
    _34988 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34988);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:3372		c = Code[pc+3]*/
    _34990 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65333 = (object)*(((s1_ptr)_2)->base + _34990);
    if (!IS_ATOM_INT(_67c_65333)){
        _67c_65333 = (object)DBL_PTR(_67c_65333)->dbl;
    }

    /** execute.e:3373		printf(val[a], val[b], val[c])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _34992 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34993 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _2 = (object)SEQ_PTR(_67val_65340);
    _34994 = (object)*(((s1_ptr)_2)->base + _67c_65333);
    EPrintf(_34992, _34993, _34994);
    _34992 = NOVALUE;
    _34993 = NOVALUE;
    _34994 = NOVALUE;

    /** execute.e:3374		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:3375	end procedure*/
    _34990 = NOVALUE;
    _34988 = NOVALUE;
    _34986 = NOVALUE;
    return;
    ;
}


void _67opSPRINTF()
{
    object _35004 = NOVALUE;
    object _35003 = NOVALUE;
    object _35002 = NOVALUE;
    object _35000 = NOVALUE;
    object _34998 = NOVALUE;
    object _34996 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3378		a = Code[pc+1]*/
    _34996 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _34996);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3379		b = Code[pc+2]*/
    _34998 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _34998);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:3380		target = Code[pc+3]*/
    _35000 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _35000);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3381		val[target] = sprintf(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _35002 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _35003 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _35004 = EPrintf(-9999999, _35002, _35003);
    _35002 = NOVALUE;
    _35003 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35004;
    if( _1 != _35004 ){
        DeRef(_1);
    }
    _35004 = NOVALUE;

    /** execute.e:3382		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:3383	end procedure*/
    _34998 = NOVALUE;
    _35000 = NOVALUE;
    _34996 = NOVALUE;
    return;
    ;
}


void _67opCOMMAND_LINE()
{
    object _cmd_70086 = NOVALUE;
    object _35014 = NOVALUE;
    object _35013 = NOVALUE;
    object _35012 = NOVALUE;
    object _35011 = NOVALUE;
    object _35009 = NOVALUE;
    object _35006 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3388		target = Code[pc+1]*/
    _35006 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _35006);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3389		cmd = command_line()*/
    DeRef(_cmd_70086);
    _cmd_70086 = Command_Line();

    /** execute.e:3391		if length(cmd) > 2 then*/
    if (IS_SEQUENCE(_cmd_70086)){
            _35009 = SEQ_PTR(_cmd_70086)->length;
    }
    else {
        _35009 = 1;
    }
    if (_35009 <= 2LL)
    goto L1; // [26] 53

    /** execute.e:3392			cmd = {cmd[1]} & cmd[3..$]*/
    _2 = (object)SEQ_PTR(_cmd_70086);
    _35011 = (object)*(((s1_ptr)_2)->base + 1LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_35011);
    ((intptr_t*)_2)[1] = _35011;
    _35012 = MAKE_SEQ(_1);
    _35011 = NOVALUE;
    if (IS_SEQUENCE(_cmd_70086)){
            _35013 = SEQ_PTR(_cmd_70086)->length;
    }
    else {
        _35013 = 1;
    }
    rhs_slice_target = (object_ptr)&_35014;
    RHS_Slice(_cmd_70086, 3LL, _35013);
    Concat((object_ptr)&_cmd_70086, _35012, _35014);
    DeRefDS(_35012);
    _35012 = NOVALUE;
    DeRef(_35012);
    _35012 = NOVALUE;
    DeRefDS(_35014);
    _35014 = NOVALUE;
L1: 

    /** execute.e:3394		val[target] = cmd*/
    RefDS(_cmd_70086);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _cmd_70086;
    DeRef(_1);

    /** execute.e:3395		pc += 2*/
    _67pc_65330 = _67pc_65330 + 2LL;

    /** execute.e:3396	end procedure*/
    DeRefDS(_cmd_70086);
    DeRef(_35006);
    _35006 = NOVALUE;
    return;
    ;
}


void _67opOPTION_SWITCHES()
{
    object _cmd_70102 = NOVALUE;
    object _35017 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3401		target = Code[pc+1]*/
    _35017 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _35017);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3402		cmd = option_switches()*/
    DeRef(_cmd_70102);
    RefDS(_0switches);
    _cmd_70102 = _0switches;

    /** execute.e:3403		val[target] = cmd*/
    RefDS(_cmd_70102);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _cmd_70102;
    DeRef(_1);

    /** execute.e:3404		pc += 2*/
    _67pc_65330 = _67pc_65330 + 2LL;

    /** execute.e:3405	end procedure*/
    DeRefDS(_cmd_70102);
    _35017 = NOVALUE;
    return;
    ;
}


void _67opGETENV()
{
    object _35029 = NOVALUE;
    object _35028 = NOVALUE;
    object _35026 = NOVALUE;
    object _35025 = NOVALUE;
    object _35023 = NOVALUE;
    object _35021 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3408		a = Code[pc+1]*/
    _35021 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _35021);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3409		target = Code[pc+2]*/
    _35023 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _35023);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3410		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _35025 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _35026 = IS_ATOM(_35025);
    _35025 = NOVALUE;
    if (_35026 == 0)
    {
        _35026 = NOVALUE;
        goto L1; // [46] 55
    }
    else{
        _35026 = NOVALUE;
    }

    /** execute.e:3411			RTFatal("argument to getenv must be a sequence")*/
    RefDS(_35027);
    _67RTFatal(_35027);
L1: 

    /** execute.e:3413		val[target] = getenv(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _35028 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _35029 = EGetEnv(_35028);
    _35028 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35029;
    if( _1 != _35029 ){
        DeRef(_1);
    }
    _35029 = NOVALUE;

    /** execute.e:3414		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:3415	end procedure*/
    DeRef(_35023);
    _35023 = NOVALUE;
    DeRef(_35021);
    _35021 = NOVALUE;
    return;
    ;
}


void _67opC_PROC()
{
    object _sub_70126 = NOVALUE;
    object _35038 = NOVALUE;
    object _35037 = NOVALUE;
    object _35035 = NOVALUE;
    object _35033 = NOVALUE;
    object _35031 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3420		a = Code[pc+1]*/
    _35031 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _35031);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3421		b = Code[pc+2]*/
    _35033 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _35033);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:3422		sub = Code[pc+3]*/
    _35035 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _sub_70126 = (object)*(((s1_ptr)_2)->base + _35035);
    if (!IS_ATOM_INT(_sub_70126)){
        _sub_70126 = (object)DBL_PTR(_sub_70126)->dbl;
    }

    /** execute.e:3423		c_proc(val[a], val[b])  -- callback could happen here*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _35037 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _35038 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    call_c(0, _35037, _35038);
    _35037 = NOVALUE;
    _35038 = NOVALUE;

    /** execute.e:3424		restore_privates(sub)*/
    _67restore_privates(_sub_70126);

    /** execute.e:3425		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:3426	end procedure*/
    _35031 = NOVALUE;
    _35035 = NOVALUE;
    _35033 = NOVALUE;
    return;
    ;
}


void _67opC_FUNC()
{
    object _target_70141 = NOVALUE;
    object _sub_70143 = NOVALUE;
    object _temp_70144 = NOVALUE;
    object _35049 = NOVALUE;
    object _35048 = NOVALUE;
    object _35046 = NOVALUE;
    object _35044 = NOVALUE;
    object _35042 = NOVALUE;
    object _35040 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3431		object temp*/

    /** execute.e:3433		a = Code[pc+1]*/
    _35040 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _35040);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3434		b = Code[pc+2]*/
    _35042 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _35042);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:3435		sub = Code[pc+3]*/
    _35044 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _sub_70143 = (object)*(((s1_ptr)_2)->base + _35044);
    if (!IS_ATOM_INT(_sub_70143)){
        _sub_70143 = (object)DBL_PTR(_sub_70143)->dbl;
    }

    /** execute.e:3436		target = Code[pc+4]*/
    _35046 = _67pc_65330 + 4LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _target_70141 = (object)*(((s1_ptr)_2)->base + _35046);
    if (!IS_ATOM_INT(_target_70141)){
        _target_70141 = (object)DBL_PTR(_target_70141)->dbl;
    }

    /** execute.e:3437		temp = c_func(val[a], val[b])  -- callback could happen here*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _35048 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _35049 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    DeRef(_temp_70144);
    _temp_70144 = call_c(1, _35048, _35049);
    _35048 = NOVALUE;
    _35049 = NOVALUE;

    /** execute.e:3438		restore_privates(sub)*/
    _67restore_privates(_sub_70143);

    /** execute.e:3439		val[target] = temp*/
    Ref(_temp_70144);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _target_70141);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _temp_70144;
    DeRef(_1);

    /** execute.e:3440		pc += 5*/
    _67pc_65330 = _67pc_65330 + 5LL;

    /** execute.e:3441	end procedure*/
    DeRef(_temp_70144);
    _35040 = NOVALUE;
    _35042 = NOVALUE;
    _35044 = NOVALUE;
    _35046 = NOVALUE;
    return;
    ;
}


void _67opTRACE()
{
    object _35053 = NOVALUE;
    object _35052 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3444		TraceOn = val[Code[pc+1]]*/
    _35052 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _35053 = (object)*(((s1_ptr)_2)->base + _35052);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!IS_ATOM_INT(_35053)){
        _67TraceOn_65328 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_35053)->dbl));
    }
    else{
        _67TraceOn_65328 = (object)*(((s1_ptr)_2)->base + _35053);
    }
    if (!IS_ATOM_INT(_67TraceOn_65328))
    _67TraceOn_65328 = (object)DBL_PTR(_67TraceOn_65328)->dbl;

    /** execute.e:3445		pc += 2  -- turn on/off tracing*/
    _67pc_65330 = _67pc_65330 + 2LL;

    /** execute.e:3446	end procedure*/
    _35052 = NOVALUE;
    _35053 = NOVALUE;
    return;
    ;
}


void _67opPROFILE()
{
    object _0, _1, _2;
    

    /** execute.e:3452		pc += 2*/
    _67pc_65330 = _67pc_65330 + 2LL;

    /** execute.e:3453	end procedure*/
    return;
    ;
}


void _67opUPDATE_GLOBALS()
{
    object _0, _1, _2;
    

    /** execute.e:3458		pc += 1*/
    _67pc_65330 = _67pc_65330 + 1;

    /** execute.e:3459	end procedure*/
    return;
    ;
}


object _67general_callback(object _rtn_def_70176, object _args_70177)
{
    object _arglist_assign_70179 = NOVALUE;
    object _35075 = NOVALUE;
    object _35073 = NOVALUE;
    object _35072 = NOVALUE;
    object _35071 = NOVALUE;
    object _35068 = NOVALUE;
    object _35067 = NOVALUE;
    object _35065 = NOVALUE;
    object _35064 = NOVALUE;
    object _35060 = NOVALUE;
    object _35058 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:3493		val[t_id] = rtn_def[C_USER_ROUTINE]*/
    _2 = (object)SEQ_PTR(_rtn_def_70176);
    _35058 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_35058);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_id_65261);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35058;
    if( _1 != _35058 ){
        DeRef(_1);
    }
    _35058 = NOVALUE;

    /** execute.e:3494		val[t_arglist] = args*/
    RefDS(_args_70177);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_arglist_65262);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _args_70177;
    DeRef(_1);

    /** execute.e:3495		atom arglist_assign = new_arg_assign()*/
    _0 = _arglist_assign_70179;
    _arglist_assign_70179 = _67new_arg_assign();
    DeRef(_0);

    /** execute.e:3497		SymTab[call_back_routine][S_RESIDENT_TASK] = current_task*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67call_back_routine_65264 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67current_task_65347;
    DeRef(_1);
    _35060 = NOVALUE;

    /** execute.e:3500		call_stack = append(call_stack, pc)*/
    Append(&_67call_stack_65348, _67call_stack_65348, _67pc_65330);

    /** execute.e:3501		call_stack = append(call_stack, call_back_routine)*/
    Append(&_67call_stack_65348, _67call_stack_65348, _67call_back_routine_65264);

    /** execute.e:3503		Code = call_back_code*/
    RefDS(_67call_back_code_65258);
    DeRef(_27Code_20660);
    _27Code_20660 = _67call_back_code_65258;

    /** execute.e:3504		pc = 1*/
    _67pc_65330 = 1LL;

    /** execute.e:3506		do_exec()*/
    _67do_exec();

    /** execute.e:3509		pc = call_stack[$-1]*/
    if (IS_SEQUENCE(_67call_stack_65348)){
            _35064 = SEQ_PTR(_67call_stack_65348)->length;
    }
    else {
        _35064 = 1;
    }
    _35065 = _35064 - 1LL;
    _35064 = NOVALUE;
    _2 = (object)SEQ_PTR(_67call_stack_65348);
    _67pc_65330 = (object)*(((s1_ptr)_2)->base + _35065);
    if (!IS_ATOM_INT(_67pc_65330))
    _67pc_65330 = (object)DBL_PTR(_67pc_65330)->dbl;

    /** execute.e:3510		call_stack = call_stack[1..$-2]*/
    if (IS_SEQUENCE(_67call_stack_65348)){
            _35067 = SEQ_PTR(_67call_stack_65348)->length;
    }
    else {
        _35067 = 1;
    }
    _35068 = _35067 - 2LL;
    _35067 = NOVALUE;
    rhs_slice_target = (object_ptr)&_67call_stack_65348;
    RHS_Slice(_67call_stack_65348, 1LL, _35068);

    /** execute.e:3512		if arglist_assign = arg_assign then*/
    if (binary_op_a(NOTEQ, _arglist_assign_70179, _67arg_assign_65274)){
        goto L1; // [126] 143
    }

    /** execute.e:3513			val[t_arglist] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_arglist_65262);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
L1: 

    /** execute.e:3516		Code = SymTab[call_stack[$]][S_CODE]*/
    if (IS_SEQUENCE(_67call_stack_65348)){
            _35071 = SEQ_PTR(_67call_stack_65348)->length;
    }
    else {
        _35071 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_65348);
    _35072 = (object)*(((s1_ptr)_2)->base + _35071);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_35072)){
        _35073 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_35072)->dbl));
    }
    else{
        _35073 = (object)*(((s1_ptr)_2)->base + _35072);
    }
    DeRef(_27Code_20660);
    _2 = (object)SEQ_PTR(_35073);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    Ref(_27Code_20660);
    _35073 = NOVALUE;

    /** execute.e:3518		return val[t_return_val]*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _35075 = (object)*(((s1_ptr)_2)->base + _67t_return_val_65263);
    Ref(_35075);
    DeRefDS(_rtn_def_70176);
    DeRefDS(_args_70177);
    DeRef(_arglist_assign_70179);
    DeRef(_35065);
    _35065 = NOVALUE;
    _35072 = NOVALUE;
    DeRef(_35068);
    _35068 = NOVALUE;
    return _35075;
    ;
}


object _67machine_callback(object _cbx_70210, object _ptr_70211)
{
    object _rtn_def_70212 = NOVALUE;
    object _args_70213 = NOVALUE;
    object _35083 = NOVALUE;
    object _35081 = NOVALUE;
    object _35080 = NOVALUE;
    object _35079 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3528		rtn_def = call_backs[cbx]*/
    DeRef(_rtn_def_70212);
    _2 = (object)SEQ_PTR(_67call_backs_65257);
    if (!IS_ATOM_INT(_cbx_70210)){
        _rtn_def_70212 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_cbx_70210)->dbl));
    }
    else{
        _rtn_def_70212 = (object)*(((s1_ptr)_2)->base + _cbx_70210);
    }
    RefDS(_rtn_def_70212);

    /** execute.e:3529		args = peek4u(ptr & call_backs[cbx][C_NUM_ARGS])*/
    _2 = (object)SEQ_PTR(_67call_backs_65257);
    if (!IS_ATOM_INT(_cbx_70210)){
        _35079 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_cbx_70210)->dbl));
    }
    else{
        _35079 = (object)*(((s1_ptr)_2)->base + _cbx_70210);
    }
    _2 = (object)SEQ_PTR(_35079);
    _35080 = (object)*(((s1_ptr)_2)->base + 3LL);
    _35079 = NOVALUE;
    if (IS_SEQUENCE(_ptr_70211) && IS_ATOM(_35080)) {
    }
    else if (IS_ATOM(_ptr_70211) && IS_SEQUENCE(_35080)) {
        Ref(_ptr_70211);
        Prepend(&_35081, _35080, _ptr_70211);
    }
    else {
        Concat((object_ptr)&_35081, _ptr_70211, _35080);
    }
    _35080 = NOVALUE;
    DeRef(_args_70213);
    _1 = (object)SEQ_PTR(_35081);
    peek4_addr = (uint32_t *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _args_70213 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        _1 = (object)*peek4_addr++;
        if ((uintptr_t)_1 > (uintptr_t)MAXINT){
            _1 = NewDouble((eudouble)(uintptr_t)_1);
        }
        *pokeptr_addr = _1;
    }
    DeRefDS(_35081);
    _35081 = NOVALUE;

    /** execute.e:3531		return general_callback(rtn_def, args)*/
    RefDS(_rtn_def_70212);
    RefDS(_args_70213);
    _35083 = _67general_callback(_rtn_def_70212, _args_70213);
    DeRef(_cbx_70210);
    DeRef(_ptr_70211);
    DeRefDS(_rtn_def_70212);
    DeRefDS(_args_70213);
    return _35083;
    ;
}


object _67callback(object _a_70240)
{
    object _35099 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3626		return machine_func(M_CALL_BACK, a)*/
    _35099 = machine(52LL, _a_70240);
    DeRefi(_a_70240);
    return _35099;
    ;
}


void _67do_callback(object _b_70244)
{
    object _r_70246 = NOVALUE;
    object _asm_70247 = NOVALUE;
    object _id_70248 = NOVALUE;
    object _convention_70249 = NOVALUE;
    object _x_70250 = NOVALUE;
    object _35161 = NOVALUE;
    object _35160 = NOVALUE;
    object _35159 = NOVALUE;
    object _35158 = NOVALUE;
    object _35157 = NOVALUE;
    object _35156 = NOVALUE;
    object _35155 = NOVALUE;
    object _35154 = NOVALUE;
    object _35152 = NOVALUE;
    object _35151 = NOVALUE;
    object _35150 = NOVALUE;
    object _35149 = NOVALUE;
    object _35147 = NOVALUE;
    object _35128 = NOVALUE;
    object _35127 = NOVALUE;
    object _35125 = NOVALUE;
    object _35124 = NOVALUE;
    object _35123 = NOVALUE;
    object _35122 = NOVALUE;
    object _35121 = NOVALUE;
    object _35120 = NOVALUE;
    object _35119 = NOVALUE;
    object _35118 = NOVALUE;
    object _35117 = NOVALUE;
    object _35116 = NOVALUE;
    object _35114 = NOVALUE;
    object _35113 = NOVALUE;
    object _35112 = NOVALUE;
    object _35111 = NOVALUE;
    object _35109 = NOVALUE;
    object _35107 = NOVALUE;
    object _35106 = NOVALUE;
    object _35104 = NOVALUE;
    object _35101 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3631		atom asm*/

    /** execute.e:3632		integer id, convention*/

    /** execute.e:3633		object x*/

    /** execute.e:3636		x = val[b]*/
    DeRef(_x_70250);
    _2 = (object)SEQ_PTR(_67val_65340);
    _x_70250 = (object)*(((s1_ptr)_2)->base + _b_70244);
    Ref(_x_70250);

    /** execute.e:3637		if atom(x) then*/
    _35101 = IS_ATOM(_x_70250);
    if (_35101 == 0)
    {
        _35101 = NOVALUE;
        goto L1; // [22] 40
    }
    else{
        _35101 = NOVALUE;
    }

    /** execute.e:3638			id = x*/
    Ref(_x_70250);
    _id_70248 = _x_70250;
    if (!IS_ATOM_INT(_id_70248)) {
        _1 = (object)(DBL_PTR(_id_70248)->dbl);
        DeRefDS(_id_70248);
        _id_70248 = _1;
    }

    /** execute.e:3639			convention = 0*/
    _convention_70249 = 0LL;
    goto L2; // [37] 57
L1: 

    /** execute.e:3641			id = x[2]*/
    _2 = (object)SEQ_PTR(_x_70250);
    _id_70248 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_id_70248)){
        _id_70248 = (object)DBL_PTR(_id_70248)->dbl;
    }

    /** execute.e:3642			convention = x[1]*/
    _2 = (object)SEQ_PTR(_x_70250);
    _convention_70249 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_convention_70249)){
        _convention_70249 = (object)DBL_PTR(_convention_70249)->dbl;
    }
L2: 

    /** execute.e:3645		if id < 0 or id >= length(e_routine) then*/
    _35104 = (_id_70248 < 0LL);
    if (_35104 != 0) {
        goto L3; // [65] 83
    }
    if (IS_SEQUENCE(_67e_routine_65379)){
            _35106 = SEQ_PTR(_67e_routine_65379)->length;
    }
    else {
        _35106 = 1;
    }
    _35107 = (_id_70248 >= _35106);
    _35106 = NOVALUE;
    if (_35107 == 0)
    {
        DeRef(_35107);
        _35107 = NOVALUE;
        goto L4; // [79] 89
    }
    else{
        DeRef(_35107);
        _35107 = NOVALUE;
    }
L3: 

    /** execute.e:3646			RTFatal("Invalid routine id")*/
    RefDS(_35108);
    _67RTFatal(_35108);
L4: 

    /** execute.e:3649		r = e_routine[id+1]*/
    _35109 = _id_70248 + 1;
    _2 = (object)SEQ_PTR(_67e_routine_65379);
    _r_70246 = (object)*(((s1_ptr)_2)->base + _35109);

    /** execute.e:3651		if platform() = WIN32 and convention = 0 then*/
    _35111 = (2LL == 2LL);
    if (_35111 == 0) {
        goto L5; // [111] 224
    }
    _35113 = (_convention_70249 == 0LL);
    if (_35113 == 0)
    {
        DeRef(_35113);
        _35113 = NOVALUE;
        goto L5; // [122] 224
    }
    else{
        DeRef(_35113);
        _35113 = NOVALUE;
    }

    /** execute.e:3653			asm = dep:allocate_protect(length(cb_std), 1, PAGE_EXECUTE_READWRITE)*/
    _35114 = 24;
    _0 = _asm_70247;
    _asm_70247 = _6allocate_protect(24LL, 1LL, 64LL);
    DeRef(_0);
    _35114 = NOVALUE;

    /** execute.e:3654			poke( asm, cb_std )*/
    if (IS_ATOM_INT(_asm_70247)){
        poke_addr = (uint8_t *)_asm_70247;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_asm_70247)->dbl);
    }
    _1 = (object)SEQ_PTR(_67cb_std_70220);
    _1 = (object)((s1_ptr)_1)->base;
    while (1) {
        _1 += sizeof(object);
        _2 = *((object *)_1);
        if (IS_ATOM_INT(_2)) {
            *poke_addr++ = (uint8_t)_2;
        }
        else if (_2 == NOVALUE) {
            break;
        }
        else {
            *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
        }
    }

    /** execute.e:3655			poke4( asm + 7, length(call_backs) + 1 )*/
    if (IS_ATOM_INT(_asm_70247)) {
        _35116 = _asm_70247 + 7LL;
        if ((object)((uintptr_t)_35116 + (uintptr_t)HIGH_BITS) >= 0){
            _35116 = NewDouble((eudouble)_35116);
        }
    }
    else {
        _35116 = NewDouble(DBL_PTR(_asm_70247)->dbl + (eudouble)7LL);
    }
    if (IS_SEQUENCE(_67call_backs_65257)){
            _35117 = SEQ_PTR(_67call_backs_65257)->length;
    }
    else {
        _35117 = 1;
    }
    _35118 = _35117 + 1;
    _35117 = NOVALUE;
    if (IS_ATOM_INT(_35116)){
        poke4_addr = (uint32_t *)_35116;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_35116)->dbl);
    }
    *poke4_addr = (uint32_t)_35118;
    DeRef(_35116);
    _35116 = NOVALUE;
    _35118 = NOVALUE;

    /** execute.e:3656			poke4( asm + 13, asm + 20 )*/
    if (IS_ATOM_INT(_asm_70247)) {
        _35119 = _asm_70247 + 13LL;
        if ((object)((uintptr_t)_35119 + (uintptr_t)HIGH_BITS) >= 0){
            _35119 = NewDouble((eudouble)_35119);
        }
    }
    else {
        _35119 = NewDouble(DBL_PTR(_asm_70247)->dbl + (eudouble)13LL);
    }
    if (IS_ATOM_INT(_asm_70247)) {
        _35120 = _asm_70247 + 20LL;
        if ((object)((uintptr_t)_35120 + (uintptr_t)HIGH_BITS) >= 0){
            _35120 = NewDouble((eudouble)_35120);
        }
    }
    else {
        _35120 = NewDouble(DBL_PTR(_asm_70247)->dbl + (eudouble)20LL);
    }
    if (IS_ATOM_INT(_35119)){
        poke4_addr = (uint32_t *)_35119;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_35119)->dbl);
    }
    if (IS_ATOM_INT(_35120)) {
        *poke4_addr = (uint32_t)_35120;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_35120)->dbl;
    }
    DeRef(_35119);
    _35119 = NOVALUE;
    DeRef(_35120);
    _35120 = NOVALUE;

    /** execute.e:3657			poke( asm + 18, SymTab[r][S_NUM_ARGS] * 4 )*/
    if (IS_ATOM_INT(_asm_70247)) {
        _35121 = _asm_70247 + 18LL;
        if ((object)((uintptr_t)_35121 + (uintptr_t)HIGH_BITS) >= 0){
            _35121 = NewDouble((eudouble)_35121);
        }
    }
    else {
        _35121 = NewDouble(DBL_PTR(_asm_70247)->dbl + (eudouble)18LL);
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _35122 = (object)*(((s1_ptr)_2)->base + _r_70246);
    _2 = (object)SEQ_PTR(_35122);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _35123 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _35123 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _35122 = NOVALUE;
    if (IS_ATOM_INT(_35123)) {
        {
            int128_t p128 = (int128_t)_35123 * (int128_t)4LL;
            if( p128 != (int128_t)(_35124 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _35124 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _35124 = binary_op(MULTIPLY, _35123, 4LL);
    }
    _35123 = NOVALUE;
    if (IS_ATOM_INT(_35121)){
        poke_addr = (uint8_t *)_35121;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_35121)->dbl);
    }
    if (IS_ATOM_INT(_35124)) {
        *poke_addr = (uint8_t)_35124;
    }
    else if (IS_ATOM(_35124)) {
        *poke_addr = (uint8_t)DBL_PTR(_35124)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_35124);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke_addr++ = (uint8_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_35121);
    _35121 = NOVALUE;
    DeRef(_35124);
    _35124 = NOVALUE;

    /** execute.e:3658			poke4( asm + 20, callback( routine_id("machine_callback") ) )*/
    if (IS_ATOM_INT(_asm_70247)) {
        _35125 = _asm_70247 + 20LL;
        if ((object)((uintptr_t)_35125 + (uintptr_t)HIGH_BITS) >= 0){
            _35125 = NewDouble((eudouble)_35125);
        }
    }
    else {
        _35125 = NewDouble(DBL_PTR(_asm_70247)->dbl + (eudouble)20LL);
    }
    _35127 = CRoutineId(1600, 67, _35126);
    _35128 = _67callback(_35127);
    _35127 = NOVALUE;
    if (IS_ATOM_INT(_35125)){
        poke4_addr = (uint32_t *)_35125;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_35125)->dbl);
    }
    if (IS_ATOM_INT(_35128)) {
        *poke4_addr = (uint32_t)_35128;
    }
    else if (IS_ATOM(_35128)) {
        *poke4_addr = (uint32_t)DBL_PTR(_35128)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_35128);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke4_addr++ = (int32_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *(object *)poke4_addr++ = (uint32_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_35125);
    _35125 = NOVALUE;
    DeRef(_35128);
    _35128 = NOVALUE;
    goto L6; // [221] 409
L5: 

    /** execute.e:3659		elsif platform() = OSX then*/

    /** execute.e:3675			asm = dep:allocate_protect(length(cb_cdecl), 1, PAGE_EXECUTE_READWRITE)*/
    _35147 = 27;
    _0 = _asm_70247;
    _asm_70247 = _6allocate_protect(27LL, 1LL, 64LL);
    DeRef(_0);
    _35147 = NOVALUE;

    /** execute.e:3676			poke( asm, cb_cdecl )*/
    if (IS_ATOM_INT(_asm_70247)){
        poke_addr = (uint8_t *)_asm_70247;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_asm_70247)->dbl);
    }
    _1 = (object)SEQ_PTR(_67cb_cdecl_70225);
    _1 = (object)((s1_ptr)_1)->base;
    while (1) {
        _1 += sizeof(object);
        _2 = *((object *)_1);
        if (IS_ATOM_INT(_2)) {
            *poke_addr++ = (uint8_t)_2;
        }
        else if (_2 == NOVALUE) {
            break;
        }
        else {
            *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
        }
    }

    /** execute.e:3677			poke4( asm + 7, length(call_backs) + 1 )*/
    if (IS_ATOM_INT(_asm_70247)) {
        _35149 = _asm_70247 + 7LL;
        if ((object)((uintptr_t)_35149 + (uintptr_t)HIGH_BITS) >= 0){
            _35149 = NewDouble((eudouble)_35149);
        }
    }
    else {
        _35149 = NewDouble(DBL_PTR(_asm_70247)->dbl + (eudouble)7LL);
    }
    if (IS_SEQUENCE(_67call_backs_65257)){
            _35150 = SEQ_PTR(_67call_backs_65257)->length;
    }
    else {
        _35150 = 1;
    }
    _35151 = _35150 + 1;
    _35150 = NOVALUE;
    if (IS_ATOM_INT(_35149)){
        poke4_addr = (uint32_t *)_35149;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_35149)->dbl);
    }
    *poke4_addr = (uint32_t)_35151;
    DeRef(_35149);
    _35149 = NOVALUE;
    _35151 = NOVALUE;

    /** execute.e:3678			poke4( asm + 13, asm + 23 )*/
    if (IS_ATOM_INT(_asm_70247)) {
        _35152 = _asm_70247 + 13LL;
        if ((object)((uintptr_t)_35152 + (uintptr_t)HIGH_BITS) >= 0){
            _35152 = NewDouble((eudouble)_35152);
        }
    }
    else {
        _35152 = NewDouble(DBL_PTR(_asm_70247)->dbl + (eudouble)13LL);
    }
    if (IS_ATOM_INT(_asm_70247)) {
        _35154 = _asm_70247 + 23LL;
        if ((object)((uintptr_t)_35154 + (uintptr_t)HIGH_BITS) >= 0){
            _35154 = NewDouble((eudouble)_35154);
        }
    }
    else {
        _35154 = NewDouble(DBL_PTR(_asm_70247)->dbl + (eudouble)23LL);
    }
    if (IS_ATOM_INT(_35152)){
        poke4_addr = (uint32_t *)_35152;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_35152)->dbl);
    }
    if (IS_ATOM_INT(_35154)) {
        *poke4_addr = (uint32_t)_35154;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_35154)->dbl;
    }
    DeRef(_35152);
    _35152 = NOVALUE;
    DeRef(_35154);
    _35154 = NOVALUE;

    /** execute.e:3679			poke4( asm + 23, callback( ( '+' & routine_id("machine_callback") ) ) )*/
    if (IS_ATOM_INT(_asm_70247)) {
        _35155 = _asm_70247 + 23LL;
        if ((object)((uintptr_t)_35155 + (uintptr_t)HIGH_BITS) >= 0){
            _35155 = NewDouble((eudouble)_35155);
        }
    }
    else {
        _35155 = NewDouble(DBL_PTR(_asm_70247)->dbl + (eudouble)23LL);
    }
    _35156 = CRoutineId(1600, 67, _35126);
    Concat((object_ptr)&_35157, 43LL, _35156);
    _35156 = NOVALUE;
    _35158 = _67callback(_35157);
    _35157 = NOVALUE;
    if (IS_ATOM_INT(_35155)){
        poke4_addr = (uint32_t *)_35155;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_35155)->dbl);
    }
    if (IS_ATOM_INT(_35158)) {
        *poke4_addr = (uint32_t)_35158;
    }
    else if (IS_ATOM(_35158)) {
        *poke4_addr = (uint32_t)DBL_PTR(_35158)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_35158);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke4_addr++ = (int32_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *(object *)poke4_addr++ = (uint32_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_35155);
    _35155 = NOVALUE;
    DeRef(_35158);
    _35158 = NOVALUE;
L6: 

    /** execute.e:3682		val[target] = asm*/
    Ref(_asm_70247);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _asm_70247;
    DeRef(_1);

    /** execute.e:3683		call_backs = append( call_backs, { r, id, SymTab[r][S_NUM_ARGS] })*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _35159 = (object)*(((s1_ptr)_2)->base + _r_70246);
    _2 = (object)SEQ_PTR(_35159);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _35160 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _35160 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _35159 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _r_70246;
    ((intptr_t*)_2)[2] = _id_70248;
    Ref(_35160);
    ((intptr_t*)_2)[3] = _35160;
    _35161 = MAKE_SEQ(_1);
    _35160 = NOVALUE;
    RefDS(_35161);
    Append(&_67call_backs_65257, _67call_backs_65257, _35161);
    DeRefDS(_35161);
    _35161 = NOVALUE;

    /** execute.e:3684	end procedure*/
    DeRef(_asm_70247);
    DeRef(_x_70250);
    DeRef(_35109);
    _35109 = NOVALUE;
    DeRef(_35104);
    _35104 = NOVALUE;
    DeRef(_35111);
    _35111 = NOVALUE;
    return;
    ;
}


void _67do_crash_routine(object _b_70333)
{
    object _x_70334 = NOVALUE;
    object _35169 = NOVALUE;
    object _35168 = NOVALUE;
    object _35167 = NOVALUE;
    object _35166 = NOVALUE;
    object _35165 = NOVALUE;
    object _35164 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3690		x = val[b]*/
    DeRef(_x_70334);
    _2 = (object)SEQ_PTR(_67val_65340);
    _x_70334 = (object)*(((s1_ptr)_2)->base + _b_70333);
    Ref(_x_70334);

    /** execute.e:3691		if atom(x) and x >= 0 and x < length(e_routine) then*/
    _35164 = IS_ATOM(_x_70334);
    if (_35164 == 0) {
        _35165 = 0;
        goto L1; // [16] 28
    }
    if (IS_ATOM_INT(_x_70334)) {
        _35166 = (_x_70334 >= 0LL);
    }
    else {
        _35166 = binary_op(GREATEREQ, _x_70334, 0LL);
    }
    if (IS_ATOM_INT(_35166))
    _35165 = (_35166 != 0);
    else
    _35165 = DBL_PTR(_35166)->dbl != 0.0;
L1: 
    if (_35165 == 0) {
        goto L2; // [28] 56
    }
    if (IS_SEQUENCE(_67e_routine_65379)){
            _35168 = SEQ_PTR(_67e_routine_65379)->length;
    }
    else {
        _35168 = 1;
    }
    if (IS_ATOM_INT(_x_70334)) {
        _35169 = (_x_70334 < _35168);
    }
    else {
        _35169 = binary_op(LESS, _x_70334, _35168);
    }
    _35168 = NOVALUE;
    if (_35169 == 0) {
        DeRef(_35169);
        _35169 = NOVALUE;
        goto L2; // [42] 56
    }
    else {
        if (!IS_ATOM_INT(_35169) && DBL_PTR(_35169)->dbl == 0.0){
            DeRef(_35169);
            _35169 = NOVALUE;
            goto L2; // [42] 56
        }
        DeRef(_35169);
        _35169 = NOVALUE;
    }
    DeRef(_35169);
    _35169 = NOVALUE;

    /** execute.e:3692			crash_list = append(crash_list, x)*/
    Ref(_x_70334);
    Append(&_67crash_list_65266, _67crash_list_65266, _x_70334);
    goto L3; // [53] 62
L2: 

    /** execute.e:3694			RTFatal("crash routine requires a valid routine id")*/
    RefDS(_35171);
    _67RTFatal(_35171);
L3: 

    /** execute.e:3696	end procedure*/
    DeRef(_x_70334);
    DeRef(_35166);
    _35166 = NOVALUE;
    return;
    ;
}


void _67opREMOVE()
{
    object _35183 = NOVALUE;
    object _35182 = NOVALUE;
    object _35181 = NOVALUE;
    object _35180 = NOVALUE;
    object _35178 = NOVALUE;
    object _35176 = NOVALUE;
    object _35174 = NOVALUE;
    object _35172 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3699	 	a = Code[pc+1]*/
    _35172 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _35172);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3700	 	b = Code[pc+2]*/
    _35174 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _35174);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:3701	 	c = Code[pc+3]*/
    _35176 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65333 = (object)*(((s1_ptr)_2)->base + _35176);
    if (!IS_ATOM_INT(_67c_65333)){
        _67c_65333 = (object)DBL_PTR(_67c_65333)->dbl;
    }

    /** execute.e:3702	 	target = Code[pc+4]*/
    _35178 = _67pc_65330 + 4LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _35178);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3703	 	val[target] = remove(val[a],val[b],val[c])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _35180 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _35181 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _2 = (object)SEQ_PTR(_67val_65340);
    _35182 = (object)*(((s1_ptr)_2)->base + _67c_65333);
    {
        s1_ptr assign_space = SEQ_PTR(_35180);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_35181)) ? _35181 : (object)(DBL_PTR(_35181)->dbl);
        int stop = (IS_ATOM_INT(_35182)) ? _35182 : (object)(DBL_PTR(_35182)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
            RefDS(_35180);
            DeRef(_35183);
            _35183 = _35180;
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_35180), start, &_35183 );
            }
            else Tail(SEQ_PTR(_35180), stop+1, &_35183);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_35180), start, &_35183);
        }
        else {
            assign_slice_seq = &assign_space;
            _1 = Remove_elements(start, stop, 0);
            DeRef(_35183);
            _35183 = _1;
        }
    }
    _35180 = NOVALUE;
    _35181 = NOVALUE;
    _35182 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35183;
    if( _1 != _35183 ){
        DeRef(_1);
    }
    _35183 = NOVALUE;

    /** execute.e:3704	 	pc += 5*/
    _67pc_65330 = _67pc_65330 + 5LL;

    /** execute.e:3705	end procedure*/
    _35172 = NOVALUE;
    _35174 = NOVALUE;
    _35176 = NOVALUE;
    _35178 = NOVALUE;
    return;
    ;
}


void _67opREPLACE()
{
    object _35199 = NOVALUE;
    object _35198 = NOVALUE;
    object _35197 = NOVALUE;
    object _35196 = NOVALUE;
    object _35195 = NOVALUE;
    object _35193 = NOVALUE;
    object _35191 = NOVALUE;
    object _35189 = NOVALUE;
    object _35187 = NOVALUE;
    object _35185 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3708	 	a = Code[pc+1]*/
    _35185 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _35185);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3709	 	b = Code[pc+2]*/
    _35187 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _35187);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:3710	 	c = Code[pc+3]*/
    _35189 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65333 = (object)*(((s1_ptr)_2)->base + _35189);
    if (!IS_ATOM_INT(_67c_65333)){
        _67c_65333 = (object)DBL_PTR(_67c_65333)->dbl;
    }

    /** execute.e:3711	 	d = Code[pc+4]*/
    _35191 = _67pc_65330 + 4LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67d_65334 = (object)*(((s1_ptr)_2)->base + _35191);
    if (!IS_ATOM_INT(_67d_65334)){
        _67d_65334 = (object)DBL_PTR(_67d_65334)->dbl;
    }

    /** execute.e:3712	 	target = Code[pc+5]*/
    _35193 = _67pc_65330 + 5LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _35193);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3713	 	val[target] = replace(val[a],val[b],val[c],val[d])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _35195 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _35196 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _2 = (object)SEQ_PTR(_67val_65340);
    _35197 = (object)*(((s1_ptr)_2)->base + _67c_65333);
    _2 = (object)SEQ_PTR(_67val_65340);
    _35198 = (object)*(((s1_ptr)_2)->base + _67d_65334);
    {
        intptr_t p1 = _35195;
        intptr_t p2 = _35196;
        intptr_t p3 = _35197;
        intptr_t p4 = _35198;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_35199;
        Replace( &replace_params );
    }
    _35195 = NOVALUE;
    _35196 = NOVALUE;
    _35197 = NOVALUE;
    _35198 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35199;
    if( _1 != _35199 ){
        DeRef(_1);
    }
    _35199 = NOVALUE;

    /** execute.e:3714	 	pc += 6*/
    _67pc_65330 = _67pc_65330 + 6LL;

    /** execute.e:3715	end procedure*/
    _35193 = NOVALUE;
    _35185 = NOVALUE;
    _35191 = NOVALUE;
    _35189 = NOVALUE;
    _35187 = NOVALUE;
    return;
    ;
}


void _67opHEAD()
{
    object _35209 = NOVALUE;
    object _35208 = NOVALUE;
    object _35207 = NOVALUE;
    object _35205 = NOVALUE;
    object _35203 = NOVALUE;
    object _35201 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3718		a = Code[pc+1]*/
    _35201 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _35201);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3719		b = Code[pc+2]*/
    _35203 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _35203);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:3720		target = Code[pc+3]*/
    _35205 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _35205);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3721		val[target] = head(val[a],val[b])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _35207 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _35208 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    {
        int len = SEQ_PTR(_35207)->length;
        int size = (IS_ATOM_INT(_35208)) ? _35208 : (object)(DBL_PTR(_35208)->dbl);
        if (size <= 0){
            DeRef( _35209 );
            _35209 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_35207);
            DeRef(_35209);
            _35209 = _35207;
        }
        else{
            Head(SEQ_PTR(_35207),size+1,&_35209);
        }
    }
    _35207 = NOVALUE;
    _35208 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35209;
    if( _1 != _35209 ){
        DeRef(_1);
    }
    _35209 = NOVALUE;

    /** execute.e:3722		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:3723	end procedure*/
    _35205 = NOVALUE;
    _35203 = NOVALUE;
    _35201 = NOVALUE;
    return;
    ;
}


void _67opTAIL()
{
    object _35219 = NOVALUE;
    object _35218 = NOVALUE;
    object _35217 = NOVALUE;
    object _35215 = NOVALUE;
    object _35213 = NOVALUE;
    object _35211 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3726		a = Code[pc+1]*/
    _35211 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _35211);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3727		b = Code[pc+2]*/
    _35213 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _35213);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:3728		target = Code[pc+3]*/
    _35215 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _35215);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3729		val[target] = tail(val[a],val[b])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _35217 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _35218 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    {
        int len = SEQ_PTR(_35217)->length;
        int size = (IS_ATOM_INT(_35218)) ? _35218 : (object)(DBL_PTR(_35218)->dbl);
        if (size <= 0) {
            DeRef(_35219);
            _35219 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_35217);
            DeRef(_35219);
            _35219 = _35217;
        }
        else Tail(SEQ_PTR(_35217), len-size+1, &_35219);
    }
    _35217 = NOVALUE;
    _35218 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35219;
    if( _1 != _35219 ){
        DeRef(_1);
    }
    _35219 = NOVALUE;

    /** execute.e:3730		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:3731	end procedure*/
    _35211 = NOVALUE;
    _35213 = NOVALUE;
    _35215 = NOVALUE;
    return;
    ;
}


void _67opMACHINE_FUNC()
{
    object _35232 = NOVALUE;
    object _35231 = NOVALUE;
    object _35230 = NOVALUE;
    object _35228 = NOVALUE;
    object _35225 = NOVALUE;
    object _35223 = NOVALUE;
    object _35221 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3734		a = Code[pc+1]*/
    _35221 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _35221);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3735		b = Code[pc+2]*/
    _35223 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _35223);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:3736		target = Code[pc+3]*/
    _35225 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _35225);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3738		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:3740		if val[a] = M_CALL_BACK then*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _35228 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    if (binary_op_a(NOTEQ, _35228, 52LL)){
        _35228 = NOVALUE;
        goto L1; // [67] 81
    }
    _35228 = NOVALUE;

    /** execute.e:3742			do_callback(b)*/
    _67do_callback(_67b_65332);
    goto L2; // [78] 112
L1: 

    /** execute.e:3744			val[target] = machine_func(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _35230 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _35231 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _35232 = machine(_35230, _35231);
    _35230 = NOVALUE;
    _35231 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35232;
    if( _1 != _35232 ){
        DeRef(_1);
    }
    _35232 = NOVALUE;
L2: 

    /** execute.e:3746	end procedure*/
    DeRef(_35221);
    _35221 = NOVALUE;
    DeRef(_35223);
    _35223 = NOVALUE;
    DeRef(_35225);
    _35225 = NOVALUE;
    return;
    ;
}


void _67opSPLICE()
{
    object _35244 = NOVALUE;
    object _35243 = NOVALUE;
    object _35242 = NOVALUE;
    object _35241 = NOVALUE;
    object _35239 = NOVALUE;
    object _35237 = NOVALUE;
    object _35235 = NOVALUE;
    object _35233 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3749		a = Code[pc+1]*/
    _35233 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _35233);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3750		b = Code[pc+2]*/
    _35235 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _35235);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:3751		c = Code[pc+3]*/
    _35237 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65333 = (object)*(((s1_ptr)_2)->base + _35237);
    if (!IS_ATOM_INT(_67c_65333)){
        _67c_65333 = (object)DBL_PTR(_67c_65333)->dbl;
    }

    /** execute.e:3752		target = Code[pc+4]*/
    _35239 = _67pc_65330 + 4LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _35239);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3753		val[target] = splice(val[a],val[b],val[c])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _35241 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _35242 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _2 = (object)SEQ_PTR(_67val_65340);
    _35243 = (object)*(((s1_ptr)_2)->base + _67c_65333);
    {
        s1_ptr assign_space;
        insert_pos = IS_ATOM_INT(_35243) ? _35243 : DBL_PTR(_35243)->dbl;
        if (insert_pos <= 0) {
            if (IS_SEQUENCE(_35242)) {
                Concat(&_35244,_35242,_35241);
            }
            else{
                Prepend(&_35244,_35241,_35242);
            }
        }
        else if (insert_pos > SEQ_PTR(_35241)->length){
            if (IS_SEQUENCE(_35242)) {
                Concat(&_35244,_35241,_35242);
            }
            else{
                Append(&_35244,_35241,_35242);
            }
        }
        else if (IS_SEQUENCE(_35242)) {
            if( _35244 != _35241 || SEQ_PTR( _35241 )->ref != 1 ){
                DeRef( _35244 );
                RefDS( _35241 );
            }
            assign_space = Add_internal_space( _35241, insert_pos,((s1_ptr)SEQ_PTR(_35242))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_35242), _35241 == _35244 );
            _35244 = MAKE_SEQ( assign_space );
        }
        else {
            if( _35244 == _35241 && SEQ_PTR( _35241 )->ref == 1 ){
                _35244 = Insert( _35241, _35242, insert_pos);
            }
            else {
                DeRef( _35244 );
                RefDS( _35241 );
                _35244 = Insert( _35241, _35242, insert_pos);
            }
        }
    }
    _35241 = NOVALUE;
    _35242 = NOVALUE;
    _35243 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35244;
    if( _1 != _35244 ){
        DeRef(_1);
    }
    _35244 = NOVALUE;

    /** execute.e:3754		pc += 5*/
    _67pc_65330 = _67pc_65330 + 5LL;

    /** execute.e:3755	end procedure*/
    _35235 = NOVALUE;
    _35233 = NOVALUE;
    _35239 = NOVALUE;
    _35237 = NOVALUE;
    return;
    ;
}


void _67opINSERT()
{
    object _35257 = NOVALUE;
    object _35256 = NOVALUE;
    object _35255 = NOVALUE;
    object _35254 = NOVALUE;
    object _35252 = NOVALUE;
    object _35250 = NOVALUE;
    object _35248 = NOVALUE;
    object _35246 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3758		a = Code[pc+1]*/
    _35246 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _35246);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3759		b = Code[pc+2]*/
    _35248 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _35248);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:3760		c = Code[pc+3]*/
    _35250 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65333 = (object)*(((s1_ptr)_2)->base + _35250);
    if (!IS_ATOM_INT(_67c_65333)){
        _67c_65333 = (object)DBL_PTR(_67c_65333)->dbl;
    }

    /** execute.e:3761		target = Code[pc+4]*/
    _35252 = _67pc_65330 + 4LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65335 = (object)*(((s1_ptr)_2)->base + _35252);
    if (!IS_ATOM_INT(_67target_65335)){
        _67target_65335 = (object)DBL_PTR(_67target_65335)->dbl;
    }

    /** execute.e:3762		val[target] = insert(val[a],val[b],val[c])*/
    _2 = (object)SEQ_PTR(_67val_65340);
    _35254 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67val_65340);
    _35255 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    _2 = (object)SEQ_PTR(_67val_65340);
    _35256 = (object)*(((s1_ptr)_2)->base + _67c_65333);
    {
        s1_ptr assign_space;
        insert_pos = IS_ATOM_INT(_35256) ? _35256 : DBL_PTR(_35256)->dbl;
        if (insert_pos <= 0){
            Prepend(&_35257,_35254,_35255);
        }
        else if (insert_pos > SEQ_PTR(_35254)->length) {
            Ref( _35255 );
            Append(&_35257,_35254,_35255);
        }
        else {
            Ref( _35255 );
            RefDS( _35254 );
            _35257 = Insert(_35254,_35255,insert_pos);
        }
    }
    _35254 = NOVALUE;
    _35255 = NOVALUE;
    _35256 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35257;
    if( _1 != _35257 ){
        DeRef(_1);
    }
    _35257 = NOVALUE;

    /** execute.e:3763		pc += 5*/
    _67pc_65330 = _67pc_65330 + 5LL;

    /** execute.e:3764	end procedure*/
    _35246 = NOVALUE;
    _35250 = NOVALUE;
    _35248 = NOVALUE;
    _35252 = NOVALUE;
    return;
    ;
}


void _67opMACHINE_PROC()
{
    object _v_70478 = NOVALUE;
    object _35276 = NOVALUE;
    object _35275 = NOVALUE;
    object _35273 = NOVALUE;
    object _35271 = NOVALUE;
    object _35270 = NOVALUE;
    object _35268 = NOVALUE;
    object _35267 = NOVALUE;
    object _35261 = NOVALUE;
    object _35259 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3770		a = Code[pc+1]*/
    _35259 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _35259);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3771		b = Code[pc+2]*/
    _35261 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65332 = (object)*(((s1_ptr)_2)->base + _35261);
    if (!IS_ATOM_INT(_67b_65332)){
        _67b_65332 = (object)DBL_PTR(_67b_65332)->dbl;
    }

    /** execute.e:3772		v = val[a]*/
    DeRef(_v_70478);
    _2 = (object)SEQ_PTR(_67val_65340);
    _v_70478 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    Ref(_v_70478);

    /** execute.e:3774		switch v do*/
    if (IS_SEQUENCE(_v_70478) ){
        goto L1; // [45] 201
    }
    if(!IS_ATOM_INT(_v_70478)){
        if( (DBL_PTR(_v_70478)->dbl != (eudouble) ((object) DBL_PTR(_v_70478)->dbl) ) ){
            goto L1; // [45] 201
        }
        _0 = (object) DBL_PTR(_v_70478)->dbl;
    }
    else {
        _0 = _v_70478;
    };
    switch ( _0 ){ 

        /** execute.e:3775			case M_CRASH_ROUTINE then*/
        case 66:

        /** execute.e:3777				do_crash_routine(b)*/
        _67do_crash_routine(_67b_65332);
        goto L2; // [61] 217

        /** execute.e:3779			case M_CRASH_MESSAGE then*/
        case 37:

        /** execute.e:3780				crash_msg = val[b]*/
        DeRef(_67crash_msg_65256);
        _2 = (object)SEQ_PTR(_67val_65340);
        _67crash_msg_65256 = (object)*(((s1_ptr)_2)->base + _67b_65332);
        Ref(_67crash_msg_65256);
        goto L2; // [77] 217

        /** execute.e:3782			case M_CRASH_FILE then*/
        case 57:

        /** execute.e:3783				if sequence(val[b]) then*/
        _2 = (object)SEQ_PTR(_67val_65340);
        _35267 = (object)*(((s1_ptr)_2)->base + _67b_65332);
        _35268 = IS_SEQUENCE(_35267);
        _35267 = NOVALUE;
        if (_35268 == 0)
        {
            _35268 = NOVALUE;
            goto L2; // [96] 217
        }
        else{
            _35268 = NOVALUE;
        }

        /** execute.e:3784					err_file_name = val[b]*/
        DeRef(_67err_file_name_65381);
        _2 = (object)SEQ_PTR(_67val_65340);
        _67err_file_name_65381 = (object)*(((s1_ptr)_2)->base + _67b_65332);
        Ref(_67err_file_name_65381);
        goto L2; // [112] 217

        /** execute.e:3787			case M_WARNING_FILE then*/
        case 72:

        /** execute.e:3788				display_warnings = 1*/
        _49display_warnings_49692 = 1LL;

        /** execute.e:3789				if sequence(val[b]) then*/
        _2 = (object)SEQ_PTR(_67val_65340);
        _35270 = (object)*(((s1_ptr)_2)->base + _67b_65332);
        _35271 = IS_SEQUENCE(_35270);
        _35270 = NOVALUE;
        if (_35271 == 0)
        {
            _35271 = NOVALUE;
            goto L3; // [138] 154
        }
        else{
            _35271 = NOVALUE;
        }

        /** execute.e:3790					TempWarningName = val[b]*/
        DeRef(_27TempWarningName_20585);
        _2 = (object)SEQ_PTR(_67val_65340);
        _27TempWarningName_20585 = (object)*(((s1_ptr)_2)->base + _67b_65332);
        Ref(_27TempWarningName_20585);
        goto L2; // [151] 217
L3: 

        /** execute.e:3792					TempWarningName = STDERR*/
        DeRef(_27TempWarningName_20585);
        _27TempWarningName_20585 = 2LL;

        /** execute.e:3793					display_warnings = (val[b] >= 0)*/
        _2 = (object)SEQ_PTR(_67val_65340);
        _35273 = (object)*(((s1_ptr)_2)->base + _67b_65332);
        if (IS_ATOM_INT(_35273)) {
            _49display_warnings_49692 = (_35273 >= 0LL);
        }
        else {
            _49display_warnings_49692 = binary_op(GREATEREQ, _35273, 0LL);
        }
        _35273 = NOVALUE;
        if (!IS_ATOM_INT(_49display_warnings_49692)) {
            _1 = (object)(DBL_PTR(_49display_warnings_49692)->dbl);
            DeRefDS(_49display_warnings_49692);
            _49display_warnings_49692 = _1;
        }
        goto L2; // [178] 217

        /** execute.e:3796			case M_CRASH then*/
        case 67:

        /** execute.e:3798				RTFatal( val[b] )*/
        _2 = (object)SEQ_PTR(_67val_65340);
        _35275 = (object)*(((s1_ptr)_2)->base + _67b_65332);
        Ref(_35275);
        _67RTFatal(_35275);
        _35275 = NOVALUE;
        goto L2; // [197] 217

        /** execute.e:3801			case else*/
        default:
L1: 

        /** execute.e:3802				machine_proc(v, val[b])*/
        _2 = (object)SEQ_PTR(_67val_65340);
        _35276 = (object)*(((s1_ptr)_2)->base + _67b_65332);
        machine(_v_70478, _35276);
        _35276 = NOVALUE;
    ;}L2: 

    /** execute.e:3804		pc += 3*/
    _67pc_65330 = _67pc_65330 + 3LL;

    /** execute.e:3805	end procedure*/
    DeRef(_v_70478);
    DeRef(_35259);
    _35259 = NOVALUE;
    DeRef(_35261);
    _35261 = NOVALUE;
    return;
    ;
}


void _67opDEREF_TEMP()
{
    object _35279 = NOVALUE;
    object _35278 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3808		val[Code[pc+1]] = NOVALUE*/
    _35278 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _35279 = (object)*(((s1_ptr)_2)->base + _35278);
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35279))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_35279)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _35279);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);

    /** execute.e:3809		pc += 2*/
    _67pc_65330 = _67pc_65330 + 2LL;

    /** execute.e:3810	end procedure*/
    _35279 = NOVALUE;
    _35278 = NOVALUE;
    return;
    ;
}


void _67do_delete_routine(object _dx_70531, object _o_70532)
{
    object _arglist_assign_70535 = NOVALUE;
    object _35301 = NOVALUE;
    object _35300 = NOVALUE;
    object _35299 = NOVALUE;
    object _35298 = NOVALUE;
    object _35297 = NOVALUE;
    object _35295 = NOVALUE;
    object _35294 = NOVALUE;
    object _35292 = NOVALUE;
    object _35291 = NOVALUE;
    object _35286 = NOVALUE;
    object _35284 = NOVALUE;
    object _35283 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:3823		val[t_id] = user_delete_rid[dx]*/
    _2 = (object)SEQ_PTR(_67user_delete_rid_70524);
    _35283 = (object)*(((s1_ptr)_2)->base + _dx_70531);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_id_65261);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35283;
    if( _1 != _35283 ){
        DeRef(_1);
    }
    _35283 = NOVALUE;

    /** execute.e:3824		val[t_arglist] = {o}*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_o_70532);
    ((intptr_t*)_2)[1] = _o_70532;
    _35284 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_arglist_65262);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35284;
    if( _1 != _35284 ){
        DeRef(_1);
    }
    _35284 = NOVALUE;

    /** execute.e:3825		atom arglist_assign = new_arg_assign()*/
    _0 = _arglist_assign_70535;
    _arglist_assign_70535 = _67new_arg_assign();
    DeRef(_0);

    /** execute.e:3827		SymTab[delete_code_routine][S_RESIDENT_TASK] = current_task*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67delete_code_routine_65265 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67current_task_65347;
    DeRef(_1);
    _35286 = NOVALUE;

    /** execute.e:3830		call_stack = append(call_stack, pc)*/
    Append(&_67call_stack_65348, _67call_stack_65348, _67pc_65330);

    /** execute.e:3831		call_stack = append(call_stack, delete_code_routine)*/
    Append(&_67call_stack_65348, _67call_stack_65348, _67delete_code_routine_65265);

    /** execute.e:3833		Code = delete_code*/
    RefDS(_67delete_code_65259);
    DeRef(_27Code_20660);
    _27Code_20660 = _67delete_code_65259;

    /** execute.e:3834		pc = 1*/
    _67pc_65330 = 1LL;

    /** execute.e:3836		do_exec()*/
    _67do_exec();

    /** execute.e:3838		if arglist_assign = arg_assign then*/
    if (binary_op_a(NOTEQ, _arglist_assign_70535, _67arg_assign_65274)){
        goto L1; // [99] 116
    }

    /** execute.e:3840			val[t_arglist] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_arglist_65262);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
L1: 

    /** execute.e:3842		o = 0*/
    DeRef(_o_70532);
    _o_70532 = 0LL;

    /** execute.e:3845		pc = call_stack[$-1]*/
    if (IS_SEQUENCE(_67call_stack_65348)){
            _35291 = SEQ_PTR(_67call_stack_65348)->length;
    }
    else {
        _35291 = 1;
    }
    _35292 = _35291 - 1LL;
    _35291 = NOVALUE;
    _2 = (object)SEQ_PTR(_67call_stack_65348);
    _67pc_65330 = (object)*(((s1_ptr)_2)->base + _35292);
    if (!IS_ATOM_INT(_67pc_65330))
    _67pc_65330 = (object)DBL_PTR(_67pc_65330)->dbl;

    /** execute.e:3846		call_stack = call_stack[1..$-2]*/
    if (IS_SEQUENCE(_67call_stack_65348)){
            _35294 = SEQ_PTR(_67call_stack_65348)->length;
    }
    else {
        _35294 = 1;
    }
    _35295 = _35294 - 2LL;
    _35294 = NOVALUE;
    rhs_slice_target = (object_ptr)&_67call_stack_65348;
    RHS_Slice(_67call_stack_65348, 1LL, _35295);

    /** execute.e:3848		restore_privates( call_stack[$] )*/
    if (IS_SEQUENCE(_67call_stack_65348)){
            _35297 = SEQ_PTR(_67call_stack_65348)->length;
    }
    else {
        _35297 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_65348);
    _35298 = (object)*(((s1_ptr)_2)->base + _35297);
    Ref(_35298);
    _67restore_privates(_35298);
    _35298 = NOVALUE;

    /** execute.e:3851		Code = SymTab[call_stack[$]][S_CODE]*/
    if (IS_SEQUENCE(_67call_stack_65348)){
            _35299 = SEQ_PTR(_67call_stack_65348)->length;
    }
    else {
        _35299 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_65348);
    _35300 = (object)*(((s1_ptr)_2)->base + _35299);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_35300)){
        _35301 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_35300)->dbl));
    }
    else{
        _35301 = (object)*(((s1_ptr)_2)->base + _35300);
    }
    DeRef(_27Code_20660);
    _2 = (object)SEQ_PTR(_35301);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    Ref(_27Code_20660);
    _35301 = NOVALUE;

    /** execute.e:3852	end procedure*/
    DeRef(_arglist_assign_70535);
    _35295 = NOVALUE;
    _35292 = NOVALUE;
    _35300 = NOVALUE;
    return;
    ;
}


void _67user_delete_01(object _o_70565)
{
    object _0, _1, _2;
    

    /** execute.e:3855		do_delete_routine( 1, o )*/
    Ref(_o_70565);
    _67do_delete_routine(1LL, _o_70565);

    /** execute.e:3856	end procedure*/
    DeRef(_o_70565);
    return;
    ;
}


void _67user_delete_02(object _o_70570)
{
    object _0, _1, _2;
    

    /** execute.e:3860		do_delete_routine( 2, o )*/
    Ref(_o_70570);
    _67do_delete_routine(2LL, _o_70570);

    /** execute.e:3861	end procedure*/
    DeRef(_o_70570);
    return;
    ;
}


void _67user_delete_03(object _o_70575)
{
    object _0, _1, _2;
    

    /** execute.e:3865		do_delete_routine( 3, o )*/
    Ref(_o_70575);
    _67do_delete_routine(3LL, _o_70575);

    /** execute.e:3866	end procedure*/
    DeRef(_o_70575);
    return;
    ;
}


void _67user_delete_04(object _o_70580)
{
    object _0, _1, _2;
    

    /** execute.e:3870		do_delete_routine( 4, o )*/
    Ref(_o_70580);
    _67do_delete_routine(4LL, _o_70580);

    /** execute.e:3871	end procedure*/
    DeRef(_o_70580);
    return;
    ;
}


void _67user_delete_05(object _o_70585)
{
    object _0, _1, _2;
    

    /** execute.e:3875		do_delete_routine( 5, o )*/
    Ref(_o_70585);
    _67do_delete_routine(5LL, _o_70585);

    /** execute.e:3876	end procedure*/
    DeRef(_o_70585);
    return;
    ;
}


void _67user_delete_06(object _o_70590)
{
    object _0, _1, _2;
    

    /** execute.e:3880		do_delete_routine( 6, o )*/
    Ref(_o_70590);
    _67do_delete_routine(6LL, _o_70590);

    /** execute.e:3881	end procedure*/
    DeRef(_o_70590);
    return;
    ;
}


void _67user_delete_07(object _o_70595)
{
    object _0, _1, _2;
    

    /** execute.e:3885		do_delete_routine( 7, o )*/
    Ref(_o_70595);
    _67do_delete_routine(7LL, _o_70595);

    /** execute.e:3886	end procedure*/
    DeRef(_o_70595);
    return;
    ;
}


void _67user_delete_08(object _o_70600)
{
    object _0, _1, _2;
    

    /** execute.e:3890		do_delete_routine( 8, o )*/
    Ref(_o_70600);
    _67do_delete_routine(8LL, _o_70600);

    /** execute.e:3891	end procedure*/
    DeRef(_o_70600);
    return;
    ;
}


void _67user_delete_09(object _o_70605)
{
    object _0, _1, _2;
    

    /** execute.e:3895		do_delete_routine( 9, o )*/
    Ref(_o_70605);
    _67do_delete_routine(9LL, _o_70605);

    /** execute.e:3896	end procedure*/
    DeRef(_o_70605);
    return;
    ;
}


void _67user_delete_10(object _o_70610)
{
    object _0, _1, _2;
    

    /** execute.e:3900		do_delete_routine( 10, o )*/
    Ref(_o_70610);
    _67do_delete_routine(10LL, _o_70610);

    /** execute.e:3901	end procedure*/
    DeRef(_o_70610);
    return;
    ;
}


void _67user_delete_11(object _o_70615)
{
    object _0, _1, _2;
    

    /** execute.e:3905		do_delete_routine( 11, o )*/
    Ref(_o_70615);
    _67do_delete_routine(11LL, _o_70615);

    /** execute.e:3906	end procedure*/
    DeRef(_o_70615);
    return;
    ;
}


void _67user_delete_12(object _o_70620)
{
    object _0, _1, _2;
    

    /** execute.e:3910		do_delete_routine( 12, o )*/
    Ref(_o_70620);
    _67do_delete_routine(12LL, _o_70620);

    /** execute.e:3911	end procedure*/
    DeRef(_o_70620);
    return;
    ;
}


void _67user_delete_13(object _o_70625)
{
    object _0, _1, _2;
    

    /** execute.e:3915		do_delete_routine( 13, o )*/
    Ref(_o_70625);
    _67do_delete_routine(13LL, _o_70625);

    /** execute.e:3916	end procedure*/
    DeRef(_o_70625);
    return;
    ;
}


void _67user_delete_14(object _o_70630)
{
    object _0, _1, _2;
    

    /** execute.e:3920		do_delete_routine( 14, o )*/
    Ref(_o_70630);
    _67do_delete_routine(14LL, _o_70630);

    /** execute.e:3921	end procedure*/
    DeRef(_o_70630);
    return;
    ;
}


void _67user_delete_15(object _o_70635)
{
    object _0, _1, _2;
    

    /** execute.e:3925		do_delete_routine( 15, o )*/
    Ref(_o_70635);
    _67do_delete_routine(15LL, _o_70635);

    /** execute.e:3926	end procedure*/
    DeRef(_o_70635);
    return;
    ;
}


void _67user_delete_16(object _o_70640)
{
    object _0, _1, _2;
    

    /** execute.e:3930		do_delete_routine( 16, o )*/
    Ref(_o_70640);
    _67do_delete_routine(16LL, _o_70640);

    /** execute.e:3931	end procedure*/
    DeRef(_o_70640);
    return;
    ;
}


void _67user_delete_17(object _o_70645)
{
    object _0, _1, _2;
    

    /** execute.e:3935		do_delete_routine( 17, o )*/
    Ref(_o_70645);
    _67do_delete_routine(17LL, _o_70645);

    /** execute.e:3936	end procedure*/
    DeRef(_o_70645);
    return;
    ;
}


void _67user_delete_18(object _o_70651)
{
    object _0, _1, _2;
    

    /** execute.e:3940		do_delete_routine( 18, o )*/
    Ref(_o_70651);
    _67do_delete_routine(18LL, _o_70651);

    /** execute.e:3941	end procedure*/
    DeRef(_o_70651);
    return;
    ;
}


void _67user_delete_19(object _o_70656)
{
    object _0, _1, _2;
    

    /** execute.e:3945		do_delete_routine( 19, o )*/
    Ref(_o_70656);
    _67do_delete_routine(19LL, _o_70656);

    /** execute.e:3946	end procedure*/
    DeRef(_o_70656);
    return;
    ;
}


void _67user_delete_20(object _o_70662)
{
    object _0, _1, _2;
    

    /** execute.e:3950		do_delete_routine( 20, o )*/
    Ref(_o_70662);
    _67do_delete_routine(20LL, _o_70662);

    /** execute.e:3951	end procedure*/
    DeRef(_o_70662);
    return;
    ;
}


void _67opDELETE_ROUTINE()
{
    object _rid_70670 = NOVALUE;
    object _35360 = NOVALUE;
    object _35359 = NOVALUE;
    object _35358 = NOVALUE;
    object _35357 = NOVALUE;
    object _35356 = NOVALUE;
    object _35355 = NOVALUE;
    object _35348 = NOVALUE;
    object _35347 = NOVALUE;
    object _35345 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3956		a = Code[pc+1]*/
    _35345 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65331 = (object)*(((s1_ptr)_2)->base + _35345);
    if (!IS_ATOM_INT(_67a_65331)){
        _67a_65331 = (object)DBL_PTR(_67a_65331)->dbl;
    }

    /** execute.e:3958		integer rid = val[Code[pc+2]]*/
    _35347 = _67pc_65330 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _35348 = (object)*(((s1_ptr)_2)->base + _35347);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!IS_ATOM_INT(_35348)){
        _rid_70670 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_35348)->dbl));
    }
    else{
        _rid_70670 = (object)*(((s1_ptr)_2)->base + _35348);
    }
    if (!IS_ATOM_INT(_rid_70670))
    _rid_70670 = (object)DBL_PTR(_rid_70670)->dbl;

    /** execute.e:3959		b = find( rid, user_delete_rid )*/
    _67b_65332 = find_from(_rid_70670, _67user_delete_rid_70524, 1LL);

    /** execute.e:3960		if not b then*/
    if (_67b_65332 != 0)
    goto L1; // [50] 86

    /** execute.e:3961			b = find( -1, user_delete_rid )*/
    _67b_65332 = find_from(-1LL, _67user_delete_rid_70524, 1LL);

    /** execute.e:3962			if not b then*/
    if (_67b_65332 != 0)
    goto L2; // [66] 75

    /** execute.e:3963				RTFatal("Maximum of 20 user defined delete routines exceeded.")*/
    RefDS(_35354);
    _67RTFatal(_35354);
L2: 

    /** execute.e:3965			user_delete_rid[b] = rid*/
    _2 = (object)SEQ_PTR(_67user_delete_rid_70524);
    _2 = (object)(((s1_ptr)_2)->base + _67b_65332);
    *(intptr_t *)_2 = _rid_70670;
L1: 

    /** execute.e:3967		val[Code[pc+3]] = delete_routine( val[a], eu_delete_rid[b] )*/
    _35355 = _67pc_65330 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _35356 = (object)*(((s1_ptr)_2)->base + _35355);
    _2 = (object)SEQ_PTR(_67val_65340);
    _35357 = (object)*(((s1_ptr)_2)->base + _67a_65331);
    _2 = (object)SEQ_PTR(_67eu_delete_rid_70522);
    _35358 = (object)*(((s1_ptr)_2)->base + _67b_65332);
    DeRef(_35359);
    if( IS_ATOM_INT(_35357) ){
        _35359 = NewDouble( (eudouble) _35357 );
    }
    else {
        if( !UNIQUE(SEQ_PTR(_35357)) ){
            if( IS_ATOM_DBL( _35357 ) ){
                _35359 = NewDouble( DBL_PTR(_35357)->dbl );
            }
            else {
                RefDS(_35357);
                _35359 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_35357) ));
            }
        }
        else {
            _35359 = _35357;
        }
    }
    _1 = (object) _00[_35358].cleanup;
    if( _1 == 0 ){
        _1 = (object) TransAlloc( sizeof(struct cleanup) );
        _00[_35358].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _35358;
    ((cleanup_ptr)_1)->next = 0;
    if( IS_ATOM(_35359) ){
        if( IS_ATOM_INT(_35359) ){
            _35359 = NewDouble( (eudouble) _35357 );
        }
        if(DBL_PTR(_35359)->cleanup != 0 ){
            _1 = (object) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_35359)->cleanup );
        }
        else if( !UNIQUE(DBL_PTR(_35359)) ){
            DeRefDS(_35359);
            _35359 = NewDouble( DBL_PTR(_35359)->dbl );
        }
        DBL_PTR(_35359)->cleanup = (cleanup_ptr)_1;
    }
    else{
        if(SEQ_PTR(_35359)->cleanup != 0 ){
            _1 = (object) ChainDeleteRoutine( (cleanup_ptr)_1, SEQ_PTR(_35359)->cleanup );
        }
        else if( !UNIQUE(SEQ_PTR(_35359)) ){
            _35359 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_35359) ));
        }
        SEQ_PTR(_35359)->cleanup = (cleanup_ptr)_1;
    }
    _35357 = NOVALUE;
    _35358 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35356))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_35356)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _35356);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35359;
    if( _1 != _35359 ){
        DeRef(_1);
    }
    _35359 = NOVALUE;

    /** execute.e:3968		if sym_mode( a ) = M_TEMP then*/
    _35360 = _53sym_mode(_67a_65331);
    if (binary_op_a(NOTEQ, _35360, 3LL)){
        DeRef(_35360);
        _35360 = NOVALUE;
        goto L3; // [136] 153
    }
    DeRef(_35360);
    _35360 = NOVALUE;

    /** execute.e:3969			val[a] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65340 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67a_65331);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
L3: 

    /** execute.e:3972		pc += 4*/
    _67pc_65330 = _67pc_65330 + 4LL;

    /** execute.e:3973	end procedure*/
    DeRef(_35347);
    _35347 = NOVALUE;
    _35356 = NOVALUE;
    DeRef(_35345);
    _35345 = NOVALUE;
    _35348 = NOVALUE;
    DeRef(_35355);
    _35355 = NOVALUE;
    return;
    ;
}


void _67opDELETE_OBJECT()
{
    object _35365 = NOVALUE;
    object _35364 = NOVALUE;
    object _35363 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3976		delete( val[Code[pc+1]] )*/
    _35363 = _67pc_65330 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _35364 = (object)*(((s1_ptr)_2)->base + _35363);
    _2 = (object)SEQ_PTR(_67val_65340);
    if (!IS_ATOM_INT(_35364)){
        _35365 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_35364)->dbl));
    }
    else{
        _35365 = (object)*(((s1_ptr)_2)->base + _35364);
    }
    if( IS_SEQUENCE(_35365) ){
        cleanup_sequence(SEQ_PTR(_35365));
    }
    if( IS_ATOM_DBL(_35365)){
        cleanup_double(DBL_PTR(_35365));
    }
    _35365 = NOVALUE;

    /** execute.e:3977		pc += 2*/
    _67pc_65330 = _67pc_65330 + 2LL;

    /** execute.e:3978	end procedure*/
    _35363 = NOVALUE;
    _35364 = NOVALUE;
    return;
    ;
}


void _67do_exec()
{
    object _op_70706 = NOVALUE;
    object _35374 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3982		keep_running = TRUE*/
    _67keep_running_65337 = _9TRUE_441;

    /** execute.e:3983		while keep_running do*/
L1: 
    if (_67keep_running_65337 == 0)
    {
        goto L2; // [17] 1910
    }
    else{
    }

    /** execute.e:3984			integer op = Code[pc]*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    _op_70706 = (object)*(((s1_ptr)_2)->base + _67pc_65330);
    if (!IS_ATOM_INT(_op_70706)){
        _op_70706 = (object)DBL_PTR(_op_70706)->dbl;
    }

    /** execute.e:3985			ifdef DEBUG then*/

    /** execute.e:3992			switch op do*/
    _0 = _op_70706;
    switch ( _0 ){ 

        /** execute.e:3993				case ABORT then*/
        case 126:

        /** execute.e:3994					opABORT()*/
        _67opABORT();
        goto L3; // [49] 1903

        /** execute.e:3996				case AND then*/
        case 8:

        /** execute.e:3997					opAND()*/
        _67opAND();
        goto L3; // [59] 1903

        /** execute.e:3999				case AND_BITS then*/
        case 56:

        /** execute.e:4000					opAND_BITS()*/
        _67opAND_BITS();
        goto L3; // [69] 1903

        /** execute.e:4002				case APPEND then*/
        case 35:

        /** execute.e:4003					opAPPEND()*/
        _67opAPPEND();
        goto L3; // [79] 1903

        /** execute.e:4005				case ARCTAN then*/
        case 73:

        /** execute.e:4006					opARCTAN()*/
        _67opARCTAN();
        goto L3; // [89] 1903

        /** execute.e:4008				case ASSIGN, ASSIGN_I then*/
        case 18:
        case 113:

        /** execute.e:4009					opASSIGN()*/
        _67opASSIGN();
        goto L3; // [101] 1903

        /** execute.e:4011				case ASSIGN_OP_SLICE then*/
        case 150:

        /** execute.e:4012					opASSIGN_OP_SLICE()*/
        _67opASSIGN_OP_SLICE();
        goto L3; // [111] 1903

        /** execute.e:4014				case ASSIGN_OP_SUBS then*/
        case 149:

        /** execute.e:4015					opASSIGN_OP_SUBS()*/
        _67opASSIGN_OP_SUBS();
        goto L3; // [121] 1903

        /** execute.e:4017				case ASSIGN_SLICE then*/
        case 45:

        /** execute.e:4018					opASSIGN_SLICE()*/
        _67opASSIGN_SLICE();
        goto L3; // [131] 1903

        /** execute.e:4020				case ASSIGN_SUBS, ASSIGN_SUBS_CHECK, ASSIGN_SUBS_I then*/
        case 16:
        case 84:
        case 118:

        /** execute.e:4021					opASSIGN_SUBS()*/
        _67opASSIGN_SUBS();
        goto L3; // [145] 1903

        /** execute.e:4023				case ATOM_CHECK then*/
        case 101:

        /** execute.e:4024					opATOM_CHECK()*/
        _67opATOM_CHECK();
        goto L3; // [155] 1903

        /** execute.e:4026				case BADRETURNF then*/
        case 43:

        /** execute.e:4027					opBADRETURNF()*/
        _67opBADRETURNF();
        goto L3; // [165] 1903

        /** execute.e:4029				case C_FUNC then*/
        case 133:

        /** execute.e:4030					opC_FUNC()*/
        _67opC_FUNC();
        goto L3; // [175] 1903

        /** execute.e:4032				case C_PROC then*/
        case 132:

        /** execute.e:4033					opC_PROC()*/
        _67opC_PROC();
        goto L3; // [185] 1903

        /** execute.e:4035				case CALL then*/
        case 129:

        /** execute.e:4036					opCALL()*/
        _67opCALL();
        goto L3; // [195] 1903

        /** execute.e:4038				case CALL_BACK_RETURN then*/
        case 135:

        /** execute.e:4039					opCALL_BACK_RETURN()*/
        _67opCALL_BACK_RETURN();
        goto L3; // [205] 1903

        /** execute.e:4041				case CALL_PROC, CALL_FUNC then*/
        case 136:
        case 137:

        /** execute.e:4042					opCALL_PROC()*/
        _67opCALL_PROC();
        goto L3; // [217] 1903

        /** execute.e:4044				case CASE then*/
        case 186:

        /** execute.e:4045					opCASE()*/
        _67opCASE();
        goto L3; // [227] 1903

        /** execute.e:4047				case CLEAR_SCREEN then*/
        case 59:

        /** execute.e:4048					opCLEAR_SCREEN()*/
        _67opCLEAR_SCREEN();
        goto L3; // [237] 1903

        /** execute.e:4050				case CLOSE then*/
        case 86:

        /** execute.e:4051					opCLOSE()*/
        _67opCLOSE();
        goto L3; // [247] 1903

        /** execute.e:4053				case COMMAND_LINE then*/
        case 100:

        /** execute.e:4054					opCOMMAND_LINE()*/
        _67opCOMMAND_LINE();
        goto L3; // [257] 1903

        /** execute.e:4056				case COMPARE then*/
        case 76:

        /** execute.e:4057					opCOMPARE()*/
        _67opCOMPARE();
        goto L3; // [267] 1903

        /** execute.e:4059				case CONCAT then*/
        case 15:

        /** execute.e:4060					opCONCAT()*/
        _67opCONCAT();
        goto L3; // [277] 1903

        /** execute.e:4062				case CONCAT_N then*/
        case 157:

        /** execute.e:4063					opCONCAT_N()*/
        _67opCONCAT_N();
        goto L3; // [287] 1903

        /** execute.e:4065				case COS then*/
        case 81:

        /** execute.e:4066					opCOS()*/
        _67opCOS();
        goto L3; // [297] 1903

        /** execute.e:4068				case DATE then*/
        case 69:

        /** execute.e:4069					opDATE()*/
        _67opDATE();
        goto L3; // [307] 1903

        /** execute.e:4071				case DIV2 then*/
        case 98:

        /** execute.e:4072					opDIV2()*/
        _67opDIV2();
        goto L3; // [317] 1903

        /** execute.e:4074				case DIVIDE then*/
        case 14:

        /** execute.e:4075					opDIVIDE()*/
        _67opDIVIDE();
        goto L3; // [327] 1903

        /** execute.e:4077				case ELSE, EXIT, ENDWHILE, RETRY then*/
        case 23:
        case 61:
        case 22:
        case 184:

        /** execute.e:4078					opELSE()*/
        _67opELSE();
        goto L3; // [343] 1903

        /** execute.e:4080				case ENDFOR_GENERAL, ENDFOR_UP, ENDFOR_DOWN, ENDFOR_INT_UP,*/
        case 39:
        case 49:
        case 50:
        case 48:
        case 52:
        case 55:

        /** execute.e:4082					opENDFOR_GENERAL()*/
        _67opENDFOR_GENERAL();
        goto L3; // [363] 1903

        /** execute.e:4084				case ENDFOR_INT_UP1 then*/
        case 54:

        /** execute.e:4085					opENDFOR_INT_UP1()*/
        _67opENDFOR_INT_UP1();
        goto L3; // [373] 1903

        /** execute.e:4087				case EQUAL then*/
        case 153:

        /** execute.e:4088					opEQUAL()*/
        _67opEQUAL();
        goto L3; // [383] 1903

        /** execute.e:4090				case EQUALS then*/
        case 3:

        /** execute.e:4091					opEQUALS()*/
        _67opEQUALS();
        goto L3; // [393] 1903

        /** execute.e:4093				case EQUALS_IFW, EQUALS_IFW_I then*/
        case 104:
        case 121:

        /** execute.e:4094					opEQUALS_IFW()*/
        _67opEQUALS_IFW();
        goto L3; // [405] 1903

        /** execute.e:4096				case EXIT_BLOCK then*/
        case 206:

        /** execute.e:4097					opEXIT_BLOCK()*/
        _67opEXIT_BLOCK();
        goto L3; // [415] 1903

        /** execute.e:4099				case FIND then*/
        case 77:

        /** execute.e:4100					opFIND()*/
        _67opFIND();
        goto L3; // [425] 1903

        /** execute.e:4102				case FIND_FROM then*/
        case 176:

        /** execute.e:4103					opFIND_FROM()*/
        _67opFIND_FROM();
        goto L3; // [435] 1903

        /** execute.e:4105				case FLOOR then*/
        case 83:

        /** execute.e:4106					opFLOOR()*/
        _67opFLOOR();
        goto L3; // [445] 1903

        /** execute.e:4108				case FLOOR_DIV then*/
        case 63:

        /** execute.e:4109					opFLOOR_DIV()*/
        _67opFLOOR_DIV();
        goto L3; // [455] 1903

        /** execute.e:4111				case FLOOR_DIV2 then*/
        case 66:

        /** execute.e:4112					opFLOOR_DIV2()*/
        _67opFLOOR_DIV2();
        goto L3; // [465] 1903

        /** execute.e:4114				case FOR, FOR_I then*/
        case 21:
        case 125:

        /** execute.e:4115					opFOR()*/
        _67opFOR();
        goto L3; // [477] 1903

        /** execute.e:4117				case GET_KEY then*/
        case 79:

        /** execute.e:4118					opGET_KEY()*/
        _67opGET_KEY();
        goto L3; // [487] 1903

        /** execute.e:4120				case GETC then*/
        case 33:

        /** execute.e:4121					opGETC()*/
        _67opGETC();
        goto L3; // [497] 1903

        /** execute.e:4123				case GETENV then*/
        case 91:

        /** execute.e:4124					opGETENV()*/
        _67opGETENV();
        goto L3; // [507] 1903

        /** execute.e:4126				case GETS then*/
        case 17:

        /** execute.e:4127					opGETS()*/
        _67opGETS();
        goto L3; // [517] 1903

        /** execute.e:4129				case GLABEL then*/
        case 189:

        /** execute.e:4130					opGLABEL()*/
        _67opGLABEL();
        goto L3; // [527] 1903

        /** execute.e:4132				case GLOBAL_INIT_CHECK, PRIVATE_INIT_CHECK then*/
        case 109:
        case 30:

        /** execute.e:4133					opGLOBAL_INIT_CHECK()*/
        _67opGLOBAL_INIT_CHECK();
        goto L3; // [539] 1903

        /** execute.e:4135				case GOTO then*/
        case 188:

        /** execute.e:4136					opGOTO()*/
        _67opGOTO();
        goto L3; // [549] 1903

        /** execute.e:4138				case GREATER then*/
        case 6:

        /** execute.e:4139					opGREATER()*/
        _67opGREATER();
        goto L3; // [559] 1903

        /** execute.e:4141				case GREATER_IFW, GREATER_IFW_I then*/
        case 107:
        case 124:

        /** execute.e:4142					opGREATER_IFW()*/
        _67opGREATER_IFW();
        goto L3; // [571] 1903

        /** execute.e:4144				case GREATEREQ then*/
        case 2:

        /** execute.e:4145					opGREATEREQ()*/
        _67opGREATEREQ();
        goto L3; // [581] 1903

        /** execute.e:4147				case GREATEREQ_IFW, GREATEREQ_IFW_I then*/
        case 103:
        case 120:

        /** execute.e:4148					opGREATEREQ_IFW()*/
        _67opGREATEREQ_IFW();
        goto L3; // [593] 1903

        /** execute.e:4150				case HASH then*/
        case 194:

        /** execute.e:4151					opHASH()*/
        _67opHASH();
        goto L3; // [603] 1903

        /** execute.e:4153				case HEAD then*/
        case 198:

        /** execute.e:4154					opHEAD()*/
        _67opHEAD();
        goto L3; // [613] 1903

        /** execute.e:4156				case IF then*/
        case 20:

        /** execute.e:4157					opIF()*/
        _67opIF();
        goto L3; // [623] 1903

        /** execute.e:4159				case INSERT then*/
        case 191:

        /** execute.e:4160					opINSERT()*/
        _67opINSERT();
        goto L3; // [633] 1903

        /** execute.e:4162				case INTEGER_CHECK then*/
        case 96:

        /** execute.e:4163					opINTEGER_CHECK()*/
        _67opINTEGER_CHECK();
        goto L3; // [643] 1903

        /** execute.e:4165				case IS_A_SEQUENCE then*/
        case 68:

        /** execute.e:4166					opIS_A_SEQUENCE()*/
        _67opIS_A_SEQUENCE();
        goto L3; // [653] 1903

        /** execute.e:4168				case IS_AN_ATOM then*/
        case 67:

        /** execute.e:4169					opIS_AN_ATOM()*/
        _67opIS_AN_ATOM();
        goto L3; // [663] 1903

        /** execute.e:4171				case IS_AN_INTEGER then*/
        case 94:

        /** execute.e:4172					opIS_AN_INTEGER()*/
        _67opIS_AN_INTEGER();
        goto L3; // [673] 1903

        /** execute.e:4174				case IS_AN_OBJECT then*/
        case 40:

        /** execute.e:4175					opIS_AN_OBJECT()*/
        _67opIS_AN_OBJECT();
        goto L3; // [683] 1903

        /** execute.e:4177				case LENGTH then*/
        case 42:

        /** execute.e:4178					opLENGTH()*/
        _67opLENGTH();
        goto L3; // [693] 1903

        /** execute.e:4180				case LESS then*/
        case 1:

        /** execute.e:4181					opLESS()*/
        _67opLESS();
        goto L3; // [703] 1903

        /** execute.e:4183				case LESS_IFW_I, LESS_IFW then*/
        case 119:
        case 102:

        /** execute.e:4184					opLESS_IFW()*/
        _67opLESS_IFW();
        goto L3; // [715] 1903

        /** execute.e:4186				case LESSEQ then*/
        case 5:

        /** execute.e:4187					opLESSEQ()*/
        _67opLESSEQ();
        goto L3; // [725] 1903

        /** execute.e:4189				case LESSEQ_IFW, LESSEQ_IFW_I then*/
        case 106:
        case 123:

        /** execute.e:4190					opLESSEQ_IFW()*/
        _67opLESSEQ_IFW();
        goto L3; // [737] 1903

        /** execute.e:4192				case LHS_SUBS then*/
        case 95:

        /** execute.e:4193					opLHS_SUBS()*/
        _67opLHS_SUBS();
        goto L3; // [747] 1903

        /** execute.e:4195				case LHS_SUBS1 then*/
        case 161:

        /** execute.e:4196					opLHS_SUBS1()*/
        _67opLHS_SUBS1();
        goto L3; // [757] 1903

        /** execute.e:4198				case LHS_SUBS1_COPY then*/
        case 166:

        /** execute.e:4199					opLHS_SUBS1_COPY()*/
        _67opLHS_SUBS1_COPY();
        goto L3; // [767] 1903

        /** execute.e:4201				case LOG then*/
        case 74:

        /** execute.e:4202					opLOG()*/
        _67opLOG();
        goto L3; // [777] 1903

        /** execute.e:4204				case MACHINE_FUNC then*/
        case 111:

        /** execute.e:4205					opMACHINE_FUNC()*/
        _67opMACHINE_FUNC();
        goto L3; // [787] 1903

        /** execute.e:4207				case MACHINE_PROC then*/
        case 112:

        /** execute.e:4208					opMACHINE_PROC()*/
        _67opMACHINE_PROC();
        goto L3; // [797] 1903

        /** execute.e:4210				case MATCH then*/
        case 78:

        /** execute.e:4211					opMATCH()*/
        _67opMATCH();
        goto L3; // [807] 1903

        /** execute.e:4213				case MATCH_FROM then*/
        case 177:

        /** execute.e:4214					opMATCH_FROM()*/
        _67opMATCH_FROM();
        goto L3; // [817] 1903

        /** execute.e:4216				case MEM_COPY then*/
        case 130:

        /** execute.e:4217					opMEM_COPY()*/
        _67opMEM_COPY();
        goto L3; // [827] 1903

        /** execute.e:4219				case MEM_SET then*/
        case 131:

        /** execute.e:4220					opMEM_SET()*/
        _67opMEM_SET();
        goto L3; // [837] 1903

        /** execute.e:4222				case MINUS, MINUS_I then*/
        case 10:
        case 116:

        /** execute.e:4223					opMINUS()*/
        _67opMINUS();
        goto L3; // [849] 1903

        /** execute.e:4225				case MULTIPLY then*/
        case 13:

        /** execute.e:4226					opMULTIPLY()*/
        _67opMULTIPLY();
        goto L3; // [859] 1903

        /** execute.e:4228				case NOP2, SC2_NULL, ASSIGN_SUBS2, PLATFORM, END_PARAM_CHECK,*/
        case 110:
        case 145:
        case 148:
        case 155:
        case 156:
        case 158:
        case 159:

        /** execute.e:4230					opNOP2()*/
        _67opNOP2();
        goto L3; // [881] 1903

        /** execute.e:4232				case NOPSWITCH then*/
        case 187:

        /** execute.e:4233					opNOPSWITCH()*/
        _67opNOPSWITCH();
        goto L3; // [891] 1903

        /** execute.e:4235				case NOT then*/
        case 7:

        /** execute.e:4236					opNOT()*/
        _67opNOT();
        goto L3; // [901] 1903

        /** execute.e:4238				case NOT_BITS then*/
        case 51:

        /** execute.e:4239					opNOT_BITS()*/
        _67opNOT_BITS();
        goto L3; // [911] 1903

        /** execute.e:4241				case NOT_IFW then*/
        case 108:

        /** execute.e:4242					opNOT_IFW()*/
        _67opNOT_IFW();
        goto L3; // [921] 1903

        /** execute.e:4244				case NOTEQ then*/
        case 4:

        /** execute.e:4245					opNOTEQ()*/
        _67opNOTEQ();
        goto L3; // [931] 1903

        /** execute.e:4247				case NOTEQ_IFW, NOTEQ_IFW_I then*/
        case 105:
        case 122:

        /** execute.e:4248					opNOTEQ_IFW()*/
        _67opNOTEQ_IFW();
        goto L3; // [943] 1903

        /** execute.e:4250				case OPEN then*/
        case 37:

        /** execute.e:4251					opOPEN()*/
        _67opOPEN();
        goto L3; // [953] 1903

        /** execute.e:4253				case OPTION_SWITCHES then*/
        case 183:

        /** execute.e:4254					opOPTION_SWITCHES()*/
        _67opOPTION_SWITCHES();
        goto L3; // [963] 1903

        /** execute.e:4256				case OR then*/
        case 9:

        /** execute.e:4257					opOR()*/
        _67opOR();
        goto L3; // [973] 1903

        /** execute.e:4259				case OR_BITS then*/
        case 24:

        /** execute.e:4260					opOR_BITS()*/
        _67opOR_BITS();
        goto L3; // [983] 1903

        /** execute.e:4262				case PASSIGN_OP_SLICE then*/
        case 165:

        /** execute.e:4263					opPASSIGN_OP_SLICE()*/
        _67opPASSIGN_OP_SLICE();
        goto L3; // [993] 1903

        /** execute.e:4265				case PASSIGN_OP_SUBS then*/
        case 164:

        /** execute.e:4266					opPASSIGN_OP_SUBS()*/
        _67opPASSIGN_OP_SUBS();
        goto L3; // [1003] 1903

        /** execute.e:4268				case PASSIGN_SLICE then*/
        case 163:

        /** execute.e:4269					opPASSIGN_SLICE()*/
        _67opPASSIGN_SLICE();
        goto L3; // [1013] 1903

        /** execute.e:4271				case PASSIGN_SUBS then*/
        case 162:

        /** execute.e:4272					opPASSIGN_SUBS()*/
        _67opPASSIGN_SUBS();
        goto L3; // [1023] 1903

        /** execute.e:4274				case PEEK then*/
        case 127:

        /** execute.e:4275					opPEEK()*/
        _67opPEEK();
        goto L3; // [1033] 1903

        /** execute.e:4277				case PEEK_STRING then*/
        case 182:

        /** execute.e:4278					opPEEK_STRING()*/
        _67opPEEK_STRING();
        goto L3; // [1043] 1903

        /** execute.e:4280				case PEEK2S then*/
        case 179:

        /** execute.e:4281					opPEEK2S()*/
        _67opPEEK2S();
        goto L3; // [1053] 1903

        /** execute.e:4283				case PEEK2U then*/
        case 180:

        /** execute.e:4284					opPEEK2U()*/
        _67opPEEK2U();
        goto L3; // [1063] 1903

        /** execute.e:4286				case PEEK4S then*/
        case 139:

        /** execute.e:4287					opPEEK4S()*/
        _67opPEEK4S();
        goto L3; // [1073] 1903

        /** execute.e:4289				case PEEK4U then*/
        case 140:

        /** execute.e:4290					opPEEK4U()*/
        _67opPEEK4U();
        goto L3; // [1083] 1903

        /** execute.e:4292				case PEEK8S then*/
        case 213:

        /** execute.e:4293					opPEEK8S()*/
        _67opPEEK8S();
        goto L3; // [1093] 1903

        /** execute.e:4295				case PEEK8U then*/
        case 214:

        /** execute.e:4296					opPEEK8U()*/
        _67opPEEK8U();
        goto L3; // [1103] 1903

        /** execute.e:4298				case PEEKS then*/
        case 181:

        /** execute.e:4299					opPEEKS()*/
        _67opPEEKS();
        goto L3; // [1113] 1903

        /** execute.e:4301				case PLENGTH then*/
        case 160:

        /** execute.e:4302					opPLENGTH()*/
        _67opPLENGTH();
        goto L3; // [1123] 1903

        /** execute.e:4304				case PLUS, PLUS_I then*/
        case 11:
        case 115:

        /** execute.e:4305					opPLUS()*/
        _67opPLUS();
        goto L3; // [1135] 1903

        /** execute.e:4307				case PLUS1, PLUS1_I then*/
        case 93:
        case 117:

        /** execute.e:4308					opPLUS1()*/
        _67opPLUS1();
        goto L3; // [1147] 1903

        /** execute.e:4310				case POKE then*/
        case 128:

        /** execute.e:4311					opPOKE()*/
        _67opPOKE();
        goto L3; // [1157] 1903

        /** execute.e:4313				case POKE2 then*/
        case 178:

        /** execute.e:4314					opPOKE2()*/
        _67opPOKE2();
        goto L3; // [1167] 1903

        /** execute.e:4316				case POKE4 then*/
        case 138:

        /** execute.e:4317					opPOKE4()*/
        _67opPOKE4();
        goto L3; // [1177] 1903

        /** execute.e:4319				case POKE8 then*/
        case 212:

        /** execute.e:4320					opPOKE8()*/
        _67opPOKE8();
        goto L3; // [1187] 1903

        /** execute.e:4322				case POKE_POINTER then*/
        case 215:

        /** execute.e:4323					opPOKE4()*/
        _67opPOKE4();
        goto L3; // [1197] 1903

        /** execute.e:4325				case PEEK_POINTER then*/
        case 216:

        /** execute.e:4326					opPEEK4U()*/
        _67opPEEK4U();
        goto L3; // [1207] 1903

        /** execute.e:4328				case POSITION then*/
        case 60:

        /** execute.e:4329					opPOSITION()*/
        _67opPOSITION();
        goto L3; // [1217] 1903

        /** execute.e:4331				case POWER then*/
        case 72:

        /** execute.e:4332					opPOWER()*/
        _67opPOWER();
        goto L3; // [1227] 1903

        /** execute.e:4334				case PREPEND then*/
        case 57:

        /** execute.e:4335					opPREPEND()*/
        _67opPREPEND();
        goto L3; // [1237] 1903

        /** execute.e:4337				case PRINT then*/
        case 19:

        /** execute.e:4338					opPRINT()*/
        _67opPRINT();
        goto L3; // [1247] 1903

        /** execute.e:4340				case PRINTF then*/
        case 38:

        /** execute.e:4341					opPRINTF()*/
        _67opPRINTF();
        goto L3; // [1257] 1903

        /** execute.e:4343				case PROC_TAIL then*/
        case 203:

        /** execute.e:4344					opPROC_TAIL()*/
        _67opPROC_TAIL();
        goto L3; // [1267] 1903

        /** execute.e:4346				case PROC then*/
        case 27:

        /** execute.e:4347					opPROC()*/
        _67opPROC();
        goto L3; // [1277] 1903

        /** execute.e:4349				case PROFILE, DISPLAY_VAR, ERASE_PRIVATE_NAMES, ERASE_SYMBOL then*/
        case 151:
        case 87:
        case 88:
        case 90:

        /** execute.e:4350					opPROFILE()*/
        _67opPROFILE();
        goto L3; // [1293] 1903

        /** execute.e:4352				case PUTS then*/
        case 44:

        /** execute.e:4353					opPUTS()*/
        _67opPUTS();
        goto L3; // [1303] 1903

        /** execute.e:4355				case QPRINT then*/
        case 36:

        /** execute.e:4356					opQPRINT()*/
        _67opQPRINT();
        goto L3; // [1313] 1903

        /** execute.e:4358				case RAND then*/
        case 62:

        /** execute.e:4359					opRAND()*/
        _67opRAND();
        goto L3; // [1323] 1903

        /** execute.e:4361				case REMAINDER then*/
        case 71:

        /** execute.e:4362					opREMAINDER()*/
        _67opREMAINDER();
        goto L3; // [1333] 1903

        /** execute.e:4364				case REMOVE then*/
        case 200:

        /** execute.e:4365					opREMOVE()*/
        _67opREMOVE();
        goto L3; // [1343] 1903

        /** execute.e:4367				case REPEAT then*/
        case 32:

        /** execute.e:4368					opREPEAT()*/
        _67opREPEAT();
        goto L3; // [1353] 1903

        /** execute.e:4370				case REPLACE then*/
        case 201:

        /** execute.e:4371					opREPLACE()*/
        _67opREPLACE();
        goto L3; // [1363] 1903

        /** execute.e:4373				case RETURNF then*/
        case 28:

        /** execute.e:4374					opRETURNF()*/
        _67opRETURNF();
        goto L3; // [1373] 1903

        /** execute.e:4376				case RETURNP then*/
        case 29:

        /** execute.e:4377					opRETURNP()*/
        _67opRETURNP();
        goto L3; // [1383] 1903

        /** execute.e:4379				case RETURNT then*/
        case 34:

        /** execute.e:4380					opRETURNT()*/
        _67opRETURNT();
        goto L3; // [1393] 1903

        /** execute.e:4382				case RHS_SLICE then*/
        case 46:

        /** execute.e:4383					opRHS_SLICE()*/
        _67opRHS_SLICE();
        goto L3; // [1403] 1903

        /** execute.e:4385				case RHS_SUBS, RHS_SUBS_CHECK, RHS_SUBS_I then*/
        case 25:
        case 92:
        case 114:

        /** execute.e:4386					opRHS_SUBS()*/
        _67opRHS_SUBS();
        goto L3; // [1417] 1903

        /** execute.e:4388				case RIGHT_BRACE_2 then*/
        case 85:

        /** execute.e:4389					opRIGHT_BRACE_2()*/
        _67opRIGHT_BRACE_2();
        goto L3; // [1427] 1903

        /** execute.e:4391				case RIGHT_BRACE_N then*/
        case 31:

        /** execute.e:4392					opRIGHT_BRACE_N()*/
        _67opRIGHT_BRACE_N();
        goto L3; // [1437] 1903

        /** execute.e:4394				case ROUTINE_ID then*/
        case 134:

        /** execute.e:4395					opROUTINE_ID()*/
        _67opROUTINE_ID();
        goto L3; // [1447] 1903

        /** execute.e:4397				case SC1_AND then*/
        case 141:

        /** execute.e:4398					opSC1_AND()*/
        _67opSC1_AND();
        goto L3; // [1457] 1903

        /** execute.e:4400				case SC1_AND_IF then*/
        case 146:

        /** execute.e:4401					opSC1_AND_IF()*/
        _67opSC1_AND_IF();
        goto L3; // [1467] 1903

        /** execute.e:4403				case SC1_OR then*/
        case 143:

        /** execute.e:4404					opSC1_OR()*/
        _67opSC1_OR();
        goto L3; // [1477] 1903

        /** execute.e:4406				case SC1_OR_IF then*/
        case 147:

        /** execute.e:4407					opSC1_OR_IF()*/
        _67opSC1_OR_IF();
        goto L3; // [1487] 1903

        /** execute.e:4409				case SC2_OR, SC2_AND then*/
        case 144:
        case 142:

        /** execute.e:4410					opSC2_OR()*/
        _67opSC2_OR();
        goto L3; // [1499] 1903

        /** execute.e:4412				case SEQUENCE_CHECK then*/
        case 97:

        /** execute.e:4413					opSEQUENCE_CHECK()*/
        _67opSEQUENCE_CHECK();
        goto L3; // [1509] 1903

        /** execute.e:4415				case SIN then*/
        case 80:

        /** execute.e:4416					opSIN()*/
        _67opSIN();
        goto L3; // [1519] 1903

        /** execute.e:4418				case SPACE_USED then*/
        case 75:

        /** execute.e:4419					opSPACE_USED()*/
        _67opSPACE_USED();
        goto L3; // [1529] 1903

        /** execute.e:4421				case SPLICE then*/
        case 190:

        /** execute.e:4422					opSPLICE()*/
        _67opSPLICE();
        goto L3; // [1539] 1903

        /** execute.e:4424				case SPRINTF then*/
        case 53:

        /** execute.e:4425					opSPRINTF()*/
        _67opSPRINTF();
        goto L3; // [1549] 1903

        /** execute.e:4427				case SQRT then*/
        case 41:

        /** execute.e:4428					opSQRT()*/
        _67opSQRT();
        goto L3; // [1559] 1903

        /** execute.e:4430				case STARTLINE then*/
        case 58:

        /** execute.e:4431					opSTARTLINE()*/
        _67opSTARTLINE();
        goto L3; // [1569] 1903

        /** execute.e:4433				case SWITCH, SWITCH_I then*/
        case 185:
        case 193:

        /** execute.e:4434					opSWITCH()*/
        _67opSWITCH();
        goto L3; // [1581] 1903

        /** execute.e:4436				case SWITCH_SPI then*/
        case 192:

        /** execute.e:4437					opSWITCH_SPI()*/
        _67opSWITCH_SPI();
        goto L3; // [1591] 1903

        /** execute.e:4439				case SWITCH_RT then*/
        case 202:

        /** execute.e:4440					opSWITCH_RT()*/
        _67opSWITCH_RT();
        goto L3; // [1601] 1903

        /** execute.e:4442				case SYSTEM then*/
        case 99:

        /** execute.e:4443					opSYSTEM()*/
        _67opSYSTEM();
        goto L3; // [1611] 1903

        /** execute.e:4445				case SYSTEM_EXEC then*/
        case 154:

        /** execute.e:4446					opSYSTEM_EXEC()*/
        _67opSYSTEM_EXEC();
        goto L3; // [1621] 1903

        /** execute.e:4448				case TAIL then*/
        case 199:

        /** execute.e:4449					opTAIL()*/
        _67opTAIL();
        goto L3; // [1631] 1903

        /** execute.e:4451				case TAN then*/
        case 82:

        /** execute.e:4452					opTAN()*/
        _67opTAN();
        goto L3; // [1641] 1903

        /** execute.e:4454				case TASK_CLOCK_START then*/
        case 175:

        /** execute.e:4455					opTASK_CLOCK_START()*/
        _67opTASK_CLOCK_START();
        goto L3; // [1651] 1903

        /** execute.e:4457				case TASK_CLOCK_STOP then*/
        case 174:

        /** execute.e:4458					opTASK_CLOCK_STOP()*/
        _67opTASK_CLOCK_STOP();
        goto L3; // [1661] 1903

        /** execute.e:4460				case TASK_CREATE then*/
        case 167:

        /** execute.e:4461					opTASK_CREATE()*/
        _67opTASK_CREATE();
        goto L3; // [1671] 1903

        /** execute.e:4463				case TASK_LIST then*/
        case 172:

        /** execute.e:4464					opTASK_LIST()*/
        _67opTASK_LIST();
        goto L3; // [1681] 1903

        /** execute.e:4466				case TASK_SCHEDULE then*/
        case 168:

        /** execute.e:4467					opTASK_SCHEDULE()*/
        _67opTASK_SCHEDULE();
        goto L3; // [1691] 1903

        /** execute.e:4469				case TASK_SELF then*/
        case 170:

        /** execute.e:4470					opTASK_SELF()*/
        _67opTASK_SELF();
        goto L3; // [1701] 1903

        /** execute.e:4472				case TASK_STATUS then*/
        case 173:

        /** execute.e:4473					opTASK_STATUS()*/
        _67opTASK_STATUS();
        goto L3; // [1711] 1903

        /** execute.e:4475				case TASK_SUSPEND then*/
        case 171:

        /** execute.e:4476					opTASK_SUSPEND()*/
        _67opTASK_SUSPEND();
        goto L3; // [1721] 1903

        /** execute.e:4478				case TASK_YIELD then*/
        case 169:

        /** execute.e:4479					opTASK_YIELD()*/
        _67opTASK_YIELD();
        goto L3; // [1731] 1903

        /** execute.e:4481				case TIME then*/
        case 70:

        /** execute.e:4482					opTIME()*/
        _67opTIME();
        goto L3; // [1741] 1903

        /** execute.e:4484				case TRACE then*/
        case 64:

        /** execute.e:4485					opTRACE()*/
        _67opTRACE();
        goto L3; // [1751] 1903

        /** execute.e:4487				case TYPE_CHECK then*/
        case 65:

        /** execute.e:4488					opTYPE_CHECK()*/
        _67opTYPE_CHECK();
        goto L3; // [1761] 1903

        /** execute.e:4490				case UMINUS then*/
        case 12:

        /** execute.e:4491					opUMINUS()*/
        _67opUMINUS();
        goto L3; // [1771] 1903

        /** execute.e:4493				case UPDATE_GLOBALS then*/
        case 89:

        /** execute.e:4494					opUPDATE_GLOBALS()*/
        _67opUPDATE_GLOBALS();
        goto L3; // [1781] 1903

        /** execute.e:4496				case WHILE then*/
        case 47:

        /** execute.e:4497					opWHILE()*/
        _67opWHILE();
        goto L3; // [1791] 1903

        /** execute.e:4499				case XOR then*/
        case 152:

        /** execute.e:4500					opXOR()*/
        _67opXOR();
        goto L3; // [1801] 1903

        /** execute.e:4502				case XOR_BITS then*/
        case 26:

        /** execute.e:4503					opXOR_BITS()*/
        _67opXOR_BITS();
        goto L3; // [1811] 1903

        /** execute.e:4505				case DELETE_ROUTINE then*/
        case 204:

        /** execute.e:4506					opDELETE_ROUTINE()*/
        _67opDELETE_ROUTINE();
        goto L3; // [1821] 1903

        /** execute.e:4508				case DELETE_OBJECT then*/
        case 205:

        /** execute.e:4509					opDELETE_OBJECT()*/
        _67opDELETE_OBJECT();
        goto L3; // [1831] 1903

        /** execute.e:4511				case REF_TEMP then*/
        case 207:

        /** execute.e:4512					pc += 2*/
        _67pc_65330 = _67pc_65330 + 2LL;
        goto L3; // [1845] 1903

        /** execute.e:4513				case DEREF_TEMP, NOVALUE_TEMP then*/
        case 208:
        case 209:

        /** execute.e:4514					opDEREF_TEMP()*/
        _67opDEREF_TEMP();
        goto L3; // [1857] 1903

        /** execute.e:4516				case COVERAGE_LINE then*/
        case 210:

        /** execute.e:4517					opCOVERAGE_LINE()*/
        _67opCOVERAGE_LINE();
        goto L3; // [1867] 1903

        /** execute.e:4519				case COVERAGE_ROUTINE then*/
        case 211:

        /** execute.e:4520					opCOVERAGE_ROUTINE()*/
        _67opCOVERAGE_ROUTINE();
        goto L3; // [1877] 1903

        /** execute.e:4522				case SIZEOF then*/
        case 217:

        /** execute.e:4523					opSIZEOF()*/
        _67opSIZEOF();
        goto L3; // [1887] 1903

        /** execute.e:4525				case else*/
        default:

        /** execute.e:4526					RTFatal( sprintf("Unknown opcode: %d", op ) )*/
        _35374 = EPrintf(-9999999, _35373, _op_70706);
        _67RTFatal(_35374);
        _35374 = NOVALUE;
    ;}L3: 

    /** execute.e:4528		end while*/
    goto L1; // [1907] 15
L2: 

    /** execute.e:4529		keep_running = TRUE -- so higher-level do_exec() will keep running*/
    _67keep_running_65337 = _9TRUE_441;

    /** execute.e:4530	end procedure*/
    return;
    ;
}


void _67InitBackEnd()
{
    object _name_71111 = NOVALUE;
    object _len_71112 = NOVALUE;
    object _35385 = NOVALUE;
    object _35384 = NOVALUE;
    object _35383 = NOVALUE;
    object _35382 = NOVALUE;
    object _35381 = NOVALUE;
    object _35379 = NOVALUE;
    object _35378 = NOVALUE;
    object _35377 = NOVALUE;
    object _35376 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:4540		integer len = length(val)*/
    if (IS_SEQUENCE(_67val_65340)){
            _len_71112 = SEQ_PTR(_67val_65340)->length;
    }
    else {
        _len_71112 = 1;
    }

    /** execute.e:4541		val = val & repeat(0, length(SymTab)-length(val))*/
    if (IS_SEQUENCE(_28SymTab_11572)){
            _35376 = SEQ_PTR(_28SymTab_11572)->length;
    }
    else {
        _35376 = 1;
    }
    if (IS_SEQUENCE(_67val_65340)){
            _35377 = SEQ_PTR(_67val_65340)->length;
    }
    else {
        _35377 = 1;
    }
    _35378 = _35376 - _35377;
    _35376 = NOVALUE;
    _35377 = NOVALUE;
    _35379 = Repeat(0LL, _35378);
    _35378 = NOVALUE;
    Concat((object_ptr)&_67val_65340, _67val_65340, _35379);
    DeRefDS(_35379);
    _35379 = NOVALUE;

    /** execute.e:4542		for i = len + 1 to length(SymTab) do*/
    _35381 = _len_71112 + 1;
    if (IS_SEQUENCE(_28SymTab_11572)){
            _35382 = SEQ_PTR(_28SymTab_11572)->length;
    }
    else {
        _35382 = 1;
    }
    {
        object _i_71121;
        _i_71121 = _35381;
L1: 
        if (_i_71121 > _35382){
            goto L2; // [45] 94
        }

        /** execute.e:4543			val[i] = SymTab[i][S_OBJ] -- might be NOVALUE*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _35383 = (object)*(((s1_ptr)_2)->base + _i_71121);
        _2 = (object)SEQ_PTR(_35383);
        _35384 = (object)*(((s1_ptr)_2)->base + 1LL);
        _35383 = NOVALUE;
        Ref(_35384);
        _2 = (object)SEQ_PTR(_67val_65340);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_65340 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_71121);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _35384;
        if( _1 != _35384 ){
            DeRef(_1);
        }
        _35384 = NOVALUE;

        /** execute.e:4544			SymTab[i][S_OBJ] = 0*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_71121 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0LL;
        DeRef(_1);
        _35385 = NOVALUE;

        /** execute.e:4545		end for*/
        _i_71121 = _i_71121 + 1LL;
        goto L1; // [89] 52
L2: 
        ;
    }

    /** execute.e:4546	end procedure*/
    DeRef(_35381);
    _35381 = NOVALUE;
    return;
    ;
}


void _67fake_init(object _ignore_71135)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_ignore_71135)) {
        _1 = (object)(DBL_PTR(_ignore_71135)->dbl);
        DeRefDS(_ignore_71135);
        _ignore_71135 = _1;
    }

    /** execute.e:4549		intoptions()*/
    _68intoptions();

    /** execute.e:4550	end procedure*/
    return;
    ;
}


void _67Execute(object _proc_71144, object _start_index_71145)
{
    object _35394 = NOVALUE;
    object _35390 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_proc_71144)) {
        _1 = (object)(DBL_PTR(_proc_71144)->dbl);
        DeRefDS(_proc_71144);
        _proc_71144 = _1;
    }
    if (!IS_ATOM_INT(_start_index_71145)) {
        _1 = (object)(DBL_PTR(_start_index_71145)->dbl);
        DeRefDS(_start_index_71145);
        _start_index_71145 = _1;
    }

    /** execute.e:4555		InitBackEnd()*/
    _67InitBackEnd();

    /** execute.e:4556		if current_task = -1 then*/
    if (_67current_task_65347 != -1LL)
    goto L1; // [13] 23

    /** execute.e:4557		current_task = 1*/
    _67current_task_65347 = 1LL;
L1: 

    /** execute.e:4559		if not length(call_stack) then*/
    if (IS_SEQUENCE(_67call_stack_65348)){
            _35390 = SEQ_PTR(_67call_stack_65348)->length;
    }
    else {
        _35390 = 1;
    }
    if (_35390 != 0)
    goto L2; // [30] 40
    _35390 = NOVALUE;

    /** execute.e:4560		call_stack = {proc}*/
    _0 = _67call_stack_65348;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _proc_71144;
    _67call_stack_65348 = MAKE_SEQ(_1);
    DeRefDS(_0);
L2: 

    /** execute.e:4562		if pc = -1 then*/
    if (_67pc_65330 != -1LL)
    goto L3; // [44] 54

    /** execute.e:4563		pc = start_index*/
    _67pc_65330 = _start_index_71145;
L3: 

    /** execute.e:4565		Code = SymTab[proc][S_CODE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _35394 = (object)*(((s1_ptr)_2)->base + _proc_71144);
    DeRef(_27Code_20660);
    _2 = (object)SEQ_PTR(_35394);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    Ref(_27Code_20660);
    _35394 = NOVALUE;

    /** execute.e:4566		do_exec()*/
    _67do_exec();

    /** execute.e:4567		if repl then*/

    /** execute.e:4570	end procedure*/
    return;
    ;
}


void _67BackEnd(object _ignore_71167)
{
    object _0, _1, _2;
    

    /** execute.e:4577		Execute(TopLevelSub, 1)*/
    _67Execute(_27TopLevelSub_20578, 1LL);

    /** execute.e:4578	end procedure*/
    return;
    ;
}



// 0xE04C1CE6
