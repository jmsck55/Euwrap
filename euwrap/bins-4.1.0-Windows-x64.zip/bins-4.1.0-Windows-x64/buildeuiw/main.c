// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _69GetSourceName()
{
    object _real_name_72748 = NOVALUE;
    object _fh_72749 = NOVALUE;
    object _has_extension_72751 = NOVALUE;
    object _36362 = NOVALUE;
    object _36360 = NOVALUE;
    object _36359 = NOVALUE;
    object _36356 = NOVALUE;
    object _36355 = NOVALUE;
    object _36354 = NOVALUE;
    object _36353 = NOVALUE;
    object _36352 = NOVALUE;
    object _36351 = NOVALUE;
    object _36348 = NOVALUE;
    object _36347 = NOVALUE;
    object _36345 = NOVALUE;
    object _36344 = NOVALUE;
    object _36343 = NOVALUE;
    object _36342 = NOVALUE;
    object _36341 = NOVALUE;
    object _36340 = NOVALUE;
    object _36337 = NOVALUE;
    object _36336 = NOVALUE;
    object _36334 = NOVALUE;
    object _36333 = NOVALUE;
    object _36329 = NOVALUE;
    object _36328 = NOVALUE;
    object _36325 = NOVALUE;
    object _36324 = NOVALUE;
    object _36323 = NOVALUE;
    object _36321 = NOVALUE;
    object _36320 = NOVALUE;
    object _36319 = NOVALUE;
    object _36318 = NOVALUE;
    object _36317 = NOVALUE;
    object _36316 = NOVALUE;
    object _36315 = NOVALUE;
    object _0, _1, _2;
    

    /** main.e:48		boolean has_extension = FALSE*/
    _has_extension_72751 = _9FALSE_439;

    /** main.e:50		if length(src_name) = 0 and not repl then*/
    if (IS_SEQUENCE(_47src_name_50053)){
            _36315 = SEQ_PTR(_47src_name_50053)->length;
    }
    else {
        _36315 = 1;
    }
    _36316 = (_36315 == 0LL);
    _36315 = NOVALUE;
    if (_36316 == 0) {
        goto L1; // [19] 45
    }
    _36318 = (0LL == 0);
    if (_36318 == 0)
    {
        DeRef(_36318);
        _36318 = NOVALUE;
        goto L1; // [29] 45
    }
    else{
        DeRef(_36318);
        _36318 = NOVALUE;
    }

    /** main.e:51			show_banner()*/
    _47show_banner();

    /** main.e:52			return -2 -- No source file*/
    DeRef(_real_name_72748);
    DeRef(_36316);
    _36316 = NOVALUE;
    return -2LL;
    goto L2; // [42] 143
L1: 

    /** main.e:53		elsif length(src_name) = 0 and repl then*/
    if (IS_SEQUENCE(_47src_name_50053)){
            _36319 = SEQ_PTR(_47src_name_50053)->length;
    }
    else {
        _36319 = 1;
    }
    _36320 = (_36319 == 0LL);
    _36319 = NOVALUE;
    if (_36320 == 0) {
        goto L3; // [56] 142
    }
    goto L3; // [63] 142

    /** main.e:54			known_files = append(known_files, "")*/
    RefDS(_22218);
    Append(&_28known_files_11573, _28known_files_11573, _22218);

    /** main.e:55			known_files_hash &= hash(known_files[$], stdhash:HSIEH32)*/
    if (IS_SEQUENCE(_28known_files_11573)){
            _36323 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _36323 = 1;
    }
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _36324 = (object)*(((s1_ptr)_2)->base + _36323);
    _36325 = calc_hash(_36324, -5LL);
    _36324 = NOVALUE;
    Ref(_36325);
    Append(&_28known_files_hash_11574, _28known_files_hash_11574, _36325);
    DeRef(_36325);
    _36325 = NOVALUE;

    /** main.e:56			real_name = ""*/
    RefDS(_22218);
    DeRef(_real_name_72748);
    _real_name_72748 = _22218;

    /** main.e:57			finished_files &= 0*/
    Append(&_28finished_files_11575, _28finished_files_11575, 0LL);

    /** main.e:58			file_include_depend = append( file_include_depend, { length( known_files ) } )*/
    if (IS_SEQUENCE(_28known_files_11573)){
            _36328 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _36328 = 1;
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _36328;
    _36329 = MAKE_SEQ(_1);
    _36328 = NOVALUE;
    RefDS(_36329);
    Append(&_28file_include_depend_11576, _28file_include_depend_11576, _36329);
    DeRefDS(_36329);
    _36329 = NOVALUE;

    /** main.e:59			return repl_file*/
    DeRefDS(_real_name_72748);
    DeRef(_36316);
    _36316 = NOVALUE;
    DeRef(_36320);
    _36320 = NOVALUE;
    return 5555LL;
L3: 
L2: 

    /** main.e:62		ifdef WINDOWS then*/

    /** main.e:63			src_name = match_replace("/", src_name, "\\")*/
    RefDS(_23818);
    RefDS(_47src_name_50053);
    RefDS(_36331);
    _0 = _14match_replace(_23818, _47src_name_50053, _36331, 0LL);
    DeRefDS(_47src_name_50053);
    _47src_name_50053 = _0;

    /** main.e:66		for p = length(src_name) to 1 by -1 do*/
    if (IS_SEQUENCE(_47src_name_50053)){
            _36333 = SEQ_PTR(_47src_name_50053)->length;
    }
    else {
        _36333 = 1;
    }
    {
        object _p_72791;
        _p_72791 = _36333;
L4: 
        if (_p_72791 < 1LL){
            goto L5; // [165] 229
        }

        /** main.e:67			if src_name[p] = '.' then*/
        _2 = (object)SEQ_PTR(_47src_name_50053);
        _36334 = (object)*(((s1_ptr)_2)->base + _p_72791);
        if (binary_op_a(NOTEQ, _36334, 46LL)){
            _36334 = NOVALUE;
            goto L6; // [180] 198
        }
        _36334 = NOVALUE;

        /** main.e:68			   has_extension = TRUE*/
        _has_extension_72751 = _9TRUE_441;

        /** main.e:69			   exit*/
        goto L5; // [193] 229
        goto L7; // [195] 222
L6: 

        /** main.e:70			elsif find(src_name[p], SLASH_CHARS) then*/
        _2 = (object)SEQ_PTR(_47src_name_50053);
        _36336 = (object)*(((s1_ptr)_2)->base + _p_72791);
        _36337 = find_from(_36336, _44SLASH_CHARS_20736, 1LL);
        _36336 = NOVALUE;
        if (_36337 == 0)
        {
            _36337 = NOVALUE;
            goto L8; // [213] 221
        }
        else{
            _36337 = NOVALUE;
        }

        /** main.e:71			   exit*/
        goto L5; // [218] 229
L8: 
L7: 

        /** main.e:73		end for*/
        _p_72791 = _p_72791 + -1LL;
        goto L4; // [224] 172
L5: 
        ;
    }

    /** main.e:75		if not has_extension then*/
    if (_has_extension_72751 != 0)
    goto L9; // [231] 336

    /** main.e:79			known_files = append(known_files, "")*/
    RefDS(_22218);
    Append(&_28known_files_11573, _28known_files_11573, _22218);

    /** main.e:82			for i = 1 to length( DEFAULT_EXTS ) do*/
    _36340 = 4;
    {
        object _i_72810;
        _i_72810 = 1LL;
LA: 
        if (_i_72810 > 4LL){
            goto LB; // [251] 316
        }

        /** main.e:83				known_files[$] = src_name & DEFAULT_EXTS[i]*/
        if (IS_SEQUENCE(_28known_files_11573)){
                _36341 = SEQ_PTR(_28known_files_11573)->length;
        }
        else {
            _36341 = 1;
        }
        _2 = (object)SEQ_PTR(_44DEFAULT_EXTS_20710);
        _36342 = (object)*(((s1_ptr)_2)->base + _i_72810);
        Concat((object_ptr)&_36343, _47src_name_50053, _36342);
        _36342 = NOVALUE;
        _2 = (object)SEQ_PTR(_28known_files_11573);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28known_files_11573 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _36341);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _36343;
        if( _1 != _36343 ){
            DeRef(_1);
        }
        _36343 = NOVALUE;

        /** main.e:84				real_name = e_path_find(known_files[$])*/
        if (IS_SEQUENCE(_28known_files_11573)){
                _36344 = SEQ_PTR(_28known_files_11573)->length;
        }
        else {
            _36344 = 1;
        }
        _2 = (object)SEQ_PTR(_28known_files_11573);
        _36345 = (object)*(((s1_ptr)_2)->base + _36344);
        Ref(_36345);
        _0 = _real_name_72748;
        _real_name_72748 = _46e_path_find(_36345);
        DeRef(_0);
        _36345 = NOVALUE;

        /** main.e:85				if sequence(real_name) then*/
        _36347 = IS_SEQUENCE(_real_name_72748);
        if (_36347 == 0)
        {
            _36347 = NOVALUE;
            goto LC; // [301] 309
        }
        else{
            _36347 = NOVALUE;
        }

        /** main.e:86					exit*/
        goto LB; // [306] 316
LC: 

        /** main.e:88			end for*/
        _i_72810 = _i_72810 + 1LL;
        goto LA; // [311] 258
LB: 
        ;
    }

    /** main.e:90			if atom(real_name) then*/
    _36348 = IS_ATOM(_real_name_72748);
    if (_36348 == 0)
    {
        _36348 = NOVALUE;
        goto LD; // [323] 372
    }
    else{
        _36348 = NOVALUE;
    }

    /** main.e:91				return -1*/
    DeRef(_real_name_72748);
    DeRef(_36316);
    _36316 = NOVALUE;
    DeRef(_36320);
    _36320 = NOVALUE;
    return -1LL;
    goto LD; // [333] 372
L9: 

    /** main.e:94			known_files = append(known_files, src_name)*/
    RefDS(_47src_name_50053);
    Append(&_28known_files_11573, _28known_files_11573, _47src_name_50053);

    /** main.e:95			real_name = e_path_find(src_name)*/
    RefDS(_47src_name_50053);
    _0 = _real_name_72748;
    _real_name_72748 = _46e_path_find(_47src_name_50053);
    DeRef(_0);

    /** main.e:96			if atom(real_name) then*/
    _36351 = IS_ATOM(_real_name_72748);
    if (_36351 == 0)
    {
        _36351 = NOVALUE;
        goto LE; // [361] 371
    }
    else{
        _36351 = NOVALUE;
    }

    /** main.e:97				return -1*/
    DeRef(_real_name_72748);
    DeRef(_36316);
    _36316 = NOVALUE;
    DeRef(_36320);
    _36320 = NOVALUE;
    return -1LL;
LE: 
LD: 

    /** main.e:100		known_files[$] = canonical_path(real_name,,CORRECT)*/
    if (IS_SEQUENCE(_28known_files_11573)){
            _36352 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _36352 = 1;
    }
    Ref(_real_name_72748);
    _36353 = _15canonical_path(_real_name_72748, 0LL, 2LL);
    _2 = (object)SEQ_PTR(_28known_files_11573);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28known_files_11573 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _36352);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36353;
    if( _1 != _36353 ){
        DeRef(_1);
    }
    _36353 = NOVALUE;

    /** main.e:101		known_files_hash &= hash(known_files[$], stdhash:HSIEH32)*/
    if (IS_SEQUENCE(_28known_files_11573)){
            _36354 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _36354 = 1;
    }
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _36355 = (object)*(((s1_ptr)_2)->base + _36354);
    _36356 = calc_hash(_36355, -5LL);
    _36355 = NOVALUE;
    Ref(_36356);
    Append(&_28known_files_hash_11574, _28known_files_hash_11574, _36356);
    DeRef(_36356);
    _36356 = NOVALUE;

    /** main.e:102		finished_files &= 0*/
    Append(&_28finished_files_11575, _28finished_files_11575, 0LL);

    /** main.e:103		file_include_depend = append( file_include_depend, { length( known_files ) } )*/
    if (IS_SEQUENCE(_28known_files_11573)){
            _36359 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _36359 = 1;
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _36359;
    _36360 = MAKE_SEQ(_1);
    _36359 = NOVALUE;
    RefDS(_36360);
    Append(&_28file_include_depend_11576, _28file_include_depend_11576, _36360);
    DeRefDS(_36360);
    _36360 = NOVALUE;

    /** main.e:105		if file_exists(real_name) then*/
    Ref(_real_name_72748);
    _36362 = _15file_exists(_real_name_72748);
    if (_36362 == 0) {
        DeRef(_36362);
        _36362 = NOVALUE;
        goto LF; // [451] 475
    }
    else {
        if (!IS_ATOM_INT(_36362) && DBL_PTR(_36362)->dbl == 0.0){
            DeRef(_36362);
            _36362 = NOVALUE;
            goto LF; // [451] 475
        }
        DeRef(_36362);
        _36362 = NOVALUE;
    }
    DeRef(_36362);
    _36362 = NOVALUE;

    /** main.e:106			real_name = maybe_preprocess(real_name)*/
    Ref(_real_name_72748);
    _0 = _real_name_72748;
    _real_name_72748 = _63maybe_preprocess(_real_name_72748);
    DeRef(_0);

    /** main.e:107			fh = open_locked(real_name)*/
    Ref(_real_name_72748);
    _fh_72749 = _28open_locked(_real_name_72748);
    if (!IS_ATOM_INT(_fh_72749)) {
        _1 = (object)(DBL_PTR(_fh_72749)->dbl);
        DeRefDS(_fh_72749);
        _fh_72749 = _1;
    }

    /** main.e:108			return fh*/
    DeRef(_real_name_72748);
    DeRef(_36316);
    _36316 = NOVALUE;
    DeRef(_36320);
    _36320 = NOVALUE;
    return _fh_72749;
LF: 

    /** main.e:111		return -1*/
    DeRef(_real_name_72748);
    DeRef(_36316);
    _36316 = NOVALUE;
    DeRef(_36320);
    _36320 = NOVALUE;
    return -1LL;
    ;
}


void _69main()
{
    object _argc_72879 = NOVALUE;
    object _argv_72880 = NOVALUE;
    object _36392 = NOVALUE;
    object _36391 = NOVALUE;
    object _36388 = NOVALUE;
    object _36386 = NOVALUE;
    object _36384 = NOVALUE;
    object _36383 = NOVALUE;
    object _36382 = NOVALUE;
    object _36381 = NOVALUE;
    object _36380 = NOVALUE;
    object _36379 = NOVALUE;
    object _36378 = NOVALUE;
    object _36377 = NOVALUE;
    object _36373 = NOVALUE;
    object _0, _1, _2;
    

    /** main.e:131		argv = command_line()*/
    DeRef(_argv_72880);
    _argv_72880 = Command_Line();

    /** main.e:133		if BIND then*/
    if (_27BIND_20182 == 0)
    {
        goto L1; // [9] 21
    }
    else{
    }

    /** main.e:134			argv = extract_options(argv)*/
    RefDS(_argv_72880);
    _0 = _argv_72880;
    _argv_72880 = _2extract_options(_argv_72880);
    DeRefDS(_0);
L1: 

    /** main.e:137		argc = length(argv)*/
    if (IS_SEQUENCE(_argv_72880)){
            _argc_72879 = SEQ_PTR(_argv_72880)->length;
    }
    else {
        _argc_72879 = 1;
    }

    /** main.e:139		Argv = argv*/
    RefDS(_argv_72880);
    DeRef(_27Argv_20582);
    _27Argv_20582 = _argv_72880;

    /** main.e:140		Argc = argc*/
    _27Argc_20581 = _argc_72879;

    /** main.e:142		TempErrName = "ex.err"*/
    RefDS(_32173);
    DeRefi(_49TempErrName_49691);
    _49TempErrName_49691 = _32173;

    /** main.e:143		TempWarningName = STDERR*/
    DeRef(_27TempWarningName_20585);
    _27TempWarningName_20585 = 2LL;

    /** main.e:144		display_warnings = 1*/
    _49display_warnings_49692 = 1LL;

    /** main.e:146		InitGlobals()*/
    _43InitGlobals();

    /** main.e:148		if TRANSLATE or BIND or INTERPRET then*/
    if (_27TRANSLATE_20179 != 0) {
        _36373 = 1;
        goto L2; // [69] 79
    }
    _36373 = (_27BIND_20182 != 0);
L2: 
    if (_36373 != 0) {
        goto L3; // [79] 90
    }
    if (_27INTERPRET_20176 == 0)
    {
        goto L4; // [86] 96
    }
    else{
    }
L3: 

    /** main.e:149			InitBackEnd(0)*/
    _2InitBackEnd(0LL);
L4: 

    /** main.e:152		src_file = GetSourceName()*/
    _0 = _69GetSourceName();
    _27src_file_20693 = _0;
    if (!IS_ATOM_INT(_27src_file_20693)) {
        _1 = (object)(DBL_PTR(_27src_file_20693)->dbl);
        DeRefDS(_27src_file_20693);
        _27src_file_20693 = _1;
    }

    /** main.e:154		if src_file = -1 then*/
    if (_27src_file_20693 != -1LL)
    goto L5; // [107] 185

    /** main.e:156			screen_output(STDERR, GetMsgText(CANT_OPEN_1, 0, {known_files[$]}))*/
    if (IS_SEQUENCE(_28known_files_11573)){
            _36377 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _36377 = 1;
    }
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _36378 = (object)*(((s1_ptr)_2)->base + _36377);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_36378);
    ((intptr_t*)_2)[1] = _36378;
    _36379 = MAKE_SEQ(_1);
    _36378 = NOVALUE;
    _36380 = _30GetMsgText(51LL, 0LL, _36379);
    _36379 = NOVALUE;
    _49screen_output(2LL, _36380);
    _36380 = NOVALUE;

    /** main.e:157			if not batch_job and not test_only then*/
    _36381 = (_27batch_job_20584 == 0);
    if (_36381 == 0) {
        goto L6; // [147] 177
    }
    _36383 = (_27test_only_20583 == 0);
    if (_36383 == 0)
    {
        DeRef(_36383);
        _36383 = NOVALUE;
        goto L6; // [157] 177
    }
    else{
        DeRef(_36383);
        _36383 = NOVALUE;
    }

    /** main.e:158				maybe_any_key(GetMsgText(PAUSED_PRESS_ANY_KEY,0), STDERR)*/
    RefDS(_22218);
    _36384 = _30GetMsgText(277LL, 0LL, _22218);
    _38maybe_any_key(_36384, 2LL);
    _36384 = NOVALUE;
L6: 

    /** main.e:160			Cleanup(1)*/
    _49Cleanup(1LL);
    goto L7; // [182] 230
L5: 

    /** main.e:162		elsif src_file >= 0 then*/
    if (_27src_file_20693 < 0LL)
    goto L8; // [189] 229

    /** main.e:163			main_path = known_files[$]*/
    if (IS_SEQUENCE(_28known_files_11573)){
            _36386 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _36386 = 1;
    }
    DeRef(_27main_path_20692);
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _27main_path_20692 = (object)*(((s1_ptr)_2)->base + _36386);
    Ref(_27main_path_20692);

    /** main.e:164			if length(main_path) = 0 then*/
    if (IS_SEQUENCE(_27main_path_20692)){
            _36388 = SEQ_PTR(_27main_path_20692)->length;
    }
    else {
        _36388 = 1;
    }
    if (_36388 != 0LL)
    goto L9; // [213] 228

    /** main.e:165				main_path = '.' & SLASH*/
    Concat((object_ptr)&_27main_path_20692, 46LL, 92LL);
L9: 
L8: 
L7: 

    /** main.e:171		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto LA; // [234] 243
    }
    else{
    }

    /** main.e:172			InitBackEnd(1)*/
    _2InitBackEnd(1LL);
LA: 

    /** main.e:175		CheckPlatform()*/
    _2CheckPlatform();

    /** main.e:177		InitSymTab()*/
    _53InitSymTab();

    /** main.e:178		InitEmit()*/
    _45InitEmit();

    /** main.e:179		InitLex()*/
    _61InitLex();

    /** main.e:180		InitParser()*/
    _43InitParser();

    /** main.e:184		eu_namespace()*/
    _61eu_namespace();

    /** main.e:186		ifdef TRANSLATOR then*/

    /** main.e:197		main_file()*/
    _61main_file();

    /** main.e:199		check_coverage()*/
    _50check_coverage();

    /** main.e:201		parser()*/
    _43parser();

    /** main.e:203		init_coverage()*/
    _50init_coverage();

    /** main.e:206		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto LB; // [289] 300
    }
    else{
    }

    /** main.e:207			BackEnd(0) -- translate IL to C*/
    _2BackEnd(0LL);
    goto LC; // [297] 387
LB: 

    /** main.e:209		elsif BIND then*/
    if (_27BIND_20182 == 0)
    {
        goto LD; // [304] 314
    }
    else{
    }

    /** main.e:210			OutputIL()*/
    _2OutputIL();
    goto LC; // [311] 387
LD: 

    /** main.e:212		elsif INTERPRET and not test_only then*/
    if (_27INTERPRET_20176 == 0) {
        goto LE; // [318] 386
    }
    _36392 = (_27test_only_20583 == 0);
    if (_36392 == 0)
    {
        DeRef(_36392);
        _36392 = NOVALUE;
        goto LE; // [328] 386
    }
    else{
        DeRef(_36392);
        _36392 = NOVALUE;
    }

    /** main.e:213			ifdef not STDDEBUG then*/

    /** main.e:214				BackEnd(0) -- execute IL using Euphoria-coded back-end*/
    _2BackEnd(0LL);

    /** main.e:216			while repl do*/
LE: 
LC: 

    /** main.e:225		Cleanup(0) -- does warnings*/
    _49Cleanup(0LL);

    /** main.e:226	end procedure*/
    DeRef(_argv_72880);
    DeRef(_36381);
    _36381 = NOVALUE;
    return;
    ;
}



// 0x75FD6798
