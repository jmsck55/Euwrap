// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _50check_coverage()
{
    object _25386 = NOVALUE;
    object _25385 = NOVALUE;
    object _25384 = NOVALUE;
    object _25383 = NOVALUE;
    object _25382 = NOVALUE;
    object _25381 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:45		for i = length( file_coverage ) + 1 to length( known_files ) do*/
    if (IS_SEQUENCE(_50file_coverage_49277)){
            _25381 = SEQ_PTR(_50file_coverage_49277)->length;
    }
    else {
        _25381 = 1;
    }
    _25382 = _25381 + 1;
    _25381 = NOVALUE;
    if (IS_SEQUENCE(_28known_files_11573)){
            _25383 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _25383 = 1;
    }
    {
        object _i_49288;
        _i_49288 = _25382;
L1: 
        if (_i_49288 > _25383){
            goto L2; // [17] 58
        }

        /** coverage.e:46			file_coverage &= find( canonical_path( known_files[i],,1 ), covered_files )*/
        _2 = (object)SEQ_PTR(_28known_files_11573);
        _25384 = (object)*(((s1_ptr)_2)->base + _i_49288);
        Ref(_25384);
        _25385 = _15canonical_path(_25384, 0LL, 1LL);
        _25384 = NOVALUE;
        _25386 = find_from(_25385, _50covered_files_49276, 1LL);
        DeRef(_25385);
        _25385 = NOVALUE;
        Append(&_50file_coverage_49277, _50file_coverage_49277, _25386);
        _25386 = NOVALUE;

        /** coverage.e:47		end for*/
        _i_49288 = _i_49288 + 1LL;
        goto L1; // [53] 24
L2: 
        ;
    }

    /** coverage.e:48	end procedure*/
    DeRef(_25382);
    _25382 = NOVALUE;
    return;
    ;
}


void _50init_coverage()
{
    object _cmd_49312 = NOVALUE;
    object _25404 = NOVALUE;
    object _25403 = NOVALUE;
    object _25401 = NOVALUE;
    object _25400 = NOVALUE;
    object _25399 = NOVALUE;
    object _25397 = NOVALUE;
    object _25395 = NOVALUE;
    object _25394 = NOVALUE;
    object _25392 = NOVALUE;
    object _25391 = NOVALUE;
    object _25390 = NOVALUE;
    object _25389 = NOVALUE;
    object _25388 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:54		if initialized_coverage then*/
    if (_50initialized_coverage_49284 == 0)
    {
        goto L1; // [5] 14
    }
    else{
    }

    /** coverage.e:55			return*/
    return;
L1: 

    /** coverage.e:57		initialized_coverage = 1*/
    _50initialized_coverage_49284 = 1LL;

    /** coverage.e:58		for i = 1 to length( file_coverage ) do*/
    if (IS_SEQUENCE(_50file_coverage_49277)){
            _25388 = SEQ_PTR(_50file_coverage_49277)->length;
    }
    else {
        _25388 = 1;
    }
    {
        object _i_49303;
        _i_49303 = 1LL;
L2: 
        if (_i_49303 > _25388){
            goto L3; // [26] 67
        }

        /** coverage.e:59			file_coverage[i] = find( canonical_path( known_files[i],,1 ), covered_files )*/
        _2 = (object)SEQ_PTR(_28known_files_11573);
        _25389 = (object)*(((s1_ptr)_2)->base + _i_49303);
        Ref(_25389);
        _25390 = _15canonical_path(_25389, 0LL, 1LL);
        _25389 = NOVALUE;
        _25391 = find_from(_25390, _50covered_files_49276, 1LL);
        DeRef(_25390);
        _25390 = NOVALUE;
        _2 = (object)SEQ_PTR(_50file_coverage_49277);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _50file_coverage_49277 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_49303);
        *(intptr_t *)_2 = _25391;
        if( _1 != _25391 ){
        }
        _25391 = NOVALUE;

        /** coverage.e:60		end for*/
        _i_49303 = _i_49303 + 1LL;
        goto L2; // [62] 33
L3: 
        ;
    }

    /** coverage.e:62		if equal( coverage_db_name, "" ) then*/
    if (_50coverage_db_name_49278 == _22218)
    _25392 = 1;
    else if (IS_ATOM_INT(_50coverage_db_name_49278) && IS_ATOM_INT(_22218))
    _25392 = 0;
    else
    _25392 = (compare(_50coverage_db_name_49278, _22218) == 0);
    if (_25392 == 0)
    {
        _25392 = NOVALUE;
        goto L4; // [75] 105
    }
    else{
        _25392 = NOVALUE;
    }

    /** coverage.e:63			sequence cmd = command_line()*/
    DeRef(_cmd_49312);
    _cmd_49312 = Command_Line();

    /** coverage.e:64			coverage_db_name = canonical_path( filebase( cmd[2] ) & "-cvg.edb" )*/
    _2 = (object)SEQ_PTR(_cmd_49312);
    _25394 = (object)*(((s1_ptr)_2)->base + 2LL);
    RefDS(_25394);
    _25395 = _15filebase(_25394);
    _25394 = NOVALUE;
    if (IS_SEQUENCE(_25395) && IS_ATOM(_25396)) {
    }
    else if (IS_ATOM(_25395) && IS_SEQUENCE(_25396)) {
        Ref(_25395);
        Prepend(&_25397, _25396, _25395);
    }
    else {
        Concat((object_ptr)&_25397, _25395, _25396);
        DeRef(_25395);
        _25395 = NOVALUE;
    }
    DeRef(_25395);
    _25395 = NOVALUE;
    _0 = _15canonical_path(_25397, 0LL, 0LL);
    DeRefDS(_50coverage_db_name_49278);
    _50coverage_db_name_49278 = _0;
    _25397 = NOVALUE;
L4: 
    DeRef(_cmd_49312);
    _cmd_49312 = NOVALUE;

    /** coverage.e:67		if coverage_erase and file_exists( coverage_db_name ) then*/
    if (_50coverage_erase_49279 == 0) {
        goto L5; // [111] 153
    }
    RefDS(_50coverage_db_name_49278);
    _25400 = _15file_exists(_50coverage_db_name_49278);
    if (_25400 == 0) {
        DeRef(_25400);
        _25400 = NOVALUE;
        goto L5; // [122] 153
    }
    else {
        if (!IS_ATOM_INT(_25400) && DBL_PTR(_25400)->dbl == 0.0){
            DeRef(_25400);
            _25400 = NOVALUE;
            goto L5; // [122] 153
        }
        DeRef(_25400);
        _25400 = NOVALUE;
    }
    DeRef(_25400);
    _25400 = NOVALUE;

    /** coverage.e:68			if not delete_file( coverage_db_name ) then*/
    RefDS(_50coverage_db_name_49278);
    _25401 = _15delete_file(_50coverage_db_name_49278);
    if (IS_ATOM_INT(_25401)) {
        if (_25401 != 0){
            DeRef(_25401);
            _25401 = NOVALUE;
            goto L6; // [133] 152
        }
    }
    else {
        if (DBL_PTR(_25401)->dbl != 0.0){
            DeRef(_25401);
            _25401 = NOVALUE;
            goto L6; // [133] 152
        }
    }
    DeRef(_25401);
    _25401 = NOVALUE;

    /** coverage.e:69				CompileErr( COULD_NOT_ERASE_COVERAGE_DATABASE_1, { coverage_db_name } )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_50coverage_db_name_49278);
    ((intptr_t*)_2)[1] = _50coverage_db_name_49278;
    _25403 = MAKE_SEQ(_1);
    _49CompileErr(335LL, _25403, 0LL);
    _25403 = NOVALUE;
L6: 
L5: 

    /** coverage.e:73		if db_open( coverage_db_name ) = DB_OK then*/
    RefDS(_50coverage_db_name_49278);
    _25404 = _41db_open(_50coverage_db_name_49278, 0LL);
    if (binary_op_a(NOTEQ, _25404, 0LL)){
        DeRef(_25404);
        _25404 = NOVALUE;
        goto L7; // [164] 177
    }
    DeRef(_25404);
    _25404 = NOVALUE;

    /** coverage.e:74			read_coverage_db()*/
    _50read_coverage_db();

    /** coverage.e:75			db_close()*/
    _41db_close();
L7: 

    /** coverage.e:77	end procedure*/
    return;
    ;
}


void _50write_map(object _coverage_49342, object _table_name_49343)
{
    object _keys_49367 = NOVALUE;
    object _rec_49372 = NOVALUE;
    object _val_49376 = NOVALUE;
    object _32064 = NOVALUE;
    object _25421 = NOVALUE;
    object _25418 = NOVALUE;
    object _25416 = NOVALUE;
    object _25415 = NOVALUE;
    object _25413 = NOVALUE;
    object _25412 = NOVALUE;
    object _25410 = NOVALUE;
    object _25408 = NOVALUE;
    object _25406 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:80		if db_select( coverage_db_name, DB_LOCK_EXCLUSIVE) = DB_OK then*/
    RefDS(_50coverage_db_name_49278);
    _25406 = _41db_select(_50coverage_db_name_49278, 2LL);
    if (binary_op_a(NOTEQ, _25406, 0LL)){
        DeRef(_25406);
        _25406 = NOVALUE;
        goto L1; // [16] 63
    }
    DeRef(_25406);
    _25406 = NOVALUE;

    /** coverage.e:81			if db_select_table( table_name ) != DB_OK then*/
    RefDS(_table_name_49343);
    _25408 = _41db_select_table(_table_name_49343);
    if (binary_op_a(EQUALS, _25408, 0LL)){
        DeRef(_25408);
        _25408 = NOVALUE;
        goto L2; // [28] 77
    }
    DeRef(_25408);
    _25408 = NOVALUE;

    /** coverage.e:82				if db_create_table( table_name ) != DB_OK then*/
    RefDS(_table_name_49343);
    _25410 = _41db_create_table(_table_name_49343, 50LL);
    if (binary_op_a(EQUALS, _25410, 0LL)){
        DeRef(_25410);
        _25410 = NOVALUE;
        goto L2; // [41] 77
    }
    DeRef(_25410);
    _25410 = NOVALUE;

    /** coverage.e:83					CompileErr( COULD_NOT_CREATE_COVERAGE_TABLE_1, {table_name} )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_table_name_49343);
    ((intptr_t*)_2)[1] = _table_name_49343;
    _25412 = MAKE_SEQ(_1);
    _49CompileErr(336LL, _25412, 0LL);
    _25412 = NOVALUE;
    goto L2; // [60] 77
L1: 

    /** coverage.e:87			CompileErr( COULD_NOT_CREATE_COVERAGE_TABLE_1, {table_name} )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_table_name_49343);
    ((intptr_t*)_2)[1] = _table_name_49343;
    _25413 = MAKE_SEQ(_1);
    _49CompileErr(336LL, _25413, 0LL);
    _25413 = NOVALUE;
L2: 

    /** coverage.e:90		sequence keys = map:keys( coverage )*/
    Ref(_coverage_49342);
    _0 = _keys_49367;
    _keys_49367 = _34keys(_coverage_49342, 0LL);
    DeRef(_0);

    /** coverage.e:91		for i = 1 to length( keys ) do*/
    if (IS_SEQUENCE(_keys_49367)){
            _25415 = SEQ_PTR(_keys_49367)->length;
    }
    else {
        _25415 = 1;
    }
    {
        object _i_49370;
        _i_49370 = 1LL;
L3: 
        if (_i_49370 > _25415){
            goto L4; // [91] 171
        }

        /** coverage.e:92			integer rec = db_find_key( keys[i] )*/
        _2 = (object)SEQ_PTR(_keys_49367);
        _25416 = (object)*(((s1_ptr)_2)->base + _i_49370);
        Ref(_25416);
        RefDS(_41current_table_name_16042);
        _rec_49372 = _41db_find_key(_25416, _41current_table_name_16042);
        _25416 = NOVALUE;
        if (!IS_ATOM_INT(_rec_49372)) {
            _1 = (object)(DBL_PTR(_rec_49372)->dbl);
            DeRefDS(_rec_49372);
            _rec_49372 = _1;
        }

        /** coverage.e:93			integer val = map:get( coverage, keys[i] )*/
        _2 = (object)SEQ_PTR(_keys_49367);
        _25418 = (object)*(((s1_ptr)_2)->base + _i_49370);
        Ref(_coverage_49342);
        Ref(_25418);
        _val_49376 = _34get(_coverage_49342, _25418, 0LL);
        _25418 = NOVALUE;
        if (!IS_ATOM_INT(_val_49376)) {
            _1 = (object)(DBL_PTR(_val_49376)->dbl);
            DeRefDS(_val_49376);
            _val_49376 = _1;
        }

        /** coverage.e:94			if rec > 0 then*/
        if (_rec_49372 <= 0LL)
        goto L5; // [129] 145

        /** coverage.e:95				db_replace_data( rec, val )*/
        RefDS(_41current_table_name_16042);
        _41db_replace_data(_rec_49372, _val_49376, _41current_table_name_16042);
        goto L6; // [142] 162
L5: 

        /** coverage.e:97				db_insert( keys[i], val )*/
        _2 = (object)SEQ_PTR(_keys_49367);
        _25421 = (object)*(((s1_ptr)_2)->base + _i_49370);
        Ref(_25421);
        RefDS(_41current_table_name_16042);
        _32064 = _41db_insert(_25421, _val_49376, _41current_table_name_16042);
        _25421 = NOVALUE;
        DeRef(_32064);
        _32064 = NOVALUE;
L6: 

        /** coverage.e:99		end for*/
        _i_49370 = _i_49370 + 1LL;
        goto L3; // [166] 98
L4: 
        ;
    }

    /** coverage.e:101	end procedure*/
    DeRef(_coverage_49342);
    DeRefDS(_table_name_49343);
    DeRef(_keys_49367);
    return;
    ;
}


object _50write_coverage_db()
{
    object _25438 = NOVALUE;
    object _25437 = NOVALUE;
    object _25435 = NOVALUE;
    object _25434 = NOVALUE;
    object _25433 = NOVALUE;
    object _25431 = NOVALUE;
    object _25430 = NOVALUE;
    object _25429 = NOVALUE;
    object _25426 = NOVALUE;
    object _25424 = NOVALUE;
    object _25422 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:105		if wrote_coverage then*/
    if (_50wrote_coverage_49385 == 0)
    {
        goto L1; // [5] 15
    }
    else{
    }

    /** coverage.e:106			return 1*/
    return 1LL;
L1: 

    /** coverage.e:108		wrote_coverage = 1*/
    _50wrote_coverage_49385 = 1LL;

    /** coverage.e:109		init_coverage()*/
    _50init_coverage();

    /** coverage.e:110		if not length( covered_files ) then*/
    if (IS_SEQUENCE(_50covered_files_49276)){
            _25422 = SEQ_PTR(_50covered_files_49276)->length;
    }
    else {
        _25422 = 1;
    }
    if (_25422 != 0)
    goto L2; // [31] 41
    _25422 = NOVALUE;

    /** coverage.e:111			return 1*/
    return 1LL;
L2: 

    /** coverage.e:114		if DB_OK != db_open( coverage_db_name, DB_LOCK_EXCLUSIVE) then*/
    RefDS(_50coverage_db_name_49278);
    _25424 = _41db_open(_50coverage_db_name_49278, 2LL);
    if (binary_op_a(EQUALS, 0LL, _25424)){
        DeRef(_25424);
        _25424 = NOVALUE;
        goto L3; // [54] 95
    }
    DeRef(_25424);
    _25424 = NOVALUE;

    /** coverage.e:115			if DB_OK != db_create( coverage_db_name ) then*/
    RefDS(_50coverage_db_name_49278);
    _25426 = _41db_create(_50coverage_db_name_49278, 0LL, 5LL, 5LL);
    if (binary_op_a(EQUALS, 0LL, _25426)){
        DeRef(_25426);
        _25426 = NOVALUE;
        goto L4; // [71] 94
    }
    DeRef(_25426);
    _25426 = NOVALUE;

    /** coverage.e:116				printf(2, "error opening %s\n", {coverage_db_name})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_50coverage_db_name_49278);
    ((intptr_t*)_2)[1] = _50coverage_db_name_49278;
    _25429 = MAKE_SEQ(_1);
    EPrintf(2LL, _25428, _25429);
    DeRefDS(_25429);
    _25429 = NOVALUE;

    /** coverage.e:117				return 0*/
    return 0LL;
L4: 
L3: 

    /** coverage.e:121		process_lines()*/
    _50process_lines();

    /** coverage.e:122		for tx = 1 to length( routine_map ) do*/
    if (IS_SEQUENCE(_50routine_map_49282)){
            _25430 = SEQ_PTR(_50routine_map_49282)->length;
    }
    else {
        _25430 = 1;
    }
    {
        object _tx_49407;
        _tx_49407 = 1LL;
L5: 
        if (_tx_49407 > _25430){
            goto L6; // [106] 164
        }

        /** coverage.e:123			write_map( routine_map[tx], 'r' & covered_files[tx] )*/
        _2 = (object)SEQ_PTR(_50routine_map_49282);
        _25431 = (object)*(((s1_ptr)_2)->base + _tx_49407);
        _2 = (object)SEQ_PTR(_50covered_files_49276);
        _25433 = (object)*(((s1_ptr)_2)->base + _tx_49407);
        if (IS_SEQUENCE(114LL) && IS_ATOM(_25433)) {
        }
        else if (IS_ATOM(114LL) && IS_SEQUENCE(_25433)) {
            Prepend(&_25434, _25433, 114LL);
        }
        else {
            Concat((object_ptr)&_25434, 114LL, _25433);
        }
        _25433 = NOVALUE;
        Ref(_25431);
        _50write_map(_25431, _25434);
        _25431 = NOVALUE;
        _25434 = NOVALUE;

        /** coverage.e:124			write_map( line_map[tx],    'l' & covered_files[tx] )*/
        _2 = (object)SEQ_PTR(_50line_map_49281);
        _25435 = (object)*(((s1_ptr)_2)->base + _tx_49407);
        _2 = (object)SEQ_PTR(_50covered_files_49276);
        _25437 = (object)*(((s1_ptr)_2)->base + _tx_49407);
        if (IS_SEQUENCE(108LL) && IS_ATOM(_25437)) {
        }
        else if (IS_ATOM(108LL) && IS_SEQUENCE(_25437)) {
            Prepend(&_25438, _25437, 108LL);
        }
        else {
            Concat((object_ptr)&_25438, 108LL, _25437);
        }
        _25437 = NOVALUE;
        Ref(_25435);
        _50write_map(_25435, _25438);
        _25435 = NOVALUE;
        _25438 = NOVALUE;

        /** coverage.e:125		end for*/
        _tx_49407 = _tx_49407 + 1LL;
        goto L5; // [159] 113
L6: 
        ;
    }

    /** coverage.e:127		db_close()*/
    _41db_close();

    /** coverage.e:129		routine_map = {}*/
    RefDS(_22218);
    DeRef(_50routine_map_49282);
    _50routine_map_49282 = _22218;

    /** coverage.e:130		line_map    = {}*/
    RefDS(_22218);
    DeRef(_50line_map_49281);
    _50line_map_49281 = _22218;

    /** coverage.e:131		return 1*/
    return 1LL;
    ;
}


void _50read_coverage_db()
{
    object _tables_49420 = NOVALUE;
    object _name_49426 = NOVALUE;
    object _fx_49430 = NOVALUE;
    object _the_map_49437 = NOVALUE;
    object _32063 = NOVALUE;
    object _25454 = NOVALUE;
    object _25453 = NOVALUE;
    object _25452 = NOVALUE;
    object _25448 = NOVALUE;
    object _25447 = NOVALUE;
    object _25446 = NOVALUE;
    object _25442 = NOVALUE;
    object _25441 = NOVALUE;
    object _25440 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:135		sequence tables = db_table_list()*/
    _0 = _tables_49420;
    _tables_49420 = _41db_table_list();
    DeRef(_0);

    /** coverage.e:137		for i = 1 to length( tables ) do*/
    if (IS_SEQUENCE(_tables_49420)){
            _25440 = SEQ_PTR(_tables_49420)->length;
    }
    else {
        _25440 = 1;
    }
    {
        object _i_49424;
        _i_49424 = 1LL;
L1: 
        if (_i_49424 > _25440){
            goto L2; // [13] 157
        }

        /** coverage.e:138			sequence name = tables[i][2..$]*/
        _2 = (object)SEQ_PTR(_tables_49420);
        _25441 = (object)*(((s1_ptr)_2)->base + _i_49424);
        if (IS_SEQUENCE(_25441)){
                _25442 = SEQ_PTR(_25441)->length;
        }
        else {
            _25442 = 1;
        }
        rhs_slice_target = (object_ptr)&_name_49426;
        RHS_Slice(_25441, 2LL, _25442);
        _25441 = NOVALUE;

        /** coverage.e:139			integer fx = find( name, covered_files )*/
        _fx_49430 = find_from(_name_49426, _50covered_files_49276, 1LL);

        /** coverage.e:140			if not fx then*/
        if (_fx_49430 != 0)
        goto L3; // [45] 55

        /** coverage.e:141				continue*/
        DeRefDS(_name_49426);
        _name_49426 = NOVALUE;
        DeRef(_the_map_49437);
        _the_map_49437 = NOVALUE;
        goto L4; // [52] 152
L3: 

        /** coverage.e:144			db_select_table( tables[i] )*/
        _2 = (object)SEQ_PTR(_tables_49420);
        _25446 = (object)*(((s1_ptr)_2)->base + _i_49424);
        Ref(_25446);
        _32063 = _41db_select_table(_25446);
        _25446 = NOVALUE;
        DeRef(_32063);
        _32063 = NOVALUE;

        /** coverage.e:146			if tables[i][1] = 'r' then*/
        _2 = (object)SEQ_PTR(_tables_49420);
        _25447 = (object)*(((s1_ptr)_2)->base + _i_49424);
        _2 = (object)SEQ_PTR(_25447);
        _25448 = (object)*(((s1_ptr)_2)->base + 1LL);
        _25447 = NOVALUE;
        if (binary_op_a(NOTEQ, _25448, 114LL)){
            _25448 = NOVALUE;
            goto L5; // [77] 92
        }
        _25448 = NOVALUE;

        /** coverage.e:148				the_map = routine_map[fx]*/
        DeRef(_the_map_49437);
        _2 = (object)SEQ_PTR(_50routine_map_49282);
        _the_map_49437 = (object)*(((s1_ptr)_2)->base + _fx_49430);
        Ref(_the_map_49437);
        goto L6; // [89] 101
L5: 

        /** coverage.e:152				the_map = line_map[fx]*/
        DeRef(_the_map_49437);
        _2 = (object)SEQ_PTR(_50line_map_49281);
        _the_map_49437 = (object)*(((s1_ptr)_2)->base + _fx_49430);
        Ref(_the_map_49437);
L6: 

        /** coverage.e:156			for j = 1 to db_table_size() do*/
        RefDS(_41current_table_name_16042);
        _25452 = _41db_table_size(_41current_table_name_16042);
        {
            object _j_49446;
            _j_49446 = 1LL;
L7: 
            if (binary_op_a(GREATER, _j_49446, _25452)){
                goto L8; // [109] 148
            }

            /** coverage.e:157				map:put( the_map, db_record_key( j ), db_record_data( j ), map:ADD )*/
            Ref(_j_49446);
            RefDS(_41current_table_name_16042);
            _25453 = _41db_record_key(_j_49446, _41current_table_name_16042);
            Ref(_j_49446);
            RefDS(_41current_table_name_16042);
            _25454 = _41db_record_data(_j_49446, _41current_table_name_16042);
            Ref(_the_map_49437);
            _34put(_the_map_49437, _25453, _25454, 2LL, 0LL);
            _25453 = NOVALUE;
            _25454 = NOVALUE;

            /** coverage.e:158			end for*/
            _0 = _j_49446;
            if (IS_ATOM_INT(_j_49446)) {
                _j_49446 = _j_49446 + 1LL;
                if ((object)((uintptr_t)_j_49446 +(uintptr_t) HIGH_BITS) >= 0){
                    _j_49446 = NewDouble((eudouble)_j_49446);
                }
            }
            else {
                _j_49446 = binary_op_a(PLUS, _j_49446, 1LL);
            }
            DeRef(_0);
            goto L7; // [143] 116
L8: 
            ;
            DeRef(_j_49446);
        }
        DeRef(_name_49426);
        _name_49426 = NOVALUE;
        DeRef(_the_map_49437);
        _the_map_49437 = NOVALUE;

        /** coverage.e:160		end for*/
L4: 
        _i_49424 = _i_49424 + 1LL;
        goto L1; // [152] 20
L2: 
        ;
    }

    /** coverage.e:161	end procedure*/
    DeRef(_tables_49420);
    DeRef(_25452);
    _25452 = NOVALUE;
    return;
    ;
}


void _50coverage_db(object _name_49455)
{
    object _0, _1, _2;
    

    /** coverage.e:164		coverage_db_name = name*/
    RefDS(_name_49455);
    DeRef(_50coverage_db_name_49278);
    _50coverage_db_name_49278 = _name_49455;

    /** coverage.e:165	end procedure*/
    DeRefDS(_name_49455);
    return;
    ;
}


object _50coverage_on()
{
    object _25455 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:170		return file_coverage[current_file_no]*/
    _2 = (object)SEQ_PTR(_50file_coverage_49277);
    _25455 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    return _25455;
    ;
}


void _50new_covered_path(object _name_49467)
{
    object _new_1__tmp_at14_49471 = NOVALUE;
    object _new_inlined_new_at_14_49470 = NOVALUE;
    object _new_1__tmp_at36_49475 = NOVALUE;
    object _new_inlined_new_at_36_49474 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:176		covered_files = append( covered_files, name )*/
    RefDS(_name_49467);
    Append(&_50covered_files_49276, _50covered_files_49276, _name_49467);

    /** coverage.e:177		routine_map &= map:new()*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at14_49471;
    _new_1__tmp_at14_49471 = _34new_map_seq(8LL);
    DeRef(_0);
    Ref(_new_1__tmp_at14_49471);
    _0 = _new_inlined_new_at_14_49470;
    _new_inlined_new_at_14_49470 = _35malloc(_new_1__tmp_at14_49471, 1LL);
    DeRef(_0);
    DeRef(_new_1__tmp_at14_49471);
    _new_1__tmp_at14_49471 = NOVALUE;
    if (IS_SEQUENCE(_50routine_map_49282) && IS_ATOM(_new_inlined_new_at_14_49470)) {
        Ref(_new_inlined_new_at_14_49470);
        Append(&_50routine_map_49282, _50routine_map_49282, _new_inlined_new_at_14_49470);
    }
    else if (IS_ATOM(_50routine_map_49282) && IS_SEQUENCE(_new_inlined_new_at_14_49470)) {
    }
    else {
        Concat((object_ptr)&_50routine_map_49282, _50routine_map_49282, _new_inlined_new_at_14_49470);
    }

    /** coverage.e:178		line_map    &= map:new()*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at36_49475;
    _new_1__tmp_at36_49475 = _34new_map_seq(8LL);
    DeRef(_0);
    Ref(_new_1__tmp_at36_49475);
    _0 = _new_inlined_new_at_36_49474;
    _new_inlined_new_at_36_49474 = _35malloc(_new_1__tmp_at36_49475, 1LL);
    DeRef(_0);
    DeRef(_new_1__tmp_at36_49475);
    _new_1__tmp_at36_49475 = NOVALUE;
    if (IS_SEQUENCE(_50line_map_49281) && IS_ATOM(_new_inlined_new_at_36_49474)) {
        Ref(_new_inlined_new_at_36_49474);
        Append(&_50line_map_49281, _50line_map_49281, _new_inlined_new_at_36_49474);
    }
    else if (IS_ATOM(_50line_map_49281) && IS_SEQUENCE(_new_inlined_new_at_36_49474)) {
    }
    else {
        Concat((object_ptr)&_50line_map_49281, _50line_map_49281, _new_inlined_new_at_36_49474);
    }

    /** coverage.e:179	end procedure*/
    DeRefDS(_name_49467);
    return;
    ;
}


void _50add_coverage(object _cover_this_49479)
{
    object _path_49480 = NOVALUE;
    object _files_49489 = NOVALUE;
    object _subpath_49517 = NOVALUE;
    object _25494 = NOVALUE;
    object _25493 = NOVALUE;
    object _25492 = NOVALUE;
    object _25491 = NOVALUE;
    object _25490 = NOVALUE;
    object _25489 = NOVALUE;
    object _25488 = NOVALUE;
    object _25487 = NOVALUE;
    object _25486 = NOVALUE;
    object _25485 = NOVALUE;
    object _25484 = NOVALUE;
    object _25483 = NOVALUE;
    object _25481 = NOVALUE;
    object _25480 = NOVALUE;
    object _25479 = NOVALUE;
    object _25478 = NOVALUE;
    object _25477 = NOVALUE;
    object _25476 = NOVALUE;
    object _25475 = NOVALUE;
    object _25474 = NOVALUE;
    object _25472 = NOVALUE;
    object _25471 = NOVALUE;
    object _25470 = NOVALUE;
    object _25469 = NOVALUE;
    object _25468 = NOVALUE;
    object _25467 = NOVALUE;
    object _25466 = NOVALUE;
    object _25465 = NOVALUE;
    object _25462 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:185		sequence path = canonical_path( cover_this,, CORRECT )*/
    RefDS(_cover_this_49479);
    _0 = _path_49480;
    _path_49480 = _15canonical_path(_cover_this_49479, 0LL, 2LL);
    DeRef(_0);

    /** coverage.e:187		if file_type( path ) = FILETYPE_DIRECTORY then*/
    RefDS(_path_49480);
    _25462 = _15file_type(_path_49480);
    if (binary_op_a(NOTEQ, _25462, 2LL)){
        DeRef(_25462);
        _25462 = NOVALUE;
        goto L1; // [23] 211
    }
    DeRef(_25462);
    _25462 = NOVALUE;

    /** coverage.e:188			sequence files = dir( path  )*/
    RefDS(_path_49480);
    _0 = _files_49489;
    _files_49489 = _15dir(_path_49480);
    DeRef(_0);

    /** coverage.e:190			for i = 1 to length( files ) do*/
    if (IS_SEQUENCE(_files_49489)){
            _25465 = SEQ_PTR(_files_49489)->length;
    }
    else {
        _25465 = 1;
    }
    {
        object _i_49493;
        _i_49493 = 1LL;
L2: 
        if (_i_49493 > _25465){
            goto L3; // [40] 206
        }

        /** coverage.e:191				if find( 'd', files[i][D_ATTRIBUTES] ) then*/
        _2 = (object)SEQ_PTR(_files_49489);
        _25466 = (object)*(((s1_ptr)_2)->base + _i_49493);
        _2 = (object)SEQ_PTR(_25466);
        _25467 = (object)*(((s1_ptr)_2)->base + 2LL);
        _25466 = NOVALUE;
        _25468 = find_from(100LL, _25467, 1LL);
        _25467 = NOVALUE;
        if (_25468 == 0)
        {
            _25468 = NOVALUE;
            goto L4; // [64] 118
        }
        else{
            _25468 = NOVALUE;
        }

        /** coverage.e:192					if not eu:find(files[i][D_NAME], {".", ".."}) then*/
        _2 = (object)SEQ_PTR(_files_49489);
        _25469 = (object)*(((s1_ptr)_2)->base + _i_49493);
        _2 = (object)SEQ_PTR(_25469);
        _25470 = (object)*(((s1_ptr)_2)->base + 1LL);
        _25469 = NOVALUE;
        RefDS(_23422);
        RefDS(_23423);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _23423;
        ((intptr_t *)_2)[2] = _23422;
        _25471 = MAKE_SEQ(_1);
        _25472 = find_from(_25470, _25471, 1LL);
        _25470 = NOVALUE;
        DeRefDS(_25471);
        _25471 = NOVALUE;
        if (_25472 != 0)
        goto L5; // [88] 199
        _25472 = NOVALUE;

        /** coverage.e:193						add_coverage( cover_this & SLASH & files[i][D_NAME] )*/
        _2 = (object)SEQ_PTR(_files_49489);
        _25474 = (object)*(((s1_ptr)_2)->base + _i_49493);
        _2 = (object)SEQ_PTR(_25474);
        _25475 = (object)*(((s1_ptr)_2)->base + 1LL);
        _25474 = NOVALUE;
        {
            object concat_list[3];

            concat_list[0] = _25475;
            concat_list[1] = 92LL;
            concat_list[2] = _cover_this_49479;
            Concat_N((object_ptr)&_25476, concat_list, 3);
        }
        _25475 = NOVALUE;
        _50add_coverage(_25476);
        _25476 = NOVALUE;
        goto L5; // [115] 199
L4: 

        /** coverage.e:196				elsif regex:has_match( eu_file, files[i][D_NAME] ) then*/
        _2 = (object)SEQ_PTR(_files_49489);
        _25477 = (object)*(((s1_ptr)_2)->base + _i_49493);
        _2 = (object)SEQ_PTR(_25477);
        _25478 = (object)*(((s1_ptr)_2)->base + 1LL);
        _25477 = NOVALUE;
        Ref(_50eu_file_49461);
        Ref(_25478);
        _25479 = _51has_match(_50eu_file_49461, _25478, 1LL, 0LL);
        _25478 = NOVALUE;
        if (_25479 == 0) {
            DeRef(_25479);
            _25479 = NOVALUE;
            goto L6; // [139] 196
        }
        else {
            if (!IS_ATOM_INT(_25479) && DBL_PTR(_25479)->dbl == 0.0){
                DeRef(_25479);
                _25479 = NOVALUE;
                goto L6; // [139] 196
            }
            DeRef(_25479);
            _25479 = NOVALUE;
        }
        DeRef(_25479);
        _25479 = NOVALUE;

        /** coverage.e:198					sequence subpath = path & SLASH & files[i][D_NAME]*/
        _2 = (object)SEQ_PTR(_files_49489);
        _25480 = (object)*(((s1_ptr)_2)->base + _i_49493);
        _2 = (object)SEQ_PTR(_25480);
        _25481 = (object)*(((s1_ptr)_2)->base + 1LL);
        _25480 = NOVALUE;
        {
            object concat_list[3];

            concat_list[0] = _25481;
            concat_list[1] = 92LL;
            concat_list[2] = _path_49480;
            Concat_N((object_ptr)&_subpath_49517, concat_list, 3);
        }
        _25481 = NOVALUE;

        /** coverage.e:199					if not find( subpath, covered_files ) and not excluded( subpath ) then*/
        _25483 = find_from(_subpath_49517, _50covered_files_49276, 1LL);
        _25484 = (_25483 == 0);
        _25483 = NOVALUE;
        if (_25484 == 0) {
            goto L7; // [174] 195
        }
        RefDS(_subpath_49517);
        _25486 = _50excluded(_subpath_49517);
        if (IS_ATOM_INT(_25486)) {
            _25487 = (_25486 == 0);
        }
        else {
            _25487 = unary_op(NOT, _25486);
        }
        DeRef(_25486);
        _25486 = NOVALUE;
        if (_25487 == 0) {
            DeRef(_25487);
            _25487 = NOVALUE;
            goto L7; // [186] 195
        }
        else {
            if (!IS_ATOM_INT(_25487) && DBL_PTR(_25487)->dbl == 0.0){
                DeRef(_25487);
                _25487 = NOVALUE;
                goto L7; // [186] 195
            }
            DeRef(_25487);
            _25487 = NOVALUE;
        }
        DeRef(_25487);
        _25487 = NOVALUE;

        /** coverage.e:200						new_covered_path( subpath )*/
        RefDS(_subpath_49517);
        _50new_covered_path(_subpath_49517);
L7: 
L6: 
        DeRef(_subpath_49517);
        _subpath_49517 = NOVALUE;
L5: 

        /** coverage.e:203			end for*/
        _i_49493 = _i_49493 + 1LL;
        goto L2; // [201] 47
L3: 
        ;
    }
    DeRef(_files_49489);
    _files_49489 = NOVALUE;
    goto L8; // [208] 262
L1: 

    /** coverage.e:204		elsif regex:has_match( eu_file, path ) and*/
    Ref(_50eu_file_49461);
    RefDS(_path_49480);
    _25488 = _51has_match(_50eu_file_49461, _path_49480, 1LL, 0LL);
    if (IS_ATOM_INT(_25488)) {
        if (_25488 == 0) {
            DeRef(_25489);
            _25489 = 0;
            goto L9; // [222] 240
        }
    }
    else {
        if (DBL_PTR(_25488)->dbl == 0.0) {
            DeRef(_25489);
            _25489 = 0;
            goto L9; // [222] 240
        }
    }
    _25490 = find_from(_path_49480, _50covered_files_49276, 1LL);
    _25491 = (_25490 == 0);
    _25490 = NOVALUE;
    DeRef(_25489);
    _25489 = (_25491 != 0);
L9: 
    if (_25489 == 0) {
        goto LA; // [240] 261
    }
    RefDS(_path_49480);
    _25493 = _50excluded(_path_49480);
    if (IS_ATOM_INT(_25493)) {
        _25494 = (_25493 == 0);
    }
    else {
        _25494 = unary_op(NOT, _25493);
    }
    DeRef(_25493);
    _25493 = NOVALUE;
    if (_25494 == 0) {
        DeRef(_25494);
        _25494 = NOVALUE;
        goto LA; // [252] 261
    }
    else {
        if (!IS_ATOM_INT(_25494) && DBL_PTR(_25494)->dbl == 0.0){
            DeRef(_25494);
            _25494 = NOVALUE;
            goto LA; // [252] 261
        }
        DeRef(_25494);
        _25494 = NOVALUE;
    }
    DeRef(_25494);
    _25494 = NOVALUE;

    /** coverage.e:207			new_covered_path( path )*/
    RefDS(_path_49480);
    _50new_covered_path(_path_49480);
LA: 
L8: 

    /** coverage.e:209	end procedure*/
    DeRefDS(_cover_this_49479);
    DeRef(_path_49480);
    DeRef(_25491);
    _25491 = NOVALUE;
    DeRef(_25484);
    _25484 = NOVALUE;
    DeRef(_25488);
    _25488 = NOVALUE;
    return;
    ;
}


object _50excluded(object _file_49541)
{
    object _25497 = NOVALUE;
    object _25496 = NOVALUE;
    object _25495 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:212		for i = 1 to length( exclusion_patterns ) do*/
    if (IS_SEQUENCE(_50exclusion_patterns_49280)){
            _25495 = SEQ_PTR(_50exclusion_patterns_49280)->length;
    }
    else {
        _25495 = 1;
    }
    {
        object _i_49543;
        _i_49543 = 1LL;
L1: 
        if (_i_49543 > _25495){
            goto L2; // [10] 49
        }

        /** coverage.e:213			if regex:has_match( exclusion_patterns[i], file ) then*/
        _2 = (object)SEQ_PTR(_50exclusion_patterns_49280);
        _25496 = (object)*(((s1_ptr)_2)->base + _i_49543);
        Ref(_25496);
        RefDS(_file_49541);
        _25497 = _51has_match(_25496, _file_49541, 1LL, 0LL);
        _25496 = NOVALUE;
        if (_25497 == 0) {
            DeRef(_25497);
            _25497 = NOVALUE;
            goto L3; // [32] 42
        }
        else {
            if (!IS_ATOM_INT(_25497) && DBL_PTR(_25497)->dbl == 0.0){
                DeRef(_25497);
                _25497 = NOVALUE;
                goto L3; // [32] 42
            }
            DeRef(_25497);
            _25497 = NOVALUE;
        }
        DeRef(_25497);
        _25497 = NOVALUE;

        /** coverage.e:214				return 1*/
        DeRefDS(_file_49541);
        return 1LL;
L3: 

        /** coverage.e:216		end for*/
        _i_49543 = _i_49543 + 1LL;
        goto L1; // [44] 17
L2: 
        ;
    }

    /** coverage.e:217		return 0*/
    DeRefDS(_file_49541);
    return 0LL;
    ;
}


void _50coverage_exclude(object _patterns_49550)
{
    object _ex_49555 = NOVALUE;
    object _fx_49562 = NOVALUE;
    object _25515 = NOVALUE;
    object _25514 = NOVALUE;
    object _25513 = NOVALUE;
    object _25512 = NOVALUE;
    object _25506 = NOVALUE;
    object _25505 = NOVALUE;
    object _25503 = NOVALUE;
    object _25501 = NOVALUE;
    object _25499 = NOVALUE;
    object _25498 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:221		for i = 1 to length( patterns ) do*/
    if (IS_SEQUENCE(_patterns_49550)){
            _25498 = SEQ_PTR(_patterns_49550)->length;
    }
    else {
        _25498 = 1;
    }
    {
        object _i_49552;
        _i_49552 = 1LL;
L1: 
        if (_i_49552 > _25498){
            goto L2; // [8] 163
        }

        /** coverage.e:222			regex ex = regex:new( patterns[i] )*/
        _2 = (object)SEQ_PTR(_patterns_49550);
        _25499 = (object)*(((s1_ptr)_2)->base + _i_49552);
        Ref(_25499);
        _0 = _ex_49555;
        _ex_49555 = _51new(_25499, 0LL);
        DeRef(_0);
        _25499 = NOVALUE;

        /** coverage.e:223			if regex( ex ) then*/
        Ref(_ex_49555);
        _25501 = _51regex(_ex_49555);
        if (_25501 == 0) {
            DeRef(_25501);
            _25501 = NOVALUE;
            goto L3; // [32] 127
        }
        else {
            if (!IS_ATOM_INT(_25501) && DBL_PTR(_25501)->dbl == 0.0){
                DeRef(_25501);
                _25501 = NOVALUE;
                goto L3; // [32] 127
            }
            DeRef(_25501);
            _25501 = NOVALUE;
        }
        DeRef(_25501);
        _25501 = NOVALUE;

        /** coverage.e:224				exclusion_patterns = append( exclusion_patterns, ex )*/
        Ref(_ex_49555);
        Append(&_50exclusion_patterns_49280, _50exclusion_patterns_49280, _ex_49555);

        /** coverage.e:225				integer fx = 1*/
        _fx_49562 = 1LL;

        /** coverage.e:226				while fx <= length( covered_files ) do*/
L4: 
        if (IS_SEQUENCE(_50covered_files_49276)){
                _25503 = SEQ_PTR(_50covered_files_49276)->length;
        }
        else {
            _25503 = 1;
        }
        if (_fx_49562 > _25503)
        goto L5; // [58] 122

        /** coverage.e:227					if regex:has_match( ex, covered_files[fx] ) then*/
        _2 = (object)SEQ_PTR(_50covered_files_49276);
        _25505 = (object)*(((s1_ptr)_2)->base + _fx_49562);
        Ref(_ex_49555);
        Ref(_25505);
        _25506 = _51has_match(_ex_49555, _25505, 1LL, 0LL);
        _25505 = NOVALUE;
        if (_25506 == 0) {
            DeRef(_25506);
            _25506 = NOVALUE;
            goto L6; // [77] 110
        }
        else {
            if (!IS_ATOM_INT(_25506) && DBL_PTR(_25506)->dbl == 0.0){
                DeRef(_25506);
                _25506 = NOVALUE;
                goto L6; // [77] 110
            }
            DeRef(_25506);
            _25506 = NOVALUE;
        }
        DeRef(_25506);
        _25506 = NOVALUE;

        /** coverage.e:228						covered_files = remove( covered_files, fx )*/
        {
            s1_ptr assign_space = SEQ_PTR(_50covered_files_49276);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_49562)) ? _fx_49562 : (object)(DBL_PTR(_fx_49562)->dbl);
            int stop = (IS_ATOM_INT(_fx_49562)) ? _fx_49562 : (object)(DBL_PTR(_fx_49562)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_50covered_files_49276), start, &_50covered_files_49276 );
                }
                else Tail(SEQ_PTR(_50covered_files_49276), stop+1, &_50covered_files_49276);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_50covered_files_49276), start, &_50covered_files_49276);
            }
            else {
                assign_slice_seq = &assign_space;
                _50covered_files_49276 = Remove_elements(start, stop, (SEQ_PTR(_50covered_files_49276)->ref == 1));
            }
        }

        /** coverage.e:229						routine_map   = remove( routine_map, fx )*/
        {
            s1_ptr assign_space = SEQ_PTR(_50routine_map_49282);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_49562)) ? _fx_49562 : (object)(DBL_PTR(_fx_49562)->dbl);
            int stop = (IS_ATOM_INT(_fx_49562)) ? _fx_49562 : (object)(DBL_PTR(_fx_49562)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_50routine_map_49282), start, &_50routine_map_49282 );
                }
                else Tail(SEQ_PTR(_50routine_map_49282), stop+1, &_50routine_map_49282);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_50routine_map_49282), start, &_50routine_map_49282);
            }
            else {
                assign_slice_seq = &assign_space;
                _50routine_map_49282 = Remove_elements(start, stop, (SEQ_PTR(_50routine_map_49282)->ref == 1));
            }
        }

        /** coverage.e:230						line_map      = remove( line_map, fx )*/
        {
            s1_ptr assign_space = SEQ_PTR(_50line_map_49281);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_49562)) ? _fx_49562 : (object)(DBL_PTR(_fx_49562)->dbl);
            int stop = (IS_ATOM_INT(_fx_49562)) ? _fx_49562 : (object)(DBL_PTR(_fx_49562)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_50line_map_49281), start, &_50line_map_49281 );
                }
                else Tail(SEQ_PTR(_50line_map_49281), stop+1, &_50line_map_49281);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_50line_map_49281), start, &_50line_map_49281);
            }
            else {
                assign_slice_seq = &assign_space;
                _50line_map_49281 = Remove_elements(start, stop, (SEQ_PTR(_50line_map_49281)->ref == 1));
            }
        }
        goto L4; // [107] 53
L6: 

        /** coverage.e:232						fx += 1*/
        _fx_49562 = _fx_49562 + 1;

        /** coverage.e:234				end while*/
        goto L4; // [119] 53
L5: 
        goto L7; // [124] 154
L3: 

        /** coverage.e:236				printf( 2,"%s\n", { GetMsgText( ERROR_CREATING_REGEX_FOR_COVERAGE_EXCLUSION_PATTERN_1, 1, {patterns[i]}) } )*/
        _2 = (object)SEQ_PTR(_patterns_49550);
        _25512 = (object)*(((s1_ptr)_2)->base + _i_49552);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_25512);
        ((intptr_t*)_2)[1] = _25512;
        _25513 = MAKE_SEQ(_1);
        _25512 = NOVALUE;
        _25514 = _30GetMsgText(339LL, 1LL, _25513);
        _25513 = NOVALUE;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _25514;
        _25515 = MAKE_SEQ(_1);
        _25514 = NOVALUE;
        EPrintf(2LL, _25511, _25515);
        DeRefDS(_25515);
        _25515 = NOVALUE;
L7: 
        DeRef(_ex_49555);
        _ex_49555 = NOVALUE;

        /** coverage.e:238		end for*/
        _i_49552 = _i_49552 + 1LL;
        goto L1; // [158] 15
L2: 
        ;
    }

    /** coverage.e:240	end procedure*/
    DeRefDS(_patterns_49550);
    return;
    ;
}


void _50new_coverage_db()
{
    object _0, _1, _2;
    

    /** coverage.e:243		coverage_erase = 1*/
    _50coverage_erase_49279 = 1LL;

    /** coverage.e:244	end procedure*/
    return;
    ;
}


void _50include_line(object _line_number_49586)
{
    object _25516 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:247		if coverage_on() then*/
    _25516 = _50coverage_on();
    if (_25516 == 0) {
        DeRef(_25516);
        _25516 = NOVALUE;
        goto L1; // [8] 34
    }
    else {
        if (!IS_ATOM_INT(_25516) && DBL_PTR(_25516)->dbl == 0.0){
            DeRef(_25516);
            _25516 = NOVALUE;
            goto L1; // [8] 34
        }
        DeRef(_25516);
        _25516 = NOVALUE;
    }
    DeRef(_25516);
    _25516 = NOVALUE;

    /** coverage.e:248			emit_op( COVERAGE_LINE )*/
    _45emit_op(210LL);

    /** coverage.e:249			emit_addr( gline_number )*/
    _45emit_addr(_27gline_number_20576);

    /** coverage.e:251			included_lines &= line_number*/
    Append(&_50included_lines_49283, _50included_lines_49283, _line_number_49586);
L1: 

    /** coverage.e:253	end procedure*/
    return;
    ;
}


void _50include_routine()
{
    object _file_no_49602 = NOVALUE;
    object _25523 = NOVALUE;
    object _25522 = NOVALUE;
    object _25521 = NOVALUE;
    object _25519 = NOVALUE;
    object _25518 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:256		if coverage_on() then*/
    _25518 = _50coverage_on();
    if (_25518 == 0) {
        DeRef(_25518);
        _25518 = NOVALUE;
        goto L1; // [6] 69
    }
    else {
        if (!IS_ATOM_INT(_25518) && DBL_PTR(_25518)->dbl == 0.0){
            DeRef(_25518);
            _25518 = NOVALUE;
            goto L1; // [6] 69
        }
        DeRef(_25518);
        _25518 = NOVALUE;
    }
    DeRef(_25518);
    _25518 = NOVALUE;

    /** coverage.e:257			emit_op( COVERAGE_ROUTINE )*/
    _45emit_op(211LL);

    /** coverage.e:258			emit_addr( CurrentSub )*/
    _45emit_addr(_27CurrentSub_20579);

    /** coverage.e:261			integer file_no = SymTab[CurrentSub][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25519 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_25519);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _file_no_49602 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _file_no_49602 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    if (!IS_ATOM_INT(_file_no_49602)){
        _file_no_49602 = (object)DBL_PTR(_file_no_49602)->dbl;
    }
    _25519 = NOVALUE;

    /** coverage.e:262			map:put( routine_map[file_coverage[file_no]], sym_name( CurrentSub ), 0, map:ADD )*/
    _2 = (object)SEQ_PTR(_50file_coverage_49277);
    _25521 = (object)*(((s1_ptr)_2)->base + _file_no_49602);
    _2 = (object)SEQ_PTR(_50routine_map_49282);
    _25522 = (object)*(((s1_ptr)_2)->base + _25521);
    _25523 = _53sym_name(_27CurrentSub_20579);
    Ref(_25522);
    _34put(_25522, _25523, 0LL, 2LL, 0LL);
    _25522 = NOVALUE;
    _25523 = NOVALUE;
L1: 

    /** coverage.e:264	end procedure*/
    _25521 = NOVALUE;
    return;
    ;
}


void _50process_lines()
{
    object _sline_49630 = NOVALUE;
    object _file_49634 = NOVALUE;
    object _line_49644 = NOVALUE;
    object _25541 = NOVALUE;
    object _25539 = NOVALUE;
    object _25538 = NOVALUE;
    object _25537 = NOVALUE;
    object _25536 = NOVALUE;
    object _25535 = NOVALUE;
    object _25533 = NOVALUE;
    object _25531 = NOVALUE;
    object _25530 = NOVALUE;
    object _25528 = NOVALUE;
    object _25527 = NOVALUE;
    object _25526 = NOVALUE;
    object _25524 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:267		if not length( included_lines ) then*/
    if (IS_SEQUENCE(_50included_lines_49283)){
            _25524 = SEQ_PTR(_50included_lines_49283)->length;
    }
    else {
        _25524 = 1;
    }
    if (_25524 != 0)
    goto L1; // [8] 17
    _25524 = NOVALUE;

    /** coverage.e:268			return*/
    return;
L1: 

    /** coverage.e:270		if atom(slist[$]) then*/
    if (IS_SEQUENCE(_27slist_20662)){
            _25526 = SEQ_PTR(_27slist_20662)->length;
    }
    else {
        _25526 = 1;
    }
    _2 = (object)SEQ_PTR(_27slist_20662);
    _25527 = (object)*(((s1_ptr)_2)->base + _25526);
    _25528 = IS_ATOM(_25527);
    _25527 = NOVALUE;
    if (_25528 == 0)
    {
        _25528 = NOVALUE;
        goto L2; // [31] 45
    }
    else{
        _25528 = NOVALUE;
    }

    /** coverage.e:271			slist = s_expand( slist )*/
    RefDS(_27slist_20662);
    _0 = _61s_expand(_27slist_20662);
    DeRefDS(_27slist_20662);
    _27slist_20662 = _0;
L2: 

    /** coverage.e:273		for i = 1 to length( included_lines ) do*/
    if (IS_SEQUENCE(_50included_lines_49283)){
            _25530 = SEQ_PTR(_50included_lines_49283)->length;
    }
    else {
        _25530 = 1;
    }
    {
        object _i_49628;
        _i_49628 = 1LL;
L3: 
        if (_i_49628 > _25530){
            goto L4; // [52] 157
        }

        /** coverage.e:274			sequence sline = slist[included_lines[i]]*/
        _2 = (object)SEQ_PTR(_50included_lines_49283);
        _25531 = (object)*(((s1_ptr)_2)->base + _i_49628);
        DeRef(_sline_49630);
        _2 = (object)SEQ_PTR(_27slist_20662);
        _sline_49630 = (object)*(((s1_ptr)_2)->base + _25531);
        Ref(_sline_49630);

        /** coverage.e:275			integer file = file_coverage[sline[LOCAL_FILE_NO]]*/
        _2 = (object)SEQ_PTR(_sline_49630);
        _25533 = (object)*(((s1_ptr)_2)->base + 3LL);
        _2 = (object)SEQ_PTR(_50file_coverage_49277);
        if (!IS_ATOM_INT(_25533)){
            _file_49634 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25533)->dbl));
        }
        else{
            _file_49634 = (object)*(((s1_ptr)_2)->base + _25533);
        }

        /** coverage.e:276			if file and file <= length( line_map ) and line_map[file] then*/
        if (_file_49634 == 0) {
            _25535 = 0;
            goto L5; // [91] 108
        }
        if (IS_SEQUENCE(_50line_map_49281)){
                _25536 = SEQ_PTR(_50line_map_49281)->length;
        }
        else {
            _25536 = 1;
        }
        _25537 = (_file_49634 <= _25536);
        _25536 = NOVALUE;
        _25535 = (_25537 != 0);
L5: 
        if (_25535 == 0) {
            goto L6; // [108] 146
        }
        _2 = (object)SEQ_PTR(_50line_map_49281);
        _25539 = (object)*(((s1_ptr)_2)->base + _file_49634);
        if (_25539 == 0) {
            _25539 = NOVALUE;
            goto L6; // [119] 146
        }
        else {
            if (!IS_ATOM_INT(_25539) && DBL_PTR(_25539)->dbl == 0.0){
                _25539 = NOVALUE;
                goto L6; // [119] 146
            }
            _25539 = NOVALUE;
        }
        _25539 = NOVALUE;

        /** coverage.e:277				integer line = sline[LINE]*/
        _2 = (object)SEQ_PTR(_sline_49630);
        _line_49644 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_line_49644))
        _line_49644 = (object)DBL_PTR(_line_49644)->dbl;

        /** coverage.e:278				map:put( line_map[file], line, 0, map:ADD )*/
        _2 = (object)SEQ_PTR(_50line_map_49281);
        _25541 = (object)*(((s1_ptr)_2)->base + _file_49634);
        Ref(_25541);
        _34put(_25541, _line_49644, 0LL, 2LL, 0LL);
        _25541 = NOVALUE;
L6: 
        DeRef(_sline_49630);
        _sline_49630 = NOVALUE;

        /** coverage.e:280		end for*/
        _i_49628 = _i_49628 + 1LL;
        goto L3; // [152] 59
L4: 
        ;
    }

    /** coverage.e:281	end procedure*/
    _25531 = NOVALUE;
    _25533 = NOVALUE;
    DeRef(_25537);
    _25537 = NOVALUE;
    return;
    ;
}


object _50cover_line(object _gline_number_49650)
{
    object _sline_49660 = NOVALUE;
    object _file_49663 = NOVALUE;
    object _line_49668 = NOVALUE;
    object _25550 = NOVALUE;
    object _25547 = NOVALUE;
    object _25544 = NOVALUE;
    object _25543 = NOVALUE;
    object _25542 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_gline_number_49650)) {
        _1 = (object)(DBL_PTR(_gline_number_49650)->dbl);
        DeRefDS(_gline_number_49650);
        _gline_number_49650 = _1;
    }

    /** coverage.e:284		if atom(slist[$]) then*/
    if (IS_SEQUENCE(_27slist_20662)){
            _25542 = SEQ_PTR(_27slist_20662)->length;
    }
    else {
        _25542 = 1;
    }
    _2 = (object)SEQ_PTR(_27slist_20662);
    _25543 = (object)*(((s1_ptr)_2)->base + _25542);
    _25544 = IS_ATOM(_25543);
    _25543 = NOVALUE;
    if (_25544 == 0)
    {
        _25544 = NOVALUE;
        goto L1; // [17] 31
    }
    else{
        _25544 = NOVALUE;
    }

    /** coverage.e:285			slist = s_expand(slist)*/
    RefDS(_27slist_20662);
    _0 = _61s_expand(_27slist_20662);
    DeRefDS(_27slist_20662);
    _27slist_20662 = _0;
L1: 

    /** coverage.e:287		sequence sline = slist[gline_number]*/
    DeRef(_sline_49660);
    _2 = (object)SEQ_PTR(_27slist_20662);
    _sline_49660 = (object)*(((s1_ptr)_2)->base + _gline_number_49650);
    Ref(_sline_49660);

    /** coverage.e:288		integer file = file_coverage[sline[LOCAL_FILE_NO]]*/
    _2 = (object)SEQ_PTR(_sline_49660);
    _25547 = (object)*(((s1_ptr)_2)->base + 3LL);
    _2 = (object)SEQ_PTR(_50file_coverage_49277);
    if (!IS_ATOM_INT(_25547)){
        _file_49663 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25547)->dbl));
    }
    else{
        _file_49663 = (object)*(((s1_ptr)_2)->base + _25547);
    }

    /** coverage.e:289		if file then*/
    if (_file_49663 == 0)
    {
        goto L2; // [57] 84
    }
    else{
    }

    /** coverage.e:290			integer line = sline[LINE]*/
    _2 = (object)SEQ_PTR(_sline_49660);
    _line_49668 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_line_49668))
    _line_49668 = (object)DBL_PTR(_line_49668)->dbl;

    /** coverage.e:291			map:put( line_map[file], line, 1, map:ADD )*/
    _2 = (object)SEQ_PTR(_50line_map_49281);
    _25550 = (object)*(((s1_ptr)_2)->base + _file_49663);
    Ref(_25550);
    _34put(_25550, _line_49668, 1LL, 2LL, 0LL);
    _25550 = NOVALUE;
L2: 

    /** coverage.e:293		return 0*/
    DeRef(_sline_49660);
    _25547 = NOVALUE;
    return 0LL;
    ;
}


object _50cover_routine(object _sub_49675)
{
    object _file_no_49676 = NOVALUE;
    object _25555 = NOVALUE;
    object _25554 = NOVALUE;
    object _25553 = NOVALUE;
    object _25551 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sub_49675)) {
        _1 = (object)(DBL_PTR(_sub_49675)->dbl);
        DeRefDS(_sub_49675);
        _sub_49675 = _1;
    }

    /** coverage.e:297		integer file_no = SymTab[sub][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25551 = (object)*(((s1_ptr)_2)->base + _sub_49675);
    _2 = (object)SEQ_PTR(_25551);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _file_no_49676 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _file_no_49676 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    if (!IS_ATOM_INT(_file_no_49676)){
        _file_no_49676 = (object)DBL_PTR(_file_no_49676)->dbl;
    }
    _25551 = NOVALUE;

    /** coverage.e:298		map:put( routine_map[file_coverage[file_no]], sym_name( sub ), 1, map:ADD )*/
    _2 = (object)SEQ_PTR(_50file_coverage_49277);
    _25553 = (object)*(((s1_ptr)_2)->base + _file_no_49676);
    _2 = (object)SEQ_PTR(_50routine_map_49282);
    _25554 = (object)*(((s1_ptr)_2)->base + _25553);
    _25555 = _53sym_name(_sub_49675);
    Ref(_25554);
    _34put(_25554, _25555, 1LL, 2LL, 0LL);
    _25554 = NOVALUE;
    _25555 = NOVALUE;

    /** coverage.e:299		return 0*/
    _25553 = NOVALUE;
    return 0LL;
    ;
}



// 0xEEF78549
