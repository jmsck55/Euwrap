// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _72default_state()
{
    object _35535 = NOVALUE;
    object _0, _1, _2;
    

    /** tokenize.e:177		return {*/
    _1 = NewS1(8);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    ((intptr_t*)_2)[3] = 0LL;
    ((intptr_t*)_2)[4] = 1LL;
    ((intptr_t*)_2)[5] = 0LL;
    ((intptr_t*)_2)[6] = 1LL;
    ((intptr_t*)_2)[7] = 0LL;
    ((intptr_t*)_2)[8] = 0LL;
    _35535 = MAKE_SEQ(_1);
    return _35535;
    ;
}


object _72new()
{
    object _state_71427 = NOVALUE;
    object _0, _1, _2;
    

    /** tokenize.e:200		atom state = eumem:malloc()*/
    _0 = _state_71427;
    _state_71427 = _35malloc(1LL, 1LL);
    DeRef(_0);

    /** tokenize.e:202		reset(state)*/
    Ref(_state_71427);
    _72reset(_state_71427);

    /** tokenize.e:204		return state*/
    return _state_71427;
    ;
}


void _72reset(object _state_71432)
{
    object _35539 = NOVALUE;
    object _0, _1, _2;
    

    /** tokenize.e:215		eumem:ram_space[state] = default_state()*/
    _35539 = _72default_state();
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_13045 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_71432))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_state_71432)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _state_71432);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35539;
    if( _1 != _35539 ){
        DeRef(_1);
    }
    _35539 = NOVALUE;

    /** tokenize.e:216	end procedure*/
    DeRef(_state_71432);
    return;
    ;
}



// 0x57B58D99
