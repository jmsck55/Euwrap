// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _38any_key(object _prompt_14603, object _con_14605)
{
    object _wait_key_inlined_wait_key_at_27_14611 = NOVALUE;
    object _8369 = NOVALUE;
    object _0, _1, _2;
    

    /** console.e:883		if not find(con, {1,2}) then*/
    _8369 = find_from(_con_14605, _8368, 1LL);
    if (_8369 != 0)
    goto L1; // [12] 21
    _8369 = NOVALUE;

    /** console.e:884			con = 1*/
    _con_14605 = 1LL;
L1: 

    /** console.e:886		puts(con, prompt)*/
    EPuts(_con_14605, _prompt_14603); // DJP 

    /** console.e:887		wait_key()*/

    /** console.e:854		return machine_func(M_WAIT_KEY, 0)*/
    _wait_key_inlined_wait_key_at_27_14611 = machine(26LL, 0LL);

    /** console.e:888		puts(con, "\n")*/
    EPuts(_con_14605, _8371); // DJP 

    /** console.e:889	end procedure*/
    DeRefDS(_prompt_14603);
    return;
    ;
}


void _38maybe_any_key(object _prompt_14615, object _con_14616)
{
    object _has_console_inlined_has_console_at_6_14619 = NOVALUE;
    object _0, _1, _2;
    

    /** console.e:923		if not has_console() then*/

    /** console.e:59		return machine_func(M_HAS_CONSOLE, 0)*/
    DeRef(_has_console_inlined_has_console_at_6_14619);
    _has_console_inlined_has_console_at_6_14619 = machine(99LL, 0LL);
    if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_14619)) {
        if (_has_console_inlined_has_console_at_6_14619 != 0){
            goto L1; // [14] 24
        }
    }
    else {
        if (DBL_PTR(_has_console_inlined_has_console_at_6_14619)->dbl != 0.0){
            goto L1; // [14] 24
        }
    }

    /** console.e:924			any_key(prompt, con)*/
    RefDS(_prompt_14615);
    _38any_key(_prompt_14615, _con_14616);
L1: 

    /** console.e:926	end procedure*/
    DeRefDS(_prompt_14615);
    return;
    ;
}



// 0x7CD11344
