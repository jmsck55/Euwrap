// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _44host_platform()
{
    object _0, _1, _2;
    

    /** platform.e:113		return ihost_platform*/
    return 2LL;
    ;
}


object _44GetPlatformDefines(object _for_translator_20787)
{
    object _local_defines_20788 = NOVALUE;
    object _lcmds_20798 = NOVALUE;
    object _fh_20800 = NOVALUE;
    object _sk_20820 = NOVALUE;
    object _11768 = NOVALUE;
    object _11767 = NOVALUE;
    object _11765 = NOVALUE;
    object _11762 = NOVALUE;
    object _11761 = NOVALUE;
    object _11759 = NOVALUE;
    object _11758 = NOVALUE;
    object _11756 = NOVALUE;
    object _11753 = NOVALUE;
    object _11752 = NOVALUE;
    object _11750 = NOVALUE;
    object _11749 = NOVALUE;
    object _11747 = NOVALUE;
    object _11745 = NOVALUE;
    object _11743 = NOVALUE;
    object _11742 = NOVALUE;
    object _11740 = NOVALUE;
    object _11737 = NOVALUE;
    object _11735 = NOVALUE;
    object _11734 = NOVALUE;
    object _11732 = NOVALUE;
    object _11730 = NOVALUE;
    object _11728 = NOVALUE;
    object _11727 = NOVALUE;
    object _11725 = NOVALUE;
    object _11723 = NOVALUE;
    object _11721 = NOVALUE;
    object _11720 = NOVALUE;
    object _11718 = NOVALUE;
    object _11716 = NOVALUE;
    object _11714 = NOVALUE;
    object _11713 = NOVALUE;
    object _11711 = NOVALUE;
    object _11708 = NOVALUE;
    object _11706 = NOVALUE;
    object _11705 = NOVALUE;
    object _11703 = NOVALUE;
    object _11701 = NOVALUE;
    object _11699 = NOVALUE;
    object _11698 = NOVALUE;
    object _11695 = NOVALUE;
    object _11692 = NOVALUE;
    object _11689 = NOVALUE;
    object _11685 = NOVALUE;
    object _11684 = NOVALUE;
    object _11679 = NOVALUE;
    object _11678 = NOVALUE;
    object _11665 = NOVALUE;
    object _11662 = NOVALUE;
    object _11659 = NOVALUE;
    object _11658 = NOVALUE;
    object _11657 = NOVALUE;
    object _11653 = NOVALUE;
    object _11650 = NOVALUE;
    object _11647 = NOVALUE;
    object _11645 = NOVALUE;
    object _11644 = NOVALUE;
    object _0, _1, _2;
    

    /** platform.e:174		sequence local_defines = {}*/
    RefDS(_5);
    DeRef(_local_defines_20788);
    _local_defines_20788 = _5;

    /** platform.e:176		if (IWINDOWS and not for_translator) or (TWINDOWS and for_translator) then*/
    if (_44IWINDOWS_20714 == 0) {
        _11644 = 0;
        goto L1; // [14] 25
    }
    _11645 = (0LL == 0);
    _11644 = (_11645 != 0);
L1: 
    if (_11644 != 0) {
        goto L2; // [25] 44
    }
    if (_44TWINDOWS_20715 == 0) {
        DeRef(_11647);
        _11647 = 0;
        goto L3; // [31] 39
    }
    _11647 = (_for_translator_20787 != 0);
L3: 
    if (_11647 == 0)
    {
        _11647 = NOVALUE;
        goto L4; // [40] 326
    }
    else{
        _11647 = NOVALUE;
    }
L2: 

    /** platform.e:177			local_defines &= {"WINDOWS", "WIN32"}*/
    RefDS(_11649);
    RefDS(_11648);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _11648;
    ((intptr_t *)_2)[2] = _11649;
    _11650 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20788, _local_defines_20788, _11650);
    DeRefDS(_11650);
    _11650 = NOVALUE;

    /** platform.e:178			sequence lcmds = command_line()*/
    DeRef(_lcmds_20798);
    _lcmds_20798 = Command_Line();

    /** platform.e:181			integer fh*/

    /** platform.e:182			fh = open(lcmds[1], "rb")*/
    _2 = (object)SEQ_PTR(_lcmds_20798);
    _11653 = (object)*(((s1_ptr)_2)->base + 1LL);
    _fh_20800 = EOpen(_11653, _8900, 0LL);
    _11653 = NOVALUE;

    /** platform.e:183			if fh = -1 then*/
    if (_fh_20800 != -1LL)
    goto L5; // [73] 123

    /** platform.e:185	 			if match("euiw", lower(lcmds[1])) != 0 then*/
    _2 = (object)SEQ_PTR(_lcmds_20798);
    _11657 = (object)*(((s1_ptr)_2)->base + 1LL);
    RefDS(_11657);
    _11658 = _12lower(_11657);
    _11657 = NOVALUE;
    _11659 = e_match_from(_11656, _11658, 1LL);
    DeRef(_11658);
    _11658 = NOVALUE;
    if (_11659 == 0LL)
    goto L6; // [92] 109

    /** platform.e:186	 				local_defines &= { "GUI" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11661);
    ((intptr_t*)_2)[1] = _11661;
    _11662 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20788, _local_defines_20788, _11662);
    DeRefDS(_11662);
    _11662 = NOVALUE;
    goto L7; // [106] 321
L6: 

    /** platform.e:188	 				local_defines &= { "CONSOLE" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11664);
    ((intptr_t*)_2)[1] = _11664;
    _11665 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20788, _local_defines_20788, _11665);
    DeRefDS(_11665);
    _11665 = NOVALUE;
    goto L7; // [120] 321
L5: 

    /** platform.e:191				atom sk*/

    /** platform.e:192				sk = seek(fh, #18) -- Fixed location of relocation table.*/
    _0 = _sk_20820;
    _sk_20820 = _18seek(_fh_20800, 24LL);
    DeRef(_0);

    /** platform.e:193				sk = get_integer16(fh)*/
    _0 = _sk_20820;
    _sk_20820 = _18get_integer16(_fh_20800);
    DeRef(_0);

    /** platform.e:194				if sk = #40 then*/
    if (binary_op_a(NOTEQ, _sk_20820, 64LL)){
        goto L8; // [140] 259
    }

    /** platform.e:196					sk = seek(fh, #3C) -- Fixed location of COFF signature offset.*/
    _0 = _sk_20820;
    _sk_20820 = _18seek(_fh_20800, 60LL);
    DeRef(_0);

    /** platform.e:197					sk = get_integer32(fh)*/
    _0 = _sk_20820;
    _sk_20820 = _18get_integer32(_fh_20800);
    DeRef(_0);

    /** platform.e:198					sk = seek(fh, sk)*/
    Ref(_sk_20820);
    _0 = _sk_20820;
    _sk_20820 = _18seek(_fh_20800, _sk_20820);
    DeRef(_0);

    /** platform.e:199					sk = get_integer16(fh)*/
    _0 = _sk_20820;
    _sk_20820 = _18get_integer16(_fh_20800);
    DeRef(_0);

    /** platform.e:200					if sk = #4550 then -- "PE" in intel endian*/
    if (binary_op_a(NOTEQ, _sk_20820, 17744LL)){
        goto L9; // [172] 221
    }

    /** platform.e:201						sk = get_integer16(fh)*/
    _0 = _sk_20820;
    _sk_20820 = _18get_integer16(_fh_20800);
    DeRef(_0);

    /** platform.e:202						if sk = 0 then*/
    if (binary_op_a(NOTEQ, _sk_20820, 0LL)){
        goto LA; // [184] 212
    }

    /** platform.e:204							sk = seek(fh, where(fh) + 88 )*/
    _11678 = _18where(_fh_20800);
    if (IS_ATOM_INT(_11678)) {
        _11679 = _11678 + 88LL;
        if ((object)((uintptr_t)_11679 + (uintptr_t)HIGH_BITS) >= 0){
            _11679 = NewDouble((eudouble)_11679);
        }
    }
    else {
        _11679 = binary_op(PLUS, _11678, 88LL);
    }
    DeRef(_11678);
    _11678 = NOVALUE;
    _0 = _sk_20820;
    _sk_20820 = _18seek(_fh_20800, _11679);
    DeRef(_0);
    _11679 = NOVALUE;

    /** platform.e:205							sk = get_integer16(fh)*/
    _0 = _sk_20820;
    _sk_20820 = _18get_integer16(_fh_20800);
    DeRef(_0);
    goto LB; // [209] 265
LA: 

    /** platform.e:207							sk = 0	-- Don't know this format.*/
    DeRef(_sk_20820);
    _sk_20820 = 0LL;
    goto LB; // [218] 265
L9: 

    /** platform.e:209					elsif sk = #454E then -- "NE" in intel endian*/
    if (binary_op_a(NOTEQ, _sk_20820, 17742LL)){
        goto LC; // [223] 250
    }

    /** platform.e:211						sk = seek(fh, where(fh) + 54 )*/
    _11684 = _18where(_fh_20800);
    if (IS_ATOM_INT(_11684)) {
        _11685 = _11684 + 54LL;
        if ((object)((uintptr_t)_11685 + (uintptr_t)HIGH_BITS) >= 0){
            _11685 = NewDouble((eudouble)_11685);
        }
    }
    else {
        _11685 = binary_op(PLUS, _11684, 54LL);
    }
    DeRef(_11684);
    _11684 = NOVALUE;
    _0 = _sk_20820;
    _sk_20820 = _18seek(_fh_20800, _11685);
    DeRef(_0);
    _11685 = NOVALUE;

    /** platform.e:212						sk = getc(fh)*/
    DeRef(_sk_20820);
    if (_fh_20800 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_20800, EF_READ);
        last_r_file_no = _fh_20800;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _sk_20820 = getKBchar();
        }
        else{
            _sk_20820 = getc(last_r_file_ptr);
        }
    }
    else{
        _sk_20820 = getc(last_r_file_ptr);
    }
    goto LB; // [247] 265
LC: 

    /** platform.e:214						sk = 0*/
    DeRef(_sk_20820);
    _sk_20820 = 0LL;
    goto LB; // [256] 265
L8: 

    /** platform.e:217					sk = 0*/
    DeRef(_sk_20820);
    _sk_20820 = 0LL;
LB: 

    /** platform.e:219				if sk = 2 then*/
    if (binary_op_a(NOTEQ, _sk_20820, 2LL)){
        goto LD; // [267] 284
    }

    /** platform.e:220					local_defines &= { "GUI" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11661);
    ((intptr_t*)_2)[1] = _11661;
    _11689 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20788, _local_defines_20788, _11689);
    DeRefDS(_11689);
    _11689 = NOVALUE;
    goto LE; // [281] 314
LD: 

    /** platform.e:221				elsif sk = 3 then*/
    if (binary_op_a(NOTEQ, _sk_20820, 3LL)){
        goto LF; // [286] 303
    }

    /** platform.e:222					local_defines &= { "CONSOLE" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11664);
    ((intptr_t*)_2)[1] = _11664;
    _11692 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20788, _local_defines_20788, _11692);
    DeRefDS(_11692);
    _11692 = NOVALUE;
    goto LE; // [300] 314
LF: 

    /** platform.e:224					local_defines &= { "UNKNOWN" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11694);
    ((intptr_t*)_2)[1] = _11694;
    _11695 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20788, _local_defines_20788, _11695);
    DeRefDS(_11695);
    _11695 = NOVALUE;
LE: 

    /** platform.e:226				close(fh)*/
    EClose(_fh_20800);
    DeRef(_sk_20820);
    _sk_20820 = NOVALUE;
L7: 
    DeRef(_lcmds_20798);
    _lcmds_20798 = NOVALUE;
    goto L10; // [323] 575
L4: 

    /** platform.e:229			local_defines = append( local_defines, "CONSOLE" )*/
    RefDS(_11664);
    Append(&_local_defines_20788, _local_defines_20788, _11664);

    /** platform.e:230			if (ILINUX and not for_translator) or (TLINUX and for_translator) then*/
    if (0LL == 0) {
        _11698 = 0;
        goto L11; // [336] 347
    }
    _11699 = (_for_translator_20787 == 0);
    _11698 = (_11699 != 0);
L11: 
    if (_11698 != 0) {
        goto L12; // [347] 366
    }
    if (0LL == 0) {
        DeRef(_11701);
        _11701 = 0;
        goto L13; // [353] 361
    }
    _11701 = (_for_translator_20787 != 0);
L13: 
    if (_11701 == 0)
    {
        _11701 = NOVALUE;
        goto L14; // [362] 379
    }
    else{
        _11701 = NOVALUE;
    }
L12: 

    /** platform.e:231				local_defines &= {"UNIX", "LINUX"}*/
    RefDS(_11702);
    RefDS(_11435);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _11435;
    ((intptr_t *)_2)[2] = _11702;
    _11703 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20788, _local_defines_20788, _11703);
    DeRefDS(_11703);
    _11703 = NOVALUE;
    goto L15; // [376] 574
L14: 

    /** platform.e:232			elsif (IOSX and not for_translator) or (TOSX and for_translator) then*/
    if (0LL == 0) {
        _11705 = 0;
        goto L16; // [383] 394
    }
    _11706 = (_for_translator_20787 == 0);
    _11705 = (_11706 != 0);
L16: 
    if (_11705 != 0) {
        goto L17; // [394] 413
    }
    if (0LL == 0) {
        DeRef(_11708);
        _11708 = 0;
        goto L18; // [400] 408
    }
    _11708 = (_for_translator_20787 != 0);
L18: 
    if (_11708 == 0)
    {
        _11708 = NOVALUE;
        goto L19; // [409] 428
    }
    else{
        _11708 = NOVALUE;
    }
L17: 

    /** platform.e:233				local_defines &= {"UNIX", "BSD", "OSX"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11435);
    ((intptr_t*)_2)[1] = _11435;
    RefDS(_11709);
    ((intptr_t*)_2)[2] = _11709;
    RefDS(_11710);
    ((intptr_t*)_2)[3] = _11710;
    _11711 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20788, _local_defines_20788, _11711);
    DeRefDS(_11711);
    _11711 = NOVALUE;
    goto L15; // [425] 574
L19: 

    /** platform.e:234			elsif (IOPENBSD and not for_translator) or (TOPENBSD and for_translator) then*/
    if (0LL == 0) {
        _11713 = 0;
        goto L1A; // [432] 443
    }
    _11714 = (_for_translator_20787 == 0);
    _11713 = (_11714 != 0);
L1A: 
    if (_11713 != 0) {
        goto L1B; // [443] 462
    }
    if (0LL == 0) {
        DeRef(_11716);
        _11716 = 0;
        goto L1C; // [449] 457
    }
    _11716 = (_for_translator_20787 != 0);
L1C: 
    if (_11716 == 0)
    {
        _11716 = NOVALUE;
        goto L1D; // [458] 477
    }
    else{
        _11716 = NOVALUE;
    }
L1B: 

    /** platform.e:235				local_defines &= { "UNIX", "BSD", "OPENBSD"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11435);
    ((intptr_t*)_2)[1] = _11435;
    RefDS(_11709);
    ((intptr_t*)_2)[2] = _11709;
    RefDS(_11717);
    ((intptr_t*)_2)[3] = _11717;
    _11718 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20788, _local_defines_20788, _11718);
    DeRefDS(_11718);
    _11718 = NOVALUE;
    goto L15; // [474] 574
L1D: 

    /** platform.e:236			elsif (INETBSD and not for_translator) or (TNETBSD and for_translator) then*/
    if (0LL == 0) {
        _11720 = 0;
        goto L1E; // [481] 492
    }
    _11721 = (_for_translator_20787 == 0);
    _11720 = (_11721 != 0);
L1E: 
    if (_11720 != 0) {
        goto L1F; // [492] 511
    }
    if (0LL == 0) {
        DeRef(_11723);
        _11723 = 0;
        goto L20; // [498] 506
    }
    _11723 = (_for_translator_20787 != 0);
L20: 
    if (_11723 == 0)
    {
        _11723 = NOVALUE;
        goto L21; // [507] 526
    }
    else{
        _11723 = NOVALUE;
    }
L1F: 

    /** platform.e:237				local_defines &= { "UNIX", "BSD", "NETBSD"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11435);
    ((intptr_t*)_2)[1] = _11435;
    RefDS(_11709);
    ((intptr_t*)_2)[2] = _11709;
    RefDS(_11724);
    ((intptr_t*)_2)[3] = _11724;
    _11725 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20788, _local_defines_20788, _11725);
    DeRefDS(_11725);
    _11725 = NOVALUE;
    goto L15; // [523] 574
L21: 

    /** platform.e:238			elsif (IBSD and not for_translator) or (TBSD and for_translator) then*/
    if (0LL == 0) {
        _11727 = 0;
        goto L22; // [530] 541
    }
    _11728 = (_for_translator_20787 == 0);
    _11727 = (_11728 != 0);
L22: 
    if (_11727 != 0) {
        goto L23; // [541] 560
    }
    if (0LL == 0) {
        DeRef(_11730);
        _11730 = 0;
        goto L24; // [547] 555
    }
    _11730 = (_for_translator_20787 != 0);
L24: 
    if (_11730 == 0)
    {
        _11730 = NOVALUE;
        goto L25; // [556] 573
    }
    else{
        _11730 = NOVALUE;
    }
L23: 

    /** platform.e:239				local_defines &= {"UNIX", "BSD", "FREEBSD"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11435);
    ((intptr_t*)_2)[1] = _11435;
    RefDS(_11709);
    ((intptr_t*)_2)[2] = _11709;
    RefDS(_11731);
    ((intptr_t*)_2)[3] = _11731;
    _11732 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20788, _local_defines_20788, _11732);
    DeRefDS(_11732);
    _11732 = NOVALUE;
L25: 
L15: 
L10: 

    /** platform.e:243		if (IX86 and not for_translator) or (TX86 and for_translator) then*/
    if (0LL == 0) {
        _11734 = 0;
        goto L26; // [579] 590
    }
    _11735 = (_for_translator_20787 == 0);
    _11734 = (_11735 != 0);
L26: 
    if (_11734 != 0) {
        goto L27; // [590] 609
    }
    if (0LL == 0) {
        DeRef(_11737);
        _11737 = 0;
        goto L28; // [596] 604
    }
    _11737 = (_for_translator_20787 != 0);
L28: 
    if (_11737 == 0)
    {
        _11737 = NOVALUE;
        goto L29; // [605] 624
    }
    else{
        _11737 = NOVALUE;
    }
L27: 

    /** platform.e:244			local_defines &= {"X86", "BITS32", "LONG32"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11637);
    ((intptr_t*)_2)[1] = _11637;
    RefDS(_11738);
    ((intptr_t*)_2)[2] = _11738;
    RefDS(_11739);
    ((intptr_t*)_2)[3] = _11739;
    _11740 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20788, _local_defines_20788, _11740);
    DeRefDS(_11740);
    _11740 = NOVALUE;
    goto L2A; // [621] 777
L29: 

    /** platform.e:246		elsif (IX86_64 and not for_translator) or (TX86_64 and for_translator) then*/
    if (_44IX86_64_20730 == 0) {
        _11742 = 0;
        goto L2B; // [628] 639
    }
    _11743 = (_for_translator_20787 == 0);
    _11742 = (_11743 != 0);
L2B: 
    if (_11742 != 0) {
        goto L2C; // [639] 658
    }
    if (_44TX86_64_20731 == 0) {
        DeRef(_11745);
        _11745 = 0;
        goto L2D; // [645] 653
    }
    _11745 = (_for_translator_20787 != 0);
L2D: 
    if (_11745 == 0)
    {
        _11745 = NOVALUE;
        goto L2E; // [654] 729
    }
    else{
        _11745 = NOVALUE;
    }
L2C: 

    /** platform.e:247			local_defines &= {"X86_64", "BITS64"}*/
    RefDS(_11746);
    RefDS(_11639);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _11639;
    ((intptr_t *)_2)[2] = _11746;
    _11747 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20788, _local_defines_20788, _11747);
    DeRefDS(_11747);
    _11747 = NOVALUE;

    /** platform.e:248			if (IWINDOWS and not for_translator) or (TWINDOWS and for_translator) then*/
    if (_44IWINDOWS_20714 == 0) {
        _11749 = 0;
        goto L2F; // [672] 683
    }
    _11750 = (_for_translator_20787 == 0);
    _11749 = (_11750 != 0);
L2F: 
    if (_11749 != 0) {
        goto L30; // [683] 702
    }
    if (_44TWINDOWS_20715 == 0) {
        DeRef(_11752);
        _11752 = 0;
        goto L31; // [689] 697
    }
    _11752 = (_for_translator_20787 != 0);
L31: 
    if (_11752 == 0)
    {
        _11752 = NOVALUE;
        goto L32; // [698] 715
    }
    else{
        _11752 = NOVALUE;
    }
L30: 

    /** platform.e:249				local_defines &= {"LONG32"}*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11739);
    ((intptr_t*)_2)[1] = _11739;
    _11753 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20788, _local_defines_20788, _11753);
    DeRefDS(_11753);
    _11753 = NOVALUE;
    goto L2A; // [712] 777
L32: 

    /** platform.e:251				local_defines &= {"LONG64"}*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11755);
    ((intptr_t*)_2)[1] = _11755;
    _11756 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20788, _local_defines_20788, _11756);
    DeRefDS(_11756);
    _11756 = NOVALUE;
    goto L2A; // [726] 777
L2E: 

    /** platform.e:253		elsif (IARM and not for_translator) or (TARM and for_translator) then*/
    if (0LL == 0) {
        _11758 = 0;
        goto L33; // [733] 744
    }
    _11759 = (_for_translator_20787 == 0);
    _11758 = (_11759 != 0);
L33: 
    if (_11758 != 0) {
        goto L34; // [744] 763
    }
    if (0LL == 0) {
        DeRef(_11761);
        _11761 = 0;
        goto L35; // [750] 758
    }
    _11761 = (_for_translator_20787 != 0);
L35: 
    if (_11761 == 0)
    {
        _11761 = NOVALUE;
        goto L36; // [759] 776
    }
    else{
        _11761 = NOVALUE;
    }
L34: 

    /** platform.e:254			local_defines &= {"ARM", "BITS32", "LONG32"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11641);
    ((intptr_t*)_2)[1] = _11641;
    RefDS(_11738);
    ((intptr_t*)_2)[2] = _11738;
    RefDS(_11739);
    ((intptr_t*)_2)[3] = _11739;
    _11762 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20788, _local_defines_20788, _11762);
    DeRefDS(_11762);
    _11762 = NOVALUE;
L36: 
L2A: 

    /** platform.e:259		return { "_PLAT_START" } & local_defines & { "_PLAT_STOP" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11764);
    ((intptr_t*)_2)[1] = _11764;
    _11765 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11766);
    ((intptr_t*)_2)[1] = _11766;
    _11767 = MAKE_SEQ(_1);
    {
        object concat_list[3];

        concat_list[0] = _11767;
        concat_list[1] = _local_defines_20788;
        concat_list[2] = _11765;
        Concat_N((object_ptr)&_11768, concat_list, 3);
    }
    DeRefDS(_11767);
    _11767 = NOVALUE;
    DeRefDS(_11765);
    _11765 = NOVALUE;
    DeRefDS(_local_defines_20788);
    DeRef(_11759);
    _11759 = NOVALUE;
    DeRef(_11706);
    _11706 = NOVALUE;
    DeRef(_11721);
    _11721 = NOVALUE;
    DeRef(_11743);
    _11743 = NOVALUE;
    DeRef(_11728);
    _11728 = NOVALUE;
    DeRef(_11714);
    _11714 = NOVALUE;
    DeRef(_11699);
    _11699 = NOVALUE;
    DeRef(_11645);
    _11645 = NOVALUE;
    DeRef(_11750);
    _11750 = NOVALUE;
    DeRef(_11735);
    _11735 = NOVALUE;
    return _11768;
    ;
}



// 0x1CF8880A
