// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _3sleep(object _t_1594)
{
    object _0, _1, _2;
    

    /** os.e:503		if t >= 0 then*/
    if (binary_op_a(LESS, _t_1594, 0LL)){
        goto L1; // [3] 13
    }

    /** os.e:504			machine_proc(M_SLEEP, t)*/
    machine(64LL, _t_1594);
L1: 

    /** os.e:506	end procedure*/
    DeRef(_t_1594);
    return;
    ;
}



// 0x8A30E08D
