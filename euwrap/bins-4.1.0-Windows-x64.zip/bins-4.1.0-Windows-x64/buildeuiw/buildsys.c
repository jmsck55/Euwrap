// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _55update_checksum(object _raw_data_45826)
{
    object _23855 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:213		cfile_check = xor_bits(cfile_check, hash( raw_data, stdhash:HSIEH32))*/
    _23855 = calc_hash(_raw_data_45826, -5LL);
    _0 = _55cfile_check_45807;
    if (IS_ATOM_INT(_55cfile_check_45807) && IS_ATOM_INT(_23855)) {
        {uintptr_t tu;
             tu = (uintptr_t)_55cfile_check_45807 ^ (uintptr_t)_23855;
             _55cfile_check_45807 = MAKE_UINT(tu);
        }
    }
    else {
        if (IS_ATOM_INT(_55cfile_check_45807)) {
            temp_d.dbl = (eudouble)_55cfile_check_45807;
            _55cfile_check_45807 = Dxor_bits(&temp_d, DBL_PTR(_23855));
        }
        else {
            if (IS_ATOM_INT(_23855)) {
                temp_d.dbl = (eudouble)_23855;
                _55cfile_check_45807 = Dxor_bits(DBL_PTR(_55cfile_check_45807), &temp_d);
            }
            else
            _55cfile_check_45807 = Dxor_bits(DBL_PTR(_55cfile_check_45807), DBL_PTR(_23855));
        }
    }
    DeRef(_0);
    DeRef(_23855);
    _23855 = NOVALUE;

    /** buildsys.e:214	end procedure*/
    DeRef(_raw_data_45826);
    return;
    ;
}


void _55write_checksum(object _file_45831)
{
    object _0, _1, _2;
    

    /** buildsys.e:219		printf( file, "\n// 0x%08x\n", cfile_check )*/
    EPrintf(_file_45831, _23857, _55cfile_check_45807);

    /** buildsys.e:220		cfile_check = 0*/
    DeRef(_55cfile_check_45807);
    _55cfile_check_45807 = 0LL;

    /** buildsys.e:221	end procedure*/
    return;
    ;
}


object _55find_file_element(object _needle_45835, object _files_45836)
{
    object _23873 = NOVALUE;
    object _23872 = NOVALUE;
    object _23871 = NOVALUE;
    object _23870 = NOVALUE;
    object _23869 = NOVALUE;
    object _23868 = NOVALUE;
    object _23867 = NOVALUE;
    object _23866 = NOVALUE;
    object _23865 = NOVALUE;
    object _23864 = NOVALUE;
    object _23863 = NOVALUE;
    object _23862 = NOVALUE;
    object _23861 = NOVALUE;
    object _23860 = NOVALUE;
    object _23859 = NOVALUE;
    object _23858 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:228		for j = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_45836)){
            _23858 = SEQ_PTR(_files_45836)->length;
    }
    else {
        _23858 = 1;
    }
    {
        object _j_45838;
        _j_45838 = 1LL;
L1: 
        if (_j_45838 > _23858){
            goto L2; // [10] 50
        }

        /** buildsys.e:229			if equal(files[j][D_NAME],needle) then*/
        _2 = (object)SEQ_PTR(_files_45836);
        _23859 = (object)*(((s1_ptr)_2)->base + _j_45838);
        _2 = (object)SEQ_PTR(_23859);
        _23860 = (object)*(((s1_ptr)_2)->base + 1LL);
        _23859 = NOVALUE;
        if (_23860 == _needle_45835)
        _23861 = 1;
        else if (IS_ATOM_INT(_23860) && IS_ATOM_INT(_needle_45835))
        _23861 = 0;
        else
        _23861 = (compare(_23860, _needle_45835) == 0);
        _23860 = NOVALUE;
        if (_23861 == 0)
        {
            _23861 = NOVALUE;
            goto L3; // [33] 43
        }
        else{
            _23861 = NOVALUE;
        }

        /** buildsys.e:230				return j*/
        DeRefDS(_needle_45835);
        DeRefDS(_files_45836);
        return _j_45838;
L3: 

        /** buildsys.e:232		end for*/
        _j_45838 = _j_45838 + 1LL;
        goto L1; // [45] 17
L2: 
        ;
    }

    /** buildsys.e:233		for j = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_45836)){
            _23862 = SEQ_PTR(_files_45836)->length;
    }
    else {
        _23862 = 1;
    }
    {
        object _j_45846;
        _j_45846 = 1LL;
L4: 
        if (_j_45846 > _23862){
            goto L5; // [55] 103
        }

        /** buildsys.e:234			if equal(lower(files[j][D_NAME]),lower(needle)) then*/
        _2 = (object)SEQ_PTR(_files_45836);
        _23863 = (object)*(((s1_ptr)_2)->base + _j_45846);
        _2 = (object)SEQ_PTR(_23863);
        _23864 = (object)*(((s1_ptr)_2)->base + 1LL);
        _23863 = NOVALUE;
        Ref(_23864);
        _23865 = _12lower(_23864);
        _23864 = NOVALUE;
        RefDS(_needle_45835);
        _23866 = _12lower(_needle_45835);
        if (_23865 == _23866)
        _23867 = 1;
        else if (IS_ATOM_INT(_23865) && IS_ATOM_INT(_23866))
        _23867 = 0;
        else
        _23867 = (compare(_23865, _23866) == 0);
        DeRef(_23865);
        _23865 = NOVALUE;
        DeRef(_23866);
        _23866 = NOVALUE;
        if (_23867 == 0)
        {
            _23867 = NOVALUE;
            goto L6; // [86] 96
        }
        else{
            _23867 = NOVALUE;
        }

        /** buildsys.e:235				return j*/
        DeRefDS(_needle_45835);
        DeRefDS(_files_45836);
        return _j_45846;
L6: 

        /** buildsys.e:237		end for*/
        _j_45846 = _j_45846 + 1LL;
        goto L4; // [98] 62
L5: 
        ;
    }

    /** buildsys.e:239		for j = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_45836)){
            _23868 = SEQ_PTR(_files_45836)->length;
    }
    else {
        _23868 = 1;
    }
    {
        object _j_45858;
        _j_45858 = 1LL;
L7: 
        if (_j_45858 > _23868){
            goto L8; // [108] 156
        }

        /** buildsys.e:240			if equal(lower(files[j][D_ALTNAME]),lower(needle)) then*/
        _2 = (object)SEQ_PTR(_files_45836);
        _23869 = (object)*(((s1_ptr)_2)->base + _j_45858);
        _2 = (object)SEQ_PTR(_23869);
        _23870 = (object)*(((s1_ptr)_2)->base + 11LL);
        _23869 = NOVALUE;
        Ref(_23870);
        _23871 = _12lower(_23870);
        _23870 = NOVALUE;
        RefDS(_needle_45835);
        _23872 = _12lower(_needle_45835);
        if (_23871 == _23872)
        _23873 = 1;
        else if (IS_ATOM_INT(_23871) && IS_ATOM_INT(_23872))
        _23873 = 0;
        else
        _23873 = (compare(_23871, _23872) == 0);
        DeRef(_23871);
        _23871 = NOVALUE;
        DeRef(_23872);
        _23872 = NOVALUE;
        if (_23873 == 0)
        {
            _23873 = NOVALUE;
            goto L9; // [139] 149
        }
        else{
            _23873 = NOVALUE;
        }

        /** buildsys.e:241				return j*/
        DeRefDS(_needle_45835);
        DeRefDS(_files_45836);
        return _j_45858;
L9: 

        /** buildsys.e:243		end for*/
        _j_45858 = _j_45858 + 1LL;
        goto L7; // [151] 115
L8: 
        ;
    }

    /** buildsys.e:244		return 0*/
    DeRefDS(_needle_45835);
    DeRefDS(_files_45836);
    return 0LL;
    ;
}


object _55adjust_for_command_line_passing(object _long_path_45879)
{
    object _slash_45880 = NOVALUE;
    object _longs_45889 = NOVALUE;
    object _short_path_45895 = NOVALUE;
    object _files_45901 = NOVALUE;
    object _file_location_45904 = NOVALUE;
    object _23913 = NOVALUE;
    object _23912 = NOVALUE;
    object _23910 = NOVALUE;
    object _23909 = NOVALUE;
    object _23907 = NOVALUE;
    object _23906 = NOVALUE;
    object _23904 = NOVALUE;
    object _23903 = NOVALUE;
    object _23900 = NOVALUE;
    object _23899 = NOVALUE;
    object _23897 = NOVALUE;
    object _23896 = NOVALUE;
    object _23895 = NOVALUE;
    object _23894 = NOVALUE;
    object _23893 = NOVALUE;
    object _23891 = NOVALUE;
    object _23890 = NOVALUE;
    object _23888 = NOVALUE;
    object _23886 = NOVALUE;
    object _23884 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:310		if compiler_type = COMPILER_GCC then*/

    /** buildsys.e:312		elsif compiler_type = COMPILER_WATCOM then*/

    /** buildsys.e:315			slash = SLASH*/
    _slash_45880 = 92LL;

    /** buildsys.e:317		ifdef UNIX then*/

    /** buildsys.e:320			long_path = regex:find_replace(quote_pattern, long_path, "")*/
    Ref(_55quote_pattern_45872);
    RefDS(_long_path_45879);
    RefDS(_22218);
    _0 = _long_path_45879;
    _long_path_45879 = _51find_replace(_55quote_pattern_45872, _long_path_45879, _22218, 1LL, 0LL);
    DeRefDS(_0);

    /** buildsys.e:321			sequence longs = split( slash_pattern, long_path )*/
    Ref(_55slash_pattern_45869);
    RefDS(_long_path_45879);
    _0 = _longs_45889;
    _longs_45889 = _51split(_55slash_pattern_45869, _long_path_45879, 1LL, 0LL);
    DeRef(_0);

    /** buildsys.e:322			if length(longs)=0 then*/
    if (IS_SEQUENCE(_longs_45889)){
            _23884 = SEQ_PTR(_longs_45889)->length;
    }
    else {
        _23884 = 1;
    }
    if (_23884 != 0LL)
    goto L1; // [79] 90

    /** buildsys.e:323				return long_path*/
    DeRefDS(_longs_45889);
    DeRef(_short_path_45895);
    return _long_path_45879;
L1: 

    /** buildsys.e:325			sequence short_path = longs[1] & slash*/
    _2 = (object)SEQ_PTR(_longs_45889);
    _23886 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_23886) && IS_ATOM(_slash_45880)) {
        Append(&_short_path_45895, _23886, _slash_45880);
    }
    else if (IS_ATOM(_23886) && IS_SEQUENCE(_slash_45880)) {
    }
    else {
        Concat((object_ptr)&_short_path_45895, _23886, _slash_45880);
        _23886 = NOVALUE;
    }
    _23886 = NOVALUE;

    /** buildsys.e:326			for i = 2 to length(longs) do*/
    if (IS_SEQUENCE(_longs_45889)){
            _23888 = SEQ_PTR(_longs_45889)->length;
    }
    else {
        _23888 = 1;
    }
    {
        object _i_45899;
        _i_45899 = 2LL;
L2: 
        if (_i_45899 > _23888){
            goto L3; // [107] 266
        }

        /** buildsys.e:327				object files = dir(short_path)*/
        RefDS(_short_path_45895);
        _0 = _files_45901;
        _files_45901 = _15dir(_short_path_45895);
        DeRef(_0);

        /** buildsys.e:328				integer file_location = 0*/
        _file_location_45904 = 0LL;

        /** buildsys.e:329				if sequence(files) then*/
        _23890 = IS_SEQUENCE(_files_45901);
        if (_23890 == 0)
        {
            _23890 = NOVALUE;
            goto L4; // [130] 147
        }
        else{
            _23890 = NOVALUE;
        }

        /** buildsys.e:330					file_location = find_file_element(longs[i], files)*/
        _2 = (object)SEQ_PTR(_longs_45889);
        _23891 = (object)*(((s1_ptr)_2)->base + _i_45899);
        Ref(_23891);
        Ref(_files_45901);
        _file_location_45904 = _55find_file_element(_23891, _files_45901);
        _23891 = NOVALUE;
        if (!IS_ATOM_INT(_file_location_45904)) {
            _1 = (object)(DBL_PTR(_file_location_45904)->dbl);
            DeRefDS(_file_location_45904);
            _file_location_45904 = _1;
        }
L4: 

        /** buildsys.e:332				if file_location then*/
        if (_file_location_45904 == 0)
        {
            goto L5; // [149] 215
        }
        else{
        }

        /** buildsys.e:333					if sequence(files[file_location][D_ALTNAME]) then*/
        _2 = (object)SEQ_PTR(_files_45901);
        _23893 = (object)*(((s1_ptr)_2)->base + _file_location_45904);
        _2 = (object)SEQ_PTR(_23893);
        _23894 = (object)*(((s1_ptr)_2)->base + 11LL);
        _23893 = NOVALUE;
        _23895 = IS_SEQUENCE(_23894);
        _23894 = NOVALUE;
        if (_23895 == 0)
        {
            _23895 = NOVALUE;
            goto L6; // [167] 189
        }
        else{
            _23895 = NOVALUE;
        }

        /** buildsys.e:334						short_path &= files[file_location][D_ALTNAME]*/
        _2 = (object)SEQ_PTR(_files_45901);
        _23896 = (object)*(((s1_ptr)_2)->base + _file_location_45904);
        _2 = (object)SEQ_PTR(_23896);
        _23897 = (object)*(((s1_ptr)_2)->base + 11LL);
        _23896 = NOVALUE;
        if (IS_SEQUENCE(_short_path_45895) && IS_ATOM(_23897)) {
            Ref(_23897);
            Append(&_short_path_45895, _short_path_45895, _23897);
        }
        else if (IS_ATOM(_short_path_45895) && IS_SEQUENCE(_23897)) {
        }
        else {
            Concat((object_ptr)&_short_path_45895, _short_path_45895, _23897);
        }
        _23897 = NOVALUE;
        goto L7; // [186] 206
L6: 

        /** buildsys.e:336						short_path &= files[file_location][D_NAME]*/
        _2 = (object)SEQ_PTR(_files_45901);
        _23899 = (object)*(((s1_ptr)_2)->base + _file_location_45904);
        _2 = (object)SEQ_PTR(_23899);
        _23900 = (object)*(((s1_ptr)_2)->base + 1LL);
        _23899 = NOVALUE;
        if (IS_SEQUENCE(_short_path_45895) && IS_ATOM(_23900)) {
            Ref(_23900);
            Append(&_short_path_45895, _short_path_45895, _23900);
        }
        else if (IS_ATOM(_short_path_45895) && IS_SEQUENCE(_23900)) {
        }
        else {
            Concat((object_ptr)&_short_path_45895, _short_path_45895, _23900);
        }
        _23900 = NOVALUE;
L7: 

        /** buildsys.e:338					short_path &= slash*/
        Append(&_short_path_45895, _short_path_45895, _slash_45880);
        goto L8; // [212] 257
L5: 

        /** buildsys.e:340					if not find(' ',longs[i]) then*/
        _2 = (object)SEQ_PTR(_longs_45889);
        _23903 = (object)*(((s1_ptr)_2)->base + _i_45899);
        _23904 = find_from(32LL, _23903, 1LL);
        _23903 = NOVALUE;
        if (_23904 != 0)
        goto L9; // [226] 250
        _23904 = NOVALUE;

        /** buildsys.e:341						short_path &= longs[i] & slash*/
        _2 = (object)SEQ_PTR(_longs_45889);
        _23906 = (object)*(((s1_ptr)_2)->base + _i_45899);
        if (IS_SEQUENCE(_23906) && IS_ATOM(_slash_45880)) {
            Append(&_23907, _23906, _slash_45880);
        }
        else if (IS_ATOM(_23906) && IS_SEQUENCE(_slash_45880)) {
        }
        else {
            Concat((object_ptr)&_23907, _23906, _slash_45880);
            _23906 = NOVALUE;
        }
        _23906 = NOVALUE;
        Concat((object_ptr)&_short_path_45895, _short_path_45895, _23907);
        DeRefDS(_23907);
        _23907 = NOVALUE;

        /** buildsys.e:342						continue*/
        DeRef(_files_45901);
        _files_45901 = NOVALUE;
        goto LA; // [247] 261
L9: 

        /** buildsys.e:344					return 0*/
        DeRef(_files_45901);
        DeRefDS(_long_path_45879);
        DeRef(_longs_45889);
        DeRef(_short_path_45895);
        return 0LL;
L8: 
        DeRef(_files_45901);
        _files_45901 = NOVALUE;

        /** buildsys.e:346			end for -- i*/
LA: 
        _i_45899 = _i_45899 + 1LL;
        goto L2; // [261] 114
L3: 
        ;
    }

    /** buildsys.e:347			if short_path[$] = slash then*/
    if (IS_SEQUENCE(_short_path_45895)){
            _23909 = SEQ_PTR(_short_path_45895)->length;
    }
    else {
        _23909 = 1;
    }
    _2 = (object)SEQ_PTR(_short_path_45895);
    _23910 = (object)*(((s1_ptr)_2)->base + _23909);
    if (binary_op_a(NOTEQ, _23910, _slash_45880)){
        _23910 = NOVALUE;
        goto LB; // [275] 294
    }
    _23910 = NOVALUE;

    /** buildsys.e:348				short_path = short_path[1..$-1]*/
    if (IS_SEQUENCE(_short_path_45895)){
            _23912 = SEQ_PTR(_short_path_45895)->length;
    }
    else {
        _23912 = 1;
    }
    _23913 = _23912 - 1LL;
    _23912 = NOVALUE;
    rhs_slice_target = (object_ptr)&_short_path_45895;
    RHS_Slice(_short_path_45895, 1LL, _23913);
LB: 

    /** buildsys.e:350			return short_path*/
    DeRefDS(_long_path_45879);
    DeRef(_longs_45889);
    DeRef(_23913);
    _23913 = NOVALUE;
    return _short_path_45895;
    ;
}


object _55adjust_for_build_file(object _long_path_45942)
{
    object _short_path_45943 = NOVALUE;
    object _23921 = NOVALUE;
    object _23920 = NOVALUE;
    object _23919 = NOVALUE;
    object _23918 = NOVALUE;
    object _23917 = NOVALUE;
    object _23916 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:355	    object short_path = adjust_for_command_line_passing(long_path)*/
    RefDS(_long_path_45942);
    _0 = _short_path_45943;
    _short_path_45943 = _55adjust_for_command_line_passing(_long_path_45942);
    DeRef(_0);

    /** buildsys.e:356	    if atom(short_path) then*/
    _23916 = IS_ATOM(_short_path_45943);
    if (_23916 == 0)
    {
        _23916 = NOVALUE;
        goto L1; // [14] 24
    }
    else{
        _23916 = NOVALUE;
    }

    /** buildsys.e:357	    	return short_path*/
    DeRefDS(_long_path_45942);
    return _short_path_45943;
L1: 

    /** buildsys.e:359		if compiler_type = COMPILER_GCC and build_system_type != BUILD_DIRECT and TWINDOWS then*/
    _23917 = (0LL == 1LL);
    if (_23917 == 0) {
        _23918 = 0;
        goto L2; // [32] 46
    }
    _23919 = (3LL != 3LL);
    _23918 = (_23919 != 0);
L2: 
    if (_23918 == 0) {
        goto L3; // [46] 69
    }
    if (_44TWINDOWS_20715 == 0)
    {
        goto L3; // [53] 69
    }
    else{
    }

    /** buildsys.e:360			return windows_to_mingw_path(short_path)*/
    Ref(_short_path_45943);
    _23921 = _55windows_to_mingw_path(_short_path_45943);
    DeRefDS(_long_path_45942);
    DeRef(_short_path_45943);
    DeRef(_23919);
    _23919 = NOVALUE;
    DeRef(_23917);
    _23917 = NOVALUE;
    return _23921;
    goto L4; // [66] 76
L3: 

    /** buildsys.e:362			return short_path*/
    DeRefDS(_long_path_45942);
    DeRef(_23921);
    _23921 = NOVALUE;
    DeRef(_23919);
    _23919 = NOVALUE;
    DeRef(_23917);
    _23917 = NOVALUE;
    return _short_path_45943;
L4: 
    ;
}


object _55setup_build()
{
    object _c_exe_45958 = NOVALUE;
    object _c_flags_45959 = NOVALUE;
    object _l_exe_45960 = NOVALUE;
    object _l_flags_45961 = NOVALUE;
    object _obj_ext_45962 = NOVALUE;
    object _exe_ext_45963 = NOVALUE;
    object _l_flags_begin_45964 = NOVALUE;
    object _rc_comp_45965 = NOVALUE;
    object _l_names_45966 = NOVALUE;
    object _l_ext_45967 = NOVALUE;
    object _t_slash_45968 = NOVALUE;
    object _eudir_46010 = NOVALUE;
    object _compile_dir_46068 = NOVALUE;
    object _bits_46079 = NOVALUE;
    object _m_flag_46089 = NOVALUE;
    object _24078 = NOVALUE;
    object _24075 = NOVALUE;
    object _24074 = NOVALUE;
    object _24071 = NOVALUE;
    object _24070 = NOVALUE;
    object _24067 = NOVALUE;
    object _24066 = NOVALUE;
    object _24063 = NOVALUE;
    object _24062 = NOVALUE;
    object _24055 = NOVALUE;
    object _24054 = NOVALUE;
    object _24049 = NOVALUE;
    object _24048 = NOVALUE;
    object _24043 = NOVALUE;
    object _24042 = NOVALUE;
    object _24039 = NOVALUE;
    object _24038 = NOVALUE;
    object _24026 = NOVALUE;
    object _24025 = NOVALUE;
    object _24010 = NOVALUE;
    object _24009 = NOVALUE;
    object _24001 = NOVALUE;
    object _23999 = NOVALUE;
    object _23998 = NOVALUE;
    object _23997 = NOVALUE;
    object _23996 = NOVALUE;
    object _23992 = NOVALUE;
    object _23991 = NOVALUE;
    object _23977 = NOVALUE;
    object _23976 = NOVALUE;
    object _23973 = NOVALUE;
    object _23961 = NOVALUE;
    object _23957 = NOVALUE;
    object _23954 = NOVALUE;
    object _23953 = NOVALUE;
    object _23952 = NOVALUE;
    object _23949 = NOVALUE;
    object _23948 = NOVALUE;
    object _23947 = NOVALUE;
    object _23944 = NOVALUE;
    object _23940 = NOVALUE;
    object _23939 = NOVALUE;
    object _23937 = NOVALUE;
    object _23936 = NOVALUE;
    object _23935 = NOVALUE;
    object _23934 = NOVALUE;
    object _23927 = NOVALUE;
    object _23926 = NOVALUE;
    object _23925 = NOVALUE;
    object _23924 = NOVALUE;
    object _23923 = NOVALUE;
    object _23922 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:373			c_exe   = "",*/
    RefDS(_22218);
    DeRef(_c_exe_45958);
    _c_exe_45958 = _22218;

    /** buildsys.e:374			c_flags = "",*/
    RefDS(_22218);
    DeRef(_c_flags_45959);
    _c_flags_45959 = _22218;

    /** buildsys.e:375			l_exe   = "",*/
    RefDS(_22218);
    DeRef(_l_exe_45960);
    _l_exe_45960 = _22218;

    /** buildsys.e:376			l_flags = "",*/
    RefDS(_22218);
    DeRefi(_l_flags_45961);
    _l_flags_45961 = _22218;

    /** buildsys.e:377			obj_ext = "",*/
    RefDS(_22218);
    DeRefi(_obj_ext_45962);
    _obj_ext_45962 = _22218;

    /** buildsys.e:378			exe_ext = "",*/
    RefDS(_22218);
    DeRefi(_exe_ext_45963);
    _exe_ext_45963 = _22218;

    /** buildsys.e:379			l_flags_begin = "",*/
    RefDS(_22218);
    DeRefi(_l_flags_begin_45964);
    _l_flags_begin_45964 = _22218;

    /** buildsys.e:380			rc_comp = "",*/
    RefDS(_22218);
    DeRef(_rc_comp_45965);
    _rc_comp_45965 = _22218;

    /** buildsys.e:385		if dll_option*/
    if (_57dll_option_42963 == 0) {
        _23922 = 0;
        goto L1; // [61] 78
    }
    _23923 = 0;
    _23924 = (0LL > 0LL);
    _23923 = NOVALUE;
    _23922 = (_23924 != 0);
L1: 
    if (_23922 == 0) {
        goto L2; // [78] 101
    }
    _23926 = (_44TWINDOWS_20715 == 0);
    if (_23926 == 0)
    {
        DeRef(_23926);
        _23926 = NOVALUE;
        goto L2; // [88] 101
    }
    else{
        DeRef(_23926);
        _23926 = NOVALUE;
    }

    /** buildsys.e:388			user_library = user_pic_library*/
    RefDS(_57user_pic_library_42976);
    DeRef(_57user_library_42975);
    _57user_library_42975 = _57user_pic_library_42976;
L2: 

    /** buildsys.e:391		if length(user_library) = 0 then*/
    if (IS_SEQUENCE(_57user_library_42975)){
            _23927 = SEQ_PTR(_57user_library_42975)->length;
    }
    else {
        _23927 = 1;
    }
    if (_23927 != 0LL)
    goto L3; // [108] 366

    /** buildsys.e:392			if debug_option then*/
    if (_57debug_option_42973 == 0)
    {
        goto L4; // [116] 128
    }
    else{
    }

    /** buildsys.e:393				l_names = { "eudbg", "eu" }*/
    RefDS(_23930);
    RefDS(_23929);
    DeRef(_l_names_45966);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _23929;
    ((intptr_t *)_2)[2] = _23930;
    _l_names_45966 = MAKE_SEQ(_1);
    goto L5; // [125] 135
L4: 

    /** buildsys.e:395				l_names = { "eu", "eudbg" }*/
    RefDS(_23929);
    RefDS(_23930);
    DeRef(_l_names_45966);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _23930;
    ((intptr_t *)_2)[2] = _23929;
    _l_names_45966 = MAKE_SEQ(_1);
L5: 

    /** buildsys.e:400			if TUNIX or compiler_type = COMPILER_GCC then*/
    if (0LL != 0) {
        goto L6; // [139] 154
    }
    _23934 = (0LL == 1LL);
    if (_23934 == 0)
    {
        DeRef(_23934);
        _23934 = NOVALUE;
        goto L7; // [150] 224
    }
    else{
        DeRef(_23934);
        _23934 = NOVALUE;
    }
L6: 

    /** buildsys.e:401				l_ext = "a"*/
    RefDS(_22511);
    DeRefi(_l_ext_45967);
    _l_ext_45967 = _22511;

    /** buildsys.e:402				t_slash = "/"*/
    RefDS(_23818);
    DeRefi(_t_slash_45968);
    _t_slash_45968 = _23818;

    /** buildsys.e:403				if dll_option and not TWINDOWS then*/
    if (_57dll_option_42963 == 0) {
        goto L8; // [172] 247
    }
    _23936 = (_44TWINDOWS_20715 == 0);
    if (_23936 == 0)
    {
        DeRef(_23936);
        _23936 = NOVALUE;
        goto L8; // [182] 247
    }
    else{
        DeRef(_23936);
        _23936 = NOVALUE;
    }

    /** buildsys.e:404					for i = 1 to length( l_names ) do*/
    if (IS_SEQUENCE(_l_names_45966)){
            _23937 = SEQ_PTR(_l_names_45966)->length;
    }
    else {
        _23937 = 1;
    }
    {
        object _i_46001;
        _i_46001 = 1LL;
L9: 
        if (_i_46001 > _23937){
            goto LA; // [192] 220
        }

        /** buildsys.e:406						l_names[i] &= "so"*/
        _2 = (object)SEQ_PTR(_l_names_45966);
        _23939 = (object)*(((s1_ptr)_2)->base + _i_46001);
        if (IS_SEQUENCE(_23939) && IS_ATOM(_23938)) {
        }
        else if (IS_ATOM(_23939) && IS_SEQUENCE(_23938)) {
            Ref(_23939);
            Prepend(&_23940, _23938, _23939);
        }
        else {
            Concat((object_ptr)&_23940, _23939, _23938);
            _23939 = NOVALUE;
        }
        _23939 = NOVALUE;
        _2 = (object)SEQ_PTR(_l_names_45966);
        _2 = (object)(((s1_ptr)_2)->base + _i_46001);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _23940;
        if( _1 != _23940 ){
            DeRef(_1);
        }
        _23940 = NOVALUE;

        /** buildsys.e:407					end for*/
        _i_46001 = _i_46001 + 1LL;
        goto L9; // [215] 199
LA: 
        ;
    }
    goto L8; // [221] 247
L7: 

    /** buildsys.e:409			elsif TWINDOWS then*/
    if (_44TWINDOWS_20715 == 0)
    {
        goto LB; // [228] 246
    }
    else{
    }

    /** buildsys.e:410				l_ext = "lib"*/
    RefDS(_23941);
    DeRefi(_l_ext_45967);
    _l_ext_45967 = _23941;

    /** buildsys.e:411				t_slash = "\\"*/
    RefDS(_23942);
    DeRefi(_t_slash_45968);
    _t_slash_45968 = _23942;
LB: 
L8: 

    /** buildsys.e:414			object eudir = get_eucompiledir()*/
    _0 = _eudir_46010;
    _eudir_46010 = _57get_eucompiledir();
    DeRef(_0);

    /** buildsys.e:415			if not file_exists(eudir) then*/
    Ref(_eudir_46010);
    _23944 = _15file_exists(_eudir_46010);
    if (IS_ATOM_INT(_23944)) {
        if (_23944 != 0){
            DeRef(_23944);
            _23944 = NOVALUE;
            goto LC; // [258] 279
        }
    }
    else {
        if (DBL_PTR(_23944)->dbl != 0.0){
            DeRef(_23944);
            _23944 = NOVALUE;
            goto LC; // [258] 279
        }
    }
    DeRef(_23944);
    _23944 = NOVALUE;

    /** buildsys.e:416				printf(2,"Supplied directory \'%s\' is not a valid EUDIR\n",{get_eucompiledir()})*/
    _23947 = _57get_eucompiledir();
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _23947;
    _23948 = MAKE_SEQ(_1);
    _23947 = NOVALUE;
    EPrintf(2LL, _23946, _23948);
    DeRefDS(_23948);
    _23948 = NOVALUE;

    /** buildsys.e:417				abort(1)*/
    UserCleanup(1LL);
LC: 

    /** buildsys.e:419			for tk = 1 to length(l_names) label "translation kind" do*/
    if (IS_SEQUENCE(_l_names_45966)){
            _23949 = SEQ_PTR(_l_names_45966)->length;
    }
    else {
        _23949 = 1;
    }
    {
        object _tk_46022;
        _tk_46022 = 1LL;
LD: 
        if (_tk_46022 > _23949){
            goto LE; // [286] 365
        }

        /** buildsys.e:420				user_library = eudir & sprintf("%sbin%s%s.%s",{t_slash, t_slash, l_names[tk],l_ext})*/
        _2 = (object)SEQ_PTR(_l_names_45966);
        _23952 = (object)*(((s1_ptr)_2)->base + _tk_46022);
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        RefDSn(_t_slash_45968, 2);
        ((intptr_t*)_2)[1] = _t_slash_45968;
        ((intptr_t*)_2)[2] = _t_slash_45968;
        Ref(_23952);
        ((intptr_t*)_2)[3] = _23952;
        RefDS(_l_ext_45967);
        ((intptr_t*)_2)[4] = _l_ext_45967;
        _23953 = MAKE_SEQ(_1);
        _23952 = NOVALUE;
        _23954 = EPrintf(-9999999, _23951, _23953);
        DeRefDS(_23953);
        _23953 = NOVALUE;
        if (IS_SEQUENCE(_eudir_46010) && IS_ATOM(_23954)) {
        }
        else if (IS_ATOM(_eudir_46010) && IS_SEQUENCE(_23954)) {
            Ref(_eudir_46010);
            Prepend(&_57user_library_42975, _23954, _eudir_46010);
        }
        else {
            Concat((object_ptr)&_57user_library_42975, _eudir_46010, _23954);
        }
        DeRefDS(_23954);
        _23954 = NOVALUE;

        /** buildsys.e:421				if TUNIX or compiler_type = COMPILER_GCC then*/
        if (0LL != 0) {
            goto LF; // [324] 339
        }
        _23957 = (0LL == 1LL);
        if (_23957 == 0)
        {
            DeRef(_23957);
            _23957 = NOVALUE;
            goto L10; // [335] 342
        }
        else{
            DeRef(_23957);
            _23957 = NOVALUE;
        }
LF: 

        /** buildsys.e:422					ifdef UNIX then*/
L10: 

        /** buildsys.e:436				if file_exists(user_library) then*/
        RefDS(_57user_library_42975);
        _23961 = _15file_exists(_57user_library_42975);
        if (_23961 == 0) {
            DeRef(_23961);
            _23961 = NOVALUE;
            goto L11; // [350] 358
        }
        else {
            if (!IS_ATOM_INT(_23961) && DBL_PTR(_23961)->dbl == 0.0){
                DeRef(_23961);
                _23961 = NOVALUE;
                goto L11; // [350] 358
            }
            DeRef(_23961);
            _23961 = NOVALUE;
        }
        DeRef(_23961);
        _23961 = NOVALUE;

        /** buildsys.e:437					exit "translation kind"*/
        goto LE; // [355] 365
L11: 

        /** buildsys.e:439			end for -- tk*/
        _tk_46022 = _tk_46022 + 1LL;
        goto LD; // [360] 293
LE: 
        ;
    }
L3: 
    DeRef(_eudir_46010);
    _eudir_46010 = NOVALUE;

    /** buildsys.e:441		user_library = adjust_for_build_file(user_library)*/
    RefDS(_57user_library_42975);
    _0 = _55adjust_for_build_file(_57user_library_42975);
    DeRefDS(_57user_library_42975);
    _57user_library_42975 = _0;

    /** buildsys.e:443		if TWINDOWS then*/
    if (_44TWINDOWS_20715 == 0)
    {
        goto L12; // [382] 437
    }
    else{
    }

    /** buildsys.e:444			if compiler_type = COMPILER_WATCOM then*/

    /** buildsys.e:447				c_flags &= " -DEWINDOWS"*/
    Concat((object_ptr)&_c_flags_45959, _c_flags_45959, _23966);

    /** buildsys.e:450			if dll_option then*/
    if (_57dll_option_42963 == 0)
    {
        goto L13; // [413] 426
    }
    else{
    }

    /** buildsys.e:451				exe_ext = ".dll"*/
    RefDS(_23968);
    DeRefi(_exe_ext_45963);
    _exe_ext_45963 = _23968;
    goto L14; // [423] 478
L13: 

    /** buildsys.e:453				exe_ext = ".exe"*/
    RefDS(_23969);
    DeRefi(_exe_ext_45963);
    _exe_ext_45963 = _23969;
    goto L14; // [434] 478
L12: 

    /** buildsys.e:455		elsif TOSX then*/

    /** buildsys.e:460			if dll_option then*/
    if (_57dll_option_42963 == 0)
    {
        goto L15; // [466] 477
    }
    else{
    }

    /** buildsys.e:461				exe_ext = ".so"*/
    RefDS(_23971);
    DeRefi(_exe_ext_45963);
    _exe_ext_45963 = _23971;
L15: 
L14: 

    /** buildsys.e:465		object compile_dir = get_eucompiledir()*/
    _0 = _compile_dir_46068;
    _compile_dir_46068 = _57get_eucompiledir();
    DeRef(_0);

    /** buildsys.e:466		if not file_exists(compile_dir) then*/
    Ref(_compile_dir_46068);
    _23973 = _15file_exists(_compile_dir_46068);
    if (IS_ATOM_INT(_23973)) {
        if (_23973 != 0){
            DeRef(_23973);
            _23973 = NOVALUE;
            goto L16; // [489] 510
        }
    }
    else {
        if (DBL_PTR(_23973)->dbl != 0.0){
            DeRef(_23973);
            _23973 = NOVALUE;
            goto L16; // [489] 510
        }
    }
    DeRef(_23973);
    _23973 = NOVALUE;

    /** buildsys.e:467			printf(2,"Couldn't get include directory '%s'",{get_eucompiledir()})*/
    _23976 = _57get_eucompiledir();
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _23976;
    _23977 = MAKE_SEQ(_1);
    _23976 = NOVALUE;
    EPrintf(2LL, _23975, _23977);
    DeRefDS(_23977);
    _23977 = NOVALUE;

    /** buildsys.e:468			abort(1)*/
    UserCleanup(1LL);
L16: 

    /** buildsys.e:471		integer bits = 32*/
    _bits_46079 = 32LL;

    /** buildsys.e:472		if TX86_64 then*/
    if (_44TX86_64_20731 == 0)
    {
        goto L17; // [519] 528
    }
    else{
    }

    /** buildsys.e:473			bits = 64*/
    _bits_46079 = 64LL;
L17: 

    /** buildsys.e:476		switch compiler_type do*/
    _0 = 0LL;
    switch ( _0 ){ 

        /** buildsys.e:477			case COMPILER_GCC then*/
        case 1:

        /** buildsys.e:478				c_exe = compiler_prefix & "gcc"*/
        Concat((object_ptr)&_c_exe_45958, _55compiler_prefix_45791, _23980);

        /** buildsys.e:479				l_exe = compiler_prefix & "gcc"*/
        Concat((object_ptr)&_l_exe_45960, _55compiler_prefix_45791, _23980);

        /** buildsys.e:480				obj_ext = "o"*/
        RefDS(_23983);
        DeRefi(_obj_ext_45962);
        _obj_ext_45962 = _23983;

        /** buildsys.e:482				sequence m_flag = ""*/
        RefDS(_22218);
        DeRefi(_m_flag_46089);
        _m_flag_46089 = _22218;

        /** buildsys.e:483				if not TARM then*/

        /** buildsys.e:485					m_flag = sprintf( "-m%d", bits )*/
        DeRefDSi(_m_flag_46089);
        _m_flag_46089 = EPrintf(-9999999, _23985, _bits_46079);

        /** buildsys.e:488				if debug_option then*/
        if (_57debug_option_42973 == 0)
        {
            goto L18; // [589] 601
        }
        else{
        }

        /** buildsys.e:489					c_flags &= " -g3"*/
        Concat((object_ptr)&_c_flags_45959, _c_flags_45959, _23987);
        goto L19; // [598] 608
L18: 

        /** buildsys.e:491					c_flags &= " -fomit-frame-pointer"*/
        Concat((object_ptr)&_c_flags_45959, _c_flags_45959, _23989);
L19: 

        /** buildsys.e:494				if dll_option and not TWINDOWS then*/
        if (_57dll_option_42963 == 0) {
            goto L1A; // [612] 632
        }
        _23992 = (_44TWINDOWS_20715 == 0);
        if (_23992 == 0)
        {
            DeRef(_23992);
            _23992 = NOVALUE;
            goto L1A; // [622] 632
        }
        else{
            DeRef(_23992);
            _23992 = NOVALUE;
        }

        /** buildsys.e:495					c_flags &= " -fPIC"*/
        Concat((object_ptr)&_c_flags_45959, _c_flags_45959, _23993);
L1A: 

        /** buildsys.e:498				c_flags &= sprintf(" -c -w -fsigned-char -O2 %s -I%s -ffast-math",*/
        _23996 = _57get_eucompiledir();
        _23997 = _55adjust_for_build_file(_23996);
        _23996 = NOVALUE;
        RefDS(_m_flag_46089);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _m_flag_46089;
        ((intptr_t *)_2)[2] = _23997;
        _23998 = MAKE_SEQ(_1);
        _23997 = NOVALUE;
        _23999 = EPrintf(-9999999, _23995, _23998);
        DeRefDS(_23998);
        _23998 = NOVALUE;
        Concat((object_ptr)&_c_flags_45959, _c_flags_45959, _23999);
        DeRefDS(_23999);
        _23999 = NOVALUE;

        /** buildsys.e:501				if TWINDOWS and mno_cygwin then*/
        if (_44TWINDOWS_20715 == 0) {
            goto L1B; // [657] 674
        }
        goto L1B; // [664] 674

        /** buildsys.e:504					c_flags &= " -mno-cygwin"*/
        Concat((object_ptr)&_c_flags_45959, _c_flags_45959, _24002);
L1B: 

        /** buildsys.e:507				if build_system_type != BUILD_DIRECT then*/

        /** buildsys.e:510					l_flags = sprintf( " %s %s",*/
        RefDS(_57user_library_42975);
        _24009 = _55adjust_for_command_line_passing(_57user_library_42975);
        RefDS(_m_flag_46089);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _24009;
        ((intptr_t *)_2)[2] = _m_flag_46089;
        _24010 = MAKE_SEQ(_1);
        _24009 = NOVALUE;
        DeRefi(_l_flags_45961);
        _l_flags_45961 = EPrintf(-9999999, _24008, _24010);
        DeRefDS(_24010);
        _24010 = NOVALUE;

        /** buildsys.e:514				if dll_option then*/
        if (_57dll_option_42963 == 0)
        {
            goto L1C; // [716] 726
        }
        else{
        }

        /** buildsys.e:515					l_flags &= " -shared "*/
        Concat((object_ptr)&_l_flags_45961, _l_flags_45961, _24012);
L1C: 

        /** buildsys.e:518				if TLINUX then*/

        /** buildsys.e:520				elsif TBSD then*/

        /** buildsys.e:522				elsif TOSX then*/

        /** buildsys.e:524				elsif TWINDOWS then*/
        if (_44TWINDOWS_20715 == 0)
        {
            goto L1D; // [778] 810
        }
        else{
        }

        /** buildsys.e:525					if mno_cygwin then*/

        /** buildsys.e:529					if not con_option then*/
        if (_57con_option_42965 != 0)
        goto L1E; // [799] 809

        /** buildsys.e:532						l_flags &= " -mwindows"*/
        Concat((object_ptr)&_l_flags_45961, _l_flags_45961, _24022);
L1E: 
L1D: 

        /** buildsys.e:537				rc_comp = compiler_prefix & "windres -DSRCDIR=\"" & adjust_for_build_file(current_dir()) & "\" [1] -O coff -o [2]"*/
        _24025 = _15current_dir();
        _24026 = _55adjust_for_build_file(_24025);
        _24025 = NOVALUE;
        {
            object concat_list[4];

            concat_list[0] = _24027;
            concat_list[1] = _24026;
            concat_list[2] = _24024;
            concat_list[3] = _55compiler_prefix_45791;
            Concat_N((object_ptr)&_rc_comp_45965, concat_list, 4);
        }
        DeRef(_24026);
        _24026 = NOVALUE;
        DeRefi(_m_flag_46089);
        _m_flag_46089 = NOVALUE;
        goto L1F; // [831] 1037

        /** buildsys.e:539			case COMPILER_WATCOM then*/
        case 2:

        /** buildsys.e:540				c_exe = compiler_prefix & "wcc386"*/
        Concat((object_ptr)&_c_exe_45958, _55compiler_prefix_45791, _24029);

        /** buildsys.e:541				l_exe = compiler_prefix & "wlink"*/
        Concat((object_ptr)&_l_exe_45960, _55compiler_prefix_45791, _24031);

        /** buildsys.e:542				obj_ext = "obj"*/
        RefDS(_24033);
        DeRefi(_obj_ext_45962);
        _obj_ext_45962 = _24033;

        /** buildsys.e:544				if debug_option then*/
        if (_57debug_option_42973 == 0)
        {
            goto L20; // [864] 881
        }
        else{
        }

        /** buildsys.e:545					c_flags = " /d3"*/
        RefDS(_24034);
        DeRef(_c_flags_45959);
        _c_flags_45959 = _24034;

        /** buildsys.e:546					l_flags_begin &= " DEBUG ALL "*/
        Concat((object_ptr)&_l_flags_begin_45964, _l_flags_begin_45964, _24035);
L20: 

        /** buildsys.e:549				l_flags &= sprintf(" OPTION STACK=%d ", { total_stack_size })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _57total_stack_size_42978;
        _24038 = MAKE_SEQ(_1);
        _24039 = EPrintf(-9999999, _24037, _24038);
        DeRefDS(_24038);
        _24038 = NOVALUE;
        Concat((object_ptr)&_l_flags_45961, _l_flags_45961, _24039);
        DeRefDS(_24039);
        _24039 = NOVALUE;

        /** buildsys.e:550				l_flags &= sprintf(" COMMIT STACK=%d ", { total_stack_size })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _57total_stack_size_42978;
        _24042 = MAKE_SEQ(_1);
        _24043 = EPrintf(-9999999, _24041, _24042);
        DeRefDS(_24042);
        _24042 = NOVALUE;
        Concat((object_ptr)&_l_flags_45961, _l_flags_45961, _24043);
        DeRefDS(_24043);
        _24043 = NOVALUE;

        /** buildsys.e:551				l_flags &= " OPTION QUIET OPTION ELIMINATE OPTION CASEEXACT"*/
        Concat((object_ptr)&_l_flags_45961, _l_flags_45961, _24045);

        /** buildsys.e:553				if dll_option then*/
        if (_57dll_option_42963 == 0)
        {
            goto L21; // [923] 949
        }
        else{
        }

        /** buildsys.e:554					c_flags &= " /bd /bt=nt /mf /w0 /zq /j /zp4 /fp5 /fpi87 /5r /otimra /s /I" & adjust_for_build_file(compile_dir) */
        Ref(_compile_dir_46068);
        _24048 = _55adjust_for_build_file(_compile_dir_46068);
        if (IS_SEQUENCE(_24047) && IS_ATOM(_24048)) {
            Ref(_24048);
            Append(&_24049, _24047, _24048);
        }
        else if (IS_ATOM(_24047) && IS_SEQUENCE(_24048)) {
        }
        else {
            Concat((object_ptr)&_24049, _24047, _24048);
        }
        DeRef(_24048);
        _24048 = NOVALUE;
        Concat((object_ptr)&_c_flags_45959, _c_flags_45959, _24049);
        DeRefDS(_24049);
        _24049 = NOVALUE;

        /** buildsys.e:555					l_flags &= " SYSTEM NT_DLL initinstance terminstance"*/
        Concat((object_ptr)&_l_flags_45961, _l_flags_45961, _24051);
        goto L22; // [946] 987
L21: 

        /** buildsys.e:557					c_flags &= " /bt=nt /mf /w0 /zq /j /zp4 /fp5 /fpi87 /5r /otimra /s /I" & adjust_for_build_file(compile_dir)*/
        Ref(_compile_dir_46068);
        _24054 = _55adjust_for_build_file(_compile_dir_46068);
        if (IS_SEQUENCE(_24053) && IS_ATOM(_24054)) {
            Ref(_24054);
            Append(&_24055, _24053, _24054);
        }
        else if (IS_ATOM(_24053) && IS_SEQUENCE(_24054)) {
        }
        else {
            Concat((object_ptr)&_24055, _24053, _24054);
        }
        DeRef(_24054);
        _24054 = NOVALUE;
        Concat((object_ptr)&_c_flags_45959, _c_flags_45959, _24055);
        DeRefDS(_24055);
        _24055 = NOVALUE;

        /** buildsys.e:558					if con_option then*/
        if (_57con_option_42965 == 0)
        {
            goto L23; // [967] 979
        }
        else{
        }

        /** buildsys.e:560						l_flags = " SYSTEM NT" & l_flags*/
        Concat((object_ptr)&_l_flags_45961, _24057, _l_flags_45961);
        goto L24; // [976] 986
L23: 

        /** buildsys.e:562						l_flags = " SYSTEM NT_WIN RUNTIME WINDOWS=4.0" & l_flags*/
        Concat((object_ptr)&_l_flags_45961, _24059, _l_flags_45961);
L24: 
L22: 

        /** buildsys.e:566				l_flags &= sprintf(" FILE %s", { (user_library) })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_57user_library_42975);
        ((intptr_t*)_2)[1] = _57user_library_42975;
        _24062 = MAKE_SEQ(_1);
        _24063 = EPrintf(-9999999, _24061, _24062);
        DeRefDS(_24062);
        _24062 = NOVALUE;
        Concat((object_ptr)&_l_flags_45961, _l_flags_45961, _24063);
        DeRefDS(_24063);
        _24063 = NOVALUE;

        /** buildsys.e:570				rc_comp = compiler_prefix &"wrc -DSRCDIR=\"" & adjust_for_build_file(current_dir()) & "\" -q -fo=[2] -ad [1] [3]"*/
        _24066 = _15current_dir();
        _24067 = _55adjust_for_build_file(_24066);
        _24066 = NOVALUE;
        {
            object concat_list[4];

            concat_list[0] = _24068;
            concat_list[1] = _24067;
            concat_list[2] = _24065;
            concat_list[3] = _55compiler_prefix_45791;
            Concat_N((object_ptr)&_rc_comp_45965, concat_list, 4);
        }
        DeRef(_24067);
        _24067 = NOVALUE;
        goto L1F; // [1021] 1037

        /** buildsys.e:571			case else*/
        default:

        /** buildsys.e:572				CompileErr(COMPILER_IS_UNKNOWN)*/
        RefDS(_22218);
        _49CompileErr(43LL, _22218, 0LL);
    ;}L1F: 

    /** buildsys.e:575		if length(cflags) then*/
    _24070 = 0;

    /** buildsys.e:580		if length(extra_cflags) then*/
    _24071 = 0;

    /** buildsys.e:584		if length(lflags) then*/
    _24074 = 0;

    /** buildsys.e:589		if length(extra_lflags) then*/
    _24075 = 0;

    /** buildsys.e:593		return { */
    _1 = NewS1(9);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_c_exe_45958);
    ((intptr_t*)_2)[1] = _c_exe_45958;
    RefDS(_c_flags_45959);
    ((intptr_t*)_2)[2] = _c_flags_45959;
    RefDS(_l_exe_45960);
    ((intptr_t*)_2)[3] = _l_exe_45960;
    RefDS(_l_flags_45961);
    ((intptr_t*)_2)[4] = _l_flags_45961;
    RefDS(_obj_ext_45962);
    ((intptr_t*)_2)[5] = _obj_ext_45962;
    RefDS(_exe_ext_45963);
    ((intptr_t*)_2)[6] = _exe_ext_45963;
    RefDS(_l_flags_begin_45964);
    ((intptr_t*)_2)[7] = _l_flags_begin_45964;
    RefDS(_rc_comp_45965);
    ((intptr_t*)_2)[8] = _rc_comp_45965;
    RefDS(_57user_library_42975);
    ((intptr_t*)_2)[9] = _57user_library_42975;
    _24078 = MAKE_SEQ(_1);
    DeRefDS(_c_exe_45958);
    DeRefDS(_c_flags_45959);
    DeRefDS(_l_exe_45960);
    DeRefDSi(_l_flags_45961);
    DeRefDSi(_obj_ext_45962);
    DeRefDSi(_exe_ext_45963);
    DeRefDSi(_l_flags_begin_45964);
    DeRefDS(_rc_comp_45965);
    DeRef(_l_names_45966);
    DeRefi(_l_ext_45967);
    DeRefi(_t_slash_45968);
    DeRef(_compile_dir_46068);
    DeRef(_23924);
    _23924 = NOVALUE;
    return _24078;
    ;
}


void _55ensure_exename(object _ext_46236)
{
    object _24085 = NOVALUE;
    object _24084 = NOVALUE;
    object _24083 = NOVALUE;
    object _24082 = NOVALUE;
    object _24080 = NOVALUE;
    object _24079 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:602		if length(exe_name[D_ALTNAME]) = 0 then*/
    _2 = (object)SEQ_PTR(_55exe_name_45793);
    _24079 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (IS_SEQUENCE(_24079)){
            _24080 = SEQ_PTR(_24079)->length;
    }
    else {
        _24080 = 1;
    }
    _24079 = NOVALUE;
    if (_24080 != 0LL)
    goto L1; // [16] 67

    /** buildsys.e:603			exe_name[D_NAME] = current_dir() & SLASH & file0 & ext*/
    _24082 = _15current_dir();
    {
        object concat_list[4];

        concat_list[0] = _ext_46236;
        concat_list[1] = _57file0_44926;
        concat_list[2] = 92LL;
        concat_list[3] = _24082;
        Concat_N((object_ptr)&_24083, concat_list, 4);
    }
    DeRef(_24082);
    _24082 = NOVALUE;
    _2 = (object)SEQ_PTR(_55exe_name_45793);
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24083;
    if( _1 != _24083 ){
        DeRef(_1);
    }
    _24083 = NOVALUE;

    /** buildsys.e:604			exe_name[D_ALTNAME] = adjust_for_command_line_passing(exe_name[D_NAME])*/
    _2 = (object)SEQ_PTR(_55exe_name_45793);
    _24084 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_24084);
    _24085 = _55adjust_for_command_line_passing(_24084);
    _24084 = NOVALUE;
    _2 = (object)SEQ_PTR(_55exe_name_45793);
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24085;
    if( _1 != _24085 ){
        DeRef(_1);
    }
    _24085 = NOVALUE;
L1: 

    /** buildsys.e:606	end procedure*/
    DeRefDS(_ext_46236);
    _24079 = NOVALUE;
    return;
    ;
}


void _55write_objlink_file()
{
    object _settings_46254 = NOVALUE;
    object _fh_46256 = NOVALUE;
    object _s_46304 = NOVALUE;
    object _24134 = NOVALUE;
    object _24132 = NOVALUE;
    object _24131 = NOVALUE;
    object _24130 = NOVALUE;
    object _24129 = NOVALUE;
    object _24128 = NOVALUE;
    object _24127 = NOVALUE;
    object _24126 = NOVALUE;
    object _24125 = NOVALUE;
    object _24124 = NOVALUE;
    object _24123 = NOVALUE;
    object _24122 = NOVALUE;
    object _24121 = NOVALUE;
    object _24119 = NOVALUE;
    object _24118 = NOVALUE;
    object _24117 = NOVALUE;
    object _24116 = NOVALUE;
    object _24114 = NOVALUE;
    object _24113 = NOVALUE;
    object _24112 = NOVALUE;
    object _24111 = NOVALUE;
    object _24110 = NOVALUE;
    object _24109 = NOVALUE;
    object _24103 = NOVALUE;
    object _24102 = NOVALUE;
    object _24099 = NOVALUE;
    object _24098 = NOVALUE;
    object _24097 = NOVALUE;
    object _24096 = NOVALUE;
    object _24095 = NOVALUE;
    object _24093 = NOVALUE;
    object _24092 = NOVALUE;
    object _24091 = NOVALUE;
    object _24088 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:612		sequence settings = setup_build()*/
    _0 = _settings_46254;
    _settings_46254 = _55setup_build();
    DeRef(_0);

    /** buildsys.e:613		integer fh = open(output_dir & file0 & ".lnk", "wb")*/
    {
        object concat_list[3];

        concat_list[0] = _24087;
        concat_list[1] = _57file0_44926;
        concat_list[2] = _57output_dir_42977;
        Concat_N((object_ptr)&_24088, concat_list, 3);
    }
    _fh_46256 = EOpen(_24088, _24089, 0LL);
    DeRefDS(_24088);
    _24088 = NOVALUE;

    /** buildsys.e:615		ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (object)SEQ_PTR(_settings_46254);
    _24091 = (object)*(((s1_ptr)_2)->base + 6LL);
    Ref(_24091);
    _55ensure_exename(_24091);
    _24091 = NOVALUE;

    /** buildsys.e:617		if length(settings[SETUP_LFLAGS_BEGIN]) > 0 then*/
    _2 = (object)SEQ_PTR(_settings_46254);
    _24092 = (object)*(((s1_ptr)_2)->base + 7LL);
    if (IS_SEQUENCE(_24092)){
            _24093 = SEQ_PTR(_24092)->length;
    }
    else {
        _24093 = 1;
    }
    _24092 = NOVALUE;
    if (_24093 <= 0LL)
    goto L1; // [43] 63

    /** buildsys.e:618			puts(fh, settings[SETUP_LFLAGS_BEGIN] & HOSTNL)*/
    _2 = (object)SEQ_PTR(_settings_46254);
    _24095 = (object)*(((s1_ptr)_2)->base + 7LL);
    if (IS_SEQUENCE(_24095) && IS_ATOM(_44HOSTNL_20738)) {
    }
    else if (IS_ATOM(_24095) && IS_SEQUENCE(_44HOSTNL_20738)) {
        Ref(_24095);
        Prepend(&_24096, _44HOSTNL_20738, _24095);
    }
    else {
        Concat((object_ptr)&_24096, _24095, _44HOSTNL_20738);
        _24095 = NOVALUE;
    }
    _24095 = NOVALUE;
    EPuts(_fh_46256, _24096); // DJP 
    DeRefDS(_24096);
    _24096 = NOVALUE;
L1: 

    /** buildsys.e:621		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_42967)){
            _24097 = SEQ_PTR(_57generated_files_42967)->length;
    }
    else {
        _24097 = 1;
    }
    {
        object _i_46272;
        _i_46272 = 1LL;
L2: 
        if (_i_46272 > _24097){
            goto L3; // [70] 132
        }

        /** buildsys.e:622			if match(".o", generated_files[i]) then*/
        _2 = (object)SEQ_PTR(_57generated_files_42967);
        _24098 = (object)*(((s1_ptr)_2)->base + _i_46272);
        _24099 = e_match_from(_23382, _24098, 1LL);
        _24098 = NOVALUE;
        if (_24099 == 0)
        {
            _24099 = NOVALUE;
            goto L4; // [90] 125
        }
        else{
            _24099 = NOVALUE;
        }

        /** buildsys.e:623				if compiler_type = COMPILER_WATCOM then*/

        /** buildsys.e:627				puts(fh, generated_files[i] & HOSTNL)*/
        _2 = (object)SEQ_PTR(_57generated_files_42967);
        _24102 = (object)*(((s1_ptr)_2)->base + _i_46272);
        Concat((object_ptr)&_24103, _24102, _44HOSTNL_20738);
        _24102 = NOVALUE;
        _24102 = NOVALUE;
        EPuts(_fh_46256, _24103); // DJP 
        DeRefDS(_24103);
        _24103 = NOVALUE;
L4: 

        /** buildsys.e:629		end for*/
        _i_46272 = _i_46272 + 1LL;
        goto L2; // [127] 77
L3: 
        ;
    }

    /** buildsys.e:631		if compiler_type = COMPILER_WATCOM then*/

    /** buildsys.e:635		puts(fh, trim(settings[SETUP_LFLAGS] & HOSTNL))*/
    _2 = (object)SEQ_PTR(_settings_46254);
    _24109 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_SEQUENCE(_24109) && IS_ATOM(_44HOSTNL_20738)) {
    }
    else if (IS_ATOM(_24109) && IS_SEQUENCE(_44HOSTNL_20738)) {
        Ref(_24109);
        Prepend(&_24110, _44HOSTNL_20738, _24109);
    }
    else {
        Concat((object_ptr)&_24110, _24109, _44HOSTNL_20738);
        _24109 = NOVALUE;
    }
    _24109 = NOVALUE;
    RefDS(_4905);
    _24111 = _12trim(_24110, _4905, 0LL);
    _24110 = NOVALUE;
    EPuts(_fh_46256, _24111); // DJP 
    DeRef(_24111);
    _24111 = NOVALUE;

    /** buildsys.e:637		if compiler_type = COMPILER_WATCOM and dll_option then*/
    _24112 = (0LL == 2LL);
    if (_24112 == 0) {
        goto L5; // [194] 361
    }
    if (_57dll_option_42963 == 0)
    {
        goto L5; // [201] 361
    }
    else{
    }

    /** buildsys.e:638			puts(fh, HOSTNL)*/
    EPuts(_fh_46256, _44HOSTNL_20738); // DJP 

    /** buildsys.e:640			object s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24114 = (object)*(((s1_ptr)_2)->base + _27TopLevelSub_20578);
    DeRef(_s_46304);
    _2 = (object)SEQ_PTR(_24114);
    _s_46304 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_s_46304);
    _24114 = NOVALUE;

    /** buildsys.e:641			while s do*/
L6: 
    if (_s_46304 <= 0) {
        if (_s_46304 == 0) {
            goto L7; // [232] 360
        }
        else {
            if (!IS_ATOM_INT(_s_46304) && DBL_PTR(_s_46304)->dbl == 0.0){
                goto L7; // [232] 360
            }
        }
    }

    /** buildsys.e:642				if eu:find(SymTab[s][S_TOKEN], RTN_TOKS) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_s_46304)){
        _24116 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_46304)->dbl));
    }
    else{
        _24116 = (object)*(((s1_ptr)_2)->base + _s_46304);
    }
    _2 = (object)SEQ_PTR(_24116);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _24117 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _24117 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _24116 = NOVALUE;
    _24118 = find_from(_24117, _29RTN_TOKS_12277, 1LL);
    _24117 = NOVALUE;
    if (_24118 == 0)
    {
        _24118 = NOVALUE;
        goto L8; // [256] 341
    }
    else{
        _24118 = NOVALUE;
    }

    /** buildsys.e:643					if is_exported( s ) then*/
    Ref(_s_46304);
    _24119 = _57is_exported(_s_46304);
    if (_24119 == 0) {
        DeRef(_24119);
        _24119 = NOVALUE;
        goto L9; // [265] 340
    }
    else {
        if (!IS_ATOM_INT(_24119) && DBL_PTR(_24119)->dbl == 0.0){
            DeRef(_24119);
            _24119 = NOVALUE;
            goto L9; // [265] 340
        }
        DeRef(_24119);
        _24119 = NOVALUE;
    }
    DeRef(_24119);
    _24119 = NOVALUE;

    /** buildsys.e:644						printf(fh, "EXPORT %s='__%d%s@%d'" & HOSTNL,*/
    Concat((object_ptr)&_24121, _24120, _44HOSTNL_20738);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_s_46304)){
        _24122 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_46304)->dbl));
    }
    else{
        _24122 = (object)*(((s1_ptr)_2)->base + _s_46304);
    }
    _2 = (object)SEQ_PTR(_24122);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _24123 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _24123 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _24122 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_s_46304)){
        _24124 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_46304)->dbl));
    }
    else{
        _24124 = (object)*(((s1_ptr)_2)->base + _s_46304);
    }
    _2 = (object)SEQ_PTR(_24124);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _24125 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _24125 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _24124 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_s_46304)){
        _24126 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_46304)->dbl));
    }
    else{
        _24126 = (object)*(((s1_ptr)_2)->base + _s_46304);
    }
    _2 = (object)SEQ_PTR(_24126);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _24127 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _24127 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _24126 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_s_46304)){
        _24128 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_46304)->dbl));
    }
    else{
        _24128 = (object)*(((s1_ptr)_2)->base + _s_46304);
    }
    _2 = (object)SEQ_PTR(_24128);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _24129 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _24129 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _24128 = NOVALUE;
    if (IS_ATOM_INT(_24129)) {
        {
            int128_t p128 = (int128_t)_24129 * (int128_t)4LL;
            if( p128 != (int128_t)(_24130 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _24130 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _24130 = binary_op(MULTIPLY, _24129, 4LL);
    }
    _24129 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24123);
    ((intptr_t*)_2)[1] = _24123;
    Ref(_24125);
    ((intptr_t*)_2)[2] = _24125;
    Ref(_24127);
    ((intptr_t*)_2)[3] = _24127;
    ((intptr_t*)_2)[4] = _24130;
    _24131 = MAKE_SEQ(_1);
    _24130 = NOVALUE;
    _24127 = NOVALUE;
    _24125 = NOVALUE;
    _24123 = NOVALUE;
    EPrintf(_fh_46256, _24121, _24131);
    DeRefDS(_24121);
    _24121 = NOVALUE;
    DeRefDS(_24131);
    _24131 = NOVALUE;
L9: 
L8: 

    /** buildsys.e:649				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_s_46304)){
        _24132 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_46304)->dbl));
    }
    else{
        _24132 = (object)*(((s1_ptr)_2)->base + _s_46304);
    }
    DeRef(_s_46304);
    _2 = (object)SEQ_PTR(_24132);
    _s_46304 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_s_46304);
    _24132 = NOVALUE;

    /** buildsys.e:650			end while*/
    goto L6; // [357] 232
L7: 
L5: 
    DeRef(_s_46304);
    _s_46304 = NOVALUE;

    /** buildsys.e:653		close(fh)*/
    EClose(_fh_46256);

    /** buildsys.e:655		generated_files = append(generated_files, file0 & ".lnk")*/
    Concat((object_ptr)&_24134, _57file0_44926, _24087);
    RefDS(_24134);
    Append(&_57generated_files_42967, _57generated_files_42967, _24134);
    DeRefDS(_24134);
    _24134 = NOVALUE;

    /** buildsys.e:656	end procedure*/
    DeRef(_settings_46254);
    DeRef(_24112);
    _24112 = NOVALUE;
    _24092 = NOVALUE;
    return;
    ;
}


void _55write_makefile_srcobj_list(object _fh_46353)
{
    object _file_count_46384 = NOVALUE;
    object _24167 = NOVALUE;
    object _24166 = NOVALUE;
    object _24165 = NOVALUE;
    object _24163 = NOVALUE;
    object _24162 = NOVALUE;
    object _24161 = NOVALUE;
    object _24159 = NOVALUE;
    object _24158 = NOVALUE;
    object _24156 = NOVALUE;
    object _24155 = NOVALUE;
    object _24154 = NOVALUE;
    object _24153 = NOVALUE;
    object _24152 = NOVALUE;
    object _24151 = NOVALUE;
    object _24149 = NOVALUE;
    object _24148 = NOVALUE;
    object _24147 = NOVALUE;
    object _24142 = NOVALUE;
    object _24141 = NOVALUE;
    object _24140 = NOVALUE;
    object _24139 = NOVALUE;
    object _24138 = NOVALUE;
    object _24137 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:660		printf(fh, "%s_SOURCES =", { upper(file0) })*/
    RefDS(_57file0_44926);
    _24137 = _12upper(_57file0_44926);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24137;
    _24138 = MAKE_SEQ(_1);
    _24137 = NOVALUE;
    EPrintf(_fh_46353, _24136, _24138);
    DeRefDS(_24138);
    _24138 = NOVALUE;

    /** buildsys.e:661		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_42967)){
            _24139 = SEQ_PTR(_57generated_files_42967)->length;
    }
    else {
        _24139 = 1;
    }
    {
        object _i_46360;
        _i_46360 = 1LL;
L1: 
        if (_i_46360 > _24139){
            goto L2; // [26] 94
        }

        /** buildsys.e:662			if generated_files[i][$] = 'c' then*/
        _2 = (object)SEQ_PTR(_57generated_files_42967);
        _24140 = (object)*(((s1_ptr)_2)->base + _i_46360);
        if (IS_SEQUENCE(_24140)){
                _24141 = SEQ_PTR(_24140)->length;
        }
        else {
            _24141 = 1;
        }
        _2 = (object)SEQ_PTR(_24140);
        _24142 = (object)*(((s1_ptr)_2)->base + _24141);
        _24140 = NOVALUE;
        if (binary_op_a(NOTEQ, _24142, 99LL)){
            _24142 = NOVALUE;
            goto L3; // [48] 87
        }
        _24142 = NOVALUE;

        /** buildsys.e:663				if i > 1 then*/
        if (_i_46360 <= 1LL)
        goto L4; // [54] 71

        /** buildsys.e:664					printf(fh, " \\%s\t", { HOSTNL }  )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_44HOSTNL_20738);
        ((intptr_t*)_2)[1] = _44HOSTNL_20738;
        _24147 = MAKE_SEQ(_1);
        EPrintf(_fh_46353, _24146, _24147);
        DeRefDS(_24147);
        _24147 = NOVALUE;
L4: 

        /** buildsys.e:666				puts(fh, " " & generated_files[i])*/
        _2 = (object)SEQ_PTR(_57generated_files_42967);
        _24148 = (object)*(((s1_ptr)_2)->base + _i_46360);
        Concat((object_ptr)&_24149, _23627, _24148);
        _24148 = NOVALUE;
        EPuts(_fh_46353, _24149); // DJP 
        DeRefDS(_24149);
        _24149 = NOVALUE;
L3: 

        /** buildsys.e:668		end for*/
        _i_46360 = _i_46360 + 1LL;
        goto L1; // [89] 33
L2: 
        ;
    }

    /** buildsys.e:669		puts(fh, HOSTNL)*/
    EPuts(_fh_46353, _44HOSTNL_20738); // DJP 

    /** buildsys.e:671		printf(fh, "%s_OBJECTS =", { upper(file0) })*/
    RefDS(_57file0_44926);
    _24151 = _12upper(_57file0_44926);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24151;
    _24152 = MAKE_SEQ(_1);
    _24151 = NOVALUE;
    EPrintf(_fh_46353, _24150, _24152);
    DeRefDS(_24152);
    _24152 = NOVALUE;

    /** buildsys.e:672		integer file_count = 0*/
    _file_count_46384 = 0LL;

    /** buildsys.e:673		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_42967)){
            _24153 = SEQ_PTR(_57generated_files_42967)->length;
    }
    else {
        _24153 = 1;
    }
    {
        object _i_46386;
        _i_46386 = 1LL;
L5: 
        if (_i_46386 > _24153){
            goto L6; // [129] 199
        }

        /** buildsys.e:674			if match(".o", generated_files[i]) then*/
        _2 = (object)SEQ_PTR(_57generated_files_42967);
        _24154 = (object)*(((s1_ptr)_2)->base + _i_46386);
        _24155 = e_match_from(_23382, _24154, 1LL);
        _24154 = NOVALUE;
        if (_24155 == 0)
        {
            _24155 = NOVALUE;
            goto L7; // [149] 192
        }
        else{
            _24155 = NOVALUE;
        }

        /** buildsys.e:675				if file_count then*/
        if (_file_count_46384 == 0)
        {
            goto L8; // [154] 170
        }
        else{
        }

        /** buildsys.e:676					printf(fh, " \\%s\t", { HOSTNL }  )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_44HOSTNL_20738);
        ((intptr_t*)_2)[1] = _44HOSTNL_20738;
        _24156 = MAKE_SEQ(_1);
        EPrintf(_fh_46353, _24146, _24156);
        DeRefDS(_24156);
        _24156 = NOVALUE;
L8: 

        /** buildsys.e:678				file_count += 1*/
        _file_count_46384 = _file_count_46384 + 1;

        /** buildsys.e:679				puts(fh, " " & generated_files[i])*/
        _2 = (object)SEQ_PTR(_57generated_files_42967);
        _24158 = (object)*(((s1_ptr)_2)->base + _i_46386);
        Concat((object_ptr)&_24159, _23627, _24158);
        _24158 = NOVALUE;
        EPuts(_fh_46353, _24159); // DJP 
        DeRefDS(_24159);
        _24159 = NOVALUE;
L7: 

        /** buildsys.e:681		end for*/
        _i_46386 = _i_46386 + 1LL;
        goto L5; // [194] 136
L6: 
        ;
    }

    /** buildsys.e:682		puts(fh, HOSTNL)*/
    EPuts(_fh_46353, _44HOSTNL_20738); // DJP 

    /** buildsys.e:684		printf(fh, "%s_GENERATED_FILES = ", { upper(file0) })*/
    RefDS(_57file0_44926);
    _24161 = _12upper(_57file0_44926);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24161;
    _24162 = MAKE_SEQ(_1);
    _24161 = NOVALUE;
    EPrintf(_fh_46353, _24160, _24162);
    DeRefDS(_24162);
    _24162 = NOVALUE;

    /** buildsys.e:685		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_42967)){
            _24163 = SEQ_PTR(_57generated_files_42967)->length;
    }
    else {
        _24163 = 1;
    }
    {
        object _i_46407;
        _i_46407 = 1LL;
L9: 
        if (_i_46407 > _24163){
            goto LA; // [229] 277
        }

        /** buildsys.e:686			if i > 1 then*/
        if (_i_46407 <= 1LL)
        goto LB; // [238] 255

        /** buildsys.e:687				printf(fh, " \\%s\t", { HOSTNL }  )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_44HOSTNL_20738);
        ((intptr_t*)_2)[1] = _44HOSTNL_20738;
        _24165 = MAKE_SEQ(_1);
        EPrintf(_fh_46353, _24146, _24165);
        DeRefDS(_24165);
        _24165 = NOVALUE;
LB: 

        /** buildsys.e:689			puts(fh, " " & generated_files[i])*/
        _2 = (object)SEQ_PTR(_57generated_files_42967);
        _24166 = (object)*(((s1_ptr)_2)->base + _i_46407);
        Concat((object_ptr)&_24167, _23627, _24166);
        _24166 = NOVALUE;
        EPuts(_fh_46353, _24167); // DJP 
        DeRefDS(_24167);
        _24167 = NOVALUE;

        /** buildsys.e:690		end for*/
        _i_46407 = _i_46407 + 1LL;
        goto L9; // [272] 236
LA: 
        ;
    }

    /** buildsys.e:691		puts(fh, HOSTNL)*/
    EPuts(_fh_46353, _44HOSTNL_20738); // DJP 

    /** buildsys.e:692	end procedure*/
    return;
    ;
}


object _55windows_to_mingw_path(object _s_46420)
{
    object _24169 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:701		ifdef TEST_FOR_WIN9X_ON_MING then*/

    /** buildsys.e:711		return search:find_replace('\\',s,'/')*/
    RefDS(_s_46420);
    _24169 = _14find_replace(92LL, _s_46420, 47LL, 0LL);
    DeRefDS(_s_46420);
    return _24169;
    ;
}


void _55write_makefile_full()
{
    object _settings_46425 = NOVALUE;
    object _fh_46428 = NOVALUE;
    object _24296 = NOVALUE;
    object _24294 = NOVALUE;
    object _24292 = NOVALUE;
    object _24291 = NOVALUE;
    object _24290 = NOVALUE;
    object _24289 = NOVALUE;
    object _24288 = NOVALUE;
    object _24286 = NOVALUE;
    object _24285 = NOVALUE;
    object _24283 = NOVALUE;
    object _24282 = NOVALUE;
    object _24281 = NOVALUE;
    object _24280 = NOVALUE;
    object _24278 = NOVALUE;
    object _24277 = NOVALUE;
    object _24275 = NOVALUE;
    object _24274 = NOVALUE;
    object _24272 = NOVALUE;
    object _24271 = NOVALUE;
    object _24270 = NOVALUE;
    object _24269 = NOVALUE;
    object _24268 = NOVALUE;
    object _24267 = NOVALUE;
    object _24266 = NOVALUE;
    object _24265 = NOVALUE;
    object _24263 = NOVALUE;
    object _24262 = NOVALUE;
    object _24261 = NOVALUE;
    object _24260 = NOVALUE;
    object _24259 = NOVALUE;
    object _24258 = NOVALUE;
    object _24257 = NOVALUE;
    object _24256 = NOVALUE;
    object _24255 = NOVALUE;
    object _24254 = NOVALUE;
    object _24253 = NOVALUE;
    object _24252 = NOVALUE;
    object _24251 = NOVALUE;
    object _24249 = NOVALUE;
    object _24248 = NOVALUE;
    object _24186 = NOVALUE;
    object _24185 = NOVALUE;
    object _24184 = NOVALUE;
    object _24182 = NOVALUE;
    object _24181 = NOVALUE;
    object _24180 = NOVALUE;
    object _24178 = NOVALUE;
    object _24177 = NOVALUE;
    object _24176 = NOVALUE;
    object _24173 = NOVALUE;
    object _24171 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:718		sequence settings = setup_build()*/
    _0 = _settings_46425;
    _settings_46425 = _55setup_build();
    DeRef(_0);

    /** buildsys.e:720		ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (object)SEQ_PTR(_settings_46425);
    _24171 = (object)*(((s1_ptr)_2)->base + 6LL);
    Ref(_24171);
    _55ensure_exename(_24171);
    _24171 = NOVALUE;

    /** buildsys.e:722		integer fh = open(output_dir & file0 & ".mak", "wb")*/
    {
        object concat_list[3];

        concat_list[0] = _24172;
        concat_list[1] = _57file0_44926;
        concat_list[2] = _57output_dir_42977;
        Concat_N((object_ptr)&_24173, concat_list, 3);
    }
    _fh_46428 = EOpen(_24173, _24089, 0LL);
    DeRefDS(_24173);
    _24173 = NOVALUE;

    /** buildsys.e:724		printf(fh, "CC     = %s" & HOSTNL, { settings[SETUP_CEXE] })*/
    Concat((object_ptr)&_24176, _24175, _44HOSTNL_20738);
    _2 = (object)SEQ_PTR(_settings_46425);
    _24177 = (object)*(((s1_ptr)_2)->base + 1LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24177);
    ((intptr_t*)_2)[1] = _24177;
    _24178 = MAKE_SEQ(_1);
    _24177 = NOVALUE;
    EPrintf(_fh_46428, _24176, _24178);
    DeRefDS(_24176);
    _24176 = NOVALUE;
    DeRefDS(_24178);
    _24178 = NOVALUE;

    /** buildsys.e:725		printf(fh, "CFLAGS = %s" & HOSTNL, { settings[SETUP_CFLAGS] })*/
    Concat((object_ptr)&_24180, _24179, _44HOSTNL_20738);
    _2 = (object)SEQ_PTR(_settings_46425);
    _24181 = (object)*(((s1_ptr)_2)->base + 2LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24181);
    ((intptr_t*)_2)[1] = _24181;
    _24182 = MAKE_SEQ(_1);
    _24181 = NOVALUE;
    EPrintf(_fh_46428, _24180, _24182);
    DeRefDS(_24180);
    _24180 = NOVALUE;
    DeRefDS(_24182);
    _24182 = NOVALUE;

    /** buildsys.e:726		printf(fh, "LINKER = %s" & HOSTNL, { settings[SETUP_LEXE] })*/
    Concat((object_ptr)&_24184, _24183, _44HOSTNL_20738);
    _2 = (object)SEQ_PTR(_settings_46425);
    _24185 = (object)*(((s1_ptr)_2)->base + 3LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24185);
    ((intptr_t*)_2)[1] = _24185;
    _24186 = MAKE_SEQ(_1);
    _24185 = NOVALUE;
    EPrintf(_fh_46428, _24184, _24186);
    DeRefDS(_24184);
    _24184 = NOVALUE;
    DeRefDS(_24186);
    _24186 = NOVALUE;

    /** buildsys.e:728		if compiler_type = COMPILER_GCC then*/

    /** buildsys.e:731			write_objlink_file()*/
    _55write_objlink_file();

    /** buildsys.e:734		write_makefile_srcobj_list(fh)*/
    _55write_makefile_srcobj_list(_fh_46428);

    /** buildsys.e:735		puts(fh, HOSTNL)*/
    EPuts(_fh_46428, _44HOSTNL_20738); // DJP 

    /** buildsys.e:737		if compiler_type = COMPILER_WATCOM then*/

    /** buildsys.e:770			printf(fh, "RUNTIME_LIBRARY=%s\n", { settings[SETUP_RUNTIME_LIBRARY] } )*/
    _2 = (object)SEQ_PTR(_settings_46425);
    _24248 = (object)*(((s1_ptr)_2)->base + 9LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24248);
    ((intptr_t*)_2)[1] = _24248;
    _24249 = MAKE_SEQ(_1);
    _24248 = NOVALUE;
    EPrintf(_fh_46428, _24247, _24249);
    DeRefDS(_24249);
    _24249 = NOVALUE;

    /** buildsys.e:771			printf(fh, "%s: $(%s_OBJECTS) $(RUNTIME_LIBRARY) %s " & HOSTNL, { adjust_for_build_file(exe_name[D_ALTNAME]), upper(file0), rc_file[D_ALTNAME] })*/
    Concat((object_ptr)&_24251, _24250, _44HOSTNL_20738);
    _2 = (object)SEQ_PTR(_55exe_name_45793);
    _24252 = (object)*(((s1_ptr)_2)->base + 11LL);
    Ref(_24252);
    _24253 = _55adjust_for_build_file(_24252);
    _24252 = NOVALUE;
    RefDS(_57file0_44926);
    _24254 = _12upper(_57file0_44926);
    _2 = (object)SEQ_PTR(_55rc_file_45799);
    _24255 = (object)*(((s1_ptr)_2)->base + 11LL);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24253;
    ((intptr_t*)_2)[2] = _24254;
    RefDS(_24255);
    ((intptr_t*)_2)[3] = _24255;
    _24256 = MAKE_SEQ(_1);
    _24255 = NOVALUE;
    _24254 = NOVALUE;
    _24253 = NOVALUE;
    EPrintf(_fh_46428, _24251, _24256);
    DeRefDS(_24251);
    _24251 = NOVALUE;
    DeRefDS(_24256);
    _24256 = NOVALUE;

    /** buildsys.e:772			if length(rc_file[D_ALTNAME]) then*/
    _2 = (object)SEQ_PTR(_55rc_file_45799);
    _24257 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (IS_SEQUENCE(_24257)){
            _24258 = SEQ_PTR(_24257)->length;
    }
    else {
        _24258 = 1;
    }
    _24257 = NOVALUE;
    if (_24258 == 0)
    {
        _24258 = NOVALUE;
        goto L1; // [646] 690
    }
    else{
        _24258 = NOVALUE;
    }

    /** buildsys.e:773				writef(fh, "\t" & settings[SETUP_RC_COMPILER] & HOSTNL, { rc_file[D_ALTNAME], res_file[D_ALTNAME] })*/
    _2 = (object)SEQ_PTR(_settings_46425);
    _24259 = (object)*(((s1_ptr)_2)->base + 8LL);
    {
        object concat_list[3];

        concat_list[0] = _44HOSTNL_20738;
        concat_list[1] = _24259;
        concat_list[2] = _24206;
        Concat_N((object_ptr)&_24260, concat_list, 3);
    }
    _24259 = NOVALUE;
    _2 = (object)SEQ_PTR(_55rc_file_45799);
    _24261 = (object)*(((s1_ptr)_2)->base + 11LL);
    _2 = (object)SEQ_PTR(_55res_file_45805);
    _24262 = (object)*(((s1_ptr)_2)->base + 11LL);
    RefDS(_24262);
    RefDS(_24261);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24261;
    ((intptr_t *)_2)[2] = _24262;
    _24263 = MAKE_SEQ(_1);
    _24262 = NOVALUE;
    _24261 = NOVALUE;
    _18writef(_fh_46428, _24260, _24263, 0LL);
    _24260 = NOVALUE;
    _24263 = NOVALUE;
L1: 

    /** buildsys.e:775			printf(fh, "\t$(LINKER) -o %s $(%s_OBJECTS) %s $(LFLAGS)" & HOSTNL, {*/
    Concat((object_ptr)&_24265, _24264, _44HOSTNL_20738);
    _2 = (object)SEQ_PTR(_55exe_name_45793);
    _24266 = (object)*(((s1_ptr)_2)->base + 11LL);
    RefDS(_57file0_44926);
    _24267 = _12upper(_57file0_44926);
    _2 = (object)SEQ_PTR(_55res_file_45805);
    _24268 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (IS_SEQUENCE(_24268)){
            _24269 = SEQ_PTR(_24268)->length;
    }
    else {
        _24269 = 1;
    }
    _24268 = NOVALUE;
    _2 = (object)SEQ_PTR(_55res_file_45805);
    _24270 = (object)*(((s1_ptr)_2)->base + 11LL);
    RefDS(_24270);
    RefDS(_22218);
    _24271 = _56iif(_24269, _24270, _22218);
    _24269 = NOVALUE;
    _24270 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24266);
    ((intptr_t*)_2)[1] = _24266;
    ((intptr_t*)_2)[2] = _24267;
    ((intptr_t*)_2)[3] = _24271;
    _24272 = MAKE_SEQ(_1);
    _24271 = NOVALUE;
    _24267 = NOVALUE;
    _24266 = NOVALUE;
    EPrintf(_fh_46428, _24265, _24272);
    DeRefDS(_24265);
    _24265 = NOVALUE;
    DeRefDS(_24272);
    _24272 = NOVALUE;

    /** buildsys.e:777			puts(fh, HOSTNL)*/
    EPuts(_fh_46428, _44HOSTNL_20738); // DJP 

    /** buildsys.e:778			printf(fh, ".PHONY: %s-clean %s-clean-all" & HOSTNL, { file0, file0 })*/
    Concat((object_ptr)&_24274, _24273, _44HOSTNL_20738);
    RefDS(_57file0_44926);
    RefDS(_57file0_44926);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _57file0_44926;
    ((intptr_t *)_2)[2] = _57file0_44926;
    _24275 = MAKE_SEQ(_1);
    EPrintf(_fh_46428, _24274, _24275);
    DeRefDS(_24274);
    _24274 = NOVALUE;
    DeRefDS(_24275);
    _24275 = NOVALUE;

    /** buildsys.e:779			puts(fh, HOSTNL)*/
    EPuts(_fh_46428, _44HOSTNL_20738); // DJP 

    /** buildsys.e:780			printf(fh, "%s-clean:" & HOSTNL, { file0 })*/
    Concat((object_ptr)&_24277, _24276, _44HOSTNL_20738);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_57file0_44926);
    ((intptr_t*)_2)[1] = _57file0_44926;
    _24278 = MAKE_SEQ(_1);
    EPrintf(_fh_46428, _24277, _24278);
    DeRefDS(_24277);
    _24277 = NOVALUE;
    DeRefDS(_24278);
    _24278 = NOVALUE;

    /** buildsys.e:781			printf(fh, "\trm -rf $(%s_OBJECTS) %s" & HOSTNL, { upper(file0), res_file[D_ALTNAME] })*/
    Concat((object_ptr)&_24280, _24279, _44HOSTNL_20738);
    RefDS(_57file0_44926);
    _24281 = _12upper(_57file0_44926);
    _2 = (object)SEQ_PTR(_55res_file_45805);
    _24282 = (object)*(((s1_ptr)_2)->base + 11LL);
    RefDS(_24282);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24281;
    ((intptr_t *)_2)[2] = _24282;
    _24283 = MAKE_SEQ(_1);
    _24282 = NOVALUE;
    _24281 = NOVALUE;
    EPrintf(_fh_46428, _24280, _24283);
    DeRefDS(_24280);
    _24280 = NOVALUE;
    DeRefDS(_24283);
    _24283 = NOVALUE;

    /** buildsys.e:782			puts(fh, HOSTNL)*/
    EPuts(_fh_46428, _44HOSTNL_20738); // DJP 

    /** buildsys.e:783			printf(fh, "%s-clean-all: %s-clean" & HOSTNL, { file0, file0 })*/
    Concat((object_ptr)&_24285, _24284, _44HOSTNL_20738);
    RefDS(_57file0_44926);
    RefDS(_57file0_44926);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _57file0_44926;
    ((intptr_t *)_2)[2] = _57file0_44926;
    _24286 = MAKE_SEQ(_1);
    EPrintf(_fh_46428, _24285, _24286);
    DeRefDS(_24285);
    _24285 = NOVALUE;
    DeRefDS(_24286);
    _24286 = NOVALUE;

    /** buildsys.e:784			printf(fh, "\trm -rf $(%s_SOURCES) %s %s" & HOSTNL, { upper(file0), res_file[D_ALTNAME], exe_name[D_ALTNAME] })*/
    Concat((object_ptr)&_24288, _24287, _44HOSTNL_20738);
    RefDS(_57file0_44926);
    _24289 = _12upper(_57file0_44926);
    _2 = (object)SEQ_PTR(_55res_file_45805);
    _24290 = (object)*(((s1_ptr)_2)->base + 11LL);
    _2 = (object)SEQ_PTR(_55exe_name_45793);
    _24291 = (object)*(((s1_ptr)_2)->base + 11LL);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24289;
    RefDS(_24290);
    ((intptr_t*)_2)[2] = _24290;
    Ref(_24291);
    ((intptr_t*)_2)[3] = _24291;
    _24292 = MAKE_SEQ(_1);
    _24291 = NOVALUE;
    _24290 = NOVALUE;
    _24289 = NOVALUE;
    EPrintf(_fh_46428, _24288, _24292);
    DeRefDS(_24288);
    _24288 = NOVALUE;
    DeRefDS(_24292);
    _24292 = NOVALUE;

    /** buildsys.e:785			puts(fh, HOSTNL)*/
    EPuts(_fh_46428, _44HOSTNL_20738); // DJP 

    /** buildsys.e:786			puts(fh, "%.o: %.c" & HOSTNL)*/
    Concat((object_ptr)&_24294, _24293, _44HOSTNL_20738);
    EPuts(_fh_46428, _24294); // DJP 
    DeRefDS(_24294);
    _24294 = NOVALUE;

    /** buildsys.e:787			puts(fh, "\t$(CC) $(CFLAGS) $*.c -o $*.o" & HOSTNL)*/
    Concat((object_ptr)&_24296, _24295, _44HOSTNL_20738);
    EPuts(_fh_46428, _24296); // DJP 
    DeRefDS(_24296);
    _24296 = NOVALUE;

    /** buildsys.e:788			puts(fh, HOSTNL)*/
    EPuts(_fh_46428, _44HOSTNL_20738); // DJP 

    /** buildsys.e:791		close(fh)*/
    EClose(_fh_46428);

    /** buildsys.e:792	end procedure*/
    DeRef(_settings_46425);
    _24257 = NOVALUE;
    _24268 = NOVALUE;
    return;
    ;
}


void _55write_makefile_partial()
{
    object _settings_46654 = NOVALUE;
    object _fh_46656 = NOVALUE;
    object _24298 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:798		sequence settings = setup_build()*/
    _0 = _settings_46654;
    _settings_46654 = _55setup_build();
    DeRef(_0);

    /** buildsys.e:799		integer fh = open(output_dir & file0 & ".mak", "wb")*/
    {
        object concat_list[3];

        concat_list[0] = _24172;
        concat_list[1] = _57file0_44926;
        concat_list[2] = _57output_dir_42977;
        Concat_N((object_ptr)&_24298, concat_list, 3);
    }
    _fh_46656 = EOpen(_24298, _24089, 0LL);
    DeRefDS(_24298);
    _24298 = NOVALUE;

    /** buildsys.e:801		write_makefile_srcobj_list(fh)*/
    _55write_makefile_srcobj_list(_fh_46656);

    /** buildsys.e:803		close(fh)*/
    EClose(_fh_46656);

    /** buildsys.e:804	end procedure*/
    DeRefDS(_settings_46654);
    return;
    ;
}


void _55build_direct(object _link_only_46663, object _the_file0_46664)
{
    object _cmd_46670 = NOVALUE;
    object _objs_46671 = NOVALUE;
    object _settings_46672 = NOVALUE;
    object _cwd_46674 = NOVALUE;
    object _status_46677 = NOVALUE;
    object _link_files_46708 = NOVALUE;
    object _pdone_46734 = NOVALUE;
    object _files_46786 = NOVALUE;
    object _32071 = NOVALUE;
    object _32070 = NOVALUE;
    object _32069 = NOVALUE;
    object _32068 = NOVALUE;
    object _32067 = NOVALUE;
    object _32065 = NOVALUE;
    object _24443 = NOVALUE;
    object _24442 = NOVALUE;
    object _24441 = NOVALUE;
    object _24440 = NOVALUE;
    object _24439 = NOVALUE;
    object _24438 = NOVALUE;
    object _24437 = NOVALUE;
    object _24435 = NOVALUE;
    object _24434 = NOVALUE;
    object _24433 = NOVALUE;
    object _24432 = NOVALUE;
    object _24428 = NOVALUE;
    object _24427 = NOVALUE;
    object _24426 = NOVALUE;
    object _24425 = NOVALUE;
    object _24424 = NOVALUE;
    object _24423 = NOVALUE;
    object _24422 = NOVALUE;
    object _24421 = NOVALUE;
    object _24420 = NOVALUE;
    object _24419 = NOVALUE;
    object _24418 = NOVALUE;
    object _24417 = NOVALUE;
    object _24416 = NOVALUE;
    object _24415 = NOVALUE;
    object _24414 = NOVALUE;
    object _24411 = NOVALUE;
    object _24410 = NOVALUE;
    object _24409 = NOVALUE;
    object _24408 = NOVALUE;
    object _24405 = NOVALUE;
    object _24403 = NOVALUE;
    object _24402 = NOVALUE;
    object _24401 = NOVALUE;
    object _24400 = NOVALUE;
    object _24399 = NOVALUE;
    object _24398 = NOVALUE;
    object _24395 = NOVALUE;
    object _24394 = NOVALUE;
    object _24390 = NOVALUE;
    object _24389 = NOVALUE;
    object _24388 = NOVALUE;
    object _24384 = NOVALUE;
    object _24383 = NOVALUE;
    object _24382 = NOVALUE;
    object _24381 = NOVALUE;
    object _24380 = NOVALUE;
    object _24379 = NOVALUE;
    object _24378 = NOVALUE;
    object _24377 = NOVALUE;
    object _24376 = NOVALUE;
    object _24375 = NOVALUE;
    object _24374 = NOVALUE;
    object _24373 = NOVALUE;
    object _24371 = NOVALUE;
    object _24370 = NOVALUE;
    object _24369 = NOVALUE;
    object _24368 = NOVALUE;
    object _24367 = NOVALUE;
    object _24365 = NOVALUE;
    object _24364 = NOVALUE;
    object _24363 = NOVALUE;
    object _24362 = NOVALUE;
    object _24361 = NOVALUE;
    object _24359 = NOVALUE;
    object _24357 = NOVALUE;
    object _24356 = NOVALUE;
    object _24355 = NOVALUE;
    object _24354 = NOVALUE;
    object _24352 = NOVALUE;
    object _24351 = NOVALUE;
    object _24350 = NOVALUE;
    object _24347 = NOVALUE;
    object _24346 = NOVALUE;
    object _24345 = NOVALUE;
    object _24344 = NOVALUE;
    object _24343 = NOVALUE;
    object _24342 = NOVALUE;
    object _24341 = NOVALUE;
    object _24340 = NOVALUE;
    object _24339 = NOVALUE;
    object _24338 = NOVALUE;
    object _24335 = NOVALUE;
    object _24334 = NOVALUE;
    object _24330 = NOVALUE;
    object _24328 = NOVALUE;
    object _24327 = NOVALUE;
    object _24326 = NOVALUE;
    object _24325 = NOVALUE;
    object _24322 = NOVALUE;
    object _24321 = NOVALUE;
    object _24320 = NOVALUE;
    object _24319 = NOVALUE;
    object _24317 = NOVALUE;
    object _24316 = NOVALUE;
    object _24315 = NOVALUE;
    object _24314 = NOVALUE;
    object _24313 = NOVALUE;
    object _24310 = NOVALUE;
    object _24304 = NOVALUE;
    object _24300 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:810		if length(the_file0) then*/
    _24300 = 0;

    /** buildsys.e:813		sequence cmd, objs = "", settings = setup_build(), cwd = current_dir()*/
    RefDS(_22218);
    DeRef(_objs_46671);
    _objs_46671 = _22218;
    _0 = _settings_46672;
    _settings_46672 = _55setup_build();
    DeRef(_0);
    _0 = _cwd_46674;
    _cwd_46674 = _15current_dir();
    DeRef(_0);

    /** buildsys.e:814		integer status*/

    /** buildsys.e:816		ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (object)SEQ_PTR(_settings_46672);
    _24304 = (object)*(((s1_ptr)_2)->base + 6LL);
    Ref(_24304);
    _55ensure_exename(_24304);
    _24304 = NOVALUE;

    /** buildsys.e:818		if not link_only then*/

    /** buildsys.e:819			switch compiler_type do*/
    _0 = 0LL;
    switch ( _0 ){ 

        /** buildsys.e:820				case COMPILER_GCC then*/
        case 1:

        /** buildsys.e:821					if not silent then*/
        if (_27silent_20687 != 0)
        goto L1; // [72] 123

        /** buildsys.e:822						ShowMsg(1, COMPILING_WITH_1, {"GCC"})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24309);
        ((intptr_t*)_2)[1] = _24309;
        _24310 = MAKE_SEQ(_1);
        _30ShowMsg(1LL, 176LL, _24310, 1LL);
        _24310 = NOVALUE;
        goto L1; // [90] 123

        /** buildsys.e:825				case COMPILER_WATCOM then*/
        case 2:

        /** buildsys.e:826					write_objlink_file()*/
        _55write_objlink_file();

        /** buildsys.e:828					if not silent then*/
        if (_27silent_20687 != 0)
        goto L2; // [104] 122

        /** buildsys.e:829						ShowMsg(1, COMPILING_WITH_1, {"Watcom"})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24312);
        ((intptr_t*)_2)[1] = _24312;
        _24313 = MAKE_SEQ(_1);
        _30ShowMsg(1LL, 176LL, _24313, 1LL);
        _24313 = NOVALUE;
L2: 
    ;}L1: 

    /** buildsys.e:834		if sequence(output_dir) and length(output_dir) > 0 then*/
    _24314 = 1;
    if (_24314 == 0) {
        goto L3; // [131] 159
    }
    _24316 = 0;
    _24317 = (0LL > 0LL);
    _24316 = NOVALUE;
    if (_24317 == 0)
    {
        DeRef(_24317);
        _24317 = NOVALUE;
        goto L3; // [145] 159
    }
    else{
        DeRef(_24317);
        _24317 = NOVALUE;
    }

    /** buildsys.e:835			chdir(output_dir)*/
    RefDS(_57output_dir_42977);
    _32071 = _15chdir(_57output_dir_42977);
    DeRef(_32071);
    _32071 = NOVALUE;
L3: 

    /** buildsys.e:838		sequence link_files = {}*/
    RefDS(_22218);
    DeRef(_link_files_46708);
    _link_files_46708 = _22218;

    /** buildsys.e:840		if not link_only then*/
    if (_link_only_46663 != 0)
    goto L4; // [168] 482

    /** buildsys.e:841			for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_42967)){
            _24319 = SEQ_PTR(_57generated_files_42967)->length;
    }
    else {
        _24319 = 1;
    }
    {
        object _i_46712;
        _i_46712 = 1LL;
L5: 
        if (_i_46712 > _24319){
            goto L6; // [178] 479
        }

        /** buildsys.e:842				if generated_files[i][$] = 'c' then*/
        _2 = (object)SEQ_PTR(_57generated_files_42967);
        _24320 = (object)*(((s1_ptr)_2)->base + _i_46712);
        if (IS_SEQUENCE(_24320)){
                _24321 = SEQ_PTR(_24320)->length;
        }
        else {
            _24321 = 1;
        }
        _2 = (object)SEQ_PTR(_24320);
        _24322 = (object)*(((s1_ptr)_2)->base + _24321);
        _24320 = NOVALUE;
        if (binary_op_a(NOTEQ, _24322, 99LL)){
            _24322 = NOVALUE;
            goto L7; // [200] 438
        }
        _24322 = NOVALUE;

        /** buildsys.e:843					cmd = sprintf("%s %s %s", { settings[SETUP_CEXE], settings[SETUP_CFLAGS],*/
        _2 = (object)SEQ_PTR(_settings_46672);
        _24325 = (object)*(((s1_ptr)_2)->base + 1LL);
        _2 = (object)SEQ_PTR(_settings_46672);
        _24326 = (object)*(((s1_ptr)_2)->base + 2LL);
        _2 = (object)SEQ_PTR(_57generated_files_42967);
        _24327 = (object)*(((s1_ptr)_2)->base + _i_46712);
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_24325);
        ((intptr_t*)_2)[1] = _24325;
        Ref(_24326);
        ((intptr_t*)_2)[2] = _24326;
        RefDS(_24327);
        ((intptr_t*)_2)[3] = _24327;
        _24328 = MAKE_SEQ(_1);
        _24327 = NOVALUE;
        _24326 = NOVALUE;
        _24325 = NOVALUE;
        DeRef(_cmd_46670);
        _cmd_46670 = EPrintf(-9999999, _24324, _24328);
        DeRefDS(_24328);
        _24328 = NOVALUE;

        /** buildsys.e:846					link_files = append(link_files, generated_files[i])*/
        _2 = (object)SEQ_PTR(_57generated_files_42967);
        _24330 = (object)*(((s1_ptr)_2)->base + _i_46712);
        RefDS(_24330);
        Append(&_link_files_46708, _link_files_46708, _24330);
        _24330 = NOVALUE;

        /** buildsys.e:848					if not silent then*/
        if (_27silent_20687 != 0)
        goto L8; // [246] 374

        /** buildsys.e:849						atom pdone = 100 * (i / length(generated_files))*/
        if (IS_SEQUENCE(_57generated_files_42967)){
                _24334 = SEQ_PTR(_57generated_files_42967)->length;
        }
        else {
            _24334 = 1;
        }
        _24335 = (_i_46712 % _24334) ? NewDouble((eudouble)_i_46712 / _24334) : (_i_46712 / _24334);
        _24334 = NOVALUE;
        DeRef(_pdone_46734);
        if (IS_ATOM_INT(_24335)) {
            {
                int128_t p128 = (int128_t)100LL * (int128_t)_24335;
                if( p128 != (int128_t)(_pdone_46734 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                    _pdone_46734 = NewDouble( (eudouble)p128 );
                }
            }
        }
        else {
            _pdone_46734 = NewDouble((eudouble)100LL * DBL_PTR(_24335)->dbl);
        }
        DeRef(_24335);
        _24335 = NOVALUE;

        /** buildsys.e:850						if not verbose then*/
        if (_27verbose_20690 != 0)
        goto L9; // [268] 358

        /** buildsys.e:853							if 0 and outdated_files[i] = 0 and force_build = 0 then*/
        if (0LL == 0) {
            _24338 = 0;
            goto LA; // [273] 291
        }
        _2 = (object)SEQ_PTR(_57outdated_files_42968);
        _24339 = (object)*(((s1_ptr)_2)->base + _i_46712);
        if (IS_ATOM_INT(_24339)) {
            _24340 = (_24339 == 0LL);
        }
        else {
            _24340 = binary_op(EQUALS, _24339, 0LL);
        }
        _24339 = NOVALUE;
        if (IS_ATOM_INT(_24340))
        _24338 = (_24340 != 0);
        else
        _24338 = DBL_PTR(_24340)->dbl != 0.0;
LA: 
        if (_24338 == 0) {
            goto LB; // [291] 334
        }
        _24342 = (0LL == 0LL);
        if (_24342 == 0)
        {
            DeRef(_24342);
            _24342 = NOVALUE;
            goto LB; // [302] 334
        }
        else{
            DeRef(_24342);
            _24342 = NOVALUE;
        }

        /** buildsys.e:854								ShowMsg(1, SKIPPING__130_2_UPTODATE, { pdone, generated_files[i] })*/
        _2 = (object)SEQ_PTR(_57generated_files_42967);
        _24343 = (object)*(((s1_ptr)_2)->base + _i_46712);
        RefDS(_24343);
        Ref(_pdone_46734);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _pdone_46734;
        ((intptr_t *)_2)[2] = _24343;
        _24344 = MAKE_SEQ(_1);
        _24343 = NOVALUE;
        _30ShowMsg(1LL, 325LL, _24344, 1LL);
        _24344 = NOVALUE;

        /** buildsys.e:855								continue*/
        DeRef(_pdone_46734);
        _pdone_46734 = NOVALUE;
        goto LC; // [329] 474
        goto LD; // [331] 373
LB: 

        /** buildsys.e:857								ShowMsg(1, COMPILING_130_2, { pdone, generated_files[i] })*/
        _2 = (object)SEQ_PTR(_57generated_files_42967);
        _24345 = (object)*(((s1_ptr)_2)->base + _i_46712);
        RefDS(_24345);
        Ref(_pdone_46734);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _pdone_46734;
        ((intptr_t *)_2)[2] = _24345;
        _24346 = MAKE_SEQ(_1);
        _24345 = NOVALUE;
        _30ShowMsg(1LL, 163LL, _24346, 1LL);
        _24346 = NOVALUE;
        goto LD; // [355] 373
L9: 

        /** buildsys.e:860							ShowMsg(1, COMPILING_130_2, { pdone, cmd })*/
        RefDS(_cmd_46670);
        Ref(_pdone_46734);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _pdone_46734;
        ((intptr_t *)_2)[2] = _cmd_46670;
        _24347 = MAKE_SEQ(_1);
        _30ShowMsg(1LL, 163LL, _24347, 1LL);
        _24347 = NOVALUE;
LD: 
L8: 
        DeRef(_pdone_46734);
        _pdone_46734 = NOVALUE;

        /** buildsys.e:865					status = system_exec(cmd, 0)*/
        _status_46677 = system_exec_call(_cmd_46670, 0LL);

        /** buildsys.e:866					if status != 0 then*/
        if (_status_46677 == 0LL)
        goto LE; // [384] 472

        /** buildsys.e:867						ShowMsg(2, COULDNT_COMPILE_FILE_1, { generated_files[i] })*/
        _2 = (object)SEQ_PTR(_57generated_files_42967);
        _24350 = (object)*(((s1_ptr)_2)->base + _i_46712);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24350);
        ((intptr_t*)_2)[1] = _24350;
        _24351 = MAKE_SEQ(_1);
        _24350 = NOVALUE;
        _30ShowMsg(2LL, 164LL, _24351, 1LL);
        _24351 = NOVALUE;

        /** buildsys.e:868						ShowMsg(2, STATUS_1_COMMAND_2, { status, cmd })*/
        RefDS(_cmd_46670);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _status_46677;
        ((intptr_t *)_2)[2] = _cmd_46670;
        _24352 = MAKE_SEQ(_1);
        _30ShowMsg(2LL, 165LL, _24352, 1LL);
        _24352 = NOVALUE;

        /** buildsys.e:869						goto "build_direct_cleanup"*/
        goto GF;
        goto LE; // [435] 472
L7: 

        /** buildsys.e:871				elsif match(".o", generated_files[i]) then*/
        _2 = (object)SEQ_PTR(_57generated_files_42967);
        _24354 = (object)*(((s1_ptr)_2)->base + _i_46712);
        _24355 = e_match_from(_23382, _24354, 1LL);
        _24354 = NOVALUE;
        if (_24355 == 0)
        {
            _24355 = NOVALUE;
            goto L10; // [451] 471
        }
        else{
            _24355 = NOVALUE;
        }

        /** buildsys.e:872					objs &= " " & generated_files[i]*/
        _2 = (object)SEQ_PTR(_57generated_files_42967);
        _24356 = (object)*(((s1_ptr)_2)->base + _i_46712);
        Concat((object_ptr)&_24357, _23627, _24356);
        _24356 = NOVALUE;
        Concat((object_ptr)&_objs_46671, _objs_46671, _24357);
        DeRefDS(_24357);
        _24357 = NOVALUE;
L10: 
LE: 

        /** buildsys.e:874			end for*/
LC: 
        _i_46712 = _i_46712 + 1LL;
        goto L5; // [474] 185
L6: 
        ;
    }
    goto L11; // [479] 541
L4: 

    /** buildsys.e:876			object files = read_lines(file0 & ".bld")*/
    Concat((object_ptr)&_24359, _57file0_44926, _23838);
    _0 = _files_46786;
    _files_46786 = _18read_lines(_24359);
    DeRef(_0);
    _24359 = NOVALUE;

    /** buildsys.e:877			for i = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_46786)){
            _24361 = SEQ_PTR(_files_46786)->length;
    }
    else {
        _24361 = 1;
    }
    {
        object _i_46792;
        _i_46792 = 1LL;
L12: 
        if (_i_46792 > _24361){
            goto L13; // [499] 538
        }

        /** buildsys.e:878				objs &= " " & filebase(files[i]) & "." & settings[SETUP_OBJ_EXT]*/
        _2 = (object)SEQ_PTR(_files_46786);
        _24362 = (object)*(((s1_ptr)_2)->base + _i_46792);
        Ref(_24362);
        _24363 = _15filebase(_24362);
        _24362 = NOVALUE;
        _2 = (object)SEQ_PTR(_settings_46672);
        _24364 = (object)*(((s1_ptr)_2)->base + 5LL);
        {
            object concat_list[4];

            concat_list[0] = _24364;
            concat_list[1] = _23423;
            concat_list[2] = _24363;
            concat_list[3] = _23627;
            Concat_N((object_ptr)&_24365, concat_list, 4);
        }
        _24364 = NOVALUE;
        DeRef(_24363);
        _24363 = NOVALUE;
        Concat((object_ptr)&_objs_46671, _objs_46671, _24365);
        DeRefDS(_24365);
        _24365 = NOVALUE;

        /** buildsys.e:879			end for*/
        _i_46792 = _i_46792 + 1LL;
        goto L12; // [533] 506
L13: 
        ;
    }
    DeRef(_files_46786);
    _files_46786 = NOVALUE;
L11: 

    /** buildsys.e:882		if keep and not link_only and length(link_files) then*/
    if (_57keep_42970 == 0) {
        _24367 = 0;
        goto L14; // [545] 556
    }
    _24368 = (_link_only_46663 == 0);
    _24367 = (_24368 != 0);
L14: 
    if (_24367 == 0) {
        goto L15; // [556] 585
    }
    if (IS_SEQUENCE(_link_files_46708)){
            _24370 = SEQ_PTR(_link_files_46708)->length;
    }
    else {
        _24370 = 1;
    }
    if (_24370 == 0)
    {
        _24370 = NOVALUE;
        goto L15; // [564] 585
    }
    else{
        _24370 = NOVALUE;
    }

    /** buildsys.e:883			write_lines(file0 & ".bld", link_files)*/
    Concat((object_ptr)&_24371, _57file0_44926, _23838);
    RefDS(_link_files_46708);
    _32070 = _18write_lines(_24371, _link_files_46708);
    _24371 = NOVALUE;
    DeRef(_32070);
    _32070 = NOVALUE;
    goto L16; // [582] 609
L15: 

    /** buildsys.e:884		elsif keep = 0 then*/
    if (_57keep_42970 != 0LL)
    goto L17; // [589] 608

    /** buildsys.e:886			delete_file(file0 & ".bld")*/
    Concat((object_ptr)&_24373, _57file0_44926, _23838);
    _32069 = _15delete_file(_24373);
    _24373 = NOVALUE;
    DeRef(_32069);
    _32069 = NOVALUE;
L17: 
L16: 

    /** buildsys.e:890		if length(rc_file[D_ALTNAME]) and length(settings[SETUP_RC_COMPILER]) and compiler_type = COMPILER_GCC then*/
    _2 = (object)SEQ_PTR(_55rc_file_45799);
    _24374 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (IS_SEQUENCE(_24374)){
            _24375 = SEQ_PTR(_24374)->length;
    }
    else {
        _24375 = 1;
    }
    _24374 = NOVALUE;
    if (_24375 == 0) {
        _24376 = 0;
        goto L18; // [622] 637
    }
    _2 = (object)SEQ_PTR(_settings_46672);
    _24377 = (object)*(((s1_ptr)_2)->base + 8LL);
    if (IS_SEQUENCE(_24377)){
            _24378 = SEQ_PTR(_24377)->length;
    }
    else {
        _24378 = 1;
    }
    _24377 = NOVALUE;
    _24376 = (_24378 != 0);
L18: 
    if (_24376 == 0) {
        goto L19; // [637] 742
    }
    _24380 = (0LL == 1LL);
    if (_24380 == 0)
    {
        DeRef(_24380);
        _24380 = NOVALUE;
        goto L19; // [648] 742
    }
    else{
        DeRef(_24380);
        _24380 = NOVALUE;
    }

    /** buildsys.e:891			cmd = text:format(settings[SETUP_RC_COMPILER], { rc_file[D_ALTNAME], res_file[D_ALTNAME] })*/
    _2 = (object)SEQ_PTR(_settings_46672);
    _24381 = (object)*(((s1_ptr)_2)->base + 8LL);
    _2 = (object)SEQ_PTR(_55rc_file_45799);
    _24382 = (object)*(((s1_ptr)_2)->base + 11LL);
    _2 = (object)SEQ_PTR(_55res_file_45805);
    _24383 = (object)*(((s1_ptr)_2)->base + 11LL);
    RefDS(_24383);
    RefDS(_24382);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24382;
    ((intptr_t *)_2)[2] = _24383;
    _24384 = MAKE_SEQ(_1);
    _24383 = NOVALUE;
    _24382 = NOVALUE;
    Ref(_24381);
    _0 = _cmd_46670;
    _cmd_46670 = _12format(_24381, _24384);
    DeRef(_0);
    _24381 = NOVALUE;
    _24384 = NOVALUE;

    /** buildsys.e:892			status = system_exec(cmd, 0)*/
    _status_46677 = system_exec_call(_cmd_46670, 0LL);

    /** buildsys.e:893			if status != 0 then*/
    if (_status_46677 == 0LL)
    goto L1A; // [692] 741

    /** buildsys.e:894				ShowMsg(2, UNABLE_TO_COMPILE_RESOURCE_FILE_1, { rc_file[D_NAME] })*/
    _2 = (object)SEQ_PTR(_55rc_file_45799);
    _24388 = (object)*(((s1_ptr)_2)->base + 1LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_24388);
    ((intptr_t*)_2)[1] = _24388;
    _24389 = MAKE_SEQ(_1);
    _24388 = NOVALUE;
    _30ShowMsg(2LL, 350LL, _24389, 1LL);
    _24389 = NOVALUE;

    /** buildsys.e:895				ShowMsg(2, STATUS_1_COMMAND_2_A, { status, cmd })*/
    RefDS(_cmd_46670);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _status_46677;
    ((intptr_t *)_2)[2] = _cmd_46670;
    _24390 = MAKE_SEQ(_1);
    _30ShowMsg(2LL, 169LL, _24390, 1LL);
    _24390 = NOVALUE;

    /** buildsys.e:897				goto "build_direct_cleanup"*/
    goto GF;
L1A: 
L19: 

    /** buildsys.e:901		switch compiler_type do*/
    _0 = 0LL;
    switch ( _0 ){ 

        /** buildsys.e:902			case COMPILER_WATCOM then*/
        case 2:

        /** buildsys.e:903				cmd = sprintf("%s @%s.lnk", { settings[SETUP_LEXE], file0 })*/
        _2 = (object)SEQ_PTR(_settings_46672);
        _24394 = (object)*(((s1_ptr)_2)->base + 3LL);
        RefDS(_57file0_44926);
        Ref(_24394);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _24394;
        ((intptr_t *)_2)[2] = _57file0_44926;
        _24395 = MAKE_SEQ(_1);
        _24394 = NOVALUE;
        DeRef(_cmd_46670);
        _cmd_46670 = EPrintf(-9999999, _24393, _24395);
        DeRefDS(_24395);
        _24395 = NOVALUE;
        goto L1B; // [771] 848

        /** buildsys.e:905			case COMPILER_GCC then*/
        case 1:

        /** buildsys.e:906				cmd = sprintf("%s -o %s %s %s %s", { */
        _2 = (object)SEQ_PTR(_settings_46672);
        _24398 = (object)*(((s1_ptr)_2)->base + 3LL);
        _2 = (object)SEQ_PTR(_55exe_name_45793);
        _24399 = (object)*(((s1_ptr)_2)->base + 11LL);
        Ref(_24399);
        _24400 = _55adjust_for_build_file(_24399);
        _24399 = NOVALUE;
        _2 = (object)SEQ_PTR(_55res_file_45805);
        _24401 = (object)*(((s1_ptr)_2)->base + 11LL);
        _2 = (object)SEQ_PTR(_settings_46672);
        _24402 = (object)*(((s1_ptr)_2)->base + 4LL);
        _1 = NewS1(5);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_24398);
        ((intptr_t*)_2)[1] = _24398;
        ((intptr_t*)_2)[2] = _24400;
        RefDS(_objs_46671);
        ((intptr_t*)_2)[3] = _objs_46671;
        RefDS(_24401);
        ((intptr_t*)_2)[4] = _24401;
        Ref(_24402);
        ((intptr_t*)_2)[5] = _24402;
        _24403 = MAKE_SEQ(_1);
        _24402 = NOVALUE;
        _24401 = NOVALUE;
        _24400 = NOVALUE;
        _24398 = NOVALUE;
        DeRef(_cmd_46670);
        _cmd_46670 = EPrintf(-9999999, _24397, _24403);
        DeRefDS(_24403);
        _24403 = NOVALUE;
        goto L1B; // [819] 848

        /** buildsys.e:915			case else*/
        default:

        /** buildsys.e:916				ShowMsg(2, UNKNOWN_COMPILER_TYPE_1, { compiler_type })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = 0LL;
        _24405 = MAKE_SEQ(_1);
        _30ShowMsg(2LL, 167LL, _24405, 1LL);
        _24405 = NOVALUE;

        /** buildsys.e:918				goto "build_direct_cleanup"*/
        goto GF;
    ;}L1B: 

    /** buildsys.e:921		if not silent then*/
    if (_27silent_20687 != 0)
    goto L1C; // [852] 910

    /** buildsys.e:922			if not verbose then*/
    if (_27verbose_20690 != 0)
    goto L1D; // [859] 892

    /** buildsys.e:923				ShowMsg(1, LINKING_100_1, { abbreviate_path(exe_name[D_NAME]) })*/
    _2 = (object)SEQ_PTR(_55exe_name_45793);
    _24408 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_24408);
    RefDS(_22218);
    _24409 = _15abbreviate_path(_24408, _22218);
    _24408 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24409;
    _24410 = MAKE_SEQ(_1);
    _24409 = NOVALUE;
    _30ShowMsg(1LL, 166LL, _24410, 1LL);
    _24410 = NOVALUE;
    goto L1E; // [889] 909
L1D: 

    /** buildsys.e:925				ShowMsg(1, LINKING_100_1, { cmd })*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_cmd_46670);
    ((intptr_t*)_2)[1] = _cmd_46670;
    _24411 = MAKE_SEQ(_1);
    _30ShowMsg(1LL, 166LL, _24411, 1LL);
    _24411 = NOVALUE;
L1E: 
L1C: 

    /** buildsys.e:929		status = system_exec(cmd, 0)*/
    _status_46677 = system_exec_call(_cmd_46670, 0LL);

    /** buildsys.e:930		if status != 0 then*/
    if (_status_46677 == 0LL)
    goto L1F; // [920] 967

    /** buildsys.e:931			ShowMsg(2, UNABLE_TO_LINK_1, { exe_name[D_NAME] })*/
    _2 = (object)SEQ_PTR(_55exe_name_45793);
    _24414 = (object)*(((s1_ptr)_2)->base + 1LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24414);
    ((intptr_t*)_2)[1] = _24414;
    _24415 = MAKE_SEQ(_1);
    _24414 = NOVALUE;
    _30ShowMsg(2LL, 168LL, _24415, 1LL);
    _24415 = NOVALUE;

    /** buildsys.e:932			ShowMsg(2, STATUS_1_COMMAND_2_A, { status, cmd })*/
    RefDS(_cmd_46670);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _status_46677;
    ((intptr_t *)_2)[2] = _cmd_46670;
    _24416 = MAKE_SEQ(_1);
    _30ShowMsg(2LL, 169LL, _24416, 1LL);
    _24416 = NOVALUE;

    /** buildsys.e:934			goto "build_direct_cleanup"*/
    goto GF;
L1F: 

    /** buildsys.e:938		if length(rc_file[D_ALTNAME]) and length(settings[SETUP_RC_COMPILER]) and compiler_type = COMPILER_WATCOM then*/
    _2 = (object)SEQ_PTR(_55rc_file_45799);
    _24417 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (IS_SEQUENCE(_24417)){
            _24418 = SEQ_PTR(_24417)->length;
    }
    else {
        _24418 = 1;
    }
    _24417 = NOVALUE;
    if (_24418 == 0) {
        _24419 = 0;
        goto L20; // [980] 995
    }
    _2 = (object)SEQ_PTR(_settings_46672);
    _24420 = (object)*(((s1_ptr)_2)->base + 8LL);
    if (IS_SEQUENCE(_24420)){
            _24421 = SEQ_PTR(_24420)->length;
    }
    else {
        _24421 = 1;
    }
    _24420 = NOVALUE;
    _24419 = (_24421 != 0);
L20: 
    if (_24419 == 0) {
        goto L21; // [995] 1118
    }
    _24423 = (0LL == 2LL);
    if (_24423 == 0)
    {
        DeRef(_24423);
        _24423 = NOVALUE;
        goto L21; // [1006] 1118
    }
    else{
        DeRef(_24423);
        _24423 = NOVALUE;
    }

    /** buildsys.e:939			cmd = text:format(settings[SETUP_RC_COMPILER], { rc_file[D_ALTNAME], res_file[D_ALTNAME], exe_name[D_ALTNAME] })*/
    _2 = (object)SEQ_PTR(_settings_46672);
    _24424 = (object)*(((s1_ptr)_2)->base + 8LL);
    _2 = (object)SEQ_PTR(_55rc_file_45799);
    _24425 = (object)*(((s1_ptr)_2)->base + 11LL);
    _2 = (object)SEQ_PTR(_55res_file_45805);
    _24426 = (object)*(((s1_ptr)_2)->base + 11LL);
    _2 = (object)SEQ_PTR(_55exe_name_45793);
    _24427 = (object)*(((s1_ptr)_2)->base + 11LL);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_24425);
    ((intptr_t*)_2)[1] = _24425;
    RefDS(_24426);
    ((intptr_t*)_2)[2] = _24426;
    Ref(_24427);
    ((intptr_t*)_2)[3] = _24427;
    _24428 = MAKE_SEQ(_1);
    _24427 = NOVALUE;
    _24426 = NOVALUE;
    _24425 = NOVALUE;
    Ref(_24424);
    _0 = _cmd_46670;
    _cmd_46670 = _12format(_24424, _24428);
    DeRef(_0);
    _24424 = NOVALUE;
    _24428 = NOVALUE;

    /** buildsys.e:940			status = system_exec(cmd, 0)*/
    _status_46677 = system_exec_call(_cmd_46670, 0LL);

    /** buildsys.e:941			if status != 0 then*/
    if (_status_46677 == 0LL)
    goto L22; // [1060] 1117

    /** buildsys.e:942				ShowMsg(2, UNABLE_TO_LINK_RESOURCE_FILE_1_INTO_EXECUTABLE_2, { rc_file[D_NAME], exe_name[D_NAME] })*/
    _2 = (object)SEQ_PTR(_55rc_file_45799);
    _24432 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_55exe_name_45793);
    _24433 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_24433);
    RefDS(_24432);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24432;
    ((intptr_t *)_2)[2] = _24433;
    _24434 = MAKE_SEQ(_1);
    _24433 = NOVALUE;
    _24432 = NOVALUE;
    _30ShowMsg(2LL, 187LL, _24434, 1LL);
    _24434 = NOVALUE;

    /** buildsys.e:943				ShowMsg(2, STATUS_1_COMMAND_2_A, { status, cmd })*/
    RefDS(_cmd_46670);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _status_46677;
    ((intptr_t *)_2)[2] = _cmd_46670;
    _24435 = MAKE_SEQ(_1);
    _30ShowMsg(2LL, 169LL, _24435, 1LL);
    _24435 = NOVALUE;

    /** buildsys.e:945				goto "build_direct_cleanup"*/
    goto GF;
L22: 
L21: 

    /** buildsys.e:949	label "build_direct_cleanup"*/
GF:

    /** buildsys.e:950		if keep = 0 then*/
    if (_57keep_42970 != 0LL)
    goto L23; // [1126] 1277

    /** buildsys.e:951			for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_42967)){
            _24437 = SEQ_PTR(_57generated_files_42967)->length;
    }
    else {
        _24437 = 1;
    }
    {
        object _i_46928;
        _i_46928 = 1LL;
L24: 
        if (_i_46928 > _24437){
            goto L25; // [1137] 1193
        }

        /** buildsys.e:952				if verbose then*/
        if (_27verbose_20690 == 0)
        {
            goto L26; // [1148] 1172
        }
        else{
        }

        /** buildsys.e:953					ShowMsg(1, DELETING_1, { generated_files[i] })*/
        _2 = (object)SEQ_PTR(_57generated_files_42967);
        _24438 = (object)*(((s1_ptr)_2)->base + _i_46928);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24438);
        ((intptr_t*)_2)[1] = _24438;
        _24439 = MAKE_SEQ(_1);
        _24438 = NOVALUE;
        _30ShowMsg(1LL, 347LL, _24439, 1LL);
        _24439 = NOVALUE;
L26: 

        /** buildsys.e:955				delete_file(generated_files[i])*/
        _2 = (object)SEQ_PTR(_57generated_files_42967);
        _24440 = (object)*(((s1_ptr)_2)->base + _i_46928);
        RefDS(_24440);
        _32068 = _15delete_file(_24440);
        _24440 = NOVALUE;
        DeRef(_32068);
        _32068 = NOVALUE;

        /** buildsys.e:956			end for*/
        _i_46928 = _i_46928 + 1LL;
        goto L24; // [1188] 1144
L25: 
        ;
    }

    /** buildsys.e:958			if length(res_file[D_ALTNAME]) then*/
    _2 = (object)SEQ_PTR(_55res_file_45805);
    _24441 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (IS_SEQUENCE(_24441)){
            _24442 = SEQ_PTR(_24441)->length;
    }
    else {
        _24442 = 1;
    }
    _24441 = NOVALUE;
    if (_24442 == 0)
    {
        _24442 = NOVALUE;
        goto L27; // [1206] 1226
    }
    else{
        _24442 = NOVALUE;
    }

    /** buildsys.e:959				delete_file(res_file[D_ALTNAME])*/
    _2 = (object)SEQ_PTR(_55res_file_45805);
    _24443 = (object)*(((s1_ptr)_2)->base + 11LL);
    RefDS(_24443);
    _32067 = _15delete_file(_24443);
    _24443 = NOVALUE;
    DeRef(_32067);
    _32067 = NOVALUE;
L27: 

    /** buildsys.e:962			if remove_output_dir then*/
L23: 

    /** buildsys.e:972		chdir(cwd)*/
    RefDS(_cwd_46674);
    _32065 = _15chdir(_cwd_46674);
    DeRef(_32065);
    _32065 = NOVALUE;

    /** buildsys.e:973	end procedure*/
    DeRefDS(_the_file0_46664);
    DeRef(_cmd_46670);
    DeRef(_objs_46671);
    DeRef(_settings_46672);
    DeRefDS(_cwd_46674);
    DeRef(_link_files_46708);
    _24374 = NOVALUE;
    _24377 = NOVALUE;
    _24417 = NOVALUE;
    DeRef(_24368);
    _24368 = NOVALUE;
    DeRef(_24340);
    _24340 = NOVALUE;
    _24420 = NOVALUE;
    _24441 = NOVALUE;
    return;
    ;
}


void _55write_buildfile()
{
    object _make_command_46970 = NOVALUE;
    object _settings_47015 = NOVALUE;
    object _24470 = NOVALUE;
    object _24469 = NOVALUE;
    object _24465 = NOVALUE;
    object _24464 = NOVALUE;
    object _24463 = NOVALUE;
    object _24461 = NOVALUE;
    object _24460 = NOVALUE;
    object _24459 = NOVALUE;
    object _24458 = NOVALUE;
    object _24457 = NOVALUE;
    object _24456 = NOVALUE;
    object _24455 = NOVALUE;
    object _24454 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:982		switch build_system_type do*/
    _0 = 3LL;
    switch ( _0 ){ 

        /** buildsys.e:983			case BUILD_MAKEFILE_FULL then*/
        case 2:

        /** buildsys.e:984				write_makefile_full()*/
        _55write_makefile_full();

        /** buildsys.e:986				if not silent then*/
        if (_27silent_20687 != 0)
        goto L1; // [22] 142

        /** buildsys.e:987					sequence make_command*/

        /** buildsys.e:988					if compiler_type = COMPILER_WATCOM then*/

        /** buildsys.e:991						make_command = "make -f "*/
        RefDS(_24453);
        DeRefi(_make_command_46970);
        _make_command_46970 = _24453;

        /** buildsys.e:994					ShowMsg(1, MSG_1C_FILES_WERE_CREATED, { cfile_count + 2 })*/
        _24454 = _27cfile_count_20650 + 2LL;
        if ((object)((uintptr_t)_24454 + (uintptr_t)HIGH_BITS) >= 0){
            _24454 = NewDouble((eudouble)_24454);
        }
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _24454;
        _24455 = MAKE_SEQ(_1);
        _24454 = NOVALUE;
        _30ShowMsg(1LL, 170LL, _24455, 1LL);
        _24455 = NOVALUE;

        /** buildsys.e:996					if sequence(output_dir) and length(output_dir) > 0 then*/
        _24456 = 1;
        if (_24456 == 0) {
            goto L2; // [80] 122
        }
        _24458 = 0;
        _24459 = (0LL > 0LL);
        _24458 = NOVALUE;
        if (_24459 == 0)
        {
            DeRef(_24459);
            _24459 = NOVALUE;
            goto L2; // [94] 122
        }
        else{
            DeRef(_24459);
            _24459 = NOVALUE;
        }

        /** buildsys.e:997						ShowMsg(1, TO_BUILD_YOUR_PROJECT_CHANGE_DIRECTORY_TO_1_AND_TYPE_23MAK, { output_dir, make_command, file0 })*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_57output_dir_42977);
        ((intptr_t*)_2)[1] = _57output_dir_42977;
        RefDS(_make_command_46970);
        ((intptr_t*)_2)[2] = _make_command_46970;
        RefDS(_57file0_44926);
        ((intptr_t*)_2)[3] = _57file0_44926;
        _24460 = MAKE_SEQ(_1);
        _30ShowMsg(1LL, 174LL, _24460, 1LL);
        _24460 = NOVALUE;
        goto L3; // [119] 141
L2: 

        /** buildsys.e:999						ShowMsg(1, TO_BUILD_YOUR_PROJECT_TYPE_12MAK, { make_command, file0 })*/
        RefDS(_57file0_44926);
        RefDS(_make_command_46970);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _make_command_46970;
        ((intptr_t *)_2)[2] = _57file0_44926;
        _24461 = MAKE_SEQ(_1);
        _30ShowMsg(1LL, 172LL, _24461, 1LL);
        _24461 = NOVALUE;
L3: 
L1: 
        DeRefi(_make_command_46970);
        _make_command_46970 = NOVALUE;
        goto L4; // [144] 277

        /** buildsys.e:1003			case BUILD_MAKEFILE_PARTIAL then*/
        case 1:

        /** buildsys.e:1004				write_makefile_partial()*/
        _55write_makefile_partial();

        /** buildsys.e:1006				if not silent then*/
        if (_27silent_20687 != 0)
        goto L4; // [158] 277

        /** buildsys.e:1007					ShowMsg(1, MSG_1C_FILES_WERE_CREATED, { cfile_count + 2 })*/
        _24463 = _27cfile_count_20650 + 2LL;
        if ((object)((uintptr_t)_24463 + (uintptr_t)HIGH_BITS) >= 0){
            _24463 = NewDouble((eudouble)_24463);
        }
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _24463;
        _24464 = MAKE_SEQ(_1);
        _24463 = NOVALUE;
        _30ShowMsg(1LL, 170LL, _24464, 1LL);
        _24464 = NOVALUE;

        /** buildsys.e:1008					ShowMsg(1, TO_BUILD_YOUR_PROJECT_INCLUDE_1MAK_INTO_A_LARGER_MAKEFILE_PROJECT, { file0 })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_57file0_44926);
        ((intptr_t*)_2)[1] = _57file0_44926;
        _24465 = MAKE_SEQ(_1);
        _30ShowMsg(1LL, 173LL, _24465, 1LL);
        _24465 = NOVALUE;
        goto L4; // [198] 277

        /** buildsys.e:1011			case BUILD_DIRECT then*/
        case 3:

        /** buildsys.e:1012				build_direct()*/
        RefDS(_22218);
        _55build_direct(0LL, _22218);

        /** buildsys.e:1014				if not silent then*/
        if (_27silent_20687 != 0)
        goto L5; // [214] 225

        /** buildsys.e:1015					sequence settings = setup_build()*/
        _0 = _settings_47015;
        _settings_47015 = _55setup_build();
        DeRef(_0);
L5: 
        DeRef(_settings_47015);
        _settings_47015 = NOVALUE;
        goto L4; // [227] 277

        /** buildsys.e:1019			case BUILD_NONE then*/
        case 0:

        /** buildsys.e:1020				if not silent then*/
        if (_27silent_20687 != 0)
        goto L4; // [237] 277

        /** buildsys.e:1021					ShowMsg(1, MSG_1C_FILES_WERE_CREATED, { cfile_count + 2 })*/
        _24469 = _27cfile_count_20650 + 2LL;
        if ((object)((uintptr_t)_24469 + (uintptr_t)HIGH_BITS) >= 0){
            _24469 = NewDouble((eudouble)_24469);
        }
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _24469;
        _24470 = MAKE_SEQ(_1);
        _24469 = NOVALUE;
        _30ShowMsg(1LL, 170LL, _24470, 1LL);
        _24470 = NOVALUE;
        goto L4; // [261] 277

        /** buildsys.e:1026			case else*/
        default:

        /** buildsys.e:1027				CompileErr(UNKNOWN_BUILD_FILE_TYPE)*/
        RefDS(_22218);
        _49CompileErr(151LL, _22218, 0LL);
    ;}L4: 

    /** buildsys.e:1029	end procedure*/
    return;
    ;
}



// 0x3F02C4AF
