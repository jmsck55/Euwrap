// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _47add_options(object _new_options_50185)
{
    object _0, _1, _2;
    

    /** cominit.e:65		options = splice(options, new_options, COMMON_OPTIONS_SPLICE_IDX)*/
    {
        s1_ptr assign_space;
        insert_pos = 16LL;
        if (insert_pos <= 0) {
            Concat(&_47options_50181,_new_options_50185,_47options_50181);
        }
        else if (insert_pos > SEQ_PTR(_47options_50181)->length){
            Concat(&_47options_50181,_47options_50181,_new_options_50185);
        }
        else if (IS_SEQUENCE(_new_options_50185)) {
            if( _47options_50181 != _47options_50181 || SEQ_PTR( _47options_50181 )->ref != 1 ){
                DeRef( _47options_50181 );
                RefDS( _47options_50181 );
            }
            assign_space = Add_internal_space( _47options_50181, insert_pos,((s1_ptr)SEQ_PTR(_new_options_50185))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_new_options_50185), _47options_50181 == _47options_50181 );
            _47options_50181 = MAKE_SEQ( assign_space );
        }
        else {
            if( _47options_50181 == _47options_50181 && SEQ_PTR( _47options_50181 )->ref == 1 ){
                _47options_50181 = Insert( _47options_50181, _new_options_50185, insert_pos);
            }
            else {
                DeRef( _47options_50181 );
                RefDS( _47options_50181 );
                _47options_50181 = Insert( _47options_50181, _new_options_50185, insert_pos);
            }
        }
    }

    /** cominit.e:67	end procedure*/
    DeRefDS(_new_options_50185);
    return;
    ;
}


object _47get_options()
{
    object _0, _1, _2;
    

    /** cominit.e:73		return options*/
    RefDS(_47options_50181);
    return _47options_50181;
    ;
}


object _47get_switches()
{
    object _0, _1, _2;
    

    /** cominit.e:87		return switches*/
    RefDS(_47switches_50054);
    return _47switches_50054;
    ;
}


void _47show_copyrights()
{
    object _notices_50195 = NOVALUE;
    object _25787 = NOVALUE;
    object _25786 = NOVALUE;
    object _25784 = NOVALUE;
    object _25783 = NOVALUE;
    object _25782 = NOVALUE;
    object _25781 = NOVALUE;
    object _25779 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:94		sequence notices = all_copyrights()*/
    _0 = _notices_50195;
    _notices_50195 = _40all_copyrights();
    DeRef(_0);

    /** cominit.e:95		for i = 1 to length(notices) do*/
    if (IS_SEQUENCE(_notices_50195)){
            _25779 = SEQ_PTR(_notices_50195)->length;
    }
    else {
        _25779 = 1;
    }
    {
        object _i_50199;
        _i_50199 = 1LL;
L1: 
        if (_i_50199 > _25779){
            goto L2; // [13] 60
        }

        /** cominit.e:96			printf(2, "%s\n  %s\n\n", { notices[i][1], match_replace("\n", notices[i][2], "\n  ") })*/
        _2 = (object)SEQ_PTR(_notices_50195);
        _25781 = (object)*(((s1_ptr)_2)->base + _i_50199);
        _2 = (object)SEQ_PTR(_25781);
        _25782 = (object)*(((s1_ptr)_2)->base + 1LL);
        _25781 = NOVALUE;
        _2 = (object)SEQ_PTR(_notices_50195);
        _25783 = (object)*(((s1_ptr)_2)->base + _i_50199);
        _2 = (object)SEQ_PTR(_25783);
        _25784 = (object)*(((s1_ptr)_2)->base + 2LL);
        _25783 = NOVALUE;
        RefDS(_22425);
        Ref(_25784);
        RefDS(_25785);
        _25786 = _14match_replace(_22425, _25784, _25785, 0LL);
        _25784 = NOVALUE;
        Ref(_25782);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _25782;
        ((intptr_t *)_2)[2] = _25786;
        _25787 = MAKE_SEQ(_1);
        _25786 = NOVALUE;
        _25782 = NOVALUE;
        EPrintf(2LL, _25780, _25787);
        DeRefDS(_25787);
        _25787 = NOVALUE;

        /** cominit.e:97		end for*/
        _i_50199 = _i_50199 + 1LL;
        goto L1; // [55] 20
L2: 
        ;
    }

    /** cominit.e:98	end procedure*/
    DeRef(_notices_50195);
    return;
    ;
}


void _47show_banner()
{
    object _version_type_inlined_version_type_at_220_50268 = NOVALUE;
    object _version_string_short_1__tmp_at204_50266 = NOVALUE;
    object _version_string_short_inlined_version_string_short_at_204_50265 = NOVALUE;
    object _version_revision_inlined_version_revision_at_133_50246 = NOVALUE;
    object _platform_name_inlined_platform_name_at_94_50238 = NOVALUE;
    object _prod_name_50212 = NOVALUE;
    object _memory_type_50213 = NOVALUE;
    object _misc_info_50235 = NOVALUE;
    object _EuConsole_50250 = NOVALUE;
    object _25812 = NOVALUE;
    object _25811 = NOVALUE;
    object _25810 = NOVALUE;
    object _25807 = NOVALUE;
    object _25806 = NOVALUE;
    object _25802 = NOVALUE;
    object _25801 = NOVALUE;
    object _25800 = NOVALUE;
    object _25798 = NOVALUE;
    object _25796 = NOVALUE;
    object _25795 = NOVALUE;
    object _25794 = NOVALUE;
    object _25789 = NOVALUE;
    object _25788 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:109		if INTERPRET and not BIND then*/
    if (_27INTERPRET_20176 == 0) {
        goto L1; // [5] 33
    }
    _25789 = (_27BIND_20182 == 0);
    if (_25789 == 0)
    {
        DeRef(_25789);
        _25789 = NOVALUE;
        goto L1; // [15] 33
    }
    else{
        DeRef(_25789);
        _25789 = NOVALUE;
    }

    /** cominit.e:110			prod_name = GetMsgText(EUPHORIA_INTERPRETER,0)*/
    RefDS(_22218);
    _0 = _prod_name_50212;
    _prod_name_50212 = _30GetMsgText(270LL, 0LL, _22218);
    DeRef(_0);
    goto L2; // [30] 76
L1: 

    /** cominit.e:112		elsif TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L3; // [37] 55
    }
    else{
    }

    /** cominit.e:113			prod_name = GetMsgText(EUPHORIA_TO_C_TRANSLATOR,0)*/
    RefDS(_22218);
    _0 = _prod_name_50212;
    _prod_name_50212 = _30GetMsgText(271LL, 0LL, _22218);
    DeRef(_0);
    goto L2; // [52] 76
L3: 

    /** cominit.e:115		elsif BIND then*/
    if (_27BIND_20182 == 0)
    {
        goto L4; // [59] 75
    }
    else{
    }

    /** cominit.e:116			prod_name = GetMsgText(EUPHORIA_BINDER,0)*/
    RefDS(_22218);
    _0 = _prod_name_50212;
    _prod_name_50212 = _30GetMsgText(272LL, 0LL, _22218);
    DeRef(_0);
L4: 
L2: 

    /** cominit.e:119		ifdef EU_MANAGED_MEM then*/

    /** cominit.e:122			memory_type = GetMsgText(USING_SYSTEM_MEMORY,0)*/
    RefDS(_22218);
    _0 = _memory_type_50213;
    _memory_type_50213 = _30GetMsgText(274LL, 0LL, _22218);
    DeRef(_0);

    /** cominit.e:125		sequence misc_info = {*/
    _25794 = _40arch_bits();

    /** info.e:48		ifdef WINDOWS then*/

    /** info.e:49			return "Windows"*/
    RefDS(_8528);
    DeRefi(_platform_name_inlined_platform_name_at_94_50238);
    _platform_name_inlined_platform_name_at_94_50238 = _8528;
    _25795 = _40version_date(0LL);
    _25796 = _40version_node(0LL);
    _0 = _misc_info_50235;
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _25794;
    RefDS(_platform_name_inlined_platform_name_at_94_50238);
    ((intptr_t*)_2)[2] = _platform_name_inlined_platform_name_at_94_50238;
    RefDS(_memory_type_50213);
    ((intptr_t*)_2)[3] = _memory_type_50213;
    RefDS(_22218);
    ((intptr_t*)_2)[4] = _22218;
    ((intptr_t*)_2)[5] = _25795;
    ((intptr_t*)_2)[6] = _25796;
    _misc_info_50235 = MAKE_SEQ(_1);
    DeRef(_0);
    _25796 = NOVALUE;
    _25795 = NOVALUE;
    _25794 = NOVALUE;

    /** cominit.e:134		if info:is_developmental then*/
    if (_40is_developmental_14897 == 0)
    {
        goto L5; // [126] 160
    }
    else{
    }

    /** cominit.e:135			misc_info[$] = sprintf("%d:%s", { info:version_revision(), info:version_node() })*/
    _25798 = 6;

    /** info.e:157		return version_info[REVISION]*/
    DeRef(_version_revision_inlined_version_revision_at_133_50246);
    _2 = (object)SEQ_PTR(_40version_info_14895);
    _version_revision_inlined_version_revision_at_133_50246 = (object)*(((s1_ptr)_2)->base + 6LL);
    Ref(_version_revision_inlined_version_revision_at_133_50246);
    _25800 = _40version_node(0LL);
    Ref(_version_revision_inlined_version_revision_at_133_50246);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _version_revision_inlined_version_revision_at_133_50246;
    ((intptr_t *)_2)[2] = _25800;
    _25801 = MAKE_SEQ(_1);
    _25800 = NOVALUE;
    _25802 = EPrintf(-9999999, _25799, _25801);
    DeRefDS(_25801);
    _25801 = NOVALUE;
    _2 = (object)SEQ_PTR(_misc_info_50235);
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25802;
    if( _1 != _25802 ){
        DeRef(_1);
    }
    _25802 = NOVALUE;
L5: 

    /** cominit.e:138		object EuConsole = getenv("EUCONS")*/
    DeRefi(_EuConsole_50250);
    _EuConsole_50250 = EGetEnv(_25803);

    /** cominit.e:139		if equal(EuConsole, "1") then*/
    if (_EuConsole_50250 == _25805)
    _25806 = 1;
    else if (IS_ATOM_INT(_EuConsole_50250) && IS_ATOM_INT(_25805))
    _25806 = 0;
    else
    _25806 = (compare(_EuConsole_50250, _25805) == 0);
    if (_25806 == 0)
    {
        _25806 = NOVALUE;
        goto L6; // [171] 191
    }
    else{
        _25806 = NOVALUE;
    }

    /** cominit.e:140			misc_info[4] = GetMsgText(EUCONSOLE,0)*/
    RefDS(_22218);
    _25807 = _30GetMsgText(275LL, 0LL, _22218);
    _2 = (object)SEQ_PTR(_misc_info_50235);
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25807;
    if( _1 != _25807 ){
        DeRef(_1);
    }
    _25807 = NOVALUE;
    goto L7; // [188] 199
L6: 

    /** cominit.e:142			misc_info = remove(misc_info, 4)*/
    {
        s1_ptr assign_space = SEQ_PTR(_misc_info_50235);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(4LL)) ? 4LL : (object)(DBL_PTR(4LL)->dbl);
        int stop = (IS_ATOM_INT(4LL)) ? 4LL : (object)(DBL_PTR(4LL)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_misc_info_50235), start, &_misc_info_50235 );
            }
            else Tail(SEQ_PTR(_misc_info_50235), stop+1, &_misc_info_50235);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_misc_info_50235), start, &_misc_info_50235);
        }
        else {
            assign_slice_seq = &assign_space;
            _misc_info_50235 = Remove_elements(start, stop, (SEQ_PTR(_misc_info_50235)->ref == 1));
        }
    }
L7: 

    /** cominit.e:145		screen_output(STDERR, sprintf("%s v%s %s\n   %s %s, %s\n   Revision Date: %s, Id: %s\n", {*/

    /** info.e:261		return sprintf("%d.%d.%d", version_info[MAJ_VER..PAT_VER])*/
    rhs_slice_target = (object_ptr)&_version_string_short_1__tmp_at204_50266;
    RHS_Slice(_40version_info_14895, 1LL, 3LL);
    DeRefi(_version_string_short_inlined_version_string_short_at_204_50265);
    _version_string_short_inlined_version_string_short_at_204_50265 = EPrintf(-9999999, _8586, _version_string_short_1__tmp_at204_50266);
    DeRef(_version_string_short_1__tmp_at204_50266);
    _version_string_short_1__tmp_at204_50266 = NOVALUE;

    /** info.e:202		return version_info[VER_TYPE]*/
    DeRef(_version_type_inlined_version_type_at_220_50268);
    _2 = (object)SEQ_PTR(_40version_info_14895);
    _version_type_inlined_version_type_at_220_50268 = (object)*(((s1_ptr)_2)->base + 4LL);
    Ref(_version_type_inlined_version_type_at_220_50268);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_prod_name_50212);
    ((intptr_t*)_2)[1] = _prod_name_50212;
    RefDS(_version_string_short_inlined_version_string_short_at_204_50265);
    ((intptr_t*)_2)[2] = _version_string_short_inlined_version_string_short_at_204_50265;
    Ref(_version_type_inlined_version_type_at_220_50268);
    ((intptr_t*)_2)[3] = _version_type_inlined_version_type_at_220_50268;
    _25810 = MAKE_SEQ(_1);
    Concat((object_ptr)&_25811, _25810, _misc_info_50235);
    DeRefDS(_25810);
    _25810 = NOVALUE;
    DeRef(_25810);
    _25810 = NOVALUE;
    _25812 = EPrintf(-9999999, _25809, _25811);
    DeRefDS(_25811);
    _25811 = NOVALUE;
    _49screen_output(2LL, _25812);
    _25812 = NOVALUE;

    /** cominit.e:147	end procedure*/
    DeRefDS(_prod_name_50212);
    DeRef(_memory_type_50213);
    DeRefDS(_misc_info_50235);
    DeRefi(_EuConsole_50250);
    return;
    ;
}


object _47find_opt(object _name_type_50280, object _opt_50281, object _opts_50282)
{
    object _o_50286 = NOVALUE;
    object _has_case_50288 = NOVALUE;
    object _25825 = NOVALUE;
    object _25824 = NOVALUE;
    object _25823 = NOVALUE;
    object _25822 = NOVALUE;
    object _25821 = NOVALUE;
    object _25820 = NOVALUE;
    object _25819 = NOVALUE;
    object _25818 = NOVALUE;
    object _25817 = NOVALUE;
    object _25815 = NOVALUE;
    object _25813 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:172		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_50282)){
            _25813 = SEQ_PTR(_opts_50282)->length;
    }
    else {
        _25813 = 1;
    }
    {
        object _i_50284;
        _i_50284 = 1LL;
L1: 
        if (_i_50284 > _25813){
            goto L2; // [12] 113
        }

        /** cominit.e:173			sequence o = opts[i]		*/
        DeRef(_o_50286);
        _2 = (object)SEQ_PTR(_opts_50282);
        _o_50286 = (object)*(((s1_ptr)_2)->base + _i_50284);
        Ref(_o_50286);

        /** cominit.e:174			integer has_case = find(HAS_CASE, o[OPTIONS])*/
        _2 = (object)SEQ_PTR(_o_50286);
        _25815 = (object)*(((s1_ptr)_2)->base + 4LL);
        _has_case_50288 = find_from(99LL, _25815, 1LL);
        _25815 = NOVALUE;

        /** cominit.e:176			if has_case and equal(o[name_type], opt) then*/
        if (_has_case_50288 == 0) {
            goto L3; // [42] 67
        }
        _2 = (object)SEQ_PTR(_o_50286);
        _25818 = (object)*(((s1_ptr)_2)->base + _name_type_50280);
        if (_25818 == _opt_50281)
        _25819 = 1;
        else if (IS_ATOM_INT(_25818) && IS_ATOM_INT(_opt_50281))
        _25819 = 0;
        else
        _25819 = (compare(_25818, _opt_50281) == 0);
        _25818 = NOVALUE;
        if (_25819 == 0)
        {
            _25819 = NOVALUE;
            goto L3; // [55] 67
        }
        else{
            _25819 = NOVALUE;
        }

        /** cominit.e:177				return o*/
        DeRefDS(_opt_50281);
        DeRefDS(_opts_50282);
        return _o_50286;
        goto L4; // [64] 104
L3: 

        /** cominit.e:178			elsif not has_case and equal(text:lower(o[name_type]), text:lower(opt)) then*/
        _25820 = (_has_case_50288 == 0);
        if (_25820 == 0) {
            goto L5; // [72] 103
        }
        _2 = (object)SEQ_PTR(_o_50286);
        _25822 = (object)*(((s1_ptr)_2)->base + _name_type_50280);
        Ref(_25822);
        _25823 = _12lower(_25822);
        _25822 = NOVALUE;
        RefDS(_opt_50281);
        _25824 = _12lower(_opt_50281);
        if (_25823 == _25824)
        _25825 = 1;
        else if (IS_ATOM_INT(_25823) && IS_ATOM_INT(_25824))
        _25825 = 0;
        else
        _25825 = (compare(_25823, _25824) == 0);
        DeRef(_25823);
        _25823 = NOVALUE;
        DeRef(_25824);
        _25824 = NOVALUE;
        if (_25825 == 0)
        {
            _25825 = NOVALUE;
            goto L5; // [93] 103
        }
        else{
            _25825 = NOVALUE;
        }

        /** cominit.e:179				return o*/
        DeRefDS(_opt_50281);
        DeRefDS(_opts_50282);
        DeRef(_25820);
        _25820 = NOVALUE;
        return _o_50286;
L5: 
L4: 
        DeRef(_o_50286);
        _o_50286 = NOVALUE;

        /** cominit.e:181		end for*/
        _i_50284 = _i_50284 + 1LL;
        goto L1; // [108] 19
L2: 
        ;
    }

    /** cominit.e:183		return {}*/
    RefDS(_22218);
    DeRefDS(_opt_50281);
    DeRefDS(_opts_50282);
    DeRef(_25820);
    _25820 = NOVALUE;
    return _22218;
    ;
}


object _47merge_parameters(object _a_50305, object _b_50306, object _opts_50307, object _dedupe_50308)
{
    object _i_50309 = NOVALUE;
    object _opt_50313 = NOVALUE;
    object _this_opt_50319 = NOVALUE;
    object _bi_50320 = NOVALUE;
    object _beginLen_50380 = NOVALUE;
    object _first_extra_50402 = NOVALUE;
    object _opt_50406 = NOVALUE;
    object _this_opt_50411 = NOVALUE;
    object _25919 = NOVALUE;
    object _25918 = NOVALUE;
    object _25915 = NOVALUE;
    object _25914 = NOVALUE;
    object _25913 = NOVALUE;
    object _25911 = NOVALUE;
    object _25910 = NOVALUE;
    object _25909 = NOVALUE;
    object _25908 = NOVALUE;
    object _25906 = NOVALUE;
    object _25905 = NOVALUE;
    object _25903 = NOVALUE;
    object _25902 = NOVALUE;
    object _25901 = NOVALUE;
    object _25900 = NOVALUE;
    object _25899 = NOVALUE;
    object _25898 = NOVALUE;
    object _25897 = NOVALUE;
    object _25895 = NOVALUE;
    object _25892 = NOVALUE;
    object _25891 = NOVALUE;
    object _25886 = NOVALUE;
    object _25884 = NOVALUE;
    object _25883 = NOVALUE;
    object _25882 = NOVALUE;
    object _25881 = NOVALUE;
    object _25880 = NOVALUE;
    object _25879 = NOVALUE;
    object _25878 = NOVALUE;
    object _25877 = NOVALUE;
    object _25873 = NOVALUE;
    object _25872 = NOVALUE;
    object _25871 = NOVALUE;
    object _25870 = NOVALUE;
    object _25869 = NOVALUE;
    object _25868 = NOVALUE;
    object _25867 = NOVALUE;
    object _25866 = NOVALUE;
    object _25865 = NOVALUE;
    object _25864 = NOVALUE;
    object _25863 = NOVALUE;
    object _25862 = NOVALUE;
    object _25861 = NOVALUE;
    object _25860 = NOVALUE;
    object _25859 = NOVALUE;
    object _25857 = NOVALUE;
    object _25856 = NOVALUE;
    object _25855 = NOVALUE;
    object _25854 = NOVALUE;
    object _25853 = NOVALUE;
    object _25852 = NOVALUE;
    object _25851 = NOVALUE;
    object _25850 = NOVALUE;
    object _25848 = NOVALUE;
    object _25847 = NOVALUE;
    object _25846 = NOVALUE;
    object _25845 = NOVALUE;
    object _25843 = NOVALUE;
    object _25842 = NOVALUE;
    object _25841 = NOVALUE;
    object _25840 = NOVALUE;
    object _25839 = NOVALUE;
    object _25838 = NOVALUE;
    object _25837 = NOVALUE;
    object _25835 = NOVALUE;
    object _25834 = NOVALUE;
    object _25832 = NOVALUE;
    object _25829 = NOVALUE;
    object _25826 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:199		integer i = 1*/
    _i_50309 = 1LL;

    /** cominit.e:201		while i <= length(a) do*/
L1: 
    if (IS_SEQUENCE(_a_50305)){
            _25826 = SEQ_PTR(_a_50305)->length;
    }
    else {
        _25826 = 1;
    }
    if (_i_50309 > _25826)
    goto L2; // [22] 465

    /** cominit.e:202			sequence opt = a[i]*/
    DeRef(_opt_50313);
    _2 = (object)SEQ_PTR(_a_50305);
    _opt_50313 = (object)*(((s1_ptr)_2)->base + _i_50309);
    Ref(_opt_50313);

    /** cominit.e:203			if length(opt) < 2 then*/
    if (IS_SEQUENCE(_opt_50313)){
            _25829 = SEQ_PTR(_opt_50313)->length;
    }
    else {
        _25829 = 1;
    }
    if (_25829 >= 2LL)
    goto L3; // [39] 56

    /** cominit.e:204				i += 1*/
    _i_50309 = _i_50309 + 1;

    /** cominit.e:205				continue*/
    DeRefDS(_opt_50313);
    _opt_50313 = NOVALUE;
    DeRef(_this_opt_50319);
    _this_opt_50319 = NOVALUE;
    goto L1; // [53] 19
L3: 

    /** cominit.e:208			sequence this_opt = {}*/
    RefDS(_22218);
    DeRef(_this_opt_50319);
    _this_opt_50319 = _22218;

    /** cominit.e:209			integer bi = 0*/
    _bi_50320 = 0LL;

    /** cominit.e:211			if opt[2] = '-' then*/
    _2 = (object)SEQ_PTR(_opt_50313);
    _25832 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (binary_op_a(NOTEQ, _25832, 45LL)){
        _25832 = NOVALUE;
        goto L4; // [74] 149
    }
    _25832 = NOVALUE;

    /** cominit.e:214				this_opt = find_opt(LONGNAME, opt[3..$], opts)*/
    if (IS_SEQUENCE(_opt_50313)){
            _25834 = SEQ_PTR(_opt_50313)->length;
    }
    else {
        _25834 = 1;
    }
    rhs_slice_target = (object_ptr)&_25835;
    RHS_Slice(_opt_50313, 3LL, _25834);
    RefDS(_opts_50307);
    _0 = _this_opt_50319;
    _this_opt_50319 = _47find_opt(2LL, _25835, _opts_50307);
    DeRefDS(_0);
    _25835 = NOVALUE;

    /** cominit.e:216				for j = 1 to length(b) do*/
    if (IS_SEQUENCE(_b_50306)){
            _25837 = SEQ_PTR(_b_50306)->length;
    }
    else {
        _25837 = 1;
    }
    {
        object _j_50328;
        _j_50328 = 1LL;
L5: 
        if (_j_50328 > _25837){
            goto L6; // [101] 146
        }

        /** cominit.e:217					if equal(text:lower(b[j]), text:lower(opt)) then*/
        _2 = (object)SEQ_PTR(_b_50306);
        _25838 = (object)*(((s1_ptr)_2)->base + _j_50328);
        Ref(_25838);
        _25839 = _12lower(_25838);
        _25838 = NOVALUE;
        RefDS(_opt_50313);
        _25840 = _12lower(_opt_50313);
        if (_25839 == _25840)
        _25841 = 1;
        else if (IS_ATOM_INT(_25839) && IS_ATOM_INT(_25840))
        _25841 = 0;
        else
        _25841 = (compare(_25839, _25840) == 0);
        DeRef(_25839);
        _25839 = NOVALUE;
        DeRef(_25840);
        _25840 = NOVALUE;
        if (_25841 == 0)
        {
            _25841 = NOVALUE;
            goto L7; // [126] 139
        }
        else{
            _25841 = NOVALUE;
        }

        /** cominit.e:218						bi = j*/
        _bi_50320 = _j_50328;

        /** cominit.e:219						exit*/
        goto L6; // [136] 146
L7: 

        /** cominit.e:221				end for*/
        _j_50328 = _j_50328 + 1LL;
        goto L5; // [141] 108
L6: 
        ;
    }
    goto L8; // [146] 292
L4: 

    /** cominit.e:223			elsif opt[1] = '-' or opt[1] = '/' then*/
    _2 = (object)SEQ_PTR(_opt_50313);
    _25842 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_25842)) {
        _25843 = (_25842 == 45LL);
    }
    else {
        _25843 = binary_op(EQUALS, _25842, 45LL);
    }
    _25842 = NOVALUE;
    if (IS_ATOM_INT(_25843)) {
        if (_25843 != 0) {
            goto L9; // [159] 176
        }
    }
    else {
        if (DBL_PTR(_25843)->dbl != 0.0) {
            goto L9; // [159] 176
        }
    }
    _2 = (object)SEQ_PTR(_opt_50313);
    _25845 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_25845)) {
        _25846 = (_25845 == 47LL);
    }
    else {
        _25846 = binary_op(EQUALS, _25845, 47LL);
    }
    _25845 = NOVALUE;
    if (_25846 == 0) {
        DeRef(_25846);
        _25846 = NOVALUE;
        goto LA; // [172] 291
    }
    else {
        if (!IS_ATOM_INT(_25846) && DBL_PTR(_25846)->dbl == 0.0){
            DeRef(_25846);
            _25846 = NOVALUE;
            goto LA; // [172] 291
        }
        DeRef(_25846);
        _25846 = NOVALUE;
    }
    DeRef(_25846);
    _25846 = NOVALUE;
L9: 

    /** cominit.e:226				this_opt = find_opt(SHORTNAME, opt[2..$], opts)*/
    if (IS_SEQUENCE(_opt_50313)){
            _25847 = SEQ_PTR(_opt_50313)->length;
    }
    else {
        _25847 = 1;
    }
    rhs_slice_target = (object_ptr)&_25848;
    RHS_Slice(_opt_50313, 2LL, _25847);
    RefDS(_opts_50307);
    _0 = _this_opt_50319;
    _this_opt_50319 = _47find_opt(1LL, _25848, _opts_50307);
    DeRef(_0);
    _25848 = NOVALUE;

    /** cominit.e:228				for j = 1 to length(b) do*/
    if (IS_SEQUENCE(_b_50306)){
            _25850 = SEQ_PTR(_b_50306)->length;
    }
    else {
        _25850 = 1;
    }
    {
        object _j_50345;
        _j_50345 = 1LL;
LB: 
        if (_j_50345 > _25850){
            goto LC; // [199] 290
        }

        /** cominit.e:229					if equal(text:lower(b[j]), '-' & text:lower(opt[2..$])) or */
        _2 = (object)SEQ_PTR(_b_50306);
        _25851 = (object)*(((s1_ptr)_2)->base + _j_50345);
        Ref(_25851);
        _25852 = _12lower(_25851);
        _25851 = NOVALUE;
        if (IS_SEQUENCE(_opt_50313)){
                _25853 = SEQ_PTR(_opt_50313)->length;
        }
        else {
            _25853 = 1;
        }
        rhs_slice_target = (object_ptr)&_25854;
        RHS_Slice(_opt_50313, 2LL, _25853);
        _25855 = _12lower(_25854);
        _25854 = NOVALUE;
        if (IS_SEQUENCE(45LL) && IS_ATOM(_25855)) {
        }
        else if (IS_ATOM(45LL) && IS_SEQUENCE(_25855)) {
            Prepend(&_25856, _25855, 45LL);
        }
        else {
            Concat((object_ptr)&_25856, 45LL, _25855);
        }
        DeRef(_25855);
        _25855 = NOVALUE;
        if (_25852 == _25856)
        _25857 = 1;
        else if (IS_ATOM_INT(_25852) && IS_ATOM_INT(_25856))
        _25857 = 0;
        else
        _25857 = (compare(_25852, _25856) == 0);
        DeRef(_25852);
        _25852 = NOVALUE;
        DeRefDS(_25856);
        _25856 = NOVALUE;
        if (_25857 != 0) {
            goto LD; // [236] 273
        }
        _2 = (object)SEQ_PTR(_b_50306);
        _25859 = (object)*(((s1_ptr)_2)->base + _j_50345);
        Ref(_25859);
        _25860 = _12lower(_25859);
        _25859 = NOVALUE;
        if (IS_SEQUENCE(_opt_50313)){
                _25861 = SEQ_PTR(_opt_50313)->length;
        }
        else {
            _25861 = 1;
        }
        rhs_slice_target = (object_ptr)&_25862;
        RHS_Slice(_opt_50313, 2LL, _25861);
        _25863 = _12lower(_25862);
        _25862 = NOVALUE;
        if (IS_SEQUENCE(47LL) && IS_ATOM(_25863)) {
        }
        else if (IS_ATOM(47LL) && IS_SEQUENCE(_25863)) {
            Prepend(&_25864, _25863, 47LL);
        }
        else {
            Concat((object_ptr)&_25864, 47LL, _25863);
        }
        DeRef(_25863);
        _25863 = NOVALUE;
        if (_25860 == _25864)
        _25865 = 1;
        else if (IS_ATOM_INT(_25860) && IS_ATOM_INT(_25864))
        _25865 = 0;
        else
        _25865 = (compare(_25860, _25864) == 0);
        DeRef(_25860);
        _25860 = NOVALUE;
        DeRefDS(_25864);
        _25864 = NOVALUE;
        if (_25865 == 0)
        {
            _25865 = NOVALUE;
            goto LE; // [269] 283
        }
        else{
            _25865 = NOVALUE;
        }
LD: 

        /** cominit.e:232						bi = j*/
        _bi_50320 = _j_50345;

        /** cominit.e:233						exit*/
        goto LC; // [280] 290
LE: 

        /** cominit.e:235				end for*/
        _j_50345 = _j_50345 + 1LL;
        goto LB; // [285] 206
LC: 
        ;
    }
LA: 
L8: 

    /** cominit.e:243			if length(this_opt) and not find(MULTIPLE, this_opt[OPTIONS]) then*/
    if (IS_SEQUENCE(_this_opt_50319)){
            _25866 = SEQ_PTR(_this_opt_50319)->length;
    }
    else {
        _25866 = 1;
    }
    if (_25866 == 0) {
        goto LF; // [297] 451
    }
    _2 = (object)SEQ_PTR(_this_opt_50319);
    _25868 = (object)*(((s1_ptr)_2)->base + 4LL);
    _25869 = find_from(42LL, _25868, 1LL);
    _25868 = NOVALUE;
    _25870 = (_25869 == 0);
    _25869 = NOVALUE;
    if (_25870 == 0)
    {
        DeRef(_25870);
        _25870 = NOVALUE;
        goto LF; // [316] 451
    }
    else{
        DeRef(_25870);
        _25870 = NOVALUE;
    }

    /** cominit.e:244				if bi then*/
    if (_bi_50320 == 0)
    {
        goto L10; // [321] 365
    }
    else{
    }

    /** cominit.e:245					if find(HAS_PARAMETER, this_opt[OPTIONS]) then*/
    _2 = (object)SEQ_PTR(_this_opt_50319);
    _25871 = (object)*(((s1_ptr)_2)->base + 4LL);
    _25872 = find_from(112LL, _25871, 1LL);
    _25871 = NOVALUE;
    if (_25872 == 0)
    {
        _25872 = NOVALUE;
        goto L11; // [337] 354
    }
    else{
        _25872 = NOVALUE;
    }

    /** cominit.e:247						a = remove(a, i, i + 1)*/
    _25873 = _i_50309 + 1;
    if (_25873 > MAXINT){
        _25873 = NewDouble((eudouble)_25873);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_a_50305);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_i_50309)) ? _i_50309 : (object)(DBL_PTR(_i_50309)->dbl);
        int stop = (IS_ATOM_INT(_25873)) ? _25873 : (object)(DBL_PTR(_25873)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_a_50305), start, &_a_50305 );
            }
            else Tail(SEQ_PTR(_a_50305), stop+1, &_a_50305);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_a_50305), start, &_a_50305);
        }
        else {
            assign_slice_seq = &assign_space;
            _a_50305 = Remove_elements(start, stop, (SEQ_PTR(_a_50305)->ref == 1));
        }
    }
    DeRef(_25873);
    _25873 = NOVALUE;
    goto L12; // [351] 458
L11: 

    /** cominit.e:250						a = remove(a, i)*/
    {
        s1_ptr assign_space = SEQ_PTR(_a_50305);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_i_50309)) ? _i_50309 : (object)(DBL_PTR(_i_50309)->dbl);
        int stop = (IS_ATOM_INT(_i_50309)) ? _i_50309 : (object)(DBL_PTR(_i_50309)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_a_50305), start, &_a_50305 );
            }
            else Tail(SEQ_PTR(_a_50305), stop+1, &_a_50305);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_a_50305), start, &_a_50305);
        }
        else {
            assign_slice_seq = &assign_space;
            _a_50305 = Remove_elements(start, stop, (SEQ_PTR(_a_50305)->ref == 1));
        }
    }
    goto L12; // [362] 458
L10: 

    /** cominit.e:265					integer beginLen = length(a)*/
    if (IS_SEQUENCE(_a_50305)){
            _beginLen_50380 = SEQ_PTR(_a_50305)->length;
    }
    else {
        _beginLen_50380 = 1;
    }

    /** cominit.e:267					if dedupe = 0 and i < beginLen then*/
    _25877 = (_dedupe_50308 == 0LL);
    if (_25877 == 0) {
        goto L13; // [376] 438
    }
    _25879 = (_i_50309 < _beginLen_50380);
    if (_25879 == 0)
    {
        DeRef(_25879);
        _25879 = NOVALUE;
        goto L13; // [385] 438
    }
    else{
        DeRef(_25879);
        _25879 = NOVALUE;
    }

    /** cominit.e:268						a = merge_parameters( a[i + 1..$], a[1..i], opts, 1)*/
    _25880 = _i_50309 + 1;
    if (_25880 > MAXINT){
        _25880 = NewDouble((eudouble)_25880);
    }
    if (IS_SEQUENCE(_a_50305)){
            _25881 = SEQ_PTR(_a_50305)->length;
    }
    else {
        _25881 = 1;
    }
    rhs_slice_target = (object_ptr)&_25882;
    RHS_Slice(_a_50305, _25880, _25881);
    rhs_slice_target = (object_ptr)&_25883;
    RHS_Slice(_a_50305, 1LL, _i_50309);
    RefDS(_opts_50307);
    DeRef(_25884);
    _25884 = _opts_50307;
    _0 = _a_50305;
    _a_50305 = _47merge_parameters(_25882, _25883, _25884, 1LL);
    DeRefDS(_0);
    _25882 = NOVALUE;
    _25883 = NOVALUE;
    _25884 = NOVALUE;

    /** cominit.e:270						if beginLen = length(a) then*/
    if (IS_SEQUENCE(_a_50305)){
            _25886 = SEQ_PTR(_a_50305)->length;
    }
    else {
        _25886 = 1;
    }
    if (_beginLen_50380 != _25886)
    goto L14; // [424] 445

    /** cominit.e:272							i += 1*/
    _i_50309 = _i_50309 + 1;
    goto L14; // [435] 445
L13: 

    /** cominit.e:276						i += 1*/
    _i_50309 = _i_50309 + 1;
L14: 
    goto L12; // [448] 458
LF: 

    /** cominit.e:282				i += 1*/
    _i_50309 = _i_50309 + 1;
L12: 
    DeRef(_opt_50313);
    _opt_50313 = NOVALUE;
    DeRef(_this_opt_50319);
    _this_opt_50319 = NOVALUE;

    /** cominit.e:284		end while*/
    goto L1; // [462] 19
L2: 

    /** cominit.e:286		if dedupe then*/
    if (_dedupe_50308 == 0)
    {
        goto L15; // [467] 481
    }
    else{
    }

    /** cominit.e:287			return b & a*/
    Concat((object_ptr)&_25891, _b_50306, _a_50305);
    DeRefDS(_a_50305);
    DeRefDS(_b_50306);
    DeRefDS(_opts_50307);
    DeRef(_25843);
    _25843 = NOVALUE;
    DeRef(_25880);
    _25880 = NOVALUE;
    DeRef(_25877);
    _25877 = NOVALUE;
    return _25891;
L15: 

    /** cominit.e:290		integer first_extra = 0*/
    _first_extra_50402 = 0LL;

    /** cominit.e:292		i = 1*/
    _i_50309 = 1LL;

    /** cominit.e:295		while i <= length(b) do*/
L16: 
    if (IS_SEQUENCE(_b_50306)){
            _25892 = SEQ_PTR(_b_50306)->length;
    }
    else {
        _25892 = 1;
    }
    if (_i_50309 > _25892)
    goto L17; // [499] 692

    /** cominit.e:296			sequence opt = b[i]*/
    DeRef(_opt_50406);
    _2 = (object)SEQ_PTR(_b_50306);
    _opt_50406 = (object)*(((s1_ptr)_2)->base + _i_50309);
    Ref(_opt_50406);

    /** cominit.e:299			if length(opt) <= 1 then*/
    if (IS_SEQUENCE(_opt_50406)){
            _25895 = SEQ_PTR(_opt_50406)->length;
    }
    else {
        _25895 = 1;
    }
    if (_25895 > 1LL)
    goto L18; // [516] 532

    /** cominit.e:300				first_extra = i*/
    _first_extra_50402 = _i_50309;

    /** cominit.e:301				exit*/
    DeRefDS(_opt_50406);
    _opt_50406 = NOVALUE;
    DeRef(_this_opt_50411);
    _this_opt_50411 = NOVALUE;
    goto L17; // [529] 692
L18: 

    /** cominit.e:304			sequence this_opt = {}*/
    RefDS(_22218);
    DeRef(_this_opt_50411);
    _this_opt_50411 = _22218;

    /** cominit.e:305			if opt[2] = '-' and opt[1] = '-' then*/
    _2 = (object)SEQ_PTR(_opt_50406);
    _25897 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_25897)) {
        _25898 = (_25897 == 45LL);
    }
    else {
        _25898 = binary_op(EQUALS, _25897, 45LL);
    }
    _25897 = NOVALUE;
    if (IS_ATOM_INT(_25898)) {
        if (_25898 == 0) {
            goto L19; // [549] 586
        }
    }
    else {
        if (DBL_PTR(_25898)->dbl == 0.0) {
            goto L19; // [549] 586
        }
    }
    _2 = (object)SEQ_PTR(_opt_50406);
    _25900 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_25900)) {
        _25901 = (_25900 == 45LL);
    }
    else {
        _25901 = binary_op(EQUALS, _25900, 45LL);
    }
    _25900 = NOVALUE;
    if (_25901 == 0) {
        DeRef(_25901);
        _25901 = NOVALUE;
        goto L19; // [562] 586
    }
    else {
        if (!IS_ATOM_INT(_25901) && DBL_PTR(_25901)->dbl == 0.0){
            DeRef(_25901);
            _25901 = NOVALUE;
            goto L19; // [562] 586
        }
        DeRef(_25901);
        _25901 = NOVALUE;
    }
    DeRef(_25901);
    _25901 = NOVALUE;

    /** cominit.e:306				this_opt = find_opt(LONGNAME, opt[3..$], opts)*/
    if (IS_SEQUENCE(_opt_50406)){
            _25902 = SEQ_PTR(_opt_50406)->length;
    }
    else {
        _25902 = 1;
    }
    rhs_slice_target = (object_ptr)&_25903;
    RHS_Slice(_opt_50406, 3LL, _25902);
    RefDS(_opts_50307);
    _0 = _this_opt_50411;
    _this_opt_50411 = _47find_opt(2LL, _25903, _opts_50307);
    DeRef(_0);
    _25903 = NOVALUE;
    goto L1A; // [583] 633
L19: 

    /** cominit.e:307			elsif opt[1] = '-' or opt[1] = '/' then*/
    _2 = (object)SEQ_PTR(_opt_50406);
    _25905 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_25905)) {
        _25906 = (_25905 == 45LL);
    }
    else {
        _25906 = binary_op(EQUALS, _25905, 45LL);
    }
    _25905 = NOVALUE;
    if (IS_ATOM_INT(_25906)) {
        if (_25906 != 0) {
            goto L1B; // [596] 613
        }
    }
    else {
        if (DBL_PTR(_25906)->dbl != 0.0) {
            goto L1B; // [596] 613
        }
    }
    _2 = (object)SEQ_PTR(_opt_50406);
    _25908 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_25908)) {
        _25909 = (_25908 == 47LL);
    }
    else {
        _25909 = binary_op(EQUALS, _25908, 47LL);
    }
    _25908 = NOVALUE;
    if (_25909 == 0) {
        DeRef(_25909);
        _25909 = NOVALUE;
        goto L1C; // [609] 632
    }
    else {
        if (!IS_ATOM_INT(_25909) && DBL_PTR(_25909)->dbl == 0.0){
            DeRef(_25909);
            _25909 = NOVALUE;
            goto L1C; // [609] 632
        }
        DeRef(_25909);
        _25909 = NOVALUE;
    }
    DeRef(_25909);
    _25909 = NOVALUE;
L1B: 

    /** cominit.e:308				this_opt = find_opt(SHORTNAME, opt[2..$], opts)*/
    if (IS_SEQUENCE(_opt_50406)){
            _25910 = SEQ_PTR(_opt_50406)->length;
    }
    else {
        _25910 = 1;
    }
    rhs_slice_target = (object_ptr)&_25911;
    RHS_Slice(_opt_50406, 2LL, _25910);
    RefDS(_opts_50307);
    _0 = _this_opt_50411;
    _this_opt_50411 = _47find_opt(1LL, _25911, _opts_50307);
    DeRef(_0);
    _25911 = NOVALUE;
L1C: 
L1A: 

    /** cominit.e:311			if length(this_opt) then*/
    if (IS_SEQUENCE(_this_opt_50411)){
            _25913 = SEQ_PTR(_this_opt_50411)->length;
    }
    else {
        _25913 = 1;
    }
    if (_25913 == 0)
    {
        _25913 = NOVALUE;
        goto L1D; // [638] 667
    }
    else{
        _25913 = NOVALUE;
    }

    /** cominit.e:312				if find(HAS_PARAMETER, this_opt[OPTIONS]) then*/
    _2 = (object)SEQ_PTR(_this_opt_50411);
    _25914 = (object)*(((s1_ptr)_2)->base + 4LL);
    _25915 = find_from(112LL, _25914, 1LL);
    _25914 = NOVALUE;
    if (_25915 == 0)
    {
        _25915 = NOVALUE;
        goto L1E; // [654] 679
    }
    else{
        _25915 = NOVALUE;
    }

    /** cominit.e:313					i += 1*/
    _i_50309 = _i_50309 + 1;
    goto L1E; // [664] 679
L1D: 

    /** cominit.e:316				first_extra = i*/
    _first_extra_50402 = _i_50309;

    /** cominit.e:317				exit*/
    DeRef(_opt_50406);
    _opt_50406 = NOVALUE;
    DeRef(_this_opt_50411);
    _this_opt_50411 = NOVALUE;
    goto L17; // [676] 692
L1E: 

    /** cominit.e:320			i += 1*/
    _i_50309 = _i_50309 + 1;
    DeRef(_opt_50406);
    _opt_50406 = NOVALUE;
    DeRef(_this_opt_50411);
    _this_opt_50411 = NOVALUE;

    /** cominit.e:321		end while*/
    goto L16; // [689] 496
L17: 

    /** cominit.e:323		if first_extra then*/
    if (_first_extra_50402 == 0)
    {
        goto L1F; // [694] 709
    }
    else{
    }

    /** cominit.e:324			return splice(b, a, first_extra)*/
    {
        s1_ptr assign_space;
        insert_pos = _first_extra_50402;
        if (insert_pos <= 0) {
            Concat(&_25918,_a_50305,_b_50306);
        }
        else if (insert_pos > SEQ_PTR(_b_50306)->length){
            Concat(&_25918,_b_50306,_a_50305);
        }
        else if (IS_SEQUENCE(_a_50305)) {
            if( _25918 != _b_50306 || SEQ_PTR( _b_50306 )->ref != 1 ){
                DeRef( _25918 );
                RefDS( _b_50306 );
            }
            assign_space = Add_internal_space( _b_50306, insert_pos,((s1_ptr)SEQ_PTR(_a_50305))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_a_50305), _b_50306 == _25918 );
            _25918 = MAKE_SEQ( assign_space );
        }
        else {
            if( _25918 == _b_50306 && SEQ_PTR( _b_50306 )->ref == 1 ){
                _25918 = Insert( _b_50306, _a_50305, insert_pos);
            }
            else {
                DeRef( _25918 );
                RefDS( _b_50306 );
                _25918 = Insert( _b_50306, _a_50305, insert_pos);
            }
        }
    }
    DeRefDS(_a_50305);
    DeRefDS(_b_50306);
    DeRefDS(_opts_50307);
    DeRef(_25843);
    _25843 = NOVALUE;
    DeRef(_25898);
    _25898 = NOVALUE;
    DeRef(_25891);
    _25891 = NOVALUE;
    DeRef(_25880);
    _25880 = NOVALUE;
    DeRef(_25906);
    _25906 = NOVALUE;
    DeRef(_25877);
    _25877 = NOVALUE;
    return _25918;
L1F: 

    /** cominit.e:328		return b & a*/
    Concat((object_ptr)&_25919, _b_50306, _a_50305);
    DeRefDS(_a_50305);
    DeRefDS(_b_50306);
    DeRefDS(_opts_50307);
    DeRef(_25918);
    _25918 = NOVALUE;
    DeRef(_25843);
    _25843 = NOVALUE;
    DeRef(_25898);
    _25898 = NOVALUE;
    DeRef(_25891);
    _25891 = NOVALUE;
    DeRef(_25880);
    _25880 = NOVALUE;
    DeRef(_25906);
    _25906 = NOVALUE;
    DeRef(_25877);
    _25877 = NOVALUE;
    return _25919;
    ;
}


object _47validate_opt(object _opt_type_50444, object _arg_50445, object _args_50446, object _ix_50447)
{
    object _opt_50448 = NOVALUE;
    object _this_opt_50456 = NOVALUE;
    object _25938 = NOVALUE;
    object _25937 = NOVALUE;
    object _25936 = NOVALUE;
    object _25935 = NOVALUE;
    object _25934 = NOVALUE;
    object _25932 = NOVALUE;
    object _25931 = NOVALUE;
    object _25930 = NOVALUE;
    object _25929 = NOVALUE;
    object _25928 = NOVALUE;
    object _25926 = NOVALUE;
    object _25923 = NOVALUE;
    object _25921 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:336		if opt_type = SHORTNAME then*/
    if (_opt_type_50444 != 1LL)
    goto L1; // [11] 28

    /** cominit.e:337			opt = arg[2..$]*/
    if (IS_SEQUENCE(_arg_50445)){
            _25921 = SEQ_PTR(_arg_50445)->length;
    }
    else {
        _25921 = 1;
    }
    rhs_slice_target = (object_ptr)&_opt_50448;
    RHS_Slice(_arg_50445, 2LL, _25921);
    goto L2; // [25] 39
L1: 

    /** cominit.e:339			opt = arg[3..$]*/
    if (IS_SEQUENCE(_arg_50445)){
            _25923 = SEQ_PTR(_arg_50445)->length;
    }
    else {
        _25923 = 1;
    }
    rhs_slice_target = (object_ptr)&_opt_50448;
    RHS_Slice(_arg_50445, 3LL, _25923);
L2: 

    /** cominit.e:342		sequence this_opt = find_opt( opt_type, opt, options )*/
    RefDS(_opt_50448);
    RefDS(_47options_50181);
    _0 = _this_opt_50456;
    _this_opt_50456 = _47find_opt(_opt_type_50444, _opt_50448, _47options_50181);
    DeRef(_0);

    /** cominit.e:343		if not length( this_opt ) then*/
    if (IS_SEQUENCE(_this_opt_50456)){
            _25926 = SEQ_PTR(_this_opt_50456)->length;
    }
    else {
        _25926 = 1;
    }
    if (_25926 != 0)
    goto L3; // [58] 72
    _25926 = NOVALUE;

    /** cominit.e:345			return { 0, 0 }*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = 0LL;
    _25928 = MAKE_SEQ(_1);
    DeRefDS(_arg_50445);
    DeRefDS(_args_50446);
    DeRefDS(_opt_50448);
    DeRefDS(_this_opt_50456);
    return _25928;
L3: 

    /** cominit.e:348		if find( HAS_PARAMETER, this_opt[OPTIONS] ) then*/
    _2 = (object)SEQ_PTR(_this_opt_50456);
    _25929 = (object)*(((s1_ptr)_2)->base + 4LL);
    _25930 = find_from(112LL, _25929, 1LL);
    _25929 = NOVALUE;
    if (_25930 == 0)
    {
        _25930 = NOVALUE;
        goto L4; // [85] 135
    }
    else{
        _25930 = NOVALUE;
    }

    /** cominit.e:349			if ix = length( args ) - 1 then*/
    if (IS_SEQUENCE(_args_50446)){
            _25931 = SEQ_PTR(_args_50446)->length;
    }
    else {
        _25931 = 1;
    }
    _25932 = _25931 - 1LL;
    _25931 = NOVALUE;
    if (_ix_50447 != _25932)
    goto L5; // [97] 117

    /** cominit.e:351				CompileErr( MISSING_CMD_PARAMETER, { arg } )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_arg_50445);
    ((intptr_t*)_2)[1] = _arg_50445;
    _25934 = MAKE_SEQ(_1);
    _49CompileErr(353LL, _25934, 0LL);
    _25934 = NOVALUE;
    goto L6; // [114] 150
L5: 

    /** cominit.e:353				return { ix, ix + 2 }*/
    _25935 = _ix_50447 + 2LL;
    if ((object)((uintptr_t)_25935 + (uintptr_t)HIGH_BITS) >= 0){
        _25935 = NewDouble((eudouble)_25935);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _ix_50447;
    ((intptr_t *)_2)[2] = _25935;
    _25936 = MAKE_SEQ(_1);
    _25935 = NOVALUE;
    DeRefDS(_arg_50445);
    DeRefDS(_args_50446);
    DeRef(_opt_50448);
    DeRef(_this_opt_50456);
    DeRef(_25932);
    _25932 = NOVALUE;
    DeRef(_25928);
    _25928 = NOVALUE;
    return _25936;
    goto L6; // [132] 150
L4: 

    /** cominit.e:356			return { ix, ix + 1 }*/
    _25937 = _ix_50447 + 1;
    if (_25937 > MAXINT){
        _25937 = NewDouble((eudouble)_25937);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _ix_50447;
    ((intptr_t *)_2)[2] = _25937;
    _25938 = MAKE_SEQ(_1);
    _25937 = NOVALUE;
    DeRefDS(_arg_50445);
    DeRefDS(_args_50446);
    DeRef(_opt_50448);
    DeRef(_this_opt_50456);
    DeRef(_25932);
    _25932 = NOVALUE;
    DeRef(_25936);
    _25936 = NOVALUE;
    DeRef(_25928);
    _25928 = NOVALUE;
    return _25938;
L6: 
    ;
}


object _47find_next_opt(object _ix_50481, object _args_50482)
{
    object _arg_50486 = NOVALUE;
    object _25960 = NOVALUE;
    object _25959 = NOVALUE;
    object _25957 = NOVALUE;
    object _25956 = NOVALUE;
    object _25955 = NOVALUE;
    object _25954 = NOVALUE;
    object _25953 = NOVALUE;
    object _25952 = NOVALUE;
    object _25951 = NOVALUE;
    object _25950 = NOVALUE;
    object _25948 = NOVALUE;
    object _25946 = NOVALUE;
    object _25944 = NOVALUE;
    object _25942 = NOVALUE;
    object _25939 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:374		while ix < length( args ) do*/
L1: 
    if (IS_SEQUENCE(_args_50482)){
            _25939 = SEQ_PTR(_args_50482)->length;
    }
    else {
        _25939 = 1;
    }
    if (_ix_50481 >= _25939)
    goto L2; // [13] 157

    /** cominit.e:375			sequence arg = args[ix]*/
    DeRef(_arg_50486);
    _2 = (object)SEQ_PTR(_args_50482);
    _arg_50486 = (object)*(((s1_ptr)_2)->base + _ix_50481);
    Ref(_arg_50486);

    /** cominit.e:376			if length( arg ) > 1 then*/
    if (IS_SEQUENCE(_arg_50486)){
            _25942 = SEQ_PTR(_arg_50486)->length;
    }
    else {
        _25942 = 1;
    }
    if (_25942 <= 1LL)
    goto L3; // [30] 129

    /** cominit.e:377				if arg[1] = '-' then*/
    _2 = (object)SEQ_PTR(_arg_50486);
    _25944 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _25944, 45LL)){
        _25944 = NOVALUE;
        goto L4; // [40] 111
    }
    _25944 = NOVALUE;

    /** cominit.e:378					if arg[2] = '-' then*/
    _2 = (object)SEQ_PTR(_arg_50486);
    _25946 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (binary_op_a(NOTEQ, _25946, 45LL)){
        _25946 = NOVALUE;
        goto L5; // [50] 94
    }
    _25946 = NOVALUE;

    /** cominit.e:380						if length( arg ) = 2 then*/
    if (IS_SEQUENCE(_arg_50486)){
            _25948 = SEQ_PTR(_arg_50486)->length;
    }
    else {
        _25948 = 1;
    }
    if (_25948 != 2LL)
    goto L6; // [59] 78

    /** cominit.e:382							return { 0, ix - 1 }*/
    _25950 = _ix_50481 - 1LL;
    if ((object)((uintptr_t)_25950 +(uintptr_t) HIGH_BITS) >= 0){
        _25950 = NewDouble((eudouble)_25950);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = _25950;
    _25951 = MAKE_SEQ(_1);
    _25950 = NOVALUE;
    DeRefDS(_arg_50486);
    DeRefDS(_args_50482);
    return _25951;
L6: 

    /** cominit.e:385						return validate_opt( LONGNAME, arg, args, ix )*/
    RefDS(_arg_50486);
    RefDS(_args_50482);
    _25952 = _47validate_opt(2LL, _arg_50486, _args_50482, _ix_50481);
    DeRefDS(_arg_50486);
    DeRefDS(_args_50482);
    DeRef(_25951);
    _25951 = NOVALUE;
    return _25952;
    goto L7; // [91] 144
L5: 

    /** cominit.e:389						return validate_opt( SHORTNAME, arg, args, ix )*/
    RefDS(_arg_50486);
    RefDS(_args_50482);
    _25953 = _47validate_opt(1LL, _arg_50486, _args_50482, _ix_50481);
    DeRefDS(_arg_50486);
    DeRefDS(_args_50482);
    DeRef(_25951);
    _25951 = NOVALUE;
    DeRef(_25952);
    _25952 = NOVALUE;
    return _25953;
    goto L7; // [108] 144
L4: 

    /** cominit.e:393					return {0, ix-1}*/
    _25954 = _ix_50481 - 1LL;
    if ((object)((uintptr_t)_25954 +(uintptr_t) HIGH_BITS) >= 0){
        _25954 = NewDouble((eudouble)_25954);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = _25954;
    _25955 = MAKE_SEQ(_1);
    _25954 = NOVALUE;
    DeRef(_arg_50486);
    DeRefDS(_args_50482);
    DeRef(_25951);
    _25951 = NOVALUE;
    DeRef(_25953);
    _25953 = NOVALUE;
    DeRef(_25952);
    _25952 = NOVALUE;
    return _25955;
    goto L7; // [126] 144
L3: 

    /** cominit.e:397				return { 0, ix-1 }*/
    _25956 = _ix_50481 - 1LL;
    if ((object)((uintptr_t)_25956 +(uintptr_t) HIGH_BITS) >= 0){
        _25956 = NewDouble((eudouble)_25956);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = _25956;
    _25957 = MAKE_SEQ(_1);
    _25956 = NOVALUE;
    DeRef(_arg_50486);
    DeRefDS(_args_50482);
    DeRef(_25951);
    _25951 = NOVALUE;
    DeRef(_25953);
    _25953 = NOVALUE;
    DeRef(_25955);
    _25955 = NOVALUE;
    DeRef(_25952);
    _25952 = NOVALUE;
    return _25957;
L7: 

    /** cominit.e:400			ix += 1*/
    _ix_50481 = _ix_50481 + 1;
    DeRef(_arg_50486);
    _arg_50486 = NOVALUE;

    /** cominit.e:401		end while*/
    goto L1; // [154] 10
L2: 

    /** cominit.e:402		return {0, ix-1}*/
    _25959 = _ix_50481 - 1LL;
    if ((object)((uintptr_t)_25959 +(uintptr_t) HIGH_BITS) >= 0){
        _25959 = NewDouble((eudouble)_25959);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = _25959;
    _25960 = MAKE_SEQ(_1);
    _25959 = NOVALUE;
    DeRefDS(_args_50482);
    DeRef(_25951);
    _25951 = NOVALUE;
    DeRef(_25953);
    _25953 = NOVALUE;
    DeRef(_25955);
    _25955 = NOVALUE;
    DeRef(_25957);
    _25957 = NOVALUE;
    DeRef(_25952);
    _25952 = NOVALUE;
    return _25960;
    ;
}


object _47expand_config_options(object _args_50516)
{
    object _idx_50517 = NOVALUE;
    object _next_idx_50518 = NOVALUE;
    object _files_50519 = NOVALUE;
    object _cmd_1_2_50520 = NOVALUE;
    object _25983 = NOVALUE;
    object _25982 = NOVALUE;
    object _25981 = NOVALUE;
    object _25980 = NOVALUE;
    object _25979 = NOVALUE;
    object _25978 = NOVALUE;
    object _25977 = NOVALUE;
    object _25976 = NOVALUE;
    object _25975 = NOVALUE;
    object _25970 = NOVALUE;
    object _25968 = NOVALUE;
    object _25967 = NOVALUE;
    object _25966 = NOVALUE;
    object _25964 = NOVALUE;
    object _25963 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:410		integer idx = 1*/
    _idx_50517 = 1LL;

    /** cominit.e:412		sequence files = {}*/
    RefDS(_22218);
    DeRef(_files_50519);
    _files_50519 = _22218;

    /** cominit.e:413		sequence cmd_1_2 = args[1..2]*/
    rhs_slice_target = (object_ptr)&_cmd_1_2_50520;
    RHS_Slice(_args_50516, 1LL, 2LL);

    /** cominit.e:414		args = remove( args, 1, 2 )*/
    {
        s1_ptr assign_space = SEQ_PTR(_args_50516);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(1LL)) ? 1LL : (object)(DBL_PTR(1LL)->dbl);
        int stop = (IS_ATOM_INT(2LL)) ? 2LL : (object)(DBL_PTR(2LL)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_args_50516), start, &_args_50516 );
            }
            else Tail(SEQ_PTR(_args_50516), stop+1, &_args_50516);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_args_50516), start, &_args_50516);
        }
        else {
            assign_slice_seq = &assign_space;
            _args_50516 = Remove_elements(start, stop, (SEQ_PTR(_args_50516)->ref == 1));
        }
    }

    /** cominit.e:416		while idx with entry do*/
    goto L1; // [31] 94
L2: 
    if (_idx_50517 == 0)
    {
        goto L3; // [34] 114
    }
    else{
    }

    /** cominit.e:417			if equal(upper(args[idx]), "-C") then*/
    _2 = (object)SEQ_PTR(_args_50516);
    _25963 = (object)*(((s1_ptr)_2)->base + _idx_50517);
    Ref(_25963);
    _25964 = _12upper(_25963);
    _25963 = NOVALUE;
    if (_25964 == _25965)
    _25966 = 1;
    else if (IS_ATOM_INT(_25964) && IS_ATOM_INT(_25965))
    _25966 = 0;
    else
    _25966 = (compare(_25964, _25965) == 0);
    DeRef(_25964);
    _25964 = NOVALUE;
    if (_25966 == 0)
    {
        _25966 = NOVALUE;
        goto L4; // [51] 82
    }
    else{
        _25966 = NOVALUE;
    }

    /** cominit.e:418				files = append( files, args[idx+1] )*/
    _25967 = _idx_50517 + 1;
    _2 = (object)SEQ_PTR(_args_50516);
    _25968 = (object)*(((s1_ptr)_2)->base + _25967);
    Ref(_25968);
    Append(&_files_50519, _files_50519, _25968);
    _25968 = NOVALUE;

    /** cominit.e:419				args = remove( args, idx, idx + 1 )*/
    _25970 = _idx_50517 + 1;
    if (_25970 > MAXINT){
        _25970 = NewDouble((eudouble)_25970);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_args_50516);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_idx_50517)) ? _idx_50517 : (object)(DBL_PTR(_idx_50517)->dbl);
        int stop = (IS_ATOM_INT(_25970)) ? _25970 : (object)(DBL_PTR(_25970)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_args_50516), start, &_args_50516 );
            }
            else Tail(SEQ_PTR(_args_50516), stop+1, &_args_50516);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_args_50516), start, &_args_50516);
        }
        else {
            assign_slice_seq = &assign_space;
            _args_50516 = Remove_elements(start, stop, (SEQ_PTR(_args_50516)->ref == 1));
        }
    }
    DeRef(_25970);
    _25970 = NOVALUE;
    goto L5; // [79] 91
L4: 

    /** cominit.e:422				idx = next_idx[2]*/
    _2 = (object)SEQ_PTR(_next_idx_50518);
    _idx_50517 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_idx_50517))
    _idx_50517 = (object)DBL_PTR(_idx_50517)->dbl;
L5: 

    /** cominit.e:424		entry*/
L1: 

    /** cominit.e:425			next_idx = find_next_opt( idx, args )*/
    RefDS(_args_50516);
    _0 = _next_idx_50518;
    _next_idx_50518 = _47find_next_opt(_idx_50517, _args_50516);
    DeRef(_0);

    /** cominit.e:426			idx = next_idx[1]*/
    _2 = (object)SEQ_PTR(_next_idx_50518);
    _idx_50517 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_idx_50517))
    _idx_50517 = (object)DBL_PTR(_idx_50517)->dbl;

    /** cominit.e:427		end while*/
    goto L2; // [111] 34
L3: 

    /** cominit.e:428		return cmd_1_2 & merge_parameters( GetDefaultArgs( files ), args[1..next_idx[2]], options, 1 ) & args[next_idx[2]+1..$]*/
    RefDS(_files_50519);
    _25975 = _46GetDefaultArgs(_files_50519);
    _2 = (object)SEQ_PTR(_next_idx_50518);
    _25976 = (object)*(((s1_ptr)_2)->base + 2LL);
    rhs_slice_target = (object_ptr)&_25977;
    RHS_Slice(_args_50516, 1LL, _25976);
    RefDS(_47options_50181);
    _25978 = _47merge_parameters(_25975, _25977, _47options_50181, 1LL);
    _25975 = NOVALUE;
    _25977 = NOVALUE;
    _2 = (object)SEQ_PTR(_next_idx_50518);
    _25979 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_25979)) {
        _25980 = _25979 + 1;
        if (_25980 > MAXINT){
            _25980 = NewDouble((eudouble)_25980);
        }
    }
    else
    _25980 = binary_op(PLUS, 1, _25979);
    _25979 = NOVALUE;
    if (IS_SEQUENCE(_args_50516)){
            _25981 = SEQ_PTR(_args_50516)->length;
    }
    else {
        _25981 = 1;
    }
    rhs_slice_target = (object_ptr)&_25982;
    RHS_Slice(_args_50516, _25980, _25981);
    {
        object concat_list[3];

        concat_list[0] = _25982;
        concat_list[1] = _25978;
        concat_list[2] = _cmd_1_2_50520;
        Concat_N((object_ptr)&_25983, concat_list, 3);
    }
    DeRefDS(_25982);
    _25982 = NOVALUE;
    DeRef(_25978);
    _25978 = NOVALUE;
    DeRefDS(_args_50516);
    DeRefDS(_next_idx_50518);
    DeRefDS(_files_50519);
    DeRefDS(_cmd_1_2_50520);
    _25976 = NOVALUE;
    DeRef(_25980);
    _25980 = NOVALUE;
    DeRef(_25967);
    _25967 = NOVALUE;
    return _25983;
    ;
}


void _47handle_common_options(object _opts_50551)
{
    object _opt_keys_50552 = NOVALUE;
    object _option_w_50554 = NOVALUE;
    object _key_50558 = NOVALUE;
    object _val_50560 = NOVALUE;
    object _this_warn_50606 = NOVALUE;
    object _auto_add_warn_50608 = NOVALUE;
    object _n_50615 = NOVALUE;
    object _this_warn_50638 = NOVALUE;
    object _auto_add_warn_50640 = NOVALUE;
    object _n_50646 = NOVALUE;
    object _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50683 = NOVALUE;
    object _prompt_inlined_maybe_any_key_at_617_50682 = NOVALUE;
    object _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50696 = NOVALUE;
    object _prompt_inlined_maybe_any_key_at_693_50695 = NOVALUE;
    object _26043 = NOVALUE;
    object _26042 = NOVALUE;
    object _26040 = NOVALUE;
    object _26038 = NOVALUE;
    object _26036 = NOVALUE;
    object _26035 = NOVALUE;
    object _26034 = NOVALUE;
    object _26033 = NOVALUE;
    object _26032 = NOVALUE;
    object _26031 = NOVALUE;
    object _26030 = NOVALUE;
    object _26029 = NOVALUE;
    object _26027 = NOVALUE;
    object _26025 = NOVALUE;
    object _26024 = NOVALUE;
    object _26023 = NOVALUE;
    object _26018 = NOVALUE;
    object _26016 = NOVALUE;
    object _26014 = NOVALUE;
    object _26011 = NOVALUE;
    object _26010 = NOVALUE;
    object _26005 = NOVALUE;
    object _26002 = NOVALUE;
    object _26000 = NOVALUE;
    object _25998 = NOVALUE;
    object _25997 = NOVALUE;
    object _25996 = NOVALUE;
    object _25995 = NOVALUE;
    object _25994 = NOVALUE;
    object _25993 = NOVALUE;
    object _25991 = NOVALUE;
    object _25990 = NOVALUE;
    object _25985 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:435		sequence opt_keys = m:keys(opts)*/
    Ref(_opts_50551);
    _0 = _opt_keys_50552;
    _opt_keys_50552 = _34keys(_opts_50551, 0LL);
    DeRef(_0);

    /** cominit.e:436		integer option_w = 0*/
    _option_w_50554 = 0LL;

    /** cominit.e:438		for idx = 1 to length(opt_keys) do*/
    if (IS_SEQUENCE(_opt_keys_50552)){
            _25985 = SEQ_PTR(_opt_keys_50552)->length;
    }
    else {
        _25985 = 1;
    }
    {
        object _idx_50556;
        _idx_50556 = 1LL;
L1: 
        if (_idx_50556 > _25985){
            goto L2; // [20] 795
        }

        /** cominit.e:439			sequence key = opt_keys[idx]*/
        DeRef(_key_50558);
        _2 = (object)SEQ_PTR(_opt_keys_50552);
        _key_50558 = (object)*(((s1_ptr)_2)->base + _idx_50556);
        Ref(_key_50558);

        /** cominit.e:440			object val = m:get(opts, key)*/
        Ref(_opts_50551);
        RefDS(_key_50558);
        _0 = _val_50560;
        _val_50560 = _34get(_opts_50551, _key_50558, 0LL);
        DeRef(_0);

        /** cominit.e:442			switch key do*/
        _1 = find(_key_50558, _25988);
        switch ( _1 ){ 

            /** cominit.e:443				case "i" then*/
            case 1:

            /** cominit.e:444					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50560)){
                    _25990 = SEQ_PTR(_val_50560)->length;
            }
            else {
                _25990 = 1;
            }
            {
                object _i_50566;
                _i_50566 = 1LL;
L3: 
                if (_i_50566 > _25990){
                    goto L4; // [59] 82
                }

                /** cominit.e:445						add_include_directory(val[i])*/
                _2 = (object)SEQ_PTR(_val_50560);
                _25991 = (object)*(((s1_ptr)_2)->base + _i_50566);
                Ref(_25991);
                _46add_include_directory(_25991);
                _25991 = NOVALUE;

                /** cominit.e:446					end for*/
                _i_50566 = _i_50566 + 1LL;
                goto L3; // [77] 66
L4: 
                ;
            }
            goto L5; // [82] 786

            /** cominit.e:448				case "d" then*/
            case 2:

            /** cominit.e:449					OpDefines &= val*/
            if (IS_SEQUENCE(_27OpDefines_20645) && IS_ATOM(_val_50560)) {
                Ref(_val_50560);
                Append(&_27OpDefines_20645, _27OpDefines_20645, _val_50560);
            }
            else if (IS_ATOM(_27OpDefines_20645) && IS_SEQUENCE(_val_50560)) {
            }
            else {
                Concat((object_ptr)&_27OpDefines_20645, _27OpDefines_20645, _val_50560);
            }
            goto L5; // [98] 786

            /** cominit.e:451				case "batch" then*/
            case 3:

            /** cominit.e:452					batch_job = 1*/
            _27batch_job_20584 = 1LL;
            goto L5; // [111] 786

            /** cominit.e:454				case "test" then*/
            case 4:

            /** cominit.e:455					test_only = 1*/
            _27test_only_20583 = 1LL;
            goto L5; // [124] 786

            /** cominit.e:457				case "strict" then*/
            case 5:

            /** cominit.e:458					Strict_is_on = 1*/
            _27Strict_is_on_20637 = 1LL;
            goto L5; // [137] 786

            /** cominit.e:460				case "p" then*/
            case 6:

            /** cominit.e:461					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50560)){
                    _25993 = SEQ_PTR(_val_50560)->length;
            }
            else {
                _25993 = 1;
            }
            {
                object _i_50581;
                _i_50581 = 1LL;
L6: 
                if (_i_50581 > _25993){
                    goto L7; // [148] 173
                }

                /** cominit.e:462						add_preprocessor(val[i])*/
                _2 = (object)SEQ_PTR(_val_50560);
                _25994 = (object)*(((s1_ptr)_2)->base + _i_50581);
                Ref(_25994);
                _63add_preprocessor(_25994, 0LL, 0LL);
                _25994 = NOVALUE;

                /** cominit.e:463					end for*/
                _i_50581 = _i_50581 + 1LL;
                goto L6; // [168] 155
L7: 
                ;
            }
            goto L5; // [173] 786

            /** cominit.e:465				case "pf" then*/
            case 7:

            /** cominit.e:466					force_preprocessor = 1*/
            _28force_preprocessor_11591 = 1LL;
            goto L5; // [186] 786

            /** cominit.e:468				case "l" then*/
            case 8:

            /** cominit.e:469					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50560)){
                    _25995 = SEQ_PTR(_val_50560)->length;
            }
            else {
                _25995 = 1;
            }
            {
                object _i_50589;
                _i_50589 = 1LL;
L8: 
                if (_i_50589 > _25995){
                    goto L9; // [197] 238
                }

                /** cominit.e:470						LocalizeQual = append(LocalizeQual, (filter(lower(val[i]), STDFLTR_ALPHA)))*/
                _2 = (object)SEQ_PTR(_val_50560);
                _25996 = (object)*(((s1_ptr)_2)->base + _i_50589);
                Ref(_25996);
                _25997 = _12lower(_25996);
                _25996 = NOVALUE;
                RefDS(_22218);
                RefDS(_5);
                _25998 = _24filter(_25997, _24STDFLTR_ALPHA_7031, _22218, _5);
                _25997 = NOVALUE;
                Ref(_25998);
                Append(&_28LocalizeQual_11592, _28LocalizeQual_11592, _25998);
                DeRef(_25998);
                _25998 = NOVALUE;

                /** cominit.e:471					end for*/
                _i_50589 = _i_50589 + 1LL;
                goto L8; // [233] 204
L9: 
                ;
            }
            goto L5; // [238] 786

            /** cominit.e:473				case "ldb" then*/
            case 9:

            /** cominit.e:474					LocalDB = val*/
            Ref(_val_50560);
            DeRef(_28LocalDB_11593);
            _28LocalDB_11593 = _val_50560;
            goto L5; // [251] 786

            /** cominit.e:476				case "w" then*/
            case 10:

            /** cominit.e:477					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50560)){
                    _26000 = SEQ_PTR(_val_50560)->length;
            }
            else {
                _26000 = 1;
            }
            {
                object _i_50604;
                _i_50604 = 1LL;
LA: 
                if (_i_50604 > _26000){
                    goto LB; // [262] 392
                }

                /** cominit.e:478						sequence this_warn = val[i]*/
                DeRef(_this_warn_50606);
                _2 = (object)SEQ_PTR(_val_50560);
                _this_warn_50606 = (object)*(((s1_ptr)_2)->base + _i_50604);
                Ref(_this_warn_50606);

                /** cominit.e:479						integer auto_add_warn = 0*/
                _auto_add_warn_50608 = 0LL;

                /** cominit.e:480						if this_warn[1] = '+' then*/
                _2 = (object)SEQ_PTR(_this_warn_50606);
                _26002 = (object)*(((s1_ptr)_2)->base + 1LL);
                if (binary_op_a(NOTEQ, _26002, 43LL)){
                    _26002 = NOVALUE;
                    goto LC; // [288] 308
                }
                _26002 = NOVALUE;

                /** cominit.e:481							auto_add_warn = 1*/
                _auto_add_warn_50608 = 1LL;

                /** cominit.e:482							this_warn = this_warn[2 .. $]*/
                if (IS_SEQUENCE(_this_warn_50606)){
                        _26005 = SEQ_PTR(_this_warn_50606)->length;
                }
                else {
                    _26005 = 1;
                }
                rhs_slice_target = (object_ptr)&_this_warn_50606;
                RHS_Slice(_this_warn_50606, 2LL, _26005);
LC: 

                /** cominit.e:484						integer n = find(this_warn, warning_names)*/
                _n_50615 = find_from(_this_warn_50606, _27warning_names_20616, 1LL);

                /** cominit.e:485						if n != 0 then*/
                if (_n_50615 == 0LL)
                goto LD; // [319] 383

                /** cominit.e:486							if auto_add_warn or option_w = 1 then*/
                if (_auto_add_warn_50608 != 0) {
                    goto LE; // [325] 338
                }
                _26010 = (_option_w_50554 == 1LL);
                if (_26010 == 0)
                {
                    DeRef(_26010);
                    _26010 = NOVALUE;
                    goto LF; // [334] 357
                }
                else{
                    DeRef(_26010);
                    _26010 = NOVALUE;
                }
LE: 

                /** cominit.e:487								OpWarning = or_bits(OpWarning, warning_flags[n])*/
                _2 = (object)SEQ_PTR(_27warning_flags_20614);
                _26011 = (object)*(((s1_ptr)_2)->base + _n_50615);
                {uintptr_t tu;
                     tu = (uintptr_t)_27OpWarning_20639 | (uintptr_t)_26011;
                     _27OpWarning_20639 = MAKE_UINT(tu);
                }
                _26011 = NOVALUE;
                if (!IS_ATOM_INT(_27OpWarning_20639)) {
                    _1 = (object)(DBL_PTR(_27OpWarning_20639)->dbl);
                    DeRefDS(_27OpWarning_20639);
                    _27OpWarning_20639 = _1;
                }
                goto L10; // [354] 373
LF: 

                /** cominit.e:489								option_w = 1*/
                _option_w_50554 = 1LL;

                /** cominit.e:490								OpWarning = warning_flags[n]*/
                _2 = (object)SEQ_PTR(_27warning_flags_20614);
                _27OpWarning_20639 = (object)*(((s1_ptr)_2)->base + _n_50615);
L10: 

                /** cominit.e:493							prev_OpWarning = OpWarning*/
                _27prev_OpWarning_20640 = _27OpWarning_20639;
LD: 
                DeRef(_this_warn_50606);
                _this_warn_50606 = NOVALUE;

                /** cominit.e:495					end for*/
                _i_50604 = _i_50604 + 1LL;
                goto LA; // [387] 269
LB: 
                ;
            }
            goto L5; // [392] 786

            /** cominit.e:497				case "x" then*/
            case 11:

            /** cominit.e:498					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50560)){
                    _26014 = SEQ_PTR(_val_50560)->length;
            }
            else {
                _26014 = 1;
            }
            {
                object _i_50636;
                _i_50636 = 1LL;
L11: 
                if (_i_50636 > _26014){
                    goto L12; // [403] 542
                }

                /** cominit.e:499						sequence this_warn = val[i]*/
                DeRef(_this_warn_50638);
                _2 = (object)SEQ_PTR(_val_50560);
                _this_warn_50638 = (object)*(((s1_ptr)_2)->base + _i_50636);
                Ref(_this_warn_50638);

                /** cominit.e:500						integer auto_add_warn = 0*/
                _auto_add_warn_50640 = 0LL;

                /** cominit.e:501						if this_warn[1] = '+' then*/
                _2 = (object)SEQ_PTR(_this_warn_50638);
                _26016 = (object)*(((s1_ptr)_2)->base + 1LL);
                if (binary_op_a(NOTEQ, _26016, 43LL)){
                    _26016 = NOVALUE;
                    goto L13; // [429] 449
                }
                _26016 = NOVALUE;

                /** cominit.e:502							auto_add_warn = 1*/
                _auto_add_warn_50640 = 1LL;

                /** cominit.e:503							this_warn = this_warn[2 .. $]*/
                if (IS_SEQUENCE(_this_warn_50638)){
                        _26018 = SEQ_PTR(_this_warn_50638)->length;
                }
                else {
                    _26018 = 1;
                }
                rhs_slice_target = (object_ptr)&_this_warn_50638;
                RHS_Slice(_this_warn_50638, 2LL, _26018);
L13: 

                /** cominit.e:505						integer n = find(this_warn, warning_names)*/
                _n_50646 = find_from(_this_warn_50638, _27warning_names_20616, 1LL);

                /** cominit.e:506						if n != 0 then*/
                if (_n_50646 == 0LL)
                goto L14; // [460] 533

                /** cominit.e:507							if auto_add_warn or option_w = -1 then*/
                if (_auto_add_warn_50640 != 0) {
                    goto L15; // [466] 479
                }
                _26023 = (_option_w_50554 == -1LL);
                if (_26023 == 0)
                {
                    DeRef(_26023);
                    _26023 = NOVALUE;
                    goto L16; // [475] 501
                }
                else{
                    DeRef(_26023);
                    _26023 = NOVALUE;
                }
L15: 

                /** cominit.e:508								OpWarning = and_bits(OpWarning, not_bits(warning_flags[n]))*/
                _2 = (object)SEQ_PTR(_27warning_flags_20614);
                _26024 = (object)*(((s1_ptr)_2)->base + _n_50646);
                _26025 = not_bits(_26024);
                _26024 = NOVALUE;
                if (IS_ATOM_INT(_26025)) {
                    {uintptr_t tu;
                         tu = (uintptr_t)_27OpWarning_20639 & (uintptr_t)_26025;
                         _27OpWarning_20639 = MAKE_UINT(tu);
                    }
                }
                else {
                    temp_d.dbl = (eudouble)_27OpWarning_20639;
                    _27OpWarning_20639 = Dand_bits(&temp_d, DBL_PTR(_26025));
                }
                DeRef(_26025);
                _26025 = NOVALUE;
                if (!IS_ATOM_INT(_27OpWarning_20639)) {
                    _1 = (object)(DBL_PTR(_27OpWarning_20639)->dbl);
                    DeRefDS(_27OpWarning_20639);
                    _27OpWarning_20639 = _1;
                }
                goto L17; // [498] 523
L16: 

                /** cominit.e:510								option_w = -1*/
                _option_w_50554 = -1LL;

                /** cominit.e:511								OpWarning = all_warning_flag - warning_flags[n]*/
                _2 = (object)SEQ_PTR(_27warning_flags_20614);
                _26027 = (object)*(((s1_ptr)_2)->base + _n_50646);
                _27OpWarning_20639 = 32767LL - _26027;
                _26027 = NOVALUE;
L17: 

                /** cominit.e:514							prev_OpWarning = OpWarning*/
                _27prev_OpWarning_20640 = _27OpWarning_20639;
L14: 
                DeRef(_this_warn_50638);
                _this_warn_50638 = NOVALUE;

                /** cominit.e:516					end for*/
                _i_50636 = _i_50636 + 1LL;
                goto L11; // [537] 410
L12: 
                ;
            }
            goto L5; // [542] 786

            /** cominit.e:518				case "wf" then*/
            case 12:

            /** cominit.e:519					TempWarningName = val*/
            Ref(_val_50560);
            DeRef(_27TempWarningName_20585);
            _27TempWarningName_20585 = _val_50560;

            /** cominit.e:520				  	error:warning_file(TempWarningName)*/
            Ref(_27TempWarningName_20585);
            _5warning_file(_27TempWarningName_20585);
            goto L5; // [560] 786

            /** cominit.e:522				case "v", "version" then*/
            case 13:
            case 14:

            /** cominit.e:523					show_banner()*/
            _47show_banner();

            /** cominit.e:524					if not batch_job and not test_only then*/
            _26029 = (_27batch_job_20584 == 0);
            if (_26029 == 0) {
                goto L18; // [579] 634
            }
            _26031 = (_27test_only_20583 == 0);
            if (_26031 == 0)
            {
                DeRef(_26031);
                _26031 = NOVALUE;
                goto L18; // [589] 634
            }
            else{
                DeRef(_26031);
                _26031 = NOVALUE;
            }

            /** cominit.e:525						console:maybe_any_key(GetMsgText(MSG_PRESS_ANY_KEY_AND_WINDOW_WILL_CLOSE,0), 2)*/
            RefDS(_22218);
            _26032 = _30GetMsgText(278LL, 0LL, _22218);
            DeRef(_prompt_inlined_maybe_any_key_at_617_50682);
            _prompt_inlined_maybe_any_key_at_617_50682 = _26032;
            _26032 = NOVALUE;

            /** console.e:923		if not has_console() then*/

            /** console.e:59		return machine_func(M_HAS_CONSOLE, 0)*/
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50683);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50683 = machine(99LL, 0LL);
            if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50683)) {
                if (_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50683 != 0){
                    goto L19; // [616] 631
                }
            }
            else {
                if (DBL_PTR(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50683)->dbl != 0.0){
                    goto L19; // [616] 631
                }
            }

            /** console.e:924			any_key(prompt, con)*/
            Ref(_prompt_inlined_maybe_any_key_at_617_50682);
            _38any_key(_prompt_inlined_maybe_any_key_at_617_50682, 2LL);

            /** console.e:926	end procedure*/
            goto L19; // [628] 631
L19: 
            DeRef(_prompt_inlined_maybe_any_key_at_617_50682);
            _prompt_inlined_maybe_any_key_at_617_50682 = NOVALUE;
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50683);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50683 = NOVALUE;
L18: 

            /** cominit.e:528					abort(0)*/
            UserCleanup(0LL);
            goto L5; // [638] 786

            /** cominit.e:530				case "copyright" then*/
            case 15:

            /** cominit.e:531					show_copyrights()*/
            _47show_copyrights();

            /** cominit.e:532					if not batch_job and not test_only then*/
            _26033 = (_27batch_job_20584 == 0);
            if (_26033 == 0) {
                goto L1A; // [655] 710
            }
            _26035 = (_27test_only_20583 == 0);
            if (_26035 == 0)
            {
                DeRef(_26035);
                _26035 = NOVALUE;
                goto L1A; // [665] 710
            }
            else{
                DeRef(_26035);
                _26035 = NOVALUE;
            }

            /** cominit.e:533						console:maybe_any_key(GetMsgText(MSG_PRESS_ANY_KEY_AND_WINDOW_WILL_CLOSE,0), 2)*/
            RefDS(_22218);
            _26036 = _30GetMsgText(278LL, 0LL, _22218);
            DeRef(_prompt_inlined_maybe_any_key_at_693_50695);
            _prompt_inlined_maybe_any_key_at_693_50695 = _26036;
            _26036 = NOVALUE;

            /** console.e:923		if not has_console() then*/

            /** console.e:59		return machine_func(M_HAS_CONSOLE, 0)*/
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50696);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50696 = machine(99LL, 0LL);
            if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50696)) {
                if (_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50696 != 0){
                    goto L1B; // [692] 707
                }
            }
            else {
                if (DBL_PTR(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50696)->dbl != 0.0){
                    goto L1B; // [692] 707
                }
            }

            /** console.e:924			any_key(prompt, con)*/
            Ref(_prompt_inlined_maybe_any_key_at_693_50695);
            _38any_key(_prompt_inlined_maybe_any_key_at_693_50695, 2LL);

            /** console.e:926	end procedure*/
            goto L1B; // [704] 707
L1B: 
            DeRef(_prompt_inlined_maybe_any_key_at_693_50695);
            _prompt_inlined_maybe_any_key_at_693_50695 = NOVALUE;
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50696);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50696 = NOVALUE;
L1A: 

            /** cominit.e:535					abort(0)*/
            UserCleanup(0LL);
            goto L5; // [714] 786

            /** cominit.e:537				case "eudir" then*/
            case 16:

            /** cominit.e:538					set_eudir( val )*/
            Ref(_val_50560);
            _28set_eudir(_val_50560);
            goto L5; // [725] 786

            /** cominit.e:540				case "trace-lines" then*/
            case 17:

            /** cominit.e:541					val = value( val )*/
            Ref(_val_50560);
            _0 = _val_50560;
            _val_50560 = _17value(_val_50560, 1LL, _17GET_SHORT_ANSWER_4103);
            DeRef(_0);

            /** cominit.e:542					if val[1] = GET_SUCCESS then*/
            _2 = (object)SEQ_PTR(_val_50560);
            _26038 = (object)*(((s1_ptr)_2)->base + 1LL);
            if (binary_op_a(NOTEQ, _26038, 0LL)){
                _26038 = NOVALUE;
                goto L1C; // [749] 767
            }
            _26038 = NOVALUE;

            /** cominit.e:543						trace_lines = floor( val[2] )*/
            _2 = (object)SEQ_PTR(_val_50560);
            _26040 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (IS_ATOM_INT(_26040))
            _27trace_lines_65059 = e_floor(_26040);
            else
            _27trace_lines_65059 = unary_op(FLOOR, _26040);
            _26040 = NOVALUE;
            if (!IS_ATOM_INT(_27trace_lines_65059)) {
                _1 = (object)(DBL_PTR(_27trace_lines_65059)->dbl);
                DeRefDS(_27trace_lines_65059);
                _27trace_lines_65059 = _1;
            }
            goto L1D; // [764] 785
L1C: 

            /** cominit.e:545						puts(2, GetMsgText( BAD_TRACE_LINES ) )*/
            RefDS(_22218);
            _26042 = _30GetMsgText(604LL, 1LL, _22218);
            EPuts(2LL, _26042); // DJP 
            DeRef(_26042);
            _26042 = NOVALUE;

            /** cominit.e:546						abort( 1 )*/
            UserCleanup(1LL);
L1D: 
        ;}L5: 
        DeRef(_key_50558);
        _key_50558 = NOVALUE;
        DeRef(_val_50560);
        _val_50560 = NOVALUE;

        /** cominit.e:549		end for*/
        _idx_50556 = _idx_50556 + 1LL;
        goto L1; // [790] 27
L2: 
        ;
    }

    /** cominit.e:551		if length(LocalizeQual) = 0 then*/
    if (IS_SEQUENCE(_28LocalizeQual_11592)){
            _26043 = SEQ_PTR(_28LocalizeQual_11592)->length;
    }
    else {
        _26043 = 1;
    }
    if (_26043 != 0LL)
    goto L1E; // [802] 815

    /** cominit.e:552			LocalizeQual = {"en"}*/
    _0 = _28LocalizeQual_11592;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_26045);
    ((intptr_t*)_2)[1] = _26045;
    _28LocalizeQual_11592 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1E: 

    /** cominit.e:554	end procedure*/
    DeRef(_opts_50551);
    DeRef(_opt_keys_50552);
    DeRef(_26029);
    _26029 = NOVALUE;
    DeRef(_26033);
    _26033 = NOVALUE;
    return;
    ;
}


void _47finalize_command_line(object _opts_50722)
{
    object _extras_50729 = NOVALUE;
    object _pairs_50734 = NOVALUE;
    object _pair_50739 = NOVALUE;
    object _26075 = NOVALUE;
    object _26073 = NOVALUE;
    object _26070 = NOVALUE;
    object _26069 = NOVALUE;
    object _26068 = NOVALUE;
    object _26067 = NOVALUE;
    object _26066 = NOVALUE;
    object _26065 = NOVALUE;
    object _26064 = NOVALUE;
    object _26063 = NOVALUE;
    object _26062 = NOVALUE;
    object _26061 = NOVALUE;
    object _26060 = NOVALUE;
    object _26059 = NOVALUE;
    object _26058 = NOVALUE;
    object _26057 = NOVALUE;
    object _26056 = NOVALUE;
    object _26055 = NOVALUE;
    object _26054 = NOVALUE;
    object _26053 = NOVALUE;
    object _26051 = NOVALUE;
    object _26048 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:562		if Strict_is_on then -- overrides any -W/-X switches*/
    if (_27Strict_is_on_20637 == 0)
    {
        goto L1; // [5] 27
    }
    else{
    }

    /** cominit.e:563			OpWarning = all_warning_flag*/
    _27OpWarning_20639 = 32767LL;

    /** cominit.e:564			prev_OpWarning = OpWarning*/
    _27prev_OpWarning_20640 = 32767LL;
L1: 

    /** cominit.e:569		sequence extras = m:get(opts, cmdline:EXTRAS)*/
    Ref(_opts_50722);
    RefDS(_48EXTRAS_20984);
    _0 = _extras_50729;
    _extras_50729 = _34get(_opts_50722, _48EXTRAS_20984, 0LL);
    DeRef(_0);

    /** cominit.e:570		if length(extras) > 0 then*/
    if (IS_SEQUENCE(_extras_50729)){
            _26048 = SEQ_PTR(_extras_50729)->length;
    }
    else {
        _26048 = 1;
    }
    if (_26048 <= 0LL)
    goto L2; // [44] 270

    /** cominit.e:571			sequence pairs = m:pairs( opts )*/
    Ref(_opts_50722);
    _0 = _pairs_50734;
    _pairs_50734 = _34pairs(_opts_50722, 0LL);
    DeRef(_0);

    /** cominit.e:573			for i = 1 to length( pairs ) do*/
    if (IS_SEQUENCE(_pairs_50734)){
            _26051 = SEQ_PTR(_pairs_50734)->length;
    }
    else {
        _26051 = 1;
    }
    {
        object _i_50737;
        _i_50737 = 1LL;
L3: 
        if (_i_50737 > _26051){
            goto L4; // [62] 237
        }

        /** cominit.e:574				sequence pair = pairs[i]*/
        DeRef(_pair_50739);
        _2 = (object)SEQ_PTR(_pairs_50734);
        _pair_50739 = (object)*(((s1_ptr)_2)->base + _i_50737);
        Ref(_pair_50739);

        /** cominit.e:575				if equal( pair[1], cmdline:EXTRAS ) then*/
        _2 = (object)SEQ_PTR(_pair_50739);
        _26053 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (_26053 == _48EXTRAS_20984)
        _26054 = 1;
        else if (IS_ATOM_INT(_26053) && IS_ATOM_INT(_48EXTRAS_20984))
        _26054 = 0;
        else
        _26054 = (compare(_26053, _48EXTRAS_20984) == 0);
        _26053 = NOVALUE;
        if (_26054 == 0)
        {
            _26054 = NOVALUE;
            goto L5; // [89] 99
        }
        else{
            _26054 = NOVALUE;
        }

        /** cominit.e:576					continue*/
        DeRefDS(_pair_50739);
        _pair_50739 = NOVALUE;
        goto L6; // [96] 232
L5: 

        /** cominit.e:578				pair[1] = prepend( pair[1], '-' )*/
        _2 = (object)SEQ_PTR(_pair_50739);
        _26055 = (object)*(((s1_ptr)_2)->base + 1LL);
        Prepend(&_26056, _26055, 45LL);
        _26055 = NOVALUE;
        _2 = (object)SEQ_PTR(_pair_50739);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _pair_50739 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26056;
        if( _1 != _26056 ){
            DeRef(_1);
        }
        _26056 = NOVALUE;

        /** cominit.e:579				if sequence( pair[2] ) then*/
        _2 = (object)SEQ_PTR(_pair_50739);
        _26057 = (object)*(((s1_ptr)_2)->base + 2LL);
        _26058 = IS_SEQUENCE(_26057);
        _26057 = NOVALUE;
        if (_26058 == 0)
        {
            _26058 = NOVALUE;
            goto L7; // [122] 215
        }
        else{
            _26058 = NOVALUE;
        }

        /** cominit.e:580					if length( pair[2] ) and sequence( pair[2][1] ) then*/
        _2 = (object)SEQ_PTR(_pair_50739);
        _26059 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (IS_SEQUENCE(_26059)){
                _26060 = SEQ_PTR(_26059)->length;
        }
        else {
            _26060 = 1;
        }
        _26059 = NOVALUE;
        if (_26060 == 0) {
            goto L8; // [134] 203
        }
        _2 = (object)SEQ_PTR(_pair_50739);
        _26062 = (object)*(((s1_ptr)_2)->base + 2LL);
        _2 = (object)SEQ_PTR(_26062);
        _26063 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26062 = NOVALUE;
        _26064 = IS_SEQUENCE(_26063);
        _26063 = NOVALUE;
        if (_26064 == 0)
        {
            _26064 = NOVALUE;
            goto L8; // [150] 203
        }
        else{
            _26064 = NOVALUE;
        }

        /** cominit.e:581						for j = 1 to length( pair[2] ) do*/
        _2 = (object)SEQ_PTR(_pair_50739);
        _26065 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (IS_SEQUENCE(_26065)){
                _26066 = SEQ_PTR(_26065)->length;
        }
        else {
            _26066 = 1;
        }
        _26065 = NOVALUE;
        {
            object _j_50757;
            _j_50757 = 1LL;
L9: 
            if (_j_50757 > _26066){
                goto LA; // [162] 200
            }

            /** cominit.e:582							switches &= { pair[1], pair[2][j] }*/
            _2 = (object)SEQ_PTR(_pair_50739);
            _26067 = (object)*(((s1_ptr)_2)->base + 1LL);
            _2 = (object)SEQ_PTR(_pair_50739);
            _26068 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_26068);
            _26069 = (object)*(((s1_ptr)_2)->base + _j_50757);
            _26068 = NOVALUE;
            Ref(_26069);
            Ref(_26067);
            _1 = NewS1(2);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t *)_2)[1] = _26067;
            ((intptr_t *)_2)[2] = _26069;
            _26070 = MAKE_SEQ(_1);
            _26069 = NOVALUE;
            _26067 = NOVALUE;
            Concat((object_ptr)&_47switches_50054, _47switches_50054, _26070);
            DeRefDS(_26070);
            _26070 = NOVALUE;

            /** cominit.e:583						end for*/
            _j_50757 = _j_50757 + 1LL;
            goto L9; // [195] 169
LA: 
            ;
        }
        goto LB; // [200] 228
L8: 

        /** cominit.e:585						switches &= pair*/
        Concat((object_ptr)&_47switches_50054, _47switches_50054, _pair_50739);
        goto LB; // [212] 228
L7: 

        /** cominit.e:588					switches = append( switches, pair[1] )*/
        _2 = (object)SEQ_PTR(_pair_50739);
        _26073 = (object)*(((s1_ptr)_2)->base + 1LL);
        Ref(_26073);
        Append(&_47switches_50054, _47switches_50054, _26073);
        _26073 = NOVALUE;
LB: 
        DeRef(_pair_50739);
        _pair_50739 = NOVALUE;

        /** cominit.e:590			end for*/
L6: 
        _i_50737 = _i_50737 + 1LL;
        goto L3; // [232] 69
L4: 
        ;
    }

    /** cominit.e:592			Argv = Argv[2..3] & extras*/
    rhs_slice_target = (object_ptr)&_26075;
    RHS_Slice(_27Argv_20582, 2LL, 3LL);
    Concat((object_ptr)&_27Argv_20582, _26075, _extras_50729);
    DeRefDS(_26075);
    _26075 = NOVALUE;
    DeRef(_26075);
    _26075 = NOVALUE;

    /** cominit.e:593			Argc = length(Argv)*/
    if (IS_SEQUENCE(_27Argv_20582)){
            _27Argc_20581 = SEQ_PTR(_27Argv_20582)->length;
    }
    else {
        _27Argc_20581 = 1;
    }

    /** cominit.e:595			src_name = extras[1]*/
    DeRef(_47src_name_50053);
    _2 = (object)SEQ_PTR(_extras_50729);
    _47src_name_50053 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_47src_name_50053);
L2: 
    DeRef(_pairs_50734);
    _pairs_50734 = NOVALUE;

    /** cominit.e:597	end procedure*/
    DeRef(_opts_50722);
    DeRef(_extras_50729);
    _26059 = NOVALUE;
    _26065 = NOVALUE;
    return;
    ;
}



// 0xA35A89AA
