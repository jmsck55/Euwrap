// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _57get_eucompiledir()
{
    object _x_42981 = NOVALUE;
    object _22598 = NOVALUE;
    object _22594 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:133		object x = getenv("EUCOMPILEDIR")*/
    DeRef(_x_42981);
    _x_42981 = EGetEnv(_22592);

    /** c_decl.e:134		if is_eudir_from_cmdline() then*/
    _22594 = _28is_eudir_from_cmdline();
    if (_22594 == 0) {
        DeRef(_22594);
        _22594 = NOVALUE;
        goto L1; // [11] 20
    }
    else {
        if (!IS_ATOM_INT(_22594) && DBL_PTR(_22594)->dbl == 0.0){
            DeRef(_22594);
            _22594 = NOVALUE;
            goto L1; // [11] 20
        }
        DeRef(_22594);
        _22594 = NOVALUE;
    }
    DeRef(_22594);
    _22594 = NOVALUE;

    /** c_decl.e:135			x = get_eudir()*/
    _0 = _x_42981;
    _x_42981 = _28get_eudir();
    DeRefi(_0);
L1: 

    /** c_decl.e:138		ifdef UNIX then*/

    /** c_decl.e:152		if equal(x, -1) then*/
    if (_x_42981 == -1LL)
    _22598 = 1;
    else if (IS_ATOM_INT(_x_42981) && IS_ATOM_INT(-1LL))
    _22598 = 0;
    else
    _22598 = (compare(_x_42981, -1LL) == 0);
    if (_22598 == 0)
    {
        _22598 = NOVALUE;
        goto L2; // [28] 37
    }
    else{
        _22598 = NOVALUE;
    }

    /** c_decl.e:153			x = get_eudir()*/
    _0 = _x_42981;
    _x_42981 = _28get_eudir();
    DeRef(_0);
L2: 

    /** c_decl.e:156		return x*/
    return _x_42981;
    ;
}


void _57NewBB(object _a_call_42997, object _mask_42998, object _sub_43000)
{
    object _s_43002 = NOVALUE;
    object _22631 = NOVALUE;
    object _22630 = NOVALUE;
    object _22628 = NOVALUE;
    object _22627 = NOVALUE;
    object _22625 = NOVALUE;
    object _22624 = NOVALUE;
    object _22623 = NOVALUE;
    object _22622 = NOVALUE;
    object _22621 = NOVALUE;
    object _22620 = NOVALUE;
    object _22619 = NOVALUE;
    object _22618 = NOVALUE;
    object _22617 = NOVALUE;
    object _22616 = NOVALUE;
    object _22615 = NOVALUE;
    object _22614 = NOVALUE;
    object _22613 = NOVALUE;
    object _22612 = NOVALUE;
    object _22611 = NOVALUE;
    object _22610 = NOVALUE;
    object _22609 = NOVALUE;
    object _22608 = NOVALUE;
    object _22607 = NOVALUE;
    object _22606 = NOVALUE;
    object _22605 = NOVALUE;
    object _22604 = NOVALUE;
    object _22603 = NOVALUE;
    object _22601 = NOVALUE;
    object _22600 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_mask_42998)) {
        _1 = (object)(DBL_PTR(_mask_42998)->dbl);
        DeRefDS(_mask_42998);
        _mask_42998 = _1;
    }

    /** c_decl.e:166		if a_call then*/
    if (_a_call_42997 == 0)
    {
        goto L1; // [9] 252
    }
    else{
    }

    /** c_decl.e:169			for i = 1 to length(BB_info) do*/
    if (IS_SEQUENCE(_57BB_info_42959)){
            _22600 = SEQ_PTR(_57BB_info_42959)->length;
    }
    else {
        _22600 = 1;
    }
    {
        object _i_43005;
        _i_43005 = 1LL;
L2: 
        if (_i_43005 > _22600){
            goto L3; // [19] 249
        }

        /** c_decl.e:170				s = BB_info[i][BB_VAR]*/
        _2 = (object)SEQ_PTR(_57BB_info_42959);
        _22601 = (object)*(((s1_ptr)_2)->base + _i_43005);
        _2 = (object)SEQ_PTR(_22601);
        _s_43002 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (!IS_ATOM_INT(_s_43002)){
            _s_43002 = (object)DBL_PTR(_s_43002)->dbl;
        }
        _22601 = NOVALUE;

        /** c_decl.e:171				if SymTab[s][S_MODE] = M_NORMAL and*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _22603 = (object)*(((s1_ptr)_2)->base + _s_43002);
        _2 = (object)SEQ_PTR(_22603);
        _22604 = (object)*(((s1_ptr)_2)->base + 3LL);
        _22603 = NOVALUE;
        if (IS_ATOM_INT(_22604)) {
            _22605 = (_22604 == 1LL);
        }
        else {
            _22605 = binary_op(EQUALS, _22604, 1LL);
        }
        _22604 = NOVALUE;
        if (IS_ATOM_INT(_22605)) {
            if (_22605 == 0) {
                goto L4; // [60] 242
            }
        }
        else {
            if (DBL_PTR(_22605)->dbl == 0.0) {
                goto L4; // [60] 242
            }
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _22607 = (object)*(((s1_ptr)_2)->base + _s_43002);
        _2 = (object)SEQ_PTR(_22607);
        _22608 = (object)*(((s1_ptr)_2)->base + 4LL);
        _22607 = NOVALUE;
        if (IS_ATOM_INT(_22608)) {
            _22609 = (_22608 == 6LL);
        }
        else {
            _22609 = binary_op(EQUALS, _22608, 6LL);
        }
        _22608 = NOVALUE;
        if (IS_ATOM_INT(_22609)) {
            if (_22609 != 0) {
                DeRef(_22610);
                _22610 = 1;
                goto L5; // [82] 108
            }
        }
        else {
            if (DBL_PTR(_22609)->dbl != 0.0) {
                DeRef(_22610);
                _22610 = 1;
                goto L5; // [82] 108
            }
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _22611 = (object)*(((s1_ptr)_2)->base + _s_43002);
        _2 = (object)SEQ_PTR(_22611);
        _22612 = (object)*(((s1_ptr)_2)->base + 4LL);
        _22611 = NOVALUE;
        if (IS_ATOM_INT(_22612)) {
            _22613 = (_22612 == 5LL);
        }
        else {
            _22613 = binary_op(EQUALS, _22612, 5LL);
        }
        _22612 = NOVALUE;
        DeRef(_22610);
        if (IS_ATOM_INT(_22613))
        _22610 = (_22613 != 0);
        else
        _22610 = DBL_PTR(_22613)->dbl != 0.0;
L5: 
        if (_22610 != 0) {
            _22614 = 1;
            goto L6; // [108] 134
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _22615 = (object)*(((s1_ptr)_2)->base + _s_43002);
        _2 = (object)SEQ_PTR(_22615);
        _22616 = (object)*(((s1_ptr)_2)->base + 4LL);
        _22615 = NOVALUE;
        if (IS_ATOM_INT(_22616)) {
            _22617 = (_22616 == 11LL);
        }
        else {
            _22617 = binary_op(EQUALS, _22616, 11LL);
        }
        _22616 = NOVALUE;
        if (IS_ATOM_INT(_22617))
        _22614 = (_22617 != 0);
        else
        _22614 = DBL_PTR(_22617)->dbl != 0.0;
L6: 
        if (_22614 != 0) {
            DeRef(_22618);
            _22618 = 1;
            goto L7; // [134] 160
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _22619 = (object)*(((s1_ptr)_2)->base + _s_43002);
        _2 = (object)SEQ_PTR(_22619);
        _22620 = (object)*(((s1_ptr)_2)->base + 4LL);
        _22619 = NOVALUE;
        if (IS_ATOM_INT(_22620)) {
            _22621 = (_22620 == 13LL);
        }
        else {
            _22621 = binary_op(EQUALS, _22620, 13LL);
        }
        _22620 = NOVALUE;
        if (IS_ATOM_INT(_22621))
        _22618 = (_22621 != 0);
        else
        _22618 = DBL_PTR(_22621)->dbl != 0.0;
L7: 
        if (_22618 == 0)
        {
            _22618 = NOVALUE;
            goto L4; // [161] 242
        }
        else{
            _22618 = NOVALUE;
        }

        /** c_decl.e:176					  if and_bits(mask, power(2, remainder(s, E_SIZE))) then*/
        _22622 = (_s_43002 % 29LL);
        _22623 = power(2LL, _22622);
        _22622 = NOVALUE;
        if (IS_ATOM_INT(_22623)) {
            {uintptr_t tu;
                 tu = (uintptr_t)_mask_42998 & (uintptr_t)_22623;
                 _22624 = MAKE_UINT(tu);
            }
        }
        else {
            temp_d.dbl = (eudouble)_mask_42998;
            _22624 = Dand_bits(&temp_d, DBL_PTR(_22623));
        }
        DeRef(_22623);
        _22623 = NOVALUE;
        if (_22624 == 0) {
            DeRef(_22624);
            _22624 = NOVALUE;
            goto L8; // [180] 241
        }
        else {
            if (!IS_ATOM_INT(_22624) && DBL_PTR(_22624)->dbl == 0.0){
                DeRef(_22624);
                _22624 = NOVALUE;
                goto L8; // [180] 241
            }
            DeRef(_22624);
            _22624 = NOVALUE;
        }
        DeRef(_22624);
        _22624 = NOVALUE;

        /** c_decl.e:177						  if mask = E_ALL_EFFECT or s < sub then*/
        _22625 = (_mask_42998 == 1073741823LL);
        if (_22625 != 0) {
            goto L9; // [191] 204
        }
        _22627 = (_s_43002 < _sub_43000);
        if (_22627 == 0)
        {
            DeRef(_22627);
            _22627 = NOVALUE;
            goto LA; // [200] 240
        }
        else{
            DeRef(_22627);
            _22627 = NOVALUE;
        }
L9: 

        /** c_decl.e:178							  BB_info[i][BB_TYPE..BB_OBJ] =*/
        _2 = (object)SEQ_PTR(_57BB_info_42959);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _57BB_info_42959 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_43005 + ((s1_ptr)_2)->base);
        Ref(_27MAXINT_20395);
        Ref(_27MININT_20396);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _27MININT_20396;
        ((intptr_t *)_2)[2] = _27MAXINT_20395;
        _22630 = MAKE_SEQ(_1);
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = 0LL;
        ((intptr_t*)_2)[2] = 0LL;
        Ref(_27NOVALUE_20426);
        ((intptr_t*)_2)[3] = _27NOVALUE_20426;
        ((intptr_t*)_2)[4] = _22630;
        _22631 = MAKE_SEQ(_1);
        _22630 = NOVALUE;
        assign_slice_seq = (s1_ptr *)_3;
        AssignSlice(2LL, 5LL, _22631);
        DeRefDS(_22631);
        _22631 = NOVALUE;
LA: 
L8: 
L4: 

        /** c_decl.e:183			end for*/
        _i_43005 = _i_43005 + 1LL;
        goto L2; // [244] 26
L3: 
        ;
    }
    goto LB; // [249] 260
L1: 

    /** c_decl.e:186			BB_info = {}*/
    RefDS(_22218);
    DeRef(_57BB_info_42959);
    _57BB_info_42959 = _22218;
LB: 

    /** c_decl.e:188	end procedure*/
    DeRef(_22621);
    _22621 = NOVALUE;
    DeRef(_22609);
    _22609 = NOVALUE;
    DeRef(_22625);
    _22625 = NOVALUE;
    DeRef(_22613);
    _22613 = NOVALUE;
    DeRef(_22605);
    _22605 = NOVALUE;
    DeRef(_22617);
    _22617 = NOVALUE;
    DeRef(_22628);
    _22628 = NOVALUE;
    return;
    ;
}


object _57BB_var_obj(object _var_43070)
{
    object _bbi_43071 = NOVALUE;
    object _22642 = NOVALUE;
    object _22640 = NOVALUE;
    object _22638 = NOVALUE;
    object _22637 = NOVALUE;
    object _22635 = NOVALUE;
    object _22633 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:196		for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_57BB_info_42959)){
            _22633 = SEQ_PTR(_57BB_info_42959)->length;
    }
    else {
        _22633 = 1;
    }
    {
        object _i_43073;
        _i_43073 = _22633;
L1: 
        if (_i_43073 < 1LL){
            goto L2; // [10] 99
        }

        /** c_decl.e:197			bbi = BB_info[i]*/
        DeRef(_bbi_43071);
        _2 = (object)SEQ_PTR(_57BB_info_42959);
        _bbi_43071 = (object)*(((s1_ptr)_2)->base + _i_43073);
        Ref(_bbi_43071);

        /** c_decl.e:198			if bbi[BB_VAR] != var then*/
        _2 = (object)SEQ_PTR(_bbi_43071);
        _22635 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(EQUALS, _22635, _var_43070)){
            _22635 = NOVALUE;
            goto L3; // [31] 40
        }
        _22635 = NOVALUE;

        /** c_decl.e:199				continue*/
        goto L4; // [37] 94
L3: 

        /** c_decl.e:202			if SymTab[var][S_MODE] != M_NORMAL then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _22637 = (object)*(((s1_ptr)_2)->base + _var_43070);
        _2 = (object)SEQ_PTR(_22637);
        _22638 = (object)*(((s1_ptr)_2)->base + 3LL);
        _22637 = NOVALUE;
        if (binary_op_a(EQUALS, _22638, 1LL)){
            _22638 = NOVALUE;
            goto L5; // [56] 65
        }
        _22638 = NOVALUE;

        /** c_decl.e:203				continue*/
        goto L4; // [62] 94
L5: 

        /** c_decl.e:206			if bbi[BB_TYPE] != TYPE_INTEGER then*/
        _2 = (object)SEQ_PTR(_bbi_43071);
        _22640 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (binary_op_a(EQUALS, _22640, 1LL)){
            _22640 = NOVALUE;
            goto L6; // [73] 82
        }
        _22640 = NOVALUE;

        /** c_decl.e:207				exit*/
        goto L2; // [79] 99
L6: 

        /** c_decl.e:210			return bbi[BB_OBJ]*/
        _2 = (object)SEQ_PTR(_bbi_43071);
        _22642 = (object)*(((s1_ptr)_2)->base + 5LL);
        Ref(_22642);
        DeRef(_bbi_43071);
        return _22642;

        /** c_decl.e:211		end for*/
L4: 
        _i_43073 = _i_43073 + -1LL;
        goto L1; // [94] 17
L2: 
        ;
    }

    /** c_decl.e:212		return BB_def_values*/
    RefDS(_57BB_def_values_43064);
    DeRef(_bbi_43071);
    _22642 = NOVALUE;
    return _57BB_def_values_43064;
    ;
}


object _57BB_var_type(object _var_43093)
{
    object _22658 = NOVALUE;
    object _22657 = NOVALUE;
    object _22655 = NOVALUE;
    object _22654 = NOVALUE;
    object _22652 = NOVALUE;
    object _22651 = NOVALUE;
    object _22650 = NOVALUE;
    object _22649 = NOVALUE;
    object _22648 = NOVALUE;
    object _22647 = NOVALUE;
    object _22646 = NOVALUE;
    object _22645 = NOVALUE;
    object _22644 = NOVALUE;
    object _22643 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:218		for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_57BB_info_42959)){
            _22643 = SEQ_PTR(_57BB_info_42959)->length;
    }
    else {
        _22643 = 1;
    }
    {
        object _i_43095;
        _i_43095 = _22643;
L1: 
        if (_i_43095 < 1LL){
            goto L2; // [10] 125
        }

        /** c_decl.e:219			if BB_info[i][BB_VAR] = var and*/
        _2 = (object)SEQ_PTR(_57BB_info_42959);
        _22644 = (object)*(((s1_ptr)_2)->base + _i_43095);
        _2 = (object)SEQ_PTR(_22644);
        _22645 = (object)*(((s1_ptr)_2)->base + 1LL);
        _22644 = NOVALUE;
        if (IS_ATOM_INT(_22645)) {
            _22646 = (_22645 == _var_43093);
        }
        else {
            _22646 = binary_op(EQUALS, _22645, _var_43093);
        }
        _22645 = NOVALUE;
        if (IS_ATOM_INT(_22646)) {
            if (_22646 == 0) {
                goto L3; // [33] 118
            }
        }
        else {
            if (DBL_PTR(_22646)->dbl == 0.0) {
                goto L3; // [33] 118
            }
        }
        _2 = (object)SEQ_PTR(_57BB_info_42959);
        _22648 = (object)*(((s1_ptr)_2)->base + _i_43095);
        _2 = (object)SEQ_PTR(_22648);
        _22649 = (object)*(((s1_ptr)_2)->base + 1LL);
        _22648 = NOVALUE;
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!IS_ATOM_INT(_22649)){
            _22650 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_22649)->dbl));
        }
        else{
            _22650 = (object)*(((s1_ptr)_2)->base + _22649);
        }
        _2 = (object)SEQ_PTR(_22650);
        _22651 = (object)*(((s1_ptr)_2)->base + 3LL);
        _22650 = NOVALUE;
        if (IS_ATOM_INT(_22651)) {
            _22652 = (_22651 == 1LL);
        }
        else {
            _22652 = binary_op(EQUALS, _22651, 1LL);
        }
        _22651 = NOVALUE;
        if (_22652 == 0) {
            DeRef(_22652);
            _22652 = NOVALUE;
            goto L3; // [66] 118
        }
        else {
            if (!IS_ATOM_INT(_22652) && DBL_PTR(_22652)->dbl == 0.0){
                DeRef(_22652);
                _22652 = NOVALUE;
                goto L3; // [66] 118
            }
            DeRef(_22652);
            _22652 = NOVALUE;
        }
        DeRef(_22652);
        _22652 = NOVALUE;

        /** c_decl.e:221				ifdef DEBUG then*/

        /** c_decl.e:228				if BB_info[i][BB_TYPE] = TYPE_NULL then  -- var has only been read*/
        _2 = (object)SEQ_PTR(_57BB_info_42959);
        _22654 = (object)*(((s1_ptr)_2)->base + _i_43095);
        _2 = (object)SEQ_PTR(_22654);
        _22655 = (object)*(((s1_ptr)_2)->base + 2LL);
        _22654 = NOVALUE;
        if (binary_op_a(NOTEQ, _22655, 0LL)){
            _22655 = NOVALUE;
            goto L4; // [85] 100
        }
        _22655 = NOVALUE;

        /** c_decl.e:229					return TYPE_OBJECT*/
        _22649 = NOVALUE;
        DeRef(_22646);
        _22646 = NOVALUE;
        return 16LL;
        goto L5; // [97] 117
L4: 

        /** c_decl.e:231					return BB_info[i][BB_TYPE]*/
        _2 = (object)SEQ_PTR(_57BB_info_42959);
        _22657 = (object)*(((s1_ptr)_2)->base + _i_43095);
        _2 = (object)SEQ_PTR(_22657);
        _22658 = (object)*(((s1_ptr)_2)->base + 2LL);
        _22657 = NOVALUE;
        Ref(_22658);
        _22649 = NOVALUE;
        DeRef(_22646);
        _22646 = NOVALUE;
        return _22658;
L5: 
L3: 

        /** c_decl.e:234		end for*/
        _i_43095 = _i_43095 + -1LL;
        goto L1; // [120] 17
L2: 
        ;
    }

    /** c_decl.e:235		return TYPE_OBJECT*/
    _22649 = NOVALUE;
    DeRef(_22646);
    _22646 = NOVALUE;
    _22658 = NOVALUE;
    return 16LL;
    ;
}


object _57GType(object _s_43124)
{
    object _t_43125 = NOVALUE;
    object _local_t_43126 = NOVALUE;
    object _22662 = NOVALUE;
    object _22661 = NOVALUE;
    object _22659 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_43124)) {
        _1 = (object)(DBL_PTR(_s_43124)->dbl);
        DeRefDS(_s_43124);
        _s_43124 = _1;
    }

    /** c_decl.e:243		t = SymTab[s][S_GTYPE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22659 = (object)*(((s1_ptr)_2)->base + _s_43124);
    _2 = (object)SEQ_PTR(_22659);
    _t_43125 = (object)*(((s1_ptr)_2)->base + 36LL);
    if (!IS_ATOM_INT(_t_43125)){
        _t_43125 = (object)DBL_PTR(_t_43125)->dbl;
    }
    _22659 = NOVALUE;

    /** c_decl.e:244		ifdef DEBUG then*/

    /** c_decl.e:250		if SymTab[s][S_MODE] != M_NORMAL then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22661 = (object)*(((s1_ptr)_2)->base + _s_43124);
    _2 = (object)SEQ_PTR(_22661);
    _22662 = (object)*(((s1_ptr)_2)->base + 3LL);
    _22661 = NOVALUE;
    if (binary_op_a(EQUALS, _22662, 1LL)){
        _22662 = NOVALUE;
        goto L1; // [37] 48
    }
    _22662 = NOVALUE;

    /** c_decl.e:251			return t*/
    return _t_43125;
L1: 

    /** c_decl.e:254		local_t = BB_var_type(s)*/
    _local_t_43126 = _57BB_var_type(_s_43124);
    if (!IS_ATOM_INT(_local_t_43126)) {
        _1 = (object)(DBL_PTR(_local_t_43126)->dbl);
        DeRefDS(_local_t_43126);
        _local_t_43126 = _1;
    }

    /** c_decl.e:255		if local_t = TYPE_OBJECT then*/
    if (_local_t_43126 != 16LL)
    goto L2; // [60] 71

    /** c_decl.e:256			return t*/
    return _t_43125;
L2: 

    /** c_decl.e:258		if t = TYPE_INTEGER then*/
    if (_t_43125 != 1LL)
    goto L3; // [75] 88

    /** c_decl.e:259			return TYPE_INTEGER*/
    return 1LL;
L3: 

    /** c_decl.e:261		return local_t*/
    return _local_t_43126;
    ;
}


object _57GDelete()
{
    object _0, _1, _2;
    

    /** c_decl.e:269		return g_has_delete*/
    return _57g_has_delete_43146;
    ;
}


object _57HasDelete(object _s_43153)
{
    object _22677 = NOVALUE;
    object _22676 = NOVALUE;
    object _22674 = NOVALUE;
    object _22673 = NOVALUE;
    object _22672 = NOVALUE;
    object _22671 = NOVALUE;
    object _22669 = NOVALUE;
    object _22668 = NOVALUE;
    object _22667 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_43153)) {
        _1 = (object)(DBL_PTR(_s_43153)->dbl);
        DeRefDS(_s_43153);
        _s_43153 = _1;
    }

    /** c_decl.e:274		for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_57BB_info_42959)){
            _22667 = SEQ_PTR(_57BB_info_42959)->length;
    }
    else {
        _22667 = 1;
    }
    {
        object _i_43155;
        _i_43155 = _22667;
L1: 
        if (_i_43155 < 1LL){
            goto L2; // [10] 57
        }

        /** c_decl.e:275			if BB_info[i][BB_VAR] = s then*/
        _2 = (object)SEQ_PTR(_57BB_info_42959);
        _22668 = (object)*(((s1_ptr)_2)->base + _i_43155);
        _2 = (object)SEQ_PTR(_22668);
        _22669 = (object)*(((s1_ptr)_2)->base + 1LL);
        _22668 = NOVALUE;
        if (binary_op_a(NOTEQ, _22669, _s_43153)){
            _22669 = NOVALUE;
            goto L3; // [29] 50
        }
        _22669 = NOVALUE;

        /** c_decl.e:276				return BB_info[i][BB_DELETE]*/
        _2 = (object)SEQ_PTR(_57BB_info_42959);
        _22671 = (object)*(((s1_ptr)_2)->base + _i_43155);
        _2 = (object)SEQ_PTR(_22671);
        _22672 = (object)*(((s1_ptr)_2)->base + 6LL);
        _22671 = NOVALUE;
        Ref(_22672);
        return _22672;
L3: 

        /** c_decl.e:278		end for*/
        _i_43155 = _i_43155 + -1LL;
        goto L1; // [52] 17
L2: 
        ;
    }

    /** c_decl.e:279		if length(SymTab[s]) < S_HAS_DELETE then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22673 = (object)*(((s1_ptr)_2)->base + _s_43153);
    if (IS_SEQUENCE(_22673)){
            _22674 = SEQ_PTR(_22673)->length;
    }
    else {
        _22674 = 1;
    }
    _22673 = NOVALUE;
    if (_22674 >= 54LL)
    goto L4; // [70] 81

    /** c_decl.e:280			return 0*/
    _22673 = NOVALUE;
    _22672 = NOVALUE;
    return 0LL;
L4: 

    /** c_decl.e:282		return SymTab[s][S_HAS_DELETE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22676 = (object)*(((s1_ptr)_2)->base + _s_43153);
    _2 = (object)SEQ_PTR(_22676);
    _22677 = (object)*(((s1_ptr)_2)->base + 54LL);
    _22676 = NOVALUE;
    Ref(_22677);
    _22673 = NOVALUE;
    _22672 = NOVALUE;
    return _22677;
    ;
}


object _57ObjValue(object _s_43176)
{
    object _local_t_43177 = NOVALUE;
    object _st_43178 = NOVALUE;
    object _tmin_43179 = NOVALUE;
    object _tmax_43180 = NOVALUE;
    object _22690 = NOVALUE;
    object _22688 = NOVALUE;
    object _22687 = NOVALUE;
    object _22685 = NOVALUE;
    object _22682 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_43176)) {
        _1 = (object)(DBL_PTR(_s_43176)->dbl);
        DeRefDS(_s_43176);
        _s_43176 = _1;
    }

    /** c_decl.e:293		st = SymTab[s]*/
    DeRef(_st_43178);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _st_43178 = (object)*(((s1_ptr)_2)->base + _s_43176);
    Ref(_st_43178);

    /** c_decl.e:294		tmin = st[S_OBJ_MIN]*/
    DeRef(_tmin_43179);
    _2 = (object)SEQ_PTR(_st_43178);
    _tmin_43179 = (object)*(((s1_ptr)_2)->base + 30LL);
    Ref(_tmin_43179);

    /** c_decl.e:295		tmax = st[S_OBJ_MAX]*/
    DeRef(_tmax_43180);
    _2 = (object)SEQ_PTR(_st_43178);
    _tmax_43180 = (object)*(((s1_ptr)_2)->base + 31LL);
    Ref(_tmax_43180);

    /** c_decl.e:297		if tmin != tmax then*/
    if (binary_op_a(EQUALS, _tmin_43179, _tmax_43180)){
        goto L1; // [29] 41
    }

    /** c_decl.e:298			tmin = NOVALUE*/
    Ref(_27NOVALUE_20426);
    DeRef(_tmin_43179);
    _tmin_43179 = _27NOVALUE_20426;
L1: 

    /** c_decl.e:300		if st[S_MODE] != M_NORMAL then*/
    _2 = (object)SEQ_PTR(_st_43178);
    _22682 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (binary_op_a(EQUALS, _22682, 1LL)){
        _22682 = NOVALUE;
        goto L2; // [51] 62
    }
    _22682 = NOVALUE;

    /** c_decl.e:301			return tmin*/
    DeRef(_local_t_43177);
    DeRef(_st_43178);
    DeRef(_tmax_43180);
    return _tmin_43179;
L2: 

    /** c_decl.e:305		local_t = BB_var_obj(s)*/
    _0 = _local_t_43177;
    _local_t_43177 = _57BB_var_obj(_s_43176);
    DeRef(_0);

    /** c_decl.e:306		if local_t[MIN] = NOVALUE then*/
    _2 = (object)SEQ_PTR(_local_t_43177);
    _22685 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _22685, _27NOVALUE_20426)){
        _22685 = NOVALUE;
        goto L3; // [80] 91
    }
    _22685 = NOVALUE;

    /** c_decl.e:307			return tmin*/
    DeRefDS(_local_t_43177);
    DeRef(_st_43178);
    DeRef(_tmax_43180);
    return _tmin_43179;
L3: 

    /** c_decl.e:310		if local_t[MIN] != local_t[MAX] then*/
    _2 = (object)SEQ_PTR(_local_t_43177);
    _22687 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_local_t_43177);
    _22688 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (binary_op_a(EQUALS, _22687, _22688)){
        _22687 = NOVALUE;
        _22688 = NOVALUE;
        goto L4; // [105] 116
    }
    _22687 = NOVALUE;
    _22688 = NOVALUE;

    /** c_decl.e:311			return tmin*/
    DeRefDS(_local_t_43177);
    DeRef(_st_43178);
    DeRef(_tmax_43180);
    return _tmin_43179;
L4: 

    /** c_decl.e:314		return local_t[MIN]*/
    _2 = (object)SEQ_PTR(_local_t_43177);
    _22690 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_22690);
    DeRefDS(_local_t_43177);
    DeRef(_st_43178);
    DeRef(_tmin_43179);
    DeRef(_tmax_43180);
    return _22690;
    ;
}


object _57TypeIs(object _x_43211, object _typei_43212)
{
    object _22692 = NOVALUE;
    object _22691 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_43211)) {
        _1 = (object)(DBL_PTR(_x_43211)->dbl);
        DeRefDS(_x_43211);
        _x_43211 = _1;
    }

    /** c_decl.e:319		return GType(x) = typei*/
    _22691 = _57GType(_x_43211);
    if (IS_ATOM_INT(_22691)) {
        _22692 = (_22691 == _typei_43212);
    }
    else {
        _22692 = binary_op(EQUALS, _22691, _typei_43212);
    }
    DeRef(_22691);
    _22691 = NOVALUE;
    return _22692;
    ;
}


object _57TypeIsIn(object _x_43217, object _types_43218)
{
    object _22694 = NOVALUE;
    object _22693 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_43217)) {
        _1 = (object)(DBL_PTR(_x_43217)->dbl);
        DeRefDS(_x_43217);
        _x_43217 = _1;
    }

    /** c_decl.e:323		return find(GType(x), types)*/
    _22693 = _57GType(_x_43217);
    _22694 = find_from(_22693, _types_43218, 1LL);
    DeRef(_22693);
    _22693 = NOVALUE;
    DeRefDS(_types_43218);
    return _22694;
    ;
}


object _57TypeIsNot(object _x_43223, object _typei_43224)
{
    object _22696 = NOVALUE;
    object _22695 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_43223)) {
        _1 = (object)(DBL_PTR(_x_43223)->dbl);
        DeRefDS(_x_43223);
        _x_43223 = _1;
    }

    /** c_decl.e:327		return GType(x) != typei*/
    _22695 = _57GType(_x_43223);
    if (IS_ATOM_INT(_22695)) {
        _22696 = (_22695 != _typei_43224);
    }
    else {
        _22696 = binary_op(NOTEQ, _22695, _typei_43224);
    }
    DeRef(_22695);
    _22695 = NOVALUE;
    return _22696;
    ;
}


object _57TypeIsNotIn(object _x_43229, object _types_43230)
{
    object _22699 = NOVALUE;
    object _22698 = NOVALUE;
    object _22697 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_43229)) {
        _1 = (object)(DBL_PTR(_x_43229)->dbl);
        DeRefDS(_x_43229);
        _x_43229 = _1;
    }

    /** c_decl.e:331		return not find(GType(x), types)*/
    _22697 = _57GType(_x_43229);
    _22698 = find_from(_22697, _types_43230, 1LL);
    DeRef(_22697);
    _22697 = NOVALUE;
    _22699 = (_22698 == 0);
    _22698 = NOVALUE;
    DeRefDS(_types_43230);
    return _22699;
    ;
}


object _57or_type(object _t1_43236, object _t2_43237)
{
    object _22719 = NOVALUE;
    object _22718 = NOVALUE;
    object _22717 = NOVALUE;
    object _22716 = NOVALUE;
    object _22711 = NOVALUE;
    object _22709 = NOVALUE;
    object _22704 = NOVALUE;
    object _22702 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_t1_43236)) {
        _1 = (object)(DBL_PTR(_t1_43236)->dbl);
        DeRefDS(_t1_43236);
        _t1_43236 = _1;
    }
    if (!IS_ATOM_INT(_t2_43237)) {
        _1 = (object)(DBL_PTR(_t2_43237)->dbl);
        DeRefDS(_t2_43237);
        _t2_43237 = _1;
    }

    /** c_decl.e:337		if t1 = TYPE_NULL then*/
    if (_t1_43236 != 0LL)
    goto L1; // [9] 22

    /** c_decl.e:338			return t2*/
    return _t2_43237;
    goto L2; // [19] 307
L1: 

    /** c_decl.e:340		elsif t2 = TYPE_NULL then*/
    if (_t2_43237 != 0LL)
    goto L3; // [26] 39

    /** c_decl.e:341			return t1*/
    return _t1_43236;
    goto L2; // [36] 307
L3: 

    /** c_decl.e:343		elsif t1 = TYPE_OBJECT or t2 = TYPE_OBJECT then*/
    _22702 = (_t1_43236 == 16LL);
    if (_22702 != 0) {
        goto L4; // [47] 62
    }
    _22704 = (_t2_43237 == 16LL);
    if (_22704 == 0)
    {
        DeRef(_22704);
        _22704 = NOVALUE;
        goto L5; // [58] 73
    }
    else{
        DeRef(_22704);
        _22704 = NOVALUE;
    }
L4: 

    /** c_decl.e:344			return TYPE_OBJECT*/
    DeRef(_22702);
    _22702 = NOVALUE;
    return 16LL;
    goto L2; // [70] 307
L5: 

    /** c_decl.e:346		elsif t1 = TYPE_SEQUENCE then*/
    if (_t1_43236 != 8LL)
    goto L6; // [77] 112

    /** c_decl.e:347			if t2 = TYPE_SEQUENCE then*/
    if (_t2_43237 != 8LL)
    goto L7; // [85] 100

    /** c_decl.e:348				return TYPE_SEQUENCE*/
    DeRef(_22702);
    _22702 = NOVALUE;
    return 8LL;
    goto L2; // [97] 307
L7: 

    /** c_decl.e:350				return TYPE_OBJECT*/
    DeRef(_22702);
    _22702 = NOVALUE;
    return 16LL;
    goto L2; // [109] 307
L6: 

    /** c_decl.e:353		elsif t2 = TYPE_SEQUENCE then*/
    if (_t2_43237 != 8LL)
    goto L8; // [116] 151

    /** c_decl.e:354			if t1 = TYPE_SEQUENCE then*/
    if (_t1_43236 != 8LL)
    goto L9; // [124] 139

    /** c_decl.e:355				return TYPE_SEQUENCE*/
    DeRef(_22702);
    _22702 = NOVALUE;
    return 8LL;
    goto L2; // [136] 307
L9: 

    /** c_decl.e:357				return TYPE_OBJECT*/
    DeRef(_22702);
    _22702 = NOVALUE;
    return 16LL;
    goto L2; // [148] 307
L8: 

    /** c_decl.e:360		elsif t1 = TYPE_ATOM or t2 = TYPE_ATOM then*/
    _22709 = (_t1_43236 == 4LL);
    if (_22709 != 0) {
        goto LA; // [159] 174
    }
    _22711 = (_t2_43237 == 4LL);
    if (_22711 == 0)
    {
        DeRef(_22711);
        _22711 = NOVALUE;
        goto LB; // [170] 185
    }
    else{
        DeRef(_22711);
        _22711 = NOVALUE;
    }
LA: 

    /** c_decl.e:361			return TYPE_ATOM*/
    DeRef(_22702);
    _22702 = NOVALUE;
    DeRef(_22709);
    _22709 = NOVALUE;
    return 4LL;
    goto L2; // [182] 307
LB: 

    /** c_decl.e:363		elsif t1 = TYPE_DOUBLE then*/
    if (_t1_43236 != 2LL)
    goto LC; // [189] 224

    /** c_decl.e:364			if t2 = TYPE_INTEGER then*/
    if (_t2_43237 != 1LL)
    goto LD; // [197] 212

    /** c_decl.e:365				return TYPE_ATOM*/
    DeRef(_22702);
    _22702 = NOVALUE;
    DeRef(_22709);
    _22709 = NOVALUE;
    return 4LL;
    goto L2; // [209] 307
LD: 

    /** c_decl.e:367				return TYPE_DOUBLE*/
    DeRef(_22702);
    _22702 = NOVALUE;
    DeRef(_22709);
    _22709 = NOVALUE;
    return 2LL;
    goto L2; // [221] 307
LC: 

    /** c_decl.e:370		elsif t2 = TYPE_DOUBLE then*/
    if (_t2_43237 != 2LL)
    goto LE; // [228] 263

    /** c_decl.e:371			if t1 = TYPE_INTEGER then*/
    if (_t1_43236 != 1LL)
    goto LF; // [236] 251

    /** c_decl.e:372				return TYPE_ATOM*/
    DeRef(_22702);
    _22702 = NOVALUE;
    DeRef(_22709);
    _22709 = NOVALUE;
    return 4LL;
    goto L2; // [248] 307
LF: 

    /** c_decl.e:374				return TYPE_DOUBLE*/
    DeRef(_22702);
    _22702 = NOVALUE;
    DeRef(_22709);
    _22709 = NOVALUE;
    return 2LL;
    goto L2; // [260] 307
LE: 

    /** c_decl.e:377		elsif t1 = TYPE_INTEGER and t2 = TYPE_INTEGER then*/
    _22716 = (_t1_43236 == 1LL);
    if (_22716 == 0) {
        goto L10; // [271] 296
    }
    _22718 = (_t2_43237 == 1LL);
    if (_22718 == 0)
    {
        DeRef(_22718);
        _22718 = NOVALUE;
        goto L10; // [282] 296
    }
    else{
        DeRef(_22718);
        _22718 = NOVALUE;
    }

    /** c_decl.e:378			return TYPE_INTEGER*/
    DeRef(_22702);
    _22702 = NOVALUE;
    DeRef(_22709);
    _22709 = NOVALUE;
    DeRef(_22716);
    _22716 = NOVALUE;
    return 1LL;
    goto L2; // [293] 307
L10: 

    /** c_decl.e:381			InternalErr(258, {t1, t2})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _t1_43236;
    ((intptr_t *)_2)[2] = _t2_43237;
    _22719 = MAKE_SEQ(_1);
    _49InternalErr(258LL, _22719);
    _22719 = NOVALUE;
L2: 
    ;
}


void _57RemoveFromBB(object _s_43307)
{
    object _int_43308 = NOVALUE;
    object _22721 = NOVALUE;
    object _22720 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:388		for i = 1 to length(BB_info) do*/
    if (IS_SEQUENCE(_57BB_info_42959)){
            _22720 = SEQ_PTR(_57BB_info_42959)->length;
    }
    else {
        _22720 = 1;
    }
    {
        object _i_43310;
        _i_43310 = 1LL;
L1: 
        if (_i_43310 > _22720){
            goto L2; // [10] 59
        }

        /** c_decl.e:389			int = BB_info[i][BB_VAR]*/
        _2 = (object)SEQ_PTR(_57BB_info_42959);
        _22721 = (object)*(((s1_ptr)_2)->base + _i_43310);
        _2 = (object)SEQ_PTR(_22721);
        _int_43308 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (!IS_ATOM_INT(_int_43308)){
            _int_43308 = (object)DBL_PTR(_int_43308)->dbl;
        }
        _22721 = NOVALUE;

        /** c_decl.e:390			if int = s then*/
        if (_int_43308 != _s_43307)
        goto L3; // [33] 52

        /** c_decl.e:391				BB_info = remove( BB_info, int )*/
        {
            s1_ptr assign_space = SEQ_PTR(_57BB_info_42959);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_int_43308)) ? _int_43308 : (object)(DBL_PTR(_int_43308)->dbl);
            int stop = (IS_ATOM_INT(_int_43308)) ? _int_43308 : (object)(DBL_PTR(_int_43308)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_57BB_info_42959), start, &_57BB_info_42959 );
                }
                else Tail(SEQ_PTR(_57BB_info_42959), stop+1, &_57BB_info_42959);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_57BB_info_42959), start, &_57BB_info_42959);
            }
            else {
                assign_slice_seq = &assign_space;
                _57BB_info_42959 = Remove_elements(start, stop, (SEQ_PTR(_57BB_info_42959)->ref == 1));
            }
        }

        /** c_decl.e:392				return*/
        return;
L3: 

        /** c_decl.e:394		end for*/
        _i_43310 = _i_43310 + 1LL;
        goto L1; // [54] 17
L2: 
        ;
    }

    /** c_decl.e:395	end procedure*/
    return;
    ;
}


void _57SetBBType(object _s_43328, object _t_43329, object _val_43330, object _etype_43331, object _has_delete_43332)
{
    object _found_43333 = NOVALUE;
    object _i_43334 = NOVALUE;
    object _tn_43335 = NOVALUE;
    object _int_43336 = NOVALUE;
    object _sym_43337 = NOVALUE;
    object _mode_43342 = NOVALUE;
    object _gtype_43357 = NOVALUE;
    object _new_type_43394 = NOVALUE;
    object _bbsym_43417 = NOVALUE;
    object _bbi_43553 = NOVALUE;
    object _22840 = NOVALUE;
    object _22839 = NOVALUE;
    object _22838 = NOVALUE;
    object _22836 = NOVALUE;
    object _22835 = NOVALUE;
    object _22834 = NOVALUE;
    object _22832 = NOVALUE;
    object _22831 = NOVALUE;
    object _22829 = NOVALUE;
    object _22827 = NOVALUE;
    object _22826 = NOVALUE;
    object _22824 = NOVALUE;
    object _22822 = NOVALUE;
    object _22821 = NOVALUE;
    object _22820 = NOVALUE;
    object _22819 = NOVALUE;
    object _22818 = NOVALUE;
    object _22817 = NOVALUE;
    object _22816 = NOVALUE;
    object _22815 = NOVALUE;
    object _22814 = NOVALUE;
    object _22811 = NOVALUE;
    object _22807 = NOVALUE;
    object _22802 = NOVALUE;
    object _22800 = NOVALUE;
    object _22799 = NOVALUE;
    object _22798 = NOVALUE;
    object _22796 = NOVALUE;
    object _22794 = NOVALUE;
    object _22793 = NOVALUE;
    object _22792 = NOVALUE;
    object _22790 = NOVALUE;
    object _22789 = NOVALUE;
    object _22787 = NOVALUE;
    object _22786 = NOVALUE;
    object _22785 = NOVALUE;
    object _22783 = NOVALUE;
    object _22782 = NOVALUE;
    object _22779 = NOVALUE;
    object _22778 = NOVALUE;
    object _22777 = NOVALUE;
    object _22775 = NOVALUE;
    object _22773 = NOVALUE;
    object _22772 = NOVALUE;
    object _22770 = NOVALUE;
    object _22769 = NOVALUE;
    object _22768 = NOVALUE;
    object _22766 = NOVALUE;
    object _22765 = NOVALUE;
    object _22754 = NOVALUE;
    object _22752 = NOVALUE;
    object _22749 = NOVALUE;
    object _22748 = NOVALUE;
    object _22745 = NOVALUE;
    object _22744 = NOVALUE;
    object _22743 = NOVALUE;
    object _22741 = NOVALUE;
    object _22740 = NOVALUE;
    object _22739 = NOVALUE;
    object _22737 = NOVALUE;
    object _22736 = NOVALUE;
    object _22734 = NOVALUE;
    object _22731 = NOVALUE;
    object _22729 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_43328)) {
        _1 = (object)(DBL_PTR(_s_43328)->dbl);
        DeRefDS(_s_43328);
        _s_43328 = _1;
    }
    if (!IS_ATOM_INT(_t_43329)) {
        _1 = (object)(DBL_PTR(_t_43329)->dbl);
        DeRefDS(_t_43329);
        _t_43329 = _1;
    }
    if (!IS_ATOM_INT(_etype_43331)) {
        _1 = (object)(DBL_PTR(_etype_43331)->dbl);
        DeRefDS(_etype_43331);
        _etype_43331 = _1;
    }
    if (!IS_ATOM_INT(_has_delete_43332)) {
        _1 = (object)(DBL_PTR(_has_delete_43332)->dbl);
        DeRefDS(_has_delete_43332);
        _has_delete_43332 = _1;
    }

    /** c_decl.e:416		if has_delete then*/
    if (_has_delete_43332 == 0)
    {
        goto L1; // [13] 27
    }
    else{
    }

    /** c_decl.e:417			p_has_delete = 1*/
    _57p_has_delete_43147 = 1LL;

    /** c_decl.e:418			g_has_delete = 1*/
    _57g_has_delete_43146 = 1LL;
L1: 

    /** c_decl.e:421		sym = SymTab[s]*/
    DeRef(_sym_43337);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _sym_43337 = (object)*(((s1_ptr)_2)->base + _s_43328);
    Ref(_sym_43337);

    /** c_decl.e:422		SymTab[s] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _s_43328);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** c_decl.e:424		integer mode = sym[S_MODE]*/
    _2 = (object)SEQ_PTR(_sym_43337);
    _mode_43342 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_mode_43342))
    _mode_43342 = (object)DBL_PTR(_mode_43342)->dbl;

    /** c_decl.e:425		if mode = M_NORMAL or mode = M_TEMP  then*/
    _22729 = (_mode_43342 == 1LL);
    if (_22729 != 0) {
        goto L2; // [61] 76
    }
    _22731 = (_mode_43342 == 3LL);
    if (_22731 == 0)
    {
        DeRef(_22731);
        _22731 = NOVALUE;
        goto L3; // [72] 1167
    }
    else{
        DeRef(_22731);
        _22731 = NOVALUE;
    }
L2: 

    /** c_decl.e:427			found = FALSE*/
    _found_43333 = _9FALSE_439;

    /** c_decl.e:428			if mode = M_TEMP then*/
    if (_mode_43342 != 3LL)
    goto L4; // [89] 465

    /** c_decl.e:429				sym[S_GTYPE] = t*/
    _2 = (object)SEQ_PTR(_sym_43337);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43337 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _t_43329;
    DeRef(_1);

    /** c_decl.e:430				sym[S_SEQ_ELEM] = etype*/
    _2 = (object)SEQ_PTR(_sym_43337);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43337 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _etype_43331;
    DeRef(_1);

    /** c_decl.e:431				integer gtype = sym[S_GTYPE]*/
    _2 = (object)SEQ_PTR(_sym_43337);
    _gtype_43357 = (object)*(((s1_ptr)_2)->base + 36LL);
    if (!IS_ATOM_INT(_gtype_43357))
    _gtype_43357 = (object)DBL_PTR(_gtype_43357)->dbl;

    /** c_decl.e:432				if gtype = TYPE_OBJECT*/
    _22734 = (_gtype_43357 == 16LL);
    if (_22734 != 0) {
        goto L5; // [125] 140
    }
    _22736 = (_gtype_43357 == 8LL);
    if (_22736 == 0)
    {
        DeRef(_22736);
        _22736 = NOVALUE;
        goto L6; // [136] 213
    }
    else{
        DeRef(_22736);
        _22736 = NOVALUE;
    }
L5: 

    /** c_decl.e:435					if val[MIN] < 0 then*/
    _2 = (object)SEQ_PTR(_val_43330);
    _22737 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(GREATEREQ, _22737, 0LL)){
        _22737 = NOVALUE;
        goto L7; // [148] 165
    }
    _22737 = NOVALUE;

    /** c_decl.e:436						sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_sym_43337);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43337 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
    goto L8; // [162] 180
L7: 

    /** c_decl.e:438						sym[S_SEQ_LEN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43330);
    _22739 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_22739);
    _2 = (object)SEQ_PTR(_sym_43337);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43337 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22739;
    if( _1 != _22739 ){
        DeRef(_1);
    }
    _22739 = NOVALUE;
L8: 

    /** c_decl.e:440					sym[S_OBJ] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_sym_43337);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43337 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);

    /** c_decl.e:442					sym[S_OBJ_MIN] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_sym_43337);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43337 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);

    /** c_decl.e:443					sym[S_OBJ_MAX] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_sym_43337);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43337 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
    goto L9; // [210] 252
L6: 

    /** c_decl.e:445					sym[S_OBJ_MIN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43330);
    _22740 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_22740);
    _2 = (object)SEQ_PTR(_sym_43337);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43337 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22740;
    if( _1 != _22740 ){
        DeRef(_1);
    }
    _22740 = NOVALUE;

    /** c_decl.e:446					sym[S_OBJ_MAX] = val[MAX]*/
    _2 = (object)SEQ_PTR(_val_43330);
    _22741 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_22741);
    _2 = (object)SEQ_PTR(_sym_43337);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43337 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22741;
    if( _1 != _22741 ){
        DeRef(_1);
    }
    _22741 = NOVALUE;

    /** c_decl.e:447					sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_sym_43337);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43337 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
L9: 

    /** c_decl.e:449				if not Initializing then*/
    if (_27Initializing_20652 != 0)
    goto LA; // [256] 326

    /** c_decl.e:450					integer new_type = or_type(temp_name_type[sym[S_TEMP_NAME]][T_GTYPE_NEW], t)*/
    _2 = (object)SEQ_PTR(_sym_43337);
    _22743 = (object)*(((s1_ptr)_2)->base + 34LL);
    _2 = (object)SEQ_PTR(_27temp_name_type_20654);
    if (!IS_ATOM_INT(_22743)){
        _22744 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_22743)->dbl));
    }
    else{
        _22744 = (object)*(((s1_ptr)_2)->base + _22743);
    }
    _2 = (object)SEQ_PTR(_22744);
    _22745 = (object)*(((s1_ptr)_2)->base + 2LL);
    _22744 = NOVALUE;
    Ref(_22745);
    _new_type_43394 = _57or_type(_22745, _t_43329);
    _22745 = NOVALUE;
    if (!IS_ATOM_INT(_new_type_43394)) {
        _1 = (object)(DBL_PTR(_new_type_43394)->dbl);
        DeRefDS(_new_type_43394);
        _new_type_43394 = _1;
    }

    /** c_decl.e:451					if new_type = TYPE_NULL then*/
    if (_new_type_43394 != 0LL)
    goto LB; // [290] 304

    /** c_decl.e:452						new_type = TYPE_OBJECT*/
    _new_type_43394 = 16LL;
LB: 

    /** c_decl.e:454					temp_name_type[sym[S_TEMP_NAME]][T_GTYPE_NEW] = new_type*/
    _2 = (object)SEQ_PTR(_sym_43337);
    _22748 = (object)*(((s1_ptr)_2)->base + 34LL);
    _2 = (object)SEQ_PTR(_27temp_name_type_20654);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27temp_name_type_20654 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_22748))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_22748)->dbl));
    else
    _3 = (object)(_22748 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _new_type_43394;
    DeRef(_1);
    _22749 = NOVALUE;
LA: 

    /** c_decl.e:458				tn = sym[S_TEMP_NAME]*/
    _2 = (object)SEQ_PTR(_sym_43337);
    _tn_43335 = (object)*(((s1_ptr)_2)->base + 34LL);
    if (!IS_ATOM_INT(_tn_43335))
    _tn_43335 = (object)DBL_PTR(_tn_43335)->dbl;

    /** c_decl.e:459				i = 1*/
    _i_43334 = 1LL;

    /** c_decl.e:460				while i <= length(BB_info) do*/
LC: 
    if (IS_SEQUENCE(_57BB_info_42959)){
            _22752 = SEQ_PTR(_57BB_info_42959)->length;
    }
    else {
        _22752 = 1;
    }
    if (_i_43334 > _22752)
    goto LD; // [351] 460

    /** c_decl.e:461					sequence bbsym*/

    /** c_decl.e:462					int = BB_info[i][BB_VAR]*/
    _2 = (object)SEQ_PTR(_57BB_info_42959);
    _22754 = (object)*(((s1_ptr)_2)->base + _i_43334);
    _2 = (object)SEQ_PTR(_22754);
    _int_43336 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_int_43336)){
        _int_43336 = (object)DBL_PTR(_int_43336)->dbl;
    }
    _22754 = NOVALUE;

    /** c_decl.e:463					if int = s then*/
    if (_int_43336 != _s_43328)
    goto LE; // [373] 387

    /** c_decl.e:464						bbsym = sym*/
    RefDS(_sym_43337);
    DeRef(_bbsym_43417);
    _bbsym_43417 = _sym_43337;
    goto LF; // [384] 398
LE: 

    /** c_decl.e:466						bbsym = SymTab[int]*/
    DeRef(_bbsym_43417);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _bbsym_43417 = (object)*(((s1_ptr)_2)->base + _int_43336);
    Ref(_bbsym_43417);
LF: 

    /** c_decl.e:468					int = bbsym[S_MODE]*/
    _2 = (object)SEQ_PTR(_bbsym_43417);
    _int_43336 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_int_43336))
    _int_43336 = (object)DBL_PTR(_int_43336)->dbl;

    /** c_decl.e:469					if int = M_TEMP then*/
    if (_int_43336 != 3LL)
    goto L10; // [412] 447

    /** c_decl.e:470						int = bbsym[S_TEMP_NAME]*/
    _2 = (object)SEQ_PTR(_bbsym_43417);
    _int_43336 = (object)*(((s1_ptr)_2)->base + 34LL);
    if (!IS_ATOM_INT(_int_43336))
    _int_43336 = (object)DBL_PTR(_int_43336)->dbl;

    /** c_decl.e:471						if int = tn then*/
    if (_int_43336 != _tn_43335)
    goto L11; // [426] 446

    /** c_decl.e:472							found = TRUE*/
    _found_43333 = _9TRUE_441;

    /** c_decl.e:473							exit*/
    DeRefDS(_bbsym_43417);
    _bbsym_43417 = NOVALUE;
    goto LD; // [443] 460
L11: 
L10: 

    /** c_decl.e:476					i += 1*/
    _i_43334 = _i_43334 + 1;
    DeRef(_bbsym_43417);
    _bbsym_43417 = NOVALUE;

    /** c_decl.e:477				end while*/
    goto LC; // [457] 346
LD: 
    goto L12; // [462] 889
L4: 

    /** c_decl.e:479				if t != TYPE_NULL then*/
    if (_t_43329 == 0LL)
    goto L13; // [469] 824

    /** c_decl.e:480					if not Initializing then*/
    if (_27Initializing_20652 != 0)
    goto L14; // [477] 500

    /** c_decl.e:481						sym[S_GTYPE_NEW] = or_type(sym[S_GTYPE_NEW], t)*/
    _2 = (object)SEQ_PTR(_sym_43337);
    _22765 = (object)*(((s1_ptr)_2)->base + 38LL);
    Ref(_22765);
    _22766 = _57or_type(_22765, _t_43329);
    _22765 = NOVALUE;
    _2 = (object)SEQ_PTR(_sym_43337);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43337 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 38LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22766;
    if( _1 != _22766 ){
        DeRef(_1);
    }
    _22766 = NOVALUE;
L14: 

    /** c_decl.e:484					if t = TYPE_SEQUENCE then*/
    if (_t_43329 != 8LL)
    goto L15; // [504] 633

    /** c_decl.e:485						sym[S_SEQ_ELEM_NEW] =*/
    _2 = (object)SEQ_PTR(_sym_43337);
    _22768 = (object)*(((s1_ptr)_2)->base + 40LL);
    Ref(_22768);
    _22769 = _57or_type(_22768, _etype_43331);
    _22768 = NOVALUE;
    _2 = (object)SEQ_PTR(_sym_43337);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43337 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22769;
    if( _1 != _22769 ){
        DeRef(_1);
    }
    _22769 = NOVALUE;

    /** c_decl.e:488						if val[MIN] != -1 then*/
    _2 = (object)SEQ_PTR(_val_43330);
    _22770 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _22770, -1LL)){
        _22770 = NOVALUE;
        goto L16; // [535] 823
    }
    _22770 = NOVALUE;

    /** c_decl.e:489							if sym[S_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_43337);
    _22772 = (object)*(((s1_ptr)_2)->base + 39LL);
    if (IS_ATOM_INT(_27NOVALUE_20426)) {
        if ((uintptr_t)_27NOVALUE_20426 == (uintptr_t)HIGH_BITS){
            _22773 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22773 = - _27NOVALUE_20426;
        }
    }
    else {
        _22773 = unary_op(UMINUS, _27NOVALUE_20426);
    }
    if (binary_op_a(NOTEQ, _22772, _22773)){
        _22772 = NOVALUE;
        DeRef(_22773);
        _22773 = NOVALUE;
        goto L17; // [552] 599
    }
    _22772 = NOVALUE;
    DeRef(_22773);
    _22773 = NOVALUE;

    /** c_decl.e:490								if val[MIN] < 0 then*/
    _2 = (object)SEQ_PTR(_val_43330);
    _22775 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(GREATEREQ, _22775, 0LL)){
        _22775 = NOVALUE;
        goto L18; // [564] 581
    }
    _22775 = NOVALUE;

    /** c_decl.e:491									sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_sym_43337);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43337 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
    goto L16; // [578] 823
L18: 

    /** c_decl.e:493									sym[S_SEQ_LEN_NEW] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43330);
    _22777 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_22777);
    _2 = (object)SEQ_PTR(_sym_43337);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43337 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22777;
    if( _1 != _22777 ){
        DeRef(_1);
    }
    _22777 = NOVALUE;
    goto L16; // [596] 823
L17: 

    /** c_decl.e:495							elsif val[MIN] != sym[S_SEQ_LEN_NEW] then*/
    _2 = (object)SEQ_PTR(_val_43330);
    _22778 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_sym_43337);
    _22779 = (object)*(((s1_ptr)_2)->base + 39LL);
    if (binary_op_a(EQUALS, _22778, _22779)){
        _22778 = NOVALUE;
        _22779 = NOVALUE;
        goto L16; // [613] 823
    }
    _22778 = NOVALUE;
    _22779 = NOVALUE;

    /** c_decl.e:496								sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_sym_43337);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43337 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
    goto L16; // [630] 823
L15: 

    /** c_decl.e:500					elsif t = TYPE_INTEGER then*/
    if (_t_43329 != 1LL)
    goto L19; // [637] 774

    /** c_decl.e:502						if sym[S_OBJ_MIN_NEW] = -NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_43337);
    _22782 = (object)*(((s1_ptr)_2)->base + 41LL);
    if (IS_ATOM_INT(_27NOVALUE_20426)) {
        if ((uintptr_t)_27NOVALUE_20426 == (uintptr_t)HIGH_BITS){
            _22783 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22783 = - _27NOVALUE_20426;
        }
    }
    else {
        _22783 = unary_op(UMINUS, _27NOVALUE_20426);
    }
    if (binary_op_a(NOTEQ, _22782, _22783)){
        _22782 = NOVALUE;
        DeRef(_22783);
        _22783 = NOVALUE;
        goto L1A; // [654] 689
    }
    _22782 = NOVALUE;
    DeRef(_22783);
    _22783 = NOVALUE;

    /** c_decl.e:504							sym[S_OBJ_MIN_NEW] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43330);
    _22785 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_22785);
    _2 = (object)SEQ_PTR(_sym_43337);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43337 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22785;
    if( _1 != _22785 ){
        DeRef(_1);
    }
    _22785 = NOVALUE;

    /** c_decl.e:505							sym[S_OBJ_MAX_NEW] = val[MAX]*/
    _2 = (object)SEQ_PTR(_val_43330);
    _22786 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_22786);
    _2 = (object)SEQ_PTR(_sym_43337);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43337 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 42LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22786;
    if( _1 != _22786 ){
        DeRef(_1);
    }
    _22786 = NOVALUE;
    goto L16; // [686] 823
L1A: 

    /** c_decl.e:507						elsif sym[S_OBJ_MIN_NEW] != NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_43337);
    _22787 = (object)*(((s1_ptr)_2)->base + 41LL);
    if (binary_op_a(EQUALS, _22787, _27NOVALUE_20426)){
        _22787 = NOVALUE;
        goto L16; // [699] 823
    }
    _22787 = NOVALUE;

    /** c_decl.e:509							if val[MIN] < sym[S_OBJ_MIN_NEW] then*/
    _2 = (object)SEQ_PTR(_val_43330);
    _22789 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_sym_43337);
    _22790 = (object)*(((s1_ptr)_2)->base + 41LL);
    if (binary_op_a(GREATEREQ, _22789, _22790)){
        _22789 = NOVALUE;
        _22790 = NOVALUE;
        goto L1B; // [717] 736
    }
    _22789 = NOVALUE;
    _22790 = NOVALUE;

    /** c_decl.e:510								sym[S_OBJ_MIN_NEW] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43330);
    _22792 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_22792);
    _2 = (object)SEQ_PTR(_sym_43337);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43337 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22792;
    if( _1 != _22792 ){
        DeRef(_1);
    }
    _22792 = NOVALUE;
L1B: 

    /** c_decl.e:512							if val[MAX] > sym[S_OBJ_MAX_NEW] then*/
    _2 = (object)SEQ_PTR(_val_43330);
    _22793 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_sym_43337);
    _22794 = (object)*(((s1_ptr)_2)->base + 42LL);
    if (binary_op_a(LESSEQ, _22793, _22794)){
        _22793 = NOVALUE;
        _22794 = NOVALUE;
        goto L16; // [750] 823
    }
    _22793 = NOVALUE;
    _22794 = NOVALUE;

    /** c_decl.e:513								sym[S_OBJ_MAX_NEW] = val[MAX]*/
    _2 = (object)SEQ_PTR(_val_43330);
    _22796 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_22796);
    _2 = (object)SEQ_PTR(_sym_43337);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43337 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 42LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22796;
    if( _1 != _22796 ){
        DeRef(_1);
    }
    _22796 = NOVALUE;
    goto L16; // [771] 823
L19: 

    /** c_decl.e:518						sym[S_OBJ_MIN_NEW] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_sym_43337);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43337 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);

    /** c_decl.e:519						if t = TYPE_OBJECT then*/
    if (_t_43329 != 16LL)
    goto L1C; // [788] 822

    /** c_decl.e:522							sym[S_SEQ_ELEM_NEW] =*/
    _2 = (object)SEQ_PTR(_sym_43337);
    _22798 = (object)*(((s1_ptr)_2)->base + 40LL);
    Ref(_22798);
    _22799 = _57or_type(_22798, _etype_43331);
    _22798 = NOVALUE;
    _2 = (object)SEQ_PTR(_sym_43337);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43337 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22799;
    if( _1 != _22799 ){
        DeRef(_1);
    }
    _22799 = NOVALUE;

    /** c_decl.e:524							sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_sym_43337);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43337 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
L1C: 
L16: 
L13: 

    /** c_decl.e:529				i = 1*/
    _i_43334 = 1LL;

    /** c_decl.e:530				while i <= length(BB_info) do*/
L1D: 
    if (IS_SEQUENCE(_57BB_info_42959)){
            _22800 = SEQ_PTR(_57BB_info_42959)->length;
    }
    else {
        _22800 = 1;
    }
    if (_i_43334 > _22800)
    goto L1E; // [839] 888

    /** c_decl.e:531					int = BB_info[i][BB_VAR]*/
    _2 = (object)SEQ_PTR(_57BB_info_42959);
    _22802 = (object)*(((s1_ptr)_2)->base + _i_43334);
    _2 = (object)SEQ_PTR(_22802);
    _int_43336 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_int_43336)){
        _int_43336 = (object)DBL_PTR(_int_43336)->dbl;
    }
    _22802 = NOVALUE;

    /** c_decl.e:532					if int = s then*/
    if (_int_43336 != _s_43328)
    goto L1F; // [859] 877

    /** c_decl.e:533						found = TRUE*/
    _found_43333 = _9TRUE_441;

    /** c_decl.e:534						exit*/
    goto L1E; // [874] 888
L1F: 

    /** c_decl.e:536					i += 1*/
    _i_43334 = _i_43334 + 1;

    /** c_decl.e:537				end while*/
    goto L1D; // [885] 834
L1E: 
L12: 

    /** c_decl.e:541			if not found then*/
    if (_found_43333 != 0)
    goto L20; // [891] 907

    /** c_decl.e:543				BB_info = append(BB_info, repeat(0, 6))*/
    _22807 = Repeat(0LL, 6LL);
    RefDS(_22807);
    Append(&_57BB_info_42959, _57BB_info_42959, _22807);
    DeRefDS(_22807);
    _22807 = NOVALUE;
L20: 

    /** c_decl.e:546			if t = TYPE_NULL then*/
    if (_t_43329 != 0LL)
    goto L21; // [911] 949

    /** c_decl.e:547				if not found then*/
    if (_found_43333 != 0)
    goto L22; // [917] 1308

    /** c_decl.e:549					BB_info[i] = dummy_bb*/
    RefDS(_57dummy_bb_43317);
    _2 = (object)SEQ_PTR(_57BB_info_42959);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _57BB_info_42959 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _i_43334);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _57dummy_bb_43317;
    DeRef(_1);

    /** c_decl.e:550					BB_info[i][BB_VAR] = s*/
    _2 = (object)SEQ_PTR(_57BB_info_42959);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _57BB_info_42959 = MAKE_SEQ(_2);
    }
    _3 = (object)(_i_43334 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_43328;
    DeRef(_1);
    _22811 = NOVALUE;
    goto L22; // [946] 1308
L21: 

    /** c_decl.e:554				sequence bbi = BB_info[i]*/
    DeRef(_bbi_43553);
    _2 = (object)SEQ_PTR(_57BB_info_42959);
    _bbi_43553 = (object)*(((s1_ptr)_2)->base + _i_43334);
    Ref(_bbi_43553);

    /** c_decl.e:555				BB_info[i] = 0*/
    _2 = (object)SEQ_PTR(_57BB_info_42959);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _57BB_info_42959 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _i_43334);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** c_decl.e:556				bbi[BB_VAR] = s*/
    _2 = (object)SEQ_PTR(_bbi_43553);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43553 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_43328;
    DeRef(_1);

    /** c_decl.e:557				bbi[BB_TYPE] = t*/
    _2 = (object)SEQ_PTR(_bbi_43553);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43553 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _t_43329;
    DeRef(_1);

    /** c_decl.e:558				bbi[BB_DELETE] = has_delete*/
    _2 = (object)SEQ_PTR(_bbi_43553);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43553 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _has_delete_43332;
    DeRef(_1);

    /** c_decl.e:560				if t = TYPE_SEQUENCE and val[MIN] = -1 then*/
    _22814 = (_t_43329 == 8LL);
    if (_22814 == 0) {
        goto L23; // [995] 1077
    }
    _2 = (object)SEQ_PTR(_val_43330);
    _22816 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_22816)) {
        _22817 = (_22816 == -1LL);
    }
    else {
        _22817 = binary_op(EQUALS, _22816, -1LL);
    }
    _22816 = NOVALUE;
    if (_22817 == 0) {
        DeRef(_22817);
        _22817 = NOVALUE;
        goto L23; // [1010] 1077
    }
    else {
        if (!IS_ATOM_INT(_22817) && DBL_PTR(_22817)->dbl == 0.0){
            DeRef(_22817);
            _22817 = NOVALUE;
            goto L23; // [1010] 1077
        }
        DeRef(_22817);
        _22817 = NOVALUE;
    }
    DeRef(_22817);
    _22817 = NOVALUE;

    /** c_decl.e:562					if found and bbi[BB_ELEM] != TYPE_NULL then*/
    if (_found_43333 == 0) {
        goto L24; // [1015] 1051
    }
    _2 = (object)SEQ_PTR(_bbi_43553);
    _22819 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (IS_ATOM_INT(_22819)) {
        _22820 = (_22819 != 0LL);
    }
    else {
        _22820 = binary_op(NOTEQ, _22819, 0LL);
    }
    _22819 = NOVALUE;
    if (_22820 == 0) {
        DeRef(_22820);
        _22820 = NOVALUE;
        goto L24; // [1030] 1051
    }
    else {
        if (!IS_ATOM_INT(_22820) && DBL_PTR(_22820)->dbl == 0.0){
            DeRef(_22820);
            _22820 = NOVALUE;
            goto L24; // [1030] 1051
        }
        DeRef(_22820);
        _22820 = NOVALUE;
    }
    DeRef(_22820);
    _22820 = NOVALUE;

    /** c_decl.e:564						bbi[BB_ELEM] = or_type(bbi[BB_ELEM], etype)*/
    _2 = (object)SEQ_PTR(_bbi_43553);
    _22821 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_22821);
    _22822 = _57or_type(_22821, _etype_43331);
    _22821 = NOVALUE;
    _2 = (object)SEQ_PTR(_bbi_43553);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43553 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22822;
    if( _1 != _22822 ){
        DeRef(_1);
    }
    _22822 = NOVALUE;
    goto L25; // [1048] 1060
L24: 

    /** c_decl.e:566						bbi[BB_ELEM] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_bbi_43553);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43553 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
L25: 

    /** c_decl.e:568					if not found then*/
    if (_found_43333 != 0)
    goto L26; // [1062] 1153

    /** c_decl.e:569						bbi[BB_SEQLEN] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_bbi_43553);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43553 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
    goto L26; // [1074] 1153
L23: 

    /** c_decl.e:572					bbi[BB_ELEM] = etype*/
    _2 = (object)SEQ_PTR(_bbi_43553);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43553 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _etype_43331;
    DeRef(_1);

    /** c_decl.e:573					if t = TYPE_SEQUENCE or t = TYPE_OBJECT then*/
    _22824 = (_t_43329 == 8LL);
    if (_22824 != 0) {
        goto L27; // [1091] 1106
    }
    _22826 = (_t_43329 == 16LL);
    if (_22826 == 0)
    {
        DeRef(_22826);
        _22826 = NOVALUE;
        goto L28; // [1102] 1145
    }
    else{
        DeRef(_22826);
        _22826 = NOVALUE;
    }
L27: 

    /** c_decl.e:574						if val[MIN] < 0 then*/
    _2 = (object)SEQ_PTR(_val_43330);
    _22827 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(GREATEREQ, _22827, 0LL)){
        _22827 = NOVALUE;
        goto L29; // [1114] 1129
    }
    _22827 = NOVALUE;

    /** c_decl.e:575							bbi[BB_SEQLEN] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_bbi_43553);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43553 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
    goto L2A; // [1126] 1152
L29: 

    /** c_decl.e:577							bbi[BB_SEQLEN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43330);
    _22829 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_22829);
    _2 = (object)SEQ_PTR(_bbi_43553);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43553 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22829;
    if( _1 != _22829 ){
        DeRef(_1);
    }
    _22829 = NOVALUE;
    goto L2A; // [1142] 1152
L28: 

    /** c_decl.e:580						bbi[BB_OBJ] = val*/
    RefDS(_val_43330);
    _2 = (object)SEQ_PTR(_bbi_43553);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43553 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _val_43330;
    DeRef(_1);
L2A: 
L26: 

    /** c_decl.e:583				BB_info[i] = bbi*/
    RefDS(_bbi_43553);
    _2 = (object)SEQ_PTR(_57BB_info_42959);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _57BB_info_42959 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _i_43334);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _bbi_43553;
    DeRef(_1);
    DeRefDS(_bbi_43553);
    _bbi_43553 = NOVALUE;
    goto L22; // [1164] 1308
L3: 

    /** c_decl.e:586		elsif mode = M_CONSTANT then*/
    if (_mode_43342 != 2LL)
    goto L2B; // [1171] 1307

    /** c_decl.e:587			sym[S_GTYPE] = t*/
    _2 = (object)SEQ_PTR(_sym_43337);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43337 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _t_43329;
    DeRef(_1);

    /** c_decl.e:588			sym[S_SEQ_ELEM] = etype*/
    _2 = (object)SEQ_PTR(_sym_43337);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43337 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _etype_43331;
    DeRef(_1);

    /** c_decl.e:589			if sym[S_GTYPE] = TYPE_SEQUENCE or*/
    _2 = (object)SEQ_PTR(_sym_43337);
    _22831 = (object)*(((s1_ptr)_2)->base + 36LL);
    if (IS_ATOM_INT(_22831)) {
        _22832 = (_22831 == 8LL);
    }
    else {
        _22832 = binary_op(EQUALS, _22831, 8LL);
    }
    _22831 = NOVALUE;
    if (IS_ATOM_INT(_22832)) {
        if (_22832 != 0) {
            goto L2C; // [1205] 1226
        }
    }
    else {
        if (DBL_PTR(_22832)->dbl != 0.0) {
            goto L2C; // [1205] 1226
        }
    }
    _2 = (object)SEQ_PTR(_sym_43337);
    _22834 = (object)*(((s1_ptr)_2)->base + 36LL);
    if (IS_ATOM_INT(_22834)) {
        _22835 = (_22834 == 16LL);
    }
    else {
        _22835 = binary_op(EQUALS, _22834, 16LL);
    }
    _22834 = NOVALUE;
    if (_22835 == 0) {
        DeRef(_22835);
        _22835 = NOVALUE;
        goto L2D; // [1222] 1269
    }
    else {
        if (!IS_ATOM_INT(_22835) && DBL_PTR(_22835)->dbl == 0.0){
            DeRef(_22835);
            _22835 = NOVALUE;
            goto L2D; // [1222] 1269
        }
        DeRef(_22835);
        _22835 = NOVALUE;
    }
    DeRef(_22835);
    _22835 = NOVALUE;
L2C: 

    /** c_decl.e:591				if val[MIN] < 0 then*/
    _2 = (object)SEQ_PTR(_val_43330);
    _22836 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(GREATEREQ, _22836, 0LL)){
        _22836 = NOVALUE;
        goto L2E; // [1234] 1251
    }
    _22836 = NOVALUE;

    /** c_decl.e:592					sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_sym_43337);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43337 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
    goto L2F; // [1248] 1298
L2E: 

    /** c_decl.e:594					sym[S_SEQ_LEN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43330);
    _22838 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_22838);
    _2 = (object)SEQ_PTR(_sym_43337);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43337 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22838;
    if( _1 != _22838 ){
        DeRef(_1);
    }
    _22838 = NOVALUE;
    goto L2F; // [1266] 1298
L2D: 

    /** c_decl.e:597				sym[S_OBJ_MIN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43330);
    _22839 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_22839);
    _2 = (object)SEQ_PTR(_sym_43337);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43337 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22839;
    if( _1 != _22839 ){
        DeRef(_1);
    }
    _22839 = NOVALUE;

    /** c_decl.e:598				sym[S_OBJ_MAX] = val[MAX]*/
    _2 = (object)SEQ_PTR(_val_43330);
    _22840 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_22840);
    _2 = (object)SEQ_PTR(_sym_43337);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43337 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22840;
    if( _1 != _22840 ){
        DeRef(_1);
    }
    _22840 = NOVALUE;
L2F: 

    /** c_decl.e:600			sym[S_HAS_DELETE] = has_delete*/
    _2 = (object)SEQ_PTR(_sym_43337);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43337 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 54LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _has_delete_43332;
    DeRef(_1);
L2B: 
L22: 

    /** c_decl.e:603		SymTab[s] = sym*/
    RefDS(_sym_43337);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _s_43328);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_43337;
    DeRef(_1);

    /** c_decl.e:605	end procedure*/
    DeRefDS(_val_43330);
    DeRefDS(_sym_43337);
    DeRef(_22814);
    _22814 = NOVALUE;
    DeRef(_22832);
    _22832 = NOVALUE;
    _22748 = NOVALUE;
    DeRef(_22824);
    _22824 = NOVALUE;
    DeRef(_22734);
    _22734 = NOVALUE;
    DeRef(_22729);
    _22729 = NOVALUE;
    _22743 = NOVALUE;
    return;
    ;
}


void _57CName(object _s_43627)
{
    object _v_43628 = NOVALUE;
    object _mode_43630 = NOVALUE;
    object _22905 = NOVALUE;
    object _22904 = NOVALUE;
    object _22902 = NOVALUE;
    object _22901 = NOVALUE;
    object _22900 = NOVALUE;
    object _22899 = NOVALUE;
    object _22898 = NOVALUE;
    object _22897 = NOVALUE;
    object _22896 = NOVALUE;
    object _22895 = NOVALUE;
    object _22893 = NOVALUE;
    object _22891 = NOVALUE;
    object _22890 = NOVALUE;
    object _22889 = NOVALUE;
    object _22888 = NOVALUE;
    object _22887 = NOVALUE;
    object _22886 = NOVALUE;
    object _22884 = NOVALUE;
    object _22883 = NOVALUE;
    object _22882 = NOVALUE;
    object _22881 = NOVALUE;
    object _22880 = NOVALUE;
    object _22878 = NOVALUE;
    object _22877 = NOVALUE;
    object _22876 = NOVALUE;
    object _22875 = NOVALUE;
    object _22874 = NOVALUE;
    object _22873 = NOVALUE;
    object _22871 = NOVALUE;
    object _22870 = NOVALUE;
    object _22868 = NOVALUE;
    object _22867 = NOVALUE;
    object _22866 = NOVALUE;
    object _22865 = NOVALUE;
    object _22864 = NOVALUE;
    object _22863 = NOVALUE;
    object _22862 = NOVALUE;
    object _22861 = NOVALUE;
    object _22860 = NOVALUE;
    object _22859 = NOVALUE;
    object _22858 = NOVALUE;
    object _22857 = NOVALUE;
    object _22855 = NOVALUE;
    object _22854 = NOVALUE;
    object _22850 = NOVALUE;
    object _22849 = NOVALUE;
    object _22848 = NOVALUE;
    object _22847 = NOVALUE;
    object _22846 = NOVALUE;
    object _22845 = NOVALUE;
    object _22842 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_43627)) {
        _1 = (object)(DBL_PTR(_s_43627)->dbl);
        DeRefDS(_s_43627);
        _s_43627 = _1;
    }

    /** c_decl.e:612		v = ObjValue(s)*/
    _0 = _v_43628;
    _v_43628 = _57ObjValue(_s_43627);
    DeRef(_0);

    /** c_decl.e:613		integer mode = SymTab[s][S_MODE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22842 = (object)*(((s1_ptr)_2)->base + _s_43627);
    _2 = (object)SEQ_PTR(_22842);
    _mode_43630 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_mode_43630)){
        _mode_43630 = (object)DBL_PTR(_mode_43630)->dbl;
    }
    _22842 = NOVALUE;

    /** c_decl.e:614	 	if mode = M_NORMAL then*/
    if (_mode_43630 != 1LL)
    goto L1; // [29] 254

    /** c_decl.e:617			if LeftSym = FALSE and GType(s) = TYPE_INTEGER and v != NOVALUE then*/
    _22845 = (_57LeftSym_42960 == _9FALSE_439);
    if (_22845 == 0) {
        _22846 = 0;
        goto L2; // [43] 61
    }
    _22847 = _57GType(_s_43627);
    if (IS_ATOM_INT(_22847)) {
        _22848 = (_22847 == 1LL);
    }
    else {
        _22848 = binary_op(EQUALS, _22847, 1LL);
    }
    DeRef(_22847);
    _22847 = NOVALUE;
    if (IS_ATOM_INT(_22848))
    _22846 = (_22848 != 0);
    else
    _22846 = DBL_PTR(_22848)->dbl != 0.0;
L2: 
    if (_22846 == 0) {
        goto L3; // [61] 98
    }
    if (IS_ATOM_INT(_v_43628) && IS_ATOM_INT(_27NOVALUE_20426)) {
        _22850 = (_v_43628 != _27NOVALUE_20426);
    }
    else {
        _22850 = binary_op(NOTEQ, _v_43628, _27NOVALUE_20426);
    }
    if (_22850 == 0) {
        DeRef(_22850);
        _22850 = NOVALUE;
        goto L3; // [72] 98
    }
    else {
        if (!IS_ATOM_INT(_22850) && DBL_PTR(_22850)->dbl == 0.0){
            DeRef(_22850);
            _22850 = NOVALUE;
            goto L3; // [72] 98
        }
        DeRef(_22850);
        _22850 = NOVALUE;
    }
    DeRef(_22850);
    _22850 = NOVALUE;

    /** c_decl.e:618				c_printf("%d", v)*/
    RefDS(_22851);
    Ref(_v_43628);
    _54c_printf(_22851, _v_43628);

    /** c_decl.e:619				if TARGET_SIZEOF_POINTER = 8 then*/

    /** c_decl.e:620					c_puts( "LL" )*/
    RefDS(_22853);
    _54c_puts(_22853);
    goto L4; // [95] 180
L3: 

    /** c_decl.e:623				if SymTab[s][S_SCOPE] > SC_PRIVATE then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22854 = (object)*(((s1_ptr)_2)->base + _s_43627);
    _2 = (object)SEQ_PTR(_22854);
    _22855 = (object)*(((s1_ptr)_2)->base + 4LL);
    _22854 = NOVALUE;
    if (binary_op_a(LESSEQ, _22855, 3LL)){
        _22855 = NOVALUE;
        goto L5; // [114] 156
    }
    _22855 = NOVALUE;

    /** c_decl.e:624					c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22857 = (object)*(((s1_ptr)_2)->base + _s_43627);
    _2 = (object)SEQ_PTR(_22857);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _22858 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _22858 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _22857 = NOVALUE;
    RefDS(_22350);
    Ref(_22858);
    _54c_printf(_22350, _22858);
    _22858 = NOVALUE;

    /** c_decl.e:625					c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22859 = (object)*(((s1_ptr)_2)->base + _s_43627);
    _2 = (object)SEQ_PTR(_22859);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _22860 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _22860 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _22859 = NOVALUE;
    Ref(_22860);
    _54c_puts(_22860);
    _22860 = NOVALUE;
    goto L6; // [153] 179
L5: 

    /** c_decl.e:627					c_puts("_")*/
    RefDS(_22299);
    _54c_puts(_22299);

    /** c_decl.e:628					c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22861 = (object)*(((s1_ptr)_2)->base + _s_43627);
    _2 = (object)SEQ_PTR(_22861);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _22862 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _22862 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _22861 = NOVALUE;
    Ref(_22862);
    _54c_puts(_22862);
    _22862 = NOVALUE;
L6: 
L4: 

    /** c_decl.e:631			if s != CurrentSub and SymTab[s][S_NREFS] < 2 then*/
    _22863 = (_s_43627 != _27CurrentSub_20579);
    if (_22863 == 0) {
        goto L7; // [188] 236
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22865 = (object)*(((s1_ptr)_2)->base + _s_43627);
    _2 = (object)SEQ_PTR(_22865);
    _22866 = (object)*(((s1_ptr)_2)->base + 12LL);
    _22865 = NOVALUE;
    if (IS_ATOM_INT(_22866)) {
        _22867 = (_22866 < 2LL);
    }
    else {
        _22867 = binary_op(LESS, _22866, 2LL);
    }
    _22866 = NOVALUE;
    if (_22867 == 0) {
        DeRef(_22867);
        _22867 = NOVALUE;
        goto L7; // [209] 236
    }
    else {
        if (!IS_ATOM_INT(_22867) && DBL_PTR(_22867)->dbl == 0.0){
            DeRef(_22867);
            _22867 = NOVALUE;
            goto L7; // [209] 236
        }
        DeRef(_22867);
        _22867 = NOVALUE;
    }
    DeRef(_22867);
    _22867 = NOVALUE;

    /** c_decl.e:632				SymTab[s][S_NREFS] += 1*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_43627 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _22870 = (object)*(((s1_ptr)_2)->base + 12LL);
    _22868 = NOVALUE;
    if (IS_ATOM_INT(_22870)) {
        _22871 = _22870 + 1;
        if (_22871 > MAXINT){
            _22871 = NewDouble((eudouble)_22871);
        }
    }
    else
    _22871 = binary_op(PLUS, 1, _22870);
    _22870 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22871;
    if( _1 != _22871 ){
        DeRef(_1);
    }
    _22871 = NOVALUE;
    _22868 = NOVALUE;
L7: 

    /** c_decl.e:634			SetBBType(s, TYPE_NULL, novalue, TYPE_OBJECT, 0) -- record that this var was referenced in this BB*/
    RefDS(_54novalue_47064);
    _57SetBBType(_s_43627, 0LL, _54novalue_47064, 16LL, 0LL);
    goto L8; // [251] 533
L1: 

    /** c_decl.e:636	 	elsif mode = M_CONSTANT then*/
    if (_mode_43630 != 2LL)
    goto L9; // [258] 448

    /** c_decl.e:638			if (is_integer( sym_obj( s ) ) and SymTab[s][S_GTYPE] != TYPE_DOUBLE ) or (LeftSym = FALSE and TypeIs(s, TYPE_INTEGER) and v != NOVALUE) then*/
    _22873 = _53sym_obj(_s_43627);
    _22874 = _27is_integer(_22873);
    _22873 = NOVALUE;
    if (IS_ATOM_INT(_22874)) {
        if (_22874 == 0) {
            DeRef(_22875);
            _22875 = 0;
            goto LA; // [272] 298
        }
    }
    else {
        if (DBL_PTR(_22874)->dbl == 0.0) {
            DeRef(_22875);
            _22875 = 0;
            goto LA; // [272] 298
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22876 = (object)*(((s1_ptr)_2)->base + _s_43627);
    _2 = (object)SEQ_PTR(_22876);
    _22877 = (object)*(((s1_ptr)_2)->base + 36LL);
    _22876 = NOVALUE;
    if (IS_ATOM_INT(_22877)) {
        _22878 = (_22877 != 2LL);
    }
    else {
        _22878 = binary_op(NOTEQ, _22877, 2LL);
    }
    _22877 = NOVALUE;
    DeRef(_22875);
    if (IS_ATOM_INT(_22878))
    _22875 = (_22878 != 0);
    else
    _22875 = DBL_PTR(_22878)->dbl != 0.0;
LA: 
    if (_22875 != 0) {
        goto LB; // [298] 344
    }
    _22880 = (_57LeftSym_42960 == _9FALSE_439);
    if (_22880 == 0) {
        _22881 = 0;
        goto LC; // [310] 325
    }
    _22882 = _57TypeIs(_s_43627, 1LL);
    if (IS_ATOM_INT(_22882))
    _22881 = (_22882 != 0);
    else
    _22881 = DBL_PTR(_22882)->dbl != 0.0;
LC: 
    if (_22881 == 0) {
        DeRef(_22883);
        _22883 = 0;
        goto LD; // [325] 339
    }
    if (IS_ATOM_INT(_v_43628) && IS_ATOM_INT(_27NOVALUE_20426)) {
        _22884 = (_v_43628 != _27NOVALUE_20426);
    }
    else {
        _22884 = binary_op(NOTEQ, _v_43628, _27NOVALUE_20426);
    }
    if (IS_ATOM_INT(_22884))
    _22883 = (_22884 != 0);
    else
    _22883 = DBL_PTR(_22884)->dbl != 0.0;
LD: 
    if (_22883 == 0)
    {
        _22883 = NOVALUE;
        goto LE; // [340] 367
    }
    else{
        _22883 = NOVALUE;
    }
LB: 

    /** c_decl.e:641				c_printf("%d", v)*/
    RefDS(_22851);
    Ref(_v_43628);
    _54c_printf(_22851, _v_43628);

    /** c_decl.e:642				if TARGET_SIZEOF_POINTER = 8 then*/

    /** c_decl.e:643					c_puts( "LL" )*/
    RefDS(_22853);
    _54c_puts(_22853);
    goto L8; // [364] 533
LE: 

    /** c_decl.e:647				c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22886 = (object)*(((s1_ptr)_2)->base + _s_43627);
    _2 = (object)SEQ_PTR(_22886);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _22887 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _22887 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _22886 = NOVALUE;
    RefDS(_22350);
    Ref(_22887);
    _54c_printf(_22350, _22887);
    _22887 = NOVALUE;

    /** c_decl.e:648				c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22888 = (object)*(((s1_ptr)_2)->base + _s_43627);
    _2 = (object)SEQ_PTR(_22888);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _22889 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _22889 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _22888 = NOVALUE;
    Ref(_22889);
    _54c_puts(_22889);
    _22889 = NOVALUE;

    /** c_decl.e:649				if SymTab[s][S_NREFS] < 2 then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22890 = (object)*(((s1_ptr)_2)->base + _s_43627);
    _2 = (object)SEQ_PTR(_22890);
    _22891 = (object)*(((s1_ptr)_2)->base + 12LL);
    _22890 = NOVALUE;
    if (binary_op_a(GREATEREQ, _22891, 2LL)){
        _22891 = NOVALUE;
        goto L8; // [416] 533
    }
    _22891 = NOVALUE;

    /** c_decl.e:650					SymTab[s][S_NREFS] += 1*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_43627 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _22895 = (object)*(((s1_ptr)_2)->base + 12LL);
    _22893 = NOVALUE;
    if (IS_ATOM_INT(_22895)) {
        _22896 = _22895 + 1;
        if (_22896 > MAXINT){
            _22896 = NewDouble((eudouble)_22896);
        }
    }
    else
    _22896 = binary_op(PLUS, 1, _22895);
    _22895 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22896;
    if( _1 != _22896 ){
        DeRef(_1);
    }
    _22896 = NOVALUE;
    _22893 = NOVALUE;
    goto L8; // [445] 533
L9: 

    /** c_decl.e:656			if LeftSym = FALSE and GType(s) = TYPE_INTEGER and v != NOVALUE then*/
    _22897 = (_57LeftSym_42960 == _9FALSE_439);
    if (_22897 == 0) {
        _22898 = 0;
        goto LF; // [458] 476
    }
    _22899 = _57GType(_s_43627);
    if (IS_ATOM_INT(_22899)) {
        _22900 = (_22899 == 1LL);
    }
    else {
        _22900 = binary_op(EQUALS, _22899, 1LL);
    }
    DeRef(_22899);
    _22899 = NOVALUE;
    if (IS_ATOM_INT(_22900))
    _22898 = (_22900 != 0);
    else
    _22898 = DBL_PTR(_22900)->dbl != 0.0;
LF: 
    if (_22898 == 0) {
        goto L10; // [476] 513
    }
    if (IS_ATOM_INT(_v_43628) && IS_ATOM_INT(_27NOVALUE_20426)) {
        _22902 = (_v_43628 != _27NOVALUE_20426);
    }
    else {
        _22902 = binary_op(NOTEQ, _v_43628, _27NOVALUE_20426);
    }
    if (_22902 == 0) {
        DeRef(_22902);
        _22902 = NOVALUE;
        goto L10; // [487] 513
    }
    else {
        if (!IS_ATOM_INT(_22902) && DBL_PTR(_22902)->dbl == 0.0){
            DeRef(_22902);
            _22902 = NOVALUE;
            goto L10; // [487] 513
        }
        DeRef(_22902);
        _22902 = NOVALUE;
    }
    DeRef(_22902);
    _22902 = NOVALUE;

    /** c_decl.e:657				c_printf("%d", v)*/
    RefDS(_22851);
    Ref(_v_43628);
    _54c_printf(_22851, _v_43628);

    /** c_decl.e:658				if TARGET_SIZEOF_POINTER = 8 then*/

    /** c_decl.e:659					c_puts( "LL" )*/
    RefDS(_22853);
    _54c_puts(_22853);
    goto L11; // [510] 532
L10: 

    /** c_decl.e:662				c_printf("_%d", SymTab[s][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22904 = (object)*(((s1_ptr)_2)->base + _s_43627);
    _2 = (object)SEQ_PTR(_22904);
    _22905 = (object)*(((s1_ptr)_2)->base + 34LL);
    _22904 = NOVALUE;
    RefDS(_22350);
    Ref(_22905);
    _54c_printf(_22350, _22905);
    _22905 = NOVALUE;
L11: 
L8: 

    /** c_decl.e:666		LeftSym = FALSE*/
    _57LeftSym_42960 = _9FALSE_439;

    /** c_decl.e:667	end procedure*/
    DeRef(_v_43628);
    DeRef(_22882);
    _22882 = NOVALUE;
    DeRef(_22900);
    _22900 = NOVALUE;
    DeRef(_22878);
    _22878 = NOVALUE;
    DeRef(_22848);
    _22848 = NOVALUE;
    DeRef(_22874);
    _22874 = NOVALUE;
    DeRef(_22880);
    _22880 = NOVALUE;
    DeRef(_22863);
    _22863 = NOVALUE;
    DeRef(_22884);
    _22884 = NOVALUE;
    DeRef(_22845);
    _22845 = NOVALUE;
    DeRef(_22897);
    _22897 = NOVALUE;
    return;
    ;
}


void _57c_stmt(object _stmt_43775, object _arg_43776, object _lhs_arg_43778)
{
    object _argcount_43779 = NOVALUE;
    object _i_43780 = NOVALUE;
    object _22964 = NOVALUE;
    object _22963 = NOVALUE;
    object _22962 = NOVALUE;
    object _22961 = NOVALUE;
    object _22960 = NOVALUE;
    object _22959 = NOVALUE;
    object _22958 = NOVALUE;
    object _22957 = NOVALUE;
    object _22956 = NOVALUE;
    object _22955 = NOVALUE;
    object _22954 = NOVALUE;
    object _22953 = NOVALUE;
    object _22952 = NOVALUE;
    object _22951 = NOVALUE;
    object _22950 = NOVALUE;
    object _22948 = NOVALUE;
    object _22947 = NOVALUE;
    object _22945 = NOVALUE;
    object _22943 = NOVALUE;
    object _22941 = NOVALUE;
    object _22940 = NOVALUE;
    object _22939 = NOVALUE;
    object _22938 = NOVALUE;
    object _22936 = NOVALUE;
    object _22935 = NOVALUE;
    object _22934 = NOVALUE;
    object _22933 = NOVALUE;
    object _22932 = NOVALUE;
    object _22930 = NOVALUE;
    object _22929 = NOVALUE;
    object _22928 = NOVALUE;
    object _22927 = NOVALUE;
    object _22925 = NOVALUE;
    object _22924 = NOVALUE;
    object _22923 = NOVALUE;
    object _22922 = NOVALUE;
    object _22921 = NOVALUE;
    object _22917 = NOVALUE;
    object _22916 = NOVALUE;
    object _22915 = NOVALUE;
    object _22914 = NOVALUE;
    object _22913 = NOVALUE;
    object _22912 = NOVALUE;
    object _22910 = NOVALUE;
    object _22908 = NOVALUE;
    object _22907 = NOVALUE;
    object _22906 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_lhs_arg_43778)) {
        _1 = (object)(DBL_PTR(_lhs_arg_43778)->dbl);
        DeRefDS(_lhs_arg_43778);
        _lhs_arg_43778 = _1;
    }

    /** c_decl.e:675		if LAST_PASS = TRUE and Initializing = FALSE then*/
    _22906 = (_57LAST_PASS_42949 == _9TRUE_441);
    if (_22906 == 0) {
        goto L1; // [15] 47
    }
    _22908 = (_27Initializing_20652 == _9FALSE_439);
    if (_22908 == 0)
    {
        DeRef(_22908);
        _22908 = NOVALUE;
        goto L1; // [28] 47
    }
    else{
        DeRef(_22908);
        _22908 = NOVALUE;
    }

    /** c_decl.e:676			cfile_size += 1*/
    _27cfile_size_20651 = _27cfile_size_20651 + 1LL;

    /** c_decl.e:677			update_checksum( stmt )*/
    RefDS(_stmt_43775);
    _55update_checksum(_stmt_43775);
L1: 

    /** c_decl.e:681		if emit_c_output then*/
    if (_54emit_c_output_47057 == 0)
    {
        goto L2; // [51] 60
    }
    else{
    }

    /** c_decl.e:682			adjust_indent_before(stmt)*/
    RefDS(_stmt_43775);
    _54adjust_indent_before(_stmt_43775);
L2: 

    /** c_decl.e:685		if atom(arg) then*/
    _22910 = IS_ATOM(_arg_43776);
    if (_22910 == 0)
    {
        _22910 = NOVALUE;
        goto L3; // [65] 75
    }
    else{
        _22910 = NOVALUE;
    }

    /** c_decl.e:686			arg = {arg}*/
    _0 = _arg_43776;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_arg_43776);
    ((intptr_t*)_2)[1] = _arg_43776;
    _arg_43776 = MAKE_SEQ(_1);
    DeRef(_0);
L3: 

    /** c_decl.e:689		argcount = 1*/
    _argcount_43779 = 1LL;

    /** c_decl.e:690		i = 1*/
    _i_43780 = 1LL;

    /** c_decl.e:691		while i <= length(stmt) and length(stmt) > 0 do*/
L4: 
    if (IS_SEQUENCE(_stmt_43775)){
            _22912 = SEQ_PTR(_stmt_43775)->length;
    }
    else {
        _22912 = 1;
    }
    _22913 = (_i_43780 <= _22912);
    _22912 = NOVALUE;
    if (_22913 == 0) {
        goto L5; // [97] 435
    }
    if (IS_SEQUENCE(_stmt_43775)){
            _22915 = SEQ_PTR(_stmt_43775)->length;
    }
    else {
        _22915 = 1;
    }
    _22916 = (_22915 > 0LL);
    _22915 = NOVALUE;
    if (_22916 == 0)
    {
        DeRef(_22916);
        _22916 = NOVALUE;
        goto L5; // [109] 435
    }
    else{
        DeRef(_22916);
        _22916 = NOVALUE;
    }

    /** c_decl.e:692			if stmt[i] = '@' then*/
    _2 = (object)SEQ_PTR(_stmt_43775);
    _22917 = (object)*(((s1_ptr)_2)->base + _i_43780);
    if (binary_op_a(NOTEQ, _22917, 64LL)){
        _22917 = NOVALUE;
        goto L6; // [118] 288
    }
    _22917 = NOVALUE;

    /** c_decl.e:694				if i = 1 then*/
    if (_i_43780 != 1LL)
    goto L7; // [124] 138

    /** c_decl.e:695					LeftSym = TRUE*/
    _57LeftSym_42960 = _9TRUE_441;
L7: 

    /** c_decl.e:698				if i < length(stmt) and stmt[i+1] > '0' and stmt[i+1] <= '9' then*/
    if (IS_SEQUENCE(_stmt_43775)){
            _22921 = SEQ_PTR(_stmt_43775)->length;
    }
    else {
        _22921 = 1;
    }
    _22922 = (_i_43780 < _22921);
    _22921 = NOVALUE;
    if (_22922 == 0) {
        _22923 = 0;
        goto L8; // [147] 167
    }
    _22924 = _i_43780 + 1;
    _2 = (object)SEQ_PTR(_stmt_43775);
    _22925 = (object)*(((s1_ptr)_2)->base + _22924);
    if (IS_ATOM_INT(_22925)) {
        _22927 = (_22925 > 48LL);
    }
    else {
        _22927 = binary_op(GREATER, _22925, 48LL);
    }
    _22925 = NOVALUE;
    if (IS_ATOM_INT(_22927))
    _22923 = (_22927 != 0);
    else
    _22923 = DBL_PTR(_22927)->dbl != 0.0;
L8: 
    if (_22923 == 0) {
        goto L9; // [167] 249
    }
    _22929 = _i_43780 + 1;
    _2 = (object)SEQ_PTR(_stmt_43775);
    _22930 = (object)*(((s1_ptr)_2)->base + _22929);
    if (IS_ATOM_INT(_22930)) {
        _22932 = (_22930 <= 57LL);
    }
    else {
        _22932 = binary_op(LESSEQ, _22930, 57LL);
    }
    _22930 = NOVALUE;
    if (_22932 == 0) {
        DeRef(_22932);
        _22932 = NOVALUE;
        goto L9; // [184] 249
    }
    else {
        if (!IS_ATOM_INT(_22932) && DBL_PTR(_22932)->dbl == 0.0){
            DeRef(_22932);
            _22932 = NOVALUE;
            goto L9; // [184] 249
        }
        DeRef(_22932);
        _22932 = NOVALUE;
    }
    DeRef(_22932);
    _22932 = NOVALUE;

    /** c_decl.e:700					if arg[stmt[i+1]-'0'] = lhs_arg then*/
    _22933 = _i_43780 + 1;
    _2 = (object)SEQ_PTR(_stmt_43775);
    _22934 = (object)*(((s1_ptr)_2)->base + _22933);
    if (IS_ATOM_INT(_22934)) {
        _22935 = _22934 - 48LL;
    }
    else {
        _22935 = binary_op(MINUS, _22934, 48LL);
    }
    _22934 = NOVALUE;
    _2 = (object)SEQ_PTR(_arg_43776);
    if (!IS_ATOM_INT(_22935)){
        _22936 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_22935)->dbl));
    }
    else{
        _22936 = (object)*(((s1_ptr)_2)->base + _22935);
    }
    if (binary_op_a(NOTEQ, _22936, _lhs_arg_43778)){
        _22936 = NOVALUE;
        goto LA; // [205] 219
    }
    _22936 = NOVALUE;

    /** c_decl.e:701						LeftSym = TRUE*/
    _57LeftSym_42960 = _9TRUE_441;
LA: 

    /** c_decl.e:703					CName(arg[stmt[i+1]-'0'])*/
    _22938 = _i_43780 + 1;
    _2 = (object)SEQ_PTR(_stmt_43775);
    _22939 = (object)*(((s1_ptr)_2)->base + _22938);
    if (IS_ATOM_INT(_22939)) {
        _22940 = _22939 - 48LL;
    }
    else {
        _22940 = binary_op(MINUS, _22939, 48LL);
    }
    _22939 = NOVALUE;
    _2 = (object)SEQ_PTR(_arg_43776);
    if (!IS_ATOM_INT(_22940)){
        _22941 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_22940)->dbl));
    }
    else{
        _22941 = (object)*(((s1_ptr)_2)->base + _22940);
    }
    Ref(_22941);
    _57CName(_22941);
    _22941 = NOVALUE;

    /** c_decl.e:704					i += 1*/
    _i_43780 = _i_43780 + 1;
    goto LB; // [246] 279
L9: 

    /** c_decl.e:708					if arg[argcount] = lhs_arg then*/
    _2 = (object)SEQ_PTR(_arg_43776);
    _22943 = (object)*(((s1_ptr)_2)->base + _argcount_43779);
    if (binary_op_a(NOTEQ, _22943, _lhs_arg_43778)){
        _22943 = NOVALUE;
        goto LC; // [255] 269
    }
    _22943 = NOVALUE;

    /** c_decl.e:709						LeftSym = TRUE*/
    _57LeftSym_42960 = _9TRUE_441;
LC: 

    /** c_decl.e:711					CName(arg[argcount])*/
    _2 = (object)SEQ_PTR(_arg_43776);
    _22945 = (object)*(((s1_ptr)_2)->base + _argcount_43779);
    Ref(_22945);
    _57CName(_22945);
    _22945 = NOVALUE;
LB: 

    /** c_decl.e:714				argcount += 1*/
    _argcount_43779 = _argcount_43779 + 1;
    goto LD; // [285] 353
L6: 

    /** c_decl.e:717				c_putc(stmt[i])*/
    _2 = (object)SEQ_PTR(_stmt_43775);
    _22947 = (object)*(((s1_ptr)_2)->base + _i_43780);
    Ref(_22947);
    _54c_putc(_22947);
    _22947 = NOVALUE;

    /** c_decl.e:718				if stmt[i] = '&' and i < length(stmt) and stmt[i+1] = '@' then*/
    _2 = (object)SEQ_PTR(_stmt_43775);
    _22948 = (object)*(((s1_ptr)_2)->base + _i_43780);
    if (IS_ATOM_INT(_22948)) {
        _22950 = (_22948 == 38LL);
    }
    else {
        _22950 = binary_op(EQUALS, _22948, 38LL);
    }
    _22948 = NOVALUE;
    if (IS_ATOM_INT(_22950)) {
        if (_22950 == 0) {
            DeRef(_22951);
            _22951 = 0;
            goto LE; // [307] 322
        }
    }
    else {
        if (DBL_PTR(_22950)->dbl == 0.0) {
            DeRef(_22951);
            _22951 = 0;
            goto LE; // [307] 322
        }
    }
    if (IS_SEQUENCE(_stmt_43775)){
            _22952 = SEQ_PTR(_stmt_43775)->length;
    }
    else {
        _22952 = 1;
    }
    _22953 = (_i_43780 < _22952);
    _22952 = NOVALUE;
    DeRef(_22951);
    _22951 = (_22953 != 0);
LE: 
    if (_22951 == 0) {
        goto LF; // [322] 352
    }
    _22955 = _i_43780 + 1;
    _2 = (object)SEQ_PTR(_stmt_43775);
    _22956 = (object)*(((s1_ptr)_2)->base + _22955);
    if (IS_ATOM_INT(_22956)) {
        _22957 = (_22956 == 64LL);
    }
    else {
        _22957 = binary_op(EQUALS, _22956, 64LL);
    }
    _22956 = NOVALUE;
    if (_22957 == 0) {
        DeRef(_22957);
        _22957 = NOVALUE;
        goto LF; // [339] 352
    }
    else {
        if (!IS_ATOM_INT(_22957) && DBL_PTR(_22957)->dbl == 0.0){
            DeRef(_22957);
            _22957 = NOVALUE;
            goto LF; // [339] 352
        }
        DeRef(_22957);
        _22957 = NOVALUE;
    }
    DeRef(_22957);
    _22957 = NOVALUE;

    /** c_decl.e:719					LeftSym = TRUE -- never say: x = x &y or andy - always leave space*/
    _57LeftSym_42960 = _9TRUE_441;
LF: 
LD: 

    /** c_decl.e:723			if stmt[i] = '\n' and i < length(stmt) then*/
    _2 = (object)SEQ_PTR(_stmt_43775);
    _22958 = (object)*(((s1_ptr)_2)->base + _i_43780);
    if (IS_ATOM_INT(_22958)) {
        _22959 = (_22958 == 10LL);
    }
    else {
        _22959 = binary_op(EQUALS, _22958, 10LL);
    }
    _22958 = NOVALUE;
    if (IS_ATOM_INT(_22959)) {
        if (_22959 == 0) {
            goto L10; // [363] 424
        }
    }
    else {
        if (DBL_PTR(_22959)->dbl == 0.0) {
            goto L10; // [363] 424
        }
    }
    if (IS_SEQUENCE(_stmt_43775)){
            _22961 = SEQ_PTR(_stmt_43775)->length;
    }
    else {
        _22961 = 1;
    }
    _22962 = (_i_43780 < _22961);
    _22961 = NOVALUE;
    if (_22962 == 0)
    {
        DeRef(_22962);
        _22962 = NOVALUE;
        goto L10; // [375] 424
    }
    else{
        DeRef(_22962);
        _22962 = NOVALUE;
    }

    /** c_decl.e:724				if emit_c_output then*/
    if (_54emit_c_output_47057 == 0)
    {
        goto L11; // [382] 391
    }
    else{
    }

    /** c_decl.e:725					adjust_indent_after(stmt)*/
    RefDS(_stmt_43775);
    _54adjust_indent_after(_stmt_43775);
L11: 

    /** c_decl.e:727				stmt = stmt[i+1..$]*/
    _22963 = _i_43780 + 1;
    if (_22963 > MAXINT){
        _22963 = NewDouble((eudouble)_22963);
    }
    if (IS_SEQUENCE(_stmt_43775)){
            _22964 = SEQ_PTR(_stmt_43775)->length;
    }
    else {
        _22964 = 1;
    }
    rhs_slice_target = (object_ptr)&_stmt_43775;
    RHS_Slice(_stmt_43775, _22963, _22964);

    /** c_decl.e:728				i = 0*/
    _i_43780 = 0LL;

    /** c_decl.e:729				if emit_c_output then*/
    if (_54emit_c_output_47057 == 0)
    {
        goto L12; // [414] 423
    }
    else{
    }

    /** c_decl.e:730					adjust_indent_before(stmt)*/
    RefDS(_stmt_43775);
    _54adjust_indent_before(_stmt_43775);
L12: 
L10: 

    /** c_decl.e:734			i += 1*/
    _i_43780 = _i_43780 + 1;

    /** c_decl.e:735		end while*/
    goto L4; // [432] 90
L5: 

    /** c_decl.e:737		if emit_c_output then*/
    if (_54emit_c_output_47057 == 0)
    {
        goto L13; // [439] 448
    }
    else{
    }

    /** c_decl.e:738			adjust_indent_after(stmt)*/
    RefDS(_stmt_43775);
    _54adjust_indent_after(_stmt_43775);
L13: 

    /** c_decl.e:740	end procedure*/
    DeRefDS(_stmt_43775);
    DeRef(_arg_43776);
    DeRef(_22955);
    _22955 = NOVALUE;
    DeRef(_22913);
    _22913 = NOVALUE;
    DeRef(_22950);
    _22950 = NOVALUE;
    DeRef(_22929);
    _22929 = NOVALUE;
    DeRef(_22922);
    _22922 = NOVALUE;
    DeRef(_22924);
    _22924 = NOVALUE;
    DeRef(_22933);
    _22933 = NOVALUE;
    DeRef(_22953);
    _22953 = NOVALUE;
    DeRef(_22963);
    _22963 = NOVALUE;
    DeRef(_22959);
    _22959 = NOVALUE;
    DeRef(_22938);
    _22938 = NOVALUE;
    DeRef(_22927);
    _22927 = NOVALUE;
    DeRef(_22906);
    _22906 = NOVALUE;
    DeRef(_22940);
    _22940 = NOVALUE;
    DeRef(_22935);
    _22935 = NOVALUE;
    return;
    ;
}


void _57c_stmt0(object _stmt_43878)
{
    object _0, _1, _2;
    

    /** c_decl.e:745		if emit_c_output then*/
    if (_54emit_c_output_47057 == 0)
    {
        goto L1; // [7] 18
    }
    else{
    }

    /** c_decl.e:746			c_stmt(stmt, {})*/
    RefDS(_stmt_43878);
    RefDS(_22218);
    _57c_stmt(_stmt_43878, _22218, 0LL);
L1: 

    /** c_decl.e:748	end procedure*/
    DeRefDS(_stmt_43878);
    return;
    ;
}


object _57needs_uninit(object _eentry_43883)
{
    object _22987 = NOVALUE;
    object _22986 = NOVALUE;
    object _22985 = NOVALUE;
    object _22984 = NOVALUE;
    object _22983 = NOVALUE;
    object _22982 = NOVALUE;
    object _22981 = NOVALUE;
    object _22980 = NOVALUE;
    object _22979 = NOVALUE;
    object _22978 = NOVALUE;
    object _22977 = NOVALUE;
    object _22976 = NOVALUE;
    object _22975 = NOVALUE;
    object _22974 = NOVALUE;
    object _22973 = NOVALUE;
    object _22972 = NOVALUE;
    object _22971 = NOVALUE;
    object _22970 = NOVALUE;
    object _22969 = NOVALUE;
    object _22968 = NOVALUE;
    object _22967 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:751		if eentry[S_SCOPE] >= SC_LOCAL*/
    _2 = (object)SEQ_PTR(_eentry_43883);
    _22967 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_22967)) {
        _22968 = (_22967 >= 5LL);
    }
    else {
        _22968 = binary_op(GREATEREQ, _22967, 5LL);
    }
    _22967 = NOVALUE;
    if (IS_ATOM_INT(_22968)) {
        if (_22968 == 0) {
            _22969 = 0;
            goto L1; // [17] 77
        }
    }
    else {
        if (DBL_PTR(_22968)->dbl == 0.0) {
            _22969 = 0;
            goto L1; // [17] 77
        }
    }
    _2 = (object)SEQ_PTR(_eentry_43883);
    _22970 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_22970)) {
        _22971 = (_22970 <= 6LL);
    }
    else {
        _22971 = binary_op(LESSEQ, _22970, 6LL);
    }
    _22970 = NOVALUE;
    if (IS_ATOM_INT(_22971)) {
        if (_22971 != 0) {
            _22972 = 1;
            goto L2; // [33] 53
        }
    }
    else {
        if (DBL_PTR(_22971)->dbl != 0.0) {
            _22972 = 1;
            goto L2; // [33] 53
        }
    }
    _2 = (object)SEQ_PTR(_eentry_43883);
    _22973 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_22973)) {
        _22974 = (_22973 == 11LL);
    }
    else {
        _22974 = binary_op(EQUALS, _22973, 11LL);
    }
    _22973 = NOVALUE;
    DeRef(_22972);
    if (IS_ATOM_INT(_22974))
    _22972 = (_22974 != 0);
    else
    _22972 = DBL_PTR(_22974)->dbl != 0.0;
L2: 
    if (_22972 != 0) {
        _22975 = 1;
        goto L3; // [53] 73
    }
    _2 = (object)SEQ_PTR(_eentry_43883);
    _22976 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_22976)) {
        _22977 = (_22976 == 13LL);
    }
    else {
        _22977 = binary_op(EQUALS, _22976, 13LL);
    }
    _22976 = NOVALUE;
    if (IS_ATOM_INT(_22977))
    _22975 = (_22977 != 0);
    else
    _22975 = DBL_PTR(_22977)->dbl != 0.0;
L3: 
    DeRef(_22969);
    _22969 = (_22975 != 0);
L1: 
    if (_22969 == 0) {
        _22978 = 0;
        goto L4; // [77] 97
    }
    _2 = (object)SEQ_PTR(_eentry_43883);
    _22979 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (IS_ATOM_INT(_22979)) {
        _22980 = (_22979 != 0LL);
    }
    else {
        _22980 = binary_op(NOTEQ, _22979, 0LL);
    }
    _22979 = NOVALUE;
    if (IS_ATOM_INT(_22980))
    _22978 = (_22980 != 0);
    else
    _22978 = DBL_PTR(_22980)->dbl != 0.0;
L4: 
    if (_22978 == 0) {
        _22981 = 0;
        goto L5; // [97] 117
    }
    _2 = (object)SEQ_PTR(_eentry_43883);
    _22982 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (IS_ATOM_INT(_22982)) {
        _22983 = (_22982 != 99LL);
    }
    else {
        _22983 = binary_op(NOTEQ, _22982, 99LL);
    }
    _22982 = NOVALUE;
    if (IS_ATOM_INT(_22983))
    _22981 = (_22983 != 0);
    else
    _22981 = DBL_PTR(_22983)->dbl != 0.0;
L5: 
    if (_22981 == 0) {
        goto L6; // [117] 150
    }
    _2 = (object)SEQ_PTR(_eentry_43883);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _22985 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _22985 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _22986 = find_from(_22985, _29RTN_TOKS_12277, 1LL);
    _22985 = NOVALUE;
    _22987 = (_22986 == 0);
    _22986 = NOVALUE;
    if (_22987 == 0)
    {
        DeRef(_22987);
        _22987 = NOVALUE;
        goto L6; // [138] 150
    }
    else{
        DeRef(_22987);
        _22987 = NOVALUE;
    }

    /** c_decl.e:757			return 1*/
    DeRefDS(_eentry_43883);
    DeRef(_22971);
    _22971 = NOVALUE;
    DeRef(_22983);
    _22983 = NOVALUE;
    DeRef(_22980);
    _22980 = NOVALUE;
    DeRef(_22968);
    _22968 = NOVALUE;
    DeRef(_22974);
    _22974 = NOVALUE;
    DeRef(_22977);
    _22977 = NOVALUE;
    return 1LL;
    goto L7; // [147] 157
L6: 

    /** c_decl.e:759			return 0*/
    DeRefDS(_eentry_43883);
    DeRef(_22971);
    _22971 = NOVALUE;
    DeRef(_22983);
    _22983 = NOVALUE;
    DeRef(_22980);
    _22980 = NOVALUE;
    DeRef(_22968);
    _22968 = NOVALUE;
    DeRef(_22974);
    _22974 = NOVALUE;
    DeRef(_22977);
    _22977 = NOVALUE;
    return 0LL;
L7: 
    ;
}


void _57DeclareFileVars()
{
    object _s_43924 = NOVALUE;
    object _eentry_43926 = NOVALUE;
    object _cleanup_vars_44020 = NOVALUE;
    object _23070 = NOVALUE;
    object _23063 = NOVALUE;
    object _23058 = NOVALUE;
    object _23055 = NOVALUE;
    object _23054 = NOVALUE;
    object _23053 = NOVALUE;
    object _23051 = NOVALUE;
    object _23047 = NOVALUE;
    object _23043 = NOVALUE;
    object _23040 = NOVALUE;
    object _23039 = NOVALUE;
    object _23038 = NOVALUE;
    object _23036 = NOVALUE;
    object _23032 = NOVALUE;
    object _23028 = NOVALUE;
    object _23027 = NOVALUE;
    object _23026 = NOVALUE;
    object _23023 = NOVALUE;
    object _23022 = NOVALUE;
    object _23020 = NOVALUE;
    object _23019 = NOVALUE;
    object _23018 = NOVALUE;
    object _23017 = NOVALUE;
    object _23013 = NOVALUE;
    object _23012 = NOVALUE;
    object _23011 = NOVALUE;
    object _23010 = NOVALUE;
    object _23009 = NOVALUE;
    object _23008 = NOVALUE;
    object _23007 = NOVALUE;
    object _23006 = NOVALUE;
    object _23005 = NOVALUE;
    object _23004 = NOVALUE;
    object _23003 = NOVALUE;
    object _23002 = NOVALUE;
    object _23001 = NOVALUE;
    object _23000 = NOVALUE;
    object _22999 = NOVALUE;
    object _22998 = NOVALUE;
    object _22997 = NOVALUE;
    object _22996 = NOVALUE;
    object _22995 = NOVALUE;
    object _22994 = NOVALUE;
    object _22993 = NOVALUE;
    object _22992 = NOVALUE;
    object _22989 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:769		c_puts("// Declaring file vars\n")*/
    RefDS(_22988);
    _54c_puts(_22988);

    /** c_decl.e:770		s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22989 = (object)*(((s1_ptr)_2)->base + _27TopLevelSub_20578);
    _2 = (object)SEQ_PTR(_22989);
    _s_43924 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_43924)){
        _s_43924 = (object)DBL_PTR(_s_43924)->dbl;
    }
    _22989 = NOVALUE;

    /** c_decl.e:772		while s do*/
L1: 
    if (_s_43924 == 0)
    {
        goto L2; // [29] 328
    }
    else{
    }

    /** c_decl.e:773			eentry = SymTab[s]*/
    DeRef(_eentry_43926);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _eentry_43926 = (object)*(((s1_ptr)_2)->base + _s_43924);
    Ref(_eentry_43926);

    /** c_decl.e:774			if eentry[S_SCOPE] >= SC_LOCAL*/
    _2 = (object)SEQ_PTR(_eentry_43926);
    _22992 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_22992)) {
        _22993 = (_22992 >= 5LL);
    }
    else {
        _22993 = binary_op(GREATEREQ, _22992, 5LL);
    }
    _22992 = NOVALUE;
    if (IS_ATOM_INT(_22993)) {
        if (_22993 == 0) {
            DeRef(_22994);
            _22994 = 0;
            goto L3; // [56] 116
        }
    }
    else {
        if (DBL_PTR(_22993)->dbl == 0.0) {
            DeRef(_22994);
            _22994 = 0;
            goto L3; // [56] 116
        }
    }
    _2 = (object)SEQ_PTR(_eentry_43926);
    _22995 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_22995)) {
        _22996 = (_22995 <= 6LL);
    }
    else {
        _22996 = binary_op(LESSEQ, _22995, 6LL);
    }
    _22995 = NOVALUE;
    if (IS_ATOM_INT(_22996)) {
        if (_22996 != 0) {
            DeRef(_22997);
            _22997 = 1;
            goto L4; // [72] 92
        }
    }
    else {
        if (DBL_PTR(_22996)->dbl != 0.0) {
            DeRef(_22997);
            _22997 = 1;
            goto L4; // [72] 92
        }
    }
    _2 = (object)SEQ_PTR(_eentry_43926);
    _22998 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_22998)) {
        _22999 = (_22998 == 11LL);
    }
    else {
        _22999 = binary_op(EQUALS, _22998, 11LL);
    }
    _22998 = NOVALUE;
    DeRef(_22997);
    if (IS_ATOM_INT(_22999))
    _22997 = (_22999 != 0);
    else
    _22997 = DBL_PTR(_22999)->dbl != 0.0;
L4: 
    if (_22997 != 0) {
        _23000 = 1;
        goto L5; // [92] 112
    }
    _2 = (object)SEQ_PTR(_eentry_43926);
    _23001 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_23001)) {
        _23002 = (_23001 == 13LL);
    }
    else {
        _23002 = binary_op(EQUALS, _23001, 13LL);
    }
    _23001 = NOVALUE;
    if (IS_ATOM_INT(_23002))
    _23000 = (_23002 != 0);
    else
    _23000 = DBL_PTR(_23002)->dbl != 0.0;
L5: 
    DeRef(_22994);
    _22994 = (_23000 != 0);
L3: 
    if (_22994 == 0) {
        _23003 = 0;
        goto L6; // [116] 136
    }
    _2 = (object)SEQ_PTR(_eentry_43926);
    _23004 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (IS_ATOM_INT(_23004)) {
        _23005 = (_23004 != 0LL);
    }
    else {
        _23005 = binary_op(NOTEQ, _23004, 0LL);
    }
    _23004 = NOVALUE;
    if (IS_ATOM_INT(_23005))
    _23003 = (_23005 != 0);
    else
    _23003 = DBL_PTR(_23005)->dbl != 0.0;
L6: 
    if (_23003 == 0) {
        _23006 = 0;
        goto L7; // [136] 156
    }
    _2 = (object)SEQ_PTR(_eentry_43926);
    _23007 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (IS_ATOM_INT(_23007)) {
        _23008 = (_23007 != 99LL);
    }
    else {
        _23008 = binary_op(NOTEQ, _23007, 99LL);
    }
    _23007 = NOVALUE;
    if (IS_ATOM_INT(_23008))
    _23006 = (_23008 != 0);
    else
    _23006 = DBL_PTR(_23008)->dbl != 0.0;
L7: 
    if (_23006 == 0) {
        goto L8; // [156] 307
    }
    _2 = (object)SEQ_PTR(_eentry_43926);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _23010 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _23010 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _23011 = find_from(_23010, _29RTN_TOKS_12277, 1LL);
    _23010 = NOVALUE;
    _23012 = (_23011 == 0);
    _23011 = NOVALUE;
    if (_23012 == 0)
    {
        DeRef(_23012);
        _23012 = NOVALUE;
        goto L8; // [177] 307
    }
    else{
        DeRef(_23012);
        _23012 = NOVALUE;
    }

    /** c_decl.e:780				if eentry[S_TOKEN] = PROC then*/
    _2 = (object)SEQ_PTR(_eentry_43926);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _23013 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _23013 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    if (binary_op_a(NOTEQ, _23013, 27LL)){
        _23013 = NOVALUE;
        goto L9; // [190] 202
    }
    _23013 = NOVALUE;

    /** c_decl.e:781					c_puts( "void ")*/
    RefDS(_23015);
    _54c_puts(_23015);
    goto LA; // [199] 208
L9: 

    /** c_decl.e:783					c_puts("object ")*/
    RefDS(_23016);
    _54c_puts(_23016);
LA: 

    /** c_decl.e:785				c_printf("_%d", eentry[S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_eentry_43926);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _23017 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _23017 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    RefDS(_22350);
    Ref(_23017);
    _54c_printf(_22350, _23017);
    _23017 = NOVALUE;

    /** c_decl.e:786				c_puts(eentry[S_NAME])*/
    _2 = (object)SEQ_PTR(_eentry_43926);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _23018 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _23018 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    Ref(_23018);
    _54c_puts(_23018);
    _23018 = NOVALUE;

    /** c_decl.e:787				if is_integer( eentry[S_OBJ] ) then*/
    _2 = (object)SEQ_PTR(_eentry_43926);
    _23019 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_23019);
    _23020 = _27is_integer(_23019);
    _23019 = NOVALUE;
    if (_23020 == 0) {
        DeRef(_23020);
        _23020 = NOVALUE;
        goto LB; // [243] 267
    }
    else {
        if (!IS_ATOM_INT(_23020) && DBL_PTR(_23020)->dbl == 0.0){
            DeRef(_23020);
            _23020 = NOVALUE;
            goto LB; // [243] 267
        }
        DeRef(_23020);
        _23020 = NOVALUE;
    }
    DeRef(_23020);
    _23020 = NOVALUE;

    /** c_decl.e:788						c_printf(" = %d%s;\n", { eentry[S_OBJ], LL_suffix} )*/
    _2 = (object)SEQ_PTR(_eentry_43926);
    _23022 = (object)*(((s1_ptr)_2)->base + 1LL);
    RefDS(_58LL_suffix_30383);
    Ref(_23022);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _23022;
    ((intptr_t *)_2)[2] = _58LL_suffix_30383;
    _23023 = MAKE_SEQ(_1);
    _23022 = NOVALUE;
    RefDS(_23021);
    _54c_printf(_23021, _23023);
    _23023 = NOVALUE;
    goto LC; // [264] 273
LB: 

    /** c_decl.e:790					c_puts(" = NOVALUE;\n")*/
    RefDS(_23024);
    _54c_puts(_23024);
LC: 

    /** c_decl.e:793				c_hputs("extern object ")*/
    RefDS(_23025);
    _54c_hputs(_23025);

    /** c_decl.e:794				c_hprintf("_%d", eentry[S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_eentry_43926);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _23026 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _23026 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    RefDS(_22350);
    Ref(_23026);
    _54c_hprintf(_22350, _23026);
    _23026 = NOVALUE;

    /** c_decl.e:795				c_hputs(eentry[S_NAME])*/
    _2 = (object)SEQ_PTR(_eentry_43926);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _23027 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _23027 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    Ref(_23027);
    _54c_hputs(_23027);
    _23027 = NOVALUE;

    /** c_decl.e:797				c_hputs(";\n")*/
    RefDS(_22506);
    _54c_hputs(_22506);
L8: 

    /** c_decl.e:799			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23028 = (object)*(((s1_ptr)_2)->base + _s_43924);
    _2 = (object)SEQ_PTR(_23028);
    _s_43924 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_43924)){
        _s_43924 = (object)DBL_PTR(_s_43924)->dbl;
    }
    _23028 = NOVALUE;

    /** c_decl.e:800		end while*/
    goto L1; // [325] 29
L2: 

    /** c_decl.e:801		c_puts("\n")*/
    RefDS(_22425);
    _54c_puts(_22425);

    /** c_decl.e:802		c_hputs("\n")*/
    RefDS(_22425);
    _54c_hputs(_22425);

    /** c_decl.e:803		if dll_option or debug_option then*/
    if (_57dll_option_42963 != 0) {
        goto LD; // [342] 353
    }
    if (_57debug_option_42973 == 0)
    {
        goto LE; // [349] 707
    }
    else{
    }
LD: 

    /** c_decl.e:804			integer cleanup_vars = 0*/
    _cleanup_vars_44020 = 0LL;

    /** c_decl.e:805			c_puts("// Declaring var array for cleanup\n")*/
    RefDS(_23031);
    _54c_puts(_23031);

    /** c_decl.e:806			s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23032 = (object)*(((s1_ptr)_2)->base + _27TopLevelSub_20578);
    _2 = (object)SEQ_PTR(_23032);
    _s_43924 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_43924)){
        _s_43924 = (object)DBL_PTR(_s_43924)->dbl;
    }
    _23032 = NOVALUE;

    /** c_decl.e:807			c_stmt0( "object_ptr _0var_cleanup[] = {\n" )*/
    RefDS(_23034);
    _57c_stmt0(_23034);

    /** c_decl.e:808			while s do*/
LF: 
    if (_s_43924 == 0)
    {
        goto L10; // [391] 473
    }
    else{
    }

    /** c_decl.e:809				eentry = SymTab[s]*/
    DeRef(_eentry_43926);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _eentry_43926 = (object)*(((s1_ptr)_2)->base + _s_43924);
    Ref(_eentry_43926);

    /** c_decl.e:810				if needs_uninit( eentry ) then*/
    RefDS(_eentry_43926);
    _23036 = _57needs_uninit(_eentry_43926);
    if (_23036 == 0) {
        DeRef(_23036);
        _23036 = NOVALUE;
        goto L11; // [410] 452
    }
    else {
        if (!IS_ATOM_INT(_23036) && DBL_PTR(_23036)->dbl == 0.0){
            DeRef(_23036);
            _23036 = NOVALUE;
            goto L11; // [410] 452
        }
        DeRef(_23036);
        _23036 = NOVALUE;
    }
    DeRef(_23036);
    _23036 = NOVALUE;

    /** c_decl.e:812					c_stmt0( sprintf("&_%d", eentry[S_FILE_NO]))*/
    _2 = (object)SEQ_PTR(_eentry_43926);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _23038 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _23038 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _23039 = EPrintf(-9999999, _23037, _23038);
    _23038 = NOVALUE;
    _57c_stmt0(_23039);
    _23039 = NOVALUE;

    /** c_decl.e:813					c_puts(eentry[S_NAME] )*/
    _2 = (object)SEQ_PTR(_eentry_43926);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _23040 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _23040 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    Ref(_23040);
    _54c_puts(_23040);
    _23040 = NOVALUE;

    /** c_decl.e:814					c_printf(", // %d\n", cleanup_vars )*/
    RefDS(_23041);
    _54c_printf(_23041, _cleanup_vars_44020);

    /** c_decl.e:815					cleanup_vars += 1*/
    _cleanup_vars_44020 = _cleanup_vars_44020 + 1;
L11: 

    /** c_decl.e:818				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23043 = (object)*(((s1_ptr)_2)->base + _s_43924);
    _2 = (object)SEQ_PTR(_23043);
    _s_43924 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_43924)){
        _s_43924 = (object)DBL_PTR(_s_43924)->dbl;
    }
    _23043 = NOVALUE;

    /** c_decl.e:819			end while*/
    goto LF; // [470] 391
L10: 

    /** c_decl.e:820			c_stmt0( "0\n" )*/
    RefDS(_23045);
    _57c_stmt0(_23045);

    /** c_decl.e:821			c_stmt0( "};\n" )*/
    RefDS(_23046);
    _57c_stmt0(_23046);

    /** c_decl.e:822			s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23047 = (object)*(((s1_ptr)_2)->base + _27TopLevelSub_20578);
    _2 = (object)SEQ_PTR(_23047);
    _s_43924 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_43924)){
        _s_43924 = (object)DBL_PTR(_s_43924)->dbl;
    }
    _23047 = NOVALUE;

    /** c_decl.e:823			c_stmt0( "char *_0var_cleanup_name[] = {\n" )*/
    RefDS(_23049);
    _57c_stmt0(_23049);

    /** c_decl.e:824			cleanup_vars = 0*/
    _cleanup_vars_44020 = 0LL;

    /** c_decl.e:825			while s do*/
L12: 
    if (_s_43924 == 0)
    {
        goto L13; // [516] 598
    }
    else{
    }

    /** c_decl.e:826				eentry = SymTab[s]*/
    DeRef(_eentry_43926);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _eentry_43926 = (object)*(((s1_ptr)_2)->base + _s_43924);
    Ref(_eentry_43926);

    /** c_decl.e:827				if needs_uninit( eentry ) then*/
    RefDS(_eentry_43926);
    _23051 = _57needs_uninit(_eentry_43926);
    if (_23051 == 0) {
        DeRef(_23051);
        _23051 = NOVALUE;
        goto L14; // [535] 577
    }
    else {
        if (!IS_ATOM_INT(_23051) && DBL_PTR(_23051)->dbl == 0.0){
            DeRef(_23051);
            _23051 = NOVALUE;
            goto L14; // [535] 577
        }
        DeRef(_23051);
        _23051 = NOVALUE;
    }
    DeRef(_23051);
    _23051 = NOVALUE;

    /** c_decl.e:828					c_stmt0( sprintf("\"_%d", eentry[S_FILE_NO]))*/
    _2 = (object)SEQ_PTR(_eentry_43926);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _23053 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _23053 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _23054 = EPrintf(-9999999, _23052, _23053);
    _23053 = NOVALUE;
    _57c_stmt0(_23054);
    _23054 = NOVALUE;

    /** c_decl.e:829					c_puts(eentry[S_NAME] )*/
    _2 = (object)SEQ_PTR(_eentry_43926);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _23055 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _23055 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    Ref(_23055);
    _54c_puts(_23055);
    _23055 = NOVALUE;

    /** c_decl.e:830					c_printf("\", // %d\n", cleanup_vars )*/
    RefDS(_23056);
    _54c_printf(_23056, _cleanup_vars_44020);

    /** c_decl.e:831					cleanup_vars += 1*/
    _cleanup_vars_44020 = _cleanup_vars_44020 + 1;
L14: 

    /** c_decl.e:834				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23058 = (object)*(((s1_ptr)_2)->base + _s_43924);
    _2 = (object)SEQ_PTR(_23058);
    _s_43924 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_43924)){
        _s_43924 = (object)DBL_PTR(_s_43924)->dbl;
    }
    _23058 = NOVALUE;

    /** c_decl.e:835			end while*/
    goto L12; // [595] 516
L13: 

    /** c_decl.e:836			c_stmt0( "0\n" )*/
    RefDS(_23045);
    _57c_stmt0(_23045);

    /** c_decl.e:837			c_stmt0( "};\n" )*/
    RefDS(_23046);
    _57c_stmt0(_23046);

    /** c_decl.e:838			c_stmt0( "void _0cleanup_vars(){\n" )*/
    RefDS(_23060);
    _57c_stmt0(_23060);

    /** c_decl.e:839				c_stmt0( "int i;\n" )*/
    RefDS(_22311);
    _57c_stmt0(_22311);

    /** c_decl.e:840				c_stmt0( "object x;\n" )*/
    RefDS(_23061);
    _57c_stmt0(_23061);

    /** c_decl.e:841				c_stmt0( sprintf( "for( i = 0; i < %d; ++i ){\n", cleanup_vars ) )*/
    _23063 = EPrintf(-9999999, _23062, _cleanup_vars_44020);
    _57c_stmt0(_23063);
    _23063 = NOVALUE;

    /** c_decl.e:842					c_stmt0( "x = *_0var_cleanup[i];\n" )*/
    RefDS(_23064);
    _57c_stmt0(_23064);

    //c_decl.e:843					c_stmt0( "if( x >= NOVALUE ) /* do nothing */;\n" )
    RefDS(_23065);
    _57c_stmt0(_23065);

    /** c_decl.e:844					c_stmt0( "else if ( IS_ATOM_DBL( x ) && DBL_PTR( x )->cleanup != 0) {\n")*/
    RefDS(_23066);
    _57c_stmt0(_23066);

    /** c_decl.e:845						c_stmt0( "cleanup_double( DBL_PTR( x ) );\n")*/
    RefDS(_23067);
    _57c_stmt0(_23067);

    /** c_decl.e:846					c_stmt0( "}\n" )*/
    RefDS(_16189);
    _57c_stmt0(_16189);

    /** c_decl.e:847						c_stmt0( "else if (IS_SEQUENCE( x ) && SEQ_PTR( x )->cleanup != 0 ) {\n")*/
    RefDS(_23068);
    _57c_stmt0(_23068);

    /** c_decl.e:848						c_stmt0( "cleanup_sequence( SEQ_PTR( x ) );\n")*/
    RefDS(_23069);
    _57c_stmt0(_23069);

    /** c_decl.e:849					c_stmt0( "}\n" )*/
    RefDS(_16189);
    _57c_stmt0(_16189);

    /** c_decl.e:850				c_stmt0( "}\n" )*/
    RefDS(_16189);
    _57c_stmt0(_16189);

    /** c_decl.e:851				c_stmt0( sprintf( "for( i = 0; i < %d; ++i ){\n", cleanup_vars ) )*/
    _23070 = EPrintf(-9999999, _23062, _cleanup_vars_44020);
    _57c_stmt0(_23070);
    _23070 = NOVALUE;

    /** c_decl.e:852					c_stmt0( "DeRef( *_0var_cleanup[i] );\n" )*/
    RefDS(_23071);
    _57c_stmt0(_23071);

    /** c_decl.e:853					c_stmt0( "*_0var_cleanup[i] = NOVALUE;\n" )*/
    RefDS(_23072);
    _57c_stmt0(_23072);

    /** c_decl.e:854				c_stmt0( "}\n" )*/
    RefDS(_16189);
    _57c_stmt0(_16189);

    /** c_decl.e:855			c_stmt0( "}\n" )*/
    RefDS(_16189);
    _57c_stmt0(_16189);
LE: 

    /** c_decl.e:857	end procedure*/
    DeRef(_eentry_43926);
    DeRef(_22993);
    _22993 = NOVALUE;
    DeRef(_22996);
    _22996 = NOVALUE;
    DeRef(_22999);
    _22999 = NOVALUE;
    DeRef(_23005);
    _23005 = NOVALUE;
    DeRef(_23002);
    _23002 = NOVALUE;
    DeRef(_23008);
    _23008 = NOVALUE;
    return;
    ;
}


object _57PromoteTypeInfo()
{
    object _updsym_44091 = NOVALUE;
    object _s_44093 = NOVALUE;
    object _sym_44094 = NOVALUE;
    object _symo_44095 = NOVALUE;
    object _upd_44324 = NOVALUE;
    object _23171 = NOVALUE;
    object _23169 = NOVALUE;
    object _23168 = NOVALUE;
    object _23167 = NOVALUE;
    object _23166 = NOVALUE;
    object _23164 = NOVALUE;
    object _23162 = NOVALUE;
    object _23161 = NOVALUE;
    object _23160 = NOVALUE;
    object _23159 = NOVALUE;
    object _23158 = NOVALUE;
    object _23154 = NOVALUE;
    object _23151 = NOVALUE;
    object _23150 = NOVALUE;
    object _23149 = NOVALUE;
    object _23148 = NOVALUE;
    object _23147 = NOVALUE;
    object _23146 = NOVALUE;
    object _23145 = NOVALUE;
    object _23144 = NOVALUE;
    object _23143 = NOVALUE;
    object _23142 = NOVALUE;
    object _23141 = NOVALUE;
    object _23139 = NOVALUE;
    object _23138 = NOVALUE;
    object _23137 = NOVALUE;
    object _23136 = NOVALUE;
    object _23135 = NOVALUE;
    object _23134 = NOVALUE;
    object _23133 = NOVALUE;
    object _23132 = NOVALUE;
    object _23131 = NOVALUE;
    object _23130 = NOVALUE;
    object _23128 = NOVALUE;
    object _23127 = NOVALUE;
    object _23126 = NOVALUE;
    object _23124 = NOVALUE;
    object _23123 = NOVALUE;
    object _23122 = NOVALUE;
    object _23120 = NOVALUE;
    object _23119 = NOVALUE;
    object _23118 = NOVALUE;
    object _23117 = NOVALUE;
    object _23116 = NOVALUE;
    object _23115 = NOVALUE;
    object _23114 = NOVALUE;
    object _23112 = NOVALUE;
    object _23111 = NOVALUE;
    object _23110 = NOVALUE;
    object _23109 = NOVALUE;
    object _23107 = NOVALUE;
    object _23106 = NOVALUE;
    object _23104 = NOVALUE;
    object _23103 = NOVALUE;
    object _23102 = NOVALUE;
    object _23101 = NOVALUE;
    object _23100 = NOVALUE;
    object _23099 = NOVALUE;
    object _23098 = NOVALUE;
    object _23096 = NOVALUE;
    object _23095 = NOVALUE;
    object _23094 = NOVALUE;
    object _23093 = NOVALUE;
    object _23092 = NOVALUE;
    object _23091 = NOVALUE;
    object _23090 = NOVALUE;
    object _23089 = NOVALUE;
    object _23088 = NOVALUE;
    object _23087 = NOVALUE;
    object _23086 = NOVALUE;
    object _23085 = NOVALUE;
    object _23084 = NOVALUE;
    object _23083 = NOVALUE;
    object _23081 = NOVALUE;
    object _23080 = NOVALUE;
    object _23079 = NOVALUE;
    object _23077 = NOVALUE;
    object _23076 = NOVALUE;
    object _23073 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** c_decl.e:866		sequence sym, symo*/

    /** c_decl.e:868		updsym = 0*/
    _updsym_44091 = 0LL;

    /** c_decl.e:869		g_has_delete = p_has_delete*/
    _57g_has_delete_43146 = _57p_has_delete_43147;

    /** c_decl.e:870		s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23073 = (object)*(((s1_ptr)_2)->base + _27TopLevelSub_20578);
    _2 = (object)SEQ_PTR(_23073);
    _s_44093 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_44093)){
        _s_44093 = (object)DBL_PTR(_s_44093)->dbl;
    }
    _23073 = NOVALUE;

    /** c_decl.e:871		while s do*/
L1: 
    if (_s_44093 == 0)
    {
        goto L2; // [38] 921
    }
    else{
    }

    /** c_decl.e:872			sym = SymTab[s]*/
    DeRef(_sym_44094);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _sym_44094 = (object)*(((s1_ptr)_2)->base + _s_44093);
    Ref(_sym_44094);

    /** c_decl.e:873			symo = sym*/
    RefDS(_sym_44094);
    DeRef(_symo_44095);
    _symo_44095 = _sym_44094;

    /** c_decl.e:874			if sym[S_TOKEN] = FUNC or sym[S_TOKEN] = TYPE then*/
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _23076 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _23076 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    if (IS_ATOM_INT(_23076)) {
        _23077 = (_23076 == 501LL);
    }
    else {
        _23077 = binary_op(EQUALS, _23076, 501LL);
    }
    _23076 = NOVALUE;
    if (IS_ATOM_INT(_23077)) {
        if (_23077 != 0) {
            goto L3; // [72] 93
        }
    }
    else {
        if (DBL_PTR(_23077)->dbl != 0.0) {
            goto L3; // [72] 93
        }
    }
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _23079 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _23079 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    if (IS_ATOM_INT(_23079)) {
        _23080 = (_23079 == 504LL);
    }
    else {
        _23080 = binary_op(EQUALS, _23079, 504LL);
    }
    _23079 = NOVALUE;
    if (_23080 == 0) {
        DeRef(_23080);
        _23080 = NOVALUE;
        goto L4; // [89] 138
    }
    else {
        if (!IS_ATOM_INT(_23080) && DBL_PTR(_23080)->dbl == 0.0){
            DeRef(_23080);
            _23080 = NOVALUE;
            goto L4; // [89] 138
        }
        DeRef(_23080);
        _23080 = NOVALUE;
    }
    DeRef(_23080);
    _23080 = NOVALUE;
L3: 

    /** c_decl.e:875				if sym[S_GTYPE_NEW] = TYPE_NULL then*/
    _2 = (object)SEQ_PTR(_sym_44094);
    _23081 = (object)*(((s1_ptr)_2)->base + 38LL);
    if (binary_op_a(NOTEQ, _23081, 0LL)){
        _23081 = NOVALUE;
        goto L5; // [103] 120
    }
    _23081 = NOVALUE;

    /** c_decl.e:876					sym[S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44094 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);
    goto L6; // [117] 549
L5: 

    /** c_decl.e:878					sym[S_GTYPE] = sym[S_GTYPE_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44094);
    _23083 = (object)*(((s1_ptr)_2)->base + 38LL);
    Ref(_23083);
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44094 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23083;
    if( _1 != _23083 ){
        DeRef(_1);
    }
    _23083 = NOVALUE;
    goto L6; // [135] 549
L4: 

    /** c_decl.e:883				if sym[S_GTYPE] != TYPE_INTEGER and*/
    _2 = (object)SEQ_PTR(_sym_44094);
    _23084 = (object)*(((s1_ptr)_2)->base + 36LL);
    if (IS_ATOM_INT(_23084)) {
        _23085 = (_23084 != 1LL);
    }
    else {
        _23085 = binary_op(NOTEQ, _23084, 1LL);
    }
    _23084 = NOVALUE;
    if (IS_ATOM_INT(_23085)) {
        if (_23085 == 0) {
            DeRef(_23086);
            _23086 = 0;
            goto L7; // [152] 172
        }
    }
    else {
        if (DBL_PTR(_23085)->dbl == 0.0) {
            DeRef(_23086);
            _23086 = 0;
            goto L7; // [152] 172
        }
    }
    _2 = (object)SEQ_PTR(_sym_44094);
    _23087 = (object)*(((s1_ptr)_2)->base + 38LL);
    if (IS_ATOM_INT(_23087)) {
        _23088 = (_23087 != 16LL);
    }
    else {
        _23088 = binary_op(NOTEQ, _23087, 16LL);
    }
    _23087 = NOVALUE;
    DeRef(_23086);
    if (IS_ATOM_INT(_23088))
    _23086 = (_23088 != 0);
    else
    _23086 = DBL_PTR(_23088)->dbl != 0.0;
L7: 
    if (_23086 == 0) {
        goto L8; // [172] 283
    }
    _2 = (object)SEQ_PTR(_sym_44094);
    _23090 = (object)*(((s1_ptr)_2)->base + 38LL);
    if (IS_ATOM_INT(_23090)) {
        _23091 = (_23090 != 0LL);
    }
    else {
        _23091 = binary_op(NOTEQ, _23090, 0LL);
    }
    _23090 = NOVALUE;
    if (_23091 == 0) {
        DeRef(_23091);
        _23091 = NOVALUE;
        goto L8; // [189] 283
    }
    else {
        if (!IS_ATOM_INT(_23091) && DBL_PTR(_23091)->dbl == 0.0){
            DeRef(_23091);
            _23091 = NOVALUE;
            goto L8; // [189] 283
        }
        DeRef(_23091);
        _23091 = NOVALUE;
    }
    DeRef(_23091);
    _23091 = NOVALUE;

    /** c_decl.e:886					if sym[S_GTYPE_NEW] = TYPE_INTEGER or*/
    _2 = (object)SEQ_PTR(_sym_44094);
    _23092 = (object)*(((s1_ptr)_2)->base + 38LL);
    if (IS_ATOM_INT(_23092)) {
        _23093 = (_23092 == 1LL);
    }
    else {
        _23093 = binary_op(EQUALS, _23092, 1LL);
    }
    _23092 = NOVALUE;
    if (IS_ATOM_INT(_23093)) {
        if (_23093 != 0) {
            DeRef(_23094);
            _23094 = 1;
            goto L9; // [206] 226
        }
    }
    else {
        if (DBL_PTR(_23093)->dbl != 0.0) {
            DeRef(_23094);
            _23094 = 1;
            goto L9; // [206] 226
        }
    }
    _2 = (object)SEQ_PTR(_sym_44094);
    _23095 = (object)*(((s1_ptr)_2)->base + 36LL);
    if (IS_ATOM_INT(_23095)) {
        _23096 = (_23095 == 16LL);
    }
    else {
        _23096 = binary_op(EQUALS, _23095, 16LL);
    }
    _23095 = NOVALUE;
    DeRef(_23094);
    if (IS_ATOM_INT(_23096))
    _23094 = (_23096 != 0);
    else
    _23094 = DBL_PTR(_23096)->dbl != 0.0;
L9: 
    if (_23094 != 0) {
        goto LA; // [226] 267
    }
    _2 = (object)SEQ_PTR(_sym_44094);
    _23098 = (object)*(((s1_ptr)_2)->base + 36LL);
    if (IS_ATOM_INT(_23098)) {
        _23099 = (_23098 == 4LL);
    }
    else {
        _23099 = binary_op(EQUALS, _23098, 4LL);
    }
    _23098 = NOVALUE;
    if (IS_ATOM_INT(_23099)) {
        if (_23099 == 0) {
            DeRef(_23100);
            _23100 = 0;
            goto LB; // [242] 262
        }
    }
    else {
        if (DBL_PTR(_23099)->dbl == 0.0) {
            DeRef(_23100);
            _23100 = 0;
            goto LB; // [242] 262
        }
    }
    _2 = (object)SEQ_PTR(_sym_44094);
    _23101 = (object)*(((s1_ptr)_2)->base + 38LL);
    if (IS_ATOM_INT(_23101)) {
        _23102 = (_23101 == 2LL);
    }
    else {
        _23102 = binary_op(EQUALS, _23101, 2LL);
    }
    _23101 = NOVALUE;
    DeRef(_23100);
    if (IS_ATOM_INT(_23102))
    _23100 = (_23102 != 0);
    else
    _23100 = DBL_PTR(_23102)->dbl != 0.0;
LB: 
    if (_23100 == 0)
    {
        _23100 = NOVALUE;
        goto LC; // [263] 282
    }
    else{
        _23100 = NOVALUE;
    }
LA: 

    /** c_decl.e:890							sym[S_GTYPE] = sym[S_GTYPE_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44094);
    _23103 = (object)*(((s1_ptr)_2)->base + 38LL);
    Ref(_23103);
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44094 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23103;
    if( _1 != _23103 ){
        DeRef(_1);
    }
    _23103 = NOVALUE;
LC: 
L8: 

    /** c_decl.e:893				if sym[S_ARG_TYPE_NEW] = TYPE_NULL then*/
    _2 = (object)SEQ_PTR(_sym_44094);
    _23104 = (object)*(((s1_ptr)_2)->base + 44LL);
    if (binary_op_a(NOTEQ, _23104, 0LL)){
        _23104 = NOVALUE;
        goto LD; // [293] 310
    }
    _23104 = NOVALUE;

    /** c_decl.e:894					sym[S_ARG_TYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44094 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 43LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);
    goto LE; // [307] 325
LD: 

    /** c_decl.e:896					sym[S_ARG_TYPE] = sym[S_ARG_TYPE_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44094);
    _23106 = (object)*(((s1_ptr)_2)->base + 44LL);
    Ref(_23106);
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44094 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 43LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23106;
    if( _1 != _23106 ){
        DeRef(_1);
    }
    _23106 = NOVALUE;
LE: 

    /** c_decl.e:898				sym[S_ARG_TYPE_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44094 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 44LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** c_decl.e:900				if sym[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL then*/
    _2 = (object)SEQ_PTR(_sym_44094);
    _23107 = (object)*(((s1_ptr)_2)->base + 46LL);
    if (binary_op_a(NOTEQ, _23107, 0LL)){
        _23107 = NOVALUE;
        goto LF; // [345] 362
    }
    _23107 = NOVALUE;

    /** c_decl.e:901					sym[S_ARG_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44094 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 45LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);
    goto L10; // [359] 377
LF: 

    /** c_decl.e:903					sym[S_ARG_SEQ_ELEM] = sym[S_ARG_SEQ_ELEM_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44094);
    _23109 = (object)*(((s1_ptr)_2)->base + 46LL);
    Ref(_23109);
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44094 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 45LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23109;
    if( _1 != _23109 ){
        DeRef(_1);
    }
    _23109 = NOVALUE;
L10: 

    /** c_decl.e:905				sym[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44094 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 46LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** c_decl.e:907				if sym[S_ARG_MIN_NEW] = -NOVALUE or*/
    _2 = (object)SEQ_PTR(_sym_44094);
    _23110 = (object)*(((s1_ptr)_2)->base + 49LL);
    if (IS_ATOM_INT(_27NOVALUE_20426)) {
        if ((uintptr_t)_27NOVALUE_20426 == (uintptr_t)HIGH_BITS){
            _23111 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23111 = - _27NOVALUE_20426;
        }
    }
    else {
        _23111 = unary_op(UMINUS, _27NOVALUE_20426);
    }
    if (IS_ATOM_INT(_23110) && IS_ATOM_INT(_23111)) {
        _23112 = (_23110 == _23111);
    }
    else {
        _23112 = binary_op(EQUALS, _23110, _23111);
    }
    _23110 = NOVALUE;
    DeRef(_23111);
    _23111 = NOVALUE;
    if (IS_ATOM_INT(_23112)) {
        if (_23112 != 0) {
            goto L11; // [404] 425
        }
    }
    else {
        if (DBL_PTR(_23112)->dbl != 0.0) {
            goto L11; // [404] 425
        }
    }
    _2 = (object)SEQ_PTR(_sym_44094);
    _23114 = (object)*(((s1_ptr)_2)->base + 49LL);
    if (IS_ATOM_INT(_23114) && IS_ATOM_INT(_27NOVALUE_20426)) {
        _23115 = (_23114 == _27NOVALUE_20426);
    }
    else {
        _23115 = binary_op(EQUALS, _23114, _27NOVALUE_20426);
    }
    _23114 = NOVALUE;
    if (_23115 == 0) {
        DeRef(_23115);
        _23115 = NOVALUE;
        goto L12; // [421] 448
    }
    else {
        if (!IS_ATOM_INT(_23115) && DBL_PTR(_23115)->dbl == 0.0){
            DeRef(_23115);
            _23115 = NOVALUE;
            goto L12; // [421] 448
        }
        DeRef(_23115);
        _23115 = NOVALUE;
    }
    DeRef(_23115);
    _23115 = NOVALUE;
L11: 

    /** c_decl.e:909					sym[S_ARG_MIN] = MININT*/
    Ref(_27MININT_20396);
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44094 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 47LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27MININT_20396;
    DeRef(_1);

    /** c_decl.e:910					sym[S_ARG_MAX] = MAXINT*/
    Ref(_27MAXINT_20395);
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44094 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 48LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27MAXINT_20395;
    DeRef(_1);
    goto L13; // [445] 477
L12: 

    /** c_decl.e:912					sym[S_ARG_MIN] = sym[S_ARG_MIN_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44094);
    _23116 = (object)*(((s1_ptr)_2)->base + 49LL);
    Ref(_23116);
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44094 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 47LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23116;
    if( _1 != _23116 ){
        DeRef(_1);
    }
    _23116 = NOVALUE;

    /** c_decl.e:913					sym[S_ARG_MAX] = sym[S_ARG_MAX_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44094);
    _23117 = (object)*(((s1_ptr)_2)->base + 50LL);
    Ref(_23117);
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44094 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 48LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23117;
    if( _1 != _23117 ){
        DeRef(_1);
    }
    _23117 = NOVALUE;
L13: 

    /** c_decl.e:915				sym[S_ARG_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_27NOVALUE_20426)) {
        if ((uintptr_t)_27NOVALUE_20426 == (uintptr_t)HIGH_BITS){
            _23118 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23118 = - _27NOVALUE_20426;
        }
    }
    else {
        _23118 = unary_op(UMINUS, _27NOVALUE_20426);
    }
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44094 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 49LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23118;
    if( _1 != _23118 ){
        DeRef(_1);
    }
    _23118 = NOVALUE;

    /** c_decl.e:917				if sym[S_ARG_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_44094);
    _23119 = (object)*(((s1_ptr)_2)->base + 52LL);
    if (IS_ATOM_INT(_27NOVALUE_20426)) {
        if ((uintptr_t)_27NOVALUE_20426 == (uintptr_t)HIGH_BITS){
            _23120 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23120 = - _27NOVALUE_20426;
        }
    }
    else {
        _23120 = unary_op(UMINUS, _27NOVALUE_20426);
    }
    if (binary_op_a(NOTEQ, _23119, _23120)){
        _23119 = NOVALUE;
        DeRef(_23120);
        _23120 = NOVALUE;
        goto L14; // [503] 520
    }
    _23119 = NOVALUE;
    DeRef(_23120);
    _23120 = NOVALUE;

    /** c_decl.e:918					sym[S_ARG_SEQ_LEN] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44094 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 51LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
    goto L15; // [517] 535
L14: 

    /** c_decl.e:920					sym[S_ARG_SEQ_LEN] = sym[S_ARG_SEQ_LEN_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44094);
    _23122 = (object)*(((s1_ptr)_2)->base + 52LL);
    Ref(_23122);
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44094 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 51LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23122;
    if( _1 != _23122 ){
        DeRef(_1);
    }
    _23122 = NOVALUE;
L15: 

    /** c_decl.e:922				sym[S_ARG_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_27NOVALUE_20426)) {
        if ((uintptr_t)_27NOVALUE_20426 == (uintptr_t)HIGH_BITS){
            _23123 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23123 = - _27NOVALUE_20426;
        }
    }
    else {
        _23123 = unary_op(UMINUS, _27NOVALUE_20426);
    }
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44094 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 52LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23123;
    if( _1 != _23123 ){
        DeRef(_1);
    }
    _23123 = NOVALUE;
L6: 

    /** c_decl.e:925			sym[S_GTYPE_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44094 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 38LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** c_decl.e:927			if sym[S_SEQ_ELEM_NEW] = TYPE_NULL then*/
    _2 = (object)SEQ_PTR(_sym_44094);
    _23124 = (object)*(((s1_ptr)_2)->base + 40LL);
    if (binary_op_a(NOTEQ, _23124, 0LL)){
        _23124 = NOVALUE;
        goto L16; // [569] 586
    }
    _23124 = NOVALUE;

    /** c_decl.e:928			   sym[S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44094 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);
    goto L17; // [583] 601
L16: 

    /** c_decl.e:930				sym[S_SEQ_ELEM] = sym[S_SEQ_ELEM_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44094);
    _23126 = (object)*(((s1_ptr)_2)->base + 40LL);
    Ref(_23126);
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44094 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23126;
    if( _1 != _23126 ){
        DeRef(_1);
    }
    _23126 = NOVALUE;
L17: 

    /** c_decl.e:932			sym[S_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44094 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** c_decl.e:934			if sym[S_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_44094);
    _23127 = (object)*(((s1_ptr)_2)->base + 39LL);
    if (IS_ATOM_INT(_27NOVALUE_20426)) {
        if ((uintptr_t)_27NOVALUE_20426 == (uintptr_t)HIGH_BITS){
            _23128 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23128 = - _27NOVALUE_20426;
        }
    }
    else {
        _23128 = unary_op(UMINUS, _27NOVALUE_20426);
    }
    if (binary_op_a(NOTEQ, _23127, _23128)){
        _23127 = NOVALUE;
        DeRef(_23128);
        _23128 = NOVALUE;
        goto L18; // [624] 641
    }
    _23127 = NOVALUE;
    DeRef(_23128);
    _23128 = NOVALUE;

    /** c_decl.e:935				sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44094 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
    goto L19; // [638] 656
L18: 

    /** c_decl.e:937				sym[S_SEQ_LEN] = sym[S_SEQ_LEN_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44094);
    _23130 = (object)*(((s1_ptr)_2)->base + 39LL);
    Ref(_23130);
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44094 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23130;
    if( _1 != _23130 ){
        DeRef(_1);
    }
    _23130 = NOVALUE;
L19: 

    /** c_decl.e:939			sym[S_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_27NOVALUE_20426)) {
        if ((uintptr_t)_27NOVALUE_20426 == (uintptr_t)HIGH_BITS){
            _23131 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23131 = - _27NOVALUE_20426;
        }
    }
    else {
        _23131 = unary_op(UMINUS, _27NOVALUE_20426);
    }
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44094 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23131;
    if( _1 != _23131 ){
        DeRef(_1);
    }
    _23131 = NOVALUE;

    /** c_decl.e:941			if sym[S_TOKEN] != NAMESPACE*/
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _23132 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _23132 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    if (IS_ATOM_INT(_23132)) {
        _23133 = (_23132 != 523LL);
    }
    else {
        _23133 = binary_op(NOTEQ, _23132, 523LL);
    }
    _23132 = NOVALUE;
    if (IS_ATOM_INT(_23133)) {
        if (_23133 == 0) {
            goto L1A; // [683] 794
        }
    }
    else {
        if (DBL_PTR(_23133)->dbl == 0.0) {
            goto L1A; // [683] 794
        }
    }
    _2 = (object)SEQ_PTR(_sym_44094);
    _23135 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (IS_ATOM_INT(_23135)) {
        _23136 = (_23135 != 2LL);
    }
    else {
        _23136 = binary_op(NOTEQ, _23135, 2LL);
    }
    _23135 = NOVALUE;
    if (_23136 == 0) {
        DeRef(_23136);
        _23136 = NOVALUE;
        goto L1A; // [700] 794
    }
    else {
        if (!IS_ATOM_INT(_23136) && DBL_PTR(_23136)->dbl == 0.0){
            DeRef(_23136);
            _23136 = NOVALUE;
            goto L1A; // [700] 794
        }
        DeRef(_23136);
        _23136 = NOVALUE;
    }
    DeRef(_23136);
    _23136 = NOVALUE;

    /** c_decl.e:944				if sym[S_OBJ_MIN_NEW] = -NOVALUE or*/
    _2 = (object)SEQ_PTR(_sym_44094);
    _23137 = (object)*(((s1_ptr)_2)->base + 41LL);
    if (IS_ATOM_INT(_27NOVALUE_20426)) {
        if ((uintptr_t)_27NOVALUE_20426 == (uintptr_t)HIGH_BITS){
            _23138 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23138 = - _27NOVALUE_20426;
        }
    }
    else {
        _23138 = unary_op(UMINUS, _27NOVALUE_20426);
    }
    if (IS_ATOM_INT(_23137) && IS_ATOM_INT(_23138)) {
        _23139 = (_23137 == _23138);
    }
    else {
        _23139 = binary_op(EQUALS, _23137, _23138);
    }
    _23137 = NOVALUE;
    DeRef(_23138);
    _23138 = NOVALUE;
    if (IS_ATOM_INT(_23139)) {
        if (_23139 != 0) {
            goto L1B; // [720] 741
        }
    }
    else {
        if (DBL_PTR(_23139)->dbl != 0.0) {
            goto L1B; // [720] 741
        }
    }
    _2 = (object)SEQ_PTR(_sym_44094);
    _23141 = (object)*(((s1_ptr)_2)->base + 41LL);
    if (IS_ATOM_INT(_23141) && IS_ATOM_INT(_27NOVALUE_20426)) {
        _23142 = (_23141 == _27NOVALUE_20426);
    }
    else {
        _23142 = binary_op(EQUALS, _23141, _27NOVALUE_20426);
    }
    _23141 = NOVALUE;
    if (_23142 == 0) {
        DeRef(_23142);
        _23142 = NOVALUE;
        goto L1C; // [737] 764
    }
    else {
        if (!IS_ATOM_INT(_23142) && DBL_PTR(_23142)->dbl == 0.0){
            DeRef(_23142);
            _23142 = NOVALUE;
            goto L1C; // [737] 764
        }
        DeRef(_23142);
        _23142 = NOVALUE;
    }
    DeRef(_23142);
    _23142 = NOVALUE;
L1B: 

    /** c_decl.e:946					sym[S_OBJ_MIN] = MININT*/
    Ref(_27MININT_20396);
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44094 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27MININT_20396;
    DeRef(_1);

    /** c_decl.e:947					sym[S_OBJ_MAX] = MAXINT*/
    Ref(_27MAXINT_20395);
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44094 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27MAXINT_20395;
    DeRef(_1);
    goto L1D; // [761] 793
L1C: 

    /** c_decl.e:949					sym[S_OBJ_MIN] = sym[S_OBJ_MIN_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44094);
    _23143 = (object)*(((s1_ptr)_2)->base + 41LL);
    Ref(_23143);
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44094 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23143;
    if( _1 != _23143 ){
        DeRef(_1);
    }
    _23143 = NOVALUE;

    /** c_decl.e:950					sym[S_OBJ_MAX] = sym[S_OBJ_MAX_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44094);
    _23144 = (object)*(((s1_ptr)_2)->base + 42LL);
    Ref(_23144);
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44094 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23144;
    if( _1 != _23144 ){
        DeRef(_1);
    }
    _23144 = NOVALUE;
L1D: 
L1A: 

    /** c_decl.e:953			sym[S_OBJ_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_27NOVALUE_20426)) {
        if ((uintptr_t)_27NOVALUE_20426 == (uintptr_t)HIGH_BITS){
            _23145 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23145 = - _27NOVALUE_20426;
        }
    }
    else {
        _23145 = unary_op(UMINUS, _27NOVALUE_20426);
    }
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44094 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23145;
    if( _1 != _23145 ){
        DeRef(_1);
    }
    _23145 = NOVALUE;

    /** c_decl.e:955			if sym[S_NREFS] = 1 and*/
    _2 = (object)SEQ_PTR(_sym_44094);
    _23146 = (object)*(((s1_ptr)_2)->base + 12LL);
    if (IS_ATOM_INT(_23146)) {
        _23147 = (_23146 == 1LL);
    }
    else {
        _23147 = binary_op(EQUALS, _23146, 1LL);
    }
    _23146 = NOVALUE;
    if (IS_ATOM_INT(_23147)) {
        if (_23147 == 0) {
            goto L1E; // [819] 874
        }
    }
    else {
        if (DBL_PTR(_23147)->dbl == 0.0) {
            goto L1E; // [819] 874
        }
    }
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _23149 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _23149 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _23150 = find_from(_23149, _29RTN_TOKS_12277, 1LL);
    _23149 = NOVALUE;
    if (_23150 == 0)
    {
        _23150 = NOVALUE;
        goto L1E; // [837] 874
    }
    else{
        _23150 = NOVALUE;
    }

    /** c_decl.e:957				if sym[S_USAGE] != U_DELETED then*/
    _2 = (object)SEQ_PTR(_sym_44094);
    _23151 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (binary_op_a(EQUALS, _23151, 99LL)){
        _23151 = NOVALUE;
        goto L1F; // [850] 873
    }
    _23151 = NOVALUE;

    /** c_decl.e:958					sym[S_USAGE] = U_DELETED*/
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44094 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 99LL;
    DeRef(_1);

    /** c_decl.e:959					deleted_routines += 1*/
    _57deleted_routines_44088 = _57deleted_routines_44088 + 1;
L1F: 
L1E: 

    /** c_decl.e:962			sym[S_NREFS] = 0*/
    _2 = (object)SEQ_PTR(_sym_44094);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44094 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** c_decl.e:963			if not equal(symo, sym) then*/
    if (_symo_44095 == _sym_44094)
    _23154 = 1;
    else if (IS_ATOM_INT(_symo_44095) && IS_ATOM_INT(_sym_44094))
    _23154 = 0;
    else
    _23154 = (compare(_symo_44095, _sym_44094) == 0);
    if (_23154 != 0)
    goto L20; // [888] 906
    _23154 = NOVALUE;

    /** c_decl.e:964				SymTab[s] = sym*/
    RefDS(_sym_44094);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _s_44093);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_44094;
    DeRef(_1);

    /** c_decl.e:965				updsym += 1*/
    _updsym_44091 = _updsym_44091 + 1;
L20: 

    /** c_decl.e:967			s = sym[S_NEXT]*/
    _2 = (object)SEQ_PTR(_sym_44094);
    _s_44093 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_44093)){
        _s_44093 = (object)DBL_PTR(_s_44093)->dbl;
    }

    /** c_decl.e:968		end while*/
    goto L1; // [918] 38
L2: 

    /** c_decl.e:971		for i = 1 to length(temp_name_type) do*/
    if (IS_SEQUENCE(_27temp_name_type_20654)){
            _23158 = SEQ_PTR(_27temp_name_type_20654)->length;
    }
    else {
        _23158 = 1;
    }
    {
        object _i_44321;
        _i_44321 = 1LL;
L21: 
        if (_i_44321 > _23158){
            goto L22; // [928] 1061
        }

        /** c_decl.e:972			integer upd = 0*/
        _upd_44324 = 0LL;

        /** c_decl.e:974			if temp_name_type[i][T_GTYPE] != temp_name_type[i][T_GTYPE_NEW] then*/
        _2 = (object)SEQ_PTR(_27temp_name_type_20654);
        _23159 = (object)*(((s1_ptr)_2)->base + _i_44321);
        _2 = (object)SEQ_PTR(_23159);
        _23160 = (object)*(((s1_ptr)_2)->base + 1LL);
        _23159 = NOVALUE;
        _2 = (object)SEQ_PTR(_27temp_name_type_20654);
        _23161 = (object)*(((s1_ptr)_2)->base + _i_44321);
        _2 = (object)SEQ_PTR(_23161);
        _23162 = (object)*(((s1_ptr)_2)->base + 2LL);
        _23161 = NOVALUE;
        if (binary_op_a(EQUALS, _23160, _23162)){
            _23160 = NOVALUE;
            _23162 = NOVALUE;
            goto L23; // [966] 1003
        }
        _23160 = NOVALUE;
        _23162 = NOVALUE;

        /** c_decl.e:975				temp_name_type[i][T_GTYPE] = temp_name_type[i][T_GTYPE_NEW]*/
        _2 = (object)SEQ_PTR(_27temp_name_type_20654);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _27temp_name_type_20654 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_44321 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_27temp_name_type_20654);
        _23166 = (object)*(((s1_ptr)_2)->base + _i_44321);
        _2 = (object)SEQ_PTR(_23166);
        _23167 = (object)*(((s1_ptr)_2)->base + 2LL);
        _23166 = NOVALUE;
        Ref(_23167);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _23167;
        if( _1 != _23167 ){
            DeRef(_1);
        }
        _23167 = NOVALUE;
        _23164 = NOVALUE;

        /** c_decl.e:976				upd = 1*/
        _upd_44324 = 1LL;
L23: 

        /** c_decl.e:978			if temp_name_type[i][T_GTYPE_NEW] != TYPE_NULL then*/
        _2 = (object)SEQ_PTR(_27temp_name_type_20654);
        _23168 = (object)*(((s1_ptr)_2)->base + _i_44321);
        _2 = (object)SEQ_PTR(_23168);
        _23169 = (object)*(((s1_ptr)_2)->base + 2LL);
        _23168 = NOVALUE;
        if (binary_op_a(EQUALS, _23169, 0LL)){
            _23169 = NOVALUE;
            goto L24; // [1019] 1046
        }
        _23169 = NOVALUE;

        /** c_decl.e:979				temp_name_type[i][T_GTYPE_NEW] = TYPE_NULL*/
        _2 = (object)SEQ_PTR(_27temp_name_type_20654);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _27temp_name_type_20654 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_44321 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 2LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0LL;
        DeRef(_1);
        _23171 = NOVALUE;

        /** c_decl.e:980				upd = 1*/
        _upd_44324 = 1LL;
L24: 

        /** c_decl.e:982			updsym += upd*/
        _updsym_44091 = _updsym_44091 + _upd_44324;

        /** c_decl.e:983		end for*/
        _i_44321 = _i_44321 + 1LL;
        goto L21; // [1056] 935
L22: 
        ;
    }

    /** c_decl.e:985		return updsym*/
    DeRef(_sym_44094);
    DeRef(_symo_44095);
    DeRef(_23102);
    _23102 = NOVALUE;
    DeRef(_23133);
    _23133 = NOVALUE;
    DeRef(_23096);
    _23096 = NOVALUE;
    DeRef(_23085);
    _23085 = NOVALUE;
    DeRef(_23093);
    _23093 = NOVALUE;
    DeRef(_23088);
    _23088 = NOVALUE;
    DeRef(_23099);
    _23099 = NOVALUE;
    DeRef(_23112);
    _23112 = NOVALUE;
    DeRef(_23139);
    _23139 = NOVALUE;
    DeRef(_23147);
    _23147 = NOVALUE;
    DeRef(_23077);
    _23077 = NOVALUE;
    return _updsym_44091;
    ;
}


void _57declare_prototype(object _s_44359)
{
    object _ret_type_44360 = NOVALUE;
    object _scope_44371 = NOVALUE;
    object _23191 = NOVALUE;
    object _23190 = NOVALUE;
    object _23188 = NOVALUE;
    object _23187 = NOVALUE;
    object _23186 = NOVALUE;
    object _23185 = NOVALUE;
    object _23183 = NOVALUE;
    object _23182 = NOVALUE;
    object _23181 = NOVALUE;
    object _23180 = NOVALUE;
    object _23179 = NOVALUE;
    object _23177 = NOVALUE;
    object _23176 = NOVALUE;
    object _23174 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:990		if sym_token( s ) = PROC then*/
    _23174 = _53sym_token(_s_44359);
    if (binary_op_a(NOTEQ, _23174, 27LL)){
        DeRef(_23174);
        _23174 = NOVALUE;
        goto L1; // [11] 25
    }
    DeRef(_23174);
    _23174 = NOVALUE;

    /** c_decl.e:991			ret_type = "void "*/
    RefDS(_23015);
    DeRefi(_ret_type_44360);
    _ret_type_44360 = _23015;
    goto L2; // [22] 33
L1: 

    /** c_decl.e:993			ret_type ="object "*/
    RefDS(_23016);
    DeRefi(_ret_type_44360);
    _ret_type_44360 = _23016;
L2: 

    /** c_decl.e:996		c_hputs(ret_type)*/
    RefDS(_ret_type_44360);
    _54c_hputs(_ret_type_44360);

    /** c_decl.e:999		if dll_option and TWINDOWS  then*/
    if (_57dll_option_42963 == 0) {
        goto L3; // [44] 116
    }
    if (_44TWINDOWS_20715 == 0)
    {
        goto L3; // [51] 116
    }
    else{
    }

    /** c_decl.e:1000			integer scope = SymTab[s][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23177 = (object)*(((s1_ptr)_2)->base + _s_44359);
    _2 = (object)SEQ_PTR(_23177);
    _scope_44371 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_scope_44371)){
        _scope_44371 = (object)DBL_PTR(_scope_44371)->dbl;
    }
    _23177 = NOVALUE;

    /** c_decl.e:1001			if (scope = SC_PUBLIC*/
    _23179 = (_scope_44371 == 13LL);
    if (_23179 != 0) {
        _23180 = 1;
        goto L4; // [78] 92
    }
    _23181 = (_scope_44371 == 11LL);
    _23180 = (_23181 != 0);
L4: 
    if (_23180 != 0) {
        DeRef(_23182);
        _23182 = 1;
        goto L5; // [92] 106
    }
    _23183 = (_scope_44371 == 6LL);
    _23182 = (_23183 != 0);
L5: 
    if (_23182 == 0)
    {
        _23182 = NOVALUE;
        goto L6; // [106] 115
    }
    else{
        _23182 = NOVALUE;
    }

    /** c_decl.e:1006				c_hputs("__stdcall ")*/
    RefDS(_23184);
    _54c_hputs(_23184);
L6: 
L3: 

    /** c_decl.e:1010		c_hprintf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23185 = (object)*(((s1_ptr)_2)->base + _s_44359);
    _2 = (object)SEQ_PTR(_23185);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _23186 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _23186 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _23185 = NOVALUE;
    RefDS(_22350);
    Ref(_23186);
    _54c_hprintf(_22350, _23186);
    _23186 = NOVALUE;

    /** c_decl.e:1011		c_hputs(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23187 = (object)*(((s1_ptr)_2)->base + _s_44359);
    _2 = (object)SEQ_PTR(_23187);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _23188 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _23188 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _23187 = NOVALUE;
    Ref(_23188);
    _54c_hputs(_23188);
    _23188 = NOVALUE;

    /** c_decl.e:1012		c_hputs("(")*/
    RefDS(_23189);
    _54c_hputs(_23189);

    /** c_decl.e:1014		for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23190 = (object)*(((s1_ptr)_2)->base + _s_44359);
    _2 = (object)SEQ_PTR(_23190);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _23191 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _23191 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _23190 = NOVALUE;
    {
        object _i_44400;
        _i_44400 = 1LL;
L7: 
        if (binary_op_a(GREATER, _i_44400, _23191)){
            goto L8; // [172] 206
        }

        /** c_decl.e:1015			if i = 1 then*/
        if (binary_op_a(NOTEQ, _i_44400, 1LL)){
            goto L9; // [181] 193
        }

        /** c_decl.e:1016				c_hputs("object")*/
        RefDS(_23193);
        _54c_hputs(_23193);
        goto LA; // [190] 199
L9: 

        /** c_decl.e:1018				c_hputs(", object")*/
        RefDS(_23194);
        _54c_hputs(_23194);
LA: 

        /** c_decl.e:1020		end for*/
        _0 = _i_44400;
        if (IS_ATOM_INT(_i_44400)) {
            _i_44400 = _i_44400 + 1LL;
            if ((object)((uintptr_t)_i_44400 +(uintptr_t) HIGH_BITS) >= 0){
                _i_44400 = NewDouble((eudouble)_i_44400);
            }
        }
        else {
            _i_44400 = binary_op_a(PLUS, _i_44400, 1LL);
        }
        DeRef(_0);
        goto L7; // [201] 179
L8: 
        ;
        DeRef(_i_44400);
    }

    /** c_decl.e:1021		c_hputs(");\n")*/
    RefDS(_22534);
    _54c_hputs(_22534);

    /** c_decl.e:1022	end procedure*/
    DeRefi(_ret_type_44360);
    DeRef(_23179);
    _23179 = NOVALUE;
    _23191 = NOVALUE;
    DeRef(_23183);
    _23183 = NOVALUE;
    DeRef(_23181);
    _23181 = NOVALUE;
    return;
    ;
}


void _57add_to_routine_list(object _s_44416, object _seq_num_44417, object _first_44418)
{
    object _p_44493 = NOVALUE;
    object _23240 = NOVALUE;
    object _23238 = NOVALUE;
    object _23236 = NOVALUE;
    object _23234 = NOVALUE;
    object _23232 = NOVALUE;
    object _23231 = NOVALUE;
    object _23230 = NOVALUE;
    object _23228 = NOVALUE;
    object _23226 = NOVALUE;
    object _23224 = NOVALUE;
    object _23223 = NOVALUE;
    object _23221 = NOVALUE;
    object _23220 = NOVALUE;
    object _23216 = NOVALUE;
    object _23215 = NOVALUE;
    object _23214 = NOVALUE;
    object _23213 = NOVALUE;
    object _23212 = NOVALUE;
    object _23211 = NOVALUE;
    object _23210 = NOVALUE;
    object _23209 = NOVALUE;
    object _23208 = NOVALUE;
    object _23207 = NOVALUE;
    object _23205 = NOVALUE;
    object _23204 = NOVALUE;
    object _23203 = NOVALUE;
    object _23202 = NOVALUE;
    object _23199 = NOVALUE;
    object _23198 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** c_decl.e:1025		if not first then*/
    if (_first_44418 != 0)
    goto L1; // [9] 18

    /** c_decl.e:1026			c_puts(",\n")*/
    RefDS(_23196);
    _54c_puts(_23196);
L1: 

    /** c_decl.e:1029		c_puts("  {\"")*/
    RefDS(_23197);
    _54c_puts(_23197);

    /** c_decl.e:1031		c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23198 = (object)*(((s1_ptr)_2)->base + _s_44416);
    _2 = (object)SEQ_PTR(_23198);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _23199 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _23199 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _23198 = NOVALUE;
    Ref(_23199);
    _54c_puts(_23199);
    _23199 = NOVALUE;

    /** c_decl.e:1032		c_puts("\", ")*/
    RefDS(_23200);
    _54c_puts(_23200);

    /** c_decl.e:1033		c_puts("(object (*)())")*/
    RefDS(_23201);
    _54c_puts(_23201);

    /** c_decl.e:1034		c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23202 = (object)*(((s1_ptr)_2)->base + _s_44416);
    _2 = (object)SEQ_PTR(_23202);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _23203 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _23203 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _23202 = NOVALUE;
    RefDS(_22350);
    Ref(_23203);
    _54c_printf(_22350, _23203);
    _23203 = NOVALUE;

    /** c_decl.e:1035		c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23204 = (object)*(((s1_ptr)_2)->base + _s_44416);
    _2 = (object)SEQ_PTR(_23204);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _23205 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _23205 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _23204 = NOVALUE;
    Ref(_23205);
    _54c_puts(_23205);
    _23205 = NOVALUE;

    /** c_decl.e:1036		c_printf(", %d", seq_num)*/
    RefDS(_23206);
    _54c_printf(_23206, _seq_num_44417);

    /** c_decl.e:1037		c_printf(", %d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23207 = (object)*(((s1_ptr)_2)->base + _s_44416);
    _2 = (object)SEQ_PTR(_23207);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _23208 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _23208 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _23207 = NOVALUE;
    RefDS(_23206);
    Ref(_23208);
    _54c_printf(_23206, _23208);
    _23208 = NOVALUE;

    /** c_decl.e:1038		c_printf(", %d", SymTab[s][S_NUM_ARGS])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23209 = (object)*(((s1_ptr)_2)->base + _s_44416);
    _2 = (object)SEQ_PTR(_23209);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _23210 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _23210 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _23209 = NOVALUE;
    RefDS(_23206);
    Ref(_23210);
    _54c_printf(_23206, _23210);
    _23210 = NOVALUE;

    /** c_decl.e:1040		if TWINDOWS and dll_option and find( SymTab[s][S_SCOPE], { SC_GLOBAL, SC_EXPORT, SC_PUBLIC} ) then*/
    if (_44TWINDOWS_20715 == 0) {
        _23211 = 0;
        goto L2; // [131] 141
    }
    _23211 = (_57dll_option_42963 != 0);
L2: 
    if (_23211 == 0) {
        goto L3; // [141] 186
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23213 = (object)*(((s1_ptr)_2)->base + _s_44416);
    _2 = (object)SEQ_PTR(_23213);
    _23214 = (object)*(((s1_ptr)_2)->base + 4LL);
    _23213 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 6LL;
    ((intptr_t*)_2)[2] = 11LL;
    ((intptr_t*)_2)[3] = 13LL;
    _23215 = MAKE_SEQ(_1);
    _23216 = find_from(_23214, _23215, 1LL);
    _23214 = NOVALUE;
    DeRefDS(_23215);
    _23215 = NOVALUE;
    if (_23216 == 0)
    {
        _23216 = NOVALUE;
        goto L3; // [175] 186
    }
    else{
        _23216 = NOVALUE;
    }

    /** c_decl.e:1041			c_puts(", 1")  -- must call with __stdcall convention*/
    RefDS(_23217);
    _54c_puts(_23217);
    goto L4; // [183] 192
L3: 

    /** c_decl.e:1043			c_puts(", 0")  -- default: call with normal or __cdecl convention*/
    RefDS(_23218);
    _54c_puts(_23218);
L4: 

    /** c_decl.e:1046		c_printf(", %d, 0", SymTab[s][S_SCOPE] )*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23220 = (object)*(((s1_ptr)_2)->base + _s_44416);
    _2 = (object)SEQ_PTR(_23220);
    _23221 = (object)*(((s1_ptr)_2)->base + 4LL);
    _23220 = NOVALUE;
    RefDS(_23219);
    Ref(_23221);
    _54c_printf(_23219, _23221);
    _23221 = NOVALUE;

    /** c_decl.e:1047		c_puts("}")*/
    RefDS(_23222);
    _54c_puts(_23222);

    /** c_decl.e:1049		if SymTab[s][S_NREFS] < 2 then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23223 = (object)*(((s1_ptr)_2)->base + _s_44416);
    _2 = (object)SEQ_PTR(_23223);
    _23224 = (object)*(((s1_ptr)_2)->base + 12LL);
    _23223 = NOVALUE;
    if (binary_op_a(GREATEREQ, _23224, 2LL)){
        _23224 = NOVALUE;
        goto L5; // [229] 249
    }
    _23224 = NOVALUE;

    /** c_decl.e:1050			SymTab[s][S_NREFS] = 2 --s->nrefs++*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_44416 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _23226 = NOVALUE;
L5: 

    /** c_decl.e:1055		symtab_index p = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23228 = (object)*(((s1_ptr)_2)->base + _s_44416);
    _2 = (object)SEQ_PTR(_23228);
    _p_44493 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_p_44493)){
        _p_44493 = (object)DBL_PTR(_p_44493)->dbl;
    }
    _23228 = NOVALUE;

    /** c_decl.e:1056		for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23230 = (object)*(((s1_ptr)_2)->base + _s_44416);
    _2 = (object)SEQ_PTR(_23230);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _23231 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _23231 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _23230 = NOVALUE;
    {
        object _i_44499;
        _i_44499 = 1LL;
L6: 
        if (binary_op_a(GREATER, _i_44499, _23231)){
            goto L7; // [279] 377
        }

        /** c_decl.e:1057			SymTab[p][S_ARG_SEQ_ELEM_NEW] = TYPE_OBJECT*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_44493 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 46LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 16LL;
        DeRef(_1);
        _23232 = NOVALUE;

        /** c_decl.e:1058			SymTab[p][S_ARG_TYPE_NEW] = TYPE_OBJECT*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_44493 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 44LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 16LL;
        DeRef(_1);
        _23234 = NOVALUE;

        /** c_decl.e:1059			SymTab[p][S_ARG_MIN_NEW] = NOVALUE*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_44493 + ((s1_ptr)_2)->base);
        Ref(_27NOVALUE_20426);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 49LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _27NOVALUE_20426;
        DeRef(_1);
        _23236 = NOVALUE;

        /** c_decl.e:1060			SymTab[p][S_ARG_SEQ_LEN_NEW] = NOVALUE*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_44493 + ((s1_ptr)_2)->base);
        Ref(_27NOVALUE_20426);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 52LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _27NOVALUE_20426;
        DeRef(_1);
        _23238 = NOVALUE;

        /** c_decl.e:1061			p = SymTab[p][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _23240 = (object)*(((s1_ptr)_2)->base + _p_44493);
        _2 = (object)SEQ_PTR(_23240);
        _p_44493 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_p_44493)){
            _p_44493 = (object)DBL_PTR(_p_44493)->dbl;
        }
        _23240 = NOVALUE;

        /** c_decl.e:1062		end for*/
        _0 = _i_44499;
        if (IS_ATOM_INT(_i_44499)) {
            _i_44499 = _i_44499 + 1LL;
            if ((object)((uintptr_t)_i_44499 +(uintptr_t) HIGH_BITS) >= 0){
                _i_44499 = NewDouble((eudouble)_i_44499);
            }
        }
        else {
            _i_44499 = binary_op_a(PLUS, _i_44499, 1LL);
        }
        DeRef(_0);
        goto L6; // [372] 286
L7: 
        ;
        DeRef(_i_44499);
    }

    /** c_decl.e:1063	end procedure*/
    _23231 = NOVALUE;
    return;
    ;
}


void _57DeclareRoutineList()
{
    object _s_44531 = NOVALUE;
    object _first_44532 = NOVALUE;
    object _seq_num_44533 = NOVALUE;
    object _these_routines_44541 = NOVALUE;
    object _these_routines_44563 = NOVALUE;
    object _23256 = NOVALUE;
    object _23255 = NOVALUE;
    object _23253 = NOVALUE;
    object _23251 = NOVALUE;
    object _23248 = NOVALUE;
    object _23247 = NOVALUE;
    object _23245 = NOVALUE;
    object _23243 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1069		integer first, seq_num*/

    /** c_decl.e:1071		c_hputs("extern struct routine_list _00[];\n")*/
    RefDS(_23242);
    _54c_hputs(_23242);

    /** c_decl.e:1073		check_file_routines()*/
    _57check_file_routines();

    /** c_decl.e:1074		for f = 1 to length( file_routines ) do*/
    if (IS_SEQUENCE(_57file_routines_45124)){
            _23243 = SEQ_PTR(_57file_routines_45124)->length;
    }
    else {
        _23243 = 1;
    }
    {
        object _f_44538;
        _f_44538 = 1LL;
L1: 
        if (_f_44538 > _23243){
            goto L2; // [19] 98
        }

        /** c_decl.e:1075			sequence these_routines = file_routines[f]*/
        DeRef(_these_routines_44541);
        _2 = (object)SEQ_PTR(_57file_routines_45124);
        _these_routines_44541 = (object)*(((s1_ptr)_2)->base + _f_44538);
        Ref(_these_routines_44541);

        /** c_decl.e:1076			for r = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_44541)){
                _23245 = SEQ_PTR(_these_routines_44541)->length;
        }
        else {
            _23245 = 1;
        }
        {
            object _r_44545;
            _r_44545 = 1LL;
L3: 
            if (_r_44545 > _23245){
                goto L4; // [41] 89
            }

            /** c_decl.e:1077				s = these_routines[r]*/
            _2 = (object)SEQ_PTR(_these_routines_44541);
            _s_44531 = (object)*(((s1_ptr)_2)->base + _r_44545);
            if (!IS_ATOM_INT(_s_44531)){
                _s_44531 = (object)DBL_PTR(_s_44531)->dbl;
            }

            /** c_decl.e:1078				if SymTab[s][S_USAGE] != U_DELETED then*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23247 = (object)*(((s1_ptr)_2)->base + _s_44531);
            _2 = (object)SEQ_PTR(_23247);
            _23248 = (object)*(((s1_ptr)_2)->base + 5LL);
            _23247 = NOVALUE;
            if (binary_op_a(EQUALS, _23248, 99LL)){
                _23248 = NOVALUE;
                goto L5; // [72] 82
            }
            _23248 = NOVALUE;

            /** c_decl.e:1080					declare_prototype( s )*/
            _57declare_prototype(_s_44531);
L5: 

            /** c_decl.e:1083			end for*/
            _r_44545 = _r_44545 + 1LL;
            goto L3; // [84] 48
L4: 
            ;
        }
        DeRef(_these_routines_44541);
        _these_routines_44541 = NOVALUE;

        /** c_decl.e:1084		end for*/
        _f_44538 = _f_44538 + 1LL;
        goto L1; // [93] 26
L2: 
        ;
    }

    /** c_decl.e:1085		c_puts("\n")*/
    RefDS(_22425);
    _54c_puts(_22425);

    /** c_decl.e:1088		seq_num = 0*/
    _seq_num_44533 = 0LL;

    /** c_decl.e:1089		first = TRUE*/
    _first_44532 = _9TRUE_441;

    /** c_decl.e:1090		c_puts("struct routine_list _00[] = {\n")*/
    RefDS(_23250);
    _54c_puts(_23250);

    /** c_decl.e:1092		for f = 1 to length( file_routines ) do*/
    if (IS_SEQUENCE(_57file_routines_45124)){
            _23251 = SEQ_PTR(_57file_routines_45124)->length;
    }
    else {
        _23251 = 1;
    }
    {
        object _f_44560;
        _f_44560 = 1LL;
L6: 
        if (_f_44560 > _23251){
            goto L7; // [129] 222
        }

        /** c_decl.e:1093			sequence these_routines = file_routines[f]*/
        DeRef(_these_routines_44563);
        _2 = (object)SEQ_PTR(_57file_routines_45124);
        _these_routines_44563 = (object)*(((s1_ptr)_2)->base + _f_44560);
        Ref(_these_routines_44563);

        /** c_decl.e:1094			for r = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_44563)){
                _23253 = SEQ_PTR(_these_routines_44563)->length;
        }
        else {
            _23253 = 1;
        }
        {
            object _r_44567;
            _r_44567 = 1LL;
L8: 
            if (_r_44567 > _23253){
                goto L9; // [151] 213
            }

            /** c_decl.e:1095				s = these_routines[r]*/
            _2 = (object)SEQ_PTR(_these_routines_44563);
            _s_44531 = (object)*(((s1_ptr)_2)->base + _r_44567);
            if (!IS_ATOM_INT(_s_44531)){
                _s_44531 = (object)DBL_PTR(_s_44531)->dbl;
            }

            /** c_decl.e:1096				if SymTab[s][S_RI_TARGET] then*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23255 = (object)*(((s1_ptr)_2)->base + _s_44531);
            _2 = (object)SEQ_PTR(_23255);
            _23256 = (object)*(((s1_ptr)_2)->base + 53LL);
            _23255 = NOVALUE;
            if (_23256 == 0) {
                _23256 = NOVALUE;
                goto LA; // [180] 200
            }
            else {
                if (!IS_ATOM_INT(_23256) && DBL_PTR(_23256)->dbl == 0.0){
                    _23256 = NOVALUE;
                    goto LA; // [180] 200
                }
                _23256 = NOVALUE;
            }
            _23256 = NOVALUE;

            /** c_decl.e:1098					add_to_routine_list( s, seq_num, first )*/
            _57add_to_routine_list(_s_44531, _seq_num_44533, _first_44532);

            /** c_decl.e:1099					first = FALSE*/
            _first_44532 = _9FALSE_439;
LA: 

            /** c_decl.e:1102				seq_num += 1*/
            _seq_num_44533 = _seq_num_44533 + 1;

            /** c_decl.e:1103			end for*/
            _r_44567 = _r_44567 + 1LL;
            goto L8; // [208] 158
L9: 
            ;
        }
        DeRef(_these_routines_44563);
        _these_routines_44563 = NOVALUE;

        /** c_decl.e:1104		end for*/
        _f_44560 = _f_44560 + 1LL;
        goto L6; // [217] 136
L7: 
        ;
    }

    /** c_decl.e:1105		if not first then*/
    if (_first_44532 != 0)
    goto LB; // [224] 233

    /** c_decl.e:1106			c_puts(",\n")*/
    RefDS(_23196);
    _54c_puts(_23196);
LB: 

    /** c_decl.e:1108		c_puts("  {\"\", 0, 999999999, 0, 0, 0, 0}\n};\n\n")  -- end marker*/
    RefDS(_23259);
    _54c_puts(_23259);

    /** c_decl.e:1110		c_hputs("extern char ** _02;\n")*/
    RefDS(_23260);
    _54c_hputs(_23260);

    /** c_decl.e:1111		c_puts("char ** _02;\n")*/
    RefDS(_23261);
    _54c_puts(_23261);

    /** c_decl.e:1113		c_hputs("extern object _0switches;\n")*/
    RefDS(_23262);
    _54c_hputs(_23262);

    /** c_decl.e:1114		c_puts("object _0switches;\n")*/
    RefDS(_23263);
    _54c_puts(_23263);

    /** c_decl.e:1115	end procedure*/
    return;
    ;
}


void _57DeclareNameSpaceList()
{
    object _s_44593 = NOVALUE;
    object _first_44594 = NOVALUE;
    object _seq_num_44595 = NOVALUE;
    object _23283 = NOVALUE;
    object _23281 = NOVALUE;
    object _23280 = NOVALUE;
    object _23279 = NOVALUE;
    object _23278 = NOVALUE;
    object _23276 = NOVALUE;
    object _23275 = NOVALUE;
    object _23272 = NOVALUE;
    object _23271 = NOVALUE;
    object _23270 = NOVALUE;
    object _23269 = NOVALUE;
    object _23268 = NOVALUE;
    object _23266 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1121		integer first, seq_num*/

    /** c_decl.e:1123		c_hputs("extern struct ns_list _01[];\n")*/
    RefDS(_23264);
    _54c_hputs(_23264);

    /** c_decl.e:1124		c_puts("struct ns_list _01[] = {\n")*/
    RefDS(_23265);
    _54c_puts(_23265);

    /** c_decl.e:1126		seq_num = 0*/
    _seq_num_44595 = 0LL;

    /** c_decl.e:1127		first = TRUE*/
    _first_44594 = _9TRUE_441;

    /** c_decl.e:1129		s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23266 = (object)*(((s1_ptr)_2)->base + _27TopLevelSub_20578);
    _2 = (object)SEQ_PTR(_23266);
    _s_44593 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_44593)){
        _s_44593 = (object)DBL_PTR(_s_44593)->dbl;
    }
    _23266 = NOVALUE;

    /** c_decl.e:1130		while s do*/
L1: 
    if (_s_44593 == 0)
    {
        goto L2; // [50] 215
    }
    else{
    }

    /** c_decl.e:1131			if find(SymTab[s][S_TOKEN], NAMED_TOKS) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23268 = (object)*(((s1_ptr)_2)->base + _s_44593);
    _2 = (object)SEQ_PTR(_23268);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _23269 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _23269 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _23268 = NOVALUE;
    _23270 = find_from(_23269, _29NAMED_TOKS_12279, 1LL);
    _23269 = NOVALUE;
    if (_23270 == 0)
    {
        _23270 = NOVALUE;
        goto L3; // [74] 194
    }
    else{
        _23270 = NOVALUE;
    }

    /** c_decl.e:1132				if SymTab[s][S_TOKEN] = NAMESPACE then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23271 = (object)*(((s1_ptr)_2)->base + _s_44593);
    _2 = (object)SEQ_PTR(_23271);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _23272 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _23272 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _23271 = NOVALUE;
    if (binary_op_a(NOTEQ, _23272, 523LL)){
        _23272 = NOVALUE;
        goto L4; // [93] 187
    }
    _23272 = NOVALUE;

    /** c_decl.e:1133					if not first then*/
    if (_first_44594 != 0)
    goto L5; // [99] 108

    /** c_decl.e:1134						c_puts(",\n")*/
    RefDS(_23196);
    _54c_puts(_23196);
L5: 

    /** c_decl.e:1136					first = FALSE*/
    _first_44594 = _9FALSE_439;

    /** c_decl.e:1138					c_puts("  {\"")*/
    RefDS(_23197);
    _54c_puts(_23197);

    /** c_decl.e:1139					c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23275 = (object)*(((s1_ptr)_2)->base + _s_44593);
    _2 = (object)SEQ_PTR(_23275);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _23276 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _23276 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _23275 = NOVALUE;
    Ref(_23276);
    _54c_puts(_23276);
    _23276 = NOVALUE;

    /** c_decl.e:1140					c_printf("\", %d", SymTab[s][S_OBJ])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23278 = (object)*(((s1_ptr)_2)->base + _s_44593);
    _2 = (object)SEQ_PTR(_23278);
    _23279 = (object)*(((s1_ptr)_2)->base + 1LL);
    _23278 = NOVALUE;
    RefDS(_23277);
    Ref(_23279);
    _54c_printf(_23277, _23279);
    _23279 = NOVALUE;

    /** c_decl.e:1141					c_printf(", %d", seq_num)*/
    RefDS(_23206);
    _54c_printf(_23206, _seq_num_44595);

    /** c_decl.e:1142					c_printf(", %d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23280 = (object)*(((s1_ptr)_2)->base + _s_44593);
    _2 = (object)SEQ_PTR(_23280);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _23281 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _23281 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _23280 = NOVALUE;
    RefDS(_23206);
    Ref(_23281);
    _54c_printf(_23206, _23281);
    _23281 = NOVALUE;

    /** c_decl.e:1144					c_puts("}")*/
    RefDS(_23222);
    _54c_puts(_23222);
L4: 

    /** c_decl.e:1146				seq_num += 1*/
    _seq_num_44595 = _seq_num_44595 + 1;
L3: 

    /** c_decl.e:1148			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23283 = (object)*(((s1_ptr)_2)->base + _s_44593);
    _2 = (object)SEQ_PTR(_23283);
    _s_44593 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_44593)){
        _s_44593 = (object)DBL_PTR(_s_44593)->dbl;
    }
    _23283 = NOVALUE;

    /** c_decl.e:1149		end while*/
    goto L1; // [212] 50
L2: 

    /** c_decl.e:1150		if not first then*/
    if (_first_44594 != 0)
    goto L6; // [217] 226

    /** c_decl.e:1151			c_puts(",\n")*/
    RefDS(_23196);
    _54c_puts(_23196);
L6: 

    /** c_decl.e:1153		c_puts("  {\"\", 0, 999999999, 0}\n};\n\n")  -- end marker*/
    RefDS(_23286);
    _54c_puts(_23286);

    /** c_decl.e:1154	end procedure*/
    return;
    ;
}


object _57is_exported(object _s_44657)
{
    object _eentry_44658 = NOVALUE;
    object _scope_44661 = NOVALUE;
    object _23301 = NOVALUE;
    object _23300 = NOVALUE;
    object _23299 = NOVALUE;
    object _23298 = NOVALUE;
    object _23297 = NOVALUE;
    object _23296 = NOVALUE;
    object _23295 = NOVALUE;
    object _23294 = NOVALUE;
    object _23293 = NOVALUE;
    object _23292 = NOVALUE;
    object _23291 = NOVALUE;
    object _23289 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_44657)) {
        _1 = (object)(DBL_PTR(_s_44657)->dbl);
        DeRefDS(_s_44657);
        _s_44657 = _1;
    }

    /** c_decl.e:1159		sequence eentry = SymTab[s]*/
    DeRef(_eentry_44658);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _eentry_44658 = (object)*(((s1_ptr)_2)->base + _s_44657);
    Ref(_eentry_44658);

    /** c_decl.e:1160		integer scope = eentry[S_SCOPE]*/
    _2 = (object)SEQ_PTR(_eentry_44658);
    _scope_44661 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_scope_44661))
    _scope_44661 = (object)DBL_PTR(_scope_44661)->dbl;

    /** c_decl.e:1162		if eentry[S_MODE] = M_NORMAL then*/
    _2 = (object)SEQ_PTR(_eentry_44658);
    _23289 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (binary_op_a(NOTEQ, _23289, 1LL)){
        _23289 = NOVALUE;
        goto L1; // [31] 125
    }
    _23289 = NOVALUE;

    /** c_decl.e:1163			if eentry[S_FILE_NO] = 1 and find(scope, { SC_EXPORT, SC_PUBLIC, SC_GLOBAL }) then*/
    _2 = (object)SEQ_PTR(_eentry_44658);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _23291 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _23291 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    if (IS_ATOM_INT(_23291)) {
        _23292 = (_23291 == 1LL);
    }
    else {
        _23292 = binary_op(EQUALS, _23291, 1LL);
    }
    _23291 = NOVALUE;
    if (IS_ATOM_INT(_23292)) {
        if (_23292 == 0) {
            goto L2; // [47] 79
        }
    }
    else {
        if (DBL_PTR(_23292)->dbl == 0.0) {
            goto L2; // [47] 79
        }
    }
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 11LL;
    ((intptr_t*)_2)[2] = 13LL;
    ((intptr_t*)_2)[3] = 6LL;
    _23294 = MAKE_SEQ(_1);
    _23295 = find_from(_scope_44661, _23294, 1LL);
    DeRefDS(_23294);
    _23294 = NOVALUE;
    if (_23295 == 0)
    {
        _23295 = NOVALUE;
        goto L2; // [69] 79
    }
    else{
        _23295 = NOVALUE;
    }

    /** c_decl.e:1164				return 1*/
    DeRef(_eentry_44658);
    DeRef(_23292);
    _23292 = NOVALUE;
    return 1LL;
L2: 

    /** c_decl.e:1167			if scope = SC_PUBLIC and*/
    _23296 = (_scope_44661 == 13LL);
    if (_23296 == 0) {
        goto L3; // [87] 124
    }
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _23298 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_eentry_44658);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _23299 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _23299 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _2 = (object)SEQ_PTR(_23298);
    if (!IS_ATOM_INT(_23299)){
        _23300 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_23299)->dbl));
    }
    else{
        _23300 = (object)*(((s1_ptr)_2)->base + _23299);
    }
    _23298 = NOVALUE;
    if (IS_ATOM_INT(_23300)) {
        {uintptr_t tu;
             tu = (uintptr_t)_23300 & (uintptr_t)4LL;
             _23301 = MAKE_UINT(tu);
        }
    }
    else {
        _23301 = binary_op(AND_BITS, _23300, 4LL);
    }
    _23300 = NOVALUE;
    if (_23301 == 0) {
        DeRef(_23301);
        _23301 = NOVALUE;
        goto L3; // [114] 124
    }
    else {
        if (!IS_ATOM_INT(_23301) && DBL_PTR(_23301)->dbl == 0.0){
            DeRef(_23301);
            _23301 = NOVALUE;
            goto L3; // [114] 124
        }
        DeRef(_23301);
        _23301 = NOVALUE;
    }
    DeRef(_23301);
    _23301 = NOVALUE;

    /** c_decl.e:1170				return 1*/
    DeRef(_eentry_44658);
    _23299 = NOVALUE;
    DeRef(_23292);
    _23292 = NOVALUE;
    DeRef(_23296);
    _23296 = NOVALUE;
    return 1LL;
L3: 
L1: 

    /** c_decl.e:1174		return 0*/
    DeRef(_eentry_44658);
    _23299 = NOVALUE;
    DeRef(_23292);
    _23292 = NOVALUE;
    DeRef(_23296);
    _23296 = NOVALUE;
    return 0LL;
    ;
}


void _57version()
{
    object _23335 = NOVALUE;
    object _23334 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1207		c_puts("// Euphoria To C version " & version_string() & "\n")*/
    _23334 = _40version_string(0LL);
    {
        object concat_list[3];

        concat_list[0] = _22425;
        concat_list[1] = _23334;
        concat_list[2] = _23333;
        Concat_N((object_ptr)&_23335, concat_list, 3);
    }
    DeRef(_23334);
    _23334 = NOVALUE;
    _54c_puts(_23335);
    _23335 = NOVALUE;

    /** c_decl.e:1208	end procedure*/
    return;
    ;
}


void _57new_c_file(object _name_44765)
{
    object _23338 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1213		cfile_size = 0*/
    _27cfile_size_20651 = 0LL;

    /** c_decl.e:1216		if LAST_PASS = FALSE then*/
    if (_57LAST_PASS_42949 != _9FALSE_439)
    goto L1; // [16] 26

    /** c_decl.e:1217			return*/
    DeRefDS(_name_44765);
    return;
L1: 

    /** c_decl.e:1220		write_checksum( c_code )*/
    _55write_checksum(_54c_code_47060);

    /** c_decl.e:1221		close(c_code)*/
    EClose(_54c_code_47060);

    /** c_decl.e:1223		c_code = open(output_dir & name & ".c", "w")*/
    {
        object concat_list[3];

        concat_list[0] = _23337;
        concat_list[1] = _name_44765;
        concat_list[2] = _57output_dir_42977;
        Concat_N((object_ptr)&_23338, concat_list, 3);
    }
    _54c_code_47060 = EOpen(_23338, _22363, 0LL);
    DeRefDS(_23338);
    _23338 = NOVALUE;

    /** c_decl.e:1224		if c_code = -1 then*/
    if (_54c_code_47060 != -1LL)
    goto L2; // [60] 74

    /** c_decl.e:1225			CompileErr(COULDNT_OPEN_C_FILE_FOR_OUTPUT)*/
    RefDS(_22218);
    _49CompileErr(57LL, _22218, 0LL);
L2: 

    /** c_decl.e:1228		cfile_count += 1*/
    _27cfile_count_20650 = _27cfile_count_20650 + 1LL;

    /** c_decl.e:1229		version()*/
    _57version();

    /** c_decl.e:1231		c_puts("#include \"include/euphoria.h\"\n")*/
    RefDS(_22368);
    _54c_puts(_22368);

    /** c_decl.e:1233		c_puts("#include \"main-.h\"\n\n")*/
    RefDS(_22369);
    _54c_puts(_22369);

    /** c_decl.e:1235		if not TUNIX then*/

    /** c_decl.e:1236			name = lower(name)  -- for faster compare later*/
    RefDS(_name_44765);
    _0 = _name_44765;
    _name_44765 = _12lower(_name_44765);
    DeRefDS(_0);

    /** c_decl.e:1238	end procedure*/
    DeRefDS(_name_44765);
    return;
    ;
}


object _57unique_c_name(object _name_44795)
{
    object _i_44796 = NOVALUE;
    object _compare_name_44797 = NOVALUE;
    object _next_fc_44798 = NOVALUE;
    object _23354 = NOVALUE;
    object _23352 = NOVALUE;
    object _23351 = NOVALUE;
    object _23350 = NOVALUE;
    object _23348 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1253		compare_name = name & ".c"*/
    Concat((object_ptr)&_compare_name_44797, _name_44795, _23337);

    /** c_decl.e:1254		if not TUNIX then*/

    /** c_decl.e:1255			compare_name = lower(compare_name)*/
    RefDS(_compare_name_44797);
    _0 = _compare_name_44797;
    _compare_name_44797 = _12lower(_compare_name_44797);
    DeRefDS(_0);

    /** c_decl.e:1258		next_fc = 1*/
    _next_fc_44798 = 1LL;

    /** c_decl.e:1259		i = 1*/
    _i_44796 = 1LL;

    /** c_decl.e:1261		while i <= length(generated_files) do*/
L1: 
    if (IS_SEQUENCE(_57generated_files_42967)){
            _23348 = SEQ_PTR(_57generated_files_42967)->length;
    }
    else {
        _23348 = 1;
    }
    if (_i_44796 > _23348)
    goto L2; // [45] 141

    /** c_decl.e:1263			if equal(generated_files[i], compare_name) then*/
    _2 = (object)SEQ_PTR(_57generated_files_42967);
    _23350 = (object)*(((s1_ptr)_2)->base + _i_44796);
    if (_23350 == _compare_name_44797)
    _23351 = 1;
    else if (IS_ATOM_INT(_23350) && IS_ATOM_INT(_compare_name_44797))
    _23351 = 0;
    else
    _23351 = (compare(_23350, _compare_name_44797) == 0);
    _23350 = NOVALUE;
    if (_23351 == 0)
    {
        _23351 = NOVALUE;
        goto L3; // [61] 129
    }
    else{
        _23351 = NOVALUE;
    }

    /** c_decl.e:1265				if next_fc > length(file_chars) then*/
    if (IS_SEQUENCE(_57file_chars_44791)){
            _23352 = SEQ_PTR(_57file_chars_44791)->length;
    }
    else {
        _23352 = 1;
    }
    if (_next_fc_44798 <= _23352)
    goto L4; // [69] 83

    /** c_decl.e:1266					CompileErr(SORRY_TOO_MANY_C_FILES_WITH_THE_SAME_BASE_NAME)*/
    RefDS(_22218);
    _49CompileErr(140LL, _22218, 0LL);
L4: 

    /** c_decl.e:1269				name[1] = file_chars[next_fc]*/
    _2 = (object)SEQ_PTR(_57file_chars_44791);
    _23354 = (object)*(((s1_ptr)_2)->base + _next_fc_44798);
    Ref(_23354);
    _2 = (object)SEQ_PTR(_name_44795);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _name_44795 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23354;
    if( _1 != _23354 ){
        DeRef(_1);
    }
    _23354 = NOVALUE;

    /** c_decl.e:1270				compare_name = name & ".c"*/
    Concat((object_ptr)&_compare_name_44797, _name_44795, _23337);

    /** c_decl.e:1271				if not TUNIX then*/

    /** c_decl.e:1272					compare_name = lower(compare_name)*/
    RefDS(_compare_name_44797);
    _0 = _compare_name_44797;
    _compare_name_44797 = _12lower(_compare_name_44797);
    DeRefDS(_0);

    /** c_decl.e:1275				next_fc += 1*/
    _next_fc_44798 = _next_fc_44798 + 1;

    /** c_decl.e:1276				i = 1 -- start over and compare again*/
    _i_44796 = 1LL;
    goto L1; // [126] 40
L3: 

    /** c_decl.e:1279				i += 1*/
    _i_44796 = _i_44796 + 1;

    /** c_decl.e:1281		end while*/
    goto L1; // [138] 40
L2: 

    /** c_decl.e:1283		return name*/
    DeRef(_compare_name_44797);
    return _name_44795;
    ;
}


object _57is_file_newer(object _f1_44828, object _f2_44829)
{
    object _d1_44830 = NOVALUE;
    object _d2_44833 = NOVALUE;
    object _diff_2__tmp_at42_44844 = NOVALUE;
    object _diff_1__tmp_at42_44843 = NOVALUE;
    object _diff_inlined_diff_at_42_44842 = NOVALUE;
    object _23364 = NOVALUE;
    object _23362 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1287		object d1 = file_timestamp(f1)*/
    RefDS(_f1_44828);
    _0 = _d1_44830;
    _d1_44830 = _15file_timestamp(_f1_44828);
    DeRef(_0);

    /** c_decl.e:1288		object d2 = file_timestamp(f2)*/
    RefDS(_f2_44829);
    _0 = _d2_44833;
    _d2_44833 = _15file_timestamp(_f2_44829);
    DeRef(_0);

    /** c_decl.e:1290		if atom(d1) or atom(d2) then return 1 end if*/
    _23362 = IS_ATOM(_d1_44830);
    if (_23362 != 0) {
        goto L1; // [22] 34
    }
    _23364 = IS_ATOM(_d2_44833);
    if (_23364 == 0)
    {
        _23364 = NOVALUE;
        goto L2; // [30] 39
    }
    else{
        _23364 = NOVALUE;
    }
L1: 
    DeRefDS(_f1_44828);
    DeRefDS(_f2_44829);
    DeRef(_d1_44830);
    DeRef(_d2_44833);
    return 1LL;
L2: 

    /** c_decl.e:1291		if datetime:diff(d1, d2) < 0 then*/

    /** datetime.e:1253		return datetimeToSeconds(dt2) - datetimeToSeconds(dt1)*/
    Ref(_d2_44833);
    _0 = _diff_1__tmp_at42_44843;
    _diff_1__tmp_at42_44843 = _16datetimeToSeconds(_d2_44833);
    DeRef(_0);
    Ref(_d1_44830);
    _0 = _diff_2__tmp_at42_44844;
    _diff_2__tmp_at42_44844 = _16datetimeToSeconds(_d1_44830);
    DeRef(_0);
    DeRef(_diff_inlined_diff_at_42_44842);
    if (IS_ATOM_INT(_diff_1__tmp_at42_44843) && IS_ATOM_INT(_diff_2__tmp_at42_44844)) {
        _diff_inlined_diff_at_42_44842 = _diff_1__tmp_at42_44843 - _diff_2__tmp_at42_44844;
        if ((object)((uintptr_t)_diff_inlined_diff_at_42_44842 +(uintptr_t) HIGH_BITS) >= 0){
            _diff_inlined_diff_at_42_44842 = NewDouble((eudouble)_diff_inlined_diff_at_42_44842);
        }
    }
    else {
        _diff_inlined_diff_at_42_44842 = binary_op(MINUS, _diff_1__tmp_at42_44843, _diff_2__tmp_at42_44844);
    }
    DeRef(_diff_1__tmp_at42_44843);
    _diff_1__tmp_at42_44843 = NOVALUE;
    DeRef(_diff_2__tmp_at42_44844);
    _diff_2__tmp_at42_44844 = NOVALUE;
    if (binary_op_a(GREATEREQ, _diff_inlined_diff_at_42_44842, 0LL)){
        goto L3; // [58] 69
    }

    /** c_decl.e:1292			return 1*/
    DeRefDS(_f1_44828);
    DeRefDS(_f2_44829);
    DeRef(_d1_44830);
    DeRef(_d2_44833);
    return 1LL;
L3: 

    /** c_decl.e:1295		return 0*/
    DeRefDS(_f1_44828);
    DeRefDS(_f2_44829);
    DeRef(_d1_44830);
    DeRef(_d2_44833);
    return 0LL;
    ;
}


void _57add_file(object _filename_44848, object _eu_filename_44849)
{
    object _obj_fname_44869 = NOVALUE;
    object _src_fname_44870 = NOVALUE;
    object _23388 = NOVALUE;
    object _23387 = NOVALUE;
    object _23374 = NOVALUE;
    object _23373 = NOVALUE;
    object _23370 = NOVALUE;
    object _23369 = NOVALUE;
    object _23368 = NOVALUE;
    object _23367 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1303		if equal("c", fileext(filename)) then*/
    RefDS(_filename_44848);
    _23367 = _15fileext(_filename_44848);
    if (_23366 == _23367)
    _23368 = 1;
    else if (IS_ATOM_INT(_23366) && IS_ATOM_INT(_23367))
    _23368 = 0;
    else
    _23368 = (compare(_23366, _23367) == 0);
    DeRef(_23367);
    _23367 = NOVALUE;
    if (_23368 == 0)
    {
        _23368 = NOVALUE;
        goto L1; // [15] 35
    }
    else{
        _23368 = NOVALUE;
    }

    /** c_decl.e:1304			filename = filename[1..$-2]*/
    if (IS_SEQUENCE(_filename_44848)){
            _23369 = SEQ_PTR(_filename_44848)->length;
    }
    else {
        _23369 = 1;
    }
    _23370 = _23369 - 2LL;
    _23369 = NOVALUE;
    rhs_slice_target = (object_ptr)&_filename_44848;
    RHS_Slice(_filename_44848, 1LL, _23370);
    goto L2; // [32] 82
L1: 

    /** c_decl.e:1305		elsif equal("h", fileext(filename)) then*/
    RefDS(_filename_44848);
    _23373 = _15fileext(_filename_44848);
    if (_23372 == _23373)
    _23374 = 1;
    else if (IS_ATOM_INT(_23372) && IS_ATOM_INT(_23373))
    _23374 = 0;
    else
    _23374 = (compare(_23372, _23373) == 0);
    DeRef(_23373);
    _23373 = NOVALUE;
    if (_23374 == 0)
    {
        _23374 = NOVALUE;
        goto L3; // [45] 81
    }
    else{
        _23374 = NOVALUE;
    }

    /** c_decl.e:1306			generated_files = append(generated_files, filename)*/
    RefDS(_filename_44848);
    Append(&_57generated_files_42967, _57generated_files_42967, _filename_44848);

    /** c_decl.e:1307			if build_system_type = BUILD_DIRECT then*/

    /** c_decl.e:1308				outdated_files  = append(outdated_files, 0)*/
    Append(&_57outdated_files_42968, _57outdated_files_42968, 0LL);

    /** c_decl.e:1311			return*/
    DeRefDS(_filename_44848);
    DeRefDS(_eu_filename_44849);
    DeRef(_obj_fname_44869);
    DeRef(_src_fname_44870);
    DeRef(_23370);
    _23370 = NOVALUE;
    return;
L3: 
L2: 

    /** c_decl.e:1314		sequence obj_fname = filename, src_fname = filename & ".c"*/
    RefDS(_filename_44848);
    DeRef(_obj_fname_44869);
    _obj_fname_44869 = _filename_44848;
    Concat((object_ptr)&_src_fname_44870, _filename_44848, _23337);

    /** c_decl.e:1316		if compiler_type = COMPILER_WATCOM then*/

    /** c_decl.e:1319			obj_fname &= ".o"*/
    Concat((object_ptr)&_obj_fname_44869, _obj_fname_44869, _23382);

    /** c_decl.e:1322		generated_files = append(generated_files, src_fname)*/
    RefDS(_src_fname_44870);
    Append(&_57generated_files_42967, _57generated_files_42967, _src_fname_44870);

    /** c_decl.e:1323		generated_files = append(generated_files, obj_fname)*/
    RefDS(_obj_fname_44869);
    Append(&_57generated_files_42967, _57generated_files_42967, _obj_fname_44869);

    /** c_decl.e:1324		if build_system_type = BUILD_DIRECT then*/

    /** c_decl.e:1325			outdated_files  = append(outdated_files, is_file_newer(eu_filename, output_dir & src_fname))*/
    Concat((object_ptr)&_23387, _57output_dir_42977, _src_fname_44870);
    RefDS(_eu_filename_44849);
    _23388 = _57is_file_newer(_eu_filename_44849, _23387);
    _23387 = NOVALUE;
    Ref(_23388);
    Append(&_57outdated_files_42968, _57outdated_files_42968, _23388);
    DeRef(_23388);
    _23388 = NOVALUE;

    /** c_decl.e:1326			outdated_files  = append(outdated_files, 0)*/
    Append(&_57outdated_files_42968, _57outdated_files_42968, 0LL);

    /** c_decl.e:1328	end procedure*/
    DeRefDS(_filename_44848);
    DeRefDS(_eu_filename_44849);
    DeRef(_obj_fname_44869);
    DeRef(_src_fname_44870);
    DeRef(_23370);
    _23370 = NOVALUE;
    return;
    ;
}


object _57any_code(object _file_no_44893)
{
    object _these_routines_44895 = NOVALUE;
    object _s_44902 = NOVALUE;
    object _23404 = NOVALUE;
    object _23403 = NOVALUE;
    object _23402 = NOVALUE;
    object _23401 = NOVALUE;
    object _23400 = NOVALUE;
    object _23399 = NOVALUE;
    object _23398 = NOVALUE;
    object _23397 = NOVALUE;
    object _23396 = NOVALUE;
    object _23395 = NOVALUE;
    object _23394 = NOVALUE;
    object _23392 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1334		check_file_routines()*/
    _57check_file_routines();

    /** c_decl.e:1336		sequence these_routines = file_routines[file_no]*/
    DeRef(_these_routines_44895);
    _2 = (object)SEQ_PTR(_57file_routines_45124);
    _these_routines_44895 = (object)*(((s1_ptr)_2)->base + _file_no_44893);
    Ref(_these_routines_44895);

    /** c_decl.e:1337		for i = 1 to length( these_routines ) do*/
    if (IS_SEQUENCE(_these_routines_44895)){
            _23392 = SEQ_PTR(_these_routines_44895)->length;
    }
    else {
        _23392 = 1;
    }
    {
        object _i_44899;
        _i_44899 = 1LL;
L1: 
        if (_i_44899 > _23392){
            goto L2; // [22] 126
        }

        /** c_decl.e:1338			symtab_index s = these_routines[i]*/
        _2 = (object)SEQ_PTR(_these_routines_44895);
        _s_44902 = (object)*(((s1_ptr)_2)->base + _i_44899);
        if (!IS_ATOM_INT(_s_44902)){
            _s_44902 = (object)DBL_PTR(_s_44902)->dbl;
        }

        /** c_decl.e:1339			if SymTab[s][S_FILE_NO] = file_no and*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _23394 = (object)*(((s1_ptr)_2)->base + _s_44902);
        _2 = (object)SEQ_PTR(_23394);
        if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
            _23395 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
        }
        else{
            _23395 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
        }
        _23394 = NOVALUE;
        if (IS_ATOM_INT(_23395)) {
            _23396 = (_23395 == _file_no_44893);
        }
        else {
            _23396 = binary_op(EQUALS, _23395, _file_no_44893);
        }
        _23395 = NOVALUE;
        if (IS_ATOM_INT(_23396)) {
            if (_23396 == 0) {
                DeRef(_23397);
                _23397 = 0;
                goto L3; // [55] 81
            }
        }
        else {
            if (DBL_PTR(_23396)->dbl == 0.0) {
                DeRef(_23397);
                _23397 = 0;
                goto L3; // [55] 81
            }
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _23398 = (object)*(((s1_ptr)_2)->base + _s_44902);
        _2 = (object)SEQ_PTR(_23398);
        _23399 = (object)*(((s1_ptr)_2)->base + 5LL);
        _23398 = NOVALUE;
        if (IS_ATOM_INT(_23399)) {
            _23400 = (_23399 != 99LL);
        }
        else {
            _23400 = binary_op(NOTEQ, _23399, 99LL);
        }
        _23399 = NOVALUE;
        DeRef(_23397);
        if (IS_ATOM_INT(_23400))
        _23397 = (_23400 != 0);
        else
        _23397 = DBL_PTR(_23400)->dbl != 0.0;
L3: 
        if (_23397 == 0) {
            goto L4; // [81] 117
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _23402 = (object)*(((s1_ptr)_2)->base + _s_44902);
        _2 = (object)SEQ_PTR(_23402);
        if (!IS_ATOM_INT(_27S_TOKEN_20214)){
            _23403 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
        }
        else{
            _23403 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
        }
        _23402 = NOVALUE;
        _23404 = find_from(_23403, _29RTN_TOKS_12277, 1LL);
        _23403 = NOVALUE;
        if (_23404 == 0)
        {
            _23404 = NOVALUE;
            goto L4; // [105] 117
        }
        else{
            _23404 = NOVALUE;
        }

        /** c_decl.e:1342				return TRUE -- found a non-deleted routine in this file*/
        DeRef(_these_routines_44895);
        DeRef(_23396);
        _23396 = NOVALUE;
        DeRef(_23400);
        _23400 = NOVALUE;
        return _9TRUE_441;
L4: 

        /** c_decl.e:1344		end for*/
        _i_44899 = _i_44899 + 1LL;
        goto L1; // [121] 29
L2: 
        ;
    }

    /** c_decl.e:1345		return FALSE*/
    DeRef(_these_routines_44895);
    DeRef(_23396);
    _23396 = NOVALUE;
    DeRef(_23400);
    _23400 = NOVALUE;
    return _9FALSE_439;
    ;
}


void _57check_file_routines()
{
    object _s_45133 = NOVALUE;
    object _23570 = NOVALUE;
    object _23569 = NOVALUE;
    object _23568 = NOVALUE;
    object _23567 = NOVALUE;
    object _23566 = NOVALUE;
    object _23565 = NOVALUE;
    object _23564 = NOVALUE;
    object _23563 = NOVALUE;
    object _23562 = NOVALUE;
    object _23561 = NOVALUE;
    object _23560 = NOVALUE;
    object _23559 = NOVALUE;
    object _23557 = NOVALUE;
    object _23555 = NOVALUE;
    object _23553 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1451		if not length( file_routines ) then*/
    if (IS_SEQUENCE(_57file_routines_45124)){
            _23553 = SEQ_PTR(_57file_routines_45124)->length;
    }
    else {
        _23553 = 1;
    }
    if (_23553 != 0)
    goto L1; // [8] 146
    _23553 = NOVALUE;

    /** c_decl.e:1452			file_routines = repeat( {}, length( known_files ) )*/
    if (IS_SEQUENCE(_28known_files_11573)){
            _23555 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _23555 = 1;
    }
    DeRefDS(_57file_routines_45124);
    _57file_routines_45124 = Repeat(_22218, _23555);
    _23555 = NOVALUE;

    /** c_decl.e:1453			integer s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23557 = (object)*(((s1_ptr)_2)->base + _27TopLevelSub_20578);
    _2 = (object)SEQ_PTR(_23557);
    _s_45133 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_45133)){
        _s_45133 = (object)DBL_PTR(_s_45133)->dbl;
    }
    _23557 = NOVALUE;

    /** c_decl.e:1454			while s do*/
L2: 
    if (_s_45133 == 0)
    {
        goto L3; // [45] 145
    }
    else{
    }

    /** c_decl.e:1455				if SymTab[s][S_USAGE] != U_DELETED and*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23559 = (object)*(((s1_ptr)_2)->base + _s_45133);
    _2 = (object)SEQ_PTR(_23559);
    _23560 = (object)*(((s1_ptr)_2)->base + 5LL);
    _23559 = NOVALUE;
    if (IS_ATOM_INT(_23560)) {
        _23561 = (_23560 != 99LL);
    }
    else {
        _23561 = binary_op(NOTEQ, _23560, 99LL);
    }
    _23560 = NOVALUE;
    if (IS_ATOM_INT(_23561)) {
        if (_23561 == 0) {
            goto L4; // [68] 124
        }
    }
    else {
        if (DBL_PTR(_23561)->dbl == 0.0) {
            goto L4; // [68] 124
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23563 = (object)*(((s1_ptr)_2)->base + _s_45133);
    _2 = (object)SEQ_PTR(_23563);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _23564 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _23564 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _23563 = NOVALUE;
    _23565 = find_from(_23564, _29RTN_TOKS_12277, 1LL);
    _23564 = NOVALUE;
    if (_23565 == 0)
    {
        _23565 = NOVALUE;
        goto L4; // [92] 124
    }
    else{
        _23565 = NOVALUE;
    }

    /** c_decl.e:1458					file_routines[SymTab[s][S_FILE_NO]] &= s*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23566 = (object)*(((s1_ptr)_2)->base + _s_45133);
    _2 = (object)SEQ_PTR(_23566);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _23567 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _23567 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _23566 = NOVALUE;
    _2 = (object)SEQ_PTR(_57file_routines_45124);
    if (!IS_ATOM_INT(_23567)){
        _23568 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_23567)->dbl));
    }
    else{
        _23568 = (object)*(((s1_ptr)_2)->base + _23567);
    }
    if (IS_SEQUENCE(_23568) && IS_ATOM(_s_45133)) {
        Append(&_23569, _23568, _s_45133);
    }
    else if (IS_ATOM(_23568) && IS_SEQUENCE(_s_45133)) {
    }
    else {
        Concat((object_ptr)&_23569, _23568, _s_45133);
        _23568 = NOVALUE;
    }
    _23568 = NOVALUE;
    _2 = (object)SEQ_PTR(_57file_routines_45124);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _57file_routines_45124 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_23567))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_23567)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _23567);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23569;
    if( _1 != _23569 ){
        DeRef(_1);
    }
    _23569 = NOVALUE;
L4: 

    /** c_decl.e:1460				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23570 = (object)*(((s1_ptr)_2)->base + _s_45133);
    _2 = (object)SEQ_PTR(_23570);
    _s_45133 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_45133)){
        _s_45133 = (object)DBL_PTR(_s_45133)->dbl;
    }
    _23570 = NOVALUE;

    /** c_decl.e:1461			end while*/
    goto L2; // [142] 45
L3: 
L1: 

    /** c_decl.e:1464	end procedure*/
    _23567 = NOVALUE;
    DeRef(_23561);
    _23561 = NOVALUE;
    return;
    ;
}


void _57GenerateUserRoutines()
{
    object _s_45167 = NOVALUE;
    object _sp_45168 = NOVALUE;
    object _next_c_char_45169 = NOVALUE;
    object _q_45170 = NOVALUE;
    object _temps_45171 = NOVALUE;
    object _buff_45172 = NOVALUE;
    object _base_name_45173 = NOVALUE;
    object _long_c_file_45174 = NOVALUE;
    object _c_file_45175 = NOVALUE;
    object _these_routines_45246 = NOVALUE;
    object _ret_type_45306 = NOVALUE;
    object _s_scope_45315 = NOVALUE;
    object _s_file_45318 = NOVALUE;
    object _scope_45395 = NOVALUE;
    object _names_45429 = NOVALUE;
    object _name_45439 = NOVALUE;
    object _23808 = NOVALUE;
    object _23806 = NOVALUE;
    object _23805 = NOVALUE;
    object _23804 = NOVALUE;
    object _23803 = NOVALUE;
    object _23802 = NOVALUE;
    object _23801 = NOVALUE;
    object _23799 = NOVALUE;
    object _23797 = NOVALUE;
    object _23796 = NOVALUE;
    object _23765 = NOVALUE;
    object _23764 = NOVALUE;
    object _23762 = NOVALUE;
    object _23760 = NOVALUE;
    object _23759 = NOVALUE;
    object _23758 = NOVALUE;
    object _23757 = NOVALUE;
    object _23756 = NOVALUE;
    object _23755 = NOVALUE;
    object _23754 = NOVALUE;
    object _23752 = NOVALUE;
    object _23751 = NOVALUE;
    object _23750 = NOVALUE;
    object _23749 = NOVALUE;
    object _23748 = NOVALUE;
    object _23747 = NOVALUE;
    object _23746 = NOVALUE;
    object _23745 = NOVALUE;
    object _23743 = NOVALUE;
    object _23742 = NOVALUE;
    object _23740 = NOVALUE;
    object _23739 = NOVALUE;
    object _23738 = NOVALUE;
    object _23737 = NOVALUE;
    object _23736 = NOVALUE;
    object _23735 = NOVALUE;
    object _23734 = NOVALUE;
    object _23733 = NOVALUE;
    object _23731 = NOVALUE;
    object _23730 = NOVALUE;
    object _23728 = NOVALUE;
    object _23727 = NOVALUE;
    object _23726 = NOVALUE;
    object _23724 = NOVALUE;
    object _23719 = NOVALUE;
    object _23718 = NOVALUE;
    object _23716 = NOVALUE;
    object _23714 = NOVALUE;
    object _23708 = NOVALUE;
    object _23707 = NOVALUE;
    object _23706 = NOVALUE;
    object _23705 = NOVALUE;
    object _23704 = NOVALUE;
    object _23703 = NOVALUE;
    object _23702 = NOVALUE;
    object _23701 = NOVALUE;
    object _23699 = NOVALUE;
    object _23698 = NOVALUE;
    object _23696 = NOVALUE;
    object _23695 = NOVALUE;
    object _23692 = NOVALUE;
    object _23690 = NOVALUE;
    object _23689 = NOVALUE;
    object _23688 = NOVALUE;
    object _23684 = NOVALUE;
    object _23681 = NOVALUE;
    object _23678 = NOVALUE;
    object _23677 = NOVALUE;
    object _23676 = NOVALUE;
    object _23675 = NOVALUE;
    object _23673 = NOVALUE;
    object _23672 = NOVALUE;
    object _23670 = NOVALUE;
    object _23669 = NOVALUE;
    object _23668 = NOVALUE;
    object _23666 = NOVALUE;
    object _23663 = NOVALUE;
    object _23662 = NOVALUE;
    object _23661 = NOVALUE;
    object _23660 = NOVALUE;
    object _23659 = NOVALUE;
    object _23658 = NOVALUE;
    object _23657 = NOVALUE;
    object _23656 = NOVALUE;
    object _23655 = NOVALUE;
    object _23654 = NOVALUE;
    object _23653 = NOVALUE;
    object _23652 = NOVALUE;
    object _23651 = NOVALUE;
    object _23650 = NOVALUE;
    object _23649 = NOVALUE;
    object _23647 = NOVALUE;
    object _23644 = NOVALUE;
    object _23643 = NOVALUE;
    object _23641 = NOVALUE;
    object _23638 = NOVALUE;
    object _23637 = NOVALUE;
    object _23633 = NOVALUE;
    object _23632 = NOVALUE;
    object _23629 = NOVALUE;
    object _23624 = NOVALUE;
    object _23623 = NOVALUE;
    object _23622 = NOVALUE;
    object _23621 = NOVALUE;
    object _23620 = NOVALUE;
    object _23619 = NOVALUE;
    object _23618 = NOVALUE;
    object _23617 = NOVALUE;
    object _23616 = NOVALUE;
    object _23615 = NOVALUE;
    object _23614 = NOVALUE;
    object _23613 = NOVALUE;
    object _23612 = NOVALUE;
    object _23611 = NOVALUE;
    object _23609 = NOVALUE;
    object _23608 = NOVALUE;
    object _23606 = NOVALUE;
    object _23603 = NOVALUE;
    object _23600 = NOVALUE;
    object _23597 = NOVALUE;
    object _23594 = NOVALUE;
    object _23593 = NOVALUE;
    object _23592 = NOVALUE;
    object _23589 = NOVALUE;
    object _23586 = NOVALUE;
    object _23584 = NOVALUE;
    object _23580 = NOVALUE;
    object _23579 = NOVALUE;
    object _23577 = NOVALUE;
    object _23576 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** c_decl.e:1468		integer next_c_char, q, temps*/

    /** c_decl.e:1469		sequence buff, base_name, long_c_file, c_file*/

    /** c_decl.e:1471		if not silent then*/
    if (_27silent_20687 != 0)
    goto L1; // [9] 68

    /** c_decl.e:1472			if Pass = 1 then*/
    if (_57Pass_42951 != 1LL)
    goto L2; // [16] 31

    /** c_decl.e:1473				ShowMsg(1, TRANSLATING_CODE_PASS,,0)*/
    RefDS(_22218);
    _30ShowMsg(1LL, 239LL, _22218, 0LL);
L2: 

    /** c_decl.e:1476			if LAST_PASS = TRUE then*/
    if (_57LAST_PASS_42949 != _9TRUE_441)
    goto L3; // [37] 54

    /** c_decl.e:1477				ShowMsg(1, MSG__GENERATING)*/
    RefDS(_22218);
    _30ShowMsg(1LL, 240LL, _22218, 1LL);
    goto L4; // [51] 67
L3: 

    /** c_decl.e:1479				ShowMsg(1, MSG_1, Pass, 0)*/
    _30ShowMsg(1LL, 241LL, _57Pass_42951, 0LL);
L4: 
L1: 

    /** c_decl.e:1483		check_file_routines()*/
    _57check_file_routines();

    /** c_decl.e:1485		c_puts("// GenerateUserRoutines\n")*/
    RefDS(_23575);
    _54c_puts(_23575);

    /** c_decl.e:1486		for file_no = 1 to length(known_files) do*/
    if (IS_SEQUENCE(_28known_files_11573)){
            _23576 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _23576 = 1;
    }
    {
        object _file_no_45194;
        _file_no_45194 = 1LL;
L5: 
        if (_file_no_45194 > _23576){
            goto L6; // [84] 2208
        }

        /** c_decl.e:1487			if file_no = 1 or any_code(file_no) then*/
        _23577 = (_file_no_45194 == 1LL);
        if (_23577 != 0) {
            goto L7; // [97] 110
        }
        _23579 = _57any_code(_file_no_45194);
        if (_23579 == 0) {
            DeRef(_23579);
            _23579 = NOVALUE;
            goto L8; // [106] 2199
        }
        else {
            if (!IS_ATOM_INT(_23579) && DBL_PTR(_23579)->dbl == 0.0){
                DeRef(_23579);
                _23579 = NOVALUE;
                goto L8; // [106] 2199
            }
            DeRef(_23579);
            _23579 = NOVALUE;
        }
        DeRef(_23579);
        _23579 = NOVALUE;
L7: 

        /** c_decl.e:1490				next_c_char = 1*/
        _next_c_char_45169 = 1LL;

        /** c_decl.e:1491				base_name = name_ext(known_files[file_no])*/
        _2 = (object)SEQ_PTR(_28known_files_11573);
        _23580 = (object)*(((s1_ptr)_2)->base + _file_no_45194);
        Ref(_23580);
        _0 = _base_name_45173;
        _base_name_45173 = _53name_ext(_23580);
        DeRef(_0);
        _23580 = NOVALUE;

        /** c_decl.e:1492				c_file = base_name*/
        RefDS(_base_name_45173);
        DeRef(_c_file_45175);
        _c_file_45175 = _base_name_45173;

        /** c_decl.e:1494				q = length(c_file)*/
        if (IS_SEQUENCE(_c_file_45175)){
                _q_45170 = SEQ_PTR(_c_file_45175)->length;
        }
        else {
            _q_45170 = 1;
        }

        /** c_decl.e:1495				while q >= 1 do*/
L9: 
        if (_q_45170 < 1LL)
        goto LA; // [146] 187

        /** c_decl.e:1496					if c_file[q] = '.' then*/
        _2 = (object)SEQ_PTR(_c_file_45175);
        _23584 = (object)*(((s1_ptr)_2)->base + _q_45170);
        if (binary_op_a(NOTEQ, _23584, 46LL)){
            _23584 = NOVALUE;
            goto LB; // [156] 176
        }
        _23584 = NOVALUE;

        /** c_decl.e:1497						c_file = c_file[1..q-1]*/
        _23586 = _q_45170 - 1LL;
        rhs_slice_target = (object_ptr)&_c_file_45175;
        RHS_Slice(_c_file_45175, 1LL, _23586);

        /** c_decl.e:1498						exit*/
        goto LA; // [173] 187
LB: 

        /** c_decl.e:1500					q -= 1*/
        _q_45170 = _q_45170 - 1LL;

        /** c_decl.e:1501				end while*/
        goto L9; // [184] 146
LA: 

        /** c_decl.e:1503				if find(lower(c_file), {"main-", "init-"})  then*/
        RefDS(_c_file_45175);
        _23589 = _12lower(_c_file_45175);
        RefDS(_23591);
        RefDS(_23590);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _23590;
        ((intptr_t *)_2)[2] = _23591;
        _23592 = MAKE_SEQ(_1);
        _23593 = find_from(_23589, _23592, 1LL);
        DeRef(_23589);
        _23589 = NOVALUE;
        DeRefDS(_23592);
        _23592 = NOVALUE;
        if (_23593 == 0)
        {
            _23593 = NOVALUE;
            goto LC; // [202] 219
        }
        else{
            _23593 = NOVALUE;
        }

        /** c_decl.e:1504					CompileErr(MSG_1_CONFLICTS_WITH_A_FILE_NAME_USED_INTERNALLY_BY_THE_TRANSLATOR, {base_name})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_base_name_45173);
        ((intptr_t*)_2)[1] = _base_name_45173;
        _23594 = MAKE_SEQ(_1);
        _49CompileErr(12LL, _23594, 0LL);
        _23594 = NOVALUE;
LC: 

        /** c_decl.e:1507				long_c_file = c_file*/
        RefDS(_c_file_45175);
        DeRef(_long_c_file_45174);
        _long_c_file_45174 = _c_file_45175;

        /** c_decl.e:1508				if LAST_PASS = TRUE then*/
        if (_57LAST_PASS_42949 != _9TRUE_441)
        goto LD; // [232] 257

        /** c_decl.e:1509					c_file = unique_c_name(c_file)*/
        RefDS(_c_file_45175);
        _0 = _c_file_45175;
        _c_file_45175 = _57unique_c_name(_c_file_45175);
        DeRefDS(_0);

        /** c_decl.e:1510					add_file(c_file, known_files[file_no])*/
        _2 = (object)SEQ_PTR(_28known_files_11573);
        _23597 = (object)*(((s1_ptr)_2)->base + _file_no_45194);
        RefDS(_c_file_45175);
        Ref(_23597);
        _57add_file(_c_file_45175, _23597);
        _23597 = NOVALUE;
LD: 

        /** c_decl.e:1513				if file_no = 1 then*/
        if (_file_no_45194 != 1LL)
        goto LE; // [259] 322

        /** c_decl.e:1515					if LAST_PASS = TRUE then*/
        if (_57LAST_PASS_42949 != _9TRUE_441)
        goto LF; // [269] 314

        /** c_decl.e:1516						add_file("main-")*/
        RefDS(_23590);
        RefDS(_22218);
        _57add_file(_23590, _22218);

        /** c_decl.e:1517						for i = 0 to main_name_num-1 do*/
        _23600 = _54main_name_num_47062 - 1LL;
        if ((object)((uintptr_t)_23600 +(uintptr_t) HIGH_BITS) >= 0){
            _23600 = NewDouble((eudouble)_23600);
        }
        {
            object _i_45236;
            _i_45236 = 0LL;
L10: 
            if (binary_op_a(GREATER, _i_45236, _23600)){
                goto L11; // [287] 313
            }

            /** c_decl.e:1518							buff = sprintf("main-%d", i)*/
            DeRefi(_buff_45172);
            _buff_45172 = EPrintf(-9999999, _23601, _i_45236);

            /** c_decl.e:1519							add_file(buff)*/
            RefDS(_buff_45172);
            RefDS(_22218);
            _57add_file(_buff_45172, _22218);

            /** c_decl.e:1520						end for*/
            _0 = _i_45236;
            if (IS_ATOM_INT(_i_45236)) {
                _i_45236 = _i_45236 + 1LL;
                if ((object)((uintptr_t)_i_45236 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_45236 = NewDouble((eudouble)_i_45236);
                }
            }
            else {
                _i_45236 = binary_op_a(PLUS, _i_45236, 1LL);
            }
            DeRef(_0);
            goto L10; // [308] 294
L11: 
            ;
            DeRef(_i_45236);
        }
LF: 

        /** c_decl.e:1523					file0 = long_c_file*/
        RefDS(_long_c_file_45174);
        DeRef(_57file0_44926);
        _57file0_44926 = _long_c_file_45174;
LE: 

        /** c_decl.e:1526				new_c_file(c_file)*/
        RefDS(_c_file_45175);
        _57new_c_file(_c_file_45175);

        /** c_decl.e:1528				s = SymTab[TopLevelSub][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _23603 = (object)*(((s1_ptr)_2)->base + _27TopLevelSub_20578);
        _2 = (object)SEQ_PTR(_23603);
        _s_45167 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_s_45167)){
            _s_45167 = (object)DBL_PTR(_s_45167)->dbl;
        }
        _23603 = NOVALUE;

        /** c_decl.e:1530				sequence these_routines = file_routines[file_no]*/
        DeRef(_these_routines_45246);
        _2 = (object)SEQ_PTR(_57file_routines_45124);
        _these_routines_45246 = (object)*(((s1_ptr)_2)->base + _file_no_45194);
        Ref(_these_routines_45246);

        /** c_decl.e:1531				for routine_no = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_45246)){
                _23606 = SEQ_PTR(_these_routines_45246)->length;
        }
        else {
            _23606 = 1;
        }
        {
            object _routine_no_45249;
            _routine_no_45249 = 1LL;
L12: 
            if (_routine_no_45249 > _23606){
                goto L13; // [360] 2198
            }

            /** c_decl.e:1532					s = these_routines[routine_no]*/
            _2 = (object)SEQ_PTR(_these_routines_45246);
            _s_45167 = (object)*(((s1_ptr)_2)->base + _routine_no_45249);
            if (!IS_ATOM_INT(_s_45167)){
                _s_45167 = (object)DBL_PTR(_s_45167)->dbl;
            }

            /** c_decl.e:1533					if SymTab[s][S_USAGE] != U_DELETED then*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23608 = (object)*(((s1_ptr)_2)->base + _s_45167);
            _2 = (object)SEQ_PTR(_23608);
            _23609 = (object)*(((s1_ptr)_2)->base + 5LL);
            _23608 = NOVALUE;
            if (binary_op_a(EQUALS, _23609, 99LL)){
                _23609 = NOVALUE;
                goto L14; // [391] 2189
            }
            _23609 = NOVALUE;

            /** c_decl.e:1537						if LAST_PASS = TRUE and*/
            _23611 = (_57LAST_PASS_42949 == _9TRUE_441);
            if (_23611 == 0) {
                goto L15; // [405] 601
            }
            _23613 = (_27cfile_size_20651 > 100000LL);
            if (_23613 != 0) {
                DeRef(_23614);
                _23614 = 1;
                goto L16; // [417] 480
            }
            _23615 = (_s_45167 != _27TopLevelSub_20578);
            if (_23615 == 0) {
                _23616 = 0;
                goto L17; // [427] 447
            }
            _23617 = (100000LL % 4LL) ? NewDouble((eudouble)100000LL / 4LL) : (100000LL / 4LL);
            if (IS_ATOM_INT(_23617)) {
                _23618 = (_27cfile_size_20651 > _23617);
            }
            else {
                _23618 = ((eudouble)_27cfile_size_20651 > DBL_PTR(_23617)->dbl);
            }
            DeRef(_23617);
            _23617 = NOVALUE;
            _23616 = (_23618 != 0);
L17: 
            if (_23616 == 0) {
                _23619 = 0;
                goto L18; // [447] 476
            }
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23620 = (object)*(((s1_ptr)_2)->base + _s_45167);
            _2 = (object)SEQ_PTR(_23620);
            if (!IS_ATOM_INT(_27S_CODE_20221)){
                _23621 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
            }
            else{
                _23621 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
            }
            _23620 = NOVALUE;
            if (IS_SEQUENCE(_23621)){
                    _23622 = SEQ_PTR(_23621)->length;
            }
            else {
                _23622 = 1;
            }
            _23621 = NOVALUE;
            _23623 = (_23622 > 100000LL);
            _23622 = NOVALUE;
            _23619 = (_23623 != 0);
L18: 
            DeRef(_23614);
            _23614 = (_23619 != 0);
L16: 
            if (_23614 == 0)
            {
                _23614 = NOVALUE;
                goto L15; // [481] 601
            }
            else{
                _23614 = NOVALUE;
            }

            /** c_decl.e:1546							if length(c_file) = 7 then*/
            if (IS_SEQUENCE(_c_file_45175)){
                    _23624 = SEQ_PTR(_c_file_45175)->length;
            }
            else {
                _23624 = 1;
            }
            if (_23624 != 7LL)
            goto L19; // [489] 500

            /** c_decl.e:1548								c_file &= " "*/
            Concat((object_ptr)&_c_file_45175, _c_file_45175, _23627);
L19: 

            /** c_decl.e:1551							if length(c_file) >= 8 then*/
            if (IS_SEQUENCE(_c_file_45175)){
                    _23629 = SEQ_PTR(_c_file_45175)->length;
            }
            else {
                _23629 = 1;
            }
            if (_23629 < 8LL)
            goto L1A; // [505] 528

            /** c_decl.e:1552								c_file[7] = '_'*/
            _2 = (object)SEQ_PTR(_c_file_45175);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _c_file_45175 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 7LL);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 95LL;
            DeRef(_1);

            /** c_decl.e:1553								c_file[8] = file_chars[next_c_char]*/
            _2 = (object)SEQ_PTR(_57file_chars_44791);
            _23632 = (object)*(((s1_ptr)_2)->base + _next_c_char_45169);
            Ref(_23632);
            _2 = (object)SEQ_PTR(_c_file_45175);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _c_file_45175 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 8LL);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _23632;
            if( _1 != _23632 ){
                DeRef(_1);
            }
            _23632 = NOVALUE;
            goto L1B; // [525] 560
L1A: 

            /** c_decl.e:1556								if find('_', c_file) = 0 then*/
            _23633 = find_from(95LL, _c_file_45175, 1LL);
            if (_23633 != 0LL)
            goto L1C; // [535] 546

            /** c_decl.e:1557									c_file &= "_ "*/
            Concat((object_ptr)&_c_file_45175, _c_file_45175, _23635);
L1C: 

            /** c_decl.e:1560								c_file[$] = file_chars[next_c_char]*/
            if (IS_SEQUENCE(_c_file_45175)){
                    _23637 = SEQ_PTR(_c_file_45175)->length;
            }
            else {
                _23637 = 1;
            }
            _2 = (object)SEQ_PTR(_57file_chars_44791);
            _23638 = (object)*(((s1_ptr)_2)->base + _next_c_char_45169);
            Ref(_23638);
            _2 = (object)SEQ_PTR(_c_file_45175);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _c_file_45175 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _23637);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _23638;
            if( _1 != _23638 ){
                DeRef(_1);
            }
            _23638 = NOVALUE;
L1B: 

            /** c_decl.e:1564							c_file = unique_c_name(c_file)*/
            RefDS(_c_file_45175);
            _0 = _c_file_45175;
            _c_file_45175 = _57unique_c_name(_c_file_45175);
            DeRefDS(_0);

            /** c_decl.e:1565							new_c_file(c_file)*/
            RefDS(_c_file_45175);
            _57new_c_file(_c_file_45175);

            /** c_decl.e:1567							next_c_char += 1*/
            _next_c_char_45169 = _next_c_char_45169 + 1;

            /** c_decl.e:1568							if next_c_char > length(file_chars) then*/
            if (IS_SEQUENCE(_57file_chars_44791)){
                    _23641 = SEQ_PTR(_57file_chars_44791)->length;
            }
            else {
                _23641 = 1;
            }
            if (_next_c_char_45169 <= _23641)
            goto L1D; // [584] 594

            /** c_decl.e:1569								next_c_char = 1  -- (unique_c_name will resolve)*/
            _next_c_char_45169 = 1LL;
L1D: 

            /** c_decl.e:1572							add_file(c_file)*/
            RefDS(_c_file_45175);
            RefDS(_22218);
            _57add_file(_c_file_45175, _22218);
L15: 

            /** c_decl.e:1575						sequence ret_type*/

            /** c_decl.e:1576						if SymTab[s][S_TOKEN] = PROC then*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23643 = (object)*(((s1_ptr)_2)->base + _s_45167);
            _2 = (object)SEQ_PTR(_23643);
            if (!IS_ATOM_INT(_27S_TOKEN_20214)){
                _23644 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
            }
            else{
                _23644 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
            }
            _23643 = NOVALUE;
            if (binary_op_a(NOTEQ, _23644, 27LL)){
                _23644 = NOVALUE;
                goto L1E; // [619] 633
            }
            _23644 = NOVALUE;

            /** c_decl.e:1577							ret_type = "void "*/
            RefDS(_23015);
            DeRefi(_ret_type_45306);
            _ret_type_45306 = _23015;
            goto L1F; // [630] 641
L1E: 

            /** c_decl.e:1579							ret_type = "object "*/
            RefDS(_23016);
            DeRefi(_ret_type_45306);
            _ret_type_45306 = _23016;
L1F: 

            /** c_decl.e:1581						integer s_scope = sym_scope( s )*/
            _s_scope_45315 = _53sym_scope(_s_45167);
            if (!IS_ATOM_INT(_s_scope_45315)) {
                _1 = (object)(DBL_PTR(_s_scope_45315)->dbl);
                DeRefDS(_s_scope_45315);
                _s_scope_45315 = _1;
            }

            /** c_decl.e:1582						integer s_file  = SymTab[s][S_FILE_NO]*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23647 = (object)*(((s1_ptr)_2)->base + _s_45167);
            _2 = (object)SEQ_PTR(_23647);
            if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
                _s_file_45318 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
            }
            else{
                _s_file_45318 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
            }
            if (!IS_ATOM_INT(_s_file_45318)){
                _s_file_45318 = (object)DBL_PTR(_s_file_45318)->dbl;
            }
            _23647 = NOVALUE;

            /** c_decl.e:1583						if dll_option and*/
            if (_57dll_option_42963 == 0) {
                goto L20; // [669] 827
            }
            _23650 = (_s_scope_45315 == 6LL);
            if (_23650 != 0) {
                DeRef(_23651);
                _23651 = 1;
                goto L21; // [679] 757
            }
            _23652 = (_s_file_45318 == 1LL);
            if (_23652 == 0) {
                _23653 = 0;
                goto L22; // [687] 715
            }
            _23654 = (_s_scope_45315 == 13LL);
            if (_23654 != 0) {
                _23655 = 1;
                goto L23; // [697] 711
            }
            _23656 = (_s_scope_45315 == 11LL);
            _23655 = (_23656 != 0);
L23: 
            _23653 = (_23655 != 0);
L22: 
            if (_23653 != 0) {
                _23657 = 1;
                goto L24; // [715] 753
            }
            _23658 = (_s_scope_45315 == 13LL);
            if (_23658 == 0) {
                _23659 = 0;
                goto L25; // [725] 749
            }
            _2 = (object)SEQ_PTR(_28include_matrix_11579);
            _23660 = (object)*(((s1_ptr)_2)->base + 1LL);
            _2 = (object)SEQ_PTR(_23660);
            _23661 = (object)*(((s1_ptr)_2)->base + _s_file_45318);
            _23660 = NOVALUE;
            if (IS_ATOM_INT(_23661)) {
                {uintptr_t tu;
                     tu = (uintptr_t)_23661 & (uintptr_t)4LL;
                     _23662 = MAKE_UINT(tu);
                }
            }
            else {
                _23662 = binary_op(AND_BITS, _23661, 4LL);
            }
            _23661 = NOVALUE;
            if (IS_ATOM_INT(_23662))
            _23659 = (_23662 != 0);
            else
            _23659 = DBL_PTR(_23662)->dbl != 0.0;
L25: 
            _23657 = (_23659 != 0);
L24: 
            DeRef(_23651);
            _23651 = (_23657 != 0);
L21: 
            if (_23651 == 0)
            {
                _23651 = NOVALUE;
                goto L20; // [758] 827
            }
            else{
                _23651 = NOVALUE;
            }

            /** c_decl.e:1589							SymTab[s][S_RI_TARGET] = TRUE*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _28SymTab_11572 = MAKE_SEQ(_2);
            }
            _3 = (object)(_s_45167 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 53LL);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _9TRUE_441;
            DeRef(_1);
            _23663 = NOVALUE;

            /** c_decl.e:1590							LeftSym = TRUE*/
            _57LeftSym_42960 = _9TRUE_441;

            /** c_decl.e:1593							if TWINDOWS then*/
            if (_44TWINDOWS_20715 == 0)
            {
                goto L26; // [791] 810
            }
            else{
            }

            /** c_decl.e:1594								c_stmt(ret_type & " __stdcall @(", s)*/
            Concat((object_ptr)&_23666, _ret_type_45306, _23665);
            _57c_stmt(_23666, _s_45167, 0LL);
            _23666 = NOVALUE;
            goto L27; // [807] 850
L26: 

            /** c_decl.e:1596								c_stmt(ret_type & "@(", s)*/
            Concat((object_ptr)&_23668, _ret_type_45306, _23667);
            _57c_stmt(_23668, _s_45167, 0LL);
            _23668 = NOVALUE;
            goto L27; // [824] 850
L20: 

            /** c_decl.e:1600							LeftSym = TRUE*/
            _57LeftSym_42960 = _9TRUE_441;

            /** c_decl.e:1601							c_stmt( ret_type & "@(", s)*/
            Concat((object_ptr)&_23669, _ret_type_45306, _23667);
            _57c_stmt(_23669, _s_45167, 0LL);
            _23669 = NOVALUE;
L27: 

            /** c_decl.e:1605						sp = SymTab[s][S_NEXT]*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23670 = (object)*(((s1_ptr)_2)->base + _s_45167);
            _2 = (object)SEQ_PTR(_23670);
            _sp_45168 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_sp_45168)){
                _sp_45168 = (object)DBL_PTR(_sp_45168)->dbl;
            }
            _23670 = NOVALUE;

            /** c_decl.e:1606						for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23672 = (object)*(((s1_ptr)_2)->base + _s_45167);
            _2 = (object)SEQ_PTR(_23672);
            if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
                _23673 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
            }
            else{
                _23673 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
            }
            _23672 = NOVALUE;
            {
                object _p_45365;
                _p_45365 = 1LL;
L28: 
                if (binary_op_a(GREATER, _p_45365, _23673)){
                    goto L29; // [880] 956
                }

                /** c_decl.e:1607							c_puts("object _")*/
                RefDS(_23674);
                _54c_puts(_23674);

                /** c_decl.e:1608							c_puts(SymTab[sp][S_NAME])*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23675 = (object)*(((s1_ptr)_2)->base + _sp_45168);
                _2 = (object)SEQ_PTR(_23675);
                if (!IS_ATOM_INT(_27S_NAME_20209)){
                    _23676 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
                }
                else{
                    _23676 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
                }
                _23675 = NOVALUE;
                Ref(_23676);
                _54c_puts(_23676);
                _23676 = NOVALUE;

                /** c_decl.e:1609							if p != SymTab[s][S_NUM_ARGS] then*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23677 = (object)*(((s1_ptr)_2)->base + _s_45167);
                _2 = (object)SEQ_PTR(_23677);
                if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
                    _23678 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
                }
                else{
                    _23678 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
                }
                _23677 = NOVALUE;
                if (binary_op_a(EQUALS, _p_45365, _23678)){
                    _23678 = NOVALUE;
                    goto L2A; // [923] 933
                }
                _23678 = NOVALUE;

                /** c_decl.e:1610								c_puts(", ")*/
                RefDS(_23680);
                _54c_puts(_23680);
L2A: 

                /** c_decl.e:1612							sp = SymTab[sp][S_NEXT]*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23681 = (object)*(((s1_ptr)_2)->base + _sp_45168);
                _2 = (object)SEQ_PTR(_23681);
                _sp_45168 = (object)*(((s1_ptr)_2)->base + 2LL);
                if (!IS_ATOM_INT(_sp_45168)){
                    _sp_45168 = (object)DBL_PTR(_sp_45168)->dbl;
                }
                _23681 = NOVALUE;

                /** c_decl.e:1613						end for*/
                _0 = _p_45365;
                if (IS_ATOM_INT(_p_45365)) {
                    _p_45365 = _p_45365 + 1LL;
                    if ((object)((uintptr_t)_p_45365 +(uintptr_t) HIGH_BITS) >= 0){
                        _p_45365 = NewDouble((eudouble)_p_45365);
                    }
                }
                else {
                    _p_45365 = binary_op_a(PLUS, _p_45365, 1LL);
                }
                DeRef(_0);
                goto L28; // [951] 887
L29: 
                ;
                DeRef(_p_45365);
            }

            /** c_decl.e:1615						c_puts(")\n")*/
            RefDS(_23683);
            _54c_puts(_23683);

            /** c_decl.e:1616						c_stmt0("{\n")*/
            RefDS(_22331);
            _57c_stmt0(_22331);

            /** c_decl.e:1618						NewBB(0, E_ALL_EFFECT, 0)*/
            _57NewBB(0LL, 1073741823LL, 0LL);

            /** c_decl.e:1619						Initializing = TRUE*/
            _27Initializing_20652 = _9TRUE_441;

            /** c_decl.e:1622						while sp do*/
L2B: 
            if (_sp_45168 == 0)
            {
                goto L2C; // [989] 1128
            }
            else{
            }

            /** c_decl.e:1623							integer scope = SymTab[sp][S_SCOPE]*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23684 = (object)*(((s1_ptr)_2)->base + _sp_45168);
            _2 = (object)SEQ_PTR(_23684);
            _scope_45395 = (object)*(((s1_ptr)_2)->base + 4LL);
            if (!IS_ATOM_INT(_scope_45395)){
                _scope_45395 = (object)DBL_PTR(_scope_45395)->dbl;
            }
            _23684 = NOVALUE;

            /** c_decl.e:1624							switch scope with fallthru do*/
            _0 = _scope_45395;
            switch ( _0 ){ 

                /** c_decl.e:1625								case SC_LOOP_VAR, SC_UNDEFINED then*/
                case 2:
                case 9:

                /** c_decl.e:1628									break*/
                goto L2D; // [1023] 1105

                /** c_decl.e:1630								case SC_PRIVATE then*/
                case 3:

                /** c_decl.e:1631									c_stmt0("object ")*/
                RefDS(_23016);
                _57c_stmt0(_23016);

                /** c_decl.e:1632									c_puts("_")*/
                RefDS(_22299);
                _54c_puts(_22299);

                /** c_decl.e:1633									c_puts(SymTab[sp][S_NAME])*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23688 = (object)*(((s1_ptr)_2)->base + _sp_45168);
                _2 = (object)SEQ_PTR(_23688);
                if (!IS_ATOM_INT(_27S_NAME_20209)){
                    _23689 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
                }
                else{
                    _23689 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
                }
                _23688 = NOVALUE;
                Ref(_23689);
                _54c_puts(_23689);
                _23689 = NOVALUE;

                /** c_decl.e:1635									c_puts(" = NOVALUE;\n")*/
                RefDS(_23024);
                _54c_puts(_23024);

                /** c_decl.e:1636									target[MIN] = NOVALUE*/
                Ref(_27NOVALUE_20426);
                _2 = (object)SEQ_PTR(_58target_28771);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _58target_28771 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 1LL);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _27NOVALUE_20426;
                DeRef(_1);

                /** c_decl.e:1637									target[MAX] = NOVALUE*/
                Ref(_27NOVALUE_20426);
                _2 = (object)SEQ_PTR(_58target_28771);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _58target_28771 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 2LL);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _27NOVALUE_20426;
                DeRef(_1);

                /** c_decl.e:1638									RemoveFromBB( sp )*/
                _57RemoveFromBB(_sp_45168);

                /** c_decl.e:1640									break*/
                goto L2D; // [1092] 1105

                /** c_decl.e:1642								case else*/
                default:

                /** c_decl.e:1643									exit*/
                goto L2C; // [1102] 1128
            ;}L2D: 

            /** c_decl.e:1645							sp = SymTab[sp][S_NEXT]*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23690 = (object)*(((s1_ptr)_2)->base + _sp_45168);
            _2 = (object)SEQ_PTR(_23690);
            _sp_45168 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_sp_45168)){
                _sp_45168 = (object)DBL_PTR(_sp_45168)->dbl;
            }
            _23690 = NOVALUE;

            /** c_decl.e:1646						end while*/
            goto L2B; // [1125] 989
L2C: 

            /** c_decl.e:1649						temps = SymTab[s][S_TEMPS]*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23692 = (object)*(((s1_ptr)_2)->base + _s_45167);
            _2 = (object)SEQ_PTR(_23692);
            if (!IS_ATOM_INT(_27S_TEMPS_20254)){
                _temps_45171 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TEMPS_20254)->dbl));
            }
            else{
                _temps_45171 = (object)*(((s1_ptr)_2)->base + _27S_TEMPS_20254);
            }
            if (!IS_ATOM_INT(_temps_45171)){
                _temps_45171 = (object)DBL_PTR(_temps_45171)->dbl;
            }
            _23692 = NOVALUE;

            /** c_decl.e:1650						sequence names = {}*/
            RefDS(_22218);
            DeRef(_names_45429);
            _names_45429 = _22218;

            /** c_decl.e:1651						while temps != 0 do*/
L2E: 
            if (_temps_45171 == 0LL)
            goto L2F; // [1156] 1348

            /** c_decl.e:1652							if SymTab[temps][S_SCOPE] != DELETED then*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23695 = (object)*(((s1_ptr)_2)->base + _temps_45171);
            _2 = (object)SEQ_PTR(_23695);
            _23696 = (object)*(((s1_ptr)_2)->base + 4LL);
            _23695 = NOVALUE;
            if (binary_op_a(EQUALS, _23696, 2LL)){
                _23696 = NOVALUE;
                goto L30; // [1176] 1308
            }
            _23696 = NOVALUE;

            /** c_decl.e:1653								sequence name = sprintf("_%d", SymTab[temps][S_TEMP_NAME] )*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23698 = (object)*(((s1_ptr)_2)->base + _temps_45171);
            _2 = (object)SEQ_PTR(_23698);
            _23699 = (object)*(((s1_ptr)_2)->base + 34LL);
            _23698 = NOVALUE;
            DeRefi(_name_45439);
            _name_45439 = EPrintf(-9999999, _22350, _23699);
            _23699 = NOVALUE;

            /** c_decl.e:1654								if temp_name_type[SymTab[temps][S_TEMP_NAME]][T_GTYPE]*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23701 = (object)*(((s1_ptr)_2)->base + _temps_45171);
            _2 = (object)SEQ_PTR(_23701);
            _23702 = (object)*(((s1_ptr)_2)->base + 34LL);
            _23701 = NOVALUE;
            _2 = (object)SEQ_PTR(_27temp_name_type_20654);
            if (!IS_ATOM_INT(_23702)){
                _23703 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_23702)->dbl));
            }
            else{
                _23703 = (object)*(((s1_ptr)_2)->base + _23702);
            }
            _2 = (object)SEQ_PTR(_23703);
            _23704 = (object)*(((s1_ptr)_2)->base + 1LL);
            _23703 = NOVALUE;
            if (IS_ATOM_INT(_23704)) {
                _23705 = (_23704 != 0LL);
            }
            else {
                _23705 = binary_op(NOTEQ, _23704, 0LL);
            }
            _23704 = NOVALUE;
            if (IS_ATOM_INT(_23705)) {
                if (_23705 == 0) {
                    goto L31; // [1230] 1304
                }
            }
            else {
                if (DBL_PTR(_23705)->dbl == 0.0) {
                    goto L31; // [1230] 1304
                }
            }
            _23707 = find_from(_name_45439, _names_45429, 1LL);
            _23708 = (_23707 == 0);
            _23707 = NOVALUE;
            if (_23708 == 0)
            {
                DeRef(_23708);
                _23708 = NOVALUE;
                goto L31; // [1243] 1304
            }
            else{
                DeRef(_23708);
                _23708 = NOVALUE;
            }

            /** c_decl.e:1657									c_stmt0("object ")*/
            RefDS(_23016);
            _57c_stmt0(_23016);

            /** c_decl.e:1658									c_puts( name )*/
            RefDS(_name_45439);
            _54c_puts(_name_45439);

            /** c_decl.e:1659									c_puts(" = NOVALUE")*/
            RefDS(_23709);
            _54c_puts(_23709);

            /** c_decl.e:1661									target = {NOVALUE, NOVALUE}*/
            Ref(_27NOVALUE_20426);
            Ref(_27NOVALUE_20426);
            DeRef(_58target_28771);
            _1 = NewS1(2);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t *)_2)[1] = _27NOVALUE_20426;
            ((intptr_t *)_2)[2] = _27NOVALUE_20426;
            _58target_28771 = MAKE_SEQ(_1);

            /** c_decl.e:1663									SetBBType(temps, TYPE_INTEGER, target, TYPE_OBJECT, 0)*/
            RefDS(_58target_28771);
            _57SetBBType(_temps_45171, 1LL, _58target_28771, 16LL, 0LL);

            /** c_decl.e:1664									ifdef DEBUG then*/

            /** c_decl.e:1667										c_puts(";\n")*/
            RefDS(_22506);
            _54c_puts(_22506);

            /** c_decl.e:1669									names = prepend( names, name )*/
            RefDS(_name_45439);
            Prepend(&_names_45429, _names_45429, _name_45439);
            goto L32; // [1301] 1307
L31: 

            /** c_decl.e:1671									ifdef DEBUG then*/
L32: 
L30: 
            DeRefi(_name_45439);
            _name_45439 = NOVALUE;

            /** c_decl.e:1677							SymTab[temps][S_GTYPE] = TYPE_OBJECT*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _28SymTab_11572 = MAKE_SEQ(_2);
            }
            _3 = (object)(_temps_45171 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 36LL);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 16LL;
            DeRef(_1);
            _23714 = NOVALUE;

            /** c_decl.e:1678							temps = SymTab[temps][S_NEXT]*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23716 = (object)*(((s1_ptr)_2)->base + _temps_45171);
            _2 = (object)SEQ_PTR(_23716);
            _temps_45171 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_temps_45171)){
                _temps_45171 = (object)DBL_PTR(_temps_45171)->dbl;
            }
            _23716 = NOVALUE;

            /** c_decl.e:1679						end while*/
            goto L2E; // [1345] 1156
L2F: 

            /** c_decl.e:1680						Initializing = FALSE*/
            _27Initializing_20652 = _9FALSE_439;

            /** c_decl.e:1682						if SymTab[s][S_LHS_SUBS2] then*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23718 = (object)*(((s1_ptr)_2)->base + _s_45167);
            _2 = (object)SEQ_PTR(_23718);
            _23719 = (object)*(((s1_ptr)_2)->base + 37LL);
            _23718 = NOVALUE;
            if (_23719 == 0) {
                _23719 = NOVALUE;
                goto L33; // [1371] 1384
            }
            else {
                if (!IS_ATOM_INT(_23719) && DBL_PTR(_23719)->dbl == 0.0){
                    _23719 = NOVALUE;
                    goto L33; // [1371] 1384
                }
                _23719 = NOVALUE;
            }
            _23719 = NOVALUE;

            /** c_decl.e:1683							c_stmt0("object _0, _1, _2, _3;\n\n")*/
            RefDS(_23720);
            _57c_stmt0(_23720);

            /** c_decl.e:1684							ifdef DEBUG then*/
            goto L34; // [1381] 1392
L33: 

            /** c_decl.e:1688							c_stmt0("object _0, _1, _2;\n\n")*/
            RefDS(_23722);
            _57c_stmt0(_23722);

            /** c_decl.e:1689							ifdef DEBUG then*/
L34: 

            /** c_decl.e:1696						sp = SymTab[s][S_NEXT]*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23724 = (object)*(((s1_ptr)_2)->base + _s_45167);
            _2 = (object)SEQ_PTR(_23724);
            _sp_45168 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_sp_45168)){
                _sp_45168 = (object)DBL_PTR(_sp_45168)->dbl;
            }
            _23724 = NOVALUE;

            /** c_decl.e:1697						for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23726 = (object)*(((s1_ptr)_2)->base + _s_45167);
            _2 = (object)SEQ_PTR(_23726);
            if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
                _23727 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
            }
            else{
                _23727 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
            }
            _23726 = NOVALUE;
            {
                object _p_45500;
                _p_45500 = 1LL;
L35: 
                if (binary_op_a(GREATER, _p_45500, _23727)){
                    goto L36; // [1422] 1773
                }

                /** c_decl.e:1698							SymTab[sp][S_ONE_REF] = FALSE*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _28SymTab_11572 = MAKE_SEQ(_2);
                }
                _3 = (object)(_sp_45168 + ((s1_ptr)_2)->base);
                _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    *(intptr_t *)_3 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 35LL);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _9FALSE_439;
                DeRef(_1);
                _23728 = NOVALUE;

                /** c_decl.e:1699							if SymTab[sp][S_ARG_TYPE] = TYPE_SEQUENCE then*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23730 = (object)*(((s1_ptr)_2)->base + _sp_45168);
                _2 = (object)SEQ_PTR(_23730);
                _23731 = (object)*(((s1_ptr)_2)->base + 43LL);
                _23730 = NOVALUE;
                if (binary_op_a(NOTEQ, _23731, 8LL)){
                    _23731 = NOVALUE;
                    goto L37; // [1462] 1526
                }
                _23731 = NOVALUE;

                /** c_decl.e:1700								target[MIN] = SymTab[sp][S_ARG_SEQ_LEN]*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23733 = (object)*(((s1_ptr)_2)->base + _sp_45168);
                _2 = (object)SEQ_PTR(_23733);
                _23734 = (object)*(((s1_ptr)_2)->base + 51LL);
                _23733 = NOVALUE;
                Ref(_23734);
                _2 = (object)SEQ_PTR(_58target_28771);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _58target_28771 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 1LL);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _23734;
                if( _1 != _23734 ){
                    DeRef(_1);
                }
                _23734 = NOVALUE;

                /** c_decl.e:1701								SetBBType(sp, SymTab[sp][S_ARG_TYPE], target,*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23735 = (object)*(((s1_ptr)_2)->base + _sp_45168);
                _2 = (object)SEQ_PTR(_23735);
                _23736 = (object)*(((s1_ptr)_2)->base + 43LL);
                _23735 = NOVALUE;
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23737 = (object)*(((s1_ptr)_2)->base + _sp_45168);
                _2 = (object)SEQ_PTR(_23737);
                _23738 = (object)*(((s1_ptr)_2)->base + 45LL);
                _23737 = NOVALUE;
                Ref(_23736);
                RefDS(_58target_28771);
                Ref(_23738);
                _57SetBBType(_sp_45168, _23736, _58target_28771, _23738, 0LL);
                _23736 = NOVALUE;
                _23738 = NOVALUE;
                goto L38; // [1523] 1750
L37: 

                /** c_decl.e:1704							elsif SymTab[sp][S_ARG_TYPE] = TYPE_INTEGER then*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23739 = (object)*(((s1_ptr)_2)->base + _sp_45168);
                _2 = (object)SEQ_PTR(_23739);
                _23740 = (object)*(((s1_ptr)_2)->base + 43LL);
                _23739 = NOVALUE;
                if (binary_op_a(NOTEQ, _23740, 1LL)){
                    _23740 = NOVALUE;
                    goto L39; // [1542] 1666
                }
                _23740 = NOVALUE;

                /** c_decl.e:1705								if SymTab[sp][S_ARG_MIN] = NOVALUE then*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23742 = (object)*(((s1_ptr)_2)->base + _sp_45168);
                _2 = (object)SEQ_PTR(_23742);
                _23743 = (object)*(((s1_ptr)_2)->base + 47LL);
                _23742 = NOVALUE;
                if (binary_op_a(NOTEQ, _23743, _27NOVALUE_20426)){
                    _23743 = NOVALUE;
                    goto L3A; // [1562] 1593
                }
                _23743 = NOVALUE;

                /** c_decl.e:1706									target[MIN] = MININT*/
                Ref(_27MININT_20396);
                _2 = (object)SEQ_PTR(_58target_28771);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _58target_28771 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 1LL);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _27MININT_20396;
                DeRef(_1);

                /** c_decl.e:1707									target[MAX] = MAXINT*/
                Ref(_27MAXINT_20395);
                _2 = (object)SEQ_PTR(_58target_28771);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _58target_28771 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 2LL);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _27MAXINT_20395;
                DeRef(_1);
                goto L3B; // [1590] 1638
L3A: 

                /** c_decl.e:1709									target[MIN] = SymTab[sp][S_ARG_MIN]*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23745 = (object)*(((s1_ptr)_2)->base + _sp_45168);
                _2 = (object)SEQ_PTR(_23745);
                _23746 = (object)*(((s1_ptr)_2)->base + 47LL);
                _23745 = NOVALUE;
                Ref(_23746);
                _2 = (object)SEQ_PTR(_58target_28771);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _58target_28771 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 1LL);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _23746;
                if( _1 != _23746 ){
                    DeRef(_1);
                }
                _23746 = NOVALUE;

                /** c_decl.e:1710									target[MAX] = SymTab[sp][S_ARG_MAX]*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23747 = (object)*(((s1_ptr)_2)->base + _sp_45168);
                _2 = (object)SEQ_PTR(_23747);
                _23748 = (object)*(((s1_ptr)_2)->base + 48LL);
                _23747 = NOVALUE;
                Ref(_23748);
                _2 = (object)SEQ_PTR(_58target_28771);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _58target_28771 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 2LL);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _23748;
                if( _1 != _23748 ){
                    DeRef(_1);
                }
                _23748 = NOVALUE;
L3B: 

                /** c_decl.e:1712								SetBBType(sp, SymTab[sp][S_ARG_TYPE], target, TYPE_OBJECT, 0)*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23749 = (object)*(((s1_ptr)_2)->base + _sp_45168);
                _2 = (object)SEQ_PTR(_23749);
                _23750 = (object)*(((s1_ptr)_2)->base + 43LL);
                _23749 = NOVALUE;
                Ref(_23750);
                RefDS(_58target_28771);
                _57SetBBType(_sp_45168, _23750, _58target_28771, 16LL, 0LL);
                _23750 = NOVALUE;
                goto L38; // [1663] 1750
L39: 

                /** c_decl.e:1714							elsif SymTab[sp][S_ARG_TYPE] = TYPE_OBJECT then*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23751 = (object)*(((s1_ptr)_2)->base + _sp_45168);
                _2 = (object)SEQ_PTR(_23751);
                _23752 = (object)*(((s1_ptr)_2)->base + 43LL);
                _23751 = NOVALUE;
                if (binary_op_a(NOTEQ, _23752, 16LL)){
                    _23752 = NOVALUE;
                    goto L3C; // [1682] 1724
                }
                _23752 = NOVALUE;

                /** c_decl.e:1716								SetBBType(sp, SymTab[sp][S_ARG_TYPE], novalue,*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23754 = (object)*(((s1_ptr)_2)->base + _sp_45168);
                _2 = (object)SEQ_PTR(_23754);
                _23755 = (object)*(((s1_ptr)_2)->base + 43LL);
                _23754 = NOVALUE;
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23756 = (object)*(((s1_ptr)_2)->base + _sp_45168);
                _2 = (object)SEQ_PTR(_23756);
                _23757 = (object)*(((s1_ptr)_2)->base + 45LL);
                _23756 = NOVALUE;
                Ref(_23755);
                RefDS(_54novalue_47064);
                Ref(_23757);
                _57SetBBType(_sp_45168, _23755, _54novalue_47064, _23757, 0LL);
                _23755 = NOVALUE;
                _23757 = NOVALUE;
                goto L38; // [1721] 1750
L3C: 

                /** c_decl.e:1720								SetBBType(sp, SymTab[sp][S_ARG_TYPE], novalue, TYPE_OBJECT, 0)*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23758 = (object)*(((s1_ptr)_2)->base + _sp_45168);
                _2 = (object)SEQ_PTR(_23758);
                _23759 = (object)*(((s1_ptr)_2)->base + 43LL);
                _23758 = NOVALUE;
                Ref(_23759);
                RefDS(_54novalue_47064);
                _57SetBBType(_sp_45168, _23759, _54novalue_47064, 16LL, 0LL);
                _23759 = NOVALUE;
L38: 

                /** c_decl.e:1723							sp = SymTab[sp][S_NEXT]*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23760 = (object)*(((s1_ptr)_2)->base + _sp_45168);
                _2 = (object)SEQ_PTR(_23760);
                _sp_45168 = (object)*(((s1_ptr)_2)->base + 2LL);
                if (!IS_ATOM_INT(_sp_45168)){
                    _sp_45168 = (object)DBL_PTR(_sp_45168)->dbl;
                }
                _23760 = NOVALUE;

                /** c_decl.e:1724						end for*/
                _0 = _p_45500;
                if (IS_ATOM_INT(_p_45500)) {
                    _p_45500 = _p_45500 + 1LL;
                    if ((object)((uintptr_t)_p_45500 +(uintptr_t) HIGH_BITS) >= 0){
                        _p_45500 = NewDouble((eudouble)_p_45500);
                    }
                }
                else {
                    _p_45500 = binary_op_a(PLUS, _p_45500, 1LL);
                }
                DeRef(_0);
                goto L35; // [1768] 1429
L36: 
                ;
                DeRef(_p_45500);
            }

            /** c_decl.e:1727						call_proc(Execute_id, {s})*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t*)_2)[1] = _s_45167;
            _23762 = MAKE_SEQ(_1);
            _1 = (object)SEQ_PTR(_23762);
            _2 = (object)((s1_ptr)_1)->base;
            _0 = (object)_00[_27Execute_id_20659].addr;
            Ref( *(( (intptr_t*)_2) + 1) );
            (*(intptr_t (*)())_0)(
                                *( ((intptr_t *)_2) + 1)
                                 );
            DeRefDS(_23762);
            _23762 = NOVALUE;

            /** c_decl.e:1729						c_puts("    ;\n}\n")*/
            RefDS(_23763);
            _54c_puts(_23763);

            /** c_decl.e:1730						if dll_option and is_exported( s ) then*/
            if (_57dll_option_42963 == 0) {
                goto L3D; // [1793] 2183
            }
            _23765 = _57is_exported(_s_45167);
            if (_23765 == 0) {
                DeRef(_23765);
                _23765 = NOVALUE;
                goto L3D; // [1802] 2183
            }
            else {
                if (!IS_ATOM_INT(_23765) && DBL_PTR(_23765)->dbl == 0.0){
                    DeRef(_23765);
                    _23765 = NOVALUE;
                    goto L3D; // [1802] 2183
                }
                DeRef(_23765);
                _23765 = NOVALUE;
            }
            DeRef(_23765);
            _23765 = NOVALUE;

            /** c_decl.e:1732							LeftSym = TRUE*/
            _57LeftSym_42960 = _9TRUE_441;

            /** c_decl.e:1733							if TOSX then*/

            /** c_decl.e:1762							elsif TWINDOWS then*/
            if (_44TWINDOWS_20715 == 0)
            {
                goto L3E; // [2082] 2145
            }
            else{
            }

            /** c_decl.e:1766								c_stmt0( ret_type & SymTab[s][S_NAME] & "() __attribute__ ((alias (\"" )*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23796 = (object)*(((s1_ptr)_2)->base + _s_45167);
            _2 = (object)SEQ_PTR(_23796);
            if (!IS_ATOM_INT(_27S_NAME_20209)){
                _23797 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
            }
            else{
                _23797 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
            }
            _23796 = NOVALUE;
            {
                object concat_list[3];

                concat_list[0] = _23798;
                concat_list[1] = _23797;
                concat_list[2] = _ret_type_45306;
                Concat_N((object_ptr)&_23799, concat_list, 3);
            }
            _23797 = NOVALUE;
            _57c_stmt0(_23799);
            _23799 = NOVALUE;

            /** c_decl.e:1767								CName( s )*/
            _57CName(_s_45167);

            /** c_decl.e:1768								c_puts( sprintf( "@%d\")));\n", SymTab[s][S_NUM_ARGS] * TARGET_SIZEOF_POINTER ) )*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23801 = (object)*(((s1_ptr)_2)->base + _s_45167);
            _2 = (object)SEQ_PTR(_23801);
            if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
                _23802 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
            }
            else{
                _23802 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
            }
            _23801 = NOVALUE;
            if (IS_ATOM_INT(_23802)) {
                {
                    int128_t p128 = (int128_t)_23802 * (int128_t)8LL;
                    if( p128 != (int128_t)(_23803 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                        _23803 = NewDouble( (eudouble)p128 );
                    }
                }
            }
            else {
                _23803 = binary_op(MULTIPLY, _23802, 8LL);
            }
            _23802 = NOVALUE;
            _23804 = EPrintf(-9999999, _23800, _23803);
            DeRef(_23803);
            _23803 = NOVALUE;
            _54c_puts(_23804);
            _23804 = NOVALUE;
            goto L3F; // [2142] 2173
L3E: 

            /** c_decl.e:1770								c_stmt( ret_type & SymTab[s][S_NAME] & "() __attribute__ ((alias (\"@\")));\n", s )*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23805 = (object)*(((s1_ptr)_2)->base + _s_45167);
            _2 = (object)SEQ_PTR(_23805);
            if (!IS_ATOM_INT(_27S_NAME_20209)){
                _23806 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
            }
            else{
                _23806 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
            }
            _23805 = NOVALUE;
            {
                object concat_list[3];

                concat_list[0] = _23807;
                concat_list[1] = _23806;
                concat_list[2] = _ret_type_45306;
                Concat_N((object_ptr)&_23808, concat_list, 3);
            }
            _23806 = NOVALUE;
            _57c_stmt(_23808, _s_45167, 0LL);
            _23808 = NOVALUE;
L3F: 

            /** c_decl.e:1772							LeftSym = FALSE*/
            _57LeftSym_42960 = _9FALSE_439;
L3D: 

            /** c_decl.e:1774						c_puts("\n\n" )*/
            RefDS(_22371);
            _54c_puts(_22371);
L14: 
            DeRefi(_ret_type_45306);
            _ret_type_45306 = NOVALUE;
            DeRef(_names_45429);
            _names_45429 = NOVALUE;

            /** c_decl.e:1776				end for*/
            _routine_no_45249 = _routine_no_45249 + 1LL;
            goto L12; // [2193] 367
L13: 
            ;
        }
L8: 
        DeRef(_these_routines_45246);
        _these_routines_45246 = NOVALUE;

        /** c_decl.e:1778		end for*/
        _file_no_45194 = _file_no_45194 + 1LL;
        goto L5; // [2203] 91
L6: 
        ;
    }

    /** c_decl.e:1779	end procedure*/
    DeRefi(_buff_45172);
    DeRef(_base_name_45173);
    DeRef(_long_c_file_45174);
    DeRef(_c_file_45175);
    DeRef(_23658);
    _23658 = NOVALUE;
    DeRef(_23652);
    _23652 = NOVALUE;
    DeRef(_23650);
    _23650 = NOVALUE;
    _23673 = NOVALUE;
    DeRef(_23600);
    _23600 = NOVALUE;
    DeRef(_23611);
    _23611 = NOVALUE;
    _23727 = NOVALUE;
    DeRef(_23615);
    _23615 = NOVALUE;
    DeRef(_23662);
    _23662 = NOVALUE;
    _23702 = NOVALUE;
    DeRef(_23618);
    _23618 = NOVALUE;
    _23621 = NOVALUE;
    DeRef(_23613);
    _23613 = NOVALUE;
    DeRef(_23577);
    _23577 = NOVALUE;
    DeRef(_23586);
    _23586 = NOVALUE;
    DeRef(_23656);
    _23656 = NOVALUE;
    DeRef(_23705);
    _23705 = NOVALUE;
    DeRef(_23654);
    _23654 = NOVALUE;
    DeRef(_23623);
    _23623 = NOVALUE;
    return;
    ;
}



// 0x6D5EB94B
