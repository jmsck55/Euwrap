// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _43EndLineTable()
{
    object _0, _1, _2;
    

    /** parser.e:120		LineTable = append(LineTable, -2)*/
    Append(&_27LineTable_20661, _27LineTable_20661, -2LL);

    /** parser.e:121	end procedure*/
    return;
    ;
}


void _43CreateTopLevel()
{
    object _28146 = NOVALUE;
    object _28144 = NOVALUE;
    object _28142 = NOVALUE;
    object _28140 = NOVALUE;
    object _28138 = NOVALUE;
    object _28136 = NOVALUE;
    object _28134 = NOVALUE;
    object _28132 = NOVALUE;
    object _28130 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:125		SymTab[TopLevelSub][S_NUM_ARGS] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _28130 = NOVALUE;

    /** parser.e:126		SymTab[TopLevelSub][S_TEMPS] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_TEMPS_20254))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TEMPS_20254)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_TEMPS_20254);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _28132 = NOVALUE;

    /** parser.e:127		SymTab[TopLevelSub][S_CODE] = {}*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    RefDS(_22218);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22218;
    DeRef(_1);
    _28134 = NOVALUE;

    /** parser.e:128		SymTab[TopLevelSub][S_LINETAB] = {}*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    RefDS(_22218);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_LINETAB_20244))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_LINETAB_20244)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_LINETAB_20244);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22218;
    DeRef(_1);
    _28136 = NOVALUE;

    /** parser.e:129		SymTab[TopLevelSub][S_FIRSTLINE] = 1*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_FIRSTLINE_20249))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FIRSTLINE_20249)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_FIRSTLINE_20249);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _28138 = NOVALUE;

    /** parser.e:130		SymTab[TopLevelSub][S_REFLIST] = {}*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    RefDS(_22218);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 24LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22218;
    DeRef(_1);
    _28140 = NOVALUE;

    /** parser.e:131		SymTab[TopLevelSub][S_NREFS] = 1*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _28142 = NOVALUE;

    /** parser.e:132		SymTab[TopLevelSub][S_RESIDENT_TASK] = 1*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _28144 = NOVALUE;

    /** parser.e:133		SymTab[TopLevelSub][S_SAVED_PRIVATES] = {}*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    RefDS(_22218);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 26LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22218;
    DeRef(_1);
    _28146 = NOVALUE;

    /** parser.e:135		Start_block( PROC, TopLevelSub )*/
    _64Start_block(27LL, _27TopLevelSub_20578);

    /** parser.e:136	end procedure*/
    return;
    ;
}


void _43CheckForUndefinedGotoLabels()
{
    object _28160 = NOVALUE;
    object _28159 = NOVALUE;
    object _28156 = NOVALUE;
    object _28154 = NOVALUE;
    object _28152 = NOVALUE;
    object _28150 = NOVALUE;
    object _28149 = NOVALUE;
    object _28148 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:139		for i = 1 to length(goto_delay) do*/
    if (IS_SEQUENCE(_27goto_delay_20682)){
            _28148 = SEQ_PTR(_27goto_delay_20682)->length;
    }
    else {
        _28148 = 1;
    }
    {
        object _i_55572;
        _i_55572 = 1LL;
L1: 
        if (_i_55572 > _28148){
            goto L2; // [8] 106
        }

        /** parser.e:140			if not equal(goto_delay[i],"") then*/
        _2 = (object)SEQ_PTR(_27goto_delay_20682);
        _28149 = (object)*(((s1_ptr)_2)->base + _i_55572);
        if (_28149 == _22218)
        _28150 = 1;
        else if (IS_ATOM_INT(_28149) && IS_ATOM_INT(_22218))
        _28150 = 0;
        else
        _28150 = (compare(_28149, _22218) == 0);
        _28149 = NOVALUE;
        if (_28150 != 0)
        goto L3; // [27] 99
        _28150 = NOVALUE;

        /** parser.e:141				line_number = goto_line[i][1] -- tell compiler the correct line number*/
        _2 = (object)SEQ_PTR(_43goto_line_55478);
        _28152 = (object)*(((s1_ptr)_2)->base + _i_55572);
        _2 = (object)SEQ_PTR(_28152);
        _27line_number_20572 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (!IS_ATOM_INT(_27line_number_20572)){
            _27line_number_20572 = (object)DBL_PTR(_27line_number_20572)->dbl;
        }
        _28152 = NOVALUE;

        /** parser.e:142				gline_number = goto_line[i][1] -- tell compiler the correct line number*/
        _2 = (object)SEQ_PTR(_43goto_line_55478);
        _28154 = (object)*(((s1_ptr)_2)->base + _i_55572);
        _2 = (object)SEQ_PTR(_28154);
        _27gline_number_20576 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (!IS_ATOM_INT(_27gline_number_20576)){
            _27gline_number_20576 = (object)DBL_PTR(_27gline_number_20576)->dbl;
        }
        _28154 = NOVALUE;

        /** parser.e:143				ThisLine = goto_line[i][2] -- tell compiler the correct line number*/
        _2 = (object)SEQ_PTR(_43goto_line_55478);
        _28156 = (object)*(((s1_ptr)_2)->base + _i_55572);
        DeRef(_49ThisLine_49693);
        _2 = (object)SEQ_PTR(_28156);
        _49ThisLine_49693 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_49ThisLine_49693);
        _28156 = NOVALUE;

        /** parser.e:144				bp = length(ThisLine)*/
        if (IS_SEQUENCE(_49ThisLine_49693)){
                _49bp_49697 = SEQ_PTR(_49ThisLine_49693)->length;
        }
        else {
            _49bp_49697 = 1;
        }

        /** parser.e:145					CompileErr(UNKNOWN_LABEL_1, {goto_delay[i]})*/
        _2 = (object)SEQ_PTR(_27goto_delay_20682);
        _28159 = (object)*(((s1_ptr)_2)->base + _i_55572);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_28159);
        ((intptr_t*)_2)[1] = _28159;
        _28160 = MAKE_SEQ(_1);
        _28159 = NOVALUE;
        _49CompileErr(156LL, _28160, 0LL);
        _28160 = NOVALUE;
L3: 

        /** parser.e:147		end for*/
        _i_55572 = _i_55572 + 1LL;
        goto L1; // [101] 15
L2: 
        ;
    }

    /** parser.e:148	end procedure*/
    return;
    ;
}


void _43PushGoto()
{
    object _new_1__tmp_at88_55607 = NOVALUE;
    object _new_inlined_new_at_88_55606 = NOVALUE;
    object _28161 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:151		goto_stack = append(goto_stack, {goto_addr, goto_list, goto_labels, goto_delay, goto_line, goto_ref, label_block, goto_init })*/
    _1 = NewS1(8);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_43goto_addr_55480);
    ((intptr_t*)_2)[1] = _43goto_addr_55480;
    RefDS(_27goto_list_20683);
    ((intptr_t*)_2)[2] = _27goto_list_20683;
    RefDS(_43goto_labels_55479);
    ((intptr_t*)_2)[3] = _43goto_labels_55479;
    RefDS(_27goto_delay_20682);
    ((intptr_t*)_2)[4] = _27goto_delay_20682;
    RefDS(_43goto_line_55478);
    ((intptr_t*)_2)[5] = _43goto_line_55478;
    RefDS(_43goto_ref_55482);
    ((intptr_t*)_2)[6] = _43goto_ref_55482;
    RefDS(_43label_block_55483);
    ((intptr_t*)_2)[7] = _43label_block_55483;
    Ref(_43goto_init_55485);
    ((intptr_t*)_2)[8] = _43goto_init_55485;
    _28161 = MAKE_SEQ(_1);
    RefDS(_28161);
    Append(&_43goto_stack_55481, _43goto_stack_55481, _28161);
    DeRefDS(_28161);
    _28161 = NOVALUE;

    /** parser.e:152		goto_addr = {}*/
    RefDS(_22218);
    DeRefDS(_43goto_addr_55480);
    _43goto_addr_55480 = _22218;

    /** parser.e:153		goto_list = {}*/
    RefDS(_22218);
    DeRefDS(_27goto_list_20683);
    _27goto_list_20683 = _22218;

    /** parser.e:154		goto_labels = {}*/
    RefDS(_22218);
    DeRefDS(_43goto_labels_55479);
    _43goto_labels_55479 = _22218;

    /** parser.e:155		goto_delay = {}*/
    RefDS(_22218);
    DeRefDS(_27goto_delay_20682);
    _27goto_delay_20682 = _22218;

    /** parser.e:156		goto_line = {}*/
    RefDS(_22218);
    DeRefDS(_43goto_line_55478);
    _43goto_line_55478 = _22218;

    /** parser.e:157		goto_ref = {}*/
    RefDS(_22218);
    DeRefDS(_43goto_ref_55482);
    _43goto_ref_55482 = _22218;

    /** parser.e:158		label_block = {}*/
    RefDS(_22218);
    DeRefDS(_43label_block_55483);
    _43label_block_55483 = _22218;

    /** parser.e:159		goto_init = map:new()*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at88_55607;
    _new_1__tmp_at88_55607 = _34new_map_seq(8LL);
    DeRef(_0);
    Ref(_new_1__tmp_at88_55607);
    _0 = _35malloc(_new_1__tmp_at88_55607, 1LL);
    DeRef(_43goto_init_55485);
    _43goto_init_55485 = _0;
    DeRef(_new_1__tmp_at88_55607);
    _new_1__tmp_at88_55607 = NOVALUE;

    /** parser.e:160	end procedure*/
    return;
    ;
}


void _43PopGoto()
{
    object _28187 = NOVALUE;
    object _28185 = NOVALUE;
    object _28184 = NOVALUE;
    object _28182 = NOVALUE;
    object _28181 = NOVALUE;
    object _28179 = NOVALUE;
    object _28178 = NOVALUE;
    object _28176 = NOVALUE;
    object _28175 = NOVALUE;
    object _28173 = NOVALUE;
    object _28172 = NOVALUE;
    object _28170 = NOVALUE;
    object _28169 = NOVALUE;
    object _28167 = NOVALUE;
    object _28166 = NOVALUE;
    object _28164 = NOVALUE;
    object _28163 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:163		CheckForUndefinedGotoLabels()*/
    _43CheckForUndefinedGotoLabels();

    /** parser.e:164		goto_addr   = goto_stack[$][1]*/
    if (IS_SEQUENCE(_43goto_stack_55481)){
            _28163 = SEQ_PTR(_43goto_stack_55481)->length;
    }
    else {
        _28163 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_55481);
    _28164 = (object)*(((s1_ptr)_2)->base + _28163);
    DeRef(_43goto_addr_55480);
    _2 = (object)SEQ_PTR(_28164);
    _43goto_addr_55480 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_43goto_addr_55480);
    _28164 = NOVALUE;

    /** parser.e:165		goto_list   = goto_stack[$][2]*/
    if (IS_SEQUENCE(_43goto_stack_55481)){
            _28166 = SEQ_PTR(_43goto_stack_55481)->length;
    }
    else {
        _28166 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_55481);
    _28167 = (object)*(((s1_ptr)_2)->base + _28166);
    DeRef(_27goto_list_20683);
    _2 = (object)SEQ_PTR(_28167);
    _27goto_list_20683 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_27goto_list_20683);
    _28167 = NOVALUE;

    /** parser.e:166		goto_labels = goto_stack[$][3]*/
    if (IS_SEQUENCE(_43goto_stack_55481)){
            _28169 = SEQ_PTR(_43goto_stack_55481)->length;
    }
    else {
        _28169 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_55481);
    _28170 = (object)*(((s1_ptr)_2)->base + _28169);
    DeRef(_43goto_labels_55479);
    _2 = (object)SEQ_PTR(_28170);
    _43goto_labels_55479 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_43goto_labels_55479);
    _28170 = NOVALUE;

    /** parser.e:167		goto_delay  = goto_stack[$][4]*/
    if (IS_SEQUENCE(_43goto_stack_55481)){
            _28172 = SEQ_PTR(_43goto_stack_55481)->length;
    }
    else {
        _28172 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_55481);
    _28173 = (object)*(((s1_ptr)_2)->base + _28172);
    DeRef(_27goto_delay_20682);
    _2 = (object)SEQ_PTR(_28173);
    _27goto_delay_20682 = (object)*(((s1_ptr)_2)->base + 4LL);
    Ref(_27goto_delay_20682);
    _28173 = NOVALUE;

    /** parser.e:168		goto_line   = goto_stack[$][5]*/
    if (IS_SEQUENCE(_43goto_stack_55481)){
            _28175 = SEQ_PTR(_43goto_stack_55481)->length;
    }
    else {
        _28175 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_55481);
    _28176 = (object)*(((s1_ptr)_2)->base + _28175);
    DeRef(_43goto_line_55478);
    _2 = (object)SEQ_PTR(_28176);
    _43goto_line_55478 = (object)*(((s1_ptr)_2)->base + 5LL);
    Ref(_43goto_line_55478);
    _28176 = NOVALUE;

    /** parser.e:169		goto_ref    = goto_stack[$][6]*/
    if (IS_SEQUENCE(_43goto_stack_55481)){
            _28178 = SEQ_PTR(_43goto_stack_55481)->length;
    }
    else {
        _28178 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_55481);
    _28179 = (object)*(((s1_ptr)_2)->base + _28178);
    DeRef(_43goto_ref_55482);
    _2 = (object)SEQ_PTR(_28179);
    _43goto_ref_55482 = (object)*(((s1_ptr)_2)->base + 6LL);
    Ref(_43goto_ref_55482);
    _28179 = NOVALUE;

    /** parser.e:170		label_block = goto_stack[$][7]*/
    if (IS_SEQUENCE(_43goto_stack_55481)){
            _28181 = SEQ_PTR(_43goto_stack_55481)->length;
    }
    else {
        _28181 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_55481);
    _28182 = (object)*(((s1_ptr)_2)->base + _28181);
    DeRef(_43label_block_55483);
    _2 = (object)SEQ_PTR(_28182);
    _43label_block_55483 = (object)*(((s1_ptr)_2)->base + 7LL);
    Ref(_43label_block_55483);
    _28182 = NOVALUE;

    /** parser.e:171		goto_init   = goto_stack[$][8]*/
    if (IS_SEQUENCE(_43goto_stack_55481)){
            _28184 = SEQ_PTR(_43goto_stack_55481)->length;
    }
    else {
        _28184 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_55481);
    _28185 = (object)*(((s1_ptr)_2)->base + _28184);
    DeRef(_43goto_init_55485);
    _2 = (object)SEQ_PTR(_28185);
    _43goto_init_55485 = (object)*(((s1_ptr)_2)->base + 8LL);
    Ref(_43goto_init_55485);
    _28185 = NOVALUE;

    /** parser.e:173		goto_stack = remove( goto_stack, length( goto_stack ) )*/
    if (IS_SEQUENCE(_43goto_stack_55481)){
            _28187 = SEQ_PTR(_43goto_stack_55481)->length;
    }
    else {
        _28187 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_43goto_stack_55481);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_28187)) ? _28187 : (object)(DBL_PTR(_28187)->dbl);
        int stop = (IS_ATOM_INT(_28187)) ? _28187 : (object)(DBL_PTR(_28187)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_43goto_stack_55481), start, &_43goto_stack_55481 );
            }
            else Tail(SEQ_PTR(_43goto_stack_55481), stop+1, &_43goto_stack_55481);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_43goto_stack_55481), start, &_43goto_stack_55481);
        }
        else {
            assign_slice_seq = &assign_space;
            _43goto_stack_55481 = Remove_elements(start, stop, (SEQ_PTR(_43goto_stack_55481)->ref == 1));
        }
    }
    _28187 = NOVALUE;
    _28187 = NOVALUE;

    /** parser.e:175	end procedure*/
    return;
    ;
}


void _43EnterTopLevel(object _end_line_table_55640)
{
    object _28206 = NOVALUE;
    object _28205 = NOVALUE;
    object _28203 = NOVALUE;
    object _28202 = NOVALUE;
    object _28200 = NOVALUE;
    object _28198 = NOVALUE;
    object _28196 = NOVALUE;
    object _28194 = NOVALUE;
    object _28193 = NOVALUE;
    object _28191 = NOVALUE;
    object _28189 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:179		if CurrentSub then*/
    if (_27CurrentSub_20579 == 0)
    {
        goto L1; // [7] 59
    }
    else{
    }

    /** parser.e:180			if end_line_table then*/
    if (_end_line_table_55640 == 0)
    {
        goto L2; // [12] 58
    }
    else{
    }

    /** parser.e:181				EndLineTable()*/
    _43EndLineTable();

    /** parser.e:182				SymTab[CurrentSub][S_LINETAB] = LineTable*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27CurrentSub_20579 + ((s1_ptr)_2)->base);
    RefDS(_27LineTable_20661);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_LINETAB_20244))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_LINETAB_20244)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_LINETAB_20244);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27LineTable_20661;
    DeRef(_1);
    _28189 = NOVALUE;

    /** parser.e:183				SymTab[CurrentSub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27CurrentSub_20579 + ((s1_ptr)_2)->base);
    RefDS(_27Code_20660);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27Code_20660;
    DeRef(_1);
    _28191 = NOVALUE;
L2: 
L1: 

    /** parser.e:186		if length(goto_stack) then*/
    if (IS_SEQUENCE(_43goto_stack_55481)){
            _28193 = SEQ_PTR(_43goto_stack_55481)->length;
    }
    else {
        _28193 = 1;
    }
    if (_28193 == 0)
    {
        _28193 = NOVALUE;
        goto L3; // [66] 74
    }
    else{
        _28193 = NOVALUE;
    }

    /** parser.e:187			PopGoto()*/
    _43PopGoto();
L3: 

    /** parser.e:189		LineTable = SymTab[TopLevelSub][S_LINETAB]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28194 = (object)*(((s1_ptr)_2)->base + _27TopLevelSub_20578);
    DeRef(_27LineTable_20661);
    _2 = (object)SEQ_PTR(_28194);
    if (!IS_ATOM_INT(_27S_LINETAB_20244)){
        _27LineTable_20661 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_LINETAB_20244)->dbl));
    }
    else{
        _27LineTable_20661 = (object)*(((s1_ptr)_2)->base + _27S_LINETAB_20244);
    }
    Ref(_27LineTable_20661);
    _28194 = NOVALUE;

    /** parser.e:190		Code = SymTab[TopLevelSub][S_CODE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28196 = (object)*(((s1_ptr)_2)->base + _27TopLevelSub_20578);
    DeRef(_27Code_20660);
    _2 = (object)SEQ_PTR(_28196);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    Ref(_27Code_20660);
    _28196 = NOVALUE;

    /** parser.e:191		SymTab[TopLevelSub][S_LINETAB] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_LINETAB_20244))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_LINETAB_20244)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_LINETAB_20244);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _28198 = NOVALUE;

    /** parser.e:192		SymTab[TopLevelSub][S_CODE] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _28200 = NOVALUE;

    /** parser.e:193		previous_op = -1*/
    _27previous_op_20670 = -1LL;

    /** parser.e:194		CurrentSub = TopLevelSub*/
    _27CurrentSub_20579 = _27TopLevelSub_20578;

    /** parser.e:195		clear_last()*/
    _45clear_last();

    /** parser.e:196		if length( branch_stack ) then*/
    if (IS_SEQUENCE(_43branch_stack_55467)){
            _28202 = SEQ_PTR(_43branch_stack_55467)->length;
    }
    else {
        _28202 = 1;
    }
    if (_28202 == 0)
    {
        _28202 = NOVALUE;
        goto L4; // [171] 205
    }
    else{
        _28202 = NOVALUE;
    }

    /** parser.e:197			branch_list = branch_stack[$]*/
    if (IS_SEQUENCE(_43branch_stack_55467)){
            _28203 = SEQ_PTR(_43branch_stack_55467)->length;
    }
    else {
        _28203 = 1;
    }
    DeRef(_43branch_list_55466);
    _2 = (object)SEQ_PTR(_43branch_stack_55467);
    _43branch_list_55466 = (object)*(((s1_ptr)_2)->base + _28203);
    Ref(_43branch_list_55466);

    /** parser.e:198			branch_stack = tail( branch_stack )*/
    if (IS_SEQUENCE(_43branch_stack_55467)){
            _28205 = SEQ_PTR(_43branch_stack_55467)->length;
    }
    else {
        _28205 = 1;
    }
    _28206 = _28205 - 1LL;
    _28205 = NOVALUE;
    {
        int len = SEQ_PTR(_43branch_stack_55467)->length;
        int size = (IS_ATOM_INT(_28206)) ? _28206 : (object)(DBL_PTR(_28206)->dbl);
        if (size <= 0) {
            DeRef(_43branch_stack_55467);
            _43branch_stack_55467 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_43branch_stack_55467);
            DeRef(_43branch_stack_55467);
            _43branch_stack_55467 = _43branch_stack_55467;
        }
        else Tail(SEQ_PTR(_43branch_stack_55467), len-size+1, &_43branch_stack_55467);
    }
    _28206 = NOVALUE;
L4: 

    /** parser.e:200	end procedure*/
    return;
    ;
}


void _43LeaveTopLevel()
{
    object _28211 = NOVALUE;
    object _28209 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:204		branch_stack = append( branch_stack, branch_list )*/
    RefDS(_43branch_list_55466);
    Append(&_43branch_stack_55467, _43branch_stack_55467, _43branch_list_55466);

    /** parser.e:205		branch_list = {}*/
    RefDS(_22218);
    DeRefDS(_43branch_list_55466);
    _43branch_list_55466 = _22218;

    /** parser.e:206		PushGoto()*/
    _43PushGoto();

    /** parser.e:207		LastLineNumber = -1*/
    _61LastLineNumber_25929 = -1LL;

    /** parser.e:208		SymTab[TopLevelSub][S_LINETAB] = LineTable*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    RefDS(_27LineTable_20661);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_LINETAB_20244))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_LINETAB_20244)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_LINETAB_20244);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27LineTable_20661;
    DeRef(_1);
    _28209 = NOVALUE;

    /** parser.e:209		SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    RefDS(_27Code_20660);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27Code_20660;
    DeRef(_1);
    _28211 = NOVALUE;

    /** parser.e:210		LineTable = {}*/
    RefDS(_22218);
    DeRefDS(_27LineTable_20661);
    _27LineTable_20661 = _22218;

    /** parser.e:211		Code = {}*/
    RefDS(_22218);
    DeRefDS(_27Code_20660);
    _27Code_20660 = _22218;

    /** parser.e:212		previous_op = -1*/
    _27previous_op_20670 = -1LL;

    /** parser.e:213		clear_last()*/
    _45clear_last();

    /** parser.e:214	end procedure*/
    return;
    ;
}


void _43InitParser()
{
    object _new_1__tmp_at195_55716 = NOVALUE;
    object _new_inlined_new_at_195_55715 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:217		goto_stack = {}*/
    RefDS(_22218);
    DeRef(_43goto_stack_55481);
    _43goto_stack_55481 = _22218;

    /** parser.e:220		goto_labels = {}*/
    RefDS(_22218);
    DeRef(_43goto_labels_55479);
    _43goto_labels_55479 = _22218;

    /** parser.e:221		label_block = {}*/
    RefDS(_22218);
    DeRef(_43label_block_55483);
    _43label_block_55483 = _22218;

    /** parser.e:222		goto_ref = {}*/
    RefDS(_22218);
    DeRef(_43goto_ref_55482);
    _43goto_ref_55482 = _22218;

    /** parser.e:223		goto_addr = {}*/
    RefDS(_22218);
    DeRef(_43goto_addr_55480);
    _43goto_addr_55480 = _22218;

    /** parser.e:224		goto_line = {}*/
    RefDS(_22218);
    DeRef(_43goto_line_55478);
    _43goto_line_55478 = _22218;

    /** parser.e:225		break_list = {}*/
    RefDS(_22218);
    DeRefi(_43break_list_55486);
    _43break_list_55486 = _22218;

    /** parser.e:226		break_delay = {}*/
    RefDS(_22218);
    DeRef(_43break_delay_55487);
    _43break_delay_55487 = _22218;

    /** parser.e:227		exit_list = {}*/
    RefDS(_22218);
    DeRefi(_43exit_list_55488);
    _43exit_list_55488 = _22218;

    /** parser.e:228		exit_delay = {}*/
    RefDS(_22218);
    DeRef(_43exit_delay_55489);
    _43exit_delay_55489 = _22218;

    /** parser.e:229		continue_list = {}*/
    RefDS(_22218);
    DeRefi(_43continue_list_55490);
    _43continue_list_55490 = _22218;

    /** parser.e:230		continue_delay = {}*/
    RefDS(_22218);
    DeRef(_43continue_delay_55491);
    _43continue_delay_55491 = _22218;

    /** parser.e:231		init_stack = {}*/
    RefDS(_22218);
    DeRefi(_43init_stack_55501);
    _43init_stack_55501 = _22218;

    /** parser.e:232		CurrentSub = 0*/
    _27CurrentSub_20579 = 0LL;

    /** parser.e:233		CreateTopLevel()*/
    _43CreateTopLevel();

    /** parser.e:234		EnterTopLevel()*/
    _43EnterTopLevel(1LL);

    /** parser.e:235		backed_up_tok = {}*/
    RefDS(_22218);
    DeRef(_43backed_up_tok_55475);
    _43backed_up_tok_55475 = _22218;

    /** parser.e:236		loop_stack = {}*/
    RefDS(_22218);
    DeRefi(_43loop_stack_55502);
    _43loop_stack_55502 = _22218;

    /** parser.e:237		stmt_nest = 0*/
    _43stmt_nest_55500 = 0LL;

    /** parser.e:238		loop_labels = {}*/
    RefDS(_22218);
    DeRef(_43loop_labels_55496);
    _43loop_labels_55496 = _22218;

    /** parser.e:239		if_labels = {}*/
    RefDS(_22218);
    DeRef(_43if_labels_55497);
    _43if_labels_55497 = _22218;

    /** parser.e:240		if_stack = {}*/
    RefDS(_22218);
    DeRefi(_43if_stack_55503);
    _43if_stack_55503 = _22218;

    /** parser.e:241		continue_addr = {}*/
    RefDS(_22218);
    DeRefi(_43continue_addr_55493);
    _43continue_addr_55493 = _22218;

    /** parser.e:242		retry_addr = {}*/
    RefDS(_22218);
    DeRefi(_43retry_addr_55494);
    _43retry_addr_55494 = _22218;

    /** parser.e:243		entry_addr = {}*/
    RefDS(_22218);
    DeRefi(_43entry_addr_55492);
    _43entry_addr_55492 = _22218;

    /** parser.e:244		block_list = {}*/
    RefDS(_22218);
    DeRefi(_43block_list_55498);
    _43block_list_55498 = _22218;

    /** parser.e:245		block_index = 0*/
    _43block_index_55499 = 0LL;

    /** parser.e:246		param_num = -1*/
    _43param_num_55477 = -1LL;

    /** parser.e:247		entry_stack = {}*/
    RefDS(_22218);
    DeRef(_43entry_stack_55495);
    _43entry_stack_55495 = _22218;

    /** parser.e:248		goto_init = map:new()*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at195_55716;
    _new_1__tmp_at195_55716 = _34new_map_seq(8LL);
    DeRef(_0);
    Ref(_new_1__tmp_at195_55716);
    _0 = _35malloc(_new_1__tmp_at195_55716, 1LL);
    DeRef(_43goto_init_55485);
    _43goto_init_55485 = _0;
    DeRef(_new_1__tmp_at195_55716);
    _new_1__tmp_at195_55716 = NOVALUE;

    /** parser.e:249	end procedure*/
    return;
    ;
}


void _43NotReached(object _tok_55735, object _keyword_55736)
{
    object _28228 = NOVALUE;
    object _28227 = NOVALUE;
    object _28226 = NOVALUE;
    object _28225 = NOVALUE;
    object _28224 = NOVALUE;
    object _28223 = NOVALUE;
    object _28221 = NOVALUE;
    object _28220 = NOVALUE;
    object _28219 = NOVALUE;
    object _28218 = NOVALUE;
    object _28216 = NOVALUE;
    object _28215 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_tok_55735)) {
        _1 = (object)(DBL_PTR(_tok_55735)->dbl);
        DeRefDS(_tok_55735);
        _tok_55735 = _1;
    }

    /** parser.e:271		if not find(tok, {END, ELSE, ELSIF, END_OF_FILE, CASE, IFDEF, ELSIFDEF, ELSEDEF}) then*/
    _1 = NewS1(8);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 402LL;
    ((intptr_t*)_2)[2] = 23LL;
    ((intptr_t*)_2)[3] = 414LL;
    ((intptr_t*)_2)[4] = -21LL;
    ((intptr_t*)_2)[5] = 186LL;
    ((intptr_t*)_2)[6] = 407LL;
    ((intptr_t*)_2)[7] = 408LL;
    ((intptr_t*)_2)[8] = 409LL;
    _28215 = MAKE_SEQ(_1);
    _28216 = find_from(_tok_55735, _28215, 1LL);
    DeRefDS(_28215);
    _28215 = NOVALUE;
    if (_28216 != 0)
    goto L1; // [39] 135
    _28216 = NOVALUE;

    /** parser.e:272			if equal(keyword, "goto") and find(tok, {LOOP, LABEL, WHILE}) then*/
    if (_keyword_55736 == _26550)
    _28218 = 1;
    else if (IS_ATOM_INT(_keyword_55736) && IS_ATOM_INT(_26550))
    _28218 = 0;
    else
    _28218 = (compare(_keyword_55736, _26550) == 0);
    if (_28218 == 0) {
        goto L2; // [48] 79
    }
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 422LL;
    ((intptr_t*)_2)[2] = 419LL;
    ((intptr_t*)_2)[3] = 47LL;
    _28220 = MAKE_SEQ(_1);
    _28221 = find_from(_tok_55735, _28220, 1LL);
    DeRefDS(_28220);
    _28220 = NOVALUE;
    if (_28221 == 0)
    {
        _28221 = NOVALUE;
        goto L2; // [70] 79
    }
    else{
        _28221 = NOVALUE;
    }

    /** parser.e:273				return*/
    DeRefDSi(_keyword_55736);
    return;
L2: 

    /** parser.e:275			if equal(keyword, "abort()") and tok = LABEL then*/
    if (_keyword_55736 == _28222)
    _28223 = 1;
    else if (IS_ATOM_INT(_keyword_55736) && IS_ATOM_INT(_28222))
    _28223 = 0;
    else
    _28223 = (compare(_keyword_55736, _28222) == 0);
    if (_28223 == 0) {
        goto L3; // [85] 105
    }
    _28225 = (_tok_55735 == 419LL);
    if (_28225 == 0)
    {
        DeRef(_28225);
        _28225 = NOVALUE;
        goto L3; // [96] 105
    }
    else{
        DeRef(_28225);
        _28225 = NOVALUE;
    }

    /** parser.e:278				return*/
    DeRefDSi(_keyword_55736);
    return;
L3: 

    /** parser.e:280			Warning(218, not_reached_warning_flag,*/
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _28226 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    Ref(_28226);
    _28227 = _53name_ext(_28226);
    _28226 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _28227;
    ((intptr_t*)_2)[2] = _27line_number_20572;
    RefDS(_keyword_55736);
    ((intptr_t*)_2)[3] = _keyword_55736;
    _28228 = MAKE_SEQ(_1);
    _28227 = NOVALUE;
    _49Warning(218LL, 512LL, _28228);
    _28228 = NOVALUE;
L1: 

    /** parser.e:285	end procedure*/
    DeRefDSi(_keyword_55736);
    return;
    ;
}


void _43Forward_InitCheck(object _tok_55775, object _ref_55776)
{
    object _sym_55778 = NOVALUE;
    object _28234 = NOVALUE;
    object _28233 = NOVALUE;
    object _28232 = NOVALUE;
    object _28230 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:289		if ref then*/
    if (_ref_55776 == 0)
    {
        goto L1; // [5] 83
    }
    else{
    }

    /** parser.e:290			integer sym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_55775);
    _sym_55778 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_sym_55778)){
        _sym_55778 = (object)DBL_PTR(_sym_55778)->dbl;
    }

    /** parser.e:291			if tok[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_55775);
    _28230 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28230, 512LL)){
        _28230 = NOVALUE;
        goto L2; // [28] 50
    }
    _28230 = NOVALUE;

    /** parser.e:292				set_qualified_fwd( SymTab[sym][S_FILE_NO] )*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28232 = (object)*(((s1_ptr)_2)->base + _sym_55778);
    _2 = (object)SEQ_PTR(_28232);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _28233 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _28233 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _28232 = NOVALUE;
    Ref(_28233);
    _61set_qualified_fwd(_28233);
    _28233 = NOVALUE;
L2: 

    /** parser.e:294			ref = new_forward_reference( GLOBAL_INIT_CHECK, tok[T_SYM], GLOBAL_INIT_CHECK )*/
    _2 = (object)SEQ_PTR(_tok_55775);
    _28234 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_28234);
    _ref_55776 = _42new_forward_reference(109LL, _28234, 109LL);
    _28234 = NOVALUE;
    if (!IS_ATOM_INT(_ref_55776)) {
        _1 = (object)(DBL_PTR(_ref_55776)->dbl);
        DeRefDS(_ref_55776);
        _ref_55776 = _1;
    }

    /** parser.e:296			emit_op( GLOBAL_INIT_CHECK )*/
    _45emit_op(109LL);

    /** parser.e:297			emit_addr( sym )*/
    _45emit_addr(_sym_55778);
L1: 

    /** parser.e:299	end procedure*/
    DeRef(_tok_55775);
    return;
    ;
}


void _43InitCheck(object _sym_55803, object _ref_55804)
{
    object _28311 = NOVALUE;
    object _28310 = NOVALUE;
    object _28309 = NOVALUE;
    object _28308 = NOVALUE;
    object _28307 = NOVALUE;
    object _28306 = NOVALUE;
    object _28305 = NOVALUE;
    object _28304 = NOVALUE;
    object _28302 = NOVALUE;
    object _28300 = NOVALUE;
    object _28299 = NOVALUE;
    object _28297 = NOVALUE;
    object _28296 = NOVALUE;
    object _28295 = NOVALUE;
    object _28294 = NOVALUE;
    object _28293 = NOVALUE;
    object _28292 = NOVALUE;
    object _28291 = NOVALUE;
    object _28290 = NOVALUE;
    object _28289 = NOVALUE;
    object _28288 = NOVALUE;
    object _28287 = NOVALUE;
    object _28286 = NOVALUE;
    object _28285 = NOVALUE;
    object _28284 = NOVALUE;
    object _28282 = NOVALUE;
    object _28281 = NOVALUE;
    object _28280 = NOVALUE;
    object _28279 = NOVALUE;
    object _28278 = NOVALUE;
    object _28277 = NOVALUE;
    object _28276 = NOVALUE;
    object _28275 = NOVALUE;
    object _28274 = NOVALUE;
    object _28272 = NOVALUE;
    object _28271 = NOVALUE;
    object _28270 = NOVALUE;
    object _28269 = NOVALUE;
    object _28268 = NOVALUE;
    object _28267 = NOVALUE;
    object _28266 = NOVALUE;
    object _28265 = NOVALUE;
    object _28264 = NOVALUE;
    object _28263 = NOVALUE;
    object _28262 = NOVALUE;
    object _28261 = NOVALUE;
    object _28260 = NOVALUE;
    object _28259 = NOVALUE;
    object _28258 = NOVALUE;
    object _28257 = NOVALUE;
    object _28256 = NOVALUE;
    object _28255 = NOVALUE;
    object _28254 = NOVALUE;
    object _28253 = NOVALUE;
    object _28252 = NOVALUE;
    object _28251 = NOVALUE;
    object _28249 = NOVALUE;
    object _28248 = NOVALUE;
    object _28247 = NOVALUE;
    object _28246 = NOVALUE;
    object _28245 = NOVALUE;
    object _28244 = NOVALUE;
    object _28243 = NOVALUE;
    object _28242 = NOVALUE;
    object _28241 = NOVALUE;
    object _28240 = NOVALUE;
    object _28239 = NOVALUE;
    object _28238 = NOVALUE;
    object _28236 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:306		if sym < 0 or (SymTab[sym][S_MODE] = M_NORMAL and*/
    _28236 = (_sym_55803 < 0LL);
    if (_28236 != 0) {
        goto L1; // [11] 90
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28238 = (object)*(((s1_ptr)_2)->base + _sym_55803);
    _2 = (object)SEQ_PTR(_28238);
    _28239 = (object)*(((s1_ptr)_2)->base + 3LL);
    _28238 = NOVALUE;
    if (IS_ATOM_INT(_28239)) {
        _28240 = (_28239 == 1LL);
    }
    else {
        _28240 = binary_op(EQUALS, _28239, 1LL);
    }
    _28239 = NOVALUE;
    if (IS_ATOM_INT(_28240)) {
        if (_28240 == 0) {
            _28241 = 0;
            goto L2; // [33] 59
        }
    }
    else {
        if (DBL_PTR(_28240)->dbl == 0.0) {
            _28241 = 0;
            goto L2; // [33] 59
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28242 = (object)*(((s1_ptr)_2)->base + _sym_55803);
    _2 = (object)SEQ_PTR(_28242);
    _28243 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28242 = NOVALUE;
    if (IS_ATOM_INT(_28243)) {
        _28244 = (_28243 != 2LL);
    }
    else {
        _28244 = binary_op(NOTEQ, _28243, 2LL);
    }
    _28243 = NOVALUE;
    DeRef(_28241);
    if (IS_ATOM_INT(_28244))
    _28241 = (_28244 != 0);
    else
    _28241 = DBL_PTR(_28244)->dbl != 0.0;
L2: 
    if (_28241 == 0) {
        DeRef(_28245);
        _28245 = 0;
        goto L3; // [59] 85
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28246 = (object)*(((s1_ptr)_2)->base + _sym_55803);
    _2 = (object)SEQ_PTR(_28246);
    _28247 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28246 = NOVALUE;
    if (IS_ATOM_INT(_28247)) {
        _28248 = (_28247 != 4LL);
    }
    else {
        _28248 = binary_op(NOTEQ, _28247, 4LL);
    }
    _28247 = NOVALUE;
    if (IS_ATOM_INT(_28248))
    _28245 = (_28248 != 0);
    else
    _28245 = DBL_PTR(_28248)->dbl != 0.0;
L3: 
    if (_28245 == 0)
    {
        _28245 = NOVALUE;
        goto L4; // [86] 502
    }
    else{
        _28245 = NOVALUE;
    }
L1: 

    /** parser.e:309			if sym < 0 or ((SymTab[sym][S_SCOPE] != SC_PRIVATE and*/
    _28249 = (_sym_55803 < 0LL);
    if (_28249 != 0) {
        goto L5; // [96] 213
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28251 = (object)*(((s1_ptr)_2)->base + _sym_55803);
    _2 = (object)SEQ_PTR(_28251);
    _28252 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28251 = NOVALUE;
    if (IS_ATOM_INT(_28252)) {
        _28253 = (_28252 != 3LL);
    }
    else {
        _28253 = binary_op(NOTEQ, _28252, 3LL);
    }
    _28252 = NOVALUE;
    if (IS_ATOM_INT(_28253)) {
        if (_28253 == 0) {
            DeRef(_28254);
            _28254 = 0;
            goto L6; // [118] 144
        }
    }
    else {
        if (DBL_PTR(_28253)->dbl == 0.0) {
            DeRef(_28254);
            _28254 = 0;
            goto L6; // [118] 144
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28255 = (object)*(((s1_ptr)_2)->base + _sym_55803);
    _2 = (object)SEQ_PTR(_28255);
    _28256 = (object)*(((s1_ptr)_2)->base + 1LL);
    _28255 = NOVALUE;
    if (_28256 == _27NOVALUE_20426)
    _28257 = 1;
    else if (IS_ATOM_INT(_28256) && IS_ATOM_INT(_27NOVALUE_20426))
    _28257 = 0;
    else
    _28257 = (compare(_28256, _27NOVALUE_20426) == 0);
    _28256 = NOVALUE;
    DeRef(_28254);
    _28254 = (_28257 != 0);
L6: 
    if (_28254 != 0) {
        DeRef(_28258);
        _28258 = 1;
        goto L7; // [144] 208
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28259 = (object)*(((s1_ptr)_2)->base + _sym_55803);
    _2 = (object)SEQ_PTR(_28259);
    _28260 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28259 = NOVALUE;
    if (IS_ATOM_INT(_28260)) {
        _28261 = (_28260 == 3LL);
    }
    else {
        _28261 = binary_op(EQUALS, _28260, 3LL);
    }
    _28260 = NOVALUE;
    if (IS_ATOM_INT(_28261)) {
        if (_28261 == 0) {
            DeRef(_28262);
            _28262 = 0;
            goto L8; // [166] 204
        }
    }
    else {
        if (DBL_PTR(_28261)->dbl == 0.0) {
            DeRef(_28262);
            _28262 = 0;
            goto L8; // [166] 204
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28263 = (object)*(((s1_ptr)_2)->base + _sym_55803);
    _2 = (object)SEQ_PTR(_28263);
    _28264 = (object)*(((s1_ptr)_2)->base + 16LL);
    _28263 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28265 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_28265);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _28266 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _28266 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _28265 = NOVALUE;
    if (IS_ATOM_INT(_28264) && IS_ATOM_INT(_28266)) {
        _28267 = (_28264 >= _28266);
    }
    else {
        _28267 = binary_op(GREATEREQ, _28264, _28266);
    }
    _28264 = NOVALUE;
    _28266 = NOVALUE;
    DeRef(_28262);
    if (IS_ATOM_INT(_28267))
    _28262 = (_28267 != 0);
    else
    _28262 = DBL_PTR(_28267)->dbl != 0.0;
L8: 
    DeRef(_28258);
    _28258 = (_28262 != 0);
L7: 
    if (_28258 == 0)
    {
        _28258 = NOVALUE;
        goto L9; // [209] 566
    }
    else{
        _28258 = NOVALUE;
    }
L5: 

    /** parser.e:313				if sym < 0 or (SymTab[sym][S_INITLEVEL] = -1)*/
    _28268 = (_sym_55803 < 0LL);
    if (_28268 != 0) {
        _28269 = 1;
        goto LA; // [219] 243
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28270 = (object)*(((s1_ptr)_2)->base + _sym_55803);
    _2 = (object)SEQ_PTR(_28270);
    _28271 = (object)*(((s1_ptr)_2)->base + 14LL);
    _28270 = NOVALUE;
    if (IS_ATOM_INT(_28271)) {
        _28272 = (_28271 == -1LL);
    }
    else {
        _28272 = binary_op(EQUALS, _28271, -1LL);
    }
    _28271 = NOVALUE;
    if (IS_ATOM_INT(_28272))
    _28269 = (_28272 != 0);
    else
    _28269 = DBL_PTR(_28272)->dbl != 0.0;
LA: 
    if (_28269 != 0) {
        goto LB; // [243] 270
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28274 = (object)*(((s1_ptr)_2)->base + _sym_55803);
    _2 = (object)SEQ_PTR(_28274);
    _28275 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28274 = NOVALUE;
    if (IS_ATOM_INT(_28275)) {
        _28276 = (_28275 != 3LL);
    }
    else {
        _28276 = binary_op(NOTEQ, _28275, 3LL);
    }
    _28275 = NOVALUE;
    if (_28276 == 0) {
        DeRef(_28276);
        _28276 = NOVALUE;
        goto L9; // [266] 566
    }
    else {
        if (!IS_ATOM_INT(_28276) && DBL_PTR(_28276)->dbl == 0.0){
            DeRef(_28276);
            _28276 = NOVALUE;
            goto L9; // [266] 566
        }
        DeRef(_28276);
        _28276 = NOVALUE;
    }
    DeRef(_28276);
    _28276 = NOVALUE;
LB: 

    /** parser.e:316					if ref then*/
    if (_ref_55804 == 0)
    {
        goto LC; // [272] 375
    }
    else{
    }

    /** parser.e:317						if sym > 0 and (SymTab[sym][S_SCOPE] = SC_UNDEFINED) then*/
    _28277 = (_sym_55803 > 0LL);
    if (_28277 == 0) {
        goto LD; // [281] 317
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28279 = (object)*(((s1_ptr)_2)->base + _sym_55803);
    _2 = (object)SEQ_PTR(_28279);
    _28280 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28279 = NOVALUE;
    if (IS_ATOM_INT(_28280)) {
        _28281 = (_28280 == 9LL);
    }
    else {
        _28281 = binary_op(EQUALS, _28280, 9LL);
    }
    _28280 = NOVALUE;
    if (_28281 == 0) {
        DeRef(_28281);
        _28281 = NOVALUE;
        goto LD; // [304] 317
    }
    else {
        if (!IS_ATOM_INT(_28281) && DBL_PTR(_28281)->dbl == 0.0){
            DeRef(_28281);
            _28281 = NOVALUE;
            goto LD; // [304] 317
        }
        DeRef(_28281);
        _28281 = NOVALUE;
    }
    DeRef(_28281);
    _28281 = NOVALUE;

    /** parser.e:318							emit_op(PRIVATE_INIT_CHECK)*/
    _45emit_op(30LL);
    goto LE; // [314] 369
LD: 

    /** parser.e:319						elsif sym < 0 or find(SymTab[sym][S_SCOPE], SCOPE_TYPES) then*/
    _28282 = (_sym_55803 < 0LL);
    if (_28282 != 0) {
        goto LF; // [323] 351
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28284 = (object)*(((s1_ptr)_2)->base + _sym_55803);
    _2 = (object)SEQ_PTR(_28284);
    _28285 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28284 = NOVALUE;
    _28286 = find_from(_28285, _43SCOPE_TYPES_55459, 1LL);
    _28285 = NOVALUE;
    if (_28286 == 0)
    {
        _28286 = NOVALUE;
        goto L10; // [347] 361
    }
    else{
        _28286 = NOVALUE;
    }
LF: 

    /** parser.e:320							emit_op(GLOBAL_INIT_CHECK) -- will become NOP2*/
    _45emit_op(109LL);
    goto LE; // [358] 369
L10: 

    /** parser.e:322							emit_op(PRIVATE_INIT_CHECK)*/
    _45emit_op(30LL);
LE: 

    /** parser.e:324						emit_addr(sym)*/
    _45emit_addr(_sym_55803);
LC: 

    /** parser.e:326					if sym > 0 */
    _28287 = (_sym_55803 > 0LL);
    if (_28287 == 0) {
        _28288 = 0;
        goto L11; // [381] 411
    }
    _28289 = (_43short_circuit_55468 <= 0LL);
    if (_28289 != 0) {
        _28290 = 1;
        goto L12; // [391] 407
    }
    _28291 = (_43short_circuit_B_55470 == _9FALSE_439);
    _28290 = (_28291 != 0);
L12: 
    _28288 = (_28290 != 0);
L11: 
    if (_28288 == 0) {
        goto L9; // [411] 566
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28293 = (object)*(((s1_ptr)_2)->base + _sym_55803);
    _2 = (object)SEQ_PTR(_28293);
    _28294 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28293 = NOVALUE;
    if (IS_ATOM_INT(_28294)) {
        _28295 = (_28294 != 3LL);
    }
    else {
        _28295 = binary_op(NOTEQ, _28294, 3LL);
    }
    _28294 = NOVALUE;
    if (IS_ATOM_INT(_28295)) {
        _28296 = (_28295 == 0);
    }
    else {
        _28296 = unary_op(NOT, _28295);
    }
    DeRef(_28295);
    _28295 = NOVALUE;
    if (_28296 == 0) {
        DeRef(_28296);
        _28296 = NOVALUE;
        goto L9; // [437] 566
    }
    else {
        if (!IS_ATOM_INT(_28296) && DBL_PTR(_28296)->dbl == 0.0){
            DeRef(_28296);
            _28296 = NOVALUE;
            goto L9; // [437] 566
        }
        DeRef(_28296);
        _28296 = NOVALUE;
    }
    DeRef(_28296);
    _28296 = NOVALUE;

    /** parser.e:330						if CurrentSub != TopLevelSub */
    _28297 = (_27CurrentSub_20579 != _27TopLevelSub_20578);
    if (_28297 != 0) {
        goto L13; // [450] 470
    }
    if (IS_SEQUENCE(_28known_files_11573)){
            _28299 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _28299 = 1;
    }
    _28300 = (_27current_file_no_20571 == _28299);
    _28299 = NOVALUE;
    if (_28300 == 0)
    {
        DeRef(_28300);
        _28300 = NOVALUE;
        goto L9; // [466] 566
    }
    else{
        DeRef(_28300);
        _28300 = NOVALUE;
    }
L13: 

    /** parser.e:335							init_stack = append(init_stack, sym)*/
    Append(&_43init_stack_55501, _43init_stack_55501, _sym_55803);

    /** parser.e:336							SymTab[sym][S_INITLEVEL] = stmt_nest*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_55803 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _43stmt_nest_55500;
    DeRef(_1);
    _28302 = NOVALUE;
    goto L9; // [499] 566
L4: 

    /** parser.e:343		elsif ref and sym > 0 and sym_mode( sym ) = M_CONSTANT and equal( NOVALUE, sym_obj( sym ) ) then*/
    if (_ref_55804 == 0) {
        _28304 = 0;
        goto L14; // [504] 516
    }
    _28305 = (_sym_55803 > 0LL);
    _28304 = (_28305 != 0);
L14: 
    if (_28304 == 0) {
        _28306 = 0;
        goto L15; // [516] 534
    }
    _28307 = _53sym_mode(_sym_55803);
    if (IS_ATOM_INT(_28307)) {
        _28308 = (_28307 == 2LL);
    }
    else {
        _28308 = binary_op(EQUALS, _28307, 2LL);
    }
    DeRef(_28307);
    _28307 = NOVALUE;
    if (IS_ATOM_INT(_28308))
    _28306 = (_28308 != 0);
    else
    _28306 = DBL_PTR(_28308)->dbl != 0.0;
L15: 
    if (_28306 == 0) {
        goto L16; // [534] 565
    }
    _28310 = _53sym_obj(_sym_55803);
    if (_27NOVALUE_20426 == _28310)
    _28311 = 1;
    else if (IS_ATOM_INT(_27NOVALUE_20426) && IS_ATOM_INT(_28310))
    _28311 = 0;
    else
    _28311 = (compare(_27NOVALUE_20426, _28310) == 0);
    DeRef(_28310);
    _28310 = NOVALUE;
    if (_28311 == 0)
    {
        _28311 = NOVALUE;
        goto L16; // [549] 565
    }
    else{
        _28311 = NOVALUE;
    }

    /** parser.e:344			emit_op( GLOBAL_INIT_CHECK )*/
    _45emit_op(109LL);

    /** parser.e:345			emit_addr(sym)*/
    _45emit_addr(_sym_55803);
L16: 
L9: 

    /** parser.e:349	end procedure*/
    DeRef(_28244);
    _28244 = NOVALUE;
    DeRef(_28287);
    _28287 = NOVALUE;
    DeRef(_28277);
    _28277 = NOVALUE;
    DeRef(_28297);
    _28297 = NOVALUE;
    DeRef(_28267);
    _28267 = NOVALUE;
    DeRef(_28291);
    _28291 = NOVALUE;
    DeRef(_28240);
    _28240 = NOVALUE;
    DeRef(_28289);
    _28289 = NOVALUE;
    DeRef(_28272);
    _28272 = NOVALUE;
    DeRef(_28249);
    _28249 = NOVALUE;
    DeRef(_28282);
    _28282 = NOVALUE;
    DeRef(_28248);
    _28248 = NOVALUE;
    DeRef(_28305);
    _28305 = NOVALUE;
    DeRef(_28268);
    _28268 = NOVALUE;
    DeRef(_28253);
    _28253 = NOVALUE;
    DeRef(_28261);
    _28261 = NOVALUE;
    DeRef(_28236);
    _28236 = NOVALUE;
    DeRef(_28308);
    _28308 = NOVALUE;
    return;
    ;
}


void _43InitDelete()
{
    object _28324 = NOVALUE;
    object _28323 = NOVALUE;
    object _28321 = NOVALUE;
    object _28320 = NOVALUE;
    object _28319 = NOVALUE;
    object _28318 = NOVALUE;
    object _28317 = NOVALUE;
    object _28316 = NOVALUE;
    object _28315 = NOVALUE;
    object _28314 = NOVALUE;
    object _28313 = NOVALUE;
    object _28312 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:354		while length(init_stack) and*/
L1: 
    if (IS_SEQUENCE(_43init_stack_55501)){
            _28312 = SEQ_PTR(_43init_stack_55501)->length;
    }
    else {
        _28312 = 1;
    }
    if (_28312 == 0) {
        goto L2; // [11] 91
    }
    if (IS_SEQUENCE(_43init_stack_55501)){
            _28314 = SEQ_PTR(_43init_stack_55501)->length;
    }
    else {
        _28314 = 1;
    }
    _2 = (object)SEQ_PTR(_43init_stack_55501);
    _28315 = (object)*(((s1_ptr)_2)->base + _28314);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28316 = (object)*(((s1_ptr)_2)->base + _28315);
    _2 = (object)SEQ_PTR(_28316);
    _28317 = (object)*(((s1_ptr)_2)->base + 14LL);
    _28316 = NOVALUE;
    if (IS_ATOM_INT(_28317)) {
        _28318 = (_28317 > _43stmt_nest_55500);
    }
    else {
        _28318 = binary_op(GREATER, _28317, _43stmt_nest_55500);
    }
    _28317 = NOVALUE;
    if (_28318 <= 0) {
        if (_28318 == 0) {
            DeRef(_28318);
            _28318 = NOVALUE;
            goto L2; // [43] 91
        }
        else {
            if (!IS_ATOM_INT(_28318) && DBL_PTR(_28318)->dbl == 0.0){
                DeRef(_28318);
                _28318 = NOVALUE;
                goto L2; // [43] 91
            }
            DeRef(_28318);
            _28318 = NOVALUE;
        }
    }
    DeRef(_28318);
    _28318 = NOVALUE;

    /** parser.e:356			SymTab[init_stack[$]][S_INITLEVEL] = -1*/
    if (IS_SEQUENCE(_43init_stack_55501)){
            _28319 = SEQ_PTR(_43init_stack_55501)->length;
    }
    else {
        _28319 = 1;
    }
    _2 = (object)SEQ_PTR(_43init_stack_55501);
    _28320 = (object)*(((s1_ptr)_2)->base + _28319);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_28320 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1LL;
    DeRef(_1);
    _28321 = NOVALUE;

    /** parser.e:357			init_stack = init_stack[1..$-1]*/
    if (IS_SEQUENCE(_43init_stack_55501)){
            _28323 = SEQ_PTR(_43init_stack_55501)->length;
    }
    else {
        _28323 = 1;
    }
    _28324 = _28323 - 1LL;
    _28323 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43init_stack_55501;
    RHS_Slice(_43init_stack_55501, 1LL, _28324);

    /** parser.e:358		end while*/
    goto L1; // [88] 6
L2: 

    /** parser.e:359	end procedure*/
    _28315 = NOVALUE;
    _28320 = NOVALUE;
    DeRef(_28324);
    _28324 = NOVALUE;
    return;
    ;
}


void _43emit_forward_addr()
{
    object _28326 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:364		emit_addr(0)*/
    _45emit_addr(0LL);

    /** parser.e:365		branch_list = append(branch_list, length(Code))*/
    if (IS_SEQUENCE(_27Code_20660)){
            _28326 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _28326 = 1;
    }
    Append(&_43branch_list_55466, _43branch_list_55466, _28326);
    _28326 = NOVALUE;

    /** parser.e:366	end procedure*/
    return;
    ;
}


void _43StraightenBranches()
{
    object _br_55977 = NOVALUE;
    object _target_55978 = NOVALUE;
    object _28347 = NOVALUE;
    object _28346 = NOVALUE;
    object _28345 = NOVALUE;
    object _28344 = NOVALUE;
    object _28342 = NOVALUE;
    object _28341 = NOVALUE;
    object _28340 = NOVALUE;
    object _28338 = NOVALUE;
    object _28337 = NOVALUE;
    object _28336 = NOVALUE;
    object _28335 = NOVALUE;
    object _28333 = NOVALUE;
    object _28330 = NOVALUE;
    object _28329 = NOVALUE;
    object _28328 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:373		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L1; // [5] 14
    }
    else{
    }

    /** parser.e:374			return -- do it in back-end*/
    return;
L1: 

    /** parser.e:376		for i = length(branch_list) to 1 by -1 do*/
    if (IS_SEQUENCE(_43branch_list_55466)){
            _28328 = SEQ_PTR(_43branch_list_55466)->length;
    }
    else {
        _28328 = 1;
    }
    {
        object _i_55982;
        _i_55982 = _28328;
L2: 
        if (_i_55982 < 1LL){
            goto L3; // [21] 170
        }

        /** parser.e:377			if branch_list[i] > length(Code) then*/
        _2 = (object)SEQ_PTR(_43branch_list_55466);
        _28329 = (object)*(((s1_ptr)_2)->base + _i_55982);
        if (IS_SEQUENCE(_27Code_20660)){
                _28330 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _28330 = 1;
        }
        if (binary_op_a(LESSEQ, _28329, _28330)){
            _28329 = NOVALUE;
            _28330 = NOVALUE;
            goto L4; // [41] 53
        }
        _28329 = NOVALUE;
        _28330 = NOVALUE;

        /** parser.e:378				CompileErr("wtf")*/
        RefDS(_28332);
        RefDS(_22218);
        _49CompileErr(_28332, _22218, 0LL);
L4: 

        /** parser.e:380			target = Code[branch_list[i]]*/
        _2 = (object)SEQ_PTR(_43branch_list_55466);
        _28333 = (object)*(((s1_ptr)_2)->base + _i_55982);
        _2 = (object)SEQ_PTR(_27Code_20660);
        if (!IS_ATOM_INT(_28333)){
            _target_55978 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28333)->dbl));
        }
        else{
            _target_55978 = (object)*(((s1_ptr)_2)->base + _28333);
        }
        if (!IS_ATOM_INT(_target_55978)){
            _target_55978 = (object)DBL_PTR(_target_55978)->dbl;
        }

        /** parser.e:381			if target <= length(Code) and target > 0 then*/
        if (IS_SEQUENCE(_27Code_20660)){
                _28335 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _28335 = 1;
        }
        _28336 = (_target_55978 <= _28335);
        _28335 = NOVALUE;
        if (_28336 == 0) {
            goto L5; // [80] 163
        }
        _28338 = (_target_55978 > 0LL);
        if (_28338 == 0)
        {
            DeRef(_28338);
            _28338 = NOVALUE;
            goto L5; // [89] 163
        }
        else{
            DeRef(_28338);
            _28338 = NOVALUE;
        }

        /** parser.e:382				br = Code[target]*/
        _2 = (object)SEQ_PTR(_27Code_20660);
        _br_55977 = (object)*(((s1_ptr)_2)->base + _target_55978);
        if (!IS_ATOM_INT(_br_55977)){
            _br_55977 = (object)DBL_PTR(_br_55977)->dbl;
        }

        /** parser.e:383				if br = ELSE or br = ENDWHILE or br = EXIT then*/
        _28340 = (_br_55977 == 23LL);
        if (_28340 != 0) {
            _28341 = 1;
            goto L6; // [110] 124
        }
        _28342 = (_br_55977 == 22LL);
        _28341 = (_28342 != 0);
L6: 
        if (_28341 != 0) {
            goto L7; // [124] 139
        }
        _28344 = (_br_55977 == 61LL);
        if (_28344 == 0)
        {
            DeRef(_28344);
            _28344 = NOVALUE;
            goto L8; // [135] 162
        }
        else{
            DeRef(_28344);
            _28344 = NOVALUE;
        }
L7: 

        /** parser.e:384					backpatch(branch_list[i], Code[target+1])*/
        _2 = (object)SEQ_PTR(_43branch_list_55466);
        _28345 = (object)*(((s1_ptr)_2)->base + _i_55982);
        _28346 = _target_55978 + 1;
        _2 = (object)SEQ_PTR(_27Code_20660);
        _28347 = (object)*(((s1_ptr)_2)->base + _28346);
        Ref(_28345);
        Ref(_28347);
        _45backpatch(_28345, _28347);
        _28345 = NOVALUE;
        _28347 = NOVALUE;
L8: 
L5: 

        /** parser.e:387		end for*/
        _i_55982 = _i_55982 + -1LL;
        goto L2; // [165] 28
L3: 
        ;
    }

    /** parser.e:388		branch_list = {}*/
    RefDS(_22218);
    DeRef(_43branch_list_55466);
    _43branch_list_55466 = _22218;

    /** parser.e:389	end procedure*/
    _28333 = NOVALUE;
    DeRef(_28336);
    _28336 = NOVALUE;
    DeRef(_28342);
    _28342 = NOVALUE;
    DeRef(_28340);
    _28340 = NOVALUE;
    DeRef(_28346);
    _28346 = NOVALUE;
    return;
    ;
}


void _43PatchEList(object _base_56030)
{
    object _break_top_56031 = NOVALUE;
    object _n_56032 = NOVALUE;
    object _28364 = NOVALUE;
    object _28363 = NOVALUE;
    object _28362 = NOVALUE;
    object _28358 = NOVALUE;
    object _28357 = NOVALUE;
    object _28356 = NOVALUE;
    object _28354 = NOVALUE;
    object _28353 = NOVALUE;
    object _28351 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:410		if not length(break_list) then*/
    if (IS_SEQUENCE(_43break_list_55486)){
            _28351 = SEQ_PTR(_43break_list_55486)->length;
    }
    else {
        _28351 = 1;
    }
    if (_28351 != 0)
    goto L1; // [10] 19
    _28351 = NOVALUE;

    /** parser.e:411			return*/
    return;
L1: 

    /** parser.e:414		break_top = 0*/
    _break_top_56031 = 0LL;

    /** parser.e:415		for i=length(break_list) to base+1 by -1 do*/
    if (IS_SEQUENCE(_43break_list_55486)){
            _28353 = SEQ_PTR(_43break_list_55486)->length;
    }
    else {
        _28353 = 1;
    }
    _28354 = _base_56030 + 1;
    if (_28354 > MAXINT){
        _28354 = NewDouble((eudouble)_28354);
    }
    {
        object _i_56037;
        _i_56037 = _28353;
L2: 
        if (binary_op_a(LESS, _i_56037, _28354)){
            goto L3; // [35] 129
        }

        /** parser.e:416			n=break_delay[i]*/
        _2 = (object)SEQ_PTR(_43break_delay_55487);
        if (!IS_ATOM_INT(_i_56037)){
            _n_56032 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_56037)->dbl));
        }
        else{
            _n_56032 = (object)*(((s1_ptr)_2)->base + _i_56037);
        }
        if (!IS_ATOM_INT(_n_56032))
        _n_56032 = (object)DBL_PTR(_n_56032)->dbl;

        /** parser.e:417			break_delay[i] -= (n>0)*/
        _28356 = (_n_56032 > 0LL);
        _2 = (object)SEQ_PTR(_43break_delay_55487);
        if (!IS_ATOM_INT(_i_56037)){
            _28357 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_56037)->dbl));
        }
        else{
            _28357 = (object)*(((s1_ptr)_2)->base + _i_56037);
        }
        if (IS_ATOM_INT(_28357)) {
            _28358 = _28357 - _28356;
            if ((object)((uintptr_t)_28358 +(uintptr_t) HIGH_BITS) >= 0){
                _28358 = NewDouble((eudouble)_28358);
            }
        }
        else {
            _28358 = binary_op(MINUS, _28357, _28356);
        }
        _28357 = NOVALUE;
        _28356 = NOVALUE;
        _2 = (object)SEQ_PTR(_43break_delay_55487);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _43break_delay_55487 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_56037))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_56037)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _i_56037);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _28358;
        if( _1 != _28358 ){
            DeRef(_1);
        }
        _28358 = NOVALUE;

        /** parser.e:418			if n>1 then*/
        if (_n_56032 <= 1LL)
        goto L4; // [72] 93

        /** parser.e:419				if break_top = 0 then*/
        if (_break_top_56031 != 0LL)
        goto L5; // [78] 122

        /** parser.e:420					break_top = i*/
        Ref(_i_56037);
        _break_top_56031 = _i_56037;
        if (!IS_ATOM_INT(_break_top_56031)) {
            _1 = (object)(DBL_PTR(_break_top_56031)->dbl);
            DeRefDS(_break_top_56031);
            _break_top_56031 = _1;
        }
        goto L5; // [90] 122
L4: 

        /** parser.e:422			elsif n=1 then*/
        if (_n_56032 != 1LL)
        goto L6; // [95] 121

        /** parser.e:423				backpatch(break_list[i],length(Code)+1)*/
        _2 = (object)SEQ_PTR(_43break_list_55486);
        if (!IS_ATOM_INT(_i_56037)){
            _28362 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_56037)->dbl));
        }
        else{
            _28362 = (object)*(((s1_ptr)_2)->base + _i_56037);
        }
        if (IS_SEQUENCE(_27Code_20660)){
                _28363 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _28363 = 1;
        }
        _28364 = _28363 + 1;
        _28363 = NOVALUE;
        _45backpatch(_28362, _28364);
        _28362 = NOVALUE;
        _28364 = NOVALUE;
L6: 
L5: 

        /** parser.e:425		end for*/
        _0 = _i_56037;
        if (IS_ATOM_INT(_i_56037)) {
            _i_56037 = _i_56037 + -1LL;
            if ((object)((uintptr_t)_i_56037 +(uintptr_t) HIGH_BITS) >= 0){
                _i_56037 = NewDouble((eudouble)_i_56037);
            }
        }
        else {
            _i_56037 = binary_op_a(PLUS, _i_56037, -1LL);
        }
        DeRef(_0);
        goto L2; // [124] 42
L3: 
        ;
        DeRef(_i_56037);
    }

    /** parser.e:427		if break_top=0 then*/
    if (_break_top_56031 != 0LL)
    goto L7; // [131] 141

    /** parser.e:428		    break_top=base*/
    _break_top_56031 = _base_56030;
L7: 

    /** parser.e:431		break_delay = break_delay[1..break_top]*/
    rhs_slice_target = (object_ptr)&_43break_delay_55487;
    RHS_Slice(_43break_delay_55487, 1LL, _break_top_56031);

    /** parser.e:432		break_list = break_list[1..break_top]*/
    rhs_slice_target = (object_ptr)&_43break_list_55486;
    RHS_Slice(_43break_list_55486, 1LL, _break_top_56031);

    /** parser.e:433	end procedure*/
    DeRef(_28354);
    _28354 = NOVALUE;
    return;
    ;
}


void _43PatchNList(object _base_56061)
{
    object _next_top_56062 = NOVALUE;
    object _n_56063 = NOVALUE;
    object _28381 = NOVALUE;
    object _28380 = NOVALUE;
    object _28379 = NOVALUE;
    object _28375 = NOVALUE;
    object _28374 = NOVALUE;
    object _28373 = NOVALUE;
    object _28371 = NOVALUE;
    object _28370 = NOVALUE;
    object _28368 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:439		if not length(continue_list) then*/
    if (IS_SEQUENCE(_43continue_list_55490)){
            _28368 = SEQ_PTR(_43continue_list_55490)->length;
    }
    else {
        _28368 = 1;
    }
    if (_28368 != 0)
    goto L1; // [10] 19
    _28368 = NOVALUE;

    /** parser.e:440			return*/
    return;
L1: 

    /** parser.e:443		next_top = 0*/
    _next_top_56062 = 0LL;

    /** parser.e:445		for i=length(continue_list) to base+1 by -1 do*/
    if (IS_SEQUENCE(_43continue_list_55490)){
            _28370 = SEQ_PTR(_43continue_list_55490)->length;
    }
    else {
        _28370 = 1;
    }
    _28371 = _base_56061 + 1;
    if (_28371 > MAXINT){
        _28371 = NewDouble((eudouble)_28371);
    }
    {
        object _i_56068;
        _i_56068 = _28370;
L2: 
        if (binary_op_a(LESS, _i_56068, _28371)){
            goto L3; // [35] 129
        }

        /** parser.e:446			n=continue_delay[i]*/
        _2 = (object)SEQ_PTR(_43continue_delay_55491);
        if (!IS_ATOM_INT(_i_56068)){
            _n_56063 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_56068)->dbl));
        }
        else{
            _n_56063 = (object)*(((s1_ptr)_2)->base + _i_56068);
        }
        if (!IS_ATOM_INT(_n_56063))
        _n_56063 = (object)DBL_PTR(_n_56063)->dbl;

        /** parser.e:447			continue_delay[i] -= (n>0)*/
        _28373 = (_n_56063 > 0LL);
        _2 = (object)SEQ_PTR(_43continue_delay_55491);
        if (!IS_ATOM_INT(_i_56068)){
            _28374 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_56068)->dbl));
        }
        else{
            _28374 = (object)*(((s1_ptr)_2)->base + _i_56068);
        }
        if (IS_ATOM_INT(_28374)) {
            _28375 = _28374 - _28373;
            if ((object)((uintptr_t)_28375 +(uintptr_t) HIGH_BITS) >= 0){
                _28375 = NewDouble((eudouble)_28375);
            }
        }
        else {
            _28375 = binary_op(MINUS, _28374, _28373);
        }
        _28374 = NOVALUE;
        _28373 = NOVALUE;
        _2 = (object)SEQ_PTR(_43continue_delay_55491);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _43continue_delay_55491 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_56068))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_56068)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _i_56068);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _28375;
        if( _1 != _28375 ){
            DeRef(_1);
        }
        _28375 = NOVALUE;

        /** parser.e:448			if n>1 then*/
        if (_n_56063 <= 1LL)
        goto L4; // [72] 93

        /** parser.e:449				if next_top = 0 then*/
        if (_next_top_56062 != 0LL)
        goto L5; // [78] 122

        /** parser.e:450					next_top = i*/
        Ref(_i_56068);
        _next_top_56062 = _i_56068;
        if (!IS_ATOM_INT(_next_top_56062)) {
            _1 = (object)(DBL_PTR(_next_top_56062)->dbl);
            DeRefDS(_next_top_56062);
            _next_top_56062 = _1;
        }
        goto L5; // [90] 122
L4: 

        /** parser.e:452			elsif n=1 then*/
        if (_n_56063 != 1LL)
        goto L6; // [95] 121

        /** parser.e:453				backpatch(continue_list[i],length(Code)+1)*/
        _2 = (object)SEQ_PTR(_43continue_list_55490);
        if (!IS_ATOM_INT(_i_56068)){
            _28379 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_56068)->dbl));
        }
        else{
            _28379 = (object)*(((s1_ptr)_2)->base + _i_56068);
        }
        if (IS_SEQUENCE(_27Code_20660)){
                _28380 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _28380 = 1;
        }
        _28381 = _28380 + 1;
        _28380 = NOVALUE;
        _45backpatch(_28379, _28381);
        _28379 = NOVALUE;
        _28381 = NOVALUE;
L6: 
L5: 

        /** parser.e:455		end for*/
        _0 = _i_56068;
        if (IS_ATOM_INT(_i_56068)) {
            _i_56068 = _i_56068 + -1LL;
            if ((object)((uintptr_t)_i_56068 +(uintptr_t) HIGH_BITS) >= 0){
                _i_56068 = NewDouble((eudouble)_i_56068);
            }
        }
        else {
            _i_56068 = binary_op_a(PLUS, _i_56068, -1LL);
        }
        DeRef(_0);
        goto L2; // [124] 42
L3: 
        ;
        DeRef(_i_56068);
    }

    /** parser.e:457		if next_top=0 then*/
    if (_next_top_56062 != 0LL)
    goto L7; // [131] 141

    /** parser.e:458		    next_top=base*/
    _next_top_56062 = _base_56061;
L7: 

    /** parser.e:461		continue_delay =continue_delay[1..next_top]*/
    rhs_slice_target = (object_ptr)&_43continue_delay_55491;
    RHS_Slice(_43continue_delay_55491, 1LL, _next_top_56062);

    /** parser.e:462		continue_list = continue_list[1..next_top]*/
    rhs_slice_target = (object_ptr)&_43continue_list_55490;
    RHS_Slice(_43continue_list_55490, 1LL, _next_top_56062);

    /** parser.e:463	end procedure*/
    DeRef(_28371);
    _28371 = NOVALUE;
    return;
    ;
}


void _43PatchXList(object _base_56092)
{
    object _exit_top_56093 = NOVALUE;
    object _n_56094 = NOVALUE;
    object _28398 = NOVALUE;
    object _28397 = NOVALUE;
    object _28396 = NOVALUE;
    object _28392 = NOVALUE;
    object _28391 = NOVALUE;
    object _28390 = NOVALUE;
    object _28388 = NOVALUE;
    object _28387 = NOVALUE;
    object _28385 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:469		if not length(exit_list) then*/
    if (IS_SEQUENCE(_43exit_list_55488)){
            _28385 = SEQ_PTR(_43exit_list_55488)->length;
    }
    else {
        _28385 = 1;
    }
    if (_28385 != 0)
    goto L1; // [10] 19
    _28385 = NOVALUE;

    /** parser.e:470			return*/
    return;
L1: 

    /** parser.e:473		exit_top = 0*/
    _exit_top_56093 = 0LL;

    /** parser.e:475		for i=length(exit_list) to base+1 by -1 do*/
    if (IS_SEQUENCE(_43exit_list_55488)){
            _28387 = SEQ_PTR(_43exit_list_55488)->length;
    }
    else {
        _28387 = 1;
    }
    _28388 = _base_56092 + 1;
    if (_28388 > MAXINT){
        _28388 = NewDouble((eudouble)_28388);
    }
    {
        object _i_56099;
        _i_56099 = _28387;
L2: 
        if (binary_op_a(LESS, _i_56099, _28388)){
            goto L3; // [35] 129
        }

        /** parser.e:476			n=exit_delay[i]*/
        _2 = (object)SEQ_PTR(_43exit_delay_55489);
        if (!IS_ATOM_INT(_i_56099)){
            _n_56094 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_56099)->dbl));
        }
        else{
            _n_56094 = (object)*(((s1_ptr)_2)->base + _i_56099);
        }
        if (!IS_ATOM_INT(_n_56094))
        _n_56094 = (object)DBL_PTR(_n_56094)->dbl;

        /** parser.e:477			exit_delay[i] -= (n>0)*/
        _28390 = (_n_56094 > 0LL);
        _2 = (object)SEQ_PTR(_43exit_delay_55489);
        if (!IS_ATOM_INT(_i_56099)){
            _28391 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_56099)->dbl));
        }
        else{
            _28391 = (object)*(((s1_ptr)_2)->base + _i_56099);
        }
        if (IS_ATOM_INT(_28391)) {
            _28392 = _28391 - _28390;
            if ((object)((uintptr_t)_28392 +(uintptr_t) HIGH_BITS) >= 0){
                _28392 = NewDouble((eudouble)_28392);
            }
        }
        else {
            _28392 = binary_op(MINUS, _28391, _28390);
        }
        _28391 = NOVALUE;
        _28390 = NOVALUE;
        _2 = (object)SEQ_PTR(_43exit_delay_55489);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _43exit_delay_55489 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_56099))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_56099)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _i_56099);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _28392;
        if( _1 != _28392 ){
            DeRef(_1);
        }
        _28392 = NOVALUE;

        /** parser.e:478			if n>1 then*/
        if (_n_56094 <= 1LL)
        goto L4; // [72] 93

        /** parser.e:479				if exit_top = 0 then*/
        if (_exit_top_56093 != 0LL)
        goto L5; // [78] 122

        /** parser.e:480					exit_top = i*/
        Ref(_i_56099);
        _exit_top_56093 = _i_56099;
        if (!IS_ATOM_INT(_exit_top_56093)) {
            _1 = (object)(DBL_PTR(_exit_top_56093)->dbl);
            DeRefDS(_exit_top_56093);
            _exit_top_56093 = _1;
        }
        goto L5; // [90] 122
L4: 

        /** parser.e:482			elsif n=1 then*/
        if (_n_56094 != 1LL)
        goto L6; // [95] 121

        /** parser.e:483				backpatch(exit_list[i],length(Code)+1)*/
        _2 = (object)SEQ_PTR(_43exit_list_55488);
        if (!IS_ATOM_INT(_i_56099)){
            _28396 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_56099)->dbl));
        }
        else{
            _28396 = (object)*(((s1_ptr)_2)->base + _i_56099);
        }
        if (IS_SEQUENCE(_27Code_20660)){
                _28397 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _28397 = 1;
        }
        _28398 = _28397 + 1;
        _28397 = NOVALUE;
        _45backpatch(_28396, _28398);
        _28396 = NOVALUE;
        _28398 = NOVALUE;
L6: 
L5: 

        /** parser.e:485		end for*/
        _0 = _i_56099;
        if (IS_ATOM_INT(_i_56099)) {
            _i_56099 = _i_56099 + -1LL;
            if ((object)((uintptr_t)_i_56099 +(uintptr_t) HIGH_BITS) >= 0){
                _i_56099 = NewDouble((eudouble)_i_56099);
            }
        }
        else {
            _i_56099 = binary_op_a(PLUS, _i_56099, -1LL);
        }
        DeRef(_0);
        goto L2; // [124] 42
L3: 
        ;
        DeRef(_i_56099);
    }

    /** parser.e:487		if exit_top=0 then*/
    if (_exit_top_56093 != 0LL)
    goto L7; // [131] 141

    /** parser.e:488		    exit_top=base*/
    _exit_top_56093 = _base_56092;
L7: 

    /** parser.e:491		exit_delay = exit_delay [1..exit_top]*/
    rhs_slice_target = (object_ptr)&_43exit_delay_55489;
    RHS_Slice(_43exit_delay_55489, 1LL, _exit_top_56093);

    /** parser.e:492		exit_list = exit_list [1..exit_top]*/
    rhs_slice_target = (object_ptr)&_43exit_list_55488;
    RHS_Slice(_43exit_list_55488, 1LL, _exit_top_56093);

    /** parser.e:493	end procedure*/
    DeRef(_28388);
    _28388 = NOVALUE;
    return;
    ;
}


void _43putback(object _t_56124)
{
    object _28403 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:497		backed_up_tok = append(backed_up_tok, t)*/
    Ref(_t_56124);
    Append(&_43backed_up_tok_55475, _43backed_up_tok_55475, _t_56124);

    /** parser.e:499		if t[T_SYM] then*/
    _2 = (object)SEQ_PTR(_t_56124);
    _28403 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (_28403 == 0) {
        _28403 = NOVALUE;
        goto L1; // [17] 79
    }
    else {
        if (!IS_ATOM_INT(_28403) && DBL_PTR(_28403)->dbl == 0.0){
            _28403 = NOVALUE;
            goto L1; // [17] 79
        }
        _28403 = NOVALUE;
    }
    _28403 = NOVALUE;

    /** parser.e:500			putback_ForwardLine     = ForwardLine*/
    Ref(_49ForwardLine_49694);
    DeRef(_49putback_ForwardLine_49695);
    _49putback_ForwardLine_49695 = _49ForwardLine_49694;

    /** parser.e:501			putback_forward_bp      = forward_bp*/
    _49putback_forward_bp_49699 = _49forward_bp_49698;

    /** parser.e:502			putback_fwd_line_number = fwd_line_number*/
    _27putback_fwd_line_number_20574 = _27fwd_line_number_20573;

    /** parser.e:504			if last_fwd_line_number then*/
    if (_27last_fwd_line_number_20575 == 0)
    {
        goto L2; // [49] 78
    }
    else{
    }

    /** parser.e:505				ForwardLine     = last_ForwardLine*/
    Ref(_49last_ForwardLine_49696);
    DeRef(_49ForwardLine_49694);
    _49ForwardLine_49694 = _49last_ForwardLine_49696;

    /** parser.e:506				forward_bp      = last_forward_bp*/
    _49forward_bp_49698 = _49last_forward_bp_49700;

    /** parser.e:507				fwd_line_number = last_fwd_line_number*/
    _27fwd_line_number_20573 = _27last_fwd_line_number_20575;
L2: 
L1: 

    /** parser.e:510	end procedure*/
    DeRef(_t_56124);
    return;
    ;
}


void _43start_recording()
{
    object _0, _1, _2;
    

    /** parser.e:519		psm_stack &= Parser_mode*/
    Append(&_43psm_stack_56143, _43psm_stack_56143, _27Parser_mode_20677);

    /** parser.e:520		can_stack = append(can_stack,canned_tokens)*/
    Ref(_43canned_tokens_55512);
    Append(&_43can_stack_56144, _43can_stack_56144, _43canned_tokens_55512);

    /** parser.e:521		idx_stack &= canned_index*/
    Append(&_43idx_stack_56145, _43idx_stack_56145, _43canned_index_55513);

    /** parser.e:522		tok_stack = append(tok_stack,backed_up_tok)*/
    RefDS(_43backed_up_tok_55475);
    Append(&_43tok_stack_56146, _43tok_stack_56146, _43backed_up_tok_55475);

    /** parser.e:523		canned_tokens = {}*/
    RefDS(_22218);
    DeRef(_43canned_tokens_55512);
    _43canned_tokens_55512 = _22218;

    /** parser.e:524		Parser_mode = PAM_RECORD*/
    _27Parser_mode_20677 = 1LL;

    /** parser.e:525		clear_last()*/
    _45clear_last();

    /** parser.e:526	end procedure*/
    return;
    ;
}


object _43restore_parser()
{
    object _n_56159 = NOVALUE;
    object _tok_56160 = NOVALUE;
    object _x_56161 = NOVALUE;
    object _28434 = NOVALUE;
    object _28433 = NOVALUE;
    object _28432 = NOVALUE;
    object _28430 = NOVALUE;
    object _28426 = NOVALUE;
    object _28425 = NOVALUE;
    object _28423 = NOVALUE;
    object _28421 = NOVALUE;
    object _28420 = NOVALUE;
    object _28418 = NOVALUE;
    object _28416 = NOVALUE;
    object _28415 = NOVALUE;
    object _28413 = NOVALUE;
    object _28411 = NOVALUE;
    object _28410 = NOVALUE;
    object _28408 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:533		n=Parser_mode*/
    _n_56159 = _27Parser_mode_20677;

    /** parser.e:534		x = canned_tokens*/
    Ref(_43canned_tokens_55512);
    DeRef(_x_56161);
    _x_56161 = _43canned_tokens_55512;

    /** parser.e:535		canned_tokens = can_stack[$]*/
    if (IS_SEQUENCE(_43can_stack_56144)){
            _28408 = SEQ_PTR(_43can_stack_56144)->length;
    }
    else {
        _28408 = 1;
    }
    DeRef(_43canned_tokens_55512);
    _2 = (object)SEQ_PTR(_43can_stack_56144);
    _43canned_tokens_55512 = (object)*(((s1_ptr)_2)->base + _28408);
    Ref(_43canned_tokens_55512);

    /** parser.e:536		can_stack     = can_stack[1..$-1]*/
    if (IS_SEQUENCE(_43can_stack_56144)){
            _28410 = SEQ_PTR(_43can_stack_56144)->length;
    }
    else {
        _28410 = 1;
    }
    _28411 = _28410 - 1LL;
    _28410 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43can_stack_56144;
    RHS_Slice(_43can_stack_56144, 1LL, _28411);

    /** parser.e:537		canned_index  = idx_stack[$]*/
    if (IS_SEQUENCE(_43idx_stack_56145)){
            _28413 = SEQ_PTR(_43idx_stack_56145)->length;
    }
    else {
        _28413 = 1;
    }
    _2 = (object)SEQ_PTR(_43idx_stack_56145);
    _43canned_index_55513 = (object)*(((s1_ptr)_2)->base + _28413);

    /** parser.e:538		idx_stack     = idx_stack[1..$-1]*/
    if (IS_SEQUENCE(_43idx_stack_56145)){
            _28415 = SEQ_PTR(_43idx_stack_56145)->length;
    }
    else {
        _28415 = 1;
    }
    _28416 = _28415 - 1LL;
    _28415 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43idx_stack_56145;
    RHS_Slice(_43idx_stack_56145, 1LL, _28416);

    /** parser.e:539		Parser_mode   = psm_stack[$]*/
    if (IS_SEQUENCE(_43psm_stack_56143)){
            _28418 = SEQ_PTR(_43psm_stack_56143)->length;
    }
    else {
        _28418 = 1;
    }
    _2 = (object)SEQ_PTR(_43psm_stack_56143);
    _27Parser_mode_20677 = (object)*(((s1_ptr)_2)->base + _28418);

    /** parser.e:540		psm_stack     = psm_stack[1..$-1]*/
    if (IS_SEQUENCE(_43psm_stack_56143)){
            _28420 = SEQ_PTR(_43psm_stack_56143)->length;
    }
    else {
        _28420 = 1;
    }
    _28421 = _28420 - 1LL;
    _28420 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43psm_stack_56143;
    RHS_Slice(_43psm_stack_56143, 1LL, _28421);

    /** parser.e:541		tok 		  = tok_stack[$]*/
    if (IS_SEQUENCE(_43tok_stack_56146)){
            _28423 = SEQ_PTR(_43tok_stack_56146)->length;
    }
    else {
        _28423 = 1;
    }
    DeRef(_tok_56160);
    _2 = (object)SEQ_PTR(_43tok_stack_56146);
    _tok_56160 = (object)*(((s1_ptr)_2)->base + _28423);
    RefDS(_tok_56160);

    /** parser.e:542		tok_stack 	  = tok_stack[1..$-1]*/
    if (IS_SEQUENCE(_43tok_stack_56146)){
            _28425 = SEQ_PTR(_43tok_stack_56146)->length;
    }
    else {
        _28425 = 1;
    }
    _28426 = _28425 - 1LL;
    _28425 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43tok_stack_56146;
    RHS_Slice(_43tok_stack_56146, 1LL, _28426);

    /** parser.e:543		clear_last()*/
    _45clear_last();

    /** parser.e:544		if n=PAM_PLAYBACK then*/
    if (_n_56159 != -1LL)
    goto L1; // [137] 150

    /** parser.e:545			return {}*/
    RefDS(_22218);
    DeRefDS(_tok_56160);
    DeRefDS(_x_56161);
    _28426 = NOVALUE;
    _28421 = NOVALUE;
    _28416 = NOVALUE;
    _28411 = NOVALUE;
    return _22218;
    goto L2; // [147] 167
L1: 

    /** parser.e:547		elsif n = PAM_NORMAL then*/
    if (_n_56159 != 0LL)
    goto L3; // [154] 166

    /** parser.e:548			use_private_list = 0*/
    _27use_private_list_20685 = 0LL;
L3: 
L2: 

    /** parser.e:550		if length(backed_up_tok) > 0 then*/
    if (IS_SEQUENCE(_43backed_up_tok_55475)){
            _28430 = SEQ_PTR(_43backed_up_tok_55475)->length;
    }
    else {
        _28430 = 1;
    }
    if (_28430 <= 0LL)
    goto L4; // [174] 199

    /** parser.e:551			return x[1..$-1]*/
    if (IS_SEQUENCE(_x_56161)){
            _28432 = SEQ_PTR(_x_56161)->length;
    }
    else {
        _28432 = 1;
    }
    _28433 = _28432 - 1LL;
    _28432 = NOVALUE;
    rhs_slice_target = (object_ptr)&_28434;
    RHS_Slice(_x_56161, 1LL, _28433);
    DeRef(_tok_56160);
    DeRefDS(_x_56161);
    _28433 = NOVALUE;
    DeRef(_28426);
    _28426 = NOVALUE;
    DeRef(_28421);
    _28421 = NOVALUE;
    DeRef(_28416);
    _28416 = NOVALUE;
    DeRef(_28411);
    _28411 = NOVALUE;
    return _28434;
    goto L5; // [196] 206
L4: 

    /** parser.e:553			return x*/
    DeRef(_tok_56160);
    DeRef(_28433);
    _28433 = NOVALUE;
    DeRef(_28434);
    _28434 = NOVALUE;
    DeRef(_28426);
    _28426 = NOVALUE;
    DeRef(_28421);
    _28421 = NOVALUE;
    DeRef(_28416);
    _28416 = NOVALUE;
    DeRef(_28411);
    _28411 = NOVALUE;
    return _x_56161;
L5: 
    ;
}


void _43start_playback(object _s_56201)
{
    object _0, _1, _2;
    

    /** parser.e:558		psm_stack &= Parser_mode*/
    Append(&_43psm_stack_56143, _43psm_stack_56143, _27Parser_mode_20677);

    /** parser.e:559		can_stack = append(can_stack,canned_tokens)*/
    Ref(_43canned_tokens_55512);
    Append(&_43can_stack_56144, _43can_stack_56144, _43canned_tokens_55512);

    /** parser.e:560		idx_stack &= canned_index*/
    Append(&_43idx_stack_56145, _43idx_stack_56145, _43canned_index_55513);

    /** parser.e:561		tok_stack = append(tok_stack,backed_up_tok)*/
    RefDS(_43backed_up_tok_55475);
    Append(&_43tok_stack_56146, _43tok_stack_56146, _43backed_up_tok_55475);

    /** parser.e:562		canned_index = 1*/
    _43canned_index_55513 = 1LL;

    /** parser.e:563		canned_tokens = s*/
    RefDS(_s_56201);
    DeRef(_43canned_tokens_55512);
    _43canned_tokens_55512 = _s_56201;

    /** parser.e:564		backed_up_tok = {}*/
    RefDS(_22218);
    DeRefDS(_43backed_up_tok_55475);
    _43backed_up_tok_55475 = _22218;

    /** parser.e:565		Parser_mode = PAM_PLAYBACK*/
    _27Parser_mode_20677 = -1LL;

    /** parser.e:566	end procedure*/
    DeRefDS(_s_56201);
    return;
    ;
}


void _43restore_parseargs_states()
{
    object _s_56220 = NOVALUE;
    object _n_56221 = NOVALUE;
    object _28451 = NOVALUE;
    object _28450 = NOVALUE;
    object _28442 = NOVALUE;
    object _28441 = NOVALUE;
    object _28439 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:584		s = parseargs_states[$]*/
    if (IS_SEQUENCE(_43parseargs_states_56209)){
            _28439 = SEQ_PTR(_43parseargs_states_56209)->length;
    }
    else {
        _28439 = 1;
    }
    DeRef(_s_56220);
    _2 = (object)SEQ_PTR(_43parseargs_states_56209);
    _s_56220 = (object)*(((s1_ptr)_2)->base + _28439);
    RefDS(_s_56220);

    /** parser.e:585		parseargs_states = parseargs_states[1..$-1]*/
    if (IS_SEQUENCE(_43parseargs_states_56209)){
            _28441 = SEQ_PTR(_43parseargs_states_56209)->length;
    }
    else {
        _28441 = 1;
    }
    _28442 = _28441 - 1LL;
    _28441 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43parseargs_states_56209;
    RHS_Slice(_43parseargs_states_56209, 1LL, _28442);

    /** parser.e:586		n=s[PS_POSITION]*/
    _2 = (object)SEQ_PTR(_s_56220);
    _n_56221 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_n_56221))
    _n_56221 = (object)DBL_PTR(_n_56221)->dbl;

    /** parser.e:587		private_list = private_list[1..n]*/
    rhs_slice_target = (object_ptr)&_43private_list_56214;
    RHS_Slice(_43private_list_56214, 1LL, _n_56221);

    /** parser.e:588		private_sym = private_sym[1..n]*/
    rhs_slice_target = (object_ptr)&_27private_sym_20684;
    RHS_Slice(_27private_sym_20684, 1LL, _n_56221);

    /** parser.e:589		lock_scanner = s[PS_SCAN_LOCK]*/
    _2 = (object)SEQ_PTR(_s_56220);
    _43lock_scanner_56215 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_43lock_scanner_56215))
    _43lock_scanner_56215 = (object)DBL_PTR(_43lock_scanner_56215)->dbl;

    /** parser.e:590		use_private_list = s[PS_USE_LIST]*/
    _2 = (object)SEQ_PTR(_s_56220);
    _27use_private_list_20685 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_27use_private_list_20685)){
        _27use_private_list_20685 = (object)DBL_PTR(_27use_private_list_20685)->dbl;
    }

    /** parser.e:591		on_arg = s[PS_ON_ARG]*/
    _2 = (object)SEQ_PTR(_s_56220);
    _43on_arg_56216 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_43on_arg_56216))
    _43on_arg_56216 = (object)DBL_PTR(_43on_arg_56216)->dbl;

    /** parser.e:592		nested_calls = nested_calls[1..$-1]*/
    if (IS_SEQUENCE(_43nested_calls_56217)){
            _28450 = SEQ_PTR(_43nested_calls_56217)->length;
    }
    else {
        _28450 = 1;
    }
    _28451 = _28450 - 1LL;
    _28450 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43nested_calls_56217;
    RHS_Slice(_43nested_calls_56217, 1LL, _28451);

    /** parser.e:593	end procedure*/
    DeRefDS(_s_56220);
    _28442 = NOVALUE;
    _28451 = NOVALUE;
    return;
    ;
}


object _43read_recorded_token(object _n_56241)
{
    object _t_56243 = NOVALUE;
    object _p_56244 = NOVALUE;
    object _prev_Nne_56245 = NOVALUE;
    object _ts_56274 = NOVALUE;
    object _32059 = NOVALUE;
    object _32058 = NOVALUE;
    object _32057 = NOVALUE;
    object _32056 = NOVALUE;
    object _32055 = NOVALUE;
    object _32054 = NOVALUE;
    object _32053 = NOVALUE;
    object _32052 = NOVALUE;
    object _28523 = NOVALUE;
    object _28522 = NOVALUE;
    object _28521 = NOVALUE;
    object _28520 = NOVALUE;
    object _28516 = NOVALUE;
    object _28514 = NOVALUE;
    object _28513 = NOVALUE;
    object _28512 = NOVALUE;
    object _28511 = NOVALUE;
    object _28509 = NOVALUE;
    object _28508 = NOVALUE;
    object _28507 = NOVALUE;
    object _28506 = NOVALUE;
    object _28504 = NOVALUE;
    object _28501 = NOVALUE;
    object _28499 = NOVALUE;
    object _28497 = NOVALUE;
    object _28496 = NOVALUE;
    object _28495 = NOVALUE;
    object _28494 = NOVALUE;
    object _28492 = NOVALUE;
    object _28490 = NOVALUE;
    object _28486 = NOVALUE;
    object _28484 = NOVALUE;
    object _28482 = NOVALUE;
    object _28481 = NOVALUE;
    object _28480 = NOVALUE;
    object _28479 = NOVALUE;
    object _28478 = NOVALUE;
    object _28477 = NOVALUE;
    object _28476 = NOVALUE;
    object _28475 = NOVALUE;
    object _28474 = NOVALUE;
    object _28473 = NOVALUE;
    object _28472 = NOVALUE;
    object _28471 = NOVALUE;
    object _28469 = NOVALUE;
    object _28468 = NOVALUE;
    object _28466 = NOVALUE;
    object _28465 = NOVALUE;
    object _28464 = NOVALUE;
    object _28463 = NOVALUE;
    object _28462 = NOVALUE;
    object _28461 = NOVALUE;
    object _28460 = NOVALUE;
    object _28459 = NOVALUE;
    object _28456 = NOVALUE;
    object _28454 = NOVALUE;
    object _28453 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_n_56241)) {
        _1 = (object)(DBL_PTR(_n_56241)->dbl);
        DeRefDS(_n_56241);
        _n_56241 = _1;
    }

    /** parser.e:597		integer p, prev_Nne*/

    /** parser.e:598		if atom(Ns_recorded[n]) label "top if" then*/
    _2 = (object)SEQ_PTR(_27Ns_recorded_20679);
    _28453 = (object)*(((s1_ptr)_2)->base + _n_56241);
    _28454 = IS_ATOM(_28453);
    _28453 = NOVALUE;
    if (_28454 == 0)
    {
        _28454 = NOVALUE;
        goto L1; // [16] 405
    }
    else{
        _28454 = NOVALUE;
    }

    /** parser.e:599			if use_private_list then*/
    if (_27use_private_list_20685 == 0)
    {
        goto L2; // [23] 171
    }
    else{
    }

    /** parser.e:600				p = find( Recorded[n], private_list)*/
    _2 = (object)SEQ_PTR(_27Recorded_20678);
    _28456 = (object)*(((s1_ptr)_2)->base + _n_56241);
    _p_56244 = find_from(_28456, _43private_list_56214, 1LL);
    _28456 = NOVALUE;

    /** parser.e:601				if p > 0 then -- the value of this parameter is known, use it*/
    if (_p_56244 <= 0LL)
    goto L3; // [43] 170

    /** parser.e:603					if TRANSLATE*/
    if (_27TRANSLATE_20179 == 0) {
        goto L4; // [51] 150
    }
    _2 = (object)SEQ_PTR(_27private_sym_20684);
    _28460 = (object)*(((s1_ptr)_2)->base + _p_56244);
    if (IS_ATOM_INT(_28460)) {
        _28461 = (_28460 < 0LL);
    }
    else {
        _28461 = binary_op(LESS, _28460, 0LL);
    }
    _28460 = NOVALUE;
    if (IS_ATOM_INT(_28461)) {
        if (_28461 != 0) {
            _28462 = 1;
            goto L5; // [65] 97
        }
    }
    else {
        if (DBL_PTR(_28461)->dbl != 0.0) {
            _28462 = 1;
            goto L5; // [65] 97
        }
    }
    _2 = (object)SEQ_PTR(_27private_sym_20684);
    _28463 = (object)*(((s1_ptr)_2)->base + _p_56244);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_28463)){
        _28464 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28463)->dbl));
    }
    else{
        _28464 = (object)*(((s1_ptr)_2)->base + _28463);
    }
    _2 = (object)SEQ_PTR(_28464);
    _28465 = (object)*(((s1_ptr)_2)->base + 3LL);
    _28464 = NOVALUE;
    if (IS_ATOM_INT(_28465)) {
        _28466 = (_28465 == 3LL);
    }
    else {
        _28466 = binary_op(EQUALS, _28465, 3LL);
    }
    _28465 = NOVALUE;
    DeRef(_28462);
    if (IS_ATOM_INT(_28466))
    _28462 = (_28466 != 0);
    else
    _28462 = DBL_PTR(_28466)->dbl != 0.0;
L5: 
    if (_28462 == 0)
    {
        _28462 = NOVALUE;
        goto L4; // [98] 150
    }
    else{
        _28462 = NOVALUE;
    }

    /** parser.e:610						symtab_index ts = NewTempSym()*/
    _ts_56274 = _53NewTempSym(0LL);
    if (!IS_ATOM_INT(_ts_56274)) {
        _1 = (object)(DBL_PTR(_ts_56274)->dbl);
        DeRefDS(_ts_56274);
        _ts_56274 = _1;
    }

    /** parser.e:611						Code &= { ASSIGN, private_sym[p], ts }*/
    _2 = (object)SEQ_PTR(_27private_sym_20684);
    _28468 = (object)*(((s1_ptr)_2)->base + _p_56244);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 18LL;
    Ref(_28468);
    ((intptr_t*)_2)[2] = _28468;
    ((intptr_t*)_2)[3] = _ts_56274;
    _28469 = MAKE_SEQ(_1);
    _28468 = NOVALUE;
    Concat((object_ptr)&_27Code_20660, _27Code_20660, _28469);
    DeRefDS(_28469);
    _28469 = NOVALUE;

    /** parser.e:612						return {VARIABLE, ts}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100LL;
    ((intptr_t *)_2)[2] = _ts_56274;
    _28471 = MAKE_SEQ(_1);
    DeRef(_t_56243);
    DeRef(_28461);
    _28461 = NOVALUE;
    DeRef(_28466);
    _28466 = NOVALUE;
    _28463 = NOVALUE;
    return _28471;
    goto L6; // [147] 169
L4: 

    /** parser.e:614						return {VARIABLE, private_sym[p]}*/
    _2 = (object)SEQ_PTR(_27private_sym_20684);
    _28472 = (object)*(((s1_ptr)_2)->base + _p_56244);
    Ref(_28472);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100LL;
    ((intptr_t *)_2)[2] = _28472;
    _28473 = MAKE_SEQ(_1);
    _28472 = NOVALUE;
    DeRef(_t_56243);
    DeRef(_28461);
    _28461 = NOVALUE;
    DeRef(_28471);
    _28471 = NOVALUE;
    DeRef(_28466);
    _28466 = NOVALUE;
    _28463 = NOVALUE;
    return _28473;
L6: 
L3: 
L2: 

    /** parser.e:620			prev_Nne = No_new_entry*/
    _prev_Nne_56245 = _53No_new_entry_48427;

    /** parser.e:621			No_new_entry = 1*/
    _53No_new_entry_48427 = 1LL;

    /** parser.e:623			if Recorded_sym[n] > 0 and  sym_scope( Recorded_sym[n] ) != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_27Recorded_sym_20680);
    _28474 = (object)*(((s1_ptr)_2)->base + _n_56241);
    if (IS_ATOM_INT(_28474)) {
        _28475 = (_28474 > 0LL);
    }
    else {
        _28475 = binary_op(GREATER, _28474, 0LL);
    }
    _28474 = NOVALUE;
    if (IS_ATOM_INT(_28475)) {
        if (_28475 == 0) {
            goto L7; // [199] 250
        }
    }
    else {
        if (DBL_PTR(_28475)->dbl == 0.0) {
            goto L7; // [199] 250
        }
    }
    _2 = (object)SEQ_PTR(_27Recorded_sym_20680);
    _28477 = (object)*(((s1_ptr)_2)->base + _n_56241);
    Ref(_28477);
    _28478 = _53sym_scope(_28477);
    _28477 = NOVALUE;
    if (IS_ATOM_INT(_28478)) {
        _28479 = (_28478 != 9LL);
    }
    else {
        _28479 = binary_op(NOTEQ, _28478, 9LL);
    }
    DeRef(_28478);
    _28478 = NOVALUE;
    if (_28479 == 0) {
        DeRef(_28479);
        _28479 = NOVALUE;
        goto L7; // [220] 250
    }
    else {
        if (!IS_ATOM_INT(_28479) && DBL_PTR(_28479)->dbl == 0.0){
            DeRef(_28479);
            _28479 = NOVALUE;
            goto L7; // [220] 250
        }
        DeRef(_28479);
        _28479 = NOVALUE;
    }
    DeRef(_28479);
    _28479 = NOVALUE;

    /** parser.e:624				t = { sym_token( Recorded_sym[n] ), Recorded_sym[n] }*/
    _2 = (object)SEQ_PTR(_27Recorded_sym_20680);
    _28480 = (object)*(((s1_ptr)_2)->base + _n_56241);
    Ref(_28480);
    _28481 = _53sym_token(_28480);
    _28480 = NOVALUE;
    _2 = (object)SEQ_PTR(_27Recorded_sym_20680);
    _28482 = (object)*(((s1_ptr)_2)->base + _n_56241);
    Ref(_28482);
    DeRef(_t_56243);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28481;
    ((intptr_t *)_2)[2] = _28482;
    _t_56243 = MAKE_SEQ(_1);
    _28482 = NOVALUE;
    _28481 = NOVALUE;

    /** parser.e:625				break "top if"*/
    goto L8; // [247] 734
L7: 

    /** parser.e:628			t = keyfind(Recorded[n],-1)*/
    _2 = (object)SEQ_PTR(_27Recorded_20678);
    _28484 = (object)*(((s1_ptr)_2)->base + _n_56241);
    RefDS(_28484);
    DeRef(_32058);
    _32058 = _28484;
    _32059 = _53hashfn(_32058);
    _32058 = NOVALUE;
    RefDS(_28484);
    _0 = _t_56243;
    _t_56243 = _53keyfind(_28484, -1LL, _27current_file_no_20571, 0LL, _32059);
    DeRef(_0);
    _28484 = NOVALUE;
    _32059 = NOVALUE;

    /** parser.e:629			if t[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_t_56243);
    _28486 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28486, 509LL)){
        _28486 = NOVALUE;
        goto L8; // [286] 734
    }
    _28486 = NOVALUE;

    /** parser.e:630		        p = Recorded_sym[n]*/
    _2 = (object)SEQ_PTR(_27Recorded_sym_20680);
    _p_56244 = (object)*(((s1_ptr)_2)->base + _n_56241);
    if (!IS_ATOM_INT(_p_56244)){
        _p_56244 = (object)DBL_PTR(_p_56244)->dbl;
    }

    /** parser.e:631		        if p = 0 then*/
    if (_p_56244 != 0LL)
    goto L9; // [302] 382

    /** parser.e:633					No_new_entry = 0*/
    _53No_new_entry_48427 = 0LL;

    /** parser.e:634					t = keyfind( Recorded[n], -1 )*/
    _2 = (object)SEQ_PTR(_27Recorded_20678);
    _28490 = (object)*(((s1_ptr)_2)->base + _n_56241);
    RefDS(_28490);
    DeRef(_32056);
    _32056 = _28490;
    _32057 = _53hashfn(_32056);
    _32056 = NOVALUE;
    RefDS(_28490);
    _0 = _t_56243;
    _t_56243 = _53keyfind(_28490, -1LL, _27current_file_no_20571, 0LL, _32057);
    DeRef(_0);
    _28490 = NOVALUE;
    _32057 = NOVALUE;

    /** parser.e:635					No_new_entry = 1*/
    _53No_new_entry_48427 = 1LL;

    /** parser.e:636					if t[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_t_56243);
    _28492 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28492, 509LL)){
        _28492 = NOVALUE;
        goto L8; // [355] 734
    }
    _28492 = NOVALUE;

    /** parser.e:637						CompileErr(VARIABLE_1_HAS_NOT_BEEN_DECLARED,{Recorded[n]})*/
    _2 = (object)SEQ_PTR(_27Recorded_20678);
    _28494 = (object)*(((s1_ptr)_2)->base + _n_56241);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_28494);
    ((intptr_t*)_2)[1] = _28494;
    _28495 = MAKE_SEQ(_1);
    _28494 = NOVALUE;
    _49CompileErr(157LL, _28495, 0LL);
    _28495 = NOVALUE;
    goto L8; // [379] 734
L9: 

    /** parser.e:640					t = {SymTab[p][S_TOKEN], p}*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28496 = (object)*(((s1_ptr)_2)->base + _p_56244);
    _2 = (object)SEQ_PTR(_28496);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _28497 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _28497 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _28496 = NOVALUE;
    Ref(_28497);
    DeRef(_t_56243);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28497;
    ((intptr_t *)_2)[2] = _p_56244;
    _t_56243 = MAKE_SEQ(_1);
    _28497 = NOVALUE;
    goto L8; // [402] 734
L1: 

    /** parser.e:644			prev_Nne = No_new_entry*/
    _prev_Nne_56245 = _53No_new_entry_48427;

    /** parser.e:645			No_new_entry = 1*/
    _53No_new_entry_48427 = 1LL;

    /** parser.e:646			t = keyfind(Ns_recorded[n],-1, , 1)*/
    _2 = (object)SEQ_PTR(_27Ns_recorded_20679);
    _28499 = (object)*(((s1_ptr)_2)->base + _n_56241);
    Ref(_28499);
    DeRef(_32054);
    _32054 = _28499;
    _32055 = _53hashfn(_32054);
    _32054 = NOVALUE;
    Ref(_28499);
    _0 = _t_56243;
    _t_56243 = _53keyfind(_28499, -1LL, _27current_file_no_20571, 1LL, _32055);
    DeRef(_0);
    _28499 = NOVALUE;
    _32055 = NOVALUE;

    /** parser.e:647			if t[T_ID] != NAMESPACE then*/
    _2 = (object)SEQ_PTR(_t_56243);
    _28501 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _28501, 523LL)){
        _28501 = NOVALUE;
        goto LA; // [456] 524
    }
    _28501 = NOVALUE;

    /** parser.e:648				p = Ns_recorded_sym[n]*/
    _2 = (object)SEQ_PTR(_27Ns_recorded_sym_20681);
    _p_56244 = (object)*(((s1_ptr)_2)->base + _n_56241);
    if (!IS_ATOM_INT(_p_56244)){
        _p_56244 = (object)DBL_PTR(_p_56244)->dbl;
    }

    /** parser.e:649				if p = 0 or sym_token( p ) != NAMESPACE then*/
    _28504 = (_p_56244 == 0LL);
    if (_28504 != 0) {
        goto LB; // [476] 495
    }
    _28506 = _53sym_token(_p_56244);
    if (IS_ATOM_INT(_28506)) {
        _28507 = (_28506 != 523LL);
    }
    else {
        _28507 = binary_op(NOTEQ, _28506, 523LL);
    }
    DeRef(_28506);
    _28506 = NOVALUE;
    if (_28507 == 0) {
        DeRef(_28507);
        _28507 = NOVALUE;
        goto LC; // [491] 515
    }
    else {
        if (!IS_ATOM_INT(_28507) && DBL_PTR(_28507)->dbl == 0.0){
            DeRef(_28507);
            _28507 = NOVALUE;
            goto LC; // [491] 515
        }
        DeRef(_28507);
        _28507 = NOVALUE;
    }
    DeRef(_28507);
    _28507 = NOVALUE;
LB: 

    /** parser.e:650					CompileErr(UNKNOWN_NAMESPACE_1_IN_DEFAULT_ARGUMENT, {Ns_recorded[n]})*/
    _2 = (object)SEQ_PTR(_27Ns_recorded_20679);
    _28508 = (object)*(((s1_ptr)_2)->base + _n_56241);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_28508);
    ((intptr_t*)_2)[1] = _28508;
    _28509 = MAKE_SEQ(_1);
    _28508 = NOVALUE;
    _49CompileErr(153LL, _28509, 0LL);
    _28509 = NOVALUE;
LC: 

    /** parser.e:652				t = {NAMESPACE, p}*/
    DeRef(_t_56243);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 523LL;
    ((intptr_t *)_2)[2] = _p_56244;
    _t_56243 = MAKE_SEQ(_1);
LA: 

    /** parser.e:655			t = keyfind(Recorded[n],SymTab[t[T_SYM]][S_OBJ])*/
    _2 = (object)SEQ_PTR(_27Recorded_20678);
    _28511 = (object)*(((s1_ptr)_2)->base + _n_56241);
    _2 = (object)SEQ_PTR(_t_56243);
    _28512 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_28512)){
        _28513 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28512)->dbl));
    }
    else{
        _28513 = (object)*(((s1_ptr)_2)->base + _28512);
    }
    _2 = (object)SEQ_PTR(_28513);
    _28514 = (object)*(((s1_ptr)_2)->base + 1LL);
    _28513 = NOVALUE;
    RefDS(_28511);
    DeRef(_32052);
    _32052 = _28511;
    _32053 = _53hashfn(_32052);
    _32052 = NOVALUE;
    RefDS(_28511);
    Ref(_28514);
    _0 = _t_56243;
    _t_56243 = _53keyfind(_28511, _28514, _27current_file_no_20571, 0LL, _32053);
    DeRef(_0);
    _28511 = NOVALUE;
    _28514 = NOVALUE;
    _32053 = NOVALUE;

    /** parser.e:656			if t[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_t_56243);
    _28516 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28516, 509LL)){
        _28516 = NOVALUE;
        goto LD; // [577] 636
    }
    _28516 = NOVALUE;

    /** parser.e:657		        p = Recorded_sym[n]*/
    _2 = (object)SEQ_PTR(_27Recorded_sym_20680);
    _p_56244 = (object)*(((s1_ptr)_2)->base + _n_56241);
    if (!IS_ATOM_INT(_p_56244)){
        _p_56244 = (object)DBL_PTR(_p_56244)->dbl;
    }

    /** parser.e:658		        if p = 0 then*/
    if (_p_56244 != 0LL)
    goto LE; // [593] 617

    /** parser.e:659		        	CompileErr(VARIABLE_1_HAS_NOT_BEEN_DECLARED,{Recorded[n]})*/
    _2 = (object)SEQ_PTR(_27Recorded_20678);
    _28520 = (object)*(((s1_ptr)_2)->base + _n_56241);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_28520);
    ((intptr_t*)_2)[1] = _28520;
    _28521 = MAKE_SEQ(_1);
    _28520 = NOVALUE;
    _49CompileErr(157LL, _28521, 0LL);
    _28521 = NOVALUE;
LE: 

    /** parser.e:661			    t = {SymTab[p][S_TOKEN], p}*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28522 = (object)*(((s1_ptr)_2)->base + _p_56244);
    _2 = (object)SEQ_PTR(_28522);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _28523 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _28523 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _28522 = NOVALUE;
    Ref(_28523);
    DeRef(_t_56243);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28523;
    ((intptr_t *)_2)[2] = _p_56244;
    _t_56243 = MAKE_SEQ(_1);
    _28523 = NOVALUE;
LD: 

    /** parser.e:663			n = t[T_ID]*/
    _2 = (object)SEQ_PTR(_t_56243);
    _n_56241 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_n_56241)){
        _n_56241 = (object)DBL_PTR(_n_56241)->dbl;
    }

    /** parser.e:664			if n = VARIABLE then*/
    if (_n_56241 != -100LL)
    goto LF; // [650] 666

    /** parser.e:665				n = QUALIFIED_VARIABLE*/
    _n_56241 = 512LL;
    goto L10; // [663] 725
LF: 

    /** parser.e:666			elsif n = FUNC then*/
    if (_n_56241 != 501LL)
    goto L11; // [670] 686

    /** parser.e:667				n = QUALIFIED_FUNC*/
    _n_56241 = 520LL;
    goto L10; // [683] 725
L11: 

    /** parser.e:668			elsif n = PROC then*/
    if (_n_56241 != 27LL)
    goto L12; // [690] 706

    /** parser.e:669				n = QUALIFIED_PROC*/
    _n_56241 = 521LL;
    goto L10; // [703] 725
L12: 

    /** parser.e:670			elsif n = TYPE then*/
    if (_n_56241 != 504LL)
    goto L13; // [710] 724

    /** parser.e:671				n = QUALIFIED_TYPE*/
    _n_56241 = 522LL;
L13: 
L10: 

    /** parser.e:673			t[T_ID] = n*/
    _2 = (object)SEQ_PTR(_t_56243);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _t_56243 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _n_56241;
    DeRef(_1);
L8: 

    /** parser.e:675		No_new_entry = prev_Nne*/
    _53No_new_entry_48427 = _prev_Nne_56245;

    /** parser.e:676	  	return t*/
    DeRef(_28461);
    _28461 = NOVALUE;
    _28512 = NOVALUE;
    DeRef(_28473);
    _28473 = NOVALUE;
    DeRef(_28504);
    _28504 = NOVALUE;
    DeRef(_28475);
    _28475 = NOVALUE;
    DeRef(_28471);
    _28471 = NOVALUE;
    DeRef(_28466);
    _28466 = NOVALUE;
    _28463 = NOVALUE;
    return _t_56243;
    ;
}


object _43next_token()
{
    object _t_56425 = NOVALUE;
    object _s_56426 = NOVALUE;
    object _28562 = NOVALUE;
    object _28561 = NOVALUE;
    object _28560 = NOVALUE;
    object _28559 = NOVALUE;
    object _28558 = NOVALUE;
    object _28557 = NOVALUE;
    object _28556 = NOVALUE;
    object _28555 = NOVALUE;
    object _28553 = NOVALUE;
    object _28552 = NOVALUE;
    object _28551 = NOVALUE;
    object _28550 = NOVALUE;
    object _28548 = NOVALUE;
    object _28546 = NOVALUE;
    object _28544 = NOVALUE;
    object _28540 = NOVALUE;
    object _28537 = NOVALUE;
    object _28534 = NOVALUE;
    object _28532 = NOVALUE;
    object _28530 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:682		sequence s*/

    /** parser.e:684		if length(backed_up_tok) > 0 then*/
    if (IS_SEQUENCE(_43backed_up_tok_55475)){
            _28530 = SEQ_PTR(_43backed_up_tok_55475)->length;
    }
    else {
        _28530 = 1;
    }
    if (_28530 <= 0LL)
    goto L1; // [10] 82

    /** parser.e:685			t = backed_up_tok[$]*/
    if (IS_SEQUENCE(_43backed_up_tok_55475)){
            _28532 = SEQ_PTR(_43backed_up_tok_55475)->length;
    }
    else {
        _28532 = 1;
    }
    DeRef(_t_56425);
    _2 = (object)SEQ_PTR(_43backed_up_tok_55475);
    _t_56425 = (object)*(((s1_ptr)_2)->base + _28532);
    Ref(_t_56425);

    /** parser.e:686			backed_up_tok = remove( backed_up_tok, length( backed_up_tok ) )*/
    if (IS_SEQUENCE(_43backed_up_tok_55475)){
            _28534 = SEQ_PTR(_43backed_up_tok_55475)->length;
    }
    else {
        _28534 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_43backed_up_tok_55475);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_28534)) ? _28534 : (object)(DBL_PTR(_28534)->dbl);
        int stop = (IS_ATOM_INT(_28534)) ? _28534 : (object)(DBL_PTR(_28534)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_43backed_up_tok_55475), start, &_43backed_up_tok_55475 );
            }
            else Tail(SEQ_PTR(_43backed_up_tok_55475), stop+1, &_43backed_up_tok_55475);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_43backed_up_tok_55475), start, &_43backed_up_tok_55475);
        }
        else {
            assign_slice_seq = &assign_space;
            _43backed_up_tok_55475 = Remove_elements(start, stop, (SEQ_PTR(_43backed_up_tok_55475)->ref == 1));
        }
    }
    _28534 = NOVALUE;
    _28534 = NOVALUE;

    /** parser.e:687			if putback_fwd_line_number then*/
    if (_27putback_fwd_line_number_20574 == 0)
    {
        goto L2; // [43] 349
    }
    else{
    }

    /** parser.e:689				ForwardLine     = putback_ForwardLine*/
    Ref(_49putback_ForwardLine_49695);
    DeRef(_49ForwardLine_49694);
    _49ForwardLine_49694 = _49putback_ForwardLine_49695;

    /** parser.e:690				forward_bp      = putback_forward_bp*/
    _49forward_bp_49698 = _49putback_forward_bp_49699;

    /** parser.e:691				fwd_line_number = putback_fwd_line_number*/
    _27fwd_line_number_20573 = _27putback_fwd_line_number_20574;

    /** parser.e:693				putback_fwd_line_number = 0*/
    _27putback_fwd_line_number_20574 = 0LL;
    goto L2; // [79] 349
L1: 

    /** parser.e:696		elsif Parser_mode = PAM_PLAYBACK then*/
    if (_27Parser_mode_20677 != -1LL)
    goto L3; // [88] 302

    /** parser.e:697			if canned_index <= length(canned_tokens) then*/
    if (IS_SEQUENCE(_43canned_tokens_55512)){
            _28537 = SEQ_PTR(_43canned_tokens_55512)->length;
    }
    else {
        _28537 = 1;
    }
    if (_43canned_index_55513 > _28537)
    goto L4; // [101] 150

    /** parser.e:698				t = canned_tokens[canned_index]*/
    DeRef(_t_56425);
    _2 = (object)SEQ_PTR(_43canned_tokens_55512);
    _t_56425 = (object)*(((s1_ptr)_2)->base + _43canned_index_55513);
    Ref(_t_56425);

    /** parser.e:699				if canned_index < length(canned_tokens) then*/
    if (IS_SEQUENCE(_43canned_tokens_55512)){
            _28540 = SEQ_PTR(_43canned_tokens_55512)->length;
    }
    else {
        _28540 = 1;
    }
    if (_43canned_index_55513 >= _28540)
    goto L5; // [124] 139

    /** parser.e:700					canned_index += 1*/
    _43canned_index_55513 = _43canned_index_55513 + 1;
    goto L6; // [136] 157
L5: 

    /** parser.e:702		            s = restore_parser()*/
    _0 = _s_56426;
    _s_56426 = _43restore_parser();
    DeRef(_0);
    goto L6; // [147] 157
L4: 

    /** parser.e:705		    	InternalErr(266)*/
    RefDS(_22218);
    _49InternalErr(266LL, _22218);
L6: 

    /** parser.e:707			if t[T_ID] = RECORDED then*/
    _2 = (object)SEQ_PTR(_t_56425);
    _28544 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28544, 508LL)){
        _28544 = NOVALUE;
        goto L7; // [169] 188
    }
    _28544 = NOVALUE;

    /** parser.e:708				t=read_recorded_token(t[T_SYM])*/
    _2 = (object)SEQ_PTR(_t_56425);
    _28546 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_28546);
    _0 = _t_56425;
    _t_56425 = _43read_recorded_token(_28546);
    DeRef(_0);
    _28546 = NOVALUE;
    goto L2; // [185] 349
L7: 

    /** parser.e:709			elsif t[T_ID] = DEF_PARAM then*/
    _2 = (object)SEQ_PTR(_t_56425);
    _28548 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28548, 510LL)){
        _28548 = NOVALUE;
        goto L2; // [198] 349
    }
    _28548 = NOVALUE;

    /** parser.e:710	        	for i=length(nested_calls) to 1 by -1 do*/
    if (IS_SEQUENCE(_43nested_calls_56217)){
            _28550 = SEQ_PTR(_43nested_calls_56217)->length;
    }
    else {
        _28550 = 1;
    }
    {
        object _i_56473;
        _i_56473 = _28550;
L8: 
        if (_i_56473 < 1LL){
            goto L9; // [209] 288
        }

        /** parser.e:711	        	    if nested_calls[i] = t[T_SYM][2] then*/
        _2 = (object)SEQ_PTR(_43nested_calls_56217);
        _28551 = (object)*(((s1_ptr)_2)->base + _i_56473);
        _2 = (object)SEQ_PTR(_t_56425);
        _28552 = (object)*(((s1_ptr)_2)->base + 2LL);
        _2 = (object)SEQ_PTR(_28552);
        _28553 = (object)*(((s1_ptr)_2)->base + 2LL);
        _28552 = NOVALUE;
        if (binary_op_a(NOTEQ, _28551, _28553)){
            _28551 = NOVALUE;
            _28553 = NOVALUE;
            goto LA; // [234] 281
        }
        _28551 = NOVALUE;
        _28553 = NOVALUE;

        /** parser.e:712						return {VARIABLE, private_sym[parseargs_states[i][PS_POSITION]+t[T_SYM][1]]}*/
        _2 = (object)SEQ_PTR(_43parseargs_states_56209);
        _28555 = (object)*(((s1_ptr)_2)->base + _i_56473);
        _2 = (object)SEQ_PTR(_28555);
        _28556 = (object)*(((s1_ptr)_2)->base + 1LL);
        _28555 = NOVALUE;
        _2 = (object)SEQ_PTR(_t_56425);
        _28557 = (object)*(((s1_ptr)_2)->base + 2LL);
        _2 = (object)SEQ_PTR(_28557);
        _28558 = (object)*(((s1_ptr)_2)->base + 1LL);
        _28557 = NOVALUE;
        if (IS_ATOM_INT(_28556) && IS_ATOM_INT(_28558)) {
            _28559 = _28556 + _28558;
        }
        else {
            _28559 = binary_op(PLUS, _28556, _28558);
        }
        _28556 = NOVALUE;
        _28558 = NOVALUE;
        _2 = (object)SEQ_PTR(_27private_sym_20684);
        if (!IS_ATOM_INT(_28559)){
            _28560 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28559)->dbl));
        }
        else{
            _28560 = (object)*(((s1_ptr)_2)->base + _28559);
        }
        Ref(_28560);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -100LL;
        ((intptr_t *)_2)[2] = _28560;
        _28561 = MAKE_SEQ(_1);
        _28560 = NOVALUE;
        DeRef(_t_56425);
        DeRef(_s_56426);
        DeRef(_28559);
        _28559 = NOVALUE;
        return _28561;
LA: 

        /** parser.e:714				end for*/
        _i_56473 = _i_56473 + -1LL;
        goto L8; // [283] 216
L9: 
        ;
    }

    /** parser.e:715				CompileErr(INTERNAL_NESTED_CALL_PARSING_ERROR)*/
    RefDS(_22218);
    _49CompileErr(98LL, _22218, 0LL);
    goto L2; // [299] 349
L3: 

    /** parser.e:717		elsif lock_scanner then*/
    if (_43lock_scanner_56215 == 0)
    {
        goto LB; // [306] 324
    }
    else{
    }

    /** parser.e:718			return {PLAYBACK_ENDS,0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 505LL;
    ((intptr_t *)_2)[2] = 0LL;
    _28562 = MAKE_SEQ(_1);
    DeRef(_t_56425);
    DeRef(_s_56426);
    DeRef(_28561);
    _28561 = NOVALUE;
    DeRef(_28559);
    _28559 = NOVALUE;
    return _28562;
    goto L2; // [321] 349
LB: 

    /** parser.e:720		    t = Scanner()*/
    _0 = _t_56425;
    _t_56425 = _61Scanner();
    DeRef(_0);

    /** parser.e:721		    if Parser_mode = PAM_RECORD then*/
    if (_27Parser_mode_20677 != 1LL)
    goto LC; // [335] 348

    /** parser.e:722		        canned_tokens = append(canned_tokens,t)*/
    Ref(_t_56425);
    Append(&_43canned_tokens_55512, _43canned_tokens_55512, _t_56425);
LC: 
L2: 

    /** parser.e:725		putback_fwd_line_number = 0*/
    _27putback_fwd_line_number_20574 = 0LL;

    /** parser.e:726		return t*/
    DeRef(_s_56426);
    DeRef(_28561);
    _28561 = NOVALUE;
    DeRef(_28562);
    _28562 = NOVALUE;
    DeRef(_28559);
    _28559 = NOVALUE;
    return _t_56425;
    ;
}


object _43Expr_list()
{
    object _tok_56509 = NOVALUE;
    object _n_56510 = NOVALUE;
    object _28578 = NOVALUE;
    object _28575 = NOVALUE;
    object _28574 = NOVALUE;
    object _28572 = NOVALUE;
    object _28571 = NOVALUE;
    object _28567 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:734		integer n*/

    /** parser.e:736		tok = next_token()*/
    _0 = _tok_56509;
    _tok_56509 = _43next_token();
    DeRef(_0);

    /** parser.e:737		putback(tok)*/
    Ref(_tok_56509);
    _43putback(_tok_56509);

    /** parser.e:738		if tok[T_ID] = RIGHT_BRACE then*/
    _2 = (object)SEQ_PTR(_tok_56509);
    _28567 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28567, -25LL)){
        _28567 = NOVALUE;
        goto L1; // [23] 36
    }
    _28567 = NOVALUE;

    /** parser.e:739			return 0*/
    DeRef(_tok_56509);
    return 0LL;
    goto L2; // [33] 142
L1: 

    /** parser.e:741			n = 0*/
    _n_56510 = 0LL;

    /** parser.e:742			short_circuit -= 1*/
    _43short_circuit_55468 = _43short_circuit_55468 - 1LL;

    /** parser.e:743			while TRUE do*/
L3: 
    if (_9TRUE_441 == 0)
    {
        goto L4; // [56] 133
    }
    else{
    }

    /** parser.e:744				gListItem &= 1*/
    Append(&_43gListItem_55504, _43gListItem_55504, 1LL);

    /** parser.e:745				Expr()*/
    _43Expr();

    /** parser.e:746				n += gListItem[$]*/
    if (IS_SEQUENCE(_43gListItem_55504)){
            _28571 = SEQ_PTR(_43gListItem_55504)->length;
    }
    else {
        _28571 = 1;
    }
    _2 = (object)SEQ_PTR(_43gListItem_55504);
    _28572 = (object)*(((s1_ptr)_2)->base + _28571);
    _n_56510 = _n_56510 + _28572;
    _28572 = NOVALUE;

    /** parser.e:747				gListItem = gListItem[1 .. $-1]*/
    if (IS_SEQUENCE(_43gListItem_55504)){
            _28574 = SEQ_PTR(_43gListItem_55504)->length;
    }
    else {
        _28574 = 1;
    }
    _28575 = _28574 - 1LL;
    _28574 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43gListItem_55504;
    RHS_Slice(_43gListItem_55504, 1LL, _28575);

    /** parser.e:748				tok = next_token()*/
    _0 = _tok_56509;
    _tok_56509 = _43next_token();
    DeRef(_0);

    /** parser.e:749				if tok[T_ID] != COMMA then*/
    _2 = (object)SEQ_PTR(_tok_56509);
    _28578 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _28578, -30LL)){
        _28578 = NOVALUE;
        goto L3; // [119] 54
    }
    _28578 = NOVALUE;

    /** parser.e:750					exit*/
    goto L4; // [125] 133

    /** parser.e:752			end while*/
    goto L3; // [130] 54
L4: 

    /** parser.e:753			short_circuit += 1*/
    _43short_circuit_55468 = _43short_circuit_55468 + 1;
L2: 

    /** parser.e:755		putback(tok)*/
    Ref(_tok_56509);
    _43putback(_tok_56509);

    /** parser.e:756		return n*/
    DeRef(_tok_56509);
    DeRef(_28575);
    _28575 = NOVALUE;
    return _n_56510;
    ;
}


void _43tok_match(object _tok_56538, object _prevtok_56539)
{
    object _t_56541 = NOVALUE;
    object _expected_56542 = NOVALUE;
    object _actual_56543 = NOVALUE;
    object _prevname_56544 = NOVALUE;
    object _28590 = NOVALUE;
    object _28588 = NOVALUE;
    object _28585 = NOVALUE;
    object _28582 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:762		sequence expected, actual, prevname*/

    /** parser.e:764		t = next_token()*/
    _0 = _t_56541;
    _t_56541 = _43next_token();
    DeRef(_0);

    /** parser.e:765		if t[T_ID] != tok then*/
    _2 = (object)SEQ_PTR(_t_56541);
    _28582 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _28582, _tok_56538)){
        _28582 = NOVALUE;
        goto L1; // [20] 96
    }
    _28582 = NOVALUE;

    /** parser.e:766			expected = LexName(tok)*/
    RefDS(_26682);
    _0 = _expected_56542;
    _expected_56542 = _45LexName(_tok_56538, _26682);
    DeRef(_0);

    /** parser.e:767			actual = LexName(t[T_ID])*/
    _2 = (object)SEQ_PTR(_t_56541);
    _28585 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_28585);
    RefDS(_26682);
    _0 = _actual_56543;
    _actual_56543 = _45LexName(_28585, _26682);
    DeRef(_0);
    _28585 = NOVALUE;

    /** parser.e:768			if prevtok = 0 then*/
    if (_prevtok_56539 != 0LL)
    goto L2; // [50] 70

    /** parser.e:769				CompileErr(SYNTAX_ERROR__EXPECTED_TO_SEE_POSSIBLY_1_NOT_2, {expected, actual})*/
    RefDS(_actual_56543);
    RefDS(_expected_56542);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _expected_56542;
    ((intptr_t *)_2)[2] = _actual_56543;
    _28588 = MAKE_SEQ(_1);
    _49CompileErr(132LL, _28588, 0LL);
    _28588 = NOVALUE;
    goto L3; // [67] 95
L2: 

    /** parser.e:771				prevname = LexName(prevtok)*/
    RefDS(_26682);
    _0 = _prevname_56544;
    _prevname_56544 = _45LexName(_prevtok_56539, _26682);
    DeRef(_0);

    /** parser.e:772				CompileErr(SYNTAX_ERROR__EXPECTED_TO_SEE_1_AFTER_2_NOT_3, {expected, prevname, actual})*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_expected_56542);
    ((intptr_t*)_2)[1] = _expected_56542;
    RefDS(_prevname_56544);
    ((intptr_t*)_2)[2] = _prevname_56544;
    RefDS(_actual_56543);
    ((intptr_t*)_2)[3] = _actual_56543;
    _28590 = MAKE_SEQ(_1);
    _49CompileErr(138LL, _28590, 0LL);
    _28590 = NOVALUE;
L3: 
L1: 

    /** parser.e:775	end procedure*/
    DeRef(_t_56541);
    DeRef(_expected_56542);
    DeRef(_actual_56543);
    DeRef(_prevname_56544);
    return;
    ;
}


void _43UndefinedVar(object _s_56580)
{
    object _dup_56582 = NOVALUE;
    object _errmsg_56583 = NOVALUE;
    object _rname_56584 = NOVALUE;
    object _fname_56585 = NOVALUE;
    object _28613 = NOVALUE;
    object _28612 = NOVALUE;
    object _28610 = NOVALUE;
    object _28608 = NOVALUE;
    object _28607 = NOVALUE;
    object _28605 = NOVALUE;
    object _28603 = NOVALUE;
    object _28601 = NOVALUE;
    object _28600 = NOVALUE;
    object _28599 = NOVALUE;
    object _28598 = NOVALUE;
    object _28597 = NOVALUE;
    object _28595 = NOVALUE;
    object _28594 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_56580)) {
        _1 = (object)(DBL_PTR(_s_56580)->dbl);
        DeRefDS(_s_56580);
        _s_56580 = _1;
    }

    /** parser.e:790		sequence errmsg*/

    /** parser.e:791		sequence rname*/

    /** parser.e:792		sequence fname*/

    /** parser.e:794		if SymTab[s][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28594 = (object)*(((s1_ptr)_2)->base + _s_56580);
    _2 = (object)SEQ_PTR(_28594);
    _28595 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28594 = NOVALUE;
    if (binary_op_a(NOTEQ, _28595, 9LL)){
        _28595 = NOVALUE;
        goto L1; // [25] 57
    }
    _28595 = NOVALUE;

    /** parser.e:795			CompileErr(MSG_1_HAS_NOT_BEEN_DECLARED, {SymTab[s][S_NAME]})*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28597 = (object)*(((s1_ptr)_2)->base + _s_56580);
    _2 = (object)SEQ_PTR(_28597);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _28598 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _28598 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _28597 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_28598);
    ((intptr_t*)_2)[1] = _28598;
    _28599 = MAKE_SEQ(_1);
    _28598 = NOVALUE;
    _49CompileErr(19LL, _28599, 0LL);
    _28599 = NOVALUE;
    goto L2; // [54] 206
L1: 

    /** parser.e:797		elsif SymTab[s][S_SCOPE] = SC_MULTIPLY_DEFINED then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28600 = (object)*(((s1_ptr)_2)->base + _s_56580);
    _2 = (object)SEQ_PTR(_28600);
    _28601 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28600 = NOVALUE;
    if (binary_op_a(NOTEQ, _28601, 10LL)){
        _28601 = NOVALUE;
        goto L3; // [73] 183
    }
    _28601 = NOVALUE;

    /** parser.e:798			rname = SymTab[s][S_NAME]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28603 = (object)*(((s1_ptr)_2)->base + _s_56580);
    DeRef(_rname_56584);
    _2 = (object)SEQ_PTR(_28603);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _rname_56584 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _rname_56584 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    Ref(_rname_56584);
    _28603 = NOVALUE;

    /** parser.e:799			errmsg = ""*/
    RefDS(_22218);
    DeRef(_errmsg_56583);
    _errmsg_56583 = _22218;

    /** parser.e:801			for i = 1 to length(dup_globals) do*/
    if (IS_SEQUENCE(_53dup_globals_48416)){
            _28605 = SEQ_PTR(_53dup_globals_48416)->length;
    }
    else {
        _28605 = 1;
    }
    {
        object _i_56612;
        _i_56612 = 1LL;
L4: 
        if (_i_56612 > _28605){
            goto L5; // [107] 165
        }

        /** parser.e:802				dup = dup_globals[i]*/
        _2 = (object)SEQ_PTR(_53dup_globals_48416);
        _dup_56582 = (object)*(((s1_ptr)_2)->base + _i_56612);
        if (!IS_ATOM_INT(_dup_56582)){
            _dup_56582 = (object)DBL_PTR(_dup_56582)->dbl;
        }

        /** parser.e:803				fname = known_files[SymTab[dup][S_FILE_NO]]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28607 = (object)*(((s1_ptr)_2)->base + _dup_56582);
        _2 = (object)SEQ_PTR(_28607);
        if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
            _28608 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
        }
        else{
            _28608 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
        }
        _28607 = NOVALUE;
        DeRef(_fname_56585);
        _2 = (object)SEQ_PTR(_28known_files_11573);
        if (!IS_ATOM_INT(_28608)){
            _fname_56585 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28608)->dbl));
        }
        else{
            _fname_56585 = (object)*(((s1_ptr)_2)->base + _28608);
        }
        Ref(_fname_56585);

        /** parser.e:804				errmsg &= "    " & fname & "\n"*/
        {
            object concat_list[3];

            concat_list[0] = _22425;
            concat_list[1] = _fname_56585;
            concat_list[2] = _25160;
            Concat_N((object_ptr)&_28610, concat_list, 3);
        }
        Concat((object_ptr)&_errmsg_56583, _errmsg_56583, _28610);
        DeRefDS(_28610);
        _28610 = NOVALUE;

        /** parser.e:806			end for*/
        _i_56612 = _i_56612 + 1LL;
        goto L4; // [160] 114
L5: 
        ;
    }

    /** parser.e:808			CompileErr(A_NAMESPACE_QUALIFIER_IS_NEEDED_TO_RESOLVE_1BECAUSE_2_IS_DECLARED_AS_A_GLOBALPUBLIC_SYMBOL_IN3, {rname, rname, errmsg})*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDSn(_rname_56584, 2);
    ((intptr_t*)_2)[1] = _rname_56584;
    ((intptr_t*)_2)[2] = _rname_56584;
    RefDS(_errmsg_56583);
    ((intptr_t*)_2)[3] = _errmsg_56583;
    _28612 = MAKE_SEQ(_1);
    _49CompileErr(23LL, _28612, 0LL);
    _28612 = NOVALUE;
    goto L2; // [180] 206
L3: 

    /** parser.e:810		elsif length(symbol_resolution_warning) then*/
    if (IS_SEQUENCE(_27symbol_resolution_warning_20673)){
            _28613 = SEQ_PTR(_27symbol_resolution_warning_20673)->length;
    }
    else {
        _28613 = 1;
    }
    if (_28613 == 0)
    {
        _28613 = NOVALUE;
        goto L6; // [190] 205
    }
    else{
        _28613 = NOVALUE;
    }

    /** parser.e:811			Warning( symbol_resolution_warning, resolution_warning_flag)*/
    RefDS(_27symbol_resolution_warning_20673);
    RefDS(_22218);
    _49Warning(_27symbol_resolution_warning_20673, 1LL, _22218);
L6: 
L2: 

    /** parser.e:813	end procedure*/
    DeRef(_errmsg_56583);
    DeRef(_rname_56584);
    DeRef(_fname_56585);
    _28608 = NOVALUE;
    return;
    ;
}


void _43WrongNumberArgs(object _subsym_56637, object _only_56638)
{
    object _msgno_56639 = NOVALUE;
    object _28625 = NOVALUE;
    object _28624 = NOVALUE;
    object _28623 = NOVALUE;
    object _28622 = NOVALUE;
    object _28621 = NOVALUE;
    object _28619 = NOVALUE;
    object _28617 = NOVALUE;
    object _28615 = NOVALUE;
    object _28614 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_subsym_56637)) {
        _1 = (object)(DBL_PTR(_subsym_56637)->dbl);
        DeRefDS(_subsym_56637);
        _subsym_56637 = _1;
    }

    /** parser.e:819		if SymTab[subsym][S_NUM_ARGS] = 1 then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28614 = (object)*(((s1_ptr)_2)->base + _subsym_56637);
    _2 = (object)SEQ_PTR(_28614);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _28615 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _28615 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _28614 = NOVALUE;
    if (binary_op_a(NOTEQ, _28615, 1LL)){
        _28615 = NOVALUE;
        goto L1; // [19] 49
    }
    _28615 = NOVALUE;

    /** parser.e:820			if length(only) = 0 then*/
    if (IS_SEQUENCE(_only_56638)){
            _28617 = SEQ_PTR(_only_56638)->length;
    }
    else {
        _28617 = 1;
    }
    if (_28617 != 0LL)
    goto L2; // [28] 40

    /** parser.e:821				msgno = 20*/
    _msgno_56639 = 20LL;
    goto L3; // [37] 73
L2: 

    /** parser.e:823				msgno = 237*/
    _msgno_56639 = 237LL;
    goto L3; // [46] 73
L1: 

    /** parser.e:826			if length(only) = 0 then*/
    if (IS_SEQUENCE(_only_56638)){
            _28619 = SEQ_PTR(_only_56638)->length;
    }
    else {
        _28619 = 1;
    }
    if (_28619 != 0LL)
    goto L4; // [54] 66

    /** parser.e:827				msgno = 236*/
    _msgno_56639 = 236LL;
    goto L5; // [63] 72
L4: 

    /** parser.e:829				msgno = 238*/
    _msgno_56639 = 238LL;
L5: 
L3: 

    /** parser.e:833		CompileErr(msgno, {SymTab[subsym][S_NAME], SymTab[subsym][S_NUM_ARGS]})*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28621 = (object)*(((s1_ptr)_2)->base + _subsym_56637);
    _2 = (object)SEQ_PTR(_28621);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _28622 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _28622 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _28621 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28623 = (object)*(((s1_ptr)_2)->base + _subsym_56637);
    _2 = (object)SEQ_PTR(_28623);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _28624 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _28624 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _28623 = NOVALUE;
    Ref(_28624);
    Ref(_28622);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28622;
    ((intptr_t *)_2)[2] = _28624;
    _28625 = MAKE_SEQ(_1);
    _28624 = NOVALUE;
    _28622 = NOVALUE;
    _49CompileErr(_msgno_56639, _28625, 0LL);
    _28625 = NOVALUE;

    /** parser.e:834	end procedure*/
    DeRefDSi(_only_56638);
    return;
    ;
}


void _43MissingArgs(object _subsym_56668)
{
    object _eentry_56669 = NOVALUE;
    object _28630 = NOVALUE;
    object _28629 = NOVALUE;
    object _28628 = NOVALUE;
    object _28627 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:837		sequence eentry = SymTab[subsym]*/
    DeRef(_eentry_56669);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _eentry_56669 = (object)*(((s1_ptr)_2)->base + _subsym_56668);
    Ref(_eentry_56669);

    /** parser.e:839		CompileErr(MSG_1_NEEDS_AT_LEAST_2_PARAMETERS_BUT_SOME_NONDEFAULTABLE_ARGUMENTS_ARE_MISSING, {eentry[S_NAME], eentry[S_DEF_ARGS][2]})*/
    _2 = (object)SEQ_PTR(_eentry_56669);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _28627 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _28627 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _2 = (object)SEQ_PTR(_eentry_56669);
    _28628 = (object)*(((s1_ptr)_2)->base + 28LL);
    _2 = (object)SEQ_PTR(_28628);
    _28629 = (object)*(((s1_ptr)_2)->base + 2LL);
    _28628 = NOVALUE;
    Ref(_28629);
    Ref(_28627);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28627;
    ((intptr_t *)_2)[2] = _28629;
    _28630 = MAKE_SEQ(_1);
    _28629 = NOVALUE;
    _28627 = NOVALUE;
    _49CompileErr(235LL, _28630, 0LL);
    _28630 = NOVALUE;

    /** parser.e:840	end procedure*/
    DeRefDS(_eentry_56669);
    return;
    ;
}


void _43Parse_default_arg(object _subsym_56683, object _arg_56684, object _fwd_private_list_56685, object _fwd_private_sym_56686)
{
    object _param_56688 = NOVALUE;
    object _28650 = NOVALUE;
    object _28649 = NOVALUE;
    object _28648 = NOVALUE;
    object _28647 = NOVALUE;
    object _28646 = NOVALUE;
    object _28645 = NOVALUE;
    object _28644 = NOVALUE;
    object _28643 = NOVALUE;
    object _28642 = NOVALUE;
    object _28641 = NOVALUE;
    object _28640 = NOVALUE;
    object _28639 = NOVALUE;
    object _28638 = NOVALUE;
    object _28636 = NOVALUE;
    object _28635 = NOVALUE;
    object _28632 = NOVALUE;
    object _28631 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:843		symtab_index param = subsym*/
    _param_56688 = _subsym_56683;

    /** parser.e:844		on_arg = arg*/
    _43on_arg_56216 = _arg_56684;

    /** parser.e:845		parseargs_states = append(parseargs_states,*/
    if (IS_SEQUENCE(_43private_list_56214)){
            _28631 = SEQ_PTR(_43private_list_56214)->length;
    }
    else {
        _28631 = 1;
    }
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _28631;
    ((intptr_t*)_2)[2] = _43lock_scanner_56215;
    ((intptr_t*)_2)[3] = _27use_private_list_20685;
    ((intptr_t*)_2)[4] = _43on_arg_56216;
    _28632 = MAKE_SEQ(_1);
    _28631 = NOVALUE;
    RefDS(_28632);
    Append(&_43parseargs_states_56209, _43parseargs_states_56209, _28632);
    DeRefDS(_28632);
    _28632 = NOVALUE;

    /** parser.e:847		nested_calls &= subsym*/
    Append(&_43nested_calls_56217, _43nested_calls_56217, _subsym_56683);

    /** parser.e:849		for i = 1 to arg do*/
    _28635 = _arg_56684;
    {
        object _i_56695;
        _i_56695 = 1LL;
L1: 
        if (_i_56695 > _28635){
            goto L2; // [60] 90
        }

        /** parser.e:850			param = SymTab[param][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28636 = (object)*(((s1_ptr)_2)->base + _param_56688);
        _2 = (object)SEQ_PTR(_28636);
        _param_56688 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_param_56688)){
            _param_56688 = (object)DBL_PTR(_param_56688)->dbl;
        }
        _28636 = NOVALUE;

        /** parser.e:851		end for*/
        _i_56695 = _i_56695 + 1LL;
        goto L1; // [85] 67
L2: 
        ;
    }

    /** parser.e:853		private_list = fwd_private_list*/
    RefDS(_fwd_private_list_56685);
    DeRef(_43private_list_56214);
    _43private_list_56214 = _fwd_private_list_56685;

    /** parser.e:854		private_sym  = fwd_private_sym*/
    RefDS(_fwd_private_sym_56686);
    DeRef(_27private_sym_20684);
    _27private_sym_20684 = _fwd_private_sym_56686;

    /** parser.e:856		if atom(SymTab[param][S_CODE]) then  -- but no default set*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28638 = (object)*(((s1_ptr)_2)->base + _param_56688);
    _2 = (object)SEQ_PTR(_28638);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _28639 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _28639 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    _28638 = NOVALUE;
    _28640 = IS_ATOM(_28639);
    _28639 = NOVALUE;
    if (_28640 == 0)
    {
        _28640 = NOVALUE;
        goto L3; // [121] 164
    }
    else{
        _28640 = NOVALUE;
    }

    /** parser.e:857			CompileErr(ARGUMENT_1_OF_2_3_WAS_OMITTED_BUT_THERE_IS_NO_DEFAULT_VALUE_DEFINED, {arg, SymTab[subsym][S_NAME], SymTab[param][S_NAME]})*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28641 = (object)*(((s1_ptr)_2)->base + _subsym_56683);
    _2 = (object)SEQ_PTR(_28641);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _28642 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _28642 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _28641 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28643 = (object)*(((s1_ptr)_2)->base + _param_56688);
    _2 = (object)SEQ_PTR(_28643);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _28644 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _28644 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _28643 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _arg_56684;
    Ref(_28642);
    ((intptr_t*)_2)[2] = _28642;
    Ref(_28644);
    ((intptr_t*)_2)[3] = _28644;
    _28645 = MAKE_SEQ(_1);
    _28644 = NOVALUE;
    _28642 = NOVALUE;
    _49CompileErr(26LL, _28645, 0LL);
    _28645 = NOVALUE;
L3: 

    /** parser.e:860		use_private_list = 1*/
    _27use_private_list_20685 = 1LL;

    /** parser.e:861		lock_scanner = 1*/
    _43lock_scanner_56215 = 1LL;

    /** parser.e:862		start_playback(SymTab[param][S_CODE] )*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28646 = (object)*(((s1_ptr)_2)->base + _param_56688);
    _2 = (object)SEQ_PTR(_28646);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _28647 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _28647 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    _28646 = NOVALUE;
    Ref(_28647);
    _43start_playback(_28647);
    _28647 = NOVALUE;

    /** parser.e:863		call_proc(forward_expr, {})*/
    _0 = (object)_00[_43forward_expr_56505].addr;
    (*(intptr_t (*)())_0)(
                         );

    /** parser.e:865		add_private_symbol( Top(), SymTab[param][S_NAME] )*/
    _28648 = _45Top();
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28649 = (object)*(((s1_ptr)_2)->base + _param_56688);
    _2 = (object)SEQ_PTR(_28649);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _28650 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _28650 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _28649 = NOVALUE;
    Ref(_28650);
    _42add_private_symbol(_28648, _28650);
    _28648 = NOVALUE;
    _28650 = NOVALUE;

    /** parser.e:866		lock_scanner = 0*/
    _43lock_scanner_56215 = 0LL;

    /** parser.e:867		restore_parseargs_states()*/
    _43restore_parseargs_states();

    /** parser.e:868	end procedure*/
    DeRefDS(_fwd_private_list_56685);
    DeRefDSi(_fwd_private_sym_56686);
    return;
    ;
}


void _43ParseArgs(object _subsym_56734)
{
    object _n_56735 = NOVALUE;
    object _fda_56736 = NOVALUE;
    object _lnda_56737 = NOVALUE;
    object _tok_56739 = NOVALUE;
    object _s_56741 = NOVALUE;
    object _var_code_56742 = NOVALUE;
    object _name_56743 = NOVALUE;
    object _28760 = NOVALUE;
    object _28758 = NOVALUE;
    object _28754 = NOVALUE;
    object _28753 = NOVALUE;
    object _28752 = NOVALUE;
    object _28749 = NOVALUE;
    object _28746 = NOVALUE;
    object _28744 = NOVALUE;
    object _28742 = NOVALUE;
    object _28740 = NOVALUE;
    object _28738 = NOVALUE;
    object _28737 = NOVALUE;
    object _28736 = NOVALUE;
    object _28735 = NOVALUE;
    object _28734 = NOVALUE;
    object _28733 = NOVALUE;
    object _28732 = NOVALUE;
    object _28726 = NOVALUE;
    object _28725 = NOVALUE;
    object _28724 = NOVALUE;
    object _28723 = NOVALUE;
    object _28722 = NOVALUE;
    object _28721 = NOVALUE;
    object _28718 = NOVALUE;
    object _28715 = NOVALUE;
    object _28710 = NOVALUE;
    object _28708 = NOVALUE;
    object _28707 = NOVALUE;
    object _28706 = NOVALUE;
    object _28704 = NOVALUE;
    object _28701 = NOVALUE;
    object _28698 = NOVALUE;
    object _28696 = NOVALUE;
    object _28694 = NOVALUE;
    object _28692 = NOVALUE;
    object _28690 = NOVALUE;
    object _28689 = NOVALUE;
    object _28688 = NOVALUE;
    object _28687 = NOVALUE;
    object _28686 = NOVALUE;
    object _28685 = NOVALUE;
    object _28684 = NOVALUE;
    object _28682 = NOVALUE;
    object _28681 = NOVALUE;
    object _28680 = NOVALUE;
    object _28679 = NOVALUE;
    object _28678 = NOVALUE;
    object _28677 = NOVALUE;
    object _28674 = NOVALUE;
    object _28673 = NOVALUE;
    object _28672 = NOVALUE;
    object _28670 = NOVALUE;
    object _28669 = NOVALUE;
    object _28667 = NOVALUE;
    object _28663 = NOVALUE;
    object _28662 = NOVALUE;
    object _28660 = NOVALUE;
    object _28659 = NOVALUE;
    object _28657 = NOVALUE;
    object _28656 = NOVALUE;
    object _28655 = NOVALUE;
    object _28654 = NOVALUE;
    object _28653 = NOVALUE;
    object _28651 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_subsym_56734)) {
        _1 = (object)(DBL_PTR(_subsym_56734)->dbl);
        DeRefDS(_subsym_56734);
        _subsym_56734 = _1;
    }

    /** parser.e:875		object var_code*/

    /** parser.e:876		sequence name*/

    /** parser.e:878		n = SymTab[subsym][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28651 = (object)*(((s1_ptr)_2)->base + _subsym_56734);
    _2 = (object)SEQ_PTR(_28651);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _n_56735 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _n_56735 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    if (!IS_ATOM_INT(_n_56735)){
        _n_56735 = (object)DBL_PTR(_n_56735)->dbl;
    }
    _28651 = NOVALUE;

    /** parser.e:879		if sequence(SymTab[subsym][S_DEF_ARGS]) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28653 = (object)*(((s1_ptr)_2)->base + _subsym_56734);
    _2 = (object)SEQ_PTR(_28653);
    _28654 = (object)*(((s1_ptr)_2)->base + 28LL);
    _28653 = NOVALUE;
    _28655 = IS_SEQUENCE(_28654);
    _28654 = NOVALUE;
    if (_28655 == 0)
    {
        _28655 = NOVALUE;
        goto L1; // [40] 86
    }
    else{
        _28655 = NOVALUE;
    }

    /** parser.e:880			fda = SymTab[subsym][S_DEF_ARGS][1]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28656 = (object)*(((s1_ptr)_2)->base + _subsym_56734);
    _2 = (object)SEQ_PTR(_28656);
    _28657 = (object)*(((s1_ptr)_2)->base + 28LL);
    _28656 = NOVALUE;
    _2 = (object)SEQ_PTR(_28657);
    _fda_56736 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_fda_56736)){
        _fda_56736 = (object)DBL_PTR(_fda_56736)->dbl;
    }
    _28657 = NOVALUE;

    /** parser.e:881			lnda = SymTab[subsym][S_DEF_ARGS][2]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28659 = (object)*(((s1_ptr)_2)->base + _subsym_56734);
    _2 = (object)SEQ_PTR(_28659);
    _28660 = (object)*(((s1_ptr)_2)->base + 28LL);
    _28659 = NOVALUE;
    _2 = (object)SEQ_PTR(_28660);
    _lnda_56737 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_lnda_56737)){
        _lnda_56737 = (object)DBL_PTR(_lnda_56737)->dbl;
    }
    _28660 = NOVALUE;
    goto L2; // [83] 97
L1: 

    /** parser.e:883			fda = 0*/
    _fda_56736 = 0LL;

    /** parser.e:884			lnda = 0*/
    _lnda_56737 = 0LL;
L2: 

    /** parser.e:886		s = subsym*/
    _s_56741 = _subsym_56734;

    /** parser.e:888		parseargs_states = append(parseargs_states,*/
    if (IS_SEQUENCE(_43private_list_56214)){
            _28662 = SEQ_PTR(_43private_list_56214)->length;
    }
    else {
        _28662 = 1;
    }
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _28662;
    ((intptr_t*)_2)[2] = _43lock_scanner_56215;
    ((intptr_t*)_2)[3] = _27use_private_list_20685;
    ((intptr_t*)_2)[4] = _43on_arg_56216;
    _28663 = MAKE_SEQ(_1);
    _28662 = NOVALUE;
    RefDS(_28663);
    Append(&_43parseargs_states_56209, _43parseargs_states_56209, _28663);
    DeRefDS(_28663);
    _28663 = NOVALUE;

    /** parser.e:890		nested_calls &= subsym*/
    Append(&_43nested_calls_56217, _43nested_calls_56217, _subsym_56734);

    /** parser.e:891		lock_scanner = 0*/
    _43lock_scanner_56215 = 0LL;

    /** parser.e:892		on_arg = 0*/
    _43on_arg_56216 = 0LL;

    /** parser.e:894		short_circuit -= 1*/
    _43short_circuit_55468 = _43short_circuit_55468 - 1LL;

    /** parser.e:895		for i = 1 to n do*/
    _28667 = _n_56735;
    {
        object _i_56772;
        _i_56772 = 1LL;
L3: 
        if (_i_56772 > _28667){
            goto L4; // [161] 1050
        }

        /** parser.e:897		  	tok = next_token()*/
        _0 = _tok_56739;
        _tok_56739 = _43next_token();
        DeRef(_0);

        /** parser.e:899			if tok[T_ID] = QUESTION_MARK or tok[T_ID] = COMMA then*/
        _2 = (object)SEQ_PTR(_tok_56739);
        _28669 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_28669)) {
            _28670 = (_28669 == -31LL);
        }
        else {
            _28670 = binary_op(EQUALS, _28669, -31LL);
        }
        _28669 = NOVALUE;
        if (IS_ATOM_INT(_28670)) {
            if (_28670 != 0) {
                goto L5; // [187] 208
            }
        }
        else {
            if (DBL_PTR(_28670)->dbl != 0.0) {
                goto L5; // [187] 208
            }
        }
        _2 = (object)SEQ_PTR(_tok_56739);
        _28672 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_28672)) {
            _28673 = (_28672 == -30LL);
        }
        else {
            _28673 = binary_op(EQUALS, _28672, -30LL);
        }
        _28672 = NOVALUE;
        if (_28673 == 0) {
            DeRef(_28673);
            _28673 = NOVALUE;
            goto L6; // [204] 505
        }
        else {
            if (!IS_ATOM_INT(_28673) && DBL_PTR(_28673)->dbl == 0.0){
                DeRef(_28673);
                _28673 = NOVALUE;
                goto L6; // [204] 505
            }
            DeRef(_28673);
            _28673 = NOVALUE;
        }
        DeRef(_28673);
        _28673 = NOVALUE;
L5: 

        /** parser.e:902				if tok[T_ID] = QUESTION_MARK then*/
        _2 = (object)SEQ_PTR(_tok_56739);
        _28674 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _28674, -31LL)){
            _28674 = NOVALUE;
            goto L7; // [218] 297
        }
        _28674 = NOVALUE;

        /** parser.e:903					tok = next_token()*/
        _0 = _tok_56739;
        _tok_56739 = _43next_token();
        DeRef(_0);

        /** parser.e:904					if tok[T_ID] != RIGHT_ROUND and tok[T_ID] != COMMA then*/
        _2 = (object)SEQ_PTR(_tok_56739);
        _28677 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_28677)) {
            _28678 = (_28677 != -27LL);
        }
        else {
            _28678 = binary_op(NOTEQ, _28677, -27LL);
        }
        _28677 = NOVALUE;
        if (IS_ATOM_INT(_28678)) {
            if (_28678 == 0) {
                goto L8; // [241] 273
            }
        }
        else {
            if (DBL_PTR(_28678)->dbl == 0.0) {
                goto L8; // [241] 273
            }
        }
        _2 = (object)SEQ_PTR(_tok_56739);
        _28680 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_28680)) {
            _28681 = (_28680 != -30LL);
        }
        else {
            _28681 = binary_op(NOTEQ, _28680, -30LL);
        }
        _28680 = NOVALUE;
        if (_28681 == 0) {
            DeRef(_28681);
            _28681 = NOVALUE;
            goto L8; // [258] 273
        }
        else {
            if (!IS_ATOM_INT(_28681) && DBL_PTR(_28681)->dbl == 0.0){
                DeRef(_28681);
                _28681 = NOVALUE;
                goto L8; // [258] 273
            }
            DeRef(_28681);
            _28681 = NOVALUE;
        }
        DeRef(_28681);
        _28681 = NOVALUE;

        /** parser.e:905						CompileErr( BADLYFORMED_LIST_OF_PARAMETERS__EXPECTED__OR)*/
        RefDS(_22218);
        _49CompileErr(41LL, _22218, 0LL);
        goto L9; // [270] 298
L8: 

        /** parser.e:906					elsif tok[T_ID] = RIGHT_ROUND then*/
        _2 = (object)SEQ_PTR(_tok_56739);
        _28682 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _28682, -27LL)){
            _28682 = NOVALUE;
            goto L9; // [283] 298
        }
        _28682 = NOVALUE;

        /** parser.e:907						putback( tok )*/
        Ref(_tok_56739);
        _43putback(_tok_56739);
        goto L9; // [294] 298
L7: 
L9: 

        /** parser.e:912				if SymTab[subsym][S_OPCODE] then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28684 = (object)*(((s1_ptr)_2)->base + _subsym_56734);
        _2 = (object)SEQ_PTR(_28684);
        _28685 = (object)*(((s1_ptr)_2)->base + 21LL);
        _28684 = NOVALUE;
        if (_28685 == 0) {
            _28685 = NOVALUE;
            goto LA; // [312] 372
        }
        else {
            if (!IS_ATOM_INT(_28685) && DBL_PTR(_28685)->dbl == 0.0){
                _28685 = NOVALUE;
                goto LA; // [312] 372
            }
            _28685 = NOVALUE;
        }
        _28685 = NOVALUE;

        /** parser.e:913					if atom(SymTab[subsym][S_CODE]) then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28686 = (object)*(((s1_ptr)_2)->base + _subsym_56734);
        _2 = (object)SEQ_PTR(_28686);
        if (!IS_ATOM_INT(_27S_CODE_20221)){
            _28687 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
        }
        else{
            _28687 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
        }
        _28686 = NOVALUE;
        _28688 = IS_ATOM(_28687);
        _28687 = NOVALUE;
        if (_28688 == 0)
        {
            _28688 = NOVALUE;
            goto LB; // [332] 343
        }
        else{
            _28688 = NOVALUE;
        }

        /** parser.e:914						var_code = 0*/
        DeRef(_var_code_56742);
        _var_code_56742 = 0LL;
        goto LC; // [340] 362
LB: 

        /** parser.e:916						var_code = SymTab[subsym][S_CODE][i]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28689 = (object)*(((s1_ptr)_2)->base + _subsym_56734);
        _2 = (object)SEQ_PTR(_28689);
        if (!IS_ATOM_INT(_27S_CODE_20221)){
            _28690 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
        }
        else{
            _28690 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
        }
        _28689 = NOVALUE;
        DeRef(_var_code_56742);
        _2 = (object)SEQ_PTR(_28690);
        _var_code_56742 = (object)*(((s1_ptr)_2)->base + _i_56772);
        Ref(_var_code_56742);
        _28690 = NOVALUE;
LC: 

        /** parser.e:918					name = ""*/
        RefDS(_22218);
        DeRef(_name_56743);
        _name_56743 = _22218;
        goto LD; // [369] 419
LA: 

        /** parser.e:920					s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28692 = (object)*(((s1_ptr)_2)->base + _s_56741);
        _2 = (object)SEQ_PTR(_28692);
        _s_56741 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_s_56741)){
            _s_56741 = (object)DBL_PTR(_s_56741)->dbl;
        }
        _28692 = NOVALUE;

        /** parser.e:921					var_code = SymTab[s][S_CODE]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28694 = (object)*(((s1_ptr)_2)->base + _s_56741);
        DeRef(_var_code_56742);
        _2 = (object)SEQ_PTR(_28694);
        if (!IS_ATOM_INT(_27S_CODE_20221)){
            _var_code_56742 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
        }
        else{
            _var_code_56742 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
        }
        Ref(_var_code_56742);
        _28694 = NOVALUE;

        /** parser.e:922					name = SymTab[s][S_NAME]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28696 = (object)*(((s1_ptr)_2)->base + _s_56741);
        DeRef(_name_56743);
        _2 = (object)SEQ_PTR(_28696);
        if (!IS_ATOM_INT(_27S_NAME_20209)){
            _name_56743 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
        }
        else{
            _name_56743 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
        }
        Ref(_name_56743);
        _28696 = NOVALUE;
LD: 

        /** parser.e:925				if atom(var_code) then  -- but no default set*/
        _28698 = IS_ATOM(_var_code_56742);
        if (_28698 == 0)
        {
            _28698 = NOVALUE;
            goto LE; // [426] 439
        }
        else{
            _28698 = NOVALUE;
        }

        /** parser.e:926					CompileErr(ARGUMENT_1_WAS_OMITTED_BUT_THERE_IS_NO_DEFAULT_VALUE_DEFINED,i)*/
        _49CompileErr(29LL, _i_56772, 0LL);
LE: 

        /** parser.e:929				use_private_list = 1*/
        _27use_private_list_20685 = 1LL;

        /** parser.e:930				start_playback(var_code)*/
        Ref(_var_code_56742);
        _43start_playback(_var_code_56742);

        /** parser.e:931				lock_scanner=1*/
        _43lock_scanner_56215 = 1LL;

        /** parser.e:934				Expr()*/
        _43Expr();

        /** parser.e:935				lock_scanner=0*/
        _43lock_scanner_56215 = 0LL;

        /** parser.e:936				on_arg += 1*/
        _43on_arg_56216 = _43on_arg_56216 + 1;

        /** parser.e:937				private_list = append(private_list,name)*/
        RefDS(_name_56743);
        Append(&_43private_list_56214, _43private_list_56214, _name_56743);

        /** parser.e:938				private_sym &= Top()*/
        _28701 = _45Top();
        if (IS_SEQUENCE(_27private_sym_20684) && IS_ATOM(_28701)) {
            Ref(_28701);
            Append(&_27private_sym_20684, _27private_sym_20684, _28701);
        }
        else if (IS_ATOM(_27private_sym_20684) && IS_SEQUENCE(_28701)) {
        }
        else {
            Concat((object_ptr)&_27private_sym_20684, _27private_sym_20684, _28701);
        }
        DeRef(_28701);
        _28701 = NOVALUE;

        /** parser.e:939				backed_up_tok = {tok} -- ????*/
        _0 = _43backed_up_tok_55475;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_tok_56739);
        ((intptr_t*)_2)[1] = _tok_56739;
        _43backed_up_tok_55475 = MAKE_SEQ(_1);
        DeRef(_0);
        goto LF; // [502] 633
L6: 

        /** parser.e:942			elsif tok[T_ID] != RIGHT_ROUND then*/
        _2 = (object)SEQ_PTR(_tok_56739);
        _28704 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(EQUALS, _28704, -27LL)){
            _28704 = NOVALUE;
            goto L10; // [515] 632
        }
        _28704 = NOVALUE;

        /** parser.e:944				if SymTab[subsym][S_OPCODE] then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28706 = (object)*(((s1_ptr)_2)->base + _subsym_56734);
        _2 = (object)SEQ_PTR(_28706);
        _28707 = (object)*(((s1_ptr)_2)->base + 21LL);
        _28706 = NOVALUE;
        if (_28707 == 0) {
            _28707 = NOVALUE;
            goto L11; // [533] 546
        }
        else {
            if (!IS_ATOM_INT(_28707) && DBL_PTR(_28707)->dbl == 0.0){
                _28707 = NOVALUE;
                goto L11; // [533] 546
            }
            _28707 = NOVALUE;
        }
        _28707 = NOVALUE;

        /** parser.e:945					name = ""*/
        RefDS(_22218);
        DeRef(_name_56743);
        _name_56743 = _22218;
        goto L12; // [543] 579
L11: 

        /** parser.e:947					s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28708 = (object)*(((s1_ptr)_2)->base + _s_56741);
        _2 = (object)SEQ_PTR(_28708);
        _s_56741 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_s_56741)){
            _s_56741 = (object)DBL_PTR(_s_56741)->dbl;
        }
        _28708 = NOVALUE;

        /** parser.e:948					name = SymTab[s][S_NAME]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28710 = (object)*(((s1_ptr)_2)->base + _s_56741);
        DeRef(_name_56743);
        _2 = (object)SEQ_PTR(_28710);
        if (!IS_ATOM_INT(_27S_NAME_20209)){
            _name_56743 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
        }
        else{
            _name_56743 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
        }
        Ref(_name_56743);
        _28710 = NOVALUE;
L12: 

        /** parser.e:951				use_private_list = Parser_mode != PAM_NORMAL*/
        _27use_private_list_20685 = (_27Parser_mode_20677 != 0LL);

        /** parser.e:952				putback(tok)*/
        Ref(_tok_56739);
        _43putback(_tok_56739);

        /** parser.e:953				Expr()*/
        _43Expr();

        /** parser.e:954				on_arg += 1*/
        _43on_arg_56216 = _43on_arg_56216 + 1;

        /** parser.e:955				private_list = append(private_list,name)*/
        RefDS(_name_56743);
        Append(&_43private_list_56214, _43private_list_56214, _name_56743);

        /** parser.e:956				private_sym &= Top()*/
        _28715 = _45Top();
        if (IS_SEQUENCE(_27private_sym_20684) && IS_ATOM(_28715)) {
            Ref(_28715);
            Append(&_27private_sym_20684, _27private_sym_20684, _28715);
        }
        else if (IS_ATOM(_27private_sym_20684) && IS_SEQUENCE(_28715)) {
        }
        else {
            Concat((object_ptr)&_27private_sym_20684, _27private_sym_20684, _28715);
        }
        DeRef(_28715);
        _28715 = NOVALUE;
L10: 
LF: 

        /** parser.e:959			if on_arg != n then*/
        if (_43on_arg_56216 == _n_56735)
        goto L13; // [637] 1043

        /** parser.e:960				if tok[T_ID] = RIGHT_ROUND then*/
        _2 = (object)SEQ_PTR(_tok_56739);
        _28718 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _28718, -27LL)){
            _28718 = NOVALUE;
            goto L14; // [651] 661
        }
        _28718 = NOVALUE;

        /** parser.e:961					putback( tok )*/
        Ref(_tok_56739);
        _43putback(_tok_56739);
L14: 

        /** parser.e:963				tok = next_token()*/
        _0 = _tok_56739;
        _tok_56739 = _43next_token();
        DeRef(_0);

        /** parser.e:964				if tok[T_ID] != COMMA and tok[T_ID] != QUESTION_MARK then*/
        _2 = (object)SEQ_PTR(_tok_56739);
        _28721 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_28721)) {
            _28722 = (_28721 != -30LL);
        }
        else {
            _28722 = binary_op(NOTEQ, _28721, -30LL);
        }
        _28721 = NOVALUE;
        if (IS_ATOM_INT(_28722)) {
            if (_28722 == 0) {
                goto L15; // [680] 1042
            }
        }
        else {
            if (DBL_PTR(_28722)->dbl == 0.0) {
                goto L15; // [680] 1042
            }
        }
        _2 = (object)SEQ_PTR(_tok_56739);
        _28724 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_28724)) {
            _28725 = (_28724 != -31LL);
        }
        else {
            _28725 = binary_op(NOTEQ, _28724, -31LL);
        }
        _28724 = NOVALUE;
        if (_28725 == 0) {
            DeRef(_28725);
            _28725 = NOVALUE;
            goto L15; // [697] 1042
        }
        else {
            if (!IS_ATOM_INT(_28725) && DBL_PTR(_28725)->dbl == 0.0){
                DeRef(_28725);
                _28725 = NOVALUE;
                goto L15; // [697] 1042
            }
            DeRef(_28725);
            _28725 = NOVALUE;
        }
        DeRef(_28725);
        _28725 = NOVALUE;

        /** parser.e:966			  		if tok[T_ID] = RIGHT_ROUND then*/
        _2 = (object)SEQ_PTR(_tok_56739);
        _28726 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _28726, -27LL)){
            _28726 = NOVALUE;
            goto L16; // [710] 1027
        }
        _28726 = NOVALUE;

        /** parser.e:968						if fda=0 then*/
        if (_fda_56736 != 0LL)
        goto L17; // [718] 731

        /** parser.e:969							WrongNumberArgs(subsym, "")*/
        RefDS(_22218);
        _43WrongNumberArgs(_subsym_56734, _22218);
        goto L18; // [728] 746
L17: 

        /** parser.e:970						elsif i<lnda then*/
        if (_i_56772 >= _lnda_56737)
        goto L19; // [735] 745

        /** parser.e:971							MissingArgs(subsym)*/
        _43MissingArgs(_subsym_56734);
L19: 
L18: 

        /** parser.e:973						lock_scanner = 1*/
        _43lock_scanner_56215 = 1LL;

        /** parser.e:974						use_private_list = 1*/
        _27use_private_list_20685 = 1LL;

        /** parser.e:977						while on_arg < n do*/
L1A: 
        if (_43on_arg_56216 >= _n_56735)
        goto L1B; // [765] 976

        /** parser.e:978							on_arg += 1*/
        _43on_arg_56216 = _43on_arg_56216 + 1;

        /** parser.e:979							if SymTab[subsym][S_OPCODE] then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28732 = (object)*(((s1_ptr)_2)->base + _subsym_56734);
        _2 = (object)SEQ_PTR(_28732);
        _28733 = (object)*(((s1_ptr)_2)->base + 21LL);
        _28732 = NOVALUE;
        if (_28733 == 0) {
            _28733 = NOVALUE;
            goto L1C; // [791] 853
        }
        else {
            if (!IS_ATOM_INT(_28733) && DBL_PTR(_28733)->dbl == 0.0){
                _28733 = NOVALUE;
                goto L1C; // [791] 853
            }
            _28733 = NOVALUE;
        }
        _28733 = NOVALUE;

        /** parser.e:980								if atom(SymTab[subsym][S_CODE]) then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28734 = (object)*(((s1_ptr)_2)->base + _subsym_56734);
        _2 = (object)SEQ_PTR(_28734);
        if (!IS_ATOM_INT(_27S_CODE_20221)){
            _28735 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
        }
        else{
            _28735 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
        }
        _28734 = NOVALUE;
        _28736 = IS_ATOM(_28735);
        _28735 = NOVALUE;
        if (_28736 == 0)
        {
            _28736 = NOVALUE;
            goto L1D; // [811] 822
        }
        else{
            _28736 = NOVALUE;
        }

        /** parser.e:981									var_code = 0*/
        DeRef(_var_code_56742);
        _var_code_56742 = 0LL;
        goto L1E; // [819] 843
L1D: 

        /** parser.e:983									var_code = SymTab[subsym][S_CODE][on_arg]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28737 = (object)*(((s1_ptr)_2)->base + _subsym_56734);
        _2 = (object)SEQ_PTR(_28737);
        if (!IS_ATOM_INT(_27S_CODE_20221)){
            _28738 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
        }
        else{
            _28738 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
        }
        _28737 = NOVALUE;
        DeRef(_var_code_56742);
        _2 = (object)SEQ_PTR(_28738);
        _var_code_56742 = (object)*(((s1_ptr)_2)->base + _43on_arg_56216);
        Ref(_var_code_56742);
        _28738 = NOVALUE;
L1E: 

        /** parser.e:986								name = ""*/
        RefDS(_22218);
        DeRef(_name_56743);
        _name_56743 = _22218;
        goto L1F; // [850] 900
L1C: 

        /** parser.e:989								s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28740 = (object)*(((s1_ptr)_2)->base + _s_56741);
        _2 = (object)SEQ_PTR(_28740);
        _s_56741 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_s_56741)){
            _s_56741 = (object)DBL_PTR(_s_56741)->dbl;
        }
        _28740 = NOVALUE;

        /** parser.e:990								var_code = SymTab[s][S_CODE]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28742 = (object)*(((s1_ptr)_2)->base + _s_56741);
        DeRef(_var_code_56742);
        _2 = (object)SEQ_PTR(_28742);
        if (!IS_ATOM_INT(_27S_CODE_20221)){
            _var_code_56742 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
        }
        else{
            _var_code_56742 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
        }
        Ref(_var_code_56742);
        _28742 = NOVALUE;

        /** parser.e:991								name = SymTab[s][S_NAME]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28744 = (object)*(((s1_ptr)_2)->base + _s_56741);
        DeRef(_name_56743);
        _2 = (object)SEQ_PTR(_28744);
        if (!IS_ATOM_INT(_27S_NAME_20209)){
            _name_56743 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
        }
        else{
            _name_56743 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
        }
        Ref(_name_56743);
        _28744 = NOVALUE;
L1F: 

        /** parser.e:993							if sequence(var_code) then*/
        _28746 = IS_SEQUENCE(_var_code_56742);
        if (_28746 == 0)
        {
            _28746 = NOVALUE;
            goto L20; // [907] 959
        }
        else{
            _28746 = NOVALUE;
        }

        /** parser.e:995								putback( tok )*/
        Ref(_tok_56739);
        _43putback(_tok_56739);

        /** parser.e:996								start_playback(var_code)*/
        Ref(_var_code_56742);
        _43start_playback(_var_code_56742);

        /** parser.e:999								Expr()*/
        _43Expr();

        /** parser.e:1000								if on_arg < n then*/
        if (_43on_arg_56216 >= _n_56735)
        goto L1A; // [928] 763

        /** parser.e:1001									private_list = append(private_list,name)*/
        RefDS(_name_56743);
        Append(&_43private_list_56214, _43private_list_56214, _name_56743);

        /** parser.e:1002									private_sym &= Top()*/
        _28749 = _45Top();
        if (IS_SEQUENCE(_27private_sym_20684) && IS_ATOM(_28749)) {
            Ref(_28749);
            Append(&_27private_sym_20684, _27private_sym_20684, _28749);
        }
        else if (IS_ATOM(_27private_sym_20684) && IS_SEQUENCE(_28749)) {
        }
        else {
            Concat((object_ptr)&_27private_sym_20684, _27private_sym_20684, _28749);
        }
        DeRef(_28749);
        _28749 = NOVALUE;
        goto L1A; // [956] 763
L20: 

        /** parser.e:1005								CompileErr(ARGUMENT_1_WAS_OMITTED_BUT_THERE_IS_NO_DEFAULT_VALUE_DEFINED, on_arg)*/
        _49CompileErr(29LL, _43on_arg_56216, 0LL);

        /** parser.e:1007			  		    end while*/
        goto L1A; // [973] 763
L1B: 

        /** parser.e:1009						short_circuit += 1*/
        _43short_circuit_55468 = _43short_circuit_55468 + 1;

        /** parser.e:1010						if backed_up_tok[$][T_ID] = PLAYBACK_ENDS then*/
        if (IS_SEQUENCE(_43backed_up_tok_55475)){
                _28752 = SEQ_PTR(_43backed_up_tok_55475)->length;
        }
        else {
            _28752 = 1;
        }
        _2 = (object)SEQ_PTR(_43backed_up_tok_55475);
        _28753 = (object)*(((s1_ptr)_2)->base + _28752);
        _2 = (object)SEQ_PTR(_28753);
        _28754 = (object)*(((s1_ptr)_2)->base + 1LL);
        _28753 = NOVALUE;
        if (binary_op_a(NOTEQ, _28754, 505LL)){
            _28754 = NOVALUE;
            goto L21; // [1003] 1015
        }
        _28754 = NOVALUE;

        /** parser.e:1011							backed_up_tok = {}*/
        RefDS(_22218);
        DeRefDS(_43backed_up_tok_55475);
        _43backed_up_tok_55475 = _22218;
L21: 

        /** parser.e:1014						restore_parseargs_states()*/
        _43restore_parseargs_states();

        /** parser.e:1016						return*/
        DeRef(_tok_56739);
        DeRef(_var_code_56742);
        DeRef(_name_56743);
        DeRef(_28722);
        _28722 = NOVALUE;
        DeRef(_28670);
        _28670 = NOVALUE;
        DeRef(_28678);
        _28678 = NOVALUE;
        return;
        goto L22; // [1024] 1041
L16: 

        /** parser.e:1018						putback(tok)*/
        Ref(_tok_56739);
        _43putback(_tok_56739);

        /** parser.e:1019						tok_match(COMMA)*/
        _43tok_match(-30LL, 0LL);
L22: 
L15: 
L13: 

        /** parser.e:1024		end for*/
        _i_56772 = _i_56772 + 1LL;
        goto L3; // [1045] 168
L4: 
        ;
    }

    /** parser.e:1025		tok = next_token()*/
    _0 = _tok_56739;
    _tok_56739 = _43next_token();
    DeRef(_0);

    /** parser.e:1026		short_circuit += 1*/
    _43short_circuit_55468 = _43short_circuit_55468 + 1;

    /** parser.e:1027		if tok[T_ID] != RIGHT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok_56739);
    _28758 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _28758, -27LL)){
        _28758 = NOVALUE;
        goto L23; // [1073] 1115
    }
    _28758 = NOVALUE;

    /** parser.e:1028			if tok[T_ID] = COMMA then*/
    _2 = (object)SEQ_PTR(_tok_56739);
    _28760 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28760, -30LL)){
        _28760 = NOVALUE;
        goto L24; // [1087] 1100
    }
    _28760 = NOVALUE;

    /** parser.e:1029				WrongNumberArgs(subsym, "only ")*/
    RefDS(_28762);
    _43WrongNumberArgs(_subsym_56734, _28762);
    goto L25; // [1097] 1114
L24: 

    /** parser.e:1031				putback(tok)*/
    Ref(_tok_56739);
    _43putback(_tok_56739);

    /** parser.e:1032				tok_match(RIGHT_ROUND)*/
    _43tok_match(-27LL, 0LL);
L25: 
L23: 

    /** parser.e:1036		restore_parseargs_states()*/
    _43restore_parseargs_states();

    /** parser.e:1037	end procedure*/
    DeRef(_tok_56739);
    DeRef(_var_code_56742);
    DeRef(_name_56743);
    DeRef(_28722);
    _28722 = NOVALUE;
    DeRef(_28670);
    _28670 = NOVALUE;
    DeRef(_28678);
    _28678 = NOVALUE;
    return;
    ;
}


void _43Forward_var(object _tok_56984, object _init_check_56985, object _op_56986)
{
    object _ref_56990 = NOVALUE;
    object _28766 = NOVALUE;
    object _28764 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_op_56986)) {
        _1 = (object)(DBL_PTR(_op_56986)->dbl);
        DeRefDS(_op_56986);
        _op_56986 = _1;
    }

    /** parser.e:1041		ref = new_forward_reference( VARIABLE, tok[T_SYM], op )*/
    _2 = (object)SEQ_PTR(_tok_56984);
    _28764 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_28764);
    _ref_56990 = _42new_forward_reference(-100LL, _28764, _op_56986);
    _28764 = NOVALUE;
    if (!IS_ATOM_INT(_ref_56990)) {
        _1 = (object)(DBL_PTR(_ref_56990)->dbl);
        DeRefDS(_ref_56990);
        _ref_56990 = _1;
    }

    /** parser.e:1042		emit_opnd( - ref )*/
    if ((uintptr_t)_ref_56990 == (uintptr_t)HIGH_BITS){
        _28766 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _28766 = - _ref_56990;
    }
    _45emit_opnd(_28766);
    _28766 = NOVALUE;

    /** parser.e:1043		if init_check != -1 then*/
    if (_init_check_56985 == -1LL)
    goto L1; // [33] 44

    /** parser.e:1044			Forward_InitCheck( tok, init_check )*/
    Ref(_tok_56984);
    _43Forward_InitCheck(_tok_56984, _init_check_56985);
L1: 

    /** parser.e:1047	end procedure*/
    DeRef(_tok_56984);
    return;
    ;
}


void _43Forward_call(object _tok_57003, object _opcode_57004)
{
    object _args_57007 = NOVALUE;
    object _proc_57009 = NOVALUE;
    object _tok_id_57012 = NOVALUE;
    object _id_57019 = NOVALUE;
    object _fc_pc_57043 = NOVALUE;
    object _28785 = NOVALUE;
    object _28784 = NOVALUE;
    object _28781 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1050		integer args = 0*/
    _args_57007 = 0LL;

    /** parser.e:1051		symtab_index proc = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_57003);
    _proc_57009 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_proc_57009)){
        _proc_57009 = (object)DBL_PTR(_proc_57009)->dbl;
    }

    /** parser.e:1052		integer tok_id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57003);
    _tok_id_57012 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_tok_id_57012)){
        _tok_id_57012 = (object)DBL_PTR(_tok_id_57012)->dbl;
    }

    /** parser.e:1053		remove_symbol( proc )*/
    _53remove_symbol(_proc_57009);

    /** parser.e:1054		short_circuit -= 1*/
    _43short_circuit_55468 = _43short_circuit_55468 - 1LL;

    /** parser.e:1055		while 1 do*/
L1: 

    /** parser.e:1056			tok = next_token()*/
    _0 = _tok_57003;
    _tok_57003 = _43next_token();
    DeRef(_0);

    /** parser.e:1057			integer id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57003);
    _id_57019 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_57019)){
        _id_57019 = (object)DBL_PTR(_id_57019)->dbl;
    }

    /** parser.e:1059			switch id do*/
    _0 = _id_57019;
    switch ( _0 ){ 

        /** parser.e:1060				case COMMA then*/
        case -30:

        /** parser.e:1061					emit_opnd( 0 ) -- clean this up later*/
        _45emit_opnd(0LL);

        /** parser.e:1062					args += 1*/
        _args_57007 = _args_57007 + 1;
        goto L2; // [83] 168

        /** parser.e:1064				case RIGHT_ROUND then*/
        case -27:

        /** parser.e:1065					exit*/
        goto L3; // [93] 175
        goto L2; // [95] 168

        /** parser.e:1067				case else*/
        default:

        /** parser.e:1068					putback( tok )*/
        Ref(_tok_57003);
        _43putback(_tok_57003);

        /** parser.e:1069					call_proc( forward_expr, {} )*/
        _0 = (object)_00[_43forward_expr_56505].addr;
        (*(intptr_t (*)())_0)(
                             );

        /** parser.e:1070					args += 1*/
        _args_57007 = _args_57007 + 1;

        /** parser.e:1072					tok = next_token()*/
        _0 = _tok_57003;
        _tok_57003 = _43next_token();
        DeRef(_0);

        /** parser.e:1073					id = tok[T_ID]*/
        _2 = (object)SEQ_PTR(_tok_57003);
        _id_57019 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (!IS_ATOM_INT(_id_57019)){
            _id_57019 = (object)DBL_PTR(_id_57019)->dbl;
        }

        /** parser.e:1074					if id = RIGHT_ROUND then*/
        if (_id_57019 != -27LL)
        goto L4; // [138] 149

        /** parser.e:1075						exit*/
        goto L3; // [146] 175
L4: 

        /** parser.e:1078					if id != COMMA then*/
        if (_id_57019 == -30LL)
        goto L5; // [153] 167

        /** parser.e:1079							CompileErr(EXPECTED__OR)*/
        RefDS(_22218);
        _49CompileErr(69LL, _22218, 0LL);
L5: 
    ;}L2: 

    /** parser.e:1082		end while*/
    goto L1; // [172] 46
L3: 

    /** parser.e:1084		integer fc_pc = length( Code ) + 1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _28781 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _28781 = 1;
    }
    _fc_pc_57043 = _28781 + 1;
    _28781 = NOVALUE;

    /** parser.e:1085		emit_opnd( args )*/
    _45emit_opnd(_args_57007);

    /** parser.e:1087		op_info1 = proc*/
    _45op_info1_51473 = _proc_57009;

    /** parser.e:1088		if tok_id = QUALIFIED_VARIABLE then*/
    if (_tok_id_57012 != 512LL)
    goto L6; // [202] 226

    /** parser.e:1089			set_qualified_fwd( SymTab[proc][S_FILE_NO] )*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28784 = (object)*(((s1_ptr)_2)->base + _proc_57009);
    _2 = (object)SEQ_PTR(_28784);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _28785 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _28785 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _28784 = NOVALUE;
    Ref(_28785);
    _61set_qualified_fwd(_28785);
    _28785 = NOVALUE;
    goto L7; // [223] 232
L6: 

    /** parser.e:1091			set_qualified_fwd( -1 )*/
    _61set_qualified_fwd(-1LL);
L7: 

    /** parser.e:1093		emit_op( opcode )*/
    _45emit_op(_opcode_57004);

    /** parser.e:1094		if not TRANSLATE then*/
    if (_27TRANSLATE_20179 != 0)
    goto L8; // [241] 260

    /** parser.e:1095			if OpTrace then*/
    if (_27OpTrace_20641 == 0)
    {
        goto L9; // [248] 259
    }
    else{
    }

    /** parser.e:1096				emit_op(UPDATE_GLOBALS)*/
    _45emit_op(89LL);
L9: 
L8: 

    /** parser.e:1099		short_circuit += 1*/
    _43short_circuit_55468 = _43short_circuit_55468 + 1;

    /** parser.e:1100	end procedure*/
    DeRef(_tok_57003);
    return;
    ;
}


void _43Object_call(object _tok_57071)
{
    object _tok2_57073 = NOVALUE;
    object _tok3_57074 = NOVALUE;
    object _save_factors_57075 = NOVALUE;
    object _save_lhs_subs_level_57076 = NOVALUE;
    object _sym_57078 = NOVALUE;
    object _28843 = NOVALUE;
    object _28841 = NOVALUE;
    object _28838 = NOVALUE;
    object _28834 = NOVALUE;
    object _28828 = NOVALUE;
    object _28825 = NOVALUE;
    object _28824 = NOVALUE;
    object _28823 = NOVALUE;
    object _28821 = NOVALUE;
    object _28820 = NOVALUE;
    object _28818 = NOVALUE;
    object _28817 = NOVALUE;
    object _28814 = NOVALUE;
    object _28813 = NOVALUE;
    object _28812 = NOVALUE;
    object _28810 = NOVALUE;
    object _28809 = NOVALUE;
    object _28807 = NOVALUE;
    object _28806 = NOVALUE;
    object _28805 = NOVALUE;
    object _28804 = NOVALUE;
    object _28802 = NOVALUE;
    object _28801 = NOVALUE;
    object _28799 = NOVALUE;
    object _28798 = NOVALUE;
    object _28795 = NOVALUE;
    object _28793 = NOVALUE;
    object _28792 = NOVALUE;
    object _28790 = NOVALUE;
    object _28789 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:1104		integer save_factors, save_lhs_subs_level*/

    /** parser.e:1107		tok2 = next_token()*/
    _0 = _tok2_57073;
    _tok2_57073 = _43next_token();
    DeRef(_0);

    /** parser.e:1108		if tok2[T_ID] = VARIABLE or tok2[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok2_57073);
    _28789 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28789)) {
        _28790 = (_28789 == -100LL);
    }
    else {
        _28790 = binary_op(EQUALS, _28789, -100LL);
    }
    _28789 = NOVALUE;
    if (IS_ATOM_INT(_28790)) {
        if (_28790 != 0) {
            goto L1; // [22] 43
        }
    }
    else {
        if (DBL_PTR(_28790)->dbl != 0.0) {
            goto L1; // [22] 43
        }
    }
    _2 = (object)SEQ_PTR(_tok2_57073);
    _28792 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28792)) {
        _28793 = (_28792 == 512LL);
    }
    else {
        _28793 = binary_op(EQUALS, _28792, 512LL);
    }
    _28792 = NOVALUE;
    if (_28793 == 0) {
        DeRef(_28793);
        _28793 = NOVALUE;
        goto L2; // [39] 582
    }
    else {
        if (!IS_ATOM_INT(_28793) && DBL_PTR(_28793)->dbl == 0.0){
            DeRef(_28793);
            _28793 = NOVALUE;
            goto L2; // [39] 582
        }
        DeRef(_28793);
        _28793 = NOVALUE;
    }
    DeRef(_28793);
    _28793 = NOVALUE;
L1: 

    /** parser.e:1109			tok3 = next_token()*/
    _0 = _tok3_57074;
    _tok3_57074 = _43next_token();
    DeRef(_0);

    /** parser.e:1110			if tok3[T_ID] = RIGHT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok3_57074);
    _28795 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28795, -27LL)){
        _28795 = NOVALUE;
        goto L3; // [58] 155
    }
    _28795 = NOVALUE;

    /** parser.e:1112				sym = tok2[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok2_57073);
    _sym_57078 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_sym_57078)){
        _sym_57078 = (object)DBL_PTR(_sym_57078)->dbl;
    }

    /** parser.e:1113				if SymTab[sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28798 = (object)*(((s1_ptr)_2)->base + _sym_57078);
    _2 = (object)SEQ_PTR(_28798);
    _28799 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28798 = NOVALUE;
    if (binary_op_a(NOTEQ, _28799, 9LL)){
        _28799 = NOVALUE;
        goto L4; // [88] 108
    }
    _28799 = NOVALUE;

    /** parser.e:1114					Forward_var( tok2 )*/
    _2 = (object)SEQ_PTR(_tok2_57073);
    _28801 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_tok2_57073);
    Ref(_28801);
    _43Forward_var(_tok2_57073, -1LL, _28801);
    _28801 = NOVALUE;
    goto L5; // [105] 147
L4: 

    /** parser.e:1116					SymTab[sym][S_USAGE] = or_bits(SymTab[sym][S_USAGE], U_READ)*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_57078 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28804 = (object)*(((s1_ptr)_2)->base + _sym_57078);
    _2 = (object)SEQ_PTR(_28804);
    _28805 = (object)*(((s1_ptr)_2)->base + 5LL);
    _28804 = NOVALUE;
    if (IS_ATOM_INT(_28805)) {
        {uintptr_t tu;
             tu = (uintptr_t)_28805 | (uintptr_t)1LL;
             _28806 = MAKE_UINT(tu);
        }
    }
    else {
        _28806 = binary_op(OR_BITS, _28805, 1LL);
    }
    _28805 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _28806;
    if( _1 != _28806 ){
        DeRef(_1);
    }
    _28806 = NOVALUE;
    _28802 = NOVALUE;

    /** parser.e:1118					emit_opnd(sym)*/
    _45emit_opnd(_sym_57078);
L5: 

    /** parser.e:1120				putback( tok3 )*/
    Ref(_tok3_57074);
    _43putback(_tok3_57074);
    goto L6; // [152] 571
L3: 

    /** parser.e:1122			elsif tok3[T_ID] = COMMA then*/
    _2 = (object)SEQ_PTR(_tok3_57074);
    _28807 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28807, -30LL)){
        _28807 = NOVALUE;
        goto L7; // [165] 184
    }
    _28807 = NOVALUE;

    /** parser.e:1124				WrongNumberArgs(tok[T_SYM], "")*/
    _2 = (object)SEQ_PTR(_tok_57071);
    _28809 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_28809);
    RefDS(_22218);
    _43WrongNumberArgs(_28809, _22218);
    _28809 = NOVALUE;
    goto L6; // [181] 571
L7: 

    /** parser.e:1126			elsif tok3[T_ID] = LEFT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok3_57074);
    _28810 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28810, -26LL)){
        _28810 = NOVALUE;
        goto L8; // [194] 244
    }
    _28810 = NOVALUE;

    /** parser.e:1127				if SymTab[tok2[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_tok2_57073);
    _28812 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_28812)){
        _28813 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28812)->dbl));
    }
    else{
        _28813 = (object)*(((s1_ptr)_2)->base + _28812);
    }
    _2 = (object)SEQ_PTR(_28813);
    _28814 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28813 = NOVALUE;
    if (binary_op_a(NOTEQ, _28814, 9LL)){
        _28814 = NOVALUE;
        goto L9; // [220] 235
    }
    _28814 = NOVALUE;

    /** parser.e:1128					Forward_call( tok2, FUNC_FORWARD )*/
    Ref(_tok2_57073);
    _43Forward_call(_tok2_57073, 196LL);
    goto L6; // [232] 571
L9: 

    /** parser.e:1130					Function_call( tok2 )*/
    Ref(_tok2_57073);
    _43Function_call(_tok2_57073);
    goto L6; // [241] 571
L8: 

    /** parser.e:1139				sym = tok2[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok2_57073);
    _sym_57078 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_sym_57078)){
        _sym_57078 = (object)DBL_PTR(_sym_57078)->dbl;
    }

    /** parser.e:1140				if SymTab[sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28817 = (object)*(((s1_ptr)_2)->base + _sym_57078);
    _2 = (object)SEQ_PTR(_28817);
    _28818 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28817 = NOVALUE;
    if (binary_op_a(NOTEQ, _28818, 9LL)){
        _28818 = NOVALUE;
        goto LA; // [270] 292
    }
    _28818 = NOVALUE;

    /** parser.e:1141					Forward_var( tok2, TRUE )*/
    _2 = (object)SEQ_PTR(_tok2_57073);
    _28820 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_tok2_57073);
    Ref(_28820);
    _43Forward_var(_tok2_57073, _9TRUE_441, _28820);
    _28820 = NOVALUE;
    goto LB; // [289] 339
LA: 

    /** parser.e:1143					SymTab[sym][S_USAGE] = or_bits(SymTab[sym][S_USAGE], U_READ)*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_57078 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28823 = (object)*(((s1_ptr)_2)->base + _sym_57078);
    _2 = (object)SEQ_PTR(_28823);
    _28824 = (object)*(((s1_ptr)_2)->base + 5LL);
    _28823 = NOVALUE;
    if (IS_ATOM_INT(_28824)) {
        {uintptr_t tu;
             tu = (uintptr_t)_28824 | (uintptr_t)1LL;
             _28825 = MAKE_UINT(tu);
        }
    }
    else {
        _28825 = binary_op(OR_BITS, _28824, 1LL);
    }
    _28824 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _28825;
    if( _1 != _28825 ){
        DeRef(_1);
    }
    _28825 = NOVALUE;
    _28821 = NOVALUE;

    /** parser.e:1144					InitCheck(sym, TRUE)*/
    _43InitCheck(_sym_57078, _9TRUE_441);

    /** parser.e:1145					emit_opnd(sym)*/
    _45emit_opnd(_sym_57078);
LB: 

    /** parser.e:1149				if sym = left_sym then*/
    if (_sym_57078 != _43left_sym_55509)
    goto LC; // [343] 353

    /** parser.e:1150					lhs_subs_level = 0*/
    _43lhs_subs_level_55507 = 0LL;
LC: 

    /** parser.e:1155				tok2 = tok3*/
    Ref(_tok3_57074);
    DeRef(_tok2_57073);
    _tok2_57073 = _tok3_57074;

    /** parser.e:1156				current_sequence = append(current_sequence, sym)*/
    Append(&_45current_sequence_51481, _45current_sequence_51481, _sym_57078);

    /** parser.e:1157				while tok2[T_ID] = LEFT_SQUARE do*/
LD: 
    _2 = (object)SEQ_PTR(_tok2_57073);
    _28828 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28828, -28LL)){
        _28828 = NOVALUE;
        goto LE; // [381] 549
    }
    _28828 = NOVALUE;

    /** parser.e:1158					subs_depth += 1*/
    _43subs_depth_55510 = _43subs_depth_55510 + 1;

    /** parser.e:1159					if lhs_subs_level >= 0 then*/
    if (_43lhs_subs_level_55507 < 0LL)
    goto LF; // [397] 410

    /** parser.e:1160						lhs_subs_level += 1*/
    _43lhs_subs_level_55507 = _43lhs_subs_level_55507 + 1;
LF: 

    /** parser.e:1162					save_factors = factors*/
    _save_factors_57075 = _43factors_55506;

    /** parser.e:1163					save_lhs_subs_level = lhs_subs_level*/
    _save_lhs_subs_level_57076 = _43lhs_subs_level_55507;

    /** parser.e:1164					call_proc(forward_expr, {})*/
    _0 = (object)_00[_43forward_expr_56505].addr;
    (*(intptr_t (*)())_0)(
                         );

    /** parser.e:1165					tok2 = next_token()*/
    _0 = _tok2_57073;
    _tok2_57073 = _43next_token();
    DeRef(_0);

    /** parser.e:1166					if tok2[T_ID] = SLICE then*/
    _2 = (object)SEQ_PTR(_tok2_57073);
    _28834 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28834, 513LL)){
        _28834 = NOVALUE;
        goto L10; // [446] 484
    }
    _28834 = NOVALUE;

    /** parser.e:1167						call_proc(forward_expr, {})*/
    _0 = (object)_00[_43forward_expr_56505].addr;
    (*(intptr_t (*)())_0)(
                         );

    /** parser.e:1168						emit_op(RHS_SLICE)*/
    _45emit_op(46LL);

    /** parser.e:1169						tok_match(RIGHT_SQUARE)*/
    _43tok_match(-29LL, 0LL);

    /** parser.e:1170						tok2 = next_token()*/
    _0 = _tok2_57073;
    _tok2_57073 = _43next_token();
    DeRef(_0);

    /** parser.e:1171						exit*/
    goto LE; // [479] 549
    goto L11; // [481] 529
L10: 

    /** parser.e:1173						putback(tok2)*/
    Ref(_tok2_57073);
    _43putback(_tok2_57073);

    /** parser.e:1174						tok_match(RIGHT_SQUARE)*/
    _43tok_match(-29LL, 0LL);

    /** parser.e:1175						subs_depth -= 1*/
    _43subs_depth_55510 = _43subs_depth_55510 - 1LL;

    /** parser.e:1176						current_sequence = remove( current_sequence, length( current_sequence ) )*/
    if (IS_SEQUENCE(_45current_sequence_51481)){
            _28838 = SEQ_PTR(_45current_sequence_51481)->length;
    }
    else {
        _28838 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_45current_sequence_51481);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_28838)) ? _28838 : (object)(DBL_PTR(_28838)->dbl);
        int stop = (IS_ATOM_INT(_28838)) ? _28838 : (object)(DBL_PTR(_28838)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_45current_sequence_51481), start, &_45current_sequence_51481 );
            }
            else Tail(SEQ_PTR(_45current_sequence_51481), stop+1, &_45current_sequence_51481);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_45current_sequence_51481), start, &_45current_sequence_51481);
        }
        else {
            assign_slice_seq = &assign_space;
            _45current_sequence_51481 = Remove_elements(start, stop, (SEQ_PTR(_45current_sequence_51481)->ref == 1));
        }
    }
    _28838 = NOVALUE;
    _28838 = NOVALUE;

    /** parser.e:1177						emit_op(RHS_SUBS)*/
    _45emit_op(25LL);
L11: 

    /** parser.e:1180					factors = save_factors*/
    _43factors_55506 = _save_factors_57075;

    /** parser.e:1181					lhs_subs_level = save_lhs_subs_level*/
    _43lhs_subs_level_55507 = _save_lhs_subs_level_57076;

    /** parser.e:1182					tok2 = next_token()*/
    _0 = _tok2_57073;
    _tok2_57073 = _43next_token();
    DeRef(_0);

    /** parser.e:1183				end while*/
    goto LD; // [546] 373
LE: 

    /** parser.e:1184				current_sequence = remove( current_sequence, length( current_sequence ) )*/
    if (IS_SEQUENCE(_45current_sequence_51481)){
            _28841 = SEQ_PTR(_45current_sequence_51481)->length;
    }
    else {
        _28841 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_45current_sequence_51481);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_28841)) ? _28841 : (object)(DBL_PTR(_28841)->dbl);
        int stop = (IS_ATOM_INT(_28841)) ? _28841 : (object)(DBL_PTR(_28841)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_45current_sequence_51481), start, &_45current_sequence_51481 );
            }
            else Tail(SEQ_PTR(_45current_sequence_51481), stop+1, &_45current_sequence_51481);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_45current_sequence_51481), start, &_45current_sequence_51481);
        }
        else {
            assign_slice_seq = &assign_space;
            _45current_sequence_51481 = Remove_elements(start, stop, (SEQ_PTR(_45current_sequence_51481)->ref == 1));
        }
    }
    _28841 = NOVALUE;
    _28841 = NOVALUE;

    /** parser.e:1185				putback(tok2)*/
    Ref(_tok2_57073);
    _43putback(_tok2_57073);
L6: 

    /** parser.e:1189			tok_match( RIGHT_ROUND )*/
    _43tok_match(-27LL, 0LL);
    goto L12; // [579] 599
L2: 

    /** parser.e:1191			putback(tok2)*/
    Ref(_tok2_57073);
    _43putback(_tok2_57073);

    /** parser.e:1192			ParseArgs(tok[T_SYM])*/
    _2 = (object)SEQ_PTR(_tok_57071);
    _28843 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_28843);
    _43ParseArgs(_28843);
    _28843 = NOVALUE;
L12: 

    /** parser.e:1194	end procedure*/
    DeRef(_tok_57071);
    DeRef(_tok2_57073);
    DeRef(_tok3_57074);
    _28812 = NOVALUE;
    DeRef(_28790);
    _28790 = NOVALUE;
    return;
    ;
}


void _43Function_call(object _tok_57216)
{
    object _id_57217 = NOVALUE;
    object _scope_57218 = NOVALUE;
    object _opcode_57219 = NOVALUE;
    object _e_57220 = NOVALUE;
    object _28885 = NOVALUE;
    object _28884 = NOVALUE;
    object _28883 = NOVALUE;
    object _28882 = NOVALUE;
    object _28881 = NOVALUE;
    object _28880 = NOVALUE;
    object _28879 = NOVALUE;
    object _28877 = NOVALUE;
    object _28876 = NOVALUE;
    object _28874 = NOVALUE;
    object _28873 = NOVALUE;
    object _28872 = NOVALUE;
    object _28871 = NOVALUE;
    object _28870 = NOVALUE;
    object _28869 = NOVALUE;
    object _28868 = NOVALUE;
    object _28867 = NOVALUE;
    object _28865 = NOVALUE;
    object _28864 = NOVALUE;
    object _28863 = NOVALUE;
    object _28862 = NOVALUE;
    object _28861 = NOVALUE;
    object _28860 = NOVALUE;
    object _28859 = NOVALUE;
    object _28857 = NOVALUE;
    object _28855 = NOVALUE;
    object _28854 = NOVALUE;
    object _28852 = NOVALUE;
    object _28850 = NOVALUE;
    object _28849 = NOVALUE;
    object _28848 = NOVALUE;
    object _28847 = NOVALUE;
    object _28845 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:1200		id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57216);
    _id_57217 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_57217)){
        _id_57217 = (object)DBL_PTR(_id_57217)->dbl;
    }

    /** parser.e:1201		if id = FUNC or id = TYPE then*/
    _28845 = (_id_57217 == 501LL);
    if (_28845 != 0) {
        goto L1; // [19] 34
    }
    _28847 = (_id_57217 == 504LL);
    if (_28847 == 0)
    {
        DeRef(_28847);
        _28847 = NOVALUE;
        goto L2; // [30] 46
    }
    else{
        DeRef(_28847);
        _28847 = NOVALUE;
    }
L1: 

    /** parser.e:1203			UndefinedVar( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_57216);
    _28848 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_28848);
    _43UndefinedVar(_28848);
    _28848 = NOVALUE;
L2: 

    /** parser.e:1206		e = SymTab[tok[T_SYM]][S_EFFECT]*/
    _2 = (object)SEQ_PTR(_tok_57216);
    _28849 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_28849)){
        _28850 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28849)->dbl));
    }
    else{
        _28850 = (object)*(((s1_ptr)_2)->base + _28849);
    }
    _2 = (object)SEQ_PTR(_28850);
    _e_57220 = (object)*(((s1_ptr)_2)->base + 23LL);
    if (!IS_ATOM_INT(_e_57220)){
        _e_57220 = (object)DBL_PTR(_e_57220)->dbl;
    }
    _28850 = NOVALUE;

    /** parser.e:1207		if e then*/
    if (_e_57220 == 0)
    {
        goto L3; // [70] 229
    }
    else{
    }

    /** parser.e:1209			if e = E_ALL_EFFECT or tok[T_SYM] > left_sym then*/
    _28852 = (_e_57220 == 1073741823LL);
    if (_28852 != 0) {
        goto L4; // [81] 102
    }
    _2 = (object)SEQ_PTR(_tok_57216);
    _28854 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_28854)) {
        _28855 = (_28854 > _43left_sym_55509);
    }
    else {
        _28855 = binary_op(GREATER, _28854, _43left_sym_55509);
    }
    _28854 = NOVALUE;
    if (_28855 == 0) {
        DeRef(_28855);
        _28855 = NOVALUE;
        goto L5; // [98] 111
    }
    else {
        if (!IS_ATOM_INT(_28855) && DBL_PTR(_28855)->dbl == 0.0){
            DeRef(_28855);
            _28855 = NOVALUE;
            goto L5; // [98] 111
        }
        DeRef(_28855);
        _28855 = NOVALUE;
    }
    DeRef(_28855);
    _28855 = NOVALUE;
L4: 

    /** parser.e:1211				side_effect_calls = or_bits(side_effect_calls, e)*/
    {uintptr_t tu;
         tu = (uintptr_t)_43side_effect_calls_55505 | (uintptr_t)_e_57220;
         _43side_effect_calls_55505 = MAKE_UINT(tu);
    }
L5: 

    /** parser.e:1214			SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT], e)*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27CurrentSub_20579 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28859 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_28859);
    _28860 = (object)*(((s1_ptr)_2)->base + 23LL);
    _28859 = NOVALUE;
    if (IS_ATOM_INT(_28860)) {
        {uintptr_t tu;
             tu = (uintptr_t)_28860 | (uintptr_t)_e_57220;
             _28861 = MAKE_UINT(tu);
        }
    }
    else {
        _28861 = binary_op(OR_BITS, _28860, _e_57220);
    }
    _28860 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _28861;
    if( _1 != _28861 ){
        DeRef(_1);
    }
    _28861 = NOVALUE;
    _28857 = NOVALUE;

    /** parser.e:1216			if short_circuit > 0 and short_circuit_B and*/
    _28862 = (_43short_circuit_55468 > 0LL);
    if (_28862 == 0) {
        _28863 = 0;
        goto L6; // [154] 164
    }
    _28863 = (_43short_circuit_B_55470 != 0);
L6: 
    if (_28863 == 0) {
        goto L7; // [164] 228
    }
    _28865 = find_from(_id_57217, _29FUNC_TOKS_12289, 1LL);
    if (_28865 == 0)
    {
        _28865 = NOVALUE;
        goto L7; // [176] 228
    }
    else{
        _28865 = NOVALUE;
    }

    /** parser.e:1218				Warning(219, short_circuit_warning_flag,*/
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _28867 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    Ref(_28867);
    RefDS(_22218);
    _28868 = _15abbreviate_path(_28867, _22218);
    _28867 = NOVALUE;
    _2 = (object)SEQ_PTR(_tok_57216);
    _28869 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_28869)){
        _28870 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28869)->dbl));
    }
    else{
        _28870 = (object)*(((s1_ptr)_2)->base + _28869);
    }
    _2 = (object)SEQ_PTR(_28870);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _28871 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _28871 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _28870 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _28868;
    ((intptr_t*)_2)[2] = _27line_number_20572;
    Ref(_28871);
    ((intptr_t*)_2)[3] = _28871;
    _28872 = MAKE_SEQ(_1);
    _28871 = NOVALUE;
    _28868 = NOVALUE;
    _49Warning(219LL, 2LL, _28872);
    _28872 = NOVALUE;
L7: 
L3: 

    /** parser.e:1222		tok_match(LEFT_ROUND)*/
    _43tok_match(-26LL, 0LL);

    /** parser.e:1223		scope = SymTab[tok[T_SYM]][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_tok_57216);
    _28873 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_28873)){
        _28874 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28873)->dbl));
    }
    else{
        _28874 = (object)*(((s1_ptr)_2)->base + _28873);
    }
    _2 = (object)SEQ_PTR(_28874);
    _scope_57218 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_scope_57218)){
        _scope_57218 = (object)DBL_PTR(_scope_57218)->dbl;
    }
    _28874 = NOVALUE;

    /** parser.e:1224		opcode = SymTab[tok[T_SYM]][S_OPCODE]*/
    _2 = (object)SEQ_PTR(_tok_57216);
    _28876 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_28876)){
        _28877 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28876)->dbl));
    }
    else{
        _28877 = (object)*(((s1_ptr)_2)->base + _28876);
    }
    _2 = (object)SEQ_PTR(_28877);
    _opcode_57219 = (object)*(((s1_ptr)_2)->base + 21LL);
    if (!IS_ATOM_INT(_opcode_57219)){
        _opcode_57219 = (object)DBL_PTR(_opcode_57219)->dbl;
    }
    _28877 = NOVALUE;

    /** parser.e:1225		if equal(SymTab[tok[T_SYM]][S_NAME],"object") and scope = SC_PREDEF then*/
    _2 = (object)SEQ_PTR(_tok_57216);
    _28879 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_28879)){
        _28880 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28879)->dbl));
    }
    else{
        _28880 = (object)*(((s1_ptr)_2)->base + _28879);
    }
    _2 = (object)SEQ_PTR(_28880);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _28881 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _28881 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _28880 = NOVALUE;
    if (_28881 == _23193)
    _28882 = 1;
    else if (IS_ATOM_INT(_28881) && IS_ATOM_INT(_23193))
    _28882 = 0;
    else
    _28882 = (compare(_28881, _23193) == 0);
    _28881 = NOVALUE;
    if (_28882 == 0) {
        goto L8; // [305] 327
    }
    _28884 = (_scope_57218 == 7LL);
    if (_28884 == 0)
    {
        DeRef(_28884);
        _28884 = NOVALUE;
        goto L8; // [316] 327
    }
    else{
        DeRef(_28884);
        _28884 = NOVALUE;
    }

    /** parser.e:1227			Object_call( tok )*/
    Ref(_tok_57216);
    _43Object_call(_tok_57216);
    goto L9; // [324] 339
L8: 

    /** parser.e:1230			ParseArgs(tok[T_SYM])*/
    _2 = (object)SEQ_PTR(_tok_57216);
    _28885 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_28885);
    _43ParseArgs(_28885);
    _28885 = NOVALUE;
L9: 

    /** parser.e:1233		if scope = SC_PREDEF then*/
    if (_scope_57218 != 7LL)
    goto LA; // [343] 355

    /** parser.e:1234			emit_op(opcode)*/
    _45emit_op(_opcode_57219);
    goto LB; // [352] 393
LA: 

    /** parser.e:1236			op_info1 = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_57216);
    _45op_info1_51473 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_45op_info1_51473)){
        _45op_info1_51473 = (object)DBL_PTR(_45op_info1_51473)->dbl;
    }

    /** parser.e:1238			emit_or_inline()*/
    _66emit_or_inline();

    /** parser.e:1239			if not TRANSLATE then*/
    if (_27TRANSLATE_20179 != 0)
    goto LC; // [373] 392

    /** parser.e:1240				if OpTrace then*/
    if (_27OpTrace_20641 == 0)
    {
        goto LD; // [380] 391
    }
    else{
    }

    /** parser.e:1241					emit_op(UPDATE_GLOBALS)*/
    _45emit_op(89LL);
LD: 
LC: 
LB: 

    /** parser.e:1245	end procedure*/
    DeRef(_tok_57216);
    _28876 = NOVALUE;
    _28869 = NOVALUE;
    _28879 = NOVALUE;
    DeRef(_28845);
    _28845 = NOVALUE;
    _28873 = NOVALUE;
    DeRef(_28852);
    _28852 = NOVALUE;
    _28849 = NOVALUE;
    DeRef(_28862);
    _28862 = NOVALUE;
    return;
    ;
}


void _43Factor()
{
    object _tok_57325 = NOVALUE;
    object _id_57326 = NOVALUE;
    object _n_57327 = NOVALUE;
    object _save_factors_57328 = NOVALUE;
    object _save_lhs_subs_level_57329 = NOVALUE;
    object _sym_57331 = NOVALUE;
    object _forward_57362 = NOVALUE;
    object _28945 = NOVALUE;
    object _28944 = NOVALUE;
    object _28943 = NOVALUE;
    object _28941 = NOVALUE;
    object _28940 = NOVALUE;
    object _28939 = NOVALUE;
    object _28938 = NOVALUE;
    object _28937 = NOVALUE;
    object _28935 = NOVALUE;
    object _28931 = NOVALUE;
    object _28928 = NOVALUE;
    object _28924 = NOVALUE;
    object _28918 = NOVALUE;
    object _28913 = NOVALUE;
    object _28912 = NOVALUE;
    object _28911 = NOVALUE;
    object _28909 = NOVALUE;
    object _28908 = NOVALUE;
    object _28906 = NOVALUE;
    object _28904 = NOVALUE;
    object _28903 = NOVALUE;
    object _28902 = NOVALUE;
    object _28900 = NOVALUE;
    object _28893 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:1250		integer id, n*/

    /** parser.e:1251		integer save_factors, save_lhs_subs_level*/

    /** parser.e:1254		factors += 1*/
    _43factors_55506 = _43factors_55506 + 1;

    /** parser.e:1255		tok = next_token()*/
    _0 = _tok_57325;
    _tok_57325 = _43next_token();
    DeRef(_0);

    /** parser.e:1256		id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57325);
    _id_57326 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_57326)){
        _id_57326 = (object)DBL_PTR(_id_57326)->dbl;
    }

    /** parser.e:1257		if id = RECORDED then*/
    if (_id_57326 != 508LL)
    goto L1; // [32] 59

    /** parser.e:1258			tok = read_recorded_token(tok[T_SYM])*/
    _2 = (object)SEQ_PTR(_tok_57325);
    _28893 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_28893);
    _0 = _tok_57325;
    _tok_57325 = _43read_recorded_token(_28893);
    DeRef(_0);
    _28893 = NOVALUE;

    /** parser.e:1259			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57325);
    _id_57326 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_57326)){
        _id_57326 = (object)DBL_PTR(_id_57326)->dbl;
    }
L1: 

    /** parser.e:1261		switch id label "factor" do*/
    _0 = _id_57326;
    switch ( _0 ){ 

        /** parser.e:1262			case VARIABLE, QUALIFIED_VARIABLE then*/
        case -100:
        case 512:

        /** parser.e:1263				sym = tok[T_SYM]*/
        _2 = (object)SEQ_PTR(_tok_57325);
        _sym_57331 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_sym_57331)){
            _sym_57331 = (object)DBL_PTR(_sym_57331)->dbl;
        }

        /** parser.e:1264				if sym < 0 or SymTab[sym][S_SCOPE] = SC_UNDEFINED then*/
        _28900 = (_sym_57331 < 0LL);
        if (_28900 != 0) {
            goto L2; // [88] 115
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28902 = (object)*(((s1_ptr)_2)->base + _sym_57331);
        _2 = (object)SEQ_PTR(_28902);
        _28903 = (object)*(((s1_ptr)_2)->base + 4LL);
        _28902 = NOVALUE;
        if (IS_ATOM_INT(_28903)) {
            _28904 = (_28903 == 9LL);
        }
        else {
            _28904 = binary_op(EQUALS, _28903, 9LL);
        }
        _28903 = NOVALUE;
        if (_28904 == 0) {
            DeRef(_28904);
            _28904 = NOVALUE;
            goto L3; // [111] 177
        }
        else {
            if (!IS_ATOM_INT(_28904) && DBL_PTR(_28904)->dbl == 0.0){
                DeRef(_28904);
                _28904 = NOVALUE;
                goto L3; // [111] 177
            }
            DeRef(_28904);
            _28904 = NOVALUE;
        }
        DeRef(_28904);
        _28904 = NOVALUE;
L2: 

        /** parser.e:1265					token forward = next_token()*/
        _0 = _forward_57362;
        _forward_57362 = _43next_token();
        DeRef(_0);

        /** parser.e:1266					if forward[T_ID] = LEFT_ROUND then*/
        _2 = (object)SEQ_PTR(_forward_57362);
        _28906 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _28906, -26LL)){
            _28906 = NOVALUE;
            goto L4; // [130] 151
        }
        _28906 = NOVALUE;

        /** parser.e:1267						Forward_call( tok, FUNC_FORWARD )*/
        Ref(_tok_57325);
        _43Forward_call(_tok_57325, 196LL);

        /** parser.e:1268						break "factor"*/
        DeRef(_forward_57362);
        _forward_57362 = NOVALUE;
        goto L5; // [146] 694
        goto L6; // [148] 172
L4: 

        /** parser.e:1270						putback( forward )*/
        Ref(_forward_57362);
        _43putback(_forward_57362);

        /** parser.e:1271						Forward_var( tok, TRUE )*/
        _2 = (object)SEQ_PTR(_tok_57325);
        _28908 = (object)*(((s1_ptr)_2)->base + 1LL);
        Ref(_tok_57325);
        Ref(_28908);
        _43Forward_var(_tok_57325, _9TRUE_441, _28908);
        _28908 = NOVALUE;
L6: 
        DeRef(_forward_57362);
        _forward_57362 = NOVALUE;
        goto L7; // [174] 229
L3: 

        /** parser.e:1275					UndefinedVar(sym)*/
        _43UndefinedVar(_sym_57331);

        /** parser.e:1276					SymTab[sym][S_USAGE] = or_bits(SymTab[sym][S_USAGE], U_READ)*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_sym_57331 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28911 = (object)*(((s1_ptr)_2)->base + _sym_57331);
        _2 = (object)SEQ_PTR(_28911);
        _28912 = (object)*(((s1_ptr)_2)->base + 5LL);
        _28911 = NOVALUE;
        if (IS_ATOM_INT(_28912)) {
            {uintptr_t tu;
                 tu = (uintptr_t)_28912 | (uintptr_t)1LL;
                 _28913 = MAKE_UINT(tu);
            }
        }
        else {
            _28913 = binary_op(OR_BITS, _28912, 1LL);
        }
        _28912 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _28913;
        if( _1 != _28913 ){
            DeRef(_1);
        }
        _28913 = NOVALUE;
        _28909 = NOVALUE;

        /** parser.e:1277					InitCheck(sym, TRUE)*/
        _43InitCheck(_sym_57331, _9TRUE_441);

        /** parser.e:1278					emit_opnd(sym)*/
        _45emit_opnd(_sym_57331);
L7: 

        /** parser.e:1281				if sym = left_sym then*/
        if (_sym_57331 != _43left_sym_55509)
        goto L8; // [233] 243

        /** parser.e:1282					lhs_subs_level = 0 -- start counting subscripts*/
        _43lhs_subs_level_55507 = 0LL;
L8: 

        /** parser.e:1285				short_circuit -= 1*/
        _43short_circuit_55468 = _43short_circuit_55468 - 1LL;

        /** parser.e:1286				tok = next_token()*/
        _0 = _tok_57325;
        _tok_57325 = _43next_token();
        DeRef(_0);

        /** parser.e:1287				current_sequence = append(current_sequence, sym)*/
        Append(&_45current_sequence_51481, _45current_sequence_51481, _sym_57331);

        /** parser.e:1288				while tok[T_ID] = LEFT_SQUARE do*/
L9: 
        _2 = (object)SEQ_PTR(_tok_57325);
        _28918 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _28918, -28LL)){
            _28918 = NOVALUE;
            goto LA; // [279] 447
        }
        _28918 = NOVALUE;

        /** parser.e:1289					subs_depth += 1*/
        _43subs_depth_55510 = _43subs_depth_55510 + 1;

        /** parser.e:1290					if lhs_subs_level >= 0 then*/
        if (_43lhs_subs_level_55507 < 0LL)
        goto LB; // [295] 308

        /** parser.e:1291						lhs_subs_level += 1*/
        _43lhs_subs_level_55507 = _43lhs_subs_level_55507 + 1;
LB: 

        /** parser.e:1293					save_factors = factors*/
        _save_factors_57328 = _43factors_55506;

        /** parser.e:1294					save_lhs_subs_level = lhs_subs_level*/
        _save_lhs_subs_level_57329 = _43lhs_subs_level_55507;

        /** parser.e:1295					call_proc(forward_expr, {})*/
        _0 = (object)_00[_43forward_expr_56505].addr;
        (*(intptr_t (*)())_0)(
                             );

        /** parser.e:1296					tok = next_token()*/
        _0 = _tok_57325;
        _tok_57325 = _43next_token();
        DeRef(_0);

        /** parser.e:1297					if tok[T_ID] = SLICE then*/
        _2 = (object)SEQ_PTR(_tok_57325);
        _28924 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _28924, 513LL)){
            _28924 = NOVALUE;
            goto LC; // [344] 382
        }
        _28924 = NOVALUE;

        /** parser.e:1298						call_proc(forward_expr, {})*/
        _0 = (object)_00[_43forward_expr_56505].addr;
        (*(intptr_t (*)())_0)(
                             );

        /** parser.e:1299						emit_op(RHS_SLICE)*/
        _45emit_op(46LL);

        /** parser.e:1300						tok_match(RIGHT_SQUARE)*/
        _43tok_match(-29LL, 0LL);

        /** parser.e:1301						tok = next_token()*/
        _0 = _tok_57325;
        _tok_57325 = _43next_token();
        DeRef(_0);

        /** parser.e:1302						exit*/
        goto LA; // [377] 447
        goto LD; // [379] 427
LC: 

        /** parser.e:1304						putback(tok)*/
        Ref(_tok_57325);
        _43putback(_tok_57325);

        /** parser.e:1305						tok_match(RIGHT_SQUARE)*/
        _43tok_match(-29LL, 0LL);

        /** parser.e:1306						subs_depth -= 1*/
        _43subs_depth_55510 = _43subs_depth_55510 - 1LL;

        /** parser.e:1307						current_sequence = remove( current_sequence, length( current_sequence ) )*/
        if (IS_SEQUENCE(_45current_sequence_51481)){
                _28928 = SEQ_PTR(_45current_sequence_51481)->length;
        }
        else {
            _28928 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_45current_sequence_51481);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_28928)) ? _28928 : (object)(DBL_PTR(_28928)->dbl);
            int stop = (IS_ATOM_INT(_28928)) ? _28928 : (object)(DBL_PTR(_28928)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_45current_sequence_51481), start, &_45current_sequence_51481 );
                }
                else Tail(SEQ_PTR(_45current_sequence_51481), stop+1, &_45current_sequence_51481);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_45current_sequence_51481), start, &_45current_sequence_51481);
            }
            else {
                assign_slice_seq = &assign_space;
                _45current_sequence_51481 = Remove_elements(start, stop, (SEQ_PTR(_45current_sequence_51481)->ref == 1));
            }
        }
        _28928 = NOVALUE;
        _28928 = NOVALUE;

        /** parser.e:1308						emit_op(RHS_SUBS) -- current_sequence will be updated*/
        _45emit_op(25LL);
LD: 

        /** parser.e:1310					factors = save_factors*/
        _43factors_55506 = _save_factors_57328;

        /** parser.e:1311					lhs_subs_level = save_lhs_subs_level*/
        _43lhs_subs_level_55507 = _save_lhs_subs_level_57329;

        /** parser.e:1312					tok = next_token()*/
        _0 = _tok_57325;
        _tok_57325 = _43next_token();
        DeRef(_0);

        /** parser.e:1313				end while*/
        goto L9; // [444] 271
LA: 

        /** parser.e:1314				current_sequence = remove( current_sequence, length( current_sequence ) )*/
        if (IS_SEQUENCE(_45current_sequence_51481)){
                _28931 = SEQ_PTR(_45current_sequence_51481)->length;
        }
        else {
            _28931 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_45current_sequence_51481);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_28931)) ? _28931 : (object)(DBL_PTR(_28931)->dbl);
            int stop = (IS_ATOM_INT(_28931)) ? _28931 : (object)(DBL_PTR(_28931)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_45current_sequence_51481), start, &_45current_sequence_51481 );
                }
                else Tail(SEQ_PTR(_45current_sequence_51481), stop+1, &_45current_sequence_51481);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_45current_sequence_51481), start, &_45current_sequence_51481);
            }
            else {
                assign_slice_seq = &assign_space;
                _45current_sequence_51481 = Remove_elements(start, stop, (SEQ_PTR(_45current_sequence_51481)->ref == 1));
            }
        }
        _28931 = NOVALUE;
        _28931 = NOVALUE;

        /** parser.e:1315				putback(tok)*/
        Ref(_tok_57325);
        _43putback(_tok_57325);

        /** parser.e:1316				short_circuit += 1*/
        _43short_circuit_55468 = _43short_circuit_55468 + 1;
        goto L5; // [476] 694

        /** parser.e:1318			case DOLLAR then*/
        case -22:

        /** parser.e:1319				tok = next_token()*/
        _0 = _tok_57325;
        _tok_57325 = _43next_token();
        DeRef(_0);

        /** parser.e:1320				putback(tok)*/
        Ref(_tok_57325);
        _43putback(_tok_57325);

        /** parser.e:1321				if tok[T_ID] = RIGHT_BRACE then*/
        _2 = (object)SEQ_PTR(_tok_57325);
        _28935 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _28935, -25LL)){
            _28935 = NOVALUE;
            goto LE; // [502] 520
        }
        _28935 = NOVALUE;

        /** parser.e:1322					gListItem[$] = 0*/
        if (IS_SEQUENCE(_43gListItem_55504)){
                _28937 = SEQ_PTR(_43gListItem_55504)->length;
        }
        else {
            _28937 = 1;
        }
        _2 = (object)SEQ_PTR(_43gListItem_55504);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _43gListItem_55504 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _28937);
        *(intptr_t *)_2 = 0LL;
        goto L5; // [517] 694
LE: 

        /** parser.e:1324					if subs_depth > 0 and length(current_sequence) then*/
        _28938 = (_43subs_depth_55510 > 0LL);
        if (_28938 == 0) {
            goto LF; // [528] 551
        }
        if (IS_SEQUENCE(_45current_sequence_51481)){
                _28940 = SEQ_PTR(_45current_sequence_51481)->length;
        }
        else {
            _28940 = 1;
        }
        if (_28940 == 0)
        {
            _28940 = NOVALUE;
            goto LF; // [538] 551
        }
        else{
            _28940 = NOVALUE;
        }

        /** parser.e:1325						emit_op(DOLLAR)*/
        _45emit_op(-22LL);
        goto L5; // [548] 694
LF: 

        /** parser.e:1327						CompileErr(MSG__MUST_ONLY_APPEAR_BETWEEN__AND__OR_AS_THE_LAST_ITEM_IN_A_SEQUENCE_LITERAL)*/
        RefDS(_22218);
        _49CompileErr(21LL, _22218, 0LL);
        goto L5; // [562] 694

        /** parser.e:1331			case ATOM then*/
        case 502:

        /** parser.e:1332				emit_opnd(tok[T_SYM])*/
        _2 = (object)SEQ_PTR(_tok_57325);
        _28941 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_28941);
        _45emit_opnd(_28941);
        _28941 = NOVALUE;
        goto L5; // [579] 694

        /** parser.e:1334			case LEFT_BRACE then*/
        case -24:

        /** parser.e:1335				n = Expr_list()*/
        _n_57327 = _43Expr_list();
        if (!IS_ATOM_INT(_n_57327)) {
            _1 = (object)(DBL_PTR(_n_57327)->dbl);
            DeRefDS(_n_57327);
            _n_57327 = _1;
        }

        /** parser.e:1336				tok_match(RIGHT_BRACE)*/
        _43tok_match(-25LL, 0LL);

        /** parser.e:1337				op_info1 = n*/
        _45op_info1_51473 = _n_57327;

        /** parser.e:1338				emit_op(RIGHT_BRACE_N)*/
        _45emit_op(31LL);
        goto L5; // [614] 694

        /** parser.e:1340			case STRING then*/
        case 503:

        /** parser.e:1341				emit_opnd(tok[T_SYM])*/
        _2 = (object)SEQ_PTR(_tok_57325);
        _28943 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_28943);
        _45emit_opnd(_28943);
        _28943 = NOVALUE;
        goto L5; // [631] 694

        /** parser.e:1343			case LEFT_ROUND then*/
        case -26:

        /** parser.e:1344				call_proc(forward_expr, {})*/
        _0 = (object)_00[_43forward_expr_56505].addr;
        (*(intptr_t (*)())_0)(
                             );

        /** parser.e:1345				tok_match(RIGHT_ROUND)*/
        _43tok_match(-27LL, 0LL);
        goto L5; // [652] 694

        /** parser.e:1347			case FUNC, TYPE, QUALIFIED_FUNC, QUALIFIED_TYPE then*/
        case 501:
        case 504:
        case 520:
        case 522:

        /** parser.e:1348				Function_call( tok )*/
        Ref(_tok_57325);
        _43Function_call(_tok_57325);
        goto L5; // [669] 694

        /** parser.e:1350			case else*/
        default:

        /** parser.e:1351				CompileErr(SYNTAX_ERROR__EXPECTED_TO_SEE_AN_EXPRESSION_NOT_1, {LexName(id)})*/
        RefDS(_26682);
        _28944 = _45LexName(_id_57326, _26682);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _28944;
        _28945 = MAKE_SEQ(_1);
        _28944 = NOVALUE;
        _49CompileErr(135LL, _28945, 0LL);
        _28945 = NOVALUE;
    ;}L5: 

    /** parser.e:1353	end procedure*/
    DeRef(_tok_57325);
    DeRef(_28900);
    _28900 = NOVALUE;
    DeRef(_28938);
    _28938 = NOVALUE;
    return;
    ;
}


void _43UFactor()
{
    object _tok_57484 = NOVALUE;
    object _28951 = NOVALUE;
    object _28949 = NOVALUE;
    object _28947 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1359		tok = next_token()*/
    _0 = _tok_57484;
    _tok_57484 = _43next_token();
    DeRef(_0);

    /** parser.e:1361		if tok[T_ID] = MINUS then*/
    _2 = (object)SEQ_PTR(_tok_57484);
    _28947 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28947, 10LL)){
        _28947 = NOVALUE;
        goto L1; // [16] 34
    }
    _28947 = NOVALUE;

    /** parser.e:1362			Factor()*/
    _43Factor();

    /** parser.e:1363			emit_op(UMINUS)*/
    _45emit_op(12LL);
    goto L2; // [31] 93
L1: 

    /** parser.e:1365		elsif tok[T_ID] = NOT then*/
    _2 = (object)SEQ_PTR(_tok_57484);
    _28949 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28949, 7LL)){
        _28949 = NOVALUE;
        goto L3; // [44] 62
    }
    _28949 = NOVALUE;

    /** parser.e:1366			Factor()*/
    _43Factor();

    /** parser.e:1367			emit_op(NOT)*/
    _45emit_op(7LL);
    goto L2; // [59] 93
L3: 

    /** parser.e:1369		elsif tok[T_ID] = PLUS then*/
    _2 = (object)SEQ_PTR(_tok_57484);
    _28951 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28951, 11LL)){
        _28951 = NOVALUE;
        goto L4; // [72] 83
    }
    _28951 = NOVALUE;

    /** parser.e:1370			Factor()*/
    _43Factor();
    goto L2; // [80] 93
L4: 

    /** parser.e:1373			putback(tok)*/
    Ref(_tok_57484);
    _43putback(_tok_57484);

    /** parser.e:1374			Factor()*/
    _43Factor();
L2: 

    /** parser.e:1377	end procedure*/
    DeRef(_tok_57484);
    return;
    ;
}


object _43Term()
{
    object _tok_57509 = NOVALUE;
    object _28959 = NOVALUE;
    object _28958 = NOVALUE;
    object _28957 = NOVALUE;
    object _28955 = NOVALUE;
    object _28954 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1383		UFactor()*/
    _43UFactor();

    /** parser.e:1384		tok = next_token()*/
    _0 = _tok_57509;
    _tok_57509 = _43next_token();
    DeRef(_0);

    /** parser.e:1385		while tok[T_ID] = reserved:MULTIPLY or tok[T_ID] = reserved:DIVIDE do*/
L1: 
    _2 = (object)SEQ_PTR(_tok_57509);
    _28954 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28954)) {
        _28955 = (_28954 == 13LL);
    }
    else {
        _28955 = binary_op(EQUALS, _28954, 13LL);
    }
    _28954 = NOVALUE;
    if (IS_ATOM_INT(_28955)) {
        if (_28955 != 0) {
            goto L2; // [25] 44
        }
    }
    else {
        if (DBL_PTR(_28955)->dbl != 0.0) {
            goto L2; // [25] 44
        }
    }
    _2 = (object)SEQ_PTR(_tok_57509);
    _28957 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28957)) {
        _28958 = (_28957 == 14LL);
    }
    else {
        _28958 = binary_op(EQUALS, _28957, 14LL);
    }
    _28957 = NOVALUE;
    if (_28958 <= 0) {
        if (_28958 == 0) {
            DeRef(_28958);
            _28958 = NOVALUE;
            goto L3; // [40] 69
        }
        else {
            if (!IS_ATOM_INT(_28958) && DBL_PTR(_28958)->dbl == 0.0){
                DeRef(_28958);
                _28958 = NOVALUE;
                goto L3; // [40] 69
            }
            DeRef(_28958);
            _28958 = NOVALUE;
        }
    }
    DeRef(_28958);
    _28958 = NOVALUE;
L2: 

    /** parser.e:1386			UFactor()*/
    _43UFactor();

    /** parser.e:1387			emit_op(tok[T_ID])*/
    _2 = (object)SEQ_PTR(_tok_57509);
    _28959 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_28959);
    _45emit_op(_28959);
    _28959 = NOVALUE;

    /** parser.e:1388			tok = next_token()*/
    _0 = _tok_57509;
    _tok_57509 = _43next_token();
    DeRef(_0);

    /** parser.e:1389		end while*/
    goto L1; // [66] 15
L3: 

    /** parser.e:1390		return tok*/
    DeRef(_28955);
    _28955 = NOVALUE;
    return _tok_57509;
    ;
}


object _43aexpr()
{
    object _tok_57526 = NOVALUE;
    object _id_57527 = NOVALUE;
    object _28966 = NOVALUE;
    object _28965 = NOVALUE;
    object _28963 = NOVALUE;
    object _28962 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1396		integer id*/

    /** parser.e:1398		tok = Term()*/
    _0 = _tok_57526;
    _tok_57526 = _43Term();
    DeRef(_0);

    /** parser.e:1399		while tok[T_ID] = PLUS or tok[T_ID] = MINUS do*/
L1: 
    _2 = (object)SEQ_PTR(_tok_57526);
    _28962 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28962)) {
        _28963 = (_28962 == 11LL);
    }
    else {
        _28963 = binary_op(EQUALS, _28962, 11LL);
    }
    _28962 = NOVALUE;
    if (IS_ATOM_INT(_28963)) {
        if (_28963 != 0) {
            goto L2; // [25] 46
        }
    }
    else {
        if (DBL_PTR(_28963)->dbl != 0.0) {
            goto L2; // [25] 46
        }
    }
    _2 = (object)SEQ_PTR(_tok_57526);
    _28965 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28965)) {
        _28966 = (_28965 == 10LL);
    }
    else {
        _28966 = binary_op(EQUALS, _28965, 10LL);
    }
    _28965 = NOVALUE;
    if (_28966 <= 0) {
        if (_28966 == 0) {
            DeRef(_28966);
            _28966 = NOVALUE;
            goto L3; // [42] 71
        }
        else {
            if (!IS_ATOM_INT(_28966) && DBL_PTR(_28966)->dbl == 0.0){
                DeRef(_28966);
                _28966 = NOVALUE;
                goto L3; // [42] 71
            }
            DeRef(_28966);
            _28966 = NOVALUE;
        }
    }
    DeRef(_28966);
    _28966 = NOVALUE;
L2: 

    /** parser.e:1400			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57526);
    _id_57527 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_57527)){
        _id_57527 = (object)DBL_PTR(_id_57527)->dbl;
    }

    /** parser.e:1401			tok = Term()*/
    _0 = _tok_57526;
    _tok_57526 = _43Term();
    DeRef(_0);

    /** parser.e:1402			emit_op(id)*/
    _45emit_op(_id_57527);

    /** parser.e:1403		end while*/
    goto L1; // [68] 13
L3: 

    /** parser.e:1404		return tok*/
    DeRef(_28963);
    _28963 = NOVALUE;
    return _tok_57526;
    ;
}


object _43cexpr()
{
    object _tok_57546 = NOVALUE;
    object _concat_count_57547 = NOVALUE;
    object _28970 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1410		integer concat_count*/

    /** parser.e:1412		tok = aexpr()*/
    _0 = _tok_57546;
    _tok_57546 = _43aexpr();
    DeRef(_0);

    /** parser.e:1413		concat_count = 0*/
    _concat_count_57547 = 0LL;

    /** parser.e:1414		while tok[T_ID] = reserved:CONCAT do*/
L1: 
    _2 = (object)SEQ_PTR(_tok_57546);
    _28970 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28970, 15LL)){
        _28970 = NOVALUE;
        goto L2; // [24] 44
    }
    _28970 = NOVALUE;

    /** parser.e:1415			tok = aexpr()*/
    _0 = _tok_57546;
    _tok_57546 = _43aexpr();
    DeRef(_0);

    /** parser.e:1416			concat_count += 1*/
    _concat_count_57547 = _concat_count_57547 + 1;

    /** parser.e:1417		end while*/
    goto L1; // [41] 18
L2: 

    /** parser.e:1419		if concat_count = 1 then*/
    if (_concat_count_57547 != 1LL)
    goto L3; // [46] 58

    /** parser.e:1420			emit_op( reserved:CONCAT )*/
    _45emit_op(15LL);
    goto L4; // [55] 81
L3: 

    /** parser.e:1422		elsif concat_count > 1 then*/
    if (_concat_count_57547 <= 1LL)
    goto L5; // [60] 80

    /** parser.e:1423			op_info1 = concat_count+1*/
    _45op_info1_51473 = _concat_count_57547 + 1;

    /** parser.e:1424			emit_op(CONCAT_N)*/
    _45emit_op(157LL);
L5: 
L4: 

    /** parser.e:1427		return tok*/
    return _tok_57546;
    ;
}


object _43rexpr()
{
    object _tok_57567 = NOVALUE;
    object _id_57568 = NOVALUE;
    object _28982 = NOVALUE;
    object _28981 = NOVALUE;
    object _28980 = NOVALUE;
    object _28979 = NOVALUE;
    object _28978 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1433		integer id*/

    /** parser.e:1435		tok = cexpr()*/
    _0 = _tok_57567;
    _tok_57567 = _43cexpr();
    DeRef(_0);

    /** parser.e:1436		while tok[T_ID] <= GREATER and tok[T_ID] >= LESS do*/
L1: 
    _2 = (object)SEQ_PTR(_tok_57567);
    _28978 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28978)) {
        _28979 = (_28978 <= 6LL);
    }
    else {
        _28979 = binary_op(LESSEQ, _28978, 6LL);
    }
    _28978 = NOVALUE;
    if (IS_ATOM_INT(_28979)) {
        if (_28979 == 0) {
            goto L2; // [25] 70
        }
    }
    else {
        if (DBL_PTR(_28979)->dbl == 0.0) {
            goto L2; // [25] 70
        }
    }
    _2 = (object)SEQ_PTR(_tok_57567);
    _28981 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28981)) {
        _28982 = (_28981 >= 1LL);
    }
    else {
        _28982 = binary_op(GREATEREQ, _28981, 1LL);
    }
    _28981 = NOVALUE;
    if (_28982 <= 0) {
        if (_28982 == 0) {
            DeRef(_28982);
            _28982 = NOVALUE;
            goto L2; // [42] 70
        }
        else {
            if (!IS_ATOM_INT(_28982) && DBL_PTR(_28982)->dbl == 0.0){
                DeRef(_28982);
                _28982 = NOVALUE;
                goto L2; // [42] 70
            }
            DeRef(_28982);
            _28982 = NOVALUE;
        }
    }
    DeRef(_28982);
    _28982 = NOVALUE;

    /** parser.e:1437			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57567);
    _id_57568 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_57568)){
        _id_57568 = (object)DBL_PTR(_id_57568)->dbl;
    }

    /** parser.e:1438			tok = cexpr()*/
    _0 = _tok_57567;
    _tok_57567 = _43cexpr();
    DeRef(_0);

    /** parser.e:1439			emit_op(id)*/
    _45emit_op(_id_57568);

    /** parser.e:1440		end while*/
    goto L1; // [67] 13
L2: 

    /** parser.e:1441		return tok*/
    DeRef(_28979);
    _28979 = NOVALUE;
    return _tok_57567;
    ;
}


void _43Expr()
{
    object _tok_57594 = NOVALUE;
    object _id_57595 = NOVALUE;
    object _patch_57596 = NOVALUE;
    object _29005 = NOVALUE;
    object _29003 = NOVALUE;
    object _29002 = NOVALUE;
    object _29000 = NOVALUE;
    object _28999 = NOVALUE;
    object _28998 = NOVALUE;
    object _28997 = NOVALUE;
    object _28996 = NOVALUE;
    object _28990 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1451		integer id*/

    /** parser.e:1452		integer patch*/

    /** parser.e:1454		ExprLine = ThisLine*/
    Ref(_49ThisLine_49693);
    DeRef(_43ExprLine_57589);
    _43ExprLine_57589 = _49ThisLine_49693;

    /** parser.e:1455		expr_bp = bp*/
    _43expr_bp_57590 = _49bp_49697;

    /** parser.e:1456		id = -1*/
    _id_57595 = -1LL;

    /** parser.e:1457		patch = 0*/
    _patch_57596 = 0LL;

    /** parser.e:1458		while TRUE do*/
L1: 
    if (_9TRUE_441 == 0)
    {
        goto L2; // [40] 300
    }
    else{
    }

    /** parser.e:1459			if id != -1 then*/
    if (_id_57595 == -1LL)
    goto L3; // [45] 116

    /** parser.e:1460				if id != XOR then*/
    if (_id_57595 == 152LL)
    goto L4; // [53] 115

    /** parser.e:1461					if short_circuit > 0 then*/
    if (_43short_circuit_55468 <= 0LL)
    goto L5; // [61] 114

    /** parser.e:1462						if id = OR then*/
    if (_id_57595 != 9LL)
    goto L6; // [69] 83

    /** parser.e:1463							emit_op(SC1_OR)*/
    _45emit_op(143LL);
    goto L7; // [80] 91
L6: 

    /** parser.e:1465							emit_op(SC1_AND)*/
    _45emit_op(141LL);
L7: 

    /** parser.e:1467						patch = length(Code)+1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _28990 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _28990 = 1;
    }
    _patch_57596 = _28990 + 1;
    _28990 = NOVALUE;

    /** parser.e:1468						emit_forward_addr()*/
    _43emit_forward_addr();

    /** parser.e:1469						short_circuit_B = TRUE*/
    _43short_circuit_B_55470 = _9TRUE_441;
L5: 
L4: 
L3: 

    /** parser.e:1474			tok = rexpr()*/
    _0 = _tok_57594;
    _tok_57594 = _43rexpr();
    DeRef(_0);

    /** parser.e:1476			if id != -1 then*/
    if (_id_57595 == -1LL)
    goto L8; // [123] 268

    /** parser.e:1477				if id != XOR then*/
    if (_id_57595 == 152LL)
    goto L9; // [131] 261

    /** parser.e:1478					if short_circuit > 0 then*/
    if (_43short_circuit_55468 <= 0LL)
    goto LA; // [139] 252

    /** parser.e:1479						if tok[T_ID] != THEN and tok[T_ID] != DO then*/
    _2 = (object)SEQ_PTR(_tok_57594);
    _28996 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28996)) {
        _28997 = (_28996 != 410LL);
    }
    else {
        _28997 = binary_op(NOTEQ, _28996, 410LL);
    }
    _28996 = NOVALUE;
    if (IS_ATOM_INT(_28997)) {
        if (_28997 == 0) {
            goto LB; // [157] 206
        }
    }
    else {
        if (DBL_PTR(_28997)->dbl == 0.0) {
            goto LB; // [157] 206
        }
    }
    _2 = (object)SEQ_PTR(_tok_57594);
    _28999 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28999)) {
        _29000 = (_28999 != 411LL);
    }
    else {
        _29000 = binary_op(NOTEQ, _28999, 411LL);
    }
    _28999 = NOVALUE;
    if (_29000 == 0) {
        DeRef(_29000);
        _29000 = NOVALUE;
        goto LB; // [174] 206
    }
    else {
        if (!IS_ATOM_INT(_29000) && DBL_PTR(_29000)->dbl == 0.0){
            DeRef(_29000);
            _29000 = NOVALUE;
            goto LB; // [174] 206
        }
        DeRef(_29000);
        _29000 = NOVALUE;
    }
    DeRef(_29000);
    _29000 = NOVALUE;

    /** parser.e:1480							if id = OR then*/
    if (_id_57595 != 9LL)
    goto LC; // [181] 195

    /** parser.e:1481								emit_op(SC2_OR)*/
    _45emit_op(144LL);
    goto LD; // [192] 219
LC: 

    /** parser.e:1483								emit_op(SC2_AND)*/
    _45emit_op(142LL);
    goto LD; // [203] 219
LB: 

    /** parser.e:1486							SC1_type = id -- if/while/elsif must patch*/
    _43SC1_type_55473 = _id_57595;

    /** parser.e:1487							emit_op(SC2_NULL)*/
    _45emit_op(145LL);
LD: 

    /** parser.e:1489						if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto LE; // [223] 234
    }
    else{
    }

    /** parser.e:1490							emit_op(NOP1)   -- to get label here*/
    _45emit_op(159LL);
LE: 

    /** parser.e:1492						backpatch(patch, length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29002 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29002 = 1;
    }
    _29003 = _29002 + 1;
    _29002 = NOVALUE;
    _45backpatch(_patch_57596, _29003);
    _29003 = NOVALUE;
    goto LF; // [249] 267
LA: 

    /** parser.e:1494						emit_op(id)*/
    _45emit_op(_id_57595);
    goto LF; // [258] 267
L9: 

    /** parser.e:1497					emit_op(id)*/
    _45emit_op(_id_57595);
LF: 
L8: 

    /** parser.e:1500			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57594);
    _id_57595 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_57595)){
        _id_57595 = (object)DBL_PTR(_id_57595)->dbl;
    }

    /** parser.e:1501			if not find(id, boolOps) then*/
    _29005 = find_from(_id_57595, _43boolOps_57584, 1LL);
    if (_29005 != 0)
    goto L1; // [287] 38
    _29005 = NOVALUE;

    /** parser.e:1502				exit*/
    goto L2; // [292] 300

    /** parser.e:1504		end while*/
    goto L1; // [297] 38
L2: 

    /** parser.e:1505		putback(tok)*/
    Ref(_tok_57594);
    _43putback(_tok_57594);

    /** parser.e:1506		SC1_patch = patch -- extra line*/
    _43SC1_patch_55472 = _patch_57596;

    /** parser.e:1507	end procedure*/
    DeRef(_tok_57594);
    DeRef(_28997);
    _28997 = NOVALUE;
    return;
    ;
}


void _43TypeCheck(object _var_57671)
{
    object _which_type_57672 = NOVALUE;
    object _ref_57682 = NOVALUE;
    object _ref_57715 = NOVALUE;
    object _29061 = NOVALUE;
    object _29060 = NOVALUE;
    object _29059 = NOVALUE;
    object _29058 = NOVALUE;
    object _29057 = NOVALUE;
    object _29055 = NOVALUE;
    object _29054 = NOVALUE;
    object _29053 = NOVALUE;
    object _29052 = NOVALUE;
    object _29051 = NOVALUE;
    object _29050 = NOVALUE;
    object _29048 = NOVALUE;
    object _29047 = NOVALUE;
    object _29044 = NOVALUE;
    object _29043 = NOVALUE;
    object _29042 = NOVALUE;
    object _29041 = NOVALUE;
    object _29036 = NOVALUE;
    object _29035 = NOVALUE;
    object _29031 = NOVALUE;
    object _29029 = NOVALUE;
    object _29028 = NOVALUE;
    object _29027 = NOVALUE;
    object _29025 = NOVALUE;
    object _29024 = NOVALUE;
    object _29023 = NOVALUE;
    object _29022 = NOVALUE;
    object _29021 = NOVALUE;
    object _29020 = NOVALUE;
    object _29017 = NOVALUE;
    object _29015 = NOVALUE;
    object _29013 = NOVALUE;
    object _29012 = NOVALUE;
    object _29011 = NOVALUE;
    object _29009 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_var_57671)) {
        _1 = (object)(DBL_PTR(_var_57671)->dbl);
        DeRefDS(_var_57671);
        _var_57671 = _1;
    }

    /** parser.e:1515		if var < 0 or SymTab[var][S_SCOPE] = SC_UNDEFINED then*/
    _29009 = (_var_57671 < 0LL);
    if (_29009 != 0) {
        goto L1; // [9] 36
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29011 = (object)*(((s1_ptr)_2)->base + _var_57671);
    _2 = (object)SEQ_PTR(_29011);
    _29012 = (object)*(((s1_ptr)_2)->base + 4LL);
    _29011 = NOVALUE;
    if (IS_ATOM_INT(_29012)) {
        _29013 = (_29012 == 9LL);
    }
    else {
        _29013 = binary_op(EQUALS, _29012, 9LL);
    }
    _29012 = NOVALUE;
    if (_29013 == 0) {
        DeRef(_29013);
        _29013 = NOVALUE;
        goto L2; // [32] 76
    }
    else {
        if (!IS_ATOM_INT(_29013) && DBL_PTR(_29013)->dbl == 0.0){
            DeRef(_29013);
            _29013 = NOVALUE;
            goto L2; // [32] 76
        }
        DeRef(_29013);
        _29013 = NOVALUE;
    }
    DeRef(_29013);
    _29013 = NOVALUE;
L1: 

    /** parser.e:1517			integer ref = new_forward_reference( TYPE_CHECK, var, TYPE_CHECK_FORWARD )*/
    _ref_57682 = _42new_forward_reference(65LL, _var_57671, 197LL);
    if (!IS_ATOM_INT(_ref_57682)) {
        _1 = (object)(DBL_PTR(_ref_57682)->dbl);
        DeRefDS(_ref_57682);
        _ref_57682 = _1;
    }

    /** parser.e:1518			Code &= { TYPE_CHECK_FORWARD, var, OpTypeCheck }*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 197LL;
    ((intptr_t*)_2)[2] = _var_57671;
    ((intptr_t*)_2)[3] = _27OpTypeCheck_20642;
    _29015 = MAKE_SEQ(_1);
    Concat((object_ptr)&_27Code_20660, _27Code_20660, _29015);
    DeRefDS(_29015);
    _29015 = NOVALUE;

    /** parser.e:1519			return*/
    DeRef(_29009);
    _29009 = NOVALUE;
    return;
L2: 

    /** parser.e:1522		which_type = SymTab[var][S_VTYPE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29017 = (object)*(((s1_ptr)_2)->base + _var_57671);
    _2 = (object)SEQ_PTR(_29017);
    _which_type_57672 = (object)*(((s1_ptr)_2)->base + 15LL);
    if (!IS_ATOM_INT(_which_type_57672)){
        _which_type_57672 = (object)DBL_PTR(_which_type_57672)->dbl;
    }
    _29017 = NOVALUE;

    /** parser.e:1523		if which_type = 0 then*/
    if (_which_type_57672 != 0LL)
    goto L3; // [96] 106

    /** parser.e:1524			return	-- Not a typed identifier.*/
    DeRef(_29009);
    _29009 = NOVALUE;
    return;
L3: 

    /** parser.e:1526		if which_type > 0 and length(SymTab[which_type]) < S_TOKEN then*/
    _29020 = (_which_type_57672 > 0LL);
    if (_29020 == 0) {
        goto L4; // [112] 141
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29022 = (object)*(((s1_ptr)_2)->base + _which_type_57672);
    if (IS_SEQUENCE(_29022)){
            _29023 = SEQ_PTR(_29022)->length;
    }
    else {
        _29023 = 1;
    }
    _29022 = NOVALUE;
    if (IS_ATOM_INT(_27S_TOKEN_20214)) {
        _29024 = (_29023 < _27S_TOKEN_20214);
    }
    else {
        _29024 = binary_op(LESS, _29023, _27S_TOKEN_20214);
    }
    _29023 = NOVALUE;
    if (_29024 == 0) {
        DeRef(_29024);
        _29024 = NOVALUE;
        goto L4; // [132] 141
    }
    else {
        if (!IS_ATOM_INT(_29024) && DBL_PTR(_29024)->dbl == 0.0){
            DeRef(_29024);
            _29024 = NOVALUE;
            goto L4; // [132] 141
        }
        DeRef(_29024);
        _29024 = NOVALUE;
    }
    DeRef(_29024);
    _29024 = NOVALUE;

    /** parser.e:1527			return	-- Not a typed identifier.*/
    _29022 = NOVALUE;
    DeRef(_29009);
    _29009 = NOVALUE;
    DeRef(_29020);
    _29020 = NOVALUE;
    return;
L4: 

    /** parser.e:1530		if which_type < 0 or SymTab[which_type][S_TOKEN] = VARIABLE  then*/
    _29025 = (_which_type_57672 < 0LL);
    if (_29025 != 0) {
        goto L5; // [147] 174
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29027 = (object)*(((s1_ptr)_2)->base + _which_type_57672);
    _2 = (object)SEQ_PTR(_29027);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _29028 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _29028 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _29027 = NOVALUE;
    if (IS_ATOM_INT(_29028)) {
        _29029 = (_29028 == -100LL);
    }
    else {
        _29029 = binary_op(EQUALS, _29028, -100LL);
    }
    _29028 = NOVALUE;
    if (_29029 == 0) {
        DeRef(_29029);
        _29029 = NOVALUE;
        goto L6; // [170] 214
    }
    else {
        if (!IS_ATOM_INT(_29029) && DBL_PTR(_29029)->dbl == 0.0){
            DeRef(_29029);
            _29029 = NOVALUE;
            goto L6; // [170] 214
        }
        DeRef(_29029);
        _29029 = NOVALUE;
    }
    DeRef(_29029);
    _29029 = NOVALUE;
L5: 

    /** parser.e:1531			integer ref = new_forward_reference( TYPE_CHECK, which_type, TYPE )*/
    _ref_57715 = _42new_forward_reference(65LL, _which_type_57672, 504LL);
    if (!IS_ATOM_INT(_ref_57715)) {
        _1 = (object)(DBL_PTR(_ref_57715)->dbl);
        DeRefDS(_ref_57715);
        _ref_57715 = _1;
    }

    /** parser.e:1532			Code &= { TYPE_CHECK_FORWARD, var, OpTypeCheck }*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 197LL;
    ((intptr_t*)_2)[2] = _var_57671;
    ((intptr_t*)_2)[3] = _27OpTypeCheck_20642;
    _29031 = MAKE_SEQ(_1);
    Concat((object_ptr)&_27Code_20660, _27Code_20660, _29031);
    DeRefDS(_29031);
    _29031 = NOVALUE;

    /** parser.e:1534			return*/
    _29022 = NOVALUE;
    DeRef(_29009);
    _29009 = NOVALUE;
    DeRef(_29020);
    _29020 = NOVALUE;
    DeRef(_29025);
    _29025 = NOVALUE;
    return;
L6: 

    /** parser.e:1537		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L7; // [220] 317
    }
    else{
    }

    /** parser.e:1538			if OpTypeCheck then*/
    if (_27OpTypeCheck_20642 == 0)
    {
        goto L8; // [227] 481
    }
    else{
    }

    /** parser.e:1539				switch which_type do*/
    if( _43_57729_cases == 0 ){
        _43_57729_cases = 1;
        SEQ_PTR( _29033 )->base[1] = _53object_type_47227;
        SEQ_PTR( _29033 )->base[2] = _53sequence_type_47231;
        SEQ_PTR( _29033 )->base[3] = _53atom_type_47229;
        SEQ_PTR( _29033 )->base[4] = _53integer_type_47233;
    }
    _1 = find(_which_type_57672, _29033);
    switch ( _1 ){ 

        /** parser.e:1540					case object_type, sequence_type, atom_type then*/
        case 1:
        case 2:
        case 3:

        /** parser.e:1542					case integer_type then*/
        goto L8; // [247] 481
        case 4:

        /** parser.e:1544						op_info1 = var*/
        _45op_info1_51473 = _var_57671;

        /** parser.e:1545						emit_op(INTEGER_CHECK)*/
        _45emit_op(96LL);
        goto L8; // [265] 481

        /** parser.e:1546					case else*/
        case 0:

        /** parser.e:1547						if SymTab[which_type][S_EFFECT] then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _29035 = (object)*(((s1_ptr)_2)->base + _which_type_57672);
        _2 = (object)SEQ_PTR(_29035);
        _29036 = (object)*(((s1_ptr)_2)->base + 23LL);
        _29035 = NOVALUE;
        if (_29036 == 0) {
            _29036 = NOVALUE;
            goto L9; // [285] 312
        }
        else {
            if (!IS_ATOM_INT(_29036) && DBL_PTR(_29036)->dbl == 0.0){
                _29036 = NOVALUE;
                goto L9; // [285] 312
            }
            _29036 = NOVALUE;
        }
        _29036 = NOVALUE;

        /** parser.e:1549							emit_opnd(var)*/
        _45emit_opnd(_var_57671);

        /** parser.e:1550							op_info1 = which_type*/
        _45op_info1_51473 = _which_type_57672;

        /** parser.e:1552							emit_or_inline()*/
        _66emit_or_inline();

        /** parser.e:1553							emit_op(TYPE_CHECK)*/
        _45emit_op(65LL);
L9: 
    ;}    goto L8; // [314] 481
L7: 

    /** parser.e:1559			if OpTypeCheck then*/
    if (_27OpTypeCheck_20642 == 0)
    {
        goto LA; // [321] 480
    }
    else{
    }

    /** parser.e:1560				if which_type != object_type then*/
    if (_which_type_57672 == _53object_type_47227)
    goto LB; // [328] 479

    /** parser.e:1561					if which_type = integer_type then*/
    if (_which_type_57672 != _53integer_type_47233)
    goto LC; // [336] 357

    /** parser.e:1562							op_info1 = var*/
    _45op_info1_51473 = _var_57671;

    /** parser.e:1563							emit_op(INTEGER_CHECK)*/
    _45emit_op(96LL);
    goto LD; // [354] 478
LC: 

    /** parser.e:1565					elsif which_type = sequence_type then*/
    if (_which_type_57672 != _53sequence_type_47231)
    goto LE; // [361] 382

    /** parser.e:1566							op_info1 = var*/
    _45op_info1_51473 = _var_57671;

    /** parser.e:1567							emit_op(SEQUENCE_CHECK)*/
    _45emit_op(97LL);
    goto LD; // [379] 478
LE: 

    /** parser.e:1569					elsif which_type = atom_type then*/
    if (_which_type_57672 != _53atom_type_47229)
    goto LF; // [386] 407

    /** parser.e:1570							op_info1 = var*/
    _45op_info1_51473 = _var_57671;

    /** parser.e:1571							emit_op(ATOM_CHECK)*/
    _45emit_op(101LL);
    goto LD; // [404] 478
LF: 

    /** parser.e:1575							if SymTab[SymTab[which_type][S_NEXT]][S_VTYPE] =*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29041 = (object)*(((s1_ptr)_2)->base + _which_type_57672);
    _2 = (object)SEQ_PTR(_29041);
    _29042 = (object)*(((s1_ptr)_2)->base + 2LL);
    _29041 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_29042)){
        _29043 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29042)->dbl));
    }
    else{
        _29043 = (object)*(((s1_ptr)_2)->base + _29042);
    }
    _2 = (object)SEQ_PTR(_29043);
    _29044 = (object)*(((s1_ptr)_2)->base + 15LL);
    _29043 = NOVALUE;
    if (binary_op_a(NOTEQ, _29044, _53integer_type_47233)){
        _29044 = NOVALUE;
        goto L10; // [435] 454
    }
    _29044 = NOVALUE;

    /** parser.e:1577								op_info1 = var*/
    _45op_info1_51473 = _var_57671;

    /** parser.e:1578								emit_op(INTEGER_CHECK) -- need integer conversion*/
    _45emit_op(96LL);
L10: 

    /** parser.e:1580							emit_opnd(var)*/
    _45emit_opnd(_var_57671);

    /** parser.e:1581							op_info1 = which_type*/
    _45op_info1_51473 = _which_type_57672;

    /** parser.e:1582							emit_or_inline()*/
    _66emit_or_inline();

    /** parser.e:1584							emit_op(TYPE_CHECK)*/
    _45emit_op(65LL);
LD: 
LB: 
LA: 
L8: 

    /** parser.e:1590		if TRANSLATE or not OpTypeCheck then*/
    if (_27TRANSLATE_20179 != 0) {
        goto L11; // [485] 499
    }
    _29047 = (_27OpTypeCheck_20642 == 0);
    if (_29047 == 0)
    {
        DeRef(_29047);
        _29047 = NOVALUE;
        goto L12; // [495] 620
    }
    else{
        DeRef(_29047);
        _29047 = NOVALUE;
    }
L11: 

    /** parser.e:1591			op_info1 = var*/
    _45op_info1_51473 = _var_57671;

    /** parser.e:1592			if which_type = sequence_type or*/
    _29048 = (_which_type_57672 == _53sequence_type_47231);
    if (_29048 != 0) {
        goto L13; // [514] 553
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29050 = (object)*(((s1_ptr)_2)->base + _which_type_57672);
    _2 = (object)SEQ_PTR(_29050);
    _29051 = (object)*(((s1_ptr)_2)->base + 2LL);
    _29050 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_29051)){
        _29052 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29051)->dbl));
    }
    else{
        _29052 = (object)*(((s1_ptr)_2)->base + _29051);
    }
    _2 = (object)SEQ_PTR(_29052);
    _29053 = (object)*(((s1_ptr)_2)->base + 15LL);
    _29052 = NOVALUE;
    if (IS_ATOM_INT(_29053)) {
        _29054 = (_29053 == _53sequence_type_47231);
    }
    else {
        _29054 = binary_op(EQUALS, _29053, _53sequence_type_47231);
    }
    _29053 = NOVALUE;
    if (_29054 == 0) {
        DeRef(_29054);
        _29054 = NOVALUE;
        goto L14; // [549] 563
    }
    else {
        if (!IS_ATOM_INT(_29054) && DBL_PTR(_29054)->dbl == 0.0){
            DeRef(_29054);
            _29054 = NOVALUE;
            goto L14; // [549] 563
        }
        DeRef(_29054);
        _29054 = NOVALUE;
    }
    DeRef(_29054);
    _29054 = NOVALUE;
L13: 

    /** parser.e:1595				emit_op(SEQUENCE_CHECK)*/
    _45emit_op(97LL);
    goto L15; // [560] 619
L14: 

    /** parser.e:1597			elsif which_type = integer_type or*/
    _29055 = (_which_type_57672 == _53integer_type_47233);
    if (_29055 != 0) {
        goto L16; // [571] 610
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29057 = (object)*(((s1_ptr)_2)->base + _which_type_57672);
    _2 = (object)SEQ_PTR(_29057);
    _29058 = (object)*(((s1_ptr)_2)->base + 2LL);
    _29057 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_29058)){
        _29059 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29058)->dbl));
    }
    else{
        _29059 = (object)*(((s1_ptr)_2)->base + _29058);
    }
    _2 = (object)SEQ_PTR(_29059);
    _29060 = (object)*(((s1_ptr)_2)->base + 15LL);
    _29059 = NOVALUE;
    if (IS_ATOM_INT(_29060)) {
        _29061 = (_29060 == _53integer_type_47233);
    }
    else {
        _29061 = binary_op(EQUALS, _29060, _53integer_type_47233);
    }
    _29060 = NOVALUE;
    if (_29061 == 0) {
        DeRef(_29061);
        _29061 = NOVALUE;
        goto L17; // [606] 618
    }
    else {
        if (!IS_ATOM_INT(_29061) && DBL_PTR(_29061)->dbl == 0.0){
            DeRef(_29061);
            _29061 = NOVALUE;
            goto L17; // [606] 618
        }
        DeRef(_29061);
        _29061 = NOVALUE;
    }
    DeRef(_29061);
    _29061 = NOVALUE;
L16: 

    /** parser.e:1600				emit_op(INTEGER_CHECK)*/
    _45emit_op(96LL);
L17: 
L15: 
L12: 

    /** parser.e:1603	end procedure*/
    _29022 = NOVALUE;
    DeRef(_29009);
    _29009 = NOVALUE;
    _29051 = NOVALUE;
    DeRef(_29020);
    _29020 = NOVALUE;
    DeRef(_29048);
    _29048 = NOVALUE;
    _29042 = NOVALUE;
    DeRef(_29025);
    _29025 = NOVALUE;
    _29058 = NOVALUE;
    DeRef(_29055);
    _29055 = NOVALUE;
    return;
    ;
}


void _43Assignment(object _left_var_57836)
{
    object _tok_57838 = NOVALUE;
    object _subs_57839 = NOVALUE;
    object _slice_57840 = NOVALUE;
    object _assign_op_57841 = NOVALUE;
    object _subs1_patch_57842 = NOVALUE;
    object _dangerous_57844 = NOVALUE;
    object _lname_57969 = NOVALUE;
    object _temp_len_57988 = NOVALUE;
    object _29158 = NOVALUE;
    object _29157 = NOVALUE;
    object _29156 = NOVALUE;
    object _29155 = NOVALUE;
    object _29154 = NOVALUE;
    object _29153 = NOVALUE;
    object _29152 = NOVALUE;
    object _29143 = NOVALUE;
    object _29142 = NOVALUE;
    object _29141 = NOVALUE;
    object _29140 = NOVALUE;
    object _29139 = NOVALUE;
    object _29138 = NOVALUE;
    object _29137 = NOVALUE;
    object _29136 = NOVALUE;
    object _29135 = NOVALUE;
    object _29134 = NOVALUE;
    object _29133 = NOVALUE;
    object _29132 = NOVALUE;
    object _29131 = NOVALUE;
    object _29130 = NOVALUE;
    object _29129 = NOVALUE;
    object _29127 = NOVALUE;
    object _29126 = NOVALUE;
    object _29125 = NOVALUE;
    object _29123 = NOVALUE;
    object _29118 = NOVALUE;
    object _29117 = NOVALUE;
    object _29114 = NOVALUE;
    object _29113 = NOVALUE;
    object _29111 = NOVALUE;
    object _29105 = NOVALUE;
    object _29100 = NOVALUE;
    object _29097 = NOVALUE;
    object _29094 = NOVALUE;
    object _29091 = NOVALUE;
    object _29090 = NOVALUE;
    object _29089 = NOVALUE;
    object _29087 = NOVALUE;
    object _29086 = NOVALUE;
    object _29085 = NOVALUE;
    object _29084 = NOVALUE;
    object _29083 = NOVALUE;
    object _29082 = NOVALUE;
    object _29080 = NOVALUE;
    object _29079 = NOVALUE;
    object _29078 = NOVALUE;
    object _29077 = NOVALUE;
    object _29075 = NOVALUE;
    object _29074 = NOVALUE;
    object _29073 = NOVALUE;
    object _29072 = NOVALUE;
    object _29071 = NOVALUE;
    object _29069 = NOVALUE;
    object _29068 = NOVALUE;
    object _29067 = NOVALUE;
    object _29064 = NOVALUE;
    object _29063 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:1608		integer subs, slice, assign_op, subs1_patch*/

    /** parser.e:1611		left_sym = left_var[T_SYM]*/
    _2 = (object)SEQ_PTR(_left_var_57836);
    _43left_sym_55509 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_43left_sym_55509)){
        _43left_sym_55509 = (object)DBL_PTR(_43left_sym_55509)->dbl;
    }

    /** parser.e:1612		if SymTab[left_sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29063 = (object)*(((s1_ptr)_2)->base + _43left_sym_55509);
    _2 = (object)SEQ_PTR(_29063);
    _29064 = (object)*(((s1_ptr)_2)->base + 4LL);
    _29063 = NOVALUE;
    if (binary_op_a(NOTEQ, _29064, 9LL)){
        _29064 = NOVALUE;
        goto L1; // [31] 54
    }
    _29064 = NOVALUE;

    /** parser.e:1613			Forward_var( left_var, ,ASSIGN )*/
    Ref(_left_var_57836);
    _43Forward_var(_left_var_57836, -1LL, 18LL);

    /** parser.e:1614			left_sym = Pop() -- pops off what forward var emitted, because it gets emitted later*/
    _0 = _45Pop();
    _43left_sym_55509 = _0;
    if (!IS_ATOM_INT(_43left_sym_55509)) {
        _1 = (object)(DBL_PTR(_43left_sym_55509)->dbl);
        DeRefDS(_43left_sym_55509);
        _43left_sym_55509 = _1;
    }
    goto L2; // [51] 271
L1: 

    /** parser.e:1616			UndefinedVar(left_sym)*/
    _43UndefinedVar(_43left_sym_55509);

    /** parser.e:1617			if SymTab[left_sym][S_SCOPE] = SC_LOOP_VAR or*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29067 = (object)*(((s1_ptr)_2)->base + _43left_sym_55509);
    _2 = (object)SEQ_PTR(_29067);
    _29068 = (object)*(((s1_ptr)_2)->base + 4LL);
    _29067 = NOVALUE;
    if (IS_ATOM_INT(_29068)) {
        _29069 = (_29068 == 2LL);
    }
    else {
        _29069 = binary_op(EQUALS, _29068, 2LL);
    }
    _29068 = NOVALUE;
    if (IS_ATOM_INT(_29069)) {
        if (_29069 != 0) {
            goto L3; // [83] 112
        }
    }
    else {
        if (DBL_PTR(_29069)->dbl != 0.0) {
            goto L3; // [83] 112
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29071 = (object)*(((s1_ptr)_2)->base + _43left_sym_55509);
    _2 = (object)SEQ_PTR(_29071);
    _29072 = (object)*(((s1_ptr)_2)->base + 4LL);
    _29071 = NOVALUE;
    if (IS_ATOM_INT(_29072)) {
        _29073 = (_29072 == 4LL);
    }
    else {
        _29073 = binary_op(EQUALS, _29072, 4LL);
    }
    _29072 = NOVALUE;
    if (_29073 == 0) {
        DeRef(_29073);
        _29073 = NOVALUE;
        goto L4; // [108] 124
    }
    else {
        if (!IS_ATOM_INT(_29073) && DBL_PTR(_29073)->dbl == 0.0){
            DeRef(_29073);
            _29073 = NOVALUE;
            goto L4; // [108] 124
        }
        DeRef(_29073);
        _29073 = NOVALUE;
    }
    DeRef(_29073);
    _29073 = NOVALUE;
L3: 

    /** parser.e:1619				CompileErr(MAY_NOT_ASSIGN_TO_A_FORLOOP_VARIABLE)*/
    RefDS(_22218);
    _49CompileErr(109LL, _22218, 0LL);
    goto L5; // [121] 233
L4: 

    /** parser.e:1621			elsif SymTab[left_sym][S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29074 = (object)*(((s1_ptr)_2)->base + _43left_sym_55509);
    _2 = (object)SEQ_PTR(_29074);
    _29075 = (object)*(((s1_ptr)_2)->base + 3LL);
    _29074 = NOVALUE;
    if (binary_op_a(NOTEQ, _29075, 2LL)){
        _29075 = NOVALUE;
        goto L6; // [142] 158
    }
    _29075 = NOVALUE;

    /** parser.e:1622				CompileErr(MAY_NOT_CHANGE_THE_VALUE_OF_A_CONSTANT)*/
    RefDS(_22218);
    _49CompileErr(110LL, _22218, 0LL);
    goto L5; // [155] 233
L6: 

    /** parser.e:1624			elsif find(SymTab[left_sym][S_SCOPE], SCOPE_TYPES) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29077 = (object)*(((s1_ptr)_2)->base + _43left_sym_55509);
    _2 = (object)SEQ_PTR(_29077);
    _29078 = (object)*(((s1_ptr)_2)->base + 4LL);
    _29077 = NOVALUE;
    _29079 = find_from(_29078, _43SCOPE_TYPES_55459, 1LL);
    _29078 = NOVALUE;
    if (_29079 == 0)
    {
        _29079 = NOVALUE;
        goto L7; // [181] 232
    }
    else{
        _29079 = NOVALUE;
    }

    /** parser.e:1626				SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT],*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27CurrentSub_20579 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29082 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_29082);
    _29083 = (object)*(((s1_ptr)_2)->base + 23LL);
    _29082 = NOVALUE;
    _29084 = (_43left_sym_55509 % 29LL);
    _29085 = power(2LL, _29084);
    _29084 = NOVALUE;
    if (IS_ATOM_INT(_29083) && IS_ATOM_INT(_29085)) {
        {uintptr_t tu;
             tu = (uintptr_t)_29083 | (uintptr_t)_29085;
             _29086 = MAKE_UINT(tu);
        }
    }
    else {
        _29086 = binary_op(OR_BITS, _29083, _29085);
    }
    _29083 = NOVALUE;
    DeRef(_29085);
    _29085 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29086;
    if( _1 != _29086 ){
        DeRef(_1);
    }
    _29086 = NOVALUE;
    _29080 = NOVALUE;
L7: 
L5: 

    /** parser.e:1630			SymTab[left_sym][S_USAGE] = or_bits(SymTab[left_sym][S_USAGE], U_WRITTEN)*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_43left_sym_55509 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29089 = (object)*(((s1_ptr)_2)->base + _43left_sym_55509);
    _2 = (object)SEQ_PTR(_29089);
    _29090 = (object)*(((s1_ptr)_2)->base + 5LL);
    _29089 = NOVALUE;
    if (IS_ATOM_INT(_29090)) {
        {uintptr_t tu;
             tu = (uintptr_t)_29090 | (uintptr_t)2LL;
             _29091 = MAKE_UINT(tu);
        }
    }
    else {
        _29091 = binary_op(OR_BITS, _29090, 2LL);
    }
    _29090 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29091;
    if( _1 != _29091 ){
        DeRef(_1);
    }
    _29091 = NOVALUE;
    _29087 = NOVALUE;
L2: 

    /** parser.e:1635		tok = next_token()*/
    _0 = _tok_57838;
    _tok_57838 = _43next_token();
    DeRef(_0);

    /** parser.e:1636		subs = 0*/
    _subs_57839 = 0LL;

    /** parser.e:1637		slice = FALSE*/
    _slice_57840 = _9FALSE_439;

    /** parser.e:1639		dangerous = FALSE*/
    _dangerous_57844 = _9FALSE_439;

    /** parser.e:1640		side_effect_calls = 0*/
    _43side_effect_calls_55505 = 0LL;

    /** parser.e:1643		emit_opnd(left_sym)*/
    _45emit_opnd(_43left_sym_55509);

    /** parser.e:1644		current_sequence = append(current_sequence, left_sym)*/
    Append(&_45current_sequence_51481, _45current_sequence_51481, _43left_sym_55509);

    /** parser.e:1646		while tok[T_ID] = LEFT_SQUARE do*/
L8: 
    _2 = (object)SEQ_PTR(_tok_57838);
    _29094 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29094, -28LL)){
        _29094 = NOVALUE;
        goto L9; // [334] 523
    }
    _29094 = NOVALUE;

    /** parser.e:1647			subs_depth += 1*/
    _43subs_depth_55510 = _43subs_depth_55510 + 1;

    /** parser.e:1648			if lhs_ptr then*/
    if (_45lhs_ptr_51483 == 0)
    {
        goto LA; // [350] 405
    }
    else{
    }

    /** parser.e:1650				current_sequence = remove( current_sequence, length( current_sequence ) )*/
    if (IS_SEQUENCE(_45current_sequence_51481)){
            _29097 = SEQ_PTR(_45current_sequence_51481)->length;
    }
    else {
        _29097 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_45current_sequence_51481);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_29097)) ? _29097 : (object)(DBL_PTR(_29097)->dbl);
        int stop = (IS_ATOM_INT(_29097)) ? _29097 : (object)(DBL_PTR(_29097)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_45current_sequence_51481), start, &_45current_sequence_51481 );
            }
            else Tail(SEQ_PTR(_45current_sequence_51481), stop+1, &_45current_sequence_51481);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_45current_sequence_51481), start, &_45current_sequence_51481);
        }
        else {
            assign_slice_seq = &assign_space;
            _45current_sequence_51481 = Remove_elements(start, stop, (SEQ_PTR(_45current_sequence_51481)->ref == 1));
        }
    }
    _29097 = NOVALUE;
    _29097 = NOVALUE;

    /** parser.e:1651				if subs = 1 then*/
    if (_subs_57839 != 1LL)
    goto LB; // [371] 396

    /** parser.e:1653					subs1_patch = length(Code)+1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29100 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29100 = 1;
    }
    _subs1_patch_57842 = _29100 + 1;
    _29100 = NOVALUE;

    /** parser.e:1654					emit_op(LHS_SUBS1) -- creates new current_sequence*/
    _45emit_op(161LL);
    goto LC; // [393] 404
LB: 

    /** parser.e:1657					emit_op(LHS_SUBS) -- adds to current_sequence*/
    _45emit_op(95LL);
LC: 
LA: 

    /** parser.e:1660			subs += 1*/
    _subs_57839 = _subs_57839 + 1;

    /** parser.e:1661			if subs = 1 then*/
    if (_subs_57839 != 1LL)
    goto LD; // [413] 428

    /** parser.e:1662				InitCheck(left_sym, TRUE)*/
    _43InitCheck(_43left_sym_55509, _9TRUE_441);
LD: 

    /** parser.e:1664			Expr()*/
    _43Expr();

    /** parser.e:1665			tok = next_token()*/
    _0 = _tok_57838;
    _tok_57838 = _43next_token();
    DeRef(_0);

    /** parser.e:1666			if tok[T_ID] = SLICE then*/
    _2 = (object)SEQ_PTR(_tok_57838);
    _29105 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29105, 513LL)){
        _29105 = NOVALUE;
        goto LE; // [447] 484
    }
    _29105 = NOVALUE;

    /** parser.e:1667				Expr()*/
    _43Expr();

    /** parser.e:1668				slice = TRUE*/
    _slice_57840 = _9TRUE_441;

    /** parser.e:1669				tok_match(RIGHT_SQUARE)*/
    _43tok_match(-29LL, 0LL);

    /** parser.e:1670				tok = next_token()*/
    _0 = _tok_57838;
    _tok_57838 = _43next_token();
    DeRef(_0);

    /** parser.e:1671				exit  -- no further subs or slices allowed*/
    goto L9; // [479] 523
    goto LF; // [481] 506
LE: 

    /** parser.e:1673				putback(tok)*/
    Ref(_tok_57838);
    _43putback(_tok_57838);

    /** parser.e:1674				tok_match(RIGHT_SQUARE)*/
    _43tok_match(-29LL, 0LL);

    /** parser.e:1675				subs_depth -= 1*/
    _43subs_depth_55510 = _43subs_depth_55510 - 1LL;
LF: 

    /** parser.e:1677			tok = next_token()*/
    _0 = _tok_57838;
    _tok_57838 = _43next_token();
    DeRef(_0);

    /** parser.e:1678			lhs_ptr = TRUE*/
    _45lhs_ptr_51483 = _9TRUE_441;

    /** parser.e:1679		end while*/
    goto L8; // [520] 326
L9: 

    /** parser.e:1681		lhs_ptr = FALSE*/
    _45lhs_ptr_51483 = _9FALSE_439;

    /** parser.e:1683		assign_op = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57838);
    _assign_op_57841 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_assign_op_57841)){
        _assign_op_57841 = (object)DBL_PTR(_assign_op_57841)->dbl;
    }

    /** parser.e:1684		if not find(assign_op, ASSIGN_OPS) then*/
    _29111 = find_from(_assign_op_57841, _43ASSIGN_OPS_55451, 1LL);
    if (_29111 != 0)
    goto L10; // [549] 613
    _29111 = NOVALUE;

    /** parser.e:1685			sequence lname = SymTab[left_var[T_SYM]][S_NAME]*/
    _2 = (object)SEQ_PTR(_left_var_57836);
    _29113 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_29113)){
        _29114 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29113)->dbl));
    }
    else{
        _29114 = (object)*(((s1_ptr)_2)->base + _29113);
    }
    DeRef(_lname_57969);
    _2 = (object)SEQ_PTR(_29114);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _lname_57969 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _lname_57969 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    Ref(_lname_57969);
    _29114 = NOVALUE;

    /** parser.e:1686			if assign_op = COLON then*/
    if (_assign_op_57841 != -23LL)
    goto L11; // [578] 598

    /** parser.e:1687				CompileErr(SYNTAX_ERROR__UNKNOWN_NAMESPACE_1_USED, {lname})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_lname_57969);
    ((intptr_t*)_2)[1] = _lname_57969;
    _29117 = MAKE_SEQ(_1);
    _49CompileErr(133LL, _29117, 0LL);
    _29117 = NOVALUE;
    goto L12; // [595] 612
L11: 

    /** parser.e:1689				CompileErr(EXPECTED_TO_SEE_AN_ASSIGNMENT_AFTER_1_SUCH_AS__OR, {lname})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_lname_57969);
    ((intptr_t*)_2)[1] = _lname_57969;
    _29118 = MAKE_SEQ(_1);
    _49CompileErr(76LL, _29118, 0LL);
    _29118 = NOVALUE;
L12: 
L10: 
    DeRef(_lname_57969);
    _lname_57969 = NOVALUE;

    /** parser.e:1693		if subs = 0 then*/
    if (_subs_57839 != 0LL)
    goto L13; // [617] 745

    /** parser.e:1695			integer temp_len = length(Code)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _temp_len_57988 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _temp_len_57988 = 1;
    }

    /** parser.e:1696			if assign_op = EQUALS then*/
    if (_assign_op_57841 != 3LL)
    goto L14; // [632] 653

    /** parser.e:1697				Expr() -- RHS expression*/
    _43Expr();

    /** parser.e:1698				InitCheck(left_sym, FALSE)*/
    _43InitCheck(_43left_sym_55509, _9FALSE_439);
    goto L15; // [650] 726
L14: 

    /** parser.e:1700				InitCheck(left_sym, TRUE)*/
    _43InitCheck(_43left_sym_55509, _9TRUE_441);

    /** parser.e:1701				if left_sym > 0 then*/
    if (_43left_sym_55509 <= 0LL)
    goto L16; // [667] 709

    /** parser.e:1702					SymTab[left_sym][S_USAGE] = or_bits(SymTab[left_sym][S_USAGE], U_READ)*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_43left_sym_55509 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29125 = (object)*(((s1_ptr)_2)->base + _43left_sym_55509);
    _2 = (object)SEQ_PTR(_29125);
    _29126 = (object)*(((s1_ptr)_2)->base + 5LL);
    _29125 = NOVALUE;
    if (IS_ATOM_INT(_29126)) {
        {uintptr_t tu;
             tu = (uintptr_t)_29126 | (uintptr_t)1LL;
             _29127 = MAKE_UINT(tu);
        }
    }
    else {
        _29127 = binary_op(OR_BITS, _29126, 1LL);
    }
    _29126 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29127;
    if( _1 != _29127 ){
        DeRef(_1);
    }
    _29127 = NOVALUE;
    _29123 = NOVALUE;
L16: 

    /** parser.e:1704				emit_opnd(left_sym)*/
    _45emit_opnd(_43left_sym_55509);

    /** parser.e:1705				Expr() -- RHS expression*/
    _43Expr();

    /** parser.e:1706				emit_assign_op(assign_op)*/
    _45emit_assign_op(_assign_op_57841);
L15: 

    /** parser.e:1708			emit_op(ASSIGN)*/
    _45emit_op(18LL);

    /** parser.e:1709			TypeCheck(left_sym)*/
    _43TypeCheck(_43left_sym_55509);
    goto L17; // [742] 1169
L13: 

    /** parser.e:1712			factors = 0*/
    _43factors_55506 = 0LL;

    /** parser.e:1713			lhs_subs_level = -1*/
    _43lhs_subs_level_55507 = -1LL;

    /** parser.e:1714			Expr() -- RHS expression*/
    _43Expr();

    /** parser.e:1716			if subs > 1 then*/
    if (_subs_57839 <= 1LL)
    goto L18; // [761] 900

    /** parser.e:1717				if left_sym < 0 or SymTab[left_sym][S_SCOPE] != SC_PRIVATE and*/
    _29129 = (_43left_sym_55509 < 0LL);
    if (_29129 != 0) {
        _29130 = 1;
        goto L19; // [773] 801
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29131 = (object)*(((s1_ptr)_2)->base + _43left_sym_55509);
    _2 = (object)SEQ_PTR(_29131);
    _29132 = (object)*(((s1_ptr)_2)->base + 4LL);
    _29131 = NOVALUE;
    if (IS_ATOM_INT(_29132)) {
        _29133 = (_29132 != 3LL);
    }
    else {
        _29133 = binary_op(NOTEQ, _29132, 3LL);
    }
    _29132 = NOVALUE;
    if (IS_ATOM_INT(_29133))
    _29130 = (_29133 != 0);
    else
    _29130 = DBL_PTR(_29133)->dbl != 0.0;
L19: 
    if (_29130 == 0) {
        goto L1A; // [801] 835
    }
    _29135 = (_43left_sym_55509 % 29LL);
    _29136 = power(2LL, _29135);
    _29135 = NOVALUE;
    if (IS_ATOM_INT(_29136)) {
        {uintptr_t tu;
             tu = (uintptr_t)_43side_effect_calls_55505 & (uintptr_t)_29136;
             _29137 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (eudouble)_43side_effect_calls_55505;
        _29137 = Dand_bits(&temp_d, DBL_PTR(_29136));
    }
    DeRef(_29136);
    _29136 = NOVALUE;
    if (_29137 == 0) {
        DeRef(_29137);
        _29137 = NOVALUE;
        goto L1A; // [824] 835
    }
    else {
        if (!IS_ATOM_INT(_29137) && DBL_PTR(_29137)->dbl == 0.0){
            DeRef(_29137);
            _29137 = NOVALUE;
            goto L1A; // [824] 835
        }
        DeRef(_29137);
        _29137 = NOVALUE;
    }
    DeRef(_29137);
    _29137 = NOVALUE;

    /** parser.e:1722					dangerous = TRUE*/
    _dangerous_57844 = _9TRUE_441;
L1A: 

    /** parser.e:1725				if factors = 1 and*/
    _29138 = (_43factors_55506 == 1LL);
    if (_29138 == 0) {
        _29139 = 0;
        goto L1B; // [843] 857
    }
    _29140 = (_43lhs_subs_level_55507 >= 0LL);
    _29139 = (_29140 != 0);
L1B: 
    if (_29139 == 0) {
        goto L1C; // [857] 883
    }
    _29142 = _subs_57839 + _slice_57840;
    if ((object)((uintptr_t)_29142 + (uintptr_t)HIGH_BITS) >= 0){
        _29142 = NewDouble((eudouble)_29142);
    }
    if (IS_ATOM_INT(_29142)) {
        _29143 = (_43lhs_subs_level_55507 < _29142);
    }
    else {
        _29143 = ((eudouble)_43lhs_subs_level_55507 < DBL_PTR(_29142)->dbl);
    }
    DeRef(_29142);
    _29142 = NOVALUE;
    if (_29143 == 0)
    {
        DeRef(_29143);
        _29143 = NOVALUE;
        goto L1C; // [872] 883
    }
    else{
        DeRef(_29143);
        _29143 = NOVALUE;
    }

    /** parser.e:1729					dangerous = TRUE*/
    _dangerous_57844 = _9TRUE_441;
L1C: 

    /** parser.e:1732				if dangerous then*/
    if (_dangerous_57844 == 0)
    {
        goto L1D; // [885] 899
    }
    else{
    }

    /** parser.e:1738					backpatch(subs1_patch, LHS_SUBS1_COPY)*/
    _45backpatch(_subs1_patch_57842, 166LL);
L1D: 
L18: 

    /** parser.e:1742			if slice then*/
    if (_slice_57840 == 0)
    {
        goto L1E; // [902] 970
    }
    else{
    }

    /** parser.e:1743				if assign_op != EQUALS then*/
    if (_assign_op_57841 == 3LL)
    goto L1F; // [909] 943

    /** parser.e:1744					if subs = 1 then*/
    if (_subs_57839 != 1LL)
    goto L20; // [915] 929

    /** parser.e:1745						emit_op(ASSIGN_OP_SLICE)*/
    _45emit_op(150LL);
    goto L21; // [926] 937
L20: 

    /** parser.e:1747						emit_op(PASSIGN_OP_SLICE)*/
    _45emit_op(165LL);
L21: 

    /** parser.e:1749					emit_assign_op(assign_op)*/
    _45emit_assign_op(_assign_op_57841);
L1F: 

    /** parser.e:1751				if subs = 1 then*/
    if (_subs_57839 != 1LL)
    goto L22; // [945] 959

    /** parser.e:1752					emit_op(ASSIGN_SLICE)*/
    _45emit_op(45LL);
    goto L23; // [956] 1060
L22: 

    /** parser.e:1754					emit_op(PASSIGN_SLICE)*/
    _45emit_op(163LL);
    goto L23; // [967] 1060
L1E: 

    /** parser.e:1757				if assign_op = EQUALS then*/
    if (_assign_op_57841 != 3LL)
    goto L24; // [974] 1005

    /** parser.e:1758					if subs = 1 then*/
    if (_subs_57839 != 1LL)
    goto L25; // [980] 994

    /** parser.e:1759						emit_op(ASSIGN_SUBS)*/
    _45emit_op(16LL);
    goto L26; // [991] 1059
L25: 

    /** parser.e:1761						emit_op(PASSIGN_SUBS)*/
    _45emit_op(162LL);
    goto L26; // [1002] 1059
L24: 

    /** parser.e:1764					if subs = 1 then*/
    if (_subs_57839 != 1LL)
    goto L27; // [1007] 1021

    /** parser.e:1765						emit_op(ASSIGN_OP_SUBS)*/
    _45emit_op(149LL);
    goto L28; // [1018] 1029
L27: 

    /** parser.e:1767						emit_op(PASSIGN_OP_SUBS)*/
    _45emit_op(164LL);
L28: 

    /** parser.e:1769					emit_assign_op(assign_op)*/
    _45emit_assign_op(_assign_op_57841);

    /** parser.e:1770					if subs = 1 then*/
    if (_subs_57839 != 1LL)
    goto L29; // [1036] 1050

    /** parser.e:1771						emit_op(ASSIGN_SUBS2)*/
    _45emit_op(148LL);
    goto L2A; // [1047] 1058
L29: 

    /** parser.e:1773						emit_op(PASSIGN_SUBS)*/
    _45emit_op(162LL);
L2A: 
L26: 
L23: 

    /** parser.e:1778			if subs > 1 then*/
    if (_subs_57839 <= 1LL)
    goto L2B; // [1062] 1114

    /** parser.e:1779				if dangerous then*/
    if (_dangerous_57844 == 0)
    {
        goto L2C; // [1068] 1105
    }
    else{
    }

    /** parser.e:1781					emit_opnd(left_sym)*/
    _45emit_opnd(_43left_sym_55509);

    /** parser.e:1782					emit_opnd(lhs_subs1_copy_temp) -- will be freed*/
    _45emit_opnd(_45lhs_subs1_copy_temp_51486);

    /** parser.e:1783					emit_temp( lhs_subs1_copy_temp, NEW_REFERENCE )*/
    _45emit_temp(_45lhs_subs1_copy_temp_51486, 1LL);

    /** parser.e:1784					emit_op(ASSIGN)*/
    _45emit_op(18LL);
    goto L2D; // [1102] 1113
L2C: 

    /** parser.e:1787					TempFree(lhs_subs1_copy_temp)*/
    _45TempFree(_45lhs_subs1_copy_temp_51486);
L2D: 
L2B: 

    /** parser.e:1791			if OpTypeCheck and (left_sym < 0 or SymTab[left_sym][S_VTYPE] != sequence_type) then*/
    if (_27OpTypeCheck_20642 == 0) {
        goto L2E; // [1118] 1168
    }
    _29153 = (_43left_sym_55509 < 0LL);
    if (_29153 != 0) {
        DeRef(_29154);
        _29154 = 1;
        goto L2F; // [1128] 1156
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29155 = (object)*(((s1_ptr)_2)->base + _43left_sym_55509);
    _2 = (object)SEQ_PTR(_29155);
    _29156 = (object)*(((s1_ptr)_2)->base + 15LL);
    _29155 = NOVALUE;
    if (IS_ATOM_INT(_29156)) {
        _29157 = (_29156 != _53sequence_type_47231);
    }
    else {
        _29157 = binary_op(NOTEQ, _29156, _53sequence_type_47231);
    }
    _29156 = NOVALUE;
    if (IS_ATOM_INT(_29157))
    _29154 = (_29157 != 0);
    else
    _29154 = DBL_PTR(_29157)->dbl != 0.0;
L2F: 
    if (_29154 == 0)
    {
        _29154 = NOVALUE;
        goto L2E; // [1157] 1168
    }
    else{
        _29154 = NOVALUE;
    }

    /** parser.e:1792				TypeCheck(left_sym)*/
    _43TypeCheck(_43left_sym_55509);
L2E: 
L17: 

    /** parser.e:1796		current_sequence = remove( current_sequence, length( current_sequence ) )*/
    if (IS_SEQUENCE(_45current_sequence_51481)){
            _29158 = SEQ_PTR(_45current_sequence_51481)->length;
    }
    else {
        _29158 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_45current_sequence_51481);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_29158)) ? _29158 : (object)(DBL_PTR(_29158)->dbl);
        int stop = (IS_ATOM_INT(_29158)) ? _29158 : (object)(DBL_PTR(_29158)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_45current_sequence_51481), start, &_45current_sequence_51481 );
            }
            else Tail(SEQ_PTR(_45current_sequence_51481), stop+1, &_45current_sequence_51481);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_45current_sequence_51481), start, &_45current_sequence_51481);
        }
        else {
            assign_slice_seq = &assign_space;
            _45current_sequence_51481 = Remove_elements(start, stop, (SEQ_PTR(_45current_sequence_51481)->ref == 1));
        }
    }
    _29158 = NOVALUE;
    _29158 = NOVALUE;

    /** parser.e:1798		if not TRANSLATE then*/
    if (_27TRANSLATE_20179 != 0)
    goto L30; // [1189] 1215

    /** parser.e:1799			if OpTrace then*/
    if (_27OpTrace_20641 == 0)
    {
        goto L31; // [1196] 1214
    }
    else{
    }

    /** parser.e:1800				emit_op(DISPLAY_VAR)*/
    _45emit_op(87LL);

    /** parser.e:1801				emit_addr(left_sym)*/
    _45emit_addr(_43left_sym_55509);
L31: 
L30: 

    /** parser.e:1804	end procedure*/
    DeRef(_left_var_57836);
    DeRef(_tok_57838);
    DeRef(_29129);
    _29129 = NOVALUE;
    DeRef(_29153);
    _29153 = NOVALUE;
    _29113 = NOVALUE;
    DeRef(_29140);
    _29140 = NOVALUE;
    DeRef(_29138);
    _29138 = NOVALUE;
    DeRef(_29069);
    _29069 = NOVALUE;
    DeRef(_29157);
    _29157 = NOVALUE;
    DeRef(_29133);
    _29133 = NOVALUE;
    return;
    ;
}


void _43Multi_assign()
{
    object _lhs_syms_58128 = NOVALUE;
    object _lhs_list_58129 = NOVALUE;
    object _tok_58131 = NOVALUE;
    object _need_comma_58132 = NOVALUE;
    object _temp_sym_58194 = NOVALUE;
    object _temps_58197 = NOVALUE;
    object _len_58245 = NOVALUE;
    object _29217 = NOVALUE;
    object _29215 = NOVALUE;
    object _29213 = NOVALUE;
    object _29211 = NOVALUE;
    object _29210 = NOVALUE;
    object _29209 = NOVALUE;
    object _29208 = NOVALUE;
    object _29207 = NOVALUE;
    object _29206 = NOVALUE;
    object _29204 = NOVALUE;
    object _29203 = NOVALUE;
    object _29202 = NOVALUE;
    object _29201 = NOVALUE;
    object _29200 = NOVALUE;
    object _29198 = NOVALUE;
    object _29197 = NOVALUE;
    object _29196 = NOVALUE;
    object _29195 = NOVALUE;
    object _29194 = NOVALUE;
    object _29190 = NOVALUE;
    object _29189 = NOVALUE;
    object _29188 = NOVALUE;
    object _29187 = NOVALUE;
    object _29184 = NOVALUE;
    object _29183 = NOVALUE;
    object _29181 = NOVALUE;
    object _29180 = NOVALUE;
    object _29179 = NOVALUE;
    object _29177 = NOVALUE;
    object _29176 = NOVALUE;
    object _29175 = NOVALUE;
    object _29174 = NOVALUE;
    object _29172 = NOVALUE;
    object _29171 = NOVALUE;
    object _29170 = NOVALUE;
    object _29168 = NOVALUE;
    object _29167 = NOVALUE;
    object _29164 = NOVALUE;
    object _29161 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:1811		sequence lhs_syms = {}*/
    RefDS(_22218);
    DeRef(_lhs_syms_58128);
    _lhs_syms_58128 = _22218;

    /** parser.e:1812		sequence lhs_list = {} -- make sure we don't repeat anything*/
    RefDS(_22218);
    DeRef(_lhs_list_58129);
    _lhs_list_58129 = _22218;

    /** parser.e:1814		integer need_comma = 0*/
    _need_comma_58132 = 0LL;

    /** parser.e:1815		while tok[T_ID] != RIGHT_BRACE with entry do*/
    goto L1; // [22] 215
L2: 
    _2 = (object)SEQ_PTR(_tok_58131);
    _29161 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _29161, -25LL)){
        _29161 = NOVALUE;
        goto L3; // [35] 225
    }
    _29161 = NOVALUE;

    /** parser.e:1817			if need_comma then*/
    if (_need_comma_58132 == 0)
    {
        goto L4; // [41] 63
    }
    else{
    }

    /** parser.e:1818				putback( tok )*/
    Ref(_tok_58131);
    _43putback(_tok_58131);

    /** parser.e:1819				tok_match( COMMA )*/
    _43tok_match(-30LL, 0LL);

    /** parser.e:1820				tok = next_token()*/
    _0 = _tok_58131;
    _tok_58131 = _43next_token();
    DeRef(_0);
L4: 

    /** parser.e:1823			if tok[T_ID] = QUESTION_MARK then*/
    _2 = (object)SEQ_PTR(_tok_58131);
    _29164 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29164, -31LL)){
        _29164 = NOVALUE;
        goto L5; // [73] 86
    }
    _29164 = NOVALUE;

    /** parser.e:1825				lhs_syms &= 0*/
    Append(&_lhs_syms_58128, _lhs_syms_58128, 0LL);
    goto L6; // [83] 207
L5: 

    /** parser.e:1826			elsif tok[T_ID] = VARIABLE or tok[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_58131);
    _29167 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_29167)) {
        _29168 = (_29167 == -100LL);
    }
    else {
        _29168 = binary_op(EQUALS, _29167, -100LL);
    }
    _29167 = NOVALUE;
    if (IS_ATOM_INT(_29168)) {
        if (_29168 != 0) {
            goto L7; // [100] 121
        }
    }
    else {
        if (DBL_PTR(_29168)->dbl != 0.0) {
            goto L7; // [100] 121
        }
    }
    _2 = (object)SEQ_PTR(_tok_58131);
    _29170 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_29170)) {
        _29171 = (_29170 == 512LL);
    }
    else {
        _29171 = binary_op(EQUALS, _29170, 512LL);
    }
    _29170 = NOVALUE;
    if (_29171 == 0) {
        DeRef(_29171);
        _29171 = NOVALUE;
        goto L8; // [117] 197
    }
    else {
        if (!IS_ATOM_INT(_29171) && DBL_PTR(_29171)->dbl == 0.0){
            DeRef(_29171);
            _29171 = NOVALUE;
            goto L8; // [117] 197
        }
        DeRef(_29171);
        _29171 = NOVALUE;
    }
    DeRef(_29171);
    _29171 = NOVALUE;
L7: 

    /** parser.e:1827				lhs_syms &= tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_58131);
    _29172 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_SEQUENCE(_lhs_syms_58128) && IS_ATOM(_29172)) {
        Ref(_29172);
        Append(&_lhs_syms_58128, _lhs_syms_58128, _29172);
    }
    else if (IS_ATOM(_lhs_syms_58128) && IS_SEQUENCE(_29172)) {
    }
    else {
        Concat((object_ptr)&_lhs_syms_58128, _lhs_syms_58128, _29172);
    }
    _29172 = NOVALUE;

    /** parser.e:1828				if SymTab[lhs_syms[$]][S_SCOPE] = SC_UNDEFINED then*/
    if (IS_SEQUENCE(_lhs_syms_58128)){
            _29174 = SEQ_PTR(_lhs_syms_58128)->length;
    }
    else {
        _29174 = 1;
    }
    _2 = (object)SEQ_PTR(_lhs_syms_58128);
    _29175 = (object)*(((s1_ptr)_2)->base + _29174);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_29175)){
        _29176 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29175)->dbl));
    }
    else{
        _29176 = (object)*(((s1_ptr)_2)->base + _29175);
    }
    _2 = (object)SEQ_PTR(_29176);
    _29177 = (object)*(((s1_ptr)_2)->base + 4LL);
    _29176 = NOVALUE;
    if (binary_op_a(NOTEQ, _29177, 9LL)){
        _29177 = NOVALUE;
        goto L9; // [156] 180
    }
    _29177 = NOVALUE;

    /** parser.e:1829					lhs_list = append( lhs_list, sym_name( lhs_syms[$] ) )*/
    if (IS_SEQUENCE(_lhs_syms_58128)){
            _29179 = SEQ_PTR(_lhs_syms_58128)->length;
    }
    else {
        _29179 = 1;
    }
    _2 = (object)SEQ_PTR(_lhs_syms_58128);
    _29180 = (object)*(((s1_ptr)_2)->base + _29179);
    Ref(_29180);
    _29181 = _53sym_name(_29180);
    _29180 = NOVALUE;
    Ref(_29181);
    Append(&_lhs_list_58129, _lhs_list_58129, _29181);
    DeRef(_29181);
    _29181 = NOVALUE;
    goto L6; // [177] 207
L9: 

    /** parser.e:1831					lhs_list &= lhs_syms[$]*/
    if (IS_SEQUENCE(_lhs_syms_58128)){
            _29183 = SEQ_PTR(_lhs_syms_58128)->length;
    }
    else {
        _29183 = 1;
    }
    _2 = (object)SEQ_PTR(_lhs_syms_58128);
    _29184 = (object)*(((s1_ptr)_2)->base + _29183);
    if (IS_SEQUENCE(_lhs_list_58129) && IS_ATOM(_29184)) {
        Ref(_29184);
        Append(&_lhs_list_58129, _lhs_list_58129, _29184);
    }
    else if (IS_ATOM(_lhs_list_58129) && IS_SEQUENCE(_29184)) {
    }
    else {
        Concat((object_ptr)&_lhs_list_58129, _lhs_list_58129, _29184);
    }
    _29184 = NOVALUE;
    goto L6; // [194] 207
L8: 

    /** parser.e:1834				CompileErr( A_VARIABLE_NAME_IS_EXPECTED_HERE)*/
    RefDS(_22218);
    _49CompileErr(24LL, _22218, 0LL);
L6: 

    /** parser.e:1837			need_comma = 1*/
    _need_comma_58132 = 1LL;

    /** parser.e:1838		entry*/
L1: 

    /** parser.e:1839			tok = next_token()*/
    _0 = _tok_58131;
    _tok_58131 = _43next_token();
    DeRef(_0);

    /** parser.e:1840		end while*/
    goto L2; // [222] 25
L3: 

    /** parser.e:1843		if length( lhs_list ) != length( remove_dups( sort( lhs_list ) ) ) then*/
    if (IS_SEQUENCE(_lhs_list_58129)){
            _29187 = SEQ_PTR(_lhs_list_58129)->length;
    }
    else {
        _29187 = 1;
    }
    RefDS(_lhs_list_58129);
    _29188 = _25sort(_lhs_list_58129, 1LL);
    _29189 = _24remove_dups(_29188, 2LL);
    _29188 = NOVALUE;
    if (IS_SEQUENCE(_29189)){
            _29190 = SEQ_PTR(_29189)->length;
    }
    else {
        _29190 = 1;
    }
    DeRef(_29189);
    _29189 = NOVALUE;
    if (_29187 == _29190)
    goto LA; // [243] 257

    /** parser.e:1844			CompileErr( DUPLICATE_MULTI_ASSIGN )*/
    RefDS(_22218);
    _49CompileErr(602LL, _22218, 0LL);
LA: 

    /** parser.e:1846		tok_match( EQUALS )*/
    _43tok_match(3LL, 0LL);

    /** parser.e:1849		Expr()*/
    _43Expr();

    /** parser.e:1851		symtab_index temp_sym = Pop()*/
    _temp_sym_58194 = _45Pop();
    if (!IS_ATOM_INT(_temp_sym_58194)) {
        _1 = (object)(DBL_PTR(_temp_sym_58194)->dbl);
        DeRefDS(_temp_sym_58194);
        _temp_sym_58194 = _1;
    }

    /** parser.e:1852		sequence temps = pop_temps()*/
    _0 = _temps_58197;
    _temps_58197 = _45pop_temps();
    DeRef(_0);

    /** parser.e:1853		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto LB; // [287] 303
    }
    else{
    }

    /** parser.e:1854			emit_opnd( temp_sym )*/
    _45emit_opnd(_temp_sym_58194);

    /** parser.e:1855			emit_op( REF_TEMP )*/
    _45emit_op(207LL);
LB: 

    /** parser.e:1858		for i = 1 to length( lhs_syms ) do*/
    if (IS_SEQUENCE(_lhs_syms_58128)){
            _29194 = SEQ_PTR(_lhs_syms_58128)->length;
    }
    else {
        _29194 = 1;
    }
    {
        object _i_58206;
        _i_58206 = 1LL;
LC: 
        if (_i_58206 > _29194){
            goto LD; // [308] 512
        }

        /** parser.e:1859			if lhs_syms[i] then*/
        _2 = (object)SEQ_PTR(_lhs_syms_58128);
        _29195 = (object)*(((s1_ptr)_2)->base + _i_58206);
        if (_29195 == 0) {
            _29195 = NOVALUE;
            goto LE; // [321] 503
        }
        else {
            if (!IS_ATOM_INT(_29195) && DBL_PTR(_29195)->dbl == 0.0){
                _29195 = NOVALUE;
                goto LE; // [321] 503
            }
            _29195 = NOVALUE;
        }
        _29195 = NOVALUE;

        /** parser.e:1860				if SymTab[lhs_syms[i]][S_SCOPE] = SC_UNDEFINED then*/
        _2 = (object)SEQ_PTR(_lhs_syms_58128);
        _29196 = (object)*(((s1_ptr)_2)->base + _i_58206);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!IS_ATOM_INT(_29196)){
            _29197 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29196)->dbl));
        }
        else{
            _29197 = (object)*(((s1_ptr)_2)->base + _29196);
        }
        _2 = (object)SEQ_PTR(_29197);
        _29198 = (object)*(((s1_ptr)_2)->base + 4LL);
        _29197 = NOVALUE;
        if (binary_op_a(NOTEQ, _29198, 9LL)){
            _29198 = NOVALUE;
            goto LF; // [344] 379
        }
        _29198 = NOVALUE;

        /** parser.e:1861					Forward_var( { VARIABLE, lhs_syms[i]}, ,ASSIGN )*/
        _2 = (object)SEQ_PTR(_lhs_syms_58128);
        _29200 = (object)*(((s1_ptr)_2)->base + _i_58206);
        Ref(_29200);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -100LL;
        ((intptr_t *)_2)[2] = _29200;
        _29201 = MAKE_SEQ(_1);
        _29200 = NOVALUE;
        _43Forward_var(_29201, -1LL, 18LL);
        _29201 = NOVALUE;

        /** parser.e:1862					lhs_syms[i] = Pop()*/
        _29202 = _45Pop();
        _2 = (object)SEQ_PTR(_lhs_syms_58128);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _lhs_syms_58128 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_58206);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _29202;
        if( _1 != _29202 ){
            DeRef(_1);
        }
        _29202 = NOVALUE;
        goto L10; // [376] 421
LF: 

        /** parser.e:1864					SymTab[lhs_syms[i]][S_USAGE] = or_bits(SymTab[lhs_syms[i]][S_USAGE], U_WRITTEN)*/
        _2 = (object)SEQ_PTR(_lhs_syms_58128);
        _29203 = (object)*(((s1_ptr)_2)->base + _i_58206);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_29203))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_29203)->dbl));
        else
        _3 = (object)(_29203 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_lhs_syms_58128);
        _29206 = (object)*(((s1_ptr)_2)->base + _i_58206);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!IS_ATOM_INT(_29206)){
            _29207 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29206)->dbl));
        }
        else{
            _29207 = (object)*(((s1_ptr)_2)->base + _29206);
        }
        _2 = (object)SEQ_PTR(_29207);
        _29208 = (object)*(((s1_ptr)_2)->base + 5LL);
        _29207 = NOVALUE;
        if (IS_ATOM_INT(_29208)) {
            {uintptr_t tu;
                 tu = (uintptr_t)_29208 | (uintptr_t)2LL;
                 _29209 = MAKE_UINT(tu);
            }
        }
        else {
            _29209 = binary_op(OR_BITS, _29208, 2LL);
        }
        _29208 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _29209;
        if( _1 != _29209 ){
            DeRef(_1);
        }
        _29209 = NOVALUE;
        _29204 = NOVALUE;
L10: 

        /** parser.e:1867				emit_opnd( lhs_syms[i] )*/
        _2 = (object)SEQ_PTR(_lhs_syms_58128);
        _29210 = (object)*(((s1_ptr)_2)->base + _i_58206);
        Ref(_29210);
        _45emit_opnd(_29210);
        _29210 = NOVALUE;

        /** parser.e:1869				emit_opnd( temp_sym )*/
        _45emit_opnd(_temp_sym_58194);

        /** parser.e:1870				emit_opnd( NewIntSym( i ) )*/
        _29211 = _53NewIntSym(_i_58206);
        _45emit_opnd(_29211);
        _29211 = NOVALUE;

        /** parser.e:1871				emit_op( RHS_SUBS )*/
        _45emit_op(25LL);

        /** parser.e:1872				integer len = length( Code )*/
        if (IS_SEQUENCE(_27Code_20660)){
                _len_58245 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _len_58245 = 1;
        }

        /** parser.e:1873				if Code[len] = temp_sym then*/
        _2 = (object)SEQ_PTR(_27Code_20660);
        _29213 = (object)*(((s1_ptr)_2)->base + _len_58245);
        if (binary_op_a(NOTEQ, _29213, _temp_sym_58194)){
            _29213 = NOVALUE;
            goto L11; // [466] 486
        }
        _29213 = NOVALUE;

        /** parser.e:1875					Code = remove( Code, len - 1, len )*/
        _29215 = _len_58245 - 1LL;
        {
            s1_ptr assign_space = SEQ_PTR(_27Code_20660);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_29215)) ? _29215 : (object)(DBL_PTR(_29215)->dbl);
            int stop = (IS_ATOM_INT(_len_58245)) ? _len_58245 : (object)(DBL_PTR(_len_58245)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_27Code_20660), start, &_27Code_20660 );
                }
                else Tail(SEQ_PTR(_27Code_20660), stop+1, &_27Code_20660);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_27Code_20660), start, &_27Code_20660);
            }
            else {
                assign_slice_seq = &assign_space;
                _27Code_20660 = Remove_elements(start, stop, (SEQ_PTR(_27Code_20660)->ref == 1));
            }
        }
        _29215 = NOVALUE;
L11: 

        /** parser.e:1877				emit_op( ASSIGN )*/
        _45emit_op(18LL);

        /** parser.e:1879				TypeCheck( lhs_syms[i] )*/
        _2 = (object)SEQ_PTR(_lhs_syms_58128);
        _29217 = (object)*(((s1_ptr)_2)->base + _i_58206);
        Ref(_29217);
        _43TypeCheck(_29217);
        _29217 = NOVALUE;
LE: 

        /** parser.e:1882		end for*/
        _i_58206 = _i_58206 + 1LL;
        goto LC; // [507] 315
LD: 
        ;
    }

    /** parser.e:1884		push_temps( temps )*/
    RefDS(_temps_58197);
    _45push_temps(_temps_58197);

    /** parser.e:1885		flush_temps()*/
    RefDS(_22218);
    _45flush_temps(_22218);

    /** parser.e:1887		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L12; // [526] 542
    }
    else{
    }

    /** parser.e:1888			emit_opnd( temp_sym )*/
    _45emit_opnd(_temp_sym_58194);

    /** parser.e:1889			emit_op( DEREF_TEMP )*/
    _45emit_op(208LL);
L12: 

    /** parser.e:1891	end procedure*/
    DeRef(_lhs_syms_58128);
    DeRef(_lhs_list_58129);
    DeRef(_tok_58131);
    DeRef(_temps_58197);
    _29175 = NOVALUE;
    _29206 = NOVALUE;
    _29189 = NOVALUE;
    _29196 = NOVALUE;
    DeRef(_29168);
    _29168 = NOVALUE;
    _29203 = NOVALUE;
    return;
    ;
}


void _43Return_statement()
{
    object _tok_58269 = NOVALUE;
    object _pop_58270 = NOVALUE;
    object _last_op_58277 = NOVALUE;
    object _last_pc_58280 = NOVALUE;
    object _is_tail_58283 = NOVALUE;
    object _29249 = NOVALUE;
    object _29247 = NOVALUE;
    object _29246 = NOVALUE;
    object _29245 = NOVALUE;
    object _29244 = NOVALUE;
    object _29242 = NOVALUE;
    object _29241 = NOVALUE;
    object _29240 = NOVALUE;
    object _29239 = NOVALUE;
    object _29238 = NOVALUE;
    object _29237 = NOVALUE;
    object _29236 = NOVALUE;
    object _29235 = NOVALUE;
    object _29231 = NOVALUE;
    object _29230 = NOVALUE;
    object _29228 = NOVALUE;
    object _29227 = NOVALUE;
    object _29226 = NOVALUE;
    object _29225 = NOVALUE;
    object _29224 = NOVALUE;
    object _29223 = NOVALUE;
    object _29222 = NOVALUE;
    object _29221 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1897		integer pop*/

    /** parser.e:1898		if CurrentSub = TopLevelSub then*/
    if (_27CurrentSub_20579 != _27TopLevelSub_20578)
    goto L1; // [9] 23

    /** parser.e:1899			CompileErr(RETURN_MUST_BE_INSIDE_A_PROCEDURE_OR_FUNCTION)*/
    RefDS(_22218);
    _49CompileErr(130LL, _22218, 0LL);
L1: 

    /** parser.e:1902		integer*/

    /** parser.e:1903			last_op = Last_op(),*/
    _last_op_58277 = _45Last_op();
    if (!IS_ATOM_INT(_last_op_58277)) {
        _1 = (object)(DBL_PTR(_last_op_58277)->dbl);
        DeRefDS(_last_op_58277);
        _last_op_58277 = _1;
    }

    /** parser.e:1904			last_pc = Last_pc(),*/
    _last_pc_58280 = _45Last_pc();
    if (!IS_ATOM_INT(_last_pc_58280)) {
        _1 = (object)(DBL_PTR(_last_pc_58280)->dbl);
        DeRefDS(_last_pc_58280);
        _last_pc_58280 = _1;
    }

    /** parser.e:1905			is_tail = 0*/
    _is_tail_58283 = 0LL;

    /** parser.e:1907		if last_op = PROC and length(Code) > last_pc and Code[last_pc+1] = CurrentSub then*/
    _29221 = (_last_op_58277 == 27LL);
    if (_29221 == 0) {
        _29222 = 0;
        goto L2; // [52] 69
    }
    if (IS_SEQUENCE(_27Code_20660)){
            _29223 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29223 = 1;
    }
    _29224 = (_29223 > _last_pc_58280);
    _29223 = NOVALUE;
    _29222 = (_29224 != 0);
L2: 
    if (_29222 == 0) {
        goto L3; // [69] 99
    }
    _29226 = _last_pc_58280 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _29227 = (object)*(((s1_ptr)_2)->base + _29226);
    if (IS_ATOM_INT(_29227)) {
        _29228 = (_29227 == _27CurrentSub_20579);
    }
    else {
        _29228 = binary_op(EQUALS, _29227, _27CurrentSub_20579);
    }
    _29227 = NOVALUE;
    if (_29228 == 0) {
        DeRef(_29228);
        _29228 = NOVALUE;
        goto L3; // [90] 99
    }
    else {
        if (!IS_ATOM_INT(_29228) && DBL_PTR(_29228)->dbl == 0.0){
            DeRef(_29228);
            _29228 = NOVALUE;
            goto L3; // [90] 99
        }
        DeRef(_29228);
        _29228 = NOVALUE;
    }
    DeRef(_29228);
    _29228 = NOVALUE;

    /** parser.e:1908			is_tail = 1*/
    _is_tail_58283 = 1LL;
L3: 

    /** parser.e:1911		if not TRANSLATE then*/
    if (_27TRANSLATE_20179 != 0)
    goto L4; // [103] 129

    /** parser.e:1912			if OpTrace then*/
    if (_27OpTrace_20641 == 0)
    {
        goto L5; // [110] 128
    }
    else{
    }

    /** parser.e:1913				emit_op(ERASE_PRIVATE_NAMES)*/
    _45emit_op(88LL);

    /** parser.e:1914				emit_addr(CurrentSub)*/
    _45emit_addr(_27CurrentSub_20579);
L5: 
L4: 

    /** parser.e:1917		if SymTab[CurrentSub][S_TOKEN] != PROC then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29230 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_29230);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _29231 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _29231 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _29230 = NOVALUE;
    if (binary_op_a(EQUALS, _29231, 27LL)){
        _29231 = NOVALUE;
        goto L6; // [147] 273
    }
    _29231 = NOVALUE;

    /** parser.e:1918			Expr()*/
    _43Expr();

    /** parser.e:1919			last_op = Last_op()*/
    _last_op_58277 = _45Last_op();
    if (!IS_ATOM_INT(_last_op_58277)) {
        _1 = (object)(DBL_PTR(_last_op_58277)->dbl);
        DeRefDS(_last_op_58277);
        _last_op_58277 = _1;
    }

    /** parser.e:1920			last_pc = Last_pc()*/
    _last_pc_58280 = _45Last_pc();
    if (!IS_ATOM_INT(_last_pc_58280)) {
        _1 = (object)(DBL_PTR(_last_pc_58280)->dbl);
        DeRefDS(_last_pc_58280);
        _last_pc_58280 = _1;
    }

    /** parser.e:1921			if last_op = PROC and length(Code) > last_pc and Code[last_pc+1] = CurrentSub then*/
    _29235 = (_last_op_58277 == 27LL);
    if (_29235 == 0) {
        _29236 = 0;
        goto L7; // [177] 194
    }
    if (IS_SEQUENCE(_27Code_20660)){
            _29237 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29237 = 1;
    }
    _29238 = (_29237 > _last_pc_58280);
    _29237 = NOVALUE;
    _29236 = (_29238 != 0);
L7: 
    if (_29236 == 0) {
        goto L8; // [194] 253
    }
    _29240 = _last_pc_58280 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _29241 = (object)*(((s1_ptr)_2)->base + _29240);
    if (IS_ATOM_INT(_29241)) {
        _29242 = (_29241 == _27CurrentSub_20579);
    }
    else {
        _29242 = binary_op(EQUALS, _29241, _27CurrentSub_20579);
    }
    _29241 = NOVALUE;
    if (_29242 == 0) {
        DeRef(_29242);
        _29242 = NOVALUE;
        goto L8; // [215] 253
    }
    else {
        if (!IS_ATOM_INT(_29242) && DBL_PTR(_29242)->dbl == 0.0){
            DeRef(_29242);
            _29242 = NOVALUE;
            goto L8; // [215] 253
        }
        DeRef(_29242);
        _29242 = NOVALUE;
    }
    DeRef(_29242);
    _29242 = NOVALUE;

    /** parser.e:1922				pop = Pop() -- prevent cg_stack (code generation stack) leakage*/
    _pop_58270 = _45Pop();
    if (!IS_ATOM_INT(_pop_58270)) {
        _1 = (object)(DBL_PTR(_pop_58270)->dbl);
        DeRefDS(_pop_58270);
        _pop_58270 = _1;
    }

    /** parser.e:1923				Code[Last_pc()] = PROC_TAIL*/
    _29244 = _45Last_pc();
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_29244))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_29244)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _29244);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 203LL;
    DeRef(_1);

    /** parser.e:1924				if object(pop_temps()) then end if*/
    _29245 = _45pop_temps();
    if( NOVALUE == _29245 ){
        _29246 = 0;
    }
    else{
        if (IS_ATOM_INT(_29245))
        _29246 = 1;
        else if (IS_ATOM_DBL(_29245)) {
             if (IS_ATOM_INT(DoubleToInt(_29245))) {
                 _29246 = 1;
                 } else {
                     _29246 = 2;
                } } else if (IS_SEQUENCE(_29245))
                _29246 = 3;
                else
                _29246 = 0;
            }
            DeRef(_29245);
            _29245 = NOVALUE;
            if (_29246 == 0)
            {
                _29246 = NOVALUE;
                goto L9; // [246] 300
            }
            else{
                _29246 = NOVALUE;
            }
            goto L9; // [250] 300
L8: 

            /** parser.e:1926				FuncReturn = TRUE*/
            _43FuncReturn_55476 = _9TRUE_441;

            /** parser.e:1927				emit_op(RETURNF)*/
            _45emit_op(28LL);
            goto L9; // [270] 300
L6: 

            /** parser.e:1930			if is_tail then*/
            if (_is_tail_58283 == 0)
            {
                goto LA; // [275] 292
            }
            else{
            }

            /** parser.e:1931				Code[Last_pc()] = PROC_TAIL*/
            _29247 = _45Last_pc();
            _2 = (object)SEQ_PTR(_27Code_20660);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _27Code_20660 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_29247))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_29247)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _29247);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 203LL;
            DeRef(_1);
LA: 

            /** parser.e:1933			emit_op(RETURNP)*/
            _45emit_op(29LL);
L9: 

            /** parser.e:1936		tok = next_token()*/
            _0 = _tok_58269;
            _tok_58269 = _43next_token();
            DeRef(_0);

            /** parser.e:1937		putback(tok)*/
            Ref(_tok_58269);
            _43putback(_tok_58269);

            /** parser.e:1938		NotReached(tok[T_ID], "return")*/
            _2 = (object)SEQ_PTR(_tok_58269);
            _29249 = (object)*(((s1_ptr)_2)->base + 1LL);
            Ref(_29249);
            RefDS(_26608);
            _43NotReached(_29249, _26608);
            _29249 = NOVALUE;

            /** parser.e:1939	end procedure*/
            DeRef(_tok_58269);
            DeRef(_29244);
            _29244 = NOVALUE;
            DeRef(_29247);
            _29247 = NOVALUE;
            DeRef(_29235);
            _29235 = NOVALUE;
            DeRef(_29221);
            _29221 = NOVALUE;
            DeRef(_29224);
            _29224 = NOVALUE;
            DeRef(_29226);
            _29226 = NOVALUE;
            DeRef(_29238);
            _29238 = NOVALUE;
            DeRef(_29240);
            _29240 = NOVALUE;
            return;
    ;
}


object _43exit_level(object _tok_58359, object _flag_58360)
{
    object _arg_58361 = NOVALUE;
    object _n_58362 = NOVALUE;
    object _num_labels_58363 = NOVALUE;
    object _negative_58364 = NOVALUE;
    object _labels_58365 = NOVALUE;
    object _29278 = NOVALUE;
    object _29277 = NOVALUE;
    object _29276 = NOVALUE;
    object _29275 = NOVALUE;
    object _29274 = NOVALUE;
    object _29271 = NOVALUE;
    object _29270 = NOVALUE;
    object _29269 = NOVALUE;
    object _29267 = NOVALUE;
    object _29266 = NOVALUE;
    object _29265 = NOVALUE;
    object _29264 = NOVALUE;
    object _29262 = NOVALUE;
    object _29257 = NOVALUE;
    object _29256 = NOVALUE;
    object _29254 = NOVALUE;
    object _29251 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1946		integer negative = 0*/
    _negative_58364 = 0LL;

    /** parser.e:1949		if flag then*/
    if (_flag_58360 == 0)
    {
        goto L1; // [10] 25
    }
    else{
    }

    /** parser.e:1950			labels = if_labels*/
    RefDS(_43if_labels_55497);
    DeRef(_labels_58365);
    _labels_58365 = _43if_labels_55497;
    goto L2; // [22] 35
L1: 

    /** parser.e:1952			labels = loop_labels*/
    RefDS(_43loop_labels_55496);
    DeRef(_labels_58365);
    _labels_58365 = _43loop_labels_55496;
L2: 

    /** parser.e:1954		num_labels = length(labels)*/
    if (IS_SEQUENCE(_labels_58365)){
            _num_labels_58363 = SEQ_PTR(_labels_58365)->length;
    }
    else {
        _num_labels_58363 = 1;
    }

    /** parser.e:1956		if tok[T_ID] = MINUS then*/
    _2 = (object)SEQ_PTR(_tok_58359);
    _29251 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29251, 10LL)){
        _29251 = NOVALUE;
        goto L3; // [52] 67
    }
    _29251 = NOVALUE;

    /** parser.e:1957			tok = next_token()*/
    _0 = _tok_58359;
    _tok_58359 = _43next_token();
    DeRef(_0);

    /** parser.e:1958			negative = 1*/
    _negative_58364 = 1LL;
L3: 

    /** parser.e:1961		if tok[T_ID]=ATOM then*/
    _2 = (object)SEQ_PTR(_tok_58359);
    _29254 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29254, 502LL)){
        _29254 = NOVALUE;
        goto L4; // [77] 180
    }
    _29254 = NOVALUE;

    /** parser.e:1962			arg = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_tok_58359);
    _29256 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_29256)){
        _29257 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29256)->dbl));
    }
    else{
        _29257 = (object)*(((s1_ptr)_2)->base + _29256);
    }
    DeRef(_arg_58361);
    _2 = (object)SEQ_PTR(_29257);
    _arg_58361 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_arg_58361);
    _29257 = NOVALUE;

    /** parser.e:1963			n = floor(arg)*/
    if (IS_ATOM_INT(_arg_58361))
    _n_58362 = e_floor(_arg_58361);
    else
    _n_58362 = unary_op(FLOOR, _arg_58361);
    if (!IS_ATOM_INT(_n_58362)) {
        _1 = (object)(DBL_PTR(_n_58362)->dbl);
        DeRefDS(_n_58362);
        _n_58362 = _1;
    }

    /** parser.e:1964			if negative then*/
    if (_negative_58364 == 0)
    {
        goto L5; // [110] 122
    }
    else{
    }

    /** parser.e:1965				n = num_labels - n*/
    _n_58362 = _num_labels_58363 - _n_58362;
    goto L6; // [119] 135
L5: 

    /** parser.e:1966			elsif n = 0 then*/
    if (_n_58362 != 0LL)
    goto L7; // [124] 134

    /** parser.e:1967				n = num_labels*/
    _n_58362 = _num_labels_58363;
L7: 
L6: 

    /** parser.e:1969			if n<=0 or n>num_labels then*/
    _29262 = (_n_58362 <= 0LL);
    if (_29262 != 0) {
        goto L8; // [141] 154
    }
    _29264 = (_n_58362 > _num_labels_58363);
    if (_29264 == 0)
    {
        DeRef(_29264);
        _29264 = NOVALUE;
        goto L9; // [150] 164
    }
    else{
        DeRef(_29264);
        _29264 = NOVALUE;
    }
L8: 

    /** parser.e:1970				CompileErr(EXITBREAK_ARGUMENT_OUT_OF_RANGE)*/
    RefDS(_22218);
    _49CompileErr(87LL, _22218, 0LL);
L9: 

    /** parser.e:1972			return {n, next_token()}*/
    _29265 = _43next_token();
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _n_58362;
    ((intptr_t *)_2)[2] = _29265;
    _29266 = MAKE_SEQ(_1);
    _29265 = NOVALUE;
    DeRef(_tok_58359);
    DeRef(_arg_58361);
    DeRef(_labels_58365);
    _29256 = NOVALUE;
    DeRef(_29262);
    _29262 = NOVALUE;
    return _29266;
    goto LA; // [177] 270
L4: 

    /** parser.e:1973		elsif tok[T_ID]=STRING then*/
    _2 = (object)SEQ_PTR(_tok_58359);
    _29267 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29267, 503LL)){
        _29267 = NOVALUE;
        goto LB; // [190] 259
    }
    _29267 = NOVALUE;

    /** parser.e:1974			n = find(SymTab[tok[T_SYM]][S_OBJ],labels)*/
    _2 = (object)SEQ_PTR(_tok_58359);
    _29269 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_29269)){
        _29270 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29269)->dbl));
    }
    else{
        _29270 = (object)*(((s1_ptr)_2)->base + _29269);
    }
    _2 = (object)SEQ_PTR(_29270);
    _29271 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29270 = NOVALUE;
    _n_58362 = find_from(_29271, _labels_58365, 1LL);
    _29271 = NOVALUE;

    /** parser.e:1975			if n = 0 then*/
    if (_n_58362 != 0LL)
    goto LC; // [221] 235

    /** parser.e:1976				CompileErr(UNKNOWN_BLOCK_LABEL)*/
    RefDS(_22218);
    _49CompileErr(152LL, _22218, 0LL);
LC: 

    /** parser.e:1978			return {num_labels + 1 - n, next_token()}*/
    _29274 = _num_labels_58363 + 1;
    if (_29274 > MAXINT){
        _29274 = NewDouble((eudouble)_29274);
    }
    if (IS_ATOM_INT(_29274)) {
        _29275 = _29274 - _n_58362;
        if ((object)((uintptr_t)_29275 +(uintptr_t) HIGH_BITS) >= 0){
            _29275 = NewDouble((eudouble)_29275);
        }
    }
    else {
        _29275 = NewDouble(DBL_PTR(_29274)->dbl - (eudouble)_n_58362);
    }
    DeRef(_29274);
    _29274 = NOVALUE;
    _29276 = _43next_token();
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _29275;
    ((intptr_t *)_2)[2] = _29276;
    _29277 = MAKE_SEQ(_1);
    _29276 = NOVALUE;
    _29275 = NOVALUE;
    DeRef(_tok_58359);
    DeRef(_arg_58361);
    DeRef(_labels_58365);
    _29256 = NOVALUE;
    DeRef(_29262);
    _29262 = NOVALUE;
    _29269 = NOVALUE;
    DeRef(_29266);
    _29266 = NOVALUE;
    return _29277;
    goto LA; // [256] 270
LB: 

    /** parser.e:1980			return {1, tok} -- no parameters*/
    Ref(_tok_58359);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1LL;
    ((intptr_t *)_2)[2] = _tok_58359;
    _29278 = MAKE_SEQ(_1);
    DeRef(_tok_58359);
    DeRef(_arg_58361);
    DeRef(_labels_58365);
    _29256 = NOVALUE;
    DeRef(_29277);
    _29277 = NOVALUE;
    DeRef(_29262);
    _29262 = NOVALUE;
    _29269 = NOVALUE;
    DeRef(_29266);
    _29266 = NOVALUE;
    return _29278;
LA: 
    ;
}


void _43GLabel_statement()
{
    object _tok_58424 = NOVALUE;
    object _labbel_58425 = NOVALUE;
    object _laddr_58426 = NOVALUE;
    object _n_58427 = NOVALUE;
    object _29297 = NOVALUE;
    object _29295 = NOVALUE;
    object _29294 = NOVALUE;
    object _29293 = NOVALUE;
    object _29292 = NOVALUE;
    object _29290 = NOVALUE;
    object _29287 = NOVALUE;
    object _29285 = NOVALUE;
    object _29283 = NOVALUE;
    object _29282 = NOVALUE;
    object _29280 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1986		object labbel*/

    /** parser.e:1987		object laddr*/

    /** parser.e:1988		integer n*/

    /** parser.e:1990		tok = next_token()*/
    _0 = _tok_58424;
    _tok_58424 = _43next_token();
    DeRef(_0);

    /** parser.e:1992		if tok[T_ID] != STRING then*/
    _2 = (object)SEQ_PTR(_tok_58424);
    _29280 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _29280, 503LL)){
        _29280 = NOVALUE;
        goto L1; // [22] 36
    }
    _29280 = NOVALUE;

    /** parser.e:1993			CompileErr(A_LABEL_CLAUSE_MUST_BE_FOLLOWED_BY_A_CONSTANT_STRING)*/
    RefDS(_22218);
    _49CompileErr(35LL, _22218, 0LL);
L1: 

    /** parser.e:1996		labbel = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_tok_58424);
    _29282 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_29282)){
        _29283 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29282)->dbl));
    }
    else{
        _29283 = (object)*(((s1_ptr)_2)->base + _29282);
    }
    DeRef(_labbel_58425);
    _2 = (object)SEQ_PTR(_29283);
    _labbel_58425 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_labbel_58425);
    _29283 = NOVALUE;

    /** parser.e:1997		laddr = length(Code) + 1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29285 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29285 = 1;
    }
    _laddr_58426 = _29285 + 1;
    _29285 = NOVALUE;

    /** parser.e:1999		if find(labbel, goto_labels) then*/
    _29287 = find_from(_labbel_58425, _43goto_labels_55479, 1LL);
    if (_29287 == 0)
    {
        _29287 = NOVALUE;
        goto L2; // [76] 89
    }
    else{
        _29287 = NOVALUE;
    }

    /** parser.e:2000			CompileErr(DUPLICATE_LABEL_NAME)*/
    RefDS(_22218);
    _49CompileErr(59LL, _22218, 0LL);
L2: 

    /** parser.e:2003		goto_labels = append(goto_labels, labbel)*/
    Ref(_labbel_58425);
    Append(&_43goto_labels_55479, _43goto_labels_55479, _labbel_58425);

    /** parser.e:2004		goto_addr = append(goto_addr, laddr)*/
    Append(&_43goto_addr_55480, _43goto_addr_55480, _laddr_58426);

    /** parser.e:2005		label_block = append( label_block, top_block() )*/
    _29290 = _64top_block(0LL);
    Ref(_29290);
    Append(&_43label_block_55483, _43label_block_55483, _29290);
    DeRef(_29290);
    _29290 = NOVALUE;

    /** parser.e:2007		while n with entry do*/
    goto L3; // [119] 178
L4: 
    if (_n_58427 == 0)
    {
        goto L5; // [124] 192
    }
    else{
    }

    /** parser.e:2008			backpatch(goto_list[n], laddr)*/
    _2 = (object)SEQ_PTR(_27goto_list_20683);
    _29292 = (object)*(((s1_ptr)_2)->base + _n_58427);
    Ref(_29292);
    _45backpatch(_29292, _laddr_58426);
    _29292 = NOVALUE;

    /** parser.e:2009			set_glabel_block( goto_ref[n], top_block() )*/
    _2 = (object)SEQ_PTR(_43goto_ref_55482);
    _29293 = (object)*(((s1_ptr)_2)->base + _n_58427);
    _29294 = _64top_block(0LL);
    Ref(_29293);
    _42set_glabel_block(_29293, _29294);
    _29293 = NOVALUE;
    _29294 = NOVALUE;

    /** parser.e:2010			goto_delay[n] = "" --clear it*/
    RefDS(_22218);
    _2 = (object)SEQ_PTR(_27goto_delay_20682);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27goto_delay_20682 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _n_58427);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22218;
    DeRef(_1);

    /** parser.e:2011			goto_line[n] = {-1,""} --clear it*/
    RefDS(_22218);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1LL;
    ((intptr_t *)_2)[2] = _22218;
    _29295 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_43goto_line_55478);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43goto_line_55478 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _n_58427);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29295;
    if( _1 != _29295 ){
        DeRef(_1);
    }
    _29295 = NOVALUE;

    /** parser.e:2013		entry*/
L3: 

    /** parser.e:2014			n = find(labbel, goto_delay)*/
    _n_58427 = find_from(_labbel_58425, _27goto_delay_20682, 1LL);

    /** parser.e:2015		end while*/
    goto L4; // [189] 122
L5: 

    /** parser.e:2017		force_uninitialize( map:get( goto_init, labbel, {} ) )*/
    Ref(_43goto_init_55485);
    Ref(_labbel_58425);
    RefDS(_22218);
    _29297 = _34get(_43goto_init_55485, _labbel_58425, _22218);
    _43force_uninitialize(_29297);
    _29297 = NOVALUE;

    /** parser.e:2019		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L6; // [209] 225
    }
    else{
    }

    /** parser.e:2020			emit_op(GLABEL)*/
    _45emit_op(189LL);

    /** parser.e:2021			emit_addr(laddr)*/
    _45emit_addr(_laddr_58426);
L6: 

    /** parser.e:2023	end procedure*/
    DeRef(_tok_58424);
    DeRef(_labbel_58425);
    _29282 = NOVALUE;
    return;
    ;
}


void _43Goto_statement()
{
    object _tok_58476 = NOVALUE;
    object _n_58477 = NOVALUE;
    object _num_labels_58478 = NOVALUE;
    object _32051 = NOVALUE;
    object _29336 = NOVALUE;
    object _29335 = NOVALUE;
    object _29332 = NOVALUE;
    object _29331 = NOVALUE;
    object _29330 = NOVALUE;
    object _29329 = NOVALUE;
    object _29328 = NOVALUE;
    object _29327 = NOVALUE;
    object _29326 = NOVALUE;
    object _29325 = NOVALUE;
    object _29324 = NOVALUE;
    object _29323 = NOVALUE;
    object _29322 = NOVALUE;
    object _29321 = NOVALUE;
    object _29319 = NOVALUE;
    object _29318 = NOVALUE;
    object _29316 = NOVALUE;
    object _29315 = NOVALUE;
    object _29313 = NOVALUE;
    object _29312 = NOVALUE;
    object _29310 = NOVALUE;
    object _29309 = NOVALUE;
    object _29308 = NOVALUE;
    object _29307 = NOVALUE;
    object _29304 = NOVALUE;
    object _29303 = NOVALUE;
    object _29302 = NOVALUE;
    object _29300 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2028		integer n*/

    /** parser.e:2029		integer num_labels*/

    /** parser.e:2031		tok = next_token()*/
    _0 = _tok_58476;
    _tok_58476 = _43next_token();
    DeRef(_0);

    /** parser.e:2032		num_labels = length(goto_labels)*/
    if (IS_SEQUENCE(_43goto_labels_55479)){
            _num_labels_58478 = SEQ_PTR(_43goto_labels_55479)->length;
    }
    else {
        _num_labels_58478 = 1;
    }

    /** parser.e:2034		if tok[T_ID]=STRING then*/
    _2 = (object)SEQ_PTR(_tok_58476);
    _29300 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29300, 503LL)){
        _29300 = NOVALUE;
        goto L1; // [27] 267
    }
    _29300 = NOVALUE;

    /** parser.e:2035			n = find(SymTab[tok[T_SYM]][S_OBJ],goto_labels)*/
    _2 = (object)SEQ_PTR(_tok_58476);
    _29302 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_29302)){
        _29303 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29302)->dbl));
    }
    else{
        _29303 = (object)*(((s1_ptr)_2)->base + _29302);
    }
    _2 = (object)SEQ_PTR(_29303);
    _29304 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29303 = NOVALUE;
    _n_58477 = find_from(_29304, _43goto_labels_55479, 1LL);
    _29304 = NOVALUE;

    /** parser.e:2036			if n = 0 then*/
    if (_n_58477 != 0LL)
    goto L2; // [60] 241

    /** parser.e:2037				goto_delay &= {SymTab[tok[T_SYM]][S_OBJ]}*/
    _2 = (object)SEQ_PTR(_tok_58476);
    _29307 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_29307)){
        _29308 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29307)->dbl));
    }
    else{
        _29308 = (object)*(((s1_ptr)_2)->base + _29307);
    }
    _2 = (object)SEQ_PTR(_29308);
    _29309 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29308 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_29309);
    ((intptr_t*)_2)[1] = _29309;
    _29310 = MAKE_SEQ(_1);
    _29309 = NOVALUE;
    Concat((object_ptr)&_27goto_delay_20682, _27goto_delay_20682, _29310);
    DeRefDS(_29310);
    _29310 = NOVALUE;

    /** parser.e:2038				goto_list &= length(Code)+2 --not 1???*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29312 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29312 = 1;
    }
    _29313 = _29312 + 2LL;
    _29312 = NOVALUE;
    Append(&_27goto_list_20683, _27goto_list_20683, _29313);
    _29313 = NOVALUE;

    /** parser.e:2039				goto_line &= {{line_number,ThisLine}}*/
    Ref(_49ThisLine_49693);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _27line_number_20572;
    ((intptr_t *)_2)[2] = _49ThisLine_49693;
    _29315 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _29315;
    _29316 = MAKE_SEQ(_1);
    _29315 = NOVALUE;
    Concat((object_ptr)&_43goto_line_55478, _43goto_line_55478, _29316);
    DeRefDS(_29316);
    _29316 = NOVALUE;

    /** parser.e:2040				goto_ref &= new_forward_reference( GOTO, top_block() )*/
    _29318 = _64top_block(0LL);
    _32051 = 188LL;
    _29319 = _42new_forward_reference(188LL, _29318, 188LL);
    _29318 = NOVALUE;
    _32051 = NOVALUE;
    if (IS_SEQUENCE(_43goto_ref_55482) && IS_ATOM(_29319)) {
        Ref(_29319);
        Append(&_43goto_ref_55482, _43goto_ref_55482, _29319);
    }
    else if (IS_ATOM(_43goto_ref_55482) && IS_SEQUENCE(_29319)) {
    }
    else {
        Concat((object_ptr)&_43goto_ref_55482, _43goto_ref_55482, _29319);
    }
    DeRef(_29319);
    _29319 = NOVALUE;

    /** parser.e:2041				map:put( goto_init, SymTab[tok[T_SYM]][S_OBJ], get_private_uninitialized() )*/
    _2 = (object)SEQ_PTR(_tok_58476);
    _29321 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_29321)){
        _29322 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29321)->dbl));
    }
    else{
        _29322 = (object)*(((s1_ptr)_2)->base + _29321);
    }
    _2 = (object)SEQ_PTR(_29322);
    _29323 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29322 = NOVALUE;
    _29324 = _43get_private_uninitialized();
    Ref(_43goto_init_55485);
    Ref(_29323);
    _34put(_43goto_init_55485, _29323, _29324, 1LL, 0LL);
    _29323 = NOVALUE;
    _29324 = NOVALUE;

    /** parser.e:2042				add_data( goto_ref[$], sym_obj( tok[T_SYM] ) )*/
    if (IS_SEQUENCE(_43goto_ref_55482)){
            _29325 = SEQ_PTR(_43goto_ref_55482)->length;
    }
    else {
        _29325 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_ref_55482);
    _29326 = (object)*(((s1_ptr)_2)->base + _29325);
    _2 = (object)SEQ_PTR(_tok_58476);
    _29327 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_29327);
    _29328 = _53sym_obj(_29327);
    _29327 = NOVALUE;
    Ref(_29326);
    _42add_data(_29326, _29328);
    _29326 = NOVALUE;
    _29328 = NOVALUE;

    /** parser.e:2043				set_line( goto_ref[$], line_number, ThisLine, bp )*/
    if (IS_SEQUENCE(_43goto_ref_55482)){
            _29329 = SEQ_PTR(_43goto_ref_55482)->length;
    }
    else {
        _29329 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_ref_55482);
    _29330 = (object)*(((s1_ptr)_2)->base + _29329);
    Ref(_29330);
    Ref(_49ThisLine_49693);
    _42set_line(_29330, _27line_number_20572, _49ThisLine_49693, _49bp_49697);
    _29330 = NOVALUE;
    goto L3; // [238] 259
L2: 

    /** parser.e:2045				Goto_block( top_block(), label_block[n] )*/
    _29331 = _64top_block(0LL);
    _2 = (object)SEQ_PTR(_43label_block_55483);
    _29332 = (object)*(((s1_ptr)_2)->base + _n_58477);
    Ref(_29332);
    _64Goto_block(_29331, _29332, 0LL);
    _29331 = NOVALUE;
    _29332 = NOVALUE;
L3: 

    /** parser.e:2047			tok = next_token()*/
    _0 = _tok_58476;
    _tok_58476 = _43next_token();
    DeRef(_0);
    goto L4; // [264] 277
L1: 

    /** parser.e:2049			CompileErr(GOTO_STATEMENT_WITHOUT_A_STRING_LABEL)*/
    RefDS(_22218);
    _49CompileErr(96LL, _22218, 0LL);
L4: 

    /** parser.e:2052		emit_op(GOTO)*/
    _45emit_op(188LL);

    /** parser.e:2053		if n = 0 then*/
    if (_n_58477 != 0LL)
    goto L5; // [288] 300

    /** parser.e:2054			emit_addr(0) -- to be back-patched*/
    _45emit_addr(0LL);
    goto L6; // [297] 312
L5: 

    /** parser.e:2056			emit_addr(goto_addr[n])*/
    _2 = (object)SEQ_PTR(_43goto_addr_55480);
    _29335 = (object)*(((s1_ptr)_2)->base + _n_58477);
    Ref(_29335);
    _45emit_addr(_29335);
    _29335 = NOVALUE;
L6: 

    /** parser.e:2059		putback(tok)*/
    Ref(_tok_58476);
    _43putback(_tok_58476);

    /** parser.e:2060		NotReached(tok[T_ID], "goto")*/
    _2 = (object)SEQ_PTR(_tok_58476);
    _29336 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_29336);
    RefDS(_26550);
    _43NotReached(_29336, _26550);
    _29336 = NOVALUE;

    /** parser.e:2061	end procedure*/
    DeRef(_tok_58476);
    _29321 = NOVALUE;
    _29302 = NOVALUE;
    _29307 = NOVALUE;
    return;
    ;
}


void _43Exit_statement()
{
    object _addr_inlined_AppendXList_at_65_58581 = NOVALUE;
    object _tok_58563 = NOVALUE;
    object _by_ref_58564 = NOVALUE;
    object _29344 = NOVALUE;
    object _29343 = NOVALUE;
    object _29342 = NOVALUE;
    object _29341 = NOVALUE;
    object _29339 = NOVALUE;
    object _29337 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2066		sequence by_ref*/

    /** parser.e:2068		if not length(loop_stack) then*/
    if (IS_SEQUENCE(_43loop_stack_55502)){
            _29337 = SEQ_PTR(_43loop_stack_55502)->length;
    }
    else {
        _29337 = 1;
    }
    if (_29337 != 0)
    goto L1; // [10] 23
    _29337 = NOVALUE;

    /** parser.e:2069			CompileErr(EXIT_STATEMENT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22218);
    _49CompileErr(88LL, _22218, 0LL);
L1: 

    /** parser.e:2072		by_ref = exit_level(next_token(),0) -- can't pass tok by reference*/
    _29339 = _43next_token();
    _0 = _by_ref_58564;
    _by_ref_58564 = _43exit_level(_29339, 0LL);
    DeRef(_0);
    _29339 = NOVALUE;

    /** parser.e:2073		Leave_blocks( by_ref[1], LOOP_BLOCK )*/
    _2 = (object)SEQ_PTR(_by_ref_58564);
    _29341 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_29341);
    _64Leave_blocks(_29341, 1LL);
    _29341 = NOVALUE;

    /** parser.e:2074		emit_op(EXIT)*/
    _45emit_op(61LL);

    /** parser.e:2075		AppendXList(length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29342 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29342 = 1;
    }
    _29343 = _29342 + 1;
    _29342 = NOVALUE;
    _addr_inlined_AppendXList_at_65_58581 = _29343;
    _29343 = NOVALUE;

    /** parser.e:398		exit_list = append(exit_list, addr)*/
    Append(&_43exit_list_55488, _43exit_list_55488, _addr_inlined_AppendXList_at_65_58581);

    /** parser.e:399	end procedure*/
    goto L2; // [80] 83
L2: 

    /** parser.e:2076		exit_delay &= by_ref[1]*/
    _2 = (object)SEQ_PTR(_by_ref_58564);
    _29344 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_43exit_delay_55489) && IS_ATOM(_29344)) {
        Ref(_29344);
        Append(&_43exit_delay_55489, _43exit_delay_55489, _29344);
    }
    else if (IS_ATOM(_43exit_delay_55489) && IS_SEQUENCE(_29344)) {
    }
    else {
        Concat((object_ptr)&_43exit_delay_55489, _43exit_delay_55489, _29344);
    }
    _29344 = NOVALUE;

    /** parser.e:2077		emit_forward_addr()    -- to be back-patched*/
    _43emit_forward_addr();

    /** parser.e:2078		tok = by_ref[2]*/
    DeRef(_tok_58563);
    _2 = (object)SEQ_PTR(_by_ref_58564);
    _tok_58563 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_tok_58563);

    /** parser.e:2079		putback(tok)*/
    Ref(_tok_58563);
    _43putback(_tok_58563);

    /** parser.e:2080	end procedure*/
    DeRef(_tok_58563);
    DeRefDS(_by_ref_58564);
    return;
    ;
}


void _43Continue_statement()
{
    object _addr_inlined_AppendNList_at_153_58627 = NOVALUE;
    object _tok_58588 = NOVALUE;
    object _by_ref_58589 = NOVALUE;
    object _loop_level_58590 = NOVALUE;
    object _29370 = NOVALUE;
    object _29367 = NOVALUE;
    object _29366 = NOVALUE;
    object _29365 = NOVALUE;
    object _29364 = NOVALUE;
    object _29363 = NOVALUE;
    object _29362 = NOVALUE;
    object _29360 = NOVALUE;
    object _29359 = NOVALUE;
    object _29358 = NOVALUE;
    object _29357 = NOVALUE;
    object _29356 = NOVALUE;
    object _29355 = NOVALUE;
    object _29354 = NOVALUE;
    object _29353 = NOVALUE;
    object _29351 = NOVALUE;
    object _29349 = NOVALUE;
    object _29347 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2085		sequence by_ref*/

    /** parser.e:2086		integer loop_level*/

    /** parser.e:2088		if not length(loop_stack) then*/
    if (IS_SEQUENCE(_43loop_stack_55502)){
            _29347 = SEQ_PTR(_43loop_stack_55502)->length;
    }
    else {
        _29347 = 1;
    }
    if (_29347 != 0)
    goto L1; // [12] 25
    _29347 = NOVALUE;

    /** parser.e:2089			CompileErr(CONTINUE_STATEMENT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22218);
    _49CompileErr(49LL, _22218, 0LL);
L1: 

    /** parser.e:2092		by_ref = exit_level(next_token(),0) -- can't pass tok by reference*/
    _29349 = _43next_token();
    _0 = _by_ref_58589;
    _by_ref_58589 = _43exit_level(_29349, 0LL);
    DeRef(_0);
    _29349 = NOVALUE;

    /** parser.e:2093		Leave_blocks( by_ref[1], LOOP_BLOCK )*/
    _2 = (object)SEQ_PTR(_by_ref_58589);
    _29351 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_29351);
    _64Leave_blocks(_29351, 1LL);
    _29351 = NOVALUE;

    /** parser.e:2094		emit_op(ELSE)*/
    _45emit_op(23LL);

    /** parser.e:2095		loop_level = by_ref[1]*/
    _2 = (object)SEQ_PTR(_by_ref_58589);
    _loop_level_58590 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_loop_level_58590))
    _loop_level_58590 = (object)DBL_PTR(_loop_level_58590)->dbl;

    /** parser.e:2098		if continue_addr[$+1-loop_level] then -- address is known for while loops*/
    if (IS_SEQUENCE(_43continue_addr_55493)){
            _29353 = SEQ_PTR(_43continue_addr_55493)->length;
    }
    else {
        _29353 = 1;
    }
    _29354 = _29353 + 1;
    _29353 = NOVALUE;
    _29355 = _29354 - _loop_level_58590;
    _29354 = NOVALUE;
    _2 = (object)SEQ_PTR(_43continue_addr_55493);
    _29356 = (object)*(((s1_ptr)_2)->base + _29355);
    if (_29356 == 0)
    {
        _29356 = NOVALUE;
        goto L2; // [81] 142
    }
    else{
        _29356 = NOVALUE;
    }

    /** parser.e:2099			if continue_addr[$+1-loop_level] < 0 then*/
    if (IS_SEQUENCE(_43continue_addr_55493)){
            _29357 = SEQ_PTR(_43continue_addr_55493)->length;
    }
    else {
        _29357 = 1;
    }
    _29358 = _29357 + 1;
    _29357 = NOVALUE;
    _29359 = _29358 - _loop_level_58590;
    _29358 = NOVALUE;
    _2 = (object)SEQ_PTR(_43continue_addr_55493);
    _29360 = (object)*(((s1_ptr)_2)->base + _29359);
    if (_29360 >= 0LL)
    goto L3; // [103] 117

    /** parser.e:2101				CompileErr(CONTINUE_STATEMENT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22218);
    _49CompileErr(49LL, _22218, 0LL);
L3: 

    /** parser.e:2103			emit_addr(continue_addr[$+1-loop_level])*/
    if (IS_SEQUENCE(_43continue_addr_55493)){
            _29362 = SEQ_PTR(_43continue_addr_55493)->length;
    }
    else {
        _29362 = 1;
    }
    _29363 = _29362 + 1;
    _29362 = NOVALUE;
    _29364 = _29363 - _loop_level_58590;
    _29363 = NOVALUE;
    _2 = (object)SEQ_PTR(_43continue_addr_55493);
    _29365 = (object)*(((s1_ptr)_2)->base + _29364);
    _45emit_addr(_29365);
    _29365 = NOVALUE;
    goto L4; // [139] 186
L2: 

    /** parser.e:2105			AppendNList(length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29366 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29366 = 1;
    }
    _29367 = _29366 + 1;
    _29366 = NOVALUE;
    _addr_inlined_AppendNList_at_153_58627 = _29367;
    _29367 = NOVALUE;

    /** parser.e:403		continue_list = append(continue_list, addr)*/
    Append(&_43continue_list_55490, _43continue_list_55490, _addr_inlined_AppendNList_at_153_58627);

    /** parser.e:404	end procedure*/
    goto L5; // [168] 171
L5: 

    /** parser.e:2106			continue_delay &= loop_level*/
    Append(&_43continue_delay_55491, _43continue_delay_55491, _loop_level_58590);

    /** parser.e:2107			emit_forward_addr()    -- to be back-patched*/
    _43emit_forward_addr();
L4: 

    /** parser.e:2110		tok = by_ref[2]*/
    DeRef(_tok_58588);
    _2 = (object)SEQ_PTR(_by_ref_58589);
    _tok_58588 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_tok_58588);

    /** parser.e:2111		putback(tok)*/
    Ref(_tok_58588);
    _43putback(_tok_58588);

    /** parser.e:2113		NotReached(tok[T_ID], "continue")*/
    _2 = (object)SEQ_PTR(_tok_58588);
    _29370 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_29370);
    RefDS(_26512);
    _43NotReached(_29370, _26512);
    _29370 = NOVALUE;

    /** parser.e:2114	end procedure*/
    DeRef(_tok_58588);
    DeRefDS(_by_ref_58589);
    DeRef(_29364);
    _29364 = NOVALUE;
    DeRef(_29355);
    _29355 = NOVALUE;
    _29360 = NOVALUE;
    DeRef(_29359);
    _29359 = NOVALUE;
    return;
    ;
}


void _43Retry_statement()
{
    object _by_ref_58634 = NOVALUE;
    object _tok_58636 = NOVALUE;
    object _29394 = NOVALUE;
    object _29392 = NOVALUE;
    object _29391 = NOVALUE;
    object _29390 = NOVALUE;
    object _29389 = NOVALUE;
    object _29388 = NOVALUE;
    object _29386 = NOVALUE;
    object _29385 = NOVALUE;
    object _29384 = NOVALUE;
    object _29383 = NOVALUE;
    object _29382 = NOVALUE;
    object _29380 = NOVALUE;
    object _29379 = NOVALUE;
    object _29378 = NOVALUE;
    object _29377 = NOVALUE;
    object _29376 = NOVALUE;
    object _29375 = NOVALUE;
    object _29373 = NOVALUE;
    object _29371 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2122		if not length(loop_stack) then*/
    if (IS_SEQUENCE(_43loop_stack_55502)){
            _29371 = SEQ_PTR(_43loop_stack_55502)->length;
    }
    else {
        _29371 = 1;
    }
    if (_29371 != 0)
    goto L1; // [8] 21
    _29371 = NOVALUE;

    /** parser.e:2123			CompileErr(RETRY_STATEMENT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22218);
    _49CompileErr(131LL, _22218, 0LL);
L1: 

    /** parser.e:2126		by_ref = exit_level(next_token(),0) -- can't pass tok by reference*/
    _29373 = _43next_token();
    _0 = _by_ref_58634;
    _by_ref_58634 = _43exit_level(_29373, 0LL);
    DeRef(_0);
    _29373 = NOVALUE;

    /** parser.e:2127		Leave_blocks( by_ref[1], LOOP_BLOCK )*/
    _2 = (object)SEQ_PTR(_by_ref_58634);
    _29375 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_29375);
    _64Leave_blocks(_29375, 1LL);
    _29375 = NOVALUE;

    /** parser.e:2128		if loop_stack[$+1-by_ref[1]]=FOR then*/
    if (IS_SEQUENCE(_43loop_stack_55502)){
            _29376 = SEQ_PTR(_43loop_stack_55502)->length;
    }
    else {
        _29376 = 1;
    }
    _29377 = _29376 + 1;
    _29376 = NOVALUE;
    _2 = (object)SEQ_PTR(_by_ref_58634);
    _29378 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_29378)) {
        _29379 = _29377 - _29378;
    }
    else {
        _29379 = binary_op(MINUS, _29377, _29378);
    }
    _29377 = NOVALUE;
    _29378 = NOVALUE;
    _2 = (object)SEQ_PTR(_43loop_stack_55502);
    if (!IS_ATOM_INT(_29379)){
        _29380 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29379)->dbl));
    }
    else{
        _29380 = (object)*(((s1_ptr)_2)->base + _29379);
    }
    if (_29380 != 21LL)
    goto L2; // [70] 84

    /** parser.e:2129			emit_op(RETRY) -- for Translator to emit a label at the right place*/
    _45emit_op(184LL);
    goto L3; // [81] 129
L2: 

    /** parser.e:2131			if retry_addr[$+1-by_ref[1]] < 0 then*/
    if (IS_SEQUENCE(_43retry_addr_55494)){
            _29382 = SEQ_PTR(_43retry_addr_55494)->length;
    }
    else {
        _29382 = 1;
    }
    _29383 = _29382 + 1;
    _29382 = NOVALUE;
    _2 = (object)SEQ_PTR(_by_ref_58634);
    _29384 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_29384)) {
        _29385 = _29383 - _29384;
    }
    else {
        _29385 = binary_op(MINUS, _29383, _29384);
    }
    _29383 = NOVALUE;
    _29384 = NOVALUE;
    _2 = (object)SEQ_PTR(_43retry_addr_55494);
    if (!IS_ATOM_INT(_29385)){
        _29386 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29385)->dbl));
    }
    else{
        _29386 = (object)*(((s1_ptr)_2)->base + _29385);
    }
    if (_29386 >= 0LL)
    goto L4; // [107] 121

    /** parser.e:2133				CompileErr(RETRY_STATEMENT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22218);
    _49CompileErr(131LL, _22218, 0LL);
L4: 

    /** parser.e:2135			emit_op(ELSE)*/
    _45emit_op(23LL);
L3: 

    /** parser.e:2138		emit_addr(retry_addr[$+1-by_ref[1]])*/
    if (IS_SEQUENCE(_43retry_addr_55494)){
            _29388 = SEQ_PTR(_43retry_addr_55494)->length;
    }
    else {
        _29388 = 1;
    }
    _29389 = _29388 + 1;
    _29388 = NOVALUE;
    _2 = (object)SEQ_PTR(_by_ref_58634);
    _29390 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_29390)) {
        _29391 = _29389 - _29390;
    }
    else {
        _29391 = binary_op(MINUS, _29389, _29390);
    }
    _29389 = NOVALUE;
    _29390 = NOVALUE;
    _2 = (object)SEQ_PTR(_43retry_addr_55494);
    if (!IS_ATOM_INT(_29391)){
        _29392 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29391)->dbl));
    }
    else{
        _29392 = (object)*(((s1_ptr)_2)->base + _29391);
    }
    _45emit_addr(_29392);
    _29392 = NOVALUE;

    /** parser.e:2139		tok = by_ref[2]*/
    DeRef(_tok_58636);
    _2 = (object)SEQ_PTR(_by_ref_58634);
    _tok_58636 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_tok_58636);

    /** parser.e:2140		putback(tok)*/
    Ref(_tok_58636);
    _43putback(_tok_58636);

    /** parser.e:2141		NotReached(tok[T_ID], "retry")*/
    _2 = (object)SEQ_PTR(_tok_58636);
    _29394 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_29394);
    RefDS(_26606);
    _43NotReached(_29394, _26606);
    _29394 = NOVALUE;

    /** parser.e:2142	end procedure*/
    DeRefDS(_by_ref_58634);
    DeRef(_tok_58636);
    DeRef(_29391);
    _29391 = NOVALUE;
    _29386 = NOVALUE;
    DeRef(_29385);
    _29385 = NOVALUE;
    DeRef(_29379);
    _29379 = NOVALUE;
    _29380 = NOVALUE;
    return;
    ;
}


object _43in_switch()
{
    object _29399 = NOVALUE;
    object _29398 = NOVALUE;
    object _29397 = NOVALUE;
    object _29396 = NOVALUE;
    object _29395 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2145		if length( if_stack ) and if_stack[$] = SWITCH then*/
    if (IS_SEQUENCE(_43if_stack_55503)){
            _29395 = SEQ_PTR(_43if_stack_55503)->length;
    }
    else {
        _29395 = 1;
    }
    if (_29395 == 0) {
        goto L1; // [8] 40
    }
    if (IS_SEQUENCE(_43if_stack_55503)){
            _29397 = SEQ_PTR(_43if_stack_55503)->length;
    }
    else {
        _29397 = 1;
    }
    _2 = (object)SEQ_PTR(_43if_stack_55503);
    _29398 = (object)*(((s1_ptr)_2)->base + _29397);
    _29399 = (_29398 == 185LL);
    _29398 = NOVALUE;
    if (_29399 == 0)
    {
        DeRef(_29399);
        _29399 = NOVALUE;
        goto L1; // [28] 40
    }
    else{
        DeRef(_29399);
        _29399 = NOVALUE;
    }

    /** parser.e:2146			return 1*/
    return 1LL;
    goto L2; // [37] 47
L1: 

    /** parser.e:2148			return 0*/
    return 0LL;
L2: 
    ;
}


void _43Break_statement()
{
    object _addr_inlined_AppendEList_at_65_58709 = NOVALUE;
    object _tok_58691 = NOVALUE;
    object _by_ref_58692 = NOVALUE;
    object _29410 = NOVALUE;
    object _29407 = NOVALUE;
    object _29406 = NOVALUE;
    object _29405 = NOVALUE;
    object _29404 = NOVALUE;
    object _29402 = NOVALUE;
    object _29400 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2154		sequence by_ref*/

    /** parser.e:2156		if not length(if_labels) then*/
    if (IS_SEQUENCE(_43if_labels_55497)){
            _29400 = SEQ_PTR(_43if_labels_55497)->length;
    }
    else {
        _29400 = 1;
    }
    if (_29400 != 0)
    goto L1; // [10] 23
    _29400 = NOVALUE;

    /** parser.e:2157			CompileErr(BREAK_STATEMENT_MUST_BE_INSIDE_A_IF_OR_A_SWITCH_BLOCK)*/
    RefDS(_22218);
    _49CompileErr(40LL, _22218, 0LL);
L1: 

    /** parser.e:2160		by_ref = exit_level(next_token(),1)*/
    _29402 = _43next_token();
    _0 = _by_ref_58692;
    _by_ref_58692 = _43exit_level(_29402, 1LL);
    DeRef(_0);
    _29402 = NOVALUE;

    /** parser.e:2161		Leave_blocks( by_ref[1], CONDITIONAL_BLOCK )*/
    _2 = (object)SEQ_PTR(_by_ref_58692);
    _29404 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_29404);
    _64Leave_blocks(_29404, 2LL);
    _29404 = NOVALUE;

    /** parser.e:2162		emit_op(ELSE)*/
    _45emit_op(23LL);

    /** parser.e:2163		AppendEList(length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29405 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29405 = 1;
    }
    _29406 = _29405 + 1;
    _29405 = NOVALUE;
    _addr_inlined_AppendEList_at_65_58709 = _29406;
    _29406 = NOVALUE;

    /** parser.e:393		break_list = append(break_list, addr)*/
    Append(&_43break_list_55486, _43break_list_55486, _addr_inlined_AppendEList_at_65_58709);

    /** parser.e:394	end procedure*/
    goto L2; // [80] 83
L2: 

    /** parser.e:2165		break_delay &= by_ref[1]*/
    _2 = (object)SEQ_PTR(_by_ref_58692);
    _29407 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_43break_delay_55487) && IS_ATOM(_29407)) {
        Ref(_29407);
        Append(&_43break_delay_55487, _43break_delay_55487, _29407);
    }
    else if (IS_ATOM(_43break_delay_55487) && IS_SEQUENCE(_29407)) {
    }
    else {
        Concat((object_ptr)&_43break_delay_55487, _43break_delay_55487, _29407);
    }
    _29407 = NOVALUE;

    /** parser.e:2166		emit_forward_addr()    -- to be back-patched*/
    _43emit_forward_addr();

    /** parser.e:2167		tok = by_ref[2]*/
    DeRef(_tok_58691);
    _2 = (object)SEQ_PTR(_by_ref_58692);
    _tok_58691 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_tok_58691);

    /** parser.e:2168		putback(tok)*/
    Ref(_tok_58691);
    _43putback(_tok_58691);

    /** parser.e:2169		NotReached(tok[T_ID], "break")*/
    _2 = (object)SEQ_PTR(_tok_58691);
    _29410 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_29410);
    RefDS(_26496);
    _43NotReached(_29410, _26496);
    _29410 = NOVALUE;

    /** parser.e:2170	end procedure*/
    DeRef(_tok_58691);
    DeRefDS(_by_ref_58692);
    return;
    ;
}


object _43finish_block_header(object _opcode_58718)
{
    object _tok_58720 = NOVALUE;
    object _labbel_58721 = NOVALUE;
    object _has_entry_58722 = NOVALUE;
    object _29464 = NOVALUE;
    object _29463 = NOVALUE;
    object _29462 = NOVALUE;
    object _29461 = NOVALUE;
    object _29458 = NOVALUE;
    object _29453 = NOVALUE;
    object _29450 = NOVALUE;
    object _29448 = NOVALUE;
    object _29445 = NOVALUE;
    object _29444 = NOVALUE;
    object _29442 = NOVALUE;
    object _29439 = NOVALUE;
    object _29436 = NOVALUE;
    object _29435 = NOVALUE;
    object _29433 = NOVALUE;
    object _29431 = NOVALUE;
    object _29428 = NOVALUE;
    object _29425 = NOVALUE;
    object _29424 = NOVALUE;
    object _29422 = NOVALUE;
    object _29420 = NOVALUE;
    object _29419 = NOVALUE;
    object _29418 = NOVALUE;
    object _29415 = NOVALUE;
    object _29412 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2176		object labbel*/

    /** parser.e:2177		integer has_entry*/

    /** parser.e:2179		tok = next_token()*/
    _0 = _tok_58720;
    _tok_58720 = _43next_token();
    DeRef(_0);

    /** parser.e:2180		has_entry=0*/
    _has_entry_58722 = 0LL;

    /** parser.e:2182		if tok[T_ID] = WITH then*/
    _2 = (object)SEQ_PTR(_tok_58720);
    _29412 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29412, 420LL)){
        _29412 = NOVALUE;
        goto L1; // [27] 160
    }
    _29412 = NOVALUE;

    /** parser.e:2183			tok = next_token()*/
    _0 = _tok_58720;
    _tok_58720 = _43next_token();
    DeRef(_0);

    /** parser.e:2184			switch tok[T_ID] do*/
    _2 = (object)SEQ_PTR(_tok_58720);
    _29415 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_29415) ){
        goto L2; // [44] 140
    }
    if(!IS_ATOM_INT(_29415)){
        if( (DBL_PTR(_29415)->dbl != (eudouble) ((object) DBL_PTR(_29415)->dbl) ) ){
            goto L2; // [44] 140
        }
        _0 = (object) DBL_PTR(_29415)->dbl;
    }
    else {
        _0 = _29415;
    };
    _29415 = NOVALUE;
    switch ( _0 ){ 

        /** parser.e:2185			    case ENTRY then*/
        case 424:

        /** parser.e:2186					if not (opcode = WHILE or opcode = LOOP) then*/
        _29418 = (_opcode_58718 == 47LL);
        if (_29418 != 0) {
            DeRef(_29419);
            _29419 = 1;
            goto L3; // [61] 75
        }
        _29420 = (_opcode_58718 == 422LL);
        _29419 = (_29420 != 0);
L3: 
        if (_29419 != 0)
        goto L4; // [75] 88
        _29419 = NOVALUE;

        /** parser.e:2187						CompileErr(MSG_WITH_ENTRY_IS_ONLY_VALID_ON_A_WHILE_OR_LOOP_STATEMENT)*/
        RefDS(_22218);
        _49CompileErr(14LL, _22218, 0LL);
L4: 

        /** parser.e:2190				    has_entry = 1*/
        _has_entry_58722 = 1LL;
        goto L5; // [93] 152

        /** parser.e:2192				case FALLTHRU then*/
        case 431:

        /** parser.e:2193					if not opcode = SWITCH then*/
        _29422 = (_opcode_58718 == 0);
        if (_29422 != 185LL)
        goto L6; // [106] 120

        /** parser.e:2194						CompileErr(MSG_WITH_FALLTHRU_IS_ONLY_VALID_IN_A_SWITCH_STATEMENT)*/
        RefDS(_22218);
        _49CompileErr(13LL, _22218, 0LL);
L6: 

        /** parser.e:2197					switch_stack[$][SWITCH_FALLTHRU] = 1*/
        if (IS_SEQUENCE(_43switch_stack_55717)){
                _29424 = SEQ_PTR(_43switch_stack_55717)->length;
        }
        else {
            _29424 = 1;
        }
        _2 = (object)SEQ_PTR(_43switch_stack_55717);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _43switch_stack_55717 = MAKE_SEQ(_2);
        }
        _3 = (object)(_29424 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 1LL;
        DeRef(_1);
        _29425 = NOVALUE;
        goto L5; // [136] 152

        /** parser.e:2199				case else*/
        default:
L2: 

        /** parser.e:2200				    CompileErr(AN_UNKNOWN_WITHWITHOUT_OPTION_HAS_BEEN_SPECIFIED)*/
        RefDS(_22218);
        _49CompileErr(27LL, _22218, 0LL);
    ;}L5: 

    /** parser.e:2203	        tok = next_token()*/
    _0 = _tok_58720;
    _tok_58720 = _43next_token();
    DeRef(_0);
    goto L7; // [157] 250
L1: 

    /** parser.e:2204		elsif tok[T_ID] = WITHOUT then*/
    _2 = (object)SEQ_PTR(_tok_58720);
    _29428 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29428, 421LL)){
        _29428 = NOVALUE;
        goto L8; // [170] 249
    }
    _29428 = NOVALUE;

    /** parser.e:2205			tok = next_token()*/
    _0 = _tok_58720;
    _tok_58720 = _43next_token();
    DeRef(_0);

    /** parser.e:2206			if tok[T_ID] = FALLTHRU then*/
    _2 = (object)SEQ_PTR(_tok_58720);
    _29431 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29431, 431LL)){
        _29431 = NOVALUE;
        goto L9; // [189] 233
    }
    _29431 = NOVALUE;

    /** parser.e:2207				if not opcode = SWITCH then*/
    _29433 = (_opcode_58718 == 0);
    if (_29433 != 185LL)
    goto LA; // [200] 214

    /** parser.e:2208					CompileErr(MSG_WITHOUT_FALLTHRU_IS_ONLY_VALID_IN_A_SWITCH_STATEMENT)*/
    RefDS(_22218);
    _49CompileErr(15LL, _22218, 0LL);
LA: 

    /** parser.e:2211				switch_stack[$][SWITCH_FALLTHRU] = 0*/
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _29435 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _29435 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55717);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55717 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29435 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _29436 = NOVALUE;
    goto LB; // [230] 243
L9: 

    /** parser.e:2214				CompileErr(AN_UNKNOWN_WITHWITHOUT_OPTION_HAS_BEEN_SPECIFIED)*/
    RefDS(_22218);
    _49CompileErr(27LL, _22218, 0LL);
LB: 

    /** parser.e:2216	        tok = next_token()*/
    _0 = _tok_58720;
    _tok_58720 = _43next_token();
    DeRef(_0);
L8: 
L7: 

    /** parser.e:2219		labbel=0*/
    DeRef(_labbel_58721);
    _labbel_58721 = 0LL;

    /** parser.e:2220		if tok[T_ID]=LABEL then*/
    _2 = (object)SEQ_PTR(_tok_58720);
    _29439 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29439, 419LL)){
        _29439 = NOVALUE;
        goto LC; // [265] 329
    }
    _29439 = NOVALUE;

    /** parser.e:2221			tok = next_token()*/
    _0 = _tok_58720;
    _tok_58720 = _43next_token();
    DeRef(_0);

    /** parser.e:2222			if tok[T_ID] != STRING then*/
    _2 = (object)SEQ_PTR(_tok_58720);
    _29442 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _29442, 503LL)){
        _29442 = NOVALUE;
        goto LD; // [284] 298
    }
    _29442 = NOVALUE;

    /** parser.e:2223				CompileErr(A_LABEL_CLAUSE_MUST_BE_FOLLOWED_BY_A_LITERAL_STRING)*/
    RefDS(_22218);
    _49CompileErr(38LL, _22218, 0LL);
LD: 

    /** parser.e:2225			labbel = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_tok_58720);
    _29444 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_29444)){
        _29445 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29444)->dbl));
    }
    else{
        _29445 = (object)*(((s1_ptr)_2)->base + _29444);
    }
    DeRef(_labbel_58721);
    _2 = (object)SEQ_PTR(_29445);
    _labbel_58721 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_labbel_58721);
    _29445 = NOVALUE;

    /** parser.e:2226			block_label( labbel )*/
    Ref(_labbel_58721);
    _64block_label(_labbel_58721);

    /** parser.e:2227			tok = next_token()*/
    _0 = _tok_58720;
    _tok_58720 = _43next_token();
    DeRef(_0);
LC: 

    /** parser.e:2229		if opcode = IF or opcode = SWITCH then*/
    _29448 = (_opcode_58718 == 20LL);
    if (_29448 != 0) {
        goto LE; // [337] 352
    }
    _29450 = (_opcode_58718 == 185LL);
    if (_29450 == 0)
    {
        DeRef(_29450);
        _29450 = NOVALUE;
        goto LF; // [348] 363
    }
    else{
        DeRef(_29450);
        _29450 = NOVALUE;
    }
LE: 

    /** parser.e:2230			if_labels = append(if_labels,labbel)*/
    Ref(_labbel_58721);
    Append(&_43if_labels_55497, _43if_labels_55497, _labbel_58721);
    goto L10; // [360] 372
LF: 

    /** parser.e:2232			loop_labels = append(loop_labels,labbel)*/
    Ref(_labbel_58721);
    Append(&_43loop_labels_55496, _43loop_labels_55496, _labbel_58721);
L10: 

    /** parser.e:2234		if block_index=length(block_list) then*/
    if (IS_SEQUENCE(_43block_list_55498)){
            _29453 = SEQ_PTR(_43block_list_55498)->length;
    }
    else {
        _29453 = 1;
    }
    if (_43block_index_55499 != _29453)
    goto L11; // [381] 404

    /** parser.e:2235		    block_list &= opcode*/
    Append(&_43block_list_55498, _43block_list_55498, _opcode_58718);

    /** parser.e:2236		    block_index += 1*/
    _43block_index_55499 = _43block_index_55499 + 1;
    goto L12; // [401] 423
L11: 

    /** parser.e:2238		    block_index += 1*/
    _43block_index_55499 = _43block_index_55499 + 1;

    /** parser.e:2239		    block_list[block_index] = opcode*/
    _2 = (object)SEQ_PTR(_43block_list_55498);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43block_list_55498 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _43block_index_55499);
    *(intptr_t *)_2 = _opcode_58718;
L12: 

    /** parser.e:2241		if tok[T_ID]=ENTRY then*/
    _2 = (object)SEQ_PTR(_tok_58720);
    _29458 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29458, 424LL)){
        _29458 = NOVALUE;
        goto L13; // [433] 463
    }
    _29458 = NOVALUE;

    /** parser.e:2242		    if has_entry then*/
    if (_has_entry_58722 == 0)
    {
        goto L14; // [439] 452
    }
    else{
    }

    /** parser.e:2243		        CompileErr(DUPLICATE_ENTRY_CLAUSE_IN_A_LOOP_HEADER)*/
    RefDS(_22218);
    _49CompileErr(64LL, _22218, 0LL);
L14: 

    /** parser.e:2245		    has_entry=1*/
    _has_entry_58722 = 1LL;

    /** parser.e:2246		    tok=next_token()*/
    _0 = _tok_58720;
    _tok_58720 = _43next_token();
    DeRef(_0);
L13: 

    /** parser.e:2248		if has_entry and (opcode = IF or opcode = SWITCH) then*/
    if (_has_entry_58722 == 0) {
        goto L15; // [465] 503
    }
    _29462 = (_opcode_58718 == 20LL);
    if (_29462 != 0) {
        DeRef(_29463);
        _29463 = 1;
        goto L16; // [475] 489
    }
    _29464 = (_opcode_58718 == 185LL);
    _29463 = (_29464 != 0);
L16: 
    if (_29463 == 0)
    {
        _29463 = NOVALUE;
        goto L15; // [490] 503
    }
    else{
        _29463 = NOVALUE;
    }

    /** parser.e:2249			CompileErr(ENTRY_KEYWORD_IS_NOT_SUPPORTED_INSIDE_AN_IF_OR_SWITCH_BLOCK_HEADER)*/
    RefDS(_22218);
    _49CompileErr(80LL, _22218, 0LL);
L15: 

    /** parser.e:2251		if opcode = IF then*/
    if (_opcode_58718 != 20LL)
    goto L17; // [507] 523

    /** parser.e:2252			opcode = THEN*/
    _opcode_58718 = 410LL;
    goto L18; // [520] 533
L17: 

    /** parser.e:2254			opcode = DO*/
    _opcode_58718 = 411LL;
L18: 

    /** parser.e:2256		putback(tok)*/
    Ref(_tok_58720);
    _43putback(_tok_58720);

    /** parser.e:2257		tok_match(opcode)*/
    _43tok_match(_opcode_58718, 0LL);

    /** parser.e:2258		return has_entry*/
    DeRef(_tok_58720);
    DeRef(_labbel_58721);
    DeRef(_29433);
    _29433 = NOVALUE;
    DeRef(_29420);
    _29420 = NOVALUE;
    DeRef(_29418);
    _29418 = NOVALUE;
    _29444 = NOVALUE;
    DeRef(_29448);
    _29448 = NOVALUE;
    DeRef(_29462);
    _29462 = NOVALUE;
    DeRef(_29422);
    _29422 = NOVALUE;
    DeRef(_29464);
    _29464 = NOVALUE;
    return _has_entry_58722;
    ;
}


void _43If_statement()
{
    object _addr_inlined_AppendEList_at_624_58976 = NOVALUE;
    object _addr_inlined_AppendEList_at_260_58905 = NOVALUE;
    object _tok_58848 = NOVALUE;
    object _prev_false_58849 = NOVALUE;
    object _prev_false2_58850 = NOVALUE;
    object _elist_base_58851 = NOVALUE;
    object _temps_58859 = NOVALUE;
    object _32050 = NOVALUE;
    object _29530 = NOVALUE;
    object _29529 = NOVALUE;
    object _29526 = NOVALUE;
    object _29525 = NOVALUE;
    object _29523 = NOVALUE;
    object _29522 = NOVALUE;
    object _29521 = NOVALUE;
    object _29519 = NOVALUE;
    object _29518 = NOVALUE;
    object _29516 = NOVALUE;
    object _29515 = NOVALUE;
    object _29514 = NOVALUE;
    object _29512 = NOVALUE;
    object _29511 = NOVALUE;
    object _29509 = NOVALUE;
    object _29508 = NOVALUE;
    object _29507 = NOVALUE;
    object _29506 = NOVALUE;
    object _29504 = NOVALUE;
    object _29503 = NOVALUE;
    object _29500 = NOVALUE;
    object _29498 = NOVALUE;
    object _29497 = NOVALUE;
    object _29496 = NOVALUE;
    object _29493 = NOVALUE;
    object _29490 = NOVALUE;
    object _29489 = NOVALUE;
    object _29487 = NOVALUE;
    object _29486 = NOVALUE;
    object _29484 = NOVALUE;
    object _29483 = NOVALUE;
    object _29481 = NOVALUE;
    object _29478 = NOVALUE;
    object _29476 = NOVALUE;
    object _29475 = NOVALUE;
    object _29474 = NOVALUE;
    object _29470 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2265		integer prev_false*/

    /** parser.e:2266		integer prev_false2*/

    /** parser.e:2267		integer elist_base*/

    /** parser.e:2269		if_stack &= IF*/
    Append(&_43if_stack_55503, _43if_stack_55503, 20LL);

    /** parser.e:2271		Start_block( IF )*/
    _64Start_block(20LL, 0LL);

    /** parser.e:2273		elist_base = length(break_list)*/
    if (IS_SEQUENCE(_43break_list_55486)){
            _elist_base_58851 = SEQ_PTR(_43break_list_55486)->length;
    }
    else {
        _elist_base_58851 = 1;
    }

    /** parser.e:2274		short_circuit += 1*/
    _43short_circuit_55468 = _43short_circuit_55468 + 1;

    /** parser.e:2275		short_circuit_B = FALSE*/
    _43short_circuit_B_55470 = _9FALSE_439;

    /** parser.e:2276		SC1_type = 0*/
    _43SC1_type_55473 = 0LL;

    /** parser.e:2277		Expr()*/
    _43Expr();

    /** parser.e:2279		sequence temps = get_temps()*/
    _32050 = Repeat(_22218, 2LL);
    _0 = _temps_58859;
    _temps_58859 = _45get_temps(_32050);
    DeRef(_0);
    _32050 = NOVALUE;

    /** parser.e:2281		emit_op(IF)*/
    _45emit_op(20LL);

    /** parser.e:2282		prev_false = length(Code)+1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29470 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29470 = 1;
    }
    _prev_false_58849 = _29470 + 1;
    _29470 = NOVALUE;

    /** parser.e:2283		emit_forward_addr() -- to be patched*/
    _43emit_forward_addr();

    /** parser.e:2284		prev_false2=finish_block_header(IF)  -- 0*/
    _prev_false2_58850 = _43finish_block_header(20LL);
    if (!IS_ATOM_INT(_prev_false2_58850)) {
        _1 = (object)(DBL_PTR(_prev_false2_58850)->dbl);
        DeRefDS(_prev_false2_58850);
        _prev_false2_58850 = _1;
    }

    /** parser.e:2285		if SC1_type = OR then*/
    if (_43SC1_type_55473 != 9LL)
    goto L1; // [106] 159

    /** parser.e:2286			backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29474 = _43SC1_patch_55472 - 3LL;
    if ((object)((uintptr_t)_29474 +(uintptr_t) HIGH_BITS) >= 0){
        _29474 = NewDouble((eudouble)_29474);
    }
    _45backpatch(_29474, 147LL);
    _29474 = NOVALUE;

    /** parser.e:2287			if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L2; // [128] 139
    }
    else{
    }

    /** parser.e:2288				emit_op(NOP1)  -- to get label here*/
    _45emit_op(159LL);
L2: 

    /** parser.e:2290			backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29475 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29475 = 1;
    }
    _29476 = _29475 + 1;
    _29475 = NOVALUE;
    _45backpatch(_43SC1_patch_55472, _29476);
    _29476 = NOVALUE;
    goto L3; // [156] 192
L1: 

    /** parser.e:2291		elsif SC1_type = AND then*/
    if (_43SC1_type_55473 != 8LL)
    goto L4; // [165] 191

    /** parser.e:2292			backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29478 = _43SC1_patch_55472 - 3LL;
    if ((object)((uintptr_t)_29478 +(uintptr_t) HIGH_BITS) >= 0){
        _29478 = NewDouble((eudouble)_29478);
    }
    _45backpatch(_29478, 146LL);
    _29478 = NOVALUE;

    /** parser.e:2293			prev_false2 = SC1_patch*/
    _prev_false2_58850 = _43SC1_patch_55472;
L4: 
L3: 

    /** parser.e:2295		short_circuit -= 1*/
    _43short_circuit_55468 = _43short_circuit_55468 - 1LL;

    /** parser.e:2298		Statement_list()*/
    _43Statement_list();

    /** parser.e:2299		tok = next_token()*/
    _0 = _tok_58848;
    _tok_58848 = _43next_token();
    DeRef(_0);

    /** parser.e:2301		while tok[T_ID] = ELSIF do*/
L5: 
    _2 = (object)SEQ_PTR(_tok_58848);
    _29481 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29481, 414LL)){
        _29481 = NOVALUE;
        goto L6; // [222] 530
    }
    _29481 = NOVALUE;

    /** parser.e:2302			Sibling_block( IF )*/
    _64Sibling_block(20LL);

    /** parser.e:2305			emit_op(ELSE)*/
    _45emit_op(23LL);

    /** parser.e:2306			AppendEList(length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29483 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29483 = 1;
    }
    _29484 = _29483 + 1;
    _29483 = NOVALUE;
    _addr_inlined_AppendEList_at_260_58905 = _29484;
    _29484 = NOVALUE;

    /** parser.e:393		break_list = append(break_list, addr)*/
    Append(&_43break_list_55486, _43break_list_55486, _addr_inlined_AppendEList_at_260_58905);

    /** parser.e:394	end procedure*/
    goto L7; // [266] 269
L7: 

    /** parser.e:2307			break_delay &= 1*/
    Append(&_43break_delay_55487, _43break_delay_55487, 1LL);

    /** parser.e:2308			emit_forward_addr()  -- to be patched*/
    _43emit_forward_addr();

    /** parser.e:2309			if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L8; // [287] 298
    }
    else{
    }

    /** parser.e:2310				emit_op(NOP1)*/
    _45emit_op(159LL);
L8: 

    /** parser.e:2312			backpatch(prev_false, length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29486 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29486 = 1;
    }
    _29487 = _29486 + 1;
    _29486 = NOVALUE;
    _45backpatch(_prev_false_58849, _29487);
    _29487 = NOVALUE;

    /** parser.e:2313			if prev_false2 != 0 then*/
    if (_prev_false2_58850 == 0LL)
    goto L9; // [315] 335

    /** parser.e:2314				backpatch(prev_false2, length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29489 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29489 = 1;
    }
    _29490 = _29489 + 1;
    _29489 = NOVALUE;
    _45backpatch(_prev_false2_58850, _29490);
    _29490 = NOVALUE;
L9: 

    /** parser.e:2317			StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:2318			short_circuit += 1*/
    _43short_circuit_55468 = _43short_circuit_55468 + 1;

    /** parser.e:2319			short_circuit_B = FALSE*/
    _43short_circuit_B_55470 = _9FALSE_439;

    /** parser.e:2320			SC1_type = 0*/
    _43SC1_type_55473 = 0LL;

    /** parser.e:2322			push_temps( temps )*/
    RefDS(_temps_58859);
    _45push_temps(_temps_58859);

    /** parser.e:2323			Expr()*/
    _43Expr();

    /** parser.e:2325			temps = get_temps( temps )*/
    RefDS(_temps_58859);
    _0 = _temps_58859;
    _temps_58859 = _45get_temps(_temps_58859);
    DeRefDS(_0);

    /** parser.e:2327			emit_op(IF)*/
    _45emit_op(20LL);

    /** parser.e:2328			prev_false = length(Code)+1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29493 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29493 = 1;
    }
    _prev_false_58849 = _29493 + 1;
    _29493 = NOVALUE;

    /** parser.e:2329			prev_false2 = 0*/
    _prev_false2_58850 = 0LL;

    /** parser.e:2330			emit_forward_addr() -- to be patched*/
    _43emit_forward_addr();

    /** parser.e:2331			if SC1_type = OR then*/
    if (_43SC1_type_55473 != 9LL)
    goto LA; // [414] 467

    /** parser.e:2332				backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29496 = _43SC1_patch_55472 - 3LL;
    if ((object)((uintptr_t)_29496 +(uintptr_t) HIGH_BITS) >= 0){
        _29496 = NewDouble((eudouble)_29496);
    }
    _45backpatch(_29496, 147LL);
    _29496 = NOVALUE;

    /** parser.e:2333				if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto LB; // [436] 447
    }
    else{
    }

    /** parser.e:2334					emit_op(NOP1)*/
    _45emit_op(159LL);
LB: 

    /** parser.e:2336				backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29497 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29497 = 1;
    }
    _29498 = _29497 + 1;
    _29497 = NOVALUE;
    _45backpatch(_43SC1_patch_55472, _29498);
    _29498 = NOVALUE;
    goto LC; // [464] 500
LA: 

    /** parser.e:2337			elsif SC1_type = AND then*/
    if (_43SC1_type_55473 != 8LL)
    goto LD; // [473] 499

    /** parser.e:2338				backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29500 = _43SC1_patch_55472 - 3LL;
    if ((object)((uintptr_t)_29500 +(uintptr_t) HIGH_BITS) >= 0){
        _29500 = NewDouble((eudouble)_29500);
    }
    _45backpatch(_29500, 146LL);
    _29500 = NOVALUE;

    /** parser.e:2339				prev_false2 = SC1_patch*/
    _prev_false2_58850 = _43SC1_patch_55472;
LD: 
LC: 

    /** parser.e:2341			short_circuit -= 1*/
    _43short_circuit_55468 = _43short_circuit_55468 - 1LL;

    /** parser.e:2342			tok_match(THEN)*/
    _43tok_match(410LL, 0LL);

    /** parser.e:2345			Statement_list()*/
    _43Statement_list();

    /** parser.e:2346			tok = next_token()*/
    _0 = _tok_58848;
    _tok_58848 = _43next_token();
    DeRef(_0);

    /** parser.e:2347		end while*/
    goto L5; // [527] 214
L6: 

    /** parser.e:2349		if tok[T_ID] = ELSE or length(temps[1]) then*/
    _2 = (object)SEQ_PTR(_tok_58848);
    _29503 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_29503)) {
        _29504 = (_29503 == 23LL);
    }
    else {
        _29504 = binary_op(EQUALS, _29503, 23LL);
    }
    _29503 = NOVALUE;
    if (IS_ATOM_INT(_29504)) {
        if (_29504 != 0) {
            goto LE; // [544] 560
        }
    }
    else {
        if (DBL_PTR(_29504)->dbl != 0.0) {
            goto LE; // [544] 560
        }
    }
    _2 = (object)SEQ_PTR(_temps_58859);
    _29506 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_29506)){
            _29507 = SEQ_PTR(_29506)->length;
    }
    else {
        _29507 = 1;
    }
    _29506 = NOVALUE;
    if (_29507 == 0)
    {
        _29507 = NOVALUE;
        goto LF; // [556] 715
    }
    else{
        _29507 = NOVALUE;
    }
LE: 

    /** parser.e:2354			Sibling_block( IF )*/
    _64Sibling_block(20LL);

    /** parser.e:2356			StartSourceLine(FALSE, , COVERAGE_SUPPRESS )*/
    _45StartSourceLine(_9FALSE_439, 0LL, 1LL);

    /** parser.e:2357			emit_op(ELSE)*/
    _45emit_op(23LL);

    /** parser.e:2358			AppendEList(length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29508 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29508 = 1;
    }
    _29509 = _29508 + 1;
    _29508 = NOVALUE;
    _addr_inlined_AppendEList_at_624_58976 = _29509;
    _29509 = NOVALUE;

    /** parser.e:393		break_list = append(break_list, addr)*/
    Append(&_43break_list_55486, _43break_list_55486, _addr_inlined_AppendEList_at_624_58976);

    /** parser.e:394	end procedure*/
    goto L10; // [611] 614
L10: 

    /** parser.e:2359			break_delay &= 1*/
    Append(&_43break_delay_55487, _43break_delay_55487, 1LL);

    /** parser.e:2360			emit_forward_addr() -- to be patched*/
    _43emit_forward_addr();

    /** parser.e:2361			if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L11; // [632] 643
    }
    else{
    }

    /** parser.e:2362				emit_op(NOP1)*/
    _45emit_op(159LL);
L11: 

    /** parser.e:2364			backpatch(prev_false, length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29511 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29511 = 1;
    }
    _29512 = _29511 + 1;
    _29511 = NOVALUE;
    _45backpatch(_prev_false_58849, _29512);
    _29512 = NOVALUE;

    /** parser.e:2365			if prev_false2 != 0 then*/
    if (_prev_false2_58850 == 0LL)
    goto L12; // [660] 680

    /** parser.e:2366				backpatch(prev_false2, length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29514 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29514 = 1;
    }
    _29515 = _29514 + 1;
    _29514 = NOVALUE;
    _45backpatch(_prev_false2_58850, _29515);
    _29515 = NOVALUE;
L12: 

    /** parser.e:2369			push_temps( temps )*/
    RefDS(_temps_58859);
    _45push_temps(_temps_58859);

    /** parser.e:2371			if tok[T_ID] = ELSE then*/
    _2 = (object)SEQ_PTR(_tok_58848);
    _29516 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29516, 23LL)){
        _29516 = NOVALUE;
        goto L13; // [695] 706
    }
    _29516 = NOVALUE;

    /** parser.e:2372				Statement_list()*/
    _43Statement_list();
    goto L14; // [703] 773
L13: 

    /** parser.e:2374				putback(tok)*/
    Ref(_tok_58848);
    _43putback(_tok_58848);
    goto L14; // [712] 773
LF: 

    /** parser.e:2377			putback(tok)*/
    Ref(_tok_58848);
    _43putback(_tok_58848);

    /** parser.e:2378			if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L15; // [724] 735
    }
    else{
    }

    /** parser.e:2379				emit_op(NOP1)*/
    _45emit_op(159LL);
L15: 

    /** parser.e:2381			backpatch(prev_false, length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29518 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29518 = 1;
    }
    _29519 = _29518 + 1;
    _29518 = NOVALUE;
    _45backpatch(_prev_false_58849, _29519);
    _29519 = NOVALUE;

    /** parser.e:2382			if prev_false2 != 0 then*/
    if (_prev_false2_58850 == 0LL)
    goto L16; // [752] 772

    /** parser.e:2383				backpatch(prev_false2, length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29521 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29521 = 1;
    }
    _29522 = _29521 + 1;
    _29521 = NOVALUE;
    _45backpatch(_prev_false2_58850, _29522);
    _29522 = NOVALUE;
L16: 
L14: 

    /** parser.e:2387		tok_match(END)*/
    _43tok_match(402LL, 0LL);

    /** parser.e:2388		tok_match(IF, END)*/
    _43tok_match(20LL, 402LL);

    /** parser.e:2390		End_block( IF )*/
    _64End_block(20LL);

    /** parser.e:2392		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L17; // [802] 825
    }
    else{
    }

    /** parser.e:2393			if length(break_list) > elist_base then*/
    if (IS_SEQUENCE(_43break_list_55486)){
            _29523 = SEQ_PTR(_43break_list_55486)->length;
    }
    else {
        _29523 = 1;
    }
    if (_29523 <= _elist_base_58851)
    goto L18; // [812] 824

    /** parser.e:2394				emit_op(NOP1)  -- to emit label here*/
    _45emit_op(159LL);
L18: 
L17: 

    /** parser.e:2397		PatchEList(elist_base)*/
    _43PatchEList(_elist_base_58851);

    /** parser.e:2398		if_labels = if_labels[1..$-1]*/
    if (IS_SEQUENCE(_43if_labels_55497)){
            _29525 = SEQ_PTR(_43if_labels_55497)->length;
    }
    else {
        _29525 = 1;
    }
    _29526 = _29525 - 1LL;
    _29525 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43if_labels_55497;
    RHS_Slice(_43if_labels_55497, 1LL, _29526);

    /** parser.e:2399		block_index -= 1*/
    _43block_index_55499 = _43block_index_55499 - 1LL;

    /** parser.e:2400		if_stack = if_stack[1..$-1]*/
    if (IS_SEQUENCE(_43if_stack_55503)){
            _29529 = SEQ_PTR(_43if_stack_55503)->length;
    }
    else {
        _29529 = 1;
    }
    _29530 = _29529 - 1LL;
    _29529 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43if_stack_55503;
    RHS_Slice(_43if_stack_55503, 1LL, _29530);

    /** parser.e:2402	end procedure*/
    DeRef(_tok_58848);
    DeRef(_temps_58859);
    _29530 = NOVALUE;
    _29506 = NOVALUE;
    _29526 = NOVALUE;
    DeRef(_29504);
    _29504 = NOVALUE;
    return;
    ;
}


void _43exit_loop(object _exit_base_59036)
{
    object _29545 = NOVALUE;
    object _29544 = NOVALUE;
    object _29542 = NOVALUE;
    object _29541 = NOVALUE;
    object _29539 = NOVALUE;
    object _29538 = NOVALUE;
    object _29536 = NOVALUE;
    object _29535 = NOVALUE;
    object _29533 = NOVALUE;
    object _29532 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2405		PatchXList(exit_base)*/
    _43PatchXList(_exit_base_59036);

    /** parser.e:2406		loop_labels = loop_labels[1..$-1]*/
    if (IS_SEQUENCE(_43loop_labels_55496)){
            _29532 = SEQ_PTR(_43loop_labels_55496)->length;
    }
    else {
        _29532 = 1;
    }
    _29533 = _29532 - 1LL;
    _29532 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43loop_labels_55496;
    RHS_Slice(_43loop_labels_55496, 1LL, _29533);

    /** parser.e:2407		loop_stack = loop_stack[1..$-1]*/
    if (IS_SEQUENCE(_43loop_stack_55502)){
            _29535 = SEQ_PTR(_43loop_stack_55502)->length;
    }
    else {
        _29535 = 1;
    }
    _29536 = _29535 - 1LL;
    _29535 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43loop_stack_55502;
    RHS_Slice(_43loop_stack_55502, 1LL, _29536);

    /** parser.e:2408		continue_addr = continue_addr[1..$-1]*/
    if (IS_SEQUENCE(_43continue_addr_55493)){
            _29538 = SEQ_PTR(_43continue_addr_55493)->length;
    }
    else {
        _29538 = 1;
    }
    _29539 = _29538 - 1LL;
    _29538 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43continue_addr_55493;
    RHS_Slice(_43continue_addr_55493, 1LL, _29539);

    /** parser.e:2409		retry_addr = retry_addr[1..$-1]*/
    if (IS_SEQUENCE(_43retry_addr_55494)){
            _29541 = SEQ_PTR(_43retry_addr_55494)->length;
    }
    else {
        _29541 = 1;
    }
    _29542 = _29541 - 1LL;
    _29541 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43retry_addr_55494;
    RHS_Slice(_43retry_addr_55494, 1LL, _29542);

    /** parser.e:2410		entry_addr = entry_addr[1..$-1]*/
    if (IS_SEQUENCE(_43entry_addr_55492)){
            _29544 = SEQ_PTR(_43entry_addr_55492)->length;
    }
    else {
        _29544 = 1;
    }
    _29545 = _29544 - 1LL;
    _29544 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43entry_addr_55492;
    RHS_Slice(_43entry_addr_55492, 1LL, _29545);

    /** parser.e:2411		block_index -= 1*/
    _43block_index_55499 = _43block_index_55499 - 1LL;

    /** parser.e:2412	end procedure*/
    _29545 = NOVALUE;
    _29539 = NOVALUE;
    _29536 = NOVALUE;
    _29533 = NOVALUE;
    _29542 = NOVALUE;
    return;
    ;
}


void _43push_switch()
{
    object _new_1__tmp_at14_59059 = NOVALUE;
    object _new_inlined_new_at_14_59058 = NOVALUE;
    object _29549 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2415		if_stack &= SWITCH*/
    Append(&_43if_stack_55503, _43if_stack_55503, 185LL);

    /** parser.e:2416		switch_stack = append( switch_stack,*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at14_59059;
    _new_1__tmp_at14_59059 = _34new_map_seq(8LL);
    DeRef(_0);
    Ref(_new_1__tmp_at14_59059);
    _0 = _new_inlined_new_at_14_59058;
    _new_inlined_new_at_14_59058 = _35malloc(_new_1__tmp_at14_59059, 1LL);
    DeRef(_0);
    DeRef(_new_1__tmp_at14_59059);
    _new_1__tmp_at14_59059 = NOVALUE;
    _1 = NewS1(13);
    _2 = (object)((s1_ptr)_1)->base;
    RefDSn(_22218, 2);
    ((intptr_t*)_2)[1] = _22218;
    ((intptr_t*)_2)[2] = _22218;
    ((intptr_t*)_2)[3] = 0LL;
    ((intptr_t*)_2)[4] = 0LL;
    ((intptr_t*)_2)[5] = 0LL;
    ((intptr_t*)_2)[6] = 0LL;
    Ref(_new_inlined_new_at_14_59058);
    ((intptr_t*)_2)[7] = _new_inlined_new_at_14_59058;
    RefDS(_22218);
    ((intptr_t*)_2)[8] = _22218;
    ((intptr_t*)_2)[9] = 0LL;
    RefDSn(_22218, 4);
    ((intptr_t*)_2)[10] = _22218;
    ((intptr_t*)_2)[11] = _22218;
    ((intptr_t*)_2)[12] = _22218;
    ((intptr_t*)_2)[13] = _22218;
    _29549 = MAKE_SEQ(_1);
    RefDS(_29549);
    Append(&_43switch_stack_55717, _43switch_stack_55717, _29549);
    DeRefDS(_29549);
    _29549 = NOVALUE;

    /** parser.e:2433	end procedure*/
    return;
    ;
}


void _43pop_switch(object _break_base_59064)
{
    object _29564 = NOVALUE;
    object _29563 = NOVALUE;
    object _29561 = NOVALUE;
    object _29560 = NOVALUE;
    object _29558 = NOVALUE;
    object _29557 = NOVALUE;
    object _29555 = NOVALUE;
    object _29554 = NOVALUE;
    object _29553 = NOVALUE;
    object _29552 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2438		PatchEList( break_base )*/
    _43PatchEList(_break_base_59064);

    /** parser.e:2439		block_index -= 1*/
    _43block_index_55499 = _43block_index_55499 - 1LL;

    /** parser.e:2440		if length(switch_stack[$][SWITCH_CASES]) > 0 then*/
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _29552 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _29552 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55717);
    _29553 = (object)*(((s1_ptr)_2)->base + _29552);
    _2 = (object)SEQ_PTR(_29553);
    _29554 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29553 = NOVALUE;
    if (IS_SEQUENCE(_29554)){
            _29555 = SEQ_PTR(_29554)->length;
    }
    else {
        _29555 = 1;
    }
    _29554 = NOVALUE;
    if (_29555 <= 0LL)
    goto L1; // [34] 46

    /** parser.e:2441			End_block( CASE )*/
    _64End_block(186LL);
L1: 

    /** parser.e:2443		if_labels = if_labels[1..$-1]*/
    if (IS_SEQUENCE(_43if_labels_55497)){
            _29557 = SEQ_PTR(_43if_labels_55497)->length;
    }
    else {
        _29557 = 1;
    }
    _29558 = _29557 - 1LL;
    _29557 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43if_labels_55497;
    RHS_Slice(_43if_labels_55497, 1LL, _29558);

    /** parser.e:2444		if_stack  = if_stack[1..$-1]*/
    if (IS_SEQUENCE(_43if_stack_55503)){
            _29560 = SEQ_PTR(_43if_stack_55503)->length;
    }
    else {
        _29560 = 1;
    }
    _29561 = _29560 - 1LL;
    _29560 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43if_stack_55503;
    RHS_Slice(_43if_stack_55503, 1LL, _29561);

    /** parser.e:2445		switch_stack  = switch_stack[1..$-1]*/
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _29563 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _29563 = 1;
    }
    _29564 = _29563 - 1LL;
    _29563 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43switch_stack_55717;
    RHS_Slice(_43switch_stack_55717, 1LL, _29564);

    /** parser.e:2446	end procedure*/
    _29564 = NOVALUE;
    _29558 = NOVALUE;
    _29554 = NOVALUE;
    _29561 = NOVALUE;
    return;
    ;
}


void _43add_case(object _sym_59085, object _sign_59086)
{
    object _29611 = NOVALUE;
    object _29610 = NOVALUE;
    object _29609 = NOVALUE;
    object _29608 = NOVALUE;
    object _29607 = NOVALUE;
    object _29606 = NOVALUE;
    object _29604 = NOVALUE;
    object _29603 = NOVALUE;
    object _29602 = NOVALUE;
    object _29601 = NOVALUE;
    object _29599 = NOVALUE;
    object _29598 = NOVALUE;
    object _29597 = NOVALUE;
    object _29596 = NOVALUE;
    object _29594 = NOVALUE;
    object _29593 = NOVALUE;
    object _29592 = NOVALUE;
    object _29591 = NOVALUE;
    object _29590 = NOVALUE;
    object _29588 = NOVALUE;
    object _29587 = NOVALUE;
    object _29586 = NOVALUE;
    object _29585 = NOVALUE;
    object _29584 = NOVALUE;
    object _29583 = NOVALUE;
    object _29581 = NOVALUE;
    object _29580 = NOVALUE;
    object _29579 = NOVALUE;
    object _29578 = NOVALUE;
    object _29577 = NOVALUE;
    object _29576 = NOVALUE;
    object _29574 = NOVALUE;
    object _29573 = NOVALUE;
    object _29571 = NOVALUE;
    object _29570 = NOVALUE;
    object _29569 = NOVALUE;
    object _29568 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2450		if sign < 0 then*/
    if (_sign_59086 >= 0LL)
    goto L1; // [5] 15

    /** parser.e:2451			sym = -sym*/
    _0 = _sym_59085;
    if (IS_ATOM_INT(_sym_59085)) {
        if ((uintptr_t)_sym_59085 == (uintptr_t)HIGH_BITS){
            _sym_59085 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _sym_59085 = - _sym_59085;
        }
    }
    else {
        _sym_59085 = unary_op(UMINUS, _sym_59085);
    }
    DeRefi(_0);
L1: 

    /** parser.e:2454		if find(sym, switch_stack[$][SWITCH_CASES] ) = 0 then*/
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _29568 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _29568 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55717);
    _29569 = (object)*(((s1_ptr)_2)->base + _29568);
    _2 = (object)SEQ_PTR(_29569);
    _29570 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29569 = NOVALUE;
    _29571 = find_from(_sym_59085, _29570, 1LL);
    _29570 = NOVALUE;
    if (_29571 != 0LL)
    goto L2; // [35] 252

    /** parser.e:2455			switch_stack[$][SWITCH_CASES]            = append( switch_stack[$][SWITCH_CASES], sym )*/
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _29573 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _29573 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55717);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55717 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29573 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _29576 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _29576 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55717);
    _29577 = (object)*(((s1_ptr)_2)->base + _29576);
    _2 = (object)SEQ_PTR(_29577);
    _29578 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29577 = NOVALUE;
    Ref(_sym_59085);
    Append(&_29579, _29578, _sym_59085);
    _29578 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29579;
    if( _1 != _29579 ){
        DeRef(_1);
    }
    _29579 = NOVALUE;
    _29574 = NOVALUE;

    /** parser.e:2456			switch_stack[$][SWITCH_JUMP_TABLE]      &= length(Code) + 1*/
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _29580 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _29580 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55717);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55717 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29580 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_27Code_20660)){
            _29583 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29583 = 1;
    }
    _29584 = _29583 + 1;
    _29583 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29585 = (object)*(((s1_ptr)_2)->base + 2LL);
    _29581 = NOVALUE;
    if (IS_SEQUENCE(_29585) && IS_ATOM(_29584)) {
        Append(&_29586, _29585, _29584);
    }
    else if (IS_ATOM(_29585) && IS_SEQUENCE(_29584)) {
    }
    else {
        Concat((object_ptr)&_29586, _29585, _29584);
        _29585 = NOVALUE;
    }
    _29585 = NOVALUE;
    _29584 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29586;
    if( _1 != _29586 ){
        DeRef(_1);
    }
    _29586 = NOVALUE;
    _29581 = NOVALUE;

    /** parser.e:2457			switch_stack[$][SWITCH_THISLINE]        &= {ThisLine}*/
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _29587 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _29587 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55717);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55717 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29587 + ((s1_ptr)_2)->base);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_49ThisLine_49693);
    ((intptr_t*)_2)[1] = _49ThisLine_49693;
    _29590 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29591 = (object)*(((s1_ptr)_2)->base + 10LL);
    _29588 = NOVALUE;
    if (IS_SEQUENCE(_29591) && IS_ATOM(_29590)) {
    }
    else if (IS_ATOM(_29591) && IS_SEQUENCE(_29590)) {
        Ref(_29591);
        Prepend(&_29592, _29590, _29591);
    }
    else {
        Concat((object_ptr)&_29592, _29591, _29590);
        _29591 = NOVALUE;
    }
    _29591 = NOVALUE;
    DeRefDS(_29590);
    _29590 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29592;
    if( _1 != _29592 ){
        DeRef(_1);
    }
    _29592 = NOVALUE;
    _29588 = NOVALUE;

    /** parser.e:2458			switch_stack[$][SWITCH_BP]              &= bp*/
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _29593 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _29593 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55717);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55717 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29593 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29596 = (object)*(((s1_ptr)_2)->base + 11LL);
    _29594 = NOVALUE;
    if (IS_SEQUENCE(_29596) && IS_ATOM(_49bp_49697)) {
        Append(&_29597, _29596, _49bp_49697);
    }
    else if (IS_ATOM(_29596) && IS_SEQUENCE(_49bp_49697)) {
    }
    else {
        Concat((object_ptr)&_29597, _29596, _49bp_49697);
        _29596 = NOVALUE;
    }
    _29596 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29597;
    if( _1 != _29597 ){
        DeRef(_1);
    }
    _29597 = NOVALUE;
    _29594 = NOVALUE;

    /** parser.e:2459			switch_stack[$][SWITCH_LINE_NUMBER]     &= line_number*/
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _29598 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _29598 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55717);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55717 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29598 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29601 = (object)*(((s1_ptr)_2)->base + 12LL);
    _29599 = NOVALUE;
    if (IS_SEQUENCE(_29601) && IS_ATOM(_27line_number_20572)) {
        Append(&_29602, _29601, _27line_number_20572);
    }
    else if (IS_ATOM(_29601) && IS_SEQUENCE(_27line_number_20572)) {
    }
    else {
        Concat((object_ptr)&_29602, _29601, _27line_number_20572);
        _29601 = NOVALUE;
    }
    _29601 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29602;
    if( _1 != _29602 ){
        DeRef(_1);
    }
    _29602 = NOVALUE;
    _29599 = NOVALUE;

    /** parser.e:2460			switch_stack[$][SWITCH_CURRENT_FILE_NO] &= current_file_no*/
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _29603 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _29603 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55717);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55717 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29603 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29606 = (object)*(((s1_ptr)_2)->base + 13LL);
    _29604 = NOVALUE;
    if (IS_SEQUENCE(_29606) && IS_ATOM(_27current_file_no_20571)) {
        Append(&_29607, _29606, _27current_file_no_20571);
    }
    else if (IS_ATOM(_29606) && IS_SEQUENCE(_27current_file_no_20571)) {
    }
    else {
        Concat((object_ptr)&_29607, _29606, _27current_file_no_20571);
        _29606 = NOVALUE;
    }
    _29606 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 13LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29607;
    if( _1 != _29607 ){
        DeRef(_1);
    }
    _29607 = NOVALUE;
    _29604 = NOVALUE;

    /** parser.e:2462			if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L3; // [217] 262
    }
    else{
    }

    /** parser.e:2463				emit_addr( CASE )*/
    _45emit_addr(186LL);

    /** parser.e:2464				emit_addr( length( switch_stack[$][SWITCH_CASES] ) )*/
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _29608 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _29608 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55717);
    _29609 = (object)*(((s1_ptr)_2)->base + _29608);
    _2 = (object)SEQ_PTR(_29609);
    _29610 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29609 = NOVALUE;
    if (IS_SEQUENCE(_29610)){
            _29611 = SEQ_PTR(_29610)->length;
    }
    else {
        _29611 = 1;
    }
    _29610 = NOVALUE;
    _45emit_addr(_29611);
    _29611 = NOVALUE;
    goto L3; // [249] 262
L2: 

    /** parser.e:2467			CompileErr( DUPLICATE_CASE_VALUE_USED)*/
    RefDS(_22218);
    _49CompileErr(63LL, _22218, 0LL);
L3: 

    /** parser.e:2469	end procedure*/
    DeRef(_sym_59085);
    _29610 = NOVALUE;
    return;
    ;
}


void _43case_else()
{
    object _29619 = NOVALUE;
    object _29618 = NOVALUE;
    object _29616 = NOVALUE;
    object _29615 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2476		switch_stack[$][SWITCH_ELSE] = length(Code) + 1*/
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _29615 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _29615 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55717);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55717 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29615 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_27Code_20660)){
            _29618 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29618 = 1;
    }
    _29619 = _29618 + 1;
    _29618 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29619;
    if( _1 != _29619 ){
        DeRef(_1);
    }
    _29619 = NOVALUE;
    _29616 = NOVALUE;

    /** parser.e:2477		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L1; // [30] 46
    }
    else{
    }

    /** parser.e:2478			emit_addr( CASE )*/
    _45emit_addr(186LL);

    /** parser.e:2479			emit_addr( 0 )*/
    _45emit_addr(0LL);
L1: 

    /** parser.e:2482	end procedure*/
    return;
    ;
}


void _43Case_statement()
{
    object _else_case_2__tmp_at147_59209 = NOVALUE;
    object _else_case_1__tmp_at147_59208 = NOVALUE;
    object _else_case_inlined_else_case_at_147_59207 = NOVALUE;
    object _tok_59170 = NOVALUE;
    object _condition_59172 = NOVALUE;
    object _start_line_59202 = NOVALUE;
    object _sign_59214 = NOVALUE;
    object _fwd_59227 = NOVALUE;
    object _symi_59237 = NOVALUE;
    object _fwdref_59309 = NOVALUE;
    object _32049 = NOVALUE;
    object _29702 = NOVALUE;
    object _29701 = NOVALUE;
    object _29700 = NOVALUE;
    object _29699 = NOVALUE;
    object _29698 = NOVALUE;
    object _29697 = NOVALUE;
    object _29695 = NOVALUE;
    object _29694 = NOVALUE;
    object _29693 = NOVALUE;
    object _29691 = NOVALUE;
    object _29690 = NOVALUE;
    object _29689 = NOVALUE;
    object _29687 = NOVALUE;
    object _29684 = NOVALUE;
    object _29681 = NOVALUE;
    object _29680 = NOVALUE;
    object _29679 = NOVALUE;
    object _29678 = NOVALUE;
    object _29675 = NOVALUE;
    object _29674 = NOVALUE;
    object _29673 = NOVALUE;
    object _29672 = NOVALUE;
    object _29669 = NOVALUE;
    object _29668 = NOVALUE;
    object _29667 = NOVALUE;
    object _29666 = NOVALUE;
    object _29664 = NOVALUE;
    object _29663 = NOVALUE;
    object _29662 = NOVALUE;
    object _29660 = NOVALUE;
    object _29659 = NOVALUE;
    object _29658 = NOVALUE;
    object _29657 = NOVALUE;
    object _29656 = NOVALUE;
    object _29654 = NOVALUE;
    object _29653 = NOVALUE;
    object _29651 = NOVALUE;
    object _29650 = NOVALUE;
    object _29649 = NOVALUE;
    object _29648 = NOVALUE;
    object _29644 = NOVALUE;
    object _29643 = NOVALUE;
    object _29642 = NOVALUE;
    object _29639 = NOVALUE;
    object _29636 = NOVALUE;
    object _29633 = NOVALUE;
    object _29632 = NOVALUE;
    object _29631 = NOVALUE;
    object _29630 = NOVALUE;
    object _29629 = NOVALUE;
    object _29628 = NOVALUE;
    object _29627 = NOVALUE;
    object _29625 = NOVALUE;
    object _29624 = NOVALUE;
    object _29623 = NOVALUE;
    object _29622 = NOVALUE;
    object _29620 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2489		if not in_switch() then*/
    _29620 = _43in_switch();
    if (IS_ATOM_INT(_29620)) {
        if (_29620 != 0){
            DeRef(_29620);
            _29620 = NOVALUE;
            goto L1; // [6] 19
        }
    }
    else {
        if (DBL_PTR(_29620)->dbl != 0.0){
            DeRef(_29620);
            _29620 = NOVALUE;
            goto L1; // [6] 19
        }
    }
    DeRef(_29620);
    _29620 = NOVALUE;

    /** parser.e:2490			CompileErr( A_CASE_MUST_BE_INSIDE_A_SWITCH)*/
    RefDS(_22218);
    _49CompileErr(34LL, _22218, 0LL);
L1: 

    /** parser.e:2493		if length(switch_stack[$][SWITCH_CASES]) > 0 then*/
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _29622 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _29622 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55717);
    _29623 = (object)*(((s1_ptr)_2)->base + _29622);
    _2 = (object)SEQ_PTR(_29623);
    _29624 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29623 = NOVALUE;
    if (IS_SEQUENCE(_29624)){
            _29625 = SEQ_PTR(_29624)->length;
    }
    else {
        _29625 = 1;
    }
    _29624 = NOVALUE;
    if (_29625 <= 0LL)
    goto L2; // [37] 103

    /** parser.e:2495			Sibling_block( CASE )*/
    _64Sibling_block(186LL);

    /** parser.e:2497			if not switch_stack[$][SWITCH_FALLTHRU] and*/
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _29627 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _29627 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55717);
    _29628 = (object)*(((s1_ptr)_2)->base + _29627);
    _2 = (object)SEQ_PTR(_29628);
    _29629 = (object)*(((s1_ptr)_2)->base + 5LL);
    _29628 = NOVALUE;
    if (IS_ATOM_INT(_29629)) {
        _29630 = (_29629 == 0);
    }
    else {
        _29630 = unary_op(NOT, _29629);
    }
    _29629 = NOVALUE;
    if (IS_ATOM_INT(_29630)) {
        if (_29630 == 0) {
            goto L3; // [66] 112
        }
    }
    else {
        if (DBL_PTR(_29630)->dbl == 0.0) {
            goto L3; // [66] 112
        }
    }
    _29632 = (_43fallthru_case_59166 == 0);
    if (_29632 == 0)
    {
        DeRef(_29632);
        _29632 = NOVALUE;
        goto L3; // [76] 112
    }
    else{
        DeRef(_29632);
        _29632 = NOVALUE;
    }

    /** parser.e:2501				putback( {CASE, 0} )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 186LL;
    ((intptr_t *)_2)[2] = 0LL;
    _29633 = MAKE_SEQ(_1);
    _43putback(_29633);
    _29633 = NOVALUE;

    /** parser.e:2502				Break_statement()*/
    _43Break_statement();

    /** parser.e:2503				tok = next_token()*/
    _0 = _tok_59170;
    _tok_59170 = _43next_token();
    DeRef(_0);
    goto L3; // [100] 112
L2: 

    /** parser.e:2506			Start_block( CASE )*/
    _64Start_block(186LL, 0LL);
L3: 

    /** parser.e:2509		StartSourceLine(TRUE, , COVERAGE_SUPPRESS)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 1LL);

    /** parser.e:2511		fallthru_case = 0*/
    _43fallthru_case_59166 = 0LL;

    /** parser.e:2512		integer start_line = line_number*/
    _start_line_59202 = _27line_number_20572;

    /** parser.e:2513		while 1 do*/
L4: 

    /** parser.e:2515			if else_case() then*/

    /** parser.e:2472		return switch_stack[$][SWITCH_ELSE]*/
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _else_case_1__tmp_at147_59208 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _else_case_1__tmp_at147_59208 = 1;
    }
    DeRef(_else_case_2__tmp_at147_59209);
    _2 = (object)SEQ_PTR(_43switch_stack_55717);
    _else_case_2__tmp_at147_59209 = (object)*(((s1_ptr)_2)->base + _else_case_1__tmp_at147_59208);
    RefDS(_else_case_2__tmp_at147_59209);
    DeRef(_else_case_inlined_else_case_at_147_59207);
    _2 = (object)SEQ_PTR(_else_case_2__tmp_at147_59209);
    _else_case_inlined_else_case_at_147_59207 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_else_case_inlined_else_case_at_147_59207);
    DeRef(_else_case_2__tmp_at147_59209);
    _else_case_2__tmp_at147_59209 = NOVALUE;
    if (_else_case_inlined_else_case_at_147_59207 == 0) {
        goto L5; // [162] 175
    }
    else {
        if (!IS_ATOM_INT(_else_case_inlined_else_case_at_147_59207) && DBL_PTR(_else_case_inlined_else_case_at_147_59207)->dbl == 0.0){
            goto L5; // [162] 175
        }
    }

    /** parser.e:2516				CompileErr( A_CASE_BLOCK_CANNOT_FOLLOW_A_CASE_ELSE_BLOCK)*/
    RefDS(_22218);
    _49CompileErr(33LL, _22218, 0LL);
L5: 

    /** parser.e:2518			maybe_namespace()*/
    _61maybe_namespace();

    /** parser.e:2519			tok = next_token()*/
    _0 = _tok_59170;
    _tok_59170 = _43next_token();
    DeRef(_0);

    /** parser.e:2520			integer sign = 1*/
    _sign_59214 = 1LL;

    /** parser.e:2521			if tok[T_ID] = MINUS then*/
    _2 = (object)SEQ_PTR(_tok_59170);
    _29636 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29636, 10LL)){
        _29636 = NOVALUE;
        goto L6; // [199] 216
    }
    _29636 = NOVALUE;

    /** parser.e:2522				sign = -1*/
    _sign_59214 = -1LL;

    /** parser.e:2523				tok = next_token()*/
    _0 = _tok_59170;
    _tok_59170 = _43next_token();
    DeRef(_0);
    goto L7; // [213] 237
L6: 

    /** parser.e:2524			elsif tok[T_ID] = PLUS then*/
    _2 = (object)SEQ_PTR(_tok_59170);
    _29639 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29639, 11LL)){
        _29639 = NOVALUE;
        goto L8; // [226] 236
    }
    _29639 = NOVALUE;

    /** parser.e:2525				tok = next_token()*/
    _0 = _tok_59170;
    _tok_59170 = _43next_token();
    DeRef(_0);
L8: 
L7: 

    /** parser.e:2528			integer fwd*/

    /** parser.e:2529			if not find( tok[T_ID], {ATOM, STRING, ELSE} ) then*/
    _2 = (object)SEQ_PTR(_tok_59170);
    _29642 = (object)*(((s1_ptr)_2)->base + 1LL);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 502LL;
    ((intptr_t*)_2)[2] = 503LL;
    ((intptr_t*)_2)[3] = 23LL;
    _29643 = MAKE_SEQ(_1);
    _29644 = find_from(_29642, _29643, 1LL);
    _29642 = NOVALUE;
    DeRefDS(_29643);
    _29643 = NOVALUE;
    if (_29644 != 0)
    goto L9; // [264] 439
    _29644 = NOVALUE;

    /** parser.e:2531				integer symi = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_59170);
    _symi_59237 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_symi_59237)){
        _symi_59237 = (object)DBL_PTR(_symi_59237)->dbl;
    }

    /** parser.e:2532				fwd = -1*/
    _fwd_59227 = -1LL;

    /** parser.e:2533				if symi > 0 then*/
    if (_symi_59237 <= 0LL)
    goto LA; // [284] 434

    /** parser.e:2534					if find(tok[T_ID] , VAR_TOKS) then*/
    _2 = (object)SEQ_PTR(_tok_59170);
    _29648 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29649 = find_from(_29648, _29VAR_TOKS_12287, 1LL);
    _29648 = NOVALUE;
    if (_29649 == 0)
    {
        _29649 = NOVALUE;
        goto LB; // [303] 433
    }
    else{
        _29649 = NOVALUE;
    }

    /** parser.e:2535						if SymTab[symi][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29650 = (object)*(((s1_ptr)_2)->base + _symi_59237);
    _2 = (object)SEQ_PTR(_29650);
    _29651 = (object)*(((s1_ptr)_2)->base + 4LL);
    _29650 = NOVALUE;
    if (binary_op_a(NOTEQ, _29651, 9LL)){
        _29651 = NOVALUE;
        goto LC; // [322] 334
    }
    _29651 = NOVALUE;

    /** parser.e:2537							fwd = symi*/
    _fwd_59227 = _symi_59237;
    goto LD; // [331] 432
LC: 

    /** parser.e:2538						elsif SymTab[symi][S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29653 = (object)*(((s1_ptr)_2)->base + _symi_59237);
    _2 = (object)SEQ_PTR(_29653);
    _29654 = (object)*(((s1_ptr)_2)->base + 3LL);
    _29653 = NOVALUE;
    if (binary_op_a(NOTEQ, _29654, 2LL)){
        _29654 = NOVALUE;
        goto LE; // [350] 431
    }
    _29654 = NOVALUE;

    /** parser.e:2539							fwd = 0*/
    _fwd_59227 = 0LL;

    /** parser.e:2540							if SymTab[symi][S_CODE] then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29656 = (object)*(((s1_ptr)_2)->base + _symi_59237);
    _2 = (object)SEQ_PTR(_29656);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _29657 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _29657 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    _29656 = NOVALUE;
    if (_29657 == 0) {
        _29657 = NOVALUE;
        goto LF; // [373] 397
    }
    else {
        if (!IS_ATOM_INT(_29657) && DBL_PTR(_29657)->dbl == 0.0){
            _29657 = NOVALUE;
            goto LF; // [373] 397
        }
        _29657 = NOVALUE;
    }
    _29657 = NOVALUE;

    /** parser.e:2541								tok[T_SYM] = SymTab[symi][S_CODE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29658 = (object)*(((s1_ptr)_2)->base + _symi_59237);
    _2 = (object)SEQ_PTR(_29658);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _29659 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _29659 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    _29658 = NOVALUE;
    Ref(_29659);
    _2 = (object)SEQ_PTR(_tok_59170);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_59170 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29659;
    if( _1 != _29659 ){
        DeRef(_1);
    }
    _29659 = NOVALUE;
LF: 

    /** parser.e:2543							SymTab[symi][S_USAGE] = or_bits( SymTab[symi][S_USAGE], U_READ )*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_symi_59237 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29662 = (object)*(((s1_ptr)_2)->base + _symi_59237);
    _2 = (object)SEQ_PTR(_29662);
    _29663 = (object)*(((s1_ptr)_2)->base + 5LL);
    _29662 = NOVALUE;
    if (IS_ATOM_INT(_29663)) {
        {uintptr_t tu;
             tu = (uintptr_t)_29663 | (uintptr_t)1LL;
             _29664 = MAKE_UINT(tu);
        }
    }
    else {
        _29664 = binary_op(OR_BITS, _29663, 1LL);
    }
    _29663 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29664;
    if( _1 != _29664 ){
        DeRef(_1);
    }
    _29664 = NOVALUE;
    _29660 = NOVALUE;
LE: 
LD: 
LB: 
LA: 
    goto L10; // [436] 445
L9: 

    /** parser.e:2548				fwd = 0*/
    _fwd_59227 = 0LL;
L10: 

    /** parser.e:2551			if fwd < 0 then*/
    if (_fwd_59227 >= 0LL)
    goto L11; // [449] 477

    /** parser.e:2552				CompileErr( FOUND_1_BUT_EXPECTED_ELSE_AN_ATOM_STRING_CONSTANT_OR_ENUM, {find_category(tok[T_ID])})*/
    _2 = (object)SEQ_PTR(_tok_59170);
    _29666 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_29666);
    _29667 = _62find_category(_29666);
    _29666 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _29667;
    _29668 = MAKE_SEQ(_1);
    _29667 = NOVALUE;
    _49CompileErr(91LL, _29668, 0LL);
    _29668 = NOVALUE;
L11: 

    /** parser.e:2555			if tok[T_ID] = ELSE then*/
    _2 = (object)SEQ_PTR(_tok_59170);
    _29669 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29669, 23LL)){
        _29669 = NOVALUE;
        goto L12; // [487] 552
    }
    _29669 = NOVALUE;

    /** parser.e:2556				if sign = -1 then*/
    if (_sign_59214 != -1LL)
    goto L13; // [493] 507

    /** parser.e:2557					CompileErr( EXPECTED_AN_ATOM_STRING_OR_A_CONSTANT_ASSIGNED_AN_ATOM_OR_A_STRING)*/
    RefDS(_22218);
    _49CompileErr(71LL, _22218, 0LL);
L13: 

    /** parser.e:2559				if length(switch_stack[$][SWITCH_CASES]) = 0 then*/
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _29672 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _29672 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55717);
    _29673 = (object)*(((s1_ptr)_2)->base + _29672);
    _2 = (object)SEQ_PTR(_29673);
    _29674 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29673 = NOVALUE;
    if (IS_SEQUENCE(_29674)){
            _29675 = SEQ_PTR(_29674)->length;
    }
    else {
        _29675 = 1;
    }
    _29674 = NOVALUE;
    if (_29675 != 0LL)
    goto L14; // [525] 539

    /** parser.e:2560					CompileErr( CASE_ELSE_CANNOT_BE_FIRST_CASE_IN_SWITCH)*/
    RefDS(_22218);
    _49CompileErr(44LL, _22218, 0LL);
L14: 

    /** parser.e:2562				case_else()*/
    _43case_else();

    /** parser.e:2563				exit*/
    goto L15; // [547] 789
    goto L16; // [549] 623
L12: 

    /** parser.e:2565			elsif fwd then*/
    if (_fwd_59227 == 0)
    {
        goto L17; // [554] 606
    }
    else{
    }

    /** parser.e:2566				integer fwdref = new_forward_reference( CASE, fwd )*/
    DeRef(_32049);
    _32049 = 186LL;
    _fwdref_59309 = _42new_forward_reference(186LL, _fwd_59227, 186LL);
    _32049 = NOVALUE;
    if (!IS_ATOM_INT(_fwdref_59309)) {
        _1 = (object)(DBL_PTR(_fwdref_59309)->dbl);
        DeRefDS(_fwdref_59309);
        _fwdref_59309 = _1;
    }

    /** parser.e:2567				add_case( {fwdref}, sign )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _fwdref_59309;
    _29678 = MAKE_SEQ(_1);
    _43add_case(_29678, _sign_59214);
    _29678 = NOVALUE;

    /** parser.e:2568				fwd:set_data( fwdref, switch_stack[$][SWITCH_PC] )*/
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _29679 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _29679 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55717);
    _29680 = (object)*(((s1_ptr)_2)->base + _29679);
    _2 = (object)SEQ_PTR(_29680);
    _29681 = (object)*(((s1_ptr)_2)->base + 4LL);
    _29680 = NOVALUE;
    Ref(_29681);
    _42set_data(_fwdref_59309, _29681);
    _29681 = NOVALUE;
    goto L16; // [603] 623
L17: 

    /** parser.e:2571				condition = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_59170);
    _condition_59172 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_condition_59172)){
        _condition_59172 = (object)DBL_PTR(_condition_59172)->dbl;
    }

    /** parser.e:2572				add_case( condition, sign )*/
    _43add_case(_condition_59172, _sign_59214);
L16: 

    /** parser.e:2575			tok = next_token()*/
    _0 = _tok_59170;
    _tok_59170 = _43next_token();
    DeRef(_0);

    /** parser.e:2576			if tok[T_ID] = THEN then*/
    _2 = (object)SEQ_PTR(_tok_59170);
    _29684 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29684, 410LL)){
        _29684 = NOVALUE;
        goto L18; // [638] 742
    }
    _29684 = NOVALUE;

    /** parser.e:2577				tok = next_token()*/
    _0 = _tok_59170;
    _tok_59170 = _43next_token();
    DeRef(_0);

    /** parser.e:2579				if tok[T_ID] = CASE then*/
    _2 = (object)SEQ_PTR(_tok_59170);
    _29687 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29687, 186LL)){
        _29687 = NOVALUE;
        goto L19; // [657] 727
    }
    _29687 = NOVALUE;

    /** parser.e:2580					if switch_stack[$][SWITCH_FALLTHRU] then*/
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _29689 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _29689 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55717);
    _29690 = (object)*(((s1_ptr)_2)->base + _29689);
    _2 = (object)SEQ_PTR(_29690);
    _29691 = (object)*(((s1_ptr)_2)->base + 5LL);
    _29690 = NOVALUE;
    if (_29691 == 0) {
        _29691 = NOVALUE;
        goto L1A; // [676] 691
    }
    else {
        if (!IS_ATOM_INT(_29691) && DBL_PTR(_29691)->dbl == 0.0){
            _29691 = NOVALUE;
            goto L1A; // [676] 691
        }
        _29691 = NOVALUE;
    }
    _29691 = NOVALUE;

    /** parser.e:2581						start_line = line_number*/
    _start_line_59202 = _27line_number_20572;
    goto L1B; // [688] 782
L1A: 

    /** parser.e:2583						putback( tok )*/
    Ref(_tok_59170);
    _43putback(_tok_59170);

    /** parser.e:2584						Warning(220, empty_case_warning_flag,*/
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _29693 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    Ref(_29693);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _29693;
    ((intptr_t *)_2)[2] = _start_line_59202;
    _29694 = MAKE_SEQ(_1);
    _29693 = NOVALUE;
    _49Warning(220LL, 2048LL, _29694);
    _29694 = NOVALUE;

    /** parser.e:2586						exit*/
    goto L15; // [721] 789
    goto L1B; // [724] 782
L19: 

    /** parser.e:2589					putback( tok )*/
    Ref(_tok_59170);
    _43putback(_tok_59170);

    /** parser.e:2590					exit*/
    goto L15; // [736] 789
    goto L1B; // [739] 782
L18: 

    /** parser.e:2593			elsif tok[T_ID] != COMMA then*/
    _2 = (object)SEQ_PTR(_tok_59170);
    _29695 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _29695, -30LL)){
        _29695 = NOVALUE;
        goto L1C; // [752] 781
    }
    _29695 = NOVALUE;

    /** parser.e:2594				CompileErr(EXPECTED_THEN_OR__NOT_1,{LexName(tok[T_ID])})*/
    _2 = (object)SEQ_PTR(_tok_59170);
    _29697 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_29697);
    RefDS(_26682);
    _29698 = _45LexName(_29697, _26682);
    _29697 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _29698;
    _29699 = MAKE_SEQ(_1);
    _29698 = NOVALUE;
    _49CompileErr(66LL, _29699, 0LL);
    _29699 = NOVALUE;
L1C: 
L1B: 

    /** parser.e:2597		end while*/
    goto L4; // [786] 142
L15: 

    /** parser.e:2598		StartSourceLine( TRUE )*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:2599		emit_temp( switch_stack[$][SWITCH_VALUE], NEW_REFERENCE )*/
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _29700 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _29700 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55717);
    _29701 = (object)*(((s1_ptr)_2)->base + _29700);
    _2 = (object)SEQ_PTR(_29701);
    _29702 = (object)*(((s1_ptr)_2)->base + 6LL);
    _29701 = NOVALUE;
    Ref(_29702);
    _45emit_temp(_29702, 1LL);
    _29702 = NOVALUE;

    /** parser.e:2600		flush_temps()*/
    RefDS(_22218);
    _45flush_temps(_22218);

    /** parser.e:2601	end procedure*/
    DeRef(_tok_59170);
    _29624 = NOVALUE;
    DeRef(_29630);
    _29630 = NOVALUE;
    _29674 = NOVALUE;
    return;
    ;
}


void _43Fallthru_statement()
{
    object _29703 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2604		if not in_switch() then*/
    _29703 = _43in_switch();
    if (IS_ATOM_INT(_29703)) {
        if (_29703 != 0){
            DeRef(_29703);
            _29703 = NOVALUE;
            goto L1; // [6] 19
        }
    }
    else {
        if (DBL_PTR(_29703)->dbl != 0.0){
            DeRef(_29703);
            _29703 = NOVALUE;
            goto L1; // [6] 19
        }
    }
    DeRef(_29703);
    _29703 = NOVALUE;

    /** parser.e:2605			CompileErr( A_FALLTHRU_MUST_BE_INSIDE_A_SWITCH)*/
    RefDS(_22218);
    _49CompileErr(22LL, _22218, 0LL);
L1: 

    /** parser.e:2607		tok_match( CASE )*/
    _43tok_match(186LL, 0LL);

    /** parser.e:2608		fallthru_case = 1*/
    _43fallthru_case_59166 = 1LL;

    /** parser.e:2609		Case_statement()*/
    _43Case_statement();

    /** parser.e:2610	end procedure*/
    return;
    ;
}


void _43update_translator_info(object _sym_59378, object _all_ints_59379, object _has_integer_59380, object _has_atom_59381, object _has_sequence_59382)
{
    object _29728 = NOVALUE;
    object _29726 = NOVALUE;
    object _29724 = NOVALUE;
    object _29722 = NOVALUE;
    object _29720 = NOVALUE;
    object _29719 = NOVALUE;
    object _29717 = NOVALUE;
    object _29715 = NOVALUE;
    object _29714 = NOVALUE;
    object _29713 = NOVALUE;
    object _29712 = NOVALUE;
    object _29711 = NOVALUE;
    object _29709 = NOVALUE;
    object _29707 = NOVALUE;
    object _29705 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2615		SymTab[sym][S_MODE] = M_TEMP    -- override CONSTANT for compile*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_59378 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3LL;
    DeRef(_1);
    _29705 = NOVALUE;

    /** parser.e:2616		SymTab[sym][S_GTYPE] = TYPE_SEQUENCE*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_59378 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 8LL;
    DeRef(_1);
    _29707 = NOVALUE;

    /** parser.e:2617		SymTab[sym][S_SEQ_LEN] = length( SymTab[sym][S_OBJ] )*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_59378 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29711 = (object)*(((s1_ptr)_2)->base + _sym_59378);
    _2 = (object)SEQ_PTR(_29711);
    _29712 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29711 = NOVALUE;
    if (IS_SEQUENCE(_29712)){
            _29713 = SEQ_PTR(_29712)->length;
    }
    else {
        _29713 = 1;
    }
    _29712 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29713;
    if( _1 != _29713 ){
        DeRef(_1);
    }
    _29713 = NOVALUE;
    _29709 = NOVALUE;

    /** parser.e:2619		if SymTab[sym][S_SEQ_LEN] > 0 then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29714 = (object)*(((s1_ptr)_2)->base + _sym_59378);
    _2 = (object)SEQ_PTR(_29714);
    _29715 = (object)*(((s1_ptr)_2)->base + 32LL);
    _29714 = NOVALUE;
    if (binary_op_a(LESSEQ, _29715, 0LL)){
        _29715 = NOVALUE;
        goto L1; // [89] 198
    }
    _29715 = NOVALUE;

    /** parser.e:2620			if all_ints then*/
    if (_all_ints_59379 == 0)
    {
        goto L2; // [95] 118
    }
    else{
    }

    /** parser.e:2621				SymTab[sym][S_SEQ_ELEM] = TYPE_INTEGER*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_59378 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _29717 = NOVALUE;
    goto L3; // [115] 216
L2: 

    /** parser.e:2623			elsif has_atom + has_sequence + has_integer > 1 then*/
    _29719 = _has_atom_59381 + _has_sequence_59382;
    if ((object)((uintptr_t)_29719 + (uintptr_t)HIGH_BITS) >= 0){
        _29719 = NewDouble((eudouble)_29719);
    }
    if (IS_ATOM_INT(_29719)) {
        _29720 = _29719 + _has_integer_59380;
        if ((object)((uintptr_t)_29720 + (uintptr_t)HIGH_BITS) >= 0){
            _29720 = NewDouble((eudouble)_29720);
        }
    }
    else {
        _29720 = NewDouble(DBL_PTR(_29719)->dbl + (eudouble)_has_integer_59380);
    }
    DeRef(_29719);
    _29719 = NOVALUE;
    if (binary_op_a(LESSEQ, _29720, 1LL)){
        DeRef(_29720);
        _29720 = NOVALUE;
        goto L4; // [128] 152
    }
    DeRef(_29720);
    _29720 = NOVALUE;

    /** parser.e:2624				SymTab[sym][S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_59378 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);
    _29722 = NOVALUE;
    goto L3; // [149] 216
L4: 

    /** parser.e:2626			elsif has_atom then*/
    if (_has_atom_59381 == 0)
    {
        goto L5; // [154] 177
    }
    else{
    }

    /** parser.e:2627				SymTab[sym][S_SEQ_ELEM] = TYPE_ATOM*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_59378 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 4LL;
    DeRef(_1);
    _29724 = NOVALUE;
    goto L3; // [174] 216
L5: 

    /** parser.e:2630				SymTab[sym][S_SEQ_ELEM] = TYPE_SEQUENCE*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_59378 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 8LL;
    DeRef(_1);
    _29726 = NOVALUE;
    goto L3; // [195] 216
L1: 

    /** parser.e:2634			SymTab[sym][S_SEQ_ELEM] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_59378 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _29728 = NOVALUE;
L3: 

    /** parser.e:2636	end procedure*/
    _29712 = NOVALUE;
    return;
    ;
}


void _43optimize_switch(object _switch_pc_59443, object _else_bp_59444, object _cases_59445, object _jump_table_59446)
{
    object _values_59447 = NOVALUE;
    object _min_59451 = NOVALUE;
    object _max_59453 = NOVALUE;
    object _all_ints_59455 = NOVALUE;
    object _has_integer_59456 = NOVALUE;
    object _has_atom_59457 = NOVALUE;
    object _has_sequence_59458 = NOVALUE;
    object _has_unassigned_59459 = NOVALUE;
    object _has_fwdref_59460 = NOVALUE;
    object _unique_values_59461 = NOVALUE;
    object _unique_jumps_59463 = NOVALUE;
    object _new_1__tmp_at74_59466 = NOVALUE;
    object _new_inlined_new_at_74_59465 = NOVALUE;
    object _jump_59467 = NOVALUE;
    object _jump_offset_59471 = NOVALUE;
    object _sym_59478 = NOVALUE;
    object _sign_59480 = NOVALUE;
    object _value_i_59493 = NOVALUE;
    object _v_59517 = NOVALUE;
    object _else_target_59603 = NOVALUE;
    object _opcode_59606 = NOVALUE;
    object _delta_59612 = NOVALUE;
    object _switch_table_59622 = NOVALUE;
    object _offset_59625 = NOVALUE;
    object _29842 = NOVALUE;
    object _29841 = NOVALUE;
    object _29840 = NOVALUE;
    object _29839 = NOVALUE;
    object _29837 = NOVALUE;
    object _29835 = NOVALUE;
    object _29832 = NOVALUE;
    object _29831 = NOVALUE;
    object _29830 = NOVALUE;
    object _29829 = NOVALUE;
    object _29828 = NOVALUE;
    object _29827 = NOVALUE;
    object _29826 = NOVALUE;
    object _29823 = NOVALUE;
    object _29822 = NOVALUE;
    object _29821 = NOVALUE;
    object _29820 = NOVALUE;
    object _29819 = NOVALUE;
    object _29818 = NOVALUE;
    object _29814 = NOVALUE;
    object _29813 = NOVALUE;
    object _29811 = NOVALUE;
    object _29810 = NOVALUE;
    object _29809 = NOVALUE;
    object _29808 = NOVALUE;
    object _29807 = NOVALUE;
    object _29806 = NOVALUE;
    object _29805 = NOVALUE;
    object _29804 = NOVALUE;
    object _29803 = NOVALUE;
    object _29802 = NOVALUE;
    object _29800 = NOVALUE;
    object _29799 = NOVALUE;
    object _29795 = NOVALUE;
    object _29793 = NOVALUE;
    object _29792 = NOVALUE;
    object _29791 = NOVALUE;
    object _29789 = NOVALUE;
    object _29786 = NOVALUE;
    object _29785 = NOVALUE;
    object _29784 = NOVALUE;
    object _29782 = NOVALUE;
    object _29781 = NOVALUE;
    object _29780 = NOVALUE;
    object _29778 = NOVALUE;
    object _29777 = NOVALUE;
    object _29776 = NOVALUE;
    object _29774 = NOVALUE;
    object _29773 = NOVALUE;
    object _29772 = NOVALUE;
    object _29770 = NOVALUE;
    object _29767 = NOVALUE;
    object _29766 = NOVALUE;
    object _29765 = NOVALUE;
    object _29764 = NOVALUE;
    object _29763 = NOVALUE;
    object _29762 = NOVALUE;
    object _29761 = NOVALUE;
    object _29760 = NOVALUE;
    object _29759 = NOVALUE;
    object _29758 = NOVALUE;
    object _29757 = NOVALUE;
    object _29756 = NOVALUE;
    object _29753 = NOVALUE;
    object _29752 = NOVALUE;
    object _29751 = NOVALUE;
    object _29749 = NOVALUE;
    object _29748 = NOVALUE;
    object _29746 = NOVALUE;
    object _29745 = NOVALUE;
    object _29744 = NOVALUE;
    object _29740 = NOVALUE;
    object _29739 = NOVALUE;
    object _29738 = NOVALUE;
    object _29736 = NOVALUE;
    object _29735 = NOVALUE;
    object _29731 = NOVALUE;
    object _29730 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2641		sequence values = switch_stack[$][SWITCH_CASES]*/
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _29730 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _29730 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55717);
    _29731 = (object)*(((s1_ptr)_2)->base + _29730);
    DeRef(_values_59447);
    _2 = (object)SEQ_PTR(_29731);
    _values_59447 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_values_59447);
    _29731 = NOVALUE;

    /** parser.e:2642		atom min =  1e+300*/
    RefDS(_29733);
    DeRef(_min_59451);
    _min_59451 = _29733;

    /** parser.e:2643		atom max = -1e+300*/
    RefDS(_29734);
    DeRef(_max_59453);
    _max_59453 = _29734;

    /** parser.e:2644		integer all_ints = 1*/
    _all_ints_59455 = 1LL;

    /** parser.e:2645		integer has_integer    = 0*/
    _has_integer_59456 = 0LL;

    /** parser.e:2646		integer has_atom       = 0*/
    _has_atom_59457 = 0LL;

    /** parser.e:2647		integer has_sequence   = 0*/
    _has_sequence_59458 = 0LL;

    /** parser.e:2648		integer has_unassigned = 0*/
    _has_unassigned_59459 = 0LL;

    /** parser.e:2649		integer has_fwdref     = 0*/
    _has_fwdref_59460 = 0LL;

    /** parser.e:2650		sequence unique_values = {}*/
    RefDS(_22218);
    DeRef(_unique_values_59461);
    _unique_values_59461 = _22218;

    /** parser.e:2651		map unique_jumps = map:new()*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at74_59466;
    _new_1__tmp_at74_59466 = _34new_map_seq(8LL);
    DeRef(_0);
    Ref(_new_1__tmp_at74_59466);
    _0 = _unique_jumps_59463;
    _unique_jumps_59463 = _35malloc(_new_1__tmp_at74_59466, 1LL);
    DeRef(_0);
    DeRef(_new_1__tmp_at74_59466);
    _new_1__tmp_at74_59466 = NOVALUE;

    /** parser.e:2653		sequence jump = switch_stack[$][SWITCH_JUMP_TABLE]*/
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _29735 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _29735 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55717);
    _29736 = (object)*(((s1_ptr)_2)->base + _29735);
    DeRef(_jump_59467);
    _2 = (object)SEQ_PTR(_29736);
    _jump_59467 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_jump_59467);
    _29736 = NOVALUE;

    /** parser.e:2654		integer jump_offset = 0*/
    _jump_offset_59471 = 0LL;

    /** parser.e:2655		for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_59447)){
            _29738 = SEQ_PTR(_values_59447)->length;
    }
    else {
        _29738 = 1;
    }
    {
        object _i_59473;
        _i_59473 = 1LL;
L1: 
        if (_i_59473 > _29738){
            goto L2; // [116] 586
        }

        /** parser.e:2656			if sequence( values[i] ) then*/
        _2 = (object)SEQ_PTR(_values_59447);
        _29739 = (object)*(((s1_ptr)_2)->base + _i_59473);
        _29740 = IS_SEQUENCE(_29739);
        _29739 = NOVALUE;
        if (_29740 == 0)
        {
            _29740 = NOVALUE;
            goto L3; // [132] 145
        }
        else{
            _29740 = NOVALUE;
        }

        /** parser.e:2657				has_fwdref = 1*/
        _has_fwdref_59460 = 1LL;

        /** parser.e:2658				exit*/
        goto L2; // [142] 586
L3: 

        /** parser.e:2660			integer sym = values[i]*/
        _2 = (object)SEQ_PTR(_values_59447);
        _sym_59478 = (object)*(((s1_ptr)_2)->base + _i_59473);
        if (!IS_ATOM_INT(_sym_59478))
        _sym_59478 = (object)DBL_PTR(_sym_59478)->dbl;

        /** parser.e:2661			integer sign*/

        /** parser.e:2663			if sym < 0 then*/
        if (_sym_59478 >= 0LL)
        goto L4; // [155] 174

        /** parser.e:2664				sign = -1*/
        _sign_59480 = -1LL;

        /** parser.e:2665				sym = -sym*/
        _sym_59478 = - _sym_59478;
        goto L5; // [171] 180
L4: 

        /** parser.e:2667				sign = 1*/
        _sign_59480 = 1LL;
L5: 

        /** parser.e:2669			if not equal(SymTab[sym][S_OBJ], NOVALUE) then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _29744 = (object)*(((s1_ptr)_2)->base + _sym_59478);
        _2 = (object)SEQ_PTR(_29744);
        _29745 = (object)*(((s1_ptr)_2)->base + 1LL);
        _29744 = NOVALUE;
        if (_29745 == _27NOVALUE_20426)
        _29746 = 1;
        else if (IS_ATOM_INT(_29745) && IS_ATOM_INT(_27NOVALUE_20426))
        _29746 = 0;
        else
        _29746 = (compare(_29745, _27NOVALUE_20426) == 0);
        _29745 = NOVALUE;
        if (_29746 != 0)
        goto L6; // [200] 565
        _29746 = NOVALUE;

        /** parser.e:2670				object value_i = sign * SymTab[sym][S_OBJ]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _29748 = (object)*(((s1_ptr)_2)->base + _sym_59478);
        _2 = (object)SEQ_PTR(_29748);
        _29749 = (object)*(((s1_ptr)_2)->base + 1LL);
        _29748 = NOVALUE;
        DeRef(_value_i_59493);
        if (IS_ATOM_INT(_29749)) {
            {
                int128_t p128 = (int128_t)_sign_59480 * (int128_t)_29749;
                if( p128 != (int128_t)(_value_i_59493 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                    _value_i_59493 = NewDouble( (eudouble)p128 );
                }
            }
        }
        else {
            _value_i_59493 = binary_op(MULTIPLY, _sign_59480, _29749);
        }
        _29749 = NOVALUE;

        /** parser.e:2671				values[i] = value_i*/
        Ref(_value_i_59493);
        _2 = (object)SEQ_PTR(_values_59447);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _values_59447 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_59473);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _value_i_59493;
        DeRef(_1);

        /** parser.e:2672				if TRANSLATE then*/
        if (_27TRANSLATE_20179 == 0)
        {
            goto L7; // [233] 274
        }
        else{
        }

        /** parser.e:2673					if Code[jump[i]-2] = CASE then*/
        _2 = (object)SEQ_PTR(_jump_59467);
        _29751 = (object)*(((s1_ptr)_2)->base + _i_59473);
        if (IS_ATOM_INT(_29751)) {
            _29752 = _29751 - 2LL;
        }
        else {
            _29752 = binary_op(MINUS, _29751, 2LL);
        }
        _29751 = NOVALUE;
        _2 = (object)SEQ_PTR(_27Code_20660);
        if (!IS_ATOM_INT(_29752)){
            _29753 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29752)->dbl));
        }
        else{
            _29753 = (object)*(((s1_ptr)_2)->base + _29752);
        }
        if (binary_op_a(NOTEQ, _29753, 186LL)){
            _29753 = NOVALUE;
            goto L8; // [254] 267
        }
        _29753 = NOVALUE;

        /** parser.e:2674						jump_offset -=2*/
        _jump_offset_59471 = _jump_offset_59471 - 2LL;
        goto L9; // [264] 273
L8: 

        /** parser.e:2676						jump_offset = 0*/
        _jump_offset_59471 = 0LL;
L9: 
L7: 

        /** parser.e:2680				if find( value_i, map:get( unique_jumps, jump[i] + jump_offset, {}) ) then*/
        _2 = (object)SEQ_PTR(_jump_59467);
        _29756 = (object)*(((s1_ptr)_2)->base + _i_59473);
        if (IS_ATOM_INT(_29756)) {
            _29757 = _29756 + _jump_offset_59471;
            if ((object)((uintptr_t)_29757 + (uintptr_t)HIGH_BITS) >= 0){
                _29757 = NewDouble((eudouble)_29757);
            }
        }
        else {
            _29757 = binary_op(PLUS, _29756, _jump_offset_59471);
        }
        _29756 = NOVALUE;
        Ref(_unique_jumps_59463);
        RefDS(_22218);
        _29758 = _34get(_unique_jumps_59463, _29757, _22218);
        _29757 = NOVALUE;
        _29759 = find_from(_value_i_59493, _29758, 1LL);
        DeRef(_29758);
        _29758 = NOVALUE;
        if (_29759 == 0)
        {
            _29759 = NOVALUE;
            goto LA; // [295] 301
        }
        else{
            _29759 = NOVALUE;
        }
        goto LB; // [298] 560
LA: 

        /** parser.e:2683				elsif find( value_i, unique_values ) then*/
        _29760 = find_from(_value_i_59493, _unique_values_59461, 1LL);
        if (_29760 == 0)
        {
            _29760 = NOVALUE;
            goto LC; // [308] 467
        }
        else{
            _29760 = NOVALUE;
        }

        /** parser.e:2686					object v = ""*/
        RefDS(_22218);
        DeRef(_v_59517);
        _v_59517 = _22218;

        /** parser.e:2687					if length( SymTab[sym] ) > S_NAME and sequence( sym_name( sym ) ) then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _29761 = (object)*(((s1_ptr)_2)->base + _sym_59478);
        if (IS_SEQUENCE(_29761)){
                _29762 = SEQ_PTR(_29761)->length;
        }
        else {
            _29762 = 1;
        }
        _29761 = NOVALUE;
        if (IS_ATOM_INT(_27S_NAME_20209)) {
            _29763 = (_29762 > _27S_NAME_20209);
        }
        else {
            _29763 = binary_op(GREATER, _29762, _27S_NAME_20209);
        }
        _29762 = NOVALUE;
        if (IS_ATOM_INT(_29763)) {
            if (_29763 == 0) {
                goto LD; // [333] 359
            }
        }
        else {
            if (DBL_PTR(_29763)->dbl == 0.0) {
                goto LD; // [333] 359
            }
        }
        _29765 = _53sym_name(_sym_59478);
        _29766 = IS_SEQUENCE(_29765);
        DeRef(_29765);
        _29765 = NOVALUE;
        if (_29766 == 0)
        {
            _29766 = NOVALUE;
            goto LD; // [345] 359
        }
        else{
            _29766 = NOVALUE;
        }

        /** parser.e:2688						v = sym_name( sym ) & " = " */
        _29767 = _53sym_name(_sym_59478);
        if (IS_SEQUENCE(_29767) && IS_ATOM(_29768)) {
        }
        else if (IS_ATOM(_29767) && IS_SEQUENCE(_29768)) {
            Ref(_29767);
            Prepend(&_v_59517, _29768, _29767);
        }
        else {
            Concat((object_ptr)&_v_59517, _29767, _29768);
            DeRef(_29767);
            _29767 = NOVALUE;
        }
        DeRef(_29767);
        _29767 = NOVALUE;
LD: 

        /** parser.e:2691					v &= sprint( value_i )*/
        Ref(_value_i_59493);
        _29770 = _12sprint(_value_i_59493);
        if (IS_SEQUENCE(_v_59517) && IS_ATOM(_29770)) {
            Ref(_29770);
            Append(&_v_59517, _v_59517, _29770);
        }
        else if (IS_ATOM(_v_59517) && IS_SEQUENCE(_29770)) {
            Ref(_v_59517);
            Prepend(&_v_59517, _29770, _v_59517);
        }
        else {
            Concat((object_ptr)&_v_59517, _v_59517, _29770);
        }
        DeRef(_29770);
        _29770 = NOVALUE;

        /** parser.e:2692					ThisLine        = switch_stack[$][SWITCH_THISLINE][i]*/
        if (IS_SEQUENCE(_43switch_stack_55717)){
                _29772 = SEQ_PTR(_43switch_stack_55717)->length;
        }
        else {
            _29772 = 1;
        }
        _2 = (object)SEQ_PTR(_43switch_stack_55717);
        _29773 = (object)*(((s1_ptr)_2)->base + _29772);
        _2 = (object)SEQ_PTR(_29773);
        _29774 = (object)*(((s1_ptr)_2)->base + 10LL);
        _29773 = NOVALUE;
        DeRef(_49ThisLine_49693);
        _2 = (object)SEQ_PTR(_29774);
        _49ThisLine_49693 = (object)*(((s1_ptr)_2)->base + _i_59473);
        Ref(_49ThisLine_49693);
        _29774 = NOVALUE;

        /** parser.e:2693					bp              = switch_stack[$][SWITCH_BP][i]*/
        if (IS_SEQUENCE(_43switch_stack_55717)){
                _29776 = SEQ_PTR(_43switch_stack_55717)->length;
        }
        else {
            _29776 = 1;
        }
        _2 = (object)SEQ_PTR(_43switch_stack_55717);
        _29777 = (object)*(((s1_ptr)_2)->base + _29776);
        _2 = (object)SEQ_PTR(_29777);
        _29778 = (object)*(((s1_ptr)_2)->base + 11LL);
        _29777 = NOVALUE;
        _2 = (object)SEQ_PTR(_29778);
        _49bp_49697 = (object)*(((s1_ptr)_2)->base + _i_59473);
        if (!IS_ATOM_INT(_49bp_49697)){
            _49bp_49697 = (object)DBL_PTR(_49bp_49697)->dbl;
        }
        _29778 = NOVALUE;

        /** parser.e:2694					line_number     = switch_stack[$][SWITCH_LINE_NUMBER][i]*/
        if (IS_SEQUENCE(_43switch_stack_55717)){
                _29780 = SEQ_PTR(_43switch_stack_55717)->length;
        }
        else {
            _29780 = 1;
        }
        _2 = (object)SEQ_PTR(_43switch_stack_55717);
        _29781 = (object)*(((s1_ptr)_2)->base + _29780);
        _2 = (object)SEQ_PTR(_29781);
        _29782 = (object)*(((s1_ptr)_2)->base + 12LL);
        _29781 = NOVALUE;
        _2 = (object)SEQ_PTR(_29782);
        _27line_number_20572 = (object)*(((s1_ptr)_2)->base + _i_59473);
        if (!IS_ATOM_INT(_27line_number_20572)){
            _27line_number_20572 = (object)DBL_PTR(_27line_number_20572)->dbl;
        }
        _29782 = NOVALUE;

        /** parser.e:2695					current_file_no = switch_stack[$][SWITCH_CURRENT_FILE_NO][i]*/
        if (IS_SEQUENCE(_43switch_stack_55717)){
                _29784 = SEQ_PTR(_43switch_stack_55717)->length;
        }
        else {
            _29784 = 1;
        }
        _2 = (object)SEQ_PTR(_43switch_stack_55717);
        _29785 = (object)*(((s1_ptr)_2)->base + _29784);
        _2 = (object)SEQ_PTR(_29785);
        _29786 = (object)*(((s1_ptr)_2)->base + 13LL);
        _29785 = NOVALUE;
        _2 = (object)SEQ_PTR(_29786);
        _27current_file_no_20571 = (object)*(((s1_ptr)_2)->base + _i_59473);
        if (!IS_ATOM_INT(_27current_file_no_20571)){
            _27current_file_no_20571 = (object)DBL_PTR(_27current_file_no_20571)->dbl;
        }
        _29786 = NOVALUE;

        /** parser.e:2697					CompileErr("duplicate case value used in switch: [1]", {v})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_v_59517);
        ((intptr_t*)_2)[1] = _v_59517;
        _29789 = MAKE_SEQ(_1);
        RefDS(_29788);
        _49CompileErr(_29788, _29789, 0LL);
        _29789 = NOVALUE;
        DeRefDS(_v_59517);
        _v_59517 = NOVALUE;
        goto LB; // [464] 560
LC: 

        /** parser.e:2700					unique_values   &= value_i*/
        if (IS_SEQUENCE(_unique_values_59461) && IS_ATOM(_value_i_59493)) {
            Ref(_value_i_59493);
            Append(&_unique_values_59461, _unique_values_59461, _value_i_59493);
        }
        else if (IS_ATOM(_unique_values_59461) && IS_SEQUENCE(_value_i_59493)) {
        }
        else {
            Concat((object_ptr)&_unique_values_59461, _unique_values_59461, _value_i_59493);
        }

        /** parser.e:2701					map:put( unique_jumps, jump[i] + jump_offset, value_i, map:APPEND )*/
        _2 = (object)SEQ_PTR(_jump_59467);
        _29791 = (object)*(((s1_ptr)_2)->base + _i_59473);
        if (IS_ATOM_INT(_29791)) {
            _29792 = _29791 + _jump_offset_59471;
            if ((object)((uintptr_t)_29792 + (uintptr_t)HIGH_BITS) >= 0){
                _29792 = NewDouble((eudouble)_29792);
            }
        }
        else {
            _29792 = binary_op(PLUS, _29791, _jump_offset_59471);
        }
        _29791 = NOVALUE;
        Ref(_unique_jumps_59463);
        Ref(_value_i_59493);
        _34put(_unique_jumps_59463, _29792, _value_i_59493, 6LL, 0LL);
        _29792 = NOVALUE;

        /** parser.e:2703					if not is_integer( value_i ) then*/
        Ref(_value_i_59493);
        _29793 = _27is_integer(_value_i_59493);
        if (IS_ATOM_INT(_29793)) {
            if (_29793 != 0){
                DeRef(_29793);
                _29793 = NOVALUE;
                goto LE; // [496] 529
            }
        }
        else {
            if (DBL_PTR(_29793)->dbl != 0.0){
                DeRef(_29793);
                _29793 = NOVALUE;
                goto LE; // [496] 529
            }
        }
        DeRef(_29793);
        _29793 = NOVALUE;

        /** parser.e:2704						all_ints = 0*/
        _all_ints_59455 = 0LL;

        /** parser.e:2705						if atom( value_i ) then*/
        _29795 = IS_ATOM(_value_i_59493);
        if (_29795 == 0)
        {
            _29795 = NOVALUE;
            goto LF; // [509] 520
        }
        else{
            _29795 = NOVALUE;
        }

        /** parser.e:2706							has_atom = 1*/
        _has_atom_59457 = 1LL;
        goto L10; // [517] 559
LF: 

        /** parser.e:2708							has_sequence = 1*/
        _has_sequence_59458 = 1LL;
        goto L10; // [526] 559
LE: 

        /** parser.e:2711						has_integer = 1*/
        _has_integer_59456 = 1LL;

        /** parser.e:2713						if value_i < min then*/
        if (binary_op_a(GREATEREQ, _value_i_59493, _min_59451)){
            goto L11; // [536] 546
        }

        /** parser.e:2714							min = value_i*/
        Ref(_value_i_59493);
        DeRef(_min_59451);
        _min_59451 = _value_i_59493;
L11: 

        /** parser.e:2717						if value_i > max then*/
        if (binary_op_a(LESSEQ, _value_i_59493, _max_59453)){
            goto L12; // [548] 558
        }

        /** parser.e:2718							max = value_i*/
        Ref(_value_i_59493);
        DeRef(_max_59453);
        _max_59453 = _value_i_59493;
L12: 
L10: 
LB: 
        DeRef(_value_i_59493);
        _value_i_59493 = NOVALUE;
        goto L13; // [562] 577
L6: 

        /** parser.e:2723				has_unassigned = 1*/
        _has_unassigned_59459 = 1LL;

        /** parser.e:2724				exit*/
        goto L2; // [574] 586
L13: 

        /** parser.e:2726		end for*/
        _i_59473 = _i_59473 + 1LL;
        goto L1; // [581] 123
L2: 
        ;
    }

    /** parser.e:2728		if has_unassigned or has_fwdref then*/
    if (_has_unassigned_59459 != 0) {
        goto L14; // [588] 597
    }
    if (_has_fwdref_59460 == 0)
    {
        goto L15; // [593] 615
    }
    else{
    }
L14: 

    /** parser.e:2729			values = switch_stack[$][SWITCH_CASES]*/
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _29799 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _29799 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55717);
    _29800 = (object)*(((s1_ptr)_2)->base + _29799);
    DeRef(_values_59447);
    _2 = (object)SEQ_PTR(_29800);
    _values_59447 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_values_59447);
    _29800 = NOVALUE;
L15: 

    /** parser.e:2732		if switch_stack[$][SWITCH_ELSE] then*/
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _29802 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _29802 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55717);
    _29803 = (object)*(((s1_ptr)_2)->base + _29802);
    _2 = (object)SEQ_PTR(_29803);
    _29804 = (object)*(((s1_ptr)_2)->base + 3LL);
    _29803 = NOVALUE;
    if (_29804 == 0) {
        _29804 = NOVALUE;
        goto L16; // [630] 657
    }
    else {
        if (!IS_ATOM_INT(_29804) && DBL_PTR(_29804)->dbl == 0.0){
            _29804 = NOVALUE;
            goto L16; // [630] 657
        }
        _29804 = NOVALUE;
    }
    _29804 = NOVALUE;

    /** parser.e:2733				Code[else_bp] = switch_stack[$][SWITCH_ELSE]*/
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _29805 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _29805 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55717);
    _29806 = (object)*(((s1_ptr)_2)->base + _29805);
    _2 = (object)SEQ_PTR(_29806);
    _29807 = (object)*(((s1_ptr)_2)->base + 3LL);
    _29806 = NOVALUE;
    Ref(_29807);
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _else_bp_59444);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29807;
    if( _1 != _29807 ){
        DeRef(_1);
    }
    _29807 = NOVALUE;
    goto L17; // [654] 681
L16: 

    /** parser.e:2736			Code[else_bp] = length(Code) + 1 + TRANSLATE*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29808 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29808 = 1;
    }
    _29809 = _29808 + 1;
    _29808 = NOVALUE;
    _29810 = _29809 + _27TRANSLATE_20179;
    _29809 = NOVALUE;
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _else_bp_59444);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29810;
    if( _1 != _29810 ){
        DeRef(_1);
    }
    _29810 = NOVALUE;
L17: 

    /** parser.e:2739		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L18; // [685] 712
    }
    else{
    }

    /** parser.e:2744			SymTab[cases][S_OBJ] &= 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_cases_59445 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29813 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29811 = NOVALUE;
    if (IS_SEQUENCE(_29813) && IS_ATOM(0LL)) {
        Append(&_29814, _29813, 0LL);
    }
    else if (IS_ATOM(_29813) && IS_SEQUENCE(0LL)) {
    }
    else {
        Concat((object_ptr)&_29814, _29813, 0LL);
        _29813 = NOVALUE;
    }
    _29813 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29814;
    if( _1 != _29814 ){
        DeRef(_1);
    }
    _29814 = NOVALUE;
    _29811 = NOVALUE;
L18: 

    /** parser.e:2748		integer else_target = Code[else_bp]*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    _else_target_59603 = (object)*(((s1_ptr)_2)->base + _else_bp_59444);
    if (!IS_ATOM_INT(_else_target_59603)){
        _else_target_59603 = (object)DBL_PTR(_else_target_59603)->dbl;
    }

    /** parser.e:2749		integer opcode = SWITCH*/
    _opcode_59606 = 185LL;

    /** parser.e:2750		if has_unassigned or has_fwdref then*/
    if (_has_unassigned_59459 != 0) {
        goto L19; // [733] 742
    }
    if (_has_fwdref_59460 == 0)
    {
        goto L1A; // [738] 754
    }
    else{
    }
L19: 

    /** parser.e:2751			opcode = SWITCH_RT*/
    _opcode_59606 = 202LL;
    goto L1B; // [751] 907
L1A: 

    /** parser.e:2753		elsif all_ints then*/
    if (_all_ints_59455 == 0)
    {
        goto L1C; // [756] 904
    }
    else{
    }

    /** parser.e:2754			atom delta = max - min*/
    DeRef(_delta_59612);
    if (IS_ATOM_INT(_max_59453) && IS_ATOM_INT(_min_59451)) {
        _delta_59612 = _max_59453 - _min_59451;
        if ((object)((uintptr_t)_delta_59612 +(uintptr_t) HIGH_BITS) >= 0){
            _delta_59612 = NewDouble((eudouble)_delta_59612);
        }
    }
    else {
        if (IS_ATOM_INT(_max_59453)) {
            _delta_59612 = NewDouble((eudouble)_max_59453 - DBL_PTR(_min_59451)->dbl);
        }
        else {
            if (IS_ATOM_INT(_min_59451)) {
                _delta_59612 = NewDouble(DBL_PTR(_max_59453)->dbl - (eudouble)_min_59451);
            }
            else
            _delta_59612 = NewDouble(DBL_PTR(_max_59453)->dbl - DBL_PTR(_min_59451)->dbl);
        }
    }

    /** parser.e:2755			if not TRANSLATE and  delta < 1024 and delta >= 0 then*/
    _29818 = (_27TRANSLATE_20179 == 0);
    if (_29818 == 0) {
        _29819 = 0;
        goto L1D; // [772] 784
    }
    if (IS_ATOM_INT(_delta_59612)) {
        _29820 = (_delta_59612 < 1024LL);
    }
    else {
        _29820 = (DBL_PTR(_delta_59612)->dbl < (eudouble)1024LL);
    }
    _29819 = (_29820 != 0);
L1D: 
    if (_29819 == 0) {
        goto L1E; // [784] 893
    }
    if (IS_ATOM_INT(_delta_59612)) {
        _29822 = (_delta_59612 >= 0LL);
    }
    else {
        _29822 = (DBL_PTR(_delta_59612)->dbl >= (eudouble)0LL);
    }
    if (_29822 == 0)
    {
        DeRef(_29822);
        _29822 = NOVALUE;
        goto L1E; // [793] 893
    }
    else{
        DeRef(_29822);
        _29822 = NOVALUE;
    }

    /** parser.e:2756				opcode = SWITCH_SPI*/
    _opcode_59606 = 192LL;

    /** parser.e:2758				sequence switch_table = repeat( else_target, delta + 1 )*/
    if (IS_ATOM_INT(_delta_59612)) {
        _29823 = _delta_59612 + 1;
    }
    else
    _29823 = binary_op(PLUS, 1, _delta_59612);
    DeRef(_switch_table_59622);
    _switch_table_59622 = Repeat(_else_target_59603, _29823);
    DeRef(_29823);
    _29823 = NOVALUE;

    /** parser.e:2759				integer offset = min - 1*/
    if (IS_ATOM_INT(_min_59451)) {
        _offset_59625 = _min_59451 - 1LL;
    }
    else {
        _offset_59625 = NewDouble(DBL_PTR(_min_59451)->dbl - (eudouble)1LL);
    }
    if (!IS_ATOM_INT(_offset_59625)) {
        _1 = (object)(DBL_PTR(_offset_59625)->dbl);
        DeRefDS(_offset_59625);
        _offset_59625 = _1;
    }

    /** parser.e:2760				for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_59447)){
            _29826 = SEQ_PTR(_values_59447)->length;
    }
    else {
        _29826 = 1;
    }
    {
        object _i_59628;
        _i_59628 = 1LL;
L1F: 
        if (_i_59628 > _29826){
            goto L20; // [828] 860
        }

        /** parser.e:2761					switch_table[values[i] - offset] = jump[i]*/
        _2 = (object)SEQ_PTR(_values_59447);
        _29827 = (object)*(((s1_ptr)_2)->base + _i_59628);
        if (IS_ATOM_INT(_29827)) {
            _29828 = _29827 - _offset_59625;
            if ((object)((uintptr_t)_29828 +(uintptr_t) HIGH_BITS) >= 0){
                _29828 = NewDouble((eudouble)_29828);
            }
        }
        else {
            _29828 = binary_op(MINUS, _29827, _offset_59625);
        }
        _29827 = NOVALUE;
        _2 = (object)SEQ_PTR(_jump_59467);
        _29829 = (object)*(((s1_ptr)_2)->base + _i_59628);
        Ref(_29829);
        _2 = (object)SEQ_PTR(_switch_table_59622);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _switch_table_59622 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_29828))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_29828)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _29828);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _29829;
        if( _1 != _29829 ){
            DeRef(_1);
        }
        _29829 = NOVALUE;

        /** parser.e:2762				end for*/
        _i_59628 = _i_59628 + 1LL;
        goto L1F; // [855] 835
L20: 
        ;
    }

    /** parser.e:2763				Code[switch_pc + 2] = offset*/
    _29830 = _switch_pc_59443 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _29830);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _offset_59625;
    DeRef(_1);

    /** parser.e:2764				switch_stack[$][SWITCH_JUMP_TABLE] = switch_table*/
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _29831 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _29831 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55717);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55717 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29831 + ((s1_ptr)_2)->base);
    RefDS(_switch_table_59622);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _switch_table_59622;
    DeRef(_1);
    _29832 = NOVALUE;
    DeRefDS(_switch_table_59622);
    _switch_table_59622 = NOVALUE;
    goto L21; // [890] 903
L1E: 

    /** parser.e:2766				opcode = SWITCH_I*/
    _opcode_59606 = 193LL;
L21: 
L1C: 
    DeRef(_delta_59612);
    _delta_59612 = NOVALUE;
L1B: 

    /** parser.e:2770		Code[switch_pc] = opcode*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _switch_pc_59443);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _opcode_59606;
    DeRef(_1);

    /** parser.e:2771		if opcode != SWITCH_SPI then*/
    if (_opcode_59606 == 192LL)
    goto L22; // [919] 956

    /** parser.e:2772			SymTab[cases][S_OBJ] = values*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_cases_59445 + ((s1_ptr)_2)->base);
    RefDS(_values_59447);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _values_59447;
    DeRef(_1);
    _29835 = NOVALUE;

    /** parser.e:2773			if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L23; // [942] 955
    }
    else{
    }

    /** parser.e:2774				update_translator_info( cases, all_ints, has_integer, has_atom, has_sequence )*/
    _43update_translator_info(_cases_59445, _all_ints_59455, _has_integer_59456, _has_atom_59457, _has_sequence_59458);
L23: 
L22: 

    /** parser.e:2779		SymTab[jump_table][S_OBJ] = switch_stack[$][SWITCH_JUMP_TABLE] - switch_pc*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_jump_table_59446 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _29839 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _29839 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55717);
    _29840 = (object)*(((s1_ptr)_2)->base + _29839);
    _2 = (object)SEQ_PTR(_29840);
    _29841 = (object)*(((s1_ptr)_2)->base + 2LL);
    _29840 = NOVALUE;
    if (IS_ATOM_INT(_29841)) {
        _29842 = _29841 - _switch_pc_59443;
        if ((object)((uintptr_t)_29842 +(uintptr_t) HIGH_BITS) >= 0){
            _29842 = NewDouble((eudouble)_29842);
        }
    }
    else {
        _29842 = binary_op(MINUS, _29841, _switch_pc_59443);
    }
    _29841 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29842;
    if( _1 != _29842 ){
        DeRef(_1);
    }
    _29842 = NOVALUE;
    _29837 = NOVALUE;

    /** parser.e:2781	end procedure*/
    DeRef(_values_59447);
    DeRef(_min_59451);
    DeRef(_max_59453);
    DeRef(_unique_values_59461);
    DeRef(_unique_jumps_59463);
    DeRef(_jump_59467);
    DeRef(_29820);
    _29820 = NOVALUE;
    DeRef(_29830);
    _29830 = NOVALUE;
    DeRef(_29818);
    _29818 = NOVALUE;
    _29761 = NOVALUE;
    DeRef(_29763);
    _29763 = NOVALUE;
    DeRef(_29752);
    _29752 = NOVALUE;
    DeRef(_29828);
    _29828 = NOVALUE;
    return;
    ;
}


void _43Switch_statement()
{
    object _else_case_2__tmp_at250_59722 = NOVALUE;
    object _else_case_1__tmp_at250_59721 = NOVALUE;
    object _else_case_inlined_else_case_at_250_59720 = NOVALUE;
    object _break_base_59660 = NOVALUE;
    object _cases_59662 = NOVALUE;
    object _jump_table_59663 = NOVALUE;
    object _else_bp_59664 = NOVALUE;
    object _switch_pc_59665 = NOVALUE;
    object _t_59702 = NOVALUE;
    object _29874 = NOVALUE;
    object _29873 = NOVALUE;
    object _29871 = NOVALUE;
    object _29870 = NOVALUE;
    object _29869 = NOVALUE;
    object _29865 = NOVALUE;
    object _29861 = NOVALUE;
    object _29860 = NOVALUE;
    object _29858 = NOVALUE;
    object _29857 = NOVALUE;
    object _29855 = NOVALUE;
    object _29854 = NOVALUE;
    object _29852 = NOVALUE;
    object _29851 = NOVALUE;
    object _29850 = NOVALUE;
    object _29849 = NOVALUE;
    object _29848 = NOVALUE;
    object _29847 = NOVALUE;
    object _29845 = NOVALUE;
    object _29844 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2786		integer else_bp*/

    /** parser.e:2787		integer switch_pc*/

    /** parser.e:2789		push_switch()*/
    _43push_switch();

    /** parser.e:2790		break_base = length(break_list)*/
    if (IS_SEQUENCE(_43break_list_55486)){
            _break_base_59660 = SEQ_PTR(_43break_list_55486)->length;
    }
    else {
        _break_base_59660 = 1;
    }

    /** parser.e:2792		Expr()*/
    _43Expr();

    /** parser.e:2793		switch_stack[$][SWITCH_VALUE] = Top()*/
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _29844 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _29844 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55717);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55717 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29844 + ((s1_ptr)_2)->base);
    _29847 = _45Top();
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29847;
    if( _1 != _29847 ){
        DeRef(_1);
    }
    _29847 = NOVALUE;
    _29845 = NOVALUE;

    /** parser.e:2794		clear_temp( switch_stack[$][SWITCH_VALUE] )*/
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _29848 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _29848 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55717);
    _29849 = (object)*(((s1_ptr)_2)->base + _29848);
    _2 = (object)SEQ_PTR(_29849);
    _29850 = (object)*(((s1_ptr)_2)->base + 6LL);
    _29849 = NOVALUE;
    Ref(_29850);
    _45clear_temp(_29850);
    _29850 = NOVALUE;

    /** parser.e:2796		cases = NewStringSym( {-1, length(SymTab) } )*/
    if (IS_SEQUENCE(_28SymTab_11572)){
            _29851 = SEQ_PTR(_28SymTab_11572)->length;
    }
    else {
        _29851 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1LL;
    ((intptr_t *)_2)[2] = _29851;
    _29852 = MAKE_SEQ(_1);
    _29851 = NOVALUE;
    _cases_59662 = _53NewStringSym(_29852);
    _29852 = NOVALUE;
    if (!IS_ATOM_INT(_cases_59662)) {
        _1 = (object)(DBL_PTR(_cases_59662)->dbl);
        DeRefDS(_cases_59662);
        _cases_59662 = _1;
    }

    /** parser.e:2798		emit_opnd( cases )*/
    _45emit_opnd(_cases_59662);

    /** parser.e:2800		jump_table = NewStringSym( {-2, length(SymTab) } )*/
    if (IS_SEQUENCE(_28SymTab_11572)){
            _29854 = SEQ_PTR(_28SymTab_11572)->length;
    }
    else {
        _29854 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -2LL;
    ((intptr_t *)_2)[2] = _29854;
    _29855 = MAKE_SEQ(_1);
    _29854 = NOVALUE;
    _jump_table_59663 = _53NewStringSym(_29855);
    _29855 = NOVALUE;
    if (!IS_ATOM_INT(_jump_table_59663)) {
        _1 = (object)(DBL_PTR(_jump_table_59663)->dbl);
        DeRefDS(_jump_table_59663);
        _jump_table_59663 = _1;
    }

    /** parser.e:2801		emit_opnd( jump_table )*/
    _45emit_opnd(_jump_table_59663);

    /** parser.e:2803		if finish_block_header(SWITCH) then end if*/
    _29857 = _43finish_block_header(185LL);
    if (_29857 == 0) {
        DeRef(_29857);
        _29857 = NOVALUE;
        goto L1; // [109] 113
    }
    else {
        if (!IS_ATOM_INT(_29857) && DBL_PTR(_29857)->dbl == 0.0){
            DeRef(_29857);
            _29857 = NOVALUE;
            goto L1; // [109] 113
        }
        DeRef(_29857);
        _29857 = NOVALUE;
    }
    DeRef(_29857);
    _29857 = NOVALUE;
L1: 

    /** parser.e:2805		switch_pc = length(Code) + 1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29858 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29858 = 1;
    }
    _switch_pc_59665 = _29858 + 1;
    _29858 = NOVALUE;

    /** parser.e:2806		switch_stack[$][SWITCH_PC] = switch_pc*/
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _29860 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _29860 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55717);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55717 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29860 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _switch_pc_59665;
    DeRef(_1);
    _29861 = NOVALUE;

    /** parser.e:2808		emit_op(SWITCH)*/
    _45emit_op(185LL);

    /** parser.e:2809		emit_forward_addr()  -- the else*/
    _43emit_forward_addr();

    /** parser.e:2810		else_bp = length( Code )*/
    if (IS_SEQUENCE(_27Code_20660)){
            _else_bp_59664 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _else_bp_59664 = 1;
    }

    /** parser.e:2813		t = next_token()*/
    _0 = _t_59702;
    _t_59702 = _43next_token();
    DeRef(_0);

    /** parser.e:2814		if t[T_ID] = CASE then*/
    _2 = (object)SEQ_PTR(_t_59702);
    _29865 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29865, 186LL)){
        _29865 = NOVALUE;
        goto L2; // [173] 188
    }
    _29865 = NOVALUE;

    /** parser.e:2816			Case_statement()*/
    _43Case_statement();

    /** parser.e:2818			Statement_list()*/
    _43Statement_list();
    goto L3; // [185] 194
L2: 

    /** parser.e:2821			putback(t)*/
    Ref(_t_59702);
    _43putback(_t_59702);
L3: 

    /** parser.e:2824		optimize_switch( switch_pc, else_bp, cases, jump_table )*/
    _43optimize_switch(_switch_pc_59665, _else_bp_59664, _cases_59662, _jump_table_59663);

    /** parser.e:2825		tok_match(END)*/
    _43tok_match(402LL, 0LL);

    /** parser.e:2826		tok_match(SWITCH, END)*/
    _43tok_match(185LL, 402LL);

    /** parser.e:2827		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L4; // [224] 235
    }
    else{
    }

    /** parser.e:2828			emit_op(NOPSWITCH)*/
    _45emit_op(187LL);
L4: 

    /** parser.e:2831		if not else_case() then*/

    /** parser.e:2472		return switch_stack[$][SWITCH_ELSE]*/
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _else_case_1__tmp_at250_59721 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _else_case_1__tmp_at250_59721 = 1;
    }
    DeRef(_else_case_2__tmp_at250_59722);
    _2 = (object)SEQ_PTR(_43switch_stack_55717);
    _else_case_2__tmp_at250_59722 = (object)*(((s1_ptr)_2)->base + _else_case_1__tmp_at250_59721);
    RefDS(_else_case_2__tmp_at250_59722);
    DeRef(_else_case_inlined_else_case_at_250_59720);
    _2 = (object)SEQ_PTR(_else_case_2__tmp_at250_59722);
    _else_case_inlined_else_case_at_250_59720 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_else_case_inlined_else_case_at_250_59720);
    DeRef(_else_case_2__tmp_at250_59722);
    _else_case_2__tmp_at250_59722 = NOVALUE;
    if (IS_ATOM_INT(_else_case_inlined_else_case_at_250_59720)) {
        if (_else_case_inlined_else_case_at_250_59720 != 0){
            goto L5; // [255] 327
        }
    }
    else {
        if (DBL_PTR(_else_case_inlined_else_case_at_250_59720)->dbl != 0.0){
            goto L5; // [255] 327
        }
    }

    /** parser.e:2832			if not TRANSLATE then*/
    if (_27TRANSLATE_20179 != 0)
    goto L6; // [262] 303

    /** parser.e:2833				StartSourceLine( TRUE, , COVERAGE_SUPPRESS )*/
    _45StartSourceLine(_9TRUE_441, 0LL, 1LL);

    /** parser.e:2834				emit_temp( switch_stack[$][SWITCH_VALUE], NEW_REFERENCE )*/
    if (IS_SEQUENCE(_43switch_stack_55717)){
            _29869 = SEQ_PTR(_43switch_stack_55717)->length;
    }
    else {
        _29869 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55717);
    _29870 = (object)*(((s1_ptr)_2)->base + _29869);
    _2 = (object)SEQ_PTR(_29870);
    _29871 = (object)*(((s1_ptr)_2)->base + 6LL);
    _29870 = NOVALUE;
    Ref(_29871);
    _45emit_temp(_29871, 1LL);
    _29871 = NOVALUE;

    /** parser.e:2835				flush_temps()*/
    RefDS(_22218);
    _45flush_temps(_22218);
L6: 

    /** parser.e:2838			Warning(221, no_case_else_warning_flag,*/
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _29873 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    Ref(_29873);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _29873;
    ((intptr_t *)_2)[2] = _27line_number_20572;
    _29874 = MAKE_SEQ(_1);
    _29873 = NOVALUE;
    _49Warning(221LL, 4096LL, _29874);
    _29874 = NOVALUE;
L5: 

    /** parser.e:2841		pop_switch( break_base )*/
    _43pop_switch(_break_base_59660);

    /** parser.e:2842	end procedure*/
    DeRef(_t_59702);
    return;
    ;
}


object _43get_private_uninitialized()
{
    object _uninitialized_59746 = NOVALUE;
    object _s_59752 = NOVALUE;
    object _pu_59758 = NOVALUE;
    object _29891 = NOVALUE;
    object _29889 = NOVALUE;
    object _29888 = NOVALUE;
    object _29887 = NOVALUE;
    object _29886 = NOVALUE;
    object _29885 = NOVALUE;
    object _29884 = NOVALUE;
    object _29883 = NOVALUE;
    object _29882 = NOVALUE;
    object _29881 = NOVALUE;
    object _29880 = NOVALUE;
    object _29879 = NOVALUE;
    object _29876 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2845		sequence uninitialized = {}*/
    RefDS(_22218);
    DeRefi(_uninitialized_59746);
    _uninitialized_59746 = _22218;

    /** parser.e:2846		if CurrentSub != TopLevelSub then*/
    if (_27CurrentSub_20579 == _27TopLevelSub_20578)
    goto L1; // [14] 149

    /** parser.e:2847			symtab_pointer s = SymTab[CurrentSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29876 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_29876);
    _s_59752 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_59752)){
        _s_59752 = (object)DBL_PTR(_s_59752)->dbl;
    }
    _29876 = NOVALUE;

    /** parser.e:2848			sequence pu = { SC_PRIVATE, SC_UNDEFINED }*/
    DeRefi(_pu_59758);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 3LL;
    ((intptr_t *)_2)[2] = 9LL;
    _pu_59758 = MAKE_SEQ(_1);

    /** parser.e:2849			while s and find( SymTab[s][S_SCOPE], pu ) do*/
L2: 
    if (_s_59752 == 0) {
        goto L3; // [51] 148
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29880 = (object)*(((s1_ptr)_2)->base + _s_59752);
    _2 = (object)SEQ_PTR(_29880);
    _29881 = (object)*(((s1_ptr)_2)->base + 4LL);
    _29880 = NOVALUE;
    _29882 = find_from(_29881, _pu_59758, 1LL);
    _29881 = NOVALUE;
    if (_29882 == 0)
    {
        _29882 = NOVALUE;
        goto L3; // [73] 148
    }
    else{
        _29882 = NOVALUE;
    }

    /** parser.e:2850				if SymTab[s][S_SCOPE] = SC_PRIVATE and SymTab[s][S_INITLEVEL] = -1 then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29883 = (object)*(((s1_ptr)_2)->base + _s_59752);
    _2 = (object)SEQ_PTR(_29883);
    _29884 = (object)*(((s1_ptr)_2)->base + 4LL);
    _29883 = NOVALUE;
    if (IS_ATOM_INT(_29884)) {
        _29885 = (_29884 == 3LL);
    }
    else {
        _29885 = binary_op(EQUALS, _29884, 3LL);
    }
    _29884 = NOVALUE;
    if (IS_ATOM_INT(_29885)) {
        if (_29885 == 0) {
            goto L4; // [96] 127
        }
    }
    else {
        if (DBL_PTR(_29885)->dbl == 0.0) {
            goto L4; // [96] 127
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29887 = (object)*(((s1_ptr)_2)->base + _s_59752);
    _2 = (object)SEQ_PTR(_29887);
    _29888 = (object)*(((s1_ptr)_2)->base + 14LL);
    _29887 = NOVALUE;
    if (IS_ATOM_INT(_29888)) {
        _29889 = (_29888 == -1LL);
    }
    else {
        _29889 = binary_op(EQUALS, _29888, -1LL);
    }
    _29888 = NOVALUE;
    if (_29889 == 0) {
        DeRef(_29889);
        _29889 = NOVALUE;
        goto L4; // [117] 127
    }
    else {
        if (!IS_ATOM_INT(_29889) && DBL_PTR(_29889)->dbl == 0.0){
            DeRef(_29889);
            _29889 = NOVALUE;
            goto L4; // [117] 127
        }
        DeRef(_29889);
        _29889 = NOVALUE;
    }
    DeRef(_29889);
    _29889 = NOVALUE;

    /** parser.e:2851					uninitialized &= s*/
    Append(&_uninitialized_59746, _uninitialized_59746, _s_59752);
L4: 

    /** parser.e:2853				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29891 = (object)*(((s1_ptr)_2)->base + _s_59752);
    _2 = (object)SEQ_PTR(_29891);
    _s_59752 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_59752)){
        _s_59752 = (object)DBL_PTR(_s_59752)->dbl;
    }
    _29891 = NOVALUE;

    /** parser.e:2854			end while*/
    goto L2; // [145] 51
L3: 
L1: 
    DeRefi(_pu_59758);
    _pu_59758 = NOVALUE;

    /** parser.e:2856		return uninitialized*/
    DeRef(_29885);
    _29885 = NOVALUE;
    return _uninitialized_59746;
    ;
}


void _43While_statement()
{
    object _bp1_59789 = NOVALUE;
    object _bp2_59790 = NOVALUE;
    object _exit_base_59791 = NOVALUE;
    object _next_base_59792 = NOVALUE;
    object _uninitialized_59793 = NOVALUE;
    object _temps_59863 = NOVALUE;
    object _29927 = NOVALUE;
    object _29926 = NOVALUE;
    object _29925 = NOVALUE;
    object _29921 = NOVALUE;
    object _29920 = NOVALUE;
    object _29918 = NOVALUE;
    object _29916 = NOVALUE;
    object _29915 = NOVALUE;
    object _29914 = NOVALUE;
    object _29910 = NOVALUE;
    object _29908 = NOVALUE;
    object _29906 = NOVALUE;
    object _29900 = NOVALUE;
    object _29898 = NOVALUE;
    object _29897 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2865		sequence uninitialized = get_private_uninitialized()*/
    _0 = _uninitialized_59793;
    _uninitialized_59793 = _43get_private_uninitialized();
    DeRef(_0);

    /** parser.e:2867		entry_stack = append( entry_stack, uninitialized )*/
    RefDS(_uninitialized_59793);
    Append(&_43entry_stack_55495, _43entry_stack_55495, _uninitialized_59793);

    /** parser.e:2869		Start_block( WHILE )*/
    _64Start_block(47LL, 0LL);

    /** parser.e:2871		exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_43exit_list_55488)){
            _exit_base_59791 = SEQ_PTR(_43exit_list_55488)->length;
    }
    else {
        _exit_base_59791 = 1;
    }

    /** parser.e:2872		next_base = length(continue_list)*/
    if (IS_SEQUENCE(_43continue_list_55490)){
            _next_base_59792 = SEQ_PTR(_43continue_list_55490)->length;
    }
    else {
        _next_base_59792 = 1;
    }

    /** parser.e:2873		entry_addr &= length(Code)+1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29897 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29897 = 1;
    }
    _29898 = _29897 + 1;
    _29897 = NOVALUE;
    Append(&_43entry_addr_55492, _43entry_addr_55492, _29898);
    _29898 = NOVALUE;

    /** parser.e:2874		emit_op(NOP2) -- Entry_statement may patch this later*/
    _45emit_op(110LL);

    /** parser.e:2875		emit_addr(0)*/
    _45emit_addr(0LL);

    /** parser.e:2876		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L1; // [71] 82
    }
    else{
    }

    /** parser.e:2877			emit_op(NOPWHILE)*/
    _45emit_op(158LL);
L1: 

    /** parser.e:2879		bp1 = length(Code)+1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29900 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29900 = 1;
    }
    _bp1_59789 = _29900 + 1;
    _29900 = NOVALUE;

    /** parser.e:2880		continue_addr &= bp1*/
    Append(&_43continue_addr_55493, _43continue_addr_55493, _bp1_59789);

    /** parser.e:2881		short_circuit += 1*/
    _43short_circuit_55468 = _43short_circuit_55468 + 1;

    /** parser.e:2882		short_circuit_B = FALSE*/
    _43short_circuit_B_55470 = _9FALSE_439;

    /** parser.e:2883		SC1_type = 0*/
    _43SC1_type_55473 = 0LL;

    /** parser.e:2884		Expr()*/
    _43Expr();

    /** parser.e:2885		optimized_while = FALSE*/
    _45optimized_while_51475 = _9FALSE_439;

    /** parser.e:2886		emit_op(WHILE)*/
    _45emit_op(47LL);

    /** parser.e:2887		short_circuit -= 1*/
    _43short_circuit_55468 = _43short_circuit_55468 - 1LL;

    /** parser.e:2888		if not optimized_while then*/
    if (_45optimized_while_51475 != 0)
    goto L2; // [153] 174

    /** parser.e:2890			bp2 = length(Code)+1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29906 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29906 = 1;
    }
    _bp2_59790 = _29906 + 1;
    _29906 = NOVALUE;

    /** parser.e:2891			emit_forward_addr() -- will be patched*/
    _43emit_forward_addr();
    goto L3; // [171] 180
L2: 

    /** parser.e:2893			bp2 = 0*/
    _bp2_59790 = 0LL;
L3: 

    /** parser.e:2895		if finish_block_header(WHILE)=0 then*/
    _29908 = _43finish_block_header(47LL);
    if (binary_op_a(NOTEQ, _29908, 0LL)){
        DeRef(_29908);
        _29908 = NOVALUE;
        goto L4; // [188] 204
    }
    DeRef(_29908);
    _29908 = NOVALUE;

    /** parser.e:2896			entry_addr[$]=-1*/
    if (IS_SEQUENCE(_43entry_addr_55492)){
            _29910 = SEQ_PTR(_43entry_addr_55492)->length;
    }
    else {
        _29910 = 1;
    }
    _2 = (object)SEQ_PTR(_43entry_addr_55492);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43entry_addr_55492 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _29910);
    *(intptr_t *)_2 = -1LL;
L4: 

    /** parser.e:2899		loop_stack &= WHILE*/
    Append(&_43loop_stack_55502, _43loop_stack_55502, 47LL);

    /** parser.e:2901		exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_43exit_list_55488)){
            _exit_base_59791 = SEQ_PTR(_43exit_list_55488)->length;
    }
    else {
        _exit_base_59791 = 1;
    }

    /** parser.e:2902		if SC1_type = OR then*/
    if (_43SC1_type_55473 != 9LL)
    goto L5; // [227] 280

    /** parser.e:2903			backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29914 = _43SC1_patch_55472 - 3LL;
    if ((object)((uintptr_t)_29914 +(uintptr_t) HIGH_BITS) >= 0){
        _29914 = NewDouble((eudouble)_29914);
    }
    _45backpatch(_29914, 147LL);
    _29914 = NOVALUE;

    /** parser.e:2904			if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L6; // [249] 260
    }
    else{
    }

    /** parser.e:2905				emit_op(NOP1)*/
    _45emit_op(159LL);
L6: 

    /** parser.e:2907			backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29915 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29915 = 1;
    }
    _29916 = _29915 + 1;
    _29915 = NOVALUE;
    _45backpatch(_43SC1_patch_55472, _29916);
    _29916 = NOVALUE;
    goto L7; // [277] 331
L5: 

    /** parser.e:2908		elsif SC1_type = AND then*/
    if (_43SC1_type_55473 != 8LL)
    goto L8; // [286] 330

    /** parser.e:2909			backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29918 = _43SC1_patch_55472 - 3LL;
    if ((object)((uintptr_t)_29918 +(uintptr_t) HIGH_BITS) >= 0){
        _29918 = NewDouble((eudouble)_29918);
    }
    _45backpatch(_29918, 146LL);
    _29918 = NOVALUE;

    /** parser.e:2910			AppendXList(SC1_patch)*/

    /** parser.e:398		exit_list = append(exit_list, addr)*/
    Append(&_43exit_list_55488, _43exit_list_55488, _43SC1_patch_55472);

    /** parser.e:399	end procedure*/
    goto L9; // [318] 321
L9: 

    /** parser.e:2911			exit_delay &= 1*/
    Append(&_43exit_delay_55489, _43exit_delay_55489, 1LL);
L8: 
L7: 

    /** parser.e:2913		retry_addr &= length(Code)+1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29920 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29920 = 1;
    }
    _29921 = _29920 + 1;
    _29920 = NOVALUE;
    Append(&_43retry_addr_55494, _43retry_addr_55494, _29921);
    _29921 = NOVALUE;

    /** parser.e:2915		sequence temps = pop_temps()*/
    _0 = _temps_59863;
    _temps_59863 = _45pop_temps();
    DeRef(_0);

    /** parser.e:2917		push_temps( temps )*/
    RefDS(_temps_59863);
    _45push_temps(_temps_59863);

    /** parser.e:2919		Statement_list()*/
    _43Statement_list();

    /** parser.e:2920		PatchNList(next_base)*/
    _43PatchNList(_next_base_59792);

    /** parser.e:2921		tok_match(END)*/
    _43tok_match(402LL, 0LL);

    /** parser.e:2922		tok_match(WHILE, END)*/
    _43tok_match(47LL, 402LL);

    /** parser.e:2924		End_block( WHILE )*/
    _64End_block(47LL);

    /** parser.e:2926		StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:2927		emit_op(ENDWHILE)*/
    _45emit_op(22LL);

    /** parser.e:2928		emit_addr(bp1)*/
    _45emit_addr(_bp1_59789);

    /** parser.e:2929		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto LA; // [419] 430
    }
    else{
    }

    /** parser.e:2930			emit_op(NOP1)*/
    _45emit_op(159LL);
LA: 

    /** parser.e:2932		if bp2 != 0 then*/
    if (_bp2_59790 == 0LL)
    goto LB; // [434] 454

    /** parser.e:2933			backpatch(bp2, length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29925 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29925 = 1;
    }
    _29926 = _29925 + 1;
    _29925 = NOVALUE;
    _45backpatch(_bp2_59790, _29926);
    _29926 = NOVALUE;
LB: 

    /** parser.e:2935		exit_loop(exit_base)*/
    _43exit_loop(_exit_base_59791);

    /** parser.e:2936		entry_stack = remove( entry_stack, length( entry_stack ) )*/
    if (IS_SEQUENCE(_43entry_stack_55495)){
            _29927 = SEQ_PTR(_43entry_stack_55495)->length;
    }
    else {
        _29927 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_43entry_stack_55495);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_29927)) ? _29927 : (object)(DBL_PTR(_29927)->dbl);
        int stop = (IS_ATOM_INT(_29927)) ? _29927 : (object)(DBL_PTR(_29927)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_43entry_stack_55495), start, &_43entry_stack_55495 );
            }
            else Tail(SEQ_PTR(_43entry_stack_55495), stop+1, &_43entry_stack_55495);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_43entry_stack_55495), start, &_43entry_stack_55495);
        }
        else {
            assign_slice_seq = &assign_space;
            _43entry_stack_55495 = Remove_elements(start, stop, (SEQ_PTR(_43entry_stack_55495)->ref == 1));
        }
    }
    _29927 = NOVALUE;
    _29927 = NOVALUE;

    /** parser.e:2937		push_temps( temps )*/
    RefDS(_temps_59863);
    _45push_temps(_temps_59863);

    /** parser.e:2938	end procedure*/
    DeRef(_uninitialized_59793);
    DeRefDS(_temps_59863);
    return;
    ;
}


void _43Loop_statement()
{
    object _bp1_59893 = NOVALUE;
    object _exit_base_59894 = NOVALUE;
    object _next_base_59895 = NOVALUE;
    object _t_59897 = NOVALUE;
    object _uninitialized_59900 = NOVALUE;
    object _29951 = NOVALUE;
    object _29949 = NOVALUE;
    object _29948 = NOVALUE;
    object _29947 = NOVALUE;
    object _29941 = NOVALUE;
    object _29940 = NOVALUE;
    object _29938 = NOVALUE;
    object _29935 = NOVALUE;
    object _29934 = NOVALUE;
    object _29933 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2946		Start_block( LOOP )*/
    _64Start_block(422LL, 0LL);

    /** parser.e:2948		sequence uninitialized = get_private_uninitialized()*/
    _0 = _uninitialized_59900;
    _uninitialized_59900 = _43get_private_uninitialized();
    DeRef(_0);

    /** parser.e:2949		entry_stack = append( entry_stack, uninitialized )*/
    RefDS(_uninitialized_59900);
    Append(&_43entry_stack_55495, _43entry_stack_55495, _uninitialized_59900);

    /** parser.e:2951		exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_43exit_list_55488)){
            _exit_base_59894 = SEQ_PTR(_43exit_list_55488)->length;
    }
    else {
        _exit_base_59894 = 1;
    }

    /** parser.e:2952		next_base = length(continue_list)*/
    if (IS_SEQUENCE(_43continue_list_55490)){
            _next_base_59895 = SEQ_PTR(_43continue_list_55490)->length;
    }
    else {
        _next_base_59895 = 1;
    }

    /** parser.e:2953		emit_op(NOP2) -- Entry_statement() may patch this*/
    _45emit_op(110LL);

    /** parser.e:2954		emit_addr(0)*/
    _45emit_addr(0LL);

    /** parser.e:2955		if finish_block_header(LOOP) then*/
    _29933 = _43finish_block_header(422LL);
    if (_29933 == 0) {
        DeRef(_29933);
        _29933 = NOVALUE;
        goto L1; // [58] 81
    }
    else {
        if (!IS_ATOM_INT(_29933) && DBL_PTR(_29933)->dbl == 0.0){
            DeRef(_29933);
            _29933 = NOVALUE;
            goto L1; // [58] 81
        }
        DeRef(_29933);
        _29933 = NOVALUE;
    }
    DeRef(_29933);
    _29933 = NOVALUE;

    /** parser.e:2956		    entry_addr &= length(Code)-1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29934 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29934 = 1;
    }
    _29935 = _29934 - 1LL;
    _29934 = NOVALUE;
    Append(&_43entry_addr_55492, _43entry_addr_55492, _29935);
    _29935 = NOVALUE;
    goto L2; // [78] 90
L1: 

    /** parser.e:2958			entry_addr &= -1*/
    Append(&_43entry_addr_55492, _43entry_addr_55492, -1LL);
L2: 

    /** parser.e:2962		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L3; // [94] 105
    }
    else{
    }

    /** parser.e:2963			emit_op(NOP1)*/
    _45emit_op(159LL);
L3: 

    /** parser.e:2965		bp1 = length(Code)+1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29938 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29938 = 1;
    }
    _bp1_59893 = _29938 + 1;
    _29938 = NOVALUE;

    /** parser.e:2966		retry_addr &= length(Code)+1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29940 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29940 = 1;
    }
    _29941 = _29940 + 1;
    _29940 = NOVALUE;
    Append(&_43retry_addr_55494, _43retry_addr_55494, _29941);
    _29941 = NOVALUE;

    /** parser.e:2967		continue_addr &= 0*/
    Append(&_43continue_addr_55493, _43continue_addr_55493, 0LL);

    /** parser.e:2968		loop_stack &= LOOP*/
    Append(&_43loop_stack_55502, _43loop_stack_55502, 422LL);

    /** parser.e:2970		Statement_list()*/
    _43Statement_list();

    /** parser.e:2972		End_block( LOOP )*/
    _64End_block(422LL);

    /** parser.e:2974		tok_match(UNTIL)*/
    _43tok_match(423LL, 0LL);

    /** parser.e:2975		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L4; // [174] 185
    }
    else{
    }

    /** parser.e:2976			emit_op(NOP1)*/
    _45emit_op(159LL);
L4: 

    /** parser.e:2978		PatchNList(next_base)*/
    _43PatchNList(_next_base_59895);

    /** parser.e:2979		StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:2980		short_circuit += 1*/
    _43short_circuit_55468 = _43short_circuit_55468 + 1;

    /** parser.e:2981		short_circuit_B = FALSE*/
    _43short_circuit_B_55470 = _9FALSE_439;

    /** parser.e:2982		SC1_type = 0*/
    _43SC1_type_55473 = 0LL;

    /** parser.e:2983		Expr()*/
    _43Expr();

    /** parser.e:2984		if SC1_type = OR then*/
    if (_43SC1_type_55473 != 9LL)
    goto L5; // [229] 282

    /** parser.e:2985			backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29947 = _43SC1_patch_55472 - 3LL;
    if ((object)((uintptr_t)_29947 +(uintptr_t) HIGH_BITS) >= 0){
        _29947 = NewDouble((eudouble)_29947);
    }
    _45backpatch(_29947, 147LL);
    _29947 = NOVALUE;

    /** parser.e:2986			if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L6; // [251] 262
    }
    else{
    }

    /** parser.e:2987			    emit_op(NOP1)  -- to get label here*/
    _45emit_op(159LL);
L6: 

    /** parser.e:2989			backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29948 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29948 = 1;
    }
    _29949 = _29948 + 1;
    _29948 = NOVALUE;
    _45backpatch(_43SC1_patch_55472, _29949);
    _29949 = NOVALUE;
    goto L7; // [279] 308
L5: 

    /** parser.e:2990		elsif SC1_type = AND then*/
    if (_43SC1_type_55473 != 8LL)
    goto L8; // [288] 307

    /** parser.e:2991			backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29951 = _43SC1_patch_55472 - 3LL;
    if ((object)((uintptr_t)_29951 +(uintptr_t) HIGH_BITS) >= 0){
        _29951 = NewDouble((eudouble)_29951);
    }
    _45backpatch(_29951, 146LL);
    _29951 = NOVALUE;
L8: 
L7: 

    /** parser.e:2993		short_circuit -= 1*/
    _43short_circuit_55468 = _43short_circuit_55468 - 1LL;

    /** parser.e:2994		emit_op(IF)*/
    _45emit_op(20LL);

    /** parser.e:2995		emit_addr(bp1)*/
    _45emit_addr(_bp1_59893);

    /** parser.e:2996		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L9; // [332] 343
    }
    else{
    }

    /** parser.e:2997			emit_op(NOP1)*/
    _45emit_op(159LL);
L9: 

    /** parser.e:2999		exit_loop(exit_base)*/
    _43exit_loop(_exit_base_59894);

    /** parser.e:3001		tok_match(END)*/
    _43tok_match(402LL, 0LL);

    /** parser.e:3002		tok_match(LOOP, END)*/
    _43tok_match(422LL, 402LL);

    /** parser.e:3004	end procedure*/
    DeRef(_uninitialized_59900);
    return;
    ;
}


void _43Ifdef_statement()
{
    object _option_59979 = NOVALUE;
    object _matched_59980 = NOVALUE;
    object _has_matched_59981 = NOVALUE;
    object _in_matched_59982 = NOVALUE;
    object _dead_ifdef_59983 = NOVALUE;
    object _in_elsedef_59984 = NOVALUE;
    object _tok_59986 = NOVALUE;
    object _keyw_59987 = NOVALUE;
    object _parser_id_59991 = NOVALUE;
    object _negate_60007 = NOVALUE;
    object _conjunction_60008 = NOVALUE;
    object _at_start_60009 = NOVALUE;
    object _prev_conj_60010 = NOVALUE;
    object _this_matched_60095 = NOVALUE;
    object _gotword_60111 = NOVALUE;
    object _gotthen_60112 = NOVALUE;
    object _if_lvl_60113 = NOVALUE;
    object _30068 = NOVALUE;
    object _30067 = NOVALUE;
    object _30063 = NOVALUE;
    object _30061 = NOVALUE;
    object _30058 = NOVALUE;
    object _30056 = NOVALUE;
    object _30055 = NOVALUE;
    object _30051 = NOVALUE;
    object _30048 = NOVALUE;
    object _30045 = NOVALUE;
    object _30041 = NOVALUE;
    object _30039 = NOVALUE;
    object _30038 = NOVALUE;
    object _30037 = NOVALUE;
    object _30036 = NOVALUE;
    object _30035 = NOVALUE;
    object _30034 = NOVALUE;
    object _30033 = NOVALUE;
    object _30029 = NOVALUE;
    object _30026 = NOVALUE;
    object _30025 = NOVALUE;
    object _30024 = NOVALUE;
    object _30020 = NOVALUE;
    object _30019 = NOVALUE;
    object _30018 = NOVALUE;
    object _30015 = NOVALUE;
    object _30012 = NOVALUE;
    object _30011 = NOVALUE;
    object _30010 = NOVALUE;
    object _30008 = NOVALUE;
    object _29997 = NOVALUE;
    object _29995 = NOVALUE;
    object _29994 = NOVALUE;
    object _29993 = NOVALUE;
    object _29992 = NOVALUE;
    object _29991 = NOVALUE;
    object _29990 = NOVALUE;
    object _29989 = NOVALUE;
    object _29986 = NOVALUE;
    object _29985 = NOVALUE;
    object _29983 = NOVALUE;
    object _29981 = NOVALUE;
    object _29980 = NOVALUE;
    object _29978 = NOVALUE;
    object _29976 = NOVALUE;
    object _29975 = NOVALUE;
    object _29973 = NOVALUE;
    object _29972 = NOVALUE;
    object _29971 = NOVALUE;
    object _29968 = NOVALUE;
    object _29966 = NOVALUE;
    object _29963 = NOVALUE;
    object _29962 = NOVALUE;
    object _29961 = NOVALUE;
    object _29959 = NOVALUE;
    object _29957 = NOVALUE;
    object _29956 = NOVALUE;
    object _29955 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:3012		integer matched = 0, has_matched = 0,  in_matched = 0, dead_ifdef = 0, in_elsedef = 0*/
    _matched_59980 = 0LL;
    _has_matched_59981 = 0LL;
    _in_matched_59982 = 0LL;
    _dead_ifdef_59983 = 0LL;
    _in_elsedef_59984 = 0LL;

    /** parser.e:3014		sequence keyw ="ifdef"*/
    RefDS(_26558);
    DeRefi(_keyw_59987);
    _keyw_59987 = _26558;

    /** parser.e:3016		live_ifdef += 1*/
    _43live_ifdef_59975 = _43live_ifdef_59975 + 1;

    /** parser.e:3017		ifdef_lineno &= line_number*/
    Append(&_43ifdef_lineno_59976, _43ifdef_lineno_59976, _27line_number_20572);

    /** parser.e:3019		integer parser_id*/

    /** parser.e:3020		if CurrentSub != TopLevelSub or length(if_labels) or length(loop_labels) then*/
    _29955 = (_27CurrentSub_20579 != _27TopLevelSub_20578);
    if (_29955 != 0) {
        _29956 = 1;
        goto L1; // [55] 68
    }
    if (IS_SEQUENCE(_43if_labels_55497)){
            _29957 = SEQ_PTR(_43if_labels_55497)->length;
    }
    else {
        _29957 = 1;
    }
    _29956 = (_29957 != 0);
L1: 
    if (_29956 != 0) {
        goto L2; // [68] 82
    }
    if (IS_SEQUENCE(_43loop_labels_55496)){
            _29959 = SEQ_PTR(_43loop_labels_55496)->length;
    }
    else {
        _29959 = 1;
    }
    if (_29959 == 0)
    {
        _29959 = NOVALUE;
        goto L3; // [78] 92
    }
    else{
        _29959 = NOVALUE;
    }
L2: 

    /** parser.e:3021			parser_id = forward_Statement_list*/
    _parser_id_59991 = _43forward_Statement_list_58715;
    goto L4; // [89] 100
L3: 

    /** parser.e:3023			parser_id = top_level_parser*/
    _parser_id_59991 = _43top_level_parser_59974;
L4: 

    /** parser.e:3026		while 1 label "top" do*/
L5: 

    /** parser.e:3027			if matched = 0 and in_elsedef = 0 then*/
    _29961 = (_matched_59980 == 0LL);
    if (_29961 == 0) {
        goto L6; // [111] 656
    }
    _29963 = (_in_elsedef_59984 == 0LL);
    if (_29963 == 0)
    {
        DeRef(_29963);
        _29963 = NOVALUE;
        goto L6; // [120] 656
    }
    else{
        DeRef(_29963);
        _29963 = NOVALUE;
    }

    /** parser.e:3028				integer negate = 0, conjunction = 0*/
    _negate_60007 = 0LL;
    _conjunction_60008 = 0LL;

    /** parser.e:3029				integer at_start = 1*/
    _at_start_60009 = 1LL;

    /** parser.e:3030				sequence prev_conj = ""*/
    RefDS(_22218);
    DeRef(_prev_conj_60010);
    _prev_conj_60010 = _22218;

    /** parser.e:3032				while 1 label "deflist" do*/
L7: 

    /** parser.e:3033					option = StringToken()*/
    RefDS(_5);
    _0 = _option_59979;
    _option_59979 = _61StringToken(_5);
    DeRef(_0);

    /** parser.e:3034					if equal(option, "then") then*/
    if (_option_59979 == _26625)
    _29966 = 1;
    else if (IS_ATOM_INT(_option_59979) && IS_ATOM_INT(_26625))
    _29966 = 0;
    else
    _29966 = (compare(_option_59979, _26625) == 0);
    if (_29966 == 0)
    {
        _29966 = NOVALUE;
        goto L8; // [162] 240
    }
    else{
        _29966 = NOVALUE;
    }

    /** parser.e:3035						if at_start = 1 then*/
    if (_at_start_60009 != 1LL)
    goto L9; // [167] 187

    /** parser.e:3036							CompileErr(MSG_1_IS_MISSING_DEFINED_WORD_BEFORE_THEN, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59987);
    ((intptr_t*)_2)[1] = _keyw_59987;
    _29968 = MAKE_SEQ(_1);
    _49CompileErr(6LL, _29968, 0LL);
    _29968 = NOVALUE;
    goto LA; // [184] 542
L9: 

    /** parser.e:3037						elsif conjunction = 0 then*/
    if (_conjunction_60008 != 0LL)
    goto LB; // [189] 223

    /** parser.e:3038							if negate = 0 then*/
    if (_negate_60007 != 0LL)
    goto LC; // [195] 206

    /** parser.e:3039								exit "deflist"*/
    goto LD; // [201] 630
    goto LA; // [203] 542
LC: 

    /** parser.e:3041								CompileErr(MSG_1_THEN_FOLLOWS_NOT, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59987);
    ((intptr_t*)_2)[1] = _keyw_59987;
    _29971 = MAKE_SEQ(_1);
    _49CompileErr(11LL, _29971, 0LL);
    _29971 = NOVALUE;
    goto LA; // [220] 542
LB: 

    /** parser.e:3044							CompileErr(MSG_1_THEN_FOLLOWS_2, {keyw, prev_conj})*/
    RefDS(_prev_conj_60010);
    RefDS(_keyw_59987);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _keyw_59987;
    ((intptr_t *)_2)[2] = _prev_conj_60010;
    _29972 = MAKE_SEQ(_1);
    _49CompileErr(8LL, _29972, 0LL);
    _29972 = NOVALUE;
    goto LA; // [237] 542
L8: 

    /** parser.e:3046					elsif equal(option, "not") then*/
    if (_option_59979 == _26586)
    _29973 = 1;
    else if (IS_ATOM_INT(_option_59979) && IS_ATOM_INT(_26586))
    _29973 = 0;
    else
    _29973 = (compare(_option_59979, _26586) == 0);
    if (_29973 == 0)
    {
        _29973 = NOVALUE;
        goto LE; // [246] 284
    }
    else{
        _29973 = NOVALUE;
    }

    /** parser.e:3047						if negate = 0 then*/
    if (_negate_60007 != 0LL)
    goto LF; // [251] 267

    /** parser.e:3048							negate = 1*/
    _negate_60007 = 1LL;

    /** parser.e:3049							continue "deflist"*/
    goto L7; // [262] 148
    goto LA; // [264] 542
LF: 

    /** parser.e:3051							CompileErr(MSG_1_DUPLICATE_NOT, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59987);
    ((intptr_t*)_2)[1] = _keyw_59987;
    _29975 = MAKE_SEQ(_1);
    _49CompileErr(7LL, _29975, 0LL);
    _29975 = NOVALUE;
    goto LA; // [281] 542
LE: 

    /** parser.e:3053					elsif equal(option, "and") then*/
    if (_option_59979 == _26490)
    _29976 = 1;
    else if (IS_ATOM_INT(_option_59979) && IS_ATOM_INT(_26490))
    _29976 = 0;
    else
    _29976 = (compare(_option_59979, _26490) == 0);
    if (_29976 == 0)
    {
        _29976 = NOVALUE;
        goto L10; // [290] 357
    }
    else{
        _29976 = NOVALUE;
    }

    /** parser.e:3054						if at_start = 1 then*/
    if (_at_start_60009 != 1LL)
    goto L11; // [295] 315

    /** parser.e:3055							CompileErr(MSG_1_IS_MISSING_DEFINED_WORD_BEFORE_AND, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59987);
    ((intptr_t*)_2)[1] = _keyw_59987;
    _29978 = MAKE_SEQ(_1);
    _49CompileErr(2LL, _29978, 0LL);
    _29978 = NOVALUE;
    goto LA; // [312] 542
L11: 

    /** parser.e:3056						elsif conjunction = 0 then*/
    if (_conjunction_60008 != 0LL)
    goto L12; // [317] 340

    /** parser.e:3057							conjunction = 1*/
    _conjunction_60008 = 1LL;

    /** parser.e:3058							prev_conj = option*/
    RefDS(_option_59979);
    DeRef(_prev_conj_60010);
    _prev_conj_60010 = _option_59979;

    /** parser.e:3059							continue "deflist"*/
    goto L7; // [335] 148
    goto LA; // [337] 542
L12: 

    /** parser.e:3061							CompileErr(MSG_1_AND_FOLLOWS_2,{keyw,prev_conj})*/
    RefDS(_prev_conj_60010);
    RefDS(_keyw_59987);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _keyw_59987;
    ((intptr_t *)_2)[2] = _prev_conj_60010;
    _29980 = MAKE_SEQ(_1);
    _49CompileErr(10LL, _29980, 0LL);
    _29980 = NOVALUE;
    goto LA; // [354] 542
L10: 

    /** parser.e:3063					elsif equal(option, "or") then*/
    if (_option_59979 == _26590)
    _29981 = 1;
    else if (IS_ATOM_INT(_option_59979) && IS_ATOM_INT(_26590))
    _29981 = 0;
    else
    _29981 = (compare(_option_59979, _26590) == 0);
    if (_29981 == 0)
    {
        _29981 = NOVALUE;
        goto L13; // [363] 430
    }
    else{
        _29981 = NOVALUE;
    }

    /** parser.e:3064						if at_start = 1 then*/
    if (_at_start_60009 != 1LL)
    goto L14; // [368] 388

    /** parser.e:3065							CompileErr(MSG_1_IS_MISSING_DEFINED_WORD_BEFORE_THEN, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59987);
    ((intptr_t*)_2)[1] = _keyw_59987;
    _29983 = MAKE_SEQ(_1);
    _49CompileErr(6LL, _29983, 0LL);
    _29983 = NOVALUE;
    goto LA; // [385] 542
L14: 

    /** parser.e:3066						elsif conjunction = 0 then*/
    if (_conjunction_60008 != 0LL)
    goto L15; // [390] 413

    /** parser.e:3067							conjunction = 2*/
    _conjunction_60008 = 2LL;

    /** parser.e:3068							prev_conj = option*/
    RefDS(_option_59979);
    DeRef(_prev_conj_60010);
    _prev_conj_60010 = _option_59979;

    /** parser.e:3069							continue "deflist"*/
    goto L7; // [408] 148
    goto LA; // [410] 542
L15: 

    /** parser.e:3071							CompileErr(MSG_1_OR_FOLLOWS_2, {keyw, prev_conj})*/
    RefDS(_prev_conj_60010);
    RefDS(_keyw_59987);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _keyw_59987;
    ((intptr_t *)_2)[2] = _prev_conj_60010;
    _29985 = MAKE_SEQ(_1);
    _49CompileErr(9LL, _29985, 0LL);
    _29985 = NOVALUE;
    goto LA; // [427] 542
L13: 

    /** parser.e:3073					elsif length(option) = 0 then*/
    if (IS_SEQUENCE(_option_59979)){
            _29986 = SEQ_PTR(_option_59979)->length;
    }
    else {
        _29986 = 1;
    }
    if (_29986 != 0LL)
    goto L16; // [435] 474

    /** parser.e:3074						if at_start = 1 then*/
    if (_at_start_60009 != 1LL)
    goto L17; // [441] 461

    /** parser.e:3075							CompileErr(NO_WORD_WAS_FOUND_FOLLOWING_1, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59987);
    ((intptr_t*)_2)[1] = _keyw_59987;
    _29989 = MAKE_SEQ(_1);
    _49CompileErr(122LL, _29989, 0LL);
    _29989 = NOVALUE;
    goto LA; // [458] 542
L17: 

    /** parser.e:3077							CompileErr(EXPECTING_POSSIBLY_THEN_NOT_END_OF_LINE)*/
    RefDS(_22218);
    _49CompileErr(82LL, _22218, 0LL);
    goto LA; // [471] 542
L16: 

    /** parser.e:3079					elsif not at_start and length(prev_conj) = 0 then*/
    _29990 = (_at_start_60009 == 0);
    if (_29990 == 0) {
        goto L18; // [479] 510
    }
    if (IS_SEQUENCE(_prev_conj_60010)){
            _29992 = SEQ_PTR(_prev_conj_60010)->length;
    }
    else {
        _29992 = 1;
    }
    _29993 = (_29992 == 0LL);
    _29992 = NOVALUE;
    if (_29993 == 0)
    {
        DeRef(_29993);
        _29993 = NOVALUE;
        goto L18; // [491] 510
    }
    else{
        DeRef(_29993);
        _29993 = NOVALUE;
    }

    /** parser.e:3080						CompileErr(MSG_1_NOT_UNDERSTOOD, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59987);
    ((intptr_t*)_2)[1] = _keyw_59987;
    _29994 = MAKE_SEQ(_1);
    _49CompileErr(4LL, _29994, 0LL);
    _29994 = NOVALUE;
    goto LA; // [507] 542
L18: 

    /** parser.e:3081					elsif t_identifier(option) = 0 then*/
    RefDS(_option_59979);
    _29995 = _9t_identifier(_option_59979);
    if (binary_op_a(NOTEQ, _29995, 0LL)){
        DeRef(_29995);
        _29995 = NOVALUE;
        goto L19; // [516] 536
    }
    DeRef(_29995);
    _29995 = NOVALUE;

    /** parser.e:3082						CompileErr(MSG_1_WORD_MUST_BE_AN_IDENTIFIER, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59987);
    ((intptr_t*)_2)[1] = _keyw_59987;
    _29997 = MAKE_SEQ(_1);
    _49CompileErr(3LL, _29997, 0LL);
    _29997 = NOVALUE;
    goto LA; // [533] 542
L19: 

    /** parser.e:3084						at_start = 0*/
    _at_start_60009 = 0LL;
LA: 

    /** parser.e:3087					integer this_matched = find(option, OpDefines)*/
    _this_matched_60095 = find_from(_option_59979, _27OpDefines_20645, 1LL);

    /** parser.e:3088					if negate then*/
    if (_negate_60007 == 0)
    {
        goto L1A; // [553] 567
    }
    else{
    }

    /** parser.e:3089						this_matched = not this_matched*/
    _this_matched_60095 = (_this_matched_60095 == 0);

    /** parser.e:3090						negate = 0*/
    _negate_60007 = 0LL;
L1A: 

    /** parser.e:3093					if conjunction = 0 then*/
    if (_conjunction_60008 != 0LL)
    goto L1B; // [569] 581

    /** parser.e:3094						matched = this_matched*/
    _matched_59980 = _this_matched_60095;
    goto L1C; // [578] 623
L1B: 

    /** parser.e:3096						if conjunction = 1 then*/
    if (_conjunction_60008 != 1LL)
    goto L1D; // [583] 596

    /** parser.e:3097							matched = matched and this_matched*/
    _matched_59980 = (_matched_59980 != 0 && _this_matched_60095 != 0);
    goto L1E; // [593] 610
L1D: 

    /** parser.e:3098						elsif conjunction = 2 then*/
    if (_conjunction_60008 != 2LL)
    goto L1F; // [598] 609

    /** parser.e:3099							matched = matched or this_matched*/
    _matched_59980 = (_matched_59980 != 0 || _this_matched_60095 != 0);
L1F: 
L1E: 

    /** parser.e:3101						conjunction = 0*/
    _conjunction_60008 = 0LL;

    /** parser.e:3102						prev_conj = ""*/
    RefDS(_22218);
    DeRef(_prev_conj_60010);
    _prev_conj_60010 = _22218;
L1C: 

    /** parser.e:3104				end while*/
    goto L7; // [627] 148
LD: 

    /** parser.e:3106				in_matched = matched*/
    _in_matched_59982 = _matched_59980;

    /** parser.e:3107				if matched then*/
    if (_matched_59980 == 0)
    {
        goto L20; // [637] 655
    }
    else{
    }

    /** parser.e:3108					No_new_entry = 0*/
    _53No_new_entry_48427 = 0LL;

    /** parser.e:3109					call_proc(parser_id, {})*/
    _0 = (object)_00[_parser_id_59991].addr;
    (*(intptr_t (*)())_0)(
                         );
L20: 
L6: 
    DeRef(_prev_conj_60010);
    _prev_conj_60010 = NOVALUE;

    /** parser.e:3115			integer gotword = 0*/
    _gotword_60111 = 0LL;

    /** parser.e:3116			integer gotthen = 0*/
    _gotthen_60112 = 0LL;

    /** parser.e:3117			integer if_lvl  = 0*/
    _if_lvl_60113 = 0LL;

    /** parser.e:3118			No_new_entry = not matched*/
    _53No_new_entry_48427 = (_matched_59980 == 0);

    /** parser.e:3119			has_matched = has_matched or matched*/
    _has_matched_59981 = (_has_matched_59981 != 0 || _matched_59980 != 0);

    /** parser.e:3120			keyw = "elsifdef"*/
    RefDS(_26526);
    DeRefi(_keyw_59987);
    _keyw_59987 = _26526;

    /** parser.e:3121			while 1 do*/
L21: 

    /** parser.e:3122				tok = next_token()*/
    _0 = _tok_59986;
    _tok_59986 = _43next_token();
    DeRef(_0);

    /** parser.e:3123				if tok[T_ID] = END_OF_FILE then*/
    _2 = (object)SEQ_PTR(_tok_59986);
    _30008 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30008, -21LL)){
        _30008 = NOVALUE;
        goto L22; // [713] 738
    }
    _30008 = NOVALUE;

    /** parser.e:3124					CompileErr(END_OF_FILE_REACHED_WHILE_SEARCHING_FOR_END_IFDEF_TO_MATCH_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59976)){
            _30010 = SEQ_PTR(_43ifdef_lineno_59976)->length;
    }
    else {
        _30010 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59976);
    _30011 = (object)*(((s1_ptr)_2)->base + _30010);
    _49CompileErr(65LL, _30011, 0LL);
    _30011 = NOVALUE;
    goto L21; // [735] 698
L22: 

    /** parser.e:3125				elsif tok[T_ID] = END then*/
    _2 = (object)SEQ_PTR(_tok_59986);
    _30012 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30012, 402LL)){
        _30012 = NOVALUE;
        goto L23; // [748] 874
    }
    _30012 = NOVALUE;

    /** parser.e:3126					tok = next_token()*/
    _0 = _tok_59986;
    _tok_59986 = _43next_token();
    DeRef(_0);

    /** parser.e:3127					if tok[T_ID] = IFDEF then*/
    _2 = (object)SEQ_PTR(_tok_59986);
    _30015 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30015, 407LL)){
        _30015 = NOVALUE;
        goto L24; // [767] 795
    }
    _30015 = NOVALUE;

    /** parser.e:3128						if dead_ifdef then*/
    if (_dead_ifdef_59983 == 0)
    {
        goto L25; // [773] 785
    }
    else{
    }

    /** parser.e:3129							dead_ifdef -= 1*/
    _dead_ifdef_59983 = _dead_ifdef_59983 - 1LL;
    goto L21; // [782] 698
L25: 

    /** parser.e:3131							exit "top"*/
    goto L26; // [789] 1350
    goto L21; // [792] 698
L24: 

    /** parser.e:3133					elsif in_matched then*/
    if (_in_matched_59982 == 0)
    {
        goto L27; // [797] 821
    }
    else{
    }

    /** parser.e:3135						CompileErr(EXPECTING_END_IFDEF_TO_MATCH_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59976)){
            _30018 = SEQ_PTR(_43ifdef_lineno_59976)->length;
    }
    else {
        _30018 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59976);
    _30019 = (object)*(((s1_ptr)_2)->base + _30018);
    _49CompileErr(75LL, _30019, 0LL);
    _30019 = NOVALUE;
    goto L21; // [818] 698
L27: 

    /** parser.e:3137						if tok[T_ID] = IF then*/
    _2 = (object)SEQ_PTR(_tok_59986);
    _30020 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30020, 20LL)){
        _30020 = NOVALUE;
        goto L21; // [831] 698
    }
    _30020 = NOVALUE;

    /** parser.e:3138							if if_lvl > 0 then*/
    if (_if_lvl_60113 <= 0LL)
    goto L28; // [837] 850

    /** parser.e:3139								if_lvl -= 1*/
    _if_lvl_60113 = _if_lvl_60113 - 1LL;
    goto L21; // [847] 698
L28: 

    /** parser.e:3141								CompileErr(MISMATCHED_END_IF_SHOULD_THIS_BE_AN_END_IFDEF_TO_MATCH_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59976)){
            _30024 = SEQ_PTR(_43ifdef_lineno_59976)->length;
    }
    else {
        _30024 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59976);
    _30025 = (object)*(((s1_ptr)_2)->base + _30024);
    _49CompileErr(111LL, _30025, 0LL);
    _30025 = NOVALUE;
    goto L21; // [871] 698
L23: 

    /** parser.e:3145				elsif tok[T_ID] = IF then*/
    _2 = (object)SEQ_PTR(_tok_59986);
    _30026 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30026, 20LL)){
        _30026 = NOVALUE;
        goto L29; // [884] 897
    }
    _30026 = NOVALUE;

    /** parser.e:3146					if_lvl += 1*/
    _if_lvl_60113 = _if_lvl_60113 + 1;
    goto L21; // [894] 698
L29: 

    /** parser.e:3147				elsif tok[T_ID] = ELSE then*/
    _2 = (object)SEQ_PTR(_tok_59986);
    _30029 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30029, 23LL)){
        _30029 = NOVALUE;
        goto L2A; // [907] 945
    }
    _30029 = NOVALUE;

    /** parser.e:3148					if not in_matched then*/
    if (_in_matched_59982 != 0)
    goto L21; // [913] 698

    /** parser.e:3149						if if_lvl = 0 then*/
    if (_if_lvl_60113 != 0LL)
    goto L21; // [918] 698

    /** parser.e:3150							CompileErr(MISMATCHED_ELSE_SHOULD_THIS_BE_AN_ELSEDEF_TO_MATCH_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59976)){
            _30033 = SEQ_PTR(_43ifdef_lineno_59976)->length;
    }
    else {
        _30033 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59976);
    _30034 = (object)*(((s1_ptr)_2)->base + _30033);
    _49CompileErr(108LL, _30034, 0LL);
    _30034 = NOVALUE;
    goto L21; // [942] 698
L2A: 

    /** parser.e:3153				elsif tok[T_ID] = ELSIFDEF and not dead_ifdef then*/
    _2 = (object)SEQ_PTR(_tok_59986);
    _30035 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30035)) {
        _30036 = (_30035 == 408LL);
    }
    else {
        _30036 = binary_op(EQUALS, _30035, 408LL);
    }
    _30035 = NOVALUE;
    if (IS_ATOM_INT(_30036)) {
        if (_30036 == 0) {
            goto L2B; // [959] 1101
        }
    }
    else {
        if (DBL_PTR(_30036)->dbl == 0.0) {
            goto L2B; // [959] 1101
        }
    }
    _30038 = (_dead_ifdef_59983 == 0);
    if (_30038 == 0)
    {
        DeRef(_30038);
        _30038 = NOVALUE;
        goto L2B; // [967] 1101
    }
    else{
        DeRef(_30038);
        _30038 = NOVALUE;
    }

    /** parser.e:3154					if has_matched then*/
    if (_has_matched_59981 == 0)
    {
        goto L2C; // [972] 1343
    }
    else{
    }

    /** parser.e:3155						in_matched = 0*/
    _in_matched_59982 = 0LL;

    /** parser.e:3156						No_new_entry = 1*/
    _53No_new_entry_48427 = 1LL;

    /** parser.e:3157						gotword = 0*/
    _gotword_60111 = 0LL;

    /** parser.e:3158						gotthen = 0*/
    _gotthen_60112 = 0LL;

    /** parser.e:3159						while length(option) > 0 with entry do*/
    goto L2D; // [999] 1041
L2E: 
    if (IS_SEQUENCE(_option_59979)){
            _30039 = SEQ_PTR(_option_59979)->length;
    }
    else {
        _30039 = 1;
    }
    if (_30039 <= 0LL)
    goto L2F; // [1007] 1054

    /** parser.e:3160							if equal(option, "then") then*/
    if (_option_59979 == _26625)
    _30041 = 1;
    else if (IS_ATOM_INT(_option_59979) && IS_ATOM_INT(_26625))
    _30041 = 0;
    else
    _30041 = (compare(_option_59979, _26625) == 0);
    if (_30041 == 0)
    {
        _30041 = NOVALUE;
        goto L30; // [1017] 1032
    }
    else{
        _30041 = NOVALUE;
    }

    /** parser.e:3161								gotthen = 1*/
    _gotthen_60112 = 1LL;

    /** parser.e:3162								exit*/
    goto L2F; // [1027] 1054
    goto L31; // [1029] 1038
L30: 

    /** parser.e:3164								gotword = 1*/
    _gotword_60111 = 1LL;
L31: 

    /** parser.e:3166						entry*/
L2D: 

    /** parser.e:3167							option = StringToken()*/
    RefDS(_5);
    _0 = _option_59979;
    _option_59979 = _61StringToken(_5);
    DeRef(_0);

    /** parser.e:3168						end while*/
    goto L2E; // [1051] 1002
L2F: 

    /** parser.e:3169						if gotword = 0 then*/
    if (_gotword_60111 != 0LL)
    goto L32; // [1056] 1070

    /** parser.e:3170							CompileErr(EXPECTING_A_WORD_TO_FOLLOW_ELSIFDEF)*/
    RefDS(_22218);
    _49CompileErr(78LL, _22218, 0LL);
L32: 

    /** parser.e:3172						if gotthen = 0 then*/
    if (_gotthen_60112 != 0LL)
    goto L33; // [1072] 1086

    /** parser.e:3173							CompileErr(EXPECTING_THEN_ON_ELSIFDEF_LINE)*/
    RefDS(_22218);
    _49CompileErr(77LL, _22218, 0LL);
L33: 

    /** parser.e:3175						read_line()*/
    _61read_line();
    goto L21; // [1090] 698

    /** parser.e:3177						exit*/
    goto L2C; // [1095] 1343
    goto L21; // [1098] 698
L2B: 

    /** parser.e:3179				elsif tok[T_ID] = ELSEDEF then*/
    _2 = (object)SEQ_PTR(_tok_59986);
    _30045 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30045, 409LL)){
        _30045 = NOVALUE;
        goto L34; // [1111] 1273
    }
    _30045 = NOVALUE;

    /** parser.e:3180					gotword = line_number*/
    _gotword_60111 = _27line_number_20572;

    /** parser.e:3181					option = StringToken()*/
    RefDS(_5);
    _0 = _option_59979;
    _option_59979 = _61StringToken(_5);
    DeRef(_0);

    /** parser.e:3182					if length(option) > 0 then*/
    if (IS_SEQUENCE(_option_59979)){
            _30048 = SEQ_PTR(_option_59979)->length;
    }
    else {
        _30048 = 1;
    }
    if (_30048 <= 0LL)
    goto L35; // [1137] 1173

    /** parser.e:3183						if line_number = gotword then*/
    if (_27line_number_20572 != _gotword_60111)
    goto L36; // [1145] 1159

    /** parser.e:3184							CompileErr(NOT_EXPECTING_ANYTHING_ON_SAME_LINE_AS_ELSDEF)*/
    RefDS(_22218);
    _49CompileErr(116LL, _22218, 0LL);
L36: 

    /** parser.e:3186						bp -= length(option)*/
    if (IS_SEQUENCE(_option_59979)){
            _30051 = SEQ_PTR(_option_59979)->length;
    }
    else {
        _30051 = 1;
    }
    _49bp_49697 = _49bp_49697 - _30051;
    _30051 = NOVALUE;
L35: 

    /** parser.e:3188					if not dead_ifdef then*/
    if (_dead_ifdef_59983 != 0)
    goto L21; // [1175] 698

    /** parser.e:3189						if has_matched then*/
    if (_has_matched_59981 == 0)
    {
        goto L37; // [1180] 1202
    }
    else{
    }

    /** parser.e:3190							in_matched = 0*/
    _in_matched_59982 = 0LL;

    /** parser.e:3191							No_new_entry = 1*/
    _53No_new_entry_48427 = 1LL;

    /** parser.e:3192							read_line()*/
    _61read_line();
    goto L21; // [1199] 698
L37: 

    /** parser.e:3194							No_new_entry = 0*/
    _53No_new_entry_48427 = 0LL;

    /** parser.e:3195							in_elsedef = 1*/
    _in_elsedef_59984 = 1LL;

    /** parser.e:3196							call_proc(parser_id, {})*/
    _0 = (object)_00[_parser_id_59991].addr;
    (*(intptr_t (*)())_0)(
                         );

    /** parser.e:3197							tok_match(END)*/
    _43tok_match(402LL, 0LL);

    /** parser.e:3198							tok_match(IFDEF, END)*/
    _43tok_match(407LL, 402LL);

    /** parser.e:3199							live_ifdef -= 1*/
    _43live_ifdef_59975 = _43live_ifdef_59975 - 1LL;

    /** parser.e:3200							ifdef_lineno = ifdef_lineno[1..$-1]*/
    if (IS_SEQUENCE(_43ifdef_lineno_59976)){
            _30055 = SEQ_PTR(_43ifdef_lineno_59976)->length;
    }
    else {
        _30055 = 1;
    }
    _30056 = _30055 - 1LL;
    _30055 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43ifdef_lineno_59976;
    RHS_Slice(_43ifdef_lineno_59976, 1LL, _30056);

    /** parser.e:3201							return*/
    DeRef(_option_59979);
    DeRef(_tok_59986);
    DeRefi(_keyw_59987);
    _30056 = NOVALUE;
    DeRef(_29990);
    _29990 = NOVALUE;
    DeRef(_30036);
    _30036 = NOVALUE;
    DeRef(_29961);
    _29961 = NOVALUE;
    DeRef(_29955);
    _29955 = NOVALUE;
    return;
    goto L21; // [1270] 698
L34: 

    /** parser.e:3204				elsif tok[T_ID] = IFDEF then*/
    _2 = (object)SEQ_PTR(_tok_59986);
    _30058 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30058, 407LL)){
        _30058 = NOVALUE;
        goto L38; // [1283] 1296
    }
    _30058 = NOVALUE;

    /** parser.e:3205					dead_ifdef += 1*/
    _dead_ifdef_59983 = _dead_ifdef_59983 + 1;
    goto L21; // [1293] 698
L38: 

    /** parser.e:3207				elsif tok[T_ID] = INCLUDE then*/
    _2 = (object)SEQ_PTR(_tok_59986);
    _30061 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30061, 418LL)){
        _30061 = NOVALUE;
        goto L39; // [1306] 1317
    }
    _30061 = NOVALUE;

    /** parser.e:3209					read_line()*/
    _61read_line();
    goto L21; // [1314] 698
L39: 

    /** parser.e:3211				elsif tok[T_ID] = CASE then*/
    _2 = (object)SEQ_PTR(_tok_59986);
    _30063 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30063, 186LL)){
        _30063 = NOVALUE;
        goto L21; // [1327] 698
    }
    _30063 = NOVALUE;

    /** parser.e:3213					tok = next_token()*/
    _0 = _tok_59986;
    _tok_59986 = _43next_token();
    DeRef(_0);

    /** parser.e:3216			end while*/
    goto L21; // [1340] 698
L2C: 

    /** parser.e:3217		end while*/
    goto L5; // [1347] 105
L26: 

    /** parser.e:3219		live_ifdef -= 1*/
    _43live_ifdef_59975 = _43live_ifdef_59975 - 1LL;

    /** parser.e:3220		ifdef_lineno = ifdef_lineno[1..$-1]*/
    if (IS_SEQUENCE(_43ifdef_lineno_59976)){
            _30067 = SEQ_PTR(_43ifdef_lineno_59976)->length;
    }
    else {
        _30067 = 1;
    }
    _30068 = _30067 - 1LL;
    _30067 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43ifdef_lineno_59976;
    RHS_Slice(_43ifdef_lineno_59976, 1LL, _30068);

    /** parser.e:3221		No_new_entry = 0*/
    _53No_new_entry_48427 = 0LL;

    /** parser.e:3222	end procedure*/
    DeRef(_option_59979);
    DeRef(_tok_59986);
    DeRefi(_keyw_59987);
    DeRef(_30056);
    _30056 = NOVALUE;
    DeRef(_29990);
    _29990 = NOVALUE;
    DeRef(_30036);
    _30036 = NOVALUE;
    DeRef(_29961);
    _29961 = NOVALUE;
    DeRef(_29955);
    _29955 = NOVALUE;
    _30068 = NOVALUE;
    return;
    ;
}


object _43SetPrivateScope(object _s_60266, object _type_sym_60268, object _n_60269)
{
    object _hashval_60270 = NOVALUE;
    object _scope_60271 = NOVALUE;
    object _t_60273 = NOVALUE;
    object _30089 = NOVALUE;
    object _30088 = NOVALUE;
    object _30087 = NOVALUE;
    object _30086 = NOVALUE;
    object _30085 = NOVALUE;
    object _30084 = NOVALUE;
    object _30081 = NOVALUE;
    object _30078 = NOVALUE;
    object _30076 = NOVALUE;
    object _30074 = NOVALUE;
    object _30070 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_60266)) {
        _1 = (object)(DBL_PTR(_s_60266)->dbl);
        DeRefDS(_s_60266);
        _s_60266 = _1;
    }

    /** parser.e:3230		scope = SymTab[s][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30070 = (object)*(((s1_ptr)_2)->base + _s_60266);
    _2 = (object)SEQ_PTR(_30070);
    _scope_60271 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_scope_60271)){
        _scope_60271 = (object)DBL_PTR(_scope_60271)->dbl;
    }
    _30070 = NOVALUE;

    /** parser.e:3231		switch scope do*/
    _0 = _scope_60271;
    switch ( _0 ){ 

        /** parser.e:3232			case SC_PRIVATE then*/
        case 3:

        /** parser.e:3233				DefinedYet(s)*/
        _53DefinedYet(_s_60266);

        /** parser.e:3234				Block_var( s )*/
        _64Block_var(_s_60266);

        /** parser.e:3235				return s*/
        return _s_60266;
        goto L1; // [50] 260

        /** parser.e:3237			case SC_LOOP_VAR then*/
        case 2:

        /** parser.e:3238				DefinedYet(s)*/
        _53DefinedYet(_s_60266);

        /** parser.e:3239				return s*/
        return _s_60266;
        goto L1; // [67] 260

        /** parser.e:3241			case SC_UNDEFINED, SC_MULTIPLY_DEFINED then*/
        case 9:
        case 10:

        /** parser.e:3242				SymTab[s][S_SCOPE] = SC_PRIVATE*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_s_60266 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 4LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 3LL;
        DeRef(_1);
        _30074 = NOVALUE;

        /** parser.e:3243				SymTab[s][S_VARNUM] = n*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_s_60266 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 16LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _n_60269;
        DeRef(_1);
        _30076 = NOVALUE;

        /** parser.e:3244				SymTab[s][S_VTYPE] = type_sym*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_s_60266 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 15LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _type_sym_60268;
        DeRef(_1);
        _30078 = NOVALUE;

        /** parser.e:3245				if type_sym < 0 then*/
        if (_type_sym_60268 >= 0LL)
        goto L2; // [124] 135

        /** parser.e:3246					register_forward_type( s, type_sym )*/
        _42register_forward_type(_s_60266, _type_sym_60268);
L2: 

        /** parser.e:3248				Block_var( s )*/
        _64Block_var(_s_60266);

        /** parser.e:3249				return s*/
        return _s_60266;
        goto L1; // [146] 260

        /** parser.e:3251			case SC_LOCAL, SC_GLOBAL, SC_PREDEF, SC_PUBLIC, SC_EXPORT then*/
        case 5:
        case 6:
        case 7:
        case 13:
        case 11:

        /** parser.e:3252				hashval = SymTab[s][S_HASHVAL]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _30081 = (object)*(((s1_ptr)_2)->base + _s_60266);
        _2 = (object)SEQ_PTR(_30081);
        _hashval_60270 = (object)*(((s1_ptr)_2)->base + 11LL);
        if (!IS_ATOM_INT(_hashval_60270)){
            _hashval_60270 = (object)DBL_PTR(_hashval_60270)->dbl;
        }
        _30081 = NOVALUE;

        /** parser.e:3253				t = buckets[hashval]*/
        _2 = (object)SEQ_PTR(_53buckets_47223);
        _t_60273 = (object)*(((s1_ptr)_2)->base + _hashval_60270);
        if (!IS_ATOM_INT(_t_60273)){
            _t_60273 = (object)DBL_PTR(_t_60273)->dbl;
        }

        /** parser.e:3254				buckets[hashval] = NewEntry(SymTab[s][S_NAME], n, SC_PRIVATE,*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _30084 = (object)*(((s1_ptr)_2)->base + _s_60266);
        _2 = (object)SEQ_PTR(_30084);
        if (!IS_ATOM_INT(_27S_NAME_20209)){
            _30085 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
        }
        else{
            _30085 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
        }
        _30084 = NOVALUE;
        Ref(_30085);
        _30086 = _53NewEntry(_30085, _n_60269, 3LL, -100LL, _hashval_60270, _t_60273, _type_sym_60268);
        _30085 = NOVALUE;
        _2 = (object)SEQ_PTR(_53buckets_47223);
        _2 = (object)(((s1_ptr)_2)->base + _hashval_60270);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _30086;
        if( _1 != _30086 ){
            DeRef(_1);
        }
        _30086 = NOVALUE;

        /** parser.e:3256				Block_var( buckets[hashval] )*/
        _2 = (object)SEQ_PTR(_53buckets_47223);
        _30087 = (object)*(((s1_ptr)_2)->base + _hashval_60270);
        Ref(_30087);
        _64Block_var(_30087);
        _30087 = NOVALUE;

        /** parser.e:3257				return buckets[hashval]*/
        _2 = (object)SEQ_PTR(_53buckets_47223);
        _30088 = (object)*(((s1_ptr)_2)->base + _hashval_60270);
        Ref(_30088);
        return _30088;
        goto L1; // [243] 260

        /** parser.e:3259			case else*/
        default:

        /** parser.e:3260				InternalErr(267, {scope})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _scope_60271;
        _30089 = MAKE_SEQ(_1);
        _49InternalErr(267LL, _30089);
        _30089 = NOVALUE;
    ;}L1: 

    /** parser.e:3264		return 0*/
    _30088 = NOVALUE;
    return 0LL;
    ;
}


void _43For_statement()
{
    object _bp1_60338 = NOVALUE;
    object _bp2_60339 = NOVALUE;
    object _exit_base_60340 = NOVALUE;
    object _next_base_60341 = NOVALUE;
    object _end_op_60342 = NOVALUE;
    object _tok_60344 = NOVALUE;
    object _loop_var_60345 = NOVALUE;
    object _loop_var_sym_60347 = NOVALUE;
    object _save_syms_60348 = NOVALUE;
    object _30136 = NOVALUE;
    object _30134 = NOVALUE;
    object _30133 = NOVALUE;
    object _30127 = NOVALUE;
    object _30125 = NOVALUE;
    object _30123 = NOVALUE;
    object _30122 = NOVALUE;
    object _30121 = NOVALUE;
    object _30120 = NOVALUE;
    object _30118 = NOVALUE;
    object _30116 = NOVALUE;
    object _30115 = NOVALUE;
    object _30114 = NOVALUE;
    object _30113 = NOVALUE;
    object _30111 = NOVALUE;
    object _30109 = NOVALUE;
    object _30105 = NOVALUE;
    object _30103 = NOVALUE;
    object _30100 = NOVALUE;
    object _30098 = NOVALUE;
    object _30092 = NOVALUE;
    object _30091 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:3273		sequence save_syms*/

    /** parser.e:3275		Start_block( FOR )*/
    _64Start_block(21LL, 0LL);

    /** parser.e:3276		loop_var = next_token()*/
    _0 = _loop_var_60345;
    _loop_var_60345 = _43next_token();
    DeRef(_0);

    /** parser.e:3277		if not find(loop_var[T_ID], ADDR_TOKS) then*/
    _2 = (object)SEQ_PTR(_loop_var_60345);
    _30091 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30092 = find_from(_30091, _29ADDR_TOKS_12281, 1LL);
    _30091 = NOVALUE;
    if (_30092 != 0)
    goto L1; // [31] 44
    _30092 = NOVALUE;

    /** parser.e:3278			CompileErr(A_LOOP_VARIABLE_NAME_IS_EXPECTED_HERE)*/
    RefDS(_22218);
    _49CompileErr(28LL, _22218, 0LL);
L1: 

    /** parser.e:3281		if BIND then*/
    if (_27BIND_20182 == 0)
    {
        goto L2; // [48] 57
    }
    else{
    }

    /** parser.e:3282			add_ref(loop_var)*/
    Ref(_loop_var_60345);
    _53add_ref(_loop_var_60345);
L2: 

    /** parser.e:3285		tok_match(EQUALS)*/
    _43tok_match(3LL, 0LL);

    /** parser.e:3286		exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_43exit_list_55488)){
            _exit_base_60340 = SEQ_PTR(_43exit_list_55488)->length;
    }
    else {
        _exit_base_60340 = 1;
    }

    /** parser.e:3287		next_base = length(continue_list)*/
    if (IS_SEQUENCE(_43continue_list_55490)){
            _next_base_60341 = SEQ_PTR(_43continue_list_55490)->length;
    }
    else {
        _next_base_60341 = 1;
    }

    /** parser.e:3288		Expr()*/
    _43Expr();

    /** parser.e:3289		tok_match(TO)*/
    _43tok_match(403LL, 0LL);

    /** parser.e:3290		exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_43exit_list_55488)){
            _exit_base_60340 = SEQ_PTR(_43exit_list_55488)->length;
    }
    else {
        _exit_base_60340 = 1;
    }

    /** parser.e:3291		Expr()*/
    _43Expr();

    /** parser.e:3292		tok = next_token()*/
    _0 = _tok_60344;
    _tok_60344 = _43next_token();
    DeRef(_0);

    /** parser.e:3293		if tok[T_ID] = BY then*/
    _2 = (object)SEQ_PTR(_tok_60344);
    _30098 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30098, 404LL)){
        _30098 = NOVALUE;
        goto L3; // [117] 137
    }
    _30098 = NOVALUE;

    /** parser.e:3294			Expr()*/
    _43Expr();

    /** parser.e:3295			end_op = ENDFOR_GENERAL -- will be set at runtime by FOR op*/
    _end_op_60342 = 39LL;
    goto L4; // [134] 161
L3: 

    /** parser.e:3298			emit_opnd(NewIntSym(1))*/
    _30100 = _53NewIntSym(1LL);
    _45emit_opnd(_30100);
    _30100 = NOVALUE;

    /** parser.e:3299			putback(tok)*/
    Ref(_tok_60344);
    _43putback(_tok_60344);

    /** parser.e:3300			end_op = ENDFOR_INT_UP1*/
    _end_op_60342 = 54LL;
L4: 

    /** parser.e:3303		loop_var_sym = loop_var[T_SYM]*/
    _2 = (object)SEQ_PTR(_loop_var_60345);
    _loop_var_sym_60347 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_loop_var_sym_60347)){
        _loop_var_sym_60347 = (object)DBL_PTR(_loop_var_sym_60347)->dbl;
    }

    /** parser.e:3304		if CurrentSub = TopLevelSub then*/
    if (_27CurrentSub_20579 != _27TopLevelSub_20578)
    goto L5; // [177] 223

    /** parser.e:3305			DefinedYet(loop_var_sym)*/
    _53DefinedYet(_loop_var_sym_60347);

    /** parser.e:3306			SymTab[loop_var_sym][S_SCOPE] = SC_GLOOP_VAR*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_loop_var_sym_60347 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 4LL;
    DeRef(_1);
    _30103 = NOVALUE;

    /** parser.e:3307			SymTab[loop_var_sym][S_VTYPE] = object_type*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_loop_var_sym_60347 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _53object_type_47227;
    DeRef(_1);
    _30105 = NOVALUE;
    goto L6; // [220] 267
L5: 

    /** parser.e:3309			loop_var_sym = SetPrivateScope(loop_var_sym, object_type, param_num)*/
    _loop_var_sym_60347 = _43SetPrivateScope(_loop_var_sym_60347, _53object_type_47227, _43param_num_55477);
    if (!IS_ATOM_INT(_loop_var_sym_60347)) {
        _1 = (object)(DBL_PTR(_loop_var_sym_60347)->dbl);
        DeRefDS(_loop_var_sym_60347);
        _loop_var_sym_60347 = _1;
    }

    /** parser.e:3310			param_num += 1*/
    _43param_num_55477 = _43param_num_55477 + 1;

    /** parser.e:3311			SymTab[loop_var_sym][S_SCOPE] = SC_LOOP_VAR*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_loop_var_sym_60347 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _30109 = NOVALUE;

    /** parser.e:3312			Pop_block_var()*/
    _64Pop_block_var();
L6: 

    /** parser.e:3314		SymTab[loop_var_sym][S_USAGE] = or_bits(SymTab[loop_var_sym][S_USAGE], U_USED)*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_loop_var_sym_60347 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30113 = (object)*(((s1_ptr)_2)->base + _loop_var_sym_60347);
    _2 = (object)SEQ_PTR(_30113);
    _30114 = (object)*(((s1_ptr)_2)->base + 5LL);
    _30113 = NOVALUE;
    if (IS_ATOM_INT(_30114)) {
        {uintptr_t tu;
             tu = (uintptr_t)_30114 | (uintptr_t)3LL;
             _30115 = MAKE_UINT(tu);
        }
    }
    else {
        _30115 = binary_op(OR_BITS, _30114, 3LL);
    }
    _30114 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30115;
    if( _1 != _30115 ){
        DeRef(_1);
    }
    _30115 = NOVALUE;
    _30111 = NOVALUE;

    /** parser.e:3316		op_info1 = loop_var_sym*/
    _45op_info1_51473 = _loop_var_sym_60347;

    /** parser.e:3317		emit_op(FOR)*/
    _45emit_op(21LL);

    /** parser.e:3318		emit_addr(loop_var_sym)*/
    _45emit_addr(_loop_var_sym_60347);

    /** parser.e:3319		if finish_block_header(FOR) then*/
    _30116 = _43finish_block_header(21LL);
    if (_30116 == 0) {
        DeRef(_30116);
        _30116 = NOVALUE;
        goto L7; // [327] 340
    }
    else {
        if (!IS_ATOM_INT(_30116) && DBL_PTR(_30116)->dbl == 0.0){
            DeRef(_30116);
            _30116 = NOVALUE;
            goto L7; // [327] 340
        }
        DeRef(_30116);
        _30116 = NOVALUE;
    }
    DeRef(_30116);
    _30116 = NOVALUE;

    /** parser.e:3320			CompileErr(ENTRY_IS_NOT_SUPPORTED_IN_FOR_LOOPS)*/
    RefDS(_22218);
    _49CompileErr(83LL, _22218, 0LL);
L7: 

    /** parser.e:3322		entry_addr &= 0*/
    Append(&_43entry_addr_55492, _43entry_addr_55492, 0LL);

    /** parser.e:3323		bp1 = length(Code)+1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _30118 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _30118 = 1;
    }
    _bp1_60338 = _30118 + 1;
    _30118 = NOVALUE;

    /** parser.e:3324		emit_addr(0) -- will be patched - don't straighten*/
    _45emit_addr(0LL);

    /** parser.e:3326		save_syms = Code[$-5..$-3] -- could be temps, but can't get rid of them yet*/
    if (IS_SEQUENCE(_27Code_20660)){
            _30120 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _30120 = 1;
    }
    _30121 = _30120 - 5LL;
    _30120 = NOVALUE;
    if (IS_SEQUENCE(_27Code_20660)){
            _30122 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _30122 = 1;
    }
    _30123 = _30122 - 3LL;
    _30122 = NOVALUE;
    rhs_slice_target = (object_ptr)&_save_syms_60348;
    RHS_Slice(_27Code_20660, _30121, _30123);

    /** parser.e:3327		for i = 1 to 3 do*/
    {
        object _i_60438;
        _i_60438 = 1LL;
L8: 
        if (_i_60438 > 3LL){
            goto L9; // [389] 412
        }

        /** parser.e:3328			clear_temp( save_syms[i] )*/
        _2 = (object)SEQ_PTR(_save_syms_60348);
        _30125 = (object)*(((s1_ptr)_2)->base + _i_60438);
        Ref(_30125);
        _45clear_temp(_30125);
        _30125 = NOVALUE;

        /** parser.e:3329		end for*/
        _i_60438 = _i_60438 + 1LL;
        goto L8; // [407] 396
L9: 
        ;
    }

    /** parser.e:3330		flush_temps()*/
    RefDS(_22218);
    _45flush_temps(_22218);

    /** parser.e:3332		bp2 = length(Code)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _bp2_60339 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _bp2_60339 = 1;
    }

    /** parser.e:3333		retry_addr &= bp2 + 1*/
    _30127 = _bp2_60339 + 1;
    Append(&_43retry_addr_55494, _43retry_addr_55494, _30127);
    _30127 = NOVALUE;

    /** parser.e:3334		continue_addr &= 0*/
    Append(&_43continue_addr_55493, _43continue_addr_55493, 0LL);

    /** parser.e:3336		loop_stack &= FOR*/
    Append(&_43loop_stack_55502, _43loop_stack_55502, 21LL);

    /** parser.e:3338		if not TRANSLATE then*/
    if (_27TRANSLATE_20179 != 0)
    goto LA; // [458] 482

    /** parser.e:3339			if OpTrace then*/
    if (_27OpTrace_20641 == 0)
    {
        goto LB; // [465] 481
    }
    else{
    }

    /** parser.e:3340				emit_op(DISPLAY_VAR)*/
    _45emit_op(87LL);

    /** parser.e:3341				emit_addr(loop_var_sym)*/
    _45emit_addr(_loop_var_sym_60347);
LB: 
LA: 

    /** parser.e:3345		Statement_list()*/
    _43Statement_list();

    /** parser.e:3346		tok_match(END)*/
    _43tok_match(402LL, 0LL);

    /** parser.e:3347		tok_match(FOR, END)*/
    _43tok_match(21LL, 402LL);

    /** parser.e:3349		End_block( FOR )*/
    _64End_block(21LL);

    /** parser.e:3351		StartSourceLine(TRUE, TRANSLATE)*/
    _45StartSourceLine(_9TRUE_441, _27TRANSLATE_20179, 2LL);

    /** parser.e:3352		op_info1 = loop_var_sym*/
    _45op_info1_51473 = _loop_var_sym_60347;

    /** parser.e:3353		op_info2 = bp2 + 1*/
    _45op_info2_51474 = _bp2_60339 + 1;

    /** parser.e:3354		PatchNList(next_base)*/
    _43PatchNList(_next_base_60341);

    /** parser.e:3355		emit_op(end_op)*/
    _45emit_op(_end_op_60342);

    /** parser.e:3356		backpatch(bp1, length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _30133 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _30133 = 1;
    }
    _30134 = _30133 + 1;
    _30133 = NOVALUE;
    _45backpatch(_bp1_60338, _30134);
    _30134 = NOVALUE;

    /** parser.e:3357		if not TRANSLATE then*/
    if (_27TRANSLATE_20179 != 0)
    goto LC; // [568] 592

    /** parser.e:3358			if OpTrace then*/
    if (_27OpTrace_20641 == 0)
    {
        goto LD; // [575] 591
    }
    else{
    }

    /** parser.e:3359				emit_op(ERASE_SYMBOL)*/
    _45emit_op(90LL);

    /** parser.e:3360				emit_addr(loop_var_sym)*/
    _45emit_addr(_loop_var_sym_60347);
LD: 
LC: 

    /** parser.e:3364		Hide(loop_var_sym)*/
    _53Hide(_loop_var_sym_60347);

    /** parser.e:3365		exit_loop(exit_base)*/
    _43exit_loop(_exit_base_60340);

    /** parser.e:3366		for i = 1 to 3 do*/
    {
        object _i_60484;
        _i_60484 = 1LL;
LE: 
        if (_i_60484 > 3LL){
            goto LF; // [604] 630
        }

        /** parser.e:3367			emit_temp( save_syms[i], NEW_REFERENCE )*/
        _2 = (object)SEQ_PTR(_save_syms_60348);
        _30136 = (object)*(((s1_ptr)_2)->base + _i_60484);
        Ref(_30136);
        _45emit_temp(_30136, 1LL);
        _30136 = NOVALUE;

        /** parser.e:3368		end for*/
        _i_60484 = _i_60484 + 1LL;
        goto LE; // [625] 611
LF: 
        ;
    }

    /** parser.e:3369		flush_temps()*/
    RefDS(_22218);
    _45flush_temps(_22218);

    /** parser.e:3370	end procedure*/
    DeRef(_tok_60344);
    DeRef(_loop_var_60345);
    DeRef(_save_syms_60348);
    DeRef(_30121);
    _30121 = NOVALUE;
    DeRef(_30123);
    _30123 = NOVALUE;
    return;
    ;
}


object _43CompileType(object _type_ptr_60492)
{
    object _t_60493 = NOVALUE;
    object _30147 = NOVALUE;
    object _30146 = NOVALUE;
    object _30145 = NOVALUE;
    object _30139 = NOVALUE;
    object _30138 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_type_ptr_60492)) {
        _1 = (object)(DBL_PTR(_type_ptr_60492)->dbl);
        DeRefDS(_type_ptr_60492);
        _type_ptr_60492 = _1;
    }

    /** parser.e:3376		if type_ptr < 0 then*/
    if (_type_ptr_60492 >= 0LL)
    goto L1; // [5] 16

    /** parser.e:3378			return type_ptr*/
    return _type_ptr_60492;
L1: 

    /** parser.e:3381		if SymTab[type_ptr][S_TOKEN] = OBJECT then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30138 = (object)*(((s1_ptr)_2)->base + _type_ptr_60492);
    _2 = (object)SEQ_PTR(_30138);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _30139 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _30139 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _30138 = NOVALUE;
    if (binary_op_a(NOTEQ, _30139, 415LL)){
        _30139 = NOVALUE;
        goto L2; // [32] 47
    }
    _30139 = NOVALUE;

    /** parser.e:3382			return TYPE_OBJECT*/
    return 16LL;
    goto L3; // [44] 218
L2: 

    /** parser.e:3384		elsif type_ptr = integer_type then*/
    if (_type_ptr_60492 != _53integer_type_47233)
    goto L4; // [51] 66

    /** parser.e:3385			return TYPE_INTEGER*/
    return 1LL;
    goto L3; // [63] 218
L4: 

    /** parser.e:3387		elsif type_ptr = atom_type then*/
    if (_type_ptr_60492 != _53atom_type_47229)
    goto L5; // [70] 85

    /** parser.e:3388			return TYPE_ATOM*/
    return 4LL;
    goto L3; // [82] 218
L5: 

    /** parser.e:3390		elsif type_ptr = sequence_type then*/
    if (_type_ptr_60492 != _53sequence_type_47231)
    goto L6; // [89] 104

    /** parser.e:3391			return TYPE_SEQUENCE*/
    return 8LL;
    goto L3; // [101] 218
L6: 

    /** parser.e:3393		elsif type_ptr = object_type then*/
    if (_type_ptr_60492 != _53object_type_47227)
    goto L7; // [108] 123

    /** parser.e:3394			return TYPE_OBJECT*/
    return 16LL;
    goto L3; // [120] 218
L7: 

    /** parser.e:3398			t = SymTab[SymTab[type_ptr][S_NEXT]][S_VTYPE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30145 = (object)*(((s1_ptr)_2)->base + _type_ptr_60492);
    _2 = (object)SEQ_PTR(_30145);
    _30146 = (object)*(((s1_ptr)_2)->base + 2LL);
    _30145 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30146)){
        _30147 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30146)->dbl));
    }
    else{
        _30147 = (object)*(((s1_ptr)_2)->base + _30146);
    }
    _2 = (object)SEQ_PTR(_30147);
    _t_60493 = (object)*(((s1_ptr)_2)->base + 15LL);
    if (!IS_ATOM_INT(_t_60493)){
        _t_60493 = (object)DBL_PTR(_t_60493)->dbl;
    }
    _30147 = NOVALUE;

    /** parser.e:3399			if t = integer_type then*/
    if (_t_60493 != _53integer_type_47233)
    goto L8; // [155] 170

    /** parser.e:3400				return TYPE_INTEGER*/
    _30146 = NOVALUE;
    return 1LL;
    goto L9; // [167] 217
L8: 

    /** parser.e:3401			elsif t = atom_type then*/
    if (_t_60493 != _53atom_type_47229)
    goto LA; // [174] 189

    /** parser.e:3402				return TYPE_ATOM*/
    _30146 = NOVALUE;
    return 4LL;
    goto L9; // [186] 217
LA: 

    /** parser.e:3403			elsif t = sequence_type then*/
    if (_t_60493 != _53sequence_type_47231)
    goto LB; // [193] 208

    /** parser.e:3404				return TYPE_SEQUENCE*/
    _30146 = NOVALUE;
    return 8LL;
    goto L9; // [205] 217
LB: 

    /** parser.e:3406				return TYPE_OBJECT*/
    _30146 = NOVALUE;
    return 16LL;
L9: 
L3: 
    ;
}


object _43get_assigned_sym()
{
    object _30160 = NOVALUE;
    object _30159 = NOVALUE;
    object _30158 = NOVALUE;
    object _30156 = NOVALUE;
    object _30155 = NOVALUE;
    object _30154 = NOVALUE;
    object _30153 = NOVALUE;
    object _30152 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:3416		if not find( Code[$-2], {ASSIGN, ASSIGN_I}) then*/
    if (IS_SEQUENCE(_27Code_20660)){
            _30152 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _30152 = 1;
    }
    _30153 = _30152 - 2LL;
    _30152 = NOVALUE;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _30154 = (object)*(((s1_ptr)_2)->base + _30153);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 18LL;
    ((intptr_t *)_2)[2] = 113LL;
    _30155 = MAKE_SEQ(_1);
    _30156 = find_from(_30154, _30155, 1LL);
    _30154 = NOVALUE;
    DeRefDS(_30155);
    _30155 = NOVALUE;
    if (_30156 != 0)
    goto L1; // [29] 39
    _30156 = NOVALUE;

    /** parser.e:3417			return 0*/
    _30153 = NOVALUE;
    return 0LL;
L1: 

    /** parser.e:3419		return Code[$-1]*/
    if (IS_SEQUENCE(_27Code_20660)){
            _30158 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _30158 = 1;
    }
    _30159 = _30158 - 1LL;
    _30158 = NOVALUE;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _30160 = (object)*(((s1_ptr)_2)->base + _30159);
    Ref(_30160);
    _30159 = NOVALUE;
    DeRef(_30153);
    _30153 = NOVALUE;
    return _30160;
    ;
}


void _43Assign_Constant(object _sym_60562)
{
    object _valsym_60564 = NOVALUE;
    object _val_60567 = NOVALUE;
    object _30187 = NOVALUE;
    object _30186 = NOVALUE;
    object _30184 = NOVALUE;
    object _30183 = NOVALUE;
    object _30182 = NOVALUE;
    object _30180 = NOVALUE;
    object _30179 = NOVALUE;
    object _30178 = NOVALUE;
    object _30176 = NOVALUE;
    object _30175 = NOVALUE;
    object _30174 = NOVALUE;
    object _30172 = NOVALUE;
    object _30171 = NOVALUE;
    object _30170 = NOVALUE;
    object _30168 = NOVALUE;
    object _30166 = NOVALUE;
    object _30164 = NOVALUE;
    object _30162 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:3423		symtab_index valsym = Pop() -- pop the sym for the constant, too*/
    _valsym_60564 = _45Pop();
    if (!IS_ATOM_INT(_valsym_60564)) {
        _1 = (object)(DBL_PTR(_valsym_60564)->dbl);
        DeRefDS(_valsym_60564);
        _valsym_60564 = _1;
    }

    /** parser.e:3424		object val = SymTab[valsym][S_OBJ]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30162 = (object)*(((s1_ptr)_2)->base + _valsym_60564);
    DeRef(_val_60567);
    _2 = (object)SEQ_PTR(_30162);
    _val_60567 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_val_60567);
    _30162 = NOVALUE;

    /** parser.e:3426		SymTab[sym][S_OBJ] = val*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60562 + ((s1_ptr)_2)->base);
    Ref(_val_60567);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _val_60567;
    DeRef(_1);
    _30164 = NOVALUE;

    /** parser.e:3427		SymTab[sym][S_INITLEVEL] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60562 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30166 = NOVALUE;

    /** parser.e:3429		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L1; // [58] 197
    }
    else{
    }

    /** parser.e:3431			SymTab[sym][S_GTYPE] = SymTab[valsym][S_GTYPE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60562 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30170 = (object)*(((s1_ptr)_2)->base + _valsym_60564);
    _2 = (object)SEQ_PTR(_30170);
    _30171 = (object)*(((s1_ptr)_2)->base + 36LL);
    _30170 = NOVALUE;
    Ref(_30171);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30171;
    if( _1 != _30171 ){
        DeRef(_1);
    }
    _30171 = NOVALUE;
    _30168 = NOVALUE;

    /** parser.e:3432			SymTab[sym][S_SEQ_ELEM] = SymTab[valsym][S_SEQ_ELEM]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60562 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30174 = (object)*(((s1_ptr)_2)->base + _valsym_60564);
    _2 = (object)SEQ_PTR(_30174);
    _30175 = (object)*(((s1_ptr)_2)->base + 33LL);
    _30174 = NOVALUE;
    Ref(_30175);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30175;
    if( _1 != _30175 ){
        DeRef(_1);
    }
    _30175 = NOVALUE;
    _30172 = NOVALUE;

    /** parser.e:3433			SymTab[sym][S_OBJ_MIN] = SymTab[valsym][S_OBJ_MIN]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60562 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30178 = (object)*(((s1_ptr)_2)->base + _valsym_60564);
    _2 = (object)SEQ_PTR(_30178);
    _30179 = (object)*(((s1_ptr)_2)->base + 30LL);
    _30178 = NOVALUE;
    Ref(_30179);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30179;
    if( _1 != _30179 ){
        DeRef(_1);
    }
    _30179 = NOVALUE;
    _30176 = NOVALUE;

    /** parser.e:3434			SymTab[sym][S_OBJ_MAX] = SymTab[valsym][S_OBJ_MAX]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60562 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30182 = (object)*(((s1_ptr)_2)->base + _valsym_60564);
    _2 = (object)SEQ_PTR(_30182);
    _30183 = (object)*(((s1_ptr)_2)->base + 31LL);
    _30182 = NOVALUE;
    Ref(_30183);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30183;
    if( _1 != _30183 ){
        DeRef(_1);
    }
    _30183 = NOVALUE;
    _30180 = NOVALUE;

    /** parser.e:3435			SymTab[sym][S_SEQ_LEN] = SymTab[valsym][S_SEQ_LEN]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60562 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30186 = (object)*(((s1_ptr)_2)->base + _valsym_60564);
    _2 = (object)SEQ_PTR(_30186);
    _30187 = (object)*(((s1_ptr)_2)->base + 32LL);
    _30186 = NOVALUE;
    Ref(_30187);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30187;
    if( _1 != _30187 ){
        DeRef(_1);
    }
    _30187 = NOVALUE;
    _30184 = NOVALUE;
L1: 

    /** parser.e:3437	end procedure*/
    DeRef(_val_60567);
    return;
    ;
}


object _43Global_declaration(object _type_ptr_60624, object _scope_60625)
{
    object _new_symbols_60626 = NOVALUE;
    object _tok_60628 = NOVALUE;
    object _tsym_60629 = NOVALUE;
    object _prevtok_60630 = NOVALUE;
    object _sym_60632 = NOVALUE;
    object _valsym_60633 = NOVALUE;
    object _h_60634 = NOVALUE;
    object _count_60635 = NOVALUE;
    object _val_60636 = NOVALUE;
    object _usedval_60637 = NOVALUE;
    object _deltafunc_60638 = NOVALUE;
    object _delta_60639 = NOVALUE;
    object _is_fwd_ref_60640 = NOVALUE;
    object _ptok_60657 = NOVALUE;
    object _negate_60673 = NOVALUE;
    object _negate_60923 = NOVALUE;
    object _32048 = NOVALUE;
    object _32047 = NOVALUE;
    object _32046 = NOVALUE;
    object _30428 = NOVALUE;
    object _30426 = NOVALUE;
    object _30424 = NOVALUE;
    object _30422 = NOVALUE;
    object _30420 = NOVALUE;
    object _30417 = NOVALUE;
    object _30415 = NOVALUE;
    object _30414 = NOVALUE;
    object _30413 = NOVALUE;
    object _30412 = NOVALUE;
    object _30411 = NOVALUE;
    object _30410 = NOVALUE;
    object _30408 = NOVALUE;
    object _30404 = NOVALUE;
    object _30402 = NOVALUE;
    object _30400 = NOVALUE;
    object _30398 = NOVALUE;
    object _30396 = NOVALUE;
    object _30394 = NOVALUE;
    object _30393 = NOVALUE;
    object _30391 = NOVALUE;
    object _30390 = NOVALUE;
    object _30389 = NOVALUE;
    object _30387 = NOVALUE;
    object _30385 = NOVALUE;
    object _30383 = NOVALUE;
    object _30382 = NOVALUE;
    object _30381 = NOVALUE;
    object _30379 = NOVALUE;
    object _30378 = NOVALUE;
    object _30377 = NOVALUE;
    object _30375 = NOVALUE;
    object _30373 = NOVALUE;
    object _30371 = NOVALUE;
    object _30370 = NOVALUE;
    object _30369 = NOVALUE;
    object _30368 = NOVALUE;
    object _30367 = NOVALUE;
    object _30364 = NOVALUE;
    object _30362 = NOVALUE;
    object _30360 = NOVALUE;
    object _30359 = NOVALUE;
    object _30358 = NOVALUE;
    object _30354 = NOVALUE;
    object _30353 = NOVALUE;
    object _30352 = NOVALUE;
    object _30348 = NOVALUE;
    object _30347 = NOVALUE;
    object _30346 = NOVALUE;
    object _30344 = NOVALUE;
    object _30343 = NOVALUE;
    object _30342 = NOVALUE;
    object _30341 = NOVALUE;
    object _30340 = NOVALUE;
    object _30339 = NOVALUE;
    object _30338 = NOVALUE;
    object _30337 = NOVALUE;
    object _30336 = NOVALUE;
    object _30333 = NOVALUE;
    object _30331 = NOVALUE;
    object _30330 = NOVALUE;
    object _30328 = NOVALUE;
    object _30327 = NOVALUE;
    object _30325 = NOVALUE;
    object _30324 = NOVALUE;
    object _30323 = NOVALUE;
    object _30322 = NOVALUE;
    object _30320 = NOVALUE;
    object _30318 = NOVALUE;
    object _30316 = NOVALUE;
    object _30313 = NOVALUE;
    object _30310 = NOVALUE;
    object _30307 = NOVALUE;
    object _30305 = NOVALUE;
    object _30304 = NOVALUE;
    object _30303 = NOVALUE;
    object _30302 = NOVALUE;
    object _30300 = NOVALUE;
    object _30299 = NOVALUE;
    object _30298 = NOVALUE;
    object _30297 = NOVALUE;
    object _30293 = NOVALUE;
    object _30292 = NOVALUE;
    object _30291 = NOVALUE;
    object _30290 = NOVALUE;
    object _30289 = NOVALUE;
    object _30288 = NOVALUE;
    object _30285 = NOVALUE;
    object _30283 = NOVALUE;
    object _30282 = NOVALUE;
    object _30281 = NOVALUE;
    object _30280 = NOVALUE;
    object _30279 = NOVALUE;
    object _30276 = NOVALUE;
    object _30274 = NOVALUE;
    object _30272 = NOVALUE;
    object _30271 = NOVALUE;
    object _30270 = NOVALUE;
    object _30269 = NOVALUE;
    object _30268 = NOVALUE;
    object _30267 = NOVALUE;
    object _30266 = NOVALUE;
    object _30264 = NOVALUE;
    object _30261 = NOVALUE;
    object _30259 = NOVALUE;
    object _30258 = NOVALUE;
    object _30257 = NOVALUE;
    object _30256 = NOVALUE;
    object _30255 = NOVALUE;
    object _30254 = NOVALUE;
    object _30253 = NOVALUE;
    object _30252 = NOVALUE;
    object _30249 = NOVALUE;
    object _30248 = NOVALUE;
    object _30247 = NOVALUE;
    object _30245 = NOVALUE;
    object _30244 = NOVALUE;
    object _30243 = NOVALUE;
    object _30242 = NOVALUE;
    object _30241 = NOVALUE;
    object _30239 = NOVALUE;
    object _30238 = NOVALUE;
    object _30237 = NOVALUE;
    object _30235 = NOVALUE;
    object _30234 = NOVALUE;
    object _30232 = NOVALUE;
    object _30229 = NOVALUE;
    object _30227 = NOVALUE;
    object _30225 = NOVALUE;
    object _30217 = NOVALUE;
    object _30216 = NOVALUE;
    object _30214 = NOVALUE;
    object _30211 = NOVALUE;
    object _30203 = NOVALUE;
    object _30200 = NOVALUE;
    object _30199 = NOVALUE;
    object _30197 = NOVALUE;
    object _30193 = NOVALUE;
    object _30192 = NOVALUE;
    object _30191 = NOVALUE;
    object _30190 = NOVALUE;
    object _30189 = NOVALUE;
    object _30188 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_type_ptr_60624)) {
        _1 = (object)(DBL_PTR(_type_ptr_60624)->dbl);
        DeRefDS(_type_ptr_60624);
        _type_ptr_60624 = _1;
    }

    /** parser.e:3447		object tsym*/

    /** parser.e:3448		object prevtok = 0*/
    DeRef(_prevtok_60630);
    _prevtok_60630 = 0LL;

    /** parser.e:3450		integer h, count = 0*/
    _count_60635 = 0LL;

    /** parser.e:3451		atom val = 1, usedval*/
    DeRef(_val_60636);
    _val_60636 = 1LL;

    /** parser.e:3452		integer deltafunc = '+'*/
    _deltafunc_60638 = 43LL;

    /** parser.e:3453		atom delta = 1*/
    DeRef(_delta_60639);
    _delta_60639 = 1LL;

    /** parser.e:3455		new_symbols = {}*/
    RefDS(_22218);
    DeRefi(_new_symbols_60626);
    _new_symbols_60626 = _22218;

    /** parser.e:3456		integer is_fwd_ref = 0*/
    _is_fwd_ref_60640 = 0LL;

    /** parser.e:3457		if type_ptr > 0 and SymTab[type_ptr][S_SCOPE] = SC_UNDEFINED then*/
    _30188 = (_type_ptr_60624 > 0LL);
    if (_30188 == 0) {
        goto L1; // [50] 105
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30190 = (object)*(((s1_ptr)_2)->base + _type_ptr_60624);
    _2 = (object)SEQ_PTR(_30190);
    _30191 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30190 = NOVALUE;
    if (IS_ATOM_INT(_30191)) {
        _30192 = (_30191 == 9LL);
    }
    else {
        _30192 = binary_op(EQUALS, _30191, 9LL);
    }
    _30191 = NOVALUE;
    if (_30192 == 0) {
        DeRef(_30192);
        _30192 = NOVALUE;
        goto L1; // [73] 105
    }
    else {
        if (!IS_ATOM_INT(_30192) && DBL_PTR(_30192)->dbl == 0.0){
            DeRef(_30192);
            _30192 = NOVALUE;
            goto L1; // [73] 105
        }
        DeRef(_30192);
        _30192 = NOVALUE;
    }
    DeRef(_30192);
    _30192 = NOVALUE;

    /** parser.e:3458			is_fwd_ref = 1*/
    _is_fwd_ref_60640 = 1LL;

    /** parser.e:3459			Hide(type_ptr)*/
    _53Hide(_type_ptr_60624);

    /** parser.e:3460			type_ptr = -new_forward_reference( TYPE, type_ptr )*/
    DeRef(_32048);
    _32048 = 504LL;
    _30193 = _42new_forward_reference(504LL, _type_ptr_60624, 504LL);
    _32048 = NOVALUE;
    if (IS_ATOM_INT(_30193)) {
        if ((uintptr_t)_30193 == (uintptr_t)HIGH_BITS){
            _type_ptr_60624 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _type_ptr_60624 = - _30193;
        }
    }
    else {
        _type_ptr_60624 = unary_op(UMINUS, _30193);
    }
    DeRef(_30193);
    _30193 = NOVALUE;
    if (!IS_ATOM_INT(_type_ptr_60624)) {
        _1 = (object)(DBL_PTR(_type_ptr_60624)->dbl);
        DeRefDS(_type_ptr_60624);
        _type_ptr_60624 = _1;
    }
L1: 

    /** parser.e:3463		if type_ptr = -1 then*/
    if (_type_ptr_60624 != -1LL)
    goto L2; // [107] 426

    /** parser.e:3465			sequence ptok = next_token()*/
    _0 = _ptok_60657;
    _ptok_60657 = _43next_token();
    DeRef(_0);

    /** parser.e:3466			if ptok[T_ID] = TYPE_DECL then*/
    _2 = (object)SEQ_PTR(_ptok_60657);
    _30197 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30197, 416LL)){
        _30197 = NOVALUE;
        goto L3; // [128] 172
    }
    _30197 = NOVALUE;

    /** parser.e:3469				putback(keyfind("enum",-1))*/
    RefDS(_26534);
    DeRef(_32046);
    _32046 = _26534;
    _32047 = _53hashfn(_32046);
    _32046 = NOVALUE;
    RefDS(_26534);
    _30199 = _53keyfind(_26534, -1LL, _27current_file_no_20571, 0LL, _32047);
    _32047 = NOVALUE;
    _43putback(_30199);
    _30199 = NOVALUE;

    /** parser.e:3470				SubProg(TYPE_DECL, scope, 0)*/
    _43SubProg(416LL, _scope_60625, 0LL);

    /** parser.e:3471				return {}*/
    RefDS(_22218);
    DeRefDS(_ptok_60657);
    DeRefi(_new_symbols_60626);
    DeRef(_tok_60628);
    DeRef(_tsym_60629);
    DeRef(_prevtok_60630);
    DeRef(_val_60636);
    DeRef(_usedval_60637);
    DeRef(_delta_60639);
    DeRef(_30188);
    _30188 = NOVALUE;
    return _22218;
    goto L4; // [169] 425
L3: 

    /** parser.e:3472			elsif ptok[T_ID] = BY then*/
    _2 = (object)SEQ_PTR(_ptok_60657);
    _30200 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30200, 404LL)){
        _30200 = NOVALUE;
        goto L5; // [182] 419
    }
    _30200 = NOVALUE;

    /** parser.e:3474				integer negate = 0*/
    _negate_60673 = 0LL;

    /** parser.e:3475				ptok = next_token()*/
    _0 = _ptok_60657;
    _ptok_60657 = _43next_token();
    DeRefDS(_0);

    /** parser.e:3476				switch ptok[T_ID] do*/
    _2 = (object)SEQ_PTR(_ptok_60657);
    _30203 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_30203) ){
        goto L6; // [206] 285
    }
    if(!IS_ATOM_INT(_30203)){
        if( (DBL_PTR(_30203)->dbl != (eudouble) ((object) DBL_PTR(_30203)->dbl) ) ){
            goto L6; // [206] 285
        }
        _0 = (object) DBL_PTR(_30203)->dbl;
    }
    else {
        _0 = _30203;
    };
    _30203 = NOVALUE;
    switch ( _0 ){ 

        /** parser.e:3477					case reserved:MULTIPLY then*/
        case 13:

        /** parser.e:3478						deltafunc = '*'*/
        _deltafunc_60638 = 42LL;

        /** parser.e:3479						ptok = next_token()*/
        _0 = _ptok_60657;
        _ptok_60657 = _43next_token();
        DeRef(_0);
        goto L7; // [227] 293

        /** parser.e:3481					case reserved:DIVIDE then*/
        case 14:

        /** parser.e:3482						deltafunc = '/'*/
        _deltafunc_60638 = 47LL;

        /** parser.e:3483						ptok = next_token()*/
        _0 = _ptok_60657;
        _ptok_60657 = _43next_token();
        DeRef(_0);
        goto L7; // [245] 293

        /** parser.e:3485					case MINUS then*/
        case 10:

        /** parser.e:3486						deltafunc = '-'*/
        _deltafunc_60638 = 45LL;

        /** parser.e:3487						ptok = next_token()*/
        _0 = _ptok_60657;
        _ptok_60657 = _43next_token();
        DeRef(_0);
        goto L7; // [263] 293

        /** parser.e:3489					case PLUS then*/
        case 11:

        /** parser.e:3490						deltafunc = '+'*/
        _deltafunc_60638 = 43LL;

        /** parser.e:3491						ptok = next_token()*/
        _0 = _ptok_60657;
        _ptok_60657 = _43next_token();
        DeRef(_0);
        goto L7; // [281] 293

        /** parser.e:3493					case else*/
        default:
L6: 

        /** parser.e:3494						deltafunc = '+'*/
        _deltafunc_60638 = 43LL;
    ;}L7: 

    /** parser.e:3498				if ptok[T_ID] = MINUS then*/
    _2 = (object)SEQ_PTR(_ptok_60657);
    _30211 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30211, 10LL)){
        _30211 = NOVALUE;
        goto L8; // [303] 320
    }
    _30211 = NOVALUE;

    /** parser.e:3499					negate = 1*/
    _negate_60673 = 1LL;

    /** parser.e:3500					ptok = next_token()*/
    _0 = _ptok_60657;
    _ptok_60657 = _43next_token();
    DeRefDS(_0);
L8: 

    /** parser.e:3502				if ptok[T_ID] != ATOM then*/
    _2 = (object)SEQ_PTR(_ptok_60657);
    _30214 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _30214, 502LL)){
        _30214 = NOVALUE;
        goto L9; // [330] 344
    }
    _30214 = NOVALUE;

    /** parser.e:3503					CompileErr( A_NUMERIC_LITERAL_WAS_EXPECTED)*/
    RefDS(_22218);
    _49CompileErr(344LL, _22218, 0LL);
L9: 

    /** parser.e:3506				delta = SymTab[ptok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_ptok_60657);
    _30216 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30216)){
        _30217 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30216)->dbl));
    }
    else{
        _30217 = (object)*(((s1_ptr)_2)->base + _30216);
    }
    DeRef(_delta_60639);
    _2 = (object)SEQ_PTR(_30217);
    _delta_60639 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_delta_60639);
    _30217 = NOVALUE;

    /** parser.e:3507				if negate then*/
    if (_negate_60673 == 0)
    {
        goto LA; // [366] 375
    }
    else{
    }

    /** parser.e:3508					delta = -delta*/
    _0 = _delta_60639;
    if (IS_ATOM_INT(_delta_60639)) {
        if ((uintptr_t)_delta_60639 == (uintptr_t)HIGH_BITS){
            _delta_60639 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _delta_60639 = - _delta_60639;
        }
    }
    else {
        _delta_60639 = unary_op(UMINUS, _delta_60639);
    }
    DeRef(_0);
LA: 

    /** parser.e:3511				switch deltafunc do*/
    _0 = _deltafunc_60638;
    switch ( _0 ){ 

        /** parser.e:3512					case '/' then*/
        case 47:

        /** parser.e:3513						delta = 1 / delta*/
        _0 = _delta_60639;
        if (IS_ATOM_INT(_delta_60639)) {
            _delta_60639 = (1LL % _delta_60639) ? NewDouble((eudouble)1LL / _delta_60639) : (1LL / _delta_60639);
        }
        else {
            _delta_60639 = NewDouble((eudouble)1LL / DBL_PTR(_delta_60639)->dbl);
        }
        DeRef(_0);

        /** parser.e:3514						deltafunc = '*'*/
        _deltafunc_60638 = 42LL;
        goto LB; // [397] 414

        /** parser.e:3516					case '-' then*/
        case 45:

        /** parser.e:3517						delta = -delta*/
        _0 = _delta_60639;
        if (IS_ATOM_INT(_delta_60639)) {
            if ((uintptr_t)_delta_60639 == (uintptr_t)HIGH_BITS){
                _delta_60639 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _delta_60639 = - _delta_60639;
            }
        }
        else {
            _delta_60639 = unary_op(UMINUS, _delta_60639);
        }
        DeRef(_0);

        /** parser.e:3518						deltafunc = '+'*/
        _deltafunc_60638 = 43LL;
    ;}LB: 
    goto L4; // [416] 425
L5: 

    /** parser.e:3523				putback(ptok)*/
    RefDS(_ptok_60657);
    _43putback(_ptok_60657);
L4: 
L2: 
    DeRef(_ptok_60657);
    _ptok_60657 = NOVALUE;

    /** parser.e:3527		valsym = 0*/
    _valsym_60633 = 0LL;

    /** parser.e:3528		while TRUE do*/
LC: 
    if (_9TRUE_441 == 0)
    {
        goto LD; // [442] 2303
    }
    else{
    }

    /** parser.e:3529			tok = next_token()*/
    _0 = _tok_60628;
    _tok_60628 = _43next_token();
    DeRef(_0);

    /** parser.e:3530			if tok[T_ID] = DOLLAR then*/
    _2 = (object)SEQ_PTR(_tok_60628);
    _30225 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30225, -22LL)){
        _30225 = NOVALUE;
        goto LE; // [460] 499
    }
    _30225 = NOVALUE;

    /** parser.e:3531				if not equal(prevtok, 0) then*/
    if (_prevtok_60630 == 0LL)
    _30227 = 1;
    else if (IS_ATOM_INT(_prevtok_60630) && IS_ATOM_INT(0LL))
    _30227 = 0;
    else
    _30227 = (compare(_prevtok_60630, 0LL) == 0);
    if (_30227 != 0)
    goto LF; // [470] 498
    _30227 = NOVALUE;

    /** parser.e:3532					if prevtok[T_ID] = COMMA then*/
    _2 = (object)SEQ_PTR(_prevtok_60630);
    _30229 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30229, -30LL)){
        _30229 = NOVALUE;
        goto L10; // [483] 497
    }
    _30229 = NOVALUE;

    /** parser.e:3534						tok = next_token()*/
    _0 = _tok_60628;
    _tok_60628 = _43next_token();
    DeRef(_0);

    /** parser.e:3535						exit*/
    goto LD; // [494] 2303
L10: 
LF: 
LE: 

    /** parser.e:3539			if tok[T_ID] = END_OF_FILE then*/
    _2 = (object)SEQ_PTR(_tok_60628);
    _30232 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30232, -21LL)){
        _30232 = NOVALUE;
        goto L11; // [509] 523
    }
    _30232 = NOVALUE;

    /** parser.e:3540				CompileErr( AN_IDENTIFIER_IS_EXPECTED_HERE)*/
    RefDS(_22218);
    _49CompileErr(32LL, _22218, 0LL);
L11: 

    /** parser.e:3543			if not find(tok[T_ID], ADDR_TOKS) then*/
    _2 = (object)SEQ_PTR(_tok_60628);
    _30234 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30235 = find_from(_30234, _29ADDR_TOKS_12281, 1LL);
    _30234 = NOVALUE;
    if (_30235 != 0)
    goto L12; // [538] 565
    _30235 = NOVALUE;

    /** parser.e:3544				CompileErr(FOUND__1__BUT_WAS_EXPECTING_AN_IDENTIFIER_NAME, {find_category(tok[T_ID])} )*/
    _2 = (object)SEQ_PTR(_tok_60628);
    _30237 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_30237);
    _30238 = _62find_category(_30237);
    _30237 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30238;
    _30239 = MAKE_SEQ(_1);
    _30238 = NOVALUE;
    _49CompileErr(25LL, _30239, 0LL);
    _30239 = NOVALUE;
L12: 

    /** parser.e:3546			sym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_60628);
    _sym_60632 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_sym_60632)){
        _sym_60632 = (object)DBL_PTR(_sym_60632)->dbl;
    }

    /** parser.e:3547			DefinedYet(sym)*/
    _53DefinedYet(_sym_60632);

    /** parser.e:3548			if find(SymTab[sym][S_SCOPE], {SC_GLOBAL, SC_PREDEF, SC_PUBLIC, SC_EXPORT}) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30241 = (object)*(((s1_ptr)_2)->base + _sym_60632);
    _2 = (object)SEQ_PTR(_30241);
    _30242 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30241 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 6LL;
    ((intptr_t*)_2)[2] = 7LL;
    ((intptr_t*)_2)[3] = 13LL;
    ((intptr_t*)_2)[4] = 11LL;
    _30243 = MAKE_SEQ(_1);
    _30244 = find_from(_30242, _30243, 1LL);
    _30242 = NOVALUE;
    DeRefDS(_30243);
    _30243 = NOVALUE;
    if (_30244 == 0)
    {
        _30244 = NOVALUE;
        goto L13; // [614] 676
    }
    else{
        _30244 = NOVALUE;
    }

    /** parser.e:3549				h = SymTab[sym][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30245 = (object)*(((s1_ptr)_2)->base + _sym_60632);
    _2 = (object)SEQ_PTR(_30245);
    _h_60634 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (!IS_ATOM_INT(_h_60634)){
        _h_60634 = (object)DBL_PTR(_h_60634)->dbl;
    }
    _30245 = NOVALUE;

    /** parser.e:3551				sym = NewEntry(SymTab[sym][S_NAME], 0, 0, VARIABLE, h, buckets[h], 0)*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30247 = (object)*(((s1_ptr)_2)->base + _sym_60632);
    _2 = (object)SEQ_PTR(_30247);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _30248 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _30248 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _30247 = NOVALUE;
    _2 = (object)SEQ_PTR(_53buckets_47223);
    _30249 = (object)*(((s1_ptr)_2)->base + _h_60634);
    Ref(_30248);
    Ref(_30249);
    _sym_60632 = _53NewEntry(_30248, 0LL, 0LL, -100LL, _h_60634, _30249, 0LL);
    _30248 = NOVALUE;
    _30249 = NOVALUE;
    if (!IS_ATOM_INT(_sym_60632)) {
        _1 = (object)(DBL_PTR(_sym_60632)->dbl);
        DeRefDS(_sym_60632);
        _sym_60632 = _1;
    }

    /** parser.e:3552				buckets[h] = sym*/
    _2 = (object)SEQ_PTR(_53buckets_47223);
    _2 = (object)(((s1_ptr)_2)->base + _h_60634);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_60632;
    DeRef(_1);
L13: 

    /** parser.e:3555			new_symbols = append(new_symbols, sym)*/
    Append(&_new_symbols_60626, _new_symbols_60626, _sym_60632);

    /** parser.e:3556			Block_var( sym )*/
    _64Block_var(_sym_60632);

    /** parser.e:3557			if SymTab[sym][S_SCOPE] = SC_UNDEFINED and SymTab[sym][S_FILE_NO] != current_file_no then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30252 = (object)*(((s1_ptr)_2)->base + _sym_60632);
    _2 = (object)SEQ_PTR(_30252);
    _30253 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30252 = NOVALUE;
    if (IS_ATOM_INT(_30253)) {
        _30254 = (_30253 == 9LL);
    }
    else {
        _30254 = binary_op(EQUALS, _30253, 9LL);
    }
    _30253 = NOVALUE;
    if (IS_ATOM_INT(_30254)) {
        if (_30254 == 0) {
            goto L14; // [707] 751
        }
    }
    else {
        if (DBL_PTR(_30254)->dbl == 0.0) {
            goto L14; // [707] 751
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30256 = (object)*(((s1_ptr)_2)->base + _sym_60632);
    _2 = (object)SEQ_PTR(_30256);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _30257 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _30257 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _30256 = NOVALUE;
    if (IS_ATOM_INT(_30257)) {
        _30258 = (_30257 != _27current_file_no_20571);
    }
    else {
        _30258 = binary_op(NOTEQ, _30257, _27current_file_no_20571);
    }
    _30257 = NOVALUE;
    if (_30258 == 0) {
        DeRef(_30258);
        _30258 = NOVALUE;
        goto L14; // [730] 751
    }
    else {
        if (!IS_ATOM_INT(_30258) && DBL_PTR(_30258)->dbl == 0.0){
            DeRef(_30258);
            _30258 = NOVALUE;
            goto L14; // [730] 751
        }
        DeRef(_30258);
        _30258 = NOVALUE;
    }
    DeRef(_30258);
    _30258 = NOVALUE;

    /** parser.e:3558				SymTab[sym][S_FILE_NO] = current_file_no*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60632 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_FILE_NO_20205))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27current_file_no_20571;
    DeRef(_1);
    _30259 = NOVALUE;
L14: 

    /** parser.e:3560			SymTab[sym][S_SCOPE] = scope*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60632 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _scope_60625;
    DeRef(_1);
    _30261 = NOVALUE;

    /** parser.e:3562			if type_ptr = 0 then*/
    if (_type_ptr_60624 != 0LL)
    goto L15; // [768] 1103

    /** parser.e:3564				SymTab[sym][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60632 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _30264 = NOVALUE;

    /** parser.e:3566				buckets[SymTab[sym][S_HASHVAL]] = SymTab[sym][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30266 = (object)*(((s1_ptr)_2)->base + _sym_60632);
    _2 = (object)SEQ_PTR(_30266);
    _30267 = (object)*(((s1_ptr)_2)->base + 11LL);
    _30266 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30268 = (object)*(((s1_ptr)_2)->base + _sym_60632);
    _2 = (object)SEQ_PTR(_30268);
    _30269 = (object)*(((s1_ptr)_2)->base + 9LL);
    _30268 = NOVALUE;
    Ref(_30269);
    _2 = (object)SEQ_PTR(_53buckets_47223);
    if (!IS_ATOM_INT(_30267))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_30267)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _30267);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30269;
    if( _1 != _30269 ){
        DeRef(_1);
    }
    _30269 = NOVALUE;

    /** parser.e:3567				tok_match(EQUALS)*/
    _43tok_match(3LL, 0LL);

    /** parser.e:3568				StartSourceLine(FALSE, , COVERAGE_OVERRIDE)*/
    _45StartSourceLine(_9FALSE_439, 0LL, 3LL);

    /** parser.e:3569				emit_opnd(sym)*/
    _45emit_opnd(_sym_60632);

    /** parser.e:3570				Expr()  -- no new symbols can be defined in here*/
    _43Expr();

    /** parser.e:3571				buckets[SymTab[sym][S_HASHVAL]] = sym*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30270 = (object)*(((s1_ptr)_2)->base + _sym_60632);
    _2 = (object)SEQ_PTR(_30270);
    _30271 = (object)*(((s1_ptr)_2)->base + 11LL);
    _30270 = NOVALUE;
    _2 = (object)SEQ_PTR(_53buckets_47223);
    if (!IS_ATOM_INT(_30271))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_30271)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _30271);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_60632;
    DeRef(_1);

    /** parser.e:3572				SymTab[sym][S_USAGE] = U_WRITTEN*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60632 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _30272 = NOVALUE;

    /** parser.e:3573				if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L16; // [890] 928
    }
    else{
    }

    /** parser.e:3574					SymTab[sym][S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60632 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);
    _30274 = NOVALUE;

    /** parser.e:3575					SymTab[sym][S_OBJ] = NOVALUE     -- distinguish from literals*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60632 + ((s1_ptr)_2)->base);
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
    _30276 = NOVALUE;
L16: 

    /** parser.e:3577				valsym = Top()*/
    _valsym_60633 = _45Top();
    if (!IS_ATOM_INT(_valsym_60633)) {
        _1 = (object)(DBL_PTR(_valsym_60633)->dbl);
        DeRefDS(_valsym_60633);
        _valsym_60633 = _1;
    }

    /** parser.e:3579				if valsym > 0 and compare( SymTab[valsym][S_OBJ], NOVALUE ) then*/
    _30279 = (_valsym_60633 > 0LL);
    if (_30279 == 0) {
        goto L17; // [941] 982
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30281 = (object)*(((s1_ptr)_2)->base + _valsym_60633);
    _2 = (object)SEQ_PTR(_30281);
    _30282 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30281 = NOVALUE;
    if (IS_ATOM_INT(_30282) && IS_ATOM_INT(_27NOVALUE_20426)){
        _30283 = (_30282 < _27NOVALUE_20426) ? -1 : (_30282 > _27NOVALUE_20426);
    }
    else{
        _30283 = compare(_30282, _27NOVALUE_20426);
    }
    _30282 = NOVALUE;
    if (_30283 == 0)
    {
        _30283 = NOVALUE;
        goto L17; // [964] 982
    }
    else{
        _30283 = NOVALUE;
    }

    /** parser.e:3580					Assign_Constant( sym )*/
    _43Assign_Constant(_sym_60632);

    /** parser.e:3581					sym = Pop()*/
    _sym_60632 = _45Pop();
    if (!IS_ATOM_INT(_sym_60632)) {
        _1 = (object)(DBL_PTR(_sym_60632)->dbl);
        DeRefDS(_sym_60632);
        _sym_60632 = _1;
    }
    goto L18; // [979] 2269
L17: 

    /** parser.e:3584					emit_op(ASSIGN)*/
    _45emit_op(18LL);

    /** parser.e:3585					if Last_op() = ASSIGN then*/
    _30285 = _45Last_op();
    if (binary_op_a(NOTEQ, _30285, 18LL)){
        DeRef(_30285);
        _30285 = NOVALUE;
        goto L19; // [996] 1010
    }
    DeRef(_30285);
    _30285 = NOVALUE;

    /** parser.e:3586						valsym = get_assigned_sym()*/
    _valsym_60633 = _43get_assigned_sym();
    if (!IS_ATOM_INT(_valsym_60633)) {
        _1 = (object)(DBL_PTR(_valsym_60633)->dbl);
        DeRefDS(_valsym_60633);
        _valsym_60633 = _1;
    }
    goto L1A; // [1007] 1018
L19: 

    /** parser.e:3589						valsym = -1*/
    _valsym_60633 = -1LL;
L1A: 

    /** parser.e:3591					if valsym > 0 and compare( SymTab[valsym][S_OBJ], NOVALUE ) then*/
    _30288 = (_valsym_60633 > 0LL);
    if (_30288 == 0) {
        goto L1B; // [1024] 1066
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30290 = (object)*(((s1_ptr)_2)->base + _valsym_60633);
    _2 = (object)SEQ_PTR(_30290);
    _30291 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30290 = NOVALUE;
    if (IS_ATOM_INT(_30291) && IS_ATOM_INT(_27NOVALUE_20426)){
        _30292 = (_30291 < _27NOVALUE_20426) ? -1 : (_30291 > _27NOVALUE_20426);
    }
    else{
        _30292 = compare(_30291, _27NOVALUE_20426);
    }
    _30291 = NOVALUE;
    if (_30292 == 0)
    {
        _30292 = NOVALUE;
        goto L1B; // [1047] 1066
    }
    else{
        _30292 = NOVALUE;
    }

    /** parser.e:3593						SymTab[sym][S_CODE] = valsym*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60632 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _valsym_60633;
    DeRef(_1);
    _30293 = NOVALUE;
L1B: 

    /** parser.e:3596					if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L18; // [1070] 2269
    }
    else{
    }

    /** parser.e:3597						count += 1*/
    _count_60635 = _count_60635 + 1;

    /** parser.e:3598						if count = 10 then*/
    if (_count_60635 != 10LL)
    goto L18; // [1081] 2269

    /** parser.e:3599							count = 0*/
    _count_60635 = 0LL;

    /** parser.e:3601							emit_op( RETURNT )*/
    _45emit_op(34LL);
    goto L18; // [1100] 2269
L15: 

    /** parser.e:3606			elsif type_ptr = -1 and not is_fwd_ref then*/
    _30297 = (_type_ptr_60624 == -1LL);
    if (_30297 == 0) {
        goto L1C; // [1109] 2096
    }
    _30299 = (_is_fwd_ref_60640 == 0);
    if (_30299 == 0)
    {
        DeRef(_30299);
        _30299 = NOVALUE;
        goto L1C; // [1117] 2096
    }
    else{
        DeRef(_30299);
        _30299 = NOVALUE;
    }

    /** parser.e:3608				StartSourceLine(FALSE, , COVERAGE_OVERRIDE )*/
    _45StartSourceLine(_9FALSE_439, 0LL, 3LL);

    /** parser.e:3609				SymTab[sym][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60632 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _30300 = NOVALUE;

    /** parser.e:3611				buckets[SymTab[sym][S_HASHVAL]] = SymTab[sym][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30302 = (object)*(((s1_ptr)_2)->base + _sym_60632);
    _2 = (object)SEQ_PTR(_30302);
    _30303 = (object)*(((s1_ptr)_2)->base + 11LL);
    _30302 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30304 = (object)*(((s1_ptr)_2)->base + _sym_60632);
    _2 = (object)SEQ_PTR(_30304);
    _30305 = (object)*(((s1_ptr)_2)->base + 9LL);
    _30304 = NOVALUE;
    Ref(_30305);
    _2 = (object)SEQ_PTR(_53buckets_47223);
    if (!IS_ATOM_INT(_30303))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_30303)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _30303);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30305;
    if( _1 != _30305 ){
        DeRef(_1);
    }
    _30305 = NOVALUE;

    /** parser.e:3612				tok = next_token()*/
    _0 = _tok_60628;
    _tok_60628 = _43next_token();
    DeRef(_0);

    /** parser.e:3615				emit_opnd(sym)*/
    _45emit_opnd(_sym_60632);

    /** parser.e:3617				if tok[T_ID] = EQUALS then*/
    _2 = (object)SEQ_PTR(_tok_60628);
    _30307 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30307, 3LL)){
        _30307 = NOVALUE;
        goto L1D; // [1200] 1607
    }
    _30307 = NOVALUE;

    /** parser.e:3618					integer negate = 1*/
    _negate_60923 = 1LL;

    /** parser.e:3620					tok = next_token()*/
    _0 = _tok_60628;
    _tok_60628 = _43next_token();
    DeRef(_0);

    /** parser.e:3621					if tok[T_ID] = MINUS then*/
    _2 = (object)SEQ_PTR(_tok_60628);
    _30310 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30310, 10LL)){
        _30310 = NOVALUE;
        goto L1E; // [1224] 1239
    }
    _30310 = NOVALUE;

    /** parser.e:3622						negate = -1*/
    _negate_60923 = -1LL;

    /** parser.e:3623						tok = next_token()*/
    _0 = _tok_60628;
    _tok_60628 = _43next_token();
    DeRef(_0);
L1E: 

    /** parser.e:3626					if tok[T_ID] = ATOM then*/
    _2 = (object)SEQ_PTR(_tok_60628);
    _30313 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30313, 502LL)){
        _30313 = NOVALUE;
        goto L1F; // [1249] 1266
    }
    _30313 = NOVALUE;

    /** parser.e:3627						valsym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_60628);
    _valsym_60633 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_valsym_60633)){
        _valsym_60633 = (object)DBL_PTR(_valsym_60633)->dbl;
    }
    goto L20; // [1263] 1464
L1F: 

    /** parser.e:3628					elsif tok[T_SYM] > 0 then*/
    _2 = (object)SEQ_PTR(_tok_60628);
    _30316 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (binary_op_a(LESSEQ, _30316, 0LL)){
        _30316 = NOVALUE;
        goto L21; // [1274] 1454
    }
    _30316 = NOVALUE;

    /** parser.e:3629						tsym = SymTab[tok[T_SYM]]*/
    _2 = (object)SEQ_PTR(_tok_60628);
    _30318 = (object)*(((s1_ptr)_2)->base + 2LL);
    DeRef(_tsym_60629);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30318)){
        _tsym_60629 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30318)->dbl));
    }
    else{
        _tsym_60629 = (object)*(((s1_ptr)_2)->base + _30318);
    }
    Ref(_tsym_60629);

    /** parser.e:3630						if tsym[S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_tsym_60629);
    _30320 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (binary_op_a(NOTEQ, _30320, 2LL)){
        _30320 = NOVALUE;
        goto L22; // [1302] 1415
    }
    _30320 = NOVALUE;

    /** parser.e:3631							if length(tsym) >= S_CODE and tsym[S_CODE] then*/
    if (IS_SEQUENCE(_tsym_60629)){
            _30322 = SEQ_PTR(_tsym_60629)->length;
    }
    else {
        _30322 = 1;
    }
    if (IS_ATOM_INT(_27S_CODE_20221)) {
        _30323 = (_30322 >= _27S_CODE_20221);
    }
    else {
        _30323 = binary_op(GREATEREQ, _30322, _27S_CODE_20221);
    }
    _30322 = NOVALUE;
    if (IS_ATOM_INT(_30323)) {
        if (_30323 == 0) {
            goto L23; // [1317] 1344
        }
    }
    else {
        if (DBL_PTR(_30323)->dbl == 0.0) {
            goto L23; // [1317] 1344
        }
    }
    _2 = (object)SEQ_PTR(_tsym_60629);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _30325 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _30325 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    if (_30325 == 0) {
        _30325 = NOVALUE;
        goto L23; // [1328] 1344
    }
    else {
        if (!IS_ATOM_INT(_30325) && DBL_PTR(_30325)->dbl == 0.0){
            _30325 = NOVALUE;
            goto L23; // [1328] 1344
        }
        _30325 = NOVALUE;
    }
    _30325 = NOVALUE;

    /** parser.e:3632								valsym = tsym[S_CODE]*/
    _2 = (object)SEQ_PTR(_tsym_60629);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _valsym_60633 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _valsym_60633 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    if (!IS_ATOM_INT(_valsym_60633)){
        _valsym_60633 = (object)DBL_PTR(_valsym_60633)->dbl;
    }
    goto L20; // [1341] 1464
L23: 

    /** parser.e:3634							elsif not equal( tsym[S_OBJ], NOVALUE ) then*/
    _2 = (object)SEQ_PTR(_tsym_60629);
    _30327 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (_30327 == _27NOVALUE_20426)
    _30328 = 1;
    else if (IS_ATOM_INT(_30327) && IS_ATOM_INT(_27NOVALUE_20426))
    _30328 = 0;
    else
    _30328 = (compare(_30327, _27NOVALUE_20426) == 0);
    _30327 = NOVALUE;
    if (_30328 != 0)
    goto L24; // [1358] 1402
    _30328 = NOVALUE;

    /** parser.e:3635								if is_integer(tsym[S_OBJ]) then*/
    _2 = (object)SEQ_PTR(_tsym_60629);
    _30330 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_30330);
    _30331 = _27is_integer(_30330);
    _30330 = NOVALUE;
    if (_30331 == 0) {
        DeRef(_30331);
        _30331 = NOVALUE;
        goto L25; // [1373] 1389
    }
    else {
        if (!IS_ATOM_INT(_30331) && DBL_PTR(_30331)->dbl == 0.0){
            DeRef(_30331);
            _30331 = NOVALUE;
            goto L25; // [1373] 1389
        }
        DeRef(_30331);
        _30331 = NOVALUE;
    }
    DeRef(_30331);
    _30331 = NOVALUE;

    /** parser.e:3636									valsym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_60628);
    _valsym_60633 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_valsym_60633)){
        _valsym_60633 = (object)DBL_PTR(_valsym_60633)->dbl;
    }
    goto L20; // [1386] 1464
L25: 

    /** parser.e:3638									CompileErr(AN_ENUM_CONSTANT_MUST_BE_AN_INTEGER)*/
    RefDS(_22218);
    _49CompileErr(30LL, _22218, 0LL);
    goto L20; // [1399] 1464
L24: 

    /** parser.e:3641								CompileErr(ENUM_CONSTANTS_MUST_BE_ASSIGNED_AN_INTEGER)*/
    RefDS(_22218);
    _49CompileErr(70LL, _22218, 0LL);
    goto L20; // [1412] 1464
L22: 

    /** parser.e:3643						elsif tsym[S_OBJ] = NOVALUE then*/
    _2 = (object)SEQ_PTR(_tsym_60629);
    _30333 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30333, _27NOVALUE_20426)){
        _30333 = NOVALUE;
        goto L26; // [1425] 1441
    }
    _30333 = NOVALUE;

    /** parser.e:3645							CompileErr(ENUM_FWD_REFERENCES_NOT_SUPPORTED)*/
    RefDS(_22218);
    _49CompileErr(331LL, _22218, 0LL);
    goto L20; // [1438] 1464
L26: 

    /** parser.e:3647							CompileErr(INTEGER_OR_CONSTANT_EXPECTED)*/
    RefDS(_22218);
    _49CompileErr(99LL, _22218, 0LL);
    goto L20; // [1451] 1464
L21: 

    /** parser.e:3651							CompileErr(INTEGER_OR_CONSTANT_EXPECTED)*/
    RefDS(_22218);
    _49CompileErr(99LL, _22218, 0LL);
L20: 

    /** parser.e:3653					valsym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_60628);
    _valsym_60633 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_valsym_60633)){
        _valsym_60633 = (object)DBL_PTR(_valsym_60633)->dbl;
    }

    /** parser.e:3654					if not atom( SymTab[valsym][S_OBJ] ) and tsym[S_SCOPE] != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30336 = (object)*(((s1_ptr)_2)->base + _valsym_60633);
    _2 = (object)SEQ_PTR(_30336);
    _30337 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30336 = NOVALUE;
    _30338 = IS_ATOM(_30337);
    _30337 = NOVALUE;
    _30339 = (_30338 == 0);
    _30338 = NOVALUE;
    if (_30339 == 0) {
        goto L27; // [1494] 1526
    }
    _2 = (object)SEQ_PTR(_tsym_60629);
    _30341 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_30341)) {
        _30342 = (_30341 != 9LL);
    }
    else {
        _30342 = binary_op(NOTEQ, _30341, 9LL);
    }
    _30341 = NOVALUE;
    if (_30342 == 0) {
        DeRef(_30342);
        _30342 = NOVALUE;
        goto L27; // [1513] 1526
    }
    else {
        if (!IS_ATOM_INT(_30342) && DBL_PTR(_30342)->dbl == 0.0){
            DeRef(_30342);
            _30342 = NOVALUE;
            goto L27; // [1513] 1526
        }
        DeRef(_30342);
        _30342 = NOVALUE;
    }
    DeRef(_30342);
    _30342 = NOVALUE;

    /** parser.e:3655						CompileErr(ENUM_CONSTANTS_MUST_BE_INTEGERS)*/
    RefDS(_22218);
    _49CompileErr(84LL, _22218, 0LL);
L27: 

    /** parser.e:3657					val = SymTab[valsym][S_OBJ] * negate*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30343 = (object)*(((s1_ptr)_2)->base + _valsym_60633);
    _2 = (object)SEQ_PTR(_30343);
    _30344 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30343 = NOVALUE;
    DeRef(_val_60636);
    if (IS_ATOM_INT(_30344)) {
        {
            int128_t p128 = (int128_t)_30344 * (int128_t)_negate_60923;
            if( p128 != (int128_t)(_val_60636 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _val_60636 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _val_60636 = binary_op(MULTIPLY, _30344, _negate_60923);
    }
    _30344 = NOVALUE;

    /** parser.e:3658					if is_integer(val) then*/
    Ref(_val_60636);
    _30346 = _27is_integer(_val_60636);
    if (_30346 == 0) {
        DeRef(_30346);
        _30346 = NOVALUE;
        goto L28; // [1550] 1565
    }
    else {
        if (!IS_ATOM_INT(_30346) && DBL_PTR(_30346)->dbl == 0.0){
            DeRef(_30346);
            _30346 = NOVALUE;
            goto L28; // [1550] 1565
        }
        DeRef(_30346);
        _30346 = NOVALUE;
    }
    DeRef(_30346);
    _30346 = NOVALUE;

    /** parser.e:3659						Push(NewIntSym(val))*/
    Ref(_val_60636);
    _30347 = _53NewIntSym(_val_60636);
    _45Push(_30347);
    _30347 = NOVALUE;
    goto L29; // [1562] 1575
L28: 

    /** parser.e:3661						Push(NewDoubleSym(val))*/
    Ref(_val_60636);
    _30348 = _53NewDoubleSym(_val_60636);
    _45Push(_30348);
    _30348 = NOVALUE;
L29: 

    /** parser.e:3663					usedval = val*/
    Ref(_val_60636);
    DeRef(_usedval_60637);
    _usedval_60637 = _val_60636;

    /** parser.e:3664					if deltafunc = '+' then*/
    if (_deltafunc_60638 != 43LL)
    goto L2A; // [1582] 1595

    /** parser.e:3665						val += delta*/
    _0 = _val_60636;
    if (IS_ATOM_INT(_val_60636) && IS_ATOM_INT(_delta_60639)) {
        _val_60636 = _val_60636 + _delta_60639;
        if ((object)((uintptr_t)_val_60636 + (uintptr_t)HIGH_BITS) >= 0){
            _val_60636 = NewDouble((eudouble)_val_60636);
        }
    }
    else {
        if (IS_ATOM_INT(_val_60636)) {
            _val_60636 = NewDouble((eudouble)_val_60636 + DBL_PTR(_delta_60639)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_60639)) {
                _val_60636 = NewDouble(DBL_PTR(_val_60636)->dbl + (eudouble)_delta_60639);
            }
            else
            _val_60636 = NewDouble(DBL_PTR(_val_60636)->dbl + DBL_PTR(_delta_60639)->dbl);
        }
    }
    DeRef(_0);
    goto L2B; // [1592] 1602
L2A: 

    /** parser.e:3667						val *= delta*/
    _0 = _val_60636;
    if (IS_ATOM_INT(_val_60636) && IS_ATOM_INT(_delta_60639)) {
        {
            int128_t p128 = (int128_t)_val_60636 * (int128_t)_delta_60639;
            if( p128 != (int128_t)(_val_60636 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _val_60636 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        if (IS_ATOM_INT(_val_60636)) {
            _val_60636 = NewDouble((eudouble)_val_60636 * DBL_PTR(_delta_60639)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_60639)) {
                _val_60636 = NewDouble(DBL_PTR(_val_60636)->dbl * (eudouble)_delta_60639);
            }
            else
            _val_60636 = NewDouble(DBL_PTR(_val_60636)->dbl * DBL_PTR(_delta_60639)->dbl);
        }
    }
    DeRef(_0);
L2B: 
    goto L2C; // [1604] 1678
L1D: 

    /** parser.e:3670					putback(tok)*/
    Ref(_tok_60628);
    _43putback(_tok_60628);

    /** parser.e:3671					if is_integer(val) then*/
    Ref(_val_60636);
    _30352 = _27is_integer(_val_60636);
    if (_30352 == 0) {
        DeRef(_30352);
        _30352 = NOVALUE;
        goto L2D; // [1618] 1633
    }
    else {
        if (!IS_ATOM_INT(_30352) && DBL_PTR(_30352)->dbl == 0.0){
            DeRef(_30352);
            _30352 = NOVALUE;
            goto L2D; // [1618] 1633
        }
        DeRef(_30352);
        _30352 = NOVALUE;
    }
    DeRef(_30352);
    _30352 = NOVALUE;

    /** parser.e:3672						Push(NewIntSym(val))*/
    Ref(_val_60636);
    _30353 = _53NewIntSym(_val_60636);
    _45Push(_30353);
    _30353 = NOVALUE;
    goto L2E; // [1630] 1643
L2D: 

    /** parser.e:3674						Push(NewDoubleSym(val))*/
    Ref(_val_60636);
    _30354 = _53NewDoubleSym(_val_60636);
    _45Push(_30354);
    _30354 = NOVALUE;
L2E: 

    /** parser.e:3676					usedval = val*/
    Ref(_val_60636);
    DeRef(_usedval_60637);
    _usedval_60637 = _val_60636;

    /** parser.e:3677					if deltafunc = '+' then*/
    if (_deltafunc_60638 != 43LL)
    goto L2F; // [1650] 1663

    /** parser.e:3678						val += delta*/
    _0 = _val_60636;
    if (IS_ATOM_INT(_val_60636) && IS_ATOM_INT(_delta_60639)) {
        _val_60636 = _val_60636 + _delta_60639;
        if ((object)((uintptr_t)_val_60636 + (uintptr_t)HIGH_BITS) >= 0){
            _val_60636 = NewDouble((eudouble)_val_60636);
        }
    }
    else {
        if (IS_ATOM_INT(_val_60636)) {
            _val_60636 = NewDouble((eudouble)_val_60636 + DBL_PTR(_delta_60639)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_60639)) {
                _val_60636 = NewDouble(DBL_PTR(_val_60636)->dbl + (eudouble)_delta_60639);
            }
            else
            _val_60636 = NewDouble(DBL_PTR(_val_60636)->dbl + DBL_PTR(_delta_60639)->dbl);
        }
    }
    DeRef(_0);
    goto L30; // [1660] 1670
L2F: 

    /** parser.e:3680						val *= delta*/
    _0 = _val_60636;
    if (IS_ATOM_INT(_val_60636) && IS_ATOM_INT(_delta_60639)) {
        {
            int128_t p128 = (int128_t)_val_60636 * (int128_t)_delta_60639;
            if( p128 != (int128_t)(_val_60636 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _val_60636 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        if (IS_ATOM_INT(_val_60636)) {
            _val_60636 = NewDouble((eudouble)_val_60636 * DBL_PTR(_delta_60639)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_60639)) {
                _val_60636 = NewDouble(DBL_PTR(_val_60636)->dbl * (eudouble)_delta_60639);
            }
            else
            _val_60636 = NewDouble(DBL_PTR(_val_60636)->dbl * DBL_PTR(_delta_60639)->dbl);
        }
    }
    DeRef(_0);
L30: 

    /** parser.e:3682					valsym = 0*/
    _valsym_60633 = 0LL;
L2C: 

    /** parser.e:3684				buckets[SymTab[sym][S_HASHVAL]] = sym*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30358 = (object)*(((s1_ptr)_2)->base + _sym_60632);
    _2 = (object)SEQ_PTR(_30358);
    _30359 = (object)*(((s1_ptr)_2)->base + 11LL);
    _30358 = NOVALUE;
    _2 = (object)SEQ_PTR(_53buckets_47223);
    if (!IS_ATOM_INT(_30359))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_30359)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _30359);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_60632;
    DeRef(_1);

    /** parser.e:3685				SymTab[sym][S_USAGE] = U_WRITTEN*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60632 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _30360 = NOVALUE;

    /** parser.e:3687				if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L31; // [1719] 1757
    }
    else{
    }

    /** parser.e:3688					SymTab[sym][S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60632 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);
    _30362 = NOVALUE;

    /** parser.e:3689					SymTab[sym][S_OBJ] = NOVALUE     -- distinguish from literals*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60632 + ((s1_ptr)_2)->base);
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
    _30364 = NOVALUE;
L31: 

    /** parser.e:3692				if valsym < 0 then*/
    if (_valsym_60633 >= 0LL)
    goto L32; // [1759] 1764
L32: 

    /** parser.e:3697				if valsym and compare( SymTab[valsym][S_OBJ], NOVALUE ) then*/
    if (_valsym_60633 == 0) {
        goto L33; // [1766] 1946
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30368 = (object)*(((s1_ptr)_2)->base + _valsym_60633);
    _2 = (object)SEQ_PTR(_30368);
    _30369 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30368 = NOVALUE;
    if (IS_ATOM_INT(_30369) && IS_ATOM_INT(_27NOVALUE_20426)){
        _30370 = (_30369 < _27NOVALUE_20426) ? -1 : (_30369 > _27NOVALUE_20426);
    }
    else{
        _30370 = compare(_30369, _27NOVALUE_20426);
    }
    _30369 = NOVALUE;
    if (_30370 == 0)
    {
        _30370 = NOVALUE;
        goto L33; // [1789] 1946
    }
    else{
        _30370 = NOVALUE;
    }

    /** parser.e:3699					SymTab[sym][S_CODE] = valsym*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60632 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _valsym_60633;
    DeRef(_1);
    _30371 = NOVALUE;

    /** parser.e:3700					SymTab[sym][S_OBJ]  = usedval*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60632 + ((s1_ptr)_2)->base);
    Ref(_usedval_60637);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60637;
    DeRef(_1);
    _30373 = NOVALUE;

    /** parser.e:3702					if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L34; // [1828] 2079
    }
    else{
    }

    /** parser.e:3704						SymTab[sym][S_GTYPE] = SymTab[valsym][S_GTYPE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60632 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30377 = (object)*(((s1_ptr)_2)->base + _valsym_60633);
    _2 = (object)SEQ_PTR(_30377);
    _30378 = (object)*(((s1_ptr)_2)->base + 36LL);
    _30377 = NOVALUE;
    Ref(_30378);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30378;
    if( _1 != _30378 ){
        DeRef(_1);
    }
    _30378 = NOVALUE;
    _30375 = NOVALUE;

    /** parser.e:3705						SymTab[sym][S_SEQ_ELEM] = SymTab[valsym][S_SEQ_ELEM]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60632 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30381 = (object)*(((s1_ptr)_2)->base + _valsym_60633);
    _2 = (object)SEQ_PTR(_30381);
    _30382 = (object)*(((s1_ptr)_2)->base + 33LL);
    _30381 = NOVALUE;
    Ref(_30382);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30382;
    if( _1 != _30382 ){
        DeRef(_1);
    }
    _30382 = NOVALUE;
    _30379 = NOVALUE;

    /** parser.e:3706						SymTab[sym][S_OBJ_MIN] = usedval*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60632 + ((s1_ptr)_2)->base);
    Ref(_usedval_60637);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60637;
    DeRef(_1);
    _30383 = NOVALUE;

    /** parser.e:3707						SymTab[sym][S_OBJ_MAX] = usedval*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60632 + ((s1_ptr)_2)->base);
    Ref(_usedval_60637);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60637;
    DeRef(_1);
    _30385 = NOVALUE;

    /** parser.e:3708						SymTab[sym][S_SEQ_LEN] = SymTab[valsym][S_SEQ_LEN]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60632 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30389 = (object)*(((s1_ptr)_2)->base + _valsym_60633);
    _2 = (object)SEQ_PTR(_30389);
    _30390 = (object)*(((s1_ptr)_2)->base + 32LL);
    _30389 = NOVALUE;
    Ref(_30390);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30390;
    if( _1 != _30390 ){
        DeRef(_1);
    }
    _30390 = NOVALUE;
    _30387 = NOVALUE;
    goto L34; // [1943] 2079
L33: 

    /** parser.e:3711					SymTab[sym][S_OBJ] = usedval*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60632 + ((s1_ptr)_2)->base);
    Ref(_usedval_60637);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60637;
    DeRef(_1);
    _30391 = NOVALUE;

    /** parser.e:3712					if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L35; // [1967] 2078
    }
    else{
    }

    /** parser.e:3714						if is_integer( usedval ) then*/
    Ref(_usedval_60637);
    _30393 = _27is_integer(_usedval_60637);
    if (_30393 == 0) {
        DeRef(_30393);
        _30393 = NOVALUE;
        goto L36; // [1976] 1999
    }
    else {
        if (!IS_ATOM_INT(_30393) && DBL_PTR(_30393)->dbl == 0.0){
            DeRef(_30393);
            _30393 = NOVALUE;
            goto L36; // [1976] 1999
        }
        DeRef(_30393);
        _30393 = NOVALUE;
    }
    DeRef(_30393);
    _30393 = NOVALUE;

    /** parser.e:3715							SymTab[sym][S_GTYPE] = TYPE_INTEGER*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60632 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _30394 = NOVALUE;
    goto L37; // [1996] 2017
L36: 

    /** parser.e:3717							SymTab[sym][S_GTYPE] = TYPE_DOUBLE*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60632 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _30396 = NOVALUE;
L37: 

    /** parser.e:3719						SymTab[sym][S_SEQ_ELEM] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60632 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30398 = NOVALUE;

    /** parser.e:3720						SymTab[sym][S_OBJ_MIN] = usedval*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60632 + ((s1_ptr)_2)->base);
    Ref(_usedval_60637);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60637;
    DeRef(_1);
    _30400 = NOVALUE;

    /** parser.e:3721						SymTab[sym][S_OBJ_MAX] = usedval*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60632 + ((s1_ptr)_2)->base);
    Ref(_usedval_60637);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60637;
    DeRef(_1);
    _30402 = NOVALUE;

    /** parser.e:3722						SymTab[sym][S_SEQ_LEN] = 0 --SymTab[valsym][S_SEQ_LEN]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60632 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30404 = NOVALUE;
L35: 
L34: 

    /** parser.e:3725				valsym = Pop()*/
    _valsym_60633 = _45Pop();
    if (!IS_ATOM_INT(_valsym_60633)) {
        _1 = (object)(DBL_PTR(_valsym_60633)->dbl);
        DeRefDS(_valsym_60633);
        _valsym_60633 = _1;
    }

    /** parser.e:3726				valsym = Pop()*/
    _valsym_60633 = _45Pop();
    if (!IS_ATOM_INT(_valsym_60633)) {
        _1 = (object)(DBL_PTR(_valsym_60633)->dbl);
        DeRefDS(_valsym_60633);
        _valsym_60633 = _1;
    }
    goto L18; // [2093] 2269
L1C: 

    /** parser.e:3729				SymTab[sym][S_MODE] = M_NORMAL*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60632 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _30408 = NOVALUE;

    /** parser.e:3730				if type_ptr > 0 and SymTab[type_ptr][S_TOKEN] = OBJECT then*/
    _30410 = (_type_ptr_60624 > 0LL);
    if (_30410 == 0) {
        goto L38; // [2119] 2165
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30412 = (object)*(((s1_ptr)_2)->base + _type_ptr_60624);
    _2 = (object)SEQ_PTR(_30412);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _30413 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _30413 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _30412 = NOVALUE;
    if (IS_ATOM_INT(_30413)) {
        _30414 = (_30413 == 415LL);
    }
    else {
        _30414 = binary_op(EQUALS, _30413, 415LL);
    }
    _30413 = NOVALUE;
    if (_30414 == 0) {
        DeRef(_30414);
        _30414 = NOVALUE;
        goto L38; // [2142] 2165
    }
    else {
        if (!IS_ATOM_INT(_30414) && DBL_PTR(_30414)->dbl == 0.0){
            DeRef(_30414);
            _30414 = NOVALUE;
            goto L38; // [2142] 2165
        }
        DeRef(_30414);
        _30414 = NOVALUE;
    }
    DeRef(_30414);
    _30414 = NOVALUE;

    /** parser.e:3731					SymTab[sym][S_VTYPE] = object_type*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60632 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _53object_type_47227;
    DeRef(_1);
    _30415 = NOVALUE;
    goto L39; // [2162] 2194
L38: 

    /** parser.e:3733					SymTab[sym][S_VTYPE] = type_ptr*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60632 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _type_ptr_60624;
    DeRef(_1);
    _30417 = NOVALUE;

    /** parser.e:3734					if type_ptr < 0 then*/
    if (_type_ptr_60624 >= 0LL)
    goto L3A; // [2182] 2193

    /** parser.e:3735						register_forward_type( sym, type_ptr )*/
    _42register_forward_type(_sym_60632, _type_ptr_60624);
L3A: 
L39: 

    /** parser.e:3739				if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L3B; // [2198] 2221
    }
    else{
    }

    /** parser.e:3740					SymTab[sym][S_GTYPE] = CompileType(type_ptr)*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60632 + ((s1_ptr)_2)->base);
    _30422 = _43CompileType(_type_ptr_60624);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30422;
    if( _1 != _30422 ){
        DeRef(_1);
    }
    _30422 = NOVALUE;
    _30420 = NOVALUE;
L3B: 

    /** parser.e:3743		   		tok = next_token()*/
    _0 = _tok_60628;
    _tok_60628 = _43next_token();
    DeRef(_0);

    /** parser.e:3744	   			putback(tok)*/
    Ref(_tok_60628);
    _43putback(_tok_60628);

    /** parser.e:3745		   		if tok[T_ID] = EQUALS then -- assign on declare*/
    _2 = (object)SEQ_PTR(_tok_60628);
    _30424 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30424, 3LL)){
        _30424 = NOVALUE;
        goto L3C; // [2241] 2268
    }
    _30424 = NOVALUE;

    /** parser.e:3746		   			StartSourceLine( FALSE, , COVERAGE_OVERRIDE )*/
    _45StartSourceLine(_9FALSE_439, 0LL, 3LL);

    /** parser.e:3747		   			Assignment({VARIABLE,sym})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100LL;
    ((intptr_t *)_2)[2] = _sym_60632;
    _30426 = MAKE_SEQ(_1);
    _43Assignment(_30426);
    _30426 = NOVALUE;
L3C: 
L18: 

    /** parser.e:3750			tok = next_token()*/
    _0 = _tok_60628;
    _tok_60628 = _43next_token();
    DeRef(_0);

    /** parser.e:3751			if tok[T_ID] != COMMA then*/
    _2 = (object)SEQ_PTR(_tok_60628);
    _30428 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _30428, -30LL)){
        _30428 = NOVALUE;
        goto L3D; // [2284] 2293
    }
    _30428 = NOVALUE;

    /** parser.e:3752				exit*/
    goto LD; // [2290] 2303
L3D: 

    /** parser.e:3754			prevtok = tok*/
    Ref(_tok_60628);
    DeRef(_prevtok_60630);
    _prevtok_60630 = _tok_60628;

    /** parser.e:3755		end while*/
    goto LC; // [2300] 440
LD: 

    /** parser.e:3756		putback(tok)*/
    Ref(_tok_60628);
    _43putback(_tok_60628);

    /** parser.e:3757		return new_symbols*/
    DeRef(_tok_60628);
    DeRef(_tsym_60629);
    DeRef(_prevtok_60630);
    DeRef(_val_60636);
    DeRef(_usedval_60637);
    DeRef(_delta_60639);
    _30216 = NOVALUE;
    DeRef(_30254);
    _30254 = NOVALUE;
    DeRef(_30288);
    _30288 = NOVALUE;
    DeRef(_30188);
    _30188 = NOVALUE;
    DeRef(_30279);
    _30279 = NOVALUE;
    _30303 = NOVALUE;
    DeRef(_30297);
    _30297 = NOVALUE;
    DeRef(_30323);
    _30323 = NOVALUE;
    _30318 = NOVALUE;
    DeRef(_30410);
    _30410 = NOVALUE;
    _30359 = NOVALUE;
    _30267 = NOVALUE;
    _30271 = NOVALUE;
    DeRef(_30339);
    _30339 = NOVALUE;
    return _new_symbols_60626;
    ;
}


void _43Private_declaration(object _type_sym_61214)
{
    object _tok_61216 = NOVALUE;
    object _sym_61218 = NOVALUE;
    object _32045 = NOVALUE;
    object _32044 = NOVALUE;
    object _32043 = NOVALUE;
    object _30454 = NOVALUE;
    object _30452 = NOVALUE;
    object _30450 = NOVALUE;
    object _30448 = NOVALUE;
    object _30446 = NOVALUE;
    object _30444 = NOVALUE;
    object _30442 = NOVALUE;
    object _30439 = NOVALUE;
    object _30437 = NOVALUE;
    object _30436 = NOVALUE;
    object _30433 = NOVALUE;
    object _30431 = NOVALUE;
    object _30430 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_type_sym_61214)) {
        _1 = (object)(DBL_PTR(_type_sym_61214)->dbl);
        DeRefDS(_type_sym_61214);
        _type_sym_61214 = _1;
    }

    /** parser.e:3765		if SymTab[type_sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30430 = (object)*(((s1_ptr)_2)->base + _type_sym_61214);
    _2 = (object)SEQ_PTR(_30430);
    _30431 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30430 = NOVALUE;
    if (binary_op_a(NOTEQ, _30431, 9LL)){
        _30431 = NOVALUE;
        goto L1; // [19] 47
    }
    _30431 = NOVALUE;

    /** parser.e:3766			Hide( type_sym )*/
    _53Hide(_type_sym_61214);

    /** parser.e:3767			type_sym = -new_forward_reference( TYPE, type_sym )*/
    _32045 = 504LL;
    _30433 = _42new_forward_reference(504LL, _type_sym_61214, 504LL);
    _32045 = NOVALUE;
    if (IS_ATOM_INT(_30433)) {
        if ((uintptr_t)_30433 == (uintptr_t)HIGH_BITS){
            _type_sym_61214 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _type_sym_61214 = - _30433;
        }
    }
    else {
        _type_sym_61214 = unary_op(UMINUS, _30433);
    }
    DeRef(_30433);
    _30433 = NOVALUE;
    if (!IS_ATOM_INT(_type_sym_61214)) {
        _1 = (object)(DBL_PTR(_type_sym_61214)->dbl);
        DeRefDS(_type_sym_61214);
        _type_sym_61214 = _1;
    }
L1: 

    /** parser.e:3770		while TRUE do*/
L2: 
    if (_9TRUE_441 == 0)
    {
        goto L3; // [54] 257
    }
    else{
    }

    /** parser.e:3771			tok = next_token()*/
    _0 = _tok_61216;
    _tok_61216 = _43next_token();
    DeRef(_0);

    /** parser.e:3772			if not find(tok[T_ID], ID_TOKS) then*/
    _2 = (object)SEQ_PTR(_tok_61216);
    _30436 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30437 = find_from(_30436, _29ID_TOKS_12283, 1LL);
    _30436 = NOVALUE;
    if (_30437 != 0)
    goto L4; // [77] 90
    _30437 = NOVALUE;

    /** parser.e:3773				CompileErr(A_VARIABLE_NAME_IS_EXPECTED_HERE)*/
    RefDS(_22218);
    _49CompileErr(24LL, _22218, 0LL);
L4: 

    /** parser.e:3775			sym = SetPrivateScope(tok[T_SYM], type_sym, param_num)*/
    _2 = (object)SEQ_PTR(_tok_61216);
    _30439 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30439);
    _sym_61218 = _43SetPrivateScope(_30439, _type_sym_61214, _43param_num_55477);
    _30439 = NOVALUE;
    if (!IS_ATOM_INT(_sym_61218)) {
        _1 = (object)(DBL_PTR(_sym_61218)->dbl);
        DeRefDS(_sym_61218);
        _sym_61218 = _1;
    }

    /** parser.e:3776			param_num += 1*/
    _43param_num_55477 = _43param_num_55477 + 1;

    /** parser.e:3778			if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L5; // [120] 143
    }
    else{
    }

    /** parser.e:3779				SymTab[sym][S_GTYPE] = CompileType(type_sym)*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_61218 + ((s1_ptr)_2)->base);
    _30444 = _43CompileType(_type_sym_61214);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30444;
    if( _1 != _30444 ){
        DeRef(_1);
    }
    _30444 = NOVALUE;
    _30442 = NOVALUE;
L5: 

    /** parser.e:3782	   		tok = next_token()*/
    _0 = _tok_61216;
    _tok_61216 = _43next_token();
    DeRef(_0);

    /** parser.e:3783	   		if tok[T_ID] = EQUALS then -- assign on declare*/
    _2 = (object)SEQ_PTR(_tok_61216);
    _30446 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30446, 3LL)){
        _30446 = NOVALUE;
        goto L6; // [158] 233
    }
    _30446 = NOVALUE;

    /** parser.e:3784			    putback(tok)*/
    Ref(_tok_61216);
    _43putback(_tok_61216);

    /** parser.e:3785			    StartSourceLine( TRUE )*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:3797			    Assignment({VARIABLE,sym})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100LL;
    ((intptr_t *)_2)[2] = _sym_61218;
    _30448 = MAKE_SEQ(_1);
    _43Assignment(_30448);
    _30448 = NOVALUE;

    /** parser.e:3800				tok = next_token()*/
    _0 = _tok_61216;
    _tok_61216 = _43next_token();
    DeRef(_0);

    /** parser.e:3801				if tok[T_ID]=IGNORED then*/
    _2 = (object)SEQ_PTR(_tok_61216);
    _30450 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30450, 509LL)){
        _30450 = NOVALUE;
        goto L7; // [202] 232
    }
    _30450 = NOVALUE;

    /** parser.e:3802					tok = keyfind(tok[T_SYM],-1)*/
    _2 = (object)SEQ_PTR(_tok_61216);
    _30452 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30452);
    DeRef(_32043);
    _32043 = _30452;
    _32044 = _53hashfn(_32043);
    _32043 = NOVALUE;
    Ref(_30452);
    _0 = _tok_61216;
    _tok_61216 = _53keyfind(_30452, -1LL, _27current_file_no_20571, 0LL, _32044);
    DeRef(_0);
    _30452 = NOVALUE;
    _32044 = NOVALUE;
L7: 
L6: 

    /** parser.e:3806			if tok[T_ID] != COMMA then*/
    _2 = (object)SEQ_PTR(_tok_61216);
    _30454 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _30454, -30LL)){
        _30454 = NOVALUE;
        goto L2; // [243] 52
    }
    _30454 = NOVALUE;

    /** parser.e:3807				exit*/
    goto L3; // [249] 257

    /** parser.e:3809		end while*/
    goto L2; // [254] 52
L3: 

    /** parser.e:3810		putback(tok)*/
    Ref(_tok_61216);
    _43putback(_tok_61216);

    /** parser.e:3811	end procedure*/
    DeRef(_tok_61216);
    return;
    ;
}


void _43Procedure_call(object _tok_61281)
{
    object _n_61282 = NOVALUE;
    object _scope_61283 = NOVALUE;
    object _opcode_61284 = NOVALUE;
    object _temp_tok_61286 = NOVALUE;
    object _s_61288 = NOVALUE;
    object _sub_61289 = NOVALUE;
    object _30490 = NOVALUE;
    object _30485 = NOVALUE;
    object _30484 = NOVALUE;
    object _30483 = NOVALUE;
    object _30482 = NOVALUE;
    object _30481 = NOVALUE;
    object _30480 = NOVALUE;
    object _30479 = NOVALUE;
    object _30478 = NOVALUE;
    object _30477 = NOVALUE;
    object _30476 = NOVALUE;
    object _30475 = NOVALUE;
    object _30473 = NOVALUE;
    object _30472 = NOVALUE;
    object _30471 = NOVALUE;
    object _30470 = NOVALUE;
    object _30469 = NOVALUE;
    object _30468 = NOVALUE;
    object _30467 = NOVALUE;
    object _30465 = NOVALUE;
    object _30464 = NOVALUE;
    object _30463 = NOVALUE;
    object _30461 = NOVALUE;
    object _30459 = NOVALUE;
    object _30457 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:3820		tok_match(LEFT_ROUND)*/
    _43tok_match(-26LL, 0LL);

    /** parser.e:3821		s = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_61281);
    _s_61288 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_61288)){
        _s_61288 = (object)DBL_PTR(_s_61288)->dbl;
    }

    /** parser.e:3822		sub=s*/
    _sub_61289 = _s_61288;

    /** parser.e:3823		n = SymTab[s][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30457 = (object)*(((s1_ptr)_2)->base + _s_61288);
    _2 = (object)SEQ_PTR(_30457);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _n_61282 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _n_61282 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    if (!IS_ATOM_INT(_n_61282)){
        _n_61282 = (object)DBL_PTR(_n_61282)->dbl;
    }
    _30457 = NOVALUE;

    /** parser.e:3824		scope = SymTab[s][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30459 = (object)*(((s1_ptr)_2)->base + _s_61288);
    _2 = (object)SEQ_PTR(_30459);
    _scope_61283 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_scope_61283)){
        _scope_61283 = (object)DBL_PTR(_scope_61283)->dbl;
    }
    _30459 = NOVALUE;

    /** parser.e:3825		opcode = SymTab[s][S_OPCODE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30461 = (object)*(((s1_ptr)_2)->base + _s_61288);
    _2 = (object)SEQ_PTR(_30461);
    _opcode_61284 = (object)*(((s1_ptr)_2)->base + 21LL);
    if (!IS_ATOM_INT(_opcode_61284)){
        _opcode_61284 = (object)DBL_PTR(_opcode_61284)->dbl;
    }
    _30461 = NOVALUE;

    /** parser.e:3826		if SymTab[s][S_EFFECT] then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30463 = (object)*(((s1_ptr)_2)->base + _s_61288);
    _2 = (object)SEQ_PTR(_30463);
    _30464 = (object)*(((s1_ptr)_2)->base + 23LL);
    _30463 = NOVALUE;
    if (_30464 == 0) {
        _30464 = NOVALUE;
        goto L1; // [88] 139
    }
    else {
        if (!IS_ATOM_INT(_30464) && DBL_PTR(_30464)->dbl == 0.0){
            _30464 = NOVALUE;
            goto L1; // [88] 139
        }
        _30464 = NOVALUE;
    }
    _30464 = NOVALUE;

    /** parser.e:3827			SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT],*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27CurrentSub_20579 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30467 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_30467);
    _30468 = (object)*(((s1_ptr)_2)->base + 23LL);
    _30467 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30469 = (object)*(((s1_ptr)_2)->base + _s_61288);
    _2 = (object)SEQ_PTR(_30469);
    _30470 = (object)*(((s1_ptr)_2)->base + 23LL);
    _30469 = NOVALUE;
    if (IS_ATOM_INT(_30468) && IS_ATOM_INT(_30470)) {
        {uintptr_t tu;
             tu = (uintptr_t)_30468 | (uintptr_t)_30470;
             _30471 = MAKE_UINT(tu);
        }
    }
    else {
        _30471 = binary_op(OR_BITS, _30468, _30470);
    }
    _30468 = NOVALUE;
    _30470 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30471;
    if( _1 != _30471 ){
        DeRef(_1);
    }
    _30471 = NOVALUE;
    _30465 = NOVALUE;
L1: 

    /** parser.e:3830		ParseArgs(s)*/
    _43ParseArgs(_s_61288);

    /** parser.e:3833		for i=1 to n+1 do*/
    _30472 = _n_61282 + 1;
    if (_30472 > MAXINT){
        _30472 = NewDouble((eudouble)_30472);
    }
    {
        object _i_61326;
        _i_61326 = 1LL;
L2: 
        if (binary_op_a(GREATER, _i_61326, _30472)){
            goto L3; // [150] 180
        }

        /** parser.e:3834			s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _30473 = (object)*(((s1_ptr)_2)->base + _s_61288);
        _2 = (object)SEQ_PTR(_30473);
        _s_61288 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_s_61288)){
            _s_61288 = (object)DBL_PTR(_s_61288)->dbl;
        }
        _30473 = NOVALUE;

        /** parser.e:3835		end for*/
        _0 = _i_61326;
        if (IS_ATOM_INT(_i_61326)) {
            _i_61326 = _i_61326 + 1LL;
            if ((object)((uintptr_t)_i_61326 +(uintptr_t) HIGH_BITS) >= 0){
                _i_61326 = NewDouble((eudouble)_i_61326);
            }
        }
        else {
            _i_61326 = binary_op_a(PLUS, _i_61326, 1LL);
        }
        DeRef(_0);
        goto L2; // [175] 157
L3: 
        ;
        DeRef(_i_61326);
    }

    /** parser.e:3836		while s and SymTab[s][S_SCOPE]=SC_PRIVATE do*/
L4: 
    if (_s_61288 == 0) {
        goto L5; // [185] 281
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30476 = (object)*(((s1_ptr)_2)->base + _s_61288);
    _2 = (object)SEQ_PTR(_30476);
    _30477 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30476 = NOVALUE;
    if (IS_ATOM_INT(_30477)) {
        _30478 = (_30477 == 3LL);
    }
    else {
        _30478 = binary_op(EQUALS, _30477, 3LL);
    }
    _30477 = NOVALUE;
    if (_30478 <= 0) {
        if (_30478 == 0) {
            DeRef(_30478);
            _30478 = NOVALUE;
            goto L5; // [208] 281
        }
        else {
            if (!IS_ATOM_INT(_30478) && DBL_PTR(_30478)->dbl == 0.0){
                DeRef(_30478);
                _30478 = NOVALUE;
                goto L5; // [208] 281
            }
            DeRef(_30478);
            _30478 = NOVALUE;
        }
    }
    DeRef(_30478);
    _30478 = NOVALUE;

    /** parser.e:3837			if sequence(SymTab[s][S_CODE]) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30479 = (object)*(((s1_ptr)_2)->base + _s_61288);
    _2 = (object)SEQ_PTR(_30479);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _30480 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _30480 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    _30479 = NOVALUE;
    _30481 = IS_SEQUENCE(_30480);
    _30480 = NOVALUE;
    if (_30481 == 0)
    {
        _30481 = NOVALUE;
        goto L6; // [228] 260
    }
    else{
        _30481 = NOVALUE;
    }

    /** parser.e:3838				start_playback(SymTab[s][S_CODE])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30482 = (object)*(((s1_ptr)_2)->base + _s_61288);
    _2 = (object)SEQ_PTR(_30482);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _30483 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _30483 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    _30482 = NOVALUE;
    Ref(_30483);
    _43start_playback(_30483);
    _30483 = NOVALUE;

    /** parser.e:3839				Assignment({VARIABLE,s})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100LL;
    ((intptr_t *)_2)[2] = _s_61288;
    _30484 = MAKE_SEQ(_1);
    _43Assignment(_30484);
    _30484 = NOVALUE;
L6: 

    /** parser.e:3841			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30485 = (object)*(((s1_ptr)_2)->base + _s_61288);
    _2 = (object)SEQ_PTR(_30485);
    _s_61288 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_61288)){
        _s_61288 = (object)DBL_PTR(_s_61288)->dbl;
    }
    _30485 = NOVALUE;

    /** parser.e:3842		end while*/
    goto L4; // [278] 185
L5: 

    /** parser.e:3844		s = sub*/
    _s_61288 = _sub_61289;

    /** parser.e:3845		if scope = SC_PREDEF then*/
    if (_scope_61283 != 7LL)
    goto L7; // [292] 335

    /** parser.e:3846			emit_op(opcode)*/
    _45emit_op(_opcode_61284);

    /** parser.e:3847			if opcode = ABORT then*/
    if (_opcode_61284 != 126LL)
    goto L8; // [305] 370

    /** parser.e:3848				temp_tok = next_token()*/
    _0 = _temp_tok_61286;
    _temp_tok_61286 = _43next_token();
    DeRef(_0);

    /** parser.e:3849				putback(temp_tok)*/
    Ref(_temp_tok_61286);
    _43putback(_temp_tok_61286);

    /** parser.e:3850				NotReached(temp_tok[T_ID], "abort()")*/
    _2 = (object)SEQ_PTR(_temp_tok_61286);
    _30490 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_30490);
    RefDS(_28222);
    _43NotReached(_30490, _28222);
    _30490 = NOVALUE;
    goto L8; // [332] 370
L7: 

    /** parser.e:3853			op_info1 = s*/
    _45op_info1_51473 = _s_61288;

    /** parser.e:3855			emit_or_inline()*/
    _66emit_or_inline();

    /** parser.e:3856			if not TRANSLATE then*/
    if (_27TRANSLATE_20179 != 0)
    goto L9; // [350] 369

    /** parser.e:3857				if OpTrace then*/
    if (_27OpTrace_20641 == 0)
    {
        goto LA; // [357] 368
    }
    else{
    }

    /** parser.e:3858					emit_op(UPDATE_GLOBALS)*/
    _45emit_op(89LL);
LA: 
L9: 
L8: 

    /** parser.e:3862	end procedure*/
    DeRef(_tok_61281);
    DeRef(_temp_tok_61286);
    DeRef(_30472);
    _30472 = NOVALUE;
    return;
    ;
}


void _43Print_statement()
{
    object _30497 = NOVALUE;
    object _30496 = NOVALUE;
    object _30495 = NOVALUE;
    object _30493 = NOVALUE;
    object _30492 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:3866		emit_opnd(NewIntSym(1)) -- stdout*/
    _30492 = _53NewIntSym(1LL);
    _45emit_opnd(_30492);
    _30492 = NOVALUE;

    /** parser.e:3867		Expr()*/
    _43Expr();

    /** parser.e:3868		emit_op(QPRINT)*/
    _45emit_op(36LL);

    /** parser.e:3869		SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT],*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27CurrentSub_20579 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30495 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_30495);
    _30496 = (object)*(((s1_ptr)_2)->base + 23LL);
    _30495 = NOVALUE;
    if (IS_ATOM_INT(_30496)) {
        {uintptr_t tu;
             tu = (uintptr_t)_30496 | (uintptr_t)536870912LL;
             _30497 = MAKE_UINT(tu);
        }
    }
    else {
        _30497 = binary_op(OR_BITS, _30496, 536870912LL);
    }
    _30496 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30497;
    if( _1 != _30497 ){
        DeRef(_1);
    }
    _30497 = NOVALUE;
    _30493 = NOVALUE;

    /** parser.e:3871	end procedure*/
    return;
    ;
}


void _43Entry_statement()
{
    object _addr_61397 = NOVALUE;
    object _30521 = NOVALUE;
    object _30520 = NOVALUE;
    object _30519 = NOVALUE;
    object _30518 = NOVALUE;
    object _30517 = NOVALUE;
    object _30516 = NOVALUE;
    object _30515 = NOVALUE;
    object _30514 = NOVALUE;
    object _30510 = NOVALUE;
    object _30508 = NOVALUE;
    object _30507 = NOVALUE;
    object _30506 = NOVALUE;
    object _30505 = NOVALUE;
    object _30503 = NOVALUE;
    object _30502 = NOVALUE;
    object _30501 = NOVALUE;
    object _30499 = NOVALUE;
    object _30498 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:3878		if not length(loop_stack) or block_index=0 then*/
    if (IS_SEQUENCE(_43loop_stack_55502)){
            _30498 = SEQ_PTR(_43loop_stack_55502)->length;
    }
    else {
        _30498 = 1;
    }
    _30499 = (_30498 == 0);
    _30498 = NOVALUE;
    if (_30499 != 0) {
        goto L1; // [11] 26
    }
    _30501 = (_43block_index_55499 == 0LL);
    if (_30501 == 0)
    {
        DeRef(_30501);
        _30501 = NOVALUE;
        goto L2; // [22] 36
    }
    else{
        DeRef(_30501);
        _30501 = NOVALUE;
    }
L1: 

    /** parser.e:3879			CompileErr(THE_ENTRY_STATEMENT_MUST_APPEAR_INSIDE_A_LOOP)*/
    RefDS(_22218);
    _49CompileErr(144LL, _22218, 0LL);
L2: 

    /** parser.e:3881		if block_list[block_index]=IF or block_list[block_index]=SWITCH then*/
    _2 = (object)SEQ_PTR(_43block_list_55498);
    _30502 = (object)*(((s1_ptr)_2)->base + _43block_index_55499);
    _30503 = (_30502 == 20LL);
    _30502 = NOVALUE;
    if (_30503 != 0) {
        goto L3; // [52] 75
    }
    _2 = (object)SEQ_PTR(_43block_list_55498);
    _30505 = (object)*(((s1_ptr)_2)->base + _43block_index_55499);
    _30506 = (_30505 == 185LL);
    _30505 = NOVALUE;
    if (_30506 == 0)
    {
        DeRef(_30506);
        _30506 = NOVALUE;
        goto L4; // [71] 87
    }
    else{
        DeRef(_30506);
        _30506 = NOVALUE;
    }
L3: 

    /** parser.e:3882			CompileErr(THE_INNERMOST_BLOCK_CONTAINING_AN_ENTRY_STATEMENT_MUST_BE_THE_LOOP_IT_DEFINES_AN_ENTRY_IN)*/
    RefDS(_22218);
    _49CompileErr(143LL, _22218, 0LL);
    goto L5; // [84] 115
L4: 

    /** parser.e:3883		elsif loop_stack[$] = FOR then  -- not allowed in an innermost for loop*/
    if (IS_SEQUENCE(_43loop_stack_55502)){
            _30507 = SEQ_PTR(_43loop_stack_55502)->length;
    }
    else {
        _30507 = 1;
    }
    _2 = (object)SEQ_PTR(_43loop_stack_55502);
    _30508 = (object)*(((s1_ptr)_2)->base + _30507);
    if (_30508 != 21LL)
    goto L6; // [100] 114

    /** parser.e:3884			CompileErr(THE_ENTRY_STATEMENT_CAN_NOT_BE_USED_IN_A_FOR_BLOCK)*/
    RefDS(_22218);
    _49CompileErr(142LL, _22218, 0LL);
L6: 
L5: 

    /** parser.e:3886		addr = entry_addr[$]*/
    if (IS_SEQUENCE(_43entry_addr_55492)){
            _30510 = SEQ_PTR(_43entry_addr_55492)->length;
    }
    else {
        _30510 = 1;
    }
    _2 = (object)SEQ_PTR(_43entry_addr_55492);
    _addr_61397 = (object)*(((s1_ptr)_2)->base + _30510);

    /** parser.e:3887		if addr=0  then*/
    if (_addr_61397 != 0LL)
    goto L7; // [128] 144

    /** parser.e:3888			CompileErr(THE_ENTRY_STATEMENT_MUST_APPEAR_AT_MOST_ONCE_INSIDE_A_LOOP)*/
    RefDS(_22218);
    _49CompileErr(141LL, _22218, 0LL);
    goto L8; // [141] 161
L7: 

    /** parser.e:3889		elsif addr<0 then*/
    if (_addr_61397 >= 0LL)
    goto L9; // [146] 160

    /** parser.e:3890			CompileErr(ENTRY_STATEMENT_IS_BEING_USED_WITHOUT_A_CORRESPONDING_ENTRY_CLAUSE_IN_THE_LOOP_HEADER)*/
    RefDS(_22218);
    _49CompileErr(73LL, _22218, 0LL);
L9: 
L8: 

    /** parser.e:3892		backpatch(addr,ELSE)*/
    _45backpatch(_addr_61397, 23LL);

    /** parser.e:3893		backpatch(addr+1,length(Code)+1+(TRANSLATE>0))*/
    _30514 = _addr_61397 + 1;
    if (_30514 > MAXINT){
        _30514 = NewDouble((eudouble)_30514);
    }
    if (IS_SEQUENCE(_27Code_20660)){
            _30515 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _30515 = 1;
    }
    _30516 = _30515 + 1;
    _30515 = NOVALUE;
    _30517 = (_27TRANSLATE_20179 > 0LL);
    _30518 = _30516 + _30517;
    _30516 = NOVALUE;
    _30517 = NOVALUE;
    _45backpatch(_30514, _30518);
    _30514 = NOVALUE;
    _30518 = NOVALUE;

    /** parser.e:3894		entry_addr[$] = 0*/
    if (IS_SEQUENCE(_43entry_addr_55492)){
            _30519 = SEQ_PTR(_43entry_addr_55492)->length;
    }
    else {
        _30519 = 1;
    }
    _2 = (object)SEQ_PTR(_43entry_addr_55492);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43entry_addr_55492 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _30519);
    *(intptr_t *)_2 = 0LL;

    /** parser.e:3895		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto LA; // [213] 224
    }
    else{
    }

    /** parser.e:3896		    emit_op(NOP1)*/
    _45emit_op(159LL);
LA: 

    /** parser.e:3899		force_uninitialize( entry_stack[$] )*/
    if (IS_SEQUENCE(_43entry_stack_55495)){
            _30520 = SEQ_PTR(_43entry_stack_55495)->length;
    }
    else {
        _30520 = 1;
    }
    _2 = (object)SEQ_PTR(_43entry_stack_55495);
    _30521 = (object)*(((s1_ptr)_2)->base + _30520);
    Ref(_30521);
    _43force_uninitialize(_30521);
    _30521 = NOVALUE;

    /** parser.e:3901	end procedure*/
    DeRef(_30499);
    _30499 = NOVALUE;
    DeRef(_30503);
    _30503 = NOVALUE;
    _30508 = NOVALUE;
    return;
    ;
}


void _43force_uninitialize(object _uninitialized_61452)
{
    object _30524 = NOVALUE;
    object _30523 = NOVALUE;
    object _30522 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:3907		for i = 1 to length( uninitialized ) do*/
    if (IS_SEQUENCE(_uninitialized_61452)){
            _30522 = SEQ_PTR(_uninitialized_61452)->length;
    }
    else {
        _30522 = 1;
    }
    {
        object _i_61454;
        _i_61454 = 1LL;
L1: 
        if (_i_61454 > _30522){
            goto L2; // [8] 41
        }

        /** parser.e:3908			SymTab[uninitialized[i]][S_INITLEVEL] = -1*/
        _2 = (object)SEQ_PTR(_uninitialized_61452);
        _30523 = (object)*(((s1_ptr)_2)->base + _i_61454);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_30523))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_30523)->dbl));
        else
        _3 = (object)(_30523 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 14LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = -1LL;
        DeRef(_1);
        _30524 = NOVALUE;

        /** parser.e:3909		end for*/
        _i_61454 = _i_61454 + 1LL;
        goto L1; // [36] 15
L2: 
        ;
    }

    /** parser.e:3910	end procedure*/
    DeRefDS(_uninitialized_61452);
    _30523 = NOVALUE;
    return;
    ;
}


void _43Statement_list()
{
    object _tok_61464 = NOVALUE;
    object _id_61465 = NOVALUE;
    object _forward_61488 = NOVALUE;
    object _test_61637 = NOVALUE;
    object _30597 = NOVALUE;
    object _30596 = NOVALUE;
    object _30593 = NOVALUE;
    object _30591 = NOVALUE;
    object _30590 = NOVALUE;
    object _30587 = NOVALUE;
    object _30584 = NOVALUE;
    object _30583 = NOVALUE;
    object _30582 = NOVALUE;
    object _30579 = NOVALUE;
    object _30577 = NOVALUE;
    object _30575 = NOVALUE;
    object _30573 = NOVALUE;
    object _30555 = NOVALUE;
    object _30554 = NOVALUE;
    object _30552 = NOVALUE;
    object _30550 = NOVALUE;
    object _30549 = NOVALUE;
    object _30547 = NOVALUE;
    object _30545 = NOVALUE;
    object _30544 = NOVALUE;
    object _30543 = NOVALUE;
    object _30542 = NOVALUE;
    object _30537 = NOVALUE;
    object _30534 = NOVALUE;
    object _30533 = NOVALUE;
    object _30532 = NOVALUE;
    object _30531 = NOVALUE;
    object _30529 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:3915		integer id*/

    /** parser.e:3917		stmt_nest += 1*/
    _43stmt_nest_55500 = _43stmt_nest_55500 + 1;

    /** parser.e:3918		while TRUE do*/
L1: 
    if (_9TRUE_441 == 0)
    {
        goto L2; // [18] 1125
    }
    else{
    }

    /** parser.e:3919			tok = next_token()*/
    _0 = _tok_61464;
    _tok_61464 = _43next_token();
    DeRef(_0);

    /** parser.e:3920			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_61464);
    _id_61465 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_61465)){
        _id_61465 = (object)DBL_PTR(_id_61465)->dbl;
    }

    /** parser.e:3921			if id = VARIABLE or id = QUALIFIED_VARIABLE then*/
    _30529 = (_id_61465 == -100LL);
    if (_30529 != 0) {
        goto L3; // [44] 59
    }
    _30531 = (_id_61465 == 512LL);
    if (_30531 == 0)
    {
        DeRef(_30531);
        _30531 = NOVALUE;
        goto L4; // [55] 229
    }
    else{
        DeRef(_30531);
        _30531 = NOVALUE;
    }
L3: 

    /** parser.e:3922				if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_tok_61464);
    _30532 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30532)){
        _30533 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30532)->dbl));
    }
    else{
        _30533 = (object)*(((s1_ptr)_2)->base + _30532);
    }
    _2 = (object)SEQ_PTR(_30533);
    _30534 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30533 = NOVALUE;
    if (binary_op_a(NOTEQ, _30534, 9LL)){
        _30534 = NOVALUE;
        goto L5; // [81] 210
    }
    _30534 = NOVALUE;

    /** parser.e:3923					token forward = next_token()*/
    _0 = _forward_61488;
    _forward_61488 = _43next_token();
    DeRef(_0);

    /** parser.e:3924					switch forward[T_ID] do*/
    _2 = (object)SEQ_PTR(_forward_61488);
    _30537 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_30537) ){
        goto L6; // [98] 204
    }
    if(!IS_ATOM_INT(_30537)){
        if( (DBL_PTR(_30537)->dbl != (eudouble) ((object) DBL_PTR(_30537)->dbl) ) ){
            goto L6; // [98] 204
        }
        _0 = (object) DBL_PTR(_30537)->dbl;
    }
    else {
        _0 = _30537;
    };
    _30537 = NOVALUE;
    switch ( _0 ){ 

        /** parser.e:3925						case LEFT_ROUND then*/
        case -26:

        /** parser.e:3926							StartSourceLine( TRUE )*/
        _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

        /** parser.e:3928							Forward_call( tok )*/
        Ref(_tok_61464);
        _43Forward_call(_tok_61464, 195LL);

        /** parser.e:3929							flush_temps()*/
        RefDS(_22218);
        _45flush_temps(_22218);

        /** parser.e:3930							continue*/
        DeRef(_forward_61488);
        _forward_61488 = NOVALUE;
        goto L1; // [133] 16
        goto L6; // [135] 204

        /** parser.e:3932						case VARIABLE then*/
        case -100:

        /** parser.e:3933							putback( forward )*/
        Ref(_forward_61488);
        _43putback(_forward_61488);

        /** parser.e:3934							if param_num != -1 then*/
        if (_43param_num_55477 == -1LL)
        goto L7; // [150] 176

        /** parser.e:3936								param_num += 1*/
        _43param_num_55477 = _43param_num_55477 + 1;

        /** parser.e:3937								Private_declaration( tok[T_SYM] )*/
        _2 = (object)SEQ_PTR(_tok_61464);
        _30542 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_30542);
        _43Private_declaration(_30542);
        _30542 = NOVALUE;
        goto L8; // [173] 192
L7: 

        /** parser.e:3939								Global_declaration( tok[T_SYM], SC_LOCAL )*/
        _2 = (object)SEQ_PTR(_tok_61464);
        _30543 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_30543);
        _30544 = _43Global_declaration(_30543, 5LL);
        _30543 = NOVALUE;
L8: 

        /** parser.e:3941							flush_temps()*/
        RefDS(_22218);
        _45flush_temps(_22218);

        /** parser.e:3942							continue*/
        DeRef(_forward_61488);
        _forward_61488 = NOVALUE;
        goto L1; // [201] 16
    ;}L6: 

    /** parser.e:3945					putback( forward )*/
    Ref(_forward_61488);
    _43putback(_forward_61488);
L5: 
    DeRef(_forward_61488);
    _forward_61488 = NOVALUE;

    /** parser.e:3947				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:3948				Assignment(tok)*/
    Ref(_tok_61464);
    _43Assignment(_tok_61464);
    goto L9; // [226] 1115
L4: 

    /** parser.e:3950			elsif id = PROC or id = QUALIFIED_PROC then*/
    _30545 = (_id_61465 == 27LL);
    if (_30545 != 0) {
        goto LA; // [237] 252
    }
    _30547 = (_id_61465 == 521LL);
    if (_30547 == 0)
    {
        DeRef(_30547);
        _30547 = NOVALUE;
        goto LB; // [248] 289
    }
    else{
        DeRef(_30547);
        _30547 = NOVALUE;
    }
LA: 

    /** parser.e:3951				if id = PROC then*/
    if (_id_61465 != 27LL)
    goto LC; // [256] 272

    /** parser.e:3953					UndefinedVar( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_61464);
    _30549 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30549);
    _43UndefinedVar(_30549);
    _30549 = NOVALUE;
LC: 

    /** parser.e:3955				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:3956				Procedure_call(tok)*/
    Ref(_tok_61464);
    _43Procedure_call(_tok_61464);
    goto L9; // [286] 1115
LB: 

    /** parser.e:3958			elsif id = FUNC or id = QUALIFIED_FUNC then*/
    _30550 = (_id_61465 == 501LL);
    if (_30550 != 0) {
        goto LD; // [297] 312
    }
    _30552 = (_id_61465 == 520LL);
    if (_30552 == 0)
    {
        DeRef(_30552);
        _30552 = NOVALUE;
        goto LE; // [308] 362
    }
    else{
        DeRef(_30552);
        _30552 = NOVALUE;
    }
LD: 

    /** parser.e:3959				if id = FUNC then*/
    if (_id_61465 != 501LL)
    goto LF; // [316] 332

    /** parser.e:3961					UndefinedVar( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_61464);
    _30554 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30554);
    _43UndefinedVar(_30554);
    _30554 = NOVALUE;
LF: 

    /** parser.e:3963				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:3964				Procedure_call(tok)*/
    Ref(_tok_61464);
    _43Procedure_call(_tok_61464);

    /** parser.e:3965				clear_op()*/
    _45clear_op();

    /** parser.e:3966				if Pop() then end if*/
    _30555 = _45Pop();
    if (_30555 == 0) {
        DeRef(_30555);
        _30555 = NOVALUE;
        goto L9; // [355] 1115
    }
    else {
        if (!IS_ATOM_INT(_30555) && DBL_PTR(_30555)->dbl == 0.0){
            DeRef(_30555);
            _30555 = NOVALUE;
            goto L9; // [355] 1115
        }
        DeRef(_30555);
        _30555 = NOVALUE;
    }
    DeRef(_30555);
    _30555 = NOVALUE;
    goto L9; // [359] 1115
LE: 

    /** parser.e:3968			elsif id = IF then*/
    if (_id_61465 != 20LL)
    goto L10; // [366] 386

    /** parser.e:3969				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:3970				If_statement()*/
    _43If_statement();
    goto L9; // [383] 1115
L10: 

    /** parser.e:3972			elsif id = FOR then*/
    if (_id_61465 != 21LL)
    goto L11; // [390] 410

    /** parser.e:3973				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:3974				For_statement()*/
    _43For_statement();
    goto L9; // [407] 1115
L11: 

    /** parser.e:3976			elsif id = RETURN then*/
    if (_id_61465 != 413LL)
    goto L12; // [414] 434

    /** parser.e:3977				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:3978				Return_statement()*/
    _43Return_statement();
    goto L9; // [431] 1115
L12: 

    /** parser.e:3980			elsif id = LABEL then*/
    if (_id_61465 != 419LL)
    goto L13; // [438] 460

    /** parser.e:3981				StartSourceLine(TRUE, , COVERAGE_SUPPRESS )*/
    _45StartSourceLine(_9TRUE_441, 0LL, 1LL);

    /** parser.e:3982				GLabel_statement()*/
    _43GLabel_statement();
    goto L9; // [457] 1115
L13: 

    /** parser.e:3984			elsif id = GOTO then*/
    if (_id_61465 != 188LL)
    goto L14; // [464] 484

    /** parser.e:3985				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:3986				Goto_statement()*/
    _43Goto_statement();
    goto L9; // [481] 1115
L14: 

    /** parser.e:3988			elsif id = EXIT then*/
    if (_id_61465 != 61LL)
    goto L15; // [488] 508

    /** parser.e:3989				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:3990				Exit_statement()*/
    _43Exit_statement();
    goto L9; // [505] 1115
L15: 

    /** parser.e:3992			elsif id = BREAK then*/
    if (_id_61465 != 425LL)
    goto L16; // [512] 532

    /** parser.e:3993				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:3994				Break_statement()*/
    _43Break_statement();
    goto L9; // [529] 1115
L16: 

    /** parser.e:3996			elsif id = WHILE then*/
    if (_id_61465 != 47LL)
    goto L17; // [536] 556

    /** parser.e:3997				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:3998				While_statement()*/
    _43While_statement();
    goto L9; // [553] 1115
L17: 

    /** parser.e:4000			elsif id = LOOP then*/
    if (_id_61465 != 422LL)
    goto L18; // [560] 580

    /** parser.e:4001			    StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:4002		        Loop_statement()*/
    _43Loop_statement();
    goto L9; // [577] 1115
L18: 

    /** parser.e:4004			elsif id = ENTRY then*/
    if (_id_61465 != 424LL)
    goto L19; // [584] 606

    /** parser.e:4005			    StartSourceLine(TRUE, , COVERAGE_SUPPRESS )*/
    _45StartSourceLine(_9TRUE_441, 0LL, 1LL);

    /** parser.e:4006			    Entry_statement()*/
    _43Entry_statement();
    goto L9; // [603] 1115
L19: 

    /** parser.e:4008			elsif id = QUESTION_MARK then*/
    if (_id_61465 != -31LL)
    goto L1A; // [610] 630

    /** parser.e:4009				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:4010				Print_statement()*/
    _43Print_statement();
    goto L9; // [627] 1115
L1A: 

    /** parser.e:4012			elsif id = CONTINUE then*/
    if (_id_61465 != 426LL)
    goto L1B; // [634] 654

    /** parser.e:4013				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:4014				Continue_statement()*/
    _43Continue_statement();
    goto L9; // [651] 1115
L1B: 

    /** parser.e:4016			elsif id = RETRY then*/
    if (_id_61465 != 184LL)
    goto L1C; // [658] 678

    /** parser.e:4017				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:4018				Retry_statement()*/
    _43Retry_statement();
    goto L9; // [675] 1115
L1C: 

    /** parser.e:4020			elsif id = IFDEF then*/
    if (_id_61465 != 407LL)
    goto L1D; // [682] 702

    /** parser.e:4021				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:4022				Ifdef_statement()*/
    _43Ifdef_statement();
    goto L9; // [699] 1115
L1D: 

    /** parser.e:4024			elsif id = CASE then*/
    if (_id_61465 != 186LL)
    goto L1E; // [706] 717

    /** parser.e:4025				Case_statement()*/
    _43Case_statement();
    goto L9; // [714] 1115
L1E: 

    /** parser.e:4027			elsif id = SWITCH then*/
    if (_id_61465 != 185LL)
    goto L1F; // [721] 741

    /** parser.e:4028				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:4029				Switch_statement()*/
    _43Switch_statement();
    goto L9; // [738] 1115
L1F: 

    /** parser.e:4031			elsif id = FALLTHRU then*/
    if (_id_61465 != 431LL)
    goto L20; // [745] 756

    /** parser.e:4032				Fallthru_statement()*/
    _43Fallthru_statement();
    goto L9; // [753] 1115
L20: 

    /** parser.e:4034			elsif id = TYPE or id = QUALIFIED_TYPE then*/
    _30573 = (_id_61465 == 504LL);
    if (_30573 != 0) {
        goto L21; // [764] 779
    }
    _30575 = (_id_61465 == 522LL);
    if (_30575 == 0)
    {
        DeRef(_30575);
        _30575 = NOVALUE;
        goto L22; // [775] 904
    }
    else{
        DeRef(_30575);
        _30575 = NOVALUE;
    }
L21: 

    /** parser.e:4035				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:4036				token test = next_token()*/
    _0 = _test_61637;
    _test_61637 = _43next_token();
    DeRef(_0);

    /** parser.e:4037				putback( test )*/
    Ref(_test_61637);
    _43putback(_test_61637);

    /** parser.e:4038				if test[T_ID] = LEFT_ROUND then*/
    _2 = (object)SEQ_PTR(_test_61637);
    _30577 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30577, -26LL)){
        _30577 = NOVALUE;
        goto L23; // [808] 852
    }
    _30577 = NOVALUE;

    /** parser.e:4039					StartSourceLine( TRUE )*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:4040					Procedure_call(tok)*/
    Ref(_tok_61464);
    _43Procedure_call(_tok_61464);

    /** parser.e:4041					clear_op()*/
    _45clear_op();

    /** parser.e:4042					if Pop() then end if*/
    _30579 = _45Pop();
    if (_30579 == 0) {
        DeRef(_30579);
        _30579 = NOVALUE;
        goto L24; // [835] 839
    }
    else {
        if (!IS_ATOM_INT(_30579) && DBL_PTR(_30579)->dbl == 0.0){
            DeRef(_30579);
            _30579 = NOVALUE;
            goto L24; // [835] 839
        }
        DeRef(_30579);
        _30579 = NOVALUE;
    }
    DeRef(_30579);
    _30579 = NOVALUE;
L24: 

    /** parser.e:4043					ExecCommand()*/
    _43ExecCommand();

    /** parser.e:4044					continue*/
    DeRef(_test_61637);
    _test_61637 = NOVALUE;
    goto L1; // [847] 16
    goto L25; // [849] 899
L23: 

    /** parser.e:4047					if param_num != -1 then*/
    if (_43param_num_55477 == -1LL)
    goto L26; // [856] 882

    /** parser.e:4049						param_num += 1*/
    _43param_num_55477 = _43param_num_55477 + 1;

    /** parser.e:4050						Private_declaration( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_61464);
    _30582 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30582);
    _43Private_declaration(_30582);
    _30582 = NOVALUE;
    goto L27; // [879] 898
L26: 

    /** parser.e:4052						Global_declaration( tok[T_SYM], SC_LOCAL )*/
    _2 = (object)SEQ_PTR(_tok_61464);
    _30583 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30583);
    _30584 = _43Global_declaration(_30583, 5LL);
    _30583 = NOVALUE;
L27: 
L25: 
    DeRef(_test_61637);
    _test_61637 = NOVALUE;
    goto L9; // [901] 1115
L22: 

    /** parser.e:4055			elsif id = LEFT_BRACE then*/
    if (_id_61465 != -24LL)
    goto L28; // [908] 928

    /** parser.e:4056				StartSourceLine( TRUE )*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:4057				Multi_assign()*/
    _43Multi_assign();
    goto L9; // [925] 1115
L28: 

    /** parser.e:4060				if id = ELSE then*/
    if (_id_61465 != 23LL)
    goto L29; // [932] 990

    /** parser.e:4061					if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_43if_stack_55503)){
            _30587 = SEQ_PTR(_43if_stack_55503)->length;
    }
    else {
        _30587 = 1;
    }
    if (_30587 != 0LL)
    goto L2A; // [943] 1051

    /** parser.e:4062						if live_ifdef > 0 then*/
    if (_43live_ifdef_59975 <= 0LL)
    goto L2B; // [951] 976

    /** parser.e:4063							CompileErr(SHOULD_THIS_BE_ELSEDEF_FOR_THE_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59976)){
            _30590 = SEQ_PTR(_43ifdef_lineno_59976)->length;
    }
    else {
        _30590 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59976);
    _30591 = (object)*(((s1_ptr)_2)->base + _30590);
    _49CompileErr(134LL, _30591, 0LL);
    _30591 = NOVALUE;
    goto L2A; // [973] 1051
L2B: 

    /** parser.e:4065							CompileErr(NOT_EXPECTING_ELSE)*/
    RefDS(_22218);
    _49CompileErr(118LL, _22218, 0LL);
    goto L2A; // [987] 1051
L29: 

    /** parser.e:4068				elsif id = ELSIF then*/
    if (_id_61465 != 414LL)
    goto L2C; // [994] 1050

    /** parser.e:4069					if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_43if_stack_55503)){
            _30593 = SEQ_PTR(_43if_stack_55503)->length;
    }
    else {
        _30593 = 1;
    }
    if (_30593 != 0LL)
    goto L2D; // [1005] 1049

    /** parser.e:4070						if live_ifdef > 0 then*/
    if (_43live_ifdef_59975 <= 0LL)
    goto L2E; // [1013] 1038

    /** parser.e:4071							CompileErr(SHOULD_THIS_BE_ELSIFDEF_FOR_THE_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59976)){
            _30596 = SEQ_PTR(_43ifdef_lineno_59976)->length;
    }
    else {
        _30596 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59976);
    _30597 = (object)*(((s1_ptr)_2)->base + _30596);
    _49CompileErr(139LL, _30597, 0LL);
    _30597 = NOVALUE;
    goto L2F; // [1035] 1048
L2E: 

    /** parser.e:4073							CompileErr(NOT_EXPECTING_ELSIF)*/
    RefDS(_22218);
    _49CompileErr(119LL, _22218, 0LL);
L2F: 
L2D: 
L2C: 
L2A: 

    /** parser.e:4078				putback( tok )*/
    Ref(_tok_61464);
    _43putback(_tok_61464);

    /** parser.e:4080				switch id do*/
    _0 = _id_61465;
    switch ( _0 ){ 

        /** parser.e:4081					case END, ELSEDEF, ELSIFDEF, ELSIF, ELSE, UNTIL then*/
        case 402:
        case 409:
        case 408:
        case 414:
        case 23:
        case 423:

        /** parser.e:4083						stmt_nest -= 1*/
        _43stmt_nest_55500 = _43stmt_nest_55500 - 1LL;

        /** parser.e:4084						InitDelete()*/
        _43InitDelete();

        /** parser.e:4085						flush_temps()*/
        RefDS(_22218);
        _45flush_temps(_22218);

        /** parser.e:4086						return*/
        DeRef(_tok_61464);
        DeRef(_30529);
        _30529 = NOVALUE;
        DeRef(_30544);
        _30544 = NOVALUE;
        DeRef(_30584);
        _30584 = NOVALUE;
        DeRef(_30545);
        _30545 = NOVALUE;
        DeRef(_30573);
        _30573 = NOVALUE;
        _30532 = NOVALUE;
        DeRef(_30550);
        _30550 = NOVALUE;
        return;
        goto L30; // [1099] 1114

        /** parser.e:4088					case else*/
        default:

        /** parser.e:4089						tok_match( END )*/
        _43tok_match(402LL, 0LL);
    ;}L30: 
L9: 

    /** parser.e:4094			flush_temps()*/
    RefDS(_22218);
    _45flush_temps(_22218);

    /** parser.e:4095		end while*/
    goto L1; // [1122] 16
L2: 

    /** parser.e:4096	end procedure*/
    DeRef(_tok_61464);
    DeRef(_30529);
    _30529 = NOVALUE;
    DeRef(_30544);
    _30544 = NOVALUE;
    DeRef(_30584);
    _30584 = NOVALUE;
    DeRef(_30545);
    _30545 = NOVALUE;
    DeRef(_30573);
    _30573 = NOVALUE;
    _30532 = NOVALUE;
    DeRef(_30550);
    _30550 = NOVALUE;
    return;
    ;
}


void _43SubProg(object _prog_type_61716, object _scope_61717, object _deprecated_61718)
{
    object _h_61719 = NOVALUE;
    object _pt_61720 = NOVALUE;
    object _p_61722 = NOVALUE;
    object _type_sym_61723 = NOVALUE;
    object _sym_61724 = NOVALUE;
    object _tok_61726 = NOVALUE;
    object _prog_name_61727 = NOVALUE;
    object _first_def_arg_61728 = NOVALUE;
    object _again_61729 = NOVALUE;
    object _type_enum_61730 = NOVALUE;
    object _seq_sym_61731 = NOVALUE;
    object _i1_sym_61732 = NOVALUE;
    object _enum_syms_61733 = NOVALUE;
    object _type_enum_gline_61734 = NOVALUE;
    object _real_gline_61735 = NOVALUE;
    object _tsym_61747 = NOVALUE;
    object _seq_symbol_61758 = NOVALUE;
    object _middle_def_args_61965 = NOVALUE;
    object _last_nda_61966 = NOVALUE;
    object _start_def_61967 = NOVALUE;
    object _last_link_61969 = NOVALUE;
    object _temptok_61996 = NOVALUE;
    object _undef_type_61998 = NOVALUE;
    object _tokcat_62050 = NOVALUE;
    object _32042 = NOVALUE;
    object _32041 = NOVALUE;
    object _32040 = NOVALUE;
    object _32039 = NOVALUE;
    object _32038 = NOVALUE;
    object _32037 = NOVALUE;
    object _32036 = NOVALUE;
    object _32035 = NOVALUE;
    object _32034 = NOVALUE;
    object _30865 = NOVALUE;
    object _30863 = NOVALUE;
    object _30862 = NOVALUE;
    object _30860 = NOVALUE;
    object _30859 = NOVALUE;
    object _30858 = NOVALUE;
    object _30857 = NOVALUE;
    object _30856 = NOVALUE;
    object _30854 = NOVALUE;
    object _30853 = NOVALUE;
    object _30850 = NOVALUE;
    object _30849 = NOVALUE;
    object _30848 = NOVALUE;
    object _30847 = NOVALUE;
    object _30845 = NOVALUE;
    object _30836 = NOVALUE;
    object _30834 = NOVALUE;
    object _30833 = NOVALUE;
    object _30832 = NOVALUE;
    object _30831 = NOVALUE;
    object _30828 = NOVALUE;
    object _30827 = NOVALUE;
    object _30826 = NOVALUE;
    object _30824 = NOVALUE;
    object _30821 = NOVALUE;
    object _30820 = NOVALUE;
    object _30819 = NOVALUE;
    object _30817 = NOVALUE;
    object _30816 = NOVALUE;
    object _30813 = NOVALUE;
    object _30811 = NOVALUE;
    object _30809 = NOVALUE;
    object _30808 = NOVALUE;
    object _30807 = NOVALUE;
    object _30806 = NOVALUE;
    object _30804 = NOVALUE;
    object _30803 = NOVALUE;
    object _30802 = NOVALUE;
    object _30801 = NOVALUE;
    object _30800 = NOVALUE;
    object _30799 = NOVALUE;
    object _30796 = NOVALUE;
    object _30794 = NOVALUE;
    object _30792 = NOVALUE;
    object _30790 = NOVALUE;
    object _30788 = NOVALUE;
    object _30785 = NOVALUE;
    object _30783 = NOVALUE;
    object _30782 = NOVALUE;
    object _30779 = NOVALUE;
    object _30775 = NOVALUE;
    object _30774 = NOVALUE;
    object _30772 = NOVALUE;
    object _30770 = NOVALUE;
    object _30768 = NOVALUE;
    object _30766 = NOVALUE;
    object _30764 = NOVALUE;
    object _30762 = NOVALUE;
    object _30761 = NOVALUE;
    object _30760 = NOVALUE;
    object _30759 = NOVALUE;
    object _30758 = NOVALUE;
    object _30757 = NOVALUE;
    object _30756 = NOVALUE;
    object _30755 = NOVALUE;
    object _30754 = NOVALUE;
    object _30753 = NOVALUE;
    object _30752 = NOVALUE;
    object _30751 = NOVALUE;
    object _30748 = NOVALUE;
    object _30747 = NOVALUE;
    object _30746 = NOVALUE;
    object _30745 = NOVALUE;
    object _30744 = NOVALUE;
    object _30743 = NOVALUE;
    object _30742 = NOVALUE;
    object _30741 = NOVALUE;
    object _30740 = NOVALUE;
    object _30739 = NOVALUE;
    object _30738 = NOVALUE;
    object _30737 = NOVALUE;
    object _30736 = NOVALUE;
    object _30735 = NOVALUE;
    object _30734 = NOVALUE;
    object _30732 = NOVALUE;
    object _30730 = NOVALUE;
    object _30729 = NOVALUE;
    object _30724 = NOVALUE;
    object _30723 = NOVALUE;
    object _30721 = NOVALUE;
    object _30720 = NOVALUE;
    object _30719 = NOVALUE;
    object _30718 = NOVALUE;
    object _30717 = NOVALUE;
    object _30716 = NOVALUE;
    object _30715 = NOVALUE;
    object _30714 = NOVALUE;
    object _30713 = NOVALUE;
    object _30712 = NOVALUE;
    object _30710 = NOVALUE;
    object _30709 = NOVALUE;
    object _30707 = NOVALUE;
    object _30706 = NOVALUE;
    object _30705 = NOVALUE;
    object _30704 = NOVALUE;
    object _30703 = NOVALUE;
    object _30702 = NOVALUE;
    object _30701 = NOVALUE;
    object _30699 = NOVALUE;
    object _30696 = NOVALUE;
    object _30694 = NOVALUE;
    object _30692 = NOVALUE;
    object _30690 = NOVALUE;
    object _30688 = NOVALUE;
    object _30686 = NOVALUE;
    object _30684 = NOVALUE;
    object _30682 = NOVALUE;
    object _30680 = NOVALUE;
    object _30678 = NOVALUE;
    object _30677 = NOVALUE;
    object _30676 = NOVALUE;
    object _30675 = NOVALUE;
    object _30674 = NOVALUE;
    object _30673 = NOVALUE;
    object _30672 = NOVALUE;
    object _30670 = NOVALUE;
    object _30669 = NOVALUE;
    object _30667 = NOVALUE;
    object _30665 = NOVALUE;
    object _30663 = NOVALUE;
    object _30662 = NOVALUE;
    object _30659 = NOVALUE;
    object _30658 = NOVALUE;
    object _30657 = NOVALUE;
    object _30656 = NOVALUE;
    object _30655 = NOVALUE;
    object _30651 = NOVALUE;
    object _30650 = NOVALUE;
    object _30649 = NOVALUE;
    object _30648 = NOVALUE;
    object _30647 = NOVALUE;
    object _30645 = NOVALUE;
    object _30644 = NOVALUE;
    object _30643 = NOVALUE;
    object _30641 = NOVALUE;
    object _30640 = NOVALUE;
    object _30639 = NOVALUE;
    object _30638 = NOVALUE;
    object _30634 = NOVALUE;
    object _30633 = NOVALUE;
    object _30632 = NOVALUE;
    object _30630 = NOVALUE;
    object _30629 = NOVALUE;
    object _30628 = NOVALUE;
    object _30627 = NOVALUE;
    object _30626 = NOVALUE;
    object _30625 = NOVALUE;
    object _30621 = NOVALUE;
    object _30620 = NOVALUE;
    object _30619 = NOVALUE;
    object _30617 = NOVALUE;
    object _30616 = NOVALUE;
    object _30615 = NOVALUE;
    object _30613 = NOVALUE;
    object _30612 = NOVALUE;
    object _30610 = NOVALUE;
    object _30609 = NOVALUE;
    object _30608 = NOVALUE;
    object _30604 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_prog_type_61716)) {
        _1 = (object)(DBL_PTR(_prog_type_61716)->dbl);
        DeRefDS(_prog_type_61716);
        _prog_type_61716 = _1;
    }

    /** parser.e:4105		integer first_def_arg*/

    /** parser.e:4106		integer again*/

    /** parser.e:4107		integer type_enum*/

    /** parser.e:4108		object seq_sym*/

    /** parser.e:4109		object i1_sym*/

    /** parser.e:4110		sequence enum_syms = {}*/
    RefDS(_22218);
    DeRef(_enum_syms_61733);
    _enum_syms_61733 = _22218;

    /** parser.e:4111		integer type_enum_gline, real_gline*/

    /** parser.e:4113		LeaveTopLevel()*/
    _43LeaveTopLevel();

    /** parser.e:4114		prog_name = next_token()*/
    _0 = _prog_name_61727;
    _prog_name_61727 = _43next_token();
    DeRef(_0);

    /** parser.e:4115		if prog_name[T_ID] = END_OF_FILE then*/
    _2 = (object)SEQ_PTR(_prog_name_61727);
    _30604 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30604, -21LL)){
        _30604 = NOVALUE;
        goto L1; // [45] 59
    }
    _30604 = NOVALUE;

    /** parser.e:4116			CompileErr( AN_IDENTIFIER_IS_EXPECTED_HERE)*/
    RefDS(_22218);
    _49CompileErr(32LL, _22218, 0LL);
L1: 

    /** parser.e:4118		type_enum =  0*/
    _type_enum_61730 = 0LL;

    /** parser.e:4119		if prog_type = TYPE_DECL then*/
    if (_prog_type_61716 != 416LL)
    goto L2; // [68] 322

    /** parser.e:4120			object tsym = prog_name[T_SYM]*/
    DeRef(_tsym_61747);
    _2 = (object)SEQ_PTR(_prog_name_61727);
    _tsym_61747 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_tsym_61747);

    /** parser.e:4121			if equal(sym_name(prog_name[T_SYM]),"enum") then*/
    _2 = (object)SEQ_PTR(_prog_name_61727);
    _30608 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30608);
    _30609 = _53sym_name(_30608);
    _30608 = NOVALUE;
    if (_30609 == _26534)
    _30610 = 1;
    else if (IS_ATOM_INT(_30609) && IS_ATOM_INT(_26534))
    _30610 = 0;
    else
    _30610 = (compare(_30609, _26534) == 0);
    DeRef(_30609);
    _30609 = NOVALUE;
    if (_30610 == 0)
    {
        _30610 = NOVALUE;
        goto L3; // [96] 319
    }
    else{
        _30610 = NOVALUE;
    }

    /** parser.e:4125				EnterTopLevel( FALSE )*/
    _43EnterTopLevel(_9FALSE_439);

    /** parser.e:4126				type_enum_gline = gline_number*/
    _type_enum_gline_61734 = _27gline_number_20576;

    /** parser.e:4127				type_enum = 1*/
    _type_enum_61730 = 1LL;

    /** parser.e:4128				sequence seq_symbol*/

    /** parser.e:4129				prog_name = next_token()*/
    _0 = _prog_name_61727;
    _prog_name_61727 = _43next_token();
    DeRef(_0);

    /** parser.e:4130				if not find(prog_name[T_ID], ADDR_TOKS) then*/
    _2 = (object)SEQ_PTR(_prog_name_61727);
    _30612 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30613 = find_from(_30612, _29ADDR_TOKS_12281, 1LL);
    _30612 = NOVALUE;
    if (_30613 != 0)
    goto L4; // [142] 169
    _30613 = NOVALUE;

    /** parser.e:4131					CompileErr(FOUND__1__BUT_WAS_EXPECTING_AN_IDENTIFIER_NAME, {find_category(prog_name[T_ID])} )*/
    _2 = (object)SEQ_PTR(_prog_name_61727);
    _30615 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_30615);
    _30616 = _62find_category(_30615);
    _30615 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30616;
    _30617 = MAKE_SEQ(_1);
    _30616 = NOVALUE;
    _49CompileErr(25LL, _30617, 0LL);
    _30617 = NOVALUE;
L4: 

    /** parser.e:4133				enum_syms = Global_declaration(-1, scope)*/
    _0 = _enum_syms_61733;
    _enum_syms_61733 = _43Global_declaration(-1LL, _scope_61717);
    DeRef(_0);

    /** parser.e:4134				seq_symbol = enum_syms*/
    RefDS(_enum_syms_61733);
    DeRef(_seq_symbol_61758);
    _seq_symbol_61758 = _enum_syms_61733;

    /** parser.e:4135				for i = 1 to length( enum_syms ) do*/
    if (IS_SEQUENCE(_enum_syms_61733)){
            _30619 = SEQ_PTR(_enum_syms_61733)->length;
    }
    else {
        _30619 = 1;
    }
    {
        object _i_61775;
        _i_61775 = 1LL;
L5: 
        if (_i_61775 > _30619){
            goto L6; // [190] 218
        }

        /** parser.e:4136					seq_symbol[i] = sym_obj(enum_syms[i])*/
        _2 = (object)SEQ_PTR(_enum_syms_61733);
        _30620 = (object)*(((s1_ptr)_2)->base + _i_61775);
        Ref(_30620);
        _30621 = _53sym_obj(_30620);
        _30620 = NOVALUE;
        _2 = (object)SEQ_PTR(_seq_symbol_61758);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _seq_symbol_61758 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_61775);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _30621;
        if( _1 != _30621 ){
            DeRef(_1);
        }
        _30621 = NOVALUE;

        /** parser.e:4137				end for*/
        _i_61775 = _i_61775 + 1LL;
        goto L5; // [213] 197
L6: 
        ;
    }

    /** parser.e:4142				i1_sym = keyfind("i1",-1)*/
    RefDS(_30622);
    DeRef(_32041);
    _32041 = _30622;
    _32042 = _53hashfn(_32041);
    _32041 = NOVALUE;
    RefDS(_30622);
    _0 = _i1_sym_61732;
    _i1_sym_61732 = _53keyfind(_30622, -1LL, _27current_file_no_20571, 0LL, _32042);
    DeRef(_0);
    _32042 = NOVALUE;

    /** parser.e:4143				seq_sym = NewStringSym(seq_symbol)*/
    RefDS(_seq_symbol_61758);
    _0 = _seq_sym_61731;
    _seq_sym_61731 = _53NewStringSym(_seq_symbol_61758);
    DeRef(_0);

    /** parser.e:4144				putback(keyfind("return",-1))*/
    RefDS(_26608);
    DeRef(_32039);
    _32039 = _26608;
    _32040 = _53hashfn(_32039);
    _32039 = NOVALUE;
    RefDS(_26608);
    _30625 = _53keyfind(_26608, -1LL, _27current_file_no_20571, 0LL, _32040);
    _32040 = NOVALUE;
    _43putback(_30625);
    _30625 = NOVALUE;

    /** parser.e:4145				putback({RIGHT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -27LL;
    ((intptr_t *)_2)[2] = 0LL;
    _30626 = MAKE_SEQ(_1);
    _43putback(_30626);
    _30626 = NOVALUE;

    /** parser.e:4146				putback(i1_sym)*/
    Ref(_i1_sym_61732);
    _43putback(_i1_sym_61732);

    /** parser.e:4147				putback(keyfind("object",-1))*/
    RefDS(_23193);
    DeRef(_32037);
    _32037 = _23193;
    _32038 = _53hashfn(_32037);
    _32037 = NOVALUE;
    RefDS(_23193);
    _30627 = _53keyfind(_23193, -1LL, _27current_file_no_20571, 0LL, _32038);
    _32038 = NOVALUE;
    _43putback(_30627);
    _30627 = NOVALUE;

    /** parser.e:4148				putback({LEFT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -26LL;
    ((intptr_t *)_2)[2] = 0LL;
    _30628 = MAKE_SEQ(_1);
    _43putback(_30628);
    _30628 = NOVALUE;

    /** parser.e:4150				LeaveTopLevel()*/
    _43LeaveTopLevel();
L3: 
    DeRef(_seq_symbol_61758);
    _seq_symbol_61758 = NOVALUE;
L2: 
    DeRef(_tsym_61747);
    _tsym_61747 = NOVALUE;

    /** parser.e:4153		if not find(prog_name[T_ID], ADDR_TOKS) then*/
    _2 = (object)SEQ_PTR(_prog_name_61727);
    _30629 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30630 = find_from(_30629, _29ADDR_TOKS_12281, 1LL);
    _30629 = NOVALUE;
    if (_30630 != 0)
    goto L7; // [339] 366
    _30630 = NOVALUE;

    /** parser.e:4154			CompileErr(FOUND__1__BUT_WAS_EXPECTING_AN_IDENTIFIER_NAME, {find_category(prog_name[T_ID])} )*/
    _2 = (object)SEQ_PTR(_prog_name_61727);
    _30632 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_30632);
    _30633 = _62find_category(_30632);
    _30632 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30633;
    _30634 = MAKE_SEQ(_1);
    _30633 = NOVALUE;
    _49CompileErr(25LL, _30634, 0LL);
    _30634 = NOVALUE;
L7: 

    /** parser.e:4156		p = prog_name[T_SYM]*/
    _2 = (object)SEQ_PTR(_prog_name_61727);
    _p_61722 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_p_61722)){
        _p_61722 = (object)DBL_PTR(_p_61722)->dbl;
    }

    /** parser.e:4157		DefinedYet(p)*/
    _53DefinedYet(_p_61722);

    /** parser.e:4158		if prog_type = PROCEDURE then*/
    if (_prog_type_61716 != 405LL)
    goto L8; // [385] 401

    /** parser.e:4159			pt = PROC*/
    _pt_61720 = 27LL;
    goto L9; // [398] 431
L8: 

    /** parser.e:4160		elsif prog_type = FUNCTION then*/
    if (_prog_type_61716 != 406LL)
    goto LA; // [405] 421

    /** parser.e:4161			pt = FUNC*/
    _pt_61720 = 501LL;
    goto L9; // [418] 431
LA: 

    /** parser.e:4163			pt = TYPE*/
    _pt_61720 = 504LL;
L9: 

    /** parser.e:4166		clear_fwd_refs()*/
    _42clear_fwd_refs();

    /** parser.e:4167		if find(SymTab[p][S_SCOPE], {SC_PREDEF, SC_GLOBAL, SC_PUBLIC, SC_EXPORT, SC_OVERRIDE}) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30638 = (object)*(((s1_ptr)_2)->base + _p_61722);
    _2 = (object)SEQ_PTR(_30638);
    _30639 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30638 = NOVALUE;
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 7LL;
    ((intptr_t*)_2)[2] = 6LL;
    ((intptr_t*)_2)[3] = 13LL;
    ((intptr_t*)_2)[4] = 11LL;
    ((intptr_t*)_2)[5] = 12LL;
    _30640 = MAKE_SEQ(_1);
    _30641 = find_from(_30639, _30640, 1LL);
    _30639 = NOVALUE;
    DeRefDS(_30640);
    _30640 = NOVALUE;
    if (_30641 == 0)
    {
        _30641 = NOVALUE;
        goto LB; // [472] 668
    }
    else{
        _30641 = NOVALUE;
    }

    /** parser.e:4169			if scope = SC_OVERRIDE then*/
    if (_scope_61717 != 12LL)
    goto LC; // [479] 605

    /** parser.e:4170				if SymTab[p][S_SCOPE] = SC_PREDEF or SymTab[p][S_SCOPE] = SC_OVERRIDE then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30643 = (object)*(((s1_ptr)_2)->base + _p_61722);
    _2 = (object)SEQ_PTR(_30643);
    _30644 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30643 = NOVALUE;
    if (IS_ATOM_INT(_30644)) {
        _30645 = (_30644 == 7LL);
    }
    else {
        _30645 = binary_op(EQUALS, _30644, 7LL);
    }
    _30644 = NOVALUE;
    if (IS_ATOM_INT(_30645)) {
        if (_30645 != 0) {
            goto LD; // [503] 530
        }
    }
    else {
        if (DBL_PTR(_30645)->dbl != 0.0) {
            goto LD; // [503] 530
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30647 = (object)*(((s1_ptr)_2)->base + _p_61722);
    _2 = (object)SEQ_PTR(_30647);
    _30648 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30647 = NOVALUE;
    if (IS_ATOM_INT(_30648)) {
        _30649 = (_30648 == 12LL);
    }
    else {
        _30649 = binary_op(EQUALS, _30648, 12LL);
    }
    _30648 = NOVALUE;
    if (_30649 == 0) {
        DeRef(_30649);
        _30649 = NOVALUE;
        goto LE; // [526] 604
    }
    else {
        if (!IS_ATOM_INT(_30649) && DBL_PTR(_30649)->dbl == 0.0){
            DeRef(_30649);
            _30649 = NOVALUE;
            goto LE; // [526] 604
        }
        DeRef(_30649);
        _30649 = NOVALUE;
    }
    DeRef(_30649);
    _30649 = NOVALUE;
LD: 

    /** parser.e:4171						if SymTab[p][S_SCOPE] = SC_OVERRIDE then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30650 = (object)*(((s1_ptr)_2)->base + _p_61722);
    _2 = (object)SEQ_PTR(_30650);
    _30651 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30650 = NOVALUE;
    if (binary_op_a(NOTEQ, _30651, 12LL)){
        _30651 = NOVALUE;
        goto LF; // [546] 558
    }
    _30651 = NOVALUE;

    /** parser.e:4172							again = 223*/
    _again_61729 = 223LL;
    goto L10; // [555] 564
LF: 

    /** parser.e:4174							again = 222*/
    _again_61729 = 222LL;
L10: 

    /** parser.e:4176						Warning(again, override_warning_flag,*/
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _30655 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30656 = (object)*(((s1_ptr)_2)->base + _p_61722);
    _2 = (object)SEQ_PTR(_30656);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _30657 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _30657 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _30656 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_30655);
    ((intptr_t*)_2)[1] = _30655;
    ((intptr_t*)_2)[2] = _27line_number_20572;
    Ref(_30657);
    ((intptr_t*)_2)[3] = _30657;
    _30658 = MAKE_SEQ(_1);
    _30657 = NOVALUE;
    _30655 = NOVALUE;
    _49Warning(_again_61729, 4LL, _30658);
    _30658 = NOVALUE;
LE: 
LC: 

    /** parser.e:4181			h = SymTab[p][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30659 = (object)*(((s1_ptr)_2)->base + _p_61722);
    _2 = (object)SEQ_PTR(_30659);
    _h_61719 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (!IS_ATOM_INT(_h_61719)){
        _h_61719 = (object)DBL_PTR(_h_61719)->dbl;
    }
    _30659 = NOVALUE;

    /** parser.e:4182			sym = buckets[h]*/
    _2 = (object)SEQ_PTR(_53buckets_47223);
    _sym_61724 = (object)*(((s1_ptr)_2)->base + _h_61719);
    if (!IS_ATOM_INT(_sym_61724)){
        _sym_61724 = (object)DBL_PTR(_sym_61724)->dbl;
    }

    /** parser.e:4183			p = NewEntry(SymTab[p][S_NAME], 0, 0, pt, h, sym, 0)*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30662 = (object)*(((s1_ptr)_2)->base + _p_61722);
    _2 = (object)SEQ_PTR(_30662);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _30663 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _30663 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _30662 = NOVALUE;
    Ref(_30663);
    _p_61722 = _53NewEntry(_30663, 0LL, 0LL, _pt_61720, _h_61719, _sym_61724, 0LL);
    _30663 = NOVALUE;
    if (!IS_ATOM_INT(_p_61722)) {
        _1 = (object)(DBL_PTR(_p_61722)->dbl);
        DeRefDS(_p_61722);
        _p_61722 = _1;
    }

    /** parser.e:4184			buckets[h] = p*/
    _2 = (object)SEQ_PTR(_53buckets_47223);
    _2 = (object)(((s1_ptr)_2)->base + _h_61719);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _p_61722;
    DeRef(_1);
LB: 

    /** parser.e:4187		Start_block( pt, p )*/
    _64Start_block(_pt_61720, _p_61722);

    /** parser.e:4189		CurrentSub = p*/
    _27CurrentSub_20579 = _p_61722;

    /** parser.e:4190		first_def_arg = 0*/
    _first_def_arg_61728 = 0LL;

    /** parser.e:4191		temps_allocated = 0*/
    _53temps_allocated_47760 = 0LL;

    /** parser.e:4193		SymTab[p][S_SCOPE] = scope*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61722 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _scope_61717;
    DeRef(_1);
    _30665 = NOVALUE;

    /** parser.e:4195		SymTab[p][S_TOKEN] = pt*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61722 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_TOKEN_20214))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _pt_61720;
    DeRef(_1);
    _30667 = NOVALUE;

    /** parser.e:4197		if length(SymTab[p]) < SIZEOF_ROUTINE_ENTRY then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30669 = (object)*(((s1_ptr)_2)->base + _p_61722);
    if (IS_SEQUENCE(_30669)){
            _30670 = SEQ_PTR(_30669)->length;
    }
    else {
        _30670 = 1;
    }
    _30669 = NOVALUE;
    if (_30670 >= _27SIZEOF_ROUTINE_ENTRY_20335)
    goto L11; // [738] 780

    /** parser.e:4199			SymTab[p] = SymTab[p] & repeat(0, SIZEOF_ROUTINE_ENTRY -*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30672 = (object)*(((s1_ptr)_2)->base + _p_61722);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30673 = (object)*(((s1_ptr)_2)->base + _p_61722);
    if (IS_SEQUENCE(_30673)){
            _30674 = SEQ_PTR(_30673)->length;
    }
    else {
        _30674 = 1;
    }
    _30673 = NOVALUE;
    _30675 = _27SIZEOF_ROUTINE_ENTRY_20335 - _30674;
    _30674 = NOVALUE;
    _30676 = Repeat(0LL, _30675);
    _30675 = NOVALUE;
    if (IS_SEQUENCE(_30672) && IS_ATOM(_30676)) {
    }
    else if (IS_ATOM(_30672) && IS_SEQUENCE(_30676)) {
        Ref(_30672);
        Prepend(&_30677, _30676, _30672);
    }
    else {
        Concat((object_ptr)&_30677, _30672, _30676);
        _30672 = NOVALUE;
    }
    _30672 = NOVALUE;
    DeRefDS(_30676);
    _30676 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _p_61722);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30677;
    if( _1 != _30677 ){
        DeRef(_1);
    }
    _30677 = NOVALUE;
L11: 

    /** parser.e:4203		SymTab[p][S_CODE] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61722 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30678 = NOVALUE;

    /** parser.e:4204		SymTab[p][S_LINETAB] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61722 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_LINETAB_20244))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_LINETAB_20244)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_LINETAB_20244);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30680 = NOVALUE;

    /** parser.e:4205		SymTab[p][S_EFFECT] = E_PURE*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61722 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30682 = NOVALUE;

    /** parser.e:4206		SymTab[p][S_REFLIST] = {}*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61722 + ((s1_ptr)_2)->base);
    RefDS(_22218);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 24LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22218;
    DeRef(_1);
    _30684 = NOVALUE;

    /** parser.e:4207		SymTab[p][S_FIRSTLINE] = gline_number*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61722 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_FIRSTLINE_20249))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FIRSTLINE_20249)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_FIRSTLINE_20249);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27gline_number_20576;
    DeRef(_1);
    _30686 = NOVALUE;

    /** parser.e:4208		SymTab[p][S_TEMPS] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61722 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_TEMPS_20254))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TEMPS_20254)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_TEMPS_20254);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30688 = NOVALUE;

    /** parser.e:4209		SymTab[p][S_RESIDENT_TASK] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61722 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30690 = NOVALUE;

    /** parser.e:4210		SymTab[p][S_SAVED_PRIVATES] = {}*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61722 + ((s1_ptr)_2)->base);
    RefDS(_22218);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 26LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22218;
    DeRef(_1);
    _30692 = NOVALUE;

    /** parser.e:4211		SymTab[p][S_DEPRECATED] = deprecated*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61722 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _deprecated_61718;
    DeRef(_1);
    _30694 = NOVALUE;

    /** parser.e:4213		if type_enum then*/
    if (_type_enum_61730 == 0)
    {
        goto L12; // [921] 978
    }
    else{
    }

    /** parser.e:4214			SymTab[p][S_FIRSTLINE] = type_enum_gline*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61722 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_FIRSTLINE_20249))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FIRSTLINE_20249)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_FIRSTLINE_20249);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _type_enum_gline_61734;
    DeRef(_1);
    _30696 = NOVALUE;

    /** parser.e:4215			real_gline = gline_number*/
    _real_gline_61735 = _27gline_number_20576;

    /** parser.e:4216			gline_number = type_enum_gline*/
    _27gline_number_20576 = _type_enum_gline_61734;

    /** parser.e:4217			StartSourceLine( FALSE, , COVERAGE_OVERRIDE )*/
    _45StartSourceLine(_9FALSE_439, 0LL, 3LL);

    /** parser.e:4218			gline_number = real_gline*/
    _27gline_number_20576 = _real_gline_61735;
    goto L13; // [975] 990
L12: 

    /** parser.e:4220			StartSourceLine(FALSE, , COVERAGE_OVERRIDE)*/
    _45StartSourceLine(_9FALSE_439, 0LL, 3LL);
L13: 

    /** parser.e:4223		tok_match(LEFT_ROUND)*/
    _43tok_match(-26LL, 0LL);

    /** parser.e:4224		tok = next_token()*/
    _0 = _tok_61726;
    _tok_61726 = _43next_token();
    DeRef(_0);

    /** parser.e:4225		param_num = 0*/
    _43param_num_55477 = 0LL;

    /** parser.e:4228		sequence middle_def_args = {}*/
    RefDS(_22218);
    DeRef(_middle_def_args_61965);
    _middle_def_args_61965 = _22218;

    /** parser.e:4229		integer last_nda = 0, start_def = 0*/
    _last_nda_61966 = 0LL;
    _start_def_61967 = 0LL;

    /** parser.e:4230		symtab_index last_link = p*/
    _last_link_61969 = _p_61722;

    /** parser.e:4231		while tok[T_ID] != RIGHT_ROUND do*/
L14: 
    _2 = (object)SEQ_PTR(_tok_61726);
    _30699 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _30699, -27LL)){
        _30699 = NOVALUE;
        goto L15; // [1043] 1830
    }
    _30699 = NOVALUE;

    /** parser.e:4234			if tok[T_ID] != TYPE and tok[T_ID] != QUALIFIED_TYPE then*/
    _2 = (object)SEQ_PTR(_tok_61726);
    _30701 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30701)) {
        _30702 = (_30701 != 504LL);
    }
    else {
        _30702 = binary_op(NOTEQ, _30701, 504LL);
    }
    _30701 = NOVALUE;
    if (IS_ATOM_INT(_30702)) {
        if (_30702 == 0) {
            goto L16; // [1061] 1291
        }
    }
    else {
        if (DBL_PTR(_30702)->dbl == 0.0) {
            goto L16; // [1061] 1291
        }
    }
    _2 = (object)SEQ_PTR(_tok_61726);
    _30704 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30704)) {
        _30705 = (_30704 != 522LL);
    }
    else {
        _30705 = binary_op(NOTEQ, _30704, 522LL);
    }
    _30704 = NOVALUE;
    if (_30705 == 0) {
        DeRef(_30705);
        _30705 = NOVALUE;
        goto L16; // [1078] 1291
    }
    else {
        if (!IS_ATOM_INT(_30705) && DBL_PTR(_30705)->dbl == 0.0){
            DeRef(_30705);
            _30705 = NOVALUE;
            goto L16; // [1078] 1291
        }
        DeRef(_30705);
        _30705 = NOVALUE;
    }
    DeRef(_30705);
    _30705 = NOVALUE;

    /** parser.e:4235				if tok[T_ID] = VARIABLE or tok[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_61726);
    _30706 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30706)) {
        _30707 = (_30706 == -100LL);
    }
    else {
        _30707 = binary_op(EQUALS, _30706, -100LL);
    }
    _30706 = NOVALUE;
    if (IS_ATOM_INT(_30707)) {
        if (_30707 != 0) {
            goto L17; // [1095] 1116
        }
    }
    else {
        if (DBL_PTR(_30707)->dbl != 0.0) {
            goto L17; // [1095] 1116
        }
    }
    _2 = (object)SEQ_PTR(_tok_61726);
    _30709 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30709)) {
        _30710 = (_30709 == 512LL);
    }
    else {
        _30710 = binary_op(EQUALS, _30709, 512LL);
    }
    _30709 = NOVALUE;
    if (_30710 == 0) {
        DeRef(_30710);
        _30710 = NOVALUE;
        goto L18; // [1112] 1280
    }
    else {
        if (!IS_ATOM_INT(_30710) && DBL_PTR(_30710)->dbl == 0.0){
            DeRef(_30710);
            _30710 = NOVALUE;
            goto L18; // [1112] 1280
        }
        DeRef(_30710);
        _30710 = NOVALUE;
    }
    DeRef(_30710);
    _30710 = NOVALUE;
L17: 

    /** parser.e:4237					token temptok = next_token()*/
    _0 = _temptok_61996;
    _temptok_61996 = _43next_token();
    DeRef(_0);

    /** parser.e:4238					integer undef_type = 0*/
    _undef_type_61998 = 0LL;

    /** parser.e:4239					if temptok[T_ID] != TYPE and temptok[T_ID] != QUALIFIED_TYPE then*/
    _2 = (object)SEQ_PTR(_temptok_61996);
    _30712 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30712)) {
        _30713 = (_30712 != 504LL);
    }
    else {
        _30713 = binary_op(NOTEQ, _30712, 504LL);
    }
    _30712 = NOVALUE;
    if (IS_ATOM_INT(_30713)) {
        if (_30713 == 0) {
            goto L19; // [1140] 1243
        }
    }
    else {
        if (DBL_PTR(_30713)->dbl == 0.0) {
            goto L19; // [1140] 1243
        }
    }
    _2 = (object)SEQ_PTR(_temptok_61996);
    _30715 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30715)) {
        _30716 = (_30715 != 522LL);
    }
    else {
        _30716 = binary_op(NOTEQ, _30715, 522LL);
    }
    _30715 = NOVALUE;
    if (_30716 == 0) {
        DeRef(_30716);
        _30716 = NOVALUE;
        goto L19; // [1157] 1243
    }
    else {
        if (!IS_ATOM_INT(_30716) && DBL_PTR(_30716)->dbl == 0.0){
            DeRef(_30716);
            _30716 = NOVALUE;
            goto L19; // [1157] 1243
        }
        DeRef(_30716);
        _30716 = NOVALUE;
    }
    DeRef(_30716);
    _30716 = NOVALUE;

    /** parser.e:4240						if find( temptok[T_ID], FULL_ID_TOKS) then*/
    _2 = (object)SEQ_PTR(_temptok_61996);
    _30717 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30718 = find_from(_30717, _29FULL_ID_TOKS_12285, 1LL);
    _30717 = NOVALUE;
    if (_30718 == 0)
    {
        _30718 = NOVALUE;
        goto L1A; // [1175] 1242
    }
    else{
        _30718 = NOVALUE;
    }

    /** parser.e:4242							if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_tok_61726);
    _30719 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30719)){
        _30720 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30719)->dbl));
    }
    else{
        _30720 = (object)*(((s1_ptr)_2)->base + _30719);
    }
    _2 = (object)SEQ_PTR(_30720);
    _30721 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30720 = NOVALUE;
    if (binary_op_a(NOTEQ, _30721, 9LL)){
        _30721 = NOVALUE;
        goto L1B; // [1200] 1231
    }
    _30721 = NOVALUE;

    /** parser.e:4245								undef_type = - new_forward_reference( TYPE, tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_61726);
    _30723 = (object)*(((s1_ptr)_2)->base + 2LL);
    DeRef(_32036);
    _32036 = 504LL;
    Ref(_30723);
    _30724 = _42new_forward_reference(504LL, _30723, 504LL);
    _30723 = NOVALUE;
    _32036 = NOVALUE;
    if (IS_ATOM_INT(_30724)) {
        if ((uintptr_t)_30724 == (uintptr_t)HIGH_BITS){
            _undef_type_61998 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _undef_type_61998 = - _30724;
        }
    }
    else {
        _undef_type_61998 = unary_op(UMINUS, _30724);
    }
    DeRef(_30724);
    _30724 = NOVALUE;
    if (!IS_ATOM_INT(_undef_type_61998)) {
        _1 = (object)(DBL_PTR(_undef_type_61998)->dbl);
        DeRefDS(_undef_type_61998);
        _undef_type_61998 = _1;
    }
    goto L1C; // [1228] 1241
L1B: 

    /** parser.e:4247								CompileErr(A_TYPE_IS_EXPECTED_HERE)*/
    RefDS(_22218);
    _49CompileErr(37LL, _22218, 0LL);
L1C: 
L1A: 
L19: 

    /** parser.e:4251					putback(temptok) -- Return whatever came after the name back onto the token stream.*/
    Ref(_temptok_61996);
    _43putback(_temptok_61996);

    /** parser.e:4252					if undef_type != 0 then*/
    if (_undef_type_61998 == 0LL)
    goto L1D; // [1250] 1265

    /** parser.e:4254						tok[T_SYM] = undef_type*/
    _2 = (object)SEQ_PTR(_tok_61726);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_61726 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _undef_type_61998;
    DeRef(_1);
    goto L1E; // [1262] 1275
L1D: 

    /** parser.e:4256						CompileErr(A_TYPE_IS_EXPECTED_HERE)*/
    RefDS(_22218);
    _49CompileErr(37LL, _22218, 0LL);
L1E: 
    DeRef(_temptok_61996);
    _temptok_61996 = NOVALUE;
    goto L1F; // [1277] 1290
L18: 

    /** parser.e:4259					CompileErr(A_TYPE_IS_EXPECTED_HERE)*/
    RefDS(_22218);
    _49CompileErr(37LL, _22218, 0LL);
L1F: 
L16: 

    /** parser.e:4262			type_sym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_61726);
    _type_sym_61723 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_type_sym_61723)){
        _type_sym_61723 = (object)DBL_PTR(_type_sym_61723)->dbl;
    }

    /** parser.e:4263			tok = next_token()*/
    _0 = _tok_61726;
    _tok_61726 = _43next_token();
    DeRef(_0);

    /** parser.e:4264			if not find(tok[T_ID], ID_TOKS) then*/
    _2 = (object)SEQ_PTR(_tok_61726);
    _30729 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30730 = find_from(_30729, _29ID_TOKS_12283, 1LL);
    _30729 = NOVALUE;
    if (_30730 != 0)
    goto L20; // [1321] 1439
    _30730 = NOVALUE;

    /** parser.e:4265				sequence tokcat = find_category(tok[T_ID])*/
    _2 = (object)SEQ_PTR(_tok_61726);
    _30732 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_30732);
    _0 = _tokcat_62050;
    _tokcat_62050 = _62find_category(_30732);
    DeRef(_0);
    _30732 = NOVALUE;

    /** parser.e:4266				if tok[T_SYM] != 0 and length(SymTab[tok[T_SYM]]) >= S_NAME then*/
    _2 = (object)SEQ_PTR(_tok_61726);
    _30734 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_30734)) {
        _30735 = (_30734 != 0LL);
    }
    else {
        _30735 = binary_op(NOTEQ, _30734, 0LL);
    }
    _30734 = NOVALUE;
    if (IS_ATOM_INT(_30735)) {
        if (_30735 == 0) {
            goto L21; // [1350] 1413
        }
    }
    else {
        if (DBL_PTR(_30735)->dbl == 0.0) {
            goto L21; // [1350] 1413
        }
    }
    _2 = (object)SEQ_PTR(_tok_61726);
    _30737 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30737)){
        _30738 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30737)->dbl));
    }
    else{
        _30738 = (object)*(((s1_ptr)_2)->base + _30737);
    }
    if (IS_SEQUENCE(_30738)){
            _30739 = SEQ_PTR(_30738)->length;
    }
    else {
        _30739 = 1;
    }
    _30738 = NOVALUE;
    if (IS_ATOM_INT(_27S_NAME_20209)) {
        _30740 = (_30739 >= _27S_NAME_20209);
    }
    else {
        _30740 = binary_op(GREATEREQ, _30739, _27S_NAME_20209);
    }
    _30739 = NOVALUE;
    if (_30740 == 0) {
        DeRef(_30740);
        _30740 = NOVALUE;
        goto L21; // [1376] 1413
    }
    else {
        if (!IS_ATOM_INT(_30740) && DBL_PTR(_30740)->dbl == 0.0){
            DeRef(_30740);
            _30740 = NOVALUE;
            goto L21; // [1376] 1413
        }
        DeRef(_30740);
        _30740 = NOVALUE;
    }
    DeRef(_30740);
    _30740 = NOVALUE;

    /** parser.e:4267					CompileErr(FOUND_1_2_BUT_WAS_EXPECTING_A_PARAMETER_NAME_INSTEAD, {tokcat, SymTab[tok[T_SYM]][S_NAME]})*/
    _2 = (object)SEQ_PTR(_tok_61726);
    _30741 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30741)){
        _30742 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30741)->dbl));
    }
    else{
        _30742 = (object)*(((s1_ptr)_2)->base + _30741);
    }
    _2 = (object)SEQ_PTR(_30742);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _30743 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _30743 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _30742 = NOVALUE;
    Ref(_30743);
    RefDS(_tokcat_62050);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _tokcat_62050;
    ((intptr_t *)_2)[2] = _30743;
    _30744 = MAKE_SEQ(_1);
    _30743 = NOVALUE;
    _49CompileErr(90LL, _30744, 0LL);
    _30744 = NOVALUE;
    goto L22; // [1410] 1438
L21: 

    /** parser.e:4269					CompileErr(FOUND_1_BUT_WAS_EXPECTING_A_PARAMETER_NAME_INSTEAD, {LexName(tok[T_ID])})*/
    _2 = (object)SEQ_PTR(_tok_61726);
    _30745 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_30745);
    RefDS(_26682);
    _30746 = _45LexName(_30745, _26682);
    _30745 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30746;
    _30747 = MAKE_SEQ(_1);
    _30746 = NOVALUE;
    _49CompileErr(92LL, _30747, 0LL);
    _30747 = NOVALUE;
L22: 
L20: 
    DeRef(_tokcat_62050);
    _tokcat_62050 = NOVALUE;

    /** parser.e:4272			sym = SetPrivateScope(tok[T_SYM], type_sym, param_num)*/
    _2 = (object)SEQ_PTR(_tok_61726);
    _30748 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30748);
    _sym_61724 = _43SetPrivateScope(_30748, _type_sym_61723, _43param_num_55477);
    _30748 = NOVALUE;
    if (!IS_ATOM_INT(_sym_61724)) {
        _1 = (object)(DBL_PTR(_sym_61724)->dbl);
        DeRefDS(_sym_61724);
        _sym_61724 = _1;
    }

    /** parser.e:4273			param_num += 1*/
    _43param_num_55477 = _43param_num_55477 + 1;

    /** parser.e:4275			if SymTab[last_link][S_NEXT] != sym*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30751 = (object)*(((s1_ptr)_2)->base + _last_link_61969);
    _2 = (object)SEQ_PTR(_30751);
    _30752 = (object)*(((s1_ptr)_2)->base + 2LL);
    _30751 = NOVALUE;
    if (IS_ATOM_INT(_30752)) {
        _30753 = (_30752 != _sym_61724);
    }
    else {
        _30753 = binary_op(NOTEQ, _30752, _sym_61724);
    }
    _30752 = NOVALUE;
    if (IS_ATOM_INT(_30753)) {
        if (_30753 == 0) {
            goto L23; // [1485] 1566
        }
    }
    else {
        if (DBL_PTR(_30753)->dbl == 0.0) {
            goto L23; // [1485] 1566
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30755 = (object)*(((s1_ptr)_2)->base + _last_link_61969);
    _2 = (object)SEQ_PTR(_30755);
    _30756 = (object)*(((s1_ptr)_2)->base + 2LL);
    _30755 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30756)){
        _30757 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30756)->dbl));
    }
    else{
        _30757 = (object)*(((s1_ptr)_2)->base + _30756);
    }
    _2 = (object)SEQ_PTR(_30757);
    _30758 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30757 = NOVALUE;
    if (IS_ATOM_INT(_30758)) {
        _30759 = (_30758 == 9LL);
    }
    else {
        _30759 = binary_op(EQUALS, _30758, 9LL);
    }
    _30758 = NOVALUE;
    if (_30759 == 0) {
        DeRef(_30759);
        _30759 = NOVALUE;
        goto L23; // [1520] 1566
    }
    else {
        if (!IS_ATOM_INT(_30759) && DBL_PTR(_30759)->dbl == 0.0){
            DeRef(_30759);
            _30759 = NOVALUE;
            goto L23; // [1520] 1566
        }
        DeRef(_30759);
        _30759 = NOVALUE;
    }
    DeRef(_30759);
    _30759 = NOVALUE;

    /** parser.e:4278				SymTab[SymTab[last_link][S_NEXT]][S_NEXT] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30760 = (object)*(((s1_ptr)_2)->base + _last_link_61969);
    _2 = (object)SEQ_PTR(_30760);
    _30761 = (object)*(((s1_ptr)_2)->base + 2LL);
    _30760 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_30761))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_30761)->dbl));
    else
    _3 = (object)(_30761 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30762 = NOVALUE;

    /** parser.e:4279				SymTab[last_link][S_NEXT] = sym*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_last_link_61969 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_61724;
    DeRef(_1);
    _30764 = NOVALUE;
L23: 

    /** parser.e:4282			last_link = sym*/
    _last_link_61969 = _sym_61724;

    /** parser.e:4284			if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L24; // [1577] 1600
    }
    else{
    }

    /** parser.e:4285				SymTab[sym][S_GTYPE] = CompileType(type_sym)*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_61724 + ((s1_ptr)_2)->base);
    _30768 = _43CompileType(_type_sym_61723);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30768;
    if( _1 != _30768 ){
        DeRef(_1);
    }
    _30768 = NOVALUE;
    _30766 = NOVALUE;
L24: 

    /** parser.e:4289			tok = next_token()*/
    _0 = _tok_61726;
    _tok_61726 = _43next_token();
    DeRef(_0);

    /** parser.e:4290			if tok[T_ID] = EQUALS then -- defaulted parameter*/
    _2 = (object)SEQ_PTR(_tok_61726);
    _30770 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30770, 3LL)){
        _30770 = NOVALUE;
        goto L25; // [1615] 1697
    }
    _30770 = NOVALUE;

    /** parser.e:4291				start_recording()*/
    _43start_recording();

    /** parser.e:4292				Expr()*/
    _43Expr();

    /** parser.e:4293				SymTab[sym][S_CODE] = restore_parser()*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_61724 + ((s1_ptr)_2)->base);
    _30774 = _43restore_parser();
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30774;
    if( _1 != _30774 ){
        DeRef(_1);
    }
    _30774 = NOVALUE;
    _30772 = NOVALUE;

    /** parser.e:4294				if Pop() then end if -- don't leak the default argument*/
    _30775 = _45Pop();
    if (_30775 == 0) {
        DeRef(_30775);
        _30775 = NOVALUE;
        goto L26; // [1650] 1654
    }
    else {
        if (!IS_ATOM_INT(_30775) && DBL_PTR(_30775)->dbl == 0.0){
            DeRef(_30775);
            _30775 = NOVALUE;
            goto L26; // [1650] 1654
        }
        DeRef(_30775);
        _30775 = NOVALUE;
    }
    DeRef(_30775);
    _30775 = NOVALUE;
L26: 

    /** parser.e:4295				tok = next_token()*/
    _0 = _tok_61726;
    _tok_61726 = _43next_token();
    DeRef(_0);

    /** parser.e:4296				if first_def_arg = 0 then*/
    if (_first_def_arg_61728 != 0LL)
    goto L27; // [1661] 1673

    /** parser.e:4297					first_def_arg = param_num*/
    _first_def_arg_61728 = _43param_num_55477;
L27: 

    /** parser.e:4299				previous_op = -1 -- no interferences betwen defparms, or them and subsequent code*/
    _27previous_op_20670 = -1LL;

    /** parser.e:4300				if start_def = 0 then*/
    if (_start_def_61967 != 0LL)
    goto L28; // [1682] 1754

    /** parser.e:4301					start_def = param_num*/
    _start_def_61967 = _43param_num_55477;
    goto L28; // [1694] 1754
L25: 

    /** parser.e:4304				last_nda = param_num*/
    _last_nda_61966 = _43param_num_55477;

    /** parser.e:4305				if start_def then*/
    if (_start_def_61967 == 0)
    {
        goto L29; // [1706] 1753
    }
    else{
    }

    /** parser.e:4306					if start_def = param_num-1 then*/
    _30779 = _43param_num_55477 - 1LL;
    if ((object)((uintptr_t)_30779 +(uintptr_t) HIGH_BITS) >= 0){
        _30779 = NewDouble((eudouble)_30779);
    }
    if (binary_op_a(NOTEQ, _start_def_61967, _30779)){
        DeRef(_30779);
        _30779 = NOVALUE;
        goto L2A; // [1717] 1730
    }
    DeRef(_30779);
    _30779 = NOVALUE;

    /** parser.e:4307						middle_def_args &= start_def*/
    Append(&_middle_def_args_61965, _middle_def_args_61965, _start_def_61967);
    goto L2B; // [1727] 1747
L2A: 

    /** parser.e:4309						middle_def_args = append(middle_def_args, {start_def, param_num-1})*/
    _30782 = _43param_num_55477 - 1LL;
    if ((object)((uintptr_t)_30782 +(uintptr_t) HIGH_BITS) >= 0){
        _30782 = NewDouble((eudouble)_30782);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _start_def_61967;
    ((intptr_t *)_2)[2] = _30782;
    _30783 = MAKE_SEQ(_1);
    _30782 = NOVALUE;
    RefDS(_30783);
    Append(&_middle_def_args_61965, _middle_def_args_61965, _30783);
    DeRefDS(_30783);
    _30783 = NOVALUE;
L2B: 

    /** parser.e:4311					start_def = 0*/
    _start_def_61967 = 0LL;
L29: 
L28: 

    /** parser.e:4314			if tok[T_ID] = COMMA then*/
    _2 = (object)SEQ_PTR(_tok_61726);
    _30785 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30785, -30LL)){
        _30785 = NOVALUE;
        goto L2C; // [1764] 1800
    }
    _30785 = NOVALUE;

    /** parser.e:4315				tok = next_token()*/
    _0 = _tok_61726;
    _tok_61726 = _43next_token();
    DeRef(_0);

    /** parser.e:4316				if tok[T_ID] = RIGHT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok_61726);
    _30788 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30788, -27LL)){
        _30788 = NOVALUE;
        goto L14; // [1783] 1035
    }
    _30788 = NOVALUE;

    /** parser.e:4317					CompileErr(EXPECTED_TO_SEE_A_PARAMETER_DECLARATION_NOT)*/
    RefDS(_22218);
    _49CompileErr(85LL, _22218, 0LL);
    goto L14; // [1797] 1035
L2C: 

    /** parser.e:4319			elsif tok[T_ID] != RIGHT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok_61726);
    _30790 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _30790, -27LL)){
        _30790 = NOVALUE;
        goto L14; // [1810] 1035
    }
    _30790 = NOVALUE;

    /** parser.e:4320				CompileErr(BADLYFORMED_LIST_OF_PARAMETERS__EXPECTED__OR)*/
    RefDS(_22218);
    _49CompileErr(41LL, _22218, 0LL);

    /** parser.e:4322		end while*/
    goto L14; // [1827] 1035
L15: 

    /** parser.e:4323		Code = {} -- removes any spurious code emitted while recording parameters*/
    RefDS(_22218);
    DeRef(_27Code_20660);
    _27Code_20660 = _22218;

    /** parser.e:4325		SymTab[p][S_NUM_ARGS] = param_num*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61722 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _43param_num_55477;
    DeRef(_1);
    _30792 = NOVALUE;

    /** parser.e:4326		SymTab[p][S_DEF_ARGS] = {first_def_arg, last_nda, middle_def_args}*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61722 + ((s1_ptr)_2)->base);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _first_def_arg_61728;
    ((intptr_t*)_2)[2] = _last_nda_61966;
    RefDS(_middle_def_args_61965);
    ((intptr_t*)_2)[3] = _middle_def_args_61965;
    _30796 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 28LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30796;
    if( _1 != _30796 ){
        DeRef(_1);
    }
    _30796 = NOVALUE;
    _30794 = NOVALUE;

    /** parser.e:4327		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L2D; // [1879] 1913
    }
    else{
    }

    /** parser.e:4328			if param_num > max_params then*/
    if (_43param_num_55477 <= _45max_params_51479)
    goto L2E; // [1888] 1902

    /** parser.e:4329				max_params = param_num*/
    _45max_params_51479 = _43param_num_55477;
L2E: 

    /** parser.e:4331			num_routines += 1*/
    _27num_routines_20580 = _27num_routines_20580 + 1LL;
L2D: 

    /** parser.e:4333		if SymTab[p][S_TOKEN] = TYPE and param_num != 1 then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30799 = (object)*(((s1_ptr)_2)->base + _p_61722);
    _2 = (object)SEQ_PTR(_30799);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _30800 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _30800 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _30799 = NOVALUE;
    if (IS_ATOM_INT(_30800)) {
        _30801 = (_30800 == 504LL);
    }
    else {
        _30801 = binary_op(EQUALS, _30800, 504LL);
    }
    _30800 = NOVALUE;
    if (IS_ATOM_INT(_30801)) {
        if (_30801 == 0) {
            goto L2F; // [1933] 1957
        }
    }
    else {
        if (DBL_PTR(_30801)->dbl == 0.0) {
            goto L2F; // [1933] 1957
        }
    }
    _30803 = (_43param_num_55477 != 1LL);
    if (_30803 == 0)
    {
        DeRef(_30803);
        _30803 = NOVALUE;
        goto L2F; // [1944] 1957
    }
    else{
        DeRef(_30803);
        _30803 = NOVALUE;
    }

    /** parser.e:4334			CompileErr(TYPES_MUST_HAVE_EXACTLY_ONE_PARAMETER)*/
    RefDS(_22218);
    _49CompileErr(148LL, _22218, 0LL);
L2F: 

    /** parser.e:4337		include_routine()*/
    _50include_routine();

    /** parser.e:4340		sym = SymTab[p][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30804 = (object)*(((s1_ptr)_2)->base + _p_61722);
    _2 = (object)SEQ_PTR(_30804);
    _sym_61724 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_sym_61724)){
        _sym_61724 = (object)DBL_PTR(_sym_61724)->dbl;
    }
    _30804 = NOVALUE;

    /** parser.e:4341		for i = 1 to SymTab[p][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30806 = (object)*(((s1_ptr)_2)->base + _p_61722);
    _2 = (object)SEQ_PTR(_30806);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _30807 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _30807 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _30806 = NOVALUE;
    {
        object _i_62209;
        _i_62209 = 1LL;
L30: 
        if (binary_op_a(GREATER, _i_62209, _30807)){
            goto L31; // [1991] 2070
        }

        /** parser.e:4342			while SymTab[sym][S_SCOPE] != SC_PRIVATE do*/
L32: 
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _30808 = (object)*(((s1_ptr)_2)->base + _sym_61724);
        _2 = (object)SEQ_PTR(_30808);
        _30809 = (object)*(((s1_ptr)_2)->base + 4LL);
        _30808 = NOVALUE;
        if (binary_op_a(EQUALS, _30809, 3LL)){
            _30809 = NOVALUE;
            goto L33; // [2017] 2042
        }
        _30809 = NOVALUE;

        /** parser.e:4343				sym = SymTab[sym][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _30811 = (object)*(((s1_ptr)_2)->base + _sym_61724);
        _2 = (object)SEQ_PTR(_30811);
        _sym_61724 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_sym_61724)){
            _sym_61724 = (object)DBL_PTR(_sym_61724)->dbl;
        }
        _30811 = NOVALUE;

        /** parser.e:4344			end while*/
        goto L32; // [2039] 2003
L33: 

        /** parser.e:4345			TypeCheck(sym)*/
        _43TypeCheck(_sym_61724);

        /** parser.e:4346			sym = SymTab[sym][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _30813 = (object)*(((s1_ptr)_2)->base + _sym_61724);
        _2 = (object)SEQ_PTR(_30813);
        _sym_61724 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_sym_61724)){
            _sym_61724 = (object)DBL_PTR(_sym_61724)->dbl;
        }
        _30813 = NOVALUE;

        /** parser.e:4347		end for*/
        _0 = _i_62209;
        if (IS_ATOM_INT(_i_62209)) {
            _i_62209 = _i_62209 + 1LL;
            if ((object)((uintptr_t)_i_62209 +(uintptr_t) HIGH_BITS) >= 0){
                _i_62209 = NewDouble((eudouble)_i_62209);
            }
        }
        else {
            _i_62209 = binary_op_a(PLUS, _i_62209, 1LL);
        }
        DeRef(_0);
        goto L30; // [2065] 1998
L31: 
        ;
        DeRef(_i_62209);
    }

    /** parser.e:4352		tok = next_token()*/
    _0 = _tok_61726;
    _tok_61726 = _43next_token();
    DeRef(_0);

    /** parser.e:4353		while tok[T_ID] = TYPE or tok[T_ID] = QUALIFIED_TYPE do*/
L34: 
    _2 = (object)SEQ_PTR(_tok_61726);
    _30816 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30816)) {
        _30817 = (_30816 == 504LL);
    }
    else {
        _30817 = binary_op(EQUALS, _30816, 504LL);
    }
    _30816 = NOVALUE;
    if (IS_ATOM_INT(_30817)) {
        if (_30817 != 0) {
            goto L35; // [2092] 2113
        }
    }
    else {
        if (DBL_PTR(_30817)->dbl != 0.0) {
            goto L35; // [2092] 2113
        }
    }
    _2 = (object)SEQ_PTR(_tok_61726);
    _30819 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30819)) {
        _30820 = (_30819 == 522LL);
    }
    else {
        _30820 = binary_op(EQUALS, _30819, 522LL);
    }
    _30819 = NOVALUE;
    if (_30820 <= 0) {
        if (_30820 == 0) {
            DeRef(_30820);
            _30820 = NOVALUE;
            goto L36; // [2109] 2134
        }
        else {
            if (!IS_ATOM_INT(_30820) && DBL_PTR(_30820)->dbl == 0.0){
                DeRef(_30820);
                _30820 = NOVALUE;
                goto L36; // [2109] 2134
            }
            DeRef(_30820);
            _30820 = NOVALUE;
        }
    }
    DeRef(_30820);
    _30820 = NOVALUE;
L35: 

    /** parser.e:4354			Private_declaration(tok[T_SYM])*/
    _2 = (object)SEQ_PTR(_tok_61726);
    _30821 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30821);
    _43Private_declaration(_30821);
    _30821 = NOVALUE;

    /** parser.e:4355			tok = next_token()*/
    _0 = _tok_61726;
    _tok_61726 = _43next_token();
    DeRef(_0);

    /** parser.e:4356		end while*/
    goto L34; // [2131] 2080
L36: 

    /** parser.e:4358		if not TRANSLATE then*/
    if (_27TRANSLATE_20179 != 0)
    goto L37; // [2138] 2241

    /** parser.e:4359			if OpTrace then*/
    if (_27OpTrace_20641 == 0)
    {
        goto L38; // [2145] 2240
    }
    else{
    }

    /** parser.e:4361				emit_op(ERASE_PRIVATE_NAMES)*/
    _45emit_op(88LL);

    /** parser.e:4362				emit_addr(p)*/
    _45emit_addr(_p_61722);

    /** parser.e:4364				sym = SymTab[p][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30824 = (object)*(((s1_ptr)_2)->base + _p_61722);
    _2 = (object)SEQ_PTR(_30824);
    _sym_61724 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_sym_61724)){
        _sym_61724 = (object)DBL_PTR(_sym_61724)->dbl;
    }
    _30824 = NOVALUE;

    /** parser.e:4365				for i = 1 to SymTab[p][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30826 = (object)*(((s1_ptr)_2)->base + _p_61722);
    _2 = (object)SEQ_PTR(_30826);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _30827 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _30827 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _30826 = NOVALUE;
    {
        object _i_62256;
        _i_62256 = 1LL;
L39: 
        if (binary_op_a(GREATER, _i_62256, _30827)){
            goto L3A; // [2190] 2232
        }

        /** parser.e:4366					emit_op(DISPLAY_VAR)*/
        _45emit_op(87LL);

        /** parser.e:4367					emit_addr(sym)*/
        _45emit_addr(_sym_61724);

        /** parser.e:4368					sym = SymTab[sym][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _30828 = (object)*(((s1_ptr)_2)->base + _sym_61724);
        _2 = (object)SEQ_PTR(_30828);
        _sym_61724 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_sym_61724)){
            _sym_61724 = (object)DBL_PTR(_sym_61724)->dbl;
        }
        _30828 = NOVALUE;

        /** parser.e:4369				end for*/
        _0 = _i_62256;
        if (IS_ATOM_INT(_i_62256)) {
            _i_62256 = _i_62256 + 1LL;
            if ((object)((uintptr_t)_i_62256 +(uintptr_t) HIGH_BITS) >= 0){
                _i_62256 = NewDouble((eudouble)_i_62256);
            }
        }
        else {
            _i_62256 = binary_op_a(PLUS, _i_62256, 1LL);
        }
        DeRef(_0);
        goto L39; // [2227] 2197
L3A: 
        ;
        DeRef(_i_62256);
    }

    /** parser.e:4371				emit_op(UPDATE_GLOBALS)*/
    _45emit_op(89LL);
L38: 
L37: 

    /** parser.e:4374		putback(tok)*/
    Ref(_tok_61726);
    _43putback(_tok_61726);

    /** parser.e:4377		FuncReturn = FALSE*/
    _43FuncReturn_55476 = _9FALSE_439;

    /** parser.e:4378		if type_enum then*/
    if (_type_enum_61730 == 0)
    {
        goto L3B; // [2257] 2426
    }
    else{
    }

    /** parser.e:4380			stmt_nest += 1*/
    _43stmt_nest_55500 = _43stmt_nest_55500 + 1;

    /** parser.e:4381			tok_match(RETURN)*/
    _43tok_match(413LL, 0LL);

    /** parser.e:4382			putback({RIGHT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -27LL;
    ((intptr_t *)_2)[2] = 0LL;
    _30831 = MAKE_SEQ(_1);
    _43putback(_30831);
    _30831 = NOVALUE;

    /** parser.e:4383			putback({VARIABLE,seq_sym})*/
    Ref(_seq_sym_61731);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100LL;
    ((intptr_t *)_2)[2] = _seq_sym_61731;
    _30832 = MAKE_SEQ(_1);
    _43putback(_30832);
    _30832 = NOVALUE;

    /** parser.e:4384			putback({COMMA,0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -30LL;
    ((intptr_t *)_2)[2] = 0LL;
    _30833 = MAKE_SEQ(_1);
    _43putback(_30833);
    _30833 = NOVALUE;

    /** parser.e:4385			putback(i1_sym)*/
    Ref(_i1_sym_61732);
    _43putback(_i1_sym_61732);

    /** parser.e:4386			putback({LEFT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -26LL;
    ((intptr_t *)_2)[2] = 0LL;
    _30834 = MAKE_SEQ(_1);
    _43putback(_30834);
    _30834 = NOVALUE;

    /** parser.e:4387			putback(keyfind("find",-1))*/
    RefDS(_30835);
    DeRef(_32034);
    _32034 = _30835;
    _32035 = _53hashfn(_32034);
    _32034 = NOVALUE;
    RefDS(_30835);
    _30836 = _53keyfind(_30835, -1LL, _27current_file_no_20571, 0LL, _32035);
    _32035 = NOVALUE;
    _43putback(_30836);
    _30836 = NOVALUE;

    /** parser.e:4388			if not TRANSLATE then*/
    if (_27TRANSLATE_20179 != 0)
    goto L3C; // [2355] 2381

    /** parser.e:4389				if OpTrace then*/
    if (_27OpTrace_20641 == 0)
    {
        goto L3D; // [2362] 2380
    }
    else{
    }

    /** parser.e:4390					emit_op(ERASE_PRIVATE_NAMES)*/
    _45emit_op(88LL);

    /** parser.e:4391					emit_addr(CurrentSub)*/
    _45emit_addr(_27CurrentSub_20579);
L3D: 
L3C: 

    /** parser.e:4394			Expr()*/
    _43Expr();

    /** parser.e:4395			FuncReturn = TRUE*/
    _43FuncReturn_55476 = _9TRUE_441;

    /** parser.e:4396			emit_op(RETURNF)*/
    _45emit_op(28LL);

    /** parser.e:4397			flush_temps()*/
    RefDS(_22218);
    _45flush_temps(_22218);

    /** parser.e:4398			stmt_nest -= 1*/
    _43stmt_nest_55500 = _43stmt_nest_55500 - 1LL;

    /** parser.e:4399			InitDelete()*/
    _43InitDelete();

    /** parser.e:4400			flush_temps()*/
    RefDS(_22218);
    _45flush_temps(_22218);
    goto L3E; // [2423] 2439
L3B: 

    /** parser.e:4402			Statement_list()*/
    _43Statement_list();

    /** parser.e:4404			tok_match(END)*/
    _43tok_match(402LL, 0LL);
L3E: 

    /** parser.e:4408		tok_match(prog_type, END)*/
    _43tok_match(_prog_type_61716, 402LL);

    /** parser.e:4410		if prog_type != PROCEDURE then*/
    if (_prog_type_61716 == 405LL)
    goto L3F; // [2451] 2503

    /** parser.e:4411			if not FuncReturn then*/
    if (_43FuncReturn_55476 != 0)
    goto L40; // [2459] 2493

    /** parser.e:4412				if prog_type = FUNCTION then*/
    if (_prog_type_61716 != 406LL)
    goto L41; // [2466] 2482

    /** parser.e:4413					CompileErr(NO_VALUE_RETURNED_FROM_FUNCTION)*/
    RefDS(_22218);
    _49CompileErr(120LL, _22218, 0LL);
    goto L42; // [2479] 2492
L41: 

    /** parser.e:4415					CompileErr(TYPE_MUST_RETURN_TRUE__FALSE_VALUE)*/
    RefDS(_22218);
    _49CompileErr(149LL, _22218, 0LL);
L42: 
L40: 

    /** parser.e:4418			emit_op(BADRETURNF) -- function/type shouldn't reach here*/
    _45emit_op(43LL);
    goto L43; // [2500] 2563
L3F: 

    /** parser.e:4421			StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:4422			if not TRANSLATE then*/
    if (_27TRANSLATE_20179 != 0)
    goto L44; // [2516] 2540

    /** parser.e:4423				if OpTrace then*/
    if (_27OpTrace_20641 == 0)
    {
        goto L45; // [2523] 2539
    }
    else{
    }

    /** parser.e:4424					emit_op(ERASE_PRIVATE_NAMES)*/
    _45emit_op(88LL);

    /** parser.e:4425					emit_addr(p)*/
    _45emit_addr(_p_61722);
L45: 
L44: 

    /** parser.e:4428			emit_op(RETURNP)*/
    _45emit_op(29LL);

    /** parser.e:4429			if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L46; // [2551] 2562
    }
    else{
    }

    /** parser.e:4430				emit_op(BADRETURNF) -- just to mark end of procedure*/
    _45emit_op(43LL);
L46: 
L43: 

    /** parser.e:4433		Drop_block( pt )*/
    _64Drop_block(_pt_61720);

    /** parser.e:4435		if Strict_Override > 0 then*/
    if (_27Strict_Override_20638 <= 0LL)
    goto L47; // [2572] 2587

    /** parser.e:4436			Strict_Override -= 1	-- Reset at the end of each routine.*/
    _27Strict_Override_20638 = _27Strict_Override_20638 - 1LL;
L47: 

    /** parser.e:4439		SymTab[p][S_STACK_SPACE] += temps_allocated + param_num*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61722 + ((s1_ptr)_2)->base);
    _30847 = _53temps_allocated_47760 + _43param_num_55477;
    if ((object)((uintptr_t)_30847 + (uintptr_t)HIGH_BITS) >= 0){
        _30847 = NewDouble((eudouble)_30847);
    }
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_27S_STACK_SPACE_20269)){
        _30848 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_STACK_SPACE_20269)->dbl));
    }
    else{
        _30848 = (object)*(((s1_ptr)_2)->base + _27S_STACK_SPACE_20269);
    }
    _30845 = NOVALUE;
    if (IS_ATOM_INT(_30848) && IS_ATOM_INT(_30847)) {
        _30849 = _30848 + _30847;
        if ((object)((uintptr_t)_30849 + (uintptr_t)HIGH_BITS) >= 0){
            _30849 = NewDouble((eudouble)_30849);
        }
    }
    else {
        _30849 = binary_op(PLUS, _30848, _30847);
    }
    _30848 = NOVALUE;
    DeRef(_30847);
    _30847 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_STACK_SPACE_20269))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_STACK_SPACE_20269)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_STACK_SPACE_20269);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30849;
    if( _1 != _30849 ){
        DeRef(_1);
    }
    _30849 = NOVALUE;
    _30845 = NOVALUE;

    /** parser.e:4440		if temps_allocated + param_num > max_stack_per_call then*/
    _30850 = _53temps_allocated_47760 + _43param_num_55477;
    if ((object)((uintptr_t)_30850 + (uintptr_t)HIGH_BITS) >= 0){
        _30850 = NewDouble((eudouble)_30850);
    }
    if (binary_op_a(LESSEQ, _30850, _27max_stack_per_call_20671)){
        DeRef(_30850);
        _30850 = NOVALUE;
        goto L48; // [2630] 2647
    }
    DeRef(_30850);
    _30850 = NOVALUE;

    /** parser.e:4441			max_stack_per_call = temps_allocated + param_num*/
    _27max_stack_per_call_20671 = _53temps_allocated_47760 + _43param_num_55477;
L48: 

    /** parser.e:4443		param_num = -1*/
    _43param_num_55477 = -1LL;

    /** parser.e:4445		StraightenBranches()*/
    _43StraightenBranches();

    /** parser.e:4446		check_inline( p )*/
    _66check_inline(_p_61722);

    /** parser.e:4447		param_num = -1*/
    _43param_num_55477 = -1LL;

    /** parser.e:4448		EnterTopLevel()*/
    _43EnterTopLevel(1LL);

    /** parser.e:4451		if length( enum_syms ) then*/
    if (IS_SEQUENCE(_enum_syms_61733)){
            _30853 = SEQ_PTR(_enum_syms_61733)->length;
    }
    else {
        _30853 = 1;
    }
    if (_30853 == 0)
    {
        _30853 = NOVALUE;
        goto L49; // [2676] 2763
    }
    else{
        _30853 = NOVALUE;
    }

    /** parser.e:4452			SymTab[p][S_NEXT] = SymTab[enum_syms[$]][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61722 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_enum_syms_61733)){
            _30856 = SEQ_PTR(_enum_syms_61733)->length;
    }
    else {
        _30856 = 1;
    }
    _2 = (object)SEQ_PTR(_enum_syms_61733);
    _30857 = (object)*(((s1_ptr)_2)->base + _30856);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30857)){
        _30858 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30857)->dbl));
    }
    else{
        _30858 = (object)*(((s1_ptr)_2)->base + _30857);
    }
    _2 = (object)SEQ_PTR(_30858);
    _30859 = (object)*(((s1_ptr)_2)->base + 2LL);
    _30858 = NOVALUE;
    Ref(_30859);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30859;
    if( _1 != _30859 ){
        DeRef(_1);
    }
    _30859 = NOVALUE;
    _30854 = NOVALUE;

    /** parser.e:4453			SymTab[last_sym][S_NEXT] = enum_syms[1]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_53last_sym_47236 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_enum_syms_61733);
    _30862 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_30862);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30862;
    if( _1 != _30862 ){
        DeRef(_1);
    }
    _30862 = NOVALUE;
    _30860 = NOVALUE;

    /** parser.e:4454			last_sym = enum_syms[$]*/
    if (IS_SEQUENCE(_enum_syms_61733)){
            _30863 = SEQ_PTR(_enum_syms_61733)->length;
    }
    else {
        _30863 = 1;
    }
    _2 = (object)SEQ_PTR(_enum_syms_61733);
    _53last_sym_47236 = (object)*(((s1_ptr)_2)->base + _30863);
    if (!IS_ATOM_INT(_53last_sym_47236)){
        _53last_sym_47236 = (object)DBL_PTR(_53last_sym_47236)->dbl;
    }

    /** parser.e:4455			SymTab[last_sym][S_NEXT] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_53last_sym_47236 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30865 = NOVALUE;
L49: 

    /** parser.e:4457	end procedure*/
    DeRef(_tok_61726);
    DeRef(_prog_name_61727);
    DeRef(_seq_sym_61731);
    DeRef(_i1_sym_61732);
    DeRef(_enum_syms_61733);
    DeRef(_middle_def_args_61965);
    DeRef(_30753);
    _30753 = NOVALUE;
    DeRef(_30735);
    _30735 = NOVALUE;
    _30741 = NOVALUE;
    DeRef(_30713);
    _30713 = NOVALUE;
    DeRef(_30702);
    _30702 = NOVALUE;
    _30738 = NOVALUE;
    DeRef(_30801);
    _30801 = NOVALUE;
    _30737 = NOVALUE;
    _30669 = NOVALUE;
    _30827 = NOVALUE;
    _30761 = NOVALUE;
    _30673 = NOVALUE;
    _30719 = NOVALUE;
    _30857 = NOVALUE;
    DeRef(_30707);
    _30707 = NOVALUE;
    DeRef(_30817);
    _30817 = NOVALUE;
    DeRef(_30645);
    _30645 = NOVALUE;
    _30756 = NOVALUE;
    _30807 = NOVALUE;
    return;
    ;
}


void _43InitGlobals()
{
    object _30884 = NOVALUE;
    object _30882 = NOVALUE;
    object _30881 = NOVALUE;
    object _30880 = NOVALUE;
    object _30879 = NOVALUE;
    object _30878 = NOVALUE;
    object _30877 = NOVALUE;
    object _30875 = NOVALUE;
    object _30874 = NOVALUE;
    object _30873 = NOVALUE;
    object _30872 = NOVALUE;
    object _30870 = NOVALUE;
    object _30869 = NOVALUE;
    object _30868 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:4461		ResetTP()*/
    _61ResetTP();

    /** parser.e:4462		OpTypeCheck = TRUE*/
    _27OpTypeCheck_20642 = _9TRUE_441;

    /** parser.e:4464		OpDefines &= {*/
    _30868 = _40version_major();
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30868;
    _30869 = MAKE_SEQ(_1);
    _30868 = NOVALUE;
    _30870 = EPrintf(-9999999, _30867, _30869);
    DeRefDS(_30869);
    _30869 = NOVALUE;
    _30872 = _40version_major();
    _30873 = _40version_minor();
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _30872;
    ((intptr_t *)_2)[2] = _30873;
    _30874 = MAKE_SEQ(_1);
    _30873 = NOVALUE;
    _30872 = NOVALUE;
    _30875 = EPrintf(-9999999, _30871, _30874);
    DeRefDS(_30874);
    _30874 = NOVALUE;
    _30877 = _40version_major();
    _30878 = _40version_minor();
    _30879 = _40version_patch();
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30877;
    ((intptr_t*)_2)[2] = _30878;
    ((intptr_t*)_2)[3] = _30879;
    _30880 = MAKE_SEQ(_1);
    _30879 = NOVALUE;
    _30878 = NOVALUE;
    _30877 = NOVALUE;
    _30881 = EPrintf(-9999999, _30876, _30880);
    DeRefDS(_30880);
    _30880 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30870;
    ((intptr_t*)_2)[2] = _30875;
    ((intptr_t*)_2)[3] = _30881;
    _30882 = MAKE_SEQ(_1);
    _30881 = NOVALUE;
    _30875 = NOVALUE;
    _30870 = NOVALUE;
    Concat((object_ptr)&_27OpDefines_20645, _27OpDefines_20645, _30882);
    DeRefDS(_30882);
    _30882 = NOVALUE;

    /** parser.e:4470		OpDefines &= GetPlatformDefines()*/
    _30884 = _44GetPlatformDefines(0LL);
    if (IS_SEQUENCE(_27OpDefines_20645) && IS_ATOM(_30884)) {
        Ref(_30884);
        Append(&_27OpDefines_20645, _27OpDefines_20645, _30884);
    }
    else if (IS_ATOM(_27OpDefines_20645) && IS_SEQUENCE(_30884)) {
    }
    else {
        Concat((object_ptr)&_27OpDefines_20645, _27OpDefines_20645, _30884);
    }
    DeRef(_30884);
    _30884 = NOVALUE;

    /** parser.e:4472		if repl then*/

    /** parser.e:4476			OpInline = DEFAULT_INLINE*/
    _27OpInline_20646 = 30LL;

    /** parser.e:4478		OpIndirectInclude = 1*/
    _27OpIndirectInclude_20647 = 1LL;

    /** parser.e:4479	end procedure*/
    return;
    ;
}


void _43not_supported_compile(object _feature_62426)
{
    object _30886 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:4483		CompileErr(MSG_1_IS_NOT_SUPPORTED_IN_EUPHORIA_FOR_2, {feature, version_name})*/
    RefDS(_27version_name_20193);
    RefDS(_feature_62426);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _feature_62426;
    ((intptr_t *)_2)[2] = _27version_name_20193;
    _30886 = MAKE_SEQ(_1);
    _49CompileErr(5LL, _30886, 0LL);
    _30886 = NOVALUE;

    /** parser.e:4484	end procedure*/
    DeRefDSi(_feature_62426);
    return;
    ;
}


void _43SetWith(object _on_off_62433)
{
    object _option_62434 = NOVALUE;
    object _idx_62435 = NOVALUE;
    object _reset_flags_62436 = NOVALUE;
    object _tok_62488 = NOVALUE;
    object _good_sofar_62538 = NOVALUE;
    object _tok_62541 = NOVALUE;
    object _warning_extra_62543 = NOVALUE;
    object _endlist_62636 = NOVALUE;
    object _tok_62785 = NOVALUE;
    object _31033 = NOVALUE;
    object _31032 = NOVALUE;
    object _31031 = NOVALUE;
    object _31030 = NOVALUE;
    object _31029 = NOVALUE;
    object _31026 = NOVALUE;
    object _31025 = NOVALUE;
    object _31024 = NOVALUE;
    object _31022 = NOVALUE;
    object _31020 = NOVALUE;
    object _31019 = NOVALUE;
    object _31018 = NOVALUE;
    object _31015 = NOVALUE;
    object _31013 = NOVALUE;
    object _31012 = NOVALUE;
    object _31011 = NOVALUE;
    object _31010 = NOVALUE;
    object _31009 = NOVALUE;
    object _31005 = NOVALUE;
    object _31003 = NOVALUE;
    object _31001 = NOVALUE;
    object _30997 = NOVALUE;
    object _30992 = NOVALUE;
    object _30991 = NOVALUE;
    object _30986 = NOVALUE;
    object _30985 = NOVALUE;
    object _30984 = NOVALUE;
    object _30983 = NOVALUE;
    object _30982 = NOVALUE;
    object _30981 = NOVALUE;
    object _30980 = NOVALUE;
    object _30979 = NOVALUE;
    object _30978 = NOVALUE;
    object _30977 = NOVALUE;
    object _30975 = NOVALUE;
    object _30974 = NOVALUE;
    object _30972 = NOVALUE;
    object _30971 = NOVALUE;
    object _30970 = NOVALUE;
    object _30968 = NOVALUE;
    object _30967 = NOVALUE;
    object _30965 = NOVALUE;
    object _30962 = NOVALUE;
    object _30960 = NOVALUE;
    object _30957 = NOVALUE;
    object _30956 = NOVALUE;
    object _30955 = NOVALUE;
    object _30954 = NOVALUE;
    object _30947 = NOVALUE;
    object _30946 = NOVALUE;
    object _30944 = NOVALUE;
    object _30941 = NOVALUE;
    object _30940 = NOVALUE;
    object _30938 = NOVALUE;
    object _30937 = NOVALUE;
    object _30936 = NOVALUE;
    object _30935 = NOVALUE;
    object _30934 = NOVALUE;
    object _30933 = NOVALUE;
    object _30930 = NOVALUE;
    object _30929 = NOVALUE;
    object _30928 = NOVALUE;
    object _30927 = NOVALUE;
    object _30926 = NOVALUE;
    object _30925 = NOVALUE;
    object _30922 = NOVALUE;
    object _30921 = NOVALUE;
    object _30920 = NOVALUE;
    object _30918 = NOVALUE;
    object _30915 = NOVALUE;
    object _30913 = NOVALUE;
    object _30912 = NOVALUE;
    object _30910 = NOVALUE;
    object _30909 = NOVALUE;
    object _30908 = NOVALUE;
    object _30907 = NOVALUE;
    object _30906 = NOVALUE;
    object _30905 = NOVALUE;
    object _30903 = NOVALUE;
    object _30900 = NOVALUE;
    object _30899 = NOVALUE;
    object _30898 = NOVALUE;
    object _30897 = NOVALUE;
    object _30895 = NOVALUE;
    object _30894 = NOVALUE;
    object _30893 = NOVALUE;
    object _30892 = NOVALUE;
    object _30890 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:4490		integer reset_flags = 1*/
    _reset_flags_62436 = 1LL;

    /** parser.e:4493		option = StringToken("&+=")*/
    RefDS(_30887);
    _0 = _option_62434;
    _option_62434 = _61StringToken(_30887);
    DeRef(_0);

    /** parser.e:4495		if equal(option, "type_check") then*/
    if (_option_62434 == _30889)
    _30890 = 1;
    else if (IS_ATOM_INT(_option_62434) && IS_ATOM_INT(_30889))
    _30890 = 0;
    else
    _30890 = (compare(_option_62434, _30889) == 0);
    if (_30890 == 0)
    {
        _30890 = NOVALUE;
        goto L1; // [22] 35
    }
    else{
        _30890 = NOVALUE;
    }

    /** parser.e:4496			OpTypeCheck = on_off*/
    _27OpTypeCheck_20642 = _on_off_62433;
    goto L2; // [32] 1546
L1: 

    /** parser.e:4498		elsif equal(option, "profile") then*/
    if (_option_62434 == _30891)
    _30892 = 1;
    else if (IS_ATOM_INT(_option_62434) && IS_ATOM_INT(_30891))
    _30892 = 0;
    else
    _30892 = (compare(_option_62434, _30891) == 0);
    if (_30892 == 0)
    {
        _30892 = NOVALUE;
        goto L3; // [41] 121
    }
    else{
        _30892 = NOVALUE;
    }

    /** parser.e:4499			if not TRANSLATE and not BIND then*/
    _30893 = (_27TRANSLATE_20179 == 0);
    if (_30893 == 0) {
        goto L2; // [51] 1546
    }
    _30895 = (_27BIND_20182 == 0);
    if (_30895 == 0)
    {
        DeRef(_30895);
        _30895 = NOVALUE;
        goto L2; // [61] 1546
    }
    else{
        DeRef(_30895);
        _30895 = NOVALUE;
    }

    /** parser.e:4500				OpProfileStatement = on_off*/
    _27OpProfileStatement_20643 = _on_off_62433;

    /** parser.e:4501				if OpProfileStatement then*/
    if (_27OpProfileStatement_20643 == 0)
    {
        goto L2; // [75] 1546
    }
    else{
    }

    /** parser.e:4502					if AnyTimeProfile then*/
    if (_28AnyTimeProfile_11595 == 0)
    {
        goto L4; // [82] 106
    }
    else{
    }

    /** parser.e:4503						Warning(224, mixed_profile_warning_flag)*/
    RefDS(_22218);
    _49Warning(224LL, 1024LL, _22218);

    /** parser.e:4504						OpProfileStatement = FALSE*/
    _27OpProfileStatement_20643 = _9FALSE_439;
    goto L2; // [103] 1546
L4: 

    /** parser.e:4506						AnyStatementProfile = TRUE*/
    _28AnyStatementProfile_11596 = _9TRUE_441;
    goto L2; // [118] 1546
L3: 

    /** parser.e:4511		elsif equal(option, "profile_time") then*/
    if (_option_62434 == _30896)
    _30897 = 1;
    else if (IS_ATOM_INT(_option_62434) && IS_ATOM_INT(_30896))
    _30897 = 0;
    else
    _30897 = (compare(_option_62434, _30896) == 0);
    if (_30897 == 0)
    {
        _30897 = NOVALUE;
        goto L5; // [127] 364
    }
    else{
        _30897 = NOVALUE;
    }

    /** parser.e:4512			if not TRANSLATE and not BIND then*/
    _30898 = (_27TRANSLATE_20179 == 0);
    if (_30898 == 0) {
        goto L2; // [137] 1546
    }
    _30900 = (_27BIND_20182 == 0);
    if (_30900 == 0)
    {
        DeRef(_30900);
        _30900 = NOVALUE;
        goto L2; // [147] 1546
    }
    else{
        DeRef(_30900);
        _30900 = NOVALUE;
    }

    /** parser.e:4513				if not IWINDOWS then*/
    if (_44IWINDOWS_20714 != 0)
    goto L6; // [154] 169

    /** parser.e:4514					if on_off then*/
    if (_on_off_62433 == 0)
    {
        goto L7; // [159] 168
    }
    else{
    }

    /** parser.e:4515						not_supported_compile("profile_time")*/
    RefDS(_30896);
    _43not_supported_compile(_30896);
L7: 
L6: 

    /** parser.e:4518				OpProfileTime = on_off*/
    _27OpProfileTime_20644 = _on_off_62433;

    /** parser.e:4519				if OpProfileTime then*/
    if (_27OpProfileTime_20644 == 0)
    {
        goto L8; // [180] 358
    }
    else{
    }

    /** parser.e:4520					if AnyStatementProfile then*/
    if (_28AnyStatementProfile_11596 == 0)
    {
        goto L9; // [187] 209
    }
    else{
    }

    /** parser.e:4521						Warning(224,mixed_profile_warning_flag)*/
    RefDS(_22218);
    _49Warning(224LL, 1024LL, _22218);

    /** parser.e:4522						OpProfileTime = FALSE*/
    _27OpProfileTime_20644 = _9FALSE_439;
L9: 

    /** parser.e:4524					token tok = next_token()*/
    _0 = _tok_62488;
    _tok_62488 = _43next_token();
    DeRef(_0);

    /** parser.e:4525					if tok[T_ID] = ATOM then*/
    _2 = (object)SEQ_PTR(_tok_62488);
    _30903 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30903, 502LL)){
        _30903 = NOVALUE;
        goto LA; // [224] 319
    }
    _30903 = NOVALUE;

    /** parser.e:4526						if is_integer(SymTab[tok[T_SYM]][S_OBJ]) then*/
    _2 = (object)SEQ_PTR(_tok_62488);
    _30905 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30905)){
        _30906 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30905)->dbl));
    }
    else{
        _30906 = (object)*(((s1_ptr)_2)->base + _30905);
    }
    _2 = (object)SEQ_PTR(_30906);
    _30907 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30906 = NOVALUE;
    Ref(_30907);
    _30908 = _27is_integer(_30907);
    _30907 = NOVALUE;
    if (_30908 == 0) {
        DeRef(_30908);
        _30908 = NOVALUE;
        goto LB; // [252] 280
    }
    else {
        if (!IS_ATOM_INT(_30908) && DBL_PTR(_30908)->dbl == 0.0){
            DeRef(_30908);
            _30908 = NOVALUE;
            goto LB; // [252] 280
        }
        DeRef(_30908);
        _30908 = NOVALUE;
    }
    DeRef(_30908);
    _30908 = NOVALUE;

    /** parser.e:4527							sample_size = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_tok_62488);
    _30909 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30909)){
        _30910 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30909)->dbl));
    }
    else{
        _30910 = (object)*(((s1_ptr)_2)->base + _30909);
    }
    _2 = (object)SEQ_PTR(_30910);
    _27sample_size_20672 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_27sample_size_20672)){
        _27sample_size_20672 = (object)DBL_PTR(_27sample_size_20672)->dbl;
    }
    _30910 = NOVALUE;
    goto LC; // [277] 288
LB: 

    /** parser.e:4529							sample_size = -1*/
    _27sample_size_20672 = -1LL;
LC: 

    /** parser.e:4531						if sample_size < 1 and OpProfileTime then*/
    _30912 = (_27sample_size_20672 < 1LL);
    if (_30912 == 0) {
        goto LD; // [296] 332
    }
    if (_27OpProfileTime_20644 == 0)
    {
        goto LD; // [303] 332
    }
    else{
    }

    /** parser.e:4532							CompileErr(SAMPLE_SIZE_MUST_BE_A_POSITIVE_INTEGER)*/
    RefDS(_22218);
    _49CompileErr(136LL, _22218, 0LL);
    goto LD; // [316] 332
LA: 

    /** parser.e:4535						putback(tok)*/
    Ref(_tok_62488);
    _43putback(_tok_62488);

    /** parser.e:4536						sample_size = DEFAULT_SAMPLE_SIZE*/
    _27sample_size_20672 = 25000LL;
LD: 

    /** parser.e:4538					if OpProfileTime then*/
    if (_27OpProfileTime_20644 == 0)
    {
        goto LE; // [336] 357
    }
    else{
    }

    /** parser.e:4539						if IWINDOWS then*/
    if (_44IWINDOWS_20714 == 0)
    {
        goto LF; // [343] 356
    }
    else{
    }

    /** parser.e:4540							AnyTimeProfile = TRUE*/
    _28AnyTimeProfile_11595 = _9TRUE_441;
LF: 
LE: 
L8: 
    DeRef(_tok_62488);
    _tok_62488 = NOVALUE;
    goto L2; // [361] 1546
L5: 

    /** parser.e:4546		elsif equal(option, "trace") then*/
    if (_option_62434 == _30914)
    _30915 = 1;
    else if (IS_ATOM_INT(_option_62434) && IS_ATOM_INT(_30914))
    _30915 = 0;
    else
    _30915 = (compare(_option_62434, _30914) == 0);
    if (_30915 == 0)
    {
        _30915 = NOVALUE;
        goto L10; // [370] 391
    }
    else{
        _30915 = NOVALUE;
    }

    /** parser.e:4547			if not BIND then*/
    if (_27BIND_20182 != 0)
    goto L2; // [377] 1546

    /** parser.e:4548				OpTrace = on_off*/
    _27OpTrace_20641 = _on_off_62433;
    goto L2; // [388] 1546
L10: 

    /** parser.e:4551		elsif equal(option, "warning") then*/
    if (_option_62434 == _30917)
    _30918 = 1;
    else if (IS_ATOM_INT(_option_62434) && IS_ATOM_INT(_30917))
    _30918 = 0;
    else
    _30918 = (compare(_option_62434, _30917) == 0);
    if (_30918 == 0)
    {
        _30918 = NOVALUE;
        goto L11; // [397] 1243
    }
    else{
        _30918 = NOVALUE;
    }

    /** parser.e:4552			integer good_sofar = line_number*/
    _good_sofar_62538 = _27line_number_20572;

    /** parser.e:4553			reset_flags = 1*/
    _reset_flags_62436 = 1LL;

    /** parser.e:4554			token tok = next_token()*/
    _0 = _tok_62541;
    _tok_62541 = _43next_token();
    DeRef(_0);

    /** parser.e:4555			integer warning_extra = 1*/
    _warning_extra_62543 = 1LL;

    /** parser.e:4556			if find(tok[T_ID], {CONCAT_EQUALS, PLUS_EQUALS}) != 0 then*/
    _2 = (object)SEQ_PTR(_tok_62541);
    _30920 = (object)*(((s1_ptr)_2)->base + 1LL);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 519LL;
    ((intptr_t *)_2)[2] = 515LL;
    _30921 = MAKE_SEQ(_1);
    _30922 = find_from(_30920, _30921, 1LL);
    _30920 = NOVALUE;
    DeRefDS(_30921);
    _30921 = NOVALUE;
    if (_30922 == 0LL)
    goto L12; // [445] 506

    /** parser.e:4557				tok = next_token()*/
    _0 = _tok_62541;
    _tok_62541 = _43next_token();
    DeRef(_0);

    /** parser.e:4558				if tok[T_ID] != LEFT_BRACE and tok[T_ID] != LEFT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok_62541);
    _30925 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30925)) {
        _30926 = (_30925 != -24LL);
    }
    else {
        _30926 = binary_op(NOTEQ, _30925, -24LL);
    }
    _30925 = NOVALUE;
    if (IS_ATOM_INT(_30926)) {
        if (_30926 == 0) {
            goto L13; // [468] 498
        }
    }
    else {
        if (DBL_PTR(_30926)->dbl == 0.0) {
            goto L13; // [468] 498
        }
    }
    _2 = (object)SEQ_PTR(_tok_62541);
    _30928 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30928)) {
        _30929 = (_30928 != -26LL);
    }
    else {
        _30929 = binary_op(NOTEQ, _30928, -26LL);
    }
    _30928 = NOVALUE;
    if (_30929 == 0) {
        DeRef(_30929);
        _30929 = NOVALUE;
        goto L13; // [485] 498
    }
    else {
        if (!IS_ATOM_INT(_30929) && DBL_PTR(_30929)->dbl == 0.0){
            DeRef(_30929);
            _30929 = NOVALUE;
            goto L13; // [485] 498
        }
        DeRef(_30929);
        _30929 = NOVALUE;
    }
    DeRef(_30929);
    _30929 = NOVALUE;

    /** parser.e:4559					CompileErr(WARNING_NAMES_MUST_BE_ENCLOSED_IN)*/
    RefDS(_22218);
    _49CompileErr(160LL, _22218, 0LL);
L13: 

    /** parser.e:4561				reset_flags = 0*/
    _reset_flags_62436 = 0LL;
    goto L14; // [503] 734
L12: 

    /** parser.e:4562			elsif tok[T_ID] = EQUALS then*/
    _2 = (object)SEQ_PTR(_tok_62541);
    _30930 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30930, 3LL)){
        _30930 = NOVALUE;
        goto L15; // [516] 577
    }
    _30930 = NOVALUE;

    /** parser.e:4563				tok = next_token()*/
    _0 = _tok_62541;
    _tok_62541 = _43next_token();
    DeRef(_0);

    /** parser.e:4564				if tok[T_ID] != LEFT_BRACE and tok[T_ID] != LEFT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok_62541);
    _30933 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30933)) {
        _30934 = (_30933 != -24LL);
    }
    else {
        _30934 = binary_op(NOTEQ, _30933, -24LL);
    }
    _30933 = NOVALUE;
    if (IS_ATOM_INT(_30934)) {
        if (_30934 == 0) {
            goto L16; // [539] 569
        }
    }
    else {
        if (DBL_PTR(_30934)->dbl == 0.0) {
            goto L16; // [539] 569
        }
    }
    _2 = (object)SEQ_PTR(_tok_62541);
    _30936 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30936)) {
        _30937 = (_30936 != -26LL);
    }
    else {
        _30937 = binary_op(NOTEQ, _30936, -26LL);
    }
    _30936 = NOVALUE;
    if (_30937 == 0) {
        DeRef(_30937);
        _30937 = NOVALUE;
        goto L16; // [556] 569
    }
    else {
        if (!IS_ATOM_INT(_30937) && DBL_PTR(_30937)->dbl == 0.0){
            DeRef(_30937);
            _30937 = NOVALUE;
            goto L16; // [556] 569
        }
        DeRef(_30937);
        _30937 = NOVALUE;
    }
    DeRef(_30937);
    _30937 = NOVALUE;

    /** parser.e:4565					CompileErr(WARNING_NAMES_MUST_BE_ENCLOSED_IN)*/
    RefDS(_22218);
    _49CompileErr(160LL, _22218, 0LL);
L16: 

    /** parser.e:4567				reset_flags = 1*/
    _reset_flags_62436 = 1LL;
    goto L14; // [574] 734
L15: 

    /** parser.e:4568			elsif tok[T_ID] = VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_62541);
    _30938 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30938, -100LL)){
        _30938 = NOVALUE;
        goto L17; // [587] 733
    }
    _30938 = NOVALUE;

    /** parser.e:4569				option = SymTab[tok[T_SYM]][S_NAME]*/
    _2 = (object)SEQ_PTR(_tok_62541);
    _30940 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30940)){
        _30941 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30940)->dbl));
    }
    else{
        _30941 = (object)*(((s1_ptr)_2)->base + _30940);
    }
    DeRef(_option_62434);
    _2 = (object)SEQ_PTR(_30941);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _option_62434 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _option_62434 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    Ref(_option_62434);
    _30941 = NOVALUE;

    /** parser.e:4570				if equal(option, "save") then*/
    if (_option_62434 == _30943)
    _30944 = 1;
    else if (IS_ATOM_INT(_option_62434) && IS_ATOM_INT(_30943))
    _30944 = 0;
    else
    _30944 = (compare(_option_62434, _30943) == 0);
    if (_30944 == 0)
    {
        _30944 = NOVALUE;
        goto L18; // [619] 643
    }
    else{
        _30944 = NOVALUE;
    }

    /** parser.e:4571					prev_OpWarning = OpWarning*/
    _27prev_OpWarning_20640 = _27OpWarning_20639;

    /** parser.e:4572					warning_extra = FALSE*/
    _warning_extra_62543 = _9FALSE_439;
    goto L19; // [640] 732
L18: 

    /** parser.e:4574				elsif equal(option, "restore") then*/
    if (_option_62434 == _30945)
    _30946 = 1;
    else if (IS_ATOM_INT(_option_62434) && IS_ATOM_INT(_30945))
    _30946 = 0;
    else
    _30946 = (compare(_option_62434, _30945) == 0);
    if (_30946 == 0)
    {
        _30946 = NOVALUE;
        goto L1A; // [649] 673
    }
    else{
        _30946 = NOVALUE;
    }

    /** parser.e:4575					OpWarning = prev_OpWarning*/
    _27OpWarning_20639 = _27prev_OpWarning_20640;

    /** parser.e:4576					warning_extra = FALSE*/
    _warning_extra_62543 = _9FALSE_439;
    goto L19; // [670] 732
L1A: 

    /** parser.e:4578				elsif equal(option, "strict") then*/
    if (_option_62434 == _25756)
    _30947 = 1;
    else if (IS_ATOM_INT(_option_62434) && IS_ATOM_INT(_25756))
    _30947 = 0;
    else
    _30947 = (compare(_option_62434, _25756) == 0);
    if (_30947 == 0)
    {
        _30947 = NOVALUE;
        goto L1B; // [679] 731
    }
    else{
        _30947 = NOVALUE;
    }

    /** parser.e:4579					if on_off = 0 then*/
    if (_on_off_62433 != 0LL)
    goto L1C; // [684] 701

    /** parser.e:4580						Strict_Override += 1*/
    _27Strict_Override_20638 = _27Strict_Override_20638 + 1LL;
    goto L1D; // [698] 721
L1C: 

    /** parser.e:4581					elsif Strict_Override > 0 then*/
    if (_27Strict_Override_20638 <= 0LL)
    goto L1E; // [705] 720

    /** parser.e:4582						Strict_Override -= 1*/
    _27Strict_Override_20638 = _27Strict_Override_20638 - 1LL;
L1E: 
L1D: 

    /** parser.e:4584					warning_extra = FALSE*/
    _warning_extra_62543 = _9FALSE_439;
L1B: 
L19: 
L17: 
L14: 

    /** parser.e:4588			if warning_extra = TRUE then*/
    if (_warning_extra_62543 != _9TRUE_441)
    goto L1F; // [738] 1238

    /** parser.e:4589				if reset_flags then*/
    if (_reset_flags_62436 == 0)
    {
        goto L20; // [744] 776
    }
    else{
    }

    /** parser.e:4590					if on_off = 0 then*/
    if (_on_off_62433 != 0LL)
    goto L21; // [749] 765

    /** parser.e:4591						OpWarning = no_warning_flag*/
    _27OpWarning_20639 = 0LL;
    goto L22; // [762] 775
L21: 

    /** parser.e:4593						OpWarning = all_warning_flag*/
    _27OpWarning_20639 = 32767LL;
L22: 
L20: 

    /** parser.e:4597				if find(tok[T_ID], {LEFT_BRACE, LEFT_ROUND}) then*/
    _2 = (object)SEQ_PTR(_tok_62541);
    _30954 = (object)*(((s1_ptr)_2)->base + 1LL);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -24LL;
    ((intptr_t *)_2)[2] = -26LL;
    _30955 = MAKE_SEQ(_1);
    _30956 = find_from(_30954, _30955, 1LL);
    _30954 = NOVALUE;
    DeRefDS(_30955);
    _30955 = NOVALUE;
    if (_30956 == 0)
    {
        _30956 = NOVALUE;
        goto L23; // [797] 1231
    }
    else{
        _30956 = NOVALUE;
    }

    /** parser.e:4598					integer endlist*/

    /** parser.e:4599					if tok[T_ID] = LEFT_BRACE then*/
    _2 = (object)SEQ_PTR(_tok_62541);
    _30957 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30957, -24LL)){
        _30957 = NOVALUE;
        goto L24; // [812] 828
    }
    _30957 = NOVALUE;

    /** parser.e:4600						endlist = RIGHT_BRACE*/
    _endlist_62636 = -25LL;
    goto L25; // [825] 838
L24: 

    /** parser.e:4602						endlist = RIGHT_ROUND*/
    _endlist_62636 = -27LL;
L25: 

    /** parser.e:4604					tok = next_token()*/
    _0 = _tok_62541;
    _tok_62541 = _43next_token();
    DeRef(_0);

    /** parser.e:4605					while tok[T_ID] != endlist do*/
L26: 
    _2 = (object)SEQ_PTR(_tok_62541);
    _30960 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _30960, _endlist_62636)){
        _30960 = NOVALUE;
        goto L27; // [856] 1226
    }
    _30960 = NOVALUE;

    /** parser.e:4606						if tok[T_ID] = COMMA then*/
    _2 = (object)SEQ_PTR(_tok_62541);
    _30962 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30962, -30LL)){
        _30962 = NOVALUE;
        goto L28; // [870] 884
    }
    _30962 = NOVALUE;

    /** parser.e:4607							tok = next_token()*/
    _0 = _tok_62541;
    _tok_62541 = _43next_token();
    DeRef(_0);

    /** parser.e:4608							continue*/
    goto L26; // [881] 848
L28: 

    /** parser.e:4611						if tok[T_ID] = STRING then*/
    _2 = (object)SEQ_PTR(_tok_62541);
    _30965 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30965, 503LL)){
        _30965 = NOVALUE;
        goto L29; // [894] 923
    }
    _30965 = NOVALUE;

    /** parser.e:4612							option = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_tok_62541);
    _30967 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30967)){
        _30968 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30967)->dbl));
    }
    else{
        _30968 = (object)*(((s1_ptr)_2)->base + _30967);
    }
    DeRef(_option_62434);
    _2 = (object)SEQ_PTR(_30968);
    _option_62434 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_option_62434);
    _30968 = NOVALUE;
    goto L2A; // [920] 1071
L29: 

    /** parser.e:4613						elsif length(SymTab[tok[T_SYM]]) >= S_NAME then*/
    _2 = (object)SEQ_PTR(_tok_62541);
    _30970 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30970)){
        _30971 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30970)->dbl));
    }
    else{
        _30971 = (object)*(((s1_ptr)_2)->base + _30970);
    }
    if (IS_SEQUENCE(_30971)){
            _30972 = SEQ_PTR(_30971)->length;
    }
    else {
        _30972 = 1;
    }
    _30971 = NOVALUE;
    if (binary_op_a(LESS, _30972, _27S_NAME_20209)){
        _30972 = NOVALUE;
        goto L2B; // [942] 971
    }
    _30972 = NOVALUE;

    /** parser.e:4614							option = SymTab[tok[T_SYM]][S_NAME]*/
    _2 = (object)SEQ_PTR(_tok_62541);
    _30974 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30974)){
        _30975 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30974)->dbl));
    }
    else{
        _30975 = (object)*(((s1_ptr)_2)->base + _30974);
    }
    DeRef(_option_62434);
    _2 = (object)SEQ_PTR(_30975);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _option_62434 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _option_62434 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    Ref(_option_62434);
    _30975 = NOVALUE;
    goto L2A; // [968] 1071
L2B: 

    /** parser.e:4616							option = ""*/
    RefDS(_22218);
    DeRef(_option_62434);
    _option_62434 = _22218;

    /** parser.e:4617							for k = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_62keylist_23493)){
            _30977 = SEQ_PTR(_62keylist_23493)->length;
    }
    else {
        _30977 = 1;
    }
    {
        object _k_62683;
        _k_62683 = 1LL;
L2C: 
        if (_k_62683 > _30977){
            goto L2D; // [985] 1070
        }

        /** parser.e:4618								if keylist[k][S_SCOPE] = SC_KEYWORD and*/
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _30978 = (object)*(((s1_ptr)_2)->base + _k_62683);
        _2 = (object)SEQ_PTR(_30978);
        _30979 = (object)*(((s1_ptr)_2)->base + 4LL);
        _30978 = NOVALUE;
        if (IS_ATOM_INT(_30979)) {
            _30980 = (_30979 == 8LL);
        }
        else {
            _30980 = binary_op(EQUALS, _30979, 8LL);
        }
        _30979 = NOVALUE;
        if (IS_ATOM_INT(_30980)) {
            if (_30980 == 0) {
                goto L2E; // [1012] 1063
            }
        }
        else {
            if (DBL_PTR(_30980)->dbl == 0.0) {
                goto L2E; // [1012] 1063
            }
        }
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _30982 = (object)*(((s1_ptr)_2)->base + _k_62683);
        _2 = (object)SEQ_PTR(_30982);
        if (!IS_ATOM_INT(_27S_TOKEN_20214)){
            _30983 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
        }
        else{
            _30983 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
        }
        _30982 = NOVALUE;
        _2 = (object)SEQ_PTR(_tok_62541);
        _30984 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_30983) && IS_ATOM_INT(_30984)) {
            _30985 = (_30983 == _30984);
        }
        else {
            _30985 = binary_op(EQUALS, _30983, _30984);
        }
        _30983 = NOVALUE;
        _30984 = NOVALUE;
        if (_30985 == 0) {
            DeRef(_30985);
            _30985 = NOVALUE;
            goto L2E; // [1039] 1063
        }
        else {
            if (!IS_ATOM_INT(_30985) && DBL_PTR(_30985)->dbl == 0.0){
                DeRef(_30985);
                _30985 = NOVALUE;
                goto L2E; // [1039] 1063
            }
            DeRef(_30985);
            _30985 = NOVALUE;
        }
        DeRef(_30985);
        _30985 = NOVALUE;

        /** parser.e:4621										option = keylist[k][S_NAME]*/
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _30986 = (object)*(((s1_ptr)_2)->base + _k_62683);
        DeRef(_option_62434);
        _2 = (object)SEQ_PTR(_30986);
        if (!IS_ATOM_INT(_27S_NAME_20209)){
            _option_62434 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
        }
        else{
            _option_62434 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
        }
        Ref(_option_62434);
        _30986 = NOVALUE;

        /** parser.e:4622										exit*/
        goto L2D; // [1060] 1070
L2E: 

        /** parser.e:4624							end for*/
        _k_62683 = _k_62683 + 1LL;
        goto L2C; // [1065] 992
L2D: 
        ;
    }
L2A: 

    /** parser.e:4628						idx = find(option, warning_names)*/
    _idx_62435 = find_from(_option_62434, _27warning_names_20616, 1LL);

    /** parser.e:4629						if idx = 0 then*/
    if (_idx_62435 != 0LL)
    goto L2F; // [1082] 1137

    /** parser.e:4630		 					if good_sofar != line_number then*/
    if (_good_sofar_62538 == _27line_number_20572)
    goto L30; // [1090] 1104

    /** parser.e:4631	 							CompileErr(TOO_MANY_WARNING_ERRORS)*/
    RefDS(_22218);
    _49CompileErr(147LL, _22218, 0LL);
L30: 

    /** parser.e:4633							Warning(225, 0,*/
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _30991 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_30991);
    ((intptr_t*)_2)[1] = _30991;
    ((intptr_t*)_2)[2] = _27line_number_20572;
    RefDS(_option_62434);
    ((intptr_t*)_2)[3] = _option_62434;
    _30992 = MAKE_SEQ(_1);
    _30991 = NOVALUE;
    _49Warning(225LL, 0LL, _30992);
    _30992 = NOVALUE;

    /** parser.e:4635							tok = next_token()*/
    _0 = _tok_62541;
    _tok_62541 = _43next_token();
    DeRef(_0);

    /** parser.e:4636							continue*/
    goto L26; // [1134] 848
L2F: 

    /** parser.e:4639						idx = warning_flags[idx]*/
    _2 = (object)SEQ_PTR(_27warning_flags_20614);
    _idx_62435 = (object)*(((s1_ptr)_2)->base + _idx_62435);

    /** parser.e:4640						if idx = 0 then*/
    if (_idx_62435 != 0LL)
    goto L31; // [1149] 1183

    /** parser.e:4641							if on_off then*/
    if (_on_off_62433 == 0)
    {
        goto L32; // [1155] 1170
    }
    else{
    }

    /** parser.e:4642								OpWarning = no_warning_flag*/
    _27OpWarning_20639 = 0LL;
    goto L33; // [1167] 1216
L32: 

    /** parser.e:4644							    OpWarning = all_warning_flag*/
    _27OpWarning_20639 = 32767LL;
    goto L33; // [1180] 1216
L31: 

    /** parser.e:4647							if on_off then*/
    if (_on_off_62433 == 0)
    {
        goto L34; // [1185] 1201
    }
    else{
    }

    /** parser.e:4648								OpWarning = or_bits(OpWarning, idx)*/
    {uintptr_t tu;
         tu = (uintptr_t)_27OpWarning_20639 | (uintptr_t)_idx_62435;
         _27OpWarning_20639 = MAKE_UINT(tu);
    }
    if (!IS_ATOM_INT(_27OpWarning_20639)) {
        _1 = (object)(DBL_PTR(_27OpWarning_20639)->dbl);
        DeRefDS(_27OpWarning_20639);
        _27OpWarning_20639 = _1;
    }
    goto L35; // [1198] 1215
L34: 

    /** parser.e:4650							    OpWarning = and_bits(OpWarning, not_bits(idx))*/
    _30997 = not_bits(_idx_62435);
    if (IS_ATOM_INT(_30997)) {
        {uintptr_t tu;
             tu = (uintptr_t)_27OpWarning_20639 & (uintptr_t)_30997;
             _27OpWarning_20639 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (eudouble)_27OpWarning_20639;
        _27OpWarning_20639 = Dand_bits(&temp_d, DBL_PTR(_30997));
    }
    DeRef(_30997);
    _30997 = NOVALUE;
    if (!IS_ATOM_INT(_27OpWarning_20639)) {
        _1 = (object)(DBL_PTR(_27OpWarning_20639)->dbl);
        DeRefDS(_27OpWarning_20639);
        _27OpWarning_20639 = _1;
    }
L35: 
L33: 

    /** parser.e:4653						tok = next_token()*/
    _0 = _tok_62541;
    _tok_62541 = _43next_token();
    DeRef(_0);

    /** parser.e:4654					end while*/
    goto L26; // [1223] 848
L27: 
    goto L36; // [1228] 1237
L23: 

    /** parser.e:4656					putback(tok)*/
    Ref(_tok_62541);
    _43putback(_tok_62541);
L36: 
L1F: 
    DeRef(_tok_62541);
    _tok_62541 = NOVALUE;
    goto L2; // [1240] 1546
L11: 

    /** parser.e:4659		elsif equal(option, "define") then*/
    if (_option_62434 == _31000)
    _31001 = 1;
    else if (IS_ATOM_INT(_option_62434) && IS_ATOM_INT(_31000))
    _31001 = 0;
    else
    _31001 = (compare(_option_62434, _31000) == 0);
    if (_31001 == 0)
    {
        _31001 = NOVALUE;
        goto L37; // [1249] 1376
    }
    else{
        _31001 = NOVALUE;
    }

    /** parser.e:4660			option = StringToken()*/
    RefDS(_5);
    _0 = _option_62434;
    _option_62434 = _61StringToken(_5);
    DeRefDS(_0);

    /** parser.e:4661			if length(option) = 0 then*/
    if (IS_SEQUENCE(_option_62434)){
            _31003 = SEQ_PTR(_option_62434)->length;
    }
    else {
        _31003 = 1;
    }
    if (_31003 != 0LL)
    goto L38; // [1265] 1281

    /** parser.e:4662				CompileErr(EXPECTING_TO_FIND_A_WORD_TO_DEFINE_BUT_REACHED_END_OF_LINE_FIRST)*/
    RefDS(_22218);
    _49CompileErr(81LL, _22218, 0LL);
    goto L39; // [1278] 1301
L38: 

    /** parser.e:4664			elsif not t_identifier(option) then*/
    RefDS(_option_62434);
    _31005 = _9t_identifier(_option_62434);
    if (IS_ATOM_INT(_31005)) {
        if (_31005 != 0){
            DeRef(_31005);
            _31005 = NOVALUE;
            goto L3A; // [1287] 1300
        }
    }
    else {
        if (DBL_PTR(_31005)->dbl != 0.0){
            DeRef(_31005);
            _31005 = NOVALUE;
            goto L3A; // [1287] 1300
        }
    }
    DeRef(_31005);
    _31005 = NOVALUE;

    /** parser.e:4665				CompileErr(DEFINED_WORD_MUST_ONLY_HAVE_ALPHANUMERICS_AND_UNDERSCORE)*/
    RefDS(_22218);
    _49CompileErr(61LL, _22218, 0LL);
L3A: 
L39: 

    /** parser.e:4668			if on_off = 0 then*/
    if (_on_off_62433 != 0LL)
    goto L3B; // [1303] 1358

    /** parser.e:4669				idx = find(option, OpDefines)*/
    _idx_62435 = find_from(_option_62434, _27OpDefines_20645, 1LL);

    /** parser.e:4670				if idx then*/
    if (_idx_62435 == 0)
    {
        goto L2; // [1318] 1546
    }
    else{
    }

    /** parser.e:4671					OpDefines = OpDefines[1..idx-1]&OpDefines[idx+1..$]*/
    _31009 = _idx_62435 - 1LL;
    rhs_slice_target = (object_ptr)&_31010;
    RHS_Slice(_27OpDefines_20645, 1LL, _31009);
    _31011 = _idx_62435 + 1;
    if (IS_SEQUENCE(_27OpDefines_20645)){
            _31012 = SEQ_PTR(_27OpDefines_20645)->length;
    }
    else {
        _31012 = 1;
    }
    rhs_slice_target = (object_ptr)&_31013;
    RHS_Slice(_27OpDefines_20645, _31011, _31012);
    Concat((object_ptr)&_27OpDefines_20645, _31010, _31013);
    DeRefDS(_31010);
    _31010 = NOVALUE;
    DeRef(_31010);
    _31010 = NOVALUE;
    DeRefDS(_31013);
    _31013 = NOVALUE;
    goto L2; // [1355] 1546
L3B: 

    /** parser.e:4674				OpDefines &= {option}*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_option_62434);
    ((intptr_t*)_2)[1] = _option_62434;
    _31015 = MAKE_SEQ(_1);
    Concat((object_ptr)&_27OpDefines_20645, _27OpDefines_20645, _31015);
    DeRefDS(_31015);
    _31015 = NOVALUE;
    goto L2; // [1373] 1546
L37: 

    /** parser.e:4677		elsif equal(option, "inline") then*/
    if (_option_62434 == _31017)
    _31018 = 1;
    else if (IS_ATOM_INT(_option_62434) && IS_ATOM_INT(_31017))
    _31018 = 0;
    else
    _31018 = (compare(_option_62434, _31017) == 0);
    if (_31018 == 0)
    {
        _31018 = NOVALUE;
        goto L3C; // [1382] 1478
    }
    else{
        _31018 = NOVALUE;
    }

    /** parser.e:4679			if on_off and not repl then*/
    if (_on_off_62433 == 0) {
        goto L3D; // [1387] 1467
    }
    _31020 = (0LL == 0);
    if (_31020 == 0)
    {
        DeRef(_31020);
        _31020 = NOVALUE;
        goto L3D; // [1397] 1467
    }
    else{
        DeRef(_31020);
        _31020 = NOVALUE;
    }

    /** parser.e:4680				token tok = next_token()*/
    _0 = _tok_62785;
    _tok_62785 = _43next_token();
    DeRef(_0);

    /** parser.e:4681				if tok[T_ID] = ATOM then*/
    _2 = (object)SEQ_PTR(_tok_62785);
    _31022 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _31022, 502LL)){
        _31022 = NOVALUE;
        goto L3E; // [1415] 1447
    }
    _31022 = NOVALUE;

    /** parser.e:4682					OpInline = floor( SymTab[tok[T_SYM]][S_OBJ] )*/
    _2 = (object)SEQ_PTR(_tok_62785);
    _31024 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_31024)){
        _31025 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31024)->dbl));
    }
    else{
        _31025 = (object)*(((s1_ptr)_2)->base + _31024);
    }
    _2 = (object)SEQ_PTR(_31025);
    _31026 = (object)*(((s1_ptr)_2)->base + 1LL);
    _31025 = NOVALUE;
    if (IS_ATOM_INT(_31026))
    _27OpInline_20646 = e_floor(_31026);
    else
    _27OpInline_20646 = unary_op(FLOOR, _31026);
    _31026 = NOVALUE;
    if (!IS_ATOM_INT(_27OpInline_20646)) {
        _1 = (object)(DBL_PTR(_27OpInline_20646)->dbl);
        DeRefDS(_27OpInline_20646);
        _27OpInline_20646 = _1;
    }
    goto L3F; // [1444] 1462
L3E: 

    /** parser.e:4684					putback(tok)*/
    Ref(_tok_62785);
    _43putback(_tok_62785);

    /** parser.e:4685					OpInline = DEFAULT_INLINE*/
    _27OpInline_20646 = 30LL;
L3F: 
    DeRef(_tok_62785);
    _tok_62785 = NOVALUE;
    goto L2; // [1464] 1546
L3D: 

    /** parser.e:4688				OpInline = 0*/
    _27OpInline_20646 = 0LL;
    goto L2; // [1475] 1546
L3C: 

    /** parser.e:4692		elsif equal( option, "indirect_includes" ) then*/
    if (_option_62434 == _31028)
    _31029 = 1;
    else if (IS_ATOM_INT(_option_62434) && IS_ATOM_INT(_31028))
    _31029 = 0;
    else
    _31029 = (compare(_option_62434, _31028) == 0);
    if (_31029 == 0)
    {
        _31029 = NOVALUE;
        goto L40; // [1484] 1497
    }
    else{
        _31029 = NOVALUE;
    }

    /** parser.e:4693			OpIndirectInclude = on_off*/
    _27OpIndirectInclude_20647 = _on_off_62433;
    goto L2; // [1494] 1546
L40: 

    /** parser.e:4695		elsif equal(option, "batch") then*/
    if (_option_62434 == _25753)
    _31030 = 1;
    else if (IS_ATOM_INT(_option_62434) && IS_ATOM_INT(_25753))
    _31030 = 0;
    else
    _31030 = (compare(_option_62434, _25753) == 0);
    if (_31030 == 0)
    {
        _31030 = NOVALUE;
        goto L41; // [1503] 1516
    }
    else{
        _31030 = NOVALUE;
    }

    /** parser.e:4696			batch_job = on_off*/
    _27batch_job_20584 = _on_off_62433;
    goto L2; // [1513] 1546
L41: 

    /** parser.e:4698		elsif integer(to_number(option, -1)) then*/
    RefDS(_option_62434);
    _31031 = _13to_number(_option_62434, -1LL);
    if (IS_ATOM_INT(_31031))
    _31032 = 1;
    else if (IS_ATOM_DBL(_31031))
    _31032 = IS_ATOM_INT(DoubleToInt(_31031));
    else
    _31032 = 0;
    DeRef(_31031);
    _31031 = NOVALUE;
    if (_31032 == 0)
    {
        _31032 = NOVALUE;
        goto L42; // [1526] 1532
    }
    else{
        _31032 = NOVALUE;
    }
    goto L2; // [1529] 1546
L42: 

    /** parser.e:4702			CompileErr(UNKNOWN_WITHWITHOUT_OPTION_1, {option})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_option_62434);
    ((intptr_t*)_2)[1] = _option_62434;
    _31033 = MAKE_SEQ(_1);
    _49CompileErr(154LL, _31033, 0LL);
    _31033 = NOVALUE;
L2: 

    /** parser.e:4705	end procedure*/
    DeRef(_option_62434);
    _30971 = NOVALUE;
    _30940 = NOVALUE;
    _30974 = NOVALUE;
    DeRef(_30912);
    _30912 = NOVALUE;
    _30967 = NOVALUE;
    DeRef(_30926);
    _30926 = NOVALUE;
    DeRef(_30893);
    _30893 = NOVALUE;
    DeRef(_31011);
    _31011 = NOVALUE;
    DeRef(_30980);
    _30980 = NOVALUE;
    DeRef(_30934);
    _30934 = NOVALUE;
    _31024 = NOVALUE;
    DeRef(_31009);
    _31009 = NOVALUE;
    _30909 = NOVALUE;
    DeRef(_30898);
    _30898 = NOVALUE;
    _30970 = NOVALUE;
    _30905 = NOVALUE;
    return;
    ;
}


void _43ExecCommand()
{
    object _0, _1, _2;
    

    /** parser.e:4709		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L1; // [5] 16
    }
    else{
    }

    /** parser.e:4710			emit_op(RETURNT)*/
    _45emit_op(34LL);
L1: 

    /** parser.e:4712		StraightenBranches()  -- straighten top-level*/
    _43StraightenBranches();

    /** parser.e:4713	end procedure*/
    return;
    ;
}


object _43undefined_var(object _tok_62829, object _scope_62830)
{
    object _forward_62832 = NOVALUE;
    object _31039 = NOVALUE;
    object _31038 = NOVALUE;
    object _31035 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:4716		token forward = next_token()*/
    _0 = _forward_62832;
    _forward_62832 = _43next_token();
    DeRef(_0);

    /** parser.e:4717			switch forward[T_ID] do*/
    _2 = (object)SEQ_PTR(_forward_62832);
    _31035 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_31035) ){
        goto L1; // [16] 82
    }
    if(!IS_ATOM_INT(_31035)){
        if( (DBL_PTR(_31035)->dbl != (eudouble) ((object) DBL_PTR(_31035)->dbl) ) ){
            goto L1; // [16] 82
        }
        _0 = (object) DBL_PTR(_31035)->dbl;
    }
    else {
        _0 = _31035;
    };
    _31035 = NOVALUE;
    switch ( _0 ){ 

        /** parser.e:4718				case LEFT_ROUND then*/
        case -26:

        /** parser.e:4719					StartSourceLine( TRUE )*/
        _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

        /** parser.e:4720					Forward_call( tok )*/
        Ref(_tok_62829);
        _43Forward_call(_tok_62829, 195LL);

        /** parser.e:4721					return 1*/
        DeRef(_tok_62829);
        DeRef(_forward_62832);
        return 1LL;
        goto L2; // [48] 96

        /** parser.e:4723				case VARIABLE then*/
        case -100:

        /** parser.e:4724					putback( forward )*/
        Ref(_forward_62832);
        _43putback(_forward_62832);

        /** parser.e:4725					Global_declaration( tok[T_SYM], scope )*/
        _2 = (object)SEQ_PTR(_tok_62829);
        _31038 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_31038);
        _31039 = _43Global_declaration(_31038, _scope_62830);
        _31038 = NOVALUE;

        /** parser.e:4726					return 1*/
        DeRef(_tok_62829);
        DeRef(_forward_62832);
        DeRef(_31039);
        _31039 = NOVALUE;
        return 1LL;
        goto L2; // [78] 96

        /** parser.e:4728				case else*/
        default:
L1: 

        /** parser.e:4729					putback( forward )*/
        Ref(_forward_62832);
        _43putback(_forward_62832);

        /** parser.e:4730					return 0*/
        DeRef(_tok_62829);
        DeRef(_forward_62832);
        DeRef(_31039);
        _31039 = NOVALUE;
        return 0LL;
    ;}L2: 
    ;
}


void _43real_parser(object _nested_62851)
{
    object _tok_62853 = NOVALUE;
    object _id_62854 = NOVALUE;
    object _scope_62855 = NOVALUE;
    object _deprecated_62917 = NOVALUE;
    object _test_63012 = NOVALUE;
    object _31179 = NOVALUE;
    object _31177 = NOVALUE;
    object _31176 = NOVALUE;
    object _31175 = NOVALUE;
    object _31174 = NOVALUE;
    object _31173 = NOVALUE;
    object _31172 = NOVALUE;
    object _31171 = NOVALUE;
    object _31166 = NOVALUE;
    object _31165 = NOVALUE;
    object _31162 = NOVALUE;
    object _31160 = NOVALUE;
    object _31159 = NOVALUE;
    object _31156 = NOVALUE;
    object _31142 = NOVALUE;
    object _31135 = NOVALUE;
    object _31134 = NOVALUE;
    object _31132 = NOVALUE;
    object _31130 = NOVALUE;
    object _31129 = NOVALUE;
    object _31127 = NOVALUE;
    object _31125 = NOVALUE;
    object _31120 = NOVALUE;
    object _31118 = NOVALUE;
    object _31116 = NOVALUE;
    object _31115 = NOVALUE;
    object _31114 = NOVALUE;
    object _31112 = NOVALUE;
    object _31110 = NOVALUE;
    object _31108 = NOVALUE;
    object _31106 = NOVALUE;
    object _31105 = NOVALUE;
    object _31104 = NOVALUE;
    object _31103 = NOVALUE;
    object _31102 = NOVALUE;
    object _31101 = NOVALUE;
    object _31100 = NOVALUE;
    object _31099 = NOVALUE;
    object _31098 = NOVALUE;
    object _31097 = NOVALUE;
    object _31096 = NOVALUE;
    object _31095 = NOVALUE;
    object _31094 = NOVALUE;
    object _31093 = NOVALUE;
    object _31091 = NOVALUE;
    object _31090 = NOVALUE;
    object _31089 = NOVALUE;
    object _31088 = NOVALUE;
    object _31086 = NOVALUE;
    object _31084 = NOVALUE;
    object _31083 = NOVALUE;
    object _31082 = NOVALUE;
    object _31080 = NOVALUE;
    object _31069 = NOVALUE;
    object _31067 = NOVALUE;
    object _31066 = NOVALUE;
    object _31065 = NOVALUE;
    object _31064 = NOVALUE;
    object _31063 = NOVALUE;
    object _31062 = NOVALUE;
    object _31061 = NOVALUE;
    object _31060 = NOVALUE;
    object _31059 = NOVALUE;
    object _31057 = NOVALUE;
    object _31056 = NOVALUE;
    object _31055 = NOVALUE;
    object _31054 = NOVALUE;
    object _31053 = NOVALUE;
    object _31052 = NOVALUE;
    object _31051 = NOVALUE;
    object _31050 = NOVALUE;
    object _31049 = NOVALUE;
    object _31048 = NOVALUE;
    object _31046 = NOVALUE;
    object _31042 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:4737		integer id*/

    /** parser.e:4738		integer scope*/

    /** parser.e:4740		while TRUE do  -- infinite loop until scanner aborts*/
L1: 
    if (_9TRUE_441 == 0)
    {
        goto L2; // [14] 1925
    }
    else{
    }

    /** parser.e:4741			if OpInline = 25000 then*/
    if (_27OpInline_20646 != 25000LL)
    goto L3; // [21] 35

    /** parser.e:4742				CompileErr("OpInline went nuts: [1]", OpInline )*/
    RefDS(_31041);
    _49CompileErr(_31041, _27OpInline_20646, 0LL);
L3: 

    /** parser.e:4744			start_index = length(Code)+1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _31042 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _31042 = 1;
    }
    _43start_index_55474 = _31042 + 1;
    _31042 = NOVALUE;

    /** parser.e:4745			tok = next_token()*/
    _0 = _tok_62853;
    _tok_62853 = _43next_token();
    DeRef(_0);

    /** parser.e:4746			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_62853);
    _id_62854 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_62854)){
        _id_62854 = (object)DBL_PTR(_id_62854)->dbl;
    }

    /** parser.e:4747			if id = VARIABLE or id = QUALIFIED_VARIABLE then*/
    _31046 = (_id_62854 == -100LL);
    if (_31046 != 0) {
        goto L4; // [69] 84
    }
    _31048 = (_id_62854 == 512LL);
    if (_31048 == 0)
    {
        DeRef(_31048);
        _31048 = NOVALUE;
        goto L5; // [80] 151
    }
    else{
        DeRef(_31048);
        _31048 = NOVALUE;
    }
L4: 

    /** parser.e:4748				if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED*/
    _2 = (object)SEQ_PTR(_tok_62853);
    _31049 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_31049)){
        _31050 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31049)->dbl));
    }
    else{
        _31050 = (object)*(((s1_ptr)_2)->base + _31049);
    }
    _2 = (object)SEQ_PTR(_31050);
    _31051 = (object)*(((s1_ptr)_2)->base + 4LL);
    _31050 = NOVALUE;
    if (IS_ATOM_INT(_31051)) {
        _31052 = (_31051 == 9LL);
    }
    else {
        _31052 = binary_op(EQUALS, _31051, 9LL);
    }
    _31051 = NOVALUE;
    if (IS_ATOM_INT(_31052)) {
        if (_31052 == 0) {
            goto L6; // [110] 130
        }
    }
    else {
        if (DBL_PTR(_31052)->dbl == 0.0) {
            goto L6; // [110] 130
        }
    }
    Ref(_tok_62853);
    _31054 = _43undefined_var(_tok_62853, 5LL);
    if (_31054 == 0) {
        DeRef(_31054);
        _31054 = NOVALUE;
        goto L6; // [122] 130
    }
    else {
        if (!IS_ATOM_INT(_31054) && DBL_PTR(_31054)->dbl == 0.0){
            DeRef(_31054);
            _31054 = NOVALUE;
            goto L6; // [122] 130
        }
        DeRef(_31054);
        _31054 = NOVALUE;
    }
    DeRef(_31054);
    _31054 = NOVALUE;

    /** parser.e:4750					continue*/
    goto L1; // [127] 12
L6: 

    /** parser.e:4752				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:4753				Assignment(tok)*/
    Ref(_tok_62853);
    _43Assignment(_tok_62853);

    /** parser.e:4754				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [148] 1915
L5: 

    /** parser.e:4756			elsif id = PROCEDURE or id = FUNCTION or id = TYPE_DECL then*/
    _31055 = (_id_62854 == 405LL);
    if (_31055 != 0) {
        _31056 = 1;
        goto L8; // [159] 173
    }
    _31057 = (_id_62854 == 406LL);
    _31056 = (_31057 != 0);
L8: 
    if (_31056 != 0) {
        goto L9; // [173] 188
    }
    _31059 = (_id_62854 == 416LL);
    if (_31059 == 0)
    {
        DeRef(_31059);
        _31059 = NOVALUE;
        goto LA; // [184] 206
    }
    else{
        DeRef(_31059);
        _31059 = NOVALUE;
    }
L9: 

    /** parser.e:4757				SubProg(tok[T_ID], SC_LOCAL, 0)*/
    _2 = (object)SEQ_PTR(_tok_62853);
    _31060 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_31060);
    _43SubProg(_31060, 5LL, 0LL);
    _31060 = NOVALUE;
    goto L7; // [203] 1915
LA: 

    /** parser.e:4759			elsif id = GLOBAL or id = EXPORT or id = OVERRIDE or id = PUBLIC or id = DEPRECATE then*/
    _31061 = (_id_62854 == 412LL);
    if (_31061 != 0) {
        _31062 = 1;
        goto LB; // [214] 228
    }
    _31063 = (_id_62854 == 428LL);
    _31062 = (_31063 != 0);
LB: 
    if (_31062 != 0) {
        _31064 = 1;
        goto LC; // [228] 242
    }
    _31065 = (_id_62854 == 429LL);
    _31064 = (_31065 != 0);
LC: 
    if (_31064 != 0) {
        _31066 = 1;
        goto LD; // [242] 256
    }
    _31067 = (_id_62854 == 430LL);
    _31066 = (_31067 != 0);
LD: 
    if (_31066 != 0) {
        goto LE; // [256] 271
    }
    _31069 = (_id_62854 == 433LL);
    if (_31069 == 0)
    {
        DeRef(_31069);
        _31069 = NOVALUE;
        goto LF; // [267] 692
    }
    else{
        DeRef(_31069);
        _31069 = NOVALUE;
    }
LE: 

    /** parser.e:4760				integer deprecated = 0*/
    _deprecated_62917 = 0LL;

    /** parser.e:4762				if id = DEPRECATE then*/
    if (_id_62854 != 433LL)
    goto L10; // [280] 305

    /** parser.e:4763					deprecated = 1*/
    _deprecated_62917 = 1LL;

    /** parser.e:4765					tok = next_token()*/
    _0 = _tok_62853;
    _tok_62853 = _43next_token();
    DeRef(_0);

    /** parser.e:4766					id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_62853);
    _id_62854 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_62854)){
        _id_62854 = (object)DBL_PTR(_id_62854)->dbl;
    }
L10: 

    /** parser.e:4769				scope = SC_LOCAL*/
    _scope_62855 = 5LL;

    /** parser.e:4770				if id = GLOBAL then*/
    if (_id_62854 != 412LL)
    goto L11; // [318] 334

    /** parser.e:4771				    scope = SC_GLOBAL*/
    _scope_62855 = 6LL;
    goto L12; // [331] 393
L11: 

    /** parser.e:4772				elsif id = EXPORT then*/
    if (_id_62854 != 428LL)
    goto L13; // [338] 354

    /** parser.e:4773					scope = SC_EXPORT*/
    _scope_62855 = 11LL;
    goto L12; // [351] 393
L13: 

    /** parser.e:4774				elsif id = OVERRIDE then*/
    if (_id_62854 != 429LL)
    goto L14; // [358] 374

    /** parser.e:4775					scope = SC_OVERRIDE*/
    _scope_62855 = 12LL;
    goto L12; // [371] 393
L14: 

    /** parser.e:4776				elsif id = PUBLIC then*/
    if (_id_62854 != 430LL)
    goto L15; // [378] 392

    /** parser.e:4777					scope = SC_PUBLIC*/
    _scope_62855 = 13LL;
L15: 
L12: 

    /** parser.e:4781				if scope != SC_LOCAL then*/
    if (_scope_62855 == 5LL)
    goto L16; // [397] 417

    /** parser.e:4782					tok = next_token()*/
    _0 = _tok_62853;
    _tok_62853 = _43next_token();
    DeRef(_0);

    /** parser.e:4783					id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_62853);
    _id_62854 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_62854)){
        _id_62854 = (object)DBL_PTR(_id_62854)->dbl;
    }
L16: 

    /** parser.e:4786				if id = TYPE or id = QUALIFIED_TYPE then*/
    _31080 = (_id_62854 == 504LL);
    if (_31080 != 0) {
        goto L17; // [425] 440
    }
    _31082 = (_id_62854 == 522LL);
    if (_31082 == 0)
    {
        DeRef(_31082);
        _31082 = NOVALUE;
        goto L18; // [436] 456
    }
    else{
        DeRef(_31082);
        _31082 = NOVALUE;
    }
L17: 

    /** parser.e:4787					Global_declaration(tok[T_SYM], scope )*/
    _2 = (object)SEQ_PTR(_tok_62853);
    _31083 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_31083);
    _31084 = _43Global_declaration(_31083, _scope_62855);
    _31083 = NOVALUE;
    goto L19; // [453] 687
L18: 

    /** parser.e:4789				elsif id = CONSTANT then*/
    if (_id_62854 != 417LL)
    goto L1A; // [460] 478

    /** parser.e:4790					Global_declaration(0, scope )*/
    _31086 = _43Global_declaration(0LL, _scope_62855);

    /** parser.e:4791					ExecCommand()*/
    _43ExecCommand();
    goto L19; // [475] 687
L1A: 

    /** parser.e:4793				elsif id = ENUM then*/
    if (_id_62854 != 427LL)
    goto L1B; // [482] 500

    /** parser.e:4794					Global_declaration(-1, scope )*/
    _31088 = _43Global_declaration(-1LL, _scope_62855);

    /** parser.e:4795					ExecCommand()*/
    _43ExecCommand();
    goto L19; // [497] 687
L1B: 

    /** parser.e:4797				elsif id = PROCEDURE or id = FUNCTION or id = TYPE_DECL then*/
    _31089 = (_id_62854 == 405LL);
    if (_31089 != 0) {
        _31090 = 1;
        goto L1C; // [508] 522
    }
    _31091 = (_id_62854 == 406LL);
    _31090 = (_31091 != 0);
L1C: 
    if (_31090 != 0) {
        goto L1D; // [522] 537
    }
    _31093 = (_id_62854 == 416LL);
    if (_31093 == 0)
    {
        DeRef(_31093);
        _31093 = NOVALUE;
        goto L1E; // [533] 547
    }
    else{
        DeRef(_31093);
        _31093 = NOVALUE;
    }
L1D: 

    /** parser.e:4798					SubProg(id, scope, deprecated)*/
    _43SubProg(_id_62854, _scope_62855, _deprecated_62917);
    goto L19; // [544] 687
L1E: 

    /** parser.e:4800				elsif (scope = SC_PUBLIC) and id = INCLUDE then*/
    _31094 = (_scope_62855 == 13LL);
    if (_31094 == 0) {
        goto L1F; // [555] 581
    }
    _31096 = (_id_62854 == 418LL);
    if (_31096 == 0)
    {
        DeRef(_31096);
        _31096 = NOVALUE;
        goto L1F; // [566] 581
    }
    else{
        DeRef(_31096);
        _31096 = NOVALUE;
    }

    /** parser.e:4801					IncludeScan( 1 )*/
    _61IncludeScan(1LL);

    /** parser.e:4802					PushGoto()*/
    _43PushGoto();
    goto L19; // [578] 687
L1F: 

    /** parser.e:4803				elsif (id = VARIABLE or id = QUALIFIED_VARIABLE)*/
    _31097 = (_id_62854 == -100LL);
    if (_31097 != 0) {
        _31098 = 1;
        goto L20; // [589] 603
    }
    _31099 = (_id_62854 == 512LL);
    _31098 = (_31099 != 0);
L20: 
    if (_31098 == 0) {
        _31100 = 0;
        goto L21; // [603] 635
    }
    _2 = (object)SEQ_PTR(_tok_62853);
    _31101 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_31101)){
        _31102 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31101)->dbl));
    }
    else{
        _31102 = (object)*(((s1_ptr)_2)->base + _31101);
    }
    _2 = (object)SEQ_PTR(_31102);
    _31103 = (object)*(((s1_ptr)_2)->base + 4LL);
    _31102 = NOVALUE;
    if (IS_ATOM_INT(_31103)) {
        _31104 = (_31103 == 9LL);
    }
    else {
        _31104 = binary_op(EQUALS, _31103, 9LL);
    }
    _31103 = NOVALUE;
    if (IS_ATOM_INT(_31104))
    _31100 = (_31104 != 0);
    else
    _31100 = DBL_PTR(_31104)->dbl != 0.0;
L21: 
    if (_31100 == 0) {
        goto L22; // [635] 657
    }
    Ref(_tok_62853);
    _31106 = _43undefined_var(_tok_62853, _scope_62855);
    if (_31106 == 0) {
        DeRef(_31106);
        _31106 = NOVALUE;
        goto L22; // [645] 657
    }
    else {
        if (!IS_ATOM_INT(_31106) && DBL_PTR(_31106)->dbl == 0.0){
            DeRef(_31106);
            _31106 = NOVALUE;
            goto L22; // [645] 657
        }
        DeRef(_31106);
        _31106 = NOVALUE;
    }
    DeRef(_31106);
    _31106 = NOVALUE;

    /** parser.e:4807					continue*/
    goto L1; // [652] 12
    goto L19; // [654] 687
L22: 

    /** parser.e:4809				elsif scope = SC_GLOBAL then*/
    if (_scope_62855 != 6LL)
    goto L23; // [661] 677

    /** parser.e:4810					CompileErr( MSG_GLOBAL_MUST_BE_FOLLOWED_BYA_TYPE_CONSTANT_ENUM_PROCEDURE_TYPE_OR_FUNCTION)*/
    RefDS(_22218);
    _49CompileErr(18LL, _22218, 0LL);
    goto L19; // [674] 687
L23: 

    /** parser.e:4812					CompileErr( MSG_PUBLIC_OR_EXPORT_MUST_BE_FOLLOWED_BYA_TYPE_CONSTANT_ENUM_PROCEDURE_TYPE_OR_FUNCTION)*/
    RefDS(_22218);
    _49CompileErr(16LL, _22218, 0LL);
L19: 
    goto L7; // [689] 1915
LF: 

    /** parser.e:4815			elsif id = TYPE or id = QUALIFIED_TYPE then*/
    _31108 = (_id_62854 == 504LL);
    if (_31108 != 0) {
        goto L24; // [700] 715
    }
    _31110 = (_id_62854 == 522LL);
    if (_31110 == 0)
    {
        DeRef(_31110);
        _31110 = NOVALUE;
        goto L25; // [711] 800
    }
    else{
        DeRef(_31110);
        _31110 = NOVALUE;
    }
L24: 

    /** parser.e:4816				token test = next_token()*/
    _0 = _test_63012;
    _test_63012 = _43next_token();
    DeRef(_0);

    /** parser.e:4817				putback( test )*/
    Ref(_test_63012);
    _43putback(_test_63012);

    /** parser.e:4818				if test[T_ID] = LEFT_ROUND then*/
    _2 = (object)SEQ_PTR(_test_63012);
    _31112 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _31112, -26LL)){
        _31112 = NOVALUE;
        goto L26; // [735] 773
    }
    _31112 = NOVALUE;

    /** parser.e:4819						StartSourceLine( TRUE )*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:4820						Procedure_call(tok)*/
    Ref(_tok_62853);
    _43Procedure_call(_tok_62853);

    /** parser.e:4821						clear_op()*/
    _45clear_op();

    /** parser.e:4822						if Pop() then end if*/
    _31114 = _45Pop();
    if (_31114 == 0) {
        DeRef(_31114);
        _31114 = NOVALUE;
        goto L27; // [762] 766
    }
    else {
        if (!IS_ATOM_INT(_31114) && DBL_PTR(_31114)->dbl == 0.0){
            DeRef(_31114);
            _31114 = NOVALUE;
            goto L27; // [762] 766
        }
        DeRef(_31114);
        _31114 = NOVALUE;
    }
    DeRef(_31114);
    _31114 = NOVALUE;
L27: 

    /** parser.e:4823						ExecCommand()*/
    _43ExecCommand();
    goto L28; // [770] 789
L26: 

    /** parser.e:4826					Global_declaration( tok[T_SYM], SC_LOCAL )*/
    _2 = (object)SEQ_PTR(_tok_62853);
    _31115 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_31115);
    _31116 = _43Global_declaration(_31115, 5LL);
    _31115 = NOVALUE;
L28: 

    /** parser.e:4829				continue*/
    DeRef(_test_63012);
    _test_63012 = NOVALUE;
    goto L1; // [793] 12
    goto L7; // [797] 1915
L25: 

    /** parser.e:4831			elsif id = CONSTANT then*/
    if (_id_62854 != 417LL)
    goto L29; // [804] 824

    /** parser.e:4832				Global_declaration(0, SC_LOCAL)*/
    _31118 = _43Global_declaration(0LL, 5LL);

    /** parser.e:4833				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [821] 1915
L29: 

    /** parser.e:4835			elsif id = ENUM then*/
    if (_id_62854 != 427LL)
    goto L2A; // [828] 848

    /** parser.e:4836				Global_declaration(-1, SC_LOCAL)*/
    _31120 = _43Global_declaration(-1LL, 5LL);

    /** parser.e:4837				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [845] 1915
L2A: 

    /** parser.e:4839			elsif id = IF then*/
    if (_id_62854 != 20LL)
    goto L2B; // [852] 876

    /** parser.e:4840				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:4841				If_statement()*/
    _43If_statement();

    /** parser.e:4842				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [873] 1915
L2B: 

    /** parser.e:4844			elsif id = FOR then*/
    if (_id_62854 != 21LL)
    goto L2C; // [880] 904

    /** parser.e:4845				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:4846				For_statement()*/
    _43For_statement();

    /** parser.e:4847				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [901] 1915
L2C: 

    /** parser.e:4849			elsif id = WHILE then*/
    if (_id_62854 != 47LL)
    goto L2D; // [908] 932

    /** parser.e:4850				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:4851				While_statement()*/
    _43While_statement();

    /** parser.e:4852				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [929] 1915
L2D: 

    /** parser.e:4854			elsif id = LOOP then*/
    if (_id_62854 != 422LL)
    goto L2E; // [936] 960

    /** parser.e:4855			    StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:4856			    Loop_statement()*/
    _43Loop_statement();

    /** parser.e:4857			    ExecCommand()*/
    _43ExecCommand();
    goto L7; // [957] 1915
L2E: 

    /** parser.e:4859			elsif id = PROC or id = QUALIFIED_PROC then*/
    _31125 = (_id_62854 == 27LL);
    if (_31125 != 0) {
        goto L2F; // [968] 983
    }
    _31127 = (_id_62854 == 521LL);
    if (_31127 == 0)
    {
        DeRef(_31127);
        _31127 = NOVALUE;
        goto L30; // [979] 1024
    }
    else{
        DeRef(_31127);
        _31127 = NOVALUE;
    }
L2F: 

    /** parser.e:4860				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:4861				if id = PROC then*/
    if (_id_62854 != 27LL)
    goto L31; // [996] 1012

    /** parser.e:4863					UndefinedVar( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_62853);
    _31129 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_31129);
    _43UndefinedVar(_31129);
    _31129 = NOVALUE;
L31: 

    /** parser.e:4866				Procedure_call(tok)*/
    Ref(_tok_62853);
    _43Procedure_call(_tok_62853);

    /** parser.e:4867				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [1021] 1915
L30: 

    /** parser.e:4869			elsif id = FUNC or id = QUALIFIED_FUNC then*/
    _31130 = (_id_62854 == 501LL);
    if (_31130 != 0) {
        goto L32; // [1032] 1047
    }
    _31132 = (_id_62854 == 520LL);
    if (_31132 == 0)
    {
        DeRef(_31132);
        _31132 = NOVALUE;
        goto L33; // [1043] 1101
    }
    else{
        DeRef(_31132);
        _31132 = NOVALUE;
    }
L32: 

    /** parser.e:4870				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:4871				if id = FUNC then*/
    if (_id_62854 != 501LL)
    goto L34; // [1060] 1076

    /** parser.e:4873					UndefinedVar( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_62853);
    _31134 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_31134);
    _43UndefinedVar(_31134);
    _31134 = NOVALUE;
L34: 

    /** parser.e:4876				Procedure_call(tok)*/
    Ref(_tok_62853);
    _43Procedure_call(_tok_62853);

    /** parser.e:4877				clear_op()*/
    _45clear_op();

    /** parser.e:4878				if Pop() then end if*/
    _31135 = _45Pop();
    if (_31135 == 0) {
        DeRef(_31135);
        _31135 = NOVALUE;
        goto L35; // [1090] 1094
    }
    else {
        if (!IS_ATOM_INT(_31135) && DBL_PTR(_31135)->dbl == 0.0){
            DeRef(_31135);
            _31135 = NOVALUE;
            goto L35; // [1090] 1094
        }
        DeRef(_31135);
        _31135 = NOVALUE;
    }
    DeRef(_31135);
    _31135 = NOVALUE;
L35: 

    /** parser.e:4879				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [1098] 1915
L33: 

    /** parser.e:4881			elsif id = RETURN then*/
    if (_id_62854 != 413LL)
    goto L36; // [1105] 1116

    /** parser.e:4882				Return_statement() -- will fail - not allowed at top level*/
    _43Return_statement();
    goto L7; // [1113] 1915
L36: 

    /** parser.e:4884			elsif id = EXIT then*/
    if (_id_62854 != 61LL)
    goto L37; // [1120] 1158

    /** parser.e:4885				if nested then*/
    if (_nested_62851 == 0)
    {
        goto L38; // [1126] 1145
    }
    else{
    }

    /** parser.e:4886				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:4887				Exit_statement()*/
    _43Exit_statement();
    goto L7; // [1142] 1915
L38: 

    /** parser.e:4889				CompileErr(EXIT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22218);
    _49CompileErr(89LL, _22218, 0LL);
    goto L7; // [1155] 1915
L37: 

    /** parser.e:4892			elsif id = INCLUDE then*/
    if (_id_62854 != 418LL)
    goto L39; // [1162] 1178

    /** parser.e:4893				IncludeScan( 0 )*/
    _61IncludeScan(0LL);

    /** parser.e:4894				PushGoto()*/
    _43PushGoto();
    goto L7; // [1175] 1915
L39: 

    /** parser.e:4896			elsif id = WITH then*/
    if (_id_62854 != 420LL)
    goto L3A; // [1182] 1196

    /** parser.e:4897				SetWith(TRUE)*/
    _43SetWith(_9TRUE_441);
    goto L7; // [1193] 1915
L3A: 

    /** parser.e:4899			elsif id = WITHOUT then*/
    if (_id_62854 != 421LL)
    goto L3B; // [1200] 1214

    /** parser.e:4900				SetWith(FALSE)*/
    _43SetWith(_9FALSE_439);
    goto L7; // [1211] 1915
L3B: 

    /** parser.e:4902			elsif id = END_OF_FILE then*/
    if (_id_62854 != -21LL)
    goto L3C; // [1218] 1335

    /** parser.e:4903				if IncludePop() then*/
    _31142 = _61IncludePop();
    if (_31142 == 0) {
        DeRef(_31142);
        _31142 = NOVALUE;
        goto L3D; // [1227] 1323
    }
    else {
        if (!IS_ATOM_INT(_31142) && DBL_PTR(_31142)->dbl == 0.0){
            DeRef(_31142);
            _31142 = NOVALUE;
            goto L3D; // [1227] 1323
        }
        DeRef(_31142);
        _31142 = NOVALUE;
    }
    DeRef(_31142);
    _31142 = NOVALUE;

    /** parser.e:4904					backed_up_tok = {}*/
    RefDS(_22218);
    DeRef(_43backed_up_tok_55475);
    _43backed_up_tok_55475 = _22218;

    /** parser.e:4905					PopGoto()*/
    _43PopGoto();

    /** parser.e:4906					read_line()*/
    _61read_line();

    /** parser.e:4908					last_ForwardLine     = ThisLine*/
    Ref(_49ThisLine_49693);
    DeRef(_49last_ForwardLine_49696);
    _49last_ForwardLine_49696 = _49ThisLine_49693;

    /** parser.e:4909					last_fwd_line_number = line_number*/
    _27last_fwd_line_number_20575 = _27line_number_20572;

    /** parser.e:4910					last_forward_bp      = bp*/
    _49last_forward_bp_49700 = _49bp_49697;

    /** parser.e:4912					putback_ForwardLine     = ThisLine*/
    Ref(_49ThisLine_49693);
    DeRef(_49putback_ForwardLine_49695);
    _49putback_ForwardLine_49695 = _49ThisLine_49693;

    /** parser.e:4913					putback_fwd_line_number = line_number*/
    _27putback_fwd_line_number_20574 = _27line_number_20572;

    /** parser.e:4914					putback_forward_bp      = bp*/
    _49putback_forward_bp_49699 = _49bp_49697;

    /** parser.e:4916					ForwardLine     = ThisLine*/
    Ref(_49ThisLine_49693);
    DeRef(_49ForwardLine_49694);
    _49ForwardLine_49694 = _49ThisLine_49693;

    /** parser.e:4917					fwd_line_number = line_number*/
    _27fwd_line_number_20573 = _27line_number_20572;

    /** parser.e:4918					forward_bp      = bp*/
    _49forward_bp_49698 = _49bp_49697;
    goto L7; // [1320] 1915
L3D: 

    /** parser.e:4921					CheckForUndefinedGotoLabels()*/
    _43CheckForUndefinedGotoLabels();

    /** parser.e:4922					exit -- all finished*/
    goto L2; // [1329] 1925
    goto L7; // [1332] 1915
L3C: 

    /** parser.e:4925			elsif id = QUESTION_MARK then*/
    if (_id_62854 != -31LL)
    goto L3E; // [1339] 1363

    /** parser.e:4926				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:4927				Print_statement()*/
    _43Print_statement();

    /** parser.e:4928				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [1360] 1915
L3E: 

    /** parser.e:4930			elsif id = LABEL then*/
    if (_id_62854 != 419LL)
    goto L3F; // [1367] 1389

    /** parser.e:4931				StartSourceLine(TRUE, , COVERAGE_SUPPRESS)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 1LL);

    /** parser.e:4932				GLabel_statement()*/
    _43GLabel_statement();
    goto L7; // [1386] 1915
L3F: 

    /** parser.e:4934			elsif id = GOTO then*/
    if (_id_62854 != 188LL)
    goto L40; // [1393] 1413

    /** parser.e:4935				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:4936				Goto_statement()*/
    _43Goto_statement();
    goto L7; // [1410] 1915
L40: 

    /** parser.e:4938			elsif id = CONTINUE then*/
    if (_id_62854 != 426LL)
    goto L41; // [1417] 1455

    /** parser.e:4939				if nested then*/
    if (_nested_62851 == 0)
    {
        goto L42; // [1423] 1442
    }
    else{
    }

    /** parser.e:4940					StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:4941					Continue_statement()*/
    _43Continue_statement();
    goto L7; // [1439] 1915
L42: 

    /** parser.e:4943					CompileErr(CONTINUE_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22218);
    _49CompileErr(50LL, _22218, 0LL);
    goto L7; // [1452] 1915
L41: 

    /** parser.e:4946			elsif id = RETRY then*/
    if (_id_62854 != 184LL)
    goto L43; // [1459] 1497

    /** parser.e:4947				if nested then*/
    if (_nested_62851 == 0)
    {
        goto L44; // [1465] 1484
    }
    else{
    }

    /** parser.e:4948					StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:4949					Retry_statement()*/
    _43Retry_statement();
    goto L7; // [1481] 1915
L44: 

    /** parser.e:4951					CompileErr(RETRY_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22218);
    _49CompileErr(128LL, _22218, 0LL);
    goto L7; // [1494] 1915
L43: 

    /** parser.e:4954			elsif id = BREAK then*/
    if (_id_62854 != 425LL)
    goto L45; // [1501] 1539

    /** parser.e:4955				if nested then*/
    if (_nested_62851 == 0)
    {
        goto L46; // [1507] 1526
    }
    else{
    }

    /** parser.e:4956					StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:4957					Break_statement()*/
    _43Break_statement();
    goto L7; // [1523] 1915
L46: 

    /** parser.e:4959					CompileErr(BREAK_MUST_BE_INSIDE_AN_IF_BLOCK)*/
    RefDS(_22218);
    _49CompileErr(39LL, _22218, 0LL);
    goto L7; // [1536] 1915
L45: 

    /** parser.e:4962			elsif id = ENTRY then*/
    if (_id_62854 != 424LL)
    goto L47; // [1543] 1583

    /** parser.e:4963				if nested then*/
    if (_nested_62851 == 0)
    {
        goto L48; // [1549] 1570
    }
    else{
    }

    /** parser.e:4964				    StartSourceLine(TRUE, , COVERAGE_SUPPRESS)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 1LL);

    /** parser.e:4965				    Entry_statement()*/
    _43Entry_statement();
    goto L7; // [1567] 1915
L48: 

    /** parser.e:4967					CompileErr(ENTRY_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22218);
    _49CompileErr(72LL, _22218, 0LL);
    goto L7; // [1580] 1915
L47: 

    /** parser.e:4970			elsif id = IFDEF then*/
    if (_id_62854 != 407LL)
    goto L49; // [1587] 1607

    /** parser.e:4971				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:4972				Ifdef_statement()*/
    _43Ifdef_statement();
    goto L7; // [1604] 1915
L49: 

    /** parser.e:4974			elsif id = CASE then*/
    if (_id_62854 != 186LL)
    goto L4A; // [1611] 1622

    /** parser.e:4975				Case_statement()*/
    _43Case_statement();
    goto L7; // [1619] 1915
L4A: 

    /** parser.e:4977			elsif id = SWITCH then*/
    if (_id_62854 != 185LL)
    goto L4B; // [1626] 1646

    /** parser.e:4978				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:4979				Switch_statement()*/
    _43Switch_statement();
    goto L7; // [1643] 1915
L4B: 

    /** parser.e:4981			elsif id = LEFT_BRACE then*/
    if (_id_62854 != -24LL)
    goto L4C; // [1650] 1670

    /** parser.e:4982				StartSourceLine( TRUE )*/
    _45StartSourceLine(_9TRUE_441, 0LL, 2LL);

    /** parser.e:4983				Multi_assign()*/
    _43Multi_assign();
    goto L7; // [1667] 1915
L4C: 

    /** parser.e:4985			elsif id = ILLEGAL_CHAR then*/
    if (_id_62854 != -20LL)
    goto L4D; // [1674] 1690

    /** parser.e:4986				CompileErr(ILLEGAL_CHARACTER)*/
    RefDS(_22218);
    _49CompileErr(102LL, _22218, 0LL);
    goto L7; // [1687] 1915
L4D: 

    /** parser.e:4989				if nested then*/
    if (_nested_62851 == 0)
    {
        goto L4E; // [1692] 1852
    }
    else{
    }

    /** parser.e:4990					if id = ELSE then*/
    if (_id_62854 != 23LL)
    goto L4F; // [1699] 1757

    /** parser.e:4991						if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_43if_stack_55503)){
            _31156 = SEQ_PTR(_43if_stack_55503)->length;
    }
    else {
        _31156 = 1;
    }
    if (_31156 != 0LL)
    goto L50; // [1710] 1818

    /** parser.e:4992							if live_ifdef > 0 then*/
    if (_43live_ifdef_59975 <= 0LL)
    goto L51; // [1718] 1743

    /** parser.e:4993								CompileErr(SHOULD_THIS_BE_ELSEDEF_FOR_THE_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59976)){
            _31159 = SEQ_PTR(_43ifdef_lineno_59976)->length;
    }
    else {
        _31159 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59976);
    _31160 = (object)*(((s1_ptr)_2)->base + _31159);
    _49CompileErr(134LL, _31160, 0LL);
    _31160 = NOVALUE;
    goto L50; // [1740] 1818
L51: 

    /** parser.e:4995								CompileErr(NOT_EXPECTING_ELSE)*/
    RefDS(_22218);
    _49CompileErr(118LL, _22218, 0LL);
    goto L50; // [1754] 1818
L4F: 

    /** parser.e:4998					elsif id = ELSIF then*/
    if (_id_62854 != 414LL)
    goto L52; // [1761] 1817

    /** parser.e:4999						if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_43if_stack_55503)){
            _31162 = SEQ_PTR(_43if_stack_55503)->length;
    }
    else {
        _31162 = 1;
    }
    if (_31162 != 0LL)
    goto L53; // [1772] 1816

    /** parser.e:5000							if live_ifdef > 0 then*/
    if (_43live_ifdef_59975 <= 0LL)
    goto L54; // [1780] 1805

    /** parser.e:5001								CompileErr(SHOULD_THIS_BE_ELSIFDEF_FOR_THE_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59976)){
            _31165 = SEQ_PTR(_43ifdef_lineno_59976)->length;
    }
    else {
        _31165 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59976);
    _31166 = (object)*(((s1_ptr)_2)->base + _31165);
    _49CompileErr(139LL, _31166, 0LL);
    _31166 = NOVALUE;
    goto L55; // [1802] 1815
L54: 

    /** parser.e:5003								CompileErr(NOT_EXPECTING_ELSIF)*/
    RefDS(_22218);
    _49CompileErr(119LL, _22218, 0LL);
L55: 
L53: 
L52: 
L50: 

    /** parser.e:5007					putback(tok)*/
    Ref(_tok_62853);
    _43putback(_tok_62853);

    /** parser.e:5008					if stmt_nest > 0 then*/
    if (_43stmt_nest_55500 <= 0LL)
    goto L56; // [1827] 1844

    /** parser.e:5009						stmt_nest -= 1*/
    _43stmt_nest_55500 = _43stmt_nest_55500 - 1LL;

    /** parser.e:5010						InitDelete()*/
    _43InitDelete();
L56: 

    /** parser.e:5012					return*/
    DeRef(_tok_62853);
    DeRef(_31120);
    _31120 = NOVALUE;
    DeRef(_31065);
    _31065 = NOVALUE;
    DeRef(_31080);
    _31080 = NOVALUE;
    DeRef(_31118);
    _31118 = NOVALUE;
    _31101 = NOVALUE;
    DeRef(_31055);
    _31055 = NOVALUE;
    DeRef(_31067);
    _31067 = NOVALUE;
    DeRef(_31116);
    _31116 = NOVALUE;
    _31049 = NOVALUE;
    DeRef(_31061);
    _31061 = NOVALUE;
    DeRef(_31086);
    _31086 = NOVALUE;
    DeRef(_31089);
    _31089 = NOVALUE;
    DeRef(_31046);
    _31046 = NOVALUE;
    DeRef(_31108);
    _31108 = NOVALUE;
    DeRef(_31125);
    _31125 = NOVALUE;
    DeRef(_31084);
    _31084 = NOVALUE;
    DeRef(_31097);
    _31097 = NOVALUE;
    DeRef(_31057);
    _31057 = NOVALUE;
    DeRef(_31088);
    _31088 = NOVALUE;
    DeRef(_31052);
    _31052 = NOVALUE;
    DeRef(_31130);
    _31130 = NOVALUE;
    DeRef(_31091);
    _31091 = NOVALUE;
    DeRef(_31094);
    _31094 = NOVALUE;
    DeRef(_31063);
    _31063 = NOVALUE;
    DeRef(_31099);
    _31099 = NOVALUE;
    DeRef(_31104);
    _31104 = NOVALUE;
    return;
    goto L57; // [1849] 1914
L4E: 

    /** parser.e:5014					if id = END then*/
    if (_id_62854 != 402LL)
    goto L58; // [1856] 1889

    /** parser.e:5015						tok = next_token()*/
    _0 = _tok_62853;
    _tok_62853 = _43next_token();
    DeRef(_0);

    /** parser.e:5016						CompileErr(MSG_END_HAS_NO_MATCHING_1, {find_token_text(tok[T_ID])})*/
    _2 = (object)SEQ_PTR(_tok_62853);
    _31171 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_31171);
    _31172 = _62find_token_text(_31171);
    _31171 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _31172;
    _31173 = MAKE_SEQ(_1);
    _31172 = NOVALUE;
    _49CompileErr(17LL, _31173, 0LL);
    _31173 = NOVALUE;
L58: 

    /** parser.e:5019					CompileErr(NOT_EXPECTING_TO_SEE_1_HERE, { match_replace(",", find_token_text(id), "") })*/
    _31174 = _62find_token_text(_id_62854);
    RefDS(_26504);
    RefDS(_22218);
    _31175 = _14match_replace(_26504, _31174, _22218, 0LL);
    _31174 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _31175;
    _31176 = MAKE_SEQ(_1);
    _31175 = NOVALUE;
    _49CompileErr(117LL, _31176, 0LL);
    _31176 = NOVALUE;
L57: 
L7: 

    /** parser.e:5024			flush_temps()*/
    RefDS(_22218);
    _45flush_temps(_22218);

    /** parser.e:5025		end while*/
    goto L1; // [1922] 12
L2: 

    /** parser.e:5026		emit_op(RETURNT)*/
    _45emit_op(34LL);

    /** parser.e:5027		clear_last()*/
    _45clear_last();

    /** parser.e:5028		StraightenBranches()*/
    _43StraightenBranches();

    /** parser.e:5029		SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    RefDS(_27Code_20660);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27Code_20660;
    DeRef(_1);
    _31177 = NOVALUE;

    /** parser.e:5030		EndLineTable()*/
    _43EndLineTable();

    /** parser.e:5031		SymTab[TopLevelSub][S_LINETAB] = LineTable*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    RefDS(_27LineTable_20661);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_LINETAB_20244))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_LINETAB_20244)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_LINETAB_20244);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27LineTable_20661;
    DeRef(_1);
    _31179 = NOVALUE;

    /** parser.e:5032	end procedure*/
    DeRef(_tok_62853);
    DeRef(_31120);
    _31120 = NOVALUE;
    DeRef(_31065);
    _31065 = NOVALUE;
    DeRef(_31080);
    _31080 = NOVALUE;
    DeRef(_31118);
    _31118 = NOVALUE;
    _31101 = NOVALUE;
    DeRef(_31055);
    _31055 = NOVALUE;
    DeRef(_31067);
    _31067 = NOVALUE;
    DeRef(_31116);
    _31116 = NOVALUE;
    _31049 = NOVALUE;
    DeRef(_31061);
    _31061 = NOVALUE;
    DeRef(_31086);
    _31086 = NOVALUE;
    DeRef(_31089);
    _31089 = NOVALUE;
    DeRef(_31046);
    _31046 = NOVALUE;
    DeRef(_31108);
    _31108 = NOVALUE;
    DeRef(_31125);
    _31125 = NOVALUE;
    DeRef(_31084);
    _31084 = NOVALUE;
    DeRef(_31097);
    _31097 = NOVALUE;
    DeRef(_31057);
    _31057 = NOVALUE;
    DeRef(_31088);
    _31088 = NOVALUE;
    DeRef(_31052);
    _31052 = NOVALUE;
    DeRef(_31130);
    _31130 = NOVALUE;
    DeRef(_31091);
    _31091 = NOVALUE;
    DeRef(_31094);
    _31094 = NOVALUE;
    DeRef(_31063);
    _31063 = NOVALUE;
    DeRef(_31099);
    _31099 = NOVALUE;
    DeRef(_31104);
    _31104 = NOVALUE;
    return;
    ;
}


void _43parser()
{
    object _31183 = NOVALUE;
    object _31181 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:5035		real_parser(0)*/
    _43real_parser(0LL);

    /** parser.e:5036		mark_final_targets()*/
    _53mark_final_targets();

    /** parser.e:5037		resolve_unincluded_globals( 1 )*/
    _53resolve_unincluded_globals(1LL);

    /** parser.e:5038		Resolve_forward_references( 1 )*/
    _42Resolve_forward_references(1LL);

    /** parser.e:5039		SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    RefDS(_27Code_20660);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27Code_20660;
    DeRef(_1);
    _31181 = NOVALUE;

    /** parser.e:5040		SymTab[TopLevelSub][S_LINETAB] = LineTable*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    RefDS(_27LineTable_20661);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_LINETAB_20244))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_LINETAB_20244)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_LINETAB_20244);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27LineTable_20661;
    DeRef(_1);
    _31183 = NOVALUE;

    /** parser.e:5041		Code = {}*/
    RefDS(_22218);
    DeRefDS(_27Code_20660);
    _27Code_20660 = _22218;

    /** parser.e:5042		LineTable = {}*/
    RefDS(_22218);
    DeRefDS(_27LineTable_20661);
    _27LineTable_20661 = _22218;

    /** parser.e:5043		inline_deferred_calls()*/
    _66inline_deferred_calls();

    /** parser.e:5044		if not repl then*/

    /** parser.e:5045		End_block( PROC )*/
    _64End_block(27LL);

    /** parser.e:5046		Code = {}*/
    RefDS(_22218);
    DeRefDS(_27Code_20660);
    _27Code_20660 = _22218;

    /** parser.e:5047		LineTable = {}*/
    RefDS(_22218);
    DeRefDS(_27LineTable_20661);
    _27LineTable_20661 = _22218;

    /** parser.e:5049	end procedure*/
    return;
    ;
}


void _43nested_parser()
{
    object _0, _1, _2;
    

    /** parser.e:5052		real_parser(1)*/
    _43real_parser(1LL);

    /** parser.e:5053	end procedure*/
    return;
    ;
}



// 0x3CA65906
