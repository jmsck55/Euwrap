// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _9char_test(object _test_data_479, object _char_set_480)
{
    object _lChr_481 = NOVALUE;
    object _128 = NOVALUE;
    object _127 = NOVALUE;
    object _126 = NOVALUE;
    object _125 = NOVALUE;
    object _124 = NOVALUE;
    object _123 = NOVALUE;
    object _122 = NOVALUE;
    object _121 = NOVALUE;
    object _120 = NOVALUE;
    object _119 = NOVALUE;
    object _118 = NOVALUE;
    object _115 = NOVALUE;
    object _114 = NOVALUE;
    object _113 = NOVALUE;
    object _112 = NOVALUE;
    object _110 = NOVALUE;
    object _108 = NOVALUE;
    object _107 = NOVALUE;
    object _106 = NOVALUE;
    object _105 = NOVALUE;
    object _104 = NOVALUE;
    object _103 = NOVALUE;
    object _102 = NOVALUE;
    object _101 = NOVALUE;
    object _100 = NOVALUE;
    object _99 = NOVALUE;
    object _98 = NOVALUE;
    object _97 = NOVALUE;
    object _96 = NOVALUE;
    object _95 = NOVALUE;
    object _94 = NOVALUE;
    object _0, _1, _2;
    

    /** types.e:194		if integer(test_data) then*/
    if (IS_ATOM_INT(_test_data_479))
    _94 = 1;
    else if (IS_ATOM_DBL(_test_data_479))
    _94 = IS_ATOM_INT(DoubleToInt(_test_data_479));
    else
    _94 = 0;
    if (_94 == 0)
    {
        _94 = NOVALUE;
        goto L1; // [8] 115
    }
    else{
        _94 = NOVALUE;
    }

    /** types.e:195			if sequence(char_set[1]) then*/
    _2 = (object)SEQ_PTR(_char_set_480);
    _95 = (object)*(((s1_ptr)_2)->base + 1LL);
    _96 = IS_SEQUENCE(_95);
    _95 = NOVALUE;
    if (_96 == 0)
    {
        _96 = NOVALUE;
        goto L2; // [20] 96
    }
    else{
        _96 = NOVALUE;
    }

    /** types.e:196				for j = 1 to length(char_set) do*/
    if (IS_SEQUENCE(_char_set_480)){
            _97 = SEQ_PTR(_char_set_480)->length;
    }
    else {
        _97 = 1;
    }
    {
        object _j_488;
        _j_488 = 1LL;
L3: 
        if (_j_488 > _97){
            goto L4; // [28] 85
        }

        /** types.e:197					if test_data >= char_set[j][1] and test_data <= char_set[j][2] then */
        _2 = (object)SEQ_PTR(_char_set_480);
        _98 = (object)*(((s1_ptr)_2)->base + _j_488);
        _2 = (object)SEQ_PTR(_98);
        _99 = (object)*(((s1_ptr)_2)->base + 1LL);
        _98 = NOVALUE;
        if (IS_ATOM_INT(_test_data_479) && IS_ATOM_INT(_99)) {
            _100 = (_test_data_479 >= _99);
        }
        else {
            _100 = binary_op(GREATEREQ, _test_data_479, _99);
        }
        _99 = NOVALUE;
        if (IS_ATOM_INT(_100)) {
            if (_100 == 0) {
                goto L5; // [49] 78
            }
        }
        else {
            if (DBL_PTR(_100)->dbl == 0.0) {
                goto L5; // [49] 78
            }
        }
        _2 = (object)SEQ_PTR(_char_set_480);
        _102 = (object)*(((s1_ptr)_2)->base + _j_488);
        _2 = (object)SEQ_PTR(_102);
        _103 = (object)*(((s1_ptr)_2)->base + 2LL);
        _102 = NOVALUE;
        if (IS_ATOM_INT(_test_data_479) && IS_ATOM_INT(_103)) {
            _104 = (_test_data_479 <= _103);
        }
        else {
            _104 = binary_op(LESSEQ, _test_data_479, _103);
        }
        _103 = NOVALUE;
        if (_104 == 0) {
            DeRef(_104);
            _104 = NOVALUE;
            goto L5; // [66] 78
        }
        else {
            if (!IS_ATOM_INT(_104) && DBL_PTR(_104)->dbl == 0.0){
                DeRef(_104);
                _104 = NOVALUE;
                goto L5; // [66] 78
            }
            DeRef(_104);
            _104 = NOVALUE;
        }
        DeRef(_104);
        _104 = NOVALUE;

        /** types.e:198						return TRUE */
        DeRef(_test_data_479);
        DeRefDS(_char_set_480);
        DeRef(_100);
        _100 = NOVALUE;
        return _9TRUE_441;
L5: 

        /** types.e:200				end for*/
        _j_488 = _j_488 + 1LL;
        goto L3; // [80] 35
L4: 
        ;
    }

    /** types.e:201				return FALSE*/
    DeRef(_test_data_479);
    DeRefDS(_char_set_480);
    DeRef(_100);
    _100 = NOVALUE;
    return _9FALSE_439;
    goto L6; // [93] 328
L2: 

    /** types.e:203				return find(test_data, char_set) > 0*/
    _105 = find_from(_test_data_479, _char_set_480, 1LL);
    _106 = (_105 > 0LL);
    _105 = NOVALUE;
    DeRef(_test_data_479);
    DeRefDS(_char_set_480);
    DeRef(_100);
    _100 = NOVALUE;
    return _106;
    goto L6; // [112] 328
L1: 

    /** types.e:205		elsif sequence(test_data) then*/
    _107 = IS_SEQUENCE(_test_data_479);
    if (_107 == 0)
    {
        _107 = NOVALUE;
        goto L7; // [120] 319
    }
    else{
        _107 = NOVALUE;
    }

    /** types.e:206			if length(test_data) = 0 then */
    if (IS_SEQUENCE(_test_data_479)){
            _108 = SEQ_PTR(_test_data_479)->length;
    }
    else {
        _108 = 1;
    }
    if (_108 != 0LL)
    goto L8; // [128] 141

    /** types.e:207				return FALSE */
    DeRef(_test_data_479);
    DeRefDS(_char_set_480);
    DeRef(_106);
    _106 = NOVALUE;
    DeRef(_100);
    _100 = NOVALUE;
    return _9FALSE_439;
L8: 

    /** types.e:209			for i = 1 to length(test_data) label "NXTCHR" do*/
    if (IS_SEQUENCE(_test_data_479)){
            _110 = SEQ_PTR(_test_data_479)->length;
    }
    else {
        _110 = 1;
    }
    {
        object _i_507;
        _i_507 = 1LL;
L9: 
        if (_i_507 > _110){
            goto LA; // [146] 308
        }

        /** types.e:210				if sequence(test_data[i]) then */
        _2 = (object)SEQ_PTR(_test_data_479);
        _112 = (object)*(((s1_ptr)_2)->base + _i_507);
        _113 = IS_SEQUENCE(_112);
        _112 = NOVALUE;
        if (_113 == 0)
        {
            _113 = NOVALUE;
            goto LB; // [162] 174
        }
        else{
            _113 = NOVALUE;
        }

        /** types.e:211					return FALSE*/
        DeRef(_test_data_479);
        DeRefDS(_char_set_480);
        DeRef(_106);
        _106 = NOVALUE;
        DeRef(_100);
        _100 = NOVALUE;
        return _9FALSE_439;
LB: 

        /** types.e:213				if not integer(test_data[i]) then */
        _2 = (object)SEQ_PTR(_test_data_479);
        _114 = (object)*(((s1_ptr)_2)->base + _i_507);
        if (IS_ATOM_INT(_114))
        _115 = 1;
        else if (IS_ATOM_DBL(_114))
        _115 = IS_ATOM_INT(DoubleToInt(_114));
        else
        _115 = 0;
        _114 = NOVALUE;
        if (_115 != 0)
        goto LC; // [183] 195
        _115 = NOVALUE;

        /** types.e:214					return FALSE*/
        DeRef(_test_data_479);
        DeRefDS(_char_set_480);
        DeRef(_106);
        _106 = NOVALUE;
        DeRef(_100);
        _100 = NOVALUE;
        return _9FALSE_439;
LC: 

        /** types.e:216				lChr = test_data[i]*/
        _2 = (object)SEQ_PTR(_test_data_479);
        _lChr_481 = (object)*(((s1_ptr)_2)->base + _i_507);
        if (!IS_ATOM_INT(_lChr_481)){
            _lChr_481 = (object)DBL_PTR(_lChr_481)->dbl;
        }

        /** types.e:217				if sequence(char_set[1]) then*/
        _2 = (object)SEQ_PTR(_char_set_480);
        _118 = (object)*(((s1_ptr)_2)->base + 1LL);
        _119 = IS_SEQUENCE(_118);
        _118 = NOVALUE;
        if (_119 == 0)
        {
            _119 = NOVALUE;
            goto LD; // [212] 276
        }
        else{
            _119 = NOVALUE;
        }

        /** types.e:218					for j = 1 to length(char_set) do*/
        if (IS_SEQUENCE(_char_set_480)){
                _120 = SEQ_PTR(_char_set_480)->length;
        }
        else {
            _120 = 1;
        }
        {
            object _j_522;
            _j_522 = 1LL;
LE: 
            if (_j_522 > _120){
                goto LF; // [220] 273
            }

            /** types.e:219						if lChr >= char_set[j][1] and lChr <= char_set[j][2] then*/
            _2 = (object)SEQ_PTR(_char_set_480);
            _121 = (object)*(((s1_ptr)_2)->base + _j_522);
            _2 = (object)SEQ_PTR(_121);
            _122 = (object)*(((s1_ptr)_2)->base + 1LL);
            _121 = NOVALUE;
            if (IS_ATOM_INT(_122)) {
                _123 = (_lChr_481 >= _122);
            }
            else {
                _123 = binary_op(GREATEREQ, _lChr_481, _122);
            }
            _122 = NOVALUE;
            if (IS_ATOM_INT(_123)) {
                if (_123 == 0) {
                    goto L10; // [241] 266
                }
            }
            else {
                if (DBL_PTR(_123)->dbl == 0.0) {
                    goto L10; // [241] 266
                }
            }
            _2 = (object)SEQ_PTR(_char_set_480);
            _125 = (object)*(((s1_ptr)_2)->base + _j_522);
            _2 = (object)SEQ_PTR(_125);
            _126 = (object)*(((s1_ptr)_2)->base + 2LL);
            _125 = NOVALUE;
            if (IS_ATOM_INT(_126)) {
                _127 = (_lChr_481 <= _126);
            }
            else {
                _127 = binary_op(LESSEQ, _lChr_481, _126);
            }
            _126 = NOVALUE;
            if (_127 == 0) {
                DeRef(_127);
                _127 = NOVALUE;
                goto L10; // [258] 266
            }
            else {
                if (!IS_ATOM_INT(_127) && DBL_PTR(_127)->dbl == 0.0){
                    DeRef(_127);
                    _127 = NOVALUE;
                    goto L10; // [258] 266
                }
                DeRef(_127);
                _127 = NOVALUE;
            }
            DeRef(_127);
            _127 = NOVALUE;

            /** types.e:220							continue "NXTCHR" */
            goto L11; // [263] 303
L10: 

            /** types.e:222					end for*/
            _j_522 = _j_522 + 1LL;
            goto LE; // [268] 227
LF: 
            ;
        }
        goto L12; // [273] 293
LD: 

        /** types.e:224					if find(lChr, char_set) > 0 then*/
        _128 = find_from(_lChr_481, _char_set_480, 1LL);
        if (_128 <= 0LL)
        goto L13; // [283] 292

        /** types.e:225						continue "NXTCHR"*/
        goto L11; // [289] 303
L13: 
L12: 

        /** types.e:228				return FALSE*/
        DeRef(_test_data_479);
        DeRefDS(_char_set_480);
        DeRef(_106);
        _106 = NOVALUE;
        DeRef(_100);
        _100 = NOVALUE;
        DeRef(_123);
        _123 = NOVALUE;
        return _9FALSE_439;

        /** types.e:229			end for*/
L11: 
        _i_507 = _i_507 + 1LL;
        goto L9; // [303] 153
LA: 
        ;
    }

    /** types.e:230			return TRUE*/
    DeRef(_test_data_479);
    DeRefDS(_char_set_480);
    DeRef(_106);
    _106 = NOVALUE;
    DeRef(_100);
    _100 = NOVALUE;
    DeRef(_123);
    _123 = NOVALUE;
    return _9TRUE_441;
    goto L6; // [316] 328
L7: 

    /** types.e:232			return FALSE*/
    DeRef(_test_data_479);
    DeRefDS(_char_set_480);
    DeRef(_106);
    _106 = NOVALUE;
    DeRef(_100);
    _100 = NOVALUE;
    DeRef(_123);
    _123 = NOVALUE;
    return _9FALSE_439;
L6: 
    ;
}


void _9set_default_charsets()
{
    object _193 = NOVALUE;
    object _191 = NOVALUE;
    object _190 = NOVALUE;
    object _188 = NOVALUE;
    object _185 = NOVALUE;
    object _184 = NOVALUE;
    object _183 = NOVALUE;
    object _182 = NOVALUE;
    object _179 = NOVALUE;
    object _177 = NOVALUE;
    object _166 = NOVALUE;
    object _159 = NOVALUE;
    object _156 = NOVALUE;
    object _149 = NOVALUE;
    object _146 = NOVALUE;
    object _145 = NOVALUE;
    object _144 = NOVALUE;
    object _141 = NOVALUE;
    object _139 = NOVALUE;
    object _131 = NOVALUE;
    object _130 = NOVALUE;
    object _0, _1, _2;
    

    /** types.e:247		Defined_Sets = repeat(0, CS_LAST - CS_FIRST - 1)*/
    _130 = 20LL;
    _131 = 19LL;
    _130 = NOVALUE;
    DeRef(_9Defined_Sets_537);
    _9Defined_Sets_537 = Repeat(0LL, 19LL);
    _131 = NOVALUE;

    /** types.e:248		Defined_Sets[CS_Alphabetic	] = {{'a', 'z'}, {'A', 'Z'}}*/
    RefDS(_138);
    RefDS(_135);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _135;
    ((intptr_t *)_2)[2] = _138;
    _139 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_9Defined_Sets_537);
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    *(intptr_t *)_2 = _139;
    if( _1 != _139 ){
    }
    _139 = NOVALUE;

    /** types.e:249		Defined_Sets[CS_Alphanumeric] = {{'0', '9'}, {'a', 'z'}, {'A', 'Z'}}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_140);
    ((intptr_t*)_2)[1] = _140;
    RefDS(_135);
    ((intptr_t*)_2)[2] = _135;
    RefDS(_138);
    ((intptr_t*)_2)[3] = _138;
    _141 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_9Defined_Sets_537);
    _2 = (object)(((s1_ptr)_2)->base + 10LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _141;
    if( _1 != _141 ){
        DeRef(_1);
    }
    _141 = NOVALUE;

    /** types.e:250		Defined_Sets[CS_Identifier]   = {{'0', '9'}, {'a', 'z'}, {'A', 'Z'}, {'_', '_'}}*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_140);
    ((intptr_t*)_2)[1] = _140;
    RefDS(_135);
    ((intptr_t*)_2)[2] = _135;
    RefDS(_138);
    ((intptr_t*)_2)[3] = _138;
    RefDS(_143);
    ((intptr_t*)_2)[4] = _143;
    _144 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_9Defined_Sets_537);
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _144;
    if( _1 != _144 ){
        DeRef(_1);
    }
    _144 = NOVALUE;

    /** types.e:251		Defined_Sets[CS_Uppercase 	] = {{'A', 'Z'}}*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_138);
    ((intptr_t*)_2)[1] = _138;
    _145 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_9Defined_Sets_537);
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _145;
    if( _1 != _145 ){
        DeRef(_1);
    }
    _145 = NOVALUE;

    /** types.e:252		Defined_Sets[CS_Lowercase 	] = {{'a', 'z'}}*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_135);
    ((intptr_t*)_2)[1] = _135;
    _146 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_9Defined_Sets_537);
    _2 = (object)(((s1_ptr)_2)->base + 8LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _146;
    if( _1 != _146 ){
        DeRef(_1);
    }
    _146 = NOVALUE;

    /** types.e:253		Defined_Sets[CS_Printable 	] = {{' ', '~'}}*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_148);
    ((intptr_t*)_2)[1] = _148;
    _149 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_9Defined_Sets_537);
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _149;
    if( _1 != _149 ){
        DeRef(_1);
    }
    _149 = NOVALUE;

    /** types.e:254		Defined_Sets[CS_Displayable ] = {{' ', '~'}, "  ", "\t\t", "\n\n", "\r\r", {8,8}, {7,7} }*/
    _1 = NewS1(7);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_148);
    ((intptr_t*)_2)[1] = _148;
    RefDS(_150);
    ((intptr_t*)_2)[2] = _150;
    RefDS(_151);
    ((intptr_t*)_2)[3] = _151;
    RefDS(_152);
    ((intptr_t*)_2)[4] = _152;
    RefDS(_153);
    ((intptr_t*)_2)[5] = _153;
    RefDS(_154);
    ((intptr_t*)_2)[6] = _154;
    RefDS(_155);
    ((intptr_t*)_2)[7] = _155;
    _156 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_9Defined_Sets_537);
    _2 = (object)(((s1_ptr)_2)->base + 7LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _156;
    if( _1 != _156 ){
        DeRef(_1);
    }
    _156 = NOVALUE;

    /** types.e:255		Defined_Sets[CS_Whitespace 	] = " \t\n\r" & 11 & 160*/
    {
        object concat_list[3];

        concat_list[0] = 160LL;
        concat_list[1] = 11LL;
        concat_list[2] = _157;
        Concat_N((object_ptr)&_159, concat_list, 3);
    }
    _2 = (object)SEQ_PTR(_9Defined_Sets_537);
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _159;
    if( _1 != _159 ){
        DeRef(_1);
    }
    _159 = NOVALUE;

    /** types.e:256		Defined_Sets[CS_Consonant 	] = "bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ"*/
    RefDS(_160);
    _2 = (object)SEQ_PTR(_9Defined_Sets_537);
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _160;
    DeRef(_1);

    /** types.e:257		Defined_Sets[CS_Vowel 		] = "aeiouAEIOU"*/
    RefDS(_161);
    _2 = (object)SEQ_PTR(_9Defined_Sets_537);
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _161;
    DeRef(_1);

    /** types.e:258		Defined_Sets[CS_Hexadecimal ] = {{'0', '9'}, {'A', 'F'},{'a', 'f'}}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_140);
    ((intptr_t*)_2)[1] = _140;
    RefDS(_163);
    ((intptr_t*)_2)[2] = _163;
    RefDS(_165);
    ((intptr_t*)_2)[3] = _165;
    _166 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_9Defined_Sets_537);
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _166;
    if( _1 != _166 ){
        DeRef(_1);
    }
    _166 = NOVALUE;

    /** types.e:259		Defined_Sets[CS_Punctuation ] = {{' ', '/'}, {':', '?'}, {'[', '`'}, {'{', '~'}}*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_168);
    ((intptr_t*)_2)[1] = _168;
    RefDS(_171);
    ((intptr_t*)_2)[2] = _171;
    RefDS(_174);
    ((intptr_t*)_2)[3] = _174;
    RefDS(_176);
    ((intptr_t*)_2)[4] = _176;
    _177 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_9Defined_Sets_537);
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _177;
    if( _1 != _177 ){
        DeRef(_1);
    }
    _177 = NOVALUE;

    /** types.e:260		Defined_Sets[CS_Control 	] = {{0, 31}, {127, 127}}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = 31LL;
    _179 = MAKE_SEQ(_1);
    RefDS(_181);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _179;
    ((intptr_t *)_2)[2] = _181;
    _182 = MAKE_SEQ(_1);
    _179 = NOVALUE;
    _2 = (object)SEQ_PTR(_9Defined_Sets_537);
    _2 = (object)(((s1_ptr)_2)->base + 14LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _182;
    if( _1 != _182 ){
        DeRef(_1);
    }
    _182 = NOVALUE;

    /** types.e:261		Defined_Sets[CS_ASCII 		] = {{0, 127}}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = 127LL;
    _183 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _183;
    _184 = MAKE_SEQ(_1);
    _183 = NOVALUE;
    _2 = (object)SEQ_PTR(_9Defined_Sets_537);
    _2 = (object)(((s1_ptr)_2)->base + 13LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _184;
    if( _1 != _184 ){
        DeRef(_1);
    }
    _184 = NOVALUE;

    /** types.e:262		Defined_Sets[CS_Digit 		] = {{'0', '9'}}*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_140);
    ((intptr_t*)_2)[1] = _140;
    _185 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_9Defined_Sets_537);
    _2 = (object)(((s1_ptr)_2)->base + 15LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _185;
    if( _1 != _185 ){
        DeRef(_1);
    }
    _185 = NOVALUE;

    /** types.e:263		Defined_Sets[CS_Graphic 	] = {{'!', '~'}}*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_187);
    ((intptr_t*)_2)[1] = _187;
    _188 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_9Defined_Sets_537);
    _2 = (object)(((s1_ptr)_2)->base + 16LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _188;
    if( _1 != _188 ){
        DeRef(_1);
    }
    _188 = NOVALUE;

    /** types.e:264		Defined_Sets[CS_Bytes	 	] = {{0, 255}}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = 255LL;
    _190 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _190;
    _191 = MAKE_SEQ(_1);
    _190 = NOVALUE;
    _2 = (object)SEQ_PTR(_9Defined_Sets_537);
    _2 = (object)(((s1_ptr)_2)->base + 17LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _191;
    if( _1 != _191 ){
        DeRef(_1);
    }
    _191 = NOVALUE;

    /** types.e:265		Defined_Sets[CS_SpecWord 	] = "_"*/
    RefDS(_192);
    _2 = (object)SEQ_PTR(_9Defined_Sets_537);
    _2 = (object)(((s1_ptr)_2)->base + 18LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _192;
    DeRef(_1);

    /** types.e:266		Defined_Sets[CS_Boolean     ] = {TRUE,FALSE}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _9TRUE_441;
    ((intptr_t *)_2)[2] = _9FALSE_439;
    _193 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_9Defined_Sets_537);
    _2 = (object)(((s1_ptr)_2)->base + 19LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _193;
    if( _1 != _193 ){
        DeRef(_1);
    }
    _193 = NOVALUE;

    /** types.e:267	end procedure*/
    return;
    ;
}


object _9t_identifier(object _test_data_661)
{
    object _237 = NOVALUE;
    object _236 = NOVALUE;
    object _235 = NOVALUE;
    object _234 = NOVALUE;
    object _233 = NOVALUE;
    object _232 = NOVALUE;
    object _231 = NOVALUE;
    object _230 = NOVALUE;
    object _229 = NOVALUE;
    object _228 = NOVALUE;
    object _0, _1, _2;
    

    /** types.e:458		if t_digit(test_data) then*/
    RefDS(_test_data_661);
    _228 = _9t_digit(_test_data_661);
    if (_228 == 0) {
        DeRef(_228);
        _228 = NOVALUE;
        goto L1; // [7] 19
    }
    else {
        if (!IS_ATOM_INT(_228) && DBL_PTR(_228)->dbl == 0.0){
            DeRef(_228);
            _228 = NOVALUE;
            goto L1; // [7] 19
        }
        DeRef(_228);
        _228 = NOVALUE;
    }
    DeRef(_228);
    _228 = NOVALUE;

    /** types.e:459			return 0*/
    DeRefDS(_test_data_661);
    return 0LL;
    goto L2; // [16] 63
L1: 

    /** types.e:460		elsif sequence(test_data) and length(test_data) > 0 and t_digit(test_data[1]) then*/
    _229 = IS_SEQUENCE(_test_data_661);
    if (_229 == 0) {
        _230 = 0;
        goto L3; // [24] 39
    }
    if (IS_SEQUENCE(_test_data_661)){
            _231 = SEQ_PTR(_test_data_661)->length;
    }
    else {
        _231 = 1;
    }
    _232 = (_231 > 0LL);
    _231 = NOVALUE;
    _230 = (_232 != 0);
L3: 
    if (_230 == 0) {
        goto L4; // [39] 62
    }
    _2 = (object)SEQ_PTR(_test_data_661);
    _234 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_234);
    _235 = _9t_digit(_234);
    _234 = NOVALUE;
    if (_235 == 0) {
        DeRef(_235);
        _235 = NOVALUE;
        goto L4; // [52] 62
    }
    else {
        if (!IS_ATOM_INT(_235) && DBL_PTR(_235)->dbl == 0.0){
            DeRef(_235);
            _235 = NOVALUE;
            goto L4; // [52] 62
        }
        DeRef(_235);
        _235 = NOVALUE;
    }
    DeRef(_235);
    _235 = NOVALUE;

    /** types.e:461			return 0*/
    DeRef(_test_data_661);
    DeRef(_232);
    _232 = NOVALUE;
    return 0LL;
L4: 
L2: 

    /** types.e:464		return char_test(test_data, Defined_Sets[CS_Identifier])*/
    _2 = (object)SEQ_PTR(_9Defined_Sets_537);
    _236 = (object)*(((s1_ptr)_2)->base + 11LL);
    Ref(_test_data_661);
    Ref(_236);
    _237 = _9char_test(_test_data_661, _236);
    _236 = NOVALUE;
    DeRef(_test_data_661);
    DeRef(_232);
    _232 = NOVALUE;
    return _237;
    ;
}


object _9t_alpha(object _test_data_678)
{
    object _239 = NOVALUE;
    object _238 = NOVALUE;
    object _0, _1, _2;
    

    /** types.e:494		return char_test(test_data, Defined_Sets[CS_Alphabetic])*/
    _2 = (object)SEQ_PTR(_9Defined_Sets_537);
    _238 = (object)*(((s1_ptr)_2)->base + 12LL);
    Ref(_test_data_678);
    Ref(_238);
    _239 = _9char_test(_test_data_678, _238);
    _238 = NOVALUE;
    DeRef(_test_data_678);
    return _239;
    ;
}


object _9t_digit(object _test_data_693)
{
    object _245 = NOVALUE;
    object _244 = NOVALUE;
    object _0, _1, _2;
    

    /** types.e:587		return char_test(test_data, Defined_Sets[CS_Digit])*/
    _2 = (object)SEQ_PTR(_9Defined_Sets_537);
    _244 = (object)*(((s1_ptr)_2)->base + 15LL);
    Ref(_test_data_693);
    Ref(_244);
    _245 = _9char_test(_test_data_693, _244);
    _244 = NOVALUE;
    DeRef(_test_data_693);
    return _245;
    ;
}


object _9t_specword(object _test_data_703)
{
    object _249 = NOVALUE;
    object _248 = NOVALUE;
    object _0, _1, _2;
    

    /** types.e:659		return char_test(test_data, Defined_Sets[CS_SpecWord])*/
    _2 = (object)SEQ_PTR(_9Defined_Sets_537);
    _248 = (object)*(((s1_ptr)_2)->base + 18LL);
    Ref(_test_data_703);
    Ref(_248);
    _249 = _9char_test(_test_data_703, _248);
    _248 = NOVALUE;
    DeRef(_test_data_703);
    return _249;
    ;
}


object _9t_lower(object _test_data_713)
{
    object _253 = NOVALUE;
    object _252 = NOVALUE;
    object _0, _1, _2;
    

    /** types.e:727		return char_test(test_data, Defined_Sets[CS_Lowercase])*/
    _2 = (object)SEQ_PTR(_9Defined_Sets_537);
    _252 = (object)*(((s1_ptr)_2)->base + 8LL);
    Ref(_test_data_713);
    Ref(_252);
    _253 = _9char_test(_test_data_713, _252);
    _252 = NOVALUE;
    DeRef(_test_data_713);
    return _253;
    ;
}


object _9t_display(object _test_data_723)
{
    object _257 = NOVALUE;
    object _256 = NOVALUE;
    object _0, _1, _2;
    

    /** types.e:795		return char_test(test_data, Defined_Sets[CS_Displayable])*/
    _2 = (object)SEQ_PTR(_9Defined_Sets_537);
    _256 = (object)*(((s1_ptr)_2)->base + 7LL);
    Ref(_test_data_723);
    Ref(_256);
    _257 = _9char_test(_test_data_723, _256);
    _256 = NOVALUE;
    DeRef(_test_data_723);
    return _257;
    ;
}


object _9t_upper(object _test_data_738)
{
    object _263 = NOVALUE;
    object _262 = NOVALUE;
    object _0, _1, _2;
    

    /** types.e:890		return char_test(test_data, Defined_Sets[CS_Uppercase])*/
    _2 = (object)SEQ_PTR(_9Defined_Sets_537);
    _262 = (object)*(((s1_ptr)_2)->base + 9LL);
    Ref(_test_data_738);
    Ref(_262);
    _263 = _9char_test(_test_data_738, _262);
    _262 = NOVALUE;
    DeRef(_test_data_738);
    return _263;
    ;
}


object _9number_array(object _x_787)
{
    object _288 = NOVALUE;
    object _287 = NOVALUE;
    object _286 = NOVALUE;
    object _284 = NOVALUE;
    object _0, _1, _2;
    

    /** types.e:1071		if not sequence(x) then*/
    _284 = IS_SEQUENCE(_x_787);
    if (_284 != 0)
    goto L1; // [6] 16
    _284 = NOVALUE;

    /** types.e:1072			return 0*/
    DeRef(_x_787);
    return 0LL;
L1: 

    /** types.e:1075		for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_787)){
            _286 = SEQ_PTR(_x_787)->length;
    }
    else {
        _286 = 1;
    }
    {
        object _i_792;
        _i_792 = 1LL;
L2: 
        if (_i_792 > _286){
            goto L3; // [21] 54
        }

        /** types.e:1076			if not atom(x[i]) then*/
        _2 = (object)SEQ_PTR(_x_787);
        _287 = (object)*(((s1_ptr)_2)->base + _i_792);
        _288 = IS_ATOM(_287);
        _287 = NOVALUE;
        if (_288 != 0)
        goto L4; // [37] 47
        _288 = NOVALUE;

        /** types.e:1077				return 0*/
        DeRef(_x_787);
        return 0LL;
L4: 

        /** types.e:1079		end for*/
        _i_792 = _i_792 + 1LL;
        goto L2; // [49] 28
L3: 
        ;
    }

    /** types.e:1080		return 1*/
    DeRef(_x_787);
    return 1LL;
    ;
}


object _9ascii_string(object _x_813)
{
    object _304 = NOVALUE;
    object _302 = NOVALUE;
    object _300 = NOVALUE;
    object _299 = NOVALUE;
    object _298 = NOVALUE;
    object _296 = NOVALUE;
    object _0, _1, _2;
    

    /** types.e:1132		if not sequence(x) then*/
    _296 = IS_SEQUENCE(_x_813);
    if (_296 != 0)
    goto L1; // [6] 16
    _296 = NOVALUE;

    /** types.e:1133			return 0*/
    DeRef(_x_813);
    return 0LL;
L1: 

    /** types.e:1136		for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_813)){
            _298 = SEQ_PTR(_x_813)->length;
    }
    else {
        _298 = 1;
    }
    {
        object _i_818;
        _i_818 = 1LL;
L2: 
        if (_i_818 > _298){
            goto L3; // [21] 88
        }

        /** types.e:1137			if not integer(x[i]) then*/
        _2 = (object)SEQ_PTR(_x_813);
        _299 = (object)*(((s1_ptr)_2)->base + _i_818);
        if (IS_ATOM_INT(_299))
        _300 = 1;
        else if (IS_ATOM_DBL(_299))
        _300 = IS_ATOM_INT(DoubleToInt(_299));
        else
        _300 = 0;
        _299 = NOVALUE;
        if (_300 != 0)
        goto L4; // [37] 47
        _300 = NOVALUE;

        /** types.e:1138				return 0*/
        DeRef(_x_813);
        return 0LL;
L4: 

        /** types.e:1140			if x[i] < 0 then*/
        _2 = (object)SEQ_PTR(_x_813);
        _302 = (object)*(((s1_ptr)_2)->base + _i_818);
        if (binary_op_a(GREATEREQ, _302, 0LL)){
            _302 = NOVALUE;
            goto L5; // [53] 64
        }
        _302 = NOVALUE;

        /** types.e:1141				return 0*/
        DeRef(_x_813);
        return 0LL;
L5: 

        /** types.e:1143			if x[i] > 127 then*/
        _2 = (object)SEQ_PTR(_x_813);
        _304 = (object)*(((s1_ptr)_2)->base + _i_818);
        if (binary_op_a(LESSEQ, _304, 127LL)){
            _304 = NOVALUE;
            goto L6; // [70] 81
        }
        _304 = NOVALUE;

        /** types.e:1144				return 0*/
        DeRef(_x_813);
        return 0LL;
L6: 

        /** types.e:1146		end for*/
        _i_818 = _i_818 + 1LL;
        goto L2; // [83] 28
L3: 
        ;
    }

    /** types.e:1147		return 1*/
    DeRef(_x_813);
    return 1LL;
    ;
}


object _9string(object _x_832)
{
    object _314 = NOVALUE;
    object _312 = NOVALUE;
    object _310 = NOVALUE;
    object _309 = NOVALUE;
    object _308 = NOVALUE;
    object _306 = NOVALUE;
    object _0, _1, _2;
    

    /** types.e:1171		if not sequence(x) then*/
    _306 = IS_SEQUENCE(_x_832);
    if (_306 != 0)
    goto L1; // [6] 16
    _306 = NOVALUE;

    /** types.e:1172			return 0*/
    DeRef(_x_832);
    return 0LL;
L1: 

    /** types.e:1175		for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_832)){
            _308 = SEQ_PTR(_x_832)->length;
    }
    else {
        _308 = 1;
    }
    {
        object _i_837;
        _i_837 = 1LL;
L2: 
        if (_i_837 > _308){
            goto L3; // [21] 88
        }

        /** types.e:1176			if not integer(x[i]) then*/
        _2 = (object)SEQ_PTR(_x_832);
        _309 = (object)*(((s1_ptr)_2)->base + _i_837);
        if (IS_ATOM_INT(_309))
        _310 = 1;
        else if (IS_ATOM_DBL(_309))
        _310 = IS_ATOM_INT(DoubleToInt(_309));
        else
        _310 = 0;
        _309 = NOVALUE;
        if (_310 != 0)
        goto L4; // [37] 47
        _310 = NOVALUE;

        /** types.e:1177				return 0*/
        DeRef(_x_832);
        return 0LL;
L4: 

        /** types.e:1179			if x[i] < 0 then*/
        _2 = (object)SEQ_PTR(_x_832);
        _312 = (object)*(((s1_ptr)_2)->base + _i_837);
        if (binary_op_a(GREATEREQ, _312, 0LL)){
            _312 = NOVALUE;
            goto L5; // [53] 64
        }
        _312 = NOVALUE;

        /** types.e:1180				return 0*/
        DeRef(_x_832);
        return 0LL;
L5: 

        /** types.e:1182			if x[i] > 255 then*/
        _2 = (object)SEQ_PTR(_x_832);
        _314 = (object)*(((s1_ptr)_2)->base + _i_837);
        if (binary_op_a(LESSEQ, _314, 255LL)){
            _314 = NOVALUE;
            goto L6; // [70] 81
        }
        _314 = NOVALUE;

        /** types.e:1183				return 0*/
        DeRef(_x_832);
        return 0LL;
L6: 

        /** types.e:1185		end for*/
        _i_837 = _i_837 + 1LL;
        goto L2; // [83] 28
L3: 
        ;
    }

    /** types.e:1186		return 1*/
    DeRef(_x_832);
    return 1LL;
    ;
}


object _9cstring(object _x_851)
{
    object _324 = NOVALUE;
    object _322 = NOVALUE;
    object _320 = NOVALUE;
    object _319 = NOVALUE;
    object _318 = NOVALUE;
    object _316 = NOVALUE;
    object _0, _1, _2;
    

    /** types.e:1210		if not sequence(x) then*/
    _316 = 1;
    if (_316 != 0)
    goto L1; // [6] 16
    _316 = NOVALUE;

    /** types.e:1211			return 0*/
    DeRefDS(_x_851);
    return 0LL;
L1: 

    /** types.e:1214		for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_851)){
            _318 = SEQ_PTR(_x_851)->length;
    }
    else {
        _318 = 1;
    }
    {
        object _i_856;
        _i_856 = 1LL;
L2: 
        if (_i_856 > _318){
            goto L3; // [21] 88
        }

        /** types.e:1215			if not integer(x[i]) then*/
        _2 = (object)SEQ_PTR(_x_851);
        _319 = (object)*(((s1_ptr)_2)->base + _i_856);
        if (IS_ATOM_INT(_319))
        _320 = 1;
        else if (IS_ATOM_DBL(_319))
        _320 = IS_ATOM_INT(DoubleToInt(_319));
        else
        _320 = 0;
        _319 = NOVALUE;
        if (_320 != 0)
        goto L4; // [37] 47
        _320 = NOVALUE;

        /** types.e:1216				return 0*/
        DeRef(_x_851);
        return 0LL;
L4: 

        /** types.e:1218			if x[i] <= 0 then*/
        _2 = (object)SEQ_PTR(_x_851);
        _322 = (object)*(((s1_ptr)_2)->base + _i_856);
        if (binary_op_a(GREATER, _322, 0LL)){
            _322 = NOVALUE;
            goto L5; // [53] 64
        }
        _322 = NOVALUE;

        /** types.e:1219				return 0*/
        DeRef(_x_851);
        return 0LL;
L5: 

        /** types.e:1221			if x[i] > 255 then*/
        _2 = (object)SEQ_PTR(_x_851);
        _324 = (object)*(((s1_ptr)_2)->base + _i_856);
        if (binary_op_a(LESSEQ, _324, 255LL)){
            _324 = NOVALUE;
            goto L6; // [70] 81
        }
        _324 = NOVALUE;

        /** types.e:1222				return 0*/
        DeRef(_x_851);
        return 0LL;
L6: 

        /** types.e:1224		end for*/
        _i_856 = _i_856 + 1LL;
        goto L2; // [83] 28
L3: 
        ;
    }

    /** types.e:1225		return 1*/
    DeRef(_x_851);
    return 1LL;
    ;
}



// 0x6728D6F3
