// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _31get_text(object _MsgNum_18746, object _LocalQuals_18747, object _DBBase_18748)
{
    object _db_res_18750 = NOVALUE;
    object _lMsgText_18751 = NOVALUE;
    object _dbname_18752 = NOVALUE;
    object _10462 = NOVALUE;
    object _10460 = NOVALUE;
    object _10458 = NOVALUE;
    object _10457 = NOVALUE;
    object _10456 = NOVALUE;
    object _10454 = NOVALUE;
    object _10453 = NOVALUE;
    object _10452 = NOVALUE;
    object _10446 = NOVALUE;
    object _10445 = NOVALUE;
    object _10444 = NOVALUE;
    object _10437 = NOVALUE;
    object _10434 = NOVALUE;
    object _10432 = NOVALUE;
    object _10430 = NOVALUE;
    object _10429 = NOVALUE;
    object _10428 = NOVALUE;
    object _10427 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_MsgNum_18746)) {
        _1 = (object)(DBL_PTR(_MsgNum_18746)->dbl);
        DeRefDS(_MsgNum_18746);
        _MsgNum_18746 = _1;
    }

    /** locale.e:798		db_res = -1*/
    _db_res_18750 = -1LL;

    /** locale.e:799		lMsgText = 0*/
    DeRef(_lMsgText_18751);
    _lMsgText_18751 = 0LL;

    /** locale.e:801		if string(LocalQuals) and length(LocalQuals) > 0 then*/
    RefDS(_LocalQuals_18747);
    _10427 = _9string(_LocalQuals_18747);
    if (IS_ATOM_INT(_10427)) {
        if (_10427 == 0) {
            goto L1; // [23] 45
        }
    }
    else {
        if (DBL_PTR(_10427)->dbl == 0.0) {
            goto L1; // [23] 45
        }
    }
    if (IS_SEQUENCE(_LocalQuals_18747)){
            _10429 = SEQ_PTR(_LocalQuals_18747)->length;
    }
    else {
        _10429 = 1;
    }
    _10430 = (_10429 > 0LL);
    _10429 = NOVALUE;
    if (_10430 == 0)
    {
        DeRef(_10430);
        _10430 = NOVALUE;
        goto L1; // [35] 45
    }
    else{
        DeRef(_10430);
        _10430 = NOVALUE;
    }

    /** locale.e:802			LocalQuals = {LocalQuals}*/
    _0 = _LocalQuals_18747;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_LocalQuals_18747);
    ((intptr_t*)_2)[1] = _LocalQuals_18747;
    _LocalQuals_18747 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1: 

    /** locale.e:804		for i = 1 to length(LocalQuals) do*/
    if (IS_SEQUENCE(_LocalQuals_18747)){
            _10432 = SEQ_PTR(_LocalQuals_18747)->length;
    }
    else {
        _10432 = 1;
    }
    {
        object _i_18761;
        _i_18761 = 1LL;
L2: 
        if (_i_18761 > _10432){
            goto L3; // [50] 136
        }

        /** locale.e:805			dbname = DBBase & "_" & LocalQuals[i] & ".edb"*/
        _2 = (object)SEQ_PTR(_LocalQuals_18747);
        _10434 = (object)*(((s1_ptr)_2)->base + _i_18761);
        {
            object concat_list[4];

            concat_list[0] = _10435;
            concat_list[1] = _10434;
            concat_list[2] = _10433;
            concat_list[3] = _DBBase_18748;
            Concat_N((object_ptr)&_dbname_18752, concat_list, 4);
        }
        _10434 = NOVALUE;

        /** locale.e:806			db_res = eds:db_select( filesys:locate_file( dbname ), eds:DB_LOCK_READ_ONLY)*/
        RefDS(_dbname_18752);
        RefDS(_5);
        RefDS(_5);
        _10437 = _15locate_file(_dbname_18752, _5, _5);
        _db_res_18750 = _41db_select(_10437, 3LL);
        _10437 = NOVALUE;
        if (!IS_ATOM_INT(_db_res_18750)) {
            _1 = (object)(DBL_PTR(_db_res_18750)->dbl);
            DeRefDS(_db_res_18750);
            _db_res_18750 = _1;
        }

        /** locale.e:807			if db_res = eds:DB_OK then*/
        if (_db_res_18750 != 0LL)
        goto L4; // [87] 129

        /** locale.e:808				db_res = eds:db_select_table("1")*/
        RefDS(_10440);
        _db_res_18750 = _41db_select_table(_10440);
        if (!IS_ATOM_INT(_db_res_18750)) {
            _1 = (object)(DBL_PTR(_db_res_18750)->dbl);
            DeRefDS(_db_res_18750);
            _db_res_18750 = _1;
        }

        /** locale.e:809				if db_res = eds:DB_OK then*/
        if (_db_res_18750 != 0LL)
        goto L5; // [101] 128

        /** locale.e:810					lMsgText = eds:db_fetch_record(MsgNum)*/
        RefDS(_41current_table_name_16042);
        _0 = _lMsgText_18751;
        _lMsgText_18751 = _41db_fetch_record(_MsgNum_18746, _41current_table_name_16042);
        DeRef(_0);

        /** locale.e:811					if sequence(lMsgText) then*/
        _10444 = IS_SEQUENCE(_lMsgText_18751);
        if (_10444 == 0)
        {
            _10444 = NOVALUE;
            goto L6; // [119] 127
        }
        else{
            _10444 = NOVALUE;
        }

        /** locale.e:812						exit*/
        goto L3; // [124] 136
L6: 
L5: 
L4: 

        /** locale.e:816		end for*/
        _i_18761 = _i_18761 + 1LL;
        goto L2; // [131] 57
L3: 
        ;
    }

    /** locale.e:819		if atom(lMsgText) then*/
    _10445 = IS_ATOM(_lMsgText_18751);
    if (_10445 == 0)
    {
        _10445 = NOVALUE;
        goto L7; // [141] 281
    }
    else{
        _10445 = NOVALUE;
    }

    /** locale.e:820			dbname = filesys:locate_file( DBBase & ".edb" )*/
    Concat((object_ptr)&_10446, _DBBase_18748, _10435);
    RefDS(_5);
    RefDS(_5);
    _0 = _dbname_18752;
    _dbname_18752 = _15locate_file(_10446, _5, _5);
    DeRef(_0);
    _10446 = NOVALUE;

    /** locale.e:821			db_res = eds:db_select(	dbname, DB_LOCK_READ_ONLY)*/
    RefDS(_dbname_18752);
    _db_res_18750 = _41db_select(_dbname_18752, 3LL);
    if (!IS_ATOM_INT(_db_res_18750)) {
        _1 = (object)(DBL_PTR(_db_res_18750)->dbl);
        DeRefDS(_db_res_18750);
        _db_res_18750 = _1;
    }

    /** locale.e:822			if db_res = eds:DB_OK then*/
    if (_db_res_18750 != 0LL)
    goto L8; // [171] 280

    /** locale.e:823				db_res = eds:db_select_table("1")*/
    RefDS(_10440);
    _db_res_18750 = _41db_select_table(_10440);
    if (!IS_ATOM_INT(_db_res_18750)) {
        _1 = (object)(DBL_PTR(_db_res_18750)->dbl);
        DeRefDS(_db_res_18750);
        _db_res_18750 = _1;
    }

    /** locale.e:824				if db_res = eds:DB_OK then*/
    if (_db_res_18750 != 0LL)
    goto L9; // [185] 279

    /** locale.e:825					for i = 1 to length(LocalQuals) do*/
    if (IS_SEQUENCE(_LocalQuals_18747)){
            _10452 = SEQ_PTR(_LocalQuals_18747)->length;
    }
    else {
        _10452 = 1;
    }
    {
        object _i_18790;
        _i_18790 = 1LL;
LA: 
        if (_i_18790 > _10452){
            goto LB; // [194] 238
        }

        /** locale.e:826						lMsgText = eds:db_fetch_record({LocalQuals[i],MsgNum})*/
        _2 = (object)SEQ_PTR(_LocalQuals_18747);
        _10453 = (object)*(((s1_ptr)_2)->base + _i_18790);
        Ref(_10453);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _10453;
        ((intptr_t *)_2)[2] = _MsgNum_18746;
        _10454 = MAKE_SEQ(_1);
        _10453 = NOVALUE;
        RefDS(_41current_table_name_16042);
        _0 = _lMsgText_18751;
        _lMsgText_18751 = _41db_fetch_record(_10454, _41current_table_name_16042);
        DeRef(_0);
        _10454 = NOVALUE;

        /** locale.e:827						if sequence(lMsgText) then*/
        _10456 = IS_SEQUENCE(_lMsgText_18751);
        if (_10456 == 0)
        {
            _10456 = NOVALUE;
            goto LC; // [223] 231
        }
        else{
            _10456 = NOVALUE;
        }

        /** locale.e:828							exit*/
        goto LB; // [228] 238
LC: 

        /** locale.e:830					end for*/
        _i_18790 = _i_18790 + 1LL;
        goto LA; // [233] 201
LB: 
        ;
    }

    /** locale.e:831					if atom(lMsgText) then*/
    _10457 = IS_ATOM(_lMsgText_18751);
    if (_10457 == 0)
    {
        _10457 = NOVALUE;
        goto LD; // [243] 260
    }
    else{
        _10457 = NOVALUE;
    }

    /** locale.e:832						lMsgText = eds:db_fetch_record({"",MsgNum})*/
    RefDS(_5);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _5;
    ((intptr_t *)_2)[2] = _MsgNum_18746;
    _10458 = MAKE_SEQ(_1);
    RefDS(_41current_table_name_16042);
    _0 = _lMsgText_18751;
    _lMsgText_18751 = _41db_fetch_record(_10458, _41current_table_name_16042);
    DeRef(_0);
    _10458 = NOVALUE;
LD: 

    /** locale.e:834					if atom(lMsgText) then*/
    _10460 = IS_ATOM(_lMsgText_18751);
    if (_10460 == 0)
    {
        _10460 = NOVALUE;
        goto LE; // [265] 278
    }
    else{
        _10460 = NOVALUE;
    }

    /** locale.e:835						lMsgText = eds:db_fetch_record(MsgNum)*/
    RefDS(_41current_table_name_16042);
    _0 = _lMsgText_18751;
    _lMsgText_18751 = _41db_fetch_record(_MsgNum_18746, _41current_table_name_16042);
    DeRef(_0);
LE: 
L9: 
L8: 
L7: 

    /** locale.e:840		if atom(lMsgText) then*/
    _10462 = IS_ATOM(_lMsgText_18751);
    if (_10462 == 0)
    {
        _10462 = NOVALUE;
        goto LF; // [286] 298
    }
    else{
        _10462 = NOVALUE;
    }

    /** locale.e:841			return 0*/
    DeRefDS(_LocalQuals_18747);
    DeRefDS(_DBBase_18748);
    DeRef(_lMsgText_18751);
    DeRef(_dbname_18752);
    DeRef(_10427);
    _10427 = NOVALUE;
    return 0LL;
    goto L10; // [295] 305
LF: 

    /** locale.e:843			return lMsgText*/
    DeRefDS(_LocalQuals_18747);
    DeRefDS(_DBBase_18748);
    DeRef(_dbname_18752);
    DeRef(_10427);
    _10427 = NOVALUE;
    return _lMsgText_18751;
L10: 
    ;
}



// 0xBBEE39A5
