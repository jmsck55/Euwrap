// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _54c_putc(object _c_47070)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_c_47070)) {
        _1 = (object)(DBL_PTR(_c_47070)->dbl);
        DeRefDS(_c_47070);
        _c_47070 = _1;
    }

    /** c_out.e:62		if emit_c_output then*/
    if (_54emit_c_output_47057 == 0)
    {
        goto L1; // [7] 23
    }
    else{
    }

    /** c_out.e:63			puts(c_code, c)*/
    EPuts(_54c_code_47060, _c_47070); // DJP 

    /** c_out.e:64			update_checksum( c )*/
    _55update_checksum(_c_47070);
L1: 

    /** c_out.e:66	end procedure*/
    return;
    ;
}


void _54c_hputs(object _c_source_47075)
{
    object _0, _1, _2;
    

    /** c_out.e:71		if emit_c_output then*/
    if (_54emit_c_output_47057 == 0)
    {
        goto L1; // [7] 18
    }
    else{
    }

    /** c_out.e:72			puts(c_h, c_source)    */
    EPuts(_54c_h_47061, _c_source_47075); // DJP 
L1: 

    /** c_out.e:74	end procedure*/
    DeRefDS(_c_source_47075);
    return;
    ;
}


void _54c_puts(object _c_source_47079)
{
    object _0, _1, _2;
    

    /** c_out.e:79		if emit_c_output then*/
    if (_54emit_c_output_47057 == 0)
    {
        goto L1; // [7] 23
    }
    else{
    }

    /** c_out.e:80			puts(c_code, c_source)*/
    EPuts(_54c_code_47060, _c_source_47079); // DJP 

    /** c_out.e:81			update_checksum( c_source )*/
    RefDS(_c_source_47079);
    _55update_checksum(_c_source_47079);
L1: 

    /** c_out.e:83	end procedure*/
    DeRefDS(_c_source_47079);
    return;
    ;
}


void _54c_hprintf(object _format_47084, object _value_47085)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_value_47085)) {
        _1 = (object)(DBL_PTR(_value_47085)->dbl);
        DeRefDS(_value_47085);
        _value_47085 = _1;
    }

    /** c_out.e:88		if emit_c_output then*/
    if (_54emit_c_output_47057 == 0)
    {
        goto L1; // [9] 21
    }
    else{
    }

    /** c_out.e:89			printf(c_h, format, value)*/
    EPrintf(_54c_h_47061, _format_47084, _value_47085);
L1: 

    /** c_out.e:91	end procedure*/
    DeRefDSi(_format_47084);
    return;
    ;
}


void _54c_printf(object _format_47089, object _value_47090)
{
    object _text_47092 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:96		if emit_c_output then*/
    if (_54emit_c_output_47057 == 0)
    {
        goto L1; // [7] 29
    }
    else{
    }

    /** c_out.e:97			sequence text = sprintf( format, value )*/
    DeRefi(_text_47092);
    _text_47092 = EPrintf(-9999999, _format_47089, _value_47090);

    /** c_out.e:98			puts(c_code, text)*/
    EPuts(_54c_code_47060, _text_47092); // DJP 

    /** c_out.e:99			update_checksum( text )*/
    RefDS(_text_47092);
    _55update_checksum(_text_47092);
L1: 
    DeRefi(_text_47092);
    _text_47092 = NOVALUE;

    /** c_out.e:101	end procedure*/
    DeRefDSi(_format_47089);
    DeRef(_value_47090);
    return;
    ;
}


void _54c_printf8(object _value_47103)
{
    object _buff_47104 = NOVALUE;
    object _neg_47105 = NOVALUE;
    object _p_47106 = NOVALUE;
    object _24508 = NOVALUE;
    object _24507 = NOVALUE;
    object _24505 = NOVALUE;
    object _24503 = NOVALUE;
    object _24501 = NOVALUE;
    object _24499 = NOVALUE;
    object _24497 = NOVALUE;
    object _24495 = NOVALUE;
    object _24493 = NOVALUE;
    object _24490 = NOVALUE;
    object _24488 = NOVALUE;
    object _24486 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:115		if emit_c_output then*/
    if (_54emit_c_output_47057 == 0)
    {
        goto L1; // [5] 217
    }
    else{
    }

    /** c_out.e:116			neg = 0*/
    _neg_47105 = 0LL;

    /** c_out.e:117			buff = sprintf("%.20eL", value)*/
    DeRef(_buff_47104);
    _buff_47104 = EPrintf(-9999999, _24484, _value_47103);

    /** c_out.e:118			if length(buff) < 10 then*/
    if (IS_SEQUENCE(_buff_47104)){
            _24486 = SEQ_PTR(_buff_47104)->length;
    }
    else {
        _24486 = 1;
    }
    if (_24486 >= 10LL)
    goto L2; // [24] 209

    /** c_out.e:120				p = 1*/
    _p_47106 = 1LL;

    /** c_out.e:121				while p <= length(buff) do*/
L3: 
    if (IS_SEQUENCE(_buff_47104)){
            _24488 = SEQ_PTR(_buff_47104)->length;
    }
    else {
        _24488 = 1;
    }
    if (_p_47106 > _24488)
    goto L4; // [41] 208

    /** c_out.e:122					if buff[p] = '-' then*/
    _2 = (object)SEQ_PTR(_buff_47104);
    _24490 = (object)*(((s1_ptr)_2)->base + _p_47106);
    if (binary_op_a(NOTEQ, _24490, 45LL)){
        _24490 = NOVALUE;
        goto L5; // [51] 63
    }
    _24490 = NOVALUE;

    /** c_out.e:123						neg = 1*/
    _neg_47105 = 1LL;
    goto L6; // [60] 197
L5: 

    /** c_out.e:125					elsif buff[p] = 'i' or buff[p] = 'I' then*/
    _2 = (object)SEQ_PTR(_buff_47104);
    _24493 = (object)*(((s1_ptr)_2)->base + _p_47106);
    if (IS_ATOM_INT(_24493)) {
        _24495 = (_24493 == 105LL);
    }
    else {
        _24495 = binary_op(EQUALS, _24493, 105LL);
    }
    _24493 = NOVALUE;
    if (IS_ATOM_INT(_24495)) {
        if (_24495 != 0) {
            goto L7; // [73] 90
        }
    }
    else {
        if (DBL_PTR(_24495)->dbl != 0.0) {
            goto L7; // [73] 90
        }
    }
    _2 = (object)SEQ_PTR(_buff_47104);
    _24497 = (object)*(((s1_ptr)_2)->base + _p_47106);
    if (IS_ATOM_INT(_24497)) {
        _24499 = (_24497 == 73LL);
    }
    else {
        _24499 = binary_op(EQUALS, _24497, 73LL);
    }
    _24497 = NOVALUE;
    if (_24499 == 0) {
        DeRef(_24499);
        _24499 = NOVALUE;
        goto L8; // [86] 114
    }
    else {
        if (!IS_ATOM_INT(_24499) && DBL_PTR(_24499)->dbl == 0.0){
            DeRef(_24499);
            _24499 = NOVALUE;
            goto L8; // [86] 114
        }
        DeRef(_24499);
        _24499 = NOVALUE;
    }
    DeRef(_24499);
    _24499 = NOVALUE;
L7: 

    /** c_out.e:127						buff = CREATE_INF*/
    RefDS(_54CREATE_INF_47095);
    DeRef(_buff_47104);
    _buff_47104 = _54CREATE_INF_47095;

    /** c_out.e:128						if neg then*/
    if (_neg_47105 == 0)
    {
        goto L4; // [97] 208
    }
    else{
    }

    /** c_out.e:129							buff = prepend(buff, '-')*/
    Prepend(&_buff_47104, _buff_47104, 45LL);

    /** c_out.e:131						exit*/
    goto L4; // [109] 208
    goto L6; // [111] 197
L8: 

    /** c_out.e:133					elsif buff[p] = 'n' or buff[p] = 'N' then*/
    _2 = (object)SEQ_PTR(_buff_47104);
    _24501 = (object)*(((s1_ptr)_2)->base + _p_47106);
    if (IS_ATOM_INT(_24501)) {
        _24503 = (_24501 == 110LL);
    }
    else {
        _24503 = binary_op(EQUALS, _24501, 110LL);
    }
    _24501 = NOVALUE;
    if (IS_ATOM_INT(_24503)) {
        if (_24503 != 0) {
            goto L9; // [124] 141
        }
    }
    else {
        if (DBL_PTR(_24503)->dbl != 0.0) {
            goto L9; // [124] 141
        }
    }
    _2 = (object)SEQ_PTR(_buff_47104);
    _24505 = (object)*(((s1_ptr)_2)->base + _p_47106);
    if (IS_ATOM_INT(_24505)) {
        _24507 = (_24505 == 78LL);
    }
    else {
        _24507 = binary_op(EQUALS, _24505, 78LL);
    }
    _24505 = NOVALUE;
    if (_24507 == 0) {
        DeRef(_24507);
        _24507 = NOVALUE;
        goto LA; // [137] 196
    }
    else {
        if (!IS_ATOM_INT(_24507) && DBL_PTR(_24507)->dbl == 0.0){
            DeRef(_24507);
            _24507 = NOVALUE;
            goto LA; // [137] 196
        }
        DeRef(_24507);
        _24507 = NOVALUE;
    }
    DeRef(_24507);
    _24507 = NOVALUE;
L9: 

    /** c_out.e:135						ifdef UNIX then*/

    /** c_out.e:141							if sequence(wat_path) then*/
    _24508 = 0;
    if (_24508 == 0)
    {
        _24508 = NOVALUE;
        goto LB; // [150] 173
    }
    else{
        _24508 = NOVALUE;
    }

    /** c_out.e:142								buff = CREATE_NAN2*/
    RefDS(_54CREATE_NAN2_47099);
    DeRef(_buff_47104);
    _buff_47104 = _54CREATE_NAN2_47099;

    /** c_out.e:143								if not neg then*/
    if (_neg_47105 != 0)
    goto L4; // [160] 208

    /** c_out.e:144									buff = prepend(buff, '-')*/
    Prepend(&_buff_47104, _buff_47104, 45LL);
    goto L4; // [170] 208
LB: 

    /** c_out.e:148								buff = CREATE_NAN1*/
    RefDS(_54CREATE_NAN1_47097);
    DeRef(_buff_47104);
    _buff_47104 = _54CREATE_NAN1_47097;

    /** c_out.e:149								if neg then*/
    if (_neg_47105 == 0)
    {
        goto L4; // [180] 208
    }
    else{
    }

    /** c_out.e:150									buff = prepend(buff, '-')*/
    Prepend(&_buff_47104, _buff_47104, 45LL);

    /** c_out.e:153							exit*/
    goto L4; // [193] 208
LA: 
L6: 

    /** c_out.e:156					p += 1*/
    _p_47106 = _p_47106 + 1;

    /** c_out.e:157				end while*/
    goto L3; // [205] 38
L4: 
L2: 

    /** c_out.e:159			puts(c_code, buff)*/
    EPuts(_54c_code_47060, _buff_47104); // DJP 
L1: 

    /** c_out.e:161	end procedure*/
    DeRef(_value_47103);
    DeRef(_buff_47104);
    DeRef(_24495);
    _24495 = NOVALUE;
    DeRef(_24503);
    _24503 = NOVALUE;
    return;
    ;
}


void _54adjust_indent_before(object _stmt_47154)
{
    object _i_47155 = NOVALUE;
    object _lb_47157 = NOVALUE;
    object _rb_47158 = NOVALUE;
    object _24527 = NOVALUE;
    object _24525 = NOVALUE;
    object _24523 = NOVALUE;
    object _24515 = NOVALUE;
    object _24514 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:177		lb = FALSE*/
    _lb_47157 = _9FALSE_439;

    /** c_out.e:178		rb = FALSE*/
    _rb_47158 = _9FALSE_439;

    /** c_out.e:180		for p = 1 to length(stmt) do*/
    if (IS_SEQUENCE(_stmt_47154)){
            _24514 = SEQ_PTR(_stmt_47154)->length;
    }
    else {
        _24514 = 1;
    }
    {
        object _p_47162;
        _p_47162 = 1LL;
L1: 
        if (_p_47162 > _24514){
            goto L2; // [22] 102
        }

        /** c_out.e:181			switch stmt[p] do*/
        _2 = (object)SEQ_PTR(_stmt_47154);
        _24515 = (object)*(((s1_ptr)_2)->base + _p_47162);
        if (IS_SEQUENCE(_24515) ){
            goto L3; // [35] 95
        }
        if(!IS_ATOM_INT(_24515)){
            if( (DBL_PTR(_24515)->dbl != (eudouble) ((object) DBL_PTR(_24515)->dbl) ) ){
                goto L3; // [35] 95
            }
            _0 = (object) DBL_PTR(_24515)->dbl;
        }
        else {
            _0 = _24515;
        };
        _24515 = NOVALUE;
        switch ( _0 ){ 

            /** c_out.e:182				case '\n' then*/
            case 10:

            /** c_out.e:183					exit*/
            goto L2; // [46] 102
            goto L3; // [48] 95

            /** c_out.e:185				case  '}' then*/
            case 125:

            /** c_out.e:186					rb = TRUE*/
            _rb_47158 = _9TRUE_441;

            /** c_out.e:187					if lb then*/
            if (_lb_47157 == 0)
            {
                goto L3; // [63] 95
            }
            else{
            }

            /** c_out.e:188						exit*/
            goto L2; // [68] 102
            goto L3; // [71] 95

            /** c_out.e:191				case '{' then*/
            case 123:

            /** c_out.e:192					lb = TRUE*/
            _lb_47157 = _9TRUE_441;

            /** c_out.e:193					if rb then */
            if (_rb_47158 == 0)
            {
                goto L4; // [86] 94
            }
            else{
            }

            /** c_out.e:194						exit*/
            goto L2; // [91] 102
L4: 
        ;}L3: 

        /** c_out.e:198		end for*/
        _p_47162 = _p_47162 + 1LL;
        goto L1; // [97] 29
L2: 
        ;
    }

    /** c_out.e:200		if rb then*/
    if (_rb_47158 == 0)
    {
        goto L5; // [104] 122
    }
    else{
    }

    /** c_out.e:201			if not lb then*/
    if (_lb_47157 != 0)
    goto L6; // [109] 121

    /** c_out.e:202				indent -= 4*/
    _54indent_47148 = _54indent_47148 - 4LL;
L6: 
L5: 

    /** c_out.e:206		i = indent + temp_indent*/
    _i_47155 = _54indent_47148 + _54temp_indent_47149;

    /** c_out.e:207		while i >= length(big_blanks) do*/
L7: 
    if (IS_SEQUENCE(_54big_blanks_47150)){
            _24523 = SEQ_PTR(_54big_blanks_47150)->length;
    }
    else {
        _24523 = 1;
    }
    if (_i_47155 < _24523)
    goto L8; // [140] 163

    /** c_out.e:208			c_puts(big_blanks)*/
    RefDS(_54big_blanks_47150);
    _54c_puts(_54big_blanks_47150);

    /** c_out.e:209			i -= length(big_blanks)*/
    if (IS_SEQUENCE(_54big_blanks_47150)){
            _24525 = SEQ_PTR(_54big_blanks_47150)->length;
    }
    else {
        _24525 = 1;
    }
    _i_47155 = _i_47155 - _24525;
    _24525 = NOVALUE;

    /** c_out.e:210		end while*/
    goto L7; // [160] 137
L8: 

    /** c_out.e:212		c_puts(big_blanks[1..i])*/
    rhs_slice_target = (object_ptr)&_24527;
    RHS_Slice(_54big_blanks_47150, 1LL, _i_47155);
    _54c_puts(_24527);
    _24527 = NOVALUE;

    /** c_out.e:214		temp_indent = 0    */
    _54temp_indent_47149 = 0LL;

    /** c_out.e:215	end procedure*/
    DeRefDS(_stmt_47154);
    return;
    ;
}


void _54adjust_indent_after(object _stmt_47189)
{
    object _24548 = NOVALUE;
    object _24547 = NOVALUE;
    object _24545 = NOVALUE;
    object _24543 = NOVALUE;
    object _24542 = NOVALUE;
    object _24539 = NOVALUE;
    object _24537 = NOVALUE;
    object _24536 = NOVALUE;
    object _24533 = NOVALUE;
    object _24529 = NOVALUE;
    object _24528 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:221		for p = 1 to length(stmt) do*/
    if (IS_SEQUENCE(_stmt_47189)){
            _24528 = SEQ_PTR(_stmt_47189)->length;
    }
    else {
        _24528 = 1;
    }
    {
        object _p_47191;
        _p_47191 = 1LL;
L1: 
        if (_p_47191 > _24528){
            goto L2; // [8] 61
        }

        /** c_out.e:222			switch stmt[p] do*/
        _2 = (object)SEQ_PTR(_stmt_47189);
        _24529 = (object)*(((s1_ptr)_2)->base + _p_47191);
        if (IS_SEQUENCE(_24529) ){
            goto L3; // [21] 54
        }
        if(!IS_ATOM_INT(_24529)){
            if( (DBL_PTR(_24529)->dbl != (eudouble) ((object) DBL_PTR(_24529)->dbl) ) ){
                goto L3; // [21] 54
            }
            _0 = (object) DBL_PTR(_24529)->dbl;
        }
        else {
            _0 = _24529;
        };
        _24529 = NOVALUE;
        switch ( _0 ){ 

            /** c_out.e:223				case '\n' then*/
            case 10:

            /** c_out.e:224					exit*/
            goto L2; // [32] 61
            goto L3; // [34] 54

            /** c_out.e:226				case '{' then*/
            case 123:

            /** c_out.e:227					indent += 4*/
            _54indent_47148 = _54indent_47148 + 4LL;

            /** c_out.e:228					return*/
            DeRefDS(_stmt_47189);
            return;
        ;}L3: 

        /** c_out.e:230		end for*/
        _p_47191 = _p_47191 + 1LL;
        goto L1; // [56] 15
L2: 
        ;
    }

    /** c_out.e:232		if length(stmt) < 3 then*/
    if (IS_SEQUENCE(_stmt_47189)){
            _24533 = SEQ_PTR(_stmt_47189)->length;
    }
    else {
        _24533 = 1;
    }
    if (_24533 >= 3LL)
    goto L4; // [66] 76

    /** c_out.e:233			return*/
    DeRefDS(_stmt_47189);
    return;
L4: 

    /** c_out.e:236		if not equal("if ", stmt[1..3]) then*/
    rhs_slice_target = (object_ptr)&_24536;
    RHS_Slice(_stmt_47189, 1LL, 3LL);
    if (_24535 == _24536)
    _24537 = 1;
    else if (IS_ATOM_INT(_24535) && IS_ATOM_INT(_24536))
    _24537 = 0;
    else
    _24537 = (compare(_24535, _24536) == 0);
    DeRefDS(_24536);
    _24536 = NOVALUE;
    if (_24537 != 0)
    goto L5; // [87] 96
    _24537 = NOVALUE;

    /** c_out.e:237			return*/
    DeRefDS(_stmt_47189);
    return;
L5: 

    /** c_out.e:240		if length(stmt) < 5 then*/
    if (IS_SEQUENCE(_stmt_47189)){
            _24539 = SEQ_PTR(_stmt_47189)->length;
    }
    else {
        _24539 = 1;
    }
    if (_24539 >= 5LL)
    goto L6; // [101] 111

    /** c_out.e:241			return*/
    DeRefDS(_stmt_47189);
    return;
L6: 

    /** c_out.e:244		if not equal("else", stmt[1..4]) then*/
    rhs_slice_target = (object_ptr)&_24542;
    RHS_Slice(_stmt_47189, 1LL, 4LL);
    if (_24541 == _24542)
    _24543 = 1;
    else if (IS_ATOM_INT(_24541) && IS_ATOM_INT(_24542))
    _24543 = 0;
    else
    _24543 = (compare(_24541, _24542) == 0);
    DeRefDS(_24542);
    _24542 = NOVALUE;
    if (_24543 != 0)
    goto L7; // [122] 131
    _24543 = NOVALUE;

    /** c_out.e:245			return*/
    DeRefDS(_stmt_47189);
    return;
L7: 

    /** c_out.e:248		if not find(stmt[5], {" \n"}) then*/
    _2 = (object)SEQ_PTR(_stmt_47189);
    _24545 = (object)*(((s1_ptr)_2)->base + 5LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_24546);
    ((intptr_t*)_2)[1] = _24546;
    _24547 = MAKE_SEQ(_1);
    _24548 = find_from(_24545, _24547, 1LL);
    _24545 = NOVALUE;
    DeRefDS(_24547);
    _24547 = NOVALUE;
    if (_24548 != 0)
    goto L8; // [146] 155
    _24548 = NOVALUE;

    /** c_out.e:249			return*/
    DeRefDS(_stmt_47189);
    return;
L8: 

    /** c_out.e:252		temp_indent = 4*/
    _54temp_indent_47149 = 4LL;

    /** c_out.e:254	end procedure*/
    DeRefDS(_stmt_47189);
    return;
    ;
}



// 0x859F17EC
