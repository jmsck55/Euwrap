// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _14find_all(object _needle_1861, object _haystack_1862, object _start_1863)
{
    object _kx_1864 = NOVALUE;
    object _805 = NOVALUE;
    object _804 = NOVALUE;
    object _0, _1, _2;
    

    /** search.e:292		integer kx = 0*/
    _kx_1864 = 0LL;

    /** search.e:293		while start with entry do*/
    goto L1; // [12] 39
L2: 
    if (_start_1863 == 0)
    {
        goto L3; // [15] 51
    }
    else{
    }

    /** search.e:294			kx += 1*/
    _kx_1864 = _kx_1864 + 1;

    /** search.e:295			haystack[kx] = start*/
    _2 = (object)SEQ_PTR(_haystack_1862);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _haystack_1862 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _kx_1864);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _start_1863;
    DeRef(_1);

    /** search.e:296			start += 1*/
    _start_1863 = _start_1863 + 1;

    /** search.e:297		entry*/
L1: 

    /** search.e:298			start = find(needle, haystack, start)*/
    _start_1863 = find_from(_needle_1861, _haystack_1862, _start_1863);

    /** search.e:299		end while*/
    goto L2; // [48] 15
L3: 

    /** search.e:301		haystack = remove( haystack, kx+1, length( haystack ) )*/
    _804 = _kx_1864 + 1;
    if (_804 > MAXINT){
        _804 = NewDouble((eudouble)_804);
    }
    if (IS_SEQUENCE(_haystack_1862)){
            _805 = SEQ_PTR(_haystack_1862)->length;
    }
    else {
        _805 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_haystack_1862);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_804)) ? _804 : (object)(DBL_PTR(_804)->dbl);
        int stop = (IS_ATOM_INT(_805)) ? _805 : (object)(DBL_PTR(_805)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_haystack_1862), start, &_haystack_1862 );
            }
            else Tail(SEQ_PTR(_haystack_1862), stop+1, &_haystack_1862);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_haystack_1862), start, &_haystack_1862);
        }
        else {
            assign_slice_seq = &assign_space;
            _haystack_1862 = Remove_elements(start, stop, (SEQ_PTR(_haystack_1862)->ref == 1));
        }
    }
    DeRef(_804);
    _804 = NOVALUE;
    _805 = NOVALUE;

    /** search.e:302		return haystack*/
    return _haystack_1862;
    ;
}


object _14rfind(object _needle_1979, object _haystack_1980, object _start_1981)
{
    object _len_1983 = NOVALUE;
    object _866 = NOVALUE;
    object _865 = NOVALUE;
    object _862 = NOVALUE;
    object _861 = NOVALUE;
    object _859 = NOVALUE;
    object _0, _1, _2;
    

    /** search.e:550		integer len = length(haystack)*/
    if (IS_SEQUENCE(_haystack_1980)){
            _len_1983 = SEQ_PTR(_haystack_1980)->length;
    }
    else {
        _len_1983 = 1;
    }

    /** search.e:552		if start = 0 then start = len end if*/
    if (_start_1981 != 0LL)
    goto L1; // [12] 20
    _start_1981 = _len_1983;
L1: 

    /** search.e:553		if (start > len) or (len + start < 1) then*/
    _859 = (_start_1981 > _len_1983);
    if (_859 != 0) {
        goto L2; // [26] 43
    }
    _861 = _len_1983 + _start_1981;
    if ((object)((uintptr_t)_861 + (uintptr_t)HIGH_BITS) >= 0){
        _861 = NewDouble((eudouble)_861);
    }
    if (IS_ATOM_INT(_861)) {
        _862 = (_861 < 1LL);
    }
    else {
        _862 = (DBL_PTR(_861)->dbl < (eudouble)1LL);
    }
    DeRef(_861);
    _861 = NOVALUE;
    if (_862 == 0)
    {
        DeRef(_862);
        _862 = NOVALUE;
        goto L3; // [39] 50
    }
    else{
        DeRef(_862);
        _862 = NOVALUE;
    }
L2: 

    /** search.e:554			return 0*/
    DeRef(_needle_1979);
    DeRefDS(_haystack_1980);
    DeRef(_859);
    _859 = NOVALUE;
    return 0LL;
L3: 

    /** search.e:557		if start < 1 then*/
    if (_start_1981 >= 1LL)
    goto L4; // [52] 63

    /** search.e:558			start = len + start*/
    _start_1981 = _len_1983 + _start_1981;
L4: 

    /** search.e:561		for i = start to 1 by -1 do*/
    {
        object _i_1996;
        _i_1996 = _start_1981;
L5: 
        if (_i_1996 < 1LL){
            goto L6; // [65] 99
        }

        /** search.e:562			if equal(haystack[i], needle) then*/
        _2 = (object)SEQ_PTR(_haystack_1980);
        _865 = (object)*(((s1_ptr)_2)->base + _i_1996);
        if (_865 == _needle_1979)
        _866 = 1;
        else if (IS_ATOM_INT(_865) && IS_ATOM_INT(_needle_1979))
        _866 = 0;
        else
        _866 = (compare(_865, _needle_1979) == 0);
        _865 = NOVALUE;
        if (_866 == 0)
        {
            _866 = NOVALUE;
            goto L7; // [82] 92
        }
        else{
            _866 = NOVALUE;
        }

        /** search.e:563				return i*/
        DeRef(_needle_1979);
        DeRefDS(_haystack_1980);
        DeRef(_859);
        _859 = NOVALUE;
        return _i_1996;
L7: 

        /** search.e:565		end for*/
        _i_1996 = _i_1996 + -1LL;
        goto L5; // [94] 72
L6: 
        ;
    }

    /** search.e:567		return 0*/
    DeRef(_needle_1979);
    DeRefDS(_haystack_1980);
    DeRef(_859);
    _859 = NOVALUE;
    return 0LL;
    ;
}


object _14find_replace(object _needle_2002, object _haystack_2003, object _replacement_2004, object _max_2005)
{
    object _posn_2006 = NOVALUE;
    object _870 = NOVALUE;
    object _0, _1, _2;
    

    /** search.e:612		integer posn = 0*/
    _posn_2006 = 0LL;

    /** search.e:614		while posn != 0 entry do */
    goto L1; // [12] 45
L2: 
    if (_posn_2006 == 0LL)
    goto L3; // [15] 61

    /** search.e:615			haystack[posn] = replacement*/
    Ref(_replacement_2004);
    _2 = (object)SEQ_PTR(_haystack_2003);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _haystack_2003 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _posn_2006);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _replacement_2004;
    DeRef(_1);

    /** search.e:616			max -= 1*/
    _max_2005 = _max_2005 - 1LL;

    /** search.e:617			if max = 0 then*/
    if (_max_2005 != 0LL)
    goto L4; // [33] 42

    /** search.e:618				exit*/
    goto L3; // [39] 61
L4: 

    /** search.e:620		entry*/
L1: 

    /** search.e:621			posn = find(needle, haystack, posn + 1)*/
    _870 = _posn_2006 + 1;
    if (_870 > MAXINT){
        _870 = NewDouble((eudouble)_870);
    }
    _posn_2006 = find_from(_needle_2002, _haystack_2003, _870);
    DeRef(_870);
    _870 = NOVALUE;

    /** search.e:622		end while*/
    goto L2; // [58] 15
L3: 

    /** search.e:624		return haystack*/
    DeRef(_needle_2002);
    DeRefi(_replacement_2004);
    return _haystack_2003;
    ;
}


object _14match_replace(object _needle_2016, object _haystack_2017, object _replacement_2018, object _max_2019)
{
    object _posn_2020 = NOVALUE;
    object _needle_len_2021 = NOVALUE;
    object _replacement_len_2022 = NOVALUE;
    object _scan_from_2023 = NOVALUE;
    object _cnt_2024 = NOVALUE;
    object _882 = NOVALUE;
    object _879 = NOVALUE;
    object _877 = NOVALUE;
    object _875 = NOVALUE;
    object _0, _1, _2;
    

    /** search.e:692		if max < 0 then*/

    /** search.e:696		cnt = length(haystack)*/
    if (IS_SEQUENCE(_haystack_2017)){
            _cnt_2024 = SEQ_PTR(_haystack_2017)->length;
    }
    else {
        _cnt_2024 = 1;
    }

    /** search.e:697		if max != 0 then*/

    /** search.e:701		if atom(needle) then*/
    _875 = IS_ATOM(_needle_2016);
    if (_875 == 0)
    {
        _875 = NOVALUE;
        goto L1; // [40] 50
    }
    else{
        _875 = NOVALUE;
    }

    /** search.e:702			needle = {needle}*/
    _0 = _needle_2016;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_needle_2016);
    ((intptr_t*)_2)[1] = _needle_2016;
    _needle_2016 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** search.e:704		if atom(replacement) then*/
    _877 = IS_ATOM(_replacement_2018);
    if (_877 == 0)
    {
        _877 = NOVALUE;
        goto L2; // [55] 65
    }
    else{
        _877 = NOVALUE;
    }

    /** search.e:705			replacement = {replacement}*/
    _0 = _replacement_2018;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_replacement_2018);
    ((intptr_t*)_2)[1] = _replacement_2018;
    _replacement_2018 = MAKE_SEQ(_1);
    DeRef(_0);
L2: 

    /** search.e:708		needle_len = length(needle) - 1*/
    if (IS_SEQUENCE(_needle_2016)){
            _879 = SEQ_PTR(_needle_2016)->length;
    }
    else {
        _879 = 1;
    }
    _needle_len_2021 = _879 - 1LL;
    _879 = NOVALUE;

    /** search.e:709		replacement_len = length(replacement)*/
    if (IS_SEQUENCE(_replacement_2018)){
            _replacement_len_2022 = SEQ_PTR(_replacement_2018)->length;
    }
    else {
        _replacement_len_2022 = 1;
    }

    /** search.e:711		scan_from = 1*/
    _scan_from_2023 = 1LL;

    /** search.e:712		while posn with entry do*/
    goto L3; // [86] 132
L4: 
    if (_posn_2020 == 0)
    {
        goto L5; // [91] 144
    }
    else{
    }

    /** search.e:713			haystack = replace(haystack, replacement, posn, posn + needle_len)*/
    _882 = _posn_2020 + _needle_len_2021;
    if ((object)((uintptr_t)_882 + (uintptr_t)HIGH_BITS) >= 0){
        _882 = NewDouble((eudouble)_882);
    }
    {
        intptr_t p1 = _haystack_2017;
        intptr_t p2 = _replacement_2018;
        intptr_t p3 = _posn_2020;
        intptr_t p4 = _882;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_haystack_2017;
        Replace( &replace_params );
    }
    DeRef(_882);
    _882 = NOVALUE;

    /** search.e:715			cnt -= 1*/
    _cnt_2024 = _cnt_2024 - 1LL;

    /** search.e:716			if cnt = 0 then*/
    if (_cnt_2024 != 0LL)
    goto L6; // [114] 123

    /** search.e:717				exit*/
    goto L5; // [120] 144
L6: 

    /** search.e:719			scan_from = posn + replacement_len*/
    _scan_from_2023 = _posn_2020 + _replacement_len_2022;

    /** search.e:720		entry*/
L3: 

    /** search.e:721			posn = match(needle, haystack, scan_from)*/
    _posn_2020 = e_match_from(_needle_2016, _haystack_2017, _scan_from_2023);

    /** search.e:722		end while*/
    goto L4; // [141] 89
L5: 

    /** search.e:724		return haystack*/
    DeRef(_needle_2016);
    DeRef(_replacement_2018);
    return _haystack_2017;
    ;
}


object _14begins(object _sub_text_2137, object _full_text_2138)
{
    object _946 = NOVALUE;
    object _945 = NOVALUE;
    object _944 = NOVALUE;
    object _942 = NOVALUE;
    object _941 = NOVALUE;
    object _940 = NOVALUE;
    object _939 = NOVALUE;
    object _938 = NOVALUE;
    object _936 = NOVALUE;
    object _0, _1, _2;
    

    /** search.e:976		if length(full_text) = 0 then*/
    if (IS_SEQUENCE(_full_text_2138)){
            _936 = SEQ_PTR(_full_text_2138)->length;
    }
    else {
        _936 = 1;
    }
    if (_936 != 0LL)
    goto L1; // [8] 19

    /** search.e:977			return 0*/
    DeRef(_sub_text_2137);
    DeRefDS(_full_text_2138);
    return 0LL;
L1: 

    /** search.e:980		if atom(sub_text) then*/
    _938 = IS_ATOM(_sub_text_2137);
    if (_938 == 0)
    {
        _938 = NOVALUE;
        goto L2; // [24] 57
    }
    else{
        _938 = NOVALUE;
    }

    /** search.e:981			if equal(sub_text, full_text[1]) then*/
    _2 = (object)SEQ_PTR(_full_text_2138);
    _939 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (_sub_text_2137 == _939)
    _940 = 1;
    else if (IS_ATOM_INT(_sub_text_2137) && IS_ATOM_INT(_939))
    _940 = 0;
    else
    _940 = (compare(_sub_text_2137, _939) == 0);
    _939 = NOVALUE;
    if (_940 == 0)
    {
        _940 = NOVALUE;
        goto L3; // [37] 49
    }
    else{
        _940 = NOVALUE;
    }

    /** search.e:982				return 1*/
    DeRef(_sub_text_2137);
    DeRefDS(_full_text_2138);
    return 1LL;
    goto L4; // [46] 56
L3: 

    /** search.e:984				return 0*/
    DeRef(_sub_text_2137);
    DeRefDS(_full_text_2138);
    return 0LL;
L4: 
L2: 

    /** search.e:988		if length(sub_text) > length(full_text) then*/
    if (IS_SEQUENCE(_sub_text_2137)){
            _941 = SEQ_PTR(_sub_text_2137)->length;
    }
    else {
        _941 = 1;
    }
    if (IS_SEQUENCE(_full_text_2138)){
            _942 = SEQ_PTR(_full_text_2138)->length;
    }
    else {
        _942 = 1;
    }
    if (_941 <= _942)
    goto L5; // [65] 76

    /** search.e:989			return 0*/
    DeRef(_sub_text_2137);
    DeRefDS(_full_text_2138);
    return 0LL;
L5: 

    /** search.e:992		if equal(sub_text, full_text[1.. length(sub_text)]) then*/
    if (IS_SEQUENCE(_sub_text_2137)){
            _944 = SEQ_PTR(_sub_text_2137)->length;
    }
    else {
        _944 = 1;
    }
    rhs_slice_target = (object_ptr)&_945;
    RHS_Slice(_full_text_2138, 1LL, _944);
    if (_sub_text_2137 == _945)
    _946 = 1;
    else if (IS_ATOM_INT(_sub_text_2137) && IS_ATOM_INT(_945))
    _946 = 0;
    else
    _946 = (compare(_sub_text_2137, _945) == 0);
    DeRefDS(_945);
    _945 = NOVALUE;
    if (_946 == 0)
    {
        _946 = NOVALUE;
        goto L6; // [90] 102
    }
    else{
        _946 = NOVALUE;
    }

    /** search.e:993			return 1*/
    DeRef(_sub_text_2137);
    DeRefDS(_full_text_2138);
    return 1LL;
    goto L7; // [99] 109
L6: 

    /** search.e:995			return 0*/
    DeRef(_sub_text_2137);
    DeRefDS(_full_text_2138);
    return 0LL;
L7: 
    ;
}


object _14ends(object _sub_text_2159, object _full_text_2160)
{
    object _962 = NOVALUE;
    object _961 = NOVALUE;
    object _960 = NOVALUE;
    object _959 = NOVALUE;
    object _958 = NOVALUE;
    object _957 = NOVALUE;
    object _956 = NOVALUE;
    object _954 = NOVALUE;
    object _953 = NOVALUE;
    object _952 = NOVALUE;
    object _951 = NOVALUE;
    object _950 = NOVALUE;
    object _949 = NOVALUE;
    object _947 = NOVALUE;
    object _0, _1, _2;
    

    /** search.e:1026		if length(full_text) = 0 then*/
    if (IS_SEQUENCE(_full_text_2160)){
            _947 = SEQ_PTR(_full_text_2160)->length;
    }
    else {
        _947 = 1;
    }
    if (_947 != 0LL)
    goto L1; // [8] 19

    /** search.e:1027			return 0*/
    DeRefDSi(_sub_text_2159);
    DeRefDS(_full_text_2160);
    return 0LL;
L1: 

    /** search.e:1030		if atom(sub_text) then*/
    _949 = IS_ATOM(_sub_text_2159);
    if (_949 == 0)
    {
        _949 = NOVALUE;
        goto L2; // [24] 60
    }
    else{
        _949 = NOVALUE;
    }

    /** search.e:1031			if equal(sub_text, full_text[$]) then*/
    if (IS_SEQUENCE(_full_text_2160)){
            _950 = SEQ_PTR(_full_text_2160)->length;
    }
    else {
        _950 = 1;
    }
    _2 = (object)SEQ_PTR(_full_text_2160);
    _951 = (object)*(((s1_ptr)_2)->base + _950);
    if (_sub_text_2159 == _951)
    _952 = 1;
    else if (IS_ATOM_INT(_sub_text_2159) && IS_ATOM_INT(_951))
    _952 = 0;
    else
    _952 = (compare(_sub_text_2159, _951) == 0);
    _951 = NOVALUE;
    if (_952 == 0)
    {
        _952 = NOVALUE;
        goto L3; // [40] 52
    }
    else{
        _952 = NOVALUE;
    }

    /** search.e:1032				return 1*/
    DeRefi(_sub_text_2159);
    DeRefDS(_full_text_2160);
    return 1LL;
    goto L4; // [49] 59
L3: 

    /** search.e:1034				return 0*/
    DeRefi(_sub_text_2159);
    DeRefDS(_full_text_2160);
    return 0LL;
L4: 
L2: 

    /** search.e:1038		if length(sub_text) > length(full_text) then*/
    if (IS_SEQUENCE(_sub_text_2159)){
            _953 = SEQ_PTR(_sub_text_2159)->length;
    }
    else {
        _953 = 1;
    }
    if (IS_SEQUENCE(_full_text_2160)){
            _954 = SEQ_PTR(_full_text_2160)->length;
    }
    else {
        _954 = 1;
    }
    if (_953 <= _954)
    goto L5; // [68] 79

    /** search.e:1039			return 0*/
    DeRefi(_sub_text_2159);
    DeRefDS(_full_text_2160);
    return 0LL;
L5: 

    /** search.e:1042		if equal(sub_text, full_text[$ - length(sub_text) + 1 .. $]) then*/
    if (IS_SEQUENCE(_full_text_2160)){
            _956 = SEQ_PTR(_full_text_2160)->length;
    }
    else {
        _956 = 1;
    }
    if (IS_SEQUENCE(_sub_text_2159)){
            _957 = SEQ_PTR(_sub_text_2159)->length;
    }
    else {
        _957 = 1;
    }
    _958 = _956 - _957;
    _956 = NOVALUE;
    _957 = NOVALUE;
    _959 = _958 + 1;
    _958 = NOVALUE;
    if (IS_SEQUENCE(_full_text_2160)){
            _960 = SEQ_PTR(_full_text_2160)->length;
    }
    else {
        _960 = 1;
    }
    rhs_slice_target = (object_ptr)&_961;
    RHS_Slice(_full_text_2160, _959, _960);
    if (_sub_text_2159 == _961)
    _962 = 1;
    else if (IS_ATOM_INT(_sub_text_2159) && IS_ATOM_INT(_961))
    _962 = 0;
    else
    _962 = (compare(_sub_text_2159, _961) == 0);
    DeRefDS(_961);
    _961 = NOVALUE;
    if (_962 == 0)
    {
        _962 = NOVALUE;
        goto L6; // [107] 119
    }
    else{
        _962 = NOVALUE;
    }

    /** search.e:1043			return 1*/
    DeRefi(_sub_text_2159);
    DeRefDS(_full_text_2160);
    _959 = NOVALUE;
    return 1LL;
    goto L7; // [116] 126
L6: 

    /** search.e:1045			return 0*/
    DeRefi(_sub_text_2159);
    DeRefDS(_full_text_2160);
    DeRef(_959);
    _959 = NOVALUE;
    return 0LL;
L7: 
    ;
}



// 0xE968F3CC
