// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _25sort(object _x_5886, object _order_5887)
{
    object _gap_5888 = NOVALUE;
    object _j_5889 = NOVALUE;
    object _first_5890 = NOVALUE;
    object _last_5891 = NOVALUE;
    object _tempi_5892 = NOVALUE;
    object _tempj_5893 = NOVALUE;
    object _3013 = NOVALUE;
    object _3009 = NOVALUE;
    object _3006 = NOVALUE;
    object _3002 = NOVALUE;
    object _2999 = NOVALUE;
    object _0, _1, _2;
    

    /** sort.e:72		if order >= 0 then*/

    /** sort.e:73			order = -1*/
    _order_5887 = -1LL;
    goto L1; // [16] 25

    /** sort.e:75			order = 1*/
    _order_5887 = 1LL;
L1: 

    /** sort.e:79		last = length(x)*/
    if (IS_SEQUENCE(_x_5886)){
            _last_5891 = SEQ_PTR(_x_5886)->length;
    }
    else {
        _last_5891 = 1;
    }

    /** sort.e:80		gap = floor(last / 10) + 1*/
    if (10LL > 0 && _last_5891 >= 0) {
        _2999 = _last_5891 / 10LL;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_last_5891 / (eudouble)10LL);
        _2999 = (object)temp_dbl;
    }
    _gap_5888 = _2999 + 1;
    _2999 = NOVALUE;

    /** sort.e:81		while 1 do*/
L2: 

    /** sort.e:82			first = gap + 1*/
    _first_5890 = _gap_5888 + 1;

    /** sort.e:83			for i = first to last do*/
    _3002 = _last_5891;
    {
        object _i_5903;
        _i_5903 = _first_5890;
L3: 
        if (_i_5903 > _3002){
            goto L4; // [56] 152
        }

        /** sort.e:84				tempi = x[i]*/
        DeRef(_tempi_5892);
        _2 = (object)SEQ_PTR(_x_5886);
        _tempi_5892 = (object)*(((s1_ptr)_2)->base + _i_5903);
        Ref(_tempi_5892);

        /** sort.e:85				j = i - gap*/
        _j_5889 = _i_5903 - _gap_5888;

        /** sort.e:86				while 1 do*/
L5: 

        /** sort.e:87					tempj = x[j]*/
        DeRef(_tempj_5893);
        _2 = (object)SEQ_PTR(_x_5886);
        _tempj_5893 = (object)*(((s1_ptr)_2)->base + _j_5889);
        Ref(_tempj_5893);

        /** sort.e:88					if eu:compare(tempi, tempj) != order then*/
        if (IS_ATOM_INT(_tempi_5892) && IS_ATOM_INT(_tempj_5893)){
            _3006 = (_tempi_5892 < _tempj_5893) ? -1 : (_tempi_5892 > _tempj_5893);
        }
        else{
            _3006 = compare(_tempi_5892, _tempj_5893);
        }
        if (_3006 == _order_5887)
        goto L6; // [92] 107

        /** sort.e:89						j += gap*/
        _j_5889 = _j_5889 + _gap_5888;

        /** sort.e:90						exit*/
        goto L7; // [104] 139
L6: 

        /** sort.e:92					x[j+gap] = tempj*/
        _3009 = _j_5889 + _gap_5888;
        Ref(_tempj_5893);
        _2 = (object)SEQ_PTR(_x_5886);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _x_5886 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _3009);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _tempj_5893;
        DeRef(_1);

        /** sort.e:93					if j <= gap then*/
        if (_j_5889 > _gap_5888)
        goto L8; // [119] 128

        /** sort.e:94						exit*/
        goto L7; // [125] 139
L8: 

        /** sort.e:96					j -= gap*/
        _j_5889 = _j_5889 - _gap_5888;

        /** sort.e:97				end while*/
        goto L5; // [136] 80
L7: 

        /** sort.e:98				x[j] = tempi*/
        Ref(_tempi_5892);
        _2 = (object)SEQ_PTR(_x_5886);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _x_5886 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _j_5889);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _tempi_5892;
        DeRef(_1);

        /** sort.e:99			end for*/
        _i_5903 = _i_5903 + 1LL;
        goto L3; // [147] 63
L4: 
        ;
    }

    /** sort.e:100			if gap = 1 then*/
    if (_gap_5888 != 1LL)
    goto L9; // [154] 167

    /** sort.e:101				return x*/
    DeRef(_tempi_5892);
    DeRef(_tempj_5893);
    DeRef(_3009);
    _3009 = NOVALUE;
    return _x_5886;
    goto L2; // [164] 45
L9: 

    /** sort.e:103				gap = floor(gap / 7) + 1*/
    if (7LL > 0 && _gap_5888 >= 0) {
        _3013 = _gap_5888 / 7LL;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_gap_5888 / (eudouble)7LL);
        _3013 = (object)temp_dbl;
    }
    _gap_5888 = _3013 + 1;
    _3013 = NOVALUE;

    /** sort.e:105		end while*/
    goto L2; // [180] 45
    ;
}


object _25custom_sort(object _custom_compare_5924, object _x_5925, object _data_5926, object _order_5927)
{
    object _gap_5928 = NOVALUE;
    object _j_5929 = NOVALUE;
    object _first_5930 = NOVALUE;
    object _last_5931 = NOVALUE;
    object _tempi_5932 = NOVALUE;
    object _tempj_5933 = NOVALUE;
    object _result_5934 = NOVALUE;
    object _args_5935 = NOVALUE;
    object _3041 = NOVALUE;
    object _3037 = NOVALUE;
    object _3034 = NOVALUE;
    object _3032 = NOVALUE;
    object _3031 = NOVALUE;
    object _3026 = NOVALUE;
    object _3023 = NOVALUE;
    object _3019 = NOVALUE;
    object _3017 = NOVALUE;
    object _0, _1, _2;
    

    /** sort.e:253		sequence args = {0, 0}*/
    DeRef(_args_5935);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = 0LL;
    _args_5935 = MAKE_SEQ(_1);

    /** sort.e:255		if order >= 0 then*/

    /** sort.e:256			order = -1*/
    _order_5927 = -1LL;
    goto L1; // [24] 33

    /** sort.e:258			order = 1*/
    _order_5927 = 1LL;
L1: 

    /** sort.e:261		if atom(data) then*/
    _3017 = IS_ATOM(_data_5926);
    if (_3017 == 0)
    {
        _3017 = NOVALUE;
        goto L2; // [38] 50
    }
    else{
        _3017 = NOVALUE;
    }

    /** sort.e:262			args &= data*/
    if (IS_SEQUENCE(_args_5935) && IS_ATOM(_data_5926)) {
        Ref(_data_5926);
        Append(&_args_5935, _args_5935, _data_5926);
    }
    else if (IS_ATOM(_args_5935) && IS_SEQUENCE(_data_5926)) {
    }
    else {
        Concat((object_ptr)&_args_5935, _args_5935, _data_5926);
    }
    goto L3; // [47] 70
L2: 

    /** sort.e:263		elsif length(data) then*/
    _3019 = 0;
L3: 

    /** sort.e:267		last = length(x)*/
    if (IS_SEQUENCE(_x_5925)){
            _last_5931 = SEQ_PTR(_x_5925)->length;
    }
    else {
        _last_5931 = 1;
    }

    /** sort.e:268		gap = floor(last / 10) + 1*/
    if (10LL > 0 && _last_5931 >= 0) {
        _3023 = _last_5931 / 10LL;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_last_5931 / (eudouble)10LL);
        _3023 = (object)temp_dbl;
    }
    _gap_5928 = _3023 + 1;
    _3023 = NOVALUE;

    /** sort.e:269		while 1 do*/
L4: 

    /** sort.e:270			first = gap + 1*/
    _first_5930 = _gap_5928 + 1;

    /** sort.e:271			for i = first to last do*/
    _3026 = _last_5931;
    {
        object _i_5953;
        _i_5953 = _first_5930;
L5: 
        if (_i_5953 > _3026){
            goto L6; // [101] 240
        }

        /** sort.e:272				tempi = x[i]*/
        DeRef(_tempi_5932);
        _2 = (object)SEQ_PTR(_x_5925);
        _tempi_5932 = (object)*(((s1_ptr)_2)->base + _i_5953);
        Ref(_tempi_5932);

        /** sort.e:273				args[1] = tempi*/
        Ref(_tempi_5932);
        _2 = (object)SEQ_PTR(_args_5935);
        _2 = (object)(((s1_ptr)_2)->base + 1LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _tempi_5932;
        DeRef(_1);

        /** sort.e:274				j = i - gap*/
        _j_5929 = _i_5953 - _gap_5928;

        /** sort.e:275				while 1 do*/
L7: 

        /** sort.e:276					tempj = x[j]*/
        DeRef(_tempj_5933);
        _2 = (object)SEQ_PTR(_x_5925);
        _tempj_5933 = (object)*(((s1_ptr)_2)->base + _j_5929);
        Ref(_tempj_5933);

        /** sort.e:277					args[2] = tempj*/
        Ref(_tempj_5933);
        _2 = (object)SEQ_PTR(_args_5935);
        _2 = (object)(((s1_ptr)_2)->base + 2LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _tempj_5933;
        DeRef(_1);

        /** sort.e:278					result = call_func(custom_compare, args)*/
        _1 = (object)SEQ_PTR(_args_5935);
        _2 = (object)((s1_ptr)_1)->base;
        _0 = (object)_00[_custom_compare_5924].addr;
        switch(((s1_ptr)_1)->length) {
            case 0:
                _1 = (*(intptr_t (*)())_0)(
                                     );
                break;
            case 1:
                Ref( *(( (intptr_t*)_2) + 1) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1)
                                     );
                break;
            case 2:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2)
                                     );
                break;
            case 3:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3)
                                     );
                break;
            case 4:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4)
                                     );
                break;
            case 5:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5)
                                     );
                break;
            case 6:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                Ref( *(( (intptr_t*)_2) + 6) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5), 
                                    *( ((intptr_t *)_2) + 6)
                                     );
                break;
            case 7:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                Ref( *(( (intptr_t*)_2) + 6) );
                Ref( *(( (intptr_t*)_2) + 7) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5), 
                                    *( ((intptr_t *)_2) + 6), 
                                    *( ((intptr_t *)_2) + 7)
                                     );
                break;
            case 8:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                Ref( *(( (intptr_t*)_2) + 6) );
                Ref( *(( (intptr_t*)_2) + 7) );
                Ref( *(( (intptr_t*)_2) + 8) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5), 
                                    *( ((intptr_t *)_2) + 6), 
                                    *( ((intptr_t *)_2) + 7), 
                                    *( ((intptr_t *)_2) + 8)
                                     );
                break;
            case 9:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                Ref( *(( (intptr_t*)_2) + 6) );
                Ref( *(( (intptr_t*)_2) + 7) );
                Ref( *(( (intptr_t*)_2) + 8) );
                Ref( *(( (intptr_t*)_2) + 9) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5), 
                                    *( ((intptr_t *)_2) + 6), 
                                    *( ((intptr_t *)_2) + 7), 
                                    *( ((intptr_t *)_2) + 8), 
                                    *( ((intptr_t *)_2) + 9)
                                     );
                break;
            case 10:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                Ref( *(( (intptr_t*)_2) + 6) );
                Ref( *(( (intptr_t*)_2) + 7) );
                Ref( *(( (intptr_t*)_2) + 8) );
                Ref( *(( (intptr_t*)_2) + 9) );
                Ref( *(( (intptr_t*)_2) + 10) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5), 
                                    *( ((intptr_t *)_2) + 6), 
                                    *( ((intptr_t *)_2) + 7), 
                                    *( ((intptr_t *)_2) + 8), 
                                    *( ((intptr_t *)_2) + 9), 
                                    *( ((intptr_t *)_2) + 10)
                                     );
                break;
            case 11:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                Ref( *(( (intptr_t*)_2) + 6) );
                Ref( *(( (intptr_t*)_2) + 7) );
                Ref( *(( (intptr_t*)_2) + 8) );
                Ref( *(( (intptr_t*)_2) + 9) );
                Ref( *(( (intptr_t*)_2) + 10) );
                Ref( *(( (intptr_t*)_2) + 11) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5), 
                                    *( ((intptr_t *)_2) + 6), 
                                    *( ((intptr_t *)_2) + 7), 
                                    *( ((intptr_t *)_2) + 8), 
                                    *( ((intptr_t *)_2) + 9), 
                                    *( ((intptr_t *)_2) + 10), 
                                    *( ((intptr_t *)_2) + 11)
                                     );
                break;
            case 12:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                Ref( *(( (intptr_t*)_2) + 6) );
                Ref( *(( (intptr_t*)_2) + 7) );
                Ref( *(( (intptr_t*)_2) + 8) );
                Ref( *(( (intptr_t*)_2) + 9) );
                Ref( *(( (intptr_t*)_2) + 10) );
                Ref( *(( (intptr_t*)_2) + 11) );
                Ref( *(( (intptr_t*)_2) + 12) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5), 
                                    *( ((intptr_t *)_2) + 6), 
                                    *( ((intptr_t *)_2) + 7), 
                                    *( ((intptr_t *)_2) + 8), 
                                    *( ((intptr_t *)_2) + 9), 
                                    *( ((intptr_t *)_2) + 10), 
                                    *( ((intptr_t *)_2) + 11), 
                                    *( ((intptr_t *)_2) + 12)
                                     );
                break;
        }
        DeRef(_result_5934);
        _result_5934 = _1;

        /** sort.e:279					if sequence(result) then*/
        _3031 = IS_SEQUENCE(_result_5934);
        if (_3031 == 0)
        {
            _3031 = NOVALUE;
            goto L8; // [154] 174
        }
        else{
            _3031 = NOVALUE;
        }

        /** sort.e:280						args[3] = result[2]*/
        _2 = (object)SEQ_PTR(_result_5934);
        _3032 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_3032);
        _2 = (object)SEQ_PTR(_args_5935);
        _2 = (object)(((s1_ptr)_2)->base + 3LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _3032;
        if( _1 != _3032 ){
            DeRef(_1);
        }
        _3032 = NOVALUE;

        /** sort.e:281						result = result[1]*/
        _0 = _result_5934;
        _2 = (object)SEQ_PTR(_result_5934);
        _result_5934 = (object)*(((s1_ptr)_2)->base + 1LL);
        Ref(_result_5934);
        DeRef(_0);
L8: 

        /** sort.e:283					if eu:compare(result, 0) != order then*/
        if (IS_ATOM_INT(_result_5934) && IS_ATOM_INT(0LL)){
            _3034 = (_result_5934 < 0LL) ? -1 : (_result_5934 > 0LL);
        }
        else{
            _3034 = compare(_result_5934, 0LL);
        }
        if (_3034 == _order_5927)
        goto L9; // [180] 195

        /** sort.e:284						j += gap*/
        _j_5929 = _j_5929 + _gap_5928;

        /** sort.e:285						exit*/
        goto LA; // [192] 227
L9: 

        /** sort.e:287					x[j+gap] = tempj*/
        _3037 = _j_5929 + _gap_5928;
        Ref(_tempj_5933);
        _2 = (object)SEQ_PTR(_x_5925);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _x_5925 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _3037);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _tempj_5933;
        DeRef(_1);

        /** sort.e:288					if j <= gap then*/
        if (_j_5929 > _gap_5928)
        goto LB; // [207] 216

        /** sort.e:289						exit*/
        goto LA; // [213] 227
LB: 

        /** sort.e:291					j -= gap*/
        _j_5929 = _j_5929 - _gap_5928;

        /** sort.e:292				end while*/
        goto L7; // [224] 131
LA: 

        /** sort.e:293				x[j] = tempi*/
        Ref(_tempi_5932);
        _2 = (object)SEQ_PTR(_x_5925);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _x_5925 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _j_5929);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _tempi_5932;
        DeRef(_1);

        /** sort.e:294			end for*/
        _i_5953 = _i_5953 + 1LL;
        goto L5; // [235] 108
L6: 
        ;
    }

    /** sort.e:295			if gap = 1 then*/
    if (_gap_5928 != 1LL)
    goto LC; // [242] 255

    /** sort.e:296				return x*/
    DeRef(_data_5926);
    DeRef(_tempi_5932);
    DeRef(_tempj_5933);
    DeRef(_result_5934);
    DeRef(_args_5935);
    DeRef(_3037);
    _3037 = NOVALUE;
    return _x_5925;
    goto L4; // [252] 90
LC: 

    /** sort.e:298				gap = floor(gap / 7) + 1*/
    if (7LL > 0 && _gap_5928 >= 0) {
        _3041 = _gap_5928 / 7LL;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_gap_5928 / (eudouble)7LL);
        _3041 = (object)temp_dbl;
    }
    _gap_5928 = _3041 + 1;
    _3041 = NOVALUE;

    /** sort.e:300		end while*/
    goto L4; // [268] 90
    ;
}


object _25column_compare(object _a_5979, object _b_5980, object _cols_5981)
{
    object _sign_5982 = NOVALUE;
    object _column_5983 = NOVALUE;
    object _3064 = NOVALUE;
    object _3062 = NOVALUE;
    object _3061 = NOVALUE;
    object _3060 = NOVALUE;
    object _3059 = NOVALUE;
    object _3058 = NOVALUE;
    object _3057 = NOVALUE;
    object _3055 = NOVALUE;
    object _3054 = NOVALUE;
    object _3053 = NOVALUE;
    object _3051 = NOVALUE;
    object _3049 = NOVALUE;
    object _3046 = NOVALUE;
    object _3044 = NOVALUE;
    object _3043 = NOVALUE;
    object _0, _1, _2;
    

    /** sort.e:309		for i = 1 to length(cols) do*/
    if (IS_SEQUENCE(_cols_5981)){
            _3043 = SEQ_PTR(_cols_5981)->length;
    }
    else {
        _3043 = 1;
    }
    {
        object _i_5985;
        _i_5985 = 1LL;
L1: 
        if (_i_5985 > _3043){
            goto L2; // [6] 176
        }

        /** sort.e:310			if cols[i] < 0 then*/
        _2 = (object)SEQ_PTR(_cols_5981);
        _3044 = (object)*(((s1_ptr)_2)->base + _i_5985);
        if (binary_op_a(GREATEREQ, _3044, 0LL)){
            _3044 = NOVALUE;
            goto L3; // [19] 42
        }
        _3044 = NOVALUE;

        /** sort.e:311				sign = -1*/
        _sign_5982 = -1LL;

        /** sort.e:312				column = -cols[i]*/
        _2 = (object)SEQ_PTR(_cols_5981);
        _3046 = (object)*(((s1_ptr)_2)->base + _i_5985);
        if (IS_ATOM_INT(_3046)) {
            if ((uintptr_t)_3046 == (uintptr_t)HIGH_BITS){
                _column_5983 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _column_5983 = - _3046;
            }
        }
        else {
            _column_5983 = unary_op(UMINUS, _3046);
        }
        _3046 = NOVALUE;
        if (!IS_ATOM_INT(_column_5983)) {
            _1 = (object)(DBL_PTR(_column_5983)->dbl);
            DeRefDS(_column_5983);
            _column_5983 = _1;
        }
        goto L4; // [39] 56
L3: 

        /** sort.e:314				sign = 1*/
        _sign_5982 = 1LL;

        /** sort.e:315				column = cols[i]*/
        _2 = (object)SEQ_PTR(_cols_5981);
        _column_5983 = (object)*(((s1_ptr)_2)->base + _i_5985);
        if (!IS_ATOM_INT(_column_5983)){
            _column_5983 = (object)DBL_PTR(_column_5983)->dbl;
        }
L4: 

        /** sort.e:317			if column <= length(a) then*/
        if (IS_SEQUENCE(_a_5979)){
                _3049 = SEQ_PTR(_a_5979)->length;
        }
        else {
            _3049 = 1;
        }
        if (_column_5983 > _3049)
        goto L5; // [63] 137

        /** sort.e:318				if column <= length(b) then*/
        if (IS_SEQUENCE(_b_5980)){
                _3051 = SEQ_PTR(_b_5980)->length;
        }
        else {
            _3051 = 1;
        }
        if (_column_5983 > _3051)
        goto L6; // [72] 121

        /** sort.e:319					if not equal(a[column], b[column]) then*/
        _2 = (object)SEQ_PTR(_a_5979);
        _3053 = (object)*(((s1_ptr)_2)->base + _column_5983);
        _2 = (object)SEQ_PTR(_b_5980);
        _3054 = (object)*(((s1_ptr)_2)->base + _column_5983);
        if (_3053 == _3054)
        _3055 = 1;
        else if (IS_ATOM_INT(_3053) && IS_ATOM_INT(_3054))
        _3055 = 0;
        else
        _3055 = (compare(_3053, _3054) == 0);
        _3053 = NOVALUE;
        _3054 = NOVALUE;
        if (_3055 != 0)
        goto L7; // [90] 169
        _3055 = NOVALUE;

        /** sort.e:320						return sign * eu:compare(a[column], b[column])*/
        _2 = (object)SEQ_PTR(_a_5979);
        _3057 = (object)*(((s1_ptr)_2)->base + _column_5983);
        _2 = (object)SEQ_PTR(_b_5980);
        _3058 = (object)*(((s1_ptr)_2)->base + _column_5983);
        if (IS_ATOM_INT(_3057) && IS_ATOM_INT(_3058)){
            _3059 = (_3057 < _3058) ? -1 : (_3057 > _3058);
        }
        else{
            _3059 = compare(_3057, _3058);
        }
        _3057 = NOVALUE;
        _3058 = NOVALUE;
        {
            int128_t p128 = (int128_t)_sign_5982 * (int128_t)_3059;
            if( p128 != (int128_t)(_3060 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _3060 = NewDouble( (eudouble)p128 );
            }
        }
        _3059 = NOVALUE;
        DeRef(_a_5979);
        DeRef(_b_5980);
        DeRef(_cols_5981);
        return _3060;
        goto L7; // [118] 169
L6: 

        /** sort.e:323					return sign * -1*/
        {
            int128_t p128 = (int128_t)_sign_5982 * (int128_t)-1LL;
            if( p128 != (int128_t)(_3061 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _3061 = NewDouble( (eudouble)p128 );
            }
        }
        DeRef(_a_5979);
        DeRef(_b_5980);
        DeRef(_cols_5981);
        DeRef(_3060);
        _3060 = NOVALUE;
        return _3061;
        goto L7; // [134] 169
L5: 

        /** sort.e:326				if column <= length(b) then*/
        if (IS_SEQUENCE(_b_5980)){
                _3062 = SEQ_PTR(_b_5980)->length;
        }
        else {
            _3062 = 1;
        }
        if (_column_5983 > _3062)
        goto L8; // [142] 161

        /** sort.e:327					return sign * 1*/
        _3064 = _sign_5982 * 1LL;
        DeRef(_a_5979);
        DeRef(_b_5980);
        DeRef(_cols_5981);
        DeRef(_3060);
        _3060 = NOVALUE;
        DeRef(_3061);
        _3061 = NOVALUE;
        return _3064;
        goto L9; // [158] 168
L8: 

        /** sort.e:329					return 0*/
        DeRef(_a_5979);
        DeRef(_b_5980);
        DeRef(_cols_5981);
        DeRef(_3060);
        _3060 = NOVALUE;
        DeRef(_3061);
        _3061 = NOVALUE;
        DeRef(_3064);
        _3064 = NOVALUE;
        return 0LL;
L9: 
L7: 

        /** sort.e:332		end for*/
        _i_5985 = _i_5985 + 1LL;
        goto L1; // [171] 13
L2: 
        ;
    }

    /** sort.e:333		return 0*/
    DeRef(_a_5979);
    DeRef(_b_5980);
    DeRef(_cols_5981);
    DeRef(_3060);
    _3060 = NOVALUE;
    DeRef(_3061);
    _3061 = NOVALUE;
    DeRef(_3064);
    _3064 = NOVALUE;
    return 0LL;
    ;
}



// 0xFD33243B
