// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _10pretty_out(object _text_1618)
{
    object _682 = NOVALUE;
    object _680 = NOVALUE;
    object _678 = NOVALUE;
    object _677 = NOVALUE;
    object _0, _1, _2;
    

    /** pretty.e:19		pretty_line &= text*/
    if (IS_SEQUENCE(_10pretty_line_1615) && IS_ATOM(_text_1618)) {
        Ref(_text_1618);
        Append(&_10pretty_line_1615, _10pretty_line_1615, _text_1618);
    }
    else if (IS_ATOM(_10pretty_line_1615) && IS_SEQUENCE(_text_1618)) {
    }
    else {
        Concat((object_ptr)&_10pretty_line_1615, _10pretty_line_1615, _text_1618);
    }

    /** pretty.e:20		if equal(text, '\n') and pretty_printing then*/
    if (_text_1618 == 10LL)
    _677 = 1;
    else if (IS_ATOM_INT(_text_1618) && IS_ATOM_INT(10LL))
    _677 = 0;
    else
    _677 = (compare(_text_1618, 10LL) == 0);
    if (_677 == 0) {
        goto L1; // [15] 50
    }
    if (_10pretty_printing_1612 == 0)
    {
        goto L1; // [22] 50
    }
    else{
    }

    /** pretty.e:21			puts(pretty_file, pretty_line)*/
    EPuts(_10pretty_file_1603, _10pretty_line_1615); // DJP 

    /** pretty.e:22			pretty_line = ""*/
    RefDS(_5);
    DeRefDS(_10pretty_line_1615);
    _10pretty_line_1615 = _5;

    /** pretty.e:23			pretty_line_count += 1*/
    _10pretty_line_count_1608 = _10pretty_line_count_1608 + 1;
L1: 

    /** pretty.e:25		if atom(text) then*/
    _680 = IS_ATOM(_text_1618);
    if (_680 == 0)
    {
        _680 = NOVALUE;
        goto L2; // [55] 69
    }
    else{
        _680 = NOVALUE;
    }

    /** pretty.e:26			pretty_chars += 1*/
    _10pretty_chars_1600 = _10pretty_chars_1600 + 1;
    goto L3; // [66] 81
L2: 

    /** pretty.e:28			pretty_chars += length(text)*/
    if (IS_SEQUENCE(_text_1618)){
            _682 = SEQ_PTR(_text_1618)->length;
    }
    else {
        _682 = 1;
    }
    _10pretty_chars_1600 = _10pretty_chars_1600 + _682;
    _682 = NOVALUE;
L3: 

    /** pretty.e:30	end procedure*/
    DeRef(_text_1618);
    return;
    ;
}


void _10cut_line(object _n_1632)
{
    object _685 = NOVALUE;
    object _0, _1, _2;
    

    /** pretty.e:34		if not pretty_line_breaks then	*/
    if (_10pretty_line_breaks_1611 != 0)
    goto L1; // [7] 21

    /** pretty.e:35			pretty_chars = 0*/
    _10pretty_chars_1600 = 0LL;

    /** pretty.e:36			return*/
    return;
L1: 

    /** pretty.e:38		if pretty_chars + n > pretty_end_col then*/
    _685 = _10pretty_chars_1600 + _n_1632;
    if ((object)((uintptr_t)_685 + (uintptr_t)HIGH_BITS) >= 0){
        _685 = NewDouble((eudouble)_685);
    }
    if (binary_op_a(LESSEQ, _685, _10pretty_end_col_1599)){
        DeRef(_685);
        _685 = NOVALUE;
        goto L2; // [31] 46
    }
    DeRef(_685);
    _685 = NOVALUE;

    /** pretty.e:39			pretty_out('\n')*/
    _10pretty_out(10LL);

    /** pretty.e:40			pretty_chars = 0*/
    _10pretty_chars_1600 = 0LL;
L2: 

    /** pretty.e:42	end procedure*/
    return;
    ;
}


void _10indent()
{
    object _693 = NOVALUE;
    object _692 = NOVALUE;
    object _691 = NOVALUE;
    object _690 = NOVALUE;
    object _0, _1, _2;
    

    /** pretty.e:46		if pretty_line_breaks = 0 then	*/
    if (_10pretty_line_breaks_1611 != 0LL)
    goto L1; // [5] 22

    /** pretty.e:47			pretty_chars = 0*/
    _10pretty_chars_1600 = 0LL;

    /** pretty.e:48			return*/
    return;
    goto L2; // [19] 85
L1: 

    /** pretty.e:49		elsif pretty_line_breaks = -1 then*/
    if (_10pretty_line_breaks_1611 != -1LL)
    goto L3; // [26] 38

    /** pretty.e:51			cut_line( 0 )*/
    _10cut_line(0LL);
    goto L2; // [35] 85
L3: 

    /** pretty.e:54			if pretty_chars > 0 then*/
    if (_10pretty_chars_1600 <= 0LL)
    goto L4; // [42] 57

    /** pretty.e:55				pretty_out('\n')*/
    _10pretty_out(10LL);

    /** pretty.e:56				pretty_chars = 0*/
    _10pretty_chars_1600 = 0LL;
L4: 

    /** pretty.e:58			pretty_out(repeat(' ', (pretty_start_col-1) + */
    _690 = _10pretty_start_col_1601 - 1LL;
    if ((object)((uintptr_t)_690 +(uintptr_t) HIGH_BITS) >= 0){
        _690 = NewDouble((eudouble)_690);
    }
    {
        int128_t p128 = (int128_t)_10pretty_level_1602 * (int128_t)_10pretty_indent_1605;
        if( p128 != (int128_t)(_691 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
            _691 = NewDouble( (eudouble)p128 );
        }
    }
    if (IS_ATOM_INT(_690) && IS_ATOM_INT(_691)) {
        _692 = _690 + _691;
    }
    else {
        if (IS_ATOM_INT(_690)) {
            _692 = NewDouble((eudouble)_690 + DBL_PTR(_691)->dbl);
        }
        else {
            if (IS_ATOM_INT(_691)) {
                _692 = NewDouble(DBL_PTR(_690)->dbl + (eudouble)_691);
            }
            else
            _692 = NewDouble(DBL_PTR(_690)->dbl + DBL_PTR(_691)->dbl);
        }
    }
    DeRef(_690);
    _690 = NOVALUE;
    DeRef(_691);
    _691 = NOVALUE;
    _693 = Repeat(32LL, _692);
    DeRef(_692);
    _692 = NOVALUE;
    _10pretty_out(_693);
    _693 = NOVALUE;
L2: 

    /** pretty.e:62	end procedure*/
    return;
    ;
}


object _10esc_char(object _a_1653)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_a_1653)) {
        _1 = (object)(DBL_PTR(_a_1653)->dbl);
        DeRefDS(_a_1653);
        _a_1653 = _1;
    }

    /** pretty.e:66		switch a do*/
    _0 = _a_1653;
    switch ( _0 ){ 

        /** pretty.e:67			case'\t' then*/
        case 9:

        /** pretty.e:68				return `\t`*/
        RefDS(_696);
        return _696;
        goto L1; // [20] 81

        /** pretty.e:70			case'\n' then*/
        case 10:

        /** pretty.e:71				return `\n`*/
        RefDS(_697);
        return _697;
        goto L1; // [32] 81

        /** pretty.e:73			case'\r' then*/
        case 13:

        /** pretty.e:74				return `\r`*/
        RefDS(_698);
        return _698;
        goto L1; // [44] 81

        /** pretty.e:76			case'\\' then*/
        case 92:

        /** pretty.e:77				return `\\`*/
        RefDS(_700);
        return _700;
        goto L1; // [56] 81

        /** pretty.e:79			case'"' then*/
        case 34:

        /** pretty.e:80				return `\"`*/
        RefDS(_702);
        return _702;
        goto L1; // [68] 81

        /** pretty.e:82			case else*/
        default:

        /** pretty.e:83				return a*/
        return _a_1653;
    ;}L1: 
    ;
}


void _10rPrint(object _a_1671)
{
    object _sbuff_1672 = NOVALUE;
    object _multi_line_1673 = NOVALUE;
    object _all_ascii_1674 = NOVALUE;
    object _759 = NOVALUE;
    object _758 = NOVALUE;
    object _757 = NOVALUE;
    object _756 = NOVALUE;
    object _752 = NOVALUE;
    object _751 = NOVALUE;
    object _750 = NOVALUE;
    object _749 = NOVALUE;
    object _747 = NOVALUE;
    object _746 = NOVALUE;
    object _744 = NOVALUE;
    object _743 = NOVALUE;
    object _741 = NOVALUE;
    object _740 = NOVALUE;
    object _739 = NOVALUE;
    object _738 = NOVALUE;
    object _737 = NOVALUE;
    object _736 = NOVALUE;
    object _735 = NOVALUE;
    object _734 = NOVALUE;
    object _733 = NOVALUE;
    object _732 = NOVALUE;
    object _731 = NOVALUE;
    object _730 = NOVALUE;
    object _729 = NOVALUE;
    object _728 = NOVALUE;
    object _727 = NOVALUE;
    object _726 = NOVALUE;
    object _725 = NOVALUE;
    object _721 = NOVALUE;
    object _720 = NOVALUE;
    object _719 = NOVALUE;
    object _718 = NOVALUE;
    object _717 = NOVALUE;
    object _716 = NOVALUE;
    object _714 = NOVALUE;
    object _713 = NOVALUE;
    object _709 = NOVALUE;
    object _708 = NOVALUE;
    object _707 = NOVALUE;
    object _704 = NOVALUE;
    object _703 = NOVALUE;
    object _0, _1, _2;
    

    /** pretty.e:92		if atom(a) then*/
    _703 = IS_ATOM(_a_1671);
    if (_703 == 0)
    {
        _703 = NOVALUE;
        goto L1; // [6] 176
    }
    else{
        _703 = NOVALUE;
    }

    /** pretty.e:93			if integer(a) then*/
    if (IS_ATOM_INT(_a_1671))
    _704 = 1;
    else if (IS_ATOM_DBL(_a_1671))
    _704 = IS_ATOM_INT(DoubleToInt(_a_1671));
    else
    _704 = 0;
    if (_704 == 0)
    {
        _704 = NOVALUE;
        goto L2; // [14] 157
    }
    else{
        _704 = NOVALUE;
    }

    /** pretty.e:94				sbuff = sprintf(pretty_int_format, a)*/
    DeRef(_sbuff_1672);
    _sbuff_1672 = EPrintf(-9999999, _10pretty_int_format_1614, _a_1671);

    /** pretty.e:95				if pretty_ascii then */
    if (_10pretty_ascii_1604 == 0)
    {
        goto L3; // [29] 166
    }
    else{
    }

    /** pretty.e:96					if pretty_ascii >= 3 then */
    if (_10pretty_ascii_1604 < 3LL)
    goto L4; // [36] 103

    /** pretty.e:98						if (a >= pretty_ascii_min and a <= pretty_ascii_max) then*/
    if (IS_ATOM_INT(_a_1671)) {
        _707 = (_a_1671 >= _10pretty_ascii_min_1606);
    }
    else {
        _707 = binary_op(GREATEREQ, _a_1671, _10pretty_ascii_min_1606);
    }
    if (IS_ATOM_INT(_707)) {
        if (_707 == 0) {
            _708 = 0;
            goto L5; // [48] 62
        }
    }
    else {
        if (DBL_PTR(_707)->dbl == 0.0) {
            _708 = 0;
            goto L5; // [48] 62
        }
    }
    if (IS_ATOM_INT(_a_1671)) {
        _709 = (_a_1671 <= _10pretty_ascii_max_1607);
    }
    else {
        _709 = binary_op(LESSEQ, _a_1671, _10pretty_ascii_max_1607);
    }
    DeRef(_708);
    if (IS_ATOM_INT(_709))
    _708 = (_709 != 0);
    else
    _708 = DBL_PTR(_709)->dbl != 0.0;
L5: 
    if (_708 == 0)
    {
        _708 = NOVALUE;
        goto L6; // [62] 76
    }
    else{
        _708 = NOVALUE;
    }

    /** pretty.e:99							sbuff = '\'' & a & '\''  -- display char only*/
    {
        object concat_list[3];

        concat_list[0] = 39LL;
        concat_list[1] = _a_1671;
        concat_list[2] = 39LL;
        Concat_N((object_ptr)&_sbuff_1672, concat_list, 3);
    }
    goto L3; // [73] 166
L6: 

    /** pretty.e:101						elsif find(a, "\t\n\r\\") then*/
    _713 = find_from(_a_1671, _712, 1LL);
    if (_713 == 0)
    {
        _713 = NOVALUE;
        goto L3; // [83] 166
    }
    else{
        _713 = NOVALUE;
    }

    /** pretty.e:102							sbuff = '\'' & esc_char(a) & '\''  -- display char only*/
    Ref(_a_1671);
    _714 = _10esc_char(_a_1671);
    {
        object concat_list[3];

        concat_list[0] = 39LL;
        concat_list[1] = _714;
        concat_list[2] = 39LL;
        Concat_N((object_ptr)&_sbuff_1672, concat_list, 3);
    }
    DeRef(_714);
    _714 = NOVALUE;
    goto L3; // [100] 166
L4: 

    /** pretty.e:107						if (a >= pretty_ascii_min and a <= pretty_ascii_max) and pretty_ascii < 2 then*/
    if (IS_ATOM_INT(_a_1671)) {
        _716 = (_a_1671 >= _10pretty_ascii_min_1606);
    }
    else {
        _716 = binary_op(GREATEREQ, _a_1671, _10pretty_ascii_min_1606);
    }
    if (IS_ATOM_INT(_716)) {
        if (_716 == 0) {
            DeRef(_717);
            _717 = 0;
            goto L7; // [111] 125
        }
    }
    else {
        if (DBL_PTR(_716)->dbl == 0.0) {
            DeRef(_717);
            _717 = 0;
            goto L7; // [111] 125
        }
    }
    if (IS_ATOM_INT(_a_1671)) {
        _718 = (_a_1671 <= _10pretty_ascii_max_1607);
    }
    else {
        _718 = binary_op(LESSEQ, _a_1671, _10pretty_ascii_max_1607);
    }
    DeRef(_717);
    if (IS_ATOM_INT(_718))
    _717 = (_718 != 0);
    else
    _717 = DBL_PTR(_718)->dbl != 0.0;
L7: 
    if (_717 == 0) {
        goto L3; // [125] 166
    }
    _720 = (_10pretty_ascii_1604 < 2LL);
    if (_720 == 0)
    {
        DeRef(_720);
        _720 = NOVALUE;
        goto L3; // [136] 166
    }
    else{
        DeRef(_720);
        _720 = NOVALUE;
    }

    /** pretty.e:108							sbuff &= '\'' & a & '\'' -- add to numeric display*/
    {
        object concat_list[3];

        concat_list[0] = 39LL;
        concat_list[1] = _a_1671;
        concat_list[2] = 39LL;
        Concat_N((object_ptr)&_721, concat_list, 3);
    }
    Concat((object_ptr)&_sbuff_1672, _sbuff_1672, _721);
    DeRefDS(_721);
    _721 = NOVALUE;
    goto L3; // [154] 166
L2: 

    /** pretty.e:113				sbuff = sprintf(pretty_fp_format, a)*/
    DeRef(_sbuff_1672);
    _sbuff_1672 = EPrintf(-9999999, _10pretty_fp_format_1613, _a_1671);
L3: 

    /** pretty.e:115			pretty_out(sbuff)*/
    RefDS(_sbuff_1672);
    _10pretty_out(_sbuff_1672);
    goto L8; // [173] 535
L1: 

    /** pretty.e:119			cut_line(1)*/
    _10cut_line(1LL);

    /** pretty.e:120			multi_line = 0*/
    _multi_line_1673 = 0LL;

    /** pretty.e:121			all_ascii = pretty_ascii > 1*/
    _all_ascii_1674 = (_10pretty_ascii_1604 > 1LL);

    /** pretty.e:122			for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_1671)){
            _725 = SEQ_PTR(_a_1671)->length;
    }
    else {
        _725 = 1;
    }
    {
        object _i_1708;
        _i_1708 = 1LL;
L9: 
        if (_i_1708 > _725){
            goto LA; // [199] 345
        }

        /** pretty.e:123				if sequence(a[i]) and length(a[i]) > 0 then*/
        _2 = (object)SEQ_PTR(_a_1671);
        _726 = (object)*(((s1_ptr)_2)->base + _i_1708);
        _727 = IS_SEQUENCE(_726);
        _726 = NOVALUE;
        if (_727 == 0) {
            goto LB; // [215] 249
        }
        _2 = (object)SEQ_PTR(_a_1671);
        _729 = (object)*(((s1_ptr)_2)->base + _i_1708);
        if (IS_SEQUENCE(_729)){
                _730 = SEQ_PTR(_729)->length;
        }
        else {
            _730 = 1;
        }
        _729 = NOVALUE;
        _731 = (_730 > 0LL);
        _730 = NOVALUE;
        if (_731 == 0)
        {
            DeRef(_731);
            _731 = NOVALUE;
            goto LB; // [231] 249
        }
        else{
            DeRef(_731);
            _731 = NOVALUE;
        }

        /** pretty.e:124					multi_line = 1*/
        _multi_line_1673 = 1LL;

        /** pretty.e:125					all_ascii = 0*/
        _all_ascii_1674 = 0LL;

        /** pretty.e:126					exit*/
        goto LA; // [246] 345
LB: 

        /** pretty.e:128				if not integer(a[i]) or*/
        _2 = (object)SEQ_PTR(_a_1671);
        _732 = (object)*(((s1_ptr)_2)->base + _i_1708);
        if (IS_ATOM_INT(_732))
        _733 = 1;
        else if (IS_ATOM_DBL(_732))
        _733 = IS_ATOM_INT(DoubleToInt(_732));
        else
        _733 = 0;
        _732 = NOVALUE;
        _734 = (_733 == 0);
        _733 = NOVALUE;
        if (_734 != 0) {
            _735 = 1;
            goto LC; // [261] 313
        }
        _2 = (object)SEQ_PTR(_a_1671);
        _736 = (object)*(((s1_ptr)_2)->base + _i_1708);
        if (IS_ATOM_INT(_736)) {
            _737 = (_736 < _10pretty_ascii_min_1606);
        }
        else {
            _737 = binary_op(LESS, _736, _10pretty_ascii_min_1606);
        }
        _736 = NOVALUE;
        if (IS_ATOM_INT(_737)) {
            if (_737 == 0) {
                DeRef(_738);
                _738 = 0;
                goto LD; // [275] 309
            }
        }
        else {
            if (DBL_PTR(_737)->dbl == 0.0) {
                DeRef(_738);
                _738 = 0;
                goto LD; // [275] 309
            }
        }
        _739 = (_10pretty_ascii_1604 < 2LL);
        if (_739 != 0) {
            _740 = 1;
            goto LE; // [285] 305
        }
        _2 = (object)SEQ_PTR(_a_1671);
        _741 = (object)*(((s1_ptr)_2)->base + _i_1708);
        _743 = find_from(_741, _742, 1LL);
        _741 = NOVALUE;
        _744 = (_743 == 0);
        _743 = NOVALUE;
        _740 = (_744 != 0);
LE: 
        DeRef(_738);
        _738 = (_740 != 0);
LD: 
        _735 = (_738 != 0);
LC: 
        if (_735 != 0) {
            goto LF; // [313] 332
        }
        _2 = (object)SEQ_PTR(_a_1671);
        _746 = (object)*(((s1_ptr)_2)->base + _i_1708);
        if (IS_ATOM_INT(_746)) {
            _747 = (_746 > _10pretty_ascii_max_1607);
        }
        else {
            _747 = binary_op(GREATER, _746, _10pretty_ascii_max_1607);
        }
        _746 = NOVALUE;
        if (_747 == 0) {
            DeRef(_747);
            _747 = NOVALUE;
            goto L10; // [328] 338
        }
        else {
            if (!IS_ATOM_INT(_747) && DBL_PTR(_747)->dbl == 0.0){
                DeRef(_747);
                _747 = NOVALUE;
                goto L10; // [328] 338
            }
            DeRef(_747);
            _747 = NOVALUE;
        }
        DeRef(_747);
        _747 = NOVALUE;
LF: 

        /** pretty.e:132					all_ascii = 0*/
        _all_ascii_1674 = 0LL;
L10: 

        /** pretty.e:134			end for*/
        _i_1708 = _i_1708 + 1LL;
        goto L9; // [340] 206
LA: 
        ;
    }

    /** pretty.e:136			if all_ascii then*/
    if (_all_ascii_1674 == 0)
    {
        goto L11; // [347] 358
    }
    else{
    }

    /** pretty.e:137				pretty_out('\"')*/
    _10pretty_out(34LL);
    goto L12; // [355] 364
L11: 

    /** pretty.e:139				pretty_out('{')*/
    _10pretty_out(123LL);
L12: 

    /** pretty.e:141			pretty_level += 1*/
    _10pretty_level_1602 = _10pretty_level_1602 + 1;

    /** pretty.e:142			for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_1671)){
            _749 = SEQ_PTR(_a_1671)->length;
    }
    else {
        _749 = 1;
    }
    {
        object _i_1738;
        _i_1738 = 1LL;
L13: 
        if (_i_1738 > _749){
            goto L14; // [377] 497
        }

        /** pretty.e:143				if multi_line then*/
        if (_multi_line_1673 == 0)
        {
            goto L15; // [386] 394
        }
        else{
        }

        /** pretty.e:144					indent()*/
        _10indent();
L15: 

        /** pretty.e:146				if all_ascii then*/
        if (_all_ascii_1674 == 0)
        {
            goto L16; // [396] 415
        }
        else{
        }

        /** pretty.e:147					pretty_out(esc_char(a[i]))*/
        _2 = (object)SEQ_PTR(_a_1671);
        _750 = (object)*(((s1_ptr)_2)->base + _i_1738);
        Ref(_750);
        _751 = _10esc_char(_750);
        _750 = NOVALUE;
        _10pretty_out(_751);
        _751 = NOVALUE;
        goto L17; // [412] 425
L16: 

        /** pretty.e:149					rPrint(a[i])*/
        _2 = (object)SEQ_PTR(_a_1671);
        _752 = (object)*(((s1_ptr)_2)->base + _i_1738);
        Ref(_752);
        _10rPrint(_752);
        _752 = NOVALUE;
L17: 

        /** pretty.e:151				if pretty_line_count >= pretty_line_max then*/
        if (_10pretty_line_count_1608 < _10pretty_line_max_1609)
        goto L18; // [431] 459

        /** pretty.e:152					if not pretty_dots then*/
        if (_10pretty_dots_1610 != 0)
        goto L19; // [439] 448

        /** pretty.e:153						pretty_out(" ...")*/
        RefDS(_755);
        _10pretty_out(_755);
L19: 

        /** pretty.e:155					pretty_dots = 1*/
        _10pretty_dots_1610 = 1LL;

        /** pretty.e:156					return*/
        DeRef(_a_1671);
        DeRef(_sbuff_1672);
        DeRef(_716);
        _716 = NOVALUE;
        DeRef(_744);
        _744 = NOVALUE;
        DeRef(_707);
        _707 = NOVALUE;
        DeRef(_739);
        _739 = NOVALUE;
        DeRef(_709);
        _709 = NOVALUE;
        _729 = NOVALUE;
        DeRef(_734);
        _734 = NOVALUE;
        DeRef(_718);
        _718 = NOVALUE;
        DeRef(_737);
        _737 = NOVALUE;
        return;
L18: 

        /** pretty.e:158				if i != length(a) and not all_ascii then*/
        if (IS_SEQUENCE(_a_1671)){
                _756 = SEQ_PTR(_a_1671)->length;
        }
        else {
            _756 = 1;
        }
        _757 = (_i_1738 != _756);
        _756 = NOVALUE;
        if (_757 == 0) {
            goto L1A; // [468] 490
        }
        _759 = (_all_ascii_1674 == 0);
        if (_759 == 0)
        {
            DeRef(_759);
            _759 = NOVALUE;
            goto L1A; // [476] 490
        }
        else{
            DeRef(_759);
            _759 = NOVALUE;
        }

        /** pretty.e:159					pretty_out(',')*/
        _10pretty_out(44LL);

        /** pretty.e:160					cut_line(6)*/
        _10cut_line(6LL);
L1A: 

        /** pretty.e:162			end for*/
        _i_1738 = _i_1738 + 1LL;
        goto L13; // [492] 384
L14: 
        ;
    }

    /** pretty.e:163			pretty_level -= 1*/
    _10pretty_level_1602 = _10pretty_level_1602 - 1LL;

    /** pretty.e:164			if multi_line then*/
    if (_multi_line_1673 == 0)
    {
        goto L1B; // [507] 515
    }
    else{
    }

    /** pretty.e:165				indent()*/
    _10indent();
L1B: 

    /** pretty.e:167			if all_ascii then*/
    if (_all_ascii_1674 == 0)
    {
        goto L1C; // [517] 528
    }
    else{
    }

    /** pretty.e:168				pretty_out('\"')*/
    _10pretty_out(34LL);
    goto L1D; // [525] 534
L1C: 

    /** pretty.e:170				pretty_out('}')*/
    _10pretty_out(125LL);
L1D: 
L8: 

    /** pretty.e:173	end procedure*/
    DeRef(_a_1671);
    DeRef(_sbuff_1672);
    DeRef(_757);
    _757 = NOVALUE;
    DeRef(_716);
    _716 = NOVALUE;
    DeRef(_744);
    _744 = NOVALUE;
    DeRef(_707);
    _707 = NOVALUE;
    DeRef(_739);
    _739 = NOVALUE;
    DeRef(_709);
    _709 = NOVALUE;
    _729 = NOVALUE;
    DeRef(_734);
    _734 = NOVALUE;
    DeRef(_718);
    _718 = NOVALUE;
    DeRef(_737);
    _737 = NOVALUE;
    return;
    ;
}


void _10pretty(object _x_1780, object _options_1781)
{
    object _774 = NOVALUE;
    object _773 = NOVALUE;
    object _772 = NOVALUE;
    object _771 = NOVALUE;
    object _769 = NOVALUE;
    object _768 = NOVALUE;
    object _0, _1, _2;
    

    /** pretty.e:197		if length(options) < length( PRETTY_DEFAULT ) then*/
    if (IS_SEQUENCE(_options_1781)){
            _768 = SEQ_PTR(_options_1781)->length;
    }
    else {
        _768 = 1;
    }
    _769 = 10;
    if (_768 >= 10LL)
    goto L1; // [13] 41

    /** pretty.e:198			options &= PRETTY_DEFAULT[length(options)+1..$]*/
    if (IS_SEQUENCE(_options_1781)){
            _771 = SEQ_PTR(_options_1781)->length;
    }
    else {
        _771 = 1;
    }
    _772 = _771 + 1;
    _771 = NOVALUE;
    _773 = 10;
    rhs_slice_target = (object_ptr)&_774;
    RHS_Slice(_10PRETTY_DEFAULT_1766, _772, 10LL);
    Concat((object_ptr)&_options_1781, _options_1781, _774);
    DeRefDS(_774);
    _774 = NOVALUE;
L1: 

    /** pretty.e:202		pretty_ascii = options[DISPLAY_ASCII] */
    _2 = (object)SEQ_PTR(_options_1781);
    _10pretty_ascii_1604 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_10pretty_ascii_1604))
    _10pretty_ascii_1604 = (object)DBL_PTR(_10pretty_ascii_1604)->dbl;

    /** pretty.e:203		pretty_indent = options[INDENT]*/
    _2 = (object)SEQ_PTR(_options_1781);
    _10pretty_indent_1605 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_10pretty_indent_1605))
    _10pretty_indent_1605 = (object)DBL_PTR(_10pretty_indent_1605)->dbl;

    /** pretty.e:204		pretty_start_col = options[START_COLUMN]*/
    _2 = (object)SEQ_PTR(_options_1781);
    _10pretty_start_col_1601 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_10pretty_start_col_1601))
    _10pretty_start_col_1601 = (object)DBL_PTR(_10pretty_start_col_1601)->dbl;

    /** pretty.e:205		pretty_end_col = options[WRAP]*/
    _2 = (object)SEQ_PTR(_options_1781);
    _10pretty_end_col_1599 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_10pretty_end_col_1599))
    _10pretty_end_col_1599 = (object)DBL_PTR(_10pretty_end_col_1599)->dbl;

    /** pretty.e:206		pretty_int_format = options[INT_FORMAT]*/
    DeRef(_10pretty_int_format_1614);
    _2 = (object)SEQ_PTR(_options_1781);
    _10pretty_int_format_1614 = (object)*(((s1_ptr)_2)->base + 5LL);
    Ref(_10pretty_int_format_1614);

    /** pretty.e:207		pretty_fp_format = options[FP_FORMAT]*/
    DeRef(_10pretty_fp_format_1613);
    _2 = (object)SEQ_PTR(_options_1781);
    _10pretty_fp_format_1613 = (object)*(((s1_ptr)_2)->base + 6LL);
    Ref(_10pretty_fp_format_1613);

    /** pretty.e:208		pretty_ascii_min = options[MIN_ASCII]*/
    _2 = (object)SEQ_PTR(_options_1781);
    _10pretty_ascii_min_1606 = (object)*(((s1_ptr)_2)->base + 7LL);
    if (!IS_ATOM_INT(_10pretty_ascii_min_1606))
    _10pretty_ascii_min_1606 = (object)DBL_PTR(_10pretty_ascii_min_1606)->dbl;

    /** pretty.e:209		pretty_ascii_max = options[MAX_ASCII]*/
    _2 = (object)SEQ_PTR(_options_1781);
    _10pretty_ascii_max_1607 = (object)*(((s1_ptr)_2)->base + 8LL);
    if (!IS_ATOM_INT(_10pretty_ascii_max_1607))
    _10pretty_ascii_max_1607 = (object)DBL_PTR(_10pretty_ascii_max_1607)->dbl;

    /** pretty.e:210		pretty_line_max = options[MAX_LINES]*/
    _2 = (object)SEQ_PTR(_options_1781);
    _10pretty_line_max_1609 = (object)*(((s1_ptr)_2)->base + 9LL);
    if (!IS_ATOM_INT(_10pretty_line_max_1609))
    _10pretty_line_max_1609 = (object)DBL_PTR(_10pretty_line_max_1609)->dbl;

    /** pretty.e:211		pretty_line_breaks = options[LINE_BREAKS]*/
    _2 = (object)SEQ_PTR(_options_1781);
    _10pretty_line_breaks_1611 = (object)*(((s1_ptr)_2)->base + 10LL);
    if (!IS_ATOM_INT(_10pretty_line_breaks_1611))
    _10pretty_line_breaks_1611 = (object)DBL_PTR(_10pretty_line_breaks_1611)->dbl;

    /** pretty.e:213		pretty_chars = pretty_start_col*/
    _10pretty_chars_1600 = _10pretty_start_col_1601;

    /** pretty.e:215		pretty_level = 0 */
    _10pretty_level_1602 = 0LL;

    /** pretty.e:216		pretty_line = ""*/
    RefDS(_5);
    DeRef(_10pretty_line_1615);
    _10pretty_line_1615 = _5;

    /** pretty.e:217		pretty_line_count = 0*/
    _10pretty_line_count_1608 = 0LL;

    /** pretty.e:218		pretty_dots = 0*/
    _10pretty_dots_1610 = 0LL;

    /** pretty.e:219		rPrint(x)*/
    Ref(_x_1780);
    _10rPrint(_x_1780);

    /** pretty.e:220	end procedure*/
    DeRef(_x_1780);
    DeRefDS(_options_1781);
    DeRef(_772);
    _772 = NOVALUE;
    return;
    ;
}


void _10pretty_print(object _fn_1803, object _x_1804, object _options_1805)
{
    object _0, _1, _2;
    

    /** pretty.e:339		pretty_printing = 1*/
    _10pretty_printing_1612 = 1LL;

    /** pretty.e:340		pretty_file = fn*/
    _10pretty_file_1603 = _fn_1803;

    /** pretty.e:341		pretty( x, options )*/
    Ref(_x_1804);
    RefDS(_options_1805);
    _10pretty(_x_1804, _options_1805);

    /** pretty.e:342		puts(pretty_file, pretty_line)*/
    EPuts(_10pretty_file_1603, _10pretty_line_1615); // DJP 

    /** pretty.e:343	end procedure*/
    DeRef(_x_1804);
    DeRefDS(_options_1805);
    return;
    ;
}



// 0x345D8D9E
