// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _49screen_output(object _f_49704, object _msg_49705)
{
    object _0, _1, _2;
    

    /** error.e:44		puts(f, msg)*/
    EPuts(2LL, _msg_49705); // DJP 

    /** error.e:45	end procedure*/
    DeRefDS(_msg_49705);
    return;
    ;
}


void _49Warning(object _msg_49708, object _mask_49709, object _args_49710)
{
    object _orig_mask_49711 = NOVALUE;
    object _text_49712 = NOVALUE;
    object _w_name_49713 = NOVALUE;
    object _25578 = NOVALUE;
    object _25576 = NOVALUE;
    object _25574 = NOVALUE;
    object _25571 = NOVALUE;
    object _25566 = NOVALUE;
    object _25564 = NOVALUE;
    object _25563 = NOVALUE;
    object _25562 = NOVALUE;
    object _25561 = NOVALUE;
    object _25559 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:54		if display_warnings = 0 then*/
    if (_49display_warnings_49692 != 0LL)
    goto L1; // [9] 19

    /** error.e:55			return*/
    DeRef(_msg_49708);
    DeRefDS(_args_49710);
    DeRef(_text_49712);
    DeRef(_w_name_49713);
    return;
L1: 

    /** error.e:58		if not Strict_is_on or Strict_Override then*/
    _25559 = (_27Strict_is_on_20637 == 0);
    if (_25559 != 0) {
        goto L2; // [26] 37
    }
    if (_27Strict_Override_20638 == 0)
    {
        goto L3; // [33] 56
    }
    else{
    }
L2: 

    /** error.e:59			if find(mask, strict_only_warnings) then*/
    _25561 = find_from(_mask_49709, _27strict_only_warnings_20635, 1LL);
    if (_25561 == 0)
    {
        _25561 = NOVALUE;
        goto L4; // [46] 55
    }
    else{
        _25561 = NOVALUE;
    }

    /** error.e:60				return*/
    DeRef(_msg_49708);
    DeRefDS(_args_49710);
    DeRef(_text_49712);
    DeRef(_w_name_49713);
    DeRef(_25559);
    _25559 = NOVALUE;
    return;
L4: 
L3: 

    /** error.e:64		orig_mask = mask -- =0 for non maskable warnings - none implemented so far*/
    _orig_mask_49711 = _mask_49709;

    /** error.e:65		if Strict_is_on and Strict_Override = 0 then*/
    if (_27Strict_is_on_20637 == 0) {
        goto L5; // [65] 85
    }
    _25563 = (_27Strict_Override_20638 == 0LL);
    if (_25563 == 0)
    {
        DeRef(_25563);
        _25563 = NOVALUE;
        goto L5; // [76] 85
    }
    else{
        DeRef(_25563);
        _25563 = NOVALUE;
    }

    /** error.e:66			mask = 0*/
    _mask_49709 = 0LL;
L5: 

    /** error.e:69		if mask = 0 or and_bits(OpWarning, mask) then*/
    _25564 = (_mask_49709 == 0LL);
    if (_25564 != 0) {
        goto L6; // [91] 106
    }
    {uintptr_t tu;
         tu = (uintptr_t)_27OpWarning_20639 & (uintptr_t)_mask_49709;
         _25566 = MAKE_UINT(tu);
    }
    if (_25566 == 0) {
        DeRef(_25566);
        _25566 = NOVALUE;
        goto L7; // [102] 215
    }
    else {
        if (!IS_ATOM_INT(_25566) && DBL_PTR(_25566)->dbl == 0.0){
            DeRef(_25566);
            _25566 = NOVALUE;
            goto L7; // [102] 215
        }
        DeRef(_25566);
        _25566 = NOVALUE;
    }
    DeRef(_25566);
    _25566 = NOVALUE;
L6: 

    /** error.e:70			if orig_mask != 0 then*/
    if (_orig_mask_49711 == 0LL)
    goto L8; // [108] 122

    /** error.e:71				orig_mask = find(orig_mask,warning_flags)*/
    _orig_mask_49711 = find_from(_orig_mask_49711, _27warning_flags_20614, 1LL);
L8: 

    /** error.e:74			if orig_mask != 0 then*/
    if (_orig_mask_49711 == 0LL)
    goto L9; // [124] 145

    /** error.e:75				w_name = "{ " & warning_names[orig_mask] & " }"*/
    _2 = (object)SEQ_PTR(_27warning_names_20616);
    _25571 = (object)*(((s1_ptr)_2)->base + _orig_mask_49711);
    {
        object concat_list[3];

        concat_list[0] = _25572;
        concat_list[1] = _25571;
        concat_list[2] = _25570;
        Concat_N((object_ptr)&_w_name_49713, concat_list, 3);
    }
    _25571 = NOVALUE;
    goto LA; // [142] 153
L9: 

    /** error.e:77				w_name = "" -- not maskable*/
    RefDS(_22218);
    DeRef(_w_name_49713);
    _w_name_49713 = _22218;
LA: 

    /** error.e:80			if atom(msg) then*/
    _25574 = IS_ATOM(_msg_49708);
    if (_25574 == 0)
    {
        _25574 = NOVALUE;
        goto LB; // [158] 170
    }
    else{
        _25574 = NOVALUE;
    }

    /** error.e:81				msg = GetMsgText(msg, 1, args)*/
    Ref(_msg_49708);
    RefDS(_args_49710);
    _0 = _msg_49708;
    _msg_49708 = _30GetMsgText(_msg_49708, 1LL, _args_49710);
    DeRef(_0);
LB: 

    /** error.e:84			text = GetMsgText(WARNING_1T2, 0, {w_name, msg})*/
    Ref(_msg_49708);
    RefDS(_w_name_49713);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _w_name_49713;
    ((intptr_t *)_2)[2] = _msg_49708;
    _25576 = MAKE_SEQ(_1);
    _0 = _text_49712;
    _text_49712 = _30GetMsgText(204LL, 0LL, _25576);
    DeRef(_0);
    _25576 = NOVALUE;

    /** error.e:85			if find(text, warning_list) then*/
    _25578 = find_from(_text_49712, _49warning_list_49701, 1LL);
    if (_25578 == 0)
    {
        _25578 = NOVALUE;
        goto LC; // [197] 206
    }
    else{
        _25578 = NOVALUE;
    }

    /** error.e:86				return -- duplicate*/
    DeRef(_msg_49708);
    DeRefDS(_args_49710);
    DeRefDS(_text_49712);
    DeRefDS(_w_name_49713);
    DeRef(_25564);
    _25564 = NOVALUE;
    DeRef(_25559);
    _25559 = NOVALUE;
    return;
LC: 

    /** error.e:89			warning_list = append(warning_list, text)*/
    RefDS(_text_49712);
    Append(&_49warning_list_49701, _49warning_list_49701, _text_49712);
L7: 

    /** error.e:91	end procedure*/
    DeRef(_msg_49708);
    DeRefDS(_args_49710);
    DeRef(_text_49712);
    DeRef(_w_name_49713);
    DeRef(_25564);
    _25564 = NOVALUE;
    DeRef(_25559);
    _25559 = NOVALUE;
    return;
    ;
}


object _49ShowWarnings()
{
    object _c_49778 = NOVALUE;
    object _errfile_49779 = NOVALUE;
    object _twf_49780 = NOVALUE;
    object _25618 = NOVALUE;
    object _25614 = NOVALUE;
    object _25613 = NOVALUE;
    object _25612 = NOVALUE;
    object _25611 = NOVALUE;
    object _25610 = NOVALUE;
    object _25609 = NOVALUE;
    object _25607 = NOVALUE;
    object _25606 = NOVALUE;
    object _25605 = NOVALUE;
    object _25603 = NOVALUE;
    object _25602 = NOVALUE;
    object _25601 = NOVALUE;
    object _25600 = NOVALUE;
    object _25598 = NOVALUE;
    object _25594 = NOVALUE;
    object _25592 = NOVALUE;
    object _25591 = NOVALUE;
    object _25590 = NOVALUE;
    object _25588 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:117		if display_warnings = 0 or length(warning_list) = 0 then*/
    _25588 = (_49display_warnings_49692 == 0LL);
    if (_25588 != 0) {
        goto L1; // [9] 27
    }
    if (IS_SEQUENCE(_49warning_list_49701)){
            _25590 = SEQ_PTR(_49warning_list_49701)->length;
    }
    else {
        _25590 = 1;
    }
    _25591 = (_25590 == 0LL);
    _25590 = NOVALUE;
    if (_25591 == 0)
    {
        DeRef(_25591);
        _25591 = NOVALUE;
        goto L2; // [23] 39
    }
    else{
        DeRef(_25591);
        _25591 = NOVALUE;
    }
L1: 

    /** error.e:118			return length(warning_list)*/
    if (IS_SEQUENCE(_49warning_list_49701)){
            _25592 = SEQ_PTR(_49warning_list_49701)->length;
    }
    else {
        _25592 = 1;
    }
    DeRef(_25588);
    _25588 = NOVALUE;
    return _25592;
L2: 

    /** error.e:121		if TempErrFile > 0 then*/
    if (_49TempErrFile_49689 <= 0LL)
    goto L3; // [43] 57

    /** error.e:122			errfile = TempErrFile*/
    _errfile_49779 = _49TempErrFile_49689;
    goto L4; // [54] 67
L3: 

    /** error.e:124			errfile = STDERR*/
    _errfile_49779 = 2LL;
L4: 

    /** error.e:127		if not integer(TempWarningName) then*/
    if (IS_ATOM_INT(_27TempWarningName_20585))
    _25594 = 1;
    else if (IS_ATOM_DBL(_27TempWarningName_20585))
    _25594 = IS_ATOM_INT(DoubleToInt(_27TempWarningName_20585));
    else
    _25594 = 0;
    if (_25594 != 0)
    goto L5; // [74] 183
    _25594 = NOVALUE;

    /** error.e:128			twf = open(TempWarningName,"w")*/
    _twf_49780 = EOpen(_27TempWarningName_20585, _22363, 0LL);

    /** error.e:129			if twf = -1 then*/
    if (_twf_49780 != -1LL)
    goto L6; // [88] 140

    /** error.e:130				ShowMsg(errfile, UNABLE_TO_CREATE_WARNING_FILE_1, {TempWarningName})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_27TempWarningName_20585);
    ((intptr_t*)_2)[1] = _27TempWarningName_20585;
    _25598 = MAKE_SEQ(_1);
    _30ShowMsg(_errfile_49779, 205LL, _25598, 1LL);
    _25598 = NOVALUE;

    /** error.e:131				if errfile != STDERR then*/
    if (_errfile_49779 == 2LL)
    goto L7; // [114] 177

    /** error.e:132					ShowMsg(STDERR, UNABLE_TO_CREATE_WARNING_FILE_1, {TempWarningName})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_27TempWarningName_20585);
    ((intptr_t*)_2)[1] = _27TempWarningName_20585;
    _25600 = MAKE_SEQ(_1);
    _30ShowMsg(2LL, 205LL, _25600, 1LL);
    _25600 = NOVALUE;
    goto L7; // [137] 177
L6: 

    /** error.e:135				for i = 1 to length(warning_list) do*/
    if (IS_SEQUENCE(_49warning_list_49701)){
            _25601 = SEQ_PTR(_49warning_list_49701)->length;
    }
    else {
        _25601 = 1;
    }
    {
        object _i_49813;
        _i_49813 = 1LL;
L8: 
        if (_i_49813 > _25601){
            goto L9; // [147] 172
        }

        /** error.e:136					puts(twf, warning_list[i])*/
        _2 = (object)SEQ_PTR(_49warning_list_49701);
        _25602 = (object)*(((s1_ptr)_2)->base + _i_49813);
        EPuts(_twf_49780, _25602); // DJP 
        _25602 = NOVALUE;

        /** error.e:137				end for*/
        _i_49813 = _i_49813 + 1LL;
        goto L8; // [167] 154
L9: 
        ;
    }

    /** error.e:138			    close(twf)*/
    EClose(_twf_49780);
L7: 

    /** error.e:140			TempWarningName = 99 -- Flag that we have done this already.*/
    DeRef(_27TempWarningName_20585);
    _27TempWarningName_20585 = 99LL;
L5: 

    /** error.e:143		if batch_job = 0 or errfile != STDERR then*/
    _25603 = (_27batch_job_20584 == 0LL);
    if (_25603 != 0) {
        goto LA; // [191] 208
    }
    _25605 = (_errfile_49779 != 2LL);
    if (_25605 == 0)
    {
        DeRef(_25605);
        _25605 = NOVALUE;
        goto LB; // [204] 317
    }
    else{
        DeRef(_25605);
        _25605 = NOVALUE;
    }
LA: 

    /** error.e:144			for i = 1 to length(warning_list) do*/
    if (IS_SEQUENCE(_49warning_list_49701)){
            _25606 = SEQ_PTR(_49warning_list_49701)->length;
    }
    else {
        _25606 = 1;
    }
    {
        object _i_49824;
        _i_49824 = 1LL;
LC: 
        if (_i_49824 > _25606){
            goto LD; // [215] 316
        }

        /** error.e:145				puts(errfile, warning_list[i])*/
        _2 = (object)SEQ_PTR(_49warning_list_49701);
        _25607 = (object)*(((s1_ptr)_2)->base + _i_49824);
        EPuts(_errfile_49779, _25607); // DJP 
        _25607 = NOVALUE;

        /** error.e:146				if errfile = STDERR then*/
        if (_errfile_49779 != 2LL)
        goto LE; // [239] 309

        /** error.e:147					if remainder(i, 20) = 0 and batch_job = 0 and test_only = 0 then*/
        _25609 = (_i_49824 % 20LL);
        _25610 = (_25609 == 0LL);
        _25609 = NOVALUE;
        if (_25610 == 0) {
            _25611 = 0;
            goto LF; // [253] 267
        }
        _25612 = (_27batch_job_20584 == 0LL);
        _25611 = (_25612 != 0);
LF: 
        if (_25611 == 0) {
            goto L10; // [267] 308
        }
        _25614 = (_27test_only_20583 == 0LL);
        if (_25614 == 0)
        {
            DeRef(_25614);
            _25614 = NOVALUE;
            goto L10; // [278] 308
        }
        else{
            DeRef(_25614);
            _25614 = NOVALUE;
        }

        /** error.e:148						ShowMsg(errfile, PRESS_ENTER_TO_CONTINUE_Q_TO_QUIT)*/
        RefDS(_22218);
        _30ShowMsg(_errfile_49779, 206LL, _22218, 1LL);

        /** error.e:149						c = getc(0)*/
        if (0LL != last_r_file_no) {
            last_r_file_ptr = which_file(0LL, EF_READ);
            last_r_file_no = 0LL;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _c_49778 = getKBchar();
            }
            else{
                _c_49778 = getc(last_r_file_ptr);
            }
        }
        else{
            _c_49778 = getc(last_r_file_ptr);
        }

        /** error.e:150						if c = 'q' then*/
        if (_c_49778 != 113LL)
        goto L11; // [298] 307

        /** error.e:151							exit*/
        goto LD; // [304] 316
L11: 
L10: 
LE: 

        /** error.e:155			end for*/
        _i_49824 = _i_49824 + 1LL;
        goto LC; // [311] 222
LD: 
        ;
    }
LB: 

    /** error.e:158		return length(warning_list)*/
    if (IS_SEQUENCE(_49warning_list_49701)){
            _25618 = SEQ_PTR(_49warning_list_49701)->length;
    }
    else {
        _25618 = 1;
    }
    DeRef(_25588);
    _25588 = NOVALUE;
    DeRef(_25610);
    _25610 = NOVALUE;
    DeRef(_25603);
    _25603 = NOVALUE;
    DeRef(_25612);
    _25612 = NOVALUE;
    return _25618;
    ;
}


void _49ShowDefines(object _errfile_49848)
{
    object _c_49849 = NOVALUE;
    object _25632 = NOVALUE;
    object _25631 = NOVALUE;
    object _25629 = NOVALUE;
    object _25628 = NOVALUE;
    object _25625 = NOVALUE;
    object _25624 = NOVALUE;
    object _25623 = NOVALUE;
    object _25622 = NOVALUE;
    object _25621 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:164		if errfile=0 then*/
    if (_errfile_49848 != 0LL)
    goto L1; // [5] 19

    /** error.e:165			errfile = STDERR*/
    _errfile_49848 = 2LL;
L1: 

    /** error.e:168		puts(errfile, format("\n--- [1] ---\n", {GetMsgText(DEFINED_WORDS,0)}))*/
    RefDS(_22218);
    _25621 = _30GetMsgText(207LL, 0LL, _22218);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _25621;
    _25622 = MAKE_SEQ(_1);
    _25621 = NOVALUE;
    RefDS(_25620);
    _25623 = _12format(_25620, _25622);
    _25622 = NOVALUE;
    EPuts(_errfile_49848, _25623); // DJP 
    DeRef(_25623);
    _25623 = NOVALUE;

    /** error.e:170		for i = 1 to length(OpDefines) do*/
    if (IS_SEQUENCE(_27OpDefines_20645)){
            _25624 = SEQ_PTR(_27OpDefines_20645)->length;
    }
    else {
        _25624 = 1;
    }
    {
        object _i_49861;
        _i_49861 = 1LL;
L2: 
        if (_i_49861 > _25624){
            goto L3; // [48] 100
        }

        /** error.e:171			if find(OpDefines[i], {"_PLAT_START", "_PLAT_STOP"}) = 0 then*/
        _2 = (object)SEQ_PTR(_27OpDefines_20645);
        _25625 = (object)*(((s1_ptr)_2)->base + _i_49861);
        RefDS(_25627);
        RefDS(_25626);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _25626;
        ((intptr_t *)_2)[2] = _25627;
        _25628 = MAKE_SEQ(_1);
        _25629 = find_from(_25625, _25628, 1LL);
        _25625 = NOVALUE;
        DeRefDS(_25628);
        _25628 = NOVALUE;
        if (_25629 != 0LL)
        goto L4; // [72] 93

        /** error.e:172				printf(errfile, "%s\n", {OpDefines[i]})*/
        _2 = (object)SEQ_PTR(_27OpDefines_20645);
        _25631 = (object)*(((s1_ptr)_2)->base + _i_49861);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_25631);
        ((intptr_t*)_2)[1] = _25631;
        _25632 = MAKE_SEQ(_1);
        _25631 = NOVALUE;
        EPrintf(_errfile_49848, _25511, _25632);
        DeRefDS(_25632);
        _25632 = NOVALUE;
L4: 

        /** error.e:174		end for*/
        _i_49861 = _i_49861 + 1LL;
        goto L2; // [95] 55
L3: 
        ;
    }

    /** error.e:175		puts(errfile, "-------------------\n")*/
    EPuts(_errfile_49848, _25633); // DJP 

    /** error.e:177	end procedure*/
    return;
    ;
}


void _49Cleanup(object _status_49878)
{
    object _w_49879 = NOVALUE;
    object _show_error_49880 = NOVALUE;
    object _32062 = NOVALUE;
    object _25651 = NOVALUE;
    object _25650 = NOVALUE;
    object _25649 = NOVALUE;
    object _25648 = NOVALUE;
    object _25647 = NOVALUE;
    object _25646 = NOVALUE;
    object _25645 = NOVALUE;
    object _25644 = NOVALUE;
    object _25643 = NOVALUE;
    object _25642 = NOVALUE;
    object _25640 = NOVALUE;
    object _25639 = NOVALUE;
    object _25638 = NOVALUE;
    object _25637 = NOVALUE;
    object _25636 = NOVALUE;
    object _25634 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_status_49878)) {
        _1 = (object)(DBL_PTR(_status_49878)->dbl);
        DeRefDS(_status_49878);
        _status_49878 = _1;
    }

    /** error.e:182		integer w, show_error = 0*/
    _show_error_49880 = 0LL;

    /** error.e:184		ifdef EU_EX then*/

    /** error.e:187			write_coverage_db()*/
    _32062 = _50write_coverage_db();
    DeRef(_32062);
    _32062 = NOVALUE;

    /** error.e:190		show_error = 1*/
    _show_error_49880 = 1LL;

    /** error.e:196		if object(src_file) = 0 then*/
    if( NOVALUE == _27src_file_20693 ){
        _25634 = 0;
    }
    else{
        _25634 = 1;
    }
    if (_25634 != 0LL)
    goto L1; // [27] 41

    /** error.e:197			src_file = -1*/
    _27src_file_20693 = -1LL;
    goto L2; // [38] 93
L1: 

    /** error.e:198		elsif src_file >= 0 and (src_file != repl_file or not repl) then*/
    _25636 = (_27src_file_20693 >= 0LL);
    if (_25636 == 0) {
        goto L3; // [49] 92
    }
    _25638 = (_27src_file_20693 != 5555LL);
    if (_25638 != 0) {
        DeRef(_25639);
        _25639 = 1;
        goto L4; // [61] 74
    }
    _25640 = (0LL == 0);
    _25639 = (_25640 != 0);
L4: 
    if (_25639 == 0)
    {
        _25639 = NOVALUE;
        goto L3; // [75] 92
    }
    else{
        _25639 = NOVALUE;
    }

    /** error.e:199			close(src_file)*/
    EClose(_27src_file_20693);

    /** error.e:200			src_file = -1*/
    _27src_file_20693 = -1LL;
L3: 
L2: 

    /** error.e:203		w = ShowWarnings()*/
    _w_49879 = _49ShowWarnings();
    if (!IS_ATOM_INT(_w_49879)) {
        _1 = (object)(DBL_PTR(_w_49879)->dbl);
        DeRefDS(_w_49879);
        _w_49879 = _1;
    }

    /** error.e:204		if not TRANSLATE and (BIND or show_error) and (w or Errors) then*/
    _25642 = (_27TRANSLATE_20179 == 0);
    if (_25642 == 0) {
        _25643 = 0;
        goto L5; // [107] 125
    }
    if (_27BIND_20182 != 0) {
        _25644 = 1;
        goto L6; // [113] 121
    }
    _25644 = (_show_error_49880 != 0);
L6: 
    _25643 = (_25644 != 0);
L5: 
    if (_25643 == 0) {
        goto L7; // [125] 186
    }
    if (_w_49879 != 0) {
        DeRef(_25646);
        _25646 = 1;
        goto L8; // [129] 139
    }
    _25646 = (_49Errors_49688 != 0);
L8: 
    if (_25646 == 0)
    {
        _25646 = NOVALUE;
        goto L7; // [140] 186
    }
    else{
        _25646 = NOVALUE;
    }

    /** error.e:205			if not batch_job and not test_only then*/
    _25647 = (_27batch_job_20584 == 0);
    if (_25647 == 0) {
        goto L9; // [150] 185
    }
    _25649 = (_27test_only_20583 == 0);
    if (_25649 == 0)
    {
        DeRef(_25649);
        _25649 = NOVALUE;
        goto L9; // [160] 185
    }
    else{
        DeRef(_25649);
        _25649 = NOVALUE;
    }

    /** error.e:206				screen_output(STDERR, GetMsgText(PRESS_ENTER,0))*/
    RefDS(_22218);
    _25650 = _30GetMsgText(208LL, 0LL, _22218);
    _49screen_output(2LL, _25650);
    _25650 = NOVALUE;

    /** error.e:207				getc(0) -- wait*/
    if (0LL != last_r_file_no) {
        last_r_file_ptr = which_file(0LL, EF_READ);
        last_r_file_no = 0LL;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _25651 = getKBchar();
        }
        else{
            _25651 = getc(last_r_file_ptr);
        }
    }
    else{
        _25651 = getc(last_r_file_ptr);
    }
L9: 
L7: 

    /** error.e:212		cleanup_open_includes()*/
    _61cleanup_open_includes();

    /** error.e:213		abort(status)*/
    UserCleanup(_status_49878);

    /** error.e:214	end procedure*/
    DeRef(_25640);
    _25640 = NOVALUE;
    DeRef(_25636);
    _25636 = NOVALUE;
    DeRef(_25642);
    _25642 = NOVALUE;
    DeRef(_25647);
    _25647 = NOVALUE;
    DeRef(_25638);
    _25638 = NOVALUE;
    return;
    ;
}


void _49OpenErrFile()
{
    object _25658 = NOVALUE;
    object _25657 = NOVALUE;
    object _25655 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:219	    if TempErrFile != -1 then*/
    if (_49TempErrFile_49689 == -1LL)
    goto L1; // [5] 19

    /** error.e:220			TempErrFile = open(TempErrName, "w")*/
    _49TempErrFile_49689 = EOpen(_49TempErrName_49691, _22363, 0LL);
L1: 

    /** error.e:223		if TempErrFile = -1 then*/
    if (_49TempErrFile_49689 != -1LL)
    goto L2; // [23] 66

    /** error.e:224			if length(TempErrName) > 0 then*/
    _25655 = 6;

    /** error.e:225				screen_output(STDERR, GetMsgText(CANT_CREATE_ERROR_MESSAGE_FILE_1, 0, {TempErrName}))*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_49TempErrName_49691);
    ((intptr_t*)_2)[1] = _49TempErrName_49691;
    _25657 = MAKE_SEQ(_1);
    _25658 = _30GetMsgText(209LL, 0LL, _25657);
    _25657 = NOVALUE;
    _49screen_output(2LL, _25658);
    _25658 = NOVALUE;

    /** error.e:227			abort(1) -- with no clean up*/
    UserCleanup(1LL);
L2: 

    /** error.e:229	end procedure*/
    return;
    ;
}


void _49ShowErr(object _f_49937)
{
    object _msg_inlined_screen_output_at_43_49950 = NOVALUE;
    object _25665 = NOVALUE;
    object _25664 = NOVALUE;
    object _25663 = NOVALUE;
    object _25661 = NOVALUE;
    object _25659 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:234		if length(known_files) = 0 then*/
    if (IS_SEQUENCE(_28known_files_11573)){
            _25659 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _25659 = 1;
    }
    if (_25659 != 0LL)
    goto L1; // [10] 20

    /** error.e:235			return*/
    return;
L1: 

    /** error.e:238		if ThisLine[1] = END_OF_FILE_CHAR then*/
    _2 = (object)SEQ_PTR(_49ThisLine_49693);
    _25661 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _25661, 26LL)){
        _25661 = NOVALUE;
        goto L2; // [30] 64
    }
    _25661 = NOVALUE;

    /** error.e:239			screen_output(f, GetMsgText(MSG_ENDOFFILE,0))*/
    RefDS(_22218);
    _25663 = _30GetMsgText(210LL, 0LL, _22218);
    DeRef(_msg_inlined_screen_output_at_43_49950);
    _msg_inlined_screen_output_at_43_49950 = _25663;
    _25663 = NOVALUE;

    /** error.e:44		puts(f, msg)*/
    EPuts(_f_49937, _msg_inlined_screen_output_at_43_49950); // DJP 

    /** error.e:45	end procedure*/
    goto L3; // [56] 59
L3: 
    DeRef(_msg_inlined_screen_output_at_43_49950);
    _msg_inlined_screen_output_at_43_49950 = NOVALUE;
    goto L4; // [61] 81
L2: 

    /** error.e:241			screen_output(f, ThisLine)*/

    /** error.e:44		puts(f, msg)*/
    EPuts(_f_49937, _49ThisLine_49693); // DJP 

    /** error.e:45	end procedure*/
    goto L5; // [77] 80
L5: 
L4: 

    /** error.e:244		for i = 1 to bp-2 do -- bp-1 points to last character read*/
    _25664 = _49bp_49697 - 2LL;
    if ((object)((uintptr_t)_25664 +(uintptr_t) HIGH_BITS) >= 0){
        _25664 = NewDouble((eudouble)_25664);
    }
    {
        object _i_49954;
        _i_49954 = 1LL;
L6: 
        if (binary_op_a(GREATER, _i_49954, _25664)){
            goto L7; // [89] 143
        }

        /** error.e:245			if ThisLine[i] = '\t' then*/
        _2 = (object)SEQ_PTR(_49ThisLine_49693);
        if (!IS_ATOM_INT(_i_49954)){
            _25665 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_49954)->dbl));
        }
        else{
            _25665 = (object)*(((s1_ptr)_2)->base + _i_49954);
        }
        if (binary_op_a(NOTEQ, _25665, 9LL)){
            _25665 = NOVALUE;
            goto L8; // [104] 123
        }
        _25665 = NOVALUE;

        /** error.e:246				screen_output(f, "\t")*/

        /** error.e:44		puts(f, msg)*/
        EPuts(_f_49937, _24206); // DJP 

        /** error.e:45	end procedure*/
        goto L9; // [117] 136
        goto L9; // [120] 136
L8: 

        /** error.e:248				screen_output(f, " ")*/

        /** error.e:44		puts(f, msg)*/
        EPuts(_f_49937, _23627); // DJP 

        /** error.e:45	end procedure*/
        goto LA; // [132] 135
LA: 
L9: 

        /** error.e:250		end for*/
        _0 = _i_49954;
        if (IS_ATOM_INT(_i_49954)) {
            _i_49954 = _i_49954 + 1LL;
            if ((object)((uintptr_t)_i_49954 +(uintptr_t) HIGH_BITS) >= 0){
                _i_49954 = NewDouble((eudouble)_i_49954);
            }
        }
        else {
            _i_49954 = binary_op_a(PLUS, _i_49954, 1LL);
        }
        DeRef(_0);
        goto L6; // [138] 96
L7: 
        ;
        DeRef(_i_49954);
    }

    /** error.e:252		screen_output(f, "^\n\n")*/

    /** error.e:44		puts(f, msg)*/
    EPuts(_f_49937, _25667); // DJP 

    /** error.e:45	end procedure*/
    goto LB; // [152] 155
LB: 

    /** error.e:253	end procedure*/
    DeRef(_25664);
    _25664 = NOVALUE;
    return;
    ;
}


void _49CompileErr(object _msg_49966, object _args_49967, object _preproc_49968)
{
    object _errmsg_49969 = NOVALUE;
    object _25688 = NOVALUE;
    object _25684 = NOVALUE;
    object _25683 = NOVALUE;
    object _25682 = NOVALUE;
    object _25681 = NOVALUE;
    object _25680 = NOVALUE;
    object _25679 = NOVALUE;
    object _25677 = NOVALUE;
    object _25676 = NOVALUE;
    object _25674 = NOVALUE;
    object _25673 = NOVALUE;
    object _25672 = NOVALUE;
    object _25668 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:260		if integer(msg) then*/
    if (IS_ATOM_INT(_msg_49966))
    _25668 = 1;
    else if (IS_ATOM_DBL(_msg_49966))
    _25668 = IS_ATOM_INT(DoubleToInt(_msg_49966));
    else
    _25668 = 0;
    if (_25668 == 0)
    {
        _25668 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _25668 = NOVALUE;
    }

    /** error.e:261			msg = GetMsgText(msg)*/
    Ref(_msg_49966);
    RefDS(_22218);
    _0 = _msg_49966;
    _msg_49966 = _30GetMsgText(_msg_49966, 1LL, _22218);
    DeRefi(_0);
L1: 

    /** error.e:264		msg = format(msg, args)*/
    Ref(_msg_49966);
    Ref(_args_49967);
    _0 = _msg_49966;
    _msg_49966 = _12format(_msg_49966, _args_49967);
    DeRef(_0);

    /** error.e:266		Errors += 1*/
    _49Errors_49688 = _49Errors_49688 + 1;

    /** error.e:267		if not preproc and length(known_files) then*/
    _25672 = (_preproc_49968 == 0);
    if (_25672 == 0) {
        goto L2; // [40] 78
    }
    if (IS_SEQUENCE(_28known_files_11573)){
            _25674 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _25674 = 1;
    }
    if (_25674 == 0)
    {
        _25674 = NOVALUE;
        goto L2; // [50] 78
    }
    else{
        _25674 = NOVALUE;
    }

    /** error.e:268			errmsg = sprintf("%s:%d\n%s\n", {known_files[current_file_no],*/
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _25676 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_25676);
    ((intptr_t*)_2)[1] = _25676;
    ((intptr_t*)_2)[2] = _27line_number_20572;
    Ref(_msg_49966);
    ((intptr_t*)_2)[3] = _msg_49966;
    _25677 = MAKE_SEQ(_1);
    _25676 = NOVALUE;
    DeRef(_errmsg_49969);
    _errmsg_49969 = EPrintf(-9999999, _25675, _25677);
    DeRefDS(_25677);
    _25677 = NOVALUE;
    goto L3; // [75] 121
L2: 

    /** error.e:271			errmsg = msg*/
    Ref(_msg_49966);
    DeRef(_errmsg_49969);
    _errmsg_49969 = _msg_49966;

    /** error.e:272			if length(msg) > 0 and msg[$] != '\n' then*/
    if (IS_SEQUENCE(_msg_49966)){
            _25679 = SEQ_PTR(_msg_49966)->length;
    }
    else {
        _25679 = 1;
    }
    _25680 = (_25679 > 0LL);
    _25679 = NOVALUE;
    if (_25680 == 0) {
        goto L4; // [94] 120
    }
    if (IS_SEQUENCE(_msg_49966)){
            _25682 = SEQ_PTR(_msg_49966)->length;
    }
    else {
        _25682 = 1;
    }
    _2 = (object)SEQ_PTR(_msg_49966);
    _25683 = (object)*(((s1_ptr)_2)->base + _25682);
    if (IS_ATOM_INT(_25683)) {
        _25684 = (_25683 != 10LL);
    }
    else {
        _25684 = binary_op(NOTEQ, _25683, 10LL);
    }
    _25683 = NOVALUE;
    if (_25684 == 0) {
        DeRef(_25684);
        _25684 = NOVALUE;
        goto L4; // [110] 120
    }
    else {
        if (!IS_ATOM_INT(_25684) && DBL_PTR(_25684)->dbl == 0.0){
            DeRef(_25684);
            _25684 = NOVALUE;
            goto L4; // [110] 120
        }
        DeRef(_25684);
        _25684 = NOVALUE;
    }
    DeRef(_25684);
    _25684 = NOVALUE;

    /** error.e:273				errmsg &= '\n'*/
    Append(&_errmsg_49969, _errmsg_49969, 10LL);
L4: 
L3: 

    /** error.e:277		if not preproc then*/
    if (_preproc_49968 != 0)
    goto L5; // [123] 131

    /** error.e:279			OpenErrFile() -- exits if error filename is ""*/
    _49OpenErrFile();
L5: 

    /** error.e:281		screen_output(STDERR, errmsg)*/
    RefDS(_errmsg_49969);
    _49screen_output(2LL, _errmsg_49969);

    /** error.e:283		if not preproc then*/
    if (_preproc_49968 != 0)
    goto L6; // [143] 198

    /** error.e:284			ShowErr(STDERR)*/
    _49ShowErr(2LL);

    /** error.e:286			puts(TempErrFile, errmsg)*/
    EPuts(_49TempErrFile_49689, _errmsg_49969); // DJP 

    /** error.e:288			ShowErr(TempErrFile)*/
    _49ShowErr(_49TempErrFile_49689);

    /** error.e:290			ShowWarnings()*/
    _25688 = _49ShowWarnings();

    /** error.e:292			ShowDefines(TempErrFile)*/
    _49ShowDefines(_49TempErrFile_49689);

    /** error.e:294			close(TempErrFile)*/
    EClose(_49TempErrFile_49689);

    /** error.e:295			TempErrFile = -2*/
    _49TempErrFile_49689 = -2LL;

    /** error.e:296			ifdef CRASH_ON_ERROR then*/

    /** error.e:299			Cleanup(1)*/
    _49Cleanup(1LL);
L6: 

    /** error.e:302	end procedure*/
    DeRef(_msg_49966);
    DeRef(_args_49967);
    DeRef(_errmsg_49969);
    DeRef(_25680);
    _25680 = NOVALUE;
    DeRef(_25688);
    _25688 = NOVALUE;
    DeRef(_25672);
    _25672 = NOVALUE;
    return;
    ;
}


void _49InternalErr(object _msgno_50013, object _args_50014)
{
    object _msg_50015 = NOVALUE;
    object _25704 = NOVALUE;
    object _25702 = NOVALUE;
    object _25701 = NOVALUE;
    object _25700 = NOVALUE;
    object _25699 = NOVALUE;
    object _25698 = NOVALUE;
    object _25697 = NOVALUE;
    object _25696 = NOVALUE;
    object _25695 = NOVALUE;
    object _25694 = NOVALUE;
    object _25693 = NOVALUE;
    object _25690 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:316		if atom(args) then*/
    _25690 = 0;
    if (_25690 == 0)
    {
        _25690 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _25690 = NOVALUE;
    }

    /** error.e:317			args = {args}*/
    _0 = _args_50014;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_args_50014);
    ((intptr_t*)_2)[1] = _args_50014;
    _args_50014 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1: 

    /** error.e:320		msg = GetMsgText(msgno, 1, args)*/
    Ref(_args_50014);
    _0 = _msg_50015;
    _msg_50015 = _30GetMsgText(_msgno_50013, 1LL, _args_50014);
    DeRef(_0);

    /** error.e:321		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L2; // [32] 58
    }
    else{
    }

    /** error.e:322			screen_output(STDERR, GetMsgText(INTERNAL_ERRORT1, 1, {msg}))*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_msg_50015);
    ((intptr_t*)_2)[1] = _msg_50015;
    _25693 = MAKE_SEQ(_1);
    _25694 = _30GetMsgText(211LL, 1LL, _25693);
    _25693 = NOVALUE;
    _49screen_output(2LL, _25694);
    _25694 = NOVALUE;
    goto L3; // [55] 91
L2: 

    /** error.e:324			screen_output(STDERR, GetMsgText(INTERNAL_ERROR_AT_12T3, 1, {known_files[current_file_no], line_number, msg}))*/
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _25695 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_25695);
    ((intptr_t*)_2)[1] = _25695;
    ((intptr_t*)_2)[2] = _27line_number_20572;
    RefDS(_msg_50015);
    ((intptr_t*)_2)[3] = _msg_50015;
    _25696 = MAKE_SEQ(_1);
    _25695 = NOVALUE;
    _25697 = _30GetMsgText(212LL, 1LL, _25696);
    _25696 = NOVALUE;
    _49screen_output(2LL, _25697);
    _25697 = NOVALUE;
L3: 

    /** error.e:327		if not batch_job and not test_only then*/
    _25698 = (_27batch_job_20584 == 0);
    if (_25698 == 0) {
        goto L4; // [98] 133
    }
    _25700 = (_27test_only_20583 == 0);
    if (_25700 == 0)
    {
        DeRef(_25700);
        _25700 = NOVALUE;
        goto L4; // [108] 133
    }
    else{
        DeRef(_25700);
        _25700 = NOVALUE;
    }

    /** error.e:328			screen_output(STDERR, GetMsgText(PRESS_ENTER, 0))*/
    RefDS(_22218);
    _25701 = _30GetMsgText(208LL, 0LL, _22218);
    _49screen_output(2LL, _25701);
    _25701 = NOVALUE;

    /** error.e:329			getc(0)*/
    if (0LL != last_r_file_no) {
        last_r_file_ptr = which_file(0LL, EF_READ);
        last_r_file_no = 0LL;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _25702 = getKBchar();
        }
        else{
            _25702 = getc(last_r_file_ptr);
        }
    }
    else{
        _25702 = getc(last_r_file_ptr);
    }
L4: 

    /** error.e:333		machine_proc(67, GetMsgText(FAILED_DUE_TO_INTERNAL_ERROR))*/
    RefDS(_22218);
    _25704 = _30GetMsgText(213LL, 1LL, _22218);
    machine(67LL, _25704);
    DeRef(_25704);
    _25704 = NOVALUE;

    /** error.e:334	end procedure*/
    DeRef(_args_50014);
    DeRef(_msg_50015);
    DeRef(_25698);
    _25698 = NOVALUE;
    return;
    ;
}



// 0x113ED648
