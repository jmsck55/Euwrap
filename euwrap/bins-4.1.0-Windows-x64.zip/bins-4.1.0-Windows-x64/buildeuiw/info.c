// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _40arch_bits()
{
    object _8538 = NOVALUE;
    object _8537 = NOVALUE;
    object _8536 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:72		return sprintf( "%d-bit", 8 * sizeof( C_POINTER ) )*/
    _8536 = eu_sizeof( 50331649LL );
    {
        int128_t p128 = (int128_t)8LL * (int128_t)_8536;
        if( p128 != (int128_t)(_8537 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
            _8537 = NewDouble( (eudouble)p128 );
        }
    }
    _8536 = NOVALUE;
    _8538 = EPrintf(-9999999, _8535, _8537);
    DeRef(_8537);
    _8537 = NOVALUE;
    return _8538;
    ;
}


object _40version_major()
{
    object _8547 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:100		return version_info[MAJ_VER]*/
    _2 = (object)SEQ_PTR(_40version_info_14895);
    _8547 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_8547);
    return _8547;
    ;
}


object _40version_minor()
{
    object _8548 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:112		return version_info[MIN_VER]*/
    _2 = (object)SEQ_PTR(_40version_info_14895);
    _8548 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_8548);
    return _8548;
    ;
}


object _40version_patch()
{
    object _8549 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:124		return version_info[PAT_VER]*/
    _2 = (object)SEQ_PTR(_40version_info_14895);
    _8549 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_8549);
    return _8549;
    ;
}


object _40version_node(object _full_14940)
{
    object _8556 = NOVALUE;
    object _8555 = NOVALUE;
    object _8554 = NOVALUE;
    object _8553 = NOVALUE;
    object _8552 = NOVALUE;
    object _8551 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:141		if full or length(version_info[NODE]) < 12 then*/
    if (0LL != 0) {
        goto L1; // [5] 27
    }
    _2 = (object)SEQ_PTR(_40version_info_14895);
    _8551 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (IS_SEQUENCE(_8551)){
            _8552 = SEQ_PTR(_8551)->length;
    }
    else {
        _8552 = 1;
    }
    _8551 = NOVALUE;
    _8553 = (_8552 < 12LL);
    _8552 = NOVALUE;
    if (_8553 == 0)
    {
        DeRef(_8553);
        _8553 = NOVALUE;
        goto L2; // [23] 40
    }
    else{
        DeRef(_8553);
        _8553 = NOVALUE;
    }
L1: 

    /** info.e:142			return version_info[NODE]*/
    _2 = (object)SEQ_PTR(_40version_info_14895);
    _8554 = (object)*(((s1_ptr)_2)->base + 5LL);
    Ref(_8554);
    _8551 = NOVALUE;
    return _8554;
L2: 

    /** info.e:145		return version_info[NODE][1..12]*/
    _2 = (object)SEQ_PTR(_40version_info_14895);
    _8555 = (object)*(((s1_ptr)_2)->base + 5LL);
    rhs_slice_target = (object_ptr)&_8556;
    RHS_Slice(_8555, 1LL, 12LL);
    _8555 = NOVALUE;
    _8554 = NOVALUE;
    _8551 = NOVALUE;
    return _8556;
    ;
}


object _40version_date(object _full_14954)
{
    object _8565 = NOVALUE;
    object _8564 = NOVALUE;
    object _8563 = NOVALUE;
    object _8562 = NOVALUE;
    object _8561 = NOVALUE;
    object _8560 = NOVALUE;
    object _8558 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:181		if full or is_developmental or length(version_info[REVISION_DATE]) < 10 then*/
    if (_full_14954 != 0) {
        _8558 = 1;
        goto L1; // [5] 15
    }
    _8558 = (_40is_developmental_14897 != 0);
L1: 
    if (_8558 != 0) {
        goto L2; // [15] 37
    }
    _2 = (object)SEQ_PTR(_40version_info_14895);
    _8560 = (object)*(((s1_ptr)_2)->base + 7LL);
    if (IS_SEQUENCE(_8560)){
            _8561 = SEQ_PTR(_8560)->length;
    }
    else {
        _8561 = 1;
    }
    _8560 = NOVALUE;
    _8562 = (_8561 < 10LL);
    _8561 = NOVALUE;
    if (_8562 == 0)
    {
        DeRef(_8562);
        _8562 = NOVALUE;
        goto L3; // [33] 50
    }
    else{
        DeRef(_8562);
        _8562 = NOVALUE;
    }
L2: 

    /** info.e:182			return version_info[REVISION_DATE]*/
    _2 = (object)SEQ_PTR(_40version_info_14895);
    _8563 = (object)*(((s1_ptr)_2)->base + 7LL);
    Ref(_8563);
    _8560 = NOVALUE;
    return _8563;
L3: 

    /** info.e:185		return version_info[REVISION_DATE][1..10]*/
    _2 = (object)SEQ_PTR(_40version_info_14895);
    _8564 = (object)*(((s1_ptr)_2)->base + 7LL);
    rhs_slice_target = (object_ptr)&_8565;
    RHS_Slice(_8564, 1LL, 10LL);
    _8564 = NOVALUE;
    _8563 = NOVALUE;
    _8560 = NOVALUE;
    return _8565;
    ;
}


object _40version_string(object _full_14969)
{
    object _version_revision_inlined_version_revision_at_41_14978 = NOVALUE;
    object _8585 = NOVALUE;
    object _8584 = NOVALUE;
    object _8583 = NOVALUE;
    object _8582 = NOVALUE;
    object _8581 = NOVALUE;
    object _8580 = NOVALUE;
    object _8579 = NOVALUE;
    object _8578 = NOVALUE;
    object _8576 = NOVALUE;
    object _8575 = NOVALUE;
    object _8574 = NOVALUE;
    object _8573 = NOVALUE;
    object _8572 = NOVALUE;
    object _8571 = NOVALUE;
    object _8570 = NOVALUE;
    object _8569 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:225		if full or is_developmental then*/
    if (0LL != 0) {
        goto L1; // [5] 16
    }
    if (_40is_developmental_14897 == 0)
    {
        goto L2; // [12] 80
    }
    else{
    }
L1: 

    /** info.e:226			return sprintf("%d.%d.%d %s (%d:%s, %s)", {*/
    _2 = (object)SEQ_PTR(_40version_info_14895);
    _8569 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_40version_info_14895);
    _8570 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_40version_info_14895);
    _8571 = (object)*(((s1_ptr)_2)->base + 3LL);
    _2 = (object)SEQ_PTR(_40version_info_14895);
    _8572 = (object)*(((s1_ptr)_2)->base + 4LL);

    /** info.e:157		return version_info[REVISION]*/
    DeRef(_version_revision_inlined_version_revision_at_41_14978);
    _2 = (object)SEQ_PTR(_40version_info_14895);
    _version_revision_inlined_version_revision_at_41_14978 = (object)*(((s1_ptr)_2)->base + 6LL);
    Ref(_version_revision_inlined_version_revision_at_41_14978);
    _8573 = _40version_node(0LL);
    _8574 = _40version_date(_full_14969);
    _1 = NewS1(7);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_8569);
    ((intptr_t*)_2)[1] = _8569;
    Ref(_8570);
    ((intptr_t*)_2)[2] = _8570;
    Ref(_8571);
    ((intptr_t*)_2)[3] = _8571;
    Ref(_8572);
    ((intptr_t*)_2)[4] = _8572;
    Ref(_version_revision_inlined_version_revision_at_41_14978);
    ((intptr_t*)_2)[5] = _version_revision_inlined_version_revision_at_41_14978;
    ((intptr_t*)_2)[6] = _8573;
    ((intptr_t*)_2)[7] = _8574;
    _8575 = MAKE_SEQ(_1);
    _8574 = NOVALUE;
    _8573 = NOVALUE;
    _8572 = NOVALUE;
    _8571 = NOVALUE;
    _8570 = NOVALUE;
    _8569 = NOVALUE;
    _8576 = EPrintf(-9999999, _8568, _8575);
    DeRefDS(_8575);
    _8575 = NOVALUE;
    return _8576;
    goto L3; // [77] 132
L2: 

    /** info.e:236			return sprintf("%d.%d.%d %s (%s, %s)", {*/
    _2 = (object)SEQ_PTR(_40version_info_14895);
    _8578 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_40version_info_14895);
    _8579 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_40version_info_14895);
    _8580 = (object)*(((s1_ptr)_2)->base + 3LL);
    _2 = (object)SEQ_PTR(_40version_info_14895);
    _8581 = (object)*(((s1_ptr)_2)->base + 4LL);
    _8582 = _40version_node(0LL);
    _8583 = _40version_date(_full_14969);
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_8578);
    ((intptr_t*)_2)[1] = _8578;
    Ref(_8579);
    ((intptr_t*)_2)[2] = _8579;
    Ref(_8580);
    ((intptr_t*)_2)[3] = _8580;
    Ref(_8581);
    ((intptr_t*)_2)[4] = _8581;
    ((intptr_t*)_2)[5] = _8582;
    ((intptr_t*)_2)[6] = _8583;
    _8584 = MAKE_SEQ(_1);
    _8583 = NOVALUE;
    _8582 = NOVALUE;
    _8581 = NOVALUE;
    _8580 = NOVALUE;
    _8579 = NOVALUE;
    _8578 = NOVALUE;
    _8585 = EPrintf(-9999999, _8577, _8584);
    DeRefDS(_8584);
    _8584 = NOVALUE;
    DeRef(_8576);
    _8576 = NOVALUE;
    return _8585;
L3: 
    ;
}


object _40version_string_long(object _full_15000)
{
    object _platform_name_inlined_platform_name_at_8_15004 = NOVALUE;
    object _8593 = NOVALUE;
    object _8592 = NOVALUE;
    object _8589 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:284		return version_string(full) & " for " & platform_name() & " " & arch_bits()*/
    _8589 = _40version_string(0LL);

    /** info.e:48		ifdef WINDOWS then*/

    /** info.e:49			return "Windows"*/
    RefDS(_8528);
    DeRefi(_platform_name_inlined_platform_name_at_8_15004);
    _platform_name_inlined_platform_name_at_8_15004 = _8528;
    _8592 = _40arch_bits();
    {
        object concat_list[5];

        concat_list[0] = _8592;
        concat_list[1] = _8591;
        concat_list[2] = _platform_name_inlined_platform_name_at_8_15004;
        concat_list[3] = _8590;
        concat_list[4] = _8589;
        Concat_N((object_ptr)&_8593, concat_list, 5);
    }
    DeRef(_8592);
    _8592 = NOVALUE;
    DeRef(_8589);
    _8589 = NOVALUE;
    return _8593;
    ;
}


object _40all_copyrights()
{
    object _pcre_copyright_inlined_pcre_copyright_at_19_15027 = NOVALUE;
    object _euphoria_copyright_2__tmp_at2_15025 = NOVALUE;
    object _euphoria_copyright_1__tmp_at2_15024 = NOVALUE;
    object _euphoria_copyright_inlined_euphoria_copyright_at_2_15023 = NOVALUE;
    object _8602 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:355		return {*/

    /** info.e:309		return {*/
    _0 = _euphoria_copyright_1__tmp_at2_15024;
    _euphoria_copyright_1__tmp_at2_15024 = _40version_string_long(0LL);
    DeRef(_0);
    if (IS_SEQUENCE(_8594) && IS_ATOM(_euphoria_copyright_1__tmp_at2_15024)) {
        Ref(_euphoria_copyright_1__tmp_at2_15024);
        Append(&_euphoria_copyright_2__tmp_at2_15025, _8594, _euphoria_copyright_1__tmp_at2_15024);
    }
    else if (IS_ATOM(_8594) && IS_SEQUENCE(_euphoria_copyright_1__tmp_at2_15024)) {
    }
    else {
        Concat((object_ptr)&_euphoria_copyright_2__tmp_at2_15025, _8594, _euphoria_copyright_1__tmp_at2_15024);
    }
    RefDS(_8597);
    RefDS(_euphoria_copyright_2__tmp_at2_15025);
    DeRef(_euphoria_copyright_inlined_euphoria_copyright_at_2_15023);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _euphoria_copyright_2__tmp_at2_15025;
    ((intptr_t *)_2)[2] = _8597;
    _euphoria_copyright_inlined_euphoria_copyright_at_2_15023 = MAKE_SEQ(_1);
    DeRef(_euphoria_copyright_1__tmp_at2_15024);
    _euphoria_copyright_1__tmp_at2_15024 = NOVALUE;
    DeRef(_euphoria_copyright_2__tmp_at2_15025);
    _euphoria_copyright_2__tmp_at2_15025 = NOVALUE;

    /** info.e:331		return {*/
    RefDS(_8600);
    RefDS(_8599);
    DeRef(_pcre_copyright_inlined_pcre_copyright_at_19_15027);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _8599;
    ((intptr_t *)_2)[2] = _8600;
    _pcre_copyright_inlined_pcre_copyright_at_19_15027 = MAKE_SEQ(_1);
    RefDS(_pcre_copyright_inlined_pcre_copyright_at_19_15027);
    RefDS(_euphoria_copyright_inlined_euphoria_copyright_at_2_15023);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _euphoria_copyright_inlined_euphoria_copyright_at_2_15023;
    ((intptr_t *)_2)[2] = _pcre_copyright_inlined_pcre_copyright_at_19_15027;
    _8602 = MAKE_SEQ(_1);
    return _8602;
    ;
}



// 0x0960B321
