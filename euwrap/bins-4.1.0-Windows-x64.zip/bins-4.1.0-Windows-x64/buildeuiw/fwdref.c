// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _42clear_fwd_refs()
{
    object _0, _1, _2;
    

    /** fwdref.e:70		fwdref_count = 0*/
    _42fwdref_count_63337 = 0LL;

    /** fwdref.e:71	end procedure*/
    return;
    ;
}


object _42get_fwdref_count()
{
    object _0, _1, _2;
    

    /** fwdref.e:74		return fwdref_count*/
    return _42fwdref_count_63337;
    ;
}


void _42set_glabel_block(object _ref_63344, object _block_63346)
{
    object _31191 = NOVALUE;
    object _31190 = NOVALUE;
    object _31188 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_63344)) {
        _1 = (object)(DBL_PTR(_ref_63344)->dbl);
        DeRefDS(_ref_63344);
        _ref_63344 = _1;
    }
    if (!IS_ATOM_INT(_block_63346)) {
        _1 = (object)(DBL_PTR(_block_63346)->dbl);
        DeRefDS(_block_63346);
        _block_63346 = _1;
    }

    /** fwdref.e:78		forward_references[ref][FR_DATA] &= block*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63317 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63344 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _31190 = (object)*(((s1_ptr)_2)->base + 12LL);
    _31188 = NOVALUE;
    if (IS_SEQUENCE(_31190) && IS_ATOM(_block_63346)) {
        Append(&_31191, _31190, _block_63346);
    }
    else if (IS_ATOM(_31190) && IS_SEQUENCE(_block_63346)) {
    }
    else {
        Concat((object_ptr)&_31191, _31190, _block_63346);
        _31190 = NOVALUE;
    }
    _31190 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31191;
    if( _1 != _31191 ){
        DeRef(_1);
    }
    _31191 = NOVALUE;
    _31188 = NOVALUE;

    /** fwdref.e:79	end procedure*/
    return;
    ;
}


void _42replace_code(object _code_63358, object _start_63359, object _finish_63360, object _subprog_63361)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_finish_63360)) {
        _1 = (object)(DBL_PTR(_finish_63360)->dbl);
        DeRefDS(_finish_63360);
        _finish_63360 = _1;
    }
    if (!IS_ATOM_INT(_subprog_63361)) {
        _1 = (object)(DBL_PTR(_subprog_63361)->dbl);
        DeRefDS(_subprog_63361);
        _subprog_63361 = _1;
    }

    /** fwdref.e:88		shifting_sub = subprog*/
    _42shifting_sub_63336 = _subprog_63361;

    /** fwdref.e:89		shift:replace_code( code, start, finish )*/
    RefDS(_code_63358);
    _65replace_code(_code_63358, _start_63359, _finish_63360);

    /** fwdref.e:90		shifting_sub = 0*/
    _42shifting_sub_63336 = 0LL;

    /** fwdref.e:91	end procedure*/
    DeRefDS(_code_63358);
    return;
    ;
}


void _42resolved_reference(object _ref_63364)
{
    object _file_63365 = NOVALUE;
    object _subprog_63368 = NOVALUE;
    object _tx_63371 = NOVALUE;
    object _ax_63372 = NOVALUE;
    object _sp_63373 = NOVALUE;
    object _r_63388 = NOVALUE;
    object _r_63406 = NOVALUE;
    object _31215 = NOVALUE;
    object _31214 = NOVALUE;
    object _31213 = NOVALUE;
    object _31211 = NOVALUE;
    object _31208 = NOVALUE;
    object _31206 = NOVALUE;
    object _31204 = NOVALUE;
    object _31203 = NOVALUE;
    object _31201 = NOVALUE;
    object _31199 = NOVALUE;
    object _31197 = NOVALUE;
    object _31196 = NOVALUE;
    object _31194 = NOVALUE;
    object _31192 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:95			file    = forward_references[ref][FR_FILE],*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    _31192 = (object)*(((s1_ptr)_2)->base + _ref_63364);
    _2 = (object)SEQ_PTR(_31192);
    _file_63365 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_file_63365)){
        _file_63365 = (object)DBL_PTR(_file_63365)->dbl;
    }
    _31192 = NOVALUE;

    /** fwdref.e:96			subprog = forward_references[ref][FR_SUBPROG]*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    _31194 = (object)*(((s1_ptr)_2)->base + _ref_63364);
    _2 = (object)SEQ_PTR(_31194);
    _subprog_63368 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_subprog_63368)){
        _subprog_63368 = (object)DBL_PTR(_subprog_63368)->dbl;
    }
    _31194 = NOVALUE;

    /** fwdref.e:99			tx = 0,*/
    _tx_63371 = 0LL;

    /** fwdref.e:100			ax = 0,*/
    _ax_63372 = 0LL;

    /** fwdref.e:101			sp = 0*/
    _sp_63373 = 0LL;

    /** fwdref.e:103		if forward_references[ref][FR_SUBPROG] = TopLevelSub then*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    _31196 = (object)*(((s1_ptr)_2)->base + _ref_63364);
    _2 = (object)SEQ_PTR(_31196);
    _31197 = (object)*(((s1_ptr)_2)->base + 4LL);
    _31196 = NOVALUE;
    if (binary_op_a(NOTEQ, _31197, _27TopLevelSub_20578)){
        _31197 = NOVALUE;
        goto L1; // [60] 80
    }
    _31197 = NOVALUE;

    /** fwdref.e:104			tx = find( ref, toplevel_references[file] )*/
    _2 = (object)SEQ_PTR(_42toplevel_references_63320);
    _31199 = (object)*(((s1_ptr)_2)->base + _file_63365);
    _tx_63371 = find_from(_ref_63364, _31199, 1LL);
    _31199 = NOVALUE;
    goto L2; // [77] 111
L1: 

    /** fwdref.e:106			sp = find( subprog, active_subprogs[file] )*/
    _2 = (object)SEQ_PTR(_42active_subprogs_63318);
    _31201 = (object)*(((s1_ptr)_2)->base + _file_63365);
    _sp_63373 = find_from(_subprog_63368, _31201, 1LL);
    _31201 = NOVALUE;

    /** fwdref.e:107			ax = find( ref, active_references[file][sp] )*/
    _2 = (object)SEQ_PTR(_42active_references_63319);
    _31203 = (object)*(((s1_ptr)_2)->base + _file_63365);
    _2 = (object)SEQ_PTR(_31203);
    _31204 = (object)*(((s1_ptr)_2)->base + _sp_63373);
    _31203 = NOVALUE;
    _ax_63372 = find_from(_ref_63364, _31204, 1LL);
    _31204 = NOVALUE;
L2: 

    /** fwdref.e:110		if ax then*/
    if (_ax_63372 == 0)
    {
        goto L3; // [113] 253
    }
    else{
    }

    /** fwdref.e:111			sequence r = active_references[file][sp] */
    _2 = (object)SEQ_PTR(_42active_references_63319);
    _31206 = (object)*(((s1_ptr)_2)->base + _file_63365);
    DeRef(_r_63388);
    _2 = (object)SEQ_PTR(_31206);
    _r_63388 = (object)*(((s1_ptr)_2)->base + _sp_63373);
    Ref(_r_63388);
    _31206 = NOVALUE;

    /** fwdref.e:112			active_references[file][sp] = 0*/
    _2 = (object)SEQ_PTR(_42active_references_63319);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42active_references_63319 = MAKE_SEQ(_2);
    }
    _3 = (object)(_file_63365 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _sp_63373);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _31208 = NOVALUE;

    /** fwdref.e:113			r = remove( r, ax )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_63388);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ax_63372)) ? _ax_63372 : (object)(DBL_PTR(_ax_63372)->dbl);
        int stop = (IS_ATOM_INT(_ax_63372)) ? _ax_63372 : (object)(DBL_PTR(_ax_63372)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_63388), start, &_r_63388 );
            }
            else Tail(SEQ_PTR(_r_63388), stop+1, &_r_63388);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_63388), start, &_r_63388);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_63388 = Remove_elements(start, stop, (SEQ_PTR(_r_63388)->ref == 1));
        }
    }

    /** fwdref.e:114			active_references[file][sp] = r*/
    _2 = (object)SEQ_PTR(_42active_references_63319);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42active_references_63319 = MAKE_SEQ(_2);
    }
    _3 = (object)(_file_63365 + ((s1_ptr)_2)->base);
    RefDS(_r_63388);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _sp_63373);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_63388;
    DeRef(_1);
    _31211 = NOVALUE;

    /** fwdref.e:116			if not length( active_references[file][sp] ) then*/
    _2 = (object)SEQ_PTR(_42active_references_63319);
    _31213 = (object)*(((s1_ptr)_2)->base + _file_63365);
    _2 = (object)SEQ_PTR(_31213);
    _31214 = (object)*(((s1_ptr)_2)->base + _sp_63373);
    _31213 = NOVALUE;
    if (IS_SEQUENCE(_31214)){
            _31215 = SEQ_PTR(_31214)->length;
    }
    else {
        _31215 = 1;
    }
    _31214 = NOVALUE;
    if (_31215 != 0)
    goto L4; // [178] 248
    _31215 = NOVALUE;

    /** fwdref.e:117				r = active_references[file]*/
    DeRefDS(_r_63388);
    _2 = (object)SEQ_PTR(_42active_references_63319);
    _r_63388 = (object)*(((s1_ptr)_2)->base + _file_63365);
    Ref(_r_63388);

    /** fwdref.e:118				active_references[file] = 0*/
    _2 = (object)SEQ_PTR(_42active_references_63319);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42active_references_63319 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_63365);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** fwdref.e:119				r = remove( r, sp )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_63388);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_sp_63373)) ? _sp_63373 : (object)(DBL_PTR(_sp_63373)->dbl);
        int stop = (IS_ATOM_INT(_sp_63373)) ? _sp_63373 : (object)(DBL_PTR(_sp_63373)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_63388), start, &_r_63388 );
            }
            else Tail(SEQ_PTR(_r_63388), stop+1, &_r_63388);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_63388), start, &_r_63388);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_63388 = Remove_elements(start, stop, (SEQ_PTR(_r_63388)->ref == 1));
        }
    }

    /** fwdref.e:120				active_references[file] = r*/
    RefDS(_r_63388);
    _2 = (object)SEQ_PTR(_42active_references_63319);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42active_references_63319 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_63365);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_63388;
    DeRef(_1);

    /** fwdref.e:122				r = active_subprogs[file]*/
    DeRefDS(_r_63388);
    _2 = (object)SEQ_PTR(_42active_subprogs_63318);
    _r_63388 = (object)*(((s1_ptr)_2)->base + _file_63365);
    Ref(_r_63388);

    /** fwdref.e:123				active_subprogs[file] = 0*/
    _2 = (object)SEQ_PTR(_42active_subprogs_63318);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42active_subprogs_63318 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_63365);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** fwdref.e:124				r = remove( r,   sp )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_63388);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_sp_63373)) ? _sp_63373 : (object)(DBL_PTR(_sp_63373)->dbl);
        int stop = (IS_ATOM_INT(_sp_63373)) ? _sp_63373 : (object)(DBL_PTR(_sp_63373)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_63388), start, &_r_63388 );
            }
            else Tail(SEQ_PTR(_r_63388), stop+1, &_r_63388);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_63388), start, &_r_63388);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_63388 = Remove_elements(start, stop, (SEQ_PTR(_r_63388)->ref == 1));
        }
    }

    /** fwdref.e:125				active_subprogs[file] = r*/
    RefDS(_r_63388);
    _2 = (object)SEQ_PTR(_42active_subprogs_63318);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42active_subprogs_63318 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_63365);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_63388;
    DeRef(_1);
L4: 
    DeRef(_r_63388);
    _r_63388 = NOVALUE;
    goto L5; // [250] 303
L3: 

    /** fwdref.e:127		elsif tx then*/
    if (_tx_63371 == 0)
    {
        goto L6; // [255] 296
    }
    else{
    }

    /** fwdref.e:128			sequence r = toplevel_references[file]*/
    DeRef(_r_63406);
    _2 = (object)SEQ_PTR(_42toplevel_references_63320);
    _r_63406 = (object)*(((s1_ptr)_2)->base + _file_63365);
    Ref(_r_63406);

    /** fwdref.e:129			toplevel_references[file] = 0*/
    _2 = (object)SEQ_PTR(_42toplevel_references_63320);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42toplevel_references_63320 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_63365);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** fwdref.e:130			r = remove( r, tx )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_63406);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_tx_63371)) ? _tx_63371 : (object)(DBL_PTR(_tx_63371)->dbl);
        int stop = (IS_ATOM_INT(_tx_63371)) ? _tx_63371 : (object)(DBL_PTR(_tx_63371)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_63406), start, &_r_63406 );
            }
            else Tail(SEQ_PTR(_r_63406), stop+1, &_r_63406);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_63406), start, &_r_63406);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_63406 = Remove_elements(start, stop, (SEQ_PTR(_r_63406)->ref == 1));
        }
    }

    /** fwdref.e:131			toplevel_references[file] = r*/
    RefDS(_r_63406);
    _2 = (object)SEQ_PTR(_42toplevel_references_63320);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42toplevel_references_63320 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_63365);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_63406;
    DeRef(_1);
    DeRefDS(_r_63406);
    _r_63406 = NOVALUE;
    goto L5; // [293] 303
L6: 

    /** fwdref.e:134			InternalErr( 260 )*/
    RefDS(_22218);
    _49InternalErr(260LL, _22218);
L5: 

    /** fwdref.e:136		inactive_references &= ref*/
    Append(&_42inactive_references_63321, _42inactive_references_63321, _ref_63364);

    /** fwdref.e:137		forward_references[ref] = 0*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _ref_63364);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** fwdref.e:138	end procedure*/
    _31214 = NOVALUE;
    return;
    ;
}


void _42set_code(object _ref_63420)
{
    object _31240 = NOVALUE;
    object _31238 = NOVALUE;
    object _31237 = NOVALUE;
    object _31236 = NOVALUE;
    object _31235 = NOVALUE;
    object _31233 = NOVALUE;
    object _31231 = NOVALUE;
    object _31229 = NOVALUE;
    object _31227 = NOVALUE;
    object _31224 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:146		patch_code_sub = forward_references[ref][FR_SUBPROG]*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    _31224 = (object)*(((s1_ptr)_2)->base + _ref_63420);
    _2 = (object)SEQ_PTR(_31224);
    _42patch_code_sub_63415 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_42patch_code_sub_63415)){
        _42patch_code_sub_63415 = (object)DBL_PTR(_42patch_code_sub_63415)->dbl;
    }
    _31224 = NOVALUE;

    /** fwdref.e:147		if patch_code_sub != CurrentSub then*/
    if (_42patch_code_sub_63415 == _27CurrentSub_20579)
    goto L1; // [23] 136

    /** fwdref.e:149			patch_code_temp = Code*/
    RefDS(_27Code_20660);
    DeRef(_42patch_code_temp_63412);
    _42patch_code_temp_63412 = _27Code_20660;

    /** fwdref.e:150			patch_linetab_temp = LineTable*/
    RefDS(_27LineTable_20661);
    DeRef(_42patch_linetab_temp_63413);
    _42patch_linetab_temp_63413 = _27LineTable_20661;

    /** fwdref.e:152			Code = SymTab[patch_code_sub][S_CODE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31227 = (object)*(((s1_ptr)_2)->base + _42patch_code_sub_63415);
    DeRefDS(_27Code_20660);
    _2 = (object)SEQ_PTR(_31227);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    Ref(_27Code_20660);
    _31227 = NOVALUE;

    /** fwdref.e:153			SymTab[patch_code_sub][S_CODE] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_42patch_code_sub_63415 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _31229 = NOVALUE;

    /** fwdref.e:154			LineTable = SymTab[patch_code_sub][S_LINETAB]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31231 = (object)*(((s1_ptr)_2)->base + _42patch_code_sub_63415);
    DeRefDS(_27LineTable_20661);
    _2 = (object)SEQ_PTR(_31231);
    if (!IS_ATOM_INT(_27S_LINETAB_20244)){
        _27LineTable_20661 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_LINETAB_20244)->dbl));
    }
    else{
        _27LineTable_20661 = (object)*(((s1_ptr)_2)->base + _27S_LINETAB_20244);
    }
    Ref(_27LineTable_20661);
    _31231 = NOVALUE;

    /** fwdref.e:155			SymTab[patch_code_sub][S_LINETAB] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_42patch_code_sub_63415 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_LINETAB_20244))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_LINETAB_20244)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_LINETAB_20244);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _31233 = NOVALUE;

    /** fwdref.e:157			patch_current_sub = CurrentSub*/
    _42patch_current_sub_63417 = _27CurrentSub_20579;

    /** fwdref.e:158			CurrentSub = patch_code_sub*/
    _27CurrentSub_20579 = _42patch_code_sub_63415;
    goto L2; // [133] 203
L1: 

    /** fwdref.e:160			patch_current_sub = patch_code_sub*/
    _42patch_current_sub_63417 = _42patch_code_sub_63415;

    /** fwdref.e:161			if sequence( SymTab[patch_current_sub][S_CODE] ) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31235 = (object)*(((s1_ptr)_2)->base + _42patch_current_sub_63417);
    _2 = (object)SEQ_PTR(_31235);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _31236 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _31236 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    _31235 = NOVALUE;
    _31237 = IS_SEQUENCE(_31236);
    _31236 = NOVALUE;
    if (_31237 == 0)
    {
        _31237 = NOVALUE;
        goto L3; // [164] 202
    }
    else{
        _31237 = NOVALUE;
    }

    /** fwdref.e:162				SymTab[patch_code_sub][S_CODE] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_42patch_code_sub_63415 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _31238 = NOVALUE;

    /** fwdref.e:163				SymTab[patch_code_sub][S_LINETAB] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_42patch_code_sub_63415 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_LINETAB_20244))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_LINETAB_20244)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_LINETAB_20244);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _31240 = NOVALUE;
L3: 
L2: 

    /** fwdref.e:166	end procedure*/
    return;
    ;
}


void _42reset_code()
{
    object _31245 = NOVALUE;
    object _31243 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:169		if patch_code_sub != patch_current_sub then*/
    if (_42patch_code_sub_63415 == _42patch_current_sub_63417)
    goto L1; // [7] 77

    /** fwdref.e:171			SymTab[patch_code_sub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_42patch_code_sub_63415 + ((s1_ptr)_2)->base);
    RefDS(_27Code_20660);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27Code_20660;
    DeRef(_1);
    _31243 = NOVALUE;

    /** fwdref.e:172			SymTab[patch_code_sub][S_LINETAB] = LineTable*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_42patch_code_sub_63415 + ((s1_ptr)_2)->base);
    RefDS(_27LineTable_20661);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_LINETAB_20244))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_LINETAB_20244)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_LINETAB_20244);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27LineTable_20661;
    DeRef(_1);
    _31245 = NOVALUE;

    /** fwdref.e:175			CurrentSub = patch_current_sub*/
    _27CurrentSub_20579 = _42patch_current_sub_63417;

    /** fwdref.e:176			Code = patch_code_temp*/
    RefDS(_42patch_code_temp_63412);
    DeRefDS(_27Code_20660);
    _27Code_20660 = _42patch_code_temp_63412;

    /** fwdref.e:177			LineTable = patch_linetab_temp*/
    RefDS(_42patch_linetab_temp_63413);
    DeRefDS(_27LineTable_20661);
    _27LineTable_20661 = _42patch_linetab_temp_63413;
L1: 

    /** fwdref.e:181		patch_code_temp = {}*/
    RefDS(_22218);
    DeRef(_42patch_code_temp_63412);
    _42patch_code_temp_63412 = _22218;

    /** fwdref.e:182		patch_linetab_temp = {}*/
    RefDS(_22218);
    DeRef(_42patch_linetab_temp_63413);
    _42patch_linetab_temp_63413 = _22218;

    /** fwdref.e:183	end procedure*/
    return;
    ;
}


void _42set_data(object _ref_63482, object _data_63483)
{
    object _31247 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:186		forward_references[ref][FR_DATA] = data*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63317 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63482 + ((s1_ptr)_2)->base);
    Ref(_data_63483);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _data_63483;
    DeRef(_1);
    _31247 = NOVALUE;

    /** fwdref.e:187	end procedure*/
    DeRef(_data_63483);
    return;
    ;
}


void _42add_data(object _ref_63488, object _data_63489)
{
    object _31253 = NOVALUE;
    object _31252 = NOVALUE;
    object _31251 = NOVALUE;
    object _31249 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_63488)) {
        _1 = (object)(DBL_PTR(_ref_63488)->dbl);
        DeRefDS(_ref_63488);
        _ref_63488 = _1;
    }

    /** fwdref.e:190		forward_references[ref][FR_DATA] = append( forward_references[ref][FR_DATA], data )*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63317 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63488 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    _31251 = (object)*(((s1_ptr)_2)->base + _ref_63488);
    _2 = (object)SEQ_PTR(_31251);
    _31252 = (object)*(((s1_ptr)_2)->base + 12LL);
    _31251 = NOVALUE;
    Ref(_data_63489);
    Append(&_31253, _31252, _data_63489);
    _31252 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31253;
    if( _1 != _31253 ){
        DeRef(_1);
    }
    _31253 = NOVALUE;
    _31249 = NOVALUE;

    /** fwdref.e:191	end procedure*/
    DeRef(_data_63489);
    return;
    ;
}


void _42set_line(object _ref_63497, object _line_no_63498, object _this_line_63499, object _bp_63500)
{
    object _31258 = NOVALUE;
    object _31256 = NOVALUE;
    object _31254 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_63497)) {
        _1 = (object)(DBL_PTR(_ref_63497)->dbl);
        DeRefDS(_ref_63497);
        _ref_63497 = _1;
    }

    /** fwdref.e:194		forward_references[ref][FR_LINE] = line_no*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63317 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63497 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _line_no_63498;
    DeRef(_1);
    _31254 = NOVALUE;

    /** fwdref.e:195		forward_references[ref][FR_THISLINE] = this_line*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63317 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63497 + ((s1_ptr)_2)->base);
    RefDS(_this_line_63499);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 7LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _this_line_63499;
    DeRef(_1);
    _31256 = NOVALUE;

    /** fwdref.e:196		forward_references[ref][FR_BP] = bp*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63317 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63497 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 8LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _bp_63500;
    DeRef(_1);
    _31258 = NOVALUE;

    /** fwdref.e:198	end procedure*/
    DeRefDS(_this_line_63499);
    return;
    ;
}


void _42add_private_symbol(object _sym_63512, object _name_63513)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_63512)) {
        _1 = (object)(DBL_PTR(_sym_63512)->dbl);
        DeRefDS(_sym_63512);
        _sym_63512 = _1;
    }

    /** fwdref.e:206		fwd_private_sym &= sym*/
    Append(&_42fwd_private_sym_63507, _42fwd_private_sym_63507, _sym_63512);

    /** fwdref.e:207		fwd_private_name = append( fwd_private_name, name )*/
    RefDS(_name_63513);
    Append(&_42fwd_private_name_63508, _42fwd_private_name_63508, _name_63513);

    /** fwdref.e:209	end procedure*/
    DeRefDS(_name_63513);
    return;
    ;
}


void _42patch_forward_goto(object _tok_63521, object _ref_63522)
{
    object _fr_63523 = NOVALUE;
    object _31274 = NOVALUE;
    object _31273 = NOVALUE;
    object _31272 = NOVALUE;
    object _31271 = NOVALUE;
    object _31270 = NOVALUE;
    object _31269 = NOVALUE;
    object _31268 = NOVALUE;
    object _31267 = NOVALUE;
    object _31265 = NOVALUE;
    object _31264 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:217		sequence fr = forward_references[ref]*/
    DeRef(_fr_63523);
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    _fr_63523 = (object)*(((s1_ptr)_2)->base + _ref_63522);
    Ref(_fr_63523);

    /** fwdref.e:218		set_code( ref )*/
    _42set_code(_ref_63522);

    /** fwdref.e:220		shifting_sub = fr[FR_SUBPROG]*/
    _2 = (object)SEQ_PTR(_fr_63523);
    _42shifting_sub_63336 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_42shifting_sub_63336))
    _42shifting_sub_63336 = (object)DBL_PTR(_42shifting_sub_63336)->dbl;

    /** fwdref.e:222		if length( fr[FR_DATA] ) = 2 then*/
    _2 = (object)SEQ_PTR(_fr_63523);
    _31264 = (object)*(((s1_ptr)_2)->base + 12LL);
    if (IS_SEQUENCE(_31264)){
            _31265 = SEQ_PTR(_31264)->length;
    }
    else {
        _31265 = 1;
    }
    _31264 = NOVALUE;
    if (_31265 != 2LL)
    goto L1; // [33] 64

    /** fwdref.e:223			prep_forward_error( ref )*/
    _42prep_forward_error(_ref_63522);

    /** fwdref.e:224			CompileErr( UNKNOWN_LABEL_1, { fr[FR_DATA][2] })*/
    _2 = (object)SEQ_PTR(_fr_63523);
    _31267 = (object)*(((s1_ptr)_2)->base + 12LL);
    _2 = (object)SEQ_PTR(_31267);
    _31268 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31267 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_31268);
    ((intptr_t*)_2)[1] = _31268;
    _31269 = MAKE_SEQ(_1);
    _31268 = NOVALUE;
    _49CompileErr(156LL, _31269, 0LL);
    _31269 = NOVALUE;
L1: 

    /** fwdref.e:227		Goto_block(  fr[FR_DATA][1], fr[FR_DATA][3], fr[FR_PC] )*/
    _2 = (object)SEQ_PTR(_fr_63523);
    _31270 = (object)*(((s1_ptr)_2)->base + 12LL);
    _2 = (object)SEQ_PTR(_31270);
    _31271 = (object)*(((s1_ptr)_2)->base + 1LL);
    _31270 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_63523);
    _31272 = (object)*(((s1_ptr)_2)->base + 12LL);
    _2 = (object)SEQ_PTR(_31272);
    _31273 = (object)*(((s1_ptr)_2)->base + 3LL);
    _31272 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_63523);
    _31274 = (object)*(((s1_ptr)_2)->base + 5LL);
    Ref(_31271);
    Ref(_31273);
    Ref(_31274);
    _64Goto_block(_31271, _31273, _31274);
    _31271 = NOVALUE;
    _31273 = NOVALUE;
    _31274 = NOVALUE;

    /** fwdref.e:229		shifting_sub = 0*/
    _42shifting_sub_63336 = 0LL;

    /** fwdref.e:231		reset_code()*/
    _42reset_code();

    /** fwdref.e:232		resolved_reference( ref )*/
    _42resolved_reference(_ref_63522);

    /** fwdref.e:233	end procedure*/
    DeRefDS(_fr_63523);
    _31264 = NOVALUE;
    return;
    ;
}


void _42patch_forward_call(object _tok_63545, object _ref_63546)
{
    object _fr_63547 = NOVALUE;
    object _sub_63550 = NOVALUE;
    object _defarg_63556 = NOVALUE;
    object _paramsym_63560 = NOVALUE;
    object _old_63563 = NOVALUE;
    object _tx_63567 = NOVALUE;
    object _code_sub_63577 = NOVALUE;
    object _args_63579 = NOVALUE;
    object _is_func_63584 = NOVALUE;
    object _real_file_63598 = NOVALUE;
    object _code_63602 = NOVALUE;
    object _temp_sub_63604 = NOVALUE;
    object _pc_63606 = NOVALUE;
    object _next_pc_63608 = NOVALUE;
    object _supplied_args_63609 = NOVALUE;
    object _name_63612 = NOVALUE;
    object _old_temps_allocated_63648 = NOVALUE;
    object _temp_target_63657 = NOVALUE;
    object _converted_code_63660 = NOVALUE;
    object _target_63676 = NOVALUE;
    object _has_defaults_63682 = NOVALUE;
    object _goto_target_63683 = NOVALUE;
    object _defarg_63686 = NOVALUE;
    object _code_len_63687 = NOVALUE;
    object _extra_default_args_63689 = NOVALUE;
    object _param_sym_63692 = NOVALUE;
    object _params_63693 = NOVALUE;
    object _orig_code_63695 = NOVALUE;
    object _orig_linetable_63696 = NOVALUE;
    object _ar_sp_63700 = NOVALUE;
    object _pre_refs_63704 = NOVALUE;
    object _old_fwd_params_63719 = NOVALUE;
    object _temp_shifting_sub_63760 = NOVALUE;
    object _new_code_63764 = NOVALUE;
    object _routine_type_63773 = NOVALUE;
    object _32033 = NOVALUE;
    object _31415 = NOVALUE;
    object _31414 = NOVALUE;
    object _31413 = NOVALUE;
    object _31411 = NOVALUE;
    object _31410 = NOVALUE;
    object _31409 = NOVALUE;
    object _31408 = NOVALUE;
    object _31407 = NOVALUE;
    object _31406 = NOVALUE;
    object _31405 = NOVALUE;
    object _31404 = NOVALUE;
    object _31403 = NOVALUE;
    object _31402 = NOVALUE;
    object _31401 = NOVALUE;
    object _31400 = NOVALUE;
    object _31399 = NOVALUE;
    object _31397 = NOVALUE;
    object _31396 = NOVALUE;
    object _31395 = NOVALUE;
    object _31394 = NOVALUE;
    object _31393 = NOVALUE;
    object _31392 = NOVALUE;
    object _31391 = NOVALUE;
    object _31390 = NOVALUE;
    object _31388 = NOVALUE;
    object _31385 = NOVALUE;
    object _31384 = NOVALUE;
    object _31383 = NOVALUE;
    object _31382 = NOVALUE;
    object _31378 = NOVALUE;
    object _31377 = NOVALUE;
    object _31376 = NOVALUE;
    object _31375 = NOVALUE;
    object _31374 = NOVALUE;
    object _31372 = NOVALUE;
    object _31371 = NOVALUE;
    object _31370 = NOVALUE;
    object _31369 = NOVALUE;
    object _31368 = NOVALUE;
    object _31367 = NOVALUE;
    object _31365 = NOVALUE;
    object _31364 = NOVALUE;
    object _31362 = NOVALUE;
    object _31361 = NOVALUE;
    object _31360 = NOVALUE;
    object _31359 = NOVALUE;
    object _31357 = NOVALUE;
    object _31355 = NOVALUE;
    object _31354 = NOVALUE;
    object _31353 = NOVALUE;
    object _31351 = NOVALUE;
    object _31350 = NOVALUE;
    object _31348 = NOVALUE;
    object _31346 = NOVALUE;
    object _31343 = NOVALUE;
    object _31339 = NOVALUE;
    object _31337 = NOVALUE;
    object _31336 = NOVALUE;
    object _31334 = NOVALUE;
    object _31333 = NOVALUE;
    object _31332 = NOVALUE;
    object _31331 = NOVALUE;
    object _31329 = NOVALUE;
    object _31328 = NOVALUE;
    object _31327 = NOVALUE;
    object _31326 = NOVALUE;
    object _31325 = NOVALUE;
    object _31323 = NOVALUE;
    object _31322 = NOVALUE;
    object _31321 = NOVALUE;
    object _31320 = NOVALUE;
    object _31319 = NOVALUE;
    object _31318 = NOVALUE;
    object _31317 = NOVALUE;
    object _31316 = NOVALUE;
    object _31315 = NOVALUE;
    object _31314 = NOVALUE;
    object _31313 = NOVALUE;
    object _31312 = NOVALUE;
    object _31311 = NOVALUE;
    object _31310 = NOVALUE;
    object _31308 = NOVALUE;
    object _31307 = NOVALUE;
    object _31306 = NOVALUE;
    object _31305 = NOVALUE;
    object _31304 = NOVALUE;
    object _31301 = NOVALUE;
    object _31297 = NOVALUE;
    object _31296 = NOVALUE;
    object _31295 = NOVALUE;
    object _31294 = NOVALUE;
    object _31293 = NOVALUE;
    object _31292 = NOVALUE;
    object _31290 = NOVALUE;
    object _31287 = NOVALUE;
    object _31285 = NOVALUE;
    object _31284 = NOVALUE;
    object _31282 = NOVALUE;
    object _31279 = NOVALUE;
    object _31278 = NOVALUE;
    object _31277 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:242		sequence fr = forward_references[ref]*/
    DeRef(_fr_63547);
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    _fr_63547 = (object)*(((s1_ptr)_2)->base + _ref_63546);
    Ref(_fr_63547);

    /** fwdref.e:243		symtab_index sub = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63545);
    _sub_63550 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_sub_63550)){
        _sub_63550 = (object)DBL_PTR(_sub_63550)->dbl;
    }

    /** fwdref.e:245		if sequence( fr[FR_DATA] ) then*/
    _2 = (object)SEQ_PTR(_fr_63547);
    _31277 = (object)*(((s1_ptr)_2)->base + 12LL);
    _31278 = IS_SEQUENCE(_31277);
    _31277 = NOVALUE;
    if (_31278 == 0)
    {
        _31278 = NOVALUE;
        goto L1; // [32] 117
    }
    else{
        _31278 = NOVALUE;
    }

    /** fwdref.e:246			sequence defarg = fr[FR_DATA][1]*/
    _2 = (object)SEQ_PTR(_fr_63547);
    _31279 = (object)*(((s1_ptr)_2)->base + 12LL);
    DeRef(_defarg_63556);
    _2 = (object)SEQ_PTR(_31279);
    _defarg_63556 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_defarg_63556);
    _31279 = NOVALUE;

    /** fwdref.e:247			symtab_index paramsym = defarg[2]*/
    _2 = (object)SEQ_PTR(_defarg_63556);
    _paramsym_63560 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_paramsym_63560)){
        _paramsym_63560 = (object)DBL_PTR(_paramsym_63560)->dbl;
    }

    /** fwdref.e:248			token old = { RECORDED, defarg[3] }*/
    _2 = (object)SEQ_PTR(_defarg_63556);
    _31282 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_31282);
    DeRef(_old_63563);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 508LL;
    ((intptr_t *)_2)[2] = _31282;
    _old_63563 = MAKE_SEQ(_1);
    _31282 = NOVALUE;

    /** fwdref.e:249			integer tx = find( old, SymTab[paramsym][S_CODE] )*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31284 = (object)*(((s1_ptr)_2)->base + _paramsym_63560);
    _2 = (object)SEQ_PTR(_31284);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _31285 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _31285 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    _31284 = NOVALUE;
    _tx_63567 = find_from(_old_63563, _31285, 1LL);
    _31285 = NOVALUE;

    /** fwdref.e:250			SymTab[paramsym][S_CODE][tx] = tok*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_paramsym_63560 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _3 = (object)(_27S_CODE_20221 + ((s1_ptr)_2)->base);
    _31287 = NOVALUE;
    Ref(_tok_63545);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _tx_63567);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _tok_63545;
    DeRef(_1);
    _31287 = NOVALUE;

    /** fwdref.e:251			resolved_reference( ref )*/
    _42resolved_reference(_ref_63546);

    /** fwdref.e:252			return*/
    DeRefDS(_defarg_63556);
    DeRefDS(_old_63563);
    DeRef(_tok_63545);
    DeRefDS(_fr_63547);
    DeRef(_code_63602);
    DeRef(_name_63612);
    DeRef(_params_63693);
    DeRef(_orig_code_63695);
    DeRef(_orig_linetable_63696);
    DeRef(_old_fwd_params_63719);
    DeRef(_new_code_63764);
    return;
L1: 
    DeRef(_defarg_63556);
    _defarg_63556 = NOVALUE;
    DeRef(_old_63563);
    _old_63563 = NOVALUE;

    /** fwdref.e:255		integer code_sub = fr[FR_SUBPROG]*/
    _2 = (object)SEQ_PTR(_fr_63547);
    _code_sub_63577 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_code_sub_63577))
    _code_sub_63577 = (object)DBL_PTR(_code_sub_63577)->dbl;

    /** fwdref.e:257		integer args = SymTab[sub][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31290 = (object)*(((s1_ptr)_2)->base + _sub_63550);
    _2 = (object)SEQ_PTR(_31290);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _args_63579 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _args_63579 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    if (!IS_ATOM_INT(_args_63579)){
        _args_63579 = (object)DBL_PTR(_args_63579)->dbl;
    }
    _31290 = NOVALUE;

    /** fwdref.e:258		integer is_func = (SymTab[sub][S_TOKEN] = FUNC) or (SymTab[sub][S_TOKEN] = TYPE)*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31292 = (object)*(((s1_ptr)_2)->base + _sub_63550);
    _2 = (object)SEQ_PTR(_31292);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _31293 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _31293 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _31292 = NOVALUE;
    if (IS_ATOM_INT(_31293)) {
        _31294 = (_31293 == 501LL);
    }
    else {
        _31294 = binary_op(EQUALS, _31293, 501LL);
    }
    _31293 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31295 = (object)*(((s1_ptr)_2)->base + _sub_63550);
    _2 = (object)SEQ_PTR(_31295);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _31296 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _31296 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _31295 = NOVALUE;
    if (IS_ATOM_INT(_31296)) {
        _31297 = (_31296 == 504LL);
    }
    else {
        _31297 = binary_op(EQUALS, _31296, 504LL);
    }
    _31296 = NOVALUE;
    if (IS_ATOM_INT(_31294) && IS_ATOM_INT(_31297)) {
        _is_func_63584 = (_31294 != 0 || _31297 != 0);
    }
    else {
        _is_func_63584 = binary_op(OR, _31294, _31297);
    }
    DeRef(_31294);
    _31294 = NOVALUE;
    DeRef(_31297);
    _31297 = NOVALUE;
    if (!IS_ATOM_INT(_is_func_63584)) {
        _1 = (object)(DBL_PTR(_is_func_63584)->dbl);
        DeRefDS(_is_func_63584);
        _is_func_63584 = _1;
    }

    /** fwdref.e:260		integer real_file = current_file_no*/
    _real_file_63598 = _27current_file_no_20571;

    /** fwdref.e:261		current_file_no = fr[FR_FILE]*/
    _2 = (object)SEQ_PTR(_fr_63547);
    _27current_file_no_20571 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_27current_file_no_20571)){
        _27current_file_no_20571 = (object)DBL_PTR(_27current_file_no_20571)->dbl;
    }

    /** fwdref.e:263		set_code( ref )*/
    _42set_code(_ref_63546);

    /** fwdref.e:264		sequence code = Code*/
    RefDS(_27Code_20660);
    DeRef(_code_63602);
    _code_63602 = _27Code_20660;

    /** fwdref.e:265		integer temp_sub = CurrentSub*/
    _temp_sub_63604 = _27CurrentSub_20579;

    /** fwdref.e:267		integer pc = fr[FR_PC]*/
    _2 = (object)SEQ_PTR(_fr_63547);
    _pc_63606 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (!IS_ATOM_INT(_pc_63606))
    _pc_63606 = (object)DBL_PTR(_pc_63606)->dbl;

    /** fwdref.e:268		integer next_pc = pc*/
    _next_pc_63608 = _pc_63606;

    /** fwdref.e:269		integer supplied_args = code[pc+2]*/
    _31301 = _pc_63606 + 2LL;
    _2 = (object)SEQ_PTR(_code_63602);
    _supplied_args_63609 = (object)*(((s1_ptr)_2)->base + _31301);
    if (!IS_ATOM_INT(_supplied_args_63609))
    _supplied_args_63609 = (object)DBL_PTR(_supplied_args_63609)->dbl;

    /** fwdref.e:270		sequence name = fr[FR_NAME]*/
    DeRef(_name_63612);
    _2 = (object)SEQ_PTR(_fr_63547);
    _name_63612 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_name_63612);

    /** fwdref.e:272		if Code[pc] != FUNC_FORWARD and Code[pc] != PROC_FORWARD then*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    _31304 = (object)*(((s1_ptr)_2)->base + _pc_63606);
    if (IS_ATOM_INT(_31304)) {
        _31305 = (_31304 != 196LL);
    }
    else {
        _31305 = binary_op(NOTEQ, _31304, 196LL);
    }
    _31304 = NOVALUE;
    if (IS_ATOM_INT(_31305)) {
        if (_31305 == 0) {
            goto L2; // [268] 332
        }
    }
    else {
        if (DBL_PTR(_31305)->dbl == 0.0) {
            goto L2; // [268] 332
        }
    }
    _2 = (object)SEQ_PTR(_27Code_20660);
    _31307 = (object)*(((s1_ptr)_2)->base + _pc_63606);
    if (IS_ATOM_INT(_31307)) {
        _31308 = (_31307 != 195LL);
    }
    else {
        _31308 = binary_op(NOTEQ, _31307, 195LL);
    }
    _31307 = NOVALUE;
    if (_31308 == 0) {
        DeRef(_31308);
        _31308 = NOVALUE;
        goto L2; // [285] 332
    }
    else {
        if (!IS_ATOM_INT(_31308) && DBL_PTR(_31308)->dbl == 0.0){
            DeRef(_31308);
            _31308 = NOVALUE;
            goto L2; // [285] 332
        }
        DeRef(_31308);
        _31308 = NOVALUE;
    }
    DeRef(_31308);
    _31308 = NOVALUE;

    /** fwdref.e:273			prep_forward_error( ref )*/
    _42prep_forward_error(_ref_63546);

    /** fwdref.e:274			CompileErr( "The forward call to [4] wasn't where we thought it would be: [1]:[2]:[3]",*/
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _31310 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    _2 = (object)SEQ_PTR(_fr_63547);
    _31311 = (object)*(((s1_ptr)_2)->base + 4LL);
    Ref(_31311);
    _31312 = _53sym_name(_31311);
    _31311 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_63547);
    _31313 = (object)*(((s1_ptr)_2)->base + 6LL);
    _2 = (object)SEQ_PTR(_fr_63547);
    _31314 = (object)*(((s1_ptr)_2)->base + 2LL);
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_31310);
    ((intptr_t*)_2)[1] = _31310;
    ((intptr_t*)_2)[2] = _31312;
    Ref(_31313);
    ((intptr_t*)_2)[3] = _31313;
    Ref(_31314);
    ((intptr_t*)_2)[4] = _31314;
    _31315 = MAKE_SEQ(_1);
    _31314 = NOVALUE;
    _31313 = NOVALUE;
    _31312 = NOVALUE;
    _31310 = NOVALUE;
    RefDS(_31309);
    _49CompileErr(_31309, _31315, 0LL);
    _31315 = NOVALUE;
L2: 

    /** fwdref.e:278		if SymTab[sub][S_DEPRECATED] then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31316 = (object)*(((s1_ptr)_2)->base + _sub_63550);
    _2 = (object)SEQ_PTR(_31316);
    _31317 = (object)*(((s1_ptr)_2)->base + 30LL);
    _31316 = NOVALUE;
    if (_31317 == 0) {
        _31317 = NOVALUE;
        goto L3; // [346] 375
    }
    else {
        if (!IS_ATOM_INT(_31317) && DBL_PTR(_31317)->dbl == 0.0){
            _31317 = NOVALUE;
            goto L3; // [346] 375
        }
        _31317 = NOVALUE;
    }
    _31317 = NOVALUE;

    /** fwdref.e:279			Warning(327, deprecated_warning_flag, { SymTab[sub][S_NAME] })*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31318 = (object)*(((s1_ptr)_2)->base + _sub_63550);
    _2 = (object)SEQ_PTR(_31318);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _31319 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _31319 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _31318 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_31319);
    ((intptr_t*)_2)[1] = _31319;
    _31320 = MAKE_SEQ(_1);
    _31319 = NOVALUE;
    _49Warning(327LL, 16384LL, _31320);
    _31320 = NOVALUE;
L3: 

    /** fwdref.e:282		integer old_temps_allocated = temps_allocated*/
    _old_temps_allocated_63648 = _53temps_allocated_47760;

    /** fwdref.e:283		temps_allocated = 0*/
    _53temps_allocated_47760 = 0LL;

    /** fwdref.e:285		if is_func and fr[FR_OP] = PROC then*/
    if (_is_func_63584 == 0) {
        goto L4; // [393] 481
    }
    _2 = (object)SEQ_PTR(_fr_63547);
    _31322 = (object)*(((s1_ptr)_2)->base + 10LL);
    if (IS_ATOM_INT(_31322)) {
        _31323 = (_31322 == 27LL);
    }
    else {
        _31323 = binary_op(EQUALS, _31322, 27LL);
    }
    _31322 = NOVALUE;
    if (_31323 == 0) {
        DeRef(_31323);
        _31323 = NOVALUE;
        goto L4; // [408] 481
    }
    else {
        if (!IS_ATOM_INT(_31323) && DBL_PTR(_31323)->dbl == 0.0){
            DeRef(_31323);
            _31323 = NOVALUE;
            goto L4; // [408] 481
        }
        DeRef(_31323);
        _31323 = NOVALUE;
    }
    DeRef(_31323);
    _31323 = NOVALUE;

    /** fwdref.e:288			symtab_index temp_target = NewTempSym()*/
    _temp_target_63657 = _53NewTempSym(0LL);
    if (!IS_ATOM_INT(_temp_target_63657)) {
        _1 = (object)(DBL_PTR(_temp_target_63657)->dbl);
        DeRefDS(_temp_target_63657);
        _temp_target_63657 = _1;
    }

    /** fwdref.e:289			sequence converted_code = */
    _31325 = _pc_63606 + 1;
    if (_31325 > MAXINT){
        _31325 = NewDouble((eudouble)_31325);
    }
    _31326 = _pc_63606 + 2LL;
    if ((object)((uintptr_t)_31326 + (uintptr_t)HIGH_BITS) >= 0){
        _31326 = NewDouble((eudouble)_31326);
    }
    if (IS_ATOM_INT(_31326)) {
        _31327 = _31326 + _supplied_args_63609;
    }
    else {
        _31327 = NewDouble(DBL_PTR(_31326)->dbl + (eudouble)_supplied_args_63609);
    }
    DeRef(_31326);
    _31326 = NOVALUE;
    rhs_slice_target = (object_ptr)&_31328;
    RHS_Slice(_27Code_20660, _31325, _31327);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 208LL;
    ((intptr_t *)_2)[2] = _temp_target_63657;
    _31329 = MAKE_SEQ(_1);
    {
        object concat_list[4];

        concat_list[0] = _31329;
        concat_list[1] = _temp_target_63657;
        concat_list[2] = _31328;
        concat_list[3] = 196LL;
        Concat_N((object_ptr)&_converted_code_63660, concat_list, 4);
    }
    DeRefDS(_31329);
    _31329 = NOVALUE;
    DeRefDS(_31328);
    _31328 = NOVALUE;

    /** fwdref.e:295			replace_code( converted_code, pc, pc + 2 + supplied_args, code_sub )*/
    _31331 = _pc_63606 + 2LL;
    if ((object)((uintptr_t)_31331 + (uintptr_t)HIGH_BITS) >= 0){
        _31331 = NewDouble((eudouble)_31331);
    }
    if (IS_ATOM_INT(_31331)) {
        _31332 = _31331 + _supplied_args_63609;
        if ((object)((uintptr_t)_31332 + (uintptr_t)HIGH_BITS) >= 0){
            _31332 = NewDouble((eudouble)_31332);
        }
    }
    else {
        _31332 = NewDouble(DBL_PTR(_31331)->dbl + (eudouble)_supplied_args_63609);
    }
    DeRef(_31331);
    _31331 = NOVALUE;
    RefDS(_converted_code_63660);
    _42replace_code(_converted_code_63660, _pc_63606, _31332, _code_sub_63577);
    _31332 = NOVALUE;

    /** fwdref.e:297			code = Code*/
    RefDS(_27Code_20660);
    DeRef(_code_63602);
    _code_63602 = _27Code_20660;
L4: 
    DeRef(_converted_code_63660);
    _converted_code_63660 = NOVALUE;

    /** fwdref.e:299		next_pc +=*/
    _31333 = 3LL + _supplied_args_63609;
    if ((object)((uintptr_t)_31333 + (uintptr_t)HIGH_BITS) >= 0){
        _31333 = NewDouble((eudouble)_31333);
    }
    if (IS_ATOM_INT(_31333)) {
        _31334 = _31333 + _is_func_63584;
        if ((object)((uintptr_t)_31334 + (uintptr_t)HIGH_BITS) >= 0){
            _31334 = NewDouble((eudouble)_31334);
        }
    }
    else {
        _31334 = NewDouble(DBL_PTR(_31333)->dbl + (eudouble)_is_func_63584);
    }
    DeRef(_31333);
    _31333 = NOVALUE;
    if (IS_ATOM_INT(_31334)) {
        _next_pc_63608 = _next_pc_63608 + _31334;
    }
    else {
        _next_pc_63608 = NewDouble((eudouble)_next_pc_63608 + DBL_PTR(_31334)->dbl);
    }
    DeRef(_31334);
    _31334 = NOVALUE;
    if (!IS_ATOM_INT(_next_pc_63608)) {
        _1 = (object)(DBL_PTR(_next_pc_63608)->dbl);
        DeRefDS(_next_pc_63608);
        _next_pc_63608 = _1;
    }

    /** fwdref.e:303		integer target*/

    /** fwdref.e:304		if is_func then*/
    if (_is_func_63584 == 0)
    {
        goto L5; // [503] 525
    }
    else{
    }

    /** fwdref.e:305			target = Code[pc + 3 + supplied_args]*/
    _31336 = _pc_63606 + 3LL;
    if ((object)((uintptr_t)_31336 + (uintptr_t)HIGH_BITS) >= 0){
        _31336 = NewDouble((eudouble)_31336);
    }
    if (IS_ATOM_INT(_31336)) {
        _31337 = _31336 + _supplied_args_63609;
    }
    else {
        _31337 = NewDouble(DBL_PTR(_31336)->dbl + (eudouble)_supplied_args_63609);
    }
    DeRef(_31336);
    _31336 = NOVALUE;
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!IS_ATOM_INT(_31337)){
        _target_63676 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31337)->dbl));
    }
    else{
        _target_63676 = (object)*(((s1_ptr)_2)->base + _31337);
    }
    if (!IS_ATOM_INT(_target_63676)){
        _target_63676 = (object)DBL_PTR(_target_63676)->dbl;
    }
L5: 

    /** fwdref.e:307		integer has_defaults = 0*/
    _has_defaults_63682 = 0LL;

    /** fwdref.e:308		integer goto_target = length( code ) + 1*/
    if (IS_SEQUENCE(_code_63602)){
            _31339 = SEQ_PTR(_code_63602)->length;
    }
    else {
        _31339 = 1;
    }
    _goto_target_63683 = _31339 + 1;
    _31339 = NOVALUE;

    /** fwdref.e:309		integer defarg = 0*/
    _defarg_63686 = 0LL;

    /** fwdref.e:310		integer code_len = length(code)*/
    if (IS_SEQUENCE(_code_63602)){
            _code_len_63687 = SEQ_PTR(_code_63602)->length;
    }
    else {
        _code_len_63687 = 1;
    }

    /** fwdref.e:312		integer extra_default_args = 0*/
    _extra_default_args_63689 = 0LL;

    /** fwdref.e:313		set_dont_read( 1 )*/
    _61set_dont_read(1LL);

    /** fwdref.e:314		reset_private_lists()*/

    /** fwdref.e:212		fwd_private_sym  = {}*/
    RefDS(_22218);
    DeRefi(_42fwd_private_sym_63507);
    _42fwd_private_sym_63507 = _22218;

    /** fwdref.e:213		fwd_private_name = {}*/
    RefDS(_22218);
    DeRef(_42fwd_private_name_63508);
    _42fwd_private_name_63508 = _22218;

    /** fwdref.e:214	end procedure*/
    goto L6; // [577] 580
L6: 

    /** fwdref.e:315		integer param_sym = sub*/
    _param_sym_63692 = _sub_63550;

    /** fwdref.e:316		sequence params = repeat( 0, args )*/
    DeRef(_params_63693);
    _params_63693 = Repeat(0LL, _args_63579);

    /** fwdref.e:317		sequence orig_code = code*/
    RefDS(_code_63602);
    DeRef(_orig_code_63695);
    _orig_code_63695 = _code_63602;

    /** fwdref.e:318		sequence orig_linetable = LineTable*/
    RefDS(_27LineTable_20661);
    DeRef(_orig_linetable_63696);
    _orig_linetable_63696 = _27LineTable_20661;

    /** fwdref.e:319		LineTable = {}*/
    RefDS(_22218);
    DeRefDS(_27LineTable_20661);
    _27LineTable_20661 = _22218;

    /** fwdref.e:320		Code = {}*/
    RefDS(_22218);
    DeRef(_27Code_20660);
    _27Code_20660 = _22218;

    /** fwdref.e:323		integer ar_sp = find( code_sub, active_subprogs[current_file_no] )*/
    _2 = (object)SEQ_PTR(_42active_subprogs_63318);
    _31343 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    _ar_sp_63700 = find_from(_code_sub_63577, _31343, 1LL);
    _31343 = NOVALUE;

    /** fwdref.e:324		integer pre_refs*/

    /** fwdref.e:326		if code_sub = TopLevelSub then*/
    if (_code_sub_63577 != _27TopLevelSub_20578)
    goto L7; // [644] 664

    /** fwdref.e:327			pre_refs = length( toplevel_references[current_file_no] )*/
    _2 = (object)SEQ_PTR(_42toplevel_references_63320);
    _31346 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    if (IS_SEQUENCE(_31346)){
            _pre_refs_63704 = SEQ_PTR(_31346)->length;
    }
    else {
        _pre_refs_63704 = 1;
    }
    _31346 = NOVALUE;
    goto L8; // [661] 697
L7: 

    /** fwdref.e:329			ar_sp = find( code_sub, active_subprogs[current_file_no] )*/
    _2 = (object)SEQ_PTR(_42active_subprogs_63318);
    _31348 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    _ar_sp_63700 = find_from(_code_sub_63577, _31348, 1LL);
    _31348 = NOVALUE;

    /** fwdref.e:330			pre_refs = length( active_references[current_file_no][ar_sp] )*/
    _2 = (object)SEQ_PTR(_42active_references_63319);
    _31350 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    _2 = (object)SEQ_PTR(_31350);
    _31351 = (object)*(((s1_ptr)_2)->base + _ar_sp_63700);
    _31350 = NOVALUE;
    if (IS_SEQUENCE(_31351)){
            _pre_refs_63704 = SEQ_PTR(_31351)->length;
    }
    else {
        _pre_refs_63704 = 1;
    }
    _31351 = NOVALUE;
L8: 

    /** fwdref.e:333		sequence old_fwd_params = {}*/
    RefDS(_22218);
    DeRef(_old_fwd_params_63719);
    _old_fwd_params_63719 = _22218;

    /** fwdref.e:334		for i = pc + 3 to pc + args + 2 do*/
    _31353 = _pc_63606 + 3LL;
    if ((object)((uintptr_t)_31353 + (uintptr_t)HIGH_BITS) >= 0){
        _31353 = NewDouble((eudouble)_31353);
    }
    _31354 = _pc_63606 + _args_63579;
    if ((object)((uintptr_t)_31354 + (uintptr_t)HIGH_BITS) >= 0){
        _31354 = NewDouble((eudouble)_31354);
    }
    if (IS_ATOM_INT(_31354)) {
        _31355 = _31354 + 2LL;
        if ((object)((uintptr_t)_31355 + (uintptr_t)HIGH_BITS) >= 0){
            _31355 = NewDouble((eudouble)_31355);
        }
    }
    else {
        _31355 = NewDouble(DBL_PTR(_31354)->dbl + (eudouble)2LL);
    }
    DeRef(_31354);
    _31354 = NOVALUE;
    {
        object _i_63721;
        Ref(_31353);
        _i_63721 = _31353;
L9: 
        if (binary_op_a(GREATER, _i_63721, _31355)){
            goto LA; // [718] 879
        }

        /** fwdref.e:335			defarg += 1*/
        _defarg_63686 = _defarg_63686 + 1;

        /** fwdref.e:336			param_sym = SymTab[param_sym][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _31357 = (object)*(((s1_ptr)_2)->base + _param_sym_63692);
        _2 = (object)SEQ_PTR(_31357);
        _param_sym_63692 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_param_sym_63692)){
            _param_sym_63692 = (object)DBL_PTR(_param_sym_63692)->dbl;
        }
        _31357 = NOVALUE;

        /** fwdref.e:337			if defarg > supplied_args or i > length( code ) or not code[i] then*/
        _31359 = (_defarg_63686 > _supplied_args_63609);
        if (_31359 != 0) {
            _31360 = 1;
            goto LB; // [753] 768
        }
        if (IS_SEQUENCE(_code_63602)){
                _31361 = SEQ_PTR(_code_63602)->length;
        }
        else {
            _31361 = 1;
        }
        if (IS_ATOM_INT(_i_63721)) {
            _31362 = (_i_63721 > _31361);
        }
        else {
            _31362 = (DBL_PTR(_i_63721)->dbl > (eudouble)_31361);
        }
        _31361 = NOVALUE;
        _31360 = (_31362 != 0);
LB: 
        if (_31360 != 0) {
            goto LC; // [768] 784
        }
        _2 = (object)SEQ_PTR(_code_63602);
        if (!IS_ATOM_INT(_i_63721)){
            _31364 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63721)->dbl));
        }
        else{
            _31364 = (object)*(((s1_ptr)_2)->base + _i_63721);
        }
        if (IS_ATOM_INT(_31364)) {
            _31365 = (_31364 == 0);
        }
        else {
            _31365 = unary_op(NOT, _31364);
        }
        _31364 = NOVALUE;
        if (_31365 == 0) {
            DeRef(_31365);
            _31365 = NOVALUE;
            goto LD; // [780] 834
        }
        else {
            if (!IS_ATOM_INT(_31365) && DBL_PTR(_31365)->dbl == 0.0){
                DeRef(_31365);
                _31365 = NOVALUE;
                goto LD; // [780] 834
            }
            DeRef(_31365);
            _31365 = NOVALUE;
        }
        DeRef(_31365);
        _31365 = NOVALUE;
LC: 

        /** fwdref.e:339				has_defaults = 1*/
        _has_defaults_63682 = 1LL;

        /** fwdref.e:340				extra_default_args += 1*/
        _extra_default_args_63689 = _extra_default_args_63689 + 1;

        /** fwdref.e:345				show_params( sub )*/
        _53show_params(_sub_63550);

        /** fwdref.e:346				set_error_info( ref )*/
        _42set_error_info(_ref_63546);

        /** fwdref.e:347				Parse_default_arg(sub, defarg, fwd_private_name, fwd_private_sym) --call_proc( parse_arg_rid, { sub, defarg, fwd_private_name, fwd_private_sym } )*/
        RefDS(_42fwd_private_name_63508);
        RefDS(_42fwd_private_sym_63507);
        _43Parse_default_arg(_sub_63550, _defarg_63686, _42fwd_private_name_63508, _42fwd_private_sym_63507);

        /** fwdref.e:348				hide_params( sub )*/
        _53hide_params(_sub_63550);

        /** fwdref.e:349				params[defarg] = Pop()*/
        _31367 = _45Pop();
        _2 = (object)SEQ_PTR(_params_63693);
        _2 = (object)(((s1_ptr)_2)->base + _defarg_63686);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31367;
        if( _1 != _31367 ){
            DeRef(_1);
        }
        _31367 = NOVALUE;
        goto LE; // [831] 872
LD: 

        /** fwdref.e:351				extra_default_args = 0*/
        _extra_default_args_63689 = 0LL;

        /** fwdref.e:352				add_private_symbol( code[i], SymTab[param_sym][S_NAME] )*/
        _2 = (object)SEQ_PTR(_code_63602);
        if (!IS_ATOM_INT(_i_63721)){
            _31368 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63721)->dbl));
        }
        else{
            _31368 = (object)*(((s1_ptr)_2)->base + _i_63721);
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _31369 = (object)*(((s1_ptr)_2)->base + _param_sym_63692);
        _2 = (object)SEQ_PTR(_31369);
        if (!IS_ATOM_INT(_27S_NAME_20209)){
            _31370 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
        }
        else{
            _31370 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
        }
        _31369 = NOVALUE;
        Ref(_31368);
        Ref(_31370);
        _42add_private_symbol(_31368, _31370);
        _31368 = NOVALUE;
        _31370 = NOVALUE;

        /** fwdref.e:353				params[defarg] = code[i]*/
        _2 = (object)SEQ_PTR(_code_63602);
        if (!IS_ATOM_INT(_i_63721)){
            _31371 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63721)->dbl));
        }
        else{
            _31371 = (object)*(((s1_ptr)_2)->base + _i_63721);
        }
        Ref(_31371);
        _2 = (object)SEQ_PTR(_params_63693);
        _2 = (object)(((s1_ptr)_2)->base + _defarg_63686);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31371;
        if( _1 != _31371 ){
            DeRef(_1);
        }
        _31371 = NOVALUE;
LE: 

        /** fwdref.e:355		end for*/
        _0 = _i_63721;
        if (IS_ATOM_INT(_i_63721)) {
            _i_63721 = _i_63721 + 1LL;
            if ((object)((uintptr_t)_i_63721 +(uintptr_t) HIGH_BITS) >= 0){
                _i_63721 = NewDouble((eudouble)_i_63721);
            }
        }
        else {
            _i_63721 = binary_op_a(PLUS, _i_63721, 1LL);
        }
        DeRef(_0);
        goto L9; // [874] 725
LA: 
        ;
        DeRef(_i_63721);
    }

    /** fwdref.e:357		SymTab[code_sub][S_STACK_SPACE] += temps_allocated*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_code_sub_63577 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_27S_STACK_SPACE_20269)){
        _31374 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_STACK_SPACE_20269)->dbl));
    }
    else{
        _31374 = (object)*(((s1_ptr)_2)->base + _27S_STACK_SPACE_20269);
    }
    _31372 = NOVALUE;
    if (IS_ATOM_INT(_31374)) {
        _31375 = _31374 + _53temps_allocated_47760;
        if ((object)((uintptr_t)_31375 + (uintptr_t)HIGH_BITS) >= 0){
            _31375 = NewDouble((eudouble)_31375);
        }
    }
    else {
        _31375 = binary_op(PLUS, _31374, _53temps_allocated_47760);
    }
    _31374 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_STACK_SPACE_20269))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_STACK_SPACE_20269)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_STACK_SPACE_20269);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31375;
    if( _1 != _31375 ){
        DeRef(_1);
    }
    _31375 = NOVALUE;
    _31372 = NOVALUE;

    /** fwdref.e:358		temps_allocated = old_temps_allocated*/
    _53temps_allocated_47760 = _old_temps_allocated_63648;

    /** fwdref.e:363		integer temp_shifting_sub = shifting_sub*/
    _temp_shifting_sub_63760 = _42shifting_sub_63336;

    /** fwdref.e:364		shift( -pc, pc-1 )*/
    if ((uintptr_t)_pc_63606 == (uintptr_t)HIGH_BITS){
        _31376 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31376 = - _pc_63606;
    }
    _31377 = _pc_63606 - 1LL;
    if ((object)((uintptr_t)_31377 +(uintptr_t) HIGH_BITS) >= 0){
        _31377 = NewDouble((eudouble)_31377);
    }
    Ref(_31376);
    DeRef(_32033);
    _32033 = _31376;
    _65shift(_31376, _31377, _32033);
    _31376 = NOVALUE;
    _31377 = NOVALUE;
    _32033 = NOVALUE;

    /** fwdref.e:366		sequence new_code = Code*/
    RefDS(_27Code_20660);
    DeRef(_new_code_63764);
    _new_code_63764 = _27Code_20660;

    /** fwdref.e:367		Code = orig_code*/
    RefDS(_orig_code_63695);
    DeRefDS(_27Code_20660);
    _27Code_20660 = _orig_code_63695;

    /** fwdref.e:368		orig_code = {}*/
    RefDS(_22218);
    DeRefDS(_orig_code_63695);
    _orig_code_63695 = _22218;

    /** fwdref.e:369		LineTable = orig_linetable*/
    RefDS(_orig_linetable_63696);
    DeRef(_27LineTable_20661);
    _27LineTable_20661 = _orig_linetable_63696;

    /** fwdref.e:370		orig_linetable = {}*/
    RefDS(_22218);
    DeRefDS(_orig_linetable_63696);
    _orig_linetable_63696 = _22218;

    /** fwdref.e:371		set_dont_read( 0 )*/
    _61set_dont_read(0LL);

    /** fwdref.e:372		current_file_no = real_file*/
    _27current_file_no_20571 = _real_file_63598;

    /** fwdref.e:374		if args != ( supplied_args + extra_default_args ) then*/
    _31378 = _supplied_args_63609 + _extra_default_args_63689;
    if ((object)((uintptr_t)_31378 + (uintptr_t)HIGH_BITS) >= 0){
        _31378 = NewDouble((eudouble)_31378);
    }
    if (binary_op_a(EQUALS, _args_63579, _31378)){
        DeRef(_31378);
        _31378 = NOVALUE;
        goto LF; // [990] 1070
    }
    DeRef(_31378);
    _31378 = NOVALUE;

    /** fwdref.e:375			sequence routine_type*/

    /** fwdref.e:377			if is_func then */
    if (_is_func_63584 == 0)
    {
        goto L10; // [998] 1011
    }
    else{
    }

    /** fwdref.e:378				routine_type = "function"*/
    RefDS(_26544);
    DeRefi(_routine_type_63773);
    _routine_type_63773 = _26544;
    goto L11; // [1008] 1019
L10: 

    /** fwdref.e:380				routine_type = "procedure"*/
    RefDS(_26598);
    DeRefi(_routine_type_63773);
    _routine_type_63773 = _26598;
L11: 

    /** fwdref.e:382			current_file_no = fr[FR_FILE]*/
    _2 = (object)SEQ_PTR(_fr_63547);
    _27current_file_no_20571 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_27current_file_no_20571)){
        _27current_file_no_20571 = (object)DBL_PTR(_27current_file_no_20571)->dbl;
    }

    /** fwdref.e:383			line_number = fr[FR_LINE]*/
    _2 = (object)SEQ_PTR(_fr_63547);
    _27line_number_20572 = (object)*(((s1_ptr)_2)->base + 6LL);
    if (!IS_ATOM_INT(_27line_number_20572)){
        _27line_number_20572 = (object)DBL_PTR(_27line_number_20572)->dbl;
    }

    /** fwdref.e:384			CompileErr( WRONG_NUMBER_OF_ARGUMENTS_SUPPLIED_FOR_FORWARD_REFERENCET1_2_3_4__EXPECTED_5_BUT_FOUND_6,*/
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _31382 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    _31383 = _supplied_args_63609 + _extra_default_args_63689;
    if ((object)((uintptr_t)_31383 + (uintptr_t)HIGH_BITS) >= 0){
        _31383 = NewDouble((eudouble)_31383);
    }
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_31382);
    ((intptr_t*)_2)[1] = _31382;
    ((intptr_t*)_2)[2] = _27line_number_20572;
    RefDS(_routine_type_63773);
    ((intptr_t*)_2)[3] = _routine_type_63773;
    RefDS(_name_63612);
    ((intptr_t*)_2)[4] = _name_63612;
    ((intptr_t*)_2)[5] = _args_63579;
    ((intptr_t*)_2)[6] = _31383;
    _31384 = MAKE_SEQ(_1);
    _31383 = NOVALUE;
    _31382 = NOVALUE;
    _49CompileErr(158LL, _31384, 0LL);
    _31384 = NOVALUE;
LF: 
    DeRefi(_routine_type_63773);
    _routine_type_63773 = NOVALUE;

    /** fwdref.e:388		new_code &= PROC & sub & params*/
    {
        object concat_list[3];

        concat_list[0] = _params_63693;
        concat_list[1] = _sub_63550;
        concat_list[2] = 27LL;
        Concat_N((object_ptr)&_31385, concat_list, 3);
    }
    Concat((object_ptr)&_new_code_63764, _new_code_63764, _31385);
    DeRefDS(_31385);
    _31385 = NOVALUE;

    /** fwdref.e:389		if is_func then*/
    if (_is_func_63584 == 0)
    {
        goto L12; // [1088] 1100
    }
    else{
    }

    /** fwdref.e:390			new_code &= target*/
    Append(&_new_code_63764, _new_code_63764, _target_63676);
L12: 

    /** fwdref.e:393		replace_code( new_code, pc, next_pc - 1, code_sub )*/
    _31388 = _next_pc_63608 - 1LL;
    if ((object)((uintptr_t)_31388 +(uintptr_t) HIGH_BITS) >= 0){
        _31388 = NewDouble((eudouble)_31388);
    }
    RefDS(_new_code_63764);
    _42replace_code(_new_code_63764, _pc_63606, _31388, _code_sub_63577);
    _31388 = NOVALUE;

    /** fwdref.e:395		if code_sub = TopLevelSub then*/
    if (_code_sub_63577 != _27TopLevelSub_20578)
    goto L13; // [1116] 1197

    /** fwdref.e:396			for i = pre_refs + 1 to length( toplevel_references[fr[FR_FILE]] ) do*/
    _31390 = _pre_refs_63704 + 1;
    if (_31390 > MAXINT){
        _31390 = NewDouble((eudouble)_31390);
    }
    _2 = (object)SEQ_PTR(_fr_63547);
    _31391 = (object)*(((s1_ptr)_2)->base + 3LL);
    _2 = (object)SEQ_PTR(_42toplevel_references_63320);
    if (!IS_ATOM_INT(_31391)){
        _31392 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31391)->dbl));
    }
    else{
        _31392 = (object)*(((s1_ptr)_2)->base + _31391);
    }
    if (IS_SEQUENCE(_31392)){
            _31393 = SEQ_PTR(_31392)->length;
    }
    else {
        _31393 = 1;
    }
    _31392 = NOVALUE;
    {
        object _i_63798;
        Ref(_31390);
        _i_63798 = _31390;
L14: 
        if (binary_op_a(GREATER, _i_63798, _31393)){
            goto L15; // [1141] 1194
        }

        /** fwdref.e:397				forward_references[toplevel_references[fr[FR_FILE]][i]][FR_PC] += pc - 1*/
        _2 = (object)SEQ_PTR(_fr_63547);
        _31394 = (object)*(((s1_ptr)_2)->base + 3LL);
        _2 = (object)SEQ_PTR(_42toplevel_references_63320);
        if (!IS_ATOM_INT(_31394)){
            _31395 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31394)->dbl));
        }
        else{
            _31395 = (object)*(((s1_ptr)_2)->base + _31394);
        }
        _2 = (object)SEQ_PTR(_31395);
        if (!IS_ATOM_INT(_i_63798)){
            _31396 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63798)->dbl));
        }
        else{
            _31396 = (object)*(((s1_ptr)_2)->base + _i_63798);
        }
        _31395 = NOVALUE;
        _2 = (object)SEQ_PTR(_42forward_references_63317);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _42forward_references_63317 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31396))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31396)->dbl));
        else
        _3 = (object)(_31396 + ((s1_ptr)_2)->base);
        _31399 = _pc_63606 - 1LL;
        if ((object)((uintptr_t)_31399 +(uintptr_t) HIGH_BITS) >= 0){
            _31399 = NewDouble((eudouble)_31399);
        }
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _31400 = (object)*(((s1_ptr)_2)->base + 5LL);
        _31397 = NOVALUE;
        if (IS_ATOM_INT(_31400) && IS_ATOM_INT(_31399)) {
            _31401 = _31400 + _31399;
            if ((object)((uintptr_t)_31401 + (uintptr_t)HIGH_BITS) >= 0){
                _31401 = NewDouble((eudouble)_31401);
            }
        }
        else {
            _31401 = binary_op(PLUS, _31400, _31399);
        }
        _31400 = NOVALUE;
        DeRef(_31399);
        _31399 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31401;
        if( _1 != _31401 ){
            DeRef(_1);
        }
        _31401 = NOVALUE;
        _31397 = NOVALUE;

        /** fwdref.e:398			end for*/
        _0 = _i_63798;
        if (IS_ATOM_INT(_i_63798)) {
            _i_63798 = _i_63798 + 1LL;
            if ((object)((uintptr_t)_i_63798 +(uintptr_t) HIGH_BITS) >= 0){
                _i_63798 = NewDouble((eudouble)_i_63798);
            }
        }
        else {
            _i_63798 = binary_op_a(PLUS, _i_63798, 1LL);
        }
        DeRef(_0);
        goto L14; // [1189] 1148
L15: 
        ;
        DeRef(_i_63798);
    }
    goto L16; // [1194] 1280
L13: 

    /** fwdref.e:400			for i = pre_refs + 1 to length( active_references[fr[FR_FILE]][ar_sp] ) do*/
    _31402 = _pre_refs_63704 + 1;
    if (_31402 > MAXINT){
        _31402 = NewDouble((eudouble)_31402);
    }
    _2 = (object)SEQ_PTR(_fr_63547);
    _31403 = (object)*(((s1_ptr)_2)->base + 3LL);
    _2 = (object)SEQ_PTR(_42active_references_63319);
    if (!IS_ATOM_INT(_31403)){
        _31404 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31403)->dbl));
    }
    else{
        _31404 = (object)*(((s1_ptr)_2)->base + _31403);
    }
    _2 = (object)SEQ_PTR(_31404);
    _31405 = (object)*(((s1_ptr)_2)->base + _ar_sp_63700);
    _31404 = NOVALUE;
    if (IS_SEQUENCE(_31405)){
            _31406 = SEQ_PTR(_31405)->length;
    }
    else {
        _31406 = 1;
    }
    _31405 = NOVALUE;
    {
        object _i_63813;
        Ref(_31402);
        _i_63813 = _31402;
L17: 
        if (binary_op_a(GREATER, _i_63813, _31406)){
            goto L18; // [1222] 1279
        }

        /** fwdref.e:401				forward_references[active_references[fr[FR_FILE]][ar_sp][i]][FR_PC] += pc - 1*/
        _2 = (object)SEQ_PTR(_fr_63547);
        _31407 = (object)*(((s1_ptr)_2)->base + 3LL);
        _2 = (object)SEQ_PTR(_42active_references_63319);
        if (!IS_ATOM_INT(_31407)){
            _31408 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31407)->dbl));
        }
        else{
            _31408 = (object)*(((s1_ptr)_2)->base + _31407);
        }
        _2 = (object)SEQ_PTR(_31408);
        _31409 = (object)*(((s1_ptr)_2)->base + _ar_sp_63700);
        _31408 = NOVALUE;
        _2 = (object)SEQ_PTR(_31409);
        if (!IS_ATOM_INT(_i_63813)){
            _31410 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63813)->dbl));
        }
        else{
            _31410 = (object)*(((s1_ptr)_2)->base + _i_63813);
        }
        _31409 = NOVALUE;
        _2 = (object)SEQ_PTR(_42forward_references_63317);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _42forward_references_63317 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31410))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31410)->dbl));
        else
        _3 = (object)(_31410 + ((s1_ptr)_2)->base);
        _31413 = _pc_63606 - 1LL;
        if ((object)((uintptr_t)_31413 +(uintptr_t) HIGH_BITS) >= 0){
            _31413 = NewDouble((eudouble)_31413);
        }
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _31414 = (object)*(((s1_ptr)_2)->base + 5LL);
        _31411 = NOVALUE;
        if (IS_ATOM_INT(_31414) && IS_ATOM_INT(_31413)) {
            _31415 = _31414 + _31413;
            if ((object)((uintptr_t)_31415 + (uintptr_t)HIGH_BITS) >= 0){
                _31415 = NewDouble((eudouble)_31415);
            }
        }
        else {
            _31415 = binary_op(PLUS, _31414, _31413);
        }
        _31414 = NOVALUE;
        DeRef(_31413);
        _31413 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31415;
        if( _1 != _31415 ){
            DeRef(_1);
        }
        _31415 = NOVALUE;
        _31411 = NOVALUE;

        /** fwdref.e:402			end for*/
        _0 = _i_63813;
        if (IS_ATOM_INT(_i_63813)) {
            _i_63813 = _i_63813 + 1LL;
            if ((object)((uintptr_t)_i_63813 +(uintptr_t) HIGH_BITS) >= 0){
                _i_63813 = NewDouble((eudouble)_i_63813);
            }
        }
        else {
            _i_63813 = binary_op_a(PLUS, _i_63813, 1LL);
        }
        DeRef(_0);
        goto L17; // [1274] 1229
L18: 
        ;
        DeRef(_i_63813);
    }
L16: 

    /** fwdref.e:405		reset_code()*/
    _42reset_code();

    /** fwdref.e:408		resolved_reference( ref )*/
    _42resolved_reference(_ref_63546);

    /** fwdref.e:409	end procedure*/
    DeRef(_tok_63545);
    DeRef(_fr_63547);
    DeRef(_code_63602);
    DeRef(_name_63612);
    DeRef(_params_63693);
    DeRef(_orig_code_63695);
    DeRef(_orig_linetable_63696);
    DeRef(_old_fwd_params_63719);
    DeRef(_new_code_63764);
    _31394 = NOVALUE;
    DeRef(_31390);
    _31390 = NOVALUE;
    _31410 = NOVALUE;
    DeRef(_31353);
    _31353 = NOVALUE;
    _31405 = NOVALUE;
    DeRef(_31337);
    _31337 = NOVALUE;
    DeRef(_31359);
    _31359 = NOVALUE;
    _31346 = NOVALUE;
    _31396 = NOVALUE;
    DeRef(_31301);
    _31301 = NOVALUE;
    DeRef(_31402);
    _31402 = NOVALUE;
    _31392 = NOVALUE;
    DeRef(_31355);
    _31355 = NOVALUE;
    DeRef(_31305);
    _31305 = NOVALUE;
    _31351 = NOVALUE;
    _31391 = NOVALUE;
    DeRef(_31362);
    _31362 = NOVALUE;
    DeRef(_31325);
    _31325 = NOVALUE;
    _31407 = NOVALUE;
    _31403 = NOVALUE;
    DeRef(_31327);
    _31327 = NOVALUE;
    return;
    ;
}


void _42set_error_info(object _ref_63830)
{
    object _fr_63831 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:412		sequence fr = forward_references[ref]*/
    DeRef(_fr_63831);
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    _fr_63831 = (object)*(((s1_ptr)_2)->base + _ref_63830);
    Ref(_fr_63831);

    /** fwdref.e:413		ThisLine        = fr[FR_THISLINE]*/
    DeRef(_49ThisLine_49693);
    _2 = (object)SEQ_PTR(_fr_63831);
    _49ThisLine_49693 = (object)*(((s1_ptr)_2)->base + 7LL);
    Ref(_49ThisLine_49693);

    /** fwdref.e:414		bp              = fr[FR_BP]*/
    _2 = (object)SEQ_PTR(_fr_63831);
    _49bp_49697 = (object)*(((s1_ptr)_2)->base + 8LL);
    if (!IS_ATOM_INT(_49bp_49697)){
        _49bp_49697 = (object)DBL_PTR(_49bp_49697)->dbl;
    }

    /** fwdref.e:415		line_number     = fr[FR_LINE]*/
    _2 = (object)SEQ_PTR(_fr_63831);
    _27line_number_20572 = (object)*(((s1_ptr)_2)->base + 6LL);
    if (!IS_ATOM_INT(_27line_number_20572)){
        _27line_number_20572 = (object)DBL_PTR(_27line_number_20572)->dbl;
    }

    /** fwdref.e:416		current_file_no = fr[FR_FILE]*/
    _2 = (object)SEQ_PTR(_fr_63831);
    _27current_file_no_20571 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_27current_file_no_20571)){
        _27current_file_no_20571 = (object)DBL_PTR(_27current_file_no_20571)->dbl;
    }

    /** fwdref.e:417	end procedure*/
    DeRefDS(_fr_63831);
    return;
    ;
}


void _42patch_forward_variable(object _tok_63844, object _ref_63845)
{
    object _fr_63846 = NOVALUE;
    object _sym_63849 = NOVALUE;
    object _pc_63902 = NOVALUE;
    object _vx_63906 = NOVALUE;
    object _d_63923 = NOVALUE;
    object _param_63933 = NOVALUE;
    object _old_63936 = NOVALUE;
    object _new_63941 = NOVALUE;
    object _31472 = NOVALUE;
    object _31471 = NOVALUE;
    object _31470 = NOVALUE;
    object _31468 = NOVALUE;
    object _31465 = NOVALUE;
    object _31463 = NOVALUE;
    object _31462 = NOVALUE;
    object _31461 = NOVALUE;
    object _31460 = NOVALUE;
    object _31458 = NOVALUE;
    object _31457 = NOVALUE;
    object _31456 = NOVALUE;
    object _31455 = NOVALUE;
    object _31454 = NOVALUE;
    object _31452 = NOVALUE;
    object _31450 = NOVALUE;
    object _31447 = NOVALUE;
    object _31446 = NOVALUE;
    object _31445 = NOVALUE;
    object _31443 = NOVALUE;
    object _31442 = NOVALUE;
    object _31441 = NOVALUE;
    object _31440 = NOVALUE;
    object _31438 = NOVALUE;
    object _31436 = NOVALUE;
    object _31435 = NOVALUE;
    object _31434 = NOVALUE;
    object _31433 = NOVALUE;
    object _31432 = NOVALUE;
    object _31431 = NOVALUE;
    object _31430 = NOVALUE;
    object _31429 = NOVALUE;
    object _31428 = NOVALUE;
    object _31427 = NOVALUE;
    object _31426 = NOVALUE;
    object _31425 = NOVALUE;
    object _31424 = NOVALUE;
    object _31423 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:421		sequence fr = forward_references[ref]*/
    DeRef(_fr_63846);
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    _fr_63846 = (object)*(((s1_ptr)_2)->base + _ref_63845);
    Ref(_fr_63846);

    /** fwdref.e:422		symtab_index sym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63844);
    _sym_63849 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_sym_63849)){
        _sym_63849 = (object)DBL_PTR(_sym_63849)->dbl;
    }

    /** fwdref.e:424		if SymTab[sym][S_FILE_NO] = fr[FR_FILE] */
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31423 = (object)*(((s1_ptr)_2)->base + _sym_63849);
    _2 = (object)SEQ_PTR(_31423);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _31424 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _31424 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _31423 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_63846);
    _31425 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (IS_ATOM_INT(_31424) && IS_ATOM_INT(_31425)) {
        _31426 = (_31424 == _31425);
    }
    else {
        _31426 = binary_op(EQUALS, _31424, _31425);
    }
    _31424 = NOVALUE;
    _31425 = NOVALUE;
    if (IS_ATOM_INT(_31426)) {
        if (_31426 == 0) {
            goto L1; // [45] 69
        }
    }
    else {
        if (DBL_PTR(_31426)->dbl == 0.0) {
            goto L1; // [45] 69
        }
    }
    _2 = (object)SEQ_PTR(_fr_63846);
    _31428 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_31428)) {
        _31429 = (_31428 == _27TopLevelSub_20578);
    }
    else {
        _31429 = binary_op(EQUALS, _31428, _27TopLevelSub_20578);
    }
    _31428 = NOVALUE;
    if (_31429 == 0) {
        DeRef(_31429);
        _31429 = NOVALUE;
        goto L1; // [60] 69
    }
    else {
        if (!IS_ATOM_INT(_31429) && DBL_PTR(_31429)->dbl == 0.0){
            DeRef(_31429);
            _31429 = NOVALUE;
            goto L1; // [60] 69
        }
        DeRef(_31429);
        _31429 = NOVALUE;
    }
    DeRef(_31429);
    _31429 = NOVALUE;

    /** fwdref.e:426			return*/
    DeRef(_tok_63844);
    DeRef(_fr_63846);
    DeRef(_31426);
    _31426 = NOVALUE;
    return;
L1: 

    /** fwdref.e:429		if fr[FR_OP] = ASSIGN and SymTab[sym][S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_fr_63846);
    _31430 = (object)*(((s1_ptr)_2)->base + 10LL);
    if (IS_ATOM_INT(_31430)) {
        _31431 = (_31430 == 18LL);
    }
    else {
        _31431 = binary_op(EQUALS, _31430, 18LL);
    }
    _31430 = NOVALUE;
    if (IS_ATOM_INT(_31431)) {
        if (_31431 == 0) {
            goto L2; // [81] 122
        }
    }
    else {
        if (DBL_PTR(_31431)->dbl == 0.0) {
            goto L2; // [81] 122
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31433 = (object)*(((s1_ptr)_2)->base + _sym_63849);
    _2 = (object)SEQ_PTR(_31433);
    _31434 = (object)*(((s1_ptr)_2)->base + 3LL);
    _31433 = NOVALUE;
    if (IS_ATOM_INT(_31434)) {
        _31435 = (_31434 == 2LL);
    }
    else {
        _31435 = binary_op(EQUALS, _31434, 2LL);
    }
    _31434 = NOVALUE;
    if (_31435 == 0) {
        DeRef(_31435);
        _31435 = NOVALUE;
        goto L2; // [104] 122
    }
    else {
        if (!IS_ATOM_INT(_31435) && DBL_PTR(_31435)->dbl == 0.0){
            DeRef(_31435);
            _31435 = NOVALUE;
            goto L2; // [104] 122
        }
        DeRef(_31435);
        _31435 = NOVALUE;
    }
    DeRef(_31435);
    _31435 = NOVALUE;

    /** fwdref.e:430			prep_forward_error( ref )*/
    _42prep_forward_error(_ref_63845);

    /** fwdref.e:431			CompileErr( MAY_NOT_CHANGE_THE_VALUE_OF_A_CONSTANT)*/
    RefDS(_22218);
    _49CompileErr(110LL, _22218, 0LL);
L2: 

    /** fwdref.e:434		if fr[FR_OP] = ASSIGN then*/
    _2 = (object)SEQ_PTR(_fr_63846);
    _31436 = (object)*(((s1_ptr)_2)->base + 10LL);
    if (binary_op_a(NOTEQ, _31436, 18LL)){
        _31436 = NOVALUE;
        goto L3; // [130] 170
    }
    _31436 = NOVALUE;

    /** fwdref.e:435			SymTab[sym][S_USAGE] = or_bits( U_WRITTEN, SymTab[sym][S_USAGE] )*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_63849 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31440 = (object)*(((s1_ptr)_2)->base + _sym_63849);
    _2 = (object)SEQ_PTR(_31440);
    _31441 = (object)*(((s1_ptr)_2)->base + 5LL);
    _31440 = NOVALUE;
    if (IS_ATOM_INT(_31441)) {
        {uintptr_t tu;
             tu = (uintptr_t)2LL | (uintptr_t)_31441;
             _31442 = MAKE_UINT(tu);
        }
    }
    else {
        _31442 = binary_op(OR_BITS, 2LL, _31441);
    }
    _31441 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31442;
    if( _1 != _31442 ){
        DeRef(_1);
    }
    _31442 = NOVALUE;
    _31438 = NOVALUE;
    goto L4; // [167] 204
L3: 

    /** fwdref.e:437			SymTab[sym][S_USAGE] = or_bits( U_READ, SymTab[sym][S_USAGE] )*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_63849 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31445 = (object)*(((s1_ptr)_2)->base + _sym_63849);
    _2 = (object)SEQ_PTR(_31445);
    _31446 = (object)*(((s1_ptr)_2)->base + 5LL);
    _31445 = NOVALUE;
    if (IS_ATOM_INT(_31446)) {
        {uintptr_t tu;
             tu = (uintptr_t)1LL | (uintptr_t)_31446;
             _31447 = MAKE_UINT(tu);
        }
    }
    else {
        _31447 = binary_op(OR_BITS, 1LL, _31446);
    }
    _31446 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31447;
    if( _1 != _31447 ){
        DeRef(_1);
    }
    _31447 = NOVALUE;
    _31443 = NOVALUE;
L4: 

    /** fwdref.e:440		set_code( ref )*/
    _42set_code(_ref_63845);

    /** fwdref.e:441		integer pc = fr[FR_PC]*/
    _2 = (object)SEQ_PTR(_fr_63846);
    _pc_63902 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (!IS_ATOM_INT(_pc_63902))
    _pc_63902 = (object)DBL_PTR(_pc_63902)->dbl;

    /** fwdref.e:442		if pc < 1 then*/
    if (_pc_63902 >= 1LL)
    goto L5; // [217] 227

    /** fwdref.e:443			pc = 1*/
    _pc_63902 = 1LL;
L5: 

    /** fwdref.e:445		integer vx = find( -ref, Code, pc )*/
    if ((uintptr_t)_ref_63845 == (uintptr_t)HIGH_BITS){
        _31450 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31450 = - _ref_63845;
    }
    _vx_63906 = find_from(_31450, _27Code_20660, _pc_63902);
    DeRef(_31450);
    _31450 = NOVALUE;

    /** fwdref.e:446		if vx then*/
    if (_vx_63906 == 0)
    {
        goto L6; // [241] 283
    }
    else{
    }

    /** fwdref.e:447			while vx do*/
L7: 
    if (_vx_63906 == 0)
    {
        goto L8; // [249] 277
    }
    else{
    }

    /** fwdref.e:450				Code[vx] = sym*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _vx_63906);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_63849;
    DeRef(_1);

    /** fwdref.e:451				vx = find( -ref, Code, vx )*/
    if ((uintptr_t)_ref_63845 == (uintptr_t)HIGH_BITS){
        _31452 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31452 = - _ref_63845;
    }
    _vx_63906 = find_from(_31452, _27Code_20660, _vx_63906);
    DeRef(_31452);
    _31452 = NOVALUE;

    /** fwdref.e:452			end while*/
    goto L7; // [274] 249
L8: 

    /** fwdref.e:453			resolved_reference( ref )*/
    _42resolved_reference(_ref_63845);
L6: 

    /** fwdref.e:456		if sequence( fr[FR_DATA] ) then*/
    _2 = (object)SEQ_PTR(_fr_63846);
    _31454 = (object)*(((s1_ptr)_2)->base + 12LL);
    _31455 = IS_SEQUENCE(_31454);
    _31454 = NOVALUE;
    if (_31455 == 0)
    {
        _31455 = NOVALUE;
        goto L9; // [292] 424
    }
    else{
        _31455 = NOVALUE;
    }

    /** fwdref.e:457			for i = 1 to length( fr[FR_DATA] ) do*/
    _2 = (object)SEQ_PTR(_fr_63846);
    _31456 = (object)*(((s1_ptr)_2)->base + 12LL);
    if (IS_SEQUENCE(_31456)){
            _31457 = SEQ_PTR(_31456)->length;
    }
    else {
        _31457 = 1;
    }
    _31456 = NOVALUE;
    {
        object _i_63920;
        _i_63920 = 1LL;
LA: 
        if (_i_63920 > _31457){
            goto LB; // [304] 418
        }

        /** fwdref.e:458				object d = fr[FR_DATA][i]*/
        _2 = (object)SEQ_PTR(_fr_63846);
        _31458 = (object)*(((s1_ptr)_2)->base + 12LL);
        DeRef(_d_63923);
        _2 = (object)SEQ_PTR(_31458);
        _d_63923 = (object)*(((s1_ptr)_2)->base + _i_63920);
        Ref(_d_63923);
        _31458 = NOVALUE;

        /** fwdref.e:459				if sequence( d ) and d[1] = PAM_RECORD then*/
        _31460 = IS_SEQUENCE(_d_63923);
        if (_31460 == 0) {
            goto LC; // [326] 407
        }
        _2 = (object)SEQ_PTR(_d_63923);
        _31462 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_31462)) {
            _31463 = (_31462 == 1LL);
        }
        else {
            _31463 = binary_op(EQUALS, _31462, 1LL);
        }
        _31462 = NOVALUE;
        if (_31463 == 0) {
            DeRef(_31463);
            _31463 = NOVALUE;
            goto LC; // [341] 407
        }
        else {
            if (!IS_ATOM_INT(_31463) && DBL_PTR(_31463)->dbl == 0.0){
                DeRef(_31463);
                _31463 = NOVALUE;
                goto LC; // [341] 407
            }
            DeRef(_31463);
            _31463 = NOVALUE;
        }
        DeRef(_31463);
        _31463 = NOVALUE;

        /** fwdref.e:461					symtab_index param = d[2]*/
        _2 = (object)SEQ_PTR(_d_63923);
        _param_63933 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_param_63933)){
            _param_63933 = (object)DBL_PTR(_param_63933)->dbl;
        }

        /** fwdref.e:462					token old = {RECORDED, d[3]}*/
        _2 = (object)SEQ_PTR(_d_63923);
        _31465 = (object)*(((s1_ptr)_2)->base + 3LL);
        Ref(_31465);
        DeRef(_old_63936);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 508LL;
        ((intptr_t *)_2)[2] = _31465;
        _old_63936 = MAKE_SEQ(_1);
        _31465 = NOVALUE;

        /** fwdref.e:463					token new = {VARIABLE, sym}*/
        DeRefi(_new_63941);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -100LL;
        ((intptr_t *)_2)[2] = _sym_63849;
        _new_63941 = MAKE_SEQ(_1);

        /** fwdref.e:464					SymTab[param][S_CODE] = find_replace( old, SymTab[param][S_CODE], new )*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_param_63933 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _31470 = (object)*(((s1_ptr)_2)->base + _param_63933);
        _2 = (object)SEQ_PTR(_31470);
        if (!IS_ATOM_INT(_27S_CODE_20221)){
            _31471 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
        }
        else{
            _31471 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
        }
        _31470 = NOVALUE;
        RefDS(_old_63936);
        Ref(_31471);
        RefDS(_new_63941);
        _31472 = _14find_replace(_old_63936, _31471, _new_63941, 0LL);
        _31471 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_27S_CODE_20221))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31472;
        if( _1 != _31472 ){
            DeRef(_1);
        }
        _31472 = NOVALUE;
        _31468 = NOVALUE;
LC: 
        DeRef(_old_63936);
        _old_63936 = NOVALUE;
        DeRefi(_new_63941);
        _new_63941 = NOVALUE;
        DeRef(_d_63923);
        _d_63923 = NOVALUE;

        /** fwdref.e:466			end for*/
        _i_63920 = _i_63920 + 1LL;
        goto LA; // [413] 311
LB: 
        ;
    }

    /** fwdref.e:467			resolved_reference( ref )*/
    _42resolved_reference(_ref_63845);
L9: 

    /** fwdref.e:469		reset_code()*/
    _42reset_code();

    /** fwdref.e:470	end procedure*/
    DeRef(_tok_63844);
    DeRef(_fr_63846);
    DeRef(_31431);
    _31431 = NOVALUE;
    _31456 = NOVALUE;
    DeRef(_31426);
    _31426 = NOVALUE;
    return;
    ;
}


void _42patch_forward_init_check(object _tok_63957, object _ref_63958)
{
    object _fr_63959 = NOVALUE;
    object _31480 = NOVALUE;
    object _31479 = NOVALUE;
    object _31478 = NOVALUE;
    object _31476 = NOVALUE;
    object _31475 = NOVALUE;
    object _31474 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:474		sequence fr = forward_references[ref]*/
    DeRef(_fr_63959);
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    _fr_63959 = (object)*(((s1_ptr)_2)->base + _ref_63958);
    Ref(_fr_63959);

    /** fwdref.e:475		set_code( ref )*/
    _42set_code(_ref_63958);

    /** fwdref.e:476		if sequence( fr[FR_DATA] ) then*/
    _2 = (object)SEQ_PTR(_fr_63959);
    _31474 = (object)*(((s1_ptr)_2)->base + 12LL);
    _31475 = IS_SEQUENCE(_31474);
    _31474 = NOVALUE;
    if (_31475 == 0)
    {
        _31475 = NOVALUE;
        goto L1; // [27] 38
    }
    else{
        _31475 = NOVALUE;
    }

    /** fwdref.e:478			resolved_reference( ref )*/
    _42resolved_reference(_ref_63958);
    goto L2; // [35] 85
L1: 

    /** fwdref.e:479		elsif fr[FR_PC] > 0 then*/
    _2 = (object)SEQ_PTR(_fr_63959);
    _31476 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (binary_op_a(LESSEQ, _31476, 0LL)){
        _31476 = NOVALUE;
        goto L3; // [44] 78
    }
    _31476 = NOVALUE;

    /** fwdref.e:480			Code[fr[FR_PC]+1] = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_fr_63959);
    _31478 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (IS_ATOM_INT(_31478)) {
        _31479 = _31478 + 1;
        if (_31479 > MAXINT){
            _31479 = NewDouble((eudouble)_31479);
        }
    }
    else
    _31479 = binary_op(PLUS, 1, _31478);
    _31478 = NOVALUE;
    _2 = (object)SEQ_PTR(_tok_63957);
    _31480 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_31480);
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_31479))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31479)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _31479);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31480;
    if( _1 != _31480 ){
        DeRef(_1);
    }
    _31480 = NOVALUE;

    /** fwdref.e:481			resolved_reference( ref )*/
    _42resolved_reference(_ref_63958);
    goto L2; // [75] 85
L3: 

    /** fwdref.e:483			forward_error( tok, ref )*/
    Ref(_tok_63957);
    _42forward_error(_tok_63957, _ref_63958);
L2: 

    /** fwdref.e:485		reset_code()*/
    _42reset_code();

    /** fwdref.e:486	end procedure*/
    DeRef(_tok_63957);
    DeRef(_fr_63959);
    DeRef(_31479);
    _31479 = NOVALUE;
    return;
    ;
}


object _42expected_name(object _id_63976)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_63976)) {
        _1 = (object)(DBL_PTR(_id_63976)->dbl);
        DeRefDS(_id_63976);
        _id_63976 = _1;
    }

    /** fwdref.e:491		switch id with fallthru do*/
    _0 = _id_63976;
    switch ( _0 ){ 

        /** fwdref.e:492			case PROC then*/
        case 27:
        case 195:

        /** fwdref.e:494				return "a procedure"*/
        RefDS(_26596);
        return _26596;

        /** fwdref.e:496			case FUNC then*/
        case 501:
        case 196:

        /** fwdref.e:498				return "a function"*/
        RefDS(_26542);
        return _26542;

        /** fwdref.e:500			case VARIABLE then*/
        case -100:

        /** fwdref.e:501				return "a variable, constant or enum"*/
        RefDS(_31483);
        return _31483;

        /** fwdref.e:502			case else*/
        default:

        /** fwdref.e:503				return "something"*/
        RefDS(_31484);
        return _31484;
    ;}    ;
}


void _42patch_forward_type(object _tok_63993, object _ref_63994)
{
    object _fr_63995 = NOVALUE;
    object _syms_63997 = NOVALUE;
    object _31496 = NOVALUE;
    object _31495 = NOVALUE;
    object _31493 = NOVALUE;
    object _31492 = NOVALUE;
    object _31491 = NOVALUE;
    object _31489 = NOVALUE;
    object _31488 = NOVALUE;
    object _31487 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:510		sequence fr = forward_references[ref]*/
    DeRef(_fr_63995);
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    _fr_63995 = (object)*(((s1_ptr)_2)->base + _ref_63994);
    Ref(_fr_63995);

    /** fwdref.e:511		sequence syms = fr[FR_DATA]*/
    DeRef(_syms_63997);
    _2 = (object)SEQ_PTR(_fr_63995);
    _syms_63997 = (object)*(((s1_ptr)_2)->base + 12LL);
    Ref(_syms_63997);

    /** fwdref.e:512		for i = 2 to length( syms ) do*/
    if (IS_SEQUENCE(_syms_63997)){
            _31487 = SEQ_PTR(_syms_63997)->length;
    }
    else {
        _31487 = 1;
    }
    {
        object _i_64000;
        _i_64000 = 2LL;
L1: 
        if (_i_64000 > _31487){
            goto L2; // [26] 102
        }

        /** fwdref.e:513			SymTab[syms[i]][S_VTYPE] = tok[T_SYM]*/
        _2 = (object)SEQ_PTR(_syms_63997);
        _31488 = (object)*(((s1_ptr)_2)->base + _i_64000);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31488))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31488)->dbl));
        else
        _3 = (object)(_31488 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_tok_63993);
        _31491 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_31491);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 15LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31491;
        if( _1 != _31491 ){
            DeRef(_1);
        }
        _31491 = NOVALUE;
        _31489 = NOVALUE;

        /** fwdref.e:514			if TRANSLATE then*/
        if (_27TRANSLATE_20179 == 0)
        {
            goto L3; // [62] 95
        }
        else{
        }

        /** fwdref.e:515				SymTab[syms[i]][S_GTYPE] = CompileType(tok[T_SYM])*/
        _2 = (object)SEQ_PTR(_syms_63997);
        _31492 = (object)*(((s1_ptr)_2)->base + _i_64000);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31492))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31492)->dbl));
        else
        _3 = (object)(_31492 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_tok_63993);
        _31495 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_31495);
        _31496 = _43CompileType(_31495);
        _31495 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 36LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31496;
        if( _1 != _31496 ){
            DeRef(_1);
        }
        _31496 = NOVALUE;
        _31493 = NOVALUE;
L3: 

        /** fwdref.e:517		end for*/
        _i_64000 = _i_64000 + 1LL;
        goto L1; // [97] 33
L2: 
        ;
    }

    /** fwdref.e:518		resolved_reference( ref )*/
    _42resolved_reference(_ref_63994);

    /** fwdref.e:519	end procedure*/
    DeRef(_tok_63993);
    DeRef(_fr_63995);
    DeRef(_syms_63997);
    _31488 = NOVALUE;
    _31492 = NOVALUE;
    return;
    ;
}


void _42patch_forward_case(object _tok_64023, object _ref_64024)
{
    object _fr_64025 = NOVALUE;
    object _switch_pc_64027 = NOVALUE;
    object _case_sym_64030 = NOVALUE;
    object _case_values_64059 = NOVALUE;
    object _cx_64064 = NOVALUE;
    object _negative_64072 = NOVALUE;
    object _31534 = NOVALUE;
    object _31533 = NOVALUE;
    object _31532 = NOVALUE;
    object _31531 = NOVALUE;
    object _31530 = NOVALUE;
    object _31529 = NOVALUE;
    object _31527 = NOVALUE;
    object _31525 = NOVALUE;
    object _31524 = NOVALUE;
    object _31522 = NOVALUE;
    object _31521 = NOVALUE;
    object _31518 = NOVALUE;
    object _31516 = NOVALUE;
    object _31515 = NOVALUE;
    object _31514 = NOVALUE;
    object _31513 = NOVALUE;
    object _31512 = NOVALUE;
    object _31511 = NOVALUE;
    object _31510 = NOVALUE;
    object _31509 = NOVALUE;
    object _31508 = NOVALUE;
    object _31506 = NOVALUE;
    object _31505 = NOVALUE;
    object _31504 = NOVALUE;
    object _31503 = NOVALUE;
    object _31501 = NOVALUE;
    object _31499 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:522		sequence fr = forward_references[ref]*/
    DeRef(_fr_64025);
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    _fr_64025 = (object)*(((s1_ptr)_2)->base + _ref_64024);
    Ref(_fr_64025);

    /** fwdref.e:524		integer switch_pc = fr[FR_DATA]*/
    _2 = (object)SEQ_PTR(_fr_64025);
    _switch_pc_64027 = (object)*(((s1_ptr)_2)->base + 12LL);
    if (!IS_ATOM_INT(_switch_pc_64027))
    _switch_pc_64027 = (object)DBL_PTR(_switch_pc_64027)->dbl;

    /** fwdref.e:527		if fr[FR_SUBPROG] = TopLevelSub then*/
    _2 = (object)SEQ_PTR(_fr_64025);
    _31499 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (binary_op_a(NOTEQ, _31499, _27TopLevelSub_20578)){
        _31499 = NOVALUE;
        goto L1; // [27] 48
    }
    _31499 = NOVALUE;

    /** fwdref.e:528			case_sym = Code[switch_pc + 2]*/
    _31501 = _switch_pc_64027 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _case_sym_64030 = (object)*(((s1_ptr)_2)->base + _31501);
    if (!IS_ATOM_INT(_case_sym_64030)){
        _case_sym_64030 = (object)DBL_PTR(_case_sym_64030)->dbl;
    }
    goto L2; // [45] 77
L1: 

    /** fwdref.e:530			case_sym = SymTab[fr[FR_SUBPROG]][S_CODE][switch_pc + 2]*/
    _2 = (object)SEQ_PTR(_fr_64025);
    _31503 = (object)*(((s1_ptr)_2)->base + 4LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_31503)){
        _31504 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31503)->dbl));
    }
    else{
        _31504 = (object)*(((s1_ptr)_2)->base + _31503);
    }
    _2 = (object)SEQ_PTR(_31504);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _31505 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _31505 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    _31504 = NOVALUE;
    _31506 = _switch_pc_64027 + 2LL;
    _2 = (object)SEQ_PTR(_31505);
    _case_sym_64030 = (object)*(((s1_ptr)_2)->base + _31506);
    if (!IS_ATOM_INT(_case_sym_64030)){
        _case_sym_64030 = (object)DBL_PTR(_case_sym_64030)->dbl;
    }
    _31505 = NOVALUE;
L2: 

    /** fwdref.e:533		if SymTab[tok[T_SYM]][S_FILE_NO] = fr[FR_FILE] and fr[FR_SUBPROG] = TopLevelSub then*/
    _2 = (object)SEQ_PTR(_tok_64023);
    _31508 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_31508)){
        _31509 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31508)->dbl));
    }
    else{
        _31509 = (object)*(((s1_ptr)_2)->base + _31508);
    }
    _2 = (object)SEQ_PTR(_31509);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _31510 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _31510 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _31509 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_64025);
    _31511 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (IS_ATOM_INT(_31510) && IS_ATOM_INT(_31511)) {
        _31512 = (_31510 == _31511);
    }
    else {
        _31512 = binary_op(EQUALS, _31510, _31511);
    }
    _31510 = NOVALUE;
    _31511 = NOVALUE;
    if (IS_ATOM_INT(_31512)) {
        if (_31512 == 0) {
            goto L3; // [105] 129
        }
    }
    else {
        if (DBL_PTR(_31512)->dbl == 0.0) {
            goto L3; // [105] 129
        }
    }
    _2 = (object)SEQ_PTR(_fr_64025);
    _31514 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_31514)) {
        _31515 = (_31514 == _27TopLevelSub_20578);
    }
    else {
        _31515 = binary_op(EQUALS, _31514, _27TopLevelSub_20578);
    }
    _31514 = NOVALUE;
    if (_31515 == 0) {
        DeRef(_31515);
        _31515 = NOVALUE;
        goto L3; // [120] 129
    }
    else {
        if (!IS_ATOM_INT(_31515) && DBL_PTR(_31515)->dbl == 0.0){
            DeRef(_31515);
            _31515 = NOVALUE;
            goto L3; // [120] 129
        }
        DeRef(_31515);
        _31515 = NOVALUE;
    }
    DeRef(_31515);
    _31515 = NOVALUE;

    /** fwdref.e:534			return*/
    DeRef(_tok_64023);
    DeRef(_fr_64025);
    DeRef(_case_values_64059);
    _31508 = NOVALUE;
    DeRef(_31512);
    _31512 = NOVALUE;
    _31503 = NOVALUE;
    DeRef(_31506);
    _31506 = NOVALUE;
    DeRef(_31501);
    _31501 = NOVALUE;
    return;
L3: 

    /** fwdref.e:537		sequence case_values = SymTab[case_sym][S_OBJ]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31516 = (object)*(((s1_ptr)_2)->base + _case_sym_64030);
    DeRef(_case_values_64059);
    _2 = (object)SEQ_PTR(_31516);
    _case_values_64059 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_case_values_64059);
    _31516 = NOVALUE;

    /** fwdref.e:539		integer cx = find( { ref }, case_values )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _ref_64024;
    _31518 = MAKE_SEQ(_1);
    _cx_64064 = find_from(_31518, _case_values_64059, 1LL);
    DeRefDS(_31518);
    _31518 = NOVALUE;

    /** fwdref.e:540		if not cx then*/
    if (_cx_64064 != 0)
    goto L4; // [160] 178

    /** fwdref.e:541			cx = find( { -ref }, case_values )*/
    if ((uintptr_t)_ref_64024 == (uintptr_t)HIGH_BITS){
        _31521 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31521 = - _ref_64024;
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _31521;
    _31522 = MAKE_SEQ(_1);
    _31521 = NOVALUE;
    _cx_64064 = find_from(_31522, _case_values_64059, 1LL);
    DeRefDS(_31522);
    _31522 = NOVALUE;
L4: 

    /** fwdref.e:544	 	ifdef DEBUG then	*/

    /** fwdref.e:551		integer negative = 0*/
    _negative_64072 = 0LL;

    /** fwdref.e:552		if case_values[cx][1] < 0 then*/
    _2 = (object)SEQ_PTR(_case_values_64059);
    _31524 = (object)*(((s1_ptr)_2)->base + _cx_64064);
    _2 = (object)SEQ_PTR(_31524);
    _31525 = (object)*(((s1_ptr)_2)->base + 1LL);
    _31524 = NOVALUE;
    if (binary_op_a(GREATEREQ, _31525, 0LL)){
        _31525 = NOVALUE;
        goto L5; // [195] 224
    }
    _31525 = NOVALUE;

    /** fwdref.e:553			negative = 1*/
    _negative_64072 = 1LL;

    /** fwdref.e:554			case_values[cx][1] *= -1*/
    _2 = (object)SEQ_PTR(_case_values_64059);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _case_values_64059 = MAKE_SEQ(_2);
    }
    _3 = (object)(_cx_64064 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _31529 = (object)*(((s1_ptr)_2)->base + 1LL);
    _31527 = NOVALUE;
    if (IS_ATOM_INT(_31529)) {
        {
            int128_t p128 = (int128_t)_31529 * (int128_t)-1LL;
            if( p128 != (int128_t)(_31530 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _31530 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _31530 = binary_op(MULTIPLY, _31529, -1LL);
    }
    _31529 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31530;
    if( _1 != _31530 ){
        DeRef(_1);
    }
    _31530 = NOVALUE;
    _31527 = NOVALUE;
L5: 

    /** fwdref.e:557		if negative then*/
    if (_negative_64072 == 0)
    {
        goto L6; // [226] 247
    }
    else{
    }

    /** fwdref.e:558			case_values[cx] = - tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_64023);
    _31531 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_31531)) {
        if ((uintptr_t)_31531 == (uintptr_t)HIGH_BITS){
            _31532 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _31532 = - _31531;
        }
    }
    else {
        _31532 = unary_op(UMINUS, _31531);
    }
    _31531 = NOVALUE;
    _2 = (object)SEQ_PTR(_case_values_64059);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _case_values_64059 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _cx_64064);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31532;
    if( _1 != _31532 ){
        DeRef(_1);
    }
    _31532 = NOVALUE;
    goto L7; // [244] 260
L6: 

    /** fwdref.e:560			case_values[cx] = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_64023);
    _31533 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_31533);
    _2 = (object)SEQ_PTR(_case_values_64059);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _case_values_64059 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _cx_64064);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31533;
    if( _1 != _31533 ){
        DeRef(_1);
    }
    _31533 = NOVALUE;
L7: 

    /** fwdref.e:562		SymTab[case_sym][S_OBJ] = case_values*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_case_sym_64030 + ((s1_ptr)_2)->base);
    RefDS(_case_values_64059);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _case_values_64059;
    DeRef(_1);
    _31534 = NOVALUE;

    /** fwdref.e:563		resolved_reference( ref )*/
    _42resolved_reference(_ref_64024);

    /** fwdref.e:564	end procedure*/
    DeRef(_tok_64023);
    DeRef(_fr_64025);
    DeRefDS(_case_values_64059);
    _31508 = NOVALUE;
    DeRef(_31512);
    _31512 = NOVALUE;
    _31503 = NOVALUE;
    DeRef(_31506);
    _31506 = NOVALUE;
    DeRef(_31501);
    _31501 = NOVALUE;
    return;
    ;
}


void _42patch_forward_type_check(object _tok_64095, object _ref_64096)
{
    object _fr_64097 = NOVALUE;
    object _which_type_64100 = NOVALUE;
    object _var_64102 = NOVALUE;
    object _pc_64135 = NOVALUE;
    object _with_type_check_64137 = NOVALUE;
    object _c_64167 = NOVALUE;
    object _subprog_inlined_insert_code_at_332_64176 = NOVALUE;
    object _code_inlined_insert_code_at_329_64175 = NOVALUE;
    object _subprog_inlined_insert_code_at_415_64192 = NOVALUE;
    object _code_inlined_insert_code_at_412_64191 = NOVALUE;
    object _subprog_inlined_insert_code_at_477_64202 = NOVALUE;
    object _code_inlined_insert_code_at_474_64201 = NOVALUE;
    object _subprog_inlined_insert_code_at_539_64212 = NOVALUE;
    object _code_inlined_insert_code_at_536_64211 = NOVALUE;
    object _start_pc_64219 = NOVALUE;
    object _subprog_inlined_insert_code_at_647_64236 = NOVALUE;
    object _code_inlined_insert_code_at_644_64235 = NOVALUE;
    object _c_64239 = NOVALUE;
    object _subprog_inlined_insert_code_at_741_64255 = NOVALUE;
    object _code_inlined_insert_code_at_738_64254 = NOVALUE;
    object _start_pc_64266 = NOVALUE;
    object _subprog_inlined_insert_code_at_886_64286 = NOVALUE;
    object _code_inlined_insert_code_at_883_64285 = NOVALUE;
    object _subprog_inlined_insert_code_at_987_64307 = NOVALUE;
    object _code_inlined_insert_code_at_984_64306 = NOVALUE;
    object _31624 = NOVALUE;
    object _31623 = NOVALUE;
    object _31622 = NOVALUE;
    object _31621 = NOVALUE;
    object _31620 = NOVALUE;
    object _31619 = NOVALUE;
    object _31618 = NOVALUE;
    object _31616 = NOVALUE;
    object _31614 = NOVALUE;
    object _31613 = NOVALUE;
    object _31612 = NOVALUE;
    object _31611 = NOVALUE;
    object _31610 = NOVALUE;
    object _31609 = NOVALUE;
    object _31608 = NOVALUE;
    object _31606 = NOVALUE;
    object _31605 = NOVALUE;
    object _31604 = NOVALUE;
    object _31603 = NOVALUE;
    object _31602 = NOVALUE;
    object _31601 = NOVALUE;
    object _31599 = NOVALUE;
    object _31598 = NOVALUE;
    object _31597 = NOVALUE;
    object _31596 = NOVALUE;
    object _31594 = NOVALUE;
    object _31593 = NOVALUE;
    object _31590 = NOVALUE;
    object _31589 = NOVALUE;
    object _31587 = NOVALUE;
    object _31586 = NOVALUE;
    object _31585 = NOVALUE;
    object _31584 = NOVALUE;
    object _31583 = NOVALUE;
    object _31582 = NOVALUE;
    object _31580 = NOVALUE;
    object _31579 = NOVALUE;
    object _31576 = NOVALUE;
    object _31575 = NOVALUE;
    object _31572 = NOVALUE;
    object _31571 = NOVALUE;
    object _31567 = NOVALUE;
    object _31566 = NOVALUE;
    object _31564 = NOVALUE;
    object _31563 = NOVALUE;
    object _31561 = NOVALUE;
    object _31560 = NOVALUE;
    object _31557 = NOVALUE;
    object _31554 = NOVALUE;
    object _31552 = NOVALUE;
    object _31549 = NOVALUE;
    object _31548 = NOVALUE;
    object _31545 = NOVALUE;
    object _31540 = NOVALUE;
    object _31539 = NOVALUE;
    object _31537 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:568		sequence fr = forward_references[ref]*/
    DeRef(_fr_64097);
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    _fr_64097 = (object)*(((s1_ptr)_2)->base + _ref_64096);
    Ref(_fr_64097);

    /** fwdref.e:572		if fr[FR_OP] = TYPE_CHECK_FORWARD then*/
    _2 = (object)SEQ_PTR(_fr_64097);
    _31537 = (object)*(((s1_ptr)_2)->base + 10LL);
    if (binary_op_a(NOTEQ, _31537, 197LL)){
        _31537 = NOVALUE;
        goto L1; // [21] 86
    }
    _31537 = NOVALUE;

    /** fwdref.e:573			which_type = SymTab[tok[T_SYM]][S_VTYPE]*/
    _2 = (object)SEQ_PTR(_tok_64095);
    _31539 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_31539)){
        _31540 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31539)->dbl));
    }
    else{
        _31540 = (object)*(((s1_ptr)_2)->base + _31539);
    }
    _2 = (object)SEQ_PTR(_31540);
    _which_type_64100 = (object)*(((s1_ptr)_2)->base + 15LL);
    if (!IS_ATOM_INT(_which_type_64100)){
        _which_type_64100 = (object)DBL_PTR(_which_type_64100)->dbl;
    }
    _31540 = NOVALUE;

    /** fwdref.e:574			if not which_type then*/
    if (_which_type_64100 != 0)
    goto L2; // [49] 72

    /** fwdref.e:575				which_type = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_64095);
    _which_type_64100 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_which_type_64100)){
        _which_type_64100 = (object)DBL_PTR(_which_type_64100)->dbl;
    }

    /** fwdref.e:576				var = 0*/
    _var_64102 = 0LL;
    goto L3; // [69] 144
L2: 

    /** fwdref.e:578				var = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_64095);
    _var_64102 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_var_64102)){
        _var_64102 = (object)DBL_PTR(_var_64102)->dbl;
    }
    goto L3; // [83] 144
L1: 

    /** fwdref.e:582		elsif fr[FR_OP] = TYPE then*/
    _2 = (object)SEQ_PTR(_fr_64097);
    _31545 = (object)*(((s1_ptr)_2)->base + 10LL);
    if (binary_op_a(NOTEQ, _31545, 504LL)){
        _31545 = NOVALUE;
        goto L4; // [94] 118
    }
    _31545 = NOVALUE;

    /** fwdref.e:583			which_type = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_64095);
    _which_type_64100 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_which_type_64100)){
        _which_type_64100 = (object)DBL_PTR(_which_type_64100)->dbl;
    }

    /** fwdref.e:584			var = 0*/
    _var_64102 = 0LL;
    goto L3; // [115] 144
L4: 

    /** fwdref.e:587			prep_forward_error( ref )*/
    _42prep_forward_error(_ref_64096);

    /** fwdref.e:588			InternalErr( 262, { TYPE_CHECK, TYPE_CHECK_FORWARD, fr[FR_OP] })*/
    _2 = (object)SEQ_PTR(_fr_64097);
    _31548 = (object)*(((s1_ptr)_2)->base + 10LL);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 65LL;
    ((intptr_t*)_2)[2] = 197LL;
    Ref(_31548);
    ((intptr_t*)_2)[3] = _31548;
    _31549 = MAKE_SEQ(_1);
    _31548 = NOVALUE;
    _49InternalErr(262LL, _31549);
    _31549 = NOVALUE;
L3: 

    /** fwdref.e:591		if which_type < 0 then*/
    if (_which_type_64100 >= 0LL)
    goto L5; // [148] 158

    /** fwdref.e:593			return*/
    DeRef(_tok_64095);
    DeRef(_fr_64097);
    _31539 = NOVALUE;
    return;
L5: 

    /** fwdref.e:596		set_code( ref )*/
    _42set_code(_ref_64096);

    /** fwdref.e:598		integer pc = fr[FR_PC]*/
    _2 = (object)SEQ_PTR(_fr_64097);
    _pc_64135 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (!IS_ATOM_INT(_pc_64135))
    _pc_64135 = (object)DBL_PTR(_pc_64135)->dbl;

    /** fwdref.e:599		integer with_type_check = Code[pc + 2]*/
    _31552 = _pc_64135 + 2LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _with_type_check_64137 = (object)*(((s1_ptr)_2)->base + _31552);
    if (!IS_ATOM_INT(_with_type_check_64137)){
        _with_type_check_64137 = (object)DBL_PTR(_with_type_check_64137)->dbl;
    }

    /** fwdref.e:601		if Code[pc] != TYPE_CHECK_FORWARD then*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    _31554 = (object)*(((s1_ptr)_2)->base + _pc_64135);
    if (binary_op_a(EQUALS, _31554, 197LL)){
        _31554 = NOVALUE;
        goto L6; // [193] 204
    }
    _31554 = NOVALUE;

    /** fwdref.e:602			forward_error( tok, ref )*/
    Ref(_tok_64095);
    _42forward_error(_tok_64095, _ref_64096);
L6: 

    /** fwdref.e:604		if not var then*/
    if (_var_64102 != 0)
    goto L7; // [208] 226

    /** fwdref.e:606			var = Code[pc+1]*/
    _31557 = _pc_64135 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _var_64102 = (object)*(((s1_ptr)_2)->base + _31557);
    if (!IS_ATOM_INT(_var_64102)){
        _var_64102 = (object)DBL_PTR(_var_64102)->dbl;
    }
L7: 

    /** fwdref.e:609		if var < 0 then*/
    if (_var_64102 >= 0LL)
    goto L8; // [228] 238

    /** fwdref.e:611			return*/
    DeRef(_tok_64095);
    DeRef(_fr_64097);
    DeRef(_31557);
    _31557 = NOVALUE;
    DeRef(_31552);
    _31552 = NOVALUE;
    _31539 = NOVALUE;
    return;
L8: 

    /** fwdref.e:615		replace_code( {}, pc, pc + 2, fr[FR_SUBPROG])*/
    _31560 = _pc_64135 + 2LL;
    if ((object)((uintptr_t)_31560 + (uintptr_t)HIGH_BITS) >= 0){
        _31560 = NewDouble((eudouble)_31560);
    }
    _2 = (object)SEQ_PTR(_fr_64097);
    _31561 = (object)*(((s1_ptr)_2)->base + 4LL);
    RefDS(_22218);
    Ref(_31561);
    _42replace_code(_22218, _pc_64135, _31560, _31561);
    _31560 = NOVALUE;
    _31561 = NOVALUE;

    /** fwdref.e:617		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L9; // [258] 364
    }
    else{
    }

    /** fwdref.e:618			if with_type_check then*/
    if (_with_type_check_64137 == 0)
    {
        goto LA; // [263] 771
    }
    else{
    }

    /** fwdref.e:619				if which_type != object_type then*/
    if (_which_type_64100 == _53object_type_47227)
    goto LA; // [270] 771

    /** fwdref.e:620					if SymTab[which_type][S_EFFECT] then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31563 = (object)*(((s1_ptr)_2)->base + _which_type_64100);
    _2 = (object)SEQ_PTR(_31563);
    _31564 = (object)*(((s1_ptr)_2)->base + 23LL);
    _31563 = NOVALUE;
    if (_31564 == 0) {
        _31564 = NOVALUE;
        goto LB; // [288] 357
    }
    else {
        if (!IS_ATOM_INT(_31564) && DBL_PTR(_31564)->dbl == 0.0){
            _31564 = NOVALUE;
            goto LB; // [288] 357
        }
        _31564 = NOVALUE;
    }
    _31564 = NOVALUE;

    /** fwdref.e:622						integer c = NewTempSym()*/
    _c_64167 = _53NewTempSym(0LL);
    if (!IS_ATOM_INT(_c_64167)) {
        _1 = (object)(DBL_PTR(_c_64167)->dbl);
        DeRefDS(_c_64167);
        _c_64167 = _1;
    }

    /** fwdref.e:623						insert_code( { PROC, which_type, var, c, TYPE_CHECK }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 27LL;
    ((intptr_t*)_2)[2] = _which_type_64100;
    ((intptr_t*)_2)[3] = _var_64102;
    ((intptr_t*)_2)[4] = _c_64167;
    ((intptr_t*)_2)[5] = 65LL;
    _31566 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_64097);
    _31567 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_329_64175);
    _code_inlined_insert_code_at_329_64175 = _31566;
    _31566 = NOVALUE;
    Ref(_31567);
    DeRef(_subprog_inlined_insert_code_at_332_64176);
    _subprog_inlined_insert_code_at_332_64176 = _31567;
    _31567 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_332_64176)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_332_64176)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_332_64176);
        _subprog_inlined_insert_code_at_332_64176 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _42shifting_sub_63336 = _subprog_inlined_insert_code_at_332_64176;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_329_64175);
    _65insert_code(_code_inlined_insert_code_at_329_64175, _pc_64135);

    /** fwdref.e:84		shifting_sub = 0*/
    _42shifting_sub_63336 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto LC; // [345] 348
LC: 
    DeRefi(_code_inlined_insert_code_at_329_64175);
    _code_inlined_insert_code_at_329_64175 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_332_64176);
    _subprog_inlined_insert_code_at_332_64176 = NOVALUE;

    /** fwdref.e:624						pc += 5*/
    _pc_64135 = _pc_64135 + 5LL;
LB: 
    goto LA; // [361] 771
L9: 

    /** fwdref.e:630			if with_type_check then*/
    if (_with_type_check_64137 == 0)
    {
        goto LD; // [366] 770
    }
    else{
    }

    /** fwdref.e:632				if which_type = object_type then*/
    if (_which_type_64100 != _53object_type_47227)
    goto LE; // [373] 380
    goto LF; // [377] 769
LE: 

    /** fwdref.e:636					if which_type = integer_type then*/
    if (_which_type_64100 != _53integer_type_47233)
    goto L10; // [384] 442

    /** fwdref.e:637						insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 96LL;
    ((intptr_t *)_2)[2] = _var_64102;
    _31571 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_64097);
    _31572 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_412_64191);
    _code_inlined_insert_code_at_412_64191 = _31571;
    _31571 = NOVALUE;
    Ref(_31572);
    DeRef(_subprog_inlined_insert_code_at_415_64192);
    _subprog_inlined_insert_code_at_415_64192 = _31572;
    _31572 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_415_64192)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_415_64192)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_415_64192);
        _subprog_inlined_insert_code_at_415_64192 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _42shifting_sub_63336 = _subprog_inlined_insert_code_at_415_64192;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_412_64191);
    _65insert_code(_code_inlined_insert_code_at_412_64191, _pc_64135);

    /** fwdref.e:84		shifting_sub = 0*/
    _42shifting_sub_63336 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto L11; // [428] 431
L11: 
    DeRefi(_code_inlined_insert_code_at_412_64191);
    _code_inlined_insert_code_at_412_64191 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_415_64192);
    _subprog_inlined_insert_code_at_415_64192 = NOVALUE;

    /** fwdref.e:638						pc += 2*/
    _pc_64135 = _pc_64135 + 2LL;
    goto L12; // [439] 768
L10: 

    /** fwdref.e:640					elsif which_type = sequence_type then*/
    if (_which_type_64100 != _53sequence_type_47231)
    goto L13; // [446] 504

    /** fwdref.e:641						insert_code( { SEQUENCE_CHECK, var }, pc, fr[FR_SUBPROG])*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 97LL;
    ((intptr_t *)_2)[2] = _var_64102;
    _31575 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_64097);
    _31576 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_474_64201);
    _code_inlined_insert_code_at_474_64201 = _31575;
    _31575 = NOVALUE;
    Ref(_31576);
    DeRef(_subprog_inlined_insert_code_at_477_64202);
    _subprog_inlined_insert_code_at_477_64202 = _31576;
    _31576 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_477_64202)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_477_64202)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_477_64202);
        _subprog_inlined_insert_code_at_477_64202 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _42shifting_sub_63336 = _subprog_inlined_insert_code_at_477_64202;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_474_64201);
    _65insert_code(_code_inlined_insert_code_at_474_64201, _pc_64135);

    /** fwdref.e:84		shifting_sub = 0*/
    _42shifting_sub_63336 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto L14; // [490] 493
L14: 
    DeRefi(_code_inlined_insert_code_at_474_64201);
    _code_inlined_insert_code_at_474_64201 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_477_64202);
    _subprog_inlined_insert_code_at_477_64202 = NOVALUE;

    /** fwdref.e:642						pc += 2*/
    _pc_64135 = _pc_64135 + 2LL;
    goto L12; // [501] 768
L13: 

    /** fwdref.e:644					elsif which_type = atom_type then*/
    if (_which_type_64100 != _53atom_type_47229)
    goto L15; // [508] 566

    /** fwdref.e:645						insert_code( { ATOM_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 101LL;
    ((intptr_t *)_2)[2] = _var_64102;
    _31579 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_64097);
    _31580 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_536_64211);
    _code_inlined_insert_code_at_536_64211 = _31579;
    _31579 = NOVALUE;
    Ref(_31580);
    DeRef(_subprog_inlined_insert_code_at_539_64212);
    _subprog_inlined_insert_code_at_539_64212 = _31580;
    _31580 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_539_64212)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_539_64212)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_539_64212);
        _subprog_inlined_insert_code_at_539_64212 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _42shifting_sub_63336 = _subprog_inlined_insert_code_at_539_64212;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_536_64211);
    _65insert_code(_code_inlined_insert_code_at_536_64211, _pc_64135);

    /** fwdref.e:84		shifting_sub = 0*/
    _42shifting_sub_63336 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto L16; // [552] 555
L16: 
    DeRefi(_code_inlined_insert_code_at_536_64211);
    _code_inlined_insert_code_at_536_64211 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_539_64212);
    _subprog_inlined_insert_code_at_539_64212 = NOVALUE;

    /** fwdref.e:646						pc += 2*/
    _pc_64135 = _pc_64135 + 2LL;
    goto L12; // [563] 768
L15: 

    /** fwdref.e:648					elsif SymTab[which_type][S_NEXT] then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31582 = (object)*(((s1_ptr)_2)->base + _which_type_64100);
    _2 = (object)SEQ_PTR(_31582);
    _31583 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31582 = NOVALUE;
    if (_31583 == 0) {
        _31583 = NOVALUE;
        goto L17; // [580] 765
    }
    else {
        if (!IS_ATOM_INT(_31583) && DBL_PTR(_31583)->dbl == 0.0){
            _31583 = NOVALUE;
            goto L17; // [580] 765
        }
        _31583 = NOVALUE;
    }
    _31583 = NOVALUE;

    /** fwdref.e:649						integer start_pc = pc*/
    _start_pc_64219 = _pc_64135;

    /** fwdref.e:652						if SymTab[SymTab[which_type][S_NEXT]][S_VTYPE] = integer_type then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31584 = (object)*(((s1_ptr)_2)->base + _which_type_64100);
    _2 = (object)SEQ_PTR(_31584);
    _31585 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31584 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_31585)){
        _31586 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31585)->dbl));
    }
    else{
        _31586 = (object)*(((s1_ptr)_2)->base + _31585);
    }
    _2 = (object)SEQ_PTR(_31586);
    _31587 = (object)*(((s1_ptr)_2)->base + 15LL);
    _31586 = NOVALUE;
    if (binary_op_a(NOTEQ, _31587, _53integer_type_47233)){
        _31587 = NOVALUE;
        goto L18; // [616] 672
    }
    _31587 = NOVALUE;

    /** fwdref.e:654							insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 96LL;
    ((intptr_t *)_2)[2] = _var_64102;
    _31589 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_64097);
    _31590 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_644_64235);
    _code_inlined_insert_code_at_644_64235 = _31589;
    _31589 = NOVALUE;
    Ref(_31590);
    DeRef(_subprog_inlined_insert_code_at_647_64236);
    _subprog_inlined_insert_code_at_647_64236 = _31590;
    _31590 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_647_64236)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_647_64236)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_647_64236);
        _subprog_inlined_insert_code_at_647_64236 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _42shifting_sub_63336 = _subprog_inlined_insert_code_at_647_64236;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_644_64235);
    _65insert_code(_code_inlined_insert_code_at_644_64235, _pc_64135);

    /** fwdref.e:84		shifting_sub = 0*/
    _42shifting_sub_63336 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto L19; // [660] 663
L19: 
    DeRefi(_code_inlined_insert_code_at_644_64235);
    _code_inlined_insert_code_at_644_64235 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_647_64236);
    _subprog_inlined_insert_code_at_647_64236 = NOVALUE;

    /** fwdref.e:656							pc += 2*/
    _pc_64135 = _pc_64135 + 2LL;
L18: 

    /** fwdref.e:658						symtab_index c = NewTempSym()*/
    _c_64239 = _53NewTempSym(0LL);
    if (!IS_ATOM_INT(_c_64239)) {
        _1 = (object)(DBL_PTR(_c_64239)->dbl);
        DeRefDS(_c_64239);
        _c_64239 = _1;
    }

    /** fwdref.e:659						SymTab[fr[FR_SUBPROG]][S_STACK_SPACE] += 1*/
    _2 = (object)SEQ_PTR(_fr_64097);
    _31593 = (object)*(((s1_ptr)_2)->base + 4LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_31593))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31593)->dbl));
    else
    _3 = (object)(_31593 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_27S_STACK_SPACE_20269)){
        _31596 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_STACK_SPACE_20269)->dbl));
    }
    else{
        _31596 = (object)*(((s1_ptr)_2)->base + _27S_STACK_SPACE_20269);
    }
    _31594 = NOVALUE;
    if (IS_ATOM_INT(_31596)) {
        _31597 = _31596 + 1;
        if (_31597 > MAXINT){
            _31597 = NewDouble((eudouble)_31597);
        }
    }
    else
    _31597 = binary_op(PLUS, 1, _31596);
    _31596 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_STACK_SPACE_20269))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_STACK_SPACE_20269)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_STACK_SPACE_20269);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31597;
    if( _1 != _31597 ){
        DeRef(_1);
    }
    _31597 = NOVALUE;
    _31594 = NOVALUE;

    /** fwdref.e:660						insert_code( { PROC, which_type, var, c, TYPE_CHECK }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 27LL;
    ((intptr_t*)_2)[2] = _which_type_64100;
    ((intptr_t*)_2)[3] = _var_64102;
    ((intptr_t*)_2)[4] = _c_64239;
    ((intptr_t*)_2)[5] = 65LL;
    _31598 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_64097);
    _31599 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_738_64254);
    _code_inlined_insert_code_at_738_64254 = _31598;
    _31598 = NOVALUE;
    Ref(_31599);
    DeRef(_subprog_inlined_insert_code_at_741_64255);
    _subprog_inlined_insert_code_at_741_64255 = _31599;
    _31599 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_741_64255)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_741_64255)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_741_64255);
        _subprog_inlined_insert_code_at_741_64255 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _42shifting_sub_63336 = _subprog_inlined_insert_code_at_741_64255;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_738_64254);
    _65insert_code(_code_inlined_insert_code_at_738_64254, _pc_64135);

    /** fwdref.e:84		shifting_sub = 0*/
    _42shifting_sub_63336 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto L1A; // [753] 756
L1A: 
    DeRefi(_code_inlined_insert_code_at_738_64254);
    _code_inlined_insert_code_at_738_64254 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_741_64255);
    _subprog_inlined_insert_code_at_741_64255 = NOVALUE;

    /** fwdref.e:661						pc += 4*/
    _pc_64135 = _pc_64135 + 4LL;
L17: 
L12: 
LF: 
LD: 
LA: 

    /** fwdref.e:668		if (TRANSLATE or not with_type_check) and SymTab[which_type][S_NEXT] then*/
    if (_27TRANSLATE_20179 != 0) {
        _31601 = 1;
        goto L1B; // [775] 786
    }
    _31602 = (_with_type_check_64137 == 0);
    _31601 = (_31602 != 0);
L1B: 
    if (_31601 == 0) {
        goto L1C; // [786] 1013
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31604 = (object)*(((s1_ptr)_2)->base + _which_type_64100);
    _2 = (object)SEQ_PTR(_31604);
    _31605 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31604 = NOVALUE;
    if (_31605 == 0) {
        _31605 = NOVALUE;
        goto L1C; // [803] 1013
    }
    else {
        if (!IS_ATOM_INT(_31605) && DBL_PTR(_31605)->dbl == 0.0){
            _31605 = NOVALUE;
            goto L1C; // [803] 1013
        }
        _31605 = NOVALUE;
    }
    _31605 = NOVALUE;

    /** fwdref.e:669			integer start_pc = pc*/
    _start_pc_64266 = _pc_64135;

    /** fwdref.e:671			if which_type = sequence_type or*/
    _31606 = (_which_type_64100 == _53sequence_type_47231);
    if (_31606 != 0) {
        goto L1D; // [819] 858
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31608 = (object)*(((s1_ptr)_2)->base + _which_type_64100);
    _2 = (object)SEQ_PTR(_31608);
    _31609 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31608 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_31609)){
        _31610 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31609)->dbl));
    }
    else{
        _31610 = (object)*(((s1_ptr)_2)->base + _31609);
    }
    _2 = (object)SEQ_PTR(_31610);
    _31611 = (object)*(((s1_ptr)_2)->base + 15LL);
    _31610 = NOVALUE;
    if (IS_ATOM_INT(_31611)) {
        _31612 = (_31611 == _53sequence_type_47231);
    }
    else {
        _31612 = binary_op(EQUALS, _31611, _53sequence_type_47231);
    }
    _31611 = NOVALUE;
    if (_31612 == 0) {
        DeRef(_31612);
        _31612 = NOVALUE;
        goto L1E; // [854] 912
    }
    else {
        if (!IS_ATOM_INT(_31612) && DBL_PTR(_31612)->dbl == 0.0){
            DeRef(_31612);
            _31612 = NOVALUE;
            goto L1E; // [854] 912
        }
        DeRef(_31612);
        _31612 = NOVALUE;
    }
    DeRef(_31612);
    _31612 = NOVALUE;
L1D: 

    /** fwdref.e:674				insert_code( { SEQUENCE_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 97LL;
    ((intptr_t *)_2)[2] = _var_64102;
    _31613 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_64097);
    _31614 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_883_64285);
    _code_inlined_insert_code_at_883_64285 = _31613;
    _31613 = NOVALUE;
    Ref(_31614);
    DeRef(_subprog_inlined_insert_code_at_886_64286);
    _subprog_inlined_insert_code_at_886_64286 = _31614;
    _31614 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_886_64286)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_886_64286)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_886_64286);
        _subprog_inlined_insert_code_at_886_64286 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _42shifting_sub_63336 = _subprog_inlined_insert_code_at_886_64286;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_883_64285);
    _65insert_code(_code_inlined_insert_code_at_883_64285, _pc_64135);

    /** fwdref.e:84		shifting_sub = 0*/
    _42shifting_sub_63336 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto L1F; // [898] 901
L1F: 
    DeRefi(_code_inlined_insert_code_at_883_64285);
    _code_inlined_insert_code_at_883_64285 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_886_64286);
    _subprog_inlined_insert_code_at_886_64286 = NOVALUE;

    /** fwdref.e:675				pc += 2*/
    _pc_64135 = _pc_64135 + 2LL;
    goto L20; // [909] 1012
L1E: 

    /** fwdref.e:677			elsif which_type = integer_type or*/
    _31616 = (_which_type_64100 == _53integer_type_47233);
    if (_31616 != 0) {
        goto L21; // [920] 959
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31618 = (object)*(((s1_ptr)_2)->base + _which_type_64100);
    _2 = (object)SEQ_PTR(_31618);
    _31619 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31618 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_31619)){
        _31620 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31619)->dbl));
    }
    else{
        _31620 = (object)*(((s1_ptr)_2)->base + _31619);
    }
    _2 = (object)SEQ_PTR(_31620);
    _31621 = (object)*(((s1_ptr)_2)->base + 15LL);
    _31620 = NOVALUE;
    if (IS_ATOM_INT(_31621)) {
        _31622 = (_31621 == _53integer_type_47233);
    }
    else {
        _31622 = binary_op(EQUALS, _31621, _53integer_type_47233);
    }
    _31621 = NOVALUE;
    if (_31622 == 0) {
        DeRef(_31622);
        _31622 = NOVALUE;
        goto L22; // [955] 1011
    }
    else {
        if (!IS_ATOM_INT(_31622) && DBL_PTR(_31622)->dbl == 0.0){
            DeRef(_31622);
            _31622 = NOVALUE;
            goto L22; // [955] 1011
        }
        DeRef(_31622);
        _31622 = NOVALUE;
    }
    DeRef(_31622);
    _31622 = NOVALUE;
L21: 

    /** fwdref.e:680				insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 96LL;
    ((intptr_t *)_2)[2] = _var_64102;
    _31623 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_64097);
    _31624 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_984_64306);
    _code_inlined_insert_code_at_984_64306 = _31623;
    _31623 = NOVALUE;
    Ref(_31624);
    DeRef(_subprog_inlined_insert_code_at_987_64307);
    _subprog_inlined_insert_code_at_987_64307 = _31624;
    _31624 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_987_64307)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_987_64307)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_987_64307);
        _subprog_inlined_insert_code_at_987_64307 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _42shifting_sub_63336 = _subprog_inlined_insert_code_at_987_64307;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_984_64306);
    _65insert_code(_code_inlined_insert_code_at_984_64306, _pc_64135);

    /** fwdref.e:84		shifting_sub = 0*/
    _42shifting_sub_63336 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto L23; // [999] 1002
L23: 
    DeRefi(_code_inlined_insert_code_at_984_64306);
    _code_inlined_insert_code_at_984_64306 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_987_64307);
    _subprog_inlined_insert_code_at_987_64307 = NOVALUE;

    /** fwdref.e:681				pc += 4*/
    _pc_64135 = _pc_64135 + 4LL;
L22: 
L20: 
L1C: 

    /** fwdref.e:686		resolved_reference( ref )*/
    _42resolved_reference(_ref_64096);

    /** fwdref.e:687		reset_code()*/
    _42reset_code();

    /** fwdref.e:688	end procedure*/
    DeRef(_tok_64095);
    DeRef(_fr_64097);
    _31585 = NOVALUE;
    _31609 = NOVALUE;
    DeRef(_31557);
    _31557 = NOVALUE;
    DeRef(_31606);
    _31606 = NOVALUE;
    DeRef(_31616);
    _31616 = NOVALUE;
    _31593 = NOVALUE;
    DeRef(_31552);
    _31552 = NOVALUE;
    DeRef(_31602);
    _31602 = NOVALUE;
    _31619 = NOVALUE;
    _31539 = NOVALUE;
    return;
    ;
}


void _42prep_forward_error(object _ref_64311)
{
    object _31632 = NOVALUE;
    object _31630 = NOVALUE;
    object _31628 = NOVALUE;
    object _31626 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_ref_64311)) {
        _1 = (object)(DBL_PTR(_ref_64311)->dbl);
        DeRefDS(_ref_64311);
        _ref_64311 = _1;
    }

    /** fwdref.e:691		ThisLine = forward_references[ref][FR_THISLINE]*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    _31626 = (object)*(((s1_ptr)_2)->base + _ref_64311);
    DeRef(_49ThisLine_49693);
    _2 = (object)SEQ_PTR(_31626);
    _49ThisLine_49693 = (object)*(((s1_ptr)_2)->base + 7LL);
    Ref(_49ThisLine_49693);
    _31626 = NOVALUE;

    /** fwdref.e:692		bp = forward_references[ref][FR_BP]*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    _31628 = (object)*(((s1_ptr)_2)->base + _ref_64311);
    _2 = (object)SEQ_PTR(_31628);
    _49bp_49697 = (object)*(((s1_ptr)_2)->base + 8LL);
    if (!IS_ATOM_INT(_49bp_49697)){
        _49bp_49697 = (object)DBL_PTR(_49bp_49697)->dbl;
    }
    _31628 = NOVALUE;

    /** fwdref.e:693		line_number = forward_references[ref][FR_LINE]*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    _31630 = (object)*(((s1_ptr)_2)->base + _ref_64311);
    _2 = (object)SEQ_PTR(_31630);
    _27line_number_20572 = (object)*(((s1_ptr)_2)->base + 6LL);
    if (!IS_ATOM_INT(_27line_number_20572)){
        _27line_number_20572 = (object)DBL_PTR(_27line_number_20572)->dbl;
    }
    _31630 = NOVALUE;

    /** fwdref.e:694		current_file_no = forward_references[ref][FR_FILE]*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    _31632 = (object)*(((s1_ptr)_2)->base + _ref_64311);
    _2 = (object)SEQ_PTR(_31632);
    _27current_file_no_20571 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_27current_file_no_20571)){
        _27current_file_no_20571 = (object)DBL_PTR(_27current_file_no_20571)->dbl;
    }
    _31632 = NOVALUE;

    /** fwdref.e:695	end procedure*/
    return;
    ;
}


void _42forward_error(object _tok_64327, object _ref_64328)
{
    object _31639 = NOVALUE;
    object _31638 = NOVALUE;
    object _31637 = NOVALUE;
    object _31636 = NOVALUE;
    object _31635 = NOVALUE;
    object _31634 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:698		prep_forward_error( ref )*/
    _42prep_forward_error(_ref_64328);

    /** fwdref.e:699		CompileErr(EXPECTED_1_NOT_2, { expected_name( forward_references[ref][FR_TYPE] ),*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    _31634 = (object)*(((s1_ptr)_2)->base + _ref_64328);
    _2 = (object)SEQ_PTR(_31634);
    _31635 = (object)*(((s1_ptr)_2)->base + 1LL);
    _31634 = NOVALUE;
    Ref(_31635);
    _31636 = _42expected_name(_31635);
    _31635 = NOVALUE;
    _2 = (object)SEQ_PTR(_tok_64327);
    _31637 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_31637);
    _31638 = _42expected_name(_31637);
    _31637 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _31636;
    ((intptr_t *)_2)[2] = _31638;
    _31639 = MAKE_SEQ(_1);
    _31638 = NOVALUE;
    _31636 = NOVALUE;
    _49CompileErr(68LL, _31639, 0LL);
    _31639 = NOVALUE;

    /** fwdref.e:701	end procedure*/
    DeRef(_tok_64327);
    return;
    ;
}


object _42find_reference(object _fr_64340)
{
    object _name_64341 = NOVALUE;
    object _file_64343 = NOVALUE;
    object _ns_file_64345 = NOVALUE;
    object _ix_64346 = NOVALUE;
    object _ns_64349 = NOVALUE;
    object _ns_tok_64353 = NOVALUE;
    object _tok_64365 = NOVALUE;
    object _31650 = NOVALUE;
    object _31647 = NOVALUE;
    object _31645 = NOVALUE;
    object _31643 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:706		sequence name = fr[FR_NAME]*/
    DeRef(_name_64341);
    _2 = (object)SEQ_PTR(_fr_64340);
    _name_64341 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_name_64341);

    /** fwdref.e:707		integer file  = fr[FR_FILE]*/
    _2 = (object)SEQ_PTR(_fr_64340);
    _file_64343 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_file_64343))
    _file_64343 = (object)DBL_PTR(_file_64343)->dbl;

    /** fwdref.e:709		integer ns_file = -1*/
    _ns_file_64345 = -1LL;

    /** fwdref.e:710		integer ix = find( ':', name )*/
    _ix_64346 = find_from(58LL, _name_64341, 1LL);

    /** fwdref.e:711		if ix then*/
    if (_ix_64346 == 0)
    {
        goto L1; // [31] 85
    }
    else{
    }

    /** fwdref.e:712			sequence ns = name[1..ix-1]*/
    _31643 = _ix_64346 - 1LL;
    rhs_slice_target = (object_ptr)&_ns_64349;
    RHS_Slice(_name_64341, 1LL, _31643);

    /** fwdref.e:713			token ns_tok = keyfind( ns, ns_file, file, 1, fr[FR_HASHVAL] )*/
    _2 = (object)SEQ_PTR(_fr_64340);
    _31645 = (object)*(((s1_ptr)_2)->base + 11LL);
    RefDS(_ns_64349);
    Ref(_31645);
    _0 = _ns_tok_64353;
    _ns_tok_64353 = _53keyfind(_ns_64349, -1LL, _file_64343, 1LL, _31645);
    DeRef(_0);
    _31645 = NOVALUE;

    /** fwdref.e:714			if ns_tok[T_ID] != NAMESPACE then*/
    _2 = (object)SEQ_PTR(_ns_tok_64353);
    _31647 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _31647, 523LL)){
        _31647 = NOVALUE;
        goto L2; // [69] 80
    }
    _31647 = NOVALUE;

    /** fwdref.e:715				return ns_tok*/
    DeRefDS(_ns_64349);
    DeRefDS(_fr_64340);
    DeRefDS(_name_64341);
    DeRef(_tok_64365);
    _31643 = NOVALUE;
    return _ns_tok_64353;
L2: 
    DeRef(_ns_64349);
    _ns_64349 = NOVALUE;
    DeRef(_ns_tok_64353);
    _ns_tok_64353 = NOVALUE;
    goto L3; // [82] 92
L1: 

    /** fwdref.e:718			ns_file = fr[FR_QUALIFIED]*/
    _2 = (object)SEQ_PTR(_fr_64340);
    _ns_file_64345 = (object)*(((s1_ptr)_2)->base + 9LL);
    if (!IS_ATOM_INT(_ns_file_64345))
    _ns_file_64345 = (object)DBL_PTR(_ns_file_64345)->dbl;
L3: 

    /** fwdref.e:721		No_new_entry = 1*/
    _53No_new_entry_48427 = 1LL;

    /** fwdref.e:722		object tok = keyfind( name, ns_file, file, , fr[FR_HASHVAL] )*/
    _2 = (object)SEQ_PTR(_fr_64340);
    _31650 = (object)*(((s1_ptr)_2)->base + 11LL);
    RefDS(_name_64341);
    Ref(_31650);
    _0 = _tok_64365;
    _tok_64365 = _53keyfind(_name_64341, _ns_file_64345, _file_64343, 0LL, _31650);
    DeRef(_0);
    _31650 = NOVALUE;

    /** fwdref.e:723		No_new_entry = 0*/
    _53No_new_entry_48427 = 0LL;

    /** fwdref.e:724		return tok*/
    DeRefDS(_fr_64340);
    DeRefDS(_name_64341);
    DeRef(_31643);
    _31643 = NOVALUE;
    return _tok_64365;
    ;
}


void _42register_forward_type(object _sym_64373, object _ref_64374)
{
    object _31657 = NOVALUE;
    object _31656 = NOVALUE;
    object _31654 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:729		if ref < 0 then*/
    if (_ref_64374 >= 0LL)
    goto L1; // [7] 19

    /** fwdref.e:730			ref = -ref*/
    _ref_64374 = - _ref_64374;
L1: 

    /** fwdref.e:732		forward_references[ref][FR_DATA] &= sym*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63317 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64374 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _31656 = (object)*(((s1_ptr)_2)->base + 12LL);
    _31654 = NOVALUE;
    if (IS_SEQUENCE(_31656) && IS_ATOM(_sym_64373)) {
        Append(&_31657, _31656, _sym_64373);
    }
    else if (IS_ATOM(_31656) && IS_SEQUENCE(_sym_64373)) {
    }
    else {
        Concat((object_ptr)&_31657, _31656, _sym_64373);
        _31656 = NOVALUE;
    }
    _31656 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31657;
    if( _1 != _31657 ){
        DeRef(_1);
    }
    _31657 = NOVALUE;
    _31654 = NOVALUE;

    /** fwdref.e:733	end procedure*/
    return;
    ;
}


object _42new_forward_reference(object _fwd_op_64404, object _sym_64406, object _op_64407)
{
    object _ref_64408 = NOVALUE;
    object _len_64409 = NOVALUE;
    object _hashval_64439 = NOVALUE;
    object _default_sym_64514 = NOVALUE;
    object _param_64517 = NOVALUE;
    object _set_data_2__tmp_at578_64534 = NOVALUE;
    object _set_data_1__tmp_at578_64533 = NOVALUE;
    object _data_inlined_set_data_at_575_64532 = NOVALUE;
    object _31743 = NOVALUE;
    object _31742 = NOVALUE;
    object _31741 = NOVALUE;
    object _31738 = NOVALUE;
    object _31736 = NOVALUE;
    object _31735 = NOVALUE;
    object _31733 = NOVALUE;
    object _31732 = NOVALUE;
    object _31731 = NOVALUE;
    object _31729 = NOVALUE;
    object _31727 = NOVALUE;
    object _31725 = NOVALUE;
    object _31722 = NOVALUE;
    object _31721 = NOVALUE;
    object _31719 = NOVALUE;
    object _31717 = NOVALUE;
    object _31715 = NOVALUE;
    object _31713 = NOVALUE;
    object _31712 = NOVALUE;
    object _31711 = NOVALUE;
    object _31709 = NOVALUE;
    object _31706 = NOVALUE;
    object _31704 = NOVALUE;
    object _31702 = NOVALUE;
    object _31701 = NOVALUE;
    object _31700 = NOVALUE;
    object _31699 = NOVALUE;
    object _31697 = NOVALUE;
    object _31694 = NOVALUE;
    object _31693 = NOVALUE;
    object _31692 = NOVALUE;
    object _31690 = NOVALUE;
    object _31689 = NOVALUE;
    object _31688 = NOVALUE;
    object _31687 = NOVALUE;
    object _31685 = NOVALUE;
    object _31684 = NOVALUE;
    object _31683 = NOVALUE;
    object _31682 = NOVALUE;
    object _31680 = NOVALUE;
    object _31677 = NOVALUE;
    object _31676 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_64406)) {
        _1 = (object)(DBL_PTR(_sym_64406)->dbl);
        DeRefDS(_sym_64406);
        _sym_64406 = _1;
    }

    /** fwdref.e:754			len = length( inactive_references )*/
    if (IS_SEQUENCE(_42inactive_references_63321)){
            _len_64409 = SEQ_PTR(_42inactive_references_63321)->length;
    }
    else {
        _len_64409 = 1;
    }

    /** fwdref.e:757		if len then*/
    if (_len_64409 == 0)
    {
        goto L1; // [16] 39
    }
    else{
    }

    /** fwdref.e:758			ref = inactive_references[len]*/
    _2 = (object)SEQ_PTR(_42inactive_references_63321);
    _ref_64408 = (object)*(((s1_ptr)_2)->base + _len_64409);
    if (!IS_ATOM_INT(_ref_64408))
    _ref_64408 = (object)DBL_PTR(_ref_64408)->dbl;

    /** fwdref.e:759			inactive_references = remove( inactive_references, len, len )*/
    {
        s1_ptr assign_space = SEQ_PTR(_42inactive_references_63321);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_len_64409)) ? _len_64409 : (object)(DBL_PTR(_len_64409)->dbl);
        int stop = (IS_ATOM_INT(_len_64409)) ? _len_64409 : (object)(DBL_PTR(_len_64409)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_42inactive_references_63321), start, &_42inactive_references_63321 );
            }
            else Tail(SEQ_PTR(_42inactive_references_63321), stop+1, &_42inactive_references_63321);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_42inactive_references_63321), start, &_42inactive_references_63321);
        }
        else {
            assign_slice_seq = &assign_space;
            _42inactive_references_63321 = Remove_elements(start, stop, (SEQ_PTR(_42inactive_references_63321)->ref == 1));
        }
    }
    goto L2; // [36] 55
L1: 

    /** fwdref.e:761			forward_references &= 0*/
    Append(&_42forward_references_63317, _42forward_references_63317, 0LL);

    /** fwdref.e:762			ref = length( forward_references )*/
    if (IS_SEQUENCE(_42forward_references_63317)){
            _ref_64408 = SEQ_PTR(_42forward_references_63317)->length;
    }
    else {
        _ref_64408 = 1;
    }
L2: 

    /** fwdref.e:764		forward_references[ref] = repeat( 0, FR_SIZE )*/
    _31676 = Repeat(0LL, 12LL);
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _ref_64408);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31676;
    if( _1 != _31676 ){
        DeRef(_1);
    }
    _31676 = NOVALUE;

    /** fwdref.e:766		forward_references[ref][FR_TYPE]      = fwd_op*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63317 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64408 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _fwd_op_64404;
    DeRef(_1);
    _31677 = NOVALUE;

    /** fwdref.e:767		if sym < 0 then*/
    if (_sym_64406 >= 0LL)
    goto L3; // [84] 143

    /** fwdref.e:768			forward_references[ref][FR_NAME] = forward_references[-sym][FR_NAME]*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63317 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64408 + ((s1_ptr)_2)->base);
    if ((uintptr_t)_sym_64406 == (uintptr_t)HIGH_BITS){
        _31682 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31682 = - _sym_64406;
    }
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    if (!IS_ATOM_INT(_31682)){
        _31683 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31682)->dbl));
    }
    else{
        _31683 = (object)*(((s1_ptr)_2)->base + _31682);
    }
    _2 = (object)SEQ_PTR(_31683);
    _31684 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31683 = NOVALUE;
    Ref(_31684);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31684;
    if( _1 != _31684 ){
        DeRef(_1);
    }
    _31684 = NOVALUE;
    _31680 = NOVALUE;

    /** fwdref.e:769			forward_references[ref][FR_HASHVAL] = forward_references[-sym][FR_HASHVAL]*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63317 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64408 + ((s1_ptr)_2)->base);
    if ((uintptr_t)_sym_64406 == (uintptr_t)HIGH_BITS){
        _31687 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31687 = - _sym_64406;
    }
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    if (!IS_ATOM_INT(_31687)){
        _31688 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31687)->dbl));
    }
    else{
        _31688 = (object)*(((s1_ptr)_2)->base + _31687);
    }
    _2 = (object)SEQ_PTR(_31688);
    _31689 = (object)*(((s1_ptr)_2)->base + 11LL);
    _31688 = NOVALUE;
    Ref(_31689);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31689;
    if( _1 != _31689 ){
        DeRef(_1);
    }
    _31689 = NOVALUE;
    _31685 = NOVALUE;
    goto L4; // [140] 242
L3: 

    /** fwdref.e:771			forward_references[ref][FR_NAME] = SymTab[sym][S_NAME]*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63317 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64408 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31692 = (object)*(((s1_ptr)_2)->base + _sym_64406);
    _2 = (object)SEQ_PTR(_31692);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _31693 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _31693 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _31692 = NOVALUE;
    Ref(_31693);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31693;
    if( _1 != _31693 ){
        DeRef(_1);
    }
    _31693 = NOVALUE;
    _31690 = NOVALUE;

    /** fwdref.e:772			integer hashval = SymTab[sym][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31694 = (object)*(((s1_ptr)_2)->base + _sym_64406);
    _2 = (object)SEQ_PTR(_31694);
    _hashval_64439 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (!IS_ATOM_INT(_hashval_64439)){
        _hashval_64439 = (object)DBL_PTR(_hashval_64439)->dbl;
    }
    _31694 = NOVALUE;

    /** fwdref.e:773			if 0 = hashval then*/
    if (0LL != _hashval_64439)
    goto L5; // [186] 220

    /** fwdref.e:774				forward_references[ref][FR_HASHVAL] = hashfn( forward_references[ref][FR_NAME] )*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63317 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64408 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    _31699 = (object)*(((s1_ptr)_2)->base + _ref_64408);
    _2 = (object)SEQ_PTR(_31699);
    _31700 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31699 = NOVALUE;
    Ref(_31700);
    _31701 = _53hashfn(_31700);
    _31700 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31701;
    if( _1 != _31701 ){
        DeRef(_1);
    }
    _31701 = NOVALUE;
    _31697 = NOVALUE;
    goto L6; // [217] 239
L5: 

    /** fwdref.e:776				forward_references[ref][FR_HASHVAL] = hashval*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63317 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64408 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _hashval_64439;
    DeRef(_1);
    _31702 = NOVALUE;

    /** fwdref.e:777				remove_symbol( sym )*/
    _53remove_symbol(_sym_64406);
L6: 
L4: 

    /** fwdref.e:782		forward_references[ref][FR_FILE]      = current_file_no*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63317 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64408 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27current_file_no_20571;
    DeRef(_1);
    _31704 = NOVALUE;

    /** fwdref.e:783		forward_references[ref][FR_SUBPROG]   = CurrentSub*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63317 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64408 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27CurrentSub_20579;
    DeRef(_1);
    _31706 = NOVALUE;

    /** fwdref.e:785		if fwd_op != TYPE then*/
    if (_fwd_op_64404 == 504LL)
    goto L7; // [276] 303

    /** fwdref.e:786			forward_references[ref][FR_PC]        = length( Code ) + 1*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63317 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64408 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_27Code_20660)){
            _31711 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _31711 = 1;
    }
    _31712 = _31711 + 1;
    _31711 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31712;
    if( _1 != _31712 ){
        DeRef(_1);
    }
    _31712 = NOVALUE;
    _31709 = NOVALUE;
L7: 

    /** fwdref.e:789		forward_references[ref][FR_LINE]      = fwd_line_number*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63317 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64408 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27fwd_line_number_20573;
    DeRef(_1);
    _31713 = NOVALUE;

    /** fwdref.e:790		forward_references[ref][FR_THISLINE]  = ForwardLine*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63317 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64408 + ((s1_ptr)_2)->base);
    Ref(_49ForwardLine_49694);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 7LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _49ForwardLine_49694;
    DeRef(_1);
    _31715 = NOVALUE;

    /** fwdref.e:791		forward_references[ref][FR_BP]        = forward_bp*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63317 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64408 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 8LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _49forward_bp_49698;
    DeRef(_1);
    _31717 = NOVALUE;

    /** fwdref.e:792		forward_references[ref][FR_QUALIFIED] = get_qualified_fwd()*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63317 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64408 + ((s1_ptr)_2)->base);
    _31721 = _61get_qualified_fwd();
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31721;
    if( _1 != _31721 ){
        DeRef(_1);
    }
    _31721 = NOVALUE;
    _31719 = NOVALUE;

    /** fwdref.e:793		forward_references[ref][FR_OP]        = op*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63317 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64408 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _op_64407;
    DeRef(_1);
    _31722 = NOVALUE;

    /** fwdref.e:795		if op = GOTO then*/
    if (_op_64407 != 188LL)
    goto L8; // [381] 403

    /** fwdref.e:796			forward_references[ref][FR_DATA] = { sym }*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63317 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64408 + ((s1_ptr)_2)->base);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _sym_64406;
    _31727 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31727;
    if( _1 != _31727 ){
        DeRef(_1);
    }
    _31727 = NOVALUE;
    _31725 = NOVALUE;
L8: 

    /** fwdref.e:803		if CurrentSub = TopLevelSub then*/
    if (_27CurrentSub_20579 != _27TopLevelSub_20578)
    goto L9; // [409] 471

    /** fwdref.e:804			if length( toplevel_references ) < current_file_no then*/
    if (IS_SEQUENCE(_42toplevel_references_63320)){
            _31729 = SEQ_PTR(_42toplevel_references_63320)->length;
    }
    else {
        _31729 = 1;
    }
    if (_31729 >= _27current_file_no_20571)
    goto LA; // [422] 450

    /** fwdref.e:805				toplevel_references &= repeat( {}, current_file_no - length( toplevel_references ) )*/
    if (IS_SEQUENCE(_42toplevel_references_63320)){
            _31731 = SEQ_PTR(_42toplevel_references_63320)->length;
    }
    else {
        _31731 = 1;
    }
    _31732 = _27current_file_no_20571 - _31731;
    _31731 = NOVALUE;
    _31733 = Repeat(_22218, _31732);
    _31732 = NOVALUE;
    Concat((object_ptr)&_42toplevel_references_63320, _42toplevel_references_63320, _31733);
    DeRefDS(_31733);
    _31733 = NOVALUE;
LA: 

    /** fwdref.e:807			toplevel_references[current_file_no] &= ref*/
    _2 = (object)SEQ_PTR(_42toplevel_references_63320);
    _31735 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    if (IS_SEQUENCE(_31735) && IS_ATOM(_ref_64408)) {
        Append(&_31736, _31735, _ref_64408);
    }
    else if (IS_ATOM(_31735) && IS_SEQUENCE(_ref_64408)) {
    }
    else {
        Concat((object_ptr)&_31736, _31735, _ref_64408);
        _31735 = NOVALUE;
    }
    _31735 = NOVALUE;
    _2 = (object)SEQ_PTR(_42toplevel_references_63320);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42toplevel_references_63320 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27current_file_no_20571);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31736;
    if( _1 != _31736 ){
        DeRef(_1);
    }
    _31736 = NOVALUE;
    goto LB; // [468] 595
L9: 

    /** fwdref.e:809			add_active_reference( ref )*/
    _42add_active_reference(_ref_64408, _27current_file_no_20571);

    /** fwdref.e:811			if Parser_mode = PAM_RECORD then*/
    if (_27Parser_mode_20677 != 1LL)
    goto LC; // [485] 592

    /** fwdref.e:812				symtab_pointer default_sym = CurrentSub*/
    _default_sym_64514 = _27CurrentSub_20579;

    /** fwdref.e:813				symtab_pointer param = 0*/
    _param_64517 = 0LL;

    /** fwdref.e:814				while default_sym with entry do*/
    goto LD; // [507] 536
LE: 
    if (_default_sym_64514 == 0)
    {
        goto LF; // [510] 549
    }
    else{
    }

    /** fwdref.e:815					if sym_scope( default_sym ) = SC_PRIVATE then*/
    _31738 = _53sym_scope(_default_sym_64514);
    if (binary_op_a(NOTEQ, _31738, 3LL)){
        DeRef(_31738);
        _31738 = NOVALUE;
        goto L10; // [521] 533
    }
    DeRef(_31738);
    _31738 = NOVALUE;

    /** fwdref.e:816						param = default_sym*/
    _param_64517 = _default_sym_64514;
L10: 

    /** fwdref.e:818				entry*/
LD: 

    /** fwdref.e:819					default_sym = sym_next( default_sym )*/
    _default_sym_64514 = _53sym_next(_default_sym_64514);
    if (!IS_ATOM_INT(_default_sym_64514)) {
        _1 = (object)(DBL_PTR(_default_sym_64514)->dbl);
        DeRefDS(_default_sym_64514);
        _default_sym_64514 = _1;
    }

    /** fwdref.e:820				end while*/
    goto LE; // [546] 510
LF: 

    /** fwdref.e:821				set_data( ref, {{ PAM_RECORD, param, length( Recorded_sym ) }} )*/
    if (IS_SEQUENCE(_27Recorded_sym_20680)){
            _31741 = SEQ_PTR(_27Recorded_sym_20680)->length;
    }
    else {
        _31741 = 1;
    }
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = _param_64517;
    ((intptr_t*)_2)[3] = _31741;
    _31742 = MAKE_SEQ(_1);
    _31741 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _31742;
    _31743 = MAKE_SEQ(_1);
    _31742 = NOVALUE;
    DeRef(_data_inlined_set_data_at_575_64532);
    _data_inlined_set_data_at_575_64532 = _31743;
    _31743 = NOVALUE;

    /** fwdref.e:186		forward_references[ref][FR_DATA] = data*/
    _2 = (object)SEQ_PTR(_42forward_references_63317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63317 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64408 + ((s1_ptr)_2)->base);
    RefDS(_data_inlined_set_data_at_575_64532);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _data_inlined_set_data_at_575_64532;
    DeRef(_1);

    /** fwdref.e:187	end procedure*/
    goto L11; // [586] 589
L11: 
    DeRef(_data_inlined_set_data_at_575_64532);
    _data_inlined_set_data_at_575_64532 = NOVALUE;
LC: 
LB: 

    /** fwdref.e:824		fwdref_count += 1*/
    _42fwdref_count_63337 = _42fwdref_count_63337 + 1;

    /** fwdref.e:826		ifdef EUDIS then*/

    /** fwdref.e:839		return ref*/
    DeRef(_31682);
    _31682 = NOVALUE;
    DeRef(_31687);
    _31687 = NOVALUE;
    return _ref_64408;
    ;
}


void _42add_active_reference(object _ref_64538, object _file_no_64539)
{
    object _sp_64553 = NOVALUE;
    object _31767 = NOVALUE;
    object _31766 = NOVALUE;
    object _31764 = NOVALUE;
    object _31763 = NOVALUE;
    object _31762 = NOVALUE;
    object _31760 = NOVALUE;
    object _31759 = NOVALUE;
    object _31758 = NOVALUE;
    object _31755 = NOVALUE;
    object _31753 = NOVALUE;
    object _31752 = NOVALUE;
    object _31751 = NOVALUE;
    object _31749 = NOVALUE;
    object _31748 = NOVALUE;
    object _31747 = NOVALUE;
    object _31745 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:843		if length( active_references ) < file_no then*/
    if (IS_SEQUENCE(_42active_references_63319)){
            _31745 = SEQ_PTR(_42active_references_63319)->length;
    }
    else {
        _31745 = 1;
    }
    if (_31745 >= _file_no_64539)
    goto L1; // [12] 59

    /** fwdref.e:844			active_references &= repeat( {}, file_no - length( active_references ) )*/
    if (IS_SEQUENCE(_42active_references_63319)){
            _31747 = SEQ_PTR(_42active_references_63319)->length;
    }
    else {
        _31747 = 1;
    }
    _31748 = _file_no_64539 - _31747;
    _31747 = NOVALUE;
    _31749 = Repeat(_22218, _31748);
    _31748 = NOVALUE;
    Concat((object_ptr)&_42active_references_63319, _42active_references_63319, _31749);
    DeRefDS(_31749);
    _31749 = NOVALUE;

    /** fwdref.e:845			active_subprogs   &= repeat( {}, file_no - length( active_subprogs ) )*/
    if (IS_SEQUENCE(_42active_subprogs_63318)){
            _31751 = SEQ_PTR(_42active_subprogs_63318)->length;
    }
    else {
        _31751 = 1;
    }
    _31752 = _file_no_64539 - _31751;
    _31751 = NOVALUE;
    _31753 = Repeat(_22218, _31752);
    _31752 = NOVALUE;
    Concat((object_ptr)&_42active_subprogs_63318, _42active_subprogs_63318, _31753);
    DeRefDS(_31753);
    _31753 = NOVALUE;
L1: 

    /** fwdref.e:847		integer sp = find( CurrentSub, active_subprogs[file_no] )*/
    _2 = (object)SEQ_PTR(_42active_subprogs_63318);
    _31755 = (object)*(((s1_ptr)_2)->base + _file_no_64539);
    _sp_64553 = find_from(_27CurrentSub_20579, _31755, 1LL);
    _31755 = NOVALUE;

    /** fwdref.e:848		if not sp then*/
    if (_sp_64553 != 0)
    goto L2; // [76] 127

    /** fwdref.e:849			active_subprogs[file_no] &= CurrentSub*/
    _2 = (object)SEQ_PTR(_42active_subprogs_63318);
    _31758 = (object)*(((s1_ptr)_2)->base + _file_no_64539);
    if (IS_SEQUENCE(_31758) && IS_ATOM(_27CurrentSub_20579)) {
        Append(&_31759, _31758, _27CurrentSub_20579);
    }
    else if (IS_ATOM(_31758) && IS_SEQUENCE(_27CurrentSub_20579)) {
    }
    else {
        Concat((object_ptr)&_31759, _31758, _27CurrentSub_20579);
        _31758 = NOVALUE;
    }
    _31758 = NOVALUE;
    _2 = (object)SEQ_PTR(_42active_subprogs_63318);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42active_subprogs_63318 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_no_64539);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31759;
    if( _1 != _31759 ){
        DeRef(_1);
    }
    _31759 = NOVALUE;

    /** fwdref.e:850			sp = length( active_subprogs[file_no] )*/
    _2 = (object)SEQ_PTR(_42active_subprogs_63318);
    _31760 = (object)*(((s1_ptr)_2)->base + _file_no_64539);
    if (IS_SEQUENCE(_31760)){
            _sp_64553 = SEQ_PTR(_31760)->length;
    }
    else {
        _sp_64553 = 1;
    }
    _31760 = NOVALUE;

    /** fwdref.e:852			active_references[file_no] = append( active_references[file_no], {} )*/
    _2 = (object)SEQ_PTR(_42active_references_63319);
    _31762 = (object)*(((s1_ptr)_2)->base + _file_no_64539);
    RefDS(_22218);
    Append(&_31763, _31762, _22218);
    _31762 = NOVALUE;
    _2 = (object)SEQ_PTR(_42active_references_63319);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42active_references_63319 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_no_64539);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31763;
    if( _1 != _31763 ){
        DeRef(_1);
    }
    _31763 = NOVALUE;
L2: 

    /** fwdref.e:854		active_references[file_no][sp] &= ref*/
    _2 = (object)SEQ_PTR(_42active_references_63319);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42active_references_63319 = MAKE_SEQ(_2);
    }
    _3 = (object)(_file_no_64539 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _31766 = (object)*(((s1_ptr)_2)->base + _sp_64553);
    _31764 = NOVALUE;
    if (IS_SEQUENCE(_31766) && IS_ATOM(_ref_64538)) {
        Append(&_31767, _31766, _ref_64538);
    }
    else if (IS_ATOM(_31766) && IS_SEQUENCE(_ref_64538)) {
    }
    else {
        Concat((object_ptr)&_31767, _31766, _ref_64538);
        _31766 = NOVALUE;
    }
    _31766 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _sp_64553);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31767;
    if( _1 != _31767 ){
        DeRef(_1);
    }
    _31767 = NOVALUE;
    _31764 = NOVALUE;

    /** fwdref.e:855	end procedure*/
    _31760 = NOVALUE;
    return;
    ;
}


object _42resolve_file(object _refs_64590, object _report_errors_64591, object _unincluded_ok_64592)
{
    object _errors_64593 = NOVALUE;
    object _ref_64597 = NOVALUE;
    object _fr_64599 = NOVALUE;
    object _tok_64612 = NOVALUE;
    object _code_sub_64620 = NOVALUE;
    object _fr_type_64622 = NOVALUE;
    object _sym_tok_64624 = NOVALUE;
    object _31821 = NOVALUE;
    object _31820 = NOVALUE;
    object _31819 = NOVALUE;
    object _31818 = NOVALUE;
    object _31817 = NOVALUE;
    object _31816 = NOVALUE;
    object _31811 = NOVALUE;
    object _31810 = NOVALUE;
    object _31809 = NOVALUE;
    object _31807 = NOVALUE;
    object _31806 = NOVALUE;
    object _31803 = NOVALUE;
    object _31802 = NOVALUE;
    object _31801 = NOVALUE;
    object _31797 = NOVALUE;
    object _31796 = NOVALUE;
    object _31788 = NOVALUE;
    object _31786 = NOVALUE;
    object _31785 = NOVALUE;
    object _31784 = NOVALUE;
    object _31783 = NOVALUE;
    object _31782 = NOVALUE;
    object _31781 = NOVALUE;
    object _31778 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:864		sequence errors = {}*/
    RefDS(_22218);
    DeRefi(_errors_64593);
    _errors_64593 = _22218;

    /** fwdref.e:865		for ar = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_64590)){
            _31778 = SEQ_PTR(_refs_64590)->length;
    }
    else {
        _31778 = 1;
    }
    {
        object _ar_64595;
        _ar_64595 = _31778;
L1: 
        if (_ar_64595 < 1LL){
            goto L2; // [19] 481
        }

        /** fwdref.e:866			integer ref = refs[ar]*/
        _2 = (object)SEQ_PTR(_refs_64590);
        _ref_64597 = (object)*(((s1_ptr)_2)->base + _ar_64595);
        if (!IS_ATOM_INT(_ref_64597))
        _ref_64597 = (object)DBL_PTR(_ref_64597)->dbl;

        /** fwdref.e:868			sequence fr = forward_references[ref]*/
        DeRef(_fr_64599);
        _2 = (object)SEQ_PTR(_42forward_references_63317);
        _fr_64599 = (object)*(((s1_ptr)_2)->base + _ref_64597);
        Ref(_fr_64599);

        /** fwdref.e:869			if include_matrix[fr[FR_FILE]][current_file_no] = NOT_INCLUDED and not unincluded_ok then*/
        _2 = (object)SEQ_PTR(_fr_64599);
        _31781 = (object)*(((s1_ptr)_2)->base + 3LL);
        _2 = (object)SEQ_PTR(_28include_matrix_11579);
        if (!IS_ATOM_INT(_31781)){
            _31782 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31781)->dbl));
        }
        else{
            _31782 = (object)*(((s1_ptr)_2)->base + _31781);
        }
        _2 = (object)SEQ_PTR(_31782);
        _31783 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
        _31782 = NOVALUE;
        if (IS_ATOM_INT(_31783)) {
            _31784 = (_31783 == 0LL);
        }
        else {
            _31784 = binary_op(EQUALS, _31783, 0LL);
        }
        _31783 = NOVALUE;
        if (IS_ATOM_INT(_31784)) {
            if (_31784 == 0) {
                goto L3; // [66] 84
            }
        }
        else {
            if (DBL_PTR(_31784)->dbl == 0.0) {
                goto L3; // [66] 84
            }
        }
        _31786 = (_unincluded_ok_64592 == 0);
        if (_31786 == 0)
        {
            DeRef(_31786);
            _31786 = NOVALUE;
            goto L3; // [74] 84
        }
        else{
            DeRef(_31786);
            _31786 = NOVALUE;
        }

        /** fwdref.e:870				continue*/
        DeRef(_fr_64599);
        _fr_64599 = NOVALUE;
        DeRef(_tok_64612);
        _tok_64612 = NOVALUE;
        goto L4; // [81] 476
L3: 

        /** fwdref.e:873			token tok = find_reference( fr )*/
        RefDS(_fr_64599);
        _0 = _tok_64612;
        _tok_64612 = _42find_reference(_fr_64599);
        DeRef(_0);

        /** fwdref.e:874			if tok[T_ID] = IGNORED then*/
        _2 = (object)SEQ_PTR(_tok_64612);
        _31788 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _31788, 509LL)){
            _31788 = NOVALUE;
            goto L5; // [100] 117
        }
        _31788 = NOVALUE;

        /** fwdref.e:875				errors &= ref*/
        Append(&_errors_64593, _errors_64593, _ref_64597);

        /** fwdref.e:876				continue*/
        DeRefDS(_fr_64599);
        _fr_64599 = NOVALUE;
        DeRef(_tok_64612);
        _tok_64612 = NOVALUE;
        goto L4; // [114] 476
L5: 

        /** fwdref.e:880			integer code_sub = fr[FR_SUBPROG]*/
        _2 = (object)SEQ_PTR(_fr_64599);
        _code_sub_64620 = (object)*(((s1_ptr)_2)->base + 4LL);
        if (!IS_ATOM_INT(_code_sub_64620))
        _code_sub_64620 = (object)DBL_PTR(_code_sub_64620)->dbl;

        /** fwdref.e:881			integer fr_type  = fr[FR_TYPE]*/
        _2 = (object)SEQ_PTR(_fr_64599);
        _fr_type_64622 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (!IS_ATOM_INT(_fr_type_64622))
        _fr_type_64622 = (object)DBL_PTR(_fr_type_64622)->dbl;

        /** fwdref.e:882			integer sym_tok*/

        /** fwdref.e:884			switch fr_type label "fr_type" do*/
        _0 = _fr_type_64622;
        switch ( _0 ){ 

            /** fwdref.e:885				case PROC, FUNC then*/
            case 27:
            case 501:

            /** fwdref.e:887					sym_tok = SymTab[tok[T_SYM]][S_TOKEN]*/
            _2 = (object)SEQ_PTR(_tok_64612);
            _31796 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            if (!IS_ATOM_INT(_31796)){
                _31797 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31796)->dbl));
            }
            else{
                _31797 = (object)*(((s1_ptr)_2)->base + _31796);
            }
            _2 = (object)SEQ_PTR(_31797);
            if (!IS_ATOM_INT(_27S_TOKEN_20214)){
                _sym_tok_64624 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
            }
            else{
                _sym_tok_64624 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
            }
            if (!IS_ATOM_INT(_sym_tok_64624)){
                _sym_tok_64624 = (object)DBL_PTR(_sym_tok_64624)->dbl;
            }
            _31797 = NOVALUE;

            /** fwdref.e:888					if sym_tok = TYPE then*/
            if (_sym_tok_64624 != 504LL)
            goto L6; // [170] 184

            /** fwdref.e:889						sym_tok = FUNC*/
            _sym_tok_64624 = 501LL;
L6: 

            /** fwdref.e:891					if sym_tok != fr_type then*/
            if (_sym_tok_64624 == _fr_type_64622)
            goto L7; // [186] 220

            /** fwdref.e:892						if sym_tok != FUNC and fr_type != PROC then*/
            _31801 = (_sym_tok_64624 != 501LL);
            if (_31801 == 0) {
                goto L8; // [198] 219
            }
            _31803 = (_fr_type_64622 != 27LL);
            if (_31803 == 0)
            {
                DeRef(_31803);
                _31803 = NOVALUE;
                goto L8; // [209] 219
            }
            else{
                DeRef(_31803);
                _31803 = NOVALUE;
            }

            /** fwdref.e:893							forward_error( tok, ref )*/
            Ref(_tok_64612);
            _42forward_error(_tok_64612, _ref_64597);
L8: 
L7: 

            /** fwdref.e:896					switch sym_tok do*/
            _0 = _sym_tok_64624;
            switch ( _0 ){ 

                /** fwdref.e:897						case PROC, FUNC then*/
                case 27:
                case 501:

                /** fwdref.e:898							patch_forward_call( tok, ref )*/
                Ref(_tok_64612);
                _42patch_forward_call(_tok_64612, _ref_64597);

                /** fwdref.e:899							break "fr_type"*/
                goto L9; // [241] 446
                goto L9; // [243] 446

                /** fwdref.e:901						case else*/
                default:

                /** fwdref.e:902							forward_error( tok, ref )*/
                Ref(_tok_64612);
                _42forward_error(_tok_64612, _ref_64597);
            ;}            goto L9; // [256] 446

            /** fwdref.e:906				case VARIABLE then*/
            case -100:

            /** fwdref.e:907					sym_tok = SymTab[tok[T_SYM]][S_TOKEN]*/
            _2 = (object)SEQ_PTR(_tok_64612);
            _31806 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            if (!IS_ATOM_INT(_31806)){
                _31807 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31806)->dbl));
            }
            else{
                _31807 = (object)*(((s1_ptr)_2)->base + _31806);
            }
            _2 = (object)SEQ_PTR(_31807);
            if (!IS_ATOM_INT(_27S_TOKEN_20214)){
                _sym_tok_64624 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
            }
            else{
                _sym_tok_64624 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
            }
            if (!IS_ATOM_INT(_sym_tok_64624)){
                _sym_tok_64624 = (object)DBL_PTR(_sym_tok_64624)->dbl;
            }
            _31807 = NOVALUE;

            /** fwdref.e:908					if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
            _2 = (object)SEQ_PTR(_tok_64612);
            _31809 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            if (!IS_ATOM_INT(_31809)){
                _31810 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31809)->dbl));
            }
            else{
                _31810 = (object)*(((s1_ptr)_2)->base + _31809);
            }
            _2 = (object)SEQ_PTR(_31810);
            _31811 = (object)*(((s1_ptr)_2)->base + 4LL);
            _31810 = NOVALUE;
            if (binary_op_a(NOTEQ, _31811, 9LL)){
                _31811 = NOVALUE;
                goto LA; // [306] 323
            }
            _31811 = NOVALUE;

            /** fwdref.e:909						errors &= ref*/
            Append(&_errors_64593, _errors_64593, _ref_64597);

            /** fwdref.e:910						continue*/
            DeRef(_fr_64599);
            _fr_64599 = NOVALUE;
            DeRef(_tok_64612);
            _tok_64612 = NOVALUE;
            goto L4; // [320] 476
LA: 

            /** fwdref.e:913					switch sym_tok do*/
            _0 = _sym_tok_64624;
            switch ( _0 ){ 

                /** fwdref.e:914						case CONSTANT, ENUM, VARIABLE then*/
                case 417:
                case 427:
                case -100:

                /** fwdref.e:915							patch_forward_variable( tok, ref )*/
                Ref(_tok_64612);
                _42patch_forward_variable(_tok_64612, _ref_64597);

                /** fwdref.e:916							break "fr_type"*/
                goto L9; // [346] 446
                goto L9; // [348] 446

                /** fwdref.e:917						case else*/
                default:

                /** fwdref.e:918							forward_error( tok, ref )*/
                Ref(_tok_64612);
                _42forward_error(_tok_64612, _ref_64597);
            ;}            goto L9; // [361] 446

            /** fwdref.e:921				case TYPE_CHECK then*/
            case 65:

            /** fwdref.e:922					patch_forward_type_check( tok, ref )*/
            Ref(_tok_64612);
            _42patch_forward_type_check(_tok_64612, _ref_64597);
            goto L9; // [373] 446

            /** fwdref.e:924				case GLOBAL_INIT_CHECK then*/
            case 109:

            /** fwdref.e:925					patch_forward_init_check( tok, ref )*/
            Ref(_tok_64612);
            _42patch_forward_init_check(_tok_64612, _ref_64597);
            goto L9; // [385] 446

            /** fwdref.e:927				case CASE then*/
            case 186:

            /** fwdref.e:928					patch_forward_case( tok, ref )*/
            Ref(_tok_64612);
            _42patch_forward_case(_tok_64612, _ref_64597);
            goto L9; // [397] 446

            /** fwdref.e:930				case TYPE then*/
            case 504:

            /** fwdref.e:931					patch_forward_type( tok, ref )*/
            Ref(_tok_64612);
            _42patch_forward_type(_tok_64612, _ref_64597);
            goto L9; // [409] 446

            /** fwdref.e:933				case GOTO then*/
            case 188:

            /** fwdref.e:934					patch_forward_goto( tok, ref )*/
            Ref(_tok_64612);
            _42patch_forward_goto(_tok_64612, _ref_64597);
            goto L9; // [421] 446

            /** fwdref.e:936				case else*/
            default:

            /** fwdref.e:938					InternalErr( 263, {fr[FR_TYPE], fr[FR_NAME]})*/
            _2 = (object)SEQ_PTR(_fr_64599);
            _31816 = (object)*(((s1_ptr)_2)->base + 1LL);
            _2 = (object)SEQ_PTR(_fr_64599);
            _31817 = (object)*(((s1_ptr)_2)->base + 2LL);
            Ref(_31817);
            Ref(_31816);
            _1 = NewS1(2);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t *)_2)[1] = _31816;
            ((intptr_t *)_2)[2] = _31817;
            _31818 = MAKE_SEQ(_1);
            _31817 = NOVALUE;
            _31816 = NOVALUE;
            _49InternalErr(263LL, _31818);
            _31818 = NOVALUE;
        ;}L9: 

        /** fwdref.e:940			if report_errors and sequence( forward_references[ref] ) then*/
        if (_report_errors_64591 == 0) {
            goto LB; // [448] 472
        }
        _2 = (object)SEQ_PTR(_42forward_references_63317);
        _31820 = (object)*(((s1_ptr)_2)->base + _ref_64597);
        _31821 = IS_SEQUENCE(_31820);
        _31820 = NOVALUE;
        if (_31821 == 0)
        {
            _31821 = NOVALUE;
            goto LB; // [462] 472
        }
        else{
            _31821 = NOVALUE;
        }

        /** fwdref.e:941				errors &= ref*/
        Append(&_errors_64593, _errors_64593, _ref_64597);
LB: 
        DeRef(_fr_64599);
        _fr_64599 = NOVALUE;
        DeRef(_tok_64612);
        _tok_64612 = NOVALUE;

        /** fwdref.e:944		end for*/
L4: 
        _ar_64595 = _ar_64595 + -1LL;
        goto L1; // [476] 26
L2: 
        ;
    }

    /** fwdref.e:945		return errors*/
    DeRefDS(_refs_64590);
    DeRef(_31801);
    _31801 = NOVALUE;
    _31806 = NOVALUE;
    _31809 = NOVALUE;
    DeRef(_31784);
    _31784 = NOVALUE;
    _31781 = NOVALUE;
    _31796 = NOVALUE;
    return _errors_64593;
    ;
}


object _42file_name_based_symindex_compare(object _si1_64702, object _si2_64703)
{
    object _fn1_64724 = NOVALUE;
    object _fn2_64729 = NOVALUE;
    object _31850 = NOVALUE;
    object _31849 = NOVALUE;
    object _31848 = NOVALUE;
    object _31847 = NOVALUE;
    object _31846 = NOVALUE;
    object _31845 = NOVALUE;
    object _31844 = NOVALUE;
    object _31843 = NOVALUE;
    object _31842 = NOVALUE;
    object _31841 = NOVALUE;
    object _31840 = NOVALUE;
    object _31839 = NOVALUE;
    object _31837 = NOVALUE;
    object _31835 = NOVALUE;
    object _31834 = NOVALUE;
    object _31833 = NOVALUE;
    object _31832 = NOVALUE;
    object _31831 = NOVALUE;
    object _31830 = NOVALUE;
    object _31829 = NOVALUE;
    object _31828 = NOVALUE;
    object _31827 = NOVALUE;
    object _31826 = NOVALUE;
    object _31824 = NOVALUE;
    object _31823 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_si1_64702)) {
        _1 = (object)(DBL_PTR(_si1_64702)->dbl);
        DeRefDS(_si1_64702);
        _si1_64702 = _1;
    }
    if (!IS_ATOM_INT(_si2_64703)) {
        _1 = (object)(DBL_PTR(_si2_64703)->dbl);
        DeRefDS(_si2_64703);
        _si2_64703 = _1;
    }

    /** fwdref.e:949		if not symtab_index(si1) or not symtab_index(si2) then*/
    _31823 = _27symtab_index(_si1_64702);
    if (IS_ATOM_INT(_31823)) {
        _31824 = (_31823 == 0);
    }
    else {
        _31824 = unary_op(NOT, _31823);
    }
    DeRef(_31823);
    _31823 = NOVALUE;
    if (IS_ATOM_INT(_31824)) {
        if (_31824 != 0) {
            goto L1; // [14] 30
        }
    }
    else {
        if (DBL_PTR(_31824)->dbl != 0.0) {
            goto L1; // [14] 30
        }
    }
    _31826 = _27symtab_index(_si2_64703);
    if (IS_ATOM_INT(_31826)) {
        _31827 = (_31826 == 0);
    }
    else {
        _31827 = unary_op(NOT, _31826);
    }
    DeRef(_31826);
    _31826 = NOVALUE;
    if (_31827 == 0) {
        DeRef(_31827);
        _31827 = NOVALUE;
        goto L2; // [26] 37
    }
    else {
        if (!IS_ATOM_INT(_31827) && DBL_PTR(_31827)->dbl == 0.0){
            DeRef(_31827);
            _31827 = NOVALUE;
            goto L2; // [26] 37
        }
        DeRef(_31827);
        _31827 = NOVALUE;
    }
    DeRef(_31827);
    _31827 = NOVALUE;
L1: 

    /** fwdref.e:950			return 1 -- put non symbols last*/
    DeRef(_31824);
    _31824 = NOVALUE;
    return 1LL;
L2: 

    /** fwdref.e:952		if S_FILE_NO <= length(SymTab[si1]) and S_FILE_NO <= length(SymTab[si2]) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31828 = (object)*(((s1_ptr)_2)->base + _si1_64702);
    if (IS_SEQUENCE(_31828)){
            _31829 = SEQ_PTR(_31828)->length;
    }
    else {
        _31829 = 1;
    }
    _31828 = NOVALUE;
    if (IS_ATOM_INT(_27S_FILE_NO_20205)) {
        _31830 = (_27S_FILE_NO_20205 <= _31829);
    }
    else {
        _31830 = binary_op(LESSEQ, _27S_FILE_NO_20205, _31829);
    }
    _31829 = NOVALUE;
    if (IS_ATOM_INT(_31830)) {
        if (_31830 == 0) {
            goto L3; // [54] 186
        }
    }
    else {
        if (DBL_PTR(_31830)->dbl == 0.0) {
            goto L3; // [54] 186
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31832 = (object)*(((s1_ptr)_2)->base + _si2_64703);
    if (IS_SEQUENCE(_31832)){
            _31833 = SEQ_PTR(_31832)->length;
    }
    else {
        _31833 = 1;
    }
    _31832 = NOVALUE;
    if (IS_ATOM_INT(_27S_FILE_NO_20205)) {
        _31834 = (_27S_FILE_NO_20205 <= _31833);
    }
    else {
        _31834 = binary_op(LESSEQ, _27S_FILE_NO_20205, _31833);
    }
    _31833 = NOVALUE;
    if (_31834 == 0) {
        DeRef(_31834);
        _31834 = NOVALUE;
        goto L3; // [74] 186
    }
    else {
        if (!IS_ATOM_INT(_31834) && DBL_PTR(_31834)->dbl == 0.0){
            DeRef(_31834);
            _31834 = NOVALUE;
            goto L3; // [74] 186
        }
        DeRef(_31834);
        _31834 = NOVALUE;
    }
    DeRef(_31834);
    _31834 = NOVALUE;

    /** fwdref.e:953			integer fn1 = SymTab[si1][S_FILE_NO], fn2 = SymTab[si2][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31835 = (object)*(((s1_ptr)_2)->base + _si1_64702);
    _2 = (object)SEQ_PTR(_31835);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _fn1_64724 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _fn1_64724 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    if (!IS_ATOM_INT(_fn1_64724)){
        _fn1_64724 = (object)DBL_PTR(_fn1_64724)->dbl;
    }
    _31835 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31837 = (object)*(((s1_ptr)_2)->base + _si2_64703);
    _2 = (object)SEQ_PTR(_31837);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _fn2_64729 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _fn2_64729 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    if (!IS_ATOM_INT(_fn2_64729)){
        _fn2_64729 = (object)DBL_PTR(_fn2_64729)->dbl;
    }
    _31837 = NOVALUE;

    /** fwdref.e:954			if find(1,{fn1,fn2} > length(known_files) or {fn1,fn2} <= 0) then*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _fn1_64724;
    ((intptr_t *)_2)[2] = _fn2_64729;
    _31839 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_28known_files_11573)){
            _31840 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _31840 = 1;
    }
    _31841 = binary_op(GREATER, _31839, _31840);
    DeRefDS(_31839);
    _31839 = NOVALUE;
    _31840 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _fn1_64724;
    ((intptr_t *)_2)[2] = _fn2_64729;
    _31842 = MAKE_SEQ(_1);
    _31843 = binary_op(LESSEQ, _31842, 0LL);
    DeRefDS(_31842);
    _31842 = NOVALUE;
    _31844 = binary_op(OR, _31841, _31843);
    DeRefDS(_31841);
    _31841 = NOVALUE;
    DeRefDS(_31843);
    _31843 = NOVALUE;
    _31845 = find_from(1LL, _31844, 1LL);
    DeRefDS(_31844);
    _31844 = NOVALUE;
    if (_31845 == 0)
    {
        _31845 = NOVALUE;
        goto L4; // [139] 149
    }
    else{
        _31845 = NOVALUE;
    }

    /** fwdref.e:956				return 1*/
    DeRef(_31824);
    _31824 = NOVALUE;
    _31832 = NOVALUE;
    _31828 = NOVALUE;
    DeRef(_31830);
    _31830 = NOVALUE;
    return 1LL;
L4: 

    /** fwdref.e:958			return compare(abbreviate_path(known_files[fn1]),*/
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _31846 = (object)*(((s1_ptr)_2)->base + _fn1_64724);
    Ref(_31846);
    RefDS(_22218);
    _31847 = _15abbreviate_path(_31846, _22218);
    _31846 = NOVALUE;
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _31848 = (object)*(((s1_ptr)_2)->base + _fn2_64729);
    Ref(_31848);
    RefDS(_22218);
    _31849 = _15abbreviate_path(_31848, _22218);
    _31848 = NOVALUE;
    if (IS_ATOM_INT(_31847) && IS_ATOM_INT(_31849)){
        _31850 = (_31847 < _31849) ? -1 : (_31847 > _31849);
    }
    else{
        _31850 = compare(_31847, _31849);
    }
    DeRef(_31847);
    _31847 = NOVALUE;
    DeRef(_31849);
    _31849 = NOVALUE;
    DeRef(_31824);
    _31824 = NOVALUE;
    _31832 = NOVALUE;
    _31828 = NOVALUE;
    DeRef(_31830);
    _31830 = NOVALUE;
    return _31850;
    goto L5; // [183] 193
L3: 

    /** fwdref.e:961			return 1 -- put non-names last*/
    DeRef(_31824);
    _31824 = NOVALUE;
    _31832 = NOVALUE;
    _31828 = NOVALUE;
    DeRef(_31830);
    _31830 = NOVALUE;
    return 1LL;
L5: 
    ;
}


void _42Resolve_forward_references(object _report_errors_64755)
{
    object _errors_64756 = NOVALUE;
    object _unincluded_ok_64757 = NOVALUE;
    object _msg_64818 = NOVALUE;
    object _errloc_64819 = NOVALUE;
    object _ref_64824 = NOVALUE;
    object _tok_64840 = NOVALUE;
    object _THIS_SCOPE_64842 = NOVALUE;
    object _THESE_GLOBALS_64843 = NOVALUE;
    object _syms_64901 = NOVALUE;
    object _s_64922 = NOVALUE;
    object _31983 = NOVALUE;
    object _31982 = NOVALUE;
    object _31981 = NOVALUE;
    object _31979 = NOVALUE;
    object _31974 = NOVALUE;
    object _31971 = NOVALUE;
    object _31969 = NOVALUE;
    object _31968 = NOVALUE;
    object _31967 = NOVALUE;
    object _31966 = NOVALUE;
    object _31965 = NOVALUE;
    object _31964 = NOVALUE;
    object _31963 = NOVALUE;
    object _31961 = NOVALUE;
    object _31960 = NOVALUE;
    object _31959 = NOVALUE;
    object _31957 = NOVALUE;
    object _31955 = NOVALUE;
    object _31954 = NOVALUE;
    object _31953 = NOVALUE;
    object _31952 = NOVALUE;
    object _31951 = NOVALUE;
    object _31950 = NOVALUE;
    object _31947 = NOVALUE;
    object _31943 = NOVALUE;
    object _31942 = NOVALUE;
    object _31941 = NOVALUE;
    object _31940 = NOVALUE;
    object _31939 = NOVALUE;
    object _31938 = NOVALUE;
    object _31935 = NOVALUE;
    object _31934 = NOVALUE;
    object _31933 = NOVALUE;
    object _31932 = NOVALUE;
    object _31931 = NOVALUE;
    object _31930 = NOVALUE;
    object _31927 = NOVALUE;
    object _31926 = NOVALUE;
    object _31925 = NOVALUE;
    object _31924 = NOVALUE;
    object _31923 = NOVALUE;
    object _31922 = NOVALUE;
    object _31921 = NOVALUE;
    object _31920 = NOVALUE;
    object _31919 = NOVALUE;
    object _31918 = NOVALUE;
    object _31915 = NOVALUE;
    object _31913 = NOVALUE;
    object _31910 = NOVALUE;
    object _31908 = NOVALUE;
    object _31906 = NOVALUE;
    object _31905 = NOVALUE;
    object _31903 = NOVALUE;
    object _31902 = NOVALUE;
    object _31901 = NOVALUE;
    object _31900 = NOVALUE;
    object _31899 = NOVALUE;
    object _31897 = NOVALUE;
    object _31896 = NOVALUE;
    object _31894 = NOVALUE;
    object _31893 = NOVALUE;
    object _31891 = NOVALUE;
    object _31890 = NOVALUE;
    object _31888 = NOVALUE;
    object _31887 = NOVALUE;
    object _31886 = NOVALUE;
    object _31885 = NOVALUE;
    object _31884 = NOVALUE;
    object _31883 = NOVALUE;
    object _31882 = NOVALUE;
    object _31881 = NOVALUE;
    object _31880 = NOVALUE;
    object _31879 = NOVALUE;
    object _31878 = NOVALUE;
    object _31877 = NOVALUE;
    object _31876 = NOVALUE;
    object _31875 = NOVALUE;
    object _31874 = NOVALUE;
    object _31873 = NOVALUE;
    object _31871 = NOVALUE;
    object _31870 = NOVALUE;
    object _31869 = NOVALUE;
    object _31868 = NOVALUE;
    object _31866 = NOVALUE;
    object _31865 = NOVALUE;
    object _31863 = NOVALUE;
    object _31862 = NOVALUE;
    object _31861 = NOVALUE;
    object _31860 = NOVALUE;
    object _31858 = NOVALUE;
    object _31857 = NOVALUE;
    object _31856 = NOVALUE;
    object _31855 = NOVALUE;
    object _31853 = NOVALUE;
    object _31852 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:966		sequence errors = {}*/
    RefDS(_22218);
    DeRef(_errors_64756);
    _errors_64756 = _22218;

    /** fwdref.e:967		integer unincluded_ok = get_resolve_unincluded_globals()*/
    _unincluded_ok_64757 = _53get_resolve_unincluded_globals();
    if (!IS_ATOM_INT(_unincluded_ok_64757)) {
        _1 = (object)(DBL_PTR(_unincluded_ok_64757)->dbl);
        DeRefDS(_unincluded_ok_64757);
        _unincluded_ok_64757 = _1;
    }

    /** fwdref.e:969		if length( active_references ) < length( known_files ) then*/
    if (IS_SEQUENCE(_42active_references_63319)){
            _31852 = SEQ_PTR(_42active_references_63319)->length;
    }
    else {
        _31852 = 1;
    }
    if (IS_SEQUENCE(_28known_files_11573)){
            _31853 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _31853 = 1;
    }
    if (_31852 >= _31853)
    goto L1; // [29] 86

    /** fwdref.e:970			active_references &= repeat( {}, length( known_files ) - length( active_references ) )*/
    if (IS_SEQUENCE(_28known_files_11573)){
            _31855 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _31855 = 1;
    }
    if (IS_SEQUENCE(_42active_references_63319)){
            _31856 = SEQ_PTR(_42active_references_63319)->length;
    }
    else {
        _31856 = 1;
    }
    _31857 = _31855 - _31856;
    _31855 = NOVALUE;
    _31856 = NOVALUE;
    _31858 = Repeat(_22218, _31857);
    _31857 = NOVALUE;
    Concat((object_ptr)&_42active_references_63319, _42active_references_63319, _31858);
    DeRefDS(_31858);
    _31858 = NOVALUE;

    /** fwdref.e:971			active_subprogs   &= repeat( {}, length( known_files ) - length( active_subprogs ) )*/
    if (IS_SEQUENCE(_28known_files_11573)){
            _31860 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _31860 = 1;
    }
    if (IS_SEQUENCE(_42active_subprogs_63318)){
            _31861 = SEQ_PTR(_42active_subprogs_63318)->length;
    }
    else {
        _31861 = 1;
    }
    _31862 = _31860 - _31861;
    _31860 = NOVALUE;
    _31861 = NOVALUE;
    _31863 = Repeat(_22218, _31862);
    _31862 = NOVALUE;
    Concat((object_ptr)&_42active_subprogs_63318, _42active_subprogs_63318, _31863);
    DeRefDS(_31863);
    _31863 = NOVALUE;
L1: 

    /** fwdref.e:974		if length( toplevel_references ) < length( known_files ) then*/
    if (IS_SEQUENCE(_42toplevel_references_63320)){
            _31865 = SEQ_PTR(_42toplevel_references_63320)->length;
    }
    else {
        _31865 = 1;
    }
    if (IS_SEQUENCE(_28known_files_11573)){
            _31866 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _31866 = 1;
    }
    if (_31865 >= _31866)
    goto L2; // [98] 129

    /** fwdref.e:975			toplevel_references &= repeat( {}, length( known_files ) - length( toplevel_references ) )*/
    if (IS_SEQUENCE(_28known_files_11573)){
            _31868 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _31868 = 1;
    }
    if (IS_SEQUENCE(_42toplevel_references_63320)){
            _31869 = SEQ_PTR(_42toplevel_references_63320)->length;
    }
    else {
        _31869 = 1;
    }
    _31870 = _31868 - _31869;
    _31868 = NOVALUE;
    _31869 = NOVALUE;
    _31871 = Repeat(_22218, _31870);
    _31870 = NOVALUE;
    Concat((object_ptr)&_42toplevel_references_63320, _42toplevel_references_63320, _31871);
    DeRefDS(_31871);
    _31871 = NOVALUE;
L2: 

    /** fwdref.e:978		for i = 1 to length( active_subprogs ) do*/
    if (IS_SEQUENCE(_42active_subprogs_63318)){
            _31873 = SEQ_PTR(_42active_subprogs_63318)->length;
    }
    else {
        _31873 = 1;
    }
    {
        object _i_64789;
        _i_64789 = 1LL;
L3: 
        if (_i_64789 > _31873){
            goto L4; // [136] 280
        }

        /** fwdref.e:979			if (length( active_subprogs[i] ) or length(toplevel_references[i])) */
        _2 = (object)SEQ_PTR(_42active_subprogs_63318);
        _31874 = (object)*(((s1_ptr)_2)->base + _i_64789);
        if (IS_SEQUENCE(_31874)){
                _31875 = SEQ_PTR(_31874)->length;
        }
        else {
            _31875 = 1;
        }
        _31874 = NOVALUE;
        if (_31875 != 0) {
            _31876 = 1;
            goto L5; // [154] 171
        }
        _2 = (object)SEQ_PTR(_42toplevel_references_63320);
        _31877 = (object)*(((s1_ptr)_2)->base + _i_64789);
        if (IS_SEQUENCE(_31877)){
                _31878 = SEQ_PTR(_31877)->length;
        }
        else {
            _31878 = 1;
        }
        _31877 = NOVALUE;
        _31876 = (_31878 != 0);
L5: 
        if (_31876 == 0) {
            goto L6; // [171] 273
        }
        _31880 = (_i_64789 == _27current_file_no_20571);
        if (_31880 != 0) {
            _31881 = 1;
            goto L7; // [181] 195
        }
        _2 = (object)SEQ_PTR(_28finished_files_11575);
        _31882 = (object)*(((s1_ptr)_2)->base + _i_64789);
        _31881 = (_31882 != 0);
L7: 
        if (_31881 != 0) {
            DeRef(_31883);
            _31883 = 1;
            goto L8; // [195] 203
        }
        _31883 = (_unincluded_ok_64757 != 0);
L8: 
        if (_31883 == 0)
        {
            _31883 = NOVALUE;
            goto L6; // [204] 273
        }
        else{
            _31883 = NOVALUE;
        }

        /** fwdref.e:982				for j = length( active_references[i] ) to 1 by -1 do*/
        _2 = (object)SEQ_PTR(_42active_references_63319);
        _31884 = (object)*(((s1_ptr)_2)->base + _i_64789);
        if (IS_SEQUENCE(_31884)){
                _31885 = SEQ_PTR(_31884)->length;
        }
        else {
            _31885 = 1;
        }
        _31884 = NOVALUE;
        {
            object _j_64805;
            _j_64805 = _31885;
L9: 
            if (_j_64805 < 1LL){
                goto LA; // [218] 254
            }

            /** fwdref.e:983					errors &= resolve_file( active_references[i][j], report_errors, unincluded_ok )*/
            _2 = (object)SEQ_PTR(_42active_references_63319);
            _31886 = (object)*(((s1_ptr)_2)->base + _i_64789);
            _2 = (object)SEQ_PTR(_31886);
            _31887 = (object)*(((s1_ptr)_2)->base + _j_64805);
            _31886 = NOVALUE;
            Ref(_31887);
            _31888 = _42resolve_file(_31887, _report_errors_64755, _unincluded_ok_64757);
            _31887 = NOVALUE;
            if (IS_SEQUENCE(_errors_64756) && IS_ATOM(_31888)) {
                Ref(_31888);
                Append(&_errors_64756, _errors_64756, _31888);
            }
            else if (IS_ATOM(_errors_64756) && IS_SEQUENCE(_31888)) {
            }
            else {
                Concat((object_ptr)&_errors_64756, _errors_64756, _31888);
            }
            DeRef(_31888);
            _31888 = NOVALUE;

            /** fwdref.e:984				end for*/
            _j_64805 = _j_64805 + -1LL;
            goto L9; // [249] 225
LA: 
            ;
        }

        /** fwdref.e:985				errors &= resolve_file( toplevel_references[i], report_errors, unincluded_ok )*/
        _2 = (object)SEQ_PTR(_42toplevel_references_63320);
        _31890 = (object)*(((s1_ptr)_2)->base + _i_64789);
        Ref(_31890);
        _31891 = _42resolve_file(_31890, _report_errors_64755, _unincluded_ok_64757);
        _31890 = NOVALUE;
        if (IS_SEQUENCE(_errors_64756) && IS_ATOM(_31891)) {
            Ref(_31891);
            Append(&_errors_64756, _errors_64756, _31891);
        }
        else if (IS_ATOM(_errors_64756) && IS_SEQUENCE(_31891)) {
        }
        else {
            Concat((object_ptr)&_errors_64756, _errors_64756, _31891);
        }
        DeRef(_31891);
        _31891 = NOVALUE;
L6: 

        /** fwdref.e:987		end for*/
        _i_64789 = _i_64789 + 1LL;
        goto L3; // [275] 143
L4: 
        ;
    }

    /** fwdref.e:989		if report_errors and length( errors ) then*/
    if (_report_errors_64755 == 0) {
        goto LB; // [282] 856
    }
    if (IS_SEQUENCE(_errors_64756)){
            _31894 = SEQ_PTR(_errors_64756)->length;
    }
    else {
        _31894 = 1;
    }
    if (_31894 == 0)
    {
        _31894 = NOVALUE;
        goto LB; // [290] 856
    }
    else{
        _31894 = NOVALUE;
    }

    /** fwdref.e:990			sequence msg = ""*/
    RefDS(_22218);
    DeRefi(_msg_64818);
    _msg_64818 = _22218;

    /** fwdref.e:991			sequence errloc = "Internal Error - Unknown Error Message"*/
    RefDS(_31895);
    DeRefi(_errloc_64819);
    _errloc_64819 = _31895;

    /** fwdref.e:993			for e = length(errors) to 1 by -1 do*/
    if (IS_SEQUENCE(_errors_64756)){
            _31896 = SEQ_PTR(_errors_64756)->length;
    }
    else {
        _31896 = 1;
    }
    {
        object _e_64822;
        _e_64822 = _31896;
LC: 
        if (_e_64822 < 1LL){
            goto LD; // [312] 828
        }

        /** fwdref.e:994				sequence ref = forward_references[errors[e]]*/
        _2 = (object)SEQ_PTR(_errors_64756);
        _31897 = (object)*(((s1_ptr)_2)->base + _e_64822);
        DeRef(_ref_64824);
        _2 = (object)SEQ_PTR(_42forward_references_63317);
        if (!IS_ATOM_INT(_31897)){
            _ref_64824 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31897)->dbl));
        }
        else{
            _ref_64824 = (object)*(((s1_ptr)_2)->base + _31897);
        }
        Ref(_ref_64824);

        /** fwdref.e:995				if (ref[FR_TYPE] = TYPE_CHECK and ref[FR_OP] = TYPE_CHECK) or ref[FR_TYPE] = GLOBAL_INIT_CHECK then*/
        _2 = (object)SEQ_PTR(_ref_64824);
        _31899 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_31899)) {
            _31900 = (_31899 == 65LL);
        }
        else {
            _31900 = binary_op(EQUALS, _31899, 65LL);
        }
        _31899 = NOVALUE;
        if (IS_ATOM_INT(_31900)) {
            if (_31900 == 0) {
                DeRef(_31901);
                _31901 = 0;
                goto LE; // [345] 363
            }
        }
        else {
            if (DBL_PTR(_31900)->dbl == 0.0) {
                DeRef(_31901);
                _31901 = 0;
                goto LE; // [345] 363
            }
        }
        _2 = (object)SEQ_PTR(_ref_64824);
        _31902 = (object)*(((s1_ptr)_2)->base + 10LL);
        if (IS_ATOM_INT(_31902)) {
            _31903 = (_31902 == 65LL);
        }
        else {
            _31903 = binary_op(EQUALS, _31902, 65LL);
        }
        _31902 = NOVALUE;
        DeRef(_31901);
        if (IS_ATOM_INT(_31903))
        _31901 = (_31903 != 0);
        else
        _31901 = DBL_PTR(_31903)->dbl != 0.0;
LE: 
        if (_31901 != 0) {
            goto LF; // [363] 382
        }
        _2 = (object)SEQ_PTR(_ref_64824);
        _31905 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_31905)) {
            _31906 = (_31905 == 109LL);
        }
        else {
            _31906 = binary_op(EQUALS, _31905, 109LL);
        }
        _31905 = NOVALUE;
        if (_31906 == 0) {
            DeRef(_31906);
            _31906 = NOVALUE;
            goto L10; // [378] 391
        }
        else {
            if (!IS_ATOM_INT(_31906) && DBL_PTR(_31906)->dbl == 0.0){
                DeRef(_31906);
                _31906 = NOVALUE;
                goto L10; // [378] 391
            }
            DeRef(_31906);
            _31906 = NOVALUE;
        }
        DeRef(_31906);
        _31906 = NOVALUE;
LF: 

        /** fwdref.e:997					continue*/
        DeRef(_ref_64824);
        _ref_64824 = NOVALUE;
        goto L11; // [386] 823
        goto L12; // [388] 789
L10: 

        /** fwdref.e:1001					object tok = find_reference(ref)*/
        RefDS(_ref_64824);
        _0 = _tok_64840;
        _tok_64840 = _42find_reference(_ref_64824);
        DeRef(_0);

        /** fwdref.e:1002					integer THIS_SCOPE = 3*/
        _THIS_SCOPE_64842 = 3LL;

        /** fwdref.e:1003					integer THESE_GLOBALS = 4*/
        _THESE_GLOBALS_64843 = 4LL;

        /** fwdref.e:1004					if tok[T_ID] = IGNORED then*/
        _2 = (object)SEQ_PTR(_tok_64840);
        _31908 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _31908, 509LL)){
            _31908 = NOVALUE;
            goto L13; // [417] 760
        }
        _31908 = NOVALUE;

        /** fwdref.e:1006						switch tok[THIS_SCOPE] do*/
        _2 = (object)SEQ_PTR(_tok_64840);
        _31910 = (object)*(((s1_ptr)_2)->base + 3LL);
        if (IS_SEQUENCE(_31910) ){
            goto L14; // [427] 756
        }
        if(!IS_ATOM_INT(_31910)){
            if( (DBL_PTR(_31910)->dbl != (eudouble) ((object) DBL_PTR(_31910)->dbl) ) ){
                goto L14; // [427] 756
            }
            _0 = (object) DBL_PTR(_31910)->dbl;
        }
        else {
            _0 = _31910;
        };
        _31910 = NOVALUE;
        switch ( _0 ){ 

            /** fwdref.e:1007							case SC_UNDEFINED then*/
            case 9:

            /** fwdref.e:1008								if ref[FR_QUALIFIED] != -1 then*/
            _2 = (object)SEQ_PTR(_ref_64824);
            _31913 = (object)*(((s1_ptr)_2)->base + 9LL);
            if (binary_op_a(EQUALS, _31913, -1LL)){
                _31913 = NOVALUE;
                goto L15; // [442] 556
            }
            _31913 = NOVALUE;

            /** fwdref.e:1009									if ref[FR_QUALIFIED] > 0 then*/
            _2 = (object)SEQ_PTR(_ref_64824);
            _31915 = (object)*(((s1_ptr)_2)->base + 9LL);
            if (binary_op_a(LESSEQ, _31915, 0LL)){
                _31915 = NOVALUE;
                goto L16; // [452] 517
            }
            _31915 = NOVALUE;

            /** fwdref.e:1011										errloc = sprintf("\t\'%s\' (%s:%d) was not declared in \'%s\'.\n", */
            _2 = (object)SEQ_PTR(_ref_64824);
            _31918 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_ref_64824);
            _31919 = (object)*(((s1_ptr)_2)->base + 3LL);
            _2 = (object)SEQ_PTR(_28known_files_11573);
            if (!IS_ATOM_INT(_31919)){
                _31920 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31919)->dbl));
            }
            else{
                _31920 = (object)*(((s1_ptr)_2)->base + _31919);
            }
            Ref(_31920);
            RefDS(_22218);
            _31921 = _15abbreviate_path(_31920, _22218);
            _31920 = NOVALUE;
            _2 = (object)SEQ_PTR(_ref_64824);
            _31922 = (object)*(((s1_ptr)_2)->base + 6LL);
            _2 = (object)SEQ_PTR(_ref_64824);
            _31923 = (object)*(((s1_ptr)_2)->base + 9LL);
            _2 = (object)SEQ_PTR(_28known_files_11573);
            if (!IS_ATOM_INT(_31923)){
                _31924 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31923)->dbl));
            }
            else{
                _31924 = (object)*(((s1_ptr)_2)->base + _31923);
            }
            Ref(_31924);
            RefDS(_22218);
            _31925 = _15abbreviate_path(_31924, _22218);
            _31924 = NOVALUE;
            _31926 = _14find_replace(92LL, _31925, 47LL, 0LL);
            _31925 = NOVALUE;
            _1 = NewS1(4);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_31918);
            ((intptr_t*)_2)[1] = _31918;
            ((intptr_t*)_2)[2] = _31921;
            Ref(_31922);
            ((intptr_t*)_2)[3] = _31922;
            ((intptr_t*)_2)[4] = _31926;
            _31927 = MAKE_SEQ(_1);
            _31926 = NOVALUE;
            _31922 = NOVALUE;
            _31921 = NOVALUE;
            _31918 = NOVALUE;
            DeRefi(_errloc_64819);
            _errloc_64819 = EPrintf(-9999999, _31917, _31927);
            DeRefDS(_31927);
            _31927 = NOVALUE;
            goto L17; // [514] 759
L16: 

            /** fwdref.e:1016										errloc = sprintf("\t\'%s\' (%s:%d) is not a builtin.\n", */
            _2 = (object)SEQ_PTR(_ref_64824);
            _31930 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_ref_64824);
            _31931 = (object)*(((s1_ptr)_2)->base + 3LL);
            _2 = (object)SEQ_PTR(_28known_files_11573);
            if (!IS_ATOM_INT(_31931)){
                _31932 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31931)->dbl));
            }
            else{
                _31932 = (object)*(((s1_ptr)_2)->base + _31931);
            }
            Ref(_31932);
            RefDS(_22218);
            _31933 = _15abbreviate_path(_31932, _22218);
            _31932 = NOVALUE;
            _2 = (object)SEQ_PTR(_ref_64824);
            _31934 = (object)*(((s1_ptr)_2)->base + 6LL);
            _1 = NewS1(3);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_31930);
            ((intptr_t*)_2)[1] = _31930;
            ((intptr_t*)_2)[2] = _31933;
            Ref(_31934);
            ((intptr_t*)_2)[3] = _31934;
            _31935 = MAKE_SEQ(_1);
            _31934 = NOVALUE;
            _31933 = NOVALUE;
            _31930 = NOVALUE;
            DeRefi(_errloc_64819);
            _errloc_64819 = EPrintf(-9999999, _31929, _31935);
            DeRefDS(_31935);
            _31935 = NOVALUE;
            goto L17; // [553] 759
L15: 

            /** fwdref.e:1021									errloc = sprintf("\t\'%s\' (%s:%d) has not been declared.\n", */
            _2 = (object)SEQ_PTR(_ref_64824);
            _31938 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_ref_64824);
            _31939 = (object)*(((s1_ptr)_2)->base + 3LL);
            _2 = (object)SEQ_PTR(_28known_files_11573);
            if (!IS_ATOM_INT(_31939)){
                _31940 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31939)->dbl));
            }
            else{
                _31940 = (object)*(((s1_ptr)_2)->base + _31939);
            }
            Ref(_31940);
            RefDS(_22218);
            _31941 = _15abbreviate_path(_31940, _22218);
            _31940 = NOVALUE;
            _2 = (object)SEQ_PTR(_ref_64824);
            _31942 = (object)*(((s1_ptr)_2)->base + 6LL);
            _1 = NewS1(3);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_31938);
            ((intptr_t*)_2)[1] = _31938;
            ((intptr_t*)_2)[2] = _31941;
            Ref(_31942);
            ((intptr_t*)_2)[3] = _31942;
            _31943 = MAKE_SEQ(_1);
            _31942 = NOVALUE;
            _31941 = NOVALUE;
            _31938 = NOVALUE;
            DeRefi(_errloc_64819);
            _errloc_64819 = EPrintf(-9999999, _31937, _31943);
            DeRefDS(_31943);
            _31943 = NOVALUE;
            goto L17; // [592] 759

            /** fwdref.e:1024							case SC_MULTIPLY_DEFINED then*/
            case 10:

            /** fwdref.e:1025								sequence syms = tok[THESE_GLOBALS] -- there should be no forward references in here.*/
            DeRef(_syms_64901);
            _2 = (object)SEQ_PTR(_tok_64840);
            _syms_64901 = (object)*(((s1_ptr)_2)->base + _THESE_GLOBALS_64843);
            Ref(_syms_64901);

            /** fwdref.e:1026								syms = custom_sort(routine_id("file_name_based_symindex_compare"), syms,, ASCENDING)*/
            _31947 = CRoutineId(1385, 42, _31946);
            RefDS(_syms_64901);
            RefDS(_22218);
            _0 = _syms_64901;
            _syms_64901 = _25custom_sort(_31947, _syms_64901, _22218, 1LL);
            DeRefDS(_0);
            _31947 = NOVALUE;

            /** fwdref.e:1027								errloc = sprintf("\t\'%s\' (%s:%d) has been declared more than once.\n", */
            _2 = (object)SEQ_PTR(_ref_64824);
            _31950 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_ref_64824);
            _31951 = (object)*(((s1_ptr)_2)->base + 3LL);
            _2 = (object)SEQ_PTR(_28known_files_11573);
            if (!IS_ATOM_INT(_31951)){
                _31952 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31951)->dbl));
            }
            else{
                _31952 = (object)*(((s1_ptr)_2)->base + _31951);
            }
            Ref(_31952);
            RefDS(_22218);
            _31953 = _15abbreviate_path(_31952, _22218);
            _31952 = NOVALUE;
            _2 = (object)SEQ_PTR(_ref_64824);
            _31954 = (object)*(((s1_ptr)_2)->base + 6LL);
            _1 = NewS1(3);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_31950);
            ((intptr_t*)_2)[1] = _31950;
            ((intptr_t*)_2)[2] = _31953;
            Ref(_31954);
            ((intptr_t*)_2)[3] = _31954;
            _31955 = MAKE_SEQ(_1);
            _31954 = NOVALUE;
            _31953 = NOVALUE;
            _31950 = NOVALUE;
            DeRefi(_errloc_64819);
            _errloc_64819 = EPrintf(-9999999, _31949, _31955);
            DeRefDS(_31955);
            _31955 = NOVALUE;

            /** fwdref.e:1029								for si = 1 to length(syms) do*/
            if (IS_SEQUENCE(_syms_64901)){
                    _31957 = SEQ_PTR(_syms_64901)->length;
            }
            else {
                _31957 = 1;
            }
            {
                object _si_64919;
                _si_64919 = 1LL;
L18: 
                if (_si_64919 > _31957){
                    goto L19; // [664] 750
                }

                /** fwdref.e:1030									symtab_index s = syms[si] */
                _2 = (object)SEQ_PTR(_syms_64901);
                _s_64922 = (object)*(((s1_ptr)_2)->base + _si_64919);
                if (!IS_ATOM_INT(_s_64922)){
                    _s_64922 = (object)DBL_PTR(_s_64922)->dbl;
                }

                /** fwdref.e:1031									if equal(ref[FR_NAME], sym_name(s)) then*/
                _2 = (object)SEQ_PTR(_ref_64824);
                _31959 = (object)*(((s1_ptr)_2)->base + 2LL);
                _31960 = _53sym_name(_s_64922);
                if (_31959 == _31960)
                _31961 = 1;
                else if (IS_ATOM_INT(_31959) && IS_ATOM_INT(_31960))
                _31961 = 0;
                else
                _31961 = (compare(_31959, _31960) == 0);
                _31959 = NOVALUE;
                DeRef(_31960);
                _31960 = NOVALUE;
                if (_31961 == 0)
                {
                    _31961 = NOVALUE;
                    goto L1A; // [693] 741
                }
                else{
                    _31961 = NOVALUE;
                }

                /** fwdref.e:1032										errloc &= sprintf("\t\tin %s\n", */
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _31963 = (object)*(((s1_ptr)_2)->base + _s_64922);
                _2 = (object)SEQ_PTR(_31963);
                if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
                    _31964 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
                }
                else{
                    _31964 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
                }
                _31963 = NOVALUE;
                _2 = (object)SEQ_PTR(_28known_files_11573);
                if (!IS_ATOM_INT(_31964)){
                    _31965 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31964)->dbl));
                }
                else{
                    _31965 = (object)*(((s1_ptr)_2)->base + _31964);
                }
                Ref(_31965);
                RefDS(_22218);
                _31966 = _15abbreviate_path(_31965, _22218);
                _31965 = NOVALUE;
                _31967 = _14find_replace(92LL, _31966, 47LL, 0LL);
                _31966 = NOVALUE;
                _1 = NewS1(1);
                _2 = (object)((s1_ptr)_1)->base;
                ((intptr_t*)_2)[1] = _31967;
                _31968 = MAKE_SEQ(_1);
                _31967 = NOVALUE;
                _31969 = EPrintf(-9999999, _31962, _31968);
                DeRefDS(_31968);
                _31968 = NOVALUE;
                Concat((object_ptr)&_errloc_64819, _errloc_64819, _31969);
                DeRefDS(_31969);
                _31969 = NOVALUE;
L1A: 

                /** fwdref.e:1035								end for*/
                _si_64919 = _si_64919 + 1LL;
                goto L18; // [745] 671
L19: 
                ;
            }
            DeRef(_syms_64901);
            _syms_64901 = NOVALUE;
            goto L17; // [752] 759

            /** fwdref.e:1036							case else */
            default:
L14: 
        ;}L17: 
L13: 

        /** fwdref.e:1040					if not match(errloc, msg) then*/
        _31971 = e_match_from(_errloc_64819, _msg_64818, 1LL);
        if (_31971 != 0)
        goto L1B; // [767] 786
        _31971 = NOVALUE;

        /** fwdref.e:1041						msg &= errloc*/
        Concat((object_ptr)&_msg_64818, _msg_64818, _errloc_64819);

        /** fwdref.e:1042						prep_forward_error( errors[e] )*/
        _2 = (object)SEQ_PTR(_errors_64756);
        _31974 = (object)*(((s1_ptr)_2)->base + _e_64822);
        Ref(_31974);
        _42prep_forward_error(_31974);
        _31974 = NOVALUE;
L1B: 
        DeRef(_tok_64840);
        _tok_64840 = NOVALUE;
L12: 

        /** fwdref.e:1045				ThisLine    = ref[FR_THISLINE]*/
        DeRef(_49ThisLine_49693);
        _2 = (object)SEQ_PTR(_ref_64824);
        _49ThisLine_49693 = (object)*(((s1_ptr)_2)->base + 7LL);
        Ref(_49ThisLine_49693);

        /** fwdref.e:1046				bp          = ref[FR_BP]*/
        _2 = (object)SEQ_PTR(_ref_64824);
        _49bp_49697 = (object)*(((s1_ptr)_2)->base + 8LL);
        if (!IS_ATOM_INT(_49bp_49697)){
            _49bp_49697 = (object)DBL_PTR(_49bp_49697)->dbl;
        }

        /** fwdref.e:1047				CurrentSub  = ref[FR_SUBPROG]*/
        _2 = (object)SEQ_PTR(_ref_64824);
        _27CurrentSub_20579 = (object)*(((s1_ptr)_2)->base + 4LL);
        if (!IS_ATOM_INT(_27CurrentSub_20579)){
            _27CurrentSub_20579 = (object)DBL_PTR(_27CurrentSub_20579)->dbl;
        }

        /** fwdref.e:1048				line_number = ref[FR_LINE]*/
        _2 = (object)SEQ_PTR(_ref_64824);
        _27line_number_20572 = (object)*(((s1_ptr)_2)->base + 6LL);
        if (!IS_ATOM_INT(_27line_number_20572)){
            _27line_number_20572 = (object)DBL_PTR(_27line_number_20572)->dbl;
        }
        DeRefDS(_ref_64824);
        _ref_64824 = NOVALUE;

        /** fwdref.e:1049			end for*/
L11: 
        _e_64822 = _e_64822 + -1LL;
        goto LC; // [823] 319
LD: 
        ;
    }

    /** fwdref.e:1050			if length(msg) > 0 then*/
    if (IS_SEQUENCE(_msg_64818)){
            _31979 = SEQ_PTR(_msg_64818)->length;
    }
    else {
        _31979 = 1;
    }
    if (_31979 <= 0LL)
    goto L1C; // [833] 851

    /** fwdref.e:1051				CompileErr( ERRORS_RESOLVING_THE_FOLLOWING_REFERENCES1, {msg} )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_msg_64818);
    ((intptr_t*)_2)[1] = _msg_64818;
    _31981 = MAKE_SEQ(_1);
    _49CompileErr(74LL, _31981, 0LL);
    _31981 = NOVALUE;
L1C: 
    DeRefi(_msg_64818);
    _msg_64818 = NOVALUE;
    DeRefi(_errloc_64819);
    _errloc_64819 = NOVALUE;
    goto L1D; // [853] 901
LB: 

    /** fwdref.e:1053		elsif report_errors and not repl then*/
    if (_report_errors_64755 == 0) {
        goto L1E; // [858] 900
    }
    _31983 = (0LL == 0);
    if (_31983 == 0)
    {
        DeRef(_31983);
        _31983 = NOVALUE;
        goto L1E; // [868] 900
    }
    else{
        DeRef(_31983);
        _31983 = NOVALUE;
    }

    /** fwdref.e:1055			forward_references  = {}*/
    RefDS(_22218);
    DeRef(_42forward_references_63317);
    _42forward_references_63317 = _22218;

    /** fwdref.e:1056			active_references   = {}*/
    RefDS(_22218);
    DeRef(_42active_references_63319);
    _42active_references_63319 = _22218;

    /** fwdref.e:1057			toplevel_references = {}*/
    RefDS(_22218);
    DeRef(_42toplevel_references_63320);
    _42toplevel_references_63320 = _22218;

    /** fwdref.e:1058			inactive_references = {}*/
    RefDS(_22218);
    DeRef(_42inactive_references_63321);
    _42inactive_references_63321 = _22218;
L1E: 
L1D: 

    /** fwdref.e:1060		clear_last()*/
    _45clear_last();

    /** fwdref.e:1061	end procedure*/
    DeRef(_errors_64756);
    _31919 = NOVALUE;
    _31923 = NOVALUE;
    DeRef(_31900);
    _31900 = NOVALUE;
    _31964 = NOVALUE;
    _31884 = NOVALUE;
    _31874 = NOVALUE;
    _31877 = NOVALUE;
    _31897 = NOVALUE;
    _31939 = NOVALUE;
    DeRef(_31903);
    _31903 = NOVALUE;
    _31951 = NOVALUE;
    _31931 = NOVALUE;
    DeRef(_31880);
    _31880 = NOVALUE;
    _31882 = NOVALUE;
    return;
    ;
}


void _42shift_these(object _refs_64970, object _pc_64971, object _amount_64972)
{
    object _fr_64976 = NOVALUE;
    object _32001 = NOVALUE;
    object _32000 = NOVALUE;
    object _31999 = NOVALUE;
    object _31998 = NOVALUE;
    object _31997 = NOVALUE;
    object _31996 = NOVALUE;
    object _31995 = NOVALUE;
    object _31994 = NOVALUE;
    object _31993 = NOVALUE;
    object _31992 = NOVALUE;
    object _31990 = NOVALUE;
    object _31988 = NOVALUE;
    object _31987 = NOVALUE;
    object _31985 = NOVALUE;
    object _31984 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:1064		for i = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_64970)){
            _31984 = SEQ_PTR(_refs_64970)->length;
    }
    else {
        _31984 = 1;
    }
    {
        object _i_64974;
        _i_64974 = _31984;
L1: 
        if (_i_64974 < 1LL){
            goto L2; // [12] 147
        }

        /** fwdref.e:1065			sequence fr = forward_references[refs[i]]*/
        _2 = (object)SEQ_PTR(_refs_64970);
        _31985 = (object)*(((s1_ptr)_2)->base + _i_64974);
        DeRef(_fr_64976);
        _2 = (object)SEQ_PTR(_42forward_references_63317);
        if (!IS_ATOM_INT(_31985)){
            _fr_64976 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31985)->dbl));
        }
        else{
            _fr_64976 = (object)*(((s1_ptr)_2)->base + _31985);
        }
        Ref(_fr_64976);

        /** fwdref.e:1066			forward_references[refs[i]] = 0*/
        _2 = (object)SEQ_PTR(_refs_64970);
        _31987 = (object)*(((s1_ptr)_2)->base + _i_64974);
        _2 = (object)SEQ_PTR(_42forward_references_63317);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _42forward_references_63317 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31987))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31987)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _31987);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0LL;
        DeRef(_1);

        /** fwdref.e:1067			if fr[FR_SUBPROG] = shifting_sub then*/
        _2 = (object)SEQ_PTR(_fr_64976);
        _31988 = (object)*(((s1_ptr)_2)->base + 4LL);
        if (binary_op_a(NOTEQ, _31988, _42shifting_sub_63336)){
            _31988 = NOVALUE;
            goto L3; // [53] 126
        }
        _31988 = NOVALUE;

        /** fwdref.e:1068				if fr[FR_PC] >= pc then*/
        _2 = (object)SEQ_PTR(_fr_64976);
        _31990 = (object)*(((s1_ptr)_2)->base + 5LL);
        if (binary_op_a(LESS, _31990, _pc_64971)){
            _31990 = NOVALUE;
            goto L4; // [63] 125
        }
        _31990 = NOVALUE;

        /** fwdref.e:1069					fr[FR_PC] += amount*/
        _2 = (object)SEQ_PTR(_fr_64976);
        _31992 = (object)*(((s1_ptr)_2)->base + 5LL);
        if (IS_ATOM_INT(_31992)) {
            _31993 = _31992 + _amount_64972;
            if ((object)((uintptr_t)_31993 + (uintptr_t)HIGH_BITS) >= 0){
                _31993 = NewDouble((eudouble)_31993);
            }
        }
        else {
            _31993 = binary_op(PLUS, _31992, _amount_64972);
        }
        _31992 = NOVALUE;
        _2 = (object)SEQ_PTR(_fr_64976);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _fr_64976 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31993;
        if( _1 != _31993 ){
            DeRef(_1);
        }
        _31993 = NOVALUE;

        /** fwdref.e:1070					if fr[FR_TYPE] = CASE*/
        _2 = (object)SEQ_PTR(_fr_64976);
        _31994 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_31994)) {
            _31995 = (_31994 == 186LL);
        }
        else {
            _31995 = binary_op(EQUALS, _31994, 186LL);
        }
        _31994 = NOVALUE;
        if (IS_ATOM_INT(_31995)) {
            if (_31995 == 0) {
                goto L5; // [93] 124
            }
        }
        else {
            if (DBL_PTR(_31995)->dbl == 0.0) {
                goto L5; // [93] 124
            }
        }
        _2 = (object)SEQ_PTR(_fr_64976);
        _31997 = (object)*(((s1_ptr)_2)->base + 12LL);
        if (IS_ATOM_INT(_31997)) {
            _31998 = (_31997 >= _pc_64971);
        }
        else {
            _31998 = binary_op(GREATEREQ, _31997, _pc_64971);
        }
        _31997 = NOVALUE;
        if (_31998 == 0) {
            DeRef(_31998);
            _31998 = NOVALUE;
            goto L5; // [106] 124
        }
        else {
            if (!IS_ATOM_INT(_31998) && DBL_PTR(_31998)->dbl == 0.0){
                DeRef(_31998);
                _31998 = NOVALUE;
                goto L5; // [106] 124
            }
            DeRef(_31998);
            _31998 = NOVALUE;
        }
        DeRef(_31998);
        _31998 = NOVALUE;

        /** fwdref.e:1073						fr[FR_DATA] += amount*/
        _2 = (object)SEQ_PTR(_fr_64976);
        _31999 = (object)*(((s1_ptr)_2)->base + 12LL);
        if (IS_ATOM_INT(_31999)) {
            _32000 = _31999 + _amount_64972;
            if ((object)((uintptr_t)_32000 + (uintptr_t)HIGH_BITS) >= 0){
                _32000 = NewDouble((eudouble)_32000);
            }
        }
        else {
            _32000 = binary_op(PLUS, _31999, _amount_64972);
        }
        _31999 = NOVALUE;
        _2 = (object)SEQ_PTR(_fr_64976);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _fr_64976 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 12LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _32000;
        if( _1 != _32000 ){
            DeRef(_1);
        }
        _32000 = NOVALUE;
L5: 
L4: 
L3: 

        /** fwdref.e:1077			forward_references[refs[i]] = fr*/
        _2 = (object)SEQ_PTR(_refs_64970);
        _32001 = (object)*(((s1_ptr)_2)->base + _i_64974);
        RefDS(_fr_64976);
        _2 = (object)SEQ_PTR(_42forward_references_63317);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _42forward_references_63317 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_32001))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_32001)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _32001);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _fr_64976;
        DeRef(_1);
        DeRefDS(_fr_64976);
        _fr_64976 = NOVALUE;

        /** fwdref.e:1078		end for*/
        _i_64974 = _i_64974 + -1LL;
        goto L1; // [142] 19
L2: 
        ;
    }

    /** fwdref.e:1079	end procedure*/
    DeRefDS(_refs_64970);
    _32001 = NOVALUE;
    _31985 = NOVALUE;
    _31987 = NOVALUE;
    DeRef(_31995);
    _31995 = NOVALUE;
    return;
    ;
}


void _42shift_top(object _refs_65000, object _pc_65001, object _amount_65002)
{
    object _fr_65006 = NOVALUE;
    object _32017 = NOVALUE;
    object _32016 = NOVALUE;
    object _32015 = NOVALUE;
    object _32014 = NOVALUE;
    object _32013 = NOVALUE;
    object _32012 = NOVALUE;
    object _32011 = NOVALUE;
    object _32010 = NOVALUE;
    object _32009 = NOVALUE;
    object _32008 = NOVALUE;
    object _32006 = NOVALUE;
    object _32005 = NOVALUE;
    object _32003 = NOVALUE;
    object _32002 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:1083		for i = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_65000)){
            _32002 = SEQ_PTR(_refs_65000)->length;
    }
    else {
        _32002 = 1;
    }
    {
        object _i_65004;
        _i_65004 = _32002;
L1: 
        if (_i_65004 < 1LL){
            goto L2; // [12] 134
        }

        /** fwdref.e:1084			sequence fr = forward_references[refs[i]]*/
        _2 = (object)SEQ_PTR(_refs_65000);
        _32003 = (object)*(((s1_ptr)_2)->base + _i_65004);
        DeRef(_fr_65006);
        _2 = (object)SEQ_PTR(_42forward_references_63317);
        if (!IS_ATOM_INT(_32003)){
            _fr_65006 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32003)->dbl));
        }
        else{
            _fr_65006 = (object)*(((s1_ptr)_2)->base + _32003);
        }
        Ref(_fr_65006);

        /** fwdref.e:1085			forward_references[refs[i]] = 0*/
        _2 = (object)SEQ_PTR(_refs_65000);
        _32005 = (object)*(((s1_ptr)_2)->base + _i_65004);
        _2 = (object)SEQ_PTR(_42forward_references_63317);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _42forward_references_63317 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_32005))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_32005)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _32005);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0LL;
        DeRef(_1);

        /** fwdref.e:1086			if fr[FR_PC] >= pc then*/
        _2 = (object)SEQ_PTR(_fr_65006);
        _32006 = (object)*(((s1_ptr)_2)->base + 5LL);
        if (binary_op_a(LESS, _32006, _pc_65001)){
            _32006 = NOVALUE;
            goto L3; // [51] 113
        }
        _32006 = NOVALUE;

        /** fwdref.e:1087				fr[FR_PC] += amount*/
        _2 = (object)SEQ_PTR(_fr_65006);
        _32008 = (object)*(((s1_ptr)_2)->base + 5LL);
        if (IS_ATOM_INT(_32008)) {
            _32009 = _32008 + _amount_65002;
            if ((object)((uintptr_t)_32009 + (uintptr_t)HIGH_BITS) >= 0){
                _32009 = NewDouble((eudouble)_32009);
            }
        }
        else {
            _32009 = binary_op(PLUS, _32008, _amount_65002);
        }
        _32008 = NOVALUE;
        _2 = (object)SEQ_PTR(_fr_65006);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _fr_65006 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _32009;
        if( _1 != _32009 ){
            DeRef(_1);
        }
        _32009 = NOVALUE;

        /** fwdref.e:1088				if fr[FR_TYPE] = CASE*/
        _2 = (object)SEQ_PTR(_fr_65006);
        _32010 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_32010)) {
            _32011 = (_32010 == 186LL);
        }
        else {
            _32011 = binary_op(EQUALS, _32010, 186LL);
        }
        _32010 = NOVALUE;
        if (IS_ATOM_INT(_32011)) {
            if (_32011 == 0) {
                goto L4; // [81] 112
            }
        }
        else {
            if (DBL_PTR(_32011)->dbl == 0.0) {
                goto L4; // [81] 112
            }
        }
        _2 = (object)SEQ_PTR(_fr_65006);
        _32013 = (object)*(((s1_ptr)_2)->base + 12LL);
        if (IS_ATOM_INT(_32013)) {
            _32014 = (_32013 >= _pc_65001);
        }
        else {
            _32014 = binary_op(GREATEREQ, _32013, _pc_65001);
        }
        _32013 = NOVALUE;
        if (_32014 == 0) {
            DeRef(_32014);
            _32014 = NOVALUE;
            goto L4; // [94] 112
        }
        else {
            if (!IS_ATOM_INT(_32014) && DBL_PTR(_32014)->dbl == 0.0){
                DeRef(_32014);
                _32014 = NOVALUE;
                goto L4; // [94] 112
            }
            DeRef(_32014);
            _32014 = NOVALUE;
        }
        DeRef(_32014);
        _32014 = NOVALUE;

        /** fwdref.e:1091					fr[FR_DATA] += amount*/
        _2 = (object)SEQ_PTR(_fr_65006);
        _32015 = (object)*(((s1_ptr)_2)->base + 12LL);
        if (IS_ATOM_INT(_32015)) {
            _32016 = _32015 + _amount_65002;
            if ((object)((uintptr_t)_32016 + (uintptr_t)HIGH_BITS) >= 0){
                _32016 = NewDouble((eudouble)_32016);
            }
        }
        else {
            _32016 = binary_op(PLUS, _32015, _amount_65002);
        }
        _32015 = NOVALUE;
        _2 = (object)SEQ_PTR(_fr_65006);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _fr_65006 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 12LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _32016;
        if( _1 != _32016 ){
            DeRef(_1);
        }
        _32016 = NOVALUE;
L4: 
L3: 

        /** fwdref.e:1094			forward_references[refs[i]] = fr*/
        _2 = (object)SEQ_PTR(_refs_65000);
        _32017 = (object)*(((s1_ptr)_2)->base + _i_65004);
        RefDS(_fr_65006);
        _2 = (object)SEQ_PTR(_42forward_references_63317);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _42forward_references_63317 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_32017))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_32017)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _32017);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _fr_65006;
        DeRef(_1);
        DeRefDS(_fr_65006);
        _fr_65006 = NOVALUE;

        /** fwdref.e:1095		end for*/
        _i_65004 = _i_65004 + -1LL;
        goto L1; // [129] 19
L2: 
        ;
    }

    /** fwdref.e:1096	end procedure*/
    DeRefDS(_refs_65000);
    _32003 = NOVALUE;
    _32005 = NOVALUE;
    DeRef(_32011);
    _32011 = NOVALUE;
    _32017 = NOVALUE;
    return;
    ;
}


void _42shift_fwd_refs(object _pc_65027, object _amount_65028)
{
    object _file_65039 = NOVALUE;
    object _sp_65044 = NOVALUE;
    object _32027 = NOVALUE;
    object _32026 = NOVALUE;
    object _32024 = NOVALUE;
    object _32022 = NOVALUE;
    object _32021 = NOVALUE;
    object _32020 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:1099		if not shifting_sub then*/
    if (_42shifting_sub_63336 != 0)
    goto L1; // [9] 18

    /** fwdref.e:1100			return*/
    return;
L1: 

    /** fwdref.e:1103		if shifting_sub = TopLevelSub then*/
    if (_42shifting_sub_63336 != _27TopLevelSub_20578)
    goto L2; // [24] 65

    /** fwdref.e:1104			for file = 1 to length( toplevel_references ) do*/
    if (IS_SEQUENCE(_42toplevel_references_63320)){
            _32020 = SEQ_PTR(_42toplevel_references_63320)->length;
    }
    else {
        _32020 = 1;
    }
    {
        object _file_65035;
        _file_65035 = 1LL;
L3: 
        if (_file_65035 > _32020){
            goto L4; // [35] 62
        }

        /** fwdref.e:1105				shift_top( toplevel_references[file], pc, amount )*/
        _2 = (object)SEQ_PTR(_42toplevel_references_63320);
        _32021 = (object)*(((s1_ptr)_2)->base + _file_65035);
        Ref(_32021);
        _42shift_top(_32021, _pc_65027, _amount_65028);
        _32021 = NOVALUE;

        /** fwdref.e:1106			end for*/
        _file_65035 = _file_65035 + 1LL;
        goto L3; // [57] 42
L4: 
        ;
    }
    goto L5; // [62] 118
L2: 

    /** fwdref.e:1108			integer file = SymTab[shifting_sub][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32022 = (object)*(((s1_ptr)_2)->base + _42shifting_sub_63336);
    _2 = (object)SEQ_PTR(_32022);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _file_65039 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _file_65039 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    if (!IS_ATOM_INT(_file_65039)){
        _file_65039 = (object)DBL_PTR(_file_65039)->dbl;
    }
    _32022 = NOVALUE;

    /** fwdref.e:1109			integer sp   = find( shifting_sub, active_subprogs[file] )*/
    _2 = (object)SEQ_PTR(_42active_subprogs_63318);
    _32024 = (object)*(((s1_ptr)_2)->base + _file_65039);
    _sp_65044 = find_from(_42shifting_sub_63336, _32024, 1LL);
    _32024 = NOVALUE;

    /** fwdref.e:1110			shift_these( active_references[file][sp], pc, amount )*/
    _2 = (object)SEQ_PTR(_42active_references_63319);
    _32026 = (object)*(((s1_ptr)_2)->base + _file_65039);
    _2 = (object)SEQ_PTR(_32026);
    _32027 = (object)*(((s1_ptr)_2)->base + _sp_65044);
    _32026 = NOVALUE;
    Ref(_32027);
    _42shift_these(_32027, _pc_65027, _amount_65028);
    _32027 = NOVALUE;
L5: 

    /** fwdref.e:1112	end procedure*/
    return;
    ;
}



// 0x5CAC82C0
