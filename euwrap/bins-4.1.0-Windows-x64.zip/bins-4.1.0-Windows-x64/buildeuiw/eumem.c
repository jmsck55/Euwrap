// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _35malloc(object _mem_struct_p_13053, object _cleanup_p_13055)
{
    object _temp__13056 = NOVALUE;
    object _7535 = NOVALUE;
    object _7533 = NOVALUE;
    object _7532 = NOVALUE;
    object _7531 = NOVALUE;
    object _7527 = NOVALUE;
    object _0, _1, _2;
    

    /** eumem.e:51		if atom(mem_struct_p) then*/
    _7527 = IS_ATOM(_mem_struct_p_13053);
    if (_7527 == 0)
    {
        _7527 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _7527 = NOVALUE;
    }

    /** eumem.e:52			mem_struct_p = repeat(0, mem_struct_p)*/
    _0 = _mem_struct_p_13053;
    _mem_struct_p_13053 = Repeat(0LL, _mem_struct_p_13053);
    DeRef(_0);
L1: 

    /** eumem.e:54		if ram_free_list = 0 then*/
    if (_35ram_free_list_13049 != 0LL)
    goto L2; // [22] 72

    /** eumem.e:55			ram_space = append(ram_space, mem_struct_p)*/
    Ref(_mem_struct_p_13053);
    Append(&_35ram_space_13045, _35ram_space_13045, _mem_struct_p_13053);

    /** eumem.e:56			if cleanup_p then*/
    if (_cleanup_p_13055 == 0)
    {
        goto L3; // [36] 59
    }
    else{
    }

    /** eumem.e:57				return delete_routine( length(ram_space), free_rid )*/
    if (IS_SEQUENCE(_35ram_space_13045)){
            _7531 = SEQ_PTR(_35ram_space_13045)->length;
    }
    else {
        _7531 = 1;
    }
    _7532 = NewDouble( (eudouble) _7531 );
    _1 = (object) _00[_35free_rid_13050].cleanup;
    if( _1 == 0 ){
        _1 = (object) TransAlloc( sizeof(struct cleanup) );
        _00[_35free_rid_13050].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _35free_rid_13050;
    ((cleanup_ptr)_1)->next = 0;
    if(DBL_PTR(_7532)->cleanup != 0 ){
        _1 = (object) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_7532)->cleanup );
    }
    else if( !UNIQUE(DBL_PTR(_7532)) ){
        DeRefDS(_7532);
        _7532 = NewDouble( DBL_PTR(_7532)->dbl );
    }
    DBL_PTR(_7532)->cleanup = (cleanup_ptr)_1;
    _7531 = NOVALUE;
    DeRef(_mem_struct_p_13053);
    return _7532;
    goto L4; // [56] 71
L3: 

    /** eumem.e:59				return length(ram_space)*/
    if (IS_SEQUENCE(_35ram_space_13045)){
            _7533 = SEQ_PTR(_35ram_space_13045)->length;
    }
    else {
        _7533 = 1;
    }
    DeRef(_mem_struct_p_13053);
    DeRef(_7532);
    _7532 = NOVALUE;
    return _7533;
L4: 
L2: 

    /** eumem.e:63		temp_ = ram_free_list*/
    _temp__13056 = _35ram_free_list_13049;

    /** eumem.e:64		ram_free_list = ram_space[temp_]*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    _35ram_free_list_13049 = (object)*(((s1_ptr)_2)->base + _temp__13056);
    if (!IS_ATOM_INT(_35ram_free_list_13049))
    _35ram_free_list_13049 = (object)DBL_PTR(_35ram_free_list_13049)->dbl;

    /** eumem.e:65		ram_space[temp_] = mem_struct_p*/
    Ref(_mem_struct_p_13053);
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_13045 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _temp__13056);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _mem_struct_p_13053;
    DeRef(_1);

    /** eumem.e:67		if cleanup_p then*/
    if (_cleanup_p_13055 == 0)
    {
        goto L5; // [97] 115
    }
    else{
    }

    /** eumem.e:68			return delete_routine( temp_, free_rid )*/
    _7535 = NewDouble( (eudouble) _temp__13056 );
    _1 = (object) _00[_35free_rid_13050].cleanup;
    if( _1 == 0 ){
        _1 = (object) TransAlloc( sizeof(struct cleanup) );
        _00[_35free_rid_13050].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _35free_rid_13050;
    ((cleanup_ptr)_1)->next = 0;
    if(DBL_PTR(_7535)->cleanup != 0 ){
        _1 = (object) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_7535)->cleanup );
    }
    else if( !UNIQUE(DBL_PTR(_7535)) ){
        DeRefDS(_7535);
        _7535 = NewDouble( DBL_PTR(_7535)->dbl );
    }
    DBL_PTR(_7535)->cleanup = (cleanup_ptr)_1;
    DeRef(_mem_struct_p_13053);
    DeRef(_7532);
    _7532 = NOVALUE;
    return _7535;
    goto L6; // [112] 122
L5: 

    /** eumem.e:70			return temp_*/
    DeRef(_mem_struct_p_13053);
    DeRef(_7532);
    _7532 = NOVALUE;
    DeRef(_7535);
    _7535 = NOVALUE;
    return _temp__13056;
L6: 
    ;
}


void _35free(object _mem_p_13074)
{
    object _7538 = NOVALUE;
    object _7536 = NOVALUE;
    object _0, _1, _2;
    

    /** eumem.e:95		if object( ram_space ) then*/
    if( NOVALUE == _35ram_space_13045 ){
        _7536 = 0;
    }
    else{
        _7536 = 3;
    }
    if (_7536 == 0)
    {
        _7536 = NOVALUE;
        goto L1; // [6] 52
    }
    else{
        _7536 = NOVALUE;
    }

    /** eumem.e:96			if mem_p < 1 then return end if*/
    if (binary_op_a(GREATEREQ, _mem_p_13074, 1LL)){
        goto L2; // [11] 19
    }
    DeRef(_mem_p_13074);
    return;
L2: 

    /** eumem.e:97			if mem_p > length(ram_space) then return end if*/
    if (IS_SEQUENCE(_35ram_space_13045)){
            _7538 = SEQ_PTR(_35ram_space_13045)->length;
    }
    else {
        _7538 = 1;
    }
    if (binary_op_a(LESSEQ, _mem_p_13074, _7538)){
        _7538 = NOVALUE;
        goto L3; // [26] 34
    }
    _7538 = NOVALUE;
    DeRef(_mem_p_13074);
    return;
L3: 

    /** eumem.e:99			ram_space[mem_p] = ram_free_list*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_13045 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_mem_p_13074))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_mem_p_13074)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _mem_p_13074);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35ram_free_list_13049;
    DeRef(_1);

    /** eumem.e:100			ram_free_list = floor(mem_p)*/
    if (IS_ATOM_INT(_mem_p_13074))
    _35ram_free_list_13049 = e_floor(_mem_p_13074);
    else
    _35ram_free_list_13049 = unary_op(FLOOR, _mem_p_13074);
    if (!IS_ATOM_INT(_35ram_free_list_13049)) {
        _1 = (object)(DBL_PTR(_35ram_free_list_13049)->dbl);
        DeRefDS(_35ram_free_list_13049);
        _35ram_free_list_13049 = _1;
    }
L1: 

    /** eumem.e:102	end procedure*/
    DeRef(_mem_p_13074);
    return;
    ;
}



// 0xD983EBD8
