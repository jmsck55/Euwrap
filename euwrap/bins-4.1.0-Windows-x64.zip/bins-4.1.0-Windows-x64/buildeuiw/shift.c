// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _65init_op_info()
{
    object _SHORT_CIRCUIT_25040 = NOVALUE;
    object _info_25085 = NOVALUE;
    object _14068 = NOVALUE;
    object _14067 = NOVALUE;
    object _14066 = NOVALUE;
    object _14065 = NOVALUE;
    object _14064 = NOVALUE;
    object _14063 = NOVALUE;
    object _14061 = NOVALUE;
    object _14060 = NOVALUE;
    object _14059 = NOVALUE;
    object _14058 = NOVALUE;
    object _14057 = NOVALUE;
    object _14056 = NOVALUE;
    object _14055 = NOVALUE;
    object _14054 = NOVALUE;
    object _14053 = NOVALUE;
    object _14052 = NOVALUE;
    object _14051 = NOVALUE;
    object _14050 = NOVALUE;
    object _14049 = NOVALUE;
    object _14048 = NOVALUE;
    object _14047 = NOVALUE;
    object _14046 = NOVALUE;
    object _14045 = NOVALUE;
    object _14044 = NOVALUE;
    object _14042 = NOVALUE;
    object _14041 = NOVALUE;
    object _14040 = NOVALUE;
    object _14039 = NOVALUE;
    object _14038 = NOVALUE;
    object _14037 = NOVALUE;
    object _14036 = NOVALUE;
    object _14035 = NOVALUE;
    object _14034 = NOVALUE;
    object _14033 = NOVALUE;
    object _14032 = NOVALUE;
    object _14031 = NOVALUE;
    object _14030 = NOVALUE;
    object _14029 = NOVALUE;
    object _14028 = NOVALUE;
    object _14027 = NOVALUE;
    object _14026 = NOVALUE;
    object _14025 = NOVALUE;
    object _14024 = NOVALUE;
    object _14023 = NOVALUE;
    object _14022 = NOVALUE;
    object _14021 = NOVALUE;
    object _14020 = NOVALUE;
    object _14019 = NOVALUE;
    object _14018 = NOVALUE;
    object _14017 = NOVALUE;
    object _14016 = NOVALUE;
    object _14015 = NOVALUE;
    object _14014 = NOVALUE;
    object _14013 = NOVALUE;
    object _14012 = NOVALUE;
    object _14011 = NOVALUE;
    object _14010 = NOVALUE;
    object _14009 = NOVALUE;
    object _14008 = NOVALUE;
    object _14007 = NOVALUE;
    object _14006 = NOVALUE;
    object _14005 = NOVALUE;
    object _14004 = NOVALUE;
    object _14003 = NOVALUE;
    object _14002 = NOVALUE;
    object _14001 = NOVALUE;
    object _14000 = NOVALUE;
    object _13999 = NOVALUE;
    object _13998 = NOVALUE;
    object _13997 = NOVALUE;
    object _13996 = NOVALUE;
    object _13995 = NOVALUE;
    object _13993 = NOVALUE;
    object _13992 = NOVALUE;
    object _13991 = NOVALUE;
    object _13990 = NOVALUE;
    object _13989 = NOVALUE;
    object _13988 = NOVALUE;
    object _13987 = NOVALUE;
    object _13986 = NOVALUE;
    object _13985 = NOVALUE;
    object _13984 = NOVALUE;
    object _13983 = NOVALUE;
    object _13982 = NOVALUE;
    object _13981 = NOVALUE;
    object _13980 = NOVALUE;
    object _13979 = NOVALUE;
    object _13978 = NOVALUE;
    object _13977 = NOVALUE;
    object _13976 = NOVALUE;
    object _13975 = NOVALUE;
    object _13974 = NOVALUE;
    object _13973 = NOVALUE;
    object _13972 = NOVALUE;
    object _13971 = NOVALUE;
    object _13970 = NOVALUE;
    object _13969 = NOVALUE;
    object _13968 = NOVALUE;
    object _13967 = NOVALUE;
    object _13966 = NOVALUE;
    object _13965 = NOVALUE;
    object _13964 = NOVALUE;
    object _13963 = NOVALUE;
    object _13962 = NOVALUE;
    object _13961 = NOVALUE;
    object _13960 = NOVALUE;
    object _13959 = NOVALUE;
    object _13958 = NOVALUE;
    object _13957 = NOVALUE;
    object _13956 = NOVALUE;
    object _13955 = NOVALUE;
    object _13954 = NOVALUE;
    object _13953 = NOVALUE;
    object _13952 = NOVALUE;
    object _13951 = NOVALUE;
    object _13950 = NOVALUE;
    object _13949 = NOVALUE;
    object _13948 = NOVALUE;
    object _13947 = NOVALUE;
    object _13946 = NOVALUE;
    object _13945 = NOVALUE;
    object _13944 = NOVALUE;
    object _13943 = NOVALUE;
    object _13942 = NOVALUE;
    object _13941 = NOVALUE;
    object _13940 = NOVALUE;
    object _13939 = NOVALUE;
    object _13938 = NOVALUE;
    object _13937 = NOVALUE;
    object _13936 = NOVALUE;
    object _13935 = NOVALUE;
    object _13934 = NOVALUE;
    object _13933 = NOVALUE;
    object _13932 = NOVALUE;
    object _13931 = NOVALUE;
    object _13930 = NOVALUE;
    object _13929 = NOVALUE;
    object _13928 = NOVALUE;
    object _13927 = NOVALUE;
    object _13926 = NOVALUE;
    object _13925 = NOVALUE;
    object _13924 = NOVALUE;
    object _13922 = NOVALUE;
    object _13921 = NOVALUE;
    object _13920 = NOVALUE;
    object _13919 = NOVALUE;
    object _13918 = NOVALUE;
    object _13917 = NOVALUE;
    object _13916 = NOVALUE;
    object _13915 = NOVALUE;
    object _13914 = NOVALUE;
    object _13913 = NOVALUE;
    object _13912 = NOVALUE;
    object _13911 = NOVALUE;
    object _13910 = NOVALUE;
    object _13909 = NOVALUE;
    object _13908 = NOVALUE;
    object _13907 = NOVALUE;
    object _13906 = NOVALUE;
    object _13905 = NOVALUE;
    object _13904 = NOVALUE;
    object _13903 = NOVALUE;
    object _13902 = NOVALUE;
    object _13901 = NOVALUE;
    object _13900 = NOVALUE;
    object _13899 = NOVALUE;
    object _13898 = NOVALUE;
    object _13897 = NOVALUE;
    object _13896 = NOVALUE;
    object _13894 = NOVALUE;
    object _13893 = NOVALUE;
    object _13892 = NOVALUE;
    object _13891 = NOVALUE;
    object _13890 = NOVALUE;
    object _13889 = NOVALUE;
    object _13888 = NOVALUE;
    object _13887 = NOVALUE;
    object _13886 = NOVALUE;
    object _13885 = NOVALUE;
    object _13884 = NOVALUE;
    object _13883 = NOVALUE;
    object _13882 = NOVALUE;
    object _13881 = NOVALUE;
    object _13880 = NOVALUE;
    object _13879 = NOVALUE;
    object _13878 = NOVALUE;
    object _13877 = NOVALUE;
    object _13876 = NOVALUE;
    object _13875 = NOVALUE;
    object _13874 = NOVALUE;
    object _13873 = NOVALUE;
    object _13872 = NOVALUE;
    object _13871 = NOVALUE;
    object _13870 = NOVALUE;
    object _13869 = NOVALUE;
    object _13868 = NOVALUE;
    object _13867 = NOVALUE;
    object _13866 = NOVALUE;
    object _13865 = NOVALUE;
    object _13864 = NOVALUE;
    object _13863 = NOVALUE;
    object _13862 = NOVALUE;
    object _13861 = NOVALUE;
    object _13860 = NOVALUE;
    object _13859 = NOVALUE;
    object _13858 = NOVALUE;
    object _13857 = NOVALUE;
    object _13856 = NOVALUE;
    object _13855 = NOVALUE;
    object _13854 = NOVALUE;
    object _13853 = NOVALUE;
    object _13852 = NOVALUE;
    object _13851 = NOVALUE;
    object _13850 = NOVALUE;
    object _13849 = NOVALUE;
    object _13847 = NOVALUE;
    object _13846 = NOVALUE;
    object _13845 = NOVALUE;
    object _13844 = NOVALUE;
    object _13843 = NOVALUE;
    object _13842 = NOVALUE;
    object _13841 = NOVALUE;
    object _13840 = NOVALUE;
    object _13839 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:44		op_info = repeat( 0, MAX_OPCODE )*/
    DeRef(_65op_info_24613);
    _65op_info_24613 = Repeat(0LL, 218LL);

    /** shift.e:45		op_info_size_type = repeat( 0, MAX_OPCODE )*/
    DeRef(_65op_info_size_type_24619);
    _65op_info_size_type_24619 = Repeat(0LL, 218LL);

    /** shift.e:46		op_info_size = repeat( 0, MAX_OPCODE )*/
    DeRef(_65op_info_size_24620);
    _65op_info_size_24620 = Repeat(0LL, 218LL);

    /** shift.e:47		op_info_addr = repeat( 0, MAX_OPCODE )*/
    DeRef(_65op_info_addr_24621);
    _65op_info_addr_24621 = Repeat(0LL, 218LL);

    /** shift.e:48		op_info_target = repeat( 0, MAX_OPCODE )*/
    DeRef(_65op_info_target_24622);
    _65op_info_target_24622 = Repeat(0LL, 218LL);

    /** shift.e:49		op_info_sub = repeat( 0, MAX_OPCODE )*/
    DeRef(_65op_info_sub_24623);
    _65op_info_sub_24623 = Repeat(0LL, 218LL);

    /** shift.e:51		op_info[ABORT               ] = { FIXED_SIZE, 2, {}, {}, {} }   -- ary: pun*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13839 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 126LL);
    *(intptr_t *)_2 = _13839;
    if( _1 != _13839 ){
    }
    _13839 = NOVALUE;

    /** shift.e:52		op_info[AND                 ] = { FIXED_SIZE, 4, {}, {}, {} }   -- ary: bin*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13840 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 8LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13840;
    if( _1 != _13840 ){
        DeRef(_1);
    }
    _13840 = NOVALUE;

    /** shift.e:53		op_info[AND_BITS            ] = { FIXED_SIZE, 4, {}, {3}, {} }   -- ary: bin*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13841 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 56LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13841;
    if( _1 != _13841 ){
        DeRef(_1);
    }
    _13841 = NOVALUE;

    /** shift.e:54		op_info[APPEND              ] = { FIXED_SIZE, 4, {}, {3}, {} }   -- ary: bin*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13842 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 35LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13842;
    if( _1 != _13842 ){
        DeRef(_1);
    }
    _13842 = NOVALUE;

    /** shift.e:55		op_info[ARCTAN              ] = { FIXED_SIZE, 3, {}, {2}, {} }   -- ary: un*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13843 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 73LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13843;
    if( _1 != _13843 ){
        DeRef(_1);
    }
    _13843 = NOVALUE;

    /** shift.e:56		op_info[ASSIGN              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13844 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 18LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13844;
    if( _1 != _13844 ){
        DeRef(_1);
    }
    _13844 = NOVALUE;

    /** shift.e:57		op_info[ASSIGN_I            ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13845 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 113LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13845;
    if( _1 != _13845 ){
        DeRef(_1);
    }
    _13845 = NOVALUE;

    /** shift.e:58		op_info[ASSIGN_OP_SLICE     ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13682);
    ((intptr_t*)_2)[4] = _13682;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13846 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 150LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13846;
    if( _1 != _13846 ){
        DeRef(_1);
    }
    _13846 = NOVALUE;

    /** shift.e:59		op_info[ASSIGN_OP_SUBS      ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13847 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 149LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13847;
    if( _1 != _13847 ){
        DeRef(_1);
    }
    _13847 = NOVALUE;

    /** shift.e:60		op_info[ASSIGN_SLICE        ] = { FIXED_SIZE, 5, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13848);
    ((intptr_t*)_2)[4] = _13848;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13849 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 45LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13849;
    if( _1 != _13849 ){
        DeRef(_1);
    }
    _13849 = NOVALUE;

    /** shift.e:61		op_info[ASSIGN_SUBS         ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13848);
    ((intptr_t*)_2)[4] = _13848;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13850 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 16LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13850;
    if( _1 != _13850 ){
        DeRef(_1);
    }
    _13850 = NOVALUE;

    /** shift.e:62		op_info[ASSIGN_SUBS_CHECK   ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13848);
    ((intptr_t*)_2)[4] = _13848;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13851 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 84LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13851;
    if( _1 != _13851 ){
        DeRef(_1);
    }
    _13851 = NOVALUE;

    /** shift.e:63		op_info[ASSIGN_SUBS_I       ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13848);
    ((intptr_t*)_2)[4] = _13848;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13852 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 118LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13852;
    if( _1 != _13852 ){
        DeRef(_1);
    }
    _13852 = NOVALUE;

    /** shift.e:64		op_info[BADRETURNF          ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13853 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 43LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13853;
    if( _1 != _13853 ){
        DeRef(_1);
    }
    _13853 = NOVALUE;

    /** shift.e:65		op_info[CALL                ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13854 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 129LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13854;
    if( _1 != _13854 ){
        DeRef(_1);
    }
    _13854 = NOVALUE;

    /** shift.e:66		op_info[CALL_PROC           ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13855 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 136LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13855;
    if( _1 != _13855 ){
        DeRef(_1);
    }
    _13855 = NOVALUE;

    /** shift.e:67		op_info[CALL_FUNC           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13856 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 137LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13856;
    if( _1 != _13856 ){
        DeRef(_1);
    }
    _13856 = NOVALUE;

    /** shift.e:68		op_info[CASE                ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13857 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 186LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13857;
    if( _1 != _13857 ){
        DeRef(_1);
    }
    _13857 = NOVALUE;

    /** shift.e:69		op_info[CLEAR_SCREEN        ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13858 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 59LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13858;
    if( _1 != _13858 ){
        DeRef(_1);
    }
    _13858 = NOVALUE;

    /** shift.e:70		op_info[CLOSE               ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13859 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 86LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13859;
    if( _1 != _13859 ){
        DeRef(_1);
    }
    _13859 = NOVALUE;

    /** shift.e:71		op_info[COMMAND_LINE        ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13848);
    ((intptr_t*)_2)[4] = _13848;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13860 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 100LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13860;
    if( _1 != _13860 ){
        DeRef(_1);
    }
    _13860 = NOVALUE;

    /** shift.e:72		op_info[COMPARE             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13861 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 76LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13861;
    if( _1 != _13861 ){
        DeRef(_1);
    }
    _13861 = NOVALUE;

    /** shift.e:73		op_info[CONCAT              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13862 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13862;
    if( _1 != _13862 ){
        DeRef(_1);
    }
    _13862 = NOVALUE;

    /** shift.e:74		op_info[COS                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13863 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 81LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13863;
    if( _1 != _13863 ){
        DeRef(_1);
    }
    _13863 = NOVALUE;

    /** shift.e:75		op_info[COVERAGE_LINE       ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13864 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 210LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13864;
    if( _1 != _13864 ){
        DeRef(_1);
    }
    _13864 = NOVALUE;

    /** shift.e:76		op_info[COVERAGE_ROUTINE    ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13865 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 211LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13865;
    if( _1 != _13865 ){
        DeRef(_1);
    }
    _13865 = NOVALUE;

    /** shift.e:77		op_info[C_FUNC              ] = { FIXED_SIZE, 5, {}, {4}, {3} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13682);
    ((intptr_t*)_2)[4] = _13682;
    RefDS(_13459);
    ((intptr_t*)_2)[5] = _13459;
    _13866 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 133LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13866;
    if( _1 != _13866 ){
        DeRef(_1);
    }
    _13866 = NOVALUE;

    /** shift.e:78		op_info[C_PROC              ] = { FIXED_SIZE, 4, {}, {}, {3} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[5] = _13459;
    _13867 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 132LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13867;
    if( _1 != _13867 ){
        DeRef(_1);
    }
    _13867 = NOVALUE;

    /** shift.e:79		op_info[DATE                ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13848);
    ((intptr_t*)_2)[4] = _13848;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13868 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 69LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13868;
    if( _1 != _13868 ){
        DeRef(_1);
    }
    _13868 = NOVALUE;

    /** shift.e:80		op_info[DELETE_ROUTINE      ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13869 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 204LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13869;
    if( _1 != _13869 ){
        DeRef(_1);
    }
    _13869 = NOVALUE;

    /** shift.e:81		op_info[DELETE_OBJECT       ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13870 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 205LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13870;
    if( _1 != _13870 ){
        DeRef(_1);
    }
    _13870 = NOVALUE;

    /** shift.e:82		op_info[DIV2                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13871 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 98LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13871;
    if( _1 != _13871 ){
        DeRef(_1);
    }
    _13871 = NOVALUE;

    /** shift.e:83		op_info[DIVIDE              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13872 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13872;
    if( _1 != _13872 ){
        DeRef(_1);
    }
    _13872 = NOVALUE;

    /** shift.e:84		op_info[ELSE                ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_13848);
    ((intptr_t*)_2)[3] = _13848;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13873 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13873;
    if( _1 != _13873 ){
        DeRef(_1);
    }
    _13873 = NOVALUE;

    /** shift.e:85		op_info[EXIT                ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_13848);
    ((intptr_t*)_2)[3] = _13848;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13874 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 61LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13874;
    if( _1 != _13874 ){
        DeRef(_1);
    }
    _13874 = NOVALUE;

    /** shift.e:86		op_info[EXIT_BLOCK          ] = { FIXED_SIZE, 2, {},  {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13875 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 206LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13875;
    if( _1 != _13875 ){
        DeRef(_1);
    }
    _13875 = NOVALUE;

    /** shift.e:87		op_info[ENDWHILE            ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_13848);
    ((intptr_t*)_2)[3] = _13848;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13876 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 22LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13876;
    if( _1 != _13876 ){
        DeRef(_1);
    }
    _13876 = NOVALUE;

    /** shift.e:88		op_info[RETRY               ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_13848);
    ((intptr_t*)_2)[3] = _13848;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13877 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 184LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13877;
    if( _1 != _13877 ){
        DeRef(_1);
    }
    _13877 = NOVALUE;

    /** shift.e:89		op_info[GOTO                ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_13848);
    ((intptr_t*)_2)[3] = _13848;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13878 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 188LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13878;
    if( _1 != _13878 ){
        DeRef(_1);
    }
    _13878 = NOVALUE;

    /** shift.e:90		op_info[ENDFOR_GENERAL      ] = { FIXED_SIZE, 5, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_13848);
    ((intptr_t*)_2)[3] = _13848;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13879 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13879;
    if( _1 != _13879 ){
        DeRef(_1);
    }
    _13879 = NOVALUE;

    /** shift.e:91		op_info[ENDFOR_UP           ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13848);
    ((intptr_t*)_2)[3] = _13848;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13880 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 49LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13880;
    if( _1 != _13880 ){
        DeRef(_1);
    }
    _13880 = NOVALUE;

    /** shift.e:92		op_info[ENDFOR_DOWN         ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13848);
    ((intptr_t*)_2)[3] = _13848;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13881 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 50LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13881;
    if( _1 != _13881 ){
        DeRef(_1);
    }
    _13881 = NOVALUE;

    /** shift.e:93		op_info[ENDFOR_INT_UP       ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13848);
    ((intptr_t*)_2)[3] = _13848;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13882 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 48LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13882;
    if( _1 != _13882 ){
        DeRef(_1);
    }
    _13882 = NOVALUE;

    /** shift.e:94		op_info[ENDFOR_INT_DOWN     ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13848);
    ((intptr_t*)_2)[3] = _13848;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13883 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 52LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13883;
    if( _1 != _13883 ){
        DeRef(_1);
    }
    _13883 = NOVALUE;

    /** shift.e:95		op_info[ENDFOR_INT_DOWN1    ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13848);
    ((intptr_t*)_2)[3] = _13848;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13884 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 55LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13884;
    if( _1 != _13884 ){
        DeRef(_1);
    }
    _13884 = NOVALUE;

    /** shift.e:96		op_info[ENDFOR_INT_UP1      ] = { FIXED_SIZE, 5, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_13848);
    ((intptr_t*)_2)[3] = _13848;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13885 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 54LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13885;
    if( _1 != _13885 ){
        DeRef(_1);
    }
    _13885 = NOVALUE;

    /** shift.e:97		op_info[EQUAL               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13886 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 153LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13886;
    if( _1 != _13886 ){
        DeRef(_1);
    }
    _13886 = NOVALUE;

    /** shift.e:98		op_info[EQUALS              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13887 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13887;
    if( _1 != _13887 ){
        DeRef(_1);
    }
    _13887 = NOVALUE;

    /** shift.e:99		op_info[EQUALS_IFW          ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13459);
    ((intptr_t*)_2)[3] = _13459;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13888 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 104LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13888;
    if( _1 != _13888 ){
        DeRef(_1);
    }
    _13888 = NOVALUE;

    /** shift.e:100		op_info[EQUALS_IFW_I        ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13459);
    ((intptr_t*)_2)[3] = _13459;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13889 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 121LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13889;
    if( _1 != _13889 ){
        DeRef(_1);
    }
    _13889 = NOVALUE;

    /** shift.e:101		op_info[FIND                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13890 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 77LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13890;
    if( _1 != _13890 ){
        DeRef(_1);
    }
    _13890 = NOVALUE;

    /** shift.e:102		op_info[FIND_FROM           ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13682);
    ((intptr_t*)_2)[4] = _13682;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13891 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 176LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13891;
    if( _1 != _13891 ){
        DeRef(_1);
    }
    _13891 = NOVALUE;

    /** shift.e:103		op_info[FLOOR               ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13892 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 83LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13892;
    if( _1 != _13892 ){
        DeRef(_1);
    }
    _13892 = NOVALUE;

    /** shift.e:104		op_info[FLOOR_DIV           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13893 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 63LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13893;
    if( _1 != _13893 ){
        DeRef(_1);
    }
    _13893 = NOVALUE;

    /** shift.e:105		op_info[FLOOR_DIV2          ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13894 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 66LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13894;
    if( _1 != _13894 ){
        DeRef(_1);
    }
    _13894 = NOVALUE;

    /** shift.e:106		op_info[FOR                 ] = { FIXED_SIZE, 7, {6}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 7LL;
    RefDS(_13895);
    ((intptr_t*)_2)[3] = _13895;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13896 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 21LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13896;
    if( _1 != _13896 ){
        DeRef(_1);
    }
    _13896 = NOVALUE;

    /** shift.e:107		op_info[FOR_I               ] = { FIXED_SIZE, 7, {6}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 7LL;
    RefDS(_13895);
    ((intptr_t*)_2)[3] = _13895;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13897 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 125LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13897;
    if( _1 != _13897 ){
        DeRef(_1);
    }
    _13897 = NOVALUE;

    /** shift.e:108		op_info[GETC                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13898 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13898;
    if( _1 != _13898 ){
        DeRef(_1);
    }
    _13898 = NOVALUE;

    /** shift.e:109		op_info[GETENV              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13899 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 91LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13899;
    if( _1 != _13899 ){
        DeRef(_1);
    }
    _13899 = NOVALUE;

    /** shift.e:110		op_info[GETS                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13900 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 17LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13900;
    if( _1 != _13900 ){
        DeRef(_1);
    }
    _13900 = NOVALUE;

    /** shift.e:111		op_info[GET_KEY             ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13848);
    ((intptr_t*)_2)[4] = _13848;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13901 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 79LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13901;
    if( _1 != _13901 ){
        DeRef(_1);
    }
    _13901 = NOVALUE;

    /** shift.e:112		op_info[GLABEL              ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_13848);
    ((intptr_t*)_2)[3] = _13848;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13902 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 189LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13902;
    if( _1 != _13902 ){
        DeRef(_1);
    }
    _13902 = NOVALUE;

    /** shift.e:113		op_info[GLOBAL_INIT_CHECK   ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13903 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 109LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13903;
    if( _1 != _13903 ){
        DeRef(_1);
    }
    _13903 = NOVALUE;

    /** shift.e:114		op_info[PRIVATE_INIT_CHECK  ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13904 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13904;
    if( _1 != _13904 ){
        DeRef(_1);
    }
    _13904 = NOVALUE;

    /** shift.e:115		op_info[GREATER             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13905 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13905;
    if( _1 != _13905 ){
        DeRef(_1);
    }
    _13905 = NOVALUE;

    /** shift.e:116		op_info[GREATEREQ           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13906 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13906;
    if( _1 != _13906 ){
        DeRef(_1);
    }
    _13906 = NOVALUE;

    /** shift.e:117		op_info[GREATEREQ_IFW       ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13459);
    ((intptr_t*)_2)[3] = _13459;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13907 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 103LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13907;
    if( _1 != _13907 ){
        DeRef(_1);
    }
    _13907 = NOVALUE;

    /** shift.e:118		op_info[GREATEREQ_IFW_I     ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13459);
    ((intptr_t*)_2)[3] = _13459;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13908 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 120LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13908;
    if( _1 != _13908 ){
        DeRef(_1);
    }
    _13908 = NOVALUE;

    /** shift.e:119		op_info[GREATER_IFW         ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13459);
    ((intptr_t*)_2)[3] = _13459;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13909 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 107LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13909;
    if( _1 != _13909 ){
        DeRef(_1);
    }
    _13909 = NOVALUE;

    /** shift.e:120		op_info[GREATER_IFW_I       ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13459);
    ((intptr_t*)_2)[3] = _13459;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13910 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 124LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13910;
    if( _1 != _13910 ){
        DeRef(_1);
    }
    _13910 = NOVALUE;

    /** shift.e:121		op_info[HASH                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13911 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 194LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13911;
    if( _1 != _13911 ){
        DeRef(_1);
    }
    _13911 = NOVALUE;

    /** shift.e:122		op_info[HEAD                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13912 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 198LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13912;
    if( _1 != _13912 ){
        DeRef(_1);
    }
    _13912 = NOVALUE;

    /** shift.e:123		op_info[IF                  ] = { FIXED_SIZE, 3, {2}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_13522);
    ((intptr_t*)_2)[3] = _13522;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13913 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 20LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13913;
    if( _1 != _13913 ){
        DeRef(_1);
    }
    _13913 = NOVALUE;

    /** shift.e:124		op_info[INSERT              ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13682);
    ((intptr_t*)_2)[4] = _13682;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13914 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 191LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13914;
    if( _1 != _13914 ){
        DeRef(_1);
    }
    _13914 = NOVALUE;

    /** shift.e:125		op_info[LENGTH              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13915 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 42LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13915;
    if( _1 != _13915 ){
        DeRef(_1);
    }
    _13915 = NOVALUE;

    /** shift.e:126		op_info[LESS                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13916 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13916;
    if( _1 != _13916 ){
        DeRef(_1);
    }
    _13916 = NOVALUE;

    /** shift.e:127		op_info[LESSEQ              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13917 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13917;
    if( _1 != _13917 ){
        DeRef(_1);
    }
    _13917 = NOVALUE;

    /** shift.e:128		op_info[LESSEQ_IFW          ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13459);
    ((intptr_t*)_2)[3] = _13459;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13918 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 106LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13918;
    if( _1 != _13918 ){
        DeRef(_1);
    }
    _13918 = NOVALUE;

    /** shift.e:129		op_info[LESSEQ_IFW_I        ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13459);
    ((intptr_t*)_2)[3] = _13459;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13919 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 123LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13919;
    if( _1 != _13919 ){
        DeRef(_1);
    }
    _13919 = NOVALUE;

    /** shift.e:130		op_info[LESS_IFW            ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13459);
    ((intptr_t*)_2)[3] = _13459;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13920 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 102LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13920;
    if( _1 != _13920 ){
        DeRef(_1);
    }
    _13920 = NOVALUE;

    /** shift.e:131		op_info[LESS_IFW_I          ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13459);
    ((intptr_t*)_2)[3] = _13459;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13921 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 119LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13921;
    if( _1 != _13921 ){
        DeRef(_1);
    }
    _13921 = NOVALUE;

    /** shift.e:132		op_info[LHS_SUBS            ] = { FIXED_SIZE, 5, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13922 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 95LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13922;
    if( _1 != _13922 ){
        DeRef(_1);
    }
    _13922 = NOVALUE;

    /** shift.e:133		op_info[LHS_SUBS1           ] = { FIXED_SIZE, 5, {}, {3,4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13923);
    ((intptr_t*)_2)[4] = _13923;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13924 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 161LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13924;
    if( _1 != _13924 ){
        DeRef(_1);
    }
    _13924 = NOVALUE;

    /** shift.e:134		op_info[LHS_SUBS1_COPY      ] = { FIXED_SIZE, 5, {}, {3,4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13923);
    ((intptr_t*)_2)[4] = _13923;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13925 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 166LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13925;
    if( _1 != _13925 ){
        DeRef(_1);
    }
    _13925 = NOVALUE;

    /** shift.e:135		op_info[LOG                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13926 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 74LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13926;
    if( _1 != _13926 ){
        DeRef(_1);
    }
    _13926 = NOVALUE;

    /** shift.e:136		op_info[MACHINE_FUNC        ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13927 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 111LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13927;
    if( _1 != _13927 ){
        DeRef(_1);
    }
    _13927 = NOVALUE;

    /** shift.e:137		op_info[MACHINE_PROC        ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13928 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 112LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13928;
    if( _1 != _13928 ){
        DeRef(_1);
    }
    _13928 = NOVALUE;

    /** shift.e:138		op_info[MATCH               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13929 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 78LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13929;
    if( _1 != _13929 ){
        DeRef(_1);
    }
    _13929 = NOVALUE;

    /** shift.e:139		op_info[MATCH_FROM          ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13682);
    ((intptr_t*)_2)[4] = _13682;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13930 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 177LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13930;
    if( _1 != _13930 ){
        DeRef(_1);
    }
    _13930 = NOVALUE;

    /** shift.e:140		op_info[MEM_COPY            ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13931 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 130LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13931;
    if( _1 != _13931 ){
        DeRef(_1);
    }
    _13931 = NOVALUE;

    /** shift.e:141		op_info[MEM_SET             ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13932 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 131LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13932;
    if( _1 != _13932 ){
        DeRef(_1);
    }
    _13932 = NOVALUE;

    /** shift.e:142		op_info[MINUS               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13933 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13933;
    if( _1 != _13933 ){
        DeRef(_1);
    }
    _13933 = NOVALUE;

    /** shift.e:143		op_info[MINUS_I             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13934 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 116LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13934;
    if( _1 != _13934 ){
        DeRef(_1);
    }
    _13934 = NOVALUE;

    /** shift.e:144		op_info[MULTIPLY            ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13935 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 13LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13935;
    if( _1 != _13935 ){
        DeRef(_1);
    }
    _13935 = NOVALUE;

    /** shift.e:145		op_info[NOP1                ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13936 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 159LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13936;
    if( _1 != _13936 ){
        DeRef(_1);
    }
    _13936 = NOVALUE;

    /** shift.e:146		op_info[NOPWHILE            ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13937 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 158LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13937;
    if( _1 != _13937 ){
        DeRef(_1);
    }
    _13937 = NOVALUE;

    /** shift.e:147		op_info[NOP2                ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13938 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 110LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13938;
    if( _1 != _13938 ){
        DeRef(_1);
    }
    _13938 = NOVALUE;

    /** shift.e:148		op_info[SC2_NULL            ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13939 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 145LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13939;
    if( _1 != _13939 ){
        DeRef(_1);
    }
    _13939 = NOVALUE;

    /** shift.e:149		op_info[ASSIGN_SUBS2        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13940 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 148LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13940;
    if( _1 != _13940 ){
        DeRef(_1);
    }
    _13940 = NOVALUE;

    /** shift.e:150		op_info[PLATFORM            ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13848);
    ((intptr_t*)_2)[4] = _13848;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13941 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 155LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13941;
    if( _1 != _13941 ){
        DeRef(_1);
    }
    _13941 = NOVALUE;

    /** shift.e:151		op_info[END_PARAM_CHECK     ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13942 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 156LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13942;
    if( _1 != _13942 ){
        DeRef(_1);
    }
    _13942 = NOVALUE;

    /** shift.e:153		op_info[NOPSWITCH           ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13943 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 187LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13943;
    if( _1 != _13943 ){
        DeRef(_1);
    }
    _13943 = NOVALUE;

    /** shift.e:154		op_info[NOT                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13944 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 7LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13944;
    if( _1 != _13944 ){
        DeRef(_1);
    }
    _13944 = NOVALUE;

    /** shift.e:155		op_info[NOTEQ               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13945 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13945;
    if( _1 != _13945 ){
        DeRef(_1);
    }
    _13945 = NOVALUE;

    /** shift.e:156		op_info[NOTEQ_IFW           ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13459);
    ((intptr_t*)_2)[3] = _13459;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13946 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 105LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13946;
    if( _1 != _13946 ){
        DeRef(_1);
    }
    _13946 = NOVALUE;

    /** shift.e:157		op_info[NOTEQ_IFW_I         ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13459);
    ((intptr_t*)_2)[3] = _13459;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13947 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 122LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13947;
    if( _1 != _13947 ){
        DeRef(_1);
    }
    _13947 = NOVALUE;

    /** shift.e:158		op_info[NOT_BITS            ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13948 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 51LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13948;
    if( _1 != _13948 ){
        DeRef(_1);
    }
    _13948 = NOVALUE;

    /** shift.e:159		op_info[NOT_IFW             ] = { FIXED_SIZE, 3, {2}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_13522);
    ((intptr_t*)_2)[3] = _13522;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13949 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 108LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13949;
    if( _1 != _13949 ){
        DeRef(_1);
    }
    _13949 = NOVALUE;

    /** shift.e:160		op_info[OPEN                ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13682);
    ((intptr_t*)_2)[4] = _13682;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13950 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 37LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13950;
    if( _1 != _13950 ){
        DeRef(_1);
    }
    _13950 = NOVALUE;

    /** shift.e:161		op_info[OPTION_SWITCHES     ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13848);
    ((intptr_t*)_2)[4] = _13848;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13951 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 183LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13951;
    if( _1 != _13951 ){
        DeRef(_1);
    }
    _13951 = NOVALUE;

    /** shift.e:162		op_info[OR                  ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13952 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13952;
    if( _1 != _13952 ){
        DeRef(_1);
    }
    _13952 = NOVALUE;

    /** shift.e:163		op_info[OR_BITS             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13953 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 24LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13953;
    if( _1 != _13953 ){
        DeRef(_1);
    }
    _13953 = NOVALUE;

    /** shift.e:164		op_info[PASSIGN_OP_SLICE    ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13682);
    ((intptr_t*)_2)[4] = _13682;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13954 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 165LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13954;
    if( _1 != _13954 ){
        DeRef(_1);
    }
    _13954 = NOVALUE;

    /** shift.e:165		op_info[PASSIGN_OP_SUBS     ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13955 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 164LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13955;
    if( _1 != _13955 ){
        DeRef(_1);
    }
    _13955 = NOVALUE;

    /** shift.e:166		op_info[PASSIGN_SLICE       ] = { FIXED_SIZE, 5, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13848);
    ((intptr_t*)_2)[4] = _13848;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13956 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 163LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13956;
    if( _1 != _13956 ){
        DeRef(_1);
    }
    _13956 = NOVALUE;

    /** shift.e:167		op_info[PASSIGN_SUBS        ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13848);
    ((intptr_t*)_2)[4] = _13848;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13957 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 162LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13957;
    if( _1 != _13957 ){
        DeRef(_1);
    }
    _13957 = NOVALUE;

    /** shift.e:168		op_info[PEEK_STRING         ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13958 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 182LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13958;
    if( _1 != _13958 ){
        DeRef(_1);
    }
    _13958 = NOVALUE;

    /** shift.e:169		op_info[PEEK8U              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13959 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 214LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13959;
    if( _1 != _13959 ){
        DeRef(_1);
    }
    _13959 = NOVALUE;

    /** shift.e:170		op_info[PEEK8S              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13960 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 213LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13960;
    if( _1 != _13960 ){
        DeRef(_1);
    }
    _13960 = NOVALUE;

    /** shift.e:171		op_info[PEEK2U              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13961 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 180LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13961;
    if( _1 != _13961 ){
        DeRef(_1);
    }
    _13961 = NOVALUE;

    /** shift.e:172		op_info[PEEK2S              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13962 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 179LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13962;
    if( _1 != _13962 ){
        DeRef(_1);
    }
    _13962 = NOVALUE;

    /** shift.e:173		op_info[PEEK4U              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13963 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 140LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13963;
    if( _1 != _13963 ){
        DeRef(_1);
    }
    _13963 = NOVALUE;

    /** shift.e:174		op_info[PEEK4S              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13964 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 139LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13964;
    if( _1 != _13964 ){
        DeRef(_1);
    }
    _13964 = NOVALUE;

    /** shift.e:175		op_info[PEEKS               ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13965 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 181LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13965;
    if( _1 != _13965 ){
        DeRef(_1);
    }
    _13965 = NOVALUE;

    /** shift.e:176		op_info[PEEK                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13966 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 127LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13966;
    if( _1 != _13966 ){
        DeRef(_1);
    }
    _13966 = NOVALUE;

    /** shift.e:177		op_info[SIZEOF              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13967 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 217LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13967;
    if( _1 != _13967 ){
        DeRef(_1);
    }
    _13967 = NOVALUE;

    /** shift.e:178		op_info[PEEK_POINTER        ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13968 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 216LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13968;
    if( _1 != _13968 ){
        DeRef(_1);
    }
    _13968 = NOVALUE;

    /** shift.e:179		op_info[PLENGTH             ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13969 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 160LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13969;
    if( _1 != _13969 ){
        DeRef(_1);
    }
    _13969 = NOVALUE;

    /** shift.e:180		op_info[PLUS                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13970 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13970;
    if( _1 != _13970 ){
        DeRef(_1);
    }
    _13970 = NOVALUE;

    /** shift.e:181		op_info[PLUS_I              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13971 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 115LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13971;
    if( _1 != _13971 ){
        DeRef(_1);
    }
    _13971 = NOVALUE;

    /** shift.e:182		op_info[PLUS1               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13972 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 93LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13972;
    if( _1 != _13972 ){
        DeRef(_1);
    }
    _13972 = NOVALUE;

    /** shift.e:183		op_info[PLUS1_I             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13973 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 117LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13973;
    if( _1 != _13973 ){
        DeRef(_1);
    }
    _13973 = NOVALUE;

    /** shift.e:184		op_info[POKE                ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13974 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 128LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13974;
    if( _1 != _13974 ){
        DeRef(_1);
    }
    _13974 = NOVALUE;

    /** shift.e:185		op_info[POKE2               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13975 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 178LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13975;
    if( _1 != _13975 ){
        DeRef(_1);
    }
    _13975 = NOVALUE;

    /** shift.e:186		op_info[POKE4               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13976 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 138LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13976;
    if( _1 != _13976 ){
        DeRef(_1);
    }
    _13976 = NOVALUE;

    /** shift.e:187		op_info[POKE8               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13977 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 212LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13977;
    if( _1 != _13977 ){
        DeRef(_1);
    }
    _13977 = NOVALUE;

    /** shift.e:188		op_info[POKE_POINTER        ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13978 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 215LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13978;
    if( _1 != _13978 ){
        DeRef(_1);
    }
    _13978 = NOVALUE;

    /** shift.e:189		op_info[POSITION            ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13979 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 60LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13979;
    if( _1 != _13979 ){
        DeRef(_1);
    }
    _13979 = NOVALUE;

    /** shift.e:190		op_info[POWER               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13980 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 72LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13980;
    if( _1 != _13980 ){
        DeRef(_1);
    }
    _13980 = NOVALUE;

    /** shift.e:191		op_info[PREPEND             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13981 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 57LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13981;
    if( _1 != _13981 ){
        DeRef(_1);
    }
    _13981 = NOVALUE;

    /** shift.e:192		op_info[PRINT               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13982 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 19LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13982;
    if( _1 != _13982 ){
        DeRef(_1);
    }
    _13982 = NOVALUE;

    /** shift.e:193		op_info[PRINTF              ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13983 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 38LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13983;
    if( _1 != _13983 ){
        DeRef(_1);
    }
    _13983 = NOVALUE;

    /** shift.e:194		op_info[PROFILE             ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13984 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 151LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13984;
    if( _1 != _13984 ){
        DeRef(_1);
    }
    _13984 = NOVALUE;

    /** shift.e:195		op_info[DISPLAY_VAR         ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13985 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 87LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13985;
    if( _1 != _13985 ){
        DeRef(_1);
    }
    _13985 = NOVALUE;

    /** shift.e:196		op_info[ERASE_PRIVATE_NAMES ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13986 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 88LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13986;
    if( _1 != _13986 ){
        DeRef(_1);
    }
    _13986 = NOVALUE;

    /** shift.e:197		op_info[ERASE_SYMBOL        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13987 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 90LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13987;
    if( _1 != _13987 ){
        DeRef(_1);
    }
    _13987 = NOVALUE;

    /** shift.e:198		op_info[PUTS                ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13988 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 44LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13988;
    if( _1 != _13988 ){
        DeRef(_1);
    }
    _13988 = NOVALUE;

    /** shift.e:199		op_info[QPRINT              ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13989 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13989;
    if( _1 != _13989 ){
        DeRef(_1);
    }
    _13989 = NOVALUE;

    /** shift.e:200		op_info[RAND                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13990 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 62LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13990;
    if( _1 != _13990 ){
        DeRef(_1);
    }
    _13990 = NOVALUE;

    /** shift.e:201		op_info[REMAINDER           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13991 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 71LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13991;
    if( _1 != _13991 ){
        DeRef(_1);
    }
    _13991 = NOVALUE;

    /** shift.e:202		op_info[REMOVE              ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13682);
    ((intptr_t*)_2)[4] = _13682;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13992 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 200LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13992;
    if( _1 != _13992 ){
        DeRef(_1);
    }
    _13992 = NOVALUE;

    /** shift.e:203		op_info[REPEAT              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13993 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13993;
    if( _1 != _13993 ){
        DeRef(_1);
    }
    _13993 = NOVALUE;

    /** shift.e:204		op_info[REPLACE             ] = { FIXED_SIZE, 6, {}, {5}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 6LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13994);
    ((intptr_t*)_2)[4] = _13994;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13995 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 201LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13995;
    if( _1 != _13995 ){
        DeRef(_1);
    }
    _13995 = NOVALUE;

    /** shift.e:205		op_info[RETURNF             ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13996 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 28LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13996;
    if( _1 != _13996 ){
        DeRef(_1);
    }
    _13996 = NOVALUE;

    /** shift.e:206		op_info[RETURNP             ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13997 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 29LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13997;
    if( _1 != _13997 ){
        DeRef(_1);
    }
    _13997 = NOVALUE;

    /** shift.e:207		op_info[RETURNT             ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13998 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 34LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13998;
    if( _1 != _13998 ){
        DeRef(_1);
    }
    _13998 = NOVALUE;

    /** shift.e:208		op_info[RHS_SLICE           ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13682);
    ((intptr_t*)_2)[4] = _13682;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13999 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 46LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13999;
    if( _1 != _13999 ){
        DeRef(_1);
    }
    _13999 = NOVALUE;

    /** shift.e:209		op_info[RHS_SUBS            ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14000 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14000;
    if( _1 != _14000 ){
        DeRef(_1);
    }
    _14000 = NOVALUE;

    /** shift.e:210		op_info[RHS_SUBS_I          ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14001 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 114LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14001;
    if( _1 != _14001 ){
        DeRef(_1);
    }
    _14001 = NOVALUE;

    /** shift.e:211		op_info[RHS_SUBS_CHECK      ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14002 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 92LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14002;
    if( _1 != _14002 ){
        DeRef(_1);
    }
    _14002 = NOVALUE;

    /** shift.e:212		op_info[RIGHT_BRACE_2       ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14003 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 85LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14003;
    if( _1 != _14003 ){
        DeRef(_1);
    }
    _14003 = NOVALUE;

    /** shift.e:214		op_info[ROUTINE_ID          ] = { FIXED_SIZE, 6 - TRANSLATE, {}, { 4 + not TRANSLATE }, {} }*/
    _14004 = 6LL - _27TRANSLATE_20179;
    _14005 = (_27TRANSLATE_20179 == 0);
    _14006 = 4LL + _14005;
    if ((object)((uintptr_t)_14006 + (uintptr_t)HIGH_BITS) >= 0){
        _14006 = NewDouble((eudouble)_14006);
    }
    _14005 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _14006;
    _14007 = MAKE_SEQ(_1);
    _14006 = NOVALUE;
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = _14004;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _14007;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14008 = MAKE_SEQ(_1);
    _14007 = NOVALUE;
    _14004 = NOVALUE;
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 134LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14008;
    if( _1 != _14008 ){
        DeRef(_1);
    }
    _14008 = NOVALUE;

    /** shift.e:215		op_info[SC2_OR              ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14009 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 144LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14009;
    if( _1 != _14009 ){
        DeRef(_1);
    }
    _14009 = NOVALUE;

    /** shift.e:216		op_info[SC2_AND             ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14010 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 142LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14010;
    if( _1 != _14010 ){
        DeRef(_1);
    }
    _14010 = NOVALUE;

    /** shift.e:217		op_info[SIN                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14011 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 80LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14011;
    if( _1 != _14011 ){
        DeRef(_1);
    }
    _14011 = NOVALUE;

    /** shift.e:218		op_info[SPACE_USED          ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14012 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 75LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14012;
    if( _1 != _14012 ){
        DeRef(_1);
    }
    _14012 = NOVALUE;

    /** shift.e:219		op_info[SPLICE              ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13682);
    ((intptr_t*)_2)[4] = _13682;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14013 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 190LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14013;
    if( _1 != _14013 ){
        DeRef(_1);
    }
    _14013 = NOVALUE;

    /** shift.e:220		op_info[SPRINTF             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14014 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 53LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14014;
    if( _1 != _14014 ){
        DeRef(_1);
    }
    _14014 = NOVALUE;

    /** shift.e:221		op_info[SQRT                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14015 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14015;
    if( _1 != _14015 ){
        DeRef(_1);
    }
    _14015 = NOVALUE;

    /** shift.e:222		op_info[STARTLINE           ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14016 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 58LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14016;
    if( _1 != _14016 ){
        DeRef(_1);
    }
    _14016 = NOVALUE;

    /** shift.e:223		op_info[SWITCH              ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_13682);
    ((intptr_t*)_2)[3] = _13682;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14017 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 185LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14017;
    if( _1 != _14017 ){
        DeRef(_1);
    }
    _14017 = NOVALUE;

    /** shift.e:224		op_info[SWITCH_I            ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_13682);
    ((intptr_t*)_2)[3] = _13682;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14018 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 193LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14018;
    if( _1 != _14018 ){
        DeRef(_1);
    }
    _14018 = NOVALUE;

    /** shift.e:225		op_info[SWITCH_SPI          ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_13682);
    ((intptr_t*)_2)[3] = _13682;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14019 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 192LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14019;
    if( _1 != _14019 ){
        DeRef(_1);
    }
    _14019 = NOVALUE;

    /** shift.e:226		op_info[SWITCH_RT           ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_13682);
    ((intptr_t*)_2)[3] = _13682;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14020 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 202LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14020;
    if( _1 != _14020 ){
        DeRef(_1);
    }
    _14020 = NOVALUE;

    /** shift.e:227		op_info[SYSTEM              ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14021 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 99LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14021;
    if( _1 != _14021 ){
        DeRef(_1);
    }
    _14021 = NOVALUE;

    /** shift.e:228		op_info[SYSTEM_EXEC         ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14022 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 154LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14022;
    if( _1 != _14022 ){
        DeRef(_1);
    }
    _14022 = NOVALUE;

    /** shift.e:229		op_info[TAIL                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14023 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 199LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14023;
    if( _1 != _14023 ){
        DeRef(_1);
    }
    _14023 = NOVALUE;

    /** shift.e:230		op_info[TAN                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14024 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 82LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14024;
    if( _1 != _14024 ){
        DeRef(_1);
    }
    _14024 = NOVALUE;

    /** shift.e:231		op_info[TASK_CLOCK_START    ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14025 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 175LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14025;
    if( _1 != _14025 ){
        DeRef(_1);
    }
    _14025 = NOVALUE;

    /** shift.e:232		op_info[TASK_CLOCK_STOP     ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14026 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 174LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14026;
    if( _1 != _14026 ){
        DeRef(_1);
    }
    _14026 = NOVALUE;

    /** shift.e:233		op_info[TASK_CREATE         ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14027 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 167LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14027;
    if( _1 != _14027 ){
        DeRef(_1);
    }
    _14027 = NOVALUE;

    /** shift.e:234		op_info[TASK_LIST           ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13848);
    ((intptr_t*)_2)[4] = _13848;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14028 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 172LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14028;
    if( _1 != _14028 ){
        DeRef(_1);
    }
    _14028 = NOVALUE;

    /** shift.e:235		op_info[TASK_SCHEDULE       ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14029 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 168LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14029;
    if( _1 != _14029 ){
        DeRef(_1);
    }
    _14029 = NOVALUE;

    /** shift.e:236		op_info[TASK_SELF           ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13848);
    ((intptr_t*)_2)[4] = _13848;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14030 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 170LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14030;
    if( _1 != _14030 ){
        DeRef(_1);
    }
    _14030 = NOVALUE;

    /** shift.e:237		op_info[TASK_STATUS         ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14031 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 173LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14031;
    if( _1 != _14031 ){
        DeRef(_1);
    }
    _14031 = NOVALUE;

    /** shift.e:238		op_info[TASK_SUSPEND        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14032 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 171LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14032;
    if( _1 != _14032 ){
        DeRef(_1);
    }
    _14032 = NOVALUE;

    /** shift.e:239		op_info[TASK_YIELD          ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14033 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 169LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14033;
    if( _1 != _14033 ){
        DeRef(_1);
    }
    _14033 = NOVALUE;

    /** shift.e:240		op_info[TIME                ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13848);
    ((intptr_t*)_2)[4] = _13848;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14034 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 70LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14034;
    if( _1 != _14034 ){
        DeRef(_1);
    }
    _14034 = NOVALUE;

    /** shift.e:241		op_info[TRACE               ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14035 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 64LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14035;
    if( _1 != _14035 ){
        DeRef(_1);
    }
    _14035 = NOVALUE;

    /** shift.e:242		op_info[TYPE_CHECK          ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14036 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 65LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14036;
    if( _1 != _14036 ){
        DeRef(_1);
    }
    _14036 = NOVALUE;

    /** shift.e:243		op_info[UMINUS              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14037 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14037;
    if( _1 != _14037 ){
        DeRef(_1);
    }
    _14037 = NOVALUE;

    /** shift.e:244		op_info[UPDATE_GLOBALS      ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14038 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 89LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14038;
    if( _1 != _14038 ){
        DeRef(_1);
    }
    _14038 = NOVALUE;

    /** shift.e:245		op_info[WHILE               ] = { FIXED_SIZE, 3, {2}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_13522);
    ((intptr_t*)_2)[3] = _13522;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14039 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 47LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14039;
    if( _1 != _14039 ){
        DeRef(_1);
    }
    _14039 = NOVALUE;

    /** shift.e:246		op_info[XOR                 ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14040 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 152LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14040;
    if( _1 != _14040 ){
        DeRef(_1);
    }
    _14040 = NOVALUE;

    /** shift.e:247		op_info[XOR_BITS            ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13459);
    ((intptr_t*)_2)[4] = _13459;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14041 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 26LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14041;
    if( _1 != _14041 ){
        DeRef(_1);
    }
    _14041 = NOVALUE;

    /** shift.e:249		op_info[TYPE_CHECK_FORWARD  ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14042 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 197LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14042;
    if( _1 != _14042 ){
        DeRef(_1);
    }
    _14042 = NOVALUE;

    /** shift.e:251		sequence SHORT_CIRCUIT = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _0 = _SHORT_CIRCUIT_25040;
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13459);
    ((intptr_t*)_2)[3] = _13459;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _SHORT_CIRCUIT_25040 = MAKE_SEQ(_1);
    DeRef(_0);

    /** shift.e:252		op_info[SC1_AND_IF          ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_25040);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 146LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _SHORT_CIRCUIT_25040;
    DeRef(_1);

    /** shift.e:253		op_info[SC1_OR_IF           ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_25040);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 147LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _SHORT_CIRCUIT_25040;
    DeRef(_1);

    /** shift.e:254		op_info[SC1_AND             ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_25040);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 141LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _SHORT_CIRCUIT_25040;
    DeRef(_1);

    /** shift.e:255		op_info[SC1_OR              ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_25040);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 143LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _SHORT_CIRCUIT_25040;
    DeRef(_1);

    /** shift.e:257		op_info[ATOM_CHECK          ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14044 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 101LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14044;
    if( _1 != _14044 ){
        DeRef(_1);
    }
    _14044 = NOVALUE;

    /** shift.e:258		op_info[INTEGER_CHECK       ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14045 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 96LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14045;
    if( _1 != _14045 ){
        DeRef(_1);
    }
    _14045 = NOVALUE;

    /** shift.e:259		op_info[SEQUENCE_CHECK      ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14046 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 97LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14046;
    if( _1 != _14046 ){
        DeRef(_1);
    }
    _14046 = NOVALUE;

    /** shift.e:261		op_info[IS_AN_INTEGER       ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14047 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 94LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14047;
    if( _1 != _14047 ){
        DeRef(_1);
    }
    _14047 = NOVALUE;

    /** shift.e:262		op_info[IS_AN_ATOM          ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14048 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 67LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14048;
    if( _1 != _14048 ){
        DeRef(_1);
    }
    _14048 = NOVALUE;

    /** shift.e:263		op_info[IS_A_SEQUENCE       ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14049 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 68LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14049;
    if( _1 != _14049 ){
        DeRef(_1);
    }
    _14049 = NOVALUE;

    /** shift.e:264		op_info[IS_AN_OBJECT        ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13522);
    ((intptr_t*)_2)[4] = _13522;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14050 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14050;
    if( _1 != _14050 ){
        DeRef(_1);
    }
    _14050 = NOVALUE;

    /** shift.e:266		op_info[CALL_BACK_RETURN    ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14051 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 135LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14051;
    if( _1 != _14051 ){
        DeRef(_1);
    }
    _14051 = NOVALUE;

    /** shift.e:268		op_info[REF_TEMP            ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14052 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 207LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14052;
    if( _1 != _14052 ){
        DeRef(_1);
    }
    _14052 = NOVALUE;

    /** shift.e:269		op_info[DEREF_TEMP          ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14053 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 208LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14053;
    if( _1 != _14053 ){
        DeRef(_1);
    }
    _14053 = NOVALUE;

    /** shift.e:270		op_info[NOVALUE_TEMP        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14054 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 209LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14054;
    if( _1 != _14054 ){
        DeRef(_1);
    }
    _14054 = NOVALUE;

    /** shift.e:272		op_info[PROC_FORWARD        ] = { VARIABLE_SIZE, 0, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 2LL;
    ((intptr_t*)_2)[2] = 0LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14055 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 195LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14055;
    if( _1 != _14055 ){
        DeRef(_1);
    }
    _14055 = NOVALUE;

    /** shift.e:273		op_info[FUNC_FORWARD        ] = { VARIABLE_SIZE, 0, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 2LL;
    ((intptr_t*)_2)[2] = 0LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14056 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 196LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14056;
    if( _1 != _14056 ){
        DeRef(_1);
    }
    _14056 = NOVALUE;

    /** shift.e:275		op_info[RIGHT_BRACE_N       ] = { VARIABLE_SIZE, 3, {}, {}, {} } -- target: [pc+1] + 2*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 2LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14057 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14057;
    if( _1 != _14057 ){
        DeRef(_1);
    }
    _14057 = NOVALUE;

    /** shift.e:276		op_info[CONCAT_N            ] = { VARIABLE_SIZE, 0, {}, {}, {} } -- target: [pc+1] + 2*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 2LL;
    ((intptr_t*)_2)[2] = 0LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14058 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 157LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14058;
    if( _1 != _14058 ){
        DeRef(_1);
    }
    _14058 = NOVALUE;

    /** shift.e:277		op_info[PROC                ] = { VARIABLE_SIZE, 0, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 2LL;
    ((intptr_t*)_2)[2] = 0LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14059 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 27LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14059;
    if( _1 != _14059 ){
        DeRef(_1);
    }
    _14059 = NOVALUE;

    /** shift.e:278		op_info[PROC_TAIL           ] = op_info[PROC]*/
    _2 = (object)SEQ_PTR(_65op_info_24613);
    _14060 = (object)*(((s1_ptr)_2)->base + 27LL);
    Ref(_14060);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24613 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 203LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14060;
    if( _1 != _14060 ){
        DeRef(_1);
    }
    _14060 = NOVALUE;

    /** shift.e:281		for i = 1 to MAX_OPCODE do*/
    _14061 = 218LL;
    {
        object _i_25082;
        _i_25082 = 1LL;
L1: 
        if (_i_25082 > 218LL){
            goto L2; // [3959] 4052
        }

        /** shift.e:282			object info = op_info[i]*/
        DeRef(_info_25085);
        _2 = (object)SEQ_PTR(_65op_info_24613);
        _info_25085 = (object)*(((s1_ptr)_2)->base + _i_25082);
        Ref(_info_25085);

        /** shift.e:283			if sequence( info ) then*/
        _14063 = IS_SEQUENCE(_info_25085);
        if (_14063 == 0)
        {
            _14063 = NOVALUE;
            goto L3; // [3979] 4043
        }
        else{
            _14063 = NOVALUE;
        }

        /** shift.e:284				op_info_size_type[i] = info[OP_SIZE_TYPE]*/
        _2 = (object)SEQ_PTR(_info_25085);
        _14064 = (object)*(((s1_ptr)_2)->base + 1LL);
        Ref(_14064);
        _2 = (object)SEQ_PTR(_65op_info_size_type_24619);
        _2 = (object)(((s1_ptr)_2)->base + _i_25082);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14064;
        if( _1 != _14064 ){
            DeRef(_1);
        }
        _14064 = NOVALUE;

        /** shift.e:285				op_info_size[i] = info[OP_SIZE]*/
        _2 = (object)SEQ_PTR(_info_25085);
        _14065 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_14065);
        _2 = (object)SEQ_PTR(_65op_info_size_24620);
        _2 = (object)(((s1_ptr)_2)->base + _i_25082);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14065;
        if( _1 != _14065 ){
            DeRef(_1);
        }
        _14065 = NOVALUE;

        /** shift.e:286				op_info_addr[i] = info[OP_ADDR]*/
        _2 = (object)SEQ_PTR(_info_25085);
        _14066 = (object)*(((s1_ptr)_2)->base + 3LL);
        Ref(_14066);
        _2 = (object)SEQ_PTR(_65op_info_addr_24621);
        _2 = (object)(((s1_ptr)_2)->base + _i_25082);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14066;
        if( _1 != _14066 ){
            DeRef(_1);
        }
        _14066 = NOVALUE;

        /** shift.e:287				op_info_target[i] = info[OP_TARGET]*/
        _2 = (object)SEQ_PTR(_info_25085);
        _14067 = (object)*(((s1_ptr)_2)->base + 4LL);
        Ref(_14067);
        _2 = (object)SEQ_PTR(_65op_info_target_24622);
        _2 = (object)(((s1_ptr)_2)->base + _i_25082);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14067;
        if( _1 != _14067 ){
            DeRef(_1);
        }
        _14067 = NOVALUE;

        /** shift.e:288				op_info_sub[i] = info[OP_SUB]*/
        _2 = (object)SEQ_PTR(_info_25085);
        _14068 = (object)*(((s1_ptr)_2)->base + 5LL);
        Ref(_14068);
        _2 = (object)SEQ_PTR(_65op_info_sub_24623);
        _2 = (object)(((s1_ptr)_2)->base + _i_25082);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14068;
        if( _1 != _14068 ){
            DeRef(_1);
        }
        _14068 = NOVALUE;
L3: 
        DeRef(_info_25085);
        _info_25085 = NOVALUE;

        /** shift.e:290		end for*/
        _i_25082 = _i_25082 + 1LL;
        goto L1; // [4047] 3966
L2: 
        ;
    }

    /** shift.e:291	end procedure*/
    DeRef(_SHORT_CIRCUIT_25040);
    return;
    ;
}


object _65variable_op_size(object _pc_25096, object _op_25097, object _code_25098)
{
    object _int_25101 = NOVALUE;
    object _info_25107 = NOVALUE;
    object _14088 = NOVALUE;
    object _14085 = NOVALUE;
    object _14082 = NOVALUE;
    object _14079 = NOVALUE;
    object _14078 = NOVALUE;
    object _14077 = NOVALUE;
    object _14076 = NOVALUE;
    object _14075 = NOVALUE;
    object _14074 = NOVALUE;
    object _14072 = NOVALUE;
    object _14071 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:297		switch op do*/
    _0 = _op_25097;
    switch ( _0 ){ 

        /** shift.e:298			case PROC, PROC_TAIL then*/
        case 27:
        case 203:

        /** shift.e:299				sequence info = SymTab[code[pc+1]]*/
        _14071 = _pc_25096 + 1;
        _2 = (object)SEQ_PTR(_code_25098);
        _14072 = (object)*(((s1_ptr)_2)->base + _14071);
        DeRef(_info_25107);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!IS_ATOM_INT(_14072)){
            _info_25107 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14072)->dbl));
        }
        else{
            _info_25107 = (object)*(((s1_ptr)_2)->base + _14072);
        }
        Ref(_info_25107);

        /** shift.e:300				return info[S_NUM_ARGS] + 2 + (info[S_TOKEN] != PROC)*/
        _2 = (object)SEQ_PTR(_info_25107);
        if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
            _14074 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
        }
        else{
            _14074 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
        }
        if (IS_ATOM_INT(_14074)) {
            _14075 = _14074 + 2LL;
            if ((object)((uintptr_t)_14075 + (uintptr_t)HIGH_BITS) >= 0){
                _14075 = NewDouble((eudouble)_14075);
            }
        }
        else {
            _14075 = binary_op(PLUS, _14074, 2LL);
        }
        _14074 = NOVALUE;
        _2 = (object)SEQ_PTR(_info_25107);
        if (!IS_ATOM_INT(_27S_TOKEN_20214)){
            _14076 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
        }
        else{
            _14076 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
        }
        if (IS_ATOM_INT(_14076)) {
            _14077 = (_14076 != 27LL);
        }
        else {
            _14077 = binary_op(NOTEQ, _14076, 27LL);
        }
        _14076 = NOVALUE;
        if (IS_ATOM_INT(_14075) && IS_ATOM_INT(_14077)) {
            _14078 = _14075 + _14077;
            if ((object)((uintptr_t)_14078 + (uintptr_t)HIGH_BITS) >= 0){
                _14078 = NewDouble((eudouble)_14078);
            }
        }
        else {
            _14078 = binary_op(PLUS, _14075, _14077);
        }
        DeRef(_14075);
        _14075 = NOVALUE;
        DeRef(_14077);
        _14077 = NOVALUE;
        DeRefDS(_info_25107);
        DeRefDS(_code_25098);
        _14072 = NOVALUE;
        _14071 = NOVALUE;
        return _14078;
        goto L1; // [72] 157

        /** shift.e:302			case PROC_FORWARD then*/
        case 195:

        /** shift.e:303				int = code[pc+2]*/
        _14079 = _pc_25096 + 2LL;
        _2 = (object)SEQ_PTR(_code_25098);
        _int_25101 = (object)*(((s1_ptr)_2)->base + _14079);
        if (!IS_ATOM_INT(_int_25101))
        _int_25101 = (object)DBL_PTR(_int_25101)->dbl;

        /** shift.e:304				int += 3*/
        _int_25101 = _int_25101 + 3LL;
        goto L1; // [94] 157

        /** shift.e:305			case FUNC_FORWARD then*/
        case 196:

        /** shift.e:306				int = code[pc+2]*/
        _14082 = _pc_25096 + 2LL;
        _2 = (object)SEQ_PTR(_code_25098);
        _int_25101 = (object)*(((s1_ptr)_2)->base + _14082);
        if (!IS_ATOM_INT(_int_25101))
        _int_25101 = (object)DBL_PTR(_int_25101)->dbl;

        /** shift.e:307				int += 4*/
        _int_25101 = _int_25101 + 4LL;
        goto L1; // [116] 157

        /** shift.e:308			case RIGHT_BRACE_N, CONCAT_N then*/
        case 31:
        case 157:

        /** shift.e:309				int = code[pc+1]*/
        _14085 = _pc_25096 + 1;
        _2 = (object)SEQ_PTR(_code_25098);
        _int_25101 = (object)*(((s1_ptr)_2)->base + _14085);
        if (!IS_ATOM_INT(_int_25101))
        _int_25101 = (object)DBL_PTR(_int_25101)->dbl;

        /** shift.e:310				int += 3*/
        _int_25101 = _int_25101 + 3LL;
        goto L1; // [140] 157

        /** shift.e:311			case else*/
        default:

        /** shift.e:312				InternalErr( 269, {op} )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _op_25097;
        _14088 = MAKE_SEQ(_1);
        _49InternalErr(269LL, _14088);
        _14088 = NOVALUE;
    ;}L1: 

    /** shift.e:314		return int*/
    DeRefDS(_code_25098);
    _14072 = NOVALUE;
    DeRef(_14079);
    _14079 = NOVALUE;
    DeRef(_14082);
    _14082 = NOVALUE;
    DeRef(_14085);
    _14085 = NOVALUE;
    DeRef(_14078);
    _14078 = NOVALUE;
    DeRef(_14071);
    _14071 = NOVALUE;
    return _int_25101;
    ;
}


object _65op_size(object _pc_25141, object _code_25142)
{
    object _op_25145 = NOVALUE;
    object _int_25147 = NOVALUE;
    object _14093 = NOVALUE;
    object _14092 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:318		integer op = code[pc]*/
    _2 = (object)SEQ_PTR(_code_25142);
    _op_25145 = (object)*(((s1_ptr)_2)->base + _pc_25141);
    if (!IS_ATOM_INT(_op_25145))
    _op_25145 = (object)DBL_PTR(_op_25145)->dbl;

    /** shift.e:319		integer int = op_info_size_type[op]*/
    _2 = (object)SEQ_PTR(_65op_info_size_type_24619);
    _int_25147 = (object)*(((s1_ptr)_2)->base + _op_25145);
    if (!IS_ATOM_INT(_int_25147))
    _int_25147 = (object)DBL_PTR(_int_25147)->dbl;

    /** shift.e:321		if int = FIXED_SIZE then*/
    if (_int_25147 != 1LL)
    goto L1; // [21] 40

    /** shift.e:322			return op_info_size[op]*/
    _2 = (object)SEQ_PTR(_65op_info_size_24620);
    _14092 = (object)*(((s1_ptr)_2)->base + _op_25145);
    Ref(_14092);
    DeRefDS(_code_25142);
    return _14092;
    goto L2; // [37] 53
L1: 

    /** shift.e:324			return variable_op_size( pc, op, code )*/
    RefDS(_code_25142);
    _14093 = _65variable_op_size(_pc_25141, _op_25145, _code_25142);
    DeRefDS(_code_25142);
    _14092 = NOVALUE;
    return _14093;
L2: 
    ;
}


object _65advance(object _pc_25156, object _code_25157)
{
    object _size_25160 = NOVALUE;
    object _14095 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:329		integer size = op_size( pc, code )*/
    RefDS(_code_25157);
    _size_25160 = _65op_size(_pc_25156, _code_25157);
    if (!IS_ATOM_INT(_size_25160)) {
        _1 = (object)(DBL_PTR(_size_25160)->dbl);
        DeRefDS(_size_25160);
        _size_25160 = _1;
    }

    /** shift.e:330		return pc + size*/
    _14095 = _pc_25156 + _size_25160;
    if ((object)((uintptr_t)_14095 + (uintptr_t)HIGH_BITS) >= 0){
        _14095 = NewDouble((eudouble)_14095);
    }
    DeRefDS(_code_25157);
    return _14095;
    ;
}


void _65shift_switch(object _pc_25165, object _start_25166, object _amount_25167)
{
    object _addr_25168 = NOVALUE;
    object _jump_25200 = NOVALUE;
    object _14130 = NOVALUE;
    object _14129 = NOVALUE;
    object _14128 = NOVALUE;
    object _14127 = NOVALUE;
    object _14126 = NOVALUE;
    object _14125 = NOVALUE;
    object _14124 = NOVALUE;
    object _14123 = NOVALUE;
    object _14122 = NOVALUE;
    object _14121 = NOVALUE;
    object _14120 = NOVALUE;
    object _14118 = NOVALUE;
    object _14117 = NOVALUE;
    object _14116 = NOVALUE;
    object _14115 = NOVALUE;
    object _14114 = NOVALUE;
    object _14113 = NOVALUE;
    object _14112 = NOVALUE;
    object _14111 = NOVALUE;
    object _14109 = NOVALUE;
    object _14108 = NOVALUE;
    object _14107 = NOVALUE;
    object _14106 = NOVALUE;
    object _14105 = NOVALUE;
    object _14102 = NOVALUE;
    object _14100 = NOVALUE;
    object _14099 = NOVALUE;
    object _14098 = NOVALUE;
    object _14097 = NOVALUE;
    object _14096 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** shift.e:336		if sequence( Code[pc+4] ) then*/
    _14096 = _pc_25165 + 4LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _14097 = (object)*(((s1_ptr)_2)->base + _14096);
    _14098 = IS_SEQUENCE(_14097);
    _14097 = NOVALUE;
    if (_14098 == 0)
    {
        _14098 = NOVALUE;
        goto L1; // [22] 46
    }
    else{
        _14098 = NOVALUE;
    }

    /** shift.e:337			addr = Code[pc+4][2]*/
    _14099 = _pc_25165 + 4LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _14100 = (object)*(((s1_ptr)_2)->base + _14099);
    _2 = (object)SEQ_PTR(_14100);
    _addr_25168 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_addr_25168)){
        _addr_25168 = (object)DBL_PTR(_addr_25168)->dbl;
    }
    _14100 = NOVALUE;
    goto L2; // [43] 61
L1: 

    /** shift.e:339			addr = Code[pc+4]*/
    _14102 = _pc_25165 + 4LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _addr_25168 = (object)*(((s1_ptr)_2)->base + _14102);
    if (!IS_ATOM_INT(_addr_25168)){
        _addr_25168 = (object)DBL_PTR(_addr_25168)->dbl;
    }
L2: 

    /** shift.e:343		if start < addr then*/
    if (_start_25166 >= _addr_25168)
    goto L3; // [65] 137

    /** shift.e:344			if sequence( Code[pc+4] ) then*/
    _14105 = _pc_25165 + 4LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _14106 = (object)*(((s1_ptr)_2)->base + _14105);
    _14107 = IS_SEQUENCE(_14106);
    _14106 = NOVALUE;
    if (_14107 == 0)
    {
        _14107 = NOVALUE;
        goto L4; // [84] 115
    }
    else{
        _14107 = NOVALUE;
    }

    /** shift.e:345				Code[pc+4][2] += amount*/
    _14108 = _pc_25165 + 4LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14108 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _14111 = (object)*(((s1_ptr)_2)->base + 2LL);
    _14109 = NOVALUE;
    if (IS_ATOM_INT(_14111)) {
        _14112 = _14111 + _amount_25167;
        if ((object)((uintptr_t)_14112 + (uintptr_t)HIGH_BITS) >= 0){
            _14112 = NewDouble((eudouble)_14112);
        }
    }
    else {
        _14112 = binary_op(PLUS, _14111, _amount_25167);
    }
    _14111 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14112;
    if( _1 != _14112 ){
        DeRef(_1);
    }
    _14112 = NOVALUE;
    _14109 = NOVALUE;
    goto L5; // [112] 136
L4: 

    /** shift.e:347				Code[pc+4] += amount*/
    _14113 = _pc_25165 + 4LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _14114 = (object)*(((s1_ptr)_2)->base + _14113);
    if (IS_ATOM_INT(_14114)) {
        _14115 = _14114 + _amount_25167;
        if ((object)((uintptr_t)_14115 + (uintptr_t)HIGH_BITS) >= 0){
            _14115 = NewDouble((eudouble)_14115);
        }
    }
    else {
        _14115 = binary_op(PLUS, _14114, _amount_25167);
    }
    _14114 = NOVALUE;
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14113);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14115;
    if( _1 != _14115 ){
        DeRef(_1);
    }
    _14115 = NOVALUE;
L5: 
L3: 

    /** shift.e:351		sequence jump = SymTab[Code[pc+3]][S_OBJ]*/
    _14116 = _pc_25165 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _14117 = (object)*(((s1_ptr)_2)->base + _14116);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_14117)){
        _14118 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14117)->dbl));
    }
    else{
        _14118 = (object)*(((s1_ptr)_2)->base + _14117);
    }
    DeRef(_jump_25200);
    _2 = (object)SEQ_PTR(_14118);
    _jump_25200 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_jump_25200);
    _14118 = NOVALUE;

    /** shift.e:352		for i = 1 to length(jump) do*/
    if (IS_SEQUENCE(_jump_25200)){
            _14120 = SEQ_PTR(_jump_25200)->length;
    }
    else {
        _14120 = 1;
    }
    {
        object _i_25209;
        _i_25209 = 1LL;
L6: 
        if (_i_25209 > _14120){
            goto L7; // [168] 223
        }

        /** shift.e:353			if start > pc and start < pc + jump[i] then*/
        _14121 = (_start_25166 > _pc_25165);
        if (_14121 == 0) {
            goto L8; // [181] 216
        }
        _2 = (object)SEQ_PTR(_jump_25200);
        _14123 = (object)*(((s1_ptr)_2)->base + _i_25209);
        if (IS_ATOM_INT(_14123)) {
            _14124 = _pc_25165 + _14123;
            if ((object)((uintptr_t)_14124 + (uintptr_t)HIGH_BITS) >= 0){
                _14124 = NewDouble((eudouble)_14124);
            }
        }
        else {
            _14124 = binary_op(PLUS, _pc_25165, _14123);
        }
        _14123 = NOVALUE;
        if (IS_ATOM_INT(_14124)) {
            _14125 = (_start_25166 < _14124);
        }
        else {
            _14125 = binary_op(LESS, _start_25166, _14124);
        }
        DeRef(_14124);
        _14124 = NOVALUE;
        if (_14125 == 0) {
            DeRef(_14125);
            _14125 = NOVALUE;
            goto L8; // [198] 216
        }
        else {
            if (!IS_ATOM_INT(_14125) && DBL_PTR(_14125)->dbl == 0.0){
                DeRef(_14125);
                _14125 = NOVALUE;
                goto L8; // [198] 216
            }
            DeRef(_14125);
            _14125 = NOVALUE;
        }
        DeRef(_14125);
        _14125 = NOVALUE;

        /** shift.e:354				jump[i] += amount*/
        _2 = (object)SEQ_PTR(_jump_25200);
        _14126 = (object)*(((s1_ptr)_2)->base + _i_25209);
        if (IS_ATOM_INT(_14126)) {
            _14127 = _14126 + _amount_25167;
            if ((object)((uintptr_t)_14127 + (uintptr_t)HIGH_BITS) >= 0){
                _14127 = NewDouble((eudouble)_14127);
            }
        }
        else {
            _14127 = binary_op(PLUS, _14126, _amount_25167);
        }
        _14126 = NOVALUE;
        _2 = (object)SEQ_PTR(_jump_25200);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _jump_25200 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_25209);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14127;
        if( _1 != _14127 ){
            DeRef(_1);
        }
        _14127 = NOVALUE;
L8: 

        /** shift.e:356		end for*/
        _i_25209 = _i_25209 + 1LL;
        goto L6; // [218] 175
L7: 
        ;
    }

    /** shift.e:357		SymTab[Code[pc+3]][S_OBJ] = jump*/
    _14128 = _pc_25165 + 3LL;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _14129 = (object)*(((s1_ptr)_2)->base + _14128);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_14129))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14129)->dbl));
    else
    _3 = (object)(_14129 + ((s1_ptr)_2)->base);
    RefDS(_jump_25200);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _jump_25200;
    DeRef(_1);
    _14130 = NOVALUE;

    /** shift.e:358	end procedure*/
    DeRefDS(_jump_25200);
    DeRef(_14096);
    _14096 = NOVALUE;
    _14117 = NOVALUE;
    DeRef(_14105);
    _14105 = NOVALUE;
    DeRef(_14099);
    _14099 = NOVALUE;
    _14129 = NOVALUE;
    DeRef(_14102);
    _14102 = NOVALUE;
    DeRef(_14113);
    _14113 = NOVALUE;
    _14128 = NOVALUE;
    DeRef(_14116);
    _14116 = NOVALUE;
    DeRef(_14108);
    _14108 = NOVALUE;
    DeRef(_14121);
    _14121 = NOVALUE;
    return;
    ;
}


void _65shift_addr(object _pc_25228, object _amount_25229, object _start_25230, object _bound_25231)
{
    object _int_25232 = NOVALUE;
    object _14145 = NOVALUE;
    object _14142 = NOVALUE;
    object _14138 = NOVALUE;
    object _14133 = NOVALUE;
    object _14132 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_pc_25228)) {
        _1 = (object)(DBL_PTR(_pc_25228)->dbl);
        DeRefDS(_pc_25228);
        _pc_25228 = _1;
    }

    /** shift.e:362		if atom( Code[pc] ) then*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    _14132 = (object)*(((s1_ptr)_2)->base + _pc_25228);
    _14133 = IS_ATOM(_14132);
    _14132 = NOVALUE;
    if (_14133 == 0)
    {
        _14133 = NOVALUE;
        goto L1; // [20] 75
    }
    else{
        _14133 = NOVALUE;
    }

    /** shift.e:363			int = Code[pc]*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    _int_25232 = (object)*(((s1_ptr)_2)->base + _pc_25228);
    if (!IS_ATOM_INT(_int_25232)){
        _int_25232 = (object)DBL_PTR(_int_25232)->dbl;
    }

    /** shift.e:364			if int >= start then*/
    if (_int_25232 < _start_25230)
    goto L2; // [35] 139

    /** shift.e:365				if int < bound then*/
    if (_int_25232 >= _bound_25231)
    goto L3; // [41] 56

    /** shift.e:366					Code[pc] = start*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _pc_25228);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _start_25230;
    DeRef(_1);
    goto L2; // [53] 139
L3: 

    /** shift.e:368					int += amount*/
    _int_25232 = _int_25232 + _amount_25229;

    /** shift.e:369					Code[pc] = int*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _pc_25228);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_25232;
    DeRef(_1);
    goto L2; // [72] 139
L1: 

    /** shift.e:373			int = Code[pc][2]*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    _14138 = (object)*(((s1_ptr)_2)->base + _pc_25228);
    _2 = (object)SEQ_PTR(_14138);
    _int_25232 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_int_25232)){
        _int_25232 = (object)DBL_PTR(_int_25232)->dbl;
    }
    _14138 = NOVALUE;

    /** shift.e:374			if int >= start then*/
    if (_int_25232 < _start_25230)
    goto L4; // [91] 138

    /** shift.e:375				if int < bound then*/
    if (_int_25232 >= _bound_25231)
    goto L5; // [97] 117

    /** shift.e:376					Code[pc][2] = start*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    _3 = (object)(_pc_25228 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _start_25230;
    DeRef(_1);
    _14142 = NOVALUE;
    goto L6; // [114] 137
L5: 

    /** shift.e:378					int += amount*/
    _int_25232 = _int_25232 + _amount_25229;

    /** shift.e:379					Code[pc][2] = int*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    _3 = (object)(_pc_25228 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_25232;
    DeRef(_1);
    _14145 = NOVALUE;
L6: 
L4: 
L2: 

    /** shift.e:383	end procedure*/
    return;
    ;
}


void _65shift(object _start_25265, object _amount_25266, object _bound_25267)
{
    object _int_25270 = NOVALUE;
    object _pc_25283 = NOVALUE;
    object _op_25284 = NOVALUE;
    object _finish_25285 = NOVALUE;
    object _len_25288 = NOVALUE;
    object _size_type_25313 = NOVALUE;
    object _14172 = NOVALUE;
    object _14170 = NOVALUE;
    object _14167 = NOVALUE;
    object _14165 = NOVALUE;
    object _14162 = NOVALUE;
    object _14161 = NOVALUE;
    object _14160 = NOVALUE;
    object _14158 = NOVALUE;
    object _14153 = NOVALUE;
    object _14148 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_25265)) {
        _1 = (object)(DBL_PTR(_start_25265)->dbl);
        DeRefDS(_start_25265);
        _start_25265 = _1;
    }
    if (!IS_ATOM_INT(_amount_25266)) {
        _1 = (object)(DBL_PTR(_amount_25266)->dbl);
        DeRefDS(_amount_25266);
        _amount_25266 = _1;
    }
    if (!IS_ATOM_INT(_bound_25267)) {
        _1 = (object)(DBL_PTR(_bound_25267)->dbl);
        DeRefDS(_bound_25267);
        _bound_25267 = _1;
    }

    /** shift.e:388		if amount = 0 then*/
    if (_amount_25266 != 0LL)
    goto L1; // [9] 19

    /** shift.e:389			return*/
    return;
L1: 

    /** shift.e:392		integer int*/

    /** shift.e:393		for i = length( LineTable ) to 1 by -1 do*/
    if (IS_SEQUENCE(_27LineTable_20661)){
            _14148 = SEQ_PTR(_27LineTable_20661)->length;
    }
    else {
        _14148 = 1;
    }
    {
        object _i_25272;
        _i_25272 = _14148;
L2: 
        if (_i_25272 < 1LL){
            goto L3; // [28] 84
        }

        /** shift.e:394			int = LineTable[i]*/
        _2 = (object)SEQ_PTR(_27LineTable_20661);
        _int_25270 = (object)*(((s1_ptr)_2)->base + _i_25272);
        if (!IS_ATOM_INT(_int_25270)){
            _int_25270 = (object)DBL_PTR(_int_25270)->dbl;
        }

        /** shift.e:395			if int > 0 then*/
        if (_int_25270 <= 0LL)
        goto L4; // [47] 77

        /** shift.e:396				if int < start then*/
        if (_int_25270 >= _start_25265)
        goto L5; // [53] 62

        /** shift.e:397					exit*/
        goto L3; // [59] 84
L5: 

        /** shift.e:399				int += amount*/
        _int_25270 = _int_25270 + _amount_25266;

        /** shift.e:400				LineTable[i] = int*/
        _2 = (object)SEQ_PTR(_27LineTable_20661);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _27LineTable_20661 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_25272);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _int_25270;
        DeRef(_1);
L4: 

        /** shift.e:402		end for*/
        _i_25272 = _i_25272 + -1LL;
        goto L2; // [79] 35
L3: 
        ;
    }

    /** shift.e:404		integer pc = 1*/
    _pc_25283 = 1LL;

    /** shift.e:405		integer op*/

    /** shift.e:406		integer finish = start + amount - 1*/
    _14153 = _start_25265 + _amount_25266;
    if ((object)((uintptr_t)_14153 + (uintptr_t)HIGH_BITS) >= 0){
        _14153 = NewDouble((eudouble)_14153);
    }
    if (IS_ATOM_INT(_14153)) {
        _finish_25285 = _14153 - 1LL;
    }
    else {
        _finish_25285 = NewDouble(DBL_PTR(_14153)->dbl - (eudouble)1LL);
    }
    DeRef(_14153);
    _14153 = NOVALUE;
    if (!IS_ATOM_INT(_finish_25285)) {
        _1 = (object)(DBL_PTR(_finish_25285)->dbl);
        DeRefDS(_finish_25285);
        _finish_25285 = _1;
    }

    /** shift.e:407		integer len = length( Code )*/
    if (IS_SEQUENCE(_27Code_20660)){
            _len_25288 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _len_25288 = 1;
    }

    /** shift.e:408		while pc <= len do*/
L6: 
    if (_pc_25283 > _len_25288)
    goto L7; // [115] 278

    /** shift.e:409			op = Code[pc]*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    _op_25284 = (object)*(((s1_ptr)_2)->base + _pc_25283);
    if (!IS_ATOM_INT(_op_25284)){
        _op_25284 = (object)DBL_PTR(_op_25284)->dbl;
    }

    /** shift.e:410			if pc < start or pc > finish then*/
    _14158 = (_pc_25283 < _start_25265);
    if (_14158 != 0) {
        goto L8; // [135] 148
    }
    _14160 = (_pc_25283 > _finish_25285);
    if (_14160 == 0)
    {
        DeRef(_14160);
        _14160 = NOVALUE;
        goto L9; // [144] 223
    }
    else{
        DeRef(_14160);
        _14160 = NOVALUE;
    }
L8: 

    /** shift.e:412				if length( op_info_addr[op] ) then*/
    _2 = (object)SEQ_PTR(_65op_info_addr_24621);
    _14161 = (object)*(((s1_ptr)_2)->base + _op_25284);
    if (IS_SEQUENCE(_14161)){
            _14162 = SEQ_PTR(_14161)->length;
    }
    else {
        _14162 = 1;
    }
    _14161 = NOVALUE;
    if (_14162 == 0)
    {
        _14162 = NOVALUE;
        goto LA; // [159] 222
    }
    else{
        _14162 = NOVALUE;
    }

    /** shift.e:414					switch op with fallthru do*/
    _0 = _op_25284;
    switch ( _0 ){ 

        /** shift.e:415						case SWITCH then*/
        case 185:
        case 193:
        case 192:
        case 202:

        /** shift.e:420							shift_switch( pc, start, amount )*/
        _65shift_switch(_pc_25283, _start_25265, _amount_25266);

        /** shift.e:421							break*/
        goto LB; // [188] 221

        /** shift.e:423						case else*/
        default:

        /** shift.e:424							int = op_info_addr[op][1]*/
        _2 = (object)SEQ_PTR(_65op_info_addr_24621);
        _14165 = (object)*(((s1_ptr)_2)->base + _op_25284);
        _2 = (object)SEQ_PTR(_14165);
        _int_25270 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (!IS_ATOM_INT(_int_25270)){
            _int_25270 = (object)DBL_PTR(_int_25270)->dbl;
        }
        _14165 = NOVALUE;

        /** shift.e:425							shift_addr( pc + int, amount, start, bound )*/
        _14167 = _pc_25283 + _int_25270;
        if ((object)((uintptr_t)_14167 + (uintptr_t)HIGH_BITS) >= 0){
            _14167 = NewDouble((eudouble)_14167);
        }
        _65shift_addr(_14167, _amount_25266, _start_25265, _bound_25267);
        _14167 = NOVALUE;
    ;}LB: 
LA: 
L9: 

    /** shift.e:430			integer size_type = op_info_size_type[op]*/
    _2 = (object)SEQ_PTR(_65op_info_size_type_24619);
    _size_type_25313 = (object)*(((s1_ptr)_2)->base + _op_25284);
    if (!IS_ATOM_INT(_size_type_25313))
    _size_type_25313 = (object)DBL_PTR(_size_type_25313)->dbl;

    /** shift.e:431			if size_type = FIXED_SIZE then*/
    if (_size_type_25313 != 1LL)
    goto LC; // [233] 254

    /** shift.e:433				pc += op_info_size[op]*/
    _2 = (object)SEQ_PTR(_65op_info_size_24620);
    _14170 = (object)*(((s1_ptr)_2)->base + _op_25284);
    if (IS_ATOM_INT(_14170)) {
        _pc_25283 = _pc_25283 + _14170;
    }
    else {
        _pc_25283 = binary_op(PLUS, _pc_25283, _14170);
    }
    _14170 = NOVALUE;
    if (!IS_ATOM_INT(_pc_25283)) {
        _1 = (object)(DBL_PTR(_pc_25283)->dbl);
        DeRefDS(_pc_25283);
        _pc_25283 = _1;
    }
    goto LD; // [251] 271
LC: 

    /** shift.e:435				pc += variable_op_size( pc, op )*/
    RefDS(_27Code_20660);
    _14172 = _65variable_op_size(_pc_25283, _op_25284, _27Code_20660);
    if (IS_ATOM_INT(_14172)) {
        _pc_25283 = _pc_25283 + _14172;
    }
    else {
        _pc_25283 = binary_op(PLUS, _pc_25283, _14172);
    }
    DeRef(_14172);
    _14172 = NOVALUE;
    if (!IS_ATOM_INT(_pc_25283)) {
        _1 = (object)(DBL_PTR(_pc_25283)->dbl);
        DeRefDS(_pc_25283);
        _pc_25283 = _1;
    }
LD: 

    /** shift.e:437		end while*/
    goto L6; // [275] 115
L7: 

    /** shift.e:438		shift_fwd_refs( start, amount )*/
    _42shift_fwd_refs(_start_25265, _amount_25266);

    /** shift.e:439		move_last_pc( amount )*/
    _45move_last_pc(_amount_25266);

    /** shift.e:440	end procedure*/
    _14161 = NOVALUE;
    DeRef(_14158);
    _14158 = NOVALUE;
    return;
    ;
}


void _65insert_code(object _code_25327, object _index_25328)
{
    object _14175 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:443		Code = splice( Code, code, index )*/
    {
        s1_ptr assign_space;
        insert_pos = _index_25328;
        if (insert_pos <= 0) {
            Concat(&_27Code_20660,_code_25327,_27Code_20660);
        }
        else if (insert_pos > SEQ_PTR(_27Code_20660)->length){
            Concat(&_27Code_20660,_27Code_20660,_code_25327);
        }
        else if (IS_SEQUENCE(_code_25327)) {
            if( _27Code_20660 != _27Code_20660 || SEQ_PTR( _27Code_20660 )->ref != 1 ){
                DeRef( _27Code_20660 );
                RefDS( _27Code_20660 );
            }
            assign_space = Add_internal_space( _27Code_20660, insert_pos,((s1_ptr)SEQ_PTR(_code_25327))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_code_25327), _27Code_20660 == _27Code_20660 );
            _27Code_20660 = MAKE_SEQ( assign_space );
        }
        else {
            if( _27Code_20660 == _27Code_20660 && SEQ_PTR( _27Code_20660 )->ref == 1 ){
                _27Code_20660 = Insert( _27Code_20660, _code_25327, insert_pos);
            }
            else {
                DeRef( _27Code_20660 );
                RefDS( _27Code_20660 );
                _27Code_20660 = Insert( _27Code_20660, _code_25327, insert_pos);
            }
        }
    }

    /** shift.e:444		shift( index, length( code ) )*/
    if (IS_SEQUENCE(_code_25327)){
            _14175 = SEQ_PTR(_code_25327)->length;
    }
    else {
        _14175 = 1;
    }
    _65shift(_index_25328, _14175, _index_25328);
    _14175 = NOVALUE;

    /** shift.e:445	end procedure*/
    DeRefDSi(_code_25327);
    return;
    ;
}


void _65replace_code(object _code_25335, object _start_25336, object _finish_25337)
{
    object _14180 = NOVALUE;
    object _14179 = NOVALUE;
    object _14178 = NOVALUE;
    object _14177 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_25336)) {
        _1 = (object)(DBL_PTR(_start_25336)->dbl);
        DeRefDS(_start_25336);
        _start_25336 = _1;
    }
    if (!IS_ATOM_INT(_finish_25337)) {
        _1 = (object)(DBL_PTR(_finish_25337)->dbl);
        DeRefDS(_finish_25337);
        _finish_25337 = _1;
    }

    /** shift.e:448		Code = replace( Code, code, start, finish )*/
    {
        intptr_t p1 = _27Code_20660;
        intptr_t p2 = _code_25335;
        intptr_t p3 = _start_25336;
        intptr_t p4 = _finish_25337;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_27Code_20660;
        Replace( &replace_params );
    }

    /** shift.e:449		shift( start, length( code ) - (finish - start + 1), finish )*/
    if (IS_SEQUENCE(_code_25335)){
            _14177 = SEQ_PTR(_code_25335)->length;
    }
    else {
        _14177 = 1;
    }
    _14178 = _finish_25337 - _start_25336;
    if ((object)((uintptr_t)_14178 +(uintptr_t) HIGH_BITS) >= 0){
        _14178 = NewDouble((eudouble)_14178);
    }
    if (IS_ATOM_INT(_14178)) {
        _14179 = _14178 + 1;
        if (_14179 > MAXINT){
            _14179 = NewDouble((eudouble)_14179);
        }
    }
    else
    _14179 = binary_op(PLUS, 1, _14178);
    DeRef(_14178);
    _14178 = NOVALUE;
    if (IS_ATOM_INT(_14179)) {
        _14180 = _14177 - _14179;
        if ((object)((uintptr_t)_14180 +(uintptr_t) HIGH_BITS) >= 0){
            _14180 = NewDouble((eudouble)_14180);
        }
    }
    else {
        _14180 = NewDouble((eudouble)_14177 - DBL_PTR(_14179)->dbl);
    }
    _14177 = NOVALUE;
    DeRef(_14179);
    _14179 = NOVALUE;
    _65shift(_start_25336, _14180, _finish_25337);
    _14180 = NOVALUE;

    /** shift.e:450	end procedure*/
    DeRefDS(_code_25335);
    return;
    ;
}


object _65current_op(object _pc_25347, object _code_25348)
{
    object _14188 = NOVALUE;
    object _14187 = NOVALUE;
    object _14186 = NOVALUE;
    object _14185 = NOVALUE;
    object _14184 = NOVALUE;
    object _14182 = NOVALUE;
    object _14181 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:456		if pc > length(code) or pc < 1 then*/
    if (IS_SEQUENCE(_code_25348)){
            _14181 = SEQ_PTR(_code_25348)->length;
    }
    else {
        _14181 = 1;
    }
    _14182 = (_pc_25347 > _14181);
    _14181 = NOVALUE;
    if (_14182 != 0) {
        goto L1; // [14] 27
    }
    _14184 = (_pc_25347 < 1LL);
    if (_14184 == 0)
    {
        DeRef(_14184);
        _14184 = NOVALUE;
        goto L2; // [23] 34
    }
    else{
        DeRef(_14184);
        _14184 = NOVALUE;
    }
L1: 

    /** shift.e:457			return {}*/
    RefDS(_5);
    DeRefDS(_code_25348);
    DeRef(_14182);
    _14182 = NOVALUE;
    return _5;
L2: 

    /** shift.e:459		return code[pc..pc-1+op_size( pc, code )]*/
    _14185 = _pc_25347 - 1LL;
    if ((object)((uintptr_t)_14185 +(uintptr_t) HIGH_BITS) >= 0){
        _14185 = NewDouble((eudouble)_14185);
    }
    RefDS(_code_25348);
    _14186 = _65op_size(_pc_25347, _code_25348);
    if (IS_ATOM_INT(_14185) && IS_ATOM_INT(_14186)) {
        _14187 = _14185 + _14186;
    }
    else {
        _14187 = binary_op(PLUS, _14185, _14186);
    }
    DeRef(_14185);
    _14185 = NOVALUE;
    DeRef(_14186);
    _14186 = NOVALUE;
    rhs_slice_target = (object_ptr)&_14188;
    RHS_Slice(_code_25348, _pc_25347, _14187);
    DeRefDS(_code_25348);
    DeRef(_14187);
    _14187 = NOVALUE;
    DeRef(_14182);
    _14182 = NOVALUE;
    return _14188;
    ;
}


object _65get_ops(object _pc_25362, object _offset_25363, object _num_ops_25364, object _code_25365)
{
    object _sign_25368 = NOVALUE;
    object _ops_25377 = NOVALUE;
    object _opx_25379 = NOVALUE;
    object _14205 = NOVALUE;
    object _14204 = NOVALUE;
    object _14200 = NOVALUE;
    object _14199 = NOVALUE;
    object _14198 = NOVALUE;
    object _14197 = NOVALUE;
    object _14196 = NOVALUE;
    object _14195 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:466		integer sign = offset >= 0*/
    _sign_25368 = (_offset_25363 >= 0LL);

    /** shift.e:467		if not sign then*/
    if (_sign_25368 != 0)
    goto L1; // [17] 33

    /** shift.e:468			offset = -offset*/
    _offset_25363 = - _offset_25363;

    /** shift.e:469			sign = -1*/
    _sign_25368 = -1LL;
L1: 

    /** shift.e:472		while offset do*/
L2: 
    if (_offset_25363 == 0)
    {
        goto L3; // [38] 63
    }
    else{
    }

    /** shift.e:473			pc = advance( pc )*/
    RefDS(_27Code_20660);
    _pc_25362 = _65advance(_pc_25362, _27Code_20660);
    if (!IS_ATOM_INT(_pc_25362)) {
        _1 = (object)(DBL_PTR(_pc_25362)->dbl);
        DeRefDS(_pc_25362);
        _pc_25362 = _1;
    }

    /** shift.e:474			offset -= sign*/
    _offset_25363 = _offset_25363 - _sign_25368;

    /** shift.e:475		end while*/
    goto L2; // [60] 38
L3: 

    /** shift.e:477		sequence ops = repeat( 0, num_ops )*/
    DeRef(_ops_25377);
    _ops_25377 = Repeat(0LL, _num_ops_25364);

    /** shift.e:478		integer opx = 1*/
    _opx_25379 = 1LL;

    /** shift.e:479		while num_ops and pc <= length(code) do*/
L4: 
    if (_num_ops_25364 == 0) {
        goto L5; // [79] 137
    }
    if (IS_SEQUENCE(_code_25365)){
            _14196 = SEQ_PTR(_code_25365)->length;
    }
    else {
        _14196 = 1;
    }
    _14197 = (_pc_25362 <= _14196);
    _14196 = NOVALUE;
    if (_14197 == 0)
    {
        DeRef(_14197);
        _14197 = NOVALUE;
        goto L5; // [91] 137
    }
    else{
        DeRef(_14197);
        _14197 = NOVALUE;
    }

    /** shift.e:480			ops[opx] = current_op( pc )*/
    RefDS(_27Code_20660);
    _14198 = _65current_op(_pc_25362, _27Code_20660);
    _2 = (object)SEQ_PTR(_ops_25377);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _ops_25377 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _opx_25379);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14198;
    if( _1 != _14198 ){
        DeRef(_1);
    }
    _14198 = NOVALUE;

    /** shift.e:481			pc += length( ops[opx] )*/
    _2 = (object)SEQ_PTR(_ops_25377);
    _14199 = (object)*(((s1_ptr)_2)->base + _opx_25379);
    if (IS_SEQUENCE(_14199)){
            _14200 = SEQ_PTR(_14199)->length;
    }
    else {
        _14200 = 1;
    }
    _14199 = NOVALUE;
    _pc_25362 = _pc_25362 + _14200;
    _14200 = NOVALUE;

    /** shift.e:482			opx += 1*/
    _opx_25379 = _opx_25379 + 1;

    /** shift.e:483			num_ops -= 1*/
    _num_ops_25364 = _num_ops_25364 - 1LL;

    /** shift.e:484		end while*/
    goto L4; // [134] 79
L5: 

    /** shift.e:485		if num_ops then*/
    if (_num_ops_25364 == 0)
    {
        goto L6; // [139] 156
    }
    else{
    }

    /** shift.e:486			ops = head( ops, length( ops ) - num_ops )*/
    if (IS_SEQUENCE(_ops_25377)){
            _14204 = SEQ_PTR(_ops_25377)->length;
    }
    else {
        _14204 = 1;
    }
    _14205 = _14204 - _num_ops_25364;
    if ((object)((uintptr_t)_14205 +(uintptr_t) HIGH_BITS) >= 0){
        _14205 = NewDouble((eudouble)_14205);
    }
    _14204 = NOVALUE;
    {
        int len = SEQ_PTR(_ops_25377)->length;
        int size = (IS_ATOM_INT(_14205)) ? _14205 : (object)(DBL_PTR(_14205)->dbl);
        if (size <= 0){
            DeRef( _ops_25377 );
            _ops_25377 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_ops_25377);
            DeRef(_ops_25377);
            _ops_25377 = _ops_25377;
        }
        else{
            Head(SEQ_PTR(_ops_25377),size+1,&_ops_25377);
        }
    }
    DeRef(_14205);
    _14205 = NOVALUE;
L6: 

    /** shift.e:488		return ops*/
    DeRefDS(_code_25365);
    _14199 = NOVALUE;
    return _ops_25377;
    ;
}


object _65find_ops(object _pc_25397, object _op_25398, object _code_25399)
{
    object _ops_25402 = NOVALUE;
    object _found_op_25406 = NOVALUE;
    object _14214 = NOVALUE;
    object _14212 = NOVALUE;
    object _14210 = NOVALUE;
    object _14207 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:492		sequence ops = {}*/
    RefDS(_5);
    DeRef(_ops_25402);
    _ops_25402 = _5;

    /** shift.e:493		while pc <= length(code) do*/
L1: 
    if (IS_SEQUENCE(_code_25399)){
            _14207 = SEQ_PTR(_code_25399)->length;
    }
    else {
        _14207 = 1;
    }
    if (_pc_25397 > _14207)
    goto L2; // [22] 74

    /** shift.e:494			sequence found_op = current_op( pc )*/
    RefDS(_27Code_20660);
    _0 = _found_op_25406;
    _found_op_25406 = _65current_op(_pc_25397, _27Code_20660);
    DeRef(_0);

    /** shift.e:495			if found_op[1] = op then*/
    _2 = (object)SEQ_PTR(_found_op_25406);
    _14210 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _14210, _op_25398)){
        _14210 = NOVALUE;
        goto L3; // [43] 58
    }
    _14210 = NOVALUE;

    /** shift.e:496				ops = append( ops, { pc, found_op } )*/
    RefDS(_found_op_25406);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _pc_25397;
    ((intptr_t *)_2)[2] = _found_op_25406;
    _14212 = MAKE_SEQ(_1);
    RefDS(_14212);
    Append(&_ops_25402, _ops_25402, _14212);
    DeRefDS(_14212);
    _14212 = NOVALUE;
L3: 

    /** shift.e:498			pc += length( found_op )*/
    if (IS_SEQUENCE(_found_op_25406)){
            _14214 = SEQ_PTR(_found_op_25406)->length;
    }
    else {
        _14214 = 1;
    }
    _pc_25397 = _pc_25397 + _14214;
    _14214 = NOVALUE;
    DeRefDS(_found_op_25406);
    _found_op_25406 = NOVALUE;

    /** shift.e:499		end while*/
    goto L1; // [71] 19
L2: 

    /** shift.e:500		return ops*/
    DeRefDS(_code_25399);
    return _ops_25402;
    ;
}


object _65get_target_sym(object _opseq_25418)
{
    object _op_25422 = NOVALUE;
    object _info_25424 = NOVALUE;
    object _targets_25440 = NOVALUE;
    object _sub_25455 = NOVALUE;
    object _14246 = NOVALUE;
    object _14245 = NOVALUE;
    object _14244 = NOVALUE;
    object _14243 = NOVALUE;
    object _14242 = NOVALUE;
    object _14241 = NOVALUE;
    object _14240 = NOVALUE;
    object _14238 = NOVALUE;
    object _14234 = NOVALUE;
    object _14233 = NOVALUE;
    object _14232 = NOVALUE;
    object _14231 = NOVALUE;
    object _14229 = NOVALUE;
    object _14228 = NOVALUE;
    object _14227 = NOVALUE;
    object _14226 = NOVALUE;
    object _14223 = NOVALUE;
    object _14222 = NOVALUE;
    object _14220 = NOVALUE;
    object _14216 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:509		if not length( opseq ) then*/
    if (IS_SEQUENCE(_opseq_25418)){
            _14216 = SEQ_PTR(_opseq_25418)->length;
    }
    else {
        _14216 = 1;
    }
    if (_14216 != 0)
    goto L1; // [8] 18
    _14216 = NOVALUE;

    /** shift.e:510			return 0*/
    DeRefDS(_opseq_25418);
    DeRef(_info_25424);
    return 0LL;
L1: 

    /** shift.e:512		integer op = opseq[1]*/
    _2 = (object)SEQ_PTR(_opseq_25418);
    _op_25422 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_op_25422))
    _op_25422 = (object)DBL_PTR(_op_25422)->dbl;

    /** shift.e:513		sequence info = op_info[op]*/
    DeRef(_info_25424);
    _2 = (object)SEQ_PTR(_65op_info_24613);
    _info_25424 = (object)*(((s1_ptr)_2)->base + _op_25422);
    Ref(_info_25424);

    /** shift.e:515		if info[OP_SIZE_TYPE] = FIXED_SIZE then*/
    _2 = (object)SEQ_PTR(_info_25424);
    _14220 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _14220, 1LL)){
        _14220 = NOVALUE;
        goto L2; // [40] 157
    }
    _14220 = NOVALUE;

    /** shift.e:516			switch length( info[OP_TARGET] ) do*/
    _2 = (object)SEQ_PTR(_info_25424);
    _14222 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_SEQUENCE(_14222)){
            _14223 = SEQ_PTR(_14222)->length;
    }
    else {
        _14223 = 1;
    }
    _14222 = NOVALUE;
    _0 = _14223;
    _14223 = NOVALUE;
    switch ( _0 ){ 

        /** shift.e:517				case 0 then*/
        case 0:

        /** shift.e:518					break*/
        goto L3; // [64] 152
        goto L3; // [66] 152

        /** shift.e:520				case 1 then*/
        case 1:

        /** shift.e:521					return opseq[info[OP_TARGET][1]+1]*/
        _2 = (object)SEQ_PTR(_info_25424);
        _14226 = (object)*(((s1_ptr)_2)->base + 4LL);
        _2 = (object)SEQ_PTR(_14226);
        _14227 = (object)*(((s1_ptr)_2)->base + 1LL);
        _14226 = NOVALUE;
        if (IS_ATOM_INT(_14227)) {
            _14228 = _14227 + 1;
        }
        else
        _14228 = binary_op(PLUS, 1, _14227);
        _14227 = NOVALUE;
        _2 = (object)SEQ_PTR(_opseq_25418);
        if (!IS_ATOM_INT(_14228)){
            _14229 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14228)->dbl));
        }
        else{
            _14229 = (object)*(((s1_ptr)_2)->base + _14228);
        }
        Ref(_14229);
        DeRefDS(_opseq_25418);
        DeRefDS(_info_25424);
        DeRef(_14228);
        _14228 = NOVALUE;
        _14222 = NOVALUE;
        return _14229;
        goto L3; // [94] 152

        /** shift.e:523				case else*/
        default:

        /** shift.e:524					sequence targets = info[OP_TARGET]*/
        DeRef(_targets_25440);
        _2 = (object)SEQ_PTR(_info_25424);
        _targets_25440 = (object)*(((s1_ptr)_2)->base + 4LL);
        Ref(_targets_25440);

        /** shift.e:525					for i = 1 to length( targets ) do*/
        if (IS_SEQUENCE(_targets_25440)){
                _14231 = SEQ_PTR(_targets_25440)->length;
        }
        else {
            _14231 = 1;
        }
        {
            object _i_25443;
            _i_25443 = 1LL;
L4: 
            if (_i_25443 > _14231){
                goto L5; // [113] 145
            }

            /** shift.e:526						targets[i] = opseq[targets[i] + 1]*/
            _2 = (object)SEQ_PTR(_targets_25440);
            _14232 = (object)*(((s1_ptr)_2)->base + _i_25443);
            if (IS_ATOM_INT(_14232)) {
                _14233 = _14232 + 1;
            }
            else
            _14233 = binary_op(PLUS, 1, _14232);
            _14232 = NOVALUE;
            _2 = (object)SEQ_PTR(_opseq_25418);
            if (!IS_ATOM_INT(_14233)){
                _14234 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14233)->dbl));
            }
            else{
                _14234 = (object)*(((s1_ptr)_2)->base + _14233);
            }
            Ref(_14234);
            _2 = (object)SEQ_PTR(_targets_25440);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _targets_25440 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _i_25443);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _14234;
            if( _1 != _14234 ){
                DeRef(_1);
            }
            _14234 = NOVALUE;

            /** shift.e:527					end for*/
            _i_25443 = _i_25443 + 1LL;
            goto L4; // [140] 120
L5: 
            ;
        }

        /** shift.e:529					return targets*/
        DeRefDS(_opseq_25418);
        DeRef(_info_25424);
        DeRef(_14228);
        _14228 = NOVALUE;
        _14229 = NOVALUE;
        _14222 = NOVALUE;
        DeRef(_14233);
        _14233 = NOVALUE;
        return _targets_25440;
    ;}L3: 
    DeRef(_targets_25440);
    _targets_25440 = NOVALUE;
    goto L6; // [154] 253
L2: 

    /** shift.e:535			switch op do*/
    _0 = _op_25422;
    switch ( _0 ){ 

        /** shift.e:536				case PROC, PROC_TAIL then*/
        case 27:
        case 203:

        /** shift.e:537					symtab_index sub = opseq[2]*/
        _2 = (object)SEQ_PTR(_opseq_25418);
        _sub_25455 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_sub_25455)){
            _sub_25455 = (object)DBL_PTR(_sub_25455)->dbl;
        }

        /** shift.e:538					if sym_token( sub ) = FUNC then*/
        _14238 = _53sym_token(_sub_25455);
        if (binary_op_a(NOTEQ, _14238, 501LL)){
            DeRef(_14238);
            _14238 = NOVALUE;
            goto L7; // [186] 204
        }
        DeRef(_14238);
        _14238 = NOVALUE;

        /** shift.e:539						return opseq[$]*/
        if (IS_SEQUENCE(_opseq_25418)){
                _14240 = SEQ_PTR(_opseq_25418)->length;
        }
        else {
            _14240 = 1;
        }
        _2 = (object)SEQ_PTR(_opseq_25418);
        _14241 = (object)*(((s1_ptr)_2)->base + _14240);
        Ref(_14241);
        DeRefDS(_opseq_25418);
        DeRef(_info_25424);
        DeRef(_14228);
        _14228 = NOVALUE;
        _14229 = NOVALUE;
        _14222 = NOVALUE;
        DeRef(_14233);
        _14233 = NOVALUE;
        return _14241;
L7: 
        goto L8; // [206] 252

        /** shift.e:542				case FUNC_FORWARD then*/
        case 196:

        /** shift.e:543					return opseq[$]*/
        if (IS_SEQUENCE(_opseq_25418)){
                _14242 = SEQ_PTR(_opseq_25418)->length;
        }
        else {
            _14242 = 1;
        }
        _2 = (object)SEQ_PTR(_opseq_25418);
        _14243 = (object)*(((s1_ptr)_2)->base + _14242);
        Ref(_14243);
        DeRefDS(_opseq_25418);
        DeRef(_info_25424);
        DeRef(_14228);
        _14228 = NOVALUE;
        _14229 = NOVALUE;
        _14222 = NOVALUE;
        _14241 = NOVALUE;
        DeRef(_14233);
        _14233 = NOVALUE;
        return _14243;
        goto L8; // [225] 252

        /** shift.e:545				case RIGHT_BRACE_N, CONCAT_N then*/
        case 31:
        case 157:

        /** shift.e:546					return opseq[opseq[2]+2]*/
        _2 = (object)SEQ_PTR(_opseq_25418);
        _14244 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (IS_ATOM_INT(_14244)) {
            _14245 = _14244 + 2LL;
        }
        else {
            _14245 = binary_op(PLUS, _14244, 2LL);
        }
        _14244 = NOVALUE;
        _2 = (object)SEQ_PTR(_opseq_25418);
        if (!IS_ATOM_INT(_14245)){
            _14246 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14245)->dbl));
        }
        else{
            _14246 = (object)*(((s1_ptr)_2)->base + _14245);
        }
        Ref(_14246);
        DeRefDS(_opseq_25418);
        DeRef(_info_25424);
        DeRef(_14228);
        _14228 = NOVALUE;
        _14243 = NOVALUE;
        DeRef(_14245);
        _14245 = NOVALUE;
        _14229 = NOVALUE;
        _14222 = NOVALUE;
        _14241 = NOVALUE;
        DeRef(_14233);
        _14233 = NOVALUE;
        return _14246;
    ;}L8: 
L6: 

    /** shift.e:551		return 0*/
    DeRefDS(_opseq_25418);
    DeRef(_info_25424);
    DeRef(_14228);
    _14228 = NOVALUE;
    _14243 = NOVALUE;
    DeRef(_14245);
    _14245 = NOVALUE;
    _14229 = NOVALUE;
    _14222 = NOVALUE;
    _14241 = NOVALUE;
    _14246 = NOVALUE;
    DeRef(_14233);
    _14233 = NOVALUE;
    return 0LL;
    ;
}



// 0x00134926
