// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _53hashfn(object _name_47242)
{
    object _len_47243 = NOVALUE;
    object _val_47244 = NOVALUE;
    object _int_47245 = NOVALUE;
    object _24575 = NOVALUE;
    object _24574 = NOVALUE;
    object _24571 = NOVALUE;
    object _24570 = NOVALUE;
    object _24559 = NOVALUE;
    object _24555 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:49		len = length(name)*/
    if (IS_SEQUENCE(_name_47242)){
            _len_47243 = SEQ_PTR(_name_47242)->length;
    }
    else {
        _len_47243 = 1;
    }

    /** symtab.e:51		val = name[1]*/
    _2 = (object)SEQ_PTR(_name_47242);
    _val_47244 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_val_47244))
    _val_47244 = (object)DBL_PTR(_val_47244)->dbl;

    /** symtab.e:52		int = name[$]*/
    if (IS_SEQUENCE(_name_47242)){
            _24555 = SEQ_PTR(_name_47242)->length;
    }
    else {
        _24555 = 1;
    }
    _2 = (object)SEQ_PTR(_name_47242);
    _int_47245 = (object)*(((s1_ptr)_2)->base + _24555);
    if (!IS_ATOM_INT(_int_47245))
    _int_47245 = (object)DBL_PTR(_int_47245)->dbl;

    /** symtab.e:53		int *= 256*/
    _int_47245 = _int_47245 * 256LL;

    /** symtab.e:54		val *= 2*/
    _val_47244 = _val_47244 + _val_47244;

    /** symtab.e:55		val += int + len*/
    _24559 = _int_47245 + _len_47243;
    if ((object)((uintptr_t)_24559 + (uintptr_t)HIGH_BITS) >= 0){
        _24559 = NewDouble((eudouble)_24559);
    }
    if (IS_ATOM_INT(_24559)) {
        _val_47244 = _val_47244 + _24559;
    }
    else {
        _val_47244 = NewDouble((eudouble)_val_47244 + DBL_PTR(_24559)->dbl);
    }
    DeRef(_24559);
    _24559 = NOVALUE;
    if (!IS_ATOM_INT(_val_47244)) {
        _1 = (object)(DBL_PTR(_val_47244)->dbl);
        DeRefDS(_val_47244);
        _val_47244 = _1;
    }

    /** symtab.e:57		if len = 3 then*/
    if (_len_47243 != 3LL)
    goto L1; // [51] 78

    /** symtab.e:58			val *= 32*/
    _val_47244 = _val_47244 * 32LL;

    /** symtab.e:59			int = name[2]*/
    _2 = (object)SEQ_PTR(_name_47242);
    _int_47245 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_int_47245))
    _int_47245 = (object)DBL_PTR(_int_47245)->dbl;

    /** symtab.e:60			val += int*/
    _val_47244 = _val_47244 + _int_47245;
    goto L2; // [75] 133
L1: 

    /** symtab.e:61		elsif len > 3 then*/
    if (_len_47243 <= 3LL)
    goto L3; // [80] 132

    /** symtab.e:62			val *= 32*/
    _val_47244 = _val_47244 * 32LL;

    /** symtab.e:63			int = name[2]*/
    _2 = (object)SEQ_PTR(_name_47242);
    _int_47245 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_int_47245))
    _int_47245 = (object)DBL_PTR(_int_47245)->dbl;

    /** symtab.e:64			val += int*/
    _val_47244 = _val_47244 + _int_47245;

    /** symtab.e:66			val *= 32*/
    _val_47244 = _val_47244 * 32LL;

    /** symtab.e:67			int = name[$-1]*/
    if (IS_SEQUENCE(_name_47242)){
            _24570 = SEQ_PTR(_name_47242)->length;
    }
    else {
        _24570 = 1;
    }
    _24571 = _24570 - 1LL;
    _24570 = NOVALUE;
    _2 = (object)SEQ_PTR(_name_47242);
    _int_47245 = (object)*(((s1_ptr)_2)->base + _24571);
    if (!IS_ATOM_INT(_int_47245))
    _int_47245 = (object)DBL_PTR(_int_47245)->dbl;

    /** symtab.e:68			val += int*/
    _val_47244 = _val_47244 + _int_47245;
L3: 
L2: 

    /** symtab.e:70		return remainder(val, NBUCKETS) + 1*/
    _24574 = (_val_47244 % 2003LL);
    _24575 = _24574 + 1;
    _24574 = NOVALUE;
    DeRefDS(_name_47242);
    DeRef(_24571);
    _24571 = NOVALUE;
    return _24575;
    ;
}


void _53remove_symbol(object _sym_47274)
{
    object _hash_47275 = NOVALUE;
    object _st_ptr_47276 = NOVALUE;
    object _24590 = NOVALUE;
    object _24589 = NOVALUE;
    object _24587 = NOVALUE;
    object _24586 = NOVALUE;
    object _24585 = NOVALUE;
    object _24583 = NOVALUE;
    object _24581 = NOVALUE;
    object _24580 = NOVALUE;
    object _24579 = NOVALUE;
    object _24576 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:79		hash = SymTab[sym][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24576 = (object)*(((s1_ptr)_2)->base + _sym_47274);
    _2 = (object)SEQ_PTR(_24576);
    _hash_47275 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (!IS_ATOM_INT(_hash_47275)){
        _hash_47275 = (object)DBL_PTR(_hash_47275)->dbl;
    }
    _24576 = NOVALUE;

    /** symtab.e:80		st_ptr = buckets[hash]*/
    _2 = (object)SEQ_PTR(_53buckets_47223);
    _st_ptr_47276 = (object)*(((s1_ptr)_2)->base + _hash_47275);
    if (!IS_ATOM_INT(_st_ptr_47276))
    _st_ptr_47276 = (object)DBL_PTR(_st_ptr_47276)->dbl;

    /** symtab.e:82		while st_ptr and st_ptr != sym do*/
L1: 
    if (_st_ptr_47276 == 0) {
        goto L2; // [32] 65
    }
    _24580 = (_st_ptr_47276 != _sym_47274);
    if (_24580 == 0)
    {
        DeRef(_24580);
        _24580 = NOVALUE;
        goto L2; // [41] 65
    }
    else{
        DeRef(_24580);
        _24580 = NOVALUE;
    }

    /** symtab.e:83			st_ptr = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24581 = (object)*(((s1_ptr)_2)->base + _st_ptr_47276);
    _2 = (object)SEQ_PTR(_24581);
    _st_ptr_47276 = (object)*(((s1_ptr)_2)->base + 9LL);
    if (!IS_ATOM_INT(_st_ptr_47276)){
        _st_ptr_47276 = (object)DBL_PTR(_st_ptr_47276)->dbl;
    }
    _24581 = NOVALUE;

    /** symtab.e:84		end while*/
    goto L1; // [62] 32
L2: 

    /** symtab.e:86		if st_ptr then*/
    if (_st_ptr_47276 == 0)
    {
        goto L3; // [67] 134
    }
    else{
    }

    /** symtab.e:87			if st_ptr = buckets[hash] then*/
    _2 = (object)SEQ_PTR(_53buckets_47223);
    _24583 = (object)*(((s1_ptr)_2)->base + _hash_47275);
    if (binary_op_a(NOTEQ, _st_ptr_47276, _24583)){
        _24583 = NOVALUE;
        goto L4; // [78] 105
    }
    _24583 = NOVALUE;

    /** symtab.e:89				buckets[hash] = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24585 = (object)*(((s1_ptr)_2)->base + _st_ptr_47276);
    _2 = (object)SEQ_PTR(_24585);
    _24586 = (object)*(((s1_ptr)_2)->base + 9LL);
    _24585 = NOVALUE;
    Ref(_24586);
    _2 = (object)SEQ_PTR(_53buckets_47223);
    _2 = (object)(((s1_ptr)_2)->base + _hash_47275);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24586;
    if( _1 != _24586 ){
        DeRef(_1);
    }
    _24586 = NOVALUE;
    goto L5; // [102] 133
L4: 

    /** symtab.e:92				SymTab[st_ptr][S_SAMEHASH] = SymTab[sym][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_st_ptr_47276 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24589 = (object)*(((s1_ptr)_2)->base + _sym_47274);
    _2 = (object)SEQ_PTR(_24589);
    _24590 = (object)*(((s1_ptr)_2)->base + 9LL);
    _24589 = NOVALUE;
    Ref(_24590);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24590;
    if( _1 != _24590 ){
        DeRef(_1);
    }
    _24590 = NOVALUE;
    _24587 = NOVALUE;
L5: 
L3: 

    /** symtab.e:95	end procedure*/
    return;
    ;
}


object _53NewBasicEntry(object _name_47308, object _varnum_47309, object _scope_47310, object _token_47311, object _hashval_47312, object _samehash_47314, object _type_sym_47316)
{
    object _new_47317 = NOVALUE;
    object _24599 = NOVALUE;
    object _24597 = NOVALUE;
    object _24596 = NOVALUE;
    object _24595 = NOVALUE;
    object _24594 = NOVALUE;
    object _24593 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:105		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L1; // [19] 33
    }
    else{
    }

    /** symtab.e:106			new = repeat(0, SIZEOF_ROUTINE_ENTRY)*/
    DeRef(_new_47317);
    _new_47317 = Repeat(0LL, _27SIZEOF_ROUTINE_ENTRY_20335);
    goto L2; // [30] 42
L1: 

    /** symtab.e:108			new = repeat(0, SIZEOF_VAR_ENTRY)*/
    DeRef(_new_47317);
    _new_47317 = Repeat(0LL, _27SIZEOF_VAR_ENTRY_20338);
L2: 

    /** symtab.e:111		new[S_NEXT] = 0*/
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:112		new[S_NAME] = name*/
    RefDS(_name_47308);
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_NAME_20209))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_NAME_20209);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _name_47308;
    DeRef(_1);

    /** symtab.e:113		new[S_SCOPE] = scope*/
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _scope_47310;
    DeRef(_1);

    /** symtab.e:114		new[S_MODE] = M_NORMAL*/
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);

    /** symtab.e:115		new[S_USAGE] = U_UNUSED*/
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:116		new[S_FILE_NO] = current_file_no*/
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_FILE_NO_20205))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27current_file_no_20571;
    DeRef(_1);

    /** symtab.e:118		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L3; // [102] 327
    }
    else{
    }

    /** symtab.e:120			new[S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);

    /** symtab.e:121			new[S_GTYPE_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 38LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:123			new[S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);

    /** symtab.e:124			new[S_SEQ_ELEM_NEW] = TYPE_NULL -- starting point for ORing*/
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:126			new[S_ARG_TYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 43LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);

    /** symtab.e:127			new[S_ARG_TYPE_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 44LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:128			new[S_ARG_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 45LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);

    /** symtab.e:129			new[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 46LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:131			new[S_ARG_MIN] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 47LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);

    /** symtab.e:132			new[S_ARG_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_27NOVALUE_20426)) {
        if ((uintptr_t)_27NOVALUE_20426 == (uintptr_t)HIGH_BITS){
            _24593 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24593 = - _27NOVALUE_20426;
        }
    }
    else {
        _24593 = unary_op(UMINUS, _27NOVALUE_20426);
    }
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 49LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24593;
    if( _1 != _24593 ){
        DeRef(_1);
    }
    _24593 = NOVALUE;

    /** symtab.e:134			new[S_ARG_SEQ_LEN] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 51LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);

    /** symtab.e:135			new[S_ARG_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_27NOVALUE_20426)) {
        if ((uintptr_t)_27NOVALUE_20426 == (uintptr_t)HIGH_BITS){
            _24594 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24594 = - _27NOVALUE_20426;
        }
    }
    else {
        _24594 = unary_op(UMINUS, _27NOVALUE_20426);
    }
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 52LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24594;
    if( _1 != _24594 ){
        DeRef(_1);
    }
    _24594 = NOVALUE;

    /** symtab.e:137			new[S_SEQ_LEN] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);

    /** symtab.e:138			new[S_SEQ_LEN_NEW] = -NOVALUE -- no idea yet*/
    if (IS_ATOM_INT(_27NOVALUE_20426)) {
        if ((uintptr_t)_27NOVALUE_20426 == (uintptr_t)HIGH_BITS){
            _24595 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24595 = - _27NOVALUE_20426;
        }
    }
    else {
        _24595 = unary_op(UMINUS, _27NOVALUE_20426);
    }
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24595;
    if( _1 != _24595 ){
        DeRef(_1);
    }
    _24595 = NOVALUE;

    /** symtab.e:140			new[S_NREFS] = 0*/
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:141			new[S_ONE_REF] = TRUE          -- assume TRUE until we find otherwise*/
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 35LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _9TRUE_441;
    DeRef(_1);

    /** symtab.e:142			new[S_RI_TARGET] = 0*/
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 53LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:144			new[S_OBJ_MIN] = MININT*/
    Ref(_27MININT_20396);
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27MININT_20396;
    DeRef(_1);

    /** symtab.e:145			new[S_OBJ_MIN_NEW] = -NOVALUE -- no idea yet*/
    if (IS_ATOM_INT(_27NOVALUE_20426)) {
        if ((uintptr_t)_27NOVALUE_20426 == (uintptr_t)HIGH_BITS){
            _24596 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24596 = - _27NOVALUE_20426;
        }
    }
    else {
        _24596 = unary_op(UMINUS, _27NOVALUE_20426);
    }
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24596;
    if( _1 != _24596 ){
        DeRef(_1);
    }
    _24596 = NOVALUE;

    /** symtab.e:147			new[S_OBJ_MAX] = MAXINT*/
    Ref(_27MAXINT_20395);
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27MAXINT_20395;
    DeRef(_1);

    /** symtab.e:148			new[S_OBJ_MAX_NEW] = -NOVALUE -- missing from C code? (not needed)*/
    if (IS_ATOM_INT(_27NOVALUE_20426)) {
        if ((uintptr_t)_27NOVALUE_20426 == (uintptr_t)HIGH_BITS){
            _24597 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24597 = - _27NOVALUE_20426;
        }
    }
    else {
        _24597 = unary_op(UMINUS, _27NOVALUE_20426);
    }
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 42LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24597;
    if( _1 != _24597 ){
        DeRef(_1);
    }
    _24597 = NOVALUE;
L3: 

    /** symtab.e:151		new[S_TOKEN] = token*/
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_TOKEN_20214))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _token_47311;
    DeRef(_1);

    /** symtab.e:152		new[S_VARNUM] = varnum*/
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 16LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _varnum_47309;
    DeRef(_1);

    /** symtab.e:153		new[S_INITLEVEL] = -1*/
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1LL;
    DeRef(_1);

    /** symtab.e:154		new[S_VTYPE] = type_sym*/
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _type_sym_47316;
    DeRef(_1);

    /** symtab.e:156		new[S_HASHVAL] = hashval*/
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _hashval_47312;
    DeRef(_1);

    /** symtab.e:157		new[S_SAMEHASH] = samehash*/
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _samehash_47314;
    DeRef(_1);

    /** symtab.e:159		new[S_OBJ] = NOVALUE -- important*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_new_47317);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47317 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);

    /** symtab.e:162		SymTab = append(SymTab, new)*/
    RefDS(_new_47317);
    Append(&_28SymTab_11572, _28SymTab_11572, _new_47317);

    /** symtab.e:164		return length(SymTab)*/
    if (IS_SEQUENCE(_28SymTab_11572)){
            _24599 = SEQ_PTR(_28SymTab_11572)->length;
    }
    else {
        _24599 = 1;
    }
    DeRefDS(_name_47308);
    DeRefDS(_new_47317);
    return _24599;
    ;
}


object _53NewEntry(object _name_47396, object _varnum_47397, object _scope_47398, object _token_47399, object _hashval_47400, object _samehash_47402, object _type_sym_47404)
{
    object _new_47406 = NOVALUE;
    object _24601 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_scope_47398)) {
        _1 = (object)(DBL_PTR(_scope_47398)->dbl);
        DeRefDS(_scope_47398);
        _scope_47398 = _1;
    }
    if (!IS_ATOM_INT(_token_47399)) {
        _1 = (object)(DBL_PTR(_token_47399)->dbl);
        DeRefDS(_token_47399);
        _token_47399 = _1;
    }
    if (!IS_ATOM_INT(_samehash_47402)) {
        _1 = (object)(DBL_PTR(_samehash_47402)->dbl);
        DeRefDS(_samehash_47402);
        _samehash_47402 = _1;
    }

    /** symtab.e:171		symtab_index new = NewBasicEntry( name, varnum, scope, token, hashval, samehash, type_sym )*/
    RefDS(_name_47396);
    _new_47406 = _53NewBasicEntry(_name_47396, _varnum_47397, _scope_47398, _token_47399, _hashval_47400, _samehash_47402, _type_sym_47404);
    if (!IS_ATOM_INT(_new_47406)) {
        _1 = (object)(DBL_PTR(_new_47406)->dbl);
        DeRefDS(_new_47406);
        _new_47406 = _1;
    }

    /** symtab.e:174		if last_sym then*/
    if (_53last_sym_47236 == 0)
    {
        goto L1; // [33] 54
    }
    else{
    }

    /** symtab.e:175			SymTab[last_sym][S_NEXT] = new*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_53last_sym_47236 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _new_47406;
    DeRef(_1);
    _24601 = NOVALUE;
L1: 

    /** symtab.e:177		last_sym = new*/
    _53last_sym_47236 = _new_47406;

    /** symtab.e:178		if type_sym < 0 then*/
    if (_type_sym_47404 >= 0LL)
    goto L2; // [63] 76

    /** symtab.e:179			register_forward_type( last_sym, type_sym )*/
    _42register_forward_type(_53last_sym_47236, _type_sym_47404);
L2: 

    /** symtab.e:181		return last_sym*/
    DeRefDS(_name_47396);
    return _53last_sym_47236;
    ;
}


object _53tmp_alloc()
{
    object _new_entry_47421 = NOVALUE;
    object _24615 = NOVALUE;
    object _24613 = NOVALUE;
    object _24610 = NOVALUE;
    object _24607 = NOVALUE;
    object _24606 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:188		sequence new_entry = repeat( 0, SIZEOF_TEMP_ENTRY )*/
    DeRef(_new_entry_47421);
    _new_entry_47421 = Repeat(0LL, _27SIZEOF_TEMP_ENTRY_20344);

    /** symtab.e:192		new_entry[S_USAGE] = T_UNKNOWN*/
    _2 = (object)SEQ_PTR(_new_entry_47421);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47421 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    *(intptr_t *)_2 = 4LL;

    /** symtab.e:194		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L1; // [23] 132
    }
    else{
    }

    /** symtab.e:195			new_entry[S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_entry_47421);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47421 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    *(intptr_t *)_2 = 16LL;

    /** symtab.e:196			new_entry[S_OBJ_MIN] = MININT*/
    Ref(_27MININT_20396);
    _2 = (object)SEQ_PTR(_new_entry_47421);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47421 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    *(intptr_t *)_2 = _27MININT_20396;

    /** symtab.e:197			new_entry[S_OBJ_MAX] = MAXINT*/
    Ref(_27MAXINT_20395);
    _2 = (object)SEQ_PTR(_new_entry_47421);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47421 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27MAXINT_20395;
    DeRef(_1);

    /** symtab.e:198			new_entry[S_SEQ_LEN] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_new_entry_47421);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47421 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);

    /** symtab.e:199			new_entry[S_SEQ_ELEM] = TYPE_OBJECT  -- other fields set later*/
    _2 = (object)SEQ_PTR(_new_entry_47421);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47421 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);

    /** symtab.e:200			if length(temp_name_type)+1 = 8087 then*/
    if (IS_SEQUENCE(_27temp_name_type_20654)){
            _24606 = SEQ_PTR(_27temp_name_type_20654)->length;
    }
    else {
        _24606 = 1;
    }
    _24607 = _24606 + 1;
    _24606 = NOVALUE;
    if (_24607 != 8087LL)
    goto L2; // [87] 106

    /** symtab.e:202				temp_name_type = append(temp_name_type, {0, 0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = 0LL;
    _24610 = MAKE_SEQ(_1);
    RefDS(_24610);
    Append(&_27temp_name_type_20654, _27temp_name_type_20654, _24610);
    DeRefDS(_24610);
    _24610 = NOVALUE;
L2: 

    /** symtab.e:204			temp_name_type = append(temp_name_type, TYPES_OBNL)*/
    RefDS(_54TYPES_OBNL_47054);
    Append(&_27temp_name_type_20654, _27temp_name_type_20654, _54TYPES_OBNL_47054);

    /** symtab.e:205			new_entry[S_TEMP_NAME] = length(temp_name_type)*/
    if (IS_SEQUENCE(_27temp_name_type_20654)){
            _24613 = SEQ_PTR(_27temp_name_type_20654)->length;
    }
    else {
        _24613 = 1;
    }
    _2 = (object)SEQ_PTR(_new_entry_47421);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47421 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 34LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24613;
    if( _1 != _24613 ){
        DeRef(_1);
    }
    _24613 = NOVALUE;
L1: 

    /** symtab.e:208		SymTab = append(SymTab, new_entry )*/
    RefDS(_new_entry_47421);
    Append(&_28SymTab_11572, _28SymTab_11572, _new_entry_47421);

    /** symtab.e:210		return length( SymTab )*/
    if (IS_SEQUENCE(_28SymTab_11572)){
            _24615 = SEQ_PTR(_28SymTab_11572)->length;
    }
    else {
        _24615 = 1;
    }
    DeRefDS(_new_entry_47421);
    DeRef(_24607);
    _24607 = NOVALUE;
    return _24615;
    ;
}


void _53DefinedYet(object _sym_47490)
{
    object _24635 = NOVALUE;
    object _24634 = NOVALUE;
    object _24633 = NOVALUE;
    object _24631 = NOVALUE;
    object _24630 = NOVALUE;
    object _24628 = NOVALUE;
    object _24627 = NOVALUE;
    object _24626 = NOVALUE;
    object _24625 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:230		if not find(SymTab[sym][S_SCOPE],*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24625 = (object)*(((s1_ptr)_2)->base + _sym_47490);
    _2 = (object)SEQ_PTR(_24625);
    _24626 = (object)*(((s1_ptr)_2)->base + 4LL);
    _24625 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 9LL;
    ((intptr_t*)_2)[2] = 10LL;
    ((intptr_t*)_2)[3] = 7LL;
    _24627 = MAKE_SEQ(_1);
    _24628 = find_from(_24626, _24627, 1LL);
    _24626 = NOVALUE;
    DeRefDS(_24627);
    _24627 = NOVALUE;
    if (_24628 != 0)
    goto L1; // [34] 84
    _24628 = NOVALUE;

    /** symtab.e:232			if SymTab[sym][S_FILE_NO] = current_file_no then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24630 = (object)*(((s1_ptr)_2)->base + _sym_47490);
    _2 = (object)SEQ_PTR(_24630);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _24631 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _24631 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _24630 = NOVALUE;
    if (binary_op_a(NOTEQ, _24631, _27current_file_no_20571)){
        _24631 = NOVALUE;
        goto L2; // [53] 83
    }
    _24631 = NOVALUE;

    /** symtab.e:233				CompileErr(ATTEMPT_TO_REDEFINE_1, {SymTab[sym][S_NAME]})*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24633 = (object)*(((s1_ptr)_2)->base + _sym_47490);
    _2 = (object)SEQ_PTR(_24633);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _24634 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _24634 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _24633 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24634);
    ((intptr_t*)_2)[1] = _24634;
    _24635 = MAKE_SEQ(_1);
    _24634 = NOVALUE;
    _49CompileErr(31LL, _24635, 0LL);
    _24635 = NOVALUE;
L2: 
L1: 

    /** symtab.e:236	end procedure*/
    return;
    ;
}


object _53name_ext(object _s_47518)
{
    object _24642 = NOVALUE;
    object _24641 = NOVALUE;
    object _24640 = NOVALUE;
    object _24639 = NOVALUE;
    object _24637 = NOVALUE;
    object _24636 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:241		for i = length(s) to 1 by -1 do*/
    if (IS_SEQUENCE(_s_47518)){
            _24636 = SEQ_PTR(_s_47518)->length;
    }
    else {
        _24636 = 1;
    }
    {
        object _i_47520;
        _i_47520 = _24636;
L1: 
        if (_i_47520 < 1LL){
            goto L2; // [8] 55
        }

        /** symtab.e:242			if find(s[i], "/\\:") then*/
        _2 = (object)SEQ_PTR(_s_47518);
        _24637 = (object)*(((s1_ptr)_2)->base + _i_47520);
        _24639 = find_from(_24637, _24638, 1LL);
        _24637 = NOVALUE;
        if (_24639 == 0)
        {
            _24639 = NOVALUE;
            goto L3; // [26] 48
        }
        else{
            _24639 = NOVALUE;
        }

        /** symtab.e:243				return s[i+1 .. $]*/
        _24640 = _i_47520 + 1;
        if (IS_SEQUENCE(_s_47518)){
                _24641 = SEQ_PTR(_s_47518)->length;
        }
        else {
            _24641 = 1;
        }
        rhs_slice_target = (object_ptr)&_24642;
        RHS_Slice(_s_47518, _24640, _24641);
        DeRefDS(_s_47518);
        _24640 = NOVALUE;
        return _24642;
L3: 

        /** symtab.e:245		end for*/
        _i_47520 = _i_47520 + -1LL;
        goto L1; // [50] 15
L2: 
        ;
    }

    /** symtab.e:247		return s*/
    DeRef(_24642);
    _24642 = NOVALUE;
    DeRef(_24640);
    _24640 = NOVALUE;
    return _s_47518;
    ;
}


object _53NewStringSym(object _s_47539)
{
    object _p_47541 = NOVALUE;
    object _tp_47542 = NOVALUE;
    object _prev_47543 = NOVALUE;
    object _search_count_47544 = NOVALUE;
    object _24688 = NOVALUE;
    object _24686 = NOVALUE;
    object _24685 = NOVALUE;
    object _24684 = NOVALUE;
    object _24682 = NOVALUE;
    object _24681 = NOVALUE;
    object _24678 = NOVALUE;
    object _24676 = NOVALUE;
    object _24674 = NOVALUE;
    object _24673 = NOVALUE;
    object _24672 = NOVALUE;
    object _24670 = NOVALUE;
    object _24668 = NOVALUE;
    object _24666 = NOVALUE;
    object _24664 = NOVALUE;
    object _24661 = NOVALUE;
    object _24659 = NOVALUE;
    object _24658 = NOVALUE;
    object _24657 = NOVALUE;
    object _24655 = NOVALUE;
    object _24653 = NOVALUE;
    object _24652 = NOVALUE;
    object _24651 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:255		integer search_count*/

    /** symtab.e:258		tp = literal_init*/
    _tp_47542 = _53literal_init_47235;

    /** symtab.e:259		prev = 0*/
    _prev_47543 = 0LL;

    /** symtab.e:260		search_count = 0*/
    _search_count_47544 = 0LL;

    /** symtab.e:261		while tp != 0 do*/
L1: 
    if (_tp_47542 == 0LL)
    goto L2; // [31] 170

    /** symtab.e:262			search_count += 1*/
    _search_count_47544 = _search_count_47544 + 1;

    /** symtab.e:263			if search_count > SEARCH_LIMIT then  -- avoid n-squared algorithm*/
    if (binary_op_a(LESSEQ, _search_count_47544, _53SEARCH_LIMIT_47529)){
        goto L3; // [45] 54
    }

    /** symtab.e:264				exit*/
    goto L2; // [51] 170
L3: 

    /** symtab.e:266			if equal(s, SymTab[tp][S_OBJ]) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24651 = (object)*(((s1_ptr)_2)->base + _tp_47542);
    _2 = (object)SEQ_PTR(_24651);
    _24652 = (object)*(((s1_ptr)_2)->base + 1LL);
    _24651 = NOVALUE;
    if (_s_47539 == _24652)
    _24653 = 1;
    else if (IS_ATOM_INT(_s_47539) && IS_ATOM_INT(_24652))
    _24653 = 0;
    else
    _24653 = (compare(_s_47539, _24652) == 0);
    _24652 = NOVALUE;
    if (_24653 == 0)
    {
        _24653 = NOVALUE;
        goto L4; // [72] 142
    }
    else{
        _24653 = NOVALUE;
    }

    /** symtab.e:268				if tp != literal_init then*/
    if (_tp_47542 == _53literal_init_47235)
    goto L5; // [79] 135

    /** symtab.e:269					SymTab[prev][S_NEXT] = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_47543 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24657 = (object)*(((s1_ptr)_2)->base + _tp_47542);
    _2 = (object)SEQ_PTR(_24657);
    _24658 = (object)*(((s1_ptr)_2)->base + 2LL);
    _24657 = NOVALUE;
    Ref(_24658);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24658;
    if( _1 != _24658 ){
        DeRef(_1);
    }
    _24658 = NOVALUE;
    _24655 = NOVALUE;

    /** symtab.e:270					SymTab[tp][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_tp_47542 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _53literal_init_47235;
    DeRef(_1);
    _24659 = NOVALUE;

    /** symtab.e:271					literal_init = tp*/
    _53literal_init_47235 = _tp_47542;
L5: 

    /** symtab.e:273				return tp*/
    DeRefDS(_s_47539);
    return _tp_47542;
L4: 

    /** symtab.e:275			prev = tp*/
    _prev_47543 = _tp_47542;

    /** symtab.e:276			tp = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24661 = (object)*(((s1_ptr)_2)->base + _tp_47542);
    _2 = (object)SEQ_PTR(_24661);
    _tp_47542 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_tp_47542)){
        _tp_47542 = (object)DBL_PTR(_tp_47542)->dbl;
    }
    _24661 = NOVALUE;

    /** symtab.e:277		end while*/
    goto L1; // [167] 31
L2: 

    /** symtab.e:279		p = tmp_alloc()*/
    _p_47541 = _53tmp_alloc();
    if (!IS_ATOM_INT(_p_47541)) {
        _1 = (object)(DBL_PTR(_p_47541)->dbl);
        DeRefDS(_p_47541);
        _p_47541 = _1;
    }

    /** symtab.e:280		SymTab[p][S_OBJ] = s*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47541 + ((s1_ptr)_2)->base);
    RefDS(_s_47539);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_47539;
    DeRef(_1);
    _24664 = NOVALUE;

    /** symtab.e:282		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L6; // [196] 346
    }
    else{
    }

    /** symtab.e:283			SymTab[p][S_MODE] = M_TEMP    -- override CONSTANT for compile*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47541 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3LL;
    DeRef(_1);
    _24666 = NOVALUE;

    /** symtab.e:284			SymTab[p][S_GTYPE] = TYPE_SEQUENCE*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47541 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 8LL;
    DeRef(_1);
    _24668 = NOVALUE;

    /** symtab.e:285			SymTab[p][S_SEQ_LEN] = length(s)*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47541 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_s_47539)){
            _24672 = SEQ_PTR(_s_47539)->length;
    }
    else {
        _24672 = 1;
    }
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24672;
    if( _1 != _24672 ){
        DeRef(_1);
    }
    _24672 = NOVALUE;
    _24670 = NOVALUE;

    /** symtab.e:286			if SymTab[p][S_SEQ_LEN] > 0 then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24673 = (object)*(((s1_ptr)_2)->base + _p_47541);
    _2 = (object)SEQ_PTR(_24673);
    _24674 = (object)*(((s1_ptr)_2)->base + 32LL);
    _24673 = NOVALUE;
    if (binary_op_a(LESSEQ, _24674, 0LL)){
        _24674 = NOVALUE;
        goto L7; // [265] 289
    }
    _24674 = NOVALUE;

    /** symtab.e:287				SymTab[p][S_SEQ_ELEM] = TYPE_INTEGER*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47541 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _24676 = NOVALUE;
    goto L8; // [286] 307
L7: 

    /** symtab.e:289				SymTab[p][S_SEQ_ELEM] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47541 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _24678 = NOVALUE;
L8: 

    /** symtab.e:291			c_printf("object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24681 = (object)*(((s1_ptr)_2)->base + _p_47541);
    _2 = (object)SEQ_PTR(_24681);
    _24682 = (object)*(((s1_ptr)_2)->base + 34LL);
    _24681 = NOVALUE;
    RefDS(_24680);
    Ref(_24682);
    _54c_printf(_24680, _24682);
    _24682 = NOVALUE;

    /** symtab.e:292			c_hprintf("extern object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24684 = (object)*(((s1_ptr)_2)->base + _p_47541);
    _2 = (object)SEQ_PTR(_24684);
    _24685 = (object)*(((s1_ptr)_2)->base + 34LL);
    _24684 = NOVALUE;
    RefDS(_24683);
    Ref(_24685);
    _54c_hprintf(_24683, _24685);
    _24685 = NOVALUE;
    goto L9; // [343] 364
L6: 

    /** symtab.e:295			SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47541 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _24686 = NOVALUE;
L9: 

    /** symtab.e:299		SymTab[p][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47541 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _53literal_init_47235;
    DeRef(_1);
    _24688 = NOVALUE;

    /** symtab.e:300		literal_init = p*/
    _53literal_init_47235 = _p_47541;

    /** symtab.e:301		return p*/
    DeRefDS(_s_47539);
    return _p_47541;
    ;
}


object _53NewIntSym(object _int_val_47637)
{
    object _p_47639 = NOVALUE;
    object _x_47640 = NOVALUE;
    object _24712 = NOVALUE;
    object _24710 = NOVALUE;
    object _24706 = NOVALUE;
    object _24704 = NOVALUE;
    object _24702 = NOVALUE;
    object _24700 = NOVALUE;
    object _24698 = NOVALUE;
    object _24696 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:308		integer x*/

    /** symtab.e:310		x = find(int_val, lastintval)*/
    _x_47640 = find_from(_int_val_47637, _53lastintval_47237, 1LL);

    /** symtab.e:311		if x then*/
    if (_x_47640 == 0)
    {
        goto L1; // [14] 75
    }
    else{
    }

    /** symtab.e:312			if repl then*/

    /** symtab.e:317			return lastintsym[x]  -- saves space, helps Translator reduce code size*/
    _2 = (object)SEQ_PTR(_53lastintsym_47238);
    _24696 = (object)*(((s1_ptr)_2)->base + _x_47640);
    DeRef(_int_val_47637);
    return _24696;
    goto L2; // [72] 225
L1: 

    /** symtab.e:320			label "lolol"*/
G3:

    /** symtab.e:321			p = tmp_alloc()*/
    _p_47639 = _53tmp_alloc();
    if (!IS_ATOM_INT(_p_47639)) {
        _1 = (object)(DBL_PTR(_p_47639)->dbl);
        DeRefDS(_p_47639);
        _p_47639 = _1;
    }

    /** symtab.e:322			SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47639 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _24698 = NOVALUE;

    /** symtab.e:323			SymTab[p][S_OBJ] = int_val*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47639 + ((s1_ptr)_2)->base);
    Ref(_int_val_47637);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_val_47637;
    DeRef(_1);
    _24700 = NOVALUE;

    /** symtab.e:325			if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L4; // [122] 173
    }
    else{
    }

    /** symtab.e:326				SymTab[p][S_OBJ_MIN] = int_val*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47639 + ((s1_ptr)_2)->base);
    Ref(_int_val_47637);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_val_47637;
    DeRef(_1);
    _24702 = NOVALUE;

    /** symtab.e:327				SymTab[p][S_OBJ_MAX] = int_val*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47639 + ((s1_ptr)_2)->base);
    Ref(_int_val_47637);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_val_47637;
    DeRef(_1);
    _24704 = NOVALUE;

    /** symtab.e:328				SymTab[p][S_GTYPE] = TYPE_INTEGER*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47639 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _24706 = NOVALUE;
L4: 

    /** symtab.e:331			lastintval = prepend(lastintval, int_val)*/
    Ref(_int_val_47637);
    Prepend(&_53lastintval_47237, _53lastintval_47237, _int_val_47637);

    /** symtab.e:332			lastintsym = prepend(lastintsym, p)*/
    Prepend(&_53lastintsym_47238, _53lastintsym_47238, _p_47639);

    /** symtab.e:333			if length(lastintval) > SEARCH_LIMIT then*/
    if (IS_SEQUENCE(_53lastintval_47237)){
            _24710 = SEQ_PTR(_53lastintval_47237)->length;
    }
    else {
        _24710 = 1;
    }
    if (binary_op_a(LESSEQ, _24710, _53SEARCH_LIMIT_47529)){
        _24710 = NOVALUE;
        goto L5; // [198] 218
    }
    _24710 = NOVALUE;

    /** symtab.e:334				lastintval = lastintval[1..floor(SEARCH_LIMIT/2)]*/
    if (IS_ATOM_INT(_53SEARCH_LIMIT_47529)) {
        _24712 = _53SEARCH_LIMIT_47529 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _53SEARCH_LIMIT_47529, 2);
        _24712 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    rhs_slice_target = (object_ptr)&_53lastintval_47237;
    RHS_Slice(_53lastintval_47237, 1LL, _24712);
L5: 

    /** symtab.e:336			return p*/
    DeRef(_int_val_47637);
    DeRef(_24712);
    _24712 = NOVALUE;
    _24696 = NOVALUE;
    return _p_47639;
L2: 
    ;
}


object _53NewDoubleSym(object _d_47689)
{
    object _p_47691 = NOVALUE;
    object _tp_47692 = NOVALUE;
    object _prev_47693 = NOVALUE;
    object _search_count_47694 = NOVALUE;
    object _24742 = NOVALUE;
    object _24741 = NOVALUE;
    object _24740 = NOVALUE;
    object _24739 = NOVALUE;
    object _24738 = NOVALUE;
    object _24736 = NOVALUE;
    object _24734 = NOVALUE;
    object _24732 = NOVALUE;
    object _24730 = NOVALUE;
    object _24727 = NOVALUE;
    object _24725 = NOVALUE;
    object _24724 = NOVALUE;
    object _24723 = NOVALUE;
    object _24721 = NOVALUE;
    object _24719 = NOVALUE;
    object _24718 = NOVALUE;
    object _24717 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:343		integer search_count*/

    /** symtab.e:346		tp = literal_init*/
    _tp_47692 = _53literal_init_47235;

    /** symtab.e:347		prev = 0*/
    _prev_47693 = 0LL;

    /** symtab.e:348		search_count = 0*/
    _search_count_47694 = 0LL;

    /** symtab.e:349		while tp != 0 do*/
L1: 
    if (_tp_47692 == 0LL)
    goto L2; // [29] 168

    /** symtab.e:350			search_count += 1*/
    _search_count_47694 = _search_count_47694 + 1;

    /** symtab.e:351			if search_count > SEARCH_LIMIT then  -- avoid n-squared algorithm*/
    if (binary_op_a(LESSEQ, _search_count_47694, _53SEARCH_LIMIT_47529)){
        goto L3; // [43] 52
    }

    /** symtab.e:352				exit*/
    goto L2; // [49] 168
L3: 

    /** symtab.e:354			if equal(d, SymTab[tp][S_OBJ]) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24717 = (object)*(((s1_ptr)_2)->base + _tp_47692);
    _2 = (object)SEQ_PTR(_24717);
    _24718 = (object)*(((s1_ptr)_2)->base + 1LL);
    _24717 = NOVALUE;
    if (_d_47689 == _24718)
    _24719 = 1;
    else if (IS_ATOM_INT(_d_47689) && IS_ATOM_INT(_24718))
    _24719 = 0;
    else
    _24719 = (compare(_d_47689, _24718) == 0);
    _24718 = NOVALUE;
    if (_24719 == 0)
    {
        _24719 = NOVALUE;
        goto L4; // [70] 140
    }
    else{
        _24719 = NOVALUE;
    }

    /** symtab.e:356				if tp != literal_init then*/
    if (_tp_47692 == _53literal_init_47235)
    goto L5; // [77] 133

    /** symtab.e:358					SymTab[prev][S_NEXT] = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_47693 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24723 = (object)*(((s1_ptr)_2)->base + _tp_47692);
    _2 = (object)SEQ_PTR(_24723);
    _24724 = (object)*(((s1_ptr)_2)->base + 2LL);
    _24723 = NOVALUE;
    Ref(_24724);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24724;
    if( _1 != _24724 ){
        DeRef(_1);
    }
    _24724 = NOVALUE;
    _24721 = NOVALUE;

    /** symtab.e:359					SymTab[tp][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_tp_47692 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _53literal_init_47235;
    DeRef(_1);
    _24725 = NOVALUE;

    /** symtab.e:360					literal_init = tp*/
    _53literal_init_47235 = _tp_47692;
L5: 

    /** symtab.e:362				return tp*/
    DeRef(_d_47689);
    return _tp_47692;
L4: 

    /** symtab.e:364			prev = tp*/
    _prev_47693 = _tp_47692;

    /** symtab.e:365			tp = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24727 = (object)*(((s1_ptr)_2)->base + _tp_47692);
    _2 = (object)SEQ_PTR(_24727);
    _tp_47692 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_tp_47692)){
        _tp_47692 = (object)DBL_PTR(_tp_47692)->dbl;
    }
    _24727 = NOVALUE;

    /** symtab.e:366		end while*/
    goto L1; // [165] 29
L2: 

    /** symtab.e:368		p = tmp_alloc()*/
    _p_47691 = _53tmp_alloc();
    if (!IS_ATOM_INT(_p_47691)) {
        _1 = (object)(DBL_PTR(_p_47691)->dbl);
        DeRefDS(_p_47691);
        _p_47691 = _1;
    }

    /** symtab.e:369		SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47691 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _24730 = NOVALUE;

    /** symtab.e:370		SymTab[p][S_OBJ] = d*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47691 + ((s1_ptr)_2)->base);
    Ref(_d_47689);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _d_47689;
    DeRef(_1);
    _24732 = NOVALUE;

    /** symtab.e:372		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L6; // [211] 285
    }
    else{
    }

    /** symtab.e:373			SymTab[p][S_MODE] = M_TEMP  -- override CONSTANT for compile*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47691 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3LL;
    DeRef(_1);
    _24734 = NOVALUE;

    /** symtab.e:374			SymTab[p][S_GTYPE] = TYPE_DOUBLE*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47691 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _24736 = NOVALUE;

    /** symtab.e:375			c_printf("object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24738 = (object)*(((s1_ptr)_2)->base + _p_47691);
    _2 = (object)SEQ_PTR(_24738);
    _24739 = (object)*(((s1_ptr)_2)->base + 34LL);
    _24738 = NOVALUE;
    RefDS(_24680);
    Ref(_24739);
    _54c_printf(_24680, _24739);
    _24739 = NOVALUE;

    /** symtab.e:376			c_hprintf("extern object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24740 = (object)*(((s1_ptr)_2)->base + _p_47691);
    _2 = (object)SEQ_PTR(_24740);
    _24741 = (object)*(((s1_ptr)_2)->base + 34LL);
    _24740 = NOVALUE;
    RefDS(_24683);
    Ref(_24741);
    _54c_hprintf(_24683, _24741);
    _24741 = NOVALUE;
L6: 

    /** symtab.e:379		SymTab[p][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47691 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _53literal_init_47235;
    DeRef(_1);
    _24742 = NOVALUE;

    /** symtab.e:380		literal_init = p*/
    _53literal_init_47235 = _p_47691;

    /** symtab.e:381		return p*/
    DeRef(_d_47689);
    return _p_47691;
    ;
}


object _53NewTempSym(object _inlining_47763)
{
    object _p_47765 = NOVALUE;
    object _q_47766 = NOVALUE;
    object _24791 = NOVALUE;
    object _24789 = NOVALUE;
    object _24787 = NOVALUE;
    object _24785 = NOVALUE;
    object _24783 = NOVALUE;
    object _24781 = NOVALUE;
    object _24780 = NOVALUE;
    object _24779 = NOVALUE;
    object _24777 = NOVALUE;
    object _24776 = NOVALUE;
    object _24775 = NOVALUE;
    object _24773 = NOVALUE;
    object _24771 = NOVALUE;
    object _24768 = NOVALUE;
    object _24767 = NOVALUE;
    object _24766 = NOVALUE;
    object _24764 = NOVALUE;
    object _24762 = NOVALUE;
    object _24761 = NOVALUE;
    object _24760 = NOVALUE;
    object _24758 = NOVALUE;
    object _24756 = NOVALUE;
    object _24751 = NOVALUE;
    object _24750 = NOVALUE;
    object _24749 = NOVALUE;
    object _24748 = NOVALUE;
    object _24747 = NOVALUE;
    object _24746 = NOVALUE;
    object _24744 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:392		if inlining then*/
    if (_inlining_47763 == 0)
    {
        goto L1; // [5] 85
    }
    else{
    }

    /** symtab.e:393			p = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24744 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_24744);
    if (!IS_ATOM_INT(_27S_TEMPS_20254)){
        _p_47765 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TEMPS_20254)->dbl));
    }
    else{
        _p_47765 = (object)*(((s1_ptr)_2)->base + _27S_TEMPS_20254);
    }
    if (!IS_ATOM_INT(_p_47765)){
        _p_47765 = (object)DBL_PTR(_p_47765)->dbl;
    }
    _24744 = NOVALUE;

    /** symtab.e:394			while p != 0 and SymTab[p][S_SCOPE] != FREE do*/
L2: 
    _24746 = (_p_47765 != 0LL);
    if (_24746 == 0) {
        goto L3; // [35] 93
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24748 = (object)*(((s1_ptr)_2)->base + _p_47765);
    _2 = (object)SEQ_PTR(_24748);
    _24749 = (object)*(((s1_ptr)_2)->base + 4LL);
    _24748 = NOVALUE;
    if (IS_ATOM_INT(_24749)) {
        _24750 = (_24749 != 0LL);
    }
    else {
        _24750 = binary_op(NOTEQ, _24749, 0LL);
    }
    _24749 = NOVALUE;
    if (_24750 <= 0) {
        if (_24750 == 0) {
            DeRef(_24750);
            _24750 = NOVALUE;
            goto L3; // [58] 93
        }
        else {
            if (!IS_ATOM_INT(_24750) && DBL_PTR(_24750)->dbl == 0.0){
                DeRef(_24750);
                _24750 = NOVALUE;
                goto L3; // [58] 93
            }
            DeRef(_24750);
            _24750 = NOVALUE;
        }
    }
    DeRef(_24750);
    _24750 = NOVALUE;

    /** symtab.e:395				p = SymTab[p][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24751 = (object)*(((s1_ptr)_2)->base + _p_47765);
    _2 = (object)SEQ_PTR(_24751);
    _p_47765 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_p_47765)){
        _p_47765 = (object)DBL_PTR(_p_47765)->dbl;
    }
    _24751 = NOVALUE;

    /** symtab.e:396			end while*/
    goto L2; // [79] 31
    goto L3; // [82] 93
L1: 

    /** symtab.e:398			p = 0*/
    _p_47765 = 0LL;
L3: 

    /** symtab.e:401		if p = 0 then*/
    if (_p_47765 != 0LL)
    goto L4; // [97] 213

    /** symtab.e:403			temps_allocated += 1*/
    _53temps_allocated_47760 = _53temps_allocated_47760 + 1;

    /** symtab.e:404			p = tmp_alloc()*/
    _p_47765 = _53tmp_alloc();
    if (!IS_ATOM_INT(_p_47765)) {
        _1 = (object)(DBL_PTR(_p_47765)->dbl);
        DeRefDS(_p_47765);
        _p_47765 = _1;
    }

    /** symtab.e:405			SymTab[p][S_MODE] = M_TEMP*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47765 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3LL;
    DeRef(_1);
    _24756 = NOVALUE;

    /** symtab.e:406			SymTab[p][S_NEXT] = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47765 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24760 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_24760);
    if (!IS_ATOM_INT(_27S_TEMPS_20254)){
        _24761 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TEMPS_20254)->dbl));
    }
    else{
        _24761 = (object)*(((s1_ptr)_2)->base + _27S_TEMPS_20254);
    }
    _24760 = NOVALUE;
    Ref(_24761);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24761;
    if( _1 != _24761 ){
        DeRef(_1);
    }
    _24761 = NOVALUE;
    _24758 = NOVALUE;

    /** symtab.e:407			SymTab[CurrentSub][S_TEMPS] = p*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27CurrentSub_20579 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_TEMPS_20254))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TEMPS_20254)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_TEMPS_20254);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _p_47765;
    DeRef(_1);
    _24762 = NOVALUE;

    /** symtab.e:409			if inlining then*/
    if (_inlining_47763 == 0)
    {
        goto L5; // [181] 343
    }
    else{
    }

    /** symtab.e:410				SymTab[CurrentSub][S_STACK_SPACE] += 1*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27CurrentSub_20579 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_27S_STACK_SPACE_20269)){
        _24766 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_STACK_SPACE_20269)->dbl));
    }
    else{
        _24766 = (object)*(((s1_ptr)_2)->base + _27S_STACK_SPACE_20269);
    }
    _24764 = NOVALUE;
    if (IS_ATOM_INT(_24766)) {
        _24767 = _24766 + 1;
        if (_24767 > MAXINT){
            _24767 = NewDouble((eudouble)_24767);
        }
    }
    else
    _24767 = binary_op(PLUS, 1, _24766);
    _24766 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_STACK_SPACE_20269))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_STACK_SPACE_20269)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_STACK_SPACE_20269);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24767;
    if( _1 != _24767 ){
        DeRef(_1);
    }
    _24767 = NOVALUE;
    _24764 = NOVALUE;
    goto L5; // [210] 343
L4: 

    /** symtab.e:413		elsif TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L6; // [217] 342
    }
    else{
    }

    /** symtab.e:418			SymTab[p][S_SCOPE] = DELETED*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47765 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _24768 = NOVALUE;

    /** symtab.e:420			q = tmp_alloc()*/
    _q_47766 = _53tmp_alloc();
    if (!IS_ATOM_INT(_q_47766)) {
        _1 = (object)(DBL_PTR(_q_47766)->dbl);
        DeRefDS(_q_47766);
        _q_47766 = _1;
    }

    /** symtab.e:421			SymTab[q][S_MODE] = M_TEMP*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_q_47766 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3LL;
    DeRef(_1);
    _24771 = NOVALUE;

    /** symtab.e:422			SymTab[q][S_TEMP_NAME] = SymTab[p][S_TEMP_NAME]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_q_47766 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24775 = (object)*(((s1_ptr)_2)->base + _p_47765);
    _2 = (object)SEQ_PTR(_24775);
    _24776 = (object)*(((s1_ptr)_2)->base + 34LL);
    _24775 = NOVALUE;
    Ref(_24776);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 34LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24776;
    if( _1 != _24776 ){
        DeRef(_1);
    }
    _24776 = NOVALUE;
    _24773 = NOVALUE;

    /** symtab.e:423			SymTab[q][S_NEXT] = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_q_47766 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24779 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_24779);
    if (!IS_ATOM_INT(_27S_TEMPS_20254)){
        _24780 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TEMPS_20254)->dbl));
    }
    else{
        _24780 = (object)*(((s1_ptr)_2)->base + _27S_TEMPS_20254);
    }
    _24779 = NOVALUE;
    Ref(_24780);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24780;
    if( _1 != _24780 ){
        DeRef(_1);
    }
    _24780 = NOVALUE;
    _24777 = NOVALUE;

    /** symtab.e:424			SymTab[CurrentSub][S_TEMPS] = q*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27CurrentSub_20579 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_TEMPS_20254))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TEMPS_20254)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_TEMPS_20254);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _q_47766;
    DeRef(_1);
    _24781 = NOVALUE;

    /** symtab.e:425			p = q*/
    _p_47765 = _q_47766;
L6: 
L5: 

    /** symtab.e:428		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L7; // [347] 385
    }
    else{
    }

    /** symtab.e:429			SymTab[p][S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47765 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);
    _24783 = NOVALUE;

    /** symtab.e:430			SymTab[p][S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47765 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);
    _24785 = NOVALUE;
L7: 

    /** symtab.e:433		SymTab[p][S_OBJ] = NOVALUE*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47765 + ((s1_ptr)_2)->base);
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
    _24787 = NOVALUE;

    /** symtab.e:434		SymTab[p][S_USAGE] = T_UNKNOWN*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47765 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 4LL;
    DeRef(_1);
    _24789 = NOVALUE;

    /** symtab.e:435		SymTab[p][S_SCOPE] = IN_USE*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47765 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _24791 = NOVALUE;

    /** symtab.e:437		return p*/
    DeRef(_24746);
    _24746 = NOVALUE;
    return _p_47765;
    ;
}


void _53InitSymTab()
{
    object _hashval_47882 = NOVALUE;
    object _len_47883 = NOVALUE;
    object _s_47885 = NOVALUE;
    object _st_index_47886 = NOVALUE;
    object _kname_47887 = NOVALUE;
    object _fixups_47888 = NOVALUE;
    object _si_48027 = NOVALUE;
    object _sj_48028 = NOVALUE;
    object _25380 = NOVALUE;
    object _25379 = NOVALUE;
    object _24906 = NOVALUE;
    object _24905 = NOVALUE;
    object _24904 = NOVALUE;
    object _24903 = NOVALUE;
    object _24902 = NOVALUE;
    object _24900 = NOVALUE;
    object _24899 = NOVALUE;
    object _24898 = NOVALUE;
    object _24897 = NOVALUE;
    object _24895 = NOVALUE;
    object _24893 = NOVALUE;
    object _24891 = NOVALUE;
    object _24890 = NOVALUE;
    object _24888 = NOVALUE;
    object _24886 = NOVALUE;
    object _24884 = NOVALUE;
    object _24883 = NOVALUE;
    object _24881 = NOVALUE;
    object _24880 = NOVALUE;
    object _24879 = NOVALUE;
    object _24878 = NOVALUE;
    object _24877 = NOVALUE;
    object _24874 = NOVALUE;
    object _24873 = NOVALUE;
    object _24872 = NOVALUE;
    object _24870 = NOVALUE;
    object _24869 = NOVALUE;
    object _24868 = NOVALUE;
    object _24866 = NOVALUE;
    object _24865 = NOVALUE;
    object _24864 = NOVALUE;
    object _24861 = NOVALUE;
    object _24859 = NOVALUE;
    object _24857 = NOVALUE;
    object _24856 = NOVALUE;
    object _24853 = NOVALUE;
    object _24852 = NOVALUE;
    object _24850 = NOVALUE;
    object _24848 = NOVALUE;
    object _24846 = NOVALUE;
    object _24844 = NOVALUE;
    object _24843 = NOVALUE;
    object _24842 = NOVALUE;
    object _24839 = NOVALUE;
    object _24838 = NOVALUE;
    object _24836 = NOVALUE;
    object _24835 = NOVALUE;
    object _24833 = NOVALUE;
    object _24832 = NOVALUE;
    object _24831 = NOVALUE;
    object _24829 = NOVALUE;
    object _24827 = NOVALUE;
    object _24826 = NOVALUE;
    object _24824 = NOVALUE;
    object _24823 = NOVALUE;
    object _24822 = NOVALUE;
    object _24820 = NOVALUE;
    object _24819 = NOVALUE;
    object _24818 = NOVALUE;
    object _24816 = NOVALUE;
    object _24815 = NOVALUE;
    object _24814 = NOVALUE;
    object _24812 = NOVALUE;
    object _24811 = NOVALUE;
    object _24810 = NOVALUE;
    object _24809 = NOVALUE;
    object _24808 = NOVALUE;
    object _24807 = NOVALUE;
    object _24806 = NOVALUE;
    object _24805 = NOVALUE;
    object _24804 = NOVALUE;
    object _24803 = NOVALUE;
    object _24801 = NOVALUE;
    object _24800 = NOVALUE;
    object _24799 = NOVALUE;
    object _24798 = NOVALUE;
    object _24794 = NOVALUE;
    object _24793 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:445		sequence kname, fixups = {}*/
    RefDS(_22218);
    DeRefi(_fixups_47888);
    _fixups_47888 = _22218;

    /** symtab.e:447		for k = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_62keylist_23493)){
            _24793 = SEQ_PTR(_62keylist_23493)->length;
    }
    else {
        _24793 = 1;
    }
    {
        object _k_47890;
        _k_47890 = 1LL;
L1: 
        if (_k_47890 > _24793){
            goto L2; // [15] 560
        }

        /** symtab.e:448			kname = keylist[k][K_NAME]*/
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _24794 = (object)*(((s1_ptr)_2)->base + _k_47890);
        DeRef(_kname_47887);
        _2 = (object)SEQ_PTR(_24794);
        _kname_47887 = (object)*(((s1_ptr)_2)->base + 1LL);
        Ref(_kname_47887);
        _24794 = NOVALUE;

        /** symtab.e:449			len = length(kname)*/
        if (IS_SEQUENCE(_kname_47887)){
                _len_47883 = SEQ_PTR(_kname_47887)->length;
        }
        else {
            _len_47883 = 1;
        }

        /** symtab.e:450			hashval = hashfn(kname)*/
        RefDS(_kname_47887);
        _hashval_47882 = _53hashfn(_kname_47887);
        if (!IS_ATOM_INT(_hashval_47882)) {
            _1 = (object)(DBL_PTR(_hashval_47882)->dbl);
            DeRefDS(_hashval_47882);
            _hashval_47882 = _1;
        }

        /** symtab.e:451			st_index = NewEntry(kname,*/
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _24798 = (object)*(((s1_ptr)_2)->base + _k_47890);
        _2 = (object)SEQ_PTR(_24798);
        _24799 = (object)*(((s1_ptr)_2)->base + 2LL);
        _24798 = NOVALUE;
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _24800 = (object)*(((s1_ptr)_2)->base + _k_47890);
        _2 = (object)SEQ_PTR(_24800);
        _24801 = (object)*(((s1_ptr)_2)->base + 3LL);
        _24800 = NOVALUE;
        RefDS(_kname_47887);
        Ref(_24799);
        Ref(_24801);
        _st_index_47886 = _53NewEntry(_kname_47887, 0LL, _24799, _24801, _hashval_47882, 0LL, 0LL);
        _24799 = NOVALUE;
        _24801 = NOVALUE;
        if (!IS_ATOM_INT(_st_index_47886)) {
            _1 = (object)(DBL_PTR(_st_index_47886)->dbl);
            DeRefDS(_st_index_47886);
            _st_index_47886 = _1;
        }

        /** symtab.e:456			if find(keylist[k][K_TOKEN], RTN_TOKS) then*/
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _24803 = (object)*(((s1_ptr)_2)->base + _k_47890);
        _2 = (object)SEQ_PTR(_24803);
        _24804 = (object)*(((s1_ptr)_2)->base + 3LL);
        _24803 = NOVALUE;
        _24805 = find_from(_24804, _29RTN_TOKS_12277, 1LL);
        _24804 = NOVALUE;
        if (_24805 == 0)
        {
            _24805 = NOVALUE;
            goto L3; // [110] 325
        }
        else{
            _24805 = NOVALUE;
        }

        /** symtab.e:457				SymTab[st_index] = SymTab[st_index] &*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _24806 = (object)*(((s1_ptr)_2)->base + _st_index_47886);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _24807 = (object)*(((s1_ptr)_2)->base + _st_index_47886);
        if (IS_SEQUENCE(_24807)){
                _24808 = SEQ_PTR(_24807)->length;
        }
        else {
            _24808 = 1;
        }
        _24807 = NOVALUE;
        _24809 = _27SIZEOF_ROUTINE_ENTRY_20335 - _24808;
        _24808 = NOVALUE;
        _24810 = Repeat(0LL, _24809);
        _24809 = NOVALUE;
        if (IS_SEQUENCE(_24806) && IS_ATOM(_24810)) {
        }
        else if (IS_ATOM(_24806) && IS_SEQUENCE(_24810)) {
            Ref(_24806);
            Prepend(&_24811, _24810, _24806);
        }
        else {
            Concat((object_ptr)&_24811, _24806, _24810);
            _24806 = NOVALUE;
        }
        _24806 = NOVALUE;
        DeRefDS(_24810);
        _24810 = NOVALUE;
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _st_index_47886);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24811;
        if( _1 != _24811 ){
            DeRef(_1);
        }
        _24811 = NOVALUE;

        /** symtab.e:460				SymTab[st_index][S_NUM_ARGS] = keylist[k][K_NUM_ARGS]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47886 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _24814 = (object)*(((s1_ptr)_2)->base + _k_47890);
        _2 = (object)SEQ_PTR(_24814);
        _24815 = (object)*(((s1_ptr)_2)->base + 5LL);
        _24814 = NOVALUE;
        Ref(_24815);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_27S_NUM_ARGS_20260))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24815;
        if( _1 != _24815 ){
            DeRef(_1);
        }
        _24815 = NOVALUE;
        _24812 = NOVALUE;

        /** symtab.e:461				SymTab[st_index][S_OPCODE] = keylist[k][K_OPCODE]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47886 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _24818 = (object)*(((s1_ptr)_2)->base + _k_47890);
        _2 = (object)SEQ_PTR(_24818);
        _24819 = (object)*(((s1_ptr)_2)->base + 4LL);
        _24818 = NOVALUE;
        Ref(_24819);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 21LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24819;
        if( _1 != _24819 ){
            DeRef(_1);
        }
        _24819 = NOVALUE;
        _24816 = NOVALUE;

        /** symtab.e:462				SymTab[st_index][S_EFFECT] = keylist[k][K_EFFECT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47886 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _24822 = (object)*(((s1_ptr)_2)->base + _k_47890);
        _2 = (object)SEQ_PTR(_24822);
        _24823 = (object)*(((s1_ptr)_2)->base + 6LL);
        _24822 = NOVALUE;
        Ref(_24823);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 23LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24823;
        if( _1 != _24823 ){
            DeRef(_1);
        }
        _24823 = NOVALUE;
        _24820 = NOVALUE;

        /** symtab.e:463				SymTab[st_index][S_REFLIST] = {}*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47886 + ((s1_ptr)_2)->base);
        RefDS(_22218);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 24LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _22218;
        DeRef(_1);
        _24824 = NOVALUE;

        /** symtab.e:464				if length(keylist[k]) > K_EFFECT then*/
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _24826 = (object)*(((s1_ptr)_2)->base + _k_47890);
        if (IS_SEQUENCE(_24826)){
                _24827 = SEQ_PTR(_24826)->length;
        }
        else {
            _24827 = 1;
        }
        _24826 = NOVALUE;
        if (_24827 <= 6LL)
        goto L4; // [259] 324

        /** symtab.e:465				    SymTab[st_index][S_CODE] = keylist[k][K_CODE]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47886 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _24831 = (object)*(((s1_ptr)_2)->base + _k_47890);
        _2 = (object)SEQ_PTR(_24831);
        _24832 = (object)*(((s1_ptr)_2)->base + 7LL);
        _24831 = NOVALUE;
        Ref(_24832);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_27S_CODE_20221))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24832;
        if( _1 != _24832 ){
            DeRef(_1);
        }
        _24832 = NOVALUE;
        _24829 = NOVALUE;

        /** symtab.e:466				    SymTab[st_index][S_DEF_ARGS] = keylist[k][K_DEF_ARGS]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47886 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _24835 = (object)*(((s1_ptr)_2)->base + _k_47890);
        _2 = (object)SEQ_PTR(_24835);
        _24836 = (object)*(((s1_ptr)_2)->base + 8LL);
        _24835 = NOVALUE;
        Ref(_24836);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 28LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24836;
        if( _1 != _24836 ){
            DeRef(_1);
        }
        _24836 = NOVALUE;
        _24833 = NOVALUE;

        /** symtab.e:467				    fixups &= st_index*/
        Append(&_fixups_47888, _fixups_47888, _st_index_47886);
L4: 
L3: 

        /** symtab.e:470			if keylist[k][K_TOKEN] = PROC then*/
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _24838 = (object)*(((s1_ptr)_2)->base + _k_47890);
        _2 = (object)SEQ_PTR(_24838);
        _24839 = (object)*(((s1_ptr)_2)->base + 3LL);
        _24838 = NOVALUE;
        if (binary_op_a(NOTEQ, _24839, 27LL)){
            _24839 = NOVALUE;
            goto L5; // [341] 365
        }
        _24839 = NOVALUE;

        /** symtab.e:471				if equal(kname, "<TopLevel>") then*/
        if (_kname_47887 == _24841)
        _24842 = 1;
        else if (IS_ATOM_INT(_kname_47887) && IS_ATOM_INT(_24841))
        _24842 = 0;
        else
        _24842 = (compare(_kname_47887, _24841) == 0);
        if (_24842 == 0)
        {
            _24842 = NOVALUE;
            goto L6; // [351] 462
        }
        else{
            _24842 = NOVALUE;
        }

        /** symtab.e:472					TopLevelSub = st_index*/
        _27TopLevelSub_20578 = _st_index_47886;
        goto L6; // [362] 462
L5: 

        /** symtab.e:474			elsif keylist[k][K_TOKEN] = TYPE then*/
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _24843 = (object)*(((s1_ptr)_2)->base + _k_47890);
        _2 = (object)SEQ_PTR(_24843);
        _24844 = (object)*(((s1_ptr)_2)->base + 3LL);
        _24843 = NOVALUE;
        if (binary_op_a(NOTEQ, _24844, 504LL)){
            _24844 = NOVALUE;
            goto L7; // [381] 461
        }
        _24844 = NOVALUE;

        /** symtab.e:475				if equal(kname, "object") then*/
        if (_kname_47887 == _23193)
        _24846 = 1;
        else if (IS_ATOM_INT(_kname_47887) && IS_ATOM_INT(_23193))
        _24846 = 0;
        else
        _24846 = (compare(_kname_47887, _23193) == 0);
        if (_24846 == 0)
        {
            _24846 = NOVALUE;
            goto L8; // [391] 404
        }
        else{
            _24846 = NOVALUE;
        }

        /** symtab.e:476					object_type = st_index*/
        _53object_type_47227 = _st_index_47886;
        goto L9; // [401] 460
L8: 

        /** symtab.e:477				elsif equal(kname, "atom") then*/
        if (_kname_47887 == _24847)
        _24848 = 1;
        else if (IS_ATOM_INT(_kname_47887) && IS_ATOM_INT(_24847))
        _24848 = 0;
        else
        _24848 = (compare(_kname_47887, _24847) == 0);
        if (_24848 == 0)
        {
            _24848 = NOVALUE;
            goto LA; // [410] 423
        }
        else{
            _24848 = NOVALUE;
        }

        /** symtab.e:478					atom_type = st_index*/
        _53atom_type_47229 = _st_index_47886;
        goto L9; // [420] 460
LA: 

        /** symtab.e:479				elsif equal(kname, "integer") then*/
        if (_kname_47887 == _24849)
        _24850 = 1;
        else if (IS_ATOM_INT(_kname_47887) && IS_ATOM_INT(_24849))
        _24850 = 0;
        else
        _24850 = (compare(_kname_47887, _24849) == 0);
        if (_24850 == 0)
        {
            _24850 = NOVALUE;
            goto LB; // [429] 442
        }
        else{
            _24850 = NOVALUE;
        }

        /** symtab.e:480					integer_type = st_index*/
        _53integer_type_47233 = _st_index_47886;
        goto L9; // [439] 460
LB: 

        /** symtab.e:481				elsif equal(kname, "sequence") then*/
        if (_kname_47887 == _24851)
        _24852 = 1;
        else if (IS_ATOM_INT(_kname_47887) && IS_ATOM_INT(_24851))
        _24852 = 0;
        else
        _24852 = (compare(_kname_47887, _24851) == 0);
        if (_24852 == 0)
        {
            _24852 = NOVALUE;
            goto LC; // [448] 459
        }
        else{
            _24852 = NOVALUE;
        }

        /** symtab.e:482					sequence_type = st_index*/
        _53sequence_type_47231 = _st_index_47886;
LC: 
L9: 
L7: 
L6: 

        /** symtab.e:485			if buckets[hashval] = 0 then*/
        _2 = (object)SEQ_PTR(_53buckets_47223);
        _24853 = (object)*(((s1_ptr)_2)->base + _hashval_47882);
        if (binary_op_a(NOTEQ, _24853, 0LL)){
            _24853 = NOVALUE;
            goto LD; // [470] 485
        }
        _24853 = NOVALUE;

        /** symtab.e:486				buckets[hashval] = st_index*/
        _2 = (object)SEQ_PTR(_53buckets_47223);
        _2 = (object)(((s1_ptr)_2)->base + _hashval_47882);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _st_index_47886;
        DeRef(_1);
        goto LE; // [482] 553
LD: 

        /** symtab.e:488				s = buckets[hashval]*/
        _2 = (object)SEQ_PTR(_53buckets_47223);
        _s_47885 = (object)*(((s1_ptr)_2)->base + _hashval_47882);
        if (!IS_ATOM_INT(_s_47885)){
            _s_47885 = (object)DBL_PTR(_s_47885)->dbl;
        }

        /** symtab.e:489				while SymTab[s][S_SAMEHASH] != 0 do*/
LF: 
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _24856 = (object)*(((s1_ptr)_2)->base + _s_47885);
        _2 = (object)SEQ_PTR(_24856);
        _24857 = (object)*(((s1_ptr)_2)->base + 9LL);
        _24856 = NOVALUE;
        if (binary_op_a(EQUALS, _24857, 0LL)){
            _24857 = NOVALUE;
            goto L10; // [512] 537
        }
        _24857 = NOVALUE;

        /** symtab.e:490					s = SymTab[s][S_SAMEHASH]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _24859 = (object)*(((s1_ptr)_2)->base + _s_47885);
        _2 = (object)SEQ_PTR(_24859);
        _s_47885 = (object)*(((s1_ptr)_2)->base + 9LL);
        if (!IS_ATOM_INT(_s_47885)){
            _s_47885 = (object)DBL_PTR(_s_47885)->dbl;
        }
        _24859 = NOVALUE;

        /** symtab.e:491				end while*/
        goto LF; // [534] 500
L10: 

        /** symtab.e:492				SymTab[s][S_SAMEHASH] = st_index*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_s_47885 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 9LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _st_index_47886;
        DeRef(_1);
        _24861 = NOVALUE;
LE: 

        /** symtab.e:494		end for*/
        _k_47890 = _k_47890 + 1LL;
        goto L1; // [555] 22
L2: 
        ;
    }

    /** symtab.e:495		file_start_sym = length(SymTab)*/
    if (IS_SEQUENCE(_28SymTab_11572)){
            _27file_start_sym_20577 = SEQ_PTR(_28SymTab_11572)->length;
    }
    else {
        _27file_start_sym_20577 = 1;
    }

    /** symtab.e:497		sequence si, sj*/

    /** symtab.e:498		CurrentSub = TopLevelSub*/
    _27CurrentSub_20579 = _27TopLevelSub_20578;

    /** symtab.e:499		for i=1 to length(fixups) do*/
    if (IS_SEQUENCE(_fixups_47888)){
            _24864 = SEQ_PTR(_fixups_47888)->length;
    }
    else {
        _24864 = 1;
    }
    {
        object _i_48032;
        _i_48032 = 1LL;
L11: 
        if (_i_48032 > _24864){
            goto L12; // [585] 946
        }

        /** symtab.e:500		    si = SymTab[fixups[i]][S_CODE] -- seq of either 0's or sequences of tokens*/
        _2 = (object)SEQ_PTR(_fixups_47888);
        _24865 = (object)*(((s1_ptr)_2)->base + _i_48032);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _24866 = (object)*(((s1_ptr)_2)->base + _24865);
        DeRef(_si_48027);
        _2 = (object)SEQ_PTR(_24866);
        if (!IS_ATOM_INT(_27S_CODE_20221)){
            _si_48027 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
        }
        else{
            _si_48027 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
        }
        Ref(_si_48027);
        _24866 = NOVALUE;

        /** symtab.e:501		    for j=1 to length(si) do*/
        if (IS_SEQUENCE(_si_48027)){
                _24868 = SEQ_PTR(_si_48027)->length;
        }
        else {
            _24868 = 1;
        }
        {
            object _j_48040;
            _j_48040 = 1LL;
L13: 
            if (_j_48040 > _24868){
                goto L14; // [617] 920
            }

            /** symtab.e:502		        if sequence(si[j]) then*/
            _2 = (object)SEQ_PTR(_si_48027);
            _24869 = (object)*(((s1_ptr)_2)->base + _j_48040);
            _24870 = IS_SEQUENCE(_24869);
            _24869 = NOVALUE;
            if (_24870 == 0)
            {
                _24870 = NOVALUE;
                goto L15; // [633] 913
            }
            else{
                _24870 = NOVALUE;
            }

            /** symtab.e:503		            sj = si[j] -- a sequence of tokens*/
            DeRef(_sj_48028);
            _2 = (object)SEQ_PTR(_si_48027);
            _sj_48028 = (object)*(((s1_ptr)_2)->base + _j_48040);
            Ref(_sj_48028);

            /** symtab.e:504					for ij=1 to length(sj) do*/
            if (IS_SEQUENCE(_sj_48028)){
                    _24872 = SEQ_PTR(_sj_48028)->length;
            }
            else {
                _24872 = 1;
            }
            {
                object _ij_48047;
                _ij_48047 = 1LL;
L16: 
                if (_ij_48047 > _24872){
                    goto L17; // [649] 906
                }

                /** symtab.e:505		                switch sj[ij][T_ID] with fallthru do*/
                _2 = (object)SEQ_PTR(_sj_48028);
                _24873 = (object)*(((s1_ptr)_2)->base + _ij_48047);
                _2 = (object)SEQ_PTR(_24873);
                _24874 = (object)*(((s1_ptr)_2)->base + 1LL);
                _24873 = NOVALUE;
                if (IS_SEQUENCE(_24874) ){
                    goto L18; // [668] 899
                }
                if(!IS_ATOM_INT(_24874)){
                    if( (DBL_PTR(_24874)->dbl != (eudouble) ((object) DBL_PTR(_24874)->dbl) ) ){
                        goto L18; // [668] 899
                    }
                    _0 = (object) DBL_PTR(_24874)->dbl;
                }
                else {
                    _0 = _24874;
                };
                _24874 = NOVALUE;
                switch ( _0 ){ 

                    /** symtab.e:506		                    case ATOM then -- must create a lasting temp*/
                    case 502:

                    /** symtab.e:507		                    	if is_integer(sj[ij][T_SYM]) then*/
                    _2 = (object)SEQ_PTR(_sj_48028);
                    _24877 = (object)*(((s1_ptr)_2)->base + _ij_48047);
                    _2 = (object)SEQ_PTR(_24877);
                    _24878 = (object)*(((s1_ptr)_2)->base + 2LL);
                    _24877 = NOVALUE;
                    Ref(_24878);
                    _24879 = _27is_integer(_24878);
                    _24878 = NOVALUE;
                    if (_24879 == 0) {
                        DeRef(_24879);
                        _24879 = NOVALUE;
                        goto L19; // [693] 717
                    }
                    else {
                        if (!IS_ATOM_INT(_24879) && DBL_PTR(_24879)->dbl == 0.0){
                            DeRef(_24879);
                            _24879 = NOVALUE;
                            goto L19; // [693] 717
                        }
                        DeRef(_24879);
                        _24879 = NOVALUE;
                    }
                    DeRef(_24879);
                    _24879 = NOVALUE;

                    /** symtab.e:508									st_index = NewIntSym(sj[ij][T_SYM])*/
                    _2 = (object)SEQ_PTR(_sj_48028);
                    _24880 = (object)*(((s1_ptr)_2)->base + _ij_48047);
                    _2 = (object)SEQ_PTR(_24880);
                    _24881 = (object)*(((s1_ptr)_2)->base + 2LL);
                    _24880 = NOVALUE;
                    Ref(_24881);
                    _st_index_47886 = _53NewIntSym(_24881);
                    _24881 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_47886)) {
                        _1 = (object)(DBL_PTR(_st_index_47886)->dbl);
                        DeRefDS(_st_index_47886);
                        _st_index_47886 = _1;
                    }
                    goto L1A; // [714] 736
L19: 

                    /** symtab.e:510									st_index = NewDoubleSym(sj[ij][T_SYM])*/
                    _2 = (object)SEQ_PTR(_sj_48028);
                    _24883 = (object)*(((s1_ptr)_2)->base + _ij_48047);
                    _2 = (object)SEQ_PTR(_24883);
                    _24884 = (object)*(((s1_ptr)_2)->base + 2LL);
                    _24883 = NOVALUE;
                    Ref(_24884);
                    _st_index_47886 = _53NewDoubleSym(_24884);
                    _24884 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_47886)) {
                        _1 = (object)(DBL_PTR(_st_index_47886)->dbl);
                        DeRefDS(_st_index_47886);
                        _st_index_47886 = _1;
                    }
L1A: 

                    /** symtab.e:512								SymTab[st_index][S_SCOPE] = IN_USE -- TempKeep()*/
                    _2 = (object)SEQ_PTR(_28SymTab_11572);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _28SymTab_11572 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_st_index_47886 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 4LL);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = 1LL;
                    DeRef(_1);
                    _24886 = NOVALUE;

                    /** symtab.e:513								sj[ij][T_SYM] = st_index*/
                    _2 = (object)SEQ_PTR(_sj_48028);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_48028 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_ij_48047 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 2LL);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _st_index_47886;
                    DeRef(_1);
                    _24888 = NOVALUE;

                    /** symtab.e:514								break*/
                    goto L18; // [770] 899

                    /** symtab.e:515							case STRING then -- same*/
                    case 503:

                    /** symtab.e:516		                    	st_index = NewStringSym(sj[ij][T_SYM])*/
                    _2 = (object)SEQ_PTR(_sj_48028);
                    _24890 = (object)*(((s1_ptr)_2)->base + _ij_48047);
                    _2 = (object)SEQ_PTR(_24890);
                    _24891 = (object)*(((s1_ptr)_2)->base + 2LL);
                    _24890 = NOVALUE;
                    Ref(_24891);
                    _st_index_47886 = _53NewStringSym(_24891);
                    _24891 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_47886)) {
                        _1 = (object)(DBL_PTR(_st_index_47886)->dbl);
                        DeRefDS(_st_index_47886);
                        _st_index_47886 = _1;
                    }

                    /** symtab.e:517								SymTab[st_index][S_SCOPE] = IN_USE -- TempKeep()*/
                    _2 = (object)SEQ_PTR(_28SymTab_11572);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _28SymTab_11572 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_st_index_47886 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 4LL);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = 1LL;
                    DeRef(_1);
                    _24893 = NOVALUE;

                    /** symtab.e:518								sj[ij][T_SYM] = st_index*/
                    _2 = (object)SEQ_PTR(_sj_48028);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_48028 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_ij_48047 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 2LL);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _st_index_47886;
                    DeRef(_1);
                    _24895 = NOVALUE;

                    /** symtab.e:519								break*/
                    goto L18; // [826] 899

                    /** symtab.e:520							case BUILT_IN then -- name of a builtin in econd field*/
                    case 511:

                    /** symtab.e:521	                            sj[ij] = keyfind(sj[ij][T_SYM],-1)*/
                    _2 = (object)SEQ_PTR(_sj_48028);
                    _24897 = (object)*(((s1_ptr)_2)->base + _ij_48047);
                    _2 = (object)SEQ_PTR(_24897);
                    _24898 = (object)*(((s1_ptr)_2)->base + 2LL);
                    _24897 = NOVALUE;
                    Ref(_24898);
                    DeRef(_25379);
                    _25379 = _24898;
                    _25380 = _53hashfn(_25379);
                    _25379 = NOVALUE;
                    Ref(_24898);
                    _24899 = _53keyfind(_24898, -1LL, _27current_file_no_20571, 0LL, _25380);
                    _24898 = NOVALUE;
                    _25380 = NOVALUE;
                    _2 = (object)SEQ_PTR(_sj_48028);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_48028 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + _ij_48047);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _24899;
                    if( _1 != _24899 ){
                        DeRef(_1);
                    }
                    _24899 = NOVALUE;

                    /** symtab.e:522								break*/
                    goto L18; // [867] 899

                    /** symtab.e:523							case DEF_PARAM then*/
                    case 510:

                    /** symtab.e:524								sj[ij][T_SYM] &= fixups[i]*/
                    _2 = (object)SEQ_PTR(_sj_48028);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_48028 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_ij_48047 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(_fixups_47888);
                    _24902 = (object)*(((s1_ptr)_2)->base + _i_48032);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    _24903 = (object)*(((s1_ptr)_2)->base + 2LL);
                    _24900 = NOVALUE;
                    if (IS_SEQUENCE(_24903) && IS_ATOM(_24902)) {
                        Append(&_24904, _24903, _24902);
                    }
                    else if (IS_ATOM(_24903) && IS_SEQUENCE(_24902)) {
                    }
                    else {
                        Concat((object_ptr)&_24904, _24903, _24902);
                        _24903 = NOVALUE;
                    }
                    _24903 = NOVALUE;
                    _24902 = NOVALUE;
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 2LL);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _24904;
                    if( _1 != _24904 ){
                        DeRef(_1);
                    }
                    _24904 = NOVALUE;
                    _24900 = NOVALUE;
                ;}L18: 

                /** symtab.e:526					end for*/
                _ij_48047 = _ij_48047 + 1LL;
                goto L16; // [901] 656
L17: 
                ;
            }

            /** symtab.e:527					si[j] = sj*/
            RefDS(_sj_48028);
            _2 = (object)SEQ_PTR(_si_48027);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _si_48027 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _j_48040);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _sj_48028;
            DeRef(_1);
L15: 

            /** symtab.e:529			end for*/
            _j_48040 = _j_48040 + 1LL;
            goto L13; // [915] 624
L14: 
            ;
        }

        /** symtab.e:530			SymTab[fixups[i]][S_CODE] = si*/
        _2 = (object)SEQ_PTR(_fixups_47888);
        _24905 = (object)*(((s1_ptr)_2)->base + _i_48032);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_24905 + ((s1_ptr)_2)->base);
        RefDS(_si_48027);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_27S_CODE_20221))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _si_48027;
        DeRef(_1);
        _24906 = NOVALUE;

        /** symtab.e:531		end for*/
        _i_48032 = _i_48032 + 1LL;
        goto L11; // [941] 592
L12: 
        ;
    }

    /** symtab.e:532	end procedure*/
    DeRef(_kname_47887);
    DeRefi(_fixups_47888);
    DeRef(_si_48027);
    DeRef(_sj_48028);
    _24905 = NOVALUE;
    _24826 = NOVALUE;
    _24807 = NOVALUE;
    _24865 = NOVALUE;
    return;
    ;
}


void _53add_ref(object _tok_48116)
{
    object _s_48118 = NOVALUE;
    object _24922 = NOVALUE;
    object _24921 = NOVALUE;
    object _24919 = NOVALUE;
    object _24918 = NOVALUE;
    object _24917 = NOVALUE;
    object _24915 = NOVALUE;
    object _24914 = NOVALUE;
    object _24913 = NOVALUE;
    object _24912 = NOVALUE;
    object _24911 = NOVALUE;
    object _24910 = NOVALUE;
    object _24909 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:538		s = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_48116);
    _s_48118 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_48118)){
        _s_48118 = (object)DBL_PTR(_s_48118)->dbl;
    }

    /** symtab.e:539		if s != CurrentSub and -- ignore self-ref's*/
    _24909 = (_s_48118 != _27CurrentSub_20579);
    if (_24909 == 0) {
        goto L1; // [19] 98
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24911 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_24911);
    _24912 = (object)*(((s1_ptr)_2)->base + 24LL);
    _24911 = NOVALUE;
    _24913 = find_from(_s_48118, _24912, 1LL);
    _24912 = NOVALUE;
    _24914 = (_24913 == 0);
    _24913 = NOVALUE;
    if (_24914 == 0)
    {
        DeRef(_24914);
        _24914 = NOVALUE;
        goto L1; // [46] 98
    }
    else{
        DeRef(_24914);
        _24914 = NOVALUE;
    }

    /** symtab.e:542			SymTab[s][S_NREFS] += 1*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_48118 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _24917 = (object)*(((s1_ptr)_2)->base + 12LL);
    _24915 = NOVALUE;
    if (IS_ATOM_INT(_24917)) {
        _24918 = _24917 + 1;
        if (_24918 > MAXINT){
            _24918 = NewDouble((eudouble)_24918);
        }
    }
    else
    _24918 = binary_op(PLUS, 1, _24917);
    _24917 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24918;
    if( _1 != _24918 ){
        DeRef(_1);
    }
    _24918 = NOVALUE;
    _24915 = NOVALUE;

    /** symtab.e:543			SymTab[CurrentSub][S_REFLIST] &= s*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27CurrentSub_20579 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _24921 = (object)*(((s1_ptr)_2)->base + 24LL);
    _24919 = NOVALUE;
    if (IS_SEQUENCE(_24921) && IS_ATOM(_s_48118)) {
        Append(&_24922, _24921, _s_48118);
    }
    else if (IS_ATOM(_24921) && IS_SEQUENCE(_s_48118)) {
    }
    else {
        Concat((object_ptr)&_24922, _24921, _s_48118);
        _24921 = NOVALUE;
    }
    _24921 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 24LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24922;
    if( _1 != _24922 ){
        DeRef(_1);
    }
    _24922 = NOVALUE;
    _24919 = NOVALUE;
L1: 

    /** symtab.e:545	end procedure*/
    DeRef(_tok_48116);
    DeRef(_24909);
    _24909 = NOVALUE;
    return;
    ;
}


void _53mark_all(object _attribute_48148)
{
    object _p_48151 = NOVALUE;
    object _sym_file_48158 = NOVALUE;
    object _scope_48175 = NOVALUE;
    object _24954 = NOVALUE;
    object _24953 = NOVALUE;
    object _24952 = NOVALUE;
    object _24950 = NOVALUE;
    object _24948 = NOVALUE;
    object _24947 = NOVALUE;
    object _24946 = NOVALUE;
    object _24945 = NOVALUE;
    object _24944 = NOVALUE;
    object _24942 = NOVALUE;
    object _24941 = NOVALUE;
    object _24940 = NOVALUE;
    object _24939 = NOVALUE;
    object _24935 = NOVALUE;
    object _24934 = NOVALUE;
    object _24933 = NOVALUE;
    object _24931 = NOVALUE;
    object _24930 = NOVALUE;
    object _24928 = NOVALUE;
    object _24926 = NOVALUE;
    object _24923 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:550		if just_mark_everything_from then*/
    if (_53just_mark_everything_from_48145 == 0)
    {
        goto L1; // [7] 270
    }
    else{
    }

    /** symtab.e:551			symtab_pointer p = SymTab[just_mark_everything_from][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24923 = (object)*(((s1_ptr)_2)->base + _53just_mark_everything_from_48145);
    _2 = (object)SEQ_PTR(_24923);
    _p_48151 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_p_48151)){
        _p_48151 = (object)DBL_PTR(_p_48151)->dbl;
    }
    _24923 = NOVALUE;

    /** symtab.e:552			while p != 0 do*/
L2: 
    if (_p_48151 == 0LL)
    goto L3; // [33] 269

    /** symtab.e:553				integer sym_file = SymTab[p][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24926 = (object)*(((s1_ptr)_2)->base + _p_48151);
    _2 = (object)SEQ_PTR(_24926);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _sym_file_48158 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _sym_file_48158 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    if (!IS_ATOM_INT(_sym_file_48158)){
        _sym_file_48158 = (object)DBL_PTR(_sym_file_48158)->dbl;
    }
    _24926 = NOVALUE;

    /** symtab.e:554				just_mark_everything_from = p*/
    _53just_mark_everything_from_48145 = _p_48151;

    /** symtab.e:555				if sym_file = current_file_no or map:has( recheck_routines, sym_file ) then*/
    _24928 = (_sym_file_48158 == _27current_file_no_20571);
    if (_24928 != 0) {
        goto L4; // [68] 84
    }
    Ref(_53recheck_routines_48218);
    _24930 = _34has(_53recheck_routines_48218, _sym_file_48158);
    if (_24930 == 0) {
        DeRef(_24930);
        _24930 = NOVALUE;
        goto L5; // [80] 108
    }
    else {
        if (!IS_ATOM_INT(_24930) && DBL_PTR(_24930)->dbl == 0.0){
            DeRef(_24930);
            _24930 = NOVALUE;
            goto L5; // [80] 108
        }
        DeRef(_24930);
        _24930 = NOVALUE;
    }
    DeRef(_24930);
    _24930 = NOVALUE;
L4: 

    /** symtab.e:556					SymTab[p][attribute] += 1*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_48151 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _24933 = (object)*(((s1_ptr)_2)->base + _attribute_48148);
    _24931 = NOVALUE;
    if (IS_ATOM_INT(_24933)) {
        _24934 = _24933 + 1;
        if (_24934 > MAXINT){
            _24934 = NewDouble((eudouble)_24934);
        }
    }
    else
    _24934 = binary_op(PLUS, 1, _24933);
    _24933 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _attribute_48148);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24934;
    if( _1 != _24934 ){
        DeRef(_1);
    }
    _24934 = NOVALUE;
    _24931 = NOVALUE;
    goto L6; // [105] 246
L5: 

    /** symtab.e:558					integer scope = SymTab[p][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24935 = (object)*(((s1_ptr)_2)->base + _p_48151);
    _2 = (object)SEQ_PTR(_24935);
    _scope_48175 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_scope_48175)){
        _scope_48175 = (object)DBL_PTR(_scope_48175)->dbl;
    }
    _24935 = NOVALUE;

    /** symtab.e:559					switch scope with fallthru do*/
    _0 = _scope_48175;
    switch ( _0 ){ 

        /** symtab.e:560						case SC_PUBLIC then*/
        case 13:

        /** symtab.e:561							if and_bits( DIRECT_OR_PUBLIC_INCLUDE, include_matrix[current_file_no][sym_file] ) then*/
        _2 = (object)SEQ_PTR(_28include_matrix_11579);
        _24939 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
        _2 = (object)SEQ_PTR(_24939);
        _24940 = (object)*(((s1_ptr)_2)->base + _sym_file_48158);
        _24939 = NOVALUE;
        if (IS_ATOM_INT(_24940)) {
            {uintptr_t tu;
                 tu = (uintptr_t)6LL & (uintptr_t)_24940;
                 _24941 = MAKE_UINT(tu);
            }
        }
        else {
            _24941 = binary_op(AND_BITS, 6LL, _24940);
        }
        _24940 = NOVALUE;
        if (_24941 == 0) {
            DeRef(_24941);
            _24941 = NOVALUE;
            goto L7; // [155] 243
        }
        else {
            if (!IS_ATOM_INT(_24941) && DBL_PTR(_24941)->dbl == 0.0){
                DeRef(_24941);
                _24941 = NOVALUE;
                goto L7; // [155] 243
            }
            DeRef(_24941);
            _24941 = NOVALUE;
        }
        DeRef(_24941);
        _24941 = NOVALUE;

        /** symtab.e:562								SymTab[p][attribute] += 1*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_48151 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _24944 = (object)*(((s1_ptr)_2)->base + _attribute_48148);
        _24942 = NOVALUE;
        if (IS_ATOM_INT(_24944)) {
            _24945 = _24944 + 1;
            if (_24945 > MAXINT){
                _24945 = NewDouble((eudouble)_24945);
            }
        }
        else
        _24945 = binary_op(PLUS, 1, _24944);
        _24944 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _attribute_48148);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24945;
        if( _1 != _24945 ){
            DeRef(_1);
        }
        _24945 = NOVALUE;
        _24942 = NOVALUE;

        /** symtab.e:564							break*/
        goto L7; // [182] 243

        /** symtab.e:565						case SC_EXPORT then*/
        case 11:

        /** symtab.e:566							if not and_bits( DIRECT_INCLUDE, include_matrix[current_file_no][sym_file] ) then*/
        _2 = (object)SEQ_PTR(_28include_matrix_11579);
        _24946 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
        _2 = (object)SEQ_PTR(_24946);
        _24947 = (object)*(((s1_ptr)_2)->base + _sym_file_48158);
        _24946 = NOVALUE;
        if (IS_ATOM_INT(_24947)) {
            {uintptr_t tu;
                 tu = (uintptr_t)2LL & (uintptr_t)_24947;
                 _24948 = MAKE_UINT(tu);
            }
        }
        else {
            _24948 = binary_op(AND_BITS, 2LL, _24947);
        }
        _24947 = NOVALUE;
        if (IS_ATOM_INT(_24948)) {
            if (_24948 != 0){
                DeRef(_24948);
                _24948 = NOVALUE;
                goto L8; // [208] 216
            }
        }
        else {
            if (DBL_PTR(_24948)->dbl != 0.0){
                DeRef(_24948);
                _24948 = NOVALUE;
                goto L8; // [208] 216
            }
        }
        DeRef(_24948);
        _24948 = NOVALUE;

        /** symtab.e:567								break*/
        goto L9; // [213] 217
L8: 
L9: 

        /** symtab.e:570						case SC_GLOBAL then*/
        case 6:

        /** symtab.e:571							SymTab[p][attribute] += 1*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_48151 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _24952 = (object)*(((s1_ptr)_2)->base + _attribute_48148);
        _24950 = NOVALUE;
        if (IS_ATOM_INT(_24952)) {
            _24953 = _24952 + 1;
            if (_24953 > MAXINT){
                _24953 = NewDouble((eudouble)_24953);
            }
        }
        else
        _24953 = binary_op(PLUS, 1, _24952);
        _24952 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _attribute_48148);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24953;
        if( _1 != _24953 ){
            DeRef(_1);
        }
        _24953 = NOVALUE;
        _24950 = NOVALUE;
    ;}L7: 
L6: 

    /** symtab.e:575				p = SymTab[p][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24954 = (object)*(((s1_ptr)_2)->base + _p_48151);
    _2 = (object)SEQ_PTR(_24954);
    _p_48151 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_p_48151)){
        _p_48151 = (object)DBL_PTR(_p_48151)->dbl;
    }
    _24954 = NOVALUE;

    /** symtab.e:576			end while*/
    goto L2; // [266] 33
L3: 
L1: 

    /** symtab.e:578	end procedure*/
    DeRef(_24928);
    _24928 = NOVALUE;
    return;
    ;
}


void _53mark_rechecks(object _file_no_48224)
{
    object _recheck_targets_48227 = NOVALUE;
    object _remaining_48231 = NOVALUE;
    object _marked_48235 = NOVALUE;
    object _24961 = NOVALUE;
    object _24959 = NOVALUE;
    object _24958 = NOVALUE;
    object _24957 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_file_no_48224)) {
        _1 = (object)(DBL_PTR(_file_no_48224)->dbl);
        DeRefDS(_file_no_48224);
        _file_no_48224 = _1;
    }

    /** symtab.e:584		sequence recheck_targets = map:get( recheck_routines, file_no, {} )*/
    Ref(_53recheck_routines_48218);
    RefDS(_22218);
    _0 = _recheck_targets_48227;
    _recheck_targets_48227 = _34get(_53recheck_routines_48218, _file_no_48224, _22218);
    DeRef(_0);

    /** symtab.e:585		if length( recheck_targets ) then*/
    if (IS_SEQUENCE(_recheck_targets_48227)){
            _24957 = SEQ_PTR(_recheck_targets_48227)->length;
    }
    else {
        _24957 = 1;
    }
    if (_24957 == 0)
    {
        _24957 = NOVALUE;
        goto L1; // [20] 129
    }
    else{
        _24957 = NOVALUE;
    }

    /** symtab.e:586			sequence remaining = {}*/
    RefDS(_22218);
    DeRefi(_remaining_48231);
    _remaining_48231 = _22218;

    /** symtab.e:587			for i = length( recheck_targets ) to 1 by -1 do*/
    if (IS_SEQUENCE(_recheck_targets_48227)){
            _24958 = SEQ_PTR(_recheck_targets_48227)->length;
    }
    else {
        _24958 = 1;
    }
    {
        object _i_48233;
        _i_48233 = _24958;
L2: 
        if (_i_48233 < 1LL){
            goto L3; // [35] 117
        }

        /** symtab.e:588				integer marked = 0*/
        _marked_48235 = 0LL;

        /** symtab.e:589				if TRANSLATE then*/
        if (_27TRANSLATE_20179 == 0)
        {
            goto L4; // [51] 72
        }
        else{
        }

        /** symtab.e:590					marked = MarkTargets( recheck_targets[i], S_RI_TARGET )*/
        _2 = (object)SEQ_PTR(_recheck_targets_48227);
        _24959 = (object)*(((s1_ptr)_2)->base + _i_48233);
        Ref(_24959);
        _marked_48235 = _53MarkTargets(_24959, 53LL);
        _24959 = NOVALUE;
        if (!IS_ATOM_INT(_marked_48235)) {
            _1 = (object)(DBL_PTR(_marked_48235)->dbl);
            DeRefDS(_marked_48235);
            _marked_48235 = _1;
        }
        goto L5; // [69] 96
L4: 

        /** symtab.e:591				elsif BIND then*/
        if (_27BIND_20182 == 0)
        {
            goto L6; // [76] 95
        }
        else{
        }

        /** symtab.e:592					marked = MarkTargets( recheck_targets[i], S_NREFS )*/
        _2 = (object)SEQ_PTR(_recheck_targets_48227);
        _24961 = (object)*(((s1_ptr)_2)->base + _i_48233);
        Ref(_24961);
        _marked_48235 = _53MarkTargets(_24961, 12LL);
        _24961 = NOVALUE;
        if (!IS_ATOM_INT(_marked_48235)) {
            _1 = (object)(DBL_PTR(_marked_48235)->dbl);
            DeRefDS(_marked_48235);
            _marked_48235 = _1;
        }
L6: 
L5: 

        /** symtab.e:594				if not marked then*/
        if (_marked_48235 != 0)
        goto L7; // [98] 108

        /** symtab.e:595					remaining &= file_no*/
        Append(&_remaining_48231, _remaining_48231, _file_no_48224);
L7: 

        /** symtab.e:597			end for*/
        _i_48233 = _i_48233 + -1LL;
        goto L2; // [112] 42
L3: 
        ;
    }

    /** symtab.e:598			map:put( recheck_routines, file_no, recheck_targets )*/
    Ref(_53recheck_routines_48218);
    RefDS(_recheck_targets_48227);
    _34put(_53recheck_routines_48218, _file_no_48224, _recheck_targets_48227, 1LL, 0LL);
L1: 
    DeRefi(_remaining_48231);
    _remaining_48231 = NOVALUE;

    /** symtab.e:600	end procedure*/
    DeRef(_recheck_targets_48227);
    return;
    ;
}


void _53mark_final_targets()
{
    object _size_1__tmp_at47_48263 = NOVALUE;
    object _size_inlined_size_at_47_48262 = NOVALUE;
    object _recheck_files_48264 = NOVALUE;
    object _24967 = NOVALUE;
    object _24966 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:603		if just_mark_everything_from then*/
    if (_53just_mark_everything_from_48145 == 0)
    {
        goto L1; // [5] 44
    }
    else{
    }

    /** symtab.e:604			if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L2; // [12] 25
    }
    else{
    }

    /** symtab.e:605				mark_all( S_RI_TARGET )*/
    _53mark_all(53LL);
    goto L3; // [22] 109
L2: 

    /** symtab.e:606			elsif BIND then*/
    if (_27BIND_20182 == 0)
    {
        goto L3; // [29] 109
    }
    else{
    }

    /** symtab.e:607				mark_all( S_NREFS )*/
    _53mark_all(12LL);
    goto L3; // [41] 109
L1: 

    /** symtab.e:609		elsif map:size( recheck_routines ) then*/

    /** map.e:800		return eumem:ram_space[the_map_p][MAP_SIZE]*/
    DeRef(_size_1__tmp_at47_48263);
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!IS_ATOM_INT(_53recheck_routines_48218)){
        _size_1__tmp_at47_48263 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_53recheck_routines_48218)->dbl));
    }
    else{
        _size_1__tmp_at47_48263 = (object)*(((s1_ptr)_2)->base + _53recheck_routines_48218);
    }
    Ref(_size_1__tmp_at47_48263);
    DeRef(_size_inlined_size_at_47_48262);
    _2 = (object)SEQ_PTR(_size_1__tmp_at47_48263);
    _size_inlined_size_at_47_48262 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_size_inlined_size_at_47_48262);
    DeRef(_size_1__tmp_at47_48263);
    _size_1__tmp_at47_48263 = NOVALUE;
    if (_size_inlined_size_at_47_48262 == 0) {
        goto L4; // [63] 106
    }
    else {
        if (!IS_ATOM_INT(_size_inlined_size_at_47_48262) && DBL_PTR(_size_inlined_size_at_47_48262)->dbl == 0.0){
            goto L4; // [63] 106
        }
    }

    /** symtab.e:610			sequence recheck_files = map:keys( recheck_routines )*/
    Ref(_53recheck_routines_48218);
    _0 = _recheck_files_48264;
    _recheck_files_48264 = _34keys(_53recheck_routines_48218, 0LL);
    DeRef(_0);

    /** symtab.e:611			for i = 1 to length( recheck_files ) do*/
    if (IS_SEQUENCE(_recheck_files_48264)){
            _24966 = SEQ_PTR(_recheck_files_48264)->length;
    }
    else {
        _24966 = 1;
    }
    {
        object _i_48267;
        _i_48267 = 1LL;
L5: 
        if (_i_48267 > _24966){
            goto L6; // [82] 105
        }

        /** symtab.e:612				mark_rechecks( recheck_files[i] )*/
        _2 = (object)SEQ_PTR(_recheck_files_48264);
        _24967 = (object)*(((s1_ptr)_2)->base + _i_48267);
        Ref(_24967);
        _53mark_rechecks(_24967);
        _24967 = NOVALUE;

        /** symtab.e:613			end for*/
        _i_48267 = _i_48267 + 1LL;
        goto L5; // [100] 89
L6: 
        ;
    }
L4: 
    DeRef(_recheck_files_48264);
    _recheck_files_48264 = NOVALUE;
L3: 

    /** symtab.e:615	end procedure*/
    return;
    ;
}


object _53is_routine(object _sym_48273)
{
    object _tok_48274 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:618		integer tok = sym_token( sym )*/
    _tok_48274 = _53sym_token(_sym_48273);
    if (!IS_ATOM_INT(_tok_48274)) {
        _1 = (object)(DBL_PTR(_tok_48274)->dbl);
        DeRefDS(_tok_48274);
        _tok_48274 = _1;
    }

    /** symtab.e:619		switch tok do*/
    _0 = _tok_48274;
    switch ( _0 ){ 

        /** symtab.e:620			case FUNC, PROC, TYPE then*/
        case 501:
        case 27:
        case 504:

        /** symtab.e:621				return 1*/
        return 1LL;
        goto L1; // [32] 45

        /** symtab.e:622			case else*/
        default:

        /** symtab.e:623				return 0*/
        return 0LL;
    ;}L1: 
    ;
}


object _53is_visible(object _sym_48287, object _from_file_48288)
{
    object _scope_48289 = NOVALUE;
    object _sym_file_48292 = NOVALUE;
    object _visible_mask_48297 = NOVALUE;
    object _24979 = NOVALUE;
    object _24978 = NOVALUE;
    object _24977 = NOVALUE;
    object _24976 = NOVALUE;
    object _24972 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:628		integer scope = sym_scope( sym )*/
    _scope_48289 = _53sym_scope(_sym_48287);
    if (!IS_ATOM_INT(_scope_48289)) {
        _1 = (object)(DBL_PTR(_scope_48289)->dbl);
        DeRefDS(_scope_48289);
        _scope_48289 = _1;
    }

    /** symtab.e:629		integer sym_file = SymTab[sym][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24972 = (object)*(((s1_ptr)_2)->base + _sym_48287);
    _2 = (object)SEQ_PTR(_24972);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _sym_file_48292 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _sym_file_48292 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    if (!IS_ATOM_INT(_sym_file_48292)){
        _sym_file_48292 = (object)DBL_PTR(_sym_file_48292)->dbl;
    }
    _24972 = NOVALUE;

    /** symtab.e:631		switch scope do*/
    _0 = _scope_48289;
    switch ( _0 ){ 

        /** symtab.e:632			case SC_PUBLIC then*/
        case 13:

        /** symtab.e:633				visible_mask = DIRECT_OR_PUBLIC_INCLUDE*/
        _visible_mask_48297 = 6LL;
        goto L1; // [49] 93

        /** symtab.e:634			case SC_EXPORT then*/
        case 11:

        /** symtab.e:635				visible_mask = DIRECT_INCLUDE*/
        _visible_mask_48297 = 2LL;
        goto L1; // [64] 93

        /** symtab.e:636			case SC_GLOBAL then*/
        case 6:

        /** symtab.e:637				return 1*/
        return 1LL;
        goto L1; // [76] 93

        /** symtab.e:638			case else*/
        default:

        /** symtab.e:639				return from_file = sym_file*/
        _24976 = (_from_file_48288 == _sym_file_48292);
        return _24976;
    ;}L1: 

    /** symtab.e:641		return and_bits( visible_mask, include_matrix[from_file][sym_file] )*/
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _24977 = (object)*(((s1_ptr)_2)->base + _from_file_48288);
    _2 = (object)SEQ_PTR(_24977);
    _24978 = (object)*(((s1_ptr)_2)->base + _sym_file_48292);
    _24977 = NOVALUE;
    if (IS_ATOM_INT(_24978)) {
        {uintptr_t tu;
             tu = (uintptr_t)_visible_mask_48297 & (uintptr_t)_24978;
             _24979 = MAKE_UINT(tu);
        }
    }
    else {
        _24979 = binary_op(AND_BITS, _visible_mask_48297, _24978);
    }
    _24978 = NOVALUE;
    DeRef(_24976);
    _24976 = NOVALUE;
    return _24979;
    ;
}


object _53MarkTargets(object _s_48317, object _attribute_48318)
{
    object _p_48320 = NOVALUE;
    object _sname_48321 = NOVALUE;
    object _string_48322 = NOVALUE;
    object _colon_48323 = NOVALUE;
    object _h_48324 = NOVALUE;
    object _scope_48325 = NOVALUE;
    object _found_48346 = NOVALUE;
    object _25027 = NOVALUE;
    object _25025 = NOVALUE;
    object _25024 = NOVALUE;
    object _25023 = NOVALUE;
    object _25022 = NOVALUE;
    object _25020 = NOVALUE;
    object _25019 = NOVALUE;
    object _25018 = NOVALUE;
    object _25017 = NOVALUE;
    object _25016 = NOVALUE;
    object _25014 = NOVALUE;
    object _25013 = NOVALUE;
    object _25012 = NOVALUE;
    object _25010 = NOVALUE;
    object _25008 = NOVALUE;
    object _25006 = NOVALUE;
    object _25005 = NOVALUE;
    object _25004 = NOVALUE;
    object _25003 = NOVALUE;
    object _25001 = NOVALUE;
    object _25000 = NOVALUE;
    object _24999 = NOVALUE;
    object _24998 = NOVALUE;
    object _24996 = NOVALUE;
    object _24995 = NOVALUE;
    object _24991 = NOVALUE;
    object _24990 = NOVALUE;
    object _24989 = NOVALUE;
    object _24988 = NOVALUE;
    object _24987 = NOVALUE;
    object _24986 = NOVALUE;
    object _24985 = NOVALUE;
    object _24984 = NOVALUE;
    object _24983 = NOVALUE;
    object _24982 = NOVALUE;
    object _24981 = NOVALUE;
    object _24980 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_48317)) {
        _1 = (object)(DBL_PTR(_s_48317)->dbl);
        DeRefDS(_s_48317);
        _s_48317 = _1;
    }

    /** symtab.e:648		sequence sname*/

    /** symtab.e:649		sequence string*/

    /** symtab.e:650		integer colon, h*/

    /** symtab.e:651		integer scope*/

    /** symtab.e:653		if (SymTab[s][S_MODE] = M_TEMP or*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24980 = (object)*(((s1_ptr)_2)->base + _s_48317);
    _2 = (object)SEQ_PTR(_24980);
    _24981 = (object)*(((s1_ptr)_2)->base + 3LL);
    _24980 = NOVALUE;
    if (IS_ATOM_INT(_24981)) {
        _24982 = (_24981 == 3LL);
    }
    else {
        _24982 = binary_op(EQUALS, _24981, 3LL);
    }
    _24981 = NOVALUE;
    if (IS_ATOM_INT(_24982)) {
        if (_24982 != 0) {
            _24983 = 1;
            goto L1; // [33] 59
        }
    }
    else {
        if (DBL_PTR(_24982)->dbl != 0.0) {
            _24983 = 1;
            goto L1; // [33] 59
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24984 = (object)*(((s1_ptr)_2)->base + _s_48317);
    _2 = (object)SEQ_PTR(_24984);
    _24985 = (object)*(((s1_ptr)_2)->base + 3LL);
    _24984 = NOVALUE;
    if (IS_ATOM_INT(_24985)) {
        _24986 = (_24985 == 2LL);
    }
    else {
        _24986 = binary_op(EQUALS, _24985, 2LL);
    }
    _24985 = NOVALUE;
    DeRef(_24983);
    if (IS_ATOM_INT(_24986))
    _24983 = (_24986 != 0);
    else
    _24983 = DBL_PTR(_24986)->dbl != 0.0;
L1: 
    if (_24983 == 0) {
        goto L2; // [59] 411
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24988 = (object)*(((s1_ptr)_2)->base + _s_48317);
    _2 = (object)SEQ_PTR(_24988);
    _24989 = (object)*(((s1_ptr)_2)->base + 1LL);
    _24988 = NOVALUE;
    _24990 = IS_SEQUENCE(_24989);
    _24989 = NOVALUE;
    if (_24990 == 0)
    {
        _24990 = NOVALUE;
        goto L2; // [79] 411
    }
    else{
        _24990 = NOVALUE;
    }

    /** symtab.e:658			integer found = 0*/
    _found_48346 = 0LL;

    /** symtab.e:660			string = SymTab[s][S_OBJ]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24991 = (object)*(((s1_ptr)_2)->base + _s_48317);
    DeRef(_string_48322);
    _2 = (object)SEQ_PTR(_24991);
    _string_48322 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_string_48322);
    _24991 = NOVALUE;

    /** symtab.e:661			colon = find(':', string)*/
    _colon_48323 = find_from(58LL, _string_48322, 1LL);

    /** symtab.e:662			if colon = 0 then*/
    if (_colon_48323 != 0LL)
    goto L3; // [112] 126

    /** symtab.e:663				sname = string*/
    RefDS(_string_48322);
    DeRef(_sname_48321);
    _sname_48321 = _string_48322;
    goto L4; // [123] 200
L3: 

    /** symtab.e:665				sname = string[colon+1..$]  -- ignore namespace part*/
    _24995 = _colon_48323 + 1;
    if (_24995 > MAXINT){
        _24995 = NewDouble((eudouble)_24995);
    }
    if (IS_SEQUENCE(_string_48322)){
            _24996 = SEQ_PTR(_string_48322)->length;
    }
    else {
        _24996 = 1;
    }
    rhs_slice_target = (object_ptr)&_sname_48321;
    RHS_Slice(_string_48322, _24995, _24996);

    /** symtab.e:666				while length(sname) and sname[1] = ' ' or sname[1] = '\t' do*/
L5: 
    if (IS_SEQUENCE(_sname_48321)){
            _24998 = SEQ_PTR(_sname_48321)->length;
    }
    else {
        _24998 = 1;
    }
    if (_24998 == 0) {
        _24999 = 0;
        goto L6; // [148] 164
    }
    _2 = (object)SEQ_PTR(_sname_48321);
    _25000 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_25000)) {
        _25001 = (_25000 == 32LL);
    }
    else {
        _25001 = binary_op(EQUALS, _25000, 32LL);
    }
    _25000 = NOVALUE;
    if (IS_ATOM_INT(_25001))
    _24999 = (_25001 != 0);
    else
    _24999 = DBL_PTR(_25001)->dbl != 0.0;
L6: 
    if (_24999 != 0) {
        goto L7; // [164] 181
    }
    _2 = (object)SEQ_PTR(_sname_48321);
    _25003 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_25003)) {
        _25004 = (_25003 == 9LL);
    }
    else {
        _25004 = binary_op(EQUALS, _25003, 9LL);
    }
    _25003 = NOVALUE;
    if (_25004 <= 0) {
        if (_25004 == 0) {
            DeRef(_25004);
            _25004 = NOVALUE;
            goto L8; // [177] 199
        }
        else {
            if (!IS_ATOM_INT(_25004) && DBL_PTR(_25004)->dbl == 0.0){
                DeRef(_25004);
                _25004 = NOVALUE;
                goto L8; // [177] 199
            }
            DeRef(_25004);
            _25004 = NOVALUE;
        }
    }
    DeRef(_25004);
    _25004 = NOVALUE;
L7: 

    /** symtab.e:667					sname = tail( sname, length( sname ) -1 )*/
    if (IS_SEQUENCE(_sname_48321)){
            _25005 = SEQ_PTR(_sname_48321)->length;
    }
    else {
        _25005 = 1;
    }
    _25006 = _25005 - 1LL;
    _25005 = NOVALUE;
    {
        int len = SEQ_PTR(_sname_48321)->length;
        int size = (IS_ATOM_INT(_25006)) ? _25006 : (object)(DBL_PTR(_25006)->dbl);
        if (size <= 0) {
            DeRef(_sname_48321);
            _sname_48321 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_sname_48321);
            DeRef(_sname_48321);
            _sname_48321 = _sname_48321;
        }
        else Tail(SEQ_PTR(_sname_48321), len-size+1, &_sname_48321);
    }
    _25006 = NOVALUE;

    /** symtab.e:668				end while*/
    goto L5; // [196] 145
L8: 
L4: 

    /** symtab.e:671			if length(sname) = 0 then*/
    if (IS_SEQUENCE(_sname_48321)){
            _25008 = SEQ_PTR(_sname_48321)->length;
    }
    else {
        _25008 = 1;
    }
    if (_25008 != 0LL)
    goto L9; // [207] 218

    /** symtab.e:672				return 1*/
    DeRefDS(_sname_48321);
    DeRef(_string_48322);
    DeRef(_25001);
    _25001 = NOVALUE;
    DeRef(_24995);
    _24995 = NOVALUE;
    DeRef(_24982);
    _24982 = NOVALUE;
    DeRef(_24986);
    _24986 = NOVALUE;
    return 1LL;
L9: 

    /** symtab.e:674			h = buckets[hashfn(sname)]*/
    RefDS(_sname_48321);
    _25010 = _53hashfn(_sname_48321);
    _2 = (object)SEQ_PTR(_53buckets_47223);
    if (!IS_ATOM_INT(_25010)){
        _h_48324 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25010)->dbl));
    }
    else{
        _h_48324 = (object)*(((s1_ptr)_2)->base + _25010);
    }
    if (!IS_ATOM_INT(_h_48324))
    _h_48324 = (object)DBL_PTR(_h_48324)->dbl;

    /** symtab.e:675			while h do*/
LA: 
    if (_h_48324 == 0)
    {
        goto LB; // [235] 381
    }
    else{
    }

    /** symtab.e:676				if equal(sname, SymTab[h][S_NAME]) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25012 = (object)*(((s1_ptr)_2)->base + _h_48324);
    _2 = (object)SEQ_PTR(_25012);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _25013 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _25013 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _25012 = NOVALUE;
    if (_sname_48321 == _25013)
    _25014 = 1;
    else if (IS_ATOM_INT(_sname_48321) && IS_ATOM_INT(_25013))
    _25014 = 0;
    else
    _25014 = (compare(_sname_48321, _25013) == 0);
    _25013 = NOVALUE;
    if (_25014 == 0)
    {
        _25014 = NOVALUE;
        goto LC; // [256] 360
    }
    else{
        _25014 = NOVALUE;
    }

    /** symtab.e:677					if attribute = S_NREFS then*/
    if (_attribute_48318 != 12LL)
    goto LD; // [263] 289

    /** symtab.e:678						if BIND then*/
    if (_27BIND_20182 == 0)
    {
        goto LE; // [271] 359
    }
    else{
    }

    /** symtab.e:679							add_ref({PROC, h})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 27LL;
    ((intptr_t *)_2)[2] = _h_48324;
    _25016 = MAKE_SEQ(_1);
    _53add_ref(_25016);
    _25016 = NOVALUE;
    goto LE; // [286] 359
LD: 

    /** symtab.e:681					elsif is_routine( h ) and is_visible( h, current_file_no ) then*/
    _25017 = _53is_routine(_h_48324);
    if (IS_ATOM_INT(_25017)) {
        if (_25017 == 0) {
            goto LF; // [295] 358
        }
    }
    else {
        if (DBL_PTR(_25017)->dbl == 0.0) {
            goto LF; // [295] 358
        }
    }
    _25019 = _53is_visible(_h_48324, _27current_file_no_20571);
    if (_25019 == 0) {
        DeRef(_25019);
        _25019 = NOVALUE;
        goto LF; // [307] 358
    }
    else {
        if (!IS_ATOM_INT(_25019) && DBL_PTR(_25019)->dbl == 0.0){
            DeRef(_25019);
            _25019 = NOVALUE;
            goto LF; // [307] 358
        }
        DeRef(_25019);
        _25019 = NOVALUE;
    }
    DeRef(_25019);
    _25019 = NOVALUE;

    /** symtab.e:682						SymTab[h][attribute] += 1*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_h_48324 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _25022 = (object)*(((s1_ptr)_2)->base + _attribute_48318);
    _25020 = NOVALUE;
    if (IS_ATOM_INT(_25022)) {
        _25023 = _25022 + 1;
        if (_25023 > MAXINT){
            _25023 = NewDouble((eudouble)_25023);
        }
    }
    else
    _25023 = binary_op(PLUS, 1, _25022);
    _25022 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _attribute_48318);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25023;
    if( _1 != _25023 ){
        DeRef(_1);
    }
    _25023 = NOVALUE;
    _25020 = NOVALUE;

    /** symtab.e:683						if current_file_no = SymTab[h][S_FILE_NO] then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25024 = (object)*(((s1_ptr)_2)->base + _h_48324);
    _2 = (object)SEQ_PTR(_25024);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _25025 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _25025 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _25024 = NOVALUE;
    if (binary_op_a(NOTEQ, _27current_file_no_20571, _25025)){
        _25025 = NOVALUE;
        goto L10; // [347] 357
    }
    _25025 = NOVALUE;

    /** symtab.e:684							found = 1*/
    _found_48346 = 1LL;
L10: 
LF: 
LE: 
LC: 

    /** symtab.e:688				h = SymTab[h][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25027 = (object)*(((s1_ptr)_2)->base + _h_48324);
    _2 = (object)SEQ_PTR(_25027);
    _h_48324 = (object)*(((s1_ptr)_2)->base + 9LL);
    if (!IS_ATOM_INT(_h_48324)){
        _h_48324 = (object)DBL_PTR(_h_48324)->dbl;
    }
    _25027 = NOVALUE;

    /** symtab.e:689			end while*/
    goto LA; // [378] 235
LB: 

    /** symtab.e:691			if not found then*/
    if (_found_48346 != 0)
    goto L11; // [383] 400

    /** symtab.e:692				map:put( recheck_routines, current_file_no, s, map:APPEND )*/
    Ref(_53recheck_routines_48218);
    _34put(_53recheck_routines_48218, _27current_file_no_20571, _s_48317, 6LL, 0LL);
L11: 

    /** symtab.e:694			return found*/
    DeRef(_sname_48321);
    DeRef(_string_48322);
    DeRef(_25017);
    _25017 = NOVALUE;
    DeRef(_25001);
    _25001 = NOVALUE;
    DeRef(_24995);
    _24995 = NOVALUE;
    DeRef(_25010);
    _25010 = NOVALUE;
    DeRef(_24982);
    _24982 = NOVALUE;
    DeRef(_24986);
    _24986 = NOVALUE;
    return _found_48346;
    goto L12; // [408] 440
L2: 

    /** symtab.e:696			if not just_mark_everything_from then*/
    if (_53just_mark_everything_from_48145 != 0)
    goto L13; // [415] 428

    /** symtab.e:697				just_mark_everything_from = TopLevelSub*/
    _53just_mark_everything_from_48145 = _27TopLevelSub_20578;
L13: 

    /** symtab.e:699			mark_all( attribute )*/
    _53mark_all(_attribute_48318);

    /** symtab.e:700			return 1*/
    DeRef(_sname_48321);
    DeRef(_string_48322);
    DeRef(_25017);
    _25017 = NOVALUE;
    DeRef(_25001);
    _25001 = NOVALUE;
    DeRef(_24995);
    _24995 = NOVALUE;
    DeRef(_25010);
    _25010 = NOVALUE;
    DeRef(_24982);
    _24982 = NOVALUE;
    DeRef(_24986);
    _24986 = NOVALUE;
    return 1LL;
L12: 
    ;
}


void _53resolve_unincluded_globals(object _ok_48424)
{
    object _0, _1, _2;
    

    /** symtab.e:724		Resolve_unincluded_globals = ok*/
    _53Resolve_unincluded_globals_48421 = 1LL;

    /** symtab.e:725	end procedure*/
    return;
    ;
}


object _53get_resolve_unincluded_globals()
{
    object _0, _1, _2;
    

    /** symtab.e:728		return Resolve_unincluded_globals*/
    return _53Resolve_unincluded_globals_48421;
    ;
}


object _53keyfind(object _word_48430, object _file_no_48431, object _scanning_file_48432, object _namespace_ok_48435, object _hashval_48436)
{
    object _msg_48438 = NOVALUE;
    object _b_name_48439 = NOVALUE;
    object _scope_48440 = NOVALUE;
    object _defined_48441 = NOVALUE;
    object _ix_48442 = NOVALUE;
    object _st_ptr_48444 = NOVALUE;
    object _st_builtin_48445 = NOVALUE;
    object _tok_48447 = NOVALUE;
    object _gtok_48448 = NOVALUE;
    object _any_symbol_48451 = NOVALUE;
    object _tok_file_48619 = NOVALUE;
    object _good_48626 = NOVALUE;
    object _include_type_48636 = NOVALUE;
    object _msg_file_48692 = NOVALUE;
    object _25222 = NOVALUE;
    object _25221 = NOVALUE;
    object _25219 = NOVALUE;
    object _25217 = NOVALUE;
    object _25216 = NOVALUE;
    object _25215 = NOVALUE;
    object _25214 = NOVALUE;
    object _25213 = NOVALUE;
    object _25211 = NOVALUE;
    object _25209 = NOVALUE;
    object _25208 = NOVALUE;
    object _25207 = NOVALUE;
    object _25206 = NOVALUE;
    object _25205 = NOVALUE;
    object _25204 = NOVALUE;
    object _25203 = NOVALUE;
    object _25202 = NOVALUE;
    object _25200 = NOVALUE;
    object _25199 = NOVALUE;
    object _25198 = NOVALUE;
    object _25197 = NOVALUE;
    object _25196 = NOVALUE;
    object _25195 = NOVALUE;
    object _25194 = NOVALUE;
    object _25193 = NOVALUE;
    object _25192 = NOVALUE;
    object _25191 = NOVALUE;
    object _25190 = NOVALUE;
    object _25189 = NOVALUE;
    object _25188 = NOVALUE;
    object _25187 = NOVALUE;
    object _25186 = NOVALUE;
    object _25185 = NOVALUE;
    object _25184 = NOVALUE;
    object _25182 = NOVALUE;
    object _25181 = NOVALUE;
    object _25178 = NOVALUE;
    object _25174 = NOVALUE;
    object _25172 = NOVALUE;
    object _25171 = NOVALUE;
    object _25170 = NOVALUE;
    object _25169 = NOVALUE;
    object _25168 = NOVALUE;
    object _25166 = NOVALUE;
    object _25165 = NOVALUE;
    object _25164 = NOVALUE;
    object _25163 = NOVALUE;
    object _25161 = NOVALUE;
    object _25158 = NOVALUE;
    object _25157 = NOVALUE;
    object _25156 = NOVALUE;
    object _25155 = NOVALUE;
    object _25153 = NOVALUE;
    object _25150 = NOVALUE;
    object _25149 = NOVALUE;
    object _25148 = NOVALUE;
    object _25147 = NOVALUE;
    object _25146 = NOVALUE;
    object _25145 = NOVALUE;
    object _25144 = NOVALUE;
    object _25141 = NOVALUE;
    object _25140 = NOVALUE;
    object _25138 = NOVALUE;
    object _25136 = NOVALUE;
    object _25134 = NOVALUE;
    object _25133 = NOVALUE;
    object _25132 = NOVALUE;
    object _25128 = NOVALUE;
    object _25127 = NOVALUE;
    object _25122 = NOVALUE;
    object _25120 = NOVALUE;
    object _25118 = NOVALUE;
    object _25117 = NOVALUE;
    object _25113 = NOVALUE;
    object _25112 = NOVALUE;
    object _25110 = NOVALUE;
    object _25109 = NOVALUE;
    object _25107 = NOVALUE;
    object _25106 = NOVALUE;
    object _25105 = NOVALUE;
    object _25104 = NOVALUE;
    object _25103 = NOVALUE;
    object _25101 = NOVALUE;
    object _25100 = NOVALUE;
    object _25099 = NOVALUE;
    object _25098 = NOVALUE;
    object _25097 = NOVALUE;
    object _25096 = NOVALUE;
    object _25095 = NOVALUE;
    object _25094 = NOVALUE;
    object _25093 = NOVALUE;
    object _25092 = NOVALUE;
    object _25091 = NOVALUE;
    object _25090 = NOVALUE;
    object _25089 = NOVALUE;
    object _25088 = NOVALUE;
    object _25087 = NOVALUE;
    object _25086 = NOVALUE;
    object _25085 = NOVALUE;
    object _25084 = NOVALUE;
    object _25083 = NOVALUE;
    object _25082 = NOVALUE;
    object _25081 = NOVALUE;
    object _25080 = NOVALUE;
    object _25078 = NOVALUE;
    object _25077 = NOVALUE;
    object _25075 = NOVALUE;
    object _25074 = NOVALUE;
    object _25073 = NOVALUE;
    object _25072 = NOVALUE;
    object _25071 = NOVALUE;
    object _25069 = NOVALUE;
    object _25068 = NOVALUE;
    object _25067 = NOVALUE;
    object _25065 = NOVALUE;
    object _25064 = NOVALUE;
    object _25063 = NOVALUE;
    object _25062 = NOVALUE;
    object _25061 = NOVALUE;
    object _25060 = NOVALUE;
    object _25059 = NOVALUE;
    object _25057 = NOVALUE;
    object _25056 = NOVALUE;
    object _25051 = NOVALUE;
    object _25048 = NOVALUE;
    object _25047 = NOVALUE;
    object _25046 = NOVALUE;
    object _25045 = NOVALUE;
    object _25044 = NOVALUE;
    object _25043 = NOVALUE;
    object _25042 = NOVALUE;
    object _25041 = NOVALUE;
    object _25040 = NOVALUE;
    object _25039 = NOVALUE;
    object _25038 = NOVALUE;
    object _25037 = NOVALUE;
    object _25036 = NOVALUE;
    object _25035 = NOVALUE;
    object _25034 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_file_no_48431)) {
        _1 = (object)(DBL_PTR(_file_no_48431)->dbl);
        DeRefDS(_file_no_48431);
        _file_no_48431 = _1;
    }
    if (!IS_ATOM_INT(_hashval_48436)) {
        _1 = (object)(DBL_PTR(_hashval_48436)->dbl);
        DeRefDS(_hashval_48436);
        _hashval_48436 = _1;
    }

    /** symtab.e:750		dup_globals = {}*/
    RefDS(_22218);
    DeRef(_53dup_globals_48416);
    _53dup_globals_48416 = _22218;

    /** symtab.e:751		dup_overrides = {}*/
    RefDS(_22218);
    DeRefi(_53dup_overrides_48417);
    _53dup_overrides_48417 = _22218;

    /** symtab.e:752		in_include_path = {}*/
    RefDS(_22218);
    DeRef(_53in_include_path_48418);
    _53in_include_path_48418 = _22218;

    /** symtab.e:753		symbol_resolution_warning = ""*/
    RefDS(_22218);
    DeRef(_27symbol_resolution_warning_20673);
    _27symbol_resolution_warning_20673 = _22218;

    /** symtab.e:754		st_builtin = 0*/
    _st_builtin_48445 = 0LL;

    /** symtab.e:756		ifdef EUDIS then*/

    /** symtab.e:759		st_ptr = buckets[hashval]*/
    _2 = (object)SEQ_PTR(_53buckets_47223);
    _st_ptr_48444 = (object)*(((s1_ptr)_2)->base + _hashval_48436);
    if (!IS_ATOM_INT(_st_ptr_48444)){
        _st_ptr_48444 = (object)DBL_PTR(_st_ptr_48444)->dbl;
    }

    /** symtab.e:760		integer any_symbol = namespace_ok = -1*/
    _any_symbol_48451 = (_namespace_ok_48435 == -1LL);

    /** symtab.e:761		while st_ptr do*/
L1: 
    if (_st_ptr_48444 == 0)
    {
        goto L2; // [69] 1033
    }
    else{
    }

    /** symtab.e:762			if SymTab[st_ptr][S_SCOPE] != SC_UNDEFINED */
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25034 = (object)*(((s1_ptr)_2)->base + _st_ptr_48444);
    _2 = (object)SEQ_PTR(_25034);
    _25035 = (object)*(((s1_ptr)_2)->base + 4LL);
    _25034 = NOVALUE;
    if (IS_ATOM_INT(_25035)) {
        _25036 = (_25035 != 9LL);
    }
    else {
        _25036 = binary_op(NOTEQ, _25035, 9LL);
    }
    _25035 = NOVALUE;
    if (IS_ATOM_INT(_25036)) {
        if (_25036 == 0) {
            DeRef(_25037);
            _25037 = 0;
            goto L3; // [92] 116
        }
    }
    else {
        if (DBL_PTR(_25036)->dbl == 0.0) {
            DeRef(_25037);
            _25037 = 0;
            goto L3; // [92] 116
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25038 = (object)*(((s1_ptr)_2)->base + _st_ptr_48444);
    _2 = (object)SEQ_PTR(_25038);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _25039 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _25039 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _25038 = NOVALUE;
    if (_word_48430 == _25039)
    _25040 = 1;
    else if (IS_ATOM_INT(_word_48430) && IS_ATOM_INT(_25039))
    _25040 = 0;
    else
    _25040 = (compare(_word_48430, _25039) == 0);
    _25039 = NOVALUE;
    DeRef(_25037);
    _25037 = (_25040 != 0);
L3: 
    if (_25037 == 0) {
        goto L4; // [116] 1012
    }
    if (_any_symbol_48451 != 0) {
        DeRef(_25042);
        _25042 = 1;
        goto L5; // [120] 150
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25043 = (object)*(((s1_ptr)_2)->base + _st_ptr_48444);
    _2 = (object)SEQ_PTR(_25043);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _25044 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _25044 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _25043 = NOVALUE;
    if (IS_ATOM_INT(_25044)) {
        _25045 = (_25044 == 523LL);
    }
    else {
        _25045 = binary_op(EQUALS, _25044, 523LL);
    }
    _25044 = NOVALUE;
    if (IS_ATOM_INT(_25045)) {
        _25046 = (_namespace_ok_48435 == _25045);
    }
    else {
        _25046 = binary_op(EQUALS, _namespace_ok_48435, _25045);
    }
    DeRef(_25045);
    _25045 = NOVALUE;
    if (IS_ATOM_INT(_25046))
    _25042 = (_25046 != 0);
    else
    _25042 = DBL_PTR(_25046)->dbl != 0.0;
L5: 
    if (_25042 == 0)
    {
        _25042 = NOVALUE;
        goto L4; // [151] 1012
    }
    else{
        _25042 = NOVALUE;
    }

    /** symtab.e:767				tok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25047 = (object)*(((s1_ptr)_2)->base + _st_ptr_48444);
    _2 = (object)SEQ_PTR(_25047);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _25048 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _25048 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _25047 = NOVALUE;
    Ref(_25048);
    DeRef(_tok_48447);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _25048;
    ((intptr_t *)_2)[2] = _st_ptr_48444;
    _tok_48447 = MAKE_SEQ(_1);
    _25048 = NOVALUE;

    /** symtab.e:769				if file_no = -1 then*/
    if (_file_no_48431 != -1LL)
    goto L6; // [174] 714

    /** symtab.e:774					scope = SymTab[st_ptr][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25051 = (object)*(((s1_ptr)_2)->base + _st_ptr_48444);
    _2 = (object)SEQ_PTR(_25051);
    _scope_48440 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_scope_48440)){
        _scope_48440 = (object)DBL_PTR(_scope_48440)->dbl;
    }
    _25051 = NOVALUE;

    /** symtab.e:776					switch scope with fallthru do*/
    _0 = _scope_48440;
    switch ( _0 ){ 

        /** symtab.e:777					case SC_OVERRIDE then*/
        case 12:

        /** symtab.e:778						dup_overrides &= st_ptr*/
        Append(&_53dup_overrides_48417, _53dup_overrides_48417, _st_ptr_48444);

        /** symtab.e:779						break*/
        goto L7; // [215] 1011

        /** symtab.e:781					case SC_PREDEF then*/
        case 7:

        /** symtab.e:782						st_builtin = st_ptr*/
        _st_builtin_48445 = _st_ptr_48444;

        /** symtab.e:783						break*/
        goto L7; // [230] 1011

        /** symtab.e:784					case SC_GLOBAL then*/
        case 6:

        /** symtab.e:785						if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _25056 = (object)*(((s1_ptr)_2)->base + _st_ptr_48444);
        _2 = (object)SEQ_PTR(_25056);
        if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
            _25057 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
        }
        else{
            _25057 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
        }
        _25056 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_48432, _25057)){
            _25057 = NOVALUE;
            goto L8; // [250] 274
        }
        _25057 = NOVALUE;

        /** symtab.e:788							if BIND then*/
        if (_27BIND_20182 == 0)
        {
            goto L9; // [258] 267
        }
        else{
        }

        /** symtab.e:789								add_ref(tok)*/
        Ref(_tok_48447);
        _53add_ref(_tok_48447);
L9: 

        /** symtab.e:792							return tok*/
        DeRefDS(_word_48430);
        DeRef(_msg_48438);
        DeRef(_b_name_48439);
        DeRef(_gtok_48448);
        DeRef(_25036);
        _25036 = NOVALUE;
        DeRef(_25046);
        _25046 = NOVALUE;
        return _tok_48447;
L8: 

        /** symtab.e:796						if Resolve_unincluded_globals */
        if (_53Resolve_unincluded_globals_48421 != 0) {
            _25059 = 1;
            goto LA; // [278] 322
        }
        _2 = (object)SEQ_PTR(_28finished_files_11575);
        _25060 = (object)*(((s1_ptr)_2)->base + _scanning_file_48432);
        if (_25060 == 0) {
            _25061 = 0;
            goto LB; // [288] 318
        }
        _2 = (object)SEQ_PTR(_28include_matrix_11579);
        _25062 = (object)*(((s1_ptr)_2)->base + _scanning_file_48432);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _25063 = (object)*(((s1_ptr)_2)->base + _st_ptr_48444);
        _2 = (object)SEQ_PTR(_25063);
        if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
            _25064 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
        }
        else{
            _25064 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
        }
        _25063 = NOVALUE;
        _2 = (object)SEQ_PTR(_25062);
        if (!IS_ATOM_INT(_25064)){
            _25065 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25064)->dbl));
        }
        else{
            _25065 = (object)*(((s1_ptr)_2)->base + _25064);
        }
        _25062 = NOVALUE;
        if (IS_ATOM_INT(_25065))
        _25061 = (_25065 != 0);
        else
        _25061 = DBL_PTR(_25065)->dbl != 0.0;
LB: 
        _25059 = (_25061 != 0);
LA: 
        if (_25059 != 0) {
            goto LC; // [322] 349
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _25067 = (object)*(((s1_ptr)_2)->base + _st_ptr_48444);
        _2 = (object)SEQ_PTR(_25067);
        if (!IS_ATOM_INT(_27S_TOKEN_20214)){
            _25068 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
        }
        else{
            _25068 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
        }
        _25067 = NOVALUE;
        if (IS_ATOM_INT(_25068)) {
            _25069 = (_25068 == 523LL);
        }
        else {
            _25069 = binary_op(EQUALS, _25068, 523LL);
        }
        _25068 = NOVALUE;
        if (_25069 == 0) {
            DeRef(_25069);
            _25069 = NOVALUE;
            goto L7; // [345] 1011
        }
        else {
            if (!IS_ATOM_INT(_25069) && DBL_PTR(_25069)->dbl == 0.0){
                DeRef(_25069);
                _25069 = NOVALUE;
                goto L7; // [345] 1011
            }
            DeRef(_25069);
            _25069 = NOVALUE;
        }
        DeRef(_25069);
        _25069 = NOVALUE;
LC: 

        /** symtab.e:800							gtok = tok*/
        Ref(_tok_48447);
        DeRef(_gtok_48448);
        _gtok_48448 = _tok_48447;

        /** symtab.e:801							dup_globals &= st_ptr*/
        Append(&_53dup_globals_48416, _53dup_globals_48416, _st_ptr_48444);

        /** symtab.e:802							in_include_path &= include_matrix[scanning_file][SymTab[st_ptr][S_FILE_NO]] != 0*/
        _2 = (object)SEQ_PTR(_28include_matrix_11579);
        _25071 = (object)*(((s1_ptr)_2)->base + _scanning_file_48432);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _25072 = (object)*(((s1_ptr)_2)->base + _st_ptr_48444);
        _2 = (object)SEQ_PTR(_25072);
        if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
            _25073 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
        }
        else{
            _25073 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
        }
        _25072 = NOVALUE;
        _2 = (object)SEQ_PTR(_25071);
        if (!IS_ATOM_INT(_25073)){
            _25074 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25073)->dbl));
        }
        else{
            _25074 = (object)*(((s1_ptr)_2)->base + _25073);
        }
        _25071 = NOVALUE;
        if (IS_ATOM_INT(_25074)) {
            _25075 = (_25074 != 0LL);
        }
        else {
            _25075 = binary_op(NOTEQ, _25074, 0LL);
        }
        _25074 = NOVALUE;
        if (IS_SEQUENCE(_53in_include_path_48418) && IS_ATOM(_25075)) {
            Ref(_25075);
            Append(&_53in_include_path_48418, _53in_include_path_48418, _25075);
        }
        else if (IS_ATOM(_53in_include_path_48418) && IS_SEQUENCE(_25075)) {
        }
        else {
            Concat((object_ptr)&_53in_include_path_48418, _53in_include_path_48418, _25075);
        }
        DeRef(_25075);
        _25075 = NOVALUE;

        /** symtab.e:804						break*/
        goto L7; // [399] 1011

        /** symtab.e:807					case SC_PUBLIC, SC_EXPORT then*/
        case 13:
        case 11:

        /** symtab.e:809						if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _25077 = (object)*(((s1_ptr)_2)->base + _st_ptr_48444);
        _2 = (object)SEQ_PTR(_25077);
        if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
            _25078 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
        }
        else{
            _25078 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
        }
        _25077 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_48432, _25078)){
            _25078 = NOVALUE;
            goto LD; // [421] 445
        }
        _25078 = NOVALUE;

        /** symtab.e:811							if BIND then*/
        if (_27BIND_20182 == 0)
        {
            goto LE; // [429] 438
        }
        else{
        }

        /** symtab.e:812								add_ref(tok)*/
        Ref(_tok_48447);
        _53add_ref(_tok_48447);
LE: 

        /** symtab.e:815							return tok*/
        DeRefDS(_word_48430);
        DeRef(_msg_48438);
        DeRef(_b_name_48439);
        DeRef(_gtok_48448);
        DeRef(_25036);
        _25036 = NOVALUE;
        _25064 = NOVALUE;
        _25060 = NOVALUE;
        DeRef(_25046);
        _25046 = NOVALUE;
        _25073 = NOVALUE;
        _25065 = NOVALUE;
        return _tok_48447;
LD: 

        /** symtab.e:818						if (finished_files[scanning_file] -- everything this file needs has been read in*/
        _2 = (object)SEQ_PTR(_28finished_files_11575);
        _25080 = (object)*(((s1_ptr)_2)->base + _scanning_file_48432);
        if (_25080 != 0) {
            _25081 = 1;
            goto LF; // [453] 487
        }
        if (_namespace_ok_48435 == 0) {
            _25082 = 0;
            goto L10; // [457] 483
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _25083 = (object)*(((s1_ptr)_2)->base + _st_ptr_48444);
        _2 = (object)SEQ_PTR(_25083);
        if (!IS_ATOM_INT(_27S_TOKEN_20214)){
            _25084 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
        }
        else{
            _25084 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
        }
        _25083 = NOVALUE;
        if (IS_ATOM_INT(_25084)) {
            _25085 = (_25084 == 523LL);
        }
        else {
            _25085 = binary_op(EQUALS, _25084, 523LL);
        }
        _25084 = NOVALUE;
        if (IS_ATOM_INT(_25085))
        _25082 = (_25085 != 0);
        else
        _25082 = DBL_PTR(_25085)->dbl != 0.0;
L10: 
        _25081 = (_25082 != 0);
LF: 
        if (_25081 == 0) {
            goto L7; // [487] 1011
        }
        _25087 = (_scope_48440 == 13LL);
        if (_25087 == 0) {
            _25088 = 0;
            goto L11; // [497] 533
        }
        _2 = (object)SEQ_PTR(_28include_matrix_11579);
        _25089 = (object)*(((s1_ptr)_2)->base + _scanning_file_48432);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _25090 = (object)*(((s1_ptr)_2)->base + _st_ptr_48444);
        _2 = (object)SEQ_PTR(_25090);
        if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
            _25091 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
        }
        else{
            _25091 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
        }
        _25090 = NOVALUE;
        _2 = (object)SEQ_PTR(_25089);
        if (!IS_ATOM_INT(_25091)){
            _25092 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25091)->dbl));
        }
        else{
            _25092 = (object)*(((s1_ptr)_2)->base + _25091);
        }
        _25089 = NOVALUE;
        if (IS_ATOM_INT(_25092)) {
            {uintptr_t tu;
                 tu = (uintptr_t)6LL & (uintptr_t)_25092;
                 _25093 = MAKE_UINT(tu);
            }
        }
        else {
            _25093 = binary_op(AND_BITS, 6LL, _25092);
        }
        _25092 = NOVALUE;
        if (IS_ATOM_INT(_25093))
        _25088 = (_25093 != 0);
        else
        _25088 = DBL_PTR(_25093)->dbl != 0.0;
L11: 
        if (_25088 != 0) {
            DeRef(_25094);
            _25094 = 1;
            goto L12; // [533] 583
        }
        _25095 = (_scope_48440 == 11LL);
        if (_25095 == 0) {
            _25096 = 0;
            goto L13; // [543] 579
        }
        _2 = (object)SEQ_PTR(_28include_matrix_11579);
        _25097 = (object)*(((s1_ptr)_2)->base + _scanning_file_48432);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _25098 = (object)*(((s1_ptr)_2)->base + _st_ptr_48444);
        _2 = (object)SEQ_PTR(_25098);
        if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
            _25099 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
        }
        else{
            _25099 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
        }
        _25098 = NOVALUE;
        _2 = (object)SEQ_PTR(_25097);
        if (!IS_ATOM_INT(_25099)){
            _25100 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25099)->dbl));
        }
        else{
            _25100 = (object)*(((s1_ptr)_2)->base + _25099);
        }
        _25097 = NOVALUE;
        if (IS_ATOM_INT(_25100)) {
            {uintptr_t tu;
                 tu = (uintptr_t)2LL & (uintptr_t)_25100;
                 _25101 = MAKE_UINT(tu);
            }
        }
        else {
            _25101 = binary_op(AND_BITS, 2LL, _25100);
        }
        _25100 = NOVALUE;
        if (IS_ATOM_INT(_25101))
        _25096 = (_25101 != 0);
        else
        _25096 = DBL_PTR(_25101)->dbl != 0.0;
L13: 
        DeRef(_25094);
        _25094 = (_25096 != 0);
L12: 
        if (_25094 == 0)
        {
            _25094 = NOVALUE;
            goto L7; // [584] 1011
        }
        else{
            _25094 = NOVALUE;
        }

        /** symtab.e:826							gtok = tok*/
        Ref(_tok_48447);
        DeRef(_gtok_48448);
        _gtok_48448 = _tok_48447;

        /** symtab.e:827							dup_globals &= st_ptr*/
        Append(&_53dup_globals_48416, _53dup_globals_48416, _st_ptr_48444);

        /** symtab.e:828							in_include_path &= include_matrix[scanning_file][SymTab[st_ptr][S_FILE_NO]] != 0 --symbol_in_include_path( st_ptr, scanning_file, {} )*/
        _2 = (object)SEQ_PTR(_28include_matrix_11579);
        _25103 = (object)*(((s1_ptr)_2)->base + _scanning_file_48432);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _25104 = (object)*(((s1_ptr)_2)->base + _st_ptr_48444);
        _2 = (object)SEQ_PTR(_25104);
        if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
            _25105 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
        }
        else{
            _25105 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
        }
        _25104 = NOVALUE;
        _2 = (object)SEQ_PTR(_25103);
        if (!IS_ATOM_INT(_25105)){
            _25106 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25105)->dbl));
        }
        else{
            _25106 = (object)*(((s1_ptr)_2)->base + _25105);
        }
        _25103 = NOVALUE;
        if (IS_ATOM_INT(_25106)) {
            _25107 = (_25106 != 0LL);
        }
        else {
            _25107 = binary_op(NOTEQ, _25106, 0LL);
        }
        _25106 = NOVALUE;
        if (IS_SEQUENCE(_53in_include_path_48418) && IS_ATOM(_25107)) {
            Ref(_25107);
            Append(&_53in_include_path_48418, _53in_include_path_48418, _25107);
        }
        else if (IS_ATOM(_53in_include_path_48418) && IS_SEQUENCE(_25107)) {
        }
        else {
            Concat((object_ptr)&_53in_include_path_48418, _53in_include_path_48418, _25107);
        }
        DeRef(_25107);
        _25107 = NOVALUE;

        /** symtab.e:831	ifdef STDDEBUG then*/

        /** symtab.e:852						break*/
        goto L7; // [639] 1011

        /** symtab.e:853					case SC_LOCAL then*/
        case 5:

        /** symtab.e:854						if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _25109 = (object)*(((s1_ptr)_2)->base + _st_ptr_48444);
        _2 = (object)SEQ_PTR(_25109);
        if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
            _25110 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
        }
        else{
            _25110 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
        }
        _25109 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_48432, _25110)){
            _25110 = NOVALUE;
            goto L7; // [659] 1011
        }
        _25110 = NOVALUE;

        /** symtab.e:857							if BIND then*/
        if (_27BIND_20182 == 0)
        {
            goto L14; // [667] 676
        }
        else{
        }

        /** symtab.e:858								add_ref(tok)*/
        Ref(_tok_48447);
        _53add_ref(_tok_48447);
L14: 

        /** symtab.e:861							return tok*/
        DeRefDS(_word_48430);
        DeRef(_msg_48438);
        DeRef(_b_name_48439);
        DeRef(_gtok_48448);
        DeRef(_25036);
        _25036 = NOVALUE;
        DeRef(_25101);
        _25101 = NOVALUE;
        _25064 = NOVALUE;
        DeRef(_25095);
        _25095 = NOVALUE;
        _25091 = NOVALUE;
        _25060 = NOVALUE;
        DeRef(_25046);
        _25046 = NOVALUE;
        _25080 = NOVALUE;
        _25105 = NOVALUE;
        DeRef(_25093);
        _25093 = NOVALUE;
        DeRef(_25087);
        _25087 = NOVALUE;
        DeRef(_25085);
        _25085 = NOVALUE;
        _25073 = NOVALUE;
        _25099 = NOVALUE;
        _25065 = NOVALUE;
        return _tok_48447;

        /** symtab.e:863						break*/
        goto L7; // [685] 1011

        /** symtab.e:864					case else*/
        default:

        /** symtab.e:866						if BIND then*/
        if (_27BIND_20182 == 0)
        {
            goto L15; // [695] 704
        }
        else{
        }

        /** symtab.e:867							add_ref(tok)*/
        Ref(_tok_48447);
        _53add_ref(_tok_48447);
L15: 

        /** symtab.e:870						return tok -- keyword, private*/
        DeRefDS(_word_48430);
        DeRef(_msg_48438);
        DeRef(_b_name_48439);
        DeRef(_gtok_48448);
        DeRef(_25036);
        _25036 = NOVALUE;
        DeRef(_25101);
        _25101 = NOVALUE;
        _25064 = NOVALUE;
        DeRef(_25095);
        _25095 = NOVALUE;
        _25091 = NOVALUE;
        _25060 = NOVALUE;
        DeRef(_25046);
        _25046 = NOVALUE;
        _25080 = NOVALUE;
        _25105 = NOVALUE;
        DeRef(_25093);
        _25093 = NOVALUE;
        DeRef(_25087);
        _25087 = NOVALUE;
        DeRef(_25085);
        _25085 = NOVALUE;
        _25073 = NOVALUE;
        _25099 = NOVALUE;
        _25065 = NOVALUE;
        return _tok_48447;
    ;}    goto L7; // [711] 1011
L6: 

    /** symtab.e:877					scope = SymTab[tok[T_SYM]][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_tok_48447);
    _25112 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_25112)){
        _25113 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25112)->dbl));
    }
    else{
        _25113 = (object)*(((s1_ptr)_2)->base + _25112);
    }
    _2 = (object)SEQ_PTR(_25113);
    _scope_48440 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_scope_48440)){
        _scope_48440 = (object)DBL_PTR(_scope_48440)->dbl;
    }
    _25113 = NOVALUE;

    /** symtab.e:878					if not file_no then*/
    if (_file_no_48431 != 0)
    goto L16; // [738] 772

    /** symtab.e:880						if scope = SC_PREDEF then*/
    if (_scope_48440 != 7LL)
    goto L17; // [745] 1010

    /** symtab.e:881							if BIND then*/
    if (_27BIND_20182 == 0)
    {
        goto L18; // [753] 762
    }
    else{
    }

    /** symtab.e:882								add_ref( tok )*/
    Ref(_tok_48447);
    _53add_ref(_tok_48447);
L18: 

    /** symtab.e:884							return tok*/
    DeRefDS(_word_48430);
    DeRef(_msg_48438);
    DeRef(_b_name_48439);
    DeRef(_gtok_48448);
    DeRef(_25036);
    _25036 = NOVALUE;
    DeRef(_25101);
    _25101 = NOVALUE;
    _25112 = NOVALUE;
    _25064 = NOVALUE;
    DeRef(_25095);
    _25095 = NOVALUE;
    _25091 = NOVALUE;
    _25060 = NOVALUE;
    DeRef(_25046);
    _25046 = NOVALUE;
    _25080 = NOVALUE;
    _25105 = NOVALUE;
    DeRef(_25093);
    _25093 = NOVALUE;
    DeRef(_25087);
    _25087 = NOVALUE;
    DeRef(_25085);
    _25085 = NOVALUE;
    _25073 = NOVALUE;
    _25099 = NOVALUE;
    _25065 = NOVALUE;
    return _tok_48447;
    goto L17; // [769] 1010
L16: 

    /** symtab.e:887						integer tok_file = SymTab[tok[T_SYM]][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_tok_48447);
    _25117 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_25117)){
        _25118 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25117)->dbl));
    }
    else{
        _25118 = (object)*(((s1_ptr)_2)->base + _25117);
    }
    _2 = (object)SEQ_PTR(_25118);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _tok_file_48619 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _tok_file_48619 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    if (!IS_ATOM_INT(_tok_file_48619)){
        _tok_file_48619 = (object)DBL_PTR(_tok_file_48619)->dbl;
    }
    _25118 = NOVALUE;

    /** symtab.e:888						integer good = 0*/
    _good_48626 = 0LL;

    /** symtab.e:889						if scope = SC_PRIVATE or scope = SC_PREDEF then*/
    _25120 = (_scope_48440 == 3LL);
    if (_25120 != 0) {
        goto L19; // [807] 940
    }
    _25122 = (_scope_48440 == 7LL);
    if (_25122 == 0)
    {
        DeRef(_25122);
        _25122 = NOVALUE;
        goto L1A; // [818] 825
    }
    else{
        DeRef(_25122);
        _25122 = NOVALUE;
    }
    goto L19; // [822] 940
L1A: 

    /** symtab.e:892						elsif file_no = tok_file then*/
    if (_file_no_48431 != _tok_file_48619)
    goto L1B; // [827] 839

    /** symtab.e:893							good = 1*/
    _good_48626 = 1LL;
    goto L19; // [836] 940
L1B: 

    /** symtab.e:896							integer include_type = 0*/
    _include_type_48636 = 0LL;

    /** symtab.e:897							switch scope do*/
    _0 = _scope_48440;
    switch ( _0 ){ 

        /** symtab.e:898								case SC_GLOBAL then*/
        case 6:

        /** symtab.e:899									if Resolve_unincluded_globals then*/
        if (_53Resolve_unincluded_globals_48421 == 0)
        {
            goto L1C; // [859] 874
        }
        else{
        }

        /** symtab.e:900										include_type = ANY_INCLUDE*/
        _include_type_48636 = 7LL;
        goto L1D; // [871] 919
L1C: 

        /** symtab.e:902										include_type = DIRECT_OR_PUBLIC_INCLUDE*/
        _include_type_48636 = 6LL;
        goto L1D; // [884] 919

        /** symtab.e:905								case SC_PUBLIC then*/
        case 13:

        /** symtab.e:907									if tok_file != file_no then*/
        if (_tok_file_48619 == _file_no_48431)
        goto L1E; // [892] 908

        /** symtab.e:908										include_type = PUBLIC_INCLUDE*/
        _include_type_48636 = 4LL;
        goto L1F; // [905] 918
L1E: 

        /** symtab.e:910										include_type = DIRECT_OR_PUBLIC_INCLUDE*/
        _include_type_48636 = 6LL;
L1F: 
    ;}L1D: 

    /** symtab.e:914							good = and_bits( include_type, include_matrix[file_no][tok_file] )*/
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _25127 = (object)*(((s1_ptr)_2)->base + _file_no_48431);
    _2 = (object)SEQ_PTR(_25127);
    _25128 = (object)*(((s1_ptr)_2)->base + _tok_file_48619);
    _25127 = NOVALUE;
    if (IS_ATOM_INT(_25128)) {
        {uintptr_t tu;
             tu = (uintptr_t)_include_type_48636 & (uintptr_t)_25128;
             _good_48626 = MAKE_UINT(tu);
        }
    }
    else {
        _good_48626 = binary_op(AND_BITS, _include_type_48636, _25128);
    }
    _25128 = NOVALUE;
    if (!IS_ATOM_INT(_good_48626)) {
        _1 = (object)(DBL_PTR(_good_48626)->dbl);
        DeRefDS(_good_48626);
        _good_48626 = _1;
    }
L19: 

    /** symtab.e:917						if good then*/
    if (_good_48626 == 0)
    {
        goto L20; // [942] 1007
    }
    else{
    }

    /** symtab.e:919							if file_no = tok_file then*/
    if (_file_no_48431 != _tok_file_48619)
    goto L21; // [947] 971

    /** symtab.e:920								if BIND then*/
    if (_27BIND_20182 == 0)
    {
        goto L22; // [955] 964
    }
    else{
    }

    /** symtab.e:921									add_ref(tok)*/
    Ref(_tok_48447);
    _53add_ref(_tok_48447);
L22: 

    /** symtab.e:923								return tok*/
    DeRefDS(_word_48430);
    DeRef(_msg_48438);
    DeRef(_b_name_48439);
    DeRef(_gtok_48448);
    DeRef(_25036);
    _25036 = NOVALUE;
    DeRef(_25101);
    _25101 = NOVALUE;
    _25112 = NOVALUE;
    _25064 = NOVALUE;
    DeRef(_25095);
    _25095 = NOVALUE;
    _25091 = NOVALUE;
    DeRef(_25120);
    _25120 = NOVALUE;
    _25060 = NOVALUE;
    DeRef(_25046);
    _25046 = NOVALUE;
    _25080 = NOVALUE;
    _25105 = NOVALUE;
    _25117 = NOVALUE;
    DeRef(_25093);
    _25093 = NOVALUE;
    DeRef(_25087);
    _25087 = NOVALUE;
    DeRef(_25085);
    _25085 = NOVALUE;
    _25073 = NOVALUE;
    _25099 = NOVALUE;
    _25065 = NOVALUE;
    return _tok_48447;
L21: 

    /** symtab.e:926							gtok = tok*/
    Ref(_tok_48447);
    DeRef(_gtok_48448);
    _gtok_48448 = _tok_48447;

    /** symtab.e:927							dup_globals &= st_ptr*/
    Append(&_53dup_globals_48416, _53dup_globals_48416, _st_ptr_48444);

    /** symtab.e:928							in_include_path &= include_matrix[scanning_file][tok_file] != 0*/
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _25132 = (object)*(((s1_ptr)_2)->base + _scanning_file_48432);
    _2 = (object)SEQ_PTR(_25132);
    _25133 = (object)*(((s1_ptr)_2)->base + _tok_file_48619);
    _25132 = NOVALUE;
    if (IS_ATOM_INT(_25133)) {
        _25134 = (_25133 != 0LL);
    }
    else {
        _25134 = binary_op(NOTEQ, _25133, 0LL);
    }
    _25133 = NOVALUE;
    if (IS_SEQUENCE(_53in_include_path_48418) && IS_ATOM(_25134)) {
        Ref(_25134);
        Append(&_53in_include_path_48418, _53in_include_path_48418, _25134);
    }
    else if (IS_ATOM(_53in_include_path_48418) && IS_SEQUENCE(_25134)) {
    }
    else {
        Concat((object_ptr)&_53in_include_path_48418, _53in_include_path_48418, _25134);
    }
    DeRef(_25134);
    _25134 = NOVALUE;
L20: 
L17: 
L7: 
L4: 

    /** symtab.e:936			st_ptr = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25136 = (object)*(((s1_ptr)_2)->base + _st_ptr_48444);
    _2 = (object)SEQ_PTR(_25136);
    _st_ptr_48444 = (object)*(((s1_ptr)_2)->base + 9LL);
    if (!IS_ATOM_INT(_st_ptr_48444)){
        _st_ptr_48444 = (object)DBL_PTR(_st_ptr_48444)->dbl;
    }
    _25136 = NOVALUE;

    /** symtab.e:937		end while*/
    goto L1; // [1030] 69
L2: 

    /** symtab.e:939		if length(dup_overrides) then*/
    if (IS_SEQUENCE(_53dup_overrides_48417)){
            _25138 = SEQ_PTR(_53dup_overrides_48417)->length;
    }
    else {
        _25138 = 1;
    }
    if (_25138 == 0)
    {
        _25138 = NOVALUE;
        goto L23; // [1040] 1093
    }
    else{
        _25138 = NOVALUE;
    }

    /** symtab.e:940			st_ptr = dup_overrides[1]*/
    _2 = (object)SEQ_PTR(_53dup_overrides_48417);
    _st_ptr_48444 = (object)*(((s1_ptr)_2)->base + 1LL);

    /** symtab.e:941			tok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25140 = (object)*(((s1_ptr)_2)->base + _st_ptr_48444);
    _2 = (object)SEQ_PTR(_25140);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _25141 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _25141 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _25140 = NOVALUE;
    Ref(_25141);
    DeRef(_tok_48447);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _25141;
    ((intptr_t *)_2)[2] = _st_ptr_48444;
    _tok_48447 = MAKE_SEQ(_1);
    _25141 = NOVALUE;

    /** symtab.e:944				if BIND then*/
    if (_27BIND_20182 == 0)
    {
        goto L24; // [1075] 1084
    }
    else{
    }

    /** symtab.e:945					add_ref(tok)*/
    RefDS(_tok_48447);
    _53add_ref(_tok_48447);
L24: 

    /** symtab.e:948				return tok*/
    DeRefDS(_word_48430);
    DeRef(_msg_48438);
    DeRef(_b_name_48439);
    DeRef(_gtok_48448);
    DeRef(_25036);
    _25036 = NOVALUE;
    DeRef(_25101);
    _25101 = NOVALUE;
    _25112 = NOVALUE;
    _25064 = NOVALUE;
    DeRef(_25095);
    _25095 = NOVALUE;
    _25091 = NOVALUE;
    DeRef(_25120);
    _25120 = NOVALUE;
    _25060 = NOVALUE;
    DeRef(_25046);
    _25046 = NOVALUE;
    _25080 = NOVALUE;
    _25105 = NOVALUE;
    _25117 = NOVALUE;
    DeRef(_25093);
    _25093 = NOVALUE;
    DeRef(_25087);
    _25087 = NOVALUE;
    DeRef(_25085);
    _25085 = NOVALUE;
    _25073 = NOVALUE;
    _25099 = NOVALUE;
    _25065 = NOVALUE;
    return _tok_48447;
    goto L25; // [1090] 1320
L23: 

    /** symtab.e:951		elsif st_builtin != 0 then*/
    if (_st_builtin_48445 == 0LL)
    goto L26; // [1095] 1319

    /** symtab.e:952			if length(dup_globals) and find(SymTab[st_builtin][S_NAME], builtin_warnings) = 0 then*/
    if (IS_SEQUENCE(_53dup_globals_48416)){
            _25144 = SEQ_PTR(_53dup_globals_48416)->length;
    }
    else {
        _25144 = 1;
    }
    if (_25144 == 0) {
        goto L27; // [1106] 1279
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25146 = (object)*(((s1_ptr)_2)->base + _st_builtin_48445);
    _2 = (object)SEQ_PTR(_25146);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _25147 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _25147 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _25146 = NOVALUE;
    _25148 = find_from(_25147, _53builtin_warnings_48420, 1LL);
    _25147 = NOVALUE;
    _25149 = (_25148 == 0LL);
    _25148 = NOVALUE;
    if (_25149 == 0)
    {
        DeRef(_25149);
        _25149 = NOVALUE;
        goto L27; // [1134] 1279
    }
    else{
        DeRef(_25149);
        _25149 = NOVALUE;
    }

    /** symtab.e:953				sequence msg_file */

    /** symtab.e:955				b_name = SymTab[st_builtin][S_NAME]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25150 = (object)*(((s1_ptr)_2)->base + _st_builtin_48445);
    DeRef(_b_name_48439);
    _2 = (object)SEQ_PTR(_25150);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _b_name_48439 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _b_name_48439 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    Ref(_b_name_48439);
    _25150 = NOVALUE;

    /** symtab.e:956				builtin_warnings = append(builtin_warnings, b_name)*/
    RefDS(_b_name_48439);
    Append(&_53builtin_warnings_48420, _53builtin_warnings_48420, _b_name_48439);

    /** symtab.e:958				if length(dup_globals) > 1 then*/
    if (IS_SEQUENCE(_53dup_globals_48416)){
            _25153 = SEQ_PTR(_53dup_globals_48416)->length;
    }
    else {
        _25153 = 1;
    }
    if (_25153 <= 1LL)
    goto L28; // [1170] 1184

    /** symtab.e:959					msg = "\n"*/
    RefDS(_22425);
    DeRef(_msg_48438);
    _msg_48438 = _22425;
    goto L29; // [1181] 1192
L28: 

    /** symtab.e:961					msg = ""*/
    RefDS(_22218);
    DeRef(_msg_48438);
    _msg_48438 = _22218;
L29: 

    /** symtab.e:964				for i = 1 to length(dup_globals) do*/
    if (IS_SEQUENCE(_53dup_globals_48416)){
            _25155 = SEQ_PTR(_53dup_globals_48416)->length;
    }
    else {
        _25155 = 1;
    }
    {
        object _i_48703;
        _i_48703 = 1LL;
L2A: 
        if (_i_48703 > _25155){
            goto L2B; // [1199] 1255
        }

        /** symtab.e:965					msg_file = known_files[SymTab[dup_globals[i]][S_FILE_NO]]*/
        _2 = (object)SEQ_PTR(_53dup_globals_48416);
        _25156 = (object)*(((s1_ptr)_2)->base + _i_48703);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!IS_ATOM_INT(_25156)){
            _25157 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25156)->dbl));
        }
        else{
            _25157 = (object)*(((s1_ptr)_2)->base + _25156);
        }
        _2 = (object)SEQ_PTR(_25157);
        if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
            _25158 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
        }
        else{
            _25158 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
        }
        _25157 = NOVALUE;
        DeRef(_msg_file_48692);
        _2 = (object)SEQ_PTR(_28known_files_11573);
        if (!IS_ATOM_INT(_25158)){
            _msg_file_48692 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25158)->dbl));
        }
        else{
            _msg_file_48692 = (object)*(((s1_ptr)_2)->base + _25158);
        }
        Ref(_msg_file_48692);

        /** symtab.e:966					msg &= "    " & msg_file & "\n"*/
        {
            object concat_list[3];

            concat_list[0] = _22425;
            concat_list[1] = _msg_file_48692;
            concat_list[2] = _25160;
            Concat_N((object_ptr)&_25161, concat_list, 3);
        }
        Concat((object_ptr)&_msg_48438, _msg_48438, _25161);
        DeRefDS(_25161);
        _25161 = NOVALUE;

        /** symtab.e:967				end for*/
        _i_48703 = _i_48703 + 1LL;
        goto L2A; // [1250] 1206
L2B: 
        ;
    }

    /** symtab.e:969				Warning(234, builtin_chosen_warning_flag, {b_name, known_files[scanning_file], msg})*/
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _25163 = (object)*(((s1_ptr)_2)->base + _scanning_file_48432);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_b_name_48439);
    ((intptr_t*)_2)[1] = _b_name_48439;
    Ref(_25163);
    ((intptr_t*)_2)[2] = _25163;
    RefDS(_msg_48438);
    ((intptr_t*)_2)[3] = _msg_48438;
    _25164 = MAKE_SEQ(_1);
    _25163 = NOVALUE;
    _49Warning(234LL, 8LL, _25164);
    _25164 = NOVALUE;
L27: 
    DeRef(_msg_file_48692);
    _msg_file_48692 = NOVALUE;

    /** symtab.e:972			tok = {SymTab[st_builtin][S_TOKEN], st_builtin}*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25165 = (object)*(((s1_ptr)_2)->base + _st_builtin_48445);
    _2 = (object)SEQ_PTR(_25165);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _25166 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _25166 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _25165 = NOVALUE;
    Ref(_25166);
    DeRef(_tok_48447);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _25166;
    ((intptr_t *)_2)[2] = _st_builtin_48445;
    _tok_48447 = MAKE_SEQ(_1);
    _25166 = NOVALUE;

    /** symtab.e:974			if BIND then*/
    if (_27BIND_20182 == 0)
    {
        goto L2C; // [1303] 1312
    }
    else{
    }

    /** symtab.e:975				add_ref(tok)*/
    RefDS(_tok_48447);
    _53add_ref(_tok_48447);
L2C: 

    /** symtab.e:978			return tok*/
    DeRefDS(_word_48430);
    DeRef(_msg_48438);
    DeRef(_b_name_48439);
    DeRef(_gtok_48448);
    DeRef(_25036);
    _25036 = NOVALUE;
    _25158 = NOVALUE;
    DeRef(_25101);
    _25101 = NOVALUE;
    _25112 = NOVALUE;
    _25064 = NOVALUE;
    DeRef(_25095);
    _25095 = NOVALUE;
    _25156 = NOVALUE;
    _25091 = NOVALUE;
    DeRef(_25120);
    _25120 = NOVALUE;
    _25060 = NOVALUE;
    DeRef(_25046);
    _25046 = NOVALUE;
    _25080 = NOVALUE;
    _25105 = NOVALUE;
    _25117 = NOVALUE;
    DeRef(_25093);
    _25093 = NOVALUE;
    DeRef(_25087);
    _25087 = NOVALUE;
    DeRef(_25085);
    _25085 = NOVALUE;
    _25073 = NOVALUE;
    _25099 = NOVALUE;
    _25065 = NOVALUE;
    return _tok_48447;
L26: 
L25: 

    /** symtab.e:981	ifdef STDDEBUG then*/

    /** symtab.e:996		if length(dup_globals) > 1 and find( 1, in_include_path ) then*/
    if (IS_SEQUENCE(_53dup_globals_48416)){
            _25168 = SEQ_PTR(_53dup_globals_48416)->length;
    }
    else {
        _25168 = 1;
    }
    _25169 = (_25168 > 1LL);
    _25168 = NOVALUE;
    if (_25169 == 0) {
        goto L2D; // [1333] 1452
    }
    _25171 = find_from(1LL, _53in_include_path_48418, 1LL);
    if (_25171 == 0)
    {
        _25171 = NOVALUE;
        goto L2D; // [1345] 1452
    }
    else{
        _25171 = NOVALUE;
    }

    /** symtab.e:998			ix = 1*/
    _ix_48442 = 1LL;

    /** symtab.e:999			while ix <= length(dup_globals) do*/
L2E: 
    if (IS_SEQUENCE(_53dup_globals_48416)){
            _25172 = SEQ_PTR(_53dup_globals_48416)->length;
    }
    else {
        _25172 = 1;
    }
    if (_ix_48442 > _25172)
    goto L2F; // [1363] 1411

    /** symtab.e:1000				if in_include_path[ix] then*/
    _2 = (object)SEQ_PTR(_53in_include_path_48418);
    _25174 = (object)*(((s1_ptr)_2)->base + _ix_48442);
    if (_25174 == 0) {
        _25174 = NOVALUE;
        goto L30; // [1375] 1387
    }
    else {
        if (!IS_ATOM_INT(_25174) && DBL_PTR(_25174)->dbl == 0.0){
            _25174 = NOVALUE;
            goto L30; // [1375] 1387
        }
        _25174 = NOVALUE;
    }
    _25174 = NOVALUE;

    /** symtab.e:1001					ix += 1*/
    _ix_48442 = _ix_48442 + 1;
    goto L2E; // [1384] 1358
L30: 

    /** symtab.e:1003					dup_globals     = remove( dup_globals, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_53dup_globals_48416);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_48442)) ? _ix_48442 : (object)(DBL_PTR(_ix_48442)->dbl);
        int stop = (IS_ATOM_INT(_ix_48442)) ? _ix_48442 : (object)(DBL_PTR(_ix_48442)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_53dup_globals_48416), start, &_53dup_globals_48416 );
            }
            else Tail(SEQ_PTR(_53dup_globals_48416), stop+1, &_53dup_globals_48416);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_53dup_globals_48416), start, &_53dup_globals_48416);
        }
        else {
            assign_slice_seq = &assign_space;
            _53dup_globals_48416 = Remove_elements(start, stop, (SEQ_PTR(_53dup_globals_48416)->ref == 1));
        }
    }

    /** symtab.e:1004					in_include_path = remove( in_include_path, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_53in_include_path_48418);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_48442)) ? _ix_48442 : (object)(DBL_PTR(_ix_48442)->dbl);
        int stop = (IS_ATOM_INT(_ix_48442)) ? _ix_48442 : (object)(DBL_PTR(_ix_48442)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_53in_include_path_48418), start, &_53in_include_path_48418 );
            }
            else Tail(SEQ_PTR(_53in_include_path_48418), stop+1, &_53in_include_path_48418);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_53in_include_path_48418), start, &_53in_include_path_48418);
        }
        else {
            assign_slice_seq = &assign_space;
            _53in_include_path_48418 = Remove_elements(start, stop, (SEQ_PTR(_53in_include_path_48418)->ref == 1));
        }
    }

    /** symtab.e:1006			end while*/
    goto L2E; // [1408] 1358
L2F: 

    /** symtab.e:1008			if length(dup_globals) = 1 then*/
    if (IS_SEQUENCE(_53dup_globals_48416)){
            _25178 = SEQ_PTR(_53dup_globals_48416)->length;
    }
    else {
        _25178 = 1;
    }
    if (_25178 != 1LL)
    goto L31; // [1418] 1451

    /** symtab.e:1009					st_ptr = dup_globals[1]*/
    _2 = (object)SEQ_PTR(_53dup_globals_48416);
    _st_ptr_48444 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_st_ptr_48444)){
        _st_ptr_48444 = (object)DBL_PTR(_st_ptr_48444)->dbl;
    }

    /** symtab.e:1010					gtok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25181 = (object)*(((s1_ptr)_2)->base + _st_ptr_48444);
    _2 = (object)SEQ_PTR(_25181);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _25182 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _25182 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _25181 = NOVALUE;
    Ref(_25182);
    DeRef(_gtok_48448);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _25182;
    ((intptr_t *)_2)[2] = _st_ptr_48444;
    _gtok_48448 = MAKE_SEQ(_1);
    _25182 = NOVALUE;
L31: 
L2D: 

    /** symtab.e:1014	ifdef STDDEBUG then*/

    /** symtab.e:1023		if length(dup_globals) = 1 and st_builtin = 0 then*/
    if (IS_SEQUENCE(_53dup_globals_48416)){
            _25184 = SEQ_PTR(_53dup_globals_48416)->length;
    }
    else {
        _25184 = 1;
    }
    _25185 = (_25184 == 1LL);
    _25184 = NOVALUE;
    if (_25185 == 0) {
        goto L32; // [1465] 1644
    }
    _25187 = (_st_builtin_48445 == 0LL);
    if (_25187 == 0)
    {
        DeRef(_25187);
        _25187 = NOVALUE;
        goto L32; // [1474] 1644
    }
    else{
        DeRef(_25187);
        _25187 = NOVALUE;
    }

    /** symtab.e:1026			if BIND then*/
    if (_27BIND_20182 == 0)
    {
        goto L33; // [1481] 1492
    }
    else{
    }

    /** symtab.e:1027				add_ref(gtok)*/
    Ref(_gtok_48448);
    _53add_ref(_gtok_48448);
L33: 

    /** symtab.e:1029			if not in_include_path[1] and*/
    _2 = (object)SEQ_PTR(_53in_include_path_48418);
    _25188 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_25188)) {
        _25189 = (_25188 == 0);
    }
    else {
        _25189 = unary_op(NOT, _25188);
    }
    _25188 = NOVALUE;
    if (IS_ATOM_INT(_25189)) {
        if (_25189 == 0) {
            goto L34; // [1503] 1637
        }
    }
    else {
        if (DBL_PTR(_25189)->dbl == 0.0) {
            goto L34; // [1503] 1637
        }
    }
    _2 = (object)SEQ_PTR(_gtok_48448);
    _25191 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_25191)){
        _25192 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25191)->dbl));
    }
    else{
        _25192 = (object)*(((s1_ptr)_2)->base + _25191);
    }
    _2 = (object)SEQ_PTR(_25192);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _25193 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _25193 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _25192 = NOVALUE;
    Ref(_25193);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _scanning_file_48432;
    ((intptr_t *)_2)[2] = _25193;
    _25194 = MAKE_SEQ(_1);
    _25193 = NOVALUE;
    _25195 = find_from(_25194, _53include_warnings_48419, 1LL);
    DeRefDS(_25194);
    _25194 = NOVALUE;
    _25196 = (_25195 == 0);
    _25195 = NOVALUE;
    if (_25196 == 0)
    {
        DeRef(_25196);
        _25196 = NOVALUE;
        goto L34; // [1542] 1637
    }
    else{
        DeRef(_25196);
        _25196 = NOVALUE;
    }

    /** symtab.e:1032				include_warnings = prepend( include_warnings,*/
    _2 = (object)SEQ_PTR(_gtok_48448);
    _25197 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_25197)){
        _25198 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25197)->dbl));
    }
    else{
        _25198 = (object)*(((s1_ptr)_2)->base + _25197);
    }
    _2 = (object)SEQ_PTR(_25198);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _25199 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _25199 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _25198 = NOVALUE;
    Ref(_25199);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _scanning_file_48432;
    ((intptr_t *)_2)[2] = _25199;
    _25200 = MAKE_SEQ(_1);
    _25199 = NOVALUE;
    RefDS(_25200);
    Prepend(&_53include_warnings_48419, _53include_warnings_48419, _25200);
    DeRefDS(_25200);
    _25200 = NOVALUE;

    /** symtab.e:1034	ifdef STDDEBUG then*/

    /** symtab.e:1040					symbol_resolution_warning = GetMsgText(MSG_12__IDENTIFIER_3_IN_4_IS_NOT_INCLUDED,0,*/
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _25202 = (object)*(((s1_ptr)_2)->base + _scanning_file_48432);
    Ref(_25202);
    _25203 = _53name_ext(_25202);
    _25202 = NOVALUE;
    _2 = (object)SEQ_PTR(_gtok_48448);
    _25204 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_25204)){
        _25205 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25204)->dbl));
    }
    else{
        _25205 = (object)*(((s1_ptr)_2)->base + _25204);
    }
    _2 = (object)SEQ_PTR(_25205);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _25206 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _25206 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _25205 = NOVALUE;
    _2 = (object)SEQ_PTR(_28known_files_11573);
    if (!IS_ATOM_INT(_25206)){
        _25207 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25206)->dbl));
    }
    else{
        _25207 = (object)*(((s1_ptr)_2)->base + _25206);
    }
    Ref(_25207);
    _25208 = _53name_ext(_25207);
    _25207 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _25203;
    ((intptr_t*)_2)[2] = _27line_number_20572;
    RefDS(_word_48430);
    ((intptr_t*)_2)[3] = _word_48430;
    ((intptr_t*)_2)[4] = _25208;
    _25209 = MAKE_SEQ(_1);
    _25208 = NOVALUE;
    _25203 = NOVALUE;
    _0 = _30GetMsgText(233LL, 0LL, _25209);
    DeRef(_27symbol_resolution_warning_20673);
    _27symbol_resolution_warning_20673 = _0;
    _25209 = NOVALUE;
L34: 

    /** symtab.e:1047			return gtok*/
    DeRefDS(_word_48430);
    DeRef(_msg_48438);
    DeRef(_b_name_48439);
    DeRef(_tok_48447);
    DeRef(_25189);
    _25189 = NOVALUE;
    DeRef(_25036);
    _25036 = NOVALUE;
    _25158 = NOVALUE;
    DeRef(_25101);
    _25101 = NOVALUE;
    _25112 = NOVALUE;
    _25064 = NOVALUE;
    DeRef(_25095);
    _25095 = NOVALUE;
    _25206 = NOVALUE;
    _25156 = NOVALUE;
    _25091 = NOVALUE;
    DeRef(_25120);
    _25120 = NOVALUE;
    _25191 = NOVALUE;
    _25060 = NOVALUE;
    DeRef(_25046);
    _25046 = NOVALUE;
    _25204 = NOVALUE;
    _25080 = NOVALUE;
    _25105 = NOVALUE;
    DeRef(_25185);
    _25185 = NOVALUE;
    _25117 = NOVALUE;
    _25197 = NOVALUE;
    DeRef(_25093);
    _25093 = NOVALUE;
    DeRef(_25087);
    _25087 = NOVALUE;
    DeRef(_25085);
    _25085 = NOVALUE;
    _25073 = NOVALUE;
    _25099 = NOVALUE;
    _25065 = NOVALUE;
    DeRef(_25169);
    _25169 = NOVALUE;
    return _gtok_48448;
L32: 

    /** symtab.e:1051		if length(dup_globals) = 0 then*/
    if (IS_SEQUENCE(_53dup_globals_48416)){
            _25211 = SEQ_PTR(_53dup_globals_48416)->length;
    }
    else {
        _25211 = 1;
    }
    if (_25211 != 0LL)
    goto L35; // [1651] 1725

    /** symtab.e:1052			defined = SC_UNDEFINED*/
    _defined_48441 = 9LL;

    /** symtab.e:1054			if fwd_line_number then*/
    if (_27fwd_line_number_20573 == 0)
    {
        goto L36; // [1668] 1697
    }
    else{
    }

    /** symtab.e:1055				last_ForwardLine     = ForwardLine*/
    Ref(_49ForwardLine_49694);
    DeRef(_49last_ForwardLine_49696);
    _49last_ForwardLine_49696 = _49ForwardLine_49694;

    /** symtab.e:1056				last_forward_bp      = forward_bp*/
    _49last_forward_bp_49700 = _49forward_bp_49698;

    /** symtab.e:1057				last_fwd_line_number = fwd_line_number*/
    _27last_fwd_line_number_20575 = _27fwd_line_number_20573;
L36: 

    /** symtab.e:1060			ForwardLine = ThisLine*/
    Ref(_49ThisLine_49693);
    DeRef(_49ForwardLine_49694);
    _49ForwardLine_49694 = _49ThisLine_49693;

    /** symtab.e:1061			forward_bp = bp*/
    _49forward_bp_49698 = _49bp_49697;

    /** symtab.e:1062			fwd_line_number = line_number*/
    _27fwd_line_number_20573 = _27line_number_20572;
    goto L37; // [1722] 1768
L35: 

    /** symtab.e:1064		elsif length(dup_globals) then*/
    if (IS_SEQUENCE(_53dup_globals_48416)){
            _25213 = SEQ_PTR(_53dup_globals_48416)->length;
    }
    else {
        _25213 = 1;
    }
    if (_25213 == 0)
    {
        _25213 = NOVALUE;
        goto L38; // [1732] 1747
    }
    else{
        _25213 = NOVALUE;
    }

    /** symtab.e:1065			defined = SC_MULTIPLY_DEFINED*/
    _defined_48441 = 10LL;
    goto L37; // [1744] 1768
L38: 

    /** symtab.e:1066		elsif length(dup_overrides) then*/
    if (IS_SEQUENCE(_53dup_overrides_48417)){
            _25214 = SEQ_PTR(_53dup_overrides_48417)->length;
    }
    else {
        _25214 = 1;
    }
    if (_25214 == 0)
    {
        _25214 = NOVALUE;
        goto L39; // [1754] 1767
    }
    else{
        _25214 = NOVALUE;
    }

    /** symtab.e:1067			defined = SC_OVERRIDE*/
    _defined_48441 = 12LL;
L39: 
L37: 

    /** symtab.e:1070		if No_new_entry then*/
    if (_53No_new_entry_48427 == 0)
    {
        goto L3A; // [1772] 1795
    }
    else{
    }

    /** symtab.e:1071			return {IGNORED,word,defined,dup_globals}*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 509LL;
    RefDS(_word_48430);
    ((intptr_t*)_2)[2] = _word_48430;
    ((intptr_t*)_2)[3] = _defined_48441;
    RefDS(_53dup_globals_48416);
    ((intptr_t*)_2)[4] = _53dup_globals_48416;
    _25215 = MAKE_SEQ(_1);
    DeRefDS(_word_48430);
    DeRef(_msg_48438);
    DeRef(_b_name_48439);
    DeRef(_tok_48447);
    DeRef(_gtok_48448);
    DeRef(_25189);
    _25189 = NOVALUE;
    DeRef(_25036);
    _25036 = NOVALUE;
    _25158 = NOVALUE;
    DeRef(_25101);
    _25101 = NOVALUE;
    _25112 = NOVALUE;
    _25064 = NOVALUE;
    DeRef(_25095);
    _25095 = NOVALUE;
    _25206 = NOVALUE;
    _25156 = NOVALUE;
    _25091 = NOVALUE;
    DeRef(_25120);
    _25120 = NOVALUE;
    _25191 = NOVALUE;
    _25060 = NOVALUE;
    DeRef(_25046);
    _25046 = NOVALUE;
    _25204 = NOVALUE;
    _25080 = NOVALUE;
    _25105 = NOVALUE;
    DeRef(_25185);
    _25185 = NOVALUE;
    _25117 = NOVALUE;
    _25197 = NOVALUE;
    DeRef(_25093);
    _25093 = NOVALUE;
    DeRef(_25087);
    _25087 = NOVALUE;
    DeRef(_25085);
    _25085 = NOVALUE;
    _25073 = NOVALUE;
    _25099 = NOVALUE;
    _25065 = NOVALUE;
    DeRef(_25169);
    _25169 = NOVALUE;
    return _25215;
L3A: 

    /** symtab.e:1074		tok = {VARIABLE, NewEntry(word, 0, defined,*/
    _2 = (object)SEQ_PTR(_53buckets_47223);
    _25216 = (object)*(((s1_ptr)_2)->base + _hashval_48436);
    RefDS(_word_48430);
    Ref(_25216);
    _25217 = _53NewEntry(_word_48430, 0LL, _defined_48441, -100LL, _hashval_48436, _25216, 0LL);
    _25216 = NOVALUE;
    DeRef(_tok_48447);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100LL;
    ((intptr_t *)_2)[2] = _25217;
    _tok_48447 = MAKE_SEQ(_1);
    _25217 = NOVALUE;

    /** symtab.e:1076		buckets[hashval] = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_48447);
    _25219 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_25219);
    _2 = (object)SEQ_PTR(_53buckets_47223);
    _2 = (object)(((s1_ptr)_2)->base + _hashval_48436);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25219;
    if( _1 != _25219 ){
        DeRef(_1);
    }
    _25219 = NOVALUE;

    /** symtab.e:1078		if file_no != -1 then*/
    if (_file_no_48431 == -1LL)
    goto L3B; // [1839] 1865

    /** symtab.e:1079			SymTab[tok[T_SYM]][S_FILE_NO] = file_no*/
    _2 = (object)SEQ_PTR(_tok_48447);
    _25221 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_25221))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_25221)->dbl));
    else
    _3 = (object)(_25221 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_FILE_NO_20205))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _file_no_48431;
    DeRef(_1);
    _25222 = NOVALUE;
L3B: 

    /** symtab.e:1081		return tok  -- no ref on newly declared symbol*/
    DeRefDS(_word_48430);
    DeRef(_msg_48438);
    DeRef(_b_name_48439);
    DeRef(_gtok_48448);
    DeRef(_25189);
    _25189 = NOVALUE;
    DeRef(_25036);
    _25036 = NOVALUE;
    _25158 = NOVALUE;
    DeRef(_25101);
    _25101 = NOVALUE;
    _25221 = NOVALUE;
    _25112 = NOVALUE;
    _25064 = NOVALUE;
    DeRef(_25095);
    _25095 = NOVALUE;
    _25206 = NOVALUE;
    _25156 = NOVALUE;
    _25091 = NOVALUE;
    DeRef(_25120);
    _25120 = NOVALUE;
    _25191 = NOVALUE;
    _25060 = NOVALUE;
    DeRef(_25046);
    _25046 = NOVALUE;
    _25204 = NOVALUE;
    _25080 = NOVALUE;
    _25105 = NOVALUE;
    DeRef(_25185);
    _25185 = NOVALUE;
    DeRef(_25215);
    _25215 = NOVALUE;
    _25117 = NOVALUE;
    _25197 = NOVALUE;
    DeRef(_25093);
    _25093 = NOVALUE;
    DeRef(_25087);
    _25087 = NOVALUE;
    DeRef(_25085);
    _25085 = NOVALUE;
    _25073 = NOVALUE;
    _25099 = NOVALUE;
    _25065 = NOVALUE;
    DeRef(_25169);
    _25169 = NOVALUE;
    return _tok_48447;
    ;
}


void _53Hide(object _s_48841)
{
    object _prev_48843 = NOVALUE;
    object _p_48844 = NOVALUE;
    object _25242 = NOVALUE;
    object _25241 = NOVALUE;
    object _25240 = NOVALUE;
    object _25238 = NOVALUE;
    object _25237 = NOVALUE;
    object _25236 = NOVALUE;
    object _25235 = NOVALUE;
    object _25234 = NOVALUE;
    object _25230 = NOVALUE;
    object _25229 = NOVALUE;
    object _25228 = NOVALUE;
    object _25227 = NOVALUE;
    object _25225 = NOVALUE;
    object _25224 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_48841)) {
        _1 = (object)(DBL_PTR(_s_48841)->dbl);
        DeRefDS(_s_48841);
        _s_48841 = _1;
    }

    /** symtab.e:1090		p = buckets[SymTab[s][S_HASHVAL]]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25224 = (object)*(((s1_ptr)_2)->base + _s_48841);
    _2 = (object)SEQ_PTR(_25224);
    _25225 = (object)*(((s1_ptr)_2)->base + 11LL);
    _25224 = NOVALUE;
    _2 = (object)SEQ_PTR(_53buckets_47223);
    if (!IS_ATOM_INT(_25225)){
        _p_48844 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25225)->dbl));
    }
    else{
        _p_48844 = (object)*(((s1_ptr)_2)->base + _25225);
    }
    if (!IS_ATOM_INT(_p_48844)){
        _p_48844 = (object)DBL_PTR(_p_48844)->dbl;
    }

    /** symtab.e:1091		prev = 0*/
    _prev_48843 = 0LL;

    /** symtab.e:1093		while p != s and p != 0 do*/
L1: 
    _25227 = (_p_48844 != _s_48841);
    if (_25227 == 0) {
        goto L2; // [41] 81
    }
    _25229 = (_p_48844 != 0LL);
    if (_25229 == 0)
    {
        DeRef(_25229);
        _25229 = NOVALUE;
        goto L2; // [50] 81
    }
    else{
        DeRef(_25229);
        _25229 = NOVALUE;
    }

    /** symtab.e:1094			prev = p*/
    _prev_48843 = _p_48844;

    /** symtab.e:1095			p = SymTab[p][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25230 = (object)*(((s1_ptr)_2)->base + _p_48844);
    _2 = (object)SEQ_PTR(_25230);
    _p_48844 = (object)*(((s1_ptr)_2)->base + 9LL);
    if (!IS_ATOM_INT(_p_48844)){
        _p_48844 = (object)DBL_PTR(_p_48844)->dbl;
    }
    _25230 = NOVALUE;

    /** symtab.e:1096		end while*/
    goto L1; // [78] 37
L2: 

    /** symtab.e:1098		if p = 0 then*/
    if (_p_48844 != 0LL)
    goto L3; // [83] 93

    /** symtab.e:1099			return -- already hidden*/
    _25225 = NOVALUE;
    DeRef(_25227);
    _25227 = NOVALUE;
    return;
L3: 

    /** symtab.e:1101		if prev = 0 then*/
    if (_prev_48843 != 0LL)
    goto L4; // [95] 134

    /** symtab.e:1102			buckets[SymTab[s][S_HASHVAL]] = SymTab[s][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25234 = (object)*(((s1_ptr)_2)->base + _s_48841);
    _2 = (object)SEQ_PTR(_25234);
    _25235 = (object)*(((s1_ptr)_2)->base + 11LL);
    _25234 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25236 = (object)*(((s1_ptr)_2)->base + _s_48841);
    _2 = (object)SEQ_PTR(_25236);
    _25237 = (object)*(((s1_ptr)_2)->base + 9LL);
    _25236 = NOVALUE;
    Ref(_25237);
    _2 = (object)SEQ_PTR(_53buckets_47223);
    if (!IS_ATOM_INT(_25235))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_25235)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _25235);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25237;
    if( _1 != _25237 ){
        DeRef(_1);
    }
    _25237 = NOVALUE;
    goto L5; // [131] 162
L4: 

    /** symtab.e:1104			SymTab[prev][S_SAMEHASH] = SymTab[s][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_48843 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25240 = (object)*(((s1_ptr)_2)->base + _s_48841);
    _2 = (object)SEQ_PTR(_25240);
    _25241 = (object)*(((s1_ptr)_2)->base + 9LL);
    _25240 = NOVALUE;
    Ref(_25241);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25241;
    if( _1 != _25241 ){
        DeRef(_1);
    }
    _25241 = NOVALUE;
    _25238 = NOVALUE;
L5: 

    /** symtab.e:1106		SymTab[s][S_SAMEHASH] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_48841 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _25242 = NOVALUE;

    /** symtab.e:1107	end procedure*/
    _25235 = NOVALUE;
    _25225 = NOVALUE;
    DeRef(_25227);
    _25227 = NOVALUE;
    return;
    ;
}


void _53Show(object _s_48886)
{
    object _p_48888 = NOVALUE;
    object _25254 = NOVALUE;
    object _25253 = NOVALUE;
    object _25251 = NOVALUE;
    object _25250 = NOVALUE;
    object _25248 = NOVALUE;
    object _25247 = NOVALUE;
    object _25245 = NOVALUE;
    object _25244 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:1114		p = buckets[SymTab[s][S_HASHVAL]]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25244 = (object)*(((s1_ptr)_2)->base + _s_48886);
    _2 = (object)SEQ_PTR(_25244);
    _25245 = (object)*(((s1_ptr)_2)->base + 11LL);
    _25244 = NOVALUE;
    _2 = (object)SEQ_PTR(_53buckets_47223);
    if (!IS_ATOM_INT(_25245)){
        _p_48888 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25245)->dbl));
    }
    else{
        _p_48888 = (object)*(((s1_ptr)_2)->base + _25245);
    }
    if (!IS_ATOM_INT(_p_48888)){
        _p_48888 = (object)DBL_PTR(_p_48888)->dbl;
    }

    /** symtab.e:1116		if SymTab[s][S_SAMEHASH] or p = s then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25247 = (object)*(((s1_ptr)_2)->base + _s_48886);
    _2 = (object)SEQ_PTR(_25247);
    _25248 = (object)*(((s1_ptr)_2)->base + 9LL);
    _25247 = NOVALUE;
    if (IS_ATOM_INT(_25248)) {
        if (_25248 != 0) {
            goto L1; // [39] 52
        }
    }
    else {
        if (DBL_PTR(_25248)->dbl != 0.0) {
            goto L1; // [39] 52
        }
    }
    _25250 = (_p_48888 == _s_48886);
    if (_25250 == 0)
    {
        DeRef(_25250);
        _25250 = NOVALUE;
        goto L2; // [48] 58
    }
    else{
        DeRef(_25250);
        _25250 = NOVALUE;
    }
L1: 

    /** symtab.e:1118			return*/
    _25248 = NOVALUE;
    _25245 = NOVALUE;
    return;
L2: 

    /** symtab.e:1121		SymTab[s][S_SAMEHASH] = p*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_48886 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _p_48888;
    DeRef(_1);
    _25251 = NOVALUE;

    /** symtab.e:1122		buckets[SymTab[s][S_HASHVAL]] = s*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25253 = (object)*(((s1_ptr)_2)->base + _s_48886);
    _2 = (object)SEQ_PTR(_25253);
    _25254 = (object)*(((s1_ptr)_2)->base + 11LL);
    _25253 = NOVALUE;
    _2 = (object)SEQ_PTR(_53buckets_47223);
    if (!IS_ATOM_INT(_25254))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_25254)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _25254);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_48886;
    DeRef(_1);

    /** symtab.e:1124	end procedure*/
    _25248 = NOVALUE;
    _25254 = NOVALUE;
    _25245 = NOVALUE;
    return;
    ;
}


void _53hide_params(object _s_48912)
{
    object _param_48914 = NOVALUE;
    object _25257 = NOVALUE;
    object _25256 = NOVALUE;
    object _25255 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1127		symtab_index param = s*/
    _param_48914 = _s_48912;

    /** symtab.e:1128		for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25255 = (object)*(((s1_ptr)_2)->base + _s_48912);
    _2 = (object)SEQ_PTR(_25255);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _25256 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _25256 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _25255 = NOVALUE;
    {
        object _i_48916;
        _i_48916 = 1LL;
L1: 
        if (binary_op_a(GREATER, _i_48916, _25256)){
            goto L2; // [24] 59
        }

        /** symtab.e:1129			param = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _25257 = (object)*(((s1_ptr)_2)->base + _s_48912);
        _2 = (object)SEQ_PTR(_25257);
        _param_48914 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_param_48914)){
            _param_48914 = (object)DBL_PTR(_param_48914)->dbl;
        }
        _25257 = NOVALUE;

        /** symtab.e:1130			Hide( param )*/
        _53Hide(_param_48914);

        /** symtab.e:1131		end for*/
        _0 = _i_48916;
        if (IS_ATOM_INT(_i_48916)) {
            _i_48916 = _i_48916 + 1LL;
            if ((object)((uintptr_t)_i_48916 +(uintptr_t) HIGH_BITS) >= 0){
                _i_48916 = NewDouble((eudouble)_i_48916);
            }
        }
        else {
            _i_48916 = binary_op_a(PLUS, _i_48916, 1LL);
        }
        DeRef(_0);
        goto L1; // [54] 31
L2: 
        ;
        DeRef(_i_48916);
    }

    /** symtab.e:1132	end procedure*/
    _25256 = NOVALUE;
    return;
    ;
}


void _53show_params(object _s_48928)
{
    object _param_48930 = NOVALUE;
    object _25261 = NOVALUE;
    object _25260 = NOVALUE;
    object _25259 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1135		symtab_index param = s*/
    _param_48930 = _s_48928;

    /** symtab.e:1136		for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25259 = (object)*(((s1_ptr)_2)->base + _s_48928);
    _2 = (object)SEQ_PTR(_25259);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _25260 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _25260 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _25259 = NOVALUE;
    {
        object _i_48932;
        _i_48932 = 1LL;
L1: 
        if (binary_op_a(GREATER, _i_48932, _25260)){
            goto L2; // [24] 59
        }

        /** symtab.e:1137			param = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _25261 = (object)*(((s1_ptr)_2)->base + _s_48928);
        _2 = (object)SEQ_PTR(_25261);
        _param_48930 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_param_48930)){
            _param_48930 = (object)DBL_PTR(_param_48930)->dbl;
        }
        _25261 = NOVALUE;

        /** symtab.e:1138			Show( param )*/
        _53Show(_param_48930);

        /** symtab.e:1139		end for*/
        _0 = _i_48932;
        if (IS_ATOM_INT(_i_48932)) {
            _i_48932 = _i_48932 + 1LL;
            if ((object)((uintptr_t)_i_48932 +(uintptr_t) HIGH_BITS) >= 0){
                _i_48932 = NewDouble((eudouble)_i_48932);
            }
        }
        else {
            _i_48932 = binary_op_a(PLUS, _i_48932, 1LL);
        }
        DeRef(_0);
        goto L1; // [54] 31
L2: 
        ;
        DeRef(_i_48932);
    }

    /** symtab.e:1140	end procedure*/
    _25260 = NOVALUE;
    return;
    ;
}


void _53LintCheck(object _s_48944)
{
    object _warn_level_48945 = NOVALUE;
    object _file_48946 = NOVALUE;
    object _vscope_48947 = NOVALUE;
    object _vname_48948 = NOVALUE;
    object _vusage_48949 = NOVALUE;
    object _25325 = NOVALUE;
    object _25324 = NOVALUE;
    object _25323 = NOVALUE;
    object _25322 = NOVALUE;
    object _25321 = NOVALUE;
    object _25320 = NOVALUE;
    object _25317 = NOVALUE;
    object _25316 = NOVALUE;
    object _25315 = NOVALUE;
    object _25314 = NOVALUE;
    object _25313 = NOVALUE;
    object _25312 = NOVALUE;
    object _25309 = NOVALUE;
    object _25308 = NOVALUE;
    object _25307 = NOVALUE;
    object _25306 = NOVALUE;
    object _25305 = NOVALUE;
    object _25304 = NOVALUE;
    object _25301 = NOVALUE;
    object _25299 = NOVALUE;
    object _25298 = NOVALUE;
    object _25296 = NOVALUE;
    object _25295 = NOVALUE;
    object _25293 = NOVALUE;
    object _25292 = NOVALUE;
    object _25291 = NOVALUE;
    object _25290 = NOVALUE;
    object _25287 = NOVALUE;
    object _25286 = NOVALUE;
    object _25282 = NOVALUE;
    object _25279 = NOVALUE;
    object _25278 = NOVALUE;
    object _25277 = NOVALUE;
    object _25276 = NOVALUE;
    object _25273 = NOVALUE;
    object _25272 = NOVALUE;
    object _25267 = NOVALUE;
    object _25265 = NOVALUE;
    object _25263 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_48944)) {
        _1 = (object)(DBL_PTR(_s_48944)->dbl);
        DeRefDS(_s_48944);
        _s_48944 = _1;
    }

    /** symtab.e:1150		vusage = SymTab[s][S_USAGE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25263 = (object)*(((s1_ptr)_2)->base + _s_48944);
    _2 = (object)SEQ_PTR(_25263);
    _vusage_48949 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (!IS_ATOM_INT(_vusage_48949)){
        _vusage_48949 = (object)DBL_PTR(_vusage_48949)->dbl;
    }
    _25263 = NOVALUE;

    /** symtab.e:1151		vscope = SymTab[s][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25265 = (object)*(((s1_ptr)_2)->base + _s_48944);
    _2 = (object)SEQ_PTR(_25265);
    _vscope_48947 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_vscope_48947)){
        _vscope_48947 = (object)DBL_PTR(_vscope_48947)->dbl;
    }
    _25265 = NOVALUE;

    /** symtab.e:1152		vname = SymTab[s][S_NAME]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25267 = (object)*(((s1_ptr)_2)->base + _s_48944);
    DeRef(_vname_48948);
    _2 = (object)SEQ_PTR(_25267);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _vname_48948 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _vname_48948 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    Ref(_vname_48948);
    _25267 = NOVALUE;

    /** symtab.e:1154		switch vusage do*/
    _0 = _vusage_48949;
    switch ( _0 ){ 

        /** symtab.e:1156			case U_UNUSED then*/
        case 0:

        /** symtab.e:1157				warn_level = 1*/
        _warn_level_48945 = 1LL;
        goto L1; // [67] 193

        /** symtab.e:1159			case U_WRITTEN then -- Set but never read*/
        case 2:

        /** symtab.e:1160				warn_level = 2*/
        _warn_level_48945 = 2LL;

        /** symtab.e:1162				if vscope > SC_LOCAL then*/
        if (_vscope_48947 <= 5LL)
        goto L2; // [82] 94

        /** symtab.e:1164					warn_level = 0 */
        _warn_level_48945 = 0LL;
        goto L1; // [91] 193
L2: 

        /** symtab.e:1166				elsif SymTab[s][S_MODE] = M_CONSTANT then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _25272 = (object)*(((s1_ptr)_2)->base + _s_48944);
        _2 = (object)SEQ_PTR(_25272);
        _25273 = (object)*(((s1_ptr)_2)->base + 3LL);
        _25272 = NOVALUE;
        if (binary_op_a(NOTEQ, _25273, 2LL)){
            _25273 = NOVALUE;
            goto L1; // [110] 193
        }
        _25273 = NOVALUE;

        /** symtab.e:1167					if not Strict_is_on then*/
        if (_27Strict_is_on_20637 != 0)
        goto L1; // [118] 193

        /** symtab.e:1170						warn_level = 0 */
        _warn_level_48945 = 0LL;
        goto L1; // [129] 193

        /** symtab.e:1174			case U_READ then -- Read but never set*/
        case 1:

        /** symtab.e:1175				if SymTab[s][S_VARNUM] >= SymTab[CurrentSub][S_NUM_ARGS] then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _25276 = (object)*(((s1_ptr)_2)->base + _s_48944);
        _2 = (object)SEQ_PTR(_25276);
        _25277 = (object)*(((s1_ptr)_2)->base + 16LL);
        _25276 = NOVALUE;
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _25278 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
        _2 = (object)SEQ_PTR(_25278);
        if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
            _25279 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
        }
        else{
            _25279 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
        }
        _25278 = NOVALUE;
        if (binary_op_a(LESS, _25277, _25279)){
            _25277 = NOVALUE;
            _25279 = NOVALUE;
            goto L3; // [163] 175
        }
        _25277 = NOVALUE;
        _25279 = NOVALUE;

        /** symtab.e:1176			    	warn_level = 3*/
        _warn_level_48945 = 3LL;
        goto L1; // [172] 193
L3: 

        /** symtab.e:1179			    	warn_level = 0*/
        _warn_level_48945 = 0LL;
        goto L1; // [181] 193

        /** symtab.e:1182		    case else*/
        default:

        /** symtab.e:1183		    	warn_level = 0*/
        _warn_level_48945 = 0LL;
    ;}L1: 

    /** symtab.e:1186		if warn_level = 0 then*/
    if (_warn_level_48945 != 0LL)
    goto L4; // [197] 207

    /** symtab.e:1187			return*/
    DeRef(_file_48946);
    DeRef(_vname_48948);
    return;
L4: 

    /** symtab.e:1191		file = abbreviate_path(known_files[current_file_no])*/
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _25282 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    Ref(_25282);
    RefDS(_22218);
    _0 = _file_48946;
    _file_48946 = _15abbreviate_path(_25282, _22218);
    DeRef(_0);
    _25282 = NOVALUE;

    /** symtab.e:1192		if warn_level = 3 then*/
    if (_warn_level_48945 != 3LL)
    goto L5; // [226] 308

    /** symtab.e:1193			if vscope = SC_LOCAL then*/
    if (_vscope_48947 != 5LL)
    goto L6; // [234] 275

    /** symtab.e:1194				if current_file_no = SymTab[s][S_FILE_NO] then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25286 = (object)*(((s1_ptr)_2)->base + _s_48944);
    _2 = (object)SEQ_PTR(_25286);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _25287 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _25287 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _25286 = NOVALUE;
    if (binary_op_a(NOTEQ, _27current_file_no_20571, _25287)){
        _25287 = NOVALUE;
        goto L7; // [254] 602
    }
    _25287 = NOVALUE;

    /** symtab.e:1195					Warning(226, no_value_warning_flag, {file,  vname})*/
    RefDS(_vname_48948);
    RefDS(_file_48946);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48946;
    ((intptr_t *)_2)[2] = _vname_48948;
    _25290 = MAKE_SEQ(_1);
    _49Warning(226LL, 32LL, _25290);
    _25290 = NOVALUE;
    goto L7; // [272] 602
L6: 

    /** symtab.e:1198				Warning(227, no_value_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25291 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_25291);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _25292 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _25292 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _25291 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48946);
    ((intptr_t*)_2)[1] = _file_48946;
    RefDS(_vname_48948);
    ((intptr_t*)_2)[2] = _vname_48948;
    Ref(_25292);
    ((intptr_t*)_2)[3] = _25292;
    _25293 = MAKE_SEQ(_1);
    _25292 = NOVALUE;
    _49Warning(227LL, 32LL, _25293);
    _25293 = NOVALUE;
    goto L7; // [305] 602
L5: 

    /** symtab.e:1201			if vscope = SC_LOCAL then*/
    if (_vscope_48947 != 5LL)
    goto L8; // [312] 412

    /** symtab.e:1202				if current_file_no = SymTab[s][S_FILE_NO] then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25295 = (object)*(((s1_ptr)_2)->base + _s_48944);
    _2 = (object)SEQ_PTR(_25295);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _25296 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _25296 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _25295 = NOVALUE;
    if (binary_op_a(NOTEQ, _27current_file_no_20571, _25296)){
        _25296 = NOVALUE;
        goto L9; // [332] 601
    }
    _25296 = NOVALUE;

    /** symtab.e:1203					if SymTab[s][S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25298 = (object)*(((s1_ptr)_2)->base + _s_48944);
    _2 = (object)SEQ_PTR(_25298);
    _25299 = (object)*(((s1_ptr)_2)->base + 3LL);
    _25298 = NOVALUE;
    if (binary_op_a(NOTEQ, _25299, 2LL)){
        _25299 = NOVALUE;
        goto LA; // [352] 372
    }
    _25299 = NOVALUE;

    /** symtab.e:1204						Warning(228, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_48948);
    RefDS(_file_48946);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48946;
    ((intptr_t *)_2)[2] = _vname_48948;
    _25301 = MAKE_SEQ(_1);
    _49Warning(228LL, 16LL, _25301);
    _25301 = NOVALUE;
    goto L9; // [369] 601
LA: 

    /** symtab.e:1206					elsif warn_level = 1 then*/
    if (_warn_level_48945 != 1LL)
    goto LB; // [374] 394

    /** symtab.e:1207						Warning(229, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_48948);
    RefDS(_file_48946);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48946;
    ((intptr_t *)_2)[2] = _vname_48948;
    _25304 = MAKE_SEQ(_1);
    _49Warning(229LL, 16LL, _25304);
    _25304 = NOVALUE;
    goto L9; // [391] 601
LB: 

    /** symtab.e:1210						Warning(320, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_48948);
    RefDS(_file_48946);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48946;
    ((intptr_t *)_2)[2] = _vname_48948;
    _25305 = MAKE_SEQ(_1);
    _49Warning(320LL, 16LL, _25305);
    _25305 = NOVALUE;
    goto L9; // [409] 601
L8: 

    /** symtab.e:1214				if SymTab[s][S_VARNUM] < SymTab[CurrentSub][S_NUM_ARGS] then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25306 = (object)*(((s1_ptr)_2)->base + _s_48944);
    _2 = (object)SEQ_PTR(_25306);
    _25307 = (object)*(((s1_ptr)_2)->base + 16LL);
    _25306 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25308 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_25308);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _25309 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _25309 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _25308 = NOVALUE;
    if (binary_op_a(GREATEREQ, _25307, _25309)){
        _25307 = NOVALUE;
        _25309 = NOVALUE;
        goto LC; // [440] 523
    }
    _25307 = NOVALUE;
    _25309 = NOVALUE;

    /** symtab.e:1216					if warn_level = 1 then*/
    if (_warn_level_48945 != 1LL)
    goto LD; // [446] 490

    /** symtab.e:1217						if Strict_is_on then*/
    if (_27Strict_is_on_20637 == 0)
    {
        goto LE; // [454] 600
    }
    else{
    }

    /** symtab.e:1219							Warning(230, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25312 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_25312);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _25313 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _25313 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _25312 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48946);
    ((intptr_t*)_2)[1] = _file_48946;
    RefDS(_vname_48948);
    ((intptr_t*)_2)[2] = _vname_48948;
    Ref(_25313);
    ((intptr_t*)_2)[3] = _25313;
    _25314 = MAKE_SEQ(_1);
    _25313 = NOVALUE;
    _49Warning(230LL, 16LL, _25314);
    _25314 = NOVALUE;
    goto LE; // [487] 600
LD: 

    /** symtab.e:1222						Warning(321, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25315 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_25315);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _25316 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _25316 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _25315 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48946);
    ((intptr_t*)_2)[1] = _file_48946;
    RefDS(_vname_48948);
    ((intptr_t*)_2)[2] = _vname_48948;
    Ref(_25316);
    ((intptr_t*)_2)[3] = _25316;
    _25317 = MAKE_SEQ(_1);
    _25316 = NOVALUE;
    _49Warning(321LL, 16LL, _25317);
    _25317 = NOVALUE;
    goto LE; // [520] 600
LC: 

    /** symtab.e:1226					if warn_level = 1 then*/
    if (_warn_level_48945 != 1LL)
    goto LF; // [525] 569

    /** symtab.e:1227						if Strict_is_on then*/
    if (_27Strict_is_on_20637 == 0)
    {
        goto L10; // [533] 599
    }
    else{
    }

    /** symtab.e:1229							Warning(231, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25320 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_25320);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _25321 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _25321 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _25320 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48946);
    ((intptr_t*)_2)[1] = _file_48946;
    RefDS(_vname_48948);
    ((intptr_t*)_2)[2] = _vname_48948;
    Ref(_25321);
    ((intptr_t*)_2)[3] = _25321;
    _25322 = MAKE_SEQ(_1);
    _25321 = NOVALUE;
    _49Warning(231LL, 16LL, _25322);
    _25322 = NOVALUE;
    goto L10; // [566] 599
LF: 

    /** symtab.e:1232						Warning(322, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25323 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_25323);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _25324 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _25324 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _25323 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48946);
    ((intptr_t*)_2)[1] = _file_48946;
    RefDS(_vname_48948);
    ((intptr_t*)_2)[2] = _vname_48948;
    Ref(_25324);
    ((intptr_t*)_2)[3] = _25324;
    _25325 = MAKE_SEQ(_1);
    _25324 = NOVALUE;
    _49Warning(322LL, 16LL, _25325);
    _25325 = NOVALUE;
L10: 
LE: 
L9: 
L7: 

    /** symtab.e:1238	end procedure*/
    DeRef(_file_48946);
    DeRef(_vname_48948);
    return;
    ;
}


void _53HideLocals()
{
    object _s_49118 = NOVALUE;
    object _25338 = NOVALUE;
    object _25336 = NOVALUE;
    object _25335 = NOVALUE;
    object _25334 = NOVALUE;
    object _25333 = NOVALUE;
    object _25332 = NOVALUE;
    object _25331 = NOVALUE;
    object _25330 = NOVALUE;
    object _25329 = NOVALUE;
    object _25328 = NOVALUE;
    object _25327 = NOVALUE;
    object _25326 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1244		mark_rechecks()*/
    _53mark_rechecks(_27current_file_no_20571);

    /** symtab.e:1245		s = file_start_sym*/
    _s_49118 = _27file_start_sym_20577;

    /** symtab.e:1246		while s do*/
L1: 
    if (_s_49118 == 0)
    {
        goto L2; // [22] 148
    }
    else{
    }

    /** symtab.e:1247			if SymTab[s][S_SCOPE] = SC_LOCAL and*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25326 = (object)*(((s1_ptr)_2)->base + _s_49118);
    _2 = (object)SEQ_PTR(_25326);
    _25327 = (object)*(((s1_ptr)_2)->base + 4LL);
    _25326 = NOVALUE;
    if (IS_ATOM_INT(_25327)) {
        _25328 = (_25327 == 5LL);
    }
    else {
        _25328 = binary_op(EQUALS, _25327, 5LL);
    }
    _25327 = NOVALUE;
    if (IS_ATOM_INT(_25328)) {
        if (_25328 == 0) {
            goto L3; // [45] 127
        }
    }
    else {
        if (DBL_PTR(_25328)->dbl == 0.0) {
            goto L3; // [45] 127
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25330 = (object)*(((s1_ptr)_2)->base + _s_49118);
    _2 = (object)SEQ_PTR(_25330);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _25331 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _25331 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _25330 = NOVALUE;
    if (IS_ATOM_INT(_25331)) {
        _25332 = (_25331 == _27current_file_no_20571);
    }
    else {
        _25332 = binary_op(EQUALS, _25331, _27current_file_no_20571);
    }
    _25331 = NOVALUE;
    if (_25332 == 0) {
        DeRef(_25332);
        _25332 = NOVALUE;
        goto L3; // [68] 127
    }
    else {
        if (!IS_ATOM_INT(_25332) && DBL_PTR(_25332)->dbl == 0.0){
            DeRef(_25332);
            _25332 = NOVALUE;
            goto L3; // [68] 127
        }
        DeRef(_25332);
        _25332 = NOVALUE;
    }
    DeRef(_25332);
    _25332 = NOVALUE;

    /** symtab.e:1249			   	if current_block = top_level_block and repl then*/
    _25333 = (_64current_block_25492 == _64top_level_block_25493);
    if (_25333 == 0) {
        goto L4; // [81] 94
    }
    goto L4; // [88] 94
    goto L5; // [91] 100
L4: 

    /** symtab.e:1251				Hide(s)*/
    _53Hide(_s_49118);
L5: 

    /** symtab.e:1253				if SymTab[s][S_TOKEN] = VARIABLE then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25335 = (object)*(((s1_ptr)_2)->base + _s_49118);
    _2 = (object)SEQ_PTR(_25335);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _25336 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _25336 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _25335 = NOVALUE;
    if (binary_op_a(NOTEQ, _25336, -100LL)){
        _25336 = NOVALUE;
        goto L6; // [116] 126
    }
    _25336 = NOVALUE;

    /** symtab.e:1254					LintCheck(s)*/
    _53LintCheck(_s_49118);
L6: 
L3: 

    /** symtab.e:1257			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25338 = (object)*(((s1_ptr)_2)->base + _s_49118);
    _2 = (object)SEQ_PTR(_25338);
    _s_49118 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_49118)){
        _s_49118 = (object)DBL_PTR(_s_49118)->dbl;
    }
    _25338 = NOVALUE;

    /** symtab.e:1258		end while*/
    goto L1; // [145] 22
L2: 

    /** symtab.e:1259	end procedure*/
    DeRef(_25328);
    _25328 = NOVALUE;
    DeRef(_25333);
    _25333 = NOVALUE;
    return;
    ;
}


object _53sym_name(object _sym_49157)
{
    object _25341 = NOVALUE;
    object _25340 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_49157)) {
        _1 = (object)(DBL_PTR(_sym_49157)->dbl);
        DeRefDS(_sym_49157);
        _sym_49157 = _1;
    }

    /** symtab.e:1262		return SymTab[sym][S_NAME]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25340 = (object)*(((s1_ptr)_2)->base + _sym_49157);
    _2 = (object)SEQ_PTR(_25340);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _25341 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _25341 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _25340 = NOVALUE;
    Ref(_25341);
    return _25341;
    ;
}


object _53sym_token(object _sym_49165)
{
    object _25343 = NOVALUE;
    object _25342 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_49165)) {
        _1 = (object)(DBL_PTR(_sym_49165)->dbl);
        DeRefDS(_sym_49165);
        _sym_49165 = _1;
    }

    /** symtab.e:1266		return SymTab[sym][S_TOKEN]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25342 = (object)*(((s1_ptr)_2)->base + _sym_49165);
    _2 = (object)SEQ_PTR(_25342);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _25343 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _25343 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _25342 = NOVALUE;
    Ref(_25343);
    return _25343;
    ;
}


object _53sym_scope(object _sym_49173)
{
    object _25345 = NOVALUE;
    object _25344 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_49173)) {
        _1 = (object)(DBL_PTR(_sym_49173)->dbl);
        DeRefDS(_sym_49173);
        _sym_49173 = _1;
    }

    /** symtab.e:1270		return SymTab[sym][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25344 = (object)*(((s1_ptr)_2)->base + _sym_49173);
    _2 = (object)SEQ_PTR(_25344);
    _25345 = (object)*(((s1_ptr)_2)->base + 4LL);
    _25344 = NOVALUE;
    Ref(_25345);
    return _25345;
    ;
}


object _53sym_mode(object _sym_49181)
{
    object _25347 = NOVALUE;
    object _25346 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_49181)) {
        _1 = (object)(DBL_PTR(_sym_49181)->dbl);
        DeRefDS(_sym_49181);
        _sym_49181 = _1;
    }

    /** symtab.e:1274		return SymTab[sym][S_MODE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25346 = (object)*(((s1_ptr)_2)->base + _sym_49181);
    _2 = (object)SEQ_PTR(_25346);
    _25347 = (object)*(((s1_ptr)_2)->base + 3LL);
    _25346 = NOVALUE;
    Ref(_25347);
    return _25347;
    ;
}


object _53sym_obj(object _sym_49189)
{
    object _25349 = NOVALUE;
    object _25348 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_49189)) {
        _1 = (object)(DBL_PTR(_sym_49189)->dbl);
        DeRefDS(_sym_49189);
        _sym_49189 = _1;
    }

    /** symtab.e:1278		return SymTab[sym][S_OBJ]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25348 = (object)*(((s1_ptr)_2)->base + _sym_49189);
    _2 = (object)SEQ_PTR(_25348);
    _25349 = (object)*(((s1_ptr)_2)->base + 1LL);
    _25348 = NOVALUE;
    Ref(_25349);
    return _25349;
    ;
}


object _53sym_next(object _sym_49197)
{
    object _25351 = NOVALUE;
    object _25350 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1282		return SymTab[sym][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25350 = (object)*(((s1_ptr)_2)->base + _sym_49197);
    _2 = (object)SEQ_PTR(_25350);
    _25351 = (object)*(((s1_ptr)_2)->base + 2LL);
    _25350 = NOVALUE;
    Ref(_25351);
    return _25351;
    ;
}


object _53sym_block(object _sym_49205)
{
    object _25353 = NOVALUE;
    object _25352 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1286		return SymTab[sym][S_BLOCK]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25352 = (object)*(((s1_ptr)_2)->base + _sym_49205);
    _2 = (object)SEQ_PTR(_25352);
    if (!IS_ATOM_INT(_27S_BLOCK_20229)){
        _25353 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_BLOCK_20229)->dbl));
    }
    else{
        _25353 = (object)*(((s1_ptr)_2)->base + _27S_BLOCK_20229);
    }
    _25352 = NOVALUE;
    Ref(_25353);
    return _25353;
    ;
}


object _53sym_next_in_block(object _sym_49213)
{
    object _25355 = NOVALUE;
    object _25354 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1290		return SymTab[sym][S_NEXT_IN_BLOCK]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25354 = (object)*(((s1_ptr)_2)->base + _sym_49213);
    _2 = (object)SEQ_PTR(_25354);
    if (!IS_ATOM_INT(_27S_NEXT_IN_BLOCK_20201)){
        _25355 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NEXT_IN_BLOCK_20201)->dbl));
    }
    else{
        _25355 = (object)*(((s1_ptr)_2)->base + _27S_NEXT_IN_BLOCK_20201);
    }
    _25354 = NOVALUE;
    Ref(_25355);
    return _25355;
    ;
}


object _53sym_usage(object _sym_49221)
{
    object _25357 = NOVALUE;
    object _25356 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1294		return SymTab[sym][S_USAGE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25356 = (object)*(((s1_ptr)_2)->base + _sym_49221);
    _2 = (object)SEQ_PTR(_25356);
    _25357 = (object)*(((s1_ptr)_2)->base + 5LL);
    _25356 = NOVALUE;
    Ref(_25357);
    return _25357;
    ;
}



// 0x1C9061E3
