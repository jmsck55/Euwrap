// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _71set_colors(object _pColorList_72456)
{
    object _lColorName_72457 = NOVALUE;
    object _36196 = NOVALUE;
    object _36193 = NOVALUE;
    object _36190 = NOVALUE;
    object _36187 = NOVALUE;
    object _36184 = NOVALUE;
    object _36181 = NOVALUE;
    object _36178 = NOVALUE;
    object _36173 = NOVALUE;
    object _36172 = NOVALUE;
    object _36171 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:48		for i = 1 to length(pColorList) do*/
    _36171 = 6;
    {
        object _i_72459;
        _i_72459 = 1LL;
L1: 
        if (_i_72459 > 6LL){
            goto L2; // [8] 168
        }

        /** syncolor.e:49			lColorName = text:upper(pColorList[i][1])*/
        _2 = (object)SEQ_PTR(_pColorList_72456);
        _36172 = (object)*(((s1_ptr)_2)->base + _i_72459);
        _2 = (object)SEQ_PTR(_36172);
        _36173 = (object)*(((s1_ptr)_2)->base + 1LL);
        _36172 = NOVALUE;
        Ref(_36173);
        _0 = _lColorName_72457;
        _lColorName_72457 = _12upper(_36173);
        DeRef(_0);
        _36173 = NOVALUE;

        /** syncolor.e:50			switch lColorName do*/
        _1 = find(_lColorName_72457, _36175);
        switch ( _1 ){ 

            /** syncolor.e:51				case "NORMAL" then*/
            case 1:

            /** syncolor.e:52					NORMAL_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_72456);
            _36178 = (object)*(((s1_ptr)_2)->base + _i_72459);
            _2 = (object)SEQ_PTR(_36178);
            _71NORMAL_COLOR_72445 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_71NORMAL_COLOR_72445)){
                _71NORMAL_COLOR_72445 = (object)DBL_PTR(_71NORMAL_COLOR_72445)->dbl;
            }
            _36178 = NOVALUE;
            goto L3; // [54] 161

            /** syncolor.e:53				case "COMMENT" then*/
            case 2:

            /** syncolor.e:54					COMMENT_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_72456);
            _36181 = (object)*(((s1_ptr)_2)->base + _i_72459);
            _2 = (object)SEQ_PTR(_36181);
            _71COMMENT_COLOR_72446 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_71COMMENT_COLOR_72446)){
                _71COMMENT_COLOR_72446 = (object)DBL_PTR(_71COMMENT_COLOR_72446)->dbl;
            }
            _36181 = NOVALUE;
            goto L3; // [72] 161

            /** syncolor.e:55				case "KEYWORD" then*/
            case 3:

            /** syncolor.e:56					KEYWORD_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_72456);
            _36184 = (object)*(((s1_ptr)_2)->base + _i_72459);
            _2 = (object)SEQ_PTR(_36184);
            _71KEYWORD_COLOR_72447 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_71KEYWORD_COLOR_72447)){
                _71KEYWORD_COLOR_72447 = (object)DBL_PTR(_71KEYWORD_COLOR_72447)->dbl;
            }
            _36184 = NOVALUE;
            goto L3; // [90] 161

            /** syncolor.e:57				case "BUILTIN" then*/
            case 4:

            /** syncolor.e:58					BUILTIN_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_72456);
            _36187 = (object)*(((s1_ptr)_2)->base + _i_72459);
            _2 = (object)SEQ_PTR(_36187);
            _71BUILTIN_COLOR_72448 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_71BUILTIN_COLOR_72448)){
                _71BUILTIN_COLOR_72448 = (object)DBL_PTR(_71BUILTIN_COLOR_72448)->dbl;
            }
            _36187 = NOVALUE;
            goto L3; // [108] 161

            /** syncolor.e:59				case "STRING" then*/
            case 5:

            /** syncolor.e:60					STRING_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_72456);
            _36190 = (object)*(((s1_ptr)_2)->base + _i_72459);
            _2 = (object)SEQ_PTR(_36190);
            _71STRING_COLOR_72449 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_71STRING_COLOR_72449)){
                _71STRING_COLOR_72449 = (object)DBL_PTR(_71STRING_COLOR_72449)->dbl;
            }
            _36190 = NOVALUE;
            goto L3; // [126] 161

            /** syncolor.e:61				case "BRACKET" then*/
            case 6:

            /** syncolor.e:62					BRACKET_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_72456);
            _36193 = (object)*(((s1_ptr)_2)->base + _i_72459);
            DeRef(_71BRACKET_COLOR_72450);
            _2 = (object)SEQ_PTR(_36193);
            _71BRACKET_COLOR_72450 = (object)*(((s1_ptr)_2)->base + 2LL);
            Ref(_71BRACKET_COLOR_72450);
            _36193 = NOVALUE;
            goto L3; // [144] 161

            /** syncolor.e:63				case else*/
            case 0:

            /** syncolor.e:64					printf(2, "syncolor.e: Unknown color name '%s', ignored.\n", {lColorName})*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            RefDS(_lColorName_72457);
            ((intptr_t*)_2)[1] = _lColorName_72457;
            _36196 = MAKE_SEQ(_1);
            EPrintf(2LL, _36195, _36196);
            DeRefDS(_36196);
            _36196 = NOVALUE;
        ;}L3: 

        /** syncolor.e:66		end for*/
        _i_72459 = _i_72459 + 1LL;
        goto L1; // [163] 15
L2: 
        ;
    }

    /** syncolor.e:67	end procedure*/
    DeRefDS(_pColorList_72456);
    DeRef(_lColorName_72457);
    return;
    ;
}


void _71init_class()
{
    object _0, _1, _2;
    

    /** syncolor.e:71		NORMAL_COLOR  = #330033*/
    _71NORMAL_COLOR_72445 = 3342387LL;

    /** syncolor.e:72		COMMENT_COLOR = #FF0055*/
    _71COMMENT_COLOR_72446 = 16711765LL;

    /** syncolor.e:73		KEYWORD_COLOR = #0000FF*/
    _71KEYWORD_COLOR_72447 = 255LL;

    /** syncolor.e:74		BUILTIN_COLOR = #FF00FF*/
    _71BUILTIN_COLOR_72448 = 16711935LL;

    /** syncolor.e:75		STRING_COLOR  = #00A033*/
    _71STRING_COLOR_72449 = 41011LL;

    /** syncolor.e:76		BRACKET_COLOR = {NORMAL_COLOR, #993333, #0000FF, #5500FF, #00FF00}*/
    _0 = _71BRACKET_COLOR_72450;
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 3342387LL;
    ((intptr_t*)_2)[2] = 10040115LL;
    ((intptr_t*)_2)[3] = 255LL;
    ((intptr_t*)_2)[4] = 5570815LL;
    ((intptr_t*)_2)[5] = 65280LL;
    _71BRACKET_COLOR_72450 = MAKE_SEQ(_1);
    DeRef(_0);

    /** syncolor.e:78	end procedure*/
    return;
    ;
}


object _71default_state(object _token_72523)
{
    object _36214 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:103		if not token then*/
    if (IS_ATOM_INT(_token_72523)) {
        if (_token_72523 != 0){
            goto L1; // [3] 12
        }
    }
    else {
        if (DBL_PTR(_token_72523)->dbl != 0.0){
            goto L1; // [3] 12
        }
    }

    /** syncolor.e:104			token = tokenize:new()*/
    _0 = _token_72523;
    _token_72523 = _72new();
    DeRef(_0);
L1: 

    /** syncolor.e:106		return {*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_token_72523);
    ((intptr_t*)_2)[1] = _token_72523;
    ((intptr_t*)_2)[2] = 0LL;
    ((intptr_t*)_2)[3] = 0LL;
    _36214 = MAKE_SEQ(_1);
    DeRef(_token_72523);
    return _36214;
    ;
}


object _71new()
{
    object _state_72533 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:124		atom state = eumem:malloc()*/
    _0 = _state_72533;
    _state_72533 = _35malloc(1LL, 1LL);
    DeRef(_0);

    /** syncolor.e:126		reset(state)*/
    Ref(_state_72533);
    _71reset(_state_72533);

    /** syncolor.e:128		return state*/
    return _state_72533;
    ;
}


void _71tokenize_reset(object _token_72538)
{
    object _reset_1__tmp_at7_72541 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:138		if token then*/
    if (_token_72538 == 0) {
        goto L1; // [3] 27
    }
    else {
        if (!IS_ATOM_INT(_token_72538) && DBL_PTR(_token_72538)->dbl == 0.0){
            goto L1; // [3] 27
        }
    }

    /** syncolor.e:139			tokenize:reset(token)*/

    /** tokenize.e:215		eumem:ram_space[state] = default_state()*/
    _0 = _reset_1__tmp_at7_72541;
    _reset_1__tmp_at7_72541 = _72default_state();
    DeRef(_0);
    Ref(_reset_1__tmp_at7_72541);
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_13045 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_token_72538))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_token_72538)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _token_72538);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _reset_1__tmp_at7_72541;
    DeRef(_1);

    /** tokenize.e:216	end procedure*/
    goto L2; // [21] 24
L2: 
    DeRef(_reset_1__tmp_at7_72541);
    _reset_1__tmp_at7_72541 = NOVALUE;
L1: 

    /** syncolor.e:141	end procedure*/
    DeRef(_token_72538);
    return;
    ;
}


void _71reset(object _state_72544)
{
    object _token_72545 = NOVALUE;
    object _36221 = NOVALUE;
    object _36220 = NOVALUE;
    object _36218 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:144		atom token = eumem:ram_space[state][S_TOKENIZER]*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!IS_ATOM_INT(_state_72544)){
        _36218 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_state_72544)->dbl));
    }
    else{
        _36218 = (object)*(((s1_ptr)_2)->base + _state_72544);
    }
    DeRef(_token_72545);
    _2 = (object)SEQ_PTR(_36218);
    _token_72545 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_token_72545);
    _36218 = NOVALUE;

    /** syncolor.e:145		tokenize_reset(token)*/
    Ref(_token_72545);
    _71tokenize_reset(_token_72545);

    /** syncolor.e:146		eumem:ram_space[state] = default_state(token)*/
    Ref(_token_72545);
    _36220 = _71default_state(_token_72545);
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_13045 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_72544))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_state_72544)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _state_72544);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36220;
    if( _1 != _36220 ){
        DeRef(_1);
    }
    _36220 = NOVALUE;

    /** syncolor.e:147		eumem:ram_space[state] = default_state()*/
    _36221 = _71default_state(0LL);
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_13045 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_72544))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_state_72544)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _state_72544);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36221;
    if( _1 != _36221 ){
        DeRef(_1);
    }
    _36221 = NOVALUE;

    /** syncolor.e:148	end procedure*/
    DeRef(_state_72544);
    DeRef(_token_72545);
    return;
    ;
}



// 0xA73D59E9
