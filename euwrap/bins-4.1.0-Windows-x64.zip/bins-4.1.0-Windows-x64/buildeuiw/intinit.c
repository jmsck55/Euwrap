// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _68intoptions()
{
    object _pause_msg_65170 = NOVALUE;
    object _opts_array_65181 = NOVALUE;
    object _opts_65186 = NOVALUE;
    object _opt_keys_65195 = NOVALUE;
    object _option_w_65197 = NOVALUE;
    object _key_65201 = NOVALUE;
    object _val_65203 = NOVALUE;
    object _32132 = NOVALUE;
    object _32130 = NOVALUE;
    object _32129 = NOVALUE;
    object _32128 = NOVALUE;
    object _32127 = NOVALUE;
    object _32126 = NOVALUE;
    object _32125 = NOVALUE;
    object _32124 = NOVALUE;
    object _32123 = NOVALUE;
    object _32122 = NOVALUE;
    object _32121 = NOVALUE;
    object _32116 = NOVALUE;
    object _32113 = NOVALUE;
    object _32111 = NOVALUE;
    object _0, _1, _2;
    

    /** intinit.e:43		sequence pause_msg = GetMsgText(MSG_PRESS_ANY_KEY_AND_WINDOW_WILL_CLOSE, 0)*/
    RefDS(_22218);
    _0 = _pause_msg_65170;
    _pause_msg_65170 = _30GetMsgText(278LL, 0LL, _22218);
    DeRef(_0);

    /** intinit.e:45		Argv = expand_config_options(Argv)*/
    RefDS(_27Argv_20582);
    _0 = _47expand_config_options(_27Argv_20582);
    DeRefDS(_27Argv_20582);
    _27Argv_20582 = _0;

    /** intinit.e:46		Argc = length(Argv)*/
    if (IS_SEQUENCE(_27Argv_20582)){
            _27Argc_20581 = SEQ_PTR(_27Argv_20582)->length;
    }
    else {
        _27Argc_20581 = 1;
    }

    /** intinit.e:48		sequence opts_array = sort( get_options() )*/
    _32111 = _47get_options();
    _0 = _opts_array_65181;
    _opts_array_65181 = _25sort(_32111, 1LL);
    DeRef(_0);
    _32111 = NOVALUE;

    /** intinit.e:50		m:map opts = cmd_parse( opts_array, */
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 10LL;
    ((intptr_t*)_2)[2] = 4LL;
    ((intptr_t*)_2)[3] = 8LL;
    RefDS(_pause_msg_65170);
    ((intptr_t*)_2)[4] = _pause_msg_65170;
    _32113 = MAKE_SEQ(_1);
    RefDS(_opts_array_65181);
    RefDS(_27Argv_20582);
    _0 = _opts_65186;
    _opts_65186 = _48cmd_parse(_opts_array_65181, _32113, _27Argv_20582);
    DeRef(_0);
    _32113 = NOVALUE;

    /** intinit.e:53		handle_common_options(opts)*/
    Ref(_opts_65186);
    _47handle_common_options(_opts_65186);

    /** intinit.e:55		sequence opt_keys = map:keys(opts)*/
    Ref(_opts_65186);
    _0 = _opt_keys_65195;
    _opt_keys_65195 = _34keys(_opts_65186, 0LL);
    DeRef(_0);

    /** intinit.e:56		integer option_w = 0*/
    _option_w_65197 = 0LL;

    /** intinit.e:58		for idx = 1 to length(opt_keys) do*/
    if (IS_SEQUENCE(_opt_keys_65195)){
            _32116 = SEQ_PTR(_opt_keys_65195)->length;
    }
    else {
        _32116 = 1;
    }
    {
        object _idx_65199;
        _idx_65199 = 1LL;
L1: 
        if (_idx_65199 > _32116){
            goto L2; // [91] 206
        }

        /** intinit.e:59			sequence key = opt_keys[idx]*/
        DeRef(_key_65201);
        _2 = (object)SEQ_PTR(_opt_keys_65195);
        _key_65201 = (object)*(((s1_ptr)_2)->base + _idx_65199);
        Ref(_key_65201);

        /** intinit.e:60			object val = map:get(opts, key)*/
        Ref(_opts_65186);
        RefDS(_key_65201);
        _0 = _val_65203;
        _val_65203 = _34get(_opts_65186, _key_65201, 0LL);
        DeRef(_0);

        /** intinit.e:62			switch key do*/
        _1 = find(_key_65201, _32119);
        switch ( _1 ){ 

            /** intinit.e:63				case "coverage" then*/
            case 1:

            /** intinit.e:64					for i = 1 to length( val ) do*/
            if (IS_SEQUENCE(_val_65203)){
                    _32121 = SEQ_PTR(_val_65203)->length;
            }
            else {
                _32121 = 1;
            }
            {
                object _i_65209;
                _i_65209 = 1LL;
L3: 
                if (_i_65209 > _32121){
                    goto L4; // [130] 153
                }

                /** intinit.e:65						add_coverage( val[i] )*/
                _2 = (object)SEQ_PTR(_val_65203);
                _32122 = (object)*(((s1_ptr)_2)->base + _i_65209);
                Ref(_32122);
                _50add_coverage(_32122);
                _32122 = NOVALUE;

                /** intinit.e:66					end for*/
                _i_65209 = _i_65209 + 1LL;
                goto L3; // [148] 137
L4: 
                ;
            }
            goto L5; // [153] 197

            /** intinit.e:68				case "coverage-db" then*/
            case 2:

            /** intinit.e:69					coverage_db( val )*/
            Ref(_val_65203);
            _50coverage_db(_val_65203);
            goto L5; // [164] 197

            /** intinit.e:71				case "coverage-erase" then*/
            case 3:

            /** intinit.e:72					new_coverage_db()*/
            _50new_coverage_db();
            goto L5; // [174] 197

            /** intinit.e:74				case "coverage-exclude" then*/
            case 4:

            /** intinit.e:75					coverage_exclude( val )*/
            Ref(_val_65203);
            _50coverage_exclude(_val_65203);
            goto L5; // [185] 197

            /** intinit.e:77				case "debugger" then*/
            case 5:

            /** intinit.e:78					external_debugger = val*/
            Ref(_val_65203);
            DeRef(_68external_debugger_65167);
            _68external_debugger_65167 = _val_65203;
        ;}L5: 
        DeRef(_key_65201);
        _key_65201 = NOVALUE;
        DeRef(_val_65203);
        _val_65203 = NOVALUE;

        /** intinit.e:81		end for*/
        _idx_65199 = _idx_65199 + 1LL;
        goto L1; // [201] 98
L2: 
        ;
    }

    /** intinit.e:83		if length(m:get(opts, cmdline:EXTRAS)) = 0 and not repl then*/
    Ref(_opts_65186);
    RefDS(_48EXTRAS_20984);
    _32123 = _34get(_opts_65186, _48EXTRAS_20984, 0LL);
    if (IS_SEQUENCE(_32123)){
            _32124 = SEQ_PTR(_32123)->length;
    }
    else {
        _32124 = 1;
    }
    DeRef(_32123);
    _32123 = NOVALUE;
    _32125 = (_32124 == 0LL);
    _32124 = NOVALUE;
    if (_32125 == 0) {
        goto L6; // [223] 282
    }
    _32127 = (0LL == 0);
    if (_32127 == 0)
    {
        DeRef(_32127);
        _32127 = NOVALUE;
        goto L6; // [233] 282
    }
    else{
        DeRef(_32127);
        _32127 = NOVALUE;
    }

    /** intinit.e:84			show_banner()*/
    _47show_banner();

    /** intinit.e:85			ShowMsg(2, ERROR_MUST_SPECIFY_THE_FILE_TO_BE_INTERPRETED_ON_THE_COMMAND_LINE)*/
    RefDS(_22218);
    _30ShowMsg(2LL, 249LL, _22218, 1LL);

    /** intinit.e:87			if not batch_job and not test_only then*/
    _32128 = (_27batch_job_20584 == 0);
    if (_32128 == 0) {
        goto L7; // [257] 277
    }
    _32130 = (_27test_only_20583 == 0);
    if (_32130 == 0)
    {
        DeRef(_32130);
        _32130 = NOVALUE;
        goto L7; // [267] 277
    }
    else{
        DeRef(_32130);
        _32130 = NOVALUE;
    }

    /** intinit.e:88				maybe_any_key(pause_msg)*/
    RefDS(_pause_msg_65170);
    _38maybe_any_key(_pause_msg_65170, 1LL);
L7: 

    /** intinit.e:91			abort(1)*/
    UserCleanup(1LL);
L6: 

    /** intinit.e:94		OpDefines &= { "EUI" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_32131);
    ((intptr_t*)_2)[1] = _32131;
    _32132 = MAKE_SEQ(_1);
    Concat((object_ptr)&_27OpDefines_20645, _27OpDefines_20645, _32132);
    DeRefDS(_32132);
    _32132 = NOVALUE;

    /** intinit.e:96		finalize_command_line(opts)*/
    Ref(_opts_65186);
    _47finalize_command_line(_opts_65186);

    /** intinit.e:97	end procedure*/
    DeRef(_pause_msg_65170);
    DeRef(_opts_array_65181);
    DeRef(_opts_65186);
    DeRef(_opt_keys_65195);
    _32123 = NOVALUE;
    DeRef(_32128);
    _32128 = NOVALUE;
    DeRef(_32125);
    _32125 = NOVALUE;
    return;
    ;
}



// 0x8A9494E5
