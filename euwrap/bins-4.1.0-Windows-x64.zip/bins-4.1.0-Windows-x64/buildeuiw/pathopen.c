// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _46convert_from_OEM(object _s_50802)
{
    object _ls_50803 = NOVALUE;
    object _rc_50804 = NOVALUE;
    object _26103 = NOVALUE;
    object _26102 = NOVALUE;
    object _26100 = NOVALUE;
    object _26099 = NOVALUE;
    object _26096 = NOVALUE;
    object _26095 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:37		ls=length(s)*/
    if (IS_SEQUENCE(_s_50802)){
            _ls_50803 = SEQ_PTR(_s_50802)->length;
    }
    else {
        _ls_50803 = 1;
    }

    /** pathopen.e:38		if ls>convert_length then*/
    if (_ls_50803 <= _46convert_length_50780)
    goto L1; // [12] 47

    /** pathopen.e:39			free(convert_buffer)*/
    Ref(_46convert_buffer_50779);
    _6free(_46convert_buffer_50779);

    /** pathopen.e:40			convert_length=and_bits(ls+15,-16)+1*/
    _26095 = _ls_50803 + 15LL;
    {uintptr_t tu;
         tu = (uintptr_t)_26095 & (uintptr_t)-16LL;
         _26096 = MAKE_UINT(tu);
    }
    _26095 = NOVALUE;
    if (IS_ATOM_INT(_26096)) {
        _46convert_length_50780 = _26096 + 1;
    }
    else
    { // coercing _46convert_length_50780 to an integer 1
        _46convert_length_50780 = 1+(object)(DBL_PTR(_26096)->dbl);
        if( !IS_ATOM_INT(_46convert_length_50780) ){
            _46convert_length_50780 = (object)DBL_PTR(_46convert_length_50780)->dbl;
        }
    }
    DeRef(_26096);
    _26096 = NOVALUE;

    /** pathopen.e:41			convert_buffer=allocate(convert_length)*/
    _0 = _6allocate(_46convert_length_50780, 0LL);
    DeRef(_46convert_buffer_50779);
    _46convert_buffer_50779 = _0;
L1: 

    /** pathopen.e:43		poke(convert_buffer,s)*/
    if (IS_ATOM_INT(_46convert_buffer_50779)){
        poke_addr = (uint8_t *)_46convert_buffer_50779;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_46convert_buffer_50779)->dbl);
    }
    _1 = (object)SEQ_PTR(_s_50802);
    _1 = (object)((s1_ptr)_1)->base;
    while (1) {
        _1 += sizeof(object);
        _2 = *((object *)_1);
        if (IS_ATOM_INT(_2)) {
            *poke_addr++ = (uint8_t)_2;
        }
        else if (_2 == NOVALUE) {
            break;
        }
        else {
            *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
        }
    }

    /** pathopen.e:44		poke(convert_buffer+ls,0)*/
    if (IS_ATOM_INT(_46convert_buffer_50779)) {
        _26099 = _46convert_buffer_50779 + _ls_50803;
        if ((object)((uintptr_t)_26099 + (uintptr_t)HIGH_BITS) >= 0){
            _26099 = NewDouble((eudouble)_26099);
        }
    }
    else {
        _26099 = NewDouble(DBL_PTR(_46convert_buffer_50779)->dbl + (eudouble)_ls_50803);
    }
    if (IS_ATOM_INT(_26099)){
        poke_addr = (uint8_t *)_26099;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_26099)->dbl);
    }
    *poke_addr = (uint8_t)0LL;
    DeRef(_26099);
    _26099 = NOVALUE;

    /** pathopen.e:45		rc=c_func(oem2char,{convert_buffer,convert_buffer}) -- always nonzero*/
    Ref(_46convert_buffer_50779);
    Ref(_46convert_buffer_50779);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _46convert_buffer_50779;
    ((intptr_t *)_2)[2] = _46convert_buffer_50779;
    _26100 = MAKE_SEQ(_1);
    _rc_50804 = call_c(1, _46oem2char_50778, _26100);
    DeRefDS(_26100);
    _26100 = NOVALUE;
    if (!IS_ATOM_INT(_rc_50804)) {
        _1 = (object)(DBL_PTR(_rc_50804)->dbl);
        DeRefDS(_rc_50804);
        _rc_50804 = _1;
    }

    /** pathopen.e:46		return peek({convert_buffer,ls}) */
    Ref(_46convert_buffer_50779);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _46convert_buffer_50779;
    ((intptr_t *)_2)[2] = _ls_50803;
    _26102 = MAKE_SEQ(_1);
    _1 = (object)SEQ_PTR(_26102);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _26103 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    DeRefDS(_26102);
    _26102 = NOVALUE;
    DeRefDS(_s_50802);
    return _26103;
    ;
}


object _46exe_path()
{
    object _26107 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:70		if sequence(exe_path_cache) then*/
    _26107 = IS_SEQUENCE(_46exe_path_cache_50834);
    if (_26107 == 0)
    {
        _26107 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _26107 = NOVALUE;
    }

    /** pathopen.e:71			return exe_path_cache*/
    Ref(_46exe_path_cache_50834);
    return _46exe_path_cache_50834;
L1: 

    /** pathopen.e:74		exe_path_cache = command_line()*/
    DeRef(_46exe_path_cache_50834);
    _46exe_path_cache_50834 = Command_Line();

    /** pathopen.e:75		exe_path_cache = exe_path_cache[1]*/
    _0 = _46exe_path_cache_50834;
    _2 = (object)SEQ_PTR(_46exe_path_cache_50834);
    _46exe_path_cache_50834 = (object)*(((s1_ptr)_2)->base + 1LL);
    RefDS(_46exe_path_cache_50834);
    DeRefDS(_0);

    /** pathopen.e:77		return exe_path_cache*/
    RefDS(_46exe_path_cache_50834);
    return _46exe_path_cache_50834;
    ;
}


object _46check_cache(object _env_50846, object _inc_path_50847)
{
    object _delim_50848 = NOVALUE;
    object _pos_50849 = NOVALUE;
    object _26158 = NOVALUE;
    object _26157 = NOVALUE;
    object _26156 = NOVALUE;
    object _26155 = NOVALUE;
    object _26153 = NOVALUE;
    object _26152 = NOVALUE;
    object _26151 = NOVALUE;
    object _26150 = NOVALUE;
    object _26149 = NOVALUE;
    object _26148 = NOVALUE;
    object _26147 = NOVALUE;
    object _26146 = NOVALUE;
    object _26145 = NOVALUE;
    object _26144 = NOVALUE;
    object _26143 = NOVALUE;
    object _26139 = NOVALUE;
    object _26138 = NOVALUE;
    object _26137 = NOVALUE;
    object _26136 = NOVALUE;
    object _26135 = NOVALUE;
    object _26134 = NOVALUE;
    object _26133 = NOVALUE;
    object _26132 = NOVALUE;
    object _26130 = NOVALUE;
    object _26129 = NOVALUE;
    object _26128 = NOVALUE;
    object _26127 = NOVALUE;
    object _26126 = NOVALUE;
    object _26125 = NOVALUE;
    object _26123 = NOVALUE;
    object _26122 = NOVALUE;
    object _26121 = NOVALUE;
    object _26120 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:83		if not num_var then -- first time the var is accessed, add cache entry*/
    if (_46num_var_50823 != 0)
    goto L1; // [9] 94

    /** pathopen.e:84			cache_vars = append(cache_vars,env)*/
    RefDS(_env_50846);
    Append(&_46cache_vars_50824, _46cache_vars_50824, _env_50846);

    /** pathopen.e:85			cache_strings = append(cache_strings,inc_path)*/
    RefDS(_inc_path_50847);
    Append(&_46cache_strings_50825, _46cache_strings_50825, _inc_path_50847);

    /** pathopen.e:86			cache_substrings = append(cache_substrings,{})*/
    RefDS(_22218);
    Append(&_46cache_substrings_50826, _46cache_substrings_50826, _22218);

    /** pathopen.e:87			cache_starts = append(cache_starts,{})*/
    RefDS(_22218);
    Append(&_46cache_starts_50827, _46cache_starts_50827, _22218);

    /** pathopen.e:88			cache_ends = append(cache_ends,{})*/
    RefDS(_22218);
    Append(&_46cache_ends_50828, _46cache_ends_50828, _22218);

    /** pathopen.e:89			ifdef WINDOWS then*/

    /** pathopen.e:90				cache_converted = append(cache_converted,{})*/
    RefDS(_22218);
    Append(&_46cache_converted_50829, _46cache_converted_50829, _22218);

    /** pathopen.e:92			num_var = length(cache_vars)*/
    if (IS_SEQUENCE(_46cache_vars_50824)){
            _46num_var_50823 = SEQ_PTR(_46cache_vars_50824)->length;
    }
    else {
        _46num_var_50823 = 1;
    }

    /** pathopen.e:93			cache_complete &= 0*/
    Append(&_46cache_complete_50830, _46cache_complete_50830, 0LL);

    /** pathopen.e:94			cache_delims &= 0*/
    Append(&_46cache_delims_50831, _46cache_delims_50831, 0LL);

    /** pathopen.e:95			return 0*/
    DeRefDSi(_env_50846);
    DeRefDSi(_inc_path_50847);
    return 0LL;
    goto L2; // [91] 456
L1: 

    /** pathopen.e:97			if compare(inc_path,cache_strings[num_var]) then*/
    _2 = (object)SEQ_PTR(_46cache_strings_50825);
    _26120 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
    if (IS_ATOM_INT(_inc_path_50847) && IS_ATOM_INT(_26120)){
        _26121 = (_inc_path_50847 < _26120) ? -1 : (_inc_path_50847 > _26120);
    }
    else{
        _26121 = compare(_inc_path_50847, _26120);
    }
    _26120 = NOVALUE;
    if (_26121 == 0)
    {
        _26121 = NOVALUE;
        goto L3; // [108] 455
    }
    else{
        _26121 = NOVALUE;
    }

    /** pathopen.e:98				cache_strings[num_var] = inc_path*/
    RefDS(_inc_path_50847);
    _2 = (object)SEQ_PTR(_46cache_strings_50825);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _46cache_strings_50825 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _46num_var_50823);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _inc_path_50847;
    DeRefDS(_1);

    /** pathopen.e:99				cache_complete[num_var] = 0*/
    _2 = (object)SEQ_PTR(_46cache_complete_50830);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _46cache_complete_50830 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _46num_var_50823);
    *(intptr_t *)_2 = 0LL;

    /** pathopen.e:100				if match(cache_strings[num_var],inc_path)!=1 then -- try to salvage what we can*/
    _2 = (object)SEQ_PTR(_46cache_strings_50825);
    _26122 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
    _26123 = e_match_from(_26122, _inc_path_50847, 1LL);
    _26122 = NOVALUE;
    if (_26123 == 1LL)
    goto L4; // [146] 454

    /** pathopen.e:101					pos = -1*/
    _pos_50849 = -1LL;

    /** pathopen.e:102					for i=1 to length(cache_strings[num_var]) do*/
    _2 = (object)SEQ_PTR(_46cache_strings_50825);
    _26125 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
    if (IS_SEQUENCE(_26125)){
            _26126 = SEQ_PTR(_26125)->length;
    }
    else {
        _26126 = 1;
    }
    _26125 = NOVALUE;
    {
        object _i_50870;
        _i_50870 = 1LL;
L5: 
        if (_i_50870 > _26126){
            goto L6; // [168] 453
        }

        /** pathopen.e:103						if cache_ends[num_var][i] > length(inc_path) or */
        _2 = (object)SEQ_PTR(_46cache_ends_50828);
        _26127 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
        _2 = (object)SEQ_PTR(_26127);
        _26128 = (object)*(((s1_ptr)_2)->base + _i_50870);
        _26127 = NOVALUE;
        if (IS_SEQUENCE(_inc_path_50847)){
                _26129 = SEQ_PTR(_inc_path_50847)->length;
        }
        else {
            _26129 = 1;
        }
        if (IS_ATOM_INT(_26128)) {
            _26130 = (_26128 > _26129);
        }
        else {
            _26130 = binary_op(GREATER, _26128, _26129);
        }
        _26128 = NOVALUE;
        _26129 = NOVALUE;
        if (IS_ATOM_INT(_26130)) {
            if (_26130 != 0) {
                goto L7; // [196] 250
            }
        }
        else {
            if (DBL_PTR(_26130)->dbl != 0.0) {
                goto L7; // [196] 250
            }
        }
        _2 = (object)SEQ_PTR(_46cache_substrings_50826);
        _26132 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
        _2 = (object)SEQ_PTR(_26132);
        _26133 = (object)*(((s1_ptr)_2)->base + _i_50870);
        _26132 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_starts_50827);
        _26134 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
        _2 = (object)SEQ_PTR(_26134);
        _26135 = (object)*(((s1_ptr)_2)->base + _i_50870);
        _26134 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_ends_50828);
        _26136 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
        _2 = (object)SEQ_PTR(_26136);
        _26137 = (object)*(((s1_ptr)_2)->base + _i_50870);
        _26136 = NOVALUE;
        rhs_slice_target = (object_ptr)&_26138;
        RHS_Slice(_inc_path_50847, _26135, _26137);
        if (IS_ATOM_INT(_26133) && IS_ATOM_INT(_26138)){
            _26139 = (_26133 < _26138) ? -1 : (_26133 > _26138);
        }
        else{
            _26139 = compare(_26133, _26138);
        }
        _26133 = NOVALUE;
        DeRefDS(_26138);
        _26138 = NOVALUE;
        if (_26139 == 0)
        {
            _26139 = NOVALUE;
            goto L8; // [246] 261
        }
        else{
            _26139 = NOVALUE;
        }
L7: 

        /** pathopen.e:107							pos = i-1*/
        _pos_50849 = _i_50870 - 1LL;

        /** pathopen.e:108							exit*/
        goto L6; // [258] 453
L8: 

        /** pathopen.e:110						if pos = 0 then*/
        if (_pos_50849 != 0LL)
        goto L9; // [263] 276

        /** pathopen.e:111							return 0*/
        DeRefDSi(_env_50846);
        DeRefDSi(_inc_path_50847);
        _26135 = NOVALUE;
        DeRef(_26130);
        _26130 = NOVALUE;
        _26137 = NOVALUE;
        _26125 = NOVALUE;
        return 0LL;
        goto LA; // [273] 446
L9: 

        /** pathopen.e:112						elsif pos >0 then -- crop cache data*/
        if (_pos_50849 <= 0LL)
        goto LB; // [278] 445

        /** pathopen.e:113							cache_substrings[num_var] = cache_substrings[num_var][1..pos]*/
        _2 = (object)SEQ_PTR(_46cache_substrings_50826);
        _26143 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
        rhs_slice_target = (object_ptr)&_26144;
        RHS_Slice(_26143, 1LL, _pos_50849);
        _26143 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_substrings_50826);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_substrings_50826 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50823);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26144;
        if( _1 != _26144 ){
            DeRefDS(_1);
        }
        _26144 = NOVALUE;

        /** pathopen.e:114							cache_starts[num_var] = cache_starts[num_var][1..pos]*/
        _2 = (object)SEQ_PTR(_46cache_starts_50827);
        _26145 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
        rhs_slice_target = (object_ptr)&_26146;
        RHS_Slice(_26145, 1LL, _pos_50849);
        _26145 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_starts_50827);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_starts_50827 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50823);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26146;
        if( _1 != _26146 ){
            DeRef(_1);
        }
        _26146 = NOVALUE;

        /** pathopen.e:115							cache_ends[num_var] = cache_ends[num_var][1..pos]*/
        _2 = (object)SEQ_PTR(_46cache_ends_50828);
        _26147 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
        rhs_slice_target = (object_ptr)&_26148;
        RHS_Slice(_26147, 1LL, _pos_50849);
        _26147 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_ends_50828);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_ends_50828 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50823);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26148;
        if( _1 != _26148 ){
            DeRef(_1);
        }
        _26148 = NOVALUE;

        /** pathopen.e:116							ifdef WINDOWS then*/

        /** pathopen.e:117								cache_converted[num_var] = cache_converted[num_var][1..pos]*/
        _2 = (object)SEQ_PTR(_46cache_converted_50829);
        _26149 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
        rhs_slice_target = (object_ptr)&_26150;
        RHS_Slice(_26149, 1LL, _pos_50849);
        _26149 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_converted_50829);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_converted_50829 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50823);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26150;
        if( _1 != _26150 ){
            DeRef(_1);
        }
        _26150 = NOVALUE;

        /** pathopen.e:119							delim = cache_ends[num_var][$]+1*/
        _2 = (object)SEQ_PTR(_46cache_ends_50828);
        _26151 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
        if (IS_SEQUENCE(_26151)){
                _26152 = SEQ_PTR(_26151)->length;
        }
        else {
            _26152 = 1;
        }
        _2 = (object)SEQ_PTR(_26151);
        _26153 = (object)*(((s1_ptr)_2)->base + _26152);
        _26151 = NOVALUE;
        if (IS_ATOM_INT(_26153)) {
            _delim_50848 = _26153 + 1;
        }
        else
        { // coercing _delim_50848 to an integer 1
            _delim_50848 = 1+(object)(DBL_PTR(_26153)->dbl);
            if( !IS_ATOM_INT(_delim_50848) ){
                _delim_50848 = (object)DBL_PTR(_delim_50848)->dbl;
            }
        }
        _26153 = NOVALUE;

        /** pathopen.e:120							while delim <= length(inc_path) and delim != PATH_SEPARATOR do*/
LC: 
        if (IS_SEQUENCE(_inc_path_50847)){
                _26155 = SEQ_PTR(_inc_path_50847)->length;
        }
        else {
            _26155 = 1;
        }
        _26156 = (_delim_50848 <= _26155);
        _26155 = NOVALUE;
        if (_26156 == 0) {
            goto LD; // [409] 434
        }
        _26158 = (_delim_50848 != 59LL);
        if (_26158 == 0)
        {
            DeRef(_26158);
            _26158 = NOVALUE;
            goto LD; // [420] 434
        }
        else{
            DeRef(_26158);
            _26158 = NOVALUE;
        }

        /** pathopen.e:121								delim+=1*/
        _delim_50848 = _delim_50848 + 1;

        /** pathopen.e:122							end while*/
        goto LC; // [431] 402
LD: 

        /** pathopen.e:123							cache_delims[num_var] = delim*/
        _2 = (object)SEQ_PTR(_46cache_delims_50831);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_delims_50831 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50823);
        *(intptr_t *)_2 = _delim_50848;
LB: 
LA: 

        /** pathopen.e:125					end for*/
        _i_50870 = _i_50870 + 1LL;
        goto L5; // [448] 175
L6: 
        ;
    }
L4: 
L3: 
L2: 

    /** pathopen.e:129		return 1*/
    DeRefDSi(_env_50846);
    DeRefDSi(_inc_path_50847);
    _26135 = NOVALUE;
    DeRef(_26156);
    _26156 = NOVALUE;
    DeRef(_26130);
    _26130 = NOVALUE;
    _26137 = NOVALUE;
    _26125 = NOVALUE;
    return 1LL;
    ;
}


object _46get_conf_dirs()
{
    object _delimiter_50913 = NOVALUE;
    object _dirs_50914 = NOVALUE;
    object _26164 = NOVALUE;
    object _26162 = NOVALUE;
    object _26161 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:136		ifdef UNIX then*/

    /** pathopen.e:139			delimiter = ';'*/
    _delimiter_50913 = 59LL;

    /** pathopen.e:142		dirs = ""*/
    RefDS(_22218);
    DeRef(_dirs_50914);
    _dirs_50914 = _22218;

    /** pathopen.e:143		for i = 1 to length(config_inc_paths) do*/
    if (IS_SEQUENCE(_46config_inc_paths_50832)){
            _26161 = SEQ_PTR(_46config_inc_paths_50832)->length;
    }
    else {
        _26161 = 1;
    }
    {
        object _i_50917;
        _i_50917 = 1LL;
L1: 
        if (_i_50917 > _26161){
            goto L2; // [22] 68
        }

        /** pathopen.e:144			dirs &= config_inc_paths[i]*/
        _2 = (object)SEQ_PTR(_46config_inc_paths_50832);
        _26162 = (object)*(((s1_ptr)_2)->base + _i_50917);
        Concat((object_ptr)&_dirs_50914, _dirs_50914, _26162);
        _26162 = NOVALUE;

        /** pathopen.e:145			if i != length(config_inc_paths) then*/
        if (IS_SEQUENCE(_46config_inc_paths_50832)){
                _26164 = SEQ_PTR(_46config_inc_paths_50832)->length;
        }
        else {
            _26164 = 1;
        }
        if (_i_50917 == _26164)
        goto L3; // [48] 61

        /** pathopen.e:146				dirs &= delimiter*/
        Append(&_dirs_50914, _dirs_50914, _delimiter_50913);
L3: 

        /** pathopen.e:148		end for*/
        _i_50917 = _i_50917 + 1LL;
        goto L1; // [63] 29
L2: 
        ;
    }

    /** pathopen.e:150		return dirs*/
    return _dirs_50914;
    ;
}


object _46strip_file_from_path(object _full_path_50927)
{
    object _26170 = NOVALUE;
    object _26168 = NOVALUE;
    object _26167 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:156		for i = length(full_path) to 1 by -1 do*/
    if (IS_SEQUENCE(_full_path_50927)){
            _26167 = SEQ_PTR(_full_path_50927)->length;
    }
    else {
        _26167 = 1;
    }
    {
        object _i_50929;
        _i_50929 = _26167;
L1: 
        if (_i_50929 < 1LL){
            goto L2; // [8] 46
        }

        /** pathopen.e:157			if full_path[i] = SLASH then*/
        _2 = (object)SEQ_PTR(_full_path_50927);
        _26168 = (object)*(((s1_ptr)_2)->base + _i_50929);
        if (binary_op_a(NOTEQ, _26168, 92LL)){
            _26168 = NOVALUE;
            goto L3; // [23] 39
        }
        _26168 = NOVALUE;

        /** pathopen.e:158				return full_path[1..i]*/
        rhs_slice_target = (object_ptr)&_26170;
        RHS_Slice(_full_path_50927, 1LL, _i_50929);
        DeRefDS(_full_path_50927);
        return _26170;
L3: 

        /** pathopen.e:160		end for*/
        _i_50929 = _i_50929 + -1LL;
        goto L1; // [41] 15
L2: 
        ;
    }

    /** pathopen.e:162		return ""*/
    RefDS(_22218);
    DeRefDS(_full_path_50927);
    DeRef(_26170);
    _26170 = NOVALUE;
    return _22218;
    ;
}


object _46expand_path(object _path_50938, object _prefix_50939)
{
    object _absolute_50940 = NOVALUE;
    object _26186 = NOVALUE;
    object _26185 = NOVALUE;
    object _26184 = NOVALUE;
    object _26183 = NOVALUE;
    object _26182 = NOVALUE;
    object _26181 = NOVALUE;
    object _26177 = NOVALUE;
    object _26176 = NOVALUE;
    object _26175 = NOVALUE;
    object _26171 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:169		if not length(path) then*/
    if (IS_SEQUENCE(_path_50938)){
            _26171 = SEQ_PTR(_path_50938)->length;
    }
    else {
        _26171 = 1;
    }
    if (_26171 != 0)
    goto L1; // [10] 22
    _26171 = NOVALUE;

    /** pathopen.e:170			return pwd*/
    RefDS(_46pwd_50835);
    DeRefDS(_path_50938);
    DeRefDS(_prefix_50939);
    return _46pwd_50835;
L1: 

    /** pathopen.e:174		ifdef UNIX then*/

    /** pathopen.e:185			absolute = find(path[1], SLASH_CHARS) or find(':', path)*/
    _2 = (object)SEQ_PTR(_path_50938);
    _26175 = (object)*(((s1_ptr)_2)->base + 1LL);
    _26176 = find_from(_26175, _44SLASH_CHARS_20736, 1LL);
    _26175 = NOVALUE;
    _26177 = find_from(58LL, _path_50938, 1LL);
    _absolute_50940 = (_26176 != 0 || _26177 != 0);
    _26176 = NOVALUE;
    _26177 = NOVALUE;

    /** pathopen.e:188		if not absolute then*/
    if (_absolute_50940 != 0)
    goto L2; // [50] 64

    /** pathopen.e:189			path = prefix & SLASH & path*/
    {
        object concat_list[3];

        concat_list[0] = _path_50938;
        concat_list[1] = 92LL;
        concat_list[2] = _prefix_50939;
        Concat_N((object_ptr)&_path_50938, concat_list, 3);
    }
L2: 

    /** pathopen.e:192		if length(path) and not find(path[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_path_50938)){
            _26181 = SEQ_PTR(_path_50938)->length;
    }
    else {
        _26181 = 1;
    }
    if (_26181 == 0) {
        goto L3; // [69] 103
    }
    if (IS_SEQUENCE(_path_50938)){
            _26183 = SEQ_PTR(_path_50938)->length;
    }
    else {
        _26183 = 1;
    }
    _2 = (object)SEQ_PTR(_path_50938);
    _26184 = (object)*(((s1_ptr)_2)->base + _26183);
    _26185 = find_from(_26184, _44SLASH_CHARS_20736, 1LL);
    _26184 = NOVALUE;
    _26186 = (_26185 == 0);
    _26185 = NOVALUE;
    if (_26186 == 0)
    {
        DeRef(_26186);
        _26186 = NOVALUE;
        goto L3; // [91] 103
    }
    else{
        DeRef(_26186);
        _26186 = NOVALUE;
    }

    /** pathopen.e:193			path &= SLASH*/
    Append(&_path_50938, _path_50938, 92LL);
L3: 

    /** pathopen.e:196		return path*/
    DeRefDS(_prefix_50939);
    return _path_50938;
    ;
}


void _46add_include_directory(object _path_50967)
{
    object _26189 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:200		path = expand_path( path, pwd )*/
    RefDS(_path_50967);
    RefDS(_46pwd_50835);
    _0 = _path_50967;
    _path_50967 = _46expand_path(_path_50967, _46pwd_50835);
    DeRefDS(_0);

    /** pathopen.e:202		if not find( path, config_inc_paths ) then*/
    _26189 = find_from(_path_50967, _46config_inc_paths_50832, 1LL);
    if (_26189 != 0)
    goto L1; // [23] 35
    _26189 = NOVALUE;

    /** pathopen.e:203			config_inc_paths = append( config_inc_paths, path )*/
    RefDS(_path_50967);
    Append(&_46config_inc_paths_50832, _46config_inc_paths_50832, _path_50967);
L1: 

    /** pathopen.e:205	end procedure*/
    DeRefDS(_path_50967);
    return;
    ;
}


object _46load_euphoria_config(object _file_50976)
{
    object _fn_50977 = NOVALUE;
    object _in_50978 = NOVALUE;
    object _spos_50979 = NOVALUE;
    object _epos_50980 = NOVALUE;
    object _conf_path_50981 = NOVALUE;
    object _new_args_50982 = NOVALUE;
    object _arg_50983 = NOVALUE;
    object _parm_50984 = NOVALUE;
    object _section_50985 = NOVALUE;
    object _needed_51084 = NOVALUE;
    object _26288 = NOVALUE;
    object _26287 = NOVALUE;
    object _26284 = NOVALUE;
    object _26282 = NOVALUE;
    object _26281 = NOVALUE;
    object _26259 = NOVALUE;
    object _26256 = NOVALUE;
    object _26255 = NOVALUE;
    object _26253 = NOVALUE;
    object _26249 = NOVALUE;
    object _26247 = NOVALUE;
    object _26245 = NOVALUE;
    object _26243 = NOVALUE;
    object _26241 = NOVALUE;
    object _26239 = NOVALUE;
    object _26238 = NOVALUE;
    object _26237 = NOVALUE;
    object _26235 = NOVALUE;
    object _26234 = NOVALUE;
    object _26233 = NOVALUE;
    object _26232 = NOVALUE;
    object _26231 = NOVALUE;
    object _26229 = NOVALUE;
    object _26226 = NOVALUE;
    object _26224 = NOVALUE;
    object _26220 = NOVALUE;
    object _26219 = NOVALUE;
    object _26214 = NOVALUE;
    object _26212 = NOVALUE;
    object _26210 = NOVALUE;
    object _26209 = NOVALUE;
    object _26201 = NOVALUE;
    object _26195 = NOVALUE;
    object _26194 = NOVALUE;
    object _26192 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:213		sequence new_args = {}*/
    RefDS(_22218);
    DeRef(_new_args_50982);
    _new_args_50982 = _22218;

    /** pathopen.e:219		if file_type(file) = FILETYPE_DIRECTORY then*/
    RefDS(_file_50976);
    _26192 = _15file_type(_file_50976);
    if (binary_op_a(NOTEQ, _26192, 2LL)){
        DeRef(_26192);
        _26192 = NOVALUE;
        goto L1; // [18] 53
    }
    DeRef(_26192);
    _26192 = NOVALUE;

    /** pathopen.e:220			if file[$] != SLASH then*/
    if (IS_SEQUENCE(_file_50976)){
            _26194 = SEQ_PTR(_file_50976)->length;
    }
    else {
        _26194 = 1;
    }
    _2 = (object)SEQ_PTR(_file_50976);
    _26195 = (object)*(((s1_ptr)_2)->base + _26194);
    if (binary_op_a(EQUALS, _26195, 92LL)){
        _26195 = NOVALUE;
        goto L2; // [33] 46
    }
    _26195 = NOVALUE;

    /** pathopen.e:221				file &= SLASH*/
    Append(&_file_50976, _file_50976, 92LL);
L2: 

    /** pathopen.e:223			file &= "eu.cfg"*/
    Concat((object_ptr)&_file_50976, _file_50976, _26198);
L1: 

    /** pathopen.e:226		conf_path = canonical_path( file,,CORRECT )*/
    RefDS(_file_50976);
    _0 = _conf_path_50981;
    _conf_path_50981 = _15canonical_path(_file_50976, 0LL, 2LL);
    DeRef(_0);

    /** pathopen.e:229		if find(conf_path, seen_conf) != 0 then*/
    _26201 = find_from(_conf_path_50981, _46seen_conf_50973, 1LL);
    if (_26201 == 0LL)
    goto L3; // [74] 85

    /** pathopen.e:230			return {}*/
    RefDS(_22218);
    DeRefDS(_file_50976);
    DeRefi(_in_50978);
    DeRefDS(_conf_path_50981);
    DeRef(_new_args_50982);
    DeRefi(_arg_50983);
    DeRefi(_parm_50984);
    DeRef(_section_50985);
    return _22218;
L3: 

    /** pathopen.e:232		seen_conf = append(seen_conf, conf_path)*/
    RefDS(_conf_path_50981);
    Append(&_46seen_conf_50973, _46seen_conf_50973, _conf_path_50981);

    /** pathopen.e:234		section = "all"*/
    RefDS(_26204);
    DeRef(_section_50985);
    _section_50985 = _26204;

    /** pathopen.e:235		fn = open( conf_path, "r" )*/
    _fn_50977 = EOpen(_conf_path_50981, _26205, 0LL);

    /** pathopen.e:236		if fn = -1 then return {} end if*/
    if (_fn_50977 != -1LL)
    goto L4; // [109] 118
    RefDS(_22218);
    DeRefDS(_file_50976);
    DeRefi(_in_50978);
    DeRefDS(_conf_path_50981);
    DeRef(_new_args_50982);
    DeRefi(_arg_50983);
    DeRefi(_parm_50984);
    DeRefDSi(_section_50985);
    return _22218;
L4: 

    /** pathopen.e:238		in = gets( fn )*/
    DeRefi(_in_50978);
    _in_50978 = EGets(_fn_50977);

    /** pathopen.e:239		while sequence( in ) do*/
L5: 
    _26209 = IS_SEQUENCE(_in_50978);
    if (_26209 == 0)
    {
        _26209 = NOVALUE;
        goto L6; // [131] 768
    }
    else{
        _26209 = NOVALUE;
    }

    /** pathopen.e:241			spos = 1*/
    _spos_50979 = 1LL;

    /** pathopen.e:242			while spos <= length(in) do*/
L7: 
    if (IS_SEQUENCE(_in_50978)){
            _26210 = SEQ_PTR(_in_50978)->length;
    }
    else {
        _26210 = 1;
    }
    if (_spos_50979 > _26210)
    goto L8; // [147] 182

    /** pathopen.e:243				if find( in[spos], "\n\r \t" ) = 0 then*/
    _2 = (object)SEQ_PTR(_in_50978);
    _26212 = (object)*(((s1_ptr)_2)->base + _spos_50979);
    _26214 = find_from(_26212, _26213, 1LL);
    _26212 = NOVALUE;
    if (_26214 != 0LL)
    goto L9; // [162] 171

    /** pathopen.e:244					exit*/
    goto L8; // [168] 182
L9: 

    /** pathopen.e:246				spos += 1*/
    _spos_50979 = _spos_50979 + 1;

    /** pathopen.e:247			end while*/
    goto L7; // [179] 144
L8: 

    /** pathopen.e:249			epos = length(in)*/
    if (IS_SEQUENCE(_in_50978)){
            _epos_50980 = SEQ_PTR(_in_50978)->length;
    }
    else {
        _epos_50980 = 1;
    }

    /** pathopen.e:250			while epos >= spos do*/
LA: 
    if (_epos_50980 < _spos_50979)
    goto LB; // [192] 227

    /** pathopen.e:251				if find( in[epos], "\n\r \t" ) = 0 then*/
    _2 = (object)SEQ_PTR(_in_50978);
    _26219 = (object)*(((s1_ptr)_2)->base + _epos_50980);
    _26220 = find_from(_26219, _26213, 1LL);
    _26219 = NOVALUE;
    if (_26220 != 0LL)
    goto LC; // [207] 216

    /** pathopen.e:252					exit*/
    goto LB; // [213] 227
LC: 

    /** pathopen.e:254				epos -= 1*/
    _epos_50980 = _epos_50980 - 1LL;

    /** pathopen.e:255			end while*/
    goto LA; // [224] 192
LB: 

    /** pathopen.e:257			in = in[spos .. epos]		*/
    rhs_slice_target = (object_ptr)&_in_50978;
    RHS_Slice(_in_50978, _spos_50979, _epos_50980);

    /** pathopen.e:260			arg = ""*/
    RefDS(_22218);
    DeRefi(_arg_50983);
    _arg_50983 = _22218;

    /** pathopen.e:261			parm = ""*/
    RefDS(_22218);
    DeRefi(_parm_50984);
    _parm_50984 = _22218;

    /** pathopen.e:269			if length(in) > 0 then*/
    if (IS_SEQUENCE(_in_50978)){
            _26224 = SEQ_PTR(_in_50978)->length;
    }
    else {
        _26224 = 1;
    }
    if (_26224 <= 0LL)
    goto LD; // [253] 477

    /** pathopen.e:270				if in[1] = '[' then*/
    _2 = (object)SEQ_PTR(_in_50978);
    _26226 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (_26226 != 91LL)
    goto LE; // [263] 354

    /** pathopen.e:272					section = in[2..$]*/
    if (IS_SEQUENCE(_in_50978)){
            _26229 = SEQ_PTR(_in_50978)->length;
    }
    else {
        _26229 = 1;
    }
    rhs_slice_target = (object_ptr)&_section_50985;
    RHS_Slice(_in_50978, 2LL, _26229);

    /** pathopen.e:273					if length(section) > 0 and section[$] = ']' then*/
    if (IS_SEQUENCE(_section_50985)){
            _26231 = SEQ_PTR(_section_50985)->length;
    }
    else {
        _26231 = 1;
    }
    _26232 = (_26231 > 0LL);
    _26231 = NOVALUE;
    if (_26232 == 0) {
        goto LF; // [286] 320
    }
    if (IS_SEQUENCE(_section_50985)){
            _26234 = SEQ_PTR(_section_50985)->length;
    }
    else {
        _26234 = 1;
    }
    _2 = (object)SEQ_PTR(_section_50985);
    _26235 = (object)*(((s1_ptr)_2)->base + _26234);
    _26237 = (_26235 == 93LL);
    _26235 = NOVALUE;
    if (_26237 == 0)
    {
        DeRef(_26237);
        _26237 = NOVALUE;
        goto LF; // [302] 320
    }
    else{
        DeRef(_26237);
        _26237 = NOVALUE;
    }

    /** pathopen.e:274						section = section[1..$-1]*/
    if (IS_SEQUENCE(_section_50985)){
            _26238 = SEQ_PTR(_section_50985)->length;
    }
    else {
        _26238 = 1;
    }
    _26239 = _26238 - 1LL;
    _26238 = NOVALUE;
    rhs_slice_target = (object_ptr)&_section_50985;
    RHS_Slice(_section_50985, 1LL, _26239);
LF: 

    /** pathopen.e:276					section = lower(trim(section))*/
    RefDS(_section_50985);
    RefDS(_4905);
    _26241 = _12trim(_section_50985, _4905, 0LL);
    _0 = _section_50985;
    _section_50985 = _12lower(_26241);
    DeRefDS(_0);
    _26241 = NOVALUE;

    /** pathopen.e:277					if length(section) = 0 then*/
    if (IS_SEQUENCE(_section_50985)){
            _26243 = SEQ_PTR(_section_50985)->length;
    }
    else {
        _26243 = 1;
    }
    if (_26243 != 0LL)
    goto L10; // [339] 476

    /** pathopen.e:278						section = "all"*/
    RefDS(_26204);
    DeRefDS(_section_50985);
    _section_50985 = _26204;
    goto L10; // [351] 476
LE: 

    /** pathopen.e:281				elsif length(in) > 2 then*/
    if (IS_SEQUENCE(_in_50978)){
            _26245 = SEQ_PTR(_in_50978)->length;
    }
    else {
        _26245 = 1;
    }
    if (_26245 <= 2LL)
    goto L11; // [359] 461

    /** pathopen.e:282					if in[1] = '-' then*/
    _2 = (object)SEQ_PTR(_in_50978);
    _26247 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (_26247 != 45LL)
    goto L12; // [369] 443

    /** pathopen.e:283						if in[2] != '-' then*/
    _2 = (object)SEQ_PTR(_in_50978);
    _26249 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (_26249 == 45LL)
    goto L10; // [379] 476

    /** pathopen.e:284							spos = find(' ', in)*/
    _spos_50979 = find_from(32LL, _in_50978, 1LL);

    /** pathopen.e:285							if spos = 0 then*/
    if (_spos_50979 != 0LL)
    goto L13; // [392] 413

    /** pathopen.e:286								arg = in*/
    Ref(_in_50978);
    DeRefi(_arg_50983);
    _arg_50983 = _in_50978;

    /** pathopen.e:287								parm = ""*/
    RefDS(_22218);
    DeRefi(_parm_50984);
    _parm_50984 = _22218;
    goto L10; // [410] 476
L13: 

    /** pathopen.e:289								arg = in[1..spos - 1]*/
    _26253 = _spos_50979 - 1LL;
    rhs_slice_target = (object_ptr)&_arg_50983;
    RHS_Slice(_in_50978, 1LL, _26253);

    /** pathopen.e:290								parm = in[spos + 1 .. $]*/
    _26255 = _spos_50979 + 1;
    if (_26255 > MAXINT){
        _26255 = NewDouble((eudouble)_26255);
    }
    if (IS_SEQUENCE(_in_50978)){
            _26256 = SEQ_PTR(_in_50978)->length;
    }
    else {
        _26256 = 1;
    }
    rhs_slice_target = (object_ptr)&_parm_50984;
    RHS_Slice(_in_50978, _26255, _26256);
    goto L10; // [440] 476
L12: 

    /** pathopen.e:294						arg = "-i"*/
    RefDS(_26258);
    DeRefi(_arg_50983);
    _arg_50983 = _26258;

    /** pathopen.e:295						parm = in*/
    Ref(_in_50978);
    DeRefi(_parm_50984);
    _parm_50984 = _in_50978;
    goto L10; // [458] 476
L11: 

    /** pathopen.e:298					arg = "-i"*/
    RefDS(_26258);
    DeRefi(_arg_50983);
    _arg_50983 = _26258;

    /** pathopen.e:299					parm = in*/
    Ref(_in_50978);
    DeRefi(_parm_50984);
    _parm_50984 = _in_50978;
L10: 
LD: 

    /** pathopen.e:303			if length(arg) > 0 then*/
    if (IS_SEQUENCE(_arg_50983)){
            _26259 = SEQ_PTR(_arg_50983)->length;
    }
    else {
        _26259 = 1;
    }
    if (_26259 <= 0LL)
    goto L14; // [482] 756

    /** pathopen.e:304				integer needed = 0*/
    _needed_51084 = 0LL;

    /** pathopen.e:305				switch section do*/
    _1 = find(_section_50985, _26261);
    switch ( _1 ){ 

        /** pathopen.e:306					case "all" then*/
        case 1:

        /** pathopen.e:307						needed = 1*/
        _needed_51084 = 1LL;
        goto L15; // [507] 691

        /** pathopen.e:309					case "windows" then*/
        case 2:

        /** pathopen.e:310						needed = TWINDOWS*/
        _needed_51084 = _44TWINDOWS_20715;
        goto L15; // [522] 691

        /** pathopen.e:312					case "unix" then*/
        case 3:

        /** pathopen.e:313						needed = TUNIX*/
        _needed_51084 = 0LL;
        goto L15; // [537] 691

        /** pathopen.e:315					case "translate" then*/
        case 4:

        /** pathopen.e:316						needed = TRANSLATE*/
        _needed_51084 = _27TRANSLATE_20179;
        goto L15; // [552] 691

        /** pathopen.e:318					case "translate:windows" then*/
        case 5:

        /** pathopen.e:319						needed = TRANSLATE and TWINDOWS*/
        _needed_51084 = (_27TRANSLATE_20179 != 0 && _44TWINDOWS_20715 != 0);
        goto L15; // [570] 691

        /** pathopen.e:321					case "translate:unix" then*/
        case 6:

        /** pathopen.e:322						needed = TRANSLATE and TUNIX*/
        _needed_51084 = (_27TRANSLATE_20179 != 0 && 0LL != 0);
        goto L15; // [588] 691

        /** pathopen.e:324					case "interpret" then*/
        case 7:

        /** pathopen.e:325						needed = INTERPRET*/
        _needed_51084 = _27INTERPRET_20176;
        goto L15; // [603] 691

        /** pathopen.e:327					case "interpret:windows" then*/
        case 8:

        /** pathopen.e:328						needed = INTERPRET and TWINDOWS*/
        _needed_51084 = (_27INTERPRET_20176 != 0 && _44TWINDOWS_20715 != 0);
        goto L15; // [621] 691

        /** pathopen.e:330					case "interpret:unix" then*/
        case 9:

        /** pathopen.e:331						needed = INTERPRET and TUNIX*/
        _needed_51084 = (_27INTERPRET_20176 != 0 && 0LL != 0);
        goto L15; // [639] 691

        /** pathopen.e:333					case "bind" then*/
        case 10:

        /** pathopen.e:334						needed = BIND*/
        _needed_51084 = _27BIND_20182;
        goto L15; // [654] 691

        /** pathopen.e:336					case "bind:windows" then*/
        case 11:

        /** pathopen.e:337						needed = BIND and TWINDOWS*/
        _needed_51084 = (_27BIND_20182 != 0 && _44TWINDOWS_20715 != 0);
        goto L15; // [672] 691

        /** pathopen.e:339					case "bind:unix" then*/
        case 12:

        /** pathopen.e:340						needed = BIND and TUNIX*/
        _needed_51084 = (_27BIND_20182 != 0 && 0LL != 0);
    ;}L15: 

    /** pathopen.e:344				if needed then*/
    if (_needed_51084 == 0)
    {
        goto L16; // [693] 755
    }
    else{
    }

    /** pathopen.e:345					if equal(arg, "-c") then*/
    if (_arg_50983 == _26280)
    _26281 = 1;
    else if (IS_ATOM_INT(_arg_50983) && IS_ATOM_INT(_26280))
    _26281 = 0;
    else
    _26281 = (compare(_arg_50983, _26280) == 0);
    if (_26281 == 0)
    {
        _26281 = NOVALUE;
        goto L17; // [702] 728
    }
    else{
        _26281 = NOVALUE;
    }

    /** pathopen.e:346						if length(parm) > 0 then*/
    if (IS_SEQUENCE(_parm_50984)){
            _26282 = SEQ_PTR(_parm_50984)->length;
    }
    else {
        _26282 = 1;
    }
    if (_26282 <= 0LL)
    goto L18; // [710] 754

    /** pathopen.e:347							new_args &= load_euphoria_config(parm)*/
    RefDS(_parm_50984);
    _26284 = _46load_euphoria_config(_parm_50984);
    if (IS_SEQUENCE(_new_args_50982) && IS_ATOM(_26284)) {
        Ref(_26284);
        Append(&_new_args_50982, _new_args_50982, _26284);
    }
    else if (IS_ATOM(_new_args_50982) && IS_SEQUENCE(_26284)) {
    }
    else {
        Concat((object_ptr)&_new_args_50982, _new_args_50982, _26284);
    }
    DeRef(_26284);
    _26284 = NOVALUE;
    goto L18; // [725] 754
L17: 

    /** pathopen.e:350						new_args = append(new_args, arg)*/
    RefDS(_arg_50983);
    Append(&_new_args_50982, _new_args_50982, _arg_50983);

    /** pathopen.e:351						if length(parm > 0) then*/
    _26287 = binary_op(GREATER, _parm_50984, 0LL);
    if (IS_SEQUENCE(_26287)){
            _26288 = SEQ_PTR(_26287)->length;
    }
    else {
        _26288 = 1;
    }
    DeRefDS(_26287);
    _26287 = NOVALUE;
    if (_26288 == 0)
    {
        _26288 = NOVALUE;
        goto L19; // [743] 753
    }
    else{
        _26288 = NOVALUE;
    }

    /** pathopen.e:352							new_args = append(new_args, parm)*/
    RefDS(_parm_50984);
    Append(&_new_args_50982, _new_args_50982, _parm_50984);
L19: 
L18: 
L16: 
L14: 

    /** pathopen.e:358			in = gets( fn )*/
    DeRefi(_in_50978);
    _in_50978 = EGets(_fn_50977);

    /** pathopen.e:359		end while*/
    goto L5; // [765] 128
L6: 

    /** pathopen.e:360		close(fn)*/
    EClose(_fn_50977);

    /** pathopen.e:362		return new_args*/
    DeRefDS(_file_50976);
    DeRefi(_in_50978);
    DeRef(_conf_path_50981);
    DeRefi(_arg_50983);
    DeRefi(_parm_50984);
    DeRef(_section_50985);
    DeRef(_26239);
    _26239 = NOVALUE;
    _26247 = NOVALUE;
    _26249 = NOVALUE;
    DeRef(_26232);
    _26232 = NOVALUE;
    _26287 = NOVALUE;
    DeRef(_26253);
    _26253 = NOVALUE;
    _26226 = NOVALUE;
    DeRef(_26255);
    _26255 = NOVALUE;
    return _new_args_50982;
    ;
}


object _46GetDefaultArgs(object _user_files_51151)
{
    object _env_51152 = NOVALUE;
    object _default_args_51153 = NOVALUE;
    object _conf_file_51154 = NOVALUE;
    object _cmd_options_51156 = NOVALUE;
    object _user_config_51162 = NOVALUE;
    object _26333 = NOVALUE;
    object _26332 = NOVALUE;
    object _26331 = NOVALUE;
    object _26328 = NOVALUE;
    object _26327 = NOVALUE;
    object _26326 = NOVALUE;
    object _26324 = NOVALUE;
    object _26320 = NOVALUE;
    object _26319 = NOVALUE;
    object _26318 = NOVALUE;
    object _26317 = NOVALUE;
    object _26313 = NOVALUE;
    object _26312 = NOVALUE;
    object _26311 = NOVALUE;
    object _26309 = NOVALUE;
    object _26303 = NOVALUE;
    object _26302 = NOVALUE;
    object _26300 = NOVALUE;
    object _26298 = NOVALUE;
    object _26297 = NOVALUE;
    object _26293 = NOVALUE;
    object _26292 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:367		sequence default_args = {}*/
    RefDS(_22218);
    DeRef(_default_args_51153);
    _default_args_51153 = _22218;

    /** pathopen.e:368		sequence conf_file = "eu.cfg"*/
    RefDS(_26198);
    DeRefi(_conf_file_51154);
    _conf_file_51154 = _26198;

    /** pathopen.e:370		if loaded_config_inc_paths then return "" end if*/
    if (_46loaded_config_inc_paths_50833 == 0)
    {
        goto L1; // [21] 29
    }
    else{
    }
    RefDS(_22218);
    DeRefDS(_user_files_51151);
    DeRef(_env_51152);
    DeRefDS(_default_args_51153);
    DeRefDSi(_conf_file_51154);
    DeRef(_cmd_options_51156);
    return _22218;
L1: 

    /** pathopen.e:371		loaded_config_inc_paths = 1*/
    _46loaded_config_inc_paths_50833 = 1LL;

    /** pathopen.e:380		sequence cmd_options = get_options()*/
    _0 = _cmd_options_51156;
    _cmd_options_51156 = _47get_options();
    DeRef(_0);

    /** pathopen.e:382		default_args = {}*/
    RefDS(_22218);
    DeRef(_default_args_51153);
    _default_args_51153 = _22218;

    /** pathopen.e:385		for i = 1 to length( user_files ) do*/
    if (IS_SEQUENCE(_user_files_51151)){
            _26292 = SEQ_PTR(_user_files_51151)->length;
    }
    else {
        _26292 = 1;
    }
    {
        object _i_51160;
        _i_51160 = 1LL;
L2: 
        if (_i_51160 > _26292){
            goto L3; // [53] 92
        }

        /** pathopen.e:386			sequence user_config = load_euphoria_config( user_files[i] )*/
        _2 = (object)SEQ_PTR(_user_files_51151);
        _26293 = (object)*(((s1_ptr)_2)->base + _i_51160);
        Ref(_26293);
        _0 = _user_config_51162;
        _user_config_51162 = _46load_euphoria_config(_26293);
        DeRef(_0);
        _26293 = NOVALUE;

        /** pathopen.e:387			default_args = merge_parameters( user_config, default_args, cmd_options, 1 )*/
        RefDS(_user_config_51162);
        RefDS(_default_args_51153);
        RefDS(_cmd_options_51156);
        _0 = _default_args_51153;
        _default_args_51153 = _47merge_parameters(_user_config_51162, _default_args_51153, _cmd_options_51156, 1LL);
        DeRefDS(_0);
        DeRefDS(_user_config_51162);
        _user_config_51162 = NOVALUE;

        /** pathopen.e:388		end for*/
        _i_51160 = _i_51160 + 1LL;
        goto L2; // [87] 60
L3: 
        ;
    }

    /** pathopen.e:391		default_args = merge_parameters( load_euphoria_config("./" & conf_file), default_args, cmd_options, 1 )*/
    Concat((object_ptr)&_26297, _26296, _conf_file_51154);
    _26298 = _46load_euphoria_config(_26297);
    _26297 = NOVALUE;
    RefDS(_default_args_51153);
    RefDS(_cmd_options_51156);
    _0 = _default_args_51153;
    _default_args_51153 = _47merge_parameters(_26298, _default_args_51153, _cmd_options_51156, 1LL);
    DeRefDS(_0);
    _26298 = NOVALUE;

    /** pathopen.e:394		env = strip_file_from_path( exe_path() )*/
    _26300 = _46exe_path();
    _0 = _env_51152;
    _env_51152 = _46strip_file_from_path(_26300);
    DeRef(_0);
    _26300 = NOVALUE;

    /** pathopen.e:395		default_args = merge_parameters( load_euphoria_config( env & conf_file ), default_args, cmd_options, 1 )*/
    if (IS_SEQUENCE(_env_51152) && IS_ATOM(_conf_file_51154)) {
    }
    else if (IS_ATOM(_env_51152) && IS_SEQUENCE(_conf_file_51154)) {
        Ref(_env_51152);
        Prepend(&_26302, _conf_file_51154, _env_51152);
    }
    else {
        Concat((object_ptr)&_26302, _env_51152, _conf_file_51154);
    }
    _26303 = _46load_euphoria_config(_26302);
    _26302 = NOVALUE;
    RefDS(_default_args_51153);
    RefDS(_cmd_options_51156);
    _0 = _default_args_51153;
    _default_args_51153 = _47merge_parameters(_26303, _default_args_51153, _cmd_options_51156, 1LL);
    DeRefDS(_0);
    _26303 = NOVALUE;

    /** pathopen.e:398		ifdef UNIX then*/

    /** pathopen.e:407			env = getenv( "ALLUSERSPROFILE" )*/
    DeRef(_env_51152);
    _env_51152 = EGetEnv(_26307);

    /** pathopen.e:408			if sequence(env) then*/
    _26309 = IS_SEQUENCE(_env_51152);
    if (_26309 == 0)
    {
        _26309 = NOVALUE;
        goto L4; // [151] 179
    }
    else{
        _26309 = NOVALUE;
    }

    /** pathopen.e:409				default_args = merge_parameters( load_euphoria_config( expand_path( "euphoria", env ) & conf_file ), default_args, cmd_options, 1 )*/
    RefDS(_26310);
    Ref(_env_51152);
    _26311 = _46expand_path(_26310, _env_51152);
    if (IS_SEQUENCE(_26311) && IS_ATOM(_conf_file_51154)) {
    }
    else if (IS_ATOM(_26311) && IS_SEQUENCE(_conf_file_51154)) {
        Ref(_26311);
        Prepend(&_26312, _conf_file_51154, _26311);
    }
    else {
        Concat((object_ptr)&_26312, _26311, _conf_file_51154);
        DeRef(_26311);
        _26311 = NOVALUE;
    }
    DeRef(_26311);
    _26311 = NOVALUE;
    _26313 = _46load_euphoria_config(_26312);
    _26312 = NOVALUE;
    RefDS(_default_args_51153);
    RefDS(_cmd_options_51156);
    _0 = _default_args_51153;
    _default_args_51153 = _47merge_parameters(_26313, _default_args_51153, _cmd_options_51156, 1LL);
    DeRefDS(_0);
    _26313 = NOVALUE;
L4: 

    /** pathopen.e:412			env = getenv( "APPDATA" )*/
    DeRef(_env_51152);
    _env_51152 = EGetEnv(_26315);

    /** pathopen.e:413			if sequence(env) then*/
    _26317 = IS_SEQUENCE(_env_51152);
    if (_26317 == 0)
    {
        _26317 = NOVALUE;
        goto L5; // [189] 217
    }
    else{
        _26317 = NOVALUE;
    }

    /** pathopen.e:414				default_args = merge_parameters( load_euphoria_config( expand_path( "euphoria", env ) & conf_file ), default_args, cmd_options, 1 )*/
    RefDS(_26310);
    Ref(_env_51152);
    _26318 = _46expand_path(_26310, _env_51152);
    if (IS_SEQUENCE(_26318) && IS_ATOM(_conf_file_51154)) {
    }
    else if (IS_ATOM(_26318) && IS_SEQUENCE(_conf_file_51154)) {
        Ref(_26318);
        Prepend(&_26319, _conf_file_51154, _26318);
    }
    else {
        Concat((object_ptr)&_26319, _26318, _conf_file_51154);
        DeRef(_26318);
        _26318 = NOVALUE;
    }
    DeRef(_26318);
    _26318 = NOVALUE;
    _26320 = _46load_euphoria_config(_26319);
    _26319 = NOVALUE;
    RefDS(_default_args_51153);
    RefDS(_cmd_options_51156);
    _0 = _default_args_51153;
    _default_args_51153 = _47merge_parameters(_26320, _default_args_51153, _cmd_options_51156, 1LL);
    DeRefDS(_0);
    _26320 = NOVALUE;
L5: 

    /** pathopen.e:417			env = getenv( "HOMEPATH" )*/
    DeRef(_env_51152);
    _env_51152 = EGetEnv(_26322);

    /** pathopen.e:418			if sequence(env) then*/
    _26324 = IS_SEQUENCE(_env_51152);
    if (_26324 == 0)
    {
        _26324 = NOVALUE;
        goto L6; // [227] 256
    }
    else{
        _26324 = NOVALUE;
    }

    /** pathopen.e:419				default_args = merge_parameters( load_euphoria_config( getenv( "HOMEDRIVE" ) & env & "\\" & conf_file ), default_args, cmd_options, 1 )*/
    _26326 = EGetEnv(_26325);
    {
        object concat_list[4];

        concat_list[0] = _conf_file_51154;
        concat_list[1] = _23942;
        concat_list[2] = _env_51152;
        concat_list[3] = _26326;
        Concat_N((object_ptr)&_26327, concat_list, 4);
    }
    DeRef(_26326);
    _26326 = NOVALUE;
    _26328 = _46load_euphoria_config(_26327);
    _26327 = NOVALUE;
    RefDS(_default_args_51153);
    RefDS(_cmd_options_51156);
    _0 = _default_args_51153;
    _default_args_51153 = _47merge_parameters(_26328, _default_args_51153, _cmd_options_51156, 1LL);
    DeRefDS(_0);
    _26328 = NOVALUE;
L6: 

    /** pathopen.e:427		env = get_eudir()*/
    _0 = _env_51152;
    _env_51152 = _28get_eudir();
    DeRef(_0);

    /** pathopen.e:428		if sequence(env) then*/
    _26331 = IS_SEQUENCE(_env_51152);
    if (_26331 == 0)
    {
        _26331 = NOVALUE;
        goto L7; // [266] 291
    }
    else{
        _26331 = NOVALUE;
    }

    /** pathopen.e:429			default_args = merge_parameters( load_euphoria_config(env & "/" & conf_file), default_args, cmd_options, 1 )*/
    {
        object concat_list[3];

        concat_list[0] = _conf_file_51154;
        concat_list[1] = _23818;
        concat_list[2] = _env_51152;
        Concat_N((object_ptr)&_26332, concat_list, 3);
    }
    _26333 = _46load_euphoria_config(_26332);
    _26332 = NOVALUE;
    RefDS(_default_args_51153);
    RefDS(_cmd_options_51156);
    _0 = _default_args_51153;
    _default_args_51153 = _47merge_parameters(_26333, _default_args_51153, _cmd_options_51156, 1LL);
    DeRefDS(_0);
    _26333 = NOVALUE;
L7: 

    /** pathopen.e:432		return default_args*/
    DeRefDS(_user_files_51151);
    DeRef(_env_51152);
    DeRefi(_conf_file_51154);
    DeRef(_cmd_options_51156);
    return _default_args_51153;
    ;
}


object _46ConfPath(object _file_name_51219)
{
    object _file_path_51220 = NOVALUE;
    object _try_51221 = NOVALUE;
    object _26340 = NOVALUE;
    object _26336 = NOVALUE;
    object _26335 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:440		for i = 1 to length(config_inc_paths) do*/
    if (IS_SEQUENCE(_46config_inc_paths_50832)){
            _26335 = SEQ_PTR(_46config_inc_paths_50832)->length;
    }
    else {
        _26335 = 1;
    }
    {
        object _i_51223;
        _i_51223 = 1LL;
L1: 
        if (_i_51223 > _26335){
            goto L2; // [10] 60
        }

        /** pathopen.e:441			file_path = config_inc_paths[i] & file_name*/
        _2 = (object)SEQ_PTR(_46config_inc_paths_50832);
        _26336 = (object)*(((s1_ptr)_2)->base + _i_51223);
        Concat((object_ptr)&_file_path_51220, _26336, _file_name_51219);
        _26336 = NOVALUE;
        _26336 = NOVALUE;

        /** pathopen.e:442			try = open( file_path, "r" )*/
        _try_51221 = EOpen(_file_path_51220, _26205, 0LL);

        /** pathopen.e:443			if try != -1 then*/
        if (_try_51221 == -1LL)
        goto L3; // [38] 53

        /** pathopen.e:444				return {file_path, try}*/
        RefDS(_file_path_51220);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_51220;
        ((intptr_t *)_2)[2] = _try_51221;
        _26340 = MAKE_SEQ(_1);
        DeRefDS(_file_name_51219);
        DeRefDS(_file_path_51220);
        return _26340;
L3: 

        /** pathopen.e:446		end for*/
        _i_51223 = _i_51223 + 1LL;
        goto L1; // [55] 17
L2: 
        ;
    }

    /** pathopen.e:447		return -1*/
    DeRefDS(_file_name_51219);
    DeRef(_file_path_51220);
    DeRef(_26340);
    _26340 = NOVALUE;
    return -1LL;
    ;
}


object _46ScanPath(object _file_name_51233, object _env_51234, object _flag_51235)
{
    object _inc_path_51236 = NOVALUE;
    object _full_path_51237 = NOVALUE;
    object _file_path_51238 = NOVALUE;
    object _strings_51239 = NOVALUE;
    object _end_path_51240 = NOVALUE;
    object _start_path_51241 = NOVALUE;
    object _try_51242 = NOVALUE;
    object _use_cache_51243 = NOVALUE;
    object _pos_51244 = NOVALUE;
    object _26418 = NOVALUE;
    object _26417 = NOVALUE;
    object _26416 = NOVALUE;
    object _26415 = NOVALUE;
    object _26414 = NOVALUE;
    object _26413 = NOVALUE;
    object _26412 = NOVALUE;
    object _26411 = NOVALUE;
    object _26410 = NOVALUE;
    object _26409 = NOVALUE;
    object _26408 = NOVALUE;
    object _26407 = NOVALUE;
    object _26406 = NOVALUE;
    object _26405 = NOVALUE;
    object _26404 = NOVALUE;
    object _26403 = NOVALUE;
    object _26398 = NOVALUE;
    object _26397 = NOVALUE;
    object _26396 = NOVALUE;
    object _26395 = NOVALUE;
    object _26394 = NOVALUE;
    object _26390 = NOVALUE;
    object _26389 = NOVALUE;
    object _26388 = NOVALUE;
    object _26387 = NOVALUE;
    object _26386 = NOVALUE;
    object _26385 = NOVALUE;
    object _26383 = NOVALUE;
    object _26381 = NOVALUE;
    object _26380 = NOVALUE;
    object _26378 = NOVALUE;
    object _26377 = NOVALUE;
    object _26376 = NOVALUE;
    object _26373 = NOVALUE;
    object _26372 = NOVALUE;
    object _26370 = NOVALUE;
    object _26369 = NOVALUE;
    object _26368 = NOVALUE;
    object _26366 = NOVALUE;
    object _26364 = NOVALUE;
    object _26359 = NOVALUE;
    object _26358 = NOVALUE;
    object _26357 = NOVALUE;
    object _26356 = NOVALUE;
    object _26355 = NOVALUE;
    object _26350 = NOVALUE;
    object _26342 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** pathopen.e:459		inc_path = getenv(env)*/
    DeRefi(_inc_path_51236);
    _inc_path_51236 = EGetEnv(_env_51234);

    /** pathopen.e:460		if compare(inc_path,{})!=1 then -- nothing to do, just fail*/
    if (IS_ATOM_INT(_inc_path_51236) && IS_ATOM_INT(_22218)){
        _26342 = (_inc_path_51236 < _22218) ? -1 : (_inc_path_51236 > _22218);
    }
    else{
        _26342 = compare(_inc_path_51236, _22218);
    }
    if (_26342 == 1LL)
    goto L1; // [18] 29

    /** pathopen.e:461			return -1*/
    DeRefDS(_file_name_51233);
    DeRefDSi(_env_51234);
    DeRefi(_inc_path_51236);
    DeRef(_full_path_51237);
    DeRef(_file_path_51238);
    DeRef(_strings_51239);
    return -1LL;
L1: 

    /** pathopen.e:464		num_var = find(env,cache_vars)*/
    _46num_var_50823 = find_from(_env_51234, _46cache_vars_50824, 1LL);

    /** pathopen.e:465		use_cache = check_cache(env,inc_path)*/
    RefDS(_env_51234);
    Ref(_inc_path_51236);
    _use_cache_51243 = _46check_cache(_env_51234, _inc_path_51236);
    if (!IS_ATOM_INT(_use_cache_51243)) {
        _1 = (object)(DBL_PTR(_use_cache_51243)->dbl);
        DeRefDS(_use_cache_51243);
        _use_cache_51243 = _1;
    }

    /** pathopen.e:466		inc_path = append(inc_path, PATH_SEPARATOR)*/
    Append(&_inc_path_51236, _inc_path_51236, 59LL);

    /** pathopen.e:468		file_name = SLASH & file_name*/
    Prepend(&_file_name_51233, _file_name_51233, 92LL);

    /** pathopen.e:469		if flag then*/
    if (_flag_51235 == 0)
    {
        goto L2; // [65] 77
    }
    else{
    }

    /** pathopen.e:470			file_name = include_subfolder & file_name*/
    Concat((object_ptr)&_file_name_51233, _46include_subfolder_50819, _file_name_51233);
L2: 

    /** pathopen.e:472		strings = cache_substrings[num_var]*/
    DeRef(_strings_51239);
    _2 = (object)SEQ_PTR(_46cache_substrings_50826);
    _strings_51239 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
    RefDS(_strings_51239);

    /** pathopen.e:474		if use_cache then*/
    if (_use_cache_51243 == 0)
    {
        goto L3; // [91] 292
    }
    else{
    }

    /** pathopen.e:475			for i=1 to length(strings) do*/
    if (IS_SEQUENCE(_strings_51239)){
            _26350 = SEQ_PTR(_strings_51239)->length;
    }
    else {
        _26350 = 1;
    }
    {
        object _i_51260;
        _i_51260 = 1LL;
L4: 
        if (_i_51260 > _26350){
            goto L5; // [99] 252
        }

        /** pathopen.e:476				full_path = strings[i]*/
        DeRef(_full_path_51237);
        _2 = (object)SEQ_PTR(_strings_51239);
        _full_path_51237 = (object)*(((s1_ptr)_2)->base + _i_51260);
        Ref(_full_path_51237);

        /** pathopen.e:477				file_path = full_path & file_name*/
        Concat((object_ptr)&_file_path_51238, _full_path_51237, _file_name_51233);

        /** pathopen.e:478				try = open_locked(file_path)    */
        RefDS(_file_path_51238);
        _try_51242 = _28open_locked(_file_path_51238);
        if (!IS_ATOM_INT(_try_51242)) {
            _1 = (object)(DBL_PTR(_try_51242)->dbl);
            DeRefDS(_try_51242);
            _try_51242 = _1;
        }

        /** pathopen.e:479				if try != -1 then*/
        if (_try_51242 == -1LL)
        goto L6; // [130] 145

        /** pathopen.e:480					return {file_path,try}*/
        RefDS(_file_path_51238);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_51238;
        ((intptr_t *)_2)[2] = _try_51242;
        _26355 = MAKE_SEQ(_1);
        DeRefDS(_file_name_51233);
        DeRefDSi(_env_51234);
        DeRefi(_inc_path_51236);
        DeRefDS(_full_path_51237);
        DeRefDS(_file_path_51238);
        DeRefDS(_strings_51239);
        return _26355;
L6: 

        /** pathopen.e:482				ifdef WINDOWS then */

        /** pathopen.e:483					if sequence(cache_converted[num_var][i]) then*/
        _2 = (object)SEQ_PTR(_46cache_converted_50829);
        _26356 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
        _2 = (object)SEQ_PTR(_26356);
        _26357 = (object)*(((s1_ptr)_2)->base + _i_51260);
        _26356 = NOVALUE;
        _26358 = IS_SEQUENCE(_26357);
        _26357 = NOVALUE;
        if (_26358 == 0)
        {
            _26358 = NOVALUE;
            goto L7; // [164] 245
        }
        else{
            _26358 = NOVALUE;
        }

        /** pathopen.e:486						full_path = cache_converted[num_var][i]*/
        _2 = (object)SEQ_PTR(_46cache_converted_50829);
        _26359 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
        DeRef(_full_path_51237);
        _2 = (object)SEQ_PTR(_26359);
        _full_path_51237 = (object)*(((s1_ptr)_2)->base + _i_51260);
        Ref(_full_path_51237);
        _26359 = NOVALUE;

        /** pathopen.e:487						file_path = full_path & file_name*/
        Concat((object_ptr)&_file_path_51238, _full_path_51237, _file_name_51233);

        /** pathopen.e:488						try = open_locked(file_path)*/
        RefDS(_file_path_51238);
        _try_51242 = _28open_locked(_file_path_51238);
        if (!IS_ATOM_INT(_try_51242)) {
            _1 = (object)(DBL_PTR(_try_51242)->dbl);
            DeRefDS(_try_51242);
            _try_51242 = _1;
        }

        /** pathopen.e:489						if try != -1 then*/
        if (_try_51242 == -1LL)
        goto L8; // [199] 244

        /** pathopen.e:490							cache_converted[num_var][i] = 0*/
        _2 = (object)SEQ_PTR(_46cache_converted_50829);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_converted_50829 = MAKE_SEQ(_2);
        }
        _3 = (object)(_46num_var_50823 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_51260);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0LL;
        DeRef(_1);
        _26364 = NOVALUE;

        /** pathopen.e:491							cache_substrings[num_var][i] = full_path*/
        _2 = (object)SEQ_PTR(_46cache_substrings_50826);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_substrings_50826 = MAKE_SEQ(_2);
        }
        _3 = (object)(_46num_var_50823 + ((s1_ptr)_2)->base);
        RefDS(_full_path_51237);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_51260);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _full_path_51237;
        DeRef(_1);
        _26366 = NOVALUE;

        /** pathopen.e:492							return {file_path,try}*/
        RefDS(_file_path_51238);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_51238;
        ((intptr_t *)_2)[2] = _try_51242;
        _26368 = MAKE_SEQ(_1);
        DeRefDS(_file_name_51233);
        DeRefDSi(_env_51234);
        DeRefi(_inc_path_51236);
        DeRefDS(_full_path_51237);
        DeRefDS(_file_path_51238);
        DeRef(_strings_51239);
        DeRef(_26355);
        _26355 = NOVALUE;
        return _26368;
L8: 
L7: 

        /** pathopen.e:496			end for*/
        _i_51260 = _i_51260 + 1LL;
        goto L4; // [247] 106
L5: 
        ;
    }

    /** pathopen.e:497			if cache_complete[num_var] then -- nothing to scan*/
    _2 = (object)SEQ_PTR(_46cache_complete_50830);
    _26369 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
    if (_26369 == 0)
    {
        _26369 = NOVALUE;
        goto L9; // [262] 274
    }
    else{
        _26369 = NOVALUE;
    }

    /** pathopen.e:498				return -1*/
    DeRefDS(_file_name_51233);
    DeRefDSi(_env_51234);
    DeRefi(_inc_path_51236);
    DeRef(_full_path_51237);
    DeRef(_file_path_51238);
    DeRef(_strings_51239);
    DeRef(_26368);
    _26368 = NOVALUE;
    DeRef(_26355);
    _26355 = NOVALUE;
    return -1LL;
    goto LA; // [271] 298
L9: 

    /** pathopen.e:500				pos = cache_delims[num_var]+1 -- scan remainder, starting from as far sa possible*/
    _2 = (object)SEQ_PTR(_46cache_delims_50831);
    _26370 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
    _pos_51244 = _26370 + 1;
    _26370 = NOVALUE;
    goto LA; // [289] 298
L3: 

    /** pathopen.e:503			pos = 1*/
    _pos_51244 = 1LL;
LA: 

    /** pathopen.e:506		start_path = 0*/
    _start_path_51241 = 0LL;

    /** pathopen.e:507		for p = pos to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_51236)){
            _26372 = SEQ_PTR(_inc_path_51236)->length;
    }
    else {
        _26372 = 1;
    }
    {
        object _p_51292;
        _p_51292 = _pos_51244;
LB: 
        if (_p_51292 > _26372){
            goto LC; // [310] 716
        }

        /** pathopen.e:508			if inc_path[p] = PATH_SEPARATOR then*/
        _2 = (object)SEQ_PTR(_inc_path_51236);
        _26373 = (object)*(((s1_ptr)_2)->base + _p_51292);
        if (_26373 != 59LL)
        goto LD; // [325] 665

        /** pathopen.e:510				cache_delims[num_var] = p*/
        _2 = (object)SEQ_PTR(_46cache_delims_50831);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_delims_50831 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50823);
        *(intptr_t *)_2 = _p_51292;

        /** pathopen.e:512				end_path = p-1*/
        _end_path_51240 = _p_51292 - 1LL;

        /** pathopen.e:513				while end_path >= start_path and find(inc_path[end_path], " \t" & SLASH_CHARS) do*/
LE: 
        _26376 = (_end_path_51240 >= _start_path_51241);
        if (_26376 == 0) {
            goto LF; // [354] 388
        }
        _2 = (object)SEQ_PTR(_inc_path_51236);
        _26378 = (object)*(((s1_ptr)_2)->base + _end_path_51240);
        Concat((object_ptr)&_26380, _26379, _44SLASH_CHARS_20736);
        _26381 = find_from(_26378, _26380, 1LL);
        _26378 = NOVALUE;
        DeRefDS(_26380);
        _26380 = NOVALUE;
        if (_26381 == 0)
        {
            _26381 = NOVALUE;
            goto LF; // [374] 388
        }
        else{
            _26381 = NOVALUE;
        }

        /** pathopen.e:514					end_path-=1*/
        _end_path_51240 = _end_path_51240 - 1LL;

        /** pathopen.e:515				end while*/
        goto LE; // [385] 350
LF: 

        /** pathopen.e:517				if start_path and end_path then*/
        if (_start_path_51241 == 0) {
            goto L10; // [390] 709
        }
        if (_end_path_51240 == 0)
        {
            goto L10; // [395] 709
        }
        else{
        }

        /** pathopen.e:518					full_path = inc_path[start_path..end_path]*/
        rhs_slice_target = (object_ptr)&_full_path_51237;
        RHS_Slice(_inc_path_51236, _start_path_51241, _end_path_51240);

        /** pathopen.e:519					cache_substrings[num_var] = append(cache_substrings[num_var],full_path)*/
        _2 = (object)SEQ_PTR(_46cache_substrings_50826);
        _26385 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
        RefDS(_full_path_51237);
        Append(&_26386, _26385, _full_path_51237);
        _26385 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_substrings_50826);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_substrings_50826 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50823);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26386;
        if( _1 != _26386 ){
            DeRefDS(_1);
        }
        _26386 = NOVALUE;

        /** pathopen.e:520					cache_starts[num_var] &= start_path*/
        _2 = (object)SEQ_PTR(_46cache_starts_50827);
        _26387 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
        if (IS_SEQUENCE(_26387) && IS_ATOM(_start_path_51241)) {
            Append(&_26388, _26387, _start_path_51241);
        }
        else if (IS_ATOM(_26387) && IS_SEQUENCE(_start_path_51241)) {
        }
        else {
            Concat((object_ptr)&_26388, _26387, _start_path_51241);
            _26387 = NOVALUE;
        }
        _26387 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_starts_50827);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_starts_50827 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50823);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26388;
        if( _1 != _26388 ){
            DeRef(_1);
        }
        _26388 = NOVALUE;

        /** pathopen.e:521					cache_ends[num_var] &= end_path*/
        _2 = (object)SEQ_PTR(_46cache_ends_50828);
        _26389 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
        if (IS_SEQUENCE(_26389) && IS_ATOM(_end_path_51240)) {
            Append(&_26390, _26389, _end_path_51240);
        }
        else if (IS_ATOM(_26389) && IS_SEQUENCE(_end_path_51240)) {
        }
        else {
            Concat((object_ptr)&_26390, _26389, _end_path_51240);
            _26389 = NOVALUE;
        }
        _26389 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_ends_50828);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_ends_50828 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50823);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26390;
        if( _1 != _26390 ){
            DeRef(_1);
        }
        _26390 = NOVALUE;

        /** pathopen.e:522					file_path = full_path & file_name  */
        Concat((object_ptr)&_file_path_51238, _full_path_51237, _file_name_51233);

        /** pathopen.e:523					try = open_locked(file_path)*/
        RefDS(_file_path_51238);
        _try_51242 = _28open_locked(_file_path_51238);
        if (!IS_ATOM_INT(_try_51242)) {
            _1 = (object)(DBL_PTR(_try_51242)->dbl);
            DeRefDS(_try_51242);
            _try_51242 = _1;
        }

        /** pathopen.e:524					if try != -1 then -- valid path, no point trying to convert*/
        if (_try_51242 == -1LL)
        goto L11; // [479] 514

        /** pathopen.e:525						ifdef WINDOWS then*/

        /** pathopen.e:526							cache_converted[num_var] &= 0*/
        _2 = (object)SEQ_PTR(_46cache_converted_50829);
        _26394 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
        if (IS_SEQUENCE(_26394) && IS_ATOM(0LL)) {
            Append(&_26395, _26394, 0LL);
        }
        else if (IS_ATOM(_26394) && IS_SEQUENCE(0LL)) {
        }
        else {
            Concat((object_ptr)&_26395, _26394, 0LL);
            _26394 = NOVALUE;
        }
        _26394 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_converted_50829);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_converted_50829 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50823);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26395;
        if( _1 != _26395 ){
            DeRef(_1);
        }
        _26395 = NOVALUE;

        /** pathopen.e:528						return {file_path,try}*/
        RefDS(_file_path_51238);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_51238;
        ((intptr_t *)_2)[2] = _try_51242;
        _26396 = MAKE_SEQ(_1);
        DeRefDS(_file_name_51233);
        DeRefDSi(_env_51234);
        DeRefi(_inc_path_51236);
        DeRefDSi(_full_path_51237);
        DeRefDS(_file_path_51238);
        DeRef(_strings_51239);
        DeRef(_26376);
        _26376 = NOVALUE;
        _26373 = NOVALUE;
        DeRef(_26368);
        _26368 = NOVALUE;
        DeRef(_26355);
        _26355 = NOVALUE;
        return _26396;
L11: 

        /** pathopen.e:530					ifdef WINDOWS then*/

        /** pathopen.e:531						if find(1, full_path>=128) then*/
        _26397 = binary_op(GREATEREQ, _full_path_51237, 128LL);
        _26398 = find_from(1LL, _26397, 1LL);
        DeRefDS(_26397);
        _26397 = NOVALUE;
        if (_26398 == 0)
        {
            _26398 = NOVALUE;
            goto L12; // [527] 637
        }
        else{
            _26398 = NOVALUE;
        }

        /** pathopen.e:533							full_path = convert_from_OEM(full_path)*/
        RefDS(_full_path_51237);
        _0 = _full_path_51237;
        _full_path_51237 = _46convert_from_OEM(_full_path_51237);
        DeRefDS(_0);

        /** pathopen.e:534							file_path = full_path & file_name*/
        Concat((object_ptr)&_file_path_51238, _full_path_51237, _file_name_51233);

        /** pathopen.e:535							try = open_locked(file_path)*/
        RefDS(_file_path_51238);
        _try_51242 = _28open_locked(_file_path_51238);
        if (!IS_ATOM_INT(_try_51242)) {
            _1 = (object)(DBL_PTR(_try_51242)->dbl);
            DeRefDS(_try_51242);
            _try_51242 = _1;
        }

        /** pathopen.e:536							if try != -1 then -- that was it; record translation as the valid path*/
        if (_try_51242 == -1LL)
        goto L13; // [554] 611

        /** pathopen.e:537								cache_converted[num_var] &= 0*/
        _2 = (object)SEQ_PTR(_46cache_converted_50829);
        _26403 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
        if (IS_SEQUENCE(_26403) && IS_ATOM(0LL)) {
            Append(&_26404, _26403, 0LL);
        }
        else if (IS_ATOM(_26403) && IS_SEQUENCE(0LL)) {
        }
        else {
            Concat((object_ptr)&_26404, _26403, 0LL);
            _26403 = NOVALUE;
        }
        _26403 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_converted_50829);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_converted_50829 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50823);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26404;
        if( _1 != _26404 ){
            DeRef(_1);
        }
        _26404 = NOVALUE;

        /** pathopen.e:538								cache_substrings[num_var] = append(cache_substrings[num_var],full_path)*/
        _2 = (object)SEQ_PTR(_46cache_substrings_50826);
        _26405 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
        RefDS(_full_path_51237);
        Append(&_26406, _26405, _full_path_51237);
        _26405 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_substrings_50826);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_substrings_50826 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50823);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26406;
        if( _1 != _26406 ){
            DeRefDS(_1);
        }
        _26406 = NOVALUE;

        /** pathopen.e:539								return {file_path,try}*/
        RefDS(_file_path_51238);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_51238;
        ((intptr_t *)_2)[2] = _try_51242;
        _26407 = MAKE_SEQ(_1);
        DeRefDS(_file_name_51233);
        DeRefDSi(_env_51234);
        DeRefi(_inc_path_51236);
        DeRefDS(_full_path_51237);
        DeRefDS(_file_path_51238);
        DeRef(_strings_51239);
        DeRef(_26396);
        _26396 = NOVALUE;
        DeRef(_26376);
        _26376 = NOVALUE;
        _26373 = NOVALUE;
        DeRef(_26368);
        _26368 = NOVALUE;
        DeRef(_26355);
        _26355 = NOVALUE;
        return _26407;
        goto L14; // [608] 656
L13: 

        /** pathopen.e:541								cache_converted[num_var] = append(cache_converted[num_var],full_path)*/
        _2 = (object)SEQ_PTR(_46cache_converted_50829);
        _26408 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
        RefDS(_full_path_51237);
        Append(&_26409, _26408, _full_path_51237);
        _26408 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_converted_50829);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_converted_50829 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50823);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26409;
        if( _1 != _26409 ){
            DeRef(_1);
        }
        _26409 = NOVALUE;
        goto L14; // [634] 656
L12: 

        /** pathopen.e:544							cache_converted[num_var] &= 0*/
        _2 = (object)SEQ_PTR(_46cache_converted_50829);
        _26410 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
        if (IS_SEQUENCE(_26410) && IS_ATOM(0LL)) {
            Append(&_26411, _26410, 0LL);
        }
        else if (IS_ATOM(_26410) && IS_SEQUENCE(0LL)) {
        }
        else {
            Concat((object_ptr)&_26411, _26410, 0LL);
            _26410 = NOVALUE;
        }
        _26410 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_converted_50829);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_converted_50829 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50823);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26411;
        if( _1 != _26411 ){
            DeRef(_1);
        }
        _26411 = NOVALUE;
L14: 

        /** pathopen.e:547					start_path = 0*/
        _start_path_51241 = 0LL;
        goto L10; // [662] 709
LD: 

        /** pathopen.e:549			elsif not start_path and (inc_path[p] != ' ' and inc_path[p] != '\t') then*/
        _26412 = (_start_path_51241 == 0);
        if (_26412 == 0) {
            goto L15; // [670] 708
        }
        _2 = (object)SEQ_PTR(_inc_path_51236);
        _26414 = (object)*(((s1_ptr)_2)->base + _p_51292);
        _26415 = (_26414 != 32LL);
        _26414 = NOVALUE;
        if (_26415 == 0) {
            DeRef(_26416);
            _26416 = 0;
            goto L16; // [682] 698
        }
        _2 = (object)SEQ_PTR(_inc_path_51236);
        _26417 = (object)*(((s1_ptr)_2)->base + _p_51292);
        _26418 = (_26417 != 9LL);
        _26417 = NOVALUE;
        _26416 = (_26418 != 0);
L16: 
        if (_26416 == 0)
        {
            _26416 = NOVALUE;
            goto L15; // [699] 708
        }
        else{
            _26416 = NOVALUE;
        }

        /** pathopen.e:550				start_path = p*/
        _start_path_51241 = _p_51292;
L15: 
L10: 

        /** pathopen.e:552		end for*/
        _p_51292 = _p_51292 + 1LL;
        goto LB; // [711] 317
LC: 
        ;
    }

    /** pathopen.e:554		cache_complete[num_var] = 1*/
    _2 = (object)SEQ_PTR(_46cache_complete_50830);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _46cache_complete_50830 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _46num_var_50823);
    *(intptr_t *)_2 = 1LL;

    /** pathopen.e:555		return -1*/
    DeRefDS(_file_name_51233);
    DeRefDSi(_env_51234);
    DeRefi(_inc_path_51236);
    DeRef(_full_path_51237);
    DeRef(_file_path_51238);
    DeRef(_strings_51239);
    DeRef(_26412);
    _26412 = NOVALUE;
    DeRef(_26396);
    _26396 = NOVALUE;
    DeRef(_26407);
    _26407 = NOVALUE;
    DeRef(_26418);
    _26418 = NOVALUE;
    DeRef(_26376);
    _26376 = NOVALUE;
    _26373 = NOVALUE;
    DeRef(_26415);
    _26415 = NOVALUE;
    DeRef(_26368);
    _26368 = NOVALUE;
    DeRef(_26355);
    _26355 = NOVALUE;
    return -1LL;
    ;
}


object _46Include_paths(object _add_converted_51356)
{
    object _status_51357 = NOVALUE;
    object _pos_51358 = NOVALUE;
    object _inc_path_51359 = NOVALUE;
    object _full_path_51360 = NOVALUE;
    object _start_path_51361 = NOVALUE;
    object _end_path_51362 = NOVALUE;
    object _eudir_path_51378 = NOVALUE;
    object _26479 = NOVALUE;
    object _26478 = NOVALUE;
    object _26477 = NOVALUE;
    object _26476 = NOVALUE;
    object _26475 = NOVALUE;
    object _26474 = NOVALUE;
    object _26473 = NOVALUE;
    object _26471 = NOVALUE;
    object _26470 = NOVALUE;
    object _26469 = NOVALUE;
    object _26468 = NOVALUE;
    object _26467 = NOVALUE;
    object _26466 = NOVALUE;
    object _26465 = NOVALUE;
    object _26464 = NOVALUE;
    object _26463 = NOVALUE;
    object _26462 = NOVALUE;
    object _26461 = NOVALUE;
    object _26460 = NOVALUE;
    object _26459 = NOVALUE;
    object _26458 = NOVALUE;
    object _26457 = NOVALUE;
    object _26456 = NOVALUE;
    object _26455 = NOVALUE;
    object _26454 = NOVALUE;
    object _26453 = NOVALUE;
    object _26452 = NOVALUE;
    object _26451 = NOVALUE;
    object _26449 = NOVALUE;
    object _26447 = NOVALUE;
    object _26446 = NOVALUE;
    object _26445 = NOVALUE;
    object _26444 = NOVALUE;
    object _26443 = NOVALUE;
    object _26440 = NOVALUE;
    object _26439 = NOVALUE;
    object _26437 = NOVALUE;
    object _26435 = NOVALUE;
    object _26433 = NOVALUE;
    object _26432 = NOVALUE;
    object _26430 = NOVALUE;
    object _26427 = NOVALUE;
    object _26425 = NOVALUE;
    object _26420 = NOVALUE;
    object _26419 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_add_converted_51356)) {
        _1 = (object)(DBL_PTR(_add_converted_51356)->dbl);
        DeRefDS(_add_converted_51356);
        _add_converted_51356 = _1;
    }

    /** pathopen.e:566		if length(include_Paths) then*/
    if (IS_SEQUENCE(_46include_Paths_51353)){
            _26419 = SEQ_PTR(_46include_Paths_51353)->length;
    }
    else {
        _26419 = 1;
    }
    if (_26419 == 0)
    {
        _26419 = NOVALUE;
        goto L1; // [10] 22
    }
    else{
        _26419 = NOVALUE;
    }

    /** pathopen.e:567			return include_Paths*/
    RefDS(_46include_Paths_51353);
    DeRefi(_inc_path_51359);
    DeRefi(_full_path_51360);
    DeRef(_eudir_path_51378);
    return _46include_Paths_51353;
L1: 

    /** pathopen.e:570		include_Paths = append(config_inc_paths, current_dir())*/
    _26420 = _15current_dir();
    Ref(_26420);
    Append(&_46include_Paths_51353, _46config_inc_paths_50832, _26420);
    DeRef(_26420);
    _26420 = NOVALUE;

    /** pathopen.e:571		num_var = find("EUINC", cache_vars)*/
    _46num_var_50823 = find_from(_26422, _46cache_vars_50824, 1LL);

    /** pathopen.e:572		inc_path = getenv("EUINC")*/
    DeRefi(_inc_path_51359);
    _inc_path_51359 = EGetEnv(_26422);

    /** pathopen.e:573		if atom(inc_path) then*/
    _26425 = IS_ATOM(_inc_path_51359);
    if (_26425 == 0)
    {
        _26425 = NOVALUE;
        goto L2; // [52] 61
    }
    else{
        _26425 = NOVALUE;
    }

    /** pathopen.e:574			inc_path = ""*/
    RefDS(_22218);
    DeRefi(_inc_path_51359);
    _inc_path_51359 = _22218;
L2: 

    /** pathopen.e:576		status = check_cache("EUINC", inc_path)*/
    RefDS(_26422);
    Ref(_inc_path_51359);
    _status_51357 = _46check_cache(_26422, _inc_path_51359);
    if (!IS_ATOM_INT(_status_51357)) {
        _1 = (object)(DBL_PTR(_status_51357)->dbl);
        DeRefDS(_status_51357);
        _status_51357 = _1;
    }

    /** pathopen.e:577		if length(inc_path) then*/
    if (IS_SEQUENCE(_inc_path_51359)){
            _26427 = SEQ_PTR(_inc_path_51359)->length;
    }
    else {
        _26427 = 1;
    }
    if (_26427 == 0)
    {
        _26427 = NOVALUE;
        goto L3; // [75] 87
    }
    else{
        _26427 = NOVALUE;
    }

    /** pathopen.e:578			inc_path = append(inc_path, PATH_SEPARATOR)*/
    Append(&_inc_path_51359, _inc_path_51359, 59LL);
L3: 

    /** pathopen.e:580		object eudir_path = get_eudir()*/
    _0 = _eudir_path_51378;
    _eudir_path_51378 = _28get_eudir();
    DeRef(_0);

    /** pathopen.e:581		if sequence(eudir_path) then*/
    _26430 = IS_SEQUENCE(_eudir_path_51378);
    if (_26430 == 0)
    {
        _26430 = NOVALUE;
        goto L4; // [97] 117
    }
    else{
        _26430 = NOVALUE;
    }

    /** pathopen.e:582			include_Paths = append(include_Paths, sprintf("%s/include", { eudir_path }))*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_eudir_path_51378);
    ((intptr_t*)_2)[1] = _eudir_path_51378;
    _26432 = MAKE_SEQ(_1);
    _26433 = EPrintf(-9999999, _26431, _26432);
    DeRefDS(_26432);
    _26432 = NOVALUE;
    RefDS(_26433);
    Append(&_46include_Paths_51353, _46include_Paths_51353, _26433);
    DeRefDS(_26433);
    _26433 = NOVALUE;
L4: 

    /** pathopen.e:585		if status then*/
    if (_status_51357 == 0)
    {
        goto L5; // [119] 161
    }
    else{
    }

    /** pathopen.e:587			if cache_complete[num_var] then*/
    _2 = (object)SEQ_PTR(_46cache_complete_50830);
    _26435 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
    if (_26435 == 0)
    {
        _26435 = NOVALUE;
        goto L6; // [132] 144
    }
    else{
        _26435 = NOVALUE;
    }

    /** pathopen.e:588				goto "cache done"*/
    goto G7;
L6: 

    /** pathopen.e:590			pos = cache_delims[num_var]+1*/
    _2 = (object)SEQ_PTR(_46cache_delims_50831);
    _26437 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
    _pos_51358 = _26437 + 1;
    _26437 = NOVALUE;
    goto L8; // [158] 167
L5: 

    /** pathopen.e:592	        pos = 1*/
    _pos_51358 = 1LL;
L8: 

    /** pathopen.e:594		start_path = 0*/
    _start_path_51361 = 0LL;

    /** pathopen.e:595		for p = pos to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_51359)){
            _26439 = SEQ_PTR(_inc_path_51359)->length;
    }
    else {
        _26439 = 1;
    }
    {
        object _p_51395;
        _p_51395 = _pos_51358;
L9: 
        if (_p_51395 > _26439){
            goto LA; // [179] 456
        }

        /** pathopen.e:596			if inc_path[p] = PATH_SEPARATOR then*/
        _2 = (object)SEQ_PTR(_inc_path_51359);
        _26440 = (object)*(((s1_ptr)_2)->base + _p_51395);
        if (_26440 != 59LL)
        goto LB; // [194] 405

        /** pathopen.e:598				cache_delims[num_var] = p*/
        _2 = (object)SEQ_PTR(_46cache_delims_50831);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_delims_50831 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50823);
        *(intptr_t *)_2 = _p_51395;

        /** pathopen.e:600				end_path = p-1*/
        _end_path_51362 = _p_51395 - 1LL;

        /** pathopen.e:601				while end_path >= start_path and find(inc_path[end_path]," \t" & SLASH_CHARS) do*/
LC: 
        _26443 = (_end_path_51362 >= _start_path_51361);
        if (_26443 == 0) {
            goto LD; // [223] 257
        }
        _2 = (object)SEQ_PTR(_inc_path_51359);
        _26445 = (object)*(((s1_ptr)_2)->base + _end_path_51362);
        Concat((object_ptr)&_26446, _26379, _44SLASH_CHARS_20736);
        _26447 = find_from(_26445, _26446, 1LL);
        _26445 = NOVALUE;
        DeRefDS(_26446);
        _26446 = NOVALUE;
        if (_26447 == 0)
        {
            _26447 = NOVALUE;
            goto LD; // [243] 257
        }
        else{
            _26447 = NOVALUE;
        }

        /** pathopen.e:602					end_path -= 1*/
        _end_path_51362 = _end_path_51362 - 1LL;

        /** pathopen.e:603				end while*/
        goto LC; // [254] 219
LD: 

        /** pathopen.e:605				if start_path and end_path then*/
        if (_start_path_51361 == 0) {
            goto LE; // [259] 449
        }
        if (_end_path_51362 == 0)
        {
            goto LE; // [264] 449
        }
        else{
        }

        /** pathopen.e:606					full_path = inc_path[start_path..end_path]*/
        rhs_slice_target = (object_ptr)&_full_path_51360;
        RHS_Slice(_inc_path_51359, _start_path_51361, _end_path_51362);

        /** pathopen.e:607					cache_substrings[num_var] = append(cache_substrings[num_var],full_path)*/
        _2 = (object)SEQ_PTR(_46cache_substrings_50826);
        _26451 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
        RefDS(_full_path_51360);
        Append(&_26452, _26451, _full_path_51360);
        _26451 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_substrings_50826);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_substrings_50826 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50823);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26452;
        if( _1 != _26452 ){
            DeRefDS(_1);
        }
        _26452 = NOVALUE;

        /** pathopen.e:608					cache_starts[num_var] &= start_path*/
        _2 = (object)SEQ_PTR(_46cache_starts_50827);
        _26453 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
        if (IS_SEQUENCE(_26453) && IS_ATOM(_start_path_51361)) {
            Append(&_26454, _26453, _start_path_51361);
        }
        else if (IS_ATOM(_26453) && IS_SEQUENCE(_start_path_51361)) {
        }
        else {
            Concat((object_ptr)&_26454, _26453, _start_path_51361);
            _26453 = NOVALUE;
        }
        _26453 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_starts_50827);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_starts_50827 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50823);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26454;
        if( _1 != _26454 ){
            DeRef(_1);
        }
        _26454 = NOVALUE;

        /** pathopen.e:609					cache_ends[num_var] &= end_path*/
        _2 = (object)SEQ_PTR(_46cache_ends_50828);
        _26455 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
        if (IS_SEQUENCE(_26455) && IS_ATOM(_end_path_51362)) {
            Append(&_26456, _26455, _end_path_51362);
        }
        else if (IS_ATOM(_26455) && IS_SEQUENCE(_end_path_51362)) {
        }
        else {
            Concat((object_ptr)&_26456, _26455, _end_path_51362);
            _26455 = NOVALUE;
        }
        _26455 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_ends_50828);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_ends_50828 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50823);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26456;
        if( _1 != _26456 ){
            DeRef(_1);
        }
        _26456 = NOVALUE;

        /** pathopen.e:610					ifdef WINDOWS then*/

        /** pathopen.e:611						if find(1, full_path>=128) then*/
        _26457 = binary_op(GREATEREQ, _full_path_51360, 128LL);
        _26458 = find_from(1LL, _26457, 1LL);
        DeRefDS(_26457);
        _26457 = NOVALUE;
        if (_26458 == 0)
        {
            _26458 = NOVALUE;
            goto LF; // [345] 377
        }
        else{
            _26458 = NOVALUE;
        }

        /** pathopen.e:614							cache_converted[num_var] = append(cache_converted[num_var], */
        _2 = (object)SEQ_PTR(_46cache_converted_50829);
        _26459 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
        RefDS(_full_path_51360);
        _26460 = _46convert_from_OEM(_full_path_51360);
        Ref(_26460);
        Append(&_26461, _26459, _26460);
        _26459 = NOVALUE;
        DeRef(_26460);
        _26460 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_converted_50829);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_converted_50829 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50823);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26461;
        if( _1 != _26461 ){
            DeRef(_1);
        }
        _26461 = NOVALUE;
        goto L10; // [374] 396
LF: 

        /** pathopen.e:617							cache_converted[num_var] &= 0*/
        _2 = (object)SEQ_PTR(_46cache_converted_50829);
        _26462 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
        if (IS_SEQUENCE(_26462) && IS_ATOM(0LL)) {
            Append(&_26463, _26462, 0LL);
        }
        else if (IS_ATOM(_26462) && IS_SEQUENCE(0LL)) {
        }
        else {
            Concat((object_ptr)&_26463, _26462, 0LL);
            _26462 = NOVALUE;
        }
        _26462 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_converted_50829);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_converted_50829 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50823);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26463;
        if( _1 != _26463 ){
            DeRef(_1);
        }
        _26463 = NOVALUE;
L10: 

        /** pathopen.e:620					start_path = 0*/
        _start_path_51361 = 0LL;
        goto LE; // [402] 449
LB: 

        /** pathopen.e:622			elsif not start_path and (inc_path[p] != ' ' and inc_path[p] != '\t') then*/
        _26464 = (_start_path_51361 == 0);
        if (_26464 == 0) {
            goto L11; // [410] 448
        }
        _2 = (object)SEQ_PTR(_inc_path_51359);
        _26466 = (object)*(((s1_ptr)_2)->base + _p_51395);
        _26467 = (_26466 != 32LL);
        _26466 = NOVALUE;
        if (_26467 == 0) {
            DeRef(_26468);
            _26468 = 0;
            goto L12; // [422] 438
        }
        _2 = (object)SEQ_PTR(_inc_path_51359);
        _26469 = (object)*(((s1_ptr)_2)->base + _p_51395);
        _26470 = (_26469 != 9LL);
        _26469 = NOVALUE;
        _26468 = (_26470 != 0);
L12: 
        if (_26468 == 0)
        {
            _26468 = NOVALUE;
            goto L11; // [439] 448
        }
        else{
            _26468 = NOVALUE;
        }

        /** pathopen.e:623				start_path = p*/
        _start_path_51361 = _p_51395;
L11: 
LE: 

        /** pathopen.e:625		end for*/
        _p_51395 = _p_51395 + 1LL;
        goto L9; // [451] 186
LA: 
        ;
    }

    /** pathopen.e:627	label "cache done"*/
G7:

    /** pathopen.e:628		include_Paths &= cache_substrings[num_var]*/
    _2 = (object)SEQ_PTR(_46cache_substrings_50826);
    _26471 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
    Concat((object_ptr)&_46include_Paths_51353, _46include_Paths_51353, _26471);
    _26471 = NOVALUE;

    /** pathopen.e:629		cache_complete[num_var] = 1*/
    _2 = (object)SEQ_PTR(_46cache_complete_50830);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _46cache_complete_50830 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _46num_var_50823);
    *(intptr_t *)_2 = 1LL;

    /** pathopen.e:631		ifdef WINDOWS then*/

    /** pathopen.e:632			if add_converted then*/
    if (_add_converted_51356 == 0)
    {
        goto L13; // [490] 562
    }
    else{
    }

    /** pathopen.e:633		    	for i=1 to length(cache_converted[num_var]) do*/
    _2 = (object)SEQ_PTR(_46cache_converted_50829);
    _26473 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
    if (IS_SEQUENCE(_26473)){
            _26474 = SEQ_PTR(_26473)->length;
    }
    else {
        _26474 = 1;
    }
    _26473 = NOVALUE;
    {
        object _i_51440;
        _i_51440 = 1LL;
L14: 
        if (_i_51440 > _26474){
            goto L15; // [506] 561
        }

        /** pathopen.e:634		        	if sequence(cache_converted[num_var][i]) then*/
        _2 = (object)SEQ_PTR(_46cache_converted_50829);
        _26475 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
        _2 = (object)SEQ_PTR(_26475);
        _26476 = (object)*(((s1_ptr)_2)->base + _i_51440);
        _26475 = NOVALUE;
        _26477 = IS_SEQUENCE(_26476);
        _26476 = NOVALUE;
        if (_26477 == 0)
        {
            _26477 = NOVALUE;
            goto L16; // [530] 554
        }
        else{
            _26477 = NOVALUE;
        }

        /** pathopen.e:635			        	include_Paths = append(include_Paths, cache_converted[num_var][i])*/
        _2 = (object)SEQ_PTR(_46cache_converted_50829);
        _26478 = (object)*(((s1_ptr)_2)->base + _46num_var_50823);
        _2 = (object)SEQ_PTR(_26478);
        _26479 = (object)*(((s1_ptr)_2)->base + _i_51440);
        _26478 = NOVALUE;
        Ref(_26479);
        Append(&_46include_Paths_51353, _46include_Paths_51353, _26479);
        _26479 = NOVALUE;
L16: 

        /** pathopen.e:637				end for*/
        _i_51440 = _i_51440 + 1LL;
        goto L14; // [556] 513
L15: 
        ;
    }
L13: 

    /** pathopen.e:640		return include_Paths*/
    RefDS(_46include_Paths_51353);
    DeRefi(_inc_path_51359);
    DeRefi(_full_path_51360);
    DeRef(_eudir_path_51378);
    DeRef(_26464);
    _26464 = NOVALUE;
    _26440 = NOVALUE;
    _26473 = NOVALUE;
    DeRef(_26467);
    _26467 = NOVALUE;
    DeRef(_26443);
    _26443 = NOVALUE;
    DeRef(_26470);
    _26470 = NOVALUE;
    return _46include_Paths_51353;
    ;
}


object _46e_path_find(object _name_51452)
{
    object _scan_result_51453 = NOVALUE;
    object _26489 = NOVALUE;
    object _26488 = NOVALUE;
    object _26487 = NOVALUE;
    object _26484 = NOVALUE;
    object _26483 = NOVALUE;
    object _26482 = NOVALUE;
    object _26481 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:656		if file_exists(name) then*/
    RefDS(_name_51452);
    _26481 = _15file_exists(_name_51452);
    if (_26481 == 0) {
        DeRef(_26481);
        _26481 = NOVALUE;
        goto L1; // [9] 19
    }
    else {
        if (!IS_ATOM_INT(_26481) && DBL_PTR(_26481)->dbl == 0.0){
            DeRef(_26481);
            _26481 = NOVALUE;
            goto L1; // [9] 19
        }
        DeRef(_26481);
        _26481 = NOVALUE;
    }
    DeRef(_26481);
    _26481 = NOVALUE;

    /** pathopen.e:657			return name*/
    DeRef(_scan_result_51453);
    return _name_51452;
L1: 

    /** pathopen.e:661		for i = 1 to length(SLASH_CHARS) do*/
    if (IS_SEQUENCE(_44SLASH_CHARS_20736)){
            _26482 = SEQ_PTR(_44SLASH_CHARS_20736)->length;
    }
    else {
        _26482 = 1;
    }
    {
        object _i_51458;
        _i_51458 = 1LL;
L2: 
        if (_i_51458 > _26482){
            goto L3; // [26] 63
        }

        /** pathopen.e:662			if find(SLASH_CHARS[i], name) then*/
        _2 = (object)SEQ_PTR(_44SLASH_CHARS_20736);
        _26483 = (object)*(((s1_ptr)_2)->base + _i_51458);
        _26484 = find_from(_26483, _name_51452, 1LL);
        _26483 = NOVALUE;
        if (_26484 == 0)
        {
            _26484 = NOVALUE;
            goto L4; // [46] 56
        }
        else{
            _26484 = NOVALUE;
        }

        /** pathopen.e:663				return -1*/
        DeRefDS(_name_51452);
        DeRef(_scan_result_51453);
        return -1LL;
L4: 

        /** pathopen.e:665		end for*/
        _i_51458 = _i_51458 + 1LL;
        goto L2; // [58] 33
L3: 
        ;
    }

    /** pathopen.e:667		scan_result = ScanPath(name, "PATH", 0)*/
    RefDS(_name_51452);
    RefDS(_26485);
    _0 = _scan_result_51453;
    _scan_result_51453 = _46ScanPath(_name_51452, _26485, 0LL);
    DeRef(_0);

    /** pathopen.e:668		if sequence(scan_result) then*/
    _26487 = IS_SEQUENCE(_scan_result_51453);
    if (_26487 == 0)
    {
        _26487 = NOVALUE;
        goto L5; // [76] 98
    }
    else{
        _26487 = NOVALUE;
    }

    /** pathopen.e:669			close(scan_result[2])*/
    _2 = (object)SEQ_PTR(_scan_result_51453);
    _26488 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_26488))
    EClose(_26488);
    else
    EClose((object)DBL_PTR(_26488)->dbl);
    _26488 = NOVALUE;

    /** pathopen.e:670			return scan_result[1]*/
    _2 = (object)SEQ_PTR(_scan_result_51453);
    _26489 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_26489);
    DeRefDS(_name_51452);
    DeRef(_scan_result_51453);
    return _26489;
L5: 

    /** pathopen.e:673		return -1*/
    DeRefDS(_name_51452);
    DeRef(_scan_result_51453);
    _26489 = NOVALUE;
    return -1LL;
    ;
}



// 0xCF44004D
