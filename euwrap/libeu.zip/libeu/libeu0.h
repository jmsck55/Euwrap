// Copyright (c) James J. Cook

#pragma once

#ifndef USE_PRECOMPILED_HEADERS
#ifdef WIN32
#include <direct.h>
#include <windows.h>
#else
#include <sys/types.h>
#include <dlfcn.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#endif

#ifdef WIN32
	#define libname "libeu0.dll"
	#define lib_type HINSTANCE
	#define open_dll(name) LoadLibrary(TEXT(name))
	#define close_dll(lib) FreeLibrary(lib)
	#define define_c_func(lib,name) GetProcAddress(lib,name);
	//#define reset_error_dll() // nothing
	//#define error_dll() GetLastError()

	typedef void (WINAPI *one_void_ret_void)(void);
	typedef int (WINAPI *one_void_ret_int)(int);
	typedef void (WINAPI *one_int_ret_void)(int);
	typedef int (WINAPI *one_int_ret_int)(int);
	typedef int (WINAPI *two_int_ret_int)(int,int);
#else
	#define libname "libeu0.so"
	#define lib_type void *
	#define open_dll(name) dlopen(name, RTLD_LAZY)
	#define close_dll(lib) dlclose(lib)
	#define define_c_func(lib,name) dlsym(lib,name);
	//#define reset_error_dll() dlerror()
#endif

	using namespace std;

	lib_type lib_handle;

    // Where retType is the pointer to a return type of the function
    // This return type can be int, float, double, etc or a struct or class.

	typedef int* func_t;

    // load the library -------------------------------------------------

	lib_handle = open_dll(libname);
	if (!lib_handle) {
		printf("Cannot load library: %s\n", libname);
		//exit(1);
	}


    // load the symbols -------------------------------------------------

	one_void_ret_void* init = (one_void_ret_void*) define_c_func(lib_handle, "init");
if (!init) {
	printf("Cannot load function.\n");
}
	one_void_ret_int* get_high_address = (one_void_ret_int*) define_c_func(lib_handle, "get_high_address");
if (!get_high_address) {
	printf("Cannot load function.\n");
}
	two_int_ret_int* register_address = (two_int_ret_int*) define_c_func(lib_handle, "register_address");
if (!register_address) {
	printf("Cannot load function.\n");
}
	one_int_ret_void* free_data_id = (one_int_ret_void*) define_c_func(lib_handle, "free_data_id");
if (!free_data_id) {
	printf("Cannot load function.\n");
}
	one_int_ret_int* get_low_address = (one_int_ret_int*) define_c_func(lib_handle, "get_low_address");
if (!get_low_address) {
	printf("Cannot load function.\n");
}


/*
extern void init(void);
extern int get_high_address(void);
extern int register_address(int,int);
extern void free_data_id(int);
extern int get_low_address(int);
*/

/*
#ifdef WIN32
    func_t* fn_handle = (func_t*) GetProcAddress(lib_handle, "superfunctionx");
    if (!fn_handle) {
        cerr << "Cannot load symbol superfunctionx: " << GetLastError() << endl;
    }
#else
    // reset errors
    dlerror();

    // load the symbols (handle to function "superfunctionx")
    func_t* fn_handle= (func_t*) dlsym(lib_handle, "superfunctionx");
    const char* dlsym_error = dlerror();
    if (dlsym_error) {
        cerr << "Cannot load symbol superfunctionx: " << dlsym_error << endl;
    }
#endif
*/


    // unload the library -----------------------------------------------

void close_lib(void) {
close_dll(lib_handle);
}



// end of file.
