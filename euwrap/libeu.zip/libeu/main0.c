// Copyright (c) 2020 James J. Cook

#include <stdio.h>
#include <stdlib.h>

#include "libeu0.h"

int main() {
    int id1, low, hi;
    
    init();
    
    id1 = register_address(2,3);
    low = get_low_address(id1);
    hi = get_high_address();
    
    free_data_id(id1);
    close_lib();

    //printf("done.\n");
    system("pause");
    return 0;
}

// end of file.
