// Copyright (c) 2020 James J. Cook

// example_libeu0.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "libeu0.h"


int main()
{
	int id1, low, hi;

	init_lib();

	init();

	id1 = register_address(2, 3);
	low = get_low_address(id1);
	hi = get_high_address();

	free_data_id(id1);
	close_lib();

	printf("done.\n");
	system("pause");
	return 0;
}

