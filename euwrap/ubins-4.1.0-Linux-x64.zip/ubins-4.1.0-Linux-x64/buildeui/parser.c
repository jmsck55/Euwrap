// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _43EndLineTable()
{
    object _0, _1, _2;
    

    /** parser.e:120		LineTable = append(LineTable, -2)*/
    Append(&_12LineTable_20316, _12LineTable_20316, -2LL);

    /** parser.e:121	end procedure*/
    return;
    ;
}


void _43CreateTopLevel()
{
    object _27876 = NOVALUE;
    object _27874 = NOVALUE;
    object _27872 = NOVALUE;
    object _27870 = NOVALUE;
    object _27868 = NOVALUE;
    object _27866 = NOVALUE;
    object _27864 = NOVALUE;
    object _27862 = NOVALUE;
    object _27860 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:125		SymTab[TopLevelSub][S_NUM_ARGS] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _27860 = NOVALUE;

    /** parser.e:126		SymTab[TopLevelSub][S_TEMPS] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_TEMPS_19909))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TEMPS_19909)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_TEMPS_19909);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _27862 = NOVALUE;

    /** parser.e:127		SymTab[TopLevelSub][S_CODE] = {}*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    RefDS(_22024);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_19876))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22024;
    DeRef(_1);
    _27864 = NOVALUE;

    /** parser.e:128		SymTab[TopLevelSub][S_LINETAB] = {}*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    RefDS(_22024);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_LINETAB_19899))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_LINETAB_19899)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_LINETAB_19899);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22024;
    DeRef(_1);
    _27866 = NOVALUE;

    /** parser.e:129		SymTab[TopLevelSub][S_FIRSTLINE] = 1*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_FIRSTLINE_19904))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FIRSTLINE_19904)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_FIRSTLINE_19904);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _27868 = NOVALUE;

    /** parser.e:130		SymTab[TopLevelSub][S_REFLIST] = {}*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    RefDS(_22024);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 24LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22024;
    DeRef(_1);
    _27870 = NOVALUE;

    /** parser.e:131		SymTab[TopLevelSub][S_NREFS] = 1*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _27872 = NOVALUE;

    /** parser.e:132		SymTab[TopLevelSub][S_RESIDENT_TASK] = 1*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _27874 = NOVALUE;

    /** parser.e:133		SymTab[TopLevelSub][S_SAVED_PRIVATES] = {}*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    RefDS(_22024);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 26LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22024;
    DeRef(_1);
    _27876 = NOVALUE;

    /** parser.e:135		Start_block( PROC, TopLevelSub )*/
    _64Start_block(27LL, _12TopLevelSub_20233);

    /** parser.e:136	end procedure*/
    return;
    ;
}


void _43CheckForUndefinedGotoLabels()
{
    object _27890 = NOVALUE;
    object _27889 = NOVALUE;
    object _27886 = NOVALUE;
    object _27884 = NOVALUE;
    object _27882 = NOVALUE;
    object _27880 = NOVALUE;
    object _27879 = NOVALUE;
    object _27878 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:139		for i = 1 to length(goto_delay) do*/
    if (IS_SEQUENCE(_12goto_delay_20337)){
            _27878 = SEQ_PTR(_12goto_delay_20337)->length;
    }
    else {
        _27878 = 1;
    }
    {
        object _i_55119;
        _i_55119 = 1LL;
L1: 
        if (_i_55119 > _27878){
            goto L2; // [8] 106
        }

        /** parser.e:140			if not equal(goto_delay[i],"") then*/
        _2 = (object)SEQ_PTR(_12goto_delay_20337);
        _27879 = (object)*(((s1_ptr)_2)->base + _i_55119);
        if (_27879 == _22024)
        _27880 = 1;
        else if (IS_ATOM_INT(_27879) && IS_ATOM_INT(_22024))
        _27880 = 0;
        else
        _27880 = (compare(_27879, _22024) == 0);
        _27879 = NOVALUE;
        if (_27880 != 0)
        goto L3; // [27] 99
        _27880 = NOVALUE;

        /** parser.e:141				line_number = goto_line[i][1] -- tell compiler the correct line number*/
        _2 = (object)SEQ_PTR(_43goto_line_55025);
        _27882 = (object)*(((s1_ptr)_2)->base + _i_55119);
        _2 = (object)SEQ_PTR(_27882);
        _12line_number_20227 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (!IS_ATOM_INT(_12line_number_20227)){
            _12line_number_20227 = (object)DBL_PTR(_12line_number_20227)->dbl;
        }
        _27882 = NOVALUE;

        /** parser.e:142				gline_number = goto_line[i][1] -- tell compiler the correct line number*/
        _2 = (object)SEQ_PTR(_43goto_line_55025);
        _27884 = (object)*(((s1_ptr)_2)->base + _i_55119);
        _2 = (object)SEQ_PTR(_27884);
        _12gline_number_20231 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (!IS_ATOM_INT(_12gline_number_20231)){
            _12gline_number_20231 = (object)DBL_PTR(_12gline_number_20231)->dbl;
        }
        _27884 = NOVALUE;

        /** parser.e:143				ThisLine = goto_line[i][2] -- tell compiler the correct line number*/
        _2 = (object)SEQ_PTR(_43goto_line_55025);
        _27886 = (object)*(((s1_ptr)_2)->base + _i_55119);
        DeRef(_49ThisLine_49312);
        _2 = (object)SEQ_PTR(_27886);
        _49ThisLine_49312 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_49ThisLine_49312);
        _27886 = NOVALUE;

        /** parser.e:144				bp = length(ThisLine)*/
        if (IS_SEQUENCE(_49ThisLine_49312)){
                _49bp_49316 = SEQ_PTR(_49ThisLine_49312)->length;
        }
        else {
            _49bp_49316 = 1;
        }

        /** parser.e:145					CompileErr(UNKNOWN_LABEL_1, {goto_delay[i]})*/
        _2 = (object)SEQ_PTR(_12goto_delay_20337);
        _27889 = (object)*(((s1_ptr)_2)->base + _i_55119);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_27889);
        ((intptr_t*)_2)[1] = _27889;
        _27890 = MAKE_SEQ(_1);
        _27889 = NOVALUE;
        _49CompileErr(156LL, _27890, 0LL);
        _27890 = NOVALUE;
L3: 

        /** parser.e:147		end for*/
        _i_55119 = _i_55119 + 1LL;
        goto L1; // [101] 15
L2: 
        ;
    }

    /** parser.e:148	end procedure*/
    return;
    ;
}


void _43PushGoto()
{
    object _new_1__tmp_at88_55154 = NOVALUE;
    object _new_inlined_new_at_88_55153 = NOVALUE;
    object _27891 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:151		goto_stack = append(goto_stack, {goto_addr, goto_list, goto_labels, goto_delay, goto_line, goto_ref, label_block, goto_init })*/
    _1 = NewS1(8);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_43goto_addr_55027);
    ((intptr_t*)_2)[1] = _43goto_addr_55027;
    RefDS(_12goto_list_20338);
    ((intptr_t*)_2)[2] = _12goto_list_20338;
    RefDS(_43goto_labels_55026);
    ((intptr_t*)_2)[3] = _43goto_labels_55026;
    RefDS(_12goto_delay_20337);
    ((intptr_t*)_2)[4] = _12goto_delay_20337;
    RefDS(_43goto_line_55025);
    ((intptr_t*)_2)[5] = _43goto_line_55025;
    RefDS(_43goto_ref_55029);
    ((intptr_t*)_2)[6] = _43goto_ref_55029;
    RefDS(_43label_block_55030);
    ((intptr_t*)_2)[7] = _43label_block_55030;
    Ref(_43goto_init_55032);
    ((intptr_t*)_2)[8] = _43goto_init_55032;
    _27891 = MAKE_SEQ(_1);
    RefDS(_27891);
    Append(&_43goto_stack_55028, _43goto_stack_55028, _27891);
    DeRefDS(_27891);
    _27891 = NOVALUE;

    /** parser.e:152		goto_addr = {}*/
    RefDS(_22024);
    DeRefDS(_43goto_addr_55027);
    _43goto_addr_55027 = _22024;

    /** parser.e:153		goto_list = {}*/
    RefDS(_22024);
    DeRefDS(_12goto_list_20338);
    _12goto_list_20338 = _22024;

    /** parser.e:154		goto_labels = {}*/
    RefDS(_22024);
    DeRefDS(_43goto_labels_55026);
    _43goto_labels_55026 = _22024;

    /** parser.e:155		goto_delay = {}*/
    RefDS(_22024);
    DeRefDS(_12goto_delay_20337);
    _12goto_delay_20337 = _22024;

    /** parser.e:156		goto_line = {}*/
    RefDS(_22024);
    DeRefDS(_43goto_line_55025);
    _43goto_line_55025 = _22024;

    /** parser.e:157		goto_ref = {}*/
    RefDS(_22024);
    DeRefDS(_43goto_ref_55029);
    _43goto_ref_55029 = _22024;

    /** parser.e:158		label_block = {}*/
    RefDS(_22024);
    DeRefDS(_43label_block_55030);
    _43label_block_55030 = _22024;

    /** parser.e:159		goto_init = map:new()*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at88_55154;
    _new_1__tmp_at88_55154 = _34new_map_seq(8LL);
    DeRef(_0);
    Ref(_new_1__tmp_at88_55154);
    _0 = _35malloc(_new_1__tmp_at88_55154, 1LL);
    DeRef(_43goto_init_55032);
    _43goto_init_55032 = _0;
    DeRef(_new_1__tmp_at88_55154);
    _new_1__tmp_at88_55154 = NOVALUE;

    /** parser.e:160	end procedure*/
    return;
    ;
}


void _43PopGoto()
{
    object _27917 = NOVALUE;
    object _27915 = NOVALUE;
    object _27914 = NOVALUE;
    object _27912 = NOVALUE;
    object _27911 = NOVALUE;
    object _27909 = NOVALUE;
    object _27908 = NOVALUE;
    object _27906 = NOVALUE;
    object _27905 = NOVALUE;
    object _27903 = NOVALUE;
    object _27902 = NOVALUE;
    object _27900 = NOVALUE;
    object _27899 = NOVALUE;
    object _27897 = NOVALUE;
    object _27896 = NOVALUE;
    object _27894 = NOVALUE;
    object _27893 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:163		CheckForUndefinedGotoLabels()*/
    _43CheckForUndefinedGotoLabels();

    /** parser.e:164		goto_addr   = goto_stack[$][1]*/
    if (IS_SEQUENCE(_43goto_stack_55028)){
            _27893 = SEQ_PTR(_43goto_stack_55028)->length;
    }
    else {
        _27893 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_55028);
    _27894 = (object)*(((s1_ptr)_2)->base + _27893);
    DeRef(_43goto_addr_55027);
    _2 = (object)SEQ_PTR(_27894);
    _43goto_addr_55027 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_43goto_addr_55027);
    _27894 = NOVALUE;

    /** parser.e:165		goto_list   = goto_stack[$][2]*/
    if (IS_SEQUENCE(_43goto_stack_55028)){
            _27896 = SEQ_PTR(_43goto_stack_55028)->length;
    }
    else {
        _27896 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_55028);
    _27897 = (object)*(((s1_ptr)_2)->base + _27896);
    DeRef(_12goto_list_20338);
    _2 = (object)SEQ_PTR(_27897);
    _12goto_list_20338 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_12goto_list_20338);
    _27897 = NOVALUE;

    /** parser.e:166		goto_labels = goto_stack[$][3]*/
    if (IS_SEQUENCE(_43goto_stack_55028)){
            _27899 = SEQ_PTR(_43goto_stack_55028)->length;
    }
    else {
        _27899 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_55028);
    _27900 = (object)*(((s1_ptr)_2)->base + _27899);
    DeRef(_43goto_labels_55026);
    _2 = (object)SEQ_PTR(_27900);
    _43goto_labels_55026 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_43goto_labels_55026);
    _27900 = NOVALUE;

    /** parser.e:167		goto_delay  = goto_stack[$][4]*/
    if (IS_SEQUENCE(_43goto_stack_55028)){
            _27902 = SEQ_PTR(_43goto_stack_55028)->length;
    }
    else {
        _27902 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_55028);
    _27903 = (object)*(((s1_ptr)_2)->base + _27902);
    DeRef(_12goto_delay_20337);
    _2 = (object)SEQ_PTR(_27903);
    _12goto_delay_20337 = (object)*(((s1_ptr)_2)->base + 4LL);
    Ref(_12goto_delay_20337);
    _27903 = NOVALUE;

    /** parser.e:168		goto_line   = goto_stack[$][5]*/
    if (IS_SEQUENCE(_43goto_stack_55028)){
            _27905 = SEQ_PTR(_43goto_stack_55028)->length;
    }
    else {
        _27905 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_55028);
    _27906 = (object)*(((s1_ptr)_2)->base + _27905);
    DeRef(_43goto_line_55025);
    _2 = (object)SEQ_PTR(_27906);
    _43goto_line_55025 = (object)*(((s1_ptr)_2)->base + 5LL);
    Ref(_43goto_line_55025);
    _27906 = NOVALUE;

    /** parser.e:169		goto_ref    = goto_stack[$][6]*/
    if (IS_SEQUENCE(_43goto_stack_55028)){
            _27908 = SEQ_PTR(_43goto_stack_55028)->length;
    }
    else {
        _27908 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_55028);
    _27909 = (object)*(((s1_ptr)_2)->base + _27908);
    DeRef(_43goto_ref_55029);
    _2 = (object)SEQ_PTR(_27909);
    _43goto_ref_55029 = (object)*(((s1_ptr)_2)->base + 6LL);
    Ref(_43goto_ref_55029);
    _27909 = NOVALUE;

    /** parser.e:170		label_block = goto_stack[$][7]*/
    if (IS_SEQUENCE(_43goto_stack_55028)){
            _27911 = SEQ_PTR(_43goto_stack_55028)->length;
    }
    else {
        _27911 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_55028);
    _27912 = (object)*(((s1_ptr)_2)->base + _27911);
    DeRef(_43label_block_55030);
    _2 = (object)SEQ_PTR(_27912);
    _43label_block_55030 = (object)*(((s1_ptr)_2)->base + 7LL);
    Ref(_43label_block_55030);
    _27912 = NOVALUE;

    /** parser.e:171		goto_init   = goto_stack[$][8]*/
    if (IS_SEQUENCE(_43goto_stack_55028)){
            _27914 = SEQ_PTR(_43goto_stack_55028)->length;
    }
    else {
        _27914 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_55028);
    _27915 = (object)*(((s1_ptr)_2)->base + _27914);
    DeRef(_43goto_init_55032);
    _2 = (object)SEQ_PTR(_27915);
    _43goto_init_55032 = (object)*(((s1_ptr)_2)->base + 8LL);
    Ref(_43goto_init_55032);
    _27915 = NOVALUE;

    /** parser.e:173		goto_stack = remove( goto_stack, length( goto_stack ) )*/
    if (IS_SEQUENCE(_43goto_stack_55028)){
            _27917 = SEQ_PTR(_43goto_stack_55028)->length;
    }
    else {
        _27917 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_43goto_stack_55028);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_27917)) ? _27917 : (object)(DBL_PTR(_27917)->dbl);
        int stop = (IS_ATOM_INT(_27917)) ? _27917 : (object)(DBL_PTR(_27917)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_43goto_stack_55028), start, &_43goto_stack_55028 );
            }
            else Tail(SEQ_PTR(_43goto_stack_55028), stop+1, &_43goto_stack_55028);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_43goto_stack_55028), start, &_43goto_stack_55028);
        }
        else {
            assign_slice_seq = &assign_space;
            _43goto_stack_55028 = Remove_elements(start, stop, (SEQ_PTR(_43goto_stack_55028)->ref == 1));
        }
    }
    _27917 = NOVALUE;
    _27917 = NOVALUE;

    /** parser.e:175	end procedure*/
    return;
    ;
}


void _43EnterTopLevel(object _end_line_table_55187)
{
    object _27936 = NOVALUE;
    object _27935 = NOVALUE;
    object _27933 = NOVALUE;
    object _27932 = NOVALUE;
    object _27930 = NOVALUE;
    object _27928 = NOVALUE;
    object _27926 = NOVALUE;
    object _27924 = NOVALUE;
    object _27923 = NOVALUE;
    object _27921 = NOVALUE;
    object _27919 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:179		if CurrentSub then*/
    if (_12CurrentSub_20234 == 0)
    {
        goto L1; // [7] 59
    }
    else{
    }

    /** parser.e:180			if end_line_table then*/
    if (_end_line_table_55187 == 0)
    {
        goto L2; // [12] 58
    }
    else{
    }

    /** parser.e:181				EndLineTable()*/
    _43EndLineTable();

    /** parser.e:182				SymTab[CurrentSub][S_LINETAB] = LineTable*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12CurrentSub_20234 + ((s1_ptr)_2)->base);
    RefDS(_12LineTable_20316);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_LINETAB_19899))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_LINETAB_19899)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_LINETAB_19899);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12LineTable_20316;
    DeRef(_1);
    _27919 = NOVALUE;

    /** parser.e:183				SymTab[CurrentSub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12CurrentSub_20234 + ((s1_ptr)_2)->base);
    RefDS(_12Code_20315);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_19876))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12Code_20315;
    DeRef(_1);
    _27921 = NOVALUE;
L2: 
L1: 

    /** parser.e:186		if length(goto_stack) then*/
    if (IS_SEQUENCE(_43goto_stack_55028)){
            _27923 = SEQ_PTR(_43goto_stack_55028)->length;
    }
    else {
        _27923 = 1;
    }
    if (_27923 == 0)
    {
        _27923 = NOVALUE;
        goto L3; // [66] 74
    }
    else{
        _27923 = NOVALUE;
    }

    /** parser.e:187			PopGoto()*/
    _43PopGoto();
L3: 

    /** parser.e:189		LineTable = SymTab[TopLevelSub][S_LINETAB]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27924 = (object)*(((s1_ptr)_2)->base + _12TopLevelSub_20233);
    DeRef(_12LineTable_20316);
    _2 = (object)SEQ_PTR(_27924);
    if (!IS_ATOM_INT(_12S_LINETAB_19899)){
        _12LineTable_20316 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_LINETAB_19899)->dbl));
    }
    else{
        _12LineTable_20316 = (object)*(((s1_ptr)_2)->base + _12S_LINETAB_19899);
    }
    Ref(_12LineTable_20316);
    _27924 = NOVALUE;

    /** parser.e:190		Code = SymTab[TopLevelSub][S_CODE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27926 = (object)*(((s1_ptr)_2)->base + _12TopLevelSub_20233);
    DeRef(_12Code_20315);
    _2 = (object)SEQ_PTR(_27926);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    Ref(_12Code_20315);
    _27926 = NOVALUE;

    /** parser.e:191		SymTab[TopLevelSub][S_LINETAB] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_LINETAB_19899))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_LINETAB_19899)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_LINETAB_19899);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _27928 = NOVALUE;

    /** parser.e:192		SymTab[TopLevelSub][S_CODE] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_19876))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _27930 = NOVALUE;

    /** parser.e:193		previous_op = -1*/
    _12previous_op_20325 = -1LL;

    /** parser.e:194		CurrentSub = TopLevelSub*/
    _12CurrentSub_20234 = _12TopLevelSub_20233;

    /** parser.e:195		clear_last()*/
    _45clear_last();

    /** parser.e:196		if length( branch_stack ) then*/
    if (IS_SEQUENCE(_43branch_stack_55014)){
            _27932 = SEQ_PTR(_43branch_stack_55014)->length;
    }
    else {
        _27932 = 1;
    }
    if (_27932 == 0)
    {
        _27932 = NOVALUE;
        goto L4; // [171] 205
    }
    else{
        _27932 = NOVALUE;
    }

    /** parser.e:197			branch_list = branch_stack[$]*/
    if (IS_SEQUENCE(_43branch_stack_55014)){
            _27933 = SEQ_PTR(_43branch_stack_55014)->length;
    }
    else {
        _27933 = 1;
    }
    DeRef(_43branch_list_55013);
    _2 = (object)SEQ_PTR(_43branch_stack_55014);
    _43branch_list_55013 = (object)*(((s1_ptr)_2)->base + _27933);
    Ref(_43branch_list_55013);

    /** parser.e:198			branch_stack = tail( branch_stack )*/
    if (IS_SEQUENCE(_43branch_stack_55014)){
            _27935 = SEQ_PTR(_43branch_stack_55014)->length;
    }
    else {
        _27935 = 1;
    }
    _27936 = _27935 - 1LL;
    _27935 = NOVALUE;
    {
        int len = SEQ_PTR(_43branch_stack_55014)->length;
        int size = (IS_ATOM_INT(_27936)) ? _27936 : (object)(DBL_PTR(_27936)->dbl);
        if (size <= 0) {
            DeRef(_43branch_stack_55014);
            _43branch_stack_55014 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_43branch_stack_55014);
            DeRef(_43branch_stack_55014);
            _43branch_stack_55014 = _43branch_stack_55014;
        }
        else Tail(SEQ_PTR(_43branch_stack_55014), len-size+1, &_43branch_stack_55014);
    }
    _27936 = NOVALUE;
L4: 

    /** parser.e:200	end procedure*/
    return;
    ;
}


void _43LeaveTopLevel()
{
    object _27941 = NOVALUE;
    object _27939 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:204		branch_stack = append( branch_stack, branch_list )*/
    RefDS(_43branch_list_55013);
    Append(&_43branch_stack_55014, _43branch_stack_55014, _43branch_list_55013);

    /** parser.e:205		branch_list = {}*/
    RefDS(_22024);
    DeRefDS(_43branch_list_55013);
    _43branch_list_55013 = _22024;

    /** parser.e:206		PushGoto()*/
    _43PushGoto();

    /** parser.e:207		LastLineNumber = -1*/
    _61LastLineNumber_25584 = -1LL;

    /** parser.e:208		SymTab[TopLevelSub][S_LINETAB] = LineTable*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    RefDS(_12LineTable_20316);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_LINETAB_19899))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_LINETAB_19899)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_LINETAB_19899);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12LineTable_20316;
    DeRef(_1);
    _27939 = NOVALUE;

    /** parser.e:209		SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    RefDS(_12Code_20315);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_19876))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12Code_20315;
    DeRef(_1);
    _27941 = NOVALUE;

    /** parser.e:210		LineTable = {}*/
    RefDS(_22024);
    DeRefDS(_12LineTable_20316);
    _12LineTable_20316 = _22024;

    /** parser.e:211		Code = {}*/
    RefDS(_22024);
    DeRefDS(_12Code_20315);
    _12Code_20315 = _22024;

    /** parser.e:212		previous_op = -1*/
    _12previous_op_20325 = -1LL;

    /** parser.e:213		clear_last()*/
    _45clear_last();

    /** parser.e:214	end procedure*/
    return;
    ;
}


void _43InitParser()
{
    object _new_1__tmp_at195_55263 = NOVALUE;
    object _new_inlined_new_at_195_55262 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:217		goto_stack = {}*/
    RefDS(_22024);
    DeRef(_43goto_stack_55028);
    _43goto_stack_55028 = _22024;

    /** parser.e:220		goto_labels = {}*/
    RefDS(_22024);
    DeRef(_43goto_labels_55026);
    _43goto_labels_55026 = _22024;

    /** parser.e:221		label_block = {}*/
    RefDS(_22024);
    DeRef(_43label_block_55030);
    _43label_block_55030 = _22024;

    /** parser.e:222		goto_ref = {}*/
    RefDS(_22024);
    DeRef(_43goto_ref_55029);
    _43goto_ref_55029 = _22024;

    /** parser.e:223		goto_addr = {}*/
    RefDS(_22024);
    DeRef(_43goto_addr_55027);
    _43goto_addr_55027 = _22024;

    /** parser.e:224		goto_line = {}*/
    RefDS(_22024);
    DeRef(_43goto_line_55025);
    _43goto_line_55025 = _22024;

    /** parser.e:225		break_list = {}*/
    RefDS(_22024);
    DeRefi(_43break_list_55033);
    _43break_list_55033 = _22024;

    /** parser.e:226		break_delay = {}*/
    RefDS(_22024);
    DeRef(_43break_delay_55034);
    _43break_delay_55034 = _22024;

    /** parser.e:227		exit_list = {}*/
    RefDS(_22024);
    DeRefi(_43exit_list_55035);
    _43exit_list_55035 = _22024;

    /** parser.e:228		exit_delay = {}*/
    RefDS(_22024);
    DeRef(_43exit_delay_55036);
    _43exit_delay_55036 = _22024;

    /** parser.e:229		continue_list = {}*/
    RefDS(_22024);
    DeRefi(_43continue_list_55037);
    _43continue_list_55037 = _22024;

    /** parser.e:230		continue_delay = {}*/
    RefDS(_22024);
    DeRef(_43continue_delay_55038);
    _43continue_delay_55038 = _22024;

    /** parser.e:231		init_stack = {}*/
    RefDS(_22024);
    DeRefi(_43init_stack_55048);
    _43init_stack_55048 = _22024;

    /** parser.e:232		CurrentSub = 0*/
    _12CurrentSub_20234 = 0LL;

    /** parser.e:233		CreateTopLevel()*/
    _43CreateTopLevel();

    /** parser.e:234		EnterTopLevel()*/
    _43EnterTopLevel(1LL);

    /** parser.e:235		backed_up_tok = {}*/
    RefDS(_22024);
    DeRef(_43backed_up_tok_55022);
    _43backed_up_tok_55022 = _22024;

    /** parser.e:236		loop_stack = {}*/
    RefDS(_22024);
    DeRefi(_43loop_stack_55049);
    _43loop_stack_55049 = _22024;

    /** parser.e:237		stmt_nest = 0*/
    _43stmt_nest_55047 = 0LL;

    /** parser.e:238		loop_labels = {}*/
    RefDS(_22024);
    DeRef(_43loop_labels_55043);
    _43loop_labels_55043 = _22024;

    /** parser.e:239		if_labels = {}*/
    RefDS(_22024);
    DeRef(_43if_labels_55044);
    _43if_labels_55044 = _22024;

    /** parser.e:240		if_stack = {}*/
    RefDS(_22024);
    DeRefi(_43if_stack_55050);
    _43if_stack_55050 = _22024;

    /** parser.e:241		continue_addr = {}*/
    RefDS(_22024);
    DeRefi(_43continue_addr_55040);
    _43continue_addr_55040 = _22024;

    /** parser.e:242		retry_addr = {}*/
    RefDS(_22024);
    DeRefi(_43retry_addr_55041);
    _43retry_addr_55041 = _22024;

    /** parser.e:243		entry_addr = {}*/
    RefDS(_22024);
    DeRefi(_43entry_addr_55039);
    _43entry_addr_55039 = _22024;

    /** parser.e:244		block_list = {}*/
    RefDS(_22024);
    DeRefi(_43block_list_55045);
    _43block_list_55045 = _22024;

    /** parser.e:245		block_index = 0*/
    _43block_index_55046 = 0LL;

    /** parser.e:246		param_num = -1*/
    _43param_num_55024 = -1LL;

    /** parser.e:247		entry_stack = {}*/
    RefDS(_22024);
    DeRef(_43entry_stack_55042);
    _43entry_stack_55042 = _22024;

    /** parser.e:248		goto_init = map:new()*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at195_55263;
    _new_1__tmp_at195_55263 = _34new_map_seq(8LL);
    DeRef(_0);
    Ref(_new_1__tmp_at195_55263);
    _0 = _35malloc(_new_1__tmp_at195_55263, 1LL);
    DeRef(_43goto_init_55032);
    _43goto_init_55032 = _0;
    DeRef(_new_1__tmp_at195_55263);
    _new_1__tmp_at195_55263 = NOVALUE;

    /** parser.e:249	end procedure*/
    return;
    ;
}


void _43NotReached(object _tok_55282, object _keyword_55283)
{
    object _27958 = NOVALUE;
    object _27957 = NOVALUE;
    object _27956 = NOVALUE;
    object _27955 = NOVALUE;
    object _27954 = NOVALUE;
    object _27953 = NOVALUE;
    object _27951 = NOVALUE;
    object _27950 = NOVALUE;
    object _27949 = NOVALUE;
    object _27948 = NOVALUE;
    object _27946 = NOVALUE;
    object _27945 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_tok_55282)) {
        _1 = (object)(DBL_PTR(_tok_55282)->dbl);
        DeRefDS(_tok_55282);
        _tok_55282 = _1;
    }

    /** parser.e:271		if not find(tok, {END, ELSE, ELSIF, END_OF_FILE, CASE, IFDEF, ELSIFDEF, ELSEDEF}) then*/
    _1 = NewS1(8);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 402LL;
    ((intptr_t*)_2)[2] = 23LL;
    ((intptr_t*)_2)[3] = 414LL;
    ((intptr_t*)_2)[4] = -21LL;
    ((intptr_t*)_2)[5] = 186LL;
    ((intptr_t*)_2)[6] = 407LL;
    ((intptr_t*)_2)[7] = 408LL;
    ((intptr_t*)_2)[8] = 409LL;
    _27945 = MAKE_SEQ(_1);
    _27946 = find_from(_tok_55282, _27945, 1LL);
    DeRefDS(_27945);
    _27945 = NOVALUE;
    if (_27946 != 0)
    goto L1; // [39] 135
    _27946 = NOVALUE;

    /** parser.e:272			if equal(keyword, "goto") and find(tok, {LOOP, LABEL, WHILE}) then*/
    if (_keyword_55283 == _26280)
    _27948 = 1;
    else if (IS_ATOM_INT(_keyword_55283) && IS_ATOM_INT(_26280))
    _27948 = 0;
    else
    _27948 = (compare(_keyword_55283, _26280) == 0);
    if (_27948 == 0) {
        goto L2; // [48] 79
    }
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 422LL;
    ((intptr_t*)_2)[2] = 419LL;
    ((intptr_t*)_2)[3] = 47LL;
    _27950 = MAKE_SEQ(_1);
    _27951 = find_from(_tok_55282, _27950, 1LL);
    DeRefDS(_27950);
    _27950 = NOVALUE;
    if (_27951 == 0)
    {
        _27951 = NOVALUE;
        goto L2; // [70] 79
    }
    else{
        _27951 = NOVALUE;
    }

    /** parser.e:273				return*/
    DeRefDSi(_keyword_55283);
    return;
L2: 

    /** parser.e:275			if equal(keyword, "abort()") and tok = LABEL then*/
    if (_keyword_55283 == _27952)
    _27953 = 1;
    else if (IS_ATOM_INT(_keyword_55283) && IS_ATOM_INT(_27952))
    _27953 = 0;
    else
    _27953 = (compare(_keyword_55283, _27952) == 0);
    if (_27953 == 0) {
        goto L3; // [85] 105
    }
    _27955 = (_tok_55282 == 419LL);
    if (_27955 == 0)
    {
        DeRef(_27955);
        _27955 = NOVALUE;
        goto L3; // [96] 105
    }
    else{
        DeRef(_27955);
        _27955 = NOVALUE;
    }

    /** parser.e:278				return*/
    DeRefDSi(_keyword_55283);
    return;
L3: 

    /** parser.e:280			Warning(218, not_reached_warning_flag,*/
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _27956 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    Ref(_27956);
    _27957 = _53name_ext(_27956);
    _27956 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _27957;
    ((intptr_t*)_2)[2] = _12line_number_20227;
    RefDS(_keyword_55283);
    ((intptr_t*)_2)[3] = _keyword_55283;
    _27958 = MAKE_SEQ(_1);
    _27957 = NOVALUE;
    _49Warning(218LL, 512LL, _27958);
    _27958 = NOVALUE;
L1: 

    /** parser.e:285	end procedure*/
    DeRefDSi(_keyword_55283);
    return;
    ;
}


void _43Forward_InitCheck(object _tok_55322, object _ref_55323)
{
    object _sym_55325 = NOVALUE;
    object _27964 = NOVALUE;
    object _27963 = NOVALUE;
    object _27962 = NOVALUE;
    object _27960 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:289		if ref then*/
    if (_ref_55323 == 0)
    {
        goto L1; // [5] 83
    }
    else{
    }

    /** parser.e:290			integer sym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_55322);
    _sym_55325 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_sym_55325)){
        _sym_55325 = (object)DBL_PTR(_sym_55325)->dbl;
    }

    /** parser.e:291			if tok[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_55322);
    _27960 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _27960, 512LL)){
        _27960 = NOVALUE;
        goto L2; // [28] 50
    }
    _27960 = NOVALUE;

    /** parser.e:292				set_qualified_fwd( SymTab[sym][S_FILE_NO] )*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27962 = (object)*(((s1_ptr)_2)->base + _sym_55325);
    _2 = (object)SEQ_PTR(_27962);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _27963 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _27963 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _27962 = NOVALUE;
    Ref(_27963);
    _61set_qualified_fwd(_27963);
    _27963 = NOVALUE;
L2: 

    /** parser.e:294			ref = new_forward_reference( GLOBAL_INIT_CHECK, tok[T_SYM], GLOBAL_INIT_CHECK )*/
    _2 = (object)SEQ_PTR(_tok_55322);
    _27964 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_27964);
    _ref_55323 = _42new_forward_reference(109LL, _27964, 109LL);
    _27964 = NOVALUE;
    if (!IS_ATOM_INT(_ref_55323)) {
        _1 = (object)(DBL_PTR(_ref_55323)->dbl);
        DeRefDS(_ref_55323);
        _ref_55323 = _1;
    }

    /** parser.e:296			emit_op( GLOBAL_INIT_CHECK )*/
    _45emit_op(109LL);

    /** parser.e:297			emit_addr( sym )*/
    _45emit_addr(_sym_55325);
L1: 

    /** parser.e:299	end procedure*/
    DeRef(_tok_55322);
    return;
    ;
}


void _43InitCheck(object _sym_55350, object _ref_55351)
{
    object _28041 = NOVALUE;
    object _28040 = NOVALUE;
    object _28039 = NOVALUE;
    object _28038 = NOVALUE;
    object _28037 = NOVALUE;
    object _28036 = NOVALUE;
    object _28035 = NOVALUE;
    object _28034 = NOVALUE;
    object _28032 = NOVALUE;
    object _28030 = NOVALUE;
    object _28029 = NOVALUE;
    object _28027 = NOVALUE;
    object _28026 = NOVALUE;
    object _28025 = NOVALUE;
    object _28024 = NOVALUE;
    object _28023 = NOVALUE;
    object _28022 = NOVALUE;
    object _28021 = NOVALUE;
    object _28020 = NOVALUE;
    object _28019 = NOVALUE;
    object _28018 = NOVALUE;
    object _28017 = NOVALUE;
    object _28016 = NOVALUE;
    object _28015 = NOVALUE;
    object _28014 = NOVALUE;
    object _28012 = NOVALUE;
    object _28011 = NOVALUE;
    object _28010 = NOVALUE;
    object _28009 = NOVALUE;
    object _28008 = NOVALUE;
    object _28007 = NOVALUE;
    object _28006 = NOVALUE;
    object _28005 = NOVALUE;
    object _28004 = NOVALUE;
    object _28002 = NOVALUE;
    object _28001 = NOVALUE;
    object _28000 = NOVALUE;
    object _27999 = NOVALUE;
    object _27998 = NOVALUE;
    object _27997 = NOVALUE;
    object _27996 = NOVALUE;
    object _27995 = NOVALUE;
    object _27994 = NOVALUE;
    object _27993 = NOVALUE;
    object _27992 = NOVALUE;
    object _27991 = NOVALUE;
    object _27990 = NOVALUE;
    object _27989 = NOVALUE;
    object _27988 = NOVALUE;
    object _27987 = NOVALUE;
    object _27986 = NOVALUE;
    object _27985 = NOVALUE;
    object _27984 = NOVALUE;
    object _27983 = NOVALUE;
    object _27982 = NOVALUE;
    object _27981 = NOVALUE;
    object _27979 = NOVALUE;
    object _27978 = NOVALUE;
    object _27977 = NOVALUE;
    object _27976 = NOVALUE;
    object _27975 = NOVALUE;
    object _27974 = NOVALUE;
    object _27973 = NOVALUE;
    object _27972 = NOVALUE;
    object _27971 = NOVALUE;
    object _27970 = NOVALUE;
    object _27969 = NOVALUE;
    object _27968 = NOVALUE;
    object _27966 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:306		if sym < 0 or (SymTab[sym][S_MODE] = M_NORMAL and*/
    _27966 = (_sym_55350 < 0LL);
    if (_27966 != 0) {
        goto L1; // [11] 90
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27968 = (object)*(((s1_ptr)_2)->base + _sym_55350);
    _2 = (object)SEQ_PTR(_27968);
    _27969 = (object)*(((s1_ptr)_2)->base + 3LL);
    _27968 = NOVALUE;
    if (IS_ATOM_INT(_27969)) {
        _27970 = (_27969 == 1LL);
    }
    else {
        _27970 = binary_op(EQUALS, _27969, 1LL);
    }
    _27969 = NOVALUE;
    if (IS_ATOM_INT(_27970)) {
        if (_27970 == 0) {
            _27971 = 0;
            goto L2; // [33] 59
        }
    }
    else {
        if (DBL_PTR(_27970)->dbl == 0.0) {
            _27971 = 0;
            goto L2; // [33] 59
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27972 = (object)*(((s1_ptr)_2)->base + _sym_55350);
    _2 = (object)SEQ_PTR(_27972);
    _27973 = (object)*(((s1_ptr)_2)->base + 4LL);
    _27972 = NOVALUE;
    if (IS_ATOM_INT(_27973)) {
        _27974 = (_27973 != 2LL);
    }
    else {
        _27974 = binary_op(NOTEQ, _27973, 2LL);
    }
    _27973 = NOVALUE;
    DeRef(_27971);
    if (IS_ATOM_INT(_27974))
    _27971 = (_27974 != 0);
    else
    _27971 = DBL_PTR(_27974)->dbl != 0.0;
L2: 
    if (_27971 == 0) {
        DeRef(_27975);
        _27975 = 0;
        goto L3; // [59] 85
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27976 = (object)*(((s1_ptr)_2)->base + _sym_55350);
    _2 = (object)SEQ_PTR(_27976);
    _27977 = (object)*(((s1_ptr)_2)->base + 4LL);
    _27976 = NOVALUE;
    if (IS_ATOM_INT(_27977)) {
        _27978 = (_27977 != 4LL);
    }
    else {
        _27978 = binary_op(NOTEQ, _27977, 4LL);
    }
    _27977 = NOVALUE;
    if (IS_ATOM_INT(_27978))
    _27975 = (_27978 != 0);
    else
    _27975 = DBL_PTR(_27978)->dbl != 0.0;
L3: 
    if (_27975 == 0)
    {
        _27975 = NOVALUE;
        goto L4; // [86] 502
    }
    else{
        _27975 = NOVALUE;
    }
L1: 

    /** parser.e:309			if sym < 0 or ((SymTab[sym][S_SCOPE] != SC_PRIVATE and*/
    _27979 = (_sym_55350 < 0LL);
    if (_27979 != 0) {
        goto L5; // [96] 213
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27981 = (object)*(((s1_ptr)_2)->base + _sym_55350);
    _2 = (object)SEQ_PTR(_27981);
    _27982 = (object)*(((s1_ptr)_2)->base + 4LL);
    _27981 = NOVALUE;
    if (IS_ATOM_INT(_27982)) {
        _27983 = (_27982 != 3LL);
    }
    else {
        _27983 = binary_op(NOTEQ, _27982, 3LL);
    }
    _27982 = NOVALUE;
    if (IS_ATOM_INT(_27983)) {
        if (_27983 == 0) {
            DeRef(_27984);
            _27984 = 0;
            goto L6; // [118] 144
        }
    }
    else {
        if (DBL_PTR(_27983)->dbl == 0.0) {
            DeRef(_27984);
            _27984 = 0;
            goto L6; // [118] 144
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27985 = (object)*(((s1_ptr)_2)->base + _sym_55350);
    _2 = (object)SEQ_PTR(_27985);
    _27986 = (object)*(((s1_ptr)_2)->base + 1LL);
    _27985 = NOVALUE;
    if (_27986 == _12NOVALUE_20081)
    _27987 = 1;
    else if (IS_ATOM_INT(_27986) && IS_ATOM_INT(_12NOVALUE_20081))
    _27987 = 0;
    else
    _27987 = (compare(_27986, _12NOVALUE_20081) == 0);
    _27986 = NOVALUE;
    DeRef(_27984);
    _27984 = (_27987 != 0);
L6: 
    if (_27984 != 0) {
        DeRef(_27988);
        _27988 = 1;
        goto L7; // [144] 208
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27989 = (object)*(((s1_ptr)_2)->base + _sym_55350);
    _2 = (object)SEQ_PTR(_27989);
    _27990 = (object)*(((s1_ptr)_2)->base + 4LL);
    _27989 = NOVALUE;
    if (IS_ATOM_INT(_27990)) {
        _27991 = (_27990 == 3LL);
    }
    else {
        _27991 = binary_op(EQUALS, _27990, 3LL);
    }
    _27990 = NOVALUE;
    if (IS_ATOM_INT(_27991)) {
        if (_27991 == 0) {
            DeRef(_27992);
            _27992 = 0;
            goto L8; // [166] 204
        }
    }
    else {
        if (DBL_PTR(_27991)->dbl == 0.0) {
            DeRef(_27992);
            _27992 = 0;
            goto L8; // [166] 204
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27993 = (object)*(((s1_ptr)_2)->base + _sym_55350);
    _2 = (object)SEQ_PTR(_27993);
    _27994 = (object)*(((s1_ptr)_2)->base + 16LL);
    _27993 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27995 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_27995);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _27996 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _27996 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _27995 = NOVALUE;
    if (IS_ATOM_INT(_27994) && IS_ATOM_INT(_27996)) {
        _27997 = (_27994 >= _27996);
    }
    else {
        _27997 = binary_op(GREATEREQ, _27994, _27996);
    }
    _27994 = NOVALUE;
    _27996 = NOVALUE;
    DeRef(_27992);
    if (IS_ATOM_INT(_27997))
    _27992 = (_27997 != 0);
    else
    _27992 = DBL_PTR(_27997)->dbl != 0.0;
L8: 
    DeRef(_27988);
    _27988 = (_27992 != 0);
L7: 
    if (_27988 == 0)
    {
        _27988 = NOVALUE;
        goto L9; // [209] 566
    }
    else{
        _27988 = NOVALUE;
    }
L5: 

    /** parser.e:313				if sym < 0 or (SymTab[sym][S_INITLEVEL] = -1)*/
    _27998 = (_sym_55350 < 0LL);
    if (_27998 != 0) {
        _27999 = 1;
        goto LA; // [219] 243
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28000 = (object)*(((s1_ptr)_2)->base + _sym_55350);
    _2 = (object)SEQ_PTR(_28000);
    _28001 = (object)*(((s1_ptr)_2)->base + 14LL);
    _28000 = NOVALUE;
    if (IS_ATOM_INT(_28001)) {
        _28002 = (_28001 == -1LL);
    }
    else {
        _28002 = binary_op(EQUALS, _28001, -1LL);
    }
    _28001 = NOVALUE;
    if (IS_ATOM_INT(_28002))
    _27999 = (_28002 != 0);
    else
    _27999 = DBL_PTR(_28002)->dbl != 0.0;
LA: 
    if (_27999 != 0) {
        goto LB; // [243] 270
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28004 = (object)*(((s1_ptr)_2)->base + _sym_55350);
    _2 = (object)SEQ_PTR(_28004);
    _28005 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28004 = NOVALUE;
    if (IS_ATOM_INT(_28005)) {
        _28006 = (_28005 != 3LL);
    }
    else {
        _28006 = binary_op(NOTEQ, _28005, 3LL);
    }
    _28005 = NOVALUE;
    if (_28006 == 0) {
        DeRef(_28006);
        _28006 = NOVALUE;
        goto L9; // [266] 566
    }
    else {
        if (!IS_ATOM_INT(_28006) && DBL_PTR(_28006)->dbl == 0.0){
            DeRef(_28006);
            _28006 = NOVALUE;
            goto L9; // [266] 566
        }
        DeRef(_28006);
        _28006 = NOVALUE;
    }
    DeRef(_28006);
    _28006 = NOVALUE;
LB: 

    /** parser.e:316					if ref then*/
    if (_ref_55351 == 0)
    {
        goto LC; // [272] 375
    }
    else{
    }

    /** parser.e:317						if sym > 0 and (SymTab[sym][S_SCOPE] = SC_UNDEFINED) then*/
    _28007 = (_sym_55350 > 0LL);
    if (_28007 == 0) {
        goto LD; // [281] 317
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28009 = (object)*(((s1_ptr)_2)->base + _sym_55350);
    _2 = (object)SEQ_PTR(_28009);
    _28010 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28009 = NOVALUE;
    if (IS_ATOM_INT(_28010)) {
        _28011 = (_28010 == 9LL);
    }
    else {
        _28011 = binary_op(EQUALS, _28010, 9LL);
    }
    _28010 = NOVALUE;
    if (_28011 == 0) {
        DeRef(_28011);
        _28011 = NOVALUE;
        goto LD; // [304] 317
    }
    else {
        if (!IS_ATOM_INT(_28011) && DBL_PTR(_28011)->dbl == 0.0){
            DeRef(_28011);
            _28011 = NOVALUE;
            goto LD; // [304] 317
        }
        DeRef(_28011);
        _28011 = NOVALUE;
    }
    DeRef(_28011);
    _28011 = NOVALUE;

    /** parser.e:318							emit_op(PRIVATE_INIT_CHECK)*/
    _45emit_op(30LL);
    goto LE; // [314] 369
LD: 

    /** parser.e:319						elsif sym < 0 or find(SymTab[sym][S_SCOPE], SCOPE_TYPES) then*/
    _28012 = (_sym_55350 < 0LL);
    if (_28012 != 0) {
        goto LF; // [323] 351
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28014 = (object)*(((s1_ptr)_2)->base + _sym_55350);
    _2 = (object)SEQ_PTR(_28014);
    _28015 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28014 = NOVALUE;
    _28016 = find_from(_28015, _43SCOPE_TYPES_55006, 1LL);
    _28015 = NOVALUE;
    if (_28016 == 0)
    {
        _28016 = NOVALUE;
        goto L10; // [347] 361
    }
    else{
        _28016 = NOVALUE;
    }
LF: 

    /** parser.e:320							emit_op(GLOBAL_INIT_CHECK) -- will become NOP2*/
    _45emit_op(109LL);
    goto LE; // [358] 369
L10: 

    /** parser.e:322							emit_op(PRIVATE_INIT_CHECK)*/
    _45emit_op(30LL);
LE: 

    /** parser.e:324						emit_addr(sym)*/
    _45emit_addr(_sym_55350);
LC: 

    /** parser.e:326					if sym > 0 */
    _28017 = (_sym_55350 > 0LL);
    if (_28017 == 0) {
        _28018 = 0;
        goto L11; // [381] 411
    }
    _28019 = (_43short_circuit_55015 <= 0LL);
    if (_28019 != 0) {
        _28020 = 1;
        goto L12; // [391] 407
    }
    _28021 = (_43short_circuit_B_55017 == _9FALSE_444);
    _28020 = (_28021 != 0);
L12: 
    _28018 = (_28020 != 0);
L11: 
    if (_28018 == 0) {
        goto L9; // [411] 566
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28023 = (object)*(((s1_ptr)_2)->base + _sym_55350);
    _2 = (object)SEQ_PTR(_28023);
    _28024 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28023 = NOVALUE;
    if (IS_ATOM_INT(_28024)) {
        _28025 = (_28024 != 3LL);
    }
    else {
        _28025 = binary_op(NOTEQ, _28024, 3LL);
    }
    _28024 = NOVALUE;
    if (IS_ATOM_INT(_28025)) {
        _28026 = (_28025 == 0);
    }
    else {
        _28026 = unary_op(NOT, _28025);
    }
    DeRef(_28025);
    _28025 = NOVALUE;
    if (_28026 == 0) {
        DeRef(_28026);
        _28026 = NOVALUE;
        goto L9; // [437] 566
    }
    else {
        if (!IS_ATOM_INT(_28026) && DBL_PTR(_28026)->dbl == 0.0){
            DeRef(_28026);
            _28026 = NOVALUE;
            goto L9; // [437] 566
        }
        DeRef(_28026);
        _28026 = NOVALUE;
    }
    DeRef(_28026);
    _28026 = NOVALUE;

    /** parser.e:330						if CurrentSub != TopLevelSub */
    _28027 = (_12CurrentSub_20234 != _12TopLevelSub_20233);
    if (_28027 != 0) {
        goto L13; // [450] 470
    }
    if (IS_SEQUENCE(_13known_files_11317)){
            _28029 = SEQ_PTR(_13known_files_11317)->length;
    }
    else {
        _28029 = 1;
    }
    _28030 = (_12current_file_no_20226 == _28029);
    _28029 = NOVALUE;
    if (_28030 == 0)
    {
        DeRef(_28030);
        _28030 = NOVALUE;
        goto L9; // [466] 566
    }
    else{
        DeRef(_28030);
        _28030 = NOVALUE;
    }
L13: 

    /** parser.e:335							init_stack = append(init_stack, sym)*/
    Append(&_43init_stack_55048, _43init_stack_55048, _sym_55350);

    /** parser.e:336							SymTab[sym][S_INITLEVEL] = stmt_nest*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_55350 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _43stmt_nest_55047;
    DeRef(_1);
    _28032 = NOVALUE;
    goto L9; // [499] 566
L4: 

    /** parser.e:343		elsif ref and sym > 0 and sym_mode( sym ) = M_CONSTANT and equal( NOVALUE, sym_obj( sym ) ) then*/
    if (_ref_55351 == 0) {
        _28034 = 0;
        goto L14; // [504] 516
    }
    _28035 = (_sym_55350 > 0LL);
    _28034 = (_28035 != 0);
L14: 
    if (_28034 == 0) {
        _28036 = 0;
        goto L15; // [516] 534
    }
    _28037 = _53sym_mode(_sym_55350);
    if (IS_ATOM_INT(_28037)) {
        _28038 = (_28037 == 2LL);
    }
    else {
        _28038 = binary_op(EQUALS, _28037, 2LL);
    }
    DeRef(_28037);
    _28037 = NOVALUE;
    if (IS_ATOM_INT(_28038))
    _28036 = (_28038 != 0);
    else
    _28036 = DBL_PTR(_28038)->dbl != 0.0;
L15: 
    if (_28036 == 0) {
        goto L16; // [534] 565
    }
    _28040 = _53sym_obj(_sym_55350);
    if (_12NOVALUE_20081 == _28040)
    _28041 = 1;
    else if (IS_ATOM_INT(_12NOVALUE_20081) && IS_ATOM_INT(_28040))
    _28041 = 0;
    else
    _28041 = (compare(_12NOVALUE_20081, _28040) == 0);
    DeRef(_28040);
    _28040 = NOVALUE;
    if (_28041 == 0)
    {
        _28041 = NOVALUE;
        goto L16; // [549] 565
    }
    else{
        _28041 = NOVALUE;
    }

    /** parser.e:344			emit_op( GLOBAL_INIT_CHECK )*/
    _45emit_op(109LL);

    /** parser.e:345			emit_addr(sym)*/
    _45emit_addr(_sym_55350);
L16: 
L9: 

    /** parser.e:349	end procedure*/
    DeRef(_27983);
    _27983 = NOVALUE;
    DeRef(_27997);
    _27997 = NOVALUE;
    DeRef(_27991);
    _27991 = NOVALUE;
    DeRef(_27970);
    _27970 = NOVALUE;
    DeRef(_28021);
    _28021 = NOVALUE;
    DeRef(_27966);
    _27966 = NOVALUE;
    DeRef(_27978);
    _27978 = NOVALUE;
    DeRef(_28012);
    _28012 = NOVALUE;
    DeRef(_27998);
    _27998 = NOVALUE;
    DeRef(_28019);
    _28019 = NOVALUE;
    DeRef(_28007);
    _28007 = NOVALUE;
    DeRef(_28002);
    _28002 = NOVALUE;
    DeRef(_28027);
    _28027 = NOVALUE;
    DeRef(_28017);
    _28017 = NOVALUE;
    DeRef(_27974);
    _27974 = NOVALUE;
    DeRef(_28035);
    _28035 = NOVALUE;
    DeRef(_27979);
    _27979 = NOVALUE;
    DeRef(_28038);
    _28038 = NOVALUE;
    return;
    ;
}


void _43InitDelete()
{
    object _28054 = NOVALUE;
    object _28053 = NOVALUE;
    object _28051 = NOVALUE;
    object _28050 = NOVALUE;
    object _28049 = NOVALUE;
    object _28048 = NOVALUE;
    object _28047 = NOVALUE;
    object _28046 = NOVALUE;
    object _28045 = NOVALUE;
    object _28044 = NOVALUE;
    object _28043 = NOVALUE;
    object _28042 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:354		while length(init_stack) and*/
L1: 
    if (IS_SEQUENCE(_43init_stack_55048)){
            _28042 = SEQ_PTR(_43init_stack_55048)->length;
    }
    else {
        _28042 = 1;
    }
    if (_28042 == 0) {
        goto L2; // [11] 91
    }
    if (IS_SEQUENCE(_43init_stack_55048)){
            _28044 = SEQ_PTR(_43init_stack_55048)->length;
    }
    else {
        _28044 = 1;
    }
    _2 = (object)SEQ_PTR(_43init_stack_55048);
    _28045 = (object)*(((s1_ptr)_2)->base + _28044);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28046 = (object)*(((s1_ptr)_2)->base + _28045);
    _2 = (object)SEQ_PTR(_28046);
    _28047 = (object)*(((s1_ptr)_2)->base + 14LL);
    _28046 = NOVALUE;
    if (IS_ATOM_INT(_28047)) {
        _28048 = (_28047 > _43stmt_nest_55047);
    }
    else {
        _28048 = binary_op(GREATER, _28047, _43stmt_nest_55047);
    }
    _28047 = NOVALUE;
    if (_28048 <= 0) {
        if (_28048 == 0) {
            DeRef(_28048);
            _28048 = NOVALUE;
            goto L2; // [43] 91
        }
        else {
            if (!IS_ATOM_INT(_28048) && DBL_PTR(_28048)->dbl == 0.0){
                DeRef(_28048);
                _28048 = NOVALUE;
                goto L2; // [43] 91
            }
            DeRef(_28048);
            _28048 = NOVALUE;
        }
    }
    DeRef(_28048);
    _28048 = NOVALUE;

    /** parser.e:356			SymTab[init_stack[$]][S_INITLEVEL] = -1*/
    if (IS_SEQUENCE(_43init_stack_55048)){
            _28049 = SEQ_PTR(_43init_stack_55048)->length;
    }
    else {
        _28049 = 1;
    }
    _2 = (object)SEQ_PTR(_43init_stack_55048);
    _28050 = (object)*(((s1_ptr)_2)->base + _28049);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_28050 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1LL;
    DeRef(_1);
    _28051 = NOVALUE;

    /** parser.e:357			init_stack = init_stack[1..$-1]*/
    if (IS_SEQUENCE(_43init_stack_55048)){
            _28053 = SEQ_PTR(_43init_stack_55048)->length;
    }
    else {
        _28053 = 1;
    }
    _28054 = _28053 - 1LL;
    _28053 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43init_stack_55048;
    RHS_Slice(_43init_stack_55048, 1LL, _28054);

    /** parser.e:358		end while*/
    goto L1; // [88] 6
L2: 

    /** parser.e:359	end procedure*/
    _28050 = NOVALUE;
    _28045 = NOVALUE;
    DeRef(_28054);
    _28054 = NOVALUE;
    return;
    ;
}


void _43emit_forward_addr()
{
    object _28056 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:364		emit_addr(0)*/
    _45emit_addr(0LL);

    /** parser.e:365		branch_list = append(branch_list, length(Code))*/
    if (IS_SEQUENCE(_12Code_20315)){
            _28056 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _28056 = 1;
    }
    Append(&_43branch_list_55013, _43branch_list_55013, _28056);
    _28056 = NOVALUE;

    /** parser.e:366	end procedure*/
    return;
    ;
}


void _43StraightenBranches()
{
    object _br_55524 = NOVALUE;
    object _target_55525 = NOVALUE;
    object _28077 = NOVALUE;
    object _28076 = NOVALUE;
    object _28075 = NOVALUE;
    object _28074 = NOVALUE;
    object _28072 = NOVALUE;
    object _28071 = NOVALUE;
    object _28070 = NOVALUE;
    object _28068 = NOVALUE;
    object _28067 = NOVALUE;
    object _28066 = NOVALUE;
    object _28065 = NOVALUE;
    object _28063 = NOVALUE;
    object _28060 = NOVALUE;
    object _28059 = NOVALUE;
    object _28058 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:373		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L1; // [5] 14
    }
    else{
    }

    /** parser.e:374			return -- do it in back-end*/
    return;
L1: 

    /** parser.e:376		for i = length(branch_list) to 1 by -1 do*/
    if (IS_SEQUENCE(_43branch_list_55013)){
            _28058 = SEQ_PTR(_43branch_list_55013)->length;
    }
    else {
        _28058 = 1;
    }
    {
        object _i_55529;
        _i_55529 = _28058;
L2: 
        if (_i_55529 < 1LL){
            goto L3; // [21] 170
        }

        /** parser.e:377			if branch_list[i] > length(Code) then*/
        _2 = (object)SEQ_PTR(_43branch_list_55013);
        _28059 = (object)*(((s1_ptr)_2)->base + _i_55529);
        if (IS_SEQUENCE(_12Code_20315)){
                _28060 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _28060 = 1;
        }
        if (binary_op_a(LESSEQ, _28059, _28060)){
            _28059 = NOVALUE;
            _28060 = NOVALUE;
            goto L4; // [41] 53
        }
        _28059 = NOVALUE;
        _28060 = NOVALUE;

        /** parser.e:378				CompileErr("wtf")*/
        RefDS(_28062);
        RefDS(_22024);
        _49CompileErr(_28062, _22024, 0LL);
L4: 

        /** parser.e:380			target = Code[branch_list[i]]*/
        _2 = (object)SEQ_PTR(_43branch_list_55013);
        _28063 = (object)*(((s1_ptr)_2)->base + _i_55529);
        _2 = (object)SEQ_PTR(_12Code_20315);
        if (!IS_ATOM_INT(_28063)){
            _target_55525 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28063)->dbl));
        }
        else{
            _target_55525 = (object)*(((s1_ptr)_2)->base + _28063);
        }
        if (!IS_ATOM_INT(_target_55525)){
            _target_55525 = (object)DBL_PTR(_target_55525)->dbl;
        }

        /** parser.e:381			if target <= length(Code) and target > 0 then*/
        if (IS_SEQUENCE(_12Code_20315)){
                _28065 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _28065 = 1;
        }
        _28066 = (_target_55525 <= _28065);
        _28065 = NOVALUE;
        if (_28066 == 0) {
            goto L5; // [80] 163
        }
        _28068 = (_target_55525 > 0LL);
        if (_28068 == 0)
        {
            DeRef(_28068);
            _28068 = NOVALUE;
            goto L5; // [89] 163
        }
        else{
            DeRef(_28068);
            _28068 = NOVALUE;
        }

        /** parser.e:382				br = Code[target]*/
        _2 = (object)SEQ_PTR(_12Code_20315);
        _br_55524 = (object)*(((s1_ptr)_2)->base + _target_55525);
        if (!IS_ATOM_INT(_br_55524)){
            _br_55524 = (object)DBL_PTR(_br_55524)->dbl;
        }

        /** parser.e:383				if br = ELSE or br = ENDWHILE or br = EXIT then*/
        _28070 = (_br_55524 == 23LL);
        if (_28070 != 0) {
            _28071 = 1;
            goto L6; // [110] 124
        }
        _28072 = (_br_55524 == 22LL);
        _28071 = (_28072 != 0);
L6: 
        if (_28071 != 0) {
            goto L7; // [124] 139
        }
        _28074 = (_br_55524 == 61LL);
        if (_28074 == 0)
        {
            DeRef(_28074);
            _28074 = NOVALUE;
            goto L8; // [135] 162
        }
        else{
            DeRef(_28074);
            _28074 = NOVALUE;
        }
L7: 

        /** parser.e:384					backpatch(branch_list[i], Code[target+1])*/
        _2 = (object)SEQ_PTR(_43branch_list_55013);
        _28075 = (object)*(((s1_ptr)_2)->base + _i_55529);
        _28076 = _target_55525 + 1;
        _2 = (object)SEQ_PTR(_12Code_20315);
        _28077 = (object)*(((s1_ptr)_2)->base + _28076);
        Ref(_28075);
        Ref(_28077);
        _45backpatch(_28075, _28077);
        _28075 = NOVALUE;
        _28077 = NOVALUE;
L8: 
L5: 

        /** parser.e:387		end for*/
        _i_55529 = _i_55529 + -1LL;
        goto L2; // [165] 28
L3: 
        ;
    }

    /** parser.e:388		branch_list = {}*/
    RefDS(_22024);
    DeRef(_43branch_list_55013);
    _43branch_list_55013 = _22024;

    /** parser.e:389	end procedure*/
    DeRef(_28076);
    _28076 = NOVALUE;
    DeRef(_28072);
    _28072 = NOVALUE;
    DeRef(_28070);
    _28070 = NOVALUE;
    DeRef(_28066);
    _28066 = NOVALUE;
    _28063 = NOVALUE;
    return;
    ;
}


void _43PatchEList(object _base_55577)
{
    object _break_top_55578 = NOVALUE;
    object _n_55579 = NOVALUE;
    object _28094 = NOVALUE;
    object _28093 = NOVALUE;
    object _28092 = NOVALUE;
    object _28088 = NOVALUE;
    object _28087 = NOVALUE;
    object _28086 = NOVALUE;
    object _28084 = NOVALUE;
    object _28083 = NOVALUE;
    object _28081 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:410		if not length(break_list) then*/
    if (IS_SEQUENCE(_43break_list_55033)){
            _28081 = SEQ_PTR(_43break_list_55033)->length;
    }
    else {
        _28081 = 1;
    }
    if (_28081 != 0)
    goto L1; // [10] 19
    _28081 = NOVALUE;

    /** parser.e:411			return*/
    return;
L1: 

    /** parser.e:414		break_top = 0*/
    _break_top_55578 = 0LL;

    /** parser.e:415		for i=length(break_list) to base+1 by -1 do*/
    if (IS_SEQUENCE(_43break_list_55033)){
            _28083 = SEQ_PTR(_43break_list_55033)->length;
    }
    else {
        _28083 = 1;
    }
    _28084 = _base_55577 + 1;
    if (_28084 > MAXINT){
        _28084 = NewDouble((eudouble)_28084);
    }
    {
        object _i_55584;
        _i_55584 = _28083;
L2: 
        if (binary_op_a(LESS, _i_55584, _28084)){
            goto L3; // [35] 129
        }

        /** parser.e:416			n=break_delay[i]*/
        _2 = (object)SEQ_PTR(_43break_delay_55034);
        if (!IS_ATOM_INT(_i_55584)){
            _n_55579 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55584)->dbl));
        }
        else{
            _n_55579 = (object)*(((s1_ptr)_2)->base + _i_55584);
        }
        if (!IS_ATOM_INT(_n_55579))
        _n_55579 = (object)DBL_PTR(_n_55579)->dbl;

        /** parser.e:417			break_delay[i] -= (n>0)*/
        _28086 = (_n_55579 > 0LL);
        _2 = (object)SEQ_PTR(_43break_delay_55034);
        if (!IS_ATOM_INT(_i_55584)){
            _28087 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55584)->dbl));
        }
        else{
            _28087 = (object)*(((s1_ptr)_2)->base + _i_55584);
        }
        if (IS_ATOM_INT(_28087)) {
            _28088 = _28087 - _28086;
            if ((object)((uintptr_t)_28088 +(uintptr_t) HIGH_BITS) >= 0){
                _28088 = NewDouble((eudouble)_28088);
            }
        }
        else {
            _28088 = binary_op(MINUS, _28087, _28086);
        }
        _28087 = NOVALUE;
        _28086 = NOVALUE;
        _2 = (object)SEQ_PTR(_43break_delay_55034);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _43break_delay_55034 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_55584))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55584)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _i_55584);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _28088;
        if( _1 != _28088 ){
            DeRef(_1);
        }
        _28088 = NOVALUE;

        /** parser.e:418			if n>1 then*/
        if (_n_55579 <= 1LL)
        goto L4; // [72] 93

        /** parser.e:419				if break_top = 0 then*/
        if (_break_top_55578 != 0LL)
        goto L5; // [78] 122

        /** parser.e:420					break_top = i*/
        Ref(_i_55584);
        _break_top_55578 = _i_55584;
        if (!IS_ATOM_INT(_break_top_55578)) {
            _1 = (object)(DBL_PTR(_break_top_55578)->dbl);
            DeRefDS(_break_top_55578);
            _break_top_55578 = _1;
        }
        goto L5; // [90] 122
L4: 

        /** parser.e:422			elsif n=1 then*/
        if (_n_55579 != 1LL)
        goto L6; // [95] 121

        /** parser.e:423				backpatch(break_list[i],length(Code)+1)*/
        _2 = (object)SEQ_PTR(_43break_list_55033);
        if (!IS_ATOM_INT(_i_55584)){
            _28092 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55584)->dbl));
        }
        else{
            _28092 = (object)*(((s1_ptr)_2)->base + _i_55584);
        }
        if (IS_SEQUENCE(_12Code_20315)){
                _28093 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _28093 = 1;
        }
        _28094 = _28093 + 1;
        _28093 = NOVALUE;
        _45backpatch(_28092, _28094);
        _28092 = NOVALUE;
        _28094 = NOVALUE;
L6: 
L5: 

        /** parser.e:425		end for*/
        _0 = _i_55584;
        if (IS_ATOM_INT(_i_55584)) {
            _i_55584 = _i_55584 + -1LL;
            if ((object)((uintptr_t)_i_55584 +(uintptr_t) HIGH_BITS) >= 0){
                _i_55584 = NewDouble((eudouble)_i_55584);
            }
        }
        else {
            _i_55584 = binary_op_a(PLUS, _i_55584, -1LL);
        }
        DeRef(_0);
        goto L2; // [124] 42
L3: 
        ;
        DeRef(_i_55584);
    }

    /** parser.e:427		if break_top=0 then*/
    if (_break_top_55578 != 0LL)
    goto L7; // [131] 141

    /** parser.e:428		    break_top=base*/
    _break_top_55578 = _base_55577;
L7: 

    /** parser.e:431		break_delay = break_delay[1..break_top]*/
    rhs_slice_target = (object_ptr)&_43break_delay_55034;
    RHS_Slice(_43break_delay_55034, 1LL, _break_top_55578);

    /** parser.e:432		break_list = break_list[1..break_top]*/
    rhs_slice_target = (object_ptr)&_43break_list_55033;
    RHS_Slice(_43break_list_55033, 1LL, _break_top_55578);

    /** parser.e:433	end procedure*/
    DeRef(_28084);
    _28084 = NOVALUE;
    return;
    ;
}


void _43PatchNList(object _base_55608)
{
    object _next_top_55609 = NOVALUE;
    object _n_55610 = NOVALUE;
    object _28111 = NOVALUE;
    object _28110 = NOVALUE;
    object _28109 = NOVALUE;
    object _28105 = NOVALUE;
    object _28104 = NOVALUE;
    object _28103 = NOVALUE;
    object _28101 = NOVALUE;
    object _28100 = NOVALUE;
    object _28098 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:439		if not length(continue_list) then*/
    if (IS_SEQUENCE(_43continue_list_55037)){
            _28098 = SEQ_PTR(_43continue_list_55037)->length;
    }
    else {
        _28098 = 1;
    }
    if (_28098 != 0)
    goto L1; // [10] 19
    _28098 = NOVALUE;

    /** parser.e:440			return*/
    return;
L1: 

    /** parser.e:443		next_top = 0*/
    _next_top_55609 = 0LL;

    /** parser.e:445		for i=length(continue_list) to base+1 by -1 do*/
    if (IS_SEQUENCE(_43continue_list_55037)){
            _28100 = SEQ_PTR(_43continue_list_55037)->length;
    }
    else {
        _28100 = 1;
    }
    _28101 = _base_55608 + 1;
    if (_28101 > MAXINT){
        _28101 = NewDouble((eudouble)_28101);
    }
    {
        object _i_55615;
        _i_55615 = _28100;
L2: 
        if (binary_op_a(LESS, _i_55615, _28101)){
            goto L3; // [35] 129
        }

        /** parser.e:446			n=continue_delay[i]*/
        _2 = (object)SEQ_PTR(_43continue_delay_55038);
        if (!IS_ATOM_INT(_i_55615)){
            _n_55610 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55615)->dbl));
        }
        else{
            _n_55610 = (object)*(((s1_ptr)_2)->base + _i_55615);
        }
        if (!IS_ATOM_INT(_n_55610))
        _n_55610 = (object)DBL_PTR(_n_55610)->dbl;

        /** parser.e:447			continue_delay[i] -= (n>0)*/
        _28103 = (_n_55610 > 0LL);
        _2 = (object)SEQ_PTR(_43continue_delay_55038);
        if (!IS_ATOM_INT(_i_55615)){
            _28104 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55615)->dbl));
        }
        else{
            _28104 = (object)*(((s1_ptr)_2)->base + _i_55615);
        }
        if (IS_ATOM_INT(_28104)) {
            _28105 = _28104 - _28103;
            if ((object)((uintptr_t)_28105 +(uintptr_t) HIGH_BITS) >= 0){
                _28105 = NewDouble((eudouble)_28105);
            }
        }
        else {
            _28105 = binary_op(MINUS, _28104, _28103);
        }
        _28104 = NOVALUE;
        _28103 = NOVALUE;
        _2 = (object)SEQ_PTR(_43continue_delay_55038);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _43continue_delay_55038 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_55615))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55615)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _i_55615);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _28105;
        if( _1 != _28105 ){
            DeRef(_1);
        }
        _28105 = NOVALUE;

        /** parser.e:448			if n>1 then*/
        if (_n_55610 <= 1LL)
        goto L4; // [72] 93

        /** parser.e:449				if next_top = 0 then*/
        if (_next_top_55609 != 0LL)
        goto L5; // [78] 122

        /** parser.e:450					next_top = i*/
        Ref(_i_55615);
        _next_top_55609 = _i_55615;
        if (!IS_ATOM_INT(_next_top_55609)) {
            _1 = (object)(DBL_PTR(_next_top_55609)->dbl);
            DeRefDS(_next_top_55609);
            _next_top_55609 = _1;
        }
        goto L5; // [90] 122
L4: 

        /** parser.e:452			elsif n=1 then*/
        if (_n_55610 != 1LL)
        goto L6; // [95] 121

        /** parser.e:453				backpatch(continue_list[i],length(Code)+1)*/
        _2 = (object)SEQ_PTR(_43continue_list_55037);
        if (!IS_ATOM_INT(_i_55615)){
            _28109 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55615)->dbl));
        }
        else{
            _28109 = (object)*(((s1_ptr)_2)->base + _i_55615);
        }
        if (IS_SEQUENCE(_12Code_20315)){
                _28110 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _28110 = 1;
        }
        _28111 = _28110 + 1;
        _28110 = NOVALUE;
        _45backpatch(_28109, _28111);
        _28109 = NOVALUE;
        _28111 = NOVALUE;
L6: 
L5: 

        /** parser.e:455		end for*/
        _0 = _i_55615;
        if (IS_ATOM_INT(_i_55615)) {
            _i_55615 = _i_55615 + -1LL;
            if ((object)((uintptr_t)_i_55615 +(uintptr_t) HIGH_BITS) >= 0){
                _i_55615 = NewDouble((eudouble)_i_55615);
            }
        }
        else {
            _i_55615 = binary_op_a(PLUS, _i_55615, -1LL);
        }
        DeRef(_0);
        goto L2; // [124] 42
L3: 
        ;
        DeRef(_i_55615);
    }

    /** parser.e:457		if next_top=0 then*/
    if (_next_top_55609 != 0LL)
    goto L7; // [131] 141

    /** parser.e:458		    next_top=base*/
    _next_top_55609 = _base_55608;
L7: 

    /** parser.e:461		continue_delay =continue_delay[1..next_top]*/
    rhs_slice_target = (object_ptr)&_43continue_delay_55038;
    RHS_Slice(_43continue_delay_55038, 1LL, _next_top_55609);

    /** parser.e:462		continue_list = continue_list[1..next_top]*/
    rhs_slice_target = (object_ptr)&_43continue_list_55037;
    RHS_Slice(_43continue_list_55037, 1LL, _next_top_55609);

    /** parser.e:463	end procedure*/
    DeRef(_28101);
    _28101 = NOVALUE;
    return;
    ;
}


void _43PatchXList(object _base_55639)
{
    object _exit_top_55640 = NOVALUE;
    object _n_55641 = NOVALUE;
    object _28128 = NOVALUE;
    object _28127 = NOVALUE;
    object _28126 = NOVALUE;
    object _28122 = NOVALUE;
    object _28121 = NOVALUE;
    object _28120 = NOVALUE;
    object _28118 = NOVALUE;
    object _28117 = NOVALUE;
    object _28115 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:469		if not length(exit_list) then*/
    if (IS_SEQUENCE(_43exit_list_55035)){
            _28115 = SEQ_PTR(_43exit_list_55035)->length;
    }
    else {
        _28115 = 1;
    }
    if (_28115 != 0)
    goto L1; // [10] 19
    _28115 = NOVALUE;

    /** parser.e:470			return*/
    return;
L1: 

    /** parser.e:473		exit_top = 0*/
    _exit_top_55640 = 0LL;

    /** parser.e:475		for i=length(exit_list) to base+1 by -1 do*/
    if (IS_SEQUENCE(_43exit_list_55035)){
            _28117 = SEQ_PTR(_43exit_list_55035)->length;
    }
    else {
        _28117 = 1;
    }
    _28118 = _base_55639 + 1;
    if (_28118 > MAXINT){
        _28118 = NewDouble((eudouble)_28118);
    }
    {
        object _i_55646;
        _i_55646 = _28117;
L2: 
        if (binary_op_a(LESS, _i_55646, _28118)){
            goto L3; // [35] 129
        }

        /** parser.e:476			n=exit_delay[i]*/
        _2 = (object)SEQ_PTR(_43exit_delay_55036);
        if (!IS_ATOM_INT(_i_55646)){
            _n_55641 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55646)->dbl));
        }
        else{
            _n_55641 = (object)*(((s1_ptr)_2)->base + _i_55646);
        }
        if (!IS_ATOM_INT(_n_55641))
        _n_55641 = (object)DBL_PTR(_n_55641)->dbl;

        /** parser.e:477			exit_delay[i] -= (n>0)*/
        _28120 = (_n_55641 > 0LL);
        _2 = (object)SEQ_PTR(_43exit_delay_55036);
        if (!IS_ATOM_INT(_i_55646)){
            _28121 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55646)->dbl));
        }
        else{
            _28121 = (object)*(((s1_ptr)_2)->base + _i_55646);
        }
        if (IS_ATOM_INT(_28121)) {
            _28122 = _28121 - _28120;
            if ((object)((uintptr_t)_28122 +(uintptr_t) HIGH_BITS) >= 0){
                _28122 = NewDouble((eudouble)_28122);
            }
        }
        else {
            _28122 = binary_op(MINUS, _28121, _28120);
        }
        _28121 = NOVALUE;
        _28120 = NOVALUE;
        _2 = (object)SEQ_PTR(_43exit_delay_55036);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _43exit_delay_55036 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_55646))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55646)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _i_55646);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _28122;
        if( _1 != _28122 ){
            DeRef(_1);
        }
        _28122 = NOVALUE;

        /** parser.e:478			if n>1 then*/
        if (_n_55641 <= 1LL)
        goto L4; // [72] 93

        /** parser.e:479				if exit_top = 0 then*/
        if (_exit_top_55640 != 0LL)
        goto L5; // [78] 122

        /** parser.e:480					exit_top = i*/
        Ref(_i_55646);
        _exit_top_55640 = _i_55646;
        if (!IS_ATOM_INT(_exit_top_55640)) {
            _1 = (object)(DBL_PTR(_exit_top_55640)->dbl);
            DeRefDS(_exit_top_55640);
            _exit_top_55640 = _1;
        }
        goto L5; // [90] 122
L4: 

        /** parser.e:482			elsif n=1 then*/
        if (_n_55641 != 1LL)
        goto L6; // [95] 121

        /** parser.e:483				backpatch(exit_list[i],length(Code)+1)*/
        _2 = (object)SEQ_PTR(_43exit_list_55035);
        if (!IS_ATOM_INT(_i_55646)){
            _28126 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55646)->dbl));
        }
        else{
            _28126 = (object)*(((s1_ptr)_2)->base + _i_55646);
        }
        if (IS_SEQUENCE(_12Code_20315)){
                _28127 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _28127 = 1;
        }
        _28128 = _28127 + 1;
        _28127 = NOVALUE;
        _45backpatch(_28126, _28128);
        _28126 = NOVALUE;
        _28128 = NOVALUE;
L6: 
L5: 

        /** parser.e:485		end for*/
        _0 = _i_55646;
        if (IS_ATOM_INT(_i_55646)) {
            _i_55646 = _i_55646 + -1LL;
            if ((object)((uintptr_t)_i_55646 +(uintptr_t) HIGH_BITS) >= 0){
                _i_55646 = NewDouble((eudouble)_i_55646);
            }
        }
        else {
            _i_55646 = binary_op_a(PLUS, _i_55646, -1LL);
        }
        DeRef(_0);
        goto L2; // [124] 42
L3: 
        ;
        DeRef(_i_55646);
    }

    /** parser.e:487		if exit_top=0 then*/
    if (_exit_top_55640 != 0LL)
    goto L7; // [131] 141

    /** parser.e:488		    exit_top=base*/
    _exit_top_55640 = _base_55639;
L7: 

    /** parser.e:491		exit_delay = exit_delay [1..exit_top]*/
    rhs_slice_target = (object_ptr)&_43exit_delay_55036;
    RHS_Slice(_43exit_delay_55036, 1LL, _exit_top_55640);

    /** parser.e:492		exit_list = exit_list [1..exit_top]*/
    rhs_slice_target = (object_ptr)&_43exit_list_55035;
    RHS_Slice(_43exit_list_55035, 1LL, _exit_top_55640);

    /** parser.e:493	end procedure*/
    DeRef(_28118);
    _28118 = NOVALUE;
    return;
    ;
}


void _43putback(object _t_55671)
{
    object _28133 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:497		backed_up_tok = append(backed_up_tok, t)*/
    Ref(_t_55671);
    Append(&_43backed_up_tok_55022, _43backed_up_tok_55022, _t_55671);

    /** parser.e:499		if t[T_SYM] then*/
    _2 = (object)SEQ_PTR(_t_55671);
    _28133 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (_28133 == 0) {
        _28133 = NOVALUE;
        goto L1; // [17] 79
    }
    else {
        if (!IS_ATOM_INT(_28133) && DBL_PTR(_28133)->dbl == 0.0){
            _28133 = NOVALUE;
            goto L1; // [17] 79
        }
        _28133 = NOVALUE;
    }
    _28133 = NOVALUE;

    /** parser.e:500			putback_ForwardLine     = ForwardLine*/
    Ref(_49ForwardLine_49313);
    DeRef(_49putback_ForwardLine_49314);
    _49putback_ForwardLine_49314 = _49ForwardLine_49313;

    /** parser.e:501			putback_forward_bp      = forward_bp*/
    _49putback_forward_bp_49318 = _49forward_bp_49317;

    /** parser.e:502			putback_fwd_line_number = fwd_line_number*/
    _12putback_fwd_line_number_20229 = _12fwd_line_number_20228;

    /** parser.e:504			if last_fwd_line_number then*/
    if (_12last_fwd_line_number_20230 == 0)
    {
        goto L2; // [49] 78
    }
    else{
    }

    /** parser.e:505				ForwardLine     = last_ForwardLine*/
    Ref(_49last_ForwardLine_49315);
    DeRef(_49ForwardLine_49313);
    _49ForwardLine_49313 = _49last_ForwardLine_49315;

    /** parser.e:506				forward_bp      = last_forward_bp*/
    _49forward_bp_49317 = _49last_forward_bp_49319;

    /** parser.e:507				fwd_line_number = last_fwd_line_number*/
    _12fwd_line_number_20228 = _12last_fwd_line_number_20230;
L2: 
L1: 

    /** parser.e:510	end procedure*/
    DeRef(_t_55671);
    return;
    ;
}


void _43start_recording()
{
    object _0, _1, _2;
    

    /** parser.e:519		psm_stack &= Parser_mode*/
    Append(&_43psm_stack_55690, _43psm_stack_55690, _12Parser_mode_20332);

    /** parser.e:520		can_stack = append(can_stack,canned_tokens)*/
    Ref(_43canned_tokens_55059);
    Append(&_43can_stack_55691, _43can_stack_55691, _43canned_tokens_55059);

    /** parser.e:521		idx_stack &= canned_index*/
    Append(&_43idx_stack_55692, _43idx_stack_55692, _43canned_index_55060);

    /** parser.e:522		tok_stack = append(tok_stack,backed_up_tok)*/
    RefDS(_43backed_up_tok_55022);
    Append(&_43tok_stack_55693, _43tok_stack_55693, _43backed_up_tok_55022);

    /** parser.e:523		canned_tokens = {}*/
    RefDS(_22024);
    DeRef(_43canned_tokens_55059);
    _43canned_tokens_55059 = _22024;

    /** parser.e:524		Parser_mode = PAM_RECORD*/
    _12Parser_mode_20332 = 1LL;

    /** parser.e:525		clear_last()*/
    _45clear_last();

    /** parser.e:526	end procedure*/
    return;
    ;
}


object _43restore_parser()
{
    object _n_55706 = NOVALUE;
    object _tok_55707 = NOVALUE;
    object _x_55708 = NOVALUE;
    object _28164 = NOVALUE;
    object _28163 = NOVALUE;
    object _28162 = NOVALUE;
    object _28160 = NOVALUE;
    object _28156 = NOVALUE;
    object _28155 = NOVALUE;
    object _28153 = NOVALUE;
    object _28151 = NOVALUE;
    object _28150 = NOVALUE;
    object _28148 = NOVALUE;
    object _28146 = NOVALUE;
    object _28145 = NOVALUE;
    object _28143 = NOVALUE;
    object _28141 = NOVALUE;
    object _28140 = NOVALUE;
    object _28138 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:533		n=Parser_mode*/
    _n_55706 = _12Parser_mode_20332;

    /** parser.e:534		x = canned_tokens*/
    Ref(_43canned_tokens_55059);
    DeRef(_x_55708);
    _x_55708 = _43canned_tokens_55059;

    /** parser.e:535		canned_tokens = can_stack[$]*/
    if (IS_SEQUENCE(_43can_stack_55691)){
            _28138 = SEQ_PTR(_43can_stack_55691)->length;
    }
    else {
        _28138 = 1;
    }
    DeRef(_43canned_tokens_55059);
    _2 = (object)SEQ_PTR(_43can_stack_55691);
    _43canned_tokens_55059 = (object)*(((s1_ptr)_2)->base + _28138);
    Ref(_43canned_tokens_55059);

    /** parser.e:536		can_stack     = can_stack[1..$-1]*/
    if (IS_SEQUENCE(_43can_stack_55691)){
            _28140 = SEQ_PTR(_43can_stack_55691)->length;
    }
    else {
        _28140 = 1;
    }
    _28141 = _28140 - 1LL;
    _28140 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43can_stack_55691;
    RHS_Slice(_43can_stack_55691, 1LL, _28141);

    /** parser.e:537		canned_index  = idx_stack[$]*/
    if (IS_SEQUENCE(_43idx_stack_55692)){
            _28143 = SEQ_PTR(_43idx_stack_55692)->length;
    }
    else {
        _28143 = 1;
    }
    _2 = (object)SEQ_PTR(_43idx_stack_55692);
    _43canned_index_55060 = (object)*(((s1_ptr)_2)->base + _28143);

    /** parser.e:538		idx_stack     = idx_stack[1..$-1]*/
    if (IS_SEQUENCE(_43idx_stack_55692)){
            _28145 = SEQ_PTR(_43idx_stack_55692)->length;
    }
    else {
        _28145 = 1;
    }
    _28146 = _28145 - 1LL;
    _28145 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43idx_stack_55692;
    RHS_Slice(_43idx_stack_55692, 1LL, _28146);

    /** parser.e:539		Parser_mode   = psm_stack[$]*/
    if (IS_SEQUENCE(_43psm_stack_55690)){
            _28148 = SEQ_PTR(_43psm_stack_55690)->length;
    }
    else {
        _28148 = 1;
    }
    _2 = (object)SEQ_PTR(_43psm_stack_55690);
    _12Parser_mode_20332 = (object)*(((s1_ptr)_2)->base + _28148);

    /** parser.e:540		psm_stack     = psm_stack[1..$-1]*/
    if (IS_SEQUENCE(_43psm_stack_55690)){
            _28150 = SEQ_PTR(_43psm_stack_55690)->length;
    }
    else {
        _28150 = 1;
    }
    _28151 = _28150 - 1LL;
    _28150 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43psm_stack_55690;
    RHS_Slice(_43psm_stack_55690, 1LL, _28151);

    /** parser.e:541		tok 		  = tok_stack[$]*/
    if (IS_SEQUENCE(_43tok_stack_55693)){
            _28153 = SEQ_PTR(_43tok_stack_55693)->length;
    }
    else {
        _28153 = 1;
    }
    DeRef(_tok_55707);
    _2 = (object)SEQ_PTR(_43tok_stack_55693);
    _tok_55707 = (object)*(((s1_ptr)_2)->base + _28153);
    RefDS(_tok_55707);

    /** parser.e:542		tok_stack 	  = tok_stack[1..$-1]*/
    if (IS_SEQUENCE(_43tok_stack_55693)){
            _28155 = SEQ_PTR(_43tok_stack_55693)->length;
    }
    else {
        _28155 = 1;
    }
    _28156 = _28155 - 1LL;
    _28155 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43tok_stack_55693;
    RHS_Slice(_43tok_stack_55693, 1LL, _28156);

    /** parser.e:543		clear_last()*/
    _45clear_last();

    /** parser.e:544		if n=PAM_PLAYBACK then*/
    if (_n_55706 != -1LL)
    goto L1; // [137] 150

    /** parser.e:545			return {}*/
    RefDS(_22024);
    DeRefDS(_tok_55707);
    DeRefDS(_x_55708);
    _28146 = NOVALUE;
    _28151 = NOVALUE;
    _28156 = NOVALUE;
    _28141 = NOVALUE;
    return _22024;
    goto L2; // [147] 167
L1: 

    /** parser.e:547		elsif n = PAM_NORMAL then*/
    if (_n_55706 != 0LL)
    goto L3; // [154] 166

    /** parser.e:548			use_private_list = 0*/
    _12use_private_list_20340 = 0LL;
L3: 
L2: 

    /** parser.e:550		if length(backed_up_tok) > 0 then*/
    if (IS_SEQUENCE(_43backed_up_tok_55022)){
            _28160 = SEQ_PTR(_43backed_up_tok_55022)->length;
    }
    else {
        _28160 = 1;
    }
    if (_28160 <= 0LL)
    goto L4; // [174] 199

    /** parser.e:551			return x[1..$-1]*/
    if (IS_SEQUENCE(_x_55708)){
            _28162 = SEQ_PTR(_x_55708)->length;
    }
    else {
        _28162 = 1;
    }
    _28163 = _28162 - 1LL;
    _28162 = NOVALUE;
    rhs_slice_target = (object_ptr)&_28164;
    RHS_Slice(_x_55708, 1LL, _28163);
    DeRef(_tok_55707);
    DeRefDS(_x_55708);
    _28163 = NOVALUE;
    DeRef(_28146);
    _28146 = NOVALUE;
    DeRef(_28151);
    _28151 = NOVALUE;
    DeRef(_28156);
    _28156 = NOVALUE;
    DeRef(_28141);
    _28141 = NOVALUE;
    return _28164;
    goto L5; // [196] 206
L4: 

    /** parser.e:553			return x*/
    DeRef(_tok_55707);
    DeRef(_28164);
    _28164 = NOVALUE;
    DeRef(_28163);
    _28163 = NOVALUE;
    DeRef(_28146);
    _28146 = NOVALUE;
    DeRef(_28151);
    _28151 = NOVALUE;
    DeRef(_28156);
    _28156 = NOVALUE;
    DeRef(_28141);
    _28141 = NOVALUE;
    return _x_55708;
L5: 
    ;
}


void _43start_playback(object _s_55748)
{
    object _0, _1, _2;
    

    /** parser.e:558		psm_stack &= Parser_mode*/
    Append(&_43psm_stack_55690, _43psm_stack_55690, _12Parser_mode_20332);

    /** parser.e:559		can_stack = append(can_stack,canned_tokens)*/
    Ref(_43canned_tokens_55059);
    Append(&_43can_stack_55691, _43can_stack_55691, _43canned_tokens_55059);

    /** parser.e:560		idx_stack &= canned_index*/
    Append(&_43idx_stack_55692, _43idx_stack_55692, _43canned_index_55060);

    /** parser.e:561		tok_stack = append(tok_stack,backed_up_tok)*/
    RefDS(_43backed_up_tok_55022);
    Append(&_43tok_stack_55693, _43tok_stack_55693, _43backed_up_tok_55022);

    /** parser.e:562		canned_index = 1*/
    _43canned_index_55060 = 1LL;

    /** parser.e:563		canned_tokens = s*/
    RefDS(_s_55748);
    DeRef(_43canned_tokens_55059);
    _43canned_tokens_55059 = _s_55748;

    /** parser.e:564		backed_up_tok = {}*/
    RefDS(_22024);
    DeRefDS(_43backed_up_tok_55022);
    _43backed_up_tok_55022 = _22024;

    /** parser.e:565		Parser_mode = PAM_PLAYBACK*/
    _12Parser_mode_20332 = -1LL;

    /** parser.e:566	end procedure*/
    DeRefDS(_s_55748);
    return;
    ;
}


void _43restore_parseargs_states()
{
    object _s_55767 = NOVALUE;
    object _n_55768 = NOVALUE;
    object _28181 = NOVALUE;
    object _28180 = NOVALUE;
    object _28172 = NOVALUE;
    object _28171 = NOVALUE;
    object _28169 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:584		s = parseargs_states[$]*/
    if (IS_SEQUENCE(_43parseargs_states_55756)){
            _28169 = SEQ_PTR(_43parseargs_states_55756)->length;
    }
    else {
        _28169 = 1;
    }
    DeRef(_s_55767);
    _2 = (object)SEQ_PTR(_43parseargs_states_55756);
    _s_55767 = (object)*(((s1_ptr)_2)->base + _28169);
    RefDS(_s_55767);

    /** parser.e:585		parseargs_states = parseargs_states[1..$-1]*/
    if (IS_SEQUENCE(_43parseargs_states_55756)){
            _28171 = SEQ_PTR(_43parseargs_states_55756)->length;
    }
    else {
        _28171 = 1;
    }
    _28172 = _28171 - 1LL;
    _28171 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43parseargs_states_55756;
    RHS_Slice(_43parseargs_states_55756, 1LL, _28172);

    /** parser.e:586		n=s[PS_POSITION]*/
    _2 = (object)SEQ_PTR(_s_55767);
    _n_55768 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_n_55768))
    _n_55768 = (object)DBL_PTR(_n_55768)->dbl;

    /** parser.e:587		private_list = private_list[1..n]*/
    rhs_slice_target = (object_ptr)&_43private_list_55761;
    RHS_Slice(_43private_list_55761, 1LL, _n_55768);

    /** parser.e:588		private_sym = private_sym[1..n]*/
    rhs_slice_target = (object_ptr)&_12private_sym_20339;
    RHS_Slice(_12private_sym_20339, 1LL, _n_55768);

    /** parser.e:589		lock_scanner = s[PS_SCAN_LOCK]*/
    _2 = (object)SEQ_PTR(_s_55767);
    _43lock_scanner_55762 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_43lock_scanner_55762))
    _43lock_scanner_55762 = (object)DBL_PTR(_43lock_scanner_55762)->dbl;

    /** parser.e:590		use_private_list = s[PS_USE_LIST]*/
    _2 = (object)SEQ_PTR(_s_55767);
    _12use_private_list_20340 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_12use_private_list_20340)){
        _12use_private_list_20340 = (object)DBL_PTR(_12use_private_list_20340)->dbl;
    }

    /** parser.e:591		on_arg = s[PS_ON_ARG]*/
    _2 = (object)SEQ_PTR(_s_55767);
    _43on_arg_55763 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_43on_arg_55763))
    _43on_arg_55763 = (object)DBL_PTR(_43on_arg_55763)->dbl;

    /** parser.e:592		nested_calls = nested_calls[1..$-1]*/
    if (IS_SEQUENCE(_43nested_calls_55764)){
            _28180 = SEQ_PTR(_43nested_calls_55764)->length;
    }
    else {
        _28180 = 1;
    }
    _28181 = _28180 - 1LL;
    _28180 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43nested_calls_55764;
    RHS_Slice(_43nested_calls_55764, 1LL, _28181);

    /** parser.e:593	end procedure*/
    DeRefDS(_s_55767);
    _28181 = NOVALUE;
    _28172 = NOVALUE;
    return;
    ;
}


object _43read_recorded_token(object _n_55788)
{
    object _t_55790 = NOVALUE;
    object _p_55791 = NOVALUE;
    object _prev_Nne_55792 = NOVALUE;
    object _ts_55821 = NOVALUE;
    object _31789 = NOVALUE;
    object _31788 = NOVALUE;
    object _31787 = NOVALUE;
    object _31786 = NOVALUE;
    object _31785 = NOVALUE;
    object _31784 = NOVALUE;
    object _31783 = NOVALUE;
    object _31782 = NOVALUE;
    object _28253 = NOVALUE;
    object _28252 = NOVALUE;
    object _28251 = NOVALUE;
    object _28250 = NOVALUE;
    object _28246 = NOVALUE;
    object _28244 = NOVALUE;
    object _28243 = NOVALUE;
    object _28242 = NOVALUE;
    object _28241 = NOVALUE;
    object _28239 = NOVALUE;
    object _28238 = NOVALUE;
    object _28237 = NOVALUE;
    object _28236 = NOVALUE;
    object _28234 = NOVALUE;
    object _28231 = NOVALUE;
    object _28229 = NOVALUE;
    object _28227 = NOVALUE;
    object _28226 = NOVALUE;
    object _28225 = NOVALUE;
    object _28224 = NOVALUE;
    object _28222 = NOVALUE;
    object _28220 = NOVALUE;
    object _28216 = NOVALUE;
    object _28214 = NOVALUE;
    object _28212 = NOVALUE;
    object _28211 = NOVALUE;
    object _28210 = NOVALUE;
    object _28209 = NOVALUE;
    object _28208 = NOVALUE;
    object _28207 = NOVALUE;
    object _28206 = NOVALUE;
    object _28205 = NOVALUE;
    object _28204 = NOVALUE;
    object _28203 = NOVALUE;
    object _28202 = NOVALUE;
    object _28201 = NOVALUE;
    object _28199 = NOVALUE;
    object _28198 = NOVALUE;
    object _28196 = NOVALUE;
    object _28195 = NOVALUE;
    object _28194 = NOVALUE;
    object _28193 = NOVALUE;
    object _28192 = NOVALUE;
    object _28191 = NOVALUE;
    object _28190 = NOVALUE;
    object _28189 = NOVALUE;
    object _28186 = NOVALUE;
    object _28184 = NOVALUE;
    object _28183 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_n_55788)) {
        _1 = (object)(DBL_PTR(_n_55788)->dbl);
        DeRefDS(_n_55788);
        _n_55788 = _1;
    }

    /** parser.e:597		integer p, prev_Nne*/

    /** parser.e:598		if atom(Ns_recorded[n]) label "top if" then*/
    _2 = (object)SEQ_PTR(_12Ns_recorded_20334);
    _28183 = (object)*(((s1_ptr)_2)->base + _n_55788);
    _28184 = IS_ATOM(_28183);
    _28183 = NOVALUE;
    if (_28184 == 0)
    {
        _28184 = NOVALUE;
        goto L1; // [16] 405
    }
    else{
        _28184 = NOVALUE;
    }

    /** parser.e:599			if use_private_list then*/
    if (_12use_private_list_20340 == 0)
    {
        goto L2; // [23] 171
    }
    else{
    }

    /** parser.e:600				p = find( Recorded[n], private_list)*/
    _2 = (object)SEQ_PTR(_12Recorded_20333);
    _28186 = (object)*(((s1_ptr)_2)->base + _n_55788);
    _p_55791 = find_from(_28186, _43private_list_55761, 1LL);
    _28186 = NOVALUE;

    /** parser.e:601				if p > 0 then -- the value of this parameter is known, use it*/
    if (_p_55791 <= 0LL)
    goto L3; // [43] 170

    /** parser.e:603					if TRANSLATE*/
    if (_12TRANSLATE_19834 == 0) {
        goto L4; // [51] 150
    }
    _2 = (object)SEQ_PTR(_12private_sym_20339);
    _28190 = (object)*(((s1_ptr)_2)->base + _p_55791);
    if (IS_ATOM_INT(_28190)) {
        _28191 = (_28190 < 0LL);
    }
    else {
        _28191 = binary_op(LESS, _28190, 0LL);
    }
    _28190 = NOVALUE;
    if (IS_ATOM_INT(_28191)) {
        if (_28191 != 0) {
            _28192 = 1;
            goto L5; // [65] 97
        }
    }
    else {
        if (DBL_PTR(_28191)->dbl != 0.0) {
            _28192 = 1;
            goto L5; // [65] 97
        }
    }
    _2 = (object)SEQ_PTR(_12private_sym_20339);
    _28193 = (object)*(((s1_ptr)_2)->base + _p_55791);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28193)){
        _28194 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28193)->dbl));
    }
    else{
        _28194 = (object)*(((s1_ptr)_2)->base + _28193);
    }
    _2 = (object)SEQ_PTR(_28194);
    _28195 = (object)*(((s1_ptr)_2)->base + 3LL);
    _28194 = NOVALUE;
    if (IS_ATOM_INT(_28195)) {
        _28196 = (_28195 == 3LL);
    }
    else {
        _28196 = binary_op(EQUALS, _28195, 3LL);
    }
    _28195 = NOVALUE;
    DeRef(_28192);
    if (IS_ATOM_INT(_28196))
    _28192 = (_28196 != 0);
    else
    _28192 = DBL_PTR(_28196)->dbl != 0.0;
L5: 
    if (_28192 == 0)
    {
        _28192 = NOVALUE;
        goto L4; // [98] 150
    }
    else{
        _28192 = NOVALUE;
    }

    /** parser.e:610						symtab_index ts = NewTempSym()*/
    _ts_55821 = _53NewTempSym(0LL);
    if (!IS_ATOM_INT(_ts_55821)) {
        _1 = (object)(DBL_PTR(_ts_55821)->dbl);
        DeRefDS(_ts_55821);
        _ts_55821 = _1;
    }

    /** parser.e:611						Code &= { ASSIGN, private_sym[p], ts }*/
    _2 = (object)SEQ_PTR(_12private_sym_20339);
    _28198 = (object)*(((s1_ptr)_2)->base + _p_55791);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 18LL;
    Ref(_28198);
    ((intptr_t*)_2)[2] = _28198;
    ((intptr_t*)_2)[3] = _ts_55821;
    _28199 = MAKE_SEQ(_1);
    _28198 = NOVALUE;
    Concat((object_ptr)&_12Code_20315, _12Code_20315, _28199);
    DeRefDS(_28199);
    _28199 = NOVALUE;

    /** parser.e:612						return {VARIABLE, ts}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100LL;
    ((intptr_t *)_2)[2] = _ts_55821;
    _28201 = MAKE_SEQ(_1);
    DeRef(_t_55790);
    DeRef(_28196);
    _28196 = NOVALUE;
    _28193 = NOVALUE;
    DeRef(_28191);
    _28191 = NOVALUE;
    return _28201;
    goto L6; // [147] 169
L4: 

    /** parser.e:614						return {VARIABLE, private_sym[p]}*/
    _2 = (object)SEQ_PTR(_12private_sym_20339);
    _28202 = (object)*(((s1_ptr)_2)->base + _p_55791);
    Ref(_28202);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100LL;
    ((intptr_t *)_2)[2] = _28202;
    _28203 = MAKE_SEQ(_1);
    _28202 = NOVALUE;
    DeRef(_t_55790);
    DeRef(_28196);
    _28196 = NOVALUE;
    DeRef(_28201);
    _28201 = NOVALUE;
    _28193 = NOVALUE;
    DeRef(_28191);
    _28191 = NOVALUE;
    return _28203;
L6: 
L3: 
L2: 

    /** parser.e:620			prev_Nne = No_new_entry*/
    _prev_Nne_55792 = _53No_new_entry_48046;

    /** parser.e:621			No_new_entry = 1*/
    _53No_new_entry_48046 = 1LL;

    /** parser.e:623			if Recorded_sym[n] > 0 and  sym_scope( Recorded_sym[n] ) != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_12Recorded_sym_20335);
    _28204 = (object)*(((s1_ptr)_2)->base + _n_55788);
    if (IS_ATOM_INT(_28204)) {
        _28205 = (_28204 > 0LL);
    }
    else {
        _28205 = binary_op(GREATER, _28204, 0LL);
    }
    _28204 = NOVALUE;
    if (IS_ATOM_INT(_28205)) {
        if (_28205 == 0) {
            goto L7; // [199] 250
        }
    }
    else {
        if (DBL_PTR(_28205)->dbl == 0.0) {
            goto L7; // [199] 250
        }
    }
    _2 = (object)SEQ_PTR(_12Recorded_sym_20335);
    _28207 = (object)*(((s1_ptr)_2)->base + _n_55788);
    Ref(_28207);
    _28208 = _53sym_scope(_28207);
    _28207 = NOVALUE;
    if (IS_ATOM_INT(_28208)) {
        _28209 = (_28208 != 9LL);
    }
    else {
        _28209 = binary_op(NOTEQ, _28208, 9LL);
    }
    DeRef(_28208);
    _28208 = NOVALUE;
    if (_28209 == 0) {
        DeRef(_28209);
        _28209 = NOVALUE;
        goto L7; // [220] 250
    }
    else {
        if (!IS_ATOM_INT(_28209) && DBL_PTR(_28209)->dbl == 0.0){
            DeRef(_28209);
            _28209 = NOVALUE;
            goto L7; // [220] 250
        }
        DeRef(_28209);
        _28209 = NOVALUE;
    }
    DeRef(_28209);
    _28209 = NOVALUE;

    /** parser.e:624				t = { sym_token( Recorded_sym[n] ), Recorded_sym[n] }*/
    _2 = (object)SEQ_PTR(_12Recorded_sym_20335);
    _28210 = (object)*(((s1_ptr)_2)->base + _n_55788);
    Ref(_28210);
    _28211 = _53sym_token(_28210);
    _28210 = NOVALUE;
    _2 = (object)SEQ_PTR(_12Recorded_sym_20335);
    _28212 = (object)*(((s1_ptr)_2)->base + _n_55788);
    Ref(_28212);
    DeRef(_t_55790);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28211;
    ((intptr_t *)_2)[2] = _28212;
    _t_55790 = MAKE_SEQ(_1);
    _28212 = NOVALUE;
    _28211 = NOVALUE;

    /** parser.e:625				break "top if"*/
    goto L8; // [247] 734
L7: 

    /** parser.e:628			t = keyfind(Recorded[n],-1)*/
    _2 = (object)SEQ_PTR(_12Recorded_20333);
    _28214 = (object)*(((s1_ptr)_2)->base + _n_55788);
    RefDS(_28214);
    DeRef(_31788);
    _31788 = _28214;
    _31789 = _53hashfn(_31788);
    _31788 = NOVALUE;
    RefDS(_28214);
    _0 = _t_55790;
    _t_55790 = _53keyfind(_28214, -1LL, _12current_file_no_20226, 0LL, _31789);
    DeRef(_0);
    _28214 = NOVALUE;
    _31789 = NOVALUE;

    /** parser.e:629			if t[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_t_55790);
    _28216 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28216, 509LL)){
        _28216 = NOVALUE;
        goto L8; // [286] 734
    }
    _28216 = NOVALUE;

    /** parser.e:630		        p = Recorded_sym[n]*/
    _2 = (object)SEQ_PTR(_12Recorded_sym_20335);
    _p_55791 = (object)*(((s1_ptr)_2)->base + _n_55788);
    if (!IS_ATOM_INT(_p_55791)){
        _p_55791 = (object)DBL_PTR(_p_55791)->dbl;
    }

    /** parser.e:631		        if p = 0 then*/
    if (_p_55791 != 0LL)
    goto L9; // [302] 382

    /** parser.e:633					No_new_entry = 0*/
    _53No_new_entry_48046 = 0LL;

    /** parser.e:634					t = keyfind( Recorded[n], -1 )*/
    _2 = (object)SEQ_PTR(_12Recorded_20333);
    _28220 = (object)*(((s1_ptr)_2)->base + _n_55788);
    RefDS(_28220);
    DeRef(_31786);
    _31786 = _28220;
    _31787 = _53hashfn(_31786);
    _31786 = NOVALUE;
    RefDS(_28220);
    _0 = _t_55790;
    _t_55790 = _53keyfind(_28220, -1LL, _12current_file_no_20226, 0LL, _31787);
    DeRef(_0);
    _28220 = NOVALUE;
    _31787 = NOVALUE;

    /** parser.e:635					No_new_entry = 1*/
    _53No_new_entry_48046 = 1LL;

    /** parser.e:636					if t[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_t_55790);
    _28222 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28222, 509LL)){
        _28222 = NOVALUE;
        goto L8; // [355] 734
    }
    _28222 = NOVALUE;

    /** parser.e:637						CompileErr(VARIABLE_1_HAS_NOT_BEEN_DECLARED,{Recorded[n]})*/
    _2 = (object)SEQ_PTR(_12Recorded_20333);
    _28224 = (object)*(((s1_ptr)_2)->base + _n_55788);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_28224);
    ((intptr_t*)_2)[1] = _28224;
    _28225 = MAKE_SEQ(_1);
    _28224 = NOVALUE;
    _49CompileErr(157LL, _28225, 0LL);
    _28225 = NOVALUE;
    goto L8; // [379] 734
L9: 

    /** parser.e:640					t = {SymTab[p][S_TOKEN], p}*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28226 = (object)*(((s1_ptr)_2)->base + _p_55791);
    _2 = (object)SEQ_PTR(_28226);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _28227 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _28227 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _28226 = NOVALUE;
    Ref(_28227);
    DeRef(_t_55790);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28227;
    ((intptr_t *)_2)[2] = _p_55791;
    _t_55790 = MAKE_SEQ(_1);
    _28227 = NOVALUE;
    goto L8; // [402] 734
L1: 

    /** parser.e:644			prev_Nne = No_new_entry*/
    _prev_Nne_55792 = _53No_new_entry_48046;

    /** parser.e:645			No_new_entry = 1*/
    _53No_new_entry_48046 = 1LL;

    /** parser.e:646			t = keyfind(Ns_recorded[n],-1, , 1)*/
    _2 = (object)SEQ_PTR(_12Ns_recorded_20334);
    _28229 = (object)*(((s1_ptr)_2)->base + _n_55788);
    Ref(_28229);
    DeRef(_31784);
    _31784 = _28229;
    _31785 = _53hashfn(_31784);
    _31784 = NOVALUE;
    Ref(_28229);
    _0 = _t_55790;
    _t_55790 = _53keyfind(_28229, -1LL, _12current_file_no_20226, 1LL, _31785);
    DeRef(_0);
    _28229 = NOVALUE;
    _31785 = NOVALUE;

    /** parser.e:647			if t[T_ID] != NAMESPACE then*/
    _2 = (object)SEQ_PTR(_t_55790);
    _28231 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _28231, 523LL)){
        _28231 = NOVALUE;
        goto LA; // [456] 524
    }
    _28231 = NOVALUE;

    /** parser.e:648				p = Ns_recorded_sym[n]*/
    _2 = (object)SEQ_PTR(_12Ns_recorded_sym_20336);
    _p_55791 = (object)*(((s1_ptr)_2)->base + _n_55788);
    if (!IS_ATOM_INT(_p_55791)){
        _p_55791 = (object)DBL_PTR(_p_55791)->dbl;
    }

    /** parser.e:649				if p = 0 or sym_token( p ) != NAMESPACE then*/
    _28234 = (_p_55791 == 0LL);
    if (_28234 != 0) {
        goto LB; // [476] 495
    }
    _28236 = _53sym_token(_p_55791);
    if (IS_ATOM_INT(_28236)) {
        _28237 = (_28236 != 523LL);
    }
    else {
        _28237 = binary_op(NOTEQ, _28236, 523LL);
    }
    DeRef(_28236);
    _28236 = NOVALUE;
    if (_28237 == 0) {
        DeRef(_28237);
        _28237 = NOVALUE;
        goto LC; // [491] 515
    }
    else {
        if (!IS_ATOM_INT(_28237) && DBL_PTR(_28237)->dbl == 0.0){
            DeRef(_28237);
            _28237 = NOVALUE;
            goto LC; // [491] 515
        }
        DeRef(_28237);
        _28237 = NOVALUE;
    }
    DeRef(_28237);
    _28237 = NOVALUE;
LB: 

    /** parser.e:650					CompileErr(UNKNOWN_NAMESPACE_1_IN_DEFAULT_ARGUMENT, {Ns_recorded[n]})*/
    _2 = (object)SEQ_PTR(_12Ns_recorded_20334);
    _28238 = (object)*(((s1_ptr)_2)->base + _n_55788);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_28238);
    ((intptr_t*)_2)[1] = _28238;
    _28239 = MAKE_SEQ(_1);
    _28238 = NOVALUE;
    _49CompileErr(153LL, _28239, 0LL);
    _28239 = NOVALUE;
LC: 

    /** parser.e:652				t = {NAMESPACE, p}*/
    DeRef(_t_55790);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 523LL;
    ((intptr_t *)_2)[2] = _p_55791;
    _t_55790 = MAKE_SEQ(_1);
LA: 

    /** parser.e:655			t = keyfind(Recorded[n],SymTab[t[T_SYM]][S_OBJ])*/
    _2 = (object)SEQ_PTR(_12Recorded_20333);
    _28241 = (object)*(((s1_ptr)_2)->base + _n_55788);
    _2 = (object)SEQ_PTR(_t_55790);
    _28242 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28242)){
        _28243 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28242)->dbl));
    }
    else{
        _28243 = (object)*(((s1_ptr)_2)->base + _28242);
    }
    _2 = (object)SEQ_PTR(_28243);
    _28244 = (object)*(((s1_ptr)_2)->base + 1LL);
    _28243 = NOVALUE;
    RefDS(_28241);
    DeRef(_31782);
    _31782 = _28241;
    _31783 = _53hashfn(_31782);
    _31782 = NOVALUE;
    RefDS(_28241);
    Ref(_28244);
    _0 = _t_55790;
    _t_55790 = _53keyfind(_28241, _28244, _12current_file_no_20226, 0LL, _31783);
    DeRef(_0);
    _28241 = NOVALUE;
    _28244 = NOVALUE;
    _31783 = NOVALUE;

    /** parser.e:656			if t[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_t_55790);
    _28246 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28246, 509LL)){
        _28246 = NOVALUE;
        goto LD; // [577] 636
    }
    _28246 = NOVALUE;

    /** parser.e:657		        p = Recorded_sym[n]*/
    _2 = (object)SEQ_PTR(_12Recorded_sym_20335);
    _p_55791 = (object)*(((s1_ptr)_2)->base + _n_55788);
    if (!IS_ATOM_INT(_p_55791)){
        _p_55791 = (object)DBL_PTR(_p_55791)->dbl;
    }

    /** parser.e:658		        if p = 0 then*/
    if (_p_55791 != 0LL)
    goto LE; // [593] 617

    /** parser.e:659		        	CompileErr(VARIABLE_1_HAS_NOT_BEEN_DECLARED,{Recorded[n]})*/
    _2 = (object)SEQ_PTR(_12Recorded_20333);
    _28250 = (object)*(((s1_ptr)_2)->base + _n_55788);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_28250);
    ((intptr_t*)_2)[1] = _28250;
    _28251 = MAKE_SEQ(_1);
    _28250 = NOVALUE;
    _49CompileErr(157LL, _28251, 0LL);
    _28251 = NOVALUE;
LE: 

    /** parser.e:661			    t = {SymTab[p][S_TOKEN], p}*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28252 = (object)*(((s1_ptr)_2)->base + _p_55791);
    _2 = (object)SEQ_PTR(_28252);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _28253 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _28253 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _28252 = NOVALUE;
    Ref(_28253);
    DeRef(_t_55790);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28253;
    ((intptr_t *)_2)[2] = _p_55791;
    _t_55790 = MAKE_SEQ(_1);
    _28253 = NOVALUE;
LD: 

    /** parser.e:663			n = t[T_ID]*/
    _2 = (object)SEQ_PTR(_t_55790);
    _n_55788 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_n_55788)){
        _n_55788 = (object)DBL_PTR(_n_55788)->dbl;
    }

    /** parser.e:664			if n = VARIABLE then*/
    if (_n_55788 != -100LL)
    goto LF; // [650] 666

    /** parser.e:665				n = QUALIFIED_VARIABLE*/
    _n_55788 = 512LL;
    goto L10; // [663] 725
LF: 

    /** parser.e:666			elsif n = FUNC then*/
    if (_n_55788 != 501LL)
    goto L11; // [670] 686

    /** parser.e:667				n = QUALIFIED_FUNC*/
    _n_55788 = 520LL;
    goto L10; // [683] 725
L11: 

    /** parser.e:668			elsif n = PROC then*/
    if (_n_55788 != 27LL)
    goto L12; // [690] 706

    /** parser.e:669				n = QUALIFIED_PROC*/
    _n_55788 = 521LL;
    goto L10; // [703] 725
L12: 

    /** parser.e:670			elsif n = TYPE then*/
    if (_n_55788 != 504LL)
    goto L13; // [710] 724

    /** parser.e:671				n = QUALIFIED_TYPE*/
    _n_55788 = 522LL;
L13: 
L10: 

    /** parser.e:673			t[T_ID] = n*/
    _2 = (object)SEQ_PTR(_t_55790);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _t_55790 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _n_55788;
    DeRef(_1);
L8: 

    /** parser.e:675		No_new_entry = prev_Nne*/
    _53No_new_entry_48046 = _prev_Nne_55792;

    /** parser.e:676	  	return t*/
    _28242 = NOVALUE;
    DeRef(_28196);
    _28196 = NOVALUE;
    DeRef(_28201);
    _28201 = NOVALUE;
    DeRef(_28205);
    _28205 = NOVALUE;
    _28193 = NOVALUE;
    DeRef(_28203);
    _28203 = NOVALUE;
    DeRef(_28234);
    _28234 = NOVALUE;
    DeRef(_28191);
    _28191 = NOVALUE;
    return _t_55790;
    ;
}


object _43next_token()
{
    object _t_55972 = NOVALUE;
    object _s_55973 = NOVALUE;
    object _28292 = NOVALUE;
    object _28291 = NOVALUE;
    object _28290 = NOVALUE;
    object _28289 = NOVALUE;
    object _28288 = NOVALUE;
    object _28287 = NOVALUE;
    object _28286 = NOVALUE;
    object _28285 = NOVALUE;
    object _28283 = NOVALUE;
    object _28282 = NOVALUE;
    object _28281 = NOVALUE;
    object _28280 = NOVALUE;
    object _28278 = NOVALUE;
    object _28276 = NOVALUE;
    object _28274 = NOVALUE;
    object _28270 = NOVALUE;
    object _28267 = NOVALUE;
    object _28264 = NOVALUE;
    object _28262 = NOVALUE;
    object _28260 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:682		sequence s*/

    /** parser.e:684		if length(backed_up_tok) > 0 then*/
    if (IS_SEQUENCE(_43backed_up_tok_55022)){
            _28260 = SEQ_PTR(_43backed_up_tok_55022)->length;
    }
    else {
        _28260 = 1;
    }
    if (_28260 <= 0LL)
    goto L1; // [10] 82

    /** parser.e:685			t = backed_up_tok[$]*/
    if (IS_SEQUENCE(_43backed_up_tok_55022)){
            _28262 = SEQ_PTR(_43backed_up_tok_55022)->length;
    }
    else {
        _28262 = 1;
    }
    DeRef(_t_55972);
    _2 = (object)SEQ_PTR(_43backed_up_tok_55022);
    _t_55972 = (object)*(((s1_ptr)_2)->base + _28262);
    Ref(_t_55972);

    /** parser.e:686			backed_up_tok = remove( backed_up_tok, length( backed_up_tok ) )*/
    if (IS_SEQUENCE(_43backed_up_tok_55022)){
            _28264 = SEQ_PTR(_43backed_up_tok_55022)->length;
    }
    else {
        _28264 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_43backed_up_tok_55022);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_28264)) ? _28264 : (object)(DBL_PTR(_28264)->dbl);
        int stop = (IS_ATOM_INT(_28264)) ? _28264 : (object)(DBL_PTR(_28264)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_43backed_up_tok_55022), start, &_43backed_up_tok_55022 );
            }
            else Tail(SEQ_PTR(_43backed_up_tok_55022), stop+1, &_43backed_up_tok_55022);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_43backed_up_tok_55022), start, &_43backed_up_tok_55022);
        }
        else {
            assign_slice_seq = &assign_space;
            _43backed_up_tok_55022 = Remove_elements(start, stop, (SEQ_PTR(_43backed_up_tok_55022)->ref == 1));
        }
    }
    _28264 = NOVALUE;
    _28264 = NOVALUE;

    /** parser.e:687			if putback_fwd_line_number then*/
    if (_12putback_fwd_line_number_20229 == 0)
    {
        goto L2; // [43] 349
    }
    else{
    }

    /** parser.e:689				ForwardLine     = putback_ForwardLine*/
    Ref(_49putback_ForwardLine_49314);
    DeRef(_49ForwardLine_49313);
    _49ForwardLine_49313 = _49putback_ForwardLine_49314;

    /** parser.e:690				forward_bp      = putback_forward_bp*/
    _49forward_bp_49317 = _49putback_forward_bp_49318;

    /** parser.e:691				fwd_line_number = putback_fwd_line_number*/
    _12fwd_line_number_20228 = _12putback_fwd_line_number_20229;

    /** parser.e:693				putback_fwd_line_number = 0*/
    _12putback_fwd_line_number_20229 = 0LL;
    goto L2; // [79] 349
L1: 

    /** parser.e:696		elsif Parser_mode = PAM_PLAYBACK then*/
    if (_12Parser_mode_20332 != -1LL)
    goto L3; // [88] 302

    /** parser.e:697			if canned_index <= length(canned_tokens) then*/
    if (IS_SEQUENCE(_43canned_tokens_55059)){
            _28267 = SEQ_PTR(_43canned_tokens_55059)->length;
    }
    else {
        _28267 = 1;
    }
    if (_43canned_index_55060 > _28267)
    goto L4; // [101] 150

    /** parser.e:698				t = canned_tokens[canned_index]*/
    DeRef(_t_55972);
    _2 = (object)SEQ_PTR(_43canned_tokens_55059);
    _t_55972 = (object)*(((s1_ptr)_2)->base + _43canned_index_55060);
    Ref(_t_55972);

    /** parser.e:699				if canned_index < length(canned_tokens) then*/
    if (IS_SEQUENCE(_43canned_tokens_55059)){
            _28270 = SEQ_PTR(_43canned_tokens_55059)->length;
    }
    else {
        _28270 = 1;
    }
    if (_43canned_index_55060 >= _28270)
    goto L5; // [124] 139

    /** parser.e:700					canned_index += 1*/
    _43canned_index_55060 = _43canned_index_55060 + 1;
    goto L6; // [136] 157
L5: 

    /** parser.e:702		            s = restore_parser()*/
    _0 = _s_55973;
    _s_55973 = _43restore_parser();
    DeRef(_0);
    goto L6; // [147] 157
L4: 

    /** parser.e:705		    	InternalErr(266)*/
    RefDS(_22024);
    _49InternalErr(266LL, _22024);
L6: 

    /** parser.e:707			if t[T_ID] = RECORDED then*/
    _2 = (object)SEQ_PTR(_t_55972);
    _28274 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28274, 508LL)){
        _28274 = NOVALUE;
        goto L7; // [169] 188
    }
    _28274 = NOVALUE;

    /** parser.e:708				t=read_recorded_token(t[T_SYM])*/
    _2 = (object)SEQ_PTR(_t_55972);
    _28276 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_28276);
    _0 = _t_55972;
    _t_55972 = _43read_recorded_token(_28276);
    DeRef(_0);
    _28276 = NOVALUE;
    goto L2; // [185] 349
L7: 

    /** parser.e:709			elsif t[T_ID] = DEF_PARAM then*/
    _2 = (object)SEQ_PTR(_t_55972);
    _28278 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28278, 510LL)){
        _28278 = NOVALUE;
        goto L2; // [198] 349
    }
    _28278 = NOVALUE;

    /** parser.e:710	        	for i=length(nested_calls) to 1 by -1 do*/
    if (IS_SEQUENCE(_43nested_calls_55764)){
            _28280 = SEQ_PTR(_43nested_calls_55764)->length;
    }
    else {
        _28280 = 1;
    }
    {
        object _i_56020;
        _i_56020 = _28280;
L8: 
        if (_i_56020 < 1LL){
            goto L9; // [209] 288
        }

        /** parser.e:711	        	    if nested_calls[i] = t[T_SYM][2] then*/
        _2 = (object)SEQ_PTR(_43nested_calls_55764);
        _28281 = (object)*(((s1_ptr)_2)->base + _i_56020);
        _2 = (object)SEQ_PTR(_t_55972);
        _28282 = (object)*(((s1_ptr)_2)->base + 2LL);
        _2 = (object)SEQ_PTR(_28282);
        _28283 = (object)*(((s1_ptr)_2)->base + 2LL);
        _28282 = NOVALUE;
        if (binary_op_a(NOTEQ, _28281, _28283)){
            _28281 = NOVALUE;
            _28283 = NOVALUE;
            goto LA; // [234] 281
        }
        _28281 = NOVALUE;
        _28283 = NOVALUE;

        /** parser.e:712						return {VARIABLE, private_sym[parseargs_states[i][PS_POSITION]+t[T_SYM][1]]}*/
        _2 = (object)SEQ_PTR(_43parseargs_states_55756);
        _28285 = (object)*(((s1_ptr)_2)->base + _i_56020);
        _2 = (object)SEQ_PTR(_28285);
        _28286 = (object)*(((s1_ptr)_2)->base + 1LL);
        _28285 = NOVALUE;
        _2 = (object)SEQ_PTR(_t_55972);
        _28287 = (object)*(((s1_ptr)_2)->base + 2LL);
        _2 = (object)SEQ_PTR(_28287);
        _28288 = (object)*(((s1_ptr)_2)->base + 1LL);
        _28287 = NOVALUE;
        if (IS_ATOM_INT(_28286) && IS_ATOM_INT(_28288)) {
            _28289 = _28286 + _28288;
        }
        else {
            _28289 = binary_op(PLUS, _28286, _28288);
        }
        _28286 = NOVALUE;
        _28288 = NOVALUE;
        _2 = (object)SEQ_PTR(_12private_sym_20339);
        if (!IS_ATOM_INT(_28289)){
            _28290 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28289)->dbl));
        }
        else{
            _28290 = (object)*(((s1_ptr)_2)->base + _28289);
        }
        Ref(_28290);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -100LL;
        ((intptr_t *)_2)[2] = _28290;
        _28291 = MAKE_SEQ(_1);
        _28290 = NOVALUE;
        DeRef(_t_55972);
        DeRef(_s_55973);
        DeRef(_28289);
        _28289 = NOVALUE;
        return _28291;
LA: 

        /** parser.e:714				end for*/
        _i_56020 = _i_56020 + -1LL;
        goto L8; // [283] 216
L9: 
        ;
    }

    /** parser.e:715				CompileErr(INTERNAL_NESTED_CALL_PARSING_ERROR)*/
    RefDS(_22024);
    _49CompileErr(98LL, _22024, 0LL);
    goto L2; // [299] 349
L3: 

    /** parser.e:717		elsif lock_scanner then*/
    if (_43lock_scanner_55762 == 0)
    {
        goto LB; // [306] 324
    }
    else{
    }

    /** parser.e:718			return {PLAYBACK_ENDS,0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 505LL;
    ((intptr_t *)_2)[2] = 0LL;
    _28292 = MAKE_SEQ(_1);
    DeRef(_t_55972);
    DeRef(_s_55973);
    DeRef(_28291);
    _28291 = NOVALUE;
    DeRef(_28289);
    _28289 = NOVALUE;
    return _28292;
    goto L2; // [321] 349
LB: 

    /** parser.e:720		    t = Scanner()*/
    _0 = _t_55972;
    _t_55972 = _61Scanner();
    DeRef(_0);

    /** parser.e:721		    if Parser_mode = PAM_RECORD then*/
    if (_12Parser_mode_20332 != 1LL)
    goto LC; // [335] 348

    /** parser.e:722		        canned_tokens = append(canned_tokens,t)*/
    Ref(_t_55972);
    Append(&_43canned_tokens_55059, _43canned_tokens_55059, _t_55972);
LC: 
L2: 

    /** parser.e:725		putback_fwd_line_number = 0*/
    _12putback_fwd_line_number_20229 = 0LL;

    /** parser.e:726		return t*/
    DeRef(_s_55973);
    DeRef(_28291);
    _28291 = NOVALUE;
    DeRef(_28289);
    _28289 = NOVALUE;
    DeRef(_28292);
    _28292 = NOVALUE;
    return _t_55972;
    ;
}


object _43Expr_list()
{
    object _tok_56056 = NOVALUE;
    object _n_56057 = NOVALUE;
    object _28308 = NOVALUE;
    object _28305 = NOVALUE;
    object _28304 = NOVALUE;
    object _28302 = NOVALUE;
    object _28301 = NOVALUE;
    object _28297 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:734		integer n*/

    /** parser.e:736		tok = next_token()*/
    _0 = _tok_56056;
    _tok_56056 = _43next_token();
    DeRef(_0);

    /** parser.e:737		putback(tok)*/
    Ref(_tok_56056);
    _43putback(_tok_56056);

    /** parser.e:738		if tok[T_ID] = RIGHT_BRACE then*/
    _2 = (object)SEQ_PTR(_tok_56056);
    _28297 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28297, -25LL)){
        _28297 = NOVALUE;
        goto L1; // [23] 36
    }
    _28297 = NOVALUE;

    /** parser.e:739			return 0*/
    DeRef(_tok_56056);
    return 0LL;
    goto L2; // [33] 142
L1: 

    /** parser.e:741			n = 0*/
    _n_56057 = 0LL;

    /** parser.e:742			short_circuit -= 1*/
    _43short_circuit_55015 = _43short_circuit_55015 - 1LL;

    /** parser.e:743			while TRUE do*/
L3: 
    if (_9TRUE_446 == 0)
    {
        goto L4; // [56] 133
    }
    else{
    }

    /** parser.e:744				gListItem &= 1*/
    Append(&_43gListItem_55051, _43gListItem_55051, 1LL);

    /** parser.e:745				Expr()*/
    _43Expr();

    /** parser.e:746				n += gListItem[$]*/
    if (IS_SEQUENCE(_43gListItem_55051)){
            _28301 = SEQ_PTR(_43gListItem_55051)->length;
    }
    else {
        _28301 = 1;
    }
    _2 = (object)SEQ_PTR(_43gListItem_55051);
    _28302 = (object)*(((s1_ptr)_2)->base + _28301);
    _n_56057 = _n_56057 + _28302;
    _28302 = NOVALUE;

    /** parser.e:747				gListItem = gListItem[1 .. $-1]*/
    if (IS_SEQUENCE(_43gListItem_55051)){
            _28304 = SEQ_PTR(_43gListItem_55051)->length;
    }
    else {
        _28304 = 1;
    }
    _28305 = _28304 - 1LL;
    _28304 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43gListItem_55051;
    RHS_Slice(_43gListItem_55051, 1LL, _28305);

    /** parser.e:748				tok = next_token()*/
    _0 = _tok_56056;
    _tok_56056 = _43next_token();
    DeRef(_0);

    /** parser.e:749				if tok[T_ID] != COMMA then*/
    _2 = (object)SEQ_PTR(_tok_56056);
    _28308 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _28308, -30LL)){
        _28308 = NOVALUE;
        goto L3; // [119] 54
    }
    _28308 = NOVALUE;

    /** parser.e:750					exit*/
    goto L4; // [125] 133

    /** parser.e:752			end while*/
    goto L3; // [130] 54
L4: 

    /** parser.e:753			short_circuit += 1*/
    _43short_circuit_55015 = _43short_circuit_55015 + 1;
L2: 

    /** parser.e:755		putback(tok)*/
    Ref(_tok_56056);
    _43putback(_tok_56056);

    /** parser.e:756		return n*/
    DeRef(_tok_56056);
    DeRef(_28305);
    _28305 = NOVALUE;
    return _n_56057;
    ;
}


void _43tok_match(object _tok_56085, object _prevtok_56086)
{
    object _t_56088 = NOVALUE;
    object _expected_56089 = NOVALUE;
    object _actual_56090 = NOVALUE;
    object _prevname_56091 = NOVALUE;
    object _28320 = NOVALUE;
    object _28318 = NOVALUE;
    object _28315 = NOVALUE;
    object _28312 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:762		sequence expected, actual, prevname*/

    /** parser.e:764		t = next_token()*/
    _0 = _t_56088;
    _t_56088 = _43next_token();
    DeRef(_0);

    /** parser.e:765		if t[T_ID] != tok then*/
    _2 = (object)SEQ_PTR(_t_56088);
    _28312 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _28312, _tok_56085)){
        _28312 = NOVALUE;
        goto L1; // [20] 96
    }
    _28312 = NOVALUE;

    /** parser.e:766			expected = LexName(tok)*/
    RefDS(_26412);
    _0 = _expected_56089;
    _expected_56089 = _45LexName(_tok_56085, _26412);
    DeRef(_0);

    /** parser.e:767			actual = LexName(t[T_ID])*/
    _2 = (object)SEQ_PTR(_t_56088);
    _28315 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_28315);
    RefDS(_26412);
    _0 = _actual_56090;
    _actual_56090 = _45LexName(_28315, _26412);
    DeRef(_0);
    _28315 = NOVALUE;

    /** parser.e:768			if prevtok = 0 then*/
    if (_prevtok_56086 != 0LL)
    goto L2; // [50] 70

    /** parser.e:769				CompileErr(SYNTAX_ERROR__EXPECTED_TO_SEE_POSSIBLY_1_NOT_2, {expected, actual})*/
    RefDS(_actual_56090);
    RefDS(_expected_56089);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _expected_56089;
    ((intptr_t *)_2)[2] = _actual_56090;
    _28318 = MAKE_SEQ(_1);
    _49CompileErr(132LL, _28318, 0LL);
    _28318 = NOVALUE;
    goto L3; // [67] 95
L2: 

    /** parser.e:771				prevname = LexName(prevtok)*/
    RefDS(_26412);
    _0 = _prevname_56091;
    _prevname_56091 = _45LexName(_prevtok_56086, _26412);
    DeRef(_0);

    /** parser.e:772				CompileErr(SYNTAX_ERROR__EXPECTED_TO_SEE_1_AFTER_2_NOT_3, {expected, prevname, actual})*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_expected_56089);
    ((intptr_t*)_2)[1] = _expected_56089;
    RefDS(_prevname_56091);
    ((intptr_t*)_2)[2] = _prevname_56091;
    RefDS(_actual_56090);
    ((intptr_t*)_2)[3] = _actual_56090;
    _28320 = MAKE_SEQ(_1);
    _49CompileErr(138LL, _28320, 0LL);
    _28320 = NOVALUE;
L3: 
L1: 

    /** parser.e:775	end procedure*/
    DeRef(_t_56088);
    DeRef(_expected_56089);
    DeRef(_actual_56090);
    DeRef(_prevname_56091);
    return;
    ;
}


void _43UndefinedVar(object _s_56127)
{
    object _dup_56129 = NOVALUE;
    object _errmsg_56130 = NOVALUE;
    object _rname_56131 = NOVALUE;
    object _fname_56132 = NOVALUE;
    object _28343 = NOVALUE;
    object _28342 = NOVALUE;
    object _28340 = NOVALUE;
    object _28338 = NOVALUE;
    object _28337 = NOVALUE;
    object _28335 = NOVALUE;
    object _28333 = NOVALUE;
    object _28331 = NOVALUE;
    object _28330 = NOVALUE;
    object _28329 = NOVALUE;
    object _28328 = NOVALUE;
    object _28327 = NOVALUE;
    object _28325 = NOVALUE;
    object _28324 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_56127)) {
        _1 = (object)(DBL_PTR(_s_56127)->dbl);
        DeRefDS(_s_56127);
        _s_56127 = _1;
    }

    /** parser.e:790		sequence errmsg*/

    /** parser.e:791		sequence rname*/

    /** parser.e:792		sequence fname*/

    /** parser.e:794		if SymTab[s][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28324 = (object)*(((s1_ptr)_2)->base + _s_56127);
    _2 = (object)SEQ_PTR(_28324);
    _28325 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28324 = NOVALUE;
    if (binary_op_a(NOTEQ, _28325, 9LL)){
        _28325 = NOVALUE;
        goto L1; // [25] 57
    }
    _28325 = NOVALUE;

    /** parser.e:795			CompileErr(MSG_1_HAS_NOT_BEEN_DECLARED, {SymTab[s][S_NAME]})*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28327 = (object)*(((s1_ptr)_2)->base + _s_56127);
    _2 = (object)SEQ_PTR(_28327);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _28328 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _28328 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _28327 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_28328);
    ((intptr_t*)_2)[1] = _28328;
    _28329 = MAKE_SEQ(_1);
    _28328 = NOVALUE;
    _49CompileErr(19LL, _28329, 0LL);
    _28329 = NOVALUE;
    goto L2; // [54] 206
L1: 

    /** parser.e:797		elsif SymTab[s][S_SCOPE] = SC_MULTIPLY_DEFINED then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28330 = (object)*(((s1_ptr)_2)->base + _s_56127);
    _2 = (object)SEQ_PTR(_28330);
    _28331 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28330 = NOVALUE;
    if (binary_op_a(NOTEQ, _28331, 10LL)){
        _28331 = NOVALUE;
        goto L3; // [73] 183
    }
    _28331 = NOVALUE;

    /** parser.e:798			rname = SymTab[s][S_NAME]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28333 = (object)*(((s1_ptr)_2)->base + _s_56127);
    DeRef(_rname_56131);
    _2 = (object)SEQ_PTR(_28333);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _rname_56131 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _rname_56131 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    Ref(_rname_56131);
    _28333 = NOVALUE;

    /** parser.e:799			errmsg = ""*/
    RefDS(_22024);
    DeRef(_errmsg_56130);
    _errmsg_56130 = _22024;

    /** parser.e:801			for i = 1 to length(dup_globals) do*/
    if (IS_SEQUENCE(_53dup_globals_48035)){
            _28335 = SEQ_PTR(_53dup_globals_48035)->length;
    }
    else {
        _28335 = 1;
    }
    {
        object _i_56159;
        _i_56159 = 1LL;
L4: 
        if (_i_56159 > _28335){
            goto L5; // [107] 165
        }

        /** parser.e:802				dup = dup_globals[i]*/
        _2 = (object)SEQ_PTR(_53dup_globals_48035);
        _dup_56129 = (object)*(((s1_ptr)_2)->base + _i_56159);
        if (!IS_ATOM_INT(_dup_56129)){
            _dup_56129 = (object)DBL_PTR(_dup_56129)->dbl;
        }

        /** parser.e:803				fname = known_files[SymTab[dup][S_FILE_NO]]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28337 = (object)*(((s1_ptr)_2)->base + _dup_56129);
        _2 = (object)SEQ_PTR(_28337);
        if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
            _28338 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
        }
        else{
            _28338 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
        }
        _28337 = NOVALUE;
        DeRef(_fname_56132);
        _2 = (object)SEQ_PTR(_13known_files_11317);
        if (!IS_ATOM_INT(_28338)){
            _fname_56132 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28338)->dbl));
        }
        else{
            _fname_56132 = (object)*(((s1_ptr)_2)->base + _28338);
        }
        Ref(_fname_56132);

        /** parser.e:804				errmsg &= "    " & fname & "\n"*/
        {
            object concat_list[3];

            concat_list[0] = _22231;
            concat_list[1] = _fname_56132;
            concat_list[2] = _24947;
            Concat_N((object_ptr)&_28340, concat_list, 3);
        }
        Concat((object_ptr)&_errmsg_56130, _errmsg_56130, _28340);
        DeRefDS(_28340);
        _28340 = NOVALUE;

        /** parser.e:806			end for*/
        _i_56159 = _i_56159 + 1LL;
        goto L4; // [160] 114
L5: 
        ;
    }

    /** parser.e:808			CompileErr(A_NAMESPACE_QUALIFIER_IS_NEEDED_TO_RESOLVE_1BECAUSE_2_IS_DECLARED_AS_A_GLOBALPUBLIC_SYMBOL_IN3, {rname, rname, errmsg})*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDSn(_rname_56131, 2);
    ((intptr_t*)_2)[1] = _rname_56131;
    ((intptr_t*)_2)[2] = _rname_56131;
    RefDS(_errmsg_56130);
    ((intptr_t*)_2)[3] = _errmsg_56130;
    _28342 = MAKE_SEQ(_1);
    _49CompileErr(23LL, _28342, 0LL);
    _28342 = NOVALUE;
    goto L2; // [180] 206
L3: 

    /** parser.e:810		elsif length(symbol_resolution_warning) then*/
    if (IS_SEQUENCE(_12symbol_resolution_warning_20328)){
            _28343 = SEQ_PTR(_12symbol_resolution_warning_20328)->length;
    }
    else {
        _28343 = 1;
    }
    if (_28343 == 0)
    {
        _28343 = NOVALUE;
        goto L6; // [190] 205
    }
    else{
        _28343 = NOVALUE;
    }

    /** parser.e:811			Warning( symbol_resolution_warning, resolution_warning_flag)*/
    RefDS(_12symbol_resolution_warning_20328);
    RefDS(_22024);
    _49Warning(_12symbol_resolution_warning_20328, 1LL, _22024);
L6: 
L2: 

    /** parser.e:813	end procedure*/
    DeRef(_errmsg_56130);
    DeRef(_rname_56131);
    DeRef(_fname_56132);
    _28338 = NOVALUE;
    return;
    ;
}


void _43WrongNumberArgs(object _subsym_56184, object _only_56185)
{
    object _msgno_56186 = NOVALUE;
    object _28355 = NOVALUE;
    object _28354 = NOVALUE;
    object _28353 = NOVALUE;
    object _28352 = NOVALUE;
    object _28351 = NOVALUE;
    object _28349 = NOVALUE;
    object _28347 = NOVALUE;
    object _28345 = NOVALUE;
    object _28344 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_subsym_56184)) {
        _1 = (object)(DBL_PTR(_subsym_56184)->dbl);
        DeRefDS(_subsym_56184);
        _subsym_56184 = _1;
    }

    /** parser.e:819		if SymTab[subsym][S_NUM_ARGS] = 1 then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28344 = (object)*(((s1_ptr)_2)->base + _subsym_56184);
    _2 = (object)SEQ_PTR(_28344);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _28345 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _28345 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _28344 = NOVALUE;
    if (binary_op_a(NOTEQ, _28345, 1LL)){
        _28345 = NOVALUE;
        goto L1; // [19] 49
    }
    _28345 = NOVALUE;

    /** parser.e:820			if length(only) = 0 then*/
    if (IS_SEQUENCE(_only_56185)){
            _28347 = SEQ_PTR(_only_56185)->length;
    }
    else {
        _28347 = 1;
    }
    if (_28347 != 0LL)
    goto L2; // [28] 40

    /** parser.e:821				msgno = 20*/
    _msgno_56186 = 20LL;
    goto L3; // [37] 73
L2: 

    /** parser.e:823				msgno = 237*/
    _msgno_56186 = 237LL;
    goto L3; // [46] 73
L1: 

    /** parser.e:826			if length(only) = 0 then*/
    if (IS_SEQUENCE(_only_56185)){
            _28349 = SEQ_PTR(_only_56185)->length;
    }
    else {
        _28349 = 1;
    }
    if (_28349 != 0LL)
    goto L4; // [54] 66

    /** parser.e:827				msgno = 236*/
    _msgno_56186 = 236LL;
    goto L5; // [63] 72
L4: 

    /** parser.e:829				msgno = 238*/
    _msgno_56186 = 238LL;
L5: 
L3: 

    /** parser.e:833		CompileErr(msgno, {SymTab[subsym][S_NAME], SymTab[subsym][S_NUM_ARGS]})*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28351 = (object)*(((s1_ptr)_2)->base + _subsym_56184);
    _2 = (object)SEQ_PTR(_28351);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _28352 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _28352 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _28351 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28353 = (object)*(((s1_ptr)_2)->base + _subsym_56184);
    _2 = (object)SEQ_PTR(_28353);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _28354 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _28354 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _28353 = NOVALUE;
    Ref(_28354);
    Ref(_28352);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28352;
    ((intptr_t *)_2)[2] = _28354;
    _28355 = MAKE_SEQ(_1);
    _28354 = NOVALUE;
    _28352 = NOVALUE;
    _49CompileErr(_msgno_56186, _28355, 0LL);
    _28355 = NOVALUE;

    /** parser.e:834	end procedure*/
    DeRefDSi(_only_56185);
    return;
    ;
}


void _43MissingArgs(object _subsym_56215)
{
    object _eentry_56216 = NOVALUE;
    object _28360 = NOVALUE;
    object _28359 = NOVALUE;
    object _28358 = NOVALUE;
    object _28357 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:837		sequence eentry = SymTab[subsym]*/
    DeRef(_eentry_56216);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _eentry_56216 = (object)*(((s1_ptr)_2)->base + _subsym_56215);
    Ref(_eentry_56216);

    /** parser.e:839		CompileErr(MSG_1_NEEDS_AT_LEAST_2_PARAMETERS_BUT_SOME_NONDEFAULTABLE_ARGUMENTS_ARE_MISSING, {eentry[S_NAME], eentry[S_DEF_ARGS][2]})*/
    _2 = (object)SEQ_PTR(_eentry_56216);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _28357 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _28357 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _2 = (object)SEQ_PTR(_eentry_56216);
    _28358 = (object)*(((s1_ptr)_2)->base + 28LL);
    _2 = (object)SEQ_PTR(_28358);
    _28359 = (object)*(((s1_ptr)_2)->base + 2LL);
    _28358 = NOVALUE;
    Ref(_28359);
    Ref(_28357);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28357;
    ((intptr_t *)_2)[2] = _28359;
    _28360 = MAKE_SEQ(_1);
    _28359 = NOVALUE;
    _28357 = NOVALUE;
    _49CompileErr(235LL, _28360, 0LL);
    _28360 = NOVALUE;

    /** parser.e:840	end procedure*/
    DeRefDS(_eentry_56216);
    return;
    ;
}


void _43Parse_default_arg(object _subsym_56230, object _arg_56231, object _fwd_private_list_56232, object _fwd_private_sym_56233)
{
    object _param_56235 = NOVALUE;
    object _28380 = NOVALUE;
    object _28379 = NOVALUE;
    object _28378 = NOVALUE;
    object _28377 = NOVALUE;
    object _28376 = NOVALUE;
    object _28375 = NOVALUE;
    object _28374 = NOVALUE;
    object _28373 = NOVALUE;
    object _28372 = NOVALUE;
    object _28371 = NOVALUE;
    object _28370 = NOVALUE;
    object _28369 = NOVALUE;
    object _28368 = NOVALUE;
    object _28366 = NOVALUE;
    object _28365 = NOVALUE;
    object _28362 = NOVALUE;
    object _28361 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:843		symtab_index param = subsym*/
    _param_56235 = _subsym_56230;

    /** parser.e:844		on_arg = arg*/
    _43on_arg_55763 = _arg_56231;

    /** parser.e:845		parseargs_states = append(parseargs_states,*/
    if (IS_SEQUENCE(_43private_list_55761)){
            _28361 = SEQ_PTR(_43private_list_55761)->length;
    }
    else {
        _28361 = 1;
    }
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _28361;
    ((intptr_t*)_2)[2] = _43lock_scanner_55762;
    ((intptr_t*)_2)[3] = _12use_private_list_20340;
    ((intptr_t*)_2)[4] = _43on_arg_55763;
    _28362 = MAKE_SEQ(_1);
    _28361 = NOVALUE;
    RefDS(_28362);
    Append(&_43parseargs_states_55756, _43parseargs_states_55756, _28362);
    DeRefDS(_28362);
    _28362 = NOVALUE;

    /** parser.e:847		nested_calls &= subsym*/
    Append(&_43nested_calls_55764, _43nested_calls_55764, _subsym_56230);

    /** parser.e:849		for i = 1 to arg do*/
    _28365 = _arg_56231;
    {
        object _i_56242;
        _i_56242 = 1LL;
L1: 
        if (_i_56242 > _28365){
            goto L2; // [60] 90
        }

        /** parser.e:850			param = SymTab[param][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28366 = (object)*(((s1_ptr)_2)->base + _param_56235);
        _2 = (object)SEQ_PTR(_28366);
        _param_56235 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_param_56235)){
            _param_56235 = (object)DBL_PTR(_param_56235)->dbl;
        }
        _28366 = NOVALUE;

        /** parser.e:851		end for*/
        _i_56242 = _i_56242 + 1LL;
        goto L1; // [85] 67
L2: 
        ;
    }

    /** parser.e:853		private_list = fwd_private_list*/
    RefDS(_fwd_private_list_56232);
    DeRef(_43private_list_55761);
    _43private_list_55761 = _fwd_private_list_56232;

    /** parser.e:854		private_sym  = fwd_private_sym*/
    RefDS(_fwd_private_sym_56233);
    DeRef(_12private_sym_20339);
    _12private_sym_20339 = _fwd_private_sym_56233;

    /** parser.e:856		if atom(SymTab[param][S_CODE]) then  -- but no default set*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28368 = (object)*(((s1_ptr)_2)->base + _param_56235);
    _2 = (object)SEQ_PTR(_28368);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _28369 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _28369 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    _28368 = NOVALUE;
    _28370 = IS_ATOM(_28369);
    _28369 = NOVALUE;
    if (_28370 == 0)
    {
        _28370 = NOVALUE;
        goto L3; // [121] 164
    }
    else{
        _28370 = NOVALUE;
    }

    /** parser.e:857			CompileErr(ARGUMENT_1_OF_2_3_WAS_OMITTED_BUT_THERE_IS_NO_DEFAULT_VALUE_DEFINED, {arg, SymTab[subsym][S_NAME], SymTab[param][S_NAME]})*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28371 = (object)*(((s1_ptr)_2)->base + _subsym_56230);
    _2 = (object)SEQ_PTR(_28371);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _28372 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _28372 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _28371 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28373 = (object)*(((s1_ptr)_2)->base + _param_56235);
    _2 = (object)SEQ_PTR(_28373);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _28374 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _28374 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _28373 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _arg_56231;
    Ref(_28372);
    ((intptr_t*)_2)[2] = _28372;
    Ref(_28374);
    ((intptr_t*)_2)[3] = _28374;
    _28375 = MAKE_SEQ(_1);
    _28374 = NOVALUE;
    _28372 = NOVALUE;
    _49CompileErr(26LL, _28375, 0LL);
    _28375 = NOVALUE;
L3: 

    /** parser.e:860		use_private_list = 1*/
    _12use_private_list_20340 = 1LL;

    /** parser.e:861		lock_scanner = 1*/
    _43lock_scanner_55762 = 1LL;

    /** parser.e:862		start_playback(SymTab[param][S_CODE] )*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28376 = (object)*(((s1_ptr)_2)->base + _param_56235);
    _2 = (object)SEQ_PTR(_28376);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _28377 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _28377 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    _28376 = NOVALUE;
    Ref(_28377);
    _43start_playback(_28377);
    _28377 = NOVALUE;

    /** parser.e:863		call_proc(forward_expr, {})*/
    _0 = (object)_00[_43forward_expr_56052].addr;
    (*(intptr_t (*)())_0)(
                         );

    /** parser.e:865		add_private_symbol( Top(), SymTab[param][S_NAME] )*/
    _28378 = _45Top();
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28379 = (object)*(((s1_ptr)_2)->base + _param_56235);
    _2 = (object)SEQ_PTR(_28379);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _28380 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _28380 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _28379 = NOVALUE;
    Ref(_28380);
    _42add_private_symbol(_28378, _28380);
    _28378 = NOVALUE;
    _28380 = NOVALUE;

    /** parser.e:866		lock_scanner = 0*/
    _43lock_scanner_55762 = 0LL;

    /** parser.e:867		restore_parseargs_states()*/
    _43restore_parseargs_states();

    /** parser.e:868	end procedure*/
    DeRefDS(_fwd_private_list_56232);
    DeRefDSi(_fwd_private_sym_56233);
    return;
    ;
}


void _43ParseArgs(object _subsym_56281)
{
    object _n_56282 = NOVALUE;
    object _fda_56283 = NOVALUE;
    object _lnda_56284 = NOVALUE;
    object _tok_56286 = NOVALUE;
    object _s_56288 = NOVALUE;
    object _var_code_56289 = NOVALUE;
    object _name_56290 = NOVALUE;
    object _28490 = NOVALUE;
    object _28488 = NOVALUE;
    object _28484 = NOVALUE;
    object _28483 = NOVALUE;
    object _28482 = NOVALUE;
    object _28479 = NOVALUE;
    object _28476 = NOVALUE;
    object _28474 = NOVALUE;
    object _28472 = NOVALUE;
    object _28470 = NOVALUE;
    object _28468 = NOVALUE;
    object _28467 = NOVALUE;
    object _28466 = NOVALUE;
    object _28465 = NOVALUE;
    object _28464 = NOVALUE;
    object _28463 = NOVALUE;
    object _28462 = NOVALUE;
    object _28456 = NOVALUE;
    object _28455 = NOVALUE;
    object _28454 = NOVALUE;
    object _28453 = NOVALUE;
    object _28452 = NOVALUE;
    object _28451 = NOVALUE;
    object _28448 = NOVALUE;
    object _28445 = NOVALUE;
    object _28440 = NOVALUE;
    object _28438 = NOVALUE;
    object _28437 = NOVALUE;
    object _28436 = NOVALUE;
    object _28434 = NOVALUE;
    object _28431 = NOVALUE;
    object _28428 = NOVALUE;
    object _28426 = NOVALUE;
    object _28424 = NOVALUE;
    object _28422 = NOVALUE;
    object _28420 = NOVALUE;
    object _28419 = NOVALUE;
    object _28418 = NOVALUE;
    object _28417 = NOVALUE;
    object _28416 = NOVALUE;
    object _28415 = NOVALUE;
    object _28414 = NOVALUE;
    object _28412 = NOVALUE;
    object _28411 = NOVALUE;
    object _28410 = NOVALUE;
    object _28409 = NOVALUE;
    object _28408 = NOVALUE;
    object _28407 = NOVALUE;
    object _28404 = NOVALUE;
    object _28403 = NOVALUE;
    object _28402 = NOVALUE;
    object _28400 = NOVALUE;
    object _28399 = NOVALUE;
    object _28397 = NOVALUE;
    object _28393 = NOVALUE;
    object _28392 = NOVALUE;
    object _28390 = NOVALUE;
    object _28389 = NOVALUE;
    object _28387 = NOVALUE;
    object _28386 = NOVALUE;
    object _28385 = NOVALUE;
    object _28384 = NOVALUE;
    object _28383 = NOVALUE;
    object _28381 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_subsym_56281)) {
        _1 = (object)(DBL_PTR(_subsym_56281)->dbl);
        DeRefDS(_subsym_56281);
        _subsym_56281 = _1;
    }

    /** parser.e:875		object var_code*/

    /** parser.e:876		sequence name*/

    /** parser.e:878		n = SymTab[subsym][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28381 = (object)*(((s1_ptr)_2)->base + _subsym_56281);
    _2 = (object)SEQ_PTR(_28381);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _n_56282 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _n_56282 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    if (!IS_ATOM_INT(_n_56282)){
        _n_56282 = (object)DBL_PTR(_n_56282)->dbl;
    }
    _28381 = NOVALUE;

    /** parser.e:879		if sequence(SymTab[subsym][S_DEF_ARGS]) then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28383 = (object)*(((s1_ptr)_2)->base + _subsym_56281);
    _2 = (object)SEQ_PTR(_28383);
    _28384 = (object)*(((s1_ptr)_2)->base + 28LL);
    _28383 = NOVALUE;
    _28385 = IS_SEQUENCE(_28384);
    _28384 = NOVALUE;
    if (_28385 == 0)
    {
        _28385 = NOVALUE;
        goto L1; // [40] 86
    }
    else{
        _28385 = NOVALUE;
    }

    /** parser.e:880			fda = SymTab[subsym][S_DEF_ARGS][1]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28386 = (object)*(((s1_ptr)_2)->base + _subsym_56281);
    _2 = (object)SEQ_PTR(_28386);
    _28387 = (object)*(((s1_ptr)_2)->base + 28LL);
    _28386 = NOVALUE;
    _2 = (object)SEQ_PTR(_28387);
    _fda_56283 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_fda_56283)){
        _fda_56283 = (object)DBL_PTR(_fda_56283)->dbl;
    }
    _28387 = NOVALUE;

    /** parser.e:881			lnda = SymTab[subsym][S_DEF_ARGS][2]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28389 = (object)*(((s1_ptr)_2)->base + _subsym_56281);
    _2 = (object)SEQ_PTR(_28389);
    _28390 = (object)*(((s1_ptr)_2)->base + 28LL);
    _28389 = NOVALUE;
    _2 = (object)SEQ_PTR(_28390);
    _lnda_56284 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_lnda_56284)){
        _lnda_56284 = (object)DBL_PTR(_lnda_56284)->dbl;
    }
    _28390 = NOVALUE;
    goto L2; // [83] 97
L1: 

    /** parser.e:883			fda = 0*/
    _fda_56283 = 0LL;

    /** parser.e:884			lnda = 0*/
    _lnda_56284 = 0LL;
L2: 

    /** parser.e:886		s = subsym*/
    _s_56288 = _subsym_56281;

    /** parser.e:888		parseargs_states = append(parseargs_states,*/
    if (IS_SEQUENCE(_43private_list_55761)){
            _28392 = SEQ_PTR(_43private_list_55761)->length;
    }
    else {
        _28392 = 1;
    }
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _28392;
    ((intptr_t*)_2)[2] = _43lock_scanner_55762;
    ((intptr_t*)_2)[3] = _12use_private_list_20340;
    ((intptr_t*)_2)[4] = _43on_arg_55763;
    _28393 = MAKE_SEQ(_1);
    _28392 = NOVALUE;
    RefDS(_28393);
    Append(&_43parseargs_states_55756, _43parseargs_states_55756, _28393);
    DeRefDS(_28393);
    _28393 = NOVALUE;

    /** parser.e:890		nested_calls &= subsym*/
    Append(&_43nested_calls_55764, _43nested_calls_55764, _subsym_56281);

    /** parser.e:891		lock_scanner = 0*/
    _43lock_scanner_55762 = 0LL;

    /** parser.e:892		on_arg = 0*/
    _43on_arg_55763 = 0LL;

    /** parser.e:894		short_circuit -= 1*/
    _43short_circuit_55015 = _43short_circuit_55015 - 1LL;

    /** parser.e:895		for i = 1 to n do*/
    _28397 = _n_56282;
    {
        object _i_56319;
        _i_56319 = 1LL;
L3: 
        if (_i_56319 > _28397){
            goto L4; // [161] 1050
        }

        /** parser.e:897		  	tok = next_token()*/
        _0 = _tok_56286;
        _tok_56286 = _43next_token();
        DeRef(_0);

        /** parser.e:899			if tok[T_ID] = QUESTION_MARK or tok[T_ID] = COMMA then*/
        _2 = (object)SEQ_PTR(_tok_56286);
        _28399 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_28399)) {
            _28400 = (_28399 == -31LL);
        }
        else {
            _28400 = binary_op(EQUALS, _28399, -31LL);
        }
        _28399 = NOVALUE;
        if (IS_ATOM_INT(_28400)) {
            if (_28400 != 0) {
                goto L5; // [187] 208
            }
        }
        else {
            if (DBL_PTR(_28400)->dbl != 0.0) {
                goto L5; // [187] 208
            }
        }
        _2 = (object)SEQ_PTR(_tok_56286);
        _28402 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_28402)) {
            _28403 = (_28402 == -30LL);
        }
        else {
            _28403 = binary_op(EQUALS, _28402, -30LL);
        }
        _28402 = NOVALUE;
        if (_28403 == 0) {
            DeRef(_28403);
            _28403 = NOVALUE;
            goto L6; // [204] 505
        }
        else {
            if (!IS_ATOM_INT(_28403) && DBL_PTR(_28403)->dbl == 0.0){
                DeRef(_28403);
                _28403 = NOVALUE;
                goto L6; // [204] 505
            }
            DeRef(_28403);
            _28403 = NOVALUE;
        }
        DeRef(_28403);
        _28403 = NOVALUE;
L5: 

        /** parser.e:902				if tok[T_ID] = QUESTION_MARK then*/
        _2 = (object)SEQ_PTR(_tok_56286);
        _28404 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _28404, -31LL)){
            _28404 = NOVALUE;
            goto L7; // [218] 297
        }
        _28404 = NOVALUE;

        /** parser.e:903					tok = next_token()*/
        _0 = _tok_56286;
        _tok_56286 = _43next_token();
        DeRef(_0);

        /** parser.e:904					if tok[T_ID] != RIGHT_ROUND and tok[T_ID] != COMMA then*/
        _2 = (object)SEQ_PTR(_tok_56286);
        _28407 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_28407)) {
            _28408 = (_28407 != -27LL);
        }
        else {
            _28408 = binary_op(NOTEQ, _28407, -27LL);
        }
        _28407 = NOVALUE;
        if (IS_ATOM_INT(_28408)) {
            if (_28408 == 0) {
                goto L8; // [241] 273
            }
        }
        else {
            if (DBL_PTR(_28408)->dbl == 0.0) {
                goto L8; // [241] 273
            }
        }
        _2 = (object)SEQ_PTR(_tok_56286);
        _28410 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_28410)) {
            _28411 = (_28410 != -30LL);
        }
        else {
            _28411 = binary_op(NOTEQ, _28410, -30LL);
        }
        _28410 = NOVALUE;
        if (_28411 == 0) {
            DeRef(_28411);
            _28411 = NOVALUE;
            goto L8; // [258] 273
        }
        else {
            if (!IS_ATOM_INT(_28411) && DBL_PTR(_28411)->dbl == 0.0){
                DeRef(_28411);
                _28411 = NOVALUE;
                goto L8; // [258] 273
            }
            DeRef(_28411);
            _28411 = NOVALUE;
        }
        DeRef(_28411);
        _28411 = NOVALUE;

        /** parser.e:905						CompileErr( BADLYFORMED_LIST_OF_PARAMETERS__EXPECTED__OR)*/
        RefDS(_22024);
        _49CompileErr(41LL, _22024, 0LL);
        goto L9; // [270] 298
L8: 

        /** parser.e:906					elsif tok[T_ID] = RIGHT_ROUND then*/
        _2 = (object)SEQ_PTR(_tok_56286);
        _28412 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _28412, -27LL)){
            _28412 = NOVALUE;
            goto L9; // [283] 298
        }
        _28412 = NOVALUE;

        /** parser.e:907						putback( tok )*/
        Ref(_tok_56286);
        _43putback(_tok_56286);
        goto L9; // [294] 298
L7: 
L9: 

        /** parser.e:912				if SymTab[subsym][S_OPCODE] then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28414 = (object)*(((s1_ptr)_2)->base + _subsym_56281);
        _2 = (object)SEQ_PTR(_28414);
        _28415 = (object)*(((s1_ptr)_2)->base + 21LL);
        _28414 = NOVALUE;
        if (_28415 == 0) {
            _28415 = NOVALUE;
            goto LA; // [312] 372
        }
        else {
            if (!IS_ATOM_INT(_28415) && DBL_PTR(_28415)->dbl == 0.0){
                _28415 = NOVALUE;
                goto LA; // [312] 372
            }
            _28415 = NOVALUE;
        }
        _28415 = NOVALUE;

        /** parser.e:913					if atom(SymTab[subsym][S_CODE]) then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28416 = (object)*(((s1_ptr)_2)->base + _subsym_56281);
        _2 = (object)SEQ_PTR(_28416);
        if (!IS_ATOM_INT(_12S_CODE_19876)){
            _28417 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
        }
        else{
            _28417 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
        }
        _28416 = NOVALUE;
        _28418 = IS_ATOM(_28417);
        _28417 = NOVALUE;
        if (_28418 == 0)
        {
            _28418 = NOVALUE;
            goto LB; // [332] 343
        }
        else{
            _28418 = NOVALUE;
        }

        /** parser.e:914						var_code = 0*/
        DeRef(_var_code_56289);
        _var_code_56289 = 0LL;
        goto LC; // [340] 362
LB: 

        /** parser.e:916						var_code = SymTab[subsym][S_CODE][i]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28419 = (object)*(((s1_ptr)_2)->base + _subsym_56281);
        _2 = (object)SEQ_PTR(_28419);
        if (!IS_ATOM_INT(_12S_CODE_19876)){
            _28420 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
        }
        else{
            _28420 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
        }
        _28419 = NOVALUE;
        DeRef(_var_code_56289);
        _2 = (object)SEQ_PTR(_28420);
        _var_code_56289 = (object)*(((s1_ptr)_2)->base + _i_56319);
        Ref(_var_code_56289);
        _28420 = NOVALUE;
LC: 

        /** parser.e:918					name = ""*/
        RefDS(_22024);
        DeRef(_name_56290);
        _name_56290 = _22024;
        goto LD; // [369] 419
LA: 

        /** parser.e:920					s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28422 = (object)*(((s1_ptr)_2)->base + _s_56288);
        _2 = (object)SEQ_PTR(_28422);
        _s_56288 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_s_56288)){
            _s_56288 = (object)DBL_PTR(_s_56288)->dbl;
        }
        _28422 = NOVALUE;

        /** parser.e:921					var_code = SymTab[s][S_CODE]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28424 = (object)*(((s1_ptr)_2)->base + _s_56288);
        DeRef(_var_code_56289);
        _2 = (object)SEQ_PTR(_28424);
        if (!IS_ATOM_INT(_12S_CODE_19876)){
            _var_code_56289 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
        }
        else{
            _var_code_56289 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
        }
        Ref(_var_code_56289);
        _28424 = NOVALUE;

        /** parser.e:922					name = SymTab[s][S_NAME]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28426 = (object)*(((s1_ptr)_2)->base + _s_56288);
        DeRef(_name_56290);
        _2 = (object)SEQ_PTR(_28426);
        if (!IS_ATOM_INT(_12S_NAME_19864)){
            _name_56290 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
        }
        else{
            _name_56290 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
        }
        Ref(_name_56290);
        _28426 = NOVALUE;
LD: 

        /** parser.e:925				if atom(var_code) then  -- but no default set*/
        _28428 = IS_ATOM(_var_code_56289);
        if (_28428 == 0)
        {
            _28428 = NOVALUE;
            goto LE; // [426] 439
        }
        else{
            _28428 = NOVALUE;
        }

        /** parser.e:926					CompileErr(ARGUMENT_1_WAS_OMITTED_BUT_THERE_IS_NO_DEFAULT_VALUE_DEFINED,i)*/
        _49CompileErr(29LL, _i_56319, 0LL);
LE: 

        /** parser.e:929				use_private_list = 1*/
        _12use_private_list_20340 = 1LL;

        /** parser.e:930				start_playback(var_code)*/
        Ref(_var_code_56289);
        _43start_playback(_var_code_56289);

        /** parser.e:931				lock_scanner=1*/
        _43lock_scanner_55762 = 1LL;

        /** parser.e:934				Expr()*/
        _43Expr();

        /** parser.e:935				lock_scanner=0*/
        _43lock_scanner_55762 = 0LL;

        /** parser.e:936				on_arg += 1*/
        _43on_arg_55763 = _43on_arg_55763 + 1;

        /** parser.e:937				private_list = append(private_list,name)*/
        RefDS(_name_56290);
        Append(&_43private_list_55761, _43private_list_55761, _name_56290);

        /** parser.e:938				private_sym &= Top()*/
        _28431 = _45Top();
        if (IS_SEQUENCE(_12private_sym_20339) && IS_ATOM(_28431)) {
            Ref(_28431);
            Append(&_12private_sym_20339, _12private_sym_20339, _28431);
        }
        else if (IS_ATOM(_12private_sym_20339) && IS_SEQUENCE(_28431)) {
        }
        else {
            Concat((object_ptr)&_12private_sym_20339, _12private_sym_20339, _28431);
        }
        DeRef(_28431);
        _28431 = NOVALUE;

        /** parser.e:939				backed_up_tok = {tok} -- ????*/
        _0 = _43backed_up_tok_55022;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_tok_56286);
        ((intptr_t*)_2)[1] = _tok_56286;
        _43backed_up_tok_55022 = MAKE_SEQ(_1);
        DeRef(_0);
        goto LF; // [502] 633
L6: 

        /** parser.e:942			elsif tok[T_ID] != RIGHT_ROUND then*/
        _2 = (object)SEQ_PTR(_tok_56286);
        _28434 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(EQUALS, _28434, -27LL)){
            _28434 = NOVALUE;
            goto L10; // [515] 632
        }
        _28434 = NOVALUE;

        /** parser.e:944				if SymTab[subsym][S_OPCODE] then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28436 = (object)*(((s1_ptr)_2)->base + _subsym_56281);
        _2 = (object)SEQ_PTR(_28436);
        _28437 = (object)*(((s1_ptr)_2)->base + 21LL);
        _28436 = NOVALUE;
        if (_28437 == 0) {
            _28437 = NOVALUE;
            goto L11; // [533] 546
        }
        else {
            if (!IS_ATOM_INT(_28437) && DBL_PTR(_28437)->dbl == 0.0){
                _28437 = NOVALUE;
                goto L11; // [533] 546
            }
            _28437 = NOVALUE;
        }
        _28437 = NOVALUE;

        /** parser.e:945					name = ""*/
        RefDS(_22024);
        DeRef(_name_56290);
        _name_56290 = _22024;
        goto L12; // [543] 579
L11: 

        /** parser.e:947					s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28438 = (object)*(((s1_ptr)_2)->base + _s_56288);
        _2 = (object)SEQ_PTR(_28438);
        _s_56288 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_s_56288)){
            _s_56288 = (object)DBL_PTR(_s_56288)->dbl;
        }
        _28438 = NOVALUE;

        /** parser.e:948					name = SymTab[s][S_NAME]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28440 = (object)*(((s1_ptr)_2)->base + _s_56288);
        DeRef(_name_56290);
        _2 = (object)SEQ_PTR(_28440);
        if (!IS_ATOM_INT(_12S_NAME_19864)){
            _name_56290 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
        }
        else{
            _name_56290 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
        }
        Ref(_name_56290);
        _28440 = NOVALUE;
L12: 

        /** parser.e:951				use_private_list = Parser_mode != PAM_NORMAL*/
        _12use_private_list_20340 = (_12Parser_mode_20332 != 0LL);

        /** parser.e:952				putback(tok)*/
        Ref(_tok_56286);
        _43putback(_tok_56286);

        /** parser.e:953				Expr()*/
        _43Expr();

        /** parser.e:954				on_arg += 1*/
        _43on_arg_55763 = _43on_arg_55763 + 1;

        /** parser.e:955				private_list = append(private_list,name)*/
        RefDS(_name_56290);
        Append(&_43private_list_55761, _43private_list_55761, _name_56290);

        /** parser.e:956				private_sym &= Top()*/
        _28445 = _45Top();
        if (IS_SEQUENCE(_12private_sym_20339) && IS_ATOM(_28445)) {
            Ref(_28445);
            Append(&_12private_sym_20339, _12private_sym_20339, _28445);
        }
        else if (IS_ATOM(_12private_sym_20339) && IS_SEQUENCE(_28445)) {
        }
        else {
            Concat((object_ptr)&_12private_sym_20339, _12private_sym_20339, _28445);
        }
        DeRef(_28445);
        _28445 = NOVALUE;
L10: 
LF: 

        /** parser.e:959			if on_arg != n then*/
        if (_43on_arg_55763 == _n_56282)
        goto L13; // [637] 1043

        /** parser.e:960				if tok[T_ID] = RIGHT_ROUND then*/
        _2 = (object)SEQ_PTR(_tok_56286);
        _28448 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _28448, -27LL)){
            _28448 = NOVALUE;
            goto L14; // [651] 661
        }
        _28448 = NOVALUE;

        /** parser.e:961					putback( tok )*/
        Ref(_tok_56286);
        _43putback(_tok_56286);
L14: 

        /** parser.e:963				tok = next_token()*/
        _0 = _tok_56286;
        _tok_56286 = _43next_token();
        DeRef(_0);

        /** parser.e:964				if tok[T_ID] != COMMA and tok[T_ID] != QUESTION_MARK then*/
        _2 = (object)SEQ_PTR(_tok_56286);
        _28451 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_28451)) {
            _28452 = (_28451 != -30LL);
        }
        else {
            _28452 = binary_op(NOTEQ, _28451, -30LL);
        }
        _28451 = NOVALUE;
        if (IS_ATOM_INT(_28452)) {
            if (_28452 == 0) {
                goto L15; // [680] 1042
            }
        }
        else {
            if (DBL_PTR(_28452)->dbl == 0.0) {
                goto L15; // [680] 1042
            }
        }
        _2 = (object)SEQ_PTR(_tok_56286);
        _28454 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_28454)) {
            _28455 = (_28454 != -31LL);
        }
        else {
            _28455 = binary_op(NOTEQ, _28454, -31LL);
        }
        _28454 = NOVALUE;
        if (_28455 == 0) {
            DeRef(_28455);
            _28455 = NOVALUE;
            goto L15; // [697] 1042
        }
        else {
            if (!IS_ATOM_INT(_28455) && DBL_PTR(_28455)->dbl == 0.0){
                DeRef(_28455);
                _28455 = NOVALUE;
                goto L15; // [697] 1042
            }
            DeRef(_28455);
            _28455 = NOVALUE;
        }
        DeRef(_28455);
        _28455 = NOVALUE;

        /** parser.e:966			  		if tok[T_ID] = RIGHT_ROUND then*/
        _2 = (object)SEQ_PTR(_tok_56286);
        _28456 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _28456, -27LL)){
            _28456 = NOVALUE;
            goto L16; // [710] 1027
        }
        _28456 = NOVALUE;

        /** parser.e:968						if fda=0 then*/
        if (_fda_56283 != 0LL)
        goto L17; // [718] 731

        /** parser.e:969							WrongNumberArgs(subsym, "")*/
        RefDS(_22024);
        _43WrongNumberArgs(_subsym_56281, _22024);
        goto L18; // [728] 746
L17: 

        /** parser.e:970						elsif i<lnda then*/
        if (_i_56319 >= _lnda_56284)
        goto L19; // [735] 745

        /** parser.e:971							MissingArgs(subsym)*/
        _43MissingArgs(_subsym_56281);
L19: 
L18: 

        /** parser.e:973						lock_scanner = 1*/
        _43lock_scanner_55762 = 1LL;

        /** parser.e:974						use_private_list = 1*/
        _12use_private_list_20340 = 1LL;

        /** parser.e:977						while on_arg < n do*/
L1A: 
        if (_43on_arg_55763 >= _n_56282)
        goto L1B; // [765] 976

        /** parser.e:978							on_arg += 1*/
        _43on_arg_55763 = _43on_arg_55763 + 1;

        /** parser.e:979							if SymTab[subsym][S_OPCODE] then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28462 = (object)*(((s1_ptr)_2)->base + _subsym_56281);
        _2 = (object)SEQ_PTR(_28462);
        _28463 = (object)*(((s1_ptr)_2)->base + 21LL);
        _28462 = NOVALUE;
        if (_28463 == 0) {
            _28463 = NOVALUE;
            goto L1C; // [791] 853
        }
        else {
            if (!IS_ATOM_INT(_28463) && DBL_PTR(_28463)->dbl == 0.0){
                _28463 = NOVALUE;
                goto L1C; // [791] 853
            }
            _28463 = NOVALUE;
        }
        _28463 = NOVALUE;

        /** parser.e:980								if atom(SymTab[subsym][S_CODE]) then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28464 = (object)*(((s1_ptr)_2)->base + _subsym_56281);
        _2 = (object)SEQ_PTR(_28464);
        if (!IS_ATOM_INT(_12S_CODE_19876)){
            _28465 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
        }
        else{
            _28465 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
        }
        _28464 = NOVALUE;
        _28466 = IS_ATOM(_28465);
        _28465 = NOVALUE;
        if (_28466 == 0)
        {
            _28466 = NOVALUE;
            goto L1D; // [811] 822
        }
        else{
            _28466 = NOVALUE;
        }

        /** parser.e:981									var_code = 0*/
        DeRef(_var_code_56289);
        _var_code_56289 = 0LL;
        goto L1E; // [819] 843
L1D: 

        /** parser.e:983									var_code = SymTab[subsym][S_CODE][on_arg]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28467 = (object)*(((s1_ptr)_2)->base + _subsym_56281);
        _2 = (object)SEQ_PTR(_28467);
        if (!IS_ATOM_INT(_12S_CODE_19876)){
            _28468 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
        }
        else{
            _28468 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
        }
        _28467 = NOVALUE;
        DeRef(_var_code_56289);
        _2 = (object)SEQ_PTR(_28468);
        _var_code_56289 = (object)*(((s1_ptr)_2)->base + _43on_arg_55763);
        Ref(_var_code_56289);
        _28468 = NOVALUE;
L1E: 

        /** parser.e:986								name = ""*/
        RefDS(_22024);
        DeRef(_name_56290);
        _name_56290 = _22024;
        goto L1F; // [850] 900
L1C: 

        /** parser.e:989								s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28470 = (object)*(((s1_ptr)_2)->base + _s_56288);
        _2 = (object)SEQ_PTR(_28470);
        _s_56288 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_s_56288)){
            _s_56288 = (object)DBL_PTR(_s_56288)->dbl;
        }
        _28470 = NOVALUE;

        /** parser.e:990								var_code = SymTab[s][S_CODE]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28472 = (object)*(((s1_ptr)_2)->base + _s_56288);
        DeRef(_var_code_56289);
        _2 = (object)SEQ_PTR(_28472);
        if (!IS_ATOM_INT(_12S_CODE_19876)){
            _var_code_56289 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
        }
        else{
            _var_code_56289 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
        }
        Ref(_var_code_56289);
        _28472 = NOVALUE;

        /** parser.e:991								name = SymTab[s][S_NAME]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28474 = (object)*(((s1_ptr)_2)->base + _s_56288);
        DeRef(_name_56290);
        _2 = (object)SEQ_PTR(_28474);
        if (!IS_ATOM_INT(_12S_NAME_19864)){
            _name_56290 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
        }
        else{
            _name_56290 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
        }
        Ref(_name_56290);
        _28474 = NOVALUE;
L1F: 

        /** parser.e:993							if sequence(var_code) then*/
        _28476 = IS_SEQUENCE(_var_code_56289);
        if (_28476 == 0)
        {
            _28476 = NOVALUE;
            goto L20; // [907] 959
        }
        else{
            _28476 = NOVALUE;
        }

        /** parser.e:995								putback( tok )*/
        Ref(_tok_56286);
        _43putback(_tok_56286);

        /** parser.e:996								start_playback(var_code)*/
        Ref(_var_code_56289);
        _43start_playback(_var_code_56289);

        /** parser.e:999								Expr()*/
        _43Expr();

        /** parser.e:1000								if on_arg < n then*/
        if (_43on_arg_55763 >= _n_56282)
        goto L1A; // [928] 763

        /** parser.e:1001									private_list = append(private_list,name)*/
        RefDS(_name_56290);
        Append(&_43private_list_55761, _43private_list_55761, _name_56290);

        /** parser.e:1002									private_sym &= Top()*/
        _28479 = _45Top();
        if (IS_SEQUENCE(_12private_sym_20339) && IS_ATOM(_28479)) {
            Ref(_28479);
            Append(&_12private_sym_20339, _12private_sym_20339, _28479);
        }
        else if (IS_ATOM(_12private_sym_20339) && IS_SEQUENCE(_28479)) {
        }
        else {
            Concat((object_ptr)&_12private_sym_20339, _12private_sym_20339, _28479);
        }
        DeRef(_28479);
        _28479 = NOVALUE;
        goto L1A; // [956] 763
L20: 

        /** parser.e:1005								CompileErr(ARGUMENT_1_WAS_OMITTED_BUT_THERE_IS_NO_DEFAULT_VALUE_DEFINED, on_arg)*/
        _49CompileErr(29LL, _43on_arg_55763, 0LL);

        /** parser.e:1007			  		    end while*/
        goto L1A; // [973] 763
L1B: 

        /** parser.e:1009						short_circuit += 1*/
        _43short_circuit_55015 = _43short_circuit_55015 + 1;

        /** parser.e:1010						if backed_up_tok[$][T_ID] = PLAYBACK_ENDS then*/
        if (IS_SEQUENCE(_43backed_up_tok_55022)){
                _28482 = SEQ_PTR(_43backed_up_tok_55022)->length;
        }
        else {
            _28482 = 1;
        }
        _2 = (object)SEQ_PTR(_43backed_up_tok_55022);
        _28483 = (object)*(((s1_ptr)_2)->base + _28482);
        _2 = (object)SEQ_PTR(_28483);
        _28484 = (object)*(((s1_ptr)_2)->base + 1LL);
        _28483 = NOVALUE;
        if (binary_op_a(NOTEQ, _28484, 505LL)){
            _28484 = NOVALUE;
            goto L21; // [1003] 1015
        }
        _28484 = NOVALUE;

        /** parser.e:1011							backed_up_tok = {}*/
        RefDS(_22024);
        DeRefDS(_43backed_up_tok_55022);
        _43backed_up_tok_55022 = _22024;
L21: 

        /** parser.e:1014						restore_parseargs_states()*/
        _43restore_parseargs_states();

        /** parser.e:1016						return*/
        DeRef(_tok_56286);
        DeRef(_var_code_56289);
        DeRef(_name_56290);
        DeRef(_28400);
        _28400 = NOVALUE;
        DeRef(_28452);
        _28452 = NOVALUE;
        DeRef(_28408);
        _28408 = NOVALUE;
        return;
        goto L22; // [1024] 1041
L16: 

        /** parser.e:1018						putback(tok)*/
        Ref(_tok_56286);
        _43putback(_tok_56286);

        /** parser.e:1019						tok_match(COMMA)*/
        _43tok_match(-30LL, 0LL);
L22: 
L15: 
L13: 

        /** parser.e:1024		end for*/
        _i_56319 = _i_56319 + 1LL;
        goto L3; // [1045] 168
L4: 
        ;
    }

    /** parser.e:1025		tok = next_token()*/
    _0 = _tok_56286;
    _tok_56286 = _43next_token();
    DeRef(_0);

    /** parser.e:1026		short_circuit += 1*/
    _43short_circuit_55015 = _43short_circuit_55015 + 1;

    /** parser.e:1027		if tok[T_ID] != RIGHT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok_56286);
    _28488 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _28488, -27LL)){
        _28488 = NOVALUE;
        goto L23; // [1073] 1115
    }
    _28488 = NOVALUE;

    /** parser.e:1028			if tok[T_ID] = COMMA then*/
    _2 = (object)SEQ_PTR(_tok_56286);
    _28490 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28490, -30LL)){
        _28490 = NOVALUE;
        goto L24; // [1087] 1100
    }
    _28490 = NOVALUE;

    /** parser.e:1029				WrongNumberArgs(subsym, "only ")*/
    RefDS(_28492);
    _43WrongNumberArgs(_subsym_56281, _28492);
    goto L25; // [1097] 1114
L24: 

    /** parser.e:1031				putback(tok)*/
    Ref(_tok_56286);
    _43putback(_tok_56286);

    /** parser.e:1032				tok_match(RIGHT_ROUND)*/
    _43tok_match(-27LL, 0LL);
L25: 
L23: 

    /** parser.e:1036		restore_parseargs_states()*/
    _43restore_parseargs_states();

    /** parser.e:1037	end procedure*/
    DeRef(_tok_56286);
    DeRef(_var_code_56289);
    DeRef(_name_56290);
    DeRef(_28400);
    _28400 = NOVALUE;
    DeRef(_28452);
    _28452 = NOVALUE;
    DeRef(_28408);
    _28408 = NOVALUE;
    return;
    ;
}


void _43Forward_var(object _tok_56531, object _init_check_56532, object _op_56533)
{
    object _ref_56537 = NOVALUE;
    object _28496 = NOVALUE;
    object _28494 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_op_56533)) {
        _1 = (object)(DBL_PTR(_op_56533)->dbl);
        DeRefDS(_op_56533);
        _op_56533 = _1;
    }

    /** parser.e:1041		ref = new_forward_reference( VARIABLE, tok[T_SYM], op )*/
    _2 = (object)SEQ_PTR(_tok_56531);
    _28494 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_28494);
    _ref_56537 = _42new_forward_reference(-100LL, _28494, _op_56533);
    _28494 = NOVALUE;
    if (!IS_ATOM_INT(_ref_56537)) {
        _1 = (object)(DBL_PTR(_ref_56537)->dbl);
        DeRefDS(_ref_56537);
        _ref_56537 = _1;
    }

    /** parser.e:1042		emit_opnd( - ref )*/
    if ((uintptr_t)_ref_56537 == (uintptr_t)HIGH_BITS){
        _28496 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _28496 = - _ref_56537;
    }
    _45emit_opnd(_28496);
    _28496 = NOVALUE;

    /** parser.e:1043		if init_check != -1 then*/
    if (_init_check_56532 == -1LL)
    goto L1; // [33] 44

    /** parser.e:1044			Forward_InitCheck( tok, init_check )*/
    Ref(_tok_56531);
    _43Forward_InitCheck(_tok_56531, _init_check_56532);
L1: 

    /** parser.e:1047	end procedure*/
    DeRef(_tok_56531);
    return;
    ;
}


void _43Forward_call(object _tok_56550, object _opcode_56551)
{
    object _args_56554 = NOVALUE;
    object _proc_56556 = NOVALUE;
    object _tok_id_56559 = NOVALUE;
    object _id_56566 = NOVALUE;
    object _fc_pc_56590 = NOVALUE;
    object _28515 = NOVALUE;
    object _28514 = NOVALUE;
    object _28511 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1050		integer args = 0*/
    _args_56554 = 0LL;

    /** parser.e:1051		symtab_index proc = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_56550);
    _proc_56556 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_proc_56556)){
        _proc_56556 = (object)DBL_PTR(_proc_56556)->dbl;
    }

    /** parser.e:1052		integer tok_id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_56550);
    _tok_id_56559 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_tok_id_56559)){
        _tok_id_56559 = (object)DBL_PTR(_tok_id_56559)->dbl;
    }

    /** parser.e:1053		remove_symbol( proc )*/
    _53remove_symbol(_proc_56556);

    /** parser.e:1054		short_circuit -= 1*/
    _43short_circuit_55015 = _43short_circuit_55015 - 1LL;

    /** parser.e:1055		while 1 do*/
L1: 

    /** parser.e:1056			tok = next_token()*/
    _0 = _tok_56550;
    _tok_56550 = _43next_token();
    DeRef(_0);

    /** parser.e:1057			integer id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_56550);
    _id_56566 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_56566)){
        _id_56566 = (object)DBL_PTR(_id_56566)->dbl;
    }

    /** parser.e:1059			switch id do*/
    _0 = _id_56566;
    switch ( _0 ){ 

        /** parser.e:1060				case COMMA then*/
        case -30:

        /** parser.e:1061					emit_opnd( 0 ) -- clean this up later*/
        _45emit_opnd(0LL);

        /** parser.e:1062					args += 1*/
        _args_56554 = _args_56554 + 1;
        goto L2; // [83] 168

        /** parser.e:1064				case RIGHT_ROUND then*/
        case -27:

        /** parser.e:1065					exit*/
        goto L3; // [93] 175
        goto L2; // [95] 168

        /** parser.e:1067				case else*/
        default:

        /** parser.e:1068					putback( tok )*/
        Ref(_tok_56550);
        _43putback(_tok_56550);

        /** parser.e:1069					call_proc( forward_expr, {} )*/
        _0 = (object)_00[_43forward_expr_56052].addr;
        (*(intptr_t (*)())_0)(
                             );

        /** parser.e:1070					args += 1*/
        _args_56554 = _args_56554 + 1;

        /** parser.e:1072					tok = next_token()*/
        _0 = _tok_56550;
        _tok_56550 = _43next_token();
        DeRef(_0);

        /** parser.e:1073					id = tok[T_ID]*/
        _2 = (object)SEQ_PTR(_tok_56550);
        _id_56566 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (!IS_ATOM_INT(_id_56566)){
            _id_56566 = (object)DBL_PTR(_id_56566)->dbl;
        }

        /** parser.e:1074					if id = RIGHT_ROUND then*/
        if (_id_56566 != -27LL)
        goto L4; // [138] 149

        /** parser.e:1075						exit*/
        goto L3; // [146] 175
L4: 

        /** parser.e:1078					if id != COMMA then*/
        if (_id_56566 == -30LL)
        goto L5; // [153] 167

        /** parser.e:1079							CompileErr(EXPECTED__OR)*/
        RefDS(_22024);
        _49CompileErr(69LL, _22024, 0LL);
L5: 
    ;}L2: 

    /** parser.e:1082		end while*/
    goto L1; // [172] 46
L3: 

    /** parser.e:1084		integer fc_pc = length( Code ) + 1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _28511 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _28511 = 1;
    }
    _fc_pc_56590 = _28511 + 1;
    _28511 = NOVALUE;

    /** parser.e:1085		emit_opnd( args )*/
    _45emit_opnd(_args_56554);

    /** parser.e:1087		op_info1 = proc*/
    _45op_info1_51020 = _proc_56556;

    /** parser.e:1088		if tok_id = QUALIFIED_VARIABLE then*/
    if (_tok_id_56559 != 512LL)
    goto L6; // [202] 226

    /** parser.e:1089			set_qualified_fwd( SymTab[proc][S_FILE_NO] )*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28514 = (object)*(((s1_ptr)_2)->base + _proc_56556);
    _2 = (object)SEQ_PTR(_28514);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _28515 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _28515 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _28514 = NOVALUE;
    Ref(_28515);
    _61set_qualified_fwd(_28515);
    _28515 = NOVALUE;
    goto L7; // [223] 232
L6: 

    /** parser.e:1091			set_qualified_fwd( -1 )*/
    _61set_qualified_fwd(-1LL);
L7: 

    /** parser.e:1093		emit_op( opcode )*/
    _45emit_op(_opcode_56551);

    /** parser.e:1094		if not TRANSLATE then*/
    if (_12TRANSLATE_19834 != 0)
    goto L8; // [241] 260

    /** parser.e:1095			if OpTrace then*/
    if (_12OpTrace_20296 == 0)
    {
        goto L9; // [248] 259
    }
    else{
    }

    /** parser.e:1096				emit_op(UPDATE_GLOBALS)*/
    _45emit_op(89LL);
L9: 
L8: 

    /** parser.e:1099		short_circuit += 1*/
    _43short_circuit_55015 = _43short_circuit_55015 + 1;

    /** parser.e:1100	end procedure*/
    DeRef(_tok_56550);
    return;
    ;
}


void _43Object_call(object _tok_56618)
{
    object _tok2_56620 = NOVALUE;
    object _tok3_56621 = NOVALUE;
    object _save_factors_56622 = NOVALUE;
    object _save_lhs_subs_level_56623 = NOVALUE;
    object _sym_56625 = NOVALUE;
    object _28573 = NOVALUE;
    object _28571 = NOVALUE;
    object _28568 = NOVALUE;
    object _28564 = NOVALUE;
    object _28558 = NOVALUE;
    object _28555 = NOVALUE;
    object _28554 = NOVALUE;
    object _28553 = NOVALUE;
    object _28551 = NOVALUE;
    object _28550 = NOVALUE;
    object _28548 = NOVALUE;
    object _28547 = NOVALUE;
    object _28544 = NOVALUE;
    object _28543 = NOVALUE;
    object _28542 = NOVALUE;
    object _28540 = NOVALUE;
    object _28539 = NOVALUE;
    object _28537 = NOVALUE;
    object _28536 = NOVALUE;
    object _28535 = NOVALUE;
    object _28534 = NOVALUE;
    object _28532 = NOVALUE;
    object _28531 = NOVALUE;
    object _28529 = NOVALUE;
    object _28528 = NOVALUE;
    object _28525 = NOVALUE;
    object _28523 = NOVALUE;
    object _28522 = NOVALUE;
    object _28520 = NOVALUE;
    object _28519 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:1104		integer save_factors, save_lhs_subs_level*/

    /** parser.e:1107		tok2 = next_token()*/
    _0 = _tok2_56620;
    _tok2_56620 = _43next_token();
    DeRef(_0);

    /** parser.e:1108		if tok2[T_ID] = VARIABLE or tok2[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok2_56620);
    _28519 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28519)) {
        _28520 = (_28519 == -100LL);
    }
    else {
        _28520 = binary_op(EQUALS, _28519, -100LL);
    }
    _28519 = NOVALUE;
    if (IS_ATOM_INT(_28520)) {
        if (_28520 != 0) {
            goto L1; // [22] 43
        }
    }
    else {
        if (DBL_PTR(_28520)->dbl != 0.0) {
            goto L1; // [22] 43
        }
    }
    _2 = (object)SEQ_PTR(_tok2_56620);
    _28522 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28522)) {
        _28523 = (_28522 == 512LL);
    }
    else {
        _28523 = binary_op(EQUALS, _28522, 512LL);
    }
    _28522 = NOVALUE;
    if (_28523 == 0) {
        DeRef(_28523);
        _28523 = NOVALUE;
        goto L2; // [39] 582
    }
    else {
        if (!IS_ATOM_INT(_28523) && DBL_PTR(_28523)->dbl == 0.0){
            DeRef(_28523);
            _28523 = NOVALUE;
            goto L2; // [39] 582
        }
        DeRef(_28523);
        _28523 = NOVALUE;
    }
    DeRef(_28523);
    _28523 = NOVALUE;
L1: 

    /** parser.e:1109			tok3 = next_token()*/
    _0 = _tok3_56621;
    _tok3_56621 = _43next_token();
    DeRef(_0);

    /** parser.e:1110			if tok3[T_ID] = RIGHT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok3_56621);
    _28525 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28525, -27LL)){
        _28525 = NOVALUE;
        goto L3; // [58] 155
    }
    _28525 = NOVALUE;

    /** parser.e:1112				sym = tok2[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok2_56620);
    _sym_56625 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_sym_56625)){
        _sym_56625 = (object)DBL_PTR(_sym_56625)->dbl;
    }

    /** parser.e:1113				if SymTab[sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28528 = (object)*(((s1_ptr)_2)->base + _sym_56625);
    _2 = (object)SEQ_PTR(_28528);
    _28529 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28528 = NOVALUE;
    if (binary_op_a(NOTEQ, _28529, 9LL)){
        _28529 = NOVALUE;
        goto L4; // [88] 108
    }
    _28529 = NOVALUE;

    /** parser.e:1114					Forward_var( tok2 )*/
    _2 = (object)SEQ_PTR(_tok2_56620);
    _28531 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_tok2_56620);
    Ref(_28531);
    _43Forward_var(_tok2_56620, -1LL, _28531);
    _28531 = NOVALUE;
    goto L5; // [105] 147
L4: 

    /** parser.e:1116					SymTab[sym][S_USAGE] = or_bits(SymTab[sym][S_USAGE], U_READ)*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_56625 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28534 = (object)*(((s1_ptr)_2)->base + _sym_56625);
    _2 = (object)SEQ_PTR(_28534);
    _28535 = (object)*(((s1_ptr)_2)->base + 5LL);
    _28534 = NOVALUE;
    if (IS_ATOM_INT(_28535)) {
        {uintptr_t tu;
             tu = (uintptr_t)_28535 | (uintptr_t)1LL;
             _28536 = MAKE_UINT(tu);
        }
    }
    else {
        _28536 = binary_op(OR_BITS, _28535, 1LL);
    }
    _28535 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _28536;
    if( _1 != _28536 ){
        DeRef(_1);
    }
    _28536 = NOVALUE;
    _28532 = NOVALUE;

    /** parser.e:1118					emit_opnd(sym)*/
    _45emit_opnd(_sym_56625);
L5: 

    /** parser.e:1120				putback( tok3 )*/
    Ref(_tok3_56621);
    _43putback(_tok3_56621);
    goto L6; // [152] 571
L3: 

    /** parser.e:1122			elsif tok3[T_ID] = COMMA then*/
    _2 = (object)SEQ_PTR(_tok3_56621);
    _28537 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28537, -30LL)){
        _28537 = NOVALUE;
        goto L7; // [165] 184
    }
    _28537 = NOVALUE;

    /** parser.e:1124				WrongNumberArgs(tok[T_SYM], "")*/
    _2 = (object)SEQ_PTR(_tok_56618);
    _28539 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_28539);
    RefDS(_22024);
    _43WrongNumberArgs(_28539, _22024);
    _28539 = NOVALUE;
    goto L6; // [181] 571
L7: 

    /** parser.e:1126			elsif tok3[T_ID] = LEFT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok3_56621);
    _28540 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28540, -26LL)){
        _28540 = NOVALUE;
        goto L8; // [194] 244
    }
    _28540 = NOVALUE;

    /** parser.e:1127				if SymTab[tok2[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_tok2_56620);
    _28542 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28542)){
        _28543 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28542)->dbl));
    }
    else{
        _28543 = (object)*(((s1_ptr)_2)->base + _28542);
    }
    _2 = (object)SEQ_PTR(_28543);
    _28544 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28543 = NOVALUE;
    if (binary_op_a(NOTEQ, _28544, 9LL)){
        _28544 = NOVALUE;
        goto L9; // [220] 235
    }
    _28544 = NOVALUE;

    /** parser.e:1128					Forward_call( tok2, FUNC_FORWARD )*/
    Ref(_tok2_56620);
    _43Forward_call(_tok2_56620, 196LL);
    goto L6; // [232] 571
L9: 

    /** parser.e:1130					Function_call( tok2 )*/
    Ref(_tok2_56620);
    _43Function_call(_tok2_56620);
    goto L6; // [241] 571
L8: 

    /** parser.e:1139				sym = tok2[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok2_56620);
    _sym_56625 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_sym_56625)){
        _sym_56625 = (object)DBL_PTR(_sym_56625)->dbl;
    }

    /** parser.e:1140				if SymTab[sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28547 = (object)*(((s1_ptr)_2)->base + _sym_56625);
    _2 = (object)SEQ_PTR(_28547);
    _28548 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28547 = NOVALUE;
    if (binary_op_a(NOTEQ, _28548, 9LL)){
        _28548 = NOVALUE;
        goto LA; // [270] 292
    }
    _28548 = NOVALUE;

    /** parser.e:1141					Forward_var( tok2, TRUE )*/
    _2 = (object)SEQ_PTR(_tok2_56620);
    _28550 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_tok2_56620);
    Ref(_28550);
    _43Forward_var(_tok2_56620, _9TRUE_446, _28550);
    _28550 = NOVALUE;
    goto LB; // [289] 339
LA: 

    /** parser.e:1143					SymTab[sym][S_USAGE] = or_bits(SymTab[sym][S_USAGE], U_READ)*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_56625 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28553 = (object)*(((s1_ptr)_2)->base + _sym_56625);
    _2 = (object)SEQ_PTR(_28553);
    _28554 = (object)*(((s1_ptr)_2)->base + 5LL);
    _28553 = NOVALUE;
    if (IS_ATOM_INT(_28554)) {
        {uintptr_t tu;
             tu = (uintptr_t)_28554 | (uintptr_t)1LL;
             _28555 = MAKE_UINT(tu);
        }
    }
    else {
        _28555 = binary_op(OR_BITS, _28554, 1LL);
    }
    _28554 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _28555;
    if( _1 != _28555 ){
        DeRef(_1);
    }
    _28555 = NOVALUE;
    _28551 = NOVALUE;

    /** parser.e:1144					InitCheck(sym, TRUE)*/
    _43InitCheck(_sym_56625, _9TRUE_446);

    /** parser.e:1145					emit_opnd(sym)*/
    _45emit_opnd(_sym_56625);
LB: 

    /** parser.e:1149				if sym = left_sym then*/
    if (_sym_56625 != _43left_sym_55056)
    goto LC; // [343] 353

    /** parser.e:1150					lhs_subs_level = 0*/
    _43lhs_subs_level_55054 = 0LL;
LC: 

    /** parser.e:1155				tok2 = tok3*/
    Ref(_tok3_56621);
    DeRef(_tok2_56620);
    _tok2_56620 = _tok3_56621;

    /** parser.e:1156				current_sequence = append(current_sequence, sym)*/
    Append(&_45current_sequence_51028, _45current_sequence_51028, _sym_56625);

    /** parser.e:1157				while tok2[T_ID] = LEFT_SQUARE do*/
LD: 
    _2 = (object)SEQ_PTR(_tok2_56620);
    _28558 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28558, -28LL)){
        _28558 = NOVALUE;
        goto LE; // [381] 549
    }
    _28558 = NOVALUE;

    /** parser.e:1158					subs_depth += 1*/
    _43subs_depth_55057 = _43subs_depth_55057 + 1;

    /** parser.e:1159					if lhs_subs_level >= 0 then*/
    if (_43lhs_subs_level_55054 < 0LL)
    goto LF; // [397] 410

    /** parser.e:1160						lhs_subs_level += 1*/
    _43lhs_subs_level_55054 = _43lhs_subs_level_55054 + 1;
LF: 

    /** parser.e:1162					save_factors = factors*/
    _save_factors_56622 = _43factors_55053;

    /** parser.e:1163					save_lhs_subs_level = lhs_subs_level*/
    _save_lhs_subs_level_56623 = _43lhs_subs_level_55054;

    /** parser.e:1164					call_proc(forward_expr, {})*/
    _0 = (object)_00[_43forward_expr_56052].addr;
    (*(intptr_t (*)())_0)(
                         );

    /** parser.e:1165					tok2 = next_token()*/
    _0 = _tok2_56620;
    _tok2_56620 = _43next_token();
    DeRef(_0);

    /** parser.e:1166					if tok2[T_ID] = SLICE then*/
    _2 = (object)SEQ_PTR(_tok2_56620);
    _28564 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28564, 513LL)){
        _28564 = NOVALUE;
        goto L10; // [446] 484
    }
    _28564 = NOVALUE;

    /** parser.e:1167						call_proc(forward_expr, {})*/
    _0 = (object)_00[_43forward_expr_56052].addr;
    (*(intptr_t (*)())_0)(
                         );

    /** parser.e:1168						emit_op(RHS_SLICE)*/
    _45emit_op(46LL);

    /** parser.e:1169						tok_match(RIGHT_SQUARE)*/
    _43tok_match(-29LL, 0LL);

    /** parser.e:1170						tok2 = next_token()*/
    _0 = _tok2_56620;
    _tok2_56620 = _43next_token();
    DeRef(_0);

    /** parser.e:1171						exit*/
    goto LE; // [479] 549
    goto L11; // [481] 529
L10: 

    /** parser.e:1173						putback(tok2)*/
    Ref(_tok2_56620);
    _43putback(_tok2_56620);

    /** parser.e:1174						tok_match(RIGHT_SQUARE)*/
    _43tok_match(-29LL, 0LL);

    /** parser.e:1175						subs_depth -= 1*/
    _43subs_depth_55057 = _43subs_depth_55057 - 1LL;

    /** parser.e:1176						current_sequence = remove( current_sequence, length( current_sequence ) )*/
    if (IS_SEQUENCE(_45current_sequence_51028)){
            _28568 = SEQ_PTR(_45current_sequence_51028)->length;
    }
    else {
        _28568 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_45current_sequence_51028);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_28568)) ? _28568 : (object)(DBL_PTR(_28568)->dbl);
        int stop = (IS_ATOM_INT(_28568)) ? _28568 : (object)(DBL_PTR(_28568)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_45current_sequence_51028), start, &_45current_sequence_51028 );
            }
            else Tail(SEQ_PTR(_45current_sequence_51028), stop+1, &_45current_sequence_51028);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_45current_sequence_51028), start, &_45current_sequence_51028);
        }
        else {
            assign_slice_seq = &assign_space;
            _45current_sequence_51028 = Remove_elements(start, stop, (SEQ_PTR(_45current_sequence_51028)->ref == 1));
        }
    }
    _28568 = NOVALUE;
    _28568 = NOVALUE;

    /** parser.e:1177						emit_op(RHS_SUBS)*/
    _45emit_op(25LL);
L11: 

    /** parser.e:1180					factors = save_factors*/
    _43factors_55053 = _save_factors_56622;

    /** parser.e:1181					lhs_subs_level = save_lhs_subs_level*/
    _43lhs_subs_level_55054 = _save_lhs_subs_level_56623;

    /** parser.e:1182					tok2 = next_token()*/
    _0 = _tok2_56620;
    _tok2_56620 = _43next_token();
    DeRef(_0);

    /** parser.e:1183				end while*/
    goto LD; // [546] 373
LE: 

    /** parser.e:1184				current_sequence = remove( current_sequence, length( current_sequence ) )*/
    if (IS_SEQUENCE(_45current_sequence_51028)){
            _28571 = SEQ_PTR(_45current_sequence_51028)->length;
    }
    else {
        _28571 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_45current_sequence_51028);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_28571)) ? _28571 : (object)(DBL_PTR(_28571)->dbl);
        int stop = (IS_ATOM_INT(_28571)) ? _28571 : (object)(DBL_PTR(_28571)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_45current_sequence_51028), start, &_45current_sequence_51028 );
            }
            else Tail(SEQ_PTR(_45current_sequence_51028), stop+1, &_45current_sequence_51028);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_45current_sequence_51028), start, &_45current_sequence_51028);
        }
        else {
            assign_slice_seq = &assign_space;
            _45current_sequence_51028 = Remove_elements(start, stop, (SEQ_PTR(_45current_sequence_51028)->ref == 1));
        }
    }
    _28571 = NOVALUE;
    _28571 = NOVALUE;

    /** parser.e:1185				putback(tok2)*/
    Ref(_tok2_56620);
    _43putback(_tok2_56620);
L6: 

    /** parser.e:1189			tok_match( RIGHT_ROUND )*/
    _43tok_match(-27LL, 0LL);
    goto L12; // [579] 599
L2: 

    /** parser.e:1191			putback(tok2)*/
    Ref(_tok2_56620);
    _43putback(_tok2_56620);

    /** parser.e:1192			ParseArgs(tok[T_SYM])*/
    _2 = (object)SEQ_PTR(_tok_56618);
    _28573 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_28573);
    _43ParseArgs(_28573);
    _28573 = NOVALUE;
L12: 

    /** parser.e:1194	end procedure*/
    DeRef(_tok_56618);
    DeRef(_tok2_56620);
    DeRef(_tok3_56621);
    DeRef(_28520);
    _28520 = NOVALUE;
    _28542 = NOVALUE;
    return;
    ;
}


void _43Function_call(object _tok_56763)
{
    object _id_56764 = NOVALUE;
    object _scope_56765 = NOVALUE;
    object _opcode_56766 = NOVALUE;
    object _e_56767 = NOVALUE;
    object _28615 = NOVALUE;
    object _28614 = NOVALUE;
    object _28613 = NOVALUE;
    object _28612 = NOVALUE;
    object _28611 = NOVALUE;
    object _28610 = NOVALUE;
    object _28609 = NOVALUE;
    object _28607 = NOVALUE;
    object _28606 = NOVALUE;
    object _28604 = NOVALUE;
    object _28603 = NOVALUE;
    object _28602 = NOVALUE;
    object _28601 = NOVALUE;
    object _28600 = NOVALUE;
    object _28599 = NOVALUE;
    object _28598 = NOVALUE;
    object _28597 = NOVALUE;
    object _28595 = NOVALUE;
    object _28594 = NOVALUE;
    object _28593 = NOVALUE;
    object _28592 = NOVALUE;
    object _28591 = NOVALUE;
    object _28590 = NOVALUE;
    object _28589 = NOVALUE;
    object _28587 = NOVALUE;
    object _28585 = NOVALUE;
    object _28584 = NOVALUE;
    object _28582 = NOVALUE;
    object _28580 = NOVALUE;
    object _28579 = NOVALUE;
    object _28578 = NOVALUE;
    object _28577 = NOVALUE;
    object _28575 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:1200		id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_56763);
    _id_56764 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_56764)){
        _id_56764 = (object)DBL_PTR(_id_56764)->dbl;
    }

    /** parser.e:1201		if id = FUNC or id = TYPE then*/
    _28575 = (_id_56764 == 501LL);
    if (_28575 != 0) {
        goto L1; // [19] 34
    }
    _28577 = (_id_56764 == 504LL);
    if (_28577 == 0)
    {
        DeRef(_28577);
        _28577 = NOVALUE;
        goto L2; // [30] 46
    }
    else{
        DeRef(_28577);
        _28577 = NOVALUE;
    }
L1: 

    /** parser.e:1203			UndefinedVar( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_56763);
    _28578 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_28578);
    _43UndefinedVar(_28578);
    _28578 = NOVALUE;
L2: 

    /** parser.e:1206		e = SymTab[tok[T_SYM]][S_EFFECT]*/
    _2 = (object)SEQ_PTR(_tok_56763);
    _28579 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28579)){
        _28580 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28579)->dbl));
    }
    else{
        _28580 = (object)*(((s1_ptr)_2)->base + _28579);
    }
    _2 = (object)SEQ_PTR(_28580);
    _e_56767 = (object)*(((s1_ptr)_2)->base + 23LL);
    if (!IS_ATOM_INT(_e_56767)){
        _e_56767 = (object)DBL_PTR(_e_56767)->dbl;
    }
    _28580 = NOVALUE;

    /** parser.e:1207		if e then*/
    if (_e_56767 == 0)
    {
        goto L3; // [70] 229
    }
    else{
    }

    /** parser.e:1209			if e = E_ALL_EFFECT or tok[T_SYM] > left_sym then*/
    _28582 = (_e_56767 == 1073741823LL);
    if (_28582 != 0) {
        goto L4; // [81] 102
    }
    _2 = (object)SEQ_PTR(_tok_56763);
    _28584 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_28584)) {
        _28585 = (_28584 > _43left_sym_55056);
    }
    else {
        _28585 = binary_op(GREATER, _28584, _43left_sym_55056);
    }
    _28584 = NOVALUE;
    if (_28585 == 0) {
        DeRef(_28585);
        _28585 = NOVALUE;
        goto L5; // [98] 111
    }
    else {
        if (!IS_ATOM_INT(_28585) && DBL_PTR(_28585)->dbl == 0.0){
            DeRef(_28585);
            _28585 = NOVALUE;
            goto L5; // [98] 111
        }
        DeRef(_28585);
        _28585 = NOVALUE;
    }
    DeRef(_28585);
    _28585 = NOVALUE;
L4: 

    /** parser.e:1211				side_effect_calls = or_bits(side_effect_calls, e)*/
    {uintptr_t tu;
         tu = (uintptr_t)_43side_effect_calls_55052 | (uintptr_t)_e_56767;
         _43side_effect_calls_55052 = MAKE_UINT(tu);
    }
L5: 

    /** parser.e:1214			SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT], e)*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12CurrentSub_20234 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28589 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_28589);
    _28590 = (object)*(((s1_ptr)_2)->base + 23LL);
    _28589 = NOVALUE;
    if (IS_ATOM_INT(_28590)) {
        {uintptr_t tu;
             tu = (uintptr_t)_28590 | (uintptr_t)_e_56767;
             _28591 = MAKE_UINT(tu);
        }
    }
    else {
        _28591 = binary_op(OR_BITS, _28590, _e_56767);
    }
    _28590 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _28591;
    if( _1 != _28591 ){
        DeRef(_1);
    }
    _28591 = NOVALUE;
    _28587 = NOVALUE;

    /** parser.e:1216			if short_circuit > 0 and short_circuit_B and*/
    _28592 = (_43short_circuit_55015 > 0LL);
    if (_28592 == 0) {
        _28593 = 0;
        goto L6; // [154] 164
    }
    _28593 = (_43short_circuit_B_55017 != 0);
L6: 
    if (_28593 == 0) {
        goto L7; // [164] 228
    }
    _28595 = find_from(_id_56764, _29FUNC_TOKS_12018, 1LL);
    if (_28595 == 0)
    {
        _28595 = NOVALUE;
        goto L7; // [176] 228
    }
    else{
        _28595 = NOVALUE;
    }

    /** parser.e:1218				Warning(219, short_circuit_warning_flag,*/
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _28597 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    Ref(_28597);
    RefDS(_22024);
    _28598 = _14abbreviate_path(_28597, _22024);
    _28597 = NOVALUE;
    _2 = (object)SEQ_PTR(_tok_56763);
    _28599 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28599)){
        _28600 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28599)->dbl));
    }
    else{
        _28600 = (object)*(((s1_ptr)_2)->base + _28599);
    }
    _2 = (object)SEQ_PTR(_28600);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _28601 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _28601 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _28600 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _28598;
    ((intptr_t*)_2)[2] = _12line_number_20227;
    Ref(_28601);
    ((intptr_t*)_2)[3] = _28601;
    _28602 = MAKE_SEQ(_1);
    _28601 = NOVALUE;
    _28598 = NOVALUE;
    _49Warning(219LL, 2LL, _28602);
    _28602 = NOVALUE;
L7: 
L3: 

    /** parser.e:1222		tok_match(LEFT_ROUND)*/
    _43tok_match(-26LL, 0LL);

    /** parser.e:1223		scope = SymTab[tok[T_SYM]][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_tok_56763);
    _28603 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28603)){
        _28604 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28603)->dbl));
    }
    else{
        _28604 = (object)*(((s1_ptr)_2)->base + _28603);
    }
    _2 = (object)SEQ_PTR(_28604);
    _scope_56765 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_scope_56765)){
        _scope_56765 = (object)DBL_PTR(_scope_56765)->dbl;
    }
    _28604 = NOVALUE;

    /** parser.e:1224		opcode = SymTab[tok[T_SYM]][S_OPCODE]*/
    _2 = (object)SEQ_PTR(_tok_56763);
    _28606 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28606)){
        _28607 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28606)->dbl));
    }
    else{
        _28607 = (object)*(((s1_ptr)_2)->base + _28606);
    }
    _2 = (object)SEQ_PTR(_28607);
    _opcode_56766 = (object)*(((s1_ptr)_2)->base + 21LL);
    if (!IS_ATOM_INT(_opcode_56766)){
        _opcode_56766 = (object)DBL_PTR(_opcode_56766)->dbl;
    }
    _28607 = NOVALUE;

    /** parser.e:1225		if equal(SymTab[tok[T_SYM]][S_NAME],"object") and scope = SC_PREDEF then*/
    _2 = (object)SEQ_PTR(_tok_56763);
    _28609 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28609)){
        _28610 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28609)->dbl));
    }
    else{
        _28610 = (object)*(((s1_ptr)_2)->base + _28609);
    }
    _2 = (object)SEQ_PTR(_28610);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _28611 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _28611 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _28610 = NOVALUE;
    if (_28611 == _23004)
    _28612 = 1;
    else if (IS_ATOM_INT(_28611) && IS_ATOM_INT(_23004))
    _28612 = 0;
    else
    _28612 = (compare(_28611, _23004) == 0);
    _28611 = NOVALUE;
    if (_28612 == 0) {
        goto L8; // [305] 327
    }
    _28614 = (_scope_56765 == 7LL);
    if (_28614 == 0)
    {
        DeRef(_28614);
        _28614 = NOVALUE;
        goto L8; // [316] 327
    }
    else{
        DeRef(_28614);
        _28614 = NOVALUE;
    }

    /** parser.e:1227			Object_call( tok )*/
    Ref(_tok_56763);
    _43Object_call(_tok_56763);
    goto L9; // [324] 339
L8: 

    /** parser.e:1230			ParseArgs(tok[T_SYM])*/
    _2 = (object)SEQ_PTR(_tok_56763);
    _28615 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_28615);
    _43ParseArgs(_28615);
    _28615 = NOVALUE;
L9: 

    /** parser.e:1233		if scope = SC_PREDEF then*/
    if (_scope_56765 != 7LL)
    goto LA; // [343] 355

    /** parser.e:1234			emit_op(opcode)*/
    _45emit_op(_opcode_56766);
    goto LB; // [352] 393
LA: 

    /** parser.e:1236			op_info1 = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_56763);
    _45op_info1_51020 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_45op_info1_51020)){
        _45op_info1_51020 = (object)DBL_PTR(_45op_info1_51020)->dbl;
    }

    /** parser.e:1238			emit_or_inline()*/
    _66emit_or_inline();

    /** parser.e:1239			if not TRANSLATE then*/
    if (_12TRANSLATE_19834 != 0)
    goto LC; // [373] 392

    /** parser.e:1240				if OpTrace then*/
    if (_12OpTrace_20296 == 0)
    {
        goto LD; // [380] 391
    }
    else{
    }

    /** parser.e:1241					emit_op(UPDATE_GLOBALS)*/
    _45emit_op(89LL);
LD: 
LC: 
LB: 

    /** parser.e:1245	end procedure*/
    DeRef(_tok_56763);
    DeRef(_28575);
    _28575 = NOVALUE;
    _28599 = NOVALUE;
    _28609 = NOVALUE;
    _28603 = NOVALUE;
    DeRef(_28592);
    _28592 = NOVALUE;
    DeRef(_28582);
    _28582 = NOVALUE;
    _28579 = NOVALUE;
    _28606 = NOVALUE;
    return;
    ;
}


void _43Factor()
{
    object _tok_56872 = NOVALUE;
    object _id_56873 = NOVALUE;
    object _n_56874 = NOVALUE;
    object _save_factors_56875 = NOVALUE;
    object _save_lhs_subs_level_56876 = NOVALUE;
    object _sym_56878 = NOVALUE;
    object _forward_56909 = NOVALUE;
    object _28675 = NOVALUE;
    object _28674 = NOVALUE;
    object _28673 = NOVALUE;
    object _28671 = NOVALUE;
    object _28670 = NOVALUE;
    object _28669 = NOVALUE;
    object _28668 = NOVALUE;
    object _28667 = NOVALUE;
    object _28665 = NOVALUE;
    object _28661 = NOVALUE;
    object _28658 = NOVALUE;
    object _28654 = NOVALUE;
    object _28648 = NOVALUE;
    object _28643 = NOVALUE;
    object _28642 = NOVALUE;
    object _28641 = NOVALUE;
    object _28639 = NOVALUE;
    object _28638 = NOVALUE;
    object _28636 = NOVALUE;
    object _28634 = NOVALUE;
    object _28633 = NOVALUE;
    object _28632 = NOVALUE;
    object _28630 = NOVALUE;
    object _28623 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:1250		integer id, n*/

    /** parser.e:1251		integer save_factors, save_lhs_subs_level*/

    /** parser.e:1254		factors += 1*/
    _43factors_55053 = _43factors_55053 + 1;

    /** parser.e:1255		tok = next_token()*/
    _0 = _tok_56872;
    _tok_56872 = _43next_token();
    DeRef(_0);

    /** parser.e:1256		id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_56872);
    _id_56873 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_56873)){
        _id_56873 = (object)DBL_PTR(_id_56873)->dbl;
    }

    /** parser.e:1257		if id = RECORDED then*/
    if (_id_56873 != 508LL)
    goto L1; // [32] 59

    /** parser.e:1258			tok = read_recorded_token(tok[T_SYM])*/
    _2 = (object)SEQ_PTR(_tok_56872);
    _28623 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_28623);
    _0 = _tok_56872;
    _tok_56872 = _43read_recorded_token(_28623);
    DeRef(_0);
    _28623 = NOVALUE;

    /** parser.e:1259			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_56872);
    _id_56873 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_56873)){
        _id_56873 = (object)DBL_PTR(_id_56873)->dbl;
    }
L1: 

    /** parser.e:1261		switch id label "factor" do*/
    _0 = _id_56873;
    switch ( _0 ){ 

        /** parser.e:1262			case VARIABLE, QUALIFIED_VARIABLE then*/
        case -100:
        case 512:

        /** parser.e:1263				sym = tok[T_SYM]*/
        _2 = (object)SEQ_PTR(_tok_56872);
        _sym_56878 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_sym_56878)){
            _sym_56878 = (object)DBL_PTR(_sym_56878)->dbl;
        }

        /** parser.e:1264				if sym < 0 or SymTab[sym][S_SCOPE] = SC_UNDEFINED then*/
        _28630 = (_sym_56878 < 0LL);
        if (_28630 != 0) {
            goto L2; // [88] 115
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28632 = (object)*(((s1_ptr)_2)->base + _sym_56878);
        _2 = (object)SEQ_PTR(_28632);
        _28633 = (object)*(((s1_ptr)_2)->base + 4LL);
        _28632 = NOVALUE;
        if (IS_ATOM_INT(_28633)) {
            _28634 = (_28633 == 9LL);
        }
        else {
            _28634 = binary_op(EQUALS, _28633, 9LL);
        }
        _28633 = NOVALUE;
        if (_28634 == 0) {
            DeRef(_28634);
            _28634 = NOVALUE;
            goto L3; // [111] 177
        }
        else {
            if (!IS_ATOM_INT(_28634) && DBL_PTR(_28634)->dbl == 0.0){
                DeRef(_28634);
                _28634 = NOVALUE;
                goto L3; // [111] 177
            }
            DeRef(_28634);
            _28634 = NOVALUE;
        }
        DeRef(_28634);
        _28634 = NOVALUE;
L2: 

        /** parser.e:1265					token forward = next_token()*/
        _0 = _forward_56909;
        _forward_56909 = _43next_token();
        DeRef(_0);

        /** parser.e:1266					if forward[T_ID] = LEFT_ROUND then*/
        _2 = (object)SEQ_PTR(_forward_56909);
        _28636 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _28636, -26LL)){
            _28636 = NOVALUE;
            goto L4; // [130] 151
        }
        _28636 = NOVALUE;

        /** parser.e:1267						Forward_call( tok, FUNC_FORWARD )*/
        Ref(_tok_56872);
        _43Forward_call(_tok_56872, 196LL);

        /** parser.e:1268						break "factor"*/
        DeRef(_forward_56909);
        _forward_56909 = NOVALUE;
        goto L5; // [146] 694
        goto L6; // [148] 172
L4: 

        /** parser.e:1270						putback( forward )*/
        Ref(_forward_56909);
        _43putback(_forward_56909);

        /** parser.e:1271						Forward_var( tok, TRUE )*/
        _2 = (object)SEQ_PTR(_tok_56872);
        _28638 = (object)*(((s1_ptr)_2)->base + 1LL);
        Ref(_tok_56872);
        Ref(_28638);
        _43Forward_var(_tok_56872, _9TRUE_446, _28638);
        _28638 = NOVALUE;
L6: 
        DeRef(_forward_56909);
        _forward_56909 = NOVALUE;
        goto L7; // [174] 229
L3: 

        /** parser.e:1275					UndefinedVar(sym)*/
        _43UndefinedVar(_sym_56878);

        /** parser.e:1276					SymTab[sym][S_USAGE] = or_bits(SymTab[sym][S_USAGE], U_READ)*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_sym_56878 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28641 = (object)*(((s1_ptr)_2)->base + _sym_56878);
        _2 = (object)SEQ_PTR(_28641);
        _28642 = (object)*(((s1_ptr)_2)->base + 5LL);
        _28641 = NOVALUE;
        if (IS_ATOM_INT(_28642)) {
            {uintptr_t tu;
                 tu = (uintptr_t)_28642 | (uintptr_t)1LL;
                 _28643 = MAKE_UINT(tu);
            }
        }
        else {
            _28643 = binary_op(OR_BITS, _28642, 1LL);
        }
        _28642 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _28643;
        if( _1 != _28643 ){
            DeRef(_1);
        }
        _28643 = NOVALUE;
        _28639 = NOVALUE;

        /** parser.e:1277					InitCheck(sym, TRUE)*/
        _43InitCheck(_sym_56878, _9TRUE_446);

        /** parser.e:1278					emit_opnd(sym)*/
        _45emit_opnd(_sym_56878);
L7: 

        /** parser.e:1281				if sym = left_sym then*/
        if (_sym_56878 != _43left_sym_55056)
        goto L8; // [233] 243

        /** parser.e:1282					lhs_subs_level = 0 -- start counting subscripts*/
        _43lhs_subs_level_55054 = 0LL;
L8: 

        /** parser.e:1285				short_circuit -= 1*/
        _43short_circuit_55015 = _43short_circuit_55015 - 1LL;

        /** parser.e:1286				tok = next_token()*/
        _0 = _tok_56872;
        _tok_56872 = _43next_token();
        DeRef(_0);

        /** parser.e:1287				current_sequence = append(current_sequence, sym)*/
        Append(&_45current_sequence_51028, _45current_sequence_51028, _sym_56878);

        /** parser.e:1288				while tok[T_ID] = LEFT_SQUARE do*/
L9: 
        _2 = (object)SEQ_PTR(_tok_56872);
        _28648 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _28648, -28LL)){
            _28648 = NOVALUE;
            goto LA; // [279] 447
        }
        _28648 = NOVALUE;

        /** parser.e:1289					subs_depth += 1*/
        _43subs_depth_55057 = _43subs_depth_55057 + 1;

        /** parser.e:1290					if lhs_subs_level >= 0 then*/
        if (_43lhs_subs_level_55054 < 0LL)
        goto LB; // [295] 308

        /** parser.e:1291						lhs_subs_level += 1*/
        _43lhs_subs_level_55054 = _43lhs_subs_level_55054 + 1;
LB: 

        /** parser.e:1293					save_factors = factors*/
        _save_factors_56875 = _43factors_55053;

        /** parser.e:1294					save_lhs_subs_level = lhs_subs_level*/
        _save_lhs_subs_level_56876 = _43lhs_subs_level_55054;

        /** parser.e:1295					call_proc(forward_expr, {})*/
        _0 = (object)_00[_43forward_expr_56052].addr;
        (*(intptr_t (*)())_0)(
                             );

        /** parser.e:1296					tok = next_token()*/
        _0 = _tok_56872;
        _tok_56872 = _43next_token();
        DeRef(_0);

        /** parser.e:1297					if tok[T_ID] = SLICE then*/
        _2 = (object)SEQ_PTR(_tok_56872);
        _28654 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _28654, 513LL)){
            _28654 = NOVALUE;
            goto LC; // [344] 382
        }
        _28654 = NOVALUE;

        /** parser.e:1298						call_proc(forward_expr, {})*/
        _0 = (object)_00[_43forward_expr_56052].addr;
        (*(intptr_t (*)())_0)(
                             );

        /** parser.e:1299						emit_op(RHS_SLICE)*/
        _45emit_op(46LL);

        /** parser.e:1300						tok_match(RIGHT_SQUARE)*/
        _43tok_match(-29LL, 0LL);

        /** parser.e:1301						tok = next_token()*/
        _0 = _tok_56872;
        _tok_56872 = _43next_token();
        DeRef(_0);

        /** parser.e:1302						exit*/
        goto LA; // [377] 447
        goto LD; // [379] 427
LC: 

        /** parser.e:1304						putback(tok)*/
        Ref(_tok_56872);
        _43putback(_tok_56872);

        /** parser.e:1305						tok_match(RIGHT_SQUARE)*/
        _43tok_match(-29LL, 0LL);

        /** parser.e:1306						subs_depth -= 1*/
        _43subs_depth_55057 = _43subs_depth_55057 - 1LL;

        /** parser.e:1307						current_sequence = remove( current_sequence, length( current_sequence ) )*/
        if (IS_SEQUENCE(_45current_sequence_51028)){
                _28658 = SEQ_PTR(_45current_sequence_51028)->length;
        }
        else {
            _28658 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_45current_sequence_51028);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_28658)) ? _28658 : (object)(DBL_PTR(_28658)->dbl);
            int stop = (IS_ATOM_INT(_28658)) ? _28658 : (object)(DBL_PTR(_28658)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_45current_sequence_51028), start, &_45current_sequence_51028 );
                }
                else Tail(SEQ_PTR(_45current_sequence_51028), stop+1, &_45current_sequence_51028);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_45current_sequence_51028), start, &_45current_sequence_51028);
            }
            else {
                assign_slice_seq = &assign_space;
                _45current_sequence_51028 = Remove_elements(start, stop, (SEQ_PTR(_45current_sequence_51028)->ref == 1));
            }
        }
        _28658 = NOVALUE;
        _28658 = NOVALUE;

        /** parser.e:1308						emit_op(RHS_SUBS) -- current_sequence will be updated*/
        _45emit_op(25LL);
LD: 

        /** parser.e:1310					factors = save_factors*/
        _43factors_55053 = _save_factors_56875;

        /** parser.e:1311					lhs_subs_level = save_lhs_subs_level*/
        _43lhs_subs_level_55054 = _save_lhs_subs_level_56876;

        /** parser.e:1312					tok = next_token()*/
        _0 = _tok_56872;
        _tok_56872 = _43next_token();
        DeRef(_0);

        /** parser.e:1313				end while*/
        goto L9; // [444] 271
LA: 

        /** parser.e:1314				current_sequence = remove( current_sequence, length( current_sequence ) )*/
        if (IS_SEQUENCE(_45current_sequence_51028)){
                _28661 = SEQ_PTR(_45current_sequence_51028)->length;
        }
        else {
            _28661 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_45current_sequence_51028);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_28661)) ? _28661 : (object)(DBL_PTR(_28661)->dbl);
            int stop = (IS_ATOM_INT(_28661)) ? _28661 : (object)(DBL_PTR(_28661)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_45current_sequence_51028), start, &_45current_sequence_51028 );
                }
                else Tail(SEQ_PTR(_45current_sequence_51028), stop+1, &_45current_sequence_51028);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_45current_sequence_51028), start, &_45current_sequence_51028);
            }
            else {
                assign_slice_seq = &assign_space;
                _45current_sequence_51028 = Remove_elements(start, stop, (SEQ_PTR(_45current_sequence_51028)->ref == 1));
            }
        }
        _28661 = NOVALUE;
        _28661 = NOVALUE;

        /** parser.e:1315				putback(tok)*/
        Ref(_tok_56872);
        _43putback(_tok_56872);

        /** parser.e:1316				short_circuit += 1*/
        _43short_circuit_55015 = _43short_circuit_55015 + 1;
        goto L5; // [476] 694

        /** parser.e:1318			case DOLLAR then*/
        case -22:

        /** parser.e:1319				tok = next_token()*/
        _0 = _tok_56872;
        _tok_56872 = _43next_token();
        DeRef(_0);

        /** parser.e:1320				putback(tok)*/
        Ref(_tok_56872);
        _43putback(_tok_56872);

        /** parser.e:1321				if tok[T_ID] = RIGHT_BRACE then*/
        _2 = (object)SEQ_PTR(_tok_56872);
        _28665 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _28665, -25LL)){
            _28665 = NOVALUE;
            goto LE; // [502] 520
        }
        _28665 = NOVALUE;

        /** parser.e:1322					gListItem[$] = 0*/
        if (IS_SEQUENCE(_43gListItem_55051)){
                _28667 = SEQ_PTR(_43gListItem_55051)->length;
        }
        else {
            _28667 = 1;
        }
        _2 = (object)SEQ_PTR(_43gListItem_55051);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _43gListItem_55051 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _28667);
        *(intptr_t *)_2 = 0LL;
        goto L5; // [517] 694
LE: 

        /** parser.e:1324					if subs_depth > 0 and length(current_sequence) then*/
        _28668 = (_43subs_depth_55057 > 0LL);
        if (_28668 == 0) {
            goto LF; // [528] 551
        }
        if (IS_SEQUENCE(_45current_sequence_51028)){
                _28670 = SEQ_PTR(_45current_sequence_51028)->length;
        }
        else {
            _28670 = 1;
        }
        if (_28670 == 0)
        {
            _28670 = NOVALUE;
            goto LF; // [538] 551
        }
        else{
            _28670 = NOVALUE;
        }

        /** parser.e:1325						emit_op(DOLLAR)*/
        _45emit_op(-22LL);
        goto L5; // [548] 694
LF: 

        /** parser.e:1327						CompileErr(MSG__MUST_ONLY_APPEAR_BETWEEN__AND__OR_AS_THE_LAST_ITEM_IN_A_SEQUENCE_LITERAL)*/
        RefDS(_22024);
        _49CompileErr(21LL, _22024, 0LL);
        goto L5; // [562] 694

        /** parser.e:1331			case ATOM then*/
        case 502:

        /** parser.e:1332				emit_opnd(tok[T_SYM])*/
        _2 = (object)SEQ_PTR(_tok_56872);
        _28671 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_28671);
        _45emit_opnd(_28671);
        _28671 = NOVALUE;
        goto L5; // [579] 694

        /** parser.e:1334			case LEFT_BRACE then*/
        case -24:

        /** parser.e:1335				n = Expr_list()*/
        _n_56874 = _43Expr_list();
        if (!IS_ATOM_INT(_n_56874)) {
            _1 = (object)(DBL_PTR(_n_56874)->dbl);
            DeRefDS(_n_56874);
            _n_56874 = _1;
        }

        /** parser.e:1336				tok_match(RIGHT_BRACE)*/
        _43tok_match(-25LL, 0LL);

        /** parser.e:1337				op_info1 = n*/
        _45op_info1_51020 = _n_56874;

        /** parser.e:1338				emit_op(RIGHT_BRACE_N)*/
        _45emit_op(31LL);
        goto L5; // [614] 694

        /** parser.e:1340			case STRING then*/
        case 503:

        /** parser.e:1341				emit_opnd(tok[T_SYM])*/
        _2 = (object)SEQ_PTR(_tok_56872);
        _28673 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_28673);
        _45emit_opnd(_28673);
        _28673 = NOVALUE;
        goto L5; // [631] 694

        /** parser.e:1343			case LEFT_ROUND then*/
        case -26:

        /** parser.e:1344				call_proc(forward_expr, {})*/
        _0 = (object)_00[_43forward_expr_56052].addr;
        (*(intptr_t (*)())_0)(
                             );

        /** parser.e:1345				tok_match(RIGHT_ROUND)*/
        _43tok_match(-27LL, 0LL);
        goto L5; // [652] 694

        /** parser.e:1347			case FUNC, TYPE, QUALIFIED_FUNC, QUALIFIED_TYPE then*/
        case 501:
        case 504:
        case 520:
        case 522:

        /** parser.e:1348				Function_call( tok )*/
        Ref(_tok_56872);
        _43Function_call(_tok_56872);
        goto L5; // [669] 694

        /** parser.e:1350			case else*/
        default:

        /** parser.e:1351				CompileErr(SYNTAX_ERROR__EXPECTED_TO_SEE_AN_EXPRESSION_NOT_1, {LexName(id)})*/
        RefDS(_26412);
        _28674 = _45LexName(_id_56873, _26412);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _28674;
        _28675 = MAKE_SEQ(_1);
        _28674 = NOVALUE;
        _49CompileErr(135LL, _28675, 0LL);
        _28675 = NOVALUE;
    ;}L5: 

    /** parser.e:1353	end procedure*/
    DeRef(_tok_56872);
    DeRef(_28668);
    _28668 = NOVALUE;
    DeRef(_28630);
    _28630 = NOVALUE;
    return;
    ;
}


void _43UFactor()
{
    object _tok_57031 = NOVALUE;
    object _28681 = NOVALUE;
    object _28679 = NOVALUE;
    object _28677 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1359		tok = next_token()*/
    _0 = _tok_57031;
    _tok_57031 = _43next_token();
    DeRef(_0);

    /** parser.e:1361		if tok[T_ID] = MINUS then*/
    _2 = (object)SEQ_PTR(_tok_57031);
    _28677 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28677, 10LL)){
        _28677 = NOVALUE;
        goto L1; // [16] 34
    }
    _28677 = NOVALUE;

    /** parser.e:1362			Factor()*/
    _43Factor();

    /** parser.e:1363			emit_op(UMINUS)*/
    _45emit_op(12LL);
    goto L2; // [31] 93
L1: 

    /** parser.e:1365		elsif tok[T_ID] = NOT then*/
    _2 = (object)SEQ_PTR(_tok_57031);
    _28679 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28679, 7LL)){
        _28679 = NOVALUE;
        goto L3; // [44] 62
    }
    _28679 = NOVALUE;

    /** parser.e:1366			Factor()*/
    _43Factor();

    /** parser.e:1367			emit_op(NOT)*/
    _45emit_op(7LL);
    goto L2; // [59] 93
L3: 

    /** parser.e:1369		elsif tok[T_ID] = PLUS then*/
    _2 = (object)SEQ_PTR(_tok_57031);
    _28681 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28681, 11LL)){
        _28681 = NOVALUE;
        goto L4; // [72] 83
    }
    _28681 = NOVALUE;

    /** parser.e:1370			Factor()*/
    _43Factor();
    goto L2; // [80] 93
L4: 

    /** parser.e:1373			putback(tok)*/
    Ref(_tok_57031);
    _43putback(_tok_57031);

    /** parser.e:1374			Factor()*/
    _43Factor();
L2: 

    /** parser.e:1377	end procedure*/
    DeRef(_tok_57031);
    return;
    ;
}


object _43Term()
{
    object _tok_57056 = NOVALUE;
    object _28689 = NOVALUE;
    object _28688 = NOVALUE;
    object _28687 = NOVALUE;
    object _28685 = NOVALUE;
    object _28684 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1383		UFactor()*/
    _43UFactor();

    /** parser.e:1384		tok = next_token()*/
    _0 = _tok_57056;
    _tok_57056 = _43next_token();
    DeRef(_0);

    /** parser.e:1385		while tok[T_ID] = reserved:MULTIPLY or tok[T_ID] = reserved:DIVIDE do*/
L1: 
    _2 = (object)SEQ_PTR(_tok_57056);
    _28684 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28684)) {
        _28685 = (_28684 == 13LL);
    }
    else {
        _28685 = binary_op(EQUALS, _28684, 13LL);
    }
    _28684 = NOVALUE;
    if (IS_ATOM_INT(_28685)) {
        if (_28685 != 0) {
            goto L2; // [25] 44
        }
    }
    else {
        if (DBL_PTR(_28685)->dbl != 0.0) {
            goto L2; // [25] 44
        }
    }
    _2 = (object)SEQ_PTR(_tok_57056);
    _28687 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28687)) {
        _28688 = (_28687 == 14LL);
    }
    else {
        _28688 = binary_op(EQUALS, _28687, 14LL);
    }
    _28687 = NOVALUE;
    if (_28688 <= 0) {
        if (_28688 == 0) {
            DeRef(_28688);
            _28688 = NOVALUE;
            goto L3; // [40] 69
        }
        else {
            if (!IS_ATOM_INT(_28688) && DBL_PTR(_28688)->dbl == 0.0){
                DeRef(_28688);
                _28688 = NOVALUE;
                goto L3; // [40] 69
            }
            DeRef(_28688);
            _28688 = NOVALUE;
        }
    }
    DeRef(_28688);
    _28688 = NOVALUE;
L2: 

    /** parser.e:1386			UFactor()*/
    _43UFactor();

    /** parser.e:1387			emit_op(tok[T_ID])*/
    _2 = (object)SEQ_PTR(_tok_57056);
    _28689 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_28689);
    _45emit_op(_28689);
    _28689 = NOVALUE;

    /** parser.e:1388			tok = next_token()*/
    _0 = _tok_57056;
    _tok_57056 = _43next_token();
    DeRef(_0);

    /** parser.e:1389		end while*/
    goto L1; // [66] 15
L3: 

    /** parser.e:1390		return tok*/
    DeRef(_28685);
    _28685 = NOVALUE;
    return _tok_57056;
    ;
}


object _43aexpr()
{
    object _tok_57073 = NOVALUE;
    object _id_57074 = NOVALUE;
    object _28696 = NOVALUE;
    object _28695 = NOVALUE;
    object _28693 = NOVALUE;
    object _28692 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1396		integer id*/

    /** parser.e:1398		tok = Term()*/
    _0 = _tok_57073;
    _tok_57073 = _43Term();
    DeRef(_0);

    /** parser.e:1399		while tok[T_ID] = PLUS or tok[T_ID] = MINUS do*/
L1: 
    _2 = (object)SEQ_PTR(_tok_57073);
    _28692 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28692)) {
        _28693 = (_28692 == 11LL);
    }
    else {
        _28693 = binary_op(EQUALS, _28692, 11LL);
    }
    _28692 = NOVALUE;
    if (IS_ATOM_INT(_28693)) {
        if (_28693 != 0) {
            goto L2; // [25] 46
        }
    }
    else {
        if (DBL_PTR(_28693)->dbl != 0.0) {
            goto L2; // [25] 46
        }
    }
    _2 = (object)SEQ_PTR(_tok_57073);
    _28695 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28695)) {
        _28696 = (_28695 == 10LL);
    }
    else {
        _28696 = binary_op(EQUALS, _28695, 10LL);
    }
    _28695 = NOVALUE;
    if (_28696 <= 0) {
        if (_28696 == 0) {
            DeRef(_28696);
            _28696 = NOVALUE;
            goto L3; // [42] 71
        }
        else {
            if (!IS_ATOM_INT(_28696) && DBL_PTR(_28696)->dbl == 0.0){
                DeRef(_28696);
                _28696 = NOVALUE;
                goto L3; // [42] 71
            }
            DeRef(_28696);
            _28696 = NOVALUE;
        }
    }
    DeRef(_28696);
    _28696 = NOVALUE;
L2: 

    /** parser.e:1400			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57073);
    _id_57074 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_57074)){
        _id_57074 = (object)DBL_PTR(_id_57074)->dbl;
    }

    /** parser.e:1401			tok = Term()*/
    _0 = _tok_57073;
    _tok_57073 = _43Term();
    DeRef(_0);

    /** parser.e:1402			emit_op(id)*/
    _45emit_op(_id_57074);

    /** parser.e:1403		end while*/
    goto L1; // [68] 13
L3: 

    /** parser.e:1404		return tok*/
    DeRef(_28693);
    _28693 = NOVALUE;
    return _tok_57073;
    ;
}


object _43cexpr()
{
    object _tok_57093 = NOVALUE;
    object _concat_count_57094 = NOVALUE;
    object _28700 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1410		integer concat_count*/

    /** parser.e:1412		tok = aexpr()*/
    _0 = _tok_57093;
    _tok_57093 = _43aexpr();
    DeRef(_0);

    /** parser.e:1413		concat_count = 0*/
    _concat_count_57094 = 0LL;

    /** parser.e:1414		while tok[T_ID] = reserved:CONCAT do*/
L1: 
    _2 = (object)SEQ_PTR(_tok_57093);
    _28700 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28700, 15LL)){
        _28700 = NOVALUE;
        goto L2; // [24] 44
    }
    _28700 = NOVALUE;

    /** parser.e:1415			tok = aexpr()*/
    _0 = _tok_57093;
    _tok_57093 = _43aexpr();
    DeRef(_0);

    /** parser.e:1416			concat_count += 1*/
    _concat_count_57094 = _concat_count_57094 + 1;

    /** parser.e:1417		end while*/
    goto L1; // [41] 18
L2: 

    /** parser.e:1419		if concat_count = 1 then*/
    if (_concat_count_57094 != 1LL)
    goto L3; // [46] 58

    /** parser.e:1420			emit_op( reserved:CONCAT )*/
    _45emit_op(15LL);
    goto L4; // [55] 81
L3: 

    /** parser.e:1422		elsif concat_count > 1 then*/
    if (_concat_count_57094 <= 1LL)
    goto L5; // [60] 80

    /** parser.e:1423			op_info1 = concat_count+1*/
    _45op_info1_51020 = _concat_count_57094 + 1;

    /** parser.e:1424			emit_op(CONCAT_N)*/
    _45emit_op(157LL);
L5: 
L4: 

    /** parser.e:1427		return tok*/
    return _tok_57093;
    ;
}


object _43rexpr()
{
    object _tok_57114 = NOVALUE;
    object _id_57115 = NOVALUE;
    object _28712 = NOVALUE;
    object _28711 = NOVALUE;
    object _28710 = NOVALUE;
    object _28709 = NOVALUE;
    object _28708 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1433		integer id*/

    /** parser.e:1435		tok = cexpr()*/
    _0 = _tok_57114;
    _tok_57114 = _43cexpr();
    DeRef(_0);

    /** parser.e:1436		while tok[T_ID] <= GREATER and tok[T_ID] >= LESS do*/
L1: 
    _2 = (object)SEQ_PTR(_tok_57114);
    _28708 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28708)) {
        _28709 = (_28708 <= 6LL);
    }
    else {
        _28709 = binary_op(LESSEQ, _28708, 6LL);
    }
    _28708 = NOVALUE;
    if (IS_ATOM_INT(_28709)) {
        if (_28709 == 0) {
            goto L2; // [25] 70
        }
    }
    else {
        if (DBL_PTR(_28709)->dbl == 0.0) {
            goto L2; // [25] 70
        }
    }
    _2 = (object)SEQ_PTR(_tok_57114);
    _28711 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28711)) {
        _28712 = (_28711 >= 1LL);
    }
    else {
        _28712 = binary_op(GREATEREQ, _28711, 1LL);
    }
    _28711 = NOVALUE;
    if (_28712 <= 0) {
        if (_28712 == 0) {
            DeRef(_28712);
            _28712 = NOVALUE;
            goto L2; // [42] 70
        }
        else {
            if (!IS_ATOM_INT(_28712) && DBL_PTR(_28712)->dbl == 0.0){
                DeRef(_28712);
                _28712 = NOVALUE;
                goto L2; // [42] 70
            }
            DeRef(_28712);
            _28712 = NOVALUE;
        }
    }
    DeRef(_28712);
    _28712 = NOVALUE;

    /** parser.e:1437			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57114);
    _id_57115 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_57115)){
        _id_57115 = (object)DBL_PTR(_id_57115)->dbl;
    }

    /** parser.e:1438			tok = cexpr()*/
    _0 = _tok_57114;
    _tok_57114 = _43cexpr();
    DeRef(_0);

    /** parser.e:1439			emit_op(id)*/
    _45emit_op(_id_57115);

    /** parser.e:1440		end while*/
    goto L1; // [67] 13
L2: 

    /** parser.e:1441		return tok*/
    DeRef(_28709);
    _28709 = NOVALUE;
    return _tok_57114;
    ;
}


void _43Expr()
{
    object _tok_57141 = NOVALUE;
    object _id_57142 = NOVALUE;
    object _patch_57143 = NOVALUE;
    object _28735 = NOVALUE;
    object _28733 = NOVALUE;
    object _28732 = NOVALUE;
    object _28730 = NOVALUE;
    object _28729 = NOVALUE;
    object _28728 = NOVALUE;
    object _28727 = NOVALUE;
    object _28726 = NOVALUE;
    object _28720 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1451		integer id*/

    /** parser.e:1452		integer patch*/

    /** parser.e:1454		ExprLine = ThisLine*/
    Ref(_49ThisLine_49312);
    DeRef(_43ExprLine_57136);
    _43ExprLine_57136 = _49ThisLine_49312;

    /** parser.e:1455		expr_bp = bp*/
    _43expr_bp_57137 = _49bp_49316;

    /** parser.e:1456		id = -1*/
    _id_57142 = -1LL;

    /** parser.e:1457		patch = 0*/
    _patch_57143 = 0LL;

    /** parser.e:1458		while TRUE do*/
L1: 
    if (_9TRUE_446 == 0)
    {
        goto L2; // [40] 300
    }
    else{
    }

    /** parser.e:1459			if id != -1 then*/
    if (_id_57142 == -1LL)
    goto L3; // [45] 116

    /** parser.e:1460				if id != XOR then*/
    if (_id_57142 == 152LL)
    goto L4; // [53] 115

    /** parser.e:1461					if short_circuit > 0 then*/
    if (_43short_circuit_55015 <= 0LL)
    goto L5; // [61] 114

    /** parser.e:1462						if id = OR then*/
    if (_id_57142 != 9LL)
    goto L6; // [69] 83

    /** parser.e:1463							emit_op(SC1_OR)*/
    _45emit_op(143LL);
    goto L7; // [80] 91
L6: 

    /** parser.e:1465							emit_op(SC1_AND)*/
    _45emit_op(141LL);
L7: 

    /** parser.e:1467						patch = length(Code)+1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _28720 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _28720 = 1;
    }
    _patch_57143 = _28720 + 1;
    _28720 = NOVALUE;

    /** parser.e:1468						emit_forward_addr()*/
    _43emit_forward_addr();

    /** parser.e:1469						short_circuit_B = TRUE*/
    _43short_circuit_B_55017 = _9TRUE_446;
L5: 
L4: 
L3: 

    /** parser.e:1474			tok = rexpr()*/
    _0 = _tok_57141;
    _tok_57141 = _43rexpr();
    DeRef(_0);

    /** parser.e:1476			if id != -1 then*/
    if (_id_57142 == -1LL)
    goto L8; // [123] 268

    /** parser.e:1477				if id != XOR then*/
    if (_id_57142 == 152LL)
    goto L9; // [131] 261

    /** parser.e:1478					if short_circuit > 0 then*/
    if (_43short_circuit_55015 <= 0LL)
    goto LA; // [139] 252

    /** parser.e:1479						if tok[T_ID] != THEN and tok[T_ID] != DO then*/
    _2 = (object)SEQ_PTR(_tok_57141);
    _28726 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28726)) {
        _28727 = (_28726 != 410LL);
    }
    else {
        _28727 = binary_op(NOTEQ, _28726, 410LL);
    }
    _28726 = NOVALUE;
    if (IS_ATOM_INT(_28727)) {
        if (_28727 == 0) {
            goto LB; // [157] 206
        }
    }
    else {
        if (DBL_PTR(_28727)->dbl == 0.0) {
            goto LB; // [157] 206
        }
    }
    _2 = (object)SEQ_PTR(_tok_57141);
    _28729 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28729)) {
        _28730 = (_28729 != 411LL);
    }
    else {
        _28730 = binary_op(NOTEQ, _28729, 411LL);
    }
    _28729 = NOVALUE;
    if (_28730 == 0) {
        DeRef(_28730);
        _28730 = NOVALUE;
        goto LB; // [174] 206
    }
    else {
        if (!IS_ATOM_INT(_28730) && DBL_PTR(_28730)->dbl == 0.0){
            DeRef(_28730);
            _28730 = NOVALUE;
            goto LB; // [174] 206
        }
        DeRef(_28730);
        _28730 = NOVALUE;
    }
    DeRef(_28730);
    _28730 = NOVALUE;

    /** parser.e:1480							if id = OR then*/
    if (_id_57142 != 9LL)
    goto LC; // [181] 195

    /** parser.e:1481								emit_op(SC2_OR)*/
    _45emit_op(144LL);
    goto LD; // [192] 219
LC: 

    /** parser.e:1483								emit_op(SC2_AND)*/
    _45emit_op(142LL);
    goto LD; // [203] 219
LB: 

    /** parser.e:1486							SC1_type = id -- if/while/elsif must patch*/
    _43SC1_type_55020 = _id_57142;

    /** parser.e:1487							emit_op(SC2_NULL)*/
    _45emit_op(145LL);
LD: 

    /** parser.e:1489						if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto LE; // [223] 234
    }
    else{
    }

    /** parser.e:1490							emit_op(NOP1)   -- to get label here*/
    _45emit_op(159LL);
LE: 

    /** parser.e:1492						backpatch(patch, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _28732 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _28732 = 1;
    }
    _28733 = _28732 + 1;
    _28732 = NOVALUE;
    _45backpatch(_patch_57143, _28733);
    _28733 = NOVALUE;
    goto LF; // [249] 267
LA: 

    /** parser.e:1494						emit_op(id)*/
    _45emit_op(_id_57142);
    goto LF; // [258] 267
L9: 

    /** parser.e:1497					emit_op(id)*/
    _45emit_op(_id_57142);
LF: 
L8: 

    /** parser.e:1500			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57141);
    _id_57142 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_57142)){
        _id_57142 = (object)DBL_PTR(_id_57142)->dbl;
    }

    /** parser.e:1501			if not find(id, boolOps) then*/
    _28735 = find_from(_id_57142, _43boolOps_57131, 1LL);
    if (_28735 != 0)
    goto L1; // [287] 38
    _28735 = NOVALUE;

    /** parser.e:1502				exit*/
    goto L2; // [292] 300

    /** parser.e:1504		end while*/
    goto L1; // [297] 38
L2: 

    /** parser.e:1505		putback(tok)*/
    Ref(_tok_57141);
    _43putback(_tok_57141);

    /** parser.e:1506		SC1_patch = patch -- extra line*/
    _43SC1_patch_55019 = _patch_57143;

    /** parser.e:1507	end procedure*/
    DeRef(_tok_57141);
    DeRef(_28727);
    _28727 = NOVALUE;
    return;
    ;
}


void _43TypeCheck(object _var_57218)
{
    object _which_type_57219 = NOVALUE;
    object _ref_57229 = NOVALUE;
    object _ref_57262 = NOVALUE;
    object _28791 = NOVALUE;
    object _28790 = NOVALUE;
    object _28789 = NOVALUE;
    object _28788 = NOVALUE;
    object _28787 = NOVALUE;
    object _28785 = NOVALUE;
    object _28784 = NOVALUE;
    object _28783 = NOVALUE;
    object _28782 = NOVALUE;
    object _28781 = NOVALUE;
    object _28780 = NOVALUE;
    object _28778 = NOVALUE;
    object _28777 = NOVALUE;
    object _28774 = NOVALUE;
    object _28773 = NOVALUE;
    object _28772 = NOVALUE;
    object _28771 = NOVALUE;
    object _28766 = NOVALUE;
    object _28765 = NOVALUE;
    object _28761 = NOVALUE;
    object _28759 = NOVALUE;
    object _28758 = NOVALUE;
    object _28757 = NOVALUE;
    object _28755 = NOVALUE;
    object _28754 = NOVALUE;
    object _28753 = NOVALUE;
    object _28752 = NOVALUE;
    object _28751 = NOVALUE;
    object _28750 = NOVALUE;
    object _28747 = NOVALUE;
    object _28745 = NOVALUE;
    object _28743 = NOVALUE;
    object _28742 = NOVALUE;
    object _28741 = NOVALUE;
    object _28739 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_var_57218)) {
        _1 = (object)(DBL_PTR(_var_57218)->dbl);
        DeRefDS(_var_57218);
        _var_57218 = _1;
    }

    /** parser.e:1515		if var < 0 or SymTab[var][S_SCOPE] = SC_UNDEFINED then*/
    _28739 = (_var_57218 < 0LL);
    if (_28739 != 0) {
        goto L1; // [9] 36
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28741 = (object)*(((s1_ptr)_2)->base + _var_57218);
    _2 = (object)SEQ_PTR(_28741);
    _28742 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28741 = NOVALUE;
    if (IS_ATOM_INT(_28742)) {
        _28743 = (_28742 == 9LL);
    }
    else {
        _28743 = binary_op(EQUALS, _28742, 9LL);
    }
    _28742 = NOVALUE;
    if (_28743 == 0) {
        DeRef(_28743);
        _28743 = NOVALUE;
        goto L2; // [32] 76
    }
    else {
        if (!IS_ATOM_INT(_28743) && DBL_PTR(_28743)->dbl == 0.0){
            DeRef(_28743);
            _28743 = NOVALUE;
            goto L2; // [32] 76
        }
        DeRef(_28743);
        _28743 = NOVALUE;
    }
    DeRef(_28743);
    _28743 = NOVALUE;
L1: 

    /** parser.e:1517			integer ref = new_forward_reference( TYPE_CHECK, var, TYPE_CHECK_FORWARD )*/
    _ref_57229 = _42new_forward_reference(65LL, _var_57218, 197LL);
    if (!IS_ATOM_INT(_ref_57229)) {
        _1 = (object)(DBL_PTR(_ref_57229)->dbl);
        DeRefDS(_ref_57229);
        _ref_57229 = _1;
    }

    /** parser.e:1518			Code &= { TYPE_CHECK_FORWARD, var, OpTypeCheck }*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 197LL;
    ((intptr_t*)_2)[2] = _var_57218;
    ((intptr_t*)_2)[3] = _12OpTypeCheck_20297;
    _28745 = MAKE_SEQ(_1);
    Concat((object_ptr)&_12Code_20315, _12Code_20315, _28745);
    DeRefDS(_28745);
    _28745 = NOVALUE;

    /** parser.e:1519			return*/
    DeRef(_28739);
    _28739 = NOVALUE;
    return;
L2: 

    /** parser.e:1522		which_type = SymTab[var][S_VTYPE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28747 = (object)*(((s1_ptr)_2)->base + _var_57218);
    _2 = (object)SEQ_PTR(_28747);
    _which_type_57219 = (object)*(((s1_ptr)_2)->base + 15LL);
    if (!IS_ATOM_INT(_which_type_57219)){
        _which_type_57219 = (object)DBL_PTR(_which_type_57219)->dbl;
    }
    _28747 = NOVALUE;

    /** parser.e:1523		if which_type = 0 then*/
    if (_which_type_57219 != 0LL)
    goto L3; // [96] 106

    /** parser.e:1524			return	-- Not a typed identifier.*/
    DeRef(_28739);
    _28739 = NOVALUE;
    return;
L3: 

    /** parser.e:1526		if which_type > 0 and length(SymTab[which_type]) < S_TOKEN then*/
    _28750 = (_which_type_57219 > 0LL);
    if (_28750 == 0) {
        goto L4; // [112] 141
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28752 = (object)*(((s1_ptr)_2)->base + _which_type_57219);
    if (IS_SEQUENCE(_28752)){
            _28753 = SEQ_PTR(_28752)->length;
    }
    else {
        _28753 = 1;
    }
    _28752 = NOVALUE;
    if (IS_ATOM_INT(_12S_TOKEN_19869)) {
        _28754 = (_28753 < _12S_TOKEN_19869);
    }
    else {
        _28754 = binary_op(LESS, _28753, _12S_TOKEN_19869);
    }
    _28753 = NOVALUE;
    if (_28754 == 0) {
        DeRef(_28754);
        _28754 = NOVALUE;
        goto L4; // [132] 141
    }
    else {
        if (!IS_ATOM_INT(_28754) && DBL_PTR(_28754)->dbl == 0.0){
            DeRef(_28754);
            _28754 = NOVALUE;
            goto L4; // [132] 141
        }
        DeRef(_28754);
        _28754 = NOVALUE;
    }
    DeRef(_28754);
    _28754 = NOVALUE;

    /** parser.e:1527			return	-- Not a typed identifier.*/
    DeRef(_28739);
    _28739 = NOVALUE;
    DeRef(_28750);
    _28750 = NOVALUE;
    _28752 = NOVALUE;
    return;
L4: 

    /** parser.e:1530		if which_type < 0 or SymTab[which_type][S_TOKEN] = VARIABLE  then*/
    _28755 = (_which_type_57219 < 0LL);
    if (_28755 != 0) {
        goto L5; // [147] 174
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28757 = (object)*(((s1_ptr)_2)->base + _which_type_57219);
    _2 = (object)SEQ_PTR(_28757);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _28758 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _28758 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _28757 = NOVALUE;
    if (IS_ATOM_INT(_28758)) {
        _28759 = (_28758 == -100LL);
    }
    else {
        _28759 = binary_op(EQUALS, _28758, -100LL);
    }
    _28758 = NOVALUE;
    if (_28759 == 0) {
        DeRef(_28759);
        _28759 = NOVALUE;
        goto L6; // [170] 214
    }
    else {
        if (!IS_ATOM_INT(_28759) && DBL_PTR(_28759)->dbl == 0.0){
            DeRef(_28759);
            _28759 = NOVALUE;
            goto L6; // [170] 214
        }
        DeRef(_28759);
        _28759 = NOVALUE;
    }
    DeRef(_28759);
    _28759 = NOVALUE;
L5: 

    /** parser.e:1531			integer ref = new_forward_reference( TYPE_CHECK, which_type, TYPE )*/
    _ref_57262 = _42new_forward_reference(65LL, _which_type_57219, 504LL);
    if (!IS_ATOM_INT(_ref_57262)) {
        _1 = (object)(DBL_PTR(_ref_57262)->dbl);
        DeRefDS(_ref_57262);
        _ref_57262 = _1;
    }

    /** parser.e:1532			Code &= { TYPE_CHECK_FORWARD, var, OpTypeCheck }*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 197LL;
    ((intptr_t*)_2)[2] = _var_57218;
    ((intptr_t*)_2)[3] = _12OpTypeCheck_20297;
    _28761 = MAKE_SEQ(_1);
    Concat((object_ptr)&_12Code_20315, _12Code_20315, _28761);
    DeRefDS(_28761);
    _28761 = NOVALUE;

    /** parser.e:1534			return*/
    DeRef(_28739);
    _28739 = NOVALUE;
    DeRef(_28750);
    _28750 = NOVALUE;
    DeRef(_28755);
    _28755 = NOVALUE;
    _28752 = NOVALUE;
    return;
L6: 

    /** parser.e:1537		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L7; // [220] 317
    }
    else{
    }

    /** parser.e:1538			if OpTypeCheck then*/
    if (_12OpTypeCheck_20297 == 0)
    {
        goto L8; // [227] 481
    }
    else{
    }

    /** parser.e:1539				switch which_type do*/
    if( _43_57276_cases == 0 ){
        _43_57276_cases = 1;
        SEQ_PTR( _28763 )->base[1] = _53object_type_46846;
        SEQ_PTR( _28763 )->base[2] = _53sequence_type_46850;
        SEQ_PTR( _28763 )->base[3] = _53atom_type_46848;
        SEQ_PTR( _28763 )->base[4] = _53integer_type_46852;
    }
    _1 = find(_which_type_57219, _28763);
    switch ( _1 ){ 

        /** parser.e:1540					case object_type, sequence_type, atom_type then*/
        case 1:
        case 2:
        case 3:

        /** parser.e:1542					case integer_type then*/
        goto L8; // [247] 481
        case 4:

        /** parser.e:1544						op_info1 = var*/
        _45op_info1_51020 = _var_57218;

        /** parser.e:1545						emit_op(INTEGER_CHECK)*/
        _45emit_op(96LL);
        goto L8; // [265] 481

        /** parser.e:1546					case else*/
        case 0:

        /** parser.e:1547						if SymTab[which_type][S_EFFECT] then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _28765 = (object)*(((s1_ptr)_2)->base + _which_type_57219);
        _2 = (object)SEQ_PTR(_28765);
        _28766 = (object)*(((s1_ptr)_2)->base + 23LL);
        _28765 = NOVALUE;
        if (_28766 == 0) {
            _28766 = NOVALUE;
            goto L9; // [285] 312
        }
        else {
            if (!IS_ATOM_INT(_28766) && DBL_PTR(_28766)->dbl == 0.0){
                _28766 = NOVALUE;
                goto L9; // [285] 312
            }
            _28766 = NOVALUE;
        }
        _28766 = NOVALUE;

        /** parser.e:1549							emit_opnd(var)*/
        _45emit_opnd(_var_57218);

        /** parser.e:1550							op_info1 = which_type*/
        _45op_info1_51020 = _which_type_57219;

        /** parser.e:1552							emit_or_inline()*/
        _66emit_or_inline();

        /** parser.e:1553							emit_op(TYPE_CHECK)*/
        _45emit_op(65LL);
L9: 
    ;}    goto L8; // [314] 481
L7: 

    /** parser.e:1559			if OpTypeCheck then*/
    if (_12OpTypeCheck_20297 == 0)
    {
        goto LA; // [321] 480
    }
    else{
    }

    /** parser.e:1560				if which_type != object_type then*/
    if (_which_type_57219 == _53object_type_46846)
    goto LB; // [328] 479

    /** parser.e:1561					if which_type = integer_type then*/
    if (_which_type_57219 != _53integer_type_46852)
    goto LC; // [336] 357

    /** parser.e:1562							op_info1 = var*/
    _45op_info1_51020 = _var_57218;

    /** parser.e:1563							emit_op(INTEGER_CHECK)*/
    _45emit_op(96LL);
    goto LD; // [354] 478
LC: 

    /** parser.e:1565					elsif which_type = sequence_type then*/
    if (_which_type_57219 != _53sequence_type_46850)
    goto LE; // [361] 382

    /** parser.e:1566							op_info1 = var*/
    _45op_info1_51020 = _var_57218;

    /** parser.e:1567							emit_op(SEQUENCE_CHECK)*/
    _45emit_op(97LL);
    goto LD; // [379] 478
LE: 

    /** parser.e:1569					elsif which_type = atom_type then*/
    if (_which_type_57219 != _53atom_type_46848)
    goto LF; // [386] 407

    /** parser.e:1570							op_info1 = var*/
    _45op_info1_51020 = _var_57218;

    /** parser.e:1571							emit_op(ATOM_CHECK)*/
    _45emit_op(101LL);
    goto LD; // [404] 478
LF: 

    /** parser.e:1575							if SymTab[SymTab[which_type][S_NEXT]][S_VTYPE] =*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28771 = (object)*(((s1_ptr)_2)->base + _which_type_57219);
    _2 = (object)SEQ_PTR(_28771);
    _28772 = (object)*(((s1_ptr)_2)->base + 2LL);
    _28771 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28772)){
        _28773 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28772)->dbl));
    }
    else{
        _28773 = (object)*(((s1_ptr)_2)->base + _28772);
    }
    _2 = (object)SEQ_PTR(_28773);
    _28774 = (object)*(((s1_ptr)_2)->base + 15LL);
    _28773 = NOVALUE;
    if (binary_op_a(NOTEQ, _28774, _53integer_type_46852)){
        _28774 = NOVALUE;
        goto L10; // [435] 454
    }
    _28774 = NOVALUE;

    /** parser.e:1577								op_info1 = var*/
    _45op_info1_51020 = _var_57218;

    /** parser.e:1578								emit_op(INTEGER_CHECK) -- need integer conversion*/
    _45emit_op(96LL);
L10: 

    /** parser.e:1580							emit_opnd(var)*/
    _45emit_opnd(_var_57218);

    /** parser.e:1581							op_info1 = which_type*/
    _45op_info1_51020 = _which_type_57219;

    /** parser.e:1582							emit_or_inline()*/
    _66emit_or_inline();

    /** parser.e:1584							emit_op(TYPE_CHECK)*/
    _45emit_op(65LL);
LD: 
LB: 
LA: 
L8: 

    /** parser.e:1590		if TRANSLATE or not OpTypeCheck then*/
    if (_12TRANSLATE_19834 != 0) {
        goto L11; // [485] 499
    }
    _28777 = (_12OpTypeCheck_20297 == 0);
    if (_28777 == 0)
    {
        DeRef(_28777);
        _28777 = NOVALUE;
        goto L12; // [495] 620
    }
    else{
        DeRef(_28777);
        _28777 = NOVALUE;
    }
L11: 

    /** parser.e:1591			op_info1 = var*/
    _45op_info1_51020 = _var_57218;

    /** parser.e:1592			if which_type = sequence_type or*/
    _28778 = (_which_type_57219 == _53sequence_type_46850);
    if (_28778 != 0) {
        goto L13; // [514] 553
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28780 = (object)*(((s1_ptr)_2)->base + _which_type_57219);
    _2 = (object)SEQ_PTR(_28780);
    _28781 = (object)*(((s1_ptr)_2)->base + 2LL);
    _28780 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28781)){
        _28782 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28781)->dbl));
    }
    else{
        _28782 = (object)*(((s1_ptr)_2)->base + _28781);
    }
    _2 = (object)SEQ_PTR(_28782);
    _28783 = (object)*(((s1_ptr)_2)->base + 15LL);
    _28782 = NOVALUE;
    if (IS_ATOM_INT(_28783)) {
        _28784 = (_28783 == _53sequence_type_46850);
    }
    else {
        _28784 = binary_op(EQUALS, _28783, _53sequence_type_46850);
    }
    _28783 = NOVALUE;
    if (_28784 == 0) {
        DeRef(_28784);
        _28784 = NOVALUE;
        goto L14; // [549] 563
    }
    else {
        if (!IS_ATOM_INT(_28784) && DBL_PTR(_28784)->dbl == 0.0){
            DeRef(_28784);
            _28784 = NOVALUE;
            goto L14; // [549] 563
        }
        DeRef(_28784);
        _28784 = NOVALUE;
    }
    DeRef(_28784);
    _28784 = NOVALUE;
L13: 

    /** parser.e:1595				emit_op(SEQUENCE_CHECK)*/
    _45emit_op(97LL);
    goto L15; // [560] 619
L14: 

    /** parser.e:1597			elsif which_type = integer_type or*/
    _28785 = (_which_type_57219 == _53integer_type_46852);
    if (_28785 != 0) {
        goto L16; // [571] 610
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28787 = (object)*(((s1_ptr)_2)->base + _which_type_57219);
    _2 = (object)SEQ_PTR(_28787);
    _28788 = (object)*(((s1_ptr)_2)->base + 2LL);
    _28787 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28788)){
        _28789 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28788)->dbl));
    }
    else{
        _28789 = (object)*(((s1_ptr)_2)->base + _28788);
    }
    _2 = (object)SEQ_PTR(_28789);
    _28790 = (object)*(((s1_ptr)_2)->base + 15LL);
    _28789 = NOVALUE;
    if (IS_ATOM_INT(_28790)) {
        _28791 = (_28790 == _53integer_type_46852);
    }
    else {
        _28791 = binary_op(EQUALS, _28790, _53integer_type_46852);
    }
    _28790 = NOVALUE;
    if (_28791 == 0) {
        DeRef(_28791);
        _28791 = NOVALUE;
        goto L17; // [606] 618
    }
    else {
        if (!IS_ATOM_INT(_28791) && DBL_PTR(_28791)->dbl == 0.0){
            DeRef(_28791);
            _28791 = NOVALUE;
            goto L17; // [606] 618
        }
        DeRef(_28791);
        _28791 = NOVALUE;
    }
    DeRef(_28791);
    _28791 = NOVALUE;
L16: 

    /** parser.e:1600				emit_op(INTEGER_CHECK)*/
    _45emit_op(96LL);
L17: 
L15: 
L12: 

    /** parser.e:1603	end procedure*/
    DeRef(_28739);
    _28739 = NOVALUE;
    DeRef(_28750);
    _28750 = NOVALUE;
    DeRef(_28755);
    _28755 = NOVALUE;
    _28781 = NOVALUE;
    DeRef(_28785);
    _28785 = NOVALUE;
    _28772 = NOVALUE;
    _28788 = NOVALUE;
    _28752 = NOVALUE;
    DeRef(_28778);
    _28778 = NOVALUE;
    return;
    ;
}


void _43Assignment(object _left_var_57383)
{
    object _tok_57385 = NOVALUE;
    object _subs_57386 = NOVALUE;
    object _slice_57387 = NOVALUE;
    object _assign_op_57388 = NOVALUE;
    object _subs1_patch_57389 = NOVALUE;
    object _dangerous_57391 = NOVALUE;
    object _lname_57516 = NOVALUE;
    object _temp_len_57535 = NOVALUE;
    object _28888 = NOVALUE;
    object _28887 = NOVALUE;
    object _28886 = NOVALUE;
    object _28885 = NOVALUE;
    object _28884 = NOVALUE;
    object _28883 = NOVALUE;
    object _28882 = NOVALUE;
    object _28873 = NOVALUE;
    object _28872 = NOVALUE;
    object _28871 = NOVALUE;
    object _28870 = NOVALUE;
    object _28869 = NOVALUE;
    object _28868 = NOVALUE;
    object _28867 = NOVALUE;
    object _28866 = NOVALUE;
    object _28865 = NOVALUE;
    object _28864 = NOVALUE;
    object _28863 = NOVALUE;
    object _28862 = NOVALUE;
    object _28861 = NOVALUE;
    object _28860 = NOVALUE;
    object _28859 = NOVALUE;
    object _28857 = NOVALUE;
    object _28856 = NOVALUE;
    object _28855 = NOVALUE;
    object _28853 = NOVALUE;
    object _28848 = NOVALUE;
    object _28847 = NOVALUE;
    object _28844 = NOVALUE;
    object _28843 = NOVALUE;
    object _28841 = NOVALUE;
    object _28835 = NOVALUE;
    object _28830 = NOVALUE;
    object _28827 = NOVALUE;
    object _28824 = NOVALUE;
    object _28821 = NOVALUE;
    object _28820 = NOVALUE;
    object _28819 = NOVALUE;
    object _28817 = NOVALUE;
    object _28816 = NOVALUE;
    object _28815 = NOVALUE;
    object _28814 = NOVALUE;
    object _28813 = NOVALUE;
    object _28812 = NOVALUE;
    object _28810 = NOVALUE;
    object _28809 = NOVALUE;
    object _28808 = NOVALUE;
    object _28807 = NOVALUE;
    object _28805 = NOVALUE;
    object _28804 = NOVALUE;
    object _28803 = NOVALUE;
    object _28802 = NOVALUE;
    object _28801 = NOVALUE;
    object _28799 = NOVALUE;
    object _28798 = NOVALUE;
    object _28797 = NOVALUE;
    object _28794 = NOVALUE;
    object _28793 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:1608		integer subs, slice, assign_op, subs1_patch*/

    /** parser.e:1611		left_sym = left_var[T_SYM]*/
    _2 = (object)SEQ_PTR(_left_var_57383);
    _43left_sym_55056 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_43left_sym_55056)){
        _43left_sym_55056 = (object)DBL_PTR(_43left_sym_55056)->dbl;
    }

    /** parser.e:1612		if SymTab[left_sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28793 = (object)*(((s1_ptr)_2)->base + _43left_sym_55056);
    _2 = (object)SEQ_PTR(_28793);
    _28794 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28793 = NOVALUE;
    if (binary_op_a(NOTEQ, _28794, 9LL)){
        _28794 = NOVALUE;
        goto L1; // [31] 54
    }
    _28794 = NOVALUE;

    /** parser.e:1613			Forward_var( left_var, ,ASSIGN )*/
    Ref(_left_var_57383);
    _43Forward_var(_left_var_57383, -1LL, 18LL);

    /** parser.e:1614			left_sym = Pop() -- pops off what forward var emitted, because it gets emitted later*/
    _0 = _45Pop();
    _43left_sym_55056 = _0;
    if (!IS_ATOM_INT(_43left_sym_55056)) {
        _1 = (object)(DBL_PTR(_43left_sym_55056)->dbl);
        DeRefDS(_43left_sym_55056);
        _43left_sym_55056 = _1;
    }
    goto L2; // [51] 271
L1: 

    /** parser.e:1616			UndefinedVar(left_sym)*/
    _43UndefinedVar(_43left_sym_55056);

    /** parser.e:1617			if SymTab[left_sym][S_SCOPE] = SC_LOOP_VAR or*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28797 = (object)*(((s1_ptr)_2)->base + _43left_sym_55056);
    _2 = (object)SEQ_PTR(_28797);
    _28798 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28797 = NOVALUE;
    if (IS_ATOM_INT(_28798)) {
        _28799 = (_28798 == 2LL);
    }
    else {
        _28799 = binary_op(EQUALS, _28798, 2LL);
    }
    _28798 = NOVALUE;
    if (IS_ATOM_INT(_28799)) {
        if (_28799 != 0) {
            goto L3; // [83] 112
        }
    }
    else {
        if (DBL_PTR(_28799)->dbl != 0.0) {
            goto L3; // [83] 112
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28801 = (object)*(((s1_ptr)_2)->base + _43left_sym_55056);
    _2 = (object)SEQ_PTR(_28801);
    _28802 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28801 = NOVALUE;
    if (IS_ATOM_INT(_28802)) {
        _28803 = (_28802 == 4LL);
    }
    else {
        _28803 = binary_op(EQUALS, _28802, 4LL);
    }
    _28802 = NOVALUE;
    if (_28803 == 0) {
        DeRef(_28803);
        _28803 = NOVALUE;
        goto L4; // [108] 124
    }
    else {
        if (!IS_ATOM_INT(_28803) && DBL_PTR(_28803)->dbl == 0.0){
            DeRef(_28803);
            _28803 = NOVALUE;
            goto L4; // [108] 124
        }
        DeRef(_28803);
        _28803 = NOVALUE;
    }
    DeRef(_28803);
    _28803 = NOVALUE;
L3: 

    /** parser.e:1619				CompileErr(MAY_NOT_ASSIGN_TO_A_FORLOOP_VARIABLE)*/
    RefDS(_22024);
    _49CompileErr(109LL, _22024, 0LL);
    goto L5; // [121] 233
L4: 

    /** parser.e:1621			elsif SymTab[left_sym][S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28804 = (object)*(((s1_ptr)_2)->base + _43left_sym_55056);
    _2 = (object)SEQ_PTR(_28804);
    _28805 = (object)*(((s1_ptr)_2)->base + 3LL);
    _28804 = NOVALUE;
    if (binary_op_a(NOTEQ, _28805, 2LL)){
        _28805 = NOVALUE;
        goto L6; // [142] 158
    }
    _28805 = NOVALUE;

    /** parser.e:1622				CompileErr(MAY_NOT_CHANGE_THE_VALUE_OF_A_CONSTANT)*/
    RefDS(_22024);
    _49CompileErr(110LL, _22024, 0LL);
    goto L5; // [155] 233
L6: 

    /** parser.e:1624			elsif find(SymTab[left_sym][S_SCOPE], SCOPE_TYPES) then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28807 = (object)*(((s1_ptr)_2)->base + _43left_sym_55056);
    _2 = (object)SEQ_PTR(_28807);
    _28808 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28807 = NOVALUE;
    _28809 = find_from(_28808, _43SCOPE_TYPES_55006, 1LL);
    _28808 = NOVALUE;
    if (_28809 == 0)
    {
        _28809 = NOVALUE;
        goto L7; // [181] 232
    }
    else{
        _28809 = NOVALUE;
    }

    /** parser.e:1626				SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT],*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12CurrentSub_20234 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28812 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_28812);
    _28813 = (object)*(((s1_ptr)_2)->base + 23LL);
    _28812 = NOVALUE;
    _28814 = (_43left_sym_55056 % 29LL);
    _28815 = power(2LL, _28814);
    _28814 = NOVALUE;
    if (IS_ATOM_INT(_28813) && IS_ATOM_INT(_28815)) {
        {uintptr_t tu;
             tu = (uintptr_t)_28813 | (uintptr_t)_28815;
             _28816 = MAKE_UINT(tu);
        }
    }
    else {
        _28816 = binary_op(OR_BITS, _28813, _28815);
    }
    _28813 = NOVALUE;
    DeRef(_28815);
    _28815 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _28816;
    if( _1 != _28816 ){
        DeRef(_1);
    }
    _28816 = NOVALUE;
    _28810 = NOVALUE;
L7: 
L5: 

    /** parser.e:1630			SymTab[left_sym][S_USAGE] = or_bits(SymTab[left_sym][S_USAGE], U_WRITTEN)*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_43left_sym_55056 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28819 = (object)*(((s1_ptr)_2)->base + _43left_sym_55056);
    _2 = (object)SEQ_PTR(_28819);
    _28820 = (object)*(((s1_ptr)_2)->base + 5LL);
    _28819 = NOVALUE;
    if (IS_ATOM_INT(_28820)) {
        {uintptr_t tu;
             tu = (uintptr_t)_28820 | (uintptr_t)2LL;
             _28821 = MAKE_UINT(tu);
        }
    }
    else {
        _28821 = binary_op(OR_BITS, _28820, 2LL);
    }
    _28820 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _28821;
    if( _1 != _28821 ){
        DeRef(_1);
    }
    _28821 = NOVALUE;
    _28817 = NOVALUE;
L2: 

    /** parser.e:1635		tok = next_token()*/
    _0 = _tok_57385;
    _tok_57385 = _43next_token();
    DeRef(_0);

    /** parser.e:1636		subs = 0*/
    _subs_57386 = 0LL;

    /** parser.e:1637		slice = FALSE*/
    _slice_57387 = _9FALSE_444;

    /** parser.e:1639		dangerous = FALSE*/
    _dangerous_57391 = _9FALSE_444;

    /** parser.e:1640		side_effect_calls = 0*/
    _43side_effect_calls_55052 = 0LL;

    /** parser.e:1643		emit_opnd(left_sym)*/
    _45emit_opnd(_43left_sym_55056);

    /** parser.e:1644		current_sequence = append(current_sequence, left_sym)*/
    Append(&_45current_sequence_51028, _45current_sequence_51028, _43left_sym_55056);

    /** parser.e:1646		while tok[T_ID] = LEFT_SQUARE do*/
L8: 
    _2 = (object)SEQ_PTR(_tok_57385);
    _28824 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28824, -28LL)){
        _28824 = NOVALUE;
        goto L9; // [334] 523
    }
    _28824 = NOVALUE;

    /** parser.e:1647			subs_depth += 1*/
    _43subs_depth_55057 = _43subs_depth_55057 + 1;

    /** parser.e:1648			if lhs_ptr then*/
    if (_45lhs_ptr_51030 == 0)
    {
        goto LA; // [350] 405
    }
    else{
    }

    /** parser.e:1650				current_sequence = remove( current_sequence, length( current_sequence ) )*/
    if (IS_SEQUENCE(_45current_sequence_51028)){
            _28827 = SEQ_PTR(_45current_sequence_51028)->length;
    }
    else {
        _28827 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_45current_sequence_51028);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_28827)) ? _28827 : (object)(DBL_PTR(_28827)->dbl);
        int stop = (IS_ATOM_INT(_28827)) ? _28827 : (object)(DBL_PTR(_28827)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_45current_sequence_51028), start, &_45current_sequence_51028 );
            }
            else Tail(SEQ_PTR(_45current_sequence_51028), stop+1, &_45current_sequence_51028);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_45current_sequence_51028), start, &_45current_sequence_51028);
        }
        else {
            assign_slice_seq = &assign_space;
            _45current_sequence_51028 = Remove_elements(start, stop, (SEQ_PTR(_45current_sequence_51028)->ref == 1));
        }
    }
    _28827 = NOVALUE;
    _28827 = NOVALUE;

    /** parser.e:1651				if subs = 1 then*/
    if (_subs_57386 != 1LL)
    goto LB; // [371] 396

    /** parser.e:1653					subs1_patch = length(Code)+1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _28830 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _28830 = 1;
    }
    _subs1_patch_57389 = _28830 + 1;
    _28830 = NOVALUE;

    /** parser.e:1654					emit_op(LHS_SUBS1) -- creates new current_sequence*/
    _45emit_op(161LL);
    goto LC; // [393] 404
LB: 

    /** parser.e:1657					emit_op(LHS_SUBS) -- adds to current_sequence*/
    _45emit_op(95LL);
LC: 
LA: 

    /** parser.e:1660			subs += 1*/
    _subs_57386 = _subs_57386 + 1;

    /** parser.e:1661			if subs = 1 then*/
    if (_subs_57386 != 1LL)
    goto LD; // [413] 428

    /** parser.e:1662				InitCheck(left_sym, TRUE)*/
    _43InitCheck(_43left_sym_55056, _9TRUE_446);
LD: 

    /** parser.e:1664			Expr()*/
    _43Expr();

    /** parser.e:1665			tok = next_token()*/
    _0 = _tok_57385;
    _tok_57385 = _43next_token();
    DeRef(_0);

    /** parser.e:1666			if tok[T_ID] = SLICE then*/
    _2 = (object)SEQ_PTR(_tok_57385);
    _28835 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28835, 513LL)){
        _28835 = NOVALUE;
        goto LE; // [447] 484
    }
    _28835 = NOVALUE;

    /** parser.e:1667				Expr()*/
    _43Expr();

    /** parser.e:1668				slice = TRUE*/
    _slice_57387 = _9TRUE_446;

    /** parser.e:1669				tok_match(RIGHT_SQUARE)*/
    _43tok_match(-29LL, 0LL);

    /** parser.e:1670				tok = next_token()*/
    _0 = _tok_57385;
    _tok_57385 = _43next_token();
    DeRef(_0);

    /** parser.e:1671				exit  -- no further subs or slices allowed*/
    goto L9; // [479] 523
    goto LF; // [481] 506
LE: 

    /** parser.e:1673				putback(tok)*/
    Ref(_tok_57385);
    _43putback(_tok_57385);

    /** parser.e:1674				tok_match(RIGHT_SQUARE)*/
    _43tok_match(-29LL, 0LL);

    /** parser.e:1675				subs_depth -= 1*/
    _43subs_depth_55057 = _43subs_depth_55057 - 1LL;
LF: 

    /** parser.e:1677			tok = next_token()*/
    _0 = _tok_57385;
    _tok_57385 = _43next_token();
    DeRef(_0);

    /** parser.e:1678			lhs_ptr = TRUE*/
    _45lhs_ptr_51030 = _9TRUE_446;

    /** parser.e:1679		end while*/
    goto L8; // [520] 326
L9: 

    /** parser.e:1681		lhs_ptr = FALSE*/
    _45lhs_ptr_51030 = _9FALSE_444;

    /** parser.e:1683		assign_op = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57385);
    _assign_op_57388 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_assign_op_57388)){
        _assign_op_57388 = (object)DBL_PTR(_assign_op_57388)->dbl;
    }

    /** parser.e:1684		if not find(assign_op, ASSIGN_OPS) then*/
    _28841 = find_from(_assign_op_57388, _43ASSIGN_OPS_54998, 1LL);
    if (_28841 != 0)
    goto L10; // [549] 613
    _28841 = NOVALUE;

    /** parser.e:1685			sequence lname = SymTab[left_var[T_SYM]][S_NAME]*/
    _2 = (object)SEQ_PTR(_left_var_57383);
    _28843 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28843)){
        _28844 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28843)->dbl));
    }
    else{
        _28844 = (object)*(((s1_ptr)_2)->base + _28843);
    }
    DeRef(_lname_57516);
    _2 = (object)SEQ_PTR(_28844);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _lname_57516 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _lname_57516 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    Ref(_lname_57516);
    _28844 = NOVALUE;

    /** parser.e:1686			if assign_op = COLON then*/
    if (_assign_op_57388 != -23LL)
    goto L11; // [578] 598

    /** parser.e:1687				CompileErr(SYNTAX_ERROR__UNKNOWN_NAMESPACE_1_USED, {lname})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_lname_57516);
    ((intptr_t*)_2)[1] = _lname_57516;
    _28847 = MAKE_SEQ(_1);
    _49CompileErr(133LL, _28847, 0LL);
    _28847 = NOVALUE;
    goto L12; // [595] 612
L11: 

    /** parser.e:1689				CompileErr(EXPECTED_TO_SEE_AN_ASSIGNMENT_AFTER_1_SUCH_AS__OR, {lname})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_lname_57516);
    ((intptr_t*)_2)[1] = _lname_57516;
    _28848 = MAKE_SEQ(_1);
    _49CompileErr(76LL, _28848, 0LL);
    _28848 = NOVALUE;
L12: 
L10: 
    DeRef(_lname_57516);
    _lname_57516 = NOVALUE;

    /** parser.e:1693		if subs = 0 then*/
    if (_subs_57386 != 0LL)
    goto L13; // [617] 745

    /** parser.e:1695			integer temp_len = length(Code)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _temp_len_57535 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _temp_len_57535 = 1;
    }

    /** parser.e:1696			if assign_op = EQUALS then*/
    if (_assign_op_57388 != 3LL)
    goto L14; // [632] 653

    /** parser.e:1697				Expr() -- RHS expression*/
    _43Expr();

    /** parser.e:1698				InitCheck(left_sym, FALSE)*/
    _43InitCheck(_43left_sym_55056, _9FALSE_444);
    goto L15; // [650] 726
L14: 

    /** parser.e:1700				InitCheck(left_sym, TRUE)*/
    _43InitCheck(_43left_sym_55056, _9TRUE_446);

    /** parser.e:1701				if left_sym > 0 then*/
    if (_43left_sym_55056 <= 0LL)
    goto L16; // [667] 709

    /** parser.e:1702					SymTab[left_sym][S_USAGE] = or_bits(SymTab[left_sym][S_USAGE], U_READ)*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_43left_sym_55056 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28855 = (object)*(((s1_ptr)_2)->base + _43left_sym_55056);
    _2 = (object)SEQ_PTR(_28855);
    _28856 = (object)*(((s1_ptr)_2)->base + 5LL);
    _28855 = NOVALUE;
    if (IS_ATOM_INT(_28856)) {
        {uintptr_t tu;
             tu = (uintptr_t)_28856 | (uintptr_t)1LL;
             _28857 = MAKE_UINT(tu);
        }
    }
    else {
        _28857 = binary_op(OR_BITS, _28856, 1LL);
    }
    _28856 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _28857;
    if( _1 != _28857 ){
        DeRef(_1);
    }
    _28857 = NOVALUE;
    _28853 = NOVALUE;
L16: 

    /** parser.e:1704				emit_opnd(left_sym)*/
    _45emit_opnd(_43left_sym_55056);

    /** parser.e:1705				Expr() -- RHS expression*/
    _43Expr();

    /** parser.e:1706				emit_assign_op(assign_op)*/
    _45emit_assign_op(_assign_op_57388);
L15: 

    /** parser.e:1708			emit_op(ASSIGN)*/
    _45emit_op(18LL);

    /** parser.e:1709			TypeCheck(left_sym)*/
    _43TypeCheck(_43left_sym_55056);
    goto L17; // [742] 1169
L13: 

    /** parser.e:1712			factors = 0*/
    _43factors_55053 = 0LL;

    /** parser.e:1713			lhs_subs_level = -1*/
    _43lhs_subs_level_55054 = -1LL;

    /** parser.e:1714			Expr() -- RHS expression*/
    _43Expr();

    /** parser.e:1716			if subs > 1 then*/
    if (_subs_57386 <= 1LL)
    goto L18; // [761] 900

    /** parser.e:1717				if left_sym < 0 or SymTab[left_sym][S_SCOPE] != SC_PRIVATE and*/
    _28859 = (_43left_sym_55056 < 0LL);
    if (_28859 != 0) {
        _28860 = 1;
        goto L19; // [773] 801
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28861 = (object)*(((s1_ptr)_2)->base + _43left_sym_55056);
    _2 = (object)SEQ_PTR(_28861);
    _28862 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28861 = NOVALUE;
    if (IS_ATOM_INT(_28862)) {
        _28863 = (_28862 != 3LL);
    }
    else {
        _28863 = binary_op(NOTEQ, _28862, 3LL);
    }
    _28862 = NOVALUE;
    if (IS_ATOM_INT(_28863))
    _28860 = (_28863 != 0);
    else
    _28860 = DBL_PTR(_28863)->dbl != 0.0;
L19: 
    if (_28860 == 0) {
        goto L1A; // [801] 835
    }
    _28865 = (_43left_sym_55056 % 29LL);
    _28866 = power(2LL, _28865);
    _28865 = NOVALUE;
    if (IS_ATOM_INT(_28866)) {
        {uintptr_t tu;
             tu = (uintptr_t)_43side_effect_calls_55052 & (uintptr_t)_28866;
             _28867 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (eudouble)_43side_effect_calls_55052;
        _28867 = Dand_bits(&temp_d, DBL_PTR(_28866));
    }
    DeRef(_28866);
    _28866 = NOVALUE;
    if (_28867 == 0) {
        DeRef(_28867);
        _28867 = NOVALUE;
        goto L1A; // [824] 835
    }
    else {
        if (!IS_ATOM_INT(_28867) && DBL_PTR(_28867)->dbl == 0.0){
            DeRef(_28867);
            _28867 = NOVALUE;
            goto L1A; // [824] 835
        }
        DeRef(_28867);
        _28867 = NOVALUE;
    }
    DeRef(_28867);
    _28867 = NOVALUE;

    /** parser.e:1722					dangerous = TRUE*/
    _dangerous_57391 = _9TRUE_446;
L1A: 

    /** parser.e:1725				if factors = 1 and*/
    _28868 = (_43factors_55053 == 1LL);
    if (_28868 == 0) {
        _28869 = 0;
        goto L1B; // [843] 857
    }
    _28870 = (_43lhs_subs_level_55054 >= 0LL);
    _28869 = (_28870 != 0);
L1B: 
    if (_28869 == 0) {
        goto L1C; // [857] 883
    }
    _28872 = _subs_57386 + _slice_57387;
    if ((object)((uintptr_t)_28872 + (uintptr_t)HIGH_BITS) >= 0){
        _28872 = NewDouble((eudouble)_28872);
    }
    if (IS_ATOM_INT(_28872)) {
        _28873 = (_43lhs_subs_level_55054 < _28872);
    }
    else {
        _28873 = ((eudouble)_43lhs_subs_level_55054 < DBL_PTR(_28872)->dbl);
    }
    DeRef(_28872);
    _28872 = NOVALUE;
    if (_28873 == 0)
    {
        DeRef(_28873);
        _28873 = NOVALUE;
        goto L1C; // [872] 883
    }
    else{
        DeRef(_28873);
        _28873 = NOVALUE;
    }

    /** parser.e:1729					dangerous = TRUE*/
    _dangerous_57391 = _9TRUE_446;
L1C: 

    /** parser.e:1732				if dangerous then*/
    if (_dangerous_57391 == 0)
    {
        goto L1D; // [885] 899
    }
    else{
    }

    /** parser.e:1738					backpatch(subs1_patch, LHS_SUBS1_COPY)*/
    _45backpatch(_subs1_patch_57389, 166LL);
L1D: 
L18: 

    /** parser.e:1742			if slice then*/
    if (_slice_57387 == 0)
    {
        goto L1E; // [902] 970
    }
    else{
    }

    /** parser.e:1743				if assign_op != EQUALS then*/
    if (_assign_op_57388 == 3LL)
    goto L1F; // [909] 943

    /** parser.e:1744					if subs = 1 then*/
    if (_subs_57386 != 1LL)
    goto L20; // [915] 929

    /** parser.e:1745						emit_op(ASSIGN_OP_SLICE)*/
    _45emit_op(150LL);
    goto L21; // [926] 937
L20: 

    /** parser.e:1747						emit_op(PASSIGN_OP_SLICE)*/
    _45emit_op(165LL);
L21: 

    /** parser.e:1749					emit_assign_op(assign_op)*/
    _45emit_assign_op(_assign_op_57388);
L1F: 

    /** parser.e:1751				if subs = 1 then*/
    if (_subs_57386 != 1LL)
    goto L22; // [945] 959

    /** parser.e:1752					emit_op(ASSIGN_SLICE)*/
    _45emit_op(45LL);
    goto L23; // [956] 1060
L22: 

    /** parser.e:1754					emit_op(PASSIGN_SLICE)*/
    _45emit_op(163LL);
    goto L23; // [967] 1060
L1E: 

    /** parser.e:1757				if assign_op = EQUALS then*/
    if (_assign_op_57388 != 3LL)
    goto L24; // [974] 1005

    /** parser.e:1758					if subs = 1 then*/
    if (_subs_57386 != 1LL)
    goto L25; // [980] 994

    /** parser.e:1759						emit_op(ASSIGN_SUBS)*/
    _45emit_op(16LL);
    goto L26; // [991] 1059
L25: 

    /** parser.e:1761						emit_op(PASSIGN_SUBS)*/
    _45emit_op(162LL);
    goto L26; // [1002] 1059
L24: 

    /** parser.e:1764					if subs = 1 then*/
    if (_subs_57386 != 1LL)
    goto L27; // [1007] 1021

    /** parser.e:1765						emit_op(ASSIGN_OP_SUBS)*/
    _45emit_op(149LL);
    goto L28; // [1018] 1029
L27: 

    /** parser.e:1767						emit_op(PASSIGN_OP_SUBS)*/
    _45emit_op(164LL);
L28: 

    /** parser.e:1769					emit_assign_op(assign_op)*/
    _45emit_assign_op(_assign_op_57388);

    /** parser.e:1770					if subs = 1 then*/
    if (_subs_57386 != 1LL)
    goto L29; // [1036] 1050

    /** parser.e:1771						emit_op(ASSIGN_SUBS2)*/
    _45emit_op(148LL);
    goto L2A; // [1047] 1058
L29: 

    /** parser.e:1773						emit_op(PASSIGN_SUBS)*/
    _45emit_op(162LL);
L2A: 
L26: 
L23: 

    /** parser.e:1778			if subs > 1 then*/
    if (_subs_57386 <= 1LL)
    goto L2B; // [1062] 1114

    /** parser.e:1779				if dangerous then*/
    if (_dangerous_57391 == 0)
    {
        goto L2C; // [1068] 1105
    }
    else{
    }

    /** parser.e:1781					emit_opnd(left_sym)*/
    _45emit_opnd(_43left_sym_55056);

    /** parser.e:1782					emit_opnd(lhs_subs1_copy_temp) -- will be freed*/
    _45emit_opnd(_45lhs_subs1_copy_temp_51033);

    /** parser.e:1783					emit_temp( lhs_subs1_copy_temp, NEW_REFERENCE )*/
    _45emit_temp(_45lhs_subs1_copy_temp_51033, 1LL);

    /** parser.e:1784					emit_op(ASSIGN)*/
    _45emit_op(18LL);
    goto L2D; // [1102] 1113
L2C: 

    /** parser.e:1787					TempFree(lhs_subs1_copy_temp)*/
    _45TempFree(_45lhs_subs1_copy_temp_51033);
L2D: 
L2B: 

    /** parser.e:1791			if OpTypeCheck and (left_sym < 0 or SymTab[left_sym][S_VTYPE] != sequence_type) then*/
    if (_12OpTypeCheck_20297 == 0) {
        goto L2E; // [1118] 1168
    }
    _28883 = (_43left_sym_55056 < 0LL);
    if (_28883 != 0) {
        DeRef(_28884);
        _28884 = 1;
        goto L2F; // [1128] 1156
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28885 = (object)*(((s1_ptr)_2)->base + _43left_sym_55056);
    _2 = (object)SEQ_PTR(_28885);
    _28886 = (object)*(((s1_ptr)_2)->base + 15LL);
    _28885 = NOVALUE;
    if (IS_ATOM_INT(_28886)) {
        _28887 = (_28886 != _53sequence_type_46850);
    }
    else {
        _28887 = binary_op(NOTEQ, _28886, _53sequence_type_46850);
    }
    _28886 = NOVALUE;
    if (IS_ATOM_INT(_28887))
    _28884 = (_28887 != 0);
    else
    _28884 = DBL_PTR(_28887)->dbl != 0.0;
L2F: 
    if (_28884 == 0)
    {
        _28884 = NOVALUE;
        goto L2E; // [1157] 1168
    }
    else{
        _28884 = NOVALUE;
    }

    /** parser.e:1792				TypeCheck(left_sym)*/
    _43TypeCheck(_43left_sym_55056);
L2E: 
L17: 

    /** parser.e:1796		current_sequence = remove( current_sequence, length( current_sequence ) )*/
    if (IS_SEQUENCE(_45current_sequence_51028)){
            _28888 = SEQ_PTR(_45current_sequence_51028)->length;
    }
    else {
        _28888 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_45current_sequence_51028);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_28888)) ? _28888 : (object)(DBL_PTR(_28888)->dbl);
        int stop = (IS_ATOM_INT(_28888)) ? _28888 : (object)(DBL_PTR(_28888)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_45current_sequence_51028), start, &_45current_sequence_51028 );
            }
            else Tail(SEQ_PTR(_45current_sequence_51028), stop+1, &_45current_sequence_51028);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_45current_sequence_51028), start, &_45current_sequence_51028);
        }
        else {
            assign_slice_seq = &assign_space;
            _45current_sequence_51028 = Remove_elements(start, stop, (SEQ_PTR(_45current_sequence_51028)->ref == 1));
        }
    }
    _28888 = NOVALUE;
    _28888 = NOVALUE;

    /** parser.e:1798		if not TRANSLATE then*/
    if (_12TRANSLATE_19834 != 0)
    goto L30; // [1189] 1215

    /** parser.e:1799			if OpTrace then*/
    if (_12OpTrace_20296 == 0)
    {
        goto L31; // [1196] 1214
    }
    else{
    }

    /** parser.e:1800				emit_op(DISPLAY_VAR)*/
    _45emit_op(87LL);

    /** parser.e:1801				emit_addr(left_sym)*/
    _45emit_addr(_43left_sym_55056);
L31: 
L30: 

    /** parser.e:1804	end procedure*/
    DeRef(_left_var_57383);
    DeRef(_tok_57385);
    _28843 = NOVALUE;
    DeRef(_28887);
    _28887 = NOVALUE;
    DeRef(_28799);
    _28799 = NOVALUE;
    DeRef(_28863);
    _28863 = NOVALUE;
    DeRef(_28870);
    _28870 = NOVALUE;
    DeRef(_28859);
    _28859 = NOVALUE;
    DeRef(_28868);
    _28868 = NOVALUE;
    DeRef(_28883);
    _28883 = NOVALUE;
    return;
    ;
}


void _43Multi_assign()
{
    object _lhs_syms_57675 = NOVALUE;
    object _lhs_list_57676 = NOVALUE;
    object _tok_57678 = NOVALUE;
    object _need_comma_57679 = NOVALUE;
    object _temp_sym_57741 = NOVALUE;
    object _temps_57744 = NOVALUE;
    object _len_57792 = NOVALUE;
    object _28947 = NOVALUE;
    object _28945 = NOVALUE;
    object _28943 = NOVALUE;
    object _28941 = NOVALUE;
    object _28940 = NOVALUE;
    object _28939 = NOVALUE;
    object _28938 = NOVALUE;
    object _28937 = NOVALUE;
    object _28936 = NOVALUE;
    object _28934 = NOVALUE;
    object _28933 = NOVALUE;
    object _28932 = NOVALUE;
    object _28931 = NOVALUE;
    object _28930 = NOVALUE;
    object _28928 = NOVALUE;
    object _28927 = NOVALUE;
    object _28926 = NOVALUE;
    object _28925 = NOVALUE;
    object _28924 = NOVALUE;
    object _28920 = NOVALUE;
    object _28919 = NOVALUE;
    object _28918 = NOVALUE;
    object _28917 = NOVALUE;
    object _28914 = NOVALUE;
    object _28913 = NOVALUE;
    object _28911 = NOVALUE;
    object _28910 = NOVALUE;
    object _28909 = NOVALUE;
    object _28907 = NOVALUE;
    object _28906 = NOVALUE;
    object _28905 = NOVALUE;
    object _28904 = NOVALUE;
    object _28902 = NOVALUE;
    object _28901 = NOVALUE;
    object _28900 = NOVALUE;
    object _28898 = NOVALUE;
    object _28897 = NOVALUE;
    object _28894 = NOVALUE;
    object _28891 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:1811		sequence lhs_syms = {}*/
    RefDS(_22024);
    DeRef(_lhs_syms_57675);
    _lhs_syms_57675 = _22024;

    /** parser.e:1812		sequence lhs_list = {} -- make sure we don't repeat anything*/
    RefDS(_22024);
    DeRef(_lhs_list_57676);
    _lhs_list_57676 = _22024;

    /** parser.e:1814		integer need_comma = 0*/
    _need_comma_57679 = 0LL;

    /** parser.e:1815		while tok[T_ID] != RIGHT_BRACE with entry do*/
    goto L1; // [22] 215
L2: 
    _2 = (object)SEQ_PTR(_tok_57678);
    _28891 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _28891, -25LL)){
        _28891 = NOVALUE;
        goto L3; // [35] 225
    }
    _28891 = NOVALUE;

    /** parser.e:1817			if need_comma then*/
    if (_need_comma_57679 == 0)
    {
        goto L4; // [41] 63
    }
    else{
    }

    /** parser.e:1818				putback( tok )*/
    Ref(_tok_57678);
    _43putback(_tok_57678);

    /** parser.e:1819				tok_match( COMMA )*/
    _43tok_match(-30LL, 0LL);

    /** parser.e:1820				tok = next_token()*/
    _0 = _tok_57678;
    _tok_57678 = _43next_token();
    DeRef(_0);
L4: 

    /** parser.e:1823			if tok[T_ID] = QUESTION_MARK then*/
    _2 = (object)SEQ_PTR(_tok_57678);
    _28894 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28894, -31LL)){
        _28894 = NOVALUE;
        goto L5; // [73] 86
    }
    _28894 = NOVALUE;

    /** parser.e:1825				lhs_syms &= 0*/
    Append(&_lhs_syms_57675, _lhs_syms_57675, 0LL);
    goto L6; // [83] 207
L5: 

    /** parser.e:1826			elsif tok[T_ID] = VARIABLE or tok[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_57678);
    _28897 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28897)) {
        _28898 = (_28897 == -100LL);
    }
    else {
        _28898 = binary_op(EQUALS, _28897, -100LL);
    }
    _28897 = NOVALUE;
    if (IS_ATOM_INT(_28898)) {
        if (_28898 != 0) {
            goto L7; // [100] 121
        }
    }
    else {
        if (DBL_PTR(_28898)->dbl != 0.0) {
            goto L7; // [100] 121
        }
    }
    _2 = (object)SEQ_PTR(_tok_57678);
    _28900 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28900)) {
        _28901 = (_28900 == 512LL);
    }
    else {
        _28901 = binary_op(EQUALS, _28900, 512LL);
    }
    _28900 = NOVALUE;
    if (_28901 == 0) {
        DeRef(_28901);
        _28901 = NOVALUE;
        goto L8; // [117] 197
    }
    else {
        if (!IS_ATOM_INT(_28901) && DBL_PTR(_28901)->dbl == 0.0){
            DeRef(_28901);
            _28901 = NOVALUE;
            goto L8; // [117] 197
        }
        DeRef(_28901);
        _28901 = NOVALUE;
    }
    DeRef(_28901);
    _28901 = NOVALUE;
L7: 

    /** parser.e:1827				lhs_syms &= tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_57678);
    _28902 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_SEQUENCE(_lhs_syms_57675) && IS_ATOM(_28902)) {
        Ref(_28902);
        Append(&_lhs_syms_57675, _lhs_syms_57675, _28902);
    }
    else if (IS_ATOM(_lhs_syms_57675) && IS_SEQUENCE(_28902)) {
    }
    else {
        Concat((object_ptr)&_lhs_syms_57675, _lhs_syms_57675, _28902);
    }
    _28902 = NOVALUE;

    /** parser.e:1828				if SymTab[lhs_syms[$]][S_SCOPE] = SC_UNDEFINED then*/
    if (IS_SEQUENCE(_lhs_syms_57675)){
            _28904 = SEQ_PTR(_lhs_syms_57675)->length;
    }
    else {
        _28904 = 1;
    }
    _2 = (object)SEQ_PTR(_lhs_syms_57675);
    _28905 = (object)*(((s1_ptr)_2)->base + _28904);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28905)){
        _28906 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28905)->dbl));
    }
    else{
        _28906 = (object)*(((s1_ptr)_2)->base + _28905);
    }
    _2 = (object)SEQ_PTR(_28906);
    _28907 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28906 = NOVALUE;
    if (binary_op_a(NOTEQ, _28907, 9LL)){
        _28907 = NOVALUE;
        goto L9; // [156] 180
    }
    _28907 = NOVALUE;

    /** parser.e:1829					lhs_list = append( lhs_list, sym_name( lhs_syms[$] ) )*/
    if (IS_SEQUENCE(_lhs_syms_57675)){
            _28909 = SEQ_PTR(_lhs_syms_57675)->length;
    }
    else {
        _28909 = 1;
    }
    _2 = (object)SEQ_PTR(_lhs_syms_57675);
    _28910 = (object)*(((s1_ptr)_2)->base + _28909);
    Ref(_28910);
    _28911 = _53sym_name(_28910);
    _28910 = NOVALUE;
    Ref(_28911);
    Append(&_lhs_list_57676, _lhs_list_57676, _28911);
    DeRef(_28911);
    _28911 = NOVALUE;
    goto L6; // [177] 207
L9: 

    /** parser.e:1831					lhs_list &= lhs_syms[$]*/
    if (IS_SEQUENCE(_lhs_syms_57675)){
            _28913 = SEQ_PTR(_lhs_syms_57675)->length;
    }
    else {
        _28913 = 1;
    }
    _2 = (object)SEQ_PTR(_lhs_syms_57675);
    _28914 = (object)*(((s1_ptr)_2)->base + _28913);
    if (IS_SEQUENCE(_lhs_list_57676) && IS_ATOM(_28914)) {
        Ref(_28914);
        Append(&_lhs_list_57676, _lhs_list_57676, _28914);
    }
    else if (IS_ATOM(_lhs_list_57676) && IS_SEQUENCE(_28914)) {
    }
    else {
        Concat((object_ptr)&_lhs_list_57676, _lhs_list_57676, _28914);
    }
    _28914 = NOVALUE;
    goto L6; // [194] 207
L8: 

    /** parser.e:1834				CompileErr( A_VARIABLE_NAME_IS_EXPECTED_HERE)*/
    RefDS(_22024);
    _49CompileErr(24LL, _22024, 0LL);
L6: 

    /** parser.e:1837			need_comma = 1*/
    _need_comma_57679 = 1LL;

    /** parser.e:1838		entry*/
L1: 

    /** parser.e:1839			tok = next_token()*/
    _0 = _tok_57678;
    _tok_57678 = _43next_token();
    DeRef(_0);

    /** parser.e:1840		end while*/
    goto L2; // [222] 25
L3: 

    /** parser.e:1843		if length( lhs_list ) != length( remove_dups( sort( lhs_list ) ) ) then*/
    if (IS_SEQUENCE(_lhs_list_57676)){
            _28917 = SEQ_PTR(_lhs_list_57676)->length;
    }
    else {
        _28917 = 1;
    }
    RefDS(_lhs_list_57676);
    _28918 = _25sort(_lhs_list_57676, 1LL);
    _28919 = _24remove_dups(_28918, 2LL);
    _28918 = NOVALUE;
    if (IS_SEQUENCE(_28919)){
            _28920 = SEQ_PTR(_28919)->length;
    }
    else {
        _28920 = 1;
    }
    DeRef(_28919);
    _28919 = NOVALUE;
    if (_28917 == _28920)
    goto LA; // [243] 257

    /** parser.e:1844			CompileErr( DUPLICATE_MULTI_ASSIGN )*/
    RefDS(_22024);
    _49CompileErr(602LL, _22024, 0LL);
LA: 

    /** parser.e:1846		tok_match( EQUALS )*/
    _43tok_match(3LL, 0LL);

    /** parser.e:1849		Expr()*/
    _43Expr();

    /** parser.e:1851		symtab_index temp_sym = Pop()*/
    _temp_sym_57741 = _45Pop();
    if (!IS_ATOM_INT(_temp_sym_57741)) {
        _1 = (object)(DBL_PTR(_temp_sym_57741)->dbl);
        DeRefDS(_temp_sym_57741);
        _temp_sym_57741 = _1;
    }

    /** parser.e:1852		sequence temps = pop_temps()*/
    _0 = _temps_57744;
    _temps_57744 = _45pop_temps();
    DeRef(_0);

    /** parser.e:1853		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto LB; // [287] 303
    }
    else{
    }

    /** parser.e:1854			emit_opnd( temp_sym )*/
    _45emit_opnd(_temp_sym_57741);

    /** parser.e:1855			emit_op( REF_TEMP )*/
    _45emit_op(207LL);
LB: 

    /** parser.e:1858		for i = 1 to length( lhs_syms ) do*/
    if (IS_SEQUENCE(_lhs_syms_57675)){
            _28924 = SEQ_PTR(_lhs_syms_57675)->length;
    }
    else {
        _28924 = 1;
    }
    {
        object _i_57753;
        _i_57753 = 1LL;
LC: 
        if (_i_57753 > _28924){
            goto LD; // [308] 512
        }

        /** parser.e:1859			if lhs_syms[i] then*/
        _2 = (object)SEQ_PTR(_lhs_syms_57675);
        _28925 = (object)*(((s1_ptr)_2)->base + _i_57753);
        if (_28925 == 0) {
            _28925 = NOVALUE;
            goto LE; // [321] 503
        }
        else {
            if (!IS_ATOM_INT(_28925) && DBL_PTR(_28925)->dbl == 0.0){
                _28925 = NOVALUE;
                goto LE; // [321] 503
            }
            _28925 = NOVALUE;
        }
        _28925 = NOVALUE;

        /** parser.e:1860				if SymTab[lhs_syms[i]][S_SCOPE] = SC_UNDEFINED then*/
        _2 = (object)SEQ_PTR(_lhs_syms_57675);
        _28926 = (object)*(((s1_ptr)_2)->base + _i_57753);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!IS_ATOM_INT(_28926)){
            _28927 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28926)->dbl));
        }
        else{
            _28927 = (object)*(((s1_ptr)_2)->base + _28926);
        }
        _2 = (object)SEQ_PTR(_28927);
        _28928 = (object)*(((s1_ptr)_2)->base + 4LL);
        _28927 = NOVALUE;
        if (binary_op_a(NOTEQ, _28928, 9LL)){
            _28928 = NOVALUE;
            goto LF; // [344] 379
        }
        _28928 = NOVALUE;

        /** parser.e:1861					Forward_var( { VARIABLE, lhs_syms[i]}, ,ASSIGN )*/
        _2 = (object)SEQ_PTR(_lhs_syms_57675);
        _28930 = (object)*(((s1_ptr)_2)->base + _i_57753);
        Ref(_28930);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -100LL;
        ((intptr_t *)_2)[2] = _28930;
        _28931 = MAKE_SEQ(_1);
        _28930 = NOVALUE;
        _43Forward_var(_28931, -1LL, 18LL);
        _28931 = NOVALUE;

        /** parser.e:1862					lhs_syms[i] = Pop()*/
        _28932 = _45Pop();
        _2 = (object)SEQ_PTR(_lhs_syms_57675);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _lhs_syms_57675 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_57753);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _28932;
        if( _1 != _28932 ){
            DeRef(_1);
        }
        _28932 = NOVALUE;
        goto L10; // [376] 421
LF: 

        /** parser.e:1864					SymTab[lhs_syms[i]][S_USAGE] = or_bits(SymTab[lhs_syms[i]][S_USAGE], U_WRITTEN)*/
        _2 = (object)SEQ_PTR(_lhs_syms_57675);
        _28933 = (object)*(((s1_ptr)_2)->base + _i_57753);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_28933))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_28933)->dbl));
        else
        _3 = (object)(_28933 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_lhs_syms_57675);
        _28936 = (object)*(((s1_ptr)_2)->base + _i_57753);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!IS_ATOM_INT(_28936)){
            _28937 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28936)->dbl));
        }
        else{
            _28937 = (object)*(((s1_ptr)_2)->base + _28936);
        }
        _2 = (object)SEQ_PTR(_28937);
        _28938 = (object)*(((s1_ptr)_2)->base + 5LL);
        _28937 = NOVALUE;
        if (IS_ATOM_INT(_28938)) {
            {uintptr_t tu;
                 tu = (uintptr_t)_28938 | (uintptr_t)2LL;
                 _28939 = MAKE_UINT(tu);
            }
        }
        else {
            _28939 = binary_op(OR_BITS, _28938, 2LL);
        }
        _28938 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _28939;
        if( _1 != _28939 ){
            DeRef(_1);
        }
        _28939 = NOVALUE;
        _28934 = NOVALUE;
L10: 

        /** parser.e:1867				emit_opnd( lhs_syms[i] )*/
        _2 = (object)SEQ_PTR(_lhs_syms_57675);
        _28940 = (object)*(((s1_ptr)_2)->base + _i_57753);
        Ref(_28940);
        _45emit_opnd(_28940);
        _28940 = NOVALUE;

        /** parser.e:1869				emit_opnd( temp_sym )*/
        _45emit_opnd(_temp_sym_57741);

        /** parser.e:1870				emit_opnd( NewIntSym( i ) )*/
        _28941 = _53NewIntSym(_i_57753);
        _45emit_opnd(_28941);
        _28941 = NOVALUE;

        /** parser.e:1871				emit_op( RHS_SUBS )*/
        _45emit_op(25LL);

        /** parser.e:1872				integer len = length( Code )*/
        if (IS_SEQUENCE(_12Code_20315)){
                _len_57792 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _len_57792 = 1;
        }

        /** parser.e:1873				if Code[len] = temp_sym then*/
        _2 = (object)SEQ_PTR(_12Code_20315);
        _28943 = (object)*(((s1_ptr)_2)->base + _len_57792);
        if (binary_op_a(NOTEQ, _28943, _temp_sym_57741)){
            _28943 = NOVALUE;
            goto L11; // [466] 486
        }
        _28943 = NOVALUE;

        /** parser.e:1875					Code = remove( Code, len - 1, len )*/
        _28945 = _len_57792 - 1LL;
        {
            s1_ptr assign_space = SEQ_PTR(_12Code_20315);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_28945)) ? _28945 : (object)(DBL_PTR(_28945)->dbl);
            int stop = (IS_ATOM_INT(_len_57792)) ? _len_57792 : (object)(DBL_PTR(_len_57792)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_12Code_20315), start, &_12Code_20315 );
                }
                else Tail(SEQ_PTR(_12Code_20315), stop+1, &_12Code_20315);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_12Code_20315), start, &_12Code_20315);
            }
            else {
                assign_slice_seq = &assign_space;
                _12Code_20315 = Remove_elements(start, stop, (SEQ_PTR(_12Code_20315)->ref == 1));
            }
        }
        _28945 = NOVALUE;
L11: 

        /** parser.e:1877				emit_op( ASSIGN )*/
        _45emit_op(18LL);

        /** parser.e:1879				TypeCheck( lhs_syms[i] )*/
        _2 = (object)SEQ_PTR(_lhs_syms_57675);
        _28947 = (object)*(((s1_ptr)_2)->base + _i_57753);
        Ref(_28947);
        _43TypeCheck(_28947);
        _28947 = NOVALUE;
LE: 

        /** parser.e:1882		end for*/
        _i_57753 = _i_57753 + 1LL;
        goto LC; // [507] 315
LD: 
        ;
    }

    /** parser.e:1884		push_temps( temps )*/
    RefDS(_temps_57744);
    _45push_temps(_temps_57744);

    /** parser.e:1885		flush_temps()*/
    RefDS(_22024);
    _45flush_temps(_22024);

    /** parser.e:1887		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L12; // [526] 542
    }
    else{
    }

    /** parser.e:1888			emit_opnd( temp_sym )*/
    _45emit_opnd(_temp_sym_57741);

    /** parser.e:1889			emit_op( DEREF_TEMP )*/
    _45emit_op(208LL);
L12: 

    /** parser.e:1891	end procedure*/
    DeRef(_lhs_syms_57675);
    DeRef(_lhs_list_57676);
    DeRef(_tok_57678);
    DeRef(_temps_57744);
    _28905 = NOVALUE;
    _28919 = NOVALUE;
    DeRef(_28898);
    _28898 = NOVALUE;
    _28926 = NOVALUE;
    _28936 = NOVALUE;
    _28933 = NOVALUE;
    return;
    ;
}


void _43Return_statement()
{
    object _tok_57816 = NOVALUE;
    object _pop_57817 = NOVALUE;
    object _last_op_57824 = NOVALUE;
    object _last_pc_57827 = NOVALUE;
    object _is_tail_57830 = NOVALUE;
    object _28979 = NOVALUE;
    object _28977 = NOVALUE;
    object _28976 = NOVALUE;
    object _28975 = NOVALUE;
    object _28974 = NOVALUE;
    object _28972 = NOVALUE;
    object _28971 = NOVALUE;
    object _28970 = NOVALUE;
    object _28969 = NOVALUE;
    object _28968 = NOVALUE;
    object _28967 = NOVALUE;
    object _28966 = NOVALUE;
    object _28965 = NOVALUE;
    object _28961 = NOVALUE;
    object _28960 = NOVALUE;
    object _28958 = NOVALUE;
    object _28957 = NOVALUE;
    object _28956 = NOVALUE;
    object _28955 = NOVALUE;
    object _28954 = NOVALUE;
    object _28953 = NOVALUE;
    object _28952 = NOVALUE;
    object _28951 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1897		integer pop*/

    /** parser.e:1898		if CurrentSub = TopLevelSub then*/
    if (_12CurrentSub_20234 != _12TopLevelSub_20233)
    goto L1; // [9] 23

    /** parser.e:1899			CompileErr(RETURN_MUST_BE_INSIDE_A_PROCEDURE_OR_FUNCTION)*/
    RefDS(_22024);
    _49CompileErr(130LL, _22024, 0LL);
L1: 

    /** parser.e:1902		integer*/

    /** parser.e:1903			last_op = Last_op(),*/
    _last_op_57824 = _45Last_op();
    if (!IS_ATOM_INT(_last_op_57824)) {
        _1 = (object)(DBL_PTR(_last_op_57824)->dbl);
        DeRefDS(_last_op_57824);
        _last_op_57824 = _1;
    }

    /** parser.e:1904			last_pc = Last_pc(),*/
    _last_pc_57827 = _45Last_pc();
    if (!IS_ATOM_INT(_last_pc_57827)) {
        _1 = (object)(DBL_PTR(_last_pc_57827)->dbl);
        DeRefDS(_last_pc_57827);
        _last_pc_57827 = _1;
    }

    /** parser.e:1905			is_tail = 0*/
    _is_tail_57830 = 0LL;

    /** parser.e:1907		if last_op = PROC and length(Code) > last_pc and Code[last_pc+1] = CurrentSub then*/
    _28951 = (_last_op_57824 == 27LL);
    if (_28951 == 0) {
        _28952 = 0;
        goto L2; // [52] 69
    }
    if (IS_SEQUENCE(_12Code_20315)){
            _28953 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _28953 = 1;
    }
    _28954 = (_28953 > _last_pc_57827);
    _28953 = NOVALUE;
    _28952 = (_28954 != 0);
L2: 
    if (_28952 == 0) {
        goto L3; // [69] 99
    }
    _28956 = _last_pc_57827 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _28957 = (object)*(((s1_ptr)_2)->base + _28956);
    if (IS_ATOM_INT(_28957)) {
        _28958 = (_28957 == _12CurrentSub_20234);
    }
    else {
        _28958 = binary_op(EQUALS, _28957, _12CurrentSub_20234);
    }
    _28957 = NOVALUE;
    if (_28958 == 0) {
        DeRef(_28958);
        _28958 = NOVALUE;
        goto L3; // [90] 99
    }
    else {
        if (!IS_ATOM_INT(_28958) && DBL_PTR(_28958)->dbl == 0.0){
            DeRef(_28958);
            _28958 = NOVALUE;
            goto L3; // [90] 99
        }
        DeRef(_28958);
        _28958 = NOVALUE;
    }
    DeRef(_28958);
    _28958 = NOVALUE;

    /** parser.e:1908			is_tail = 1*/
    _is_tail_57830 = 1LL;
L3: 

    /** parser.e:1911		if not TRANSLATE then*/
    if (_12TRANSLATE_19834 != 0)
    goto L4; // [103] 129

    /** parser.e:1912			if OpTrace then*/
    if (_12OpTrace_20296 == 0)
    {
        goto L5; // [110] 128
    }
    else{
    }

    /** parser.e:1913				emit_op(ERASE_PRIVATE_NAMES)*/
    _45emit_op(88LL);

    /** parser.e:1914				emit_addr(CurrentSub)*/
    _45emit_addr(_12CurrentSub_20234);
L5: 
L4: 

    /** parser.e:1917		if SymTab[CurrentSub][S_TOKEN] != PROC then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _28960 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_28960);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _28961 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _28961 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _28960 = NOVALUE;
    if (binary_op_a(EQUALS, _28961, 27LL)){
        _28961 = NOVALUE;
        goto L6; // [147] 273
    }
    _28961 = NOVALUE;

    /** parser.e:1918			Expr()*/
    _43Expr();

    /** parser.e:1919			last_op = Last_op()*/
    _last_op_57824 = _45Last_op();
    if (!IS_ATOM_INT(_last_op_57824)) {
        _1 = (object)(DBL_PTR(_last_op_57824)->dbl);
        DeRefDS(_last_op_57824);
        _last_op_57824 = _1;
    }

    /** parser.e:1920			last_pc = Last_pc()*/
    _last_pc_57827 = _45Last_pc();
    if (!IS_ATOM_INT(_last_pc_57827)) {
        _1 = (object)(DBL_PTR(_last_pc_57827)->dbl);
        DeRefDS(_last_pc_57827);
        _last_pc_57827 = _1;
    }

    /** parser.e:1921			if last_op = PROC and length(Code) > last_pc and Code[last_pc+1] = CurrentSub then*/
    _28965 = (_last_op_57824 == 27LL);
    if (_28965 == 0) {
        _28966 = 0;
        goto L7; // [177] 194
    }
    if (IS_SEQUENCE(_12Code_20315)){
            _28967 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _28967 = 1;
    }
    _28968 = (_28967 > _last_pc_57827);
    _28967 = NOVALUE;
    _28966 = (_28968 != 0);
L7: 
    if (_28966 == 0) {
        goto L8; // [194] 253
    }
    _28970 = _last_pc_57827 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _28971 = (object)*(((s1_ptr)_2)->base + _28970);
    if (IS_ATOM_INT(_28971)) {
        _28972 = (_28971 == _12CurrentSub_20234);
    }
    else {
        _28972 = binary_op(EQUALS, _28971, _12CurrentSub_20234);
    }
    _28971 = NOVALUE;
    if (_28972 == 0) {
        DeRef(_28972);
        _28972 = NOVALUE;
        goto L8; // [215] 253
    }
    else {
        if (!IS_ATOM_INT(_28972) && DBL_PTR(_28972)->dbl == 0.0){
            DeRef(_28972);
            _28972 = NOVALUE;
            goto L8; // [215] 253
        }
        DeRef(_28972);
        _28972 = NOVALUE;
    }
    DeRef(_28972);
    _28972 = NOVALUE;

    /** parser.e:1922				pop = Pop() -- prevent cg_stack (code generation stack) leakage*/
    _pop_57817 = _45Pop();
    if (!IS_ATOM_INT(_pop_57817)) {
        _1 = (object)(DBL_PTR(_pop_57817)->dbl);
        DeRefDS(_pop_57817);
        _pop_57817 = _1;
    }

    /** parser.e:1923				Code[Last_pc()] = PROC_TAIL*/
    _28974 = _45Last_pc();
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_28974))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_28974)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _28974);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 203LL;
    DeRef(_1);

    /** parser.e:1924				if object(pop_temps()) then end if*/
    _28975 = _45pop_temps();
    if( NOVALUE == _28975 ){
        _28976 = 0;
    }
    else{
        if (IS_ATOM_INT(_28975))
        _28976 = 1;
        else if (IS_ATOM_DBL(_28975)) {
             if (IS_ATOM_INT(DoubleToInt(_28975))) {
                 _28976 = 1;
                 } else {
                     _28976 = 2;
                } } else if (IS_SEQUENCE(_28975))
                _28976 = 3;
                else
                _28976 = 0;
            }
            DeRef(_28975);
            _28975 = NOVALUE;
            if (_28976 == 0)
            {
                _28976 = NOVALUE;
                goto L9; // [246] 300
            }
            else{
                _28976 = NOVALUE;
            }
            goto L9; // [250] 300
L8: 

            /** parser.e:1926				FuncReturn = TRUE*/
            _43FuncReturn_55023 = _9TRUE_446;

            /** parser.e:1927				emit_op(RETURNF)*/
            _45emit_op(28LL);
            goto L9; // [270] 300
L6: 

            /** parser.e:1930			if is_tail then*/
            if (_is_tail_57830 == 0)
            {
                goto LA; // [275] 292
            }
            else{
            }

            /** parser.e:1931				Code[Last_pc()] = PROC_TAIL*/
            _28977 = _45Last_pc();
            _2 = (object)SEQ_PTR(_12Code_20315);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _12Code_20315 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_28977))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_28977)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _28977);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 203LL;
            DeRef(_1);
LA: 

            /** parser.e:1933			emit_op(RETURNP)*/
            _45emit_op(29LL);
L9: 

            /** parser.e:1936		tok = next_token()*/
            _0 = _tok_57816;
            _tok_57816 = _43next_token();
            DeRef(_0);

            /** parser.e:1937		putback(tok)*/
            Ref(_tok_57816);
            _43putback(_tok_57816);

            /** parser.e:1938		NotReached(tok[T_ID], "return")*/
            _2 = (object)SEQ_PTR(_tok_57816);
            _28979 = (object)*(((s1_ptr)_2)->base + 1LL);
            Ref(_28979);
            RefDS(_26338);
            _43NotReached(_28979, _26338);
            _28979 = NOVALUE;

            /** parser.e:1939	end procedure*/
            DeRef(_tok_57816);
            DeRef(_28954);
            _28954 = NOVALUE;
            DeRef(_28974);
            _28974 = NOVALUE;
            DeRef(_28977);
            _28977 = NOVALUE;
            DeRef(_28951);
            _28951 = NOVALUE;
            DeRef(_28956);
            _28956 = NOVALUE;
            DeRef(_28968);
            _28968 = NOVALUE;
            DeRef(_28970);
            _28970 = NOVALUE;
            DeRef(_28965);
            _28965 = NOVALUE;
            return;
    ;
}


object _43exit_level(object _tok_57906, object _flag_57907)
{
    object _arg_57908 = NOVALUE;
    object _n_57909 = NOVALUE;
    object _num_labels_57910 = NOVALUE;
    object _negative_57911 = NOVALUE;
    object _labels_57912 = NOVALUE;
    object _29008 = NOVALUE;
    object _29007 = NOVALUE;
    object _29006 = NOVALUE;
    object _29005 = NOVALUE;
    object _29004 = NOVALUE;
    object _29001 = NOVALUE;
    object _29000 = NOVALUE;
    object _28999 = NOVALUE;
    object _28997 = NOVALUE;
    object _28996 = NOVALUE;
    object _28995 = NOVALUE;
    object _28994 = NOVALUE;
    object _28992 = NOVALUE;
    object _28987 = NOVALUE;
    object _28986 = NOVALUE;
    object _28984 = NOVALUE;
    object _28981 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1946		integer negative = 0*/
    _negative_57911 = 0LL;

    /** parser.e:1949		if flag then*/
    if (_flag_57907 == 0)
    {
        goto L1; // [10] 25
    }
    else{
    }

    /** parser.e:1950			labels = if_labels*/
    RefDS(_43if_labels_55044);
    DeRef(_labels_57912);
    _labels_57912 = _43if_labels_55044;
    goto L2; // [22] 35
L1: 

    /** parser.e:1952			labels = loop_labels*/
    RefDS(_43loop_labels_55043);
    DeRef(_labels_57912);
    _labels_57912 = _43loop_labels_55043;
L2: 

    /** parser.e:1954		num_labels = length(labels)*/
    if (IS_SEQUENCE(_labels_57912)){
            _num_labels_57910 = SEQ_PTR(_labels_57912)->length;
    }
    else {
        _num_labels_57910 = 1;
    }

    /** parser.e:1956		if tok[T_ID] = MINUS then*/
    _2 = (object)SEQ_PTR(_tok_57906);
    _28981 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28981, 10LL)){
        _28981 = NOVALUE;
        goto L3; // [52] 67
    }
    _28981 = NOVALUE;

    /** parser.e:1957			tok = next_token()*/
    _0 = _tok_57906;
    _tok_57906 = _43next_token();
    DeRef(_0);

    /** parser.e:1958			negative = 1*/
    _negative_57911 = 1LL;
L3: 

    /** parser.e:1961		if tok[T_ID]=ATOM then*/
    _2 = (object)SEQ_PTR(_tok_57906);
    _28984 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28984, 502LL)){
        _28984 = NOVALUE;
        goto L4; // [77] 180
    }
    _28984 = NOVALUE;

    /** parser.e:1962			arg = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_tok_57906);
    _28986 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28986)){
        _28987 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28986)->dbl));
    }
    else{
        _28987 = (object)*(((s1_ptr)_2)->base + _28986);
    }
    DeRef(_arg_57908);
    _2 = (object)SEQ_PTR(_28987);
    _arg_57908 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_arg_57908);
    _28987 = NOVALUE;

    /** parser.e:1963			n = floor(arg)*/
    if (IS_ATOM_INT(_arg_57908))
    _n_57909 = e_floor(_arg_57908);
    else
    _n_57909 = unary_op(FLOOR, _arg_57908);
    if (!IS_ATOM_INT(_n_57909)) {
        _1 = (object)(DBL_PTR(_n_57909)->dbl);
        DeRefDS(_n_57909);
        _n_57909 = _1;
    }

    /** parser.e:1964			if negative then*/
    if (_negative_57911 == 0)
    {
        goto L5; // [110] 122
    }
    else{
    }

    /** parser.e:1965				n = num_labels - n*/
    _n_57909 = _num_labels_57910 - _n_57909;
    goto L6; // [119] 135
L5: 

    /** parser.e:1966			elsif n = 0 then*/
    if (_n_57909 != 0LL)
    goto L7; // [124] 134

    /** parser.e:1967				n = num_labels*/
    _n_57909 = _num_labels_57910;
L7: 
L6: 

    /** parser.e:1969			if n<=0 or n>num_labels then*/
    _28992 = (_n_57909 <= 0LL);
    if (_28992 != 0) {
        goto L8; // [141] 154
    }
    _28994 = (_n_57909 > _num_labels_57910);
    if (_28994 == 0)
    {
        DeRef(_28994);
        _28994 = NOVALUE;
        goto L9; // [150] 164
    }
    else{
        DeRef(_28994);
        _28994 = NOVALUE;
    }
L8: 

    /** parser.e:1970				CompileErr(EXITBREAK_ARGUMENT_OUT_OF_RANGE)*/
    RefDS(_22024);
    _49CompileErr(87LL, _22024, 0LL);
L9: 

    /** parser.e:1972			return {n, next_token()}*/
    _28995 = _43next_token();
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _n_57909;
    ((intptr_t *)_2)[2] = _28995;
    _28996 = MAKE_SEQ(_1);
    _28995 = NOVALUE;
    DeRef(_tok_57906);
    DeRef(_arg_57908);
    DeRef(_labels_57912);
    _28986 = NOVALUE;
    DeRef(_28992);
    _28992 = NOVALUE;
    return _28996;
    goto LA; // [177] 270
L4: 

    /** parser.e:1973		elsif tok[T_ID]=STRING then*/
    _2 = (object)SEQ_PTR(_tok_57906);
    _28997 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28997, 503LL)){
        _28997 = NOVALUE;
        goto LB; // [190] 259
    }
    _28997 = NOVALUE;

    /** parser.e:1974			n = find(SymTab[tok[T_SYM]][S_OBJ],labels)*/
    _2 = (object)SEQ_PTR(_tok_57906);
    _28999 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_28999)){
        _29000 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28999)->dbl));
    }
    else{
        _29000 = (object)*(((s1_ptr)_2)->base + _28999);
    }
    _2 = (object)SEQ_PTR(_29000);
    _29001 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29000 = NOVALUE;
    _n_57909 = find_from(_29001, _labels_57912, 1LL);
    _29001 = NOVALUE;

    /** parser.e:1975			if n = 0 then*/
    if (_n_57909 != 0LL)
    goto LC; // [221] 235

    /** parser.e:1976				CompileErr(UNKNOWN_BLOCK_LABEL)*/
    RefDS(_22024);
    _49CompileErr(152LL, _22024, 0LL);
LC: 

    /** parser.e:1978			return {num_labels + 1 - n, next_token()}*/
    _29004 = _num_labels_57910 + 1;
    if (_29004 > MAXINT){
        _29004 = NewDouble((eudouble)_29004);
    }
    if (IS_ATOM_INT(_29004)) {
        _29005 = _29004 - _n_57909;
        if ((object)((uintptr_t)_29005 +(uintptr_t) HIGH_BITS) >= 0){
            _29005 = NewDouble((eudouble)_29005);
        }
    }
    else {
        _29005 = NewDouble(DBL_PTR(_29004)->dbl - (eudouble)_n_57909);
    }
    DeRef(_29004);
    _29004 = NOVALUE;
    _29006 = _43next_token();
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _29005;
    ((intptr_t *)_2)[2] = _29006;
    _29007 = MAKE_SEQ(_1);
    _29006 = NOVALUE;
    _29005 = NOVALUE;
    DeRef(_tok_57906);
    DeRef(_arg_57908);
    DeRef(_labels_57912);
    _28986 = NOVALUE;
    DeRef(_28996);
    _28996 = NOVALUE;
    DeRef(_28992);
    _28992 = NOVALUE;
    _28999 = NOVALUE;
    return _29007;
    goto LA; // [256] 270
LB: 

    /** parser.e:1980			return {1, tok} -- no parameters*/
    Ref(_tok_57906);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1LL;
    ((intptr_t *)_2)[2] = _tok_57906;
    _29008 = MAKE_SEQ(_1);
    DeRef(_tok_57906);
    DeRef(_arg_57908);
    DeRef(_labels_57912);
    _28986 = NOVALUE;
    DeRef(_28996);
    _28996 = NOVALUE;
    DeRef(_28992);
    _28992 = NOVALUE;
    _28999 = NOVALUE;
    DeRef(_29007);
    _29007 = NOVALUE;
    return _29008;
LA: 
    ;
}


void _43GLabel_statement()
{
    object _tok_57971 = NOVALUE;
    object _labbel_57972 = NOVALUE;
    object _laddr_57973 = NOVALUE;
    object _n_57974 = NOVALUE;
    object _29027 = NOVALUE;
    object _29025 = NOVALUE;
    object _29024 = NOVALUE;
    object _29023 = NOVALUE;
    object _29022 = NOVALUE;
    object _29020 = NOVALUE;
    object _29017 = NOVALUE;
    object _29015 = NOVALUE;
    object _29013 = NOVALUE;
    object _29012 = NOVALUE;
    object _29010 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1986		object labbel*/

    /** parser.e:1987		object laddr*/

    /** parser.e:1988		integer n*/

    /** parser.e:1990		tok = next_token()*/
    _0 = _tok_57971;
    _tok_57971 = _43next_token();
    DeRef(_0);

    /** parser.e:1992		if tok[T_ID] != STRING then*/
    _2 = (object)SEQ_PTR(_tok_57971);
    _29010 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _29010, 503LL)){
        _29010 = NOVALUE;
        goto L1; // [22] 36
    }
    _29010 = NOVALUE;

    /** parser.e:1993			CompileErr(A_LABEL_CLAUSE_MUST_BE_FOLLOWED_BY_A_CONSTANT_STRING)*/
    RefDS(_22024);
    _49CompileErr(35LL, _22024, 0LL);
L1: 

    /** parser.e:1996		labbel = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_tok_57971);
    _29012 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_29012)){
        _29013 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29012)->dbl));
    }
    else{
        _29013 = (object)*(((s1_ptr)_2)->base + _29012);
    }
    DeRef(_labbel_57972);
    _2 = (object)SEQ_PTR(_29013);
    _labbel_57972 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_labbel_57972);
    _29013 = NOVALUE;

    /** parser.e:1997		laddr = length(Code) + 1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29015 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29015 = 1;
    }
    _laddr_57973 = _29015 + 1;
    _29015 = NOVALUE;

    /** parser.e:1999		if find(labbel, goto_labels) then*/
    _29017 = find_from(_labbel_57972, _43goto_labels_55026, 1LL);
    if (_29017 == 0)
    {
        _29017 = NOVALUE;
        goto L2; // [76] 89
    }
    else{
        _29017 = NOVALUE;
    }

    /** parser.e:2000			CompileErr(DUPLICATE_LABEL_NAME)*/
    RefDS(_22024);
    _49CompileErr(59LL, _22024, 0LL);
L2: 

    /** parser.e:2003		goto_labels = append(goto_labels, labbel)*/
    Ref(_labbel_57972);
    Append(&_43goto_labels_55026, _43goto_labels_55026, _labbel_57972);

    /** parser.e:2004		goto_addr = append(goto_addr, laddr)*/
    Append(&_43goto_addr_55027, _43goto_addr_55027, _laddr_57973);

    /** parser.e:2005		label_block = append( label_block, top_block() )*/
    _29020 = _64top_block(0LL);
    Ref(_29020);
    Append(&_43label_block_55030, _43label_block_55030, _29020);
    DeRef(_29020);
    _29020 = NOVALUE;

    /** parser.e:2007		while n with entry do*/
    goto L3; // [119] 178
L4: 
    if (_n_57974 == 0)
    {
        goto L5; // [124] 192
    }
    else{
    }

    /** parser.e:2008			backpatch(goto_list[n], laddr)*/
    _2 = (object)SEQ_PTR(_12goto_list_20338);
    _29022 = (object)*(((s1_ptr)_2)->base + _n_57974);
    Ref(_29022);
    _45backpatch(_29022, _laddr_57973);
    _29022 = NOVALUE;

    /** parser.e:2009			set_glabel_block( goto_ref[n], top_block() )*/
    _2 = (object)SEQ_PTR(_43goto_ref_55029);
    _29023 = (object)*(((s1_ptr)_2)->base + _n_57974);
    _29024 = _64top_block(0LL);
    Ref(_29023);
    _42set_glabel_block(_29023, _29024);
    _29023 = NOVALUE;
    _29024 = NOVALUE;

    /** parser.e:2010			goto_delay[n] = "" --clear it*/
    RefDS(_22024);
    _2 = (object)SEQ_PTR(_12goto_delay_20337);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12goto_delay_20337 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _n_57974);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22024;
    DeRef(_1);

    /** parser.e:2011			goto_line[n] = {-1,""} --clear it*/
    RefDS(_22024);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1LL;
    ((intptr_t *)_2)[2] = _22024;
    _29025 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_43goto_line_55025);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43goto_line_55025 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _n_57974);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29025;
    if( _1 != _29025 ){
        DeRef(_1);
    }
    _29025 = NOVALUE;

    /** parser.e:2013		entry*/
L3: 

    /** parser.e:2014			n = find(labbel, goto_delay)*/
    _n_57974 = find_from(_labbel_57972, _12goto_delay_20337, 1LL);

    /** parser.e:2015		end while*/
    goto L4; // [189] 122
L5: 

    /** parser.e:2017		force_uninitialize( map:get( goto_init, labbel, {} ) )*/
    Ref(_43goto_init_55032);
    Ref(_labbel_57972);
    RefDS(_22024);
    _29027 = _34get(_43goto_init_55032, _labbel_57972, _22024);
    _43force_uninitialize(_29027);
    _29027 = NOVALUE;

    /** parser.e:2019		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L6; // [209] 225
    }
    else{
    }

    /** parser.e:2020			emit_op(GLABEL)*/
    _45emit_op(189LL);

    /** parser.e:2021			emit_addr(laddr)*/
    _45emit_addr(_laddr_57973);
L6: 

    /** parser.e:2023	end procedure*/
    DeRef(_tok_57971);
    DeRef(_labbel_57972);
    _29012 = NOVALUE;
    return;
    ;
}


void _43Goto_statement()
{
    object _tok_58023 = NOVALUE;
    object _n_58024 = NOVALUE;
    object _num_labels_58025 = NOVALUE;
    object _31781 = NOVALUE;
    object _29066 = NOVALUE;
    object _29065 = NOVALUE;
    object _29062 = NOVALUE;
    object _29061 = NOVALUE;
    object _29060 = NOVALUE;
    object _29059 = NOVALUE;
    object _29058 = NOVALUE;
    object _29057 = NOVALUE;
    object _29056 = NOVALUE;
    object _29055 = NOVALUE;
    object _29054 = NOVALUE;
    object _29053 = NOVALUE;
    object _29052 = NOVALUE;
    object _29051 = NOVALUE;
    object _29049 = NOVALUE;
    object _29048 = NOVALUE;
    object _29046 = NOVALUE;
    object _29045 = NOVALUE;
    object _29043 = NOVALUE;
    object _29042 = NOVALUE;
    object _29040 = NOVALUE;
    object _29039 = NOVALUE;
    object _29038 = NOVALUE;
    object _29037 = NOVALUE;
    object _29034 = NOVALUE;
    object _29033 = NOVALUE;
    object _29032 = NOVALUE;
    object _29030 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2028		integer n*/

    /** parser.e:2029		integer num_labels*/

    /** parser.e:2031		tok = next_token()*/
    _0 = _tok_58023;
    _tok_58023 = _43next_token();
    DeRef(_0);

    /** parser.e:2032		num_labels = length(goto_labels)*/
    if (IS_SEQUENCE(_43goto_labels_55026)){
            _num_labels_58025 = SEQ_PTR(_43goto_labels_55026)->length;
    }
    else {
        _num_labels_58025 = 1;
    }

    /** parser.e:2034		if tok[T_ID]=STRING then*/
    _2 = (object)SEQ_PTR(_tok_58023);
    _29030 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29030, 503LL)){
        _29030 = NOVALUE;
        goto L1; // [27] 267
    }
    _29030 = NOVALUE;

    /** parser.e:2035			n = find(SymTab[tok[T_SYM]][S_OBJ],goto_labels)*/
    _2 = (object)SEQ_PTR(_tok_58023);
    _29032 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_29032)){
        _29033 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29032)->dbl));
    }
    else{
        _29033 = (object)*(((s1_ptr)_2)->base + _29032);
    }
    _2 = (object)SEQ_PTR(_29033);
    _29034 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29033 = NOVALUE;
    _n_58024 = find_from(_29034, _43goto_labels_55026, 1LL);
    _29034 = NOVALUE;

    /** parser.e:2036			if n = 0 then*/
    if (_n_58024 != 0LL)
    goto L2; // [60] 241

    /** parser.e:2037				goto_delay &= {SymTab[tok[T_SYM]][S_OBJ]}*/
    _2 = (object)SEQ_PTR(_tok_58023);
    _29037 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_29037)){
        _29038 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29037)->dbl));
    }
    else{
        _29038 = (object)*(((s1_ptr)_2)->base + _29037);
    }
    _2 = (object)SEQ_PTR(_29038);
    _29039 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29038 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_29039);
    ((intptr_t*)_2)[1] = _29039;
    _29040 = MAKE_SEQ(_1);
    _29039 = NOVALUE;
    Concat((object_ptr)&_12goto_delay_20337, _12goto_delay_20337, _29040);
    DeRefDS(_29040);
    _29040 = NOVALUE;

    /** parser.e:2038				goto_list &= length(Code)+2 --not 1???*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29042 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29042 = 1;
    }
    _29043 = _29042 + 2LL;
    _29042 = NOVALUE;
    Append(&_12goto_list_20338, _12goto_list_20338, _29043);
    _29043 = NOVALUE;

    /** parser.e:2039				goto_line &= {{line_number,ThisLine}}*/
    Ref(_49ThisLine_49312);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _12line_number_20227;
    ((intptr_t *)_2)[2] = _49ThisLine_49312;
    _29045 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _29045;
    _29046 = MAKE_SEQ(_1);
    _29045 = NOVALUE;
    Concat((object_ptr)&_43goto_line_55025, _43goto_line_55025, _29046);
    DeRefDS(_29046);
    _29046 = NOVALUE;

    /** parser.e:2040				goto_ref &= new_forward_reference( GOTO, top_block() )*/
    _29048 = _64top_block(0LL);
    _31781 = 188LL;
    _29049 = _42new_forward_reference(188LL, _29048, 188LL);
    _29048 = NOVALUE;
    _31781 = NOVALUE;
    if (IS_SEQUENCE(_43goto_ref_55029) && IS_ATOM(_29049)) {
        Ref(_29049);
        Append(&_43goto_ref_55029, _43goto_ref_55029, _29049);
    }
    else if (IS_ATOM(_43goto_ref_55029) && IS_SEQUENCE(_29049)) {
    }
    else {
        Concat((object_ptr)&_43goto_ref_55029, _43goto_ref_55029, _29049);
    }
    DeRef(_29049);
    _29049 = NOVALUE;

    /** parser.e:2041				map:put( goto_init, SymTab[tok[T_SYM]][S_OBJ], get_private_uninitialized() )*/
    _2 = (object)SEQ_PTR(_tok_58023);
    _29051 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_29051)){
        _29052 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29051)->dbl));
    }
    else{
        _29052 = (object)*(((s1_ptr)_2)->base + _29051);
    }
    _2 = (object)SEQ_PTR(_29052);
    _29053 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29052 = NOVALUE;
    _29054 = _43get_private_uninitialized();
    Ref(_43goto_init_55032);
    Ref(_29053);
    _34put(_43goto_init_55032, _29053, _29054, 1LL, 0LL);
    _29053 = NOVALUE;
    _29054 = NOVALUE;

    /** parser.e:2042				add_data( goto_ref[$], sym_obj( tok[T_SYM] ) )*/
    if (IS_SEQUENCE(_43goto_ref_55029)){
            _29055 = SEQ_PTR(_43goto_ref_55029)->length;
    }
    else {
        _29055 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_ref_55029);
    _29056 = (object)*(((s1_ptr)_2)->base + _29055);
    _2 = (object)SEQ_PTR(_tok_58023);
    _29057 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_29057);
    _29058 = _53sym_obj(_29057);
    _29057 = NOVALUE;
    Ref(_29056);
    _42add_data(_29056, _29058);
    _29056 = NOVALUE;
    _29058 = NOVALUE;

    /** parser.e:2043				set_line( goto_ref[$], line_number, ThisLine, bp )*/
    if (IS_SEQUENCE(_43goto_ref_55029)){
            _29059 = SEQ_PTR(_43goto_ref_55029)->length;
    }
    else {
        _29059 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_ref_55029);
    _29060 = (object)*(((s1_ptr)_2)->base + _29059);
    Ref(_29060);
    Ref(_49ThisLine_49312);
    _42set_line(_29060, _12line_number_20227, _49ThisLine_49312, _49bp_49316);
    _29060 = NOVALUE;
    goto L3; // [238] 259
L2: 

    /** parser.e:2045				Goto_block( top_block(), label_block[n] )*/
    _29061 = _64top_block(0LL);
    _2 = (object)SEQ_PTR(_43label_block_55030);
    _29062 = (object)*(((s1_ptr)_2)->base + _n_58024);
    Ref(_29062);
    _64Goto_block(_29061, _29062, 0LL);
    _29061 = NOVALUE;
    _29062 = NOVALUE;
L3: 

    /** parser.e:2047			tok = next_token()*/
    _0 = _tok_58023;
    _tok_58023 = _43next_token();
    DeRef(_0);
    goto L4; // [264] 277
L1: 

    /** parser.e:2049			CompileErr(GOTO_STATEMENT_WITHOUT_A_STRING_LABEL)*/
    RefDS(_22024);
    _49CompileErr(96LL, _22024, 0LL);
L4: 

    /** parser.e:2052		emit_op(GOTO)*/
    _45emit_op(188LL);

    /** parser.e:2053		if n = 0 then*/
    if (_n_58024 != 0LL)
    goto L5; // [288] 300

    /** parser.e:2054			emit_addr(0) -- to be back-patched*/
    _45emit_addr(0LL);
    goto L6; // [297] 312
L5: 

    /** parser.e:2056			emit_addr(goto_addr[n])*/
    _2 = (object)SEQ_PTR(_43goto_addr_55027);
    _29065 = (object)*(((s1_ptr)_2)->base + _n_58024);
    Ref(_29065);
    _45emit_addr(_29065);
    _29065 = NOVALUE;
L6: 

    /** parser.e:2059		putback(tok)*/
    Ref(_tok_58023);
    _43putback(_tok_58023);

    /** parser.e:2060		NotReached(tok[T_ID], "goto")*/
    _2 = (object)SEQ_PTR(_tok_58023);
    _29066 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_29066);
    RefDS(_26280);
    _43NotReached(_29066, _26280);
    _29066 = NOVALUE;

    /** parser.e:2061	end procedure*/
    DeRef(_tok_58023);
    _29037 = NOVALUE;
    _29032 = NOVALUE;
    _29051 = NOVALUE;
    return;
    ;
}


void _43Exit_statement()
{
    object _addr_inlined_AppendXList_at_65_58128 = NOVALUE;
    object _tok_58110 = NOVALUE;
    object _by_ref_58111 = NOVALUE;
    object _29074 = NOVALUE;
    object _29073 = NOVALUE;
    object _29072 = NOVALUE;
    object _29071 = NOVALUE;
    object _29069 = NOVALUE;
    object _29067 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2066		sequence by_ref*/

    /** parser.e:2068		if not length(loop_stack) then*/
    if (IS_SEQUENCE(_43loop_stack_55049)){
            _29067 = SEQ_PTR(_43loop_stack_55049)->length;
    }
    else {
        _29067 = 1;
    }
    if (_29067 != 0)
    goto L1; // [10] 23
    _29067 = NOVALUE;

    /** parser.e:2069			CompileErr(EXIT_STATEMENT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22024);
    _49CompileErr(88LL, _22024, 0LL);
L1: 

    /** parser.e:2072		by_ref = exit_level(next_token(),0) -- can't pass tok by reference*/
    _29069 = _43next_token();
    _0 = _by_ref_58111;
    _by_ref_58111 = _43exit_level(_29069, 0LL);
    DeRef(_0);
    _29069 = NOVALUE;

    /** parser.e:2073		Leave_blocks( by_ref[1], LOOP_BLOCK )*/
    _2 = (object)SEQ_PTR(_by_ref_58111);
    _29071 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_29071);
    _64Leave_blocks(_29071, 1LL);
    _29071 = NOVALUE;

    /** parser.e:2074		emit_op(EXIT)*/
    _45emit_op(61LL);

    /** parser.e:2075		AppendXList(length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29072 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29072 = 1;
    }
    _29073 = _29072 + 1;
    _29072 = NOVALUE;
    _addr_inlined_AppendXList_at_65_58128 = _29073;
    _29073 = NOVALUE;

    /** parser.e:398		exit_list = append(exit_list, addr)*/
    Append(&_43exit_list_55035, _43exit_list_55035, _addr_inlined_AppendXList_at_65_58128);

    /** parser.e:399	end procedure*/
    goto L2; // [80] 83
L2: 

    /** parser.e:2076		exit_delay &= by_ref[1]*/
    _2 = (object)SEQ_PTR(_by_ref_58111);
    _29074 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_43exit_delay_55036) && IS_ATOM(_29074)) {
        Ref(_29074);
        Append(&_43exit_delay_55036, _43exit_delay_55036, _29074);
    }
    else if (IS_ATOM(_43exit_delay_55036) && IS_SEQUENCE(_29074)) {
    }
    else {
        Concat((object_ptr)&_43exit_delay_55036, _43exit_delay_55036, _29074);
    }
    _29074 = NOVALUE;

    /** parser.e:2077		emit_forward_addr()    -- to be back-patched*/
    _43emit_forward_addr();

    /** parser.e:2078		tok = by_ref[2]*/
    DeRef(_tok_58110);
    _2 = (object)SEQ_PTR(_by_ref_58111);
    _tok_58110 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_tok_58110);

    /** parser.e:2079		putback(tok)*/
    Ref(_tok_58110);
    _43putback(_tok_58110);

    /** parser.e:2080	end procedure*/
    DeRef(_tok_58110);
    DeRefDS(_by_ref_58111);
    return;
    ;
}


void _43Continue_statement()
{
    object _addr_inlined_AppendNList_at_153_58174 = NOVALUE;
    object _tok_58135 = NOVALUE;
    object _by_ref_58136 = NOVALUE;
    object _loop_level_58137 = NOVALUE;
    object _29100 = NOVALUE;
    object _29097 = NOVALUE;
    object _29096 = NOVALUE;
    object _29095 = NOVALUE;
    object _29094 = NOVALUE;
    object _29093 = NOVALUE;
    object _29092 = NOVALUE;
    object _29090 = NOVALUE;
    object _29089 = NOVALUE;
    object _29088 = NOVALUE;
    object _29087 = NOVALUE;
    object _29086 = NOVALUE;
    object _29085 = NOVALUE;
    object _29084 = NOVALUE;
    object _29083 = NOVALUE;
    object _29081 = NOVALUE;
    object _29079 = NOVALUE;
    object _29077 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2085		sequence by_ref*/

    /** parser.e:2086		integer loop_level*/

    /** parser.e:2088		if not length(loop_stack) then*/
    if (IS_SEQUENCE(_43loop_stack_55049)){
            _29077 = SEQ_PTR(_43loop_stack_55049)->length;
    }
    else {
        _29077 = 1;
    }
    if (_29077 != 0)
    goto L1; // [12] 25
    _29077 = NOVALUE;

    /** parser.e:2089			CompileErr(CONTINUE_STATEMENT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22024);
    _49CompileErr(49LL, _22024, 0LL);
L1: 

    /** parser.e:2092		by_ref = exit_level(next_token(),0) -- can't pass tok by reference*/
    _29079 = _43next_token();
    _0 = _by_ref_58136;
    _by_ref_58136 = _43exit_level(_29079, 0LL);
    DeRef(_0);
    _29079 = NOVALUE;

    /** parser.e:2093		Leave_blocks( by_ref[1], LOOP_BLOCK )*/
    _2 = (object)SEQ_PTR(_by_ref_58136);
    _29081 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_29081);
    _64Leave_blocks(_29081, 1LL);
    _29081 = NOVALUE;

    /** parser.e:2094		emit_op(ELSE)*/
    _45emit_op(23LL);

    /** parser.e:2095		loop_level = by_ref[1]*/
    _2 = (object)SEQ_PTR(_by_ref_58136);
    _loop_level_58137 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_loop_level_58137))
    _loop_level_58137 = (object)DBL_PTR(_loop_level_58137)->dbl;

    /** parser.e:2098		if continue_addr[$+1-loop_level] then -- address is known for while loops*/
    if (IS_SEQUENCE(_43continue_addr_55040)){
            _29083 = SEQ_PTR(_43continue_addr_55040)->length;
    }
    else {
        _29083 = 1;
    }
    _29084 = _29083 + 1;
    _29083 = NOVALUE;
    _29085 = _29084 - _loop_level_58137;
    _29084 = NOVALUE;
    _2 = (object)SEQ_PTR(_43continue_addr_55040);
    _29086 = (object)*(((s1_ptr)_2)->base + _29085);
    if (_29086 == 0)
    {
        _29086 = NOVALUE;
        goto L2; // [81] 142
    }
    else{
        _29086 = NOVALUE;
    }

    /** parser.e:2099			if continue_addr[$+1-loop_level] < 0 then*/
    if (IS_SEQUENCE(_43continue_addr_55040)){
            _29087 = SEQ_PTR(_43continue_addr_55040)->length;
    }
    else {
        _29087 = 1;
    }
    _29088 = _29087 + 1;
    _29087 = NOVALUE;
    _29089 = _29088 - _loop_level_58137;
    _29088 = NOVALUE;
    _2 = (object)SEQ_PTR(_43continue_addr_55040);
    _29090 = (object)*(((s1_ptr)_2)->base + _29089);
    if (_29090 >= 0LL)
    goto L3; // [103] 117

    /** parser.e:2101				CompileErr(CONTINUE_STATEMENT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22024);
    _49CompileErr(49LL, _22024, 0LL);
L3: 

    /** parser.e:2103			emit_addr(continue_addr[$+1-loop_level])*/
    if (IS_SEQUENCE(_43continue_addr_55040)){
            _29092 = SEQ_PTR(_43continue_addr_55040)->length;
    }
    else {
        _29092 = 1;
    }
    _29093 = _29092 + 1;
    _29092 = NOVALUE;
    _29094 = _29093 - _loop_level_58137;
    _29093 = NOVALUE;
    _2 = (object)SEQ_PTR(_43continue_addr_55040);
    _29095 = (object)*(((s1_ptr)_2)->base + _29094);
    _45emit_addr(_29095);
    _29095 = NOVALUE;
    goto L4; // [139] 186
L2: 

    /** parser.e:2105			AppendNList(length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29096 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29096 = 1;
    }
    _29097 = _29096 + 1;
    _29096 = NOVALUE;
    _addr_inlined_AppendNList_at_153_58174 = _29097;
    _29097 = NOVALUE;

    /** parser.e:403		continue_list = append(continue_list, addr)*/
    Append(&_43continue_list_55037, _43continue_list_55037, _addr_inlined_AppendNList_at_153_58174);

    /** parser.e:404	end procedure*/
    goto L5; // [168] 171
L5: 

    /** parser.e:2106			continue_delay &= loop_level*/
    Append(&_43continue_delay_55038, _43continue_delay_55038, _loop_level_58137);

    /** parser.e:2107			emit_forward_addr()    -- to be back-patched*/
    _43emit_forward_addr();
L4: 

    /** parser.e:2110		tok = by_ref[2]*/
    DeRef(_tok_58135);
    _2 = (object)SEQ_PTR(_by_ref_58136);
    _tok_58135 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_tok_58135);

    /** parser.e:2111		putback(tok)*/
    Ref(_tok_58135);
    _43putback(_tok_58135);

    /** parser.e:2113		NotReached(tok[T_ID], "continue")*/
    _2 = (object)SEQ_PTR(_tok_58135);
    _29100 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_29100);
    RefDS(_26242);
    _43NotReached(_29100, _26242);
    _29100 = NOVALUE;

    /** parser.e:2114	end procedure*/
    DeRef(_tok_58135);
    DeRefDS(_by_ref_58136);
    DeRef(_29085);
    _29085 = NOVALUE;
    DeRef(_29094);
    _29094 = NOVALUE;
    _29090 = NOVALUE;
    DeRef(_29089);
    _29089 = NOVALUE;
    return;
    ;
}


void _43Retry_statement()
{
    object _by_ref_58181 = NOVALUE;
    object _tok_58183 = NOVALUE;
    object _29124 = NOVALUE;
    object _29122 = NOVALUE;
    object _29121 = NOVALUE;
    object _29120 = NOVALUE;
    object _29119 = NOVALUE;
    object _29118 = NOVALUE;
    object _29116 = NOVALUE;
    object _29115 = NOVALUE;
    object _29114 = NOVALUE;
    object _29113 = NOVALUE;
    object _29112 = NOVALUE;
    object _29110 = NOVALUE;
    object _29109 = NOVALUE;
    object _29108 = NOVALUE;
    object _29107 = NOVALUE;
    object _29106 = NOVALUE;
    object _29105 = NOVALUE;
    object _29103 = NOVALUE;
    object _29101 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2122		if not length(loop_stack) then*/
    if (IS_SEQUENCE(_43loop_stack_55049)){
            _29101 = SEQ_PTR(_43loop_stack_55049)->length;
    }
    else {
        _29101 = 1;
    }
    if (_29101 != 0)
    goto L1; // [8] 21
    _29101 = NOVALUE;

    /** parser.e:2123			CompileErr(RETRY_STATEMENT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22024);
    _49CompileErr(131LL, _22024, 0LL);
L1: 

    /** parser.e:2126		by_ref = exit_level(next_token(),0) -- can't pass tok by reference*/
    _29103 = _43next_token();
    _0 = _by_ref_58181;
    _by_ref_58181 = _43exit_level(_29103, 0LL);
    DeRef(_0);
    _29103 = NOVALUE;

    /** parser.e:2127		Leave_blocks( by_ref[1], LOOP_BLOCK )*/
    _2 = (object)SEQ_PTR(_by_ref_58181);
    _29105 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_29105);
    _64Leave_blocks(_29105, 1LL);
    _29105 = NOVALUE;

    /** parser.e:2128		if loop_stack[$+1-by_ref[1]]=FOR then*/
    if (IS_SEQUENCE(_43loop_stack_55049)){
            _29106 = SEQ_PTR(_43loop_stack_55049)->length;
    }
    else {
        _29106 = 1;
    }
    _29107 = _29106 + 1;
    _29106 = NOVALUE;
    _2 = (object)SEQ_PTR(_by_ref_58181);
    _29108 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_29108)) {
        _29109 = _29107 - _29108;
    }
    else {
        _29109 = binary_op(MINUS, _29107, _29108);
    }
    _29107 = NOVALUE;
    _29108 = NOVALUE;
    _2 = (object)SEQ_PTR(_43loop_stack_55049);
    if (!IS_ATOM_INT(_29109)){
        _29110 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29109)->dbl));
    }
    else{
        _29110 = (object)*(((s1_ptr)_2)->base + _29109);
    }
    if (_29110 != 21LL)
    goto L2; // [70] 84

    /** parser.e:2129			emit_op(RETRY) -- for Translator to emit a label at the right place*/
    _45emit_op(184LL);
    goto L3; // [81] 129
L2: 

    /** parser.e:2131			if retry_addr[$+1-by_ref[1]] < 0 then*/
    if (IS_SEQUENCE(_43retry_addr_55041)){
            _29112 = SEQ_PTR(_43retry_addr_55041)->length;
    }
    else {
        _29112 = 1;
    }
    _29113 = _29112 + 1;
    _29112 = NOVALUE;
    _2 = (object)SEQ_PTR(_by_ref_58181);
    _29114 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_29114)) {
        _29115 = _29113 - _29114;
    }
    else {
        _29115 = binary_op(MINUS, _29113, _29114);
    }
    _29113 = NOVALUE;
    _29114 = NOVALUE;
    _2 = (object)SEQ_PTR(_43retry_addr_55041);
    if (!IS_ATOM_INT(_29115)){
        _29116 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29115)->dbl));
    }
    else{
        _29116 = (object)*(((s1_ptr)_2)->base + _29115);
    }
    if (_29116 >= 0LL)
    goto L4; // [107] 121

    /** parser.e:2133				CompileErr(RETRY_STATEMENT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22024);
    _49CompileErr(131LL, _22024, 0LL);
L4: 

    /** parser.e:2135			emit_op(ELSE)*/
    _45emit_op(23LL);
L3: 

    /** parser.e:2138		emit_addr(retry_addr[$+1-by_ref[1]])*/
    if (IS_SEQUENCE(_43retry_addr_55041)){
            _29118 = SEQ_PTR(_43retry_addr_55041)->length;
    }
    else {
        _29118 = 1;
    }
    _29119 = _29118 + 1;
    _29118 = NOVALUE;
    _2 = (object)SEQ_PTR(_by_ref_58181);
    _29120 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_29120)) {
        _29121 = _29119 - _29120;
    }
    else {
        _29121 = binary_op(MINUS, _29119, _29120);
    }
    _29119 = NOVALUE;
    _29120 = NOVALUE;
    _2 = (object)SEQ_PTR(_43retry_addr_55041);
    if (!IS_ATOM_INT(_29121)){
        _29122 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29121)->dbl));
    }
    else{
        _29122 = (object)*(((s1_ptr)_2)->base + _29121);
    }
    _45emit_addr(_29122);
    _29122 = NOVALUE;

    /** parser.e:2139		tok = by_ref[2]*/
    DeRef(_tok_58183);
    _2 = (object)SEQ_PTR(_by_ref_58181);
    _tok_58183 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_tok_58183);

    /** parser.e:2140		putback(tok)*/
    Ref(_tok_58183);
    _43putback(_tok_58183);

    /** parser.e:2141		NotReached(tok[T_ID], "retry")*/
    _2 = (object)SEQ_PTR(_tok_58183);
    _29124 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_29124);
    RefDS(_26336);
    _43NotReached(_29124, _26336);
    _29124 = NOVALUE;

    /** parser.e:2142	end procedure*/
    DeRefDS(_by_ref_58181);
    DeRef(_tok_58183);
    DeRef(_29121);
    _29121 = NOVALUE;
    _29110 = NOVALUE;
    _29116 = NOVALUE;
    DeRef(_29109);
    _29109 = NOVALUE;
    DeRef(_29115);
    _29115 = NOVALUE;
    return;
    ;
}


object _43in_switch()
{
    object _29129 = NOVALUE;
    object _29128 = NOVALUE;
    object _29127 = NOVALUE;
    object _29126 = NOVALUE;
    object _29125 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2145		if length( if_stack ) and if_stack[$] = SWITCH then*/
    if (IS_SEQUENCE(_43if_stack_55050)){
            _29125 = SEQ_PTR(_43if_stack_55050)->length;
    }
    else {
        _29125 = 1;
    }
    if (_29125 == 0) {
        goto L1; // [8] 40
    }
    if (IS_SEQUENCE(_43if_stack_55050)){
            _29127 = SEQ_PTR(_43if_stack_55050)->length;
    }
    else {
        _29127 = 1;
    }
    _2 = (object)SEQ_PTR(_43if_stack_55050);
    _29128 = (object)*(((s1_ptr)_2)->base + _29127);
    _29129 = (_29128 == 185LL);
    _29128 = NOVALUE;
    if (_29129 == 0)
    {
        DeRef(_29129);
        _29129 = NOVALUE;
        goto L1; // [28] 40
    }
    else{
        DeRef(_29129);
        _29129 = NOVALUE;
    }

    /** parser.e:2146			return 1*/
    return 1LL;
    goto L2; // [37] 47
L1: 

    /** parser.e:2148			return 0*/
    return 0LL;
L2: 
    ;
}


void _43Break_statement()
{
    object _addr_inlined_AppendEList_at_65_58256 = NOVALUE;
    object _tok_58238 = NOVALUE;
    object _by_ref_58239 = NOVALUE;
    object _29140 = NOVALUE;
    object _29137 = NOVALUE;
    object _29136 = NOVALUE;
    object _29135 = NOVALUE;
    object _29134 = NOVALUE;
    object _29132 = NOVALUE;
    object _29130 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2154		sequence by_ref*/

    /** parser.e:2156		if not length(if_labels) then*/
    if (IS_SEQUENCE(_43if_labels_55044)){
            _29130 = SEQ_PTR(_43if_labels_55044)->length;
    }
    else {
        _29130 = 1;
    }
    if (_29130 != 0)
    goto L1; // [10] 23
    _29130 = NOVALUE;

    /** parser.e:2157			CompileErr(BREAK_STATEMENT_MUST_BE_INSIDE_A_IF_OR_A_SWITCH_BLOCK)*/
    RefDS(_22024);
    _49CompileErr(40LL, _22024, 0LL);
L1: 

    /** parser.e:2160		by_ref = exit_level(next_token(),1)*/
    _29132 = _43next_token();
    _0 = _by_ref_58239;
    _by_ref_58239 = _43exit_level(_29132, 1LL);
    DeRef(_0);
    _29132 = NOVALUE;

    /** parser.e:2161		Leave_blocks( by_ref[1], CONDITIONAL_BLOCK )*/
    _2 = (object)SEQ_PTR(_by_ref_58239);
    _29134 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_29134);
    _64Leave_blocks(_29134, 2LL);
    _29134 = NOVALUE;

    /** parser.e:2162		emit_op(ELSE)*/
    _45emit_op(23LL);

    /** parser.e:2163		AppendEList(length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29135 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29135 = 1;
    }
    _29136 = _29135 + 1;
    _29135 = NOVALUE;
    _addr_inlined_AppendEList_at_65_58256 = _29136;
    _29136 = NOVALUE;

    /** parser.e:393		break_list = append(break_list, addr)*/
    Append(&_43break_list_55033, _43break_list_55033, _addr_inlined_AppendEList_at_65_58256);

    /** parser.e:394	end procedure*/
    goto L2; // [80] 83
L2: 

    /** parser.e:2165		break_delay &= by_ref[1]*/
    _2 = (object)SEQ_PTR(_by_ref_58239);
    _29137 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_43break_delay_55034) && IS_ATOM(_29137)) {
        Ref(_29137);
        Append(&_43break_delay_55034, _43break_delay_55034, _29137);
    }
    else if (IS_ATOM(_43break_delay_55034) && IS_SEQUENCE(_29137)) {
    }
    else {
        Concat((object_ptr)&_43break_delay_55034, _43break_delay_55034, _29137);
    }
    _29137 = NOVALUE;

    /** parser.e:2166		emit_forward_addr()    -- to be back-patched*/
    _43emit_forward_addr();

    /** parser.e:2167		tok = by_ref[2]*/
    DeRef(_tok_58238);
    _2 = (object)SEQ_PTR(_by_ref_58239);
    _tok_58238 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_tok_58238);

    /** parser.e:2168		putback(tok)*/
    Ref(_tok_58238);
    _43putback(_tok_58238);

    /** parser.e:2169		NotReached(tok[T_ID], "break")*/
    _2 = (object)SEQ_PTR(_tok_58238);
    _29140 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_29140);
    RefDS(_26226);
    _43NotReached(_29140, _26226);
    _29140 = NOVALUE;

    /** parser.e:2170	end procedure*/
    DeRef(_tok_58238);
    DeRefDS(_by_ref_58239);
    return;
    ;
}


object _43finish_block_header(object _opcode_58265)
{
    object _tok_58267 = NOVALUE;
    object _labbel_58268 = NOVALUE;
    object _has_entry_58269 = NOVALUE;
    object _29194 = NOVALUE;
    object _29193 = NOVALUE;
    object _29192 = NOVALUE;
    object _29191 = NOVALUE;
    object _29188 = NOVALUE;
    object _29183 = NOVALUE;
    object _29180 = NOVALUE;
    object _29178 = NOVALUE;
    object _29175 = NOVALUE;
    object _29174 = NOVALUE;
    object _29172 = NOVALUE;
    object _29169 = NOVALUE;
    object _29166 = NOVALUE;
    object _29165 = NOVALUE;
    object _29163 = NOVALUE;
    object _29161 = NOVALUE;
    object _29158 = NOVALUE;
    object _29155 = NOVALUE;
    object _29154 = NOVALUE;
    object _29152 = NOVALUE;
    object _29150 = NOVALUE;
    object _29149 = NOVALUE;
    object _29148 = NOVALUE;
    object _29145 = NOVALUE;
    object _29142 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2176		object labbel*/

    /** parser.e:2177		integer has_entry*/

    /** parser.e:2179		tok = next_token()*/
    _0 = _tok_58267;
    _tok_58267 = _43next_token();
    DeRef(_0);

    /** parser.e:2180		has_entry=0*/
    _has_entry_58269 = 0LL;

    /** parser.e:2182		if tok[T_ID] = WITH then*/
    _2 = (object)SEQ_PTR(_tok_58267);
    _29142 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29142, 420LL)){
        _29142 = NOVALUE;
        goto L1; // [27] 160
    }
    _29142 = NOVALUE;

    /** parser.e:2183			tok = next_token()*/
    _0 = _tok_58267;
    _tok_58267 = _43next_token();
    DeRef(_0);

    /** parser.e:2184			switch tok[T_ID] do*/
    _2 = (object)SEQ_PTR(_tok_58267);
    _29145 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_29145) ){
        goto L2; // [44] 140
    }
    if(!IS_ATOM_INT(_29145)){
        if( (DBL_PTR(_29145)->dbl != (eudouble) ((object) DBL_PTR(_29145)->dbl) ) ){
            goto L2; // [44] 140
        }
        _0 = (object) DBL_PTR(_29145)->dbl;
    }
    else {
        _0 = _29145;
    };
    _29145 = NOVALUE;
    switch ( _0 ){ 

        /** parser.e:2185			    case ENTRY then*/
        case 424:

        /** parser.e:2186					if not (opcode = WHILE or opcode = LOOP) then*/
        _29148 = (_opcode_58265 == 47LL);
        if (_29148 != 0) {
            DeRef(_29149);
            _29149 = 1;
            goto L3; // [61] 75
        }
        _29150 = (_opcode_58265 == 422LL);
        _29149 = (_29150 != 0);
L3: 
        if (_29149 != 0)
        goto L4; // [75] 88
        _29149 = NOVALUE;

        /** parser.e:2187						CompileErr(MSG_WITH_ENTRY_IS_ONLY_VALID_ON_A_WHILE_OR_LOOP_STATEMENT)*/
        RefDS(_22024);
        _49CompileErr(14LL, _22024, 0LL);
L4: 

        /** parser.e:2190				    has_entry = 1*/
        _has_entry_58269 = 1LL;
        goto L5; // [93] 152

        /** parser.e:2192				case FALLTHRU then*/
        case 431:

        /** parser.e:2193					if not opcode = SWITCH then*/
        _29152 = (_opcode_58265 == 0);
        if (_29152 != 185LL)
        goto L6; // [106] 120

        /** parser.e:2194						CompileErr(MSG_WITH_FALLTHRU_IS_ONLY_VALID_IN_A_SWITCH_STATEMENT)*/
        RefDS(_22024);
        _49CompileErr(13LL, _22024, 0LL);
L6: 

        /** parser.e:2197					switch_stack[$][SWITCH_FALLTHRU] = 1*/
        if (IS_SEQUENCE(_43switch_stack_55264)){
                _29154 = SEQ_PTR(_43switch_stack_55264)->length;
        }
        else {
            _29154 = 1;
        }
        _2 = (object)SEQ_PTR(_43switch_stack_55264);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _43switch_stack_55264 = MAKE_SEQ(_2);
        }
        _3 = (object)(_29154 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 1LL;
        DeRef(_1);
        _29155 = NOVALUE;
        goto L5; // [136] 152

        /** parser.e:2199				case else*/
        default:
L2: 

        /** parser.e:2200				    CompileErr(AN_UNKNOWN_WITHWITHOUT_OPTION_HAS_BEEN_SPECIFIED)*/
        RefDS(_22024);
        _49CompileErr(27LL, _22024, 0LL);
    ;}L5: 

    /** parser.e:2203	        tok = next_token()*/
    _0 = _tok_58267;
    _tok_58267 = _43next_token();
    DeRef(_0);
    goto L7; // [157] 250
L1: 

    /** parser.e:2204		elsif tok[T_ID] = WITHOUT then*/
    _2 = (object)SEQ_PTR(_tok_58267);
    _29158 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29158, 421LL)){
        _29158 = NOVALUE;
        goto L8; // [170] 249
    }
    _29158 = NOVALUE;

    /** parser.e:2205			tok = next_token()*/
    _0 = _tok_58267;
    _tok_58267 = _43next_token();
    DeRef(_0);

    /** parser.e:2206			if tok[T_ID] = FALLTHRU then*/
    _2 = (object)SEQ_PTR(_tok_58267);
    _29161 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29161, 431LL)){
        _29161 = NOVALUE;
        goto L9; // [189] 233
    }
    _29161 = NOVALUE;

    /** parser.e:2207				if not opcode = SWITCH then*/
    _29163 = (_opcode_58265 == 0);
    if (_29163 != 185LL)
    goto LA; // [200] 214

    /** parser.e:2208					CompileErr(MSG_WITHOUT_FALLTHRU_IS_ONLY_VALID_IN_A_SWITCH_STATEMENT)*/
    RefDS(_22024);
    _49CompileErr(15LL, _22024, 0LL);
LA: 

    /** parser.e:2211				switch_stack[$][SWITCH_FALLTHRU] = 0*/
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _29165 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _29165 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55264);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55264 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29165 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _29166 = NOVALUE;
    goto LB; // [230] 243
L9: 

    /** parser.e:2214				CompileErr(AN_UNKNOWN_WITHWITHOUT_OPTION_HAS_BEEN_SPECIFIED)*/
    RefDS(_22024);
    _49CompileErr(27LL, _22024, 0LL);
LB: 

    /** parser.e:2216	        tok = next_token()*/
    _0 = _tok_58267;
    _tok_58267 = _43next_token();
    DeRef(_0);
L8: 
L7: 

    /** parser.e:2219		labbel=0*/
    DeRef(_labbel_58268);
    _labbel_58268 = 0LL;

    /** parser.e:2220		if tok[T_ID]=LABEL then*/
    _2 = (object)SEQ_PTR(_tok_58267);
    _29169 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29169, 419LL)){
        _29169 = NOVALUE;
        goto LC; // [265] 329
    }
    _29169 = NOVALUE;

    /** parser.e:2221			tok = next_token()*/
    _0 = _tok_58267;
    _tok_58267 = _43next_token();
    DeRef(_0);

    /** parser.e:2222			if tok[T_ID] != STRING then*/
    _2 = (object)SEQ_PTR(_tok_58267);
    _29172 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _29172, 503LL)){
        _29172 = NOVALUE;
        goto LD; // [284] 298
    }
    _29172 = NOVALUE;

    /** parser.e:2223				CompileErr(A_LABEL_CLAUSE_MUST_BE_FOLLOWED_BY_A_LITERAL_STRING)*/
    RefDS(_22024);
    _49CompileErr(38LL, _22024, 0LL);
LD: 

    /** parser.e:2225			labbel = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_tok_58267);
    _29174 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_29174)){
        _29175 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29174)->dbl));
    }
    else{
        _29175 = (object)*(((s1_ptr)_2)->base + _29174);
    }
    DeRef(_labbel_58268);
    _2 = (object)SEQ_PTR(_29175);
    _labbel_58268 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_labbel_58268);
    _29175 = NOVALUE;

    /** parser.e:2226			block_label( labbel )*/
    Ref(_labbel_58268);
    _64block_label(_labbel_58268);

    /** parser.e:2227			tok = next_token()*/
    _0 = _tok_58267;
    _tok_58267 = _43next_token();
    DeRef(_0);
LC: 

    /** parser.e:2229		if opcode = IF or opcode = SWITCH then*/
    _29178 = (_opcode_58265 == 20LL);
    if (_29178 != 0) {
        goto LE; // [337] 352
    }
    _29180 = (_opcode_58265 == 185LL);
    if (_29180 == 0)
    {
        DeRef(_29180);
        _29180 = NOVALUE;
        goto LF; // [348] 363
    }
    else{
        DeRef(_29180);
        _29180 = NOVALUE;
    }
LE: 

    /** parser.e:2230			if_labels = append(if_labels,labbel)*/
    Ref(_labbel_58268);
    Append(&_43if_labels_55044, _43if_labels_55044, _labbel_58268);
    goto L10; // [360] 372
LF: 

    /** parser.e:2232			loop_labels = append(loop_labels,labbel)*/
    Ref(_labbel_58268);
    Append(&_43loop_labels_55043, _43loop_labels_55043, _labbel_58268);
L10: 

    /** parser.e:2234		if block_index=length(block_list) then*/
    if (IS_SEQUENCE(_43block_list_55045)){
            _29183 = SEQ_PTR(_43block_list_55045)->length;
    }
    else {
        _29183 = 1;
    }
    if (_43block_index_55046 != _29183)
    goto L11; // [381] 404

    /** parser.e:2235		    block_list &= opcode*/
    Append(&_43block_list_55045, _43block_list_55045, _opcode_58265);

    /** parser.e:2236		    block_index += 1*/
    _43block_index_55046 = _43block_index_55046 + 1;
    goto L12; // [401] 423
L11: 

    /** parser.e:2238		    block_index += 1*/
    _43block_index_55046 = _43block_index_55046 + 1;

    /** parser.e:2239		    block_list[block_index] = opcode*/
    _2 = (object)SEQ_PTR(_43block_list_55045);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43block_list_55045 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _43block_index_55046);
    *(intptr_t *)_2 = _opcode_58265;
L12: 

    /** parser.e:2241		if tok[T_ID]=ENTRY then*/
    _2 = (object)SEQ_PTR(_tok_58267);
    _29188 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29188, 424LL)){
        _29188 = NOVALUE;
        goto L13; // [433] 463
    }
    _29188 = NOVALUE;

    /** parser.e:2242		    if has_entry then*/
    if (_has_entry_58269 == 0)
    {
        goto L14; // [439] 452
    }
    else{
    }

    /** parser.e:2243		        CompileErr(DUPLICATE_ENTRY_CLAUSE_IN_A_LOOP_HEADER)*/
    RefDS(_22024);
    _49CompileErr(64LL, _22024, 0LL);
L14: 

    /** parser.e:2245		    has_entry=1*/
    _has_entry_58269 = 1LL;

    /** parser.e:2246		    tok=next_token()*/
    _0 = _tok_58267;
    _tok_58267 = _43next_token();
    DeRef(_0);
L13: 

    /** parser.e:2248		if has_entry and (opcode = IF or opcode = SWITCH) then*/
    if (_has_entry_58269 == 0) {
        goto L15; // [465] 503
    }
    _29192 = (_opcode_58265 == 20LL);
    if (_29192 != 0) {
        DeRef(_29193);
        _29193 = 1;
        goto L16; // [475] 489
    }
    _29194 = (_opcode_58265 == 185LL);
    _29193 = (_29194 != 0);
L16: 
    if (_29193 == 0)
    {
        _29193 = NOVALUE;
        goto L15; // [490] 503
    }
    else{
        _29193 = NOVALUE;
    }

    /** parser.e:2249			CompileErr(ENTRY_KEYWORD_IS_NOT_SUPPORTED_INSIDE_AN_IF_OR_SWITCH_BLOCK_HEADER)*/
    RefDS(_22024);
    _49CompileErr(80LL, _22024, 0LL);
L15: 

    /** parser.e:2251		if opcode = IF then*/
    if (_opcode_58265 != 20LL)
    goto L17; // [507] 523

    /** parser.e:2252			opcode = THEN*/
    _opcode_58265 = 410LL;
    goto L18; // [520] 533
L17: 

    /** parser.e:2254			opcode = DO*/
    _opcode_58265 = 411LL;
L18: 

    /** parser.e:2256		putback(tok)*/
    Ref(_tok_58267);
    _43putback(_tok_58267);

    /** parser.e:2257		tok_match(opcode)*/
    _43tok_match(_opcode_58265, 0LL);

    /** parser.e:2258		return has_entry*/
    DeRef(_tok_58267);
    DeRef(_labbel_58268);
    DeRef(_29178);
    _29178 = NOVALUE;
    DeRef(_29194);
    _29194 = NOVALUE;
    DeRef(_29150);
    _29150 = NOVALUE;
    DeRef(_29152);
    _29152 = NOVALUE;
    DeRef(_29192);
    _29192 = NOVALUE;
    _29174 = NOVALUE;
    DeRef(_29163);
    _29163 = NOVALUE;
    DeRef(_29148);
    _29148 = NOVALUE;
    return _has_entry_58269;
    ;
}


void _43If_statement()
{
    object _addr_inlined_AppendEList_at_624_58523 = NOVALUE;
    object _addr_inlined_AppendEList_at_260_58452 = NOVALUE;
    object _tok_58395 = NOVALUE;
    object _prev_false_58396 = NOVALUE;
    object _prev_false2_58397 = NOVALUE;
    object _elist_base_58398 = NOVALUE;
    object _temps_58406 = NOVALUE;
    object _31780 = NOVALUE;
    object _29260 = NOVALUE;
    object _29259 = NOVALUE;
    object _29256 = NOVALUE;
    object _29255 = NOVALUE;
    object _29253 = NOVALUE;
    object _29252 = NOVALUE;
    object _29251 = NOVALUE;
    object _29249 = NOVALUE;
    object _29248 = NOVALUE;
    object _29246 = NOVALUE;
    object _29245 = NOVALUE;
    object _29244 = NOVALUE;
    object _29242 = NOVALUE;
    object _29241 = NOVALUE;
    object _29239 = NOVALUE;
    object _29238 = NOVALUE;
    object _29237 = NOVALUE;
    object _29236 = NOVALUE;
    object _29234 = NOVALUE;
    object _29233 = NOVALUE;
    object _29230 = NOVALUE;
    object _29228 = NOVALUE;
    object _29227 = NOVALUE;
    object _29226 = NOVALUE;
    object _29223 = NOVALUE;
    object _29220 = NOVALUE;
    object _29219 = NOVALUE;
    object _29217 = NOVALUE;
    object _29216 = NOVALUE;
    object _29214 = NOVALUE;
    object _29213 = NOVALUE;
    object _29211 = NOVALUE;
    object _29208 = NOVALUE;
    object _29206 = NOVALUE;
    object _29205 = NOVALUE;
    object _29204 = NOVALUE;
    object _29200 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2265		integer prev_false*/

    /** parser.e:2266		integer prev_false2*/

    /** parser.e:2267		integer elist_base*/

    /** parser.e:2269		if_stack &= IF*/
    Append(&_43if_stack_55050, _43if_stack_55050, 20LL);

    /** parser.e:2271		Start_block( IF )*/
    _64Start_block(20LL, 0LL);

    /** parser.e:2273		elist_base = length(break_list)*/
    if (IS_SEQUENCE(_43break_list_55033)){
            _elist_base_58398 = SEQ_PTR(_43break_list_55033)->length;
    }
    else {
        _elist_base_58398 = 1;
    }

    /** parser.e:2274		short_circuit += 1*/
    _43short_circuit_55015 = _43short_circuit_55015 + 1;

    /** parser.e:2275		short_circuit_B = FALSE*/
    _43short_circuit_B_55017 = _9FALSE_444;

    /** parser.e:2276		SC1_type = 0*/
    _43SC1_type_55020 = 0LL;

    /** parser.e:2277		Expr()*/
    _43Expr();

    /** parser.e:2279		sequence temps = get_temps()*/
    _31780 = Repeat(_22024, 2LL);
    _0 = _temps_58406;
    _temps_58406 = _45get_temps(_31780);
    DeRef(_0);
    _31780 = NOVALUE;

    /** parser.e:2281		emit_op(IF)*/
    _45emit_op(20LL);

    /** parser.e:2282		prev_false = length(Code)+1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29200 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29200 = 1;
    }
    _prev_false_58396 = _29200 + 1;
    _29200 = NOVALUE;

    /** parser.e:2283		emit_forward_addr() -- to be patched*/
    _43emit_forward_addr();

    /** parser.e:2284		prev_false2=finish_block_header(IF)  -- 0*/
    _prev_false2_58397 = _43finish_block_header(20LL);
    if (!IS_ATOM_INT(_prev_false2_58397)) {
        _1 = (object)(DBL_PTR(_prev_false2_58397)->dbl);
        DeRefDS(_prev_false2_58397);
        _prev_false2_58397 = _1;
    }

    /** parser.e:2285		if SC1_type = OR then*/
    if (_43SC1_type_55020 != 9LL)
    goto L1; // [106] 159

    /** parser.e:2286			backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29204 = _43SC1_patch_55019 - 3LL;
    if ((object)((uintptr_t)_29204 +(uintptr_t) HIGH_BITS) >= 0){
        _29204 = NewDouble((eudouble)_29204);
    }
    _45backpatch(_29204, 147LL);
    _29204 = NOVALUE;

    /** parser.e:2287			if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L2; // [128] 139
    }
    else{
    }

    /** parser.e:2288				emit_op(NOP1)  -- to get label here*/
    _45emit_op(159LL);
L2: 

    /** parser.e:2290			backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29205 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29205 = 1;
    }
    _29206 = _29205 + 1;
    _29205 = NOVALUE;
    _45backpatch(_43SC1_patch_55019, _29206);
    _29206 = NOVALUE;
    goto L3; // [156] 192
L1: 

    /** parser.e:2291		elsif SC1_type = AND then*/
    if (_43SC1_type_55020 != 8LL)
    goto L4; // [165] 191

    /** parser.e:2292			backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29208 = _43SC1_patch_55019 - 3LL;
    if ((object)((uintptr_t)_29208 +(uintptr_t) HIGH_BITS) >= 0){
        _29208 = NewDouble((eudouble)_29208);
    }
    _45backpatch(_29208, 146LL);
    _29208 = NOVALUE;

    /** parser.e:2293			prev_false2 = SC1_patch*/
    _prev_false2_58397 = _43SC1_patch_55019;
L4: 
L3: 

    /** parser.e:2295		short_circuit -= 1*/
    _43short_circuit_55015 = _43short_circuit_55015 - 1LL;

    /** parser.e:2298		Statement_list()*/
    _43Statement_list();

    /** parser.e:2299		tok = next_token()*/
    _0 = _tok_58395;
    _tok_58395 = _43next_token();
    DeRef(_0);

    /** parser.e:2301		while tok[T_ID] = ELSIF do*/
L5: 
    _2 = (object)SEQ_PTR(_tok_58395);
    _29211 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29211, 414LL)){
        _29211 = NOVALUE;
        goto L6; // [222] 530
    }
    _29211 = NOVALUE;

    /** parser.e:2302			Sibling_block( IF )*/
    _64Sibling_block(20LL);

    /** parser.e:2305			emit_op(ELSE)*/
    _45emit_op(23LL);

    /** parser.e:2306			AppendEList(length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29213 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29213 = 1;
    }
    _29214 = _29213 + 1;
    _29213 = NOVALUE;
    _addr_inlined_AppendEList_at_260_58452 = _29214;
    _29214 = NOVALUE;

    /** parser.e:393		break_list = append(break_list, addr)*/
    Append(&_43break_list_55033, _43break_list_55033, _addr_inlined_AppendEList_at_260_58452);

    /** parser.e:394	end procedure*/
    goto L7; // [266] 269
L7: 

    /** parser.e:2307			break_delay &= 1*/
    Append(&_43break_delay_55034, _43break_delay_55034, 1LL);

    /** parser.e:2308			emit_forward_addr()  -- to be patched*/
    _43emit_forward_addr();

    /** parser.e:2309			if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L8; // [287] 298
    }
    else{
    }

    /** parser.e:2310				emit_op(NOP1)*/
    _45emit_op(159LL);
L8: 

    /** parser.e:2312			backpatch(prev_false, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29216 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29216 = 1;
    }
    _29217 = _29216 + 1;
    _29216 = NOVALUE;
    _45backpatch(_prev_false_58396, _29217);
    _29217 = NOVALUE;

    /** parser.e:2313			if prev_false2 != 0 then*/
    if (_prev_false2_58397 == 0LL)
    goto L9; // [315] 335

    /** parser.e:2314				backpatch(prev_false2, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29219 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29219 = 1;
    }
    _29220 = _29219 + 1;
    _29219 = NOVALUE;
    _45backpatch(_prev_false2_58397, _29220);
    _29220 = NOVALUE;
L9: 

    /** parser.e:2317			StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:2318			short_circuit += 1*/
    _43short_circuit_55015 = _43short_circuit_55015 + 1;

    /** parser.e:2319			short_circuit_B = FALSE*/
    _43short_circuit_B_55017 = _9FALSE_444;

    /** parser.e:2320			SC1_type = 0*/
    _43SC1_type_55020 = 0LL;

    /** parser.e:2322			push_temps( temps )*/
    RefDS(_temps_58406);
    _45push_temps(_temps_58406);

    /** parser.e:2323			Expr()*/
    _43Expr();

    /** parser.e:2325			temps = get_temps( temps )*/
    RefDS(_temps_58406);
    _0 = _temps_58406;
    _temps_58406 = _45get_temps(_temps_58406);
    DeRefDS(_0);

    /** parser.e:2327			emit_op(IF)*/
    _45emit_op(20LL);

    /** parser.e:2328			prev_false = length(Code)+1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29223 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29223 = 1;
    }
    _prev_false_58396 = _29223 + 1;
    _29223 = NOVALUE;

    /** parser.e:2329			prev_false2 = 0*/
    _prev_false2_58397 = 0LL;

    /** parser.e:2330			emit_forward_addr() -- to be patched*/
    _43emit_forward_addr();

    /** parser.e:2331			if SC1_type = OR then*/
    if (_43SC1_type_55020 != 9LL)
    goto LA; // [414] 467

    /** parser.e:2332				backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29226 = _43SC1_patch_55019 - 3LL;
    if ((object)((uintptr_t)_29226 +(uintptr_t) HIGH_BITS) >= 0){
        _29226 = NewDouble((eudouble)_29226);
    }
    _45backpatch(_29226, 147LL);
    _29226 = NOVALUE;

    /** parser.e:2333				if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto LB; // [436] 447
    }
    else{
    }

    /** parser.e:2334					emit_op(NOP1)*/
    _45emit_op(159LL);
LB: 

    /** parser.e:2336				backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29227 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29227 = 1;
    }
    _29228 = _29227 + 1;
    _29227 = NOVALUE;
    _45backpatch(_43SC1_patch_55019, _29228);
    _29228 = NOVALUE;
    goto LC; // [464] 500
LA: 

    /** parser.e:2337			elsif SC1_type = AND then*/
    if (_43SC1_type_55020 != 8LL)
    goto LD; // [473] 499

    /** parser.e:2338				backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29230 = _43SC1_patch_55019 - 3LL;
    if ((object)((uintptr_t)_29230 +(uintptr_t) HIGH_BITS) >= 0){
        _29230 = NewDouble((eudouble)_29230);
    }
    _45backpatch(_29230, 146LL);
    _29230 = NOVALUE;

    /** parser.e:2339				prev_false2 = SC1_patch*/
    _prev_false2_58397 = _43SC1_patch_55019;
LD: 
LC: 

    /** parser.e:2341			short_circuit -= 1*/
    _43short_circuit_55015 = _43short_circuit_55015 - 1LL;

    /** parser.e:2342			tok_match(THEN)*/
    _43tok_match(410LL, 0LL);

    /** parser.e:2345			Statement_list()*/
    _43Statement_list();

    /** parser.e:2346			tok = next_token()*/
    _0 = _tok_58395;
    _tok_58395 = _43next_token();
    DeRef(_0);

    /** parser.e:2347		end while*/
    goto L5; // [527] 214
L6: 

    /** parser.e:2349		if tok[T_ID] = ELSE or length(temps[1]) then*/
    _2 = (object)SEQ_PTR(_tok_58395);
    _29233 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_29233)) {
        _29234 = (_29233 == 23LL);
    }
    else {
        _29234 = binary_op(EQUALS, _29233, 23LL);
    }
    _29233 = NOVALUE;
    if (IS_ATOM_INT(_29234)) {
        if (_29234 != 0) {
            goto LE; // [544] 560
        }
    }
    else {
        if (DBL_PTR(_29234)->dbl != 0.0) {
            goto LE; // [544] 560
        }
    }
    _2 = (object)SEQ_PTR(_temps_58406);
    _29236 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_29236)){
            _29237 = SEQ_PTR(_29236)->length;
    }
    else {
        _29237 = 1;
    }
    _29236 = NOVALUE;
    if (_29237 == 0)
    {
        _29237 = NOVALUE;
        goto LF; // [556] 715
    }
    else{
        _29237 = NOVALUE;
    }
LE: 

    /** parser.e:2354			Sibling_block( IF )*/
    _64Sibling_block(20LL);

    /** parser.e:2356			StartSourceLine(FALSE, , COVERAGE_SUPPRESS )*/
    _45StartSourceLine(_9FALSE_444, 0LL, 1LL);

    /** parser.e:2357			emit_op(ELSE)*/
    _45emit_op(23LL);

    /** parser.e:2358			AppendEList(length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29238 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29238 = 1;
    }
    _29239 = _29238 + 1;
    _29238 = NOVALUE;
    _addr_inlined_AppendEList_at_624_58523 = _29239;
    _29239 = NOVALUE;

    /** parser.e:393		break_list = append(break_list, addr)*/
    Append(&_43break_list_55033, _43break_list_55033, _addr_inlined_AppendEList_at_624_58523);

    /** parser.e:394	end procedure*/
    goto L10; // [611] 614
L10: 

    /** parser.e:2359			break_delay &= 1*/
    Append(&_43break_delay_55034, _43break_delay_55034, 1LL);

    /** parser.e:2360			emit_forward_addr() -- to be patched*/
    _43emit_forward_addr();

    /** parser.e:2361			if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L11; // [632] 643
    }
    else{
    }

    /** parser.e:2362				emit_op(NOP1)*/
    _45emit_op(159LL);
L11: 

    /** parser.e:2364			backpatch(prev_false, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29241 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29241 = 1;
    }
    _29242 = _29241 + 1;
    _29241 = NOVALUE;
    _45backpatch(_prev_false_58396, _29242);
    _29242 = NOVALUE;

    /** parser.e:2365			if prev_false2 != 0 then*/
    if (_prev_false2_58397 == 0LL)
    goto L12; // [660] 680

    /** parser.e:2366				backpatch(prev_false2, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29244 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29244 = 1;
    }
    _29245 = _29244 + 1;
    _29244 = NOVALUE;
    _45backpatch(_prev_false2_58397, _29245);
    _29245 = NOVALUE;
L12: 

    /** parser.e:2369			push_temps( temps )*/
    RefDS(_temps_58406);
    _45push_temps(_temps_58406);

    /** parser.e:2371			if tok[T_ID] = ELSE then*/
    _2 = (object)SEQ_PTR(_tok_58395);
    _29246 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29246, 23LL)){
        _29246 = NOVALUE;
        goto L13; // [695] 706
    }
    _29246 = NOVALUE;

    /** parser.e:2372				Statement_list()*/
    _43Statement_list();
    goto L14; // [703] 773
L13: 

    /** parser.e:2374				putback(tok)*/
    Ref(_tok_58395);
    _43putback(_tok_58395);
    goto L14; // [712] 773
LF: 

    /** parser.e:2377			putback(tok)*/
    Ref(_tok_58395);
    _43putback(_tok_58395);

    /** parser.e:2378			if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L15; // [724] 735
    }
    else{
    }

    /** parser.e:2379				emit_op(NOP1)*/
    _45emit_op(159LL);
L15: 

    /** parser.e:2381			backpatch(prev_false, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29248 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29248 = 1;
    }
    _29249 = _29248 + 1;
    _29248 = NOVALUE;
    _45backpatch(_prev_false_58396, _29249);
    _29249 = NOVALUE;

    /** parser.e:2382			if prev_false2 != 0 then*/
    if (_prev_false2_58397 == 0LL)
    goto L16; // [752] 772

    /** parser.e:2383				backpatch(prev_false2, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29251 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29251 = 1;
    }
    _29252 = _29251 + 1;
    _29251 = NOVALUE;
    _45backpatch(_prev_false2_58397, _29252);
    _29252 = NOVALUE;
L16: 
L14: 

    /** parser.e:2387		tok_match(END)*/
    _43tok_match(402LL, 0LL);

    /** parser.e:2388		tok_match(IF, END)*/
    _43tok_match(20LL, 402LL);

    /** parser.e:2390		End_block( IF )*/
    _64End_block(20LL);

    /** parser.e:2392		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L17; // [802] 825
    }
    else{
    }

    /** parser.e:2393			if length(break_list) > elist_base then*/
    if (IS_SEQUENCE(_43break_list_55033)){
            _29253 = SEQ_PTR(_43break_list_55033)->length;
    }
    else {
        _29253 = 1;
    }
    if (_29253 <= _elist_base_58398)
    goto L18; // [812] 824

    /** parser.e:2394				emit_op(NOP1)  -- to emit label here*/
    _45emit_op(159LL);
L18: 
L17: 

    /** parser.e:2397		PatchEList(elist_base)*/
    _43PatchEList(_elist_base_58398);

    /** parser.e:2398		if_labels = if_labels[1..$-1]*/
    if (IS_SEQUENCE(_43if_labels_55044)){
            _29255 = SEQ_PTR(_43if_labels_55044)->length;
    }
    else {
        _29255 = 1;
    }
    _29256 = _29255 - 1LL;
    _29255 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43if_labels_55044;
    RHS_Slice(_43if_labels_55044, 1LL, _29256);

    /** parser.e:2399		block_index -= 1*/
    _43block_index_55046 = _43block_index_55046 - 1LL;

    /** parser.e:2400		if_stack = if_stack[1..$-1]*/
    if (IS_SEQUENCE(_43if_stack_55050)){
            _29259 = SEQ_PTR(_43if_stack_55050)->length;
    }
    else {
        _29259 = 1;
    }
    _29260 = _29259 - 1LL;
    _29259 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43if_stack_55050;
    RHS_Slice(_43if_stack_55050, 1LL, _29260);

    /** parser.e:2402	end procedure*/
    DeRef(_tok_58395);
    DeRef(_temps_58406);
    DeRef(_29234);
    _29234 = NOVALUE;
    _29236 = NOVALUE;
    _29260 = NOVALUE;
    _29256 = NOVALUE;
    return;
    ;
}


void _43exit_loop(object _exit_base_58583)
{
    object _29275 = NOVALUE;
    object _29274 = NOVALUE;
    object _29272 = NOVALUE;
    object _29271 = NOVALUE;
    object _29269 = NOVALUE;
    object _29268 = NOVALUE;
    object _29266 = NOVALUE;
    object _29265 = NOVALUE;
    object _29263 = NOVALUE;
    object _29262 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2405		PatchXList(exit_base)*/
    _43PatchXList(_exit_base_58583);

    /** parser.e:2406		loop_labels = loop_labels[1..$-1]*/
    if (IS_SEQUENCE(_43loop_labels_55043)){
            _29262 = SEQ_PTR(_43loop_labels_55043)->length;
    }
    else {
        _29262 = 1;
    }
    _29263 = _29262 - 1LL;
    _29262 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43loop_labels_55043;
    RHS_Slice(_43loop_labels_55043, 1LL, _29263);

    /** parser.e:2407		loop_stack = loop_stack[1..$-1]*/
    if (IS_SEQUENCE(_43loop_stack_55049)){
            _29265 = SEQ_PTR(_43loop_stack_55049)->length;
    }
    else {
        _29265 = 1;
    }
    _29266 = _29265 - 1LL;
    _29265 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43loop_stack_55049;
    RHS_Slice(_43loop_stack_55049, 1LL, _29266);

    /** parser.e:2408		continue_addr = continue_addr[1..$-1]*/
    if (IS_SEQUENCE(_43continue_addr_55040)){
            _29268 = SEQ_PTR(_43continue_addr_55040)->length;
    }
    else {
        _29268 = 1;
    }
    _29269 = _29268 - 1LL;
    _29268 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43continue_addr_55040;
    RHS_Slice(_43continue_addr_55040, 1LL, _29269);

    /** parser.e:2409		retry_addr = retry_addr[1..$-1]*/
    if (IS_SEQUENCE(_43retry_addr_55041)){
            _29271 = SEQ_PTR(_43retry_addr_55041)->length;
    }
    else {
        _29271 = 1;
    }
    _29272 = _29271 - 1LL;
    _29271 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43retry_addr_55041;
    RHS_Slice(_43retry_addr_55041, 1LL, _29272);

    /** parser.e:2410		entry_addr = entry_addr[1..$-1]*/
    if (IS_SEQUENCE(_43entry_addr_55039)){
            _29274 = SEQ_PTR(_43entry_addr_55039)->length;
    }
    else {
        _29274 = 1;
    }
    _29275 = _29274 - 1LL;
    _29274 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43entry_addr_55039;
    RHS_Slice(_43entry_addr_55039, 1LL, _29275);

    /** parser.e:2411		block_index -= 1*/
    _43block_index_55046 = _43block_index_55046 - 1LL;

    /** parser.e:2412	end procedure*/
    _29263 = NOVALUE;
    _29272 = NOVALUE;
    _29269 = NOVALUE;
    _29275 = NOVALUE;
    _29266 = NOVALUE;
    return;
    ;
}


void _43push_switch()
{
    object _new_1__tmp_at14_58606 = NOVALUE;
    object _new_inlined_new_at_14_58605 = NOVALUE;
    object _29279 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2415		if_stack &= SWITCH*/
    Append(&_43if_stack_55050, _43if_stack_55050, 185LL);

    /** parser.e:2416		switch_stack = append( switch_stack,*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at14_58606;
    _new_1__tmp_at14_58606 = _34new_map_seq(8LL);
    DeRef(_0);
    Ref(_new_1__tmp_at14_58606);
    _0 = _new_inlined_new_at_14_58605;
    _new_inlined_new_at_14_58605 = _35malloc(_new_1__tmp_at14_58606, 1LL);
    DeRef(_0);
    DeRef(_new_1__tmp_at14_58606);
    _new_1__tmp_at14_58606 = NOVALUE;
    _1 = NewS1(13);
    _2 = (object)((s1_ptr)_1)->base;
    RefDSn(_22024, 2);
    ((intptr_t*)_2)[1] = _22024;
    ((intptr_t*)_2)[2] = _22024;
    ((intptr_t*)_2)[3] = 0LL;
    ((intptr_t*)_2)[4] = 0LL;
    ((intptr_t*)_2)[5] = 0LL;
    ((intptr_t*)_2)[6] = 0LL;
    Ref(_new_inlined_new_at_14_58605);
    ((intptr_t*)_2)[7] = _new_inlined_new_at_14_58605;
    RefDS(_22024);
    ((intptr_t*)_2)[8] = _22024;
    ((intptr_t*)_2)[9] = 0LL;
    RefDSn(_22024, 4);
    ((intptr_t*)_2)[10] = _22024;
    ((intptr_t*)_2)[11] = _22024;
    ((intptr_t*)_2)[12] = _22024;
    ((intptr_t*)_2)[13] = _22024;
    _29279 = MAKE_SEQ(_1);
    RefDS(_29279);
    Append(&_43switch_stack_55264, _43switch_stack_55264, _29279);
    DeRefDS(_29279);
    _29279 = NOVALUE;

    /** parser.e:2433	end procedure*/
    return;
    ;
}


void _43pop_switch(object _break_base_58611)
{
    object _29294 = NOVALUE;
    object _29293 = NOVALUE;
    object _29291 = NOVALUE;
    object _29290 = NOVALUE;
    object _29288 = NOVALUE;
    object _29287 = NOVALUE;
    object _29285 = NOVALUE;
    object _29284 = NOVALUE;
    object _29283 = NOVALUE;
    object _29282 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2438		PatchEList( break_base )*/
    _43PatchEList(_break_base_58611);

    /** parser.e:2439		block_index -= 1*/
    _43block_index_55046 = _43block_index_55046 - 1LL;

    /** parser.e:2440		if length(switch_stack[$][SWITCH_CASES]) > 0 then*/
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _29282 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _29282 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55264);
    _29283 = (object)*(((s1_ptr)_2)->base + _29282);
    _2 = (object)SEQ_PTR(_29283);
    _29284 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29283 = NOVALUE;
    if (IS_SEQUENCE(_29284)){
            _29285 = SEQ_PTR(_29284)->length;
    }
    else {
        _29285 = 1;
    }
    _29284 = NOVALUE;
    if (_29285 <= 0LL)
    goto L1; // [34] 46

    /** parser.e:2441			End_block( CASE )*/
    _64End_block(186LL);
L1: 

    /** parser.e:2443		if_labels = if_labels[1..$-1]*/
    if (IS_SEQUENCE(_43if_labels_55044)){
            _29287 = SEQ_PTR(_43if_labels_55044)->length;
    }
    else {
        _29287 = 1;
    }
    _29288 = _29287 - 1LL;
    _29287 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43if_labels_55044;
    RHS_Slice(_43if_labels_55044, 1LL, _29288);

    /** parser.e:2444		if_stack  = if_stack[1..$-1]*/
    if (IS_SEQUENCE(_43if_stack_55050)){
            _29290 = SEQ_PTR(_43if_stack_55050)->length;
    }
    else {
        _29290 = 1;
    }
    _29291 = _29290 - 1LL;
    _29290 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43if_stack_55050;
    RHS_Slice(_43if_stack_55050, 1LL, _29291);

    /** parser.e:2445		switch_stack  = switch_stack[1..$-1]*/
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _29293 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _29293 = 1;
    }
    _29294 = _29293 - 1LL;
    _29293 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43switch_stack_55264;
    RHS_Slice(_43switch_stack_55264, 1LL, _29294);

    /** parser.e:2446	end procedure*/
    _29294 = NOVALUE;
    _29288 = NOVALUE;
    _29291 = NOVALUE;
    _29284 = NOVALUE;
    return;
    ;
}


void _43add_case(object _sym_58632, object _sign_58633)
{
    object _29341 = NOVALUE;
    object _29340 = NOVALUE;
    object _29339 = NOVALUE;
    object _29338 = NOVALUE;
    object _29337 = NOVALUE;
    object _29336 = NOVALUE;
    object _29334 = NOVALUE;
    object _29333 = NOVALUE;
    object _29332 = NOVALUE;
    object _29331 = NOVALUE;
    object _29329 = NOVALUE;
    object _29328 = NOVALUE;
    object _29327 = NOVALUE;
    object _29326 = NOVALUE;
    object _29324 = NOVALUE;
    object _29323 = NOVALUE;
    object _29322 = NOVALUE;
    object _29321 = NOVALUE;
    object _29320 = NOVALUE;
    object _29318 = NOVALUE;
    object _29317 = NOVALUE;
    object _29316 = NOVALUE;
    object _29315 = NOVALUE;
    object _29314 = NOVALUE;
    object _29313 = NOVALUE;
    object _29311 = NOVALUE;
    object _29310 = NOVALUE;
    object _29309 = NOVALUE;
    object _29308 = NOVALUE;
    object _29307 = NOVALUE;
    object _29306 = NOVALUE;
    object _29304 = NOVALUE;
    object _29303 = NOVALUE;
    object _29301 = NOVALUE;
    object _29300 = NOVALUE;
    object _29299 = NOVALUE;
    object _29298 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2450		if sign < 0 then*/
    if (_sign_58633 >= 0LL)
    goto L1; // [5] 15

    /** parser.e:2451			sym = -sym*/
    _0 = _sym_58632;
    if (IS_ATOM_INT(_sym_58632)) {
        if ((uintptr_t)_sym_58632 == (uintptr_t)HIGH_BITS){
            _sym_58632 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _sym_58632 = - _sym_58632;
        }
    }
    else {
        _sym_58632 = unary_op(UMINUS, _sym_58632);
    }
    DeRefi(_0);
L1: 

    /** parser.e:2454		if find(sym, switch_stack[$][SWITCH_CASES] ) = 0 then*/
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _29298 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _29298 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55264);
    _29299 = (object)*(((s1_ptr)_2)->base + _29298);
    _2 = (object)SEQ_PTR(_29299);
    _29300 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29299 = NOVALUE;
    _29301 = find_from(_sym_58632, _29300, 1LL);
    _29300 = NOVALUE;
    if (_29301 != 0LL)
    goto L2; // [35] 252

    /** parser.e:2455			switch_stack[$][SWITCH_CASES]            = append( switch_stack[$][SWITCH_CASES], sym )*/
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _29303 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _29303 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55264);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55264 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29303 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _29306 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _29306 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55264);
    _29307 = (object)*(((s1_ptr)_2)->base + _29306);
    _2 = (object)SEQ_PTR(_29307);
    _29308 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29307 = NOVALUE;
    Ref(_sym_58632);
    Append(&_29309, _29308, _sym_58632);
    _29308 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29309;
    if( _1 != _29309 ){
        DeRef(_1);
    }
    _29309 = NOVALUE;
    _29304 = NOVALUE;

    /** parser.e:2456			switch_stack[$][SWITCH_JUMP_TABLE]      &= length(Code) + 1*/
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _29310 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _29310 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55264);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55264 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29310 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_12Code_20315)){
            _29313 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29313 = 1;
    }
    _29314 = _29313 + 1;
    _29313 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29315 = (object)*(((s1_ptr)_2)->base + 2LL);
    _29311 = NOVALUE;
    if (IS_SEQUENCE(_29315) && IS_ATOM(_29314)) {
        Append(&_29316, _29315, _29314);
    }
    else if (IS_ATOM(_29315) && IS_SEQUENCE(_29314)) {
    }
    else {
        Concat((object_ptr)&_29316, _29315, _29314);
        _29315 = NOVALUE;
    }
    _29315 = NOVALUE;
    _29314 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29316;
    if( _1 != _29316 ){
        DeRef(_1);
    }
    _29316 = NOVALUE;
    _29311 = NOVALUE;

    /** parser.e:2457			switch_stack[$][SWITCH_THISLINE]        &= {ThisLine}*/
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _29317 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _29317 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55264);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55264 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29317 + ((s1_ptr)_2)->base);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_49ThisLine_49312);
    ((intptr_t*)_2)[1] = _49ThisLine_49312;
    _29320 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29321 = (object)*(((s1_ptr)_2)->base + 10LL);
    _29318 = NOVALUE;
    if (IS_SEQUENCE(_29321) && IS_ATOM(_29320)) {
    }
    else if (IS_ATOM(_29321) && IS_SEQUENCE(_29320)) {
        Ref(_29321);
        Prepend(&_29322, _29320, _29321);
    }
    else {
        Concat((object_ptr)&_29322, _29321, _29320);
        _29321 = NOVALUE;
    }
    _29321 = NOVALUE;
    DeRefDS(_29320);
    _29320 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29322;
    if( _1 != _29322 ){
        DeRef(_1);
    }
    _29322 = NOVALUE;
    _29318 = NOVALUE;

    /** parser.e:2458			switch_stack[$][SWITCH_BP]              &= bp*/
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _29323 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _29323 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55264);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55264 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29323 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29326 = (object)*(((s1_ptr)_2)->base + 11LL);
    _29324 = NOVALUE;
    if (IS_SEQUENCE(_29326) && IS_ATOM(_49bp_49316)) {
        Append(&_29327, _29326, _49bp_49316);
    }
    else if (IS_ATOM(_29326) && IS_SEQUENCE(_49bp_49316)) {
    }
    else {
        Concat((object_ptr)&_29327, _29326, _49bp_49316);
        _29326 = NOVALUE;
    }
    _29326 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29327;
    if( _1 != _29327 ){
        DeRef(_1);
    }
    _29327 = NOVALUE;
    _29324 = NOVALUE;

    /** parser.e:2459			switch_stack[$][SWITCH_LINE_NUMBER]     &= line_number*/
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _29328 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _29328 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55264);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55264 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29328 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29331 = (object)*(((s1_ptr)_2)->base + 12LL);
    _29329 = NOVALUE;
    if (IS_SEQUENCE(_29331) && IS_ATOM(_12line_number_20227)) {
        Append(&_29332, _29331, _12line_number_20227);
    }
    else if (IS_ATOM(_29331) && IS_SEQUENCE(_12line_number_20227)) {
    }
    else {
        Concat((object_ptr)&_29332, _29331, _12line_number_20227);
        _29331 = NOVALUE;
    }
    _29331 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29332;
    if( _1 != _29332 ){
        DeRef(_1);
    }
    _29332 = NOVALUE;
    _29329 = NOVALUE;

    /** parser.e:2460			switch_stack[$][SWITCH_CURRENT_FILE_NO] &= current_file_no*/
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _29333 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _29333 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55264);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55264 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29333 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29336 = (object)*(((s1_ptr)_2)->base + 13LL);
    _29334 = NOVALUE;
    if (IS_SEQUENCE(_29336) && IS_ATOM(_12current_file_no_20226)) {
        Append(&_29337, _29336, _12current_file_no_20226);
    }
    else if (IS_ATOM(_29336) && IS_SEQUENCE(_12current_file_no_20226)) {
    }
    else {
        Concat((object_ptr)&_29337, _29336, _12current_file_no_20226);
        _29336 = NOVALUE;
    }
    _29336 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 13LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29337;
    if( _1 != _29337 ){
        DeRef(_1);
    }
    _29337 = NOVALUE;
    _29334 = NOVALUE;

    /** parser.e:2462			if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L3; // [217] 262
    }
    else{
    }

    /** parser.e:2463				emit_addr( CASE )*/
    _45emit_addr(186LL);

    /** parser.e:2464				emit_addr( length( switch_stack[$][SWITCH_CASES] ) )*/
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _29338 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _29338 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55264);
    _29339 = (object)*(((s1_ptr)_2)->base + _29338);
    _2 = (object)SEQ_PTR(_29339);
    _29340 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29339 = NOVALUE;
    if (IS_SEQUENCE(_29340)){
            _29341 = SEQ_PTR(_29340)->length;
    }
    else {
        _29341 = 1;
    }
    _29340 = NOVALUE;
    _45emit_addr(_29341);
    _29341 = NOVALUE;
    goto L3; // [249] 262
L2: 

    /** parser.e:2467			CompileErr( DUPLICATE_CASE_VALUE_USED)*/
    RefDS(_22024);
    _49CompileErr(63LL, _22024, 0LL);
L3: 

    /** parser.e:2469	end procedure*/
    DeRef(_sym_58632);
    _29340 = NOVALUE;
    return;
    ;
}


void _43case_else()
{
    object _29349 = NOVALUE;
    object _29348 = NOVALUE;
    object _29346 = NOVALUE;
    object _29345 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2476		switch_stack[$][SWITCH_ELSE] = length(Code) + 1*/
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _29345 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _29345 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55264);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55264 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29345 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_12Code_20315)){
            _29348 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29348 = 1;
    }
    _29349 = _29348 + 1;
    _29348 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29349;
    if( _1 != _29349 ){
        DeRef(_1);
    }
    _29349 = NOVALUE;
    _29346 = NOVALUE;

    /** parser.e:2477		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L1; // [30] 46
    }
    else{
    }

    /** parser.e:2478			emit_addr( CASE )*/
    _45emit_addr(186LL);

    /** parser.e:2479			emit_addr( 0 )*/
    _45emit_addr(0LL);
L1: 

    /** parser.e:2482	end procedure*/
    return;
    ;
}


void _43Case_statement()
{
    object _else_case_2__tmp_at147_58756 = NOVALUE;
    object _else_case_1__tmp_at147_58755 = NOVALUE;
    object _else_case_inlined_else_case_at_147_58754 = NOVALUE;
    object _tok_58717 = NOVALUE;
    object _condition_58719 = NOVALUE;
    object _start_line_58749 = NOVALUE;
    object _sign_58761 = NOVALUE;
    object _fwd_58774 = NOVALUE;
    object _symi_58784 = NOVALUE;
    object _fwdref_58856 = NOVALUE;
    object _31779 = NOVALUE;
    object _29432 = NOVALUE;
    object _29431 = NOVALUE;
    object _29430 = NOVALUE;
    object _29429 = NOVALUE;
    object _29428 = NOVALUE;
    object _29427 = NOVALUE;
    object _29425 = NOVALUE;
    object _29424 = NOVALUE;
    object _29423 = NOVALUE;
    object _29421 = NOVALUE;
    object _29420 = NOVALUE;
    object _29419 = NOVALUE;
    object _29417 = NOVALUE;
    object _29414 = NOVALUE;
    object _29411 = NOVALUE;
    object _29410 = NOVALUE;
    object _29409 = NOVALUE;
    object _29408 = NOVALUE;
    object _29405 = NOVALUE;
    object _29404 = NOVALUE;
    object _29403 = NOVALUE;
    object _29402 = NOVALUE;
    object _29399 = NOVALUE;
    object _29398 = NOVALUE;
    object _29397 = NOVALUE;
    object _29396 = NOVALUE;
    object _29394 = NOVALUE;
    object _29393 = NOVALUE;
    object _29392 = NOVALUE;
    object _29390 = NOVALUE;
    object _29389 = NOVALUE;
    object _29388 = NOVALUE;
    object _29387 = NOVALUE;
    object _29386 = NOVALUE;
    object _29384 = NOVALUE;
    object _29383 = NOVALUE;
    object _29381 = NOVALUE;
    object _29380 = NOVALUE;
    object _29379 = NOVALUE;
    object _29378 = NOVALUE;
    object _29374 = NOVALUE;
    object _29373 = NOVALUE;
    object _29372 = NOVALUE;
    object _29369 = NOVALUE;
    object _29366 = NOVALUE;
    object _29363 = NOVALUE;
    object _29362 = NOVALUE;
    object _29361 = NOVALUE;
    object _29360 = NOVALUE;
    object _29359 = NOVALUE;
    object _29358 = NOVALUE;
    object _29357 = NOVALUE;
    object _29355 = NOVALUE;
    object _29354 = NOVALUE;
    object _29353 = NOVALUE;
    object _29352 = NOVALUE;
    object _29350 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2489		if not in_switch() then*/
    _29350 = _43in_switch();
    if (IS_ATOM_INT(_29350)) {
        if (_29350 != 0){
            DeRef(_29350);
            _29350 = NOVALUE;
            goto L1; // [6] 19
        }
    }
    else {
        if (DBL_PTR(_29350)->dbl != 0.0){
            DeRef(_29350);
            _29350 = NOVALUE;
            goto L1; // [6] 19
        }
    }
    DeRef(_29350);
    _29350 = NOVALUE;

    /** parser.e:2490			CompileErr( A_CASE_MUST_BE_INSIDE_A_SWITCH)*/
    RefDS(_22024);
    _49CompileErr(34LL, _22024, 0LL);
L1: 

    /** parser.e:2493		if length(switch_stack[$][SWITCH_CASES]) > 0 then*/
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _29352 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _29352 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55264);
    _29353 = (object)*(((s1_ptr)_2)->base + _29352);
    _2 = (object)SEQ_PTR(_29353);
    _29354 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29353 = NOVALUE;
    if (IS_SEQUENCE(_29354)){
            _29355 = SEQ_PTR(_29354)->length;
    }
    else {
        _29355 = 1;
    }
    _29354 = NOVALUE;
    if (_29355 <= 0LL)
    goto L2; // [37] 103

    /** parser.e:2495			Sibling_block( CASE )*/
    _64Sibling_block(186LL);

    /** parser.e:2497			if not switch_stack[$][SWITCH_FALLTHRU] and*/
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _29357 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _29357 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55264);
    _29358 = (object)*(((s1_ptr)_2)->base + _29357);
    _2 = (object)SEQ_PTR(_29358);
    _29359 = (object)*(((s1_ptr)_2)->base + 5LL);
    _29358 = NOVALUE;
    if (IS_ATOM_INT(_29359)) {
        _29360 = (_29359 == 0);
    }
    else {
        _29360 = unary_op(NOT, _29359);
    }
    _29359 = NOVALUE;
    if (IS_ATOM_INT(_29360)) {
        if (_29360 == 0) {
            goto L3; // [66] 112
        }
    }
    else {
        if (DBL_PTR(_29360)->dbl == 0.0) {
            goto L3; // [66] 112
        }
    }
    _29362 = (_43fallthru_case_58713 == 0);
    if (_29362 == 0)
    {
        DeRef(_29362);
        _29362 = NOVALUE;
        goto L3; // [76] 112
    }
    else{
        DeRef(_29362);
        _29362 = NOVALUE;
    }

    /** parser.e:2501				putback( {CASE, 0} )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 186LL;
    ((intptr_t *)_2)[2] = 0LL;
    _29363 = MAKE_SEQ(_1);
    _43putback(_29363);
    _29363 = NOVALUE;

    /** parser.e:2502				Break_statement()*/
    _43Break_statement();

    /** parser.e:2503				tok = next_token()*/
    _0 = _tok_58717;
    _tok_58717 = _43next_token();
    DeRef(_0);
    goto L3; // [100] 112
L2: 

    /** parser.e:2506			Start_block( CASE )*/
    _64Start_block(186LL, 0LL);
L3: 

    /** parser.e:2509		StartSourceLine(TRUE, , COVERAGE_SUPPRESS)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 1LL);

    /** parser.e:2511		fallthru_case = 0*/
    _43fallthru_case_58713 = 0LL;

    /** parser.e:2512		integer start_line = line_number*/
    _start_line_58749 = _12line_number_20227;

    /** parser.e:2513		while 1 do*/
L4: 

    /** parser.e:2515			if else_case() then*/

    /** parser.e:2472		return switch_stack[$][SWITCH_ELSE]*/
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _else_case_1__tmp_at147_58755 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _else_case_1__tmp_at147_58755 = 1;
    }
    DeRef(_else_case_2__tmp_at147_58756);
    _2 = (object)SEQ_PTR(_43switch_stack_55264);
    _else_case_2__tmp_at147_58756 = (object)*(((s1_ptr)_2)->base + _else_case_1__tmp_at147_58755);
    RefDS(_else_case_2__tmp_at147_58756);
    DeRef(_else_case_inlined_else_case_at_147_58754);
    _2 = (object)SEQ_PTR(_else_case_2__tmp_at147_58756);
    _else_case_inlined_else_case_at_147_58754 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_else_case_inlined_else_case_at_147_58754);
    DeRef(_else_case_2__tmp_at147_58756);
    _else_case_2__tmp_at147_58756 = NOVALUE;
    if (_else_case_inlined_else_case_at_147_58754 == 0) {
        goto L5; // [162] 175
    }
    else {
        if (!IS_ATOM_INT(_else_case_inlined_else_case_at_147_58754) && DBL_PTR(_else_case_inlined_else_case_at_147_58754)->dbl == 0.0){
            goto L5; // [162] 175
        }
    }

    /** parser.e:2516				CompileErr( A_CASE_BLOCK_CANNOT_FOLLOW_A_CASE_ELSE_BLOCK)*/
    RefDS(_22024);
    _49CompileErr(33LL, _22024, 0LL);
L5: 

    /** parser.e:2518			maybe_namespace()*/
    _61maybe_namespace();

    /** parser.e:2519			tok = next_token()*/
    _0 = _tok_58717;
    _tok_58717 = _43next_token();
    DeRef(_0);

    /** parser.e:2520			integer sign = 1*/
    _sign_58761 = 1LL;

    /** parser.e:2521			if tok[T_ID] = MINUS then*/
    _2 = (object)SEQ_PTR(_tok_58717);
    _29366 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29366, 10LL)){
        _29366 = NOVALUE;
        goto L6; // [199] 216
    }
    _29366 = NOVALUE;

    /** parser.e:2522				sign = -1*/
    _sign_58761 = -1LL;

    /** parser.e:2523				tok = next_token()*/
    _0 = _tok_58717;
    _tok_58717 = _43next_token();
    DeRef(_0);
    goto L7; // [213] 237
L6: 

    /** parser.e:2524			elsif tok[T_ID] = PLUS then*/
    _2 = (object)SEQ_PTR(_tok_58717);
    _29369 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29369, 11LL)){
        _29369 = NOVALUE;
        goto L8; // [226] 236
    }
    _29369 = NOVALUE;

    /** parser.e:2525				tok = next_token()*/
    _0 = _tok_58717;
    _tok_58717 = _43next_token();
    DeRef(_0);
L8: 
L7: 

    /** parser.e:2528			integer fwd*/

    /** parser.e:2529			if not find( tok[T_ID], {ATOM, STRING, ELSE} ) then*/
    _2 = (object)SEQ_PTR(_tok_58717);
    _29372 = (object)*(((s1_ptr)_2)->base + 1LL);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 502LL;
    ((intptr_t*)_2)[2] = 503LL;
    ((intptr_t*)_2)[3] = 23LL;
    _29373 = MAKE_SEQ(_1);
    _29374 = find_from(_29372, _29373, 1LL);
    _29372 = NOVALUE;
    DeRefDS(_29373);
    _29373 = NOVALUE;
    if (_29374 != 0)
    goto L9; // [264] 439
    _29374 = NOVALUE;

    /** parser.e:2531				integer symi = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_58717);
    _symi_58784 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_symi_58784)){
        _symi_58784 = (object)DBL_PTR(_symi_58784)->dbl;
    }

    /** parser.e:2532				fwd = -1*/
    _fwd_58774 = -1LL;

    /** parser.e:2533				if symi > 0 then*/
    if (_symi_58784 <= 0LL)
    goto LA; // [284] 434

    /** parser.e:2534					if find(tok[T_ID] , VAR_TOKS) then*/
    _2 = (object)SEQ_PTR(_tok_58717);
    _29378 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29379 = find_from(_29378, _29VAR_TOKS_12016, 1LL);
    _29378 = NOVALUE;
    if (_29379 == 0)
    {
        _29379 = NOVALUE;
        goto LB; // [303] 433
    }
    else{
        _29379 = NOVALUE;
    }

    /** parser.e:2535						if SymTab[symi][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29380 = (object)*(((s1_ptr)_2)->base + _symi_58784);
    _2 = (object)SEQ_PTR(_29380);
    _29381 = (object)*(((s1_ptr)_2)->base + 4LL);
    _29380 = NOVALUE;
    if (binary_op_a(NOTEQ, _29381, 9LL)){
        _29381 = NOVALUE;
        goto LC; // [322] 334
    }
    _29381 = NOVALUE;

    /** parser.e:2537							fwd = symi*/
    _fwd_58774 = _symi_58784;
    goto LD; // [331] 432
LC: 

    /** parser.e:2538						elsif SymTab[symi][S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29383 = (object)*(((s1_ptr)_2)->base + _symi_58784);
    _2 = (object)SEQ_PTR(_29383);
    _29384 = (object)*(((s1_ptr)_2)->base + 3LL);
    _29383 = NOVALUE;
    if (binary_op_a(NOTEQ, _29384, 2LL)){
        _29384 = NOVALUE;
        goto LE; // [350] 431
    }
    _29384 = NOVALUE;

    /** parser.e:2539							fwd = 0*/
    _fwd_58774 = 0LL;

    /** parser.e:2540							if SymTab[symi][S_CODE] then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29386 = (object)*(((s1_ptr)_2)->base + _symi_58784);
    _2 = (object)SEQ_PTR(_29386);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _29387 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _29387 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    _29386 = NOVALUE;
    if (_29387 == 0) {
        _29387 = NOVALUE;
        goto LF; // [373] 397
    }
    else {
        if (!IS_ATOM_INT(_29387) && DBL_PTR(_29387)->dbl == 0.0){
            _29387 = NOVALUE;
            goto LF; // [373] 397
        }
        _29387 = NOVALUE;
    }
    _29387 = NOVALUE;

    /** parser.e:2541								tok[T_SYM] = SymTab[symi][S_CODE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29388 = (object)*(((s1_ptr)_2)->base + _symi_58784);
    _2 = (object)SEQ_PTR(_29388);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _29389 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _29389 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    _29388 = NOVALUE;
    Ref(_29389);
    _2 = (object)SEQ_PTR(_tok_58717);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_58717 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29389;
    if( _1 != _29389 ){
        DeRef(_1);
    }
    _29389 = NOVALUE;
LF: 

    /** parser.e:2543							SymTab[symi][S_USAGE] = or_bits( SymTab[symi][S_USAGE], U_READ )*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_symi_58784 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29392 = (object)*(((s1_ptr)_2)->base + _symi_58784);
    _2 = (object)SEQ_PTR(_29392);
    _29393 = (object)*(((s1_ptr)_2)->base + 5LL);
    _29392 = NOVALUE;
    if (IS_ATOM_INT(_29393)) {
        {uintptr_t tu;
             tu = (uintptr_t)_29393 | (uintptr_t)1LL;
             _29394 = MAKE_UINT(tu);
        }
    }
    else {
        _29394 = binary_op(OR_BITS, _29393, 1LL);
    }
    _29393 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29394;
    if( _1 != _29394 ){
        DeRef(_1);
    }
    _29394 = NOVALUE;
    _29390 = NOVALUE;
LE: 
LD: 
LB: 
LA: 
    goto L10; // [436] 445
L9: 

    /** parser.e:2548				fwd = 0*/
    _fwd_58774 = 0LL;
L10: 

    /** parser.e:2551			if fwd < 0 then*/
    if (_fwd_58774 >= 0LL)
    goto L11; // [449] 477

    /** parser.e:2552				CompileErr( FOUND_1_BUT_EXPECTED_ELSE_AN_ATOM_STRING_CONSTANT_OR_ENUM, {find_category(tok[T_ID])})*/
    _2 = (object)SEQ_PTR(_tok_58717);
    _29396 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_29396);
    _29397 = _62find_category(_29396);
    _29396 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _29397;
    _29398 = MAKE_SEQ(_1);
    _29397 = NOVALUE;
    _49CompileErr(91LL, _29398, 0LL);
    _29398 = NOVALUE;
L11: 

    /** parser.e:2555			if tok[T_ID] = ELSE then*/
    _2 = (object)SEQ_PTR(_tok_58717);
    _29399 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29399, 23LL)){
        _29399 = NOVALUE;
        goto L12; // [487] 552
    }
    _29399 = NOVALUE;

    /** parser.e:2556				if sign = -1 then*/
    if (_sign_58761 != -1LL)
    goto L13; // [493] 507

    /** parser.e:2557					CompileErr( EXPECTED_AN_ATOM_STRING_OR_A_CONSTANT_ASSIGNED_AN_ATOM_OR_A_STRING)*/
    RefDS(_22024);
    _49CompileErr(71LL, _22024, 0LL);
L13: 

    /** parser.e:2559				if length(switch_stack[$][SWITCH_CASES]) = 0 then*/
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _29402 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _29402 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55264);
    _29403 = (object)*(((s1_ptr)_2)->base + _29402);
    _2 = (object)SEQ_PTR(_29403);
    _29404 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29403 = NOVALUE;
    if (IS_SEQUENCE(_29404)){
            _29405 = SEQ_PTR(_29404)->length;
    }
    else {
        _29405 = 1;
    }
    _29404 = NOVALUE;
    if (_29405 != 0LL)
    goto L14; // [525] 539

    /** parser.e:2560					CompileErr( CASE_ELSE_CANNOT_BE_FIRST_CASE_IN_SWITCH)*/
    RefDS(_22024);
    _49CompileErr(44LL, _22024, 0LL);
L14: 

    /** parser.e:2562				case_else()*/
    _43case_else();

    /** parser.e:2563				exit*/
    goto L15; // [547] 789
    goto L16; // [549] 623
L12: 

    /** parser.e:2565			elsif fwd then*/
    if (_fwd_58774 == 0)
    {
        goto L17; // [554] 606
    }
    else{
    }

    /** parser.e:2566				integer fwdref = new_forward_reference( CASE, fwd )*/
    DeRef(_31779);
    _31779 = 186LL;
    _fwdref_58856 = _42new_forward_reference(186LL, _fwd_58774, 186LL);
    _31779 = NOVALUE;
    if (!IS_ATOM_INT(_fwdref_58856)) {
        _1 = (object)(DBL_PTR(_fwdref_58856)->dbl);
        DeRefDS(_fwdref_58856);
        _fwdref_58856 = _1;
    }

    /** parser.e:2567				add_case( {fwdref}, sign )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _fwdref_58856;
    _29408 = MAKE_SEQ(_1);
    _43add_case(_29408, _sign_58761);
    _29408 = NOVALUE;

    /** parser.e:2568				fwd:set_data( fwdref, switch_stack[$][SWITCH_PC] )*/
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _29409 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _29409 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55264);
    _29410 = (object)*(((s1_ptr)_2)->base + _29409);
    _2 = (object)SEQ_PTR(_29410);
    _29411 = (object)*(((s1_ptr)_2)->base + 4LL);
    _29410 = NOVALUE;
    Ref(_29411);
    _42set_data(_fwdref_58856, _29411);
    _29411 = NOVALUE;
    goto L16; // [603] 623
L17: 

    /** parser.e:2571				condition = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_58717);
    _condition_58719 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_condition_58719)){
        _condition_58719 = (object)DBL_PTR(_condition_58719)->dbl;
    }

    /** parser.e:2572				add_case( condition, sign )*/
    _43add_case(_condition_58719, _sign_58761);
L16: 

    /** parser.e:2575			tok = next_token()*/
    _0 = _tok_58717;
    _tok_58717 = _43next_token();
    DeRef(_0);

    /** parser.e:2576			if tok[T_ID] = THEN then*/
    _2 = (object)SEQ_PTR(_tok_58717);
    _29414 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29414, 410LL)){
        _29414 = NOVALUE;
        goto L18; // [638] 742
    }
    _29414 = NOVALUE;

    /** parser.e:2577				tok = next_token()*/
    _0 = _tok_58717;
    _tok_58717 = _43next_token();
    DeRef(_0);

    /** parser.e:2579				if tok[T_ID] = CASE then*/
    _2 = (object)SEQ_PTR(_tok_58717);
    _29417 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29417, 186LL)){
        _29417 = NOVALUE;
        goto L19; // [657] 727
    }
    _29417 = NOVALUE;

    /** parser.e:2580					if switch_stack[$][SWITCH_FALLTHRU] then*/
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _29419 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _29419 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55264);
    _29420 = (object)*(((s1_ptr)_2)->base + _29419);
    _2 = (object)SEQ_PTR(_29420);
    _29421 = (object)*(((s1_ptr)_2)->base + 5LL);
    _29420 = NOVALUE;
    if (_29421 == 0) {
        _29421 = NOVALUE;
        goto L1A; // [676] 691
    }
    else {
        if (!IS_ATOM_INT(_29421) && DBL_PTR(_29421)->dbl == 0.0){
            _29421 = NOVALUE;
            goto L1A; // [676] 691
        }
        _29421 = NOVALUE;
    }
    _29421 = NOVALUE;

    /** parser.e:2581						start_line = line_number*/
    _start_line_58749 = _12line_number_20227;
    goto L1B; // [688] 782
L1A: 

    /** parser.e:2583						putback( tok )*/
    Ref(_tok_58717);
    _43putback(_tok_58717);

    /** parser.e:2584						Warning(220, empty_case_warning_flag,*/
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _29423 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    Ref(_29423);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _29423;
    ((intptr_t *)_2)[2] = _start_line_58749;
    _29424 = MAKE_SEQ(_1);
    _29423 = NOVALUE;
    _49Warning(220LL, 2048LL, _29424);
    _29424 = NOVALUE;

    /** parser.e:2586						exit*/
    goto L15; // [721] 789
    goto L1B; // [724] 782
L19: 

    /** parser.e:2589					putback( tok )*/
    Ref(_tok_58717);
    _43putback(_tok_58717);

    /** parser.e:2590					exit*/
    goto L15; // [736] 789
    goto L1B; // [739] 782
L18: 

    /** parser.e:2593			elsif tok[T_ID] != COMMA then*/
    _2 = (object)SEQ_PTR(_tok_58717);
    _29425 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _29425, -30LL)){
        _29425 = NOVALUE;
        goto L1C; // [752] 781
    }
    _29425 = NOVALUE;

    /** parser.e:2594				CompileErr(EXPECTED_THEN_OR__NOT_1,{LexName(tok[T_ID])})*/
    _2 = (object)SEQ_PTR(_tok_58717);
    _29427 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_29427);
    RefDS(_26412);
    _29428 = _45LexName(_29427, _26412);
    _29427 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _29428;
    _29429 = MAKE_SEQ(_1);
    _29428 = NOVALUE;
    _49CompileErr(66LL, _29429, 0LL);
    _29429 = NOVALUE;
L1C: 
L1B: 

    /** parser.e:2597		end while*/
    goto L4; // [786] 142
L15: 

    /** parser.e:2598		StartSourceLine( TRUE )*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:2599		emit_temp( switch_stack[$][SWITCH_VALUE], NEW_REFERENCE )*/
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _29430 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _29430 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55264);
    _29431 = (object)*(((s1_ptr)_2)->base + _29430);
    _2 = (object)SEQ_PTR(_29431);
    _29432 = (object)*(((s1_ptr)_2)->base + 6LL);
    _29431 = NOVALUE;
    Ref(_29432);
    _45emit_temp(_29432, 1LL);
    _29432 = NOVALUE;

    /** parser.e:2600		flush_temps()*/
    RefDS(_22024);
    _45flush_temps(_22024);

    /** parser.e:2601	end procedure*/
    DeRef(_tok_58717);
    _29354 = NOVALUE;
    _29404 = NOVALUE;
    DeRef(_29360);
    _29360 = NOVALUE;
    return;
    ;
}


void _43Fallthru_statement()
{
    object _29433 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2604		if not in_switch() then*/
    _29433 = _43in_switch();
    if (IS_ATOM_INT(_29433)) {
        if (_29433 != 0){
            DeRef(_29433);
            _29433 = NOVALUE;
            goto L1; // [6] 19
        }
    }
    else {
        if (DBL_PTR(_29433)->dbl != 0.0){
            DeRef(_29433);
            _29433 = NOVALUE;
            goto L1; // [6] 19
        }
    }
    DeRef(_29433);
    _29433 = NOVALUE;

    /** parser.e:2605			CompileErr( A_FALLTHRU_MUST_BE_INSIDE_A_SWITCH)*/
    RefDS(_22024);
    _49CompileErr(22LL, _22024, 0LL);
L1: 

    /** parser.e:2607		tok_match( CASE )*/
    _43tok_match(186LL, 0LL);

    /** parser.e:2608		fallthru_case = 1*/
    _43fallthru_case_58713 = 1LL;

    /** parser.e:2609		Case_statement()*/
    _43Case_statement();

    /** parser.e:2610	end procedure*/
    return;
    ;
}


void _43update_translator_info(object _sym_58925, object _all_ints_58926, object _has_integer_58927, object _has_atom_58928, object _has_sequence_58929)
{
    object _29458 = NOVALUE;
    object _29456 = NOVALUE;
    object _29454 = NOVALUE;
    object _29452 = NOVALUE;
    object _29450 = NOVALUE;
    object _29449 = NOVALUE;
    object _29447 = NOVALUE;
    object _29445 = NOVALUE;
    object _29444 = NOVALUE;
    object _29443 = NOVALUE;
    object _29442 = NOVALUE;
    object _29441 = NOVALUE;
    object _29439 = NOVALUE;
    object _29437 = NOVALUE;
    object _29435 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2615		SymTab[sym][S_MODE] = M_TEMP    -- override CONSTANT for compile*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_58925 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3LL;
    DeRef(_1);
    _29435 = NOVALUE;

    /** parser.e:2616		SymTab[sym][S_GTYPE] = TYPE_SEQUENCE*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_58925 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 8LL;
    DeRef(_1);
    _29437 = NOVALUE;

    /** parser.e:2617		SymTab[sym][S_SEQ_LEN] = length( SymTab[sym][S_OBJ] )*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_58925 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29441 = (object)*(((s1_ptr)_2)->base + _sym_58925);
    _2 = (object)SEQ_PTR(_29441);
    _29442 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29441 = NOVALUE;
    if (IS_SEQUENCE(_29442)){
            _29443 = SEQ_PTR(_29442)->length;
    }
    else {
        _29443 = 1;
    }
    _29442 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29443;
    if( _1 != _29443 ){
        DeRef(_1);
    }
    _29443 = NOVALUE;
    _29439 = NOVALUE;

    /** parser.e:2619		if SymTab[sym][S_SEQ_LEN] > 0 then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29444 = (object)*(((s1_ptr)_2)->base + _sym_58925);
    _2 = (object)SEQ_PTR(_29444);
    _29445 = (object)*(((s1_ptr)_2)->base + 32LL);
    _29444 = NOVALUE;
    if (binary_op_a(LESSEQ, _29445, 0LL)){
        _29445 = NOVALUE;
        goto L1; // [89] 198
    }
    _29445 = NOVALUE;

    /** parser.e:2620			if all_ints then*/
    if (_all_ints_58926 == 0)
    {
        goto L2; // [95] 118
    }
    else{
    }

    /** parser.e:2621				SymTab[sym][S_SEQ_ELEM] = TYPE_INTEGER*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_58925 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _29447 = NOVALUE;
    goto L3; // [115] 216
L2: 

    /** parser.e:2623			elsif has_atom + has_sequence + has_integer > 1 then*/
    _29449 = _has_atom_58928 + _has_sequence_58929;
    if ((object)((uintptr_t)_29449 + (uintptr_t)HIGH_BITS) >= 0){
        _29449 = NewDouble((eudouble)_29449);
    }
    if (IS_ATOM_INT(_29449)) {
        _29450 = _29449 + _has_integer_58927;
        if ((object)((uintptr_t)_29450 + (uintptr_t)HIGH_BITS) >= 0){
            _29450 = NewDouble((eudouble)_29450);
        }
    }
    else {
        _29450 = NewDouble(DBL_PTR(_29449)->dbl + (eudouble)_has_integer_58927);
    }
    DeRef(_29449);
    _29449 = NOVALUE;
    if (binary_op_a(LESSEQ, _29450, 1LL)){
        DeRef(_29450);
        _29450 = NOVALUE;
        goto L4; // [128] 152
    }
    DeRef(_29450);
    _29450 = NOVALUE;

    /** parser.e:2624				SymTab[sym][S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_58925 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);
    _29452 = NOVALUE;
    goto L3; // [149] 216
L4: 

    /** parser.e:2626			elsif has_atom then*/
    if (_has_atom_58928 == 0)
    {
        goto L5; // [154] 177
    }
    else{
    }

    /** parser.e:2627				SymTab[sym][S_SEQ_ELEM] = TYPE_ATOM*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_58925 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 4LL;
    DeRef(_1);
    _29454 = NOVALUE;
    goto L3; // [174] 216
L5: 

    /** parser.e:2630				SymTab[sym][S_SEQ_ELEM] = TYPE_SEQUENCE*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_58925 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 8LL;
    DeRef(_1);
    _29456 = NOVALUE;
    goto L3; // [195] 216
L1: 

    /** parser.e:2634			SymTab[sym][S_SEQ_ELEM] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_58925 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _29458 = NOVALUE;
L3: 

    /** parser.e:2636	end procedure*/
    _29442 = NOVALUE;
    return;
    ;
}


void _43optimize_switch(object _switch_pc_58990, object _else_bp_58991, object _cases_58992, object _jump_table_58993)
{
    object _values_58994 = NOVALUE;
    object _min_58998 = NOVALUE;
    object _max_59000 = NOVALUE;
    object _all_ints_59002 = NOVALUE;
    object _has_integer_59003 = NOVALUE;
    object _has_atom_59004 = NOVALUE;
    object _has_sequence_59005 = NOVALUE;
    object _has_unassigned_59006 = NOVALUE;
    object _has_fwdref_59007 = NOVALUE;
    object _unique_values_59008 = NOVALUE;
    object _unique_jumps_59010 = NOVALUE;
    object _new_1__tmp_at74_59013 = NOVALUE;
    object _new_inlined_new_at_74_59012 = NOVALUE;
    object _jump_59014 = NOVALUE;
    object _jump_offset_59018 = NOVALUE;
    object _sym_59025 = NOVALUE;
    object _sign_59027 = NOVALUE;
    object _value_i_59040 = NOVALUE;
    object _v_59064 = NOVALUE;
    object _else_target_59150 = NOVALUE;
    object _opcode_59153 = NOVALUE;
    object _delta_59159 = NOVALUE;
    object _switch_table_59169 = NOVALUE;
    object _offset_59172 = NOVALUE;
    object _29572 = NOVALUE;
    object _29571 = NOVALUE;
    object _29570 = NOVALUE;
    object _29569 = NOVALUE;
    object _29567 = NOVALUE;
    object _29565 = NOVALUE;
    object _29562 = NOVALUE;
    object _29561 = NOVALUE;
    object _29560 = NOVALUE;
    object _29559 = NOVALUE;
    object _29558 = NOVALUE;
    object _29557 = NOVALUE;
    object _29556 = NOVALUE;
    object _29553 = NOVALUE;
    object _29552 = NOVALUE;
    object _29551 = NOVALUE;
    object _29550 = NOVALUE;
    object _29549 = NOVALUE;
    object _29548 = NOVALUE;
    object _29544 = NOVALUE;
    object _29543 = NOVALUE;
    object _29541 = NOVALUE;
    object _29540 = NOVALUE;
    object _29539 = NOVALUE;
    object _29538 = NOVALUE;
    object _29537 = NOVALUE;
    object _29536 = NOVALUE;
    object _29535 = NOVALUE;
    object _29534 = NOVALUE;
    object _29533 = NOVALUE;
    object _29532 = NOVALUE;
    object _29530 = NOVALUE;
    object _29529 = NOVALUE;
    object _29525 = NOVALUE;
    object _29523 = NOVALUE;
    object _29522 = NOVALUE;
    object _29521 = NOVALUE;
    object _29519 = NOVALUE;
    object _29516 = NOVALUE;
    object _29515 = NOVALUE;
    object _29514 = NOVALUE;
    object _29512 = NOVALUE;
    object _29511 = NOVALUE;
    object _29510 = NOVALUE;
    object _29508 = NOVALUE;
    object _29507 = NOVALUE;
    object _29506 = NOVALUE;
    object _29504 = NOVALUE;
    object _29503 = NOVALUE;
    object _29502 = NOVALUE;
    object _29500 = NOVALUE;
    object _29497 = NOVALUE;
    object _29496 = NOVALUE;
    object _29495 = NOVALUE;
    object _29494 = NOVALUE;
    object _29493 = NOVALUE;
    object _29492 = NOVALUE;
    object _29491 = NOVALUE;
    object _29490 = NOVALUE;
    object _29489 = NOVALUE;
    object _29488 = NOVALUE;
    object _29487 = NOVALUE;
    object _29486 = NOVALUE;
    object _29483 = NOVALUE;
    object _29482 = NOVALUE;
    object _29481 = NOVALUE;
    object _29479 = NOVALUE;
    object _29478 = NOVALUE;
    object _29476 = NOVALUE;
    object _29475 = NOVALUE;
    object _29474 = NOVALUE;
    object _29470 = NOVALUE;
    object _29469 = NOVALUE;
    object _29468 = NOVALUE;
    object _29466 = NOVALUE;
    object _29465 = NOVALUE;
    object _29461 = NOVALUE;
    object _29460 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2641		sequence values = switch_stack[$][SWITCH_CASES]*/
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _29460 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _29460 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55264);
    _29461 = (object)*(((s1_ptr)_2)->base + _29460);
    DeRef(_values_58994);
    _2 = (object)SEQ_PTR(_29461);
    _values_58994 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_values_58994);
    _29461 = NOVALUE;

    /** parser.e:2642		atom min =  1e+300*/
    RefDS(_29463);
    DeRef(_min_58998);
    _min_58998 = _29463;

    /** parser.e:2643		atom max = -1e+300*/
    RefDS(_29464);
    DeRef(_max_59000);
    _max_59000 = _29464;

    /** parser.e:2644		integer all_ints = 1*/
    _all_ints_59002 = 1LL;

    /** parser.e:2645		integer has_integer    = 0*/
    _has_integer_59003 = 0LL;

    /** parser.e:2646		integer has_atom       = 0*/
    _has_atom_59004 = 0LL;

    /** parser.e:2647		integer has_sequence   = 0*/
    _has_sequence_59005 = 0LL;

    /** parser.e:2648		integer has_unassigned = 0*/
    _has_unassigned_59006 = 0LL;

    /** parser.e:2649		integer has_fwdref     = 0*/
    _has_fwdref_59007 = 0LL;

    /** parser.e:2650		sequence unique_values = {}*/
    RefDS(_22024);
    DeRef(_unique_values_59008);
    _unique_values_59008 = _22024;

    /** parser.e:2651		map unique_jumps = map:new()*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at74_59013;
    _new_1__tmp_at74_59013 = _34new_map_seq(8LL);
    DeRef(_0);
    Ref(_new_1__tmp_at74_59013);
    _0 = _unique_jumps_59010;
    _unique_jumps_59010 = _35malloc(_new_1__tmp_at74_59013, 1LL);
    DeRef(_0);
    DeRef(_new_1__tmp_at74_59013);
    _new_1__tmp_at74_59013 = NOVALUE;

    /** parser.e:2653		sequence jump = switch_stack[$][SWITCH_JUMP_TABLE]*/
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _29465 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _29465 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55264);
    _29466 = (object)*(((s1_ptr)_2)->base + _29465);
    DeRef(_jump_59014);
    _2 = (object)SEQ_PTR(_29466);
    _jump_59014 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_jump_59014);
    _29466 = NOVALUE;

    /** parser.e:2654		integer jump_offset = 0*/
    _jump_offset_59018 = 0LL;

    /** parser.e:2655		for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_58994)){
            _29468 = SEQ_PTR(_values_58994)->length;
    }
    else {
        _29468 = 1;
    }
    {
        object _i_59020;
        _i_59020 = 1LL;
L1: 
        if (_i_59020 > _29468){
            goto L2; // [116] 586
        }

        /** parser.e:2656			if sequence( values[i] ) then*/
        _2 = (object)SEQ_PTR(_values_58994);
        _29469 = (object)*(((s1_ptr)_2)->base + _i_59020);
        _29470 = IS_SEQUENCE(_29469);
        _29469 = NOVALUE;
        if (_29470 == 0)
        {
            _29470 = NOVALUE;
            goto L3; // [132] 145
        }
        else{
            _29470 = NOVALUE;
        }

        /** parser.e:2657				has_fwdref = 1*/
        _has_fwdref_59007 = 1LL;

        /** parser.e:2658				exit*/
        goto L2; // [142] 586
L3: 

        /** parser.e:2660			integer sym = values[i]*/
        _2 = (object)SEQ_PTR(_values_58994);
        _sym_59025 = (object)*(((s1_ptr)_2)->base + _i_59020);
        if (!IS_ATOM_INT(_sym_59025))
        _sym_59025 = (object)DBL_PTR(_sym_59025)->dbl;

        /** parser.e:2661			integer sign*/

        /** parser.e:2663			if sym < 0 then*/
        if (_sym_59025 >= 0LL)
        goto L4; // [155] 174

        /** parser.e:2664				sign = -1*/
        _sign_59027 = -1LL;

        /** parser.e:2665				sym = -sym*/
        _sym_59025 = - _sym_59025;
        goto L5; // [171] 180
L4: 

        /** parser.e:2667				sign = 1*/
        _sign_59027 = 1LL;
L5: 

        /** parser.e:2669			if not equal(SymTab[sym][S_OBJ], NOVALUE) then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _29474 = (object)*(((s1_ptr)_2)->base + _sym_59025);
        _2 = (object)SEQ_PTR(_29474);
        _29475 = (object)*(((s1_ptr)_2)->base + 1LL);
        _29474 = NOVALUE;
        if (_29475 == _12NOVALUE_20081)
        _29476 = 1;
        else if (IS_ATOM_INT(_29475) && IS_ATOM_INT(_12NOVALUE_20081))
        _29476 = 0;
        else
        _29476 = (compare(_29475, _12NOVALUE_20081) == 0);
        _29475 = NOVALUE;
        if (_29476 != 0)
        goto L6; // [200] 565
        _29476 = NOVALUE;

        /** parser.e:2670				object value_i = sign * SymTab[sym][S_OBJ]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _29478 = (object)*(((s1_ptr)_2)->base + _sym_59025);
        _2 = (object)SEQ_PTR(_29478);
        _29479 = (object)*(((s1_ptr)_2)->base + 1LL);
        _29478 = NOVALUE;
        DeRef(_value_i_59040);
        if (IS_ATOM_INT(_29479)) {
            {
                int128_t p128 = (int128_t)_sign_59027 * (int128_t)_29479;
                if( p128 != (int128_t)(_value_i_59040 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                    _value_i_59040 = NewDouble( (eudouble)p128 );
                }
            }
        }
        else {
            _value_i_59040 = binary_op(MULTIPLY, _sign_59027, _29479);
        }
        _29479 = NOVALUE;

        /** parser.e:2671				values[i] = value_i*/
        Ref(_value_i_59040);
        _2 = (object)SEQ_PTR(_values_58994);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _values_58994 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_59020);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _value_i_59040;
        DeRef(_1);

        /** parser.e:2672				if TRANSLATE then*/
        if (_12TRANSLATE_19834 == 0)
        {
            goto L7; // [233] 274
        }
        else{
        }

        /** parser.e:2673					if Code[jump[i]-2] = CASE then*/
        _2 = (object)SEQ_PTR(_jump_59014);
        _29481 = (object)*(((s1_ptr)_2)->base + _i_59020);
        if (IS_ATOM_INT(_29481)) {
            _29482 = _29481 - 2LL;
        }
        else {
            _29482 = binary_op(MINUS, _29481, 2LL);
        }
        _29481 = NOVALUE;
        _2 = (object)SEQ_PTR(_12Code_20315);
        if (!IS_ATOM_INT(_29482)){
            _29483 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29482)->dbl));
        }
        else{
            _29483 = (object)*(((s1_ptr)_2)->base + _29482);
        }
        if (binary_op_a(NOTEQ, _29483, 186LL)){
            _29483 = NOVALUE;
            goto L8; // [254] 267
        }
        _29483 = NOVALUE;

        /** parser.e:2674						jump_offset -=2*/
        _jump_offset_59018 = _jump_offset_59018 - 2LL;
        goto L9; // [264] 273
L8: 

        /** parser.e:2676						jump_offset = 0*/
        _jump_offset_59018 = 0LL;
L9: 
L7: 

        /** parser.e:2680				if find( value_i, map:get( unique_jumps, jump[i] + jump_offset, {}) ) then*/
        _2 = (object)SEQ_PTR(_jump_59014);
        _29486 = (object)*(((s1_ptr)_2)->base + _i_59020);
        if (IS_ATOM_INT(_29486)) {
            _29487 = _29486 + _jump_offset_59018;
            if ((object)((uintptr_t)_29487 + (uintptr_t)HIGH_BITS) >= 0){
                _29487 = NewDouble((eudouble)_29487);
            }
        }
        else {
            _29487 = binary_op(PLUS, _29486, _jump_offset_59018);
        }
        _29486 = NOVALUE;
        Ref(_unique_jumps_59010);
        RefDS(_22024);
        _29488 = _34get(_unique_jumps_59010, _29487, _22024);
        _29487 = NOVALUE;
        _29489 = find_from(_value_i_59040, _29488, 1LL);
        DeRef(_29488);
        _29488 = NOVALUE;
        if (_29489 == 0)
        {
            _29489 = NOVALUE;
            goto LA; // [295] 301
        }
        else{
            _29489 = NOVALUE;
        }
        goto LB; // [298] 560
LA: 

        /** parser.e:2683				elsif find( value_i, unique_values ) then*/
        _29490 = find_from(_value_i_59040, _unique_values_59008, 1LL);
        if (_29490 == 0)
        {
            _29490 = NOVALUE;
            goto LC; // [308] 467
        }
        else{
            _29490 = NOVALUE;
        }

        /** parser.e:2686					object v = ""*/
        RefDS(_22024);
        DeRef(_v_59064);
        _v_59064 = _22024;

        /** parser.e:2687					if length( SymTab[sym] ) > S_NAME and sequence( sym_name( sym ) ) then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _29491 = (object)*(((s1_ptr)_2)->base + _sym_59025);
        if (IS_SEQUENCE(_29491)){
                _29492 = SEQ_PTR(_29491)->length;
        }
        else {
            _29492 = 1;
        }
        _29491 = NOVALUE;
        if (IS_ATOM_INT(_12S_NAME_19864)) {
            _29493 = (_29492 > _12S_NAME_19864);
        }
        else {
            _29493 = binary_op(GREATER, _29492, _12S_NAME_19864);
        }
        _29492 = NOVALUE;
        if (IS_ATOM_INT(_29493)) {
            if (_29493 == 0) {
                goto LD; // [333] 359
            }
        }
        else {
            if (DBL_PTR(_29493)->dbl == 0.0) {
                goto LD; // [333] 359
            }
        }
        _29495 = _53sym_name(_sym_59025);
        _29496 = IS_SEQUENCE(_29495);
        DeRef(_29495);
        _29495 = NOVALUE;
        if (_29496 == 0)
        {
            _29496 = NOVALUE;
            goto LD; // [345] 359
        }
        else{
            _29496 = NOVALUE;
        }

        /** parser.e:2688						v = sym_name( sym ) & " = " */
        _29497 = _53sym_name(_sym_59025);
        if (IS_SEQUENCE(_29497) && IS_ATOM(_29498)) {
        }
        else if (IS_ATOM(_29497) && IS_SEQUENCE(_29498)) {
            Ref(_29497);
            Prepend(&_v_59064, _29498, _29497);
        }
        else {
            Concat((object_ptr)&_v_59064, _29497, _29498);
            DeRef(_29497);
            _29497 = NOVALUE;
        }
        DeRef(_29497);
        _29497 = NOVALUE;
LD: 

        /** parser.e:2691					v &= sprint( value_i )*/
        Ref(_value_i_59040);
        _29500 = _18sprint(_value_i_59040);
        if (IS_SEQUENCE(_v_59064) && IS_ATOM(_29500)) {
            Ref(_29500);
            Append(&_v_59064, _v_59064, _29500);
        }
        else if (IS_ATOM(_v_59064) && IS_SEQUENCE(_29500)) {
            Ref(_v_59064);
            Prepend(&_v_59064, _29500, _v_59064);
        }
        else {
            Concat((object_ptr)&_v_59064, _v_59064, _29500);
        }
        DeRef(_29500);
        _29500 = NOVALUE;

        /** parser.e:2692					ThisLine        = switch_stack[$][SWITCH_THISLINE][i]*/
        if (IS_SEQUENCE(_43switch_stack_55264)){
                _29502 = SEQ_PTR(_43switch_stack_55264)->length;
        }
        else {
            _29502 = 1;
        }
        _2 = (object)SEQ_PTR(_43switch_stack_55264);
        _29503 = (object)*(((s1_ptr)_2)->base + _29502);
        _2 = (object)SEQ_PTR(_29503);
        _29504 = (object)*(((s1_ptr)_2)->base + 10LL);
        _29503 = NOVALUE;
        DeRef(_49ThisLine_49312);
        _2 = (object)SEQ_PTR(_29504);
        _49ThisLine_49312 = (object)*(((s1_ptr)_2)->base + _i_59020);
        Ref(_49ThisLine_49312);
        _29504 = NOVALUE;

        /** parser.e:2693					bp              = switch_stack[$][SWITCH_BP][i]*/
        if (IS_SEQUENCE(_43switch_stack_55264)){
                _29506 = SEQ_PTR(_43switch_stack_55264)->length;
        }
        else {
            _29506 = 1;
        }
        _2 = (object)SEQ_PTR(_43switch_stack_55264);
        _29507 = (object)*(((s1_ptr)_2)->base + _29506);
        _2 = (object)SEQ_PTR(_29507);
        _29508 = (object)*(((s1_ptr)_2)->base + 11LL);
        _29507 = NOVALUE;
        _2 = (object)SEQ_PTR(_29508);
        _49bp_49316 = (object)*(((s1_ptr)_2)->base + _i_59020);
        if (!IS_ATOM_INT(_49bp_49316)){
            _49bp_49316 = (object)DBL_PTR(_49bp_49316)->dbl;
        }
        _29508 = NOVALUE;

        /** parser.e:2694					line_number     = switch_stack[$][SWITCH_LINE_NUMBER][i]*/
        if (IS_SEQUENCE(_43switch_stack_55264)){
                _29510 = SEQ_PTR(_43switch_stack_55264)->length;
        }
        else {
            _29510 = 1;
        }
        _2 = (object)SEQ_PTR(_43switch_stack_55264);
        _29511 = (object)*(((s1_ptr)_2)->base + _29510);
        _2 = (object)SEQ_PTR(_29511);
        _29512 = (object)*(((s1_ptr)_2)->base + 12LL);
        _29511 = NOVALUE;
        _2 = (object)SEQ_PTR(_29512);
        _12line_number_20227 = (object)*(((s1_ptr)_2)->base + _i_59020);
        if (!IS_ATOM_INT(_12line_number_20227)){
            _12line_number_20227 = (object)DBL_PTR(_12line_number_20227)->dbl;
        }
        _29512 = NOVALUE;

        /** parser.e:2695					current_file_no = switch_stack[$][SWITCH_CURRENT_FILE_NO][i]*/
        if (IS_SEQUENCE(_43switch_stack_55264)){
                _29514 = SEQ_PTR(_43switch_stack_55264)->length;
        }
        else {
            _29514 = 1;
        }
        _2 = (object)SEQ_PTR(_43switch_stack_55264);
        _29515 = (object)*(((s1_ptr)_2)->base + _29514);
        _2 = (object)SEQ_PTR(_29515);
        _29516 = (object)*(((s1_ptr)_2)->base + 13LL);
        _29515 = NOVALUE;
        _2 = (object)SEQ_PTR(_29516);
        _12current_file_no_20226 = (object)*(((s1_ptr)_2)->base + _i_59020);
        if (!IS_ATOM_INT(_12current_file_no_20226)){
            _12current_file_no_20226 = (object)DBL_PTR(_12current_file_no_20226)->dbl;
        }
        _29516 = NOVALUE;

        /** parser.e:2697					CompileErr("duplicate case value used in switch: [1]", {v})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_v_59064);
        ((intptr_t*)_2)[1] = _v_59064;
        _29519 = MAKE_SEQ(_1);
        RefDS(_29518);
        _49CompileErr(_29518, _29519, 0LL);
        _29519 = NOVALUE;
        DeRefDS(_v_59064);
        _v_59064 = NOVALUE;
        goto LB; // [464] 560
LC: 

        /** parser.e:2700					unique_values   &= value_i*/
        if (IS_SEQUENCE(_unique_values_59008) && IS_ATOM(_value_i_59040)) {
            Ref(_value_i_59040);
            Append(&_unique_values_59008, _unique_values_59008, _value_i_59040);
        }
        else if (IS_ATOM(_unique_values_59008) && IS_SEQUENCE(_value_i_59040)) {
        }
        else {
            Concat((object_ptr)&_unique_values_59008, _unique_values_59008, _value_i_59040);
        }

        /** parser.e:2701					map:put( unique_jumps, jump[i] + jump_offset, value_i, map:APPEND )*/
        _2 = (object)SEQ_PTR(_jump_59014);
        _29521 = (object)*(((s1_ptr)_2)->base + _i_59020);
        if (IS_ATOM_INT(_29521)) {
            _29522 = _29521 + _jump_offset_59018;
            if ((object)((uintptr_t)_29522 + (uintptr_t)HIGH_BITS) >= 0){
                _29522 = NewDouble((eudouble)_29522);
            }
        }
        else {
            _29522 = binary_op(PLUS, _29521, _jump_offset_59018);
        }
        _29521 = NOVALUE;
        Ref(_unique_jumps_59010);
        Ref(_value_i_59040);
        _34put(_unique_jumps_59010, _29522, _value_i_59040, 6LL, 0LL);
        _29522 = NOVALUE;

        /** parser.e:2703					if not is_integer( value_i ) then*/
        Ref(_value_i_59040);
        _29523 = _12is_integer(_value_i_59040);
        if (IS_ATOM_INT(_29523)) {
            if (_29523 != 0){
                DeRef(_29523);
                _29523 = NOVALUE;
                goto LE; // [496] 529
            }
        }
        else {
            if (DBL_PTR(_29523)->dbl != 0.0){
                DeRef(_29523);
                _29523 = NOVALUE;
                goto LE; // [496] 529
            }
        }
        DeRef(_29523);
        _29523 = NOVALUE;

        /** parser.e:2704						all_ints = 0*/
        _all_ints_59002 = 0LL;

        /** parser.e:2705						if atom( value_i ) then*/
        _29525 = IS_ATOM(_value_i_59040);
        if (_29525 == 0)
        {
            _29525 = NOVALUE;
            goto LF; // [509] 520
        }
        else{
            _29525 = NOVALUE;
        }

        /** parser.e:2706							has_atom = 1*/
        _has_atom_59004 = 1LL;
        goto L10; // [517] 559
LF: 

        /** parser.e:2708							has_sequence = 1*/
        _has_sequence_59005 = 1LL;
        goto L10; // [526] 559
LE: 

        /** parser.e:2711						has_integer = 1*/
        _has_integer_59003 = 1LL;

        /** parser.e:2713						if value_i < min then*/
        if (binary_op_a(GREATEREQ, _value_i_59040, _min_58998)){
            goto L11; // [536] 546
        }

        /** parser.e:2714							min = value_i*/
        Ref(_value_i_59040);
        DeRef(_min_58998);
        _min_58998 = _value_i_59040;
L11: 

        /** parser.e:2717						if value_i > max then*/
        if (binary_op_a(LESSEQ, _value_i_59040, _max_59000)){
            goto L12; // [548] 558
        }

        /** parser.e:2718							max = value_i*/
        Ref(_value_i_59040);
        DeRef(_max_59000);
        _max_59000 = _value_i_59040;
L12: 
L10: 
LB: 
        DeRef(_value_i_59040);
        _value_i_59040 = NOVALUE;
        goto L13; // [562] 577
L6: 

        /** parser.e:2723				has_unassigned = 1*/
        _has_unassigned_59006 = 1LL;

        /** parser.e:2724				exit*/
        goto L2; // [574] 586
L13: 

        /** parser.e:2726		end for*/
        _i_59020 = _i_59020 + 1LL;
        goto L1; // [581] 123
L2: 
        ;
    }

    /** parser.e:2728		if has_unassigned or has_fwdref then*/
    if (_has_unassigned_59006 != 0) {
        goto L14; // [588] 597
    }
    if (_has_fwdref_59007 == 0)
    {
        goto L15; // [593] 615
    }
    else{
    }
L14: 

    /** parser.e:2729			values = switch_stack[$][SWITCH_CASES]*/
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _29529 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _29529 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55264);
    _29530 = (object)*(((s1_ptr)_2)->base + _29529);
    DeRef(_values_58994);
    _2 = (object)SEQ_PTR(_29530);
    _values_58994 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_values_58994);
    _29530 = NOVALUE;
L15: 

    /** parser.e:2732		if switch_stack[$][SWITCH_ELSE] then*/
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _29532 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _29532 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55264);
    _29533 = (object)*(((s1_ptr)_2)->base + _29532);
    _2 = (object)SEQ_PTR(_29533);
    _29534 = (object)*(((s1_ptr)_2)->base + 3LL);
    _29533 = NOVALUE;
    if (_29534 == 0) {
        _29534 = NOVALUE;
        goto L16; // [630] 657
    }
    else {
        if (!IS_ATOM_INT(_29534) && DBL_PTR(_29534)->dbl == 0.0){
            _29534 = NOVALUE;
            goto L16; // [630] 657
        }
        _29534 = NOVALUE;
    }
    _29534 = NOVALUE;

    /** parser.e:2733				Code[else_bp] = switch_stack[$][SWITCH_ELSE]*/
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _29535 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _29535 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55264);
    _29536 = (object)*(((s1_ptr)_2)->base + _29535);
    _2 = (object)SEQ_PTR(_29536);
    _29537 = (object)*(((s1_ptr)_2)->base + 3LL);
    _29536 = NOVALUE;
    Ref(_29537);
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _else_bp_58991);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29537;
    if( _1 != _29537 ){
        DeRef(_1);
    }
    _29537 = NOVALUE;
    goto L17; // [654] 681
L16: 

    /** parser.e:2736			Code[else_bp] = length(Code) + 1 + TRANSLATE*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29538 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29538 = 1;
    }
    _29539 = _29538 + 1;
    _29538 = NOVALUE;
    _29540 = _29539 + _12TRANSLATE_19834;
    _29539 = NOVALUE;
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _else_bp_58991);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29540;
    if( _1 != _29540 ){
        DeRef(_1);
    }
    _29540 = NOVALUE;
L17: 

    /** parser.e:2739		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L18; // [685] 712
    }
    else{
    }

    /** parser.e:2744			SymTab[cases][S_OBJ] &= 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_cases_58992 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29543 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29541 = NOVALUE;
    if (IS_SEQUENCE(_29543) && IS_ATOM(0LL)) {
        Append(&_29544, _29543, 0LL);
    }
    else if (IS_ATOM(_29543) && IS_SEQUENCE(0LL)) {
    }
    else {
        Concat((object_ptr)&_29544, _29543, 0LL);
        _29543 = NOVALUE;
    }
    _29543 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29544;
    if( _1 != _29544 ){
        DeRef(_1);
    }
    _29544 = NOVALUE;
    _29541 = NOVALUE;
L18: 

    /** parser.e:2748		integer else_target = Code[else_bp]*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    _else_target_59150 = (object)*(((s1_ptr)_2)->base + _else_bp_58991);
    if (!IS_ATOM_INT(_else_target_59150)){
        _else_target_59150 = (object)DBL_PTR(_else_target_59150)->dbl;
    }

    /** parser.e:2749		integer opcode = SWITCH*/
    _opcode_59153 = 185LL;

    /** parser.e:2750		if has_unassigned or has_fwdref then*/
    if (_has_unassigned_59006 != 0) {
        goto L19; // [733] 742
    }
    if (_has_fwdref_59007 == 0)
    {
        goto L1A; // [738] 754
    }
    else{
    }
L19: 

    /** parser.e:2751			opcode = SWITCH_RT*/
    _opcode_59153 = 202LL;
    goto L1B; // [751] 907
L1A: 

    /** parser.e:2753		elsif all_ints then*/
    if (_all_ints_59002 == 0)
    {
        goto L1C; // [756] 904
    }
    else{
    }

    /** parser.e:2754			atom delta = max - min*/
    DeRef(_delta_59159);
    if (IS_ATOM_INT(_max_59000) && IS_ATOM_INT(_min_58998)) {
        _delta_59159 = _max_59000 - _min_58998;
        if ((object)((uintptr_t)_delta_59159 +(uintptr_t) HIGH_BITS) >= 0){
            _delta_59159 = NewDouble((eudouble)_delta_59159);
        }
    }
    else {
        if (IS_ATOM_INT(_max_59000)) {
            _delta_59159 = NewDouble((eudouble)_max_59000 - DBL_PTR(_min_58998)->dbl);
        }
        else {
            if (IS_ATOM_INT(_min_58998)) {
                _delta_59159 = NewDouble(DBL_PTR(_max_59000)->dbl - (eudouble)_min_58998);
            }
            else
            _delta_59159 = NewDouble(DBL_PTR(_max_59000)->dbl - DBL_PTR(_min_58998)->dbl);
        }
    }

    /** parser.e:2755			if not TRANSLATE and  delta < 1024 and delta >= 0 then*/
    _29548 = (_12TRANSLATE_19834 == 0);
    if (_29548 == 0) {
        _29549 = 0;
        goto L1D; // [772] 784
    }
    if (IS_ATOM_INT(_delta_59159)) {
        _29550 = (_delta_59159 < 1024LL);
    }
    else {
        _29550 = (DBL_PTR(_delta_59159)->dbl < (eudouble)1024LL);
    }
    _29549 = (_29550 != 0);
L1D: 
    if (_29549 == 0) {
        goto L1E; // [784] 893
    }
    if (IS_ATOM_INT(_delta_59159)) {
        _29552 = (_delta_59159 >= 0LL);
    }
    else {
        _29552 = (DBL_PTR(_delta_59159)->dbl >= (eudouble)0LL);
    }
    if (_29552 == 0)
    {
        DeRef(_29552);
        _29552 = NOVALUE;
        goto L1E; // [793] 893
    }
    else{
        DeRef(_29552);
        _29552 = NOVALUE;
    }

    /** parser.e:2756				opcode = SWITCH_SPI*/
    _opcode_59153 = 192LL;

    /** parser.e:2758				sequence switch_table = repeat( else_target, delta + 1 )*/
    if (IS_ATOM_INT(_delta_59159)) {
        _29553 = _delta_59159 + 1;
    }
    else
    _29553 = binary_op(PLUS, 1, _delta_59159);
    DeRef(_switch_table_59169);
    _switch_table_59169 = Repeat(_else_target_59150, _29553);
    DeRef(_29553);
    _29553 = NOVALUE;

    /** parser.e:2759				integer offset = min - 1*/
    if (IS_ATOM_INT(_min_58998)) {
        _offset_59172 = _min_58998 - 1LL;
    }
    else {
        _offset_59172 = NewDouble(DBL_PTR(_min_58998)->dbl - (eudouble)1LL);
    }
    if (!IS_ATOM_INT(_offset_59172)) {
        _1 = (object)(DBL_PTR(_offset_59172)->dbl);
        DeRefDS(_offset_59172);
        _offset_59172 = _1;
    }

    /** parser.e:2760				for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_58994)){
            _29556 = SEQ_PTR(_values_58994)->length;
    }
    else {
        _29556 = 1;
    }
    {
        object _i_59175;
        _i_59175 = 1LL;
L1F: 
        if (_i_59175 > _29556){
            goto L20; // [828] 860
        }

        /** parser.e:2761					switch_table[values[i] - offset] = jump[i]*/
        _2 = (object)SEQ_PTR(_values_58994);
        _29557 = (object)*(((s1_ptr)_2)->base + _i_59175);
        if (IS_ATOM_INT(_29557)) {
            _29558 = _29557 - _offset_59172;
            if ((object)((uintptr_t)_29558 +(uintptr_t) HIGH_BITS) >= 0){
                _29558 = NewDouble((eudouble)_29558);
            }
        }
        else {
            _29558 = binary_op(MINUS, _29557, _offset_59172);
        }
        _29557 = NOVALUE;
        _2 = (object)SEQ_PTR(_jump_59014);
        _29559 = (object)*(((s1_ptr)_2)->base + _i_59175);
        Ref(_29559);
        _2 = (object)SEQ_PTR(_switch_table_59169);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _switch_table_59169 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_29558))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_29558)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _29558);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _29559;
        if( _1 != _29559 ){
            DeRef(_1);
        }
        _29559 = NOVALUE;

        /** parser.e:2762				end for*/
        _i_59175 = _i_59175 + 1LL;
        goto L1F; // [855] 835
L20: 
        ;
    }

    /** parser.e:2763				Code[switch_pc + 2] = offset*/
    _29560 = _switch_pc_58990 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _29560);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _offset_59172;
    DeRef(_1);

    /** parser.e:2764				switch_stack[$][SWITCH_JUMP_TABLE] = switch_table*/
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _29561 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _29561 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55264);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55264 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29561 + ((s1_ptr)_2)->base);
    RefDS(_switch_table_59169);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _switch_table_59169;
    DeRef(_1);
    _29562 = NOVALUE;
    DeRefDS(_switch_table_59169);
    _switch_table_59169 = NOVALUE;
    goto L21; // [890] 903
L1E: 

    /** parser.e:2766				opcode = SWITCH_I*/
    _opcode_59153 = 193LL;
L21: 
L1C: 
    DeRef(_delta_59159);
    _delta_59159 = NOVALUE;
L1B: 

    /** parser.e:2770		Code[switch_pc] = opcode*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _switch_pc_58990);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _opcode_59153;
    DeRef(_1);

    /** parser.e:2771		if opcode != SWITCH_SPI then*/
    if (_opcode_59153 == 192LL)
    goto L22; // [919] 956

    /** parser.e:2772			SymTab[cases][S_OBJ] = values*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_cases_58992 + ((s1_ptr)_2)->base);
    RefDS(_values_58994);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _values_58994;
    DeRef(_1);
    _29565 = NOVALUE;

    /** parser.e:2773			if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L23; // [942] 955
    }
    else{
    }

    /** parser.e:2774				update_translator_info( cases, all_ints, has_integer, has_atom, has_sequence )*/
    _43update_translator_info(_cases_58992, _all_ints_59002, _has_integer_59003, _has_atom_59004, _has_sequence_59005);
L23: 
L22: 

    /** parser.e:2779		SymTab[jump_table][S_OBJ] = switch_stack[$][SWITCH_JUMP_TABLE] - switch_pc*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_jump_table_58993 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _29569 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _29569 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55264);
    _29570 = (object)*(((s1_ptr)_2)->base + _29569);
    _2 = (object)SEQ_PTR(_29570);
    _29571 = (object)*(((s1_ptr)_2)->base + 2LL);
    _29570 = NOVALUE;
    if (IS_ATOM_INT(_29571)) {
        _29572 = _29571 - _switch_pc_58990;
        if ((object)((uintptr_t)_29572 +(uintptr_t) HIGH_BITS) >= 0){
            _29572 = NewDouble((eudouble)_29572);
        }
    }
    else {
        _29572 = binary_op(MINUS, _29571, _switch_pc_58990);
    }
    _29571 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29572;
    if( _1 != _29572 ){
        DeRef(_1);
    }
    _29572 = NOVALUE;
    _29567 = NOVALUE;

    /** parser.e:2781	end procedure*/
    DeRef(_values_58994);
    DeRef(_min_58998);
    DeRef(_max_59000);
    DeRef(_unique_values_59008);
    DeRef(_unique_jumps_59010);
    DeRef(_jump_59014);
    DeRef(_29560);
    _29560 = NOVALUE;
    _29491 = NOVALUE;
    DeRef(_29550);
    _29550 = NOVALUE;
    DeRef(_29493);
    _29493 = NOVALUE;
    DeRef(_29482);
    _29482 = NOVALUE;
    DeRef(_29548);
    _29548 = NOVALUE;
    DeRef(_29558);
    _29558 = NOVALUE;
    return;
    ;
}


void _43Switch_statement()
{
    object _else_case_2__tmp_at250_59269 = NOVALUE;
    object _else_case_1__tmp_at250_59268 = NOVALUE;
    object _else_case_inlined_else_case_at_250_59267 = NOVALUE;
    object _break_base_59207 = NOVALUE;
    object _cases_59209 = NOVALUE;
    object _jump_table_59210 = NOVALUE;
    object _else_bp_59211 = NOVALUE;
    object _switch_pc_59212 = NOVALUE;
    object _t_59249 = NOVALUE;
    object _29604 = NOVALUE;
    object _29603 = NOVALUE;
    object _29601 = NOVALUE;
    object _29600 = NOVALUE;
    object _29599 = NOVALUE;
    object _29595 = NOVALUE;
    object _29591 = NOVALUE;
    object _29590 = NOVALUE;
    object _29588 = NOVALUE;
    object _29587 = NOVALUE;
    object _29585 = NOVALUE;
    object _29584 = NOVALUE;
    object _29582 = NOVALUE;
    object _29581 = NOVALUE;
    object _29580 = NOVALUE;
    object _29579 = NOVALUE;
    object _29578 = NOVALUE;
    object _29577 = NOVALUE;
    object _29575 = NOVALUE;
    object _29574 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2786		integer else_bp*/

    /** parser.e:2787		integer switch_pc*/

    /** parser.e:2789		push_switch()*/
    _43push_switch();

    /** parser.e:2790		break_base = length(break_list)*/
    if (IS_SEQUENCE(_43break_list_55033)){
            _break_base_59207 = SEQ_PTR(_43break_list_55033)->length;
    }
    else {
        _break_base_59207 = 1;
    }

    /** parser.e:2792		Expr()*/
    _43Expr();

    /** parser.e:2793		switch_stack[$][SWITCH_VALUE] = Top()*/
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _29574 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _29574 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55264);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55264 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29574 + ((s1_ptr)_2)->base);
    _29577 = _45Top();
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29577;
    if( _1 != _29577 ){
        DeRef(_1);
    }
    _29577 = NOVALUE;
    _29575 = NOVALUE;

    /** parser.e:2794		clear_temp( switch_stack[$][SWITCH_VALUE] )*/
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _29578 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _29578 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55264);
    _29579 = (object)*(((s1_ptr)_2)->base + _29578);
    _2 = (object)SEQ_PTR(_29579);
    _29580 = (object)*(((s1_ptr)_2)->base + 6LL);
    _29579 = NOVALUE;
    Ref(_29580);
    _45clear_temp(_29580);
    _29580 = NOVALUE;

    /** parser.e:2796		cases = NewStringSym( {-1, length(SymTab) } )*/
    if (IS_SEQUENCE(_13SymTab_11316)){
            _29581 = SEQ_PTR(_13SymTab_11316)->length;
    }
    else {
        _29581 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1LL;
    ((intptr_t *)_2)[2] = _29581;
    _29582 = MAKE_SEQ(_1);
    _29581 = NOVALUE;
    _cases_59209 = _53NewStringSym(_29582);
    _29582 = NOVALUE;
    if (!IS_ATOM_INT(_cases_59209)) {
        _1 = (object)(DBL_PTR(_cases_59209)->dbl);
        DeRefDS(_cases_59209);
        _cases_59209 = _1;
    }

    /** parser.e:2798		emit_opnd( cases )*/
    _45emit_opnd(_cases_59209);

    /** parser.e:2800		jump_table = NewStringSym( {-2, length(SymTab) } )*/
    if (IS_SEQUENCE(_13SymTab_11316)){
            _29584 = SEQ_PTR(_13SymTab_11316)->length;
    }
    else {
        _29584 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -2LL;
    ((intptr_t *)_2)[2] = _29584;
    _29585 = MAKE_SEQ(_1);
    _29584 = NOVALUE;
    _jump_table_59210 = _53NewStringSym(_29585);
    _29585 = NOVALUE;
    if (!IS_ATOM_INT(_jump_table_59210)) {
        _1 = (object)(DBL_PTR(_jump_table_59210)->dbl);
        DeRefDS(_jump_table_59210);
        _jump_table_59210 = _1;
    }

    /** parser.e:2801		emit_opnd( jump_table )*/
    _45emit_opnd(_jump_table_59210);

    /** parser.e:2803		if finish_block_header(SWITCH) then end if*/
    _29587 = _43finish_block_header(185LL);
    if (_29587 == 0) {
        DeRef(_29587);
        _29587 = NOVALUE;
        goto L1; // [109] 113
    }
    else {
        if (!IS_ATOM_INT(_29587) && DBL_PTR(_29587)->dbl == 0.0){
            DeRef(_29587);
            _29587 = NOVALUE;
            goto L1; // [109] 113
        }
        DeRef(_29587);
        _29587 = NOVALUE;
    }
    DeRef(_29587);
    _29587 = NOVALUE;
L1: 

    /** parser.e:2805		switch_pc = length(Code) + 1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29588 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29588 = 1;
    }
    _switch_pc_59212 = _29588 + 1;
    _29588 = NOVALUE;

    /** parser.e:2806		switch_stack[$][SWITCH_PC] = switch_pc*/
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _29590 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _29590 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55264);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55264 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29590 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _switch_pc_59212;
    DeRef(_1);
    _29591 = NOVALUE;

    /** parser.e:2808		emit_op(SWITCH)*/
    _45emit_op(185LL);

    /** parser.e:2809		emit_forward_addr()  -- the else*/
    _43emit_forward_addr();

    /** parser.e:2810		else_bp = length( Code )*/
    if (IS_SEQUENCE(_12Code_20315)){
            _else_bp_59211 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _else_bp_59211 = 1;
    }

    /** parser.e:2813		t = next_token()*/
    _0 = _t_59249;
    _t_59249 = _43next_token();
    DeRef(_0);

    /** parser.e:2814		if t[T_ID] = CASE then*/
    _2 = (object)SEQ_PTR(_t_59249);
    _29595 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29595, 186LL)){
        _29595 = NOVALUE;
        goto L2; // [173] 188
    }
    _29595 = NOVALUE;

    /** parser.e:2816			Case_statement()*/
    _43Case_statement();

    /** parser.e:2818			Statement_list()*/
    _43Statement_list();
    goto L3; // [185] 194
L2: 

    /** parser.e:2821			putback(t)*/
    Ref(_t_59249);
    _43putback(_t_59249);
L3: 

    /** parser.e:2824		optimize_switch( switch_pc, else_bp, cases, jump_table )*/
    _43optimize_switch(_switch_pc_59212, _else_bp_59211, _cases_59209, _jump_table_59210);

    /** parser.e:2825		tok_match(END)*/
    _43tok_match(402LL, 0LL);

    /** parser.e:2826		tok_match(SWITCH, END)*/
    _43tok_match(185LL, 402LL);

    /** parser.e:2827		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L4; // [224] 235
    }
    else{
    }

    /** parser.e:2828			emit_op(NOPSWITCH)*/
    _45emit_op(187LL);
L4: 

    /** parser.e:2831		if not else_case() then*/

    /** parser.e:2472		return switch_stack[$][SWITCH_ELSE]*/
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _else_case_1__tmp_at250_59268 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _else_case_1__tmp_at250_59268 = 1;
    }
    DeRef(_else_case_2__tmp_at250_59269);
    _2 = (object)SEQ_PTR(_43switch_stack_55264);
    _else_case_2__tmp_at250_59269 = (object)*(((s1_ptr)_2)->base + _else_case_1__tmp_at250_59268);
    RefDS(_else_case_2__tmp_at250_59269);
    DeRef(_else_case_inlined_else_case_at_250_59267);
    _2 = (object)SEQ_PTR(_else_case_2__tmp_at250_59269);
    _else_case_inlined_else_case_at_250_59267 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_else_case_inlined_else_case_at_250_59267);
    DeRef(_else_case_2__tmp_at250_59269);
    _else_case_2__tmp_at250_59269 = NOVALUE;
    if (IS_ATOM_INT(_else_case_inlined_else_case_at_250_59267)) {
        if (_else_case_inlined_else_case_at_250_59267 != 0){
            goto L5; // [255] 327
        }
    }
    else {
        if (DBL_PTR(_else_case_inlined_else_case_at_250_59267)->dbl != 0.0){
            goto L5; // [255] 327
        }
    }

    /** parser.e:2832			if not TRANSLATE then*/
    if (_12TRANSLATE_19834 != 0)
    goto L6; // [262] 303

    /** parser.e:2833				StartSourceLine( TRUE, , COVERAGE_SUPPRESS )*/
    _45StartSourceLine(_9TRUE_446, 0LL, 1LL);

    /** parser.e:2834				emit_temp( switch_stack[$][SWITCH_VALUE], NEW_REFERENCE )*/
    if (IS_SEQUENCE(_43switch_stack_55264)){
            _29599 = SEQ_PTR(_43switch_stack_55264)->length;
    }
    else {
        _29599 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55264);
    _29600 = (object)*(((s1_ptr)_2)->base + _29599);
    _2 = (object)SEQ_PTR(_29600);
    _29601 = (object)*(((s1_ptr)_2)->base + 6LL);
    _29600 = NOVALUE;
    Ref(_29601);
    _45emit_temp(_29601, 1LL);
    _29601 = NOVALUE;

    /** parser.e:2835				flush_temps()*/
    RefDS(_22024);
    _45flush_temps(_22024);
L6: 

    /** parser.e:2838			Warning(221, no_case_else_warning_flag,*/
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _29603 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    Ref(_29603);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _29603;
    ((intptr_t *)_2)[2] = _12line_number_20227;
    _29604 = MAKE_SEQ(_1);
    _29603 = NOVALUE;
    _49Warning(221LL, 4096LL, _29604);
    _29604 = NOVALUE;
L5: 

    /** parser.e:2841		pop_switch( break_base )*/
    _43pop_switch(_break_base_59207);

    /** parser.e:2842	end procedure*/
    DeRef(_t_59249);
    return;
    ;
}


object _43get_private_uninitialized()
{
    object _uninitialized_59293 = NOVALUE;
    object _s_59299 = NOVALUE;
    object _pu_59305 = NOVALUE;
    object _29621 = NOVALUE;
    object _29619 = NOVALUE;
    object _29618 = NOVALUE;
    object _29617 = NOVALUE;
    object _29616 = NOVALUE;
    object _29615 = NOVALUE;
    object _29614 = NOVALUE;
    object _29613 = NOVALUE;
    object _29612 = NOVALUE;
    object _29611 = NOVALUE;
    object _29610 = NOVALUE;
    object _29609 = NOVALUE;
    object _29606 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2845		sequence uninitialized = {}*/
    RefDS(_22024);
    DeRefi(_uninitialized_59293);
    _uninitialized_59293 = _22024;

    /** parser.e:2846		if CurrentSub != TopLevelSub then*/
    if (_12CurrentSub_20234 == _12TopLevelSub_20233)
    goto L1; // [14] 149

    /** parser.e:2847			symtab_pointer s = SymTab[CurrentSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29606 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_29606);
    _s_59299 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_59299)){
        _s_59299 = (object)DBL_PTR(_s_59299)->dbl;
    }
    _29606 = NOVALUE;

    /** parser.e:2848			sequence pu = { SC_PRIVATE, SC_UNDEFINED }*/
    DeRefi(_pu_59305);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 3LL;
    ((intptr_t *)_2)[2] = 9LL;
    _pu_59305 = MAKE_SEQ(_1);

    /** parser.e:2849			while s and find( SymTab[s][S_SCOPE], pu ) do*/
L2: 
    if (_s_59299 == 0) {
        goto L3; // [51] 148
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29610 = (object)*(((s1_ptr)_2)->base + _s_59299);
    _2 = (object)SEQ_PTR(_29610);
    _29611 = (object)*(((s1_ptr)_2)->base + 4LL);
    _29610 = NOVALUE;
    _29612 = find_from(_29611, _pu_59305, 1LL);
    _29611 = NOVALUE;
    if (_29612 == 0)
    {
        _29612 = NOVALUE;
        goto L3; // [73] 148
    }
    else{
        _29612 = NOVALUE;
    }

    /** parser.e:2850				if SymTab[s][S_SCOPE] = SC_PRIVATE and SymTab[s][S_INITLEVEL] = -1 then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29613 = (object)*(((s1_ptr)_2)->base + _s_59299);
    _2 = (object)SEQ_PTR(_29613);
    _29614 = (object)*(((s1_ptr)_2)->base + 4LL);
    _29613 = NOVALUE;
    if (IS_ATOM_INT(_29614)) {
        _29615 = (_29614 == 3LL);
    }
    else {
        _29615 = binary_op(EQUALS, _29614, 3LL);
    }
    _29614 = NOVALUE;
    if (IS_ATOM_INT(_29615)) {
        if (_29615 == 0) {
            goto L4; // [96] 127
        }
    }
    else {
        if (DBL_PTR(_29615)->dbl == 0.0) {
            goto L4; // [96] 127
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29617 = (object)*(((s1_ptr)_2)->base + _s_59299);
    _2 = (object)SEQ_PTR(_29617);
    _29618 = (object)*(((s1_ptr)_2)->base + 14LL);
    _29617 = NOVALUE;
    if (IS_ATOM_INT(_29618)) {
        _29619 = (_29618 == -1LL);
    }
    else {
        _29619 = binary_op(EQUALS, _29618, -1LL);
    }
    _29618 = NOVALUE;
    if (_29619 == 0) {
        DeRef(_29619);
        _29619 = NOVALUE;
        goto L4; // [117] 127
    }
    else {
        if (!IS_ATOM_INT(_29619) && DBL_PTR(_29619)->dbl == 0.0){
            DeRef(_29619);
            _29619 = NOVALUE;
            goto L4; // [117] 127
        }
        DeRef(_29619);
        _29619 = NOVALUE;
    }
    DeRef(_29619);
    _29619 = NOVALUE;

    /** parser.e:2851					uninitialized &= s*/
    Append(&_uninitialized_59293, _uninitialized_59293, _s_59299);
L4: 

    /** parser.e:2853				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29621 = (object)*(((s1_ptr)_2)->base + _s_59299);
    _2 = (object)SEQ_PTR(_29621);
    _s_59299 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_59299)){
        _s_59299 = (object)DBL_PTR(_s_59299)->dbl;
    }
    _29621 = NOVALUE;

    /** parser.e:2854			end while*/
    goto L2; // [145] 51
L3: 
L1: 
    DeRefi(_pu_59305);
    _pu_59305 = NOVALUE;

    /** parser.e:2856		return uninitialized*/
    DeRef(_29615);
    _29615 = NOVALUE;
    return _uninitialized_59293;
    ;
}


void _43While_statement()
{
    object _bp1_59336 = NOVALUE;
    object _bp2_59337 = NOVALUE;
    object _exit_base_59338 = NOVALUE;
    object _next_base_59339 = NOVALUE;
    object _uninitialized_59340 = NOVALUE;
    object _temps_59410 = NOVALUE;
    object _29657 = NOVALUE;
    object _29656 = NOVALUE;
    object _29655 = NOVALUE;
    object _29651 = NOVALUE;
    object _29650 = NOVALUE;
    object _29648 = NOVALUE;
    object _29646 = NOVALUE;
    object _29645 = NOVALUE;
    object _29644 = NOVALUE;
    object _29640 = NOVALUE;
    object _29638 = NOVALUE;
    object _29636 = NOVALUE;
    object _29630 = NOVALUE;
    object _29628 = NOVALUE;
    object _29627 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2865		sequence uninitialized = get_private_uninitialized()*/
    _0 = _uninitialized_59340;
    _uninitialized_59340 = _43get_private_uninitialized();
    DeRef(_0);

    /** parser.e:2867		entry_stack = append( entry_stack, uninitialized )*/
    RefDS(_uninitialized_59340);
    Append(&_43entry_stack_55042, _43entry_stack_55042, _uninitialized_59340);

    /** parser.e:2869		Start_block( WHILE )*/
    _64Start_block(47LL, 0LL);

    /** parser.e:2871		exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_43exit_list_55035)){
            _exit_base_59338 = SEQ_PTR(_43exit_list_55035)->length;
    }
    else {
        _exit_base_59338 = 1;
    }

    /** parser.e:2872		next_base = length(continue_list)*/
    if (IS_SEQUENCE(_43continue_list_55037)){
            _next_base_59339 = SEQ_PTR(_43continue_list_55037)->length;
    }
    else {
        _next_base_59339 = 1;
    }

    /** parser.e:2873		entry_addr &= length(Code)+1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29627 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29627 = 1;
    }
    _29628 = _29627 + 1;
    _29627 = NOVALUE;
    Append(&_43entry_addr_55039, _43entry_addr_55039, _29628);
    _29628 = NOVALUE;

    /** parser.e:2874		emit_op(NOP2) -- Entry_statement may patch this later*/
    _45emit_op(110LL);

    /** parser.e:2875		emit_addr(0)*/
    _45emit_addr(0LL);

    /** parser.e:2876		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L1; // [71] 82
    }
    else{
    }

    /** parser.e:2877			emit_op(NOPWHILE)*/
    _45emit_op(158LL);
L1: 

    /** parser.e:2879		bp1 = length(Code)+1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29630 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29630 = 1;
    }
    _bp1_59336 = _29630 + 1;
    _29630 = NOVALUE;

    /** parser.e:2880		continue_addr &= bp1*/
    Append(&_43continue_addr_55040, _43continue_addr_55040, _bp1_59336);

    /** parser.e:2881		short_circuit += 1*/
    _43short_circuit_55015 = _43short_circuit_55015 + 1;

    /** parser.e:2882		short_circuit_B = FALSE*/
    _43short_circuit_B_55017 = _9FALSE_444;

    /** parser.e:2883		SC1_type = 0*/
    _43SC1_type_55020 = 0LL;

    /** parser.e:2884		Expr()*/
    _43Expr();

    /** parser.e:2885		optimized_while = FALSE*/
    _45optimized_while_51022 = _9FALSE_444;

    /** parser.e:2886		emit_op(WHILE)*/
    _45emit_op(47LL);

    /** parser.e:2887		short_circuit -= 1*/
    _43short_circuit_55015 = _43short_circuit_55015 - 1LL;

    /** parser.e:2888		if not optimized_while then*/
    if (_45optimized_while_51022 != 0)
    goto L2; // [153] 174

    /** parser.e:2890			bp2 = length(Code)+1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29636 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29636 = 1;
    }
    _bp2_59337 = _29636 + 1;
    _29636 = NOVALUE;

    /** parser.e:2891			emit_forward_addr() -- will be patched*/
    _43emit_forward_addr();
    goto L3; // [171] 180
L2: 

    /** parser.e:2893			bp2 = 0*/
    _bp2_59337 = 0LL;
L3: 

    /** parser.e:2895		if finish_block_header(WHILE)=0 then*/
    _29638 = _43finish_block_header(47LL);
    if (binary_op_a(NOTEQ, _29638, 0LL)){
        DeRef(_29638);
        _29638 = NOVALUE;
        goto L4; // [188] 204
    }
    DeRef(_29638);
    _29638 = NOVALUE;

    /** parser.e:2896			entry_addr[$]=-1*/
    if (IS_SEQUENCE(_43entry_addr_55039)){
            _29640 = SEQ_PTR(_43entry_addr_55039)->length;
    }
    else {
        _29640 = 1;
    }
    _2 = (object)SEQ_PTR(_43entry_addr_55039);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43entry_addr_55039 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _29640);
    *(intptr_t *)_2 = -1LL;
L4: 

    /** parser.e:2899		loop_stack &= WHILE*/
    Append(&_43loop_stack_55049, _43loop_stack_55049, 47LL);

    /** parser.e:2901		exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_43exit_list_55035)){
            _exit_base_59338 = SEQ_PTR(_43exit_list_55035)->length;
    }
    else {
        _exit_base_59338 = 1;
    }

    /** parser.e:2902		if SC1_type = OR then*/
    if (_43SC1_type_55020 != 9LL)
    goto L5; // [227] 280

    /** parser.e:2903			backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29644 = _43SC1_patch_55019 - 3LL;
    if ((object)((uintptr_t)_29644 +(uintptr_t) HIGH_BITS) >= 0){
        _29644 = NewDouble((eudouble)_29644);
    }
    _45backpatch(_29644, 147LL);
    _29644 = NOVALUE;

    /** parser.e:2904			if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L6; // [249] 260
    }
    else{
    }

    /** parser.e:2905				emit_op(NOP1)*/
    _45emit_op(159LL);
L6: 

    /** parser.e:2907			backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29645 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29645 = 1;
    }
    _29646 = _29645 + 1;
    _29645 = NOVALUE;
    _45backpatch(_43SC1_patch_55019, _29646);
    _29646 = NOVALUE;
    goto L7; // [277] 331
L5: 

    /** parser.e:2908		elsif SC1_type = AND then*/
    if (_43SC1_type_55020 != 8LL)
    goto L8; // [286] 330

    /** parser.e:2909			backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29648 = _43SC1_patch_55019 - 3LL;
    if ((object)((uintptr_t)_29648 +(uintptr_t) HIGH_BITS) >= 0){
        _29648 = NewDouble((eudouble)_29648);
    }
    _45backpatch(_29648, 146LL);
    _29648 = NOVALUE;

    /** parser.e:2910			AppendXList(SC1_patch)*/

    /** parser.e:398		exit_list = append(exit_list, addr)*/
    Append(&_43exit_list_55035, _43exit_list_55035, _43SC1_patch_55019);

    /** parser.e:399	end procedure*/
    goto L9; // [318] 321
L9: 

    /** parser.e:2911			exit_delay &= 1*/
    Append(&_43exit_delay_55036, _43exit_delay_55036, 1LL);
L8: 
L7: 

    /** parser.e:2913		retry_addr &= length(Code)+1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29650 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29650 = 1;
    }
    _29651 = _29650 + 1;
    _29650 = NOVALUE;
    Append(&_43retry_addr_55041, _43retry_addr_55041, _29651);
    _29651 = NOVALUE;

    /** parser.e:2915		sequence temps = pop_temps()*/
    _0 = _temps_59410;
    _temps_59410 = _45pop_temps();
    DeRef(_0);

    /** parser.e:2917		push_temps( temps )*/
    RefDS(_temps_59410);
    _45push_temps(_temps_59410);

    /** parser.e:2919		Statement_list()*/
    _43Statement_list();

    /** parser.e:2920		PatchNList(next_base)*/
    _43PatchNList(_next_base_59339);

    /** parser.e:2921		tok_match(END)*/
    _43tok_match(402LL, 0LL);

    /** parser.e:2922		tok_match(WHILE, END)*/
    _43tok_match(47LL, 402LL);

    /** parser.e:2924		End_block( WHILE )*/
    _64End_block(47LL);

    /** parser.e:2926		StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:2927		emit_op(ENDWHILE)*/
    _45emit_op(22LL);

    /** parser.e:2928		emit_addr(bp1)*/
    _45emit_addr(_bp1_59336);

    /** parser.e:2929		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto LA; // [419] 430
    }
    else{
    }

    /** parser.e:2930			emit_op(NOP1)*/
    _45emit_op(159LL);
LA: 

    /** parser.e:2932		if bp2 != 0 then*/
    if (_bp2_59337 == 0LL)
    goto LB; // [434] 454

    /** parser.e:2933			backpatch(bp2, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29655 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29655 = 1;
    }
    _29656 = _29655 + 1;
    _29655 = NOVALUE;
    _45backpatch(_bp2_59337, _29656);
    _29656 = NOVALUE;
LB: 

    /** parser.e:2935		exit_loop(exit_base)*/
    _43exit_loop(_exit_base_59338);

    /** parser.e:2936		entry_stack = remove( entry_stack, length( entry_stack ) )*/
    if (IS_SEQUENCE(_43entry_stack_55042)){
            _29657 = SEQ_PTR(_43entry_stack_55042)->length;
    }
    else {
        _29657 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_43entry_stack_55042);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_29657)) ? _29657 : (object)(DBL_PTR(_29657)->dbl);
        int stop = (IS_ATOM_INT(_29657)) ? _29657 : (object)(DBL_PTR(_29657)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_43entry_stack_55042), start, &_43entry_stack_55042 );
            }
            else Tail(SEQ_PTR(_43entry_stack_55042), stop+1, &_43entry_stack_55042);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_43entry_stack_55042), start, &_43entry_stack_55042);
        }
        else {
            assign_slice_seq = &assign_space;
            _43entry_stack_55042 = Remove_elements(start, stop, (SEQ_PTR(_43entry_stack_55042)->ref == 1));
        }
    }
    _29657 = NOVALUE;
    _29657 = NOVALUE;

    /** parser.e:2937		push_temps( temps )*/
    RefDS(_temps_59410);
    _45push_temps(_temps_59410);

    /** parser.e:2938	end procedure*/
    DeRef(_uninitialized_59340);
    DeRefDS(_temps_59410);
    return;
    ;
}


void _43Loop_statement()
{
    object _bp1_59440 = NOVALUE;
    object _exit_base_59441 = NOVALUE;
    object _next_base_59442 = NOVALUE;
    object _t_59444 = NOVALUE;
    object _uninitialized_59447 = NOVALUE;
    object _29681 = NOVALUE;
    object _29679 = NOVALUE;
    object _29678 = NOVALUE;
    object _29677 = NOVALUE;
    object _29671 = NOVALUE;
    object _29670 = NOVALUE;
    object _29668 = NOVALUE;
    object _29665 = NOVALUE;
    object _29664 = NOVALUE;
    object _29663 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2946		Start_block( LOOP )*/
    _64Start_block(422LL, 0LL);

    /** parser.e:2948		sequence uninitialized = get_private_uninitialized()*/
    _0 = _uninitialized_59447;
    _uninitialized_59447 = _43get_private_uninitialized();
    DeRef(_0);

    /** parser.e:2949		entry_stack = append( entry_stack, uninitialized )*/
    RefDS(_uninitialized_59447);
    Append(&_43entry_stack_55042, _43entry_stack_55042, _uninitialized_59447);

    /** parser.e:2951		exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_43exit_list_55035)){
            _exit_base_59441 = SEQ_PTR(_43exit_list_55035)->length;
    }
    else {
        _exit_base_59441 = 1;
    }

    /** parser.e:2952		next_base = length(continue_list)*/
    if (IS_SEQUENCE(_43continue_list_55037)){
            _next_base_59442 = SEQ_PTR(_43continue_list_55037)->length;
    }
    else {
        _next_base_59442 = 1;
    }

    /** parser.e:2953		emit_op(NOP2) -- Entry_statement() may patch this*/
    _45emit_op(110LL);

    /** parser.e:2954		emit_addr(0)*/
    _45emit_addr(0LL);

    /** parser.e:2955		if finish_block_header(LOOP) then*/
    _29663 = _43finish_block_header(422LL);
    if (_29663 == 0) {
        DeRef(_29663);
        _29663 = NOVALUE;
        goto L1; // [58] 81
    }
    else {
        if (!IS_ATOM_INT(_29663) && DBL_PTR(_29663)->dbl == 0.0){
            DeRef(_29663);
            _29663 = NOVALUE;
            goto L1; // [58] 81
        }
        DeRef(_29663);
        _29663 = NOVALUE;
    }
    DeRef(_29663);
    _29663 = NOVALUE;

    /** parser.e:2956		    entry_addr &= length(Code)-1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29664 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29664 = 1;
    }
    _29665 = _29664 - 1LL;
    _29664 = NOVALUE;
    Append(&_43entry_addr_55039, _43entry_addr_55039, _29665);
    _29665 = NOVALUE;
    goto L2; // [78] 90
L1: 

    /** parser.e:2958			entry_addr &= -1*/
    Append(&_43entry_addr_55039, _43entry_addr_55039, -1LL);
L2: 

    /** parser.e:2962		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L3; // [94] 105
    }
    else{
    }

    /** parser.e:2963			emit_op(NOP1)*/
    _45emit_op(159LL);
L3: 

    /** parser.e:2965		bp1 = length(Code)+1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29668 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29668 = 1;
    }
    _bp1_59440 = _29668 + 1;
    _29668 = NOVALUE;

    /** parser.e:2966		retry_addr &= length(Code)+1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29670 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29670 = 1;
    }
    _29671 = _29670 + 1;
    _29670 = NOVALUE;
    Append(&_43retry_addr_55041, _43retry_addr_55041, _29671);
    _29671 = NOVALUE;

    /** parser.e:2967		continue_addr &= 0*/
    Append(&_43continue_addr_55040, _43continue_addr_55040, 0LL);

    /** parser.e:2968		loop_stack &= LOOP*/
    Append(&_43loop_stack_55049, _43loop_stack_55049, 422LL);

    /** parser.e:2970		Statement_list()*/
    _43Statement_list();

    /** parser.e:2972		End_block( LOOP )*/
    _64End_block(422LL);

    /** parser.e:2974		tok_match(UNTIL)*/
    _43tok_match(423LL, 0LL);

    /** parser.e:2975		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L4; // [174] 185
    }
    else{
    }

    /** parser.e:2976			emit_op(NOP1)*/
    _45emit_op(159LL);
L4: 

    /** parser.e:2978		PatchNList(next_base)*/
    _43PatchNList(_next_base_59442);

    /** parser.e:2979		StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:2980		short_circuit += 1*/
    _43short_circuit_55015 = _43short_circuit_55015 + 1;

    /** parser.e:2981		short_circuit_B = FALSE*/
    _43short_circuit_B_55017 = _9FALSE_444;

    /** parser.e:2982		SC1_type = 0*/
    _43SC1_type_55020 = 0LL;

    /** parser.e:2983		Expr()*/
    _43Expr();

    /** parser.e:2984		if SC1_type = OR then*/
    if (_43SC1_type_55020 != 9LL)
    goto L5; // [229] 282

    /** parser.e:2985			backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29677 = _43SC1_patch_55019 - 3LL;
    if ((object)((uintptr_t)_29677 +(uintptr_t) HIGH_BITS) >= 0){
        _29677 = NewDouble((eudouble)_29677);
    }
    _45backpatch(_29677, 147LL);
    _29677 = NOVALUE;

    /** parser.e:2986			if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L6; // [251] 262
    }
    else{
    }

    /** parser.e:2987			    emit_op(NOP1)  -- to get label here*/
    _45emit_op(159LL);
L6: 

    /** parser.e:2989			backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29678 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29678 = 1;
    }
    _29679 = _29678 + 1;
    _29678 = NOVALUE;
    _45backpatch(_43SC1_patch_55019, _29679);
    _29679 = NOVALUE;
    goto L7; // [279] 308
L5: 

    /** parser.e:2990		elsif SC1_type = AND then*/
    if (_43SC1_type_55020 != 8LL)
    goto L8; // [288] 307

    /** parser.e:2991			backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29681 = _43SC1_patch_55019 - 3LL;
    if ((object)((uintptr_t)_29681 +(uintptr_t) HIGH_BITS) >= 0){
        _29681 = NewDouble((eudouble)_29681);
    }
    _45backpatch(_29681, 146LL);
    _29681 = NOVALUE;
L8: 
L7: 

    /** parser.e:2993		short_circuit -= 1*/
    _43short_circuit_55015 = _43short_circuit_55015 - 1LL;

    /** parser.e:2994		emit_op(IF)*/
    _45emit_op(20LL);

    /** parser.e:2995		emit_addr(bp1)*/
    _45emit_addr(_bp1_59440);

    /** parser.e:2996		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L9; // [332] 343
    }
    else{
    }

    /** parser.e:2997			emit_op(NOP1)*/
    _45emit_op(159LL);
L9: 

    /** parser.e:2999		exit_loop(exit_base)*/
    _43exit_loop(_exit_base_59441);

    /** parser.e:3001		tok_match(END)*/
    _43tok_match(402LL, 0LL);

    /** parser.e:3002		tok_match(LOOP, END)*/
    _43tok_match(422LL, 402LL);

    /** parser.e:3004	end procedure*/
    DeRef(_uninitialized_59447);
    return;
    ;
}


void _43Ifdef_statement()
{
    object _option_59526 = NOVALUE;
    object _matched_59527 = NOVALUE;
    object _has_matched_59528 = NOVALUE;
    object _in_matched_59529 = NOVALUE;
    object _dead_ifdef_59530 = NOVALUE;
    object _in_elsedef_59531 = NOVALUE;
    object _tok_59533 = NOVALUE;
    object _keyw_59534 = NOVALUE;
    object _parser_id_59538 = NOVALUE;
    object _negate_59554 = NOVALUE;
    object _conjunction_59555 = NOVALUE;
    object _at_start_59556 = NOVALUE;
    object _prev_conj_59557 = NOVALUE;
    object _this_matched_59642 = NOVALUE;
    object _gotword_59658 = NOVALUE;
    object _gotthen_59659 = NOVALUE;
    object _if_lvl_59660 = NOVALUE;
    object _29798 = NOVALUE;
    object _29797 = NOVALUE;
    object _29793 = NOVALUE;
    object _29791 = NOVALUE;
    object _29788 = NOVALUE;
    object _29786 = NOVALUE;
    object _29785 = NOVALUE;
    object _29781 = NOVALUE;
    object _29778 = NOVALUE;
    object _29775 = NOVALUE;
    object _29771 = NOVALUE;
    object _29769 = NOVALUE;
    object _29768 = NOVALUE;
    object _29767 = NOVALUE;
    object _29766 = NOVALUE;
    object _29765 = NOVALUE;
    object _29764 = NOVALUE;
    object _29763 = NOVALUE;
    object _29759 = NOVALUE;
    object _29756 = NOVALUE;
    object _29755 = NOVALUE;
    object _29754 = NOVALUE;
    object _29750 = NOVALUE;
    object _29749 = NOVALUE;
    object _29748 = NOVALUE;
    object _29745 = NOVALUE;
    object _29742 = NOVALUE;
    object _29741 = NOVALUE;
    object _29740 = NOVALUE;
    object _29738 = NOVALUE;
    object _29727 = NOVALUE;
    object _29725 = NOVALUE;
    object _29724 = NOVALUE;
    object _29723 = NOVALUE;
    object _29722 = NOVALUE;
    object _29721 = NOVALUE;
    object _29720 = NOVALUE;
    object _29719 = NOVALUE;
    object _29716 = NOVALUE;
    object _29715 = NOVALUE;
    object _29713 = NOVALUE;
    object _29711 = NOVALUE;
    object _29710 = NOVALUE;
    object _29708 = NOVALUE;
    object _29706 = NOVALUE;
    object _29705 = NOVALUE;
    object _29703 = NOVALUE;
    object _29702 = NOVALUE;
    object _29701 = NOVALUE;
    object _29698 = NOVALUE;
    object _29696 = NOVALUE;
    object _29693 = NOVALUE;
    object _29692 = NOVALUE;
    object _29691 = NOVALUE;
    object _29689 = NOVALUE;
    object _29687 = NOVALUE;
    object _29686 = NOVALUE;
    object _29685 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:3012		integer matched = 0, has_matched = 0,  in_matched = 0, dead_ifdef = 0, in_elsedef = 0*/
    _matched_59527 = 0LL;
    _has_matched_59528 = 0LL;
    _in_matched_59529 = 0LL;
    _dead_ifdef_59530 = 0LL;
    _in_elsedef_59531 = 0LL;

    /** parser.e:3014		sequence keyw ="ifdef"*/
    RefDS(_26288);
    DeRefi(_keyw_59534);
    _keyw_59534 = _26288;

    /** parser.e:3016		live_ifdef += 1*/
    _43live_ifdef_59522 = _43live_ifdef_59522 + 1;

    /** parser.e:3017		ifdef_lineno &= line_number*/
    Append(&_43ifdef_lineno_59523, _43ifdef_lineno_59523, _12line_number_20227);

    /** parser.e:3019		integer parser_id*/

    /** parser.e:3020		if CurrentSub != TopLevelSub or length(if_labels) or length(loop_labels) then*/
    _29685 = (_12CurrentSub_20234 != _12TopLevelSub_20233);
    if (_29685 != 0) {
        _29686 = 1;
        goto L1; // [55] 68
    }
    if (IS_SEQUENCE(_43if_labels_55044)){
            _29687 = SEQ_PTR(_43if_labels_55044)->length;
    }
    else {
        _29687 = 1;
    }
    _29686 = (_29687 != 0);
L1: 
    if (_29686 != 0) {
        goto L2; // [68] 82
    }
    if (IS_SEQUENCE(_43loop_labels_55043)){
            _29689 = SEQ_PTR(_43loop_labels_55043)->length;
    }
    else {
        _29689 = 1;
    }
    if (_29689 == 0)
    {
        _29689 = NOVALUE;
        goto L3; // [78] 92
    }
    else{
        _29689 = NOVALUE;
    }
L2: 

    /** parser.e:3021			parser_id = forward_Statement_list*/
    _parser_id_59538 = _43forward_Statement_list_58262;
    goto L4; // [89] 100
L3: 

    /** parser.e:3023			parser_id = top_level_parser*/
    _parser_id_59538 = _43top_level_parser_59521;
L4: 

    /** parser.e:3026		while 1 label "top" do*/
L5: 

    /** parser.e:3027			if matched = 0 and in_elsedef = 0 then*/
    _29691 = (_matched_59527 == 0LL);
    if (_29691 == 0) {
        goto L6; // [111] 656
    }
    _29693 = (_in_elsedef_59531 == 0LL);
    if (_29693 == 0)
    {
        DeRef(_29693);
        _29693 = NOVALUE;
        goto L6; // [120] 656
    }
    else{
        DeRef(_29693);
        _29693 = NOVALUE;
    }

    /** parser.e:3028				integer negate = 0, conjunction = 0*/
    _negate_59554 = 0LL;
    _conjunction_59555 = 0LL;

    /** parser.e:3029				integer at_start = 1*/
    _at_start_59556 = 1LL;

    /** parser.e:3030				sequence prev_conj = ""*/
    RefDS(_22024);
    DeRef(_prev_conj_59557);
    _prev_conj_59557 = _22024;

    /** parser.e:3032				while 1 label "deflist" do*/
L7: 

    /** parser.e:3033					option = StringToken()*/
    RefDS(_5);
    _0 = _option_59526;
    _option_59526 = _61StringToken(_5);
    DeRef(_0);

    /** parser.e:3034					if equal(option, "then") then*/
    if (_option_59526 == _26355)
    _29696 = 1;
    else if (IS_ATOM_INT(_option_59526) && IS_ATOM_INT(_26355))
    _29696 = 0;
    else
    _29696 = (compare(_option_59526, _26355) == 0);
    if (_29696 == 0)
    {
        _29696 = NOVALUE;
        goto L8; // [162] 240
    }
    else{
        _29696 = NOVALUE;
    }

    /** parser.e:3035						if at_start = 1 then*/
    if (_at_start_59556 != 1LL)
    goto L9; // [167] 187

    /** parser.e:3036							CompileErr(MSG_1_IS_MISSING_DEFINED_WORD_BEFORE_THEN, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59534);
    ((intptr_t*)_2)[1] = _keyw_59534;
    _29698 = MAKE_SEQ(_1);
    _49CompileErr(6LL, _29698, 0LL);
    _29698 = NOVALUE;
    goto LA; // [184] 542
L9: 

    /** parser.e:3037						elsif conjunction = 0 then*/
    if (_conjunction_59555 != 0LL)
    goto LB; // [189] 223

    /** parser.e:3038							if negate = 0 then*/
    if (_negate_59554 != 0LL)
    goto LC; // [195] 206

    /** parser.e:3039								exit "deflist"*/
    goto LD; // [201] 630
    goto LA; // [203] 542
LC: 

    /** parser.e:3041								CompileErr(MSG_1_THEN_FOLLOWS_NOT, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59534);
    ((intptr_t*)_2)[1] = _keyw_59534;
    _29701 = MAKE_SEQ(_1);
    _49CompileErr(11LL, _29701, 0LL);
    _29701 = NOVALUE;
    goto LA; // [220] 542
LB: 

    /** parser.e:3044							CompileErr(MSG_1_THEN_FOLLOWS_2, {keyw, prev_conj})*/
    RefDS(_prev_conj_59557);
    RefDS(_keyw_59534);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _keyw_59534;
    ((intptr_t *)_2)[2] = _prev_conj_59557;
    _29702 = MAKE_SEQ(_1);
    _49CompileErr(8LL, _29702, 0LL);
    _29702 = NOVALUE;
    goto LA; // [237] 542
L8: 

    /** parser.e:3046					elsif equal(option, "not") then*/
    if (_option_59526 == _26316)
    _29703 = 1;
    else if (IS_ATOM_INT(_option_59526) && IS_ATOM_INT(_26316))
    _29703 = 0;
    else
    _29703 = (compare(_option_59526, _26316) == 0);
    if (_29703 == 0)
    {
        _29703 = NOVALUE;
        goto LE; // [246] 284
    }
    else{
        _29703 = NOVALUE;
    }

    /** parser.e:3047						if negate = 0 then*/
    if (_negate_59554 != 0LL)
    goto LF; // [251] 267

    /** parser.e:3048							negate = 1*/
    _negate_59554 = 1LL;

    /** parser.e:3049							continue "deflist"*/
    goto L7; // [262] 148
    goto LA; // [264] 542
LF: 

    /** parser.e:3051							CompileErr(MSG_1_DUPLICATE_NOT, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59534);
    ((intptr_t*)_2)[1] = _keyw_59534;
    _29705 = MAKE_SEQ(_1);
    _49CompileErr(7LL, _29705, 0LL);
    _29705 = NOVALUE;
    goto LA; // [281] 542
LE: 

    /** parser.e:3053					elsif equal(option, "and") then*/
    if (_option_59526 == _26220)
    _29706 = 1;
    else if (IS_ATOM_INT(_option_59526) && IS_ATOM_INT(_26220))
    _29706 = 0;
    else
    _29706 = (compare(_option_59526, _26220) == 0);
    if (_29706 == 0)
    {
        _29706 = NOVALUE;
        goto L10; // [290] 357
    }
    else{
        _29706 = NOVALUE;
    }

    /** parser.e:3054						if at_start = 1 then*/
    if (_at_start_59556 != 1LL)
    goto L11; // [295] 315

    /** parser.e:3055							CompileErr(MSG_1_IS_MISSING_DEFINED_WORD_BEFORE_AND, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59534);
    ((intptr_t*)_2)[1] = _keyw_59534;
    _29708 = MAKE_SEQ(_1);
    _49CompileErr(2LL, _29708, 0LL);
    _29708 = NOVALUE;
    goto LA; // [312] 542
L11: 

    /** parser.e:3056						elsif conjunction = 0 then*/
    if (_conjunction_59555 != 0LL)
    goto L12; // [317] 340

    /** parser.e:3057							conjunction = 1*/
    _conjunction_59555 = 1LL;

    /** parser.e:3058							prev_conj = option*/
    RefDS(_option_59526);
    DeRef(_prev_conj_59557);
    _prev_conj_59557 = _option_59526;

    /** parser.e:3059							continue "deflist"*/
    goto L7; // [335] 148
    goto LA; // [337] 542
L12: 

    /** parser.e:3061							CompileErr(MSG_1_AND_FOLLOWS_2,{keyw,prev_conj})*/
    RefDS(_prev_conj_59557);
    RefDS(_keyw_59534);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _keyw_59534;
    ((intptr_t *)_2)[2] = _prev_conj_59557;
    _29710 = MAKE_SEQ(_1);
    _49CompileErr(10LL, _29710, 0LL);
    _29710 = NOVALUE;
    goto LA; // [354] 542
L10: 

    /** parser.e:3063					elsif equal(option, "or") then*/
    if (_option_59526 == _26320)
    _29711 = 1;
    else if (IS_ATOM_INT(_option_59526) && IS_ATOM_INT(_26320))
    _29711 = 0;
    else
    _29711 = (compare(_option_59526, _26320) == 0);
    if (_29711 == 0)
    {
        _29711 = NOVALUE;
        goto L13; // [363] 430
    }
    else{
        _29711 = NOVALUE;
    }

    /** parser.e:3064						if at_start = 1 then*/
    if (_at_start_59556 != 1LL)
    goto L14; // [368] 388

    /** parser.e:3065							CompileErr(MSG_1_IS_MISSING_DEFINED_WORD_BEFORE_THEN, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59534);
    ((intptr_t*)_2)[1] = _keyw_59534;
    _29713 = MAKE_SEQ(_1);
    _49CompileErr(6LL, _29713, 0LL);
    _29713 = NOVALUE;
    goto LA; // [385] 542
L14: 

    /** parser.e:3066						elsif conjunction = 0 then*/
    if (_conjunction_59555 != 0LL)
    goto L15; // [390] 413

    /** parser.e:3067							conjunction = 2*/
    _conjunction_59555 = 2LL;

    /** parser.e:3068							prev_conj = option*/
    RefDS(_option_59526);
    DeRef(_prev_conj_59557);
    _prev_conj_59557 = _option_59526;

    /** parser.e:3069							continue "deflist"*/
    goto L7; // [408] 148
    goto LA; // [410] 542
L15: 

    /** parser.e:3071							CompileErr(MSG_1_OR_FOLLOWS_2, {keyw, prev_conj})*/
    RefDS(_prev_conj_59557);
    RefDS(_keyw_59534);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _keyw_59534;
    ((intptr_t *)_2)[2] = _prev_conj_59557;
    _29715 = MAKE_SEQ(_1);
    _49CompileErr(9LL, _29715, 0LL);
    _29715 = NOVALUE;
    goto LA; // [427] 542
L13: 

    /** parser.e:3073					elsif length(option) = 0 then*/
    if (IS_SEQUENCE(_option_59526)){
            _29716 = SEQ_PTR(_option_59526)->length;
    }
    else {
        _29716 = 1;
    }
    if (_29716 != 0LL)
    goto L16; // [435] 474

    /** parser.e:3074						if at_start = 1 then*/
    if (_at_start_59556 != 1LL)
    goto L17; // [441] 461

    /** parser.e:3075							CompileErr(NO_WORD_WAS_FOUND_FOLLOWING_1, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59534);
    ((intptr_t*)_2)[1] = _keyw_59534;
    _29719 = MAKE_SEQ(_1);
    _49CompileErr(122LL, _29719, 0LL);
    _29719 = NOVALUE;
    goto LA; // [458] 542
L17: 

    /** parser.e:3077							CompileErr(EXPECTING_POSSIBLY_THEN_NOT_END_OF_LINE)*/
    RefDS(_22024);
    _49CompileErr(82LL, _22024, 0LL);
    goto LA; // [471] 542
L16: 

    /** parser.e:3079					elsif not at_start and length(prev_conj) = 0 then*/
    _29720 = (_at_start_59556 == 0);
    if (_29720 == 0) {
        goto L18; // [479] 510
    }
    if (IS_SEQUENCE(_prev_conj_59557)){
            _29722 = SEQ_PTR(_prev_conj_59557)->length;
    }
    else {
        _29722 = 1;
    }
    _29723 = (_29722 == 0LL);
    _29722 = NOVALUE;
    if (_29723 == 0)
    {
        DeRef(_29723);
        _29723 = NOVALUE;
        goto L18; // [491] 510
    }
    else{
        DeRef(_29723);
        _29723 = NOVALUE;
    }

    /** parser.e:3080						CompileErr(MSG_1_NOT_UNDERSTOOD, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59534);
    ((intptr_t*)_2)[1] = _keyw_59534;
    _29724 = MAKE_SEQ(_1);
    _49CompileErr(4LL, _29724, 0LL);
    _29724 = NOVALUE;
    goto LA; // [507] 542
L18: 

    /** parser.e:3081					elsif t_identifier(option) = 0 then*/
    RefDS(_option_59526);
    _29725 = _9t_identifier(_option_59526);
    if (binary_op_a(NOTEQ, _29725, 0LL)){
        DeRef(_29725);
        _29725 = NOVALUE;
        goto L19; // [516] 536
    }
    DeRef(_29725);
    _29725 = NOVALUE;

    /** parser.e:3082						CompileErr(MSG_1_WORD_MUST_BE_AN_IDENTIFIER, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59534);
    ((intptr_t*)_2)[1] = _keyw_59534;
    _29727 = MAKE_SEQ(_1);
    _49CompileErr(3LL, _29727, 0LL);
    _29727 = NOVALUE;
    goto LA; // [533] 542
L19: 

    /** parser.e:3084						at_start = 0*/
    _at_start_59556 = 0LL;
LA: 

    /** parser.e:3087					integer this_matched = find(option, OpDefines)*/
    _this_matched_59642 = find_from(_option_59526, _12OpDefines_20300, 1LL);

    /** parser.e:3088					if negate then*/
    if (_negate_59554 == 0)
    {
        goto L1A; // [553] 567
    }
    else{
    }

    /** parser.e:3089						this_matched = not this_matched*/
    _this_matched_59642 = (_this_matched_59642 == 0);

    /** parser.e:3090						negate = 0*/
    _negate_59554 = 0LL;
L1A: 

    /** parser.e:3093					if conjunction = 0 then*/
    if (_conjunction_59555 != 0LL)
    goto L1B; // [569] 581

    /** parser.e:3094						matched = this_matched*/
    _matched_59527 = _this_matched_59642;
    goto L1C; // [578] 623
L1B: 

    /** parser.e:3096						if conjunction = 1 then*/
    if (_conjunction_59555 != 1LL)
    goto L1D; // [583] 596

    /** parser.e:3097							matched = matched and this_matched*/
    _matched_59527 = (_matched_59527 != 0 && _this_matched_59642 != 0);
    goto L1E; // [593] 610
L1D: 

    /** parser.e:3098						elsif conjunction = 2 then*/
    if (_conjunction_59555 != 2LL)
    goto L1F; // [598] 609

    /** parser.e:3099							matched = matched or this_matched*/
    _matched_59527 = (_matched_59527 != 0 || _this_matched_59642 != 0);
L1F: 
L1E: 

    /** parser.e:3101						conjunction = 0*/
    _conjunction_59555 = 0LL;

    /** parser.e:3102						prev_conj = ""*/
    RefDS(_22024);
    DeRef(_prev_conj_59557);
    _prev_conj_59557 = _22024;
L1C: 

    /** parser.e:3104				end while*/
    goto L7; // [627] 148
LD: 

    /** parser.e:3106				in_matched = matched*/
    _in_matched_59529 = _matched_59527;

    /** parser.e:3107				if matched then*/
    if (_matched_59527 == 0)
    {
        goto L20; // [637] 655
    }
    else{
    }

    /** parser.e:3108					No_new_entry = 0*/
    _53No_new_entry_48046 = 0LL;

    /** parser.e:3109					call_proc(parser_id, {})*/
    _0 = (object)_00[_parser_id_59538].addr;
    (*(intptr_t (*)())_0)(
                         );
L20: 
L6: 
    DeRef(_prev_conj_59557);
    _prev_conj_59557 = NOVALUE;

    /** parser.e:3115			integer gotword = 0*/
    _gotword_59658 = 0LL;

    /** parser.e:3116			integer gotthen = 0*/
    _gotthen_59659 = 0LL;

    /** parser.e:3117			integer if_lvl  = 0*/
    _if_lvl_59660 = 0LL;

    /** parser.e:3118			No_new_entry = not matched*/
    _53No_new_entry_48046 = (_matched_59527 == 0);

    /** parser.e:3119			has_matched = has_matched or matched*/
    _has_matched_59528 = (_has_matched_59528 != 0 || _matched_59527 != 0);

    /** parser.e:3120			keyw = "elsifdef"*/
    RefDS(_26256);
    DeRefi(_keyw_59534);
    _keyw_59534 = _26256;

    /** parser.e:3121			while 1 do*/
L21: 

    /** parser.e:3122				tok = next_token()*/
    _0 = _tok_59533;
    _tok_59533 = _43next_token();
    DeRef(_0);

    /** parser.e:3123				if tok[T_ID] = END_OF_FILE then*/
    _2 = (object)SEQ_PTR(_tok_59533);
    _29738 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29738, -21LL)){
        _29738 = NOVALUE;
        goto L22; // [713] 738
    }
    _29738 = NOVALUE;

    /** parser.e:3124					CompileErr(END_OF_FILE_REACHED_WHILE_SEARCHING_FOR_END_IFDEF_TO_MATCH_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59523)){
            _29740 = SEQ_PTR(_43ifdef_lineno_59523)->length;
    }
    else {
        _29740 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59523);
    _29741 = (object)*(((s1_ptr)_2)->base + _29740);
    _49CompileErr(65LL, _29741, 0LL);
    _29741 = NOVALUE;
    goto L21; // [735] 698
L22: 

    /** parser.e:3125				elsif tok[T_ID] = END then*/
    _2 = (object)SEQ_PTR(_tok_59533);
    _29742 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29742, 402LL)){
        _29742 = NOVALUE;
        goto L23; // [748] 874
    }
    _29742 = NOVALUE;

    /** parser.e:3126					tok = next_token()*/
    _0 = _tok_59533;
    _tok_59533 = _43next_token();
    DeRef(_0);

    /** parser.e:3127					if tok[T_ID] = IFDEF then*/
    _2 = (object)SEQ_PTR(_tok_59533);
    _29745 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29745, 407LL)){
        _29745 = NOVALUE;
        goto L24; // [767] 795
    }
    _29745 = NOVALUE;

    /** parser.e:3128						if dead_ifdef then*/
    if (_dead_ifdef_59530 == 0)
    {
        goto L25; // [773] 785
    }
    else{
    }

    /** parser.e:3129							dead_ifdef -= 1*/
    _dead_ifdef_59530 = _dead_ifdef_59530 - 1LL;
    goto L21; // [782] 698
L25: 

    /** parser.e:3131							exit "top"*/
    goto L26; // [789] 1350
    goto L21; // [792] 698
L24: 

    /** parser.e:3133					elsif in_matched then*/
    if (_in_matched_59529 == 0)
    {
        goto L27; // [797] 821
    }
    else{
    }

    /** parser.e:3135						CompileErr(EXPECTING_END_IFDEF_TO_MATCH_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59523)){
            _29748 = SEQ_PTR(_43ifdef_lineno_59523)->length;
    }
    else {
        _29748 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59523);
    _29749 = (object)*(((s1_ptr)_2)->base + _29748);
    _49CompileErr(75LL, _29749, 0LL);
    _29749 = NOVALUE;
    goto L21; // [818] 698
L27: 

    /** parser.e:3137						if tok[T_ID] = IF then*/
    _2 = (object)SEQ_PTR(_tok_59533);
    _29750 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29750, 20LL)){
        _29750 = NOVALUE;
        goto L21; // [831] 698
    }
    _29750 = NOVALUE;

    /** parser.e:3138							if if_lvl > 0 then*/
    if (_if_lvl_59660 <= 0LL)
    goto L28; // [837] 850

    /** parser.e:3139								if_lvl -= 1*/
    _if_lvl_59660 = _if_lvl_59660 - 1LL;
    goto L21; // [847] 698
L28: 

    /** parser.e:3141								CompileErr(MISMATCHED_END_IF_SHOULD_THIS_BE_AN_END_IFDEF_TO_MATCH_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59523)){
            _29754 = SEQ_PTR(_43ifdef_lineno_59523)->length;
    }
    else {
        _29754 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59523);
    _29755 = (object)*(((s1_ptr)_2)->base + _29754);
    _49CompileErr(111LL, _29755, 0LL);
    _29755 = NOVALUE;
    goto L21; // [871] 698
L23: 

    /** parser.e:3145				elsif tok[T_ID] = IF then*/
    _2 = (object)SEQ_PTR(_tok_59533);
    _29756 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29756, 20LL)){
        _29756 = NOVALUE;
        goto L29; // [884] 897
    }
    _29756 = NOVALUE;

    /** parser.e:3146					if_lvl += 1*/
    _if_lvl_59660 = _if_lvl_59660 + 1;
    goto L21; // [894] 698
L29: 

    /** parser.e:3147				elsif tok[T_ID] = ELSE then*/
    _2 = (object)SEQ_PTR(_tok_59533);
    _29759 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29759, 23LL)){
        _29759 = NOVALUE;
        goto L2A; // [907] 945
    }
    _29759 = NOVALUE;

    /** parser.e:3148					if not in_matched then*/
    if (_in_matched_59529 != 0)
    goto L21; // [913] 698

    /** parser.e:3149						if if_lvl = 0 then*/
    if (_if_lvl_59660 != 0LL)
    goto L21; // [918] 698

    /** parser.e:3150							CompileErr(MISMATCHED_ELSE_SHOULD_THIS_BE_AN_ELSEDEF_TO_MATCH_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59523)){
            _29763 = SEQ_PTR(_43ifdef_lineno_59523)->length;
    }
    else {
        _29763 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59523);
    _29764 = (object)*(((s1_ptr)_2)->base + _29763);
    _49CompileErr(108LL, _29764, 0LL);
    _29764 = NOVALUE;
    goto L21; // [942] 698
L2A: 

    /** parser.e:3153				elsif tok[T_ID] = ELSIFDEF and not dead_ifdef then*/
    _2 = (object)SEQ_PTR(_tok_59533);
    _29765 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_29765)) {
        _29766 = (_29765 == 408LL);
    }
    else {
        _29766 = binary_op(EQUALS, _29765, 408LL);
    }
    _29765 = NOVALUE;
    if (IS_ATOM_INT(_29766)) {
        if (_29766 == 0) {
            goto L2B; // [959] 1101
        }
    }
    else {
        if (DBL_PTR(_29766)->dbl == 0.0) {
            goto L2B; // [959] 1101
        }
    }
    _29768 = (_dead_ifdef_59530 == 0);
    if (_29768 == 0)
    {
        DeRef(_29768);
        _29768 = NOVALUE;
        goto L2B; // [967] 1101
    }
    else{
        DeRef(_29768);
        _29768 = NOVALUE;
    }

    /** parser.e:3154					if has_matched then*/
    if (_has_matched_59528 == 0)
    {
        goto L2C; // [972] 1343
    }
    else{
    }

    /** parser.e:3155						in_matched = 0*/
    _in_matched_59529 = 0LL;

    /** parser.e:3156						No_new_entry = 1*/
    _53No_new_entry_48046 = 1LL;

    /** parser.e:3157						gotword = 0*/
    _gotword_59658 = 0LL;

    /** parser.e:3158						gotthen = 0*/
    _gotthen_59659 = 0LL;

    /** parser.e:3159						while length(option) > 0 with entry do*/
    goto L2D; // [999] 1041
L2E: 
    if (IS_SEQUENCE(_option_59526)){
            _29769 = SEQ_PTR(_option_59526)->length;
    }
    else {
        _29769 = 1;
    }
    if (_29769 <= 0LL)
    goto L2F; // [1007] 1054

    /** parser.e:3160							if equal(option, "then") then*/
    if (_option_59526 == _26355)
    _29771 = 1;
    else if (IS_ATOM_INT(_option_59526) && IS_ATOM_INT(_26355))
    _29771 = 0;
    else
    _29771 = (compare(_option_59526, _26355) == 0);
    if (_29771 == 0)
    {
        _29771 = NOVALUE;
        goto L30; // [1017] 1032
    }
    else{
        _29771 = NOVALUE;
    }

    /** parser.e:3161								gotthen = 1*/
    _gotthen_59659 = 1LL;

    /** parser.e:3162								exit*/
    goto L2F; // [1027] 1054
    goto L31; // [1029] 1038
L30: 

    /** parser.e:3164								gotword = 1*/
    _gotword_59658 = 1LL;
L31: 

    /** parser.e:3166						entry*/
L2D: 

    /** parser.e:3167							option = StringToken()*/
    RefDS(_5);
    _0 = _option_59526;
    _option_59526 = _61StringToken(_5);
    DeRef(_0);

    /** parser.e:3168						end while*/
    goto L2E; // [1051] 1002
L2F: 

    /** parser.e:3169						if gotword = 0 then*/
    if (_gotword_59658 != 0LL)
    goto L32; // [1056] 1070

    /** parser.e:3170							CompileErr(EXPECTING_A_WORD_TO_FOLLOW_ELSIFDEF)*/
    RefDS(_22024);
    _49CompileErr(78LL, _22024, 0LL);
L32: 

    /** parser.e:3172						if gotthen = 0 then*/
    if (_gotthen_59659 != 0LL)
    goto L33; // [1072] 1086

    /** parser.e:3173							CompileErr(EXPECTING_THEN_ON_ELSIFDEF_LINE)*/
    RefDS(_22024);
    _49CompileErr(77LL, _22024, 0LL);
L33: 

    /** parser.e:3175						read_line()*/
    _61read_line();
    goto L21; // [1090] 698

    /** parser.e:3177						exit*/
    goto L2C; // [1095] 1343
    goto L21; // [1098] 698
L2B: 

    /** parser.e:3179				elsif tok[T_ID] = ELSEDEF then*/
    _2 = (object)SEQ_PTR(_tok_59533);
    _29775 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29775, 409LL)){
        _29775 = NOVALUE;
        goto L34; // [1111] 1273
    }
    _29775 = NOVALUE;

    /** parser.e:3180					gotword = line_number*/
    _gotword_59658 = _12line_number_20227;

    /** parser.e:3181					option = StringToken()*/
    RefDS(_5);
    _0 = _option_59526;
    _option_59526 = _61StringToken(_5);
    DeRef(_0);

    /** parser.e:3182					if length(option) > 0 then*/
    if (IS_SEQUENCE(_option_59526)){
            _29778 = SEQ_PTR(_option_59526)->length;
    }
    else {
        _29778 = 1;
    }
    if (_29778 <= 0LL)
    goto L35; // [1137] 1173

    /** parser.e:3183						if line_number = gotword then*/
    if (_12line_number_20227 != _gotword_59658)
    goto L36; // [1145] 1159

    /** parser.e:3184							CompileErr(NOT_EXPECTING_ANYTHING_ON_SAME_LINE_AS_ELSDEF)*/
    RefDS(_22024);
    _49CompileErr(116LL, _22024, 0LL);
L36: 

    /** parser.e:3186						bp -= length(option)*/
    if (IS_SEQUENCE(_option_59526)){
            _29781 = SEQ_PTR(_option_59526)->length;
    }
    else {
        _29781 = 1;
    }
    _49bp_49316 = _49bp_49316 - _29781;
    _29781 = NOVALUE;
L35: 

    /** parser.e:3188					if not dead_ifdef then*/
    if (_dead_ifdef_59530 != 0)
    goto L21; // [1175] 698

    /** parser.e:3189						if has_matched then*/
    if (_has_matched_59528 == 0)
    {
        goto L37; // [1180] 1202
    }
    else{
    }

    /** parser.e:3190							in_matched = 0*/
    _in_matched_59529 = 0LL;

    /** parser.e:3191							No_new_entry = 1*/
    _53No_new_entry_48046 = 1LL;

    /** parser.e:3192							read_line()*/
    _61read_line();
    goto L21; // [1199] 698
L37: 

    /** parser.e:3194							No_new_entry = 0*/
    _53No_new_entry_48046 = 0LL;

    /** parser.e:3195							in_elsedef = 1*/
    _in_elsedef_59531 = 1LL;

    /** parser.e:3196							call_proc(parser_id, {})*/
    _0 = (object)_00[_parser_id_59538].addr;
    (*(intptr_t (*)())_0)(
                         );

    /** parser.e:3197							tok_match(END)*/
    _43tok_match(402LL, 0LL);

    /** parser.e:3198							tok_match(IFDEF, END)*/
    _43tok_match(407LL, 402LL);

    /** parser.e:3199							live_ifdef -= 1*/
    _43live_ifdef_59522 = _43live_ifdef_59522 - 1LL;

    /** parser.e:3200							ifdef_lineno = ifdef_lineno[1..$-1]*/
    if (IS_SEQUENCE(_43ifdef_lineno_59523)){
            _29785 = SEQ_PTR(_43ifdef_lineno_59523)->length;
    }
    else {
        _29785 = 1;
    }
    _29786 = _29785 - 1LL;
    _29785 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43ifdef_lineno_59523;
    RHS_Slice(_43ifdef_lineno_59523, 1LL, _29786);

    /** parser.e:3201							return*/
    DeRef(_option_59526);
    DeRef(_tok_59533);
    DeRefi(_keyw_59534);
    DeRef(_29685);
    _29685 = NOVALUE;
    DeRef(_29691);
    _29691 = NOVALUE;
    DeRef(_29720);
    _29720 = NOVALUE;
    DeRef(_29766);
    _29766 = NOVALUE;
    _29786 = NOVALUE;
    return;
    goto L21; // [1270] 698
L34: 

    /** parser.e:3204				elsif tok[T_ID] = IFDEF then*/
    _2 = (object)SEQ_PTR(_tok_59533);
    _29788 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29788, 407LL)){
        _29788 = NOVALUE;
        goto L38; // [1283] 1296
    }
    _29788 = NOVALUE;

    /** parser.e:3205					dead_ifdef += 1*/
    _dead_ifdef_59530 = _dead_ifdef_59530 + 1;
    goto L21; // [1293] 698
L38: 

    /** parser.e:3207				elsif tok[T_ID] = INCLUDE then*/
    _2 = (object)SEQ_PTR(_tok_59533);
    _29791 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29791, 418LL)){
        _29791 = NOVALUE;
        goto L39; // [1306] 1317
    }
    _29791 = NOVALUE;

    /** parser.e:3209					read_line()*/
    _61read_line();
    goto L21; // [1314] 698
L39: 

    /** parser.e:3211				elsif tok[T_ID] = CASE then*/
    _2 = (object)SEQ_PTR(_tok_59533);
    _29793 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29793, 186LL)){
        _29793 = NOVALUE;
        goto L21; // [1327] 698
    }
    _29793 = NOVALUE;

    /** parser.e:3213					tok = next_token()*/
    _0 = _tok_59533;
    _tok_59533 = _43next_token();
    DeRef(_0);

    /** parser.e:3216			end while*/
    goto L21; // [1340] 698
L2C: 

    /** parser.e:3217		end while*/
    goto L5; // [1347] 105
L26: 

    /** parser.e:3219		live_ifdef -= 1*/
    _43live_ifdef_59522 = _43live_ifdef_59522 - 1LL;

    /** parser.e:3220		ifdef_lineno = ifdef_lineno[1..$-1]*/
    if (IS_SEQUENCE(_43ifdef_lineno_59523)){
            _29797 = SEQ_PTR(_43ifdef_lineno_59523)->length;
    }
    else {
        _29797 = 1;
    }
    _29798 = _29797 - 1LL;
    _29797 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43ifdef_lineno_59523;
    RHS_Slice(_43ifdef_lineno_59523, 1LL, _29798);

    /** parser.e:3221		No_new_entry = 0*/
    _53No_new_entry_48046 = 0LL;

    /** parser.e:3222	end procedure*/
    DeRef(_option_59526);
    DeRef(_tok_59533);
    DeRefi(_keyw_59534);
    _29798 = NOVALUE;
    DeRef(_29685);
    _29685 = NOVALUE;
    DeRef(_29691);
    _29691 = NOVALUE;
    DeRef(_29720);
    _29720 = NOVALUE;
    DeRef(_29766);
    _29766 = NOVALUE;
    DeRef(_29786);
    _29786 = NOVALUE;
    return;
    ;
}


object _43SetPrivateScope(object _s_59813, object _type_sym_59815, object _n_59816)
{
    object _hashval_59817 = NOVALUE;
    object _scope_59818 = NOVALUE;
    object _t_59820 = NOVALUE;
    object _29819 = NOVALUE;
    object _29818 = NOVALUE;
    object _29817 = NOVALUE;
    object _29816 = NOVALUE;
    object _29815 = NOVALUE;
    object _29814 = NOVALUE;
    object _29811 = NOVALUE;
    object _29808 = NOVALUE;
    object _29806 = NOVALUE;
    object _29804 = NOVALUE;
    object _29800 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_59813)) {
        _1 = (object)(DBL_PTR(_s_59813)->dbl);
        DeRefDS(_s_59813);
        _s_59813 = _1;
    }

    /** parser.e:3230		scope = SymTab[s][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29800 = (object)*(((s1_ptr)_2)->base + _s_59813);
    _2 = (object)SEQ_PTR(_29800);
    _scope_59818 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_scope_59818)){
        _scope_59818 = (object)DBL_PTR(_scope_59818)->dbl;
    }
    _29800 = NOVALUE;

    /** parser.e:3231		switch scope do*/
    _0 = _scope_59818;
    switch ( _0 ){ 

        /** parser.e:3232			case SC_PRIVATE then*/
        case 3:

        /** parser.e:3233				DefinedYet(s)*/
        _53DefinedYet(_s_59813);

        /** parser.e:3234				Block_var( s )*/
        _64Block_var(_s_59813);

        /** parser.e:3235				return s*/
        return _s_59813;
        goto L1; // [50] 260

        /** parser.e:3237			case SC_LOOP_VAR then*/
        case 2:

        /** parser.e:3238				DefinedYet(s)*/
        _53DefinedYet(_s_59813);

        /** parser.e:3239				return s*/
        return _s_59813;
        goto L1; // [67] 260

        /** parser.e:3241			case SC_UNDEFINED, SC_MULTIPLY_DEFINED then*/
        case 9:
        case 10:

        /** parser.e:3242				SymTab[s][S_SCOPE] = SC_PRIVATE*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_s_59813 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 4LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 3LL;
        DeRef(_1);
        _29804 = NOVALUE;

        /** parser.e:3243				SymTab[s][S_VARNUM] = n*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_s_59813 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 16LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _n_59816;
        DeRef(_1);
        _29806 = NOVALUE;

        /** parser.e:3244				SymTab[s][S_VTYPE] = type_sym*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_s_59813 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 15LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _type_sym_59815;
        DeRef(_1);
        _29808 = NOVALUE;

        /** parser.e:3245				if type_sym < 0 then*/
        if (_type_sym_59815 >= 0LL)
        goto L2; // [124] 135

        /** parser.e:3246					register_forward_type( s, type_sym )*/
        _42register_forward_type(_s_59813, _type_sym_59815);
L2: 

        /** parser.e:3248				Block_var( s )*/
        _64Block_var(_s_59813);

        /** parser.e:3249				return s*/
        return _s_59813;
        goto L1; // [146] 260

        /** parser.e:3251			case SC_LOCAL, SC_GLOBAL, SC_PREDEF, SC_PUBLIC, SC_EXPORT then*/
        case 5:
        case 6:
        case 7:
        case 13:
        case 11:

        /** parser.e:3252				hashval = SymTab[s][S_HASHVAL]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _29811 = (object)*(((s1_ptr)_2)->base + _s_59813);
        _2 = (object)SEQ_PTR(_29811);
        _hashval_59817 = (object)*(((s1_ptr)_2)->base + 11LL);
        if (!IS_ATOM_INT(_hashval_59817)){
            _hashval_59817 = (object)DBL_PTR(_hashval_59817)->dbl;
        }
        _29811 = NOVALUE;

        /** parser.e:3253				t = buckets[hashval]*/
        _2 = (object)SEQ_PTR(_53buckets_46842);
        _t_59820 = (object)*(((s1_ptr)_2)->base + _hashval_59817);
        if (!IS_ATOM_INT(_t_59820)){
            _t_59820 = (object)DBL_PTR(_t_59820)->dbl;
        }

        /** parser.e:3254				buckets[hashval] = NewEntry(SymTab[s][S_NAME], n, SC_PRIVATE,*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _29814 = (object)*(((s1_ptr)_2)->base + _s_59813);
        _2 = (object)SEQ_PTR(_29814);
        if (!IS_ATOM_INT(_12S_NAME_19864)){
            _29815 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
        }
        else{
            _29815 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
        }
        _29814 = NOVALUE;
        Ref(_29815);
        _29816 = _53NewEntry(_29815, _n_59816, 3LL, -100LL, _hashval_59817, _t_59820, _type_sym_59815);
        _29815 = NOVALUE;
        _2 = (object)SEQ_PTR(_53buckets_46842);
        _2 = (object)(((s1_ptr)_2)->base + _hashval_59817);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _29816;
        if( _1 != _29816 ){
            DeRef(_1);
        }
        _29816 = NOVALUE;

        /** parser.e:3256				Block_var( buckets[hashval] )*/
        _2 = (object)SEQ_PTR(_53buckets_46842);
        _29817 = (object)*(((s1_ptr)_2)->base + _hashval_59817);
        Ref(_29817);
        _64Block_var(_29817);
        _29817 = NOVALUE;

        /** parser.e:3257				return buckets[hashval]*/
        _2 = (object)SEQ_PTR(_53buckets_46842);
        _29818 = (object)*(((s1_ptr)_2)->base + _hashval_59817);
        Ref(_29818);
        return _29818;
        goto L1; // [243] 260

        /** parser.e:3259			case else*/
        default:

        /** parser.e:3260				InternalErr(267, {scope})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _scope_59818;
        _29819 = MAKE_SEQ(_1);
        _49InternalErr(267LL, _29819);
        _29819 = NOVALUE;
    ;}L1: 

    /** parser.e:3264		return 0*/
    _29818 = NOVALUE;
    return 0LL;
    ;
}


void _43For_statement()
{
    object _bp1_59885 = NOVALUE;
    object _bp2_59886 = NOVALUE;
    object _exit_base_59887 = NOVALUE;
    object _next_base_59888 = NOVALUE;
    object _end_op_59889 = NOVALUE;
    object _tok_59891 = NOVALUE;
    object _loop_var_59892 = NOVALUE;
    object _loop_var_sym_59894 = NOVALUE;
    object _save_syms_59895 = NOVALUE;
    object _29866 = NOVALUE;
    object _29864 = NOVALUE;
    object _29863 = NOVALUE;
    object _29857 = NOVALUE;
    object _29855 = NOVALUE;
    object _29853 = NOVALUE;
    object _29852 = NOVALUE;
    object _29851 = NOVALUE;
    object _29850 = NOVALUE;
    object _29848 = NOVALUE;
    object _29846 = NOVALUE;
    object _29845 = NOVALUE;
    object _29844 = NOVALUE;
    object _29843 = NOVALUE;
    object _29841 = NOVALUE;
    object _29839 = NOVALUE;
    object _29835 = NOVALUE;
    object _29833 = NOVALUE;
    object _29830 = NOVALUE;
    object _29828 = NOVALUE;
    object _29822 = NOVALUE;
    object _29821 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:3273		sequence save_syms*/

    /** parser.e:3275		Start_block( FOR )*/
    _64Start_block(21LL, 0LL);

    /** parser.e:3276		loop_var = next_token()*/
    _0 = _loop_var_59892;
    _loop_var_59892 = _43next_token();
    DeRef(_0);

    /** parser.e:3277		if not find(loop_var[T_ID], ADDR_TOKS) then*/
    _2 = (object)SEQ_PTR(_loop_var_59892);
    _29821 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29822 = find_from(_29821, _29ADDR_TOKS_12010, 1LL);
    _29821 = NOVALUE;
    if (_29822 != 0)
    goto L1; // [31] 44
    _29822 = NOVALUE;

    /** parser.e:3278			CompileErr(A_LOOP_VARIABLE_NAME_IS_EXPECTED_HERE)*/
    RefDS(_22024);
    _49CompileErr(28LL, _22024, 0LL);
L1: 

    /** parser.e:3281		if BIND then*/
    if (_12BIND_19837 == 0)
    {
        goto L2; // [48] 57
    }
    else{
    }

    /** parser.e:3282			add_ref(loop_var)*/
    Ref(_loop_var_59892);
    _53add_ref(_loop_var_59892);
L2: 

    /** parser.e:3285		tok_match(EQUALS)*/
    _43tok_match(3LL, 0LL);

    /** parser.e:3286		exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_43exit_list_55035)){
            _exit_base_59887 = SEQ_PTR(_43exit_list_55035)->length;
    }
    else {
        _exit_base_59887 = 1;
    }

    /** parser.e:3287		next_base = length(continue_list)*/
    if (IS_SEQUENCE(_43continue_list_55037)){
            _next_base_59888 = SEQ_PTR(_43continue_list_55037)->length;
    }
    else {
        _next_base_59888 = 1;
    }

    /** parser.e:3288		Expr()*/
    _43Expr();

    /** parser.e:3289		tok_match(TO)*/
    _43tok_match(403LL, 0LL);

    /** parser.e:3290		exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_43exit_list_55035)){
            _exit_base_59887 = SEQ_PTR(_43exit_list_55035)->length;
    }
    else {
        _exit_base_59887 = 1;
    }

    /** parser.e:3291		Expr()*/
    _43Expr();

    /** parser.e:3292		tok = next_token()*/
    _0 = _tok_59891;
    _tok_59891 = _43next_token();
    DeRef(_0);

    /** parser.e:3293		if tok[T_ID] = BY then*/
    _2 = (object)SEQ_PTR(_tok_59891);
    _29828 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29828, 404LL)){
        _29828 = NOVALUE;
        goto L3; // [117] 137
    }
    _29828 = NOVALUE;

    /** parser.e:3294			Expr()*/
    _43Expr();

    /** parser.e:3295			end_op = ENDFOR_GENERAL -- will be set at runtime by FOR op*/
    _end_op_59889 = 39LL;
    goto L4; // [134] 161
L3: 

    /** parser.e:3298			emit_opnd(NewIntSym(1))*/
    _29830 = _53NewIntSym(1LL);
    _45emit_opnd(_29830);
    _29830 = NOVALUE;

    /** parser.e:3299			putback(tok)*/
    Ref(_tok_59891);
    _43putback(_tok_59891);

    /** parser.e:3300			end_op = ENDFOR_INT_UP1*/
    _end_op_59889 = 54LL;
L4: 

    /** parser.e:3303		loop_var_sym = loop_var[T_SYM]*/
    _2 = (object)SEQ_PTR(_loop_var_59892);
    _loop_var_sym_59894 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_loop_var_sym_59894)){
        _loop_var_sym_59894 = (object)DBL_PTR(_loop_var_sym_59894)->dbl;
    }

    /** parser.e:3304		if CurrentSub = TopLevelSub then*/
    if (_12CurrentSub_20234 != _12TopLevelSub_20233)
    goto L5; // [177] 223

    /** parser.e:3305			DefinedYet(loop_var_sym)*/
    _53DefinedYet(_loop_var_sym_59894);

    /** parser.e:3306			SymTab[loop_var_sym][S_SCOPE] = SC_GLOOP_VAR*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_loop_var_sym_59894 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 4LL;
    DeRef(_1);
    _29833 = NOVALUE;

    /** parser.e:3307			SymTab[loop_var_sym][S_VTYPE] = object_type*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_loop_var_sym_59894 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _53object_type_46846;
    DeRef(_1);
    _29835 = NOVALUE;
    goto L6; // [220] 267
L5: 

    /** parser.e:3309			loop_var_sym = SetPrivateScope(loop_var_sym, object_type, param_num)*/
    _loop_var_sym_59894 = _43SetPrivateScope(_loop_var_sym_59894, _53object_type_46846, _43param_num_55024);
    if (!IS_ATOM_INT(_loop_var_sym_59894)) {
        _1 = (object)(DBL_PTR(_loop_var_sym_59894)->dbl);
        DeRefDS(_loop_var_sym_59894);
        _loop_var_sym_59894 = _1;
    }

    /** parser.e:3310			param_num += 1*/
    _43param_num_55024 = _43param_num_55024 + 1;

    /** parser.e:3311			SymTab[loop_var_sym][S_SCOPE] = SC_LOOP_VAR*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_loop_var_sym_59894 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _29839 = NOVALUE;

    /** parser.e:3312			Pop_block_var()*/
    _64Pop_block_var();
L6: 

    /** parser.e:3314		SymTab[loop_var_sym][S_USAGE] = or_bits(SymTab[loop_var_sym][S_USAGE], U_USED)*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_loop_var_sym_59894 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29843 = (object)*(((s1_ptr)_2)->base + _loop_var_sym_59894);
    _2 = (object)SEQ_PTR(_29843);
    _29844 = (object)*(((s1_ptr)_2)->base + 5LL);
    _29843 = NOVALUE;
    if (IS_ATOM_INT(_29844)) {
        {uintptr_t tu;
             tu = (uintptr_t)_29844 | (uintptr_t)3LL;
             _29845 = MAKE_UINT(tu);
        }
    }
    else {
        _29845 = binary_op(OR_BITS, _29844, 3LL);
    }
    _29844 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29845;
    if( _1 != _29845 ){
        DeRef(_1);
    }
    _29845 = NOVALUE;
    _29841 = NOVALUE;

    /** parser.e:3316		op_info1 = loop_var_sym*/
    _45op_info1_51020 = _loop_var_sym_59894;

    /** parser.e:3317		emit_op(FOR)*/
    _45emit_op(21LL);

    /** parser.e:3318		emit_addr(loop_var_sym)*/
    _45emit_addr(_loop_var_sym_59894);

    /** parser.e:3319		if finish_block_header(FOR) then*/
    _29846 = _43finish_block_header(21LL);
    if (_29846 == 0) {
        DeRef(_29846);
        _29846 = NOVALUE;
        goto L7; // [327] 340
    }
    else {
        if (!IS_ATOM_INT(_29846) && DBL_PTR(_29846)->dbl == 0.0){
            DeRef(_29846);
            _29846 = NOVALUE;
            goto L7; // [327] 340
        }
        DeRef(_29846);
        _29846 = NOVALUE;
    }
    DeRef(_29846);
    _29846 = NOVALUE;

    /** parser.e:3320			CompileErr(ENTRY_IS_NOT_SUPPORTED_IN_FOR_LOOPS)*/
    RefDS(_22024);
    _49CompileErr(83LL, _22024, 0LL);
L7: 

    /** parser.e:3322		entry_addr &= 0*/
    Append(&_43entry_addr_55039, _43entry_addr_55039, 0LL);

    /** parser.e:3323		bp1 = length(Code)+1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29848 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29848 = 1;
    }
    _bp1_59885 = _29848 + 1;
    _29848 = NOVALUE;

    /** parser.e:3324		emit_addr(0) -- will be patched - don't straighten*/
    _45emit_addr(0LL);

    /** parser.e:3326		save_syms = Code[$-5..$-3] -- could be temps, but can't get rid of them yet*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29850 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29850 = 1;
    }
    _29851 = _29850 - 5LL;
    _29850 = NOVALUE;
    if (IS_SEQUENCE(_12Code_20315)){
            _29852 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29852 = 1;
    }
    _29853 = _29852 - 3LL;
    _29852 = NOVALUE;
    rhs_slice_target = (object_ptr)&_save_syms_59895;
    RHS_Slice(_12Code_20315, _29851, _29853);

    /** parser.e:3327		for i = 1 to 3 do*/
    {
        object _i_59985;
        _i_59985 = 1LL;
L8: 
        if (_i_59985 > 3LL){
            goto L9; // [389] 412
        }

        /** parser.e:3328			clear_temp( save_syms[i] )*/
        _2 = (object)SEQ_PTR(_save_syms_59895);
        _29855 = (object)*(((s1_ptr)_2)->base + _i_59985);
        Ref(_29855);
        _45clear_temp(_29855);
        _29855 = NOVALUE;

        /** parser.e:3329		end for*/
        _i_59985 = _i_59985 + 1LL;
        goto L8; // [407] 396
L9: 
        ;
    }

    /** parser.e:3330		flush_temps()*/
    RefDS(_22024);
    _45flush_temps(_22024);

    /** parser.e:3332		bp2 = length(Code)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _bp2_59886 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _bp2_59886 = 1;
    }

    /** parser.e:3333		retry_addr &= bp2 + 1*/
    _29857 = _bp2_59886 + 1;
    Append(&_43retry_addr_55041, _43retry_addr_55041, _29857);
    _29857 = NOVALUE;

    /** parser.e:3334		continue_addr &= 0*/
    Append(&_43continue_addr_55040, _43continue_addr_55040, 0LL);

    /** parser.e:3336		loop_stack &= FOR*/
    Append(&_43loop_stack_55049, _43loop_stack_55049, 21LL);

    /** parser.e:3338		if not TRANSLATE then*/
    if (_12TRANSLATE_19834 != 0)
    goto LA; // [458] 482

    /** parser.e:3339			if OpTrace then*/
    if (_12OpTrace_20296 == 0)
    {
        goto LB; // [465] 481
    }
    else{
    }

    /** parser.e:3340				emit_op(DISPLAY_VAR)*/
    _45emit_op(87LL);

    /** parser.e:3341				emit_addr(loop_var_sym)*/
    _45emit_addr(_loop_var_sym_59894);
LB: 
LA: 

    /** parser.e:3345		Statement_list()*/
    _43Statement_list();

    /** parser.e:3346		tok_match(END)*/
    _43tok_match(402LL, 0LL);

    /** parser.e:3347		tok_match(FOR, END)*/
    _43tok_match(21LL, 402LL);

    /** parser.e:3349		End_block( FOR )*/
    _64End_block(21LL);

    /** parser.e:3351		StartSourceLine(TRUE, TRANSLATE)*/
    _45StartSourceLine(_9TRUE_446, _12TRANSLATE_19834, 2LL);

    /** parser.e:3352		op_info1 = loop_var_sym*/
    _45op_info1_51020 = _loop_var_sym_59894;

    /** parser.e:3353		op_info2 = bp2 + 1*/
    _45op_info2_51021 = _bp2_59886 + 1;

    /** parser.e:3354		PatchNList(next_base)*/
    _43PatchNList(_next_base_59888);

    /** parser.e:3355		emit_op(end_op)*/
    _45emit_op(_end_op_59889);

    /** parser.e:3356		backpatch(bp1, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29863 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29863 = 1;
    }
    _29864 = _29863 + 1;
    _29863 = NOVALUE;
    _45backpatch(_bp1_59885, _29864);
    _29864 = NOVALUE;

    /** parser.e:3357		if not TRANSLATE then*/
    if (_12TRANSLATE_19834 != 0)
    goto LC; // [568] 592

    /** parser.e:3358			if OpTrace then*/
    if (_12OpTrace_20296 == 0)
    {
        goto LD; // [575] 591
    }
    else{
    }

    /** parser.e:3359				emit_op(ERASE_SYMBOL)*/
    _45emit_op(90LL);

    /** parser.e:3360				emit_addr(loop_var_sym)*/
    _45emit_addr(_loop_var_sym_59894);
LD: 
LC: 

    /** parser.e:3364		Hide(loop_var_sym)*/
    _53Hide(_loop_var_sym_59894);

    /** parser.e:3365		exit_loop(exit_base)*/
    _43exit_loop(_exit_base_59887);

    /** parser.e:3366		for i = 1 to 3 do*/
    {
        object _i_60031;
        _i_60031 = 1LL;
LE: 
        if (_i_60031 > 3LL){
            goto LF; // [604] 630
        }

        /** parser.e:3367			emit_temp( save_syms[i], NEW_REFERENCE )*/
        _2 = (object)SEQ_PTR(_save_syms_59895);
        _29866 = (object)*(((s1_ptr)_2)->base + _i_60031);
        Ref(_29866);
        _45emit_temp(_29866, 1LL);
        _29866 = NOVALUE;

        /** parser.e:3368		end for*/
        _i_60031 = _i_60031 + 1LL;
        goto LE; // [625] 611
LF: 
        ;
    }

    /** parser.e:3369		flush_temps()*/
    RefDS(_22024);
    _45flush_temps(_22024);

    /** parser.e:3370	end procedure*/
    DeRef(_tok_59891);
    DeRef(_loop_var_59892);
    DeRef(_save_syms_59895);
    DeRef(_29851);
    _29851 = NOVALUE;
    DeRef(_29853);
    _29853 = NOVALUE;
    return;
    ;
}


object _43CompileType(object _type_ptr_60039)
{
    object _t_60040 = NOVALUE;
    object _29877 = NOVALUE;
    object _29876 = NOVALUE;
    object _29875 = NOVALUE;
    object _29869 = NOVALUE;
    object _29868 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_type_ptr_60039)) {
        _1 = (object)(DBL_PTR(_type_ptr_60039)->dbl);
        DeRefDS(_type_ptr_60039);
        _type_ptr_60039 = _1;
    }

    /** parser.e:3376		if type_ptr < 0 then*/
    if (_type_ptr_60039 >= 0LL)
    goto L1; // [5] 16

    /** parser.e:3378			return type_ptr*/
    return _type_ptr_60039;
L1: 

    /** parser.e:3381		if SymTab[type_ptr][S_TOKEN] = OBJECT then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29868 = (object)*(((s1_ptr)_2)->base + _type_ptr_60039);
    _2 = (object)SEQ_PTR(_29868);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _29869 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _29869 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _29868 = NOVALUE;
    if (binary_op_a(NOTEQ, _29869, 415LL)){
        _29869 = NOVALUE;
        goto L2; // [32] 47
    }
    _29869 = NOVALUE;

    /** parser.e:3382			return TYPE_OBJECT*/
    return 16LL;
    goto L3; // [44] 218
L2: 

    /** parser.e:3384		elsif type_ptr = integer_type then*/
    if (_type_ptr_60039 != _53integer_type_46852)
    goto L4; // [51] 66

    /** parser.e:3385			return TYPE_INTEGER*/
    return 1LL;
    goto L3; // [63] 218
L4: 

    /** parser.e:3387		elsif type_ptr = atom_type then*/
    if (_type_ptr_60039 != _53atom_type_46848)
    goto L5; // [70] 85

    /** parser.e:3388			return TYPE_ATOM*/
    return 4LL;
    goto L3; // [82] 218
L5: 

    /** parser.e:3390		elsif type_ptr = sequence_type then*/
    if (_type_ptr_60039 != _53sequence_type_46850)
    goto L6; // [89] 104

    /** parser.e:3391			return TYPE_SEQUENCE*/
    return 8LL;
    goto L3; // [101] 218
L6: 

    /** parser.e:3393		elsif type_ptr = object_type then*/
    if (_type_ptr_60039 != _53object_type_46846)
    goto L7; // [108] 123

    /** parser.e:3394			return TYPE_OBJECT*/
    return 16LL;
    goto L3; // [120] 218
L7: 

    /** parser.e:3398			t = SymTab[SymTab[type_ptr][S_NEXT]][S_VTYPE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29875 = (object)*(((s1_ptr)_2)->base + _type_ptr_60039);
    _2 = (object)SEQ_PTR(_29875);
    _29876 = (object)*(((s1_ptr)_2)->base + 2LL);
    _29875 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_29876)){
        _29877 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29876)->dbl));
    }
    else{
        _29877 = (object)*(((s1_ptr)_2)->base + _29876);
    }
    _2 = (object)SEQ_PTR(_29877);
    _t_60040 = (object)*(((s1_ptr)_2)->base + 15LL);
    if (!IS_ATOM_INT(_t_60040)){
        _t_60040 = (object)DBL_PTR(_t_60040)->dbl;
    }
    _29877 = NOVALUE;

    /** parser.e:3399			if t = integer_type then*/
    if (_t_60040 != _53integer_type_46852)
    goto L8; // [155] 170

    /** parser.e:3400				return TYPE_INTEGER*/
    _29876 = NOVALUE;
    return 1LL;
    goto L9; // [167] 217
L8: 

    /** parser.e:3401			elsif t = atom_type then*/
    if (_t_60040 != _53atom_type_46848)
    goto LA; // [174] 189

    /** parser.e:3402				return TYPE_ATOM*/
    _29876 = NOVALUE;
    return 4LL;
    goto L9; // [186] 217
LA: 

    /** parser.e:3403			elsif t = sequence_type then*/
    if (_t_60040 != _53sequence_type_46850)
    goto LB; // [193] 208

    /** parser.e:3404				return TYPE_SEQUENCE*/
    _29876 = NOVALUE;
    return 8LL;
    goto L9; // [205] 217
LB: 

    /** parser.e:3406				return TYPE_OBJECT*/
    _29876 = NOVALUE;
    return 16LL;
L9: 
L3: 
    ;
}


object _43get_assigned_sym()
{
    object _29890 = NOVALUE;
    object _29889 = NOVALUE;
    object _29888 = NOVALUE;
    object _29886 = NOVALUE;
    object _29885 = NOVALUE;
    object _29884 = NOVALUE;
    object _29883 = NOVALUE;
    object _29882 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:3416		if not find( Code[$-2], {ASSIGN, ASSIGN_I}) then*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29882 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29882 = 1;
    }
    _29883 = _29882 - 2LL;
    _29882 = NOVALUE;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _29884 = (object)*(((s1_ptr)_2)->base + _29883);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 18LL;
    ((intptr_t *)_2)[2] = 113LL;
    _29885 = MAKE_SEQ(_1);
    _29886 = find_from(_29884, _29885, 1LL);
    _29884 = NOVALUE;
    DeRefDS(_29885);
    _29885 = NOVALUE;
    if (_29886 != 0)
    goto L1; // [29] 39
    _29886 = NOVALUE;

    /** parser.e:3417			return 0*/
    _29883 = NOVALUE;
    return 0LL;
L1: 

    /** parser.e:3419		return Code[$-1]*/
    if (IS_SEQUENCE(_12Code_20315)){
            _29888 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _29888 = 1;
    }
    _29889 = _29888 - 1LL;
    _29888 = NOVALUE;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _29890 = (object)*(((s1_ptr)_2)->base + _29889);
    Ref(_29890);
    DeRef(_29883);
    _29883 = NOVALUE;
    _29889 = NOVALUE;
    return _29890;
    ;
}


void _43Assign_Constant(object _sym_60109)
{
    object _valsym_60111 = NOVALUE;
    object _val_60114 = NOVALUE;
    object _29917 = NOVALUE;
    object _29916 = NOVALUE;
    object _29914 = NOVALUE;
    object _29913 = NOVALUE;
    object _29912 = NOVALUE;
    object _29910 = NOVALUE;
    object _29909 = NOVALUE;
    object _29908 = NOVALUE;
    object _29906 = NOVALUE;
    object _29905 = NOVALUE;
    object _29904 = NOVALUE;
    object _29902 = NOVALUE;
    object _29901 = NOVALUE;
    object _29900 = NOVALUE;
    object _29898 = NOVALUE;
    object _29896 = NOVALUE;
    object _29894 = NOVALUE;
    object _29892 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:3423		symtab_index valsym = Pop() -- pop the sym for the constant, too*/
    _valsym_60111 = _45Pop();
    if (!IS_ATOM_INT(_valsym_60111)) {
        _1 = (object)(DBL_PTR(_valsym_60111)->dbl);
        DeRefDS(_valsym_60111);
        _valsym_60111 = _1;
    }

    /** parser.e:3424		object val = SymTab[valsym][S_OBJ]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29892 = (object)*(((s1_ptr)_2)->base + _valsym_60111);
    DeRef(_val_60114);
    _2 = (object)SEQ_PTR(_29892);
    _val_60114 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_val_60114);
    _29892 = NOVALUE;

    /** parser.e:3426		SymTab[sym][S_OBJ] = val*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60109 + ((s1_ptr)_2)->base);
    Ref(_val_60114);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _val_60114;
    DeRef(_1);
    _29894 = NOVALUE;

    /** parser.e:3427		SymTab[sym][S_INITLEVEL] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60109 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _29896 = NOVALUE;

    /** parser.e:3429		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L1; // [58] 197
    }
    else{
    }

    /** parser.e:3431			SymTab[sym][S_GTYPE] = SymTab[valsym][S_GTYPE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60109 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29900 = (object)*(((s1_ptr)_2)->base + _valsym_60111);
    _2 = (object)SEQ_PTR(_29900);
    _29901 = (object)*(((s1_ptr)_2)->base + 36LL);
    _29900 = NOVALUE;
    Ref(_29901);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29901;
    if( _1 != _29901 ){
        DeRef(_1);
    }
    _29901 = NOVALUE;
    _29898 = NOVALUE;

    /** parser.e:3432			SymTab[sym][S_SEQ_ELEM] = SymTab[valsym][S_SEQ_ELEM]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60109 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29904 = (object)*(((s1_ptr)_2)->base + _valsym_60111);
    _2 = (object)SEQ_PTR(_29904);
    _29905 = (object)*(((s1_ptr)_2)->base + 33LL);
    _29904 = NOVALUE;
    Ref(_29905);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29905;
    if( _1 != _29905 ){
        DeRef(_1);
    }
    _29905 = NOVALUE;
    _29902 = NOVALUE;

    /** parser.e:3433			SymTab[sym][S_OBJ_MIN] = SymTab[valsym][S_OBJ_MIN]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60109 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29908 = (object)*(((s1_ptr)_2)->base + _valsym_60111);
    _2 = (object)SEQ_PTR(_29908);
    _29909 = (object)*(((s1_ptr)_2)->base + 30LL);
    _29908 = NOVALUE;
    Ref(_29909);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29909;
    if( _1 != _29909 ){
        DeRef(_1);
    }
    _29909 = NOVALUE;
    _29906 = NOVALUE;

    /** parser.e:3434			SymTab[sym][S_OBJ_MAX] = SymTab[valsym][S_OBJ_MAX]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60109 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29912 = (object)*(((s1_ptr)_2)->base + _valsym_60111);
    _2 = (object)SEQ_PTR(_29912);
    _29913 = (object)*(((s1_ptr)_2)->base + 31LL);
    _29912 = NOVALUE;
    Ref(_29913);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29913;
    if( _1 != _29913 ){
        DeRef(_1);
    }
    _29913 = NOVALUE;
    _29910 = NOVALUE;

    /** parser.e:3435			SymTab[sym][S_SEQ_LEN] = SymTab[valsym][S_SEQ_LEN]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60109 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29916 = (object)*(((s1_ptr)_2)->base + _valsym_60111);
    _2 = (object)SEQ_PTR(_29916);
    _29917 = (object)*(((s1_ptr)_2)->base + 32LL);
    _29916 = NOVALUE;
    Ref(_29917);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29917;
    if( _1 != _29917 ){
        DeRef(_1);
    }
    _29917 = NOVALUE;
    _29914 = NOVALUE;
L1: 

    /** parser.e:3437	end procedure*/
    DeRef(_val_60114);
    return;
    ;
}


object _43Global_declaration(object _type_ptr_60171, object _scope_60172)
{
    object _new_symbols_60173 = NOVALUE;
    object _tok_60175 = NOVALUE;
    object _tsym_60176 = NOVALUE;
    object _prevtok_60177 = NOVALUE;
    object _sym_60179 = NOVALUE;
    object _valsym_60180 = NOVALUE;
    object _h_60181 = NOVALUE;
    object _count_60182 = NOVALUE;
    object _val_60183 = NOVALUE;
    object _usedval_60184 = NOVALUE;
    object _deltafunc_60185 = NOVALUE;
    object _delta_60186 = NOVALUE;
    object _is_fwd_ref_60187 = NOVALUE;
    object _ptok_60204 = NOVALUE;
    object _negate_60220 = NOVALUE;
    object _negate_60470 = NOVALUE;
    object _31778 = NOVALUE;
    object _31777 = NOVALUE;
    object _31776 = NOVALUE;
    object _30158 = NOVALUE;
    object _30156 = NOVALUE;
    object _30154 = NOVALUE;
    object _30152 = NOVALUE;
    object _30150 = NOVALUE;
    object _30147 = NOVALUE;
    object _30145 = NOVALUE;
    object _30144 = NOVALUE;
    object _30143 = NOVALUE;
    object _30142 = NOVALUE;
    object _30141 = NOVALUE;
    object _30140 = NOVALUE;
    object _30138 = NOVALUE;
    object _30134 = NOVALUE;
    object _30132 = NOVALUE;
    object _30130 = NOVALUE;
    object _30128 = NOVALUE;
    object _30126 = NOVALUE;
    object _30124 = NOVALUE;
    object _30123 = NOVALUE;
    object _30121 = NOVALUE;
    object _30120 = NOVALUE;
    object _30119 = NOVALUE;
    object _30117 = NOVALUE;
    object _30115 = NOVALUE;
    object _30113 = NOVALUE;
    object _30112 = NOVALUE;
    object _30111 = NOVALUE;
    object _30109 = NOVALUE;
    object _30108 = NOVALUE;
    object _30107 = NOVALUE;
    object _30105 = NOVALUE;
    object _30103 = NOVALUE;
    object _30101 = NOVALUE;
    object _30100 = NOVALUE;
    object _30099 = NOVALUE;
    object _30098 = NOVALUE;
    object _30097 = NOVALUE;
    object _30094 = NOVALUE;
    object _30092 = NOVALUE;
    object _30090 = NOVALUE;
    object _30089 = NOVALUE;
    object _30088 = NOVALUE;
    object _30084 = NOVALUE;
    object _30083 = NOVALUE;
    object _30082 = NOVALUE;
    object _30078 = NOVALUE;
    object _30077 = NOVALUE;
    object _30076 = NOVALUE;
    object _30074 = NOVALUE;
    object _30073 = NOVALUE;
    object _30072 = NOVALUE;
    object _30071 = NOVALUE;
    object _30070 = NOVALUE;
    object _30069 = NOVALUE;
    object _30068 = NOVALUE;
    object _30067 = NOVALUE;
    object _30066 = NOVALUE;
    object _30063 = NOVALUE;
    object _30061 = NOVALUE;
    object _30060 = NOVALUE;
    object _30058 = NOVALUE;
    object _30057 = NOVALUE;
    object _30055 = NOVALUE;
    object _30054 = NOVALUE;
    object _30053 = NOVALUE;
    object _30052 = NOVALUE;
    object _30050 = NOVALUE;
    object _30048 = NOVALUE;
    object _30046 = NOVALUE;
    object _30043 = NOVALUE;
    object _30040 = NOVALUE;
    object _30037 = NOVALUE;
    object _30035 = NOVALUE;
    object _30034 = NOVALUE;
    object _30033 = NOVALUE;
    object _30032 = NOVALUE;
    object _30030 = NOVALUE;
    object _30029 = NOVALUE;
    object _30028 = NOVALUE;
    object _30027 = NOVALUE;
    object _30023 = NOVALUE;
    object _30022 = NOVALUE;
    object _30021 = NOVALUE;
    object _30020 = NOVALUE;
    object _30019 = NOVALUE;
    object _30018 = NOVALUE;
    object _30015 = NOVALUE;
    object _30013 = NOVALUE;
    object _30012 = NOVALUE;
    object _30011 = NOVALUE;
    object _30010 = NOVALUE;
    object _30009 = NOVALUE;
    object _30006 = NOVALUE;
    object _30004 = NOVALUE;
    object _30002 = NOVALUE;
    object _30001 = NOVALUE;
    object _30000 = NOVALUE;
    object _29999 = NOVALUE;
    object _29998 = NOVALUE;
    object _29997 = NOVALUE;
    object _29996 = NOVALUE;
    object _29994 = NOVALUE;
    object _29991 = NOVALUE;
    object _29989 = NOVALUE;
    object _29988 = NOVALUE;
    object _29987 = NOVALUE;
    object _29986 = NOVALUE;
    object _29985 = NOVALUE;
    object _29984 = NOVALUE;
    object _29983 = NOVALUE;
    object _29982 = NOVALUE;
    object _29979 = NOVALUE;
    object _29978 = NOVALUE;
    object _29977 = NOVALUE;
    object _29975 = NOVALUE;
    object _29974 = NOVALUE;
    object _29973 = NOVALUE;
    object _29972 = NOVALUE;
    object _29971 = NOVALUE;
    object _29969 = NOVALUE;
    object _29968 = NOVALUE;
    object _29967 = NOVALUE;
    object _29965 = NOVALUE;
    object _29964 = NOVALUE;
    object _29962 = NOVALUE;
    object _29959 = NOVALUE;
    object _29957 = NOVALUE;
    object _29955 = NOVALUE;
    object _29947 = NOVALUE;
    object _29946 = NOVALUE;
    object _29944 = NOVALUE;
    object _29941 = NOVALUE;
    object _29933 = NOVALUE;
    object _29930 = NOVALUE;
    object _29929 = NOVALUE;
    object _29927 = NOVALUE;
    object _29923 = NOVALUE;
    object _29922 = NOVALUE;
    object _29921 = NOVALUE;
    object _29920 = NOVALUE;
    object _29919 = NOVALUE;
    object _29918 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_type_ptr_60171)) {
        _1 = (object)(DBL_PTR(_type_ptr_60171)->dbl);
        DeRefDS(_type_ptr_60171);
        _type_ptr_60171 = _1;
    }

    /** parser.e:3447		object tsym*/

    /** parser.e:3448		object prevtok = 0*/
    DeRef(_prevtok_60177);
    _prevtok_60177 = 0LL;

    /** parser.e:3450		integer h, count = 0*/
    _count_60182 = 0LL;

    /** parser.e:3451		atom val = 1, usedval*/
    DeRef(_val_60183);
    _val_60183 = 1LL;

    /** parser.e:3452		integer deltafunc = '+'*/
    _deltafunc_60185 = 43LL;

    /** parser.e:3453		atom delta = 1*/
    DeRef(_delta_60186);
    _delta_60186 = 1LL;

    /** parser.e:3455		new_symbols = {}*/
    RefDS(_22024);
    DeRefi(_new_symbols_60173);
    _new_symbols_60173 = _22024;

    /** parser.e:3456		integer is_fwd_ref = 0*/
    _is_fwd_ref_60187 = 0LL;

    /** parser.e:3457		if type_ptr > 0 and SymTab[type_ptr][S_SCOPE] = SC_UNDEFINED then*/
    _29918 = (_type_ptr_60171 > 0LL);
    if (_29918 == 0) {
        goto L1; // [50] 105
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29920 = (object)*(((s1_ptr)_2)->base + _type_ptr_60171);
    _2 = (object)SEQ_PTR(_29920);
    _29921 = (object)*(((s1_ptr)_2)->base + 4LL);
    _29920 = NOVALUE;
    if (IS_ATOM_INT(_29921)) {
        _29922 = (_29921 == 9LL);
    }
    else {
        _29922 = binary_op(EQUALS, _29921, 9LL);
    }
    _29921 = NOVALUE;
    if (_29922 == 0) {
        DeRef(_29922);
        _29922 = NOVALUE;
        goto L1; // [73] 105
    }
    else {
        if (!IS_ATOM_INT(_29922) && DBL_PTR(_29922)->dbl == 0.0){
            DeRef(_29922);
            _29922 = NOVALUE;
            goto L1; // [73] 105
        }
        DeRef(_29922);
        _29922 = NOVALUE;
    }
    DeRef(_29922);
    _29922 = NOVALUE;

    /** parser.e:3458			is_fwd_ref = 1*/
    _is_fwd_ref_60187 = 1LL;

    /** parser.e:3459			Hide(type_ptr)*/
    _53Hide(_type_ptr_60171);

    /** parser.e:3460			type_ptr = -new_forward_reference( TYPE, type_ptr )*/
    DeRef(_31778);
    _31778 = 504LL;
    _29923 = _42new_forward_reference(504LL, _type_ptr_60171, 504LL);
    _31778 = NOVALUE;
    if (IS_ATOM_INT(_29923)) {
        if ((uintptr_t)_29923 == (uintptr_t)HIGH_BITS){
            _type_ptr_60171 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _type_ptr_60171 = - _29923;
        }
    }
    else {
        _type_ptr_60171 = unary_op(UMINUS, _29923);
    }
    DeRef(_29923);
    _29923 = NOVALUE;
    if (!IS_ATOM_INT(_type_ptr_60171)) {
        _1 = (object)(DBL_PTR(_type_ptr_60171)->dbl);
        DeRefDS(_type_ptr_60171);
        _type_ptr_60171 = _1;
    }
L1: 

    /** parser.e:3463		if type_ptr = -1 then*/
    if (_type_ptr_60171 != -1LL)
    goto L2; // [107] 426

    /** parser.e:3465			sequence ptok = next_token()*/
    _0 = _ptok_60204;
    _ptok_60204 = _43next_token();
    DeRef(_0);

    /** parser.e:3466			if ptok[T_ID] = TYPE_DECL then*/
    _2 = (object)SEQ_PTR(_ptok_60204);
    _29927 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29927, 416LL)){
        _29927 = NOVALUE;
        goto L3; // [128] 172
    }
    _29927 = NOVALUE;

    /** parser.e:3469				putback(keyfind("enum",-1))*/
    RefDS(_26264);
    DeRef(_31776);
    _31776 = _26264;
    _31777 = _53hashfn(_31776);
    _31776 = NOVALUE;
    RefDS(_26264);
    _29929 = _53keyfind(_26264, -1LL, _12current_file_no_20226, 0LL, _31777);
    _31777 = NOVALUE;
    _43putback(_29929);
    _29929 = NOVALUE;

    /** parser.e:3470				SubProg(TYPE_DECL, scope, 0)*/
    _43SubProg(416LL, _scope_60172, 0LL);

    /** parser.e:3471				return {}*/
    RefDS(_22024);
    DeRefDS(_ptok_60204);
    DeRefi(_new_symbols_60173);
    DeRef(_tok_60175);
    DeRef(_tsym_60176);
    DeRef(_prevtok_60177);
    DeRef(_val_60183);
    DeRef(_usedval_60184);
    DeRef(_delta_60186);
    DeRef(_29918);
    _29918 = NOVALUE;
    return _22024;
    goto L4; // [169] 425
L3: 

    /** parser.e:3472			elsif ptok[T_ID] = BY then*/
    _2 = (object)SEQ_PTR(_ptok_60204);
    _29930 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29930, 404LL)){
        _29930 = NOVALUE;
        goto L5; // [182] 419
    }
    _29930 = NOVALUE;

    /** parser.e:3474				integer negate = 0*/
    _negate_60220 = 0LL;

    /** parser.e:3475				ptok = next_token()*/
    _0 = _ptok_60204;
    _ptok_60204 = _43next_token();
    DeRefDS(_0);

    /** parser.e:3476				switch ptok[T_ID] do*/
    _2 = (object)SEQ_PTR(_ptok_60204);
    _29933 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_29933) ){
        goto L6; // [206] 285
    }
    if(!IS_ATOM_INT(_29933)){
        if( (DBL_PTR(_29933)->dbl != (eudouble) ((object) DBL_PTR(_29933)->dbl) ) ){
            goto L6; // [206] 285
        }
        _0 = (object) DBL_PTR(_29933)->dbl;
    }
    else {
        _0 = _29933;
    };
    _29933 = NOVALUE;
    switch ( _0 ){ 

        /** parser.e:3477					case reserved:MULTIPLY then*/
        case 13:

        /** parser.e:3478						deltafunc = '*'*/
        _deltafunc_60185 = 42LL;

        /** parser.e:3479						ptok = next_token()*/
        _0 = _ptok_60204;
        _ptok_60204 = _43next_token();
        DeRef(_0);
        goto L7; // [227] 293

        /** parser.e:3481					case reserved:DIVIDE then*/
        case 14:

        /** parser.e:3482						deltafunc = '/'*/
        _deltafunc_60185 = 47LL;

        /** parser.e:3483						ptok = next_token()*/
        _0 = _ptok_60204;
        _ptok_60204 = _43next_token();
        DeRef(_0);
        goto L7; // [245] 293

        /** parser.e:3485					case MINUS then*/
        case 10:

        /** parser.e:3486						deltafunc = '-'*/
        _deltafunc_60185 = 45LL;

        /** parser.e:3487						ptok = next_token()*/
        _0 = _ptok_60204;
        _ptok_60204 = _43next_token();
        DeRef(_0);
        goto L7; // [263] 293

        /** parser.e:3489					case PLUS then*/
        case 11:

        /** parser.e:3490						deltafunc = '+'*/
        _deltafunc_60185 = 43LL;

        /** parser.e:3491						ptok = next_token()*/
        _0 = _ptok_60204;
        _ptok_60204 = _43next_token();
        DeRef(_0);
        goto L7; // [281] 293

        /** parser.e:3493					case else*/
        default:
L6: 

        /** parser.e:3494						deltafunc = '+'*/
        _deltafunc_60185 = 43LL;
    ;}L7: 

    /** parser.e:3498				if ptok[T_ID] = MINUS then*/
    _2 = (object)SEQ_PTR(_ptok_60204);
    _29941 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29941, 10LL)){
        _29941 = NOVALUE;
        goto L8; // [303] 320
    }
    _29941 = NOVALUE;

    /** parser.e:3499					negate = 1*/
    _negate_60220 = 1LL;

    /** parser.e:3500					ptok = next_token()*/
    _0 = _ptok_60204;
    _ptok_60204 = _43next_token();
    DeRefDS(_0);
L8: 

    /** parser.e:3502				if ptok[T_ID] != ATOM then*/
    _2 = (object)SEQ_PTR(_ptok_60204);
    _29944 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _29944, 502LL)){
        _29944 = NOVALUE;
        goto L9; // [330] 344
    }
    _29944 = NOVALUE;

    /** parser.e:3503					CompileErr( A_NUMERIC_LITERAL_WAS_EXPECTED)*/
    RefDS(_22024);
    _49CompileErr(344LL, _22024, 0LL);
L9: 

    /** parser.e:3506				delta = SymTab[ptok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_ptok_60204);
    _29946 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_29946)){
        _29947 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29946)->dbl));
    }
    else{
        _29947 = (object)*(((s1_ptr)_2)->base + _29946);
    }
    DeRef(_delta_60186);
    _2 = (object)SEQ_PTR(_29947);
    _delta_60186 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_delta_60186);
    _29947 = NOVALUE;

    /** parser.e:3507				if negate then*/
    if (_negate_60220 == 0)
    {
        goto LA; // [366] 375
    }
    else{
    }

    /** parser.e:3508					delta = -delta*/
    _0 = _delta_60186;
    if (IS_ATOM_INT(_delta_60186)) {
        if ((uintptr_t)_delta_60186 == (uintptr_t)HIGH_BITS){
            _delta_60186 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _delta_60186 = - _delta_60186;
        }
    }
    else {
        _delta_60186 = unary_op(UMINUS, _delta_60186);
    }
    DeRef(_0);
LA: 

    /** parser.e:3511				switch deltafunc do*/
    _0 = _deltafunc_60185;
    switch ( _0 ){ 

        /** parser.e:3512					case '/' then*/
        case 47:

        /** parser.e:3513						delta = 1 / delta*/
        _0 = _delta_60186;
        if (IS_ATOM_INT(_delta_60186)) {
            _delta_60186 = (1LL % _delta_60186) ? NewDouble((eudouble)1LL / _delta_60186) : (1LL / _delta_60186);
        }
        else {
            _delta_60186 = NewDouble((eudouble)1LL / DBL_PTR(_delta_60186)->dbl);
        }
        DeRef(_0);

        /** parser.e:3514						deltafunc = '*'*/
        _deltafunc_60185 = 42LL;
        goto LB; // [397] 414

        /** parser.e:3516					case '-' then*/
        case 45:

        /** parser.e:3517						delta = -delta*/
        _0 = _delta_60186;
        if (IS_ATOM_INT(_delta_60186)) {
            if ((uintptr_t)_delta_60186 == (uintptr_t)HIGH_BITS){
                _delta_60186 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _delta_60186 = - _delta_60186;
            }
        }
        else {
            _delta_60186 = unary_op(UMINUS, _delta_60186);
        }
        DeRef(_0);

        /** parser.e:3518						deltafunc = '+'*/
        _deltafunc_60185 = 43LL;
    ;}LB: 
    goto L4; // [416] 425
L5: 

    /** parser.e:3523				putback(ptok)*/
    RefDS(_ptok_60204);
    _43putback(_ptok_60204);
L4: 
L2: 
    DeRef(_ptok_60204);
    _ptok_60204 = NOVALUE;

    /** parser.e:3527		valsym = 0*/
    _valsym_60180 = 0LL;

    /** parser.e:3528		while TRUE do*/
LC: 
    if (_9TRUE_446 == 0)
    {
        goto LD; // [442] 2303
    }
    else{
    }

    /** parser.e:3529			tok = next_token()*/
    _0 = _tok_60175;
    _tok_60175 = _43next_token();
    DeRef(_0);

    /** parser.e:3530			if tok[T_ID] = DOLLAR then*/
    _2 = (object)SEQ_PTR(_tok_60175);
    _29955 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29955, -22LL)){
        _29955 = NOVALUE;
        goto LE; // [460] 499
    }
    _29955 = NOVALUE;

    /** parser.e:3531				if not equal(prevtok, 0) then*/
    if (_prevtok_60177 == 0LL)
    _29957 = 1;
    else if (IS_ATOM_INT(_prevtok_60177) && IS_ATOM_INT(0LL))
    _29957 = 0;
    else
    _29957 = (compare(_prevtok_60177, 0LL) == 0);
    if (_29957 != 0)
    goto LF; // [470] 498
    _29957 = NOVALUE;

    /** parser.e:3532					if prevtok[T_ID] = COMMA then*/
    _2 = (object)SEQ_PTR(_prevtok_60177);
    _29959 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29959, -30LL)){
        _29959 = NOVALUE;
        goto L10; // [483] 497
    }
    _29959 = NOVALUE;

    /** parser.e:3534						tok = next_token()*/
    _0 = _tok_60175;
    _tok_60175 = _43next_token();
    DeRef(_0);

    /** parser.e:3535						exit*/
    goto LD; // [494] 2303
L10: 
LF: 
LE: 

    /** parser.e:3539			if tok[T_ID] = END_OF_FILE then*/
    _2 = (object)SEQ_PTR(_tok_60175);
    _29962 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29962, -21LL)){
        _29962 = NOVALUE;
        goto L11; // [509] 523
    }
    _29962 = NOVALUE;

    /** parser.e:3540				CompileErr( AN_IDENTIFIER_IS_EXPECTED_HERE)*/
    RefDS(_22024);
    _49CompileErr(32LL, _22024, 0LL);
L11: 

    /** parser.e:3543			if not find(tok[T_ID], ADDR_TOKS) then*/
    _2 = (object)SEQ_PTR(_tok_60175);
    _29964 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29965 = find_from(_29964, _29ADDR_TOKS_12010, 1LL);
    _29964 = NOVALUE;
    if (_29965 != 0)
    goto L12; // [538] 565
    _29965 = NOVALUE;

    /** parser.e:3544				CompileErr(FOUND__1__BUT_WAS_EXPECTING_AN_IDENTIFIER_NAME, {find_category(tok[T_ID])} )*/
    _2 = (object)SEQ_PTR(_tok_60175);
    _29967 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_29967);
    _29968 = _62find_category(_29967);
    _29967 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _29968;
    _29969 = MAKE_SEQ(_1);
    _29968 = NOVALUE;
    _49CompileErr(25LL, _29969, 0LL);
    _29969 = NOVALUE;
L12: 

    /** parser.e:3546			sym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_60175);
    _sym_60179 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_sym_60179)){
        _sym_60179 = (object)DBL_PTR(_sym_60179)->dbl;
    }

    /** parser.e:3547			DefinedYet(sym)*/
    _53DefinedYet(_sym_60179);

    /** parser.e:3548			if find(SymTab[sym][S_SCOPE], {SC_GLOBAL, SC_PREDEF, SC_PUBLIC, SC_EXPORT}) then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29971 = (object)*(((s1_ptr)_2)->base + _sym_60179);
    _2 = (object)SEQ_PTR(_29971);
    _29972 = (object)*(((s1_ptr)_2)->base + 4LL);
    _29971 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 6LL;
    ((intptr_t*)_2)[2] = 7LL;
    ((intptr_t*)_2)[3] = 13LL;
    ((intptr_t*)_2)[4] = 11LL;
    _29973 = MAKE_SEQ(_1);
    _29974 = find_from(_29972, _29973, 1LL);
    _29972 = NOVALUE;
    DeRefDS(_29973);
    _29973 = NOVALUE;
    if (_29974 == 0)
    {
        _29974 = NOVALUE;
        goto L13; // [614] 676
    }
    else{
        _29974 = NOVALUE;
    }

    /** parser.e:3549				h = SymTab[sym][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29975 = (object)*(((s1_ptr)_2)->base + _sym_60179);
    _2 = (object)SEQ_PTR(_29975);
    _h_60181 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (!IS_ATOM_INT(_h_60181)){
        _h_60181 = (object)DBL_PTR(_h_60181)->dbl;
    }
    _29975 = NOVALUE;

    /** parser.e:3551				sym = NewEntry(SymTab[sym][S_NAME], 0, 0, VARIABLE, h, buckets[h], 0)*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29977 = (object)*(((s1_ptr)_2)->base + _sym_60179);
    _2 = (object)SEQ_PTR(_29977);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _29978 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _29978 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _29977 = NOVALUE;
    _2 = (object)SEQ_PTR(_53buckets_46842);
    _29979 = (object)*(((s1_ptr)_2)->base + _h_60181);
    Ref(_29978);
    Ref(_29979);
    _sym_60179 = _53NewEntry(_29978, 0LL, 0LL, -100LL, _h_60181, _29979, 0LL);
    _29978 = NOVALUE;
    _29979 = NOVALUE;
    if (!IS_ATOM_INT(_sym_60179)) {
        _1 = (object)(DBL_PTR(_sym_60179)->dbl);
        DeRefDS(_sym_60179);
        _sym_60179 = _1;
    }

    /** parser.e:3552				buckets[h] = sym*/
    _2 = (object)SEQ_PTR(_53buckets_46842);
    _2 = (object)(((s1_ptr)_2)->base + _h_60181);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_60179;
    DeRef(_1);
L13: 

    /** parser.e:3555			new_symbols = append(new_symbols, sym)*/
    Append(&_new_symbols_60173, _new_symbols_60173, _sym_60179);

    /** parser.e:3556			Block_var( sym )*/
    _64Block_var(_sym_60179);

    /** parser.e:3557			if SymTab[sym][S_SCOPE] = SC_UNDEFINED and SymTab[sym][S_FILE_NO] != current_file_no then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29982 = (object)*(((s1_ptr)_2)->base + _sym_60179);
    _2 = (object)SEQ_PTR(_29982);
    _29983 = (object)*(((s1_ptr)_2)->base + 4LL);
    _29982 = NOVALUE;
    if (IS_ATOM_INT(_29983)) {
        _29984 = (_29983 == 9LL);
    }
    else {
        _29984 = binary_op(EQUALS, _29983, 9LL);
    }
    _29983 = NOVALUE;
    if (IS_ATOM_INT(_29984)) {
        if (_29984 == 0) {
            goto L14; // [707] 751
        }
    }
    else {
        if (DBL_PTR(_29984)->dbl == 0.0) {
            goto L14; // [707] 751
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29986 = (object)*(((s1_ptr)_2)->base + _sym_60179);
    _2 = (object)SEQ_PTR(_29986);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _29987 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _29987 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _29986 = NOVALUE;
    if (IS_ATOM_INT(_29987)) {
        _29988 = (_29987 != _12current_file_no_20226);
    }
    else {
        _29988 = binary_op(NOTEQ, _29987, _12current_file_no_20226);
    }
    _29987 = NOVALUE;
    if (_29988 == 0) {
        DeRef(_29988);
        _29988 = NOVALUE;
        goto L14; // [730] 751
    }
    else {
        if (!IS_ATOM_INT(_29988) && DBL_PTR(_29988)->dbl == 0.0){
            DeRef(_29988);
            _29988 = NOVALUE;
            goto L14; // [730] 751
        }
        DeRef(_29988);
        _29988 = NOVALUE;
    }
    DeRef(_29988);
    _29988 = NOVALUE;

    /** parser.e:3558				SymTab[sym][S_FILE_NO] = current_file_no*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60179 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_FILE_NO_19860))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12current_file_no_20226;
    DeRef(_1);
    _29989 = NOVALUE;
L14: 

    /** parser.e:3560			SymTab[sym][S_SCOPE] = scope*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60179 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _scope_60172;
    DeRef(_1);
    _29991 = NOVALUE;

    /** parser.e:3562			if type_ptr = 0 then*/
    if (_type_ptr_60171 != 0LL)
    goto L15; // [768] 1103

    /** parser.e:3564				SymTab[sym][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60179 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _29994 = NOVALUE;

    /** parser.e:3566				buckets[SymTab[sym][S_HASHVAL]] = SymTab[sym][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29996 = (object)*(((s1_ptr)_2)->base + _sym_60179);
    _2 = (object)SEQ_PTR(_29996);
    _29997 = (object)*(((s1_ptr)_2)->base + 11LL);
    _29996 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _29998 = (object)*(((s1_ptr)_2)->base + _sym_60179);
    _2 = (object)SEQ_PTR(_29998);
    _29999 = (object)*(((s1_ptr)_2)->base + 9LL);
    _29998 = NOVALUE;
    Ref(_29999);
    _2 = (object)SEQ_PTR(_53buckets_46842);
    if (!IS_ATOM_INT(_29997))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_29997)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _29997);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29999;
    if( _1 != _29999 ){
        DeRef(_1);
    }
    _29999 = NOVALUE;

    /** parser.e:3567				tok_match(EQUALS)*/
    _43tok_match(3LL, 0LL);

    /** parser.e:3568				StartSourceLine(FALSE, , COVERAGE_OVERRIDE)*/
    _45StartSourceLine(_9FALSE_444, 0LL, 3LL);

    /** parser.e:3569				emit_opnd(sym)*/
    _45emit_opnd(_sym_60179);

    /** parser.e:3570				Expr()  -- no new symbols can be defined in here*/
    _43Expr();

    /** parser.e:3571				buckets[SymTab[sym][S_HASHVAL]] = sym*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30000 = (object)*(((s1_ptr)_2)->base + _sym_60179);
    _2 = (object)SEQ_PTR(_30000);
    _30001 = (object)*(((s1_ptr)_2)->base + 11LL);
    _30000 = NOVALUE;
    _2 = (object)SEQ_PTR(_53buckets_46842);
    if (!IS_ATOM_INT(_30001))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_30001)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _30001);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_60179;
    DeRef(_1);

    /** parser.e:3572				SymTab[sym][S_USAGE] = U_WRITTEN*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60179 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _30002 = NOVALUE;

    /** parser.e:3573				if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L16; // [890] 928
    }
    else{
    }

    /** parser.e:3574					SymTab[sym][S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60179 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);
    _30004 = NOVALUE;

    /** parser.e:3575					SymTab[sym][S_OBJ] = NOVALUE     -- distinguish from literals*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60179 + ((s1_ptr)_2)->base);
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
    _30006 = NOVALUE;
L16: 

    /** parser.e:3577				valsym = Top()*/
    _valsym_60180 = _45Top();
    if (!IS_ATOM_INT(_valsym_60180)) {
        _1 = (object)(DBL_PTR(_valsym_60180)->dbl);
        DeRefDS(_valsym_60180);
        _valsym_60180 = _1;
    }

    /** parser.e:3579				if valsym > 0 and compare( SymTab[valsym][S_OBJ], NOVALUE ) then*/
    _30009 = (_valsym_60180 > 0LL);
    if (_30009 == 0) {
        goto L17; // [941] 982
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30011 = (object)*(((s1_ptr)_2)->base + _valsym_60180);
    _2 = (object)SEQ_PTR(_30011);
    _30012 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30011 = NOVALUE;
    if (IS_ATOM_INT(_30012) && IS_ATOM_INT(_12NOVALUE_20081)){
        _30013 = (_30012 < _12NOVALUE_20081) ? -1 : (_30012 > _12NOVALUE_20081);
    }
    else{
        _30013 = compare(_30012, _12NOVALUE_20081);
    }
    _30012 = NOVALUE;
    if (_30013 == 0)
    {
        _30013 = NOVALUE;
        goto L17; // [964] 982
    }
    else{
        _30013 = NOVALUE;
    }

    /** parser.e:3580					Assign_Constant( sym )*/
    _43Assign_Constant(_sym_60179);

    /** parser.e:3581					sym = Pop()*/
    _sym_60179 = _45Pop();
    if (!IS_ATOM_INT(_sym_60179)) {
        _1 = (object)(DBL_PTR(_sym_60179)->dbl);
        DeRefDS(_sym_60179);
        _sym_60179 = _1;
    }
    goto L18; // [979] 2269
L17: 

    /** parser.e:3584					emit_op(ASSIGN)*/
    _45emit_op(18LL);

    /** parser.e:3585					if Last_op() = ASSIGN then*/
    _30015 = _45Last_op();
    if (binary_op_a(NOTEQ, _30015, 18LL)){
        DeRef(_30015);
        _30015 = NOVALUE;
        goto L19; // [996] 1010
    }
    DeRef(_30015);
    _30015 = NOVALUE;

    /** parser.e:3586						valsym = get_assigned_sym()*/
    _valsym_60180 = _43get_assigned_sym();
    if (!IS_ATOM_INT(_valsym_60180)) {
        _1 = (object)(DBL_PTR(_valsym_60180)->dbl);
        DeRefDS(_valsym_60180);
        _valsym_60180 = _1;
    }
    goto L1A; // [1007] 1018
L19: 

    /** parser.e:3589						valsym = -1*/
    _valsym_60180 = -1LL;
L1A: 

    /** parser.e:3591					if valsym > 0 and compare( SymTab[valsym][S_OBJ], NOVALUE ) then*/
    _30018 = (_valsym_60180 > 0LL);
    if (_30018 == 0) {
        goto L1B; // [1024] 1066
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30020 = (object)*(((s1_ptr)_2)->base + _valsym_60180);
    _2 = (object)SEQ_PTR(_30020);
    _30021 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30020 = NOVALUE;
    if (IS_ATOM_INT(_30021) && IS_ATOM_INT(_12NOVALUE_20081)){
        _30022 = (_30021 < _12NOVALUE_20081) ? -1 : (_30021 > _12NOVALUE_20081);
    }
    else{
        _30022 = compare(_30021, _12NOVALUE_20081);
    }
    _30021 = NOVALUE;
    if (_30022 == 0)
    {
        _30022 = NOVALUE;
        goto L1B; // [1047] 1066
    }
    else{
        _30022 = NOVALUE;
    }

    /** parser.e:3593						SymTab[sym][S_CODE] = valsym*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60179 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_19876))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _valsym_60180;
    DeRef(_1);
    _30023 = NOVALUE;
L1B: 

    /** parser.e:3596					if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L18; // [1070] 2269
    }
    else{
    }

    /** parser.e:3597						count += 1*/
    _count_60182 = _count_60182 + 1;

    /** parser.e:3598						if count = 10 then*/
    if (_count_60182 != 10LL)
    goto L18; // [1081] 2269

    /** parser.e:3599							count = 0*/
    _count_60182 = 0LL;

    /** parser.e:3601							emit_op( RETURNT )*/
    _45emit_op(34LL);
    goto L18; // [1100] 2269
L15: 

    /** parser.e:3606			elsif type_ptr = -1 and not is_fwd_ref then*/
    _30027 = (_type_ptr_60171 == -1LL);
    if (_30027 == 0) {
        goto L1C; // [1109] 2096
    }
    _30029 = (_is_fwd_ref_60187 == 0);
    if (_30029 == 0)
    {
        DeRef(_30029);
        _30029 = NOVALUE;
        goto L1C; // [1117] 2096
    }
    else{
        DeRef(_30029);
        _30029 = NOVALUE;
    }

    /** parser.e:3608				StartSourceLine(FALSE, , COVERAGE_OVERRIDE )*/
    _45StartSourceLine(_9FALSE_444, 0LL, 3LL);

    /** parser.e:3609				SymTab[sym][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60179 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _30030 = NOVALUE;

    /** parser.e:3611				buckets[SymTab[sym][S_HASHVAL]] = SymTab[sym][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30032 = (object)*(((s1_ptr)_2)->base + _sym_60179);
    _2 = (object)SEQ_PTR(_30032);
    _30033 = (object)*(((s1_ptr)_2)->base + 11LL);
    _30032 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30034 = (object)*(((s1_ptr)_2)->base + _sym_60179);
    _2 = (object)SEQ_PTR(_30034);
    _30035 = (object)*(((s1_ptr)_2)->base + 9LL);
    _30034 = NOVALUE;
    Ref(_30035);
    _2 = (object)SEQ_PTR(_53buckets_46842);
    if (!IS_ATOM_INT(_30033))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_30033)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _30033);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30035;
    if( _1 != _30035 ){
        DeRef(_1);
    }
    _30035 = NOVALUE;

    /** parser.e:3612				tok = next_token()*/
    _0 = _tok_60175;
    _tok_60175 = _43next_token();
    DeRef(_0);

    /** parser.e:3615				emit_opnd(sym)*/
    _45emit_opnd(_sym_60179);

    /** parser.e:3617				if tok[T_ID] = EQUALS then*/
    _2 = (object)SEQ_PTR(_tok_60175);
    _30037 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30037, 3LL)){
        _30037 = NOVALUE;
        goto L1D; // [1200] 1607
    }
    _30037 = NOVALUE;

    /** parser.e:3618					integer negate = 1*/
    _negate_60470 = 1LL;

    /** parser.e:3620					tok = next_token()*/
    _0 = _tok_60175;
    _tok_60175 = _43next_token();
    DeRef(_0);

    /** parser.e:3621					if tok[T_ID] = MINUS then*/
    _2 = (object)SEQ_PTR(_tok_60175);
    _30040 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30040, 10LL)){
        _30040 = NOVALUE;
        goto L1E; // [1224] 1239
    }
    _30040 = NOVALUE;

    /** parser.e:3622						negate = -1*/
    _negate_60470 = -1LL;

    /** parser.e:3623						tok = next_token()*/
    _0 = _tok_60175;
    _tok_60175 = _43next_token();
    DeRef(_0);
L1E: 

    /** parser.e:3626					if tok[T_ID] = ATOM then*/
    _2 = (object)SEQ_PTR(_tok_60175);
    _30043 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30043, 502LL)){
        _30043 = NOVALUE;
        goto L1F; // [1249] 1266
    }
    _30043 = NOVALUE;

    /** parser.e:3627						valsym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_60175);
    _valsym_60180 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_valsym_60180)){
        _valsym_60180 = (object)DBL_PTR(_valsym_60180)->dbl;
    }
    goto L20; // [1263] 1464
L1F: 

    /** parser.e:3628					elsif tok[T_SYM] > 0 then*/
    _2 = (object)SEQ_PTR(_tok_60175);
    _30046 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (binary_op_a(LESSEQ, _30046, 0LL)){
        _30046 = NOVALUE;
        goto L21; // [1274] 1454
    }
    _30046 = NOVALUE;

    /** parser.e:3629						tsym = SymTab[tok[T_SYM]]*/
    _2 = (object)SEQ_PTR(_tok_60175);
    _30048 = (object)*(((s1_ptr)_2)->base + 2LL);
    DeRef(_tsym_60176);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_30048)){
        _tsym_60176 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30048)->dbl));
    }
    else{
        _tsym_60176 = (object)*(((s1_ptr)_2)->base + _30048);
    }
    Ref(_tsym_60176);

    /** parser.e:3630						if tsym[S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_tsym_60176);
    _30050 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (binary_op_a(NOTEQ, _30050, 2LL)){
        _30050 = NOVALUE;
        goto L22; // [1302] 1415
    }
    _30050 = NOVALUE;

    /** parser.e:3631							if length(tsym) >= S_CODE and tsym[S_CODE] then*/
    if (IS_SEQUENCE(_tsym_60176)){
            _30052 = SEQ_PTR(_tsym_60176)->length;
    }
    else {
        _30052 = 1;
    }
    if (IS_ATOM_INT(_12S_CODE_19876)) {
        _30053 = (_30052 >= _12S_CODE_19876);
    }
    else {
        _30053 = binary_op(GREATEREQ, _30052, _12S_CODE_19876);
    }
    _30052 = NOVALUE;
    if (IS_ATOM_INT(_30053)) {
        if (_30053 == 0) {
            goto L23; // [1317] 1344
        }
    }
    else {
        if (DBL_PTR(_30053)->dbl == 0.0) {
            goto L23; // [1317] 1344
        }
    }
    _2 = (object)SEQ_PTR(_tsym_60176);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _30055 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _30055 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    if (_30055 == 0) {
        _30055 = NOVALUE;
        goto L23; // [1328] 1344
    }
    else {
        if (!IS_ATOM_INT(_30055) && DBL_PTR(_30055)->dbl == 0.0){
            _30055 = NOVALUE;
            goto L23; // [1328] 1344
        }
        _30055 = NOVALUE;
    }
    _30055 = NOVALUE;

    /** parser.e:3632								valsym = tsym[S_CODE]*/
    _2 = (object)SEQ_PTR(_tsym_60176);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _valsym_60180 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _valsym_60180 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    if (!IS_ATOM_INT(_valsym_60180)){
        _valsym_60180 = (object)DBL_PTR(_valsym_60180)->dbl;
    }
    goto L20; // [1341] 1464
L23: 

    /** parser.e:3634							elsif not equal( tsym[S_OBJ], NOVALUE ) then*/
    _2 = (object)SEQ_PTR(_tsym_60176);
    _30057 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (_30057 == _12NOVALUE_20081)
    _30058 = 1;
    else if (IS_ATOM_INT(_30057) && IS_ATOM_INT(_12NOVALUE_20081))
    _30058 = 0;
    else
    _30058 = (compare(_30057, _12NOVALUE_20081) == 0);
    _30057 = NOVALUE;
    if (_30058 != 0)
    goto L24; // [1358] 1402
    _30058 = NOVALUE;

    /** parser.e:3635								if is_integer(tsym[S_OBJ]) then*/
    _2 = (object)SEQ_PTR(_tsym_60176);
    _30060 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_30060);
    _30061 = _12is_integer(_30060);
    _30060 = NOVALUE;
    if (_30061 == 0) {
        DeRef(_30061);
        _30061 = NOVALUE;
        goto L25; // [1373] 1389
    }
    else {
        if (!IS_ATOM_INT(_30061) && DBL_PTR(_30061)->dbl == 0.0){
            DeRef(_30061);
            _30061 = NOVALUE;
            goto L25; // [1373] 1389
        }
        DeRef(_30061);
        _30061 = NOVALUE;
    }
    DeRef(_30061);
    _30061 = NOVALUE;

    /** parser.e:3636									valsym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_60175);
    _valsym_60180 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_valsym_60180)){
        _valsym_60180 = (object)DBL_PTR(_valsym_60180)->dbl;
    }
    goto L20; // [1386] 1464
L25: 

    /** parser.e:3638									CompileErr(AN_ENUM_CONSTANT_MUST_BE_AN_INTEGER)*/
    RefDS(_22024);
    _49CompileErr(30LL, _22024, 0LL);
    goto L20; // [1399] 1464
L24: 

    /** parser.e:3641								CompileErr(ENUM_CONSTANTS_MUST_BE_ASSIGNED_AN_INTEGER)*/
    RefDS(_22024);
    _49CompileErr(70LL, _22024, 0LL);
    goto L20; // [1412] 1464
L22: 

    /** parser.e:3643						elsif tsym[S_OBJ] = NOVALUE then*/
    _2 = (object)SEQ_PTR(_tsym_60176);
    _30063 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30063, _12NOVALUE_20081)){
        _30063 = NOVALUE;
        goto L26; // [1425] 1441
    }
    _30063 = NOVALUE;

    /** parser.e:3645							CompileErr(ENUM_FWD_REFERENCES_NOT_SUPPORTED)*/
    RefDS(_22024);
    _49CompileErr(331LL, _22024, 0LL);
    goto L20; // [1438] 1464
L26: 

    /** parser.e:3647							CompileErr(INTEGER_OR_CONSTANT_EXPECTED)*/
    RefDS(_22024);
    _49CompileErr(99LL, _22024, 0LL);
    goto L20; // [1451] 1464
L21: 

    /** parser.e:3651							CompileErr(INTEGER_OR_CONSTANT_EXPECTED)*/
    RefDS(_22024);
    _49CompileErr(99LL, _22024, 0LL);
L20: 

    /** parser.e:3653					valsym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_60175);
    _valsym_60180 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_valsym_60180)){
        _valsym_60180 = (object)DBL_PTR(_valsym_60180)->dbl;
    }

    /** parser.e:3654					if not atom( SymTab[valsym][S_OBJ] ) and tsym[S_SCOPE] != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30066 = (object)*(((s1_ptr)_2)->base + _valsym_60180);
    _2 = (object)SEQ_PTR(_30066);
    _30067 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30066 = NOVALUE;
    _30068 = IS_ATOM(_30067);
    _30067 = NOVALUE;
    _30069 = (_30068 == 0);
    _30068 = NOVALUE;
    if (_30069 == 0) {
        goto L27; // [1494] 1526
    }
    _2 = (object)SEQ_PTR(_tsym_60176);
    _30071 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_30071)) {
        _30072 = (_30071 != 9LL);
    }
    else {
        _30072 = binary_op(NOTEQ, _30071, 9LL);
    }
    _30071 = NOVALUE;
    if (_30072 == 0) {
        DeRef(_30072);
        _30072 = NOVALUE;
        goto L27; // [1513] 1526
    }
    else {
        if (!IS_ATOM_INT(_30072) && DBL_PTR(_30072)->dbl == 0.0){
            DeRef(_30072);
            _30072 = NOVALUE;
            goto L27; // [1513] 1526
        }
        DeRef(_30072);
        _30072 = NOVALUE;
    }
    DeRef(_30072);
    _30072 = NOVALUE;

    /** parser.e:3655						CompileErr(ENUM_CONSTANTS_MUST_BE_INTEGERS)*/
    RefDS(_22024);
    _49CompileErr(84LL, _22024, 0LL);
L27: 

    /** parser.e:3657					val = SymTab[valsym][S_OBJ] * negate*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30073 = (object)*(((s1_ptr)_2)->base + _valsym_60180);
    _2 = (object)SEQ_PTR(_30073);
    _30074 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30073 = NOVALUE;
    DeRef(_val_60183);
    if (IS_ATOM_INT(_30074)) {
        {
            int128_t p128 = (int128_t)_30074 * (int128_t)_negate_60470;
            if( p128 != (int128_t)(_val_60183 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _val_60183 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _val_60183 = binary_op(MULTIPLY, _30074, _negate_60470);
    }
    _30074 = NOVALUE;

    /** parser.e:3658					if is_integer(val) then*/
    Ref(_val_60183);
    _30076 = _12is_integer(_val_60183);
    if (_30076 == 0) {
        DeRef(_30076);
        _30076 = NOVALUE;
        goto L28; // [1550] 1565
    }
    else {
        if (!IS_ATOM_INT(_30076) && DBL_PTR(_30076)->dbl == 0.0){
            DeRef(_30076);
            _30076 = NOVALUE;
            goto L28; // [1550] 1565
        }
        DeRef(_30076);
        _30076 = NOVALUE;
    }
    DeRef(_30076);
    _30076 = NOVALUE;

    /** parser.e:3659						Push(NewIntSym(val))*/
    Ref(_val_60183);
    _30077 = _53NewIntSym(_val_60183);
    _45Push(_30077);
    _30077 = NOVALUE;
    goto L29; // [1562] 1575
L28: 

    /** parser.e:3661						Push(NewDoubleSym(val))*/
    Ref(_val_60183);
    _30078 = _53NewDoubleSym(_val_60183);
    _45Push(_30078);
    _30078 = NOVALUE;
L29: 

    /** parser.e:3663					usedval = val*/
    Ref(_val_60183);
    DeRef(_usedval_60184);
    _usedval_60184 = _val_60183;

    /** parser.e:3664					if deltafunc = '+' then*/
    if (_deltafunc_60185 != 43LL)
    goto L2A; // [1582] 1595

    /** parser.e:3665						val += delta*/
    _0 = _val_60183;
    if (IS_ATOM_INT(_val_60183) && IS_ATOM_INT(_delta_60186)) {
        _val_60183 = _val_60183 + _delta_60186;
        if ((object)((uintptr_t)_val_60183 + (uintptr_t)HIGH_BITS) >= 0){
            _val_60183 = NewDouble((eudouble)_val_60183);
        }
    }
    else {
        if (IS_ATOM_INT(_val_60183)) {
            _val_60183 = NewDouble((eudouble)_val_60183 + DBL_PTR(_delta_60186)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_60186)) {
                _val_60183 = NewDouble(DBL_PTR(_val_60183)->dbl + (eudouble)_delta_60186);
            }
            else
            _val_60183 = NewDouble(DBL_PTR(_val_60183)->dbl + DBL_PTR(_delta_60186)->dbl);
        }
    }
    DeRef(_0);
    goto L2B; // [1592] 1602
L2A: 

    /** parser.e:3667						val *= delta*/
    _0 = _val_60183;
    if (IS_ATOM_INT(_val_60183) && IS_ATOM_INT(_delta_60186)) {
        {
            int128_t p128 = (int128_t)_val_60183 * (int128_t)_delta_60186;
            if( p128 != (int128_t)(_val_60183 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _val_60183 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        if (IS_ATOM_INT(_val_60183)) {
            _val_60183 = NewDouble((eudouble)_val_60183 * DBL_PTR(_delta_60186)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_60186)) {
                _val_60183 = NewDouble(DBL_PTR(_val_60183)->dbl * (eudouble)_delta_60186);
            }
            else
            _val_60183 = NewDouble(DBL_PTR(_val_60183)->dbl * DBL_PTR(_delta_60186)->dbl);
        }
    }
    DeRef(_0);
L2B: 
    goto L2C; // [1604] 1678
L1D: 

    /** parser.e:3670					putback(tok)*/
    Ref(_tok_60175);
    _43putback(_tok_60175);

    /** parser.e:3671					if is_integer(val) then*/
    Ref(_val_60183);
    _30082 = _12is_integer(_val_60183);
    if (_30082 == 0) {
        DeRef(_30082);
        _30082 = NOVALUE;
        goto L2D; // [1618] 1633
    }
    else {
        if (!IS_ATOM_INT(_30082) && DBL_PTR(_30082)->dbl == 0.0){
            DeRef(_30082);
            _30082 = NOVALUE;
            goto L2D; // [1618] 1633
        }
        DeRef(_30082);
        _30082 = NOVALUE;
    }
    DeRef(_30082);
    _30082 = NOVALUE;

    /** parser.e:3672						Push(NewIntSym(val))*/
    Ref(_val_60183);
    _30083 = _53NewIntSym(_val_60183);
    _45Push(_30083);
    _30083 = NOVALUE;
    goto L2E; // [1630] 1643
L2D: 

    /** parser.e:3674						Push(NewDoubleSym(val))*/
    Ref(_val_60183);
    _30084 = _53NewDoubleSym(_val_60183);
    _45Push(_30084);
    _30084 = NOVALUE;
L2E: 

    /** parser.e:3676					usedval = val*/
    Ref(_val_60183);
    DeRef(_usedval_60184);
    _usedval_60184 = _val_60183;

    /** parser.e:3677					if deltafunc = '+' then*/
    if (_deltafunc_60185 != 43LL)
    goto L2F; // [1650] 1663

    /** parser.e:3678						val += delta*/
    _0 = _val_60183;
    if (IS_ATOM_INT(_val_60183) && IS_ATOM_INT(_delta_60186)) {
        _val_60183 = _val_60183 + _delta_60186;
        if ((object)((uintptr_t)_val_60183 + (uintptr_t)HIGH_BITS) >= 0){
            _val_60183 = NewDouble((eudouble)_val_60183);
        }
    }
    else {
        if (IS_ATOM_INT(_val_60183)) {
            _val_60183 = NewDouble((eudouble)_val_60183 + DBL_PTR(_delta_60186)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_60186)) {
                _val_60183 = NewDouble(DBL_PTR(_val_60183)->dbl + (eudouble)_delta_60186);
            }
            else
            _val_60183 = NewDouble(DBL_PTR(_val_60183)->dbl + DBL_PTR(_delta_60186)->dbl);
        }
    }
    DeRef(_0);
    goto L30; // [1660] 1670
L2F: 

    /** parser.e:3680						val *= delta*/
    _0 = _val_60183;
    if (IS_ATOM_INT(_val_60183) && IS_ATOM_INT(_delta_60186)) {
        {
            int128_t p128 = (int128_t)_val_60183 * (int128_t)_delta_60186;
            if( p128 != (int128_t)(_val_60183 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _val_60183 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        if (IS_ATOM_INT(_val_60183)) {
            _val_60183 = NewDouble((eudouble)_val_60183 * DBL_PTR(_delta_60186)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_60186)) {
                _val_60183 = NewDouble(DBL_PTR(_val_60183)->dbl * (eudouble)_delta_60186);
            }
            else
            _val_60183 = NewDouble(DBL_PTR(_val_60183)->dbl * DBL_PTR(_delta_60186)->dbl);
        }
    }
    DeRef(_0);
L30: 

    /** parser.e:3682					valsym = 0*/
    _valsym_60180 = 0LL;
L2C: 

    /** parser.e:3684				buckets[SymTab[sym][S_HASHVAL]] = sym*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30088 = (object)*(((s1_ptr)_2)->base + _sym_60179);
    _2 = (object)SEQ_PTR(_30088);
    _30089 = (object)*(((s1_ptr)_2)->base + 11LL);
    _30088 = NOVALUE;
    _2 = (object)SEQ_PTR(_53buckets_46842);
    if (!IS_ATOM_INT(_30089))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_30089)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _30089);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_60179;
    DeRef(_1);

    /** parser.e:3685				SymTab[sym][S_USAGE] = U_WRITTEN*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60179 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _30090 = NOVALUE;

    /** parser.e:3687				if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L31; // [1719] 1757
    }
    else{
    }

    /** parser.e:3688					SymTab[sym][S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60179 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);
    _30092 = NOVALUE;

    /** parser.e:3689					SymTab[sym][S_OBJ] = NOVALUE     -- distinguish from literals*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60179 + ((s1_ptr)_2)->base);
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
    _30094 = NOVALUE;
L31: 

    /** parser.e:3692				if valsym < 0 then*/
    if (_valsym_60180 >= 0LL)
    goto L32; // [1759] 1764
L32: 

    /** parser.e:3697				if valsym and compare( SymTab[valsym][S_OBJ], NOVALUE ) then*/
    if (_valsym_60180 == 0) {
        goto L33; // [1766] 1946
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30098 = (object)*(((s1_ptr)_2)->base + _valsym_60180);
    _2 = (object)SEQ_PTR(_30098);
    _30099 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30098 = NOVALUE;
    if (IS_ATOM_INT(_30099) && IS_ATOM_INT(_12NOVALUE_20081)){
        _30100 = (_30099 < _12NOVALUE_20081) ? -1 : (_30099 > _12NOVALUE_20081);
    }
    else{
        _30100 = compare(_30099, _12NOVALUE_20081);
    }
    _30099 = NOVALUE;
    if (_30100 == 0)
    {
        _30100 = NOVALUE;
        goto L33; // [1789] 1946
    }
    else{
        _30100 = NOVALUE;
    }

    /** parser.e:3699					SymTab[sym][S_CODE] = valsym*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60179 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_19876))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _valsym_60180;
    DeRef(_1);
    _30101 = NOVALUE;

    /** parser.e:3700					SymTab[sym][S_OBJ]  = usedval*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60179 + ((s1_ptr)_2)->base);
    Ref(_usedval_60184);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60184;
    DeRef(_1);
    _30103 = NOVALUE;

    /** parser.e:3702					if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L34; // [1828] 2079
    }
    else{
    }

    /** parser.e:3704						SymTab[sym][S_GTYPE] = SymTab[valsym][S_GTYPE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60179 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30107 = (object)*(((s1_ptr)_2)->base + _valsym_60180);
    _2 = (object)SEQ_PTR(_30107);
    _30108 = (object)*(((s1_ptr)_2)->base + 36LL);
    _30107 = NOVALUE;
    Ref(_30108);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30108;
    if( _1 != _30108 ){
        DeRef(_1);
    }
    _30108 = NOVALUE;
    _30105 = NOVALUE;

    /** parser.e:3705						SymTab[sym][S_SEQ_ELEM] = SymTab[valsym][S_SEQ_ELEM]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60179 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30111 = (object)*(((s1_ptr)_2)->base + _valsym_60180);
    _2 = (object)SEQ_PTR(_30111);
    _30112 = (object)*(((s1_ptr)_2)->base + 33LL);
    _30111 = NOVALUE;
    Ref(_30112);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30112;
    if( _1 != _30112 ){
        DeRef(_1);
    }
    _30112 = NOVALUE;
    _30109 = NOVALUE;

    /** parser.e:3706						SymTab[sym][S_OBJ_MIN] = usedval*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60179 + ((s1_ptr)_2)->base);
    Ref(_usedval_60184);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60184;
    DeRef(_1);
    _30113 = NOVALUE;

    /** parser.e:3707						SymTab[sym][S_OBJ_MAX] = usedval*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60179 + ((s1_ptr)_2)->base);
    Ref(_usedval_60184);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60184;
    DeRef(_1);
    _30115 = NOVALUE;

    /** parser.e:3708						SymTab[sym][S_SEQ_LEN] = SymTab[valsym][S_SEQ_LEN]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60179 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30119 = (object)*(((s1_ptr)_2)->base + _valsym_60180);
    _2 = (object)SEQ_PTR(_30119);
    _30120 = (object)*(((s1_ptr)_2)->base + 32LL);
    _30119 = NOVALUE;
    Ref(_30120);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30120;
    if( _1 != _30120 ){
        DeRef(_1);
    }
    _30120 = NOVALUE;
    _30117 = NOVALUE;
    goto L34; // [1943] 2079
L33: 

    /** parser.e:3711					SymTab[sym][S_OBJ] = usedval*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60179 + ((s1_ptr)_2)->base);
    Ref(_usedval_60184);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60184;
    DeRef(_1);
    _30121 = NOVALUE;

    /** parser.e:3712					if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L35; // [1967] 2078
    }
    else{
    }

    /** parser.e:3714						if is_integer( usedval ) then*/
    Ref(_usedval_60184);
    _30123 = _12is_integer(_usedval_60184);
    if (_30123 == 0) {
        DeRef(_30123);
        _30123 = NOVALUE;
        goto L36; // [1976] 1999
    }
    else {
        if (!IS_ATOM_INT(_30123) && DBL_PTR(_30123)->dbl == 0.0){
            DeRef(_30123);
            _30123 = NOVALUE;
            goto L36; // [1976] 1999
        }
        DeRef(_30123);
        _30123 = NOVALUE;
    }
    DeRef(_30123);
    _30123 = NOVALUE;

    /** parser.e:3715							SymTab[sym][S_GTYPE] = TYPE_INTEGER*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60179 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _30124 = NOVALUE;
    goto L37; // [1996] 2017
L36: 

    /** parser.e:3717							SymTab[sym][S_GTYPE] = TYPE_DOUBLE*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60179 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _30126 = NOVALUE;
L37: 

    /** parser.e:3719						SymTab[sym][S_SEQ_ELEM] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60179 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30128 = NOVALUE;

    /** parser.e:3720						SymTab[sym][S_OBJ_MIN] = usedval*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60179 + ((s1_ptr)_2)->base);
    Ref(_usedval_60184);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60184;
    DeRef(_1);
    _30130 = NOVALUE;

    /** parser.e:3721						SymTab[sym][S_OBJ_MAX] = usedval*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60179 + ((s1_ptr)_2)->base);
    Ref(_usedval_60184);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60184;
    DeRef(_1);
    _30132 = NOVALUE;

    /** parser.e:3722						SymTab[sym][S_SEQ_LEN] = 0 --SymTab[valsym][S_SEQ_LEN]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60179 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30134 = NOVALUE;
L35: 
L34: 

    /** parser.e:3725				valsym = Pop()*/
    _valsym_60180 = _45Pop();
    if (!IS_ATOM_INT(_valsym_60180)) {
        _1 = (object)(DBL_PTR(_valsym_60180)->dbl);
        DeRefDS(_valsym_60180);
        _valsym_60180 = _1;
    }

    /** parser.e:3726				valsym = Pop()*/
    _valsym_60180 = _45Pop();
    if (!IS_ATOM_INT(_valsym_60180)) {
        _1 = (object)(DBL_PTR(_valsym_60180)->dbl);
        DeRefDS(_valsym_60180);
        _valsym_60180 = _1;
    }
    goto L18; // [2093] 2269
L1C: 

    /** parser.e:3729				SymTab[sym][S_MODE] = M_NORMAL*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60179 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _30138 = NOVALUE;

    /** parser.e:3730				if type_ptr > 0 and SymTab[type_ptr][S_TOKEN] = OBJECT then*/
    _30140 = (_type_ptr_60171 > 0LL);
    if (_30140 == 0) {
        goto L38; // [2119] 2165
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30142 = (object)*(((s1_ptr)_2)->base + _type_ptr_60171);
    _2 = (object)SEQ_PTR(_30142);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _30143 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _30143 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _30142 = NOVALUE;
    if (IS_ATOM_INT(_30143)) {
        _30144 = (_30143 == 415LL);
    }
    else {
        _30144 = binary_op(EQUALS, _30143, 415LL);
    }
    _30143 = NOVALUE;
    if (_30144 == 0) {
        DeRef(_30144);
        _30144 = NOVALUE;
        goto L38; // [2142] 2165
    }
    else {
        if (!IS_ATOM_INT(_30144) && DBL_PTR(_30144)->dbl == 0.0){
            DeRef(_30144);
            _30144 = NOVALUE;
            goto L38; // [2142] 2165
        }
        DeRef(_30144);
        _30144 = NOVALUE;
    }
    DeRef(_30144);
    _30144 = NOVALUE;

    /** parser.e:3731					SymTab[sym][S_VTYPE] = object_type*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60179 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _53object_type_46846;
    DeRef(_1);
    _30145 = NOVALUE;
    goto L39; // [2162] 2194
L38: 

    /** parser.e:3733					SymTab[sym][S_VTYPE] = type_ptr*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60179 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _type_ptr_60171;
    DeRef(_1);
    _30147 = NOVALUE;

    /** parser.e:3734					if type_ptr < 0 then*/
    if (_type_ptr_60171 >= 0LL)
    goto L3A; // [2182] 2193

    /** parser.e:3735						register_forward_type( sym, type_ptr )*/
    _42register_forward_type(_sym_60179, _type_ptr_60171);
L3A: 
L39: 

    /** parser.e:3739				if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L3B; // [2198] 2221
    }
    else{
    }

    /** parser.e:3740					SymTab[sym][S_GTYPE] = CompileType(type_ptr)*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60179 + ((s1_ptr)_2)->base);
    _30152 = _43CompileType(_type_ptr_60171);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30152;
    if( _1 != _30152 ){
        DeRef(_1);
    }
    _30152 = NOVALUE;
    _30150 = NOVALUE;
L3B: 

    /** parser.e:3743		   		tok = next_token()*/
    _0 = _tok_60175;
    _tok_60175 = _43next_token();
    DeRef(_0);

    /** parser.e:3744	   			putback(tok)*/
    Ref(_tok_60175);
    _43putback(_tok_60175);

    /** parser.e:3745		   		if tok[T_ID] = EQUALS then -- assign on declare*/
    _2 = (object)SEQ_PTR(_tok_60175);
    _30154 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30154, 3LL)){
        _30154 = NOVALUE;
        goto L3C; // [2241] 2268
    }
    _30154 = NOVALUE;

    /** parser.e:3746		   			StartSourceLine( FALSE, , COVERAGE_OVERRIDE )*/
    _45StartSourceLine(_9FALSE_444, 0LL, 3LL);

    /** parser.e:3747		   			Assignment({VARIABLE,sym})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100LL;
    ((intptr_t *)_2)[2] = _sym_60179;
    _30156 = MAKE_SEQ(_1);
    _43Assignment(_30156);
    _30156 = NOVALUE;
L3C: 
L18: 

    /** parser.e:3750			tok = next_token()*/
    _0 = _tok_60175;
    _tok_60175 = _43next_token();
    DeRef(_0);

    /** parser.e:3751			if tok[T_ID] != COMMA then*/
    _2 = (object)SEQ_PTR(_tok_60175);
    _30158 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _30158, -30LL)){
        _30158 = NOVALUE;
        goto L3D; // [2284] 2293
    }
    _30158 = NOVALUE;

    /** parser.e:3752				exit*/
    goto LD; // [2290] 2303
L3D: 

    /** parser.e:3754			prevtok = tok*/
    Ref(_tok_60175);
    DeRef(_prevtok_60177);
    _prevtok_60177 = _tok_60175;

    /** parser.e:3755		end while*/
    goto LC; // [2300] 440
LD: 

    /** parser.e:3756		putback(tok)*/
    Ref(_tok_60175);
    _43putback(_tok_60175);

    /** parser.e:3757		return new_symbols*/
    DeRef(_tok_60175);
    DeRef(_tsym_60176);
    DeRef(_prevtok_60177);
    DeRef(_val_60183);
    DeRef(_usedval_60184);
    DeRef(_delta_60186);
    DeRef(_30027);
    _30027 = NOVALUE;
    DeRef(_29984);
    _29984 = NOVALUE;
    DeRef(_30069);
    _30069 = NOVALUE;
    _29997 = NOVALUE;
    _30033 = NOVALUE;
    DeRef(_30140);
    _30140 = NOVALUE;
    DeRef(_30009);
    _30009 = NOVALUE;
    DeRef(_30053);
    _30053 = NOVALUE;
    DeRef(_30018);
    _30018 = NOVALUE;
    _29946 = NOVALUE;
    _30001 = NOVALUE;
    _30089 = NOVALUE;
    DeRef(_29918);
    _29918 = NOVALUE;
    _30048 = NOVALUE;
    return _new_symbols_60173;
    ;
}


void _43Private_declaration(object _type_sym_60761)
{
    object _tok_60763 = NOVALUE;
    object _sym_60765 = NOVALUE;
    object _31775 = NOVALUE;
    object _31774 = NOVALUE;
    object _31773 = NOVALUE;
    object _30184 = NOVALUE;
    object _30182 = NOVALUE;
    object _30180 = NOVALUE;
    object _30178 = NOVALUE;
    object _30176 = NOVALUE;
    object _30174 = NOVALUE;
    object _30172 = NOVALUE;
    object _30169 = NOVALUE;
    object _30167 = NOVALUE;
    object _30166 = NOVALUE;
    object _30163 = NOVALUE;
    object _30161 = NOVALUE;
    object _30160 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_type_sym_60761)) {
        _1 = (object)(DBL_PTR(_type_sym_60761)->dbl);
        DeRefDS(_type_sym_60761);
        _type_sym_60761 = _1;
    }

    /** parser.e:3765		if SymTab[type_sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30160 = (object)*(((s1_ptr)_2)->base + _type_sym_60761);
    _2 = (object)SEQ_PTR(_30160);
    _30161 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30160 = NOVALUE;
    if (binary_op_a(NOTEQ, _30161, 9LL)){
        _30161 = NOVALUE;
        goto L1; // [19] 47
    }
    _30161 = NOVALUE;

    /** parser.e:3766			Hide( type_sym )*/
    _53Hide(_type_sym_60761);

    /** parser.e:3767			type_sym = -new_forward_reference( TYPE, type_sym )*/
    _31775 = 504LL;
    _30163 = _42new_forward_reference(504LL, _type_sym_60761, 504LL);
    _31775 = NOVALUE;
    if (IS_ATOM_INT(_30163)) {
        if ((uintptr_t)_30163 == (uintptr_t)HIGH_BITS){
            _type_sym_60761 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _type_sym_60761 = - _30163;
        }
    }
    else {
        _type_sym_60761 = unary_op(UMINUS, _30163);
    }
    DeRef(_30163);
    _30163 = NOVALUE;
    if (!IS_ATOM_INT(_type_sym_60761)) {
        _1 = (object)(DBL_PTR(_type_sym_60761)->dbl);
        DeRefDS(_type_sym_60761);
        _type_sym_60761 = _1;
    }
L1: 

    /** parser.e:3770		while TRUE do*/
L2: 
    if (_9TRUE_446 == 0)
    {
        goto L3; // [54] 257
    }
    else{
    }

    /** parser.e:3771			tok = next_token()*/
    _0 = _tok_60763;
    _tok_60763 = _43next_token();
    DeRef(_0);

    /** parser.e:3772			if not find(tok[T_ID], ID_TOKS) then*/
    _2 = (object)SEQ_PTR(_tok_60763);
    _30166 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30167 = find_from(_30166, _29ID_TOKS_12012, 1LL);
    _30166 = NOVALUE;
    if (_30167 != 0)
    goto L4; // [77] 90
    _30167 = NOVALUE;

    /** parser.e:3773				CompileErr(A_VARIABLE_NAME_IS_EXPECTED_HERE)*/
    RefDS(_22024);
    _49CompileErr(24LL, _22024, 0LL);
L4: 

    /** parser.e:3775			sym = SetPrivateScope(tok[T_SYM], type_sym, param_num)*/
    _2 = (object)SEQ_PTR(_tok_60763);
    _30169 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30169);
    _sym_60765 = _43SetPrivateScope(_30169, _type_sym_60761, _43param_num_55024);
    _30169 = NOVALUE;
    if (!IS_ATOM_INT(_sym_60765)) {
        _1 = (object)(DBL_PTR(_sym_60765)->dbl);
        DeRefDS(_sym_60765);
        _sym_60765 = _1;
    }

    /** parser.e:3776			param_num += 1*/
    _43param_num_55024 = _43param_num_55024 + 1;

    /** parser.e:3778			if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L5; // [120] 143
    }
    else{
    }

    /** parser.e:3779				SymTab[sym][S_GTYPE] = CompileType(type_sym)*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60765 + ((s1_ptr)_2)->base);
    _30174 = _43CompileType(_type_sym_60761);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30174;
    if( _1 != _30174 ){
        DeRef(_1);
    }
    _30174 = NOVALUE;
    _30172 = NOVALUE;
L5: 

    /** parser.e:3782	   		tok = next_token()*/
    _0 = _tok_60763;
    _tok_60763 = _43next_token();
    DeRef(_0);

    /** parser.e:3783	   		if tok[T_ID] = EQUALS then -- assign on declare*/
    _2 = (object)SEQ_PTR(_tok_60763);
    _30176 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30176, 3LL)){
        _30176 = NOVALUE;
        goto L6; // [158] 233
    }
    _30176 = NOVALUE;

    /** parser.e:3784			    putback(tok)*/
    Ref(_tok_60763);
    _43putback(_tok_60763);

    /** parser.e:3785			    StartSourceLine( TRUE )*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:3797			    Assignment({VARIABLE,sym})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100LL;
    ((intptr_t *)_2)[2] = _sym_60765;
    _30178 = MAKE_SEQ(_1);
    _43Assignment(_30178);
    _30178 = NOVALUE;

    /** parser.e:3800				tok = next_token()*/
    _0 = _tok_60763;
    _tok_60763 = _43next_token();
    DeRef(_0);

    /** parser.e:3801				if tok[T_ID]=IGNORED then*/
    _2 = (object)SEQ_PTR(_tok_60763);
    _30180 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30180, 509LL)){
        _30180 = NOVALUE;
        goto L7; // [202] 232
    }
    _30180 = NOVALUE;

    /** parser.e:3802					tok = keyfind(tok[T_SYM],-1)*/
    _2 = (object)SEQ_PTR(_tok_60763);
    _30182 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30182);
    DeRef(_31773);
    _31773 = _30182;
    _31774 = _53hashfn(_31773);
    _31773 = NOVALUE;
    Ref(_30182);
    _0 = _tok_60763;
    _tok_60763 = _53keyfind(_30182, -1LL, _12current_file_no_20226, 0LL, _31774);
    DeRef(_0);
    _30182 = NOVALUE;
    _31774 = NOVALUE;
L7: 
L6: 

    /** parser.e:3806			if tok[T_ID] != COMMA then*/
    _2 = (object)SEQ_PTR(_tok_60763);
    _30184 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _30184, -30LL)){
        _30184 = NOVALUE;
        goto L2; // [243] 52
    }
    _30184 = NOVALUE;

    /** parser.e:3807				exit*/
    goto L3; // [249] 257

    /** parser.e:3809		end while*/
    goto L2; // [254] 52
L3: 

    /** parser.e:3810		putback(tok)*/
    Ref(_tok_60763);
    _43putback(_tok_60763);

    /** parser.e:3811	end procedure*/
    DeRef(_tok_60763);
    return;
    ;
}


void _43Procedure_call(object _tok_60828)
{
    object _n_60829 = NOVALUE;
    object _scope_60830 = NOVALUE;
    object _opcode_60831 = NOVALUE;
    object _temp_tok_60833 = NOVALUE;
    object _s_60835 = NOVALUE;
    object _sub_60836 = NOVALUE;
    object _30220 = NOVALUE;
    object _30215 = NOVALUE;
    object _30214 = NOVALUE;
    object _30213 = NOVALUE;
    object _30212 = NOVALUE;
    object _30211 = NOVALUE;
    object _30210 = NOVALUE;
    object _30209 = NOVALUE;
    object _30208 = NOVALUE;
    object _30207 = NOVALUE;
    object _30206 = NOVALUE;
    object _30205 = NOVALUE;
    object _30203 = NOVALUE;
    object _30202 = NOVALUE;
    object _30201 = NOVALUE;
    object _30200 = NOVALUE;
    object _30199 = NOVALUE;
    object _30198 = NOVALUE;
    object _30197 = NOVALUE;
    object _30195 = NOVALUE;
    object _30194 = NOVALUE;
    object _30193 = NOVALUE;
    object _30191 = NOVALUE;
    object _30189 = NOVALUE;
    object _30187 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:3820		tok_match(LEFT_ROUND)*/
    _43tok_match(-26LL, 0LL);

    /** parser.e:3821		s = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_60828);
    _s_60835 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_60835)){
        _s_60835 = (object)DBL_PTR(_s_60835)->dbl;
    }

    /** parser.e:3822		sub=s*/
    _sub_60836 = _s_60835;

    /** parser.e:3823		n = SymTab[s][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30187 = (object)*(((s1_ptr)_2)->base + _s_60835);
    _2 = (object)SEQ_PTR(_30187);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _n_60829 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _n_60829 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    if (!IS_ATOM_INT(_n_60829)){
        _n_60829 = (object)DBL_PTR(_n_60829)->dbl;
    }
    _30187 = NOVALUE;

    /** parser.e:3824		scope = SymTab[s][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30189 = (object)*(((s1_ptr)_2)->base + _s_60835);
    _2 = (object)SEQ_PTR(_30189);
    _scope_60830 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_scope_60830)){
        _scope_60830 = (object)DBL_PTR(_scope_60830)->dbl;
    }
    _30189 = NOVALUE;

    /** parser.e:3825		opcode = SymTab[s][S_OPCODE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30191 = (object)*(((s1_ptr)_2)->base + _s_60835);
    _2 = (object)SEQ_PTR(_30191);
    _opcode_60831 = (object)*(((s1_ptr)_2)->base + 21LL);
    if (!IS_ATOM_INT(_opcode_60831)){
        _opcode_60831 = (object)DBL_PTR(_opcode_60831)->dbl;
    }
    _30191 = NOVALUE;

    /** parser.e:3826		if SymTab[s][S_EFFECT] then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30193 = (object)*(((s1_ptr)_2)->base + _s_60835);
    _2 = (object)SEQ_PTR(_30193);
    _30194 = (object)*(((s1_ptr)_2)->base + 23LL);
    _30193 = NOVALUE;
    if (_30194 == 0) {
        _30194 = NOVALUE;
        goto L1; // [88] 139
    }
    else {
        if (!IS_ATOM_INT(_30194) && DBL_PTR(_30194)->dbl == 0.0){
            _30194 = NOVALUE;
            goto L1; // [88] 139
        }
        _30194 = NOVALUE;
    }
    _30194 = NOVALUE;

    /** parser.e:3827			SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT],*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12CurrentSub_20234 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30197 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_30197);
    _30198 = (object)*(((s1_ptr)_2)->base + 23LL);
    _30197 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30199 = (object)*(((s1_ptr)_2)->base + _s_60835);
    _2 = (object)SEQ_PTR(_30199);
    _30200 = (object)*(((s1_ptr)_2)->base + 23LL);
    _30199 = NOVALUE;
    if (IS_ATOM_INT(_30198) && IS_ATOM_INT(_30200)) {
        {uintptr_t tu;
             tu = (uintptr_t)_30198 | (uintptr_t)_30200;
             _30201 = MAKE_UINT(tu);
        }
    }
    else {
        _30201 = binary_op(OR_BITS, _30198, _30200);
    }
    _30198 = NOVALUE;
    _30200 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30201;
    if( _1 != _30201 ){
        DeRef(_1);
    }
    _30201 = NOVALUE;
    _30195 = NOVALUE;
L1: 

    /** parser.e:3830		ParseArgs(s)*/
    _43ParseArgs(_s_60835);

    /** parser.e:3833		for i=1 to n+1 do*/
    _30202 = _n_60829 + 1;
    if (_30202 > MAXINT){
        _30202 = NewDouble((eudouble)_30202);
    }
    {
        object _i_60873;
        _i_60873 = 1LL;
L2: 
        if (binary_op_a(GREATER, _i_60873, _30202)){
            goto L3; // [150] 180
        }

        /** parser.e:3834			s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _30203 = (object)*(((s1_ptr)_2)->base + _s_60835);
        _2 = (object)SEQ_PTR(_30203);
        _s_60835 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_s_60835)){
            _s_60835 = (object)DBL_PTR(_s_60835)->dbl;
        }
        _30203 = NOVALUE;

        /** parser.e:3835		end for*/
        _0 = _i_60873;
        if (IS_ATOM_INT(_i_60873)) {
            _i_60873 = _i_60873 + 1LL;
            if ((object)((uintptr_t)_i_60873 +(uintptr_t) HIGH_BITS) >= 0){
                _i_60873 = NewDouble((eudouble)_i_60873);
            }
        }
        else {
            _i_60873 = binary_op_a(PLUS, _i_60873, 1LL);
        }
        DeRef(_0);
        goto L2; // [175] 157
L3: 
        ;
        DeRef(_i_60873);
    }

    /** parser.e:3836		while s and SymTab[s][S_SCOPE]=SC_PRIVATE do*/
L4: 
    if (_s_60835 == 0) {
        goto L5; // [185] 281
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30206 = (object)*(((s1_ptr)_2)->base + _s_60835);
    _2 = (object)SEQ_PTR(_30206);
    _30207 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30206 = NOVALUE;
    if (IS_ATOM_INT(_30207)) {
        _30208 = (_30207 == 3LL);
    }
    else {
        _30208 = binary_op(EQUALS, _30207, 3LL);
    }
    _30207 = NOVALUE;
    if (_30208 <= 0) {
        if (_30208 == 0) {
            DeRef(_30208);
            _30208 = NOVALUE;
            goto L5; // [208] 281
        }
        else {
            if (!IS_ATOM_INT(_30208) && DBL_PTR(_30208)->dbl == 0.0){
                DeRef(_30208);
                _30208 = NOVALUE;
                goto L5; // [208] 281
            }
            DeRef(_30208);
            _30208 = NOVALUE;
        }
    }
    DeRef(_30208);
    _30208 = NOVALUE;

    /** parser.e:3837			if sequence(SymTab[s][S_CODE]) then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30209 = (object)*(((s1_ptr)_2)->base + _s_60835);
    _2 = (object)SEQ_PTR(_30209);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _30210 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _30210 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    _30209 = NOVALUE;
    _30211 = IS_SEQUENCE(_30210);
    _30210 = NOVALUE;
    if (_30211 == 0)
    {
        _30211 = NOVALUE;
        goto L6; // [228] 260
    }
    else{
        _30211 = NOVALUE;
    }

    /** parser.e:3838				start_playback(SymTab[s][S_CODE])*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30212 = (object)*(((s1_ptr)_2)->base + _s_60835);
    _2 = (object)SEQ_PTR(_30212);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _30213 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _30213 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    _30212 = NOVALUE;
    Ref(_30213);
    _43start_playback(_30213);
    _30213 = NOVALUE;

    /** parser.e:3839				Assignment({VARIABLE,s})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100LL;
    ((intptr_t *)_2)[2] = _s_60835;
    _30214 = MAKE_SEQ(_1);
    _43Assignment(_30214);
    _30214 = NOVALUE;
L6: 

    /** parser.e:3841			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30215 = (object)*(((s1_ptr)_2)->base + _s_60835);
    _2 = (object)SEQ_PTR(_30215);
    _s_60835 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_60835)){
        _s_60835 = (object)DBL_PTR(_s_60835)->dbl;
    }
    _30215 = NOVALUE;

    /** parser.e:3842		end while*/
    goto L4; // [278] 185
L5: 

    /** parser.e:3844		s = sub*/
    _s_60835 = _sub_60836;

    /** parser.e:3845		if scope = SC_PREDEF then*/
    if (_scope_60830 != 7LL)
    goto L7; // [292] 335

    /** parser.e:3846			emit_op(opcode)*/
    _45emit_op(_opcode_60831);

    /** parser.e:3847			if opcode = ABORT then*/
    if (_opcode_60831 != 126LL)
    goto L8; // [305] 370

    /** parser.e:3848				temp_tok = next_token()*/
    _0 = _temp_tok_60833;
    _temp_tok_60833 = _43next_token();
    DeRef(_0);

    /** parser.e:3849				putback(temp_tok)*/
    Ref(_temp_tok_60833);
    _43putback(_temp_tok_60833);

    /** parser.e:3850				NotReached(temp_tok[T_ID], "abort()")*/
    _2 = (object)SEQ_PTR(_temp_tok_60833);
    _30220 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_30220);
    RefDS(_27952);
    _43NotReached(_30220, _27952);
    _30220 = NOVALUE;
    goto L8; // [332] 370
L7: 

    /** parser.e:3853			op_info1 = s*/
    _45op_info1_51020 = _s_60835;

    /** parser.e:3855			emit_or_inline()*/
    _66emit_or_inline();

    /** parser.e:3856			if not TRANSLATE then*/
    if (_12TRANSLATE_19834 != 0)
    goto L9; // [350] 369

    /** parser.e:3857				if OpTrace then*/
    if (_12OpTrace_20296 == 0)
    {
        goto LA; // [357] 368
    }
    else{
    }

    /** parser.e:3858					emit_op(UPDATE_GLOBALS)*/
    _45emit_op(89LL);
LA: 
L9: 
L8: 

    /** parser.e:3862	end procedure*/
    DeRef(_tok_60828);
    DeRef(_temp_tok_60833);
    DeRef(_30202);
    _30202 = NOVALUE;
    return;
    ;
}


void _43Print_statement()
{
    object _30227 = NOVALUE;
    object _30226 = NOVALUE;
    object _30225 = NOVALUE;
    object _30223 = NOVALUE;
    object _30222 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:3866		emit_opnd(NewIntSym(1)) -- stdout*/
    _30222 = _53NewIntSym(1LL);
    _45emit_opnd(_30222);
    _30222 = NOVALUE;

    /** parser.e:3867		Expr()*/
    _43Expr();

    /** parser.e:3868		emit_op(QPRINT)*/
    _45emit_op(36LL);

    /** parser.e:3869		SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT],*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12CurrentSub_20234 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30225 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_30225);
    _30226 = (object)*(((s1_ptr)_2)->base + 23LL);
    _30225 = NOVALUE;
    if (IS_ATOM_INT(_30226)) {
        {uintptr_t tu;
             tu = (uintptr_t)_30226 | (uintptr_t)536870912LL;
             _30227 = MAKE_UINT(tu);
        }
    }
    else {
        _30227 = binary_op(OR_BITS, _30226, 536870912LL);
    }
    _30226 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30227;
    if( _1 != _30227 ){
        DeRef(_1);
    }
    _30227 = NOVALUE;
    _30223 = NOVALUE;

    /** parser.e:3871	end procedure*/
    return;
    ;
}


void _43Entry_statement()
{
    object _addr_60944 = NOVALUE;
    object _30251 = NOVALUE;
    object _30250 = NOVALUE;
    object _30249 = NOVALUE;
    object _30248 = NOVALUE;
    object _30247 = NOVALUE;
    object _30246 = NOVALUE;
    object _30245 = NOVALUE;
    object _30244 = NOVALUE;
    object _30240 = NOVALUE;
    object _30238 = NOVALUE;
    object _30237 = NOVALUE;
    object _30236 = NOVALUE;
    object _30235 = NOVALUE;
    object _30233 = NOVALUE;
    object _30232 = NOVALUE;
    object _30231 = NOVALUE;
    object _30229 = NOVALUE;
    object _30228 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:3878		if not length(loop_stack) or block_index=0 then*/
    if (IS_SEQUENCE(_43loop_stack_55049)){
            _30228 = SEQ_PTR(_43loop_stack_55049)->length;
    }
    else {
        _30228 = 1;
    }
    _30229 = (_30228 == 0);
    _30228 = NOVALUE;
    if (_30229 != 0) {
        goto L1; // [11] 26
    }
    _30231 = (_43block_index_55046 == 0LL);
    if (_30231 == 0)
    {
        DeRef(_30231);
        _30231 = NOVALUE;
        goto L2; // [22] 36
    }
    else{
        DeRef(_30231);
        _30231 = NOVALUE;
    }
L1: 

    /** parser.e:3879			CompileErr(THE_ENTRY_STATEMENT_MUST_APPEAR_INSIDE_A_LOOP)*/
    RefDS(_22024);
    _49CompileErr(144LL, _22024, 0LL);
L2: 

    /** parser.e:3881		if block_list[block_index]=IF or block_list[block_index]=SWITCH then*/
    _2 = (object)SEQ_PTR(_43block_list_55045);
    _30232 = (object)*(((s1_ptr)_2)->base + _43block_index_55046);
    _30233 = (_30232 == 20LL);
    _30232 = NOVALUE;
    if (_30233 != 0) {
        goto L3; // [52] 75
    }
    _2 = (object)SEQ_PTR(_43block_list_55045);
    _30235 = (object)*(((s1_ptr)_2)->base + _43block_index_55046);
    _30236 = (_30235 == 185LL);
    _30235 = NOVALUE;
    if (_30236 == 0)
    {
        DeRef(_30236);
        _30236 = NOVALUE;
        goto L4; // [71] 87
    }
    else{
        DeRef(_30236);
        _30236 = NOVALUE;
    }
L3: 

    /** parser.e:3882			CompileErr(THE_INNERMOST_BLOCK_CONTAINING_AN_ENTRY_STATEMENT_MUST_BE_THE_LOOP_IT_DEFINES_AN_ENTRY_IN)*/
    RefDS(_22024);
    _49CompileErr(143LL, _22024, 0LL);
    goto L5; // [84] 115
L4: 

    /** parser.e:3883		elsif loop_stack[$] = FOR then  -- not allowed in an innermost for loop*/
    if (IS_SEQUENCE(_43loop_stack_55049)){
            _30237 = SEQ_PTR(_43loop_stack_55049)->length;
    }
    else {
        _30237 = 1;
    }
    _2 = (object)SEQ_PTR(_43loop_stack_55049);
    _30238 = (object)*(((s1_ptr)_2)->base + _30237);
    if (_30238 != 21LL)
    goto L6; // [100] 114

    /** parser.e:3884			CompileErr(THE_ENTRY_STATEMENT_CAN_NOT_BE_USED_IN_A_FOR_BLOCK)*/
    RefDS(_22024);
    _49CompileErr(142LL, _22024, 0LL);
L6: 
L5: 

    /** parser.e:3886		addr = entry_addr[$]*/
    if (IS_SEQUENCE(_43entry_addr_55039)){
            _30240 = SEQ_PTR(_43entry_addr_55039)->length;
    }
    else {
        _30240 = 1;
    }
    _2 = (object)SEQ_PTR(_43entry_addr_55039);
    _addr_60944 = (object)*(((s1_ptr)_2)->base + _30240);

    /** parser.e:3887		if addr=0  then*/
    if (_addr_60944 != 0LL)
    goto L7; // [128] 144

    /** parser.e:3888			CompileErr(THE_ENTRY_STATEMENT_MUST_APPEAR_AT_MOST_ONCE_INSIDE_A_LOOP)*/
    RefDS(_22024);
    _49CompileErr(141LL, _22024, 0LL);
    goto L8; // [141] 161
L7: 

    /** parser.e:3889		elsif addr<0 then*/
    if (_addr_60944 >= 0LL)
    goto L9; // [146] 160

    /** parser.e:3890			CompileErr(ENTRY_STATEMENT_IS_BEING_USED_WITHOUT_A_CORRESPONDING_ENTRY_CLAUSE_IN_THE_LOOP_HEADER)*/
    RefDS(_22024);
    _49CompileErr(73LL, _22024, 0LL);
L9: 
L8: 

    /** parser.e:3892		backpatch(addr,ELSE)*/
    _45backpatch(_addr_60944, 23LL);

    /** parser.e:3893		backpatch(addr+1,length(Code)+1+(TRANSLATE>0))*/
    _30244 = _addr_60944 + 1;
    if (_30244 > MAXINT){
        _30244 = NewDouble((eudouble)_30244);
    }
    if (IS_SEQUENCE(_12Code_20315)){
            _30245 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _30245 = 1;
    }
    _30246 = _30245 + 1;
    _30245 = NOVALUE;
    _30247 = (_12TRANSLATE_19834 > 0LL);
    _30248 = _30246 + _30247;
    _30246 = NOVALUE;
    _30247 = NOVALUE;
    _45backpatch(_30244, _30248);
    _30244 = NOVALUE;
    _30248 = NOVALUE;

    /** parser.e:3894		entry_addr[$] = 0*/
    if (IS_SEQUENCE(_43entry_addr_55039)){
            _30249 = SEQ_PTR(_43entry_addr_55039)->length;
    }
    else {
        _30249 = 1;
    }
    _2 = (object)SEQ_PTR(_43entry_addr_55039);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43entry_addr_55039 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _30249);
    *(intptr_t *)_2 = 0LL;

    /** parser.e:3895		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto LA; // [213] 224
    }
    else{
    }

    /** parser.e:3896		    emit_op(NOP1)*/
    _45emit_op(159LL);
LA: 

    /** parser.e:3899		force_uninitialize( entry_stack[$] )*/
    if (IS_SEQUENCE(_43entry_stack_55042)){
            _30250 = SEQ_PTR(_43entry_stack_55042)->length;
    }
    else {
        _30250 = 1;
    }
    _2 = (object)SEQ_PTR(_43entry_stack_55042);
    _30251 = (object)*(((s1_ptr)_2)->base + _30250);
    Ref(_30251);
    _43force_uninitialize(_30251);
    _30251 = NOVALUE;

    /** parser.e:3901	end procedure*/
    _30238 = NOVALUE;
    DeRef(_30233);
    _30233 = NOVALUE;
    DeRef(_30229);
    _30229 = NOVALUE;
    return;
    ;
}


void _43force_uninitialize(object _uninitialized_60999)
{
    object _30254 = NOVALUE;
    object _30253 = NOVALUE;
    object _30252 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:3907		for i = 1 to length( uninitialized ) do*/
    if (IS_SEQUENCE(_uninitialized_60999)){
            _30252 = SEQ_PTR(_uninitialized_60999)->length;
    }
    else {
        _30252 = 1;
    }
    {
        object _i_61001;
        _i_61001 = 1LL;
L1: 
        if (_i_61001 > _30252){
            goto L2; // [8] 41
        }

        /** parser.e:3908			SymTab[uninitialized[i]][S_INITLEVEL] = -1*/
        _2 = (object)SEQ_PTR(_uninitialized_60999);
        _30253 = (object)*(((s1_ptr)_2)->base + _i_61001);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_30253))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_30253)->dbl));
        else
        _3 = (object)(_30253 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 14LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = -1LL;
        DeRef(_1);
        _30254 = NOVALUE;

        /** parser.e:3909		end for*/
        _i_61001 = _i_61001 + 1LL;
        goto L1; // [36] 15
L2: 
        ;
    }

    /** parser.e:3910	end procedure*/
    DeRefDS(_uninitialized_60999);
    _30253 = NOVALUE;
    return;
    ;
}


void _43Statement_list()
{
    object _tok_61011 = NOVALUE;
    object _id_61012 = NOVALUE;
    object _forward_61035 = NOVALUE;
    object _test_61184 = NOVALUE;
    object _30327 = NOVALUE;
    object _30326 = NOVALUE;
    object _30323 = NOVALUE;
    object _30321 = NOVALUE;
    object _30320 = NOVALUE;
    object _30317 = NOVALUE;
    object _30314 = NOVALUE;
    object _30313 = NOVALUE;
    object _30312 = NOVALUE;
    object _30309 = NOVALUE;
    object _30307 = NOVALUE;
    object _30305 = NOVALUE;
    object _30303 = NOVALUE;
    object _30285 = NOVALUE;
    object _30284 = NOVALUE;
    object _30282 = NOVALUE;
    object _30280 = NOVALUE;
    object _30279 = NOVALUE;
    object _30277 = NOVALUE;
    object _30275 = NOVALUE;
    object _30274 = NOVALUE;
    object _30273 = NOVALUE;
    object _30272 = NOVALUE;
    object _30267 = NOVALUE;
    object _30264 = NOVALUE;
    object _30263 = NOVALUE;
    object _30262 = NOVALUE;
    object _30261 = NOVALUE;
    object _30259 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:3915		integer id*/

    /** parser.e:3917		stmt_nest += 1*/
    _43stmt_nest_55047 = _43stmt_nest_55047 + 1;

    /** parser.e:3918		while TRUE do*/
L1: 
    if (_9TRUE_446 == 0)
    {
        goto L2; // [18] 1125
    }
    else{
    }

    /** parser.e:3919			tok = next_token()*/
    _0 = _tok_61011;
    _tok_61011 = _43next_token();
    DeRef(_0);

    /** parser.e:3920			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_61011);
    _id_61012 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_61012)){
        _id_61012 = (object)DBL_PTR(_id_61012)->dbl;
    }

    /** parser.e:3921			if id = VARIABLE or id = QUALIFIED_VARIABLE then*/
    _30259 = (_id_61012 == -100LL);
    if (_30259 != 0) {
        goto L3; // [44] 59
    }
    _30261 = (_id_61012 == 512LL);
    if (_30261 == 0)
    {
        DeRef(_30261);
        _30261 = NOVALUE;
        goto L4; // [55] 229
    }
    else{
        DeRef(_30261);
        _30261 = NOVALUE;
    }
L3: 

    /** parser.e:3922				if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_tok_61011);
    _30262 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_30262)){
        _30263 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30262)->dbl));
    }
    else{
        _30263 = (object)*(((s1_ptr)_2)->base + _30262);
    }
    _2 = (object)SEQ_PTR(_30263);
    _30264 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30263 = NOVALUE;
    if (binary_op_a(NOTEQ, _30264, 9LL)){
        _30264 = NOVALUE;
        goto L5; // [81] 210
    }
    _30264 = NOVALUE;

    /** parser.e:3923					token forward = next_token()*/
    _0 = _forward_61035;
    _forward_61035 = _43next_token();
    DeRef(_0);

    /** parser.e:3924					switch forward[T_ID] do*/
    _2 = (object)SEQ_PTR(_forward_61035);
    _30267 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_30267) ){
        goto L6; // [98] 204
    }
    if(!IS_ATOM_INT(_30267)){
        if( (DBL_PTR(_30267)->dbl != (eudouble) ((object) DBL_PTR(_30267)->dbl) ) ){
            goto L6; // [98] 204
        }
        _0 = (object) DBL_PTR(_30267)->dbl;
    }
    else {
        _0 = _30267;
    };
    _30267 = NOVALUE;
    switch ( _0 ){ 

        /** parser.e:3925						case LEFT_ROUND then*/
        case -26:

        /** parser.e:3926							StartSourceLine( TRUE )*/
        _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

        /** parser.e:3928							Forward_call( tok )*/
        Ref(_tok_61011);
        _43Forward_call(_tok_61011, 195LL);

        /** parser.e:3929							flush_temps()*/
        RefDS(_22024);
        _45flush_temps(_22024);

        /** parser.e:3930							continue*/
        DeRef(_forward_61035);
        _forward_61035 = NOVALUE;
        goto L1; // [133] 16
        goto L6; // [135] 204

        /** parser.e:3932						case VARIABLE then*/
        case -100:

        /** parser.e:3933							putback( forward )*/
        Ref(_forward_61035);
        _43putback(_forward_61035);

        /** parser.e:3934							if param_num != -1 then*/
        if (_43param_num_55024 == -1LL)
        goto L7; // [150] 176

        /** parser.e:3936								param_num += 1*/
        _43param_num_55024 = _43param_num_55024 + 1;

        /** parser.e:3937								Private_declaration( tok[T_SYM] )*/
        _2 = (object)SEQ_PTR(_tok_61011);
        _30272 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_30272);
        _43Private_declaration(_30272);
        _30272 = NOVALUE;
        goto L8; // [173] 192
L7: 

        /** parser.e:3939								Global_declaration( tok[T_SYM], SC_LOCAL )*/
        _2 = (object)SEQ_PTR(_tok_61011);
        _30273 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_30273);
        _30274 = _43Global_declaration(_30273, 5LL);
        _30273 = NOVALUE;
L8: 

        /** parser.e:3941							flush_temps()*/
        RefDS(_22024);
        _45flush_temps(_22024);

        /** parser.e:3942							continue*/
        DeRef(_forward_61035);
        _forward_61035 = NOVALUE;
        goto L1; // [201] 16
    ;}L6: 

    /** parser.e:3945					putback( forward )*/
    Ref(_forward_61035);
    _43putback(_forward_61035);
L5: 
    DeRef(_forward_61035);
    _forward_61035 = NOVALUE;

    /** parser.e:3947				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:3948				Assignment(tok)*/
    Ref(_tok_61011);
    _43Assignment(_tok_61011);
    goto L9; // [226] 1115
L4: 

    /** parser.e:3950			elsif id = PROC or id = QUALIFIED_PROC then*/
    _30275 = (_id_61012 == 27LL);
    if (_30275 != 0) {
        goto LA; // [237] 252
    }
    _30277 = (_id_61012 == 521LL);
    if (_30277 == 0)
    {
        DeRef(_30277);
        _30277 = NOVALUE;
        goto LB; // [248] 289
    }
    else{
        DeRef(_30277);
        _30277 = NOVALUE;
    }
LA: 

    /** parser.e:3951				if id = PROC then*/
    if (_id_61012 != 27LL)
    goto LC; // [256] 272

    /** parser.e:3953					UndefinedVar( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_61011);
    _30279 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30279);
    _43UndefinedVar(_30279);
    _30279 = NOVALUE;
LC: 

    /** parser.e:3955				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:3956				Procedure_call(tok)*/
    Ref(_tok_61011);
    _43Procedure_call(_tok_61011);
    goto L9; // [286] 1115
LB: 

    /** parser.e:3958			elsif id = FUNC or id = QUALIFIED_FUNC then*/
    _30280 = (_id_61012 == 501LL);
    if (_30280 != 0) {
        goto LD; // [297] 312
    }
    _30282 = (_id_61012 == 520LL);
    if (_30282 == 0)
    {
        DeRef(_30282);
        _30282 = NOVALUE;
        goto LE; // [308] 362
    }
    else{
        DeRef(_30282);
        _30282 = NOVALUE;
    }
LD: 

    /** parser.e:3959				if id = FUNC then*/
    if (_id_61012 != 501LL)
    goto LF; // [316] 332

    /** parser.e:3961					UndefinedVar( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_61011);
    _30284 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30284);
    _43UndefinedVar(_30284);
    _30284 = NOVALUE;
LF: 

    /** parser.e:3963				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:3964				Procedure_call(tok)*/
    Ref(_tok_61011);
    _43Procedure_call(_tok_61011);

    /** parser.e:3965				clear_op()*/
    _45clear_op();

    /** parser.e:3966				if Pop() then end if*/
    _30285 = _45Pop();
    if (_30285 == 0) {
        DeRef(_30285);
        _30285 = NOVALUE;
        goto L9; // [355] 1115
    }
    else {
        if (!IS_ATOM_INT(_30285) && DBL_PTR(_30285)->dbl == 0.0){
            DeRef(_30285);
            _30285 = NOVALUE;
            goto L9; // [355] 1115
        }
        DeRef(_30285);
        _30285 = NOVALUE;
    }
    DeRef(_30285);
    _30285 = NOVALUE;
    goto L9; // [359] 1115
LE: 

    /** parser.e:3968			elsif id = IF then*/
    if (_id_61012 != 20LL)
    goto L10; // [366] 386

    /** parser.e:3969				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:3970				If_statement()*/
    _43If_statement();
    goto L9; // [383] 1115
L10: 

    /** parser.e:3972			elsif id = FOR then*/
    if (_id_61012 != 21LL)
    goto L11; // [390] 410

    /** parser.e:3973				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:3974				For_statement()*/
    _43For_statement();
    goto L9; // [407] 1115
L11: 

    /** parser.e:3976			elsif id = RETURN then*/
    if (_id_61012 != 413LL)
    goto L12; // [414] 434

    /** parser.e:3977				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:3978				Return_statement()*/
    _43Return_statement();
    goto L9; // [431] 1115
L12: 

    /** parser.e:3980			elsif id = LABEL then*/
    if (_id_61012 != 419LL)
    goto L13; // [438] 460

    /** parser.e:3981				StartSourceLine(TRUE, , COVERAGE_SUPPRESS )*/
    _45StartSourceLine(_9TRUE_446, 0LL, 1LL);

    /** parser.e:3982				GLabel_statement()*/
    _43GLabel_statement();
    goto L9; // [457] 1115
L13: 

    /** parser.e:3984			elsif id = GOTO then*/
    if (_id_61012 != 188LL)
    goto L14; // [464] 484

    /** parser.e:3985				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:3986				Goto_statement()*/
    _43Goto_statement();
    goto L9; // [481] 1115
L14: 

    /** parser.e:3988			elsif id = EXIT then*/
    if (_id_61012 != 61LL)
    goto L15; // [488] 508

    /** parser.e:3989				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:3990				Exit_statement()*/
    _43Exit_statement();
    goto L9; // [505] 1115
L15: 

    /** parser.e:3992			elsif id = BREAK then*/
    if (_id_61012 != 425LL)
    goto L16; // [512] 532

    /** parser.e:3993				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:3994				Break_statement()*/
    _43Break_statement();
    goto L9; // [529] 1115
L16: 

    /** parser.e:3996			elsif id = WHILE then*/
    if (_id_61012 != 47LL)
    goto L17; // [536] 556

    /** parser.e:3997				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:3998				While_statement()*/
    _43While_statement();
    goto L9; // [553] 1115
L17: 

    /** parser.e:4000			elsif id = LOOP then*/
    if (_id_61012 != 422LL)
    goto L18; // [560] 580

    /** parser.e:4001			    StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:4002		        Loop_statement()*/
    _43Loop_statement();
    goto L9; // [577] 1115
L18: 

    /** parser.e:4004			elsif id = ENTRY then*/
    if (_id_61012 != 424LL)
    goto L19; // [584] 606

    /** parser.e:4005			    StartSourceLine(TRUE, , COVERAGE_SUPPRESS )*/
    _45StartSourceLine(_9TRUE_446, 0LL, 1LL);

    /** parser.e:4006			    Entry_statement()*/
    _43Entry_statement();
    goto L9; // [603] 1115
L19: 

    /** parser.e:4008			elsif id = QUESTION_MARK then*/
    if (_id_61012 != -31LL)
    goto L1A; // [610] 630

    /** parser.e:4009				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:4010				Print_statement()*/
    _43Print_statement();
    goto L9; // [627] 1115
L1A: 

    /** parser.e:4012			elsif id = CONTINUE then*/
    if (_id_61012 != 426LL)
    goto L1B; // [634] 654

    /** parser.e:4013				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:4014				Continue_statement()*/
    _43Continue_statement();
    goto L9; // [651] 1115
L1B: 

    /** parser.e:4016			elsif id = RETRY then*/
    if (_id_61012 != 184LL)
    goto L1C; // [658] 678

    /** parser.e:4017				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:4018				Retry_statement()*/
    _43Retry_statement();
    goto L9; // [675] 1115
L1C: 

    /** parser.e:4020			elsif id = IFDEF then*/
    if (_id_61012 != 407LL)
    goto L1D; // [682] 702

    /** parser.e:4021				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:4022				Ifdef_statement()*/
    _43Ifdef_statement();
    goto L9; // [699] 1115
L1D: 

    /** parser.e:4024			elsif id = CASE then*/
    if (_id_61012 != 186LL)
    goto L1E; // [706] 717

    /** parser.e:4025				Case_statement()*/
    _43Case_statement();
    goto L9; // [714] 1115
L1E: 

    /** parser.e:4027			elsif id = SWITCH then*/
    if (_id_61012 != 185LL)
    goto L1F; // [721] 741

    /** parser.e:4028				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:4029				Switch_statement()*/
    _43Switch_statement();
    goto L9; // [738] 1115
L1F: 

    /** parser.e:4031			elsif id = FALLTHRU then*/
    if (_id_61012 != 431LL)
    goto L20; // [745] 756

    /** parser.e:4032				Fallthru_statement()*/
    _43Fallthru_statement();
    goto L9; // [753] 1115
L20: 

    /** parser.e:4034			elsif id = TYPE or id = QUALIFIED_TYPE then*/
    _30303 = (_id_61012 == 504LL);
    if (_30303 != 0) {
        goto L21; // [764] 779
    }
    _30305 = (_id_61012 == 522LL);
    if (_30305 == 0)
    {
        DeRef(_30305);
        _30305 = NOVALUE;
        goto L22; // [775] 904
    }
    else{
        DeRef(_30305);
        _30305 = NOVALUE;
    }
L21: 

    /** parser.e:4035				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:4036				token test = next_token()*/
    _0 = _test_61184;
    _test_61184 = _43next_token();
    DeRef(_0);

    /** parser.e:4037				putback( test )*/
    Ref(_test_61184);
    _43putback(_test_61184);

    /** parser.e:4038				if test[T_ID] = LEFT_ROUND then*/
    _2 = (object)SEQ_PTR(_test_61184);
    _30307 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30307, -26LL)){
        _30307 = NOVALUE;
        goto L23; // [808] 852
    }
    _30307 = NOVALUE;

    /** parser.e:4039					StartSourceLine( TRUE )*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:4040					Procedure_call(tok)*/
    Ref(_tok_61011);
    _43Procedure_call(_tok_61011);

    /** parser.e:4041					clear_op()*/
    _45clear_op();

    /** parser.e:4042					if Pop() then end if*/
    _30309 = _45Pop();
    if (_30309 == 0) {
        DeRef(_30309);
        _30309 = NOVALUE;
        goto L24; // [835] 839
    }
    else {
        if (!IS_ATOM_INT(_30309) && DBL_PTR(_30309)->dbl == 0.0){
            DeRef(_30309);
            _30309 = NOVALUE;
            goto L24; // [835] 839
        }
        DeRef(_30309);
        _30309 = NOVALUE;
    }
    DeRef(_30309);
    _30309 = NOVALUE;
L24: 

    /** parser.e:4043					ExecCommand()*/
    _43ExecCommand();

    /** parser.e:4044					continue*/
    DeRef(_test_61184);
    _test_61184 = NOVALUE;
    goto L1; // [847] 16
    goto L25; // [849] 899
L23: 

    /** parser.e:4047					if param_num != -1 then*/
    if (_43param_num_55024 == -1LL)
    goto L26; // [856] 882

    /** parser.e:4049						param_num += 1*/
    _43param_num_55024 = _43param_num_55024 + 1;

    /** parser.e:4050						Private_declaration( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_61011);
    _30312 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30312);
    _43Private_declaration(_30312);
    _30312 = NOVALUE;
    goto L27; // [879] 898
L26: 

    /** parser.e:4052						Global_declaration( tok[T_SYM], SC_LOCAL )*/
    _2 = (object)SEQ_PTR(_tok_61011);
    _30313 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30313);
    _30314 = _43Global_declaration(_30313, 5LL);
    _30313 = NOVALUE;
L27: 
L25: 
    DeRef(_test_61184);
    _test_61184 = NOVALUE;
    goto L9; // [901] 1115
L22: 

    /** parser.e:4055			elsif id = LEFT_BRACE then*/
    if (_id_61012 != -24LL)
    goto L28; // [908] 928

    /** parser.e:4056				StartSourceLine( TRUE )*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:4057				Multi_assign()*/
    _43Multi_assign();
    goto L9; // [925] 1115
L28: 

    /** parser.e:4060				if id = ELSE then*/
    if (_id_61012 != 23LL)
    goto L29; // [932] 990

    /** parser.e:4061					if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_43if_stack_55050)){
            _30317 = SEQ_PTR(_43if_stack_55050)->length;
    }
    else {
        _30317 = 1;
    }
    if (_30317 != 0LL)
    goto L2A; // [943] 1051

    /** parser.e:4062						if live_ifdef > 0 then*/
    if (_43live_ifdef_59522 <= 0LL)
    goto L2B; // [951] 976

    /** parser.e:4063							CompileErr(SHOULD_THIS_BE_ELSEDEF_FOR_THE_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59523)){
            _30320 = SEQ_PTR(_43ifdef_lineno_59523)->length;
    }
    else {
        _30320 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59523);
    _30321 = (object)*(((s1_ptr)_2)->base + _30320);
    _49CompileErr(134LL, _30321, 0LL);
    _30321 = NOVALUE;
    goto L2A; // [973] 1051
L2B: 

    /** parser.e:4065							CompileErr(NOT_EXPECTING_ELSE)*/
    RefDS(_22024);
    _49CompileErr(118LL, _22024, 0LL);
    goto L2A; // [987] 1051
L29: 

    /** parser.e:4068				elsif id = ELSIF then*/
    if (_id_61012 != 414LL)
    goto L2C; // [994] 1050

    /** parser.e:4069					if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_43if_stack_55050)){
            _30323 = SEQ_PTR(_43if_stack_55050)->length;
    }
    else {
        _30323 = 1;
    }
    if (_30323 != 0LL)
    goto L2D; // [1005] 1049

    /** parser.e:4070						if live_ifdef > 0 then*/
    if (_43live_ifdef_59522 <= 0LL)
    goto L2E; // [1013] 1038

    /** parser.e:4071							CompileErr(SHOULD_THIS_BE_ELSIFDEF_FOR_THE_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59523)){
            _30326 = SEQ_PTR(_43ifdef_lineno_59523)->length;
    }
    else {
        _30326 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59523);
    _30327 = (object)*(((s1_ptr)_2)->base + _30326);
    _49CompileErr(139LL, _30327, 0LL);
    _30327 = NOVALUE;
    goto L2F; // [1035] 1048
L2E: 

    /** parser.e:4073							CompileErr(NOT_EXPECTING_ELSIF)*/
    RefDS(_22024);
    _49CompileErr(119LL, _22024, 0LL);
L2F: 
L2D: 
L2C: 
L2A: 

    /** parser.e:4078				putback( tok )*/
    Ref(_tok_61011);
    _43putback(_tok_61011);

    /** parser.e:4080				switch id do*/
    _0 = _id_61012;
    switch ( _0 ){ 

        /** parser.e:4081					case END, ELSEDEF, ELSIFDEF, ELSIF, ELSE, UNTIL then*/
        case 402:
        case 409:
        case 408:
        case 414:
        case 23:
        case 423:

        /** parser.e:4083						stmt_nest -= 1*/
        _43stmt_nest_55047 = _43stmt_nest_55047 - 1LL;

        /** parser.e:4084						InitDelete()*/
        _43InitDelete();

        /** parser.e:4085						flush_temps()*/
        RefDS(_22024);
        _45flush_temps(_22024);

        /** parser.e:4086						return*/
        DeRef(_tok_61011);
        DeRef(_30280);
        _30280 = NOVALUE;
        DeRef(_30259);
        _30259 = NOVALUE;
        _30262 = NOVALUE;
        DeRef(_30275);
        _30275 = NOVALUE;
        DeRef(_30314);
        _30314 = NOVALUE;
        DeRef(_30303);
        _30303 = NOVALUE;
        DeRef(_30274);
        _30274 = NOVALUE;
        return;
        goto L30; // [1099] 1114

        /** parser.e:4088					case else*/
        default:

        /** parser.e:4089						tok_match( END )*/
        _43tok_match(402LL, 0LL);
    ;}L30: 
L9: 

    /** parser.e:4094			flush_temps()*/
    RefDS(_22024);
    _45flush_temps(_22024);

    /** parser.e:4095		end while*/
    goto L1; // [1122] 16
L2: 

    /** parser.e:4096	end procedure*/
    DeRef(_tok_61011);
    DeRef(_30280);
    _30280 = NOVALUE;
    DeRef(_30259);
    _30259 = NOVALUE;
    _30262 = NOVALUE;
    DeRef(_30275);
    _30275 = NOVALUE;
    DeRef(_30314);
    _30314 = NOVALUE;
    DeRef(_30303);
    _30303 = NOVALUE;
    DeRef(_30274);
    _30274 = NOVALUE;
    return;
    ;
}


void _43SubProg(object _prog_type_61263, object _scope_61264, object _deprecated_61265)
{
    object _h_61266 = NOVALUE;
    object _pt_61267 = NOVALUE;
    object _p_61269 = NOVALUE;
    object _type_sym_61270 = NOVALUE;
    object _sym_61271 = NOVALUE;
    object _tok_61273 = NOVALUE;
    object _prog_name_61274 = NOVALUE;
    object _first_def_arg_61275 = NOVALUE;
    object _again_61276 = NOVALUE;
    object _type_enum_61277 = NOVALUE;
    object _seq_sym_61278 = NOVALUE;
    object _i1_sym_61279 = NOVALUE;
    object _enum_syms_61280 = NOVALUE;
    object _type_enum_gline_61281 = NOVALUE;
    object _real_gline_61282 = NOVALUE;
    object _tsym_61294 = NOVALUE;
    object _seq_symbol_61305 = NOVALUE;
    object _middle_def_args_61512 = NOVALUE;
    object _last_nda_61513 = NOVALUE;
    object _start_def_61514 = NOVALUE;
    object _last_link_61516 = NOVALUE;
    object _temptok_61543 = NOVALUE;
    object _undef_type_61545 = NOVALUE;
    object _tokcat_61597 = NOVALUE;
    object _31772 = NOVALUE;
    object _31771 = NOVALUE;
    object _31770 = NOVALUE;
    object _31769 = NOVALUE;
    object _31768 = NOVALUE;
    object _31767 = NOVALUE;
    object _31766 = NOVALUE;
    object _31765 = NOVALUE;
    object _31764 = NOVALUE;
    object _30595 = NOVALUE;
    object _30593 = NOVALUE;
    object _30592 = NOVALUE;
    object _30590 = NOVALUE;
    object _30589 = NOVALUE;
    object _30588 = NOVALUE;
    object _30587 = NOVALUE;
    object _30586 = NOVALUE;
    object _30584 = NOVALUE;
    object _30583 = NOVALUE;
    object _30580 = NOVALUE;
    object _30579 = NOVALUE;
    object _30578 = NOVALUE;
    object _30577 = NOVALUE;
    object _30575 = NOVALUE;
    object _30566 = NOVALUE;
    object _30564 = NOVALUE;
    object _30563 = NOVALUE;
    object _30562 = NOVALUE;
    object _30561 = NOVALUE;
    object _30558 = NOVALUE;
    object _30557 = NOVALUE;
    object _30556 = NOVALUE;
    object _30554 = NOVALUE;
    object _30551 = NOVALUE;
    object _30550 = NOVALUE;
    object _30549 = NOVALUE;
    object _30547 = NOVALUE;
    object _30546 = NOVALUE;
    object _30543 = NOVALUE;
    object _30541 = NOVALUE;
    object _30539 = NOVALUE;
    object _30538 = NOVALUE;
    object _30537 = NOVALUE;
    object _30536 = NOVALUE;
    object _30534 = NOVALUE;
    object _30533 = NOVALUE;
    object _30532 = NOVALUE;
    object _30531 = NOVALUE;
    object _30530 = NOVALUE;
    object _30529 = NOVALUE;
    object _30526 = NOVALUE;
    object _30524 = NOVALUE;
    object _30522 = NOVALUE;
    object _30520 = NOVALUE;
    object _30518 = NOVALUE;
    object _30515 = NOVALUE;
    object _30513 = NOVALUE;
    object _30512 = NOVALUE;
    object _30509 = NOVALUE;
    object _30505 = NOVALUE;
    object _30504 = NOVALUE;
    object _30502 = NOVALUE;
    object _30500 = NOVALUE;
    object _30498 = NOVALUE;
    object _30496 = NOVALUE;
    object _30494 = NOVALUE;
    object _30492 = NOVALUE;
    object _30491 = NOVALUE;
    object _30490 = NOVALUE;
    object _30489 = NOVALUE;
    object _30488 = NOVALUE;
    object _30487 = NOVALUE;
    object _30486 = NOVALUE;
    object _30485 = NOVALUE;
    object _30484 = NOVALUE;
    object _30483 = NOVALUE;
    object _30482 = NOVALUE;
    object _30481 = NOVALUE;
    object _30478 = NOVALUE;
    object _30477 = NOVALUE;
    object _30476 = NOVALUE;
    object _30475 = NOVALUE;
    object _30474 = NOVALUE;
    object _30473 = NOVALUE;
    object _30472 = NOVALUE;
    object _30471 = NOVALUE;
    object _30470 = NOVALUE;
    object _30469 = NOVALUE;
    object _30468 = NOVALUE;
    object _30467 = NOVALUE;
    object _30466 = NOVALUE;
    object _30465 = NOVALUE;
    object _30464 = NOVALUE;
    object _30462 = NOVALUE;
    object _30460 = NOVALUE;
    object _30459 = NOVALUE;
    object _30454 = NOVALUE;
    object _30453 = NOVALUE;
    object _30451 = NOVALUE;
    object _30450 = NOVALUE;
    object _30449 = NOVALUE;
    object _30448 = NOVALUE;
    object _30447 = NOVALUE;
    object _30446 = NOVALUE;
    object _30445 = NOVALUE;
    object _30444 = NOVALUE;
    object _30443 = NOVALUE;
    object _30442 = NOVALUE;
    object _30440 = NOVALUE;
    object _30439 = NOVALUE;
    object _30437 = NOVALUE;
    object _30436 = NOVALUE;
    object _30435 = NOVALUE;
    object _30434 = NOVALUE;
    object _30433 = NOVALUE;
    object _30432 = NOVALUE;
    object _30431 = NOVALUE;
    object _30429 = NOVALUE;
    object _30426 = NOVALUE;
    object _30424 = NOVALUE;
    object _30422 = NOVALUE;
    object _30420 = NOVALUE;
    object _30418 = NOVALUE;
    object _30416 = NOVALUE;
    object _30414 = NOVALUE;
    object _30412 = NOVALUE;
    object _30410 = NOVALUE;
    object _30408 = NOVALUE;
    object _30407 = NOVALUE;
    object _30406 = NOVALUE;
    object _30405 = NOVALUE;
    object _30404 = NOVALUE;
    object _30403 = NOVALUE;
    object _30402 = NOVALUE;
    object _30400 = NOVALUE;
    object _30399 = NOVALUE;
    object _30397 = NOVALUE;
    object _30395 = NOVALUE;
    object _30393 = NOVALUE;
    object _30392 = NOVALUE;
    object _30389 = NOVALUE;
    object _30388 = NOVALUE;
    object _30387 = NOVALUE;
    object _30386 = NOVALUE;
    object _30385 = NOVALUE;
    object _30381 = NOVALUE;
    object _30380 = NOVALUE;
    object _30379 = NOVALUE;
    object _30378 = NOVALUE;
    object _30377 = NOVALUE;
    object _30375 = NOVALUE;
    object _30374 = NOVALUE;
    object _30373 = NOVALUE;
    object _30371 = NOVALUE;
    object _30370 = NOVALUE;
    object _30369 = NOVALUE;
    object _30368 = NOVALUE;
    object _30364 = NOVALUE;
    object _30363 = NOVALUE;
    object _30362 = NOVALUE;
    object _30360 = NOVALUE;
    object _30359 = NOVALUE;
    object _30358 = NOVALUE;
    object _30357 = NOVALUE;
    object _30356 = NOVALUE;
    object _30355 = NOVALUE;
    object _30351 = NOVALUE;
    object _30350 = NOVALUE;
    object _30349 = NOVALUE;
    object _30347 = NOVALUE;
    object _30346 = NOVALUE;
    object _30345 = NOVALUE;
    object _30343 = NOVALUE;
    object _30342 = NOVALUE;
    object _30340 = NOVALUE;
    object _30339 = NOVALUE;
    object _30338 = NOVALUE;
    object _30334 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_prog_type_61263)) {
        _1 = (object)(DBL_PTR(_prog_type_61263)->dbl);
        DeRefDS(_prog_type_61263);
        _prog_type_61263 = _1;
    }

    /** parser.e:4105		integer first_def_arg*/

    /** parser.e:4106		integer again*/

    /** parser.e:4107		integer type_enum*/

    /** parser.e:4108		object seq_sym*/

    /** parser.e:4109		object i1_sym*/

    /** parser.e:4110		sequence enum_syms = {}*/
    RefDS(_22024);
    DeRef(_enum_syms_61280);
    _enum_syms_61280 = _22024;

    /** parser.e:4111		integer type_enum_gline, real_gline*/

    /** parser.e:4113		LeaveTopLevel()*/
    _43LeaveTopLevel();

    /** parser.e:4114		prog_name = next_token()*/
    _0 = _prog_name_61274;
    _prog_name_61274 = _43next_token();
    DeRef(_0);

    /** parser.e:4115		if prog_name[T_ID] = END_OF_FILE then*/
    _2 = (object)SEQ_PTR(_prog_name_61274);
    _30334 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30334, -21LL)){
        _30334 = NOVALUE;
        goto L1; // [45] 59
    }
    _30334 = NOVALUE;

    /** parser.e:4116			CompileErr( AN_IDENTIFIER_IS_EXPECTED_HERE)*/
    RefDS(_22024);
    _49CompileErr(32LL, _22024, 0LL);
L1: 

    /** parser.e:4118		type_enum =  0*/
    _type_enum_61277 = 0LL;

    /** parser.e:4119		if prog_type = TYPE_DECL then*/
    if (_prog_type_61263 != 416LL)
    goto L2; // [68] 322

    /** parser.e:4120			object tsym = prog_name[T_SYM]*/
    DeRef(_tsym_61294);
    _2 = (object)SEQ_PTR(_prog_name_61274);
    _tsym_61294 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_tsym_61294);

    /** parser.e:4121			if equal(sym_name(prog_name[T_SYM]),"enum") then*/
    _2 = (object)SEQ_PTR(_prog_name_61274);
    _30338 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30338);
    _30339 = _53sym_name(_30338);
    _30338 = NOVALUE;
    if (_30339 == _26264)
    _30340 = 1;
    else if (IS_ATOM_INT(_30339) && IS_ATOM_INT(_26264))
    _30340 = 0;
    else
    _30340 = (compare(_30339, _26264) == 0);
    DeRef(_30339);
    _30339 = NOVALUE;
    if (_30340 == 0)
    {
        _30340 = NOVALUE;
        goto L3; // [96] 319
    }
    else{
        _30340 = NOVALUE;
    }

    /** parser.e:4125				EnterTopLevel( FALSE )*/
    _43EnterTopLevel(_9FALSE_444);

    /** parser.e:4126				type_enum_gline = gline_number*/
    _type_enum_gline_61281 = _12gline_number_20231;

    /** parser.e:4127				type_enum = 1*/
    _type_enum_61277 = 1LL;

    /** parser.e:4128				sequence seq_symbol*/

    /** parser.e:4129				prog_name = next_token()*/
    _0 = _prog_name_61274;
    _prog_name_61274 = _43next_token();
    DeRef(_0);

    /** parser.e:4130				if not find(prog_name[T_ID], ADDR_TOKS) then*/
    _2 = (object)SEQ_PTR(_prog_name_61274);
    _30342 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30343 = find_from(_30342, _29ADDR_TOKS_12010, 1LL);
    _30342 = NOVALUE;
    if (_30343 != 0)
    goto L4; // [142] 169
    _30343 = NOVALUE;

    /** parser.e:4131					CompileErr(FOUND__1__BUT_WAS_EXPECTING_AN_IDENTIFIER_NAME, {find_category(prog_name[T_ID])} )*/
    _2 = (object)SEQ_PTR(_prog_name_61274);
    _30345 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_30345);
    _30346 = _62find_category(_30345);
    _30345 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30346;
    _30347 = MAKE_SEQ(_1);
    _30346 = NOVALUE;
    _49CompileErr(25LL, _30347, 0LL);
    _30347 = NOVALUE;
L4: 

    /** parser.e:4133				enum_syms = Global_declaration(-1, scope)*/
    _0 = _enum_syms_61280;
    _enum_syms_61280 = _43Global_declaration(-1LL, _scope_61264);
    DeRef(_0);

    /** parser.e:4134				seq_symbol = enum_syms*/
    RefDS(_enum_syms_61280);
    DeRef(_seq_symbol_61305);
    _seq_symbol_61305 = _enum_syms_61280;

    /** parser.e:4135				for i = 1 to length( enum_syms ) do*/
    if (IS_SEQUENCE(_enum_syms_61280)){
            _30349 = SEQ_PTR(_enum_syms_61280)->length;
    }
    else {
        _30349 = 1;
    }
    {
        object _i_61322;
        _i_61322 = 1LL;
L5: 
        if (_i_61322 > _30349){
            goto L6; // [190] 218
        }

        /** parser.e:4136					seq_symbol[i] = sym_obj(enum_syms[i])*/
        _2 = (object)SEQ_PTR(_enum_syms_61280);
        _30350 = (object)*(((s1_ptr)_2)->base + _i_61322);
        Ref(_30350);
        _30351 = _53sym_obj(_30350);
        _30350 = NOVALUE;
        _2 = (object)SEQ_PTR(_seq_symbol_61305);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _seq_symbol_61305 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_61322);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _30351;
        if( _1 != _30351 ){
            DeRef(_1);
        }
        _30351 = NOVALUE;

        /** parser.e:4137				end for*/
        _i_61322 = _i_61322 + 1LL;
        goto L5; // [213] 197
L6: 
        ;
    }

    /** parser.e:4142				i1_sym = keyfind("i1",-1)*/
    RefDS(_30352);
    DeRef(_31771);
    _31771 = _30352;
    _31772 = _53hashfn(_31771);
    _31771 = NOVALUE;
    RefDS(_30352);
    _0 = _i1_sym_61279;
    _i1_sym_61279 = _53keyfind(_30352, -1LL, _12current_file_no_20226, 0LL, _31772);
    DeRef(_0);
    _31772 = NOVALUE;

    /** parser.e:4143				seq_sym = NewStringSym(seq_symbol)*/
    RefDS(_seq_symbol_61305);
    _0 = _seq_sym_61278;
    _seq_sym_61278 = _53NewStringSym(_seq_symbol_61305);
    DeRef(_0);

    /** parser.e:4144				putback(keyfind("return",-1))*/
    RefDS(_26338);
    DeRef(_31769);
    _31769 = _26338;
    _31770 = _53hashfn(_31769);
    _31769 = NOVALUE;
    RefDS(_26338);
    _30355 = _53keyfind(_26338, -1LL, _12current_file_no_20226, 0LL, _31770);
    _31770 = NOVALUE;
    _43putback(_30355);
    _30355 = NOVALUE;

    /** parser.e:4145				putback({RIGHT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -27LL;
    ((intptr_t *)_2)[2] = 0LL;
    _30356 = MAKE_SEQ(_1);
    _43putback(_30356);
    _30356 = NOVALUE;

    /** parser.e:4146				putback(i1_sym)*/
    Ref(_i1_sym_61279);
    _43putback(_i1_sym_61279);

    /** parser.e:4147				putback(keyfind("object",-1))*/
    RefDS(_23004);
    DeRef(_31767);
    _31767 = _23004;
    _31768 = _53hashfn(_31767);
    _31767 = NOVALUE;
    RefDS(_23004);
    _30357 = _53keyfind(_23004, -1LL, _12current_file_no_20226, 0LL, _31768);
    _31768 = NOVALUE;
    _43putback(_30357);
    _30357 = NOVALUE;

    /** parser.e:4148				putback({LEFT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -26LL;
    ((intptr_t *)_2)[2] = 0LL;
    _30358 = MAKE_SEQ(_1);
    _43putback(_30358);
    _30358 = NOVALUE;

    /** parser.e:4150				LeaveTopLevel()*/
    _43LeaveTopLevel();
L3: 
    DeRef(_seq_symbol_61305);
    _seq_symbol_61305 = NOVALUE;
L2: 
    DeRef(_tsym_61294);
    _tsym_61294 = NOVALUE;

    /** parser.e:4153		if not find(prog_name[T_ID], ADDR_TOKS) then*/
    _2 = (object)SEQ_PTR(_prog_name_61274);
    _30359 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30360 = find_from(_30359, _29ADDR_TOKS_12010, 1LL);
    _30359 = NOVALUE;
    if (_30360 != 0)
    goto L7; // [339] 366
    _30360 = NOVALUE;

    /** parser.e:4154			CompileErr(FOUND__1__BUT_WAS_EXPECTING_AN_IDENTIFIER_NAME, {find_category(prog_name[T_ID])} )*/
    _2 = (object)SEQ_PTR(_prog_name_61274);
    _30362 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_30362);
    _30363 = _62find_category(_30362);
    _30362 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30363;
    _30364 = MAKE_SEQ(_1);
    _30363 = NOVALUE;
    _49CompileErr(25LL, _30364, 0LL);
    _30364 = NOVALUE;
L7: 

    /** parser.e:4156		p = prog_name[T_SYM]*/
    _2 = (object)SEQ_PTR(_prog_name_61274);
    _p_61269 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_p_61269)){
        _p_61269 = (object)DBL_PTR(_p_61269)->dbl;
    }

    /** parser.e:4157		DefinedYet(p)*/
    _53DefinedYet(_p_61269);

    /** parser.e:4158		if prog_type = PROCEDURE then*/
    if (_prog_type_61263 != 405LL)
    goto L8; // [385] 401

    /** parser.e:4159			pt = PROC*/
    _pt_61267 = 27LL;
    goto L9; // [398] 431
L8: 

    /** parser.e:4160		elsif prog_type = FUNCTION then*/
    if (_prog_type_61263 != 406LL)
    goto LA; // [405] 421

    /** parser.e:4161			pt = FUNC*/
    _pt_61267 = 501LL;
    goto L9; // [418] 431
LA: 

    /** parser.e:4163			pt = TYPE*/
    _pt_61267 = 504LL;
L9: 

    /** parser.e:4166		clear_fwd_refs()*/
    _42clear_fwd_refs();

    /** parser.e:4167		if find(SymTab[p][S_SCOPE], {SC_PREDEF, SC_GLOBAL, SC_PUBLIC, SC_EXPORT, SC_OVERRIDE}) then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30368 = (object)*(((s1_ptr)_2)->base + _p_61269);
    _2 = (object)SEQ_PTR(_30368);
    _30369 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30368 = NOVALUE;
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 7LL;
    ((intptr_t*)_2)[2] = 6LL;
    ((intptr_t*)_2)[3] = 13LL;
    ((intptr_t*)_2)[4] = 11LL;
    ((intptr_t*)_2)[5] = 12LL;
    _30370 = MAKE_SEQ(_1);
    _30371 = find_from(_30369, _30370, 1LL);
    _30369 = NOVALUE;
    DeRefDS(_30370);
    _30370 = NOVALUE;
    if (_30371 == 0)
    {
        _30371 = NOVALUE;
        goto LB; // [472] 668
    }
    else{
        _30371 = NOVALUE;
    }

    /** parser.e:4169			if scope = SC_OVERRIDE then*/
    if (_scope_61264 != 12LL)
    goto LC; // [479] 605

    /** parser.e:4170				if SymTab[p][S_SCOPE] = SC_PREDEF or SymTab[p][S_SCOPE] = SC_OVERRIDE then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30373 = (object)*(((s1_ptr)_2)->base + _p_61269);
    _2 = (object)SEQ_PTR(_30373);
    _30374 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30373 = NOVALUE;
    if (IS_ATOM_INT(_30374)) {
        _30375 = (_30374 == 7LL);
    }
    else {
        _30375 = binary_op(EQUALS, _30374, 7LL);
    }
    _30374 = NOVALUE;
    if (IS_ATOM_INT(_30375)) {
        if (_30375 != 0) {
            goto LD; // [503] 530
        }
    }
    else {
        if (DBL_PTR(_30375)->dbl != 0.0) {
            goto LD; // [503] 530
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30377 = (object)*(((s1_ptr)_2)->base + _p_61269);
    _2 = (object)SEQ_PTR(_30377);
    _30378 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30377 = NOVALUE;
    if (IS_ATOM_INT(_30378)) {
        _30379 = (_30378 == 12LL);
    }
    else {
        _30379 = binary_op(EQUALS, _30378, 12LL);
    }
    _30378 = NOVALUE;
    if (_30379 == 0) {
        DeRef(_30379);
        _30379 = NOVALUE;
        goto LE; // [526] 604
    }
    else {
        if (!IS_ATOM_INT(_30379) && DBL_PTR(_30379)->dbl == 0.0){
            DeRef(_30379);
            _30379 = NOVALUE;
            goto LE; // [526] 604
        }
        DeRef(_30379);
        _30379 = NOVALUE;
    }
    DeRef(_30379);
    _30379 = NOVALUE;
LD: 

    /** parser.e:4171						if SymTab[p][S_SCOPE] = SC_OVERRIDE then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30380 = (object)*(((s1_ptr)_2)->base + _p_61269);
    _2 = (object)SEQ_PTR(_30380);
    _30381 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30380 = NOVALUE;
    if (binary_op_a(NOTEQ, _30381, 12LL)){
        _30381 = NOVALUE;
        goto LF; // [546] 558
    }
    _30381 = NOVALUE;

    /** parser.e:4172							again = 223*/
    _again_61276 = 223LL;
    goto L10; // [555] 564
LF: 

    /** parser.e:4174							again = 222*/
    _again_61276 = 222LL;
L10: 

    /** parser.e:4176						Warning(again, override_warning_flag,*/
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _30385 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30386 = (object)*(((s1_ptr)_2)->base + _p_61269);
    _2 = (object)SEQ_PTR(_30386);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _30387 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _30387 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _30386 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_30385);
    ((intptr_t*)_2)[1] = _30385;
    ((intptr_t*)_2)[2] = _12line_number_20227;
    Ref(_30387);
    ((intptr_t*)_2)[3] = _30387;
    _30388 = MAKE_SEQ(_1);
    _30387 = NOVALUE;
    _30385 = NOVALUE;
    _49Warning(_again_61276, 4LL, _30388);
    _30388 = NOVALUE;
LE: 
LC: 

    /** parser.e:4181			h = SymTab[p][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30389 = (object)*(((s1_ptr)_2)->base + _p_61269);
    _2 = (object)SEQ_PTR(_30389);
    _h_61266 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (!IS_ATOM_INT(_h_61266)){
        _h_61266 = (object)DBL_PTR(_h_61266)->dbl;
    }
    _30389 = NOVALUE;

    /** parser.e:4182			sym = buckets[h]*/
    _2 = (object)SEQ_PTR(_53buckets_46842);
    _sym_61271 = (object)*(((s1_ptr)_2)->base + _h_61266);
    if (!IS_ATOM_INT(_sym_61271)){
        _sym_61271 = (object)DBL_PTR(_sym_61271)->dbl;
    }

    /** parser.e:4183			p = NewEntry(SymTab[p][S_NAME], 0, 0, pt, h, sym, 0)*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30392 = (object)*(((s1_ptr)_2)->base + _p_61269);
    _2 = (object)SEQ_PTR(_30392);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _30393 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _30393 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _30392 = NOVALUE;
    Ref(_30393);
    _p_61269 = _53NewEntry(_30393, 0LL, 0LL, _pt_61267, _h_61266, _sym_61271, 0LL);
    _30393 = NOVALUE;
    if (!IS_ATOM_INT(_p_61269)) {
        _1 = (object)(DBL_PTR(_p_61269)->dbl);
        DeRefDS(_p_61269);
        _p_61269 = _1;
    }

    /** parser.e:4184			buckets[h] = p*/
    _2 = (object)SEQ_PTR(_53buckets_46842);
    _2 = (object)(((s1_ptr)_2)->base + _h_61266);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _p_61269;
    DeRef(_1);
LB: 

    /** parser.e:4187		Start_block( pt, p )*/
    _64Start_block(_pt_61267, _p_61269);

    /** parser.e:4189		CurrentSub = p*/
    _12CurrentSub_20234 = _p_61269;

    /** parser.e:4190		first_def_arg = 0*/
    _first_def_arg_61275 = 0LL;

    /** parser.e:4191		temps_allocated = 0*/
    _53temps_allocated_47379 = 0LL;

    /** parser.e:4193		SymTab[p][S_SCOPE] = scope*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61269 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _scope_61264;
    DeRef(_1);
    _30395 = NOVALUE;

    /** parser.e:4195		SymTab[p][S_TOKEN] = pt*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61269 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_TOKEN_19869))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _pt_61267;
    DeRef(_1);
    _30397 = NOVALUE;

    /** parser.e:4197		if length(SymTab[p]) < SIZEOF_ROUTINE_ENTRY then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30399 = (object)*(((s1_ptr)_2)->base + _p_61269);
    if (IS_SEQUENCE(_30399)){
            _30400 = SEQ_PTR(_30399)->length;
    }
    else {
        _30400 = 1;
    }
    _30399 = NOVALUE;
    if (_30400 >= _12SIZEOF_ROUTINE_ENTRY_19990)
    goto L11; // [738] 780

    /** parser.e:4199			SymTab[p] = SymTab[p] & repeat(0, SIZEOF_ROUTINE_ENTRY -*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30402 = (object)*(((s1_ptr)_2)->base + _p_61269);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30403 = (object)*(((s1_ptr)_2)->base + _p_61269);
    if (IS_SEQUENCE(_30403)){
            _30404 = SEQ_PTR(_30403)->length;
    }
    else {
        _30404 = 1;
    }
    _30403 = NOVALUE;
    _30405 = _12SIZEOF_ROUTINE_ENTRY_19990 - _30404;
    _30404 = NOVALUE;
    _30406 = Repeat(0LL, _30405);
    _30405 = NOVALUE;
    if (IS_SEQUENCE(_30402) && IS_ATOM(_30406)) {
    }
    else if (IS_ATOM(_30402) && IS_SEQUENCE(_30406)) {
        Ref(_30402);
        Prepend(&_30407, _30406, _30402);
    }
    else {
        Concat((object_ptr)&_30407, _30402, _30406);
        _30402 = NOVALUE;
    }
    _30402 = NOVALUE;
    DeRefDS(_30406);
    _30406 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _p_61269);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30407;
    if( _1 != _30407 ){
        DeRef(_1);
    }
    _30407 = NOVALUE;
L11: 

    /** parser.e:4203		SymTab[p][S_CODE] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61269 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_19876))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30408 = NOVALUE;

    /** parser.e:4204		SymTab[p][S_LINETAB] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61269 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_LINETAB_19899))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_LINETAB_19899)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_LINETAB_19899);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30410 = NOVALUE;

    /** parser.e:4205		SymTab[p][S_EFFECT] = E_PURE*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61269 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30412 = NOVALUE;

    /** parser.e:4206		SymTab[p][S_REFLIST] = {}*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61269 + ((s1_ptr)_2)->base);
    RefDS(_22024);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 24LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22024;
    DeRef(_1);
    _30414 = NOVALUE;

    /** parser.e:4207		SymTab[p][S_FIRSTLINE] = gline_number*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61269 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_FIRSTLINE_19904))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FIRSTLINE_19904)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_FIRSTLINE_19904);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12gline_number_20231;
    DeRef(_1);
    _30416 = NOVALUE;

    /** parser.e:4208		SymTab[p][S_TEMPS] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61269 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_TEMPS_19909))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TEMPS_19909)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_TEMPS_19909);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30418 = NOVALUE;

    /** parser.e:4209		SymTab[p][S_RESIDENT_TASK] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61269 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30420 = NOVALUE;

    /** parser.e:4210		SymTab[p][S_SAVED_PRIVATES] = {}*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61269 + ((s1_ptr)_2)->base);
    RefDS(_22024);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 26LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22024;
    DeRef(_1);
    _30422 = NOVALUE;

    /** parser.e:4211		SymTab[p][S_DEPRECATED] = deprecated*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61269 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _deprecated_61265;
    DeRef(_1);
    _30424 = NOVALUE;

    /** parser.e:4213		if type_enum then*/
    if (_type_enum_61277 == 0)
    {
        goto L12; // [921] 978
    }
    else{
    }

    /** parser.e:4214			SymTab[p][S_FIRSTLINE] = type_enum_gline*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61269 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_FIRSTLINE_19904))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FIRSTLINE_19904)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_FIRSTLINE_19904);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _type_enum_gline_61281;
    DeRef(_1);
    _30426 = NOVALUE;

    /** parser.e:4215			real_gline = gline_number*/
    _real_gline_61282 = _12gline_number_20231;

    /** parser.e:4216			gline_number = type_enum_gline*/
    _12gline_number_20231 = _type_enum_gline_61281;

    /** parser.e:4217			StartSourceLine( FALSE, , COVERAGE_OVERRIDE )*/
    _45StartSourceLine(_9FALSE_444, 0LL, 3LL);

    /** parser.e:4218			gline_number = real_gline*/
    _12gline_number_20231 = _real_gline_61282;
    goto L13; // [975] 990
L12: 

    /** parser.e:4220			StartSourceLine(FALSE, , COVERAGE_OVERRIDE)*/
    _45StartSourceLine(_9FALSE_444, 0LL, 3LL);
L13: 

    /** parser.e:4223		tok_match(LEFT_ROUND)*/
    _43tok_match(-26LL, 0LL);

    /** parser.e:4224		tok = next_token()*/
    _0 = _tok_61273;
    _tok_61273 = _43next_token();
    DeRef(_0);

    /** parser.e:4225		param_num = 0*/
    _43param_num_55024 = 0LL;

    /** parser.e:4228		sequence middle_def_args = {}*/
    RefDS(_22024);
    DeRef(_middle_def_args_61512);
    _middle_def_args_61512 = _22024;

    /** parser.e:4229		integer last_nda = 0, start_def = 0*/
    _last_nda_61513 = 0LL;
    _start_def_61514 = 0LL;

    /** parser.e:4230		symtab_index last_link = p*/
    _last_link_61516 = _p_61269;

    /** parser.e:4231		while tok[T_ID] != RIGHT_ROUND do*/
L14: 
    _2 = (object)SEQ_PTR(_tok_61273);
    _30429 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _30429, -27LL)){
        _30429 = NOVALUE;
        goto L15; // [1043] 1830
    }
    _30429 = NOVALUE;

    /** parser.e:4234			if tok[T_ID] != TYPE and tok[T_ID] != QUALIFIED_TYPE then*/
    _2 = (object)SEQ_PTR(_tok_61273);
    _30431 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30431)) {
        _30432 = (_30431 != 504LL);
    }
    else {
        _30432 = binary_op(NOTEQ, _30431, 504LL);
    }
    _30431 = NOVALUE;
    if (IS_ATOM_INT(_30432)) {
        if (_30432 == 0) {
            goto L16; // [1061] 1291
        }
    }
    else {
        if (DBL_PTR(_30432)->dbl == 0.0) {
            goto L16; // [1061] 1291
        }
    }
    _2 = (object)SEQ_PTR(_tok_61273);
    _30434 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30434)) {
        _30435 = (_30434 != 522LL);
    }
    else {
        _30435 = binary_op(NOTEQ, _30434, 522LL);
    }
    _30434 = NOVALUE;
    if (_30435 == 0) {
        DeRef(_30435);
        _30435 = NOVALUE;
        goto L16; // [1078] 1291
    }
    else {
        if (!IS_ATOM_INT(_30435) && DBL_PTR(_30435)->dbl == 0.0){
            DeRef(_30435);
            _30435 = NOVALUE;
            goto L16; // [1078] 1291
        }
        DeRef(_30435);
        _30435 = NOVALUE;
    }
    DeRef(_30435);
    _30435 = NOVALUE;

    /** parser.e:4235				if tok[T_ID] = VARIABLE or tok[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_61273);
    _30436 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30436)) {
        _30437 = (_30436 == -100LL);
    }
    else {
        _30437 = binary_op(EQUALS, _30436, -100LL);
    }
    _30436 = NOVALUE;
    if (IS_ATOM_INT(_30437)) {
        if (_30437 != 0) {
            goto L17; // [1095] 1116
        }
    }
    else {
        if (DBL_PTR(_30437)->dbl != 0.0) {
            goto L17; // [1095] 1116
        }
    }
    _2 = (object)SEQ_PTR(_tok_61273);
    _30439 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30439)) {
        _30440 = (_30439 == 512LL);
    }
    else {
        _30440 = binary_op(EQUALS, _30439, 512LL);
    }
    _30439 = NOVALUE;
    if (_30440 == 0) {
        DeRef(_30440);
        _30440 = NOVALUE;
        goto L18; // [1112] 1280
    }
    else {
        if (!IS_ATOM_INT(_30440) && DBL_PTR(_30440)->dbl == 0.0){
            DeRef(_30440);
            _30440 = NOVALUE;
            goto L18; // [1112] 1280
        }
        DeRef(_30440);
        _30440 = NOVALUE;
    }
    DeRef(_30440);
    _30440 = NOVALUE;
L17: 

    /** parser.e:4237					token temptok = next_token()*/
    _0 = _temptok_61543;
    _temptok_61543 = _43next_token();
    DeRef(_0);

    /** parser.e:4238					integer undef_type = 0*/
    _undef_type_61545 = 0LL;

    /** parser.e:4239					if temptok[T_ID] != TYPE and temptok[T_ID] != QUALIFIED_TYPE then*/
    _2 = (object)SEQ_PTR(_temptok_61543);
    _30442 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30442)) {
        _30443 = (_30442 != 504LL);
    }
    else {
        _30443 = binary_op(NOTEQ, _30442, 504LL);
    }
    _30442 = NOVALUE;
    if (IS_ATOM_INT(_30443)) {
        if (_30443 == 0) {
            goto L19; // [1140] 1243
        }
    }
    else {
        if (DBL_PTR(_30443)->dbl == 0.0) {
            goto L19; // [1140] 1243
        }
    }
    _2 = (object)SEQ_PTR(_temptok_61543);
    _30445 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30445)) {
        _30446 = (_30445 != 522LL);
    }
    else {
        _30446 = binary_op(NOTEQ, _30445, 522LL);
    }
    _30445 = NOVALUE;
    if (_30446 == 0) {
        DeRef(_30446);
        _30446 = NOVALUE;
        goto L19; // [1157] 1243
    }
    else {
        if (!IS_ATOM_INT(_30446) && DBL_PTR(_30446)->dbl == 0.0){
            DeRef(_30446);
            _30446 = NOVALUE;
            goto L19; // [1157] 1243
        }
        DeRef(_30446);
        _30446 = NOVALUE;
    }
    DeRef(_30446);
    _30446 = NOVALUE;

    /** parser.e:4240						if find( temptok[T_ID], FULL_ID_TOKS) then*/
    _2 = (object)SEQ_PTR(_temptok_61543);
    _30447 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30448 = find_from(_30447, _29FULL_ID_TOKS_12014, 1LL);
    _30447 = NOVALUE;
    if (_30448 == 0)
    {
        _30448 = NOVALUE;
        goto L1A; // [1175] 1242
    }
    else{
        _30448 = NOVALUE;
    }

    /** parser.e:4242							if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_tok_61273);
    _30449 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_30449)){
        _30450 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30449)->dbl));
    }
    else{
        _30450 = (object)*(((s1_ptr)_2)->base + _30449);
    }
    _2 = (object)SEQ_PTR(_30450);
    _30451 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30450 = NOVALUE;
    if (binary_op_a(NOTEQ, _30451, 9LL)){
        _30451 = NOVALUE;
        goto L1B; // [1200] 1231
    }
    _30451 = NOVALUE;

    /** parser.e:4245								undef_type = - new_forward_reference( TYPE, tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_61273);
    _30453 = (object)*(((s1_ptr)_2)->base + 2LL);
    DeRef(_31766);
    _31766 = 504LL;
    Ref(_30453);
    _30454 = _42new_forward_reference(504LL, _30453, 504LL);
    _30453 = NOVALUE;
    _31766 = NOVALUE;
    if (IS_ATOM_INT(_30454)) {
        if ((uintptr_t)_30454 == (uintptr_t)HIGH_BITS){
            _undef_type_61545 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _undef_type_61545 = - _30454;
        }
    }
    else {
        _undef_type_61545 = unary_op(UMINUS, _30454);
    }
    DeRef(_30454);
    _30454 = NOVALUE;
    if (!IS_ATOM_INT(_undef_type_61545)) {
        _1 = (object)(DBL_PTR(_undef_type_61545)->dbl);
        DeRefDS(_undef_type_61545);
        _undef_type_61545 = _1;
    }
    goto L1C; // [1228] 1241
L1B: 

    /** parser.e:4247								CompileErr(A_TYPE_IS_EXPECTED_HERE)*/
    RefDS(_22024);
    _49CompileErr(37LL, _22024, 0LL);
L1C: 
L1A: 
L19: 

    /** parser.e:4251					putback(temptok) -- Return whatever came after the name back onto the token stream.*/
    Ref(_temptok_61543);
    _43putback(_temptok_61543);

    /** parser.e:4252					if undef_type != 0 then*/
    if (_undef_type_61545 == 0LL)
    goto L1D; // [1250] 1265

    /** parser.e:4254						tok[T_SYM] = undef_type*/
    _2 = (object)SEQ_PTR(_tok_61273);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_61273 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _undef_type_61545;
    DeRef(_1);
    goto L1E; // [1262] 1275
L1D: 

    /** parser.e:4256						CompileErr(A_TYPE_IS_EXPECTED_HERE)*/
    RefDS(_22024);
    _49CompileErr(37LL, _22024, 0LL);
L1E: 
    DeRef(_temptok_61543);
    _temptok_61543 = NOVALUE;
    goto L1F; // [1277] 1290
L18: 

    /** parser.e:4259					CompileErr(A_TYPE_IS_EXPECTED_HERE)*/
    RefDS(_22024);
    _49CompileErr(37LL, _22024, 0LL);
L1F: 
L16: 

    /** parser.e:4262			type_sym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_61273);
    _type_sym_61270 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_type_sym_61270)){
        _type_sym_61270 = (object)DBL_PTR(_type_sym_61270)->dbl;
    }

    /** parser.e:4263			tok = next_token()*/
    _0 = _tok_61273;
    _tok_61273 = _43next_token();
    DeRef(_0);

    /** parser.e:4264			if not find(tok[T_ID], ID_TOKS) then*/
    _2 = (object)SEQ_PTR(_tok_61273);
    _30459 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30460 = find_from(_30459, _29ID_TOKS_12012, 1LL);
    _30459 = NOVALUE;
    if (_30460 != 0)
    goto L20; // [1321] 1439
    _30460 = NOVALUE;

    /** parser.e:4265				sequence tokcat = find_category(tok[T_ID])*/
    _2 = (object)SEQ_PTR(_tok_61273);
    _30462 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_30462);
    _0 = _tokcat_61597;
    _tokcat_61597 = _62find_category(_30462);
    DeRef(_0);
    _30462 = NOVALUE;

    /** parser.e:4266				if tok[T_SYM] != 0 and length(SymTab[tok[T_SYM]]) >= S_NAME then*/
    _2 = (object)SEQ_PTR(_tok_61273);
    _30464 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_30464)) {
        _30465 = (_30464 != 0LL);
    }
    else {
        _30465 = binary_op(NOTEQ, _30464, 0LL);
    }
    _30464 = NOVALUE;
    if (IS_ATOM_INT(_30465)) {
        if (_30465 == 0) {
            goto L21; // [1350] 1413
        }
    }
    else {
        if (DBL_PTR(_30465)->dbl == 0.0) {
            goto L21; // [1350] 1413
        }
    }
    _2 = (object)SEQ_PTR(_tok_61273);
    _30467 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_30467)){
        _30468 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30467)->dbl));
    }
    else{
        _30468 = (object)*(((s1_ptr)_2)->base + _30467);
    }
    if (IS_SEQUENCE(_30468)){
            _30469 = SEQ_PTR(_30468)->length;
    }
    else {
        _30469 = 1;
    }
    _30468 = NOVALUE;
    if (IS_ATOM_INT(_12S_NAME_19864)) {
        _30470 = (_30469 >= _12S_NAME_19864);
    }
    else {
        _30470 = binary_op(GREATEREQ, _30469, _12S_NAME_19864);
    }
    _30469 = NOVALUE;
    if (_30470 == 0) {
        DeRef(_30470);
        _30470 = NOVALUE;
        goto L21; // [1376] 1413
    }
    else {
        if (!IS_ATOM_INT(_30470) && DBL_PTR(_30470)->dbl == 0.0){
            DeRef(_30470);
            _30470 = NOVALUE;
            goto L21; // [1376] 1413
        }
        DeRef(_30470);
        _30470 = NOVALUE;
    }
    DeRef(_30470);
    _30470 = NOVALUE;

    /** parser.e:4267					CompileErr(FOUND_1_2_BUT_WAS_EXPECTING_A_PARAMETER_NAME_INSTEAD, {tokcat, SymTab[tok[T_SYM]][S_NAME]})*/
    _2 = (object)SEQ_PTR(_tok_61273);
    _30471 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_30471)){
        _30472 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30471)->dbl));
    }
    else{
        _30472 = (object)*(((s1_ptr)_2)->base + _30471);
    }
    _2 = (object)SEQ_PTR(_30472);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _30473 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _30473 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _30472 = NOVALUE;
    Ref(_30473);
    RefDS(_tokcat_61597);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _tokcat_61597;
    ((intptr_t *)_2)[2] = _30473;
    _30474 = MAKE_SEQ(_1);
    _30473 = NOVALUE;
    _49CompileErr(90LL, _30474, 0LL);
    _30474 = NOVALUE;
    goto L22; // [1410] 1438
L21: 

    /** parser.e:4269					CompileErr(FOUND_1_BUT_WAS_EXPECTING_A_PARAMETER_NAME_INSTEAD, {LexName(tok[T_ID])})*/
    _2 = (object)SEQ_PTR(_tok_61273);
    _30475 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_30475);
    RefDS(_26412);
    _30476 = _45LexName(_30475, _26412);
    _30475 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30476;
    _30477 = MAKE_SEQ(_1);
    _30476 = NOVALUE;
    _49CompileErr(92LL, _30477, 0LL);
    _30477 = NOVALUE;
L22: 
L20: 
    DeRef(_tokcat_61597);
    _tokcat_61597 = NOVALUE;

    /** parser.e:4272			sym = SetPrivateScope(tok[T_SYM], type_sym, param_num)*/
    _2 = (object)SEQ_PTR(_tok_61273);
    _30478 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30478);
    _sym_61271 = _43SetPrivateScope(_30478, _type_sym_61270, _43param_num_55024);
    _30478 = NOVALUE;
    if (!IS_ATOM_INT(_sym_61271)) {
        _1 = (object)(DBL_PTR(_sym_61271)->dbl);
        DeRefDS(_sym_61271);
        _sym_61271 = _1;
    }

    /** parser.e:4273			param_num += 1*/
    _43param_num_55024 = _43param_num_55024 + 1;

    /** parser.e:4275			if SymTab[last_link][S_NEXT] != sym*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30481 = (object)*(((s1_ptr)_2)->base + _last_link_61516);
    _2 = (object)SEQ_PTR(_30481);
    _30482 = (object)*(((s1_ptr)_2)->base + 2LL);
    _30481 = NOVALUE;
    if (IS_ATOM_INT(_30482)) {
        _30483 = (_30482 != _sym_61271);
    }
    else {
        _30483 = binary_op(NOTEQ, _30482, _sym_61271);
    }
    _30482 = NOVALUE;
    if (IS_ATOM_INT(_30483)) {
        if (_30483 == 0) {
            goto L23; // [1485] 1566
        }
    }
    else {
        if (DBL_PTR(_30483)->dbl == 0.0) {
            goto L23; // [1485] 1566
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30485 = (object)*(((s1_ptr)_2)->base + _last_link_61516);
    _2 = (object)SEQ_PTR(_30485);
    _30486 = (object)*(((s1_ptr)_2)->base + 2LL);
    _30485 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_30486)){
        _30487 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30486)->dbl));
    }
    else{
        _30487 = (object)*(((s1_ptr)_2)->base + _30486);
    }
    _2 = (object)SEQ_PTR(_30487);
    _30488 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30487 = NOVALUE;
    if (IS_ATOM_INT(_30488)) {
        _30489 = (_30488 == 9LL);
    }
    else {
        _30489 = binary_op(EQUALS, _30488, 9LL);
    }
    _30488 = NOVALUE;
    if (_30489 == 0) {
        DeRef(_30489);
        _30489 = NOVALUE;
        goto L23; // [1520] 1566
    }
    else {
        if (!IS_ATOM_INT(_30489) && DBL_PTR(_30489)->dbl == 0.0){
            DeRef(_30489);
            _30489 = NOVALUE;
            goto L23; // [1520] 1566
        }
        DeRef(_30489);
        _30489 = NOVALUE;
    }
    DeRef(_30489);
    _30489 = NOVALUE;

    /** parser.e:4278				SymTab[SymTab[last_link][S_NEXT]][S_NEXT] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30490 = (object)*(((s1_ptr)_2)->base + _last_link_61516);
    _2 = (object)SEQ_PTR(_30490);
    _30491 = (object)*(((s1_ptr)_2)->base + 2LL);
    _30490 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_30491))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_30491)->dbl));
    else
    _3 = (object)(_30491 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30492 = NOVALUE;

    /** parser.e:4279				SymTab[last_link][S_NEXT] = sym*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_last_link_61516 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_61271;
    DeRef(_1);
    _30494 = NOVALUE;
L23: 

    /** parser.e:4282			last_link = sym*/
    _last_link_61516 = _sym_61271;

    /** parser.e:4284			if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L24; // [1577] 1600
    }
    else{
    }

    /** parser.e:4285				SymTab[sym][S_GTYPE] = CompileType(type_sym)*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_61271 + ((s1_ptr)_2)->base);
    _30498 = _43CompileType(_type_sym_61270);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30498;
    if( _1 != _30498 ){
        DeRef(_1);
    }
    _30498 = NOVALUE;
    _30496 = NOVALUE;
L24: 

    /** parser.e:4289			tok = next_token()*/
    _0 = _tok_61273;
    _tok_61273 = _43next_token();
    DeRef(_0);

    /** parser.e:4290			if tok[T_ID] = EQUALS then -- defaulted parameter*/
    _2 = (object)SEQ_PTR(_tok_61273);
    _30500 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30500, 3LL)){
        _30500 = NOVALUE;
        goto L25; // [1615] 1697
    }
    _30500 = NOVALUE;

    /** parser.e:4291				start_recording()*/
    _43start_recording();

    /** parser.e:4292				Expr()*/
    _43Expr();

    /** parser.e:4293				SymTab[sym][S_CODE] = restore_parser()*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_61271 + ((s1_ptr)_2)->base);
    _30504 = _43restore_parser();
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_19876))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30504;
    if( _1 != _30504 ){
        DeRef(_1);
    }
    _30504 = NOVALUE;
    _30502 = NOVALUE;

    /** parser.e:4294				if Pop() then end if -- don't leak the default argument*/
    _30505 = _45Pop();
    if (_30505 == 0) {
        DeRef(_30505);
        _30505 = NOVALUE;
        goto L26; // [1650] 1654
    }
    else {
        if (!IS_ATOM_INT(_30505) && DBL_PTR(_30505)->dbl == 0.0){
            DeRef(_30505);
            _30505 = NOVALUE;
            goto L26; // [1650] 1654
        }
        DeRef(_30505);
        _30505 = NOVALUE;
    }
    DeRef(_30505);
    _30505 = NOVALUE;
L26: 

    /** parser.e:4295				tok = next_token()*/
    _0 = _tok_61273;
    _tok_61273 = _43next_token();
    DeRef(_0);

    /** parser.e:4296				if first_def_arg = 0 then*/
    if (_first_def_arg_61275 != 0LL)
    goto L27; // [1661] 1673

    /** parser.e:4297					first_def_arg = param_num*/
    _first_def_arg_61275 = _43param_num_55024;
L27: 

    /** parser.e:4299				previous_op = -1 -- no interferences betwen defparms, or them and subsequent code*/
    _12previous_op_20325 = -1LL;

    /** parser.e:4300				if start_def = 0 then*/
    if (_start_def_61514 != 0LL)
    goto L28; // [1682] 1754

    /** parser.e:4301					start_def = param_num*/
    _start_def_61514 = _43param_num_55024;
    goto L28; // [1694] 1754
L25: 

    /** parser.e:4304				last_nda = param_num*/
    _last_nda_61513 = _43param_num_55024;

    /** parser.e:4305				if start_def then*/
    if (_start_def_61514 == 0)
    {
        goto L29; // [1706] 1753
    }
    else{
    }

    /** parser.e:4306					if start_def = param_num-1 then*/
    _30509 = _43param_num_55024 - 1LL;
    if ((object)((uintptr_t)_30509 +(uintptr_t) HIGH_BITS) >= 0){
        _30509 = NewDouble((eudouble)_30509);
    }
    if (binary_op_a(NOTEQ, _start_def_61514, _30509)){
        DeRef(_30509);
        _30509 = NOVALUE;
        goto L2A; // [1717] 1730
    }
    DeRef(_30509);
    _30509 = NOVALUE;

    /** parser.e:4307						middle_def_args &= start_def*/
    Append(&_middle_def_args_61512, _middle_def_args_61512, _start_def_61514);
    goto L2B; // [1727] 1747
L2A: 

    /** parser.e:4309						middle_def_args = append(middle_def_args, {start_def, param_num-1})*/
    _30512 = _43param_num_55024 - 1LL;
    if ((object)((uintptr_t)_30512 +(uintptr_t) HIGH_BITS) >= 0){
        _30512 = NewDouble((eudouble)_30512);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _start_def_61514;
    ((intptr_t *)_2)[2] = _30512;
    _30513 = MAKE_SEQ(_1);
    _30512 = NOVALUE;
    RefDS(_30513);
    Append(&_middle_def_args_61512, _middle_def_args_61512, _30513);
    DeRefDS(_30513);
    _30513 = NOVALUE;
L2B: 

    /** parser.e:4311					start_def = 0*/
    _start_def_61514 = 0LL;
L29: 
L28: 

    /** parser.e:4314			if tok[T_ID] = COMMA then*/
    _2 = (object)SEQ_PTR(_tok_61273);
    _30515 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30515, -30LL)){
        _30515 = NOVALUE;
        goto L2C; // [1764] 1800
    }
    _30515 = NOVALUE;

    /** parser.e:4315				tok = next_token()*/
    _0 = _tok_61273;
    _tok_61273 = _43next_token();
    DeRef(_0);

    /** parser.e:4316				if tok[T_ID] = RIGHT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok_61273);
    _30518 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30518, -27LL)){
        _30518 = NOVALUE;
        goto L14; // [1783] 1035
    }
    _30518 = NOVALUE;

    /** parser.e:4317					CompileErr(EXPECTED_TO_SEE_A_PARAMETER_DECLARATION_NOT)*/
    RefDS(_22024);
    _49CompileErr(85LL, _22024, 0LL);
    goto L14; // [1797] 1035
L2C: 

    /** parser.e:4319			elsif tok[T_ID] != RIGHT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok_61273);
    _30520 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _30520, -27LL)){
        _30520 = NOVALUE;
        goto L14; // [1810] 1035
    }
    _30520 = NOVALUE;

    /** parser.e:4320				CompileErr(BADLYFORMED_LIST_OF_PARAMETERS__EXPECTED__OR)*/
    RefDS(_22024);
    _49CompileErr(41LL, _22024, 0LL);

    /** parser.e:4322		end while*/
    goto L14; // [1827] 1035
L15: 

    /** parser.e:4323		Code = {} -- removes any spurious code emitted while recording parameters*/
    RefDS(_22024);
    DeRef(_12Code_20315);
    _12Code_20315 = _22024;

    /** parser.e:4325		SymTab[p][S_NUM_ARGS] = param_num*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61269 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _43param_num_55024;
    DeRef(_1);
    _30522 = NOVALUE;

    /** parser.e:4326		SymTab[p][S_DEF_ARGS] = {first_def_arg, last_nda, middle_def_args}*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61269 + ((s1_ptr)_2)->base);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _first_def_arg_61275;
    ((intptr_t*)_2)[2] = _last_nda_61513;
    RefDS(_middle_def_args_61512);
    ((intptr_t*)_2)[3] = _middle_def_args_61512;
    _30526 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 28LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30526;
    if( _1 != _30526 ){
        DeRef(_1);
    }
    _30526 = NOVALUE;
    _30524 = NOVALUE;

    /** parser.e:4327		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L2D; // [1879] 1913
    }
    else{
    }

    /** parser.e:4328			if param_num > max_params then*/
    if (_43param_num_55024 <= _45max_params_51026)
    goto L2E; // [1888] 1902

    /** parser.e:4329				max_params = param_num*/
    _45max_params_51026 = _43param_num_55024;
L2E: 

    /** parser.e:4331			num_routines += 1*/
    _12num_routines_20235 = _12num_routines_20235 + 1LL;
L2D: 

    /** parser.e:4333		if SymTab[p][S_TOKEN] = TYPE and param_num != 1 then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30529 = (object)*(((s1_ptr)_2)->base + _p_61269);
    _2 = (object)SEQ_PTR(_30529);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _30530 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _30530 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _30529 = NOVALUE;
    if (IS_ATOM_INT(_30530)) {
        _30531 = (_30530 == 504LL);
    }
    else {
        _30531 = binary_op(EQUALS, _30530, 504LL);
    }
    _30530 = NOVALUE;
    if (IS_ATOM_INT(_30531)) {
        if (_30531 == 0) {
            goto L2F; // [1933] 1957
        }
    }
    else {
        if (DBL_PTR(_30531)->dbl == 0.0) {
            goto L2F; // [1933] 1957
        }
    }
    _30533 = (_43param_num_55024 != 1LL);
    if (_30533 == 0)
    {
        DeRef(_30533);
        _30533 = NOVALUE;
        goto L2F; // [1944] 1957
    }
    else{
        DeRef(_30533);
        _30533 = NOVALUE;
    }

    /** parser.e:4334			CompileErr(TYPES_MUST_HAVE_EXACTLY_ONE_PARAMETER)*/
    RefDS(_22024);
    _49CompileErr(148LL, _22024, 0LL);
L2F: 

    /** parser.e:4337		include_routine()*/
    _50include_routine();

    /** parser.e:4340		sym = SymTab[p][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30534 = (object)*(((s1_ptr)_2)->base + _p_61269);
    _2 = (object)SEQ_PTR(_30534);
    _sym_61271 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_sym_61271)){
        _sym_61271 = (object)DBL_PTR(_sym_61271)->dbl;
    }
    _30534 = NOVALUE;

    /** parser.e:4341		for i = 1 to SymTab[p][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30536 = (object)*(((s1_ptr)_2)->base + _p_61269);
    _2 = (object)SEQ_PTR(_30536);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _30537 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _30537 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _30536 = NOVALUE;
    {
        object _i_61756;
        _i_61756 = 1LL;
L30: 
        if (binary_op_a(GREATER, _i_61756, _30537)){
            goto L31; // [1991] 2070
        }

        /** parser.e:4342			while SymTab[sym][S_SCOPE] != SC_PRIVATE do*/
L32: 
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _30538 = (object)*(((s1_ptr)_2)->base + _sym_61271);
        _2 = (object)SEQ_PTR(_30538);
        _30539 = (object)*(((s1_ptr)_2)->base + 4LL);
        _30538 = NOVALUE;
        if (binary_op_a(EQUALS, _30539, 3LL)){
            _30539 = NOVALUE;
            goto L33; // [2017] 2042
        }
        _30539 = NOVALUE;

        /** parser.e:4343				sym = SymTab[sym][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _30541 = (object)*(((s1_ptr)_2)->base + _sym_61271);
        _2 = (object)SEQ_PTR(_30541);
        _sym_61271 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_sym_61271)){
            _sym_61271 = (object)DBL_PTR(_sym_61271)->dbl;
        }
        _30541 = NOVALUE;

        /** parser.e:4344			end while*/
        goto L32; // [2039] 2003
L33: 

        /** parser.e:4345			TypeCheck(sym)*/
        _43TypeCheck(_sym_61271);

        /** parser.e:4346			sym = SymTab[sym][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _30543 = (object)*(((s1_ptr)_2)->base + _sym_61271);
        _2 = (object)SEQ_PTR(_30543);
        _sym_61271 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_sym_61271)){
            _sym_61271 = (object)DBL_PTR(_sym_61271)->dbl;
        }
        _30543 = NOVALUE;

        /** parser.e:4347		end for*/
        _0 = _i_61756;
        if (IS_ATOM_INT(_i_61756)) {
            _i_61756 = _i_61756 + 1LL;
            if ((object)((uintptr_t)_i_61756 +(uintptr_t) HIGH_BITS) >= 0){
                _i_61756 = NewDouble((eudouble)_i_61756);
            }
        }
        else {
            _i_61756 = binary_op_a(PLUS, _i_61756, 1LL);
        }
        DeRef(_0);
        goto L30; // [2065] 1998
L31: 
        ;
        DeRef(_i_61756);
    }

    /** parser.e:4352		tok = next_token()*/
    _0 = _tok_61273;
    _tok_61273 = _43next_token();
    DeRef(_0);

    /** parser.e:4353		while tok[T_ID] = TYPE or tok[T_ID] = QUALIFIED_TYPE do*/
L34: 
    _2 = (object)SEQ_PTR(_tok_61273);
    _30546 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30546)) {
        _30547 = (_30546 == 504LL);
    }
    else {
        _30547 = binary_op(EQUALS, _30546, 504LL);
    }
    _30546 = NOVALUE;
    if (IS_ATOM_INT(_30547)) {
        if (_30547 != 0) {
            goto L35; // [2092] 2113
        }
    }
    else {
        if (DBL_PTR(_30547)->dbl != 0.0) {
            goto L35; // [2092] 2113
        }
    }
    _2 = (object)SEQ_PTR(_tok_61273);
    _30549 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30549)) {
        _30550 = (_30549 == 522LL);
    }
    else {
        _30550 = binary_op(EQUALS, _30549, 522LL);
    }
    _30549 = NOVALUE;
    if (_30550 <= 0) {
        if (_30550 == 0) {
            DeRef(_30550);
            _30550 = NOVALUE;
            goto L36; // [2109] 2134
        }
        else {
            if (!IS_ATOM_INT(_30550) && DBL_PTR(_30550)->dbl == 0.0){
                DeRef(_30550);
                _30550 = NOVALUE;
                goto L36; // [2109] 2134
            }
            DeRef(_30550);
            _30550 = NOVALUE;
        }
    }
    DeRef(_30550);
    _30550 = NOVALUE;
L35: 

    /** parser.e:4354			Private_declaration(tok[T_SYM])*/
    _2 = (object)SEQ_PTR(_tok_61273);
    _30551 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30551);
    _43Private_declaration(_30551);
    _30551 = NOVALUE;

    /** parser.e:4355			tok = next_token()*/
    _0 = _tok_61273;
    _tok_61273 = _43next_token();
    DeRef(_0);

    /** parser.e:4356		end while*/
    goto L34; // [2131] 2080
L36: 

    /** parser.e:4358		if not TRANSLATE then*/
    if (_12TRANSLATE_19834 != 0)
    goto L37; // [2138] 2241

    /** parser.e:4359			if OpTrace then*/
    if (_12OpTrace_20296 == 0)
    {
        goto L38; // [2145] 2240
    }
    else{
    }

    /** parser.e:4361				emit_op(ERASE_PRIVATE_NAMES)*/
    _45emit_op(88LL);

    /** parser.e:4362				emit_addr(p)*/
    _45emit_addr(_p_61269);

    /** parser.e:4364				sym = SymTab[p][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30554 = (object)*(((s1_ptr)_2)->base + _p_61269);
    _2 = (object)SEQ_PTR(_30554);
    _sym_61271 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_sym_61271)){
        _sym_61271 = (object)DBL_PTR(_sym_61271)->dbl;
    }
    _30554 = NOVALUE;

    /** parser.e:4365				for i = 1 to SymTab[p][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30556 = (object)*(((s1_ptr)_2)->base + _p_61269);
    _2 = (object)SEQ_PTR(_30556);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _30557 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _30557 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _30556 = NOVALUE;
    {
        object _i_61803;
        _i_61803 = 1LL;
L39: 
        if (binary_op_a(GREATER, _i_61803, _30557)){
            goto L3A; // [2190] 2232
        }

        /** parser.e:4366					emit_op(DISPLAY_VAR)*/
        _45emit_op(87LL);

        /** parser.e:4367					emit_addr(sym)*/
        _45emit_addr(_sym_61271);

        /** parser.e:4368					sym = SymTab[sym][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _30558 = (object)*(((s1_ptr)_2)->base + _sym_61271);
        _2 = (object)SEQ_PTR(_30558);
        _sym_61271 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_sym_61271)){
            _sym_61271 = (object)DBL_PTR(_sym_61271)->dbl;
        }
        _30558 = NOVALUE;

        /** parser.e:4369				end for*/
        _0 = _i_61803;
        if (IS_ATOM_INT(_i_61803)) {
            _i_61803 = _i_61803 + 1LL;
            if ((object)((uintptr_t)_i_61803 +(uintptr_t) HIGH_BITS) >= 0){
                _i_61803 = NewDouble((eudouble)_i_61803);
            }
        }
        else {
            _i_61803 = binary_op_a(PLUS, _i_61803, 1LL);
        }
        DeRef(_0);
        goto L39; // [2227] 2197
L3A: 
        ;
        DeRef(_i_61803);
    }

    /** parser.e:4371				emit_op(UPDATE_GLOBALS)*/
    _45emit_op(89LL);
L38: 
L37: 

    /** parser.e:4374		putback(tok)*/
    Ref(_tok_61273);
    _43putback(_tok_61273);

    /** parser.e:4377		FuncReturn = FALSE*/
    _43FuncReturn_55023 = _9FALSE_444;

    /** parser.e:4378		if type_enum then*/
    if (_type_enum_61277 == 0)
    {
        goto L3B; // [2257] 2426
    }
    else{
    }

    /** parser.e:4380			stmt_nest += 1*/
    _43stmt_nest_55047 = _43stmt_nest_55047 + 1;

    /** parser.e:4381			tok_match(RETURN)*/
    _43tok_match(413LL, 0LL);

    /** parser.e:4382			putback({RIGHT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -27LL;
    ((intptr_t *)_2)[2] = 0LL;
    _30561 = MAKE_SEQ(_1);
    _43putback(_30561);
    _30561 = NOVALUE;

    /** parser.e:4383			putback({VARIABLE,seq_sym})*/
    Ref(_seq_sym_61278);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100LL;
    ((intptr_t *)_2)[2] = _seq_sym_61278;
    _30562 = MAKE_SEQ(_1);
    _43putback(_30562);
    _30562 = NOVALUE;

    /** parser.e:4384			putback({COMMA,0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -30LL;
    ((intptr_t *)_2)[2] = 0LL;
    _30563 = MAKE_SEQ(_1);
    _43putback(_30563);
    _30563 = NOVALUE;

    /** parser.e:4385			putback(i1_sym)*/
    Ref(_i1_sym_61279);
    _43putback(_i1_sym_61279);

    /** parser.e:4386			putback({LEFT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -26LL;
    ((intptr_t *)_2)[2] = 0LL;
    _30564 = MAKE_SEQ(_1);
    _43putback(_30564);
    _30564 = NOVALUE;

    /** parser.e:4387			putback(keyfind("find",-1))*/
    RefDS(_30565);
    DeRef(_31764);
    _31764 = _30565;
    _31765 = _53hashfn(_31764);
    _31764 = NOVALUE;
    RefDS(_30565);
    _30566 = _53keyfind(_30565, -1LL, _12current_file_no_20226, 0LL, _31765);
    _31765 = NOVALUE;
    _43putback(_30566);
    _30566 = NOVALUE;

    /** parser.e:4388			if not TRANSLATE then*/
    if (_12TRANSLATE_19834 != 0)
    goto L3C; // [2355] 2381

    /** parser.e:4389				if OpTrace then*/
    if (_12OpTrace_20296 == 0)
    {
        goto L3D; // [2362] 2380
    }
    else{
    }

    /** parser.e:4390					emit_op(ERASE_PRIVATE_NAMES)*/
    _45emit_op(88LL);

    /** parser.e:4391					emit_addr(CurrentSub)*/
    _45emit_addr(_12CurrentSub_20234);
L3D: 
L3C: 

    /** parser.e:4394			Expr()*/
    _43Expr();

    /** parser.e:4395			FuncReturn = TRUE*/
    _43FuncReturn_55023 = _9TRUE_446;

    /** parser.e:4396			emit_op(RETURNF)*/
    _45emit_op(28LL);

    /** parser.e:4397			flush_temps()*/
    RefDS(_22024);
    _45flush_temps(_22024);

    /** parser.e:4398			stmt_nest -= 1*/
    _43stmt_nest_55047 = _43stmt_nest_55047 - 1LL;

    /** parser.e:4399			InitDelete()*/
    _43InitDelete();

    /** parser.e:4400			flush_temps()*/
    RefDS(_22024);
    _45flush_temps(_22024);
    goto L3E; // [2423] 2439
L3B: 

    /** parser.e:4402			Statement_list()*/
    _43Statement_list();

    /** parser.e:4404			tok_match(END)*/
    _43tok_match(402LL, 0LL);
L3E: 

    /** parser.e:4408		tok_match(prog_type, END)*/
    _43tok_match(_prog_type_61263, 402LL);

    /** parser.e:4410		if prog_type != PROCEDURE then*/
    if (_prog_type_61263 == 405LL)
    goto L3F; // [2451] 2503

    /** parser.e:4411			if not FuncReturn then*/
    if (_43FuncReturn_55023 != 0)
    goto L40; // [2459] 2493

    /** parser.e:4412				if prog_type = FUNCTION then*/
    if (_prog_type_61263 != 406LL)
    goto L41; // [2466] 2482

    /** parser.e:4413					CompileErr(NO_VALUE_RETURNED_FROM_FUNCTION)*/
    RefDS(_22024);
    _49CompileErr(120LL, _22024, 0LL);
    goto L42; // [2479] 2492
L41: 

    /** parser.e:4415					CompileErr(TYPE_MUST_RETURN_TRUE__FALSE_VALUE)*/
    RefDS(_22024);
    _49CompileErr(149LL, _22024, 0LL);
L42: 
L40: 

    /** parser.e:4418			emit_op(BADRETURNF) -- function/type shouldn't reach here*/
    _45emit_op(43LL);
    goto L43; // [2500] 2563
L3F: 

    /** parser.e:4421			StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:4422			if not TRANSLATE then*/
    if (_12TRANSLATE_19834 != 0)
    goto L44; // [2516] 2540

    /** parser.e:4423				if OpTrace then*/
    if (_12OpTrace_20296 == 0)
    {
        goto L45; // [2523] 2539
    }
    else{
    }

    /** parser.e:4424					emit_op(ERASE_PRIVATE_NAMES)*/
    _45emit_op(88LL);

    /** parser.e:4425					emit_addr(p)*/
    _45emit_addr(_p_61269);
L45: 
L44: 

    /** parser.e:4428			emit_op(RETURNP)*/
    _45emit_op(29LL);

    /** parser.e:4429			if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L46; // [2551] 2562
    }
    else{
    }

    /** parser.e:4430				emit_op(BADRETURNF) -- just to mark end of procedure*/
    _45emit_op(43LL);
L46: 
L43: 

    /** parser.e:4433		Drop_block( pt )*/
    _64Drop_block(_pt_61267);

    /** parser.e:4435		if Strict_Override > 0 then*/
    if (_12Strict_Override_20293 <= 0LL)
    goto L47; // [2572] 2587

    /** parser.e:4436			Strict_Override -= 1	-- Reset at the end of each routine.*/
    _12Strict_Override_20293 = _12Strict_Override_20293 - 1LL;
L47: 

    /** parser.e:4439		SymTab[p][S_STACK_SPACE] += temps_allocated + param_num*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61269 + ((s1_ptr)_2)->base);
    _30577 = _53temps_allocated_47379 + _43param_num_55024;
    if ((object)((uintptr_t)_30577 + (uintptr_t)HIGH_BITS) >= 0){
        _30577 = NewDouble((eudouble)_30577);
    }
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_12S_STACK_SPACE_19924)){
        _30578 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_STACK_SPACE_19924)->dbl));
    }
    else{
        _30578 = (object)*(((s1_ptr)_2)->base + _12S_STACK_SPACE_19924);
    }
    _30575 = NOVALUE;
    if (IS_ATOM_INT(_30578) && IS_ATOM_INT(_30577)) {
        _30579 = _30578 + _30577;
        if ((object)((uintptr_t)_30579 + (uintptr_t)HIGH_BITS) >= 0){
            _30579 = NewDouble((eudouble)_30579);
        }
    }
    else {
        _30579 = binary_op(PLUS, _30578, _30577);
    }
    _30578 = NOVALUE;
    DeRef(_30577);
    _30577 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_STACK_SPACE_19924))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_STACK_SPACE_19924)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_STACK_SPACE_19924);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30579;
    if( _1 != _30579 ){
        DeRef(_1);
    }
    _30579 = NOVALUE;
    _30575 = NOVALUE;

    /** parser.e:4440		if temps_allocated + param_num > max_stack_per_call then*/
    _30580 = _53temps_allocated_47379 + _43param_num_55024;
    if ((object)((uintptr_t)_30580 + (uintptr_t)HIGH_BITS) >= 0){
        _30580 = NewDouble((eudouble)_30580);
    }
    if (binary_op_a(LESSEQ, _30580, _12max_stack_per_call_20326)){
        DeRef(_30580);
        _30580 = NOVALUE;
        goto L48; // [2630] 2647
    }
    DeRef(_30580);
    _30580 = NOVALUE;

    /** parser.e:4441			max_stack_per_call = temps_allocated + param_num*/
    _12max_stack_per_call_20326 = _53temps_allocated_47379 + _43param_num_55024;
L48: 

    /** parser.e:4443		param_num = -1*/
    _43param_num_55024 = -1LL;

    /** parser.e:4445		StraightenBranches()*/
    _43StraightenBranches();

    /** parser.e:4446		check_inline( p )*/
    _66check_inline(_p_61269);

    /** parser.e:4447		param_num = -1*/
    _43param_num_55024 = -1LL;

    /** parser.e:4448		EnterTopLevel()*/
    _43EnterTopLevel(1LL);

    /** parser.e:4451		if length( enum_syms ) then*/
    if (IS_SEQUENCE(_enum_syms_61280)){
            _30583 = SEQ_PTR(_enum_syms_61280)->length;
    }
    else {
        _30583 = 1;
    }
    if (_30583 == 0)
    {
        _30583 = NOVALUE;
        goto L49; // [2676] 2763
    }
    else{
        _30583 = NOVALUE;
    }

    /** parser.e:4452			SymTab[p][S_NEXT] = SymTab[enum_syms[$]][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61269 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_enum_syms_61280)){
            _30586 = SEQ_PTR(_enum_syms_61280)->length;
    }
    else {
        _30586 = 1;
    }
    _2 = (object)SEQ_PTR(_enum_syms_61280);
    _30587 = (object)*(((s1_ptr)_2)->base + _30586);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_30587)){
        _30588 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30587)->dbl));
    }
    else{
        _30588 = (object)*(((s1_ptr)_2)->base + _30587);
    }
    _2 = (object)SEQ_PTR(_30588);
    _30589 = (object)*(((s1_ptr)_2)->base + 2LL);
    _30588 = NOVALUE;
    Ref(_30589);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30589;
    if( _1 != _30589 ){
        DeRef(_1);
    }
    _30589 = NOVALUE;
    _30584 = NOVALUE;

    /** parser.e:4453			SymTab[last_sym][S_NEXT] = enum_syms[1]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_53last_sym_46855 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_enum_syms_61280);
    _30592 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_30592);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30592;
    if( _1 != _30592 ){
        DeRef(_1);
    }
    _30592 = NOVALUE;
    _30590 = NOVALUE;

    /** parser.e:4454			last_sym = enum_syms[$]*/
    if (IS_SEQUENCE(_enum_syms_61280)){
            _30593 = SEQ_PTR(_enum_syms_61280)->length;
    }
    else {
        _30593 = 1;
    }
    _2 = (object)SEQ_PTR(_enum_syms_61280);
    _53last_sym_46855 = (object)*(((s1_ptr)_2)->base + _30593);
    if (!IS_ATOM_INT(_53last_sym_46855)){
        _53last_sym_46855 = (object)DBL_PTR(_53last_sym_46855)->dbl;
    }

    /** parser.e:4455			SymTab[last_sym][S_NEXT] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_53last_sym_46855 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30595 = NOVALUE;
L49: 

    /** parser.e:4457	end procedure*/
    DeRef(_tok_61273);
    DeRef(_prog_name_61274);
    DeRef(_seq_sym_61278);
    DeRef(_i1_sym_61279);
    DeRef(_enum_syms_61280);
    DeRef(_middle_def_args_61512);
    DeRef(_30465);
    _30465 = NOVALUE;
    _30471 = NOVALUE;
    DeRef(_30443);
    _30443 = NOVALUE;
    DeRef(_30531);
    _30531 = NOVALUE;
    _30449 = NOVALUE;
    _30486 = NOVALUE;
    _30587 = NOVALUE;
    DeRef(_30483);
    _30483 = NOVALUE;
    _30557 = NOVALUE;
    DeRef(_30375);
    _30375 = NOVALUE;
    _30399 = NOVALUE;
    DeRef(_30547);
    _30547 = NOVALUE;
    DeRef(_30432);
    _30432 = NOVALUE;
    _30537 = NOVALUE;
    _30491 = NOVALUE;
    _30403 = NOVALUE;
    DeRef(_30437);
    _30437 = NOVALUE;
    _30467 = NOVALUE;
    _30468 = NOVALUE;
    return;
    ;
}


void _43InitGlobals()
{
    object _30614 = NOVALUE;
    object _30612 = NOVALUE;
    object _30611 = NOVALUE;
    object _30610 = NOVALUE;
    object _30609 = NOVALUE;
    object _30608 = NOVALUE;
    object _30607 = NOVALUE;
    object _30605 = NOVALUE;
    object _30604 = NOVALUE;
    object _30603 = NOVALUE;
    object _30602 = NOVALUE;
    object _30600 = NOVALUE;
    object _30599 = NOVALUE;
    object _30598 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:4461		ResetTP()*/
    _61ResetTP();

    /** parser.e:4462		OpTypeCheck = TRUE*/
    _12OpTypeCheck_20297 = _9TRUE_446;

    /** parser.e:4464		OpDefines &= {*/
    _30598 = _40version_major();
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30598;
    _30599 = MAKE_SEQ(_1);
    _30598 = NOVALUE;
    _30600 = EPrintf(-9999999, _30597, _30599);
    DeRefDS(_30599);
    _30599 = NOVALUE;
    _30602 = _40version_major();
    _30603 = _40version_minor();
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _30602;
    ((intptr_t *)_2)[2] = _30603;
    _30604 = MAKE_SEQ(_1);
    _30603 = NOVALUE;
    _30602 = NOVALUE;
    _30605 = EPrintf(-9999999, _30601, _30604);
    DeRefDS(_30604);
    _30604 = NOVALUE;
    _30607 = _40version_major();
    _30608 = _40version_minor();
    _30609 = _40version_patch();
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30607;
    ((intptr_t*)_2)[2] = _30608;
    ((intptr_t*)_2)[3] = _30609;
    _30610 = MAKE_SEQ(_1);
    _30609 = NOVALUE;
    _30608 = NOVALUE;
    _30607 = NOVALUE;
    _30611 = EPrintf(-9999999, _30606, _30610);
    DeRefDS(_30610);
    _30610 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30600;
    ((intptr_t*)_2)[2] = _30605;
    ((intptr_t*)_2)[3] = _30611;
    _30612 = MAKE_SEQ(_1);
    _30611 = NOVALUE;
    _30605 = NOVALUE;
    _30600 = NOVALUE;
    Concat((object_ptr)&_12OpDefines_20300, _12OpDefines_20300, _30612);
    DeRefDS(_30612);
    _30612 = NOVALUE;

    /** parser.e:4470		OpDefines &= GetPlatformDefines()*/
    _30614 = _44GetPlatformDefines(0LL);
    if (IS_SEQUENCE(_12OpDefines_20300) && IS_ATOM(_30614)) {
        Ref(_30614);
        Append(&_12OpDefines_20300, _12OpDefines_20300, _30614);
    }
    else if (IS_ATOM(_12OpDefines_20300) && IS_SEQUENCE(_30614)) {
    }
    else {
        Concat((object_ptr)&_12OpDefines_20300, _12OpDefines_20300, _30614);
    }
    DeRef(_30614);
    _30614 = NOVALUE;

    /** parser.e:4472		if repl then*/

    /** parser.e:4476			OpInline = DEFAULT_INLINE*/
    _12OpInline_20301 = 30LL;

    /** parser.e:4478		OpIndirectInclude = 1*/
    _12OpIndirectInclude_20302 = 1LL;

    /** parser.e:4479	end procedure*/
    return;
    ;
}


void _43not_supported_compile(object _feature_61973)
{
    object _30616 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:4483		CompileErr(MSG_1_IS_NOT_SUPPORTED_IN_EUPHORIA_FOR_2, {feature, version_name})*/
    RefDS(_12version_name_19848);
    RefDS(_feature_61973);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _feature_61973;
    ((intptr_t *)_2)[2] = _12version_name_19848;
    _30616 = MAKE_SEQ(_1);
    _49CompileErr(5LL, _30616, 0LL);
    _30616 = NOVALUE;

    /** parser.e:4484	end procedure*/
    DeRefDSi(_feature_61973);
    return;
    ;
}


void _43SetWith(object _on_off_61980)
{
    object _option_61981 = NOVALUE;
    object _idx_61982 = NOVALUE;
    object _reset_flags_61983 = NOVALUE;
    object _tok_62035 = NOVALUE;
    object _good_sofar_62085 = NOVALUE;
    object _tok_62088 = NOVALUE;
    object _warning_extra_62090 = NOVALUE;
    object _endlist_62183 = NOVALUE;
    object _tok_62332 = NOVALUE;
    object _30763 = NOVALUE;
    object _30762 = NOVALUE;
    object _30761 = NOVALUE;
    object _30760 = NOVALUE;
    object _30759 = NOVALUE;
    object _30756 = NOVALUE;
    object _30755 = NOVALUE;
    object _30754 = NOVALUE;
    object _30752 = NOVALUE;
    object _30750 = NOVALUE;
    object _30749 = NOVALUE;
    object _30748 = NOVALUE;
    object _30745 = NOVALUE;
    object _30743 = NOVALUE;
    object _30742 = NOVALUE;
    object _30741 = NOVALUE;
    object _30740 = NOVALUE;
    object _30739 = NOVALUE;
    object _30735 = NOVALUE;
    object _30733 = NOVALUE;
    object _30731 = NOVALUE;
    object _30727 = NOVALUE;
    object _30722 = NOVALUE;
    object _30721 = NOVALUE;
    object _30716 = NOVALUE;
    object _30715 = NOVALUE;
    object _30714 = NOVALUE;
    object _30713 = NOVALUE;
    object _30712 = NOVALUE;
    object _30711 = NOVALUE;
    object _30710 = NOVALUE;
    object _30709 = NOVALUE;
    object _30708 = NOVALUE;
    object _30707 = NOVALUE;
    object _30705 = NOVALUE;
    object _30704 = NOVALUE;
    object _30702 = NOVALUE;
    object _30701 = NOVALUE;
    object _30700 = NOVALUE;
    object _30698 = NOVALUE;
    object _30697 = NOVALUE;
    object _30695 = NOVALUE;
    object _30692 = NOVALUE;
    object _30690 = NOVALUE;
    object _30687 = NOVALUE;
    object _30686 = NOVALUE;
    object _30685 = NOVALUE;
    object _30684 = NOVALUE;
    object _30677 = NOVALUE;
    object _30676 = NOVALUE;
    object _30674 = NOVALUE;
    object _30671 = NOVALUE;
    object _30670 = NOVALUE;
    object _30668 = NOVALUE;
    object _30667 = NOVALUE;
    object _30666 = NOVALUE;
    object _30665 = NOVALUE;
    object _30664 = NOVALUE;
    object _30663 = NOVALUE;
    object _30660 = NOVALUE;
    object _30659 = NOVALUE;
    object _30658 = NOVALUE;
    object _30657 = NOVALUE;
    object _30656 = NOVALUE;
    object _30655 = NOVALUE;
    object _30652 = NOVALUE;
    object _30651 = NOVALUE;
    object _30650 = NOVALUE;
    object _30648 = NOVALUE;
    object _30645 = NOVALUE;
    object _30643 = NOVALUE;
    object _30642 = NOVALUE;
    object _30640 = NOVALUE;
    object _30639 = NOVALUE;
    object _30638 = NOVALUE;
    object _30637 = NOVALUE;
    object _30636 = NOVALUE;
    object _30635 = NOVALUE;
    object _30633 = NOVALUE;
    object _30630 = NOVALUE;
    object _30629 = NOVALUE;
    object _30628 = NOVALUE;
    object _30627 = NOVALUE;
    object _30625 = NOVALUE;
    object _30624 = NOVALUE;
    object _30623 = NOVALUE;
    object _30622 = NOVALUE;
    object _30620 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:4490		integer reset_flags = 1*/
    _reset_flags_61983 = 1LL;

    /** parser.e:4493		option = StringToken("&+=")*/
    RefDS(_30617);
    _0 = _option_61981;
    _option_61981 = _61StringToken(_30617);
    DeRef(_0);

    /** parser.e:4495		if equal(option, "type_check") then*/
    if (_option_61981 == _30619)
    _30620 = 1;
    else if (IS_ATOM_INT(_option_61981) && IS_ATOM_INT(_30619))
    _30620 = 0;
    else
    _30620 = (compare(_option_61981, _30619) == 0);
    if (_30620 == 0)
    {
        _30620 = NOVALUE;
        goto L1; // [22] 35
    }
    else{
        _30620 = NOVALUE;
    }

    /** parser.e:4496			OpTypeCheck = on_off*/
    _12OpTypeCheck_20297 = _on_off_61980;
    goto L2; // [32] 1546
L1: 

    /** parser.e:4498		elsif equal(option, "profile") then*/
    if (_option_61981 == _30621)
    _30622 = 1;
    else if (IS_ATOM_INT(_option_61981) && IS_ATOM_INT(_30621))
    _30622 = 0;
    else
    _30622 = (compare(_option_61981, _30621) == 0);
    if (_30622 == 0)
    {
        _30622 = NOVALUE;
        goto L3; // [41] 121
    }
    else{
        _30622 = NOVALUE;
    }

    /** parser.e:4499			if not TRANSLATE and not BIND then*/
    _30623 = (_12TRANSLATE_19834 == 0);
    if (_30623 == 0) {
        goto L2; // [51] 1546
    }
    _30625 = (_12BIND_19837 == 0);
    if (_30625 == 0)
    {
        DeRef(_30625);
        _30625 = NOVALUE;
        goto L2; // [61] 1546
    }
    else{
        DeRef(_30625);
        _30625 = NOVALUE;
    }

    /** parser.e:4500				OpProfileStatement = on_off*/
    _12OpProfileStatement_20298 = _on_off_61980;

    /** parser.e:4501				if OpProfileStatement then*/
    if (_12OpProfileStatement_20298 == 0)
    {
        goto L2; // [75] 1546
    }
    else{
    }

    /** parser.e:4502					if AnyTimeProfile then*/
    if (_13AnyTimeProfile_11339 == 0)
    {
        goto L4; // [82] 106
    }
    else{
    }

    /** parser.e:4503						Warning(224, mixed_profile_warning_flag)*/
    RefDS(_22024);
    _49Warning(224LL, 1024LL, _22024);

    /** parser.e:4504						OpProfileStatement = FALSE*/
    _12OpProfileStatement_20298 = _9FALSE_444;
    goto L2; // [103] 1546
L4: 

    /** parser.e:4506						AnyStatementProfile = TRUE*/
    _13AnyStatementProfile_11340 = _9TRUE_446;
    goto L2; // [118] 1546
L3: 

    /** parser.e:4511		elsif equal(option, "profile_time") then*/
    if (_option_61981 == _30626)
    _30627 = 1;
    else if (IS_ATOM_INT(_option_61981) && IS_ATOM_INT(_30626))
    _30627 = 0;
    else
    _30627 = (compare(_option_61981, _30626) == 0);
    if (_30627 == 0)
    {
        _30627 = NOVALUE;
        goto L5; // [127] 364
    }
    else{
        _30627 = NOVALUE;
    }

    /** parser.e:4512			if not TRANSLATE and not BIND then*/
    _30628 = (_12TRANSLATE_19834 == 0);
    if (_30628 == 0) {
        goto L2; // [137] 1546
    }
    _30630 = (_12BIND_19837 == 0);
    if (_30630 == 0)
    {
        DeRef(_30630);
        _30630 = NOVALUE;
        goto L2; // [147] 1546
    }
    else{
        DeRef(_30630);
        _30630 = NOVALUE;
    }

    /** parser.e:4513				if not IWINDOWS then*/

    /** parser.e:4514					if on_off then*/
    if (_on_off_61980 == 0)
    {
        goto L6; // [159] 168
    }
    else{
    }

    /** parser.e:4515						not_supported_compile("profile_time")*/
    RefDS(_30626);
    _43not_supported_compile(_30626);
L6: 

    /** parser.e:4518				OpProfileTime = on_off*/
    _12OpProfileTime_20299 = _on_off_61980;

    /** parser.e:4519				if OpProfileTime then*/
    if (_12OpProfileTime_20299 == 0)
    {
        goto L7; // [180] 358
    }
    else{
    }

    /** parser.e:4520					if AnyStatementProfile then*/
    if (_13AnyStatementProfile_11340 == 0)
    {
        goto L8; // [187] 209
    }
    else{
    }

    /** parser.e:4521						Warning(224,mixed_profile_warning_flag)*/
    RefDS(_22024);
    _49Warning(224LL, 1024LL, _22024);

    /** parser.e:4522						OpProfileTime = FALSE*/
    _12OpProfileTime_20299 = _9FALSE_444;
L8: 

    /** parser.e:4524					token tok = next_token()*/
    _0 = _tok_62035;
    _tok_62035 = _43next_token();
    DeRef(_0);

    /** parser.e:4525					if tok[T_ID] = ATOM then*/
    _2 = (object)SEQ_PTR(_tok_62035);
    _30633 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30633, 502LL)){
        _30633 = NOVALUE;
        goto L9; // [224] 319
    }
    _30633 = NOVALUE;

    /** parser.e:4526						if is_integer(SymTab[tok[T_SYM]][S_OBJ]) then*/
    _2 = (object)SEQ_PTR(_tok_62035);
    _30635 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_30635)){
        _30636 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30635)->dbl));
    }
    else{
        _30636 = (object)*(((s1_ptr)_2)->base + _30635);
    }
    _2 = (object)SEQ_PTR(_30636);
    _30637 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30636 = NOVALUE;
    Ref(_30637);
    _30638 = _12is_integer(_30637);
    _30637 = NOVALUE;
    if (_30638 == 0) {
        DeRef(_30638);
        _30638 = NOVALUE;
        goto LA; // [252] 280
    }
    else {
        if (!IS_ATOM_INT(_30638) && DBL_PTR(_30638)->dbl == 0.0){
            DeRef(_30638);
            _30638 = NOVALUE;
            goto LA; // [252] 280
        }
        DeRef(_30638);
        _30638 = NOVALUE;
    }
    DeRef(_30638);
    _30638 = NOVALUE;

    /** parser.e:4527							sample_size = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_tok_62035);
    _30639 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_30639)){
        _30640 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30639)->dbl));
    }
    else{
        _30640 = (object)*(((s1_ptr)_2)->base + _30639);
    }
    _2 = (object)SEQ_PTR(_30640);
    _12sample_size_20327 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_12sample_size_20327)){
        _12sample_size_20327 = (object)DBL_PTR(_12sample_size_20327)->dbl;
    }
    _30640 = NOVALUE;
    goto LB; // [277] 288
LA: 

    /** parser.e:4529							sample_size = -1*/
    _12sample_size_20327 = -1LL;
LB: 

    /** parser.e:4531						if sample_size < 1 and OpProfileTime then*/
    _30642 = (_12sample_size_20327 < 1LL);
    if (_30642 == 0) {
        goto LC; // [296] 332
    }
    if (_12OpProfileTime_20299 == 0)
    {
        goto LC; // [303] 332
    }
    else{
    }

    /** parser.e:4532							CompileErr(SAMPLE_SIZE_MUST_BE_A_POSITIVE_INTEGER)*/
    RefDS(_22024);
    _49CompileErr(136LL, _22024, 0LL);
    goto LC; // [316] 332
L9: 

    /** parser.e:4535						putback(tok)*/
    Ref(_tok_62035);
    _43putback(_tok_62035);

    /** parser.e:4536						sample_size = DEFAULT_SAMPLE_SIZE*/
    _12sample_size_20327 = 25000LL;
LC: 

    /** parser.e:4538					if OpProfileTime then*/
    if (_12OpProfileTime_20299 == 0)
    {
        goto LD; // [336] 357
    }
    else{
    }

    /** parser.e:4539						if IWINDOWS then*/
LD: 
L7: 
    DeRef(_tok_62035);
    _tok_62035 = NOVALUE;
    goto L2; // [361] 1546
L5: 

    /** parser.e:4546		elsif equal(option, "trace") then*/
    if (_option_61981 == _30644)
    _30645 = 1;
    else if (IS_ATOM_INT(_option_61981) && IS_ATOM_INT(_30644))
    _30645 = 0;
    else
    _30645 = (compare(_option_61981, _30644) == 0);
    if (_30645 == 0)
    {
        _30645 = NOVALUE;
        goto LE; // [370] 391
    }
    else{
        _30645 = NOVALUE;
    }

    /** parser.e:4547			if not BIND then*/
    if (_12BIND_19837 != 0)
    goto L2; // [377] 1546

    /** parser.e:4548				OpTrace = on_off*/
    _12OpTrace_20296 = _on_off_61980;
    goto L2; // [388] 1546
LE: 

    /** parser.e:4551		elsif equal(option, "warning") then*/
    if (_option_61981 == _30647)
    _30648 = 1;
    else if (IS_ATOM_INT(_option_61981) && IS_ATOM_INT(_30647))
    _30648 = 0;
    else
    _30648 = (compare(_option_61981, _30647) == 0);
    if (_30648 == 0)
    {
        _30648 = NOVALUE;
        goto LF; // [397] 1243
    }
    else{
        _30648 = NOVALUE;
    }

    /** parser.e:4552			integer good_sofar = line_number*/
    _good_sofar_62085 = _12line_number_20227;

    /** parser.e:4553			reset_flags = 1*/
    _reset_flags_61983 = 1LL;

    /** parser.e:4554			token tok = next_token()*/
    _0 = _tok_62088;
    _tok_62088 = _43next_token();
    DeRef(_0);

    /** parser.e:4555			integer warning_extra = 1*/
    _warning_extra_62090 = 1LL;

    /** parser.e:4556			if find(tok[T_ID], {CONCAT_EQUALS, PLUS_EQUALS}) != 0 then*/
    _2 = (object)SEQ_PTR(_tok_62088);
    _30650 = (object)*(((s1_ptr)_2)->base + 1LL);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 519LL;
    ((intptr_t *)_2)[2] = 515LL;
    _30651 = MAKE_SEQ(_1);
    _30652 = find_from(_30650, _30651, 1LL);
    _30650 = NOVALUE;
    DeRefDS(_30651);
    _30651 = NOVALUE;
    if (_30652 == 0LL)
    goto L10; // [445] 506

    /** parser.e:4557				tok = next_token()*/
    _0 = _tok_62088;
    _tok_62088 = _43next_token();
    DeRef(_0);

    /** parser.e:4558				if tok[T_ID] != LEFT_BRACE and tok[T_ID] != LEFT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok_62088);
    _30655 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30655)) {
        _30656 = (_30655 != -24LL);
    }
    else {
        _30656 = binary_op(NOTEQ, _30655, -24LL);
    }
    _30655 = NOVALUE;
    if (IS_ATOM_INT(_30656)) {
        if (_30656 == 0) {
            goto L11; // [468] 498
        }
    }
    else {
        if (DBL_PTR(_30656)->dbl == 0.0) {
            goto L11; // [468] 498
        }
    }
    _2 = (object)SEQ_PTR(_tok_62088);
    _30658 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30658)) {
        _30659 = (_30658 != -26LL);
    }
    else {
        _30659 = binary_op(NOTEQ, _30658, -26LL);
    }
    _30658 = NOVALUE;
    if (_30659 == 0) {
        DeRef(_30659);
        _30659 = NOVALUE;
        goto L11; // [485] 498
    }
    else {
        if (!IS_ATOM_INT(_30659) && DBL_PTR(_30659)->dbl == 0.0){
            DeRef(_30659);
            _30659 = NOVALUE;
            goto L11; // [485] 498
        }
        DeRef(_30659);
        _30659 = NOVALUE;
    }
    DeRef(_30659);
    _30659 = NOVALUE;

    /** parser.e:4559					CompileErr(WARNING_NAMES_MUST_BE_ENCLOSED_IN)*/
    RefDS(_22024);
    _49CompileErr(160LL, _22024, 0LL);
L11: 

    /** parser.e:4561				reset_flags = 0*/
    _reset_flags_61983 = 0LL;
    goto L12; // [503] 734
L10: 

    /** parser.e:4562			elsif tok[T_ID] = EQUALS then*/
    _2 = (object)SEQ_PTR(_tok_62088);
    _30660 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30660, 3LL)){
        _30660 = NOVALUE;
        goto L13; // [516] 577
    }
    _30660 = NOVALUE;

    /** parser.e:4563				tok = next_token()*/
    _0 = _tok_62088;
    _tok_62088 = _43next_token();
    DeRef(_0);

    /** parser.e:4564				if tok[T_ID] != LEFT_BRACE and tok[T_ID] != LEFT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok_62088);
    _30663 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30663)) {
        _30664 = (_30663 != -24LL);
    }
    else {
        _30664 = binary_op(NOTEQ, _30663, -24LL);
    }
    _30663 = NOVALUE;
    if (IS_ATOM_INT(_30664)) {
        if (_30664 == 0) {
            goto L14; // [539] 569
        }
    }
    else {
        if (DBL_PTR(_30664)->dbl == 0.0) {
            goto L14; // [539] 569
        }
    }
    _2 = (object)SEQ_PTR(_tok_62088);
    _30666 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30666)) {
        _30667 = (_30666 != -26LL);
    }
    else {
        _30667 = binary_op(NOTEQ, _30666, -26LL);
    }
    _30666 = NOVALUE;
    if (_30667 == 0) {
        DeRef(_30667);
        _30667 = NOVALUE;
        goto L14; // [556] 569
    }
    else {
        if (!IS_ATOM_INT(_30667) && DBL_PTR(_30667)->dbl == 0.0){
            DeRef(_30667);
            _30667 = NOVALUE;
            goto L14; // [556] 569
        }
        DeRef(_30667);
        _30667 = NOVALUE;
    }
    DeRef(_30667);
    _30667 = NOVALUE;

    /** parser.e:4565					CompileErr(WARNING_NAMES_MUST_BE_ENCLOSED_IN)*/
    RefDS(_22024);
    _49CompileErr(160LL, _22024, 0LL);
L14: 

    /** parser.e:4567				reset_flags = 1*/
    _reset_flags_61983 = 1LL;
    goto L12; // [574] 734
L13: 

    /** parser.e:4568			elsif tok[T_ID] = VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_62088);
    _30668 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30668, -100LL)){
        _30668 = NOVALUE;
        goto L15; // [587] 733
    }
    _30668 = NOVALUE;

    /** parser.e:4569				option = SymTab[tok[T_SYM]][S_NAME]*/
    _2 = (object)SEQ_PTR(_tok_62088);
    _30670 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_30670)){
        _30671 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30670)->dbl));
    }
    else{
        _30671 = (object)*(((s1_ptr)_2)->base + _30670);
    }
    DeRef(_option_61981);
    _2 = (object)SEQ_PTR(_30671);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _option_61981 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _option_61981 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    Ref(_option_61981);
    _30671 = NOVALUE;

    /** parser.e:4570				if equal(option, "save") then*/
    if (_option_61981 == _30673)
    _30674 = 1;
    else if (IS_ATOM_INT(_option_61981) && IS_ATOM_INT(_30673))
    _30674 = 0;
    else
    _30674 = (compare(_option_61981, _30673) == 0);
    if (_30674 == 0)
    {
        _30674 = NOVALUE;
        goto L16; // [619] 643
    }
    else{
        _30674 = NOVALUE;
    }

    /** parser.e:4571					prev_OpWarning = OpWarning*/
    _12prev_OpWarning_20295 = _12OpWarning_20294;

    /** parser.e:4572					warning_extra = FALSE*/
    _warning_extra_62090 = _9FALSE_444;
    goto L17; // [640] 732
L16: 

    /** parser.e:4574				elsif equal(option, "restore") then*/
    if (_option_61981 == _30675)
    _30676 = 1;
    else if (IS_ATOM_INT(_option_61981) && IS_ATOM_INT(_30675))
    _30676 = 0;
    else
    _30676 = (compare(_option_61981, _30675) == 0);
    if (_30676 == 0)
    {
        _30676 = NOVALUE;
        goto L18; // [649] 673
    }
    else{
        _30676 = NOVALUE;
    }

    /** parser.e:4575					OpWarning = prev_OpWarning*/
    _12OpWarning_20294 = _12prev_OpWarning_20295;

    /** parser.e:4576					warning_extra = FALSE*/
    _warning_extra_62090 = _9FALSE_444;
    goto L17; // [670] 732
L18: 

    /** parser.e:4578				elsif equal(option, "strict") then*/
    if (_option_61981 == _25543)
    _30677 = 1;
    else if (IS_ATOM_INT(_option_61981) && IS_ATOM_INT(_25543))
    _30677 = 0;
    else
    _30677 = (compare(_option_61981, _25543) == 0);
    if (_30677 == 0)
    {
        _30677 = NOVALUE;
        goto L19; // [679] 731
    }
    else{
        _30677 = NOVALUE;
    }

    /** parser.e:4579					if on_off = 0 then*/
    if (_on_off_61980 != 0LL)
    goto L1A; // [684] 701

    /** parser.e:4580						Strict_Override += 1*/
    _12Strict_Override_20293 = _12Strict_Override_20293 + 1LL;
    goto L1B; // [698] 721
L1A: 

    /** parser.e:4581					elsif Strict_Override > 0 then*/
    if (_12Strict_Override_20293 <= 0LL)
    goto L1C; // [705] 720

    /** parser.e:4582						Strict_Override -= 1*/
    _12Strict_Override_20293 = _12Strict_Override_20293 - 1LL;
L1C: 
L1B: 

    /** parser.e:4584					warning_extra = FALSE*/
    _warning_extra_62090 = _9FALSE_444;
L19: 
L17: 
L15: 
L12: 

    /** parser.e:4588			if warning_extra = TRUE then*/
    if (_warning_extra_62090 != _9TRUE_446)
    goto L1D; // [738] 1238

    /** parser.e:4589				if reset_flags then*/
    if (_reset_flags_61983 == 0)
    {
        goto L1E; // [744] 776
    }
    else{
    }

    /** parser.e:4590					if on_off = 0 then*/
    if (_on_off_61980 != 0LL)
    goto L1F; // [749] 765

    /** parser.e:4591						OpWarning = no_warning_flag*/
    _12OpWarning_20294 = 0LL;
    goto L20; // [762] 775
L1F: 

    /** parser.e:4593						OpWarning = all_warning_flag*/
    _12OpWarning_20294 = 32767LL;
L20: 
L1E: 

    /** parser.e:4597				if find(tok[T_ID], {LEFT_BRACE, LEFT_ROUND}) then*/
    _2 = (object)SEQ_PTR(_tok_62088);
    _30684 = (object)*(((s1_ptr)_2)->base + 1LL);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -24LL;
    ((intptr_t *)_2)[2] = -26LL;
    _30685 = MAKE_SEQ(_1);
    _30686 = find_from(_30684, _30685, 1LL);
    _30684 = NOVALUE;
    DeRefDS(_30685);
    _30685 = NOVALUE;
    if (_30686 == 0)
    {
        _30686 = NOVALUE;
        goto L21; // [797] 1231
    }
    else{
        _30686 = NOVALUE;
    }

    /** parser.e:4598					integer endlist*/

    /** parser.e:4599					if tok[T_ID] = LEFT_BRACE then*/
    _2 = (object)SEQ_PTR(_tok_62088);
    _30687 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30687, -24LL)){
        _30687 = NOVALUE;
        goto L22; // [812] 828
    }
    _30687 = NOVALUE;

    /** parser.e:4600						endlist = RIGHT_BRACE*/
    _endlist_62183 = -25LL;
    goto L23; // [825] 838
L22: 

    /** parser.e:4602						endlist = RIGHT_ROUND*/
    _endlist_62183 = -27LL;
L23: 

    /** parser.e:4604					tok = next_token()*/
    _0 = _tok_62088;
    _tok_62088 = _43next_token();
    DeRef(_0);

    /** parser.e:4605					while tok[T_ID] != endlist do*/
L24: 
    _2 = (object)SEQ_PTR(_tok_62088);
    _30690 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _30690, _endlist_62183)){
        _30690 = NOVALUE;
        goto L25; // [856] 1226
    }
    _30690 = NOVALUE;

    /** parser.e:4606						if tok[T_ID] = COMMA then*/
    _2 = (object)SEQ_PTR(_tok_62088);
    _30692 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30692, -30LL)){
        _30692 = NOVALUE;
        goto L26; // [870] 884
    }
    _30692 = NOVALUE;

    /** parser.e:4607							tok = next_token()*/
    _0 = _tok_62088;
    _tok_62088 = _43next_token();
    DeRef(_0);

    /** parser.e:4608							continue*/
    goto L24; // [881] 848
L26: 

    /** parser.e:4611						if tok[T_ID] = STRING then*/
    _2 = (object)SEQ_PTR(_tok_62088);
    _30695 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30695, 503LL)){
        _30695 = NOVALUE;
        goto L27; // [894] 923
    }
    _30695 = NOVALUE;

    /** parser.e:4612							option = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_tok_62088);
    _30697 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_30697)){
        _30698 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30697)->dbl));
    }
    else{
        _30698 = (object)*(((s1_ptr)_2)->base + _30697);
    }
    DeRef(_option_61981);
    _2 = (object)SEQ_PTR(_30698);
    _option_61981 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_option_61981);
    _30698 = NOVALUE;
    goto L28; // [920] 1071
L27: 

    /** parser.e:4613						elsif length(SymTab[tok[T_SYM]]) >= S_NAME then*/
    _2 = (object)SEQ_PTR(_tok_62088);
    _30700 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_30700)){
        _30701 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30700)->dbl));
    }
    else{
        _30701 = (object)*(((s1_ptr)_2)->base + _30700);
    }
    if (IS_SEQUENCE(_30701)){
            _30702 = SEQ_PTR(_30701)->length;
    }
    else {
        _30702 = 1;
    }
    _30701 = NOVALUE;
    if (binary_op_a(LESS, _30702, _12S_NAME_19864)){
        _30702 = NOVALUE;
        goto L29; // [942] 971
    }
    _30702 = NOVALUE;

    /** parser.e:4614							option = SymTab[tok[T_SYM]][S_NAME]*/
    _2 = (object)SEQ_PTR(_tok_62088);
    _30704 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_30704)){
        _30705 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30704)->dbl));
    }
    else{
        _30705 = (object)*(((s1_ptr)_2)->base + _30704);
    }
    DeRef(_option_61981);
    _2 = (object)SEQ_PTR(_30705);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _option_61981 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _option_61981 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    Ref(_option_61981);
    _30705 = NOVALUE;
    goto L28; // [968] 1071
L29: 

    /** parser.e:4616							option = ""*/
    RefDS(_22024);
    DeRef(_option_61981);
    _option_61981 = _22024;

    /** parser.e:4617							for k = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_62keylist_23148)){
            _30707 = SEQ_PTR(_62keylist_23148)->length;
    }
    else {
        _30707 = 1;
    }
    {
        object _k_62230;
        _k_62230 = 1LL;
L2A: 
        if (_k_62230 > _30707){
            goto L2B; // [985] 1070
        }

        /** parser.e:4618								if keylist[k][S_SCOPE] = SC_KEYWORD and*/
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _30708 = (object)*(((s1_ptr)_2)->base + _k_62230);
        _2 = (object)SEQ_PTR(_30708);
        _30709 = (object)*(((s1_ptr)_2)->base + 4LL);
        _30708 = NOVALUE;
        if (IS_ATOM_INT(_30709)) {
            _30710 = (_30709 == 8LL);
        }
        else {
            _30710 = binary_op(EQUALS, _30709, 8LL);
        }
        _30709 = NOVALUE;
        if (IS_ATOM_INT(_30710)) {
            if (_30710 == 0) {
                goto L2C; // [1012] 1063
            }
        }
        else {
            if (DBL_PTR(_30710)->dbl == 0.0) {
                goto L2C; // [1012] 1063
            }
        }
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _30712 = (object)*(((s1_ptr)_2)->base + _k_62230);
        _2 = (object)SEQ_PTR(_30712);
        if (!IS_ATOM_INT(_12S_TOKEN_19869)){
            _30713 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
        }
        else{
            _30713 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
        }
        _30712 = NOVALUE;
        _2 = (object)SEQ_PTR(_tok_62088);
        _30714 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_30713) && IS_ATOM_INT(_30714)) {
            _30715 = (_30713 == _30714);
        }
        else {
            _30715 = binary_op(EQUALS, _30713, _30714);
        }
        _30713 = NOVALUE;
        _30714 = NOVALUE;
        if (_30715 == 0) {
            DeRef(_30715);
            _30715 = NOVALUE;
            goto L2C; // [1039] 1063
        }
        else {
            if (!IS_ATOM_INT(_30715) && DBL_PTR(_30715)->dbl == 0.0){
                DeRef(_30715);
                _30715 = NOVALUE;
                goto L2C; // [1039] 1063
            }
            DeRef(_30715);
            _30715 = NOVALUE;
        }
        DeRef(_30715);
        _30715 = NOVALUE;

        /** parser.e:4621										option = keylist[k][S_NAME]*/
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _30716 = (object)*(((s1_ptr)_2)->base + _k_62230);
        DeRef(_option_61981);
        _2 = (object)SEQ_PTR(_30716);
        if (!IS_ATOM_INT(_12S_NAME_19864)){
            _option_61981 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
        }
        else{
            _option_61981 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
        }
        Ref(_option_61981);
        _30716 = NOVALUE;

        /** parser.e:4622										exit*/
        goto L2B; // [1060] 1070
L2C: 

        /** parser.e:4624							end for*/
        _k_62230 = _k_62230 + 1LL;
        goto L2A; // [1065] 992
L2B: 
        ;
    }
L28: 

    /** parser.e:4628						idx = find(option, warning_names)*/
    _idx_61982 = find_from(_option_61981, _12warning_names_20271, 1LL);

    /** parser.e:4629						if idx = 0 then*/
    if (_idx_61982 != 0LL)
    goto L2D; // [1082] 1137

    /** parser.e:4630		 					if good_sofar != line_number then*/
    if (_good_sofar_62085 == _12line_number_20227)
    goto L2E; // [1090] 1104

    /** parser.e:4631	 							CompileErr(TOO_MANY_WARNING_ERRORS)*/
    RefDS(_22024);
    _49CompileErr(147LL, _22024, 0LL);
L2E: 

    /** parser.e:4633							Warning(225, 0,*/
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _30721 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_30721);
    ((intptr_t*)_2)[1] = _30721;
    ((intptr_t*)_2)[2] = _12line_number_20227;
    RefDS(_option_61981);
    ((intptr_t*)_2)[3] = _option_61981;
    _30722 = MAKE_SEQ(_1);
    _30721 = NOVALUE;
    _49Warning(225LL, 0LL, _30722);
    _30722 = NOVALUE;

    /** parser.e:4635							tok = next_token()*/
    _0 = _tok_62088;
    _tok_62088 = _43next_token();
    DeRef(_0);

    /** parser.e:4636							continue*/
    goto L24; // [1134] 848
L2D: 

    /** parser.e:4639						idx = warning_flags[idx]*/
    _2 = (object)SEQ_PTR(_12warning_flags_20269);
    _idx_61982 = (object)*(((s1_ptr)_2)->base + _idx_61982);

    /** parser.e:4640						if idx = 0 then*/
    if (_idx_61982 != 0LL)
    goto L2F; // [1149] 1183

    /** parser.e:4641							if on_off then*/
    if (_on_off_61980 == 0)
    {
        goto L30; // [1155] 1170
    }
    else{
    }

    /** parser.e:4642								OpWarning = no_warning_flag*/
    _12OpWarning_20294 = 0LL;
    goto L31; // [1167] 1216
L30: 

    /** parser.e:4644							    OpWarning = all_warning_flag*/
    _12OpWarning_20294 = 32767LL;
    goto L31; // [1180] 1216
L2F: 

    /** parser.e:4647							if on_off then*/
    if (_on_off_61980 == 0)
    {
        goto L32; // [1185] 1201
    }
    else{
    }

    /** parser.e:4648								OpWarning = or_bits(OpWarning, idx)*/
    {uintptr_t tu;
         tu = (uintptr_t)_12OpWarning_20294 | (uintptr_t)_idx_61982;
         _12OpWarning_20294 = MAKE_UINT(tu);
    }
    if (!IS_ATOM_INT(_12OpWarning_20294)) {
        _1 = (object)(DBL_PTR(_12OpWarning_20294)->dbl);
        DeRefDS(_12OpWarning_20294);
        _12OpWarning_20294 = _1;
    }
    goto L33; // [1198] 1215
L32: 

    /** parser.e:4650							    OpWarning = and_bits(OpWarning, not_bits(idx))*/
    _30727 = not_bits(_idx_61982);
    if (IS_ATOM_INT(_30727)) {
        {uintptr_t tu;
             tu = (uintptr_t)_12OpWarning_20294 & (uintptr_t)_30727;
             _12OpWarning_20294 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (eudouble)_12OpWarning_20294;
        _12OpWarning_20294 = Dand_bits(&temp_d, DBL_PTR(_30727));
    }
    DeRef(_30727);
    _30727 = NOVALUE;
    if (!IS_ATOM_INT(_12OpWarning_20294)) {
        _1 = (object)(DBL_PTR(_12OpWarning_20294)->dbl);
        DeRefDS(_12OpWarning_20294);
        _12OpWarning_20294 = _1;
    }
L33: 
L31: 

    /** parser.e:4653						tok = next_token()*/
    _0 = _tok_62088;
    _tok_62088 = _43next_token();
    DeRef(_0);

    /** parser.e:4654					end while*/
    goto L24; // [1223] 848
L25: 
    goto L34; // [1228] 1237
L21: 

    /** parser.e:4656					putback(tok)*/
    Ref(_tok_62088);
    _43putback(_tok_62088);
L34: 
L1D: 
    DeRef(_tok_62088);
    _tok_62088 = NOVALUE;
    goto L2; // [1240] 1546
LF: 

    /** parser.e:4659		elsif equal(option, "define") then*/
    if (_option_61981 == _30730)
    _30731 = 1;
    else if (IS_ATOM_INT(_option_61981) && IS_ATOM_INT(_30730))
    _30731 = 0;
    else
    _30731 = (compare(_option_61981, _30730) == 0);
    if (_30731 == 0)
    {
        _30731 = NOVALUE;
        goto L35; // [1249] 1376
    }
    else{
        _30731 = NOVALUE;
    }

    /** parser.e:4660			option = StringToken()*/
    RefDS(_5);
    _0 = _option_61981;
    _option_61981 = _61StringToken(_5);
    DeRefDS(_0);

    /** parser.e:4661			if length(option) = 0 then*/
    if (IS_SEQUENCE(_option_61981)){
            _30733 = SEQ_PTR(_option_61981)->length;
    }
    else {
        _30733 = 1;
    }
    if (_30733 != 0LL)
    goto L36; // [1265] 1281

    /** parser.e:4662				CompileErr(EXPECTING_TO_FIND_A_WORD_TO_DEFINE_BUT_REACHED_END_OF_LINE_FIRST)*/
    RefDS(_22024);
    _49CompileErr(81LL, _22024, 0LL);
    goto L37; // [1278] 1301
L36: 

    /** parser.e:4664			elsif not t_identifier(option) then*/
    RefDS(_option_61981);
    _30735 = _9t_identifier(_option_61981);
    if (IS_ATOM_INT(_30735)) {
        if (_30735 != 0){
            DeRef(_30735);
            _30735 = NOVALUE;
            goto L38; // [1287] 1300
        }
    }
    else {
        if (DBL_PTR(_30735)->dbl != 0.0){
            DeRef(_30735);
            _30735 = NOVALUE;
            goto L38; // [1287] 1300
        }
    }
    DeRef(_30735);
    _30735 = NOVALUE;

    /** parser.e:4665				CompileErr(DEFINED_WORD_MUST_ONLY_HAVE_ALPHANUMERICS_AND_UNDERSCORE)*/
    RefDS(_22024);
    _49CompileErr(61LL, _22024, 0LL);
L38: 
L37: 

    /** parser.e:4668			if on_off = 0 then*/
    if (_on_off_61980 != 0LL)
    goto L39; // [1303] 1358

    /** parser.e:4669				idx = find(option, OpDefines)*/
    _idx_61982 = find_from(_option_61981, _12OpDefines_20300, 1LL);

    /** parser.e:4670				if idx then*/
    if (_idx_61982 == 0)
    {
        goto L2; // [1318] 1546
    }
    else{
    }

    /** parser.e:4671					OpDefines = OpDefines[1..idx-1]&OpDefines[idx+1..$]*/
    _30739 = _idx_61982 - 1LL;
    rhs_slice_target = (object_ptr)&_30740;
    RHS_Slice(_12OpDefines_20300, 1LL, _30739);
    _30741 = _idx_61982 + 1;
    if (IS_SEQUENCE(_12OpDefines_20300)){
            _30742 = SEQ_PTR(_12OpDefines_20300)->length;
    }
    else {
        _30742 = 1;
    }
    rhs_slice_target = (object_ptr)&_30743;
    RHS_Slice(_12OpDefines_20300, _30741, _30742);
    Concat((object_ptr)&_12OpDefines_20300, _30740, _30743);
    DeRefDS(_30740);
    _30740 = NOVALUE;
    DeRef(_30740);
    _30740 = NOVALUE;
    DeRefDS(_30743);
    _30743 = NOVALUE;
    goto L2; // [1355] 1546
L39: 

    /** parser.e:4674				OpDefines &= {option}*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_option_61981);
    ((intptr_t*)_2)[1] = _option_61981;
    _30745 = MAKE_SEQ(_1);
    Concat((object_ptr)&_12OpDefines_20300, _12OpDefines_20300, _30745);
    DeRefDS(_30745);
    _30745 = NOVALUE;
    goto L2; // [1373] 1546
L35: 

    /** parser.e:4677		elsif equal(option, "inline") then*/
    if (_option_61981 == _30747)
    _30748 = 1;
    else if (IS_ATOM_INT(_option_61981) && IS_ATOM_INT(_30747))
    _30748 = 0;
    else
    _30748 = (compare(_option_61981, _30747) == 0);
    if (_30748 == 0)
    {
        _30748 = NOVALUE;
        goto L3A; // [1382] 1478
    }
    else{
        _30748 = NOVALUE;
    }

    /** parser.e:4679			if on_off and not repl then*/
    if (_on_off_61980 == 0) {
        goto L3B; // [1387] 1467
    }
    _30750 = (0LL == 0);
    if (_30750 == 0)
    {
        DeRef(_30750);
        _30750 = NOVALUE;
        goto L3B; // [1397] 1467
    }
    else{
        DeRef(_30750);
        _30750 = NOVALUE;
    }

    /** parser.e:4680				token tok = next_token()*/
    _0 = _tok_62332;
    _tok_62332 = _43next_token();
    DeRef(_0);

    /** parser.e:4681				if tok[T_ID] = ATOM then*/
    _2 = (object)SEQ_PTR(_tok_62332);
    _30752 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30752, 502LL)){
        _30752 = NOVALUE;
        goto L3C; // [1415] 1447
    }
    _30752 = NOVALUE;

    /** parser.e:4682					OpInline = floor( SymTab[tok[T_SYM]][S_OBJ] )*/
    _2 = (object)SEQ_PTR(_tok_62332);
    _30754 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_30754)){
        _30755 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30754)->dbl));
    }
    else{
        _30755 = (object)*(((s1_ptr)_2)->base + _30754);
    }
    _2 = (object)SEQ_PTR(_30755);
    _30756 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30755 = NOVALUE;
    if (IS_ATOM_INT(_30756))
    _12OpInline_20301 = e_floor(_30756);
    else
    _12OpInline_20301 = unary_op(FLOOR, _30756);
    _30756 = NOVALUE;
    if (!IS_ATOM_INT(_12OpInline_20301)) {
        _1 = (object)(DBL_PTR(_12OpInline_20301)->dbl);
        DeRefDS(_12OpInline_20301);
        _12OpInline_20301 = _1;
    }
    goto L3D; // [1444] 1462
L3C: 

    /** parser.e:4684					putback(tok)*/
    Ref(_tok_62332);
    _43putback(_tok_62332);

    /** parser.e:4685					OpInline = DEFAULT_INLINE*/
    _12OpInline_20301 = 30LL;
L3D: 
    DeRef(_tok_62332);
    _tok_62332 = NOVALUE;
    goto L2; // [1464] 1546
L3B: 

    /** parser.e:4688				OpInline = 0*/
    _12OpInline_20301 = 0LL;
    goto L2; // [1475] 1546
L3A: 

    /** parser.e:4692		elsif equal( option, "indirect_includes" ) then*/
    if (_option_61981 == _30758)
    _30759 = 1;
    else if (IS_ATOM_INT(_option_61981) && IS_ATOM_INT(_30758))
    _30759 = 0;
    else
    _30759 = (compare(_option_61981, _30758) == 0);
    if (_30759 == 0)
    {
        _30759 = NOVALUE;
        goto L3E; // [1484] 1497
    }
    else{
        _30759 = NOVALUE;
    }

    /** parser.e:4693			OpIndirectInclude = on_off*/
    _12OpIndirectInclude_20302 = _on_off_61980;
    goto L2; // [1494] 1546
L3E: 

    /** parser.e:4695		elsif equal(option, "batch") then*/
    if (_option_61981 == _25540)
    _30760 = 1;
    else if (IS_ATOM_INT(_option_61981) && IS_ATOM_INT(_25540))
    _30760 = 0;
    else
    _30760 = (compare(_option_61981, _25540) == 0);
    if (_30760 == 0)
    {
        _30760 = NOVALUE;
        goto L3F; // [1503] 1516
    }
    else{
        _30760 = NOVALUE;
    }

    /** parser.e:4696			batch_job = on_off*/
    _12batch_job_20239 = _on_off_61980;
    goto L2; // [1513] 1546
L3F: 

    /** parser.e:4698		elsif integer(to_number(option, -1)) then*/
    RefDS(_option_61981);
    _30761 = _19to_number(_option_61981, -1LL);
    if (IS_ATOM_INT(_30761))
    _30762 = 1;
    else if (IS_ATOM_DBL(_30761))
    _30762 = IS_ATOM_INT(DoubleToInt(_30761));
    else
    _30762 = 0;
    DeRef(_30761);
    _30761 = NOVALUE;
    if (_30762 == 0)
    {
        _30762 = NOVALUE;
        goto L40; // [1526] 1532
    }
    else{
        _30762 = NOVALUE;
    }
    goto L2; // [1529] 1546
L40: 

    /** parser.e:4702			CompileErr(UNKNOWN_WITHWITHOUT_OPTION_1, {option})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_option_61981);
    ((intptr_t*)_2)[1] = _option_61981;
    _30763 = MAKE_SEQ(_1);
    _49CompileErr(154LL, _30763, 0LL);
    _30763 = NOVALUE;
L2: 

    /** parser.e:4705	end procedure*/
    DeRef(_option_61981);
    _30697 = NOVALUE;
    DeRef(_30739);
    _30739 = NOVALUE;
    _30700 = NOVALUE;
    _30639 = NOVALUE;
    DeRef(_30642);
    _30642 = NOVALUE;
    _30670 = NOVALUE;
    DeRef(_30710);
    _30710 = NOVALUE;
    DeRef(_30664);
    _30664 = NOVALUE;
    _30704 = NOVALUE;
    _30701 = NOVALUE;
    DeRef(_30656);
    _30656 = NOVALUE;
    DeRef(_30623);
    _30623 = NOVALUE;
    DeRef(_30741);
    _30741 = NOVALUE;
    DeRef(_30628);
    _30628 = NOVALUE;
    _30635 = NOVALUE;
    _30754 = NOVALUE;
    return;
    ;
}


void _43ExecCommand()
{
    object _0, _1, _2;
    

    /** parser.e:4709		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L1; // [5] 16
    }
    else{
    }

    /** parser.e:4710			emit_op(RETURNT)*/
    _45emit_op(34LL);
L1: 

    /** parser.e:4712		StraightenBranches()  -- straighten top-level*/
    _43StraightenBranches();

    /** parser.e:4713	end procedure*/
    return;
    ;
}


object _43undefined_var(object _tok_62376, object _scope_62377)
{
    object _forward_62379 = NOVALUE;
    object _30769 = NOVALUE;
    object _30768 = NOVALUE;
    object _30765 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:4716		token forward = next_token()*/
    _0 = _forward_62379;
    _forward_62379 = _43next_token();
    DeRef(_0);

    /** parser.e:4717			switch forward[T_ID] do*/
    _2 = (object)SEQ_PTR(_forward_62379);
    _30765 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_30765) ){
        goto L1; // [16] 82
    }
    if(!IS_ATOM_INT(_30765)){
        if( (DBL_PTR(_30765)->dbl != (eudouble) ((object) DBL_PTR(_30765)->dbl) ) ){
            goto L1; // [16] 82
        }
        _0 = (object) DBL_PTR(_30765)->dbl;
    }
    else {
        _0 = _30765;
    };
    _30765 = NOVALUE;
    switch ( _0 ){ 

        /** parser.e:4718				case LEFT_ROUND then*/
        case -26:

        /** parser.e:4719					StartSourceLine( TRUE )*/
        _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

        /** parser.e:4720					Forward_call( tok )*/
        Ref(_tok_62376);
        _43Forward_call(_tok_62376, 195LL);

        /** parser.e:4721					return 1*/
        DeRef(_tok_62376);
        DeRef(_forward_62379);
        return 1LL;
        goto L2; // [48] 96

        /** parser.e:4723				case VARIABLE then*/
        case -100:

        /** parser.e:4724					putback( forward )*/
        Ref(_forward_62379);
        _43putback(_forward_62379);

        /** parser.e:4725					Global_declaration( tok[T_SYM], scope )*/
        _2 = (object)SEQ_PTR(_tok_62376);
        _30768 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_30768);
        _30769 = _43Global_declaration(_30768, _scope_62377);
        _30768 = NOVALUE;

        /** parser.e:4726					return 1*/
        DeRef(_tok_62376);
        DeRef(_forward_62379);
        DeRef(_30769);
        _30769 = NOVALUE;
        return 1LL;
        goto L2; // [78] 96

        /** parser.e:4728				case else*/
        default:
L1: 

        /** parser.e:4729					putback( forward )*/
        Ref(_forward_62379);
        _43putback(_forward_62379);

        /** parser.e:4730					return 0*/
        DeRef(_tok_62376);
        DeRef(_forward_62379);
        DeRef(_30769);
        _30769 = NOVALUE;
        return 0LL;
    ;}L2: 
    ;
}


void _43real_parser(object _nested_62398)
{
    object _tok_62400 = NOVALUE;
    object _id_62401 = NOVALUE;
    object _scope_62402 = NOVALUE;
    object _deprecated_62464 = NOVALUE;
    object _test_62559 = NOVALUE;
    object _30909 = NOVALUE;
    object _30907 = NOVALUE;
    object _30906 = NOVALUE;
    object _30905 = NOVALUE;
    object _30904 = NOVALUE;
    object _30903 = NOVALUE;
    object _30902 = NOVALUE;
    object _30901 = NOVALUE;
    object _30896 = NOVALUE;
    object _30895 = NOVALUE;
    object _30892 = NOVALUE;
    object _30890 = NOVALUE;
    object _30889 = NOVALUE;
    object _30886 = NOVALUE;
    object _30872 = NOVALUE;
    object _30865 = NOVALUE;
    object _30864 = NOVALUE;
    object _30862 = NOVALUE;
    object _30860 = NOVALUE;
    object _30859 = NOVALUE;
    object _30857 = NOVALUE;
    object _30855 = NOVALUE;
    object _30850 = NOVALUE;
    object _30848 = NOVALUE;
    object _30846 = NOVALUE;
    object _30845 = NOVALUE;
    object _30844 = NOVALUE;
    object _30842 = NOVALUE;
    object _30840 = NOVALUE;
    object _30838 = NOVALUE;
    object _30836 = NOVALUE;
    object _30835 = NOVALUE;
    object _30834 = NOVALUE;
    object _30833 = NOVALUE;
    object _30832 = NOVALUE;
    object _30831 = NOVALUE;
    object _30830 = NOVALUE;
    object _30829 = NOVALUE;
    object _30828 = NOVALUE;
    object _30827 = NOVALUE;
    object _30826 = NOVALUE;
    object _30825 = NOVALUE;
    object _30824 = NOVALUE;
    object _30823 = NOVALUE;
    object _30821 = NOVALUE;
    object _30820 = NOVALUE;
    object _30819 = NOVALUE;
    object _30818 = NOVALUE;
    object _30816 = NOVALUE;
    object _30814 = NOVALUE;
    object _30813 = NOVALUE;
    object _30812 = NOVALUE;
    object _30810 = NOVALUE;
    object _30799 = NOVALUE;
    object _30797 = NOVALUE;
    object _30796 = NOVALUE;
    object _30795 = NOVALUE;
    object _30794 = NOVALUE;
    object _30793 = NOVALUE;
    object _30792 = NOVALUE;
    object _30791 = NOVALUE;
    object _30790 = NOVALUE;
    object _30789 = NOVALUE;
    object _30787 = NOVALUE;
    object _30786 = NOVALUE;
    object _30785 = NOVALUE;
    object _30784 = NOVALUE;
    object _30783 = NOVALUE;
    object _30782 = NOVALUE;
    object _30781 = NOVALUE;
    object _30780 = NOVALUE;
    object _30779 = NOVALUE;
    object _30778 = NOVALUE;
    object _30776 = NOVALUE;
    object _30772 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:4737		integer id*/

    /** parser.e:4738		integer scope*/

    /** parser.e:4740		while TRUE do  -- infinite loop until scanner aborts*/
L1: 
    if (_9TRUE_446 == 0)
    {
        goto L2; // [14] 1925
    }
    else{
    }

    /** parser.e:4741			if OpInline = 25000 then*/
    if (_12OpInline_20301 != 25000LL)
    goto L3; // [21] 35

    /** parser.e:4742				CompileErr("OpInline went nuts: [1]", OpInline )*/
    RefDS(_30771);
    _49CompileErr(_30771, _12OpInline_20301, 0LL);
L3: 

    /** parser.e:4744			start_index = length(Code)+1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _30772 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _30772 = 1;
    }
    _43start_index_55021 = _30772 + 1;
    _30772 = NOVALUE;

    /** parser.e:4745			tok = next_token()*/
    _0 = _tok_62400;
    _tok_62400 = _43next_token();
    DeRef(_0);

    /** parser.e:4746			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_62400);
    _id_62401 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_62401)){
        _id_62401 = (object)DBL_PTR(_id_62401)->dbl;
    }

    /** parser.e:4747			if id = VARIABLE or id = QUALIFIED_VARIABLE then*/
    _30776 = (_id_62401 == -100LL);
    if (_30776 != 0) {
        goto L4; // [69] 84
    }
    _30778 = (_id_62401 == 512LL);
    if (_30778 == 0)
    {
        DeRef(_30778);
        _30778 = NOVALUE;
        goto L5; // [80] 151
    }
    else{
        DeRef(_30778);
        _30778 = NOVALUE;
    }
L4: 

    /** parser.e:4748				if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED*/
    _2 = (object)SEQ_PTR(_tok_62400);
    _30779 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_30779)){
        _30780 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30779)->dbl));
    }
    else{
        _30780 = (object)*(((s1_ptr)_2)->base + _30779);
    }
    _2 = (object)SEQ_PTR(_30780);
    _30781 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30780 = NOVALUE;
    if (IS_ATOM_INT(_30781)) {
        _30782 = (_30781 == 9LL);
    }
    else {
        _30782 = binary_op(EQUALS, _30781, 9LL);
    }
    _30781 = NOVALUE;
    if (IS_ATOM_INT(_30782)) {
        if (_30782 == 0) {
            goto L6; // [110] 130
        }
    }
    else {
        if (DBL_PTR(_30782)->dbl == 0.0) {
            goto L6; // [110] 130
        }
    }
    Ref(_tok_62400);
    _30784 = _43undefined_var(_tok_62400, 5LL);
    if (_30784 == 0) {
        DeRef(_30784);
        _30784 = NOVALUE;
        goto L6; // [122] 130
    }
    else {
        if (!IS_ATOM_INT(_30784) && DBL_PTR(_30784)->dbl == 0.0){
            DeRef(_30784);
            _30784 = NOVALUE;
            goto L6; // [122] 130
        }
        DeRef(_30784);
        _30784 = NOVALUE;
    }
    DeRef(_30784);
    _30784 = NOVALUE;

    /** parser.e:4750					continue*/
    goto L1; // [127] 12
L6: 

    /** parser.e:4752				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:4753				Assignment(tok)*/
    Ref(_tok_62400);
    _43Assignment(_tok_62400);

    /** parser.e:4754				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [148] 1915
L5: 

    /** parser.e:4756			elsif id = PROCEDURE or id = FUNCTION or id = TYPE_DECL then*/
    _30785 = (_id_62401 == 405LL);
    if (_30785 != 0) {
        _30786 = 1;
        goto L8; // [159] 173
    }
    _30787 = (_id_62401 == 406LL);
    _30786 = (_30787 != 0);
L8: 
    if (_30786 != 0) {
        goto L9; // [173] 188
    }
    _30789 = (_id_62401 == 416LL);
    if (_30789 == 0)
    {
        DeRef(_30789);
        _30789 = NOVALUE;
        goto LA; // [184] 206
    }
    else{
        DeRef(_30789);
        _30789 = NOVALUE;
    }
L9: 

    /** parser.e:4757				SubProg(tok[T_ID], SC_LOCAL, 0)*/
    _2 = (object)SEQ_PTR(_tok_62400);
    _30790 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_30790);
    _43SubProg(_30790, 5LL, 0LL);
    _30790 = NOVALUE;
    goto L7; // [203] 1915
LA: 

    /** parser.e:4759			elsif id = GLOBAL or id = EXPORT or id = OVERRIDE or id = PUBLIC or id = DEPRECATE then*/
    _30791 = (_id_62401 == 412LL);
    if (_30791 != 0) {
        _30792 = 1;
        goto LB; // [214] 228
    }
    _30793 = (_id_62401 == 428LL);
    _30792 = (_30793 != 0);
LB: 
    if (_30792 != 0) {
        _30794 = 1;
        goto LC; // [228] 242
    }
    _30795 = (_id_62401 == 429LL);
    _30794 = (_30795 != 0);
LC: 
    if (_30794 != 0) {
        _30796 = 1;
        goto LD; // [242] 256
    }
    _30797 = (_id_62401 == 430LL);
    _30796 = (_30797 != 0);
LD: 
    if (_30796 != 0) {
        goto LE; // [256] 271
    }
    _30799 = (_id_62401 == 433LL);
    if (_30799 == 0)
    {
        DeRef(_30799);
        _30799 = NOVALUE;
        goto LF; // [267] 692
    }
    else{
        DeRef(_30799);
        _30799 = NOVALUE;
    }
LE: 

    /** parser.e:4760				integer deprecated = 0*/
    _deprecated_62464 = 0LL;

    /** parser.e:4762				if id = DEPRECATE then*/
    if (_id_62401 != 433LL)
    goto L10; // [280] 305

    /** parser.e:4763					deprecated = 1*/
    _deprecated_62464 = 1LL;

    /** parser.e:4765					tok = next_token()*/
    _0 = _tok_62400;
    _tok_62400 = _43next_token();
    DeRef(_0);

    /** parser.e:4766					id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_62400);
    _id_62401 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_62401)){
        _id_62401 = (object)DBL_PTR(_id_62401)->dbl;
    }
L10: 

    /** parser.e:4769				scope = SC_LOCAL*/
    _scope_62402 = 5LL;

    /** parser.e:4770				if id = GLOBAL then*/
    if (_id_62401 != 412LL)
    goto L11; // [318] 334

    /** parser.e:4771				    scope = SC_GLOBAL*/
    _scope_62402 = 6LL;
    goto L12; // [331] 393
L11: 

    /** parser.e:4772				elsif id = EXPORT then*/
    if (_id_62401 != 428LL)
    goto L13; // [338] 354

    /** parser.e:4773					scope = SC_EXPORT*/
    _scope_62402 = 11LL;
    goto L12; // [351] 393
L13: 

    /** parser.e:4774				elsif id = OVERRIDE then*/
    if (_id_62401 != 429LL)
    goto L14; // [358] 374

    /** parser.e:4775					scope = SC_OVERRIDE*/
    _scope_62402 = 12LL;
    goto L12; // [371] 393
L14: 

    /** parser.e:4776				elsif id = PUBLIC then*/
    if (_id_62401 != 430LL)
    goto L15; // [378] 392

    /** parser.e:4777					scope = SC_PUBLIC*/
    _scope_62402 = 13LL;
L15: 
L12: 

    /** parser.e:4781				if scope != SC_LOCAL then*/
    if (_scope_62402 == 5LL)
    goto L16; // [397] 417

    /** parser.e:4782					tok = next_token()*/
    _0 = _tok_62400;
    _tok_62400 = _43next_token();
    DeRef(_0);

    /** parser.e:4783					id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_62400);
    _id_62401 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_62401)){
        _id_62401 = (object)DBL_PTR(_id_62401)->dbl;
    }
L16: 

    /** parser.e:4786				if id = TYPE or id = QUALIFIED_TYPE then*/
    _30810 = (_id_62401 == 504LL);
    if (_30810 != 0) {
        goto L17; // [425] 440
    }
    _30812 = (_id_62401 == 522LL);
    if (_30812 == 0)
    {
        DeRef(_30812);
        _30812 = NOVALUE;
        goto L18; // [436] 456
    }
    else{
        DeRef(_30812);
        _30812 = NOVALUE;
    }
L17: 

    /** parser.e:4787					Global_declaration(tok[T_SYM], scope )*/
    _2 = (object)SEQ_PTR(_tok_62400);
    _30813 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30813);
    _30814 = _43Global_declaration(_30813, _scope_62402);
    _30813 = NOVALUE;
    goto L19; // [453] 687
L18: 

    /** parser.e:4789				elsif id = CONSTANT then*/
    if (_id_62401 != 417LL)
    goto L1A; // [460] 478

    /** parser.e:4790					Global_declaration(0, scope )*/
    _30816 = _43Global_declaration(0LL, _scope_62402);

    /** parser.e:4791					ExecCommand()*/
    _43ExecCommand();
    goto L19; // [475] 687
L1A: 

    /** parser.e:4793				elsif id = ENUM then*/
    if (_id_62401 != 427LL)
    goto L1B; // [482] 500

    /** parser.e:4794					Global_declaration(-1, scope )*/
    _30818 = _43Global_declaration(-1LL, _scope_62402);

    /** parser.e:4795					ExecCommand()*/
    _43ExecCommand();
    goto L19; // [497] 687
L1B: 

    /** parser.e:4797				elsif id = PROCEDURE or id = FUNCTION or id = TYPE_DECL then*/
    _30819 = (_id_62401 == 405LL);
    if (_30819 != 0) {
        _30820 = 1;
        goto L1C; // [508] 522
    }
    _30821 = (_id_62401 == 406LL);
    _30820 = (_30821 != 0);
L1C: 
    if (_30820 != 0) {
        goto L1D; // [522] 537
    }
    _30823 = (_id_62401 == 416LL);
    if (_30823 == 0)
    {
        DeRef(_30823);
        _30823 = NOVALUE;
        goto L1E; // [533] 547
    }
    else{
        DeRef(_30823);
        _30823 = NOVALUE;
    }
L1D: 

    /** parser.e:4798					SubProg(id, scope, deprecated)*/
    _43SubProg(_id_62401, _scope_62402, _deprecated_62464);
    goto L19; // [544] 687
L1E: 

    /** parser.e:4800				elsif (scope = SC_PUBLIC) and id = INCLUDE then*/
    _30824 = (_scope_62402 == 13LL);
    if (_30824 == 0) {
        goto L1F; // [555] 581
    }
    _30826 = (_id_62401 == 418LL);
    if (_30826 == 0)
    {
        DeRef(_30826);
        _30826 = NOVALUE;
        goto L1F; // [566] 581
    }
    else{
        DeRef(_30826);
        _30826 = NOVALUE;
    }

    /** parser.e:4801					IncludeScan( 1 )*/
    _61IncludeScan(1LL);

    /** parser.e:4802					PushGoto()*/
    _43PushGoto();
    goto L19; // [578] 687
L1F: 

    /** parser.e:4803				elsif (id = VARIABLE or id = QUALIFIED_VARIABLE)*/
    _30827 = (_id_62401 == -100LL);
    if (_30827 != 0) {
        _30828 = 1;
        goto L20; // [589] 603
    }
    _30829 = (_id_62401 == 512LL);
    _30828 = (_30829 != 0);
L20: 
    if (_30828 == 0) {
        _30830 = 0;
        goto L21; // [603] 635
    }
    _2 = (object)SEQ_PTR(_tok_62400);
    _30831 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_30831)){
        _30832 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30831)->dbl));
    }
    else{
        _30832 = (object)*(((s1_ptr)_2)->base + _30831);
    }
    _2 = (object)SEQ_PTR(_30832);
    _30833 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30832 = NOVALUE;
    if (IS_ATOM_INT(_30833)) {
        _30834 = (_30833 == 9LL);
    }
    else {
        _30834 = binary_op(EQUALS, _30833, 9LL);
    }
    _30833 = NOVALUE;
    if (IS_ATOM_INT(_30834))
    _30830 = (_30834 != 0);
    else
    _30830 = DBL_PTR(_30834)->dbl != 0.0;
L21: 
    if (_30830 == 0) {
        goto L22; // [635] 657
    }
    Ref(_tok_62400);
    _30836 = _43undefined_var(_tok_62400, _scope_62402);
    if (_30836 == 0) {
        DeRef(_30836);
        _30836 = NOVALUE;
        goto L22; // [645] 657
    }
    else {
        if (!IS_ATOM_INT(_30836) && DBL_PTR(_30836)->dbl == 0.0){
            DeRef(_30836);
            _30836 = NOVALUE;
            goto L22; // [645] 657
        }
        DeRef(_30836);
        _30836 = NOVALUE;
    }
    DeRef(_30836);
    _30836 = NOVALUE;

    /** parser.e:4807					continue*/
    goto L1; // [652] 12
    goto L19; // [654] 687
L22: 

    /** parser.e:4809				elsif scope = SC_GLOBAL then*/
    if (_scope_62402 != 6LL)
    goto L23; // [661] 677

    /** parser.e:4810					CompileErr( MSG_GLOBAL_MUST_BE_FOLLOWED_BYA_TYPE_CONSTANT_ENUM_PROCEDURE_TYPE_OR_FUNCTION)*/
    RefDS(_22024);
    _49CompileErr(18LL, _22024, 0LL);
    goto L19; // [674] 687
L23: 

    /** parser.e:4812					CompileErr( MSG_PUBLIC_OR_EXPORT_MUST_BE_FOLLOWED_BYA_TYPE_CONSTANT_ENUM_PROCEDURE_TYPE_OR_FUNCTION)*/
    RefDS(_22024);
    _49CompileErr(16LL, _22024, 0LL);
L19: 
    goto L7; // [689] 1915
LF: 

    /** parser.e:4815			elsif id = TYPE or id = QUALIFIED_TYPE then*/
    _30838 = (_id_62401 == 504LL);
    if (_30838 != 0) {
        goto L24; // [700] 715
    }
    _30840 = (_id_62401 == 522LL);
    if (_30840 == 0)
    {
        DeRef(_30840);
        _30840 = NOVALUE;
        goto L25; // [711] 800
    }
    else{
        DeRef(_30840);
        _30840 = NOVALUE;
    }
L24: 

    /** parser.e:4816				token test = next_token()*/
    _0 = _test_62559;
    _test_62559 = _43next_token();
    DeRef(_0);

    /** parser.e:4817				putback( test )*/
    Ref(_test_62559);
    _43putback(_test_62559);

    /** parser.e:4818				if test[T_ID] = LEFT_ROUND then*/
    _2 = (object)SEQ_PTR(_test_62559);
    _30842 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30842, -26LL)){
        _30842 = NOVALUE;
        goto L26; // [735] 773
    }
    _30842 = NOVALUE;

    /** parser.e:4819						StartSourceLine( TRUE )*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:4820						Procedure_call(tok)*/
    Ref(_tok_62400);
    _43Procedure_call(_tok_62400);

    /** parser.e:4821						clear_op()*/
    _45clear_op();

    /** parser.e:4822						if Pop() then end if*/
    _30844 = _45Pop();
    if (_30844 == 0) {
        DeRef(_30844);
        _30844 = NOVALUE;
        goto L27; // [762] 766
    }
    else {
        if (!IS_ATOM_INT(_30844) && DBL_PTR(_30844)->dbl == 0.0){
            DeRef(_30844);
            _30844 = NOVALUE;
            goto L27; // [762] 766
        }
        DeRef(_30844);
        _30844 = NOVALUE;
    }
    DeRef(_30844);
    _30844 = NOVALUE;
L27: 

    /** parser.e:4823						ExecCommand()*/
    _43ExecCommand();
    goto L28; // [770] 789
L26: 

    /** parser.e:4826					Global_declaration( tok[T_SYM], SC_LOCAL )*/
    _2 = (object)SEQ_PTR(_tok_62400);
    _30845 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30845);
    _30846 = _43Global_declaration(_30845, 5LL);
    _30845 = NOVALUE;
L28: 

    /** parser.e:4829				continue*/
    DeRef(_test_62559);
    _test_62559 = NOVALUE;
    goto L1; // [793] 12
    goto L7; // [797] 1915
L25: 

    /** parser.e:4831			elsif id = CONSTANT then*/
    if (_id_62401 != 417LL)
    goto L29; // [804] 824

    /** parser.e:4832				Global_declaration(0, SC_LOCAL)*/
    _30848 = _43Global_declaration(0LL, 5LL);

    /** parser.e:4833				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [821] 1915
L29: 

    /** parser.e:4835			elsif id = ENUM then*/
    if (_id_62401 != 427LL)
    goto L2A; // [828] 848

    /** parser.e:4836				Global_declaration(-1, SC_LOCAL)*/
    _30850 = _43Global_declaration(-1LL, 5LL);

    /** parser.e:4837				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [845] 1915
L2A: 

    /** parser.e:4839			elsif id = IF then*/
    if (_id_62401 != 20LL)
    goto L2B; // [852] 876

    /** parser.e:4840				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:4841				If_statement()*/
    _43If_statement();

    /** parser.e:4842				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [873] 1915
L2B: 

    /** parser.e:4844			elsif id = FOR then*/
    if (_id_62401 != 21LL)
    goto L2C; // [880] 904

    /** parser.e:4845				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:4846				For_statement()*/
    _43For_statement();

    /** parser.e:4847				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [901] 1915
L2C: 

    /** parser.e:4849			elsif id = WHILE then*/
    if (_id_62401 != 47LL)
    goto L2D; // [908] 932

    /** parser.e:4850				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:4851				While_statement()*/
    _43While_statement();

    /** parser.e:4852				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [929] 1915
L2D: 

    /** parser.e:4854			elsif id = LOOP then*/
    if (_id_62401 != 422LL)
    goto L2E; // [936] 960

    /** parser.e:4855			    StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:4856			    Loop_statement()*/
    _43Loop_statement();

    /** parser.e:4857			    ExecCommand()*/
    _43ExecCommand();
    goto L7; // [957] 1915
L2E: 

    /** parser.e:4859			elsif id = PROC or id = QUALIFIED_PROC then*/
    _30855 = (_id_62401 == 27LL);
    if (_30855 != 0) {
        goto L2F; // [968] 983
    }
    _30857 = (_id_62401 == 521LL);
    if (_30857 == 0)
    {
        DeRef(_30857);
        _30857 = NOVALUE;
        goto L30; // [979] 1024
    }
    else{
        DeRef(_30857);
        _30857 = NOVALUE;
    }
L2F: 

    /** parser.e:4860				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:4861				if id = PROC then*/
    if (_id_62401 != 27LL)
    goto L31; // [996] 1012

    /** parser.e:4863					UndefinedVar( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_62400);
    _30859 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30859);
    _43UndefinedVar(_30859);
    _30859 = NOVALUE;
L31: 

    /** parser.e:4866				Procedure_call(tok)*/
    Ref(_tok_62400);
    _43Procedure_call(_tok_62400);

    /** parser.e:4867				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [1021] 1915
L30: 

    /** parser.e:4869			elsif id = FUNC or id = QUALIFIED_FUNC then*/
    _30860 = (_id_62401 == 501LL);
    if (_30860 != 0) {
        goto L32; // [1032] 1047
    }
    _30862 = (_id_62401 == 520LL);
    if (_30862 == 0)
    {
        DeRef(_30862);
        _30862 = NOVALUE;
        goto L33; // [1043] 1101
    }
    else{
        DeRef(_30862);
        _30862 = NOVALUE;
    }
L32: 

    /** parser.e:4870				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:4871				if id = FUNC then*/
    if (_id_62401 != 501LL)
    goto L34; // [1060] 1076

    /** parser.e:4873					UndefinedVar( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_62400);
    _30864 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30864);
    _43UndefinedVar(_30864);
    _30864 = NOVALUE;
L34: 

    /** parser.e:4876				Procedure_call(tok)*/
    Ref(_tok_62400);
    _43Procedure_call(_tok_62400);

    /** parser.e:4877				clear_op()*/
    _45clear_op();

    /** parser.e:4878				if Pop() then end if*/
    _30865 = _45Pop();
    if (_30865 == 0) {
        DeRef(_30865);
        _30865 = NOVALUE;
        goto L35; // [1090] 1094
    }
    else {
        if (!IS_ATOM_INT(_30865) && DBL_PTR(_30865)->dbl == 0.0){
            DeRef(_30865);
            _30865 = NOVALUE;
            goto L35; // [1090] 1094
        }
        DeRef(_30865);
        _30865 = NOVALUE;
    }
    DeRef(_30865);
    _30865 = NOVALUE;
L35: 

    /** parser.e:4879				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [1098] 1915
L33: 

    /** parser.e:4881			elsif id = RETURN then*/
    if (_id_62401 != 413LL)
    goto L36; // [1105] 1116

    /** parser.e:4882				Return_statement() -- will fail - not allowed at top level*/
    _43Return_statement();
    goto L7; // [1113] 1915
L36: 

    /** parser.e:4884			elsif id = EXIT then*/
    if (_id_62401 != 61LL)
    goto L37; // [1120] 1158

    /** parser.e:4885				if nested then*/
    if (_nested_62398 == 0)
    {
        goto L38; // [1126] 1145
    }
    else{
    }

    /** parser.e:4886				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:4887				Exit_statement()*/
    _43Exit_statement();
    goto L7; // [1142] 1915
L38: 

    /** parser.e:4889				CompileErr(EXIT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22024);
    _49CompileErr(89LL, _22024, 0LL);
    goto L7; // [1155] 1915
L37: 

    /** parser.e:4892			elsif id = INCLUDE then*/
    if (_id_62401 != 418LL)
    goto L39; // [1162] 1178

    /** parser.e:4893				IncludeScan( 0 )*/
    _61IncludeScan(0LL);

    /** parser.e:4894				PushGoto()*/
    _43PushGoto();
    goto L7; // [1175] 1915
L39: 

    /** parser.e:4896			elsif id = WITH then*/
    if (_id_62401 != 420LL)
    goto L3A; // [1182] 1196

    /** parser.e:4897				SetWith(TRUE)*/
    _43SetWith(_9TRUE_446);
    goto L7; // [1193] 1915
L3A: 

    /** parser.e:4899			elsif id = WITHOUT then*/
    if (_id_62401 != 421LL)
    goto L3B; // [1200] 1214

    /** parser.e:4900				SetWith(FALSE)*/
    _43SetWith(_9FALSE_444);
    goto L7; // [1211] 1915
L3B: 

    /** parser.e:4902			elsif id = END_OF_FILE then*/
    if (_id_62401 != -21LL)
    goto L3C; // [1218] 1335

    /** parser.e:4903				if IncludePop() then*/
    _30872 = _61IncludePop();
    if (_30872 == 0) {
        DeRef(_30872);
        _30872 = NOVALUE;
        goto L3D; // [1227] 1323
    }
    else {
        if (!IS_ATOM_INT(_30872) && DBL_PTR(_30872)->dbl == 0.0){
            DeRef(_30872);
            _30872 = NOVALUE;
            goto L3D; // [1227] 1323
        }
        DeRef(_30872);
        _30872 = NOVALUE;
    }
    DeRef(_30872);
    _30872 = NOVALUE;

    /** parser.e:4904					backed_up_tok = {}*/
    RefDS(_22024);
    DeRef(_43backed_up_tok_55022);
    _43backed_up_tok_55022 = _22024;

    /** parser.e:4905					PopGoto()*/
    _43PopGoto();

    /** parser.e:4906					read_line()*/
    _61read_line();

    /** parser.e:4908					last_ForwardLine     = ThisLine*/
    Ref(_49ThisLine_49312);
    DeRef(_49last_ForwardLine_49315);
    _49last_ForwardLine_49315 = _49ThisLine_49312;

    /** parser.e:4909					last_fwd_line_number = line_number*/
    _12last_fwd_line_number_20230 = _12line_number_20227;

    /** parser.e:4910					last_forward_bp      = bp*/
    _49last_forward_bp_49319 = _49bp_49316;

    /** parser.e:4912					putback_ForwardLine     = ThisLine*/
    Ref(_49ThisLine_49312);
    DeRef(_49putback_ForwardLine_49314);
    _49putback_ForwardLine_49314 = _49ThisLine_49312;

    /** parser.e:4913					putback_fwd_line_number = line_number*/
    _12putback_fwd_line_number_20229 = _12line_number_20227;

    /** parser.e:4914					putback_forward_bp      = bp*/
    _49putback_forward_bp_49318 = _49bp_49316;

    /** parser.e:4916					ForwardLine     = ThisLine*/
    Ref(_49ThisLine_49312);
    DeRef(_49ForwardLine_49313);
    _49ForwardLine_49313 = _49ThisLine_49312;

    /** parser.e:4917					fwd_line_number = line_number*/
    _12fwd_line_number_20228 = _12line_number_20227;

    /** parser.e:4918					forward_bp      = bp*/
    _49forward_bp_49317 = _49bp_49316;
    goto L7; // [1320] 1915
L3D: 

    /** parser.e:4921					CheckForUndefinedGotoLabels()*/
    _43CheckForUndefinedGotoLabels();

    /** parser.e:4922					exit -- all finished*/
    goto L2; // [1329] 1925
    goto L7; // [1332] 1915
L3C: 

    /** parser.e:4925			elsif id = QUESTION_MARK then*/
    if (_id_62401 != -31LL)
    goto L3E; // [1339] 1363

    /** parser.e:4926				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:4927				Print_statement()*/
    _43Print_statement();

    /** parser.e:4928				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [1360] 1915
L3E: 

    /** parser.e:4930			elsif id = LABEL then*/
    if (_id_62401 != 419LL)
    goto L3F; // [1367] 1389

    /** parser.e:4931				StartSourceLine(TRUE, , COVERAGE_SUPPRESS)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 1LL);

    /** parser.e:4932				GLabel_statement()*/
    _43GLabel_statement();
    goto L7; // [1386] 1915
L3F: 

    /** parser.e:4934			elsif id = GOTO then*/
    if (_id_62401 != 188LL)
    goto L40; // [1393] 1413

    /** parser.e:4935				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:4936				Goto_statement()*/
    _43Goto_statement();
    goto L7; // [1410] 1915
L40: 

    /** parser.e:4938			elsif id = CONTINUE then*/
    if (_id_62401 != 426LL)
    goto L41; // [1417] 1455

    /** parser.e:4939				if nested then*/
    if (_nested_62398 == 0)
    {
        goto L42; // [1423] 1442
    }
    else{
    }

    /** parser.e:4940					StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:4941					Continue_statement()*/
    _43Continue_statement();
    goto L7; // [1439] 1915
L42: 

    /** parser.e:4943					CompileErr(CONTINUE_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22024);
    _49CompileErr(50LL, _22024, 0LL);
    goto L7; // [1452] 1915
L41: 

    /** parser.e:4946			elsif id = RETRY then*/
    if (_id_62401 != 184LL)
    goto L43; // [1459] 1497

    /** parser.e:4947				if nested then*/
    if (_nested_62398 == 0)
    {
        goto L44; // [1465] 1484
    }
    else{
    }

    /** parser.e:4948					StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:4949					Retry_statement()*/
    _43Retry_statement();
    goto L7; // [1481] 1915
L44: 

    /** parser.e:4951					CompileErr(RETRY_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22024);
    _49CompileErr(128LL, _22024, 0LL);
    goto L7; // [1494] 1915
L43: 

    /** parser.e:4954			elsif id = BREAK then*/
    if (_id_62401 != 425LL)
    goto L45; // [1501] 1539

    /** parser.e:4955				if nested then*/
    if (_nested_62398 == 0)
    {
        goto L46; // [1507] 1526
    }
    else{
    }

    /** parser.e:4956					StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:4957					Break_statement()*/
    _43Break_statement();
    goto L7; // [1523] 1915
L46: 

    /** parser.e:4959					CompileErr(BREAK_MUST_BE_INSIDE_AN_IF_BLOCK)*/
    RefDS(_22024);
    _49CompileErr(39LL, _22024, 0LL);
    goto L7; // [1536] 1915
L45: 

    /** parser.e:4962			elsif id = ENTRY then*/
    if (_id_62401 != 424LL)
    goto L47; // [1543] 1583

    /** parser.e:4963				if nested then*/
    if (_nested_62398 == 0)
    {
        goto L48; // [1549] 1570
    }
    else{
    }

    /** parser.e:4964				    StartSourceLine(TRUE, , COVERAGE_SUPPRESS)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 1LL);

    /** parser.e:4965				    Entry_statement()*/
    _43Entry_statement();
    goto L7; // [1567] 1915
L48: 

    /** parser.e:4967					CompileErr(ENTRY_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22024);
    _49CompileErr(72LL, _22024, 0LL);
    goto L7; // [1580] 1915
L47: 

    /** parser.e:4970			elsif id = IFDEF then*/
    if (_id_62401 != 407LL)
    goto L49; // [1587] 1607

    /** parser.e:4971				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:4972				Ifdef_statement()*/
    _43Ifdef_statement();
    goto L7; // [1604] 1915
L49: 

    /** parser.e:4974			elsif id = CASE then*/
    if (_id_62401 != 186LL)
    goto L4A; // [1611] 1622

    /** parser.e:4975				Case_statement()*/
    _43Case_statement();
    goto L7; // [1619] 1915
L4A: 

    /** parser.e:4977			elsif id = SWITCH then*/
    if (_id_62401 != 185LL)
    goto L4B; // [1626] 1646

    /** parser.e:4978				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:4979				Switch_statement()*/
    _43Switch_statement();
    goto L7; // [1643] 1915
L4B: 

    /** parser.e:4981			elsif id = LEFT_BRACE then*/
    if (_id_62401 != -24LL)
    goto L4C; // [1650] 1670

    /** parser.e:4982				StartSourceLine( TRUE )*/
    _45StartSourceLine(_9TRUE_446, 0LL, 2LL);

    /** parser.e:4983				Multi_assign()*/
    _43Multi_assign();
    goto L7; // [1667] 1915
L4C: 

    /** parser.e:4985			elsif id = ILLEGAL_CHAR then*/
    if (_id_62401 != -20LL)
    goto L4D; // [1674] 1690

    /** parser.e:4986				CompileErr(ILLEGAL_CHARACTER)*/
    RefDS(_22024);
    _49CompileErr(102LL, _22024, 0LL);
    goto L7; // [1687] 1915
L4D: 

    /** parser.e:4989				if nested then*/
    if (_nested_62398 == 0)
    {
        goto L4E; // [1692] 1852
    }
    else{
    }

    /** parser.e:4990					if id = ELSE then*/
    if (_id_62401 != 23LL)
    goto L4F; // [1699] 1757

    /** parser.e:4991						if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_43if_stack_55050)){
            _30886 = SEQ_PTR(_43if_stack_55050)->length;
    }
    else {
        _30886 = 1;
    }
    if (_30886 != 0LL)
    goto L50; // [1710] 1818

    /** parser.e:4992							if live_ifdef > 0 then*/
    if (_43live_ifdef_59522 <= 0LL)
    goto L51; // [1718] 1743

    /** parser.e:4993								CompileErr(SHOULD_THIS_BE_ELSEDEF_FOR_THE_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59523)){
            _30889 = SEQ_PTR(_43ifdef_lineno_59523)->length;
    }
    else {
        _30889 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59523);
    _30890 = (object)*(((s1_ptr)_2)->base + _30889);
    _49CompileErr(134LL, _30890, 0LL);
    _30890 = NOVALUE;
    goto L50; // [1740] 1818
L51: 

    /** parser.e:4995								CompileErr(NOT_EXPECTING_ELSE)*/
    RefDS(_22024);
    _49CompileErr(118LL, _22024, 0LL);
    goto L50; // [1754] 1818
L4F: 

    /** parser.e:4998					elsif id = ELSIF then*/
    if (_id_62401 != 414LL)
    goto L52; // [1761] 1817

    /** parser.e:4999						if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_43if_stack_55050)){
            _30892 = SEQ_PTR(_43if_stack_55050)->length;
    }
    else {
        _30892 = 1;
    }
    if (_30892 != 0LL)
    goto L53; // [1772] 1816

    /** parser.e:5000							if live_ifdef > 0 then*/
    if (_43live_ifdef_59522 <= 0LL)
    goto L54; // [1780] 1805

    /** parser.e:5001								CompileErr(SHOULD_THIS_BE_ELSIFDEF_FOR_THE_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59523)){
            _30895 = SEQ_PTR(_43ifdef_lineno_59523)->length;
    }
    else {
        _30895 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59523);
    _30896 = (object)*(((s1_ptr)_2)->base + _30895);
    _49CompileErr(139LL, _30896, 0LL);
    _30896 = NOVALUE;
    goto L55; // [1802] 1815
L54: 

    /** parser.e:5003								CompileErr(NOT_EXPECTING_ELSIF)*/
    RefDS(_22024);
    _49CompileErr(119LL, _22024, 0LL);
L55: 
L53: 
L52: 
L50: 

    /** parser.e:5007					putback(tok)*/
    Ref(_tok_62400);
    _43putback(_tok_62400);

    /** parser.e:5008					if stmt_nest > 0 then*/
    if (_43stmt_nest_55047 <= 0LL)
    goto L56; // [1827] 1844

    /** parser.e:5009						stmt_nest -= 1*/
    _43stmt_nest_55047 = _43stmt_nest_55047 - 1LL;

    /** parser.e:5010						InitDelete()*/
    _43InitDelete();
L56: 

    /** parser.e:5012					return*/
    DeRef(_tok_62400);
    DeRef(_30819);
    _30819 = NOVALUE;
    DeRef(_30850);
    _30850 = NOVALUE;
    DeRef(_30827);
    _30827 = NOVALUE;
    DeRef(_30793);
    _30793 = NOVALUE;
    _30831 = NOVALUE;
    DeRef(_30810);
    _30810 = NOVALUE;
    DeRef(_30782);
    _30782 = NOVALUE;
    DeRef(_30776);
    _30776 = NOVALUE;
    DeRef(_30816);
    _30816 = NOVALUE;
    DeRef(_30795);
    _30795 = NOVALUE;
    DeRef(_30797);
    _30797 = NOVALUE;
    DeRef(_30818);
    _30818 = NOVALUE;
    DeRef(_30834);
    _30834 = NOVALUE;
    DeRef(_30838);
    _30838 = NOVALUE;
    DeRef(_30821);
    _30821 = NOVALUE;
    DeRef(_30785);
    _30785 = NOVALUE;
    DeRef(_30824);
    _30824 = NOVALUE;
    DeRef(_30846);
    _30846 = NOVALUE;
    DeRef(_30787);
    _30787 = NOVALUE;
    DeRef(_30855);
    _30855 = NOVALUE;
    DeRef(_30814);
    _30814 = NOVALUE;
    DeRef(_30791);
    _30791 = NOVALUE;
    DeRef(_30829);
    _30829 = NOVALUE;
    _30779 = NOVALUE;
    DeRef(_30860);
    _30860 = NOVALUE;
    DeRef(_30848);
    _30848 = NOVALUE;
    return;
    goto L57; // [1849] 1914
L4E: 

    /** parser.e:5014					if id = END then*/
    if (_id_62401 != 402LL)
    goto L58; // [1856] 1889

    /** parser.e:5015						tok = next_token()*/
    _0 = _tok_62400;
    _tok_62400 = _43next_token();
    DeRef(_0);

    /** parser.e:5016						CompileErr(MSG_END_HAS_NO_MATCHING_1, {find_token_text(tok[T_ID])})*/
    _2 = (object)SEQ_PTR(_tok_62400);
    _30901 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_30901);
    _30902 = _62find_token_text(_30901);
    _30901 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30902;
    _30903 = MAKE_SEQ(_1);
    _30902 = NOVALUE;
    _49CompileErr(17LL, _30903, 0LL);
    _30903 = NOVALUE;
L58: 

    /** parser.e:5019					CompileErr(NOT_EXPECTING_TO_SEE_1_HERE, { match_replace(",", find_token_text(id), "") })*/
    _30904 = _62find_token_text(_id_62401);
    RefDS(_26234);
    RefDS(_22024);
    _30905 = _20match_replace(_26234, _30904, _22024, 0LL);
    _30904 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30905;
    _30906 = MAKE_SEQ(_1);
    _30905 = NOVALUE;
    _49CompileErr(117LL, _30906, 0LL);
    _30906 = NOVALUE;
L57: 
L7: 

    /** parser.e:5024			flush_temps()*/
    RefDS(_22024);
    _45flush_temps(_22024);

    /** parser.e:5025		end while*/
    goto L1; // [1922] 12
L2: 

    /** parser.e:5026		emit_op(RETURNT)*/
    _45emit_op(34LL);

    /** parser.e:5027		clear_last()*/
    _45clear_last();

    /** parser.e:5028		StraightenBranches()*/
    _43StraightenBranches();

    /** parser.e:5029		SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    RefDS(_12Code_20315);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_19876))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12Code_20315;
    DeRef(_1);
    _30907 = NOVALUE;

    /** parser.e:5030		EndLineTable()*/
    _43EndLineTable();

    /** parser.e:5031		SymTab[TopLevelSub][S_LINETAB] = LineTable*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    RefDS(_12LineTable_20316);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_LINETAB_19899))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_LINETAB_19899)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_LINETAB_19899);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12LineTable_20316;
    DeRef(_1);
    _30909 = NOVALUE;

    /** parser.e:5032	end procedure*/
    DeRef(_tok_62400);
    DeRef(_30819);
    _30819 = NOVALUE;
    DeRef(_30850);
    _30850 = NOVALUE;
    DeRef(_30827);
    _30827 = NOVALUE;
    DeRef(_30793);
    _30793 = NOVALUE;
    _30831 = NOVALUE;
    DeRef(_30810);
    _30810 = NOVALUE;
    DeRef(_30782);
    _30782 = NOVALUE;
    DeRef(_30776);
    _30776 = NOVALUE;
    DeRef(_30816);
    _30816 = NOVALUE;
    DeRef(_30795);
    _30795 = NOVALUE;
    DeRef(_30797);
    _30797 = NOVALUE;
    DeRef(_30818);
    _30818 = NOVALUE;
    DeRef(_30834);
    _30834 = NOVALUE;
    DeRef(_30838);
    _30838 = NOVALUE;
    DeRef(_30821);
    _30821 = NOVALUE;
    DeRef(_30785);
    _30785 = NOVALUE;
    DeRef(_30824);
    _30824 = NOVALUE;
    DeRef(_30846);
    _30846 = NOVALUE;
    DeRef(_30787);
    _30787 = NOVALUE;
    DeRef(_30855);
    _30855 = NOVALUE;
    DeRef(_30814);
    _30814 = NOVALUE;
    DeRef(_30791);
    _30791 = NOVALUE;
    DeRef(_30829);
    _30829 = NOVALUE;
    _30779 = NOVALUE;
    DeRef(_30860);
    _30860 = NOVALUE;
    DeRef(_30848);
    _30848 = NOVALUE;
    return;
    ;
}


void _43parser()
{
    object _30913 = NOVALUE;
    object _30911 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:5035		real_parser(0)*/
    _43real_parser(0LL);

    /** parser.e:5036		mark_final_targets()*/
    _53mark_final_targets();

    /** parser.e:5037		resolve_unincluded_globals( 1 )*/
    _53resolve_unincluded_globals(1LL);

    /** parser.e:5038		Resolve_forward_references( 1 )*/
    _42Resolve_forward_references(1LL);

    /** parser.e:5039		SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    RefDS(_12Code_20315);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_19876))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12Code_20315;
    DeRef(_1);
    _30911 = NOVALUE;

    /** parser.e:5040		SymTab[TopLevelSub][S_LINETAB] = LineTable*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12TopLevelSub_20233 + ((s1_ptr)_2)->base);
    RefDS(_12LineTable_20316);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_LINETAB_19899))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_LINETAB_19899)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_LINETAB_19899);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12LineTable_20316;
    DeRef(_1);
    _30913 = NOVALUE;

    /** parser.e:5041		Code = {}*/
    RefDS(_22024);
    DeRefDS(_12Code_20315);
    _12Code_20315 = _22024;

    /** parser.e:5042		LineTable = {}*/
    RefDS(_22024);
    DeRefDS(_12LineTable_20316);
    _12LineTable_20316 = _22024;

    /** parser.e:5043		inline_deferred_calls()*/
    _66inline_deferred_calls();

    /** parser.e:5044		if not repl then*/

    /** parser.e:5045		End_block( PROC )*/
    _64End_block(27LL);

    /** parser.e:5046		Code = {}*/
    RefDS(_22024);
    DeRefDS(_12Code_20315);
    _12Code_20315 = _22024;

    /** parser.e:5047		LineTable = {}*/
    RefDS(_22024);
    DeRefDS(_12LineTable_20316);
    _12LineTable_20316 = _22024;

    /** parser.e:5049	end procedure*/
    return;
    ;
}


void _43nested_parser()
{
    object _0, _1, _2;
    

    /** parser.e:5052		real_parser(1)*/
    _43real_parser(1LL);

    /** parser.e:5053	end procedure*/
    return;
    ;
}



// 0x679C6537
