// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _67new_arg_assign()
{
    object _0, _1, _2;
    

    /** execute.e:81		arg_assign += 1*/
    _0 = _67arg_assign_64821;
    if (IS_ATOM_INT(_67arg_assign_64821)) {
        _67arg_assign_64821 = _67arg_assign_64821 + 1;
        if (_67arg_assign_64821 > MAXINT){
            _67arg_assign_64821 = NewDouble((eudouble)_67arg_assign_64821);
        }
    }
    else
    _67arg_assign_64821 = binary_op(PLUS, 1, _67arg_assign_64821);
    DeRef(_0);

    /** execute.e:82		return arg_assign*/
    Ref(_67arg_assign_64821);
    return _67arg_assign_64821;
    ;
}


void _67open_err_file()
{
    object _31907 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:187		err_file = open(err_file_name, "w")*/
    _67err_file_64927 = EOpen(_67err_file_name_64928, _22169, 0LL);

    /** execute.e:188		if err_file = -1 then*/
    if (_67err_file_64927 != -1LL)
    goto L1; // [14] 36

    /** execute.e:189			puts(2, "Can't open " & err_file_name & '\n')*/
    {
        object concat_list[3];

        concat_list[0] = 10LL;
        concat_list[1] = _67err_file_name_64928;
        concat_list[2] = _31906;
        Concat_N((object_ptr)&_31907, concat_list, 3);
    }
    EPuts(2LL, _31907); // DJP 
    DeRefDS(_31907);
    _31907 = NOVALUE;

    /** execute.e:190			abort(1)*/
    UserCleanup(1LL);
L1: 

    /** execute.e:192	end procedure*/
    return;
    ;
}


void _67both_puts(object _s_64941)
{
    object _0, _1, _2;
    

    /** execute.e:198		if screen_err_out then*/
    if (_67screen_err_out_64938 == 0)
    {
        goto L1; // [5] 14
    }
    else{
    }

    /** execute.e:199			puts(2, s)*/
    EPuts(2LL, _s_64941); // DJP 
L1: 

    /** execute.e:201		puts(err_file, s)*/
    EPuts(_67err_file_64927, _s_64941); // DJP 

    /** execute.e:202	end procedure*/
    DeRef(_s_64941);
    return;
    ;
}


void _67both_printf(object _format_64945, object _items_64946)
{
    object _0, _1, _2;
    

    /** execute.e:206		if screen_err_out then*/
    if (_67screen_err_out_64938 == 0)
    {
        goto L1; // [9] 19
    }
    else{
    }

    /** execute.e:207			printf(2, format, items)*/
    EPrintf(2LL, _format_64945, _items_64946);
L1: 

    /** execute.e:209		printf(err_file, format, items)*/
    EPrintf(_67err_file_64927, _format_64945, _items_64946);

    /** execute.e:210	end procedure*/
    DeRefDSi(_format_64945);
    DeRefDS(_items_64946);
    return;
    ;
}


object _67find_line(object _sub_64951, object _pc_64952)
{
    object _linetab_64953 = NOVALUE;
    object _line_64954 = NOVALUE;
    object _gline_64955 = NOVALUE;
    object _31931 = NOVALUE;
    object _31930 = NOVALUE;
    object _31929 = NOVALUE;
    object _31928 = NOVALUE;
    object _31927 = NOVALUE;
    object _31926 = NOVALUE;
    object _31924 = NOVALUE;
    object _31923 = NOVALUE;
    object _31922 = NOVALUE;
    object _31920 = NOVALUE;
    object _31919 = NOVALUE;
    object _31918 = NOVALUE;
    object _31917 = NOVALUE;
    object _31915 = NOVALUE;
    object _31914 = NOVALUE;
    object _31912 = NOVALUE;
    object _31911 = NOVALUE;
    object _31910 = NOVALUE;
    object _31908 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:217		linetab = SymTab[sub][S_LINETAB]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31908 = (object)*(((s1_ptr)_2)->base + _sub_64951);
    DeRef(_linetab_64953);
    _2 = (object)SEQ_PTR(_31908);
    if (!IS_ATOM_INT(_12S_LINETAB_19899)){
        _linetab_64953 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_LINETAB_19899)->dbl));
    }
    else{
        _linetab_64953 = (object)*(((s1_ptr)_2)->base + _12S_LINETAB_19899);
    }
    Ref(_linetab_64953);
    _31908 = NOVALUE;

    /** execute.e:218		line = 1*/
    _line_64954 = 1LL;

    /** execute.e:219		for i = 1 to length(linetab) do*/
    if (IS_SEQUENCE(_linetab_64953)){
            _31910 = SEQ_PTR(_linetab_64953)->length;
    }
    else {
        _31910 = 1;
    }
    {
        object _i_64961;
        _i_64961 = 1LL;
L1: 
        if (_i_64961 > _31910){
            goto L2; // [31] 119
        }

        /** execute.e:220			if linetab[i] >= pc or linetab[i] = -2 then*/
        _2 = (object)SEQ_PTR(_linetab_64953);
        _31911 = (object)*(((s1_ptr)_2)->base + _i_64961);
        if (IS_ATOM_INT(_31911)) {
            _31912 = (_31911 >= _pc_64952);
        }
        else {
            _31912 = binary_op(GREATEREQ, _31911, _pc_64952);
        }
        _31911 = NOVALUE;
        if (IS_ATOM_INT(_31912)) {
            if (_31912 != 0) {
                goto L3; // [48] 65
            }
        }
        else {
            if (DBL_PTR(_31912)->dbl != 0.0) {
                goto L3; // [48] 65
            }
        }
        _2 = (object)SEQ_PTR(_linetab_64953);
        _31914 = (object)*(((s1_ptr)_2)->base + _i_64961);
        if (IS_ATOM_INT(_31914)) {
            _31915 = (_31914 == -2LL);
        }
        else {
            _31915 = binary_op(EQUALS, _31914, -2LL);
        }
        _31914 = NOVALUE;
        if (_31915 == 0) {
            DeRef(_31915);
            _31915 = NOVALUE;
            goto L4; // [61] 112
        }
        else {
            if (!IS_ATOM_INT(_31915) && DBL_PTR(_31915)->dbl == 0.0){
                DeRef(_31915);
                _31915 = NOVALUE;
                goto L4; // [61] 112
            }
            DeRef(_31915);
            _31915 = NOVALUE;
        }
        DeRef(_31915);
        _31915 = NOVALUE;
L3: 

        /** execute.e:221				line = i-1*/
        _line_64954 = _i_64961 - 1LL;

        /** execute.e:222				while line > 1 and linetab[line] = -1 do*/
L5: 
        _31917 = (_line_64954 > 1LL);
        if (_31917 == 0) {
            goto L2; // [80] 119
        }
        _2 = (object)SEQ_PTR(_linetab_64953);
        _31919 = (object)*(((s1_ptr)_2)->base + _line_64954);
        if (IS_ATOM_INT(_31919)) {
            _31920 = (_31919 == -1LL);
        }
        else {
            _31920 = binary_op(EQUALS, _31919, -1LL);
        }
        _31919 = NOVALUE;
        if (_31920 <= 0) {
            if (_31920 == 0) {
                DeRef(_31920);
                _31920 = NOVALUE;
                goto L2; // [93] 119
            }
            else {
                if (!IS_ATOM_INT(_31920) && DBL_PTR(_31920)->dbl == 0.0){
                    DeRef(_31920);
                    _31920 = NOVALUE;
                    goto L2; // [93] 119
                }
                DeRef(_31920);
                _31920 = NOVALUE;
            }
        }
        DeRef(_31920);
        _31920 = NOVALUE;

        /** execute.e:223					line -= 1*/
        _line_64954 = _line_64954 - 1LL;

        /** execute.e:224				end while*/
        goto L5; // [104] 76

        /** execute.e:225				exit*/
        goto L2; // [109] 119
L4: 

        /** execute.e:227		end for*/
        _i_64961 = _i_64961 + 1LL;
        goto L1; // [114] 38
L2: 
        ;
    }

    /** execute.e:228		gline = SymTab[sub][S_FIRSTLINE] + line - 1*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31922 = (object)*(((s1_ptr)_2)->base + _sub_64951);
    _2 = (object)SEQ_PTR(_31922);
    if (!IS_ATOM_INT(_12S_FIRSTLINE_19904)){
        _31923 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FIRSTLINE_19904)->dbl));
    }
    else{
        _31923 = (object)*(((s1_ptr)_2)->base + _12S_FIRSTLINE_19904);
    }
    _31922 = NOVALUE;
    if (IS_ATOM_INT(_31923)) {
        _31924 = _31923 + _line_64954;
        if ((object)((uintptr_t)_31924 + (uintptr_t)HIGH_BITS) >= 0){
            _31924 = NewDouble((eudouble)_31924);
        }
    }
    else {
        _31924 = binary_op(PLUS, _31923, _line_64954);
    }
    _31923 = NOVALUE;
    if (IS_ATOM_INT(_31924)) {
        _gline_64955 = _31924 - 1LL;
    }
    else {
        _gline_64955 = binary_op(MINUS, _31924, 1LL);
    }
    DeRef(_31924);
    _31924 = NOVALUE;
    if (!IS_ATOM_INT(_gline_64955)) {
        _1 = (object)(DBL_PTR(_gline_64955)->dbl);
        DeRefDS(_gline_64955);
        _gline_64955 = _1;
    }

    /** execute.e:229		return {known_files[slist[gline][LOCAL_FILE_NO]], slist[gline][LINE]}*/
    _2 = (object)SEQ_PTR(_12slist_20317);
    _31926 = (object)*(((s1_ptr)_2)->base + _gline_64955);
    _2 = (object)SEQ_PTR(_31926);
    _31927 = (object)*(((s1_ptr)_2)->base + 3LL);
    _31926 = NOVALUE;
    _2 = (object)SEQ_PTR(_13known_files_11317);
    if (!IS_ATOM_INT(_31927)){
        _31928 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31927)->dbl));
    }
    else{
        _31928 = (object)*(((s1_ptr)_2)->base + _31927);
    }
    _2 = (object)SEQ_PTR(_12slist_20317);
    _31929 = (object)*(((s1_ptr)_2)->base + _gline_64955);
    _2 = (object)SEQ_PTR(_31929);
    _31930 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31929 = NOVALUE;
    Ref(_31930);
    Ref(_31928);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _31928;
    ((intptr_t *)_2)[2] = _31930;
    _31931 = MAKE_SEQ(_1);
    _31930 = NOVALUE;
    _31928 = NOVALUE;
    DeRef(_linetab_64953);
    _31927 = NOVALUE;
    DeRef(_31917);
    _31917 = NOVALUE;
    DeRef(_31912);
    _31912 = NOVALUE;
    return _31931;
    ;
}


void _67show_var(object _x_64996)
{
    object _31945 = NOVALUE;
    object _31942 = NOVALUE;
    object _31941 = NOVALUE;
    object _31940 = NOVALUE;
    object _31939 = NOVALUE;
    object _31938 = NOVALUE;
    object _31936 = NOVALUE;
    object _31935 = NOVALUE;
    object _31934 = NOVALUE;
    object _31933 = NOVALUE;
    object _31932 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:235		puts(err_file, "    " & SymTab[x][S_NAME] & " = ")*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31932 = (object)*(((s1_ptr)_2)->base + _x_64996);
    _2 = (object)SEQ_PTR(_31932);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _31933 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _31933 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _31932 = NOVALUE;
    {
        object concat_list[3];

        concat_list[0] = _29498;
        concat_list[1] = _31933;
        concat_list[2] = _24947;
        Concat_N((object_ptr)&_31934, concat_list, 3);
    }
    _31933 = NOVALUE;
    EPuts(_67err_file_64927, _31934); // DJP 
    DeRefDS(_31934);
    _31934 = NOVALUE;

    /** execute.e:236		if equal(val[x], NOVALUE) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _31935 = (object)*(((s1_ptr)_2)->base + _x_64996);
    if (_31935 == _12NOVALUE_20081)
    _31936 = 1;
    else if (IS_ATOM_INT(_31935) && IS_ATOM_INT(_12NOVALUE_20081))
    _31936 = 0;
    else
    _31936 = (compare(_31935, _12NOVALUE_20081) == 0);
    _31935 = NOVALUE;
    if (_31936 == 0)
    {
        _31936 = NOVALUE;
        goto L1; // [42] 55
    }
    else{
        _31936 = NOVALUE;
    }

    /** execute.e:237			puts(err_file, "<no value>")*/
    EPuts(_67err_file_64927, _31937); // DJP 
    goto L2; // [52] 102
L1: 

    /** execute.e:239			pretty_print(err_file, val[x],*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _31938 = (object)*(((s1_ptr)_2)->base + _x_64996);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31939 = (object)*(((s1_ptr)_2)->base + _x_64996);
    _2 = (object)SEQ_PTR(_31939);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _31940 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _31940 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _31939 = NOVALUE;
    if (IS_SEQUENCE(_31940)){
            _31941 = SEQ_PTR(_31940)->length;
    }
    else {
        _31941 = 1;
    }
    _31940 = NOVALUE;
    _31942 = _31941 + 7LL;
    _31941 = NOVALUE;
    _1 = NewS1(9);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    ((intptr_t*)_2)[3] = _31942;
    ((intptr_t*)_2)[4] = 78LL;
    RefDS(_31943);
    ((intptr_t*)_2)[5] = _31943;
    RefDS(_31944);
    ((intptr_t*)_2)[6] = _31944;
    ((intptr_t*)_2)[7] = 32LL;
    ((intptr_t*)_2)[8] = 127LL;
    ((intptr_t*)_2)[9] = 500LL;
    _31945 = MAKE_SEQ(_1);
    _31942 = NOVALUE;
    Ref(_31938);
    _10pretty_print(_67err_file_64927, _31938, _31945);
    _31938 = NOVALUE;
    _31945 = NOVALUE;
L2: 

    /** execute.e:242		puts(err_file, '\n')*/
    EPuts(_67err_file_64927, 10LL); // DJP 

    /** execute.e:243	end procedure*/
    _31940 = NOVALUE;
    return;
    ;
}


void _67save_private_block(object _rtn_idx_65026, object _block_65027)
{
    object _saved_65028 = NOVALUE;
    object _saved_list_65029 = NOVALUE;
    object _eentry_65030 = NOVALUE;
    object _task_65031 = NOVALUE;
    object _spot_65032 = NOVALUE;
    object _tn_65033 = NOVALUE;
    object _31972 = NOVALUE;
    object _31968 = NOVALUE;
    object _31967 = NOVALUE;
    object _31966 = NOVALUE;
    object _31965 = NOVALUE;
    object _31964 = NOVALUE;
    object _31963 = NOVALUE;
    object _31961 = NOVALUE;
    object _31959 = NOVALUE;
    object _31958 = NOVALUE;
    object _31955 = NOVALUE;
    object _31953 = NOVALUE;
    object _31951 = NOVALUE;
    object _31949 = NOVALUE;
    object _31948 = NOVALUE;
    object _31946 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:259		task = SymTab[rtn_idx][S_RESIDENT_TASK]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31946 = (object)*(((s1_ptr)_2)->base + _rtn_idx_65026);
    _2 = (object)SEQ_PTR(_31946);
    _task_65031 = (object)*(((s1_ptr)_2)->base + 25LL);
    if (!IS_ATOM_INT(_task_65031)){
        _task_65031 = (object)DBL_PTR(_task_65031)->dbl;
    }
    _31946 = NOVALUE;

    /** execute.e:261		eentry = {task, tcb[task][TASK_TID], block, 0}*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _31948 = (object)*(((s1_ptr)_2)->base + _task_65031);
    _2 = (object)SEQ_PTR(_31948);
    _31949 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31948 = NOVALUE;
    _0 = _eentry_65030;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _task_65031;
    Ref(_31949);
    ((intptr_t*)_2)[2] = _31949;
    RefDS(_block_65027);
    ((intptr_t*)_2)[3] = _block_65027;
    ((intptr_t*)_2)[4] = 0LL;
    _eentry_65030 = MAKE_SEQ(_1);
    DeRef(_0);
    _31949 = NOVALUE;

    /** execute.e:262		saved = SymTab[rtn_idx][S_SAVED_PRIVATES]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31951 = (object)*(((s1_ptr)_2)->base + _rtn_idx_65026);
    DeRef(_saved_65028);
    _2 = (object)SEQ_PTR(_31951);
    _saved_65028 = (object)*(((s1_ptr)_2)->base + 26LL);
    Ref(_saved_65028);
    _31951 = NOVALUE;

    /** execute.e:264		if length(saved) = 0 then*/
    if (IS_SEQUENCE(_saved_65028)){
            _31953 = SEQ_PTR(_saved_65028)->length;
    }
    else {
        _31953 = 1;
    }
    if (_31953 != 0LL)
    goto L1; // [61] 78

    /** execute.e:266			saved = {1, -- index of first item*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_eentry_65030);
    ((intptr_t*)_2)[1] = _eentry_65030;
    _31955 = MAKE_SEQ(_1);
    DeRefDS(_saved_65028);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1LL;
    ((intptr_t *)_2)[2] = _31955;
    _saved_65028 = MAKE_SEQ(_1);
    _31955 = NOVALUE;
    goto L2; // [75] 219
L1: 

    /** execute.e:270			saved_list = saved[2]*/
    DeRef(_saved_list_65029);
    _2 = (object)SEQ_PTR(_saved_65028);
    _saved_list_65029 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_saved_list_65029);

    /** execute.e:271			spot = 0*/
    _spot_65032 = 0LL;

    /** execute.e:272			for i = 1 to length(saved_list) do*/
    if (IS_SEQUENCE(_saved_list_65029)){
            _31958 = SEQ_PTR(_saved_list_65029)->length;
    }
    else {
        _31958 = 1;
    }
    {
        object _i_65053;
        _i_65053 = 1LL;
L3: 
        if (_i_65053 > _31958){
            goto L4; // [96] 169
        }

        /** execute.e:273				tn = saved_list[i][SP_TASK_NUMBER]*/
        _2 = (object)SEQ_PTR(_saved_list_65029);
        _31959 = (object)*(((s1_ptr)_2)->base + _i_65053);
        _2 = (object)SEQ_PTR(_31959);
        _tn_65033 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (!IS_ATOM_INT(_tn_65033)){
            _tn_65033 = (object)DBL_PTR(_tn_65033)->dbl;
        }
        _31959 = NOVALUE;

        /** execute.e:274				if tn = -1 or*/
        _31961 = (_tn_65033 == -1LL);
        if (_31961 != 0) {
            goto L5; // [121] 152
        }
        _2 = (object)SEQ_PTR(_saved_list_65029);
        _31963 = (object)*(((s1_ptr)_2)->base + _i_65053);
        _2 = (object)SEQ_PTR(_31963);
        _31964 = (object)*(((s1_ptr)_2)->base + 2LL);
        _31963 = NOVALUE;
        _2 = (object)SEQ_PTR(_67tcb_64921);
        _31965 = (object)*(((s1_ptr)_2)->base + _tn_65033);
        _2 = (object)SEQ_PTR(_31965);
        _31966 = (object)*(((s1_ptr)_2)->base + 2LL);
        _31965 = NOVALUE;
        if (IS_ATOM_INT(_31964) && IS_ATOM_INT(_31966)) {
            _31967 = (_31964 != _31966);
        }
        else {
            _31967 = binary_op(NOTEQ, _31964, _31966);
        }
        _31964 = NOVALUE;
        _31966 = NOVALUE;
        if (_31967 == 0) {
            DeRef(_31967);
            _31967 = NOVALUE;
            goto L6; // [148] 162
        }
        else {
            if (!IS_ATOM_INT(_31967) && DBL_PTR(_31967)->dbl == 0.0){
                DeRef(_31967);
                _31967 = NOVALUE;
                goto L6; // [148] 162
            }
            DeRef(_31967);
            _31967 = NOVALUE;
        }
        DeRef(_31967);
        _31967 = NOVALUE;
L5: 

        /** execute.e:277					spot = i*/
        _spot_65032 = _i_65053;

        /** execute.e:278					exit*/
        goto L4; // [159] 169
L6: 

        /** execute.e:280			end for*/
        _i_65053 = _i_65053 + 1LL;
        goto L3; // [164] 103
L4: 
        ;
    }

    /** execute.e:282			eentry[SP_NEXT] = saved[1] -- new eentry points to previous first*/
    _2 = (object)SEQ_PTR(_saved_65028);
    _31968 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_31968);
    _2 = (object)SEQ_PTR(_eentry_65030);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _eentry_65030 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31968;
    if( _1 != _31968 ){
        DeRef(_1);
    }
    _31968 = NOVALUE;

    /** execute.e:283			if spot = 0 then*/
    if (_spot_65032 != 0LL)
    goto L7; // [181] 199

    /** execute.e:285				saved_list = append(saved_list, eentry)*/
    RefDS(_eentry_65030);
    Append(&_saved_list_65029, _saved_list_65029, _eentry_65030);

    /** execute.e:286				spot = length(saved_list)*/
    if (IS_SEQUENCE(_saved_list_65029)){
            _spot_65032 = SEQ_PTR(_saved_list_65029)->length;
    }
    else {
        _spot_65032 = 1;
    }
    goto L8; // [196] 206
L7: 

    /** execute.e:288				saved_list[spot] = eentry*/
    RefDS(_eentry_65030);
    _2 = (object)SEQ_PTR(_saved_list_65029);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_list_65029 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _spot_65032);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _eentry_65030;
    DeRef(_1);
L8: 

    /** execute.e:291			saved[1] = spot -- it becomes the first on the list*/
    _2 = (object)SEQ_PTR(_saved_65028);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_65028 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _spot_65032;
    DeRef(_1);

    /** execute.e:292			saved[2] = saved_list*/
    RefDS(_saved_list_65029);
    _2 = (object)SEQ_PTR(_saved_65028);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_65028 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _saved_list_65029;
    DeRef(_1);
L2: 

    /** execute.e:295		SymTab[rtn_idx][S_SAVED_PRIVATES] = saved*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_rtn_idx_65026 + ((s1_ptr)_2)->base);
    RefDS(_saved_65028);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 26LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _saved_65028;
    DeRef(_1);
    _31972 = NOVALUE;

    /** execute.e:296	end procedure*/
    DeRefDS(_block_65027);
    DeRefDS(_saved_65028);
    DeRef(_saved_list_65029);
    DeRef(_eentry_65030);
    DeRef(_31961);
    _31961 = NOVALUE;
    return;
    ;
}


object _67load_private_block(object _rtn_idx_65078, object _task_65079)
{
    object _saved_65080 = NOVALUE;
    object _saved_list_65081 = NOVALUE;
    object _block_65082 = NOVALUE;
    object _p_65083 = NOVALUE;
    object _prev_p_65084 = NOVALUE;
    object _first_65085 = NOVALUE;
    object _31996 = NOVALUE;
    object _31994 = NOVALUE;
    object _31993 = NOVALUE;
    object _31992 = NOVALUE;
    object _31990 = NOVALUE;
    object _31988 = NOVALUE;
    object _31985 = NOVALUE;
    object _31983 = NOVALUE;
    object _31981 = NOVALUE;
    object _31979 = NOVALUE;
    object _31978 = NOVALUE;
    object _31974 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:304		saved = SymTab[rtn_idx][S_SAVED_PRIVATES]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31974 = (object)*(((s1_ptr)_2)->base + _rtn_idx_65078);
    DeRef(_saved_65080);
    _2 = (object)SEQ_PTR(_31974);
    _saved_65080 = (object)*(((s1_ptr)_2)->base + 26LL);
    Ref(_saved_65080);
    _31974 = NOVALUE;

    /** execute.e:305		first = saved[1]*/
    _2 = (object)SEQ_PTR(_saved_65080);
    _first_65085 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_first_65085))
    _first_65085 = (object)DBL_PTR(_first_65085)->dbl;

    /** execute.e:306		p = first -- won't be 0*/
    _p_65083 = _first_65085;

    /** execute.e:307		prev_p = -1*/
    _prev_p_65084 = -1LL;

    /** execute.e:308		saved_list = saved[2]*/
    DeRef(_saved_list_65081);
    _2 = (object)SEQ_PTR(_saved_65080);
    _saved_list_65081 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_saved_list_65081);

    /** execute.e:309		while TRUE do*/
L1: 
    if (_9TRUE_446 == 0)
    {
        goto L2; // [52] 200
    }
    else{
    }

    /** execute.e:310			if saved_list[p][SP_TASK_NUMBER] = task then*/
    _2 = (object)SEQ_PTR(_saved_list_65081);
    _31978 = (object)*(((s1_ptr)_2)->base + _p_65083);
    _2 = (object)SEQ_PTR(_31978);
    _31979 = (object)*(((s1_ptr)_2)->base + 1LL);
    _31978 = NOVALUE;
    if (binary_op_a(NOTEQ, _31979, _task_65079)){
        _31979 = NOVALUE;
        goto L3; // [65] 178
    }
    _31979 = NOVALUE;

    /** execute.e:312				block = saved_list[p][SP_BLOCK]*/
    _2 = (object)SEQ_PTR(_saved_list_65081);
    _31981 = (object)*(((s1_ptr)_2)->base + _p_65083);
    DeRef(_block_65082);
    _2 = (object)SEQ_PTR(_31981);
    _block_65082 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_block_65082);
    _31981 = NOVALUE;

    /** execute.e:313				saved_list[p][SP_TASK_NUMBER] = -1 -- mark it as deleted*/
    _2 = (object)SEQ_PTR(_saved_list_65081);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_list_65081 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_65083 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1LL;
    DeRef(_1);
    _31983 = NOVALUE;

    /** execute.e:314				saved_list[p][SP_BLOCK] = {}*/
    _2 = (object)SEQ_PTR(_saved_list_65081);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_list_65081 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_65083 + ((s1_ptr)_2)->base);
    RefDS(_22024);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22024;
    DeRef(_1);
    _31985 = NOVALUE;

    /** execute.e:315				if prev_p = -1 then*/
    if (_prev_p_65084 != -1LL)
    goto L4; // [105] 124

    /** execute.e:316					first = saved_list[p][SP_NEXT]*/
    _2 = (object)SEQ_PTR(_saved_list_65081);
    _31988 = (object)*(((s1_ptr)_2)->base + _p_65083);
    _2 = (object)SEQ_PTR(_31988);
    _first_65085 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_first_65085)){
        _first_65085 = (object)DBL_PTR(_first_65085)->dbl;
    }
    _31988 = NOVALUE;
    goto L5; // [121] 144
L4: 

    /** execute.e:318					saved_list[prev_p][SP_NEXT] = saved_list[p][SP_NEXT]*/
    _2 = (object)SEQ_PTR(_saved_list_65081);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_list_65081 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_p_65084 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_saved_list_65081);
    _31992 = (object)*(((s1_ptr)_2)->base + _p_65083);
    _2 = (object)SEQ_PTR(_31992);
    _31993 = (object)*(((s1_ptr)_2)->base + 4LL);
    _31992 = NOVALUE;
    Ref(_31993);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31993;
    if( _1 != _31993 ){
        DeRef(_1);
    }
    _31993 = NOVALUE;
    _31990 = NOVALUE;
L5: 

    /** execute.e:320				saved[1] = first*/
    _2 = (object)SEQ_PTR(_saved_65080);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_65080 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _first_65085;
    DeRef(_1);

    /** execute.e:321				saved[2] = saved_list*/
    RefDS(_saved_list_65081);
    _2 = (object)SEQ_PTR(_saved_65080);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_65080 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _saved_list_65081;
    DeRef(_1);

    /** execute.e:322				SymTab[rtn_idx][S_SAVED_PRIVATES] = saved*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_rtn_idx_65078 + ((s1_ptr)_2)->base);
    RefDS(_saved_65080);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 26LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _saved_65080;
    DeRef(_1);
    _31994 = NOVALUE;

    /** execute.e:323				return block*/
    DeRefDS(_saved_65080);
    DeRefDS(_saved_list_65081);
    return _block_65082;
L3: 

    /** execute.e:325			prev_p = p*/
    _prev_p_65084 = _p_65083;

    /** execute.e:326			p = saved_list[p][SP_NEXT]*/
    _2 = (object)SEQ_PTR(_saved_list_65081);
    _31996 = (object)*(((s1_ptr)_2)->base + _p_65083);
    _2 = (object)SEQ_PTR(_31996);
    _p_65083 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_p_65083)){
        _p_65083 = (object)DBL_PTR(_p_65083)->dbl;
    }
    _31996 = NOVALUE;

    /** execute.e:327		end while*/
    goto L1; // [197] 50
L2: 
    ;
}


void _67restore_privates(object _this_routine_65122)
{
    object _arg_65124 = NOVALUE;
    object _private_block_65125 = NOVALUE;
    object _base_65126 = NOVALUE;
    object _32063 = NOVALUE;
    object _32061 = NOVALUE;
    object _32059 = NOVALUE;
    object _32056 = NOVALUE;
    object _32054 = NOVALUE;
    object _32052 = NOVALUE;
    object _32050 = NOVALUE;
    object _32049 = NOVALUE;
    object _32048 = NOVALUE;
    object _32047 = NOVALUE;
    object _32046 = NOVALUE;
    object _32045 = NOVALUE;
    object _32044 = NOVALUE;
    object _32043 = NOVALUE;
    object _32042 = NOVALUE;
    object _32041 = NOVALUE;
    object _32040 = NOVALUE;
    object _32039 = NOVALUE;
    object _32038 = NOVALUE;
    object _32037 = NOVALUE;
    object _32036 = NOVALUE;
    object _32034 = NOVALUE;
    object _32031 = NOVALUE;
    object _32029 = NOVALUE;
    object _32026 = NOVALUE;
    object _32024 = NOVALUE;
    object _32022 = NOVALUE;
    object _32020 = NOVALUE;
    object _32019 = NOVALUE;
    object _32018 = NOVALUE;
    object _32017 = NOVALUE;
    object _32016 = NOVALUE;
    object _32015 = NOVALUE;
    object _32014 = NOVALUE;
    object _32013 = NOVALUE;
    object _32012 = NOVALUE;
    object _32011 = NOVALUE;
    object _32010 = NOVALUE;
    object _32009 = NOVALUE;
    object _32008 = NOVALUE;
    object _32007 = NOVALUE;
    object _32006 = NOVALUE;
    object _32004 = NOVALUE;
    object _32002 = NOVALUE;
    object _32001 = NOVALUE;
    object _31999 = NOVALUE;
    object _31998 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_this_routine_65122)) {
        _1 = (object)(DBL_PTR(_this_routine_65122)->dbl);
        DeRefDS(_this_routine_65122);
        _this_routine_65122 = _1;
    }

    /** execute.e:334		sequence private_block*/

    /** execute.e:335		integer base*/

    /** execute.e:337		if SymTab[this_routine][S_RESIDENT_TASK] != current_task then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31998 = (object)*(((s1_ptr)_2)->base + _this_routine_65122);
    _2 = (object)SEQ_PTR(_31998);
    _31999 = (object)*(((s1_ptr)_2)->base + 25LL);
    _31998 = NOVALUE;
    if (binary_op_a(EQUALS, _31999, _67current_task_64894)){
        _31999 = NOVALUE;
        goto L1; // [23] 535
    }
    _31999 = NOVALUE;

    /** execute.e:340			if SymTab[this_routine][S_RESIDENT_TASK] != 0 then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32001 = (object)*(((s1_ptr)_2)->base + _this_routine_65122);
    _2 = (object)SEQ_PTR(_32001);
    _32002 = (object)*(((s1_ptr)_2)->base + 25LL);
    _32001 = NOVALUE;
    if (binary_op_a(EQUALS, _32002, 0LL)){
        _32002 = NOVALUE;
        goto L2; // [41] 274
    }
    _32002 = NOVALUE;

    /** execute.e:346				arg = SymTab[this_routine][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32004 = (object)*(((s1_ptr)_2)->base + _this_routine_65122);
    _2 = (object)SEQ_PTR(_32004);
    _arg_65124 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_arg_65124)){
        _arg_65124 = (object)DBL_PTR(_arg_65124)->dbl;
    }
    _32004 = NOVALUE;

    /** execute.e:347				private_block = {}*/
    RefDS(_22024);
    DeRef(_private_block_65125);
    _private_block_65125 = _22024;

    /** execute.e:349				while arg != 0 */
L3: 
    _32006 = (_arg_65124 != 0LL);
    if (_32006 == 0) {
        goto L4; // [77] 209
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32008 = (object)*(((s1_ptr)_2)->base + _arg_65124);
    _2 = (object)SEQ_PTR(_32008);
    _32009 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32008 = NOVALUE;
    if (IS_ATOM_INT(_32009)) {
        _32010 = (_32009 <= 3LL);
    }
    else {
        _32010 = binary_op(LESSEQ, _32009, 3LL);
    }
    _32009 = NOVALUE;
    if (IS_ATOM_INT(_32010)) {
        if (_32010 != 0) {
            DeRef(_32011);
            _32011 = 1;
            goto L5; // [99] 125
        }
    }
    else {
        if (DBL_PTR(_32010)->dbl != 0.0) {
            DeRef(_32011);
            _32011 = 1;
            goto L5; // [99] 125
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32012 = (object)*(((s1_ptr)_2)->base + _arg_65124);
    _2 = (object)SEQ_PTR(_32012);
    _32013 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32012 = NOVALUE;
    if (IS_ATOM_INT(_32013)) {
        _32014 = (_32013 == 2LL);
    }
    else {
        _32014 = binary_op(EQUALS, _32013, 2LL);
    }
    _32013 = NOVALUE;
    DeRef(_32011);
    if (IS_ATOM_INT(_32014))
    _32011 = (_32014 != 0);
    else
    _32011 = DBL_PTR(_32014)->dbl != 0.0;
L5: 
    if (_32011 != 0) {
        DeRef(_32015);
        _32015 = 1;
        goto L6; // [125] 151
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32016 = (object)*(((s1_ptr)_2)->base + _arg_65124);
    _2 = (object)SEQ_PTR(_32016);
    _32017 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32016 = NOVALUE;
    if (IS_ATOM_INT(_32017)) {
        _32018 = (_32017 == 9LL);
    }
    else {
        _32018 = binary_op(EQUALS, _32017, 9LL);
    }
    _32017 = NOVALUE;
    if (IS_ATOM_INT(_32018))
    _32015 = (_32018 != 0);
    else
    _32015 = DBL_PTR(_32018)->dbl != 0.0;
L6: 
    if (_32015 == 0)
    {
        _32015 = NOVALUE;
        goto L4; // [152] 209
    }
    else{
        _32015 = NOVALUE;
    }

    /** execute.e:354					if SymTab[arg][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32019 = (object)*(((s1_ptr)_2)->base + _arg_65124);
    _2 = (object)SEQ_PTR(_32019);
    _32020 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32019 = NOVALUE;
    if (binary_op_a(EQUALS, _32020, 9LL)){
        _32020 = NOVALUE;
        goto L7; // [171] 188
    }
    _32020 = NOVALUE;

    /** execute.e:355						private_block = append(private_block, val[arg])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _32022 = (object)*(((s1_ptr)_2)->base + _arg_65124);
    Ref(_32022);
    Append(&_private_block_65125, _private_block_65125, _32022);
    _32022 = NOVALUE;
L7: 

    /** execute.e:357					arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32024 = (object)*(((s1_ptr)_2)->base + _arg_65124);
    _2 = (object)SEQ_PTR(_32024);
    _arg_65124 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_arg_65124)){
        _arg_65124 = (object)DBL_PTR(_arg_65124)->dbl;
    }
    _32024 = NOVALUE;

    /** execute.e:358				end while*/
    goto L3; // [206] 73
L4: 

    /** execute.e:361				arg = SymTab[this_routine][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32026 = (object)*(((s1_ptr)_2)->base + _this_routine_65122);
    _2 = (object)SEQ_PTR(_32026);
    if (!IS_ATOM_INT(_12S_TEMPS_19909)){
        _arg_65124 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TEMPS_19909)->dbl));
    }
    else{
        _arg_65124 = (object)*(((s1_ptr)_2)->base + _12S_TEMPS_19909);
    }
    if (!IS_ATOM_INT(_arg_65124)){
        _arg_65124 = (object)DBL_PTR(_arg_65124)->dbl;
    }
    _32026 = NOVALUE;

    /** execute.e:362				while arg != 0 do*/
L8: 
    if (_arg_65124 == 0LL)
    goto L9; // [230] 267

    /** execute.e:363					private_block = append(private_block, val[arg])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _32029 = (object)*(((s1_ptr)_2)->base + _arg_65124);
    Ref(_32029);
    Append(&_private_block_65125, _private_block_65125, _32029);
    _32029 = NOVALUE;

    /** execute.e:364					arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32031 = (object)*(((s1_ptr)_2)->base + _arg_65124);
    _2 = (object)SEQ_PTR(_32031);
    _arg_65124 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_arg_65124)){
        _arg_65124 = (object)DBL_PTR(_arg_65124)->dbl;
    }
    _32031 = NOVALUE;

    /** execute.e:365				end while*/
    goto L8; // [264] 230
L9: 

    /** execute.e:367				save_private_block(this_routine, private_block)*/
    RefDS(_private_block_65125);
    _67save_private_block(_this_routine_65122, _private_block_65125);
L2: 

    /** execute.e:371			private_block = load_private_block(this_routine, current_task)*/
    _0 = _private_block_65125;
    _private_block_65125 = _67load_private_block(_this_routine_65122, _67current_task_64894);
    DeRef(_0);

    /** execute.e:374			base = 1*/
    _base_65126 = 1LL;

    /** execute.e:375			arg = SymTab[this_routine][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32034 = (object)*(((s1_ptr)_2)->base + _this_routine_65122);
    _2 = (object)SEQ_PTR(_32034);
    _arg_65124 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_arg_65124)){
        _arg_65124 = (object)DBL_PTR(_arg_65124)->dbl;
    }
    _32034 = NOVALUE;

    /** execute.e:376			while arg != 0 */
LA: 
    _32036 = (_arg_65124 != 0LL);
    if (_32036 == 0) {
        goto LB; // [315] 453
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32038 = (object)*(((s1_ptr)_2)->base + _arg_65124);
    _2 = (object)SEQ_PTR(_32038);
    _32039 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32038 = NOVALUE;
    if (IS_ATOM_INT(_32039)) {
        _32040 = (_32039 <= 3LL);
    }
    else {
        _32040 = binary_op(LESSEQ, _32039, 3LL);
    }
    _32039 = NOVALUE;
    if (IS_ATOM_INT(_32040)) {
        if (_32040 != 0) {
            DeRef(_32041);
            _32041 = 1;
            goto LC; // [337] 363
        }
    }
    else {
        if (DBL_PTR(_32040)->dbl != 0.0) {
            DeRef(_32041);
            _32041 = 1;
            goto LC; // [337] 363
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32042 = (object)*(((s1_ptr)_2)->base + _arg_65124);
    _2 = (object)SEQ_PTR(_32042);
    _32043 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32042 = NOVALUE;
    if (IS_ATOM_INT(_32043)) {
        _32044 = (_32043 == 2LL);
    }
    else {
        _32044 = binary_op(EQUALS, _32043, 2LL);
    }
    _32043 = NOVALUE;
    DeRef(_32041);
    if (IS_ATOM_INT(_32044))
    _32041 = (_32044 != 0);
    else
    _32041 = DBL_PTR(_32044)->dbl != 0.0;
LC: 
    if (_32041 != 0) {
        DeRef(_32045);
        _32045 = 1;
        goto LD; // [363] 389
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32046 = (object)*(((s1_ptr)_2)->base + _arg_65124);
    _2 = (object)SEQ_PTR(_32046);
    _32047 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32046 = NOVALUE;
    if (IS_ATOM_INT(_32047)) {
        _32048 = (_32047 == 9LL);
    }
    else {
        _32048 = binary_op(EQUALS, _32047, 9LL);
    }
    _32047 = NOVALUE;
    if (IS_ATOM_INT(_32048))
    _32045 = (_32048 != 0);
    else
    _32045 = DBL_PTR(_32048)->dbl != 0.0;
LD: 
    if (_32045 == 0)
    {
        _32045 = NOVALUE;
        goto LB; // [390] 453
    }
    else{
        _32045 = NOVALUE;
    }

    /** execute.e:381				if SymTab[arg][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32049 = (object)*(((s1_ptr)_2)->base + _arg_65124);
    _2 = (object)SEQ_PTR(_32049);
    _32050 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32049 = NOVALUE;
    if (binary_op_a(EQUALS, _32050, 9LL)){
        _32050 = NOVALUE;
        goto LE; // [409] 432
    }
    _32050 = NOVALUE;

    /** execute.e:382					val[arg] = private_block[base]*/
    _2 = (object)SEQ_PTR(_private_block_65125);
    _32052 = (object)*(((s1_ptr)_2)->base + _base_65126);
    Ref(_32052);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _arg_65124);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32052;
    if( _1 != _32052 ){
        DeRef(_1);
    }
    _32052 = NOVALUE;

    /** execute.e:383					base += 1*/
    _base_65126 = _base_65126 + 1;
LE: 

    /** execute.e:385				arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32054 = (object)*(((s1_ptr)_2)->base + _arg_65124);
    _2 = (object)SEQ_PTR(_32054);
    _arg_65124 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_arg_65124)){
        _arg_65124 = (object)DBL_PTR(_arg_65124)->dbl;
    }
    _32054 = NOVALUE;

    /** execute.e:386			end while*/
    goto LA; // [450] 311
LB: 

    /** execute.e:389			arg = SymTab[this_routine][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32056 = (object)*(((s1_ptr)_2)->base + _this_routine_65122);
    _2 = (object)SEQ_PTR(_32056);
    if (!IS_ATOM_INT(_12S_TEMPS_19909)){
        _arg_65124 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TEMPS_19909)->dbl));
    }
    else{
        _arg_65124 = (object)*(((s1_ptr)_2)->base + _12S_TEMPS_19909);
    }
    if (!IS_ATOM_INT(_arg_65124)){
        _arg_65124 = (object)DBL_PTR(_arg_65124)->dbl;
    }
    _32056 = NOVALUE;

    /** execute.e:390			while arg != 0 do*/
LF: 
    if (_arg_65124 == 0LL)
    goto L10; // [474] 517

    /** execute.e:391				val[arg] = private_block[base]*/
    _2 = (object)SEQ_PTR(_private_block_65125);
    _32059 = (object)*(((s1_ptr)_2)->base + _base_65126);
    Ref(_32059);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _arg_65124);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32059;
    if( _1 != _32059 ){
        DeRef(_1);
    }
    _32059 = NOVALUE;

    /** execute.e:392				base += 1*/
    _base_65126 = _base_65126 + 1;

    /** execute.e:393				arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32061 = (object)*(((s1_ptr)_2)->base + _arg_65124);
    _2 = (object)SEQ_PTR(_32061);
    _arg_65124 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_arg_65124)){
        _arg_65124 = (object)DBL_PTR(_arg_65124)->dbl;
    }
    _32061 = NOVALUE;

    /** execute.e:394			end while*/
    goto LF; // [514] 474
L10: 

    /** execute.e:396			SymTab[this_routine][S_RESIDENT_TASK] = current_task*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_this_routine_65122 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67current_task_64894;
    DeRef(_1);
    _32063 = NOVALUE;
L1: 

    /** execute.e:398	end procedure*/
    DeRef(_private_block_65125);
    DeRef(_32014);
    _32014 = NOVALUE;
    DeRef(_32048);
    _32048 = NOVALUE;
    DeRef(_32006);
    _32006 = NOVALUE;
    DeRef(_32036);
    _32036 = NOVALUE;
    DeRef(_32018);
    _32018 = NOVALUE;
    DeRef(_32010);
    _32010 = NOVALUE;
    DeRef(_32044);
    _32044 = NOVALUE;
    DeRef(_32040);
    _32040 = NOVALUE;
    return;
    ;
}


object _67is_slice(object _op_65271)
{
    object _32067 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:426		return find( op, SLICE_OPS )*/
    _32067 = find_from(_op_65271, _67SLICE_OPS_65262, 1LL);
    return _32067;
    ;
}


object _67is_subs(object _op_65275)
{
    object _32069 = NOVALUE;
    object _32068 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:430		if find( op, SUB_OPS ) then*/
    _32068 = find_from(_op_65275, _67SUB_OPS_65248, 1LL);
    if (_32068 == 0)
    {
        _32068 = NOVALUE;
        goto L1; // [12] 24
    }
    else{
        _32068 = NOVALUE;
    }

    /** execute.e:431			return 1*/
    return 1LL;
    goto L2; // [21] 35
L1: 

    /** execute.e:433			return is_slice( op )*/
    _32069 = _67is_slice(_op_65275);
    return _32069;
L2: 
    ;
}


object _67subs_opsize(object _op_65282)
{
    object _32101 = NOVALUE;
    object _32099 = NOVALUE;
    object _32098 = NOVALUE;
    object _32097 = NOVALUE;
    object _32096 = NOVALUE;
    object _32095 = NOVALUE;
    object _32094 = NOVALUE;
    object _32093 = NOVALUE;
    object _32092 = NOVALUE;
    object _32091 = NOVALUE;
    object _32090 = NOVALUE;
    object _32089 = NOVALUE;
    object _32088 = NOVALUE;
    object _32087 = NOVALUE;
    object _32086 = NOVALUE;
    object _32085 = NOVALUE;
    object _32084 = NOVALUE;
    object _32082 = NOVALUE;
    object _32081 = NOVALUE;
    object _32080 = NOVALUE;
    object _32079 = NOVALUE;
    object _32078 = NOVALUE;
    object _32077 = NOVALUE;
    object _32076 = NOVALUE;
    object _32075 = NOVALUE;
    object _32074 = NOVALUE;
    object _32073 = NOVALUE;
    object _32072 = NOVALUE;
    object _32071 = NOVALUE;
    object _32070 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:438		if op = RHS_SUBS or op = RHS_SUBS_CHECK or op = PASSIGN_SUBS or op = ASSIGN_SUBS*/
    _32070 = (_op_65282 == 25LL);
    if (_32070 != 0) {
        _32071 = 1;
        goto L1; // [11] 25
    }
    _32072 = (_op_65282 == 92LL);
    _32071 = (_32072 != 0);
L1: 
    if (_32071 != 0) {
        _32073 = 1;
        goto L2; // [25] 39
    }
    _32074 = (_op_65282 == 162LL);
    _32073 = (_32074 != 0);
L2: 
    if (_32073 != 0) {
        _32075 = 1;
        goto L3; // [39] 53
    }
    _32076 = (_op_65282 == 16LL);
    _32075 = (_32076 != 0);
L3: 
    if (_32075 != 0) {
        _32077 = 1;
        goto L4; // [53] 67
    }
    _32078 = (_op_65282 == 149LL);
    _32077 = (_32078 != 0);
L4: 
    if (_32077 != 0) {
        _32079 = 1;
        goto L5; // [67] 81
    }
    _32080 = (_op_65282 == 84LL);
    _32079 = (_32080 != 0);
L5: 
    if (_32079 != 0) {
        _32081 = 1;
        goto L6; // [81] 95
    }
    _32082 = (_op_65282 == 118LL);
    _32081 = (_32082 != 0);
L6: 
    if (_32081 != 0) {
        goto L7; // [95] 110
    }
    _32084 = (_op_65282 == 164LL);
    if (_32084 == 0)
    {
        DeRef(_32084);
        _32084 = NOVALUE;
        goto L8; // [106] 119
    }
    else{
        DeRef(_32084);
        _32084 = NOVALUE;
    }
L7: 

    /** execute.e:442			return 4*/
    DeRef(_32070);
    _32070 = NOVALUE;
    DeRef(_32074);
    _32074 = NOVALUE;
    DeRef(_32076);
    _32076 = NOVALUE;
    DeRef(_32082);
    _32082 = NOVALUE;
    DeRef(_32078);
    _32078 = NOVALUE;
    DeRef(_32072);
    _32072 = NOVALUE;
    DeRef(_32080);
    _32080 = NOVALUE;
    return 4LL;
    goto L9; // [116] 256
L8: 

    /** execute.e:443		elsif op = LHS_SUBS1 or op = LHS_SUBS or op = LHS_SUBS1_COPY*/
    _32085 = (_op_65282 == 161LL);
    if (_32085 != 0) {
        _32086 = 1;
        goto LA; // [127] 141
    }
    _32087 = (_op_65282 == 95LL);
    _32086 = (_32087 != 0);
LA: 
    if (_32086 != 0) {
        _32088 = 1;
        goto LB; // [141] 155
    }
    _32089 = (_op_65282 == 166LL);
    _32088 = (_32089 != 0);
LB: 
    if (_32088 != 0) {
        _32090 = 1;
        goto LC; // [155] 169
    }
    _32091 = (_op_65282 == 45LL);
    _32090 = (_32091 != 0);
LC: 
    if (_32090 != 0) {
        _32092 = 1;
        goto LD; // [169] 183
    }
    _32093 = (_op_65282 == 163LL);
    _32092 = (_32093 != 0);
LD: 
    if (_32092 != 0) {
        _32094 = 1;
        goto LE; // [183] 197
    }
    _32095 = (_op_65282 == 46LL);
    _32094 = (_32095 != 0);
LE: 
    if (_32094 != 0) {
        _32096 = 1;
        goto LF; // [197] 211
    }
    _32097 = (_op_65282 == 150LL);
    _32096 = (_32097 != 0);
LF: 
    if (_32096 != 0) {
        _32098 = 1;
        goto L10; // [211] 225
    }
    _32099 = (_op_65282 == 165LL);
    _32098 = (_32099 != 0);
L10: 
    if (_32098 != 0) {
        goto L11; // [225] 240
    }
    _32101 = (_op_65282 == 163LL);
    if (_32101 == 0)
    {
        DeRef(_32101);
        _32101 = NOVALUE;
        goto L12; // [236] 249
    }
    else{
        DeRef(_32101);
        _32101 = NOVALUE;
    }
L11: 

    /** execute.e:448			return 5*/
    DeRef(_32099);
    _32099 = NOVALUE;
    DeRef(_32091);
    _32091 = NOVALUE;
    DeRef(_32070);
    _32070 = NOVALUE;
    DeRef(_32074);
    _32074 = NOVALUE;
    DeRef(_32087);
    _32087 = NOVALUE;
    DeRef(_32076);
    _32076 = NOVALUE;
    DeRef(_32082);
    _32082 = NOVALUE;
    DeRef(_32097);
    _32097 = NOVALUE;
    DeRef(_32089);
    _32089 = NOVALUE;
    DeRef(_32078);
    _32078 = NOVALUE;
    DeRef(_32095);
    _32095 = NOVALUE;
    DeRef(_32093);
    _32093 = NOVALUE;
    DeRef(_32072);
    _32072 = NOVALUE;
    DeRef(_32085);
    _32085 = NOVALUE;
    DeRef(_32080);
    _32080 = NOVALUE;
    return 5LL;
    goto L9; // [246] 256
L12: 

    /** execute.e:450			return 1*/
    DeRef(_32099);
    _32099 = NOVALUE;
    DeRef(_32091);
    _32091 = NOVALUE;
    DeRef(_32070);
    _32070 = NOVALUE;
    DeRef(_32074);
    _32074 = NOVALUE;
    DeRef(_32087);
    _32087 = NOVALUE;
    DeRef(_32076);
    _32076 = NOVALUE;
    DeRef(_32082);
    _32082 = NOVALUE;
    DeRef(_32097);
    _32097 = NOVALUE;
    DeRef(_32089);
    _32089 = NOVALUE;
    DeRef(_32078);
    _32078 = NOVALUE;
    DeRef(_32095);
    _32095 = NOVALUE;
    DeRef(_32093);
    _32093 = NOVALUE;
    DeRef(_32072);
    _32072 = NOVALUE;
    DeRef(_32085);
    _32085 = NOVALUE;
    DeRef(_32080);
    _32080 = NOVALUE;
    return 1LL;
L9: 
    ;
}


object _67sub_dest_offset(object _op_65337)
{
    object _offset_65338 = NOVALUE;
    object _32106 = NOVALUE;
    object _32104 = NOVALUE;
    object _32102 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:455		integer offset = subs_opsize( op ) - 1*/
    _32102 = _67subs_opsize(_op_65337);
    if (IS_ATOM_INT(_32102)) {
        _offset_65338 = _32102 - 1LL;
    }
    else {
        _offset_65338 = binary_op(MINUS, _32102, 1LL);
    }
    DeRef(_32102);
    _32102 = NOVALUE;
    if (!IS_ATOM_INT(_offset_65338)) {
        _1 = (object)(DBL_PTR(_offset_65338)->dbl);
        DeRefDS(_offset_65338);
        _offset_65338 = _1;
    }

    /** execute.e:456		if op = LHS_SUBS1_COPY or op = LHS_SUBS1 then*/
    _32104 = (_op_65337 == 166LL);
    if (_32104 != 0) {
        goto L1; // [23] 38
    }
    _32106 = (_op_65337 == 161LL);
    if (_32106 == 0)
    {
        DeRef(_32106);
        _32106 = NOVALUE;
        goto L2; // [34] 45
    }
    else{
        DeRef(_32106);
        _32106 = NOVALUE;
    }
L1: 

    /** execute.e:457			offset -= 1*/
    _offset_65338 = _offset_65338 - 1LL;
L2: 

    /** execute.e:459		return offset*/
    DeRef(_32104);
    _32104 = NOVALUE;
    return _offset_65338;
    ;
}


void _67LookBackForSubscriptSymbol(object _pc_65350, object _sublevel_65351, object _has_slice_65352)
{
    object _op_65353 = NOVALUE;
    object _start_pc_65356 = NOVALUE;
    object _sym_65358 = NOVALUE;
    object _subtext_65374 = NOVALUE;
    object _32147 = NOVALUE;
    object _32146 = NOVALUE;
    object _32145 = NOVALUE;
    object _32144 = NOVALUE;
    object _32143 = NOVALUE;
    object _32142 = NOVALUE;
    object _32141 = NOVALUE;
    object _32140 = NOVALUE;
    object _32139 = NOVALUE;
    object _32136 = NOVALUE;
    object _32135 = NOVALUE;
    object _32134 = NOVALUE;
    object _32133 = NOVALUE;
    object _32132 = NOVALUE;
    object _32131 = NOVALUE;
    object _32130 = NOVALUE;
    object _32129 = NOVALUE;
    object _32128 = NOVALUE;
    object _32127 = NOVALUE;
    object _32126 = NOVALUE;
    object _32125 = NOVALUE;
    object _32124 = NOVALUE;
    object _32123 = NOVALUE;
    object _32122 = NOVALUE;
    object _32118 = NOVALUE;
    object _32117 = NOVALUE;
    object _32116 = NOVALUE;
    object _32115 = NOVALUE;
    object _32114 = NOVALUE;
    object _32113 = NOVALUE;
    object _32111 = NOVALUE;
    object _32109 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sublevel_65351)) {
        _1 = (object)(DBL_PTR(_sublevel_65351)->dbl);
        DeRefDS(_sublevel_65351);
        _sublevel_65351 = _1;
    }

    /** execute.e:464		integer op = Code[pc]*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    _op_65353 = (object)*(((s1_ptr)_2)->base + _pc_65350);
    if (!IS_ATOM_INT(_op_65353)){
        _op_65353 = (object)DBL_PTR(_op_65353)->dbl;
    }

    /** execute.e:465		integer start_pc = pc*/
    _start_pc_65356 = _pc_65350;

    /** execute.e:466		symtab_pointer sym = Code[pc+1]*/
    _32109 = _pc_65350 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _sym_65358 = (object)*(((s1_ptr)_2)->base + _32109);
    if (!IS_ATOM_INT(_sym_65358)){
        _sym_65358 = (object)DBL_PTR(_sym_65358)->dbl;
    }

    /** execute.e:467		has_slice = has_slice or is_slice( op )*/
    _32111 = _67is_slice(_op_65353);
    if (IS_ATOM_INT(_32111)) {
        _has_slice_65352 = (_has_slice_65352 != 0 || _32111 != 0);
    }
    else {
        _has_slice_65352 = binary_op(OR, _has_slice_65352, _32111);
    }
    DeRef(_32111);
    _32111 = NOVALUE;
    if (!IS_ATOM_INT(_has_slice_65352)) {
        _1 = (object)(DBL_PTR(_has_slice_65352)->dbl);
        DeRefDS(_has_slice_65352);
        _has_slice_65352 = _1;
    }

    /** execute.e:469		if length( SymTab[sym] ) >= S_NAME and length( sym_name( sym ) ) then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32113 = (object)*(((s1_ptr)_2)->base + _sym_65358);
    if (IS_SEQUENCE(_32113)){
            _32114 = SEQ_PTR(_32113)->length;
    }
    else {
        _32114 = 1;
    }
    _32113 = NOVALUE;
    if (IS_ATOM_INT(_12S_NAME_19864)) {
        _32115 = (_32114 >= _12S_NAME_19864);
    }
    else {
        _32115 = binary_op(GREATEREQ, _32114, _12S_NAME_19864);
    }
    _32114 = NOVALUE;
    if (IS_ATOM_INT(_32115)) {
        if (_32115 == 0) {
            goto L1; // [65] 204
        }
    }
    else {
        if (DBL_PTR(_32115)->dbl == 0.0) {
            goto L1; // [65] 204
        }
    }
    _32117 = _53sym_name(_sym_65358);
    if (IS_SEQUENCE(_32117)){
            _32118 = SEQ_PTR(_32117)->length;
    }
    else {
        _32118 = 1;
    }
    DeRef(_32117);
    _32117 = NOVALUE;
    if (_32118 == 0)
    {
        _32118 = NOVALUE;
        goto L1; // [77] 204
    }
    else{
        _32118 = NOVALUE;
    }

    /** execute.e:470			sequence subtext*/

    /** execute.e:471			if has_slice then*/
    if (_has_slice_65352 == 0)
    {
        goto L2; // [84] 97
    }
    else{
    }

    /** execute.e:472				subtext = "slice/subscript"*/
    RefDS(_32119);
    DeRefi(_subtext_65374);
    _subtext_65374 = _32119;
    goto L3; // [94] 105
L2: 

    /** execute.e:474				subtext = "subscript"*/
    RefDS(_32120);
    DeRefi(_subtext_65374);
    _subtext_65374 = _32120;
L3: 

    /** execute.e:476			both_printf(" - in %s #%d of '%s'", { subtext, sublevel, sym_name( sym ) } )*/
    _32122 = _53sym_name(_sym_65358);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_subtext_65374);
    ((intptr_t*)_2)[1] = _subtext_65374;
    ((intptr_t*)_2)[2] = _sublevel_65351;
    ((intptr_t*)_2)[3] = _32122;
    _32123 = MAKE_SEQ(_1);
    _32122 = NOVALUE;
    RefDS(_32121);
    _67both_printf(_32121, _32123);
    _32123 = NOVALUE;
    DeRefDSi(_subtext_65374);
    _subtext_65374 = NOVALUE;
    goto L4; // [125] 276

    /** execute.e:480			while pc > 1*/
    goto L1; // [130] 204
L5: 
    _32124 = (_pc_65350 > 1LL);
    if (_32124 == 0) {
        DeRef(_32125);
        _32125 = 0;
        goto L6; // [137] 198
    }
    _32126 = _67is_subs(_op_65353);
    if (IS_ATOM_INT(_32126)) {
        if (_32126 == 0) {
            DeRef(_32127);
            _32127 = 0;
            goto L7; // [145] 171
        }
    }
    else {
        if (DBL_PTR(_32126)->dbl == 0.0) {
            DeRef(_32127);
            _32127 = 0;
            goto L7; // [145] 171
        }
    }
    _32128 = _67sub_dest_offset(_op_65353);
    if (IS_ATOM_INT(_32128)) {
        _32129 = _pc_65350 + _32128;
    }
    else {
        _32129 = binary_op(PLUS, _pc_65350, _32128);
    }
    DeRef(_32128);
    _32128 = NOVALUE;
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!IS_ATOM_INT(_32129)){
        _32130 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32129)->dbl));
    }
    else{
        _32130 = (object)*(((s1_ptr)_2)->base + _32129);
    }
    if (IS_ATOM_INT(_32130)) {
        _32131 = (_32130 == _sym_65358);
    }
    else {
        _32131 = binary_op(EQUALS, _32130, _sym_65358);
    }
    _32130 = NOVALUE;
    DeRef(_32127);
    if (IS_ATOM_INT(_32131))
    _32127 = (_32131 != 0);
    else
    _32127 = DBL_PTR(_32131)->dbl != 0.0;
L7: 
    _32132 = (_32127 == 0);
    _32127 = NOVALUE;
    if (_32132 != 0) {
        _32133 = 1;
        goto L8; // [174] 194
    }
    _32134 = _67subs_opsize(_op_65353);
    if (IS_ATOM_INT(_32134)) {
        _32135 = _pc_65350 + _32134;
        if ((object)((uintptr_t)_32135 + (uintptr_t)HIGH_BITS) >= 0){
            _32135 = NewDouble((eudouble)_32135);
        }
    }
    else {
        _32135 = binary_op(PLUS, _pc_65350, _32134);
    }
    DeRef(_32134);
    _32134 = NOVALUE;
    if (IS_ATOM_INT(_32135)) {
        _32136 = (_start_pc_65356 <= _32135);
    }
    else {
        _32136 = binary_op(LESSEQ, _start_pc_65356, _32135);
    }
    DeRef(_32135);
    _32135 = NOVALUE;
    if (IS_ATOM_INT(_32136))
    _32133 = (_32136 != 0);
    else
    _32133 = DBL_PTR(_32136)->dbl != 0.0;
L8: 
    DeRef(_32125);
    _32125 = (_32133 != 0);
L6: 
    if (_32125 == 0)
    {
        _32125 = NOVALUE;
        goto L9; // [198] 225
    }
    else{
        _32125 = NOVALUE;
    }

    /** execute.e:487			entry*/
L1: 

    /** execute.e:488				pc -= 1*/
    _pc_65350 = _pc_65350 - 1LL;

    /** execute.e:489				op = Code[pc]*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    _op_65353 = (object)*(((s1_ptr)_2)->base + _pc_65350);
    if (!IS_ATOM_INT(_op_65353)){
        _op_65353 = (object)DBL_PTR(_op_65353)->dbl;
    }

    /** execute.e:490			end while*/
    goto L5; // [222] 133
L9: 

    /** execute.e:492			if is_subs( op ) and (Code[pc + sub_dest_offset( op )] = sym) then*/
    _32139 = _67is_subs(_op_65353);
    if (IS_ATOM_INT(_32139)) {
        if (_32139 == 0) {
            goto LA; // [231] 275
        }
    }
    else {
        if (DBL_PTR(_32139)->dbl == 0.0) {
            goto LA; // [231] 275
        }
    }
    _32141 = _67sub_dest_offset(_op_65353);
    if (IS_ATOM_INT(_32141)) {
        _32142 = _pc_65350 + _32141;
    }
    else {
        _32142 = binary_op(PLUS, _pc_65350, _32141);
    }
    DeRef(_32141);
    _32141 = NOVALUE;
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!IS_ATOM_INT(_32142)){
        _32143 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32142)->dbl));
    }
    else{
        _32143 = (object)*(((s1_ptr)_2)->base + _32142);
    }
    if (IS_ATOM_INT(_32143)) {
        _32144 = (_32143 == _sym_65358);
    }
    else {
        _32144 = binary_op(EQUALS, _32143, _sym_65358);
    }
    _32143 = NOVALUE;
    if (_32144 == 0) {
        DeRef(_32144);
        _32144 = NOVALUE;
        goto LA; // [254] 275
    }
    else {
        if (!IS_ATOM_INT(_32144) && DBL_PTR(_32144)->dbl == 0.0){
            DeRef(_32144);
            _32144 = NOVALUE;
            goto LA; // [254] 275
        }
        DeRef(_32144);
        _32144 = NOVALUE;
    }
    DeRef(_32144);
    _32144 = NOVALUE;

    /** execute.e:493				LookBackForSubscriptSymbol( pc, sublevel + 1, has_slice )*/
    _32145 = _sublevel_65351 + 1;
    if (_32145 > MAXINT){
        _32145 = NewDouble((eudouble)_32145);
    }
    DeRef(_32146);
    _32146 = _pc_65350;
    DeRef(_32147);
    _32147 = _has_slice_65352;
    _67LookBackForSubscriptSymbol(_32146, _32145, _32147);
    _32146 = NOVALUE;
    _32145 = NOVALUE;
    _32147 = NOVALUE;
LA: 
L4: 

    /** execute.e:496	end procedure*/
    _32113 = NOVALUE;
    DeRef(_32131);
    _32131 = NOVALUE;
    DeRef(_32132);
    _32132 = NOVALUE;
    DeRef(_32139);
    _32139 = NOVALUE;
    DeRef(_32129);
    _32129 = NOVALUE;
    DeRef(_32126);
    _32126 = NOVALUE;
    DeRef(_32109);
    _32109 = NOVALUE;
    DeRef(_32124);
    _32124 = NOVALUE;
    DeRef(_32142);
    _32142 = NOVALUE;
    DeRef(_32136);
    _32136 = NOVALUE;
    DeRef(_32115);
    _32115 = NOVALUE;
    _32117 = NOVALUE;
    return;
    ;
}


void _67CheckSubsError()
{
    object _op_65415 = NOVALUE;
    object _32149 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:499		integer op = Code[pc]*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    _op_65415 = (object)*(((s1_ptr)_2)->base + _67pc_64877);
    if (!IS_ATOM_INT(_op_65415)){
        _op_65415 = (object)DBL_PTR(_op_65415)->dbl;
    }

    /** execute.e:500		if is_subs( op ) then*/
    _32149 = _67is_subs(_op_65415);
    if (_32149 == 0) {
        DeRef(_32149);
        _32149 = NOVALUE;
        goto L1; // [19] 32
    }
    else {
        if (!IS_ATOM_INT(_32149) && DBL_PTR(_32149)->dbl == 0.0){
            DeRef(_32149);
            _32149 = NOVALUE;
            goto L1; // [19] 32
        }
        DeRef(_32149);
        _32149 = NOVALUE;
    }
    DeRef(_32149);
    _32149 = NOVALUE;

    /** execute.e:501			LookBackForSubscriptSymbol( pc, 1, 0 )*/
    _67LookBackForSubscriptSymbol(_67pc_64877, 1LL, 0LL);
L1: 

    /** execute.e:503	end procedure*/
    return;
    ;
}


void _67trace_back(object _msg_65422)
{
    object _sub_65424 = NOVALUE;
    object _v_65425 = NOVALUE;
    object _levels_65426 = NOVALUE;
    object _prev_file_no_65427 = NOVALUE;
    object _task_65428 = NOVALUE;
    object _dash_count_65429 = NOVALUE;
    object _routine_name_65430 = NOVALUE;
    object _title_65431 = NOVALUE;
    object _show_message_65433 = NOVALUE;
    object _32301 = NOVALUE;
    object _32300 = NOVALUE;
    object _32298 = NOVALUE;
    object _32295 = NOVALUE;
    object _32293 = NOVALUE;
    object _32292 = NOVALUE;
    object _32291 = NOVALUE;
    object _32290 = NOVALUE;
    object _32289 = NOVALUE;
    object _32288 = NOVALUE;
    object _32287 = NOVALUE;
    object _32286 = NOVALUE;
    object _32285 = NOVALUE;
    object _32284 = NOVALUE;
    object _32283 = NOVALUE;
    object _32282 = NOVALUE;
    object _32281 = NOVALUE;
    object _32280 = NOVALUE;
    object _32278 = NOVALUE;
    object _32276 = NOVALUE;
    object _32272 = NOVALUE;
    object _32270 = NOVALUE;
    object _32268 = NOVALUE;
    object _32267 = NOVALUE;
    object _32266 = NOVALUE;
    object _32265 = NOVALUE;
    object _32264 = NOVALUE;
    object _32263 = NOVALUE;
    object _32262 = NOVALUE;
    object _32261 = NOVALUE;
    object _32260 = NOVALUE;
    object _32259 = NOVALUE;
    object _32257 = NOVALUE;
    object _32254 = NOVALUE;
    object _32253 = NOVALUE;
    object _32251 = NOVALUE;
    object _32250 = NOVALUE;
    object _32249 = NOVALUE;
    object _32247 = NOVALUE;
    object _32246 = NOVALUE;
    object _32245 = NOVALUE;
    object _32244 = NOVALUE;
    object _32243 = NOVALUE;
    object _32242 = NOVALUE;
    object _32241 = NOVALUE;
    object _32240 = NOVALUE;
    object _32239 = NOVALUE;
    object _32238 = NOVALUE;
    object _32236 = NOVALUE;
    object _32234 = NOVALUE;
    object _32233 = NOVALUE;
    object _32232 = NOVALUE;
    object _32231 = NOVALUE;
    object _32230 = NOVALUE;
    object _32229 = NOVALUE;
    object _32228 = NOVALUE;
    object _32227 = NOVALUE;
    object _32226 = NOVALUE;
    object _32225 = NOVALUE;
    object _32224 = NOVALUE;
    object _32223 = NOVALUE;
    object _32222 = NOVALUE;
    object _32221 = NOVALUE;
    object _32220 = NOVALUE;
    object _32218 = NOVALUE;
    object _32216 = NOVALUE;
    object _32215 = NOVALUE;
    object _32214 = NOVALUE;
    object _32213 = NOVALUE;
    object _32212 = NOVALUE;
    object _32204 = NOVALUE;
    object _32203 = NOVALUE;
    object _32201 = NOVALUE;
    object _32200 = NOVALUE;
    object _32199 = NOVALUE;
    object _32198 = NOVALUE;
    object _32187 = NOVALUE;
    object _32186 = NOVALUE;
    object _32185 = NOVALUE;
    object _32182 = NOVALUE;
    object _32180 = NOVALUE;
    object _32179 = NOVALUE;
    object _32178 = NOVALUE;
    object _32177 = NOVALUE;
    object _32173 = NOVALUE;
    object _32171 = NOVALUE;
    object _32168 = NOVALUE;
    object _32167 = NOVALUE;
    object _32166 = NOVALUE;
    object _32163 = NOVALUE;
    object _32162 = NOVALUE;
    object _32161 = NOVALUE;
    object _32160 = NOVALUE;
    object _32159 = NOVALUE;
    object _32155 = NOVALUE;
    object _32152 = NOVALUE;
    object _32151 = NOVALUE;
    object _32150 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:508		integer levels, prev_file_no, task, dash_count*/

    /** execute.e:509		sequence routine_name, title*/

    /** execute.e:512		if atom(slist[$]) then*/
    if (IS_SEQUENCE(_12slist_20317)){
            _32150 = SEQ_PTR(_12slist_20317)->length;
    }
    else {
        _32150 = 1;
    }
    _2 = (object)SEQ_PTR(_12slist_20317);
    _32151 = (object)*(((s1_ptr)_2)->base + _32150);
    _32152 = IS_ATOM(_32151);
    _32151 = NOVALUE;
    if (_32152 == 0)
    {
        _32152 = NOVALUE;
        goto L1; // [21] 35
    }
    else{
        _32152 = NOVALUE;
    }

    /** execute.e:513			slist = s_expand(slist)*/
    RefDS(_12slist_20317);
    _0 = _61s_expand(_12slist_20317);
    DeRefDS(_12slist_20317);
    _12slist_20317 = _0;
L1: 

    /** execute.e:518		show_message = TRUE*/
    _show_message_65433 = _9TRUE_446;

    /** execute.e:520		screen_err_out = atom(crash_msg)*/
    _67screen_err_out_64938 = IS_ATOM(_67crash_msg_64803);

    /** execute.e:522		while TRUE do*/
L2: 
    if (_9TRUE_446 == 0)
    {
        goto L3; // [56] 978
    }
    else{
    }

    /** execute.e:523			if length(tcb) > 1 then*/
    if (IS_SEQUENCE(_67tcb_64921)){
            _32155 = SEQ_PTR(_67tcb_64921)->length;
    }
    else {
        _32155 = 1;
    }
    if (_32155 <= 1LL)
    goto L4; // [66] 208

    /** execute.e:526				if current_task = 1 then*/
    if (_67current_task_64894 != 1LL)
    goto L5; // [74] 88

    /** execute.e:527					routine_name = "initial task"*/
    RefDS(_32158);
    DeRef(_routine_name_65430);
    _routine_name_65430 = _32158;
    goto L6; // [85] 127
L5: 

    /** execute.e:529					routine_name = SymTab[e_routine[1+tcb[current_task][TASK_RID]]][S_NAME]*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32159 = (object)*(((s1_ptr)_2)->base + _67current_task_64894);
    _2 = (object)SEQ_PTR(_32159);
    _32160 = (object)*(((s1_ptr)_2)->base + 1LL);
    _32159 = NOVALUE;
    if (IS_ATOM_INT(_32160)) {
        _32161 = _32160 + 1;
    }
    else
    _32161 = binary_op(PLUS, 1, _32160);
    _32160 = NOVALUE;
    _2 = (object)SEQ_PTR(_67e_routine_64926);
    if (!IS_ATOM_INT(_32161)){
        _32162 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32161)->dbl));
    }
    else{
        _32162 = (object)*(((s1_ptr)_2)->base + _32161);
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32163 = (object)*(((s1_ptr)_2)->base + _32162);
    DeRef(_routine_name_65430);
    _2 = (object)SEQ_PTR(_32163);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _routine_name_65430 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _routine_name_65430 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    Ref(_routine_name_65430);
    _32163 = NOVALUE;
L6: 

    /** execute.e:532				title = sprintf(" TASK ID %d: %s ",*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32166 = (object)*(((s1_ptr)_2)->base + _67current_task_64894);
    _2 = (object)SEQ_PTR(_32166);
    _32167 = (object)*(((s1_ptr)_2)->base + 2LL);
    _32166 = NOVALUE;
    RefDS(_routine_name_65430);
    Ref(_32167);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _32167;
    ((intptr_t *)_2)[2] = _routine_name_65430;
    _32168 = MAKE_SEQ(_1);
    _32167 = NOVALUE;
    DeRefi(_title_65431);
    _title_65431 = EPrintf(-9999999, _32165, _32168);
    DeRefDS(_32168);
    _32168 = NOVALUE;

    /** execute.e:534				dash_count = 60*/
    _dash_count_65429 = 60LL;

    /** execute.e:535				if length(title) < dash_count then*/
    if (IS_SEQUENCE(_title_65431)){
            _32171 = SEQ_PTR(_title_65431)->length;
    }
    else {
        _32171 = 1;
    }
    if (_32171 >= 60LL)
    goto L7; // [161] 175

    /** execute.e:536					dash_count = 52 - length(title)*/
    if (IS_SEQUENCE(_title_65431)){
            _32173 = SEQ_PTR(_title_65431)->length;
    }
    else {
        _32173 = 1;
    }
    _dash_count_65429 = 52LL - _32173;
    _32173 = NOVALUE;
L7: 

    /** execute.e:538				if dash_count < 1 then*/
    if (_dash_count_65429 >= 1LL)
    goto L8; // [177] 187

    /** execute.e:539					dash_count = 1*/
    _dash_count_65429 = 1LL;
L8: 

    /** execute.e:541				both_puts(repeat('-', 22) & title & repeat('-', dash_count) & "\n")*/
    _32177 = Repeat(45LL, 22LL);
    _32178 = Repeat(45LL, _dash_count_65429);
    {
        object concat_list[4];

        concat_list[0] = _22231;
        concat_list[1] = _32178;
        concat_list[2] = _title_65431;
        concat_list[3] = _32177;
        Concat_N((object_ptr)&_32179, concat_list, 4);
    }
    DeRefDS(_32178);
    _32178 = NOVALUE;
    DeRefDS(_32177);
    _32177 = NOVALUE;
    _67both_puts(_32179);
    _32179 = NOVALUE;
L4: 

    /** execute.e:544			levels = 1*/
    _levels_65426 = 1LL;

    /** execute.e:546			while length(call_stack) > 0 do*/
L9: 
    if (IS_SEQUENCE(_67call_stack_64895)){
            _32180 = SEQ_PTR(_67call_stack_64895)->length;
    }
    else {
        _32180 = 1;
    }
    if (_32180 <= 0LL)
    goto LA; // [223] 812

    /** execute.e:547				sub = call_stack[$]*/
    if (IS_SEQUENCE(_67call_stack_64895)){
            _32182 = SEQ_PTR(_67call_stack_64895)->length;
    }
    else {
        _32182 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_64895);
    _sub_65424 = (object)*(((s1_ptr)_2)->base + _32182);
    if (!IS_ATOM_INT(_sub_65424)){
        _sub_65424 = (object)DBL_PTR(_sub_65424)->dbl;
    }

    /** execute.e:548				if levels = 1 then*/
    if (_levels_65426 != 1LL)
    goto LB; // [242] 254

    /** execute.e:549					puts(2, '\n')*/
    EPuts(2LL, 10LL); // DJP 
    goto LC; // [251] 283
LB: 

    /** execute.e:551				elsif sub != call_back_routine and sub != delete_code_routine then*/
    _32185 = (_sub_65424 != _67call_back_routine_64811);
    if (_32185 == 0) {
        goto LD; // [262] 282
    }
    _32187 = (_sub_65424 != _67delete_code_routine_64812);
    if (_32187 == 0)
    {
        DeRef(_32187);
        _32187 = NOVALUE;
        goto LD; // [273] 282
    }
    else{
        DeRef(_32187);
        _32187 = NOVALUE;
    }

    /** execute.e:552					both_puts("... called from ")*/
    RefDS(_32188);
    _67both_puts(_32188);
LD: 
LC: 

    /** execute.e:556				if sub = call_back_routine then*/
    if (_sub_65424 != _67call_back_routine_64811)
    goto LE; // [287] 327

    /** execute.e:557					if crash_count > 0 then*/
    if (_67crash_count_64814 <= 0LL)
    goto LF; // [295] 311

    /** execute.e:558						both_puts("^^^ called to handle run-time crash\n")*/
    RefDS(_32191);
    _67both_puts(_32191);

    /** execute.e:559						exit*/
    goto LA; // [306] 812
    goto L10; // [308] 757
LF: 

    /** execute.e:561						both_puts("^^^ call-back from ")*/
    RefDS(_32192);
    _67both_puts(_32192);

    /** execute.e:562						ifdef WINDOWS then*/

    /** execute.e:565							both_puts("external program\n")*/
    RefDS(_32194);
    _67both_puts(_32194);
    goto L10; // [324] 757
LE: 

    /** execute.e:568				elsif sub = delete_code_routine then*/
    if (_sub_65424 != _67delete_code_routine_64812)
    goto L11; // [331] 343

    /** execute.e:569					both_puts("^^^ delete routine\n")*/
    RefDS(_32196);
    _67both_puts(_32196);
    goto L10; // [340] 757
L11: 

    /** execute.e:572					both_printf("%s:%d", find_line(sub, pc))*/
    _32198 = _67find_line(_sub_65424, _67pc_64877);
    RefDS(_32197);
    _67both_printf(_32197, _32198);
    _32198 = NOVALUE;

    /** execute.e:574					if not equal(SymTab[sub][S_NAME], "<TopLevel>") then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32199 = (object)*(((s1_ptr)_2)->base + _sub_65424);
    _2 = (object)SEQ_PTR(_32199);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _32200 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _32200 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _32199 = NOVALUE;
    if (_32200 == _24628)
    _32201 = 1;
    else if (IS_ATOM_INT(_32200) && IS_ATOM_INT(_24628))
    _32201 = 0;
    else
    _32201 = (compare(_32200, _24628) == 0);
    _32200 = NOVALUE;
    if (_32201 != 0)
    goto L12; // [374] 462
    _32201 = NOVALUE;

    /** execute.e:575						switch SymTab[sub][S_TOKEN] do*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32203 = (object)*(((s1_ptr)_2)->base + _sub_65424);
    _2 = (object)SEQ_PTR(_32203);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _32204 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _32204 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _32203 = NOVALUE;
    if (IS_SEQUENCE(_32204) ){
        goto L13; // [391] 431
    }
    if(!IS_ATOM_INT(_32204)){
        if( (DBL_PTR(_32204)->dbl != (eudouble) ((object) DBL_PTR(_32204)->dbl) ) ){
            goto L13; // [391] 431
        }
        _0 = (object) DBL_PTR(_32204)->dbl;
    }
    else {
        _0 = _32204;
    };
    _32204 = NOVALUE;
    switch ( _0 ){ 

        /** execute.e:576							case PROC then*/
        case 27:

        /** execute.e:577								both_puts(" in procedure ")*/
        RefDS(_32207);
        _67both_puts(_32207);
        goto L14; // [405] 439

        /** execute.e:579							case FUNC then*/
        case 501:

        /** execute.e:580								both_puts(" in function ")*/
        RefDS(_32208);
        _67both_puts(_32208);
        goto L14; // [416] 439

        /** execute.e:582							case TYPE then*/
        case 504:

        /** execute.e:583								both_puts(" in type ")*/
        RefDS(_32209);
        _67both_puts(_32209);
        goto L14; // [427] 439

        /** execute.e:585							case else*/
        default:
L13: 

        /** execute.e:586								RTInternal("SymTab[sub][S_TOKEN] is not a routine")*/
        RefDS(_32210);
        _67RTInternal(_32210);
    ;}L14: 

    /** execute.e:590						both_printf("%s()", {SymTab[sub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32212 = (object)*(((s1_ptr)_2)->base + _sub_65424);
    _2 = (object)SEQ_PTR(_32212);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _32213 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _32213 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _32212 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_32213);
    ((intptr_t*)_2)[1] = _32213;
    _32214 = MAKE_SEQ(_1);
    _32213 = NOVALUE;
    RefDS(_32211);
    _67both_printf(_32211, _32214);
    _32214 = NOVALUE;
L12: 

    /** execute.e:593					both_puts("\n")*/
    RefDS(_22231);
    _67both_puts(_22231);

    /** execute.e:595					if show_message then*/
    if (_show_message_65433 == 0)
    {
        goto L15; // [469] 515
    }
    else{
    }

    /** execute.e:596						if sequence(crash_msg) then*/
    _32215 = IS_SEQUENCE(_67crash_msg_64803);
    if (_32215 == 0)
    {
        _32215 = NOVALUE;
        goto L16; // [479] 493
    }
    else{
        _32215 = NOVALUE;
    }

    /** execute.e:597							clear_screen()*/
    ClearScreen();

    /** execute.e:598							puts(2, crash_msg)*/
    EPuts(2LL, _67crash_msg_64803); // DJP 
L16: 

    /** execute.e:600						both_puts(msg)*/
    RefDS(_msg_65422);
    _67both_puts(_msg_65422);

    /** execute.e:601						CheckSubsError()*/
    _67CheckSubsError();

    /** execute.e:602						both_puts(" \n")*/
    RefDS(_24333);
    _67both_puts(_24333);

    /** execute.e:603						show_message = FALSE*/
    _show_message_65433 = _9FALSE_444;
L15: 

    /** execute.e:606					if length(call_stack) < 2 then*/
    if (IS_SEQUENCE(_67call_stack_64895)){
            _32216 = SEQ_PTR(_67call_stack_64895)->length;
    }
    else {
        _32216 = 1;
    }
    if (_32216 >= 2LL)
    goto L17; // [522] 536

    /** execute.e:607						both_puts('\n')*/
    _67both_puts(10LL);

    /** execute.e:608						exit*/
    goto LA; // [533] 812
L17: 

    /** execute.e:612					v = SymTab[sub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32218 = (object)*(((s1_ptr)_2)->base + _sub_65424);
    _2 = (object)SEQ_PTR(_32218);
    _v_65425 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_v_65425)){
        _v_65425 = (object)DBL_PTR(_v_65425)->dbl;
    }
    _32218 = NOVALUE;

    /** execute.e:614					while v != 0 and*/
L18: 
    _32220 = (_v_65425 != 0LL);
    if (_32220 == 0) {
        goto L19; // [561] 686
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32222 = (object)*(((s1_ptr)_2)->base + _v_65425);
    _2 = (object)SEQ_PTR(_32222);
    _32223 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32222 = NOVALUE;
    if (IS_ATOM_INT(_32223)) {
        _32224 = (_32223 == 3LL);
    }
    else {
        _32224 = binary_op(EQUALS, _32223, 3LL);
    }
    _32223 = NOVALUE;
    if (IS_ATOM_INT(_32224)) {
        if (_32224 != 0) {
            DeRef(_32225);
            _32225 = 1;
            goto L1A; // [583] 609
        }
    }
    else {
        if (DBL_PTR(_32224)->dbl != 0.0) {
            DeRef(_32225);
            _32225 = 1;
            goto L1A; // [583] 609
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32226 = (object)*(((s1_ptr)_2)->base + _v_65425);
    _2 = (object)SEQ_PTR(_32226);
    _32227 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32226 = NOVALUE;
    if (IS_ATOM_INT(_32227)) {
        _32228 = (_32227 == 2LL);
    }
    else {
        _32228 = binary_op(EQUALS, _32227, 2LL);
    }
    _32227 = NOVALUE;
    DeRef(_32225);
    if (IS_ATOM_INT(_32228))
    _32225 = (_32228 != 0);
    else
    _32225 = DBL_PTR(_32228)->dbl != 0.0;
L1A: 
    if (_32225 != 0) {
        DeRef(_32229);
        _32229 = 1;
        goto L1B; // [609] 635
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32230 = (object)*(((s1_ptr)_2)->base + _v_65425);
    _2 = (object)SEQ_PTR(_32230);
    _32231 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32230 = NOVALUE;
    if (IS_ATOM_INT(_32231)) {
        _32232 = (_32231 == 9LL);
    }
    else {
        _32232 = binary_op(EQUALS, _32231, 9LL);
    }
    _32231 = NOVALUE;
    if (IS_ATOM_INT(_32232))
    _32229 = (_32232 != 0);
    else
    _32229 = DBL_PTR(_32232)->dbl != 0.0;
L1B: 
    if (_32229 == 0)
    {
        _32229 = NOVALUE;
        goto L19; // [636] 686
    }
    else{
        _32229 = NOVALUE;
    }

    /** execute.e:618						if SymTab[v][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32233 = (object)*(((s1_ptr)_2)->base + _v_65425);
    _2 = (object)SEQ_PTR(_32233);
    _32234 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32233 = NOVALUE;
    if (binary_op_a(EQUALS, _32234, 9LL)){
        _32234 = NOVALUE;
        goto L1C; // [655] 665
    }
    _32234 = NOVALUE;

    /** execute.e:619							show_var(v)*/
    _67show_var(_v_65425);
L1C: 

    /** execute.e:622						v = SymTab[v][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32236 = (object)*(((s1_ptr)_2)->base + _v_65425);
    _2 = (object)SEQ_PTR(_32236);
    _v_65425 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_v_65425)){
        _v_65425 = (object)DBL_PTR(_v_65425)->dbl;
    }
    _32236 = NOVALUE;

    /** execute.e:623					end while*/
    goto L18; // [683] 557
L19: 

    /** execute.e:625					if length(SymTab[sub][S_SAVED_PRIVATES]) > 0 and*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32238 = (object)*(((s1_ptr)_2)->base + _sub_65424);
    _2 = (object)SEQ_PTR(_32238);
    _32239 = (object)*(((s1_ptr)_2)->base + 26LL);
    _32238 = NOVALUE;
    if (IS_SEQUENCE(_32239)){
            _32240 = SEQ_PTR(_32239)->length;
    }
    else {
        _32240 = 1;
    }
    _32239 = NOVALUE;
    _32241 = (_32240 > 0LL);
    _32240 = NOVALUE;
    if (_32241 == 0) {
        goto L1D; // [707] 756
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32243 = (object)*(((s1_ptr)_2)->base + _sub_65424);
    _2 = (object)SEQ_PTR(_32243);
    _32244 = (object)*(((s1_ptr)_2)->base + 26LL);
    _32243 = NOVALUE;
    _2 = (object)SEQ_PTR(_32244);
    _32245 = (object)*(((s1_ptr)_2)->base + 1LL);
    _32244 = NOVALUE;
    if (IS_ATOM_INT(_32245)) {
        _32246 = (_32245 != 0LL);
    }
    else {
        _32246 = binary_op(NOTEQ, _32245, 0LL);
    }
    _32245 = NOVALUE;
    if (_32246 == 0) {
        DeRef(_32246);
        _32246 = NOVALUE;
        goto L1D; // [732] 756
    }
    else {
        if (!IS_ATOM_INT(_32246) && DBL_PTR(_32246)->dbl == 0.0){
            DeRef(_32246);
            _32246 = NOVALUE;
            goto L1D; // [732] 756
        }
        DeRef(_32246);
        _32246 = NOVALUE;
    }
    DeRef(_32246);
    _32246 = NOVALUE;

    /** execute.e:627						SymTab[sub][S_RESIDENT_TASK] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sub_65424 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _32247 = NOVALUE;

    /** execute.e:628						restore_privates(sub)*/
    _67restore_privates(_sub_65424);
L1D: 
L10: 

    /** execute.e:632				puts(err_file, '\n')*/
    EPuts(_67err_file_64927, 10LL); // DJP 

    /** execute.e:635				pc = call_stack[$-1] - 1*/
    if (IS_SEQUENCE(_67call_stack_64895)){
            _32249 = SEQ_PTR(_67call_stack_64895)->length;
    }
    else {
        _32249 = 1;
    }
    _32250 = _32249 - 1LL;
    _32249 = NOVALUE;
    _2 = (object)SEQ_PTR(_67call_stack_64895);
    _32251 = (object)*(((s1_ptr)_2)->base + _32250);
    if (IS_ATOM_INT(_32251)) {
        _67pc_64877 = _32251 - 1LL;
    }
    else {
        _67pc_64877 = binary_op(MINUS, _32251, 1LL);
    }
    _32251 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_64877)) {
        _1 = (object)(DBL_PTR(_67pc_64877)->dbl);
        DeRefDS(_67pc_64877);
        _67pc_64877 = _1;
    }

    /** execute.e:636				call_stack = call_stack[1..$-2]*/
    if (IS_SEQUENCE(_67call_stack_64895)){
            _32253 = SEQ_PTR(_67call_stack_64895)->length;
    }
    else {
        _32253 = 1;
    }
    _32254 = _32253 - 2LL;
    _32253 = NOVALUE;
    rhs_slice_target = (object_ptr)&_67call_stack_64895;
    RHS_Slice(_67call_stack_64895, 1LL, _32254);

    /** execute.e:637				levels += 1*/
    _levels_65426 = _levels_65426 + 1;

    /** execute.e:638			end while*/
    goto L9; // [809] 218
LA: 

    /** execute.e:640			tcb[current_task][TASK_STATE] = ST_DEAD -- mark as "deleted"*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64921 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_64894 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _32257 = NOVALUE;

    /** execute.e:643			task = current_task*/
    _task_65428 = _67current_task_64894;

    /** execute.e:644			for i = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_64921)){
            _32259 = SEQ_PTR(_67tcb_64921)->length;
    }
    else {
        _32259 = 1;
    }
    {
        object _i_65611;
        _i_65611 = 1LL;
L1E: 
        if (_i_65611 > _32259){
            goto L1F; // [841] 955
        }

        /** execute.e:645				if tcb[i][TASK_STATE] != ST_DEAD and*/
        _2 = (object)SEQ_PTR(_67tcb_64921);
        _32260 = (object)*(((s1_ptr)_2)->base + _i_65611);
        _2 = (object)SEQ_PTR(_32260);
        _32261 = (object)*(((s1_ptr)_2)->base + 4LL);
        _32260 = NOVALUE;
        if (IS_ATOM_INT(_32261)) {
            _32262 = (_32261 != 2LL);
        }
        else {
            _32262 = binary_op(NOTEQ, _32261, 2LL);
        }
        _32261 = NOVALUE;
        if (IS_ATOM_INT(_32262)) {
            if (_32262 == 0) {
                goto L20; // [864] 948
            }
        }
        else {
            if (DBL_PTR(_32262)->dbl == 0.0) {
                goto L20; // [864] 948
            }
        }
        _2 = (object)SEQ_PTR(_67tcb_64921);
        _32264 = (object)*(((s1_ptr)_2)->base + _i_65611);
        _2 = (object)SEQ_PTR(_32264);
        _32265 = (object)*(((s1_ptr)_2)->base + 16LL);
        _32264 = NOVALUE;
        if (IS_SEQUENCE(_32265)){
                _32266 = SEQ_PTR(_32265)->length;
        }
        else {
            _32266 = 1;
        }
        _32265 = NOVALUE;
        _32267 = (_32266 > 0LL);
        _32266 = NOVALUE;
        if (_32267 == 0)
        {
            DeRef(_32267);
            _32267 = NOVALUE;
            goto L20; // [886] 948
        }
        else{
            DeRef(_32267);
            _32267 = NOVALUE;
        }

        /** execute.e:647					current_task = i*/
        _67current_task_64894 = _i_65611;

        /** execute.e:648					call_stack = tcb[i][TASK_STACK]*/
        _2 = (object)SEQ_PTR(_67tcb_64921);
        _32268 = (object)*(((s1_ptr)_2)->base + _i_65611);
        DeRef(_67call_stack_64895);
        _2 = (object)SEQ_PTR(_32268);
        _67call_stack_64895 = (object)*(((s1_ptr)_2)->base + 16LL);
        Ref(_67call_stack_64895);
        _32268 = NOVALUE;

        /** execute.e:649					pc = tcb[i][TASK_PC]*/
        _2 = (object)SEQ_PTR(_67tcb_64921);
        _32270 = (object)*(((s1_ptr)_2)->base + _i_65611);
        _2 = (object)SEQ_PTR(_32270);
        _67pc_64877 = (object)*(((s1_ptr)_2)->base + 14LL);
        if (!IS_ATOM_INT(_67pc_64877)){
            _67pc_64877 = (object)DBL_PTR(_67pc_64877)->dbl;
        }
        _32270 = NOVALUE;

        /** execute.e:650					Code = tcb[i][TASK_CODE]*/
        _2 = (object)SEQ_PTR(_67tcb_64921);
        _32272 = (object)*(((s1_ptr)_2)->base + _i_65611);
        DeRef(_12Code_20315);
        _2 = (object)SEQ_PTR(_32272);
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + 15LL);
        Ref(_12Code_20315);
        _32272 = NOVALUE;

        /** execute.e:651					screen_err_out = FALSE  -- just show offending task on screen*/
        _67screen_err_out_64938 = _9FALSE_444;

        /** execute.e:652					exit*/
        goto L1F; // [945] 955
L20: 

        /** execute.e:654			end for*/
        _i_65611 = _i_65611 + 1LL;
        goto L1E; // [950] 848
L1F: 
        ;
    }

    /** execute.e:655			if task = current_task then*/
    if (_task_65428 != _67current_task_64894)
    goto L21; // [959] 968

    /** execute.e:656				exit*/
    goto L3; // [965] 978
L21: 

    /** execute.e:658			both_puts("\n")*/
    RefDS(_22231);
    _67both_puts(_22231);

    /** execute.e:659		end while*/
    goto L2; // [975] 54
L3: 

    /** execute.e:661		puts(2, "\n--> see " & err_file_name & '\n')*/
    {
        object concat_list[3];

        concat_list[0] = 10LL;
        concat_list[1] = _67err_file_name_64928;
        concat_list[2] = _32275;
        Concat_N((object_ptr)&_32276, concat_list, 3);
    }
    EPuts(2LL, _32276); // DJP 
    DeRefDS(_32276);
    _32276 = NOVALUE;

    /** execute.e:663		puts(err_file, "\n\nGlobal & Local Variables\n")*/
    EPuts(_67err_file_64927, _32277); // DJP 

    /** execute.e:664		prev_file_no = -1*/
    _prev_file_no_65427 = -1LL;

    /** execute.e:665		v = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32278 = (object)*(((s1_ptr)_2)->base + _12TopLevelSub_20233);
    _2 = (object)SEQ_PTR(_32278);
    _v_65425 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_v_65425)){
        _v_65425 = (object)DBL_PTR(_v_65425)->dbl;
    }
    _32278 = NOVALUE;

    /** execute.e:666		while v do*/
L22: 
    if (_v_65425 == 0)
    {
        goto L23; // [1026] 1193
    }
    else{
    }

    /** execute.e:667			if SymTab[v][S_TOKEN] = VARIABLE and*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32280 = (object)*(((s1_ptr)_2)->base + _v_65425);
    _2 = (object)SEQ_PTR(_32280);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _32281 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _32281 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _32280 = NOVALUE;
    if (IS_ATOM_INT(_32281)) {
        _32282 = (_32281 == -100LL);
    }
    else {
        _32282 = binary_op(EQUALS, _32281, -100LL);
    }
    _32281 = NOVALUE;
    if (IS_ATOM_INT(_32282)) {
        if (_32282 == 0) {
            DeRef(_32283);
            _32283 = 0;
            goto L24; // [1049] 1075
        }
    }
    else {
        if (DBL_PTR(_32282)->dbl == 0.0) {
            DeRef(_32283);
            _32283 = 0;
            goto L24; // [1049] 1075
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32284 = (object)*(((s1_ptr)_2)->base + _v_65425);
    _2 = (object)SEQ_PTR(_32284);
    _32285 = (object)*(((s1_ptr)_2)->base + 3LL);
    _32284 = NOVALUE;
    if (IS_ATOM_INT(_32285)) {
        _32286 = (_32285 == 1LL);
    }
    else {
        _32286 = binary_op(EQUALS, _32285, 1LL);
    }
    _32285 = NOVALUE;
    DeRef(_32283);
    if (IS_ATOM_INT(_32286))
    _32283 = (_32286 != 0);
    else
    _32283 = DBL_PTR(_32286)->dbl != 0.0;
L24: 
    if (_32283 == 0) {
        goto L25; // [1075] 1172
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32288 = (object)*(((s1_ptr)_2)->base + _v_65425);
    _2 = (object)SEQ_PTR(_32288);
    _32289 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32288 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 5LL;
    ((intptr_t*)_2)[2] = 6LL;
    ((intptr_t*)_2)[3] = 4LL;
    _32290 = MAKE_SEQ(_1);
    _32291 = find_from(_32289, _32290, 1LL);
    _32289 = NOVALUE;
    DeRefDS(_32290);
    _32290 = NOVALUE;
    if (_32291 == 0)
    {
        _32291 = NOVALUE;
        goto L25; // [1109] 1172
    }
    else{
        _32291 = NOVALUE;
    }

    /** execute.e:670				if SymTab[v][S_FILE_NO] != prev_file_no then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32292 = (object)*(((s1_ptr)_2)->base + _v_65425);
    _2 = (object)SEQ_PTR(_32292);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _32293 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _32293 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _32292 = NOVALUE;
    if (binary_op_a(EQUALS, _32293, _prev_file_no_65427)){
        _32293 = NOVALUE;
        goto L26; // [1126] 1166
    }
    _32293 = NOVALUE;

    /** execute.e:671					prev_file_no = SymTab[v][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32295 = (object)*(((s1_ptr)_2)->base + _v_65425);
    _2 = (object)SEQ_PTR(_32295);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _prev_file_no_65427 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _prev_file_no_65427 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    if (!IS_ATOM_INT(_prev_file_no_65427)){
        _prev_file_no_65427 = (object)DBL_PTR(_prev_file_no_65427)->dbl;
    }
    _32295 = NOVALUE;

    /** execute.e:672					puts(err_file, "\n " & known_files[prev_file_no] & ":\n")*/
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _32298 = (object)*(((s1_ptr)_2)->base + _prev_file_no_65427);
    {
        object concat_list[3];

        concat_list[0] = _32299;
        concat_list[1] = _32298;
        concat_list[2] = _32297;
        Concat_N((object_ptr)&_32300, concat_list, 3);
    }
    _32298 = NOVALUE;
    EPuts(_67err_file_64927, _32300); // DJP 
    DeRefDS(_32300);
    _32300 = NOVALUE;
L26: 

    /** execute.e:674				show_var(v)*/
    _67show_var(_v_65425);
L25: 

    /** execute.e:676			v = SymTab[v][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32301 = (object)*(((s1_ptr)_2)->base + _v_65425);
    _2 = (object)SEQ_PTR(_32301);
    _v_65425 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_v_65425)){
        _v_65425 = (object)DBL_PTR(_v_65425)->dbl;
    }
    _32301 = NOVALUE;

    /** execute.e:677		end while*/
    goto L22; // [1190] 1026
L23: 

    /** execute.e:678		puts(err_file, '\n')*/
    EPuts(_67err_file_64927, 10LL); // DJP 

    /** execute.e:679		close(err_file)*/
    EClose(_67err_file_64927);

    /** execute.e:680	end procedure*/
    DeRefDS(_msg_65422);
    DeRef(_routine_name_65430);
    DeRefi(_title_65431);
    DeRef(_32161);
    _32161 = NOVALUE;
    DeRef(_32220);
    _32220 = NOVALUE;
    _32162 = NOVALUE;
    DeRef(_32185);
    _32185 = NOVALUE;
    DeRef(_32224);
    _32224 = NOVALUE;
    _32265 = NOVALUE;
    DeRef(_32286);
    _32286 = NOVALUE;
    _32239 = NOVALUE;
    DeRef(_32232);
    _32232 = NOVALUE;
    DeRef(_32241);
    _32241 = NOVALUE;
    DeRef(_32250);
    _32250 = NOVALUE;
    DeRef(_32254);
    _32254 = NOVALUE;
    DeRef(_32282);
    _32282 = NOVALUE;
    DeRef(_32228);
    _32228 = NOVALUE;
    DeRef(_32262);
    _32262 = NOVALUE;
    return;
    ;
}


void _67call_crash_routines()
{
    object _quit_65688 = NOVALUE;
    object _32312 = NOVALUE;
    object _32310 = NOVALUE;
    object _32309 = NOVALUE;
    object _32308 = NOVALUE;
    object _32307 = NOVALUE;
    object _32306 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:688		if crash_count > 0 then*/
    if (_67crash_count_64814 <= 0LL)
    goto L1; // [5] 15

    /** execute.e:689			return*/
    DeRef(_quit_65688);
    return;
L1: 

    /** execute.e:692		crash_count += 1*/
    _67crash_count_64814 = _67crash_count_64814 + 1;

    /** execute.e:695		err_file_name = "ex_crash.err"*/
    RefDS(_32305);
    DeRef(_67err_file_name_64928);
    _67err_file_name_64928 = _32305;

    /** execute.e:697		for i = length(crash_list) to 1 by -1 do*/
    if (IS_SEQUENCE(_67crash_list_64813)){
            _32306 = SEQ_PTR(_67crash_list_64813)->length;
    }
    else {
        _32306 = 1;
    }
    {
        object _i_65694;
        _i_65694 = _32306;
L2: 
        if (_i_65694 < 1LL){
            goto L3; // [37] 94
        }

        /** execute.e:699			quit = call_func(forward_general_callback,*/
        _2 = (object)SEQ_PTR(_67crash_list_64813);
        _32307 = (object)*(((s1_ptr)_2)->base + _i_65694);
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = 0LL;
        Ref(_32307);
        ((intptr_t*)_2)[2] = _32307;
        ((intptr_t*)_2)[3] = 1LL;
        _32308 = MAKE_SEQ(_1);
        _32307 = NOVALUE;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = 0LL;
        _32309 = MAKE_SEQ(_1);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _32308;
        ((intptr_t *)_2)[2] = _32309;
        _32310 = MAKE_SEQ(_1);
        _32309 = NOVALUE;
        _32308 = NOVALUE;
        _1 = (object)SEQ_PTR(_32310);
        _2 = (object)((s1_ptr)_1)->base;
        _0 = (object)_00[_67forward_general_callback_65684].addr;
        Ref( *(( (intptr_t*)_2) + 1) );
        Ref( *(( (intptr_t*)_2) + 2) );
        _1 = (*(intptr_t (*)())_0)(
                            *( ((intptr_t *)_2) + 1), 
                            *( ((intptr_t *)_2) + 2)
                             );
        DeRef(_quit_65688);
        _quit_65688 = _1;
        DeRefDS(_32310);
        _32310 = NOVALUE;

        /** execute.e:701			if not equal(quit, 0) then*/
        if (_quit_65688 == 0LL)
        _32312 = 1;
        else if (IS_ATOM_INT(_quit_65688) && IS_ATOM_INT(0LL))
        _32312 = 0;
        else
        _32312 = (compare(_quit_65688, 0LL) == 0);
        if (_32312 != 0)
        goto L4; // [78] 87
        _32312 = NOVALUE;

        /** execute.e:702				return -- don't call the others*/
        DeRef(_quit_65688);
        return;
L4: 

        /** execute.e:704		end for*/
        _i_65694 = _i_65694 + -1LL;
        goto L2; // [89] 44
L3: 
        ;
    }

    /** execute.e:705	end procedure*/
    DeRef(_quit_65688);
    return;
    ;
}


void _67quit_after_error()
{
    object _35128 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:709		write_coverage_db()*/
    _35128 = _50write_coverage_db();
    DeRef(_35128);
    _35128 = NOVALUE;

    /** execute.e:711		ifdef WINDOWS then*/

    /** execute.e:718		abort(1)*/
    UserCleanup(1LL);

    /** execute.e:719	end procedure*/
    return;
    ;
}


void _67RTFatalType(object _x_65710)
{
    object _msg_65711 = NOVALUE;
    object _v_65712 = NOVALUE;
    object _vname_65713 = NOVALUE;
    object _32347 = NOVALUE;
    object _32343 = NOVALUE;
    object _32342 = NOVALUE;
    object _32341 = NOVALUE;
    object _32340 = NOVALUE;
    object _32338 = NOVALUE;
    object _32337 = NOVALUE;
    object _32336 = NOVALUE;
    object _32335 = NOVALUE;
    object _32333 = NOVALUE;
    object _32332 = NOVALUE;
    object _32330 = NOVALUE;
    object _32329 = NOVALUE;
    object _32327 = NOVALUE;
    object _32325 = NOVALUE;
    object _32323 = NOVALUE;
    object _32319 = NOVALUE;
    object _32317 = NOVALUE;
    object _32316 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_65710)) {
        _1 = (object)(DBL_PTR(_x_65710)->dbl);
        DeRefDS(_x_65710);
        _x_65710 = _1;
    }

    /** execute.e:726		open_err_file()*/
    _67open_err_file();

    /** execute.e:727		a = Code[x]*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _x_65710);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:728		if length(SymTab[a]) >= S_NAME then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32316 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_SEQUENCE(_32316)){
            _32317 = SEQ_PTR(_32316)->length;
    }
    else {
        _32317 = 1;
    }
    _32316 = NOVALUE;
    if (binary_op_a(LESS, _32317, _12S_NAME_19864)){
        _32317 = NOVALUE;
        goto L1; // [32] 57
    }
    _32317 = NOVALUE;

    /** execute.e:729			vname = SymTab[a][S_NAME]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32319 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    DeRef(_vname_65713);
    _2 = (object)SEQ_PTR(_32319);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _vname_65713 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _vname_65713 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    Ref(_vname_65713);
    _32319 = NOVALUE;
    goto L2; // [54] 65
L1: 

    /** execute.e:732			vname = "inlined variable"*/
    RefDS(_32321);
    DeRef(_vname_65713);
    _vname_65713 = _32321;
L2: 

    /** execute.e:734		msg = sprintf("type_check failure, %s is ", {vname})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_vname_65713);
    ((intptr_t*)_2)[1] = _vname_65713;
    _32323 = MAKE_SEQ(_1);
    DeRefi(_msg_65711);
    _msg_65711 = EPrintf(-9999999, _32322, _32323);
    DeRefDS(_32323);
    _32323 = NOVALUE;

    /** execute.e:735		v = sprint(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _32325 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    Ref(_32325);
    _0 = _v_65712;
    _v_65712 = _18sprint(_32325);
    DeRef(_0);
    _32325 = NOVALUE;

    /** execute.e:736		if length(v) > 70 - length(vname) then*/
    if (IS_SEQUENCE(_v_65712)){
            _32327 = SEQ_PTR(_v_65712)->length;
    }
    else {
        _32327 = 1;
    }
    if (IS_SEQUENCE(_vname_65713)){
            _32329 = SEQ_PTR(_vname_65713)->length;
    }
    else {
        _32329 = 1;
    }
    _32330 = 70LL - _32329;
    _32329 = NOVALUE;
    if (_32327 <= _32330)
    goto L3; // [105] 180

    /** execute.e:737			v = v[1..70 - length(vname)]*/
    if (IS_SEQUENCE(_vname_65713)){
            _32332 = SEQ_PTR(_vname_65713)->length;
    }
    else {
        _32332 = 1;
    }
    _32333 = 70LL - _32332;
    _32332 = NOVALUE;
    rhs_slice_target = (object_ptr)&_v_65712;
    RHS_Slice(_v_65712, 1LL, _32333);

    /** execute.e:738			while length(v) and not find(v[$], ",}")  do*/
L4: 
    if (IS_SEQUENCE(_v_65712)){
            _32335 = SEQ_PTR(_v_65712)->length;
    }
    else {
        _32335 = 1;
    }
    if (_32335 == 0) {
        goto L5; // [131] 173
    }
    if (IS_SEQUENCE(_v_65712)){
            _32337 = SEQ_PTR(_v_65712)->length;
    }
    else {
        _32337 = 1;
    }
    _2 = (object)SEQ_PTR(_v_65712);
    _32338 = (object)*(((s1_ptr)_2)->base + _32337);
    _32340 = find_from(_32338, _32339, 1LL);
    _32338 = NOVALUE;
    _32341 = (_32340 == 0);
    _32340 = NOVALUE;
    if (_32341 == 0)
    {
        DeRef(_32341);
        _32341 = NOVALUE;
        goto L5; // [151] 173
    }
    else{
        DeRef(_32341);
        _32341 = NOVALUE;
    }

    /** execute.e:739				v = v[1..$-1]*/
    if (IS_SEQUENCE(_v_65712)){
            _32342 = SEQ_PTR(_v_65712)->length;
    }
    else {
        _32342 = 1;
    }
    _32343 = _32342 - 1LL;
    _32342 = NOVALUE;
    rhs_slice_target = (object_ptr)&_v_65712;
    RHS_Slice(_v_65712, 1LL, _32343);

    /** execute.e:740			end while*/
    goto L4; // [170] 128
L5: 

    /** execute.e:741			v = v & " ..."*/
    Concat((object_ptr)&_v_65712, _v_65712, _32345);
L3: 

    /** execute.e:743		trace_back(msg & v)*/
    Concat((object_ptr)&_32347, _msg_65711, _v_65712);
    _67trace_back(_32347);
    _32347 = NOVALUE;

    /** execute.e:744		call_crash_routines()*/
    _67call_crash_routines();

    /** execute.e:745		quit_after_error()*/
    _67quit_after_error();

    /** execute.e:746	end procedure*/
    DeRefDSi(_msg_65711);
    DeRefDS(_v_65712);
    DeRef(_vname_65713);
    _32316 = NOVALUE;
    DeRef(_32333);
    _32333 = NOVALUE;
    DeRef(_32330);
    _32330 = NOVALUE;
    DeRef(_32343);
    _32343 = NOVALUE;
    return;
    ;
}


void _67RTFatal(object _msg_65759)
{
    object _0, _1, _2;
    

    /** execute.e:750		open_err_file()*/
    _67open_err_file();

    /** execute.e:751		trace_back(msg)*/
    RefDS(_msg_65759);
    _67trace_back(_msg_65759);

    /** execute.e:752		call_crash_routines()*/
    _67call_crash_routines();

    /** execute.e:753		quit_after_error()*/
    _67quit_after_error();

    /** execute.e:754	end procedure*/
    DeRefDS(_msg_65759);
    return;
    ;
}


void _67RTInternal(object _msg_65762)
{
    object _0, _1, _2;
    

    /** execute.e:761		machine_proc(67, msg)*/
    machine(67LL, _msg_65762);

    /** execute.e:762	end procedure*/
    DeRefDSi(_msg_65762);
    return;
    ;
}


void _67wait(object _t_65765)
{
    object _t1_65766 = NOVALUE;
    object _t2_65767 = NOVALUE;
    object _32353 = NOVALUE;
    object _32351 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:771		t1 = floor(t)*/
    DeRef(_t1_65766);
    if (IS_ATOM_INT(_t_65765))
    _t1_65766 = e_floor(_t_65765);
    else
    _t1_65766 = unary_op(FLOOR, _t_65765);

    /** execute.e:772		if t1 >= 1 then*/
    if (binary_op_a(LESS, _t1_65766, 1LL)){
        goto L1; // [8] 24
    }

    /** execute.e:773			sleep(t1)*/
    Ref(_t1_65766);
    _3sleep(_t1_65766);

    /** execute.e:774			t -= t1*/
    _0 = _t_65765;
    if (IS_ATOM_INT(_t_65765) && IS_ATOM_INT(_t1_65766)) {
        _t_65765 = _t_65765 - _t1_65766;
        if ((object)((uintptr_t)_t_65765 +(uintptr_t) HIGH_BITS) >= 0){
            _t_65765 = NewDouble((eudouble)_t_65765);
        }
    }
    else {
        if (IS_ATOM_INT(_t_65765)) {
            _t_65765 = NewDouble((eudouble)_t_65765 - DBL_PTR(_t1_65766)->dbl);
        }
        else {
            if (IS_ATOM_INT(_t1_65766)) {
                _t_65765 = NewDouble(DBL_PTR(_t_65765)->dbl - (eudouble)_t1_65766);
            }
            else
            _t_65765 = NewDouble(DBL_PTR(_t_65765)->dbl - DBL_PTR(_t1_65766)->dbl);
        }
    }
    DeRef(_0);
L1: 

    /** execute.e:777		t2 = time() + t*/
    DeRef(_32351);
    _32351 = NewDouble(current_time());
    DeRef(_t2_65767);
    if (IS_ATOM_INT(_t_65765)) {
        _t2_65767 = NewDouble(DBL_PTR(_32351)->dbl + (eudouble)_t_65765);
    }
    else
    _t2_65767 = NewDouble(DBL_PTR(_32351)->dbl + DBL_PTR(_t_65765)->dbl);
    DeRefDS(_32351);
    _32351 = NOVALUE;

    /** execute.e:778		while time() < t2 do*/
L2: 
    DeRef(_32353);
    _32353 = NewDouble(current_time());
    if (binary_op_a(GREATEREQ, _32353, _t2_65767)){
        DeRefDS(_32353);
        _32353 = NOVALUE;
        goto L3; // [39] 48
    }
    DeRef(_32353);
    _32353 = NOVALUE;

    /** execute.e:779		end while*/
    goto L2; // [45] 37
L3: 

    /** execute.e:780	end procedure*/
    DeRef(_t_65765);
    DeRef(_t1_65766);
    DeRef(_t2_65767);
    return;
    ;
}


void _67scheduler()
{
    object _earliest_time_65783 = NOVALUE;
    object _start_time_65784 = NOVALUE;
    object _now_65785 = NOVALUE;
    object _ts_found_65787 = NOVALUE;
    object _tp_65788 = NOVALUE;
    object _p_65789 = NOVALUE;
    object _earliest_task_65790 = NOVALUE;
    object _32430 = NOVALUE;
    object _32429 = NOVALUE;
    object _32426 = NOVALUE;
    object _32425 = NOVALUE;
    object _32424 = NOVALUE;
    object _32423 = NOVALUE;
    object _32422 = NOVALUE;
    object _32420 = NOVALUE;
    object _32419 = NOVALUE;
    object _32417 = NOVALUE;
    object _32415 = NOVALUE;
    object _32413 = NOVALUE;
    object _32411 = NOVALUE;
    object _32409 = NOVALUE;
    object _32407 = NOVALUE;
    object _32404 = NOVALUE;
    object _32402 = NOVALUE;
    object _32401 = NOVALUE;
    object _32399 = NOVALUE;
    object _32398 = NOVALUE;
    object _32395 = NOVALUE;
    object _32393 = NOVALUE;
    object _32387 = NOVALUE;
    object _32383 = NOVALUE;
    object _32382 = NOVALUE;
    object _32380 = NOVALUE;
    object _32378 = NOVALUE;
    object _32376 = NOVALUE;
    object _32375 = NOVALUE;
    object _32374 = NOVALUE;
    object _32373 = NOVALUE;
    object _32372 = NOVALUE;
    object _32371 = NOVALUE;
    object _32370 = NOVALUE;
    object _32368 = NOVALUE;
    object _32363 = NOVALUE;
    object _32359 = NOVALUE;
    object _32357 = NOVALUE;
    object _32356 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:789		sequence tp*/

    /** execute.e:790		integer p, earliest_task*/

    /** execute.e:795		earliest_task = rt_first*/
    _earliest_task_65790 = _67rt_first_64924;

    /** execute.e:797		if clock_stopped or earliest_task = 0 then*/
    if (_67clock_stopped_65779 != 0) {
        goto L1; // [16] 29
    }
    _32356 = (_earliest_task_65790 == 0LL);
    if (_32356 == 0)
    {
        DeRef(_32356);
        _32356 = NOVALUE;
        goto L2; // [25] 42
    }
    else{
        DeRef(_32356);
        _32356 = NOVALUE;
    }
L1: 

    /** execute.e:799			start_time = 1*/
    DeRef(_start_time_65784);
    _start_time_65784 = 1LL;

    /** execute.e:800			now = -1*/
    DeRef(_now_65785);
    _now_65785 = -1LL;
    goto L3; // [39] 232
L2: 

    /** execute.e:804			earliest_time = tcb[earliest_task][TASK_MAX_TIME]*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32357 = (object)*(((s1_ptr)_2)->base + _earliest_task_65790);
    DeRef(_earliest_time_65783);
    _2 = (object)SEQ_PTR(_32357);
    _earliest_time_65783 = (object)*(((s1_ptr)_2)->base + 9LL);
    Ref(_earliest_time_65783);
    _32357 = NOVALUE;

    /** execute.e:806			p = tcb[rt_first][TASK_NEXT]*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32359 = (object)*(((s1_ptr)_2)->base + _67rt_first_64924);
    _2 = (object)SEQ_PTR(_32359);
    _p_65789 = (object)*(((s1_ptr)_2)->base + 12LL);
    if (!IS_ATOM_INT(_p_65789)){
        _p_65789 = (object)DBL_PTR(_p_65789)->dbl;
    }
    _32359 = NOVALUE;

    /** execute.e:807			while p != 0 do*/
L4: 
    if (_p_65789 == 0LL)
    goto L5; // [75] 122

    /** execute.e:808				tp = tcb[p]*/
    DeRef(_tp_65788);
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _tp_65788 = (object)*(((s1_ptr)_2)->base + _p_65789);
    RefDS(_tp_65788);

    /** execute.e:809				if tp[TASK_MAX_TIME] < earliest_time then*/
    _2 = (object)SEQ_PTR(_tp_65788);
    _32363 = (object)*(((s1_ptr)_2)->base + 9LL);
    if (binary_op_a(GREATEREQ, _32363, _earliest_time_65783)){
        _32363 = NOVALUE;
        goto L6; // [95] 111
    }
    _32363 = NOVALUE;

    /** execute.e:810					earliest_task = p*/
    _earliest_task_65790 = _p_65789;

    /** execute.e:811					earliest_time = tp[TASK_MAX_TIME]*/
    DeRef(_earliest_time_65783);
    _2 = (object)SEQ_PTR(_tp_65788);
    _earliest_time_65783 = (object)*(((s1_ptr)_2)->base + 9LL);
    Ref(_earliest_time_65783);
L6: 

    /** execute.e:813				p = tp[TASK_NEXT]*/
    _2 = (object)SEQ_PTR(_tp_65788);
    _p_65789 = (object)*(((s1_ptr)_2)->base + 12LL);
    if (!IS_ATOM_INT(_p_65789))
    _p_65789 = (object)DBL_PTR(_p_65789)->dbl;

    /** execute.e:814			end while*/
    goto L4; // [119] 75
L5: 

    /** execute.e:817			now = time()*/
    DeRef(_now_65785);
    _now_65785 = NewDouble(current_time());

    /** execute.e:819			start_time = tcb[earliest_task][TASK_MIN_TIME]*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32368 = (object)*(((s1_ptr)_2)->base + _earliest_task_65790);
    DeRef(_start_time_65784);
    _2 = (object)SEQ_PTR(_32368);
    _start_time_65784 = (object)*(((s1_ptr)_2)->base + 8LL);
    Ref(_start_time_65784);
    _32368 = NOVALUE;

    /** execute.e:821			if earliest_task = current_task and*/
    _32370 = (_earliest_task_65790 == _67current_task_64894);
    if (_32370 == 0) {
        goto L7; // [146] 173
    }
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32372 = (object)*(((s1_ptr)_2)->base + _67current_task_64894);
    _2 = (object)SEQ_PTR(_32372);
    _32373 = (object)*(((s1_ptr)_2)->base + 10LL);
    _32372 = NOVALUE;
    if (IS_ATOM_INT(_32373)) {
        _32374 = (_32373 > 0LL);
    }
    else {
        _32374 = binary_op(GREATER, _32373, 0LL);
    }
    _32373 = NOVALUE;
    if (_32374 == 0) {
        DeRef(_32374);
        _32374 = NOVALUE;
        goto L7; // [167] 173
    }
    else {
        if (!IS_ATOM_INT(_32374) && DBL_PTR(_32374)->dbl == 0.0){
            DeRef(_32374);
            _32374 = NOVALUE;
            goto L7; // [167] 173
        }
        DeRef(_32374);
        _32374 = NOVALUE;
    }
    DeRef(_32374);
    _32374 = NOVALUE;
    goto L8; // [170] 231
L7: 

    /** execute.e:825				if tcb[current_task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32375 = (object)*(((s1_ptr)_2)->base + _67current_task_64894);
    _2 = (object)SEQ_PTR(_32375);
    _32376 = (object)*(((s1_ptr)_2)->base + 3LL);
    _32375 = NOVALUE;
    if (binary_op_a(NOTEQ, _32376, 1LL)){
        _32376 = NOVALUE;
        goto L9; // [187] 207
    }
    _32376 = NOVALUE;

    /** execute.e:826					tcb[current_task][TASK_RUNS_LEFT] = 0*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64921 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_64894 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _32378 = NOVALUE;
L9: 

    /** execute.e:828				tcb[earliest_task][TASK_RUNS_LEFT] = tcb[earliest_task][TASK_RUNS_MAX]*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64921 = MAKE_SEQ(_2);
    }
    _3 = (object)(_earliest_task_65790 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32382 = (object)*(((s1_ptr)_2)->base + _earliest_task_65790);
    _2 = (object)SEQ_PTR(_32382);
    _32383 = (object)*(((s1_ptr)_2)->base + 11LL);
    _32382 = NOVALUE;
    Ref(_32383);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32383;
    if( _1 != _32383 ){
        DeRef(_1);
    }
    _32383 = NOVALUE;
    _32380 = NOVALUE;
L8: 
L3: 

    /** execute.e:832		if start_time > now then*/
    if (binary_op_a(LESSEQ, _start_time_65784, _now_65785)){
        goto LA; // [238] 416
    }

    /** execute.e:836			ts_found = FALSE*/
    _ts_found_65787 = _9FALSE_444;

    /** execute.e:837			p = ts_first*/
    _p_65789 = _67ts_first_64925;

    /** execute.e:838			while p != 0 do*/
LB: 
    if (_p_65789 == 0LL)
    goto LC; // [261] 313

    /** execute.e:839				tp = tcb[p]*/
    DeRef(_tp_65788);
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _tp_65788 = (object)*(((s1_ptr)_2)->base + _p_65789);
    RefDS(_tp_65788);

    /** execute.e:840				if tp[TASK_RUNS_LEFT] > 0 then*/
    _2 = (object)SEQ_PTR(_tp_65788);
    _32387 = (object)*(((s1_ptr)_2)->base + 10LL);
    if (binary_op_a(LESSEQ, _32387, 0LL)){
        _32387 = NOVALUE;
        goto LD; // [281] 302
    }
    _32387 = NOVALUE;

    /** execute.e:841					  earliest_task = p*/
    _earliest_task_65790 = _p_65789;

    /** execute.e:842					  ts_found = TRUE*/
    _ts_found_65787 = _9TRUE_446;

    /** execute.e:843					  exit*/
    goto LC; // [299] 313
LD: 

    /** execute.e:845				p = tp[TASK_NEXT]*/
    _2 = (object)SEQ_PTR(_tp_65788);
    _p_65789 = (object)*(((s1_ptr)_2)->base + 12LL);
    if (!IS_ATOM_INT(_p_65789))
    _p_65789 = (object)DBL_PTR(_p_65789)->dbl;

    /** execute.e:846			end while*/
    goto LB; // [310] 261
LC: 

    /** execute.e:848			if not ts_found then*/
    if (_ts_found_65787 != 0)
    goto LE; // [315] 378

    /** execute.e:851				p = ts_first*/
    _p_65789 = _67ts_first_64925;

    /** execute.e:852				while p != 0 do*/
LF: 
    if (_p_65789 == 0LL)
    goto L10; // [330] 377

    /** execute.e:853					tp = tcb[p]*/
    DeRef(_tp_65788);
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _tp_65788 = (object)*(((s1_ptr)_2)->base + _p_65789);
    RefDS(_tp_65788);

    /** execute.e:854					earliest_task = p*/
    _earliest_task_65790 = _p_65789;

    /** execute.e:855					tcb[p][TASK_RUNS_LEFT] = tp[TASK_RUNS_MAX]*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64921 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_65789 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_tp_65788);
    _32395 = (object)*(((s1_ptr)_2)->base + 11LL);
    Ref(_32395);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32395;
    if( _1 != _32395 ){
        DeRef(_1);
    }
    _32395 = NOVALUE;
    _32393 = NOVALUE;

    /** execute.e:856					p = tp[TASK_NEXT]*/
    _2 = (object)SEQ_PTR(_tp_65788);
    _p_65789 = (object)*(((s1_ptr)_2)->base + 12LL);
    if (!IS_ATOM_INT(_p_65789))
    _p_65789 = (object)DBL_PTR(_p_65789)->dbl;

    /** execute.e:857				end while*/
    goto LF; // [374] 330
L10: 
LE: 

    /** execute.e:860			if earliest_task = 0 then*/
    if (_earliest_task_65790 != 0LL)
    goto L11; // [380] 389

    /** execute.e:863				abort(0)*/
    UserCleanup(0LL);
L11: 

    /** execute.e:866			if tcb[earliest_task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32398 = (object)*(((s1_ptr)_2)->base + _earliest_task_65790);
    _2 = (object)SEQ_PTR(_32398);
    _32399 = (object)*(((s1_ptr)_2)->base + 3LL);
    _32398 = NOVALUE;
    if (binary_op_a(NOTEQ, _32399, 1LL)){
        _32399 = NOVALUE;
        goto L12; // [401] 415
    }
    _32399 = NOVALUE;

    /** execute.e:868				wait(start_time - now)*/
    if (IS_ATOM_INT(_start_time_65784) && IS_ATOM_INT(_now_65785)) {
        _32401 = _start_time_65784 - _now_65785;
        if ((object)((uintptr_t)_32401 +(uintptr_t) HIGH_BITS) >= 0){
            _32401 = NewDouble((eudouble)_32401);
        }
    }
    else {
        if (IS_ATOM_INT(_start_time_65784)) {
            _32401 = NewDouble((eudouble)_start_time_65784 - DBL_PTR(_now_65785)->dbl);
        }
        else {
            if (IS_ATOM_INT(_now_65785)) {
                _32401 = NewDouble(DBL_PTR(_start_time_65784)->dbl - (eudouble)_now_65785);
            }
            else
            _32401 = NewDouble(DBL_PTR(_start_time_65784)->dbl - DBL_PTR(_now_65785)->dbl);
        }
    }
    _67wait(_32401);
    _32401 = NOVALUE;
L12: 
LA: 

    /** execute.e:873		tcb[earliest_task][TASK_START] = time()*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64921 = MAKE_SEQ(_2);
    }
    _3 = (object)(_earliest_task_65790 + ((s1_ptr)_2)->base);
    DeRef(_32404);
    _32404 = NewDouble(current_time());
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32404;
    if( _1 != _32404 ){
        DeRef(_1);
    }
    _32404 = NOVALUE;
    _32402 = NOVALUE;

    /** execute.e:875		if earliest_task = current_task then*/
    if (_earliest_task_65790 != _67current_task_64894)
    goto L13; // [435] 450

    /** execute.e:876			pc += 1  -- continue with current task*/
    _67pc_64877 = _67pc_64877 + 1;
    goto L14; // [447] 663
L13: 

    /** execute.e:881			tcb[current_task][TASK_CODE] = Code*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64921 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_64894 + ((s1_ptr)_2)->base);
    RefDS(_12Code_20315);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12Code_20315;
    DeRef(_1);
    _32407 = NOVALUE;

    /** execute.e:882			tcb[current_task][TASK_PC] = pc*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64921 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_64894 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67pc_64877;
    DeRef(_1);
    _32409 = NOVALUE;

    /** execute.e:883			tcb[current_task][TASK_STACK] = call_stack*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64921 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_64894 + ((s1_ptr)_2)->base);
    RefDS(_67call_stack_64895);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 16LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67call_stack_64895;
    DeRef(_1);
    _32411 = NOVALUE;

    /** execute.e:886			Code = tcb[earliest_task][TASK_CODE]*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32413 = (object)*(((s1_ptr)_2)->base + _earliest_task_65790);
    DeRefDS(_12Code_20315);
    _2 = (object)SEQ_PTR(_32413);
    _12Code_20315 = (object)*(((s1_ptr)_2)->base + 15LL);
    Ref(_12Code_20315);
    _32413 = NOVALUE;

    /** execute.e:887			pc = tcb[earliest_task][TASK_PC]*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32415 = (object)*(((s1_ptr)_2)->base + _earliest_task_65790);
    _2 = (object)SEQ_PTR(_32415);
    _67pc_64877 = (object)*(((s1_ptr)_2)->base + 14LL);
    if (!IS_ATOM_INT(_67pc_64877)){
        _67pc_64877 = (object)DBL_PTR(_67pc_64877)->dbl;
    }
    _32415 = NOVALUE;

    /** execute.e:888			call_stack = tcb[earliest_task][TASK_STACK]*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32417 = (object)*(((s1_ptr)_2)->base + _earliest_task_65790);
    DeRefDS(_67call_stack_64895);
    _2 = (object)SEQ_PTR(_32417);
    _67call_stack_64895 = (object)*(((s1_ptr)_2)->base + 16LL);
    Ref(_67call_stack_64895);
    _32417 = NOVALUE;

    /** execute.e:890			current_task = earliest_task*/
    _67current_task_64894 = _earliest_task_65790;

    /** execute.e:892			if tcb[current_task][TASK_PC] = 0 then*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32419 = (object)*(((s1_ptr)_2)->base + _67current_task_64894);
    _2 = (object)SEQ_PTR(_32419);
    _32420 = (object)*(((s1_ptr)_2)->base + 14LL);
    _32419 = NOVALUE;
    if (binary_op_a(NOTEQ, _32420, 0LL)){
        _32420 = NOVALUE;
        goto L15; // [562] 639
    }
    _32420 = NOVALUE;

    /** execute.e:895				pc = 1*/
    _67pc_64877 = 1LL;

    /** execute.e:896				val[t_id] = tcb[current_task][TASK_RID]*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32422 = (object)*(((s1_ptr)_2)->base + _67current_task_64894);
    _2 = (object)SEQ_PTR(_32422);
    _32423 = (object)*(((s1_ptr)_2)->base + 1LL);
    _32422 = NOVALUE;
    Ref(_32423);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_id_64808);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32423;
    if( _1 != _32423 ){
        DeRef(_1);
    }
    _32423 = NOVALUE;

    /** execute.e:897				val[t_arglist] = tcb[current_task][TASK_ARGS]*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32424 = (object)*(((s1_ptr)_2)->base + _67current_task_64894);
    _2 = (object)SEQ_PTR(_32424);
    _32425 = (object)*(((s1_ptr)_2)->base + 13LL);
    _32424 = NOVALUE;
    Ref(_32425);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_arglist_64809);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32425;
    if( _1 != _32425 ){
        DeRef(_1);
    }
    _32425 = NOVALUE;

    /** execute.e:898				new_arg_assign()*/
    _32426 = _67new_arg_assign();

    /** execute.e:899				Code = {CALL_PROC, t_id, t_arglist}*/
    _0 = _12Code_20315;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 136LL;
    ((intptr_t*)_2)[2] = _67t_id_64808;
    ((intptr_t*)_2)[3] = _67t_arglist_64809;
    _12Code_20315 = MAKE_SEQ(_1);
    DeRefDS(_0);
    goto L16; // [636] 662
L15: 

    /** execute.e:902				pc += 1*/
    _67pc_64877 = _67pc_64877 + 1;

    /** execute.e:903				restore_privates(call_stack[$])*/
    if (IS_SEQUENCE(_67call_stack_64895)){
            _32429 = SEQ_PTR(_67call_stack_64895)->length;
    }
    else {
        _32429 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_64895);
    _32430 = (object)*(((s1_ptr)_2)->base + _32429);
    Ref(_32430);
    _67restore_privates(_32430);
    _32430 = NOVALUE;
L16: 
L14: 

    /** execute.e:906	end procedure*/
    DeRef(_earliest_time_65783);
    DeRef(_start_time_65784);
    DeRef(_now_65785);
    DeRef(_tp_65788);
    DeRef(_32370);
    _32370 = NOVALUE;
    DeRef(_32426);
    _32426 = NOVALUE;
    return;
    ;
}


object _67task_insert(object _first_65893, object _task_65894)
{
    object _32431 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:910		tcb[task][TASK_NEXT] = first*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64921 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_65894 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _first_65893;
    DeRef(_1);
    _32431 = NOVALUE;

    /** execute.e:911		return task*/
    return _task_65894;
    ;
}


object _67task_delete(object _first_65899, object _task_65900)
{
    object _p_65901 = NOVALUE;
    object _prev_p_65902 = NOVALUE;
    object _32442 = NOVALUE;
    object _32441 = NOVALUE;
    object _32440 = NOVALUE;
    object _32438 = NOVALUE;
    object _32437 = NOVALUE;
    object _32436 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:918		prev_p = -1*/
    _prev_p_65902 = -1LL;

    /** execute.e:919		p = first*/
    _p_65901 = _first_65899;

    /** execute.e:920		while p != 0 do*/
L1: 
    if (_p_65901 == 0LL)
    goto L2; // [20] 110

    /** execute.e:921			if p = task then*/
    if (_p_65901 != _task_65900)
    goto L3; // [26] 86

    /** execute.e:922				if prev_p = -1 then*/
    if (_prev_p_65902 != -1LL)
    goto L4; // [32] 55

    /** execute.e:924					return tcb[p][TASK_NEXT]*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32436 = (object)*(((s1_ptr)_2)->base + _p_65901);
    _2 = (object)SEQ_PTR(_32436);
    _32437 = (object)*(((s1_ptr)_2)->base + 12LL);
    _32436 = NOVALUE;
    Ref(_32437);
    return _32437;
    goto L5; // [52] 85
L4: 

    /** execute.e:927					tcb[prev_p][TASK_NEXT] = tcb[p][TASK_NEXT]*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64921 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_p_65902 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32440 = (object)*(((s1_ptr)_2)->base + _p_65901);
    _2 = (object)SEQ_PTR(_32440);
    _32441 = (object)*(((s1_ptr)_2)->base + 12LL);
    _32440 = NOVALUE;
    Ref(_32441);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32441;
    if( _1 != _32441 ){
        DeRef(_1);
    }
    _32441 = NOVALUE;
    _32438 = NOVALUE;

    /** execute.e:928					return first*/
    _32437 = NOVALUE;
    return _first_65899;
L5: 
L3: 

    /** execute.e:931			prev_p = p*/
    _prev_p_65902 = _p_65901;

    /** execute.e:932			p = tcb[p][TASK_NEXT]*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32442 = (object)*(((s1_ptr)_2)->base + _p_65901);
    _2 = (object)SEQ_PTR(_32442);
    _p_65901 = (object)*(((s1_ptr)_2)->base + 12LL);
    if (!IS_ATOM_INT(_p_65901)){
        _p_65901 = (object)DBL_PTR(_p_65901)->dbl;
    }
    _32442 = NOVALUE;

    /** execute.e:933		end while*/
    goto L1; // [107] 20
L2: 

    /** execute.e:935		return first*/
    _32437 = NOVALUE;
    return _first_65899;
    ;
}


void _67opTASK_YIELD()
{
    object _now_65920 = NOVALUE;
    object _32492 = NOVALUE;
    object _32491 = NOVALUE;
    object _32490 = NOVALUE;
    object _32488 = NOVALUE;
    object _32487 = NOVALUE;
    object _32486 = NOVALUE;
    object _32485 = NOVALUE;
    object _32483 = NOVALUE;
    object _32482 = NOVALUE;
    object _32481 = NOVALUE;
    object _32480 = NOVALUE;
    object _32478 = NOVALUE;
    object _32477 = NOVALUE;
    object _32476 = NOVALUE;
    object _32475 = NOVALUE;
    object _32473 = NOVALUE;
    object _32472 = NOVALUE;
    object _32471 = NOVALUE;
    object _32469 = NOVALUE;
    object _32466 = NOVALUE;
    object _32465 = NOVALUE;
    object _32464 = NOVALUE;
    object _32463 = NOVALUE;
    object _32462 = NOVALUE;
    object _32461 = NOVALUE;
    object _32460 = NOVALUE;
    object _32459 = NOVALUE;
    object _32458 = NOVALUE;
    object _32455 = NOVALUE;
    object _32454 = NOVALUE;
    object _32453 = NOVALUE;
    object _32452 = NOVALUE;
    object _32450 = NOVALUE;
    object _32448 = NOVALUE;
    object _32447 = NOVALUE;
    object _32445 = NOVALUE;
    object _32444 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:943		if tcb[current_task][TASK_STATE] = ST_ACTIVE then*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32444 = (object)*(((s1_ptr)_2)->base + _67current_task_64894);
    _2 = (object)SEQ_PTR(_32444);
    _32445 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32444 = NOVALUE;
    if (binary_op_a(NOTEQ, _32445, 0LL)){
        _32445 = NOVALUE;
        goto L1; // [15] 312
    }
    _32445 = NOVALUE;

    /** execute.e:944			if tcb[current_task][TASK_RUNS_LEFT] > 0 then*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32447 = (object)*(((s1_ptr)_2)->base + _67current_task_64894);
    _2 = (object)SEQ_PTR(_32447);
    _32448 = (object)*(((s1_ptr)_2)->base + 10LL);
    _32447 = NOVALUE;
    if (binary_op_a(LESSEQ, _32448, 0LL)){
        _32448 = NOVALUE;
        goto L2; // [33] 61
    }
    _32448 = NOVALUE;

    /** execute.e:945				tcb[current_task][TASK_RUNS_LEFT] -= 1*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64921 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_64894 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _32452 = (object)*(((s1_ptr)_2)->base + 10LL);
    _32450 = NOVALUE;
    if (IS_ATOM_INT(_32452)) {
        _32453 = _32452 - 1LL;
        if ((object)((uintptr_t)_32453 +(uintptr_t) HIGH_BITS) >= 0){
            _32453 = NewDouble((eudouble)_32453);
        }
    }
    else {
        _32453 = binary_op(MINUS, _32452, 1LL);
    }
    _32452 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32453;
    if( _1 != _32453 ){
        DeRef(_1);
    }
    _32453 = NOVALUE;
    _32450 = NOVALUE;
L2: 

    /** execute.e:947			if tcb[current_task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32454 = (object)*(((s1_ptr)_2)->base + _67current_task_64894);
    _2 = (object)SEQ_PTR(_32454);
    _32455 = (object)*(((s1_ptr)_2)->base + 3LL);
    _32454 = NOVALUE;
    if (binary_op_a(NOTEQ, _32455, 1LL)){
        _32455 = NOVALUE;
        goto L3; // [75] 311
    }
    _32455 = NOVALUE;

    /** execute.e:948				now = time()*/
    DeRef(_now_65920);
    _now_65920 = NewDouble(current_time());

    /** execute.e:949				if tcb[current_task][TASK_RUNS_MAX] > 1 and*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32458 = (object)*(((s1_ptr)_2)->base + _67current_task_64894);
    _2 = (object)SEQ_PTR(_32458);
    _32459 = (object)*(((s1_ptr)_2)->base + 11LL);
    _32458 = NOVALUE;
    if (IS_ATOM_INT(_32459)) {
        _32460 = (_32459 > 1LL);
    }
    else {
        _32460 = binary_op(GREATER, _32459, 1LL);
    }
    _32459 = NOVALUE;
    if (IS_ATOM_INT(_32460)) {
        if (_32460 == 0) {
            goto L4; // [101] 247
        }
    }
    else {
        if (DBL_PTR(_32460)->dbl == 0.0) {
            goto L4; // [101] 247
        }
    }
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32462 = (object)*(((s1_ptr)_2)->base + _67current_task_64894);
    _2 = (object)SEQ_PTR(_32462);
    _32463 = (object)*(((s1_ptr)_2)->base + 5LL);
    _32462 = NOVALUE;
    _32464 = binary_op(EQUALS, _32463, _now_65920);
    _32463 = NOVALUE;
    if (_32464 == 0) {
        DeRef(_32464);
        _32464 = NOVALUE;
        goto L4; // [122] 247
    }
    else {
        if (!IS_ATOM_INT(_32464) && DBL_PTR(_32464)->dbl == 0.0){
            DeRef(_32464);
            _32464 = NOVALUE;
            goto L4; // [122] 247
        }
        DeRef(_32464);
        _32464 = NOVALUE;
    }
    DeRef(_32464);
    _32464 = NOVALUE;

    /** execute.e:952					if tcb[current_task][TASK_RUNS_LEFT] = 0 then*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32465 = (object)*(((s1_ptr)_2)->base + _67current_task_64894);
    _2 = (object)SEQ_PTR(_32465);
    _32466 = (object)*(((s1_ptr)_2)->base + 10LL);
    _32465 = NOVALUE;
    if (binary_op_a(NOTEQ, _32466, 0LL)){
        _32466 = NOVALUE;
        goto L5; // [139] 310
    }
    _32466 = NOVALUE;

    /** execute.e:954						now += clock_period*/
    _0 = _now_65920;
    if (IS_ATOM_INT(_now_65920)) {
        _now_65920 = NewDouble((eudouble)_now_65920 + DBL_PTR(_67clock_period_64897)->dbl);
    }
    else {
        _now_65920 = NewDouble(DBL_PTR(_now_65920)->dbl + DBL_PTR(_67clock_period_64897)->dbl);
    }
    DeRef(_0);

    /** execute.e:955						tcb[current_task][TASK_RUNS_LEFT] = tcb[current_task][TASK_RUNS_MAX]*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64921 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_64894 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32471 = (object)*(((s1_ptr)_2)->base + _67current_task_64894);
    _2 = (object)SEQ_PTR(_32471);
    _32472 = (object)*(((s1_ptr)_2)->base + 11LL);
    _32471 = NOVALUE;
    Ref(_32472);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32472;
    if( _1 != _32472 ){
        DeRef(_1);
    }
    _32472 = NOVALUE;
    _32469 = NOVALUE;

    /** execute.e:956						tcb[current_task][TASK_MIN_TIME] = now +*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64921 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_64894 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32475 = (object)*(((s1_ptr)_2)->base + _67current_task_64894);
    _2 = (object)SEQ_PTR(_32475);
    _32476 = (object)*(((s1_ptr)_2)->base + 6LL);
    _32475 = NOVALUE;
    _32477 = binary_op(PLUS, _now_65920, _32476);
    _32476 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 8LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32477;
    if( _1 != _32477 ){
        DeRef(_1);
    }
    _32477 = NOVALUE;
    _32473 = NOVALUE;

    /** execute.e:958						tcb[current_task][TASK_MAX_TIME] = now +*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64921 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_64894 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32480 = (object)*(((s1_ptr)_2)->base + _67current_task_64894);
    _2 = (object)SEQ_PTR(_32480);
    _32481 = (object)*(((s1_ptr)_2)->base + 7LL);
    _32480 = NOVALUE;
    _32482 = binary_op(PLUS, _now_65920, _32481);
    _32481 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32482;
    if( _1 != _32482 ){
        DeRef(_1);
    }
    _32482 = NOVALUE;
    _32478 = NOVALUE;
    goto L5; // [240] 310
    goto L5; // [244] 310
L4: 

    /** execute.e:965					tcb[current_task][TASK_MIN_TIME] = now +*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64921 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_64894 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32485 = (object)*(((s1_ptr)_2)->base + _67current_task_64894);
    _2 = (object)SEQ_PTR(_32485);
    _32486 = (object)*(((s1_ptr)_2)->base + 6LL);
    _32485 = NOVALUE;
    if (IS_ATOM_INT(_now_65920) && IS_ATOM_INT(_32486)) {
        _32487 = _now_65920 + _32486;
        if ((object)((uintptr_t)_32487 + (uintptr_t)HIGH_BITS) >= 0){
            _32487 = NewDouble((eudouble)_32487);
        }
    }
    else {
        _32487 = binary_op(PLUS, _now_65920, _32486);
    }
    _32486 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 8LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32487;
    if( _1 != _32487 ){
        DeRef(_1);
    }
    _32487 = NOVALUE;
    _32483 = NOVALUE;

    /** execute.e:967					tcb[current_task][TASK_MAX_TIME] = now +*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64921 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_64894 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32490 = (object)*(((s1_ptr)_2)->base + _67current_task_64894);
    _2 = (object)SEQ_PTR(_32490);
    _32491 = (object)*(((s1_ptr)_2)->base + 7LL);
    _32490 = NOVALUE;
    if (IS_ATOM_INT(_now_65920) && IS_ATOM_INT(_32491)) {
        _32492 = _now_65920 + _32491;
        if ((object)((uintptr_t)_32492 + (uintptr_t)HIGH_BITS) >= 0){
            _32492 = NewDouble((eudouble)_32492);
        }
    }
    else {
        _32492 = binary_op(PLUS, _now_65920, _32491);
    }
    _32491 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32492;
    if( _1 != _32492 ){
        DeRef(_1);
    }
    _32492 = NOVALUE;
    _32488 = NOVALUE;
L5: 
L3: 
L1: 

    /** execute.e:972		scheduler()*/
    _67scheduler();

    /** execute.e:973	end procedure*/
    DeRef(_now_65920);
    DeRef(_32460);
    _32460 = NOVALUE;
    return;
    ;
}


void _67kill_task(object _task_65979)
{
    object _32498 = NOVALUE;
    object _32494 = NOVALUE;
    object _32493 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:977		if tcb[task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32493 = (object)*(((s1_ptr)_2)->base + _task_65979);
    _2 = (object)SEQ_PTR(_32493);
    _32494 = (object)*(((s1_ptr)_2)->base + 3LL);
    _32493 = NOVALUE;
    if (binary_op_a(NOTEQ, _32494, 1LL)){
        _32494 = NOVALUE;
        goto L1; // [15] 33
    }
    _32494 = NOVALUE;

    /** execute.e:978			rt_first = task_delete(rt_first, task)*/
    _0 = _67task_delete(_67rt_first_64924, _task_65979);
    _67rt_first_64924 = _0;
    if (!IS_ATOM_INT(_67rt_first_64924)) {
        _1 = (object)(DBL_PTR(_67rt_first_64924)->dbl);
        DeRefDS(_67rt_first_64924);
        _67rt_first_64924 = _1;
    }
    goto L2; // [30] 45
L1: 

    /** execute.e:980			ts_first = task_delete(ts_first, task)*/
    _0 = _67task_delete(_67ts_first_64925, _task_65979);
    _67ts_first_64925 = _0;
    if (!IS_ATOM_INT(_67ts_first_64925)) {
        _1 = (object)(DBL_PTR(_67ts_first_64925)->dbl);
        DeRefDS(_67ts_first_64925);
        _67ts_first_64925 = _1;
    }
L2: 

    /** execute.e:982		tcb[task][TASK_STATE] = ST_DEAD*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64921 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_65979 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _32498 = NOVALUE;

    /** execute.e:984	end procedure*/
    return;
    ;
}


object _67which_task(object _tid_65991)
{
    object _32502 = NOVALUE;
    object _32501 = NOVALUE;
    object _32500 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:989		for i = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_64921)){
            _32500 = SEQ_PTR(_67tcb_64921)->length;
    }
    else {
        _32500 = 1;
    }
    {
        object _i_65993;
        _i_65993 = 1LL;
L1: 
        if (_i_65993 > _32500){
            goto L2; // [8] 45
        }

        /** execute.e:990			if tcb[i][TASK_TID] = tid then*/
        _2 = (object)SEQ_PTR(_67tcb_64921);
        _32501 = (object)*(((s1_ptr)_2)->base + _i_65993);
        _2 = (object)SEQ_PTR(_32501);
        _32502 = (object)*(((s1_ptr)_2)->base + 2LL);
        _32501 = NOVALUE;
        if (binary_op_a(NOTEQ, _32502, _tid_65991)){
            _32502 = NOVALUE;
            goto L3; // [27] 38
        }
        _32502 = NOVALUE;

        /** execute.e:991				return i*/
        DeRef(_tid_65991);
        return _i_65993;
L3: 

        /** execute.e:993		end for*/
        _i_65993 = _i_65993 + 1LL;
        goto L1; // [40] 15
L2: 
        ;
    }

    /** execute.e:994		RTFatal("invalid task id")*/
    RefDS(_32504);
    _67RTFatal(_32504);
    ;
}


void _67opTASK_STATUS()
{
    object _r_66002 = NOVALUE;
    object _tid_66003 = NOVALUE;
    object _32518 = NOVALUE;
    object _32517 = NOVALUE;
    object _32515 = NOVALUE;
    object _32514 = NOVALUE;
    object _32512 = NOVALUE;
    object _32511 = NOVALUE;
    object _32510 = NOVALUE;
    object _32507 = NOVALUE;
    object _32505 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1003		a = Code[pc+1]*/
    _32505 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _32505);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:1004		target = Code[pc+2]*/
    _32507 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _32507);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:1005		tid = val[a]*/
    DeRef(_tid_66003);
    _2 = (object)SEQ_PTR(_67val_64887);
    _tid_66003 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    Ref(_tid_66003);

    /** execute.e:1006		r = -1*/
    _r_66002 = -1LL;

    /** execute.e:1007		for t = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_64921)){
            _32510 = SEQ_PTR(_67tcb_64921)->length;
    }
    else {
        _32510 = 1;
    }
    {
        object _t_66012;
        _t_66012 = 1LL;
L1: 
        if (_t_66012 > _32510){
            goto L2; // [55] 137
        }

        /** execute.e:1008			if tcb[t][TASK_TID] = tid then*/
        _2 = (object)SEQ_PTR(_67tcb_64921);
        _32511 = (object)*(((s1_ptr)_2)->base + _t_66012);
        _2 = (object)SEQ_PTR(_32511);
        _32512 = (object)*(((s1_ptr)_2)->base + 2LL);
        _32511 = NOVALUE;
        if (binary_op_a(NOTEQ, _32512, _tid_66003)){
            _32512 = NOVALUE;
            goto L3; // [74] 130
        }
        _32512 = NOVALUE;

        /** execute.e:1009				if tcb[t][TASK_STATE] = ST_ACTIVE then*/
        _2 = (object)SEQ_PTR(_67tcb_64921);
        _32514 = (object)*(((s1_ptr)_2)->base + _t_66012);
        _2 = (object)SEQ_PTR(_32514);
        _32515 = (object)*(((s1_ptr)_2)->base + 4LL);
        _32514 = NOVALUE;
        if (binary_op_a(NOTEQ, _32515, 0LL)){
            _32515 = NOVALUE;
            goto L4; // [90] 102
        }
        _32515 = NOVALUE;

        /** execute.e:1010					r = 1*/
        _r_66002 = 1LL;
        goto L2; // [99] 137
L4: 

        /** execute.e:1011				elsif tcb[t][TASK_STATE] = ST_SUSPENDED then*/
        _2 = (object)SEQ_PTR(_67tcb_64921);
        _32517 = (object)*(((s1_ptr)_2)->base + _t_66012);
        _2 = (object)SEQ_PTR(_32517);
        _32518 = (object)*(((s1_ptr)_2)->base + 4LL);
        _32517 = NOVALUE;
        if (binary_op_a(NOTEQ, _32518, 1LL)){
            _32518 = NOVALUE;
            goto L2; // [114] 137
        }
        _32518 = NOVALUE;

        /** execute.e:1012					r = 0*/
        _r_66002 = 0LL;

        /** execute.e:1014				exit*/
        goto L2; // [127] 137
L3: 

        /** execute.e:1016		end for*/
        _t_66012 = _t_66012 + 1LL;
        goto L1; // [132] 62
L2: 
        ;
    }

    /** execute.e:1017		val[target] = r*/
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_66002;
    DeRef(_1);

    /** execute.e:1018		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:1019	end procedure*/
    DeRef(_tid_66003);
    DeRef(_32507);
    _32507 = NOVALUE;
    DeRef(_32505);
    _32505 = NOVALUE;
    return;
    ;
}


void _67opTASK_LIST()
{
    object _list_66029 = NOVALUE;
    object _32528 = NOVALUE;
    object _32527 = NOVALUE;
    object _32525 = NOVALUE;
    object _32524 = NOVALUE;
    object _32523 = NOVALUE;
    object _32521 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1025		target = Code[pc+1]*/
    _32521 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _32521);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:1026		list = {}*/
    RefDS(_22024);
    DeRef(_list_66029);
    _list_66029 = _22024;

    /** execute.e:1027		for i = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_64921)){
            _32523 = SEQ_PTR(_67tcb_64921)->length;
    }
    else {
        _32523 = 1;
    }
    {
        object _i_66034;
        _i_66034 = 1LL;
L1: 
        if (_i_66034 > _32523){
            goto L2; // [31] 78
        }

        /** execute.e:1028			if tcb[i][TASK_STATE] != ST_DEAD then*/
        _2 = (object)SEQ_PTR(_67tcb_64921);
        _32524 = (object)*(((s1_ptr)_2)->base + _i_66034);
        _2 = (object)SEQ_PTR(_32524);
        _32525 = (object)*(((s1_ptr)_2)->base + 4LL);
        _32524 = NOVALUE;
        if (binary_op_a(EQUALS, _32525, 2LL)){
            _32525 = NOVALUE;
            goto L3; // [50] 71
        }
        _32525 = NOVALUE;

        /** execute.e:1029				list = append(list, tcb[i][TASK_TID])*/
        _2 = (object)SEQ_PTR(_67tcb_64921);
        _32527 = (object)*(((s1_ptr)_2)->base + _i_66034);
        _2 = (object)SEQ_PTR(_32527);
        _32528 = (object)*(((s1_ptr)_2)->base + 2LL);
        _32527 = NOVALUE;
        Ref(_32528);
        Append(&_list_66029, _list_66029, _32528);
        _32528 = NOVALUE;
L3: 

        /** execute.e:1031		end for*/
        _i_66034 = _i_66034 + 1LL;
        goto L1; // [73] 38
L2: 
        ;
    }

    /** execute.e:1032		val[target] = list*/
    RefDS(_list_66029);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _list_66029;
    DeRef(_1);

    /** execute.e:1033		pc += 2*/
    _67pc_64877 = _67pc_64877 + 2LL;

    /** execute.e:1034	end procedure*/
    DeRefDS(_list_66029);
    DeRef(_32521);
    _32521 = NOVALUE;
    return;
    ;
}


void _67opTASK_SELF()
{
    object _32534 = NOVALUE;
    object _32533 = NOVALUE;
    object _32531 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1038		target = Code[pc+1]*/
    _32531 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _32531);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:1039		val[target] = tcb[current_task][TASK_TID]*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32533 = (object)*(((s1_ptr)_2)->base + _67current_task_64894);
    _2 = (object)SEQ_PTR(_32533);
    _32534 = (object)*(((s1_ptr)_2)->base + 2LL);
    _32533 = NOVALUE;
    Ref(_32534);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32534;
    if( _1 != _32534 ){
        DeRef(_1);
    }
    _32534 = NOVALUE;

    /** execute.e:1040		pc += 2*/
    _67pc_64877 = _67pc_64877 + 2LL;

    /** execute.e:1041	end procedure*/
    _32531 = NOVALUE;
    return;
    ;
}


void _67opTASK_CLOCK_STOP()
{
    object _0, _1, _2;
    

    /** execute.e:1048		if not clock_stopped then*/
    if (_67clock_stopped_65779 != 0)
    goto L1; // [5] 20

    /** execute.e:1049			save_clock = time()*/
    DeRef(_67save_clock_66052);
    _67save_clock_66052 = NewDouble(current_time());

    /** execute.e:1050			clock_stopped = TRUE*/
    _67clock_stopped_65779 = _9TRUE_446;
L1: 

    /** execute.e:1052		pc += 1*/
    _67pc_64877 = _67pc_64877 + 1;

    /** execute.e:1053	end procedure*/
    return;
    ;
}


void _67opTASK_CLOCK_START()
{
    object _shift_66062 = NOVALUE;
    object _32553 = NOVALUE;
    object _32552 = NOVALUE;
    object _32550 = NOVALUE;
    object _32549 = NOVALUE;
    object _32548 = NOVALUE;
    object _32546 = NOVALUE;
    object _32545 = NOVALUE;
    object _32543 = NOVALUE;
    object _32542 = NOVALUE;
    object _32541 = NOVALUE;
    object _32540 = NOVALUE;
    object _32539 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1059		if clock_stopped then*/
    if (_67clock_stopped_65779 == 0)
    {
        goto L1; // [5] 114
    }
    else{
    }

    /** execute.e:1060			if save_clock >= 0 and save_clock < time() then*/
    if (IS_ATOM_INT(_67save_clock_66052)) {
        _32539 = (_67save_clock_66052 >= 0LL);
    }
    else {
        _32539 = (DBL_PTR(_67save_clock_66052)->dbl >= (eudouble)0LL);
    }
    if (_32539 == 0) {
        goto L2; // [16] 106
    }
    _32541 = NewDouble(current_time());
    if (IS_ATOM_INT(_67save_clock_66052)) {
        _32542 = ((eudouble)_67save_clock_66052 < DBL_PTR(_32541)->dbl);
    }
    else {
        _32542 = (DBL_PTR(_67save_clock_66052)->dbl < DBL_PTR(_32541)->dbl);
    }
    DeRefDS(_32541);
    _32541 = NOVALUE;
    if (_32542 == 0)
    {
        DeRef(_32542);
        _32542 = NOVALUE;
        goto L2; // [29] 106
    }
    else{
        DeRef(_32542);
        _32542 = NOVALUE;
    }

    /** execute.e:1061				shift = time() - save_clock*/
    DeRef(_32543);
    _32543 = NewDouble(current_time());
    DeRef(_shift_66062);
    if (IS_ATOM_INT(_67save_clock_66052)) {
        _shift_66062 = NewDouble(DBL_PTR(_32543)->dbl - (eudouble)_67save_clock_66052);
    }
    else
    _shift_66062 = NewDouble(DBL_PTR(_32543)->dbl - DBL_PTR(_67save_clock_66052)->dbl);
    DeRefDS(_32543);
    _32543 = NOVALUE;

    /** execute.e:1062				for i = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_64921)){
            _32545 = SEQ_PTR(_67tcb_64921)->length;
    }
    else {
        _32545 = 1;
    }
    {
        object _i_66072;
        _i_66072 = 1LL;
L3: 
        if (_i_66072 > _32545){
            goto L4; // [49] 105
        }

        /** execute.e:1063					tcb[i][TASK_MIN_TIME] += shift*/
        _2 = (object)SEQ_PTR(_67tcb_64921);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67tcb_64921 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_66072 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _32548 = (object)*(((s1_ptr)_2)->base + 8LL);
        _32546 = NOVALUE;
        if (IS_ATOM_INT(_32548) && IS_ATOM_INT(_shift_66062)) {
            _32549 = _32548 + _shift_66062;
            if ((object)((uintptr_t)_32549 + (uintptr_t)HIGH_BITS) >= 0){
                _32549 = NewDouble((eudouble)_32549);
            }
        }
        else {
            _32549 = binary_op(PLUS, _32548, _shift_66062);
        }
        _32548 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 8LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _32549;
        if( _1 != _32549 ){
            DeRef(_1);
        }
        _32549 = NOVALUE;
        _32546 = NOVALUE;

        /** execute.e:1064					tcb[i][TASK_MAX_TIME] += shift*/
        _2 = (object)SEQ_PTR(_67tcb_64921);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67tcb_64921 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_66072 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _32552 = (object)*(((s1_ptr)_2)->base + 9LL);
        _32550 = NOVALUE;
        if (IS_ATOM_INT(_32552) && IS_ATOM_INT(_shift_66062)) {
            _32553 = _32552 + _shift_66062;
            if ((object)((uintptr_t)_32553 + (uintptr_t)HIGH_BITS) >= 0){
                _32553 = NewDouble((eudouble)_32553);
            }
        }
        else {
            _32553 = binary_op(PLUS, _32552, _shift_66062);
        }
        _32552 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 9LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _32553;
        if( _1 != _32553 ){
            DeRef(_1);
        }
        _32553 = NOVALUE;
        _32550 = NOVALUE;

        /** execute.e:1065				end for*/
        _i_66072 = _i_66072 + 1LL;
        goto L3; // [100] 56
L4: 
        ;
    }
L2: 

    /** execute.e:1067			clock_stopped = FALSE*/
    _67clock_stopped_65779 = _9FALSE_444;
L1: 

    /** execute.e:1069		pc += 1*/
    _67pc_64877 = _67pc_64877 + 1;

    /** execute.e:1070	end procedure*/
    DeRef(_shift_66062);
    DeRef(_32539);
    _32539 = NOVALUE;
    return;
    ;
}


void _67opTASK_SUSPEND()
{
    object _task_66086 = NOVALUE;
    object _32564 = NOVALUE;
    object _32563 = NOVALUE;
    object _32561 = NOVALUE;
    object _32559 = NOVALUE;
    object _32557 = NOVALUE;
    object _32555 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1076		a = Code[pc+1]*/
    _32555 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _32555);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:1077		task = which_task(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _32557 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    Ref(_32557);
    _task_66086 = _67which_task(_32557);
    _32557 = NOVALUE;
    if (!IS_ATOM_INT(_task_66086)) {
        _1 = (object)(DBL_PTR(_task_66086)->dbl);
        DeRefDS(_task_66086);
        _task_66086 = _1;
    }

    /** execute.e:1078		tcb[task][TASK_STATE] = ST_SUSPENDED*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64921 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66086 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _32559 = NOVALUE;

    /** execute.e:1079		tcb[task][TASK_MAX_TIME] = TASK_NEVER*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64921 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66086 + ((s1_ptr)_2)->base);
    RefDS(_67TASK_NEVER_64888);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67TASK_NEVER_64888;
    DeRef(_1);
    _32561 = NOVALUE;

    /** execute.e:1080		if tcb[task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32563 = (object)*(((s1_ptr)_2)->base + _task_66086);
    _2 = (object)SEQ_PTR(_32563);
    _32564 = (object)*(((s1_ptr)_2)->base + 3LL);
    _32563 = NOVALUE;
    if (binary_op_a(NOTEQ, _32564, 1LL)){
        _32564 = NOVALUE;
        goto L1; // [71] 89
    }
    _32564 = NOVALUE;

    /** execute.e:1081			rt_first = task_delete(rt_first, task)*/
    _0 = _67task_delete(_67rt_first_64924, _task_66086);
    _67rt_first_64924 = _0;
    if (!IS_ATOM_INT(_67rt_first_64924)) {
        _1 = (object)(DBL_PTR(_67rt_first_64924)->dbl);
        DeRefDS(_67rt_first_64924);
        _67rt_first_64924 = _1;
    }
    goto L2; // [86] 101
L1: 

    /** execute.e:1083			ts_first = task_delete(ts_first, task)*/
    _0 = _67task_delete(_67ts_first_64925, _task_66086);
    _67ts_first_64925 = _0;
    if (!IS_ATOM_INT(_67ts_first_64925)) {
        _1 = (object)(DBL_PTR(_67ts_first_64925)->dbl);
        DeRefDS(_67ts_first_64925);
        _67ts_first_64925 = _1;
    }
L2: 

    /** execute.e:1085		pc += 2*/
    _67pc_64877 = _67pc_64877 + 2LL;

    /** execute.e:1086	end procedure*/
    DeRef(_32555);
    _32555 = NOVALUE;
    return;
    ;
}


void _67opTASK_CREATE()
{
    object _sub_66107 = NOVALUE;
    object _new_entry_66108 = NOVALUE;
    object _recycle_66110 = NOVALUE;
    object _32604 = NOVALUE;
    object _32603 = NOVALUE;
    object _32602 = NOVALUE;
    object _32600 = NOVALUE;
    object _32599 = NOVALUE;
    object _32598 = NOVALUE;
    object _32596 = NOVALUE;
    object _32592 = NOVALUE;
    object _32591 = NOVALUE;
    object _32590 = NOVALUE;
    object _32588 = NOVALUE;
    object _32587 = NOVALUE;
    object _32585 = NOVALUE;
    object _32582 = NOVALUE;
    object _32581 = NOVALUE;
    object _32579 = NOVALUE;
    object _32578 = NOVALUE;
    object _32576 = NOVALUE;
    object _32575 = NOVALUE;
    object _32574 = NOVALUE;
    object _32572 = NOVALUE;
    object _32571 = NOVALUE;
    object _32569 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1091		sequence new_entry*/

    /** execute.e:1094		a = Code[pc+1] -- routine id*/
    _32569 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _32569);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:1095		if val[a] < 0 or val[a] >= length(e_routine) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _32571 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_ATOM_INT(_32571)) {
        _32572 = (_32571 < 0LL);
    }
    else {
        _32572 = binary_op(LESS, _32571, 0LL);
    }
    _32571 = NOVALUE;
    if (IS_ATOM_INT(_32572)) {
        if (_32572 != 0) {
            goto L1; // [33] 59
        }
    }
    else {
        if (DBL_PTR(_32572)->dbl != 0.0) {
            goto L1; // [33] 59
        }
    }
    _2 = (object)SEQ_PTR(_67val_64887);
    _32574 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_SEQUENCE(_67e_routine_64926)){
            _32575 = SEQ_PTR(_67e_routine_64926)->length;
    }
    else {
        _32575 = 1;
    }
    if (IS_ATOM_INT(_32574)) {
        _32576 = (_32574 >= _32575);
    }
    else {
        _32576 = binary_op(GREATEREQ, _32574, _32575);
    }
    _32574 = NOVALUE;
    _32575 = NOVALUE;
    if (_32576 == 0) {
        DeRef(_32576);
        _32576 = NOVALUE;
        goto L2; // [55] 65
    }
    else {
        if (!IS_ATOM_INT(_32576) && DBL_PTR(_32576)->dbl == 0.0){
            DeRef(_32576);
            _32576 = NOVALUE;
            goto L2; // [55] 65
        }
        DeRef(_32576);
        _32576 = NOVALUE;
    }
    DeRef(_32576);
    _32576 = NOVALUE;
L1: 

    /** execute.e:1096			RTFatal("invalid routine id")*/
    RefDS(_32577);
    _67RTFatal(_32577);
L2: 

    /** execute.e:1098		sub = e_routine[val[a]+1]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _32578 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_ATOM_INT(_32578)) {
        _32579 = _32578 + 1;
    }
    else
    _32579 = binary_op(PLUS, 1, _32578);
    _32578 = NOVALUE;
    _2 = (object)SEQ_PTR(_67e_routine_64926);
    if (!IS_ATOM_INT(_32579)){
        _sub_66107 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32579)->dbl));
    }
    else{
        _sub_66107 = (object)*(((s1_ptr)_2)->base + _32579);
    }

    /** execute.e:1099		if SymTab[sub][S_TOKEN] != PROC then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32581 = (object)*(((s1_ptr)_2)->base + _sub_66107);
    _2 = (object)SEQ_PTR(_32581);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _32582 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _32582 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _32581 = NOVALUE;
    if (binary_op_a(EQUALS, _32582, 27LL)){
        _32582 = NOVALUE;
        goto L3; // [103] 113
    }
    _32582 = NOVALUE;

    /** execute.e:1100			RTFatal("specify the routine id of a procedure, not a function or type")*/
    RefDS(_32584);
    _67RTFatal(_32584);
L3: 

    /** execute.e:1102		b = Code[pc+2] -- args*/
    _32585 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _32585);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:1105		new_entry = {val[a], next_task_id, T_REAL_TIME, ST_SUSPENDED, 0,*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _32587 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _32588 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _0 = _new_entry_66108;
    _1 = NewS1(16);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_32587);
    ((intptr_t*)_2)[1] = _32587;
    Ref(_67next_task_id_64896);
    ((intptr_t*)_2)[2] = _67next_task_id_64896;
    ((intptr_t*)_2)[3] = 1LL;
    ((intptr_t*)_2)[4] = 1LL;
    ((intptr_t*)_2)[5] = 0LL;
    ((intptr_t*)_2)[6] = 0LL;
    ((intptr_t*)_2)[7] = 0LL;
    ((intptr_t*)_2)[8] = 0LL;
    RefDS(_67TASK_NEVER_64888);
    ((intptr_t*)_2)[9] = _67TASK_NEVER_64888;
    ((intptr_t*)_2)[10] = 1LL;
    ((intptr_t*)_2)[11] = 1LL;
    ((intptr_t*)_2)[12] = 0LL;
    Ref(_32588);
    ((intptr_t*)_2)[13] = _32588;
    ((intptr_t*)_2)[14] = 0LL;
    RefDSn(_22024, 2);
    ((intptr_t*)_2)[15] = _22024;
    ((intptr_t*)_2)[16] = _22024;
    _new_entry_66108 = MAKE_SEQ(_1);
    DeRef(_0);
    _32588 = NOVALUE;
    _32587 = NOVALUE;

    /** execute.e:1108		recycle = FALSE*/
    _recycle_66110 = _9FALSE_444;

    /** execute.e:1109		for i = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_64921)){
            _32590 = SEQ_PTR(_67tcb_64921)->length;
    }
    else {
        _32590 = 1;
    }
    {
        object _i_66141;
        _i_66141 = 1LL;
L4: 
        if (_i_66141 > _32590){
            goto L5; // [182] 232
        }

        /** execute.e:1110			if tcb[i][TASK_STATE] = ST_DEAD then*/
        _2 = (object)SEQ_PTR(_67tcb_64921);
        _32591 = (object)*(((s1_ptr)_2)->base + _i_66141);
        _2 = (object)SEQ_PTR(_32591);
        _32592 = (object)*(((s1_ptr)_2)->base + 4LL);
        _32591 = NOVALUE;
        if (binary_op_a(NOTEQ, _32592, 2LL)){
            _32592 = NOVALUE;
            goto L6; // [201] 225
        }
        _32592 = NOVALUE;

        /** execute.e:1113				tcb[i] = new_entry*/
        RefDS(_new_entry_66108);
        _2 = (object)SEQ_PTR(_67tcb_64921);
        _2 = (object)(((s1_ptr)_2)->base + _i_66141);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _new_entry_66108;
        DeRefDS(_1);

        /** execute.e:1114				recycle = TRUE*/
        _recycle_66110 = _9TRUE_446;

        /** execute.e:1115				exit*/
        goto L5; // [222] 232
L6: 

        /** execute.e:1117		end for*/
        _i_66141 = _i_66141 + 1LL;
        goto L4; // [227] 189
L5: 
        ;
    }

    /** execute.e:1119		if not recycle then*/
    if (_recycle_66110 != 0)
    goto L7; // [234] 246

    /** execute.e:1121			tcb = append(tcb, new_entry)*/
    RefDS(_new_entry_66108);
    Append(&_67tcb_64921, _67tcb_64921, _new_entry_66108);
L7: 

    /** execute.e:1124		target = Code[pc+3]*/
    _32596 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _32596);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:1125		val[target] = next_task_id*/
    Ref(_67next_task_id_64896);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67next_task_id_64896;
    DeRef(_1);

    /** execute.e:1126		if not id_wrap and next_task_id < TASK_ID_MAX then*/
    _32598 = (_67id_wrap_64892 == 0);
    if (_32598 == 0) {
        goto L8; // [281] 306
    }
    if (IS_ATOM_INT(_67next_task_id_64896)) {
        _32600 = ((eudouble)_67next_task_id_64896 < DBL_PTR(_67TASK_ID_MAX_64889)->dbl);
    }
    else {
        _32600 = (DBL_PTR(_67next_task_id_64896)->dbl < DBL_PTR(_67TASK_ID_MAX_64889)->dbl);
    }
    if (_32600 == 0)
    {
        DeRef(_32600);
        _32600 = NOVALUE;
        goto L8; // [292] 306
    }
    else{
        DeRef(_32600);
        _32600 = NOVALUE;
    }

    /** execute.e:1127			next_task_id += 1*/
    _0 = _67next_task_id_64896;
    if (IS_ATOM_INT(_67next_task_id_64896)) {
        _67next_task_id_64896 = _67next_task_id_64896 + 1;
        if (_67next_task_id_64896 > MAXINT){
            _67next_task_id_64896 = NewDouble((eudouble)_67next_task_id_64896);
        }
    }
    else
    _67next_task_id_64896 = binary_op(PLUS, 1, _67next_task_id_64896);
    DeRef(_0);
    goto L9; // [303] 396
L8: 

    /** execute.e:1130			id_wrap = TRUE -- id's have wrapped*/
    _67id_wrap_64892 = _9TRUE_446;

    /** execute.e:1131			for i = 1 to TASK_ID_MAX do*/
    {
        object _i_66162;
        _i_66162 = 1LL;
LA: 
        if (binary_op_a(GREATER, _i_66162, _67TASK_ID_MAX_64889)){
            goto LB; // [315] 395
        }

        /** execute.e:1132				next_task_id = i*/
        Ref(_i_66162);
        DeRef(_67next_task_id_64896);
        _67next_task_id_64896 = _i_66162;

        /** execute.e:1133				for j = 1 to length(tcb) do*/
        if (IS_SEQUENCE(_67tcb_64921)){
                _32602 = SEQ_PTR(_67tcb_64921)->length;
        }
        else {
            _32602 = 1;
        }
        {
            object _j_66164;
            _j_66164 = 1LL;
LC: 
            if (_j_66164 > _32602){
                goto LD; // [334] 376
            }

            /** execute.e:1134					if next_task_id = tcb[j][TASK_TID] then*/
            _2 = (object)SEQ_PTR(_67tcb_64921);
            _32603 = (object)*(((s1_ptr)_2)->base + _j_66164);
            _2 = (object)SEQ_PTR(_32603);
            _32604 = (object)*(((s1_ptr)_2)->base + 2LL);
            _32603 = NOVALUE;
            if (binary_op_a(NOTEQ, _67next_task_id_64896, _32604)){
                _32604 = NOVALUE;
                goto LE; // [355] 369
            }
            _32604 = NOVALUE;

            /** execute.e:1135						next_task_id = 0*/
            DeRef(_67next_task_id_64896);
            _67next_task_id_64896 = 0LL;

            /** execute.e:1136						exit -- this id is still in use*/
            goto LD; // [366] 376
LE: 

            /** execute.e:1138				end for*/
            _j_66164 = _j_66164 + 1LL;
            goto LC; // [371] 341
LD: 
            ;
        }

        /** execute.e:1139				if next_task_id then*/
        if (_67next_task_id_64896 == 0) {
            goto LF; // [380] 388
        }
        else {
            if (!IS_ATOM_INT(_67next_task_id_64896) && DBL_PTR(_67next_task_id_64896)->dbl == 0.0){
                goto LF; // [380] 388
            }
        }

        /** execute.e:1140					exit -- found unused id for next time*/
        goto LB; // [385] 395
LF: 

        /** execute.e:1142			end for*/
        _0 = _i_66162;
        if (IS_ATOM_INT(_i_66162)) {
            _i_66162 = _i_66162 + 1LL;
            if ((object)((uintptr_t)_i_66162 +(uintptr_t) HIGH_BITS) >= 0){
                _i_66162 = NewDouble((eudouble)_i_66162);
            }
        }
        else {
            _i_66162 = binary_op_a(PLUS, _i_66162, 1LL);
        }
        DeRef(_0);
        goto LA; // [390] 322
LB: 
        ;
        DeRef(_i_66162);
    }
L9: 

    /** execute.e:1145		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:1146	end procedure*/
    DeRef(_new_entry_66108);
    DeRef(_32585);
    _32585 = NOVALUE;
    DeRef(_32579);
    _32579 = NOVALUE;
    DeRef(_32569);
    _32569 = NOVALUE;
    DeRef(_32598);
    _32598 = NOVALUE;
    DeRef(_32596);
    _32596 = NOVALUE;
    DeRef(_32572);
    _32572 = NOVALUE;
    return;
    ;
}


void _67opTASK_SCHEDULE()
{
    object _task_66174 = NOVALUE;
    object _now_66175 = NOVALUE;
    object _s_66176 = NOVALUE;
    object _32696 = NOVALUE;
    object _32694 = NOVALUE;
    object _32692 = NOVALUE;
    object _32691 = NOVALUE;
    object _32690 = NOVALUE;
    object _32688 = NOVALUE;
    object _32687 = NOVALUE;
    object _32686 = NOVALUE;
    object _32683 = NOVALUE;
    object _32682 = NOVALUE;
    object _32681 = NOVALUE;
    object _32680 = NOVALUE;
    object _32678 = NOVALUE;
    object _32677 = NOVALUE;
    object _32676 = NOVALUE;
    object _32674 = NOVALUE;
    object _32672 = NOVALUE;
    object _32670 = NOVALUE;
    object _32668 = NOVALUE;
    object _32665 = NOVALUE;
    object _32664 = NOVALUE;
    object _32663 = NOVALUE;
    object _32661 = NOVALUE;
    object _32658 = NOVALUE;
    object _32656 = NOVALUE;
    object _32655 = NOVALUE;
    object _32654 = NOVALUE;
    object _32652 = NOVALUE;
    object _32649 = NOVALUE;
    object _32648 = NOVALUE;
    object _32646 = NOVALUE;
    object _32645 = NOVALUE;
    object _32643 = NOVALUE;
    object _32642 = NOVALUE;
    object _32640 = NOVALUE;
    object _32639 = NOVALUE;
    object _32637 = NOVALUE;
    object _32636 = NOVALUE;
    object _32633 = NOVALUE;
    object _32631 = NOVALUE;
    object _32629 = NOVALUE;
    object _32628 = NOVALUE;
    object _32627 = NOVALUE;
    object _32625 = NOVALUE;
    object _32624 = NOVALUE;
    object _32623 = NOVALUE;
    object _32620 = NOVALUE;
    object _32619 = NOVALUE;
    object _32617 = NOVALUE;
    object _32614 = NOVALUE;
    object _32611 = NOVALUE;
    object _32609 = NOVALUE;
    object _32607 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1156		a = Code[pc+1]*/
    _32607 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _32607);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:1157		task = which_task(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _32609 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    Ref(_32609);
    _task_66174 = _67which_task(_32609);
    _32609 = NOVALUE;
    if (!IS_ATOM_INT(_task_66174)) {
        _1 = (object)(DBL_PTR(_task_66174)->dbl);
        DeRefDS(_task_66174);
        _task_66174 = _1;
    }

    /** execute.e:1158		b = Code[pc+2]*/
    _32611 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _32611);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:1159		s = val[b]*/
    DeRef(_s_66176);
    _2 = (object)SEQ_PTR(_67val_64887);
    _s_66176 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    Ref(_s_66176);

    /** execute.e:1161		if atom(s) then*/
    _32614 = IS_ATOM(_s_66176);
    if (_32614 == 0)
    {
        _32614 = NOVALUE;
        goto L1; // [64] 187
    }
    else{
        _32614 = NOVALUE;
    }

    /** execute.e:1163			if s <= 0 then*/
    if (binary_op_a(GREATER, _s_66176, 0LL)){
        goto L2; // [69] 79
    }

    /** execute.e:1164				RTFatal("number of executions must be greater than 0")*/
    RefDS(_32616);
    _67RTFatal(_32616);
L2: 

    /** execute.e:1167			tcb[task][TASK_RUNS_MAX] = s   -- max execution count*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64921 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66174 + ((s1_ptr)_2)->base);
    Ref(_s_66176);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_66176;
    DeRef(_1);
    _32617 = NOVALUE;

    /** execute.e:1168			if tcb[task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32619 = (object)*(((s1_ptr)_2)->base + _task_66174);
    _2 = (object)SEQ_PTR(_32619);
    _32620 = (object)*(((s1_ptr)_2)->base + 3LL);
    _32619 = NOVALUE;
    if (binary_op_a(NOTEQ, _32620, 1LL)){
        _32620 = NOVALUE;
        goto L3; // [104] 120
    }
    _32620 = NOVALUE;

    /** execute.e:1169				rt_first = task_delete(rt_first, task)*/
    _0 = _67task_delete(_67rt_first_64924, _task_66174);
    _67rt_first_64924 = _0;
    if (!IS_ATOM_INT(_67rt_first_64924)) {
        _1 = (object)(DBL_PTR(_67rt_first_64924)->dbl);
        DeRefDS(_67rt_first_64924);
        _67rt_first_64924 = _1;
    }
L3: 

    /** execute.e:1171			if tcb[task][TASK_TYPE] = T_REAL_TIME or*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32623 = (object)*(((s1_ptr)_2)->base + _task_66174);
    _2 = (object)SEQ_PTR(_32623);
    _32624 = (object)*(((s1_ptr)_2)->base + 3LL);
    _32623 = NOVALUE;
    if (IS_ATOM_INT(_32624)) {
        _32625 = (_32624 == 1LL);
    }
    else {
        _32625 = binary_op(EQUALS, _32624, 1LL);
    }
    _32624 = NOVALUE;
    if (IS_ATOM_INT(_32625)) {
        if (_32625 != 0) {
            goto L4; // [136] 159
        }
    }
    else {
        if (DBL_PTR(_32625)->dbl != 0.0) {
            goto L4; // [136] 159
        }
    }
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32627 = (object)*(((s1_ptr)_2)->base + _task_66174);
    _2 = (object)SEQ_PTR(_32627);
    _32628 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32627 = NOVALUE;
    if (IS_ATOM_INT(_32628)) {
        _32629 = (_32628 == 1LL);
    }
    else {
        _32629 = binary_op(EQUALS, _32628, 1LL);
    }
    _32628 = NOVALUE;
    if (_32629 == 0) {
        DeRef(_32629);
        _32629 = NOVALUE;
        goto L5; // [155] 171
    }
    else {
        if (!IS_ATOM_INT(_32629) && DBL_PTR(_32629)->dbl == 0.0){
            DeRef(_32629);
            _32629 = NOVALUE;
            goto L5; // [155] 171
        }
        DeRef(_32629);
        _32629 = NOVALUE;
    }
    DeRef(_32629);
    _32629 = NOVALUE;
L4: 

    /** execute.e:1173				ts_first = task_insert(ts_first, task)*/
    _0 = _67task_insert(_67ts_first_64925, _task_66174);
    _67ts_first_64925 = _0;
    if (!IS_ATOM_INT(_67ts_first_64925)) {
        _1 = (object)(DBL_PTR(_67ts_first_64925)->dbl);
        DeRefDS(_67ts_first_64925);
        _67ts_first_64925 = _1;
    }
L5: 

    /** execute.e:1175			tcb[task][TASK_TYPE] = T_TIME_SHARE*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64921 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66174 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _32631 = NOVALUE;
    goto L6; // [184] 542
L1: 

    /** execute.e:1179			if length(s) != 2 then*/
    if (IS_SEQUENCE(_s_66176)){
            _32633 = SEQ_PTR(_s_66176)->length;
    }
    else {
        _32633 = 1;
    }
    if (_32633 == 2LL)
    goto L7; // [192] 202

    /** execute.e:1180				RTFatal("second argument must be {min-time, max-time}")*/
    RefDS(_32635);
    _67RTFatal(_32635);
L7: 

    /** execute.e:1182			if sequence(s[1]) or sequence(s[2]) then*/
    _2 = (object)SEQ_PTR(_s_66176);
    _32636 = (object)*(((s1_ptr)_2)->base + 1LL);
    _32637 = IS_SEQUENCE(_32636);
    _32636 = NOVALUE;
    if (_32637 != 0) {
        goto L8; // [211] 227
    }
    _2 = (object)SEQ_PTR(_s_66176);
    _32639 = (object)*(((s1_ptr)_2)->base + 2LL);
    _32640 = IS_SEQUENCE(_32639);
    _32639 = NOVALUE;
    if (_32640 == 0)
    {
        _32640 = NOVALUE;
        goto L9; // [223] 233
    }
    else{
        _32640 = NOVALUE;
    }
L8: 

    /** execute.e:1183				RTFatal("min and max times must be atoms")*/
    RefDS(_32641);
    _67RTFatal(_32641);
L9: 

    /** execute.e:1185			if s[1] < 0 or s[2] < 0 then*/
    _2 = (object)SEQ_PTR(_s_66176);
    _32642 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_32642)) {
        _32643 = (_32642 < 0LL);
    }
    else {
        _32643 = binary_op(LESS, _32642, 0LL);
    }
    _32642 = NOVALUE;
    if (IS_ATOM_INT(_32643)) {
        if (_32643 != 0) {
            goto LA; // [243] 260
        }
    }
    else {
        if (DBL_PTR(_32643)->dbl != 0.0) {
            goto LA; // [243] 260
        }
    }
    _2 = (object)SEQ_PTR(_s_66176);
    _32645 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_32645)) {
        _32646 = (_32645 < 0LL);
    }
    else {
        _32646 = binary_op(LESS, _32645, 0LL);
    }
    _32645 = NOVALUE;
    if (_32646 == 0) {
        DeRef(_32646);
        _32646 = NOVALUE;
        goto LB; // [256] 266
    }
    else {
        if (!IS_ATOM_INT(_32646) && DBL_PTR(_32646)->dbl == 0.0){
            DeRef(_32646);
            _32646 = NOVALUE;
            goto LB; // [256] 266
        }
        DeRef(_32646);
        _32646 = NOVALUE;
    }
    DeRef(_32646);
    _32646 = NOVALUE;
LA: 

    /** execute.e:1186				RTFatal("min and max times must be greater than or equal to 0")*/
    RefDS(_32647);
    _67RTFatal(_32647);
LB: 

    /** execute.e:1188			if s[1] > s[2] then*/
    _2 = (object)SEQ_PTR(_s_66176);
    _32648 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_s_66176);
    _32649 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (binary_op_a(LESSEQ, _32648, _32649)){
        _32648 = NOVALUE;
        _32649 = NOVALUE;
        goto LC; // [276] 286
    }
    _32648 = NOVALUE;
    _32649 = NOVALUE;

    /** execute.e:1189				RTFatal("task min time must be <= task max time")*/
    RefDS(_32651);
    _67RTFatal(_32651);
LC: 

    /** execute.e:1191			tcb[task][TASK_MIN_INC] = s[1]*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64921 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66174 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_s_66176);
    _32654 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_32654);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32654;
    if( _1 != _32654 ){
        DeRef(_1);
    }
    _32654 = NOVALUE;
    _32652 = NOVALUE;

    /** execute.e:1193			if s[1] < clock_period/2 then*/
    _2 = (object)SEQ_PTR(_s_66176);
    _32655 = (object)*(((s1_ptr)_2)->base + 1LL);
    _32656 = binary_op(DIVIDE, _67clock_period_64897, 2);
    if (binary_op_a(GREATEREQ, _32655, _32656)){
        _32655 = NOVALUE;
        DeRefDS(_32656);
        _32656 = NOVALUE;
        goto LD; // [315] 372
    }
    _32655 = NOVALUE;
    DeRef(_32656);
    _32656 = NOVALUE;

    /** execute.e:1195				if s[1] > 1.0e-9 then*/
    _2 = (object)SEQ_PTR(_s_66176);
    _32658 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(LESSEQ, _32658, _32659)){
        _32658 = NOVALUE;
        goto LE; // [325] 355
    }
    _32658 = NOVALUE;

    /** execute.e:1196					tcb[task][TASK_RUNS_MAX] =  floor(clock_period / s[1])*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64921 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66174 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_s_66176);
    _32663 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = binary_op(DIVIDE, _67clock_period_64897, _32663);
    _32664 = unary_op(FLOOR, _2);
    DeRef(_2);
    _32663 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32664;
    if( _1 != _32664 ){
        DeRef(_1);
    }
    _32664 = NOVALUE;
    _32661 = NOVALUE;
    goto LF; // [352] 386
LE: 

    /** execute.e:1199					tcb[task][TASK_RUNS_MAX] =  1000000000 -- arbitrary, large*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64921 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66174 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1000000000LL;
    DeRef(_1);
    _32665 = NOVALUE;
    goto LF; // [369] 386
LD: 

    /** execute.e:1202				tcb[task][TASK_RUNS_MAX] = 1*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64921 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66174 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _32668 = NOVALUE;
LF: 

    /** execute.e:1204			tcb[task][TASK_MAX_INC] = s[2]*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64921 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66174 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_s_66176);
    _32672 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_32672);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 7LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32672;
    if( _1 != _32672 ){
        DeRef(_1);
    }
    _32672 = NOVALUE;
    _32670 = NOVALUE;

    /** execute.e:1205			now = time()*/
    DeRef(_now_66175);
    _now_66175 = NewDouble(current_time());

    /** execute.e:1206			tcb[task][TASK_MIN_TIME] = now + s[1]*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64921 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66174 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_s_66176);
    _32676 = (object)*(((s1_ptr)_2)->base + 1LL);
    _32677 = binary_op(PLUS, _now_66175, _32676);
    _32676 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 8LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32677;
    if( _1 != _32677 ){
        DeRef(_1);
    }
    _32677 = NOVALUE;
    _32674 = NOVALUE;

    /** execute.e:1207			tcb[task][TASK_MAX_TIME] = now + s[2]*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64921 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66174 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_s_66176);
    _32680 = (object)*(((s1_ptr)_2)->base + 2LL);
    _32681 = binary_op(PLUS, _now_66175, _32680);
    _32680 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32681;
    if( _1 != _32681 ){
        DeRef(_1);
    }
    _32681 = NOVALUE;
    _32678 = NOVALUE;

    /** execute.e:1209			if tcb[task][TASK_TYPE] = T_TIME_SHARE then*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32682 = (object)*(((s1_ptr)_2)->base + _task_66174);
    _2 = (object)SEQ_PTR(_32682);
    _32683 = (object)*(((s1_ptr)_2)->base + 3LL);
    _32682 = NOVALUE;
    if (binary_op_a(NOTEQ, _32683, 2LL)){
        _32683 = NOVALUE;
        goto L10; // [461] 477
    }
    _32683 = NOVALUE;

    /** execute.e:1210				ts_first = task_delete(ts_first, task)*/
    _0 = _67task_delete(_67ts_first_64925, _task_66174);
    _67ts_first_64925 = _0;
    if (!IS_ATOM_INT(_67ts_first_64925)) {
        _1 = (object)(DBL_PTR(_67ts_first_64925)->dbl);
        DeRefDS(_67ts_first_64925);
        _67ts_first_64925 = _1;
    }
L10: 

    /** execute.e:1212			if tcb[task][TASK_TYPE] = T_TIME_SHARE or*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32686 = (object)*(((s1_ptr)_2)->base + _task_66174);
    _2 = (object)SEQ_PTR(_32686);
    _32687 = (object)*(((s1_ptr)_2)->base + 3LL);
    _32686 = NOVALUE;
    if (IS_ATOM_INT(_32687)) {
        _32688 = (_32687 == 2LL);
    }
    else {
        _32688 = binary_op(EQUALS, _32687, 2LL);
    }
    _32687 = NOVALUE;
    if (IS_ATOM_INT(_32688)) {
        if (_32688 != 0) {
            goto L11; // [493] 516
        }
    }
    else {
        if (DBL_PTR(_32688)->dbl != 0.0) {
            goto L11; // [493] 516
        }
    }
    _2 = (object)SEQ_PTR(_67tcb_64921);
    _32690 = (object)*(((s1_ptr)_2)->base + _task_66174);
    _2 = (object)SEQ_PTR(_32690);
    _32691 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32690 = NOVALUE;
    if (IS_ATOM_INT(_32691)) {
        _32692 = (_32691 == 1LL);
    }
    else {
        _32692 = binary_op(EQUALS, _32691, 1LL);
    }
    _32691 = NOVALUE;
    if (_32692 == 0) {
        DeRef(_32692);
        _32692 = NOVALUE;
        goto L12; // [512] 528
    }
    else {
        if (!IS_ATOM_INT(_32692) && DBL_PTR(_32692)->dbl == 0.0){
            DeRef(_32692);
            _32692 = NOVALUE;
            goto L12; // [512] 528
        }
        DeRef(_32692);
        _32692 = NOVALUE;
    }
    DeRef(_32692);
    _32692 = NOVALUE;
L11: 

    /** execute.e:1214				rt_first = task_insert(rt_first, task)*/
    _0 = _67task_insert(_67rt_first_64924, _task_66174);
    _67rt_first_64924 = _0;
    if (!IS_ATOM_INT(_67rt_first_64924)) {
        _1 = (object)(DBL_PTR(_67rt_first_64924)->dbl);
        DeRefDS(_67rt_first_64924);
        _67rt_first_64924 = _1;
    }
L12: 

    /** execute.e:1216			tcb[task][TASK_TYPE] = T_REAL_TIME*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64921 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66174 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _32694 = NOVALUE;
L6: 

    /** execute.e:1218		tcb[task][TASK_STATE] = ST_ACTIVE*/
    _2 = (object)SEQ_PTR(_67tcb_64921);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_64921 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66174 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _32696 = NOVALUE;

    /** execute.e:1219		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:1220	end procedure*/
    DeRef(_now_66175);
    DeRef(_s_66176);
    DeRef(_32625);
    _32625 = NOVALUE;
    DeRef(_32643);
    _32643 = NOVALUE;
    DeRef(_32611);
    _32611 = NOVALUE;
    DeRef(_32688);
    _32688 = NOVALUE;
    DeRef(_32607);
    _32607 = NOVALUE;
    return;
    ;
}


void _67one_trace_line(object _line_66291)
{
    object _32700 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1231		ifdef UNIX then*/

    /** execute.e:1232			printf(trace_file, "%-78.78s\n", {line})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_line_66291);
    ((intptr_t*)_2)[1] = _line_66291;
    _32700 = MAKE_SEQ(_1);
    EPrintf(_67trace_file_66287, _32699, _32700);
    DeRefDS(_32700);
    _32700 = NOVALUE;

    /** execute.e:1236	end procedure*/
    DeRefDS(_line_66291);
    return;
    ;
}


void _67opCOVERAGE_LINE()
{
    object _35127 = NOVALUE;
    object _32703 = NOVALUE;
    object _32702 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1239		cover_line( Code[pc+1] )*/
    _32702 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32703 = (object)*(((s1_ptr)_2)->base + _32702);
    Ref(_32703);
    _35127 = _50cover_line(_32703);
    _32703 = NOVALUE;
    DeRef(_35127);
    _35127 = NOVALUE;

    /** execute.e:1240		pc += 2*/
    _67pc_64877 = _67pc_64877 + 2LL;

    /** execute.e:1241	end procedure*/
    _32702 = NOVALUE;
    return;
    ;
}


void _67opCOVERAGE_ROUTINE()
{
    object _35126 = NOVALUE;
    object _32706 = NOVALUE;
    object _32705 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1244		cover_routine( Code[pc+1] )*/
    _32705 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32706 = (object)*(((s1_ptr)_2)->base + _32705);
    Ref(_32706);
    _35126 = _50cover_routine(_32706);
    _32706 = NOVALUE;
    DeRef(_35126);
    _35126 = NOVALUE;

    /** execute.e:1245		pc += 2*/
    _67pc_64877 = _67pc_64877 + 2LL;

    /** execute.e:1246	end procedure*/
    _32705 = NOVALUE;
    return;
    ;
}


void _67opSTARTLINE()
{
    object _line_66311 = NOVALUE;
    object _w_66312 = NOVALUE;
    object _32740 = NOVALUE;
    object _32739 = NOVALUE;
    object _32738 = NOVALUE;
    object _32734 = NOVALUE;
    object _32729 = NOVALUE;
    object _32728 = NOVALUE;
    object _32727 = NOVALUE;
    object _32726 = NOVALUE;
    object _32725 = NOVALUE;
    object _32724 = NOVALUE;
    object _32723 = NOVALUE;
    object _32720 = NOVALUE;
    object _32719 = NOVALUE;
    object _32717 = NOVALUE;
    object _32716 = NOVALUE;
    object _32715 = NOVALUE;
    object _32713 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1253		if TraceOn then*/
    if (_67TraceOn_64875 == 0)
    {
        goto L1; // [5] 279
    }
    else{
    }

    /** execute.e:1254			if trace_file = -1 then*/
    if (_67trace_file_66287 != -1LL)
    goto L2; // [12] 40

    /** execute.e:1255				trace_file = open("ctrace.out", "wb")*/
    _67trace_file_66287 = EOpen(_32709, _23879, 0LL);

    /** execute.e:1256				if trace_file = -1 then*/
    if (_67trace_file_66287 != -1LL)
    goto L3; // [29] 39

    /** execute.e:1257					RTFatal("Couldn't open ctrace.out")*/
    RefDS(_32712);
    _67RTFatal(_32712);
L3: 
L2: 

    /** execute.e:1261			a = Code[pc+1]*/
    _32713 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _32713);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:1263			if atom(slist[$]) then*/
    if (IS_SEQUENCE(_12slist_20317)){
            _32715 = SEQ_PTR(_12slist_20317)->length;
    }
    else {
        _32715 = 1;
    }
    _2 = (object)SEQ_PTR(_12slist_20317);
    _32716 = (object)*(((s1_ptr)_2)->base + _32715);
    _32717 = IS_ATOM(_32716);
    _32716 = NOVALUE;
    if (_32717 == 0)
    {
        _32717 = NOVALUE;
        goto L4; // [70] 84
    }
    else{
        _32717 = NOVALUE;
    }

    /** execute.e:1264				slist = s_expand(slist)*/
    RefDS(_12slist_20317);
    _0 = _61s_expand(_12slist_20317);
    DeRefDS(_12slist_20317);
    _12slist_20317 = _0;
L4: 

    /** execute.e:1266			line = fetch_line(slist[a][SRC])*/
    _2 = (object)SEQ_PTR(_12slist_20317);
    _32719 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_32719);
    _32720 = (object)*(((s1_ptr)_2)->base + 1LL);
    _32719 = NOVALUE;
    Ref(_32720);
    _0 = _line_66311;
    _line_66311 = _61fetch_line(_32720);
    DeRef(_0);
    _32720 = NOVALUE;

    /** execute.e:1267			line = sprintf("%s:%d\t%s",*/
    _2 = (object)SEQ_PTR(_12slist_20317);
    _32723 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_32723);
    _32724 = (object)*(((s1_ptr)_2)->base + 3LL);
    _32723 = NOVALUE;
    _2 = (object)SEQ_PTR(_13known_files_11317);
    if (!IS_ATOM_INT(_32724)){
        _32725 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32724)->dbl));
    }
    else{
        _32725 = (object)*(((s1_ptr)_2)->base + _32724);
    }
    Ref(_32725);
    _32726 = _53name_ext(_32725);
    _32725 = NOVALUE;
    _2 = (object)SEQ_PTR(_12slist_20317);
    _32727 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_32727);
    _32728 = (object)*(((s1_ptr)_2)->base + 2LL);
    _32727 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _32726;
    Ref(_32728);
    ((intptr_t*)_2)[2] = _32728;
    RefDS(_line_66311);
    ((intptr_t*)_2)[3] = _line_66311;
    _32729 = MAKE_SEQ(_1);
    _32728 = NOVALUE;
    _32726 = NOVALUE;
    DeRefDS(_line_66311);
    _line_66311 = EPrintf(-9999999, _32722, _32729);
    DeRefDS(_32729);
    _32729 = NOVALUE;

    /** execute.e:1271			trace_line += 1*/
    _67trace_line_66288 = _67trace_line_66288 + 1;

    /** execute.e:1272			if trace_line >= trace_lines then*/
    if (_67trace_line_66288 < _12trace_lines_64606)
    goto L5; // [170] 210

    /** execute.e:1274				trace_line = 0*/
    _67trace_line_66288 = 0LL;

    /** execute.e:1275				one_trace_line("")*/
    RefDS(_22024);
    _67one_trace_line(_22024);

    /** execute.e:1276				one_trace_line("               ")*/
    RefDS(_32733);
    _67one_trace_line(_32733);

    /** execute.e:1277				flush(trace_file)*/
    _17flush(_67trace_file_66287);

    /** execute.e:1278				if seek(trace_file, 0) then*/
    _32734 = _17seek(_67trace_file_66287, 0LL);
    if (_32734 == 0) {
        DeRef(_32734);
        _32734 = NOVALUE;
        goto L6; // [205] 209
    }
    else {
        if (!IS_ATOM_INT(_32734) && DBL_PTR(_32734)->dbl == 0.0){
            DeRef(_32734);
            _32734 = NOVALUE;
            goto L6; // [205] 209
        }
        DeRef(_32734);
        _32734 = NOVALUE;
    }
    DeRef(_32734);
    _32734 = NOVALUE;
L6: 
L5: 

    /** execute.e:1282			one_trace_line(line)*/
    RefDS(_line_66311);
    _67one_trace_line(_line_66311);

    /** execute.e:1283			one_trace_line("")*/
    RefDS(_22024);
    _67one_trace_line(_22024);

    /** execute.e:1284			one_trace_line("=== THE END ===")*/
    RefDS(_32735);
    _67one_trace_line(_32735);

    /** execute.e:1285			one_trace_line("")*/
    RefDS(_22024);
    _67one_trace_line(_22024);

    /** execute.e:1286			one_trace_line("")*/
    RefDS(_22024);
    _67one_trace_line(_22024);

    /** execute.e:1287			one_trace_line("")*/
    RefDS(_22024);
    _67one_trace_line(_22024);

    /** execute.e:1288			flush(trace_file)*/
    _17flush(_67trace_file_66287);

    /** execute.e:1289			w = where(trace_file)*/
    _w_66312 = _17where(_67trace_file_66287);
    if (!IS_ATOM_INT(_w_66312)) {
        _1 = (object)(DBL_PTR(_w_66312)->dbl);
        DeRefDS(_w_66312);
        _w_66312 = _1;
    }

    /** execute.e:1290			if seek(trace_file, w-79*5) then -- back up 5 (fixed-width) lines*/
    _32738 = 395LL;
    _32739 = _w_66312 - 395LL;
    if ((object)((uintptr_t)_32739 +(uintptr_t) HIGH_BITS) >= 0){
        _32739 = NewDouble((eudouble)_32739);
    }
    _32738 = NOVALUE;
    _32740 = _17seek(_67trace_file_66287, _32739);
    _32739 = NOVALUE;
    if (_32740 == 0) {
        DeRef(_32740);
        _32740 = NOVALUE;
        goto L7; // [274] 278
    }
    else {
        if (!IS_ATOM_INT(_32740) && DBL_PTR(_32740)->dbl == 0.0){
            DeRef(_32740);
            _32740 = NOVALUE;
            goto L7; // [274] 278
        }
        DeRef(_32740);
        _32740 = NOVALUE;
    }
    DeRef(_32740);
    _32740 = NOVALUE;
L7: 
L1: 

    /** execute.e:1293		pc += 2*/
    _67pc_64877 = _67pc_64877 + 2LL;

    /** execute.e:1294	end procedure*/
    DeRef(_line_66311);
    _32724 = NOVALUE;
    DeRef(_32713);
    _32713 = NOVALUE;
    return;
    ;
}


void _67opPROC_TAIL()
{
    object _arg_66376 = NOVALUE;
    object _sub_66377 = NOVALUE;
    object _32758 = NOVALUE;
    object _32757 = NOVALUE;
    object _32756 = NOVALUE;
    object _32755 = NOVALUE;
    object _32754 = NOVALUE;
    object _32752 = NOVALUE;
    object _32751 = NOVALUE;
    object _32750 = NOVALUE;
    object _32749 = NOVALUE;
    object _32748 = NOVALUE;
    object _32747 = NOVALUE;
    object _32746 = NOVALUE;
    object _32744 = NOVALUE;
    object _32742 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1299		sub = Code[pc+1] -- subroutine*/
    _32742 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _sub_66377 = (object)*(((s1_ptr)_2)->base + _32742);
    if (!IS_ATOM_INT(_sub_66377)){
        _sub_66377 = (object)DBL_PTR(_sub_66377)->dbl;
    }

    /** execute.e:1300		arg = SymTab[sub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32744 = (object)*(((s1_ptr)_2)->base + _sub_66377);
    _2 = (object)SEQ_PTR(_32744);
    _arg_66376 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_arg_66376)){
        _arg_66376 = (object)DBL_PTR(_arg_66376)->dbl;
    }
    _32744 = NOVALUE;

    /** execute.e:1303		for i = 1 to SymTab[sub][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32746 = (object)*(((s1_ptr)_2)->base + _sub_66377);
    _2 = (object)SEQ_PTR(_32746);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _32747 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _32747 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _32746 = NOVALUE;
    {
        object _i_66386;
        _i_66386 = 1LL;
L1: 
        if (binary_op_a(GREATER, _i_66386, _32747)){
            goto L2; // [47] 107
        }

        /** execute.e:1304			val[arg] = val[Code[pc+1+i]]*/
        _32748 = _67pc_64877 + 1;
        if (_32748 > MAXINT){
            _32748 = NewDouble((eudouble)_32748);
        }
        if (IS_ATOM_INT(_32748) && IS_ATOM_INT(_i_66386)) {
            _32749 = _32748 + _i_66386;
        }
        else {
            if (IS_ATOM_INT(_32748)) {
                _32749 = NewDouble((eudouble)_32748 + DBL_PTR(_i_66386)->dbl);
            }
            else {
                if (IS_ATOM_INT(_i_66386)) {
                    _32749 = NewDouble(DBL_PTR(_32748)->dbl + (eudouble)_i_66386);
                }
                else
                _32749 = NewDouble(DBL_PTR(_32748)->dbl + DBL_PTR(_i_66386)->dbl);
            }
        }
        DeRef(_32748);
        _32748 = NOVALUE;
        _2 = (object)SEQ_PTR(_12Code_20315);
        if (!IS_ATOM_INT(_32749)){
            _32750 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32749)->dbl));
        }
        else{
            _32750 = (object)*(((s1_ptr)_2)->base + _32749);
        }
        _2 = (object)SEQ_PTR(_67val_64887);
        if (!IS_ATOM_INT(_32750)){
            _32751 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32750)->dbl));
        }
        else{
            _32751 = (object)*(((s1_ptr)_2)->base + _32750);
        }
        Ref(_32751);
        _2 = (object)SEQ_PTR(_67val_64887);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_64887 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _arg_66376);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _32751;
        if( _1 != _32751 ){
            DeRef(_1);
        }
        _32751 = NOVALUE;

        /** execute.e:1305			arg = SymTab[arg][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _32752 = (object)*(((s1_ptr)_2)->base + _arg_66376);
        _2 = (object)SEQ_PTR(_32752);
        _arg_66376 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_arg_66376)){
            _arg_66376 = (object)DBL_PTR(_arg_66376)->dbl;
        }
        _32752 = NOVALUE;

        /** execute.e:1306		end for*/
        _0 = _i_66386;
        if (IS_ATOM_INT(_i_66386)) {
            _i_66386 = _i_66386 + 1LL;
            if ((object)((uintptr_t)_i_66386 +(uintptr_t) HIGH_BITS) >= 0){
                _i_66386 = NewDouble((eudouble)_i_66386);
            }
        }
        else {
            _i_66386 = binary_op_a(PLUS, _i_66386, 1LL);
        }
        DeRef(_0);
        goto L1; // [102] 54
L2: 
        ;
        DeRef(_i_66386);
    }

    /** execute.e:1309		while arg and SymTab[arg][S_SCOPE] <= SC_PRIVATE do*/
L3: 
    if (_arg_66376 == 0) {
        goto L4; // [112] 169
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32755 = (object)*(((s1_ptr)_2)->base + _arg_66376);
    _2 = (object)SEQ_PTR(_32755);
    _32756 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32755 = NOVALUE;
    if (IS_ATOM_INT(_32756)) {
        _32757 = (_32756 <= 3LL);
    }
    else {
        _32757 = binary_op(LESSEQ, _32756, 3LL);
    }
    _32756 = NOVALUE;
    if (_32757 <= 0) {
        if (_32757 == 0) {
            DeRef(_32757);
            _32757 = NOVALUE;
            goto L4; // [135] 169
        }
        else {
            if (!IS_ATOM_INT(_32757) && DBL_PTR(_32757)->dbl == 0.0){
                DeRef(_32757);
                _32757 = NOVALUE;
                goto L4; // [135] 169
            }
            DeRef(_32757);
            _32757 = NOVALUE;
        }
    }
    DeRef(_32757);
    _32757 = NOVALUE;

    /** execute.e:1310			val[arg] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _arg_66376);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);

    /** execute.e:1311			arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32758 = (object)*(((s1_ptr)_2)->base + _arg_66376);
    _2 = (object)SEQ_PTR(_32758);
    _arg_66376 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_arg_66376)){
        _arg_66376 = (object)DBL_PTR(_arg_66376)->dbl;
    }
    _32758 = NOVALUE;

    /** execute.e:1312		end while*/
    goto L3; // [166] 112
L4: 

    /** execute.e:1315		pc = 1*/
    _67pc_64877 = 1LL;

    /** execute.e:1316	end procedure*/
    _32750 = NOVALUE;
    DeRef(_32749);
    _32749 = NOVALUE;
    _32747 = NOVALUE;
    DeRef(_32742);
    _32742 = NOVALUE;
    return;
    ;
}


void _67opPROC()
{
    object _n_66415 = NOVALUE;
    object _arg_66416 = NOVALUE;
    object _sub_66417 = NOVALUE;
    object _p_66418 = NOVALUE;
    object _private_block_66419 = NOVALUE;
    object _32825 = NOVALUE;
    object _32820 = NOVALUE;
    object _32819 = NOVALUE;
    object _32817 = NOVALUE;
    object _32815 = NOVALUE;
    object _32813 = NOVALUE;
    object _32812 = NOVALUE;
    object _32811 = NOVALUE;
    object _32810 = NOVALUE;
    object _32809 = NOVALUE;
    object _32808 = NOVALUE;
    object _32806 = NOVALUE;
    object _32804 = NOVALUE;
    object _32801 = NOVALUE;
    object _32799 = NOVALUE;
    object _32797 = NOVALUE;
    object _32795 = NOVALUE;
    object _32794 = NOVALUE;
    object _32793 = NOVALUE;
    object _32792 = NOVALUE;
    object _32791 = NOVALUE;
    object _32790 = NOVALUE;
    object _32789 = NOVALUE;
    object _32788 = NOVALUE;
    object _32787 = NOVALUE;
    object _32786 = NOVALUE;
    object _32785 = NOVALUE;
    object _32784 = NOVALUE;
    object _32783 = NOVALUE;
    object _32782 = NOVALUE;
    object _32781 = NOVALUE;
    object _32779 = NOVALUE;
    object _32778 = NOVALUE;
    object _32777 = NOVALUE;
    object _32776 = NOVALUE;
    object _32775 = NOVALUE;
    object _32773 = NOVALUE;
    object _32772 = NOVALUE;
    object _32770 = NOVALUE;
    object _32769 = NOVALUE;
    object _32767 = NOVALUE;
    object _32766 = NOVALUE;
    object _32764 = NOVALUE;
    object _32762 = NOVALUE;
    object _32760 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1324		sub = Code[pc+1] -- subroutine*/
    _32760 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _sub_66417 = (object)*(((s1_ptr)_2)->base + _32760);
    if (!IS_ATOM_INT(_sub_66417)){
        _sub_66417 = (object)DBL_PTR(_sub_66417)->dbl;
    }

    /** execute.e:1325		arg = SymTab[sub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32762 = (object)*(((s1_ptr)_2)->base + _sub_66417);
    _2 = (object)SEQ_PTR(_32762);
    _arg_66416 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_arg_66416)){
        _arg_66416 = (object)DBL_PTR(_arg_66416)->dbl;
    }
    _32762 = NOVALUE;

    /** execute.e:1327		n = SymTab[sub][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32764 = (object)*(((s1_ptr)_2)->base + _sub_66417);
    _2 = (object)SEQ_PTR(_32764);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _n_66415 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _n_66415 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    if (!IS_ATOM_INT(_n_66415)){
        _n_66415 = (object)DBL_PTR(_n_66415)->dbl;
    }
    _32764 = NOVALUE;

    /** execute.e:1329		if SymTab[sub][S_RESIDENT_TASK] != 0 then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32766 = (object)*(((s1_ptr)_2)->base + _sub_66417);
    _2 = (object)SEQ_PTR(_32766);
    _32767 = (object)*(((s1_ptr)_2)->base + 25LL);
    _32766 = NOVALUE;
    if (binary_op_a(EQUALS, _32767, 0LL)){
        _32767 = NOVALUE;
        goto L1; // [63] 413
    }
    _32767 = NOVALUE;

    /** execute.e:1333			private_block = repeat(0, SymTab[sub][S_STACK_SPACE])*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32769 = (object)*(((s1_ptr)_2)->base + _sub_66417);
    _2 = (object)SEQ_PTR(_32769);
    if (!IS_ATOM_INT(_12S_STACK_SPACE_19924)){
        _32770 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_STACK_SPACE_19924)->dbl));
    }
    else{
        _32770 = (object)*(((s1_ptr)_2)->base + _12S_STACK_SPACE_19924);
    }
    _32769 = NOVALUE;
    DeRef(_private_block_66419);
    _private_block_66419 = Repeat(0LL, _32770);
    _32770 = NOVALUE;

    /** execute.e:1334			p = 1*/
    _p_66418 = 1LL;

    /** execute.e:1335			for i = 1 to n do*/
    _32772 = _n_66415;
    {
        object _i_66443;
        _i_66443 = 1LL;
L2: 
        if (_i_66443 > _32772){
            goto L3; // [95] 173
        }

        /** execute.e:1336				private_block[p] = val[arg]*/
        _2 = (object)SEQ_PTR(_67val_64887);
        _32773 = (object)*(((s1_ptr)_2)->base + _arg_66416);
        Ref(_32773);
        _2 = (object)SEQ_PTR(_private_block_66419);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _private_block_66419 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _p_66418);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _32773;
        if( _1 != _32773 ){
            DeRef(_1);
        }
        _32773 = NOVALUE;

        /** execute.e:1337				p += 1*/
        _p_66418 = _p_66418 + 1;

        /** execute.e:1338				val[arg] = val[Code[pc+1+i]]*/
        _32775 = _67pc_64877 + 1;
        if (_32775 > MAXINT){
            _32775 = NewDouble((eudouble)_32775);
        }
        if (IS_ATOM_INT(_32775)) {
            _32776 = _32775 + _i_66443;
        }
        else {
            _32776 = NewDouble(DBL_PTR(_32775)->dbl + (eudouble)_i_66443);
        }
        DeRef(_32775);
        _32775 = NOVALUE;
        _2 = (object)SEQ_PTR(_12Code_20315);
        if (!IS_ATOM_INT(_32776)){
            _32777 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32776)->dbl));
        }
        else{
            _32777 = (object)*(((s1_ptr)_2)->base + _32776);
        }
        _2 = (object)SEQ_PTR(_67val_64887);
        if (!IS_ATOM_INT(_32777)){
            _32778 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32777)->dbl));
        }
        else{
            _32778 = (object)*(((s1_ptr)_2)->base + _32777);
        }
        Ref(_32778);
        _2 = (object)SEQ_PTR(_67val_64887);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_64887 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _arg_66416);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _32778;
        if( _1 != _32778 ){
            DeRef(_1);
        }
        _32778 = NOVALUE;

        /** execute.e:1339				arg = SymTab[arg][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _32779 = (object)*(((s1_ptr)_2)->base + _arg_66416);
        _2 = (object)SEQ_PTR(_32779);
        _arg_66416 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_arg_66416)){
            _arg_66416 = (object)DBL_PTR(_arg_66416)->dbl;
        }
        _32779 = NOVALUE;

        /** execute.e:1340			end for*/
        _i_66443 = _i_66443 + 1LL;
        goto L2; // [168] 102
L3: 
        ;
    }

    /** execute.e:1343			while arg != 0 */
L4: 
    _32781 = (_arg_66416 != 0LL);
    if (_32781 == 0) {
        goto L5; // [182] 330
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32783 = (object)*(((s1_ptr)_2)->base + _arg_66416);
    _2 = (object)SEQ_PTR(_32783);
    _32784 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32783 = NOVALUE;
    if (IS_ATOM_INT(_32784)) {
        _32785 = (_32784 <= 3LL);
    }
    else {
        _32785 = binary_op(LESSEQ, _32784, 3LL);
    }
    _32784 = NOVALUE;
    if (IS_ATOM_INT(_32785)) {
        if (_32785 != 0) {
            DeRef(_32786);
            _32786 = 1;
            goto L6; // [204] 230
        }
    }
    else {
        if (DBL_PTR(_32785)->dbl != 0.0) {
            DeRef(_32786);
            _32786 = 1;
            goto L6; // [204] 230
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32787 = (object)*(((s1_ptr)_2)->base + _arg_66416);
    _2 = (object)SEQ_PTR(_32787);
    _32788 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32787 = NOVALUE;
    if (IS_ATOM_INT(_32788)) {
        _32789 = (_32788 == 2LL);
    }
    else {
        _32789 = binary_op(EQUALS, _32788, 2LL);
    }
    _32788 = NOVALUE;
    DeRef(_32786);
    if (IS_ATOM_INT(_32789))
    _32786 = (_32789 != 0);
    else
    _32786 = DBL_PTR(_32789)->dbl != 0.0;
L6: 
    if (_32786 != 0) {
        DeRef(_32790);
        _32790 = 1;
        goto L7; // [230] 256
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32791 = (object)*(((s1_ptr)_2)->base + _arg_66416);
    _2 = (object)SEQ_PTR(_32791);
    _32792 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32791 = NOVALUE;
    if (IS_ATOM_INT(_32792)) {
        _32793 = (_32792 == 9LL);
    }
    else {
        _32793 = binary_op(EQUALS, _32792, 9LL);
    }
    _32792 = NOVALUE;
    if (IS_ATOM_INT(_32793))
    _32790 = (_32793 != 0);
    else
    _32790 = DBL_PTR(_32793)->dbl != 0.0;
L7: 
    if (_32790 == 0)
    {
        _32790 = NOVALUE;
        goto L5; // [257] 330
    }
    else{
        _32790 = NOVALUE;
    }

    /** execute.e:1348				if SymTab[arg][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32794 = (object)*(((s1_ptr)_2)->base + _arg_66416);
    _2 = (object)SEQ_PTR(_32794);
    _32795 = (object)*(((s1_ptr)_2)->base + 4LL);
    _32794 = NOVALUE;
    if (binary_op_a(EQUALS, _32795, 9LL)){
        _32795 = NOVALUE;
        goto L8; // [276] 309
    }
    _32795 = NOVALUE;

    /** execute.e:1349					private_block[p] = val[arg]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _32797 = (object)*(((s1_ptr)_2)->base + _arg_66416);
    Ref(_32797);
    _2 = (object)SEQ_PTR(_private_block_66419);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _private_block_66419 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _p_66418);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32797;
    if( _1 != _32797 ){
        DeRef(_1);
    }
    _32797 = NOVALUE;

    /** execute.e:1350					p += 1*/
    _p_66418 = _p_66418 + 1;

    /** execute.e:1351					val[arg] = NOVALUE  -- necessary?*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _arg_66416);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
L8: 

    /** execute.e:1353				arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32799 = (object)*(((s1_ptr)_2)->base + _arg_66416);
    _2 = (object)SEQ_PTR(_32799);
    _arg_66416 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_arg_66416)){
        _arg_66416 = (object)DBL_PTR(_arg_66416)->dbl;
    }
    _32799 = NOVALUE;

    /** execute.e:1354			end while*/
    goto L4; // [327] 178
L5: 

    /** execute.e:1357			arg = SymTab[sub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32801 = (object)*(((s1_ptr)_2)->base + _sub_66417);
    _2 = (object)SEQ_PTR(_32801);
    if (!IS_ATOM_INT(_12S_TEMPS_19909)){
        _arg_66416 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TEMPS_19909)->dbl));
    }
    else{
        _arg_66416 = (object)*(((s1_ptr)_2)->base + _12S_TEMPS_19909);
    }
    if (!IS_ATOM_INT(_arg_66416)){
        _arg_66416 = (object)DBL_PTR(_arg_66416)->dbl;
    }
    _32801 = NOVALUE;

    /** execute.e:1358			while arg != 0 do*/
L9: 
    if (_arg_66416 == 0LL)
    goto LA; // [351] 404

    /** execute.e:1359				private_block[p] = val[arg]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _32804 = (object)*(((s1_ptr)_2)->base + _arg_66416);
    Ref(_32804);
    _2 = (object)SEQ_PTR(_private_block_66419);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _private_block_66419 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _p_66418);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32804;
    if( _1 != _32804 ){
        DeRef(_1);
    }
    _32804 = NOVALUE;

    /** execute.e:1360				p += 1*/
    _p_66418 = _p_66418 + 1;

    /** execute.e:1361				val[arg] = NOVALUE -- necessary?*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _arg_66416);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);

    /** execute.e:1362				arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32806 = (object)*(((s1_ptr)_2)->base + _arg_66416);
    _2 = (object)SEQ_PTR(_32806);
    _arg_66416 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_arg_66416)){
        _arg_66416 = (object)DBL_PTR(_arg_66416)->dbl;
    }
    _32806 = NOVALUE;

    /** execute.e:1363			end while*/
    goto L9; // [401] 351
LA: 

    /** execute.e:1366			save_private_block(sub, private_block)*/
    RefDS(_private_block_66419);
    _67save_private_block(_sub_66417, _private_block_66419);
    goto LB; // [410] 479
L1: 

    /** execute.e:1370			for i = 1 to n do*/
    _32808 = _n_66415;
    {
        object _i_66508;
        _i_66508 = 1LL;
LC: 
        if (_i_66508 > _32808){
            goto LD; // [418] 478
        }

        /** execute.e:1371				val[arg] = val[Code[pc+1+i]]*/
        _32809 = _67pc_64877 + 1;
        if (_32809 > MAXINT){
            _32809 = NewDouble((eudouble)_32809);
        }
        if (IS_ATOM_INT(_32809)) {
            _32810 = _32809 + _i_66508;
        }
        else {
            _32810 = NewDouble(DBL_PTR(_32809)->dbl + (eudouble)_i_66508);
        }
        DeRef(_32809);
        _32809 = NOVALUE;
        _2 = (object)SEQ_PTR(_12Code_20315);
        if (!IS_ATOM_INT(_32810)){
            _32811 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32810)->dbl));
        }
        else{
            _32811 = (object)*(((s1_ptr)_2)->base + _32810);
        }
        _2 = (object)SEQ_PTR(_67val_64887);
        if (!IS_ATOM_INT(_32811)){
            _32812 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32811)->dbl));
        }
        else{
            _32812 = (object)*(((s1_ptr)_2)->base + _32811);
        }
        Ref(_32812);
        _2 = (object)SEQ_PTR(_67val_64887);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_64887 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _arg_66416);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _32812;
        if( _1 != _32812 ){
            DeRef(_1);
        }
        _32812 = NOVALUE;

        /** execute.e:1372				arg = SymTab[arg][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _32813 = (object)*(((s1_ptr)_2)->base + _arg_66416);
        _2 = (object)SEQ_PTR(_32813);
        _arg_66416 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_arg_66416)){
            _arg_66416 = (object)DBL_PTR(_arg_66416)->dbl;
        }
        _32813 = NOVALUE;

        /** execute.e:1373			end for*/
        _i_66508 = _i_66508 + 1LL;
        goto LC; // [473] 425
LD: 
        ;
    }
LB: 

    /** execute.e:1376		SymTab[sub][S_RESIDENT_TASK] = current_task*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sub_66417 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67current_task_64894;
    DeRef(_1);
    _32815 = NOVALUE;

    /** execute.e:1378		pc = pc + 2 + n*/
    _32817 = _67pc_64877 + 2LL;
    if ((object)((uintptr_t)_32817 + (uintptr_t)HIGH_BITS) >= 0){
        _32817 = NewDouble((eudouble)_32817);
    }
    if (IS_ATOM_INT(_32817)) {
        _67pc_64877 = _32817 + _n_66415;
    }
    else {
        _67pc_64877 = NewDouble(DBL_PTR(_32817)->dbl + (eudouble)_n_66415);
    }
    DeRef(_32817);
    _32817 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_64877)) {
        _1 = (object)(DBL_PTR(_67pc_64877)->dbl);
        DeRefDS(_67pc_64877);
        _67pc_64877 = _1;
    }

    /** execute.e:1379		if SymTab[sub][S_TOKEN] != PROC then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32819 = (object)*(((s1_ptr)_2)->base + _sub_66417);
    _2 = (object)SEQ_PTR(_32819);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _32820 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _32820 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _32819 = NOVALUE;
    if (binary_op_a(EQUALS, _32820, 27LL)){
        _32820 = NOVALUE;
        goto LE; // [526] 539
    }
    _32820 = NOVALUE;

    /** execute.e:1380			pc += 1*/
    _67pc_64877 = _67pc_64877 + 1;
LE: 

    /** execute.e:1383		call_stack = append(call_stack, pc)*/
    Append(&_67call_stack_64895, _67call_stack_64895, _67pc_64877);

    /** execute.e:1384		call_stack = append(call_stack, sub)*/
    Append(&_67call_stack_64895, _67call_stack_64895, _sub_66417);

    /** execute.e:1386		Code = SymTab[sub][S_CODE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32825 = (object)*(((s1_ptr)_2)->base + _sub_66417);
    DeRef(_12Code_20315);
    _2 = (object)SEQ_PTR(_32825);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    Ref(_12Code_20315);
    _32825 = NOVALUE;

    /** execute.e:1387		pc = 1*/
    _67pc_64877 = 1LL;

    /** execute.e:1388	end procedure*/
    DeRef(_private_block_66419);
    DeRef(_32793);
    _32793 = NOVALUE;
    DeRef(_32785);
    _32785 = NOVALUE;
    DeRef(_32760);
    _32760 = NOVALUE;
    DeRef(_32810);
    _32810 = NOVALUE;
    _32777 = NOVALUE;
    DeRef(_32781);
    _32781 = NOVALUE;
    DeRef(_32776);
    _32776 = NOVALUE;
    DeRef(_32789);
    _32789 = NOVALUE;
    _32811 = NOVALUE;
    return;
    ;
}


void _67exit_block(object _block_66545)
{
    object _a_66546 = NOVALUE;
    object _32830 = NOVALUE;
    object _32827 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_block_66545)) {
        _1 = (object)(DBL_PTR(_block_66545)->dbl);
        DeRefDS(_block_66545);
        _block_66545 = _1;
    }

    /** execute.e:1395		integer a = SymTab[block][S_NEXT_IN_BLOCK]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32827 = (object)*(((s1_ptr)_2)->base + _block_66545);
    _2 = (object)SEQ_PTR(_32827);
    if (!IS_ATOM_INT(_12S_NEXT_IN_BLOCK_19856)){
        _a_66546 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NEXT_IN_BLOCK_19856)->dbl));
    }
    else{
        _a_66546 = (object)*(((s1_ptr)_2)->base + _12S_NEXT_IN_BLOCK_19856);
    }
    if (!IS_ATOM_INT(_a_66546)){
        _a_66546 = (object)DBL_PTR(_a_66546)->dbl;
    }
    _32827 = NOVALUE;

    /** execute.e:1396		while a do*/
L1: 
    if (_a_66546 == 0)
    {
        goto L2; // [24] 60
    }
    else{
    }

    /** execute.e:1398			ifdef DEBUG then*/

    /** execute.e:1407			val[a] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _a_66546);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);

    /** execute.e:1409			a = SymTab[a][S_NEXT_IN_BLOCK]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32830 = (object)*(((s1_ptr)_2)->base + _a_66546);
    _2 = (object)SEQ_PTR(_32830);
    if (!IS_ATOM_INT(_12S_NEXT_IN_BLOCK_19856)){
        _a_66546 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NEXT_IN_BLOCK_19856)->dbl));
    }
    else{
        _a_66546 = (object)*(((s1_ptr)_2)->base + _12S_NEXT_IN_BLOCK_19856);
    }
    if (!IS_ATOM_INT(_a_66546)){
        _a_66546 = (object)DBL_PTR(_a_66546)->dbl;
    }
    _32830 = NOVALUE;

    /** execute.e:1410		end while*/
    goto L1; // [57] 24
L2: 

    /** execute.e:1411	end procedure*/
    return;
    ;
}


void _67opEXIT_BLOCK()
{
    object _32833 = NOVALUE;
    object _32832 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1414		exit_block( Code[pc+1] )*/
    _32832 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32833 = (object)*(((s1_ptr)_2)->base + _32832);
    Ref(_32833);
    _67exit_block(_32833);
    _32833 = NOVALUE;

    /** execute.e:1415		pc += 2*/
    _67pc_64877 = _67pc_64877 + 2LL;

    /** execute.e:1416	end procedure*/
    _32832 = NOVALUE;
    return;
    ;
}


void _67opRETURNP()
{
    object _arg_66567 = NOVALUE;
    object _sub_66568 = NOVALUE;
    object _caller_66569 = NOVALUE;
    object _op_66570 = NOVALUE;
    object _block_66577 = NOVALUE;
    object _sub_block_66582 = NOVALUE;
    object _local_result_66587 = NOVALUE;
    object _local_result_val_66588 = NOVALUE;
    object _32858 = NOVALUE;
    object _32856 = NOVALUE;
    object _32854 = NOVALUE;
    object _32853 = NOVALUE;
    object _32851 = NOVALUE;
    object _32849 = NOVALUE;
    object _32848 = NOVALUE;
    object _32846 = NOVALUE;
    object _32845 = NOVALUE;
    object _32843 = NOVALUE;
    object _32840 = NOVALUE;
    object _32838 = NOVALUE;
    object _32836 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1421		integer op = Code[pc]*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    _op_66570 = (object)*(((s1_ptr)_2)->base + _67pc_64877);
    if (!IS_ATOM_INT(_op_66570)){
        _op_66570 = (object)DBL_PTR(_op_66570)->dbl;
    }

    /** execute.e:1422		sub = Code[pc+1]*/
    _32836 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _sub_66568 = (object)*(((s1_ptr)_2)->base + _32836);
    if (!IS_ATOM_INT(_sub_66568)){
        _sub_66568 = (object)DBL_PTR(_sub_66568)->dbl;
    }

    /** execute.e:1425		symtab_index block = Code[pc+2]*/
    _32838 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _block_66577 = (object)*(((s1_ptr)_2)->base + _32838);
    if (!IS_ATOM_INT(_block_66577)){
        _block_66577 = (object)DBL_PTR(_block_66577)->dbl;
    }

    /** execute.e:1426		symtab_index sub_block = SymTab[sub][S_BLOCK]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32840 = (object)*(((s1_ptr)_2)->base + _sub_66568);
    _2 = (object)SEQ_PTR(_32840);
    if (!IS_ATOM_INT(_12S_BLOCK_19884)){
        _sub_block_66582 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_BLOCK_19884)->dbl));
    }
    else{
        _sub_block_66582 = (object)*(((s1_ptr)_2)->base + _12S_BLOCK_19884);
    }
    if (!IS_ATOM_INT(_sub_block_66582)){
        _sub_block_66582 = (object)DBL_PTR(_sub_block_66582)->dbl;
    }
    _32840 = NOVALUE;

    /** execute.e:1428		integer local_result = result*/
    _local_result_66587 = _67result_66540;

    /** execute.e:1429		object local_result_val*/

    /** execute.e:1430		if local_result then*/
    if (_local_result_66587 == 0)
    {
        goto L1; // [72] 95
    }
    else{
    }

    /** execute.e:1431			result = 0*/
    _67result_66540 = 0LL;

    /** execute.e:1432			local_result_val = result_val*/
    Ref(_67result_val_66541);
    DeRef(_local_result_val_66588);
    _local_result_val_66588 = _67result_val_66541;

    /** execute.e:1433			result_val = NOVALUE*/
    Ref(_12NOVALUE_20081);
    DeRef(_67result_val_66541);
    _67result_val_66541 = _12NOVALUE_20081;
L1: 

    /** execute.e:1436		while block != sub_block do*/
L2: 
    if (_block_66577 == _sub_block_66582)
    goto L3; // [100] 136

    /** execute.e:1437			if local_result then*/
    if (_local_result_66587 == 0)
    {
        goto L4; // [106] 115
    }
    else{
    }

    /** execute.e:1438				exit_block( block )*/
    _67exit_block(_block_66577);
L4: 

    /** execute.e:1440			block = SymTab[block][S_BLOCK]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32843 = (object)*(((s1_ptr)_2)->base + _block_66577);
    _2 = (object)SEQ_PTR(_32843);
    if (!IS_ATOM_INT(_12S_BLOCK_19884)){
        _block_66577 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_BLOCK_19884)->dbl));
    }
    else{
        _block_66577 = (object)*(((s1_ptr)_2)->base + _12S_BLOCK_19884);
    }
    if (!IS_ATOM_INT(_block_66577)){
        _block_66577 = (object)DBL_PTR(_block_66577)->dbl;
    }
    _32843 = NOVALUE;

    /** execute.e:1441		end while*/
    goto L2; // [133] 100
L3: 

    /** execute.e:1443		exit_block( sub_block )*/
    _67exit_block(_sub_block_66582);

    /** execute.e:1451		pc = call_stack[$-1]*/
    if (IS_SEQUENCE(_67call_stack_64895)){
            _32845 = SEQ_PTR(_67call_stack_64895)->length;
    }
    else {
        _32845 = 1;
    }
    _32846 = _32845 - 1LL;
    _32845 = NOVALUE;
    _2 = (object)SEQ_PTR(_67call_stack_64895);
    _67pc_64877 = (object)*(((s1_ptr)_2)->base + _32846);
    if (!IS_ATOM_INT(_67pc_64877))
    _67pc_64877 = (object)DBL_PTR(_67pc_64877)->dbl;

    /** execute.e:1452		call_stack = call_stack[1..$-2]*/
    if (IS_SEQUENCE(_67call_stack_64895)){
            _32848 = SEQ_PTR(_67call_stack_64895)->length;
    }
    else {
        _32848 = 1;
    }
    _32849 = _32848 - 2LL;
    _32848 = NOVALUE;
    rhs_slice_target = (object_ptr)&_67call_stack_64895;
    RHS_Slice(_67call_stack_64895, 1LL, _32849);

    /** execute.e:1454		SymTab[sub][S_RESIDENT_TASK] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sub_66568 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _32851 = NOVALUE;

    /** execute.e:1456		if length(call_stack) then*/
    if (IS_SEQUENCE(_67call_stack_64895)){
            _32853 = SEQ_PTR(_67call_stack_64895)->length;
    }
    else {
        _32853 = 1;
    }
    if (_32853 == 0)
    {
        _32853 = NOVALUE;
        goto L5; // [194] 256
    }
    else{
        _32853 = NOVALUE;
    }

    /** execute.e:1457			caller = call_stack[$]*/
    if (IS_SEQUENCE(_67call_stack_64895)){
            _32854 = SEQ_PTR(_67call_stack_64895)->length;
    }
    else {
        _32854 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_64895);
    _caller_66569 = (object)*(((s1_ptr)_2)->base + _32854);
    if (!IS_ATOM_INT(_caller_66569)){
        _caller_66569 = (object)DBL_PTR(_caller_66569)->dbl;
    }

    /** execute.e:1458			Code = SymTab[caller][S_CODE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32856 = (object)*(((s1_ptr)_2)->base + _caller_66569);
    DeRef(_12Code_20315);
    _2 = (object)SEQ_PTR(_32856);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    Ref(_12Code_20315);
    _32856 = NOVALUE;

    /** execute.e:1459			restore_privates(caller)*/
    _67restore_privates(_caller_66569);

    /** execute.e:1460			if local_result then*/
    if (_local_result_66587 == 0)
    {
        goto L6; // [233] 268
    }
    else{
    }

    /** execute.e:1461				val[Code[local_result]] = local_result_val*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32858 = (object)*(((s1_ptr)_2)->base + _local_result_66587);
    Ref(_local_result_val_66588);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_32858))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_32858)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _32858);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _local_result_val_66588;
    DeRef(_1);
    goto L6; // [253] 268
L5: 

    /** execute.e:1464			kill_task(current_task)*/
    _67kill_task(_67current_task_64894);

    /** execute.e:1465			scheduler()*/
    _67scheduler();
L6: 

    /** execute.e:1469	end procedure*/
    DeRef(_local_result_val_66588);
    _32858 = NOVALUE;
    DeRef(_32846);
    _32846 = NOVALUE;
    DeRef(_32836);
    _32836 = NOVALUE;
    DeRef(_32849);
    _32849 = NOVALUE;
    DeRef(_32838);
    _32838 = NOVALUE;
    return;
    ;
}


void _67opRETURNF()
{
    object _32864 = NOVALUE;
    object _32863 = NOVALUE;
    object _32862 = NOVALUE;
    object _32860 = NOVALUE;
    object _32859 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1473		result_val = val[Code[pc+3]]*/
    _32859 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32860 = (object)*(((s1_ptr)_2)->base + _32859);
    DeRef(_67result_val_66541);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!IS_ATOM_INT(_32860)){
        _67result_val_66541 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32860)->dbl));
    }
    else{
        _67result_val_66541 = (object)*(((s1_ptr)_2)->base + _32860);
    }
    Ref(_67result_val_66541);

    /** execute.e:1474		result = call_stack[$-1] - 1*/
    if (IS_SEQUENCE(_67call_stack_64895)){
            _32862 = SEQ_PTR(_67call_stack_64895)->length;
    }
    else {
        _32862 = 1;
    }
    _32863 = _32862 - 1LL;
    _32862 = NOVALUE;
    _2 = (object)SEQ_PTR(_67call_stack_64895);
    _32864 = (object)*(((s1_ptr)_2)->base + _32863);
    if (IS_ATOM_INT(_32864)) {
        _67result_66540 = _32864 - 1LL;
    }
    else {
        _67result_66540 = binary_op(MINUS, _32864, 1LL);
    }
    _32864 = NOVALUE;
    if (!IS_ATOM_INT(_67result_66540)) {
        _1 = (object)(DBL_PTR(_67result_66540)->dbl);
        DeRefDS(_67result_66540);
        _67result_66540 = _1;
    }

    /** execute.e:1475		opRETURNP()*/
    _67opRETURNP();

    /** execute.e:1476	end procedure*/
    _32860 = NOVALUE;
    _32863 = NOVALUE;
    _32859 = NOVALUE;
    return;
    ;
}


void _67opCALL_BACK_RETURN()
{
    object _0, _1, _2;
    

    /** execute.e:1480		keep_running = FALSE*/
    _67keep_running_64884 = _9FALSE_444;

    /** execute.e:1481	end procedure*/
    return;
    ;
}


void _67opBADRETURNF()
{
    object _0, _1, _2;
    

    /** execute.e:1485		RTFatal("attempt to exit a function without returning a value")*/
    RefDS(_32866);
    _67RTFatal(_32866);

    /** execute.e:1486	end procedure*/
    return;
    ;
}


void _67opRETURNT()
{
    object _32868 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1490		pc += 1*/
    _67pc_64877 = _67pc_64877 + 1;

    /** execute.e:1491		if pc > length(Code) then*/
    if (IS_SEQUENCE(_12Code_20315)){
            _32868 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _32868 = 1;
    }
    if (_67pc_64877 <= _32868)
    goto L1; // [18] 32

    /** execute.e:1492			keep_running = FALSE  -- we've reached the end of the code*/
    _67keep_running_64884 = _9FALSE_444;
L1: 

    /** execute.e:1494	end procedure*/
    return;
    ;
}


void _67opRHS_SUBS()
{
    object _sub_66647 = NOVALUE;
    object _x_66648 = NOVALUE;
    object _32891 = NOVALUE;
    object _32890 = NOVALUE;
    object _32889 = NOVALUE;
    object _32888 = NOVALUE;
    object _32886 = NOVALUE;
    object _32885 = NOVALUE;
    object _32883 = NOVALUE;
    object _32880 = NOVALUE;
    object _32878 = NOVALUE;
    object _32874 = NOVALUE;
    object _32872 = NOVALUE;
    object _32870 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1501		a = Code[pc+1]*/
    _32870 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _32870);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:1502		b = Code[pc+2]*/
    _32872 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _32872);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:1503		target = Code[pc+3]*/
    _32874 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _32874);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:1504		x = val[a]*/
    DeRef(_x_66648);
    _2 = (object)SEQ_PTR(_67val_64887);
    _x_66648 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    Ref(_x_66648);

    /** execute.e:1505		sub = val[b]*/
    DeRef(_sub_66647);
    _2 = (object)SEQ_PTR(_67val_64887);
    _sub_66647 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    Ref(_sub_66647);

    /** execute.e:1506		if atom(x) then*/
    _32878 = IS_ATOM(_x_66648);
    if (_32878 == 0)
    {
        _32878 = NOVALUE;
        goto L1; // [74] 83
    }
    else{
        _32878 = NOVALUE;
    }

    /** execute.e:1507			RTFatal("attempt to subscript an atom\n(reading from it)")*/
    RefDS(_32879);
    _67RTFatal(_32879);
L1: 

    /** execute.e:1509		if sequence(sub) then*/
    _32880 = IS_SEQUENCE(_sub_66647);
    if (_32880 == 0)
    {
        _32880 = NOVALUE;
        goto L2; // [88] 97
    }
    else{
        _32880 = NOVALUE;
    }

    /** execute.e:1510			RTFatal("subscript must be an atom\n(reading an element of a sequence)")*/
    RefDS(_32881);
    _67RTFatal(_32881);
L2: 

    /** execute.e:1512		sub = floor(sub)*/
    _0 = _sub_66647;
    if (IS_ATOM_INT(_sub_66647))
    _sub_66647 = e_floor(_sub_66647);
    else
    _sub_66647 = unary_op(FLOOR, _sub_66647);
    DeRef(_0);

    /** execute.e:1513		if sub < 1 or sub > length(x) then*/
    if (IS_ATOM_INT(_sub_66647)) {
        _32883 = (_sub_66647 < 1LL);
    }
    else {
        _32883 = binary_op(LESS, _sub_66647, 1LL);
    }
    if (IS_ATOM_INT(_32883)) {
        if (_32883 != 0) {
            goto L3; // [108] 124
        }
    }
    else {
        if (DBL_PTR(_32883)->dbl != 0.0) {
            goto L3; // [108] 124
        }
    }
    if (IS_SEQUENCE(_x_66648)){
            _32885 = SEQ_PTR(_x_66648)->length;
    }
    else {
        _32885 = 1;
    }
    if (IS_ATOM_INT(_sub_66647)) {
        _32886 = (_sub_66647 > _32885);
    }
    else {
        _32886 = binary_op(GREATER, _sub_66647, _32885);
    }
    _32885 = NOVALUE;
    if (_32886 == 0) {
        DeRef(_32886);
        _32886 = NOVALUE;
        goto L4; // [120] 141
    }
    else {
        if (!IS_ATOM_INT(_32886) && DBL_PTR(_32886)->dbl == 0.0){
            DeRef(_32886);
            _32886 = NOVALUE;
            goto L4; // [120] 141
        }
        DeRef(_32886);
        _32886 = NOVALUE;
    }
    DeRef(_32886);
    _32886 = NOVALUE;
L3: 

    /** execute.e:1514			RTFatal(*/
    if (IS_SEQUENCE(_x_66648)){
            _32888 = SEQ_PTR(_x_66648)->length;
    }
    else {
        _32888 = 1;
    }
    Ref(_sub_66647);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _sub_66647;
    ((intptr_t *)_2)[2] = _32888;
    _32889 = MAKE_SEQ(_1);
    _32888 = NOVALUE;
    _32890 = EPrintf(-9999999, _32887, _32889);
    DeRefDS(_32889);
    _32889 = NOVALUE;
    _67RTFatal(_32890);
    _32890 = NOVALUE;
L4: 

    /** execute.e:1519		val[target] = x[sub]*/
    _2 = (object)SEQ_PTR(_x_66648);
    if (!IS_ATOM_INT(_sub_66647)){
        _32891 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_sub_66647)->dbl));
    }
    else{
        _32891 = (object)*(((s1_ptr)_2)->base + _sub_66647);
    }
    Ref(_32891);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32891;
    if( _1 != _32891 ){
        DeRef(_1);
    }
    _32891 = NOVALUE;

    /** execute.e:1520		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:1521	end procedure*/
    DeRef(_sub_66647);
    DeRef(_x_66648);
    DeRef(_32874);
    _32874 = NOVALUE;
    DeRef(_32883);
    _32883 = NOVALUE;
    DeRef(_32870);
    _32870 = NOVALUE;
    DeRef(_32872);
    _32872 = NOVALUE;
    return;
    ;
}


void _67opGOTO()
{
    object _32893 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1524		pc = Code[pc+1]*/
    _32893 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64877 = (object)*(((s1_ptr)_2)->base + _32893);
    if (!IS_ATOM_INT(_67pc_64877)){
        _67pc_64877 = (object)DBL_PTR(_67pc_64877)->dbl;
    }

    /** execute.e:1525	end procedure*/
    _32893 = NOVALUE;
    return;
    ;
}


void _67opGLABEL()
{
    object _32895 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1527		pc = Code[pc+1]*/
    _32895 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64877 = (object)*(((s1_ptr)_2)->base + _32895);
    if (!IS_ATOM_INT(_67pc_64877)){
        _67pc_64877 = (object)DBL_PTR(_67pc_64877)->dbl;
    }

    /** execute.e:1528	end procedure*/
    _32895 = NOVALUE;
    return;
    ;
}


void _67opIF()
{
    object _32901 = NOVALUE;
    object _32899 = NOVALUE;
    object _32897 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1531		a = Code[pc+1]*/
    _32897 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _32897);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:1532		if val[a] = 0 then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _32899 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (binary_op_a(NOTEQ, _32899, 0LL)){
        _32899 = NOVALUE;
        goto L1; // [27] 50
    }
    _32899 = NOVALUE;

    /** execute.e:1533			pc = Code[pc+2]*/
    _32901 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64877 = (object)*(((s1_ptr)_2)->base + _32901);
    if (!IS_ATOM_INT(_67pc_64877)){
        _67pc_64877 = (object)DBL_PTR(_67pc_64877)->dbl;
    }
    goto L2; // [47] 59
L1: 

    /** execute.e:1535			pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;
L2: 

    /** execute.e:1537	end procedure*/
    DeRef(_32901);
    _32901 = NOVALUE;
    DeRef(_32897);
    _32897 = NOVALUE;
    return;
    ;
}


void _67opINTEGER_CHECK()
{
    object _32909 = NOVALUE;
    object _32907 = NOVALUE;
    object _32906 = NOVALUE;
    object _32904 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1540		a = Code[pc+1]*/
    _32904 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _32904);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:1541		if not integer(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _32906 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_ATOM_INT(_32906))
    _32907 = 1;
    else if (IS_ATOM_DBL(_32906))
    _32907 = IS_ATOM_INT(DoubleToInt(_32906));
    else
    _32907 = 0;
    _32906 = NOVALUE;
    if (_32907 != 0)
    goto L1; // [30] 45
    _32907 = NOVALUE;

    /** execute.e:1542			RTFatalType(pc+1)*/
    _32909 = _67pc_64877 + 1;
    if (_32909 > MAXINT){
        _32909 = NewDouble((eudouble)_32909);
    }
    _67RTFatalType(_32909);
    _32909 = NOVALUE;
L1: 

    /** execute.e:1544		pc += 2*/
    _67pc_64877 = _67pc_64877 + 2LL;

    /** execute.e:1545	end procedure*/
    DeRef(_32904);
    _32904 = NOVALUE;
    return;
    ;
}


void _67opATOM_CHECK()
{
    object _32916 = NOVALUE;
    object _32914 = NOVALUE;
    object _32913 = NOVALUE;
    object _32911 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1548		a = Code[pc+1]*/
    _32911 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _32911);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:1549		if not atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _32913 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _32914 = IS_ATOM(_32913);
    _32913 = NOVALUE;
    if (_32914 != 0)
    goto L1; // [30] 45
    _32914 = NOVALUE;

    /** execute.e:1550			RTFatalType(pc+1)*/
    _32916 = _67pc_64877 + 1;
    if (_32916 > MAXINT){
        _32916 = NewDouble((eudouble)_32916);
    }
    _67RTFatalType(_32916);
    _32916 = NOVALUE;
L1: 

    /** execute.e:1552		pc += 2*/
    _67pc_64877 = _67pc_64877 + 2LL;

    /** execute.e:1553	end procedure*/
    DeRef(_32911);
    _32911 = NOVALUE;
    return;
    ;
}


void _67opSEQUENCE_CHECK()
{
    object _32923 = NOVALUE;
    object _32921 = NOVALUE;
    object _32920 = NOVALUE;
    object _32918 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1556		a = Code[pc+1]*/
    _32918 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _32918);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:1557		if not sequence(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _32920 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _32921 = IS_SEQUENCE(_32920);
    _32920 = NOVALUE;
    if (_32921 != 0)
    goto L1; // [30] 45
    _32921 = NOVALUE;

    /** execute.e:1558			RTFatalType(pc+1)*/
    _32923 = _67pc_64877 + 1;
    if (_32923 > MAXINT){
        _32923 = NewDouble((eudouble)_32923);
    }
    _67RTFatalType(_32923);
    _32923 = NOVALUE;
L1: 

    /** execute.e:1560		pc += 2*/
    _67pc_64877 = _67pc_64877 + 2LL;

    /** execute.e:1561	end procedure*/
    DeRef(_32918);
    _32918 = NOVALUE;
    return;
    ;
}


void _67opASSIGN()
{
    object _a_66736 = NOVALUE;
    object _32930 = NOVALUE;
    object _32929 = NOVALUE;
    object _32927 = NOVALUE;
    object _32925 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1565		integer a = Code[pc+1]*/
    _32925 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _a_66736 = (object)*(((s1_ptr)_2)->base + _32925);
    if (!IS_ATOM_INT(_a_66736)){
        _a_66736 = (object)DBL_PTR(_a_66736)->dbl;
    }

    /** execute.e:1566		target = Code[pc+2]*/
    _32927 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _32927);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:1567		val[target] = val[a]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _32929 = (object)*(((s1_ptr)_2)->base + _a_66736);
    Ref(_32929);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32929;
    if( _1 != _32929 ){
        DeRef(_1);
    }
    _32929 = NOVALUE;

    /** execute.e:1568		if sym_mode( a ) = M_TEMP then*/
    _32930 = _53sym_mode(_a_66736);
    if (binary_op_a(NOTEQ, _32930, 3LL)){
        DeRef(_32930);
        _32930 = NOVALUE;
        goto L1; // [57] 72
    }
    DeRef(_32930);
    _32930 = NOVALUE;

    /** execute.e:1569			val[a] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _a_66736);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
L1: 

    /** execute.e:1571		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:1572	end procedure*/
    DeRef(_32927);
    _32927 = NOVALUE;
    DeRef(_32925);
    _32925 = NOVALUE;
    return;
    ;
}


void _67opELSE()
{
    object _32933 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1576		pc = Code[pc+1]*/
    _32933 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64877 = (object)*(((s1_ptr)_2)->base + _32933);
    if (!IS_ATOM_INT(_67pc_64877)){
        _67pc_64877 = (object)DBL_PTR(_67pc_64877)->dbl;
    }

    /** execute.e:1577	end procedure*/
    _32933 = NOVALUE;
    return;
    ;
}


void _67opRIGHT_BRACE_N()
{
    object _x_66758 = NOVALUE;
    object _32950 = NOVALUE;
    object _32948 = NOVALUE;
    object _32947 = NOVALUE;
    object _32946 = NOVALUE;
    object _32944 = NOVALUE;
    object _32943 = NOVALUE;
    object _32941 = NOVALUE;
    object _32940 = NOVALUE;
    object _32939 = NOVALUE;
    object _32938 = NOVALUE;
    object _32937 = NOVALUE;
    object _32935 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1583		len = Code[pc+1]*/
    _32935 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67len_64883 = (object)*(((s1_ptr)_2)->base + _32935);
    if (!IS_ATOM_INT(_67len_64883)){
        _67len_64883 = (object)DBL_PTR(_67len_64883)->dbl;
    }

    /** execute.e:1584		x = {}*/
    RefDS(_22024);
    DeRef(_x_66758);
    _x_66758 = _22024;

    /** execute.e:1585		for i = pc+len+1 to pc+2 by -1 do*/
    _32937 = _67pc_64877 + _67len_64883;
    if ((object)((uintptr_t)_32937 + (uintptr_t)HIGH_BITS) >= 0){
        _32937 = NewDouble((eudouble)_32937);
    }
    if (IS_ATOM_INT(_32937)) {
        _32938 = _32937 + 1;
        if (_32938 > MAXINT){
            _32938 = NewDouble((eudouble)_32938);
        }
    }
    else
    _32938 = binary_op(PLUS, 1, _32937);
    DeRef(_32937);
    _32937 = NOVALUE;
    _32939 = _67pc_64877 + 2LL;
    if ((object)((uintptr_t)_32939 + (uintptr_t)HIGH_BITS) >= 0){
        _32939 = NewDouble((eudouble)_32939);
    }
    {
        object _i_66763;
        Ref(_32938);
        _i_66763 = _32938;
L1: 
        if (binary_op_a(LESS, _i_66763, _32939)){
            goto L2; // [44] 111
        }

        /** execute.e:1587			x = append(x, val[Code[i]])*/
        _2 = (object)SEQ_PTR(_12Code_20315);
        if (!IS_ATOM_INT(_i_66763)){
            _32940 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_66763)->dbl));
        }
        else{
            _32940 = (object)*(((s1_ptr)_2)->base + _i_66763);
        }
        _2 = (object)SEQ_PTR(_67val_64887);
        if (!IS_ATOM_INT(_32940)){
            _32941 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32940)->dbl));
        }
        else{
            _32941 = (object)*(((s1_ptr)_2)->base + _32940);
        }
        Ref(_32941);
        Append(&_x_66758, _x_66758, _32941);
        _32941 = NOVALUE;

        /** execute.e:1588			if sym_mode( Code[i] ) = M_TEMP then*/
        _2 = (object)SEQ_PTR(_12Code_20315);
        if (!IS_ATOM_INT(_i_66763)){
            _32943 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_66763)->dbl));
        }
        else{
            _32943 = (object)*(((s1_ptr)_2)->base + _i_66763);
        }
        Ref(_32943);
        _32944 = _53sym_mode(_32943);
        _32943 = NOVALUE;
        if (binary_op_a(NOTEQ, _32944, 3LL)){
            DeRef(_32944);
            _32944 = NOVALUE;
            goto L3; // [83] 104
        }
        DeRef(_32944);
        _32944 = NOVALUE;

        /** execute.e:1589				val[Code[i]] = NOVALUE*/
        _2 = (object)SEQ_PTR(_12Code_20315);
        if (!IS_ATOM_INT(_i_66763)){
            _32946 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_66763)->dbl));
        }
        else{
            _32946 = (object)*(((s1_ptr)_2)->base + _i_66763);
        }
        Ref(_12NOVALUE_20081);
        _2 = (object)SEQ_PTR(_67val_64887);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_64887 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_32946))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_32946)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _32946);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _12NOVALUE_20081;
        DeRef(_1);
L3: 

        /** execute.e:1591		end for*/
        _0 = _i_66763;
        if (IS_ATOM_INT(_i_66763)) {
            _i_66763 = _i_66763 + -1LL;
            if ((object)((uintptr_t)_i_66763 +(uintptr_t) HIGH_BITS) >= 0){
                _i_66763 = NewDouble((eudouble)_i_66763);
            }
        }
        else {
            _i_66763 = binary_op_a(PLUS, _i_66763, -1LL);
        }
        DeRef(_0);
        goto L1; // [106] 51
L2: 
        ;
        DeRef(_i_66763);
    }

    /** execute.e:1592		target = Code[pc+len+2]*/
    _32947 = _67pc_64877 + _67len_64883;
    if ((object)((uintptr_t)_32947 + (uintptr_t)HIGH_BITS) >= 0){
        _32947 = NewDouble((eudouble)_32947);
    }
    if (IS_ATOM_INT(_32947)) {
        _32948 = _32947 + 2LL;
    }
    else {
        _32948 = NewDouble(DBL_PTR(_32947)->dbl + (eudouble)2LL);
    }
    DeRef(_32947);
    _32947 = NOVALUE;
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!IS_ATOM_INT(_32948)){
        _67target_64882 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32948)->dbl));
    }
    else{
        _67target_64882 = (object)*(((s1_ptr)_2)->base + _32948);
    }
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:1593		val[target] = x*/
    RefDS(_x_66758);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _x_66758;
    DeRef(_1);

    /** execute.e:1594		pc += 3 + len*/
    _32950 = 3LL + _67len_64883;
    if ((object)((uintptr_t)_32950 + (uintptr_t)HIGH_BITS) >= 0){
        _32950 = NewDouble((eudouble)_32950);
    }
    if (IS_ATOM_INT(_32950)) {
        _67pc_64877 = _67pc_64877 + _32950;
    }
    else {
        _67pc_64877 = NewDouble((eudouble)_67pc_64877 + DBL_PTR(_32950)->dbl);
    }
    DeRef(_32950);
    _32950 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_64877)) {
        _1 = (object)(DBL_PTR(_67pc_64877)->dbl);
        DeRefDS(_67pc_64877);
        _67pc_64877 = _1;
    }

    /** execute.e:1595	end procedure*/
    DeRefDS(_x_66758);
    _32946 = NOVALUE;
    DeRef(_32948);
    _32948 = NOVALUE;
    DeRef(_32938);
    _32938 = NOVALUE;
    DeRef(_32935);
    _32935 = NOVALUE;
    _32940 = NOVALUE;
    DeRef(_32939);
    _32939 = NOVALUE;
    return;
    ;
}


void _67opRIGHT_BRACE_2()
{
    object _32972 = NOVALUE;
    object _32971 = NOVALUE;
    object _32969 = NOVALUE;
    object _32968 = NOVALUE;
    object _32967 = NOVALUE;
    object _32966 = NOVALUE;
    object _32965 = NOVALUE;
    object _32963 = NOVALUE;
    object _32962 = NOVALUE;
    object _32961 = NOVALUE;
    object _32960 = NOVALUE;
    object _32959 = NOVALUE;
    object _32958 = NOVALUE;
    object _32957 = NOVALUE;
    object _32956 = NOVALUE;
    object _32955 = NOVALUE;
    object _32954 = NOVALUE;
    object _32952 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1599		target = Code[pc+3]*/
    _32952 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _32952);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:1601		val[target] = {val[Code[pc+2]], val[Code[pc+1]]}*/
    _32954 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32955 = (object)*(((s1_ptr)_2)->base + _32954);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!IS_ATOM_INT(_32955)){
        _32956 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32955)->dbl));
    }
    else{
        _32956 = (object)*(((s1_ptr)_2)->base + _32955);
    }
    _32957 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32958 = (object)*(((s1_ptr)_2)->base + _32957);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!IS_ATOM_INT(_32958)){
        _32959 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32958)->dbl));
    }
    else{
        _32959 = (object)*(((s1_ptr)_2)->base + _32958);
    }
    Ref(_32959);
    Ref(_32956);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _32956;
    ((intptr_t *)_2)[2] = _32959;
    _32960 = MAKE_SEQ(_1);
    _32959 = NOVALUE;
    _32956 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32960;
    if( _1 != _32960 ){
        DeRef(_1);
    }
    _32960 = NOVALUE;

    /** execute.e:1602		if sym_mode( Code[pc+2] ) = M_TEMP then*/
    _32961 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32962 = (object)*(((s1_ptr)_2)->base + _32961);
    Ref(_32962);
    _32963 = _53sym_mode(_32962);
    _32962 = NOVALUE;
    if (binary_op_a(NOTEQ, _32963, 3LL)){
        DeRef(_32963);
        _32963 = NOVALUE;
        goto L1; // [87] 114
    }
    DeRef(_32963);
    _32963 = NOVALUE;

    /** execute.e:1603			val[Code[pc+2]] = NOVALUE*/
    _32965 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32966 = (object)*(((s1_ptr)_2)->base + _32965);
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_32966))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_32966)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _32966);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
L1: 

    /** execute.e:1605		if sym_mode( Code[pc+1] ) = M_TEMP then*/
    _32967 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32968 = (object)*(((s1_ptr)_2)->base + _32967);
    Ref(_32968);
    _32969 = _53sym_mode(_32968);
    _32968 = NOVALUE;
    if (binary_op_a(NOTEQ, _32969, 3LL)){
        DeRef(_32969);
        _32969 = NOVALUE;
        goto L2; // [134] 161
    }
    DeRef(_32969);
    _32969 = NOVALUE;

    /** execute.e:1606			val[Code[pc+1]] = NOVALUE*/
    _32971 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32972 = (object)*(((s1_ptr)_2)->base + _32971);
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_32972))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_32972)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _32972);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
L2: 

    /** execute.e:1608		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:1609	end procedure*/
    DeRef(_32961);
    _32961 = NOVALUE;
    DeRef(_32957);
    _32957 = NOVALUE;
    DeRef(_32971);
    _32971 = NOVALUE;
    _32955 = NOVALUE;
    DeRef(_32967);
    _32967 = NOVALUE;
    _32958 = NOVALUE;
    _32966 = NOVALUE;
    DeRef(_32952);
    _32952 = NOVALUE;
    _32972 = NOVALUE;
    DeRef(_32965);
    _32965 = NOVALUE;
    DeRef(_32954);
    _32954 = NOVALUE;
    return;
    ;
}


void _67opPLUS1()
{
    object _32979 = NOVALUE;
    object _32978 = NOVALUE;
    object _32976 = NOVALUE;
    object _32974 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1613		a = Code[pc+1]*/
    _32974 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _32974);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:1615		target = Code[pc+3]*/
    _32976 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _32976);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:1616		val[target] = val[a] + 1*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _32978 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_ATOM_INT(_32978)) {
        _32979 = _32978 + 1;
        if (_32979 > MAXINT){
            _32979 = NewDouble((eudouble)_32979);
        }
    }
    else
    _32979 = binary_op(PLUS, 1, _32978);
    _32978 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32979;
    if( _1 != _32979 ){
        DeRef(_1);
    }
    _32979 = NOVALUE;

    /** execute.e:1617		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:1618	end procedure*/
    _32974 = NOVALUE;
    _32976 = NOVALUE;
    return;
    ;
}


void _67opGLOBAL_INIT_CHECK()
{
    object _32989 = NOVALUE;
    object _32987 = NOVALUE;
    object _32986 = NOVALUE;
    object _32984 = NOVALUE;
    object _32983 = NOVALUE;
    object _32981 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1622		a = Code[pc+1]*/
    _32981 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _32981);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:1623		if equal(val[a], NOVALUE) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _32983 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (_32983 == _12NOVALUE_20081)
    _32984 = 1;
    else if (IS_ATOM_INT(_32983) && IS_ATOM_INT(_12NOVALUE_20081))
    _32984 = 0;
    else
    _32984 = (compare(_32983, _12NOVALUE_20081) == 0);
    _32983 = NOVALUE;
    if (_32984 == 0)
    {
        _32984 = NOVALUE;
        goto L1; // [33] 62
    }
    else{
        _32984 = NOVALUE;
    }

    /** execute.e:1624			RTFatal("variable " & SymTab[a][S_NAME] & " has not been assigned a value")*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _32986 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_32986);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _32987 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _32987 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _32986 = NOVALUE;
    {
        object concat_list[3];

        concat_list[0] = _32988;
        concat_list[1] = _32987;
        concat_list[2] = _32985;
        Concat_N((object_ptr)&_32989, concat_list, 3);
    }
    _32987 = NOVALUE;
    _67RTFatal(_32989);
    _32989 = NOVALUE;
L1: 

    /** execute.e:1626		pc += 2*/
    _67pc_64877 = _67pc_64877 + 2LL;

    /** execute.e:1627	end procedure*/
    DeRef(_32981);
    _32981 = NOVALUE;
    return;
    ;
}


void _67opWHILE()
{
    object _32995 = NOVALUE;
    object _32993 = NOVALUE;
    object _32991 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1631		a = Code[pc+1]*/
    _32991 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _32991);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:1632		if val[a] = 0 then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _32993 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (binary_op_a(NOTEQ, _32993, 0LL)){
        _32993 = NOVALUE;
        goto L1; // [27] 50
    }
    _32993 = NOVALUE;

    /** execute.e:1633			pc = Code[pc+2]*/
    _32995 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64877 = (object)*(((s1_ptr)_2)->base + _32995);
    if (!IS_ATOM_INT(_67pc_64877)){
        _67pc_64877 = (object)DBL_PTR(_67pc_64877)->dbl;
    }
    goto L2; // [47] 59
L1: 

    /** execute.e:1635			pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;
L2: 

    /** execute.e:1637	end procedure*/
    DeRef(_32995);
    _32995 = NOVALUE;
    DeRef(_32991);
    _32991 = NOVALUE;
    return;
    ;
}


void _67opSWITCH_SPI()
{
    object _33020 = NOVALUE;
    object _33018 = NOVALUE;
    object _33017 = NOVALUE;
    object _33016 = NOVALUE;
    object _33015 = NOVALUE;
    object _33014 = NOVALUE;
    object _33013 = NOVALUE;
    object _33012 = NOVALUE;
    object _33011 = NOVALUE;
    object _33010 = NOVALUE;
    object _33009 = NOVALUE;
    object _33008 = NOVALUE;
    object _33006 = NOVALUE;
    object _33005 = NOVALUE;
    object _33004 = NOVALUE;
    object _33003 = NOVALUE;
    object _33002 = NOVALUE;
    object _33001 = NOVALUE;
    object _33000 = NOVALUE;
    object _32999 = NOVALUE;
    object _32998 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1645		if integer( val[Code[pc+1]] ) then*/
    _32998 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _32999 = (object)*(((s1_ptr)_2)->base + _32998);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!IS_ATOM_INT(_32999)){
        _33000 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32999)->dbl));
    }
    else{
        _33000 = (object)*(((s1_ptr)_2)->base + _32999);
    }
    if (IS_ATOM_INT(_33000))
    _33001 = 1;
    else if (IS_ATOM_DBL(_33000))
    _33001 = IS_ATOM_INT(DoubleToInt(_33000));
    else
    _33001 = 0;
    _33000 = NOVALUE;
    if (_33001 == 0)
    {
        _33001 = NOVALUE;
        goto L1; // [24] 149
    }
    else{
        _33001 = NOVALUE;
    }

    /** execute.e:1646			a = val[Code[pc+1]] - Code[pc+2]*/
    _33002 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _33003 = (object)*(((s1_ptr)_2)->base + _33002);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!IS_ATOM_INT(_33003)){
        _33004 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33003)->dbl));
    }
    else{
        _33004 = (object)*(((s1_ptr)_2)->base + _33003);
    }
    _33005 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _33006 = (object)*(((s1_ptr)_2)->base + _33005);
    if (IS_ATOM_INT(_33004) && IS_ATOM_INT(_33006)) {
        _67a_64878 = _33004 - _33006;
    }
    else {
        _67a_64878 = binary_op(MINUS, _33004, _33006);
    }
    _33004 = NOVALUE;
    _33006 = NOVALUE;
    if (!IS_ATOM_INT(_67a_64878)) {
        _1 = (object)(DBL_PTR(_67a_64878)->dbl);
        DeRefDS(_67a_64878);
        _67a_64878 = _1;
    }

    /** execute.e:1647			if a > 0 and a <= length( val[Code[pc+3]] ) then*/
    _33008 = (_67a_64878 > 0LL);
    if (_33008 == 0) {
        goto L2; // [73] 148
    }
    _33010 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _33011 = (object)*(((s1_ptr)_2)->base + _33010);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!IS_ATOM_INT(_33011)){
        _33012 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33011)->dbl));
    }
    else{
        _33012 = (object)*(((s1_ptr)_2)->base + _33011);
    }
    if (IS_SEQUENCE(_33012)){
            _33013 = SEQ_PTR(_33012)->length;
    }
    else {
        _33013 = 1;
    }
    _33012 = NOVALUE;
    _33014 = (_67a_64878 <= _33013);
    _33013 = NOVALUE;
    if (_33014 == 0)
    {
        DeRef(_33014);
        _33014 = NOVALUE;
        goto L2; // [105] 148
    }
    else{
        DeRef(_33014);
        _33014 = NOVALUE;
    }

    /** execute.e:1648				pc += val[Code[pc+3]][a]*/
    _33015 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _33016 = (object)*(((s1_ptr)_2)->base + _33015);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!IS_ATOM_INT(_33016)){
        _33017 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33016)->dbl));
    }
    else{
        _33017 = (object)*(((s1_ptr)_2)->base + _33016);
    }
    _2 = (object)SEQ_PTR(_33017);
    _33018 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _33017 = NOVALUE;
    if (IS_ATOM_INT(_33018)) {
        _67pc_64877 = _67pc_64877 + _33018;
    }
    else {
        _67pc_64877 = binary_op(PLUS, _67pc_64877, _33018);
    }
    _33018 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_64877)) {
        _1 = (object)(DBL_PTR(_67pc_64877)->dbl);
        DeRefDS(_67pc_64877);
        _67pc_64877 = _1;
    }

    /** execute.e:1649				return*/
    _33015 = NOVALUE;
    _33012 = NOVALUE;
    DeRef(_33008);
    _33008 = NOVALUE;
    _32999 = NOVALUE;
    DeRef(_32998);
    _32998 = NOVALUE;
    _33016 = NOVALUE;
    _33011 = NOVALUE;
    DeRef(_33005);
    _33005 = NOVALUE;
    DeRef(_33010);
    _33010 = NOVALUE;
    _33003 = NOVALUE;
    DeRef(_33002);
    _33002 = NOVALUE;
    return;
L2: 
L1: 

    /** execute.e:1652		pc = Code[pc+4]*/
    _33020 = _67pc_64877 + 4LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64877 = (object)*(((s1_ptr)_2)->base + _33020);
    if (!IS_ATOM_INT(_67pc_64877)){
        _67pc_64877 = (object)DBL_PTR(_67pc_64877)->dbl;
    }

    /** execute.e:1653	end procedure*/
    DeRef(_33015);
    _33015 = NOVALUE;
    _33020 = NOVALUE;
    _33012 = NOVALUE;
    DeRef(_33008);
    _33008 = NOVALUE;
    _32999 = NOVALUE;
    DeRef(_32998);
    _32998 = NOVALUE;
    _33016 = NOVALUE;
    _33011 = NOVALUE;
    DeRef(_33005);
    _33005 = NOVALUE;
    DeRef(_33010);
    _33010 = NOVALUE;
    _33003 = NOVALUE;
    DeRef(_33002);
    _33002 = NOVALUE;
    return;
    ;
}


void _67opSWITCH()
{
    object _33034 = NOVALUE;
    object _33032 = NOVALUE;
    object _33031 = NOVALUE;
    object _33030 = NOVALUE;
    object _33029 = NOVALUE;
    object _33027 = NOVALUE;
    object _33026 = NOVALUE;
    object _33025 = NOVALUE;
    object _33024 = NOVALUE;
    object _33023 = NOVALUE;
    object _33022 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1660		a = find( val[Code[pc+1]], val[Code[pc+2]] )*/
    _33022 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _33023 = (object)*(((s1_ptr)_2)->base + _33022);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!IS_ATOM_INT(_33023)){
        _33024 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33023)->dbl));
    }
    else{
        _33024 = (object)*(((s1_ptr)_2)->base + _33023);
    }
    _33025 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _33026 = (object)*(((s1_ptr)_2)->base + _33025);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!IS_ATOM_INT(_33026)){
        _33027 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33026)->dbl));
    }
    else{
        _33027 = (object)*(((s1_ptr)_2)->base + _33026);
    }
    _67a_64878 = find_from(_33024, _33027, 1LL);
    _33024 = NOVALUE;
    _33027 = NOVALUE;

    /** execute.e:1661		if a then*/
    if (_67a_64878 == 0)
    {
        goto L1; // [48] 88
    }
    else{
    }

    /** execute.e:1662			pc += val[Code[pc+3]][a]*/
    _33029 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _33030 = (object)*(((s1_ptr)_2)->base + _33029);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!IS_ATOM_INT(_33030)){
        _33031 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33030)->dbl));
    }
    else{
        _33031 = (object)*(((s1_ptr)_2)->base + _33030);
    }
    _2 = (object)SEQ_PTR(_33031);
    _33032 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _33031 = NOVALUE;
    if (IS_ATOM_INT(_33032)) {
        _67pc_64877 = _67pc_64877 + _33032;
    }
    else {
        _67pc_64877 = binary_op(PLUS, _67pc_64877, _33032);
    }
    _33032 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_64877)) {
        _1 = (object)(DBL_PTR(_67pc_64877)->dbl);
        DeRefDS(_67pc_64877);
        _67pc_64877 = _1;
    }
    goto L2; // [85] 105
L1: 

    /** execute.e:1664			pc = Code[pc + 4]*/
    _33034 = _67pc_64877 + 4LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64877 = (object)*(((s1_ptr)_2)->base + _33034);
    if (!IS_ATOM_INT(_67pc_64877)){
        _67pc_64877 = (object)DBL_PTR(_67pc_64877)->dbl;
    }
L2: 

    /** execute.e:1666	end procedure*/
    DeRef(_33029);
    _33029 = NOVALUE;
    DeRef(_33022);
    _33022 = NOVALUE;
    DeRef(_33034);
    _33034 = NOVALUE;
    DeRef(_33025);
    _33025 = NOVALUE;
    _33023 = NOVALUE;
    _33030 = NOVALUE;
    _33026 = NOVALUE;
    return;
    ;
}


void _67opSWITCH_RT()
{
    object _values_66925 = NOVALUE;
    object _all_ints_66930 = NOVALUE;
    object _max_66931 = NOVALUE;
    object _min_66933 = NOVALUE;
    object _sym_66938 = NOVALUE;
    object _sign_66940 = NOVALUE;
    object _new_value_66955 = NOVALUE;
    object _jump_66972 = NOVALUE;
    object _switch_table_66977 = NOVALUE;
    object _offset_66985 = NOVALUE;
    object _33086 = NOVALUE;
    object _33085 = NOVALUE;
    object _33084 = NOVALUE;
    object _33083 = NOVALUE;
    object _33082 = NOVALUE;
    object _33079 = NOVALUE;
    object _33078 = NOVALUE;
    object _33077 = NOVALUE;
    object _33076 = NOVALUE;
    object _33075 = NOVALUE;
    object _33073 = NOVALUE;
    object _33072 = NOVALUE;
    object _33071 = NOVALUE;
    object _33070 = NOVALUE;
    object _33069 = NOVALUE;
    object _33066 = NOVALUE;
    object _33065 = NOVALUE;
    object _33064 = NOVALUE;
    object _33063 = NOVALUE;
    object _33062 = NOVALUE;
    object _33060 = NOVALUE;
    object _33059 = NOVALUE;
    object _33058 = NOVALUE;
    object _33057 = NOVALUE;
    object _33056 = NOVALUE;
    object _33052 = NOVALUE;
    object _33050 = NOVALUE;
    object _33049 = NOVALUE;
    object _33048 = NOVALUE;
    object _33047 = NOVALUE;
    object _33046 = NOVALUE;
    object _33044 = NOVALUE;
    object _33043 = NOVALUE;
    object _33039 = NOVALUE;
    object _33037 = NOVALUE;
    object _33036 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1677		sequence values = val[Code[pc+2]]*/
    _33036 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _33037 = (object)*(((s1_ptr)_2)->base + _33036);
    DeRef(_values_66925);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!IS_ATOM_INT(_33037)){
        _values_66925 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33037)->dbl));
    }
    else{
        _values_66925 = (object)*(((s1_ptr)_2)->base + _33037);
    }
    Ref(_values_66925);

    /** execute.e:1678		integer all_ints = 1*/
    _all_ints_66930 = 1LL;

    /** execute.e:1679		integer max = MININT*/
    Ref(_12MININT_20051);
    _max_66931 = _12MININT_20051;
    if (!IS_ATOM_INT(_max_66931)) {
        _1 = (object)(DBL_PTR(_max_66931)->dbl);
        DeRefDS(_max_66931);
        _max_66931 = _1;
    }

    /** execute.e:1680		integer min = MAXINT*/
    Ref(_12MAXINT_20050);
    _min_66933 = _12MAXINT_20050;
    if (!IS_ATOM_INT(_min_66933)) {
        _1 = (object)(DBL_PTR(_min_66933)->dbl);
        DeRefDS(_min_66933);
        _min_66933 = _1;
    }

    /** execute.e:1681		for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_66925)){
            _33039 = SEQ_PTR(_values_66925)->length;
    }
    else {
        _33039 = 1;
    }
    {
        object _i_66936;
        _i_66936 = 1LL;
L1: 
        if (_i_66936 > _33039){
            goto L2; // [51] 209
        }

        /** execute.e:1682			integer sym = values[i]*/
        _2 = (object)SEQ_PTR(_values_66925);
        _sym_66938 = (object)*(((s1_ptr)_2)->base + _i_66936);
        if (!IS_ATOM_INT(_sym_66938))
        _sym_66938 = (object)DBL_PTR(_sym_66938)->dbl;

        /** execute.e:1683			integer sign = 1*/
        _sign_66940 = 1LL;

        /** execute.e:1684			if sym < 0 then*/
        if (_sym_66938 >= 0LL)
        goto L3; // [71] 88

        /** execute.e:1685				sign = -1*/
        _sign_66940 = -1LL;

        /** execute.e:1686				sym = -sym*/
        _sym_66938 = - _sym_66938;
L3: 

        /** execute.e:1688			if equal(val[sym], NOVALUE) then*/
        _2 = (object)SEQ_PTR(_67val_64887);
        _33043 = (object)*(((s1_ptr)_2)->base + _sym_66938);
        if (_33043 == _12NOVALUE_20081)
        _33044 = 1;
        else if (IS_ATOM_INT(_33043) && IS_ATOM_INT(_12NOVALUE_20081))
        _33044 = 0;
        else
        _33044 = (compare(_33043, _12NOVALUE_20081) == 0);
        _33043 = NOVALUE;
        if (_33044 == 0)
        {
            _33044 = NOVALUE;
            goto L4; // [102] 131
        }
        else{
            _33044 = NOVALUE;
        }

        /** execute.e:1689				RTFatal( sprintf( "'%s' has not been assigned a value", {SymTab[sym][S_NAME]} ) )*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _33046 = (object)*(((s1_ptr)_2)->base + _sym_66938);
        _2 = (object)SEQ_PTR(_33046);
        if (!IS_ATOM_INT(_12S_NAME_19864)){
            _33047 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
        }
        else{
            _33047 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
        }
        _33046 = NOVALUE;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_33047);
        ((intptr_t*)_2)[1] = _33047;
        _33048 = MAKE_SEQ(_1);
        _33047 = NOVALUE;
        _33049 = EPrintf(-9999999, _33045, _33048);
        DeRefDS(_33048);
        _33048 = NOVALUE;
        _67RTFatal(_33049);
        _33049 = NOVALUE;
L4: 

        /** execute.e:1691			object new_value = sign * val[sym]*/
        _2 = (object)SEQ_PTR(_67val_64887);
        _33050 = (object)*(((s1_ptr)_2)->base + _sym_66938);
        DeRef(_new_value_66955);
        if (IS_ATOM_INT(_33050)) {
            {
                int128_t p128 = (int128_t)_sign_66940 * (int128_t)_33050;
                if( p128 != (int128_t)(_new_value_66955 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                    _new_value_66955 = NewDouble( (eudouble)p128 );
                }
            }
        }
        else {
            _new_value_66955 = binary_op(MULTIPLY, _sign_66940, _33050);
        }
        _33050 = NOVALUE;

        /** execute.e:1692			values[i] = new_value*/
        Ref(_new_value_66955);
        _2 = (object)SEQ_PTR(_values_66925);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _values_66925 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_66936);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _new_value_66955;
        DeRef(_1);

        /** execute.e:1693			if not integer( new_value ) then*/
        if (IS_ATOM_INT(_new_value_66955))
        _33052 = 1;
        else if (IS_ATOM_DBL(_new_value_66955))
        _33052 = IS_ATOM_INT(DoubleToInt(_new_value_66955));
        else
        _33052 = 0;
        if (_33052 != 0)
        goto L5; // [154] 165
        _33052 = NOVALUE;

        /** execute.e:1694				all_ints = 0*/
        _all_ints_66930 = 0LL;
        goto L6; // [162] 200
L5: 

        /** execute.e:1696			elsif all_ints then*/
        if (_all_ints_66930 == 0)
        {
            goto L7; // [167] 199
        }
        else{
        }

        /** execute.e:1697				if new_value < min then*/
        if (binary_op_a(GREATEREQ, _new_value_66955, _min_66933)){
            goto L8; // [172] 184
        }

        /** execute.e:1698					min = new_value*/
        Ref(_new_value_66955);
        _min_66933 = _new_value_66955;
        if (!IS_ATOM_INT(_min_66933)) {
            _1 = (object)(DBL_PTR(_min_66933)->dbl);
            DeRefDS(_min_66933);
            _min_66933 = _1;
        }
L8: 

        /** execute.e:1701				if new_value > max then*/
        if (binary_op_a(LESSEQ, _new_value_66955, _max_66931)){
            goto L9; // [186] 198
        }

        /** execute.e:1702					max = new_value*/
        Ref(_new_value_66955);
        _max_66931 = _new_value_66955;
        if (!IS_ATOM_INT(_max_66931)) {
            _1 = (object)(DBL_PTR(_max_66931)->dbl);
            DeRefDS(_max_66931);
            _max_66931 = _1;
        }
L9: 
L7: 
L6: 
        DeRef(_new_value_66955);
        _new_value_66955 = NOVALUE;

        /** execute.e:1705		end for*/
        _i_66936 = _i_66936 + 1LL;
        goto L1; // [204] 58
L2: 
        ;
    }

    /** execute.e:1707		if all_ints and max - min < 1024 then*/
    if (_all_ints_66930 == 0) {
        goto LA; // [211] 412
    }
    _33057 = _max_66931 - _min_66933;
    if ((object)((uintptr_t)_33057 +(uintptr_t) HIGH_BITS) >= 0){
        _33057 = NewDouble((eudouble)_33057);
    }
    if (IS_ATOM_INT(_33057)) {
        _33058 = (_33057 < 1024LL);
    }
    else {
        _33058 = (DBL_PTR(_33057)->dbl < (eudouble)1024LL);
    }
    DeRef(_33057);
    _33057 = NOVALUE;
    if (_33058 == 0)
    {
        DeRef(_33058);
        _33058 = NOVALUE;
        goto LA; // [224] 412
    }
    else{
        DeRef(_33058);
        _33058 = NOVALUE;
    }

    /** execute.e:1708			Code[pc] = SWITCH_SPI*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67pc_64877);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 192LL;
    DeRef(_1);

    /** execute.e:1710			sequence jump = val[Code[pc+3]]*/
    _33059 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _33060 = (object)*(((s1_ptr)_2)->base + _33059);
    DeRef(_jump_66972);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!IS_ATOM_INT(_33060)){
        _jump_66972 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33060)->dbl));
    }
    else{
        _jump_66972 = (object)*(((s1_ptr)_2)->base + _33060);
    }
    Ref(_jump_66972);

    /** execute.e:1711			sequence switch_table = repeat( Code[pc+4] - pc, max - min + 1 )*/
    _33062 = _67pc_64877 + 4LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _33063 = (object)*(((s1_ptr)_2)->base + _33062);
    if (IS_ATOM_INT(_33063)) {
        _33064 = _33063 - _67pc_64877;
        if ((object)((uintptr_t)_33064 +(uintptr_t) HIGH_BITS) >= 0){
            _33064 = NewDouble((eudouble)_33064);
        }
    }
    else {
        _33064 = binary_op(MINUS, _33063, _67pc_64877);
    }
    _33063 = NOVALUE;
    _33065 = _max_66931 - _min_66933;
    if ((object)((uintptr_t)_33065 +(uintptr_t) HIGH_BITS) >= 0){
        _33065 = NewDouble((eudouble)_33065);
    }
    if (IS_ATOM_INT(_33065)) {
        _33066 = _33065 + 1;
    }
    else
    _33066 = binary_op(PLUS, 1, _33065);
    DeRef(_33065);
    _33065 = NOVALUE;
    DeRef(_switch_table_66977);
    _switch_table_66977 = Repeat(_33064, _33066);
    DeRef(_33064);
    _33064 = NOVALUE;
    DeRef(_33066);
    _33066 = NOVALUE;

    /** execute.e:1712			integer offset = min - 1*/
    _offset_66985 = _min_66933 - 1LL;

    /** execute.e:1713			for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_66925)){
            _33069 = SEQ_PTR(_values_66925)->length;
    }
    else {
        _33069 = 1;
    }
    {
        object _i_66988;
        _i_66988 = 1LL;
LB: 
        if (_i_66988 > _33069){
            goto LC; // [304] 336
        }

        /** execute.e:1714				switch_table[values[i] - offset] = jump[i]*/
        _2 = (object)SEQ_PTR(_values_66925);
        _33070 = (object)*(((s1_ptr)_2)->base + _i_66988);
        if (IS_ATOM_INT(_33070)) {
            _33071 = _33070 - _offset_66985;
            if ((object)((uintptr_t)_33071 +(uintptr_t) HIGH_BITS) >= 0){
                _33071 = NewDouble((eudouble)_33071);
            }
        }
        else {
            _33071 = binary_op(MINUS, _33070, _offset_66985);
        }
        _33070 = NOVALUE;
        _2 = (object)SEQ_PTR(_jump_66972);
        _33072 = (object)*(((s1_ptr)_2)->base + _i_66988);
        Ref(_33072);
        _2 = (object)SEQ_PTR(_switch_table_66977);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _switch_table_66977 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_33071))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33071)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _33071);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _33072;
        if( _1 != _33072 ){
            DeRef(_1);
        }
        _33072 = NOVALUE;

        /** execute.e:1715			end for*/
        _i_66988 = _i_66988 + 1LL;
        goto LB; // [331] 311
LC: 
        ;
    }

    /** execute.e:1716			Code[pc+2] = offset*/
    _33073 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _33073);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _offset_66985;
    DeRef(_1);

    /** execute.e:1718			val = append( val, switch_table )*/
    RefDS(_switch_table_66977);
    Append(&_67val_64887, _67val_64887, _switch_table_66977);

    /** execute.e:1719			Code[pc+3] = length(val)*/
    _33075 = _67pc_64877 + 3LL;
    if ((object)((uintptr_t)_33075 + (uintptr_t)HIGH_BITS) >= 0){
        _33075 = NewDouble((eudouble)_33075);
    }
    if (IS_SEQUENCE(_67val_64887)){
            _33076 = SEQ_PTR(_67val_64887)->length;
    }
    else {
        _33076 = 1;
    }
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33075))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33075)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33075);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33076;
    if( _1 != _33076 ){
        DeRef(_1);
    }
    _33076 = NOVALUE;

    /** execute.e:1721			SymTab[call_stack[$]][S_CODE] = Code*/
    if (IS_SEQUENCE(_67call_stack_64895)){
            _33077 = SEQ_PTR(_67call_stack_64895)->length;
    }
    else {
        _33077 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_64895);
    _33078 = (object)*(((s1_ptr)_2)->base + _33077);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33078))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33078)->dbl));
    else
    _3 = (object)(_33078 + ((s1_ptr)_2)->base);
    RefDS(_12Code_20315);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_19876))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12Code_20315;
    DeRef(_1);
    _33079 = NOVALUE;

    /** execute.e:1722			opSWITCH_SPI()*/
    _67opSWITCH_SPI();
    DeRef(_jump_66972);
    _jump_66972 = NOVALUE;
    DeRefDS(_switch_table_66977);
    _switch_table_66977 = NOVALUE;
    goto LD; // [409] 482
LA: 

    /** execute.e:1724			Code[pc] = SWITCH*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67pc_64877);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 185LL;
    DeRef(_1);

    /** execute.e:1725			val = append( val, values )*/
    RefDS(_values_66925);
    Append(&_67val_64887, _67val_64887, _values_66925);

    /** execute.e:1726			Code[pc+2] = length(val)*/
    _33082 = _67pc_64877 + 2LL;
    if ((object)((uintptr_t)_33082 + (uintptr_t)HIGH_BITS) >= 0){
        _33082 = NewDouble((eudouble)_33082);
    }
    if (IS_SEQUENCE(_67val_64887)){
            _33083 = SEQ_PTR(_67val_64887)->length;
    }
    else {
        _33083 = 1;
    }
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33082))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33082)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33082);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33083;
    if( _1 != _33083 ){
        DeRef(_1);
    }
    _33083 = NOVALUE;

    /** execute.e:1728			SymTab[call_stack[$]][S_CODE] = Code*/
    if (IS_SEQUENCE(_67call_stack_64895)){
            _33084 = SEQ_PTR(_67call_stack_64895)->length;
    }
    else {
        _33084 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_64895);
    _33085 = (object)*(((s1_ptr)_2)->base + _33084);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33085))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33085)->dbl));
    else
    _3 = (object)(_33085 + ((s1_ptr)_2)->base);
    RefDS(_12Code_20315);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_19876))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12Code_20315;
    DeRef(_1);
    _33086 = NOVALUE;

    /** execute.e:1729			opSWITCH()*/
    _67opSWITCH();
LD: 

    /** execute.e:1732	end procedure*/
    DeRef(_values_66925);
    _33078 = NOVALUE;
    _33085 = NOVALUE;
    DeRef(_33036);
    _33036 = NOVALUE;
    DeRef(_33062);
    _33062 = NOVALUE;
    DeRef(_33075);
    _33075 = NOVALUE;
    _33037 = NOVALUE;
    DeRef(_33073);
    _33073 = NOVALUE;
    DeRef(_33059);
    _33059 = NOVALUE;
    _33060 = NOVALUE;
    DeRef(_33071);
    _33071 = NOVALUE;
    DeRef(_33082);
    _33082 = NOVALUE;
    return;
    ;
}


void _67opCASE()
{
    object _0, _1, _2;
    

    /** execute.e:1736	end procedure*/
    return;
    ;
}


void _67opNOPSWITCH()
{
    object _0, _1, _2;
    

    /** execute.e:1740	end procedure*/
    return;
    ;
}


object _67var_subs(object _x_67026, object _subs_67027)
{
    object _si_67028 = NOVALUE;
    object _33101 = NOVALUE;
    object _33100 = NOVALUE;
    object _33099 = NOVALUE;
    object _33098 = NOVALUE;
    object _33097 = NOVALUE;
    object _33095 = NOVALUE;
    object _33094 = NOVALUE;
    object _33091 = NOVALUE;
    object _33089 = NOVALUE;
    object _33088 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1746		if atom(x) then*/
    _33088 = IS_ATOM(_x_67026);
    if (_33088 == 0)
    {
        _33088 = NOVALUE;
        goto L1; // [8] 17
    }
    else{
        _33088 = NOVALUE;
    }

    /** execute.e:1747			RTFatal("attempt to subscript an atom\n(reading from it)")*/
    RefDS(_32879);
    _67RTFatal(_32879);
L1: 

    /** execute.e:1749		for i = 1 to length(subs) do*/
    if (IS_SEQUENCE(_subs_67027)){
            _33089 = SEQ_PTR(_subs_67027)->length;
    }
    else {
        _33089 = 1;
    }
    {
        object _i_67032;
        _i_67032 = 1LL;
L2: 
        if (_i_67032 > _33089){
            goto L3; // [22] 110
        }

        /** execute.e:1750			si = subs[i]*/
        DeRef(_si_67028);
        _2 = (object)SEQ_PTR(_subs_67027);
        _si_67028 = (object)*(((s1_ptr)_2)->base + _i_67032);
        Ref(_si_67028);

        /** execute.e:1751			if sequence(si) then*/
        _33091 = IS_SEQUENCE(_si_67028);
        if (_33091 == 0)
        {
            _33091 = NOVALUE;
            goto L4; // [40] 49
        }
        else{
            _33091 = NOVALUE;
        }

        /** execute.e:1752				RTFatal("A subscript must be an atom")*/
        RefDS(_33092);
        _67RTFatal(_33092);
L4: 

        /** execute.e:1754			si = floor(si)*/
        _0 = _si_67028;
        if (IS_ATOM_INT(_si_67028))
        _si_67028 = e_floor(_si_67028);
        else
        _si_67028 = unary_op(FLOOR, _si_67028);
        DeRef(_0);

        /** execute.e:1755			if si > length(x) or si < 1 then*/
        if (IS_SEQUENCE(_x_67026)){
                _33094 = SEQ_PTR(_x_67026)->length;
        }
        else {
            _33094 = 1;
        }
        if (IS_ATOM_INT(_si_67028)) {
            _33095 = (_si_67028 > _33094);
        }
        else {
            _33095 = binary_op(GREATER, _si_67028, _33094);
        }
        _33094 = NOVALUE;
        if (IS_ATOM_INT(_33095)) {
            if (_33095 != 0) {
                goto L5; // [63] 76
            }
        }
        else {
            if (DBL_PTR(_33095)->dbl != 0.0) {
                goto L5; // [63] 76
            }
        }
        if (IS_ATOM_INT(_si_67028)) {
            _33097 = (_si_67028 < 1LL);
        }
        else {
            _33097 = binary_op(LESS, _si_67028, 1LL);
        }
        if (_33097 == 0) {
            DeRef(_33097);
            _33097 = NOVALUE;
            goto L6; // [72] 93
        }
        else {
            if (!IS_ATOM_INT(_33097) && DBL_PTR(_33097)->dbl == 0.0){
                DeRef(_33097);
                _33097 = NOVALUE;
                goto L6; // [72] 93
            }
            DeRef(_33097);
            _33097 = NOVALUE;
        }
        DeRef(_33097);
        _33097 = NOVALUE;
L5: 

        /** execute.e:1756				RTFatal(*/
        if (IS_SEQUENCE(_x_67026)){
                _33098 = SEQ_PTR(_x_67026)->length;
        }
        else {
            _33098 = 1;
        }
        Ref(_si_67028);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _si_67028;
        ((intptr_t *)_2)[2] = _33098;
        _33099 = MAKE_SEQ(_1);
        _33098 = NOVALUE;
        _33100 = EPrintf(-9999999, _32887, _33099);
        DeRefDS(_33099);
        _33099 = NOVALUE;
        _67RTFatal(_33100);
        _33100 = NOVALUE;
L6: 

        /** execute.e:1760			x = x[subs[i]]*/
        _2 = (object)SEQ_PTR(_subs_67027);
        _33101 = (object)*(((s1_ptr)_2)->base + _i_67032);
        _0 = _x_67026;
        _2 = (object)SEQ_PTR(_x_67026);
        if (!IS_ATOM_INT(_33101)){
            _x_67026 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33101)->dbl));
        }
        else{
            _x_67026 = (object)*(((s1_ptr)_2)->base + _33101);
        }
        Ref(_x_67026);
        DeRef(_0);

        /** execute.e:1761		end for*/
        _i_67032 = _i_67032 + 1LL;
        goto L2; // [105] 29
L3: 
        ;
    }

    /** execute.e:1762		return x*/
    DeRefDS(_subs_67027);
    DeRef(_si_67028);
    _33101 = NOVALUE;
    DeRef(_33095);
    _33095 = NOVALUE;
    return _x_67026;
    ;
}


void _67opLENGTH()
{
    object _33108 = NOVALUE;
    object _33107 = NOVALUE;
    object _33105 = NOVALUE;
    object _33103 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1767		a = Code[pc+1]*/
    _33103 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33103);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:1768		target = Code[pc+2]*/
    _33105 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33105);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:1769		val[target] = length(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33107 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_SEQUENCE(_33107)){
            _33108 = SEQ_PTR(_33107)->length;
    }
    else {
        _33108 = 1;
    }
    _33107 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33108;
    if( _1 != _33108 ){
        DeRef(_1);
    }
    _33108 = NOVALUE;

    /** execute.e:1770		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:1771	end procedure*/
    _33107 = NOVALUE;
    _33103 = NOVALUE;
    _33105 = NOVALUE;
    return;
    ;
}


void _67opPLENGTH()
{
    object _33121 = NOVALUE;
    object _33120 = NOVALUE;
    object _33119 = NOVALUE;
    object _33117 = NOVALUE;
    object _33116 = NOVALUE;
    object _33114 = NOVALUE;
    object _33112 = NOVALUE;
    object _33110 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1780		a = Code[pc+1]*/
    _33110 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33110);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:1781		target = Code[pc+2]*/
    _33112 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33112);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:1782		lhs_seq_index = val[a][1]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33114 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_33114);
    _67lhs_seq_index_64885 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_67lhs_seq_index_64885)){
        _67lhs_seq_index_64885 = (object)DBL_PTR(_67lhs_seq_index_64885)->dbl;
    }
    _33114 = NOVALUE;

    /** execute.e:1783		lhs_subs = val[a][2..$]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33116 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_SEQUENCE(_33116)){
            _33117 = SEQ_PTR(_33116)->length;
    }
    else {
        _33117 = 1;
    }
    rhs_slice_target = (object_ptr)&_67lhs_subs_64886;
    RHS_Slice(_33116, 2LL, _33117);
    _33116 = NOVALUE;

    /** execute.e:1784		val[target] = length(var_subs(val[lhs_seq_index], lhs_subs))*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33119 = (object)*(((s1_ptr)_2)->base + _67lhs_seq_index_64885);
    Ref(_33119);
    RefDS(_67lhs_subs_64886);
    _33120 = _67var_subs(_33119, _67lhs_subs_64886);
    _33119 = NOVALUE;
    if (IS_SEQUENCE(_33120)){
            _33121 = SEQ_PTR(_33120)->length;
    }
    else {
        _33121 = 1;
    }
    DeRef(_33120);
    _33120 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33121;
    if( _1 != _33121 ){
        DeRef(_1);
    }
    _33121 = NOVALUE;

    /** execute.e:1785		lhs_subs = {}*/
    RefDS(_22024);
    DeRefDS(_67lhs_subs_64886);
    _67lhs_subs_64886 = _22024;

    /** execute.e:1786		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:1787	end procedure*/
    _33120 = NOVALUE;
    _33110 = NOVALUE;
    _33112 = NOVALUE;
    return;
    ;
}


void _67opLHS_SUBS()
{
    object _33131 = NOVALUE;
    object _33130 = NOVALUE;
    object _33129 = NOVALUE;
    object _33127 = NOVALUE;
    object _33125 = NOVALUE;
    object _33123 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1792		a = Code[pc+1] -- base var sequence, or a temp that contains*/
    _33123 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33123);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:1794		b = Code[pc+2] -- subscript*/
    _33125 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33125);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:1795		target = Code[pc+3] -- temp for storing result*/
    _33127 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33127);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:1798		val[target] = append(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33129 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33130 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    Ref(_33130);
    Append(&_33131, _33129, _33130);
    _33129 = NOVALUE;
    _33130 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33131;
    if( _1 != _33131 ){
        DeRef(_1);
    }
    _33131 = NOVALUE;

    /** execute.e:1799		pc += 5*/
    _67pc_64877 = _67pc_64877 + 5LL;

    /** execute.e:1800	end procedure*/
    _33127 = NOVALUE;
    _33123 = NOVALUE;
    _33125 = NOVALUE;
    return;
    ;
}


void _67opLHS_SUBS1()
{
    object _33140 = NOVALUE;
    object _33139 = NOVALUE;
    object _33137 = NOVALUE;
    object _33135 = NOVALUE;
    object _33133 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1804		a = Code[pc+1] -- base var sequence, or a temp that contains*/
    _33133 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33133);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:1806		b = Code[pc+2] -- subscript*/
    _33135 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33135);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:1807		target = Code[pc+3] -- temp for storing result*/
    _33137 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33137);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:1810		val[target] = {a, val[b]}*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33139 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    Ref(_33139);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _67a_64878;
    ((intptr_t *)_2)[2] = _33139;
    _33140 = MAKE_SEQ(_1);
    _33139 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33140;
    if( _1 != _33140 ){
        DeRef(_1);
    }
    _33140 = NOVALUE;

    /** execute.e:1811		pc += 5*/
    _67pc_64877 = _67pc_64877 + 5LL;

    /** execute.e:1812	end procedure*/
    _33133 = NOVALUE;
    _33135 = NOVALUE;
    _33137 = NOVALUE;
    return;
    ;
}


void _67opLHS_SUBS1_COPY()
{
    object _33152 = NOVALUE;
    object _33151 = NOVALUE;
    object _33150 = NOVALUE;
    object _33148 = NOVALUE;
    object _33146 = NOVALUE;
    object _33144 = NOVALUE;
    object _33142 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1819		a = Code[pc+1] -- base var sequence*/
    _33142 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33142);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:1821		b = Code[pc+2] -- subscript*/
    _33144 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33144);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:1823		target = Code[pc+3] -- temp for storing result*/
    _33146 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33146);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:1825		c = Code[pc+4] -- temp to hold base sequence while it's manipulated*/
    _33148 = _67pc_64877 + 4LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64880 = (object)*(((s1_ptr)_2)->base + _33148);
    if (!IS_ATOM_INT(_67c_64880)){
        _67c_64880 = (object)DBL_PTR(_67c_64880)->dbl;
    }

    /** execute.e:1827		val[c] = val[a]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33150 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    Ref(_33150);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67c_64880);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33150;
    if( _1 != _33150 ){
        DeRef(_1);
    }
    _33150 = NOVALUE;

    /** execute.e:1830		val[target] = {c, val[b]}*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33151 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    Ref(_33151);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _67c_64880;
    ((intptr_t *)_2)[2] = _33151;
    _33152 = MAKE_SEQ(_1);
    _33151 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33152;
    if( _1 != _33152 ){
        DeRef(_1);
    }
    _33152 = NOVALUE;

    /** execute.e:1832		pc += 5*/
    _67pc_64877 = _67pc_64877 + 5LL;

    /** execute.e:1833	end procedure*/
    _33144 = NOVALUE;
    _33142 = NOVALUE;
    _33146 = NOVALUE;
    _33148 = NOVALUE;
    return;
    ;
}


void _67lhs_check_subs(object _seq_67126, object _subs_67127)
{
    object _33168 = NOVALUE;
    object _33167 = NOVALUE;
    object _33166 = NOVALUE;
    object _33164 = NOVALUE;
    object _33163 = NOVALUE;
    object _33161 = NOVALUE;
    object _33159 = NOVALUE;
    object _33158 = NOVALUE;
    object _33156 = NOVALUE;
    object _33154 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1837		if atom(seq) then*/
    _33154 = IS_ATOM(_seq_67126);
    if (_33154 == 0)
    {
        _33154 = NOVALUE;
        goto L1; // [6] 15
    }
    else{
        _33154 = NOVALUE;
    }

    /** execute.e:1838			RTFatal("attempt to subscript an atom\n(assigning to it)")*/
    RefDS(_33155);
    _67RTFatal(_33155);
L1: 

    /** execute.e:1840		if sequence(subs) then*/
    _33156 = IS_SEQUENCE(_subs_67127);
    if (_33156 == 0)
    {
        _33156 = NOVALUE;
        goto L2; // [20] 36
    }
    else{
        _33156 = NOVALUE;
    }

    /** execute.e:1841			RTFatal(*/
    if (IS_SEQUENCE(_seq_67126)){
            _33158 = SEQ_PTR(_seq_67126)->length;
    }
    else {
        _33158 = 1;
    }
    _33159 = EPrintf(-9999999, _33157, _33158);
    _33158 = NOVALUE;
    _67RTFatal(_33159);
    _33159 = NOVALUE;
L2: 

    /** execute.e:1846		subs = floor(subs)*/
    _0 = _subs_67127;
    if (IS_ATOM_INT(_subs_67127))
    _subs_67127 = e_floor(_subs_67127);
    else
    _subs_67127 = unary_op(FLOOR, _subs_67127);
    DeRef(_0);

    /** execute.e:1847		if subs < 1 or subs > length(seq) then*/
    if (IS_ATOM_INT(_subs_67127)) {
        _33161 = (_subs_67127 < 1LL);
    }
    else {
        _33161 = binary_op(LESS, _subs_67127, 1LL);
    }
    if (IS_ATOM_INT(_33161)) {
        if (_33161 != 0) {
            goto L3; // [47] 63
        }
    }
    else {
        if (DBL_PTR(_33161)->dbl != 0.0) {
            goto L3; // [47] 63
        }
    }
    if (IS_SEQUENCE(_seq_67126)){
            _33163 = SEQ_PTR(_seq_67126)->length;
    }
    else {
        _33163 = 1;
    }
    if (IS_ATOM_INT(_subs_67127)) {
        _33164 = (_subs_67127 > _33163);
    }
    else {
        _33164 = binary_op(GREATER, _subs_67127, _33163);
    }
    _33163 = NOVALUE;
    if (_33164 == 0) {
        DeRef(_33164);
        _33164 = NOVALUE;
        goto L4; // [59] 80
    }
    else {
        if (!IS_ATOM_INT(_33164) && DBL_PTR(_33164)->dbl == 0.0){
            DeRef(_33164);
            _33164 = NOVALUE;
            goto L4; // [59] 80
        }
        DeRef(_33164);
        _33164 = NOVALUE;
    }
    DeRef(_33164);
    _33164 = NOVALUE;
L3: 

    /** execute.e:1848			RTFatal(*/
    if (IS_SEQUENCE(_seq_67126)){
            _33166 = SEQ_PTR(_seq_67126)->length;
    }
    else {
        _33166 = 1;
    }
    Ref(_subs_67127);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _subs_67127;
    ((intptr_t *)_2)[2] = _33166;
    _33167 = MAKE_SEQ(_1);
    _33166 = NOVALUE;
    _33168 = EPrintf(-9999999, _33165, _33167);
    DeRefDS(_33167);
    _33167 = NOVALUE;
    _67RTFatal(_33168);
    _33168 = NOVALUE;
L4: 

    /** execute.e:1853	end procedure*/
    DeRef(_seq_67126);
    DeRef(_subs_67127);
    DeRef(_33161);
    _33161 = NOVALUE;
    return;
    ;
}


void _67check_slice(object _seq_67148, object _lower_67149, object _upper_67150)
{
    object _len_67151 = NOVALUE;
    object _33199 = NOVALUE;
    object _33197 = NOVALUE;
    object _33196 = NOVALUE;
    object _33195 = NOVALUE;
    object _33194 = NOVALUE;
    object _33192 = NOVALUE;
    object _33191 = NOVALUE;
    object _33190 = NOVALUE;
    object _33186 = NOVALUE;
    object _33184 = NOVALUE;
    object _33183 = NOVALUE;
    object _33174 = NOVALUE;
    object _33169 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1859		if sequence(lower) then*/
    _33169 = IS_SEQUENCE(_lower_67149);
    if (_33169 == 0)
    {
        _33169 = NOVALUE;
        goto L1; // [6] 15
    }
    else{
        _33169 = NOVALUE;
    }

    /** execute.e:1860			RTFatal("slice lower index is not an atom")*/
    RefDS(_33170);
    _67RTFatal(_33170);
L1: 

    /** execute.e:1862		lower = floor(lower)*/
    _0 = _lower_67149;
    if (IS_ATOM_INT(_lower_67149))
    _lower_67149 = e_floor(_lower_67149);
    else
    _lower_67149 = unary_op(FLOOR, _lower_67149);
    DeRef(_0);

    /** execute.e:1863		if lower < 1 then*/
    if (binary_op_a(GREATEREQ, _lower_67149, 1LL)){
        goto L2; // [22] 32
    }

    /** execute.e:1864			RTFatal("slice lower index is less than 1")*/
    RefDS(_33173);
    _67RTFatal(_33173);
L2: 

    /** execute.e:1867		if sequence(upper) then*/
    _33174 = IS_SEQUENCE(_upper_67150);
    if (_33174 == 0)
    {
        _33174 = NOVALUE;
        goto L3; // [37] 46
    }
    else{
        _33174 = NOVALUE;
    }

    /** execute.e:1868			RTFatal("slice upper index is not an atom")*/
    RefDS(_33175);
    _67RTFatal(_33175);
L3: 

    /** execute.e:1870		upper = floor(upper)*/
    _0 = _upper_67150;
    if (IS_ATOM_INT(_upper_67150))
    _upper_67150 = e_floor(_upper_67150);
    else
    _upper_67150 = unary_op(FLOOR, _upper_67150);
    DeRef(_0);

    /** execute.e:1871		if upper > #FFFF_FFFF then*/
    if (binary_op_a(LESSEQ, _upper_67150, 4294967295LL)){
        goto L4; // [53] 63
    }

    /** execute.e:1872			upper = -2147483645*/
    DeRef(_upper_67150);
    _upper_67150 = -2147483645LL;
L4: 

    /** execute.e:1874		if upper < 0 then*/
    if (binary_op_a(GREATEREQ, _upper_67150, 0LL)){
        goto L5; // [65] 79
    }

    /** execute.e:1875			RTFatal(sprintf("slice upper index is less than 0 (%d)", upper ) )*/
    _33183 = EPrintf(-9999999, _33182, _upper_67150);
    _67RTFatal(_33183);
    _33183 = NOVALUE;
L5: 

    /** execute.e:1878		if atom(seq) then*/
    _33184 = IS_ATOM(_seq_67148);
    if (_33184 == 0)
    {
        _33184 = NOVALUE;
        goto L6; // [84] 93
    }
    else{
        _33184 = NOVALUE;
    }

    /** execute.e:1879			RTFatal("attempt to slice an atom")*/
    RefDS(_33185);
    _67RTFatal(_33185);
L6: 

    /** execute.e:1882		len = upper - lower + 1*/
    if (IS_ATOM_INT(_upper_67150) && IS_ATOM_INT(_lower_67149)) {
        _33186 = _upper_67150 - _lower_67149;
        if ((object)((uintptr_t)_33186 +(uintptr_t) HIGH_BITS) >= 0){
            _33186 = NewDouble((eudouble)_33186);
        }
    }
    else {
        _33186 = binary_op(MINUS, _upper_67150, _lower_67149);
    }
    DeRef(_len_67151);
    if (IS_ATOM_INT(_33186)) {
        _len_67151 = _33186 + 1;
        if (_len_67151 > MAXINT){
            _len_67151 = NewDouble((eudouble)_len_67151);
        }
    }
    else
    _len_67151 = binary_op(PLUS, 1, _33186);
    DeRef(_33186);
    _33186 = NOVALUE;

    /** execute.e:1884		if len < 0 then*/
    if (binary_op_a(GREATEREQ, _len_67151, 0LL)){
        goto L7; // [105] 115
    }

    /** execute.e:1885			RTFatal("slice length is less than 0")*/
    RefDS(_33189);
    _67RTFatal(_33189);
L7: 

    /** execute.e:1888		if lower > length(seq) + 1 or (len > 0 and lower > length(seq)) then*/
    if (IS_SEQUENCE(_seq_67148)){
            _33190 = SEQ_PTR(_seq_67148)->length;
    }
    else {
        _33190 = 1;
    }
    _33191 = _33190 + 1;
    _33190 = NOVALUE;
    if (IS_ATOM_INT(_lower_67149)) {
        _33192 = (_lower_67149 > _33191);
    }
    else {
        _33192 = binary_op(GREATER, _lower_67149, _33191);
    }
    _33191 = NOVALUE;
    if (IS_ATOM_INT(_33192)) {
        if (_33192 != 0) {
            goto L8; // [128] 156
        }
    }
    else {
        if (DBL_PTR(_33192)->dbl != 0.0) {
            goto L8; // [128] 156
        }
    }
    if (IS_ATOM_INT(_len_67151)) {
        _33194 = (_len_67151 > 0LL);
    }
    else {
        _33194 = (DBL_PTR(_len_67151)->dbl > (eudouble)0LL);
    }
    if (_33194 == 0) {
        DeRef(_33195);
        _33195 = 0;
        goto L9; // [136] 151
    }
    if (IS_SEQUENCE(_seq_67148)){
            _33196 = SEQ_PTR(_seq_67148)->length;
    }
    else {
        _33196 = 1;
    }
    if (IS_ATOM_INT(_lower_67149)) {
        _33197 = (_lower_67149 > _33196);
    }
    else {
        _33197 = binary_op(GREATER, _lower_67149, _33196);
    }
    _33196 = NOVALUE;
    if (IS_ATOM_INT(_33197))
    _33195 = (_33197 != 0);
    else
    _33195 = DBL_PTR(_33197)->dbl != 0.0;
L9: 
    if (_33195 == 0)
    {
        _33195 = NOVALUE;
        goto LA; // [152] 162
    }
    else{
        _33195 = NOVALUE;
    }
L8: 

    /** execute.e:1889			RTFatal("slice starts past end of sequence")*/
    RefDS(_33198);
    _67RTFatal(_33198);
LA: 

    /** execute.e:1892		if upper > length(seq) then*/
    if (IS_SEQUENCE(_seq_67148)){
            _33199 = SEQ_PTR(_seq_67148)->length;
    }
    else {
        _33199 = 1;
    }
    if (binary_op_a(LESSEQ, _upper_67150, _33199)){
        _33199 = NOVALUE;
        goto LB; // [167] 177
    }
    _33199 = NOVALUE;

    /** execute.e:1893			RTFatal("slice ends past end of sequence")*/
    RefDS(_33201);
    _67RTFatal(_33201);
LB: 

    /** execute.e:1895	end procedure*/
    DeRef(_seq_67148);
    DeRef(_lower_67149);
    DeRef(_upper_67150);
    DeRef(_len_67151);
    DeRef(_33197);
    _33197 = NOVALUE;
    DeRef(_33192);
    _33192 = NOVALUE;
    DeRef(_33194);
    _33194 = NOVALUE;
    return;
    ;
}


void _67lhs_check_slice(object _seq_67196, object _lower_67197, object _upper_67198, object _rhs_67199)
{
    object _len_67200 = NOVALUE;
    object _33209 = NOVALUE;
    object _33208 = NOVALUE;
    object _33207 = NOVALUE;
    object _33206 = NOVALUE;
    object _33204 = NOVALUE;
    object _33203 = NOVALUE;
    object _33202 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1901		check_slice(seq, lower, upper)*/
    Ref(_seq_67196);
    Ref(_lower_67197);
    Ref(_upper_67198);
    _67check_slice(_seq_67196, _lower_67197, _upper_67198);

    /** execute.e:1903		len = floor(upper) - floor(lower) + 1*/
    if (IS_ATOM_INT(_upper_67198))
    _33202 = e_floor(_upper_67198);
    else
    _33202 = unary_op(FLOOR, _upper_67198);
    if (IS_ATOM_INT(_lower_67197))
    _33203 = e_floor(_lower_67197);
    else
    _33203 = unary_op(FLOOR, _lower_67197);
    if (IS_ATOM_INT(_33202) && IS_ATOM_INT(_33203)) {
        _33204 = _33202 - _33203;
        if ((object)((uintptr_t)_33204 +(uintptr_t) HIGH_BITS) >= 0){
            _33204 = NewDouble((eudouble)_33204);
        }
    }
    else {
        _33204 = binary_op(MINUS, _33202, _33203);
    }
    DeRef(_33202);
    _33202 = NOVALUE;
    DeRef(_33203);
    _33203 = NOVALUE;
    DeRef(_len_67200);
    if (IS_ATOM_INT(_33204)) {
        _len_67200 = _33204 + 1;
        if (_len_67200 > MAXINT){
            _len_67200 = NewDouble((eudouble)_len_67200);
        }
    }
    else
    _len_67200 = binary_op(PLUS, 1, _33204);
    DeRef(_33204);
    _33204 = NOVALUE;

    /** execute.e:1905		if sequence(rhs) and length(rhs) != len then*/
    _33206 = IS_SEQUENCE(_rhs_67199);
    if (_33206 == 0) {
        goto L1; // [29] 50
    }
    if (IS_SEQUENCE(_rhs_67199)){
            _33208 = SEQ_PTR(_rhs_67199)->length;
    }
    else {
        _33208 = 1;
    }
    if (IS_ATOM_INT(_len_67200)) {
        _33209 = (_33208 != _len_67200);
    }
    else {
        _33209 = ((eudouble)_33208 != DBL_PTR(_len_67200)->dbl);
    }
    _33208 = NOVALUE;
    if (_33209 == 0)
    {
        DeRef(_33209);
        _33209 = NOVALUE;
        goto L1; // [41] 50
    }
    else{
        DeRef(_33209);
        _33209 = NOVALUE;
    }

    /** execute.e:1906			RTFatal("lengths do not match on assignment to slice")*/
    RefDS(_33210);
    _67RTFatal(_33210);
L1: 

    /** execute.e:1908	end procedure*/
    DeRef(_seq_67196);
    DeRef(_lower_67197);
    DeRef(_upper_67198);
    DeRef(_rhs_67199);
    DeRef(_len_67200);
    return;
    ;
}


object _67var_slice(object _x_67213, object _subs_67214, object _lower_67215, object _upper_67216)
{
    object _33229 = NOVALUE;
    object _33227 = NOVALUE;
    object _33226 = NOVALUE;
    object _33225 = NOVALUE;
    object _33224 = NOVALUE;
    object _33223 = NOVALUE;
    object _33222 = NOVALUE;
    object _33221 = NOVALUE;
    object _33219 = NOVALUE;
    object _33218 = NOVALUE;
    object _33217 = NOVALUE;
    object _33214 = NOVALUE;
    object _33213 = NOVALUE;
    object _33212 = NOVALUE;
    object _33211 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1912		if atom(x) then*/
    _33211 = IS_ATOM(_x_67213);
    if (_33211 == 0)
    {
        _33211 = NOVALUE;
        goto L1; // [8] 17
    }
    else{
        _33211 = NOVALUE;
    }

    /** execute.e:1913			RTFatal("attempt to subscript an atom\n(reading from it)")*/
    RefDS(_32879);
    _67RTFatal(_32879);
L1: 

    /** execute.e:1915		for i = 1 to length(subs) do*/
    if (IS_SEQUENCE(_subs_67214)){
            _33212 = SEQ_PTR(_subs_67214)->length;
    }
    else {
        _33212 = 1;
    }
    {
        object _i_67220;
        _i_67220 = 1LL;
L2: 
        if (_i_67220 > _33212){
            goto L3; // [22] 122
        }

        /** execute.e:1916			if sequence(subs[i]) then*/
        _2 = (object)SEQ_PTR(_subs_67214);
        _33213 = (object)*(((s1_ptr)_2)->base + _i_67220);
        _33214 = IS_SEQUENCE(_33213);
        _33213 = NOVALUE;
        if (_33214 == 0)
        {
            _33214 = NOVALUE;
            goto L4; // [38] 47
        }
        else{
            _33214 = NOVALUE;
        }

        /** execute.e:1917				RTFatal("subscript must be an atom")*/
        RefDS(_33215);
        _67RTFatal(_33215);
L4: 

        /** execute.e:1919			subs = floor(subs)*/
        _0 = _subs_67214;
        _subs_67214 = unary_op(FLOOR, _subs_67214);
        DeRefDS(_0);

        /** execute.e:1920			if subs[i] > length(x) or subs[i] < 1 then*/
        _2 = (object)SEQ_PTR(_subs_67214);
        _33217 = (object)*(((s1_ptr)_2)->base + _i_67220);
        if (IS_SEQUENCE(_x_67213)){
                _33218 = SEQ_PTR(_x_67213)->length;
        }
        else {
            _33218 = 1;
        }
        if (IS_ATOM_INT(_33217)) {
            _33219 = (_33217 > _33218);
        }
        else {
            _33219 = binary_op(GREATER, _33217, _33218);
        }
        _33217 = NOVALUE;
        _33218 = NOVALUE;
        if (IS_ATOM_INT(_33219)) {
            if (_33219 != 0) {
                goto L5; // [67] 84
            }
        }
        else {
            if (DBL_PTR(_33219)->dbl != 0.0) {
                goto L5; // [67] 84
            }
        }
        _2 = (object)SEQ_PTR(_subs_67214);
        _33221 = (object)*(((s1_ptr)_2)->base + _i_67220);
        if (IS_ATOM_INT(_33221)) {
            _33222 = (_33221 < 1LL);
        }
        else {
            _33222 = binary_op(LESS, _33221, 1LL);
        }
        _33221 = NOVALUE;
        if (_33222 == 0) {
            DeRef(_33222);
            _33222 = NOVALUE;
            goto L6; // [80] 105
        }
        else {
            if (!IS_ATOM_INT(_33222) && DBL_PTR(_33222)->dbl == 0.0){
                DeRef(_33222);
                _33222 = NOVALUE;
                goto L6; // [80] 105
            }
            DeRef(_33222);
            _33222 = NOVALUE;
        }
        DeRef(_33222);
        _33222 = NOVALUE;
L5: 

        /** execute.e:1921				RTFatal(*/
        _2 = (object)SEQ_PTR(_subs_67214);
        _33223 = (object)*(((s1_ptr)_2)->base + _i_67220);
        if (IS_SEQUENCE(_x_67213)){
                _33224 = SEQ_PTR(_x_67213)->length;
        }
        else {
            _33224 = 1;
        }
        Ref(_33223);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _33223;
        ((intptr_t *)_2)[2] = _33224;
        _33225 = MAKE_SEQ(_1);
        _33224 = NOVALUE;
        _33223 = NOVALUE;
        _33226 = EPrintf(-9999999, _32887, _33225);
        DeRefDS(_33225);
        _33225 = NOVALUE;
        _67RTFatal(_33226);
        _33226 = NOVALUE;
L6: 

        /** execute.e:1925			x = x[subs[i]]*/
        _2 = (object)SEQ_PTR(_subs_67214);
        _33227 = (object)*(((s1_ptr)_2)->base + _i_67220);
        _0 = _x_67213;
        _2 = (object)SEQ_PTR(_x_67213);
        if (!IS_ATOM_INT(_33227)){
            _x_67213 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33227)->dbl));
        }
        else{
            _x_67213 = (object)*(((s1_ptr)_2)->base + _33227);
        }
        Ref(_x_67213);
        DeRef(_0);

        /** execute.e:1926		end for*/
        _i_67220 = _i_67220 + 1LL;
        goto L2; // [117] 29
L3: 
        ;
    }

    /** execute.e:1927		check_slice(x, lower, upper)*/
    Ref(_x_67213);
    Ref(_lower_67215);
    Ref(_upper_67216);
    _67check_slice(_x_67213, _lower_67215, _upper_67216);

    /** execute.e:1928		return x[lower..upper]*/
    rhs_slice_target = (object_ptr)&_33229;
    RHS_Slice(_x_67213, _lower_67215, _upper_67216);
    DeRef(_x_67213);
    DeRefDS(_subs_67214);
    DeRef(_lower_67215);
    DeRef(_upper_67216);
    _33227 = NOVALUE;
    DeRef(_33219);
    _33219 = NOVALUE;
    return _33229;
    ;
}


object _67assign_subs(object _x_67243, object _subs_67244, object _rhs_val_67245)
{
    object _33240 = NOVALUE;
    object _33239 = NOVALUE;
    object _33238 = NOVALUE;
    object _33237 = NOVALUE;
    object _33236 = NOVALUE;
    object _33235 = NOVALUE;
    object _33234 = NOVALUE;
    object _33233 = NOVALUE;
    object _33231 = NOVALUE;
    object _33230 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1933		lhs_check_subs(x, subs[1])*/
    _2 = (object)SEQ_PTR(_subs_67244);
    _33230 = (object)*(((s1_ptr)_2)->base + 1LL);
    RefDS(_x_67243);
    Ref(_33230);
    _67lhs_check_subs(_x_67243, _33230);
    _33230 = NOVALUE;

    /** execute.e:1934		if length(subs) = 1 then*/
    if (IS_SEQUENCE(_subs_67244)){
            _33231 = SEQ_PTR(_subs_67244)->length;
    }
    else {
        _33231 = 1;
    }
    if (_33231 != 1LL)
    goto L1; // [20] 37

    /** execute.e:1935			x[subs[1]] = rhs_val*/
    _2 = (object)SEQ_PTR(_subs_67244);
    _33233 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_rhs_val_67245);
    _2 = (object)SEQ_PTR(_x_67243);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _x_67243 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33233))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33233)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33233);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _rhs_val_67245;
    DeRef(_1);
    goto L2; // [34] 73
L1: 

    /** execute.e:1937			x[subs[1]] = assign_subs(x[subs[1]], subs[2..$], rhs_val)*/
    _2 = (object)SEQ_PTR(_subs_67244);
    _33234 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_subs_67244);
    _33235 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_x_67243);
    if (!IS_ATOM_INT(_33235)){
        _33236 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33235)->dbl));
    }
    else{
        _33236 = (object)*(((s1_ptr)_2)->base + _33235);
    }
    if (IS_SEQUENCE(_subs_67244)){
            _33237 = SEQ_PTR(_subs_67244)->length;
    }
    else {
        _33237 = 1;
    }
    rhs_slice_target = (object_ptr)&_33238;
    RHS_Slice(_subs_67244, 2LL, _33237);
    Ref(_rhs_val_67245);
    DeRef(_33239);
    _33239 = _rhs_val_67245;
    Ref(_33236);
    _33240 = _67assign_subs(_33236, _33238, _33239);
    _33236 = NOVALUE;
    _33238 = NOVALUE;
    _33239 = NOVALUE;
    _2 = (object)SEQ_PTR(_x_67243);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _x_67243 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33234))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33234)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33234);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33240;
    if( _1 != _33240 ){
        DeRef(_1);
    }
    _33240 = NOVALUE;
L2: 

    /** execute.e:1939		return x*/
    DeRefDS(_subs_67244);
    DeRef(_rhs_val_67245);
    _33235 = NOVALUE;
    _33233 = NOVALUE;
    _33234 = NOVALUE;
    return _x_67243;
    ;
}


object _67assign_slice(object _x_67261, object _subs_67262, object _lower_67263, object _upper_67264, object _rhs_val_67265)
{
    object _33257 = NOVALUE;
    object _33256 = NOVALUE;
    object _33255 = NOVALUE;
    object _33254 = NOVALUE;
    object _33253 = NOVALUE;
    object _33252 = NOVALUE;
    object _33251 = NOVALUE;
    object _33250 = NOVALUE;
    object _33249 = NOVALUE;
    object _33247 = NOVALUE;
    object _33246 = NOVALUE;
    object _33245 = NOVALUE;
    object _33244 = NOVALUE;
    object _33242 = NOVALUE;
    object _33241 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1946		lhs_check_subs(x, subs[1])*/
    _2 = (object)SEQ_PTR(_subs_67262);
    _33241 = (object)*(((s1_ptr)_2)->base + 1LL);
    RefDS(_x_67261);
    Ref(_33241);
    _67lhs_check_subs(_x_67261, _33241);
    _33241 = NOVALUE;

    /** execute.e:1947		if length(subs) = 1 then*/
    if (IS_SEQUENCE(_subs_67262)){
            _33242 = SEQ_PTR(_subs_67262)->length;
    }
    else {
        _33242 = 1;
    }
    if (_33242 != 1LL)
    goto L1; // [20] 59

    /** execute.e:1948			lhs_check_slice(x[subs[1]],lower,upper,rhs_val)*/
    _2 = (object)SEQ_PTR(_subs_67262);
    _33244 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_x_67261);
    if (!IS_ATOM_INT(_33244)){
        _33245 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33244)->dbl));
    }
    else{
        _33245 = (object)*(((s1_ptr)_2)->base + _33244);
    }
    Ref(_33245);
    Ref(_lower_67263);
    Ref(_upper_67264);
    Ref(_rhs_val_67265);
    _67lhs_check_slice(_33245, _lower_67263, _upper_67264, _rhs_val_67265);
    _33245 = NOVALUE;

    /** execute.e:1949			x[subs[1]][lower..upper] = rhs_val*/
    _2 = (object)SEQ_PTR(_subs_67262);
    _33246 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_x_67261);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _x_67261 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33246))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33246)->dbl));
    else
    _3 = (object)(_33246 + ((s1_ptr)_2)->base);
    assign_slice_seq = (s1_ptr *)_3;
    AssignSlice(_lower_67263, _upper_67264, _rhs_val_67265);
    goto L2; // [56] 103
L1: 

    /** execute.e:1951			x[subs[1]] = assign_slice(x[subs[1]], subs[2..$], lower, upper, rhs_val)*/
    _2 = (object)SEQ_PTR(_subs_67262);
    _33249 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_subs_67262);
    _33250 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_x_67261);
    if (!IS_ATOM_INT(_33250)){
        _33251 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33250)->dbl));
    }
    else{
        _33251 = (object)*(((s1_ptr)_2)->base + _33250);
    }
    if (IS_SEQUENCE(_subs_67262)){
            _33252 = SEQ_PTR(_subs_67262)->length;
    }
    else {
        _33252 = 1;
    }
    rhs_slice_target = (object_ptr)&_33253;
    RHS_Slice(_subs_67262, 2LL, _33252);
    Ref(_lower_67263);
    DeRef(_33254);
    _33254 = _lower_67263;
    Ref(_upper_67264);
    DeRef(_33255);
    _33255 = _upper_67264;
    Ref(_rhs_val_67265);
    DeRef(_33256);
    _33256 = _rhs_val_67265;
    Ref(_33251);
    _33257 = _67assign_slice(_33251, _33253, _33254, _33255, _33256);
    _33251 = NOVALUE;
    _33253 = NOVALUE;
    _33254 = NOVALUE;
    _33255 = NOVALUE;
    _33256 = NOVALUE;
    _2 = (object)SEQ_PTR(_x_67261);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _x_67261 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33249))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33249)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33249);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33257;
    if( _1 != _33257 ){
        DeRef(_1);
    }
    _33257 = NOVALUE;
L2: 

    /** execute.e:1953		return x*/
    DeRefDS(_subs_67262);
    DeRef(_lower_67263);
    DeRef(_upper_67264);
    DeRef(_rhs_val_67265);
    DeRef(_33247);
    _33247 = NOVALUE;
    _33249 = NOVALUE;
    _33250 = NOVALUE;
    _33246 = NOVALUE;
    _33244 = NOVALUE;
    return _x_67261;
    ;
}


void _67opASSIGN_SUBS()
{
    object _x_67287 = NOVALUE;
    object _subs_67288 = NOVALUE;
    object _33271 = NOVALUE;
    object _33268 = NOVALUE;
    object _33265 = NOVALUE;
    object _33263 = NOVALUE;
    object _33262 = NOVALUE;
    object _33260 = NOVALUE;
    object _33258 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1960		a = Code[pc+1]  -- the sequence*/
    _33258 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33258);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:1961		b = Code[pc+2]  -- the subscript*/
    _33260 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33260);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:1962		if sequence(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33262 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _33263 = IS_SEQUENCE(_33262);
    _33262 = NOVALUE;
    if (_33263 == 0)
    {
        _33263 = NOVALUE;
        goto L1; // [46] 55
    }
    else{
        _33263 = NOVALUE;
    }

    /** execute.e:1963			RTFatal("subscript must be an atom\n(assigning to subscript of a sequence)")*/
    RefDS(_33264);
    _67RTFatal(_33264);
L1: 

    /** execute.e:1966		c = Code[pc+3]  -- the RHS value*/
    _33265 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64880 = (object)*(((s1_ptr)_2)->base + _33265);
    if (!IS_ATOM_INT(_67c_64880)){
        _67c_64880 = (object)DBL_PTR(_67c_64880)->dbl;
    }

    /** execute.e:1967		x = val[a] -- avoid lingering ref count on val[a]*/
    DeRef(_x_67287);
    _2 = (object)SEQ_PTR(_67val_64887);
    _x_67287 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    Ref(_x_67287);

    /** execute.e:1968		lhs_check_subs(x, val[b])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33268 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    Ref(_x_67287);
    Ref(_33268);
    _67lhs_check_subs(_x_67287, _33268);
    _33268 = NOVALUE;

    /** execute.e:1969		x = val[c]*/
    DeRef(_x_67287);
    _2 = (object)SEQ_PTR(_67val_64887);
    _x_67287 = (object)*(((s1_ptr)_2)->base + _67c_64880);
    Ref(_x_67287);

    /** execute.e:1970		subs = val[b]*/
    DeRef(_subs_67288);
    _2 = (object)SEQ_PTR(_67val_64887);
    _subs_67288 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    Ref(_subs_67288);

    /** execute.e:1971		val[a][subs] = x  -- single LHS subscript*/
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67a_64878 + ((s1_ptr)_2)->base);
    Ref(_x_67287);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_subs_67288))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_subs_67288)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _subs_67288);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _x_67287;
    DeRef(_1);
    _33271 = NOVALUE;

    /** execute.e:1972		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:1973	end procedure*/
    DeRef(_x_67287);
    DeRef(_subs_67288);
    DeRef(_33260);
    _33260 = NOVALUE;
    _33265 = NOVALUE;
    DeRef(_33258);
    _33258 = NOVALUE;
    return;
    ;
}


void _67opPASSIGN_SUBS()
{
    object _33291 = NOVALUE;
    object _33290 = NOVALUE;
    object _33289 = NOVALUE;
    object _33288 = NOVALUE;
    object _33287 = NOVALUE;
    object _33285 = NOVALUE;
    object _33284 = NOVALUE;
    object _33282 = NOVALUE;
    object _33280 = NOVALUE;
    object _33279 = NOVALUE;
    object _33278 = NOVALUE;
    object _33276 = NOVALUE;
    object _33274 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1978		a = Code[pc+1]*/
    _33274 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33274);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:1979		b = Code[pc+2]  -- subscript*/
    _33276 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33276);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:1980		if sequence(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33278 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _33279 = IS_SEQUENCE(_33278);
    _33278 = NOVALUE;
    if (_33279 == 0)
    {
        _33279 = NOVALUE;
        goto L1; // [46] 55
    }
    else{
        _33279 = NOVALUE;
    }

    /** execute.e:1981			RTFatal("subscript must be an atom\n(assigning to subscript of a sequence)")*/
    RefDS(_33264);
    _67RTFatal(_33264);
L1: 

    /** execute.e:1983		c = Code[pc+3]  -- RHS value*/
    _33280 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64880 = (object)*(((s1_ptr)_2)->base + _33280);
    if (!IS_ATOM_INT(_67c_64880)){
        _67c_64880 = (object)DBL_PTR(_67c_64880)->dbl;
    }

    /** execute.e:1986		lhs_seq_index = val[a][1]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33282 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_33282);
    _67lhs_seq_index_64885 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_67lhs_seq_index_64885)){
        _67lhs_seq_index_64885 = (object)DBL_PTR(_67lhs_seq_index_64885)->dbl;
    }
    _33282 = NOVALUE;

    /** execute.e:1987		lhs_subs = val[a][2..$]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33284 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_SEQUENCE(_33284)){
            _33285 = SEQ_PTR(_33284)->length;
    }
    else {
        _33285 = 1;
    }
    rhs_slice_target = (object_ptr)&_67lhs_subs_64886;
    RHS_Slice(_33284, 2LL, _33285);
    _33284 = NOVALUE;

    /** execute.e:1988		val[lhs_seq_index] = assign_subs(val[lhs_seq_index],*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33287 = (object)*(((s1_ptr)_2)->base + _67lhs_seq_index_64885);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33288 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_SEQUENCE(_67lhs_subs_64886) && IS_ATOM(_33288)) {
        Ref(_33288);
        Append(&_33289, _67lhs_subs_64886, _33288);
    }
    else if (IS_ATOM(_67lhs_subs_64886) && IS_SEQUENCE(_33288)) {
    }
    else {
        Concat((object_ptr)&_33289, _67lhs_subs_64886, _33288);
    }
    _33288 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    _33290 = (object)*(((s1_ptr)_2)->base + _67c_64880);
    Ref(_33287);
    Ref(_33290);
    _33291 = _67assign_subs(_33287, _33289, _33290);
    _33287 = NOVALUE;
    _33289 = NOVALUE;
    _33290 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67lhs_seq_index_64885);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33291;
    if( _1 != _33291 ){
        DeRef(_1);
    }
    _33291 = NOVALUE;

    /** execute.e:1991		lhs_subs = {}*/
    RefDS(_22024);
    DeRefDS(_67lhs_subs_64886);
    _67lhs_subs_64886 = _22024;

    /** execute.e:1992		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:1993	end procedure*/
    DeRef(_33274);
    _33274 = NOVALUE;
    _33280 = NOVALUE;
    DeRef(_33276);
    _33276 = NOVALUE;
    return;
    ;
}


void _67opASSIGN_OP_SUBS()
{
    object _x_67336 = NOVALUE;
    object _33302 = NOVALUE;
    object _33301 = NOVALUE;
    object _33300 = NOVALUE;
    object _33297 = NOVALUE;
    object _33295 = NOVALUE;
    object _33293 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1999		a = Code[pc+1]*/
    _33293 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33293);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2000		b = Code[pc+2]*/
    _33295 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33295);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2001		target = Code[pc+3]*/
    _33297 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33297);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2003		lhs_subs = {}*/
    RefDS(_22024);
    DeRef(_67lhs_subs_64886);
    _67lhs_subs_64886 = _22024;

    /** execute.e:2004		x = val[a]*/
    DeRef(_x_67336);
    _2 = (object)SEQ_PTR(_67val_64887);
    _x_67336 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    Ref(_x_67336);

    /** execute.e:2005		val[target] = var_subs(x, lhs_subs & val[b])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33300 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_SEQUENCE(_67lhs_subs_64886) && IS_ATOM(_33300)) {
        Ref(_33300);
        Append(&_33301, _67lhs_subs_64886, _33300);
    }
    else if (IS_ATOM(_67lhs_subs_64886) && IS_SEQUENCE(_33300)) {
    }
    else {
        Concat((object_ptr)&_33301, _67lhs_subs_64886, _33300);
    }
    _33300 = NOVALUE;
    Ref(_x_67336);
    _33302 = _67var_subs(_x_67336, _33301);
    _33301 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33302;
    if( _1 != _33302 ){
        DeRef(_1);
    }
    _33302 = NOVALUE;

    /** execute.e:2006		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:2007	end procedure*/
    DeRef(_x_67336);
    _33297 = NOVALUE;
    _33295 = NOVALUE;
    _33293 = NOVALUE;
    return;
    ;
}


void _67opPASSIGN_OP_SUBS()
{
    object _33321 = NOVALUE;
    object _33320 = NOVALUE;
    object _33319 = NOVALUE;
    object _33318 = NOVALUE;
    object _33317 = NOVALUE;
    object _33316 = NOVALUE;
    object _33315 = NOVALUE;
    object _33313 = NOVALUE;
    object _33312 = NOVALUE;
    object _33310 = NOVALUE;
    object _33308 = NOVALUE;
    object _33306 = NOVALUE;
    object _33304 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2011		a = Code[pc+1]*/
    _33304 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33304);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2012		b = Code[pc+2]*/
    _33306 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33306);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2013		target = Code[pc+3]*/
    _33308 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33308);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2015		lhs_seq_index = val[a][1]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33310 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_33310);
    _67lhs_seq_index_64885 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_67lhs_seq_index_64885)){
        _67lhs_seq_index_64885 = (object)DBL_PTR(_67lhs_seq_index_64885)->dbl;
    }
    _33310 = NOVALUE;

    /** execute.e:2016		lhs_subs = val[a][2..$]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33312 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_SEQUENCE(_33312)){
            _33313 = SEQ_PTR(_33312)->length;
    }
    else {
        _33313 = 1;
    }
    rhs_slice_target = (object_ptr)&_67lhs_subs_64886;
    RHS_Slice(_33312, 2LL, _33313);
    _33312 = NOVALUE;

    /** execute.e:2017		Code[pc+9] = Code[pc+1] -- patch upcoming op*/
    _33315 = _67pc_64877 + 9LL;
    if ((object)((uintptr_t)_33315 + (uintptr_t)HIGH_BITS) >= 0){
        _33315 = NewDouble((eudouble)_33315);
    }
    _33316 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _33317 = (object)*(((s1_ptr)_2)->base + _33316);
    Ref(_33317);
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33315))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33315)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33315);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33317;
    if( _1 != _33317 ){
        DeRef(_1);
    }
    _33317 = NOVALUE;

    /** execute.e:2018		val[target] = var_subs(val[lhs_seq_index], lhs_subs & val[b])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33318 = (object)*(((s1_ptr)_2)->base + _67lhs_seq_index_64885);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33319 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_SEQUENCE(_67lhs_subs_64886) && IS_ATOM(_33319)) {
        Ref(_33319);
        Append(&_33320, _67lhs_subs_64886, _33319);
    }
    else if (IS_ATOM(_67lhs_subs_64886) && IS_SEQUENCE(_33319)) {
    }
    else {
        Concat((object_ptr)&_33320, _67lhs_subs_64886, _33319);
    }
    _33319 = NOVALUE;
    Ref(_33318);
    _33321 = _67var_subs(_33318, _33320);
    _33318 = NOVALUE;
    _33320 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33321;
    if( _1 != _33321 ){
        DeRef(_1);
    }
    _33321 = NOVALUE;

    /** execute.e:2019		lhs_subs = {}*/
    RefDS(_22024);
    DeRefDS(_67lhs_subs_64886);
    _67lhs_subs_64886 = _22024;

    /** execute.e:2020		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:2021	end procedure*/
    _33306 = NOVALUE;
    _33316 = NOVALUE;
    _33308 = NOVALUE;
    _33304 = NOVALUE;
    DeRef(_33315);
    _33315 = NOVALUE;
    return;
    ;
}


void _67opASSIGN_OP_SLICE()
{
    object _x_67379 = NOVALUE;
    object _33346 = NOVALUE;
    object _33345 = NOVALUE;
    object _33344 = NOVALUE;
    object _33342 = NOVALUE;
    object _33340 = NOVALUE;
    object _33339 = NOVALUE;
    object _33338 = NOVALUE;
    object _33337 = NOVALUE;
    object _33336 = NOVALUE;
    object _33335 = NOVALUE;
    object _33334 = NOVALUE;
    object _33333 = NOVALUE;
    object _33331 = NOVALUE;
    object _33330 = NOVALUE;
    object _33329 = NOVALUE;
    object _33328 = NOVALUE;
    object _33326 = NOVALUE;
    object _33323 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2027		a = Code[pc+1]*/
    _33323 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33323);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2028		x = val[a]*/
    DeRef(_x_67379);
    _2 = (object)SEQ_PTR(_67val_64887);
    _x_67379 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    Ref(_x_67379);

    /** execute.e:2029		b = Code[pc+2]*/
    _33326 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33326);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2030		if floor(val[b]) > length(x) or floor(val[b]) < 1 then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33328 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_ATOM_INT(_33328))
    _33329 = e_floor(_33328);
    else
    _33329 = unary_op(FLOOR, _33328);
    _33328 = NOVALUE;
    if (IS_SEQUENCE(_x_67379)){
            _33330 = SEQ_PTR(_x_67379)->length;
    }
    else {
        _33330 = 1;
    }
    if (IS_ATOM_INT(_33329)) {
        _33331 = (_33329 > _33330);
    }
    else {
        _33331 = binary_op(GREATER, _33329, _33330);
    }
    DeRef(_33329);
    _33329 = NOVALUE;
    _33330 = NOVALUE;
    if (IS_ATOM_INT(_33331)) {
        if (_33331 != 0) {
            goto L1; // [63] 87
        }
    }
    else {
        if (DBL_PTR(_33331)->dbl != 0.0) {
            goto L1; // [63] 87
        }
    }
    _2 = (object)SEQ_PTR(_67val_64887);
    _33333 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_ATOM_INT(_33333))
    _33334 = e_floor(_33333);
    else
    _33334 = unary_op(FLOOR, _33333);
    _33333 = NOVALUE;
    if (IS_ATOM_INT(_33334)) {
        _33335 = (_33334 < 1LL);
    }
    else {
        _33335 = binary_op(LESS, _33334, 1LL);
    }
    DeRef(_33334);
    _33334 = NOVALUE;
    if (_33335 == 0) {
        DeRef(_33335);
        _33335 = NOVALUE;
        goto L2; // [83] 112
    }
    else {
        if (!IS_ATOM_INT(_33335) && DBL_PTR(_33335)->dbl == 0.0){
            DeRef(_33335);
            _33335 = NOVALUE;
            goto L2; // [83] 112
        }
        DeRef(_33335);
        _33335 = NOVALUE;
    }
    DeRef(_33335);
    _33335 = NOVALUE;
L1: 

    /** execute.e:2031			RTFatal(*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33336 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_SEQUENCE(_x_67379)){
            _33337 = SEQ_PTR(_x_67379)->length;
    }
    else {
        _33337 = 1;
    }
    Ref(_33336);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _33336;
    ((intptr_t *)_2)[2] = _33337;
    _33338 = MAKE_SEQ(_1);
    _33337 = NOVALUE;
    _33336 = NOVALUE;
    _33339 = EPrintf(-9999999, _32887, _33338);
    DeRefDS(_33338);
    _33338 = NOVALUE;
    _67RTFatal(_33339);
    _33339 = NOVALUE;
L2: 

    /** execute.e:2035		c = Code[pc+3]*/
    _33340 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64880 = (object)*(((s1_ptr)_2)->base + _33340);
    if (!IS_ATOM_INT(_67c_64880)){
        _67c_64880 = (object)DBL_PTR(_67c_64880)->dbl;
    }

    /** execute.e:2036		target = Code[pc+4]*/
    _33342 = _67pc_64877 + 4LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33342);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2037		val[target] = var_slice(x, {}, val[b], val[c])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33344 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33345 = (object)*(((s1_ptr)_2)->base + _67c_64880);
    Ref(_x_67379);
    RefDS(_22024);
    Ref(_33344);
    Ref(_33345);
    _33346 = _67var_slice(_x_67379, _22024, _33344, _33345);
    _33344 = NOVALUE;
    _33345 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33346;
    if( _1 != _33346 ){
        DeRef(_1);
    }
    _33346 = NOVALUE;

    /** execute.e:2038		pc += 5*/
    _67pc_64877 = _67pc_64877 + 5LL;

    /** execute.e:2039	end procedure*/
    DeRef(_x_67379);
    _33340 = NOVALUE;
    DeRef(_33326);
    _33326 = NOVALUE;
    _33342 = NOVALUE;
    DeRef(_33323);
    _33323 = NOVALUE;
    DeRef(_33331);
    _33331 = NOVALUE;
    return;
    ;
}


void _67opPASSIGN_OP_SLICE()
{
    object _x_67412 = NOVALUE;
    object _33366 = NOVALUE;
    object _33365 = NOVALUE;
    object _33364 = NOVALUE;
    object _33363 = NOVALUE;
    object _33362 = NOVALUE;
    object _33361 = NOVALUE;
    object _33360 = NOVALUE;
    object _33358 = NOVALUE;
    object _33355 = NOVALUE;
    object _33353 = NOVALUE;
    object _33351 = NOVALUE;
    object _33348 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2045		a = Code[pc+1]*/
    _33348 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33348);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2046		x = val[a]*/
    DeRef(_x_67412);
    _2 = (object)SEQ_PTR(_67val_64887);
    _x_67412 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    Ref(_x_67412);

    /** execute.e:2047		b = Code[pc+2]*/
    _33351 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33351);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2048		c = Code[pc+3]*/
    _33353 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64880 = (object)*(((s1_ptr)_2)->base + _33353);
    if (!IS_ATOM_INT(_67c_64880)){
        _67c_64880 = (object)DBL_PTR(_67c_64880)->dbl;
    }

    /** execute.e:2049		target = Code[pc+4]*/
    _33355 = _67pc_64877 + 4LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33355);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2050		lhs_seq_index = x[1]*/
    _2 = (object)SEQ_PTR(_x_67412);
    _67lhs_seq_index_64885 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_67lhs_seq_index_64885)){
        _67lhs_seq_index_64885 = (object)DBL_PTR(_67lhs_seq_index_64885)->dbl;
    }

    /** execute.e:2051		lhs_subs = x[2..$]*/
    if (IS_SEQUENCE(_x_67412)){
            _33358 = SEQ_PTR(_x_67412)->length;
    }
    else {
        _33358 = 1;
    }
    rhs_slice_target = (object_ptr)&_67lhs_subs_64886;
    RHS_Slice(_x_67412, 2LL, _33358);

    /** execute.e:2052		Code[pc+10] = Code[pc+1]*/
    _33360 = _67pc_64877 + 10LL;
    if ((object)((uintptr_t)_33360 + (uintptr_t)HIGH_BITS) >= 0){
        _33360 = NewDouble((eudouble)_33360);
    }
    _33361 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _33362 = (object)*(((s1_ptr)_2)->base + _33361);
    Ref(_33362);
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33360))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33360)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33360);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33362;
    if( _1 != _33362 ){
        DeRef(_1);
    }
    _33362 = NOVALUE;

    /** execute.e:2053		val[target] = var_slice(val[lhs_seq_index], lhs_subs, val[b], val[c])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33363 = (object)*(((s1_ptr)_2)->base + _67lhs_seq_index_64885);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33364 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33365 = (object)*(((s1_ptr)_2)->base + _67c_64880);
    Ref(_33363);
    RefDS(_67lhs_subs_64886);
    Ref(_33364);
    Ref(_33365);
    _33366 = _67var_slice(_33363, _67lhs_subs_64886, _33364, _33365);
    _33363 = NOVALUE;
    _33364 = NOVALUE;
    _33365 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33366;
    if( _1 != _33366 ){
        DeRef(_1);
    }
    _33366 = NOVALUE;

    /** execute.e:2054		lhs_subs = {}*/
    RefDS(_22024);
    DeRefDS(_67lhs_subs_64886);
    _67lhs_subs_64886 = _22024;

    /** execute.e:2055		pc += 5*/
    _67pc_64877 = _67pc_64877 + 5LL;

    /** execute.e:2056	end procedure*/
    DeRef(_x_67412);
    _33361 = NOVALUE;
    DeRef(_33360);
    _33360 = NOVALUE;
    _33353 = NOVALUE;
    _33348 = NOVALUE;
    _33355 = NOVALUE;
    _33351 = NOVALUE;
    return;
    ;
}


void _67opASSIGN_SLICE()
{
    object _x_67441 = NOVALUE;
    object _33384 = NOVALUE;
    object _33383 = NOVALUE;
    object _33381 = NOVALUE;
    object _33379 = NOVALUE;
    object _33378 = NOVALUE;
    object _33377 = NOVALUE;
    object _33374 = NOVALUE;
    object _33372 = NOVALUE;
    object _33370 = NOVALUE;
    object _33368 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:2062		a = Code[pc+1]  -- sequence*/
    _33368 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33368);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2063		b = Code[pc+2]  -- 1st index*/
    _33370 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33370);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2064		c = Code[pc+3]  -- 2nd index*/
    _33372 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64880 = (object)*(((s1_ptr)_2)->base + _33372);
    if (!IS_ATOM_INT(_67c_64880)){
        _67c_64880 = (object)DBL_PTR(_67c_64880)->dbl;
    }

    /** execute.e:2065		d = Code[pc+4]  -- rhs value to assign*/
    _33374 = _67pc_64877 + 4LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67d_64881 = (object)*(((s1_ptr)_2)->base + _33374);
    if (!IS_ATOM_INT(_67d_64881)){
        _67d_64881 = (object)DBL_PTR(_67d_64881)->dbl;
    }

    /** execute.e:2067		x = val[a] -- avoid lingering ref count on val[a]*/
    DeRef(_x_67441);
    _2 = (object)SEQ_PTR(_67val_64887);
    _x_67441 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    Ref(_x_67441);

    /** execute.e:2068		lhs_check_slice(x, val[b], val[c], val[d])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33377 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33378 = (object)*(((s1_ptr)_2)->base + _67c_64880);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33379 = (object)*(((s1_ptr)_2)->base + _67d_64881);
    Ref(_x_67441);
    Ref(_33377);
    Ref(_33378);
    Ref(_33379);
    _67lhs_check_slice(_x_67441, _33377, _33378, _33379);
    _33377 = NOVALUE;
    _33378 = NOVALUE;
    _33379 = NOVALUE;

    /** execute.e:2069		x = val[d]*/
    DeRef(_x_67441);
    _2 = (object)SEQ_PTR(_67val_64887);
    _x_67441 = (object)*(((s1_ptr)_2)->base + _67d_64881);
    Ref(_x_67441);

    /** execute.e:2070		val[a][val[b]..val[c]] = x*/
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67a_64878 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33383 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33384 = (object)*(((s1_ptr)_2)->base + _67c_64880);
    assign_slice_seq = (s1_ptr *)_3;
    AssignSlice(_33383, _33384, _x_67441);
    _33383 = NOVALUE;
    _33384 = NOVALUE;

    /** execute.e:2071		pc += 5*/
    _67pc_64877 = _67pc_64877 + 5LL;

    /** execute.e:2072	end procedure*/
    DeRef(_x_67441);
    _33374 = NOVALUE;
    _33381 = NOVALUE;
    _33372 = NOVALUE;
    _33370 = NOVALUE;
    _33368 = NOVALUE;
    return;
    ;
}


void _67opPASSIGN_SLICE()
{
    object _33403 = NOVALUE;
    object _33402 = NOVALUE;
    object _33401 = NOVALUE;
    object _33400 = NOVALUE;
    object _33399 = NOVALUE;
    object _33397 = NOVALUE;
    object _33396 = NOVALUE;
    object _33394 = NOVALUE;
    object _33392 = NOVALUE;
    object _33390 = NOVALUE;
    object _33388 = NOVALUE;
    object _33386 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2076		a = Code[pc+1]  -- sequence*/
    _33386 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33386);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2077		b = Code[pc+2]  -- 1st index*/
    _33388 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33388);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2078		c = Code[pc+3]  -- 2nd index*/
    _33390 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64880 = (object)*(((s1_ptr)_2)->base + _33390);
    if (!IS_ATOM_INT(_67c_64880)){
        _67c_64880 = (object)DBL_PTR(_67c_64880)->dbl;
    }

    /** execute.e:2079		d = Code[pc+4]  -- rhs value to assign*/
    _33392 = _67pc_64877 + 4LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67d_64881 = (object)*(((s1_ptr)_2)->base + _33392);
    if (!IS_ATOM_INT(_67d_64881)){
        _67d_64881 = (object)DBL_PTR(_67d_64881)->dbl;
    }

    /** execute.e:2081		lhs_seq_index = val[a][1]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33394 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_33394);
    _67lhs_seq_index_64885 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_67lhs_seq_index_64885)){
        _67lhs_seq_index_64885 = (object)DBL_PTR(_67lhs_seq_index_64885)->dbl;
    }
    _33394 = NOVALUE;

    /** execute.e:2082		lhs_subs = val[a][2..$]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33396 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_SEQUENCE(_33396)){
            _33397 = SEQ_PTR(_33396)->length;
    }
    else {
        _33397 = 1;
    }
    rhs_slice_target = (object_ptr)&_67lhs_subs_64886;
    RHS_Slice(_33396, 2LL, _33397);
    _33396 = NOVALUE;

    /** execute.e:2083		val[lhs_seq_index] = assign_slice(val[lhs_seq_index],*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33399 = (object)*(((s1_ptr)_2)->base + _67lhs_seq_index_64885);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33400 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33401 = (object)*(((s1_ptr)_2)->base + _67c_64880);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33402 = (object)*(((s1_ptr)_2)->base + _67d_64881);
    Ref(_33399);
    RefDS(_67lhs_subs_64886);
    Ref(_33400);
    Ref(_33401);
    Ref(_33402);
    _33403 = _67assign_slice(_33399, _67lhs_subs_64886, _33400, _33401, _33402);
    _33399 = NOVALUE;
    _33400 = NOVALUE;
    _33401 = NOVALUE;
    _33402 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67lhs_seq_index_64885);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33403;
    if( _1 != _33403 ){
        DeRef(_1);
    }
    _33403 = NOVALUE;

    /** execute.e:2086		lhs_subs = {}*/
    RefDS(_22024);
    DeRefDS(_67lhs_subs_64886);
    _67lhs_subs_64886 = _22024;

    /** execute.e:2087		pc += 5*/
    _67pc_64877 = _67pc_64877 + 5LL;

    /** execute.e:2088	end procedure*/
    _33388 = NOVALUE;
    _33392 = NOVALUE;
    _33386 = NOVALUE;
    _33390 = NOVALUE;
    return;
    ;
}


void _67opRHS_SLICE()
{
    object _x_67491 = NOVALUE;
    object _33418 = NOVALUE;
    object _33417 = NOVALUE;
    object _33416 = NOVALUE;
    object _33415 = NOVALUE;
    object _33414 = NOVALUE;
    object _33411 = NOVALUE;
    object _33409 = NOVALUE;
    object _33407 = NOVALUE;
    object _33405 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2094		a = Code[pc+1]  -- sequence*/
    _33405 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33405);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2095		b = Code[pc+2]  -- 1st index*/
    _33407 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33407);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2096		c = Code[pc+3]  -- 2nd index*/
    _33409 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64880 = (object)*(((s1_ptr)_2)->base + _33409);
    if (!IS_ATOM_INT(_67c_64880)){
        _67c_64880 = (object)DBL_PTR(_67c_64880)->dbl;
    }

    /** execute.e:2097		target = Code[pc+4]*/
    _33411 = _67pc_64877 + 4LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33411);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2098		x = val[a]*/
    DeRef(_x_67491);
    _2 = (object)SEQ_PTR(_67val_64887);
    _x_67491 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    Ref(_x_67491);

    /** execute.e:2099		check_slice(x, val[b], val[c])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33414 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33415 = (object)*(((s1_ptr)_2)->base + _67c_64880);
    Ref(_x_67491);
    Ref(_33414);
    Ref(_33415);
    _67check_slice(_x_67491, _33414, _33415);
    _33414 = NOVALUE;
    _33415 = NOVALUE;

    /** execute.e:2100		val[target] = x[val[b]..val[c]]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33416 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33417 = (object)*(((s1_ptr)_2)->base + _67c_64880);
    rhs_slice_target = (object_ptr)&_33418;
    RHS_Slice(_x_67491, _33416, _33417);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33418;
    if( _1 != _33418 ){
        DeRef(_1);
    }
    _33418 = NOVALUE;

    /** execute.e:2101		pc += 5*/
    _67pc_64877 = _67pc_64877 + 5LL;

    /** execute.e:2102	end procedure*/
    DeRef(_x_67491);
    _33411 = NOVALUE;
    _33417 = NOVALUE;
    _33416 = NOVALUE;
    _33407 = NOVALUE;
    _33405 = NOVALUE;
    _33409 = NOVALUE;
    return;
    ;
}


void _67opTYPE_CHECK()
{
    object _33424 = NOVALUE;
    object _33422 = NOVALUE;
    object _33421 = NOVALUE;
    object _33420 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2107		if val[Code[pc-1]] = 0 then*/
    _33420 = _67pc_64877 - 1LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _33421 = (object)*(((s1_ptr)_2)->base + _33420);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!IS_ATOM_INT(_33421)){
        _33422 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33421)->dbl));
    }
    else{
        _33422 = (object)*(((s1_ptr)_2)->base + _33421);
    }
    if (binary_op_a(NOTEQ, _33422, 0LL)){
        _33422 = NOVALUE;
        goto L1; // [21] 37
    }
    _33422 = NOVALUE;

    /** execute.e:2108			RTFatalType(pc-2)*/
    _33424 = _67pc_64877 - 2LL;
    if ((object)((uintptr_t)_33424 +(uintptr_t) HIGH_BITS) >= 0){
        _33424 = NewDouble((eudouble)_33424);
    }
    _67RTFatalType(_33424);
    _33424 = NOVALUE;
L1: 

    /** execute.e:2110		pc += 1*/
    _67pc_64877 = _67pc_64877 + 1;

    /** execute.e:2111	end procedure*/
    DeRef(_33420);
    _33420 = NOVALUE;
    _33421 = NOVALUE;
    return;
    ;
}


void _67kill_temp(object _sym_67524)
{
    object _33426 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2114		if sym_mode( sym ) = M_TEMP then*/
    _33426 = _53sym_mode(_sym_67524);
    if (binary_op_a(NOTEQ, _33426, 3LL)){
        DeRef(_33426);
        _33426 = NOVALUE;
        goto L1; // [11] 26
    }
    DeRef(_33426);
    _33426 = NOVALUE;

    /** execute.e:2115			val[sym] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _sym_67524);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
L1: 

    /** execute.e:2117	end procedure*/
    return;
    ;
}


void _67opIS_AN_INTEGER()
{
    object _33433 = NOVALUE;
    object _33432 = NOVALUE;
    object _33430 = NOVALUE;
    object _33428 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2120		a = Code[pc+1]*/
    _33428 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33428);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2121		target = Code[pc+2]*/
    _33430 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33430);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2122		val[target] = integer(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33432 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_ATOM_INT(_33432))
    _33433 = 1;
    else if (IS_ATOM_DBL(_33432))
    _33433 = IS_ATOM_INT(DoubleToInt(_33432));
    else
    _33433 = 0;
    _33432 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33433;
    if( _1 != _33433 ){
        DeRef(_1);
    }
    _33433 = NOVALUE;

    /** execute.e:2123		kill_temp( a )*/
    _67kill_temp(_67a_64878);

    /** execute.e:2124		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:2125	end procedure*/
    _33428 = NOVALUE;
    _33430 = NOVALUE;
    return;
    ;
}


void _67opIS_AN_ATOM()
{
    object _33440 = NOVALUE;
    object _33439 = NOVALUE;
    object _33437 = NOVALUE;
    object _33435 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2128		a = Code[pc+1]*/
    _33435 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33435);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2129		target = Code[pc+2]*/
    _33437 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33437);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2130		val[target] = atom(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33439 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _33440 = IS_ATOM(_33439);
    _33439 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33440;
    if( _1 != _33440 ){
        DeRef(_1);
    }
    _33440 = NOVALUE;

    /** execute.e:2131		kill_temp( a )*/
    _67kill_temp(_67a_64878);

    /** execute.e:2132		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:2133	end procedure*/
    _33435 = NOVALUE;
    _33437 = NOVALUE;
    return;
    ;
}


void _67opIS_A_SEQUENCE()
{
    object _33447 = NOVALUE;
    object _33446 = NOVALUE;
    object _33444 = NOVALUE;
    object _33442 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2136		a = Code[pc+1]*/
    _33442 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33442);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2137		target = Code[pc+2]*/
    _33444 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33444);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2138		val[target] = sequence(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33446 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _33447 = IS_SEQUENCE(_33446);
    _33446 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33447;
    if( _1 != _33447 ){
        DeRef(_1);
    }
    _33447 = NOVALUE;

    /** execute.e:2139		kill_temp( a )*/
    _67kill_temp(_67a_64878);

    /** execute.e:2140		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:2141	end procedure*/
    _33444 = NOVALUE;
    _33442 = NOVALUE;
    return;
    ;
}


void _67opIS_AN_OBJECT()
{
    object _33456 = NOVALUE;
    object _33455 = NOVALUE;
    object _33454 = NOVALUE;
    object _33453 = NOVALUE;
    object _33451 = NOVALUE;
    object _33449 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2144		a = Code[pc+1]*/
    _33449 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33449);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2145		target = Code[pc+2]*/
    _33451 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33451);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2146		if equal( val[a], NOVALUE ) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33453 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (_33453 == _12NOVALUE_20081)
    _33454 = 1;
    else if (IS_ATOM_INT(_33453) && IS_ATOM_INT(_12NOVALUE_20081))
    _33454 = 0;
    else
    _33454 = (compare(_33453, _12NOVALUE_20081) == 0);
    _33453 = NOVALUE;
    if (_33454 == 0)
    {
        _33454 = NOVALUE;
        goto L1; // [49] 65
    }
    else{
        _33454 = NOVALUE;
    }

    /** execute.e:2147			val[target] = 0*/
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    goto L2; // [62] 87
L1: 

    /** execute.e:2149			val[target] = object( val[a] )*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33455 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if( NOVALUE == _33455 ){
        _33456 = 0;
    }
    else{
        if (IS_ATOM_INT(_33455))
        _33456 = 1;
        else if (IS_ATOM_DBL(_33455)) {
             if (IS_ATOM_INT(DoubleToInt(_33455))) {
                 _33456 = 1;
                 } else {
                     _33456 = 2;
                } } else if (IS_SEQUENCE(_33455))
                _33456 = 3;
                else
                _33456 = 0;
            }
            _33455 = NOVALUE;
            _2 = (object)SEQ_PTR(_67val_64887);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _67val_64887 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _33456;
            if( _1 != _33456 ){
                DeRef(_1);
            }
            _33456 = NOVALUE;
L2: 

            /** execute.e:2152		kill_temp( a )*/
            _67kill_temp(_67a_64878);

            /** execute.e:2153		pc += 3*/
            _67pc_64877 = _67pc_64877 + 3LL;

            /** execute.e:2154	end procedure*/
            DeRef(_33449);
            _33449 = NOVALUE;
            DeRef(_33451);
            _33451 = NOVALUE;
            return;
    ;
}


void _67opSQRT()
{
    object _33463 = NOVALUE;
    object _33462 = NOVALUE;
    object _33460 = NOVALUE;
    object _33458 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2160		a = Code[pc+1]*/
    _33458 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33458);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2161		target = Code[pc+2]*/
    _33460 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33460);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2162		val[target] = sqrt(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33462 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_ATOM_INT(_33462))
    _33463 = e_sqrt(_33462);
    else
    _33463 = unary_op(SQRT, _33462);
    _33462 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33463;
    if( _1 != _33463 ){
        DeRef(_1);
    }
    _33463 = NOVALUE;

    /** execute.e:2163		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:2164	end procedure*/
    _33458 = NOVALUE;
    _33460 = NOVALUE;
    return;
    ;
}


void _67opSIN()
{
    object _33470 = NOVALUE;
    object _33469 = NOVALUE;
    object _33467 = NOVALUE;
    object _33465 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2167		a = Code[pc+1]*/
    _33465 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33465);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2168		target = Code[pc+2]*/
    _33467 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33467);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2169		val[target] = sin(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33469 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_ATOM_INT(_33469))
    _33470 = e_sin(_33469);
    else
    _33470 = unary_op(SIN, _33469);
    _33469 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33470;
    if( _1 != _33470 ){
        DeRef(_1);
    }
    _33470 = NOVALUE;

    /** execute.e:2170		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:2171	end procedure*/
    _33467 = NOVALUE;
    _33465 = NOVALUE;
    return;
    ;
}


void _67opCOS()
{
    object _33477 = NOVALUE;
    object _33476 = NOVALUE;
    object _33474 = NOVALUE;
    object _33472 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2174		a = Code[pc+1]*/
    _33472 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33472);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2175		target = Code[pc+2]*/
    _33474 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33474);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2176		val[target] = cos(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33476 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_ATOM_INT(_33476))
    _33477 = e_cos(_33476);
    else
    _33477 = unary_op(COS, _33476);
    _33476 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33477;
    if( _1 != _33477 ){
        DeRef(_1);
    }
    _33477 = NOVALUE;

    /** execute.e:2177		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:2178	end procedure*/
    _33472 = NOVALUE;
    _33474 = NOVALUE;
    return;
    ;
}


void _67opTAN()
{
    object _33484 = NOVALUE;
    object _33483 = NOVALUE;
    object _33481 = NOVALUE;
    object _33479 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2181		a = Code[pc+1]*/
    _33479 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33479);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2182		target = Code[pc+2]*/
    _33481 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33481);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2183		val[target] = tan(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33483 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_ATOM_INT(_33483))
    _33484 = e_tan(_33483);
    else
    _33484 = unary_op(TAN, _33483);
    _33483 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33484;
    if( _1 != _33484 ){
        DeRef(_1);
    }
    _33484 = NOVALUE;

    /** execute.e:2184		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:2185	end procedure*/
    _33479 = NOVALUE;
    _33481 = NOVALUE;
    return;
    ;
}


void _67opARCTAN()
{
    object _33491 = NOVALUE;
    object _33490 = NOVALUE;
    object _33488 = NOVALUE;
    object _33486 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2188		a = Code[pc+1]*/
    _33486 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33486);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2189		target = Code[pc+2]*/
    _33488 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33488);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2190		val[target] = arctan(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33490 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_ATOM_INT(_33490))
    _33491 = e_arctan(_33490);
    else
    _33491 = unary_op(ARCTAN, _33490);
    _33490 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33491;
    if( _1 != _33491 ){
        DeRef(_1);
    }
    _33491 = NOVALUE;

    /** execute.e:2191		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:2192	end procedure*/
    _33488 = NOVALUE;
    _33486 = NOVALUE;
    return;
    ;
}


void _67opLOG()
{
    object _33498 = NOVALUE;
    object _33497 = NOVALUE;
    object _33495 = NOVALUE;
    object _33493 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2195		a = Code[pc+1]*/
    _33493 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33493);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2196		target = Code[pc+2]*/
    _33495 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33495);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2197		val[target] = log(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33497 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_ATOM_INT(_33497))
    _33498 = e_log(_33497);
    else
    _33498 = unary_op(LOG, _33497);
    _33497 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33498;
    if( _1 != _33498 ){
        DeRef(_1);
    }
    _33498 = NOVALUE;

    /** execute.e:2198		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:2199	end procedure*/
    _33495 = NOVALUE;
    _33493 = NOVALUE;
    return;
    ;
}


void _67opNOT_BITS()
{
    object _33505 = NOVALUE;
    object _33504 = NOVALUE;
    object _33502 = NOVALUE;
    object _33500 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2202		a = Code[pc+1]*/
    _33500 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33500);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2203		target = Code[pc+2]*/
    _33502 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33502);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2204		val[target] = not_bits(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33504 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_ATOM_INT(_33504))
    _33505 = not_bits(_33504);
    else
    _33505 = unary_op(NOT_BITS, _33504);
    _33504 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33505;
    if( _1 != _33505 ){
        DeRef(_1);
    }
    _33505 = NOVALUE;

    /** execute.e:2205		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:2206	end procedure*/
    _33502 = NOVALUE;
    _33500 = NOVALUE;
    return;
    ;
}


void _67opFLOOR()
{
    object _33512 = NOVALUE;
    object _33511 = NOVALUE;
    object _33509 = NOVALUE;
    object _33507 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2209		a = Code[pc+1]*/
    _33507 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33507);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2210		target = Code[pc+2]*/
    _33509 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33509);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2211		val[target] = floor(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33511 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_ATOM_INT(_33511))
    _33512 = e_floor(_33511);
    else
    _33512 = unary_op(FLOOR, _33511);
    _33511 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33512;
    if( _1 != _33512 ){
        DeRef(_1);
    }
    _33512 = NOVALUE;

    /** execute.e:2212		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:2213	end procedure*/
    _33509 = NOVALUE;
    _33507 = NOVALUE;
    return;
    ;
}


void _67opNOT_IFW()
{
    object _33519 = NOVALUE;
    object _33516 = NOVALUE;
    object _33514 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2216		a = Code[pc+1]*/
    _33514 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33514);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2217		if val[a] = 0 then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33516 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (binary_op_a(NOTEQ, _33516, 0LL)){
        _33516 = NOVALUE;
        goto L1; // [27] 42
    }
    _33516 = NOVALUE;

    /** execute.e:2218			pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;
    goto L2; // [39] 59
L1: 

    /** execute.e:2220			pc = Code[pc+2]*/
    _33519 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64877 = (object)*(((s1_ptr)_2)->base + _33519);
    if (!IS_ATOM_INT(_67pc_64877)){
        _67pc_64877 = (object)DBL_PTR(_67pc_64877)->dbl;
    }
L2: 

    /** execute.e:2222	end procedure*/
    DeRef(_33514);
    _33514 = NOVALUE;
    DeRef(_33519);
    _33519 = NOVALUE;
    return;
    ;
}


void _67opNOT()
{
    object _33526 = NOVALUE;
    object _33525 = NOVALUE;
    object _33523 = NOVALUE;
    object _33521 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2225		a = Code[pc+1]*/
    _33521 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33521);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2226		target = Code[pc+2]*/
    _33523 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33523);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2227		val[target] = not val[a]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33525 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_ATOM_INT(_33525)) {
        _33526 = (_33525 == 0);
    }
    else {
        _33526 = unary_op(NOT, _33525);
    }
    _33525 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33526;
    if( _1 != _33526 ){
        DeRef(_1);
    }
    _33526 = NOVALUE;

    /** execute.e:2228		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:2229	end procedure*/
    _33523 = NOVALUE;
    _33521 = NOVALUE;
    return;
    ;
}


void _67opUMINUS()
{
    object _33533 = NOVALUE;
    object _33532 = NOVALUE;
    object _33530 = NOVALUE;
    object _33528 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2232		a = Code[pc+1]*/
    _33528 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33528);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2233		target = Code[pc+2]*/
    _33530 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33530);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2234		val[target] = -val[a]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33532 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_ATOM_INT(_33532)) {
        if ((uintptr_t)_33532 == (uintptr_t)HIGH_BITS){
            _33533 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _33533 = - _33532;
        }
    }
    else {
        _33533 = unary_op(UMINUS, _33532);
    }
    _33532 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33533;
    if( _1 != _33533 ){
        DeRef(_1);
    }
    _33533 = NOVALUE;

    /** execute.e:2235		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:2236	end procedure*/
    _33530 = NOVALUE;
    _33528 = NOVALUE;
    return;
    ;
}


void _67opRAND()
{
    object _33540 = NOVALUE;
    object _33539 = NOVALUE;
    object _33537 = NOVALUE;
    object _33535 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2239		a = Code[pc+1]*/
    _33535 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33535);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2240		target = Code[pc+2]*/
    _33537 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33537);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2241		val[target] = rand(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33539 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_ATOM_INT(_33539)) {
        _33540 = good_rand() % ((uint32_t)_33539) + 1;
    }
    else {
        _33540 = unary_op(RAND, _33539);
    }
    _33539 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33540;
    if( _1 != _33540 ){
        DeRef(_1);
    }
    _33540 = NOVALUE;

    /** execute.e:2242		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:2243	end procedure*/
    _33535 = NOVALUE;
    _33537 = NOVALUE;
    return;
    ;
}


void _67opDIV2()
{
    object _33547 = NOVALUE;
    object _33546 = NOVALUE;
    object _33544 = NOVALUE;
    object _33542 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2247		a = Code[pc+1]*/
    _33542 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33542);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2249		target = Code[pc+3]*/
    _33544 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33544);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2250		val[target] = val[a] / 2*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33546 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_ATOM_INT(_33546)) {
        if (_33546 & 1) {
            _33547 = NewDouble((_33546 >> 1) + 0.5);
        }
        else
        _33547 = _33546 >> 1;
    }
    else {
        _33547 = binary_op(DIVIDE, _33546, 2);
    }
    _33546 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33547;
    if( _1 != _33547 ){
        DeRef(_1);
    }
    _33547 = NOVALUE;

    /** execute.e:2251		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:2252	end procedure*/
    _33544 = NOVALUE;
    _33542 = NOVALUE;
    return;
    ;
}


void _67opFLOOR_DIV2()
{
    object _33554 = NOVALUE;
    object _33553 = NOVALUE;
    object _33551 = NOVALUE;
    object _33549 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2255		a = Code[pc+1]*/
    _33549 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33549);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2257		target = Code[pc+3]*/
    _33551 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33551);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2258		val[target] = floor(val[a] / 2)*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33553 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_ATOM_INT(_33553)) {
        _33554 = _33553 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _33553, 2);
        _33554 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    _33553 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33554;
    if( _1 != _33554 ){
        DeRef(_1);
    }
    _33554 = NOVALUE;

    /** execute.e:2259		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:2260	end procedure*/
    _33551 = NOVALUE;
    _33549 = NOVALUE;
    return;
    ;
}


void _67opGREATER_IFW()
{
    object _33564 = NOVALUE;
    object _33561 = NOVALUE;
    object _33560 = NOVALUE;
    object _33558 = NOVALUE;
    object _33556 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2265		a = Code[pc+1]*/
    _33556 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33556);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2266		b = Code[pc+2]*/
    _33558 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33558);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2267		if val[a] > val[b] then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33560 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33561 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (binary_op_a(LESSEQ, _33560, _33561)){
        _33560 = NOVALUE;
        _33561 = NOVALUE;
        goto L1; // [51] 66
    }
    _33560 = NOVALUE;
    _33561 = NOVALUE;

    /** execute.e:2268			pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;
    goto L2; // [63] 83
L1: 

    /** execute.e:2270			pc = Code[pc+3]*/
    _33564 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64877 = (object)*(((s1_ptr)_2)->base + _33564);
    if (!IS_ATOM_INT(_67pc_64877)){
        _67pc_64877 = (object)DBL_PTR(_67pc_64877)->dbl;
    }
L2: 

    /** execute.e:2272	end procedure*/
    DeRef(_33558);
    _33558 = NOVALUE;
    DeRef(_33556);
    _33556 = NOVALUE;
    DeRef(_33564);
    _33564 = NOVALUE;
    return;
    ;
}


void _67opNOTEQ_IFW()
{
    object _33574 = NOVALUE;
    object _33571 = NOVALUE;
    object _33570 = NOVALUE;
    object _33568 = NOVALUE;
    object _33566 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2275		a = Code[pc+1]*/
    _33566 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33566);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2276		b = Code[pc+2]*/
    _33568 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33568);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2277		if val[a] != val[b] then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33570 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33571 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (binary_op_a(EQUALS, _33570, _33571)){
        _33570 = NOVALUE;
        _33571 = NOVALUE;
        goto L1; // [51] 66
    }
    _33570 = NOVALUE;
    _33571 = NOVALUE;

    /** execute.e:2278			pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;
    goto L2; // [63] 83
L1: 

    /** execute.e:2280			pc = Code[pc+3]*/
    _33574 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64877 = (object)*(((s1_ptr)_2)->base + _33574);
    if (!IS_ATOM_INT(_67pc_64877)){
        _67pc_64877 = (object)DBL_PTR(_67pc_64877)->dbl;
    }
L2: 

    /** execute.e:2282	end procedure*/
    DeRef(_33574);
    _33574 = NOVALUE;
    DeRef(_33568);
    _33568 = NOVALUE;
    DeRef(_33566);
    _33566 = NOVALUE;
    return;
    ;
}


void _67opLESSEQ_IFW()
{
    object _33584 = NOVALUE;
    object _33581 = NOVALUE;
    object _33580 = NOVALUE;
    object _33578 = NOVALUE;
    object _33576 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2285		a = Code[pc+1]*/
    _33576 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33576);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2286		b = Code[pc+2]*/
    _33578 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33578);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2287		if val[a] <= val[b] then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33580 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33581 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (binary_op_a(GREATER, _33580, _33581)){
        _33580 = NOVALUE;
        _33581 = NOVALUE;
        goto L1; // [51] 66
    }
    _33580 = NOVALUE;
    _33581 = NOVALUE;

    /** execute.e:2288			pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;
    goto L2; // [63] 83
L1: 

    /** execute.e:2290			pc = Code[pc+3]*/
    _33584 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64877 = (object)*(((s1_ptr)_2)->base + _33584);
    if (!IS_ATOM_INT(_67pc_64877)){
        _67pc_64877 = (object)DBL_PTR(_67pc_64877)->dbl;
    }
L2: 

    /** execute.e:2292	end procedure*/
    DeRef(_33576);
    _33576 = NOVALUE;
    DeRef(_33578);
    _33578 = NOVALUE;
    DeRef(_33584);
    _33584 = NOVALUE;
    return;
    ;
}


void _67opGREATEREQ_IFW()
{
    object _33594 = NOVALUE;
    object _33591 = NOVALUE;
    object _33590 = NOVALUE;
    object _33588 = NOVALUE;
    object _33586 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2295		a = Code[pc+1]*/
    _33586 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33586);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2296		b = Code[pc+2]*/
    _33588 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33588);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2297		if val[a] >= val[b] then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33590 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33591 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (binary_op_a(LESS, _33590, _33591)){
        _33590 = NOVALUE;
        _33591 = NOVALUE;
        goto L1; // [51] 66
    }
    _33590 = NOVALUE;
    _33591 = NOVALUE;

    /** execute.e:2298			pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;
    goto L2; // [63] 83
L1: 

    /** execute.e:2300			pc = Code[pc+3]*/
    _33594 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64877 = (object)*(((s1_ptr)_2)->base + _33594);
    if (!IS_ATOM_INT(_67pc_64877)){
        _67pc_64877 = (object)DBL_PTR(_67pc_64877)->dbl;
    }
L2: 

    /** execute.e:2302	end procedure*/
    DeRef(_33586);
    _33586 = NOVALUE;
    DeRef(_33588);
    _33588 = NOVALUE;
    DeRef(_33594);
    _33594 = NOVALUE;
    return;
    ;
}


void _67opEQUALS_IFW()
{
    object _33610 = NOVALUE;
    object _33607 = NOVALUE;
    object _33606 = NOVALUE;
    object _33604 = NOVALUE;
    object _33603 = NOVALUE;
    object _33601 = NOVALUE;
    object _33600 = NOVALUE;
    object _33598 = NOVALUE;
    object _33596 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2305		a = Code[pc+1]*/
    _33596 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33596);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2306		b = Code[pc+2]*/
    _33598 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33598);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2308		if sequence( val[a] ) or sequence( val[b] ) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33600 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _33601 = IS_SEQUENCE(_33600);
    _33600 = NOVALUE;
    if (_33601 != 0) {
        goto L1; // [46] 66
    }
    _2 = (object)SEQ_PTR(_67val_64887);
    _33603 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _33604 = IS_SEQUENCE(_33603);
    _33603 = NOVALUE;
    if (_33604 == 0)
    {
        _33604 = NOVALUE;
        goto L2; // [62] 72
    }
    else{
        _33604 = NOVALUE;
    }
L1: 

    /** execute.e:2309			RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33605);
    _67RTFatal(_33605);
L2: 

    /** execute.e:2311		if val[a] = val[b] then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33606 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33607 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (binary_op_a(NOTEQ, _33606, _33607)){
        _33606 = NOVALUE;
        _33607 = NOVALUE;
        goto L3; // [90] 105
    }
    _33606 = NOVALUE;
    _33607 = NOVALUE;

    /** execute.e:2312			pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;
    goto L4; // [102] 122
L3: 

    /** execute.e:2314			pc = Code[pc+3]*/
    _33610 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64877 = (object)*(((s1_ptr)_2)->base + _33610);
    if (!IS_ATOM_INT(_67pc_64877)){
        _67pc_64877 = (object)DBL_PTR(_67pc_64877)->dbl;
    }
L4: 

    /** execute.e:2316	end procedure*/
    DeRef(_33610);
    _33610 = NOVALUE;
    DeRef(_33596);
    _33596 = NOVALUE;
    DeRef(_33598);
    _33598 = NOVALUE;
    return;
    ;
}


void _67opLESS_IFW()
{
    object _33620 = NOVALUE;
    object _33617 = NOVALUE;
    object _33616 = NOVALUE;
    object _33614 = NOVALUE;
    object _33612 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2319		a = Code[pc+1]*/
    _33612 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33612);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2320		b = Code[pc+2]*/
    _33614 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33614);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2321		if val[a] < val[b] then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33616 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33617 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (binary_op_a(GREATEREQ, _33616, _33617)){
        _33616 = NOVALUE;
        _33617 = NOVALUE;
        goto L1; // [51] 66
    }
    _33616 = NOVALUE;
    _33617 = NOVALUE;

    /** execute.e:2322			pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;
    goto L2; // [63] 83
L1: 

    /** execute.e:2324			pc = Code[pc+3]*/
    _33620 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64877 = (object)*(((s1_ptr)_2)->base + _33620);
    if (!IS_ATOM_INT(_67pc_64877)){
        _67pc_64877 = (object)DBL_PTR(_67pc_64877)->dbl;
    }
L2: 

    /** execute.e:2326	end procedure*/
    DeRef(_33620);
    _33620 = NOVALUE;
    DeRef(_33612);
    _33612 = NOVALUE;
    DeRef(_33614);
    _33614 = NOVALUE;
    return;
    ;
}


void _67opMULTIPLY()
{
    object _33630 = NOVALUE;
    object _33629 = NOVALUE;
    object _33628 = NOVALUE;
    object _33626 = NOVALUE;
    object _33624 = NOVALUE;
    object _33622 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2331		a = Code[pc+1]*/
    _33622 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33622);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2332		b = Code[pc+2]*/
    _33624 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33624);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2333		target = Code[pc+3]*/
    _33626 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33626);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2334		val[target] = val[a] * val[b]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33628 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33629 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_ATOM_INT(_33628) && IS_ATOM_INT(_33629)) {
        {
            int128_t p128 = (int128_t)_33628 * (int128_t)_33629;
            if( p128 != (int128_t)(_33630 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _33630 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _33630 = binary_op(MULTIPLY, _33628, _33629);
    }
    _33628 = NOVALUE;
    _33629 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33630;
    if( _1 != _33630 ){
        DeRef(_1);
    }
    _33630 = NOVALUE;

    /** execute.e:2335		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:2336	end procedure*/
    _33626 = NOVALUE;
    _33624 = NOVALUE;
    _33622 = NOVALUE;
    return;
    ;
}


void _67opPLUS()
{
    object _33640 = NOVALUE;
    object _33639 = NOVALUE;
    object _33638 = NOVALUE;
    object _33636 = NOVALUE;
    object _33634 = NOVALUE;
    object _33632 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2340		a = Code[pc+1]*/
    _33632 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33632);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2341		b = Code[pc+2]*/
    _33634 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33634);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2342		target = Code[pc+3]*/
    _33636 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33636);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2343		val[target] = val[a] + val[b]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33638 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33639 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_ATOM_INT(_33638) && IS_ATOM_INT(_33639)) {
        _33640 = _33638 + _33639;
        if ((object)((uintptr_t)_33640 + (uintptr_t)HIGH_BITS) >= 0){
            _33640 = NewDouble((eudouble)_33640);
        }
    }
    else {
        _33640 = binary_op(PLUS, _33638, _33639);
    }
    _33638 = NOVALUE;
    _33639 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33640;
    if( _1 != _33640 ){
        DeRef(_1);
    }
    _33640 = NOVALUE;

    /** execute.e:2344		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:2345	end procedure*/
    _33632 = NOVALUE;
    _33636 = NOVALUE;
    _33634 = NOVALUE;
    return;
    ;
}


void _67opMINUS()
{
    object _33650 = NOVALUE;
    object _33649 = NOVALUE;
    object _33648 = NOVALUE;
    object _33646 = NOVALUE;
    object _33644 = NOVALUE;
    object _33642 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2349		a = Code[pc+1]*/
    _33642 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33642);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2350		b = Code[pc+2]*/
    _33644 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33644);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2351		target = Code[pc+3]*/
    _33646 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33646);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2352		val[target] = val[a] - val[b]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33648 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33649 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_ATOM_INT(_33648) && IS_ATOM_INT(_33649)) {
        _33650 = _33648 - _33649;
        if ((object)((uintptr_t)_33650 +(uintptr_t) HIGH_BITS) >= 0){
            _33650 = NewDouble((eudouble)_33650);
        }
    }
    else {
        _33650 = binary_op(MINUS, _33648, _33649);
    }
    _33648 = NOVALUE;
    _33649 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33650;
    if( _1 != _33650 ){
        DeRef(_1);
    }
    _33650 = NOVALUE;

    /** execute.e:2353		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:2354	end procedure*/
    _33642 = NOVALUE;
    _33644 = NOVALUE;
    _33646 = NOVALUE;
    return;
    ;
}


void _67opOR()
{
    object _33660 = NOVALUE;
    object _33659 = NOVALUE;
    object _33658 = NOVALUE;
    object _33656 = NOVALUE;
    object _33654 = NOVALUE;
    object _33652 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2357		a = Code[pc+1]*/
    _33652 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33652);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2358		b = Code[pc+2]*/
    _33654 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33654);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2359		target = Code[pc+3]*/
    _33656 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33656);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2360		val[target] = val[a] or val[b]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33658 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33659 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_ATOM_INT(_33658) && IS_ATOM_INT(_33659)) {
        _33660 = (_33658 != 0 || _33659 != 0);
    }
    else {
        _33660 = binary_op(OR, _33658, _33659);
    }
    _33658 = NOVALUE;
    _33659 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33660;
    if( _1 != _33660 ){
        DeRef(_1);
    }
    _33660 = NOVALUE;

    /** execute.e:2361		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:2362	end procedure*/
    _33656 = NOVALUE;
    _33654 = NOVALUE;
    _33652 = NOVALUE;
    return;
    ;
}


void _67opXOR()
{
    object _33670 = NOVALUE;
    object _33669 = NOVALUE;
    object _33668 = NOVALUE;
    object _33666 = NOVALUE;
    object _33664 = NOVALUE;
    object _33662 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2365		a = Code[pc+1]*/
    _33662 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33662);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2366		b = Code[pc+2]*/
    _33664 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33664);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2367		target = Code[pc+3]*/
    _33666 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33666);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2368		val[target] = val[a] xor val[b]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33668 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33669 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_ATOM_INT(_33668) && IS_ATOM_INT(_33669)) {
        _33670 = ((_33668 != 0) != (_33669 != 0));
    }
    else {
        _33670 = binary_op(XOR, _33668, _33669);
    }
    _33668 = NOVALUE;
    _33669 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33670;
    if( _1 != _33670 ){
        DeRef(_1);
    }
    _33670 = NOVALUE;

    /** execute.e:2369		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:2370	end procedure*/
    _33664 = NOVALUE;
    _33662 = NOVALUE;
    _33666 = NOVALUE;
    return;
    ;
}


void _67opAND()
{
    object _33680 = NOVALUE;
    object _33679 = NOVALUE;
    object _33678 = NOVALUE;
    object _33676 = NOVALUE;
    object _33674 = NOVALUE;
    object _33672 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2373		a = Code[pc+1]*/
    _33672 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33672);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2374		b = Code[pc+2]*/
    _33674 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33674);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2375		target = Code[pc+3]*/
    _33676 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33676);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2376		val[target] = val[a] and val[b]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33678 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33679 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_ATOM_INT(_33678) && IS_ATOM_INT(_33679)) {
        _33680 = (_33678 != 0 && _33679 != 0);
    }
    else {
        _33680 = binary_op(AND, _33678, _33679);
    }
    _33678 = NOVALUE;
    _33679 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33680;
    if( _1 != _33680 ){
        DeRef(_1);
    }
    _33680 = NOVALUE;

    /** execute.e:2377		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:2378	end procedure*/
    _33676 = NOVALUE;
    _33674 = NOVALUE;
    _33672 = NOVALUE;
    return;
    ;
}


void _67opDIVIDE()
{
    object _33693 = NOVALUE;
    object _33692 = NOVALUE;
    object _33691 = NOVALUE;
    object _33689 = NOVALUE;
    object _33688 = NOVALUE;
    object _33686 = NOVALUE;
    object _33684 = NOVALUE;
    object _33682 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2381		a = Code[pc+1]*/
    _33682 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33682);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2382		b = Code[pc+2]*/
    _33684 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33684);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2383		target = Code[pc+3]*/
    _33686 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33686);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2384		if equal(val[b], 0) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33688 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (_33688 == 0LL)
    _33689 = 1;
    else if (IS_ATOM_INT(_33688) && IS_ATOM_INT(0LL))
    _33689 = 0;
    else
    _33689 = (compare(_33688, 0LL) == 0);
    _33688 = NOVALUE;
    if (_33689 == 0)
    {
        _33689 = NOVALUE;
        goto L1; // [63] 72
    }
    else{
        _33689 = NOVALUE;
    }

    /** execute.e:2385			RTFatal("attempt to divide by 0")*/
    RefDS(_33690);
    _67RTFatal(_33690);
L1: 

    /** execute.e:2387		val[target] = val[a] / val[b]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33691 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33692 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_ATOM_INT(_33691) && IS_ATOM_INT(_33692)) {
        _33693 = (_33691 % _33692) ? NewDouble((eudouble)_33691 / _33692) : (_33691 / _33692);
    }
    else {
        _33693 = binary_op(DIVIDE, _33691, _33692);
    }
    _33691 = NOVALUE;
    _33692 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33693;
    if( _1 != _33693 ){
        DeRef(_1);
    }
    _33693 = NOVALUE;

    /** execute.e:2388		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:2389	end procedure*/
    DeRef(_33686);
    _33686 = NOVALUE;
    DeRef(_33682);
    _33682 = NOVALUE;
    DeRef(_33684);
    _33684 = NOVALUE;
    return;
    ;
}


void _67opREMAINDER()
{
    object _33706 = NOVALUE;
    object _33705 = NOVALUE;
    object _33704 = NOVALUE;
    object _33702 = NOVALUE;
    object _33701 = NOVALUE;
    object _33699 = NOVALUE;
    object _33697 = NOVALUE;
    object _33695 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2392		a = Code[pc+1]*/
    _33695 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33695);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2393		b = Code[pc+2]*/
    _33697 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33697);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2394		target = Code[pc+3]*/
    _33699 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33699);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2395		if equal(val[b], 0) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33701 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (_33701 == 0LL)
    _33702 = 1;
    else if (IS_ATOM_INT(_33701) && IS_ATOM_INT(0LL))
    _33702 = 0;
    else
    _33702 = (compare(_33701, 0LL) == 0);
    _33701 = NOVALUE;
    if (_33702 == 0)
    {
        _33702 = NOVALUE;
        goto L1; // [63] 72
    }
    else{
        _33702 = NOVALUE;
    }

    /** execute.e:2396			RTFatal("Can't get remainder of a number divided by 0")*/
    RefDS(_33703);
    _67RTFatal(_33703);
L1: 

    /** execute.e:2398		val[target] = remainder(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33704 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33705 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_ATOM_INT(_33704) && IS_ATOM_INT(_33705)) {
        _33706 = (_33704 % _33705);
    }
    else {
        _33706 = binary_op(REMAINDER, _33704, _33705);
    }
    _33704 = NOVALUE;
    _33705 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33706;
    if( _1 != _33706 ){
        DeRef(_1);
    }
    _33706 = NOVALUE;

    /** execute.e:2399		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:2400	end procedure*/
    DeRef(_33695);
    _33695 = NOVALUE;
    DeRef(_33699);
    _33699 = NOVALUE;
    DeRef(_33697);
    _33697 = NOVALUE;
    return;
    ;
}


void _67opFLOOR_DIV()
{
    object _33718 = NOVALUE;
    object _33717 = NOVALUE;
    object _33716 = NOVALUE;
    object _33715 = NOVALUE;
    object _33714 = NOVALUE;
    object _33712 = NOVALUE;
    object _33710 = NOVALUE;
    object _33708 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2403		a = Code[pc+1]*/
    _33708 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33708);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2404		b = Code[pc+2]*/
    _33710 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33710);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2405		target = Code[pc+3]*/
    _33712 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33712);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2406		if equal(val[b], 0) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33714 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (_33714 == 0LL)
    _33715 = 1;
    else if (IS_ATOM_INT(_33714) && IS_ATOM_INT(0LL))
    _33715 = 0;
    else
    _33715 = (compare(_33714, 0LL) == 0);
    _33714 = NOVALUE;
    if (_33715 == 0)
    {
        _33715 = NOVALUE;
        goto L1; // [63] 72
    }
    else{
        _33715 = NOVALUE;
    }

    /** execute.e:2407			RTFatal("attempt to divide by 0")*/
    RefDS(_33690);
    _67RTFatal(_33690);
L1: 

    /** execute.e:2409		val[target] = floor(val[a] / val[b])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33716 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33717 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_ATOM_INT(_33716) && IS_ATOM_INT(_33717)) {
        if (_33717 > 0 && _33716 >= 0) {
            _33718 = _33716 / _33717;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_33716 / (eudouble)_33717);
            if (_33716 != MININT)
            _33718 = (object)temp_dbl;
            else
            _33718 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _33716, _33717);
        _33718 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _33716 = NOVALUE;
    _33717 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33718;
    if( _1 != _33718 ){
        DeRef(_1);
    }
    _33718 = NOVALUE;

    /** execute.e:2410		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:2411	end procedure*/
    DeRef(_33712);
    _33712 = NOVALUE;
    DeRef(_33708);
    _33708 = NOVALUE;
    DeRef(_33710);
    _33710 = NOVALUE;
    return;
    ;
}


void _67opAND_BITS()
{
    object _33728 = NOVALUE;
    object _33727 = NOVALUE;
    object _33726 = NOVALUE;
    object _33724 = NOVALUE;
    object _33722 = NOVALUE;
    object _33720 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2414		a = Code[pc+1]*/
    _33720 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33720);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2415		b = Code[pc+2]*/
    _33722 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33722);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2416		target = Code[pc+3]*/
    _33724 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33724);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2417		val[target] = and_bits(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33726 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33727 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_ATOM_INT(_33726) && IS_ATOM_INT(_33727)) {
        {uintptr_t tu;
             tu = (uintptr_t)_33726 & (uintptr_t)_33727;
             _33728 = MAKE_UINT(tu);
        }
    }
    else {
        _33728 = binary_op(AND_BITS, _33726, _33727);
    }
    _33726 = NOVALUE;
    _33727 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33728;
    if( _1 != _33728 ){
        DeRef(_1);
    }
    _33728 = NOVALUE;

    /** execute.e:2418		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:2419	end procedure*/
    _33724 = NOVALUE;
    _33722 = NOVALUE;
    _33720 = NOVALUE;
    return;
    ;
}


void _67opOR_BITS()
{
    object _33738 = NOVALUE;
    object _33737 = NOVALUE;
    object _33736 = NOVALUE;
    object _33734 = NOVALUE;
    object _33732 = NOVALUE;
    object _33730 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2422		a = Code[pc+1]*/
    _33730 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33730);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2423		b = Code[pc+2]*/
    _33732 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33732);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2424		target = Code[pc+3]*/
    _33734 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33734);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2425		val[target] = or_bits(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33736 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33737 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_ATOM_INT(_33736) && IS_ATOM_INT(_33737)) {
        {uintptr_t tu;
             tu = (uintptr_t)_33736 | (uintptr_t)_33737;
             _33738 = MAKE_UINT(tu);
        }
    }
    else {
        _33738 = binary_op(OR_BITS, _33736, _33737);
    }
    _33736 = NOVALUE;
    _33737 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33738;
    if( _1 != _33738 ){
        DeRef(_1);
    }
    _33738 = NOVALUE;

    /** execute.e:2426		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:2427	end procedure*/
    _33732 = NOVALUE;
    _33734 = NOVALUE;
    _33730 = NOVALUE;
    return;
    ;
}


void _67opXOR_BITS()
{
    object _33748 = NOVALUE;
    object _33747 = NOVALUE;
    object _33746 = NOVALUE;
    object _33744 = NOVALUE;
    object _33742 = NOVALUE;
    object _33740 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2430		a = Code[pc+1]*/
    _33740 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33740);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2431		b = Code[pc+2]*/
    _33742 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33742);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2432		target = Code[pc+3]*/
    _33744 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33744);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2433		val[target] = xor_bits(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33746 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33747 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_ATOM_INT(_33746) && IS_ATOM_INT(_33747)) {
        {uintptr_t tu;
             tu = (uintptr_t)_33746 ^ (uintptr_t)_33747;
             _33748 = MAKE_UINT(tu);
        }
    }
    else {
        _33748 = binary_op(XOR_BITS, _33746, _33747);
    }
    _33746 = NOVALUE;
    _33747 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33748;
    if( _1 != _33748 ){
        DeRef(_1);
    }
    _33748 = NOVALUE;

    /** execute.e:2434		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:2435	end procedure*/
    _33742 = NOVALUE;
    _33740 = NOVALUE;
    _33744 = NOVALUE;
    return;
    ;
}


void _67opPOWER()
{
    object _33758 = NOVALUE;
    object _33757 = NOVALUE;
    object _33756 = NOVALUE;
    object _33754 = NOVALUE;
    object _33752 = NOVALUE;
    object _33750 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2438		a = Code[pc+1]*/
    _33750 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33750);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2439		b = Code[pc+2]*/
    _33752 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33752);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2440		target = Code[pc+3]*/
    _33754 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33754);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2441		val[target] = power(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33756 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33757 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_ATOM_INT(_33756) && IS_ATOM_INT(_33757)) {
        _33758 = power(_33756, _33757);
    }
    else {
        _33758 = binary_op(POWER, _33756, _33757);
    }
    _33756 = NOVALUE;
    _33757 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33758;
    if( _1 != _33758 ){
        DeRef(_1);
    }
    _33758 = NOVALUE;

    /** execute.e:2442		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:2443	end procedure*/
    _33752 = NOVALUE;
    _33754 = NOVALUE;
    _33750 = NOVALUE;
    return;
    ;
}


void _67opLESS()
{
    object _33768 = NOVALUE;
    object _33767 = NOVALUE;
    object _33766 = NOVALUE;
    object _33764 = NOVALUE;
    object _33762 = NOVALUE;
    object _33760 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2446		a = Code[pc+1]*/
    _33760 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33760);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2447		b = Code[pc+2]*/
    _33762 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33762);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2448		target = Code[pc+3]*/
    _33764 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33764);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2449		val[target] = val[a] < val[b]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33766 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33767 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_ATOM_INT(_33766) && IS_ATOM_INT(_33767)) {
        _33768 = (_33766 < _33767);
    }
    else {
        _33768 = binary_op(LESS, _33766, _33767);
    }
    _33766 = NOVALUE;
    _33767 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33768;
    if( _1 != _33768 ){
        DeRef(_1);
    }
    _33768 = NOVALUE;

    /** execute.e:2450		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:2451	end procedure*/
    _33764 = NOVALUE;
    _33762 = NOVALUE;
    _33760 = NOVALUE;
    return;
    ;
}


void _67opGREATER()
{
    object _33778 = NOVALUE;
    object _33777 = NOVALUE;
    object _33776 = NOVALUE;
    object _33774 = NOVALUE;
    object _33772 = NOVALUE;
    object _33770 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2454		a = Code[pc+1]*/
    _33770 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33770);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2455		b = Code[pc+2]*/
    _33772 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33772);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2456		target = Code[pc+3]*/
    _33774 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33774);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2457		val[target] = val[a] > val[b]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33776 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33777 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_ATOM_INT(_33776) && IS_ATOM_INT(_33777)) {
        _33778 = (_33776 > _33777);
    }
    else {
        _33778 = binary_op(GREATER, _33776, _33777);
    }
    _33776 = NOVALUE;
    _33777 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33778;
    if( _1 != _33778 ){
        DeRef(_1);
    }
    _33778 = NOVALUE;

    /** execute.e:2458		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:2459	end procedure*/
    _33772 = NOVALUE;
    _33774 = NOVALUE;
    _33770 = NOVALUE;
    return;
    ;
}


void _67opEQUALS()
{
    object _33788 = NOVALUE;
    object _33787 = NOVALUE;
    object _33786 = NOVALUE;
    object _33784 = NOVALUE;
    object _33782 = NOVALUE;
    object _33780 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2462		a = Code[pc+1]*/
    _33780 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33780);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2463		b = Code[pc+2]*/
    _33782 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33782);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2464		target = Code[pc+3]*/
    _33784 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33784);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2465		val[target] = val[a] = val[b]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33786 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33787 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_ATOM_INT(_33786) && IS_ATOM_INT(_33787)) {
        _33788 = (_33786 == _33787);
    }
    else {
        _33788 = binary_op(EQUALS, _33786, _33787);
    }
    _33786 = NOVALUE;
    _33787 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33788;
    if( _1 != _33788 ){
        DeRef(_1);
    }
    _33788 = NOVALUE;

    /** execute.e:2466		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:2467	end procedure*/
    _33784 = NOVALUE;
    _33780 = NOVALUE;
    _33782 = NOVALUE;
    return;
    ;
}


void _67opNOTEQ()
{
    object _33798 = NOVALUE;
    object _33797 = NOVALUE;
    object _33796 = NOVALUE;
    object _33794 = NOVALUE;
    object _33792 = NOVALUE;
    object _33790 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2470		a = Code[pc+1]*/
    _33790 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33790);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2471		b = Code[pc+2]*/
    _33792 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33792);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2472		target = Code[pc+3]*/
    _33794 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33794);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2473		val[target] = val[a] != val[b]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33796 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33797 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_ATOM_INT(_33796) && IS_ATOM_INT(_33797)) {
        _33798 = (_33796 != _33797);
    }
    else {
        _33798 = binary_op(NOTEQ, _33796, _33797);
    }
    _33796 = NOVALUE;
    _33797 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33798;
    if( _1 != _33798 ){
        DeRef(_1);
    }
    _33798 = NOVALUE;

    /** execute.e:2474		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:2475	end procedure*/
    _33794 = NOVALUE;
    _33792 = NOVALUE;
    _33790 = NOVALUE;
    return;
    ;
}


void _67opLESSEQ()
{
    object _33808 = NOVALUE;
    object _33807 = NOVALUE;
    object _33806 = NOVALUE;
    object _33804 = NOVALUE;
    object _33802 = NOVALUE;
    object _33800 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2478		a = Code[pc+1]*/
    _33800 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33800);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2479		b = Code[pc+2]*/
    _33802 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33802);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2480		target = Code[pc+3]*/
    _33804 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33804);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2481		val[target] = val[a] <= val[b]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33806 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33807 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_ATOM_INT(_33806) && IS_ATOM_INT(_33807)) {
        _33808 = (_33806 <= _33807);
    }
    else {
        _33808 = binary_op(LESSEQ, _33806, _33807);
    }
    _33806 = NOVALUE;
    _33807 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33808;
    if( _1 != _33808 ){
        DeRef(_1);
    }
    _33808 = NOVALUE;

    /** execute.e:2482		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:2483	end procedure*/
    _33800 = NOVALUE;
    _33804 = NOVALUE;
    _33802 = NOVALUE;
    return;
    ;
}


void _67opGREATEREQ()
{
    object _33818 = NOVALUE;
    object _33817 = NOVALUE;
    object _33816 = NOVALUE;
    object _33814 = NOVALUE;
    object _33812 = NOVALUE;
    object _33810 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2486		a = Code[pc+1]*/
    _33810 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33810);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2487		b = Code[pc+2]*/
    _33812 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33812);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2488		target = Code[pc+3]*/
    _33814 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _33814);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2489		val[target] = val[a] >= val[b]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33816 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33817 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_ATOM_INT(_33816) && IS_ATOM_INT(_33817)) {
        _33818 = (_33816 >= _33817);
    }
    else {
        _33818 = binary_op(GREATEREQ, _33816, _33817);
    }
    _33816 = NOVALUE;
    _33817 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33818;
    if( _1 != _33818 ){
        DeRef(_1);
    }
    _33818 = NOVALUE;

    /** execute.e:2490		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:2491	end procedure*/
    _33814 = NOVALUE;
    _33810 = NOVALUE;
    _33812 = NOVALUE;
    return;
    ;
}


void _67opSC1_AND()
{
    object _33828 = NOVALUE;
    object _33826 = NOVALUE;
    object _33825 = NOVALUE;
    object _33824 = NOVALUE;
    object _33822 = NOVALUE;
    object _33820 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2496		a = Code[pc+1]*/
    _33820 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33820);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2497		b = Code[pc+2]*/
    _33822 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33822);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2498		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33824 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _33825 = IS_ATOM(_33824);
    _33824 = NOVALUE;
    if (_33825 == 0)
    {
        _33825 = NOVALUE;
        goto L1; // [46] 98
    }
    else{
        _33825 = NOVALUE;
    }

    /** execute.e:2499			if val[a] = 0 then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33826 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (binary_op_a(NOTEQ, _33826, 0LL)){
        _33826 = NOVALUE;
        goto L2; // [59] 104
    }
    _33826 = NOVALUE;

    /** execute.e:2500				val[b] = 0*/
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67b_64879);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** execute.e:2501				pc = Code[pc+3]*/
    _33828 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64877 = (object)*(((s1_ptr)_2)->base + _33828);
    if (!IS_ATOM_INT(_67pc_64877)){
        _67pc_64877 = (object)DBL_PTR(_67pc_64877)->dbl;
    }

    /** execute.e:2502				return*/
    _33822 = NOVALUE;
    _33828 = NOVALUE;
    _33820 = NOVALUE;
    return;
    goto L2; // [95] 104
L1: 

    /** execute.e:2505			RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33605);
    _67RTFatal(_33605);
L2: 

    /** execute.e:2507		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:2508	end procedure*/
    DeRef(_33822);
    _33822 = NOVALUE;
    DeRef(_33828);
    _33828 = NOVALUE;
    DeRef(_33820);
    _33820 = NOVALUE;
    return;
    ;
}


void _67opSC1_AND_IF()
{
    object _33839 = NOVALUE;
    object _33837 = NOVALUE;
    object _33836 = NOVALUE;
    object _33835 = NOVALUE;
    object _33833 = NOVALUE;
    object _33831 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2512		a = Code[pc+1]*/
    _33831 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33831);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2513		b = Code[pc+2]*/
    _33833 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33833);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2514		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33835 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _33836 = IS_ATOM(_33835);
    _33835 = NOVALUE;
    if (_33836 == 0)
    {
        _33836 = NOVALUE;
        goto L1; // [46] 88
    }
    else{
        _33836 = NOVALUE;
    }

    /** execute.e:2515			if val[a] = 0 then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33837 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (binary_op_a(NOTEQ, _33837, 0LL)){
        _33837 = NOVALUE;
        goto L2; // [59] 94
    }
    _33837 = NOVALUE;

    /** execute.e:2516				pc = Code[pc+3]*/
    _33839 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64877 = (object)*(((s1_ptr)_2)->base + _33839);
    if (!IS_ATOM_INT(_67pc_64877)){
        _67pc_64877 = (object)DBL_PTR(_67pc_64877)->dbl;
    }

    /** execute.e:2517				return*/
    _33833 = NOVALUE;
    _33831 = NOVALUE;
    _33839 = NOVALUE;
    return;
    goto L2; // [85] 94
L1: 

    /** execute.e:2520			RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33605);
    _67RTFatal(_33605);
L2: 

    /** execute.e:2522		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:2523	end procedure*/
    DeRef(_33833);
    _33833 = NOVALUE;
    DeRef(_33831);
    _33831 = NOVALUE;
    DeRef(_33839);
    _33839 = NOVALUE;
    return;
    ;
}


void _67opSC1_OR()
{
    object _33850 = NOVALUE;
    object _33848 = NOVALUE;
    object _33847 = NOVALUE;
    object _33846 = NOVALUE;
    object _33844 = NOVALUE;
    object _33842 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2526		a = Code[pc+1]*/
    _33842 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33842);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2527		b = Code[pc+2]*/
    _33844 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33844);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2528		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33846 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _33847 = IS_ATOM(_33846);
    _33846 = NOVALUE;
    if (_33847 == 0)
    {
        _33847 = NOVALUE;
        goto L1; // [46] 98
    }
    else{
        _33847 = NOVALUE;
    }

    /** execute.e:2529			if val[a] != 0 then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33848 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (binary_op_a(EQUALS, _33848, 0LL)){
        _33848 = NOVALUE;
        goto L2; // [59] 104
    }
    _33848 = NOVALUE;

    /** execute.e:2530				val[b] = 1*/
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67b_64879);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);

    /** execute.e:2531				pc = Code[pc+3]*/
    _33850 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64877 = (object)*(((s1_ptr)_2)->base + _33850);
    if (!IS_ATOM_INT(_67pc_64877)){
        _67pc_64877 = (object)DBL_PTR(_67pc_64877)->dbl;
    }

    /** execute.e:2532				return*/
    _33850 = NOVALUE;
    _33844 = NOVALUE;
    _33842 = NOVALUE;
    return;
    goto L2; // [95] 104
L1: 

    /** execute.e:2535			RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33605);
    _67RTFatal(_33605);
L2: 

    /** execute.e:2537		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:2538	end procedure*/
    DeRef(_33850);
    _33850 = NOVALUE;
    DeRef(_33844);
    _33844 = NOVALUE;
    DeRef(_33842);
    _33842 = NOVALUE;
    return;
    ;
}


void _67opSC1_OR_IF()
{
    object _33861 = NOVALUE;
    object _33859 = NOVALUE;
    object _33858 = NOVALUE;
    object _33857 = NOVALUE;
    object _33855 = NOVALUE;
    object _33853 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2542		a = Code[pc+1]*/
    _33853 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33853);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2543		b = Code[pc+2]*/
    _33855 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33855);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2544		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33857 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _33858 = IS_ATOM(_33857);
    _33857 = NOVALUE;
    if (_33858 == 0)
    {
        _33858 = NOVALUE;
        goto L1; // [46] 98
    }
    else{
        _33858 = NOVALUE;
    }

    /** execute.e:2545			if val[a] != 0 then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33859 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (binary_op_a(EQUALS, _33859, 0LL)){
        _33859 = NOVALUE;
        goto L2; // [59] 104
    }
    _33859 = NOVALUE;

    /** execute.e:2546				val[b] = 1*/
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67b_64879);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);

    /** execute.e:2547				pc = Code[pc+3]*/
    _33861 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64877 = (object)*(((s1_ptr)_2)->base + _33861);
    if (!IS_ATOM_INT(_67pc_64877)){
        _67pc_64877 = (object)DBL_PTR(_67pc_64877)->dbl;
    }

    /** execute.e:2548				return*/
    _33855 = NOVALUE;
    _33853 = NOVALUE;
    _33861 = NOVALUE;
    return;
    goto L2; // [95] 104
L1: 

    /** execute.e:2551			RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33605);
    _67RTFatal(_33605);
L2: 

    /** execute.e:2553		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:2554	end procedure*/
    DeRef(_33855);
    _33855 = NOVALUE;
    DeRef(_33853);
    _33853 = NOVALUE;
    DeRef(_33861);
    _33861 = NOVALUE;
    return;
    ;
}


void _67opSC2_OR()
{
    object _33870 = NOVALUE;
    object _33869 = NOVALUE;
    object _33868 = NOVALUE;
    object _33866 = NOVALUE;
    object _33864 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2559		a = Code[pc+1]*/
    _33864 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _33864);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2560		b = Code[pc+2]*/
    _33866 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _33866);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2561		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33868 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _33869 = IS_ATOM(_33868);
    _33868 = NOVALUE;
    if (_33869 == 0)
    {
        _33869 = NOVALUE;
        goto L1; // [46] 70
    }
    else{
        _33869 = NOVALUE;
    }

    /** execute.e:2562			val[b] = val[a]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33870 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    Ref(_33870);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67b_64879);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33870;
    if( _1 != _33870 ){
        DeRef(_1);
    }
    _33870 = NOVALUE;
    goto L2; // [67] 76
L1: 

    /** execute.e:2564			RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33605);
    _67RTFatal(_33605);
L2: 

    /** execute.e:2566		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:2567	end procedure*/
    DeRef(_33866);
    _33866 = NOVALUE;
    DeRef(_33864);
    _33864 = NOVALUE;
    return;
    ;
}


void _67opFOR()
{
    object _increment_68233 = NOVALUE;
    object _limit_68234 = NOVALUE;
    object _initial_68235 = NOVALUE;
    object _loopvar_68236 = NOVALUE;
    object _jump_68237 = NOVALUE;
    object _33900 = NOVALUE;
    object _33898 = NOVALUE;
    object _33897 = NOVALUE;
    object _33895 = NOVALUE;
    object _33894 = NOVALUE;
    object _33892 = NOVALUE;
    object _33889 = NOVALUE;
    object _33888 = NOVALUE;
    object _33886 = NOVALUE;
    object _33885 = NOVALUE;
    object _33883 = NOVALUE;
    object _33882 = NOVALUE;
    object _33880 = NOVALUE;
    object _33878 = NOVALUE;
    object _33876 = NOVALUE;
    object _33874 = NOVALUE;
    object _33872 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2576		increment = Code[pc+1]*/
    _33872 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _increment_68233 = (object)*(((s1_ptr)_2)->base + _33872);
    if (!IS_ATOM_INT(_increment_68233)){
        _increment_68233 = (object)DBL_PTR(_increment_68233)->dbl;
    }

    /** execute.e:2577		limit = Code[pc+2]*/
    _33874 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _limit_68234 = (object)*(((s1_ptr)_2)->base + _33874);
    if (!IS_ATOM_INT(_limit_68234)){
        _limit_68234 = (object)DBL_PTR(_limit_68234)->dbl;
    }

    /** execute.e:2578		initial = Code[pc+3]*/
    _33876 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _initial_68235 = (object)*(((s1_ptr)_2)->base + _33876);
    if (!IS_ATOM_INT(_initial_68235)){
        _initial_68235 = (object)DBL_PTR(_initial_68235)->dbl;
    }

    /** execute.e:2581		loopvar = Code[pc+5]*/
    _33878 = _67pc_64877 + 5LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _loopvar_68236 = (object)*(((s1_ptr)_2)->base + _33878);
    if (!IS_ATOM_INT(_loopvar_68236)){
        _loopvar_68236 = (object)DBL_PTR(_loopvar_68236)->dbl;
    }

    /** execute.e:2582		jump = Code[pc+6]*/
    _33880 = _67pc_64877 + 6LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _jump_68237 = (object)*(((s1_ptr)_2)->base + _33880);
    if (!IS_ATOM_INT(_jump_68237)){
        _jump_68237 = (object)DBL_PTR(_jump_68237)->dbl;
    }

    /** execute.e:2584		if sequence(val[initial]) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33882 = (object)*(((s1_ptr)_2)->base + _initial_68235);
    _33883 = IS_SEQUENCE(_33882);
    _33882 = NOVALUE;
    if (_33883 == 0)
    {
        _33883 = NOVALUE;
        goto L1; // [92] 101
    }
    else{
        _33883 = NOVALUE;
    }

    /** execute.e:2585			RTFatal("for-loop variable is not an atom")*/
    RefDS(_33884);
    _67RTFatal(_33884);
L1: 

    /** execute.e:2587		if sequence(val[limit]) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33885 = (object)*(((s1_ptr)_2)->base + _limit_68234);
    _33886 = IS_SEQUENCE(_33885);
    _33885 = NOVALUE;
    if (_33886 == 0)
    {
        _33886 = NOVALUE;
        goto L2; // [112] 121
    }
    else{
        _33886 = NOVALUE;
    }

    /** execute.e:2588			RTFatal("for-loop limit is not an atom")*/
    RefDS(_33887);
    _67RTFatal(_33887);
L2: 

    /** execute.e:2590		if sequence(val[increment]) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33888 = (object)*(((s1_ptr)_2)->base + _increment_68233);
    _33889 = IS_SEQUENCE(_33888);
    _33888 = NOVALUE;
    if (_33889 == 0)
    {
        _33889 = NOVALUE;
        goto L3; // [132] 141
    }
    else{
        _33889 = NOVALUE;
    }

    /** execute.e:2591			RTFatal("for-loop increment is not an atom")*/
    RefDS(_33890);
    _67RTFatal(_33890);
L3: 

    /** execute.e:2594		pc += 7 -- to enter into the loop*/
    _67pc_64877 = _67pc_64877 + 7LL;

    /** execute.e:2596		if val[increment] >= 0 then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33892 = (object)*(((s1_ptr)_2)->base + _increment_68233);
    if (binary_op_a(LESS, _33892, 0LL)){
        _33892 = NOVALUE;
        goto L4; // [157] 188
    }
    _33892 = NOVALUE;

    /** execute.e:2598			if val[initial] > val[limit] then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33894 = (object)*(((s1_ptr)_2)->base + _initial_68235);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33895 = (object)*(((s1_ptr)_2)->base + _limit_68234);
    if (binary_op_a(LESSEQ, _33894, _33895)){
        _33894 = NOVALUE;
        _33895 = NOVALUE;
        goto L5; // [175] 213
    }
    _33894 = NOVALUE;
    _33895 = NOVALUE;

    /** execute.e:2599				pc = jump -- quit immediately, 0 iterations*/
    _67pc_64877 = _jump_68237;
    goto L5; // [185] 213
L4: 

    /** execute.e:2603			if val[initial] < val[limit] then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33897 = (object)*(((s1_ptr)_2)->base + _initial_68235);
    _2 = (object)SEQ_PTR(_67val_64887);
    _33898 = (object)*(((s1_ptr)_2)->base + _limit_68234);
    if (binary_op_a(GREATEREQ, _33897, _33898)){
        _33897 = NOVALUE;
        _33898 = NOVALUE;
        goto L6; // [202] 212
    }
    _33897 = NOVALUE;
    _33898 = NOVALUE;

    /** execute.e:2604				pc = jump -- quit immediately, 0 iterations*/
    _67pc_64877 = _jump_68237;
L6: 
L5: 

    /** execute.e:2608		val[loopvar] = val[initial] -- initialize loop var*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33900 = (object)*(((s1_ptr)_2)->base + _initial_68235);
    Ref(_33900);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _loopvar_68236);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33900;
    if( _1 != _33900 ){
        DeRef(_1);
    }
    _33900 = NOVALUE;

    /** execute.e:2610	end procedure*/
    DeRef(_33880);
    _33880 = NOVALUE;
    DeRef(_33876);
    _33876 = NOVALUE;
    DeRef(_33874);
    _33874 = NOVALUE;
    DeRef(_33878);
    _33878 = NOVALUE;
    DeRef(_33872);
    _33872 = NOVALUE;
    return;
    ;
}


void _67opENDFOR_GENERAL()
{
    object _loopvar_68281 = NOVALUE;
    object _increment_68282 = NOVALUE;
    object _limit_68283 = NOVALUE;
    object _next_68284 = NOVALUE;
    object _33918 = NOVALUE;
    object _33914 = NOVALUE;
    object _33909 = NOVALUE;
    object _33907 = NOVALUE;
    object _33905 = NOVALUE;
    object _33904 = NOVALUE;
    object _33902 = NOVALUE;
    object _33901 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2619		limit = val[Code[pc+2]]*/
    _33901 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _33902 = (object)*(((s1_ptr)_2)->base + _33901);
    DeRef(_limit_68283);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!IS_ATOM_INT(_33902)){
        _limit_68283 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33902)->dbl));
    }
    else{
        _limit_68283 = (object)*(((s1_ptr)_2)->base + _33902);
    }
    Ref(_limit_68283);

    /** execute.e:2620		increment = val[Code[pc+4]]*/
    _33904 = _67pc_64877 + 4LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _33905 = (object)*(((s1_ptr)_2)->base + _33904);
    DeRef(_increment_68282);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!IS_ATOM_INT(_33905)){
        _increment_68282 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33905)->dbl));
    }
    else{
        _increment_68282 = (object)*(((s1_ptr)_2)->base + _33905);
    }
    Ref(_increment_68282);

    /** execute.e:2621		loopvar = Code[pc+3]*/
    _33907 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _loopvar_68281 = (object)*(((s1_ptr)_2)->base + _33907);
    if (!IS_ATOM_INT(_loopvar_68281)){
        _loopvar_68281 = (object)DBL_PTR(_loopvar_68281)->dbl;
    }

    /** execute.e:2622		next = val[loopvar] + increment*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33909 = (object)*(((s1_ptr)_2)->base + _loopvar_68281);
    DeRef(_next_68284);
    if (IS_ATOM_INT(_33909) && IS_ATOM_INT(_increment_68282)) {
        _next_68284 = _33909 + _increment_68282;
        if ((object)((uintptr_t)_next_68284 + (uintptr_t)HIGH_BITS) >= 0){
            _next_68284 = NewDouble((eudouble)_next_68284);
        }
    }
    else {
        _next_68284 = binary_op(PLUS, _33909, _increment_68282);
    }
    _33909 = NOVALUE;

    /** execute.e:2624		if increment >= 0 then*/
    if (binary_op_a(LESS, _increment_68282, 0LL)){
        goto L1; // [71] 120
    }

    /** execute.e:2626			if next > limit then*/
    if (binary_op_a(LESSEQ, _next_68284, _limit_68283)){
        goto L2; // [77] 92
    }

    /** execute.e:2627				pc += 5 -- exit loop*/
    _67pc_64877 = _67pc_64877 + 5LL;
    goto L3; // [89] 163
L2: 

    /** execute.e:2629				val[loopvar] = next*/
    Ref(_next_68284);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _loopvar_68281);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _next_68284;
    DeRef(_1);

    /** execute.e:2630				pc = Code[pc+1] -- loop again*/
    _33914 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64877 = (object)*(((s1_ptr)_2)->base + _33914);
    if (!IS_ATOM_INT(_67pc_64877)){
        _67pc_64877 = (object)DBL_PTR(_67pc_64877)->dbl;
    }
    goto L3; // [117] 163
L1: 

    /** execute.e:2634			if next < limit then*/
    if (binary_op_a(GREATEREQ, _next_68284, _limit_68283)){
        goto L4; // [122] 137
    }

    /** execute.e:2635				pc += 5 -- exit loop*/
    _67pc_64877 = _67pc_64877 + 5LL;
    goto L5; // [134] 162
L4: 

    /** execute.e:2637				val[loopvar] = next*/
    Ref(_next_68284);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _loopvar_68281);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _next_68284;
    DeRef(_1);

    /** execute.e:2638				pc = Code[pc+1] -- loop again*/
    _33918 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64877 = (object)*(((s1_ptr)_2)->base + _33918);
    if (!IS_ATOM_INT(_67pc_64877)){
        _67pc_64877 = (object)DBL_PTR(_67pc_64877)->dbl;
    }
L5: 
L3: 

    /** execute.e:2641	end procedure*/
    DeRef(_increment_68282);
    DeRef(_limit_68283);
    DeRef(_next_68284);
    DeRef(_33918);
    _33918 = NOVALUE;
    DeRef(_33904);
    _33904 = NOVALUE;
    DeRef(_33914);
    _33914 = NOVALUE;
    _33905 = NOVALUE;
    _33902 = NOVALUE;
    DeRef(_33901);
    _33901 = NOVALUE;
    DeRef(_33907);
    _33907 = NOVALUE;
    return;
    ;
}


void _67opENDFOR_INT_UP1()
{
    object _loopvar_68317 = NOVALUE;
    object _limit_68318 = NOVALUE;
    object _next_68319 = NOVALUE;
    object _33929 = NOVALUE;
    object _33925 = NOVALUE;
    object _33923 = NOVALUE;
    object _33921 = NOVALUE;
    object _33920 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2651		limit = val[Code[pc+2]]*/
    _33920 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _33921 = (object)*(((s1_ptr)_2)->base + _33920);
    DeRef(_limit_68318);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!IS_ATOM_INT(_33921)){
        _limit_68318 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33921)->dbl));
    }
    else{
        _limit_68318 = (object)*(((s1_ptr)_2)->base + _33921);
    }
    Ref(_limit_68318);

    /** execute.e:2652		loopvar = Code[pc+3]*/
    _33923 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _loopvar_68317 = (object)*(((s1_ptr)_2)->base + _33923);
    if (!IS_ATOM_INT(_loopvar_68317)){
        _loopvar_68317 = (object)DBL_PTR(_loopvar_68317)->dbl;
    }

    /** execute.e:2653		next = val[loopvar] + 1*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _33925 = (object)*(((s1_ptr)_2)->base + _loopvar_68317);
    DeRef(_next_68319);
    if (IS_ATOM_INT(_33925)) {
        _next_68319 = _33925 + 1;
        if (_next_68319 > MAXINT){
            _next_68319 = NewDouble((eudouble)_next_68319);
        }
    }
    else
    _next_68319 = binary_op(PLUS, 1, _33925);
    _33925 = NOVALUE;

    /** execute.e:2656		if next > limit then*/
    if (binary_op_a(LESSEQ, _next_68319, _limit_68318)){
        goto L1; // [51] 66
    }

    /** execute.e:2657			pc += 5 -- exit loop*/
    _67pc_64877 = _67pc_64877 + 5LL;
    goto L2; // [63] 91
L1: 

    /** execute.e:2659			val[loopvar] = next*/
    Ref(_next_68319);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _loopvar_68317);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _next_68319;
    DeRef(_1);

    /** execute.e:2660			pc = Code[pc+1] -- loop again*/
    _33929 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67pc_64877 = (object)*(((s1_ptr)_2)->base + _33929);
    if (!IS_ATOM_INT(_67pc_64877)){
        _67pc_64877 = (object)DBL_PTR(_67pc_64877)->dbl;
    }
L2: 

    /** execute.e:2662	end procedure*/
    DeRef(_limit_68318);
    DeRef(_next_68319);
    DeRef(_33929);
    _33929 = NOVALUE;
    DeRef(_33920);
    _33920 = NOVALUE;
    _33921 = NOVALUE;
    DeRef(_33923);
    _33923 = NOVALUE;
    return;
    ;
}


object _67RTLookup(object _name_68338, object _file_68339, object _proc_68341, object _stlen_68342)
{
    object _s_68344 = NOVALUE;
    object _global_found_68345 = NOVALUE;
    object _ns_68346 = NOVALUE;
    object _colon_68347 = NOVALUE;
    object _ns_file_68348 = NOVALUE;
    object _found_in_path_68349 = NOVALUE;
    object _found_outside_path_68350 = NOVALUE;
    object _s_in_include_path_68351 = NOVALUE;
    object _scope_68448 = NOVALUE;
    object _34158 = NOVALUE;
    object _34157 = NOVALUE;
    object _34156 = NOVALUE;
    object _34155 = NOVALUE;
    object _34153 = NOVALUE;
    object _34151 = NOVALUE;
    object _34150 = NOVALUE;
    object _34149 = NOVALUE;
    object _34148 = NOVALUE;
    object _34147 = NOVALUE;
    object _34146 = NOVALUE;
    object _34145 = NOVALUE;
    object _34144 = NOVALUE;
    object _34143 = NOVALUE;
    object _34142 = NOVALUE;
    object _34141 = NOVALUE;
    object _34140 = NOVALUE;
    object _34138 = NOVALUE;
    object _34137 = NOVALUE;
    object _34136 = NOVALUE;
    object _34135 = NOVALUE;
    object _34134 = NOVALUE;
    object _34133 = NOVALUE;
    object _34132 = NOVALUE;
    object _34131 = NOVALUE;
    object _34130 = NOVALUE;
    object _34129 = NOVALUE;
    object _34128 = NOVALUE;
    object _34127 = NOVALUE;
    object _34122 = NOVALUE;
    object _34121 = NOVALUE;
    object _34120 = NOVALUE;
    object _34119 = NOVALUE;
    object _34118 = NOVALUE;
    object _34117 = NOVALUE;
    object _34116 = NOVALUE;
    object _34115 = NOVALUE;
    object _34114 = NOVALUE;
    object _34113 = NOVALUE;
    object _34112 = NOVALUE;
    object _34111 = NOVALUE;
    object _34110 = NOVALUE;
    object _34109 = NOVALUE;
    object _34108 = NOVALUE;
    object _34107 = NOVALUE;
    object _34106 = NOVALUE;
    object _34105 = NOVALUE;
    object _34103 = NOVALUE;
    object _34101 = NOVALUE;
    object _34100 = NOVALUE;
    object _34099 = NOVALUE;
    object _34098 = NOVALUE;
    object _34097 = NOVALUE;
    object _34096 = NOVALUE;
    object _34095 = NOVALUE;
    object _34094 = NOVALUE;
    object _34093 = NOVALUE;
    object _34092 = NOVALUE;
    object _34091 = NOVALUE;
    object _34090 = NOVALUE;
    object _34089 = NOVALUE;
    object _34088 = NOVALUE;
    object _34087 = NOVALUE;
    object _34086 = NOVALUE;
    object _34085 = NOVALUE;
    object _34084 = NOVALUE;
    object _34083 = NOVALUE;
    object _34082 = NOVALUE;
    object _34081 = NOVALUE;
    object _34080 = NOVALUE;
    object _34079 = NOVALUE;
    object _34078 = NOVALUE;
    object _34077 = NOVALUE;
    object _34076 = NOVALUE;
    object _34075 = NOVALUE;
    object _34074 = NOVALUE;
    object _34073 = NOVALUE;
    object _34072 = NOVALUE;
    object _34071 = NOVALUE;
    object _34070 = NOVALUE;
    object _34069 = NOVALUE;
    object _34067 = NOVALUE;
    object _34065 = NOVALUE;
    object _34064 = NOVALUE;
    object _34063 = NOVALUE;
    object _34062 = NOVALUE;
    object _34061 = NOVALUE;
    object _34060 = NOVALUE;
    object _34059 = NOVALUE;
    object _34058 = NOVALUE;
    object _34057 = NOVALUE;
    object _34056 = NOVALUE;
    object _34055 = NOVALUE;
    object _34054 = NOVALUE;
    object _34052 = NOVALUE;
    object _34049 = NOVALUE;
    object _34048 = NOVALUE;
    object _34047 = NOVALUE;
    object _34046 = NOVALUE;
    object _34045 = NOVALUE;
    object _34044 = NOVALUE;
    object _34043 = NOVALUE;
    object _34042 = NOVALUE;
    object _34041 = NOVALUE;
    object _34040 = NOVALUE;
    object _34039 = NOVALUE;
    object _34038 = NOVALUE;
    object _34037 = NOVALUE;
    object _34036 = NOVALUE;
    object _34035 = NOVALUE;
    object _34034 = NOVALUE;
    object _34033 = NOVALUE;
    object _34032 = NOVALUE;
    object _34031 = NOVALUE;
    object _34030 = NOVALUE;
    object _34029 = NOVALUE;
    object _34028 = NOVALUE;
    object _34027 = NOVALUE;
    object _34026 = NOVALUE;
    object _34025 = NOVALUE;
    object _34024 = NOVALUE;
    object _34023 = NOVALUE;
    object _34022 = NOVALUE;
    object _34021 = NOVALUE;
    object _34020 = NOVALUE;
    object _34019 = NOVALUE;
    object _34018 = NOVALUE;
    object _34017 = NOVALUE;
    object _34016 = NOVALUE;
    object _34015 = NOVALUE;
    object _34014 = NOVALUE;
    object _34013 = NOVALUE;
    object _34012 = NOVALUE;
    object _34011 = NOVALUE;
    object _34010 = NOVALUE;
    object _34009 = NOVALUE;
    object _34008 = NOVALUE;
    object _34007 = NOVALUE;
    object _34006 = NOVALUE;
    object _34005 = NOVALUE;
    object _34004 = NOVALUE;
    object _34003 = NOVALUE;
    object _34002 = NOVALUE;
    object _34001 = NOVALUE;
    object _33999 = NOVALUE;
    object _33998 = NOVALUE;
    object _33997 = NOVALUE;
    object _33996 = NOVALUE;
    object _33995 = NOVALUE;
    object _33994 = NOVALUE;
    object _33993 = NOVALUE;
    object _33992 = NOVALUE;
    object _33990 = NOVALUE;
    object _33988 = NOVALUE;
    object _33987 = NOVALUE;
    object _33986 = NOVALUE;
    object _33985 = NOVALUE;
    object _33984 = NOVALUE;
    object _33983 = NOVALUE;
    object _33982 = NOVALUE;
    object _33981 = NOVALUE;
    object _33977 = NOVALUE;
    object _33976 = NOVALUE;
    object _33975 = NOVALUE;
    object _33974 = NOVALUE;
    object _33973 = NOVALUE;
    object _33972 = NOVALUE;
    object _33971 = NOVALUE;
    object _33970 = NOVALUE;
    object _33969 = NOVALUE;
    object _33968 = NOVALUE;
    object _33967 = NOVALUE;
    object _33966 = NOVALUE;
    object _33963 = NOVALUE;
    object _33962 = NOVALUE;
    object _33960 = NOVALUE;
    object _33959 = NOVALUE;
    object _33957 = NOVALUE;
    object _33956 = NOVALUE;
    object _33955 = NOVALUE;
    object _33954 = NOVALUE;
    object _33953 = NOVALUE;
    object _33952 = NOVALUE;
    object _33951 = NOVALUE;
    object _33950 = NOVALUE;
    object _33948 = NOVALUE;
    object _33947 = NOVALUE;
    object _33946 = NOVALUE;
    object _33945 = NOVALUE;
    object _33944 = NOVALUE;
    object _33943 = NOVALUE;
    object _33942 = NOVALUE;
    object _33941 = NOVALUE;
    object _33940 = NOVALUE;
    object _33939 = NOVALUE;
    object _33938 = NOVALUE;
    object _33936 = NOVALUE;
    object _33935 = NOVALUE;
    object _33933 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2673		sequence ns*/

    /** execute.e:2674		integer colon*/

    /** execute.e:2675		integer ns_file*/

    /** execute.e:2676		integer found_in_path*/

    /** execute.e:2677		integer found_outside_path*/

    /** execute.e:2678		integer s_in_include_path*/

    /** execute.e:2680		stlen = length( SymTab )*/
    if (IS_SEQUENCE(_13SymTab_11316)){
            _stlen_68342 = SEQ_PTR(_13SymTab_11316)->length;
    }
    else {
        _stlen_68342 = 1;
    }

    /** execute.e:2681		colon = find(':', name)*/
    _colon_68347 = find_from(58LL, _name_68338, 1LL);

    /** execute.e:2683		if colon then*/
    if (_colon_68347 == 0)
    {
        goto L1; // [37] 827
    }
    else{
    }

    /** execute.e:2685			ns = name[1..colon-1]*/
    _33933 = _colon_68347 - 1LL;
    rhs_slice_target = (object_ptr)&_ns_68346;
    RHS_Slice(_name_68338, 1LL, _33933);

    /** execute.e:2686			name = name[colon+1..$]*/
    _33935 = _colon_68347 + 1;
    if (IS_SEQUENCE(_name_68338)){
            _33936 = SEQ_PTR(_name_68338)->length;
    }
    else {
        _33936 = 1;
    }
    rhs_slice_target = (object_ptr)&_name_68338;
    RHS_Slice(_name_68338, _33935, _33936);

    /** execute.e:2689			while length(ns) and (ns[$] = ' ' or ns[$] = '\t') do*/
L2: 
    if (IS_SEQUENCE(_ns_68346)){
            _33938 = SEQ_PTR(_ns_68346)->length;
    }
    else {
        _33938 = 1;
    }
    if (_33938 == 0) {
        goto L3; // [73] 130
    }
    if (IS_SEQUENCE(_ns_68346)){
            _33940 = SEQ_PTR(_ns_68346)->length;
    }
    else {
        _33940 = 1;
    }
    _2 = (object)SEQ_PTR(_ns_68346);
    _33941 = (object)*(((s1_ptr)_2)->base + _33940);
    if (IS_ATOM_INT(_33941)) {
        _33942 = (_33941 == 32LL);
    }
    else {
        _33942 = binary_op(EQUALS, _33941, 32LL);
    }
    _33941 = NOVALUE;
    if (IS_ATOM_INT(_33942)) {
        if (_33942 != 0) {
            DeRef(_33943);
            _33943 = 1;
            goto L4; // [88] 107
        }
    }
    else {
        if (DBL_PTR(_33942)->dbl != 0.0) {
            DeRef(_33943);
            _33943 = 1;
            goto L4; // [88] 107
        }
    }
    if (IS_SEQUENCE(_ns_68346)){
            _33944 = SEQ_PTR(_ns_68346)->length;
    }
    else {
        _33944 = 1;
    }
    _2 = (object)SEQ_PTR(_ns_68346);
    _33945 = (object)*(((s1_ptr)_2)->base + _33944);
    if (IS_ATOM_INT(_33945)) {
        _33946 = (_33945 == 9LL);
    }
    else {
        _33946 = binary_op(EQUALS, _33945, 9LL);
    }
    _33945 = NOVALUE;
    DeRef(_33943);
    if (IS_ATOM_INT(_33946))
    _33943 = (_33946 != 0);
    else
    _33943 = DBL_PTR(_33946)->dbl != 0.0;
L4: 
    if (_33943 == 0)
    {
        _33943 = NOVALUE;
        goto L3; // [108] 130
    }
    else{
        _33943 = NOVALUE;
    }

    /** execute.e:2690				ns = ns[1..$-1]*/
    if (IS_SEQUENCE(_ns_68346)){
            _33947 = SEQ_PTR(_ns_68346)->length;
    }
    else {
        _33947 = 1;
    }
    _33948 = _33947 - 1LL;
    _33947 = NOVALUE;
    rhs_slice_target = (object_ptr)&_ns_68346;
    RHS_Slice(_ns_68346, 1LL, _33948);

    /** execute.e:2691			end while*/
    goto L2; // [127] 70
L3: 

    /** execute.e:2694			while length(ns) and (ns[1] = ' ' or ns[1] = '\t') do*/
L5: 
    if (IS_SEQUENCE(_ns_68346)){
            _33950 = SEQ_PTR(_ns_68346)->length;
    }
    else {
        _33950 = 1;
    }
    if (_33950 == 0) {
        goto L6; // [138] 185
    }
    _2 = (object)SEQ_PTR(_ns_68346);
    _33952 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_33952)) {
        _33953 = (_33952 == 32LL);
    }
    else {
        _33953 = binary_op(EQUALS, _33952, 32LL);
    }
    _33952 = NOVALUE;
    if (IS_ATOM_INT(_33953)) {
        if (_33953 != 0) {
            DeRef(_33954);
            _33954 = 1;
            goto L7; // [150] 166
        }
    }
    else {
        if (DBL_PTR(_33953)->dbl != 0.0) {
            DeRef(_33954);
            _33954 = 1;
            goto L7; // [150] 166
        }
    }
    _2 = (object)SEQ_PTR(_ns_68346);
    _33955 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_33955)) {
        _33956 = (_33955 == 9LL);
    }
    else {
        _33956 = binary_op(EQUALS, _33955, 9LL);
    }
    _33955 = NOVALUE;
    DeRef(_33954);
    if (IS_ATOM_INT(_33956))
    _33954 = (_33956 != 0);
    else
    _33954 = DBL_PTR(_33956)->dbl != 0.0;
L7: 
    if (_33954 == 0)
    {
        _33954 = NOVALUE;
        goto L6; // [167] 185
    }
    else{
        _33954 = NOVALUE;
    }

    /** execute.e:2695				ns = ns[2..$]*/
    if (IS_SEQUENCE(_ns_68346)){
            _33957 = SEQ_PTR(_ns_68346)->length;
    }
    else {
        _33957 = 1;
    }
    rhs_slice_target = (object_ptr)&_ns_68346;
    RHS_Slice(_ns_68346, 2LL, _33957);

    /** execute.e:2696			end while*/
    goto L5; // [182] 135
L6: 

    /** execute.e:2698			if length(ns) = 0 or equal( ns, "eu") then*/
    if (IS_SEQUENCE(_ns_68346)){
            _33959 = SEQ_PTR(_ns_68346)->length;
    }
    else {
        _33959 = 1;
    }
    _33960 = (_33959 == 0LL);
    _33959 = NOVALUE;
    if (_33960 != 0) {
        goto L8; // [194] 207
    }
    if (_ns_68346 == _23708)
    _33962 = 1;
    else if (IS_ATOM_INT(_ns_68346) && IS_ATOM_INT(_23708))
    _33962 = 0;
    else
    _33962 = (compare(_ns_68346, _23708) == 0);
    if (_33962 == 0)
    {
        _33962 = NOVALUE;
        goto L9; // [203] 214
    }
    else{
        _33962 = NOVALUE;
    }
L8: 

    /** execute.e:2699				return 0 -- bad syntax*/
    DeRefDS(_name_68338);
    DeRef(_ns_68346);
    DeRef(_33946);
    _33946 = NOVALUE;
    DeRef(_33960);
    _33960 = NOVALUE;
    DeRef(_33935);
    _33935 = NOVALUE;
    DeRef(_33942);
    _33942 = NOVALUE;
    DeRef(_33933);
    _33933 = NOVALUE;
    DeRef(_33948);
    _33948 = NOVALUE;
    DeRef(_33953);
    _33953 = NOVALUE;
    DeRef(_33956);
    _33956 = NOVALUE;
    return 0LL;
L9: 

    /** execute.e:2703			s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _33963 = (object)*(((s1_ptr)_2)->base + _12TopLevelSub_20233);
    _2 = (object)SEQ_PTR(_33963);
    _s_68344 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_68344)){
        _s_68344 = (object)DBL_PTR(_s_68344)->dbl;
    }
    _33963 = NOVALUE;

    /** execute.e:2704			while s != 0 do*/
LA: 
    if (_s_68344 == 0LL)
    goto LB; // [237] 335

    /** execute.e:2705				if file = SymTab[s][S_FILE_NO] and*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _33966 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_33966);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _33967 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _33967 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _33966 = NOVALUE;
    if (IS_ATOM_INT(_33967)) {
        _33968 = (_file_68339 == _33967);
    }
    else {
        _33968 = binary_op(EQUALS, _file_68339, _33967);
    }
    _33967 = NOVALUE;
    if (IS_ATOM_INT(_33968)) {
        if (_33968 == 0) {
            DeRef(_33969);
            _33969 = 0;
            goto LC; // [259] 285
        }
    }
    else {
        if (DBL_PTR(_33968)->dbl == 0.0) {
            DeRef(_33969);
            _33969 = 0;
            goto LC; // [259] 285
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _33970 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_33970);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _33971 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _33971 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _33970 = NOVALUE;
    if (IS_ATOM_INT(_33971)) {
        _33972 = (_33971 == 523LL);
    }
    else {
        _33972 = binary_op(EQUALS, _33971, 523LL);
    }
    _33971 = NOVALUE;
    DeRef(_33969);
    if (IS_ATOM_INT(_33972))
    _33969 = (_33972 != 0);
    else
    _33969 = DBL_PTR(_33972)->dbl != 0.0;
LC: 
    if (_33969 == 0) {
        goto LD; // [285] 314
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _33974 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_33974);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _33975 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _33975 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _33974 = NOVALUE;
    if (_ns_68346 == _33975)
    _33976 = 1;
    else if (IS_ATOM_INT(_ns_68346) && IS_ATOM_INT(_33975))
    _33976 = 0;
    else
    _33976 = (compare(_ns_68346, _33975) == 0);
    _33975 = NOVALUE;
    if (_33976 == 0)
    {
        _33976 = NOVALUE;
        goto LD; // [306] 314
    }
    else{
        _33976 = NOVALUE;
    }

    /** execute.e:2708					exit*/
    goto LB; // [311] 335
LD: 

    /** execute.e:2710				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _33977 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_33977);
    _s_68344 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_68344)){
        _s_68344 = (object)DBL_PTR(_s_68344)->dbl;
    }
    _33977 = NOVALUE;

    /** execute.e:2711			end while*/
    goto LA; // [332] 237
LB: 

    /** execute.e:2713			if s = 0 then*/
    if (_s_68344 != 0LL)
    goto LE; // [337] 348

    /** execute.e:2714				return 0 -- couldn't find ns*/
    DeRefDS(_name_68338);
    DeRef(_ns_68346);
    DeRef(_33946);
    _33946 = NOVALUE;
    DeRef(_33960);
    _33960 = NOVALUE;
    DeRef(_33935);
    _33935 = NOVALUE;
    DeRef(_33972);
    _33972 = NOVALUE;
    DeRef(_33942);
    _33942 = NOVALUE;
    DeRef(_33933);
    _33933 = NOVALUE;
    DeRef(_33948);
    _33948 = NOVALUE;
    DeRef(_33953);
    _33953 = NOVALUE;
    DeRef(_33956);
    _33956 = NOVALUE;
    DeRef(_33968);
    _33968 = NOVALUE;
    return 0LL;
LE: 

    /** execute.e:2717			ns_file = val[s]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _ns_file_68348 = (object)*(((s1_ptr)_2)->base + _s_68344);
    if (!IS_ATOM_INT(_ns_file_68348))
    _ns_file_68348 = (object)DBL_PTR(_ns_file_68348)->dbl;

    /** execute.e:2720			while length(name) and (name[1] = ' ' or name[1] = '\t') do*/
LF: 
    if (IS_SEQUENCE(_name_68338)){
            _33981 = SEQ_PTR(_name_68338)->length;
    }
    else {
        _33981 = 1;
    }
    if (_33981 == 0) {
        goto L10; // [364] 411
    }
    _2 = (object)SEQ_PTR(_name_68338);
    _33983 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_33983)) {
        _33984 = (_33983 == 32LL);
    }
    else {
        _33984 = binary_op(EQUALS, _33983, 32LL);
    }
    _33983 = NOVALUE;
    if (IS_ATOM_INT(_33984)) {
        if (_33984 != 0) {
            DeRef(_33985);
            _33985 = 1;
            goto L11; // [376] 392
        }
    }
    else {
        if (DBL_PTR(_33984)->dbl != 0.0) {
            DeRef(_33985);
            _33985 = 1;
            goto L11; // [376] 392
        }
    }
    _2 = (object)SEQ_PTR(_name_68338);
    _33986 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_33986)) {
        _33987 = (_33986 == 9LL);
    }
    else {
        _33987 = binary_op(EQUALS, _33986, 9LL);
    }
    _33986 = NOVALUE;
    DeRef(_33985);
    if (IS_ATOM_INT(_33987))
    _33985 = (_33987 != 0);
    else
    _33985 = DBL_PTR(_33987)->dbl != 0.0;
L11: 
    if (_33985 == 0)
    {
        _33985 = NOVALUE;
        goto L10; // [393] 411
    }
    else{
        _33985 = NOVALUE;
    }

    /** execute.e:2721				name = name[2..$]*/
    if (IS_SEQUENCE(_name_68338)){
            _33988 = SEQ_PTR(_name_68338)->length;
    }
    else {
        _33988 = 1;
    }
    rhs_slice_target = (object_ptr)&_name_68338;
    RHS_Slice(_name_68338, 2LL, _33988);

    /** execute.e:2722			end while*/
    goto LF; // [408] 361
L10: 

    /** execute.e:2725			s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _33990 = (object)*(((s1_ptr)_2)->base + _12TopLevelSub_20233);
    _2 = (object)SEQ_PTR(_33990);
    _s_68344 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_68344)){
        _s_68344 = (object)DBL_PTR(_s_68344)->dbl;
    }
    _33990 = NOVALUE;

    /** execute.e:2726			while s != 0 and (s <= stlen or SymTab[s][S_SCOPE] = SC_PRIVATE) do*/
L12: 
    _33992 = (_s_68344 != 0LL);
    if (_33992 == 0) {
        goto L13; // [438] 818
    }
    _33994 = (_s_68344 <= _stlen_68342);
    if (_33994 != 0) {
        DeRef(_33995);
        _33995 = 1;
        goto L14; // [446] 472
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _33996 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_33996);
    _33997 = (object)*(((s1_ptr)_2)->base + 4LL);
    _33996 = NOVALUE;
    if (IS_ATOM_INT(_33997)) {
        _33998 = (_33997 == 3LL);
    }
    else {
        _33998 = binary_op(EQUALS, _33997, 3LL);
    }
    _33997 = NOVALUE;
    if (IS_ATOM_INT(_33998))
    _33995 = (_33998 != 0);
    else
    _33995 = DBL_PTR(_33998)->dbl != 0.0;
L14: 
    if (_33995 == 0)
    {
        _33995 = NOVALUE;
        goto L13; // [473] 818
    }
    else{
        _33995 = NOVALUE;
    }

    /** execute.e:2727				integer scope = SymTab[s][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _33999 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_33999);
    _scope_68448 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_scope_68448)){
        _scope_68448 = (object)DBL_PTR(_scope_68448)->dbl;
    }
    _33999 = NOVALUE;

    /** execute.e:2728				if (((scope = SC_PUBLIC) and*/
    _34001 = (_scope_68448 == 13LL);
    if (_34001 == 0) {
        _34002 = 0;
        goto L15; // [500] 584
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34003 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_34003);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _34004 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _34004 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _34003 = NOVALUE;
    if (IS_ATOM_INT(_34004)) {
        _34005 = (_34004 == _ns_file_68348);
    }
    else {
        _34005 = binary_op(EQUALS, _34004, _ns_file_68348);
    }
    _34004 = NOVALUE;
    if (IS_ATOM_INT(_34005)) {
        if (_34005 != 0) {
            DeRef(_34006);
            _34006 = 1;
            goto L16; // [520] 580
        }
    }
    else {
        if (DBL_PTR(_34005)->dbl != 0.0) {
            DeRef(_34006);
            _34006 = 1;
            goto L16; // [520] 580
        }
    }
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _34007 = (object)*(((s1_ptr)_2)->base + _ns_file_68348);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34008 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_34008);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _34009 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _34009 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _34008 = NOVALUE;
    _2 = (object)SEQ_PTR(_34007);
    if (!IS_ATOM_INT(_34009)){
        _34010 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34009)->dbl));
    }
    else{
        _34010 = (object)*(((s1_ptr)_2)->base + _34009);
    }
    _34007 = NOVALUE;
    if (IS_ATOM_INT(_34010)) {
        {uintptr_t tu;
             tu = (uintptr_t)4LL & (uintptr_t)_34010;
             _34011 = MAKE_UINT(tu);
        }
    }
    else {
        _34011 = binary_op(AND_BITS, 4LL, _34010);
    }
    _34010 = NOVALUE;
    if (IS_ATOM_INT(_34011)) {
        if (_34011 == 0) {
            DeRef(_34012);
            _34012 = 0;
            goto L17; // [552] 576
        }
    }
    else {
        if (DBL_PTR(_34011)->dbl == 0.0) {
            DeRef(_34012);
            _34012 = 0;
            goto L17; // [552] 576
        }
    }
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _34013 = (object)*(((s1_ptr)_2)->base + _file_68339);
    _2 = (object)SEQ_PTR(_34013);
    _34014 = (object)*(((s1_ptr)_2)->base + _ns_file_68348);
    _34013 = NOVALUE;
    if (IS_ATOM_INT(_34014)) {
        {uintptr_t tu;
             tu = (uintptr_t)6LL & (uintptr_t)_34014;
             _34015 = MAKE_UINT(tu);
        }
    }
    else {
        _34015 = binary_op(AND_BITS, 6LL, _34014);
    }
    _34014 = NOVALUE;
    DeRef(_34012);
    if (IS_ATOM_INT(_34015))
    _34012 = (_34015 != 0);
    else
    _34012 = DBL_PTR(_34015)->dbl != 0.0;
L17: 
    DeRef(_34006);
    _34006 = (_34012 != 0);
L16: 
    _34002 = (_34006 != 0);
L15: 
    if (_34002 != 0) {
        _34016 = 1;
        goto L18; // [584] 646
    }
    _34017 = (_scope_68448 == 11LL);
    if (_34017 == 0) {
        _34018 = 0;
        goto L19; // [594] 618
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34019 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_34019);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _34020 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _34020 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _34019 = NOVALUE;
    if (IS_ATOM_INT(_34020)) {
        _34021 = (_34020 == _ns_file_68348);
    }
    else {
        _34021 = binary_op(EQUALS, _34020, _ns_file_68348);
    }
    _34020 = NOVALUE;
    if (IS_ATOM_INT(_34021))
    _34018 = (_34021 != 0);
    else
    _34018 = DBL_PTR(_34021)->dbl != 0.0;
L19: 
    if (_34018 == 0) {
        _34022 = 0;
        goto L1A; // [618] 642
    }
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _34023 = (object)*(((s1_ptr)_2)->base + _file_68339);
    _2 = (object)SEQ_PTR(_34023);
    _34024 = (object)*(((s1_ptr)_2)->base + _ns_file_68348);
    _34023 = NOVALUE;
    if (IS_ATOM_INT(_34024)) {
        {uintptr_t tu;
             tu = (uintptr_t)2LL & (uintptr_t)_34024;
             _34025 = MAKE_UINT(tu);
        }
    }
    else {
        _34025 = binary_op(AND_BITS, 2LL, _34024);
    }
    _34024 = NOVALUE;
    if (IS_ATOM_INT(_34025))
    _34022 = (_34025 != 0);
    else
    _34022 = DBL_PTR(_34025)->dbl != 0.0;
L1A: 
    _34016 = (_34022 != 0);
L18: 
    if (_34016 != 0) {
        _34026 = 1;
        goto L1B; // [646] 660
    }
    _34027 = (_scope_68448 == 6LL);
    _34026 = (_34027 != 0);
L1B: 
    if (_34026 == 0) {
        _34028 = 0;
        goto L1C; // [660] 738
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34029 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_34029);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _34030 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _34030 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _34029 = NOVALUE;
    if (IS_ATOM_INT(_34030)) {
        _34031 = (_34030 == _ns_file_68348);
    }
    else {
        _34031 = binary_op(EQUALS, _34030, _ns_file_68348);
    }
    _34030 = NOVALUE;
    if (IS_ATOM_INT(_34031)) {
        if (_34031 != 0) {
            DeRef(_34032);
            _34032 = 1;
            goto L1D; // [680] 734
        }
    }
    else {
        if (DBL_PTR(_34031)->dbl != 0.0) {
            DeRef(_34032);
            _34032 = 1;
            goto L1D; // [680] 734
        }
    }
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _34033 = (object)*(((s1_ptr)_2)->base + _ns_file_68348);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34034 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_34034);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _34035 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _34035 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _34034 = NOVALUE;
    _2 = (object)SEQ_PTR(_34033);
    if (!IS_ATOM_INT(_34035)){
        _34036 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34035)->dbl));
    }
    else{
        _34036 = (object)*(((s1_ptr)_2)->base + _34035);
    }
    _34033 = NOVALUE;
    if (IS_ATOM_INT(_34036)) {
        if (_34036 == 0) {
            DeRef(_34037);
            _34037 = 0;
            goto L1E; // [706] 730
        }
    }
    else {
        if (DBL_PTR(_34036)->dbl == 0.0) {
            DeRef(_34037);
            _34037 = 0;
            goto L1E; // [706] 730
        }
    }
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _34038 = (object)*(((s1_ptr)_2)->base + _file_68339);
    _2 = (object)SEQ_PTR(_34038);
    _34039 = (object)*(((s1_ptr)_2)->base + _ns_file_68348);
    _34038 = NOVALUE;
    if (IS_ATOM_INT(_34039)) {
        {uintptr_t tu;
             tu = (uintptr_t)6LL & (uintptr_t)_34039;
             _34040 = MAKE_UINT(tu);
        }
    }
    else {
        _34040 = binary_op(AND_BITS, 6LL, _34039);
    }
    _34039 = NOVALUE;
    DeRef(_34037);
    if (IS_ATOM_INT(_34040))
    _34037 = (_34040 != 0);
    else
    _34037 = DBL_PTR(_34040)->dbl != 0.0;
L1E: 
    DeRef(_34032);
    _34032 = (_34037 != 0);
L1D: 
    _34028 = (_34032 != 0);
L1C: 
    if (_34028 != 0) {
        _34041 = 1;
        goto L1F; // [738] 764
    }
    _34042 = (_scope_68448 == 5LL);
    if (_34042 == 0) {
        _34043 = 0;
        goto L20; // [748] 760
    }
    _34044 = (_ns_file_68348 == _file_68339);
    _34043 = (_34044 != 0);
L20: 
    _34041 = (_34043 != 0);
L1F: 
    if (_34041 == 0) {
        goto L21; // [764] 795
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34046 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_34046);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _34047 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _34047 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _34046 = NOVALUE;
    if (_34047 == _name_68338)
    _34048 = 1;
    else if (IS_ATOM_INT(_34047) && IS_ATOM_INT(_name_68338))
    _34048 = 0;
    else
    _34048 = (compare(_34047, _name_68338) == 0);
    _34047 = NOVALUE;
    if (_34048 == 0)
    {
        _34048 = NOVALUE;
        goto L21; // [785] 795
    }
    else{
        _34048 = NOVALUE;
    }

    /** execute.e:2744					return s*/
    DeRefDS(_name_68338);
    DeRef(_ns_68346);
    DeRef(_34001);
    _34001 = NOVALUE;
    DeRef(_33946);
    _33946 = NOVALUE;
    DeRef(_33960);
    _33960 = NOVALUE;
    _34009 = NOVALUE;
    DeRef(_33987);
    _33987 = NOVALUE;
    DeRef(_33935);
    _33935 = NOVALUE;
    DeRef(_33998);
    _33998 = NOVALUE;
    DeRef(_33984);
    _33984 = NOVALUE;
    DeRef(_34017);
    _34017 = NOVALUE;
    DeRef(_34025);
    _34025 = NOVALUE;
    DeRef(_34044);
    _34044 = NOVALUE;
    DeRef(_33972);
    _33972 = NOVALUE;
    DeRef(_34031);
    _34031 = NOVALUE;
    DeRef(_33942);
    _33942 = NOVALUE;
    DeRef(_33994);
    _33994 = NOVALUE;
    DeRef(_34015);
    _34015 = NOVALUE;
    _34036 = NOVALUE;
    DeRef(_34011);
    _34011 = NOVALUE;
    DeRef(_33933);
    _33933 = NOVALUE;
    DeRef(_34027);
    _34027 = NOVALUE;
    DeRef(_34040);
    _34040 = NOVALUE;
    DeRef(_33992);
    _33992 = NOVALUE;
    DeRef(_33948);
    _33948 = NOVALUE;
    DeRef(_34005);
    _34005 = NOVALUE;
    _34035 = NOVALUE;
    DeRef(_33953);
    _33953 = NOVALUE;
    DeRef(_33956);
    _33956 = NOVALUE;
    DeRef(_34021);
    _34021 = NOVALUE;
    DeRef(_34042);
    _34042 = NOVALUE;
    DeRef(_33968);
    _33968 = NOVALUE;
    return _s_68344;
L21: 

    /** execute.e:2746				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34049 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_34049);
    _s_68344 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_68344)){
        _s_68344 = (object)DBL_PTR(_s_68344)->dbl;
    }
    _34049 = NOVALUE;

    /** execute.e:2747			end while*/
    goto L12; // [815] 434
L13: 

    /** execute.e:2749			return 0 -- couldn't find name in ns file*/
    DeRefDS(_name_68338);
    DeRef(_ns_68346);
    DeRef(_34001);
    _34001 = NOVALUE;
    DeRef(_33946);
    _33946 = NOVALUE;
    DeRef(_33960);
    _33960 = NOVALUE;
    _34009 = NOVALUE;
    DeRef(_33987);
    _33987 = NOVALUE;
    DeRef(_33935);
    _33935 = NOVALUE;
    DeRef(_33998);
    _33998 = NOVALUE;
    DeRef(_33984);
    _33984 = NOVALUE;
    DeRef(_34017);
    _34017 = NOVALUE;
    DeRef(_34025);
    _34025 = NOVALUE;
    DeRef(_34044);
    _34044 = NOVALUE;
    DeRef(_33972);
    _33972 = NOVALUE;
    DeRef(_34031);
    _34031 = NOVALUE;
    DeRef(_33942);
    _33942 = NOVALUE;
    DeRef(_33994);
    _33994 = NOVALUE;
    DeRef(_34015);
    _34015 = NOVALUE;
    _34036 = NOVALUE;
    DeRef(_34011);
    _34011 = NOVALUE;
    DeRef(_33933);
    _33933 = NOVALUE;
    DeRef(_34027);
    _34027 = NOVALUE;
    DeRef(_34040);
    _34040 = NOVALUE;
    DeRef(_33992);
    _33992 = NOVALUE;
    DeRef(_33948);
    _33948 = NOVALUE;
    DeRef(_34005);
    _34005 = NOVALUE;
    _34035 = NOVALUE;
    DeRef(_33953);
    _33953 = NOVALUE;
    DeRef(_33956);
    _33956 = NOVALUE;
    DeRef(_34021);
    _34021 = NOVALUE;
    DeRef(_34042);
    _34042 = NOVALUE;
    DeRef(_33968);
    _33968 = NOVALUE;
    return 0LL;
    goto L22; // [824] 1636
L1: 

    /** execute.e:2754			if proc != TopLevelSub then*/
    if (_proc_68341 == _12TopLevelSub_20233)
    goto L23; // [831] 958

    /** execute.e:2756				s = SymTab[proc][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34052 = (object)*(((s1_ptr)_2)->base + _proc_68341);
    _2 = (object)SEQ_PTR(_34052);
    _s_68344 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_68344)){
        _s_68344 = (object)DBL_PTR(_s_68344)->dbl;
    }
    _34052 = NOVALUE;

    /** execute.e:2757				while s and (SymTab[s][S_SCOPE] = SC_PRIVATE or*/
L24: 
    if (_s_68344 == 0) {
        goto L25; // [856] 957
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34055 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_34055);
    _34056 = (object)*(((s1_ptr)_2)->base + 4LL);
    _34055 = NOVALUE;
    if (IS_ATOM_INT(_34056)) {
        _34057 = (_34056 == 3LL);
    }
    else {
        _34057 = binary_op(EQUALS, _34056, 3LL);
    }
    _34056 = NOVALUE;
    if (IS_ATOM_INT(_34057)) {
        if (_34057 != 0) {
            DeRef(_34058);
            _34058 = 1;
            goto L26; // [878] 904
        }
    }
    else {
        if (DBL_PTR(_34057)->dbl != 0.0) {
            DeRef(_34058);
            _34058 = 1;
            goto L26; // [878] 904
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34059 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_34059);
    _34060 = (object)*(((s1_ptr)_2)->base + 4LL);
    _34059 = NOVALUE;
    if (IS_ATOM_INT(_34060)) {
        _34061 = (_34060 == 2LL);
    }
    else {
        _34061 = binary_op(EQUALS, _34060, 2LL);
    }
    _34060 = NOVALUE;
    DeRef(_34058);
    if (IS_ATOM_INT(_34061))
    _34058 = (_34061 != 0);
    else
    _34058 = DBL_PTR(_34061)->dbl != 0.0;
L26: 
    if (_34058 == 0)
    {
        _34058 = NOVALUE;
        goto L25; // [905] 957
    }
    else{
        _34058 = NOVALUE;
    }

    /** execute.e:2759					if equal(name, SymTab[s][S_NAME]) then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34062 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_34062);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _34063 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _34063 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _34062 = NOVALUE;
    if (_name_68338 == _34063)
    _34064 = 1;
    else if (IS_ATOM_INT(_name_68338) && IS_ATOM_INT(_34063))
    _34064 = 0;
    else
    _34064 = (compare(_name_68338, _34063) == 0);
    _34063 = NOVALUE;
    if (_34064 == 0)
    {
        _34064 = NOVALUE;
        goto L27; // [926] 936
    }
    else{
        _34064 = NOVALUE;
    }

    /** execute.e:2760						return s*/
    DeRefDS(_name_68338);
    DeRef(_ns_68346);
    DeRef(_34001);
    _34001 = NOVALUE;
    DeRef(_33946);
    _33946 = NOVALUE;
    DeRef(_33960);
    _33960 = NOVALUE;
    _34009 = NOVALUE;
    DeRef(_33987);
    _33987 = NOVALUE;
    DeRef(_33935);
    _33935 = NOVALUE;
    DeRef(_33998);
    _33998 = NOVALUE;
    DeRef(_33984);
    _33984 = NOVALUE;
    DeRef(_34017);
    _34017 = NOVALUE;
    DeRef(_34025);
    _34025 = NOVALUE;
    DeRef(_34044);
    _34044 = NOVALUE;
    DeRef(_34061);
    _34061 = NOVALUE;
    DeRef(_33972);
    _33972 = NOVALUE;
    DeRef(_34031);
    _34031 = NOVALUE;
    DeRef(_33942);
    _33942 = NOVALUE;
    DeRef(_33994);
    _33994 = NOVALUE;
    DeRef(_34015);
    _34015 = NOVALUE;
    _34036 = NOVALUE;
    DeRef(_34011);
    _34011 = NOVALUE;
    DeRef(_33933);
    _33933 = NOVALUE;
    DeRef(_34057);
    _34057 = NOVALUE;
    DeRef(_34027);
    _34027 = NOVALUE;
    DeRef(_34040);
    _34040 = NOVALUE;
    DeRef(_33992);
    _33992 = NOVALUE;
    DeRef(_33948);
    _33948 = NOVALUE;
    DeRef(_34005);
    _34005 = NOVALUE;
    _34035 = NOVALUE;
    DeRef(_33953);
    _33953 = NOVALUE;
    DeRef(_33956);
    _33956 = NOVALUE;
    DeRef(_34021);
    _34021 = NOVALUE;
    DeRef(_34042);
    _34042 = NOVALUE;
    DeRef(_33968);
    _33968 = NOVALUE;
    return _s_68344;
L27: 

    /** execute.e:2762					s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34065 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_34065);
    _s_68344 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_68344)){
        _s_68344 = (object)DBL_PTR(_s_68344)->dbl;
    }
    _34065 = NOVALUE;

    /** execute.e:2763				end while*/
    goto L24; // [954] 856
L25: 
L23: 

    /** execute.e:2767			s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34067 = (object)*(((s1_ptr)_2)->base + _12TopLevelSub_20233);
    _2 = (object)SEQ_PTR(_34067);
    _s_68344 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_68344)){
        _s_68344 = (object)DBL_PTR(_s_68344)->dbl;
    }
    _34067 = NOVALUE;

    /** execute.e:2768			found_in_path = 0*/
    _found_in_path_68349 = 0LL;

    /** execute.e:2769			found_outside_path = 0*/
    _found_outside_path_68350 = 0LL;

    /** execute.e:2771			while s != 0 and (s <= stlen or SymTab[s][S_SCOPE] = SC_PRIVATE) do*/
L28: 
    _34069 = (_s_68344 != 0LL);
    if (_34069 == 0) {
        goto L29; // [995] 1221
    }
    _34071 = (_s_68344 <= _stlen_68342);
    if (_34071 != 0) {
        DeRef(_34072);
        _34072 = 1;
        goto L2A; // [1003] 1029
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34073 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_34073);
    _34074 = (object)*(((s1_ptr)_2)->base + 4LL);
    _34073 = NOVALUE;
    if (IS_ATOM_INT(_34074)) {
        _34075 = (_34074 == 3LL);
    }
    else {
        _34075 = binary_op(EQUALS, _34074, 3LL);
    }
    _34074 = NOVALUE;
    if (IS_ATOM_INT(_34075))
    _34072 = (_34075 != 0);
    else
    _34072 = DBL_PTR(_34075)->dbl != 0.0;
L2A: 
    if (_34072 == 0)
    {
        _34072 = NOVALUE;
        goto L29; // [1030] 1221
    }
    else{
        _34072 = NOVALUE;
    }

    /** execute.e:2773				if SymTab[s][S_FILE_NO] = file and*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34076 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_34076);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _34077 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _34077 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _34076 = NOVALUE;
    if (IS_ATOM_INT(_34077)) {
        _34078 = (_34077 == _file_68339);
    }
    else {
        _34078 = binary_op(EQUALS, _34077, _file_68339);
    }
    _34077 = NOVALUE;
    if (IS_ATOM_INT(_34078)) {
        if (_34078 == 0) {
            DeRef(_34079);
            _34079 = 0;
            goto L2B; // [1051] 1169
        }
    }
    else {
        if (DBL_PTR(_34078)->dbl == 0.0) {
            DeRef(_34079);
            _34079 = 0;
            goto L2B; // [1051] 1169
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34080 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_34080);
    _34081 = (object)*(((s1_ptr)_2)->base + 4LL);
    _34080 = NOVALUE;
    if (IS_ATOM_INT(_34081)) {
        _34082 = (_34081 == 5LL);
    }
    else {
        _34082 = binary_op(EQUALS, _34081, 5LL);
    }
    _34081 = NOVALUE;
    if (IS_ATOM_INT(_34082)) {
        if (_34082 != 0) {
            DeRef(_34083);
            _34083 = 1;
            goto L2C; // [1073] 1099
        }
    }
    else {
        if (DBL_PTR(_34082)->dbl != 0.0) {
            DeRef(_34083);
            _34083 = 1;
            goto L2C; // [1073] 1099
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34084 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_34084);
    _34085 = (object)*(((s1_ptr)_2)->base + 4LL);
    _34084 = NOVALUE;
    if (IS_ATOM_INT(_34085)) {
        _34086 = (_34085 == 6LL);
    }
    else {
        _34086 = binary_op(EQUALS, _34085, 6LL);
    }
    _34085 = NOVALUE;
    DeRef(_34083);
    if (IS_ATOM_INT(_34086))
    _34083 = (_34086 != 0);
    else
    _34083 = DBL_PTR(_34086)->dbl != 0.0;
L2C: 
    if (_34083 != 0) {
        _34087 = 1;
        goto L2D; // [1099] 1125
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34088 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_34088);
    _34089 = (object)*(((s1_ptr)_2)->base + 4LL);
    _34088 = NOVALUE;
    if (IS_ATOM_INT(_34089)) {
        _34090 = (_34089 == 11LL);
    }
    else {
        _34090 = binary_op(EQUALS, _34089, 11LL);
    }
    _34089 = NOVALUE;
    if (IS_ATOM_INT(_34090))
    _34087 = (_34090 != 0);
    else
    _34087 = DBL_PTR(_34090)->dbl != 0.0;
L2D: 
    if (_34087 != 0) {
        _34091 = 1;
        goto L2E; // [1125] 1165
    }
    _34092 = (_proc_68341 == _12TopLevelSub_20233);
    if (_34092 == 0) {
        _34093 = 0;
        goto L2F; // [1135] 1161
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34094 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_34094);
    _34095 = (object)*(((s1_ptr)_2)->base + 4LL);
    _34094 = NOVALUE;
    if (IS_ATOM_INT(_34095)) {
        _34096 = (_34095 == 4LL);
    }
    else {
        _34096 = binary_op(EQUALS, _34095, 4LL);
    }
    _34095 = NOVALUE;
    if (IS_ATOM_INT(_34096))
    _34093 = (_34096 != 0);
    else
    _34093 = DBL_PTR(_34096)->dbl != 0.0;
L2F: 
    _34091 = (_34093 != 0);
L2E: 
    DeRef(_34079);
    _34079 = (_34091 != 0);
L2B: 
    if (_34079 == 0) {
        goto L30; // [1169] 1200
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34098 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_34098);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _34099 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _34099 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _34098 = NOVALUE;
    if (_name_68338 == _34099)
    _34100 = 1;
    else if (IS_ATOM_INT(_name_68338) && IS_ATOM_INT(_34099))
    _34100 = 0;
    else
    _34100 = (compare(_name_68338, _34099) == 0);
    _34099 = NOVALUE;
    if (_34100 == 0)
    {
        _34100 = NOVALUE;
        goto L30; // [1190] 1200
    }
    else{
        _34100 = NOVALUE;
    }

    /** execute.e:2782					return s*/
    DeRefDS(_name_68338);
    DeRef(_ns_68346);
    DeRef(_34071);
    _34071 = NOVALUE;
    DeRef(_34082);
    _34082 = NOVALUE;
    DeRef(_34001);
    _34001 = NOVALUE;
    DeRef(_33946);
    _33946 = NOVALUE;
    DeRef(_33960);
    _33960 = NOVALUE;
    DeRef(_34090);
    _34090 = NOVALUE;
    _34009 = NOVALUE;
    DeRef(_33987);
    _33987 = NOVALUE;
    DeRef(_33935);
    _33935 = NOVALUE;
    DeRef(_33998);
    _33998 = NOVALUE;
    DeRef(_33984);
    _33984 = NOVALUE;
    DeRef(_34017);
    _34017 = NOVALUE;
    DeRef(_34025);
    _34025 = NOVALUE;
    DeRef(_34044);
    _34044 = NOVALUE;
    DeRef(_34086);
    _34086 = NOVALUE;
    DeRef(_34061);
    _34061 = NOVALUE;
    DeRef(_33972);
    _33972 = NOVALUE;
    DeRef(_34031);
    _34031 = NOVALUE;
    DeRef(_33942);
    _33942 = NOVALUE;
    DeRef(_33994);
    _33994 = NOVALUE;
    DeRef(_34015);
    _34015 = NOVALUE;
    DeRef(_34096);
    _34096 = NOVALUE;
    _34036 = NOVALUE;
    DeRef(_34011);
    _34011 = NOVALUE;
    DeRef(_33933);
    _33933 = NOVALUE;
    DeRef(_34057);
    _34057 = NOVALUE;
    DeRef(_34092);
    _34092 = NOVALUE;
    DeRef(_34027);
    _34027 = NOVALUE;
    DeRef(_34078);
    _34078 = NOVALUE;
    DeRef(_34040);
    _34040 = NOVALUE;
    DeRef(_33992);
    _33992 = NOVALUE;
    DeRef(_34075);
    _34075 = NOVALUE;
    DeRef(_33948);
    _33948 = NOVALUE;
    DeRef(_34005);
    _34005 = NOVALUE;
    _34035 = NOVALUE;
    DeRef(_33953);
    _33953 = NOVALUE;
    DeRef(_33956);
    _33956 = NOVALUE;
    DeRef(_34069);
    _34069 = NOVALUE;
    DeRef(_34021);
    _34021 = NOVALUE;
    DeRef(_34042);
    _34042 = NOVALUE;
    DeRef(_33968);
    _33968 = NOVALUE;
    return _s_68344;
L30: 

    /** execute.e:2784				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34101 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_34101);
    _s_68344 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_68344)){
        _s_68344 = (object)DBL_PTR(_s_68344)->dbl;
    }
    _34101 = NOVALUE;

    /** execute.e:2785			end while*/
    goto L28; // [1218] 991
L29: 

    /** execute.e:2787			global_found = FALSE*/
    _global_found_68345 = _9FALSE_444;

    /** execute.e:2788			s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34103 = (object)*(((s1_ptr)_2)->base + _12TopLevelSub_20233);
    _2 = (object)SEQ_PTR(_34103);
    _s_68344 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_68344)){
        _s_68344 = (object)DBL_PTR(_s_68344)->dbl;
    }
    _34103 = NOVALUE;

    /** execute.e:2789			while s != 0 and (s <= stlen or SymTab[s][S_SCOPE] = SC_PRIVATE) do*/
L31: 
    _34105 = (_s_68344 != 0LL);
    if (_34105 == 0) {
        goto L32; // [1257] 1600
    }
    _34107 = (_s_68344 <= _stlen_68342);
    if (_34107 != 0) {
        DeRef(_34108);
        _34108 = 1;
        goto L33; // [1265] 1291
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34109 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_34109);
    _34110 = (object)*(((s1_ptr)_2)->base + 4LL);
    _34109 = NOVALUE;
    if (IS_ATOM_INT(_34110)) {
        _34111 = (_34110 == 3LL);
    }
    else {
        _34111 = binary_op(EQUALS, _34110, 3LL);
    }
    _34110 = NOVALUE;
    if (IS_ATOM_INT(_34111))
    _34108 = (_34111 != 0);
    else
    _34108 = DBL_PTR(_34111)->dbl != 0.0;
L33: 
    if (_34108 == 0)
    {
        _34108 = NOVALUE;
        goto L32; // [1292] 1600
    }
    else{
        _34108 = NOVALUE;
    }

    /** execute.e:2790				if SymTab[s][S_SCOPE] = SC_GLOBAL and*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34112 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_34112);
    _34113 = (object)*(((s1_ptr)_2)->base + 4LL);
    _34112 = NOVALUE;
    if (IS_ATOM_INT(_34113)) {
        _34114 = (_34113 == 6LL);
    }
    else {
        _34114 = binary_op(EQUALS, _34113, 6LL);
    }
    _34113 = NOVALUE;
    if (IS_ATOM_INT(_34114)) {
        if (_34114 == 0) {
            goto L34; // [1315] 1413
        }
    }
    else {
        if (DBL_PTR(_34114)->dbl == 0.0) {
            goto L34; // [1315] 1413
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34116 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_34116);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _34117 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _34117 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _34116 = NOVALUE;
    if (_name_68338 == _34117)
    _34118 = 1;
    else if (IS_ATOM_INT(_name_68338) && IS_ATOM_INT(_34117))
    _34118 = 0;
    else
    _34118 = (compare(_name_68338, _34117) == 0);
    _34117 = NOVALUE;
    if (_34118 == 0)
    {
        _34118 = NOVALUE;
        goto L34; // [1336] 1413
    }
    else{
        _34118 = NOVALUE;
    }

    /** execute.e:2793					s_in_include_path = include_matrix[file][SymTab[s][S_FILE_NO]] != 0*/
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _34119 = (object)*(((s1_ptr)_2)->base + _file_68339);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34120 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_34120);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _34121 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _34121 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _34120 = NOVALUE;
    _2 = (object)SEQ_PTR(_34119);
    if (!IS_ATOM_INT(_34121)){
        _34122 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34121)->dbl));
    }
    else{
        _34122 = (object)*(((s1_ptr)_2)->base + _34121);
    }
    _34119 = NOVALUE;
    if (IS_ATOM_INT(_34122)) {
        _s_in_include_path_68351 = (_34122 != 0LL);
    }
    else {
        _s_in_include_path_68351 = binary_op(NOTEQ, _34122, 0LL);
    }
    _34122 = NOVALUE;
    if (!IS_ATOM_INT(_s_in_include_path_68351)) {
        _1 = (object)(DBL_PTR(_s_in_include_path_68351)->dbl);
        DeRefDS(_s_in_include_path_68351);
        _s_in_include_path_68351 = _1;
    }

    /** execute.e:2794					if s_in_include_path then*/
    if (_s_in_include_path_68351 == 0)
    {
        goto L35; // [1371] 1390
    }
    else{
    }

    /** execute.e:2795						global_found = s*/
    _global_found_68345 = _s_68344;

    /** execute.e:2796						found_in_path += 1*/
    _found_in_path_68349 = _found_in_path_68349 + 1;
    goto L36; // [1387] 1579
L35: 

    /** execute.e:2798						if not found_in_path then*/
    if (_found_in_path_68349 != 0)
    goto L37; // [1392] 1403

    /** execute.e:2799							global_found = s*/
    _global_found_68345 = _s_68344;
L37: 

    /** execute.e:2801						found_outside_path += 1*/
    _found_outside_path_68350 = _found_outside_path_68350 + 1;
    goto L36; // [1410] 1579
L34: 

    /** execute.e:2803				elsif (sym_scope( s ) = SC_PUBLIC and equal( name, SymTab[s][S_NAME] ) and*/
    _34127 = _53sym_scope(_s_68344);
    if (IS_ATOM_INT(_34127)) {
        _34128 = (_34127 == 13LL);
    }
    else {
        _34128 = binary_op(EQUALS, _34127, 13LL);
    }
    DeRef(_34127);
    _34127 = NOVALUE;
    if (IS_ATOM_INT(_34128)) {
        if (_34128 == 0) {
            DeRef(_34129);
            _34129 = 0;
            goto L38; // [1425] 1449
        }
    }
    else {
        if (DBL_PTR(_34128)->dbl == 0.0) {
            DeRef(_34129);
            _34129 = 0;
            goto L38; // [1425] 1449
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34130 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_34130);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _34131 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _34131 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _34130 = NOVALUE;
    if (_name_68338 == _34131)
    _34132 = 1;
    else if (IS_ATOM_INT(_name_68338) && IS_ATOM_INT(_34131))
    _34132 = 0;
    else
    _34132 = (compare(_name_68338, _34131) == 0);
    _34131 = NOVALUE;
    DeRef(_34129);
    _34129 = (_34132 != 0);
L38: 
    if (_34129 == 0) {
        _34133 = 0;
        goto L39; // [1449] 1485
    }
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _34134 = (object)*(((s1_ptr)_2)->base + _file_68339);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34135 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_34135);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _34136 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _34136 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _34135 = NOVALUE;
    _2 = (object)SEQ_PTR(_34134);
    if (!IS_ATOM_INT(_34136)){
        _34137 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34136)->dbl));
    }
    else{
        _34137 = (object)*(((s1_ptr)_2)->base + _34136);
    }
    _34134 = NOVALUE;
    if (IS_ATOM_INT(_34137)) {
        {uintptr_t tu;
             tu = (uintptr_t)6LL & (uintptr_t)_34137;
             _34138 = MAKE_UINT(tu);
        }
    }
    else {
        _34138 = binary_op(AND_BITS, 6LL, _34137);
    }
    _34137 = NOVALUE;
    if (IS_ATOM_INT(_34138))
    _34133 = (_34138 != 0);
    else
    _34133 = DBL_PTR(_34138)->dbl != 0.0;
L39: 
    if (_34133 != 0) {
        goto L3A; // [1485] 1564
    }
    _34140 = _53sym_scope(_s_68344);
    if (IS_ATOM_INT(_34140)) {
        _34141 = (_34140 == 11LL);
    }
    else {
        _34141 = binary_op(EQUALS, _34140, 11LL);
    }
    DeRef(_34140);
    _34140 = NOVALUE;
    if (IS_ATOM_INT(_34141)) {
        if (_34141 == 0) {
            DeRef(_34142);
            _34142 = 0;
            goto L3B; // [1499] 1523
        }
    }
    else {
        if (DBL_PTR(_34141)->dbl == 0.0) {
            DeRef(_34142);
            _34142 = 0;
            goto L3B; // [1499] 1523
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34143 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_34143);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _34144 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _34144 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _34143 = NOVALUE;
    if (_name_68338 == _34144)
    _34145 = 1;
    else if (IS_ATOM_INT(_name_68338) && IS_ATOM_INT(_34144))
    _34145 = 0;
    else
    _34145 = (compare(_name_68338, _34144) == 0);
    _34144 = NOVALUE;
    DeRef(_34142);
    _34142 = (_34145 != 0);
L3B: 
    if (_34142 == 0) {
        DeRef(_34146);
        _34146 = 0;
        goto L3C; // [1523] 1559
    }
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _34147 = (object)*(((s1_ptr)_2)->base + _file_68339);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34148 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_34148);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _34149 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _34149 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _34148 = NOVALUE;
    _2 = (object)SEQ_PTR(_34147);
    if (!IS_ATOM_INT(_34149)){
        _34150 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34149)->dbl));
    }
    else{
        _34150 = (object)*(((s1_ptr)_2)->base + _34149);
    }
    _34147 = NOVALUE;
    if (IS_ATOM_INT(_34150)) {
        {uintptr_t tu;
             tu = (uintptr_t)2LL & (uintptr_t)_34150;
             _34151 = MAKE_UINT(tu);
        }
    }
    else {
        _34151 = binary_op(AND_BITS, 2LL, _34150);
    }
    _34150 = NOVALUE;
    if (IS_ATOM_INT(_34151))
    _34146 = (_34151 != 0);
    else
    _34146 = DBL_PTR(_34151)->dbl != 0.0;
L3C: 
    if (_34146 == 0)
    {
        _34146 = NOVALUE;
        goto L3D; // [1560] 1578
    }
    else{
        _34146 = NOVALUE;
    }
L3A: 

    /** execute.e:2808					global_found = s*/
    _global_found_68345 = _s_68344;

    /** execute.e:2809					found_in_path += 1*/
    _found_in_path_68349 = _found_in_path_68349 + 1;
L3D: 
L36: 

    /** execute.e:2811				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34153 = (object)*(((s1_ptr)_2)->base + _s_68344);
    _2 = (object)SEQ_PTR(_34153);
    _s_68344 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_68344)){
        _s_68344 = (object)DBL_PTR(_s_68344)->dbl;
    }
    _34153 = NOVALUE;

    /** execute.e:2812			end while*/
    goto L31; // [1597] 1253
L32: 

    /** execute.e:2814			if found_in_path != 1 and (( found_in_path + found_outside_path ) != 1 ) then*/
    _34155 = (_found_in_path_68349 != 1LL);
    if (_34155 == 0) {
        goto L3E; // [1606] 1629
    }
    _34157 = _found_in_path_68349 + _found_outside_path_68350;
    if ((object)((uintptr_t)_34157 + (uintptr_t)HIGH_BITS) >= 0){
        _34157 = NewDouble((eudouble)_34157);
    }
    if (IS_ATOM_INT(_34157)) {
        _34158 = (_34157 != 1LL);
    }
    else {
        _34158 = (DBL_PTR(_34157)->dbl != (eudouble)1LL);
    }
    DeRef(_34157);
    _34157 = NOVALUE;
    if (_34158 == 0)
    {
        DeRef(_34158);
        _34158 = NOVALUE;
        goto L3E; // [1619] 1629
    }
    else{
        DeRef(_34158);
        _34158 = NOVALUE;
    }

    /** execute.e:2815				return 0*/
    DeRefDS(_name_68338);
    DeRef(_ns_68346);
    DeRef(_34071);
    _34071 = NOVALUE;
    DeRef(_34082);
    _34082 = NOVALUE;
    DeRef(_34001);
    _34001 = NOVALUE;
    DeRef(_33946);
    _33946 = NOVALUE;
    DeRef(_34128);
    _34128 = NOVALUE;
    DeRef(_33960);
    _33960 = NOVALUE;
    DeRef(_34090);
    _34090 = NOVALUE;
    _34009 = NOVALUE;
    DeRef(_33987);
    _33987 = NOVALUE;
    DeRef(_33935);
    _33935 = NOVALUE;
    DeRef(_33998);
    _33998 = NOVALUE;
    DeRef(_33984);
    _33984 = NOVALUE;
    DeRef(_34017);
    _34017 = NOVALUE;
    DeRef(_34025);
    _34025 = NOVALUE;
    _34136 = NOVALUE;
    DeRef(_34044);
    _34044 = NOVALUE;
    DeRef(_34086);
    _34086 = NOVALUE;
    DeRef(_34061);
    _34061 = NOVALUE;
    DeRef(_33972);
    _33972 = NOVALUE;
    DeRef(_34031);
    _34031 = NOVALUE;
    DeRef(_34151);
    _34151 = NOVALUE;
    DeRef(_34107);
    _34107 = NOVALUE;
    DeRef(_34141);
    _34141 = NOVALUE;
    DeRef(_33942);
    _33942 = NOVALUE;
    DeRef(_33994);
    _33994 = NOVALUE;
    DeRef(_34015);
    _34015 = NOVALUE;
    DeRef(_34096);
    _34096 = NOVALUE;
    DeRef(_34111);
    _34111 = NOVALUE;
    _34121 = NOVALUE;
    _34036 = NOVALUE;
    DeRef(_34011);
    _34011 = NOVALUE;
    DeRef(_33933);
    _33933 = NOVALUE;
    DeRef(_34057);
    _34057 = NOVALUE;
    DeRef(_34092);
    _34092 = NOVALUE;
    DeRef(_34105);
    _34105 = NOVALUE;
    DeRef(_34027);
    _34027 = NOVALUE;
    _34149 = NOVALUE;
    DeRef(_34155);
    _34155 = NOVALUE;
    DeRef(_34078);
    _34078 = NOVALUE;
    DeRef(_34040);
    _34040 = NOVALUE;
    DeRef(_33992);
    _33992 = NOVALUE;
    DeRef(_34138);
    _34138 = NOVALUE;
    DeRef(_34075);
    _34075 = NOVALUE;
    DeRef(_33948);
    _33948 = NOVALUE;
    DeRef(_34005);
    _34005 = NOVALUE;
    _34035 = NOVALUE;
    DeRef(_33953);
    _33953 = NOVALUE;
    DeRef(_33956);
    _33956 = NOVALUE;
    DeRef(_34069);
    _34069 = NOVALUE;
    DeRef(_34021);
    _34021 = NOVALUE;
    DeRef(_34042);
    _34042 = NOVALUE;
    DeRef(_34114);
    _34114 = NOVALUE;
    DeRef(_33968);
    _33968 = NOVALUE;
    return 0LL;
L3E: 

    /** execute.e:2817			return global_found*/
    DeRefDS(_name_68338);
    DeRef(_ns_68346);
    DeRef(_34071);
    _34071 = NOVALUE;
    DeRef(_34082);
    _34082 = NOVALUE;
    DeRef(_34001);
    _34001 = NOVALUE;
    DeRef(_33946);
    _33946 = NOVALUE;
    DeRef(_34128);
    _34128 = NOVALUE;
    DeRef(_33960);
    _33960 = NOVALUE;
    DeRef(_34090);
    _34090 = NOVALUE;
    _34009 = NOVALUE;
    DeRef(_33987);
    _33987 = NOVALUE;
    DeRef(_33935);
    _33935 = NOVALUE;
    DeRef(_33998);
    _33998 = NOVALUE;
    DeRef(_33984);
    _33984 = NOVALUE;
    DeRef(_34017);
    _34017 = NOVALUE;
    DeRef(_34025);
    _34025 = NOVALUE;
    _34136 = NOVALUE;
    DeRef(_34044);
    _34044 = NOVALUE;
    DeRef(_34086);
    _34086 = NOVALUE;
    DeRef(_34061);
    _34061 = NOVALUE;
    DeRef(_33972);
    _33972 = NOVALUE;
    DeRef(_34031);
    _34031 = NOVALUE;
    DeRef(_34151);
    _34151 = NOVALUE;
    DeRef(_34107);
    _34107 = NOVALUE;
    DeRef(_34141);
    _34141 = NOVALUE;
    DeRef(_33942);
    _33942 = NOVALUE;
    DeRef(_33994);
    _33994 = NOVALUE;
    DeRef(_34015);
    _34015 = NOVALUE;
    DeRef(_34096);
    _34096 = NOVALUE;
    DeRef(_34111);
    _34111 = NOVALUE;
    _34121 = NOVALUE;
    _34036 = NOVALUE;
    DeRef(_34011);
    _34011 = NOVALUE;
    DeRef(_33933);
    _33933 = NOVALUE;
    DeRef(_34057);
    _34057 = NOVALUE;
    DeRef(_34092);
    _34092 = NOVALUE;
    DeRef(_34105);
    _34105 = NOVALUE;
    DeRef(_34027);
    _34027 = NOVALUE;
    _34149 = NOVALUE;
    DeRef(_34155);
    _34155 = NOVALUE;
    DeRef(_34078);
    _34078 = NOVALUE;
    DeRef(_34040);
    _34040 = NOVALUE;
    DeRef(_33992);
    _33992 = NOVALUE;
    DeRef(_34138);
    _34138 = NOVALUE;
    DeRef(_34075);
    _34075 = NOVALUE;
    DeRef(_33948);
    _33948 = NOVALUE;
    DeRef(_34005);
    _34005 = NOVALUE;
    _34035 = NOVALUE;
    DeRef(_33953);
    _33953 = NOVALUE;
    DeRef(_33956);
    _33956 = NOVALUE;
    DeRef(_34069);
    _34069 = NOVALUE;
    DeRef(_34021);
    _34021 = NOVALUE;
    DeRef(_34042);
    _34042 = NOVALUE;
    DeRef(_34114);
    _34114 = NOVALUE;
    DeRef(_33968);
    _33968 = NOVALUE;
    return _global_found_68345;
L22: 
    ;
}


void _67do_call_proc(object _sub_68726, object _args_68727, object _advance_68728)
{
    object _n_68729 = NOVALUE;
    object _arg_68730 = NOVALUE;
    object _private_block_68745 = NOVALUE;
    object _p_68751 = NOVALUE;
    object _34200 = NOVALUE;
    object _34195 = NOVALUE;
    object _34193 = NOVALUE;
    object _34192 = NOVALUE;
    object _34191 = NOVALUE;
    object _34189 = NOVALUE;
    object _34187 = NOVALUE;
    object _34184 = NOVALUE;
    object _34182 = NOVALUE;
    object _34180 = NOVALUE;
    object _34179 = NOVALUE;
    object _34178 = NOVALUE;
    object _34177 = NOVALUE;
    object _34176 = NOVALUE;
    object _34175 = NOVALUE;
    object _34173 = NOVALUE;
    object _34172 = NOVALUE;
    object _34170 = NOVALUE;
    object _34169 = NOVALUE;
    object _34167 = NOVALUE;
    object _34166 = NOVALUE;
    object _34164 = NOVALUE;
    object _34163 = NOVALUE;
    object _34161 = NOVALUE;
    object _34159 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_advance_68728)) {
        _1 = (object)(DBL_PTR(_advance_68728)->dbl);
        DeRefDS(_advance_68728);
        _advance_68728 = _1;
    }

    /** execute.e:2825		n = SymTab[sub][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34159 = (object)*(((s1_ptr)_2)->base + _sub_68726);
    _2 = (object)SEQ_PTR(_34159);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _n_68729 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _n_68729 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    if (!IS_ATOM_INT(_n_68729)){
        _n_68729 = (object)DBL_PTR(_n_68729)->dbl;
    }
    _34159 = NOVALUE;

    /** execute.e:2826		arg = SymTab[sub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34161 = (object)*(((s1_ptr)_2)->base + _sub_68726);
    _2 = (object)SEQ_PTR(_34161);
    _arg_68730 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_arg_68730)){
        _arg_68730 = (object)DBL_PTR(_arg_68730)->dbl;
    }
    _34161 = NOVALUE;

    /** execute.e:2827		if SymTab[sub][S_RESIDENT_TASK] != 0 then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34163 = (object)*(((s1_ptr)_2)->base + _sub_68726);
    _2 = (object)SEQ_PTR(_34163);
    _34164 = (object)*(((s1_ptr)_2)->base + 25LL);
    _34163 = NOVALUE;
    if (binary_op_a(EQUALS, _34164, 0LL)){
        _34164 = NOVALUE;
        goto L1; // [53] 314
    }
    _34164 = NOVALUE;

    /** execute.e:2831			sequence private_block = repeat(0, SymTab[sub][S_STACK_SPACE])*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34166 = (object)*(((s1_ptr)_2)->base + _sub_68726);
    _2 = (object)SEQ_PTR(_34166);
    if (!IS_ATOM_INT(_12S_STACK_SPACE_19924)){
        _34167 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_STACK_SPACE_19924)->dbl));
    }
    else{
        _34167 = (object)*(((s1_ptr)_2)->base + _12S_STACK_SPACE_19924);
    }
    _34166 = NOVALUE;
    DeRef(_private_block_68745);
    _private_block_68745 = Repeat(0LL, _34167);
    _34167 = NOVALUE;

    /** execute.e:2832			integer p = 1*/
    _p_68751 = 1LL;

    /** execute.e:2833			for i = 1 to n do*/
    _34169 = _n_68729;
    {
        object _i_68753;
        _i_68753 = 1LL;
L2: 
        if (_i_68753 > _34169){
            goto L3; // [85] 145
        }

        /** execute.e:2834				private_block[p] = val[arg]*/
        _2 = (object)SEQ_PTR(_67val_64887);
        _34170 = (object)*(((s1_ptr)_2)->base + _arg_68730);
        Ref(_34170);
        _2 = (object)SEQ_PTR(_private_block_68745);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _private_block_68745 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _p_68751);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _34170;
        if( _1 != _34170 ){
            DeRef(_1);
        }
        _34170 = NOVALUE;

        /** execute.e:2835				p += 1*/
        _p_68751 = _p_68751 + 1;

        /** execute.e:2836				val[arg] = args[i]*/
        _2 = (object)SEQ_PTR(_args_68727);
        _34172 = (object)*(((s1_ptr)_2)->base + _i_68753);
        Ref(_34172);
        _2 = (object)SEQ_PTR(_67val_64887);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_64887 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _arg_68730);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _34172;
        if( _1 != _34172 ){
            DeRef(_1);
        }
        _34172 = NOVALUE;

        /** execute.e:2837				arg = SymTab[arg][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _34173 = (object)*(((s1_ptr)_2)->base + _arg_68730);
        _2 = (object)SEQ_PTR(_34173);
        _arg_68730 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_arg_68730)){
            _arg_68730 = (object)DBL_PTR(_arg_68730)->dbl;
        }
        _34173 = NOVALUE;

        /** execute.e:2838			end for*/
        _i_68753 = _i_68753 + 1LL;
        goto L2; // [140] 92
L3: 
        ;
    }

    /** execute.e:2841			while arg != 0 and SymTab[arg][S_SCOPE] <= SC_PRIVATE do*/
L4: 
    _34175 = (_arg_68730 != 0LL);
    if (_34175 == 0) {
        goto L5; // [154] 229
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34177 = (object)*(((s1_ptr)_2)->base + _arg_68730);
    _2 = (object)SEQ_PTR(_34177);
    _34178 = (object)*(((s1_ptr)_2)->base + 4LL);
    _34177 = NOVALUE;
    if (IS_ATOM_INT(_34178)) {
        _34179 = (_34178 <= 3LL);
    }
    else {
        _34179 = binary_op(LESSEQ, _34178, 3LL);
    }
    _34178 = NOVALUE;
    if (_34179 <= 0) {
        if (_34179 == 0) {
            DeRef(_34179);
            _34179 = NOVALUE;
            goto L5; // [177] 229
        }
        else {
            if (!IS_ATOM_INT(_34179) && DBL_PTR(_34179)->dbl == 0.0){
                DeRef(_34179);
                _34179 = NOVALUE;
                goto L5; // [177] 229
            }
            DeRef(_34179);
            _34179 = NOVALUE;
        }
    }
    DeRef(_34179);
    _34179 = NOVALUE;

    /** execute.e:2842				private_block[p] = val[arg]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34180 = (object)*(((s1_ptr)_2)->base + _arg_68730);
    Ref(_34180);
    _2 = (object)SEQ_PTR(_private_block_68745);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _private_block_68745 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _p_68751);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34180;
    if( _1 != _34180 ){
        DeRef(_1);
    }
    _34180 = NOVALUE;

    /** execute.e:2843				p += 1*/
    _p_68751 = _p_68751 + 1;

    /** execute.e:2844				val[arg] = NOVALUE -- necessary?*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _arg_68730);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);

    /** execute.e:2845				arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34182 = (object)*(((s1_ptr)_2)->base + _arg_68730);
    _2 = (object)SEQ_PTR(_34182);
    _arg_68730 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_arg_68730)){
        _arg_68730 = (object)DBL_PTR(_arg_68730)->dbl;
    }
    _34182 = NOVALUE;

    /** execute.e:2846			end while*/
    goto L4; // [226] 150
L5: 

    /** execute.e:2849			arg = SymTab[sub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34184 = (object)*(((s1_ptr)_2)->base + _sub_68726);
    _2 = (object)SEQ_PTR(_34184);
    if (!IS_ATOM_INT(_12S_TEMPS_19909)){
        _arg_68730 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TEMPS_19909)->dbl));
    }
    else{
        _arg_68730 = (object)*(((s1_ptr)_2)->base + _12S_TEMPS_19909);
    }
    if (!IS_ATOM_INT(_arg_68730)){
        _arg_68730 = (object)DBL_PTR(_arg_68730)->dbl;
    }
    _34184 = NOVALUE;

    /** execute.e:2850			while arg != 0 do*/
L6: 
    if (_arg_68730 == 0LL)
    goto L7; // [250] 303

    /** execute.e:2851				private_block[p] = val[arg]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34187 = (object)*(((s1_ptr)_2)->base + _arg_68730);
    Ref(_34187);
    _2 = (object)SEQ_PTR(_private_block_68745);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _private_block_68745 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _p_68751);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34187;
    if( _1 != _34187 ){
        DeRef(_1);
    }
    _34187 = NOVALUE;

    /** execute.e:2852				p += 1*/
    _p_68751 = _p_68751 + 1;

    /** execute.e:2853				val[arg] = NOVALUE -- necessary?*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _arg_68730);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);

    /** execute.e:2854				arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34189 = (object)*(((s1_ptr)_2)->base + _arg_68730);
    _2 = (object)SEQ_PTR(_34189);
    _arg_68730 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_arg_68730)){
        _arg_68730 = (object)DBL_PTR(_arg_68730)->dbl;
    }
    _34189 = NOVALUE;

    /** execute.e:2855			end while*/
    goto L6; // [300] 250
L7: 

    /** execute.e:2858			save_private_block(sub, private_block)*/
    RefDS(_private_block_68745);
    _67save_private_block(_sub_68726, _private_block_68745);
    DeRefDS(_private_block_68745);
    _private_block_68745 = NOVALUE;
    goto L8; // [311] 362
L1: 

    /** execute.e:2862			for i = 1 to n do*/
    _34191 = _n_68729;
    {
        object _i_68793;
        _i_68793 = 1LL;
L9: 
        if (_i_68793 > _34191){
            goto LA; // [319] 361
        }

        /** execute.e:2863				val[arg] = args[i]*/
        _2 = (object)SEQ_PTR(_args_68727);
        _34192 = (object)*(((s1_ptr)_2)->base + _i_68793);
        Ref(_34192);
        _2 = (object)SEQ_PTR(_67val_64887);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_64887 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _arg_68730);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _34192;
        if( _1 != _34192 ){
            DeRef(_1);
        }
        _34192 = NOVALUE;

        /** execute.e:2864				arg = SymTab[arg][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _34193 = (object)*(((s1_ptr)_2)->base + _arg_68730);
        _2 = (object)SEQ_PTR(_34193);
        _arg_68730 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_arg_68730)){
            _arg_68730 = (object)DBL_PTR(_arg_68730)->dbl;
        }
        _34193 = NOVALUE;

        /** execute.e:2865			end for*/
        _i_68793 = _i_68793 + 1LL;
        goto L9; // [356] 326
LA: 
        ;
    }
L8: 

    /** execute.e:2868		SymTab[sub][S_RESIDENT_TASK] = current_task*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sub_68726 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67current_task_64894;
    DeRef(_1);
    _34195 = NOVALUE;

    /** execute.e:2870		pc += advance*/
    _67pc_64877 = _67pc_64877 + _advance_68728;

    /** execute.e:2872		call_stack = append(call_stack, pc)*/
    Append(&_67call_stack_64895, _67call_stack_64895, _67pc_64877);

    /** execute.e:2873		call_stack = append(call_stack, sub)*/
    Append(&_67call_stack_64895, _67call_stack_64895, _sub_68726);

    /** execute.e:2875		Code = SymTab[sub][S_CODE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34200 = (object)*(((s1_ptr)_2)->base + _sub_68726);
    DeRef(_12Code_20315);
    _2 = (object)SEQ_PTR(_34200);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    Ref(_12Code_20315);
    _34200 = NOVALUE;

    /** execute.e:2876		pc = 1*/
    _67pc_64877 = 1LL;

    /** execute.e:2877	end procedure*/
    DeRefDS(_args_68727);
    DeRef(_34175);
    _34175 = NOVALUE;
    return;
    ;
}


void _67opCALL_PROC()
{
    object _cf_68814 = NOVALUE;
    object _sub_68816 = NOVALUE;
    object _34249 = NOVALUE;
    object _34248 = NOVALUE;
    object _34247 = NOVALUE;
    object _34246 = NOVALUE;
    object _34245 = NOVALUE;
    object _34244 = NOVALUE;
    object _34243 = NOVALUE;
    object _34242 = NOVALUE;
    object _34241 = NOVALUE;
    object _34240 = NOVALUE;
    object _34237 = NOVALUE;
    object _34236 = NOVALUE;
    object _34235 = NOVALUE;
    object _34234 = NOVALUE;
    object _34232 = NOVALUE;
    object _34231 = NOVALUE;
    object _34230 = NOVALUE;
    object _34229 = NOVALUE;
    object _34228 = NOVALUE;
    object _34225 = NOVALUE;
    object _34224 = NOVALUE;
    object _34223 = NOVALUE;
    object _34222 = NOVALUE;
    object _34221 = NOVALUE;
    object _34218 = NOVALUE;
    object _34217 = NOVALUE;
    object _34215 = NOVALUE;
    object _34213 = NOVALUE;
    object _34212 = NOVALUE;
    object _34211 = NOVALUE;
    object _34210 = NOVALUE;
    object _34209 = NOVALUE;
    object _34207 = NOVALUE;
    object _34206 = NOVALUE;
    object _34204 = NOVALUE;
    object _34202 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2884		cf = Code[pc] = CALL_FUNC*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    _34202 = (object)*(((s1_ptr)_2)->base + _67pc_64877);
    if (IS_ATOM_INT(_34202)) {
        _cf_68814 = (_34202 == 137LL);
    }
    else {
        _cf_68814 = binary_op(EQUALS, _34202, 137LL);
    }
    _34202 = NOVALUE;
    if (!IS_ATOM_INT(_cf_68814)) {
        _1 = (object)(DBL_PTR(_cf_68814)->dbl);
        DeRefDS(_cf_68814);
        _cf_68814 = _1;
    }

    /** execute.e:2886		a = Code[pc+1]  -- routine id*/
    _34204 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34204);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2887		if val[a] < 0 or val[a] >= length(e_routine) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34206 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_ATOM_INT(_34206)) {
        _34207 = (_34206 < 0LL);
    }
    else {
        _34207 = binary_op(LESS, _34206, 0LL);
    }
    _34206 = NOVALUE;
    if (IS_ATOM_INT(_34207)) {
        if (_34207 != 0) {
            goto L1; // [49] 75
        }
    }
    else {
        if (DBL_PTR(_34207)->dbl != 0.0) {
            goto L1; // [49] 75
        }
    }
    _2 = (object)SEQ_PTR(_67val_64887);
    _34209 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_SEQUENCE(_67e_routine_64926)){
            _34210 = SEQ_PTR(_67e_routine_64926)->length;
    }
    else {
        _34210 = 1;
    }
    if (IS_ATOM_INT(_34209)) {
        _34211 = (_34209 >= _34210);
    }
    else {
        _34211 = binary_op(GREATEREQ, _34209, _34210);
    }
    _34209 = NOVALUE;
    _34210 = NOVALUE;
    if (_34211 == 0) {
        DeRef(_34211);
        _34211 = NOVALUE;
        goto L2; // [71] 81
    }
    else {
        if (!IS_ATOM_INT(_34211) && DBL_PTR(_34211)->dbl == 0.0){
            DeRef(_34211);
            _34211 = NOVALUE;
            goto L2; // [71] 81
        }
        DeRef(_34211);
        _34211 = NOVALUE;
    }
    DeRef(_34211);
    _34211 = NOVALUE;
L1: 

    /** execute.e:2888			RTFatal("invalid routine id")*/
    RefDS(_32577);
    _67RTFatal(_32577);
L2: 

    /** execute.e:2891		sub = e_routine[val[a]+1]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34212 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_ATOM_INT(_34212)) {
        _34213 = _34212 + 1;
    }
    else
    _34213 = binary_op(PLUS, 1, _34212);
    _34212 = NOVALUE;
    _2 = (object)SEQ_PTR(_67e_routine_64926);
    if (!IS_ATOM_INT(_34213)){
        _sub_68816 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34213)->dbl));
    }
    else{
        _sub_68816 = (object)*(((s1_ptr)_2)->base + _34213);
    }

    /** execute.e:2892		b = Code[pc+2]  -- argument list*/
    _34215 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34215);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2894		if cf then*/
    if (_cf_68814 == 0)
    {
        goto L3; // [121] 169
    }
    else{
    }

    /** execute.e:2895			if SymTab[sub][S_TOKEN] = PROC then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34217 = (object)*(((s1_ptr)_2)->base + _sub_68816);
    _2 = (object)SEQ_PTR(_34217);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _34218 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _34218 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _34217 = NOVALUE;
    if (binary_op_a(NOTEQ, _34218, 27LL)){
        _34218 = NOVALUE;
        goto L4; // [140] 212
    }
    _34218 = NOVALUE;

    /** execute.e:2896				RTFatal(sprintf("%s() does not return a value", SymTab[sub][S_NAME]))*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34221 = (object)*(((s1_ptr)_2)->base + _sub_68816);
    _2 = (object)SEQ_PTR(_34221);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _34222 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _34222 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _34221 = NOVALUE;
    _34223 = EPrintf(-9999999, _34220, _34222);
    _34222 = NOVALUE;
    _67RTFatal(_34223);
    _34223 = NOVALUE;
    goto L4; // [166] 212
L3: 

    /** execute.e:2899			if SymTab[sub][S_TOKEN] != PROC then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34224 = (object)*(((s1_ptr)_2)->base + _sub_68816);
    _2 = (object)SEQ_PTR(_34224);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _34225 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _34225 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _34224 = NOVALUE;
    if (binary_op_a(EQUALS, _34225, 27LL)){
        _34225 = NOVALUE;
        goto L5; // [185] 211
    }
    _34225 = NOVALUE;

    /** execute.e:2900				RTFatal(sprintf("the value returned by %s() must be assigned or used",*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34228 = (object)*(((s1_ptr)_2)->base + _sub_68816);
    _2 = (object)SEQ_PTR(_34228);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _34229 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _34229 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _34228 = NOVALUE;
    _34230 = EPrintf(-9999999, _34227, _34229);
    _34229 = NOVALUE;
    _67RTFatal(_34230);
    _34230 = NOVALUE;
L5: 
L4: 

    /** execute.e:2904		if atom(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34231 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _34232 = IS_ATOM(_34231);
    _34231 = NOVALUE;
    if (_34232 == 0)
    {
        _34232 = NOVALUE;
        goto L6; // [225] 234
    }
    else{
        _34232 = NOVALUE;
    }

    /** execute.e:2905			RTFatal("argument list must be a sequence")*/
    RefDS(_34233);
    _67RTFatal(_34233);
L6: 

    /** execute.e:2908		if SymTab[sub][S_NUM_ARGS] != length(val[b]) then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34234 = (object)*(((s1_ptr)_2)->base + _sub_68816);
    _2 = (object)SEQ_PTR(_34234);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _34235 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _34235 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _34234 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    _34236 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_SEQUENCE(_34236)){
            _34237 = SEQ_PTR(_34236)->length;
    }
    else {
        _34237 = 1;
    }
    _34236 = NOVALUE;
    if (binary_op_a(EQUALS, _34235, _34237)){
        _34235 = NOVALUE;
        _34237 = NOVALUE;
        goto L7; // [259] 314
    }
    _34235 = NOVALUE;
    _34237 = NOVALUE;

    /** execute.e:2909			RTFatal(sprintf("call to %s() via routine-id should pass %d arguments, not %d",*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34240 = (object)*(((s1_ptr)_2)->base + _sub_68816);
    _2 = (object)SEQ_PTR(_34240);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _34241 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _34241 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _34240 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34242 = (object)*(((s1_ptr)_2)->base + _sub_68816);
    _2 = (object)SEQ_PTR(_34242);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _34243 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _34243 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _34242 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    _34244 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_SEQUENCE(_34244)){
            _34245 = SEQ_PTR(_34244)->length;
    }
    else {
        _34245 = 1;
    }
    _34244 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_34241);
    ((intptr_t*)_2)[1] = _34241;
    Ref(_34243);
    ((intptr_t*)_2)[2] = _34243;
    ((intptr_t*)_2)[3] = _34245;
    _34246 = MAKE_SEQ(_1);
    _34245 = NOVALUE;
    _34243 = NOVALUE;
    _34241 = NOVALUE;
    _34247 = EPrintf(-9999999, _34239, _34246);
    DeRefDS(_34246);
    _34246 = NOVALUE;
    _67RTFatal(_34247);
    _34247 = NOVALUE;
L7: 

    /** execute.e:2914		do_call_proc( sub, val[b], 3 + cf )*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34248 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _34249 = 3LL + _cf_68814;
    if ((object)((uintptr_t)_34249 + (uintptr_t)HIGH_BITS) >= 0){
        _34249 = NewDouble((eudouble)_34249);
    }
    Ref(_34248);
    _67do_call_proc(_sub_68816, _34248, _34249);
    _34248 = NOVALUE;
    _34249 = NOVALUE;

    /** execute.e:2915	end procedure*/
    DeRef(_34215);
    _34215 = NOVALUE;
    DeRef(_34204);
    _34204 = NOVALUE;
    DeRef(_34213);
    _34213 = NOVALUE;
    DeRef(_34207);
    _34207 = NOVALUE;
    _34244 = NOVALUE;
    _34236 = NOVALUE;
    return;
    ;
}


void _67opROUTINE_ID()
{
    object _sub_68894 = NOVALUE;
    object _fn_68895 = NOVALUE;
    object _p_68896 = NOVALUE;
    object _stlen_68897 = NOVALUE;
    object _name_68898 = NOVALUE;
    object _34276 = NOVALUE;
    object _34275 = NOVALUE;
    object _34273 = NOVALUE;
    object _34271 = NOVALUE;
    object _34270 = NOVALUE;
    object _34269 = NOVALUE;
    object _34268 = NOVALUE;
    object _34267 = NOVALUE;
    object _34266 = NOVALUE;
    object _34264 = NOVALUE;
    object _34262 = NOVALUE;
    object _34259 = NOVALUE;
    object _34257 = NOVALUE;
    object _34255 = NOVALUE;
    object _34254 = NOVALUE;
    object _34252 = NOVALUE;
    object _34250 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2923		sub = Code[pc+1]   -- CurrentSub*/
    _34250 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _sub_68894 = (object)*(((s1_ptr)_2)->base + _34250);
    if (!IS_ATOM_INT(_sub_68894)){
        _sub_68894 = (object)DBL_PTR(_sub_68894)->dbl;
    }

    /** execute.e:2924		stlen = Code[pc+2]  -- s.t. length*/
    _34252 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _stlen_68897 = (object)*(((s1_ptr)_2)->base + _34252);
    if (!IS_ATOM_INT(_stlen_68897)){
        _stlen_68897 = (object)DBL_PTR(_stlen_68897)->dbl;
    }

    /** execute.e:2925		name = val[Code[pc+3]]  -- routine name sequence*/
    _34254 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _34255 = (object)*(((s1_ptr)_2)->base + _34254);
    DeRef(_name_68898);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!IS_ATOM_INT(_34255)){
        _name_68898 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34255)->dbl));
    }
    else{
        _name_68898 = (object)*(((s1_ptr)_2)->base + _34255);
    }
    Ref(_name_68898);

    /** execute.e:2926		fn = Code[pc+4]    -- file number*/
    _34257 = _67pc_64877 + 4LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _fn_68895 = (object)*(((s1_ptr)_2)->base + _34257);
    if (!IS_ATOM_INT(_fn_68895)){
        _fn_68895 = (object)DBL_PTR(_fn_68895)->dbl;
    }

    /** execute.e:2927		target = Code[pc+5]*/
    _34259 = _67pc_64877 + 5LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34259);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2928		pc += 6*/
    _67pc_64877 = _67pc_64877 + 6LL;

    /** execute.e:2929		if atom(name) then*/
    _34262 = IS_ATOM(_name_68898);
    if (_34262 == 0)
    {
        _34262 = NOVALUE;
        goto L1; // [98] 117
    }
    else{
        _34262 = NOVALUE;
    }

    /** execute.e:2930			val[target] = -1*/
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1LL;
    DeRef(_1);

    /** execute.e:2931			return*/
    DeRef(_name_68898);
    _34252 = NOVALUE;
    _34257 = NOVALUE;
    _34254 = NOVALUE;
    _34250 = NOVALUE;
    _34259 = NOVALUE;
    _34255 = NOVALUE;
    return;
L1: 

    /** execute.e:2934		p = RTLookup(name, fn, sub, stlen)*/
    Ref(_name_68898);
    _p_68896 = _67RTLookup(_name_68898, _fn_68895, _sub_68894, _stlen_68897);
    if (!IS_ATOM_INT(_p_68896)) {
        _1 = (object)(DBL_PTR(_p_68896)->dbl);
        DeRefDS(_p_68896);
        _p_68896 = _1;
    }

    /** execute.e:2935		if p = 0 or not find(SymTab[p][S_TOKEN], RTN_TOKS) then*/
    _34264 = (_p_68896 == 0LL);
    if (_34264 != 0) {
        goto L2; // [134] 165
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34266 = (object)*(((s1_ptr)_2)->base + _p_68896);
    _2 = (object)SEQ_PTR(_34266);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _34267 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _34267 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _34266 = NOVALUE;
    _34268 = find_from(_34267, _29RTN_TOKS_12006, 1LL);
    _34267 = NOVALUE;
    _34269 = (_34268 == 0);
    _34268 = NOVALUE;
    if (_34269 == 0)
    {
        DeRef(_34269);
        _34269 = NOVALUE;
        goto L3; // [161] 181
    }
    else{
        DeRef(_34269);
        _34269 = NOVALUE;
    }
L2: 

    /** execute.e:2936			val[target] = -1  -- name is not a routine*/
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1LL;
    DeRef(_1);

    /** execute.e:2937			return*/
    DeRef(_name_68898);
    DeRef(_34252);
    _34252 = NOVALUE;
    DeRef(_34257);
    _34257 = NOVALUE;
    DeRef(_34264);
    _34264 = NOVALUE;
    DeRef(_34254);
    _34254 = NOVALUE;
    DeRef(_34250);
    _34250 = NOVALUE;
    DeRef(_34259);
    _34259 = NOVALUE;
    _34255 = NOVALUE;
    return;
L3: 

    /** execute.e:2939		for i = 1 to length(e_routine) do*/
    if (IS_SEQUENCE(_67e_routine_64926)){
            _34270 = SEQ_PTR(_67e_routine_64926)->length;
    }
    else {
        _34270 = 1;
    }
    {
        object _i_68930;
        _i_68930 = 1LL;
L4: 
        if (_i_68930 > _34270){
            goto L5; // [188] 234
        }

        /** execute.e:2940			if e_routine[i] = p then*/
        _2 = (object)SEQ_PTR(_67e_routine_64926);
        _34271 = (object)*(((s1_ptr)_2)->base + _i_68930);
        if (_34271 != _p_68896)
        goto L6; // [203] 227

        /** execute.e:2941				val[target] = i - 1  -- routine was already assigned an id*/
        _34273 = _i_68930 - 1LL;
        _2 = (object)SEQ_PTR(_67val_64887);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_64887 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _34273;
        if( _1 != _34273 ){
            DeRef(_1);
        }
        _34273 = NOVALUE;

        /** execute.e:2942				return*/
        DeRef(_name_68898);
        DeRef(_34252);
        _34252 = NOVALUE;
        DeRef(_34257);
        _34257 = NOVALUE;
        DeRef(_34264);
        _34264 = NOVALUE;
        DeRef(_34254);
        _34254 = NOVALUE;
        DeRef(_34250);
        _34250 = NOVALUE;
        _34271 = NOVALUE;
        DeRef(_34259);
        _34259 = NOVALUE;
        _34255 = NOVALUE;
        return;
L6: 

        /** execute.e:2944		end for*/
        _i_68930 = _i_68930 + 1LL;
        goto L4; // [229] 195
L5: 
        ;
    }

    /** execute.e:2945		e_routine = append(e_routine, p)*/
    Append(&_67e_routine_64926, _67e_routine_64926, _p_68896);

    /** execute.e:2946		val[target] = length(e_routine) - 1*/
    if (IS_SEQUENCE(_67e_routine_64926)){
            _34275 = SEQ_PTR(_67e_routine_64926)->length;
    }
    else {
        _34275 = 1;
    }
    _34276 = _34275 - 1LL;
    _34275 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34276;
    if( _1 != _34276 ){
        DeRef(_1);
    }
    _34276 = NOVALUE;

    /** execute.e:2947	end procedure*/
    DeRef(_name_68898);
    DeRef(_34252);
    _34252 = NOVALUE;
    DeRef(_34257);
    _34257 = NOVALUE;
    DeRef(_34264);
    _34264 = NOVALUE;
    DeRef(_34254);
    _34254 = NOVALUE;
    DeRef(_34250);
    _34250 = NOVALUE;
    _34271 = NOVALUE;
    DeRef(_34259);
    _34259 = NOVALUE;
    _34255 = NOVALUE;
    return;
    ;
}


void _67opAPPEND()
{
    object _34285 = NOVALUE;
    object _34284 = NOVALUE;
    object _34283 = NOVALUE;
    object _34281 = NOVALUE;
    object _34279 = NOVALUE;
    object _34277 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2950		a = Code[pc+1]*/
    _34277 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34277);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2951		b = Code[pc+2]*/
    _34279 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34279);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2952		target = Code[pc+3]*/
    _34281 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34281);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2953		val[target] = append(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34283 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34284 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    Ref(_34284);
    Append(&_34285, _34283, _34284);
    _34283 = NOVALUE;
    _34284 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34285;
    if( _1 != _34285 ){
        DeRef(_1);
    }
    _34285 = NOVALUE;

    /** execute.e:2954		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:2955	end procedure*/
    _34281 = NOVALUE;
    _34279 = NOVALUE;
    _34277 = NOVALUE;
    return;
    ;
}


void _67opPREPEND()
{
    object _34295 = NOVALUE;
    object _34294 = NOVALUE;
    object _34293 = NOVALUE;
    object _34291 = NOVALUE;
    object _34289 = NOVALUE;
    object _34287 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2958		a = Code[pc+1]*/
    _34287 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34287);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2959		b = Code[pc+2]*/
    _34289 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34289);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2960		target = Code[pc+3]*/
    _34291 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34291);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2961		val[target] = prepend(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34293 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34294 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    Ref(_34294);
    Prepend(&_34295, _34293, _34294);
    _34293 = NOVALUE;
    _34294 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34295;
    if( _1 != _34295 ){
        DeRef(_1);
    }
    _34295 = NOVALUE;

    /** execute.e:2962		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:2963	end procedure*/
    _34289 = NOVALUE;
    _34287 = NOVALUE;
    _34291 = NOVALUE;
    return;
    ;
}


void _67opCONCAT()
{
    object _34305 = NOVALUE;
    object _34304 = NOVALUE;
    object _34303 = NOVALUE;
    object _34301 = NOVALUE;
    object _34299 = NOVALUE;
    object _34297 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2966		a = Code[pc+1]*/
    _34297 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34297);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2967		b = Code[pc+2]*/
    _34299 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34299);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2968		target = Code[pc+3]*/
    _34301 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34301);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2969		val[target] = val[a] & val[b]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34303 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34304 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_SEQUENCE(_34303) && IS_ATOM(_34304)) {
        Ref(_34304);
        Append(&_34305, _34303, _34304);
    }
    else if (IS_ATOM(_34303) && IS_SEQUENCE(_34304)) {
        Ref(_34303);
        Prepend(&_34305, _34304, _34303);
    }
    else {
        Concat((object_ptr)&_34305, _34303, _34304);
        _34303 = NOVALUE;
    }
    _34303 = NOVALUE;
    _34304 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34305;
    if( _1 != _34305 ){
        DeRef(_1);
    }
    _34305 = NOVALUE;

    /** execute.e:2970		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:2971	end procedure*/
    _34297 = NOVALUE;
    _34301 = NOVALUE;
    _34299 = NOVALUE;
    return;
    ;
}


void _67opCONCAT_N()
{
    object _n_68986 = NOVALUE;
    object _x_68987 = NOVALUE;
    object _34321 = NOVALUE;
    object _34319 = NOVALUE;
    object _34318 = NOVALUE;
    object _34316 = NOVALUE;
    object _34315 = NOVALUE;
    object _34314 = NOVALUE;
    object _34313 = NOVALUE;
    object _34312 = NOVALUE;
    object _34310 = NOVALUE;
    object _34309 = NOVALUE;
    object _34307 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2978		n = Code[pc+1] -- number of items*/
    _34307 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _n_68986 = (object)*(((s1_ptr)_2)->base + _34307);
    if (!IS_ATOM_INT(_n_68986)){
        _n_68986 = (object)DBL_PTR(_n_68986)->dbl;
    }

    /** execute.e:2980		x = val[Code[pc+2]] -- last one*/
    _34309 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _34310 = (object)*(((s1_ptr)_2)->base + _34309);
    DeRef(_x_68987);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!IS_ATOM_INT(_34310)){
        _x_68987 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34310)->dbl));
    }
    else{
        _x_68987 = (object)*(((s1_ptr)_2)->base + _34310);
    }
    Ref(_x_68987);

    /** execute.e:2981		for i = pc+3 to pc+n+1 do*/
    _34312 = _67pc_64877 + 3LL;
    if ((object)((uintptr_t)_34312 + (uintptr_t)HIGH_BITS) >= 0){
        _34312 = NewDouble((eudouble)_34312);
    }
    _34313 = _67pc_64877 + _n_68986;
    if ((object)((uintptr_t)_34313 + (uintptr_t)HIGH_BITS) >= 0){
        _34313 = NewDouble((eudouble)_34313);
    }
    if (IS_ATOM_INT(_34313)) {
        _34314 = _34313 + 1;
        if (_34314 > MAXINT){
            _34314 = NewDouble((eudouble)_34314);
        }
    }
    else
    _34314 = binary_op(PLUS, 1, _34313);
    DeRef(_34313);
    _34313 = NOVALUE;
    {
        object _i_68996;
        Ref(_34312);
        _i_68996 = _34312;
L1: 
        if (binary_op_a(GREATER, _i_68996, _34314)){
            goto L2; // [55] 87
        }

        /** execute.e:2982			x = val[Code[i]] & x*/
        _2 = (object)SEQ_PTR(_12Code_20315);
        if (!IS_ATOM_INT(_i_68996)){
            _34315 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_68996)->dbl));
        }
        else{
            _34315 = (object)*(((s1_ptr)_2)->base + _i_68996);
        }
        _2 = (object)SEQ_PTR(_67val_64887);
        if (!IS_ATOM_INT(_34315)){
            _34316 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34315)->dbl));
        }
        else{
            _34316 = (object)*(((s1_ptr)_2)->base + _34315);
        }
        if (IS_SEQUENCE(_34316) && IS_ATOM(_x_68987)) {
            Ref(_x_68987);
            Append(&_x_68987, _34316, _x_68987);
        }
        else if (IS_ATOM(_34316) && IS_SEQUENCE(_x_68987)) {
            Ref(_34316);
            Prepend(&_x_68987, _x_68987, _34316);
        }
        else {
            Concat((object_ptr)&_x_68987, _34316, _x_68987);
            _34316 = NOVALUE;
        }
        _34316 = NOVALUE;

        /** execute.e:2983		end for*/
        _0 = _i_68996;
        if (IS_ATOM_INT(_i_68996)) {
            _i_68996 = _i_68996 + 1LL;
            if ((object)((uintptr_t)_i_68996 +(uintptr_t) HIGH_BITS) >= 0){
                _i_68996 = NewDouble((eudouble)_i_68996);
            }
        }
        else {
            _i_68996 = binary_op_a(PLUS, _i_68996, 1LL);
        }
        DeRef(_0);
        goto L1; // [82] 62
L2: 
        ;
        DeRef(_i_68996);
    }

    /** execute.e:2984		target = Code[pc+n+2]*/
    _34318 = _67pc_64877 + _n_68986;
    if ((object)((uintptr_t)_34318 + (uintptr_t)HIGH_BITS) >= 0){
        _34318 = NewDouble((eudouble)_34318);
    }
    if (IS_ATOM_INT(_34318)) {
        _34319 = _34318 + 2LL;
    }
    else {
        _34319 = NewDouble(DBL_PTR(_34318)->dbl + (eudouble)2LL);
    }
    DeRef(_34318);
    _34318 = NOVALUE;
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!IS_ATOM_INT(_34319)){
        _67target_64882 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34319)->dbl));
    }
    else{
        _67target_64882 = (object)*(((s1_ptr)_2)->base + _34319);
    }
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2985		val[target] = x*/
    Ref(_x_68987);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _x_68987;
    DeRef(_1);

    /** execute.e:2986		pc += n+3*/
    _34321 = _n_68986 + 3LL;
    if ((object)((uintptr_t)_34321 + (uintptr_t)HIGH_BITS) >= 0){
        _34321 = NewDouble((eudouble)_34321);
    }
    if (IS_ATOM_INT(_34321)) {
        _67pc_64877 = _67pc_64877 + _34321;
    }
    else {
        _67pc_64877 = NewDouble((eudouble)_67pc_64877 + DBL_PTR(_34321)->dbl);
    }
    DeRef(_34321);
    _34321 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_64877)) {
        _1 = (object)(DBL_PTR(_67pc_64877)->dbl);
        DeRefDS(_67pc_64877);
        _67pc_64877 = _1;
    }

    /** execute.e:2987	end procedure*/
    DeRef(_x_68987);
    _34310 = NOVALUE;
    DeRef(_34312);
    _34312 = NOVALUE;
    _34315 = NOVALUE;
    DeRef(_34319);
    _34319 = NOVALUE;
    DeRef(_34314);
    _34314 = NOVALUE;
    DeRef(_34309);
    _34309 = NOVALUE;
    DeRef(_34307);
    _34307 = NOVALUE;
    return;
    ;
}


void _67opREPEAT()
{
    object _34341 = NOVALUE;
    object _34340 = NOVALUE;
    object _34339 = NOVALUE;
    object _34336 = NOVALUE;
    object _34333 = NOVALUE;
    object _34330 = NOVALUE;
    object _34329 = NOVALUE;
    object _34327 = NOVALUE;
    object _34325 = NOVALUE;
    object _34323 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2990		a = Code[pc+1]*/
    _34323 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34323);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:2991		b = Code[pc+2]*/
    _34325 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34325);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:2992		target = Code[pc+3]*/
    _34327 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34327);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:2993		if not atom(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34329 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _34330 = IS_ATOM(_34329);
    _34329 = NOVALUE;
    if (_34330 != 0)
    goto L1; // [62] 71
    _34330 = NOVALUE;

    /** execute.e:2994			RTFatal("repetition count must be an atom")*/
    RefDS(_34332);
    _67RTFatal(_34332);
L1: 

    /** execute.e:2996		if val[b] < 0 then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34333 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (binary_op_a(GREATEREQ, _34333, 0LL)){
        _34333 = NOVALUE;
        goto L2; // [81] 91
    }
    _34333 = NOVALUE;

    /** execute.e:2997			RTFatal("repetition count must not be negative")*/
    RefDS(_34335);
    _67RTFatal(_34335);
L2: 

    /** execute.e:2999		if val[b] > 1073741823 then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34336 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (binary_op_a(LESSEQ, _34336, 1073741823LL)){
        _34336 = NOVALUE;
        goto L3; // [101] 111
    }
    _34336 = NOVALUE;

    /** execute.e:3000			RTFatal("repetition count is too large")*/
    RefDS(_34338);
    _67RTFatal(_34338);
L3: 

    /** execute.e:3002		val[target] = repeat(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34339 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34340 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _34341 = Repeat(_34339, _34340);
    _34339 = NOVALUE;
    _34340 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34341;
    if( _1 != _34341 ){
        DeRef(_1);
    }
    _34341 = NOVALUE;

    /** execute.e:3003		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:3004	end procedure*/
    DeRef(_34327);
    _34327 = NOVALUE;
    DeRef(_34325);
    _34325 = NOVALUE;
    DeRef(_34323);
    _34323 = NOVALUE;
    return;
    ;
}


void _67opDATE()
{
    object _34345 = NOVALUE;
    object _34343 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3007		target = Code[pc+1]*/
    _34343 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34343);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3008		val[target] = date()*/
    _34345 = Date();
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34345;
    if( _1 != _34345 ){
        DeRef(_1);
    }
    _34345 = NOVALUE;

    /** execute.e:3009		pc += 2*/
    _67pc_64877 = _67pc_64877 + 2LL;

    /** execute.e:3010	end procedure*/
    _34343 = NOVALUE;
    return;
    ;
}


void _67opTIME()
{
    object _34349 = NOVALUE;
    object _34347 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3013		target = Code[pc+1]*/
    _34347 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34347);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3014		val[target] = time()*/
    _34349 = NewDouble(current_time());
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34349;
    if( _1 != _34349 ){
        DeRef(_1);
    }
    _34349 = NOVALUE;

    /** execute.e:3015		pc += 2*/
    _67pc_64877 = _67pc_64877 + 2LL;

    /** execute.e:3016	end procedure*/
    _34347 = NOVALUE;
    return;
    ;
}


void _67opSPACE_USED()
{
    object _0, _1, _2;
    

    /** execute.e:3019		pc += 2*/
    _67pc_64877 = _67pc_64877 + 2LL;

    /** execute.e:3020	end procedure*/
    return;
    ;
}


void _67opNOP2()
{
    object _0, _1, _2;
    

    /** execute.e:3024		pc+= 2*/
    _67pc_64877 = _67pc_64877 + 2LL;

    /** execute.e:3025	end procedure*/
    return;
    ;
}


void _67opPOSITION()
{
    object _34358 = NOVALUE;
    object _34357 = NOVALUE;
    object _34355 = NOVALUE;
    object _34353 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3028		a = Code[pc+1]*/
    _34353 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34353);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3029		b = Code[pc+2]*/
    _34355 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34355);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:3030		position(val[a], val[b])  -- error checks*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34357 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34358 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    Position(_34357, _34358);
    _34357 = NOVALUE;
    _34358 = NOVALUE;

    /** execute.e:3031		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:3032	end procedure*/
    _34353 = NOVALUE;
    _34355 = NOVALUE;
    return;
    ;
}


void _67opEQUAL()
{
    object _34368 = NOVALUE;
    object _34367 = NOVALUE;
    object _34366 = NOVALUE;
    object _34364 = NOVALUE;
    object _34362 = NOVALUE;
    object _34360 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3035		a = Code[pc+1]*/
    _34360 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34360);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3036		b = Code[pc+2]*/
    _34362 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34362);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:3037		target = Code[pc+3]*/
    _34364 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34364);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3038		val[target] = equal(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34366 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34367 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (_34366 == _34367)
    _34368 = 1;
    else if (IS_ATOM_INT(_34366) && IS_ATOM_INT(_34367))
    _34368 = 0;
    else
    _34368 = (compare(_34366, _34367) == 0);
    _34366 = NOVALUE;
    _34367 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34368;
    if( _1 != _34368 ){
        DeRef(_1);
    }
    _34368 = NOVALUE;

    /** execute.e:3039		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:3040	end procedure*/
    _34362 = NOVALUE;
    _34364 = NOVALUE;
    _34360 = NOVALUE;
    return;
    ;
}


void _67opHASH()
{
    object _34378 = NOVALUE;
    object _34377 = NOVALUE;
    object _34376 = NOVALUE;
    object _34374 = NOVALUE;
    object _34372 = NOVALUE;
    object _34370 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3043		a = Code[pc+1]*/
    _34370 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34370);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3044		b = Code[pc+2]*/
    _34372 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34372);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:3045		target = Code[pc+3]*/
    _34374 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34374);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3046		val[target] = hash(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34376 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34377 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _34378 = calc_hash(_34376, _34377);
    _34376 = NOVALUE;
    _34377 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34378;
    if( _1 != _34378 ){
        DeRef(_1);
    }
    _34378 = NOVALUE;

    /** execute.e:3047		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:3048	end procedure*/
    _34372 = NOVALUE;
    _34370 = NOVALUE;
    _34374 = NOVALUE;
    return;
    ;
}


void _67opCOMPARE()
{
    object _34388 = NOVALUE;
    object _34387 = NOVALUE;
    object _34386 = NOVALUE;
    object _34384 = NOVALUE;
    object _34382 = NOVALUE;
    object _34380 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3051		a = Code[pc+1]*/
    _34380 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34380);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3052		b = Code[pc+2]*/
    _34382 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34382);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:3053		target = Code[pc+3]*/
    _34384 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34384);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3054		val[target] = compare(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34386 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34387 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_ATOM_INT(_34386) && IS_ATOM_INT(_34387)){
        _34388 = (_34386 < _34387) ? -1 : (_34386 > _34387);
    }
    else{
        _34388 = compare(_34386, _34387);
    }
    _34386 = NOVALUE;
    _34387 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34388;
    if( _1 != _34388 ){
        DeRef(_1);
    }
    _34388 = NOVALUE;

    /** execute.e:3055		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:3056	end procedure*/
    _34382 = NOVALUE;
    _34384 = NOVALUE;
    _34380 = NOVALUE;
    return;
    ;
}


void _67opFIND()
{
    object _34402 = NOVALUE;
    object _34401 = NOVALUE;
    object _34400 = NOVALUE;
    object _34397 = NOVALUE;
    object _34396 = NOVALUE;
    object _34394 = NOVALUE;
    object _34392 = NOVALUE;
    object _34390 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3059		a = Code[pc+1]*/
    _34390 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34390);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3060		b = Code[pc+2]*/
    _34392 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34392);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:3061		target = Code[pc+3]*/
    _34394 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34394);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3062		if not sequence(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34396 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _34397 = IS_SEQUENCE(_34396);
    _34396 = NOVALUE;
    if (_34397 != 0)
    goto L1; // [62] 71
    _34397 = NOVALUE;

    /** execute.e:3063			RTFatal("second argument of find() must be a sequence")*/
    RefDS(_34399);
    _67RTFatal(_34399);
L1: 

    /** execute.e:3065		val[target] = find(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34400 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34401 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _34402 = find_from(_34400, _34401, 1LL);
    _34400 = NOVALUE;
    _34401 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34402;
    if( _1 != _34402 ){
        DeRef(_1);
    }
    _34402 = NOVALUE;

    /** execute.e:3066		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:3067	end procedure*/
    DeRef(_34394);
    _34394 = NOVALUE;
    DeRef(_34390);
    _34390 = NOVALUE;
    DeRef(_34392);
    _34392 = NOVALUE;
    return;
    ;
}


void _67opMATCH()
{
    object _34424 = NOVALUE;
    object _34423 = NOVALUE;
    object _34422 = NOVALUE;
    object _34419 = NOVALUE;
    object _34418 = NOVALUE;
    object _34415 = NOVALUE;
    object _34414 = NOVALUE;
    object _34411 = NOVALUE;
    object _34410 = NOVALUE;
    object _34408 = NOVALUE;
    object _34406 = NOVALUE;
    object _34404 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3070		a = Code[pc+1]*/
    _34404 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34404);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3071		b = Code[pc+2]*/
    _34406 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34406);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:3072		target = Code[pc+3]*/
    _34408 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34408);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3073		if not sequence(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34410 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _34411 = IS_SEQUENCE(_34410);
    _34410 = NOVALUE;
    if (_34411 != 0)
    goto L1; // [62] 71
    _34411 = NOVALUE;

    /** execute.e:3074			RTFatal("first argument of match() must be a sequence")*/
    RefDS(_34413);
    _67RTFatal(_34413);
L1: 

    /** execute.e:3076		if not sequence(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34414 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _34415 = IS_SEQUENCE(_34414);
    _34414 = NOVALUE;
    if (_34415 != 0)
    goto L2; // [84] 93
    _34415 = NOVALUE;

    /** execute.e:3077			RTFatal("second argument of match() must be a sequence")*/
    RefDS(_34417);
    _67RTFatal(_34417);
L2: 

    /** execute.e:3079		if length(val[a]) = 0 then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34418 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_SEQUENCE(_34418)){
            _34419 = SEQ_PTR(_34418)->length;
    }
    else {
        _34419 = 1;
    }
    _34418 = NOVALUE;
    if (_34419 != 0LL)
    goto L3; // [106] 116

    /** execute.e:3080			 RTFatal("first argument of match() must be a non-empty sequence")*/
    RefDS(_34421);
    _67RTFatal(_34421);
L3: 

    /** execute.e:3082		val[target] = match(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34422 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34423 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _34424 = e_match_from(_34422, _34423, 1LL);
    _34422 = NOVALUE;
    _34423 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34424;
    if( _1 != _34424 ){
        DeRef(_1);
    }
    _34424 = NOVALUE;

    /** execute.e:3083		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:3084	end procedure*/
    DeRef(_34404);
    _34404 = NOVALUE;
    DeRef(_34406);
    _34406 = NOVALUE;
    _34418 = NOVALUE;
    DeRef(_34408);
    _34408 = NOVALUE;
    return;
    ;
}


void _67opFIND_FROM()
{
    object _s_69166 = NOVALUE;
    object _34447 = NOVALUE;
    object _34445 = NOVALUE;
    object _34444 = NOVALUE;
    object _34443 = NOVALUE;
    object _34441 = NOVALUE;
    object _34440 = NOVALUE;
    object _34439 = NOVALUE;
    object _34438 = NOVALUE;
    object _34434 = NOVALUE;
    object _34433 = NOVALUE;
    object _34432 = NOVALUE;
    object _34431 = NOVALUE;
    object _34429 = NOVALUE;
    object _34427 = NOVALUE;
    object _34426 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3089			c = val[Code[pc+3]]*/
    _34426 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _34427 = (object)*(((s1_ptr)_2)->base + _34426);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!IS_ATOM_INT(_34427)){
        _67c_64880 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34427)->dbl));
    }
    else{
        _67c_64880 = (object)*(((s1_ptr)_2)->base + _34427);
    }
    if (!IS_ATOM_INT(_67c_64880))
    _67c_64880 = (object)DBL_PTR(_67c_64880)->dbl;

    /** execute.e:3090			target = Code[pc+4]*/
    _34429 = _67pc_64877 + 4LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34429);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3091			if not sequence(val[Code[pc+2]]) then*/
    _34431 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _34432 = (object)*(((s1_ptr)_2)->base + _34431);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!IS_ATOM_INT(_34432)){
        _34433 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34432)->dbl));
    }
    else{
        _34433 = (object)*(((s1_ptr)_2)->base + _34432);
    }
    _34434 = IS_SEQUENCE(_34433);
    _34433 = NOVALUE;
    if (_34434 != 0)
    goto L1; // [60] 82
    _34434 = NOVALUE;

    /** execute.e:3092					RTFatal("second argument of find_from() must be a sequence")*/
    RefDS(_34436);
    _67RTFatal(_34436);

    /** execute.e:3093					pc += 5*/
    _67pc_64877 = _67pc_64877 + 5LL;

    /** execute.e:3094					return*/
    DeRef(_s_69166);
    _34432 = NOVALUE;
    _34426 = NOVALUE;
    _34431 = NOVALUE;
    _34427 = NOVALUE;
    _34429 = NOVALUE;
    return;
L1: 

    /** execute.e:3096			s = val[Code[pc+2]][c..$]*/
    _34438 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _34439 = (object)*(((s1_ptr)_2)->base + _34438);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!IS_ATOM_INT(_34439)){
        _34440 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34439)->dbl));
    }
    else{
        _34440 = (object)*(((s1_ptr)_2)->base + _34439);
    }
    if (IS_SEQUENCE(_34440)){
            _34441 = SEQ_PTR(_34440)->length;
    }
    else {
        _34441 = 1;
    }
    rhs_slice_target = (object_ptr)&_s_69166;
    RHS_Slice(_34440, _67c_64880, _34441);
    _34440 = NOVALUE;

    /** execute.e:3097			b = find( val[Code[pc+1]], s )*/
    _34443 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _34444 = (object)*(((s1_ptr)_2)->base + _34443);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!IS_ATOM_INT(_34444)){
        _34445 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34444)->dbl));
    }
    else{
        _34445 = (object)*(((s1_ptr)_2)->base + _34444);
    }
    _67b_64879 = find_from(_34445, _s_69166, 1LL);
    _34445 = NOVALUE;

    /** execute.e:3098			if b then*/
    if (_67b_64879 == 0)
    {
        goto L2; // [141] 161
    }
    else{
    }

    /** execute.e:3099					b += c - 1*/
    _34447 = _67c_64880 - 1LL;
    if ((object)((uintptr_t)_34447 +(uintptr_t) HIGH_BITS) >= 0){
        _34447 = NewDouble((eudouble)_34447);
    }
    if (IS_ATOM_INT(_34447)) {
        _67b_64879 = _67b_64879 + _34447;
    }
    else {
        _67b_64879 = NewDouble((eudouble)_67b_64879 + DBL_PTR(_34447)->dbl);
    }
    DeRef(_34447);
    _34447 = NOVALUE;
    if (!IS_ATOM_INT(_67b_64879)) {
        _1 = (object)(DBL_PTR(_67b_64879)->dbl);
        DeRefDS(_67b_64879);
        _67b_64879 = _1;
    }
L2: 

    /** execute.e:3101			val[target] = b*/
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67b_64879;
    DeRef(_1);

    /** execute.e:3102			pc += 5*/
    _67pc_64877 = _67pc_64877 + 5LL;

    /** execute.e:3103	end procedure*/
    DeRef(_s_69166);
    DeRef(_34443);
    _34443 = NOVALUE;
    _34432 = NOVALUE;
    _34444 = NOVALUE;
    DeRef(_34426);
    _34426 = NOVALUE;
    DeRef(_34431);
    _34431 = NOVALUE;
    _34427 = NOVALUE;
    DeRef(_34438);
    _34438 = NOVALUE;
    _34439 = NOVALUE;
    DeRef(_34429);
    _34429 = NOVALUE;
    return;
    ;
}


void _67opMATCH_FROM()
{
    object _s_69200 = NOVALUE;
    object _34490 = NOVALUE;
    object _34489 = NOVALUE;
    object _34487 = NOVALUE;
    object _34486 = NOVALUE;
    object _34485 = NOVALUE;
    object _34484 = NOVALUE;
    object _34483 = NOVALUE;
    object _34482 = NOVALUE;
    object _34481 = NOVALUE;
    object _34480 = NOVALUE;
    object _34479 = NOVALUE;
    object _34478 = NOVALUE;
    object _34476 = NOVALUE;
    object _34470 = NOVALUE;
    object _34466 = NOVALUE;
    object _34465 = NOVALUE;
    object _34461 = NOVALUE;
    object _34460 = NOVALUE;
    object _34458 = NOVALUE;
    object _34456 = NOVALUE;
    object _34455 = NOVALUE;
    object _34453 = NOVALUE;
    object _34451 = NOVALUE;
    object _34450 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3108			c = val[Code[pc+3]]*/
    _34450 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _34451 = (object)*(((s1_ptr)_2)->base + _34450);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!IS_ATOM_INT(_34451)){
        _67c_64880 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34451)->dbl));
    }
    else{
        _67c_64880 = (object)*(((s1_ptr)_2)->base + _34451);
    }
    if (!IS_ATOM_INT(_67c_64880))
    _67c_64880 = (object)DBL_PTR(_67c_64880)->dbl;

    /** execute.e:3109			target = Code[pc+4]*/
    _34453 = _67pc_64877 + 4LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34453);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3110			s = val[Code[pc+2]]*/
    _34455 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _34456 = (object)*(((s1_ptr)_2)->base + _34455);
    DeRef(_s_69200);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!IS_ATOM_INT(_34456)){
        _s_69200 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34456)->dbl));
    }
    else{
        _s_69200 = (object)*(((s1_ptr)_2)->base + _34456);
    }
    Ref(_s_69200);

    /** execute.e:3111			a = Code[pc+1]*/
    _34458 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34458);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3112			if not sequence(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34460 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _34461 = IS_SEQUENCE(_34460);
    _34460 = NOVALUE;
    if (_34461 != 0)
    goto L1; // [86] 108
    _34461 = NOVALUE;

    /** execute.e:3113					RTFatal("first argument of match_from() must be a sequence")*/
    RefDS(_34463);
    _67RTFatal(_34463);

    /** execute.e:3114					pc += 5*/
    _67pc_64877 = _67pc_64877 + 5LL;

    /** execute.e:3115					return*/
    DeRef(_s_69200);
    _34458 = NOVALUE;
    _34456 = NOVALUE;
    _34450 = NOVALUE;
    _34451 = NOVALUE;
    _34453 = NOVALUE;
    _34455 = NOVALUE;
    return;
L1: 

    /** execute.e:3117			if length(val[a]) = 0 then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34465 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_SEQUENCE(_34465)){
            _34466 = SEQ_PTR(_34465)->length;
    }
    else {
        _34466 = 1;
    }
    _34465 = NOVALUE;
    if (_34466 != 0LL)
    goto L2; // [121] 144

    /** execute.e:3118					RTFatal("first argument of match_from() must be a non-empty sequence")*/
    RefDS(_34468);
    _67RTFatal(_34468);

    /** execute.e:3119					pc += 5*/
    _67pc_64877 = _67pc_64877 + 5LL;

    /** execute.e:3120					return*/
    DeRef(_s_69200);
    DeRef(_34458);
    _34458 = NOVALUE;
    _34465 = NOVALUE;
    _34456 = NOVALUE;
    DeRef(_34450);
    _34450 = NOVALUE;
    _34451 = NOVALUE;
    DeRef(_34453);
    _34453 = NOVALUE;
    DeRef(_34455);
    _34455 = NOVALUE;
    return;
L2: 

    /** execute.e:3122			if not sequence(s) then*/
    _34470 = IS_SEQUENCE(_s_69200);
    if (_34470 != 0)
    goto L3; // [149] 171
    _34470 = NOVALUE;

    /** execute.e:3123					RTFatal("second argument of match_from() must be a sequence")*/
    RefDS(_34472);
    _67RTFatal(_34472);

    /** execute.e:3124					pc += 5*/
    _67pc_64877 = _67pc_64877 + 5LL;

    /** execute.e:3125					return*/
    DeRef(_s_69200);
    DeRef(_34458);
    _34458 = NOVALUE;
    _34465 = NOVALUE;
    _34456 = NOVALUE;
    DeRef(_34450);
    _34450 = NOVALUE;
    _34451 = NOVALUE;
    DeRef(_34453);
    _34453 = NOVALUE;
    DeRef(_34455);
    _34455 = NOVALUE;
    return;
L3: 

    /** execute.e:3127			if c < 1 then*/
    if (_67c_64880 >= 1LL)
    goto L4; // [175] 204

    /** execute.e:3128					RTFatal(sprintf("index (%d) out of bounds in match_from()", c ))*/
    _34476 = EPrintf(-9999999, _34475, _67c_64880);
    _67RTFatal(_34476);
    _34476 = NOVALUE;

    /** execute.e:3129					pc += 5*/
    _67pc_64877 = _67pc_64877 + 5LL;

    /** execute.e:3130					return*/
    DeRef(_s_69200);
    DeRef(_34458);
    _34458 = NOVALUE;
    _34465 = NOVALUE;
    _34456 = NOVALUE;
    DeRef(_34450);
    _34450 = NOVALUE;
    _34451 = NOVALUE;
    DeRef(_34453);
    _34453 = NOVALUE;
    DeRef(_34455);
    _34455 = NOVALUE;
    return;
L4: 

    /** execute.e:3132			if not (length(s) = 0 and c = 1) and c > length(s) + 1 then*/
    if (IS_SEQUENCE(_s_69200)){
            _34478 = SEQ_PTR(_s_69200)->length;
    }
    else {
        _34478 = 1;
    }
    _34479 = (_34478 == 0LL);
    _34478 = NOVALUE;
    if (_34479 == 0) {
        DeRef(_34480);
        _34480 = 0;
        goto L5; // [213] 227
    }
    _34481 = (_67c_64880 == 1LL);
    _34480 = (_34481 != 0);
L5: 
    _34482 = (_34480 == 0);
    _34480 = NOVALUE;
    if (_34482 == 0) {
        goto L6; // [230] 276
    }
    if (IS_SEQUENCE(_s_69200)){
            _34484 = SEQ_PTR(_s_69200)->length;
    }
    else {
        _34484 = 1;
    }
    _34485 = _34484 + 1;
    _34484 = NOVALUE;
    _34486 = (_67c_64880 > _34485);
    _34485 = NOVALUE;
    if (_34486 == 0)
    {
        DeRef(_34486);
        _34486 = NOVALUE;
        goto L6; // [248] 276
    }
    else{
        DeRef(_34486);
        _34486 = NOVALUE;
    }

    /** execute.e:3133					RTFatal(sprintf("index (%d) out of bounds in match_from()", c ))*/
    _34487 = EPrintf(-9999999, _34475, _67c_64880);
    _67RTFatal(_34487);
    _34487 = NOVALUE;

    /** execute.e:3134					pc += 5*/
    _67pc_64877 = _67pc_64877 + 5LL;

    /** execute.e:3135					return*/
    DeRef(_s_69200);
    DeRef(_34479);
    _34479 = NOVALUE;
    DeRef(_34458);
    _34458 = NOVALUE;
    DeRef(_34481);
    _34481 = NOVALUE;
    _34465 = NOVALUE;
    DeRef(_34482);
    _34482 = NOVALUE;
    _34456 = NOVALUE;
    DeRef(_34450);
    _34450 = NOVALUE;
    _34451 = NOVALUE;
    DeRef(_34453);
    _34453 = NOVALUE;
    DeRef(_34455);
    _34455 = NOVALUE;
    return;
L6: 

    /** execute.e:3137			val[target] = match( val[a], s, c )*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34489 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _34490 = e_match_from(_34489, _s_69200, _67c_64880);
    _34489 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34490;
    if( _1 != _34490 ){
        DeRef(_1);
    }
    _34490 = NOVALUE;

    /** execute.e:3138			pc += 5*/
    _67pc_64877 = _67pc_64877 + 5LL;

    /** execute.e:3139	end procedure*/
    DeRef(_s_69200);
    DeRef(_34479);
    _34479 = NOVALUE;
    DeRef(_34458);
    _34458 = NOVALUE;
    DeRef(_34481);
    _34481 = NOVALUE;
    _34465 = NOVALUE;
    DeRef(_34482);
    _34482 = NOVALUE;
    _34456 = NOVALUE;
    DeRef(_34450);
    _34450 = NOVALUE;
    _34451 = NOVALUE;
    DeRef(_34453);
    _34453 = NOVALUE;
    DeRef(_34455);
    _34455 = NOVALUE;
    return;
    ;
}


void _67opPEEK2U()
{
    object _34497 = NOVALUE;
    object _34496 = NOVALUE;
    object _34494 = NOVALUE;
    object _34492 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3142		a = Code[pc+1]*/
    _34492 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34492);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3143		target = Code[pc+2]*/
    _34494 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34494);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3144		val[target] = peek2u(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34496 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_ATOM_INT(_34496)) {
        _34497 = *(uint16_t *)_34496;
    }
    else if (IS_ATOM(_34496)) {
        _34497 = *(uint16_t *)(uintptr_t)(DBL_PTR(_34496)->dbl);
    }
    else {
        _1 = (object)SEQ_PTR(_34496);
        peek2_addr = (uint16_t *)get_pos_int("peek2s/peek2u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _34497 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)*peek2_addr++;
        }
    }
    _34496 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34497;
    if( _1 != _34497 ){
        DeRef(_1);
    }
    _34497 = NOVALUE;

    /** execute.e:3145		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:3146	end procedure*/
    _34494 = NOVALUE;
    _34492 = NOVALUE;
    return;
    ;
}


void _67opPEEK2S()
{
    object _34504 = NOVALUE;
    object _34503 = NOVALUE;
    object _34501 = NOVALUE;
    object _34499 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3149		a = Code[pc+1]*/
    _34499 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34499);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3150		target = Code[pc+2]*/
    _34501 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34501);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3151		val[target] = peek2s(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34503 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_ATOM_INT(_34503)) {
        _34504 = *(int16_t *)_34503;
    }
    else if (IS_ATOM(_34503)) {
        _34504 = *(int16_t *)(uintptr_t)(DBL_PTR(_34503)->dbl);
    }
    else {
        _1 = (object)SEQ_PTR(_34503);
        peek2_addr = (uint16_t *)get_pos_int("peek2s/peek2u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _34504 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)(int16_t)*peek2_addr++;
        }
    }
    _34503 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34504;
    if( _1 != _34504 ){
        DeRef(_1);
    }
    _34504 = NOVALUE;

    /** execute.e:3152		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:3153	end procedure*/
    _34501 = NOVALUE;
    _34499 = NOVALUE;
    return;
    ;
}


void _67opPEEK4U()
{
    object _34511 = NOVALUE;
    object _34510 = NOVALUE;
    object _34508 = NOVALUE;
    object _34506 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3156		a = Code[pc+1]*/
    _34506 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34506);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3157		target = Code[pc+2]*/
    _34508 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34508);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3158		val[target] = peek4u(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34510 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_ATOM_INT(_34510)) {
        _34511 = (object)*(uint32_t *)_34510;
        if ((uintptr_t)_34511 > (uintptr_t)MAXINT){
            _34511 = NewDouble((eudouble)(uintptr_t)_34511);
        }
    }
    else if (IS_ATOM(_34510)) {
        _34511 = (object)*(uint32_t *)(uintptr_t)(DBL_PTR(_34510)->dbl);
        if ((uintptr_t)_34511 > (uintptr_t)MAXINT){
            _34511 = NewDouble((eudouble)(uintptr_t)_34511);
        }
    }
    else {
        _1 = (object)SEQ_PTR(_34510);
        peek4_addr = (uint32_t *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _34511 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            _1 = (object)*peek4_addr++;
            if ((uintptr_t)_1 > (uintptr_t)MAXINT){
                _1 = NewDouble((eudouble)(uintptr_t)_1);
            }
            *pokeptr_addr = _1;
        }
    }
    _34510 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34511;
    if( _1 != _34511 ){
        DeRef(_1);
    }
    _34511 = NOVALUE;

    /** execute.e:3159		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:3160	end procedure*/
    _34506 = NOVALUE;
    _34508 = NOVALUE;
    return;
    ;
}


void _67opPEEK4S()
{
    object _34518 = NOVALUE;
    object _34517 = NOVALUE;
    object _34515 = NOVALUE;
    object _34513 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3163		a = Code[pc+1]*/
    _34513 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34513);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3164		target = Code[pc+2]*/
    _34515 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34515);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3165		val[target] = peek4s(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34517 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_ATOM_INT(_34517)) {
        _34518 = (object)*(int32_t *)_34517;
        if (_34518 < MININT || _34518 > MAXINT){
            _34518 = NewDouble((eudouble)(object)_34518);
        }
    }
    else if (IS_ATOM(_34517)) {
        _34518 = (object)*(int32_t *)(uintptr_t)(DBL_PTR(_34517)->dbl);
        if (_34518 < MININT || _34518 > MAXINT){
            _34518 = NewDouble((eudouble)(object)_34518);
        }
    }
    else {
        _1 = (object)SEQ_PTR(_34517);
        peek4_addr = (uint32_t *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _34518 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            _1 = (object)(int32_t)*peek4_addr++;
            if (_1 < MININT || _1 > MAXINT){
                _1 = NewDouble((eudouble)_1);
            }
            *pokeptr_addr = _1;
        }
    }
    _34517 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34518;
    if( _1 != _34518 ){
        DeRef(_1);
    }
    _34518 = NOVALUE;

    /** execute.e:3166		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:3167	end procedure*/
    _34515 = NOVALUE;
    _34513 = NOVALUE;
    return;
    ;
}


void _67opPEEK8U()
{
    object _34525 = NOVALUE;
    object _34524 = NOVALUE;
    object _34522 = NOVALUE;
    object _34520 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3170		a = Code[pc+1]*/
    _34520 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34520);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3171		target = Code[pc+2]*/
    _34522 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34522);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3172		val[target] = peek8u(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34524 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    {
        int64_t peek8_longlong;
        if (IS_ATOM_INT(_34524)) {
            peek8_longlong = *(int64_t *)_34524;
            if (peek8_longlong > (uint64_t)MAXINT){
                _34525 = NewDouble((eudouble)(uint64_t)peek8_longlong);
            }
            else{
                _34525 = (object) peek8_longlong;
            }
        }
        else if (IS_ATOM(_34524)) {
            peek8_longlong = *(int64_t *)(uintptr_t)(DBL_PTR(_34524)->dbl);
            if (peek8_longlong > (uint64_t)MAXINT){
                _34525 = NewDouble((eudouble)(uint64_t)peek8_longlong);
            }
            else{
                _34525 = (object) peek8_longlong;
            }
        }
        else {
            _1 = (object)SEQ_PTR(_34524);
            peek8_addr = (uint64_t *)get_pos_int("peek8s/peek8u", *(((s1_ptr)_1)->base+1));
            _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
            pokeptr_addr = (uintptr_t *)NewS1(_2);
            _34525 = MAKE_SEQ(pokeptr_addr);
            pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
            while (--_2 >= 0) {
                pokeptr_addr++;
                peek8_longlong = *peek8_addr++;
                if ((uint64_t)peek8_longlong > (uint64_t)MAXINT){
                    _1 = NewDouble((eudouble) (uint64_t) peek8_longlong);
                }
                else{
                    _1 = (object)peek8_longlong;
                }
                *pokeptr_addr = _1;
            }
        }
    }
    _34524 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34525;
    if( _1 != _34525 ){
        DeRef(_1);
    }
    _34525 = NOVALUE;

    /** execute.e:3173		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:3174	end procedure*/
    _34520 = NOVALUE;
    _34522 = NOVALUE;
    return;
    ;
}


void _67opPEEK8S()
{
    object _34532 = NOVALUE;
    object _34531 = NOVALUE;
    object _34529 = NOVALUE;
    object _34527 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3177		a = Code[pc+1]*/
    _34527 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34527);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3178		target = Code[pc+2]*/
    _34529 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34529);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3179		val[target] = peek8s(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34531 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    {
        int64_t peek8_longlong;
        if (IS_ATOM_INT(_34531)) {
            peek8_longlong = *(int64_t *)_34531;
            if (peek8_longlong < (int64_t)MININT || peek8_longlong > (int64_t) MAXINT){
                _34532 = NewDouble((eudouble) peek8_longlong);
            }
            else{
                _34532 = (object) peek8_longlong;
            }
        }
        else if (IS_ATOM(_34531)) {
            peek8_longlong = *(int64_t *)(uintptr_t)(DBL_PTR(_34531)->dbl);
            if (peek8_longlong < (int64_t)MININT || peek8_longlong > (int64_t) MAXINT){
                _34532 = NewDouble((eudouble) peek8_longlong);
            }
            else{
                _34532 = (object) peek8_longlong;
            }
        }
        else {
            _1 = (object)SEQ_PTR(_34531);
            peek8_addr = (uint64_t *)get_pos_int("peek8s/peek8u", *(((s1_ptr)_1)->base+1));
            _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
            pokeptr_addr = (uintptr_t *)NewS1(_2);
            _34532 = MAKE_SEQ(pokeptr_addr);
            pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
            while (--_2 >= 0) {
                pokeptr_addr++;
                peek8_longlong = *peek8_addr++;
                if (peek8_longlong < (int64_t) MININT || peek8_longlong > (int64_t) MAXINT){
                    _1 = NewDouble((eudouble)peek8_longlong);
                }
                else{
                    _1 = (object)(int64_t) peek8_longlong;
                }
                *pokeptr_addr = _1;
            }
        }
    }
    _34531 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34532;
    if( _1 != _34532 ){
        DeRef(_1);
    }
    _34532 = NOVALUE;

    /** execute.e:3180		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:3181	end procedure*/
    _34529 = NOVALUE;
    _34527 = NOVALUE;
    return;
    ;
}


void _67opPEEK_STRING()
{
    object _34539 = NOVALUE;
    object _34538 = NOVALUE;
    object _34536 = NOVALUE;
    object _34534 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3183		a = Code[pc+1]*/
    _34534 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34534);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3184		target = Code[pc+2]*/
    _34536 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34536);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3185		val[target] = peek_string(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34538 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_ATOM_INT(_34538)) {
        _34539 =  NewString((char *)_34538);
    }
    else if (IS_ATOM(_34538)) {
        _34539 = NewString((char *)(uintptr_t)(DBL_PTR(_34538)->dbl));
    }
    else {
        _1 = (object)SEQ_PTR(_34538);
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _34539 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
        }
    }
    _34538 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34539;
    if( _1 != _34539 ){
        DeRef(_1);
    }
    _34539 = NOVALUE;

    /** execute.e:3186		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:3187	end procedure*/
    _34534 = NOVALUE;
    _34536 = NOVALUE;
    return;
    ;
}


void _67opPEEK()
{
    object _34546 = NOVALUE;
    object _34545 = NOVALUE;
    object _34543 = NOVALUE;
    object _34541 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3190		a = Code[pc+1]*/
    _34541 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34541);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3191		target = Code[pc+2]*/
    _34543 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34543);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3192		val[target] = peek(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34545 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_ATOM_INT(_34545)) {
        _34546 = *(uint8_t *)_34545;
    }
    else if (IS_ATOM(_34545)) {
        _34546 = *(uint8_t *)(uintptr_t)(DBL_PTR(_34545)->dbl);
    }
    else {
        _1 = (object)SEQ_PTR(_34545);
        peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _34546 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)*peek_addr++;
        }
    }
    _34545 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34546;
    if( _1 != _34546 ){
        DeRef(_1);
    }
    _34546 = NOVALUE;

    /** execute.e:3193		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:3194	end procedure*/
    _34541 = NOVALUE;
    _34543 = NOVALUE;
    return;
    ;
}


void _67opPEEKS()
{
    object _34553 = NOVALUE;
    object _34552 = NOVALUE;
    object _34550 = NOVALUE;
    object _34548 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3197		a = Code[pc+1]*/
    _34548 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34548);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3198		target = Code[pc+2]*/
    _34550 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34550);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3199		val[target] = peeks(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34552 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_ATOM_INT(_34552)) {
        _34553 = *(int8_t *)_34552;
    }
    else if (IS_ATOM(_34552)) {
        _34553 = *(int8_t *)(uintptr_t)(DBL_PTR(_34552)->dbl);
    }
    else {
        _1 = (object)SEQ_PTR(_34552);
        peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _34553 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)(int8_t)*peek_addr++;
        }
    }
    _34552 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34553;
    if( _1 != _34553 ){
        DeRef(_1);
    }
    _34553 = NOVALUE;

    /** execute.e:3200		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:3201	end procedure*/
    _34548 = NOVALUE;
    _34550 = NOVALUE;
    return;
    ;
}


void _67opSIZEOF()
{
    object _34560 = NOVALUE;
    object _34559 = NOVALUE;
    object _34557 = NOVALUE;
    object _34555 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3204		a = Code[pc+1]*/
    _34555 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34555);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3205		b = Code[pc+2]*/
    _34557 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34557);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:3206		val[b] = sizeof( val[a] )*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34559 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _34560 = eu_sizeof( _34559 );
    _34559 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67b_64879);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34560;
    if( _1 != _34560 ){
        DeRef(_1);
    }
    _34560 = NOVALUE;

    /** execute.e:3207		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:3208	end procedure*/
    _34555 = NOVALUE;
    _34557 = NOVALUE;
    return;
    ;
}


void _67opPOKE()
{
    object _34567 = NOVALUE;
    object _34566 = NOVALUE;
    object _34564 = NOVALUE;
    object _34562 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3211		a = Code[pc+1]*/
    _34562 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34562);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3212		b = Code[pc+2]*/
    _34564 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34564);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:3213		poke(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34566 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34567 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_ATOM_INT(_34566)){
        poke_addr = (uint8_t *)_34566;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_34566)->dbl);
    }
    if (IS_ATOM_INT(_34567)) {
        *poke_addr = (uint8_t)_34567;
    }
    else if (IS_ATOM(_34567)) {
        *poke_addr = (uint8_t)DBL_PTR(_34567)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_34567);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke_addr++ = (uint8_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    _34566 = NOVALUE;
    _34567 = NOVALUE;

    /** execute.e:3214		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:3215	end procedure*/
    _34564 = NOVALUE;
    _34562 = NOVALUE;
    return;
    ;
}


void _67opPOKE4()
{
    object _34574 = NOVALUE;
    object _34573 = NOVALUE;
    object _34571 = NOVALUE;
    object _34569 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3218		a = Code[pc+1]*/
    _34569 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34569);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3219		b = Code[pc+2]*/
    _34571 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34571);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:3220		poke4(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34573 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34574 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_ATOM_INT(_34573)){
        poke4_addr = (uint32_t *)_34573;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_34573)->dbl);
    }
    if (IS_ATOM_INT(_34574)) {
        *poke4_addr = (uint32_t)_34574;
    }
    else if (IS_ATOM(_34574)) {
        *poke4_addr = (uint32_t)DBL_PTR(_34574)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_34574);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke4_addr++ = (int32_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *(object *)poke4_addr++ = (uint32_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    _34573 = NOVALUE;
    _34574 = NOVALUE;

    /** execute.e:3221		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:3222	end procedure*/
    _34571 = NOVALUE;
    _34569 = NOVALUE;
    return;
    ;
}


void _67opPOKE8()
{
    object _34581 = NOVALUE;
    object _34580 = NOVALUE;
    object _34578 = NOVALUE;
    object _34576 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3225		a = Code[pc+1]*/
    _34576 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34576);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3226		b = Code[pc+2]*/
    _34578 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34578);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:3227		poke8(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34580 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34581 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_ATOM_INT(_34580)){
        poke8_addr = (uint64_t *)_34580;
    }
    else {
        poke8_addr = (uint64_t *)(uintptr_t)(DBL_PTR(_34580)->dbl);
    }
    if (IS_ATOM_INT(_34581)) {
        *poke8_addr = (uint64_t)_34581;
    }
    else if (IS_ATOM(_34581)) {
        *poke8_addr = (uint64_t)DBL_PTR(_34581)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_34581);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke8_addr++ = (uint64_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *poke8_addr++ = (uint64_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    _34580 = NOVALUE;
    _34581 = NOVALUE;

    /** execute.e:3228		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:3229	end procedure*/
    _34576 = NOVALUE;
    _34578 = NOVALUE;
    return;
    ;
}


void _67opPOKE2()
{
    object _34588 = NOVALUE;
    object _34587 = NOVALUE;
    object _34585 = NOVALUE;
    object _34583 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3232		a = Code[pc+1]*/
    _34583 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34583);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3233		b = Code[pc+2]*/
    _34585 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34585);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:3234		poke2(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34587 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34588 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_ATOM_INT(_34587)){
        poke2_addr = (uint16_t *)_34587;
    }
    else {
        poke2_addr = (uint16_t *)(uintptr_t)(DBL_PTR(_34587)->dbl);
    }
    if (IS_ATOM_INT(_34588)) {
        *poke2_addr = (uint16_t)_34588;
    }
    else if (IS_ATOM(_34588)) {
        *poke2_addr = (uint16_t)DBL_PTR(_34588)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_34588);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke2_addr++ = (uint16_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *poke2_addr++ = (uint16_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    _34587 = NOVALUE;
    _34588 = NOVALUE;

    /** execute.e:3235		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:3236	end procedure*/
    _34585 = NOVALUE;
    _34583 = NOVALUE;
    return;
    ;
}


void _67opMEM_COPY()
{
    object _34598 = NOVALUE;
    object _34597 = NOVALUE;
    object _34596 = NOVALUE;
    object _34594 = NOVALUE;
    object _34592 = NOVALUE;
    object _34590 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3240		a = Code[pc+1]*/
    _34590 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34590);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3241		b = Code[pc+2]*/
    _34592 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34592);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:3242		c = Code[pc+3]*/
    _34594 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64880 = (object)*(((s1_ptr)_2)->base + _34594);
    if (!IS_ATOM_INT(_67c_64880)){
        _67c_64880 = (object)DBL_PTR(_67c_64880)->dbl;
    }

    /** execute.e:3243		mem_copy(val[a], val[b], val[c])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34596 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34597 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34598 = (object)*(((s1_ptr)_2)->base + _67c_64880);
    memory_copy(_34596, _34597, _34598);
    _34596 = NOVALUE;
    _34597 = NOVALUE;
    _34598 = NOVALUE;

    /** execute.e:3244		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:3245	end procedure*/
    _34590 = NOVALUE;
    _34592 = NOVALUE;
    _34594 = NOVALUE;
    return;
    ;
}


void _67opMEM_SET()
{
    object _34608 = NOVALUE;
    object _34607 = NOVALUE;
    object _34606 = NOVALUE;
    object _34604 = NOVALUE;
    object _34602 = NOVALUE;
    object _34600 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3248		a = Code[pc+1]*/
    _34600 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34600);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3249		b = Code[pc+2]*/
    _34602 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34602);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:3250		c = Code[pc+3]*/
    _34604 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64880 = (object)*(((s1_ptr)_2)->base + _34604);
    if (!IS_ATOM_INT(_67c_64880)){
        _67c_64880 = (object)DBL_PTR(_67c_64880)->dbl;
    }

    /** execute.e:3251		mem_set(val[a], val[b], val[c])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34606 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34607 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34608 = (object)*(((s1_ptr)_2)->base + _67c_64880);
    memory_set(_34606, _34607, _34608);
    _34606 = NOVALUE;
    _34607 = NOVALUE;
    _34608 = NOVALUE;

    /** execute.e:3252		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:3253	end procedure*/
    _34604 = NOVALUE;
    _34600 = NOVALUE;
    _34602 = NOVALUE;
    return;
    ;
}


void _67opCALL()
{
    object _34612 = NOVALUE;
    object _34610 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3256		a = Code[pc+1]*/
    _34610 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34610);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3257		call(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34612 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_ATOM_INT(_34612))
    _0 = (object)_34612;
    else
    _0 = (object)(uintptr_t)(DBL_PTR(_34612)->dbl);
    (*(void(*)())_0)();
    _34612 = NOVALUE;

    /** execute.e:3258		pc += 2*/
    _67pc_64877 = _67pc_64877 + 2LL;

    /** execute.e:3259	end procedure*/
    _34610 = NOVALUE;
    return;
    ;
}


void _67opSYSTEM()
{
    object _34625 = NOVALUE;
    object _34624 = NOVALUE;
    object _34622 = NOVALUE;
    object _34621 = NOVALUE;
    object _34619 = NOVALUE;
    object _34618 = NOVALUE;
    object _34616 = NOVALUE;
    object _34614 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3262		a = Code[pc+1]*/
    _34614 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34614);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3263		b = Code[pc+2]*/
    _34616 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34616);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:3264		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34618 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _34619 = IS_ATOM(_34618);
    _34618 = NOVALUE;
    if (_34619 == 0)
    {
        _34619 = NOVALUE;
        goto L1; // [46] 55
    }
    else{
        _34619 = NOVALUE;
    }

    /** execute.e:3265			RTFatal("first argument of system() must be a sequence")*/
    RefDS(_34620);
    _67RTFatal(_34620);
L1: 

    /** execute.e:3267		if sequence(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34621 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _34622 = IS_SEQUENCE(_34621);
    _34621 = NOVALUE;
    if (_34622 == 0)
    {
        _34622 = NOVALUE;
        goto L2; // [68] 77
    }
    else{
        _34622 = NOVALUE;
    }

    /** execute.e:3268			RTFatal("second argument of system() must be an atom")*/
    RefDS(_34623);
    _67RTFatal(_34623);
L2: 

    /** execute.e:3270		system(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34624 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34625 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    system_call(_34624, _34625);
    _34624 = NOVALUE;
    _34625 = NOVALUE;

    /** execute.e:3271		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:3272	end procedure*/
    DeRef(_34616);
    _34616 = NOVALUE;
    DeRef(_34614);
    _34614 = NOVALUE;
    return;
    ;
}


void _67opSYSTEM_EXEC()
{
    object _34639 = NOVALUE;
    object _34638 = NOVALUE;
    object _34637 = NOVALUE;
    object _34636 = NOVALUE;
    object _34635 = NOVALUE;
    object _34634 = NOVALUE;
    object _34633 = NOVALUE;
    object _34631 = NOVALUE;
    object _34629 = NOVALUE;
    object _34627 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3275		a = Code[pc+1]*/
    _34627 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34627);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3276		b = Code[pc+2]*/
    _34629 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34629);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:3277		target = Code[pc+3]*/
    _34631 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34631);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3278		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34633 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _34634 = IS_ATOM(_34633);
    _34633 = NOVALUE;
    if (_34634 == 0)
    {
        _34634 = NOVALUE;
        goto L1; // [62] 71
    }
    else{
        _34634 = NOVALUE;
    }

    /** execute.e:3279			RTFatal("first argument of system() must be a sequence")*/
    RefDS(_34620);
    _67RTFatal(_34620);
L1: 

    /** execute.e:3281		if sequence(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34635 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _34636 = IS_SEQUENCE(_34635);
    _34635 = NOVALUE;
    if (_34636 == 0)
    {
        _34636 = NOVALUE;
        goto L2; // [84] 93
    }
    else{
        _34636 = NOVALUE;
    }

    /** execute.e:3282			RTFatal("second argument of system() must be an atom")*/
    RefDS(_34623);
    _67RTFatal(_34623);
L2: 

    /** execute.e:3284		val[target] = system_exec(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34637 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34638 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _34639 = system_exec_call(_34637, _34638);
    _34637 = NOVALUE;
    _34638 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34639;
    if( _1 != _34639 ){
        DeRef(_1);
    }
    _34639 = NOVALUE;

    /** execute.e:3285		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:3286	end procedure*/
    DeRef(_34629);
    _34629 = NOVALUE;
    DeRef(_34627);
    _34627 = NOVALUE;
    DeRef(_34631);
    _34631 = NOVALUE;
    return;
    ;
}


void _67opOPEN()
{
    object _34666 = NOVALUE;
    object _34665 = NOVALUE;
    object _34664 = NOVALUE;
    object _34663 = NOVALUE;
    object _34660 = NOVALUE;
    object _34659 = NOVALUE;
    object _34657 = NOVALUE;
    object _34656 = NOVALUE;
    object _34654 = NOVALUE;
    object _34653 = NOVALUE;
    object _34652 = NOVALUE;
    object _34650 = NOVALUE;
    object _34649 = NOVALUE;
    object _34647 = NOVALUE;
    object _34645 = NOVALUE;
    object _34643 = NOVALUE;
    object _34641 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3291		a = Code[pc+1]*/
    _34641 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34641);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3292		b = Code[pc+2]*/
    _34643 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34643);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:3293		c = Code[pc+3]*/
    _34645 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64880 = (object)*(((s1_ptr)_2)->base + _34645);
    if (!IS_ATOM_INT(_67c_64880)){
        _67c_64880 = (object)DBL_PTR(_67c_64880)->dbl;
    }

    /** execute.e:3294		target = Code[pc+4]*/
    _34647 = _67pc_64877 + 4LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34647);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3296		if atom(val[b]) or length(val[b]) > 2 then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34649 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _34650 = IS_ATOM(_34649);
    _34649 = NOVALUE;
    if (_34650 != 0) {
        goto L1; // [78] 102
    }
    _2 = (object)SEQ_PTR(_67val_64887);
    _34652 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    if (IS_SEQUENCE(_34652)){
            _34653 = SEQ_PTR(_34652)->length;
    }
    else {
        _34653 = 1;
    }
    _34652 = NOVALUE;
    _34654 = (_34653 > 2LL);
    _34653 = NOVALUE;
    if (_34654 == 0)
    {
        DeRef(_34654);
        _34654 = NOVALUE;
        goto L2; // [98] 108
    }
    else{
        DeRef(_34654);
        _34654 = NOVALUE;
    }
L1: 

    /** execute.e:3297		   RTFatal("invalid open mode")*/
    RefDS(_34655);
    _67RTFatal(_34655);
L2: 

    /** execute.e:3299		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34656 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _34657 = IS_ATOM(_34656);
    _34656 = NOVALUE;
    if (_34657 == 0)
    {
        _34657 = NOVALUE;
        goto L3; // [121] 130
    }
    else{
        _34657 = NOVALUE;
    }

    /** execute.e:3300		   RTFatal("device or file name must be a sequence")*/
    RefDS(_34658);
    _67RTFatal(_34658);
L3: 

    /** execute.e:3302		if not atom(val[c]) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34659 = (object)*(((s1_ptr)_2)->base + _67c_64880);
    _34660 = IS_ATOM(_34659);
    _34659 = NOVALUE;
    if (_34660 != 0)
    goto L4; // [143] 152
    _34660 = NOVALUE;

    /** execute.e:3303			RTFatal("cleanup must be an atom")*/
    RefDS(_34662);
    _67RTFatal(_34662);
L4: 

    /** execute.e:3305		val[target] = open(val[a], val[b], val[c])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34663 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34664 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34665 = (object)*(((s1_ptr)_2)->base + _67c_64880);
    _34666 = EOpen(_34663, _34664, _34665);
    _34663 = NOVALUE;
    _34664 = NOVALUE;
    _34665 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34666;
    if( _1 != _34666 ){
        DeRef(_1);
    }
    _34666 = NOVALUE;

    /** execute.e:3306		pc += 5*/
    _67pc_64877 = _67pc_64877 + 5LL;

    /** execute.e:3307	end procedure*/
    DeRef(_34643);
    _34643 = NOVALUE;
    DeRef(_34641);
    _34641 = NOVALUE;
    _34652 = NOVALUE;
    DeRef(_34647);
    _34647 = NOVALUE;
    DeRef(_34645);
    _34645 = NOVALUE;
    return;
    ;
}


void _67opCLOSE()
{
    object _34670 = NOVALUE;
    object _34668 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3310		a = Code[pc+1]*/
    _34668 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34668);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3311		close(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34670 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (IS_ATOM_INT(_34670))
    EClose(_34670);
    else
    EClose((object)DBL_PTR(_34670)->dbl);
    _34670 = NOVALUE;

    /** execute.e:3312		pc += 2*/
    _67pc_64877 = _67pc_64877 + 2LL;

    /** execute.e:3313	end procedure*/
    _34668 = NOVALUE;
    return;
    ;
}


void _67opABORT()
{
    object _34674 = NOVALUE;
    object _34673 = NOVALUE;
    object _34672 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3316		Cleanup(val[Code[pc+1]])*/
    _34672 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _34673 = (object)*(((s1_ptr)_2)->base + _34672);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!IS_ATOM_INT(_34673)){
        _34674 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34673)->dbl));
    }
    else{
        _34674 = (object)*(((s1_ptr)_2)->base + _34673);
    }
    Ref(_34674);
    _49Cleanup(_34674);
    _34674 = NOVALUE;

    /** execute.e:3317	end procedure*/
    _34673 = NOVALUE;
    _34672 = NOVALUE;
    return;
    ;
}


void _67opGETC()
{
    object _34680 = NOVALUE;
    object _34679 = NOVALUE;
    object _34677 = NOVALUE;
    object _34675 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3320		a = Code[pc+1]*/
    _34675 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34675);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3321		target = Code[pc+2]*/
    _34677 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34677);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3322		val[target] = getc(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34679 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (_34679 != last_r_file_no) {
        last_r_file_ptr = which_file(_34679, EF_READ);
        if (IS_ATOM_INT(_34679)){
            last_r_file_no = _34679;
        }
        else{
            last_r_file_no = NOVALUE;
        }
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _34680 = getc((FILE*)xstdin);
        }
        else{
            _34680 = getc(last_r_file_ptr);
        }
    }
    else{
        _34680 = getc(last_r_file_ptr);
    }
    _34679 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34680;
    if( _1 != _34680 ){
        DeRef(_1);
    }
    _34680 = NOVALUE;

    /** execute.e:3323		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:3324	end procedure*/
    _34677 = NOVALUE;
    _34675 = NOVALUE;
    return;
    ;
}


void _67opGETS()
{
    object _34687 = NOVALUE;
    object _34686 = NOVALUE;
    object _34684 = NOVALUE;
    object _34682 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3328		a = Code[pc+1]*/
    _34682 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34682);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3329		target = Code[pc+2]*/
    _34684 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34684);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3330		val[target] = gets(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34686 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _34687 = EGets(_34686);
    _34686 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34687;
    if( _1 != _34687 ){
        DeRef(_1);
    }
    _34687 = NOVALUE;

    /** execute.e:3331		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:3332	end procedure*/
    _34682 = NOVALUE;
    _34684 = NOVALUE;
    return;
    ;
}


void _67opGET_KEY()
{
    object _34691 = NOVALUE;
    object _34689 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3337		target = Code[pc+1]*/
    _34689 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34689);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3338		val[target] = get_key()*/
    _34691 = get_key(0);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34691;
    if( _1 != _34691 ){
        DeRef(_1);
    }
    _34691 = NOVALUE;

    /** execute.e:3339		pc += 2*/
    _67pc_64877 = _67pc_64877 + 2LL;

    /** execute.e:3340	end procedure*/
    _34689 = NOVALUE;
    return;
    ;
}


void _67opCLEAR_SCREEN()
{
    object _0, _1, _2;
    

    /** execute.e:3343		clear_screen()*/
    ClearScreen();

    /** execute.e:3344		pc += 1*/
    _67pc_64877 = _67pc_64877 + 1;

    /** execute.e:3345	end procedure*/
    return;
    ;
}


void _67opPUTS()
{
    object _34699 = NOVALUE;
    object _34698 = NOVALUE;
    object _34696 = NOVALUE;
    object _34694 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3348		a = Code[pc+1]*/
    _34694 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34694);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3349		b = Code[pc+2]*/
    _34696 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34696);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:3350		puts(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34698 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34699 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    EPuts(_34698, _34699); // DJP 
    _34698 = NOVALUE;
    _34699 = NOVALUE;

    /** execute.e:3351		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:3352	end procedure*/
    _34696 = NOVALUE;
    _34694 = NOVALUE;
    return;
    ;
}


void _67opQPRINT()
{
    object _34703 = NOVALUE;
    object _34701 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3356		a = Code[pc+2]*/
    _34701 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34701);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3357		? val[a]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34703 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    StdPrint(1LL, _34703, 1);
    _34703 = NOVALUE;

    /** execute.e:3358		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:3359	end procedure*/
    _34701 = NOVALUE;
    return;
    ;
}


void _67opPRINT()
{
    object _34710 = NOVALUE;
    object _34709 = NOVALUE;
    object _34707 = NOVALUE;
    object _34705 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3362		a = Code[pc+1]*/
    _34705 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34705);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3363		b = Code[pc+2]*/
    _34707 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34707);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:3364		print(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34709 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34710 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    StdPrint(_34709, _34710, 0);
    _34709 = NOVALUE;
    _34710 = NOVALUE;

    /** execute.e:3365		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:3366	end procedure*/
    _34705 = NOVALUE;
    _34707 = NOVALUE;
    return;
    ;
}


void _67opPRINTF()
{
    object _34720 = NOVALUE;
    object _34719 = NOVALUE;
    object _34718 = NOVALUE;
    object _34716 = NOVALUE;
    object _34714 = NOVALUE;
    object _34712 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3370		a = Code[pc+1]*/
    _34712 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34712);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3371		b = Code[pc+2]*/
    _34714 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34714);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:3372		c = Code[pc+3]*/
    _34716 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64880 = (object)*(((s1_ptr)_2)->base + _34716);
    if (!IS_ATOM_INT(_67c_64880)){
        _67c_64880 = (object)DBL_PTR(_67c_64880)->dbl;
    }

    /** execute.e:3373		printf(val[a], val[b], val[c])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34718 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34719 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34720 = (object)*(((s1_ptr)_2)->base + _67c_64880);
    EPrintf(_34718, _34719, _34720);
    _34718 = NOVALUE;
    _34719 = NOVALUE;
    _34720 = NOVALUE;

    /** execute.e:3374		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:3375	end procedure*/
    _34716 = NOVALUE;
    _34712 = NOVALUE;
    _34714 = NOVALUE;
    return;
    ;
}


void _67opSPRINTF()
{
    object _34730 = NOVALUE;
    object _34729 = NOVALUE;
    object _34728 = NOVALUE;
    object _34726 = NOVALUE;
    object _34724 = NOVALUE;
    object _34722 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3378		a = Code[pc+1]*/
    _34722 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34722);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3379		b = Code[pc+2]*/
    _34724 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34724);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:3380		target = Code[pc+3]*/
    _34726 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34726);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3381		val[target] = sprintf(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34728 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34729 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _34730 = EPrintf(-9999999, _34728, _34729);
    _34728 = NOVALUE;
    _34729 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34730;
    if( _1 != _34730 ){
        DeRef(_1);
    }
    _34730 = NOVALUE;

    /** execute.e:3382		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:3383	end procedure*/
    _34722 = NOVALUE;
    _34726 = NOVALUE;
    _34724 = NOVALUE;
    return;
    ;
}


void _67opCOMMAND_LINE()
{
    object _cmd_69626 = NOVALUE;
    object _34740 = NOVALUE;
    object _34739 = NOVALUE;
    object _34738 = NOVALUE;
    object _34737 = NOVALUE;
    object _34735 = NOVALUE;
    object _34732 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3388		target = Code[pc+1]*/
    _34732 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34732);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3389		cmd = command_line()*/
    DeRef(_cmd_69626);
    _cmd_69626 = Command_Line();

    /** execute.e:3391		if length(cmd) > 2 then*/
    if (IS_SEQUENCE(_cmd_69626)){
            _34735 = SEQ_PTR(_cmd_69626)->length;
    }
    else {
        _34735 = 1;
    }
    if (_34735 <= 2LL)
    goto L1; // [26] 53

    /** execute.e:3392			cmd = {cmd[1]} & cmd[3..$]*/
    _2 = (object)SEQ_PTR(_cmd_69626);
    _34737 = (object)*(((s1_ptr)_2)->base + 1LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_34737);
    ((intptr_t*)_2)[1] = _34737;
    _34738 = MAKE_SEQ(_1);
    _34737 = NOVALUE;
    if (IS_SEQUENCE(_cmd_69626)){
            _34739 = SEQ_PTR(_cmd_69626)->length;
    }
    else {
        _34739 = 1;
    }
    rhs_slice_target = (object_ptr)&_34740;
    RHS_Slice(_cmd_69626, 3LL, _34739);
    Concat((object_ptr)&_cmd_69626, _34738, _34740);
    DeRefDS(_34738);
    _34738 = NOVALUE;
    DeRef(_34738);
    _34738 = NOVALUE;
    DeRefDS(_34740);
    _34740 = NOVALUE;
L1: 

    /** execute.e:3394		val[target] = cmd*/
    RefDS(_cmd_69626);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _cmd_69626;
    DeRef(_1);

    /** execute.e:3395		pc += 2*/
    _67pc_64877 = _67pc_64877 + 2LL;

    /** execute.e:3396	end procedure*/
    DeRefDS(_cmd_69626);
    DeRef(_34732);
    _34732 = NOVALUE;
    return;
    ;
}


void _67opOPTION_SWITCHES()
{
    object _cmd_69642 = NOVALUE;
    object _34743 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3401		target = Code[pc+1]*/
    _34743 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34743);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3402		cmd = option_switches()*/
    DeRef(_cmd_69642);
    RefDS(_0switches);
    _cmd_69642 = _0switches;

    /** execute.e:3403		val[target] = cmd*/
    RefDS(_cmd_69642);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _cmd_69642;
    DeRef(_1);

    /** execute.e:3404		pc += 2*/
    _67pc_64877 = _67pc_64877 + 2LL;

    /** execute.e:3405	end procedure*/
    DeRefDS(_cmd_69642);
    _34743 = NOVALUE;
    return;
    ;
}


void _67opGETENV()
{
    object _34755 = NOVALUE;
    object _34754 = NOVALUE;
    object _34752 = NOVALUE;
    object _34751 = NOVALUE;
    object _34749 = NOVALUE;
    object _34747 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3408		a = Code[pc+1]*/
    _34747 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34747);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3409		target = Code[pc+2]*/
    _34749 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34749);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3410		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34751 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _34752 = IS_ATOM(_34751);
    _34751 = NOVALUE;
    if (_34752 == 0)
    {
        _34752 = NOVALUE;
        goto L1; // [46] 55
    }
    else{
        _34752 = NOVALUE;
    }

    /** execute.e:3411			RTFatal("argument to getenv must be a sequence")*/
    RefDS(_34753);
    _67RTFatal(_34753);
L1: 

    /** execute.e:3413		val[target] = getenv(val[a])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34754 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _34755 = EGetEnv(_34754);
    _34754 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34755;
    if( _1 != _34755 ){
        DeRef(_1);
    }
    _34755 = NOVALUE;

    /** execute.e:3414		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:3415	end procedure*/
    DeRef(_34747);
    _34747 = NOVALUE;
    DeRef(_34749);
    _34749 = NOVALUE;
    return;
    ;
}


void _67opC_PROC()
{
    object _sub_69666 = NOVALUE;
    object _34764 = NOVALUE;
    object _34763 = NOVALUE;
    object _34761 = NOVALUE;
    object _34759 = NOVALUE;
    object _34757 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3420		a = Code[pc+1]*/
    _34757 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34757);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3421		b = Code[pc+2]*/
    _34759 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34759);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:3422		sub = Code[pc+3]*/
    _34761 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _sub_69666 = (object)*(((s1_ptr)_2)->base + _34761);
    if (!IS_ATOM_INT(_sub_69666)){
        _sub_69666 = (object)DBL_PTR(_sub_69666)->dbl;
    }

    /** execute.e:3423		c_proc(val[a], val[b])  -- callback could happen here*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34763 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34764 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    call_c(0, _34763, _34764);
    _34763 = NOVALUE;
    _34764 = NOVALUE;

    /** execute.e:3424		restore_privates(sub)*/
    _67restore_privates(_sub_69666);

    /** execute.e:3425		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:3426	end procedure*/
    _34761 = NOVALUE;
    _34759 = NOVALUE;
    _34757 = NOVALUE;
    return;
    ;
}


void _67opC_FUNC()
{
    object _target_69681 = NOVALUE;
    object _sub_69683 = NOVALUE;
    object _temp_69684 = NOVALUE;
    object _34775 = NOVALUE;
    object _34774 = NOVALUE;
    object _34772 = NOVALUE;
    object _34770 = NOVALUE;
    object _34768 = NOVALUE;
    object _34766 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3431		object temp*/

    /** execute.e:3433		a = Code[pc+1]*/
    _34766 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34766);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3434		b = Code[pc+2]*/
    _34768 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34768);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:3435		sub = Code[pc+3]*/
    _34770 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _sub_69683 = (object)*(((s1_ptr)_2)->base + _34770);
    if (!IS_ATOM_INT(_sub_69683)){
        _sub_69683 = (object)DBL_PTR(_sub_69683)->dbl;
    }

    /** execute.e:3436		target = Code[pc+4]*/
    _34772 = _67pc_64877 + 4LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _target_69681 = (object)*(((s1_ptr)_2)->base + _34772);
    if (!IS_ATOM_INT(_target_69681)){
        _target_69681 = (object)DBL_PTR(_target_69681)->dbl;
    }

    /** execute.e:3437		temp = c_func(val[a], val[b])  -- callback could happen here*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34774 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34775 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    DeRef(_temp_69684);
    _temp_69684 = call_c(1, _34774, _34775);
    _34774 = NOVALUE;
    _34775 = NOVALUE;

    /** execute.e:3438		restore_privates(sub)*/
    _67restore_privates(_sub_69683);

    /** execute.e:3439		val[target] = temp*/
    Ref(_temp_69684);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _target_69681);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _temp_69684;
    DeRef(_1);

    /** execute.e:3440		pc += 5*/
    _67pc_64877 = _67pc_64877 + 5LL;

    /** execute.e:3441	end procedure*/
    DeRef(_temp_69684);
    _34768 = NOVALUE;
    _34770 = NOVALUE;
    _34766 = NOVALUE;
    _34772 = NOVALUE;
    return;
    ;
}


void _67opTRACE()
{
    object _34779 = NOVALUE;
    object _34778 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3444		TraceOn = val[Code[pc+1]]*/
    _34778 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _34779 = (object)*(((s1_ptr)_2)->base + _34778);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!IS_ATOM_INT(_34779)){
        _67TraceOn_64875 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34779)->dbl));
    }
    else{
        _67TraceOn_64875 = (object)*(((s1_ptr)_2)->base + _34779);
    }
    if (!IS_ATOM_INT(_67TraceOn_64875))
    _67TraceOn_64875 = (object)DBL_PTR(_67TraceOn_64875)->dbl;

    /** execute.e:3445		pc += 2  -- turn on/off tracing*/
    _67pc_64877 = _67pc_64877 + 2LL;

    /** execute.e:3446	end procedure*/
    _34779 = NOVALUE;
    _34778 = NOVALUE;
    return;
    ;
}


void _67opPROFILE()
{
    object _0, _1, _2;
    

    /** execute.e:3452		pc += 2*/
    _67pc_64877 = _67pc_64877 + 2LL;

    /** execute.e:3453	end procedure*/
    return;
    ;
}


void _67opUPDATE_GLOBALS()
{
    object _0, _1, _2;
    

    /** execute.e:3458		pc += 1*/
    _67pc_64877 = _67pc_64877 + 1;

    /** execute.e:3459	end procedure*/
    return;
    ;
}


object _67general_callback(object _rtn_def_69716, object _args_69717)
{
    object _arglist_assign_69719 = NOVALUE;
    object _34801 = NOVALUE;
    object _34799 = NOVALUE;
    object _34798 = NOVALUE;
    object _34797 = NOVALUE;
    object _34794 = NOVALUE;
    object _34793 = NOVALUE;
    object _34791 = NOVALUE;
    object _34790 = NOVALUE;
    object _34786 = NOVALUE;
    object _34784 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:3493		val[t_id] = rtn_def[C_USER_ROUTINE]*/
    _2 = (object)SEQ_PTR(_rtn_def_69716);
    _34784 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_34784);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_id_64808);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34784;
    if( _1 != _34784 ){
        DeRef(_1);
    }
    _34784 = NOVALUE;

    /** execute.e:3494		val[t_arglist] = args*/
    RefDS(_args_69717);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_arglist_64809);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _args_69717;
    DeRef(_1);

    /** execute.e:3495		atom arglist_assign = new_arg_assign()*/
    _0 = _arglist_assign_69719;
    _arglist_assign_69719 = _67new_arg_assign();
    DeRef(_0);

    /** execute.e:3497		SymTab[call_back_routine][S_RESIDENT_TASK] = current_task*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67call_back_routine_64811 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67current_task_64894;
    DeRef(_1);
    _34786 = NOVALUE;

    /** execute.e:3500		call_stack = append(call_stack, pc)*/
    Append(&_67call_stack_64895, _67call_stack_64895, _67pc_64877);

    /** execute.e:3501		call_stack = append(call_stack, call_back_routine)*/
    Append(&_67call_stack_64895, _67call_stack_64895, _67call_back_routine_64811);

    /** execute.e:3503		Code = call_back_code*/
    RefDS(_67call_back_code_64805);
    DeRef(_12Code_20315);
    _12Code_20315 = _67call_back_code_64805;

    /** execute.e:3504		pc = 1*/
    _67pc_64877 = 1LL;

    /** execute.e:3506		do_exec()*/
    _67do_exec();

    /** execute.e:3509		pc = call_stack[$-1]*/
    if (IS_SEQUENCE(_67call_stack_64895)){
            _34790 = SEQ_PTR(_67call_stack_64895)->length;
    }
    else {
        _34790 = 1;
    }
    _34791 = _34790 - 1LL;
    _34790 = NOVALUE;
    _2 = (object)SEQ_PTR(_67call_stack_64895);
    _67pc_64877 = (object)*(((s1_ptr)_2)->base + _34791);
    if (!IS_ATOM_INT(_67pc_64877))
    _67pc_64877 = (object)DBL_PTR(_67pc_64877)->dbl;

    /** execute.e:3510		call_stack = call_stack[1..$-2]*/
    if (IS_SEQUENCE(_67call_stack_64895)){
            _34793 = SEQ_PTR(_67call_stack_64895)->length;
    }
    else {
        _34793 = 1;
    }
    _34794 = _34793 - 2LL;
    _34793 = NOVALUE;
    rhs_slice_target = (object_ptr)&_67call_stack_64895;
    RHS_Slice(_67call_stack_64895, 1LL, _34794);

    /** execute.e:3512		if arglist_assign = arg_assign then*/
    if (binary_op_a(NOTEQ, _arglist_assign_69719, _67arg_assign_64821)){
        goto L1; // [126] 143
    }

    /** execute.e:3513			val[t_arglist] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_arglist_64809);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
L1: 

    /** execute.e:3516		Code = SymTab[call_stack[$]][S_CODE]*/
    if (IS_SEQUENCE(_67call_stack_64895)){
            _34797 = SEQ_PTR(_67call_stack_64895)->length;
    }
    else {
        _34797 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_64895);
    _34798 = (object)*(((s1_ptr)_2)->base + _34797);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_34798)){
        _34799 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34798)->dbl));
    }
    else{
        _34799 = (object)*(((s1_ptr)_2)->base + _34798);
    }
    DeRef(_12Code_20315);
    _2 = (object)SEQ_PTR(_34799);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    Ref(_12Code_20315);
    _34799 = NOVALUE;

    /** execute.e:3518		return val[t_return_val]*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34801 = (object)*(((s1_ptr)_2)->base + _67t_return_val_64810);
    Ref(_34801);
    DeRefDS(_rtn_def_69716);
    DeRefDS(_args_69717);
    DeRef(_arglist_assign_69719);
    _34798 = NOVALUE;
    DeRef(_34794);
    _34794 = NOVALUE;
    DeRef(_34791);
    _34791 = NOVALUE;
    return _34801;
    ;
}


object _67machine_callback(object _cbx_69750, object _ptr_69751)
{
    object _rtn_def_69752 = NOVALUE;
    object _args_69753 = NOVALUE;
    object _34809 = NOVALUE;
    object _34807 = NOVALUE;
    object _34806 = NOVALUE;
    object _34805 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3528		rtn_def = call_backs[cbx]*/
    DeRef(_rtn_def_69752);
    _2 = (object)SEQ_PTR(_67call_backs_64804);
    if (!IS_ATOM_INT(_cbx_69750)){
        _rtn_def_69752 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_cbx_69750)->dbl));
    }
    else{
        _rtn_def_69752 = (object)*(((s1_ptr)_2)->base + _cbx_69750);
    }
    RefDS(_rtn_def_69752);

    /** execute.e:3529		args = peek4u(ptr & call_backs[cbx][C_NUM_ARGS])*/
    _2 = (object)SEQ_PTR(_67call_backs_64804);
    if (!IS_ATOM_INT(_cbx_69750)){
        _34805 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_cbx_69750)->dbl));
    }
    else{
        _34805 = (object)*(((s1_ptr)_2)->base + _cbx_69750);
    }
    _2 = (object)SEQ_PTR(_34805);
    _34806 = (object)*(((s1_ptr)_2)->base + 3LL);
    _34805 = NOVALUE;
    if (IS_SEQUENCE(_ptr_69751) && IS_ATOM(_34806)) {
    }
    else if (IS_ATOM(_ptr_69751) && IS_SEQUENCE(_34806)) {
        Ref(_ptr_69751);
        Prepend(&_34807, _34806, _ptr_69751);
    }
    else {
        Concat((object_ptr)&_34807, _ptr_69751, _34806);
    }
    _34806 = NOVALUE;
    DeRef(_args_69753);
    _1 = (object)SEQ_PTR(_34807);
    peek4_addr = (uint32_t *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _args_69753 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        _1 = (object)*peek4_addr++;
        if ((uintptr_t)_1 > (uintptr_t)MAXINT){
            _1 = NewDouble((eudouble)(uintptr_t)_1);
        }
        *pokeptr_addr = _1;
    }
    DeRefDS(_34807);
    _34807 = NOVALUE;

    /** execute.e:3531		return general_callback(rtn_def, args)*/
    RefDS(_rtn_def_69752);
    RefDS(_args_69753);
    _34809 = _67general_callback(_rtn_def_69752, _args_69753);
    DeRef(_cbx_69750);
    DeRef(_ptr_69751);
    DeRefDS(_rtn_def_69752);
    DeRefDS(_args_69753);
    return _34809;
    ;
}


object _67callback(object _a_69780)
{
    object _34825 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3626		return machine_func(M_CALL_BACK, a)*/
    _34825 = machine(52LL, _a_69780);
    DeRefi(_a_69780);
    return _34825;
    ;
}


void _67do_callback(object _b_69784)
{
    object _r_69786 = NOVALUE;
    object _asm_69787 = NOVALUE;
    object _id_69788 = NOVALUE;
    object _convention_69789 = NOVALUE;
    object _x_69790 = NOVALUE;
    object _34887 = NOVALUE;
    object _34886 = NOVALUE;
    object _34885 = NOVALUE;
    object _34884 = NOVALUE;
    object _34883 = NOVALUE;
    object _34882 = NOVALUE;
    object _34881 = NOVALUE;
    object _34880 = NOVALUE;
    object _34878 = NOVALUE;
    object _34877 = NOVALUE;
    object _34876 = NOVALUE;
    object _34875 = NOVALUE;
    object _34873 = NOVALUE;
    object _34854 = NOVALUE;
    object _34853 = NOVALUE;
    object _34851 = NOVALUE;
    object _34850 = NOVALUE;
    object _34849 = NOVALUE;
    object _34848 = NOVALUE;
    object _34847 = NOVALUE;
    object _34846 = NOVALUE;
    object _34845 = NOVALUE;
    object _34844 = NOVALUE;
    object _34843 = NOVALUE;
    object _34842 = NOVALUE;
    object _34840 = NOVALUE;
    object _34839 = NOVALUE;
    object _34838 = NOVALUE;
    object _34837 = NOVALUE;
    object _34835 = NOVALUE;
    object _34833 = NOVALUE;
    object _34832 = NOVALUE;
    object _34830 = NOVALUE;
    object _34827 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3631		atom asm*/

    /** execute.e:3632		integer id, convention*/

    /** execute.e:3633		object x*/

    /** execute.e:3636		x = val[b]*/
    DeRef(_x_69790);
    _2 = (object)SEQ_PTR(_67val_64887);
    _x_69790 = (object)*(((s1_ptr)_2)->base + _b_69784);
    Ref(_x_69790);

    /** execute.e:3637		if atom(x) then*/
    _34827 = IS_ATOM(_x_69790);
    if (_34827 == 0)
    {
        _34827 = NOVALUE;
        goto L1; // [22] 40
    }
    else{
        _34827 = NOVALUE;
    }

    /** execute.e:3638			id = x*/
    Ref(_x_69790);
    _id_69788 = _x_69790;
    if (!IS_ATOM_INT(_id_69788)) {
        _1 = (object)(DBL_PTR(_id_69788)->dbl);
        DeRefDS(_id_69788);
        _id_69788 = _1;
    }

    /** execute.e:3639			convention = 0*/
    _convention_69789 = 0LL;
    goto L2; // [37] 57
L1: 

    /** execute.e:3641			id = x[2]*/
    _2 = (object)SEQ_PTR(_x_69790);
    _id_69788 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_id_69788)){
        _id_69788 = (object)DBL_PTR(_id_69788)->dbl;
    }

    /** execute.e:3642			convention = x[1]*/
    _2 = (object)SEQ_PTR(_x_69790);
    _convention_69789 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_convention_69789)){
        _convention_69789 = (object)DBL_PTR(_convention_69789)->dbl;
    }
L2: 

    /** execute.e:3645		if id < 0 or id >= length(e_routine) then*/
    _34830 = (_id_69788 < 0LL);
    if (_34830 != 0) {
        goto L3; // [65] 83
    }
    if (IS_SEQUENCE(_67e_routine_64926)){
            _34832 = SEQ_PTR(_67e_routine_64926)->length;
    }
    else {
        _34832 = 1;
    }
    _34833 = (_id_69788 >= _34832);
    _34832 = NOVALUE;
    if (_34833 == 0)
    {
        DeRef(_34833);
        _34833 = NOVALUE;
        goto L4; // [79] 89
    }
    else{
        DeRef(_34833);
        _34833 = NOVALUE;
    }
L3: 

    /** execute.e:3646			RTFatal("Invalid routine id")*/
    RefDS(_34834);
    _67RTFatal(_34834);
L4: 

    /** execute.e:3649		r = e_routine[id+1]*/
    _34835 = _id_69788 + 1;
    _2 = (object)SEQ_PTR(_67e_routine_64926);
    _r_69786 = (object)*(((s1_ptr)_2)->base + _34835);

    /** execute.e:3651		if platform() = WIN32 and convention = 0 then*/
    _34837 = (3LL == 2LL);
    if (_34837 == 0) {
        goto L5; // [111] 224
    }
    _34839 = (_convention_69789 == 0LL);
    if (_34839 == 0)
    {
        DeRef(_34839);
        _34839 = NOVALUE;
        goto L5; // [122] 224
    }
    else{
        DeRef(_34839);
        _34839 = NOVALUE;
    }

    /** execute.e:3653			asm = dep:allocate_protect(length(cb_std), 1, PAGE_EXECUTE_READWRITE)*/
    _34840 = 24;
    Ref(_5PAGE_EXECUTE_READWRITE_250);
    _0 = _asm_69787;
    _asm_69787 = _4allocate_protect(24LL, 1LL, _5PAGE_EXECUTE_READWRITE_250);
    DeRef(_0);
    _34840 = NOVALUE;

    /** execute.e:3654			poke( asm, cb_std )*/
    if (IS_ATOM_INT(_asm_69787)){
        poke_addr = (uint8_t *)_asm_69787;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_asm_69787)->dbl);
    }
    _1 = (object)SEQ_PTR(_67cb_std_69760);
    _1 = (object)((s1_ptr)_1)->base;
    while (1) {
        _1 += sizeof(object);
        _2 = *((object *)_1);
        if (IS_ATOM_INT(_2)) {
            *poke_addr++ = (uint8_t)_2;
        }
        else if (_2 == NOVALUE) {
            break;
        }
        else {
            *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
        }
    }

    /** execute.e:3655			poke4( asm + 7, length(call_backs) + 1 )*/
    if (IS_ATOM_INT(_asm_69787)) {
        _34842 = _asm_69787 + 7LL;
        if ((object)((uintptr_t)_34842 + (uintptr_t)HIGH_BITS) >= 0){
            _34842 = NewDouble((eudouble)_34842);
        }
    }
    else {
        _34842 = NewDouble(DBL_PTR(_asm_69787)->dbl + (eudouble)7LL);
    }
    if (IS_SEQUENCE(_67call_backs_64804)){
            _34843 = SEQ_PTR(_67call_backs_64804)->length;
    }
    else {
        _34843 = 1;
    }
    _34844 = _34843 + 1;
    _34843 = NOVALUE;
    if (IS_ATOM_INT(_34842)){
        poke4_addr = (uint32_t *)_34842;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_34842)->dbl);
    }
    *poke4_addr = (uint32_t)_34844;
    DeRef(_34842);
    _34842 = NOVALUE;
    _34844 = NOVALUE;

    /** execute.e:3656			poke4( asm + 13, asm + 20 )*/
    if (IS_ATOM_INT(_asm_69787)) {
        _34845 = _asm_69787 + 13LL;
        if ((object)((uintptr_t)_34845 + (uintptr_t)HIGH_BITS) >= 0){
            _34845 = NewDouble((eudouble)_34845);
        }
    }
    else {
        _34845 = NewDouble(DBL_PTR(_asm_69787)->dbl + (eudouble)13LL);
    }
    if (IS_ATOM_INT(_asm_69787)) {
        _34846 = _asm_69787 + 20LL;
        if ((object)((uintptr_t)_34846 + (uintptr_t)HIGH_BITS) >= 0){
            _34846 = NewDouble((eudouble)_34846);
        }
    }
    else {
        _34846 = NewDouble(DBL_PTR(_asm_69787)->dbl + (eudouble)20LL);
    }
    if (IS_ATOM_INT(_34845)){
        poke4_addr = (uint32_t *)_34845;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_34845)->dbl);
    }
    if (IS_ATOM_INT(_34846)) {
        *poke4_addr = (uint32_t)_34846;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_34846)->dbl;
    }
    DeRef(_34845);
    _34845 = NOVALUE;
    DeRef(_34846);
    _34846 = NOVALUE;

    /** execute.e:3657			poke( asm + 18, SymTab[r][S_NUM_ARGS] * 4 )*/
    if (IS_ATOM_INT(_asm_69787)) {
        _34847 = _asm_69787 + 18LL;
        if ((object)((uintptr_t)_34847 + (uintptr_t)HIGH_BITS) >= 0){
            _34847 = NewDouble((eudouble)_34847);
        }
    }
    else {
        _34847 = NewDouble(DBL_PTR(_asm_69787)->dbl + (eudouble)18LL);
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34848 = (object)*(((s1_ptr)_2)->base + _r_69786);
    _2 = (object)SEQ_PTR(_34848);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _34849 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _34849 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _34848 = NOVALUE;
    if (IS_ATOM_INT(_34849)) {
        {
            int128_t p128 = (int128_t)_34849 * (int128_t)4LL;
            if( p128 != (int128_t)(_34850 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _34850 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _34850 = binary_op(MULTIPLY, _34849, 4LL);
    }
    _34849 = NOVALUE;
    if (IS_ATOM_INT(_34847)){
        poke_addr = (uint8_t *)_34847;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_34847)->dbl);
    }
    if (IS_ATOM_INT(_34850)) {
        *poke_addr = (uint8_t)_34850;
    }
    else if (IS_ATOM(_34850)) {
        *poke_addr = (uint8_t)DBL_PTR(_34850)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_34850);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke_addr++ = (uint8_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_34847);
    _34847 = NOVALUE;
    DeRef(_34850);
    _34850 = NOVALUE;

    /** execute.e:3658			poke4( asm + 20, callback( routine_id("machine_callback") ) )*/
    if (IS_ATOM_INT(_asm_69787)) {
        _34851 = _asm_69787 + 20LL;
        if ((object)((uintptr_t)_34851 + (uintptr_t)HIGH_BITS) >= 0){
            _34851 = NewDouble((eudouble)_34851);
        }
    }
    else {
        _34851 = NewDouble(DBL_PTR(_asm_69787)->dbl + (eudouble)20LL);
    }
    _34853 = CRoutineId(1597, 67, _34852);
    _34854 = _67callback(_34853);
    _34853 = NOVALUE;
    if (IS_ATOM_INT(_34851)){
        poke4_addr = (uint32_t *)_34851;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_34851)->dbl);
    }
    if (IS_ATOM_INT(_34854)) {
        *poke4_addr = (uint32_t)_34854;
    }
    else if (IS_ATOM(_34854)) {
        *poke4_addr = (uint32_t)DBL_PTR(_34854)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_34854);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke4_addr++ = (int32_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *(object *)poke4_addr++ = (uint32_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_34851);
    _34851 = NOVALUE;
    DeRef(_34854);
    _34854 = NOVALUE;
    goto L6; // [221] 409
L5: 

    /** execute.e:3659		elsif platform() = OSX then*/

    /** execute.e:3675			asm = dep:allocate_protect(length(cb_cdecl), 1, PAGE_EXECUTE_READWRITE)*/
    _34873 = 27;
    Ref(_5PAGE_EXECUTE_READWRITE_250);
    _0 = _asm_69787;
    _asm_69787 = _4allocate_protect(27LL, 1LL, _5PAGE_EXECUTE_READWRITE_250);
    DeRef(_0);
    _34873 = NOVALUE;

    /** execute.e:3676			poke( asm, cb_cdecl )*/
    if (IS_ATOM_INT(_asm_69787)){
        poke_addr = (uint8_t *)_asm_69787;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_asm_69787)->dbl);
    }
    _1 = (object)SEQ_PTR(_67cb_cdecl_69765);
    _1 = (object)((s1_ptr)_1)->base;
    while (1) {
        _1 += sizeof(object);
        _2 = *((object *)_1);
        if (IS_ATOM_INT(_2)) {
            *poke_addr++ = (uint8_t)_2;
        }
        else if (_2 == NOVALUE) {
            break;
        }
        else {
            *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
        }
    }

    /** execute.e:3677			poke4( asm + 7, length(call_backs) + 1 )*/
    if (IS_ATOM_INT(_asm_69787)) {
        _34875 = _asm_69787 + 7LL;
        if ((object)((uintptr_t)_34875 + (uintptr_t)HIGH_BITS) >= 0){
            _34875 = NewDouble((eudouble)_34875);
        }
    }
    else {
        _34875 = NewDouble(DBL_PTR(_asm_69787)->dbl + (eudouble)7LL);
    }
    if (IS_SEQUENCE(_67call_backs_64804)){
            _34876 = SEQ_PTR(_67call_backs_64804)->length;
    }
    else {
        _34876 = 1;
    }
    _34877 = _34876 + 1;
    _34876 = NOVALUE;
    if (IS_ATOM_INT(_34875)){
        poke4_addr = (uint32_t *)_34875;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_34875)->dbl);
    }
    *poke4_addr = (uint32_t)_34877;
    DeRef(_34875);
    _34875 = NOVALUE;
    _34877 = NOVALUE;

    /** execute.e:3678			poke4( asm + 13, asm + 23 )*/
    if (IS_ATOM_INT(_asm_69787)) {
        _34878 = _asm_69787 + 13LL;
        if ((object)((uintptr_t)_34878 + (uintptr_t)HIGH_BITS) >= 0){
            _34878 = NewDouble((eudouble)_34878);
        }
    }
    else {
        _34878 = NewDouble(DBL_PTR(_asm_69787)->dbl + (eudouble)13LL);
    }
    if (IS_ATOM_INT(_asm_69787)) {
        _34880 = _asm_69787 + 23LL;
        if ((object)((uintptr_t)_34880 + (uintptr_t)HIGH_BITS) >= 0){
            _34880 = NewDouble((eudouble)_34880);
        }
    }
    else {
        _34880 = NewDouble(DBL_PTR(_asm_69787)->dbl + (eudouble)23LL);
    }
    if (IS_ATOM_INT(_34878)){
        poke4_addr = (uint32_t *)_34878;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_34878)->dbl);
    }
    if (IS_ATOM_INT(_34880)) {
        *poke4_addr = (uint32_t)_34880;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_34880)->dbl;
    }
    DeRef(_34878);
    _34878 = NOVALUE;
    DeRef(_34880);
    _34880 = NOVALUE;

    /** execute.e:3679			poke4( asm + 23, callback( ( '+' & routine_id("machine_callback") ) ) )*/
    if (IS_ATOM_INT(_asm_69787)) {
        _34881 = _asm_69787 + 23LL;
        if ((object)((uintptr_t)_34881 + (uintptr_t)HIGH_BITS) >= 0){
            _34881 = NewDouble((eudouble)_34881);
        }
    }
    else {
        _34881 = NewDouble(DBL_PTR(_asm_69787)->dbl + (eudouble)23LL);
    }
    _34882 = CRoutineId(1597, 67, _34852);
    Concat((object_ptr)&_34883, 43LL, _34882);
    _34882 = NOVALUE;
    _34884 = _67callback(_34883);
    _34883 = NOVALUE;
    if (IS_ATOM_INT(_34881)){
        poke4_addr = (uint32_t *)_34881;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_34881)->dbl);
    }
    if (IS_ATOM_INT(_34884)) {
        *poke4_addr = (uint32_t)_34884;
    }
    else if (IS_ATOM(_34884)) {
        *poke4_addr = (uint32_t)DBL_PTR(_34884)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_34884);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke4_addr++ = (int32_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *(object *)poke4_addr++ = (uint32_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_34881);
    _34881 = NOVALUE;
    DeRef(_34884);
    _34884 = NOVALUE;
L6: 

    /** execute.e:3682		val[target] = asm*/
    Ref(_asm_69787);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _asm_69787;
    DeRef(_1);

    /** execute.e:3683		call_backs = append( call_backs, { r, id, SymTab[r][S_NUM_ARGS] })*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _34885 = (object)*(((s1_ptr)_2)->base + _r_69786);
    _2 = (object)SEQ_PTR(_34885);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _34886 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _34886 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _34885 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _r_69786;
    ((intptr_t*)_2)[2] = _id_69788;
    Ref(_34886);
    ((intptr_t*)_2)[3] = _34886;
    _34887 = MAKE_SEQ(_1);
    _34886 = NOVALUE;
    RefDS(_34887);
    Append(&_67call_backs_64804, _67call_backs_64804, _34887);
    DeRefDS(_34887);
    _34887 = NOVALUE;

    /** execute.e:3684	end procedure*/
    DeRef(_asm_69787);
    DeRef(_x_69790);
    DeRef(_34830);
    _34830 = NOVALUE;
    DeRef(_34837);
    _34837 = NOVALUE;
    DeRef(_34835);
    _34835 = NOVALUE;
    return;
    ;
}


void _67do_crash_routine(object _b_69873)
{
    object _x_69874 = NOVALUE;
    object _34895 = NOVALUE;
    object _34894 = NOVALUE;
    object _34893 = NOVALUE;
    object _34892 = NOVALUE;
    object _34891 = NOVALUE;
    object _34890 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3690		x = val[b]*/
    DeRef(_x_69874);
    _2 = (object)SEQ_PTR(_67val_64887);
    _x_69874 = (object)*(((s1_ptr)_2)->base + _b_69873);
    Ref(_x_69874);

    /** execute.e:3691		if atom(x) and x >= 0 and x < length(e_routine) then*/
    _34890 = IS_ATOM(_x_69874);
    if (_34890 == 0) {
        _34891 = 0;
        goto L1; // [16] 28
    }
    if (IS_ATOM_INT(_x_69874)) {
        _34892 = (_x_69874 >= 0LL);
    }
    else {
        _34892 = binary_op(GREATEREQ, _x_69874, 0LL);
    }
    if (IS_ATOM_INT(_34892))
    _34891 = (_34892 != 0);
    else
    _34891 = DBL_PTR(_34892)->dbl != 0.0;
L1: 
    if (_34891 == 0) {
        goto L2; // [28] 56
    }
    if (IS_SEQUENCE(_67e_routine_64926)){
            _34894 = SEQ_PTR(_67e_routine_64926)->length;
    }
    else {
        _34894 = 1;
    }
    if (IS_ATOM_INT(_x_69874)) {
        _34895 = (_x_69874 < _34894);
    }
    else {
        _34895 = binary_op(LESS, _x_69874, _34894);
    }
    _34894 = NOVALUE;
    if (_34895 == 0) {
        DeRef(_34895);
        _34895 = NOVALUE;
        goto L2; // [42] 56
    }
    else {
        if (!IS_ATOM_INT(_34895) && DBL_PTR(_34895)->dbl == 0.0){
            DeRef(_34895);
            _34895 = NOVALUE;
            goto L2; // [42] 56
        }
        DeRef(_34895);
        _34895 = NOVALUE;
    }
    DeRef(_34895);
    _34895 = NOVALUE;

    /** execute.e:3692			crash_list = append(crash_list, x)*/
    Ref(_x_69874);
    Append(&_67crash_list_64813, _67crash_list_64813, _x_69874);
    goto L3; // [53] 62
L2: 

    /** execute.e:3694			RTFatal("crash routine requires a valid routine id")*/
    RefDS(_34897);
    _67RTFatal(_34897);
L3: 

    /** execute.e:3696	end procedure*/
    DeRef(_x_69874);
    DeRef(_34892);
    _34892 = NOVALUE;
    return;
    ;
}


void _67opREMOVE()
{
    object _34909 = NOVALUE;
    object _34908 = NOVALUE;
    object _34907 = NOVALUE;
    object _34906 = NOVALUE;
    object _34904 = NOVALUE;
    object _34902 = NOVALUE;
    object _34900 = NOVALUE;
    object _34898 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3699	 	a = Code[pc+1]*/
    _34898 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34898);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3700	 	b = Code[pc+2]*/
    _34900 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34900);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:3701	 	c = Code[pc+3]*/
    _34902 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64880 = (object)*(((s1_ptr)_2)->base + _34902);
    if (!IS_ATOM_INT(_67c_64880)){
        _67c_64880 = (object)DBL_PTR(_67c_64880)->dbl;
    }

    /** execute.e:3702	 	target = Code[pc+4]*/
    _34904 = _67pc_64877 + 4LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34904);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3703	 	val[target] = remove(val[a],val[b],val[c])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34906 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34907 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34908 = (object)*(((s1_ptr)_2)->base + _67c_64880);
    {
        s1_ptr assign_space = SEQ_PTR(_34906);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_34907)) ? _34907 : (object)(DBL_PTR(_34907)->dbl);
        int stop = (IS_ATOM_INT(_34908)) ? _34908 : (object)(DBL_PTR(_34908)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
            RefDS(_34906);
            DeRef(_34909);
            _34909 = _34906;
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_34906), start, &_34909 );
            }
            else Tail(SEQ_PTR(_34906), stop+1, &_34909);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_34906), start, &_34909);
        }
        else {
            assign_slice_seq = &assign_space;
            _1 = Remove_elements(start, stop, 0);
            DeRef(_34909);
            _34909 = _1;
        }
    }
    _34906 = NOVALUE;
    _34907 = NOVALUE;
    _34908 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34909;
    if( _1 != _34909 ){
        DeRef(_1);
    }
    _34909 = NOVALUE;

    /** execute.e:3704	 	pc += 5*/
    _67pc_64877 = _67pc_64877 + 5LL;

    /** execute.e:3705	end procedure*/
    _34904 = NOVALUE;
    _34902 = NOVALUE;
    _34898 = NOVALUE;
    _34900 = NOVALUE;
    return;
    ;
}


void _67opREPLACE()
{
    object _34925 = NOVALUE;
    object _34924 = NOVALUE;
    object _34923 = NOVALUE;
    object _34922 = NOVALUE;
    object _34921 = NOVALUE;
    object _34919 = NOVALUE;
    object _34917 = NOVALUE;
    object _34915 = NOVALUE;
    object _34913 = NOVALUE;
    object _34911 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3708	 	a = Code[pc+1]*/
    _34911 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34911);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3709	 	b = Code[pc+2]*/
    _34913 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34913);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:3710	 	c = Code[pc+3]*/
    _34915 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64880 = (object)*(((s1_ptr)_2)->base + _34915);
    if (!IS_ATOM_INT(_67c_64880)){
        _67c_64880 = (object)DBL_PTR(_67c_64880)->dbl;
    }

    /** execute.e:3711	 	d = Code[pc+4]*/
    _34917 = _67pc_64877 + 4LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67d_64881 = (object)*(((s1_ptr)_2)->base + _34917);
    if (!IS_ATOM_INT(_67d_64881)){
        _67d_64881 = (object)DBL_PTR(_67d_64881)->dbl;
    }

    /** execute.e:3712	 	target = Code[pc+5]*/
    _34919 = _67pc_64877 + 5LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34919);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3713	 	val[target] = replace(val[a],val[b],val[c],val[d])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34921 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34922 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34923 = (object)*(((s1_ptr)_2)->base + _67c_64880);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34924 = (object)*(((s1_ptr)_2)->base + _67d_64881);
    {
        intptr_t p1 = _34921;
        intptr_t p2 = _34922;
        intptr_t p3 = _34923;
        intptr_t p4 = _34924;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_34925;
        Replace( &replace_params );
    }
    _34921 = NOVALUE;
    _34922 = NOVALUE;
    _34923 = NOVALUE;
    _34924 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34925;
    if( _1 != _34925 ){
        DeRef(_1);
    }
    _34925 = NOVALUE;

    /** execute.e:3714	 	pc += 6*/
    _67pc_64877 = _67pc_64877 + 6LL;

    /** execute.e:3715	end procedure*/
    _34919 = NOVALUE;
    _34911 = NOVALUE;
    _34917 = NOVALUE;
    _34915 = NOVALUE;
    _34913 = NOVALUE;
    return;
    ;
}


void _67opHEAD()
{
    object _34935 = NOVALUE;
    object _34934 = NOVALUE;
    object _34933 = NOVALUE;
    object _34931 = NOVALUE;
    object _34929 = NOVALUE;
    object _34927 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3718		a = Code[pc+1]*/
    _34927 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34927);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3719		b = Code[pc+2]*/
    _34929 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34929);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:3720		target = Code[pc+3]*/
    _34931 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34931);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3721		val[target] = head(val[a],val[b])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34933 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34934 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    {
        int len = SEQ_PTR(_34933)->length;
        int size = (IS_ATOM_INT(_34934)) ? _34934 : (object)(DBL_PTR(_34934)->dbl);
        if (size <= 0){
            DeRef( _34935 );
            _34935 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_34933);
            DeRef(_34935);
            _34935 = _34933;
        }
        else{
            Head(SEQ_PTR(_34933),size+1,&_34935);
        }
    }
    _34933 = NOVALUE;
    _34934 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34935;
    if( _1 != _34935 ){
        DeRef(_1);
    }
    _34935 = NOVALUE;

    /** execute.e:3722		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:3723	end procedure*/
    _34931 = NOVALUE;
    _34929 = NOVALUE;
    _34927 = NOVALUE;
    return;
    ;
}


void _67opTAIL()
{
    object _34945 = NOVALUE;
    object _34944 = NOVALUE;
    object _34943 = NOVALUE;
    object _34941 = NOVALUE;
    object _34939 = NOVALUE;
    object _34937 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3726		a = Code[pc+1]*/
    _34937 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34937);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3727		b = Code[pc+2]*/
    _34939 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34939);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:3728		target = Code[pc+3]*/
    _34941 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34941);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3729		val[target] = tail(val[a],val[b])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34943 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34944 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    {
        int len = SEQ_PTR(_34943)->length;
        int size = (IS_ATOM_INT(_34944)) ? _34944 : (object)(DBL_PTR(_34944)->dbl);
        if (size <= 0) {
            DeRef(_34945);
            _34945 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_34943);
            DeRef(_34945);
            _34945 = _34943;
        }
        else Tail(SEQ_PTR(_34943), len-size+1, &_34945);
    }
    _34943 = NOVALUE;
    _34944 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34945;
    if( _1 != _34945 ){
        DeRef(_1);
    }
    _34945 = NOVALUE;

    /** execute.e:3730		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:3731	end procedure*/
    _34939 = NOVALUE;
    _34937 = NOVALUE;
    _34941 = NOVALUE;
    return;
    ;
}


void _67opMACHINE_FUNC()
{
    object _34958 = NOVALUE;
    object _34957 = NOVALUE;
    object _34956 = NOVALUE;
    object _34954 = NOVALUE;
    object _34951 = NOVALUE;
    object _34949 = NOVALUE;
    object _34947 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3734		a = Code[pc+1]*/
    _34947 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34947);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3735		b = Code[pc+2]*/
    _34949 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34949);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:3736		target = Code[pc+3]*/
    _34951 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34951);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3738		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:3740		if val[a] = M_CALL_BACK then*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34954 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    if (binary_op_a(NOTEQ, _34954, 52LL)){
        _34954 = NOVALUE;
        goto L1; // [67] 81
    }
    _34954 = NOVALUE;

    /** execute.e:3742			do_callback(b)*/
    _67do_callback(_67b_64879);
    goto L2; // [78] 112
L1: 

    /** execute.e:3744			val[target] = machine_func(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34956 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34957 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _34958 = machine(_34956, _34957);
    _34956 = NOVALUE;
    _34957 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34958;
    if( _1 != _34958 ){
        DeRef(_1);
    }
    _34958 = NOVALUE;
L2: 

    /** execute.e:3746	end procedure*/
    DeRef(_34949);
    _34949 = NOVALUE;
    DeRef(_34947);
    _34947 = NOVALUE;
    DeRef(_34951);
    _34951 = NOVALUE;
    return;
    ;
}


void _67opSPLICE()
{
    object _34970 = NOVALUE;
    object _34969 = NOVALUE;
    object _34968 = NOVALUE;
    object _34967 = NOVALUE;
    object _34965 = NOVALUE;
    object _34963 = NOVALUE;
    object _34961 = NOVALUE;
    object _34959 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3749		a = Code[pc+1]*/
    _34959 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34959);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3750		b = Code[pc+2]*/
    _34961 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34961);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:3751		c = Code[pc+3]*/
    _34963 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64880 = (object)*(((s1_ptr)_2)->base + _34963);
    if (!IS_ATOM_INT(_67c_64880)){
        _67c_64880 = (object)DBL_PTR(_67c_64880)->dbl;
    }

    /** execute.e:3752		target = Code[pc+4]*/
    _34965 = _67pc_64877 + 4LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34965);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3753		val[target] = splice(val[a],val[b],val[c])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34967 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34968 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34969 = (object)*(((s1_ptr)_2)->base + _67c_64880);
    {
        s1_ptr assign_space;
        insert_pos = IS_ATOM_INT(_34969) ? _34969 : DBL_PTR(_34969)->dbl;
        if (insert_pos <= 0) {
            if (IS_SEQUENCE(_34968)) {
                Concat(&_34970,_34968,_34967);
            }
            else{
                Prepend(&_34970,_34967,_34968);
            }
        }
        else if (insert_pos > SEQ_PTR(_34967)->length){
            if (IS_SEQUENCE(_34968)) {
                Concat(&_34970,_34967,_34968);
            }
            else{
                Append(&_34970,_34967,_34968);
            }
        }
        else if (IS_SEQUENCE(_34968)) {
            if( _34970 != _34967 || SEQ_PTR( _34967 )->ref != 1 ){
                DeRef( _34970 );
                RefDS( _34967 );
            }
            assign_space = Add_internal_space( _34967, insert_pos,((s1_ptr)SEQ_PTR(_34968))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_34968), _34967 == _34970 );
            _34970 = MAKE_SEQ( assign_space );
        }
        else {
            if( _34970 == _34967 && SEQ_PTR( _34967 )->ref == 1 ){
                _34970 = Insert( _34967, _34968, insert_pos);
            }
            else {
                DeRef( _34970 );
                RefDS( _34967 );
                _34970 = Insert( _34967, _34968, insert_pos);
            }
        }
    }
    _34967 = NOVALUE;
    _34968 = NOVALUE;
    _34969 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34970;
    if( _1 != _34970 ){
        DeRef(_1);
    }
    _34970 = NOVALUE;

    /** execute.e:3754		pc += 5*/
    _67pc_64877 = _67pc_64877 + 5LL;

    /** execute.e:3755	end procedure*/
    _34961 = NOVALUE;
    _34965 = NOVALUE;
    _34959 = NOVALUE;
    _34963 = NOVALUE;
    return;
    ;
}


void _67opINSERT()
{
    object _34983 = NOVALUE;
    object _34982 = NOVALUE;
    object _34981 = NOVALUE;
    object _34980 = NOVALUE;
    object _34978 = NOVALUE;
    object _34976 = NOVALUE;
    object _34974 = NOVALUE;
    object _34972 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3758		a = Code[pc+1]*/
    _34972 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34972);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3759		b = Code[pc+2]*/
    _34974 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34974);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:3760		c = Code[pc+3]*/
    _34976 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67c_64880 = (object)*(((s1_ptr)_2)->base + _34976);
    if (!IS_ATOM_INT(_67c_64880)){
        _67c_64880 = (object)DBL_PTR(_67c_64880)->dbl;
    }

    /** execute.e:3761		target = Code[pc+4]*/
    _34978 = _67pc_64877 + 4LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67target_64882 = (object)*(((s1_ptr)_2)->base + _34978);
    if (!IS_ATOM_INT(_67target_64882)){
        _67target_64882 = (object)DBL_PTR(_67target_64882)->dbl;
    }

    /** execute.e:3762		val[target] = insert(val[a],val[b],val[c])*/
    _2 = (object)SEQ_PTR(_67val_64887);
    _34980 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34981 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    _2 = (object)SEQ_PTR(_67val_64887);
    _34982 = (object)*(((s1_ptr)_2)->base + _67c_64880);
    {
        s1_ptr assign_space;
        insert_pos = IS_ATOM_INT(_34982) ? _34982 : DBL_PTR(_34982)->dbl;
        if (insert_pos <= 0){
            Prepend(&_34983,_34980,_34981);
        }
        else if (insert_pos > SEQ_PTR(_34980)->length) {
            Ref( _34981 );
            Append(&_34983,_34980,_34981);
        }
        else {
            Ref( _34981 );
            RefDS( _34980 );
            _34983 = Insert(_34980,_34981,insert_pos);
        }
    }
    _34980 = NOVALUE;
    _34981 = NOVALUE;
    _34982 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_64882);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34983;
    if( _1 != _34983 ){
        DeRef(_1);
    }
    _34983 = NOVALUE;

    /** execute.e:3763		pc += 5*/
    _67pc_64877 = _67pc_64877 + 5LL;

    /** execute.e:3764	end procedure*/
    _34972 = NOVALUE;
    _34976 = NOVALUE;
    _34974 = NOVALUE;
    _34978 = NOVALUE;
    return;
    ;
}


void _67opMACHINE_PROC()
{
    object _v_70018 = NOVALUE;
    object _35002 = NOVALUE;
    object _35001 = NOVALUE;
    object _34999 = NOVALUE;
    object _34997 = NOVALUE;
    object _34996 = NOVALUE;
    object _34994 = NOVALUE;
    object _34993 = NOVALUE;
    object _34987 = NOVALUE;
    object _34985 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3770		a = Code[pc+1]*/
    _34985 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _34985);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3771		b = Code[pc+2]*/
    _34987 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67b_64879 = (object)*(((s1_ptr)_2)->base + _34987);
    if (!IS_ATOM_INT(_67b_64879)){
        _67b_64879 = (object)DBL_PTR(_67b_64879)->dbl;
    }

    /** execute.e:3772		v = val[a]*/
    DeRef(_v_70018);
    _2 = (object)SEQ_PTR(_67val_64887);
    _v_70018 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    Ref(_v_70018);

    /** execute.e:3774		switch v do*/
    if (IS_SEQUENCE(_v_70018) ){
        goto L1; // [45] 201
    }
    if(!IS_ATOM_INT(_v_70018)){
        if( (DBL_PTR(_v_70018)->dbl != (eudouble) ((object) DBL_PTR(_v_70018)->dbl) ) ){
            goto L1; // [45] 201
        }
        _0 = (object) DBL_PTR(_v_70018)->dbl;
    }
    else {
        _0 = _v_70018;
    };
    switch ( _0 ){ 

        /** execute.e:3775			case M_CRASH_ROUTINE then*/
        case 66:

        /** execute.e:3777				do_crash_routine(b)*/
        _67do_crash_routine(_67b_64879);
        goto L2; // [61] 217

        /** execute.e:3779			case M_CRASH_MESSAGE then*/
        case 37:

        /** execute.e:3780				crash_msg = val[b]*/
        DeRef(_67crash_msg_64803);
        _2 = (object)SEQ_PTR(_67val_64887);
        _67crash_msg_64803 = (object)*(((s1_ptr)_2)->base + _67b_64879);
        Ref(_67crash_msg_64803);
        goto L2; // [77] 217

        /** execute.e:3782			case M_CRASH_FILE then*/
        case 57:

        /** execute.e:3783				if sequence(val[b]) then*/
        _2 = (object)SEQ_PTR(_67val_64887);
        _34993 = (object)*(((s1_ptr)_2)->base + _67b_64879);
        _34994 = IS_SEQUENCE(_34993);
        _34993 = NOVALUE;
        if (_34994 == 0)
        {
            _34994 = NOVALUE;
            goto L2; // [96] 217
        }
        else{
            _34994 = NOVALUE;
        }

        /** execute.e:3784					err_file_name = val[b]*/
        DeRef(_67err_file_name_64928);
        _2 = (object)SEQ_PTR(_67val_64887);
        _67err_file_name_64928 = (object)*(((s1_ptr)_2)->base + _67b_64879);
        Ref(_67err_file_name_64928);
        goto L2; // [112] 217

        /** execute.e:3787			case M_WARNING_FILE then*/
        case 72:

        /** execute.e:3788				display_warnings = 1*/
        _49display_warnings_49311 = 1LL;

        /** execute.e:3789				if sequence(val[b]) then*/
        _2 = (object)SEQ_PTR(_67val_64887);
        _34996 = (object)*(((s1_ptr)_2)->base + _67b_64879);
        _34997 = IS_SEQUENCE(_34996);
        _34996 = NOVALUE;
        if (_34997 == 0)
        {
            _34997 = NOVALUE;
            goto L3; // [138] 154
        }
        else{
            _34997 = NOVALUE;
        }

        /** execute.e:3790					TempWarningName = val[b]*/
        DeRef(_12TempWarningName_20240);
        _2 = (object)SEQ_PTR(_67val_64887);
        _12TempWarningName_20240 = (object)*(((s1_ptr)_2)->base + _67b_64879);
        Ref(_12TempWarningName_20240);
        goto L2; // [151] 217
L3: 

        /** execute.e:3792					TempWarningName = STDERR*/
        DeRef(_12TempWarningName_20240);
        _12TempWarningName_20240 = 2LL;

        /** execute.e:3793					display_warnings = (val[b] >= 0)*/
        _2 = (object)SEQ_PTR(_67val_64887);
        _34999 = (object)*(((s1_ptr)_2)->base + _67b_64879);
        if (IS_ATOM_INT(_34999)) {
            _49display_warnings_49311 = (_34999 >= 0LL);
        }
        else {
            _49display_warnings_49311 = binary_op(GREATEREQ, _34999, 0LL);
        }
        _34999 = NOVALUE;
        if (!IS_ATOM_INT(_49display_warnings_49311)) {
            _1 = (object)(DBL_PTR(_49display_warnings_49311)->dbl);
            DeRefDS(_49display_warnings_49311);
            _49display_warnings_49311 = _1;
        }
        goto L2; // [178] 217

        /** execute.e:3796			case M_CRASH then*/
        case 67:

        /** execute.e:3798				RTFatal( val[b] )*/
        _2 = (object)SEQ_PTR(_67val_64887);
        _35001 = (object)*(((s1_ptr)_2)->base + _67b_64879);
        Ref(_35001);
        _67RTFatal(_35001);
        _35001 = NOVALUE;
        goto L2; // [197] 217

        /** execute.e:3801			case else*/
        default:
L1: 

        /** execute.e:3802				machine_proc(v, val[b])*/
        _2 = (object)SEQ_PTR(_67val_64887);
        _35002 = (object)*(((s1_ptr)_2)->base + _67b_64879);
        machine(_v_70018, _35002);
        _35002 = NOVALUE;
    ;}L2: 

    /** execute.e:3804		pc += 3*/
    _67pc_64877 = _67pc_64877 + 3LL;

    /** execute.e:3805	end procedure*/
    DeRef(_v_70018);
    DeRef(_34987);
    _34987 = NOVALUE;
    DeRef(_34985);
    _34985 = NOVALUE;
    return;
    ;
}


void _67opDEREF_TEMP()
{
    object _35005 = NOVALUE;
    object _35004 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3808		val[Code[pc+1]] = NOVALUE*/
    _35004 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _35005 = (object)*(((s1_ptr)_2)->base + _35004);
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35005))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_35005)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _35005);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);

    /** execute.e:3809		pc += 2*/
    _67pc_64877 = _67pc_64877 + 2LL;

    /** execute.e:3810	end procedure*/
    _35005 = NOVALUE;
    _35004 = NOVALUE;
    return;
    ;
}


void _67do_delete_routine(object _dx_70071, object _o_70072)
{
    object _arglist_assign_70075 = NOVALUE;
    object _35027 = NOVALUE;
    object _35026 = NOVALUE;
    object _35025 = NOVALUE;
    object _35024 = NOVALUE;
    object _35023 = NOVALUE;
    object _35021 = NOVALUE;
    object _35020 = NOVALUE;
    object _35018 = NOVALUE;
    object _35017 = NOVALUE;
    object _35012 = NOVALUE;
    object _35010 = NOVALUE;
    object _35009 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:3823		val[t_id] = user_delete_rid[dx]*/
    _2 = (object)SEQ_PTR(_67user_delete_rid_70064);
    _35009 = (object)*(((s1_ptr)_2)->base + _dx_70071);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_id_64808);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35009;
    if( _1 != _35009 ){
        DeRef(_1);
    }
    _35009 = NOVALUE;

    /** execute.e:3824		val[t_arglist] = {o}*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_o_70072);
    ((intptr_t*)_2)[1] = _o_70072;
    _35010 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_arglist_64809);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35010;
    if( _1 != _35010 ){
        DeRef(_1);
    }
    _35010 = NOVALUE;

    /** execute.e:3825		atom arglist_assign = new_arg_assign()*/
    _0 = _arglist_assign_70075;
    _arglist_assign_70075 = _67new_arg_assign();
    DeRef(_0);

    /** execute.e:3827		SymTab[delete_code_routine][S_RESIDENT_TASK] = current_task*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67delete_code_routine_64812 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67current_task_64894;
    DeRef(_1);
    _35012 = NOVALUE;

    /** execute.e:3830		call_stack = append(call_stack, pc)*/
    Append(&_67call_stack_64895, _67call_stack_64895, _67pc_64877);

    /** execute.e:3831		call_stack = append(call_stack, delete_code_routine)*/
    Append(&_67call_stack_64895, _67call_stack_64895, _67delete_code_routine_64812);

    /** execute.e:3833		Code = delete_code*/
    RefDS(_67delete_code_64806);
    DeRef(_12Code_20315);
    _12Code_20315 = _67delete_code_64806;

    /** execute.e:3834		pc = 1*/
    _67pc_64877 = 1LL;

    /** execute.e:3836		do_exec()*/
    _67do_exec();

    /** execute.e:3838		if arglist_assign = arg_assign then*/
    if (binary_op_a(NOTEQ, _arglist_assign_70075, _67arg_assign_64821)){
        goto L1; // [99] 116
    }

    /** execute.e:3840			val[t_arglist] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_arglist_64809);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
L1: 

    /** execute.e:3842		o = 0*/
    DeRef(_o_70072);
    _o_70072 = 0LL;

    /** execute.e:3845		pc = call_stack[$-1]*/
    if (IS_SEQUENCE(_67call_stack_64895)){
            _35017 = SEQ_PTR(_67call_stack_64895)->length;
    }
    else {
        _35017 = 1;
    }
    _35018 = _35017 - 1LL;
    _35017 = NOVALUE;
    _2 = (object)SEQ_PTR(_67call_stack_64895);
    _67pc_64877 = (object)*(((s1_ptr)_2)->base + _35018);
    if (!IS_ATOM_INT(_67pc_64877))
    _67pc_64877 = (object)DBL_PTR(_67pc_64877)->dbl;

    /** execute.e:3846		call_stack = call_stack[1..$-2]*/
    if (IS_SEQUENCE(_67call_stack_64895)){
            _35020 = SEQ_PTR(_67call_stack_64895)->length;
    }
    else {
        _35020 = 1;
    }
    _35021 = _35020 - 2LL;
    _35020 = NOVALUE;
    rhs_slice_target = (object_ptr)&_67call_stack_64895;
    RHS_Slice(_67call_stack_64895, 1LL, _35021);

    /** execute.e:3848		restore_privates( call_stack[$] )*/
    if (IS_SEQUENCE(_67call_stack_64895)){
            _35023 = SEQ_PTR(_67call_stack_64895)->length;
    }
    else {
        _35023 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_64895);
    _35024 = (object)*(((s1_ptr)_2)->base + _35023);
    Ref(_35024);
    _67restore_privates(_35024);
    _35024 = NOVALUE;

    /** execute.e:3851		Code = SymTab[call_stack[$]][S_CODE]*/
    if (IS_SEQUENCE(_67call_stack_64895)){
            _35025 = SEQ_PTR(_67call_stack_64895)->length;
    }
    else {
        _35025 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_64895);
    _35026 = (object)*(((s1_ptr)_2)->base + _35025);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_35026)){
        _35027 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_35026)->dbl));
    }
    else{
        _35027 = (object)*(((s1_ptr)_2)->base + _35026);
    }
    DeRef(_12Code_20315);
    _2 = (object)SEQ_PTR(_35027);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    Ref(_12Code_20315);
    _35027 = NOVALUE;

    /** execute.e:3852	end procedure*/
    DeRef(_arglist_assign_70075);
    _35021 = NOVALUE;
    _35026 = NOVALUE;
    _35018 = NOVALUE;
    return;
    ;
}


void _67user_delete_01(object _o_70105)
{
    object _0, _1, _2;
    

    /** execute.e:3855		do_delete_routine( 1, o )*/
    Ref(_o_70105);
    _67do_delete_routine(1LL, _o_70105);

    /** execute.e:3856	end procedure*/
    DeRef(_o_70105);
    return;
    ;
}


void _67user_delete_02(object _o_70110)
{
    object _0, _1, _2;
    

    /** execute.e:3860		do_delete_routine( 2, o )*/
    Ref(_o_70110);
    _67do_delete_routine(2LL, _o_70110);

    /** execute.e:3861	end procedure*/
    DeRef(_o_70110);
    return;
    ;
}


void _67user_delete_03(object _o_70115)
{
    object _0, _1, _2;
    

    /** execute.e:3865		do_delete_routine( 3, o )*/
    Ref(_o_70115);
    _67do_delete_routine(3LL, _o_70115);

    /** execute.e:3866	end procedure*/
    DeRef(_o_70115);
    return;
    ;
}


void _67user_delete_04(object _o_70120)
{
    object _0, _1, _2;
    

    /** execute.e:3870		do_delete_routine( 4, o )*/
    Ref(_o_70120);
    _67do_delete_routine(4LL, _o_70120);

    /** execute.e:3871	end procedure*/
    DeRef(_o_70120);
    return;
    ;
}


void _67user_delete_05(object _o_70125)
{
    object _0, _1, _2;
    

    /** execute.e:3875		do_delete_routine( 5, o )*/
    Ref(_o_70125);
    _67do_delete_routine(5LL, _o_70125);

    /** execute.e:3876	end procedure*/
    DeRef(_o_70125);
    return;
    ;
}


void _67user_delete_06(object _o_70130)
{
    object _0, _1, _2;
    

    /** execute.e:3880		do_delete_routine( 6, o )*/
    Ref(_o_70130);
    _67do_delete_routine(6LL, _o_70130);

    /** execute.e:3881	end procedure*/
    DeRef(_o_70130);
    return;
    ;
}


void _67user_delete_07(object _o_70135)
{
    object _0, _1, _2;
    

    /** execute.e:3885		do_delete_routine( 7, o )*/
    Ref(_o_70135);
    _67do_delete_routine(7LL, _o_70135);

    /** execute.e:3886	end procedure*/
    DeRef(_o_70135);
    return;
    ;
}


void _67user_delete_08(object _o_70140)
{
    object _0, _1, _2;
    

    /** execute.e:3890		do_delete_routine( 8, o )*/
    Ref(_o_70140);
    _67do_delete_routine(8LL, _o_70140);

    /** execute.e:3891	end procedure*/
    DeRef(_o_70140);
    return;
    ;
}


void _67user_delete_09(object _o_70145)
{
    object _0, _1, _2;
    

    /** execute.e:3895		do_delete_routine( 9, o )*/
    Ref(_o_70145);
    _67do_delete_routine(9LL, _o_70145);

    /** execute.e:3896	end procedure*/
    DeRef(_o_70145);
    return;
    ;
}


void _67user_delete_10(object _o_70150)
{
    object _0, _1, _2;
    

    /** execute.e:3900		do_delete_routine( 10, o )*/
    Ref(_o_70150);
    _67do_delete_routine(10LL, _o_70150);

    /** execute.e:3901	end procedure*/
    DeRef(_o_70150);
    return;
    ;
}


void _67user_delete_11(object _o_70155)
{
    object _0, _1, _2;
    

    /** execute.e:3905		do_delete_routine( 11, o )*/
    Ref(_o_70155);
    _67do_delete_routine(11LL, _o_70155);

    /** execute.e:3906	end procedure*/
    DeRef(_o_70155);
    return;
    ;
}


void _67user_delete_12(object _o_70160)
{
    object _0, _1, _2;
    

    /** execute.e:3910		do_delete_routine( 12, o )*/
    Ref(_o_70160);
    _67do_delete_routine(12LL, _o_70160);

    /** execute.e:3911	end procedure*/
    DeRef(_o_70160);
    return;
    ;
}


void _67user_delete_13(object _o_70165)
{
    object _0, _1, _2;
    

    /** execute.e:3915		do_delete_routine( 13, o )*/
    Ref(_o_70165);
    _67do_delete_routine(13LL, _o_70165);

    /** execute.e:3916	end procedure*/
    DeRef(_o_70165);
    return;
    ;
}


void _67user_delete_14(object _o_70170)
{
    object _0, _1, _2;
    

    /** execute.e:3920		do_delete_routine( 14, o )*/
    Ref(_o_70170);
    _67do_delete_routine(14LL, _o_70170);

    /** execute.e:3921	end procedure*/
    DeRef(_o_70170);
    return;
    ;
}


void _67user_delete_15(object _o_70175)
{
    object _0, _1, _2;
    

    /** execute.e:3925		do_delete_routine( 15, o )*/
    Ref(_o_70175);
    _67do_delete_routine(15LL, _o_70175);

    /** execute.e:3926	end procedure*/
    DeRef(_o_70175);
    return;
    ;
}


void _67user_delete_16(object _o_70180)
{
    object _0, _1, _2;
    

    /** execute.e:3930		do_delete_routine( 16, o )*/
    Ref(_o_70180);
    _67do_delete_routine(16LL, _o_70180);

    /** execute.e:3931	end procedure*/
    DeRef(_o_70180);
    return;
    ;
}


void _67user_delete_17(object _o_70185)
{
    object _0, _1, _2;
    

    /** execute.e:3935		do_delete_routine( 17, o )*/
    Ref(_o_70185);
    _67do_delete_routine(17LL, _o_70185);

    /** execute.e:3936	end procedure*/
    DeRef(_o_70185);
    return;
    ;
}


void _67user_delete_18(object _o_70191)
{
    object _0, _1, _2;
    

    /** execute.e:3940		do_delete_routine( 18, o )*/
    Ref(_o_70191);
    _67do_delete_routine(18LL, _o_70191);

    /** execute.e:3941	end procedure*/
    DeRef(_o_70191);
    return;
    ;
}


void _67user_delete_19(object _o_70196)
{
    object _0, _1, _2;
    

    /** execute.e:3945		do_delete_routine( 19, o )*/
    Ref(_o_70196);
    _67do_delete_routine(19LL, _o_70196);

    /** execute.e:3946	end procedure*/
    DeRef(_o_70196);
    return;
    ;
}


void _67user_delete_20(object _o_70202)
{
    object _0, _1, _2;
    

    /** execute.e:3950		do_delete_routine( 20, o )*/
    Ref(_o_70202);
    _67do_delete_routine(20LL, _o_70202);

    /** execute.e:3951	end procedure*/
    DeRef(_o_70202);
    return;
    ;
}


void _67opDELETE_ROUTINE()
{
    object _rid_70210 = NOVALUE;
    object _35086 = NOVALUE;
    object _35085 = NOVALUE;
    object _35084 = NOVALUE;
    object _35083 = NOVALUE;
    object _35082 = NOVALUE;
    object _35081 = NOVALUE;
    object _35074 = NOVALUE;
    object _35073 = NOVALUE;
    object _35071 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3956		a = Code[pc+1]*/
    _35071 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _67a_64878 = (object)*(((s1_ptr)_2)->base + _35071);
    if (!IS_ATOM_INT(_67a_64878)){
        _67a_64878 = (object)DBL_PTR(_67a_64878)->dbl;
    }

    /** execute.e:3958		integer rid = val[Code[pc+2]]*/
    _35073 = _67pc_64877 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _35074 = (object)*(((s1_ptr)_2)->base + _35073);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!IS_ATOM_INT(_35074)){
        _rid_70210 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_35074)->dbl));
    }
    else{
        _rid_70210 = (object)*(((s1_ptr)_2)->base + _35074);
    }
    if (!IS_ATOM_INT(_rid_70210))
    _rid_70210 = (object)DBL_PTR(_rid_70210)->dbl;

    /** execute.e:3959		b = find( rid, user_delete_rid )*/
    _67b_64879 = find_from(_rid_70210, _67user_delete_rid_70064, 1LL);

    /** execute.e:3960		if not b then*/
    if (_67b_64879 != 0)
    goto L1; // [50] 86

    /** execute.e:3961			b = find( -1, user_delete_rid )*/
    _67b_64879 = find_from(-1LL, _67user_delete_rid_70064, 1LL);

    /** execute.e:3962			if not b then*/
    if (_67b_64879 != 0)
    goto L2; // [66] 75

    /** execute.e:3963				RTFatal("Maximum of 20 user defined delete routines exceeded.")*/
    RefDS(_35080);
    _67RTFatal(_35080);
L2: 

    /** execute.e:3965			user_delete_rid[b] = rid*/
    _2 = (object)SEQ_PTR(_67user_delete_rid_70064);
    _2 = (object)(((s1_ptr)_2)->base + _67b_64879);
    *(intptr_t *)_2 = _rid_70210;
L1: 

    /** execute.e:3967		val[Code[pc+3]] = delete_routine( val[a], eu_delete_rid[b] )*/
    _35081 = _67pc_64877 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _35082 = (object)*(((s1_ptr)_2)->base + _35081);
    _2 = (object)SEQ_PTR(_67val_64887);
    _35083 = (object)*(((s1_ptr)_2)->base + _67a_64878);
    _2 = (object)SEQ_PTR(_67eu_delete_rid_70062);
    _35084 = (object)*(((s1_ptr)_2)->base + _67b_64879);
    DeRef(_35085);
    if( IS_ATOM_INT(_35083) ){
        _35085 = NewDouble( (eudouble) _35083 );
    }
    else {
        if( !UNIQUE(SEQ_PTR(_35083)) ){
            if( IS_ATOM_DBL( _35083 ) ){
                _35085 = NewDouble( DBL_PTR(_35083)->dbl );
            }
            else {
                RefDS(_35083);
                _35085 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_35083) ));
            }
        }
        else {
            _35085 = _35083;
        }
    }
    _1 = (object) _00[_35084].cleanup;
    if( _1 == 0 ){
        _1 = (object) TransAlloc( sizeof(struct cleanup) );
        _00[_35084].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _35084;
    ((cleanup_ptr)_1)->next = 0;
    if( IS_ATOM(_35085) ){
        if( IS_ATOM_INT(_35085) ){
            _35085 = NewDouble( (eudouble) _35083 );
        }
        if(DBL_PTR(_35085)->cleanup != 0 ){
            _1 = (object) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_35085)->cleanup );
        }
        else if( !UNIQUE(DBL_PTR(_35085)) ){
            DeRefDS(_35085);
            _35085 = NewDouble( DBL_PTR(_35085)->dbl );
        }
        DBL_PTR(_35085)->cleanup = (cleanup_ptr)_1;
    }
    else{
        if(SEQ_PTR(_35085)->cleanup != 0 ){
            _1 = (object) ChainDeleteRoutine( (cleanup_ptr)_1, SEQ_PTR(_35085)->cleanup );
        }
        else if( !UNIQUE(SEQ_PTR(_35085)) ){
            _35085 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_35085) ));
        }
        SEQ_PTR(_35085)->cleanup = (cleanup_ptr)_1;
    }
    _35083 = NOVALUE;
    _35084 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35082))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_35082)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _35082);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35085;
    if( _1 != _35085 ){
        DeRef(_1);
    }
    _35085 = NOVALUE;

    /** execute.e:3968		if sym_mode( a ) = M_TEMP then*/
    _35086 = _53sym_mode(_67a_64878);
    if (binary_op_a(NOTEQ, _35086, 3LL)){
        DeRef(_35086);
        _35086 = NOVALUE;
        goto L3; // [136] 153
    }
    DeRef(_35086);
    _35086 = NOVALUE;

    /** execute.e:3969			val[a] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_64887 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67a_64878);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
L3: 

    /** execute.e:3972		pc += 4*/
    _67pc_64877 = _67pc_64877 + 4LL;

    /** execute.e:3973	end procedure*/
    DeRef(_35081);
    _35081 = NOVALUE;
    _35074 = NOVALUE;
    _35082 = NOVALUE;
    DeRef(_35073);
    _35073 = NOVALUE;
    DeRef(_35071);
    _35071 = NOVALUE;
    return;
    ;
}


void _67opDELETE_OBJECT()
{
    object _35091 = NOVALUE;
    object _35090 = NOVALUE;
    object _35089 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3976		delete( val[Code[pc+1]] )*/
    _35089 = _67pc_64877 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _35090 = (object)*(((s1_ptr)_2)->base + _35089);
    _2 = (object)SEQ_PTR(_67val_64887);
    if (!IS_ATOM_INT(_35090)){
        _35091 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_35090)->dbl));
    }
    else{
        _35091 = (object)*(((s1_ptr)_2)->base + _35090);
    }
    if( IS_SEQUENCE(_35091) ){
        cleanup_sequence(SEQ_PTR(_35091));
    }
    if( IS_ATOM_DBL(_35091)){
        cleanup_double(DBL_PTR(_35091));
    }
    _35091 = NOVALUE;

    /** execute.e:3977		pc += 2*/
    _67pc_64877 = _67pc_64877 + 2LL;

    /** execute.e:3978	end procedure*/
    _35089 = NOVALUE;
    _35090 = NOVALUE;
    return;
    ;
}


void _67do_exec()
{
    object _op_70246 = NOVALUE;
    object _35100 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3982		keep_running = TRUE*/
    _67keep_running_64884 = _9TRUE_446;

    /** execute.e:3983		while keep_running do*/
L1: 
    if (_67keep_running_64884 == 0)
    {
        goto L2; // [17] 1910
    }
    else{
    }

    /** execute.e:3984			integer op = Code[pc]*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    _op_70246 = (object)*(((s1_ptr)_2)->base + _67pc_64877);
    if (!IS_ATOM_INT(_op_70246)){
        _op_70246 = (object)DBL_PTR(_op_70246)->dbl;
    }

    /** execute.e:3985			ifdef DEBUG then*/

    /** execute.e:3992			switch op do*/
    _0 = _op_70246;
    switch ( _0 ){ 

        /** execute.e:3993				case ABORT then*/
        case 126:

        /** execute.e:3994					opABORT()*/
        _67opABORT();
        goto L3; // [49] 1903

        /** execute.e:3996				case AND then*/
        case 8:

        /** execute.e:3997					opAND()*/
        _67opAND();
        goto L3; // [59] 1903

        /** execute.e:3999				case AND_BITS then*/
        case 56:

        /** execute.e:4000					opAND_BITS()*/
        _67opAND_BITS();
        goto L3; // [69] 1903

        /** execute.e:4002				case APPEND then*/
        case 35:

        /** execute.e:4003					opAPPEND()*/
        _67opAPPEND();
        goto L3; // [79] 1903

        /** execute.e:4005				case ARCTAN then*/
        case 73:

        /** execute.e:4006					opARCTAN()*/
        _67opARCTAN();
        goto L3; // [89] 1903

        /** execute.e:4008				case ASSIGN, ASSIGN_I then*/
        case 18:
        case 113:

        /** execute.e:4009					opASSIGN()*/
        _67opASSIGN();
        goto L3; // [101] 1903

        /** execute.e:4011				case ASSIGN_OP_SLICE then*/
        case 150:

        /** execute.e:4012					opASSIGN_OP_SLICE()*/
        _67opASSIGN_OP_SLICE();
        goto L3; // [111] 1903

        /** execute.e:4014				case ASSIGN_OP_SUBS then*/
        case 149:

        /** execute.e:4015					opASSIGN_OP_SUBS()*/
        _67opASSIGN_OP_SUBS();
        goto L3; // [121] 1903

        /** execute.e:4017				case ASSIGN_SLICE then*/
        case 45:

        /** execute.e:4018					opASSIGN_SLICE()*/
        _67opASSIGN_SLICE();
        goto L3; // [131] 1903

        /** execute.e:4020				case ASSIGN_SUBS, ASSIGN_SUBS_CHECK, ASSIGN_SUBS_I then*/
        case 16:
        case 84:
        case 118:

        /** execute.e:4021					opASSIGN_SUBS()*/
        _67opASSIGN_SUBS();
        goto L3; // [145] 1903

        /** execute.e:4023				case ATOM_CHECK then*/
        case 101:

        /** execute.e:4024					opATOM_CHECK()*/
        _67opATOM_CHECK();
        goto L3; // [155] 1903

        /** execute.e:4026				case BADRETURNF then*/
        case 43:

        /** execute.e:4027					opBADRETURNF()*/
        _67opBADRETURNF();
        goto L3; // [165] 1903

        /** execute.e:4029				case C_FUNC then*/
        case 133:

        /** execute.e:4030					opC_FUNC()*/
        _67opC_FUNC();
        goto L3; // [175] 1903

        /** execute.e:4032				case C_PROC then*/
        case 132:

        /** execute.e:4033					opC_PROC()*/
        _67opC_PROC();
        goto L3; // [185] 1903

        /** execute.e:4035				case CALL then*/
        case 129:

        /** execute.e:4036					opCALL()*/
        _67opCALL();
        goto L3; // [195] 1903

        /** execute.e:4038				case CALL_BACK_RETURN then*/
        case 135:

        /** execute.e:4039					opCALL_BACK_RETURN()*/
        _67opCALL_BACK_RETURN();
        goto L3; // [205] 1903

        /** execute.e:4041				case CALL_PROC, CALL_FUNC then*/
        case 136:
        case 137:

        /** execute.e:4042					opCALL_PROC()*/
        _67opCALL_PROC();
        goto L3; // [217] 1903

        /** execute.e:4044				case CASE then*/
        case 186:

        /** execute.e:4045					opCASE()*/
        _67opCASE();
        goto L3; // [227] 1903

        /** execute.e:4047				case CLEAR_SCREEN then*/
        case 59:

        /** execute.e:4048					opCLEAR_SCREEN()*/
        _67opCLEAR_SCREEN();
        goto L3; // [237] 1903

        /** execute.e:4050				case CLOSE then*/
        case 86:

        /** execute.e:4051					opCLOSE()*/
        _67opCLOSE();
        goto L3; // [247] 1903

        /** execute.e:4053				case COMMAND_LINE then*/
        case 100:

        /** execute.e:4054					opCOMMAND_LINE()*/
        _67opCOMMAND_LINE();
        goto L3; // [257] 1903

        /** execute.e:4056				case COMPARE then*/
        case 76:

        /** execute.e:4057					opCOMPARE()*/
        _67opCOMPARE();
        goto L3; // [267] 1903

        /** execute.e:4059				case CONCAT then*/
        case 15:

        /** execute.e:4060					opCONCAT()*/
        _67opCONCAT();
        goto L3; // [277] 1903

        /** execute.e:4062				case CONCAT_N then*/
        case 157:

        /** execute.e:4063					opCONCAT_N()*/
        _67opCONCAT_N();
        goto L3; // [287] 1903

        /** execute.e:4065				case COS then*/
        case 81:

        /** execute.e:4066					opCOS()*/
        _67opCOS();
        goto L3; // [297] 1903

        /** execute.e:4068				case DATE then*/
        case 69:

        /** execute.e:4069					opDATE()*/
        _67opDATE();
        goto L3; // [307] 1903

        /** execute.e:4071				case DIV2 then*/
        case 98:

        /** execute.e:4072					opDIV2()*/
        _67opDIV2();
        goto L3; // [317] 1903

        /** execute.e:4074				case DIVIDE then*/
        case 14:

        /** execute.e:4075					opDIVIDE()*/
        _67opDIVIDE();
        goto L3; // [327] 1903

        /** execute.e:4077				case ELSE, EXIT, ENDWHILE, RETRY then*/
        case 23:
        case 61:
        case 22:
        case 184:

        /** execute.e:4078					opELSE()*/
        _67opELSE();
        goto L3; // [343] 1903

        /** execute.e:4080				case ENDFOR_GENERAL, ENDFOR_UP, ENDFOR_DOWN, ENDFOR_INT_UP,*/
        case 39:
        case 49:
        case 50:
        case 48:
        case 52:
        case 55:

        /** execute.e:4082					opENDFOR_GENERAL()*/
        _67opENDFOR_GENERAL();
        goto L3; // [363] 1903

        /** execute.e:4084				case ENDFOR_INT_UP1 then*/
        case 54:

        /** execute.e:4085					opENDFOR_INT_UP1()*/
        _67opENDFOR_INT_UP1();
        goto L3; // [373] 1903

        /** execute.e:4087				case EQUAL then*/
        case 153:

        /** execute.e:4088					opEQUAL()*/
        _67opEQUAL();
        goto L3; // [383] 1903

        /** execute.e:4090				case EQUALS then*/
        case 3:

        /** execute.e:4091					opEQUALS()*/
        _67opEQUALS();
        goto L3; // [393] 1903

        /** execute.e:4093				case EQUALS_IFW, EQUALS_IFW_I then*/
        case 104:
        case 121:

        /** execute.e:4094					opEQUALS_IFW()*/
        _67opEQUALS_IFW();
        goto L3; // [405] 1903

        /** execute.e:4096				case EXIT_BLOCK then*/
        case 206:

        /** execute.e:4097					opEXIT_BLOCK()*/
        _67opEXIT_BLOCK();
        goto L3; // [415] 1903

        /** execute.e:4099				case FIND then*/
        case 77:

        /** execute.e:4100					opFIND()*/
        _67opFIND();
        goto L3; // [425] 1903

        /** execute.e:4102				case FIND_FROM then*/
        case 176:

        /** execute.e:4103					opFIND_FROM()*/
        _67opFIND_FROM();
        goto L3; // [435] 1903

        /** execute.e:4105				case FLOOR then*/
        case 83:

        /** execute.e:4106					opFLOOR()*/
        _67opFLOOR();
        goto L3; // [445] 1903

        /** execute.e:4108				case FLOOR_DIV then*/
        case 63:

        /** execute.e:4109					opFLOOR_DIV()*/
        _67opFLOOR_DIV();
        goto L3; // [455] 1903

        /** execute.e:4111				case FLOOR_DIV2 then*/
        case 66:

        /** execute.e:4112					opFLOOR_DIV2()*/
        _67opFLOOR_DIV2();
        goto L3; // [465] 1903

        /** execute.e:4114				case FOR, FOR_I then*/
        case 21:
        case 125:

        /** execute.e:4115					opFOR()*/
        _67opFOR();
        goto L3; // [477] 1903

        /** execute.e:4117				case GET_KEY then*/
        case 79:

        /** execute.e:4118					opGET_KEY()*/
        _67opGET_KEY();
        goto L3; // [487] 1903

        /** execute.e:4120				case GETC then*/
        case 33:

        /** execute.e:4121					opGETC()*/
        _67opGETC();
        goto L3; // [497] 1903

        /** execute.e:4123				case GETENV then*/
        case 91:

        /** execute.e:4124					opGETENV()*/
        _67opGETENV();
        goto L3; // [507] 1903

        /** execute.e:4126				case GETS then*/
        case 17:

        /** execute.e:4127					opGETS()*/
        _67opGETS();
        goto L3; // [517] 1903

        /** execute.e:4129				case GLABEL then*/
        case 189:

        /** execute.e:4130					opGLABEL()*/
        _67opGLABEL();
        goto L3; // [527] 1903

        /** execute.e:4132				case GLOBAL_INIT_CHECK, PRIVATE_INIT_CHECK then*/
        case 109:
        case 30:

        /** execute.e:4133					opGLOBAL_INIT_CHECK()*/
        _67opGLOBAL_INIT_CHECK();
        goto L3; // [539] 1903

        /** execute.e:4135				case GOTO then*/
        case 188:

        /** execute.e:4136					opGOTO()*/
        _67opGOTO();
        goto L3; // [549] 1903

        /** execute.e:4138				case GREATER then*/
        case 6:

        /** execute.e:4139					opGREATER()*/
        _67opGREATER();
        goto L3; // [559] 1903

        /** execute.e:4141				case GREATER_IFW, GREATER_IFW_I then*/
        case 107:
        case 124:

        /** execute.e:4142					opGREATER_IFW()*/
        _67opGREATER_IFW();
        goto L3; // [571] 1903

        /** execute.e:4144				case GREATEREQ then*/
        case 2:

        /** execute.e:4145					opGREATEREQ()*/
        _67opGREATEREQ();
        goto L3; // [581] 1903

        /** execute.e:4147				case GREATEREQ_IFW, GREATEREQ_IFW_I then*/
        case 103:
        case 120:

        /** execute.e:4148					opGREATEREQ_IFW()*/
        _67opGREATEREQ_IFW();
        goto L3; // [593] 1903

        /** execute.e:4150				case HASH then*/
        case 194:

        /** execute.e:4151					opHASH()*/
        _67opHASH();
        goto L3; // [603] 1903

        /** execute.e:4153				case HEAD then*/
        case 198:

        /** execute.e:4154					opHEAD()*/
        _67opHEAD();
        goto L3; // [613] 1903

        /** execute.e:4156				case IF then*/
        case 20:

        /** execute.e:4157					opIF()*/
        _67opIF();
        goto L3; // [623] 1903

        /** execute.e:4159				case INSERT then*/
        case 191:

        /** execute.e:4160					opINSERT()*/
        _67opINSERT();
        goto L3; // [633] 1903

        /** execute.e:4162				case INTEGER_CHECK then*/
        case 96:

        /** execute.e:4163					opINTEGER_CHECK()*/
        _67opINTEGER_CHECK();
        goto L3; // [643] 1903

        /** execute.e:4165				case IS_A_SEQUENCE then*/
        case 68:

        /** execute.e:4166					opIS_A_SEQUENCE()*/
        _67opIS_A_SEQUENCE();
        goto L3; // [653] 1903

        /** execute.e:4168				case IS_AN_ATOM then*/
        case 67:

        /** execute.e:4169					opIS_AN_ATOM()*/
        _67opIS_AN_ATOM();
        goto L3; // [663] 1903

        /** execute.e:4171				case IS_AN_INTEGER then*/
        case 94:

        /** execute.e:4172					opIS_AN_INTEGER()*/
        _67opIS_AN_INTEGER();
        goto L3; // [673] 1903

        /** execute.e:4174				case IS_AN_OBJECT then*/
        case 40:

        /** execute.e:4175					opIS_AN_OBJECT()*/
        _67opIS_AN_OBJECT();
        goto L3; // [683] 1903

        /** execute.e:4177				case LENGTH then*/
        case 42:

        /** execute.e:4178					opLENGTH()*/
        _67opLENGTH();
        goto L3; // [693] 1903

        /** execute.e:4180				case LESS then*/
        case 1:

        /** execute.e:4181					opLESS()*/
        _67opLESS();
        goto L3; // [703] 1903

        /** execute.e:4183				case LESS_IFW_I, LESS_IFW then*/
        case 119:
        case 102:

        /** execute.e:4184					opLESS_IFW()*/
        _67opLESS_IFW();
        goto L3; // [715] 1903

        /** execute.e:4186				case LESSEQ then*/
        case 5:

        /** execute.e:4187					opLESSEQ()*/
        _67opLESSEQ();
        goto L3; // [725] 1903

        /** execute.e:4189				case LESSEQ_IFW, LESSEQ_IFW_I then*/
        case 106:
        case 123:

        /** execute.e:4190					opLESSEQ_IFW()*/
        _67opLESSEQ_IFW();
        goto L3; // [737] 1903

        /** execute.e:4192				case LHS_SUBS then*/
        case 95:

        /** execute.e:4193					opLHS_SUBS()*/
        _67opLHS_SUBS();
        goto L3; // [747] 1903

        /** execute.e:4195				case LHS_SUBS1 then*/
        case 161:

        /** execute.e:4196					opLHS_SUBS1()*/
        _67opLHS_SUBS1();
        goto L3; // [757] 1903

        /** execute.e:4198				case LHS_SUBS1_COPY then*/
        case 166:

        /** execute.e:4199					opLHS_SUBS1_COPY()*/
        _67opLHS_SUBS1_COPY();
        goto L3; // [767] 1903

        /** execute.e:4201				case LOG then*/
        case 74:

        /** execute.e:4202					opLOG()*/
        _67opLOG();
        goto L3; // [777] 1903

        /** execute.e:4204				case MACHINE_FUNC then*/
        case 111:

        /** execute.e:4205					opMACHINE_FUNC()*/
        _67opMACHINE_FUNC();
        goto L3; // [787] 1903

        /** execute.e:4207				case MACHINE_PROC then*/
        case 112:

        /** execute.e:4208					opMACHINE_PROC()*/
        _67opMACHINE_PROC();
        goto L3; // [797] 1903

        /** execute.e:4210				case MATCH then*/
        case 78:

        /** execute.e:4211					opMATCH()*/
        _67opMATCH();
        goto L3; // [807] 1903

        /** execute.e:4213				case MATCH_FROM then*/
        case 177:

        /** execute.e:4214					opMATCH_FROM()*/
        _67opMATCH_FROM();
        goto L3; // [817] 1903

        /** execute.e:4216				case MEM_COPY then*/
        case 130:

        /** execute.e:4217					opMEM_COPY()*/
        _67opMEM_COPY();
        goto L3; // [827] 1903

        /** execute.e:4219				case MEM_SET then*/
        case 131:

        /** execute.e:4220					opMEM_SET()*/
        _67opMEM_SET();
        goto L3; // [837] 1903

        /** execute.e:4222				case MINUS, MINUS_I then*/
        case 10:
        case 116:

        /** execute.e:4223					opMINUS()*/
        _67opMINUS();
        goto L3; // [849] 1903

        /** execute.e:4225				case MULTIPLY then*/
        case 13:

        /** execute.e:4226					opMULTIPLY()*/
        _67opMULTIPLY();
        goto L3; // [859] 1903

        /** execute.e:4228				case NOP2, SC2_NULL, ASSIGN_SUBS2, PLATFORM, END_PARAM_CHECK,*/
        case 110:
        case 145:
        case 148:
        case 155:
        case 156:
        case 158:
        case 159:

        /** execute.e:4230					opNOP2()*/
        _67opNOP2();
        goto L3; // [881] 1903

        /** execute.e:4232				case NOPSWITCH then*/
        case 187:

        /** execute.e:4233					opNOPSWITCH()*/
        _67opNOPSWITCH();
        goto L3; // [891] 1903

        /** execute.e:4235				case NOT then*/
        case 7:

        /** execute.e:4236					opNOT()*/
        _67opNOT();
        goto L3; // [901] 1903

        /** execute.e:4238				case NOT_BITS then*/
        case 51:

        /** execute.e:4239					opNOT_BITS()*/
        _67opNOT_BITS();
        goto L3; // [911] 1903

        /** execute.e:4241				case NOT_IFW then*/
        case 108:

        /** execute.e:4242					opNOT_IFW()*/
        _67opNOT_IFW();
        goto L3; // [921] 1903

        /** execute.e:4244				case NOTEQ then*/
        case 4:

        /** execute.e:4245					opNOTEQ()*/
        _67opNOTEQ();
        goto L3; // [931] 1903

        /** execute.e:4247				case NOTEQ_IFW, NOTEQ_IFW_I then*/
        case 105:
        case 122:

        /** execute.e:4248					opNOTEQ_IFW()*/
        _67opNOTEQ_IFW();
        goto L3; // [943] 1903

        /** execute.e:4250				case OPEN then*/
        case 37:

        /** execute.e:4251					opOPEN()*/
        _67opOPEN();
        goto L3; // [953] 1903

        /** execute.e:4253				case OPTION_SWITCHES then*/
        case 183:

        /** execute.e:4254					opOPTION_SWITCHES()*/
        _67opOPTION_SWITCHES();
        goto L3; // [963] 1903

        /** execute.e:4256				case OR then*/
        case 9:

        /** execute.e:4257					opOR()*/
        _67opOR();
        goto L3; // [973] 1903

        /** execute.e:4259				case OR_BITS then*/
        case 24:

        /** execute.e:4260					opOR_BITS()*/
        _67opOR_BITS();
        goto L3; // [983] 1903

        /** execute.e:4262				case PASSIGN_OP_SLICE then*/
        case 165:

        /** execute.e:4263					opPASSIGN_OP_SLICE()*/
        _67opPASSIGN_OP_SLICE();
        goto L3; // [993] 1903

        /** execute.e:4265				case PASSIGN_OP_SUBS then*/
        case 164:

        /** execute.e:4266					opPASSIGN_OP_SUBS()*/
        _67opPASSIGN_OP_SUBS();
        goto L3; // [1003] 1903

        /** execute.e:4268				case PASSIGN_SLICE then*/
        case 163:

        /** execute.e:4269					opPASSIGN_SLICE()*/
        _67opPASSIGN_SLICE();
        goto L3; // [1013] 1903

        /** execute.e:4271				case PASSIGN_SUBS then*/
        case 162:

        /** execute.e:4272					opPASSIGN_SUBS()*/
        _67opPASSIGN_SUBS();
        goto L3; // [1023] 1903

        /** execute.e:4274				case PEEK then*/
        case 127:

        /** execute.e:4275					opPEEK()*/
        _67opPEEK();
        goto L3; // [1033] 1903

        /** execute.e:4277				case PEEK_STRING then*/
        case 182:

        /** execute.e:4278					opPEEK_STRING()*/
        _67opPEEK_STRING();
        goto L3; // [1043] 1903

        /** execute.e:4280				case PEEK2S then*/
        case 179:

        /** execute.e:4281					opPEEK2S()*/
        _67opPEEK2S();
        goto L3; // [1053] 1903

        /** execute.e:4283				case PEEK2U then*/
        case 180:

        /** execute.e:4284					opPEEK2U()*/
        _67opPEEK2U();
        goto L3; // [1063] 1903

        /** execute.e:4286				case PEEK4S then*/
        case 139:

        /** execute.e:4287					opPEEK4S()*/
        _67opPEEK4S();
        goto L3; // [1073] 1903

        /** execute.e:4289				case PEEK4U then*/
        case 140:

        /** execute.e:4290					opPEEK4U()*/
        _67opPEEK4U();
        goto L3; // [1083] 1903

        /** execute.e:4292				case PEEK8S then*/
        case 213:

        /** execute.e:4293					opPEEK8S()*/
        _67opPEEK8S();
        goto L3; // [1093] 1903

        /** execute.e:4295				case PEEK8U then*/
        case 214:

        /** execute.e:4296					opPEEK8U()*/
        _67opPEEK8U();
        goto L3; // [1103] 1903

        /** execute.e:4298				case PEEKS then*/
        case 181:

        /** execute.e:4299					opPEEKS()*/
        _67opPEEKS();
        goto L3; // [1113] 1903

        /** execute.e:4301				case PLENGTH then*/
        case 160:

        /** execute.e:4302					opPLENGTH()*/
        _67opPLENGTH();
        goto L3; // [1123] 1903

        /** execute.e:4304				case PLUS, PLUS_I then*/
        case 11:
        case 115:

        /** execute.e:4305					opPLUS()*/
        _67opPLUS();
        goto L3; // [1135] 1903

        /** execute.e:4307				case PLUS1, PLUS1_I then*/
        case 93:
        case 117:

        /** execute.e:4308					opPLUS1()*/
        _67opPLUS1();
        goto L3; // [1147] 1903

        /** execute.e:4310				case POKE then*/
        case 128:

        /** execute.e:4311					opPOKE()*/
        _67opPOKE();
        goto L3; // [1157] 1903

        /** execute.e:4313				case POKE2 then*/
        case 178:

        /** execute.e:4314					opPOKE2()*/
        _67opPOKE2();
        goto L3; // [1167] 1903

        /** execute.e:4316				case POKE4 then*/
        case 138:

        /** execute.e:4317					opPOKE4()*/
        _67opPOKE4();
        goto L3; // [1177] 1903

        /** execute.e:4319				case POKE8 then*/
        case 212:

        /** execute.e:4320					opPOKE8()*/
        _67opPOKE8();
        goto L3; // [1187] 1903

        /** execute.e:4322				case POKE_POINTER then*/
        case 215:

        /** execute.e:4323					opPOKE4()*/
        _67opPOKE4();
        goto L3; // [1197] 1903

        /** execute.e:4325				case PEEK_POINTER then*/
        case 216:

        /** execute.e:4326					opPEEK4U()*/
        _67opPEEK4U();
        goto L3; // [1207] 1903

        /** execute.e:4328				case POSITION then*/
        case 60:

        /** execute.e:4329					opPOSITION()*/
        _67opPOSITION();
        goto L3; // [1217] 1903

        /** execute.e:4331				case POWER then*/
        case 72:

        /** execute.e:4332					opPOWER()*/
        _67opPOWER();
        goto L3; // [1227] 1903

        /** execute.e:4334				case PREPEND then*/
        case 57:

        /** execute.e:4335					opPREPEND()*/
        _67opPREPEND();
        goto L3; // [1237] 1903

        /** execute.e:4337				case PRINT then*/
        case 19:

        /** execute.e:4338					opPRINT()*/
        _67opPRINT();
        goto L3; // [1247] 1903

        /** execute.e:4340				case PRINTF then*/
        case 38:

        /** execute.e:4341					opPRINTF()*/
        _67opPRINTF();
        goto L3; // [1257] 1903

        /** execute.e:4343				case PROC_TAIL then*/
        case 203:

        /** execute.e:4344					opPROC_TAIL()*/
        _67opPROC_TAIL();
        goto L3; // [1267] 1903

        /** execute.e:4346				case PROC then*/
        case 27:

        /** execute.e:4347					opPROC()*/
        _67opPROC();
        goto L3; // [1277] 1903

        /** execute.e:4349				case PROFILE, DISPLAY_VAR, ERASE_PRIVATE_NAMES, ERASE_SYMBOL then*/
        case 151:
        case 87:
        case 88:
        case 90:

        /** execute.e:4350					opPROFILE()*/
        _67opPROFILE();
        goto L3; // [1293] 1903

        /** execute.e:4352				case PUTS then*/
        case 44:

        /** execute.e:4353					opPUTS()*/
        _67opPUTS();
        goto L3; // [1303] 1903

        /** execute.e:4355				case QPRINT then*/
        case 36:

        /** execute.e:4356					opQPRINT()*/
        _67opQPRINT();
        goto L3; // [1313] 1903

        /** execute.e:4358				case RAND then*/
        case 62:

        /** execute.e:4359					opRAND()*/
        _67opRAND();
        goto L3; // [1323] 1903

        /** execute.e:4361				case REMAINDER then*/
        case 71:

        /** execute.e:4362					opREMAINDER()*/
        _67opREMAINDER();
        goto L3; // [1333] 1903

        /** execute.e:4364				case REMOVE then*/
        case 200:

        /** execute.e:4365					opREMOVE()*/
        _67opREMOVE();
        goto L3; // [1343] 1903

        /** execute.e:4367				case REPEAT then*/
        case 32:

        /** execute.e:4368					opREPEAT()*/
        _67opREPEAT();
        goto L3; // [1353] 1903

        /** execute.e:4370				case REPLACE then*/
        case 201:

        /** execute.e:4371					opREPLACE()*/
        _67opREPLACE();
        goto L3; // [1363] 1903

        /** execute.e:4373				case RETURNF then*/
        case 28:

        /** execute.e:4374					opRETURNF()*/
        _67opRETURNF();
        goto L3; // [1373] 1903

        /** execute.e:4376				case RETURNP then*/
        case 29:

        /** execute.e:4377					opRETURNP()*/
        _67opRETURNP();
        goto L3; // [1383] 1903

        /** execute.e:4379				case RETURNT then*/
        case 34:

        /** execute.e:4380					opRETURNT()*/
        _67opRETURNT();
        goto L3; // [1393] 1903

        /** execute.e:4382				case RHS_SLICE then*/
        case 46:

        /** execute.e:4383					opRHS_SLICE()*/
        _67opRHS_SLICE();
        goto L3; // [1403] 1903

        /** execute.e:4385				case RHS_SUBS, RHS_SUBS_CHECK, RHS_SUBS_I then*/
        case 25:
        case 92:
        case 114:

        /** execute.e:4386					opRHS_SUBS()*/
        _67opRHS_SUBS();
        goto L3; // [1417] 1903

        /** execute.e:4388				case RIGHT_BRACE_2 then*/
        case 85:

        /** execute.e:4389					opRIGHT_BRACE_2()*/
        _67opRIGHT_BRACE_2();
        goto L3; // [1427] 1903

        /** execute.e:4391				case RIGHT_BRACE_N then*/
        case 31:

        /** execute.e:4392					opRIGHT_BRACE_N()*/
        _67opRIGHT_BRACE_N();
        goto L3; // [1437] 1903

        /** execute.e:4394				case ROUTINE_ID then*/
        case 134:

        /** execute.e:4395					opROUTINE_ID()*/
        _67opROUTINE_ID();
        goto L3; // [1447] 1903

        /** execute.e:4397				case SC1_AND then*/
        case 141:

        /** execute.e:4398					opSC1_AND()*/
        _67opSC1_AND();
        goto L3; // [1457] 1903

        /** execute.e:4400				case SC1_AND_IF then*/
        case 146:

        /** execute.e:4401					opSC1_AND_IF()*/
        _67opSC1_AND_IF();
        goto L3; // [1467] 1903

        /** execute.e:4403				case SC1_OR then*/
        case 143:

        /** execute.e:4404					opSC1_OR()*/
        _67opSC1_OR();
        goto L3; // [1477] 1903

        /** execute.e:4406				case SC1_OR_IF then*/
        case 147:

        /** execute.e:4407					opSC1_OR_IF()*/
        _67opSC1_OR_IF();
        goto L3; // [1487] 1903

        /** execute.e:4409				case SC2_OR, SC2_AND then*/
        case 144:
        case 142:

        /** execute.e:4410					opSC2_OR()*/
        _67opSC2_OR();
        goto L3; // [1499] 1903

        /** execute.e:4412				case SEQUENCE_CHECK then*/
        case 97:

        /** execute.e:4413					opSEQUENCE_CHECK()*/
        _67opSEQUENCE_CHECK();
        goto L3; // [1509] 1903

        /** execute.e:4415				case SIN then*/
        case 80:

        /** execute.e:4416					opSIN()*/
        _67opSIN();
        goto L3; // [1519] 1903

        /** execute.e:4418				case SPACE_USED then*/
        case 75:

        /** execute.e:4419					opSPACE_USED()*/
        _67opSPACE_USED();
        goto L3; // [1529] 1903

        /** execute.e:4421				case SPLICE then*/
        case 190:

        /** execute.e:4422					opSPLICE()*/
        _67opSPLICE();
        goto L3; // [1539] 1903

        /** execute.e:4424				case SPRINTF then*/
        case 53:

        /** execute.e:4425					opSPRINTF()*/
        _67opSPRINTF();
        goto L3; // [1549] 1903

        /** execute.e:4427				case SQRT then*/
        case 41:

        /** execute.e:4428					opSQRT()*/
        _67opSQRT();
        goto L3; // [1559] 1903

        /** execute.e:4430				case STARTLINE then*/
        case 58:

        /** execute.e:4431					opSTARTLINE()*/
        _67opSTARTLINE();
        goto L3; // [1569] 1903

        /** execute.e:4433				case SWITCH, SWITCH_I then*/
        case 185:
        case 193:

        /** execute.e:4434					opSWITCH()*/
        _67opSWITCH();
        goto L3; // [1581] 1903

        /** execute.e:4436				case SWITCH_SPI then*/
        case 192:

        /** execute.e:4437					opSWITCH_SPI()*/
        _67opSWITCH_SPI();
        goto L3; // [1591] 1903

        /** execute.e:4439				case SWITCH_RT then*/
        case 202:

        /** execute.e:4440					opSWITCH_RT()*/
        _67opSWITCH_RT();
        goto L3; // [1601] 1903

        /** execute.e:4442				case SYSTEM then*/
        case 99:

        /** execute.e:4443					opSYSTEM()*/
        _67opSYSTEM();
        goto L3; // [1611] 1903

        /** execute.e:4445				case SYSTEM_EXEC then*/
        case 154:

        /** execute.e:4446					opSYSTEM_EXEC()*/
        _67opSYSTEM_EXEC();
        goto L3; // [1621] 1903

        /** execute.e:4448				case TAIL then*/
        case 199:

        /** execute.e:4449					opTAIL()*/
        _67opTAIL();
        goto L3; // [1631] 1903

        /** execute.e:4451				case TAN then*/
        case 82:

        /** execute.e:4452					opTAN()*/
        _67opTAN();
        goto L3; // [1641] 1903

        /** execute.e:4454				case TASK_CLOCK_START then*/
        case 175:

        /** execute.e:4455					opTASK_CLOCK_START()*/
        _67opTASK_CLOCK_START();
        goto L3; // [1651] 1903

        /** execute.e:4457				case TASK_CLOCK_STOP then*/
        case 174:

        /** execute.e:4458					opTASK_CLOCK_STOP()*/
        _67opTASK_CLOCK_STOP();
        goto L3; // [1661] 1903

        /** execute.e:4460				case TASK_CREATE then*/
        case 167:

        /** execute.e:4461					opTASK_CREATE()*/
        _67opTASK_CREATE();
        goto L3; // [1671] 1903

        /** execute.e:4463				case TASK_LIST then*/
        case 172:

        /** execute.e:4464					opTASK_LIST()*/
        _67opTASK_LIST();
        goto L3; // [1681] 1903

        /** execute.e:4466				case TASK_SCHEDULE then*/
        case 168:

        /** execute.e:4467					opTASK_SCHEDULE()*/
        _67opTASK_SCHEDULE();
        goto L3; // [1691] 1903

        /** execute.e:4469				case TASK_SELF then*/
        case 170:

        /** execute.e:4470					opTASK_SELF()*/
        _67opTASK_SELF();
        goto L3; // [1701] 1903

        /** execute.e:4472				case TASK_STATUS then*/
        case 173:

        /** execute.e:4473					opTASK_STATUS()*/
        _67opTASK_STATUS();
        goto L3; // [1711] 1903

        /** execute.e:4475				case TASK_SUSPEND then*/
        case 171:

        /** execute.e:4476					opTASK_SUSPEND()*/
        _67opTASK_SUSPEND();
        goto L3; // [1721] 1903

        /** execute.e:4478				case TASK_YIELD then*/
        case 169:

        /** execute.e:4479					opTASK_YIELD()*/
        _67opTASK_YIELD();
        goto L3; // [1731] 1903

        /** execute.e:4481				case TIME then*/
        case 70:

        /** execute.e:4482					opTIME()*/
        _67opTIME();
        goto L3; // [1741] 1903

        /** execute.e:4484				case TRACE then*/
        case 64:

        /** execute.e:4485					opTRACE()*/
        _67opTRACE();
        goto L3; // [1751] 1903

        /** execute.e:4487				case TYPE_CHECK then*/
        case 65:

        /** execute.e:4488					opTYPE_CHECK()*/
        _67opTYPE_CHECK();
        goto L3; // [1761] 1903

        /** execute.e:4490				case UMINUS then*/
        case 12:

        /** execute.e:4491					opUMINUS()*/
        _67opUMINUS();
        goto L3; // [1771] 1903

        /** execute.e:4493				case UPDATE_GLOBALS then*/
        case 89:

        /** execute.e:4494					opUPDATE_GLOBALS()*/
        _67opUPDATE_GLOBALS();
        goto L3; // [1781] 1903

        /** execute.e:4496				case WHILE then*/
        case 47:

        /** execute.e:4497					opWHILE()*/
        _67opWHILE();
        goto L3; // [1791] 1903

        /** execute.e:4499				case XOR then*/
        case 152:

        /** execute.e:4500					opXOR()*/
        _67opXOR();
        goto L3; // [1801] 1903

        /** execute.e:4502				case XOR_BITS then*/
        case 26:

        /** execute.e:4503					opXOR_BITS()*/
        _67opXOR_BITS();
        goto L3; // [1811] 1903

        /** execute.e:4505				case DELETE_ROUTINE then*/
        case 204:

        /** execute.e:4506					opDELETE_ROUTINE()*/
        _67opDELETE_ROUTINE();
        goto L3; // [1821] 1903

        /** execute.e:4508				case DELETE_OBJECT then*/
        case 205:

        /** execute.e:4509					opDELETE_OBJECT()*/
        _67opDELETE_OBJECT();
        goto L3; // [1831] 1903

        /** execute.e:4511				case REF_TEMP then*/
        case 207:

        /** execute.e:4512					pc += 2*/
        _67pc_64877 = _67pc_64877 + 2LL;
        goto L3; // [1845] 1903

        /** execute.e:4513				case DEREF_TEMP, NOVALUE_TEMP then*/
        case 208:
        case 209:

        /** execute.e:4514					opDEREF_TEMP()*/
        _67opDEREF_TEMP();
        goto L3; // [1857] 1903

        /** execute.e:4516				case COVERAGE_LINE then*/
        case 210:

        /** execute.e:4517					opCOVERAGE_LINE()*/
        _67opCOVERAGE_LINE();
        goto L3; // [1867] 1903

        /** execute.e:4519				case COVERAGE_ROUTINE then*/
        case 211:

        /** execute.e:4520					opCOVERAGE_ROUTINE()*/
        _67opCOVERAGE_ROUTINE();
        goto L3; // [1877] 1903

        /** execute.e:4522				case SIZEOF then*/
        case 217:

        /** execute.e:4523					opSIZEOF()*/
        _67opSIZEOF();
        goto L3; // [1887] 1903

        /** execute.e:4525				case else*/
        default:

        /** execute.e:4526					RTFatal( sprintf("Unknown opcode: %d", op ) )*/
        _35100 = EPrintf(-9999999, _35099, _op_70246);
        _67RTFatal(_35100);
        _35100 = NOVALUE;
    ;}L3: 

    /** execute.e:4528		end while*/
    goto L1; // [1907] 15
L2: 

    /** execute.e:4529		keep_running = TRUE -- so higher-level do_exec() will keep running*/
    _67keep_running_64884 = _9TRUE_446;

    /** execute.e:4530	end procedure*/
    return;
    ;
}


void _67InitBackEnd()
{
    object _name_70651 = NOVALUE;
    object _len_70652 = NOVALUE;
    object _35111 = NOVALUE;
    object _35110 = NOVALUE;
    object _35109 = NOVALUE;
    object _35108 = NOVALUE;
    object _35107 = NOVALUE;
    object _35105 = NOVALUE;
    object _35104 = NOVALUE;
    object _35103 = NOVALUE;
    object _35102 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:4540		integer len = length(val)*/
    if (IS_SEQUENCE(_67val_64887)){
            _len_70652 = SEQ_PTR(_67val_64887)->length;
    }
    else {
        _len_70652 = 1;
    }

    /** execute.e:4541		val = val & repeat(0, length(SymTab)-length(val))*/
    if (IS_SEQUENCE(_13SymTab_11316)){
            _35102 = SEQ_PTR(_13SymTab_11316)->length;
    }
    else {
        _35102 = 1;
    }
    if (IS_SEQUENCE(_67val_64887)){
            _35103 = SEQ_PTR(_67val_64887)->length;
    }
    else {
        _35103 = 1;
    }
    _35104 = _35102 - _35103;
    _35102 = NOVALUE;
    _35103 = NOVALUE;
    _35105 = Repeat(0LL, _35104);
    _35104 = NOVALUE;
    Concat((object_ptr)&_67val_64887, _67val_64887, _35105);
    DeRefDS(_35105);
    _35105 = NOVALUE;

    /** execute.e:4542		for i = len + 1 to length(SymTab) do*/
    _35107 = _len_70652 + 1;
    if (IS_SEQUENCE(_13SymTab_11316)){
            _35108 = SEQ_PTR(_13SymTab_11316)->length;
    }
    else {
        _35108 = 1;
    }
    {
        object _i_70661;
        _i_70661 = _35107;
L1: 
        if (_i_70661 > _35108){
            goto L2; // [45] 94
        }

        /** execute.e:4543			val[i] = SymTab[i][S_OBJ] -- might be NOVALUE*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _35109 = (object)*(((s1_ptr)_2)->base + _i_70661);
        _2 = (object)SEQ_PTR(_35109);
        _35110 = (object)*(((s1_ptr)_2)->base + 1LL);
        _35109 = NOVALUE;
        Ref(_35110);
        _2 = (object)SEQ_PTR(_67val_64887);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_64887 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_70661);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _35110;
        if( _1 != _35110 ){
            DeRef(_1);
        }
        _35110 = NOVALUE;

        /** execute.e:4544			SymTab[i][S_OBJ] = 0*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_70661 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0LL;
        DeRef(_1);
        _35111 = NOVALUE;

        /** execute.e:4545		end for*/
        _i_70661 = _i_70661 + 1LL;
        goto L1; // [89] 52
L2: 
        ;
    }

    /** execute.e:4546	end procedure*/
    DeRef(_35107);
    _35107 = NOVALUE;
    return;
    ;
}


void _67fake_init(object _ignore_70675)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_ignore_70675)) {
        _1 = (object)(DBL_PTR(_ignore_70675)->dbl);
        DeRefDS(_ignore_70675);
        _ignore_70675 = _1;
    }

    /** execute.e:4549		intoptions()*/
    _68intoptions();

    /** execute.e:4550	end procedure*/
    return;
    ;
}


void _67Execute(object _proc_70684, object _start_index_70685)
{
    object _35120 = NOVALUE;
    object _35116 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_proc_70684)) {
        _1 = (object)(DBL_PTR(_proc_70684)->dbl);
        DeRefDS(_proc_70684);
        _proc_70684 = _1;
    }
    if (!IS_ATOM_INT(_start_index_70685)) {
        _1 = (object)(DBL_PTR(_start_index_70685)->dbl);
        DeRefDS(_start_index_70685);
        _start_index_70685 = _1;
    }

    /** execute.e:4555		InitBackEnd()*/
    _67InitBackEnd();

    /** execute.e:4556		if current_task = -1 then*/
    if (_67current_task_64894 != -1LL)
    goto L1; // [13] 23

    /** execute.e:4557		current_task = 1*/
    _67current_task_64894 = 1LL;
L1: 

    /** execute.e:4559		if not length(call_stack) then*/
    if (IS_SEQUENCE(_67call_stack_64895)){
            _35116 = SEQ_PTR(_67call_stack_64895)->length;
    }
    else {
        _35116 = 1;
    }
    if (_35116 != 0)
    goto L2; // [30] 40
    _35116 = NOVALUE;

    /** execute.e:4560		call_stack = {proc}*/
    _0 = _67call_stack_64895;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _proc_70684;
    _67call_stack_64895 = MAKE_SEQ(_1);
    DeRefDS(_0);
L2: 

    /** execute.e:4562		if pc = -1 then*/
    if (_67pc_64877 != -1LL)
    goto L3; // [44] 54

    /** execute.e:4563		pc = start_index*/
    _67pc_64877 = _start_index_70685;
L3: 

    /** execute.e:4565		Code = SymTab[proc][S_CODE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _35120 = (object)*(((s1_ptr)_2)->base + _proc_70684);
    DeRef(_12Code_20315);
    _2 = (object)SEQ_PTR(_35120);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    Ref(_12Code_20315);
    _35120 = NOVALUE;

    /** execute.e:4566		do_exec()*/
    _67do_exec();

    /** execute.e:4567		if repl then*/

    /** execute.e:4570	end procedure*/
    return;
    ;
}


void _67BackEnd(object _ignore_70707)
{
    object _0, _1, _2;
    

    /** execute.e:4577		Execute(TopLevelSub, 1)*/
    _67Execute(_12TopLevelSub_20233, 1LL);

    /** execute.e:4578	end procedure*/
    return;
    ;
}



// 0xD79F1FEA
