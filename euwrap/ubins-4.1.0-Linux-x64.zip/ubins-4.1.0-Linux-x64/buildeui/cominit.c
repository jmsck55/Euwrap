// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _47add_options(object _new_options_49804)
{
    object _0, _1, _2;
    

    /** cominit.e:65		options = splice(options, new_options, COMMON_OPTIONS_SPLICE_IDX)*/
    {
        s1_ptr assign_space;
        insert_pos = 16LL;
        if (insert_pos <= 0) {
            Concat(&_47options_49800,_new_options_49804,_47options_49800);
        }
        else if (insert_pos > SEQ_PTR(_47options_49800)->length){
            Concat(&_47options_49800,_47options_49800,_new_options_49804);
        }
        else if (IS_SEQUENCE(_new_options_49804)) {
            if( _47options_49800 != _47options_49800 || SEQ_PTR( _47options_49800 )->ref != 1 ){
                DeRef( _47options_49800 );
                RefDS( _47options_49800 );
            }
            assign_space = Add_internal_space( _47options_49800, insert_pos,((s1_ptr)SEQ_PTR(_new_options_49804))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_new_options_49804), _47options_49800 == _47options_49800 );
            _47options_49800 = MAKE_SEQ( assign_space );
        }
        else {
            if( _47options_49800 == _47options_49800 && SEQ_PTR( _47options_49800 )->ref == 1 ){
                _47options_49800 = Insert( _47options_49800, _new_options_49804, insert_pos);
            }
            else {
                DeRef( _47options_49800 );
                RefDS( _47options_49800 );
                _47options_49800 = Insert( _47options_49800, _new_options_49804, insert_pos);
            }
        }
    }

    /** cominit.e:67	end procedure*/
    DeRefDS(_new_options_49804);
    return;
    ;
}


object _47get_options()
{
    object _0, _1, _2;
    

    /** cominit.e:73		return options*/
    RefDS(_47options_49800);
    return _47options_49800;
    ;
}


object _47get_switches()
{
    object _0, _1, _2;
    

    /** cominit.e:87		return switches*/
    RefDS(_47switches_49673);
    return _47switches_49673;
    ;
}


void _47show_copyrights()
{
    object _notices_49814 = NOVALUE;
    object _25574 = NOVALUE;
    object _25573 = NOVALUE;
    object _25571 = NOVALUE;
    object _25570 = NOVALUE;
    object _25569 = NOVALUE;
    object _25568 = NOVALUE;
    object _25566 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:94		sequence notices = all_copyrights()*/
    _0 = _notices_49814;
    _notices_49814 = _40all_copyrights();
    DeRef(_0);

    /** cominit.e:95		for i = 1 to length(notices) do*/
    if (IS_SEQUENCE(_notices_49814)){
            _25566 = SEQ_PTR(_notices_49814)->length;
    }
    else {
        _25566 = 1;
    }
    {
        object _i_49818;
        _i_49818 = 1LL;
L1: 
        if (_i_49818 > _25566){
            goto L2; // [13] 60
        }

        /** cominit.e:96			printf(2, "%s\n  %s\n\n", { notices[i][1], match_replace("\n", notices[i][2], "\n  ") })*/
        _2 = (object)SEQ_PTR(_notices_49814);
        _25568 = (object)*(((s1_ptr)_2)->base + _i_49818);
        _2 = (object)SEQ_PTR(_25568);
        _25569 = (object)*(((s1_ptr)_2)->base + 1LL);
        _25568 = NOVALUE;
        _2 = (object)SEQ_PTR(_notices_49814);
        _25570 = (object)*(((s1_ptr)_2)->base + _i_49818);
        _2 = (object)SEQ_PTR(_25570);
        _25571 = (object)*(((s1_ptr)_2)->base + 2LL);
        _25570 = NOVALUE;
        RefDS(_22231);
        Ref(_25571);
        RefDS(_25572);
        _25573 = _20match_replace(_22231, _25571, _25572, 0LL);
        _25571 = NOVALUE;
        Ref(_25569);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _25569;
        ((intptr_t *)_2)[2] = _25573;
        _25574 = MAKE_SEQ(_1);
        _25573 = NOVALUE;
        _25569 = NOVALUE;
        EPrintf(2LL, _25567, _25574);
        DeRefDS(_25574);
        _25574 = NOVALUE;

        /** cominit.e:97		end for*/
        _i_49818 = _i_49818 + 1LL;
        goto L1; // [55] 20
L2: 
        ;
    }

    /** cominit.e:98	end procedure*/
    DeRef(_notices_49814);
    return;
    ;
}


void _47show_banner()
{
    object _version_type_inlined_version_type_at_220_49887 = NOVALUE;
    object _version_string_short_1__tmp_at204_49885 = NOVALUE;
    object _version_string_short_inlined_version_string_short_at_204_49884 = NOVALUE;
    object _version_revision_inlined_version_revision_at_133_49865 = NOVALUE;
    object _platform_name_inlined_platform_name_at_94_49857 = NOVALUE;
    object _prod_name_49831 = NOVALUE;
    object _memory_type_49832 = NOVALUE;
    object _misc_info_49854 = NOVALUE;
    object _EuConsole_49869 = NOVALUE;
    object _25599 = NOVALUE;
    object _25598 = NOVALUE;
    object _25597 = NOVALUE;
    object _25594 = NOVALUE;
    object _25593 = NOVALUE;
    object _25589 = NOVALUE;
    object _25588 = NOVALUE;
    object _25587 = NOVALUE;
    object _25585 = NOVALUE;
    object _25583 = NOVALUE;
    object _25582 = NOVALUE;
    object _25581 = NOVALUE;
    object _25576 = NOVALUE;
    object _25575 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:109		if INTERPRET and not BIND then*/
    if (_12INTERPRET_19831 == 0) {
        goto L1; // [5] 33
    }
    _25576 = (_12BIND_19837 == 0);
    if (_25576 == 0)
    {
        DeRef(_25576);
        _25576 = NOVALUE;
        goto L1; // [15] 33
    }
    else{
        DeRef(_25576);
        _25576 = NOVALUE;
    }

    /** cominit.e:110			prod_name = GetMsgText(EUPHORIA_INTERPRETER,0)*/
    RefDS(_22024);
    _0 = _prod_name_49831;
    _prod_name_49831 = _30GetMsgText(270LL, 0LL, _22024);
    DeRef(_0);
    goto L2; // [30] 76
L1: 

    /** cominit.e:112		elsif TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L3; // [37] 55
    }
    else{
    }

    /** cominit.e:113			prod_name = GetMsgText(EUPHORIA_TO_C_TRANSLATOR,0)*/
    RefDS(_22024);
    _0 = _prod_name_49831;
    _prod_name_49831 = _30GetMsgText(271LL, 0LL, _22024);
    DeRef(_0);
    goto L2; // [52] 76
L3: 

    /** cominit.e:115		elsif BIND then*/
    if (_12BIND_19837 == 0)
    {
        goto L4; // [59] 75
    }
    else{
    }

    /** cominit.e:116			prod_name = GetMsgText(EUPHORIA_BINDER,0)*/
    RefDS(_22024);
    _0 = _prod_name_49831;
    _prod_name_49831 = _30GetMsgText(272LL, 0LL, _22024);
    DeRef(_0);
L4: 
L2: 

    /** cominit.e:119		ifdef EU_MANAGED_MEM then*/

    /** cominit.e:122			memory_type = GetMsgText(USING_SYSTEM_MEMORY,0)*/
    RefDS(_22024);
    _0 = _memory_type_49832;
    _memory_type_49832 = _30GetMsgText(274LL, 0LL, _22024);
    DeRef(_0);

    /** cominit.e:125		sequence misc_info = {*/
    _25581 = _40arch_bits();

    /** info.e:48		ifdef WINDOWS then*/

    /** info.e:51			return "Linux"*/
    RefDS(_8355);
    DeRefi(_platform_name_inlined_platform_name_at_94_49857);
    _platform_name_inlined_platform_name_at_94_49857 = _8355;
    _25582 = _40version_date(0LL);
    _25583 = _40version_node(0LL);
    _0 = _misc_info_49854;
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _25581;
    RefDS(_platform_name_inlined_platform_name_at_94_49857);
    ((intptr_t*)_2)[2] = _platform_name_inlined_platform_name_at_94_49857;
    RefDS(_memory_type_49832);
    ((intptr_t*)_2)[3] = _memory_type_49832;
    RefDS(_22024);
    ((intptr_t*)_2)[4] = _22024;
    ((intptr_t*)_2)[5] = _25582;
    ((intptr_t*)_2)[6] = _25583;
    _misc_info_49854 = MAKE_SEQ(_1);
    DeRef(_0);
    _25583 = NOVALUE;
    _25582 = NOVALUE;
    _25581 = NOVALUE;

    /** cominit.e:134		if info:is_developmental then*/
    if (_40is_developmental_14584 == 0)
    {
        goto L5; // [126] 160
    }
    else{
    }

    /** cominit.e:135			misc_info[$] = sprintf("%d:%s", { info:version_revision(), info:version_node() })*/
    _25585 = 6;

    /** info.e:157		return version_info[REVISION]*/
    DeRef(_version_revision_inlined_version_revision_at_133_49865);
    _2 = (object)SEQ_PTR(_40version_info_14582);
    _version_revision_inlined_version_revision_at_133_49865 = (object)*(((s1_ptr)_2)->base + 6LL);
    Ref(_version_revision_inlined_version_revision_at_133_49865);
    _25587 = _40version_node(0LL);
    Ref(_version_revision_inlined_version_revision_at_133_49865);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _version_revision_inlined_version_revision_at_133_49865;
    ((intptr_t *)_2)[2] = _25587;
    _25588 = MAKE_SEQ(_1);
    _25587 = NOVALUE;
    _25589 = EPrintf(-9999999, _25586, _25588);
    DeRefDS(_25588);
    _25588 = NOVALUE;
    _2 = (object)SEQ_PTR(_misc_info_49854);
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25589;
    if( _1 != _25589 ){
        DeRef(_1);
    }
    _25589 = NOVALUE;
L5: 

    /** cominit.e:138		object EuConsole = getenv("EUCONS")*/
    DeRefi(_EuConsole_49869);
    _EuConsole_49869 = EGetEnv(_25590);

    /** cominit.e:139		if equal(EuConsole, "1") then*/
    if (_EuConsole_49869 == _25592)
    _25593 = 1;
    else if (IS_ATOM_INT(_EuConsole_49869) && IS_ATOM_INT(_25592))
    _25593 = 0;
    else
    _25593 = (compare(_EuConsole_49869, _25592) == 0);
    if (_25593 == 0)
    {
        _25593 = NOVALUE;
        goto L6; // [171] 191
    }
    else{
        _25593 = NOVALUE;
    }

    /** cominit.e:140			misc_info[4] = GetMsgText(EUCONSOLE,0)*/
    RefDS(_22024);
    _25594 = _30GetMsgText(275LL, 0LL, _22024);
    _2 = (object)SEQ_PTR(_misc_info_49854);
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25594;
    if( _1 != _25594 ){
        DeRef(_1);
    }
    _25594 = NOVALUE;
    goto L7; // [188] 199
L6: 

    /** cominit.e:142			misc_info = remove(misc_info, 4)*/
    {
        s1_ptr assign_space = SEQ_PTR(_misc_info_49854);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(4LL)) ? 4LL : (object)(DBL_PTR(4LL)->dbl);
        int stop = (IS_ATOM_INT(4LL)) ? 4LL : (object)(DBL_PTR(4LL)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_misc_info_49854), start, &_misc_info_49854 );
            }
            else Tail(SEQ_PTR(_misc_info_49854), stop+1, &_misc_info_49854);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_misc_info_49854), start, &_misc_info_49854);
        }
        else {
            assign_slice_seq = &assign_space;
            _misc_info_49854 = Remove_elements(start, stop, (SEQ_PTR(_misc_info_49854)->ref == 1));
        }
    }
L7: 

    /** cominit.e:145		screen_output(STDERR, sprintf("%s v%s %s\n   %s %s, %s\n   Revision Date: %s, Id: %s\n", {*/

    /** info.e:261		return sprintf("%d.%d.%d", version_info[MAJ_VER..PAT_VER])*/
    rhs_slice_target = (object_ptr)&_version_string_short_1__tmp_at204_49885;
    RHS_Slice(_40version_info_14582, 1LL, 3LL);
    DeRefi(_version_string_short_inlined_version_string_short_at_204_49884);
    _version_string_short_inlined_version_string_short_at_204_49884 = EPrintf(-9999999, _8412, _version_string_short_1__tmp_at204_49885);
    DeRef(_version_string_short_1__tmp_at204_49885);
    _version_string_short_1__tmp_at204_49885 = NOVALUE;

    /** info.e:202		return version_info[VER_TYPE]*/
    DeRef(_version_type_inlined_version_type_at_220_49887);
    _2 = (object)SEQ_PTR(_40version_info_14582);
    _version_type_inlined_version_type_at_220_49887 = (object)*(((s1_ptr)_2)->base + 4LL);
    Ref(_version_type_inlined_version_type_at_220_49887);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_prod_name_49831);
    ((intptr_t*)_2)[1] = _prod_name_49831;
    RefDS(_version_string_short_inlined_version_string_short_at_204_49884);
    ((intptr_t*)_2)[2] = _version_string_short_inlined_version_string_short_at_204_49884;
    Ref(_version_type_inlined_version_type_at_220_49887);
    ((intptr_t*)_2)[3] = _version_type_inlined_version_type_at_220_49887;
    _25597 = MAKE_SEQ(_1);
    Concat((object_ptr)&_25598, _25597, _misc_info_49854);
    DeRefDS(_25597);
    _25597 = NOVALUE;
    DeRef(_25597);
    _25597 = NOVALUE;
    _25599 = EPrintf(-9999999, _25596, _25598);
    DeRefDS(_25598);
    _25598 = NOVALUE;
    _49screen_output(2LL, _25599);
    _25599 = NOVALUE;

    /** cominit.e:147	end procedure*/
    DeRefDS(_prod_name_49831);
    DeRef(_memory_type_49832);
    DeRefDS(_misc_info_49854);
    DeRefi(_EuConsole_49869);
    return;
    ;
}


object _47find_opt(object _name_type_49899, object _opt_49900, object _opts_49901)
{
    object _o_49905 = NOVALUE;
    object _has_case_49907 = NOVALUE;
    object _25612 = NOVALUE;
    object _25611 = NOVALUE;
    object _25610 = NOVALUE;
    object _25609 = NOVALUE;
    object _25608 = NOVALUE;
    object _25607 = NOVALUE;
    object _25606 = NOVALUE;
    object _25605 = NOVALUE;
    object _25604 = NOVALUE;
    object _25602 = NOVALUE;
    object _25600 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:172		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_49901)){
            _25600 = SEQ_PTR(_opts_49901)->length;
    }
    else {
        _25600 = 1;
    }
    {
        object _i_49903;
        _i_49903 = 1LL;
L1: 
        if (_i_49903 > _25600){
            goto L2; // [12] 113
        }

        /** cominit.e:173			sequence o = opts[i]		*/
        DeRef(_o_49905);
        _2 = (object)SEQ_PTR(_opts_49901);
        _o_49905 = (object)*(((s1_ptr)_2)->base + _i_49903);
        Ref(_o_49905);

        /** cominit.e:174			integer has_case = find(HAS_CASE, o[OPTIONS])*/
        _2 = (object)SEQ_PTR(_o_49905);
        _25602 = (object)*(((s1_ptr)_2)->base + 4LL);
        _has_case_49907 = find_from(99LL, _25602, 1LL);
        _25602 = NOVALUE;

        /** cominit.e:176			if has_case and equal(o[name_type], opt) then*/
        if (_has_case_49907 == 0) {
            goto L3; // [42] 67
        }
        _2 = (object)SEQ_PTR(_o_49905);
        _25605 = (object)*(((s1_ptr)_2)->base + _name_type_49899);
        if (_25605 == _opt_49900)
        _25606 = 1;
        else if (IS_ATOM_INT(_25605) && IS_ATOM_INT(_opt_49900))
        _25606 = 0;
        else
        _25606 = (compare(_25605, _opt_49900) == 0);
        _25605 = NOVALUE;
        if (_25606 == 0)
        {
            _25606 = NOVALUE;
            goto L3; // [55] 67
        }
        else{
            _25606 = NOVALUE;
        }

        /** cominit.e:177				return o*/
        DeRefDS(_opt_49900);
        DeRefDS(_opts_49901);
        return _o_49905;
        goto L4; // [64] 104
L3: 

        /** cominit.e:178			elsif not has_case and equal(text:lower(o[name_type]), text:lower(opt)) then*/
        _25607 = (_has_case_49907 == 0);
        if (_25607 == 0) {
            goto L5; // [72] 103
        }
        _2 = (object)SEQ_PTR(_o_49905);
        _25609 = (object)*(((s1_ptr)_2)->base + _name_type_49899);
        Ref(_25609);
        _25610 = _18lower(_25609);
        _25609 = NOVALUE;
        RefDS(_opt_49900);
        _25611 = _18lower(_opt_49900);
        if (_25610 == _25611)
        _25612 = 1;
        else if (IS_ATOM_INT(_25610) && IS_ATOM_INT(_25611))
        _25612 = 0;
        else
        _25612 = (compare(_25610, _25611) == 0);
        DeRef(_25610);
        _25610 = NOVALUE;
        DeRef(_25611);
        _25611 = NOVALUE;
        if (_25612 == 0)
        {
            _25612 = NOVALUE;
            goto L5; // [93] 103
        }
        else{
            _25612 = NOVALUE;
        }

        /** cominit.e:179				return o*/
        DeRefDS(_opt_49900);
        DeRefDS(_opts_49901);
        DeRef(_25607);
        _25607 = NOVALUE;
        return _o_49905;
L5: 
L4: 
        DeRef(_o_49905);
        _o_49905 = NOVALUE;

        /** cominit.e:181		end for*/
        _i_49903 = _i_49903 + 1LL;
        goto L1; // [108] 19
L2: 
        ;
    }

    /** cominit.e:183		return {}*/
    RefDS(_22024);
    DeRefDS(_opt_49900);
    DeRefDS(_opts_49901);
    DeRef(_25607);
    _25607 = NOVALUE;
    return _22024;
    ;
}


object _47merge_parameters(object _a_49924, object _b_49925, object _opts_49926, object _dedupe_49927)
{
    object _i_49928 = NOVALUE;
    object _opt_49932 = NOVALUE;
    object _this_opt_49938 = NOVALUE;
    object _bi_49939 = NOVALUE;
    object _beginLen_49999 = NOVALUE;
    object _first_extra_50021 = NOVALUE;
    object _opt_50025 = NOVALUE;
    object _this_opt_50030 = NOVALUE;
    object _25706 = NOVALUE;
    object _25705 = NOVALUE;
    object _25702 = NOVALUE;
    object _25701 = NOVALUE;
    object _25700 = NOVALUE;
    object _25698 = NOVALUE;
    object _25697 = NOVALUE;
    object _25696 = NOVALUE;
    object _25695 = NOVALUE;
    object _25693 = NOVALUE;
    object _25692 = NOVALUE;
    object _25690 = NOVALUE;
    object _25689 = NOVALUE;
    object _25688 = NOVALUE;
    object _25687 = NOVALUE;
    object _25686 = NOVALUE;
    object _25685 = NOVALUE;
    object _25684 = NOVALUE;
    object _25682 = NOVALUE;
    object _25679 = NOVALUE;
    object _25678 = NOVALUE;
    object _25673 = NOVALUE;
    object _25671 = NOVALUE;
    object _25670 = NOVALUE;
    object _25669 = NOVALUE;
    object _25668 = NOVALUE;
    object _25667 = NOVALUE;
    object _25666 = NOVALUE;
    object _25665 = NOVALUE;
    object _25664 = NOVALUE;
    object _25660 = NOVALUE;
    object _25659 = NOVALUE;
    object _25658 = NOVALUE;
    object _25657 = NOVALUE;
    object _25656 = NOVALUE;
    object _25655 = NOVALUE;
    object _25654 = NOVALUE;
    object _25653 = NOVALUE;
    object _25652 = NOVALUE;
    object _25651 = NOVALUE;
    object _25650 = NOVALUE;
    object _25649 = NOVALUE;
    object _25648 = NOVALUE;
    object _25647 = NOVALUE;
    object _25646 = NOVALUE;
    object _25644 = NOVALUE;
    object _25643 = NOVALUE;
    object _25642 = NOVALUE;
    object _25641 = NOVALUE;
    object _25640 = NOVALUE;
    object _25639 = NOVALUE;
    object _25638 = NOVALUE;
    object _25637 = NOVALUE;
    object _25635 = NOVALUE;
    object _25634 = NOVALUE;
    object _25633 = NOVALUE;
    object _25632 = NOVALUE;
    object _25630 = NOVALUE;
    object _25629 = NOVALUE;
    object _25628 = NOVALUE;
    object _25627 = NOVALUE;
    object _25626 = NOVALUE;
    object _25625 = NOVALUE;
    object _25624 = NOVALUE;
    object _25622 = NOVALUE;
    object _25621 = NOVALUE;
    object _25619 = NOVALUE;
    object _25616 = NOVALUE;
    object _25613 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:199		integer i = 1*/
    _i_49928 = 1LL;

    /** cominit.e:201		while i <= length(a) do*/
L1: 
    if (IS_SEQUENCE(_a_49924)){
            _25613 = SEQ_PTR(_a_49924)->length;
    }
    else {
        _25613 = 1;
    }
    if (_i_49928 > _25613)
    goto L2; // [22] 465

    /** cominit.e:202			sequence opt = a[i]*/
    DeRef(_opt_49932);
    _2 = (object)SEQ_PTR(_a_49924);
    _opt_49932 = (object)*(((s1_ptr)_2)->base + _i_49928);
    Ref(_opt_49932);

    /** cominit.e:203			if length(opt) < 2 then*/
    if (IS_SEQUENCE(_opt_49932)){
            _25616 = SEQ_PTR(_opt_49932)->length;
    }
    else {
        _25616 = 1;
    }
    if (_25616 >= 2LL)
    goto L3; // [39] 56

    /** cominit.e:204				i += 1*/
    _i_49928 = _i_49928 + 1;

    /** cominit.e:205				continue*/
    DeRefDS(_opt_49932);
    _opt_49932 = NOVALUE;
    DeRef(_this_opt_49938);
    _this_opt_49938 = NOVALUE;
    goto L1; // [53] 19
L3: 

    /** cominit.e:208			sequence this_opt = {}*/
    RefDS(_22024);
    DeRef(_this_opt_49938);
    _this_opt_49938 = _22024;

    /** cominit.e:209			integer bi = 0*/
    _bi_49939 = 0LL;

    /** cominit.e:211			if opt[2] = '-' then*/
    _2 = (object)SEQ_PTR(_opt_49932);
    _25619 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (binary_op_a(NOTEQ, _25619, 45LL)){
        _25619 = NOVALUE;
        goto L4; // [74] 149
    }
    _25619 = NOVALUE;

    /** cominit.e:214				this_opt = find_opt(LONGNAME, opt[3..$], opts)*/
    if (IS_SEQUENCE(_opt_49932)){
            _25621 = SEQ_PTR(_opt_49932)->length;
    }
    else {
        _25621 = 1;
    }
    rhs_slice_target = (object_ptr)&_25622;
    RHS_Slice(_opt_49932, 3LL, _25621);
    RefDS(_opts_49926);
    _0 = _this_opt_49938;
    _this_opt_49938 = _47find_opt(2LL, _25622, _opts_49926);
    DeRefDS(_0);
    _25622 = NOVALUE;

    /** cominit.e:216				for j = 1 to length(b) do*/
    if (IS_SEQUENCE(_b_49925)){
            _25624 = SEQ_PTR(_b_49925)->length;
    }
    else {
        _25624 = 1;
    }
    {
        object _j_49947;
        _j_49947 = 1LL;
L5: 
        if (_j_49947 > _25624){
            goto L6; // [101] 146
        }

        /** cominit.e:217					if equal(text:lower(b[j]), text:lower(opt)) then*/
        _2 = (object)SEQ_PTR(_b_49925);
        _25625 = (object)*(((s1_ptr)_2)->base + _j_49947);
        Ref(_25625);
        _25626 = _18lower(_25625);
        _25625 = NOVALUE;
        RefDS(_opt_49932);
        _25627 = _18lower(_opt_49932);
        if (_25626 == _25627)
        _25628 = 1;
        else if (IS_ATOM_INT(_25626) && IS_ATOM_INT(_25627))
        _25628 = 0;
        else
        _25628 = (compare(_25626, _25627) == 0);
        DeRef(_25626);
        _25626 = NOVALUE;
        DeRef(_25627);
        _25627 = NOVALUE;
        if (_25628 == 0)
        {
            _25628 = NOVALUE;
            goto L7; // [126] 139
        }
        else{
            _25628 = NOVALUE;
        }

        /** cominit.e:218						bi = j*/
        _bi_49939 = _j_49947;

        /** cominit.e:219						exit*/
        goto L6; // [136] 146
L7: 

        /** cominit.e:221				end for*/
        _j_49947 = _j_49947 + 1LL;
        goto L5; // [141] 108
L6: 
        ;
    }
    goto L8; // [146] 292
L4: 

    /** cominit.e:223			elsif opt[1] = '-' or opt[1] = '/' then*/
    _2 = (object)SEQ_PTR(_opt_49932);
    _25629 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_25629)) {
        _25630 = (_25629 == 45LL);
    }
    else {
        _25630 = binary_op(EQUALS, _25629, 45LL);
    }
    _25629 = NOVALUE;
    if (IS_ATOM_INT(_25630)) {
        if (_25630 != 0) {
            goto L9; // [159] 176
        }
    }
    else {
        if (DBL_PTR(_25630)->dbl != 0.0) {
            goto L9; // [159] 176
        }
    }
    _2 = (object)SEQ_PTR(_opt_49932);
    _25632 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_25632)) {
        _25633 = (_25632 == 47LL);
    }
    else {
        _25633 = binary_op(EQUALS, _25632, 47LL);
    }
    _25632 = NOVALUE;
    if (_25633 == 0) {
        DeRef(_25633);
        _25633 = NOVALUE;
        goto LA; // [172] 291
    }
    else {
        if (!IS_ATOM_INT(_25633) && DBL_PTR(_25633)->dbl == 0.0){
            DeRef(_25633);
            _25633 = NOVALUE;
            goto LA; // [172] 291
        }
        DeRef(_25633);
        _25633 = NOVALUE;
    }
    DeRef(_25633);
    _25633 = NOVALUE;
L9: 

    /** cominit.e:226				this_opt = find_opt(SHORTNAME, opt[2..$], opts)*/
    if (IS_SEQUENCE(_opt_49932)){
            _25634 = SEQ_PTR(_opt_49932)->length;
    }
    else {
        _25634 = 1;
    }
    rhs_slice_target = (object_ptr)&_25635;
    RHS_Slice(_opt_49932, 2LL, _25634);
    RefDS(_opts_49926);
    _0 = _this_opt_49938;
    _this_opt_49938 = _47find_opt(1LL, _25635, _opts_49926);
    DeRef(_0);
    _25635 = NOVALUE;

    /** cominit.e:228				for j = 1 to length(b) do*/
    if (IS_SEQUENCE(_b_49925)){
            _25637 = SEQ_PTR(_b_49925)->length;
    }
    else {
        _25637 = 1;
    }
    {
        object _j_49964;
        _j_49964 = 1LL;
LB: 
        if (_j_49964 > _25637){
            goto LC; // [199] 290
        }

        /** cominit.e:229					if equal(text:lower(b[j]), '-' & text:lower(opt[2..$])) or */
        _2 = (object)SEQ_PTR(_b_49925);
        _25638 = (object)*(((s1_ptr)_2)->base + _j_49964);
        Ref(_25638);
        _25639 = _18lower(_25638);
        _25638 = NOVALUE;
        if (IS_SEQUENCE(_opt_49932)){
                _25640 = SEQ_PTR(_opt_49932)->length;
        }
        else {
            _25640 = 1;
        }
        rhs_slice_target = (object_ptr)&_25641;
        RHS_Slice(_opt_49932, 2LL, _25640);
        _25642 = _18lower(_25641);
        _25641 = NOVALUE;
        if (IS_SEQUENCE(45LL) && IS_ATOM(_25642)) {
        }
        else if (IS_ATOM(45LL) && IS_SEQUENCE(_25642)) {
            Prepend(&_25643, _25642, 45LL);
        }
        else {
            Concat((object_ptr)&_25643, 45LL, _25642);
        }
        DeRef(_25642);
        _25642 = NOVALUE;
        if (_25639 == _25643)
        _25644 = 1;
        else if (IS_ATOM_INT(_25639) && IS_ATOM_INT(_25643))
        _25644 = 0;
        else
        _25644 = (compare(_25639, _25643) == 0);
        DeRef(_25639);
        _25639 = NOVALUE;
        DeRefDS(_25643);
        _25643 = NOVALUE;
        if (_25644 != 0) {
            goto LD; // [236] 273
        }
        _2 = (object)SEQ_PTR(_b_49925);
        _25646 = (object)*(((s1_ptr)_2)->base + _j_49964);
        Ref(_25646);
        _25647 = _18lower(_25646);
        _25646 = NOVALUE;
        if (IS_SEQUENCE(_opt_49932)){
                _25648 = SEQ_PTR(_opt_49932)->length;
        }
        else {
            _25648 = 1;
        }
        rhs_slice_target = (object_ptr)&_25649;
        RHS_Slice(_opt_49932, 2LL, _25648);
        _25650 = _18lower(_25649);
        _25649 = NOVALUE;
        if (IS_SEQUENCE(47LL) && IS_ATOM(_25650)) {
        }
        else if (IS_ATOM(47LL) && IS_SEQUENCE(_25650)) {
            Prepend(&_25651, _25650, 47LL);
        }
        else {
            Concat((object_ptr)&_25651, 47LL, _25650);
        }
        DeRef(_25650);
        _25650 = NOVALUE;
        if (_25647 == _25651)
        _25652 = 1;
        else if (IS_ATOM_INT(_25647) && IS_ATOM_INT(_25651))
        _25652 = 0;
        else
        _25652 = (compare(_25647, _25651) == 0);
        DeRef(_25647);
        _25647 = NOVALUE;
        DeRefDS(_25651);
        _25651 = NOVALUE;
        if (_25652 == 0)
        {
            _25652 = NOVALUE;
            goto LE; // [269] 283
        }
        else{
            _25652 = NOVALUE;
        }
LD: 

        /** cominit.e:232						bi = j*/
        _bi_49939 = _j_49964;

        /** cominit.e:233						exit*/
        goto LC; // [280] 290
LE: 

        /** cominit.e:235				end for*/
        _j_49964 = _j_49964 + 1LL;
        goto LB; // [285] 206
LC: 
        ;
    }
LA: 
L8: 

    /** cominit.e:243			if length(this_opt) and not find(MULTIPLE, this_opt[OPTIONS]) then*/
    if (IS_SEQUENCE(_this_opt_49938)){
            _25653 = SEQ_PTR(_this_opt_49938)->length;
    }
    else {
        _25653 = 1;
    }
    if (_25653 == 0) {
        goto LF; // [297] 451
    }
    _2 = (object)SEQ_PTR(_this_opt_49938);
    _25655 = (object)*(((s1_ptr)_2)->base + 4LL);
    _25656 = find_from(42LL, _25655, 1LL);
    _25655 = NOVALUE;
    _25657 = (_25656 == 0);
    _25656 = NOVALUE;
    if (_25657 == 0)
    {
        DeRef(_25657);
        _25657 = NOVALUE;
        goto LF; // [316] 451
    }
    else{
        DeRef(_25657);
        _25657 = NOVALUE;
    }

    /** cominit.e:244				if bi then*/
    if (_bi_49939 == 0)
    {
        goto L10; // [321] 365
    }
    else{
    }

    /** cominit.e:245					if find(HAS_PARAMETER, this_opt[OPTIONS]) then*/
    _2 = (object)SEQ_PTR(_this_opt_49938);
    _25658 = (object)*(((s1_ptr)_2)->base + 4LL);
    _25659 = find_from(112LL, _25658, 1LL);
    _25658 = NOVALUE;
    if (_25659 == 0)
    {
        _25659 = NOVALUE;
        goto L11; // [337] 354
    }
    else{
        _25659 = NOVALUE;
    }

    /** cominit.e:247						a = remove(a, i, i + 1)*/
    _25660 = _i_49928 + 1;
    if (_25660 > MAXINT){
        _25660 = NewDouble((eudouble)_25660);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_a_49924);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_i_49928)) ? _i_49928 : (object)(DBL_PTR(_i_49928)->dbl);
        int stop = (IS_ATOM_INT(_25660)) ? _25660 : (object)(DBL_PTR(_25660)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_a_49924), start, &_a_49924 );
            }
            else Tail(SEQ_PTR(_a_49924), stop+1, &_a_49924);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_a_49924), start, &_a_49924);
        }
        else {
            assign_slice_seq = &assign_space;
            _a_49924 = Remove_elements(start, stop, (SEQ_PTR(_a_49924)->ref == 1));
        }
    }
    DeRef(_25660);
    _25660 = NOVALUE;
    goto L12; // [351] 458
L11: 

    /** cominit.e:250						a = remove(a, i)*/
    {
        s1_ptr assign_space = SEQ_PTR(_a_49924);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_i_49928)) ? _i_49928 : (object)(DBL_PTR(_i_49928)->dbl);
        int stop = (IS_ATOM_INT(_i_49928)) ? _i_49928 : (object)(DBL_PTR(_i_49928)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_a_49924), start, &_a_49924 );
            }
            else Tail(SEQ_PTR(_a_49924), stop+1, &_a_49924);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_a_49924), start, &_a_49924);
        }
        else {
            assign_slice_seq = &assign_space;
            _a_49924 = Remove_elements(start, stop, (SEQ_PTR(_a_49924)->ref == 1));
        }
    }
    goto L12; // [362] 458
L10: 

    /** cominit.e:265					integer beginLen = length(a)*/
    if (IS_SEQUENCE(_a_49924)){
            _beginLen_49999 = SEQ_PTR(_a_49924)->length;
    }
    else {
        _beginLen_49999 = 1;
    }

    /** cominit.e:267					if dedupe = 0 and i < beginLen then*/
    _25664 = (_dedupe_49927 == 0LL);
    if (_25664 == 0) {
        goto L13; // [376] 438
    }
    _25666 = (_i_49928 < _beginLen_49999);
    if (_25666 == 0)
    {
        DeRef(_25666);
        _25666 = NOVALUE;
        goto L13; // [385] 438
    }
    else{
        DeRef(_25666);
        _25666 = NOVALUE;
    }

    /** cominit.e:268						a = merge_parameters( a[i + 1..$], a[1..i], opts, 1)*/
    _25667 = _i_49928 + 1;
    if (_25667 > MAXINT){
        _25667 = NewDouble((eudouble)_25667);
    }
    if (IS_SEQUENCE(_a_49924)){
            _25668 = SEQ_PTR(_a_49924)->length;
    }
    else {
        _25668 = 1;
    }
    rhs_slice_target = (object_ptr)&_25669;
    RHS_Slice(_a_49924, _25667, _25668);
    rhs_slice_target = (object_ptr)&_25670;
    RHS_Slice(_a_49924, 1LL, _i_49928);
    RefDS(_opts_49926);
    DeRef(_25671);
    _25671 = _opts_49926;
    _0 = _a_49924;
    _a_49924 = _47merge_parameters(_25669, _25670, _25671, 1LL);
    DeRefDS(_0);
    _25669 = NOVALUE;
    _25670 = NOVALUE;
    _25671 = NOVALUE;

    /** cominit.e:270						if beginLen = length(a) then*/
    if (IS_SEQUENCE(_a_49924)){
            _25673 = SEQ_PTR(_a_49924)->length;
    }
    else {
        _25673 = 1;
    }
    if (_beginLen_49999 != _25673)
    goto L14; // [424] 445

    /** cominit.e:272							i += 1*/
    _i_49928 = _i_49928 + 1;
    goto L14; // [435] 445
L13: 

    /** cominit.e:276						i += 1*/
    _i_49928 = _i_49928 + 1;
L14: 
    goto L12; // [448] 458
LF: 

    /** cominit.e:282				i += 1*/
    _i_49928 = _i_49928 + 1;
L12: 
    DeRef(_opt_49932);
    _opt_49932 = NOVALUE;
    DeRef(_this_opt_49938);
    _this_opt_49938 = NOVALUE;

    /** cominit.e:284		end while*/
    goto L1; // [462] 19
L2: 

    /** cominit.e:286		if dedupe then*/
    if (_dedupe_49927 == 0)
    {
        goto L15; // [467] 481
    }
    else{
    }

    /** cominit.e:287			return b & a*/
    Concat((object_ptr)&_25678, _b_49925, _a_49924);
    DeRefDS(_a_49924);
    DeRefDS(_b_49925);
    DeRefDS(_opts_49926);
    DeRef(_25664);
    _25664 = NOVALUE;
    DeRef(_25667);
    _25667 = NOVALUE;
    DeRef(_25630);
    _25630 = NOVALUE;
    return _25678;
L15: 

    /** cominit.e:290		integer first_extra = 0*/
    _first_extra_50021 = 0LL;

    /** cominit.e:292		i = 1*/
    _i_49928 = 1LL;

    /** cominit.e:295		while i <= length(b) do*/
L16: 
    if (IS_SEQUENCE(_b_49925)){
            _25679 = SEQ_PTR(_b_49925)->length;
    }
    else {
        _25679 = 1;
    }
    if (_i_49928 > _25679)
    goto L17; // [499] 692

    /** cominit.e:296			sequence opt = b[i]*/
    DeRef(_opt_50025);
    _2 = (object)SEQ_PTR(_b_49925);
    _opt_50025 = (object)*(((s1_ptr)_2)->base + _i_49928);
    Ref(_opt_50025);

    /** cominit.e:299			if length(opt) <= 1 then*/
    if (IS_SEQUENCE(_opt_50025)){
            _25682 = SEQ_PTR(_opt_50025)->length;
    }
    else {
        _25682 = 1;
    }
    if (_25682 > 1LL)
    goto L18; // [516] 532

    /** cominit.e:300				first_extra = i*/
    _first_extra_50021 = _i_49928;

    /** cominit.e:301				exit*/
    DeRefDS(_opt_50025);
    _opt_50025 = NOVALUE;
    DeRef(_this_opt_50030);
    _this_opt_50030 = NOVALUE;
    goto L17; // [529] 692
L18: 

    /** cominit.e:304			sequence this_opt = {}*/
    RefDS(_22024);
    DeRef(_this_opt_50030);
    _this_opt_50030 = _22024;

    /** cominit.e:305			if opt[2] = '-' and opt[1] = '-' then*/
    _2 = (object)SEQ_PTR(_opt_50025);
    _25684 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_25684)) {
        _25685 = (_25684 == 45LL);
    }
    else {
        _25685 = binary_op(EQUALS, _25684, 45LL);
    }
    _25684 = NOVALUE;
    if (IS_ATOM_INT(_25685)) {
        if (_25685 == 0) {
            goto L19; // [549] 586
        }
    }
    else {
        if (DBL_PTR(_25685)->dbl == 0.0) {
            goto L19; // [549] 586
        }
    }
    _2 = (object)SEQ_PTR(_opt_50025);
    _25687 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_25687)) {
        _25688 = (_25687 == 45LL);
    }
    else {
        _25688 = binary_op(EQUALS, _25687, 45LL);
    }
    _25687 = NOVALUE;
    if (_25688 == 0) {
        DeRef(_25688);
        _25688 = NOVALUE;
        goto L19; // [562] 586
    }
    else {
        if (!IS_ATOM_INT(_25688) && DBL_PTR(_25688)->dbl == 0.0){
            DeRef(_25688);
            _25688 = NOVALUE;
            goto L19; // [562] 586
        }
        DeRef(_25688);
        _25688 = NOVALUE;
    }
    DeRef(_25688);
    _25688 = NOVALUE;

    /** cominit.e:306				this_opt = find_opt(LONGNAME, opt[3..$], opts)*/
    if (IS_SEQUENCE(_opt_50025)){
            _25689 = SEQ_PTR(_opt_50025)->length;
    }
    else {
        _25689 = 1;
    }
    rhs_slice_target = (object_ptr)&_25690;
    RHS_Slice(_opt_50025, 3LL, _25689);
    RefDS(_opts_49926);
    _0 = _this_opt_50030;
    _this_opt_50030 = _47find_opt(2LL, _25690, _opts_49926);
    DeRef(_0);
    _25690 = NOVALUE;
    goto L1A; // [583] 633
L19: 

    /** cominit.e:307			elsif opt[1] = '-' or opt[1] = '/' then*/
    _2 = (object)SEQ_PTR(_opt_50025);
    _25692 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_25692)) {
        _25693 = (_25692 == 45LL);
    }
    else {
        _25693 = binary_op(EQUALS, _25692, 45LL);
    }
    _25692 = NOVALUE;
    if (IS_ATOM_INT(_25693)) {
        if (_25693 != 0) {
            goto L1B; // [596] 613
        }
    }
    else {
        if (DBL_PTR(_25693)->dbl != 0.0) {
            goto L1B; // [596] 613
        }
    }
    _2 = (object)SEQ_PTR(_opt_50025);
    _25695 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_25695)) {
        _25696 = (_25695 == 47LL);
    }
    else {
        _25696 = binary_op(EQUALS, _25695, 47LL);
    }
    _25695 = NOVALUE;
    if (_25696 == 0) {
        DeRef(_25696);
        _25696 = NOVALUE;
        goto L1C; // [609] 632
    }
    else {
        if (!IS_ATOM_INT(_25696) && DBL_PTR(_25696)->dbl == 0.0){
            DeRef(_25696);
            _25696 = NOVALUE;
            goto L1C; // [609] 632
        }
        DeRef(_25696);
        _25696 = NOVALUE;
    }
    DeRef(_25696);
    _25696 = NOVALUE;
L1B: 

    /** cominit.e:308				this_opt = find_opt(SHORTNAME, opt[2..$], opts)*/
    if (IS_SEQUENCE(_opt_50025)){
            _25697 = SEQ_PTR(_opt_50025)->length;
    }
    else {
        _25697 = 1;
    }
    rhs_slice_target = (object_ptr)&_25698;
    RHS_Slice(_opt_50025, 2LL, _25697);
    RefDS(_opts_49926);
    _0 = _this_opt_50030;
    _this_opt_50030 = _47find_opt(1LL, _25698, _opts_49926);
    DeRef(_0);
    _25698 = NOVALUE;
L1C: 
L1A: 

    /** cominit.e:311			if length(this_opt) then*/
    if (IS_SEQUENCE(_this_opt_50030)){
            _25700 = SEQ_PTR(_this_opt_50030)->length;
    }
    else {
        _25700 = 1;
    }
    if (_25700 == 0)
    {
        _25700 = NOVALUE;
        goto L1D; // [638] 667
    }
    else{
        _25700 = NOVALUE;
    }

    /** cominit.e:312				if find(HAS_PARAMETER, this_opt[OPTIONS]) then*/
    _2 = (object)SEQ_PTR(_this_opt_50030);
    _25701 = (object)*(((s1_ptr)_2)->base + 4LL);
    _25702 = find_from(112LL, _25701, 1LL);
    _25701 = NOVALUE;
    if (_25702 == 0)
    {
        _25702 = NOVALUE;
        goto L1E; // [654] 679
    }
    else{
        _25702 = NOVALUE;
    }

    /** cominit.e:313					i += 1*/
    _i_49928 = _i_49928 + 1;
    goto L1E; // [664] 679
L1D: 

    /** cominit.e:316				first_extra = i*/
    _first_extra_50021 = _i_49928;

    /** cominit.e:317				exit*/
    DeRef(_opt_50025);
    _opt_50025 = NOVALUE;
    DeRef(_this_opt_50030);
    _this_opt_50030 = NOVALUE;
    goto L17; // [676] 692
L1E: 

    /** cominit.e:320			i += 1*/
    _i_49928 = _i_49928 + 1;
    DeRef(_opt_50025);
    _opt_50025 = NOVALUE;
    DeRef(_this_opt_50030);
    _this_opt_50030 = NOVALUE;

    /** cominit.e:321		end while*/
    goto L16; // [689] 496
L17: 

    /** cominit.e:323		if first_extra then*/
    if (_first_extra_50021 == 0)
    {
        goto L1F; // [694] 709
    }
    else{
    }

    /** cominit.e:324			return splice(b, a, first_extra)*/
    {
        s1_ptr assign_space;
        insert_pos = _first_extra_50021;
        if (insert_pos <= 0) {
            Concat(&_25705,_a_49924,_b_49925);
        }
        else if (insert_pos > SEQ_PTR(_b_49925)->length){
            Concat(&_25705,_b_49925,_a_49924);
        }
        else if (IS_SEQUENCE(_a_49924)) {
            if( _25705 != _b_49925 || SEQ_PTR( _b_49925 )->ref != 1 ){
                DeRef( _25705 );
                RefDS( _b_49925 );
            }
            assign_space = Add_internal_space( _b_49925, insert_pos,((s1_ptr)SEQ_PTR(_a_49924))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_a_49924), _b_49925 == _25705 );
            _25705 = MAKE_SEQ( assign_space );
        }
        else {
            if( _25705 == _b_49925 && SEQ_PTR( _b_49925 )->ref == 1 ){
                _25705 = Insert( _b_49925, _a_49924, insert_pos);
            }
            else {
                DeRef( _25705 );
                RefDS( _b_49925 );
                _25705 = Insert( _b_49925, _a_49924, insert_pos);
            }
        }
    }
    DeRefDS(_a_49924);
    DeRefDS(_b_49925);
    DeRefDS(_opts_49926);
    DeRef(_25693);
    _25693 = NOVALUE;
    DeRef(_25664);
    _25664 = NOVALUE;
    DeRef(_25667);
    _25667 = NOVALUE;
    DeRef(_25685);
    _25685 = NOVALUE;
    DeRef(_25630);
    _25630 = NOVALUE;
    DeRef(_25678);
    _25678 = NOVALUE;
    return _25705;
L1F: 

    /** cominit.e:328		return b & a*/
    Concat((object_ptr)&_25706, _b_49925, _a_49924);
    DeRefDS(_a_49924);
    DeRefDS(_b_49925);
    DeRefDS(_opts_49926);
    DeRef(_25693);
    _25693 = NOVALUE;
    DeRef(_25664);
    _25664 = NOVALUE;
    DeRef(_25667);
    _25667 = NOVALUE;
    DeRef(_25685);
    _25685 = NOVALUE;
    DeRef(_25630);
    _25630 = NOVALUE;
    DeRef(_25678);
    _25678 = NOVALUE;
    DeRef(_25705);
    _25705 = NOVALUE;
    return _25706;
    ;
}


object _47validate_opt(object _opt_type_50063, object _arg_50064, object _args_50065, object _ix_50066)
{
    object _opt_50067 = NOVALUE;
    object _this_opt_50075 = NOVALUE;
    object _25725 = NOVALUE;
    object _25724 = NOVALUE;
    object _25723 = NOVALUE;
    object _25722 = NOVALUE;
    object _25721 = NOVALUE;
    object _25719 = NOVALUE;
    object _25718 = NOVALUE;
    object _25717 = NOVALUE;
    object _25716 = NOVALUE;
    object _25715 = NOVALUE;
    object _25713 = NOVALUE;
    object _25710 = NOVALUE;
    object _25708 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:336		if opt_type = SHORTNAME then*/
    if (_opt_type_50063 != 1LL)
    goto L1; // [11] 28

    /** cominit.e:337			opt = arg[2..$]*/
    if (IS_SEQUENCE(_arg_50064)){
            _25708 = SEQ_PTR(_arg_50064)->length;
    }
    else {
        _25708 = 1;
    }
    rhs_slice_target = (object_ptr)&_opt_50067;
    RHS_Slice(_arg_50064, 2LL, _25708);
    goto L2; // [25] 39
L1: 

    /** cominit.e:339			opt = arg[3..$]*/
    if (IS_SEQUENCE(_arg_50064)){
            _25710 = SEQ_PTR(_arg_50064)->length;
    }
    else {
        _25710 = 1;
    }
    rhs_slice_target = (object_ptr)&_opt_50067;
    RHS_Slice(_arg_50064, 3LL, _25710);
L2: 

    /** cominit.e:342		sequence this_opt = find_opt( opt_type, opt, options )*/
    RefDS(_opt_50067);
    RefDS(_47options_49800);
    _0 = _this_opt_50075;
    _this_opt_50075 = _47find_opt(_opt_type_50063, _opt_50067, _47options_49800);
    DeRef(_0);

    /** cominit.e:343		if not length( this_opt ) then*/
    if (IS_SEQUENCE(_this_opt_50075)){
            _25713 = SEQ_PTR(_this_opt_50075)->length;
    }
    else {
        _25713 = 1;
    }
    if (_25713 != 0)
    goto L3; // [58] 72
    _25713 = NOVALUE;

    /** cominit.e:345			return { 0, 0 }*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = 0LL;
    _25715 = MAKE_SEQ(_1);
    DeRefDS(_arg_50064);
    DeRefDS(_args_50065);
    DeRefDS(_opt_50067);
    DeRefDS(_this_opt_50075);
    return _25715;
L3: 

    /** cominit.e:348		if find( HAS_PARAMETER, this_opt[OPTIONS] ) then*/
    _2 = (object)SEQ_PTR(_this_opt_50075);
    _25716 = (object)*(((s1_ptr)_2)->base + 4LL);
    _25717 = find_from(112LL, _25716, 1LL);
    _25716 = NOVALUE;
    if (_25717 == 0)
    {
        _25717 = NOVALUE;
        goto L4; // [85] 135
    }
    else{
        _25717 = NOVALUE;
    }

    /** cominit.e:349			if ix = length( args ) - 1 then*/
    if (IS_SEQUENCE(_args_50065)){
            _25718 = SEQ_PTR(_args_50065)->length;
    }
    else {
        _25718 = 1;
    }
    _25719 = _25718 - 1LL;
    _25718 = NOVALUE;
    if (_ix_50066 != _25719)
    goto L5; // [97] 117

    /** cominit.e:351				CompileErr( MISSING_CMD_PARAMETER, { arg } )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_arg_50064);
    ((intptr_t*)_2)[1] = _arg_50064;
    _25721 = MAKE_SEQ(_1);
    _49CompileErr(353LL, _25721, 0LL);
    _25721 = NOVALUE;
    goto L6; // [114] 150
L5: 

    /** cominit.e:353				return { ix, ix + 2 }*/
    _25722 = _ix_50066 + 2LL;
    if ((object)((uintptr_t)_25722 + (uintptr_t)HIGH_BITS) >= 0){
        _25722 = NewDouble((eudouble)_25722);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _ix_50066;
    ((intptr_t *)_2)[2] = _25722;
    _25723 = MAKE_SEQ(_1);
    _25722 = NOVALUE;
    DeRefDS(_arg_50064);
    DeRefDS(_args_50065);
    DeRef(_opt_50067);
    DeRef(_this_opt_50075);
    DeRef(_25719);
    _25719 = NOVALUE;
    DeRef(_25715);
    _25715 = NOVALUE;
    return _25723;
    goto L6; // [132] 150
L4: 

    /** cominit.e:356			return { ix, ix + 1 }*/
    _25724 = _ix_50066 + 1;
    if (_25724 > MAXINT){
        _25724 = NewDouble((eudouble)_25724);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _ix_50066;
    ((intptr_t *)_2)[2] = _25724;
    _25725 = MAKE_SEQ(_1);
    _25724 = NOVALUE;
    DeRefDS(_arg_50064);
    DeRefDS(_args_50065);
    DeRef(_opt_50067);
    DeRef(_this_opt_50075);
    DeRef(_25723);
    _25723 = NOVALUE;
    DeRef(_25719);
    _25719 = NOVALUE;
    DeRef(_25715);
    _25715 = NOVALUE;
    return _25725;
L6: 
    ;
}


object _47find_next_opt(object _ix_50100, object _args_50101)
{
    object _arg_50105 = NOVALUE;
    object _25747 = NOVALUE;
    object _25746 = NOVALUE;
    object _25744 = NOVALUE;
    object _25743 = NOVALUE;
    object _25742 = NOVALUE;
    object _25741 = NOVALUE;
    object _25740 = NOVALUE;
    object _25739 = NOVALUE;
    object _25738 = NOVALUE;
    object _25737 = NOVALUE;
    object _25735 = NOVALUE;
    object _25733 = NOVALUE;
    object _25731 = NOVALUE;
    object _25729 = NOVALUE;
    object _25726 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:374		while ix < length( args ) do*/
L1: 
    if (IS_SEQUENCE(_args_50101)){
            _25726 = SEQ_PTR(_args_50101)->length;
    }
    else {
        _25726 = 1;
    }
    if (_ix_50100 >= _25726)
    goto L2; // [13] 157

    /** cominit.e:375			sequence arg = args[ix]*/
    DeRef(_arg_50105);
    _2 = (object)SEQ_PTR(_args_50101);
    _arg_50105 = (object)*(((s1_ptr)_2)->base + _ix_50100);
    Ref(_arg_50105);

    /** cominit.e:376			if length( arg ) > 1 then*/
    if (IS_SEQUENCE(_arg_50105)){
            _25729 = SEQ_PTR(_arg_50105)->length;
    }
    else {
        _25729 = 1;
    }
    if (_25729 <= 1LL)
    goto L3; // [30] 129

    /** cominit.e:377				if arg[1] = '-' then*/
    _2 = (object)SEQ_PTR(_arg_50105);
    _25731 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _25731, 45LL)){
        _25731 = NOVALUE;
        goto L4; // [40] 111
    }
    _25731 = NOVALUE;

    /** cominit.e:378					if arg[2] = '-' then*/
    _2 = (object)SEQ_PTR(_arg_50105);
    _25733 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (binary_op_a(NOTEQ, _25733, 45LL)){
        _25733 = NOVALUE;
        goto L5; // [50] 94
    }
    _25733 = NOVALUE;

    /** cominit.e:380						if length( arg ) = 2 then*/
    if (IS_SEQUENCE(_arg_50105)){
            _25735 = SEQ_PTR(_arg_50105)->length;
    }
    else {
        _25735 = 1;
    }
    if (_25735 != 2LL)
    goto L6; // [59] 78

    /** cominit.e:382							return { 0, ix - 1 }*/
    _25737 = _ix_50100 - 1LL;
    if ((object)((uintptr_t)_25737 +(uintptr_t) HIGH_BITS) >= 0){
        _25737 = NewDouble((eudouble)_25737);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = _25737;
    _25738 = MAKE_SEQ(_1);
    _25737 = NOVALUE;
    DeRefDS(_arg_50105);
    DeRefDS(_args_50101);
    return _25738;
L6: 

    /** cominit.e:385						return validate_opt( LONGNAME, arg, args, ix )*/
    RefDS(_arg_50105);
    RefDS(_args_50101);
    _25739 = _47validate_opt(2LL, _arg_50105, _args_50101, _ix_50100);
    DeRefDS(_arg_50105);
    DeRefDS(_args_50101);
    DeRef(_25738);
    _25738 = NOVALUE;
    return _25739;
    goto L7; // [91] 144
L5: 

    /** cominit.e:389						return validate_opt( SHORTNAME, arg, args, ix )*/
    RefDS(_arg_50105);
    RefDS(_args_50101);
    _25740 = _47validate_opt(1LL, _arg_50105, _args_50101, _ix_50100);
    DeRefDS(_arg_50105);
    DeRefDS(_args_50101);
    DeRef(_25739);
    _25739 = NOVALUE;
    DeRef(_25738);
    _25738 = NOVALUE;
    return _25740;
    goto L7; // [108] 144
L4: 

    /** cominit.e:393					return {0, ix-1}*/
    _25741 = _ix_50100 - 1LL;
    if ((object)((uintptr_t)_25741 +(uintptr_t) HIGH_BITS) >= 0){
        _25741 = NewDouble((eudouble)_25741);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = _25741;
    _25742 = MAKE_SEQ(_1);
    _25741 = NOVALUE;
    DeRef(_arg_50105);
    DeRefDS(_args_50101);
    DeRef(_25739);
    _25739 = NOVALUE;
    DeRef(_25738);
    _25738 = NOVALUE;
    DeRef(_25740);
    _25740 = NOVALUE;
    return _25742;
    goto L7; // [126] 144
L3: 

    /** cominit.e:397				return { 0, ix-1 }*/
    _25743 = _ix_50100 - 1LL;
    if ((object)((uintptr_t)_25743 +(uintptr_t) HIGH_BITS) >= 0){
        _25743 = NewDouble((eudouble)_25743);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = _25743;
    _25744 = MAKE_SEQ(_1);
    _25743 = NOVALUE;
    DeRef(_arg_50105);
    DeRefDS(_args_50101);
    DeRef(_25739);
    _25739 = NOVALUE;
    DeRef(_25738);
    _25738 = NOVALUE;
    DeRef(_25742);
    _25742 = NOVALUE;
    DeRef(_25740);
    _25740 = NOVALUE;
    return _25744;
L7: 

    /** cominit.e:400			ix += 1*/
    _ix_50100 = _ix_50100 + 1;
    DeRef(_arg_50105);
    _arg_50105 = NOVALUE;

    /** cominit.e:401		end while*/
    goto L1; // [154] 10
L2: 

    /** cominit.e:402		return {0, ix-1}*/
    _25746 = _ix_50100 - 1LL;
    if ((object)((uintptr_t)_25746 +(uintptr_t) HIGH_BITS) >= 0){
        _25746 = NewDouble((eudouble)_25746);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = _25746;
    _25747 = MAKE_SEQ(_1);
    _25746 = NOVALUE;
    DeRefDS(_args_50101);
    DeRef(_25739);
    _25739 = NOVALUE;
    DeRef(_25744);
    _25744 = NOVALUE;
    DeRef(_25738);
    _25738 = NOVALUE;
    DeRef(_25742);
    _25742 = NOVALUE;
    DeRef(_25740);
    _25740 = NOVALUE;
    return _25747;
    ;
}


object _47expand_config_options(object _args_50135)
{
    object _idx_50136 = NOVALUE;
    object _next_idx_50137 = NOVALUE;
    object _files_50138 = NOVALUE;
    object _cmd_1_2_50139 = NOVALUE;
    object _25770 = NOVALUE;
    object _25769 = NOVALUE;
    object _25768 = NOVALUE;
    object _25767 = NOVALUE;
    object _25766 = NOVALUE;
    object _25765 = NOVALUE;
    object _25764 = NOVALUE;
    object _25763 = NOVALUE;
    object _25762 = NOVALUE;
    object _25757 = NOVALUE;
    object _25755 = NOVALUE;
    object _25754 = NOVALUE;
    object _25753 = NOVALUE;
    object _25751 = NOVALUE;
    object _25750 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:410		integer idx = 1*/
    _idx_50136 = 1LL;

    /** cominit.e:412		sequence files = {}*/
    RefDS(_22024);
    DeRef(_files_50138);
    _files_50138 = _22024;

    /** cominit.e:413		sequence cmd_1_2 = args[1..2]*/
    rhs_slice_target = (object_ptr)&_cmd_1_2_50139;
    RHS_Slice(_args_50135, 1LL, 2LL);

    /** cominit.e:414		args = remove( args, 1, 2 )*/
    {
        s1_ptr assign_space = SEQ_PTR(_args_50135);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(1LL)) ? 1LL : (object)(DBL_PTR(1LL)->dbl);
        int stop = (IS_ATOM_INT(2LL)) ? 2LL : (object)(DBL_PTR(2LL)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_args_50135), start, &_args_50135 );
            }
            else Tail(SEQ_PTR(_args_50135), stop+1, &_args_50135);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_args_50135), start, &_args_50135);
        }
        else {
            assign_slice_seq = &assign_space;
            _args_50135 = Remove_elements(start, stop, (SEQ_PTR(_args_50135)->ref == 1));
        }
    }

    /** cominit.e:416		while idx with entry do*/
    goto L1; // [31] 94
L2: 
    if (_idx_50136 == 0)
    {
        goto L3; // [34] 114
    }
    else{
    }

    /** cominit.e:417			if equal(upper(args[idx]), "-C") then*/
    _2 = (object)SEQ_PTR(_args_50135);
    _25750 = (object)*(((s1_ptr)_2)->base + _idx_50136);
    Ref(_25750);
    _25751 = _18upper(_25750);
    _25750 = NOVALUE;
    if (_25751 == _25752)
    _25753 = 1;
    else if (IS_ATOM_INT(_25751) && IS_ATOM_INT(_25752))
    _25753 = 0;
    else
    _25753 = (compare(_25751, _25752) == 0);
    DeRef(_25751);
    _25751 = NOVALUE;
    if (_25753 == 0)
    {
        _25753 = NOVALUE;
        goto L4; // [51] 82
    }
    else{
        _25753 = NOVALUE;
    }

    /** cominit.e:418				files = append( files, args[idx+1] )*/
    _25754 = _idx_50136 + 1;
    _2 = (object)SEQ_PTR(_args_50135);
    _25755 = (object)*(((s1_ptr)_2)->base + _25754);
    Ref(_25755);
    Append(&_files_50138, _files_50138, _25755);
    _25755 = NOVALUE;

    /** cominit.e:419				args = remove( args, idx, idx + 1 )*/
    _25757 = _idx_50136 + 1;
    if (_25757 > MAXINT){
        _25757 = NewDouble((eudouble)_25757);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_args_50135);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_idx_50136)) ? _idx_50136 : (object)(DBL_PTR(_idx_50136)->dbl);
        int stop = (IS_ATOM_INT(_25757)) ? _25757 : (object)(DBL_PTR(_25757)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_args_50135), start, &_args_50135 );
            }
            else Tail(SEQ_PTR(_args_50135), stop+1, &_args_50135);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_args_50135), start, &_args_50135);
        }
        else {
            assign_slice_seq = &assign_space;
            _args_50135 = Remove_elements(start, stop, (SEQ_PTR(_args_50135)->ref == 1));
        }
    }
    DeRef(_25757);
    _25757 = NOVALUE;
    goto L5; // [79] 91
L4: 

    /** cominit.e:422				idx = next_idx[2]*/
    _2 = (object)SEQ_PTR(_next_idx_50137);
    _idx_50136 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_idx_50136))
    _idx_50136 = (object)DBL_PTR(_idx_50136)->dbl;
L5: 

    /** cominit.e:424		entry*/
L1: 

    /** cominit.e:425			next_idx = find_next_opt( idx, args )*/
    RefDS(_args_50135);
    _0 = _next_idx_50137;
    _next_idx_50137 = _47find_next_opt(_idx_50136, _args_50135);
    DeRef(_0);

    /** cominit.e:426			idx = next_idx[1]*/
    _2 = (object)SEQ_PTR(_next_idx_50137);
    _idx_50136 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_idx_50136))
    _idx_50136 = (object)DBL_PTR(_idx_50136)->dbl;

    /** cominit.e:427		end while*/
    goto L2; // [111] 34
L3: 

    /** cominit.e:428		return cmd_1_2 & merge_parameters( GetDefaultArgs( files ), args[1..next_idx[2]], options, 1 ) & args[next_idx[2]+1..$]*/
    RefDS(_files_50138);
    _25762 = _46GetDefaultArgs(_files_50138);
    _2 = (object)SEQ_PTR(_next_idx_50137);
    _25763 = (object)*(((s1_ptr)_2)->base + 2LL);
    rhs_slice_target = (object_ptr)&_25764;
    RHS_Slice(_args_50135, 1LL, _25763);
    RefDS(_47options_49800);
    _25765 = _47merge_parameters(_25762, _25764, _47options_49800, 1LL);
    _25762 = NOVALUE;
    _25764 = NOVALUE;
    _2 = (object)SEQ_PTR(_next_idx_50137);
    _25766 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_25766)) {
        _25767 = _25766 + 1;
        if (_25767 > MAXINT){
            _25767 = NewDouble((eudouble)_25767);
        }
    }
    else
    _25767 = binary_op(PLUS, 1, _25766);
    _25766 = NOVALUE;
    if (IS_SEQUENCE(_args_50135)){
            _25768 = SEQ_PTR(_args_50135)->length;
    }
    else {
        _25768 = 1;
    }
    rhs_slice_target = (object_ptr)&_25769;
    RHS_Slice(_args_50135, _25767, _25768);
    {
        object concat_list[3];

        concat_list[0] = _25769;
        concat_list[1] = _25765;
        concat_list[2] = _cmd_1_2_50139;
        Concat_N((object_ptr)&_25770, concat_list, 3);
    }
    DeRefDS(_25769);
    _25769 = NOVALUE;
    DeRef(_25765);
    _25765 = NOVALUE;
    DeRefDS(_args_50135);
    DeRefDS(_next_idx_50137);
    DeRefDS(_files_50138);
    DeRefDS(_cmd_1_2_50139);
    DeRef(_25767);
    _25767 = NOVALUE;
    DeRef(_25754);
    _25754 = NOVALUE;
    _25763 = NOVALUE;
    return _25770;
    ;
}


void _47handle_common_options(object _opts_50170)
{
    object _opt_keys_50171 = NOVALUE;
    object _option_w_50173 = NOVALUE;
    object _key_50177 = NOVALUE;
    object _val_50179 = NOVALUE;
    object _this_warn_50225 = NOVALUE;
    object _auto_add_warn_50227 = NOVALUE;
    object _n_50234 = NOVALUE;
    object _this_warn_50257 = NOVALUE;
    object _auto_add_warn_50259 = NOVALUE;
    object _n_50265 = NOVALUE;
    object _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50302 = NOVALUE;
    object _prompt_inlined_maybe_any_key_at_617_50301 = NOVALUE;
    object _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50315 = NOVALUE;
    object _prompt_inlined_maybe_any_key_at_693_50314 = NOVALUE;
    object _25830 = NOVALUE;
    object _25829 = NOVALUE;
    object _25827 = NOVALUE;
    object _25825 = NOVALUE;
    object _25823 = NOVALUE;
    object _25822 = NOVALUE;
    object _25821 = NOVALUE;
    object _25820 = NOVALUE;
    object _25819 = NOVALUE;
    object _25818 = NOVALUE;
    object _25817 = NOVALUE;
    object _25816 = NOVALUE;
    object _25814 = NOVALUE;
    object _25812 = NOVALUE;
    object _25811 = NOVALUE;
    object _25810 = NOVALUE;
    object _25805 = NOVALUE;
    object _25803 = NOVALUE;
    object _25801 = NOVALUE;
    object _25798 = NOVALUE;
    object _25797 = NOVALUE;
    object _25792 = NOVALUE;
    object _25789 = NOVALUE;
    object _25787 = NOVALUE;
    object _25785 = NOVALUE;
    object _25784 = NOVALUE;
    object _25783 = NOVALUE;
    object _25782 = NOVALUE;
    object _25781 = NOVALUE;
    object _25780 = NOVALUE;
    object _25778 = NOVALUE;
    object _25777 = NOVALUE;
    object _25772 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:435		sequence opt_keys = m:keys(opts)*/
    Ref(_opts_50170);
    _0 = _opt_keys_50171;
    _opt_keys_50171 = _34keys(_opts_50170, 0LL);
    DeRef(_0);

    /** cominit.e:436		integer option_w = 0*/
    _option_w_50173 = 0LL;

    /** cominit.e:438		for idx = 1 to length(opt_keys) do*/
    if (IS_SEQUENCE(_opt_keys_50171)){
            _25772 = SEQ_PTR(_opt_keys_50171)->length;
    }
    else {
        _25772 = 1;
    }
    {
        object _idx_50175;
        _idx_50175 = 1LL;
L1: 
        if (_idx_50175 > _25772){
            goto L2; // [20] 795
        }

        /** cominit.e:439			sequence key = opt_keys[idx]*/
        DeRef(_key_50177);
        _2 = (object)SEQ_PTR(_opt_keys_50171);
        _key_50177 = (object)*(((s1_ptr)_2)->base + _idx_50175);
        Ref(_key_50177);

        /** cominit.e:440			object val = m:get(opts, key)*/
        Ref(_opts_50170);
        RefDS(_key_50177);
        _0 = _val_50179;
        _val_50179 = _34get(_opts_50170, _key_50177, 0LL);
        DeRef(_0);

        /** cominit.e:442			switch key do*/
        _1 = find(_key_50177, _25775);
        switch ( _1 ){ 

            /** cominit.e:443				case "i" then*/
            case 1:

            /** cominit.e:444					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50179)){
                    _25777 = SEQ_PTR(_val_50179)->length;
            }
            else {
                _25777 = 1;
            }
            {
                object _i_50185;
                _i_50185 = 1LL;
L3: 
                if (_i_50185 > _25777){
                    goto L4; // [59] 82
                }

                /** cominit.e:445						add_include_directory(val[i])*/
                _2 = (object)SEQ_PTR(_val_50179);
                _25778 = (object)*(((s1_ptr)_2)->base + _i_50185);
                Ref(_25778);
                _46add_include_directory(_25778);
                _25778 = NOVALUE;

                /** cominit.e:446					end for*/
                _i_50185 = _i_50185 + 1LL;
                goto L3; // [77] 66
L4: 
                ;
            }
            goto L5; // [82] 786

            /** cominit.e:448				case "d" then*/
            case 2:

            /** cominit.e:449					OpDefines &= val*/
            if (IS_SEQUENCE(_12OpDefines_20300) && IS_ATOM(_val_50179)) {
                Ref(_val_50179);
                Append(&_12OpDefines_20300, _12OpDefines_20300, _val_50179);
            }
            else if (IS_ATOM(_12OpDefines_20300) && IS_SEQUENCE(_val_50179)) {
            }
            else {
                Concat((object_ptr)&_12OpDefines_20300, _12OpDefines_20300, _val_50179);
            }
            goto L5; // [98] 786

            /** cominit.e:451				case "batch" then*/
            case 3:

            /** cominit.e:452					batch_job = 1*/
            _12batch_job_20239 = 1LL;
            goto L5; // [111] 786

            /** cominit.e:454				case "test" then*/
            case 4:

            /** cominit.e:455					test_only = 1*/
            _12test_only_20238 = 1LL;
            goto L5; // [124] 786

            /** cominit.e:457				case "strict" then*/
            case 5:

            /** cominit.e:458					Strict_is_on = 1*/
            _12Strict_is_on_20292 = 1LL;
            goto L5; // [137] 786

            /** cominit.e:460				case "p" then*/
            case 6:

            /** cominit.e:461					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50179)){
                    _25780 = SEQ_PTR(_val_50179)->length;
            }
            else {
                _25780 = 1;
            }
            {
                object _i_50200;
                _i_50200 = 1LL;
L6: 
                if (_i_50200 > _25780){
                    goto L7; // [148] 173
                }

                /** cominit.e:462						add_preprocessor(val[i])*/
                _2 = (object)SEQ_PTR(_val_50179);
                _25781 = (object)*(((s1_ptr)_2)->base + _i_50200);
                Ref(_25781);
                _63add_preprocessor(_25781, 0LL, 0LL);
                _25781 = NOVALUE;

                /** cominit.e:463					end for*/
                _i_50200 = _i_50200 + 1LL;
                goto L6; // [168] 155
L7: 
                ;
            }
            goto L5; // [173] 786

            /** cominit.e:465				case "pf" then*/
            case 7:

            /** cominit.e:466					force_preprocessor = 1*/
            _13force_preprocessor_11335 = 1LL;
            goto L5; // [186] 786

            /** cominit.e:468				case "l" then*/
            case 8:

            /** cominit.e:469					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50179)){
                    _25782 = SEQ_PTR(_val_50179)->length;
            }
            else {
                _25782 = 1;
            }
            {
                object _i_50208;
                _i_50208 = 1LL;
L8: 
                if (_i_50208 > _25782){
                    goto L9; // [197] 238
                }

                /** cominit.e:470						LocalizeQual = append(LocalizeQual, (filter(lower(val[i]), STDFLTR_ALPHA)))*/
                _2 = (object)SEQ_PTR(_val_50179);
                _25783 = (object)*(((s1_ptr)_2)->base + _i_50208);
                Ref(_25783);
                _25784 = _18lower(_25783);
                _25783 = NOVALUE;
                RefDS(_22024);
                RefDS(_5);
                _25785 = _24filter(_25784, _24STDFLTR_ALPHA_4569, _22024, _5);
                _25784 = NOVALUE;
                Ref(_25785);
                Append(&_13LocalizeQual_11336, _13LocalizeQual_11336, _25785);
                DeRef(_25785);
                _25785 = NOVALUE;

                /** cominit.e:471					end for*/
                _i_50208 = _i_50208 + 1LL;
                goto L8; // [233] 204
L9: 
                ;
            }
            goto L5; // [238] 786

            /** cominit.e:473				case "ldb" then*/
            case 9:

            /** cominit.e:474					LocalDB = val*/
            Ref(_val_50179);
            DeRef(_13LocalDB_11337);
            _13LocalDB_11337 = _val_50179;
            goto L5; // [251] 786

            /** cominit.e:476				case "w" then*/
            case 10:

            /** cominit.e:477					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50179)){
                    _25787 = SEQ_PTR(_val_50179)->length;
            }
            else {
                _25787 = 1;
            }
            {
                object _i_50223;
                _i_50223 = 1LL;
LA: 
                if (_i_50223 > _25787){
                    goto LB; // [262] 392
                }

                /** cominit.e:478						sequence this_warn = val[i]*/
                DeRef(_this_warn_50225);
                _2 = (object)SEQ_PTR(_val_50179);
                _this_warn_50225 = (object)*(((s1_ptr)_2)->base + _i_50223);
                Ref(_this_warn_50225);

                /** cominit.e:479						integer auto_add_warn = 0*/
                _auto_add_warn_50227 = 0LL;

                /** cominit.e:480						if this_warn[1] = '+' then*/
                _2 = (object)SEQ_PTR(_this_warn_50225);
                _25789 = (object)*(((s1_ptr)_2)->base + 1LL);
                if (binary_op_a(NOTEQ, _25789, 43LL)){
                    _25789 = NOVALUE;
                    goto LC; // [288] 308
                }
                _25789 = NOVALUE;

                /** cominit.e:481							auto_add_warn = 1*/
                _auto_add_warn_50227 = 1LL;

                /** cominit.e:482							this_warn = this_warn[2 .. $]*/
                if (IS_SEQUENCE(_this_warn_50225)){
                        _25792 = SEQ_PTR(_this_warn_50225)->length;
                }
                else {
                    _25792 = 1;
                }
                rhs_slice_target = (object_ptr)&_this_warn_50225;
                RHS_Slice(_this_warn_50225, 2LL, _25792);
LC: 

                /** cominit.e:484						integer n = find(this_warn, warning_names)*/
                _n_50234 = find_from(_this_warn_50225, _12warning_names_20271, 1LL);

                /** cominit.e:485						if n != 0 then*/
                if (_n_50234 == 0LL)
                goto LD; // [319] 383

                /** cominit.e:486							if auto_add_warn or option_w = 1 then*/
                if (_auto_add_warn_50227 != 0) {
                    goto LE; // [325] 338
                }
                _25797 = (_option_w_50173 == 1LL);
                if (_25797 == 0)
                {
                    DeRef(_25797);
                    _25797 = NOVALUE;
                    goto LF; // [334] 357
                }
                else{
                    DeRef(_25797);
                    _25797 = NOVALUE;
                }
LE: 

                /** cominit.e:487								OpWarning = or_bits(OpWarning, warning_flags[n])*/
                _2 = (object)SEQ_PTR(_12warning_flags_20269);
                _25798 = (object)*(((s1_ptr)_2)->base + _n_50234);
                {uintptr_t tu;
                     tu = (uintptr_t)_12OpWarning_20294 | (uintptr_t)_25798;
                     _12OpWarning_20294 = MAKE_UINT(tu);
                }
                _25798 = NOVALUE;
                if (!IS_ATOM_INT(_12OpWarning_20294)) {
                    _1 = (object)(DBL_PTR(_12OpWarning_20294)->dbl);
                    DeRefDS(_12OpWarning_20294);
                    _12OpWarning_20294 = _1;
                }
                goto L10; // [354] 373
LF: 

                /** cominit.e:489								option_w = 1*/
                _option_w_50173 = 1LL;

                /** cominit.e:490								OpWarning = warning_flags[n]*/
                _2 = (object)SEQ_PTR(_12warning_flags_20269);
                _12OpWarning_20294 = (object)*(((s1_ptr)_2)->base + _n_50234);
L10: 

                /** cominit.e:493							prev_OpWarning = OpWarning*/
                _12prev_OpWarning_20295 = _12OpWarning_20294;
LD: 
                DeRef(_this_warn_50225);
                _this_warn_50225 = NOVALUE;

                /** cominit.e:495					end for*/
                _i_50223 = _i_50223 + 1LL;
                goto LA; // [387] 269
LB: 
                ;
            }
            goto L5; // [392] 786

            /** cominit.e:497				case "x" then*/
            case 11:

            /** cominit.e:498					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50179)){
                    _25801 = SEQ_PTR(_val_50179)->length;
            }
            else {
                _25801 = 1;
            }
            {
                object _i_50255;
                _i_50255 = 1LL;
L11: 
                if (_i_50255 > _25801){
                    goto L12; // [403] 542
                }

                /** cominit.e:499						sequence this_warn = val[i]*/
                DeRef(_this_warn_50257);
                _2 = (object)SEQ_PTR(_val_50179);
                _this_warn_50257 = (object)*(((s1_ptr)_2)->base + _i_50255);
                Ref(_this_warn_50257);

                /** cominit.e:500						integer auto_add_warn = 0*/
                _auto_add_warn_50259 = 0LL;

                /** cominit.e:501						if this_warn[1] = '+' then*/
                _2 = (object)SEQ_PTR(_this_warn_50257);
                _25803 = (object)*(((s1_ptr)_2)->base + 1LL);
                if (binary_op_a(NOTEQ, _25803, 43LL)){
                    _25803 = NOVALUE;
                    goto L13; // [429] 449
                }
                _25803 = NOVALUE;

                /** cominit.e:502							auto_add_warn = 1*/
                _auto_add_warn_50259 = 1LL;

                /** cominit.e:503							this_warn = this_warn[2 .. $]*/
                if (IS_SEQUENCE(_this_warn_50257)){
                        _25805 = SEQ_PTR(_this_warn_50257)->length;
                }
                else {
                    _25805 = 1;
                }
                rhs_slice_target = (object_ptr)&_this_warn_50257;
                RHS_Slice(_this_warn_50257, 2LL, _25805);
L13: 

                /** cominit.e:505						integer n = find(this_warn, warning_names)*/
                _n_50265 = find_from(_this_warn_50257, _12warning_names_20271, 1LL);

                /** cominit.e:506						if n != 0 then*/
                if (_n_50265 == 0LL)
                goto L14; // [460] 533

                /** cominit.e:507							if auto_add_warn or option_w = -1 then*/
                if (_auto_add_warn_50259 != 0) {
                    goto L15; // [466] 479
                }
                _25810 = (_option_w_50173 == -1LL);
                if (_25810 == 0)
                {
                    DeRef(_25810);
                    _25810 = NOVALUE;
                    goto L16; // [475] 501
                }
                else{
                    DeRef(_25810);
                    _25810 = NOVALUE;
                }
L15: 

                /** cominit.e:508								OpWarning = and_bits(OpWarning, not_bits(warning_flags[n]))*/
                _2 = (object)SEQ_PTR(_12warning_flags_20269);
                _25811 = (object)*(((s1_ptr)_2)->base + _n_50265);
                _25812 = not_bits(_25811);
                _25811 = NOVALUE;
                if (IS_ATOM_INT(_25812)) {
                    {uintptr_t tu;
                         tu = (uintptr_t)_12OpWarning_20294 & (uintptr_t)_25812;
                         _12OpWarning_20294 = MAKE_UINT(tu);
                    }
                }
                else {
                    temp_d.dbl = (eudouble)_12OpWarning_20294;
                    _12OpWarning_20294 = Dand_bits(&temp_d, DBL_PTR(_25812));
                }
                DeRef(_25812);
                _25812 = NOVALUE;
                if (!IS_ATOM_INT(_12OpWarning_20294)) {
                    _1 = (object)(DBL_PTR(_12OpWarning_20294)->dbl);
                    DeRefDS(_12OpWarning_20294);
                    _12OpWarning_20294 = _1;
                }
                goto L17; // [498] 523
L16: 

                /** cominit.e:510								option_w = -1*/
                _option_w_50173 = -1LL;

                /** cominit.e:511								OpWarning = all_warning_flag - warning_flags[n]*/
                _2 = (object)SEQ_PTR(_12warning_flags_20269);
                _25814 = (object)*(((s1_ptr)_2)->base + _n_50265);
                _12OpWarning_20294 = 32767LL - _25814;
                _25814 = NOVALUE;
L17: 

                /** cominit.e:514							prev_OpWarning = OpWarning*/
                _12prev_OpWarning_20295 = _12OpWarning_20294;
L14: 
                DeRef(_this_warn_50257);
                _this_warn_50257 = NOVALUE;

                /** cominit.e:516					end for*/
                _i_50255 = _i_50255 + 1LL;
                goto L11; // [537] 410
L12: 
                ;
            }
            goto L5; // [542] 786

            /** cominit.e:518				case "wf" then*/
            case 12:

            /** cominit.e:519					TempWarningName = val*/
            Ref(_val_50179);
            DeRef(_12TempWarningName_20240);
            _12TempWarningName_20240 = _val_50179;

            /** cominit.e:520				  	error:warning_file(TempWarningName)*/
            Ref(_12TempWarningName_20240);
            _8warning_file(_12TempWarningName_20240);
            goto L5; // [560] 786

            /** cominit.e:522				case "v", "version" then*/
            case 13:
            case 14:

            /** cominit.e:523					show_banner()*/
            _47show_banner();

            /** cominit.e:524					if not batch_job and not test_only then*/
            _25816 = (_12batch_job_20239 == 0);
            if (_25816 == 0) {
                goto L18; // [579] 634
            }
            _25818 = (_12test_only_20238 == 0);
            if (_25818 == 0)
            {
                DeRef(_25818);
                _25818 = NOVALUE;
                goto L18; // [589] 634
            }
            else{
                DeRef(_25818);
                _25818 = NOVALUE;
            }

            /** cominit.e:525						console:maybe_any_key(GetMsgText(MSG_PRESS_ANY_KEY_AND_WINDOW_WILL_CLOSE,0), 2)*/
            RefDS(_22024);
            _25819 = _30GetMsgText(278LL, 0LL, _22024);
            DeRef(_prompt_inlined_maybe_any_key_at_617_50301);
            _prompt_inlined_maybe_any_key_at_617_50301 = _25819;
            _25819 = NOVALUE;

            /** console.e:923		if not has_console() then*/

            /** console.e:59		return machine_func(M_HAS_CONSOLE, 0)*/
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50302);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50302 = machine(99LL, 0LL);
            if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50302)) {
                if (_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50302 != 0){
                    goto L19; // [616] 631
                }
            }
            else {
                if (DBL_PTR(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50302)->dbl != 0.0){
                    goto L19; // [616] 631
                }
            }

            /** console.e:924			any_key(prompt, con)*/
            Ref(_prompt_inlined_maybe_any_key_at_617_50301);
            _38any_key(_prompt_inlined_maybe_any_key_at_617_50301, 2LL);

            /** console.e:926	end procedure*/
            goto L19; // [628] 631
L19: 
            DeRef(_prompt_inlined_maybe_any_key_at_617_50301);
            _prompt_inlined_maybe_any_key_at_617_50301 = NOVALUE;
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50302);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50302 = NOVALUE;
L18: 

            /** cominit.e:528					abort(0)*/
            UserCleanup(0LL);
            goto L5; // [638] 786

            /** cominit.e:530				case "copyright" then*/
            case 15:

            /** cominit.e:531					show_copyrights()*/
            _47show_copyrights();

            /** cominit.e:532					if not batch_job and not test_only then*/
            _25820 = (_12batch_job_20239 == 0);
            if (_25820 == 0) {
                goto L1A; // [655] 710
            }
            _25822 = (_12test_only_20238 == 0);
            if (_25822 == 0)
            {
                DeRef(_25822);
                _25822 = NOVALUE;
                goto L1A; // [665] 710
            }
            else{
                DeRef(_25822);
                _25822 = NOVALUE;
            }

            /** cominit.e:533						console:maybe_any_key(GetMsgText(MSG_PRESS_ANY_KEY_AND_WINDOW_WILL_CLOSE,0), 2)*/
            RefDS(_22024);
            _25823 = _30GetMsgText(278LL, 0LL, _22024);
            DeRef(_prompt_inlined_maybe_any_key_at_693_50314);
            _prompt_inlined_maybe_any_key_at_693_50314 = _25823;
            _25823 = NOVALUE;

            /** console.e:923		if not has_console() then*/

            /** console.e:59		return machine_func(M_HAS_CONSOLE, 0)*/
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50315);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50315 = machine(99LL, 0LL);
            if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50315)) {
                if (_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50315 != 0){
                    goto L1B; // [692] 707
                }
            }
            else {
                if (DBL_PTR(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50315)->dbl != 0.0){
                    goto L1B; // [692] 707
                }
            }

            /** console.e:924			any_key(prompt, con)*/
            Ref(_prompt_inlined_maybe_any_key_at_693_50314);
            _38any_key(_prompt_inlined_maybe_any_key_at_693_50314, 2LL);

            /** console.e:926	end procedure*/
            goto L1B; // [704] 707
L1B: 
            DeRef(_prompt_inlined_maybe_any_key_at_693_50314);
            _prompt_inlined_maybe_any_key_at_693_50314 = NOVALUE;
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50315);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50315 = NOVALUE;
L1A: 

            /** cominit.e:535					abort(0)*/
            UserCleanup(0LL);
            goto L5; // [714] 786

            /** cominit.e:537				case "eudir" then*/
            case 16:

            /** cominit.e:538					set_eudir( val )*/
            Ref(_val_50179);
            _13set_eudir(_val_50179);
            goto L5; // [725] 786

            /** cominit.e:540				case "trace-lines" then*/
            case 17:

            /** cominit.e:541					val = value( val )*/
            Ref(_val_50179);
            _0 = _val_50179;
            _val_50179 = _16value(_val_50179, 1LL, _16GET_SHORT_ANSWER_8754);
            DeRef(_0);

            /** cominit.e:542					if val[1] = GET_SUCCESS then*/
            _2 = (object)SEQ_PTR(_val_50179);
            _25825 = (object)*(((s1_ptr)_2)->base + 1LL);
            if (binary_op_a(NOTEQ, _25825, 0LL)){
                _25825 = NOVALUE;
                goto L1C; // [749] 767
            }
            _25825 = NOVALUE;

            /** cominit.e:543						trace_lines = floor( val[2] )*/
            _2 = (object)SEQ_PTR(_val_50179);
            _25827 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (IS_ATOM_INT(_25827))
            _12trace_lines_64606 = e_floor(_25827);
            else
            _12trace_lines_64606 = unary_op(FLOOR, _25827);
            _25827 = NOVALUE;
            if (!IS_ATOM_INT(_12trace_lines_64606)) {
                _1 = (object)(DBL_PTR(_12trace_lines_64606)->dbl);
                DeRefDS(_12trace_lines_64606);
                _12trace_lines_64606 = _1;
            }
            goto L1D; // [764] 785
L1C: 

            /** cominit.e:545						puts(2, GetMsgText( BAD_TRACE_LINES ) )*/
            RefDS(_22024);
            _25829 = _30GetMsgText(604LL, 1LL, _22024);
            EPuts(2LL, _25829); // DJP 
            DeRef(_25829);
            _25829 = NOVALUE;

            /** cominit.e:546						abort( 1 )*/
            UserCleanup(1LL);
L1D: 
        ;}L5: 
        DeRef(_key_50177);
        _key_50177 = NOVALUE;
        DeRef(_val_50179);
        _val_50179 = NOVALUE;

        /** cominit.e:549		end for*/
        _idx_50175 = _idx_50175 + 1LL;
        goto L1; // [790] 27
L2: 
        ;
    }

    /** cominit.e:551		if length(LocalizeQual) = 0 then*/
    if (IS_SEQUENCE(_13LocalizeQual_11336)){
            _25830 = SEQ_PTR(_13LocalizeQual_11336)->length;
    }
    else {
        _25830 = 1;
    }
    if (_25830 != 0LL)
    goto L1E; // [802] 815

    /** cominit.e:552			LocalizeQual = {"en"}*/
    _0 = _13LocalizeQual_11336;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_25832);
    ((intptr_t*)_2)[1] = _25832;
    _13LocalizeQual_11336 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1E: 

    /** cominit.e:554	end procedure*/
    DeRef(_opts_50170);
    DeRef(_opt_keys_50171);
    DeRef(_25820);
    _25820 = NOVALUE;
    DeRef(_25816);
    _25816 = NOVALUE;
    return;
    ;
}


void _47finalize_command_line(object _opts_50341)
{
    object _extras_50348 = NOVALUE;
    object _pairs_50353 = NOVALUE;
    object _pair_50358 = NOVALUE;
    object _25862 = NOVALUE;
    object _25860 = NOVALUE;
    object _25857 = NOVALUE;
    object _25856 = NOVALUE;
    object _25855 = NOVALUE;
    object _25854 = NOVALUE;
    object _25853 = NOVALUE;
    object _25852 = NOVALUE;
    object _25851 = NOVALUE;
    object _25850 = NOVALUE;
    object _25849 = NOVALUE;
    object _25848 = NOVALUE;
    object _25847 = NOVALUE;
    object _25846 = NOVALUE;
    object _25845 = NOVALUE;
    object _25844 = NOVALUE;
    object _25843 = NOVALUE;
    object _25842 = NOVALUE;
    object _25841 = NOVALUE;
    object _25840 = NOVALUE;
    object _25838 = NOVALUE;
    object _25835 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:562		if Strict_is_on then -- overrides any -W/-X switches*/
    if (_12Strict_is_on_20292 == 0)
    {
        goto L1; // [5] 27
    }
    else{
    }

    /** cominit.e:563			OpWarning = all_warning_flag*/
    _12OpWarning_20294 = 32767LL;

    /** cominit.e:564			prev_OpWarning = OpWarning*/
    _12prev_OpWarning_20295 = 32767LL;
L1: 

    /** cominit.e:569		sequence extras = m:get(opts, cmdline:EXTRAS)*/
    Ref(_opts_50341);
    RefDS(_48EXTRAS_20639);
    _0 = _extras_50348;
    _extras_50348 = _34get(_opts_50341, _48EXTRAS_20639, 0LL);
    DeRef(_0);

    /** cominit.e:570		if length(extras) > 0 then*/
    if (IS_SEQUENCE(_extras_50348)){
            _25835 = SEQ_PTR(_extras_50348)->length;
    }
    else {
        _25835 = 1;
    }
    if (_25835 <= 0LL)
    goto L2; // [44] 270

    /** cominit.e:571			sequence pairs = m:pairs( opts )*/
    Ref(_opts_50341);
    _0 = _pairs_50353;
    _pairs_50353 = _34pairs(_opts_50341, 0LL);
    DeRef(_0);

    /** cominit.e:573			for i = 1 to length( pairs ) do*/
    if (IS_SEQUENCE(_pairs_50353)){
            _25838 = SEQ_PTR(_pairs_50353)->length;
    }
    else {
        _25838 = 1;
    }
    {
        object _i_50356;
        _i_50356 = 1LL;
L3: 
        if (_i_50356 > _25838){
            goto L4; // [62] 237
        }

        /** cominit.e:574				sequence pair = pairs[i]*/
        DeRef(_pair_50358);
        _2 = (object)SEQ_PTR(_pairs_50353);
        _pair_50358 = (object)*(((s1_ptr)_2)->base + _i_50356);
        Ref(_pair_50358);

        /** cominit.e:575				if equal( pair[1], cmdline:EXTRAS ) then*/
        _2 = (object)SEQ_PTR(_pair_50358);
        _25840 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (_25840 == _48EXTRAS_20639)
        _25841 = 1;
        else if (IS_ATOM_INT(_25840) && IS_ATOM_INT(_48EXTRAS_20639))
        _25841 = 0;
        else
        _25841 = (compare(_25840, _48EXTRAS_20639) == 0);
        _25840 = NOVALUE;
        if (_25841 == 0)
        {
            _25841 = NOVALUE;
            goto L5; // [89] 99
        }
        else{
            _25841 = NOVALUE;
        }

        /** cominit.e:576					continue*/
        DeRefDS(_pair_50358);
        _pair_50358 = NOVALUE;
        goto L6; // [96] 232
L5: 

        /** cominit.e:578				pair[1] = prepend( pair[1], '-' )*/
        _2 = (object)SEQ_PTR(_pair_50358);
        _25842 = (object)*(((s1_ptr)_2)->base + 1LL);
        Prepend(&_25843, _25842, 45LL);
        _25842 = NOVALUE;
        _2 = (object)SEQ_PTR(_pair_50358);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _pair_50358 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _25843;
        if( _1 != _25843 ){
            DeRef(_1);
        }
        _25843 = NOVALUE;

        /** cominit.e:579				if sequence( pair[2] ) then*/
        _2 = (object)SEQ_PTR(_pair_50358);
        _25844 = (object)*(((s1_ptr)_2)->base + 2LL);
        _25845 = IS_SEQUENCE(_25844);
        _25844 = NOVALUE;
        if (_25845 == 0)
        {
            _25845 = NOVALUE;
            goto L7; // [122] 215
        }
        else{
            _25845 = NOVALUE;
        }

        /** cominit.e:580					if length( pair[2] ) and sequence( pair[2][1] ) then*/
        _2 = (object)SEQ_PTR(_pair_50358);
        _25846 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (IS_SEQUENCE(_25846)){
                _25847 = SEQ_PTR(_25846)->length;
        }
        else {
            _25847 = 1;
        }
        _25846 = NOVALUE;
        if (_25847 == 0) {
            goto L8; // [134] 203
        }
        _2 = (object)SEQ_PTR(_pair_50358);
        _25849 = (object)*(((s1_ptr)_2)->base + 2LL);
        _2 = (object)SEQ_PTR(_25849);
        _25850 = (object)*(((s1_ptr)_2)->base + 1LL);
        _25849 = NOVALUE;
        _25851 = IS_SEQUENCE(_25850);
        _25850 = NOVALUE;
        if (_25851 == 0)
        {
            _25851 = NOVALUE;
            goto L8; // [150] 203
        }
        else{
            _25851 = NOVALUE;
        }

        /** cominit.e:581						for j = 1 to length( pair[2] ) do*/
        _2 = (object)SEQ_PTR(_pair_50358);
        _25852 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (IS_SEQUENCE(_25852)){
                _25853 = SEQ_PTR(_25852)->length;
        }
        else {
            _25853 = 1;
        }
        _25852 = NOVALUE;
        {
            object _j_50376;
            _j_50376 = 1LL;
L9: 
            if (_j_50376 > _25853){
                goto LA; // [162] 200
            }

            /** cominit.e:582							switches &= { pair[1], pair[2][j] }*/
            _2 = (object)SEQ_PTR(_pair_50358);
            _25854 = (object)*(((s1_ptr)_2)->base + 1LL);
            _2 = (object)SEQ_PTR(_pair_50358);
            _25855 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_25855);
            _25856 = (object)*(((s1_ptr)_2)->base + _j_50376);
            _25855 = NOVALUE;
            Ref(_25856);
            Ref(_25854);
            _1 = NewS1(2);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t *)_2)[1] = _25854;
            ((intptr_t *)_2)[2] = _25856;
            _25857 = MAKE_SEQ(_1);
            _25856 = NOVALUE;
            _25854 = NOVALUE;
            Concat((object_ptr)&_47switches_49673, _47switches_49673, _25857);
            DeRefDS(_25857);
            _25857 = NOVALUE;

            /** cominit.e:583						end for*/
            _j_50376 = _j_50376 + 1LL;
            goto L9; // [195] 169
LA: 
            ;
        }
        goto LB; // [200] 228
L8: 

        /** cominit.e:585						switches &= pair*/
        Concat((object_ptr)&_47switches_49673, _47switches_49673, _pair_50358);
        goto LB; // [212] 228
L7: 

        /** cominit.e:588					switches = append( switches, pair[1] )*/
        _2 = (object)SEQ_PTR(_pair_50358);
        _25860 = (object)*(((s1_ptr)_2)->base + 1LL);
        Ref(_25860);
        Append(&_47switches_49673, _47switches_49673, _25860);
        _25860 = NOVALUE;
LB: 
        DeRef(_pair_50358);
        _pair_50358 = NOVALUE;

        /** cominit.e:590			end for*/
L6: 
        _i_50356 = _i_50356 + 1LL;
        goto L3; // [232] 69
L4: 
        ;
    }

    /** cominit.e:592			Argv = Argv[2..3] & extras*/
    rhs_slice_target = (object_ptr)&_25862;
    RHS_Slice(_12Argv_20237, 2LL, 3LL);
    Concat((object_ptr)&_12Argv_20237, _25862, _extras_50348);
    DeRefDS(_25862);
    _25862 = NOVALUE;
    DeRef(_25862);
    _25862 = NOVALUE;

    /** cominit.e:593			Argc = length(Argv)*/
    if (IS_SEQUENCE(_12Argv_20237)){
            _12Argc_20236 = SEQ_PTR(_12Argv_20237)->length;
    }
    else {
        _12Argc_20236 = 1;
    }

    /** cominit.e:595			src_name = extras[1]*/
    DeRef(_47src_name_49672);
    _2 = (object)SEQ_PTR(_extras_50348);
    _47src_name_49672 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_47src_name_49672);
L2: 
    DeRef(_pairs_50353);
    _pairs_50353 = NOVALUE;

    /** cominit.e:597	end procedure*/
    DeRef(_opts_50341);
    DeRef(_extras_50348);
    _25852 = NOVALUE;
    _25846 = NOVALUE;
    return;
    ;
}



// 0x032917C3
