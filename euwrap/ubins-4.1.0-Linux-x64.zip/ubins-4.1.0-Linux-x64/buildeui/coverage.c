// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _50check_coverage()
{
    object _25173 = NOVALUE;
    object _25172 = NOVALUE;
    object _25171 = NOVALUE;
    object _25170 = NOVALUE;
    object _25169 = NOVALUE;
    object _25168 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:45		for i = length( file_coverage ) + 1 to length( known_files ) do*/
    if (IS_SEQUENCE(_50file_coverage_48896)){
            _25168 = SEQ_PTR(_50file_coverage_48896)->length;
    }
    else {
        _25168 = 1;
    }
    _25169 = _25168 + 1;
    _25168 = NOVALUE;
    if (IS_SEQUENCE(_13known_files_11317)){
            _25170 = SEQ_PTR(_13known_files_11317)->length;
    }
    else {
        _25170 = 1;
    }
    {
        object _i_48907;
        _i_48907 = _25169;
L1: 
        if (_i_48907 > _25170){
            goto L2; // [17] 58
        }

        /** coverage.e:46			file_coverage &= find( canonical_path( known_files[i],,1 ), covered_files )*/
        _2 = (object)SEQ_PTR(_13known_files_11317);
        _25171 = (object)*(((s1_ptr)_2)->base + _i_48907);
        Ref(_25171);
        _25172 = _14canonical_path(_25171, 0LL, 1LL);
        _25171 = NOVALUE;
        _25173 = find_from(_25172, _50covered_files_48895, 1LL);
        DeRef(_25172);
        _25172 = NOVALUE;
        Append(&_50file_coverage_48896, _50file_coverage_48896, _25173);
        _25173 = NOVALUE;

        /** coverage.e:47		end for*/
        _i_48907 = _i_48907 + 1LL;
        goto L1; // [53] 24
L2: 
        ;
    }

    /** coverage.e:48	end procedure*/
    DeRef(_25169);
    _25169 = NOVALUE;
    return;
    ;
}


void _50init_coverage()
{
    object _cmd_48931 = NOVALUE;
    object _25191 = NOVALUE;
    object _25190 = NOVALUE;
    object _25188 = NOVALUE;
    object _25187 = NOVALUE;
    object _25186 = NOVALUE;
    object _25184 = NOVALUE;
    object _25182 = NOVALUE;
    object _25181 = NOVALUE;
    object _25179 = NOVALUE;
    object _25178 = NOVALUE;
    object _25177 = NOVALUE;
    object _25176 = NOVALUE;
    object _25175 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:54		if initialized_coverage then*/
    if (_50initialized_coverage_48903 == 0)
    {
        goto L1; // [5] 14
    }
    else{
    }

    /** coverage.e:55			return*/
    return;
L1: 

    /** coverage.e:57		initialized_coverage = 1*/
    _50initialized_coverage_48903 = 1LL;

    /** coverage.e:58		for i = 1 to length( file_coverage ) do*/
    if (IS_SEQUENCE(_50file_coverage_48896)){
            _25175 = SEQ_PTR(_50file_coverage_48896)->length;
    }
    else {
        _25175 = 1;
    }
    {
        object _i_48922;
        _i_48922 = 1LL;
L2: 
        if (_i_48922 > _25175){
            goto L3; // [26] 67
        }

        /** coverage.e:59			file_coverage[i] = find( canonical_path( known_files[i],,1 ), covered_files )*/
        _2 = (object)SEQ_PTR(_13known_files_11317);
        _25176 = (object)*(((s1_ptr)_2)->base + _i_48922);
        Ref(_25176);
        _25177 = _14canonical_path(_25176, 0LL, 1LL);
        _25176 = NOVALUE;
        _25178 = find_from(_25177, _50covered_files_48895, 1LL);
        DeRef(_25177);
        _25177 = NOVALUE;
        _2 = (object)SEQ_PTR(_50file_coverage_48896);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _50file_coverage_48896 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_48922);
        *(intptr_t *)_2 = _25178;
        if( _1 != _25178 ){
        }
        _25178 = NOVALUE;

        /** coverage.e:60		end for*/
        _i_48922 = _i_48922 + 1LL;
        goto L2; // [62] 33
L3: 
        ;
    }

    /** coverage.e:62		if equal( coverage_db_name, "" ) then*/
    if (_50coverage_db_name_48897 == _22024)
    _25179 = 1;
    else if (IS_ATOM_INT(_50coverage_db_name_48897) && IS_ATOM_INT(_22024))
    _25179 = 0;
    else
    _25179 = (compare(_50coverage_db_name_48897, _22024) == 0);
    if (_25179 == 0)
    {
        _25179 = NOVALUE;
        goto L4; // [75] 105
    }
    else{
        _25179 = NOVALUE;
    }

    /** coverage.e:63			sequence cmd = command_line()*/
    DeRef(_cmd_48931);
    _cmd_48931 = Command_Line();

    /** coverage.e:64			coverage_db_name = canonical_path( filebase( cmd[2] ) & "-cvg.edb" )*/
    _2 = (object)SEQ_PTR(_cmd_48931);
    _25181 = (object)*(((s1_ptr)_2)->base + 2LL);
    RefDS(_25181);
    _25182 = _14filebase(_25181);
    _25181 = NOVALUE;
    if (IS_SEQUENCE(_25182) && IS_ATOM(_25183)) {
    }
    else if (IS_ATOM(_25182) && IS_SEQUENCE(_25183)) {
        Ref(_25182);
        Prepend(&_25184, _25183, _25182);
    }
    else {
        Concat((object_ptr)&_25184, _25182, _25183);
        DeRef(_25182);
        _25182 = NOVALUE;
    }
    DeRef(_25182);
    _25182 = NOVALUE;
    _0 = _14canonical_path(_25184, 0LL, 0LL);
    DeRefDS(_50coverage_db_name_48897);
    _50coverage_db_name_48897 = _0;
    _25184 = NOVALUE;
L4: 
    DeRef(_cmd_48931);
    _cmd_48931 = NOVALUE;

    /** coverage.e:67		if coverage_erase and file_exists( coverage_db_name ) then*/
    if (_50coverage_erase_48898 == 0) {
        goto L5; // [111] 153
    }
    RefDS(_50coverage_db_name_48897);
    _25187 = _14file_exists(_50coverage_db_name_48897);
    if (_25187 == 0) {
        DeRef(_25187);
        _25187 = NOVALUE;
        goto L5; // [122] 153
    }
    else {
        if (!IS_ATOM_INT(_25187) && DBL_PTR(_25187)->dbl == 0.0){
            DeRef(_25187);
            _25187 = NOVALUE;
            goto L5; // [122] 153
        }
        DeRef(_25187);
        _25187 = NOVALUE;
    }
    DeRef(_25187);
    _25187 = NOVALUE;

    /** coverage.e:68			if not delete_file( coverage_db_name ) then*/
    RefDS(_50coverage_db_name_48897);
    _25188 = _14delete_file(_50coverage_db_name_48897);
    if (IS_ATOM_INT(_25188)) {
        if (_25188 != 0){
            DeRef(_25188);
            _25188 = NOVALUE;
            goto L6; // [133] 152
        }
    }
    else {
        if (DBL_PTR(_25188)->dbl != 0.0){
            DeRef(_25188);
            _25188 = NOVALUE;
            goto L6; // [133] 152
        }
    }
    DeRef(_25188);
    _25188 = NOVALUE;

    /** coverage.e:69				CompileErr( COULD_NOT_ERASE_COVERAGE_DATABASE_1, { coverage_db_name } )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_50coverage_db_name_48897);
    ((intptr_t*)_2)[1] = _50coverage_db_name_48897;
    _25190 = MAKE_SEQ(_1);
    _49CompileErr(335LL, _25190, 0LL);
    _25190 = NOVALUE;
L6: 
L5: 

    /** coverage.e:73		if db_open( coverage_db_name ) = DB_OK then*/
    RefDS(_50coverage_db_name_48897);
    _25191 = _41db_open(_50coverage_db_name_48897, 0LL);
    if (binary_op_a(NOTEQ, _25191, 0LL)){
        DeRef(_25191);
        _25191 = NOVALUE;
        goto L7; // [164] 177
    }
    DeRef(_25191);
    _25191 = NOVALUE;

    /** coverage.e:74			read_coverage_db()*/
    _50read_coverage_db();

    /** coverage.e:75			db_close()*/
    _41db_close();
L7: 

    /** coverage.e:77	end procedure*/
    return;
    ;
}


void _50write_map(object _coverage_48961, object _table_name_48962)
{
    object _keys_48986 = NOVALUE;
    object _rec_48991 = NOVALUE;
    object _val_48995 = NOVALUE;
    object _31794 = NOVALUE;
    object _25208 = NOVALUE;
    object _25205 = NOVALUE;
    object _25203 = NOVALUE;
    object _25202 = NOVALUE;
    object _25200 = NOVALUE;
    object _25199 = NOVALUE;
    object _25197 = NOVALUE;
    object _25195 = NOVALUE;
    object _25193 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:80		if db_select( coverage_db_name, DB_LOCK_EXCLUSIVE) = DB_OK then*/
    RefDS(_50coverage_db_name_48897);
    _25193 = _41db_select(_50coverage_db_name_48897, 2LL);
    if (binary_op_a(NOTEQ, _25193, 0LL)){
        DeRef(_25193);
        _25193 = NOVALUE;
        goto L1; // [16] 63
    }
    DeRef(_25193);
    _25193 = NOVALUE;

    /** coverage.e:81			if db_select_table( table_name ) != DB_OK then*/
    RefDS(_table_name_48962);
    _25195 = _41db_select_table(_table_name_48962);
    if (binary_op_a(EQUALS, _25195, 0LL)){
        DeRef(_25195);
        _25195 = NOVALUE;
        goto L2; // [28] 77
    }
    DeRef(_25195);
    _25195 = NOVALUE;

    /** coverage.e:82				if db_create_table( table_name ) != DB_OK then*/
    RefDS(_table_name_48962);
    _25197 = _41db_create_table(_table_name_48962, 50LL);
    if (binary_op_a(EQUALS, _25197, 0LL)){
        DeRef(_25197);
        _25197 = NOVALUE;
        goto L2; // [41] 77
    }
    DeRef(_25197);
    _25197 = NOVALUE;

    /** coverage.e:83					CompileErr( COULD_NOT_CREATE_COVERAGE_TABLE_1, {table_name} )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_table_name_48962);
    ((intptr_t*)_2)[1] = _table_name_48962;
    _25199 = MAKE_SEQ(_1);
    _49CompileErr(336LL, _25199, 0LL);
    _25199 = NOVALUE;
    goto L2; // [60] 77
L1: 

    /** coverage.e:87			CompileErr( COULD_NOT_CREATE_COVERAGE_TABLE_1, {table_name} )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_table_name_48962);
    ((intptr_t*)_2)[1] = _table_name_48962;
    _25200 = MAKE_SEQ(_1);
    _49CompileErr(336LL, _25200, 0LL);
    _25200 = NOVALUE;
L2: 

    /** coverage.e:90		sequence keys = map:keys( coverage )*/
    Ref(_coverage_48961);
    _0 = _keys_48986;
    _keys_48986 = _34keys(_coverage_48961, 0LL);
    DeRef(_0);

    /** coverage.e:91		for i = 1 to length( keys ) do*/
    if (IS_SEQUENCE(_keys_48986)){
            _25202 = SEQ_PTR(_keys_48986)->length;
    }
    else {
        _25202 = 1;
    }
    {
        object _i_48989;
        _i_48989 = 1LL;
L3: 
        if (_i_48989 > _25202){
            goto L4; // [91] 171
        }

        /** coverage.e:92			integer rec = db_find_key( keys[i] )*/
        _2 = (object)SEQ_PTR(_keys_48986);
        _25203 = (object)*(((s1_ptr)_2)->base + _i_48989);
        Ref(_25203);
        RefDS(_41current_table_name_15729);
        _rec_48991 = _41db_find_key(_25203, _41current_table_name_15729);
        _25203 = NOVALUE;
        if (!IS_ATOM_INT(_rec_48991)) {
            _1 = (object)(DBL_PTR(_rec_48991)->dbl);
            DeRefDS(_rec_48991);
            _rec_48991 = _1;
        }

        /** coverage.e:93			integer val = map:get( coverage, keys[i] )*/
        _2 = (object)SEQ_PTR(_keys_48986);
        _25205 = (object)*(((s1_ptr)_2)->base + _i_48989);
        Ref(_coverage_48961);
        Ref(_25205);
        _val_48995 = _34get(_coverage_48961, _25205, 0LL);
        _25205 = NOVALUE;
        if (!IS_ATOM_INT(_val_48995)) {
            _1 = (object)(DBL_PTR(_val_48995)->dbl);
            DeRefDS(_val_48995);
            _val_48995 = _1;
        }

        /** coverage.e:94			if rec > 0 then*/
        if (_rec_48991 <= 0LL)
        goto L5; // [129] 145

        /** coverage.e:95				db_replace_data( rec, val )*/
        RefDS(_41current_table_name_15729);
        _41db_replace_data(_rec_48991, _val_48995, _41current_table_name_15729);
        goto L6; // [142] 162
L5: 

        /** coverage.e:97				db_insert( keys[i], val )*/
        _2 = (object)SEQ_PTR(_keys_48986);
        _25208 = (object)*(((s1_ptr)_2)->base + _i_48989);
        Ref(_25208);
        RefDS(_41current_table_name_15729);
        _31794 = _41db_insert(_25208, _val_48995, _41current_table_name_15729);
        _25208 = NOVALUE;
        DeRef(_31794);
        _31794 = NOVALUE;
L6: 

        /** coverage.e:99		end for*/
        _i_48989 = _i_48989 + 1LL;
        goto L3; // [166] 98
L4: 
        ;
    }

    /** coverage.e:101	end procedure*/
    DeRef(_coverage_48961);
    DeRefDS(_table_name_48962);
    DeRef(_keys_48986);
    return;
    ;
}


object _50write_coverage_db()
{
    object _25225 = NOVALUE;
    object _25224 = NOVALUE;
    object _25222 = NOVALUE;
    object _25221 = NOVALUE;
    object _25220 = NOVALUE;
    object _25218 = NOVALUE;
    object _25217 = NOVALUE;
    object _25216 = NOVALUE;
    object _25213 = NOVALUE;
    object _25211 = NOVALUE;
    object _25209 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:105		if wrote_coverage then*/
    if (_50wrote_coverage_49004 == 0)
    {
        goto L1; // [5] 15
    }
    else{
    }

    /** coverage.e:106			return 1*/
    return 1LL;
L1: 

    /** coverage.e:108		wrote_coverage = 1*/
    _50wrote_coverage_49004 = 1LL;

    /** coverage.e:109		init_coverage()*/
    _50init_coverage();

    /** coverage.e:110		if not length( covered_files ) then*/
    if (IS_SEQUENCE(_50covered_files_48895)){
            _25209 = SEQ_PTR(_50covered_files_48895)->length;
    }
    else {
        _25209 = 1;
    }
    if (_25209 != 0)
    goto L2; // [31] 41
    _25209 = NOVALUE;

    /** coverage.e:111			return 1*/
    return 1LL;
L2: 

    /** coverage.e:114		if DB_OK != db_open( coverage_db_name, DB_LOCK_EXCLUSIVE) then*/
    RefDS(_50coverage_db_name_48897);
    _25211 = _41db_open(_50coverage_db_name_48897, 2LL);
    if (binary_op_a(EQUALS, 0LL, _25211)){
        DeRef(_25211);
        _25211 = NOVALUE;
        goto L3; // [54] 95
    }
    DeRef(_25211);
    _25211 = NOVALUE;

    /** coverage.e:115			if DB_OK != db_create( coverage_db_name ) then*/
    RefDS(_50coverage_db_name_48897);
    _25213 = _41db_create(_50coverage_db_name_48897, 0LL, 5LL, 5LL);
    if (binary_op_a(EQUALS, 0LL, _25213)){
        DeRef(_25213);
        _25213 = NOVALUE;
        goto L4; // [71] 94
    }
    DeRef(_25213);
    _25213 = NOVALUE;

    /** coverage.e:116				printf(2, "error opening %s\n", {coverage_db_name})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_50coverage_db_name_48897);
    ((intptr_t*)_2)[1] = _50coverage_db_name_48897;
    _25216 = MAKE_SEQ(_1);
    EPrintf(2LL, _25215, _25216);
    DeRefDS(_25216);
    _25216 = NOVALUE;

    /** coverage.e:117				return 0*/
    return 0LL;
L4: 
L3: 

    /** coverage.e:121		process_lines()*/
    _50process_lines();

    /** coverage.e:122		for tx = 1 to length( routine_map ) do*/
    if (IS_SEQUENCE(_50routine_map_48901)){
            _25217 = SEQ_PTR(_50routine_map_48901)->length;
    }
    else {
        _25217 = 1;
    }
    {
        object _tx_49026;
        _tx_49026 = 1LL;
L5: 
        if (_tx_49026 > _25217){
            goto L6; // [106] 164
        }

        /** coverage.e:123			write_map( routine_map[tx], 'r' & covered_files[tx] )*/
        _2 = (object)SEQ_PTR(_50routine_map_48901);
        _25218 = (object)*(((s1_ptr)_2)->base + _tx_49026);
        _2 = (object)SEQ_PTR(_50covered_files_48895);
        _25220 = (object)*(((s1_ptr)_2)->base + _tx_49026);
        if (IS_SEQUENCE(114LL) && IS_ATOM(_25220)) {
        }
        else if (IS_ATOM(114LL) && IS_SEQUENCE(_25220)) {
            Prepend(&_25221, _25220, 114LL);
        }
        else {
            Concat((object_ptr)&_25221, 114LL, _25220);
        }
        _25220 = NOVALUE;
        Ref(_25218);
        _50write_map(_25218, _25221);
        _25218 = NOVALUE;
        _25221 = NOVALUE;

        /** coverage.e:124			write_map( line_map[tx],    'l' & covered_files[tx] )*/
        _2 = (object)SEQ_PTR(_50line_map_48900);
        _25222 = (object)*(((s1_ptr)_2)->base + _tx_49026);
        _2 = (object)SEQ_PTR(_50covered_files_48895);
        _25224 = (object)*(((s1_ptr)_2)->base + _tx_49026);
        if (IS_SEQUENCE(108LL) && IS_ATOM(_25224)) {
        }
        else if (IS_ATOM(108LL) && IS_SEQUENCE(_25224)) {
            Prepend(&_25225, _25224, 108LL);
        }
        else {
            Concat((object_ptr)&_25225, 108LL, _25224);
        }
        _25224 = NOVALUE;
        Ref(_25222);
        _50write_map(_25222, _25225);
        _25222 = NOVALUE;
        _25225 = NOVALUE;

        /** coverage.e:125		end for*/
        _tx_49026 = _tx_49026 + 1LL;
        goto L5; // [159] 113
L6: 
        ;
    }

    /** coverage.e:127		db_close()*/
    _41db_close();

    /** coverage.e:129		routine_map = {}*/
    RefDS(_22024);
    DeRef(_50routine_map_48901);
    _50routine_map_48901 = _22024;

    /** coverage.e:130		line_map    = {}*/
    RefDS(_22024);
    DeRef(_50line_map_48900);
    _50line_map_48900 = _22024;

    /** coverage.e:131		return 1*/
    return 1LL;
    ;
}


void _50read_coverage_db()
{
    object _tables_49039 = NOVALUE;
    object _name_49045 = NOVALUE;
    object _fx_49049 = NOVALUE;
    object _the_map_49056 = NOVALUE;
    object _31793 = NOVALUE;
    object _25241 = NOVALUE;
    object _25240 = NOVALUE;
    object _25239 = NOVALUE;
    object _25235 = NOVALUE;
    object _25234 = NOVALUE;
    object _25233 = NOVALUE;
    object _25229 = NOVALUE;
    object _25228 = NOVALUE;
    object _25227 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:135		sequence tables = db_table_list()*/
    _0 = _tables_49039;
    _tables_49039 = _41db_table_list();
    DeRef(_0);

    /** coverage.e:137		for i = 1 to length( tables ) do*/
    if (IS_SEQUENCE(_tables_49039)){
            _25227 = SEQ_PTR(_tables_49039)->length;
    }
    else {
        _25227 = 1;
    }
    {
        object _i_49043;
        _i_49043 = 1LL;
L1: 
        if (_i_49043 > _25227){
            goto L2; // [13] 157
        }

        /** coverage.e:138			sequence name = tables[i][2..$]*/
        _2 = (object)SEQ_PTR(_tables_49039);
        _25228 = (object)*(((s1_ptr)_2)->base + _i_49043);
        if (IS_SEQUENCE(_25228)){
                _25229 = SEQ_PTR(_25228)->length;
        }
        else {
            _25229 = 1;
        }
        rhs_slice_target = (object_ptr)&_name_49045;
        RHS_Slice(_25228, 2LL, _25229);
        _25228 = NOVALUE;

        /** coverage.e:139			integer fx = find( name, covered_files )*/
        _fx_49049 = find_from(_name_49045, _50covered_files_48895, 1LL);

        /** coverage.e:140			if not fx then*/
        if (_fx_49049 != 0)
        goto L3; // [45] 55

        /** coverage.e:141				continue*/
        DeRefDS(_name_49045);
        _name_49045 = NOVALUE;
        DeRef(_the_map_49056);
        _the_map_49056 = NOVALUE;
        goto L4; // [52] 152
L3: 

        /** coverage.e:144			db_select_table( tables[i] )*/
        _2 = (object)SEQ_PTR(_tables_49039);
        _25233 = (object)*(((s1_ptr)_2)->base + _i_49043);
        Ref(_25233);
        _31793 = _41db_select_table(_25233);
        _25233 = NOVALUE;
        DeRef(_31793);
        _31793 = NOVALUE;

        /** coverage.e:146			if tables[i][1] = 'r' then*/
        _2 = (object)SEQ_PTR(_tables_49039);
        _25234 = (object)*(((s1_ptr)_2)->base + _i_49043);
        _2 = (object)SEQ_PTR(_25234);
        _25235 = (object)*(((s1_ptr)_2)->base + 1LL);
        _25234 = NOVALUE;
        if (binary_op_a(NOTEQ, _25235, 114LL)){
            _25235 = NOVALUE;
            goto L5; // [77] 92
        }
        _25235 = NOVALUE;

        /** coverage.e:148				the_map = routine_map[fx]*/
        DeRef(_the_map_49056);
        _2 = (object)SEQ_PTR(_50routine_map_48901);
        _the_map_49056 = (object)*(((s1_ptr)_2)->base + _fx_49049);
        Ref(_the_map_49056);
        goto L6; // [89] 101
L5: 

        /** coverage.e:152				the_map = line_map[fx]*/
        DeRef(_the_map_49056);
        _2 = (object)SEQ_PTR(_50line_map_48900);
        _the_map_49056 = (object)*(((s1_ptr)_2)->base + _fx_49049);
        Ref(_the_map_49056);
L6: 

        /** coverage.e:156			for j = 1 to db_table_size() do*/
        RefDS(_41current_table_name_15729);
        _25239 = _41db_table_size(_41current_table_name_15729);
        {
            object _j_49065;
            _j_49065 = 1LL;
L7: 
            if (binary_op_a(GREATER, _j_49065, _25239)){
                goto L8; // [109] 148
            }

            /** coverage.e:157				map:put( the_map, db_record_key( j ), db_record_data( j ), map:ADD )*/
            Ref(_j_49065);
            RefDS(_41current_table_name_15729);
            _25240 = _41db_record_key(_j_49065, _41current_table_name_15729);
            Ref(_j_49065);
            RefDS(_41current_table_name_15729);
            _25241 = _41db_record_data(_j_49065, _41current_table_name_15729);
            Ref(_the_map_49056);
            _34put(_the_map_49056, _25240, _25241, 2LL, 0LL);
            _25240 = NOVALUE;
            _25241 = NOVALUE;

            /** coverage.e:158			end for*/
            _0 = _j_49065;
            if (IS_ATOM_INT(_j_49065)) {
                _j_49065 = _j_49065 + 1LL;
                if ((object)((uintptr_t)_j_49065 +(uintptr_t) HIGH_BITS) >= 0){
                    _j_49065 = NewDouble((eudouble)_j_49065);
                }
            }
            else {
                _j_49065 = binary_op_a(PLUS, _j_49065, 1LL);
            }
            DeRef(_0);
            goto L7; // [143] 116
L8: 
            ;
            DeRef(_j_49065);
        }
        DeRef(_name_49045);
        _name_49045 = NOVALUE;
        DeRef(_the_map_49056);
        _the_map_49056 = NOVALUE;

        /** coverage.e:160		end for*/
L4: 
        _i_49043 = _i_49043 + 1LL;
        goto L1; // [152] 20
L2: 
        ;
    }

    /** coverage.e:161	end procedure*/
    DeRef(_tables_49039);
    DeRef(_25239);
    _25239 = NOVALUE;
    return;
    ;
}


void _50coverage_db(object _name_49074)
{
    object _0, _1, _2;
    

    /** coverage.e:164		coverage_db_name = name*/
    RefDS(_name_49074);
    DeRef(_50coverage_db_name_48897);
    _50coverage_db_name_48897 = _name_49074;

    /** coverage.e:165	end procedure*/
    DeRefDS(_name_49074);
    return;
    ;
}


object _50coverage_on()
{
    object _25242 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:170		return file_coverage[current_file_no]*/
    _2 = (object)SEQ_PTR(_50file_coverage_48896);
    _25242 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    return _25242;
    ;
}


void _50new_covered_path(object _name_49086)
{
    object _new_1__tmp_at14_49090 = NOVALUE;
    object _new_inlined_new_at_14_49089 = NOVALUE;
    object _new_1__tmp_at36_49094 = NOVALUE;
    object _new_inlined_new_at_36_49093 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:176		covered_files = append( covered_files, name )*/
    RefDS(_name_49086);
    Append(&_50covered_files_48895, _50covered_files_48895, _name_49086);

    /** coverage.e:177		routine_map &= map:new()*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at14_49090;
    _new_1__tmp_at14_49090 = _34new_map_seq(8LL);
    DeRef(_0);
    Ref(_new_1__tmp_at14_49090);
    _0 = _new_inlined_new_at_14_49089;
    _new_inlined_new_at_14_49089 = _35malloc(_new_1__tmp_at14_49090, 1LL);
    DeRef(_0);
    DeRef(_new_1__tmp_at14_49090);
    _new_1__tmp_at14_49090 = NOVALUE;
    if (IS_SEQUENCE(_50routine_map_48901) && IS_ATOM(_new_inlined_new_at_14_49089)) {
        Ref(_new_inlined_new_at_14_49089);
        Append(&_50routine_map_48901, _50routine_map_48901, _new_inlined_new_at_14_49089);
    }
    else if (IS_ATOM(_50routine_map_48901) && IS_SEQUENCE(_new_inlined_new_at_14_49089)) {
    }
    else {
        Concat((object_ptr)&_50routine_map_48901, _50routine_map_48901, _new_inlined_new_at_14_49089);
    }

    /** coverage.e:178		line_map    &= map:new()*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at36_49094;
    _new_1__tmp_at36_49094 = _34new_map_seq(8LL);
    DeRef(_0);
    Ref(_new_1__tmp_at36_49094);
    _0 = _new_inlined_new_at_36_49093;
    _new_inlined_new_at_36_49093 = _35malloc(_new_1__tmp_at36_49094, 1LL);
    DeRef(_0);
    DeRef(_new_1__tmp_at36_49094);
    _new_1__tmp_at36_49094 = NOVALUE;
    if (IS_SEQUENCE(_50line_map_48900) && IS_ATOM(_new_inlined_new_at_36_49093)) {
        Ref(_new_inlined_new_at_36_49093);
        Append(&_50line_map_48900, _50line_map_48900, _new_inlined_new_at_36_49093);
    }
    else if (IS_ATOM(_50line_map_48900) && IS_SEQUENCE(_new_inlined_new_at_36_49093)) {
    }
    else {
        Concat((object_ptr)&_50line_map_48900, _50line_map_48900, _new_inlined_new_at_36_49093);
    }

    /** coverage.e:179	end procedure*/
    DeRefDS(_name_49086);
    return;
    ;
}


void _50add_coverage(object _cover_this_49098)
{
    object _path_49099 = NOVALUE;
    object _files_49108 = NOVALUE;
    object _subpath_49136 = NOVALUE;
    object _25281 = NOVALUE;
    object _25280 = NOVALUE;
    object _25279 = NOVALUE;
    object _25278 = NOVALUE;
    object _25277 = NOVALUE;
    object _25276 = NOVALUE;
    object _25275 = NOVALUE;
    object _25274 = NOVALUE;
    object _25273 = NOVALUE;
    object _25272 = NOVALUE;
    object _25271 = NOVALUE;
    object _25270 = NOVALUE;
    object _25268 = NOVALUE;
    object _25267 = NOVALUE;
    object _25266 = NOVALUE;
    object _25265 = NOVALUE;
    object _25264 = NOVALUE;
    object _25263 = NOVALUE;
    object _25262 = NOVALUE;
    object _25261 = NOVALUE;
    object _25259 = NOVALUE;
    object _25258 = NOVALUE;
    object _25257 = NOVALUE;
    object _25256 = NOVALUE;
    object _25255 = NOVALUE;
    object _25254 = NOVALUE;
    object _25253 = NOVALUE;
    object _25252 = NOVALUE;
    object _25249 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:185		sequence path = canonical_path( cover_this,, CORRECT )*/
    RefDS(_cover_this_49098);
    _0 = _path_49099;
    _path_49099 = _14canonical_path(_cover_this_49098, 0LL, 2LL);
    DeRef(_0);

    /** coverage.e:187		if file_type( path ) = FILETYPE_DIRECTORY then*/
    RefDS(_path_49099);
    _25249 = _14file_type(_path_49099);
    if (binary_op_a(NOTEQ, _25249, 2LL)){
        DeRef(_25249);
        _25249 = NOVALUE;
        goto L1; // [23] 211
    }
    DeRef(_25249);
    _25249 = NOVALUE;

    /** coverage.e:188			sequence files = dir( path  )*/
    RefDS(_path_49099);
    _0 = _files_49108;
    _files_49108 = _14dir(_path_49099);
    DeRef(_0);

    /** coverage.e:190			for i = 1 to length( files ) do*/
    if (IS_SEQUENCE(_files_49108)){
            _25252 = SEQ_PTR(_files_49108)->length;
    }
    else {
        _25252 = 1;
    }
    {
        object _i_49112;
        _i_49112 = 1LL;
L2: 
        if (_i_49112 > _25252){
            goto L3; // [40] 206
        }

        /** coverage.e:191				if find( 'd', files[i][D_ATTRIBUTES] ) then*/
        _2 = (object)SEQ_PTR(_files_49108);
        _25253 = (object)*(((s1_ptr)_2)->base + _i_49112);
        _2 = (object)SEQ_PTR(_25253);
        _25254 = (object)*(((s1_ptr)_2)->base + 2LL);
        _25253 = NOVALUE;
        _25255 = find_from(100LL, _25254, 1LL);
        _25254 = NOVALUE;
        if (_25255 == 0)
        {
            _25255 = NOVALUE;
            goto L4; // [64] 118
        }
        else{
            _25255 = NOVALUE;
        }

        /** coverage.e:192					if not eu:find(files[i][D_NAME], {".", ".."}) then*/
        _2 = (object)SEQ_PTR(_files_49108);
        _25256 = (object)*(((s1_ptr)_2)->base + _i_49112);
        _2 = (object)SEQ_PTR(_25256);
        _25257 = (object)*(((s1_ptr)_2)->base + 1LL);
        _25256 = NOVALUE;
        RefDS(_23233);
        RefDS(_23234);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _23234;
        ((intptr_t *)_2)[2] = _23233;
        _25258 = MAKE_SEQ(_1);
        _25259 = find_from(_25257, _25258, 1LL);
        _25257 = NOVALUE;
        DeRefDS(_25258);
        _25258 = NOVALUE;
        if (_25259 != 0)
        goto L5; // [88] 199
        _25259 = NOVALUE;

        /** coverage.e:193						add_coverage( cover_this & SLASH & files[i][D_NAME] )*/
        _2 = (object)SEQ_PTR(_files_49108);
        _25261 = (object)*(((s1_ptr)_2)->base + _i_49112);
        _2 = (object)SEQ_PTR(_25261);
        _25262 = (object)*(((s1_ptr)_2)->base + 1LL);
        _25261 = NOVALUE;
        {
            object concat_list[3];

            concat_list[0] = _25262;
            concat_list[1] = 47LL;
            concat_list[2] = _cover_this_49098;
            Concat_N((object_ptr)&_25263, concat_list, 3);
        }
        _25262 = NOVALUE;
        _50add_coverage(_25263);
        _25263 = NOVALUE;
        goto L5; // [115] 199
L4: 

        /** coverage.e:196				elsif regex:has_match( eu_file, files[i][D_NAME] ) then*/
        _2 = (object)SEQ_PTR(_files_49108);
        _25264 = (object)*(((s1_ptr)_2)->base + _i_49112);
        _2 = (object)SEQ_PTR(_25264);
        _25265 = (object)*(((s1_ptr)_2)->base + 1LL);
        _25264 = NOVALUE;
        Ref(_50eu_file_49080);
        Ref(_25265);
        _25266 = _51has_match(_50eu_file_49080, _25265, 1LL, 0LL);
        _25265 = NOVALUE;
        if (_25266 == 0) {
            DeRef(_25266);
            _25266 = NOVALUE;
            goto L6; // [139] 196
        }
        else {
            if (!IS_ATOM_INT(_25266) && DBL_PTR(_25266)->dbl == 0.0){
                DeRef(_25266);
                _25266 = NOVALUE;
                goto L6; // [139] 196
            }
            DeRef(_25266);
            _25266 = NOVALUE;
        }
        DeRef(_25266);
        _25266 = NOVALUE;

        /** coverage.e:198					sequence subpath = path & SLASH & files[i][D_NAME]*/
        _2 = (object)SEQ_PTR(_files_49108);
        _25267 = (object)*(((s1_ptr)_2)->base + _i_49112);
        _2 = (object)SEQ_PTR(_25267);
        _25268 = (object)*(((s1_ptr)_2)->base + 1LL);
        _25267 = NOVALUE;
        {
            object concat_list[3];

            concat_list[0] = _25268;
            concat_list[1] = 47LL;
            concat_list[2] = _path_49099;
            Concat_N((object_ptr)&_subpath_49136, concat_list, 3);
        }
        _25268 = NOVALUE;

        /** coverage.e:199					if not find( subpath, covered_files ) and not excluded( subpath ) then*/
        _25270 = find_from(_subpath_49136, _50covered_files_48895, 1LL);
        _25271 = (_25270 == 0);
        _25270 = NOVALUE;
        if (_25271 == 0) {
            goto L7; // [174] 195
        }
        RefDS(_subpath_49136);
        _25273 = _50excluded(_subpath_49136);
        if (IS_ATOM_INT(_25273)) {
            _25274 = (_25273 == 0);
        }
        else {
            _25274 = unary_op(NOT, _25273);
        }
        DeRef(_25273);
        _25273 = NOVALUE;
        if (_25274 == 0) {
            DeRef(_25274);
            _25274 = NOVALUE;
            goto L7; // [186] 195
        }
        else {
            if (!IS_ATOM_INT(_25274) && DBL_PTR(_25274)->dbl == 0.0){
                DeRef(_25274);
                _25274 = NOVALUE;
                goto L7; // [186] 195
            }
            DeRef(_25274);
            _25274 = NOVALUE;
        }
        DeRef(_25274);
        _25274 = NOVALUE;

        /** coverage.e:200						new_covered_path( subpath )*/
        RefDS(_subpath_49136);
        _50new_covered_path(_subpath_49136);
L7: 
L6: 
        DeRef(_subpath_49136);
        _subpath_49136 = NOVALUE;
L5: 

        /** coverage.e:203			end for*/
        _i_49112 = _i_49112 + 1LL;
        goto L2; // [201] 47
L3: 
        ;
    }
    DeRef(_files_49108);
    _files_49108 = NOVALUE;
    goto L8; // [208] 262
L1: 

    /** coverage.e:204		elsif regex:has_match( eu_file, path ) and*/
    Ref(_50eu_file_49080);
    RefDS(_path_49099);
    _25275 = _51has_match(_50eu_file_49080, _path_49099, 1LL, 0LL);
    if (IS_ATOM_INT(_25275)) {
        if (_25275 == 0) {
            DeRef(_25276);
            _25276 = 0;
            goto L9; // [222] 240
        }
    }
    else {
        if (DBL_PTR(_25275)->dbl == 0.0) {
            DeRef(_25276);
            _25276 = 0;
            goto L9; // [222] 240
        }
    }
    _25277 = find_from(_path_49099, _50covered_files_48895, 1LL);
    _25278 = (_25277 == 0);
    _25277 = NOVALUE;
    DeRef(_25276);
    _25276 = (_25278 != 0);
L9: 
    if (_25276 == 0) {
        goto LA; // [240] 261
    }
    RefDS(_path_49099);
    _25280 = _50excluded(_path_49099);
    if (IS_ATOM_INT(_25280)) {
        _25281 = (_25280 == 0);
    }
    else {
        _25281 = unary_op(NOT, _25280);
    }
    DeRef(_25280);
    _25280 = NOVALUE;
    if (_25281 == 0) {
        DeRef(_25281);
        _25281 = NOVALUE;
        goto LA; // [252] 261
    }
    else {
        if (!IS_ATOM_INT(_25281) && DBL_PTR(_25281)->dbl == 0.0){
            DeRef(_25281);
            _25281 = NOVALUE;
            goto LA; // [252] 261
        }
        DeRef(_25281);
        _25281 = NOVALUE;
    }
    DeRef(_25281);
    _25281 = NOVALUE;

    /** coverage.e:207			new_covered_path( path )*/
    RefDS(_path_49099);
    _50new_covered_path(_path_49099);
LA: 
L8: 

    /** coverage.e:209	end procedure*/
    DeRefDS(_cover_this_49098);
    DeRef(_path_49099);
    DeRef(_25271);
    _25271 = NOVALUE;
    DeRef(_25275);
    _25275 = NOVALUE;
    DeRef(_25278);
    _25278 = NOVALUE;
    return;
    ;
}


object _50excluded(object _file_49160)
{
    object _25284 = NOVALUE;
    object _25283 = NOVALUE;
    object _25282 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:212		for i = 1 to length( exclusion_patterns ) do*/
    if (IS_SEQUENCE(_50exclusion_patterns_48899)){
            _25282 = SEQ_PTR(_50exclusion_patterns_48899)->length;
    }
    else {
        _25282 = 1;
    }
    {
        object _i_49162;
        _i_49162 = 1LL;
L1: 
        if (_i_49162 > _25282){
            goto L2; // [10] 49
        }

        /** coverage.e:213			if regex:has_match( exclusion_patterns[i], file ) then*/
        _2 = (object)SEQ_PTR(_50exclusion_patterns_48899);
        _25283 = (object)*(((s1_ptr)_2)->base + _i_49162);
        Ref(_25283);
        RefDS(_file_49160);
        _25284 = _51has_match(_25283, _file_49160, 1LL, 0LL);
        _25283 = NOVALUE;
        if (_25284 == 0) {
            DeRef(_25284);
            _25284 = NOVALUE;
            goto L3; // [32] 42
        }
        else {
            if (!IS_ATOM_INT(_25284) && DBL_PTR(_25284)->dbl == 0.0){
                DeRef(_25284);
                _25284 = NOVALUE;
                goto L3; // [32] 42
            }
            DeRef(_25284);
            _25284 = NOVALUE;
        }
        DeRef(_25284);
        _25284 = NOVALUE;

        /** coverage.e:214				return 1*/
        DeRefDS(_file_49160);
        return 1LL;
L3: 

        /** coverage.e:216		end for*/
        _i_49162 = _i_49162 + 1LL;
        goto L1; // [44] 17
L2: 
        ;
    }

    /** coverage.e:217		return 0*/
    DeRefDS(_file_49160);
    return 0LL;
    ;
}


void _50coverage_exclude(object _patterns_49169)
{
    object _ex_49174 = NOVALUE;
    object _fx_49181 = NOVALUE;
    object _25302 = NOVALUE;
    object _25301 = NOVALUE;
    object _25300 = NOVALUE;
    object _25299 = NOVALUE;
    object _25293 = NOVALUE;
    object _25292 = NOVALUE;
    object _25290 = NOVALUE;
    object _25288 = NOVALUE;
    object _25286 = NOVALUE;
    object _25285 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:221		for i = 1 to length( patterns ) do*/
    if (IS_SEQUENCE(_patterns_49169)){
            _25285 = SEQ_PTR(_patterns_49169)->length;
    }
    else {
        _25285 = 1;
    }
    {
        object _i_49171;
        _i_49171 = 1LL;
L1: 
        if (_i_49171 > _25285){
            goto L2; // [8] 163
        }

        /** coverage.e:222			regex ex = regex:new( patterns[i] )*/
        _2 = (object)SEQ_PTR(_patterns_49169);
        _25286 = (object)*(((s1_ptr)_2)->base + _i_49171);
        Ref(_25286);
        _0 = _ex_49174;
        _ex_49174 = _51new(_25286, 0LL);
        DeRef(_0);
        _25286 = NOVALUE;

        /** coverage.e:223			if regex( ex ) then*/
        Ref(_ex_49174);
        _25288 = _51regex(_ex_49174);
        if (_25288 == 0) {
            DeRef(_25288);
            _25288 = NOVALUE;
            goto L3; // [32] 127
        }
        else {
            if (!IS_ATOM_INT(_25288) && DBL_PTR(_25288)->dbl == 0.0){
                DeRef(_25288);
                _25288 = NOVALUE;
                goto L3; // [32] 127
            }
            DeRef(_25288);
            _25288 = NOVALUE;
        }
        DeRef(_25288);
        _25288 = NOVALUE;

        /** coverage.e:224				exclusion_patterns = append( exclusion_patterns, ex )*/
        Ref(_ex_49174);
        Append(&_50exclusion_patterns_48899, _50exclusion_patterns_48899, _ex_49174);

        /** coverage.e:225				integer fx = 1*/
        _fx_49181 = 1LL;

        /** coverage.e:226				while fx <= length( covered_files ) do*/
L4: 
        if (IS_SEQUENCE(_50covered_files_48895)){
                _25290 = SEQ_PTR(_50covered_files_48895)->length;
        }
        else {
            _25290 = 1;
        }
        if (_fx_49181 > _25290)
        goto L5; // [58] 122

        /** coverage.e:227					if regex:has_match( ex, covered_files[fx] ) then*/
        _2 = (object)SEQ_PTR(_50covered_files_48895);
        _25292 = (object)*(((s1_ptr)_2)->base + _fx_49181);
        Ref(_ex_49174);
        Ref(_25292);
        _25293 = _51has_match(_ex_49174, _25292, 1LL, 0LL);
        _25292 = NOVALUE;
        if (_25293 == 0) {
            DeRef(_25293);
            _25293 = NOVALUE;
            goto L6; // [77] 110
        }
        else {
            if (!IS_ATOM_INT(_25293) && DBL_PTR(_25293)->dbl == 0.0){
                DeRef(_25293);
                _25293 = NOVALUE;
                goto L6; // [77] 110
            }
            DeRef(_25293);
            _25293 = NOVALUE;
        }
        DeRef(_25293);
        _25293 = NOVALUE;

        /** coverage.e:228						covered_files = remove( covered_files, fx )*/
        {
            s1_ptr assign_space = SEQ_PTR(_50covered_files_48895);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_49181)) ? _fx_49181 : (object)(DBL_PTR(_fx_49181)->dbl);
            int stop = (IS_ATOM_INT(_fx_49181)) ? _fx_49181 : (object)(DBL_PTR(_fx_49181)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_50covered_files_48895), start, &_50covered_files_48895 );
                }
                else Tail(SEQ_PTR(_50covered_files_48895), stop+1, &_50covered_files_48895);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_50covered_files_48895), start, &_50covered_files_48895);
            }
            else {
                assign_slice_seq = &assign_space;
                _50covered_files_48895 = Remove_elements(start, stop, (SEQ_PTR(_50covered_files_48895)->ref == 1));
            }
        }

        /** coverage.e:229						routine_map   = remove( routine_map, fx )*/
        {
            s1_ptr assign_space = SEQ_PTR(_50routine_map_48901);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_49181)) ? _fx_49181 : (object)(DBL_PTR(_fx_49181)->dbl);
            int stop = (IS_ATOM_INT(_fx_49181)) ? _fx_49181 : (object)(DBL_PTR(_fx_49181)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_50routine_map_48901), start, &_50routine_map_48901 );
                }
                else Tail(SEQ_PTR(_50routine_map_48901), stop+1, &_50routine_map_48901);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_50routine_map_48901), start, &_50routine_map_48901);
            }
            else {
                assign_slice_seq = &assign_space;
                _50routine_map_48901 = Remove_elements(start, stop, (SEQ_PTR(_50routine_map_48901)->ref == 1));
            }
        }

        /** coverage.e:230						line_map      = remove( line_map, fx )*/
        {
            s1_ptr assign_space = SEQ_PTR(_50line_map_48900);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_49181)) ? _fx_49181 : (object)(DBL_PTR(_fx_49181)->dbl);
            int stop = (IS_ATOM_INT(_fx_49181)) ? _fx_49181 : (object)(DBL_PTR(_fx_49181)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_50line_map_48900), start, &_50line_map_48900 );
                }
                else Tail(SEQ_PTR(_50line_map_48900), stop+1, &_50line_map_48900);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_50line_map_48900), start, &_50line_map_48900);
            }
            else {
                assign_slice_seq = &assign_space;
                _50line_map_48900 = Remove_elements(start, stop, (SEQ_PTR(_50line_map_48900)->ref == 1));
            }
        }
        goto L4; // [107] 53
L6: 

        /** coverage.e:232						fx += 1*/
        _fx_49181 = _fx_49181 + 1;

        /** coverage.e:234				end while*/
        goto L4; // [119] 53
L5: 
        goto L7; // [124] 154
L3: 

        /** coverage.e:236				printf( 2,"%s\n", { GetMsgText( ERROR_CREATING_REGEX_FOR_COVERAGE_EXCLUSION_PATTERN_1, 1, {patterns[i]}) } )*/
        _2 = (object)SEQ_PTR(_patterns_49169);
        _25299 = (object)*(((s1_ptr)_2)->base + _i_49171);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_25299);
        ((intptr_t*)_2)[1] = _25299;
        _25300 = MAKE_SEQ(_1);
        _25299 = NOVALUE;
        _25301 = _30GetMsgText(339LL, 1LL, _25300);
        _25300 = NOVALUE;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _25301;
        _25302 = MAKE_SEQ(_1);
        _25301 = NOVALUE;
        EPrintf(2LL, _25298, _25302);
        DeRefDS(_25302);
        _25302 = NOVALUE;
L7: 
        DeRef(_ex_49174);
        _ex_49174 = NOVALUE;

        /** coverage.e:238		end for*/
        _i_49171 = _i_49171 + 1LL;
        goto L1; // [158] 15
L2: 
        ;
    }

    /** coverage.e:240	end procedure*/
    DeRefDS(_patterns_49169);
    return;
    ;
}


void _50new_coverage_db()
{
    object _0, _1, _2;
    

    /** coverage.e:243		coverage_erase = 1*/
    _50coverage_erase_48898 = 1LL;

    /** coverage.e:244	end procedure*/
    return;
    ;
}


void _50include_line(object _line_number_49205)
{
    object _25303 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:247		if coverage_on() then*/
    _25303 = _50coverage_on();
    if (_25303 == 0) {
        DeRef(_25303);
        _25303 = NOVALUE;
        goto L1; // [8] 34
    }
    else {
        if (!IS_ATOM_INT(_25303) && DBL_PTR(_25303)->dbl == 0.0){
            DeRef(_25303);
            _25303 = NOVALUE;
            goto L1; // [8] 34
        }
        DeRef(_25303);
        _25303 = NOVALUE;
    }
    DeRef(_25303);
    _25303 = NOVALUE;

    /** coverage.e:248			emit_op( COVERAGE_LINE )*/
    _45emit_op(210LL);

    /** coverage.e:249			emit_addr( gline_number )*/
    _45emit_addr(_12gline_number_20231);

    /** coverage.e:251			included_lines &= line_number*/
    Append(&_50included_lines_48902, _50included_lines_48902, _line_number_49205);
L1: 

    /** coverage.e:253	end procedure*/
    return;
    ;
}


void _50include_routine()
{
    object _file_no_49221 = NOVALUE;
    object _25310 = NOVALUE;
    object _25309 = NOVALUE;
    object _25308 = NOVALUE;
    object _25306 = NOVALUE;
    object _25305 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:256		if coverage_on() then*/
    _25305 = _50coverage_on();
    if (_25305 == 0) {
        DeRef(_25305);
        _25305 = NOVALUE;
        goto L1; // [6] 69
    }
    else {
        if (!IS_ATOM_INT(_25305) && DBL_PTR(_25305)->dbl == 0.0){
            DeRef(_25305);
            _25305 = NOVALUE;
            goto L1; // [6] 69
        }
        DeRef(_25305);
        _25305 = NOVALUE;
    }
    DeRef(_25305);
    _25305 = NOVALUE;

    /** coverage.e:257			emit_op( COVERAGE_ROUTINE )*/
    _45emit_op(211LL);

    /** coverage.e:258			emit_addr( CurrentSub )*/
    _45emit_addr(_12CurrentSub_20234);

    /** coverage.e:261			integer file_no = SymTab[CurrentSub][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25306 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_25306);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _file_no_49221 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _file_no_49221 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    if (!IS_ATOM_INT(_file_no_49221)){
        _file_no_49221 = (object)DBL_PTR(_file_no_49221)->dbl;
    }
    _25306 = NOVALUE;

    /** coverage.e:262			map:put( routine_map[file_coverage[file_no]], sym_name( CurrentSub ), 0, map:ADD )*/
    _2 = (object)SEQ_PTR(_50file_coverage_48896);
    _25308 = (object)*(((s1_ptr)_2)->base + _file_no_49221);
    _2 = (object)SEQ_PTR(_50routine_map_48901);
    _25309 = (object)*(((s1_ptr)_2)->base + _25308);
    _25310 = _53sym_name(_12CurrentSub_20234);
    Ref(_25309);
    _34put(_25309, _25310, 0LL, 2LL, 0LL);
    _25309 = NOVALUE;
    _25310 = NOVALUE;
L1: 

    /** coverage.e:264	end procedure*/
    _25308 = NOVALUE;
    return;
    ;
}


void _50process_lines()
{
    object _sline_49249 = NOVALUE;
    object _file_49253 = NOVALUE;
    object _line_49263 = NOVALUE;
    object _25328 = NOVALUE;
    object _25326 = NOVALUE;
    object _25325 = NOVALUE;
    object _25324 = NOVALUE;
    object _25323 = NOVALUE;
    object _25322 = NOVALUE;
    object _25320 = NOVALUE;
    object _25318 = NOVALUE;
    object _25317 = NOVALUE;
    object _25315 = NOVALUE;
    object _25314 = NOVALUE;
    object _25313 = NOVALUE;
    object _25311 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:267		if not length( included_lines ) then*/
    if (IS_SEQUENCE(_50included_lines_48902)){
            _25311 = SEQ_PTR(_50included_lines_48902)->length;
    }
    else {
        _25311 = 1;
    }
    if (_25311 != 0)
    goto L1; // [8] 17
    _25311 = NOVALUE;

    /** coverage.e:268			return*/
    return;
L1: 

    /** coverage.e:270		if atom(slist[$]) then*/
    if (IS_SEQUENCE(_12slist_20317)){
            _25313 = SEQ_PTR(_12slist_20317)->length;
    }
    else {
        _25313 = 1;
    }
    _2 = (object)SEQ_PTR(_12slist_20317);
    _25314 = (object)*(((s1_ptr)_2)->base + _25313);
    _25315 = IS_ATOM(_25314);
    _25314 = NOVALUE;
    if (_25315 == 0)
    {
        _25315 = NOVALUE;
        goto L2; // [31] 45
    }
    else{
        _25315 = NOVALUE;
    }

    /** coverage.e:271			slist = s_expand( slist )*/
    RefDS(_12slist_20317);
    _0 = _61s_expand(_12slist_20317);
    DeRefDS(_12slist_20317);
    _12slist_20317 = _0;
L2: 

    /** coverage.e:273		for i = 1 to length( included_lines ) do*/
    if (IS_SEQUENCE(_50included_lines_48902)){
            _25317 = SEQ_PTR(_50included_lines_48902)->length;
    }
    else {
        _25317 = 1;
    }
    {
        object _i_49247;
        _i_49247 = 1LL;
L3: 
        if (_i_49247 > _25317){
            goto L4; // [52] 157
        }

        /** coverage.e:274			sequence sline = slist[included_lines[i]]*/
        _2 = (object)SEQ_PTR(_50included_lines_48902);
        _25318 = (object)*(((s1_ptr)_2)->base + _i_49247);
        DeRef(_sline_49249);
        _2 = (object)SEQ_PTR(_12slist_20317);
        _sline_49249 = (object)*(((s1_ptr)_2)->base + _25318);
        Ref(_sline_49249);

        /** coverage.e:275			integer file = file_coverage[sline[LOCAL_FILE_NO]]*/
        _2 = (object)SEQ_PTR(_sline_49249);
        _25320 = (object)*(((s1_ptr)_2)->base + 3LL);
        _2 = (object)SEQ_PTR(_50file_coverage_48896);
        if (!IS_ATOM_INT(_25320)){
            _file_49253 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25320)->dbl));
        }
        else{
            _file_49253 = (object)*(((s1_ptr)_2)->base + _25320);
        }

        /** coverage.e:276			if file and file <= length( line_map ) and line_map[file] then*/
        if (_file_49253 == 0) {
            _25322 = 0;
            goto L5; // [91] 108
        }
        if (IS_SEQUENCE(_50line_map_48900)){
                _25323 = SEQ_PTR(_50line_map_48900)->length;
        }
        else {
            _25323 = 1;
        }
        _25324 = (_file_49253 <= _25323);
        _25323 = NOVALUE;
        _25322 = (_25324 != 0);
L5: 
        if (_25322 == 0) {
            goto L6; // [108] 146
        }
        _2 = (object)SEQ_PTR(_50line_map_48900);
        _25326 = (object)*(((s1_ptr)_2)->base + _file_49253);
        if (_25326 == 0) {
            _25326 = NOVALUE;
            goto L6; // [119] 146
        }
        else {
            if (!IS_ATOM_INT(_25326) && DBL_PTR(_25326)->dbl == 0.0){
                _25326 = NOVALUE;
                goto L6; // [119] 146
            }
            _25326 = NOVALUE;
        }
        _25326 = NOVALUE;

        /** coverage.e:277				integer line = sline[LINE]*/
        _2 = (object)SEQ_PTR(_sline_49249);
        _line_49263 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_line_49263))
        _line_49263 = (object)DBL_PTR(_line_49263)->dbl;

        /** coverage.e:278				map:put( line_map[file], line, 0, map:ADD )*/
        _2 = (object)SEQ_PTR(_50line_map_48900);
        _25328 = (object)*(((s1_ptr)_2)->base + _file_49253);
        Ref(_25328);
        _34put(_25328, _line_49263, 0LL, 2LL, 0LL);
        _25328 = NOVALUE;
L6: 
        DeRef(_sline_49249);
        _sline_49249 = NOVALUE;

        /** coverage.e:280		end for*/
        _i_49247 = _i_49247 + 1LL;
        goto L3; // [152] 59
L4: 
        ;
    }

    /** coverage.e:281	end procedure*/
    DeRef(_25324);
    _25324 = NOVALUE;
    _25320 = NOVALUE;
    _25318 = NOVALUE;
    return;
    ;
}


object _50cover_line(object _gline_number_49269)
{
    object _sline_49279 = NOVALUE;
    object _file_49282 = NOVALUE;
    object _line_49287 = NOVALUE;
    object _25337 = NOVALUE;
    object _25334 = NOVALUE;
    object _25331 = NOVALUE;
    object _25330 = NOVALUE;
    object _25329 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_gline_number_49269)) {
        _1 = (object)(DBL_PTR(_gline_number_49269)->dbl);
        DeRefDS(_gline_number_49269);
        _gline_number_49269 = _1;
    }

    /** coverage.e:284		if atom(slist[$]) then*/
    if (IS_SEQUENCE(_12slist_20317)){
            _25329 = SEQ_PTR(_12slist_20317)->length;
    }
    else {
        _25329 = 1;
    }
    _2 = (object)SEQ_PTR(_12slist_20317);
    _25330 = (object)*(((s1_ptr)_2)->base + _25329);
    _25331 = IS_ATOM(_25330);
    _25330 = NOVALUE;
    if (_25331 == 0)
    {
        _25331 = NOVALUE;
        goto L1; // [17] 31
    }
    else{
        _25331 = NOVALUE;
    }

    /** coverage.e:285			slist = s_expand(slist)*/
    RefDS(_12slist_20317);
    _0 = _61s_expand(_12slist_20317);
    DeRefDS(_12slist_20317);
    _12slist_20317 = _0;
L1: 

    /** coverage.e:287		sequence sline = slist[gline_number]*/
    DeRef(_sline_49279);
    _2 = (object)SEQ_PTR(_12slist_20317);
    _sline_49279 = (object)*(((s1_ptr)_2)->base + _gline_number_49269);
    Ref(_sline_49279);

    /** coverage.e:288		integer file = file_coverage[sline[LOCAL_FILE_NO]]*/
    _2 = (object)SEQ_PTR(_sline_49279);
    _25334 = (object)*(((s1_ptr)_2)->base + 3LL);
    _2 = (object)SEQ_PTR(_50file_coverage_48896);
    if (!IS_ATOM_INT(_25334)){
        _file_49282 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25334)->dbl));
    }
    else{
        _file_49282 = (object)*(((s1_ptr)_2)->base + _25334);
    }

    /** coverage.e:289		if file then*/
    if (_file_49282 == 0)
    {
        goto L2; // [57] 84
    }
    else{
    }

    /** coverage.e:290			integer line = sline[LINE]*/
    _2 = (object)SEQ_PTR(_sline_49279);
    _line_49287 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_line_49287))
    _line_49287 = (object)DBL_PTR(_line_49287)->dbl;

    /** coverage.e:291			map:put( line_map[file], line, 1, map:ADD )*/
    _2 = (object)SEQ_PTR(_50line_map_48900);
    _25337 = (object)*(((s1_ptr)_2)->base + _file_49282);
    Ref(_25337);
    _34put(_25337, _line_49287, 1LL, 2LL, 0LL);
    _25337 = NOVALUE;
L2: 

    /** coverage.e:293		return 0*/
    DeRef(_sline_49279);
    _25334 = NOVALUE;
    return 0LL;
    ;
}


object _50cover_routine(object _sub_49294)
{
    object _file_no_49295 = NOVALUE;
    object _25342 = NOVALUE;
    object _25341 = NOVALUE;
    object _25340 = NOVALUE;
    object _25338 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sub_49294)) {
        _1 = (object)(DBL_PTR(_sub_49294)->dbl);
        DeRefDS(_sub_49294);
        _sub_49294 = _1;
    }

    /** coverage.e:297		integer file_no = SymTab[sub][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25338 = (object)*(((s1_ptr)_2)->base + _sub_49294);
    _2 = (object)SEQ_PTR(_25338);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _file_no_49295 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _file_no_49295 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    if (!IS_ATOM_INT(_file_no_49295)){
        _file_no_49295 = (object)DBL_PTR(_file_no_49295)->dbl;
    }
    _25338 = NOVALUE;

    /** coverage.e:298		map:put( routine_map[file_coverage[file_no]], sym_name( sub ), 1, map:ADD )*/
    _2 = (object)SEQ_PTR(_50file_coverage_48896);
    _25340 = (object)*(((s1_ptr)_2)->base + _file_no_49295);
    _2 = (object)SEQ_PTR(_50routine_map_48901);
    _25341 = (object)*(((s1_ptr)_2)->base + _25340);
    _25342 = _53sym_name(_sub_49294);
    Ref(_25341);
    _34put(_25341, _25342, 1LL, 2LL, 0LL);
    _25341 = NOVALUE;
    _25342 = NOVALUE;

    /** coverage.e:299		return 0*/
    _25340 = NOVALUE;
    return 0LL;
    ;
}



// 0x5BE24F4A
