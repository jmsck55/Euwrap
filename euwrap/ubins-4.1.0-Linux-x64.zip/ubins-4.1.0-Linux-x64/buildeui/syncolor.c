// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _71set_colors(object _pColorList_71996)
{
    object _lColorName_71997 = NOVALUE;
    object _35922 = NOVALUE;
    object _35919 = NOVALUE;
    object _35916 = NOVALUE;
    object _35913 = NOVALUE;
    object _35910 = NOVALUE;
    object _35907 = NOVALUE;
    object _35904 = NOVALUE;
    object _35899 = NOVALUE;
    object _35898 = NOVALUE;
    object _35897 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:48		for i = 1 to length(pColorList) do*/
    _35897 = 6;
    {
        object _i_71999;
        _i_71999 = 1LL;
L1: 
        if (_i_71999 > 6LL){
            goto L2; // [8] 168
        }

        /** syncolor.e:49			lColorName = text:upper(pColorList[i][1])*/
        _2 = (object)SEQ_PTR(_pColorList_71996);
        _35898 = (object)*(((s1_ptr)_2)->base + _i_71999);
        _2 = (object)SEQ_PTR(_35898);
        _35899 = (object)*(((s1_ptr)_2)->base + 1LL);
        _35898 = NOVALUE;
        Ref(_35899);
        _0 = _lColorName_71997;
        _lColorName_71997 = _18upper(_35899);
        DeRef(_0);
        _35899 = NOVALUE;

        /** syncolor.e:50			switch lColorName do*/
        _1 = find(_lColorName_71997, _35901);
        switch ( _1 ){ 

            /** syncolor.e:51				case "NORMAL" then*/
            case 1:

            /** syncolor.e:52					NORMAL_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_71996);
            _35904 = (object)*(((s1_ptr)_2)->base + _i_71999);
            _2 = (object)SEQ_PTR(_35904);
            _71NORMAL_COLOR_71985 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_71NORMAL_COLOR_71985)){
                _71NORMAL_COLOR_71985 = (object)DBL_PTR(_71NORMAL_COLOR_71985)->dbl;
            }
            _35904 = NOVALUE;
            goto L3; // [54] 161

            /** syncolor.e:53				case "COMMENT" then*/
            case 2:

            /** syncolor.e:54					COMMENT_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_71996);
            _35907 = (object)*(((s1_ptr)_2)->base + _i_71999);
            _2 = (object)SEQ_PTR(_35907);
            _71COMMENT_COLOR_71986 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_71COMMENT_COLOR_71986)){
                _71COMMENT_COLOR_71986 = (object)DBL_PTR(_71COMMENT_COLOR_71986)->dbl;
            }
            _35907 = NOVALUE;
            goto L3; // [72] 161

            /** syncolor.e:55				case "KEYWORD" then*/
            case 3:

            /** syncolor.e:56					KEYWORD_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_71996);
            _35910 = (object)*(((s1_ptr)_2)->base + _i_71999);
            _2 = (object)SEQ_PTR(_35910);
            _71KEYWORD_COLOR_71987 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_71KEYWORD_COLOR_71987)){
                _71KEYWORD_COLOR_71987 = (object)DBL_PTR(_71KEYWORD_COLOR_71987)->dbl;
            }
            _35910 = NOVALUE;
            goto L3; // [90] 161

            /** syncolor.e:57				case "BUILTIN" then*/
            case 4:

            /** syncolor.e:58					BUILTIN_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_71996);
            _35913 = (object)*(((s1_ptr)_2)->base + _i_71999);
            _2 = (object)SEQ_PTR(_35913);
            _71BUILTIN_COLOR_71988 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_71BUILTIN_COLOR_71988)){
                _71BUILTIN_COLOR_71988 = (object)DBL_PTR(_71BUILTIN_COLOR_71988)->dbl;
            }
            _35913 = NOVALUE;
            goto L3; // [108] 161

            /** syncolor.e:59				case "STRING" then*/
            case 5:

            /** syncolor.e:60					STRING_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_71996);
            _35916 = (object)*(((s1_ptr)_2)->base + _i_71999);
            _2 = (object)SEQ_PTR(_35916);
            _71STRING_COLOR_71989 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_71STRING_COLOR_71989)){
                _71STRING_COLOR_71989 = (object)DBL_PTR(_71STRING_COLOR_71989)->dbl;
            }
            _35916 = NOVALUE;
            goto L3; // [126] 161

            /** syncolor.e:61				case "BRACKET" then*/
            case 6:

            /** syncolor.e:62					BRACKET_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_71996);
            _35919 = (object)*(((s1_ptr)_2)->base + _i_71999);
            DeRef(_71BRACKET_COLOR_71990);
            _2 = (object)SEQ_PTR(_35919);
            _71BRACKET_COLOR_71990 = (object)*(((s1_ptr)_2)->base + 2LL);
            Ref(_71BRACKET_COLOR_71990);
            _35919 = NOVALUE;
            goto L3; // [144] 161

            /** syncolor.e:63				case else*/
            case 0:

            /** syncolor.e:64					printf(2, "syncolor.e: Unknown color name '%s', ignored.\n", {lColorName})*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            RefDS(_lColorName_71997);
            ((intptr_t*)_2)[1] = _lColorName_71997;
            _35922 = MAKE_SEQ(_1);
            EPrintf(2LL, _35921, _35922);
            DeRefDS(_35922);
            _35922 = NOVALUE;
        ;}L3: 

        /** syncolor.e:66		end for*/
        _i_71999 = _i_71999 + 1LL;
        goto L1; // [163] 15
L2: 
        ;
    }

    /** syncolor.e:67	end procedure*/
    DeRefDS(_pColorList_71996);
    DeRef(_lColorName_71997);
    return;
    ;
}


void _71init_class()
{
    object _0, _1, _2;
    

    /** syncolor.e:71		NORMAL_COLOR  = #330033*/
    _71NORMAL_COLOR_71985 = 3342387LL;

    /** syncolor.e:72		COMMENT_COLOR = #FF0055*/
    _71COMMENT_COLOR_71986 = 16711765LL;

    /** syncolor.e:73		KEYWORD_COLOR = #0000FF*/
    _71KEYWORD_COLOR_71987 = 255LL;

    /** syncolor.e:74		BUILTIN_COLOR = #FF00FF*/
    _71BUILTIN_COLOR_71988 = 16711935LL;

    /** syncolor.e:75		STRING_COLOR  = #00A033*/
    _71STRING_COLOR_71989 = 41011LL;

    /** syncolor.e:76		BRACKET_COLOR = {NORMAL_COLOR, #993333, #0000FF, #5500FF, #00FF00}*/
    _0 = _71BRACKET_COLOR_71990;
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 3342387LL;
    ((intptr_t*)_2)[2] = 10040115LL;
    ((intptr_t*)_2)[3] = 255LL;
    ((intptr_t*)_2)[4] = 5570815LL;
    ((intptr_t*)_2)[5] = 65280LL;
    _71BRACKET_COLOR_71990 = MAKE_SEQ(_1);
    DeRef(_0);

    /** syncolor.e:78	end procedure*/
    return;
    ;
}


object _71default_state(object _token_72063)
{
    object _35940 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:103		if not token then*/
    if (IS_ATOM_INT(_token_72063)) {
        if (_token_72063 != 0){
            goto L1; // [3] 12
        }
    }
    else {
        if (DBL_PTR(_token_72063)->dbl != 0.0){
            goto L1; // [3] 12
        }
    }

    /** syncolor.e:104			token = tokenize:new()*/
    _0 = _token_72063;
    _token_72063 = _72new();
    DeRef(_0);
L1: 

    /** syncolor.e:106		return {*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_token_72063);
    ((intptr_t*)_2)[1] = _token_72063;
    ((intptr_t*)_2)[2] = 0LL;
    ((intptr_t*)_2)[3] = 0LL;
    _35940 = MAKE_SEQ(_1);
    DeRef(_token_72063);
    return _35940;
    ;
}


object _71new()
{
    object _state_72073 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:124		atom state = eumem:malloc()*/
    _0 = _state_72073;
    _state_72073 = _35malloc(1LL, 1LL);
    DeRef(_0);

    /** syncolor.e:126		reset(state)*/
    Ref(_state_72073);
    _71reset(_state_72073);

    /** syncolor.e:128		return state*/
    return _state_72073;
    ;
}


void _71tokenize_reset(object _token_72078)
{
    object _reset_1__tmp_at7_72081 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:138		if token then*/
    if (_token_72078 == 0) {
        goto L1; // [3] 27
    }
    else {
        if (!IS_ATOM_INT(_token_72078) && DBL_PTR(_token_72078)->dbl == 0.0){
            goto L1; // [3] 27
        }
    }

    /** syncolor.e:139			tokenize:reset(token)*/

    /** tokenize.e:215		eumem:ram_space[state] = default_state()*/
    _0 = _reset_1__tmp_at7_72081;
    _reset_1__tmp_at7_72081 = _72default_state();
    DeRef(_0);
    Ref(_reset_1__tmp_at7_72081);
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_12732 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_token_72078))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_token_72078)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _token_72078);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _reset_1__tmp_at7_72081;
    DeRef(_1);

    /** tokenize.e:216	end procedure*/
    goto L2; // [21] 24
L2: 
    DeRef(_reset_1__tmp_at7_72081);
    _reset_1__tmp_at7_72081 = NOVALUE;
L1: 

    /** syncolor.e:141	end procedure*/
    DeRef(_token_72078);
    return;
    ;
}


void _71reset(object _state_72084)
{
    object _token_72085 = NOVALUE;
    object _35947 = NOVALUE;
    object _35946 = NOVALUE;
    object _35944 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:144		atom token = eumem:ram_space[state][S_TOKENIZER]*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!IS_ATOM_INT(_state_72084)){
        _35944 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_state_72084)->dbl));
    }
    else{
        _35944 = (object)*(((s1_ptr)_2)->base + _state_72084);
    }
    DeRef(_token_72085);
    _2 = (object)SEQ_PTR(_35944);
    _token_72085 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_token_72085);
    _35944 = NOVALUE;

    /** syncolor.e:145		tokenize_reset(token)*/
    Ref(_token_72085);
    _71tokenize_reset(_token_72085);

    /** syncolor.e:146		eumem:ram_space[state] = default_state(token)*/
    Ref(_token_72085);
    _35946 = _71default_state(_token_72085);
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_12732 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_72084))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_state_72084)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _state_72084);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35946;
    if( _1 != _35946 ){
        DeRef(_1);
    }
    _35946 = NOVALUE;

    /** syncolor.e:147		eumem:ram_space[state] = default_state()*/
    _35947 = _71default_state(0LL);
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_12732 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_72084))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_state_72084)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _state_72084);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35947;
    if( _1 != _35947 ){
        DeRef(_1);
    }
    _35947 = NOVALUE;

    /** syncolor.e:148	end procedure*/
    DeRef(_state_72084);
    DeRef(_token_72085);
    return;
    ;
}



// 0xD33FC0EC
