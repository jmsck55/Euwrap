// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _46exe_path()
{
    object _25886 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:70		if sequence(exe_path_cache) then*/
    _25886 = IS_SEQUENCE(_46exe_path_cache_50444);
    if (_25886 == 0)
    {
        _25886 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _25886 = NOVALUE;
    }

    /** pathopen.e:71			return exe_path_cache*/
    Ref(_46exe_path_cache_50444);
    return _46exe_path_cache_50444;
L1: 

    /** pathopen.e:74		exe_path_cache = command_line()*/
    DeRef(_46exe_path_cache_50444);
    _46exe_path_cache_50444 = Command_Line();

    /** pathopen.e:75		exe_path_cache = exe_path_cache[1]*/
    _0 = _46exe_path_cache_50444;
    _2 = (object)SEQ_PTR(_46exe_path_cache_50444);
    _46exe_path_cache_50444 = (object)*(((s1_ptr)_2)->base + 1LL);
    RefDS(_46exe_path_cache_50444);
    DeRefDS(_0);

    /** pathopen.e:77		return exe_path_cache*/
    RefDS(_46exe_path_cache_50444);
    return _46exe_path_cache_50444;
    ;
}


object _46check_cache(object _env_50456, object _inc_path_50457)
{
    object _delim_50458 = NOVALUE;
    object _pos_50459 = NOVALUE;
    object _25934 = NOVALUE;
    object _25933 = NOVALUE;
    object _25932 = NOVALUE;
    object _25931 = NOVALUE;
    object _25929 = NOVALUE;
    object _25928 = NOVALUE;
    object _25927 = NOVALUE;
    object _25926 = NOVALUE;
    object _25925 = NOVALUE;
    object _25924 = NOVALUE;
    object _25923 = NOVALUE;
    object _25922 = NOVALUE;
    object _25921 = NOVALUE;
    object _25917 = NOVALUE;
    object _25916 = NOVALUE;
    object _25915 = NOVALUE;
    object _25914 = NOVALUE;
    object _25913 = NOVALUE;
    object _25912 = NOVALUE;
    object _25911 = NOVALUE;
    object _25910 = NOVALUE;
    object _25908 = NOVALUE;
    object _25907 = NOVALUE;
    object _25906 = NOVALUE;
    object _25905 = NOVALUE;
    object _25904 = NOVALUE;
    object _25903 = NOVALUE;
    object _25901 = NOVALUE;
    object _25900 = NOVALUE;
    object _25899 = NOVALUE;
    object _25898 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:83		if not num_var then -- first time the var is accessed, add cache entry*/
    if (_46num_var_50433 != 0)
    goto L1; // [9] 86

    /** pathopen.e:84			cache_vars = append(cache_vars,env)*/
    RefDS(_env_50456);
    Append(&_46cache_vars_50434, _46cache_vars_50434, _env_50456);

    /** pathopen.e:85			cache_strings = append(cache_strings,inc_path)*/
    RefDS(_inc_path_50457);
    Append(&_46cache_strings_50435, _46cache_strings_50435, _inc_path_50457);

    /** pathopen.e:86			cache_substrings = append(cache_substrings,{})*/
    RefDS(_22024);
    Append(&_46cache_substrings_50436, _46cache_substrings_50436, _22024);

    /** pathopen.e:87			cache_starts = append(cache_starts,{})*/
    RefDS(_22024);
    Append(&_46cache_starts_50437, _46cache_starts_50437, _22024);

    /** pathopen.e:88			cache_ends = append(cache_ends,{})*/
    RefDS(_22024);
    Append(&_46cache_ends_50438, _46cache_ends_50438, _22024);

    /** pathopen.e:89			ifdef WINDOWS then*/

    /** pathopen.e:92			num_var = length(cache_vars)*/
    if (IS_SEQUENCE(_46cache_vars_50434)){
            _46num_var_50433 = SEQ_PTR(_46cache_vars_50434)->length;
    }
    else {
        _46num_var_50433 = 1;
    }

    /** pathopen.e:93			cache_complete &= 0*/
    Append(&_46cache_complete_50440, _46cache_complete_50440, 0LL);

    /** pathopen.e:94			cache_delims &= 0*/
    Append(&_46cache_delims_50441, _46cache_delims_50441, 0LL);

    /** pathopen.e:95			return 0*/
    DeRefDSi(_env_50456);
    DeRefDSi(_inc_path_50457);
    return 0LL;
    goto L2; // [83] 425
L1: 

    /** pathopen.e:97			if compare(inc_path,cache_strings[num_var]) then*/
    _2 = (object)SEQ_PTR(_46cache_strings_50435);
    _25898 = (object)*(((s1_ptr)_2)->base + _46num_var_50433);
    if (IS_ATOM_INT(_inc_path_50457) && IS_ATOM_INT(_25898)){
        _25899 = (_inc_path_50457 < _25898) ? -1 : (_inc_path_50457 > _25898);
    }
    else{
        _25899 = compare(_inc_path_50457, _25898);
    }
    _25898 = NOVALUE;
    if (_25899 == 0)
    {
        _25899 = NOVALUE;
        goto L3; // [100] 424
    }
    else{
        _25899 = NOVALUE;
    }

    /** pathopen.e:98				cache_strings[num_var] = inc_path*/
    RefDS(_inc_path_50457);
    _2 = (object)SEQ_PTR(_46cache_strings_50435);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _46cache_strings_50435 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _46num_var_50433);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _inc_path_50457;
    DeRefDS(_1);

    /** pathopen.e:99				cache_complete[num_var] = 0*/
    _2 = (object)SEQ_PTR(_46cache_complete_50440);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _46cache_complete_50440 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _46num_var_50433);
    *(intptr_t *)_2 = 0LL;

    /** pathopen.e:100				if match(cache_strings[num_var],inc_path)!=1 then -- try to salvage what we can*/
    _2 = (object)SEQ_PTR(_46cache_strings_50435);
    _25900 = (object)*(((s1_ptr)_2)->base + _46num_var_50433);
    _25901 = e_match_from(_25900, _inc_path_50457, 1LL);
    _25900 = NOVALUE;
    if (_25901 == 1LL)
    goto L4; // [138] 423

    /** pathopen.e:101					pos = -1*/
    _pos_50459 = -1LL;

    /** pathopen.e:102					for i=1 to length(cache_strings[num_var]) do*/
    _2 = (object)SEQ_PTR(_46cache_strings_50435);
    _25903 = (object)*(((s1_ptr)_2)->base + _46num_var_50433);
    if (IS_SEQUENCE(_25903)){
            _25904 = SEQ_PTR(_25903)->length;
    }
    else {
        _25904 = 1;
    }
    _25903 = NOVALUE;
    {
        object _i_50479;
        _i_50479 = 1LL;
L5: 
        if (_i_50479 > _25904){
            goto L6; // [160] 422
        }

        /** pathopen.e:103						if cache_ends[num_var][i] > length(inc_path) or */
        _2 = (object)SEQ_PTR(_46cache_ends_50438);
        _25905 = (object)*(((s1_ptr)_2)->base + _46num_var_50433);
        _2 = (object)SEQ_PTR(_25905);
        _25906 = (object)*(((s1_ptr)_2)->base + _i_50479);
        _25905 = NOVALUE;
        if (IS_SEQUENCE(_inc_path_50457)){
                _25907 = SEQ_PTR(_inc_path_50457)->length;
        }
        else {
            _25907 = 1;
        }
        if (IS_ATOM_INT(_25906)) {
            _25908 = (_25906 > _25907);
        }
        else {
            _25908 = binary_op(GREATER, _25906, _25907);
        }
        _25906 = NOVALUE;
        _25907 = NOVALUE;
        if (IS_ATOM_INT(_25908)) {
            if (_25908 != 0) {
                goto L7; // [188] 242
            }
        }
        else {
            if (DBL_PTR(_25908)->dbl != 0.0) {
                goto L7; // [188] 242
            }
        }
        _2 = (object)SEQ_PTR(_46cache_substrings_50436);
        _25910 = (object)*(((s1_ptr)_2)->base + _46num_var_50433);
        _2 = (object)SEQ_PTR(_25910);
        _25911 = (object)*(((s1_ptr)_2)->base + _i_50479);
        _25910 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_starts_50437);
        _25912 = (object)*(((s1_ptr)_2)->base + _46num_var_50433);
        _2 = (object)SEQ_PTR(_25912);
        _25913 = (object)*(((s1_ptr)_2)->base + _i_50479);
        _25912 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_ends_50438);
        _25914 = (object)*(((s1_ptr)_2)->base + _46num_var_50433);
        _2 = (object)SEQ_PTR(_25914);
        _25915 = (object)*(((s1_ptr)_2)->base + _i_50479);
        _25914 = NOVALUE;
        rhs_slice_target = (object_ptr)&_25916;
        RHS_Slice(_inc_path_50457, _25913, _25915);
        if (IS_ATOM_INT(_25911) && IS_ATOM_INT(_25916)){
            _25917 = (_25911 < _25916) ? -1 : (_25911 > _25916);
        }
        else{
            _25917 = compare(_25911, _25916);
        }
        _25911 = NOVALUE;
        DeRefDS(_25916);
        _25916 = NOVALUE;
        if (_25917 == 0)
        {
            _25917 = NOVALUE;
            goto L8; // [238] 253
        }
        else{
            _25917 = NOVALUE;
        }
L7: 

        /** pathopen.e:107							pos = i-1*/
        _pos_50459 = _i_50479 - 1LL;

        /** pathopen.e:108							exit*/
        goto L6; // [250] 422
L8: 

        /** pathopen.e:110						if pos = 0 then*/
        if (_pos_50459 != 0LL)
        goto L9; // [255] 268

        /** pathopen.e:111							return 0*/
        DeRefDSi(_env_50456);
        DeRefDSi(_inc_path_50457);
        DeRef(_25908);
        _25908 = NOVALUE;
        _25903 = NOVALUE;
        _25913 = NOVALUE;
        _25915 = NOVALUE;
        return 0LL;
        goto LA; // [265] 415
L9: 

        /** pathopen.e:112						elsif pos >0 then -- crop cache data*/
        if (_pos_50459 <= 0LL)
        goto LB; // [270] 414

        /** pathopen.e:113							cache_substrings[num_var] = cache_substrings[num_var][1..pos]*/
        _2 = (object)SEQ_PTR(_46cache_substrings_50436);
        _25921 = (object)*(((s1_ptr)_2)->base + _46num_var_50433);
        rhs_slice_target = (object_ptr)&_25922;
        RHS_Slice(_25921, 1LL, _pos_50459);
        _25921 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_substrings_50436);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_substrings_50436 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50433);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _25922;
        if( _1 != _25922 ){
            DeRefDS(_1);
        }
        _25922 = NOVALUE;

        /** pathopen.e:114							cache_starts[num_var] = cache_starts[num_var][1..pos]*/
        _2 = (object)SEQ_PTR(_46cache_starts_50437);
        _25923 = (object)*(((s1_ptr)_2)->base + _46num_var_50433);
        rhs_slice_target = (object_ptr)&_25924;
        RHS_Slice(_25923, 1LL, _pos_50459);
        _25923 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_starts_50437);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_starts_50437 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50433);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _25924;
        if( _1 != _25924 ){
            DeRef(_1);
        }
        _25924 = NOVALUE;

        /** pathopen.e:115							cache_ends[num_var] = cache_ends[num_var][1..pos]*/
        _2 = (object)SEQ_PTR(_46cache_ends_50438);
        _25925 = (object)*(((s1_ptr)_2)->base + _46num_var_50433);
        rhs_slice_target = (object_ptr)&_25926;
        RHS_Slice(_25925, 1LL, _pos_50459);
        _25925 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_ends_50438);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_ends_50438 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50433);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _25926;
        if( _1 != _25926 ){
            DeRef(_1);
        }
        _25926 = NOVALUE;

        /** pathopen.e:116							ifdef WINDOWS then*/

        /** pathopen.e:119							delim = cache_ends[num_var][$]+1*/
        _2 = (object)SEQ_PTR(_46cache_ends_50438);
        _25927 = (object)*(((s1_ptr)_2)->base + _46num_var_50433);
        if (IS_SEQUENCE(_25927)){
                _25928 = SEQ_PTR(_25927)->length;
        }
        else {
            _25928 = 1;
        }
        _2 = (object)SEQ_PTR(_25927);
        _25929 = (object)*(((s1_ptr)_2)->base + _25928);
        _25927 = NOVALUE;
        if (IS_ATOM_INT(_25929)) {
            _delim_50458 = _25929 + 1;
        }
        else
        { // coercing _delim_50458 to an integer 1
            _delim_50458 = 1+(object)(DBL_PTR(_25929)->dbl);
            if( !IS_ATOM_INT(_delim_50458) ){
                _delim_50458 = (object)DBL_PTR(_delim_50458)->dbl;
            }
        }
        _25929 = NOVALUE;

        /** pathopen.e:120							while delim <= length(inc_path) and delim != PATH_SEPARATOR do*/
LC: 
        if (IS_SEQUENCE(_inc_path_50457)){
                _25931 = SEQ_PTR(_inc_path_50457)->length;
        }
        else {
            _25931 = 1;
        }
        _25932 = (_delim_50458 <= _25931);
        _25931 = NOVALUE;
        if (_25932 == 0) {
            goto LD; // [378] 403
        }
        _25934 = (_delim_50458 != 58LL);
        if (_25934 == 0)
        {
            DeRef(_25934);
            _25934 = NOVALUE;
            goto LD; // [389] 403
        }
        else{
            DeRef(_25934);
            _25934 = NOVALUE;
        }

        /** pathopen.e:121								delim+=1*/
        _delim_50458 = _delim_50458 + 1;

        /** pathopen.e:122							end while*/
        goto LC; // [400] 371
LD: 

        /** pathopen.e:123							cache_delims[num_var] = delim*/
        _2 = (object)SEQ_PTR(_46cache_delims_50441);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_delims_50441 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50433);
        *(intptr_t *)_2 = _delim_50458;
LB: 
LA: 

        /** pathopen.e:125					end for*/
        _i_50479 = _i_50479 + 1LL;
        goto L5; // [417] 167
L6: 
        ;
    }
L4: 
L3: 
L2: 

    /** pathopen.e:129		return 1*/
    DeRefDSi(_env_50456);
    DeRefDSi(_inc_path_50457);
    DeRef(_25908);
    _25908 = NOVALUE;
    _25903 = NOVALUE;
    _25913 = NOVALUE;
    DeRef(_25932);
    _25932 = NOVALUE;
    _25915 = NOVALUE;
    return 1LL;
    ;
}


object _46get_conf_dirs()
{
    object _delimiter_50520 = NOVALUE;
    object _dirs_50521 = NOVALUE;
    object _25940 = NOVALUE;
    object _25938 = NOVALUE;
    object _25937 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:136		ifdef UNIX then*/

    /** pathopen.e:137			delimiter = ':'*/
    _delimiter_50520 = 58LL;

    /** pathopen.e:142		dirs = ""*/
    RefDS(_22024);
    DeRef(_dirs_50521);
    _dirs_50521 = _22024;

    /** pathopen.e:143		for i = 1 to length(config_inc_paths) do*/
    if (IS_SEQUENCE(_46config_inc_paths_50442)){
            _25937 = SEQ_PTR(_46config_inc_paths_50442)->length;
    }
    else {
        _25937 = 1;
    }
    {
        object _i_50524;
        _i_50524 = 1LL;
L1: 
        if (_i_50524 > _25937){
            goto L2; // [22] 68
        }

        /** pathopen.e:144			dirs &= config_inc_paths[i]*/
        _2 = (object)SEQ_PTR(_46config_inc_paths_50442);
        _25938 = (object)*(((s1_ptr)_2)->base + _i_50524);
        Concat((object_ptr)&_dirs_50521, _dirs_50521, _25938);
        _25938 = NOVALUE;

        /** pathopen.e:145			if i != length(config_inc_paths) then*/
        if (IS_SEQUENCE(_46config_inc_paths_50442)){
                _25940 = SEQ_PTR(_46config_inc_paths_50442)->length;
        }
        else {
            _25940 = 1;
        }
        if (_i_50524 == _25940)
        goto L3; // [48] 61

        /** pathopen.e:146				dirs &= delimiter*/
        Append(&_dirs_50521, _dirs_50521, _delimiter_50520);
L3: 

        /** pathopen.e:148		end for*/
        _i_50524 = _i_50524 + 1LL;
        goto L1; // [63] 29
L2: 
        ;
    }

    /** pathopen.e:150		return dirs*/
    return _dirs_50521;
    ;
}


object _46strip_file_from_path(object _full_path_50534)
{
    object _25946 = NOVALUE;
    object _25944 = NOVALUE;
    object _25943 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:156		for i = length(full_path) to 1 by -1 do*/
    if (IS_SEQUENCE(_full_path_50534)){
            _25943 = SEQ_PTR(_full_path_50534)->length;
    }
    else {
        _25943 = 1;
    }
    {
        object _i_50536;
        _i_50536 = _25943;
L1: 
        if (_i_50536 < 1LL){
            goto L2; // [8] 46
        }

        /** pathopen.e:157			if full_path[i] = SLASH then*/
        _2 = (object)SEQ_PTR(_full_path_50534);
        _25944 = (object)*(((s1_ptr)_2)->base + _i_50536);
        if (binary_op_a(NOTEQ, _25944, 47LL)){
            _25944 = NOVALUE;
            goto L3; // [23] 39
        }
        _25944 = NOVALUE;

        /** pathopen.e:158				return full_path[1..i]*/
        rhs_slice_target = (object_ptr)&_25946;
        RHS_Slice(_full_path_50534, 1LL, _i_50536);
        DeRefDS(_full_path_50534);
        return _25946;
L3: 

        /** pathopen.e:160		end for*/
        _i_50536 = _i_50536 + -1LL;
        goto L1; // [41] 15
L2: 
        ;
    }

    /** pathopen.e:162		return ""*/
    RefDS(_22024);
    DeRefDS(_full_path_50534);
    DeRef(_25946);
    _25946 = NOVALUE;
    return _22024;
    ;
}


object _46expand_path(object _path_50545, object _prefix_50546)
{
    object _absolute_50547 = NOVALUE;
    object _home_50551 = NOVALUE;
    object _25971 = NOVALUE;
    object _25970 = NOVALUE;
    object _25969 = NOVALUE;
    object _25968 = NOVALUE;
    object _25967 = NOVALUE;
    object _25966 = NOVALUE;
    object _25962 = NOVALUE;
    object _25960 = NOVALUE;
    object _25959 = NOVALUE;
    object _25958 = NOVALUE;
    object _25957 = NOVALUE;
    object _25956 = NOVALUE;
    object _25953 = NOVALUE;
    object _25951 = NOVALUE;
    object _25950 = NOVALUE;
    object _25949 = NOVALUE;
    object _25947 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:169		if not length(path) then*/
    if (IS_SEQUENCE(_path_50545)){
            _25947 = SEQ_PTR(_path_50545)->length;
    }
    else {
        _25947 = 1;
    }
    if (_25947 != 0)
    goto L1; // [10] 22
    _25947 = NOVALUE;

    /** pathopen.e:170			return pwd*/
    RefDS(_46pwd_50445);
    DeRefDS(_path_50545);
    DeRefDS(_prefix_50546);
    DeRefi(_home_50551);
    return _46pwd_50445;
L1: 

    /** pathopen.e:174		ifdef UNIX then*/

    /** pathopen.e:175			object home*/

    /** pathopen.e:176			if length(path) and path[1] = '~' then*/
    if (IS_SEQUENCE(_path_50545)){
            _25949 = SEQ_PTR(_path_50545)->length;
    }
    else {
        _25949 = 1;
    }
    if (_25949 == 0) {
        goto L2; // [31] 84
    }
    _2 = (object)SEQ_PTR(_path_50545);
    _25951 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_25951)) {
        _25953 = (_25951 == 126LL);
    }
    else {
        _25953 = binary_op(EQUALS, _25951, 126LL);
    }
    _25951 = NOVALUE;
    if (_25953 == 0) {
        DeRef(_25953);
        _25953 = NOVALUE;
        goto L2; // [44] 84
    }
    else {
        if (!IS_ATOM_INT(_25953) && DBL_PTR(_25953)->dbl == 0.0){
            DeRef(_25953);
            _25953 = NOVALUE;
            goto L2; // [44] 84
        }
        DeRef(_25953);
        _25953 = NOVALUE;
    }
    DeRef(_25953);
    _25953 = NOVALUE;

    /** pathopen.e:177				home = getenv("HOME")*/
    DeRefi(_home_50551);
    _home_50551 = EGetEnv(_25954);

    /** pathopen.e:178				if sequence(home) and length(home) then*/
    _25956 = IS_SEQUENCE(_home_50551);
    if (_25956 == 0) {
        goto L3; // [57] 83
    }
    if (IS_SEQUENCE(_home_50551)){
            _25958 = SEQ_PTR(_home_50551)->length;
    }
    else {
        _25958 = 1;
    }
    if (_25958 == 0)
    {
        _25958 = NOVALUE;
        goto L3; // [65] 83
    }
    else{
        _25958 = NOVALUE;
    }

    /** pathopen.e:179					path = home & path[2..$]*/
    if (IS_SEQUENCE(_path_50545)){
            _25959 = SEQ_PTR(_path_50545)->length;
    }
    else {
        _25959 = 1;
    }
    rhs_slice_target = (object_ptr)&_25960;
    RHS_Slice(_path_50545, 2LL, _25959);
    if (IS_SEQUENCE(_home_50551) && IS_ATOM(_25960)) {
    }
    else if (IS_ATOM(_home_50551) && IS_SEQUENCE(_25960)) {
        Ref(_home_50551);
        Prepend(&_path_50545, _25960, _home_50551);
    }
    else {
        Concat((object_ptr)&_path_50545, _home_50551, _25960);
    }
    DeRefDS(_25960);
    _25960 = NOVALUE;
L3: 
L2: 

    /** pathopen.e:183			absolute = find(path[1], SLASH_CHARS)*/
    _2 = (object)SEQ_PTR(_path_50545);
    _25962 = (object)*(((s1_ptr)_2)->base + 1LL);
    _absolute_50547 = find_from(_25962, _44SLASH_CHARS_20390, 1LL);
    _25962 = NOVALUE;

    /** pathopen.e:188		if not absolute then*/
    if (_absolute_50547 != 0)
    goto L4; // [101] 115

    /** pathopen.e:189			path = prefix & SLASH & path*/
    {
        object concat_list[3];

        concat_list[0] = _path_50545;
        concat_list[1] = 47LL;
        concat_list[2] = _prefix_50546;
        Concat_N((object_ptr)&_path_50545, concat_list, 3);
    }
L4: 

    /** pathopen.e:192		if length(path) and not find(path[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_path_50545)){
            _25966 = SEQ_PTR(_path_50545)->length;
    }
    else {
        _25966 = 1;
    }
    if (_25966 == 0) {
        goto L5; // [120] 154
    }
    if (IS_SEQUENCE(_path_50545)){
            _25968 = SEQ_PTR(_path_50545)->length;
    }
    else {
        _25968 = 1;
    }
    _2 = (object)SEQ_PTR(_path_50545);
    _25969 = (object)*(((s1_ptr)_2)->base + _25968);
    _25970 = find_from(_25969, _44SLASH_CHARS_20390, 1LL);
    _25969 = NOVALUE;
    _25971 = (_25970 == 0);
    _25970 = NOVALUE;
    if (_25971 == 0)
    {
        DeRef(_25971);
        _25971 = NOVALUE;
        goto L5; // [142] 154
    }
    else{
        DeRef(_25971);
        _25971 = NOVALUE;
    }

    /** pathopen.e:193			path &= SLASH*/
    Append(&_path_50545, _path_50545, 47LL);
L5: 

    /** pathopen.e:196		return path*/
    DeRefDS(_prefix_50546);
    DeRefi(_home_50551);
    return _path_50545;
    ;
}


void _46add_include_directory(object _path_50586)
{
    object _25974 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:200		path = expand_path( path, pwd )*/
    RefDS(_path_50586);
    RefDS(_46pwd_50445);
    _0 = _path_50586;
    _path_50586 = _46expand_path(_path_50586, _46pwd_50445);
    DeRefDS(_0);

    /** pathopen.e:202		if not find( path, config_inc_paths ) then*/
    _25974 = find_from(_path_50586, _46config_inc_paths_50442, 1LL);
    if (_25974 != 0)
    goto L1; // [23] 35
    _25974 = NOVALUE;

    /** pathopen.e:203			config_inc_paths = append( config_inc_paths, path )*/
    RefDS(_path_50586);
    Append(&_46config_inc_paths_50442, _46config_inc_paths_50442, _path_50586);
L1: 

    /** pathopen.e:205	end procedure*/
    DeRefDS(_path_50586);
    return;
    ;
}


object _46load_euphoria_config(object _file_50595)
{
    object _fn_50596 = NOVALUE;
    object _in_50597 = NOVALUE;
    object _spos_50598 = NOVALUE;
    object _epos_50599 = NOVALUE;
    object _conf_path_50600 = NOVALUE;
    object _new_args_50601 = NOVALUE;
    object _arg_50602 = NOVALUE;
    object _parm_50603 = NOVALUE;
    object _section_50604 = NOVALUE;
    object _needed_50703 = NOVALUE;
    object _26073 = NOVALUE;
    object _26072 = NOVALUE;
    object _26069 = NOVALUE;
    object _26067 = NOVALUE;
    object _26066 = NOVALUE;
    object _26044 = NOVALUE;
    object _26041 = NOVALUE;
    object _26040 = NOVALUE;
    object _26038 = NOVALUE;
    object _26034 = NOVALUE;
    object _26032 = NOVALUE;
    object _26030 = NOVALUE;
    object _26028 = NOVALUE;
    object _26026 = NOVALUE;
    object _26024 = NOVALUE;
    object _26023 = NOVALUE;
    object _26022 = NOVALUE;
    object _26020 = NOVALUE;
    object _26019 = NOVALUE;
    object _26018 = NOVALUE;
    object _26017 = NOVALUE;
    object _26016 = NOVALUE;
    object _26014 = NOVALUE;
    object _26011 = NOVALUE;
    object _26009 = NOVALUE;
    object _26005 = NOVALUE;
    object _26004 = NOVALUE;
    object _25999 = NOVALUE;
    object _25997 = NOVALUE;
    object _25995 = NOVALUE;
    object _25994 = NOVALUE;
    object _25986 = NOVALUE;
    object _25980 = NOVALUE;
    object _25979 = NOVALUE;
    object _25977 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:213		sequence new_args = {}*/
    RefDS(_22024);
    DeRef(_new_args_50601);
    _new_args_50601 = _22024;

    /** pathopen.e:219		if file_type(file) = FILETYPE_DIRECTORY then*/
    RefDS(_file_50595);
    _25977 = _14file_type(_file_50595);
    if (binary_op_a(NOTEQ, _25977, 2LL)){
        DeRef(_25977);
        _25977 = NOVALUE;
        goto L1; // [18] 53
    }
    DeRef(_25977);
    _25977 = NOVALUE;

    /** pathopen.e:220			if file[$] != SLASH then*/
    if (IS_SEQUENCE(_file_50595)){
            _25979 = SEQ_PTR(_file_50595)->length;
    }
    else {
        _25979 = 1;
    }
    _2 = (object)SEQ_PTR(_file_50595);
    _25980 = (object)*(((s1_ptr)_2)->base + _25979);
    if (binary_op_a(EQUALS, _25980, 47LL)){
        _25980 = NOVALUE;
        goto L2; // [33] 46
    }
    _25980 = NOVALUE;

    /** pathopen.e:221				file &= SLASH*/
    Append(&_file_50595, _file_50595, 47LL);
L2: 

    /** pathopen.e:223			file &= "eu.cfg"*/
    Concat((object_ptr)&_file_50595, _file_50595, _25983);
L1: 

    /** pathopen.e:226		conf_path = canonical_path( file,,CORRECT )*/
    RefDS(_file_50595);
    _0 = _conf_path_50600;
    _conf_path_50600 = _14canonical_path(_file_50595, 0LL, 2LL);
    DeRef(_0);

    /** pathopen.e:229		if find(conf_path, seen_conf) != 0 then*/
    _25986 = find_from(_conf_path_50600, _46seen_conf_50592, 1LL);
    if (_25986 == 0LL)
    goto L3; // [74] 85

    /** pathopen.e:230			return {}*/
    RefDS(_22024);
    DeRefDS(_file_50595);
    DeRefi(_in_50597);
    DeRefDS(_conf_path_50600);
    DeRef(_new_args_50601);
    DeRefi(_arg_50602);
    DeRefi(_parm_50603);
    DeRef(_section_50604);
    return _22024;
L3: 

    /** pathopen.e:232		seen_conf = append(seen_conf, conf_path)*/
    RefDS(_conf_path_50600);
    Append(&_46seen_conf_50592, _46seen_conf_50592, _conf_path_50600);

    /** pathopen.e:234		section = "all"*/
    RefDS(_25989);
    DeRef(_section_50604);
    _section_50604 = _25989;

    /** pathopen.e:235		fn = open( conf_path, "r" )*/
    _fn_50596 = EOpen(_conf_path_50600, _25990, 0LL);

    /** pathopen.e:236		if fn = -1 then return {} end if*/
    if (_fn_50596 != -1LL)
    goto L4; // [109] 118
    RefDS(_22024);
    DeRefDS(_file_50595);
    DeRefi(_in_50597);
    DeRefDS(_conf_path_50600);
    DeRef(_new_args_50601);
    DeRefi(_arg_50602);
    DeRefi(_parm_50603);
    DeRefDSi(_section_50604);
    return _22024;
L4: 

    /** pathopen.e:238		in = gets( fn )*/
    DeRefi(_in_50597);
    _in_50597 = EGets(_fn_50596);

    /** pathopen.e:239		while sequence( in ) do*/
L5: 
    _25994 = IS_SEQUENCE(_in_50597);
    if (_25994 == 0)
    {
        _25994 = NOVALUE;
        goto L6; // [131] 768
    }
    else{
        _25994 = NOVALUE;
    }

    /** pathopen.e:241			spos = 1*/
    _spos_50598 = 1LL;

    /** pathopen.e:242			while spos <= length(in) do*/
L7: 
    if (IS_SEQUENCE(_in_50597)){
            _25995 = SEQ_PTR(_in_50597)->length;
    }
    else {
        _25995 = 1;
    }
    if (_spos_50598 > _25995)
    goto L8; // [147] 182

    /** pathopen.e:243				if find( in[spos], "\n\r \t" ) = 0 then*/
    _2 = (object)SEQ_PTR(_in_50597);
    _25997 = (object)*(((s1_ptr)_2)->base + _spos_50598);
    _25999 = find_from(_25997, _25998, 1LL);
    _25997 = NOVALUE;
    if (_25999 != 0LL)
    goto L9; // [162] 171

    /** pathopen.e:244					exit*/
    goto L8; // [168] 182
L9: 

    /** pathopen.e:246				spos += 1*/
    _spos_50598 = _spos_50598 + 1;

    /** pathopen.e:247			end while*/
    goto L7; // [179] 144
L8: 

    /** pathopen.e:249			epos = length(in)*/
    if (IS_SEQUENCE(_in_50597)){
            _epos_50599 = SEQ_PTR(_in_50597)->length;
    }
    else {
        _epos_50599 = 1;
    }

    /** pathopen.e:250			while epos >= spos do*/
LA: 
    if (_epos_50599 < _spos_50598)
    goto LB; // [192] 227

    /** pathopen.e:251				if find( in[epos], "\n\r \t" ) = 0 then*/
    _2 = (object)SEQ_PTR(_in_50597);
    _26004 = (object)*(((s1_ptr)_2)->base + _epos_50599);
    _26005 = find_from(_26004, _25998, 1LL);
    _26004 = NOVALUE;
    if (_26005 != 0LL)
    goto LC; // [207] 216

    /** pathopen.e:252					exit*/
    goto LB; // [213] 227
LC: 

    /** pathopen.e:254				epos -= 1*/
    _epos_50599 = _epos_50599 - 1LL;

    /** pathopen.e:255			end while*/
    goto LA; // [224] 192
LB: 

    /** pathopen.e:257			in = in[spos .. epos]		*/
    rhs_slice_target = (object_ptr)&_in_50597;
    RHS_Slice(_in_50597, _spos_50598, _epos_50599);

    /** pathopen.e:260			arg = ""*/
    RefDS(_22024);
    DeRefi(_arg_50602);
    _arg_50602 = _22024;

    /** pathopen.e:261			parm = ""*/
    RefDS(_22024);
    DeRefi(_parm_50603);
    _parm_50603 = _22024;

    /** pathopen.e:269			if length(in) > 0 then*/
    if (IS_SEQUENCE(_in_50597)){
            _26009 = SEQ_PTR(_in_50597)->length;
    }
    else {
        _26009 = 1;
    }
    if (_26009 <= 0LL)
    goto LD; // [253] 477

    /** pathopen.e:270				if in[1] = '[' then*/
    _2 = (object)SEQ_PTR(_in_50597);
    _26011 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (_26011 != 91LL)
    goto LE; // [263] 354

    /** pathopen.e:272					section = in[2..$]*/
    if (IS_SEQUENCE(_in_50597)){
            _26014 = SEQ_PTR(_in_50597)->length;
    }
    else {
        _26014 = 1;
    }
    rhs_slice_target = (object_ptr)&_section_50604;
    RHS_Slice(_in_50597, 2LL, _26014);

    /** pathopen.e:273					if length(section) > 0 and section[$] = ']' then*/
    if (IS_SEQUENCE(_section_50604)){
            _26016 = SEQ_PTR(_section_50604)->length;
    }
    else {
        _26016 = 1;
    }
    _26017 = (_26016 > 0LL);
    _26016 = NOVALUE;
    if (_26017 == 0) {
        goto LF; // [286] 320
    }
    if (IS_SEQUENCE(_section_50604)){
            _26019 = SEQ_PTR(_section_50604)->length;
    }
    else {
        _26019 = 1;
    }
    _2 = (object)SEQ_PTR(_section_50604);
    _26020 = (object)*(((s1_ptr)_2)->base + _26019);
    _26022 = (_26020 == 93LL);
    _26020 = NOVALUE;
    if (_26022 == 0)
    {
        DeRef(_26022);
        _26022 = NOVALUE;
        goto LF; // [302] 320
    }
    else{
        DeRef(_26022);
        _26022 = NOVALUE;
    }

    /** pathopen.e:274						section = section[1..$-1]*/
    if (IS_SEQUENCE(_section_50604)){
            _26023 = SEQ_PTR(_section_50604)->length;
    }
    else {
        _26023 = 1;
    }
    _26024 = _26023 - 1LL;
    _26023 = NOVALUE;
    rhs_slice_target = (object_ptr)&_section_50604;
    RHS_Slice(_section_50604, 1LL, _26024);
LF: 

    /** pathopen.e:276					section = lower(trim(section))*/
    RefDS(_section_50604);
    RefDS(_3010);
    _26026 = _18trim(_section_50604, _3010, 0LL);
    _0 = _section_50604;
    _section_50604 = _18lower(_26026);
    DeRefDS(_0);
    _26026 = NOVALUE;

    /** pathopen.e:277					if length(section) = 0 then*/
    if (IS_SEQUENCE(_section_50604)){
            _26028 = SEQ_PTR(_section_50604)->length;
    }
    else {
        _26028 = 1;
    }
    if (_26028 != 0LL)
    goto L10; // [339] 476

    /** pathopen.e:278						section = "all"*/
    RefDS(_25989);
    DeRefDS(_section_50604);
    _section_50604 = _25989;
    goto L10; // [351] 476
LE: 

    /** pathopen.e:281				elsif length(in) > 2 then*/
    if (IS_SEQUENCE(_in_50597)){
            _26030 = SEQ_PTR(_in_50597)->length;
    }
    else {
        _26030 = 1;
    }
    if (_26030 <= 2LL)
    goto L11; // [359] 461

    /** pathopen.e:282					if in[1] = '-' then*/
    _2 = (object)SEQ_PTR(_in_50597);
    _26032 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (_26032 != 45LL)
    goto L12; // [369] 443

    /** pathopen.e:283						if in[2] != '-' then*/
    _2 = (object)SEQ_PTR(_in_50597);
    _26034 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (_26034 == 45LL)
    goto L10; // [379] 476

    /** pathopen.e:284							spos = find(' ', in)*/
    _spos_50598 = find_from(32LL, _in_50597, 1LL);

    /** pathopen.e:285							if spos = 0 then*/
    if (_spos_50598 != 0LL)
    goto L13; // [392] 413

    /** pathopen.e:286								arg = in*/
    Ref(_in_50597);
    DeRefi(_arg_50602);
    _arg_50602 = _in_50597;

    /** pathopen.e:287								parm = ""*/
    RefDS(_22024);
    DeRefi(_parm_50603);
    _parm_50603 = _22024;
    goto L10; // [410] 476
L13: 

    /** pathopen.e:289								arg = in[1..spos - 1]*/
    _26038 = _spos_50598 - 1LL;
    rhs_slice_target = (object_ptr)&_arg_50602;
    RHS_Slice(_in_50597, 1LL, _26038);

    /** pathopen.e:290								parm = in[spos + 1 .. $]*/
    _26040 = _spos_50598 + 1;
    if (_26040 > MAXINT){
        _26040 = NewDouble((eudouble)_26040);
    }
    if (IS_SEQUENCE(_in_50597)){
            _26041 = SEQ_PTR(_in_50597)->length;
    }
    else {
        _26041 = 1;
    }
    rhs_slice_target = (object_ptr)&_parm_50603;
    RHS_Slice(_in_50597, _26040, _26041);
    goto L10; // [440] 476
L12: 

    /** pathopen.e:294						arg = "-i"*/
    RefDS(_26043);
    DeRefi(_arg_50602);
    _arg_50602 = _26043;

    /** pathopen.e:295						parm = in*/
    Ref(_in_50597);
    DeRefi(_parm_50603);
    _parm_50603 = _in_50597;
    goto L10; // [458] 476
L11: 

    /** pathopen.e:298					arg = "-i"*/
    RefDS(_26043);
    DeRefi(_arg_50602);
    _arg_50602 = _26043;

    /** pathopen.e:299					parm = in*/
    Ref(_in_50597);
    DeRefi(_parm_50603);
    _parm_50603 = _in_50597;
L10: 
LD: 

    /** pathopen.e:303			if length(arg) > 0 then*/
    if (IS_SEQUENCE(_arg_50602)){
            _26044 = SEQ_PTR(_arg_50602)->length;
    }
    else {
        _26044 = 1;
    }
    if (_26044 <= 0LL)
    goto L14; // [482] 756

    /** pathopen.e:304				integer needed = 0*/
    _needed_50703 = 0LL;

    /** pathopen.e:305				switch section do*/
    _1 = find(_section_50604, _26046);
    switch ( _1 ){ 

        /** pathopen.e:306					case "all" then*/
        case 1:

        /** pathopen.e:307						needed = 1*/
        _needed_50703 = 1LL;
        goto L15; // [507] 691

        /** pathopen.e:309					case "windows" then*/
        case 2:

        /** pathopen.e:310						needed = TWINDOWS*/
        _needed_50703 = 0LL;
        goto L15; // [522] 691

        /** pathopen.e:312					case "unix" then*/
        case 3:

        /** pathopen.e:313						needed = TUNIX*/
        _needed_50703 = _44TUNIX_20374;
        goto L15; // [537] 691

        /** pathopen.e:315					case "translate" then*/
        case 4:

        /** pathopen.e:316						needed = TRANSLATE*/
        _needed_50703 = _12TRANSLATE_19834;
        goto L15; // [552] 691

        /** pathopen.e:318					case "translate:windows" then*/
        case 5:

        /** pathopen.e:319						needed = TRANSLATE and TWINDOWS*/
        _needed_50703 = (_12TRANSLATE_19834 != 0 && 0LL != 0);
        goto L15; // [570] 691

        /** pathopen.e:321					case "translate:unix" then*/
        case 6:

        /** pathopen.e:322						needed = TRANSLATE and TUNIX*/
        _needed_50703 = (_12TRANSLATE_19834 != 0 && _44TUNIX_20374 != 0);
        goto L15; // [588] 691

        /** pathopen.e:324					case "interpret" then*/
        case 7:

        /** pathopen.e:325						needed = INTERPRET*/
        _needed_50703 = _12INTERPRET_19831;
        goto L15; // [603] 691

        /** pathopen.e:327					case "interpret:windows" then*/
        case 8:

        /** pathopen.e:328						needed = INTERPRET and TWINDOWS*/
        _needed_50703 = (_12INTERPRET_19831 != 0 && 0LL != 0);
        goto L15; // [621] 691

        /** pathopen.e:330					case "interpret:unix" then*/
        case 9:

        /** pathopen.e:331						needed = INTERPRET and TUNIX*/
        _needed_50703 = (_12INTERPRET_19831 != 0 && _44TUNIX_20374 != 0);
        goto L15; // [639] 691

        /** pathopen.e:333					case "bind" then*/
        case 10:

        /** pathopen.e:334						needed = BIND*/
        _needed_50703 = _12BIND_19837;
        goto L15; // [654] 691

        /** pathopen.e:336					case "bind:windows" then*/
        case 11:

        /** pathopen.e:337						needed = BIND and TWINDOWS*/
        _needed_50703 = (_12BIND_19837 != 0 && 0LL != 0);
        goto L15; // [672] 691

        /** pathopen.e:339					case "bind:unix" then*/
        case 12:

        /** pathopen.e:340						needed = BIND and TUNIX*/
        _needed_50703 = (_12BIND_19837 != 0 && _44TUNIX_20374 != 0);
    ;}L15: 

    /** pathopen.e:344				if needed then*/
    if (_needed_50703 == 0)
    {
        goto L16; // [693] 755
    }
    else{
    }

    /** pathopen.e:345					if equal(arg, "-c") then*/
    if (_arg_50602 == _26065)
    _26066 = 1;
    else if (IS_ATOM_INT(_arg_50602) && IS_ATOM_INT(_26065))
    _26066 = 0;
    else
    _26066 = (compare(_arg_50602, _26065) == 0);
    if (_26066 == 0)
    {
        _26066 = NOVALUE;
        goto L17; // [702] 728
    }
    else{
        _26066 = NOVALUE;
    }

    /** pathopen.e:346						if length(parm) > 0 then*/
    if (IS_SEQUENCE(_parm_50603)){
            _26067 = SEQ_PTR(_parm_50603)->length;
    }
    else {
        _26067 = 1;
    }
    if (_26067 <= 0LL)
    goto L18; // [710] 754

    /** pathopen.e:347							new_args &= load_euphoria_config(parm)*/
    RefDS(_parm_50603);
    _26069 = _46load_euphoria_config(_parm_50603);
    if (IS_SEQUENCE(_new_args_50601) && IS_ATOM(_26069)) {
        Ref(_26069);
        Append(&_new_args_50601, _new_args_50601, _26069);
    }
    else if (IS_ATOM(_new_args_50601) && IS_SEQUENCE(_26069)) {
    }
    else {
        Concat((object_ptr)&_new_args_50601, _new_args_50601, _26069);
    }
    DeRef(_26069);
    _26069 = NOVALUE;
    goto L18; // [725] 754
L17: 

    /** pathopen.e:350						new_args = append(new_args, arg)*/
    RefDS(_arg_50602);
    Append(&_new_args_50601, _new_args_50601, _arg_50602);

    /** pathopen.e:351						if length(parm > 0) then*/
    _26072 = binary_op(GREATER, _parm_50603, 0LL);
    if (IS_SEQUENCE(_26072)){
            _26073 = SEQ_PTR(_26072)->length;
    }
    else {
        _26073 = 1;
    }
    DeRefDS(_26072);
    _26072 = NOVALUE;
    if (_26073 == 0)
    {
        _26073 = NOVALUE;
        goto L19; // [743] 753
    }
    else{
        _26073 = NOVALUE;
    }

    /** pathopen.e:352							new_args = append(new_args, parm)*/
    RefDS(_parm_50603);
    Append(&_new_args_50601, _new_args_50601, _parm_50603);
L19: 
L18: 
L16: 
L14: 

    /** pathopen.e:358			in = gets( fn )*/
    DeRefi(_in_50597);
    _in_50597 = EGets(_fn_50596);

    /** pathopen.e:359		end while*/
    goto L5; // [765] 128
L6: 

    /** pathopen.e:360		close(fn)*/
    EClose(_fn_50596);

    /** pathopen.e:362		return new_args*/
    DeRefDS(_file_50595);
    DeRefi(_in_50597);
    DeRef(_conf_path_50600);
    DeRefi(_arg_50602);
    DeRefi(_parm_50603);
    DeRef(_section_50604);
    DeRef(_26040);
    _26040 = NOVALUE;
    _26011 = NOVALUE;
    DeRef(_26017);
    _26017 = NOVALUE;
    DeRef(_26024);
    _26024 = NOVALUE;
    _26032 = NOVALUE;
    _26072 = NOVALUE;
    DeRef(_26038);
    _26038 = NOVALUE;
    _26034 = NOVALUE;
    return _new_args_50601;
    ;
}


object _46GetDefaultArgs(object _user_files_50770)
{
    object _env_50771 = NOVALUE;
    object _default_args_50772 = NOVALUE;
    object _conf_file_50773 = NOVALUE;
    object _cmd_options_50775 = NOVALUE;
    object _user_config_50781 = NOVALUE;
    object _26108 = NOVALUE;
    object _26107 = NOVALUE;
    object _26106 = NOVALUE;
    object _26098 = NOVALUE;
    object _26097 = NOVALUE;
    object _26095 = NOVALUE;
    object _26092 = NOVALUE;
    object _26091 = NOVALUE;
    object _26088 = NOVALUE;
    object _26087 = NOVALUE;
    object _26085 = NOVALUE;
    object _26083 = NOVALUE;
    object _26082 = NOVALUE;
    object _26078 = NOVALUE;
    object _26077 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:367		sequence default_args = {}*/
    RefDS(_22024);
    DeRef(_default_args_50772);
    _default_args_50772 = _22024;

    /** pathopen.e:368		sequence conf_file = "eu.cfg"*/
    RefDS(_25983);
    DeRefi(_conf_file_50773);
    _conf_file_50773 = _25983;

    /** pathopen.e:370		if loaded_config_inc_paths then return "" end if*/
    if (_46loaded_config_inc_paths_50443 == 0)
    {
        goto L1; // [21] 29
    }
    else{
    }
    RefDS(_22024);
    DeRefDS(_user_files_50770);
    DeRef(_env_50771);
    DeRefDS(_default_args_50772);
    DeRefDSi(_conf_file_50773);
    DeRef(_cmd_options_50775);
    return _22024;
L1: 

    /** pathopen.e:371		loaded_config_inc_paths = 1*/
    _46loaded_config_inc_paths_50443 = 1LL;

    /** pathopen.e:380		sequence cmd_options = get_options()*/
    _0 = _cmd_options_50775;
    _cmd_options_50775 = _47get_options();
    DeRef(_0);

    /** pathopen.e:382		default_args = {}*/
    RefDS(_22024);
    DeRef(_default_args_50772);
    _default_args_50772 = _22024;

    /** pathopen.e:385		for i = 1 to length( user_files ) do*/
    if (IS_SEQUENCE(_user_files_50770)){
            _26077 = SEQ_PTR(_user_files_50770)->length;
    }
    else {
        _26077 = 1;
    }
    {
        object _i_50779;
        _i_50779 = 1LL;
L2: 
        if (_i_50779 > _26077){
            goto L3; // [53] 92
        }

        /** pathopen.e:386			sequence user_config = load_euphoria_config( user_files[i] )*/
        _2 = (object)SEQ_PTR(_user_files_50770);
        _26078 = (object)*(((s1_ptr)_2)->base + _i_50779);
        Ref(_26078);
        _0 = _user_config_50781;
        _user_config_50781 = _46load_euphoria_config(_26078);
        DeRef(_0);
        _26078 = NOVALUE;

        /** pathopen.e:387			default_args = merge_parameters( user_config, default_args, cmd_options, 1 )*/
        RefDS(_user_config_50781);
        RefDS(_default_args_50772);
        RefDS(_cmd_options_50775);
        _0 = _default_args_50772;
        _default_args_50772 = _47merge_parameters(_user_config_50781, _default_args_50772, _cmd_options_50775, 1LL);
        DeRefDS(_0);
        DeRefDS(_user_config_50781);
        _user_config_50781 = NOVALUE;

        /** pathopen.e:388		end for*/
        _i_50779 = _i_50779 + 1LL;
        goto L2; // [87] 60
L3: 
        ;
    }

    /** pathopen.e:391		default_args = merge_parameters( load_euphoria_config("./" & conf_file), default_args, cmd_options, 1 )*/
    Concat((object_ptr)&_26082, _26081, _conf_file_50773);
    _26083 = _46load_euphoria_config(_26082);
    _26082 = NOVALUE;
    RefDS(_default_args_50772);
    RefDS(_cmd_options_50775);
    _0 = _default_args_50772;
    _default_args_50772 = _47merge_parameters(_26083, _default_args_50772, _cmd_options_50775, 1LL);
    DeRefDS(_0);
    _26083 = NOVALUE;

    /** pathopen.e:394		env = strip_file_from_path( exe_path() )*/
    _26085 = _46exe_path();
    _0 = _env_50771;
    _env_50771 = _46strip_file_from_path(_26085);
    DeRef(_0);
    _26085 = NOVALUE;

    /** pathopen.e:395		default_args = merge_parameters( load_euphoria_config( env & conf_file ), default_args, cmd_options, 1 )*/
    if (IS_SEQUENCE(_env_50771) && IS_ATOM(_conf_file_50773)) {
    }
    else if (IS_ATOM(_env_50771) && IS_SEQUENCE(_conf_file_50773)) {
        Ref(_env_50771);
        Prepend(&_26087, _conf_file_50773, _env_50771);
    }
    else {
        Concat((object_ptr)&_26087, _env_50771, _conf_file_50773);
    }
    _26088 = _46load_euphoria_config(_26087);
    _26087 = NOVALUE;
    RefDS(_default_args_50772);
    RefDS(_cmd_options_50775);
    _0 = _default_args_50772;
    _default_args_50772 = _47merge_parameters(_26088, _default_args_50772, _cmd_options_50775, 1LL);
    DeRefDS(_0);
    _26088 = NOVALUE;

    /** pathopen.e:398		ifdef UNIX then*/

    /** pathopen.e:399			default_args = merge_parameters( load_euphoria_config( "/etc/euphoria/" & conf_file ), default_args, cmd_options, 1 )*/
    Concat((object_ptr)&_26091, _26090, _conf_file_50773);
    _26092 = _46load_euphoria_config(_26091);
    _26091 = NOVALUE;
    RefDS(_default_args_50772);
    RefDS(_cmd_options_50775);
    _0 = _default_args_50772;
    _default_args_50772 = _47merge_parameters(_26092, _default_args_50772, _cmd_options_50775, 1LL);
    DeRefDS(_0);
    _26092 = NOVALUE;

    /** pathopen.e:401			env = getenv( "HOME" )*/
    DeRef(_env_50771);
    _env_50771 = EGetEnv(_25954);

    /** pathopen.e:402			if sequence(env) then*/
    _26095 = IS_SEQUENCE(_env_50771);
    if (_26095 == 0)
    {
        _26095 = NOVALUE;
        goto L4; // [170] 195
    }
    else{
        _26095 = NOVALUE;
    }

    /** pathopen.e:403				default_args = merge_parameters( load_euphoria_config( env & "/." & conf_file ), default_args, cmd_options, 1 )*/
    {
        object concat_list[3];

        concat_list[0] = _conf_file_50773;
        concat_list[1] = _26096;
        concat_list[2] = _env_50771;
        Concat_N((object_ptr)&_26097, concat_list, 3);
    }
    _26098 = _46load_euphoria_config(_26097);
    _26097 = NOVALUE;
    RefDS(_default_args_50772);
    RefDS(_cmd_options_50775);
    _0 = _default_args_50772;
    _default_args_50772 = _47merge_parameters(_26098, _default_args_50772, _cmd_options_50775, 1LL);
    DeRefDS(_0);
    _26098 = NOVALUE;
L4: 

    /** pathopen.e:427		env = get_eudir()*/
    _0 = _env_50771;
    _env_50771 = _13get_eudir();
    DeRef(_0);

    /** pathopen.e:428		if sequence(env) then*/
    _26106 = IS_SEQUENCE(_env_50771);
    if (_26106 == 0)
    {
        _26106 = NOVALUE;
        goto L5; // [205] 230
    }
    else{
        _26106 = NOVALUE;
    }

    /** pathopen.e:429			default_args = merge_parameters( load_euphoria_config(env & "/" & conf_file), default_args, cmd_options, 1 )*/
    {
        object concat_list[3];

        concat_list[0] = _conf_file_50773;
        concat_list[1] = _23629;
        concat_list[2] = _env_50771;
        Concat_N((object_ptr)&_26107, concat_list, 3);
    }
    _26108 = _46load_euphoria_config(_26107);
    _26107 = NOVALUE;
    RefDS(_default_args_50772);
    RefDS(_cmd_options_50775);
    _0 = _default_args_50772;
    _default_args_50772 = _47merge_parameters(_26108, _default_args_50772, _cmd_options_50775, 1LL);
    DeRefDS(_0);
    _26108 = NOVALUE;
L5: 

    /** pathopen.e:432		return default_args*/
    DeRefDS(_user_files_50770);
    DeRef(_env_50771);
    DeRefi(_conf_file_50773);
    DeRef(_cmd_options_50775);
    return _default_args_50772;
    ;
}


object _46ConfPath(object _file_name_50825)
{
    object _file_path_50826 = NOVALUE;
    object _try_50827 = NOVALUE;
    object _26115 = NOVALUE;
    object _26111 = NOVALUE;
    object _26110 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:440		for i = 1 to length(config_inc_paths) do*/
    if (IS_SEQUENCE(_46config_inc_paths_50442)){
            _26110 = SEQ_PTR(_46config_inc_paths_50442)->length;
    }
    else {
        _26110 = 1;
    }
    {
        object _i_50829;
        _i_50829 = 1LL;
L1: 
        if (_i_50829 > _26110){
            goto L2; // [10] 60
        }

        /** pathopen.e:441			file_path = config_inc_paths[i] & file_name*/
        _2 = (object)SEQ_PTR(_46config_inc_paths_50442);
        _26111 = (object)*(((s1_ptr)_2)->base + _i_50829);
        Concat((object_ptr)&_file_path_50826, _26111, _file_name_50825);
        _26111 = NOVALUE;
        _26111 = NOVALUE;

        /** pathopen.e:442			try = open( file_path, "r" )*/
        _try_50827 = EOpen(_file_path_50826, _25990, 0LL);

        /** pathopen.e:443			if try != -1 then*/
        if (_try_50827 == -1LL)
        goto L3; // [38] 53

        /** pathopen.e:444				return {file_path, try}*/
        RefDS(_file_path_50826);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_50826;
        ((intptr_t *)_2)[2] = _try_50827;
        _26115 = MAKE_SEQ(_1);
        DeRefDS(_file_name_50825);
        DeRefDS(_file_path_50826);
        return _26115;
L3: 

        /** pathopen.e:446		end for*/
        _i_50829 = _i_50829 + 1LL;
        goto L1; // [55] 17
L2: 
        ;
    }

    /** pathopen.e:447		return -1*/
    DeRefDS(_file_name_50825);
    DeRef(_file_path_50826);
    DeRef(_26115);
    _26115 = NOVALUE;
    return -1LL;
    ;
}


object _46ScanPath(object _file_name_50839, object _env_50840, object _flag_50841)
{
    object _inc_path_50842 = NOVALUE;
    object _full_path_50843 = NOVALUE;
    object _file_path_50844 = NOVALUE;
    object _strings_50845 = NOVALUE;
    object _end_path_50846 = NOVALUE;
    object _start_path_50847 = NOVALUE;
    object _try_50848 = NOVALUE;
    object _use_cache_50849 = NOVALUE;
    object _pos_50850 = NOVALUE;
    object _26163 = NOVALUE;
    object _26162 = NOVALUE;
    object _26161 = NOVALUE;
    object _26160 = NOVALUE;
    object _26159 = NOVALUE;
    object _26158 = NOVALUE;
    object _26157 = NOVALUE;
    object _26156 = NOVALUE;
    object _26152 = NOVALUE;
    object _26151 = NOVALUE;
    object _26150 = NOVALUE;
    object _26149 = NOVALUE;
    object _26148 = NOVALUE;
    object _26147 = NOVALUE;
    object _26145 = NOVALUE;
    object _26143 = NOVALUE;
    object _26142 = NOVALUE;
    object _26140 = NOVALUE;
    object _26139 = NOVALUE;
    object _26138 = NOVALUE;
    object _26135 = NOVALUE;
    object _26134 = NOVALUE;
    object _26132 = NOVALUE;
    object _26131 = NOVALUE;
    object _26130 = NOVALUE;
    object _26125 = NOVALUE;
    object _26117 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:459		inc_path = getenv(env)*/
    DeRefi(_inc_path_50842);
    _inc_path_50842 = EGetEnv(_env_50840);

    /** pathopen.e:460		if compare(inc_path,{})!=1 then -- nothing to do, just fail*/
    if (IS_ATOM_INT(_inc_path_50842) && IS_ATOM_INT(_22024)){
        _26117 = (_inc_path_50842 < _22024) ? -1 : (_inc_path_50842 > _22024);
    }
    else{
        _26117 = compare(_inc_path_50842, _22024);
    }
    if (_26117 == 1LL)
    goto L1; // [18] 29

    /** pathopen.e:461			return -1*/
    DeRefDS(_file_name_50839);
    DeRefDSi(_env_50840);
    DeRefi(_inc_path_50842);
    DeRef(_full_path_50843);
    DeRef(_file_path_50844);
    DeRef(_strings_50845);
    return -1LL;
L1: 

    /** pathopen.e:464		num_var = find(env,cache_vars)*/
    _46num_var_50433 = find_from(_env_50840, _46cache_vars_50434, 1LL);

    /** pathopen.e:465		use_cache = check_cache(env,inc_path)*/
    RefDS(_env_50840);
    Ref(_inc_path_50842);
    _use_cache_50849 = _46check_cache(_env_50840, _inc_path_50842);
    if (!IS_ATOM_INT(_use_cache_50849)) {
        _1 = (object)(DBL_PTR(_use_cache_50849)->dbl);
        DeRefDS(_use_cache_50849);
        _use_cache_50849 = _1;
    }

    /** pathopen.e:466		inc_path = append(inc_path, PATH_SEPARATOR)*/
    Append(&_inc_path_50842, _inc_path_50842, 58LL);

    /** pathopen.e:468		file_name = SLASH & file_name*/
    Prepend(&_file_name_50839, _file_name_50839, 47LL);

    /** pathopen.e:469		if flag then*/
    if (_flag_50841 == 0)
    {
        goto L2; // [65] 77
    }
    else{
    }

    /** pathopen.e:470			file_name = include_subfolder & file_name*/
    Concat((object_ptr)&_file_name_50839, _46include_subfolder_50429, _file_name_50839);
L2: 

    /** pathopen.e:472		strings = cache_substrings[num_var]*/
    DeRef(_strings_50845);
    _2 = (object)SEQ_PTR(_46cache_substrings_50436);
    _strings_50845 = (object)*(((s1_ptr)_2)->base + _46num_var_50433);
    RefDS(_strings_50845);

    /** pathopen.e:474		if use_cache then*/
    if (_use_cache_50849 == 0)
    {
        goto L3; // [91] 194
    }
    else{
    }

    /** pathopen.e:475			for i=1 to length(strings) do*/
    if (IS_SEQUENCE(_strings_50845)){
            _26125 = SEQ_PTR(_strings_50845)->length;
    }
    else {
        _26125 = 1;
    }
    {
        object _i_50866;
        _i_50866 = 1LL;
L4: 
        if (_i_50866 > _26125){
            goto L5; // [99] 154
        }

        /** pathopen.e:476				full_path = strings[i]*/
        DeRef(_full_path_50843);
        _2 = (object)SEQ_PTR(_strings_50845);
        _full_path_50843 = (object)*(((s1_ptr)_2)->base + _i_50866);
        Ref(_full_path_50843);

        /** pathopen.e:477				file_path = full_path & file_name*/
        Concat((object_ptr)&_file_path_50844, _full_path_50843, _file_name_50839);

        /** pathopen.e:478				try = open_locked(file_path)    */
        RefDS(_file_path_50844);
        _try_50848 = _13open_locked(_file_path_50844);
        if (!IS_ATOM_INT(_try_50848)) {
            _1 = (object)(DBL_PTR(_try_50848)->dbl);
            DeRefDS(_try_50848);
            _try_50848 = _1;
        }

        /** pathopen.e:479				if try != -1 then*/
        if (_try_50848 == -1LL)
        goto L6; // [130] 145

        /** pathopen.e:480					return {file_path,try}*/
        RefDS(_file_path_50844);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_50844;
        ((intptr_t *)_2)[2] = _try_50848;
        _26130 = MAKE_SEQ(_1);
        DeRefDS(_file_name_50839);
        DeRefDSi(_env_50840);
        DeRefi(_inc_path_50842);
        DeRefDS(_full_path_50843);
        DeRefDS(_file_path_50844);
        DeRefDS(_strings_50845);
        return _26130;
L6: 

        /** pathopen.e:482				ifdef WINDOWS then */

        /** pathopen.e:496			end for*/
        _i_50866 = _i_50866 + 1LL;
        goto L4; // [149] 106
L5: 
        ;
    }

    /** pathopen.e:497			if cache_complete[num_var] then -- nothing to scan*/
    _2 = (object)SEQ_PTR(_46cache_complete_50440);
    _26131 = (object)*(((s1_ptr)_2)->base + _46num_var_50433);
    if (_26131 == 0)
    {
        _26131 = NOVALUE;
        goto L7; // [164] 176
    }
    else{
        _26131 = NOVALUE;
    }

    /** pathopen.e:498				return -1*/
    DeRefDS(_file_name_50839);
    DeRefDSi(_env_50840);
    DeRefi(_inc_path_50842);
    DeRef(_full_path_50843);
    DeRef(_file_path_50844);
    DeRef(_strings_50845);
    DeRef(_26130);
    _26130 = NOVALUE;
    return -1LL;
    goto L8; // [173] 200
L7: 

    /** pathopen.e:500				pos = cache_delims[num_var]+1 -- scan remainder, starting from as far sa possible*/
    _2 = (object)SEQ_PTR(_46cache_delims_50441);
    _26132 = (object)*(((s1_ptr)_2)->base + _46num_var_50433);
    _pos_50850 = _26132 + 1;
    _26132 = NOVALUE;
    goto L8; // [191] 200
L3: 

    /** pathopen.e:503			pos = 1*/
    _pos_50850 = 1LL;
L8: 

    /** pathopen.e:506		start_path = 0*/
    _start_path_50847 = 0LL;

    /** pathopen.e:507		for p = pos to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_50842)){
            _26134 = SEQ_PTR(_inc_path_50842)->length;
    }
    else {
        _26134 = 1;
    }
    {
        object _p_50882;
        _p_50882 = _pos_50850;
L9: 
        if (_p_50882 > _26134){
            goto LA; // [212] 460
        }

        /** pathopen.e:508			if inc_path[p] = PATH_SEPARATOR then*/
        _2 = (object)SEQ_PTR(_inc_path_50842);
        _26135 = (object)*(((s1_ptr)_2)->base + _p_50882);
        if (_26135 != 58LL)
        goto LB; // [227] 409

        /** pathopen.e:510				cache_delims[num_var] = p*/
        _2 = (object)SEQ_PTR(_46cache_delims_50441);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_delims_50441 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50433);
        *(intptr_t *)_2 = _p_50882;

        /** pathopen.e:512				end_path = p-1*/
        _end_path_50846 = _p_50882 - 1LL;

        /** pathopen.e:513				while end_path >= start_path and find(inc_path[end_path], " \t" & SLASH_CHARS) do*/
LC: 
        _26138 = (_end_path_50846 >= _start_path_50847);
        if (_26138 == 0) {
            goto LD; // [256] 290
        }
        _2 = (object)SEQ_PTR(_inc_path_50842);
        _26140 = (object)*(((s1_ptr)_2)->base + _end_path_50846);
        Concat((object_ptr)&_26142, _26141, _44SLASH_CHARS_20390);
        _26143 = find_from(_26140, _26142, 1LL);
        _26140 = NOVALUE;
        DeRefDS(_26142);
        _26142 = NOVALUE;
        if (_26143 == 0)
        {
            _26143 = NOVALUE;
            goto LD; // [276] 290
        }
        else{
            _26143 = NOVALUE;
        }

        /** pathopen.e:514					end_path-=1*/
        _end_path_50846 = _end_path_50846 - 1LL;

        /** pathopen.e:515				end while*/
        goto LC; // [287] 252
LD: 

        /** pathopen.e:517				if start_path and end_path then*/
        if (_start_path_50847 == 0) {
            goto LE; // [292] 453
        }
        if (_end_path_50846 == 0)
        {
            goto LE; // [297] 453
        }
        else{
        }

        /** pathopen.e:518					full_path = inc_path[start_path..end_path]*/
        rhs_slice_target = (object_ptr)&_full_path_50843;
        RHS_Slice(_inc_path_50842, _start_path_50847, _end_path_50846);

        /** pathopen.e:519					cache_substrings[num_var] = append(cache_substrings[num_var],full_path)*/
        _2 = (object)SEQ_PTR(_46cache_substrings_50436);
        _26147 = (object)*(((s1_ptr)_2)->base + _46num_var_50433);
        RefDS(_full_path_50843);
        Append(&_26148, _26147, _full_path_50843);
        _26147 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_substrings_50436);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_substrings_50436 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50433);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26148;
        if( _1 != _26148 ){
            DeRefDS(_1);
        }
        _26148 = NOVALUE;

        /** pathopen.e:520					cache_starts[num_var] &= start_path*/
        _2 = (object)SEQ_PTR(_46cache_starts_50437);
        _26149 = (object)*(((s1_ptr)_2)->base + _46num_var_50433);
        if (IS_SEQUENCE(_26149) && IS_ATOM(_start_path_50847)) {
            Append(&_26150, _26149, _start_path_50847);
        }
        else if (IS_ATOM(_26149) && IS_SEQUENCE(_start_path_50847)) {
        }
        else {
            Concat((object_ptr)&_26150, _26149, _start_path_50847);
            _26149 = NOVALUE;
        }
        _26149 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_starts_50437);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_starts_50437 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50433);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26150;
        if( _1 != _26150 ){
            DeRef(_1);
        }
        _26150 = NOVALUE;

        /** pathopen.e:521					cache_ends[num_var] &= end_path*/
        _2 = (object)SEQ_PTR(_46cache_ends_50438);
        _26151 = (object)*(((s1_ptr)_2)->base + _46num_var_50433);
        if (IS_SEQUENCE(_26151) && IS_ATOM(_end_path_50846)) {
            Append(&_26152, _26151, _end_path_50846);
        }
        else if (IS_ATOM(_26151) && IS_SEQUENCE(_end_path_50846)) {
        }
        else {
            Concat((object_ptr)&_26152, _26151, _end_path_50846);
            _26151 = NOVALUE;
        }
        _26151 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_ends_50438);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_ends_50438 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50433);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26152;
        if( _1 != _26152 ){
            DeRef(_1);
        }
        _26152 = NOVALUE;

        /** pathopen.e:522					file_path = full_path & file_name  */
        Concat((object_ptr)&_file_path_50844, _full_path_50843, _file_name_50839);

        /** pathopen.e:523					try = open_locked(file_path)*/
        RefDS(_file_path_50844);
        _try_50848 = _13open_locked(_file_path_50844);
        if (!IS_ATOM_INT(_try_50848)) {
            _1 = (object)(DBL_PTR(_try_50848)->dbl);
            DeRefDS(_try_50848);
            _try_50848 = _1;
        }

        /** pathopen.e:524					if try != -1 then -- valid path, no point trying to convert*/
        if (_try_50848 == -1LL)
        goto LF; // [381] 398

        /** pathopen.e:525						ifdef WINDOWS then*/

        /** pathopen.e:528						return {file_path,try}*/
        RefDS(_file_path_50844);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_50844;
        ((intptr_t *)_2)[2] = _try_50848;
        _26156 = MAKE_SEQ(_1);
        DeRefDS(_file_name_50839);
        DeRefDSi(_env_50840);
        DeRefi(_inc_path_50842);
        DeRefDSi(_full_path_50843);
        DeRefDS(_file_path_50844);
        DeRef(_strings_50845);
        _26135 = NOVALUE;
        DeRef(_26130);
        _26130 = NOVALUE;
        DeRef(_26138);
        _26138 = NOVALUE;
        return _26156;
LF: 

        /** pathopen.e:530					ifdef WINDOWS then*/

        /** pathopen.e:547					start_path = 0*/
        _start_path_50847 = 0LL;
        goto LE; // [406] 453
LB: 

        /** pathopen.e:549			elsif not start_path and (inc_path[p] != ' ' and inc_path[p] != '\t') then*/
        _26157 = (_start_path_50847 == 0);
        if (_26157 == 0) {
            goto L10; // [414] 452
        }
        _2 = (object)SEQ_PTR(_inc_path_50842);
        _26159 = (object)*(((s1_ptr)_2)->base + _p_50882);
        _26160 = (_26159 != 32LL);
        _26159 = NOVALUE;
        if (_26160 == 0) {
            DeRef(_26161);
            _26161 = 0;
            goto L11; // [426] 442
        }
        _2 = (object)SEQ_PTR(_inc_path_50842);
        _26162 = (object)*(((s1_ptr)_2)->base + _p_50882);
        _26163 = (_26162 != 9LL);
        _26162 = NOVALUE;
        _26161 = (_26163 != 0);
L11: 
        if (_26161 == 0)
        {
            _26161 = NOVALUE;
            goto L10; // [443] 452
        }
        else{
            _26161 = NOVALUE;
        }

        /** pathopen.e:550				start_path = p*/
        _start_path_50847 = _p_50882;
L10: 
LE: 

        /** pathopen.e:552		end for*/
        _p_50882 = _p_50882 + 1LL;
        goto L9; // [455] 219
LA: 
        ;
    }

    /** pathopen.e:554		cache_complete[num_var] = 1*/
    _2 = (object)SEQ_PTR(_46cache_complete_50440);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _46cache_complete_50440 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _46num_var_50433);
    *(intptr_t *)_2 = 1LL;

    /** pathopen.e:555		return -1*/
    DeRefDS(_file_name_50839);
    DeRefDSi(_env_50840);
    DeRefi(_inc_path_50842);
    DeRef(_full_path_50843);
    DeRef(_file_path_50844);
    DeRef(_strings_50845);
    DeRef(_26157);
    _26157 = NOVALUE;
    _26135 = NOVALUE;
    DeRef(_26163);
    _26163 = NOVALUE;
    DeRef(_26160);
    _26160 = NOVALUE;
    DeRef(_26156);
    _26156 = NOVALUE;
    DeRef(_26130);
    _26130 = NOVALUE;
    DeRef(_26138);
    _26138 = NOVALUE;
    return -1LL;
    ;
}


object _46Include_paths(object _add_converted_50924)
{
    object _status_50925 = NOVALUE;
    object _pos_50926 = NOVALUE;
    object _inc_path_50927 = NOVALUE;
    object _full_path_50928 = NOVALUE;
    object _start_path_50929 = NOVALUE;
    object _end_path_50930 = NOVALUE;
    object _eudir_path_50946 = NOVALUE;
    object _26209 = NOVALUE;
    object _26208 = NOVALUE;
    object _26207 = NOVALUE;
    object _26206 = NOVALUE;
    object _26205 = NOVALUE;
    object _26204 = NOVALUE;
    object _26203 = NOVALUE;
    object _26202 = NOVALUE;
    object _26201 = NOVALUE;
    object _26200 = NOVALUE;
    object _26199 = NOVALUE;
    object _26198 = NOVALUE;
    object _26197 = NOVALUE;
    object _26196 = NOVALUE;
    object _26194 = NOVALUE;
    object _26192 = NOVALUE;
    object _26191 = NOVALUE;
    object _26190 = NOVALUE;
    object _26189 = NOVALUE;
    object _26188 = NOVALUE;
    object _26185 = NOVALUE;
    object _26184 = NOVALUE;
    object _26182 = NOVALUE;
    object _26180 = NOVALUE;
    object _26178 = NOVALUE;
    object _26177 = NOVALUE;
    object _26175 = NOVALUE;
    object _26172 = NOVALUE;
    object _26170 = NOVALUE;
    object _26165 = NOVALUE;
    object _26164 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_add_converted_50924)) {
        _1 = (object)(DBL_PTR(_add_converted_50924)->dbl);
        DeRefDS(_add_converted_50924);
        _add_converted_50924 = _1;
    }

    /** pathopen.e:566		if length(include_Paths) then*/
    if (IS_SEQUENCE(_46include_Paths_50921)){
            _26164 = SEQ_PTR(_46include_Paths_50921)->length;
    }
    else {
        _26164 = 1;
    }
    if (_26164 == 0)
    {
        _26164 = NOVALUE;
        goto L1; // [10] 22
    }
    else{
        _26164 = NOVALUE;
    }

    /** pathopen.e:567			return include_Paths*/
    RefDS(_46include_Paths_50921);
    DeRefi(_inc_path_50927);
    DeRefi(_full_path_50928);
    DeRef(_eudir_path_50946);
    return _46include_Paths_50921;
L1: 

    /** pathopen.e:570		include_Paths = append(config_inc_paths, current_dir())*/
    _26165 = _14current_dir();
    Ref(_26165);
    Append(&_46include_Paths_50921, _46config_inc_paths_50442, _26165);
    DeRef(_26165);
    _26165 = NOVALUE;

    /** pathopen.e:571		num_var = find("EUINC", cache_vars)*/
    _46num_var_50433 = find_from(_26167, _46cache_vars_50434, 1LL);

    /** pathopen.e:572		inc_path = getenv("EUINC")*/
    DeRefi(_inc_path_50927);
    _inc_path_50927 = EGetEnv(_26167);

    /** pathopen.e:573		if atom(inc_path) then*/
    _26170 = IS_ATOM(_inc_path_50927);
    if (_26170 == 0)
    {
        _26170 = NOVALUE;
        goto L2; // [52] 61
    }
    else{
        _26170 = NOVALUE;
    }

    /** pathopen.e:574			inc_path = ""*/
    RefDS(_22024);
    DeRefi(_inc_path_50927);
    _inc_path_50927 = _22024;
L2: 

    /** pathopen.e:576		status = check_cache("EUINC", inc_path)*/
    RefDS(_26167);
    Ref(_inc_path_50927);
    _status_50925 = _46check_cache(_26167, _inc_path_50927);
    if (!IS_ATOM_INT(_status_50925)) {
        _1 = (object)(DBL_PTR(_status_50925)->dbl);
        DeRefDS(_status_50925);
        _status_50925 = _1;
    }

    /** pathopen.e:577		if length(inc_path) then*/
    if (IS_SEQUENCE(_inc_path_50927)){
            _26172 = SEQ_PTR(_inc_path_50927)->length;
    }
    else {
        _26172 = 1;
    }
    if (_26172 == 0)
    {
        _26172 = NOVALUE;
        goto L3; // [75] 87
    }
    else{
        _26172 = NOVALUE;
    }

    /** pathopen.e:578			inc_path = append(inc_path, PATH_SEPARATOR)*/
    Append(&_inc_path_50927, _inc_path_50927, 58LL);
L3: 

    /** pathopen.e:580		object eudir_path = get_eudir()*/
    _0 = _eudir_path_50946;
    _eudir_path_50946 = _13get_eudir();
    DeRef(_0);

    /** pathopen.e:581		if sequence(eudir_path) then*/
    _26175 = IS_SEQUENCE(_eudir_path_50946);
    if (_26175 == 0)
    {
        _26175 = NOVALUE;
        goto L4; // [97] 117
    }
    else{
        _26175 = NOVALUE;
    }

    /** pathopen.e:582			include_Paths = append(include_Paths, sprintf("%s/include", { eudir_path }))*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_eudir_path_50946);
    ((intptr_t*)_2)[1] = _eudir_path_50946;
    _26177 = MAKE_SEQ(_1);
    _26178 = EPrintf(-9999999, _26176, _26177);
    DeRefDS(_26177);
    _26177 = NOVALUE;
    RefDS(_26178);
    Append(&_46include_Paths_50921, _46include_Paths_50921, _26178);
    DeRefDS(_26178);
    _26178 = NOVALUE;
L4: 

    /** pathopen.e:585		if status then*/
    if (_status_50925 == 0)
    {
        goto L5; // [119] 161
    }
    else{
    }

    /** pathopen.e:587			if cache_complete[num_var] then*/
    _2 = (object)SEQ_PTR(_46cache_complete_50440);
    _26180 = (object)*(((s1_ptr)_2)->base + _46num_var_50433);
    if (_26180 == 0)
    {
        _26180 = NOVALUE;
        goto L6; // [132] 144
    }
    else{
        _26180 = NOVALUE;
    }

    /** pathopen.e:588				goto "cache done"*/
    goto G7;
L6: 

    /** pathopen.e:590			pos = cache_delims[num_var]+1*/
    _2 = (object)SEQ_PTR(_46cache_delims_50441);
    _26182 = (object)*(((s1_ptr)_2)->base + _46num_var_50433);
    _pos_50926 = _26182 + 1;
    _26182 = NOVALUE;
    goto L8; // [158] 167
L5: 

    /** pathopen.e:592	        pos = 1*/
    _pos_50926 = 1LL;
L8: 

    /** pathopen.e:594		start_path = 0*/
    _start_path_50929 = 0LL;

    /** pathopen.e:595		for p = pos to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_50927)){
            _26184 = SEQ_PTR(_inc_path_50927)->length;
    }
    else {
        _26184 = 1;
    }
    {
        object _p_50963;
        _p_50963 = _pos_50926;
L9: 
        if (_p_50963 > _26184){
            goto LA; // [179] 394
        }

        /** pathopen.e:596			if inc_path[p] = PATH_SEPARATOR then*/
        _2 = (object)SEQ_PTR(_inc_path_50927);
        _26185 = (object)*(((s1_ptr)_2)->base + _p_50963);
        if (_26185 != 58LL)
        goto LB; // [194] 343

        /** pathopen.e:598				cache_delims[num_var] = p*/
        _2 = (object)SEQ_PTR(_46cache_delims_50441);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_delims_50441 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50433);
        *(intptr_t *)_2 = _p_50963;

        /** pathopen.e:600				end_path = p-1*/
        _end_path_50930 = _p_50963 - 1LL;

        /** pathopen.e:601				while end_path >= start_path and find(inc_path[end_path]," \t" & SLASH_CHARS) do*/
LC: 
        _26188 = (_end_path_50930 >= _start_path_50929);
        if (_26188 == 0) {
            goto LD; // [223] 257
        }
        _2 = (object)SEQ_PTR(_inc_path_50927);
        _26190 = (object)*(((s1_ptr)_2)->base + _end_path_50930);
        Concat((object_ptr)&_26191, _26141, _44SLASH_CHARS_20390);
        _26192 = find_from(_26190, _26191, 1LL);
        _26190 = NOVALUE;
        DeRefDS(_26191);
        _26191 = NOVALUE;
        if (_26192 == 0)
        {
            _26192 = NOVALUE;
            goto LD; // [243] 257
        }
        else{
            _26192 = NOVALUE;
        }

        /** pathopen.e:602					end_path -= 1*/
        _end_path_50930 = _end_path_50930 - 1LL;

        /** pathopen.e:603				end while*/
        goto LC; // [254] 219
LD: 

        /** pathopen.e:605				if start_path and end_path then*/
        if (_start_path_50929 == 0) {
            goto LE; // [259] 387
        }
        if (_end_path_50930 == 0)
        {
            goto LE; // [264] 387
        }
        else{
        }

        /** pathopen.e:606					full_path = inc_path[start_path..end_path]*/
        rhs_slice_target = (object_ptr)&_full_path_50928;
        RHS_Slice(_inc_path_50927, _start_path_50929, _end_path_50930);

        /** pathopen.e:607					cache_substrings[num_var] = append(cache_substrings[num_var],full_path)*/
        _2 = (object)SEQ_PTR(_46cache_substrings_50436);
        _26196 = (object)*(((s1_ptr)_2)->base + _46num_var_50433);
        RefDS(_full_path_50928);
        Append(&_26197, _26196, _full_path_50928);
        _26196 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_substrings_50436);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_substrings_50436 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50433);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26197;
        if( _1 != _26197 ){
            DeRefDS(_1);
        }
        _26197 = NOVALUE;

        /** pathopen.e:608					cache_starts[num_var] &= start_path*/
        _2 = (object)SEQ_PTR(_46cache_starts_50437);
        _26198 = (object)*(((s1_ptr)_2)->base + _46num_var_50433);
        if (IS_SEQUENCE(_26198) && IS_ATOM(_start_path_50929)) {
            Append(&_26199, _26198, _start_path_50929);
        }
        else if (IS_ATOM(_26198) && IS_SEQUENCE(_start_path_50929)) {
        }
        else {
            Concat((object_ptr)&_26199, _26198, _start_path_50929);
            _26198 = NOVALUE;
        }
        _26198 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_starts_50437);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_starts_50437 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50433);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26199;
        if( _1 != _26199 ){
            DeRef(_1);
        }
        _26199 = NOVALUE;

        /** pathopen.e:609					cache_ends[num_var] &= end_path*/
        _2 = (object)SEQ_PTR(_46cache_ends_50438);
        _26200 = (object)*(((s1_ptr)_2)->base + _46num_var_50433);
        if (IS_SEQUENCE(_26200) && IS_ATOM(_end_path_50930)) {
            Append(&_26201, _26200, _end_path_50930);
        }
        else if (IS_ATOM(_26200) && IS_SEQUENCE(_end_path_50930)) {
        }
        else {
            Concat((object_ptr)&_26201, _26200, _end_path_50930);
            _26200 = NOVALUE;
        }
        _26200 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_ends_50438);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_ends_50438 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50433);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26201;
        if( _1 != _26201 ){
            DeRef(_1);
        }
        _26201 = NOVALUE;

        /** pathopen.e:610					ifdef WINDOWS then*/

        /** pathopen.e:620					start_path = 0*/
        _start_path_50929 = 0LL;
        goto LE; // [340] 387
LB: 

        /** pathopen.e:622			elsif not start_path and (inc_path[p] != ' ' and inc_path[p] != '\t') then*/
        _26202 = (_start_path_50929 == 0);
        if (_26202 == 0) {
            goto LF; // [348] 386
        }
        _2 = (object)SEQ_PTR(_inc_path_50927);
        _26204 = (object)*(((s1_ptr)_2)->base + _p_50963);
        _26205 = (_26204 != 32LL);
        _26204 = NOVALUE;
        if (_26205 == 0) {
            DeRef(_26206);
            _26206 = 0;
            goto L10; // [360] 376
        }
        _2 = (object)SEQ_PTR(_inc_path_50927);
        _26207 = (object)*(((s1_ptr)_2)->base + _p_50963);
        _26208 = (_26207 != 9LL);
        _26207 = NOVALUE;
        _26206 = (_26208 != 0);
L10: 
        if (_26206 == 0)
        {
            _26206 = NOVALUE;
            goto LF; // [377] 386
        }
        else{
            _26206 = NOVALUE;
        }

        /** pathopen.e:623				start_path = p*/
        _start_path_50929 = _p_50963;
LF: 
LE: 

        /** pathopen.e:625		end for*/
        _p_50963 = _p_50963 + 1LL;
        goto L9; // [389] 186
LA: 
        ;
    }

    /** pathopen.e:627	label "cache done"*/
G7:

    /** pathopen.e:628		include_Paths &= cache_substrings[num_var]*/
    _2 = (object)SEQ_PTR(_46cache_substrings_50436);
    _26209 = (object)*(((s1_ptr)_2)->base + _46num_var_50433);
    Concat((object_ptr)&_46include_Paths_50921, _46include_Paths_50921, _26209);
    _26209 = NOVALUE;

    /** pathopen.e:629		cache_complete[num_var] = 1*/
    _2 = (object)SEQ_PTR(_46cache_complete_50440);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _46cache_complete_50440 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _46num_var_50433);
    *(intptr_t *)_2 = 1LL;

    /** pathopen.e:631		ifdef WINDOWS then*/

    /** pathopen.e:640		return include_Paths*/
    RefDS(_46include_Paths_50921);
    DeRefi(_inc_path_50927);
    DeRefi(_full_path_50928);
    DeRef(_eudir_path_50946);
    DeRef(_26202);
    _26202 = NOVALUE;
    DeRef(_26205);
    _26205 = NOVALUE;
    DeRef(_26188);
    _26188 = NOVALUE;
    DeRef(_26208);
    _26208 = NOVALUE;
    _26185 = NOVALUE;
    return _46include_Paths_50921;
    ;
}


object _46e_path_find(object _name_50999)
{
    object _scan_result_51000 = NOVALUE;
    object _26219 = NOVALUE;
    object _26218 = NOVALUE;
    object _26217 = NOVALUE;
    object _26214 = NOVALUE;
    object _26213 = NOVALUE;
    object _26212 = NOVALUE;
    object _26211 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:656		if file_exists(name) then*/
    RefDS(_name_50999);
    _26211 = _14file_exists(_name_50999);
    if (_26211 == 0) {
        DeRef(_26211);
        _26211 = NOVALUE;
        goto L1; // [9] 19
    }
    else {
        if (!IS_ATOM_INT(_26211) && DBL_PTR(_26211)->dbl == 0.0){
            DeRef(_26211);
            _26211 = NOVALUE;
            goto L1; // [9] 19
        }
        DeRef(_26211);
        _26211 = NOVALUE;
    }
    DeRef(_26211);
    _26211 = NOVALUE;

    /** pathopen.e:657			return name*/
    DeRef(_scan_result_51000);
    return _name_50999;
L1: 

    /** pathopen.e:661		for i = 1 to length(SLASH_CHARS) do*/
    if (IS_SEQUENCE(_44SLASH_CHARS_20390)){
            _26212 = SEQ_PTR(_44SLASH_CHARS_20390)->length;
    }
    else {
        _26212 = 1;
    }
    {
        object _i_51005;
        _i_51005 = 1LL;
L2: 
        if (_i_51005 > _26212){
            goto L3; // [26] 63
        }

        /** pathopen.e:662			if find(SLASH_CHARS[i], name) then*/
        _2 = (object)SEQ_PTR(_44SLASH_CHARS_20390);
        _26213 = (object)*(((s1_ptr)_2)->base + _i_51005);
        _26214 = find_from(_26213, _name_50999, 1LL);
        _26213 = NOVALUE;
        if (_26214 == 0)
        {
            _26214 = NOVALUE;
            goto L4; // [46] 56
        }
        else{
            _26214 = NOVALUE;
        }

        /** pathopen.e:663				return -1*/
        DeRefDS(_name_50999);
        DeRef(_scan_result_51000);
        return -1LL;
L4: 

        /** pathopen.e:665		end for*/
        _i_51005 = _i_51005 + 1LL;
        goto L2; // [58] 33
L3: 
        ;
    }

    /** pathopen.e:667		scan_result = ScanPath(name, "PATH", 0)*/
    RefDS(_name_50999);
    RefDS(_26215);
    _0 = _scan_result_51000;
    _scan_result_51000 = _46ScanPath(_name_50999, _26215, 0LL);
    DeRef(_0);

    /** pathopen.e:668		if sequence(scan_result) then*/
    _26217 = IS_SEQUENCE(_scan_result_51000);
    if (_26217 == 0)
    {
        _26217 = NOVALUE;
        goto L5; // [76] 98
    }
    else{
        _26217 = NOVALUE;
    }

    /** pathopen.e:669			close(scan_result[2])*/
    _2 = (object)SEQ_PTR(_scan_result_51000);
    _26218 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_26218))
    EClose(_26218);
    else
    EClose((object)DBL_PTR(_26218)->dbl);
    _26218 = NOVALUE;

    /** pathopen.e:670			return scan_result[1]*/
    _2 = (object)SEQ_PTR(_scan_result_51000);
    _26219 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_26219);
    DeRefDS(_name_50999);
    DeRef(_scan_result_51000);
    return _26219;
L5: 

    /** pathopen.e:673		return -1*/
    DeRefDS(_name_50999);
    DeRef(_scan_result_51000);
    _26219 = NOVALUE;
    return -1LL;
    ;
}



// 0x25FE1F4E
