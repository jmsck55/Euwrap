// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _45Push(object _x_51276)
{
    object _26376 = NOVALUE;
    object _26374 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_51276)) {
        _1 = (object)(DBL_PTR(_x_51276)->dbl);
        DeRefDS(_x_51276);
        _x_51276 = _1;
    }

    /** emit.e:135		cgi += 1*/
    _45cgi_51036 = _45cgi_51036 + 1;

    /** emit.e:136		if cgi > length(cg_stack) then*/
    if (IS_SEQUENCE(_45cg_stack_51035)){
            _26374 = SEQ_PTR(_45cg_stack_51035)->length;
    }
    else {
        _26374 = 1;
    }
    if (_45cgi_51036 <= _26374)
    goto L1; // [20] 37

    /** emit.e:137			cg_stack &= repeat(0, 400)*/
    _26376 = Repeat(0LL, 400LL);
    Concat((object_ptr)&_45cg_stack_51035, _45cg_stack_51035, _26376);
    DeRefDS(_26376);
    _26376 = NOVALUE;
L1: 

    /** emit.e:139		cg_stack[cgi] = x*/
    _2 = (object)SEQ_PTR(_45cg_stack_51035);
    _2 = (object)(((s1_ptr)_2)->base + _45cgi_51036);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _x_51276;
    DeRef(_1);

    /** emit.e:141	end procedure*/
    return;
    ;
}


object _45Top()
{
    object _26378 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:145		return cg_stack[cgi]*/
    _2 = (object)SEQ_PTR(_45cg_stack_51035);
    _26378 = (object)*(((s1_ptr)_2)->base + _45cgi_51036);
    Ref(_26378);
    return _26378;
    ;
}


object _45Pop()
{
    object _t_51289 = NOVALUE;
    object _s_51295 = NOVALUE;
    object _26390 = NOVALUE;
    object _26388 = NOVALUE;
    object _26386 = NOVALUE;
    object _26383 = NOVALUE;
    object _26382 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** emit.e:153		t = cg_stack[cgi]*/
    _2 = (object)SEQ_PTR(_45cg_stack_51035);
    _t_51289 = (object)*(((s1_ptr)_2)->base + _45cgi_51036);
    if (!IS_ATOM_INT(_t_51289)){
        _t_51289 = (object)DBL_PTR(_t_51289)->dbl;
    }

    /** emit.e:154		cgi -= 1*/
    _45cgi_51036 = _45cgi_51036 - 1LL;

    /** emit.e:155		if t > 0 then*/
    if (_t_51289 <= 0LL)
    goto L1; // [23] 116

    /** emit.e:156			symtab_index s = t -- for type checking*/
    _s_51295 = _t_51289;

    /** emit.e:157			if SymTab[t][S_MODE] = M_TEMP then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _26382 = (object)*(((s1_ptr)_2)->base + _t_51289);
    _2 = (object)SEQ_PTR(_26382);
    _26383 = (object)*(((s1_ptr)_2)->base + 3LL);
    _26382 = NOVALUE;
    if (binary_op_a(NOTEQ, _26383, 3LL)){
        _26383 = NOVALUE;
        goto L2; // [50] 115
    }
    _26383 = NOVALUE;

    /** emit.e:158				if use_private_list = 0 then  -- no problem with reusing the temp*/
    if (_12use_private_list_20340 != 0LL)
    goto L3; // [58] 82

    /** emit.e:159					SymTab[t][S_SCOPE] = FREE -- mark it as being free*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_t_51289 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _26386 = NOVALUE;
    goto L4; // [79] 114
L3: 

    /** emit.e:163				elsif find(t, private_sym) = 0 then*/
    _26388 = find_from(_t_51289, _12private_sym_20339, 1LL);
    if (_26388 != 0LL)
    goto L5; // [91] 113

    /** emit.e:165					SymTab[t][S_SCOPE] = FREE -- mark it as being free*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_t_51289 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _26390 = NOVALUE;
L5: 
L4: 
L2: 
L1: 

    /** emit.e:169		return t*/
    return _t_51289;
    ;
}


void _45TempKeep(object _x_51323)
{
    object _26397 = NOVALUE;
    object _26396 = NOVALUE;
    object _26395 = NOVALUE;
    object _26394 = NOVALUE;
    object _26393 = NOVALUE;
    object _26392 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** emit.e:173		if x > 0 and SymTab[x][S_MODE] = M_TEMP then*/
    _26392 = (_x_51323 > 0LL);
    if (_26392 == 0) {
        goto L1; // [9] 53
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _26394 = (object)*(((s1_ptr)_2)->base + _x_51323);
    _2 = (object)SEQ_PTR(_26394);
    _26395 = (object)*(((s1_ptr)_2)->base + 3LL);
    _26394 = NOVALUE;
    if (IS_ATOM_INT(_26395)) {
        _26396 = (_26395 == 3LL);
    }
    else {
        _26396 = binary_op(EQUALS, _26395, 3LL);
    }
    _26395 = NOVALUE;
    if (_26396 == 0) {
        DeRef(_26396);
        _26396 = NOVALUE;
        goto L1; // [32] 53
    }
    else {
        if (!IS_ATOM_INT(_26396) && DBL_PTR(_26396)->dbl == 0.0){
            DeRef(_26396);
            _26396 = NOVALUE;
            goto L1; // [32] 53
        }
        DeRef(_26396);
        _26396 = NOVALUE;
    }
    DeRef(_26396);
    _26396 = NOVALUE;

    /** emit.e:174			SymTab[x][S_SCOPE] = IN_USE*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_x_51323 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _26397 = NOVALUE;
L1: 

    /** emit.e:176	end procedure*/
    DeRef(_26392);
    _26392 = NOVALUE;
    return;
    ;
}


void _45TempFree(object _x_51341)
{
    object _26403 = NOVALUE;
    object _26401 = NOVALUE;
    object _26400 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** emit.e:179		if x > 0 then*/
    if (_x_51341 <= 0LL)
    goto L1; // [5] 53

    /** emit.e:180			if SymTab[x][S_MODE] = M_TEMP then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _26400 = (object)*(((s1_ptr)_2)->base + _x_51341);
    _2 = (object)SEQ_PTR(_26400);
    _26401 = (object)*(((s1_ptr)_2)->base + 3LL);
    _26400 = NOVALUE;
    if (binary_op_a(NOTEQ, _26401, 3LL)){
        _26401 = NOVALUE;
        goto L2; // [25] 52
    }
    _26401 = NOVALUE;

    /** emit.e:181				SymTab[x][S_SCOPE] = FREE*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_x_51341 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _26403 = NOVALUE;

    /** emit.e:182				clear_temp( x )*/
    _45clear_temp(_x_51341);
L2: 
L1: 

    /** emit.e:185	end procedure*/
    return;
    ;
}


void _45TempInteger(object _x_51360)
{
    object _26410 = NOVALUE;
    object _26409 = NOVALUE;
    object _26408 = NOVALUE;
    object _26407 = NOVALUE;
    object _26406 = NOVALUE;
    object _26405 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_x_51360)) {
        _1 = (object)(DBL_PTR(_x_51360)->dbl);
        DeRefDS(_x_51360);
        _x_51360 = _1;
    }

    /** emit.e:188		if x > 0 and SymTab[x][S_MODE] = M_TEMP then*/
    _26405 = (_x_51360 > 0LL);
    if (_26405 == 0) {
        goto L1; // [9] 53
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _26407 = (object)*(((s1_ptr)_2)->base + _x_51360);
    _2 = (object)SEQ_PTR(_26407);
    _26408 = (object)*(((s1_ptr)_2)->base + 3LL);
    _26407 = NOVALUE;
    if (IS_ATOM_INT(_26408)) {
        _26409 = (_26408 == 3LL);
    }
    else {
        _26409 = binary_op(EQUALS, _26408, 3LL);
    }
    _26408 = NOVALUE;
    if (_26409 == 0) {
        DeRef(_26409);
        _26409 = NOVALUE;
        goto L1; // [32] 53
    }
    else {
        if (!IS_ATOM_INT(_26409) && DBL_PTR(_26409)->dbl == 0.0){
            DeRef(_26409);
            _26409 = NOVALUE;
            goto L1; // [32] 53
        }
        DeRef(_26409);
        _26409 = NOVALUE;
    }
    DeRef(_26409);
    _26409 = NOVALUE;

    /** emit.e:189			SymTab[x][S_USAGE] = T_INTEGER*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_x_51360 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _26410 = NOVALUE;
L1: 

    /** emit.e:191	end procedure*/
    DeRef(_26405);
    _26405 = NOVALUE;
    return;
    ;
}


object _45LexName(object _t_51377, object _defname_51378)
{
    object _name_51380 = NOVALUE;
    object _26419 = NOVALUE;
    object _26417 = NOVALUE;
    object _26415 = NOVALUE;
    object _26414 = NOVALUE;
    object _26413 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_t_51377)) {
        _1 = (object)(DBL_PTR(_t_51377)->dbl);
        DeRefDS(_t_51377);
        _t_51377 = _1;
    }

    /** emit.e:197		for i = 1 to length(token_name) do*/
    _26413 = 80;
    {
        object _i_51382;
        _i_51382 = 1LL;
L1: 
        if (_i_51382 > 80LL){
            goto L2; // [12] 82
        }

        /** emit.e:198			if t = token_name[i][LEX_NUMBER] then*/
        _2 = (object)SEQ_PTR(_45token_name_51043);
        _26414 = (object)*(((s1_ptr)_2)->base + _i_51382);
        _2 = (object)SEQ_PTR(_26414);
        _26415 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26414 = NOVALUE;
        if (binary_op_a(NOTEQ, _t_51377, _26415)){
            _26415 = NOVALUE;
            goto L3; // [31] 75
        }
        _26415 = NOVALUE;

        /** emit.e:199				name = token_name[i][LEX_NAME]*/
        _2 = (object)SEQ_PTR(_45token_name_51043);
        _26417 = (object)*(((s1_ptr)_2)->base + _i_51382);
        DeRef(_name_51380);
        _2 = (object)SEQ_PTR(_26417);
        _name_51380 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_name_51380);
        _26417 = NOVALUE;

        /** emit.e:200				if not find(' ', name) then*/
        _26419 = find_from(32LL, _name_51380, 1LL);
        if (_26419 != 0)
        goto L4; // [56] 68
        _26419 = NOVALUE;

        /** emit.e:201					name = "'" & name & "'"*/
        {
            object concat_list[3];

            concat_list[0] = _26421;
            concat_list[1] = _name_51380;
            concat_list[2] = _26421;
            Concat_N((object_ptr)&_name_51380, concat_list, 3);
        }
L4: 

        /** emit.e:203				return name*/
        DeRefDSi(_defname_51378);
        return _name_51380;
L3: 

        /** emit.e:205		end for*/
        _i_51382 = _i_51382 + 1LL;
        goto L1; // [77] 19
L2: 
        ;
    }

    /** emit.e:206		return defname -- try to avoid this case*/
    DeRef(_name_51380);
    return _defname_51378;
    ;
}


void _45InitEmit()
{
    object _0, _1, _2;
    

    /** emit.e:212		cg_stack = repeat(0, 400)*/
    DeRef(_45cg_stack_51035);
    _45cg_stack_51035 = Repeat(0LL, 400LL);

    /** emit.e:213		cgi = 0*/
    _45cgi_51036 = 0LL;

    /** emit.e:214	end procedure*/
    return;
    ;
}


object _45IsInteger(object _sym_51401)
{
    object _mode_51402 = NOVALUE;
    object _t_51404 = NOVALUE;
    object _pt_51405 = NOVALUE;
    object _26444 = NOVALUE;
    object _26443 = NOVALUE;
    object _26441 = NOVALUE;
    object _26440 = NOVALUE;
    object _26439 = NOVALUE;
    object _26437 = NOVALUE;
    object _26436 = NOVALUE;
    object _26435 = NOVALUE;
    object _26434 = NOVALUE;
    object _26432 = NOVALUE;
    object _26428 = NOVALUE;
    object _26425 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_51401)) {
        _1 = (object)(DBL_PTR(_sym_51401)->dbl);
        DeRefDS(_sym_51401);
        _sym_51401 = _1;
    }

    /** emit.e:221		if sym < 1 then*/
    if (_sym_51401 >= 1LL)
    goto L1; // [5] 16

    /** emit.e:223			return 0*/
    return 0LL;
L1: 

    /** emit.e:226		mode = SymTab[sym][S_MODE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _26425 = (object)*(((s1_ptr)_2)->base + _sym_51401);
    _2 = (object)SEQ_PTR(_26425);
    _mode_51402 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_mode_51402)){
        _mode_51402 = (object)DBL_PTR(_mode_51402)->dbl;
    }
    _26425 = NOVALUE;

    /** emit.e:227		if mode = M_NORMAL then*/
    if (_mode_51402 != 1LL)
    goto L2; // [36] 136

    /** emit.e:228			t = SymTab[sym][S_VTYPE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _26428 = (object)*(((s1_ptr)_2)->base + _sym_51401);
    _2 = (object)SEQ_PTR(_26428);
    _t_51404 = (object)*(((s1_ptr)_2)->base + 15LL);
    if (!IS_ATOM_INT(_t_51404)){
        _t_51404 = (object)DBL_PTR(_t_51404)->dbl;
    }
    _26428 = NOVALUE;

    /** emit.e:229			if t = integer_type then*/
    if (_t_51404 != _53integer_type_46852)
    goto L3; // [60] 73

    /** emit.e:230				return TRUE*/
    return _9TRUE_446;
L3: 

    /** emit.e:232			if t > 0 then*/
    if (_t_51404 <= 0LL)
    goto L4; // [75] 215

    /** emit.e:233				pt = SymTab[t][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _26432 = (object)*(((s1_ptr)_2)->base + _t_51404);
    _2 = (object)SEQ_PTR(_26432);
    _pt_51405 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_pt_51405)){
        _pt_51405 = (object)DBL_PTR(_pt_51405)->dbl;
    }
    _26432 = NOVALUE;

    /** emit.e:234				if pt and SymTab[pt][S_VTYPE] = integer_type then*/
    if (_pt_51405 == 0) {
        goto L4; // [97] 215
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _26435 = (object)*(((s1_ptr)_2)->base + _pt_51405);
    _2 = (object)SEQ_PTR(_26435);
    _26436 = (object)*(((s1_ptr)_2)->base + 15LL);
    _26435 = NOVALUE;
    if (IS_ATOM_INT(_26436)) {
        _26437 = (_26436 == _53integer_type_46852);
    }
    else {
        _26437 = binary_op(EQUALS, _26436, _53integer_type_46852);
    }
    _26436 = NOVALUE;
    if (_26437 == 0) {
        DeRef(_26437);
        _26437 = NOVALUE;
        goto L4; // [120] 215
    }
    else {
        if (!IS_ATOM_INT(_26437) && DBL_PTR(_26437)->dbl == 0.0){
            DeRef(_26437);
            _26437 = NOVALUE;
            goto L4; // [120] 215
        }
        DeRef(_26437);
        _26437 = NOVALUE;
    }
    DeRef(_26437);
    _26437 = NOVALUE;

    /** emit.e:235					return TRUE   -- usertype(integer x)*/
    return _9TRUE_446;
    goto L4; // [133] 215
L2: 

    /** emit.e:239		elsif mode = M_CONSTANT then*/
    if (_mode_51402 != 2LL)
    goto L5; // [140] 176

    /** emit.e:240			if integer(SymTab[sym][S_OBJ]) then  -- bug fixed: can't allow PLUS1_I op*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _26439 = (object)*(((s1_ptr)_2)->base + _sym_51401);
    _2 = (object)SEQ_PTR(_26439);
    _26440 = (object)*(((s1_ptr)_2)->base + 1LL);
    _26439 = NOVALUE;
    if (IS_ATOM_INT(_26440))
    _26441 = 1;
    else if (IS_ATOM_DBL(_26440))
    _26441 = IS_ATOM_INT(DoubleToInt(_26440));
    else
    _26441 = 0;
    _26440 = NOVALUE;
    if (_26441 == 0)
    {
        _26441 = NOVALUE;
        goto L4; // [161] 215
    }
    else{
        _26441 = NOVALUE;
    }

    /** emit.e:241				return TRUE*/
    return _9TRUE_446;
    goto L4; // [173] 215
L5: 

    /** emit.e:244		elsif mode = M_TEMP then*/
    if (_mode_51402 != 3LL)
    goto L6; // [180] 214

    /** emit.e:245			if SymTab[sym][S_USAGE] = T_INTEGER then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _26443 = (object)*(((s1_ptr)_2)->base + _sym_51401);
    _2 = (object)SEQ_PTR(_26443);
    _26444 = (object)*(((s1_ptr)_2)->base + 5LL);
    _26443 = NOVALUE;
    if (binary_op_a(NOTEQ, _26444, 1LL)){
        _26444 = NOVALUE;
        goto L7; // [200] 213
    }
    _26444 = NOVALUE;

    /** emit.e:246				return TRUE*/
    return _9TRUE_446;
L7: 
L6: 
L4: 

    /** emit.e:250		return FALSE*/
    return _9FALSE_444;
    ;
}


void _45emit(object _val_51462)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_val_51462)) {
        _1 = (object)(DBL_PTR(_val_51462)->dbl);
        DeRefDS(_val_51462);
        _val_51462 = _1;
    }

    /** emit.e:260		Code = append(Code, val)*/
    Append(&_12Code_20315, _12Code_20315, _val_51462);

    /** emit.e:261	end procedure*/
    return;
    ;
}


void _45emit_opnd(object _opnd_51469)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_opnd_51469)) {
        _1 = (object)(DBL_PTR(_opnd_51469)->dbl);
        DeRefDS(_opnd_51469);
        _opnd_51469 = _1;
    }

    /** emit.e:271			Push(opnd)*/
    _45Push(_opnd_51469);

    /** emit.e:272			previous_op = -1  -- N.B.*/
    _12previous_op_20325 = -1LL;

    /** emit.e:273	end procedure*/
    return;
    ;
}


void _45emit_addr(object _x_51473)
{
    object _0, _1, _2;
    

    /** emit.e:277			Code = append(Code, x)*/
    Ref(_x_51473);
    Append(&_12Code_20315, _12Code_20315, _x_51473);

    /** emit.e:278	end procedure*/
    DeRef(_x_51473);
    return;
    ;
}


void _45emit_opcode(object _op_51479)
{
    object _0, _1, _2;
    

    /** emit.e:282		Code = append(Code, op)*/
    Append(&_12Code_20315, _12Code_20315, _op_51479);

    /** emit.e:283	end procedure*/
    return;
    ;
}


void _45emit_temp(object _tempsym_51513, object _referenced_51514)
{
    object _26475 = NOVALUE;
    object _26474 = NOVALUE;
    object _26473 = NOVALUE;
    object _26472 = NOVALUE;
    object _26471 = NOVALUE;
    object _26470 = NOVALUE;
    object _26469 = NOVALUE;
    object _26468 = NOVALUE;
    object _26467 = NOVALUE;
    object _26466 = NOVALUE;
    object _26465 = NOVALUE;
    object _26464 = NOVALUE;
    object _26463 = NOVALUE;
    object _26462 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:307		if not TRANSLATE  then -- translator has its own way of handling temps*/
    if (_12TRANSLATE_19834 != 0)
    goto L1; // [7] 129

    /** emit.e:308			if sequence(tempsym) then*/
    _26462 = IS_SEQUENCE(_tempsym_51513);
    if (_26462 == 0)
    {
        _26462 = NOVALUE;
        goto L2; // [15] 53
    }
    else{
        _26462 = NOVALUE;
    }

    /** emit.e:309				for i = 1 to length(tempsym) do*/
    if (IS_SEQUENCE(_tempsym_51513)){
            _26463 = SEQ_PTR(_tempsym_51513)->length;
    }
    else {
        _26463 = 1;
    }
    {
        object _i_51521;
        _i_51521 = 1LL;
L3: 
        if (_i_51521 > _26463){
            goto L4; // [23] 50
        }

        /** emit.e:310					emit_temp( tempsym[i], referenced )*/
        _2 = (object)SEQ_PTR(_tempsym_51513);
        _26464 = (object)*(((s1_ptr)_2)->base + _i_51521);
        DeRef(_26465);
        _26465 = _referenced_51514;
        Ref(_26464);
        _45emit_temp(_26464, _26465);
        _26464 = NOVALUE;
        _26465 = NOVALUE;

        /** emit.e:311				end for*/
        _i_51521 = _i_51521 + 1LL;
        goto L3; // [45] 30
L4: 
        ;
    }
    goto L5; // [50] 128
L2: 

    /** emit.e:313			elsif tempsym > 0*/
    if (IS_ATOM_INT(_tempsym_51513)) {
        _26466 = (_tempsym_51513 > 0LL);
    }
    else {
        _26466 = binary_op(GREATER, _tempsym_51513, 0LL);
    }
    if (IS_ATOM_INT(_26466)) {
        if (_26466 == 0) {
            DeRef(_26467);
            _26467 = 0;
            goto L6; // [59] 77
        }
    }
    else {
        if (DBL_PTR(_26466)->dbl == 0.0) {
            DeRef(_26467);
            _26467 = 0;
            goto L6; // [59] 77
        }
    }
    Ref(_tempsym_51513);
    _26468 = _53sym_mode(_tempsym_51513);
    if (IS_ATOM_INT(_26468)) {
        _26469 = (_26468 == 3LL);
    }
    else {
        _26469 = binary_op(EQUALS, _26468, 3LL);
    }
    DeRef(_26468);
    _26468 = NOVALUE;
    DeRef(_26467);
    if (IS_ATOM_INT(_26469))
    _26467 = (_26469 != 0);
    else
    _26467 = DBL_PTR(_26469)->dbl != 0.0;
L6: 
    if (_26467 == 0) {
        _26470 = 0;
        goto L7; // [77] 92
    }
    Ref(_tempsym_51513);
    _26471 = _45IsInteger(_tempsym_51513);
    if (IS_ATOM_INT(_26471)) {
        _26472 = (_26471 == 0);
    }
    else {
        _26472 = unary_op(NOT, _26471);
    }
    DeRef(_26471);
    _26471 = NOVALUE;
    if (IS_ATOM_INT(_26472))
    _26470 = (_26472 != 0);
    else
    _26470 = DBL_PTR(_26472)->dbl != 0.0;
L7: 
    if (_26470 == 0) {
        goto L8; // [92] 127
    }
    _26474 = find_from(_tempsym_51513, _45emitted_temps_51509, 1LL);
    _26475 = (_26474 == 0);
    _26474 = NOVALUE;
    if (_26475 == 0)
    {
        DeRef(_26475);
        _26475 = NOVALUE;
        goto L8; // [107] 127
    }
    else{
        DeRef(_26475);
        _26475 = NOVALUE;
    }

    /** emit.e:319				emitted_temps &= tempsym*/
    if (IS_SEQUENCE(_45emitted_temps_51509) && IS_ATOM(_tempsym_51513)) {
        Ref(_tempsym_51513);
        Append(&_45emitted_temps_51509, _45emitted_temps_51509, _tempsym_51513);
    }
    else if (IS_ATOM(_45emitted_temps_51509) && IS_SEQUENCE(_tempsym_51513)) {
    }
    else {
        Concat((object_ptr)&_45emitted_temps_51509, _45emitted_temps_51509, _tempsym_51513);
    }

    /** emit.e:320				emitted_temp_referenced &= referenced*/
    Append(&_45emitted_temp_referenced_51510, _45emitted_temp_referenced_51510, _referenced_51514);
L8: 
L5: 
L1: 

    /** emit.e:323	end procedure*/
    DeRef(_tempsym_51513);
    DeRef(_26466);
    _26466 = NOVALUE;
    DeRef(_26472);
    _26472 = NOVALUE;
    DeRef(_26469);
    _26469 = NOVALUE;
    return;
    ;
}


void _45flush_temps(object _except_for_51543)
{
    object _refs_51546 = NOVALUE;
    object _novalues_51547 = NOVALUE;
    object _sym_51552 = NOVALUE;
    object _26490 = NOVALUE;
    object _26489 = NOVALUE;
    object _26488 = NOVALUE;
    object _26487 = NOVALUE;
    object _26485 = NOVALUE;
    object _26481 = NOVALUE;
    object _26480 = NOVALUE;
    object _26478 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:332		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L1; // [7] 16
    }
    else{
    }

    /** emit.e:333			return*/
    DeRefDS(_except_for_51543);
    DeRef(_refs_51546);
    DeRefi(_novalues_51547);
    return;
L1: 

    /** emit.e:336		sequence*/

    /** emit.e:337			refs = {},*/
    RefDS(_22024);
    DeRef(_refs_51546);
    _refs_51546 = _22024;

    /** emit.e:338			novalues = {}*/
    RefDS(_22024);
    DeRefi(_novalues_51547);
    _novalues_51547 = _22024;

    /** emit.e:340		derefs = {}*/
    RefDS(_22024);
    DeRefi(_45derefs_51540);
    _45derefs_51540 = _22024;

    /** emit.e:341		for i = 1 to length( emitted_temps ) do*/
    if (IS_SEQUENCE(_45emitted_temps_51509)){
            _26478 = SEQ_PTR(_45emitted_temps_51509)->length;
    }
    else {
        _26478 = 1;
    }
    {
        object _i_51549;
        _i_51549 = 1LL;
L2: 
        if (_i_51549 > _26478){
            goto L3; // [46] 119
        }

        /** emit.e:342			symtab_index sym = emitted_temps[i]*/
        _2 = (object)SEQ_PTR(_45emitted_temps_51509);
        _sym_51552 = (object)*(((s1_ptr)_2)->base + _i_51549);
        if (!IS_ATOM_INT(_sym_51552)){
            _sym_51552 = (object)DBL_PTR(_sym_51552)->dbl;
        }

        /** emit.e:344			if find( sym, except_for ) then*/
        _26480 = find_from(_sym_51552, _except_for_51543, 1LL);
        if (_26480 == 0)
        {
            _26480 = NOVALUE;
            goto L4; // [70] 80
        }
        else{
            _26480 = NOVALUE;
        }

        /** emit.e:345				continue*/
        goto L5; // [77] 114
L4: 

        /** emit.e:348			if emitted_temp_referenced[i] = NEW_REFERENCE then*/
        _2 = (object)SEQ_PTR(_45emitted_temp_referenced_51510);
        _26481 = (object)*(((s1_ptr)_2)->base + _i_51549);
        if (binary_op_a(NOTEQ, _26481, 1LL)){
            _26481 = NOVALUE;
            goto L6; // [88] 103
        }
        _26481 = NOVALUE;

        /** emit.e:349				derefs &= sym*/
        Append(&_45derefs_51540, _45derefs_51540, _sym_51552);
        goto L7; // [100] 110
L6: 

        /** emit.e:351				novalues &= sym*/
        Append(&_novalues_51547, _novalues_51547, _sym_51552);
L7: 

        /** emit.e:353		end for*/
L5: 
        _i_51549 = _i_51549 + 1LL;
        goto L2; // [114] 53
L3: 
        ;
    }

    /** emit.e:355		if not length( except_for ) then*/
    if (IS_SEQUENCE(_except_for_51543)){
            _26485 = SEQ_PTR(_except_for_51543)->length;
    }
    else {
        _26485 = 1;
    }
    if (_26485 != 0)
    goto L8; // [124] 132
    _26485 = NOVALUE;

    /** emit.e:356			clear_last()*/
    _45clear_last();
L8: 

    /** emit.e:359		for i = 1 to length( derefs ) do*/
    if (IS_SEQUENCE(_45derefs_51540)){
            _26487 = SEQ_PTR(_45derefs_51540)->length;
    }
    else {
        _26487 = 1;
    }
    {
        object _i_51567;
        _i_51567 = 1LL;
L9: 
        if (_i_51567 > _26487){
            goto LA; // [139] 171
        }

        /** emit.e:360			emit( DEREF_TEMP )*/
        _45emit(208LL);

        /** emit.e:361			emit( derefs[i] )*/
        _2 = (object)SEQ_PTR(_45derefs_51540);
        _26488 = (object)*(((s1_ptr)_2)->base + _i_51567);
        _45emit(_26488);
        _26488 = NOVALUE;

        /** emit.e:362		end for*/
        _i_51567 = _i_51567 + 1LL;
        goto L9; // [166] 146
LA: 
        ;
    }

    /** emit.e:364		for i = 1 to length( novalues ) do*/
    if (IS_SEQUENCE(_novalues_51547)){
            _26489 = SEQ_PTR(_novalues_51547)->length;
    }
    else {
        _26489 = 1;
    }
    {
        object _i_51572;
        _i_51572 = 1LL;
LB: 
        if (_i_51572 > _26489){
            goto LC; // [176] 206
        }

        /** emit.e:365			emit( NOVALUE_TEMP )*/
        _45emit(209LL);

        /** emit.e:366			emit( novalues[i] )*/
        _2 = (object)SEQ_PTR(_novalues_51547);
        _26490 = (object)*(((s1_ptr)_2)->base + _i_51572);
        _45emit(_26490);
        _26490 = NOVALUE;

        /** emit.e:367		end for*/
        _i_51572 = _i_51572 + 1LL;
        goto LB; // [201] 183
LC: 
        ;
    }

    /** emit.e:369		emitted_temps = {}*/
    RefDS(_22024);
    DeRef(_45emitted_temps_51509);
    _45emitted_temps_51509 = _22024;

    /** emit.e:370		emitted_temp_referenced = {}*/
    RefDS(_22024);
    DeRef(_45emitted_temp_referenced_51510);
    _45emitted_temp_referenced_51510 = _22024;

    /** emit.e:371	end procedure*/
    DeRefDS(_except_for_51543);
    DeRef(_refs_51546);
    DeRefi(_novalues_51547);
    return;
    ;
}


void _45flush_temp(object _temp_51579)
{
    object _except_for_51580 = NOVALUE;
    object _ix_51581 = NOVALUE;
    object _26492 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_temp_51579)) {
        _1 = (object)(DBL_PTR(_temp_51579)->dbl);
        DeRefDS(_temp_51579);
        _temp_51579 = _1;
    }

    /** emit.e:374		sequence except_for = emitted_temps*/
    RefDS(_45emitted_temps_51509);
    DeRef(_except_for_51580);
    _except_for_51580 = _45emitted_temps_51509;

    /** emit.e:375		integer ix = find( temp, emitted_temps )*/
    _ix_51581 = find_from(_temp_51579, _45emitted_temps_51509, 1LL);

    /** emit.e:376		if ix then*/
    if (_ix_51581 == 0)
    {
        goto L1; // [23] 37
    }
    else{
    }

    /** emit.e:377			flush_temps( remove( except_for, ix ) )*/
    {
        s1_ptr assign_space = SEQ_PTR(_except_for_51580);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_51581)) ? _ix_51581 : (object)(DBL_PTR(_ix_51581)->dbl);
        int stop = (IS_ATOM_INT(_ix_51581)) ? _ix_51581 : (object)(DBL_PTR(_ix_51581)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
            RefDS(_except_for_51580);
            DeRef(_26492);
            _26492 = _except_for_51580;
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_except_for_51580), start, &_26492 );
            }
            else Tail(SEQ_PTR(_except_for_51580), stop+1, &_26492);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_except_for_51580), start, &_26492);
        }
        else {
            assign_slice_seq = &assign_space;
            _1 = Remove_elements(start, stop, 0);
            DeRef(_26492);
            _26492 = _1;
        }
    }
    _45flush_temps(_26492);
    _26492 = NOVALUE;
L1: 

    /** emit.e:379	end procedure*/
    DeRef(_except_for_51580);
    return;
    ;
}


void _45check_for_temps()
{
    object _26499 = NOVALUE;
    object _26498 = NOVALUE;
    object _26497 = NOVALUE;
    object _26496 = NOVALUE;
    object _26494 = NOVALUE;
    object _26493 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:382		if TRANSLATE or last_op < 1 or last_pc < 1 then*/
    if (_12TRANSLATE_19834 != 0) {
        _26493 = 1;
        goto L1; // [5] 19
    }
    _26494 = (_45last_op_51919 < 1LL);
    _26493 = (_26494 != 0);
L1: 
    if (_26493 != 0) {
        goto L2; // [19] 34
    }
    _26496 = (_45last_pc_51920 < 1LL);
    if (_26496 == 0)
    {
        DeRef(_26496);
        _26496 = NOVALUE;
        goto L3; // [30] 40
    }
    else{
        DeRef(_26496);
        _26496 = NOVALUE;
    }
L2: 

    /** emit.e:383			return*/
    DeRef(_26494);
    _26494 = NOVALUE;
    return;
L3: 

    /** emit.e:386		emit_temp( get_target_sym( current_op( last_pc ) ), op_temp_ref[last_op] )*/
    RefDS(_12Code_20315);
    _26497 = _65current_op(_45last_pc_51920, _12Code_20315);
    _26498 = _65get_target_sym(_26497);
    _26497 = NOVALUE;
    _2 = (object)SEQ_PTR(_45op_temp_ref_51731);
    _26499 = (object)*(((s1_ptr)_2)->base + _45last_op_51919);
    _45emit_temp(_26498, _26499);
    _26498 = NOVALUE;
    _26499 = NOVALUE;

    /** emit.e:388	end procedure*/
    DeRef(_26494);
    _26494 = NOVALUE;
    return;
    ;
}


void _45clear_temp(object _tempsym_51606)
{
    object _ix_51607 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_tempsym_51606)) {
        _1 = (object)(DBL_PTR(_tempsym_51606)->dbl);
        DeRefDS(_tempsym_51606);
        _tempsym_51606 = _1;
    }

    /** emit.e:391		integer ix = find( tempsym, emitted_temps )*/
    _ix_51607 = find_from(_tempsym_51606, _45emitted_temps_51509, 1LL);

    /** emit.e:392		if ix then*/
    if (_ix_51607 == 0)
    {
        goto L1; // [14] 36
    }
    else{
    }

    /** emit.e:393			emitted_temps = remove( emitted_temps, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_45emitted_temps_51509);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_51607)) ? _ix_51607 : (object)(DBL_PTR(_ix_51607)->dbl);
        int stop = (IS_ATOM_INT(_ix_51607)) ? _ix_51607 : (object)(DBL_PTR(_ix_51607)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_45emitted_temps_51509), start, &_45emitted_temps_51509 );
            }
            else Tail(SEQ_PTR(_45emitted_temps_51509), stop+1, &_45emitted_temps_51509);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_45emitted_temps_51509), start, &_45emitted_temps_51509);
        }
        else {
            assign_slice_seq = &assign_space;
            _45emitted_temps_51509 = Remove_elements(start, stop, (SEQ_PTR(_45emitted_temps_51509)->ref == 1));
        }
    }

    /** emit.e:394			emitted_temp_referenced = remove( emitted_temp_referenced, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_45emitted_temp_referenced_51510);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_51607)) ? _ix_51607 : (object)(DBL_PTR(_ix_51607)->dbl);
        int stop = (IS_ATOM_INT(_ix_51607)) ? _ix_51607 : (object)(DBL_PTR(_ix_51607)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_45emitted_temp_referenced_51510), start, &_45emitted_temp_referenced_51510 );
            }
            else Tail(SEQ_PTR(_45emitted_temp_referenced_51510), stop+1, &_45emitted_temp_referenced_51510);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_45emitted_temp_referenced_51510), start, &_45emitted_temp_referenced_51510);
        }
        else {
            assign_slice_seq = &assign_space;
            _45emitted_temp_referenced_51510 = Remove_elements(start, stop, (SEQ_PTR(_45emitted_temp_referenced_51510)->ref == 1));
        }
    }
L1: 

    /** emit.e:396	end procedure*/
    return;
    ;
}


object _45pop_temps()
{
    object _new_emitted_51614 = NOVALUE;
    object _new_referenced_51615 = NOVALUE;
    object _26503 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:402		sequence new_emitted  = emitted_temps*/
    RefDS(_45emitted_temps_51509);
    DeRef(_new_emitted_51614);
    _new_emitted_51614 = _45emitted_temps_51509;

    /** emit.e:403		sequence new_referenced = emitted_temp_referenced*/
    RefDS(_45emitted_temp_referenced_51510);
    DeRef(_new_referenced_51615);
    _new_referenced_51615 = _45emitted_temp_referenced_51510;

    /** emit.e:405		emitted_temps  = {}*/
    RefDS(_22024);
    DeRefDS(_45emitted_temps_51509);
    _45emitted_temps_51509 = _22024;

    /** emit.e:406		emitted_temp_referenced = {}*/
    RefDS(_22024);
    DeRefDS(_45emitted_temp_referenced_51510);
    _45emitted_temp_referenced_51510 = _22024;

    /** emit.e:407		return { new_emitted, new_referenced }*/
    RefDS(_new_referenced_51615);
    RefDS(_new_emitted_51614);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _new_emitted_51614;
    ((intptr_t *)_2)[2] = _new_referenced_51615;
    _26503 = MAKE_SEQ(_1);
    DeRefDS(_new_emitted_51614);
    DeRefDS(_new_referenced_51615);
    return _26503;
    ;
}


object _45get_temps(object _add_to_51619)
{
    object _26508 = NOVALUE;
    object _26507 = NOVALUE;
    object _26506 = NOVALUE;
    object _26505 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:416		add_to[1] &= emitted_temps*/
    _2 = (object)SEQ_PTR(_add_to_51619);
    _26505 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_26505) && IS_ATOM(_45emitted_temps_51509)) {
    }
    else if (IS_ATOM(_26505) && IS_SEQUENCE(_45emitted_temps_51509)) {
        Ref(_26505);
        Prepend(&_26506, _45emitted_temps_51509, _26505);
    }
    else {
        Concat((object_ptr)&_26506, _26505, _45emitted_temps_51509);
        _26505 = NOVALUE;
    }
    _26505 = NOVALUE;
    _2 = (object)SEQ_PTR(_add_to_51619);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _add_to_51619 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _26506;
    if( _1 != _26506 ){
        DeRef(_1);
    }
    _26506 = NOVALUE;

    /** emit.e:417		add_to[2] &= emitted_temp_referenced*/
    _2 = (object)SEQ_PTR(_add_to_51619);
    _26507 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_SEQUENCE(_26507) && IS_ATOM(_45emitted_temp_referenced_51510)) {
    }
    else if (IS_ATOM(_26507) && IS_SEQUENCE(_45emitted_temp_referenced_51510)) {
        Ref(_26507);
        Prepend(&_26508, _45emitted_temp_referenced_51510, _26507);
    }
    else {
        Concat((object_ptr)&_26508, _26507, _45emitted_temp_referenced_51510);
        _26507 = NOVALUE;
    }
    _26507 = NOVALUE;
    _2 = (object)SEQ_PTR(_add_to_51619);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _add_to_51619 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _26508;
    if( _1 != _26508 ){
        DeRef(_1);
    }
    _26508 = NOVALUE;

    /** emit.e:418		return add_to*/
    return _add_to_51619;
    ;
}


void _45push_temps(object _temps_51627)
{
    object _26511 = NOVALUE;
    object _26509 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:426		emitted_temps &= temps[1]*/
    _2 = (object)SEQ_PTR(_temps_51627);
    _26509 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_45emitted_temps_51509) && IS_ATOM(_26509)) {
        Ref(_26509);
        Append(&_45emitted_temps_51509, _45emitted_temps_51509, _26509);
    }
    else if (IS_ATOM(_45emitted_temps_51509) && IS_SEQUENCE(_26509)) {
    }
    else {
        Concat((object_ptr)&_45emitted_temps_51509, _45emitted_temps_51509, _26509);
    }
    _26509 = NOVALUE;

    /** emit.e:427		emitted_temp_referenced &= temps[2]*/
    _2 = (object)SEQ_PTR(_temps_51627);
    _26511 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_SEQUENCE(_45emitted_temp_referenced_51510) && IS_ATOM(_26511)) {
        Ref(_26511);
        Append(&_45emitted_temp_referenced_51510, _45emitted_temp_referenced_51510, _26511);
    }
    else if (IS_ATOM(_45emitted_temp_referenced_51510) && IS_SEQUENCE(_26511)) {
    }
    else {
        Concat((object_ptr)&_45emitted_temp_referenced_51510, _45emitted_temp_referenced_51510, _26511);
    }
    _26511 = NOVALUE;

    /** emit.e:428		flush_temps()*/
    RefDS(_22024);
    _45flush_temps(_22024);

    /** emit.e:429	end procedure*/
    DeRefDS(_temps_51627);
    return;
    ;
}


void _45backpatch(object _index_51634, object _val_51635)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_index_51634)) {
        _1 = (object)(DBL_PTR(_index_51634)->dbl);
        DeRefDS(_index_51634);
        _index_51634 = _1;
    }
    if (!IS_ATOM_INT(_val_51635)) {
        _1 = (object)(DBL_PTR(_val_51635)->dbl);
        DeRefDS(_val_51635);
        _val_51635 = _1;
    }

    /** emit.e:433			Code[index] = val*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _index_51634);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _val_51635;
    DeRef(_1);

    /** emit.e:434	end procedure*/
    return;
    ;
}


void _45cont11ii(object _op_51819, object _ii_51821)
{
    object _t_51822 = NOVALUE;
    object _source_51823 = NOVALUE;
    object _c_51824 = NOVALUE;
    object _26520 = NOVALUE;
    object _26519 = NOVALUE;
    object _26517 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:580		emit_opcode(op)*/
    _45emit_opcode(_op_51819);

    /** emit.e:581		source = Pop()*/
    _source_51823 = _45Pop();
    if (!IS_ATOM_INT(_source_51823)) {
        _1 = (object)(DBL_PTR(_source_51823)->dbl);
        DeRefDS(_source_51823);
        _source_51823 = _1;
    }

    /** emit.e:582		emit_addr(source)*/
    _45emit_addr(_source_51823);

    /** emit.e:583		assignable = TRUE*/
    _45assignable_51038 = _9TRUE_446;

    /** emit.e:584		t = op_result[op]*/
    _2 = (object)SEQ_PTR(_45op_result_51637);
    _t_51822 = (object)*(((s1_ptr)_2)->base + _op_51819);

    /** emit.e:587		if t = T_INTEGER or (ii and IsInteger(source)) then*/
    _26517 = (_t_51822 == 1LL);
    if (_26517 != 0) {
        goto L1; // [43] 64
    }
    if (_ii_51821 == 0) {
        _26519 = 0;
        goto L2; // [47] 59
    }
    _26520 = _45IsInteger(_source_51823);
    if (IS_ATOM_INT(_26520))
    _26519 = (_26520 != 0);
    else
    _26519 = DBL_PTR(_26520)->dbl != 0.0;
L2: 
    if (_26519 == 0)
    {
        _26519 = NOVALUE;
        goto L3; // [60] 80
    }
    else{
        _26519 = NOVALUE;
    }
L1: 

    /** emit.e:588			c = NewTempSym()*/
    _c_51824 = _53NewTempSym(0LL);
    if (!IS_ATOM_INT(_c_51824)) {
        _1 = (object)(DBL_PTR(_c_51824)->dbl);
        DeRefDS(_c_51824);
        _c_51824 = _1;
    }

    /** emit.e:589			TempInteger(c)*/
    _45TempInteger(_c_51824);
    goto L4; // [77] 95
L3: 

    /** emit.e:591			c = NewTempSym() -- allocate *after* checking opnd type*/
    _c_51824 = _53NewTempSym(0LL);
    if (!IS_ATOM_INT(_c_51824)) {
        _1 = (object)(DBL_PTR(_c_51824)->dbl);
        DeRefDS(_c_51824);
        _c_51824 = _1;
    }

    /** emit.e:592			emit_temp( c, NEW_REFERENCE )*/
    _45emit_temp(_c_51824, 1LL);
L4: 

    /** emit.e:595		Push(c)*/
    _45Push(_c_51824);

    /** emit.e:596		emit_addr(c)*/
    _45emit_addr(_c_51824);

    /** emit.e:597	end procedure*/
    DeRef(_26520);
    _26520 = NOVALUE;
    DeRef(_26517);
    _26517 = NOVALUE;
    return;
    ;
}


void _45cont21d(object _op_51841, object _a_51842, object _b_51843, object _ii_51845)
{
    object _c_51846 = NOVALUE;
    object _t_51847 = NOVALUE;
    object _26530 = NOVALUE;
    object _26529 = NOVALUE;
    object _26528 = NOVALUE;
    object _26527 = NOVALUE;
    object _26525 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:602		assignable = TRUE*/
    _45assignable_51038 = _9TRUE_446;

    /** emit.e:603		t = op_result[op]*/
    _2 = (object)SEQ_PTR(_45op_result_51637);
    _t_51847 = (object)*(((s1_ptr)_2)->base + _op_51841);

    /** emit.e:604		if op = C_FUNC then*/
    if (_op_51841 != 133LL)
    goto L1; // [26] 38

    /** emit.e:605			emit_addr(CurrentSub)*/
    _45emit_addr(_12CurrentSub_20234);
L1: 

    /** emit.e:607		if t = T_INTEGER or (ii and IsInteger(a) and IsInteger(b)) then*/
    _26525 = (_t_51847 == 1LL);
    if (_26525 != 0) {
        goto L2; // [46] 79
    }
    if (_ii_51845 == 0) {
        _26527 = 0;
        goto L3; // [50] 62
    }
    _26528 = _45IsInteger(_a_51842);
    if (IS_ATOM_INT(_26528))
    _26527 = (_26528 != 0);
    else
    _26527 = DBL_PTR(_26528)->dbl != 0.0;
L3: 
    if (_26527 == 0) {
        DeRef(_26529);
        _26529 = 0;
        goto L4; // [62] 74
    }
    _26530 = _45IsInteger(_b_51843);
    if (IS_ATOM_INT(_26530))
    _26529 = (_26530 != 0);
    else
    _26529 = DBL_PTR(_26530)->dbl != 0.0;
L4: 
    if (_26529 == 0)
    {
        _26529 = NOVALUE;
        goto L5; // [75] 95
    }
    else{
        _26529 = NOVALUE;
    }
L2: 

    /** emit.e:608			c = NewTempSym()*/
    _c_51846 = _53NewTempSym(0LL);
    if (!IS_ATOM_INT(_c_51846)) {
        _1 = (object)(DBL_PTR(_c_51846)->dbl);
        DeRefDS(_c_51846);
        _c_51846 = _1;
    }

    /** emit.e:609			TempInteger(c)*/
    _45TempInteger(_c_51846);
    goto L6; // [92] 110
L5: 

    /** emit.e:611			c = NewTempSym() -- allocate *after* checking opnd types*/
    _c_51846 = _53NewTempSym(0LL);
    if (!IS_ATOM_INT(_c_51846)) {
        _1 = (object)(DBL_PTR(_c_51846)->dbl);
        DeRefDS(_c_51846);
        _c_51846 = _1;
    }

    /** emit.e:612			emit_temp( c, NEW_REFERENCE )*/
    _45emit_temp(_c_51846, 1LL);
L6: 

    /** emit.e:614		Push(c)*/
    _45Push(_c_51846);

    /** emit.e:615		emit_addr(c)*/
    _45emit_addr(_c_51846);

    /** emit.e:616	end procedure*/
    DeRef(_26530);
    _26530 = NOVALUE;
    DeRef(_26528);
    _26528 = NOVALUE;
    DeRef(_26525);
    _26525 = NOVALUE;
    return;
    ;
}


void _45cont21ii(object _op_51869, object _ii_51871)
{
    object _a_51872 = NOVALUE;
    object _b_51873 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:621		b = Pop()*/
    _b_51873 = _45Pop();
    if (!IS_ATOM_INT(_b_51873)) {
        _1 = (object)(DBL_PTR(_b_51873)->dbl);
        DeRefDS(_b_51873);
        _b_51873 = _1;
    }

    /** emit.e:622		emit_opcode(op)*/
    _45emit_opcode(_op_51869);

    /** emit.e:623		a = Pop()*/
    _a_51872 = _45Pop();
    if (!IS_ATOM_INT(_a_51872)) {
        _1 = (object)(DBL_PTR(_a_51872)->dbl);
        DeRefDS(_a_51872);
        _a_51872 = _1;
    }

    /** emit.e:624		emit_addr(a)*/
    _45emit_addr(_a_51872);

    /** emit.e:625		emit_addr(b)*/
    _45emit_addr(_b_51873);

    /** emit.e:626		cont21d(op, a, b, ii)*/
    _45cont21d(_op_51869, _a_51872, _b_51873, _ii_51871);

    /** emit.e:627	end procedure*/
    return;
    ;
}


object _45good_string(object _elements_51878)
{
    object _obj_51879 = NOVALUE;
    object _ep_51881 = NOVALUE;
    object _e_51883 = NOVALUE;
    object _element_vals_51884 = NOVALUE;
    object _26554 = NOVALUE;
    object _26553 = NOVALUE;
    object _26552 = NOVALUE;
    object _26551 = NOVALUE;
    object _26550 = NOVALUE;
    object _26549 = NOVALUE;
    object _26548 = NOVALUE;
    object _26547 = NOVALUE;
    object _26546 = NOVALUE;
    object _26545 = NOVALUE;
    object _26544 = NOVALUE;
    object _26542 = NOVALUE;
    object _26539 = NOVALUE;
    object _26538 = NOVALUE;
    object _26536 = NOVALUE;
    object _26535 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:634		sequence element_vals*/

    /** emit.e:636		if TRANSLATE and length(elements) > 10000 then*/
    if (_12TRANSLATE_19834 == 0) {
        goto L1; // [9] 31
    }
    if (IS_SEQUENCE(_elements_51878)){
            _26536 = SEQ_PTR(_elements_51878)->length;
    }
    else {
        _26536 = 1;
    }
    _26538 = (_26536 > 10000LL);
    _26536 = NOVALUE;
    if (_26538 == 0)
    {
        DeRef(_26538);
        _26538 = NOVALUE;
        goto L1; // [21] 31
    }
    else{
        DeRef(_26538);
        _26538 = NOVALUE;
    }

    /** emit.e:637			return -1 -- A huge string might upset the C compiler.*/
    DeRefDS(_elements_51878);
    DeRef(_obj_51879);
    DeRef(_element_vals_51884);
    return -1LL;
L1: 

    /** emit.e:639		element_vals = {}*/
    RefDS(_22024);
    DeRef(_element_vals_51884);
    _element_vals_51884 = _22024;

    /** emit.e:640		for i = 1 to length(elements) do*/
    if (IS_SEQUENCE(_elements_51878)){
            _26539 = SEQ_PTR(_elements_51878)->length;
    }
    else {
        _26539 = 1;
    }
    {
        object _i_51892;
        _i_51892 = 1LL;
L2: 
        if (_i_51892 > _26539){
            goto L3; // [43] 183
        }

        /** emit.e:641			ep = elements[i]*/
        _2 = (object)SEQ_PTR(_elements_51878);
        _ep_51881 = (object)*(((s1_ptr)_2)->base + _i_51892);
        if (!IS_ATOM_INT(_ep_51881)){
            _ep_51881 = (object)DBL_PTR(_ep_51881)->dbl;
        }

        /** emit.e:642			if ep < 1 then*/
        if (_ep_51881 >= 1LL)
        goto L4; // [60] 71

        /** emit.e:644				return -1*/
        DeRefDS(_elements_51878);
        DeRef(_obj_51879);
        DeRef(_element_vals_51884);
        return -1LL;
L4: 

        /** emit.e:646			e = ep*/
        _e_51883 = _ep_51881;

        /** emit.e:647			obj = SymTab[e][S_OBJ]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26542 = (object)*(((s1_ptr)_2)->base + _e_51883);
        DeRef(_obj_51879);
        _2 = (object)SEQ_PTR(_26542);
        _obj_51879 = (object)*(((s1_ptr)_2)->base + 1LL);
        Ref(_obj_51879);
        _26542 = NOVALUE;

        /** emit.e:648			if SymTab[e][S_MODE] = M_CONSTANT and*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26544 = (object)*(((s1_ptr)_2)->base + _e_51883);
        _2 = (object)SEQ_PTR(_26544);
        _26545 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26544 = NOVALUE;
        if (IS_ATOM_INT(_26545)) {
            _26546 = (_26545 == 2LL);
        }
        else {
            _26546 = binary_op(EQUALS, _26545, 2LL);
        }
        _26545 = NOVALUE;
        if (IS_ATOM_INT(_26546)) {
            if (_26546 == 0) {
                DeRef(_26547);
                _26547 = 0;
                goto L5; // [112] 123
            }
        }
        else {
            if (DBL_PTR(_26546)->dbl == 0.0) {
                DeRef(_26547);
                _26547 = 0;
                goto L5; // [112] 123
            }
        }
        if (IS_ATOM_INT(_obj_51879))
        _26548 = 1;
        else if (IS_ATOM_DBL(_obj_51879))
        _26548 = IS_ATOM_INT(DoubleToInt(_obj_51879));
        else
        _26548 = 0;
        DeRef(_26547);
        _26547 = (_26548 != 0);
L5: 
        if (_26547 == 0) {
            goto L6; // [123] 169
        }
        _26550 = (_12TRANSLATE_19834 == 0);
        if (_26550 != 0) {
            DeRef(_26551);
            _26551 = 1;
            goto L7; // [132] 156
        }
        if (IS_ATOM_INT(_obj_51879)) {
            _26552 = (_obj_51879 >= 1LL);
        }
        else {
            _26552 = binary_op(GREATEREQ, _obj_51879, 1LL);
        }
        if (IS_ATOM_INT(_26552)) {
            if (_26552 == 0) {
                DeRef(_26553);
                _26553 = 0;
                goto L8; // [140] 152
            }
        }
        else {
            if (DBL_PTR(_26552)->dbl == 0.0) {
                DeRef(_26553);
                _26553 = 0;
                goto L8; // [140] 152
            }
        }
        if (IS_ATOM_INT(_obj_51879)) {
            _26554 = (_obj_51879 <= 255LL);
        }
        else {
            _26554 = binary_op(LESSEQ, _obj_51879, 255LL);
        }
        DeRef(_26553);
        if (IS_ATOM_INT(_26554))
        _26553 = (_26554 != 0);
        else
        _26553 = DBL_PTR(_26554)->dbl != 0.0;
L8: 
        DeRef(_26551);
        _26551 = (_26553 != 0);
L7: 
        if (_26551 == 0)
        {
            _26551 = NOVALUE;
            goto L6; // [157] 169
        }
        else{
            _26551 = NOVALUE;
        }

        /** emit.e:653				element_vals = prepend(element_vals, obj)*/
        Ref(_obj_51879);
        Prepend(&_element_vals_51884, _element_vals_51884, _obj_51879);
        goto L9; // [166] 176
L6: 

        /** emit.e:655				return -1*/
        DeRefDS(_elements_51878);
        DeRef(_obj_51879);
        DeRef(_element_vals_51884);
        DeRef(_26552);
        _26552 = NOVALUE;
        DeRef(_26554);
        _26554 = NOVALUE;
        DeRef(_26550);
        _26550 = NOVALUE;
        DeRef(_26546);
        _26546 = NOVALUE;
        return -1LL;
L9: 

        /** emit.e:657		end for*/
        _i_51892 = _i_51892 + 1LL;
        goto L2; // [178] 50
L3: 
        ;
    }

    /** emit.e:658		return element_vals*/
    DeRefDS(_elements_51878);
    DeRef(_obj_51879);
    DeRef(_26552);
    _26552 = NOVALUE;
    DeRef(_26554);
    _26554 = NOVALUE;
    DeRef(_26550);
    _26550 = NOVALUE;
    DeRef(_26546);
    _26546 = NOVALUE;
    return _element_vals_51884;
    ;
}


object _45Last_op()
{
    object _0, _1, _2;
    

    /** emit.e:664		return last_op*/
    return _45last_op_51919;
    ;
}


object _45Last_pc()
{
    object _0, _1, _2;
    

    /** emit.e:668		return last_pc*/
    return _45last_pc_51920;
    ;
}


void _45move_last_pc(object _amount_51927)
{
    object _0, _1, _2;
    

    /** emit.e:672		if last_pc > 0 then*/
    if (_45last_pc_51920 <= 0LL)
    goto L1; // [7] 20

    /** emit.e:673			last_pc += amount*/
    _45last_pc_51920 = _45last_pc_51920 + _amount_51927;
L1: 

    /** emit.e:675	end procedure*/
    return;
    ;
}


void _45clear_last()
{
    object _0, _1, _2;
    

    /** emit.e:678		last_op = 0*/
    _45last_op_51919 = 0LL;

    /** emit.e:679		last_pc = 0*/
    _45last_pc_51920 = 0LL;

    /** emit.e:680	end procedure*/
    return;
    ;
}


void _45clear_op()
{
    object _0, _1, _2;
    

    /** emit.e:683		previous_op = -1*/
    _12previous_op_20325 = -1LL;

    /** emit.e:684		assignable = FALSE*/
    _45assignable_51038 = _9FALSE_444;

    /** emit.e:685	end procedure*/
    return;
    ;
}


void _45inlined_function()
{
    object _0, _1, _2;
    

    /** emit.e:689		previous_op = PROC*/
    _12previous_op_20325 = 27LL;

    /** emit.e:690		assignable = TRUE*/
    _45assignable_51038 = _9TRUE_446;

    /** emit.e:691		inlined = TRUE*/
    _45inlined_51938 = _9TRUE_446;

    /** emit.e:692	end procedure*/
    return;
    ;
}


void _45add_inline_target(object _pc_51949)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_51949)) {
        _1 = (object)(DBL_PTR(_pc_51949)->dbl);
        DeRefDS(_pc_51949);
        _pc_51949 = _1;
    }

    /** emit.e:696		inlined_targets &= pc*/
    Append(&_45inlined_targets_51946, _45inlined_targets_51946, _pc_51949);

    /** emit.e:697	end procedure*/
    return;
    ;
}


void _45clear_inline_targets()
{
    object _0, _1, _2;
    

    /** emit.e:700		inlined_targets = {}*/
    RefDS(_22024);
    DeRefi(_45inlined_targets_51946);
    _45inlined_targets_51946 = _22024;

    /** emit.e:701	end procedure*/
    return;
    ;
}


void _45emit_inline(object _code_51955)
{
    object _0, _1, _2;
    

    /** emit.e:704		last_pc = 0*/
    _45last_pc_51920 = 0LL;

    /** emit.e:705		last_op = 0*/
    _45last_op_51919 = 0LL;

    /** emit.e:706		Code &= code*/
    Concat((object_ptr)&_12Code_20315, _12Code_20315, _code_51955);

    /** emit.e:707	end procedure*/
    DeRefDS(_code_51955);
    return;
    ;
}


void _45emit_op(object _op_51960)
{
    object _a_51962 = NOVALUE;
    object _b_51963 = NOVALUE;
    object _c_51964 = NOVALUE;
    object _d_51965 = NOVALUE;
    object _source_51966 = NOVALUE;
    object _target_51967 = NOVALUE;
    object _subsym_51968 = NOVALUE;
    object _lhs_var_51970 = NOVALUE;
    object _ib_51971 = NOVALUE;
    object _ic_51972 = NOVALUE;
    object _n_51973 = NOVALUE;
    object _obj_51974 = NOVALUE;
    object _elements_51975 = NOVALUE;
    object _element_vals_51976 = NOVALUE;
    object _last_pc_backup_51977 = NOVALUE;
    object _last_op_backup_51978 = NOVALUE;
    object _temp_51987 = NOVALUE;
    object _real_op_52287 = NOVALUE;
    object _ref_52294 = NOVALUE;
    object _paths_52324 = NOVALUE;
    object _if_code_52404 = NOVALUE;
    object _if_code_52443 = NOVALUE;
    object _Top_inlined_Top_at_5482_53062 = NOVALUE;
    object _element_53133 = NOVALUE;
    object _Top_inlined_Top_at_7037_53280 = NOVALUE;
    object _31791 = NOVALUE;
    object _31790 = NOVALUE;
    object _27154 = NOVALUE;
    object _27153 = NOVALUE;
    object _27152 = NOVALUE;
    object _27148 = NOVALUE;
    object _27145 = NOVALUE;
    object _27143 = NOVALUE;
    object _27137 = NOVALUE;
    object _27136 = NOVALUE;
    object _27135 = NOVALUE;
    object _27133 = NOVALUE;
    object _27131 = NOVALUE;
    object _27130 = NOVALUE;
    object _27129 = NOVALUE;
    object _27128 = NOVALUE;
    object _27127 = NOVALUE;
    object _27126 = NOVALUE;
    object _27125 = NOVALUE;
    object _27124 = NOVALUE;
    object _27123 = NOVALUE;
    object _27122 = NOVALUE;
    object _27121 = NOVALUE;
    object _27119 = NOVALUE;
    object _27118 = NOVALUE;
    object _27117 = NOVALUE;
    object _27115 = NOVALUE;
    object _27114 = NOVALUE;
    object _27113 = NOVALUE;
    object _27112 = NOVALUE;
    object _27111 = NOVALUE;
    object _27110 = NOVALUE;
    object _27109 = NOVALUE;
    object _27108 = NOVALUE;
    object _27107 = NOVALUE;
    object _27104 = NOVALUE;
    object _27101 = NOVALUE;
    object _27100 = NOVALUE;
    object _27099 = NOVALUE;
    object _27098 = NOVALUE;
    object _27096 = NOVALUE;
    object _27094 = NOVALUE;
    object _27082 = NOVALUE;
    object _27074 = NOVALUE;
    object _27071 = NOVALUE;
    object _27070 = NOVALUE;
    object _27069 = NOVALUE;
    object _27068 = NOVALUE;
    object _27065 = NOVALUE;
    object _27064 = NOVALUE;
    object _27063 = NOVALUE;
    object _27062 = NOVALUE;
    object _27061 = NOVALUE;
    object _27060 = NOVALUE;
    object _27059 = NOVALUE;
    object _27058 = NOVALUE;
    object _27057 = NOVALUE;
    object _27056 = NOVALUE;
    object _27055 = NOVALUE;
    object _27053 = NOVALUE;
    object _27049 = NOVALUE;
    object _27048 = NOVALUE;
    object _27047 = NOVALUE;
    object _27046 = NOVALUE;
    object _27045 = NOVALUE;
    object _27044 = NOVALUE;
    object _27043 = NOVALUE;
    object _27042 = NOVALUE;
    object _27041 = NOVALUE;
    object _27040 = NOVALUE;
    object _27039 = NOVALUE;
    object _27037 = NOVALUE;
    object _27032 = NOVALUE;
    object _27031 = NOVALUE;
    object _27029 = NOVALUE;
    object _27028 = NOVALUE;
    object _27027 = NOVALUE;
    object _27025 = NOVALUE;
    object _27022 = NOVALUE;
    object _27018 = NOVALUE;
    object _27015 = NOVALUE;
    object _27014 = NOVALUE;
    object _27013 = NOVALUE;
    object _27012 = NOVALUE;
    object _27011 = NOVALUE;
    object _27010 = NOVALUE;
    object _27008 = NOVALUE;
    object _27007 = NOVALUE;
    object _27005 = NOVALUE;
    object _27004 = NOVALUE;
    object _27003 = NOVALUE;
    object _27002 = NOVALUE;
    object _27001 = NOVALUE;
    object _27000 = NOVALUE;
    object _26999 = NOVALUE;
    object _26998 = NOVALUE;
    object _26997 = NOVALUE;
    object _26996 = NOVALUE;
    object _26994 = NOVALUE;
    object _26993 = NOVALUE;
    object _26992 = NOVALUE;
    object _26991 = NOVALUE;
    object _26990 = NOVALUE;
    object _26989 = NOVALUE;
    object _26988 = NOVALUE;
    object _26987 = NOVALUE;
    object _26986 = NOVALUE;
    object _26985 = NOVALUE;
    object _26984 = NOVALUE;
    object _26983 = NOVALUE;
    object _26982 = NOVALUE;
    object _26981 = NOVALUE;
    object _26980 = NOVALUE;
    object _26978 = NOVALUE;
    object _26975 = NOVALUE;
    object _26974 = NOVALUE;
    object _26973 = NOVALUE;
    object _26972 = NOVALUE;
    object _26971 = NOVALUE;
    object _26970 = NOVALUE;
    object _26969 = NOVALUE;
    object _26968 = NOVALUE;
    object _26967 = NOVALUE;
    object _26966 = NOVALUE;
    object _26965 = NOVALUE;
    object _26964 = NOVALUE;
    object _26963 = NOVALUE;
    object _26962 = NOVALUE;
    object _26961 = NOVALUE;
    object _26959 = NOVALUE;
    object _26955 = NOVALUE;
    object _26953 = NOVALUE;
    object _26952 = NOVALUE;
    object _26950 = NOVALUE;
    object _26948 = NOVALUE;
    object _26946 = NOVALUE;
    object _26945 = NOVALUE;
    object _26943 = NOVALUE;
    object _26942 = NOVALUE;
    object _26941 = NOVALUE;
    object _26940 = NOVALUE;
    object _26939 = NOVALUE;
    object _26938 = NOVALUE;
    object _26937 = NOVALUE;
    object _26936 = NOVALUE;
    object _26935 = NOVALUE;
    object _26934 = NOVALUE;
    object _26933 = NOVALUE;
    object _26932 = NOVALUE;
    object _26931 = NOVALUE;
    object _26930 = NOVALUE;
    object _26929 = NOVALUE;
    object _26928 = NOVALUE;
    object _26927 = NOVALUE;
    object _26926 = NOVALUE;
    object _26925 = NOVALUE;
    object _26923 = NOVALUE;
    object _26921 = NOVALUE;
    object _26920 = NOVALUE;
    object _26918 = NOVALUE;
    object _26915 = NOVALUE;
    object _26914 = NOVALUE;
    object _26912 = NOVALUE;
    object _26911 = NOVALUE;
    object _26910 = NOVALUE;
    object _26908 = NOVALUE;
    object _26900 = NOVALUE;
    object _26899 = NOVALUE;
    object _26898 = NOVALUE;
    object _26897 = NOVALUE;
    object _26896 = NOVALUE;
    object _26895 = NOVALUE;
    object _26894 = NOVALUE;
    object _26893 = NOVALUE;
    object _26892 = NOVALUE;
    object _26891 = NOVALUE;
    object _26890 = NOVALUE;
    object _26889 = NOVALUE;
    object _26888 = NOVALUE;
    object _26887 = NOVALUE;
    object _26886 = NOVALUE;
    object _26885 = NOVALUE;
    object _26884 = NOVALUE;
    object _26883 = NOVALUE;
    object _26882 = NOVALUE;
    object _26881 = NOVALUE;
    object _26880 = NOVALUE;
    object _26879 = NOVALUE;
    object _26878 = NOVALUE;
    object _26877 = NOVALUE;
    object _26871 = NOVALUE;
    object _26870 = NOVALUE;
    object _26867 = NOVALUE;
    object _26864 = NOVALUE;
    object _26863 = NOVALUE;
    object _26862 = NOVALUE;
    object _26861 = NOVALUE;
    object _26860 = NOVALUE;
    object _26859 = NOVALUE;
    object _26858 = NOVALUE;
    object _26857 = NOVALUE;
    object _26856 = NOVALUE;
    object _26855 = NOVALUE;
    object _26853 = NOVALUE;
    object _26852 = NOVALUE;
    object _26851 = NOVALUE;
    object _26849 = NOVALUE;
    object _26847 = NOVALUE;
    object _26846 = NOVALUE;
    object _26845 = NOVALUE;
    object _26844 = NOVALUE;
    object _26843 = NOVALUE;
    object _26842 = NOVALUE;
    object _26841 = NOVALUE;
    object _26840 = NOVALUE;
    object _26839 = NOVALUE;
    object _26838 = NOVALUE;
    object _26836 = NOVALUE;
    object _26835 = NOVALUE;
    object _26833 = NOVALUE;
    object _26832 = NOVALUE;
    object _26831 = NOVALUE;
    object _26830 = NOVALUE;
    object _26829 = NOVALUE;
    object _26827 = NOVALUE;
    object _26826 = NOVALUE;
    object _26825 = NOVALUE;
    object _26824 = NOVALUE;
    object _26823 = NOVALUE;
    object _26822 = NOVALUE;
    object _26821 = NOVALUE;
    object _26820 = NOVALUE;
    object _26818 = NOVALUE;
    object _26817 = NOVALUE;
    object _26816 = NOVALUE;
    object _26815 = NOVALUE;
    object _26814 = NOVALUE;
    object _26812 = NOVALUE;
    object _26811 = NOVALUE;
    object _26809 = NOVALUE;
    object _26808 = NOVALUE;
    object _26807 = NOVALUE;
    object _26806 = NOVALUE;
    object _26805 = NOVALUE;
    object _26803 = NOVALUE;
    object _26801 = NOVALUE;
    object _26799 = NOVALUE;
    object _26798 = NOVALUE;
    object _26796 = NOVALUE;
    object _26795 = NOVALUE;
    object _26794 = NOVALUE;
    object _26793 = NOVALUE;
    object _26792 = NOVALUE;
    object _26791 = NOVALUE;
    object _26790 = NOVALUE;
    object _26789 = NOVALUE;
    object _26788 = NOVALUE;
    object _26787 = NOVALUE;
    object _26786 = NOVALUE;
    object _26785 = NOVALUE;
    object _26784 = NOVALUE;
    object _26783 = NOVALUE;
    object _26782 = NOVALUE;
    object _26781 = NOVALUE;
    object _26780 = NOVALUE;
    object _26777 = NOVALUE;
    object _26776 = NOVALUE;
    object _26774 = NOVALUE;
    object _26773 = NOVALUE;
    object _26772 = NOVALUE;
    object _26771 = NOVALUE;
    object _26770 = NOVALUE;
    object _26768 = NOVALUE;
    object _26766 = NOVALUE;
    object _26765 = NOVALUE;
    object _26764 = NOVALUE;
    object _26763 = NOVALUE;
    object _26762 = NOVALUE;
    object _26761 = NOVALUE;
    object _26760 = NOVALUE;
    object _26759 = NOVALUE;
    object _26758 = NOVALUE;
    object _26755 = NOVALUE;
    object _26754 = NOVALUE;
    object _26752 = NOVALUE;
    object _26751 = NOVALUE;
    object _26750 = NOVALUE;
    object _26749 = NOVALUE;
    object _26748 = NOVALUE;
    object _26745 = NOVALUE;
    object _26744 = NOVALUE;
    object _26743 = NOVALUE;
    object _26742 = NOVALUE;
    object _26741 = NOVALUE;
    object _26740 = NOVALUE;
    object _26739 = NOVALUE;
    object _26734 = NOVALUE;
    object _26733 = NOVALUE;
    object _26732 = NOVALUE;
    object _26730 = NOVALUE;
    object _26729 = NOVALUE;
    object _26727 = NOVALUE;
    object _26726 = NOVALUE;
    object _26721 = NOVALUE;
    object _26720 = NOVALUE;
    object _26719 = NOVALUE;
    object _26718 = NOVALUE;
    object _26717 = NOVALUE;
    object _26711 = NOVALUE;
    object _26710 = NOVALUE;
    object _26708 = NOVALUE;
    object _26707 = NOVALUE;
    object _26706 = NOVALUE;
    object _26705 = NOVALUE;
    object _26704 = NOVALUE;
    object _26703 = NOVALUE;
    object _26702 = NOVALUE;
    object _26701 = NOVALUE;
    object _26700 = NOVALUE;
    object _26699 = NOVALUE;
    object _26698 = NOVALUE;
    object _26696 = NOVALUE;
    object _26695 = NOVALUE;
    object _26694 = NOVALUE;
    object _26693 = NOVALUE;
    object _26692 = NOVALUE;
    object _26691 = NOVALUE;
    object _26690 = NOVALUE;
    object _26689 = NOVALUE;
    object _26688 = NOVALUE;
    object _26687 = NOVALUE;
    object _26686 = NOVALUE;
    object _26685 = NOVALUE;
    object _26684 = NOVALUE;
    object _26683 = NOVALUE;
    object _26681 = NOVALUE;
    object _26680 = NOVALUE;
    object _26679 = NOVALUE;
    object _26678 = NOVALUE;
    object _26675 = NOVALUE;
    object _26674 = NOVALUE;
    object _26673 = NOVALUE;
    object _26672 = NOVALUE;
    object _26670 = NOVALUE;
    object _26669 = NOVALUE;
    object _26668 = NOVALUE;
    object _26667 = NOVALUE;
    object _26665 = NOVALUE;
    object _26664 = NOVALUE;
    object _26663 = NOVALUE;
    object _26662 = NOVALUE;
    object _26661 = NOVALUE;
    object _26660 = NOVALUE;
    object _26659 = NOVALUE;
    object _26658 = NOVALUE;
    object _26657 = NOVALUE;
    object _26656 = NOVALUE;
    object _26655 = NOVALUE;
    object _26654 = NOVALUE;
    object _26653 = NOVALUE;
    object _26652 = NOVALUE;
    object _26650 = NOVALUE;
    object _26649 = NOVALUE;
    object _26648 = NOVALUE;
    object _26647 = NOVALUE;
    object _26646 = NOVALUE;
    object _26644 = NOVALUE;
    object _26643 = NOVALUE;
    object _26642 = NOVALUE;
    object _26641 = NOVALUE;
    object _26640 = NOVALUE;
    object _26636 = NOVALUE;
    object _26635 = NOVALUE;
    object _26634 = NOVALUE;
    object _26633 = NOVALUE;
    object _26632 = NOVALUE;
    object _26630 = NOVALUE;
    object _26629 = NOVALUE;
    object _26628 = NOVALUE;
    object _26627 = NOVALUE;
    object _26626 = NOVALUE;
    object _26625 = NOVALUE;
    object _26624 = NOVALUE;
    object _26623 = NOVALUE;
    object _26622 = NOVALUE;
    object _26621 = NOVALUE;
    object _26620 = NOVALUE;
    object _26619 = NOVALUE;
    object _26618 = NOVALUE;
    object _26617 = NOVALUE;
    object _26616 = NOVALUE;
    object _26615 = NOVALUE;
    object _26614 = NOVALUE;
    object _26613 = NOVALUE;
    object _26611 = NOVALUE;
    object _26610 = NOVALUE;
    object _26609 = NOVALUE;
    object _26608 = NOVALUE;
    object _26607 = NOVALUE;
    object _26606 = NOVALUE;
    object _26605 = NOVALUE;
    object _26604 = NOVALUE;
    object _26603 = NOVALUE;
    object _26601 = NOVALUE;
    object _26600 = NOVALUE;
    object _26599 = NOVALUE;
    object _26597 = NOVALUE;
    object _26596 = NOVALUE;
    object _26594 = NOVALUE;
    object _26592 = NOVALUE;
    object _26591 = NOVALUE;
    object _26590 = NOVALUE;
    object _26589 = NOVALUE;
    object _26588 = NOVALUE;
    object _26587 = NOVALUE;
    object _26583 = NOVALUE;
    object _26582 = NOVALUE;
    object _26581 = NOVALUE;
    object _26579 = NOVALUE;
    object _26578 = NOVALUE;
    object _26577 = NOVALUE;
    object _26576 = NOVALUE;
    object _26575 = NOVALUE;
    object _26574 = NOVALUE;
    object _26573 = NOVALUE;
    object _26572 = NOVALUE;
    object _26571 = NOVALUE;
    object _26570 = NOVALUE;
    object _26569 = NOVALUE;
    object _26568 = NOVALUE;
    object _26567 = NOVALUE;
    object _26566 = NOVALUE;
    object _26565 = NOVALUE;
    object _26560 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_op_51960)) {
        _1 = (object)(DBL_PTR(_op_51960)->dbl);
        DeRefDS(_op_51960);
        _op_51960 = _1;
    }

    /** emit.e:717		integer ib, ic, n*/

    /** emit.e:718		object obj*/

    /** emit.e:719		sequence elements*/

    /** emit.e:720		object element_vals*/

    /** emit.e:722		check_for_temps()*/
    _45check_for_temps();

    /** emit.e:723		integer last_pc_backup = last_pc*/
    _last_pc_backup_51977 = _45last_pc_51920;

    /** emit.e:724		integer last_op_backup = last_op*/
    _last_op_backup_51978 = _45last_op_51919;

    /** emit.e:726		last_op = op*/
    _45last_op_51919 = _op_51960;

    /** emit.e:727		last_pc = length(Code) + 1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _26560 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _26560 = 1;
    }
    _45last_pc_51920 = _26560 + 1;
    _26560 = NOVALUE;

    /** emit.e:729		switch op label "EMIT" do*/
    _0 = _op_51960;
    switch ( _0 ){ 

        /** emit.e:730		case ASSIGN then*/
        case 18:

        /** emit.e:731			sequence temp = {}*/
        RefDS(_22024);
        DeRef(_temp_51987);
        _temp_51987 = _22024;

        /** emit.e:732			if not TRANSLATE and*/
        _26565 = (_12TRANSLATE_19834 == 0);
        if (_26565 == 0) {
            goto L1; // [70] 202
        }
        _26567 = (_12previous_op_20325 == 92LL);
        if (_26567 != 0) {
            DeRef(_26568);
            _26568 = 1;
            goto L2; // [82] 98
        }
        _26569 = (_12previous_op_20325 == 25LL);
        _26568 = (_26569 != 0);
L2: 
        if (_26568 == 0)
        {
            _26568 = NOVALUE;
            goto L1; // [99] 202
        }
        else{
            _26568 = NOVALUE;
        }

        /** emit.e:736				while Code[$-1] = DEREF_TEMP and find( Code[$], derefs ) do*/
L3: 
        if (IS_SEQUENCE(_12Code_20315)){
                _26570 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26570 = 1;
        }
        _26571 = _26570 - 1LL;
        _26570 = NOVALUE;
        _2 = (object)SEQ_PTR(_12Code_20315);
        _26572 = (object)*(((s1_ptr)_2)->base + _26571);
        if (IS_ATOM_INT(_26572)) {
            _26573 = (_26572 == 208LL);
        }
        else {
            _26573 = binary_op(EQUALS, _26572, 208LL);
        }
        _26572 = NOVALUE;
        if (IS_ATOM_INT(_26573)) {
            if (_26573 == 0) {
                goto L4; // [126] 201
            }
        }
        else {
            if (DBL_PTR(_26573)->dbl == 0.0) {
                goto L4; // [126] 201
            }
        }
        if (IS_SEQUENCE(_12Code_20315)){
                _26575 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26575 = 1;
        }
        _2 = (object)SEQ_PTR(_12Code_20315);
        _26576 = (object)*(((s1_ptr)_2)->base + _26575);
        _26577 = find_from(_26576, _45derefs_51540, 1LL);
        _26576 = NOVALUE;
        if (_26577 == 0)
        {
            _26577 = NOVALUE;
            goto L4; // [147] 201
        }
        else{
            _26577 = NOVALUE;
        }

        /** emit.e:739					temp &= Code[$]*/
        if (IS_SEQUENCE(_12Code_20315)){
                _26578 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26578 = 1;
        }
        _2 = (object)SEQ_PTR(_12Code_20315);
        _26579 = (object)*(((s1_ptr)_2)->base + _26578);
        if (IS_SEQUENCE(_temp_51987) && IS_ATOM(_26579)) {
            Ref(_26579);
            Append(&_temp_51987, _temp_51987, _26579);
        }
        else if (IS_ATOM(_temp_51987) && IS_SEQUENCE(_26579)) {
        }
        else {
            Concat((object_ptr)&_temp_51987, _temp_51987, _26579);
        }
        _26579 = NOVALUE;

        /** emit.e:740					Code = remove( Code, length(Code)-1, length(Code) )*/
        if (IS_SEQUENCE(_12Code_20315)){
                _26581 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26581 = 1;
        }
        _26582 = _26581 - 1LL;
        _26581 = NOVALUE;
        if (IS_SEQUENCE(_12Code_20315)){
                _26583 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26583 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_12Code_20315);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_26582)) ? _26582 : (object)(DBL_PTR(_26582)->dbl);
            int stop = (IS_ATOM_INT(_26583)) ? _26583 : (object)(DBL_PTR(_26583)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_12Code_20315), start, &_12Code_20315 );
                }
                else Tail(SEQ_PTR(_12Code_20315), stop+1, &_12Code_20315);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_12Code_20315), start, &_12Code_20315);
            }
            else {
                assign_slice_seq = &assign_space;
                _12Code_20315 = Remove_elements(start, stop, (SEQ_PTR(_12Code_20315)->ref == 1));
            }
        }
        _26582 = NOVALUE;
        _26583 = NOVALUE;

        /** emit.e:741					emit_temp( temp, NEW_REFERENCE )*/
        RefDS(_temp_51987);
        _45emit_temp(_temp_51987, 1LL);

        /** emit.e:742				end while*/
        goto L3; // [198] 107
L4: 
L1: 

        /** emit.e:746			source = Pop()*/
        _source_51966 = _45Pop();
        if (!IS_ATOM_INT(_source_51966)) {
            _1 = (object)(DBL_PTR(_source_51966)->dbl);
            DeRefDS(_source_51966);
            _source_51966 = _1;
        }

        /** emit.e:747			target = Pop()*/
        _target_51967 = _45Pop();
        if (!IS_ATOM_INT(_target_51967)) {
            _1 = (object)(DBL_PTR(_target_51967)->dbl);
            DeRefDS(_target_51967);
            _target_51967 = _1;
        }

        /** emit.e:748			if assignable then*/
        if (_45assignable_51038 == 0)
        {
            goto L5; // [220] 601
        }
        else{
        }

        /** emit.e:750				if inlined then*/
        if (_45inlined_51938 == 0)
        {
            goto L6; // [227] 326
        }
        else{
        }

        /** emit.e:751					inlined = 0*/
        _45inlined_51938 = 0LL;

        /** emit.e:752					if length( inlined_targets ) then*/
        if (IS_SEQUENCE(_45inlined_targets_51946)){
                _26587 = SEQ_PTR(_45inlined_targets_51946)->length;
        }
        else {
            _26587 = 1;
        }
        if (_26587 == 0)
        {
            _26587 = NOVALUE;
            goto L7; // [242] 295
        }
        else{
            _26587 = NOVALUE;
        }

        /** emit.e:753						for i = 1 to length( inlined_targets ) do*/
        if (IS_SEQUENCE(_45inlined_targets_51946)){
                _26588 = SEQ_PTR(_45inlined_targets_51946)->length;
        }
        else {
            _26588 = 1;
        }
        {
            object _i_52030;
            _i_52030 = 1LL;
L8: 
            if (_i_52030 > _26588){
                goto L9; // [252] 280
            }

            /** emit.e:754							Code[inlined_targets[i]] = target*/
            _2 = (object)SEQ_PTR(_45inlined_targets_51946);
            _26589 = (object)*(((s1_ptr)_2)->base + _i_52030);
            _2 = (object)SEQ_PTR(_12Code_20315);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _12Code_20315 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _26589);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _target_51967;
            DeRef(_1);

            /** emit.e:755						end for*/
            _i_52030 = _i_52030 + 1LL;
            goto L8; // [275] 259
L9: 
            ;
        }

        /** emit.e:756						clear_inline_targets()*/

        /** emit.e:700		inlined_targets = {}*/
        RefDS(_22024);
        DeRefi(_45inlined_targets_51946);
        _45inlined_targets_51946 = _22024;

        /** emit.e:701	end procedure*/
        goto LA; // [291] 294
LA: 
L7: 

        /** emit.e:759					assignable = FALSE*/
        _45assignable_51038 = _9FALSE_444;

        /** emit.e:760					clear_last()*/

        /** emit.e:678		last_op = 0*/
        _45last_op_51919 = 0LL;

        /** emit.e:679		last_pc = 0*/
        _45last_pc_51920 = 0LL;

        /** emit.e:680	end procedure*/
        goto LB; // [316] 319
LB: 

        /** emit.e:761					break "EMIT"*/
        DeRef(_temp_51987);
        _temp_51987 = NOVALUE;
        goto LC; // [323] 7739
L6: 

        /** emit.e:764				clear_temp( Code[$] )*/
        if (IS_SEQUENCE(_12Code_20315)){
                _26590 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26590 = 1;
        }
        _2 = (object)SEQ_PTR(_12Code_20315);
        _26591 = (object)*(((s1_ptr)_2)->base + _26590);
        Ref(_26591);
        _45clear_temp(_26591);
        _26591 = NOVALUE;

        /** emit.e:765				Code = remove( Code, length( Code ) ) -- drop previous target*/
        if (IS_SEQUENCE(_12Code_20315)){
                _26592 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26592 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_12Code_20315);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_26592)) ? _26592 : (object)(DBL_PTR(_26592)->dbl);
            int stop = (IS_ATOM_INT(_26592)) ? _26592 : (object)(DBL_PTR(_26592)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_12Code_20315), start, &_12Code_20315 );
                }
                else Tail(SEQ_PTR(_12Code_20315), stop+1, &_12Code_20315);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_12Code_20315), start, &_12Code_20315);
            }
            else {
                assign_slice_seq = &assign_space;
                _12Code_20315 = Remove_elements(start, stop, (SEQ_PTR(_12Code_20315)->ref == 1));
            }
        }
        _26592 = NOVALUE;
        _26592 = NOVALUE;

        /** emit.e:766				op = previous_op -- keep same previous op*/
        _op_51960 = _12previous_op_20325;

        /** emit.e:767				if IsInteger(target) then*/
        _26594 = _45IsInteger(_target_51967);
        if (_26594 == 0) {
            DeRef(_26594);
            _26594 = NOVALUE;
            goto LD; // [372] 588
        }
        else {
            if (!IS_ATOM_INT(_26594) && DBL_PTR(_26594)->dbl == 0.0){
                DeRef(_26594);
                _26594 = NOVALUE;
                goto LD; // [372] 588
            }
            DeRef(_26594);
            _26594 = NOVALUE;
        }
        DeRef(_26594);
        _26594 = NOVALUE;

        /** emit.e:768					if previous_op = RHS_SUBS then*/
        if (_12previous_op_20325 != 25LL)
        goto LE; // [381] 412

        /** emit.e:769						op = RHS_SUBS_I*/
        _op_51960 = 114LL;

        /** emit.e:770						backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_12Code_20315)){
                _26596 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26596 = 1;
        }
        _26597 = _26596 - 2LL;
        _26596 = NOVALUE;
        _45backpatch(_26597, 114LL);
        _26597 = NOVALUE;
        goto LF; // [409] 587
LE: 

        /** emit.e:772					elsif previous_op = PLUS1 then*/
        if (_12previous_op_20325 != 93LL)
        goto L10; // [418] 449

        /** emit.e:773						op = PLUS1_I*/
        _op_51960 = 117LL;

        /** emit.e:774						backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_12Code_20315)){
                _26599 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26599 = 1;
        }
        _26600 = _26599 - 2LL;
        _26599 = NOVALUE;
        _45backpatch(_26600, 117LL);
        _26600 = NOVALUE;
        goto LF; // [446] 587
L10: 

        /** emit.e:776					elsif previous_op = PLUS or previous_op = MINUS then*/
        _26601 = (_12previous_op_20325 == 11LL);
        if (_26601 != 0) {
            goto L11; // [459] 476
        }
        _26603 = (_12previous_op_20325 == 10LL);
        if (_26603 == 0)
        {
            DeRef(_26603);
            _26603 = NOVALUE;
            goto L12; // [472] 567
        }
        else{
            DeRef(_26603);
            _26603 = NOVALUE;
        }
L11: 

        /** emit.e:777						if IsInteger(Code[$]) and*/
        if (IS_SEQUENCE(_12Code_20315)){
                _26604 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26604 = 1;
        }
        _2 = (object)SEQ_PTR(_12Code_20315);
        _26605 = (object)*(((s1_ptr)_2)->base + _26604);
        Ref(_26605);
        _26606 = _45IsInteger(_26605);
        _26605 = NOVALUE;
        if (IS_ATOM_INT(_26606)) {
            if (_26606 == 0) {
                goto LF; // [491] 587
            }
        }
        else {
            if (DBL_PTR(_26606)->dbl == 0.0) {
                goto LF; // [491] 587
            }
        }
        if (IS_SEQUENCE(_12Code_20315)){
                _26608 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26608 = 1;
        }
        _26609 = _26608 - 1LL;
        _26608 = NOVALUE;
        _2 = (object)SEQ_PTR(_12Code_20315);
        _26610 = (object)*(((s1_ptr)_2)->base + _26609);
        Ref(_26610);
        _26611 = _45IsInteger(_26610);
        _26610 = NOVALUE;
        if (_26611 == 0) {
            DeRef(_26611);
            _26611 = NOVALUE;
            goto LF; // [513] 587
        }
        else {
            if (!IS_ATOM_INT(_26611) && DBL_PTR(_26611)->dbl == 0.0){
                DeRef(_26611);
                _26611 = NOVALUE;
                goto LF; // [513] 587
            }
            DeRef(_26611);
            _26611 = NOVALUE;
        }
        DeRef(_26611);
        _26611 = NOVALUE;

        /** emit.e:779							if previous_op = PLUS then*/
        if (_12previous_op_20325 != 11LL)
        goto L13; // [522] 538

        /** emit.e:780								op = PLUS_I*/
        _op_51960 = 115LL;
        goto L14; // [535] 548
L13: 

        /** emit.e:782								op = MINUS_I*/
        _op_51960 = 116LL;
L14: 

        /** emit.e:784							backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_12Code_20315)){
                _26613 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26613 = 1;
        }
        _26614 = _26613 - 2LL;
        _26613 = NOVALUE;
        _45backpatch(_26614, _op_51960);
        _26614 = NOVALUE;
        goto LF; // [564] 587
L12: 

        /** emit.e:790						if IsInteger(source) then*/
        _26615 = _45IsInteger(_source_51966);
        if (_26615 == 0) {
            DeRef(_26615);
            _26615 = NOVALUE;
            goto L15; // [573] 586
        }
        else {
            if (!IS_ATOM_INT(_26615) && DBL_PTR(_26615)->dbl == 0.0){
                DeRef(_26615);
                _26615 = NOVALUE;
                goto L15; // [573] 586
            }
            DeRef(_26615);
            _26615 = NOVALUE;
        }
        DeRef(_26615);
        _26615 = NOVALUE;

        /** emit.e:791							op = ASSIGN_I -- fake to avoid subsequent check*/
        _op_51960 = 113LL;
L15: 
LF: 
LD: 

        /** emit.e:795				last_op = last_op_backup*/
        _45last_op_51919 = _last_op_backup_51978;

        /** emit.e:796				last_pc = last_pc_backup*/
        _45last_pc_51920 = _last_pc_backup_51977;
        goto L16; // [598] 743
L5: 

        /** emit.e:798				if IsInteger(source) and IsInteger(target) then*/
        _26616 = _45IsInteger(_source_51966);
        if (IS_ATOM_INT(_26616)) {
            if (_26616 == 0) {
                goto L17; // [607] 629
            }
        }
        else {
            if (DBL_PTR(_26616)->dbl == 0.0) {
                goto L17; // [607] 629
            }
        }
        _26618 = _45IsInteger(_target_51967);
        if (_26618 == 0) {
            DeRef(_26618);
            _26618 = NOVALUE;
            goto L17; // [616] 629
        }
        else {
            if (!IS_ATOM_INT(_26618) && DBL_PTR(_26618)->dbl == 0.0){
                DeRef(_26618);
                _26618 = NOVALUE;
                goto L17; // [616] 629
            }
            DeRef(_26618);
            _26618 = NOVALUE;
        }
        DeRef(_26618);
        _26618 = NOVALUE;

        /** emit.e:799					op = ASSIGN_I*/
        _op_51960 = 113LL;
L17: 

        /** emit.e:801				if source > 0 and target > 0 and*/
        _26619 = (_source_51966 > 0LL);
        if (_26619 == 0) {
            _26620 = 0;
            goto L18; // [635] 647
        }
        _26621 = (_target_51967 > 0LL);
        _26620 = (_26621 != 0);
L18: 
        if (_26620 == 0) {
            _26622 = 0;
            goto L19; // [647] 673
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26623 = (object)*(((s1_ptr)_2)->base + _source_51966);
        _2 = (object)SEQ_PTR(_26623);
        _26624 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26623 = NOVALUE;
        if (IS_ATOM_INT(_26624)) {
            _26625 = (_26624 == 2LL);
        }
        else {
            _26625 = binary_op(EQUALS, _26624, 2LL);
        }
        _26624 = NOVALUE;
        if (IS_ATOM_INT(_26625))
        _26622 = (_26625 != 0);
        else
        _26622 = DBL_PTR(_26625)->dbl != 0.0;
L19: 
        if (_26622 == 0) {
            goto L1A; // [673] 727
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26627 = (object)*(((s1_ptr)_2)->base + _target_51967);
        _2 = (object)SEQ_PTR(_26627);
        _26628 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26627 = NOVALUE;
        if (IS_ATOM_INT(_26628)) {
            _26629 = (_26628 == 2LL);
        }
        else {
            _26629 = binary_op(EQUALS, _26628, 2LL);
        }
        _26628 = NOVALUE;
        if (_26629 == 0) {
            DeRef(_26629);
            _26629 = NOVALUE;
            goto L1A; // [696] 727
        }
        else {
            if (!IS_ATOM_INT(_26629) && DBL_PTR(_26629)->dbl == 0.0){
                DeRef(_26629);
                _26629 = NOVALUE;
                goto L1A; // [696] 727
            }
            DeRef(_26629);
            _26629 = NOVALUE;
        }
        DeRef(_26629);
        _26629 = NOVALUE;

        /** emit.e:806					SymTab[target][S_OBJ] = SymTab[source][S_OBJ]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_target_51967 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26632 = (object)*(((s1_ptr)_2)->base + _source_51966);
        _2 = (object)SEQ_PTR(_26632);
        _26633 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26632 = NOVALUE;
        Ref(_26633);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26633;
        if( _1 != _26633 ){
            DeRef(_1);
        }
        _26633 = NOVALUE;
        _26630 = NOVALUE;
L1A: 

        /** emit.e:809				emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:810				emit_addr(source)*/
        _45emit_addr(_source_51966);

        /** emit.e:811				last_op = op*/
        _45last_op_51919 = _op_51960;
L16: 

        /** emit.e:814			assignable = FALSE*/
        _45assignable_51038 = _9FALSE_444;

        /** emit.e:815			emit_addr(target)*/
        _45emit_addr(_target_51967);

        /** emit.e:817			if length(temp) then*/
        if (IS_SEQUENCE(_temp_51987)){
                _26634 = SEQ_PTR(_temp_51987)->length;
        }
        else {
            _26634 = 1;
        }
        if (_26634 == 0)
        {
            _26634 = NOVALUE;
            goto L1B; // [760] 792
        }
        else{
            _26634 = NOVALUE;
        }

        /** emit.e:819				for i = 1 to length( temp ) do*/
        if (IS_SEQUENCE(_temp_51987)){
                _26635 = SEQ_PTR(_temp_51987)->length;
        }
        else {
            _26635 = 1;
        }
        {
            object _i_52133;
            _i_52133 = 1LL;
L1C: 
            if (_i_52133 > _26635){
                goto L1D; // [768] 791
            }

            /** emit.e:820					flush_temp( temp[i] )*/
            _2 = (object)SEQ_PTR(_temp_51987);
            _26636 = (object)*(((s1_ptr)_2)->base + _i_52133);
            Ref(_26636);
            _45flush_temp(_26636);
            _26636 = NOVALUE;

            /** emit.e:821				end for*/
            _i_52133 = _i_52133 + 1LL;
            goto L1C; // [786] 775
L1D: 
            ;
        }
L1B: 
        DeRef(_temp_51987);
        _temp_51987 = NOVALUE;
        goto LC; // [794] 7739

        /** emit.e:824		case RHS_SUBS then*/
        case 25:

        /** emit.e:825			b = Pop() -- subscript*/
        _b_51963 = _45Pop();
        if (!IS_ATOM_INT(_b_51963)) {
            _1 = (object)(DBL_PTR(_b_51963)->dbl);
            DeRefDS(_b_51963);
            _b_51963 = _1;
        }

        /** emit.e:826			c = Pop() -- sequence*/
        _c_51964 = _45Pop();
        if (!IS_ATOM_INT(_c_51964)) {
            _1 = (object)(DBL_PTR(_c_51964)->dbl);
            DeRefDS(_c_51964);
            _c_51964 = _1;
        }

        /** emit.e:827			target = NewTempSym() -- target*/
        _target_51967 = _53NewTempSym(0LL);
        if (!IS_ATOM_INT(_target_51967)) {
            _1 = (object)(DBL_PTR(_target_51967)->dbl);
            DeRefDS(_target_51967);
            _target_51967 = _1;
        }

        /** emit.e:828			if c < 0 or length(SymTab[c]) < S_VTYPE or SymTab[c][S_VTYPE] < 0 then -- forward reference*/
        _26640 = (_c_51964 < 0LL);
        if (_26640 != 0) {
            _26641 = 1;
            goto L1E; // [828] 851
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26642 = (object)*(((s1_ptr)_2)->base + _c_51964);
        if (IS_SEQUENCE(_26642)){
                _26643 = SEQ_PTR(_26642)->length;
        }
        else {
            _26643 = 1;
        }
        _26642 = NOVALUE;
        _26644 = (_26643 < 15LL);
        _26643 = NOVALUE;
        _26641 = (_26644 != 0);
L1E: 
        if (_26641 != 0) {
            goto L1F; // [851] 876
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26646 = (object)*(((s1_ptr)_2)->base + _c_51964);
        _2 = (object)SEQ_PTR(_26646);
        _26647 = (object)*(((s1_ptr)_2)->base + 15LL);
        _26646 = NOVALUE;
        if (IS_ATOM_INT(_26647)) {
            _26648 = (_26647 < 0LL);
        }
        else {
            _26648 = binary_op(LESS, _26647, 0LL);
        }
        _26647 = NOVALUE;
        if (_26648 == 0) {
            DeRef(_26648);
            _26648 = NOVALUE;
            goto L20; // [872] 888
        }
        else {
            if (!IS_ATOM_INT(_26648) && DBL_PTR(_26648)->dbl == 0.0){
                DeRef(_26648);
                _26648 = NOVALUE;
                goto L20; // [872] 888
            }
            DeRef(_26648);
            _26648 = NOVALUE;
        }
        DeRef(_26648);
        _26648 = NOVALUE;
L1F: 

        /** emit.e:830				op = RHS_SUBS_CHECK*/
        _op_51960 = 92LL;
        goto L21; // [885] 1049
L20: 

        /** emit.e:831			elsif SymTab[c][S_MODE] = M_NORMAL then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26649 = (object)*(((s1_ptr)_2)->base + _c_51964);
        _2 = (object)SEQ_PTR(_26649);
        _26650 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26649 = NOVALUE;
        if (binary_op_a(NOTEQ, _26650, 1LL)){
            _26650 = NOVALUE;
            goto L22; // [904] 991
        }
        _26650 = NOVALUE;

        /** emit.e:832				if SymTab[c][S_VTYPE] != sequence_type and*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26652 = (object)*(((s1_ptr)_2)->base + _c_51964);
        _2 = (object)SEQ_PTR(_26652);
        _26653 = (object)*(((s1_ptr)_2)->base + 15LL);
        _26652 = NOVALUE;
        if (IS_ATOM_INT(_26653)) {
            _26654 = (_26653 != _53sequence_type_46850);
        }
        else {
            _26654 = binary_op(NOTEQ, _26653, _53sequence_type_46850);
        }
        _26653 = NOVALUE;
        if (IS_ATOM_INT(_26654)) {
            if (_26654 == 0) {
                goto L21; // [928] 1049
            }
        }
        else {
            if (DBL_PTR(_26654)->dbl == 0.0) {
                goto L21; // [928] 1049
            }
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26656 = (object)*(((s1_ptr)_2)->base + _c_51964);
        _2 = (object)SEQ_PTR(_26656);
        _26657 = (object)*(((s1_ptr)_2)->base + 15LL);
        _26656 = NOVALUE;
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!IS_ATOM_INT(_26657)){
            _26658 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_26657)->dbl));
        }
        else{
            _26658 = (object)*(((s1_ptr)_2)->base + _26657);
        }
        _2 = (object)SEQ_PTR(_26658);
        _26659 = (object)*(((s1_ptr)_2)->base + 2LL);
        _26658 = NOVALUE;
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!IS_ATOM_INT(_26659)){
            _26660 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_26659)->dbl));
        }
        else{
            _26660 = (object)*(((s1_ptr)_2)->base + _26659);
        }
        _2 = (object)SEQ_PTR(_26660);
        _26661 = (object)*(((s1_ptr)_2)->base + 15LL);
        _26660 = NOVALUE;
        if (IS_ATOM_INT(_26661)) {
            _26662 = (_26661 != _53sequence_type_46850);
        }
        else {
            _26662 = binary_op(NOTEQ, _26661, _53sequence_type_46850);
        }
        _26661 = NOVALUE;
        if (_26662 == 0) {
            DeRef(_26662);
            _26662 = NOVALUE;
            goto L21; // [975] 1049
        }
        else {
            if (!IS_ATOM_INT(_26662) && DBL_PTR(_26662)->dbl == 0.0){
                DeRef(_26662);
                _26662 = NOVALUE;
                goto L21; // [975] 1049
            }
            DeRef(_26662);
            _26662 = NOVALUE;
        }
        DeRef(_26662);
        _26662 = NOVALUE;

        /** emit.e:835					op = RHS_SUBS_CHECK*/
        _op_51960 = 92LL;
        goto L21; // [988] 1049
L22: 

        /** emit.e:837			elsif SymTab[c][S_MODE] != M_CONSTANT or*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26663 = (object)*(((s1_ptr)_2)->base + _c_51964);
        _2 = (object)SEQ_PTR(_26663);
        _26664 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26663 = NOVALUE;
        if (IS_ATOM_INT(_26664)) {
            _26665 = (_26664 != 2LL);
        }
        else {
            _26665 = binary_op(NOTEQ, _26664, 2LL);
        }
        _26664 = NOVALUE;
        if (IS_ATOM_INT(_26665)) {
            if (_26665 != 0) {
                goto L23; // [1011] 1038
            }
        }
        else {
            if (DBL_PTR(_26665)->dbl != 0.0) {
                goto L23; // [1011] 1038
            }
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26667 = (object)*(((s1_ptr)_2)->base + _c_51964);
        _2 = (object)SEQ_PTR(_26667);
        _26668 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26667 = NOVALUE;
        _26669 = IS_SEQUENCE(_26668);
        _26668 = NOVALUE;
        _26670 = (_26669 == 0);
        _26669 = NOVALUE;
        if (_26670 == 0)
        {
            DeRef(_26670);
            _26670 = NOVALUE;
            goto L24; // [1034] 1048
        }
        else{
            DeRef(_26670);
            _26670 = NOVALUE;
        }
L23: 

        /** emit.e:839				op = RHS_SUBS_CHECK*/
        _op_51960 = 92LL;
L24: 
L21: 

        /** emit.e:841			emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:842			emit_addr(c)*/
        _45emit_addr(_c_51964);

        /** emit.e:843			emit_addr(b)*/
        _45emit_addr(_b_51963);

        /** emit.e:844			assignable = TRUE*/
        _45assignable_51038 = _9TRUE_446;

        /** emit.e:845			Push(target)*/
        _45Push(_target_51967);

        /** emit.e:846			emit_addr(target)*/
        _45emit_addr(_target_51967);

        /** emit.e:847			emit_temp(target, NEW_REFERENCE)*/
        _45emit_temp(_target_51967, 1LL);

        /** emit.e:848			current_sequence = append(current_sequence, target)*/
        Append(&_45current_sequence_51028, _45current_sequence_51028, _target_51967);

        /** emit.e:849			flush_temp( Code[$-2] )*/
        if (IS_SEQUENCE(_12Code_20315)){
                _26672 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26672 = 1;
        }
        _26673 = _26672 - 2LL;
        _26672 = NOVALUE;
        _2 = (object)SEQ_PTR(_12Code_20315);
        _26674 = (object)*(((s1_ptr)_2)->base + _26673);
        Ref(_26674);
        _45flush_temp(_26674);
        _26674 = NOVALUE;
        goto LC; // [1113] 7739

        /** emit.e:851		case PROC then -- procedure, function and type calls*/
        case 27:

        /** emit.e:853			assignable = FALSE -- assume for now*/
        _45assignable_51038 = _9FALSE_444;

        /** emit.e:854			subsym = op_info1*/
        _subsym_51968 = _45op_info1_51020;

        /** emit.e:855			n = SymTab[subsym][S_NUM_ARGS]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26675 = (object)*(((s1_ptr)_2)->base + _subsym_51968);
        _2 = (object)SEQ_PTR(_26675);
        if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
            _n_51973 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
        }
        else{
            _n_51973 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
        }
        if (!IS_ATOM_INT(_n_51973)){
            _n_51973 = (object)DBL_PTR(_n_51973)->dbl;
        }
        _26675 = NOVALUE;

        /** emit.e:857			if subsym = CurrentSub then*/
        if (_subsym_51968 != _12CurrentSub_20234)
        goto L25; // [1155] 1340

        /** emit.e:860				for i = cgi-n+1 to cgi do*/
        _26678 = _45cgi_51036 - _n_51973;
        if ((object)((uintptr_t)_26678 +(uintptr_t) HIGH_BITS) >= 0){
            _26678 = NewDouble((eudouble)_26678);
        }
        if (IS_ATOM_INT(_26678)) {
            _26679 = _26678 + 1;
            if (_26679 > MAXINT){
                _26679 = NewDouble((eudouble)_26679);
            }
        }
        else
        _26679 = binary_op(PLUS, 1, _26678);
        DeRef(_26678);
        _26678 = NOVALUE;
        _26680 = _45cgi_51036;
        {
            object _i_52219;
            Ref(_26679);
            _i_52219 = _26679;
L26: 
            if (binary_op_a(GREATER, _i_52219, _26680)){
                goto L27; // [1176] 1339
            }

            /** emit.e:861					if cg_stack[i] > 0 then -- if it's a forward reference, it's not a private*/
            _2 = (object)SEQ_PTR(_45cg_stack_51035);
            if (!IS_ATOM_INT(_i_52219)){
                _26681 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52219)->dbl));
            }
            else{
                _26681 = (object)*(((s1_ptr)_2)->base + _i_52219);
            }
            if (binary_op_a(LESSEQ, _26681, 0LL)){
                _26681 = NOVALUE;
                goto L28; // [1191] 1332
            }
            _26681 = NOVALUE;

            /** emit.e:862						if SymTab[cg_stack[i]][S_SCOPE] = SC_PRIVATE and*/
            _2 = (object)SEQ_PTR(_45cg_stack_51035);
            if (!IS_ATOM_INT(_i_52219)){
                _26683 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52219)->dbl));
            }
            else{
                _26683 = (object)*(((s1_ptr)_2)->base + _i_52219);
            }
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            if (!IS_ATOM_INT(_26683)){
                _26684 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_26683)->dbl));
            }
            else{
                _26684 = (object)*(((s1_ptr)_2)->base + _26683);
            }
            _2 = (object)SEQ_PTR(_26684);
            _26685 = (object)*(((s1_ptr)_2)->base + 4LL);
            _26684 = NOVALUE;
            if (IS_ATOM_INT(_26685)) {
                _26686 = (_26685 == 3LL);
            }
            else {
                _26686 = binary_op(EQUALS, _26685, 3LL);
            }
            _26685 = NOVALUE;
            if (IS_ATOM_INT(_26686)) {
                if (_26686 == 0) {
                    goto L29; // [1221] 1299
                }
            }
            else {
                if (DBL_PTR(_26686)->dbl == 0.0) {
                    goto L29; // [1221] 1299
                }
            }
            _2 = (object)SEQ_PTR(_45cg_stack_51035);
            if (!IS_ATOM_INT(_i_52219)){
                _26688 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52219)->dbl));
            }
            else{
                _26688 = (object)*(((s1_ptr)_2)->base + _i_52219);
            }
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            if (!IS_ATOM_INT(_26688)){
                _26689 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_26688)->dbl));
            }
            else{
                _26689 = (object)*(((s1_ptr)_2)->base + _26688);
            }
            _2 = (object)SEQ_PTR(_26689);
            _26690 = (object)*(((s1_ptr)_2)->base + 16LL);
            _26689 = NOVALUE;
            if (IS_ATOM_INT(_26690) && IS_ATOM_INT(_i_52219)) {
                _26691 = (_26690 < _i_52219);
            }
            else {
                _26691 = binary_op(LESS, _26690, _i_52219);
            }
            _26690 = NOVALUE;
            if (_26691 == 0) {
                DeRef(_26691);
                _26691 = NOVALUE;
                goto L29; // [1248] 1299
            }
            else {
                if (!IS_ATOM_INT(_26691) && DBL_PTR(_26691)->dbl == 0.0){
                    DeRef(_26691);
                    _26691 = NOVALUE;
                    goto L29; // [1248] 1299
                }
                DeRef(_26691);
                _26691 = NOVALUE;
            }
            DeRef(_26691);
            _26691 = NOVALUE;

            /** emit.e:865							emit_opcode(ASSIGN)*/
            _45emit_opcode(18LL);

            /** emit.e:866							emit_addr(cg_stack[i])*/
            _2 = (object)SEQ_PTR(_45cg_stack_51035);
            if (!IS_ATOM_INT(_i_52219)){
                _26692 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52219)->dbl));
            }
            else{
                _26692 = (object)*(((s1_ptr)_2)->base + _i_52219);
            }
            Ref(_26692);
            _45emit_addr(_26692);
            _26692 = NOVALUE;

            /** emit.e:867							cg_stack[i] = NewTempSym()*/
            _26693 = _53NewTempSym(0LL);
            _2 = (object)SEQ_PTR(_45cg_stack_51035);
            if (!IS_ATOM_INT(_i_52219))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52219)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _i_52219);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _26693;
            if( _1 != _26693 ){
                DeRef(_1);
            }
            _26693 = NOVALUE;

            /** emit.e:868							emit_addr(cg_stack[i])*/
            _2 = (object)SEQ_PTR(_45cg_stack_51035);
            if (!IS_ATOM_INT(_i_52219)){
                _26694 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52219)->dbl));
            }
            else{
                _26694 = (object)*(((s1_ptr)_2)->base + _i_52219);
            }
            Ref(_26694);
            _45emit_addr(_26694);
            _26694 = NOVALUE;

            /** emit.e:869							check_for_temps()*/
            _45check_for_temps();
            goto L2A; // [1296] 1331
L29: 

            /** emit.e:870						elsif sym_mode( cg_stack[i] ) = M_TEMP then*/
            _2 = (object)SEQ_PTR(_45cg_stack_51035);
            if (!IS_ATOM_INT(_i_52219)){
                _26695 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52219)->dbl));
            }
            else{
                _26695 = (object)*(((s1_ptr)_2)->base + _i_52219);
            }
            Ref(_26695);
            _26696 = _53sym_mode(_26695);
            _26695 = NOVALUE;
            if (binary_op_a(NOTEQ, _26696, 3LL)){
                DeRef(_26696);
                _26696 = NOVALUE;
                goto L2B; // [1313] 1330
            }
            DeRef(_26696);
            _26696 = NOVALUE;

            /** emit.e:871							emit_temp( cg_stack[i], NEW_REFERENCE )*/
            _2 = (object)SEQ_PTR(_45cg_stack_51035);
            if (!IS_ATOM_INT(_i_52219)){
                _26698 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52219)->dbl));
            }
            else{
                _26698 = (object)*(((s1_ptr)_2)->base + _i_52219);
            }
            Ref(_26698);
            _45emit_temp(_26698, 1LL);
            _26698 = NOVALUE;
L2B: 
L2A: 
L28: 

            /** emit.e:874				end for*/
            _0 = _i_52219;
            if (IS_ATOM_INT(_i_52219)) {
                _i_52219 = _i_52219 + 1LL;
                if ((object)((uintptr_t)_i_52219 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_52219 = NewDouble((eudouble)_i_52219);
                }
            }
            else {
                _i_52219 = binary_op_a(PLUS, _i_52219, 1LL);
            }
            DeRef(_0);
            goto L26; // [1334] 1183
L27: 
            ;
            DeRef(_i_52219);
        }
L25: 

        /** emit.e:877			if SymTab[subsym][S_DEPRECATED] then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26699 = (object)*(((s1_ptr)_2)->base + _subsym_51968);
        _2 = (object)SEQ_PTR(_26699);
        _26700 = (object)*(((s1_ptr)_2)->base + 30LL);
        _26699 = NOVALUE;
        if (_26700 == 0) {
            _26700 = NOVALUE;
            goto L2C; // [1354] 1383
        }
        else {
            if (!IS_ATOM_INT(_26700) && DBL_PTR(_26700)->dbl == 0.0){
                _26700 = NOVALUE;
                goto L2C; // [1354] 1383
            }
            _26700 = NOVALUE;
        }
        _26700 = NOVALUE;

        /** emit.e:878				Warning(327, deprecated_warning_flag, { SymTab[subsym][S_NAME] })*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26701 = (object)*(((s1_ptr)_2)->base + _subsym_51968);
        _2 = (object)SEQ_PTR(_26701);
        if (!IS_ATOM_INT(_12S_NAME_19864)){
            _26702 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
        }
        else{
            _26702 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
        }
        _26701 = NOVALUE;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_26702);
        ((intptr_t*)_2)[1] = _26702;
        _26703 = MAKE_SEQ(_1);
        _26702 = NOVALUE;
        _49Warning(327LL, 16384LL, _26703);
        _26703 = NOVALUE;
L2C: 

        /** emit.e:881			emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:882			emit_addr(subsym)*/
        _45emit_addr(_subsym_51968);

        /** emit.e:883			for i = cgi-n+1 to cgi do*/
        _26704 = _45cgi_51036 - _n_51973;
        if ((object)((uintptr_t)_26704 +(uintptr_t) HIGH_BITS) >= 0){
            _26704 = NewDouble((eudouble)_26704);
        }
        if (IS_ATOM_INT(_26704)) {
            _26705 = _26704 + 1;
            if (_26705 > MAXINT){
                _26705 = NewDouble((eudouble)_26705);
            }
        }
        else
        _26705 = binary_op(PLUS, 1, _26704);
        DeRef(_26704);
        _26704 = NOVALUE;
        _26706 = _45cgi_51036;
        {
            object _i_52266;
            Ref(_26705);
            _i_52266 = _26705;
L2D: 
            if (binary_op_a(GREATER, _i_52266, _26706)){
                goto L2E; // [1410] 1447
            }

            /** emit.e:884				emit_addr(cg_stack[i])*/
            _2 = (object)SEQ_PTR(_45cg_stack_51035);
            if (!IS_ATOM_INT(_i_52266)){
                _26707 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52266)->dbl));
            }
            else{
                _26707 = (object)*(((s1_ptr)_2)->base + _i_52266);
            }
            Ref(_26707);
            _45emit_addr(_26707);
            _26707 = NOVALUE;

            /** emit.e:885				emit_temp( cg_stack[i], NEW_REFERENCE )*/
            _2 = (object)SEQ_PTR(_45cg_stack_51035);
            if (!IS_ATOM_INT(_i_52266)){
                _26708 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52266)->dbl));
            }
            else{
                _26708 = (object)*(((s1_ptr)_2)->base + _i_52266);
            }
            Ref(_26708);
            _45emit_temp(_26708, 1LL);
            _26708 = NOVALUE;

            /** emit.e:886			end for*/
            _0 = _i_52266;
            if (IS_ATOM_INT(_i_52266)) {
                _i_52266 = _i_52266 + 1LL;
                if ((object)((uintptr_t)_i_52266 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_52266 = NewDouble((eudouble)_i_52266);
                }
            }
            else {
                _i_52266 = binary_op_a(PLUS, _i_52266, 1LL);
            }
            DeRef(_0);
            goto L2D; // [1442] 1417
L2E: 
            ;
            DeRef(_i_52266);
        }

        /** emit.e:888			cgi -= n*/
        _45cgi_51036 = _45cgi_51036 - _n_51973;

        /** emit.e:890			if SymTab[subsym][S_TOKEN] != PROC then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26710 = (object)*(((s1_ptr)_2)->base + _subsym_51968);
        _2 = (object)SEQ_PTR(_26710);
        if (!IS_ATOM_INT(_12S_TOKEN_19869)){
            _26711 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
        }
        else{
            _26711 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
        }
        _26710 = NOVALUE;
        if (binary_op_a(EQUALS, _26711, 27LL)){
            _26711 = NOVALUE;
            goto LC; // [1471] 7739
        }
        _26711 = NOVALUE;

        /** emit.e:891				assignable = TRUE*/
        _45assignable_51038 = _9TRUE_446;

        /** emit.e:892				c = NewTempSym() -- put final result in temp*/
        _c_51964 = _53NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_51964)) {
            _1 = (object)(DBL_PTR(_c_51964)->dbl);
            DeRefDS(_c_51964);
            _c_51964 = _1;
        }

        /** emit.e:893				emit_temp( c, NEW_REFERENCE )*/
        _45emit_temp(_c_51964, 1LL);

        /** emit.e:894				Push(c)*/
        _45Push(_c_51964);

        /** emit.e:896				emit_addr(c)*/
        _45emit_addr(_c_51964);
        goto LC; // [1507] 7739

        /** emit.e:900		case PROC_FORWARD, FUNC_FORWARD then*/
        case 195:
        case 196:

        /** emit.e:901			assignable = FALSE -- assume for now*/
        _45assignable_51038 = _9FALSE_444;

        /** emit.e:902			integer real_op*/

        /** emit.e:903			if op = PROC_FORWARD then*/
        if (_op_51960 != 195LL)
        goto L2F; // [1528] 1544

        /** emit.e:904				real_op = PROC*/
        _real_op_52287 = 27LL;
        goto L30; // [1541] 1554
L2F: 

        /** emit.e:906				real_op = FUNC*/
        _real_op_52287 = 501LL;
L30: 

        /** emit.e:908			integer ref*/

        /** emit.e:909			ref = new_forward_reference( real_op, op_info1, real_op )*/
        _ref_52294 = _42new_forward_reference(_real_op_52287, _45op_info1_51020, _real_op_52287);
        if (!IS_ATOM_INT(_ref_52294)) {
            _1 = (object)(DBL_PTR(_ref_52294)->dbl);
            DeRefDS(_ref_52294);
            _ref_52294 = _1;
        }

        /** emit.e:910			n = Pop() -- number of known args*/
        _n_51973 = _45Pop();
        if (!IS_ATOM_INT(_n_51973)) {
            _1 = (object)(DBL_PTR(_n_51973)->dbl);
            DeRefDS(_n_51973);
            _n_51973 = _1;
        }

        /** emit.e:912			emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:913			emit_addr(ref)*/
        _45emit_addr(_ref_52294);

        /** emit.e:914			emit_addr( n ) -- this changes to be the "next" instruction*/
        _45emit_addr(_n_51973);

        /** emit.e:915			for i = cgi-n+1 to cgi do*/
        _26717 = _45cgi_51036 - _n_51973;
        if ((object)((uintptr_t)_26717 +(uintptr_t) HIGH_BITS) >= 0){
            _26717 = NewDouble((eudouble)_26717);
        }
        if (IS_ATOM_INT(_26717)) {
            _26718 = _26717 + 1;
            if (_26718 > MAXINT){
                _26718 = NewDouble((eudouble)_26718);
            }
        }
        else
        _26718 = binary_op(PLUS, 1, _26717);
        DeRef(_26717);
        _26717 = NOVALUE;
        _26719 = _45cgi_51036;
        {
            object _i_52299;
            Ref(_26718);
            _i_52299 = _26718;
L31: 
            if (binary_op_a(GREATER, _i_52299, _26719)){
                goto L32; // [1609] 1646
            }

            /** emit.e:916				emit_addr(cg_stack[i])*/
            _2 = (object)SEQ_PTR(_45cg_stack_51035);
            if (!IS_ATOM_INT(_i_52299)){
                _26720 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52299)->dbl));
            }
            else{
                _26720 = (object)*(((s1_ptr)_2)->base + _i_52299);
            }
            Ref(_26720);
            _45emit_addr(_26720);
            _26720 = NOVALUE;

            /** emit.e:917				emit_temp( cg_stack[i], NEW_REFERENCE )*/
            _2 = (object)SEQ_PTR(_45cg_stack_51035);
            if (!IS_ATOM_INT(_i_52299)){
                _26721 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52299)->dbl));
            }
            else{
                _26721 = (object)*(((s1_ptr)_2)->base + _i_52299);
            }
            Ref(_26721);
            _45emit_temp(_26721, 1LL);
            _26721 = NOVALUE;

            /** emit.e:918			end for*/
            _0 = _i_52299;
            if (IS_ATOM_INT(_i_52299)) {
                _i_52299 = _i_52299 + 1LL;
                if ((object)((uintptr_t)_i_52299 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_52299 = NewDouble((eudouble)_i_52299);
                }
            }
            else {
                _i_52299 = binary_op_a(PLUS, _i_52299, 1LL);
            }
            DeRef(_0);
            goto L31; // [1641] 1616
L32: 
            ;
            DeRef(_i_52299);
        }

        /** emit.e:919			cgi -= n*/
        _45cgi_51036 = _45cgi_51036 - _n_51973;

        /** emit.e:921			if op != PROC_FORWARD then*/
        if (_op_51960 == 195LL)
        goto L33; // [1658] 1694

        /** emit.e:922				assignable = TRUE*/
        _45assignable_51038 = _9TRUE_446;

        /** emit.e:923				c = NewTempSym() -- put final result in temp*/
        _c_51964 = _53NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_51964)) {
            _1 = (object)(DBL_PTR(_c_51964)->dbl);
            DeRefDS(_c_51964);
            _c_51964 = _1;
        }

        /** emit.e:924				Push(c)*/
        _45Push(_c_51964);

        /** emit.e:926				emit_addr(c)*/
        _45emit_addr(_c_51964);

        /** emit.e:927				emit_temp( c, NEW_REFERENCE )*/
        _45emit_temp(_c_51964, 1LL);
L33: 
        goto LC; // [1696] 7739

        /** emit.e:930		case WARNING then*/
        case 506:

        /** emit.e:931			assignable = FALSE*/
        _45assignable_51038 = _9FALSE_444;

        /** emit.e:932		    a = Pop()*/
        _a_51962 = _45Pop();
        if (!IS_ATOM_INT(_a_51962)) {
            _1 = (object)(DBL_PTR(_a_51962)->dbl);
            DeRefDS(_a_51962);
            _a_51962 = _1;
        }

        /** emit.e:933			Warning(SymTab[a][S_OBJ], custom_warning_flag,"")*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26726 = (object)*(((s1_ptr)_2)->base + _a_51962);
        _2 = (object)SEQ_PTR(_26726);
        _26727 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26726 = NOVALUE;
        Ref(_26727);
        RefDS(_22024);
        _49Warning(_26727, 64LL, _22024);
        _26727 = NOVALUE;
        goto LC; // [1737] 7739

        /** emit.e:935		case INCLUDE_PATHS then*/
        case 507:

        /** emit.e:936			sequence paths*/

        /** emit.e:938			assignable = TRUE*/
        _45assignable_51038 = _9TRUE_446;

        /** emit.e:939		    a = Pop()*/
        _a_51962 = _45Pop();
        if (!IS_ATOM_INT(_a_51962)) {
            _1 = (object)(DBL_PTR(_a_51962)->dbl);
            DeRefDS(_a_51962);
            _a_51962 = _1;
        }

        /** emit.e:940		    emit_opcode(RIGHT_BRACE_N)*/
        _45emit_opcode(31LL);

        /** emit.e:941		    paths = Include_paths(SymTab[a][S_OBJ])*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26729 = (object)*(((s1_ptr)_2)->base + _a_51962);
        _2 = (object)SEQ_PTR(_26729);
        _26730 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26729 = NOVALUE;
        Ref(_26730);
        _0 = _paths_52324;
        _paths_52324 = _46Include_paths(_26730);
        DeRef(_0);
        _26730 = NOVALUE;

        /** emit.e:942		    emit(length(paths))*/
        if (IS_SEQUENCE(_paths_52324)){
                _26732 = SEQ_PTR(_paths_52324)->length;
        }
        else {
            _26732 = 1;
        }
        _45emit(_26732);
        _26732 = NOVALUE;

        /** emit.e:943		    for i=length(paths) to 1 by -1 do*/
        if (IS_SEQUENCE(_paths_52324)){
                _26733 = SEQ_PTR(_paths_52324)->length;
        }
        else {
            _26733 = 1;
        }
        {
            object _i_52336;
            _i_52336 = _26733;
L34: 
            if (_i_52336 < 1LL){
                goto L35; // [1799] 1830
            }

            /** emit.e:944		        c = NewStringSym(paths[i])*/
            _2 = (object)SEQ_PTR(_paths_52324);
            _26734 = (object)*(((s1_ptr)_2)->base + _i_52336);
            Ref(_26734);
            _c_51964 = _53NewStringSym(_26734);
            _26734 = NOVALUE;
            if (!IS_ATOM_INT(_c_51964)) {
                _1 = (object)(DBL_PTR(_c_51964)->dbl);
                DeRefDS(_c_51964);
                _c_51964 = _1;
            }

            /** emit.e:945		        emit_addr(c)*/
            _45emit_addr(_c_51964);

            /** emit.e:946		    end for*/
            _i_52336 = _i_52336 + -1LL;
            goto L34; // [1825] 1806
L35: 
            ;
        }

        /** emit.e:947		    b = NewTempSym()*/
        _b_51963 = _53NewTempSym(0LL);
        if (!IS_ATOM_INT(_b_51963)) {
            _1 = (object)(DBL_PTR(_b_51963)->dbl);
            DeRefDS(_b_51963);
            _b_51963 = _1;
        }

        /** emit.e:948			emit_temp(b, NEW_REFERENCE)*/
        _45emit_temp(_b_51963, 1LL);

        /** emit.e:949		    Push(b)*/
        _45Push(_b_51963);

        /** emit.e:950		    emit_addr(b)*/
        _45emit_addr(_b_51963);

        /** emit.e:951			last_op = RIGHT_BRACE_N*/
        _45last_op_51919 = 31LL;

        /** emit.e:952			op = last_op*/
        _op_51960 = 31LL;
        DeRef(_paths_52324);
        _paths_52324 = NOVALUE;
        goto LC; // [1872] 7739

        /** emit.e:955		case NOP1, NOP2, NOPWHILE, PRIVATE_INIT_CHECK, GLOBAL_INIT_CHECK,*/
        case 159:
        case 110:
        case 158:
        case 30:
        case 109:
        case 58:
        case 59:
        case 61:
        case 184:
        case 22:
        case 23:
        case 188:
        case 189:
        case 88:
        case 43:
        case 90:
        case 89:
        case 87:
        case 135:
        case 156:
        case 169:
        case 175:
        case 174:
        case 187:
        case 210:
        case 211:

        /** emit.e:961			emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:962			assignable = FALSE*/
        _45assignable_51038 = _9FALSE_444;

        /** emit.e:963			if op = UPDATE_GLOBALS then*/
        if (_op_51960 != 89LL)
        goto LC; // [1944] 7739

        /** emit.e:964				last_op = last_op_backup*/
        _45last_op_51919 = _last_op_backup_51978;

        /** emit.e:965				last_pc = last_pc_backup*/
        _45last_pc_51920 = _last_pc_backup_51977;
        goto LC; // [1959] 7739

        /** emit.e:969		case IF, WHILE then*/
        case 20:
        case 47:

        /** emit.e:970			a = Pop()*/
        _a_51962 = _45Pop();
        if (!IS_ATOM_INT(_a_51962)) {
            _1 = (object)(DBL_PTR(_a_51962)->dbl);
            DeRefDS(_a_51962);
            _a_51962 = _1;
        }

        /** emit.e:971			assignable = FALSE*/
        _45assignable_51038 = _9FALSE_444;

        /** emit.e:973			if previous_op >= LESS and previous_op <= NOT then*/
        _26739 = (_12previous_op_20325 >= 1LL);
        if (_26739 == 0) {
            goto L36; // [1991] 2283
        }
        _26741 = (_12previous_op_20325 <= 7LL);
        if (_26741 == 0)
        {
            DeRef(_26741);
            _26741 = NOVALUE;
            goto L36; // [2004] 2283
        }
        else{
            DeRef(_26741);
            _26741 = NOVALUE;
        }

        /** emit.e:974				clear_temp( Code[$] )*/
        if (IS_SEQUENCE(_12Code_20315)){
                _26742 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26742 = 1;
        }
        _2 = (object)SEQ_PTR(_12Code_20315);
        _26743 = (object)*(((s1_ptr)_2)->base + _26742);
        Ref(_26743);
        _45clear_temp(_26743);
        _26743 = NOVALUE;

        /** emit.e:975				Code = Code[1..$-1]*/
        if (IS_SEQUENCE(_12Code_20315)){
                _26744 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26744 = 1;
        }
        _26745 = _26744 - 1LL;
        _26744 = NOVALUE;
        rhs_slice_target = (object_ptr)&_12Code_20315;
        RHS_Slice(_12Code_20315, 1LL, _26745);

        /** emit.e:976				if previous_op = NOT then*/
        if (_12previous_op_20325 != 7LL)
        goto L37; // [2045] 2125

        /** emit.e:977					op = NOT_IFW*/
        _op_51960 = 108LL;

        /** emit.e:978					backpatch(length(Code) - 1, op)*/
        if (IS_SEQUENCE(_12Code_20315)){
                _26748 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26748 = 1;
        }
        _26749 = _26748 - 1LL;
        _26748 = NOVALUE;
        _45backpatch(_26749, 108LL);
        _26749 = NOVALUE;

        /** emit.e:979					sequence if_code = Code[$-1..$]*/
        if (IS_SEQUENCE(_12Code_20315)){
                _26750 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26750 = 1;
        }
        _26751 = _26750 - 1LL;
        _26750 = NOVALUE;
        if (IS_SEQUENCE(_12Code_20315)){
                _26752 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26752 = 1;
        }
        rhs_slice_target = (object_ptr)&_if_code_52404;
        RHS_Slice(_12Code_20315, _26751, _26752);

        /** emit.e:980					Code = Code[1..$-2]*/
        if (IS_SEQUENCE(_12Code_20315)){
                _26754 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26754 = 1;
        }
        _26755 = _26754 - 2LL;
        _26754 = NOVALUE;
        rhs_slice_target = (object_ptr)&_12Code_20315;
        RHS_Slice(_12Code_20315, 1LL, _26755);

        /** emit.e:981					Code &= if_code*/
        Concat((object_ptr)&_12Code_20315, _12Code_20315, _if_code_52404);
        DeRefDS(_if_code_52404);
        _if_code_52404 = NOVALUE;
        goto L38; // [2122] 2270
L37: 

        /** emit.e:983					if IsInteger(Code[$-1]) and IsInteger(Code[$]) then*/
        if (IS_SEQUENCE(_12Code_20315)){
                _26758 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26758 = 1;
        }
        _26759 = _26758 - 1LL;
        _26758 = NOVALUE;
        _2 = (object)SEQ_PTR(_12Code_20315);
        _26760 = (object)*(((s1_ptr)_2)->base + _26759);
        Ref(_26760);
        _26761 = _45IsInteger(_26760);
        _26760 = NOVALUE;
        if (IS_ATOM_INT(_26761)) {
            if (_26761 == 0) {
                goto L39; // [2144] 2186
            }
        }
        else {
            if (DBL_PTR(_26761)->dbl == 0.0) {
                goto L39; // [2144] 2186
            }
        }
        if (IS_SEQUENCE(_12Code_20315)){
                _26763 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26763 = 1;
        }
        _2 = (object)SEQ_PTR(_12Code_20315);
        _26764 = (object)*(((s1_ptr)_2)->base + _26763);
        Ref(_26764);
        _26765 = _45IsInteger(_26764);
        _26764 = NOVALUE;
        if (_26765 == 0) {
            DeRef(_26765);
            _26765 = NOVALUE;
            goto L39; // [2162] 2186
        }
        else {
            if (!IS_ATOM_INT(_26765) && DBL_PTR(_26765)->dbl == 0.0){
                DeRef(_26765);
                _26765 = NOVALUE;
                goto L39; // [2162] 2186
            }
            DeRef(_26765);
            _26765 = NOVALUE;
        }
        DeRef(_26765);
        _26765 = NOVALUE;

        /** emit.e:984						op = previous_op + LESS_IFW_I - LESS*/
        _26766 = _12previous_op_20325 + 119LL;
        if ((object)((uintptr_t)_26766 + (uintptr_t)HIGH_BITS) >= 0){
            _26766 = NewDouble((eudouble)_26766);
        }
        if (IS_ATOM_INT(_26766)) {
            _op_51960 = _26766 - 1LL;
        }
        else {
            _op_51960 = NewDouble(DBL_PTR(_26766)->dbl - (eudouble)1LL);
        }
        DeRef(_26766);
        _26766 = NOVALUE;
        if (!IS_ATOM_INT(_op_51960)) {
            _1 = (object)(DBL_PTR(_op_51960)->dbl);
            DeRefDS(_op_51960);
            _op_51960 = _1;
        }
        goto L3A; // [2183] 2205
L39: 

        /** emit.e:986						op = previous_op + LESS_IFW - LESS*/
        _26768 = _12previous_op_20325 + 102LL;
        if ((object)((uintptr_t)_26768 + (uintptr_t)HIGH_BITS) >= 0){
            _26768 = NewDouble((eudouble)_26768);
        }
        if (IS_ATOM_INT(_26768)) {
            _op_51960 = _26768 - 1LL;
        }
        else {
            _op_51960 = NewDouble(DBL_PTR(_26768)->dbl - (eudouble)1LL);
        }
        DeRef(_26768);
        _26768 = NOVALUE;
        if (!IS_ATOM_INT(_op_51960)) {
            _1 = (object)(DBL_PTR(_op_51960)->dbl);
            DeRefDS(_op_51960);
            _op_51960 = _1;
        }
L3A: 

        /** emit.e:989					backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_12Code_20315)){
                _26770 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26770 = 1;
        }
        _26771 = _26770 - 2LL;
        _26770 = NOVALUE;
        _45backpatch(_26771, _op_51960);
        _26771 = NOVALUE;

        /** emit.e:991					sequence if_code = Code[$-2..$]*/
        if (IS_SEQUENCE(_12Code_20315)){
                _26772 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26772 = 1;
        }
        _26773 = _26772 - 2LL;
        _26772 = NOVALUE;
        if (IS_SEQUENCE(_12Code_20315)){
                _26774 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26774 = 1;
        }
        rhs_slice_target = (object_ptr)&_if_code_52443;
        RHS_Slice(_12Code_20315, _26773, _26774);

        /** emit.e:992					Code = Code[1..$-3]*/
        if (IS_SEQUENCE(_12Code_20315)){
                _26776 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26776 = 1;
        }
        _26777 = _26776 - 3LL;
        _26776 = NOVALUE;
        rhs_slice_target = (object_ptr)&_12Code_20315;
        RHS_Slice(_12Code_20315, 1LL, _26777);

        /** emit.e:993					Code &= if_code*/
        Concat((object_ptr)&_12Code_20315, _12Code_20315, _if_code_52443);
        DeRefDS(_if_code_52443);
        _if_code_52443 = NOVALUE;
L38: 

        /** emit.e:997				last_pc = last_pc_backup*/
        _45last_pc_51920 = _last_pc_backup_51977;

        /** emit.e:998				last_op = op*/
        _45last_op_51919 = _op_51960;
        goto LC; // [2280] 7739
L36: 

        /** emit.e:1000			elsif op = WHILE and*/
        _26780 = (_op_51960 == 47LL);
        if (_26780 == 0) {
            _26781 = 0;
            goto L3B; // [2291] 2303
        }
        _26782 = (_a_51962 > 0LL);
        _26781 = (_26782 != 0);
L3B: 
        if (_26781 == 0) {
            _26783 = 0;
            goto L3C; // [2303] 2329
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26784 = (object)*(((s1_ptr)_2)->base + _a_51962);
        _2 = (object)SEQ_PTR(_26784);
        _26785 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26784 = NOVALUE;
        if (IS_ATOM_INT(_26785)) {
            _26786 = (_26785 == 2LL);
        }
        else {
            _26786 = binary_op(EQUALS, _26785, 2LL);
        }
        _26785 = NOVALUE;
        if (IS_ATOM_INT(_26786))
        _26783 = (_26786 != 0);
        else
        _26783 = DBL_PTR(_26786)->dbl != 0.0;
L3C: 
        if (_26783 == 0) {
            _26787 = 0;
            goto L3D; // [2329] 2352
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26788 = (object)*(((s1_ptr)_2)->base + _a_51962);
        _2 = (object)SEQ_PTR(_26788);
        _26789 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26788 = NOVALUE;
        if (IS_ATOM_INT(_26789))
        _26790 = 1;
        else if (IS_ATOM_DBL(_26789))
        _26790 = IS_ATOM_INT(DoubleToInt(_26789));
        else
        _26790 = 0;
        _26789 = NOVALUE;
        _26787 = (_26790 != 0);
L3D: 
        if (_26787 == 0) {
            goto L3E; // [2352] 2401
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26792 = (object)*(((s1_ptr)_2)->base + _a_51962);
        _2 = (object)SEQ_PTR(_26792);
        _26793 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26792 = NOVALUE;
        if (_26793 == 0LL)
        _26794 = 1;
        else if (IS_ATOM_INT(_26793) && IS_ATOM_INT(0LL))
        _26794 = 0;
        else
        _26794 = (compare(_26793, 0LL) == 0);
        _26793 = NOVALUE;
        _26795 = (_26794 == 0);
        _26794 = NOVALUE;
        if (_26795 == 0)
        {
            DeRef(_26795);
            _26795 = NOVALUE;
            goto L3E; // [2376] 2401
        }
        else{
            DeRef(_26795);
            _26795 = NOVALUE;
        }

        /** emit.e:1005				optimized_while = TRUE   -- while TRUE ... emit nothing*/
        _45optimized_while_51022 = _9TRUE_446;

        /** emit.e:1006				last_pc = last_pc_backup*/
        _45last_pc_51920 = _last_pc_backup_51977;

        /** emit.e:1007				last_op = last_op_backup*/
        _45last_op_51919 = _last_op_backup_51978;
        goto LC; // [2398] 7739
L3E: 

        /** emit.e:1009				flush_temps( {a} )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _a_51962;
        _26796 = MAKE_SEQ(_1);
        _45flush_temps(_26796);
        _26796 = NOVALUE;

        /** emit.e:1010				emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1011				emit_addr(a)*/
        _45emit_addr(_a_51962);
        goto LC; // [2421] 7739

        /** emit.e:1016		case INTEGER_CHECK then*/
        case 96:

        /** emit.e:1017			assignable = FALSE*/
        _45assignable_51038 = _9FALSE_444;

        /** emit.e:1018			if previous_op = ASSIGN then*/
        if (_12previous_op_20325 != 18LL)
        goto L3F; // [2440] 2499

        /** emit.e:1019				c = Code[$-1]*/
        if (IS_SEQUENCE(_12Code_20315)){
                _26798 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26798 = 1;
        }
        _26799 = _26798 - 1LL;
        _26798 = NOVALUE;
        _2 = (object)SEQ_PTR(_12Code_20315);
        _c_51964 = (object)*(((s1_ptr)_2)->base + _26799);
        if (!IS_ATOM_INT(_c_51964)){
            _c_51964 = (object)DBL_PTR(_c_51964)->dbl;
        }

        /** emit.e:1020				if not IsInteger(c) then*/
        _26801 = _45IsInteger(_c_51964);
        if (IS_ATOM_INT(_26801)) {
            if (_26801 != 0){
                DeRef(_26801);
                _26801 = NOVALUE;
                goto L40; // [2467] 2485
            }
        }
        else {
            if (DBL_PTR(_26801)->dbl != 0.0){
                DeRef(_26801);
                _26801 = NOVALUE;
                goto L40; // [2467] 2485
            }
        }
        DeRef(_26801);
        _26801 = NOVALUE;

        /** emit.e:1021					emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1022					emit_addr(op_info1)*/
        _45emit_addr(_45op_info1_51020);
        goto L41; // [2482] 2556
L40: 

        /** emit.e:1024					last_op = last_op_backup*/
        _45last_op_51919 = _last_op_backup_51978;

        /** emit.e:1025					last_pc = last_pc_backup*/
        _45last_pc_51920 = _last_pc_backup_51977;
        goto L41; // [2496] 2556
L3F: 

        /** emit.e:1027			elsif previous_op = -1 or*/
        _26803 = (_12previous_op_20325 == -1LL);
        if (_26803 != 0) {
            goto L42; // [2507] 2530
        }
        _2 = (object)SEQ_PTR(_45op_result_51637);
        _26805 = (object)*(((s1_ptr)_2)->base + _12previous_op_20325);
        _26806 = (_26805 != 1LL);
        _26805 = NOVALUE;
        if (_26806 == 0)
        {
            DeRef(_26806);
            _26806 = NOVALUE;
            goto L43; // [2526] 2545
        }
        else{
            DeRef(_26806);
            _26806 = NOVALUE;
        }
L42: 

        /** emit.e:1029				emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1030				emit_addr(op_info1)*/
        _45emit_addr(_45op_info1_51020);
        goto L41; // [2542] 2556
L43: 

        /** emit.e:1032				last_op = last_op_backup*/
        _45last_op_51919 = _last_op_backup_51978;

        /** emit.e:1033				last_pc = last_pc_backup*/
        _45last_pc_51920 = _last_pc_backup_51977;
L41: 

        /** emit.e:1035			clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_12Code_20315)){
                _26807 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26807 = 1;
        }
        _26808 = _26807 - 1LL;
        _26807 = NOVALUE;
        _2 = (object)SEQ_PTR(_12Code_20315);
        _26809 = (object)*(((s1_ptr)_2)->base + _26808);
        Ref(_26809);
        _45clear_temp(_26809);
        _26809 = NOVALUE;
        goto LC; // [2574] 7739

        /** emit.e:1037		case SEQUENCE_CHECK then*/
        case 97:

        /** emit.e:1038			assignable = FALSE*/
        _45assignable_51038 = _9FALSE_444;

        /** emit.e:1039			if previous_op = ASSIGN then*/
        if (_12previous_op_20325 != 18LL)
        goto L44; // [2593] 2720

        /** emit.e:1040				c = Code[$-1]*/
        if (IS_SEQUENCE(_12Code_20315)){
                _26811 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26811 = 1;
        }
        _26812 = _26811 - 1LL;
        _26811 = NOVALUE;
        _2 = (object)SEQ_PTR(_12Code_20315);
        _c_51964 = (object)*(((s1_ptr)_2)->base + _26812);
        if (!IS_ATOM_INT(_c_51964)){
            _c_51964 = (object)DBL_PTR(_c_51964)->dbl;
        }

        /** emit.e:1041				if c < 1 or*/
        _26814 = (_c_51964 < 1LL);
        if (_26814 != 0) {
            _26815 = 1;
            goto L45; // [2620] 2646
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26816 = (object)*(((s1_ptr)_2)->base + _c_51964);
        _2 = (object)SEQ_PTR(_26816);
        _26817 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26816 = NOVALUE;
        if (IS_ATOM_INT(_26817)) {
            _26818 = (_26817 != 2LL);
        }
        else {
            _26818 = binary_op(NOTEQ, _26817, 2LL);
        }
        _26817 = NOVALUE;
        if (IS_ATOM_INT(_26818))
        _26815 = (_26818 != 0);
        else
        _26815 = DBL_PTR(_26818)->dbl != 0.0;
L45: 
        if (_26815 != 0) {
            goto L46; // [2646] 2673
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26820 = (object)*(((s1_ptr)_2)->base + _c_51964);
        _2 = (object)SEQ_PTR(_26820);
        _26821 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26820 = NOVALUE;
        _26822 = IS_SEQUENCE(_26821);
        _26821 = NOVALUE;
        _26823 = (_26822 == 0);
        _26822 = NOVALUE;
        if (_26823 == 0)
        {
            DeRef(_26823);
            _26823 = NOVALUE;
            goto L47; // [2669] 2706
        }
        else{
            DeRef(_26823);
            _26823 = NOVALUE;
        }
L46: 

        /** emit.e:1044					emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1045					emit_addr(op_info1)*/
        _45emit_addr(_45op_info1_51020);

        /** emit.e:1046					clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_12Code_20315)){
                _26824 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26824 = 1;
        }
        _26825 = _26824 - 1LL;
        _26824 = NOVALUE;
        _2 = (object)SEQ_PTR(_12Code_20315);
        _26826 = (object)*(((s1_ptr)_2)->base + _26825);
        Ref(_26826);
        _45clear_temp(_26826);
        _26826 = NOVALUE;
        goto LC; // [2703] 7739
L47: 

        /** emit.e:1048					last_op = last_op_backup*/
        _45last_op_51919 = _last_op_backup_51978;

        /** emit.e:1049					last_pc = last_pc_backup*/
        _45last_pc_51920 = _last_pc_backup_51977;
        goto LC; // [2717] 7739
L44: 

        /** emit.e:1051			elsif previous_op = -1 or op_result[previous_op] != T_SEQUENCE then*/
        _26827 = (_12previous_op_20325 == -1LL);
        if (_26827 != 0) {
            goto L48; // [2728] 2751
        }
        _2 = (object)SEQ_PTR(_45op_result_51637);
        _26829 = (object)*(((s1_ptr)_2)->base + _12previous_op_20325);
        _26830 = (_26829 != 2LL);
        _26829 = NOVALUE;
        if (_26830 == 0)
        {
            DeRef(_26830);
            _26830 = NOVALUE;
            goto L49; // [2747] 2784
        }
        else{
            DeRef(_26830);
            _26830 = NOVALUE;
        }
L48: 

        /** emit.e:1052				emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1053				emit_addr(op_info1)*/
        _45emit_addr(_45op_info1_51020);

        /** emit.e:1054				clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_12Code_20315)){
                _26831 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26831 = 1;
        }
        _26832 = _26831 - 1LL;
        _26831 = NOVALUE;
        _2 = (object)SEQ_PTR(_12Code_20315);
        _26833 = (object)*(((s1_ptr)_2)->base + _26832);
        Ref(_26833);
        _45clear_temp(_26833);
        _26833 = NOVALUE;
        goto LC; // [2781] 7739
L49: 

        /** emit.e:1056				last_op = last_op_backup*/
        _45last_op_51919 = _last_op_backup_51978;

        /** emit.e:1057				last_pc = last_pc_backup*/
        _45last_pc_51920 = _last_pc_backup_51977;
        goto LC; // [2795] 7739

        /** emit.e:1061		case ATOM_CHECK then*/
        case 101:

        /** emit.e:1062			assignable = FALSE*/
        _45assignable_51038 = _9FALSE_444;

        /** emit.e:1063			if previous_op = ASSIGN then*/
        if (_12previous_op_20325 != 18LL)
        goto L4A; // [2814] 3015

        /** emit.e:1064				c = Code[$-1]*/
        if (IS_SEQUENCE(_12Code_20315)){
                _26835 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26835 = 1;
        }
        _26836 = _26835 - 1LL;
        _26835 = NOVALUE;
        _2 = (object)SEQ_PTR(_12Code_20315);
        _c_51964 = (object)*(((s1_ptr)_2)->base + _26836);
        if (!IS_ATOM_INT(_c_51964)){
            _c_51964 = (object)DBL_PTR(_c_51964)->dbl;
        }

        /** emit.e:1065				if c > 1*/
        _26838 = (_c_51964 > 1LL);
        if (_26838 == 0) {
            goto L4B; // [2841] 2964
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26840 = (object)*(((s1_ptr)_2)->base + _c_51964);
        _2 = (object)SEQ_PTR(_26840);
        _26841 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26840 = NOVALUE;
        if (IS_ATOM_INT(_26841)) {
            _26842 = (_26841 == 2LL);
        }
        else {
            _26842 = binary_op(EQUALS, _26841, 2LL);
        }
        _26841 = NOVALUE;
        if (_26842 == 0) {
            DeRef(_26842);
            _26842 = NOVALUE;
            goto L4B; // [2864] 2964
        }
        else {
            if (!IS_ATOM_INT(_26842) && DBL_PTR(_26842)->dbl == 0.0){
                DeRef(_26842);
                _26842 = NOVALUE;
                goto L4B; // [2864] 2964
            }
            DeRef(_26842);
            _26842 = NOVALUE;
        }
        DeRef(_26842);
        _26842 = NOVALUE;

        /** emit.e:1068					if sequence( SymTab[c][S_OBJ] ) then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26843 = (object)*(((s1_ptr)_2)->base + _c_51964);
        _2 = (object)SEQ_PTR(_26843);
        _26844 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26843 = NOVALUE;
        _26845 = IS_SEQUENCE(_26844);
        _26844 = NOVALUE;
        if (_26845 == 0)
        {
            _26845 = NOVALUE;
            goto L4C; // [2884] 2915
        }
        else{
            _26845 = NOVALUE;
        }

        /** emit.e:1070						ThisLine = ExprLine*/
        RefDS(_43ExprLine_57136);
        DeRef(_49ThisLine_49312);
        _49ThisLine_49312 = _43ExprLine_57136;

        /** emit.e:1071						bp = expr_bp*/
        _49bp_49316 = _43expr_bp_57137;

        /** emit.e:1072						CompileErr( TYPE_CHECK_ERROR__ASSIGNING_A_SEQUENCE_TO_AN_ATOM)*/
        RefDS(_22024);
        _49CompileErr(346LL, _22024, 0LL);
        goto L4D; // [2912] 3094
L4C: 

        /** emit.e:1074					elsif SymTab[c][S_OBJ] = NOVALUE then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26846 = (object)*(((s1_ptr)_2)->base + _c_51964);
        _2 = (object)SEQ_PTR(_26846);
        _26847 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26846 = NOVALUE;
        if (binary_op_a(NOTEQ, _26847, _12NOVALUE_20081)){
            _26847 = NOVALUE;
            goto L4E; // [2931] 2950
        }
        _26847 = NOVALUE;

        /** emit.e:1075						emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1076						emit_addr(op_info1)*/
        _45emit_addr(_45op_info1_51020);
        goto L4D; // [2947] 3094
L4E: 

        /** emit.e:1078						last_op = last_op_backup*/
        _45last_op_51919 = _last_op_backup_51978;

        /** emit.e:1079						last_pc = last_pc_backup*/
        _45last_pc_51920 = _last_pc_backup_51977;
        goto L4D; // [2961] 3094
L4B: 

        /** emit.e:1082				elsif c < 1 */
        _26849 = (_c_51964 < 1LL);
        if (_26849 != 0) {
            goto L4F; // [2970] 2986
        }
        _26851 = _45IsInteger(_c_51964);
        if (IS_ATOM_INT(_26851)) {
            _26852 = (_26851 == 0);
        }
        else {
            _26852 = unary_op(NOT, _26851);
        }
        DeRef(_26851);
        _26851 = NOVALUE;
        if (_26852 == 0) {
            DeRef(_26852);
            _26852 = NOVALUE;
            goto L50; // [2982] 3001
        }
        else {
            if (!IS_ATOM_INT(_26852) && DBL_PTR(_26852)->dbl == 0.0){
                DeRef(_26852);
                _26852 = NOVALUE;
                goto L50; // [2982] 3001
            }
            DeRef(_26852);
            _26852 = NOVALUE;
        }
        DeRef(_26852);
        _26852 = NOVALUE;
L4F: 

        /** emit.e:1085					emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1086					emit_addr(op_info1)*/
        _45emit_addr(_45op_info1_51020);
        goto L4D; // [2998] 3094
L50: 

        /** emit.e:1089					last_op = last_op_backup*/
        _45last_op_51919 = _last_op_backup_51978;

        /** emit.e:1090					last_pc = last_pc_backup*/
        _45last_pc_51920 = _last_pc_backup_51977;
        goto L4D; // [3012] 3094
L4A: 

        /** emit.e:1092			elsif previous_op = -1 or*/
        _26853 = (_12previous_op_20325 == -1LL);
        if (_26853 != 0) {
            goto L51; // [3023] 3068
        }
        _2 = (object)SEQ_PTR(_45op_result_51637);
        _26855 = (object)*(((s1_ptr)_2)->base + _12previous_op_20325);
        _26856 = (_26855 != 1LL);
        _26855 = NOVALUE;
        if (_26856 == 0) {
            DeRef(_26857);
            _26857 = 0;
            goto L52; // [3041] 3063
        }
        _2 = (object)SEQ_PTR(_45op_result_51637);
        _26858 = (object)*(((s1_ptr)_2)->base + _12previous_op_20325);
        _26859 = (_26858 != 3LL);
        _26858 = NOVALUE;
        _26857 = (_26859 != 0);
L52: 
        if (_26857 == 0)
        {
            _26857 = NOVALUE;
            goto L53; // [3064] 3083
        }
        else{
            _26857 = NOVALUE;
        }
L51: 

        /** emit.e:1095				emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1096				emit_addr(op_info1)*/
        _45emit_addr(_45op_info1_51020);
        goto L4D; // [3080] 3094
L53: 

        /** emit.e:1098				last_op = last_op_backup*/
        _45last_op_51919 = _last_op_backup_51978;

        /** emit.e:1099				last_pc = last_pc_backup*/
        _45last_pc_51920 = _last_pc_backup_51977;
L4D: 

        /** emit.e:1101			clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_12Code_20315)){
                _26860 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _26860 = 1;
        }
        _26861 = _26860 - 1LL;
        _26860 = NOVALUE;
        _2 = (object)SEQ_PTR(_12Code_20315);
        _26862 = (object)*(((s1_ptr)_2)->base + _26861);
        Ref(_26862);
        _45clear_temp(_26862);
        _26862 = NOVALUE;
        goto LC; // [3112] 7739

        /** emit.e:1103		case RIGHT_BRACE_N then*/
        case 31:

        /** emit.e:1105			n = op_info1*/
        _n_51973 = _45op_info1_51020;

        /** emit.e:1107			elements = {}*/
        RefDS(_22024);
        DeRef(_elements_51975);
        _elements_51975 = _22024;

        /** emit.e:1108			for i = 1 to n do*/
        _26863 = _n_51973;
        {
            object _i_52624;
            _i_52624 = 1LL;
L54: 
            if (_i_52624 > _26863){
                goto L55; // [3137] 3160
            }

            /** emit.e:1109				elements = append(elements, Pop())*/
            _26864 = _45Pop();
            Ref(_26864);
            Append(&_elements_51975, _elements_51975, _26864);
            DeRef(_26864);
            _26864 = NOVALUE;

            /** emit.e:1110			end for*/
            _i_52624 = _i_52624 + 1LL;
            goto L54; // [3155] 3144
L55: 
            ;
        }

        /** emit.e:1111			element_vals = good_string(elements)*/
        RefDS(_elements_51975);
        _0 = _element_vals_51976;
        _element_vals_51976 = _45good_string(_elements_51975);
        DeRef(_0);

        /** emit.e:1113			if sequence(element_vals) then*/
        _26867 = IS_SEQUENCE(_element_vals_51976);
        if (_26867 == 0)
        {
            _26867 = NOVALUE;
            goto L56; // [3171] 3202
        }
        else{
            _26867 = NOVALUE;
        }

        /** emit.e:1114				c = NewStringSym(element_vals)  -- make a string literal*/
        Ref(_element_vals_51976);
        _c_51964 = _53NewStringSym(_element_vals_51976);
        if (!IS_ATOM_INT(_c_51964)) {
            _1 = (object)(DBL_PTR(_c_51964)->dbl);
            DeRefDS(_c_51964);
            _c_51964 = _1;
        }

        /** emit.e:1115				assignable = FALSE*/
        _45assignable_51038 = _9FALSE_444;

        /** emit.e:1116				last_op = last_op_backup*/
        _45last_op_51919 = _last_op_backup_51978;

        /** emit.e:1117				last_pc = last_pc_backup*/
        _45last_pc_51920 = _last_pc_backup_51977;
        goto L57; // [3199] 3293
L56: 

        /** emit.e:1119				if n = 2 then*/
        if (_n_51973 != 2LL)
        goto L58; // [3204] 3227

        /** emit.e:1120					emit_opcode(RIGHT_BRACE_2) -- faster op for two items*/
        _45emit_opcode(85LL);

        /** emit.e:1121					last_op = RIGHT_BRACE_2*/
        _45last_op_51919 = 85LL;
        goto L59; // [3224] 3238
L58: 

        /** emit.e:1123					emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1124					emit(n)*/
        _45emit(_n_51973);
L59: 

        /** emit.e:1127				for i = 1 to n do*/
        _26870 = _n_51973;
        {
            object _i_52641;
            _i_52641 = 1LL;
L5A: 
            if (_i_52641 > _26870){
                goto L5B; // [3243] 3266
            }

            /** emit.e:1128					emit_addr(elements[i])*/
            _2 = (object)SEQ_PTR(_elements_51975);
            _26871 = (object)*(((s1_ptr)_2)->base + _i_52641);
            Ref(_26871);
            _45emit_addr(_26871);
            _26871 = NOVALUE;

            /** emit.e:1129				end for*/
            _i_52641 = _i_52641 + 1LL;
            goto L5A; // [3261] 3250
L5B: 
            ;
        }

        /** emit.e:1130				c = NewTempSym()*/
        _c_51964 = _53NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_51964)) {
            _1 = (object)(DBL_PTR(_c_51964)->dbl);
            DeRefDS(_c_51964);
            _c_51964 = _1;
        }

        /** emit.e:1131				emit_addr(c)*/
        _45emit_addr(_c_51964);

        /** emit.e:1132				emit_temp( c, NEW_REFERENCE )*/
        _45emit_temp(_c_51964, 1LL);

        /** emit.e:1133				assignable = TRUE*/
        _45assignable_51038 = _9TRUE_446;
L57: 

        /** emit.e:1135			Push(c)*/
        _45Push(_c_51964);
        goto LC; // [3298] 7739

        /** emit.e:1138		case ASSIGN_SUBS2,      -- can't change the op*/
        case 148:
        case 16:
        case 162:

        /** emit.e:1141			b = Pop() -- rhs value*/
        _b_51963 = _45Pop();
        if (!IS_ATOM_INT(_b_51963)) {
            _1 = (object)(DBL_PTR(_b_51963)->dbl);
            DeRefDS(_b_51963);
            _b_51963 = _1;
        }

        /** emit.e:1142			a = Pop() -- subscript*/
        _a_51962 = _45Pop();
        if (!IS_ATOM_INT(_a_51962)) {
            _1 = (object)(DBL_PTR(_a_51962)->dbl);
            DeRefDS(_a_51962);
            _a_51962 = _1;
        }

        /** emit.e:1143			c = Pop() -- sequence*/
        _c_51964 = _45Pop();
        if (!IS_ATOM_INT(_c_51964)) {
            _1 = (object)(DBL_PTR(_c_51964)->dbl);
            DeRefDS(_c_51964);
            _c_51964 = _1;
        }

        /** emit.e:1144			if op = ASSIGN_SUBS then*/
        if (_op_51960 != 16LL)
        goto L5C; // [3333] 3525

        /** emit.e:1146				if (previous_op != LHS_SUBS) and*/
        _26877 = (_12previous_op_20325 != 95LL);
        if (_26877 == 0) {
            _26878 = 0;
            goto L5D; // [3347] 3359
        }
        _26879 = (_c_51964 > 0LL);
        _26878 = (_26879 != 0);
L5D: 
        if (_26878 == 0) {
            goto L5E; // [3359] 3497
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26881 = (object)*(((s1_ptr)_2)->base + _c_51964);
        _2 = (object)SEQ_PTR(_26881);
        _26882 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26881 = NOVALUE;
        if (IS_ATOM_INT(_26882)) {
            _26883 = (_26882 != 1LL);
        }
        else {
            _26883 = binary_op(NOTEQ, _26882, 1LL);
        }
        _26882 = NOVALUE;
        if (IS_ATOM_INT(_26883)) {
            if (_26883 != 0) {
                DeRef(_26884);
                _26884 = 1;
                goto L5F; // [3381] 3481
            }
        }
        else {
            if (DBL_PTR(_26883)->dbl != 0.0) {
                DeRef(_26884);
                _26884 = 1;
                goto L5F; // [3381] 3481
            }
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26885 = (object)*(((s1_ptr)_2)->base + _c_51964);
        _2 = (object)SEQ_PTR(_26885);
        _26886 = (object)*(((s1_ptr)_2)->base + 15LL);
        _26885 = NOVALUE;
        if (IS_ATOM_INT(_26886)) {
            _26887 = (_26886 != _53sequence_type_46850);
        }
        else {
            _26887 = binary_op(NOTEQ, _26886, _53sequence_type_46850);
        }
        _26886 = NOVALUE;
        if (IS_ATOM_INT(_26887)) {
            if (_26887 == 0) {
                DeRef(_26888);
                _26888 = 0;
                goto L60; // [3403] 3477
            }
        }
        else {
            if (DBL_PTR(_26887)->dbl == 0.0) {
                DeRef(_26888);
                _26888 = 0;
                goto L60; // [3403] 3477
            }
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26889 = (object)*(((s1_ptr)_2)->base + _c_51964);
        _2 = (object)SEQ_PTR(_26889);
        _26890 = (object)*(((s1_ptr)_2)->base + 15LL);
        _26889 = NOVALUE;
        if (IS_ATOM_INT(_26890)) {
            _26891 = (_26890 > 0LL);
        }
        else {
            _26891 = binary_op(GREATER, _26890, 0LL);
        }
        _26890 = NOVALUE;
        if (IS_ATOM_INT(_26891)) {
            if (_26891 == 0) {
                DeRef(_26892);
                _26892 = 0;
                goto L61; // [3423] 3473
            }
        }
        else {
            if (DBL_PTR(_26891)->dbl == 0.0) {
                DeRef(_26892);
                _26892 = 0;
                goto L61; // [3423] 3473
            }
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26893 = (object)*(((s1_ptr)_2)->base + _c_51964);
        _2 = (object)SEQ_PTR(_26893);
        _26894 = (object)*(((s1_ptr)_2)->base + 15LL);
        _26893 = NOVALUE;
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!IS_ATOM_INT(_26894)){
            _26895 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_26894)->dbl));
        }
        else{
            _26895 = (object)*(((s1_ptr)_2)->base + _26894);
        }
        _2 = (object)SEQ_PTR(_26895);
        _26896 = (object)*(((s1_ptr)_2)->base + 2LL);
        _26895 = NOVALUE;
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!IS_ATOM_INT(_26896)){
            _26897 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_26896)->dbl));
        }
        else{
            _26897 = (object)*(((s1_ptr)_2)->base + _26896);
        }
        _2 = (object)SEQ_PTR(_26897);
        _26898 = (object)*(((s1_ptr)_2)->base + 15LL);
        _26897 = NOVALUE;
        if (IS_ATOM_INT(_26898)) {
            _26899 = (_26898 != _53sequence_type_46850);
        }
        else {
            _26899 = binary_op(NOTEQ, _26898, _53sequence_type_46850);
        }
        _26898 = NOVALUE;
        DeRef(_26892);
        if (IS_ATOM_INT(_26899))
        _26892 = (_26899 != 0);
        else
        _26892 = DBL_PTR(_26899)->dbl != 0.0;
L61: 
        DeRef(_26888);
        _26888 = (_26892 != 0);
L60: 
        DeRef(_26884);
        _26884 = (_26888 != 0);
L5F: 
        if (_26884 == 0)
        {
            _26884 = NOVALUE;
            goto L5E; // [3482] 3497
        }
        else{
            _26884 = NOVALUE;
        }

        /** emit.e:1153					op = ASSIGN_SUBS_CHECK*/
        _op_51960 = 84LL;
        goto L62; // [3494] 3517
L5E: 

        /** emit.e:1155					if IsInteger(b) then*/
        _26900 = _45IsInteger(_b_51963);
        if (_26900 == 0) {
            DeRef(_26900);
            _26900 = NOVALUE;
            goto L63; // [3503] 3516
        }
        else {
            if (!IS_ATOM_INT(_26900) && DBL_PTR(_26900)->dbl == 0.0){
                DeRef(_26900);
                _26900 = NOVALUE;
                goto L63; // [3503] 3516
            }
            DeRef(_26900);
            _26900 = NOVALUE;
        }
        DeRef(_26900);
        _26900 = NOVALUE;

        /** emit.e:1156						op = ASSIGN_SUBS_I*/
        _op_51960 = 118LL;
L63: 
L62: 

        /** emit.e:1159				emit_opcode(op)*/
        _45emit_opcode(_op_51960);
        goto L64; // [3522] 3551
L5C: 

        /** emit.e:1161			elsif op = PASSIGN_SUBS then*/
        if (_op_51960 != 162LL)
        goto L65; // [3529] 3543

        /** emit.e:1162				emit_opcode(PASSIGN_SUBS) -- always*/
        _45emit_opcode(162LL);
        goto L64; // [3540] 3551
L65: 

        /** emit.e:1165				emit_opcode(ASSIGN_SUBS) -- always*/
        _45emit_opcode(16LL);
L64: 

        /** emit.e:1169			emit_addr(c) -- sequence*/
        _45emit_addr(_c_51964);

        /** emit.e:1170			emit_addr(a) -- subscript*/
        _45emit_addr(_a_51962);

        /** emit.e:1171			emit_addr(b) -- rhs value*/
        _45emit_addr(_b_51963);

        /** emit.e:1172			assignable = FALSE*/
        _45assignable_51038 = _9FALSE_444;
        goto LC; // [3573] 7739

        /** emit.e:1174		case LHS_SUBS, LHS_SUBS1, LHS_SUBS1_COPY then*/
        case 95:
        case 161:
        case 166:

        /** emit.e:1176			a = Pop() -- subs*/
        _a_51962 = _45Pop();
        if (!IS_ATOM_INT(_a_51962)) {
            _1 = (object)(DBL_PTR(_a_51962)->dbl);
            DeRefDS(_a_51962);
            _a_51962 = _1;
        }

        /** emit.e:1177			lhs_var = Pop() -- sequence*/
        _lhs_var_51970 = _45Pop();
        if (!IS_ATOM_INT(_lhs_var_51970)) {
            _1 = (object)(DBL_PTR(_lhs_var_51970)->dbl);
            DeRefDS(_lhs_var_51970);
            _lhs_var_51970 = _1;
        }

        /** emit.e:1178			emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1179			emit_addr(lhs_var)*/
        _45emit_addr(_lhs_var_51970);

        /** emit.e:1180			emit_addr(a)*/
        _45emit_addr(_a_51962);

        /** emit.e:1181			if op = LHS_SUBS then*/
        if (_op_51960 != 95LL)
        goto L66; // [3616] 3647

        /** emit.e:1182				TempKeep(lhs_var) -- should be lhs_target_temp*/
        _45TempKeep(_lhs_var_51970);

        /** emit.e:1183				emit_addr(lhs_target_temp)*/
        _45emit_addr(_45lhs_target_temp_51034);

        /** emit.e:1184				Push(lhs_target_temp)*/
        _45Push(_45lhs_target_temp_51034);

        /** emit.e:1185				emit_addr(0) -- place holder*/
        _45emit_addr(0LL);
        goto L67; // [3644] 3701
L66: 

        /** emit.e:1189				lhs_target_temp = NewTempSym() -- use same temp for all subscripts*/
        _0 = _53NewTempSym(0LL);
        _45lhs_target_temp_51034 = _0;
        if (!IS_ATOM_INT(_45lhs_target_temp_51034)) {
            _1 = (object)(DBL_PTR(_45lhs_target_temp_51034)->dbl);
            DeRefDS(_45lhs_target_temp_51034);
            _45lhs_target_temp_51034 = _1;
        }

        /** emit.e:1190				emit_addr(lhs_target_temp) -- target temp holds pointer to sequence*/
        _45emit_addr(_45lhs_target_temp_51034);

        /** emit.e:1191				emit_temp(lhs_target_temp, NEW_REFERENCE )*/
        _45emit_temp(_45lhs_target_temp_51034, 1LL);

        /** emit.e:1192				Push(lhs_target_temp)*/
        _45Push(_45lhs_target_temp_51034);

        /** emit.e:1193				lhs_subs1_copy_temp = NewTempSym() -- place to copy (may be ignored)*/
        _0 = _53NewTempSym(0LL);
        _45lhs_subs1_copy_temp_51033 = _0;
        if (!IS_ATOM_INT(_45lhs_subs1_copy_temp_51033)) {
            _1 = (object)(DBL_PTR(_45lhs_subs1_copy_temp_51033)->dbl);
            DeRefDS(_45lhs_subs1_copy_temp_51033);
            _45lhs_subs1_copy_temp_51033 = _1;
        }

        /** emit.e:1194				emit_addr(lhs_subs1_copy_temp)*/
        _45emit_addr(_45lhs_subs1_copy_temp_51033);

        /** emit.e:1195				emit_temp( lhs_subs1_copy_temp, NEW_REFERENCE )*/
        _45emit_temp(_45lhs_subs1_copy_temp_51033, 1LL);
L67: 

        /** emit.e:1198			current_sequence = append(current_sequence, lhs_target_temp)*/
        Append(&_45current_sequence_51028, _45current_sequence_51028, _45lhs_target_temp_51034);

        /** emit.e:1199			assignable = FALSE  -- need to update current_sequence like in RHS_SUBS*/
        _45assignable_51038 = _9FALSE_444;
        goto LC; // [3718] 7739

        /** emit.e:1201		case PEEK_LONGS then*/
        case 436:

        /** emit.e:1202			if IWINDOWS or TWINDOWS or not (IX86_64 or TX86_64) then*/
        if (0LL != 0) {
            _26908 = 1;
            goto L68; // [3728] 3738
        }
        _26908 = (0LL != 0);
L68: 
        if (_26908 != 0) {
            goto L69; // [3738] 3762
        }
        if (_44IX86_64_20385 != 0) {
            DeRef(_26910);
            _26910 = 1;
            goto L6A; // [3744] 3754
        }
        _26910 = (_44TX86_64_20386 != 0);
L6A: 
        _26911 = (_26910 == 0);
        _26910 = NOVALUE;
        if (_26911 == 0)
        {
            DeRef(_26911);
            _26911 = NOVALUE;
            goto L6B; // [3758] 3774
        }
        else{
            DeRef(_26911);
            _26911 = NOVALUE;
        }
L69: 

        /** emit.e:1203				op = PEEK4S*/
        _op_51960 = 139LL;
        goto L6C; // [3771] 3784
L6B: 

        /** emit.e:1205				op = PEEK8S*/
        _op_51960 = 213LL;
L6C: 

        /** emit.e:1207			last_op = op*/
        _45last_op_51919 = _op_51960;

        /** emit.e:1208			cont11ii(op, TRUE )*/
        _45cont11ii(_op_51960, _9TRUE_446);
        goto LC; // [3797] 7739

        /** emit.e:1210		case PEEK_LONGU then*/
        case 435:

        /** emit.e:1211			if IWINDOWS or TWINDOWS or not (IX86_64 or TX86_64) then*/
        if (0LL != 0) {
            _26912 = 1;
            goto L6D; // [3807] 3817
        }
        _26912 = (0LL != 0);
L6D: 
        if (_26912 != 0) {
            goto L6E; // [3817] 3841
        }
        if (_44IX86_64_20385 != 0) {
            DeRef(_26914);
            _26914 = 1;
            goto L6F; // [3823] 3833
        }
        _26914 = (_44TX86_64_20386 != 0);
L6F: 
        _26915 = (_26914 == 0);
        _26914 = NOVALUE;
        if (_26915 == 0)
        {
            DeRef(_26915);
            _26915 = NOVALUE;
            goto L70; // [3837] 3853
        }
        else{
            DeRef(_26915);
            _26915 = NOVALUE;
        }
L6E: 

        /** emit.e:1212				op = PEEK4U*/
        _op_51960 = 140LL;
        goto L71; // [3850] 3863
L70: 

        /** emit.e:1214				op = PEEK8U*/
        _op_51960 = 214LL;
L71: 

        /** emit.e:1216			last_op = op*/
        _45last_op_51919 = _op_51960;

        /** emit.e:1217			cont11ii(op, TRUE )*/
        _45cont11ii(_op_51960, _9TRUE_446);
        goto LC; // [3876] 7739

        /** emit.e:1220		case RAND, PEEK, PEEK4S, PEEK4U, NOT_BITS, NOT, PEEK8U, PEEK8S, SIZEOF,*/
        case 62:
        case 127:
        case 139:
        case 140:
        case 51:
        case 7:
        case 214:
        case 213:
        case 217:
        case 173:
        case 180:
        case 179:
        case 181:
        case 182:
        case 216:

        /** emit.e:1222			cont11ii(op, TRUE)*/
        _45cont11ii(_op_51960, _9TRUE_446);
        goto LC; // [3918] 7739

        /** emit.e:1224		case UMINUS then*/
        case 12:

        /** emit.e:1226			a = Pop()*/
        _a_51962 = _45Pop();
        if (!IS_ATOM_INT(_a_51962)) {
            _1 = (object)(DBL_PTR(_a_51962)->dbl);
            DeRefDS(_a_51962);
            _a_51962 = _1;
        }

        /** emit.e:1228			if a > 0 then*/
        if (_a_51962 <= 0LL)
        goto L72; // [3933] 4180

        /** emit.e:1229				obj = SymTab[a][S_OBJ]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26918 = (object)*(((s1_ptr)_2)->base + _a_51962);
        DeRef(_obj_51974);
        _2 = (object)SEQ_PTR(_26918);
        _obj_51974 = (object)*(((s1_ptr)_2)->base + 1LL);
        Ref(_obj_51974);
        _26918 = NOVALUE;

        /** emit.e:1230				if SymTab[a][S_MODE] = M_CONSTANT then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26920 = (object)*(((s1_ptr)_2)->base + _a_51962);
        _2 = (object)SEQ_PTR(_26920);
        _26921 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26920 = NOVALUE;
        if (binary_op_a(NOTEQ, _26921, 2LL)){
            _26921 = NOVALUE;
            goto L73; // [3967] 4092
        }
        _26921 = NOVALUE;

        /** emit.e:1231					if is_integer(obj) then*/
        Ref(_obj_51974);
        _26923 = _12is_integer(_obj_51974);
        if (_26923 == 0) {
            DeRef(_26923);
            _26923 = NOVALUE;
            goto L74; // [3977] 4031
        }
        else {
            if (!IS_ATOM_INT(_26923) && DBL_PTR(_26923)->dbl == 0.0){
                DeRef(_26923);
                _26923 = NOVALUE;
                goto L74; // [3977] 4031
            }
            DeRef(_26923);
            _26923 = NOVALUE;
        }
        DeRef(_26923);
        _26923 = NOVALUE;

        /** emit.e:1232						if obj = MININT then*/
        if (binary_op_a(NOTEQ, _obj_51974, _12MININT_20051)){
            goto L75; // [3984] 4005
        }

        /** emit.e:1233							Push(NewDoubleSym(-MININT))*/
        if (IS_ATOM_INT(_12MININT_20051)) {
            if ((uintptr_t)_12MININT_20051 == (uintptr_t)HIGH_BITS){
                _26925 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _26925 = - _12MININT_20051;
            }
        }
        else {
            _26925 = unary_op(UMINUS, _12MININT_20051);
        }
        _26926 = _53NewDoubleSym(_26925);
        _26925 = NOVALUE;
        _45Push(_26926);
        _26926 = NOVALUE;
        goto L76; // [4002] 4018
L75: 

        /** emit.e:1235							Push(NewIntSym(-obj))*/
        if (IS_ATOM_INT(_obj_51974)) {
            if ((uintptr_t)_obj_51974 == (uintptr_t)HIGH_BITS){
                _26927 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _26927 = - _obj_51974;
            }
        }
        else {
            _26927 = unary_op(UMINUS, _obj_51974);
        }
        _26928 = _53NewIntSym(_26927);
        _26927 = NOVALUE;
        _45Push(_26928);
        _26928 = NOVALUE;
L76: 

        /** emit.e:1237						last_pc = last_pc_backup*/
        _45last_pc_51920 = _last_pc_backup_51977;

        /** emit.e:1238						last_op = last_op_backup*/
        _45last_op_51919 = _last_op_backup_51978;
        goto LC; // [4028] 7739
L74: 

        /** emit.e:1240					elsif atom(obj) and obj != NOVALUE then*/
        _26929 = IS_ATOM(_obj_51974);
        if (_26929 == 0) {
            goto L77; // [4036] 4075
        }
        if (IS_ATOM_INT(_obj_51974) && IS_ATOM_INT(_12NOVALUE_20081)) {
            _26931 = (_obj_51974 != _12NOVALUE_20081);
        }
        else {
            _26931 = binary_op(NOTEQ, _obj_51974, _12NOVALUE_20081);
        }
        if (_26931 == 0) {
            DeRef(_26931);
            _26931 = NOVALUE;
            goto L77; // [4047] 4075
        }
        else {
            if (!IS_ATOM_INT(_26931) && DBL_PTR(_26931)->dbl == 0.0){
                DeRef(_26931);
                _26931 = NOVALUE;
                goto L77; // [4047] 4075
            }
            DeRef(_26931);
            _26931 = NOVALUE;
        }
        DeRef(_26931);
        _26931 = NOVALUE;

        /** emit.e:1245						Push(NewDoubleSym(-obj))*/
        if (IS_ATOM_INT(_obj_51974)) {
            if ((uintptr_t)_obj_51974 == (uintptr_t)HIGH_BITS){
                _26932 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _26932 = - _obj_51974;
            }
        }
        else {
            _26932 = unary_op(UMINUS, _obj_51974);
        }
        _26933 = _53NewDoubleSym(_26932);
        _26932 = NOVALUE;
        _45Push(_26933);
        _26933 = NOVALUE;

        /** emit.e:1246						last_pc = last_pc_backup*/
        _45last_pc_51920 = _last_pc_backup_51977;

        /** emit.e:1247						last_op = last_op_backup*/
        _45last_op_51919 = _last_op_backup_51978;
        goto LC; // [4072] 7739
L77: 

        /** emit.e:1250						Push(a)*/
        _45Push(_a_51962);

        /** emit.e:1251						cont11ii(op, FALSE)*/
        _45cont11ii(_op_51960, _9FALSE_444);
        goto LC; // [4089] 7739
L73: 

        /** emit.e:1254				elsif TRANSLATE and SymTab[a][S_MODE] = M_TEMP and*/
        if (_12TRANSLATE_19834 == 0) {
            _26934 = 0;
            goto L78; // [4096] 4122
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26935 = (object)*(((s1_ptr)_2)->base + _a_51962);
        _2 = (object)SEQ_PTR(_26935);
        _26936 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26935 = NOVALUE;
        if (IS_ATOM_INT(_26936)) {
            _26937 = (_26936 == 3LL);
        }
        else {
            _26937 = binary_op(EQUALS, _26936, 3LL);
        }
        _26936 = NOVALUE;
        if (IS_ATOM_INT(_26937))
        _26934 = (_26937 != 0);
        else
        _26934 = DBL_PTR(_26937)->dbl != 0.0;
L78: 
        if (_26934 == 0) {
            goto L79; // [4122] 4163
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26939 = (object)*(((s1_ptr)_2)->base + _a_51962);
        _2 = (object)SEQ_PTR(_26939);
        _26940 = (object)*(((s1_ptr)_2)->base + 36LL);
        _26939 = NOVALUE;
        if (IS_ATOM_INT(_26940)) {
            _26941 = (_26940 == 2LL);
        }
        else {
            _26941 = binary_op(EQUALS, _26940, 2LL);
        }
        _26940 = NOVALUE;
        if (_26941 == 0) {
            DeRef(_26941);
            _26941 = NOVALUE;
            goto L79; // [4145] 4163
        }
        else {
            if (!IS_ATOM_INT(_26941) && DBL_PTR(_26941)->dbl == 0.0){
                DeRef(_26941);
                _26941 = NOVALUE;
                goto L79; // [4145] 4163
            }
            DeRef(_26941);
            _26941 = NOVALUE;
        }
        DeRef(_26941);
        _26941 = NOVALUE;

        /** emit.e:1256					Push(NewDoubleSym(-obj))*/
        if (IS_ATOM_INT(_obj_51974)) {
            if ((uintptr_t)_obj_51974 == (uintptr_t)HIGH_BITS){
                _26942 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _26942 = - _obj_51974;
            }
        }
        else {
            _26942 = unary_op(UMINUS, _obj_51974);
        }
        _26943 = _53NewDoubleSym(_26942);
        _26942 = NOVALUE;
        _45Push(_26943);
        _26943 = NOVALUE;
        goto LC; // [4160] 7739
L79: 

        /** emit.e:1259					Push(a)*/
        _45Push(_a_51962);

        /** emit.e:1260					cont11ii(op, FALSE)*/
        _45cont11ii(_op_51960, _9FALSE_444);
        goto LC; // [4177] 7739
L72: 

        /** emit.e:1263				Push(a)*/
        _45Push(_a_51962);

        /** emit.e:1264				cont11ii(op, FALSE)*/
        _45cont11ii(_op_51960, _9FALSE_444);
        goto LC; // [4194] 7739

        /** emit.e:1267		case LENGTH, GETC, SQRT, SIN, COS, TAN, ARCTAN, LOG, GETS, GETENV then*/
        case 42:
        case 33:
        case 41:
        case 80:
        case 81:
        case 82:
        case 73:
        case 74:
        case 17:
        case 91:

        /** emit.e:1268			cont11ii(op, FALSE)*/
        _45cont11ii(_op_51960, _9FALSE_444);
        goto LC; // [4226] 7739

        /** emit.e:1270		case IS_AN_INTEGER, IS_AN_ATOM, IS_A_SEQUENCE, IS_AN_OBJECT then*/
        case 94:
        case 67:
        case 68:
        case 40:

        /** emit.e:1271			cont11ii(op, FALSE)*/
        _45cont11ii(_op_51960, _9FALSE_444);
        goto LC; // [4246] 7739

        /** emit.e:1275		case ROUTINE_ID then*/
        case 134:

        /** emit.e:1276			emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1277			source = Pop()*/
        _source_51966 = _45Pop();
        if (!IS_ATOM_INT(_source_51966)) {
            _1 = (object)(DBL_PTR(_source_51966)->dbl);
            DeRefDS(_source_51966);
            _source_51966 = _1;
        }

        /** emit.e:1278			if TRANSLATE then*/
        if (_12TRANSLATE_19834 == 0)
        {
            goto L7A; // [4268] 4312
        }
        else{
        }

        /** emit.e:1279				emit_addr(num_routines-1)*/
        _26945 = _12num_routines_20235 - 1LL;
        if ((object)((uintptr_t)_26945 +(uintptr_t) HIGH_BITS) >= 0){
            _26945 = NewDouble((eudouble)_26945);
        }
        _45emit_addr(_26945);
        _26945 = NOVALUE;

        /** emit.e:1280				last_routine_id = num_routines*/
        _45last_routine_id_51025 = _12num_routines_20235;

        /** emit.e:1281				last_max_params = max_params*/
        _45last_max_params_51027 = _45max_params_51026;

        /** emit.e:1282				MarkTargets(source, S_RI_TARGET)*/
        _31791 = _53MarkTargets(_source_51966, 53LL);
        DeRef(_31791);
        _31791 = NOVALUE;
        goto L7B; // [4309] 4349
L7A: 

        /** emit.e:1285				emit_addr(CurrentSub)*/
        _45emit_addr(_12CurrentSub_20234);

        /** emit.e:1286				emit_addr(length(SymTab))*/
        if (IS_SEQUENCE(_13SymTab_11316)){
                _26946 = SEQ_PTR(_13SymTab_11316)->length;
        }
        else {
            _26946 = 1;
        }
        _45emit_addr(_26946);
        _26946 = NOVALUE;

        /** emit.e:1288				if BIND then*/
        if (_12BIND_19837 == 0)
        {
            goto L7C; // [4333] 4348
        }
        else{
        }

        /** emit.e:1290					MarkTargets(source, S_NREFS)*/
        _31790 = _53MarkTargets(_source_51966, 12LL);
        DeRef(_31790);
        _31790 = NOVALUE;
L7C: 
L7B: 

        /** emit.e:1294			emit_addr(source)*/
        _45emit_addr(_source_51966);

        /** emit.e:1295			emit_addr(current_file_no)  -- necessary at top level*/
        _45emit_addr(_12current_file_no_20226);

        /** emit.e:1296			assignable = TRUE*/
        _45assignable_51038 = _9TRUE_446;

        /** emit.e:1297			c = NewTempSym()*/
        _c_51964 = _53NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_51964)) {
            _1 = (object)(DBL_PTR(_c_51964)->dbl);
            DeRefDS(_c_51964);
            _c_51964 = _1;
        }

        /** emit.e:1298			TempInteger(c) -- result will always be an integer*/
        _45TempInteger(_c_51964);

        /** emit.e:1299			Push(c)*/
        _45Push(_c_51964);

        /** emit.e:1300			emit_addr(c)*/
        _45emit_addr(_c_51964);
        goto LC; // [4391] 7739

        /** emit.e:1305		case SC1_OR, SC1_AND then*/
        case 143:
        case 141:

        /** emit.e:1306			emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1307			emit_addr(Pop())*/
        _26948 = _45Pop();
        _45emit_addr(_26948);
        _26948 = NOVALUE;

        /** emit.e:1308			c = NewTempSym()*/
        _c_51964 = _53NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_51964)) {
            _1 = (object)(DBL_PTR(_c_51964)->dbl);
            DeRefDS(_c_51964);
            _c_51964 = _1;
        }

        /** emit.e:1309			Push(c)*/
        _45Push(_c_51964);

        /** emit.e:1310			emit_addr(c)*/
        _45emit_addr(_c_51964);

        /** emit.e:1311			assignable = FALSE*/
        _45assignable_51038 = _9FALSE_444;
        goto LC; // [4437] 7739

        /** emit.e:1315		case POKE_LONG then*/
        case 434:

        /** emit.e:1316			if IWINDOWS or TWINDOWS or not (IX86_64 or TX86_64) then*/
        if (0LL != 0) {
            _26950 = 1;
            goto L7D; // [4447] 4457
        }
        _26950 = (0LL != 0);
L7D: 
        if (_26950 != 0) {
            goto L7E; // [4457] 4481
        }
        if (_44IX86_64_20385 != 0) {
            DeRef(_26952);
            _26952 = 1;
            goto L7F; // [4463] 4473
        }
        _26952 = (_44TX86_64_20386 != 0);
L7F: 
        _26953 = (_26952 == 0);
        _26952 = NOVALUE;
        if (_26953 == 0)
        {
            DeRef(_26953);
            _26953 = NOVALUE;
            goto L80; // [4477] 4493
        }
        else{
            DeRef(_26953);
            _26953 = NOVALUE;
        }
L7E: 

        /** emit.e:1317				op = POKE4*/
        _op_51960 = 138LL;
        goto L81; // [4490] 4503
L80: 

        /** emit.e:1319				op = POKE8*/
        _op_51960 = 212LL;
L81: 

        /** emit.e:1321			last_op = op*/
        _45last_op_51919 = _op_51960;

        /** emit.e:1324		case SYSTEM, PUTS, PRINT, QPRINT, POSITION, MACHINE_PROC,*/
        case 99:
        case 44:
        case 19:
        case 36:
        case 60:
        case 112:
        case 132:
        case 128:
        case 138:
        case 168:
        case 178:
        case 212:
        case 215:

        /** emit.e:1326			emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1328			b = Pop()*/
        _b_51963 = _45Pop();
        if (!IS_ATOM_INT(_b_51963)) {
            _1 = (object)(DBL_PTR(_b_51963)->dbl);
            DeRefDS(_b_51963);
            _b_51963 = _1;
        }

        /** emit.e:1329			emit_addr(Pop())*/
        _26955 = _45Pop();
        _45emit_addr(_26955);
        _26955 = NOVALUE;

        /** emit.e:1330			emit_addr(b)*/
        _45emit_addr(_b_51963);

        /** emit.e:1331			if op = C_PROC then*/
        if (_op_51960 != 132LL)
        goto L82; // [4565] 4577

        /** emit.e:1332				emit_addr(CurrentSub)*/
        _45emit_addr(_12CurrentSub_20234);
L82: 

        /** emit.e:1334			assignable = FALSE*/
        _45assignable_51038 = _9FALSE_444;
        goto LC; // [4584] 7739

        /** emit.e:1337		case EQUALS, LESS, GREATER, NOTEQ, LESSEQ, GREATEREQ,*/
        case 3:
        case 1:
        case 6:
        case 4:
        case 5:
        case 2:
        case 8:
        case 9:
        case 152:
        case 71:
        case 56:
        case 24:
        case 26:

        /** emit.e:1339			cont21ii(op, TRUE)  -- both integer args => integer result*/
        _45cont21ii(_op_51960, _9TRUE_446);
        goto LC; // [4622] 7739

        /** emit.e:1341		case PLUS then -- elsif op = PLUS then*/
        case 11:

        /** emit.e:1343			b = Pop()*/
        _b_51963 = _45Pop();
        if (!IS_ATOM_INT(_b_51963)) {
            _1 = (object)(DBL_PTR(_b_51963)->dbl);
            DeRefDS(_b_51963);
            _b_51963 = _1;
        }

        /** emit.e:1344			a = Pop()*/
        _a_51962 = _45Pop();
        if (!IS_ATOM_INT(_a_51962)) {
            _1 = (object)(DBL_PTR(_a_51962)->dbl);
            DeRefDS(_a_51962);
            _a_51962 = _1;
        }

        /** emit.e:1346			if b < 1 or a < 1 then*/
        _26959 = (_b_51963 < 1LL);
        if (_26959 != 0) {
            goto L83; // [4648] 4661
        }
        _26961 = (_a_51962 < 1LL);
        if (_26961 == 0)
        {
            DeRef(_26961);
            _26961 = NOVALUE;
            goto L84; // [4657] 4682
        }
        else{
            DeRef(_26961);
            _26961 = NOVALUE;
        }
L83: 

        /** emit.e:1347				Push(a)*/
        _45Push(_a_51962);

        /** emit.e:1348				Push(b)*/
        _45Push(_b_51963);

        /** emit.e:1349				cont21ii(op, FALSE)*/
        _45cont21ii(_op_51960, _9FALSE_444);
        goto LC; // [4679] 7739
L84: 

        /** emit.e:1350			elsif SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 1) then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26962 = (object)*(((s1_ptr)_2)->base + _b_51963);
        _2 = (object)SEQ_PTR(_26962);
        _26963 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26962 = NOVALUE;
        if (IS_ATOM_INT(_26963)) {
            _26964 = (_26963 == 2LL);
        }
        else {
            _26964 = binary_op(EQUALS, _26963, 2LL);
        }
        _26963 = NOVALUE;
        if (IS_ATOM_INT(_26964)) {
            if (_26964 == 0) {
                goto L85; // [4702] 4763
            }
        }
        else {
            if (DBL_PTR(_26964)->dbl == 0.0) {
                goto L85; // [4702] 4763
            }
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26966 = (object)*(((s1_ptr)_2)->base + _b_51963);
        _2 = (object)SEQ_PTR(_26966);
        _26967 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26966 = NOVALUE;
        if (_26967 == 1LL)
        _26968 = 1;
        else if (IS_ATOM_INT(_26967) && IS_ATOM_INT(1LL))
        _26968 = 0;
        else
        _26968 = (compare(_26967, 1LL) == 0);
        _26967 = NOVALUE;
        if (_26968 == 0)
        {
            _26968 = NOVALUE;
            goto L85; // [4723] 4763
        }
        else{
            _26968 = NOVALUE;
        }

        /** emit.e:1351				op = PLUS1*/
        _op_51960 = 93LL;

        /** emit.e:1352				emit_opcode(op)*/
        _45emit_opcode(93LL);

        /** emit.e:1353				emit_addr(a)*/
        _45emit_addr(_a_51962);

        /** emit.e:1354				emit_addr(0)*/
        _45emit_addr(0LL);

        /** emit.e:1355				cont21d(op, a, b, FALSE)*/
        _45cont21d(93LL, _a_51962, _b_51963, _9FALSE_444);
        goto LC; // [4760] 7739
L85: 

        /** emit.e:1356			elsif SymTab[a][S_MODE] = M_CONSTANT and equal(SymTab[a][S_OBJ], 1) then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26969 = (object)*(((s1_ptr)_2)->base + _a_51962);
        _2 = (object)SEQ_PTR(_26969);
        _26970 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26969 = NOVALUE;
        if (IS_ATOM_INT(_26970)) {
            _26971 = (_26970 == 2LL);
        }
        else {
            _26971 = binary_op(EQUALS, _26970, 2LL);
        }
        _26970 = NOVALUE;
        if (IS_ATOM_INT(_26971)) {
            if (_26971 == 0) {
                goto L86; // [4783] 4844
            }
        }
        else {
            if (DBL_PTR(_26971)->dbl == 0.0) {
                goto L86; // [4783] 4844
            }
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26973 = (object)*(((s1_ptr)_2)->base + _a_51962);
        _2 = (object)SEQ_PTR(_26973);
        _26974 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26973 = NOVALUE;
        if (_26974 == 1LL)
        _26975 = 1;
        else if (IS_ATOM_INT(_26974) && IS_ATOM_INT(1LL))
        _26975 = 0;
        else
        _26975 = (compare(_26974, 1LL) == 0);
        _26974 = NOVALUE;
        if (_26975 == 0)
        {
            _26975 = NOVALUE;
            goto L86; // [4804] 4844
        }
        else{
            _26975 = NOVALUE;
        }

        /** emit.e:1357				op = PLUS1*/
        _op_51960 = 93LL;

        /** emit.e:1358				emit_opcode(op)*/
        _45emit_opcode(93LL);

        /** emit.e:1359				emit_addr(b)*/
        _45emit_addr(_b_51963);

        /** emit.e:1360				emit_addr(0)*/
        _45emit_addr(0LL);

        /** emit.e:1361				cont21d(op, a, b, FALSE)*/
        _45cont21d(93LL, _a_51962, _b_51963, _9FALSE_444);
        goto LC; // [4841] 7739
L86: 

        /** emit.e:1363				Push(a)*/
        _45Push(_a_51962);

        /** emit.e:1364				Push(b)*/
        _45Push(_b_51963);

        /** emit.e:1365				cont21ii(op, FALSE)*/
        _45cont21ii(_op_51960, _9FALSE_444);
        goto LC; // [4863] 7739

        /** emit.e:1368		case rw:MULTIPLY then*/
        case 13:

        /** emit.e:1370			b = Pop()*/
        _b_51963 = _45Pop();
        if (!IS_ATOM_INT(_b_51963)) {
            _1 = (object)(DBL_PTR(_b_51963)->dbl);
            DeRefDS(_b_51963);
            _b_51963 = _1;
        }

        /** emit.e:1371			a = Pop()*/
        _a_51962 = _45Pop();
        if (!IS_ATOM_INT(_a_51962)) {
            _1 = (object)(DBL_PTR(_a_51962)->dbl);
            DeRefDS(_a_51962);
            _a_51962 = _1;
        }

        /** emit.e:1372			if a < 1 or b < 1 then*/
        _26978 = (_a_51962 < 1LL);
        if (_26978 != 0) {
            goto L87; // [4889] 4902
        }
        _26980 = (_b_51963 < 1LL);
        if (_26980 == 0)
        {
            DeRef(_26980);
            _26980 = NOVALUE;
            goto L88; // [4898] 4923
        }
        else{
            DeRef(_26980);
            _26980 = NOVALUE;
        }
L87: 

        /** emit.e:1373				Push(a)*/
        _45Push(_a_51962);

        /** emit.e:1374				Push(b)*/
        _45Push(_b_51963);

        /** emit.e:1375				cont21ii(op, FALSE)*/
        _45cont21ii(_op_51960, _9FALSE_444);
        goto LC; // [4920] 7739
L88: 

        /** emit.e:1377			elsif SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 2) then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26981 = (object)*(((s1_ptr)_2)->base + _b_51963);
        _2 = (object)SEQ_PTR(_26981);
        _26982 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26981 = NOVALUE;
        if (IS_ATOM_INT(_26982)) {
            _26983 = (_26982 == 2LL);
        }
        else {
            _26983 = binary_op(EQUALS, _26982, 2LL);
        }
        _26982 = NOVALUE;
        if (IS_ATOM_INT(_26983)) {
            if (_26983 == 0) {
                goto L89; // [4943] 5004
            }
        }
        else {
            if (DBL_PTR(_26983)->dbl == 0.0) {
                goto L89; // [4943] 5004
            }
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26985 = (object)*(((s1_ptr)_2)->base + _b_51963);
        _2 = (object)SEQ_PTR(_26985);
        _26986 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26985 = NOVALUE;
        if (_26986 == 2LL)
        _26987 = 1;
        else if (IS_ATOM_INT(_26986) && IS_ATOM_INT(2LL))
        _26987 = 0;
        else
        _26987 = (compare(_26986, 2LL) == 0);
        _26986 = NOVALUE;
        if (_26987 == 0)
        {
            _26987 = NOVALUE;
            goto L89; // [4964] 5004
        }
        else{
            _26987 = NOVALUE;
        }

        /** emit.e:1379				op = PLUS*/
        _op_51960 = 11LL;

        /** emit.e:1380				emit_opcode(op)*/
        _45emit_opcode(11LL);

        /** emit.e:1381				emit_addr(a)*/
        _45emit_addr(_a_51962);

        /** emit.e:1382				emit_addr(a)*/
        _45emit_addr(_a_51962);

        /** emit.e:1383				cont21d(op, a, b, FALSE)*/
        _45cont21d(11LL, _a_51962, _b_51963, _9FALSE_444);
        goto LC; // [5001] 7739
L89: 

        /** emit.e:1385			elsif SymTab[a][S_MODE] = M_CONSTANT and equal(SymTab[a][S_OBJ], 2) then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26988 = (object)*(((s1_ptr)_2)->base + _a_51962);
        _2 = (object)SEQ_PTR(_26988);
        _26989 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26988 = NOVALUE;
        if (IS_ATOM_INT(_26989)) {
            _26990 = (_26989 == 2LL);
        }
        else {
            _26990 = binary_op(EQUALS, _26989, 2LL);
        }
        _26989 = NOVALUE;
        if (IS_ATOM_INT(_26990)) {
            if (_26990 == 0) {
                goto L8A; // [5024] 5085
            }
        }
        else {
            if (DBL_PTR(_26990)->dbl == 0.0) {
                goto L8A; // [5024] 5085
            }
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26992 = (object)*(((s1_ptr)_2)->base + _a_51962);
        _2 = (object)SEQ_PTR(_26992);
        _26993 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26992 = NOVALUE;
        if (_26993 == 2LL)
        _26994 = 1;
        else if (IS_ATOM_INT(_26993) && IS_ATOM_INT(2LL))
        _26994 = 0;
        else
        _26994 = (compare(_26993, 2LL) == 0);
        _26993 = NOVALUE;
        if (_26994 == 0)
        {
            _26994 = NOVALUE;
            goto L8A; // [5045] 5085
        }
        else{
            _26994 = NOVALUE;
        }

        /** emit.e:1386				op = PLUS*/
        _op_51960 = 11LL;

        /** emit.e:1387				emit_opcode(op)*/
        _45emit_opcode(11LL);

        /** emit.e:1388				emit_addr(b)*/
        _45emit_addr(_b_51963);

        /** emit.e:1389				emit_addr(b)*/
        _45emit_addr(_b_51963);

        /** emit.e:1390				cont21d(op, a, b, FALSE)*/
        _45cont21d(11LL, _a_51962, _b_51963, _9FALSE_444);
        goto LC; // [5082] 7739
L8A: 

        /** emit.e:1393				Push(a)*/
        _45Push(_a_51962);

        /** emit.e:1394				Push(b)*/
        _45Push(_b_51963);

        /** emit.e:1395				cont21ii(op, FALSE)*/
        _45cont21ii(_op_51960, _9FALSE_444);
        goto LC; // [5104] 7739

        /** emit.e:1399		case rw:DIVIDE then*/
        case 14:

        /** emit.e:1400			b = Pop()*/
        _b_51963 = _45Pop();
        if (!IS_ATOM_INT(_b_51963)) {
            _1 = (object)(DBL_PTR(_b_51963)->dbl);
            DeRefDS(_b_51963);
            _b_51963 = _1;
        }

        /** emit.e:1401			if b > 0 and SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 2) then*/
        _26996 = (_b_51963 > 0LL);
        if (_26996 == 0) {
            _26997 = 0;
            goto L8B; // [5123] 5149
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _26998 = (object)*(((s1_ptr)_2)->base + _b_51963);
        _2 = (object)SEQ_PTR(_26998);
        _26999 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26998 = NOVALUE;
        if (IS_ATOM_INT(_26999)) {
            _27000 = (_26999 == 2LL);
        }
        else {
            _27000 = binary_op(EQUALS, _26999, 2LL);
        }
        _26999 = NOVALUE;
        if (IS_ATOM_INT(_27000))
        _26997 = (_27000 != 0);
        else
        _26997 = DBL_PTR(_27000)->dbl != 0.0;
L8B: 
        if (_26997 == 0) {
            goto L8C; // [5149] 5220
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _27002 = (object)*(((s1_ptr)_2)->base + _b_51963);
        _2 = (object)SEQ_PTR(_27002);
        _27003 = (object)*(((s1_ptr)_2)->base + 1LL);
        _27002 = NOVALUE;
        if (_27003 == 2LL)
        _27004 = 1;
        else if (IS_ATOM_INT(_27003) && IS_ATOM_INT(2LL))
        _27004 = 0;
        else
        _27004 = (compare(_27003, 2LL) == 0);
        _27003 = NOVALUE;
        if (_27004 == 0)
        {
            _27004 = NOVALUE;
            goto L8C; // [5170] 5220
        }
        else{
            _27004 = NOVALUE;
        }

        /** emit.e:1402				op = DIV2*/
        _op_51960 = 98LL;

        /** emit.e:1403				emit_opcode(op)*/
        _45emit_opcode(98LL);

        /** emit.e:1404				emit_addr(Pop()) -- n.b. "a" hasn't been set*/
        _27005 = _45Pop();
        _45emit_addr(_27005);
        _27005 = NOVALUE;

        /** emit.e:1405				a = 0*/
        _a_51962 = 0LL;

        /** emit.e:1406				emit_addr(0)*/
        _45emit_addr(0LL);

        /** emit.e:1407				cont21d(op, a, b, FALSE)  -- could have fractional result*/
        _45cont21d(98LL, 0LL, _b_51963, _9FALSE_444);
        goto LC; // [5217] 7739
L8C: 

        /** emit.e:1409				Push(b)*/
        _45Push(_b_51963);

        /** emit.e:1410				cont21ii(op, FALSE)*/
        _45cont21ii(_op_51960, _9FALSE_444);
        goto LC; // [5234] 7739

        /** emit.e:1413		case FLOOR then*/
        case 83:

        /** emit.e:1414			if previous_op = rw:DIVIDE then*/
        if (_12previous_op_20325 != 14LL)
        goto L8D; // [5244] 5292

        /** emit.e:1415				op = FLOOR_DIV*/
        _op_51960 = 63LL;

        /** emit.e:1416				backpatch(length(Code) - 3, op)*/
        if (IS_SEQUENCE(_12Code_20315)){
                _27007 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _27007 = 1;
        }
        _27008 = _27007 - 3LL;
        _27007 = NOVALUE;
        _45backpatch(_27008, 63LL);
        _27008 = NOVALUE;

        /** emit.e:1417				assignable = TRUE*/
        _45assignable_51038 = _9TRUE_446;

        /** emit.e:1418				last_op = op*/
        _45last_op_51919 = 63LL;

        /** emit.e:1419				last_pc = last_pc_backup*/
        _45last_pc_51920 = _last_pc_backup_51977;
        goto LC; // [5289] 7739
L8D: 

        /** emit.e:1421			elsif previous_op = DIV2 then*/
        if (_12previous_op_20325 != 98LL)
        goto L8E; // [5298] 5385

        /** emit.e:1422				op = FLOOR_DIV2*/
        _op_51960 = 66LL;

        /** emit.e:1423				backpatch(length(Code) - 3, op)*/
        if (IS_SEQUENCE(_12Code_20315)){
                _27010 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _27010 = 1;
        }
        _27011 = _27010 - 3LL;
        _27010 = NOVALUE;
        _45backpatch(_27011, 66LL);
        _27011 = NOVALUE;

        /** emit.e:1424				assignable = TRUE*/
        _45assignable_51038 = _9TRUE_446;

        /** emit.e:1425				if IsInteger(Code[$-2]) then*/
        if (IS_SEQUENCE(_12Code_20315)){
                _27012 = SEQ_PTR(_12Code_20315)->length;
        }
        else {
            _27012 = 1;
        }
        _27013 = _27012 - 2LL;
        _27012 = NOVALUE;
        _2 = (object)SEQ_PTR(_12Code_20315);
        _27014 = (object)*(((s1_ptr)_2)->base + _27013);
        Ref(_27014);
        _27015 = _45IsInteger(_27014);
        _27014 = NOVALUE;
        if (_27015 == 0) {
            DeRef(_27015);
            _27015 = NOVALUE;
            goto L8F; // [5352] 5372
        }
        else {
            if (!IS_ATOM_INT(_27015) && DBL_PTR(_27015)->dbl == 0.0){
                DeRef(_27015);
                _27015 = NOVALUE;
                goto L8F; // [5352] 5372
            }
            DeRef(_27015);
            _27015 = NOVALUE;
        }
        DeRef(_27015);
        _27015 = NOVALUE;

        /** emit.e:1426					TempInteger(Top()) --mark temp as integer type*/

        /** emit.e:145		return cg_stack[cgi]*/
        DeRef(_Top_inlined_Top_at_5482_53062);
        _2 = (object)SEQ_PTR(_45cg_stack_51035);
        _Top_inlined_Top_at_5482_53062 = (object)*(((s1_ptr)_2)->base + _45cgi_51036);
        Ref(_Top_inlined_Top_at_5482_53062);
        Ref(_Top_inlined_Top_at_5482_53062);
        _45TempInteger(_Top_inlined_Top_at_5482_53062);
L8F: 

        /** emit.e:1428				last_op = op*/
        _45last_op_51919 = _op_51960;

        /** emit.e:1429				last_pc = last_pc_backup*/
        _45last_pc_51920 = _last_pc_backup_51977;
        goto LC; // [5382] 7739
L8E: 

        /** emit.e:1431				cont11ii(op, TRUE)*/
        _45cont11ii(_op_51960, _9TRUE_446);
        goto LC; // [5394] 7739

        /** emit.e:1437		case MINUS, rw:APPEND, PREPEND, COMPARE, EQUAL,*/
        case 10:
        case 35:
        case 57:
        case 76:
        case 153:
        case 154:
        case 15:
        case 32:
        case 111:
        case 133:
        case 53:
        case 167:
        case 194:
        case 198:
        case 199:
        case 204:

        /** emit.e:1440			cont21ii(op, FALSE)*/
        _45cont21ii(_op_51960, _9FALSE_444);
        goto LC; // [5438] 7739

        /** emit.e:1442		case SC2_NULL then  -- correct the stack - we aren't emitting anything*/
        case 145:

        /** emit.e:1443			c = Pop()*/
        _c_51964 = _45Pop();
        if (!IS_ATOM_INT(_c_51964)) {
            _1 = (object)(DBL_PTR(_c_51964)->dbl);
            DeRefDS(_c_51964);
            _c_51964 = _1;
        }

        /** emit.e:1444			TempKeep(c)*/
        _45TempKeep(_c_51964);

        /** emit.e:1445			b = Pop()  -- remove SC1's temp*/
        _b_51963 = _45Pop();
        if (!IS_ATOM_INT(_b_51963)) {
            _1 = (object)(DBL_PTR(_b_51963)->dbl);
            DeRefDS(_b_51963);
            _b_51963 = _1;
        }

        /** emit.e:1446			Push(c)*/
        _45Push(_c_51964);

        /** emit.e:1447			assignable = FALSE*/
        _45assignable_51038 = _9FALSE_444;

        /** emit.e:1448			last_op = last_op_backup*/
        _45last_op_51919 = _last_op_backup_51978;

        /** emit.e:1449			last_pc = last_pc_backup*/
        _45last_pc_51920 = _last_pc_backup_51977;
        goto LC; // [5485] 7739

        /** emit.e:1452		case SC2_AND, SC2_OR then*/
        case 142:
        case 144:

        /** emit.e:1453			emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1454			emit_addr(Pop())*/
        _27018 = _45Pop();
        _45emit_addr(_27018);
        _27018 = NOVALUE;

        /** emit.e:1455			c = Pop()*/
        _c_51964 = _45Pop();
        if (!IS_ATOM_INT(_c_51964)) {
            _1 = (object)(DBL_PTR(_c_51964)->dbl);
            DeRefDS(_c_51964);
            _c_51964 = _1;
        }

        /** emit.e:1456			TempKeep(c)*/
        _45TempKeep(_c_51964);

        /** emit.e:1457			emit_addr(c) -- target*/
        _45emit_addr(_c_51964);

        /** emit.e:1458			TempInteger(c)*/
        _45TempInteger(_c_51964);

        /** emit.e:1459			Push(c)*/
        _45Push(_c_51964);

        /** emit.e:1460			assignable = FALSE*/
        _45assignable_51038 = _9FALSE_444;
        goto LC; // [5540] 7739

        /** emit.e:1463		case MEM_COPY, MEM_SET, PRINTF then*/
        case 130:
        case 131:
        case 38:

        /** emit.e:1464			emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1465			c = Pop()*/
        _c_51964 = _45Pop();
        if (!IS_ATOM_INT(_c_51964)) {
            _1 = (object)(DBL_PTR(_c_51964)->dbl);
            DeRefDS(_c_51964);
            _c_51964 = _1;
        }

        /** emit.e:1466			b = Pop()*/
        _b_51963 = _45Pop();
        if (!IS_ATOM_INT(_b_51963)) {
            _1 = (object)(DBL_PTR(_b_51963)->dbl);
            DeRefDS(_b_51963);
            _b_51963 = _1;
        }

        /** emit.e:1467			emit_addr(Pop())*/
        _27022 = _45Pop();
        _45emit_addr(_27022);
        _27022 = NOVALUE;

        /** emit.e:1468			emit_addr(b)*/
        _45emit_addr(_b_51963);

        /** emit.e:1469			emit_addr(c)*/
        _45emit_addr(_c_51964);

        /** emit.e:1470			assignable = FALSE*/
        _45assignable_51038 = _9FALSE_444;
        goto LC; // [5594] 7739

        /** emit.e:1473		case RHS_SLICE, FIND, MATCH, FIND_FROM, MATCH_FROM, SPLICE, INSERT, REMOVE, OPEN then*/
        case 46:
        case 77:
        case 78:
        case 176:
        case 177:
        case 190:
        case 191:
        case 200:
        case 37:

        /** emit.e:1474			emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1475			c = Pop()*/
        _c_51964 = _45Pop();
        if (!IS_ATOM_INT(_c_51964)) {
            _1 = (object)(DBL_PTR(_c_51964)->dbl);
            DeRefDS(_c_51964);
            _c_51964 = _1;
        }

        /** emit.e:1476			b = Pop()*/
        _b_51963 = _45Pop();
        if (!IS_ATOM_INT(_b_51963)) {
            _1 = (object)(DBL_PTR(_b_51963)->dbl);
            DeRefDS(_b_51963);
            _b_51963 = _1;
        }

        /** emit.e:1477			emit_addr(Pop())*/
        _27025 = _45Pop();
        _45emit_addr(_27025);
        _27025 = NOVALUE;

        /** emit.e:1478			emit_addr(b)*/
        _45emit_addr(_b_51963);

        /** emit.e:1479			emit_addr(c)*/
        _45emit_addr(_c_51964);

        /** emit.e:1480			c = NewTempSym()*/
        _c_51964 = _53NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_51964)) {
            _1 = (object)(DBL_PTR(_c_51964)->dbl);
            DeRefDS(_c_51964);
            _c_51964 = _1;
        }

        /** emit.e:1481			if op = FIND or op = FIND_FROM or op = OPEN then*/
        _27027 = (_op_51960 == 77LL);
        if (_27027 != 0) {
            _27028 = 1;
            goto L90; // [5669] 5683
        }
        _27029 = (_op_51960 == 176LL);
        _27028 = (_27029 != 0);
L90: 
        if (_27028 != 0) {
            goto L91; // [5683] 5698
        }
        _27031 = (_op_51960 == 37LL);
        if (_27031 == 0)
        {
            DeRef(_27031);
            _27031 = NOVALUE;
            goto L92; // [5694] 5706
        }
        else{
            DeRef(_27031);
            _27031 = NOVALUE;
        }
L91: 

        /** emit.e:1482				TempInteger( c )*/
        _45TempInteger(_c_51964);
        goto L93; // [5703] 5713
L92: 

        /** emit.e:1484				emit_temp( c, NEW_REFERENCE )*/
        _45emit_temp(_c_51964, 1LL);
L93: 

        /** emit.e:1486			assignable = TRUE*/
        _45assignable_51038 = _9TRUE_446;

        /** emit.e:1487			Push(c)*/
        _45Push(_c_51964);

        /** emit.e:1488			emit_addr(c)*/
        _45emit_addr(_c_51964);
        goto LC; // [5730] 7739

        /** emit.e:1491		case CONCAT_N then     -- concatenate 3 or more items*/
        case 157:

        /** emit.e:1492			n = op_info1  -- number of items to concatenate*/
        _n_51973 = _45op_info1_51020;

        /** emit.e:1493			emit_opcode(CONCAT_N)*/
        _45emit_opcode(157LL);

        /** emit.e:1494			emit(n)*/
        _45emit(_n_51973);

        /** emit.e:1495			for i = 1 to n do*/
        _27032 = _n_51973;
        {
            object _i_53130;
            _i_53130 = 1LL;
L94: 
            if (_i_53130 > _27032){
                goto L95; // [5760] 5788
            }

            /** emit.e:1496				symtab_index element = Pop()*/
            _element_53133 = _45Pop();
            if (!IS_ATOM_INT(_element_53133)) {
                _1 = (object)(DBL_PTR(_element_53133)->dbl);
                DeRefDS(_element_53133);
                _element_53133 = _1;
            }

            /** emit.e:1497				emit_addr( element )  -- reverse order*/
            _45emit_addr(_element_53133);

            /** emit.e:1498			end for*/
            _i_53130 = _i_53130 + 1LL;
            goto L94; // [5783] 5767
L95: 
            ;
        }

        /** emit.e:1499			c = NewTempSym()*/
        _c_51964 = _53NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_51964)) {
            _1 = (object)(DBL_PTR(_c_51964)->dbl);
            DeRefDS(_c_51964);
            _c_51964 = _1;
        }

        /** emit.e:1500			emit_addr(c)*/
        _45emit_addr(_c_51964);

        /** emit.e:1501			emit_temp( c, NEW_REFERENCE )*/
        _45emit_temp(_c_51964, 1LL);

        /** emit.e:1502			assignable = TRUE*/
        _45assignable_51038 = _9TRUE_446;

        /** emit.e:1503			Push(c)*/
        _45Push(_c_51964);
        goto LC; // [5819] 7739

        /** emit.e:1505		case FOR then*/
        case 21:

        /** emit.e:1506			c = Pop() -- increment*/
        _c_51964 = _45Pop();
        if (!IS_ATOM_INT(_c_51964)) {
            _1 = (object)(DBL_PTR(_c_51964)->dbl);
            DeRefDS(_c_51964);
            _c_51964 = _1;
        }

        /** emit.e:1507			TempKeep(c)*/
        _45TempKeep(_c_51964);

        /** emit.e:1508			ic = IsInteger(c)*/
        _ic_51972 = _45IsInteger(_c_51964);
        if (!IS_ATOM_INT(_ic_51972)) {
            _1 = (object)(DBL_PTR(_ic_51972)->dbl);
            DeRefDS(_ic_51972);
            _ic_51972 = _1;
        }

        /** emit.e:1509			if c < 1 or*/
        _27037 = (_c_51964 < 1LL);
        if (_27037 != 0) {
            goto L96; // [5851] 5930
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _27039 = (object)*(((s1_ptr)_2)->base + _c_51964);
        _2 = (object)SEQ_PTR(_27039);
        _27040 = (object)*(((s1_ptr)_2)->base + 3LL);
        _27039 = NOVALUE;
        if (IS_ATOM_INT(_27040)) {
            _27041 = (_27040 == 1LL);
        }
        else {
            _27041 = binary_op(EQUALS, _27040, 1LL);
        }
        _27040 = NOVALUE;
        if (IS_ATOM_INT(_27041)) {
            if (_27041 == 0) {
                DeRef(_27042);
                _27042 = 0;
                goto L97; // [5873] 5899
            }
        }
        else {
            if (DBL_PTR(_27041)->dbl == 0.0) {
                DeRef(_27042);
                _27042 = 0;
                goto L97; // [5873] 5899
            }
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _27043 = (object)*(((s1_ptr)_2)->base + _c_51964);
        _2 = (object)SEQ_PTR(_27043);
        _27044 = (object)*(((s1_ptr)_2)->base + 4LL);
        _27043 = NOVALUE;
        if (IS_ATOM_INT(_27044)) {
            _27045 = (_27044 != 2LL);
        }
        else {
            _27045 = binary_op(NOTEQ, _27044, 2LL);
        }
        _27044 = NOVALUE;
        DeRef(_27042);
        if (IS_ATOM_INT(_27045))
        _27042 = (_27045 != 0);
        else
        _27042 = DBL_PTR(_27045)->dbl != 0.0;
L97: 
        if (_27042 == 0) {
            DeRef(_27046);
            _27046 = 0;
            goto L98; // [5899] 5925
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _27047 = (object)*(((s1_ptr)_2)->base + _c_51964);
        _2 = (object)SEQ_PTR(_27047);
        _27048 = (object)*(((s1_ptr)_2)->base + 4LL);
        _27047 = NOVALUE;
        if (IS_ATOM_INT(_27048)) {
            _27049 = (_27048 != 4LL);
        }
        else {
            _27049 = binary_op(NOTEQ, _27048, 4LL);
        }
        _27048 = NOVALUE;
        if (IS_ATOM_INT(_27049))
        _27046 = (_27049 != 0);
        else
        _27046 = DBL_PTR(_27049)->dbl != 0.0;
L98: 
        if (_27046 == 0)
        {
            _27046 = NOVALUE;
            goto L99; // [5926] 5967
        }
        else{
            _27046 = NOVALUE;
        }
L96: 

        /** emit.e:1514				emit_opcode(ASSIGN)*/
        _45emit_opcode(18LL);

        /** emit.e:1515				emit_addr(c)*/
        _45emit_addr(_c_51964);

        /** emit.e:1516				c = NewTempSym()*/
        _c_51964 = _53NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_51964)) {
            _1 = (object)(DBL_PTR(_c_51964)->dbl);
            DeRefDS(_c_51964);
            _c_51964 = _1;
        }

        /** emit.e:1517				if ic then*/
        if (_ic_51972 == 0)
        {
            goto L9A; // [5952] 5961
        }
        else{
        }

        /** emit.e:1518					TempInteger( c )*/
        _45TempInteger(_c_51964);
L9A: 

        /** emit.e:1520				emit_addr(c)*/
        _45emit_addr(_c_51964);
L99: 

        /** emit.e:1522			b = Pop() -- limit*/
        _b_51963 = _45Pop();
        if (!IS_ATOM_INT(_b_51963)) {
            _1 = (object)(DBL_PTR(_b_51963)->dbl);
            DeRefDS(_b_51963);
            _b_51963 = _1;
        }

        /** emit.e:1523			TempKeep(b)*/
        _45TempKeep(_b_51963);

        /** emit.e:1524			ib = IsInteger(b)*/
        _ib_51971 = _45IsInteger(_b_51963);
        if (!IS_ATOM_INT(_ib_51971)) {
            _1 = (object)(DBL_PTR(_ib_51971)->dbl);
            DeRefDS(_ib_51971);
            _ib_51971 = _1;
        }

        /** emit.e:1525			if b < 1 or*/
        _27053 = (_b_51963 < 1LL);
        if (_27053 != 0) {
            goto L9B; // [5993] 6072
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _27055 = (object)*(((s1_ptr)_2)->base + _b_51963);
        _2 = (object)SEQ_PTR(_27055);
        _27056 = (object)*(((s1_ptr)_2)->base + 3LL);
        _27055 = NOVALUE;
        if (IS_ATOM_INT(_27056)) {
            _27057 = (_27056 == 1LL);
        }
        else {
            _27057 = binary_op(EQUALS, _27056, 1LL);
        }
        _27056 = NOVALUE;
        if (IS_ATOM_INT(_27057)) {
            if (_27057 == 0) {
                DeRef(_27058);
                _27058 = 0;
                goto L9C; // [6015] 6041
            }
        }
        else {
            if (DBL_PTR(_27057)->dbl == 0.0) {
                DeRef(_27058);
                _27058 = 0;
                goto L9C; // [6015] 6041
            }
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _27059 = (object)*(((s1_ptr)_2)->base + _b_51963);
        _2 = (object)SEQ_PTR(_27059);
        _27060 = (object)*(((s1_ptr)_2)->base + 4LL);
        _27059 = NOVALUE;
        if (IS_ATOM_INT(_27060)) {
            _27061 = (_27060 != 2LL);
        }
        else {
            _27061 = binary_op(NOTEQ, _27060, 2LL);
        }
        _27060 = NOVALUE;
        DeRef(_27058);
        if (IS_ATOM_INT(_27061))
        _27058 = (_27061 != 0);
        else
        _27058 = DBL_PTR(_27061)->dbl != 0.0;
L9C: 
        if (_27058 == 0) {
            DeRef(_27062);
            _27062 = 0;
            goto L9D; // [6041] 6067
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _27063 = (object)*(((s1_ptr)_2)->base + _b_51963);
        _2 = (object)SEQ_PTR(_27063);
        _27064 = (object)*(((s1_ptr)_2)->base + 4LL);
        _27063 = NOVALUE;
        if (IS_ATOM_INT(_27064)) {
            _27065 = (_27064 != 4LL);
        }
        else {
            _27065 = binary_op(NOTEQ, _27064, 4LL);
        }
        _27064 = NOVALUE;
        if (IS_ATOM_INT(_27065))
        _27062 = (_27065 != 0);
        else
        _27062 = DBL_PTR(_27065)->dbl != 0.0;
L9D: 
        if (_27062 == 0)
        {
            _27062 = NOVALUE;
            goto L9E; // [6068] 6109
        }
        else{
            _27062 = NOVALUE;
        }
L9B: 

        /** emit.e:1530				emit_opcode(ASSIGN)*/
        _45emit_opcode(18LL);

        /** emit.e:1531				emit_addr(b)*/
        _45emit_addr(_b_51963);

        /** emit.e:1532				b = NewTempSym()*/
        _b_51963 = _53NewTempSym(0LL);
        if (!IS_ATOM_INT(_b_51963)) {
            _1 = (object)(DBL_PTR(_b_51963)->dbl);
            DeRefDS(_b_51963);
            _b_51963 = _1;
        }

        /** emit.e:1533				if ib then*/
        if (_ib_51971 == 0)
        {
            goto L9F; // [6094] 6103
        }
        else{
        }

        /** emit.e:1534					TempInteger( b )*/
        _45TempInteger(_b_51963);
L9F: 

        /** emit.e:1536				emit_addr(b)*/
        _45emit_addr(_b_51963);
L9E: 

        /** emit.e:1538			a = Pop() -- initial value*/
        _a_51962 = _45Pop();
        if (!IS_ATOM_INT(_a_51962)) {
            _1 = (object)(DBL_PTR(_a_51962)->dbl);
            DeRefDS(_a_51962);
            _a_51962 = _1;
        }

        /** emit.e:1539			if IsInteger(a) and ib and ic then*/
        _27068 = _45IsInteger(_a_51962);
        if (IS_ATOM_INT(_27068)) {
            if (_27068 == 0) {
                DeRef(_27069);
                _27069 = 0;
                goto LA0; // [6122] 6130
            }
        }
        else {
            if (DBL_PTR(_27068)->dbl == 0.0) {
                DeRef(_27069);
                _27069 = 0;
                goto LA0; // [6122] 6130
            }
        }
        DeRef(_27069);
        _27069 = (_ib_51971 != 0);
LA0: 
        if (_27069 == 0) {
            goto LA1; // [6130] 6169
        }
        if (_ic_51972 == 0)
        {
            goto LA1; // [6135] 6169
        }
        else{
        }

        /** emit.e:1540				SymTab[op_info1][S_VTYPE] = integer_type*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_45op_info1_51020 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 15LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _53integer_type_46852;
        DeRef(_1);
        _27071 = NOVALUE;

        /** emit.e:1541				op = FOR_I*/
        _op_51960 = 125LL;
        goto LA2; // [6166] 6179
LA1: 

        /** emit.e:1543				op = FOR*/
        _op_51960 = 21LL;
LA2: 

        /** emit.e:1545			emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1546			emit_addr(c)*/
        _45emit_addr(_c_51964);

        /** emit.e:1547			emit_addr(b)*/
        _45emit_addr(_b_51963);

        /** emit.e:1548			emit_addr(a)*/
        _45emit_addr(_a_51962);

        /** emit.e:1549			emit_addr(CurrentSub) -- in case recursion check is needed*/
        _45emit_addr(_12CurrentSub_20234);

        /** emit.e:1550			Push(b)*/
        _45Push(_b_51963);

        /** emit.e:1551			Push(c)*/
        _45Push(_c_51964);

        /** emit.e:1552			assignable = FALSE*/
        _45assignable_51038 = _9FALSE_444;
        goto LC; // [6223] 7739

        /** emit.e:1555		case ENDFOR_GENERAL, ENDFOR_INT_UP1 then  -- all ENDFORs*/
        case 39:
        case 54:

        /** emit.e:1556			emit_opcode(op) -- will be patched at runtime*/
        _45emit_opcode(_op_51960);

        /** emit.e:1557			a = Pop()*/
        _a_51962 = _45Pop();
        if (!IS_ATOM_INT(_a_51962)) {
            _1 = (object)(DBL_PTR(_a_51962)->dbl);
            DeRefDS(_a_51962);
            _a_51962 = _1;
        }

        /** emit.e:1558			emit_addr(op_info2) -- address of top of loop*/
        _45emit_addr(_45op_info2_51021);

        /** emit.e:1559			emit_addr(Pop())    -- limit*/
        _27074 = _45Pop();
        _45emit_addr(_27074);
        _27074 = NOVALUE;

        /** emit.e:1560			emit_addr(op_info1) -- loop var*/
        _45emit_addr(_45op_info1_51020);

        /** emit.e:1561			emit_addr(a)        -- increment - not always used -*/
        _45emit_addr(_a_51962);

        /** emit.e:1563			assignable = FALSE*/
        _45assignable_51038 = _9FALSE_444;
        goto LC; // [6277] 7739

        /** emit.e:1566		case ASSIGN_OP_SUBS, PASSIGN_OP_SUBS then*/
        case 149:
        case 164:

        /** emit.e:1568			b = Pop()      -- rhs value, keep on stack*/
        _b_51963 = _45Pop();
        if (!IS_ATOM_INT(_b_51963)) {
            _1 = (object)(DBL_PTR(_b_51963)->dbl);
            DeRefDS(_b_51963);
            _b_51963 = _1;
        }

        /** emit.e:1569			TempKeep(b)*/
        _45TempKeep(_b_51963);

        /** emit.e:1571			a = Pop()      -- subscript, keep on stack*/
        _a_51962 = _45Pop();
        if (!IS_ATOM_INT(_a_51962)) {
            _1 = (object)(DBL_PTR(_a_51962)->dbl);
            DeRefDS(_a_51962);
            _a_51962 = _1;
        }

        /** emit.e:1572			TempKeep(a)*/
        _45TempKeep(_a_51962);

        /** emit.e:1574			c = Pop()      -- lhs sequence, keep on stack*/
        _c_51964 = _45Pop();
        if (!IS_ATOM_INT(_c_51964)) {
            _1 = (object)(DBL_PTR(_c_51964)->dbl);
            DeRefDS(_c_51964);
            _c_51964 = _1;
        }

        /** emit.e:1575			TempKeep(c)*/
        _45TempKeep(_c_51964);

        /** emit.e:1577			emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1578			emit_addr(c)*/
        _45emit_addr(_c_51964);

        /** emit.e:1579			emit_addr(a)*/
        _45emit_addr(_a_51962);

        /** emit.e:1581			d = NewTempSym()*/
        _d_51965 = _53NewTempSym(0LL);
        if (!IS_ATOM_INT(_d_51965)) {
            _1 = (object)(DBL_PTR(_d_51965)->dbl);
            DeRefDS(_d_51965);
            _d_51965 = _1;
        }

        /** emit.e:1582			emit_addr(d)   -- place to store result*/
        _45emit_addr(_d_51965);

        /** emit.e:1583			emit_temp( d, NEW_REFERENCE )*/
        _45emit_temp(_d_51965, 1LL);

        /** emit.e:1585			Push(c)*/
        _45Push(_c_51964);

        /** emit.e:1586			Push(a)*/
        _45Push(_a_51962);

        /** emit.e:1587			Push(d)*/
        _45Push(_d_51965);

        /** emit.e:1588			Push(b)*/
        _45Push(_b_51963);

        /** emit.e:1589			assignable = FALSE*/
        _45assignable_51038 = _9FALSE_444;
        goto LC; // [6382] 7739

        /** emit.e:1592		case ASSIGN_SLICE, PASSIGN_SLICE then*/
        case 45:
        case 163:

        /** emit.e:1593			emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1594			b = Pop() -- rhs value*/
        _b_51963 = _45Pop();
        if (!IS_ATOM_INT(_b_51963)) {
            _1 = (object)(DBL_PTR(_b_51963)->dbl);
            DeRefDS(_b_51963);
            _b_51963 = _1;
        }

        /** emit.e:1595			a = Pop() -- 2nd subs*/
        _a_51962 = _45Pop();
        if (!IS_ATOM_INT(_a_51962)) {
            _1 = (object)(DBL_PTR(_a_51962)->dbl);
            DeRefDS(_a_51962);
            _a_51962 = _1;
        }

        /** emit.e:1596			c = Pop() -- 1st subs*/
        _c_51964 = _45Pop();
        if (!IS_ATOM_INT(_c_51964)) {
            _1 = (object)(DBL_PTR(_c_51964)->dbl);
            DeRefDS(_c_51964);
            _c_51964 = _1;
        }

        /** emit.e:1597			emit_addr(Pop()) -- sequence*/
        _27082 = _45Pop();
        _45emit_addr(_27082);
        _27082 = NOVALUE;

        /** emit.e:1598			emit_addr(c)*/
        _45emit_addr(_c_51964);

        /** emit.e:1599			emit_addr(a)*/
        _45emit_addr(_a_51962);

        /** emit.e:1600			emit_addr(b)*/
        _45emit_addr(_b_51963);

        /** emit.e:1601			assignable = FALSE*/
        _45assignable_51038 = _9FALSE_444;
        goto LC; // [6446] 7739

        /** emit.e:1604		case REPLACE then*/
        case 201:

        /** emit.e:1605			emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1607			b = Pop()  -- source*/
        _b_51963 = _45Pop();
        if (!IS_ATOM_INT(_b_51963)) {
            _1 = (object)(DBL_PTR(_b_51963)->dbl);
            DeRefDS(_b_51963);
            _b_51963 = _1;
        }

        /** emit.e:1608			a = Pop()  -- replacement*/
        _a_51962 = _45Pop();
        if (!IS_ATOM_INT(_a_51962)) {
            _1 = (object)(DBL_PTR(_a_51962)->dbl);
            DeRefDS(_a_51962);
            _a_51962 = _1;
        }

        /** emit.e:1609			c = Pop()  -- start of replaced slice*/
        _c_51964 = _45Pop();
        if (!IS_ATOM_INT(_c_51964)) {
            _1 = (object)(DBL_PTR(_c_51964)->dbl);
            DeRefDS(_c_51964);
            _c_51964 = _1;
        }

        /** emit.e:1610			d = Pop()  -- end of replaced slice*/
        _d_51965 = _45Pop();
        if (!IS_ATOM_INT(_d_51965)) {
            _1 = (object)(DBL_PTR(_d_51965)->dbl);
            DeRefDS(_d_51965);
            _d_51965 = _1;
        }

        /** emit.e:1611			emit_addr(d)*/
        _45emit_addr(_d_51965);

        /** emit.e:1612			emit_addr(c)*/
        _45emit_addr(_c_51964);

        /** emit.e:1613			emit_addr(a)*/
        _45emit_addr(_a_51962);

        /** emit.e:1614			emit_addr(b)*/
        _45emit_addr(_b_51963);

        /** emit.e:1616			c = NewTempSym()*/
        _c_51964 = _53NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_51964)) {
            _1 = (object)(DBL_PTR(_c_51964)->dbl);
            DeRefDS(_c_51964);
            _c_51964 = _1;
        }

        /** emit.e:1617			Push(c)*/
        _45Push(_c_51964);

        /** emit.e:1618			emit_addr(c)     -- place to store result*/
        _45emit_addr(_c_51964);

        /** emit.e:1619			emit_temp( c, NEW_REFERENCE )*/
        _45emit_temp(_c_51964, 1LL);

        /** emit.e:1620			assignable = TRUE*/
        _45assignable_51038 = _9TRUE_446;
        goto LC; // [6536] 7739

        /** emit.e:1623		case ASSIGN_OP_SLICE, PASSIGN_OP_SLICE then*/
        case 150:
        case 165:

        /** emit.e:1625			emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1627			b = Pop()        -- rhs value not used*/
        _b_51963 = _45Pop();
        if (!IS_ATOM_INT(_b_51963)) {
            _1 = (object)(DBL_PTR(_b_51963)->dbl);
            DeRefDS(_b_51963);
            _b_51963 = _1;
        }

        /** emit.e:1628			TempKeep(b)*/
        _45TempKeep(_b_51963);

        /** emit.e:1630			a = Pop()        -- 2nd subs*/
        _a_51962 = _45Pop();
        if (!IS_ATOM_INT(_a_51962)) {
            _1 = (object)(DBL_PTR(_a_51962)->dbl);
            DeRefDS(_a_51962);
            _a_51962 = _1;
        }

        /** emit.e:1631			TempKeep(a)*/
        _45TempKeep(_a_51962);

        /** emit.e:1633			c = Pop()        -- 1st subs*/
        _c_51964 = _45Pop();
        if (!IS_ATOM_INT(_c_51964)) {
            _1 = (object)(DBL_PTR(_c_51964)->dbl);
            DeRefDS(_c_51964);
            _c_51964 = _1;
        }

        /** emit.e:1634			TempKeep(c)*/
        _45TempKeep(_c_51964);

        /** emit.e:1636			d = Pop()*/
        _d_51965 = _45Pop();
        if (!IS_ATOM_INT(_d_51965)) {
            _1 = (object)(DBL_PTR(_d_51965)->dbl);
            DeRefDS(_d_51965);
            _d_51965 = _1;
        }

        /** emit.e:1637			TempKeep(d)      -- sequence*/
        _45TempKeep(_d_51965);

        /** emit.e:1639			emit_addr(d)*/
        _45emit_addr(_d_51965);

        /** emit.e:1640			Push(d)*/
        _45Push(_d_51965);

        /** emit.e:1642			emit_addr(c)*/
        _45emit_addr(_c_51964);

        /** emit.e:1643			Push(c)*/
        _45Push(_c_51964);

        /** emit.e:1645			emit_addr(a)*/
        _45emit_addr(_a_51962);

        /** emit.e:1646			Push(a)*/
        _45Push(_a_51962);

        /** emit.e:1648			c = NewTempSym()*/
        _c_51964 = _53NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_51964)) {
            _1 = (object)(DBL_PTR(_c_51964)->dbl);
            DeRefDS(_c_51964);
            _c_51964 = _1;
        }

        /** emit.e:1649			Push(c)*/
        _45Push(_c_51964);

        /** emit.e:1650			emit_addr(c)     -- place to store result*/
        _45emit_addr(_c_51964);

        /** emit.e:1651			emit_temp( c, NEW_REFERENCE )*/
        _45emit_temp(_c_51964, 1LL);

        /** emit.e:1653			Push(b)*/
        _45Push(_b_51963);

        /** emit.e:1654			assignable = FALSE*/
        _45assignable_51038 = _9FALSE_444;
        goto LC; // [6663] 7739

        /** emit.e:1657		case CALL_PROC then*/
        case 136:

        /** emit.e:1658			emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1659			b = Pop()*/
        _b_51963 = _45Pop();
        if (!IS_ATOM_INT(_b_51963)) {
            _1 = (object)(DBL_PTR(_b_51963)->dbl);
            DeRefDS(_b_51963);
            _b_51963 = _1;
        }

        /** emit.e:1660			emit_addr(Pop())*/
        _27094 = _45Pop();
        _45emit_addr(_27094);
        _27094 = NOVALUE;

        /** emit.e:1661			emit_addr(b)*/
        _45emit_addr(_b_51963);

        /** emit.e:1662			assignable = FALSE*/
        _45assignable_51038 = _9FALSE_444;
        goto LC; // [6701] 7739

        /** emit.e:1664		case CALL_FUNC then*/
        case 137:

        /** emit.e:1665			emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1666			b = Pop()*/
        _b_51963 = _45Pop();
        if (!IS_ATOM_INT(_b_51963)) {
            _1 = (object)(DBL_PTR(_b_51963)->dbl);
            DeRefDS(_b_51963);
            _b_51963 = _1;
        }

        /** emit.e:1667			emit_addr(Pop())*/
        _27096 = _45Pop();
        _45emit_addr(_27096);
        _27096 = NOVALUE;

        /** emit.e:1668			emit_addr(b)*/
        _45emit_addr(_b_51963);

        /** emit.e:1669			assignable = TRUE*/
        _45assignable_51038 = _9TRUE_446;

        /** emit.e:1670			c = NewTempSym()*/
        _c_51964 = _53NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_51964)) {
            _1 = (object)(DBL_PTR(_c_51964)->dbl);
            DeRefDS(_c_51964);
            _c_51964 = _1;
        }

        /** emit.e:1671			Push(c)*/
        _45Push(_c_51964);

        /** emit.e:1672			emit_addr(c)*/
        _45emit_addr(_c_51964);

        /** emit.e:1673			emit_temp( c, NEW_REFERENCE )*/
        _45emit_temp(_c_51964, 1LL);
        goto LC; // [6763] 7739

        /** emit.e:1675		case EXIT_BLOCK then*/
        case 206:

        /** emit.e:1676			emit_opcode( op )*/
        _45emit_opcode(_op_51960);

        /** emit.e:1677			emit_addr( Pop() )*/
        _27098 = _45Pop();
        _45emit_addr(_27098);
        _27098 = NOVALUE;

        /** emit.e:1678			assignable = FALSE*/
        _45assignable_51038 = _9FALSE_444;
        goto LC; // [6789] 7739

        /** emit.e:1680		case RETURNP then*/
        case 29:

        /** emit.e:1681			emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1682			emit_addr(CurrentSub)*/
        _45emit_addr(_12CurrentSub_20234);

        /** emit.e:1683			emit_addr(top_block())*/
        _27099 = _64top_block(0LL);
        _45emit_addr(_27099);
        _27099 = NOVALUE;

        /** emit.e:1684			assignable = FALSE*/
        _45assignable_51038 = _9FALSE_444;
        goto LC; // [6823] 7739

        /** emit.e:1686		case RETURNF then*/
        case 28:

        /** emit.e:1687			clear_temp( Top() )*/

        /** emit.e:145		return cg_stack[cgi]*/
        DeRef(_Top_inlined_Top_at_7037_53280);
        _2 = (object)SEQ_PTR(_45cg_stack_51035);
        _Top_inlined_Top_at_7037_53280 = (object)*(((s1_ptr)_2)->base + _45cgi_51036);
        Ref(_Top_inlined_Top_at_7037_53280);
        Ref(_Top_inlined_Top_at_7037_53280);
        _45clear_temp(_Top_inlined_Top_at_7037_53280);

        /** emit.e:1688			flush_temps()*/
        RefDS(_22024);
        _45flush_temps(_22024);

        /** emit.e:1689			emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1690			emit_addr(CurrentSub)*/
        _45emit_addr(_12CurrentSub_20234);

        /** emit.e:1691			emit_addr(Least_block())*/
        _27100 = _64Least_block();
        _45emit_addr(_27100);
        _27100 = NOVALUE;

        /** emit.e:1692			emit_addr(Pop())*/
        _27101 = _45Pop();
        _45emit_addr(_27101);
        _27101 = NOVALUE;

        /** emit.e:1693			assignable = FALSE*/
        _45assignable_51038 = _9FALSE_444;
        goto LC; // [6885] 7739

        /** emit.e:1695		case RETURNT then*/
        case 34:

        /** emit.e:1696			emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1697			assignable = FALSE*/
        _45assignable_51038 = _9FALSE_444;
        goto LC; // [6903] 7739

        /** emit.e:1699		case DATE, TIME, SPACE_USED, GET_KEY, TASK_LIST,*/
        case 69:
        case 70:
        case 75:
        case 79:
        case 172:
        case 100:
        case 183:

        /** emit.e:1701			emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1702			c = NewTempSym()*/
        _c_51964 = _53NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_51964)) {
            _1 = (object)(DBL_PTR(_c_51964)->dbl);
            DeRefDS(_c_51964);
            _c_51964 = _1;
        }

        /** emit.e:1703			assignable = TRUE*/
        _45assignable_51038 = _9TRUE_446;

        /** emit.e:1704			if op = GET_KEY then  -- it's in op_result as integer*/
        if (_op_51960 != 79LL)
        goto LA3; // [6945] 6957

        /** emit.e:1705				TempInteger(c)*/
        _45TempInteger(_c_51964);
        goto LA4; // [6954] 6964
LA3: 

        /** emit.e:1707				emit_temp( c, NEW_REFERENCE )*/
        _45emit_temp(_c_51964, 1LL);
LA4: 

        /** emit.e:1709			Push(c)*/
        _45Push(_c_51964);

        /** emit.e:1710			emit_addr(c)*/
        _45emit_addr(_c_51964);
        goto LC; // [6974] 7739

        /** emit.e:1712		case CLOSE, ABORT, CALL, DELETE_OBJECT then*/
        case 86:
        case 126:
        case 129:
        case 205:

        /** emit.e:1713			emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1714			emit_addr(Pop())*/
        _27104 = _45Pop();
        _45emit_addr(_27104);
        _27104 = NOVALUE;

        /** emit.e:1715			assignable = FALSE*/
        _45assignable_51038 = _9FALSE_444;
        goto LC; // [7006] 7739

        /** emit.e:1717		case POWER then*/
        case 72:

        /** emit.e:1719			b = Pop()*/
        _b_51963 = _45Pop();
        if (!IS_ATOM_INT(_b_51963)) {
            _1 = (object)(DBL_PTR(_b_51963)->dbl);
            DeRefDS(_b_51963);
            _b_51963 = _1;
        }

        /** emit.e:1720			a = Pop()*/
        _a_51962 = _45Pop();
        if (!IS_ATOM_INT(_a_51962)) {
            _1 = (object)(DBL_PTR(_a_51962)->dbl);
            DeRefDS(_a_51962);
            _a_51962 = _1;
        }

        /** emit.e:1721			if b > 0 and SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 2) then*/
        _27107 = (_b_51963 > 0LL);
        if (_27107 == 0) {
            _27108 = 0;
            goto LA5; // [7032] 7058
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _27109 = (object)*(((s1_ptr)_2)->base + _b_51963);
        _2 = (object)SEQ_PTR(_27109);
        _27110 = (object)*(((s1_ptr)_2)->base + 3LL);
        _27109 = NOVALUE;
        if (IS_ATOM_INT(_27110)) {
            _27111 = (_27110 == 2LL);
        }
        else {
            _27111 = binary_op(EQUALS, _27110, 2LL);
        }
        _27110 = NOVALUE;
        if (IS_ATOM_INT(_27111))
        _27108 = (_27111 != 0);
        else
        _27108 = DBL_PTR(_27111)->dbl != 0.0;
LA5: 
        if (_27108 == 0) {
            goto LA6; // [7058] 7115
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _27113 = (object)*(((s1_ptr)_2)->base + _b_51963);
        _2 = (object)SEQ_PTR(_27113);
        _27114 = (object)*(((s1_ptr)_2)->base + 1LL);
        _27113 = NOVALUE;
        if (_27114 == 2LL)
        _27115 = 1;
        else if (IS_ATOM_INT(_27114) && IS_ATOM_INT(2LL))
        _27115 = 0;
        else
        _27115 = (compare(_27114, 2LL) == 0);
        _27114 = NOVALUE;
        if (_27115 == 0)
        {
            _27115 = NOVALUE;
            goto LA6; // [7079] 7115
        }
        else{
            _27115 = NOVALUE;
        }

        /** emit.e:1723				op = rw:MULTIPLY*/
        _op_51960 = 13LL;

        /** emit.e:1724				emit_opcode(op)*/
        _45emit_opcode(13LL);

        /** emit.e:1725				emit_addr(a)*/
        _45emit_addr(_a_51962);

        /** emit.e:1726				emit_addr(a)*/
        _45emit_addr(_a_51962);

        /** emit.e:1727				cont21d(op, a, b, FALSE)*/
        _45cont21d(13LL, _a_51962, _b_51963, _9FALSE_444);
        goto LC; // [7112] 7739
LA6: 

        /** emit.e:1729				Push(a)*/
        _45Push(_a_51962);

        /** emit.e:1730				Push(b)*/
        _45Push(_b_51963);

        /** emit.e:1731				cont21ii(op, FALSE)*/
        _45cont21ii(_op_51960, _9FALSE_444);
        goto LC; // [7134] 7739

        /** emit.e:1735		case TYPE_CHECK then*/
        case 65:

        /** emit.e:1736			emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1737			c = Pop()*/
        _c_51964 = _45Pop();
        if (!IS_ATOM_INT(_c_51964)) {
            _1 = (object)(DBL_PTR(_c_51964)->dbl);
            DeRefDS(_c_51964);
            _c_51964 = _1;
        }

        /** emit.e:1738			assignable = FALSE*/
        _45assignable_51038 = _9FALSE_444;
        goto LC; // [7159] 7739

        /** emit.e:1741		case DOLLAR then*/
        case -22:

        /** emit.e:1742			if current_sequence[$] < 0 or SymTab[current_sequence[$]][S_SCOPE] = SC_UNDEFINED then*/
        if (IS_SEQUENCE(_45current_sequence_51028)){
                _27117 = SEQ_PTR(_45current_sequence_51028)->length;
        }
        else {
            _27117 = 1;
        }
        _2 = (object)SEQ_PTR(_45current_sequence_51028);
        _27118 = (object)*(((s1_ptr)_2)->base + _27117);
        if (IS_ATOM_INT(_27118)) {
            _27119 = (_27118 < 0LL);
        }
        else {
            _27119 = binary_op(LESS, _27118, 0LL);
        }
        _27118 = NOVALUE;
        if (IS_ATOM_INT(_27119)) {
            if (_27119 != 0) {
                goto LA7; // [7180] 7216
            }
        }
        else {
            if (DBL_PTR(_27119)->dbl != 0.0) {
                goto LA7; // [7180] 7216
            }
        }
        if (IS_SEQUENCE(_45current_sequence_51028)){
                _27121 = SEQ_PTR(_45current_sequence_51028)->length;
        }
        else {
            _27121 = 1;
        }
        _2 = (object)SEQ_PTR(_45current_sequence_51028);
        _27122 = (object)*(((s1_ptr)_2)->base + _27121);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!IS_ATOM_INT(_27122)){
            _27123 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27122)->dbl));
        }
        else{
            _27123 = (object)*(((s1_ptr)_2)->base + _27122);
        }
        _2 = (object)SEQ_PTR(_27123);
        _27124 = (object)*(((s1_ptr)_2)->base + 4LL);
        _27123 = NOVALUE;
        if (IS_ATOM_INT(_27124)) {
            _27125 = (_27124 == 9LL);
        }
        else {
            _27125 = binary_op(EQUALS, _27124, 9LL);
        }
        _27124 = NOVALUE;
        if (_27125 == 0) {
            DeRef(_27125);
            _27125 = NOVALUE;
            goto LA8; // [7212] 7286
        }
        else {
            if (!IS_ATOM_INT(_27125) && DBL_PTR(_27125)->dbl == 0.0){
                DeRef(_27125);
                _27125 = NOVALUE;
                goto LA8; // [7212] 7286
            }
            DeRef(_27125);
            _27125 = NOVALUE;
        }
        DeRef(_27125);
        _27125 = NOVALUE;
LA7: 

        /** emit.e:1743				if lhs_ptr and length(current_sequence) = 1 then*/
        if (_45lhs_ptr_51030 == 0) {
            goto LA9; // [7220] 7249
        }
        if (IS_SEQUENCE(_45current_sequence_51028)){
                _27127 = SEQ_PTR(_45current_sequence_51028)->length;
        }
        else {
            _27127 = 1;
        }
        _27128 = (_27127 == 1LL);
        _27127 = NOVALUE;
        if (_27128 == 0)
        {
            DeRef(_27128);
            _27128 = NOVALUE;
            goto LA9; // [7234] 7249
        }
        else{
            DeRef(_27128);
            _27128 = NOVALUE;
        }

        /** emit.e:1744					c = PLENGTH*/
        _c_51964 = 160LL;
        goto LAA; // [7246] 7259
LA9: 

        /** emit.e:1746					c = LENGTH*/
        _c_51964 = 42LL;
LAA: 

        /** emit.e:1748				c = - new_forward_reference( VARIABLE, current_sequence[$], c )*/
        if (IS_SEQUENCE(_45current_sequence_51028)){
                _27129 = SEQ_PTR(_45current_sequence_51028)->length;
        }
        else {
            _27129 = 1;
        }
        _2 = (object)SEQ_PTR(_45current_sequence_51028);
        _27130 = (object)*(((s1_ptr)_2)->base + _27129);
        Ref(_27130);
        _27131 = _42new_forward_reference(-100LL, _27130, _c_51964);
        _27130 = NOVALUE;
        if (IS_ATOM_INT(_27131)) {
            if ((uintptr_t)_27131 == (uintptr_t)HIGH_BITS){
                _c_51964 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _c_51964 = - _27131;
            }
        }
        else {
            _c_51964 = unary_op(UMINUS, _27131);
        }
        DeRef(_27131);
        _27131 = NOVALUE;
        if (!IS_ATOM_INT(_c_51964)) {
            _1 = (object)(DBL_PTR(_c_51964)->dbl);
            DeRefDS(_c_51964);
            _c_51964 = _1;
        }
        goto LAB; // [7283] 7300
LA8: 

        /** emit.e:1750				c = current_sequence[$]*/
        if (IS_SEQUENCE(_45current_sequence_51028)){
                _27133 = SEQ_PTR(_45current_sequence_51028)->length;
        }
        else {
            _27133 = 1;
        }
        _2 = (object)SEQ_PTR(_45current_sequence_51028);
        _c_51964 = (object)*(((s1_ptr)_2)->base + _27133);
        if (!IS_ATOM_INT(_c_51964)){
            _c_51964 = (object)DBL_PTR(_c_51964)->dbl;
        }
LAB: 

        /** emit.e:1754			if lhs_ptr and length(current_sequence) = 1 then*/
        if (_45lhs_ptr_51030 == 0) {
            goto LAC; // [7304] 7331
        }
        if (IS_SEQUENCE(_45current_sequence_51028)){
                _27136 = SEQ_PTR(_45current_sequence_51028)->length;
        }
        else {
            _27136 = 1;
        }
        _27137 = (_27136 == 1LL);
        _27136 = NOVALUE;
        if (_27137 == 0)
        {
            DeRef(_27137);
            _27137 = NOVALUE;
            goto LAC; // [7318] 7331
        }
        else{
            DeRef(_27137);
            _27137 = NOVALUE;
        }

        /** emit.e:1755				emit_opcode(PLENGTH)*/
        _45emit_opcode(160LL);
        goto LAD; // [7328] 7339
LAC: 

        /** emit.e:1757				emit_opcode(LENGTH)*/
        _45emit_opcode(42LL);
LAD: 

        /** emit.e:1760			emit_addr( c )*/
        _45emit_addr(_c_51964);

        /** emit.e:1762			c = NewTempSym()*/
        _c_51964 = _53NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_51964)) {
            _1 = (object)(DBL_PTR(_c_51964)->dbl);
            DeRefDS(_c_51964);
            _c_51964 = _1;
        }

        /** emit.e:1763			TempInteger(c)*/
        _45TempInteger(_c_51964);

        /** emit.e:1764			Push(c)*/
        _45Push(_c_51964);

        /** emit.e:1765			emit_addr(c)*/
        _45emit_addr(_c_51964);

        /** emit.e:1766			assignable = FALSE -- it wouldn't be assigned anyway*/
        _45assignable_51038 = _9FALSE_444;
        goto LC; // [7374] 7739

        /** emit.e:1769		case TASK_SELF then*/
        case 170:

        /** emit.e:1770			c = NewTempSym()*/
        _c_51964 = _53NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_51964)) {
            _1 = (object)(DBL_PTR(_c_51964)->dbl);
            DeRefDS(_c_51964);
            _c_51964 = _1;
        }

        /** emit.e:1771			Push(c)*/
        _45Push(_c_51964);

        /** emit.e:1772			emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1773			emit_addr(c)*/
        _45emit_addr(_c_51964);

        /** emit.e:1774			assignable = TRUE*/
        _45assignable_51038 = _9TRUE_446;
        goto LC; // [7410] 7739

        /** emit.e:1776		case SWITCH then*/
        case 185:

        /** emit.e:1777			emit_opcode( op )*/
        _45emit_opcode(_op_51960);

        /** emit.e:1778			c = Pop()*/
        _c_51964 = _45Pop();
        if (!IS_ATOM_INT(_c_51964)) {
            _1 = (object)(DBL_PTR(_c_51964)->dbl);
            DeRefDS(_c_51964);
            _c_51964 = _1;
        }

        /** emit.e:1779			b = Pop()*/
        _b_51963 = _45Pop();
        if (!IS_ATOM_INT(_b_51963)) {
            _1 = (object)(DBL_PTR(_b_51963)->dbl);
            DeRefDS(_b_51963);
            _b_51963 = _1;
        }

        /** emit.e:1780			a = Pop()*/
        _a_51962 = _45Pop();
        if (!IS_ATOM_INT(_a_51962)) {
            _1 = (object)(DBL_PTR(_a_51962)->dbl);
            DeRefDS(_a_51962);
            _a_51962 = _1;
        }

        /** emit.e:1781			emit_addr( a ) -- Switch Expr*/
        _45emit_addr(_a_51962);

        /** emit.e:1782			emit_addr( b ) -- Case values*/
        _45emit_addr(_b_51963);

        /** emit.e:1783			emit_addr( c ) -- Jump table*/
        _45emit_addr(_c_51964);

        /** emit.e:1785			assignable = FALSE*/
        _45assignable_51038 = _9FALSE_444;
        goto LC; // [7464] 7739

        /** emit.e:1787		case CASE then*/
        case 186:

        /** emit.e:1789			emit_opcode( op )*/
        _45emit_opcode(_op_51960);

        /** emit.e:1790			emit( cg_stack[cgi] )  -- the case index*/
        _2 = (object)SEQ_PTR(_45cg_stack_51035);
        _27143 = (object)*(((s1_ptr)_2)->base + _45cgi_51036);
        Ref(_27143);
        _45emit(_27143);
        _27143 = NOVALUE;

        /** emit.e:1791			cgi -= 1*/
        _45cgi_51036 = _45cgi_51036 - 1LL;
        goto LC; // [7496] 7739

        /** emit.e:1794		case PLATFORM then*/
        case 155:

        /** emit.e:1795			if BIND and shroud_only then*/
        if (_12BIND_19837 == 0) {
            goto LAE; // [7506] 7554
        }
        if (_12shroud_only_20224 == 0)
        {
            goto LAE; // [7513] 7554
        }
        else{
        }

        /** emit.e:1797				c = NewTempSym()*/
        _c_51964 = _53NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_51964)) {
            _1 = (object)(DBL_PTR(_c_51964)->dbl);
            DeRefDS(_c_51964);
            _c_51964 = _1;
        }

        /** emit.e:1798				TempInteger(c)*/
        _45TempInteger(_c_51964);

        /** emit.e:1799				Push(c)*/
        _45Push(_c_51964);

        /** emit.e:1800				emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1801				emit_addr(c)*/
        _45emit_addr(_c_51964);

        /** emit.e:1802				assignable = TRUE*/
        _45assignable_51038 = _9TRUE_446;
        goto LC; // [7551] 7739
LAE: 

        /** emit.e:1806				n = host_platform()*/
        _n_51973 = _44host_platform();
        if (!IS_ATOM_INT(_n_51973)) {
            _1 = (object)(DBL_PTR(_n_51973)->dbl);
            DeRefDS(_n_51973);
            _n_51973 = _1;
        }

        /** emit.e:1807				Push(NewIntSym(n))*/
        _27148 = _53NewIntSym(_n_51973);
        _45Push(_27148);
        _27148 = NOVALUE;

        /** emit.e:1808				assignable = FALSE*/
        _45assignable_51038 = _9FALSE_444;
        goto LC; // [7578] 7739

        /** emit.e:1812		case PROFILE, TASK_SUSPEND then*/
        case 151:
        case 171:

        /** emit.e:1813			a = Pop()*/
        _a_51962 = _45Pop();
        if (!IS_ATOM_INT(_a_51962)) {
            _1 = (object)(DBL_PTR(_a_51962)->dbl);
            DeRefDS(_a_51962);
            _a_51962 = _1;
        }

        /** emit.e:1814			emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1815			emit_addr(a)*/
        _45emit_addr(_a_51962);

        /** emit.e:1816			assignable = FALSE*/
        _45assignable_51038 = _9FALSE_444;
        goto LC; // [7610] 7739

        /** emit.e:1818		case TRACE then*/
        case 64:

        /** emit.e:1819			a = Pop()*/
        _a_51962 = _45Pop();
        if (!IS_ATOM_INT(_a_51962)) {
            _1 = (object)(DBL_PTR(_a_51962)->dbl);
            DeRefDS(_a_51962);
            _a_51962 = _1;
        }

        /** emit.e:1820			if OpTrace then*/
        if (_12OpTrace_20296 == 0)
        {
            goto LAF; // [7627] 7673
        }
        else{
        }

        /** emit.e:1822				emit_opcode(op)*/
        _45emit_opcode(_op_51960);

        /** emit.e:1823				emit_addr(a)*/
        _45emit_addr(_a_51962);

        /** emit.e:1824				if TRANSLATE then*/
        if (_12TRANSLATE_19834 == 0)
        {
            goto LB0; // [7644] 7672
        }
        else{
        }

        /** emit.e:1825					if not trace_called then*/
        if (_45trace_called_51023 != 0)
        goto LB1; // [7651] 7662

        /** emit.e:1826						Warning(217,0)*/
        RefDS(_22024);
        _49Warning(217LL, 0LL, _22024);
LB1: 

        /** emit.e:1828					trace_called = TRUE*/
        _45trace_called_51023 = _9TRUE_446;
LB0: 
LAF: 

        /** emit.e:1831			assignable = FALSE*/
        _45assignable_51038 = _9FALSE_444;
        goto LC; // [7680] 7739

        /** emit.e:1833		case REF_TEMP then*/
        case 207:

        /** emit.e:1835			emit_opcode( REF_TEMP )*/
        _45emit_opcode(207LL);

        /** emit.e:1836			emit_addr( Pop() )*/
        _27152 = _45Pop();
        _45emit_addr(_27152);
        _27152 = NOVALUE;
        goto LC; // [7701] 7739

        /** emit.e:1838		case DEREF_TEMP then*/
        case 208:

        /** emit.e:1839			emit_opcode( DEREF_TEMP )*/
        _45emit_opcode(208LL);

        /** emit.e:1840			emit_addr( Pop() )*/
        _27153 = _45Pop();
        _45emit_addr(_27153);
        _27153 = NOVALUE;
        goto LC; // [7722] 7739

        /** emit.e:1842		case else*/
        default:

        /** emit.e:1843			InternalErr(259, {op})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _op_51960;
        _27154 = MAKE_SEQ(_1);
        _49InternalErr(259LL, _27154);
        _27154 = NOVALUE;
    ;}LC: 

    /** emit.e:1847		previous_op = op*/
    _12previous_op_20325 = _op_51960;

    /** emit.e:1848		inlined = 0*/
    _45inlined_51938 = 0LL;

    /** emit.e:1850	end procedure*/
    DeRef(_obj_51974);
    DeRef(_elements_51975);
    DeRef(_element_vals_51976);
    DeRef(_27107);
    _27107 = NOVALUE;
    DeRef(_26751);
    _26751 = NOVALUE;
    _26589 = NOVALUE;
    DeRef(_26812);
    _26812 = NOVALUE;
    DeRef(_26849);
    _26849 = NOVALUE;
    DeRef(_26621);
    _26621 = NOVALUE;
    DeRef(_26761);
    _26761 = NOVALUE;
    DeRef(_26739);
    _26739 = NOVALUE;
    _26894 = NOVALUE;
    DeRef(_26573);
    _26573 = NOVALUE;
    DeRef(_26827);
    _26827 = NOVALUE;
    DeRef(_26571);
    _26571 = NOVALUE;
    DeRef(_26877);
    _26877 = NOVALUE;
    DeRef(_27029);
    _27029 = NOVALUE;
    DeRef(_26883);
    _26883 = NOVALUE;
    DeRef(_26838);
    _26838 = NOVALUE;
    DeRef(_27049);
    _27049 = NOVALUE;
    _26683 = NOVALUE;
    DeRef(_26990);
    _26990 = NOVALUE;
    DeRef(_26569);
    _26569 = NOVALUE;
    DeRef(_26859);
    _26859 = NOVALUE;
    DeRef(_26625);
    _26625 = NOVALUE;
    DeRef(_26836);
    _26836 = NOVALUE;
    DeRef(_26773);
    _26773 = NOVALUE;
    DeRef(_26759);
    _26759 = NOVALUE;
    DeRef(_26978);
    _26978 = NOVALUE;
    DeRef(_26825);
    _26825 = NOVALUE;
    DeRef(_26782);
    _26782 = NOVALUE;
    DeRef(_27013);
    _27013 = NOVALUE;
    DeRef(_26654);
    _26654 = NOVALUE;
    DeRef(_27045);
    _27045 = NOVALUE;
    DeRef(_26887);
    _26887 = NOVALUE;
    DeRef(_26686);
    _26686 = NOVALUE;
    _26688 = NOVALUE;
    _26659 = NOVALUE;
    DeRef(_27065);
    _27065 = NOVALUE;
    DeRef(_26786);
    _26786 = NOVALUE;
    _26657 = NOVALUE;
    DeRef(_26780);
    _26780 = NOVALUE;
    DeRef(_27027);
    _27027 = NOVALUE;
    DeRef(_26983);
    _26983 = NOVALUE;
    DeRef(_26964);
    _26964 = NOVALUE;
    DeRef(_26899);
    _26899 = NOVALUE;
    DeRef(_27000);
    _27000 = NOVALUE;
    DeRef(_26745);
    _26745 = NOVALUE;
    DeRef(_27057);
    _27057 = NOVALUE;
    DeRef(_26799);
    _26799 = NOVALUE;
    DeRef(_26856);
    _26856 = NOVALUE;
    DeRef(_26755);
    _26755 = NOVALUE;
    DeRef(_26565);
    _26565 = NOVALUE;
    DeRef(_27053);
    _27053 = NOVALUE;
    DeRef(_26959);
    _26959 = NOVALUE;
    DeRef(_26705);
    _26705 = NOVALUE;
    DeRef(_26853);
    _26853 = NOVALUE;
    DeRef(_26665);
    _26665 = NOVALUE;
    DeRef(_26679);
    _26679 = NOVALUE;
    DeRef(_27068);
    _27068 = NOVALUE;
    DeRef(_26601);
    _26601 = NOVALUE;
    DeRef(_26808);
    _26808 = NOVALUE;
    DeRef(_26567);
    _26567 = NOVALUE;
    DeRef(_27111);
    _27111 = NOVALUE;
    DeRef(_26832);
    _26832 = NOVALUE;
    DeRef(_26640);
    _26640 = NOVALUE;
    DeRef(_26818);
    _26818 = NOVALUE;
    DeRef(_26606);
    _26606 = NOVALUE;
    DeRef(_26718);
    _26718 = NOVALUE;
    DeRef(_26777);
    _26777 = NOVALUE;
    DeRef(_26971);
    _26971 = NOVALUE;
    DeRef(_26861);
    _26861 = NOVALUE;
    _26642 = NOVALUE;
    DeRef(_26609);
    _26609 = NOVALUE;
    DeRef(_27119);
    _27119 = NOVALUE;
    DeRef(_27041);
    _27041 = NOVALUE;
    _27122 = NOVALUE;
    DeRef(_26937);
    _26937 = NOVALUE;
    DeRef(_27061);
    _27061 = NOVALUE;
    DeRef(_26803);
    _26803 = NOVALUE;
    DeRef(_26619);
    _26619 = NOVALUE;
    DeRef(_26814);
    _26814 = NOVALUE;
    DeRef(_26996);
    _26996 = NOVALUE;
    DeRef(_26644);
    _26644 = NOVALUE;
    _26896 = NOVALUE;
    DeRef(_26879);
    _26879 = NOVALUE;
    DeRef(_27037);
    _27037 = NOVALUE;
    DeRef(_26891);
    _26891 = NOVALUE;
    DeRef(_26673);
    _26673 = NOVALUE;
    DeRef(_26616);
    _26616 = NOVALUE;
    return;
    ;
}


void _45emit_assign_op(object _op_53439)
{
    object _0, _1, _2;
    

    /** emit.e:1854		if op = PLUS_EQUALS then*/
    if (_op_53439 != 515LL)
    goto L1; // [7] 21

    /** emit.e:1855			emit_op(PLUS)*/
    _45emit_op(11LL);
    goto L2; // [18] 86
L1: 

    /** emit.e:1856		elsif op = MINUS_EQUALS then*/
    if (_op_53439 != 516LL)
    goto L3; // [25] 39

    /** emit.e:1857			emit_op(MINUS)*/
    _45emit_op(10LL);
    goto L2; // [36] 86
L3: 

    /** emit.e:1858		elsif op = MULTIPLY_EQUALS then*/
    if (_op_53439 != 517LL)
    goto L4; // [43] 55

    /** emit.e:1859			emit_op(rw:MULTIPLY)*/
    _45emit_op(13LL);
    goto L2; // [52] 86
L4: 

    /** emit.e:1860		elsif op = DIVIDE_EQUALS then*/
    if (_op_53439 != 518LL)
    goto L5; // [59] 71

    /** emit.e:1861			emit_op(rw:DIVIDE)*/
    _45emit_op(14LL);
    goto L2; // [68] 86
L5: 

    /** emit.e:1862		elsif op = CONCAT_EQUALS then*/
    if (_op_53439 != 519LL)
    goto L6; // [75] 85

    /** emit.e:1863			emit_op(rw:CONCAT)*/
    _45emit_op(15LL);
L6: 
L2: 

    /** emit.e:1865	end procedure*/
    return;
    ;
}


void _45StartSourceLine(object _sl_53459, object _dup_ok_53460, object _emit_coverage_53461)
{
    object _line_span_53464 = NOVALUE;
    object _27176 = NOVALUE;
    object _27174 = NOVALUE;
    object _27173 = NOVALUE;
    object _27172 = NOVALUE;
    object _27171 = NOVALUE;
    object _27170 = NOVALUE;
    object _27168 = NOVALUE;
    object _27165 = NOVALUE;
    object _27163 = NOVALUE;
    object _27162 = NOVALUE;
    object _27161 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:1873		if gline_number = LastLineNumber then*/
    if (_12gline_number_20231 != _61LastLineNumber_25584)
    goto L1; // [13] 66

    /** emit.e:1874			if length(LineTable) then*/
    if (IS_SEQUENCE(_12LineTable_20316)){
            _27161 = SEQ_PTR(_12LineTable_20316)->length;
    }
    else {
        _27161 = 1;
    }
    if (_27161 == 0)
    {
        _27161 = NOVALUE;
        goto L2; // [24] 55
    }
    else{
        _27161 = NOVALUE;
    }

    /** emit.e:1875				if dup_ok then*/
    if (_dup_ok_53460 == 0)
    {
        goto L3; // [29] 47
    }
    else{
    }

    /** emit.e:1876					emit_op( STARTLINE )*/
    _45emit_op(58LL);

    /** emit.e:1877					emit_addr( gline_number )*/
    _45emit_addr(_12gline_number_20231);
L3: 

    /** emit.e:1879				return -- ignore duplicates*/
    return;
    goto L4; // [52] 65
L2: 

    /** emit.e:1882				sl = FALSE -- top-level new statement to execute on same line*/
    _sl_53459 = _9FALSE_444;
L4: 
L1: 

    /** emit.e:1885		LastLineNumber = gline_number*/
    _61LastLineNumber_25584 = _12gline_number_20231;

    /** emit.e:1888		line_span = gline_number - SymTab[CurrentSub][S_FIRSTLINE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27162 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_27162);
    if (!IS_ATOM_INT(_12S_FIRSTLINE_19904)){
        _27163 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FIRSTLINE_19904)->dbl));
    }
    else{
        _27163 = (object)*(((s1_ptr)_2)->base + _12S_FIRSTLINE_19904);
    }
    _27162 = NOVALUE;
    if (IS_ATOM_INT(_27163)) {
        _line_span_53464 = _12gline_number_20231 - _27163;
    }
    else {
        _line_span_53464 = binary_op(MINUS, _12gline_number_20231, _27163);
    }
    _27163 = NOVALUE;
    if (!IS_ATOM_INT(_line_span_53464)) {
        _1 = (object)(DBL_PTR(_line_span_53464)->dbl);
        DeRefDS(_line_span_53464);
        _line_span_53464 = _1;
    }

    /** emit.e:1889		while length(LineTable) < line_span do*/
L5: 
    if (IS_SEQUENCE(_12LineTable_20316)){
            _27165 = SEQ_PTR(_12LineTable_20316)->length;
    }
    else {
        _27165 = 1;
    }
    if (_27165 >= _line_span_53464)
    goto L6; // [109] 128

    /** emit.e:1890			LineTable = append(LineTable, -1) -- filler*/
    Append(&_12LineTable_20316, _12LineTable_20316, -1LL);

    /** emit.e:1891		end while*/
    goto L5; // [125] 104
L6: 

    /** emit.e:1892		LineTable = append(LineTable, length(Code))*/
    if (IS_SEQUENCE(_12Code_20315)){
            _27168 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _27168 = 1;
    }
    Append(&_12LineTable_20316, _12LineTable_20316, _27168);
    _27168 = NOVALUE;

    /** emit.e:1894		if sl and (TRANSLATE or (OpTrace or OpProfileStatement)) then*/
    if (_sl_53459 == 0) {
        goto L7; // [145] 190
    }
    if (_12TRANSLATE_19834 != 0) {
        DeRef(_27171);
        _27171 = 1;
        goto L8; // [151] 171
    }
    if (_12OpTrace_20296 != 0) {
        _27172 = 1;
        goto L9; // [157] 167
    }
    _27172 = (_12OpProfileStatement_20298 != 0);
L9: 
    DeRef(_27171);
    _27171 = (_27172 != 0);
L8: 
    if (_27171 == 0)
    {
        _27171 = NOVALUE;
        goto L7; // [172] 190
    }
    else{
        _27171 = NOVALUE;
    }

    /** emit.e:1896			emit_op(STARTLINE)*/
    _45emit_op(58LL);

    /** emit.e:1897			emit_addr(gline_number)*/
    _45emit_addr(_12gline_number_20231);
L7: 

    /** emit.e:1901		if (sl and emit_coverage = COVERAGE_INCLUDE) or emit_coverage = COVERAGE_OVERRIDE then*/
    if (_sl_53459 == 0) {
        _27173 = 0;
        goto LA; // [192] 206
    }
    _27174 = (_emit_coverage_53461 == 2LL);
    _27173 = (_27174 != 0);
LA: 
    if (_27173 != 0) {
        goto LB; // [206] 221
    }
    _27176 = (_emit_coverage_53461 == 3LL);
    if (_27176 == 0)
    {
        DeRef(_27176);
        _27176 = NOVALUE;
        goto LC; // [217] 229
    }
    else{
        DeRef(_27176);
        _27176 = NOVALUE;
    }
LB: 

    /** emit.e:1902			include_line( gline_number )*/
    _50include_line(_12gline_number_20231);
LC: 

    /** emit.e:1905	end procedure*/
    DeRef(_27174);
    _27174 = NOVALUE;
    return;
    ;
}


object _45has_forward_params(object _sym_53518)
{
    object _27182 = NOVALUE;
    object _27181 = NOVALUE;
    object _27180 = NOVALUE;
    object _27179 = NOVALUE;
    object _27178 = NOVALUE;
    object _27177 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:1908		for i = cgi - (SymTab[sym][S_NUM_ARGS]-1) to cgi do*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _27177 = (object)*(((s1_ptr)_2)->base + _sym_53518);
    _2 = (object)SEQ_PTR(_27177);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _27178 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _27178 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _27177 = NOVALUE;
    if (IS_ATOM_INT(_27178)) {
        _27179 = _27178 - 1LL;
        if ((object)((uintptr_t)_27179 +(uintptr_t) HIGH_BITS) >= 0){
            _27179 = NewDouble((eudouble)_27179);
        }
    }
    else {
        _27179 = binary_op(MINUS, _27178, 1LL);
    }
    _27178 = NOVALUE;
    if (IS_ATOM_INT(_27179)) {
        _27180 = _45cgi_51036 - _27179;
        if ((object)((uintptr_t)_27180 +(uintptr_t) HIGH_BITS) >= 0){
            _27180 = NewDouble((eudouble)_27180);
        }
    }
    else {
        _27180 = binary_op(MINUS, _45cgi_51036, _27179);
    }
    DeRef(_27179);
    _27179 = NOVALUE;
    _27181 = _45cgi_51036;
    {
        object _i_53520;
        Ref(_27180);
        _i_53520 = _27180;
L1: 
        if (binary_op_a(GREATER, _i_53520, _27181)){
            goto L2; // [32] 65
        }

        /** emit.e:1909			if cg_stack[i] < 0 then*/
        _2 = (object)SEQ_PTR(_45cg_stack_51035);
        if (!IS_ATOM_INT(_i_53520)){
            _27182 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_53520)->dbl));
        }
        else{
            _27182 = (object)*(((s1_ptr)_2)->base + _i_53520);
        }
        if (binary_op_a(GREATEREQ, _27182, 0LL)){
            _27182 = NOVALUE;
            goto L3; // [47] 58
        }
        _27182 = NOVALUE;

        /** emit.e:1910				return 1*/
        DeRef(_i_53520);
        DeRef(_27180);
        _27180 = NOVALUE;
        return 1LL;
L3: 

        /** emit.e:1912		end for*/
        _0 = _i_53520;
        if (IS_ATOM_INT(_i_53520)) {
            _i_53520 = _i_53520 + 1LL;
            if ((object)((uintptr_t)_i_53520 +(uintptr_t) HIGH_BITS) >= 0){
                _i_53520 = NewDouble((eudouble)_i_53520);
            }
        }
        else {
            _i_53520 = binary_op_a(PLUS, _i_53520, 1LL);
        }
        DeRef(_0);
        goto L1; // [60] 39
L2: 
        ;
        DeRef(_i_53520);
    }

    /** emit.e:1913		return 0*/
    DeRef(_27180);
    _27180 = NOVALUE;
    return 0LL;
    ;
}



// 0xDCD18041
