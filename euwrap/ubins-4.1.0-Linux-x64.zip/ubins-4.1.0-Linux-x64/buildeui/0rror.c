// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _49screen_output(object _f_49323, object _msg_49324)
{
    object _0, _1, _2;
    

    /** error.e:44		puts(f, msg)*/
    EPuts(2LL, _msg_49324); // DJP 

    /** error.e:45	end procedure*/
    DeRefDS(_msg_49324);
    return;
    ;
}


void _49Warning(object _msg_49327, object _mask_49328, object _args_49329)
{
    object _orig_mask_49330 = NOVALUE;
    object _text_49331 = NOVALUE;
    object _w_name_49332 = NOVALUE;
    object _25365 = NOVALUE;
    object _25363 = NOVALUE;
    object _25361 = NOVALUE;
    object _25358 = NOVALUE;
    object _25353 = NOVALUE;
    object _25351 = NOVALUE;
    object _25350 = NOVALUE;
    object _25349 = NOVALUE;
    object _25348 = NOVALUE;
    object _25346 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:54		if display_warnings = 0 then*/
    if (_49display_warnings_49311 != 0LL)
    goto L1; // [9] 19

    /** error.e:55			return*/
    DeRef(_msg_49327);
    DeRefDS(_args_49329);
    DeRef(_text_49331);
    DeRef(_w_name_49332);
    return;
L1: 

    /** error.e:58		if not Strict_is_on or Strict_Override then*/
    _25346 = (_12Strict_is_on_20292 == 0);
    if (_25346 != 0) {
        goto L2; // [26] 37
    }
    if (_12Strict_Override_20293 == 0)
    {
        goto L3; // [33] 56
    }
    else{
    }
L2: 

    /** error.e:59			if find(mask, strict_only_warnings) then*/
    _25348 = find_from(_mask_49328, _12strict_only_warnings_20290, 1LL);
    if (_25348 == 0)
    {
        _25348 = NOVALUE;
        goto L4; // [46] 55
    }
    else{
        _25348 = NOVALUE;
    }

    /** error.e:60				return*/
    DeRef(_msg_49327);
    DeRefDS(_args_49329);
    DeRef(_text_49331);
    DeRef(_w_name_49332);
    DeRef(_25346);
    _25346 = NOVALUE;
    return;
L4: 
L3: 

    /** error.e:64		orig_mask = mask -- =0 for non maskable warnings - none implemented so far*/
    _orig_mask_49330 = _mask_49328;

    /** error.e:65		if Strict_is_on and Strict_Override = 0 then*/
    if (_12Strict_is_on_20292 == 0) {
        goto L5; // [65] 85
    }
    _25350 = (_12Strict_Override_20293 == 0LL);
    if (_25350 == 0)
    {
        DeRef(_25350);
        _25350 = NOVALUE;
        goto L5; // [76] 85
    }
    else{
        DeRef(_25350);
        _25350 = NOVALUE;
    }

    /** error.e:66			mask = 0*/
    _mask_49328 = 0LL;
L5: 

    /** error.e:69		if mask = 0 or and_bits(OpWarning, mask) then*/
    _25351 = (_mask_49328 == 0LL);
    if (_25351 != 0) {
        goto L6; // [91] 106
    }
    {uintptr_t tu;
         tu = (uintptr_t)_12OpWarning_20294 & (uintptr_t)_mask_49328;
         _25353 = MAKE_UINT(tu);
    }
    if (_25353 == 0) {
        DeRef(_25353);
        _25353 = NOVALUE;
        goto L7; // [102] 215
    }
    else {
        if (!IS_ATOM_INT(_25353) && DBL_PTR(_25353)->dbl == 0.0){
            DeRef(_25353);
            _25353 = NOVALUE;
            goto L7; // [102] 215
        }
        DeRef(_25353);
        _25353 = NOVALUE;
    }
    DeRef(_25353);
    _25353 = NOVALUE;
L6: 

    /** error.e:70			if orig_mask != 0 then*/
    if (_orig_mask_49330 == 0LL)
    goto L8; // [108] 122

    /** error.e:71				orig_mask = find(orig_mask,warning_flags)*/
    _orig_mask_49330 = find_from(_orig_mask_49330, _12warning_flags_20269, 1LL);
L8: 

    /** error.e:74			if orig_mask != 0 then*/
    if (_orig_mask_49330 == 0LL)
    goto L9; // [124] 145

    /** error.e:75				w_name = "{ " & warning_names[orig_mask] & " }"*/
    _2 = (object)SEQ_PTR(_12warning_names_20271);
    _25358 = (object)*(((s1_ptr)_2)->base + _orig_mask_49330);
    {
        object concat_list[3];

        concat_list[0] = _25359;
        concat_list[1] = _25358;
        concat_list[2] = _25357;
        Concat_N((object_ptr)&_w_name_49332, concat_list, 3);
    }
    _25358 = NOVALUE;
    goto LA; // [142] 153
L9: 

    /** error.e:77				w_name = "" -- not maskable*/
    RefDS(_22024);
    DeRef(_w_name_49332);
    _w_name_49332 = _22024;
LA: 

    /** error.e:80			if atom(msg) then*/
    _25361 = IS_ATOM(_msg_49327);
    if (_25361 == 0)
    {
        _25361 = NOVALUE;
        goto LB; // [158] 170
    }
    else{
        _25361 = NOVALUE;
    }

    /** error.e:81				msg = GetMsgText(msg, 1, args)*/
    Ref(_msg_49327);
    RefDS(_args_49329);
    _0 = _msg_49327;
    _msg_49327 = _30GetMsgText(_msg_49327, 1LL, _args_49329);
    DeRef(_0);
LB: 

    /** error.e:84			text = GetMsgText(WARNING_1T2, 0, {w_name, msg})*/
    Ref(_msg_49327);
    RefDS(_w_name_49332);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _w_name_49332;
    ((intptr_t *)_2)[2] = _msg_49327;
    _25363 = MAKE_SEQ(_1);
    _0 = _text_49331;
    _text_49331 = _30GetMsgText(204LL, 0LL, _25363);
    DeRef(_0);
    _25363 = NOVALUE;

    /** error.e:85			if find(text, warning_list) then*/
    _25365 = find_from(_text_49331, _49warning_list_49320, 1LL);
    if (_25365 == 0)
    {
        _25365 = NOVALUE;
        goto LC; // [197] 206
    }
    else{
        _25365 = NOVALUE;
    }

    /** error.e:86				return -- duplicate*/
    DeRef(_msg_49327);
    DeRefDS(_args_49329);
    DeRefDS(_text_49331);
    DeRefDS(_w_name_49332);
    DeRef(_25346);
    _25346 = NOVALUE;
    DeRef(_25351);
    _25351 = NOVALUE;
    return;
LC: 

    /** error.e:89			warning_list = append(warning_list, text)*/
    RefDS(_text_49331);
    Append(&_49warning_list_49320, _49warning_list_49320, _text_49331);
L7: 

    /** error.e:91	end procedure*/
    DeRef(_msg_49327);
    DeRefDS(_args_49329);
    DeRef(_text_49331);
    DeRef(_w_name_49332);
    DeRef(_25346);
    _25346 = NOVALUE;
    DeRef(_25351);
    _25351 = NOVALUE;
    return;
    ;
}


object _49ShowWarnings()
{
    object _c_49397 = NOVALUE;
    object _errfile_49398 = NOVALUE;
    object _twf_49399 = NOVALUE;
    object _25405 = NOVALUE;
    object _25401 = NOVALUE;
    object _25400 = NOVALUE;
    object _25399 = NOVALUE;
    object _25398 = NOVALUE;
    object _25397 = NOVALUE;
    object _25396 = NOVALUE;
    object _25394 = NOVALUE;
    object _25393 = NOVALUE;
    object _25392 = NOVALUE;
    object _25390 = NOVALUE;
    object _25389 = NOVALUE;
    object _25388 = NOVALUE;
    object _25387 = NOVALUE;
    object _25385 = NOVALUE;
    object _25381 = NOVALUE;
    object _25379 = NOVALUE;
    object _25378 = NOVALUE;
    object _25377 = NOVALUE;
    object _25375 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:117		if display_warnings = 0 or length(warning_list) = 0 then*/
    _25375 = (_49display_warnings_49311 == 0LL);
    if (_25375 != 0) {
        goto L1; // [9] 27
    }
    if (IS_SEQUENCE(_49warning_list_49320)){
            _25377 = SEQ_PTR(_49warning_list_49320)->length;
    }
    else {
        _25377 = 1;
    }
    _25378 = (_25377 == 0LL);
    _25377 = NOVALUE;
    if (_25378 == 0)
    {
        DeRef(_25378);
        _25378 = NOVALUE;
        goto L2; // [23] 39
    }
    else{
        DeRef(_25378);
        _25378 = NOVALUE;
    }
L1: 

    /** error.e:118			return length(warning_list)*/
    if (IS_SEQUENCE(_49warning_list_49320)){
            _25379 = SEQ_PTR(_49warning_list_49320)->length;
    }
    else {
        _25379 = 1;
    }
    DeRef(_25375);
    _25375 = NOVALUE;
    return _25379;
L2: 

    /** error.e:121		if TempErrFile > 0 then*/
    if (_49TempErrFile_49308 <= 0LL)
    goto L3; // [43] 57

    /** error.e:122			errfile = TempErrFile*/
    _errfile_49398 = _49TempErrFile_49308;
    goto L4; // [54] 67
L3: 

    /** error.e:124			errfile = STDERR*/
    _errfile_49398 = 2LL;
L4: 

    /** error.e:127		if not integer(TempWarningName) then*/
    if (IS_ATOM_INT(_12TempWarningName_20240))
    _25381 = 1;
    else if (IS_ATOM_DBL(_12TempWarningName_20240))
    _25381 = IS_ATOM_INT(DoubleToInt(_12TempWarningName_20240));
    else
    _25381 = 0;
    if (_25381 != 0)
    goto L5; // [74] 183
    _25381 = NOVALUE;

    /** error.e:128			twf = open(TempWarningName,"w")*/
    _twf_49399 = EOpen(_12TempWarningName_20240, _22169, 0LL);

    /** error.e:129			if twf = -1 then*/
    if (_twf_49399 != -1LL)
    goto L6; // [88] 140

    /** error.e:130				ShowMsg(errfile, UNABLE_TO_CREATE_WARNING_FILE_1, {TempWarningName})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_12TempWarningName_20240);
    ((intptr_t*)_2)[1] = _12TempWarningName_20240;
    _25385 = MAKE_SEQ(_1);
    _30ShowMsg(_errfile_49398, 205LL, _25385, 1LL);
    _25385 = NOVALUE;

    /** error.e:131				if errfile != STDERR then*/
    if (_errfile_49398 == 2LL)
    goto L7; // [114] 177

    /** error.e:132					ShowMsg(STDERR, UNABLE_TO_CREATE_WARNING_FILE_1, {TempWarningName})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_12TempWarningName_20240);
    ((intptr_t*)_2)[1] = _12TempWarningName_20240;
    _25387 = MAKE_SEQ(_1);
    _30ShowMsg(2LL, 205LL, _25387, 1LL);
    _25387 = NOVALUE;
    goto L7; // [137] 177
L6: 

    /** error.e:135				for i = 1 to length(warning_list) do*/
    if (IS_SEQUENCE(_49warning_list_49320)){
            _25388 = SEQ_PTR(_49warning_list_49320)->length;
    }
    else {
        _25388 = 1;
    }
    {
        object _i_49432;
        _i_49432 = 1LL;
L8: 
        if (_i_49432 > _25388){
            goto L9; // [147] 172
        }

        /** error.e:136					puts(twf, warning_list[i])*/
        _2 = (object)SEQ_PTR(_49warning_list_49320);
        _25389 = (object)*(((s1_ptr)_2)->base + _i_49432);
        EPuts(_twf_49399, _25389); // DJP 
        _25389 = NOVALUE;

        /** error.e:137				end for*/
        _i_49432 = _i_49432 + 1LL;
        goto L8; // [167] 154
L9: 
        ;
    }

    /** error.e:138			    close(twf)*/
    EClose(_twf_49399);
L7: 

    /** error.e:140			TempWarningName = 99 -- Flag that we have done this already.*/
    DeRef(_12TempWarningName_20240);
    _12TempWarningName_20240 = 99LL;
L5: 

    /** error.e:143		if batch_job = 0 or errfile != STDERR then*/
    _25390 = (_12batch_job_20239 == 0LL);
    if (_25390 != 0) {
        goto LA; // [191] 208
    }
    _25392 = (_errfile_49398 != 2LL);
    if (_25392 == 0)
    {
        DeRef(_25392);
        _25392 = NOVALUE;
        goto LB; // [204] 317
    }
    else{
        DeRef(_25392);
        _25392 = NOVALUE;
    }
LA: 

    /** error.e:144			for i = 1 to length(warning_list) do*/
    if (IS_SEQUENCE(_49warning_list_49320)){
            _25393 = SEQ_PTR(_49warning_list_49320)->length;
    }
    else {
        _25393 = 1;
    }
    {
        object _i_49443;
        _i_49443 = 1LL;
LC: 
        if (_i_49443 > _25393){
            goto LD; // [215] 316
        }

        /** error.e:145				puts(errfile, warning_list[i])*/
        _2 = (object)SEQ_PTR(_49warning_list_49320);
        _25394 = (object)*(((s1_ptr)_2)->base + _i_49443);
        EPuts(_errfile_49398, _25394); // DJP 
        _25394 = NOVALUE;

        /** error.e:146				if errfile = STDERR then*/
        if (_errfile_49398 != 2LL)
        goto LE; // [239] 309

        /** error.e:147					if remainder(i, 20) = 0 and batch_job = 0 and test_only = 0 then*/
        _25396 = (_i_49443 % 20LL);
        _25397 = (_25396 == 0LL);
        _25396 = NOVALUE;
        if (_25397 == 0) {
            _25398 = 0;
            goto LF; // [253] 267
        }
        _25399 = (_12batch_job_20239 == 0LL);
        _25398 = (_25399 != 0);
LF: 
        if (_25398 == 0) {
            goto L10; // [267] 308
        }
        _25401 = (_12test_only_20238 == 0LL);
        if (_25401 == 0)
        {
            DeRef(_25401);
            _25401 = NOVALUE;
            goto L10; // [278] 308
        }
        else{
            DeRef(_25401);
            _25401 = NOVALUE;
        }

        /** error.e:148						ShowMsg(errfile, PRESS_ENTER_TO_CONTINUE_Q_TO_QUIT)*/
        RefDS(_22024);
        _30ShowMsg(_errfile_49398, 206LL, _22024, 1LL);

        /** error.e:149						c = getc(0)*/
        if (0LL != last_r_file_no) {
            last_r_file_ptr = which_file(0LL, EF_READ);
            last_r_file_no = 0LL;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _c_49397 = getc((FILE*)xstdin);
            }
            else{
                _c_49397 = getc(last_r_file_ptr);
            }
        }
        else{
            _c_49397 = getc(last_r_file_ptr);
        }

        /** error.e:150						if c = 'q' then*/
        if (_c_49397 != 113LL)
        goto L11; // [298] 307

        /** error.e:151							exit*/
        goto LD; // [304] 316
L11: 
L10: 
LE: 

        /** error.e:155			end for*/
        _i_49443 = _i_49443 + 1LL;
        goto LC; // [311] 222
LD: 
        ;
    }
LB: 

    /** error.e:158		return length(warning_list)*/
    if (IS_SEQUENCE(_49warning_list_49320)){
            _25405 = SEQ_PTR(_49warning_list_49320)->length;
    }
    else {
        _25405 = 1;
    }
    DeRef(_25375);
    _25375 = NOVALUE;
    DeRef(_25390);
    _25390 = NOVALUE;
    DeRef(_25399);
    _25399 = NOVALUE;
    DeRef(_25397);
    _25397 = NOVALUE;
    return _25405;
    ;
}


void _49ShowDefines(object _errfile_49467)
{
    object _c_49468 = NOVALUE;
    object _25419 = NOVALUE;
    object _25418 = NOVALUE;
    object _25416 = NOVALUE;
    object _25415 = NOVALUE;
    object _25412 = NOVALUE;
    object _25411 = NOVALUE;
    object _25410 = NOVALUE;
    object _25409 = NOVALUE;
    object _25408 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:164		if errfile=0 then*/
    if (_errfile_49467 != 0LL)
    goto L1; // [5] 19

    /** error.e:165			errfile = STDERR*/
    _errfile_49467 = 2LL;
L1: 

    /** error.e:168		puts(errfile, format("\n--- [1] ---\n", {GetMsgText(DEFINED_WORDS,0)}))*/
    RefDS(_22024);
    _25408 = _30GetMsgText(207LL, 0LL, _22024);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _25408;
    _25409 = MAKE_SEQ(_1);
    _25408 = NOVALUE;
    RefDS(_25407);
    _25410 = _18format(_25407, _25409);
    _25409 = NOVALUE;
    EPuts(_errfile_49467, _25410); // DJP 
    DeRef(_25410);
    _25410 = NOVALUE;

    /** error.e:170		for i = 1 to length(OpDefines) do*/
    if (IS_SEQUENCE(_12OpDefines_20300)){
            _25411 = SEQ_PTR(_12OpDefines_20300)->length;
    }
    else {
        _25411 = 1;
    }
    {
        object _i_49480;
        _i_49480 = 1LL;
L2: 
        if (_i_49480 > _25411){
            goto L3; // [48] 100
        }

        /** error.e:171			if find(OpDefines[i], {"_PLAT_START", "_PLAT_STOP"}) = 0 then*/
        _2 = (object)SEQ_PTR(_12OpDefines_20300);
        _25412 = (object)*(((s1_ptr)_2)->base + _i_49480);
        RefDS(_25414);
        RefDS(_25413);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _25413;
        ((intptr_t *)_2)[2] = _25414;
        _25415 = MAKE_SEQ(_1);
        _25416 = find_from(_25412, _25415, 1LL);
        _25412 = NOVALUE;
        DeRefDS(_25415);
        _25415 = NOVALUE;
        if (_25416 != 0LL)
        goto L4; // [72] 93

        /** error.e:172				printf(errfile, "%s\n", {OpDefines[i]})*/
        _2 = (object)SEQ_PTR(_12OpDefines_20300);
        _25418 = (object)*(((s1_ptr)_2)->base + _i_49480);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_25418);
        ((intptr_t*)_2)[1] = _25418;
        _25419 = MAKE_SEQ(_1);
        _25418 = NOVALUE;
        EPrintf(_errfile_49467, _25298, _25419);
        DeRefDS(_25419);
        _25419 = NOVALUE;
L4: 

        /** error.e:174		end for*/
        _i_49480 = _i_49480 + 1LL;
        goto L2; // [95] 55
L3: 
        ;
    }

    /** error.e:175		puts(errfile, "-------------------\n")*/
    EPuts(_errfile_49467, _25420); // DJP 

    /** error.e:177	end procedure*/
    return;
    ;
}


void _49Cleanup(object _status_49497)
{
    object _w_49498 = NOVALUE;
    object _show_error_49499 = NOVALUE;
    object _31792 = NOVALUE;
    object _25438 = NOVALUE;
    object _25437 = NOVALUE;
    object _25436 = NOVALUE;
    object _25435 = NOVALUE;
    object _25434 = NOVALUE;
    object _25433 = NOVALUE;
    object _25432 = NOVALUE;
    object _25431 = NOVALUE;
    object _25430 = NOVALUE;
    object _25429 = NOVALUE;
    object _25427 = NOVALUE;
    object _25426 = NOVALUE;
    object _25425 = NOVALUE;
    object _25424 = NOVALUE;
    object _25423 = NOVALUE;
    object _25421 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_status_49497)) {
        _1 = (object)(DBL_PTR(_status_49497)->dbl);
        DeRefDS(_status_49497);
        _status_49497 = _1;
    }

    /** error.e:182		integer w, show_error = 0*/
    _show_error_49499 = 0LL;

    /** error.e:184		ifdef EU_EX then*/

    /** error.e:187			write_coverage_db()*/
    _31792 = _50write_coverage_db();
    DeRef(_31792);
    _31792 = NOVALUE;

    /** error.e:190		show_error = 1*/
    _show_error_49499 = 1LL;

    /** error.e:196		if object(src_file) = 0 then*/
    if( NOVALUE == _12src_file_20348 ){
        _25421 = 0;
    }
    else{
        _25421 = 1;
    }
    if (_25421 != 0LL)
    goto L1; // [27] 41

    /** error.e:197			src_file = -1*/
    _12src_file_20348 = -1LL;
    goto L2; // [38] 93
L1: 

    /** error.e:198		elsif src_file >= 0 and (src_file != repl_file or not repl) then*/
    _25423 = (_12src_file_20348 >= 0LL);
    if (_25423 == 0) {
        goto L3; // [49] 92
    }
    _25425 = (_12src_file_20348 != 5555LL);
    if (_25425 != 0) {
        DeRef(_25426);
        _25426 = 1;
        goto L4; // [61] 74
    }
    _25427 = (0LL == 0);
    _25426 = (_25427 != 0);
L4: 
    if (_25426 == 0)
    {
        _25426 = NOVALUE;
        goto L3; // [75] 92
    }
    else{
        _25426 = NOVALUE;
    }

    /** error.e:199			close(src_file)*/
    EClose(_12src_file_20348);

    /** error.e:200			src_file = -1*/
    _12src_file_20348 = -1LL;
L3: 
L2: 

    /** error.e:203		w = ShowWarnings()*/
    _w_49498 = _49ShowWarnings();
    if (!IS_ATOM_INT(_w_49498)) {
        _1 = (object)(DBL_PTR(_w_49498)->dbl);
        DeRefDS(_w_49498);
        _w_49498 = _1;
    }

    /** error.e:204		if not TRANSLATE and (BIND or show_error) and (w or Errors) then*/
    _25429 = (_12TRANSLATE_19834 == 0);
    if (_25429 == 0) {
        _25430 = 0;
        goto L5; // [107] 125
    }
    if (_12BIND_19837 != 0) {
        _25431 = 1;
        goto L6; // [113] 121
    }
    _25431 = (_show_error_49499 != 0);
L6: 
    _25430 = (_25431 != 0);
L5: 
    if (_25430 == 0) {
        goto L7; // [125] 186
    }
    if (_w_49498 != 0) {
        DeRef(_25433);
        _25433 = 1;
        goto L8; // [129] 139
    }
    _25433 = (_49Errors_49307 != 0);
L8: 
    if (_25433 == 0)
    {
        _25433 = NOVALUE;
        goto L7; // [140] 186
    }
    else{
        _25433 = NOVALUE;
    }

    /** error.e:205			if not batch_job and not test_only then*/
    _25434 = (_12batch_job_20239 == 0);
    if (_25434 == 0) {
        goto L9; // [150] 185
    }
    _25436 = (_12test_only_20238 == 0);
    if (_25436 == 0)
    {
        DeRef(_25436);
        _25436 = NOVALUE;
        goto L9; // [160] 185
    }
    else{
        DeRef(_25436);
        _25436 = NOVALUE;
    }

    /** error.e:206				screen_output(STDERR, GetMsgText(PRESS_ENTER,0))*/
    RefDS(_22024);
    _25437 = _30GetMsgText(208LL, 0LL, _22024);
    _49screen_output(2LL, _25437);
    _25437 = NOVALUE;

    /** error.e:207				getc(0) -- wait*/
    if (0LL != last_r_file_no) {
        last_r_file_ptr = which_file(0LL, EF_READ);
        last_r_file_no = 0LL;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _25438 = getc((FILE*)xstdin);
        }
        else{
            _25438 = getc(last_r_file_ptr);
        }
    }
    else{
        _25438 = getc(last_r_file_ptr);
    }
L9: 
L7: 

    /** error.e:212		cleanup_open_includes()*/
    _61cleanup_open_includes();

    /** error.e:213		abort(status)*/
    UserCleanup(_status_49497);

    /** error.e:214	end procedure*/
    DeRef(_25423);
    _25423 = NOVALUE;
    DeRef(_25427);
    _25427 = NOVALUE;
    DeRef(_25425);
    _25425 = NOVALUE;
    DeRef(_25429);
    _25429 = NOVALUE;
    DeRef(_25434);
    _25434 = NOVALUE;
    return;
    ;
}


void _49OpenErrFile()
{
    object _25445 = NOVALUE;
    object _25444 = NOVALUE;
    object _25442 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:219	    if TempErrFile != -1 then*/
    if (_49TempErrFile_49308 == -1LL)
    goto L1; // [5] 19

    /** error.e:220			TempErrFile = open(TempErrName, "w")*/
    _49TempErrFile_49308 = EOpen(_49TempErrName_49310, _22169, 0LL);
L1: 

    /** error.e:223		if TempErrFile = -1 then*/
    if (_49TempErrFile_49308 != -1LL)
    goto L2; // [23] 66

    /** error.e:224			if length(TempErrName) > 0 then*/
    _25442 = 6;

    /** error.e:225				screen_output(STDERR, GetMsgText(CANT_CREATE_ERROR_MESSAGE_FILE_1, 0, {TempErrName}))*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_49TempErrName_49310);
    ((intptr_t*)_2)[1] = _49TempErrName_49310;
    _25444 = MAKE_SEQ(_1);
    _25445 = _30GetMsgText(209LL, 0LL, _25444);
    _25444 = NOVALUE;
    _49screen_output(2LL, _25445);
    _25445 = NOVALUE;

    /** error.e:227			abort(1) -- with no clean up*/
    UserCleanup(1LL);
L2: 

    /** error.e:229	end procedure*/
    return;
    ;
}


void _49ShowErr(object _f_49556)
{
    object _msg_inlined_screen_output_at_43_49569 = NOVALUE;
    object _25452 = NOVALUE;
    object _25451 = NOVALUE;
    object _25450 = NOVALUE;
    object _25448 = NOVALUE;
    object _25446 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:234		if length(known_files) = 0 then*/
    if (IS_SEQUENCE(_13known_files_11317)){
            _25446 = SEQ_PTR(_13known_files_11317)->length;
    }
    else {
        _25446 = 1;
    }
    if (_25446 != 0LL)
    goto L1; // [10] 20

    /** error.e:235			return*/
    return;
L1: 

    /** error.e:238		if ThisLine[1] = END_OF_FILE_CHAR then*/
    _2 = (object)SEQ_PTR(_49ThisLine_49312);
    _25448 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _25448, 26LL)){
        _25448 = NOVALUE;
        goto L2; // [30] 64
    }
    _25448 = NOVALUE;

    /** error.e:239			screen_output(f, GetMsgText(MSG_ENDOFFILE,0))*/
    RefDS(_22024);
    _25450 = _30GetMsgText(210LL, 0LL, _22024);
    DeRef(_msg_inlined_screen_output_at_43_49569);
    _msg_inlined_screen_output_at_43_49569 = _25450;
    _25450 = NOVALUE;

    /** error.e:44		puts(f, msg)*/
    EPuts(_f_49556, _msg_inlined_screen_output_at_43_49569); // DJP 

    /** error.e:45	end procedure*/
    goto L3; // [56] 59
L3: 
    DeRef(_msg_inlined_screen_output_at_43_49569);
    _msg_inlined_screen_output_at_43_49569 = NOVALUE;
    goto L4; // [61] 81
L2: 

    /** error.e:241			screen_output(f, ThisLine)*/

    /** error.e:44		puts(f, msg)*/
    EPuts(_f_49556, _49ThisLine_49312); // DJP 

    /** error.e:45	end procedure*/
    goto L5; // [77] 80
L5: 
L4: 

    /** error.e:244		for i = 1 to bp-2 do -- bp-1 points to last character read*/
    _25451 = _49bp_49316 - 2LL;
    if ((object)((uintptr_t)_25451 +(uintptr_t) HIGH_BITS) >= 0){
        _25451 = NewDouble((eudouble)_25451);
    }
    {
        object _i_49573;
        _i_49573 = 1LL;
L6: 
        if (binary_op_a(GREATER, _i_49573, _25451)){
            goto L7; // [89] 143
        }

        /** error.e:245			if ThisLine[i] = '\t' then*/
        _2 = (object)SEQ_PTR(_49ThisLine_49312);
        if (!IS_ATOM_INT(_i_49573)){
            _25452 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_49573)->dbl));
        }
        else{
            _25452 = (object)*(((s1_ptr)_2)->base + _i_49573);
        }
        if (binary_op_a(NOTEQ, _25452, 9LL)){
            _25452 = NOVALUE;
            goto L8; // [104] 123
        }
        _25452 = NOVALUE;

        /** error.e:246				screen_output(f, "\t")*/

        /** error.e:44		puts(f, msg)*/
        EPuts(_f_49556, _23996); // DJP 

        /** error.e:45	end procedure*/
        goto L9; // [117] 136
        goto L9; // [120] 136
L8: 

        /** error.e:248				screen_output(f, " ")*/

        /** error.e:44		puts(f, msg)*/
        EPuts(_f_49556, _23438); // DJP 

        /** error.e:45	end procedure*/
        goto LA; // [132] 135
LA: 
L9: 

        /** error.e:250		end for*/
        _0 = _i_49573;
        if (IS_ATOM_INT(_i_49573)) {
            _i_49573 = _i_49573 + 1LL;
            if ((object)((uintptr_t)_i_49573 +(uintptr_t) HIGH_BITS) >= 0){
                _i_49573 = NewDouble((eudouble)_i_49573);
            }
        }
        else {
            _i_49573 = binary_op_a(PLUS, _i_49573, 1LL);
        }
        DeRef(_0);
        goto L6; // [138] 96
L7: 
        ;
        DeRef(_i_49573);
    }

    /** error.e:252		screen_output(f, "^\n\n")*/

    /** error.e:44		puts(f, msg)*/
    EPuts(_f_49556, _25454); // DJP 

    /** error.e:45	end procedure*/
    goto LB; // [152] 155
LB: 

    /** error.e:253	end procedure*/
    DeRef(_25451);
    _25451 = NOVALUE;
    return;
    ;
}


void _49CompileErr(object _msg_49585, object _args_49586, object _preproc_49587)
{
    object _errmsg_49588 = NOVALUE;
    object _25475 = NOVALUE;
    object _25471 = NOVALUE;
    object _25470 = NOVALUE;
    object _25469 = NOVALUE;
    object _25468 = NOVALUE;
    object _25467 = NOVALUE;
    object _25466 = NOVALUE;
    object _25464 = NOVALUE;
    object _25463 = NOVALUE;
    object _25461 = NOVALUE;
    object _25460 = NOVALUE;
    object _25459 = NOVALUE;
    object _25455 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:260		if integer(msg) then*/
    if (IS_ATOM_INT(_msg_49585))
    _25455 = 1;
    else if (IS_ATOM_DBL(_msg_49585))
    _25455 = IS_ATOM_INT(DoubleToInt(_msg_49585));
    else
    _25455 = 0;
    if (_25455 == 0)
    {
        _25455 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _25455 = NOVALUE;
    }

    /** error.e:261			msg = GetMsgText(msg)*/
    Ref(_msg_49585);
    RefDS(_22024);
    _0 = _msg_49585;
    _msg_49585 = _30GetMsgText(_msg_49585, 1LL, _22024);
    DeRefi(_0);
L1: 

    /** error.e:264		msg = format(msg, args)*/
    Ref(_msg_49585);
    Ref(_args_49586);
    _0 = _msg_49585;
    _msg_49585 = _18format(_msg_49585, _args_49586);
    DeRef(_0);

    /** error.e:266		Errors += 1*/
    _49Errors_49307 = _49Errors_49307 + 1;

    /** error.e:267		if not preproc and length(known_files) then*/
    _25459 = (_preproc_49587 == 0);
    if (_25459 == 0) {
        goto L2; // [40] 78
    }
    if (IS_SEQUENCE(_13known_files_11317)){
            _25461 = SEQ_PTR(_13known_files_11317)->length;
    }
    else {
        _25461 = 1;
    }
    if (_25461 == 0)
    {
        _25461 = NOVALUE;
        goto L2; // [50] 78
    }
    else{
        _25461 = NOVALUE;
    }

    /** error.e:268			errmsg = sprintf("%s:%d\n%s\n", {known_files[current_file_no],*/
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _25463 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_25463);
    ((intptr_t*)_2)[1] = _25463;
    ((intptr_t*)_2)[2] = _12line_number_20227;
    Ref(_msg_49585);
    ((intptr_t*)_2)[3] = _msg_49585;
    _25464 = MAKE_SEQ(_1);
    _25463 = NOVALUE;
    DeRef(_errmsg_49588);
    _errmsg_49588 = EPrintf(-9999999, _25462, _25464);
    DeRefDS(_25464);
    _25464 = NOVALUE;
    goto L3; // [75] 121
L2: 

    /** error.e:271			errmsg = msg*/
    Ref(_msg_49585);
    DeRef(_errmsg_49588);
    _errmsg_49588 = _msg_49585;

    /** error.e:272			if length(msg) > 0 and msg[$] != '\n' then*/
    if (IS_SEQUENCE(_msg_49585)){
            _25466 = SEQ_PTR(_msg_49585)->length;
    }
    else {
        _25466 = 1;
    }
    _25467 = (_25466 > 0LL);
    _25466 = NOVALUE;
    if (_25467 == 0) {
        goto L4; // [94] 120
    }
    if (IS_SEQUENCE(_msg_49585)){
            _25469 = SEQ_PTR(_msg_49585)->length;
    }
    else {
        _25469 = 1;
    }
    _2 = (object)SEQ_PTR(_msg_49585);
    _25470 = (object)*(((s1_ptr)_2)->base + _25469);
    if (IS_ATOM_INT(_25470)) {
        _25471 = (_25470 != 10LL);
    }
    else {
        _25471 = binary_op(NOTEQ, _25470, 10LL);
    }
    _25470 = NOVALUE;
    if (_25471 == 0) {
        DeRef(_25471);
        _25471 = NOVALUE;
        goto L4; // [110] 120
    }
    else {
        if (!IS_ATOM_INT(_25471) && DBL_PTR(_25471)->dbl == 0.0){
            DeRef(_25471);
            _25471 = NOVALUE;
            goto L4; // [110] 120
        }
        DeRef(_25471);
        _25471 = NOVALUE;
    }
    DeRef(_25471);
    _25471 = NOVALUE;

    /** error.e:273				errmsg &= '\n'*/
    Append(&_errmsg_49588, _errmsg_49588, 10LL);
L4: 
L3: 

    /** error.e:277		if not preproc then*/
    if (_preproc_49587 != 0)
    goto L5; // [123] 131

    /** error.e:279			OpenErrFile() -- exits if error filename is ""*/
    _49OpenErrFile();
L5: 

    /** error.e:281		screen_output(STDERR, errmsg)*/
    RefDS(_errmsg_49588);
    _49screen_output(2LL, _errmsg_49588);

    /** error.e:283		if not preproc then*/
    if (_preproc_49587 != 0)
    goto L6; // [143] 198

    /** error.e:284			ShowErr(STDERR)*/
    _49ShowErr(2LL);

    /** error.e:286			puts(TempErrFile, errmsg)*/
    EPuts(_49TempErrFile_49308, _errmsg_49588); // DJP 

    /** error.e:288			ShowErr(TempErrFile)*/
    _49ShowErr(_49TempErrFile_49308);

    /** error.e:290			ShowWarnings()*/
    _25475 = _49ShowWarnings();

    /** error.e:292			ShowDefines(TempErrFile)*/
    _49ShowDefines(_49TempErrFile_49308);

    /** error.e:294			close(TempErrFile)*/
    EClose(_49TempErrFile_49308);

    /** error.e:295			TempErrFile = -2*/
    _49TempErrFile_49308 = -2LL;

    /** error.e:296			ifdef CRASH_ON_ERROR then*/

    /** error.e:299			Cleanup(1)*/
    _49Cleanup(1LL);
L6: 

    /** error.e:302	end procedure*/
    DeRef(_msg_49585);
    DeRef(_args_49586);
    DeRef(_errmsg_49588);
    DeRef(_25475);
    _25475 = NOVALUE;
    DeRef(_25467);
    _25467 = NOVALUE;
    DeRef(_25459);
    _25459 = NOVALUE;
    return;
    ;
}


void _49InternalErr(object _msgno_49632, object _args_49633)
{
    object _msg_49634 = NOVALUE;
    object _25491 = NOVALUE;
    object _25489 = NOVALUE;
    object _25488 = NOVALUE;
    object _25487 = NOVALUE;
    object _25486 = NOVALUE;
    object _25485 = NOVALUE;
    object _25484 = NOVALUE;
    object _25483 = NOVALUE;
    object _25482 = NOVALUE;
    object _25481 = NOVALUE;
    object _25480 = NOVALUE;
    object _25477 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:316		if atom(args) then*/
    _25477 = 0;
    if (_25477 == 0)
    {
        _25477 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _25477 = NOVALUE;
    }

    /** error.e:317			args = {args}*/
    _0 = _args_49633;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_args_49633);
    ((intptr_t*)_2)[1] = _args_49633;
    _args_49633 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1: 

    /** error.e:320		msg = GetMsgText(msgno, 1, args)*/
    Ref(_args_49633);
    _0 = _msg_49634;
    _msg_49634 = _30GetMsgText(_msgno_49632, 1LL, _args_49633);
    DeRef(_0);

    /** error.e:321		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L2; // [32] 58
    }
    else{
    }

    /** error.e:322			screen_output(STDERR, GetMsgText(INTERNAL_ERRORT1, 1, {msg}))*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_msg_49634);
    ((intptr_t*)_2)[1] = _msg_49634;
    _25480 = MAKE_SEQ(_1);
    _25481 = _30GetMsgText(211LL, 1LL, _25480);
    _25480 = NOVALUE;
    _49screen_output(2LL, _25481);
    _25481 = NOVALUE;
    goto L3; // [55] 91
L2: 

    /** error.e:324			screen_output(STDERR, GetMsgText(INTERNAL_ERROR_AT_12T3, 1, {known_files[current_file_no], line_number, msg}))*/
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _25482 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_25482);
    ((intptr_t*)_2)[1] = _25482;
    ((intptr_t*)_2)[2] = _12line_number_20227;
    RefDS(_msg_49634);
    ((intptr_t*)_2)[3] = _msg_49634;
    _25483 = MAKE_SEQ(_1);
    _25482 = NOVALUE;
    _25484 = _30GetMsgText(212LL, 1LL, _25483);
    _25483 = NOVALUE;
    _49screen_output(2LL, _25484);
    _25484 = NOVALUE;
L3: 

    /** error.e:327		if not batch_job and not test_only then*/
    _25485 = (_12batch_job_20239 == 0);
    if (_25485 == 0) {
        goto L4; // [98] 133
    }
    _25487 = (_12test_only_20238 == 0);
    if (_25487 == 0)
    {
        DeRef(_25487);
        _25487 = NOVALUE;
        goto L4; // [108] 133
    }
    else{
        DeRef(_25487);
        _25487 = NOVALUE;
    }

    /** error.e:328			screen_output(STDERR, GetMsgText(PRESS_ENTER, 0))*/
    RefDS(_22024);
    _25488 = _30GetMsgText(208LL, 0LL, _22024);
    _49screen_output(2LL, _25488);
    _25488 = NOVALUE;

    /** error.e:329			getc(0)*/
    if (0LL != last_r_file_no) {
        last_r_file_ptr = which_file(0LL, EF_READ);
        last_r_file_no = 0LL;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _25489 = getc((FILE*)xstdin);
        }
        else{
            _25489 = getc(last_r_file_ptr);
        }
    }
    else{
        _25489 = getc(last_r_file_ptr);
    }
L4: 

    /** error.e:333		machine_proc(67, GetMsgText(FAILED_DUE_TO_INTERNAL_ERROR))*/
    RefDS(_22024);
    _25491 = _30GetMsgText(213LL, 1LL, _22024);
    machine(67LL, _25491);
    DeRef(_25491);
    _25491 = NOVALUE;

    /** error.e:334	end procedure*/
    DeRef(_args_49633);
    DeRef(_msg_49634);
    DeRef(_25485);
    _25485 = NOVALUE;
    return;
    ;
}



// 0xA053F52F
