// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _27reverse(object _s_7839)
{
    object _lower_7840 = NOVALUE;
    object _n_7841 = NOVALUE;
    object _n2_7842 = NOVALUE;
    object _t_7843 = NOVALUE;
    object _4274 = NOVALUE;
    object _4273 = NOVALUE;
    object _4272 = NOVALUE;
    object _4269 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:87		n = length(s)*/
    if (IS_SEQUENCE(_s_7839)){
            _n_7841 = SEQ_PTR(_s_7839)->length;
    }
    else {
        _n_7841 = 1;
    }

    /** scinot.e:88		n2 = floor(n/2)+1*/
    _4269 = _n_7841 >> 1;
    _n2_7842 = _4269 + 1;
    _4269 = NOVALUE;

    /** scinot.e:89		t = repeat(0, n)*/
    DeRef(_t_7843);
    _t_7843 = Repeat(0LL, _n_7841);

    /** scinot.e:90		lower = 1*/
    _lower_7840 = 1LL;

    /** scinot.e:91		for upper = n to n2 by -1 do*/
    _4272 = _n2_7842;
    {
        object _upper_7849;
        _upper_7849 = _n_7841;
L1: 
        if (_upper_7849 < _4272){
            goto L2; // [34] 74
        }

        /** scinot.e:92			t[upper] = s[lower]*/
        _2 = (object)SEQ_PTR(_s_7839);
        _4273 = (object)*(((s1_ptr)_2)->base + _lower_7840);
        Ref(_4273);
        _2 = (object)SEQ_PTR(_t_7843);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _t_7843 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _upper_7849);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _4273;
        if( _1 != _4273 ){
            DeRef(_1);
        }
        _4273 = NOVALUE;

        /** scinot.e:93			t[lower] = s[upper]*/
        _2 = (object)SEQ_PTR(_s_7839);
        _4274 = (object)*(((s1_ptr)_2)->base + _upper_7849);
        Ref(_4274);
        _2 = (object)SEQ_PTR(_t_7843);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _t_7843 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _lower_7840);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _4274;
        if( _1 != _4274 ){
            DeRef(_1);
        }
        _4274 = NOVALUE;

        /** scinot.e:94			lower += 1*/
        _lower_7840 = _lower_7840 + 1;

        /** scinot.e:95		end for*/
        _upper_7849 = _upper_7849 + -1LL;
        goto L1; // [69] 41
L2: 
        ;
    }

    /** scinot.e:96		return t*/
    DeRefDS(_s_7839);
    return _t_7843;
    ;
}


object _27carry(object _a_7856, object _radix_7857)
{
    object _q_7858 = NOVALUE;
    object _r_7859 = NOVALUE;
    object _b_7860 = NOVALUE;
    object _rmax_7861 = NOVALUE;
    object _i_7862 = NOVALUE;
    object _4288 = NOVALUE;
    object _4287 = NOVALUE;
    object _4286 = NOVALUE;
    object _4283 = NOVALUE;
    object _4277 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:102		rmax = radix - 1*/
    DeRef(_rmax_7861);
    _rmax_7861 = _radix_7857 - 1LL;
    if ((object)((uintptr_t)_rmax_7861 +(uintptr_t) HIGH_BITS) >= 0){
        _rmax_7861 = NewDouble((eudouble)_rmax_7861);
    }

    /** scinot.e:103		i = 1*/
    DeRef(_i_7862);
    _i_7862 = 1LL;

    /** scinot.e:104		while i <= length(a) do*/
L1: 
    if (IS_SEQUENCE(_a_7856)){
            _4277 = SEQ_PTR(_a_7856)->length;
    }
    else {
        _4277 = 1;
    }
    if (binary_op_a(GREATER, _i_7862, _4277)){
        _4277 = NOVALUE;
        goto L2; // [24] 104
    }
    _4277 = NOVALUE;

    /** scinot.e:105			b = a[i]*/
    DeRef(_b_7860);
    _2 = (object)SEQ_PTR(_a_7856);
    if (!IS_ATOM_INT(_i_7862)){
        _b_7860 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_7862)->dbl));
    }
    else{
        _b_7860 = (object)*(((s1_ptr)_2)->base + _i_7862);
    }
    Ref(_b_7860);

    /** scinot.e:106			if b > rmax then*/
    if (binary_op_a(LESSEQ, _b_7860, _rmax_7861)){
        goto L3; // [36] 93
    }

    /** scinot.e:107				q = floor( b / radix )*/
    DeRef(_q_7858);
    if (IS_ATOM_INT(_b_7860)) {
        if (_radix_7857 > 0 && _b_7860 >= 0) {
            _q_7858 = _b_7860 / _radix_7857;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_b_7860 / (eudouble)_radix_7857);
            if (_b_7860 != MININT)
            _q_7858 = (object)temp_dbl;
            else
            _q_7858 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _b_7860, _radix_7857);
        _q_7858 = unary_op(FLOOR, _2);
        DeRef(_2);
    }

    /** scinot.e:108				r = remainder( b, radix )*/
    DeRef(_r_7859);
    if (IS_ATOM_INT(_b_7860)) {
        _r_7859 = (_b_7860 % _radix_7857);
    }
    else {
        temp_d.dbl = (eudouble)_radix_7857;
        _r_7859 = Dremainder(DBL_PTR(_b_7860), &temp_d);
    }

    /** scinot.e:109				a[i] = r*/
    Ref(_r_7859);
    _2 = (object)SEQ_PTR(_a_7856);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _a_7856 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_i_7862))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_7862)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _i_7862);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_7859;
    DeRef(_1);

    /** scinot.e:110				if i = length(a) then*/
    if (IS_SEQUENCE(_a_7856)){
            _4283 = SEQ_PTR(_a_7856)->length;
    }
    else {
        _4283 = 1;
    }
    if (binary_op_a(NOTEQ, _i_7862, _4283)){
        _4283 = NOVALUE;
        goto L4; // [63] 74
    }
    _4283 = NOVALUE;

    /** scinot.e:111					a &= 0*/
    Append(&_a_7856, _a_7856, 0LL);
L4: 

    /** scinot.e:113				a[i+1] += q*/
    if (IS_ATOM_INT(_i_7862)) {
        _4286 = _i_7862 + 1;
    }
    else
    _4286 = binary_op(PLUS, 1, _i_7862);
    _2 = (object)SEQ_PTR(_a_7856);
    if (!IS_ATOM_INT(_4286)){
        _4287 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_4286)->dbl));
    }
    else{
        _4287 = (object)*(((s1_ptr)_2)->base + _4286);
    }
    if (IS_ATOM_INT(_4287) && IS_ATOM_INT(_q_7858)) {
        _4288 = _4287 + _q_7858;
        if ((object)((uintptr_t)_4288 + (uintptr_t)HIGH_BITS) >= 0){
            _4288 = NewDouble((eudouble)_4288);
        }
    }
    else {
        _4288 = binary_op(PLUS, _4287, _q_7858);
    }
    _4287 = NOVALUE;
    _2 = (object)SEQ_PTR(_a_7856);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _a_7856 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_4286))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_4286)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _4286);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _4288;
    if( _1 != _4288 ){
        DeRef(_1);
    }
    _4288 = NOVALUE;
L3: 

    /** scinot.e:115			i += 1*/
    _0 = _i_7862;
    if (IS_ATOM_INT(_i_7862)) {
        _i_7862 = _i_7862 + 1;
        if (_i_7862 > MAXINT){
            _i_7862 = NewDouble((eudouble)_i_7862);
        }
    }
    else
    _i_7862 = binary_op(PLUS, 1, _i_7862);
    DeRef(_0);

    /** scinot.e:116		end while*/
    goto L1; // [101] 21
L2: 

    /** scinot.e:118		return a*/
    DeRef(_q_7858);
    DeRef(_r_7859);
    DeRef(_b_7860);
    DeRef(_rmax_7861);
    DeRef(_i_7862);
    DeRef(_4286);
    _4286 = NOVALUE;
    return _a_7856;
    ;
}


object _27add(object _a_7882, object _b_7883)
{
    object _4306 = NOVALUE;
    object _4304 = NOVALUE;
    object _4303 = NOVALUE;
    object _4302 = NOVALUE;
    object _4301 = NOVALUE;
    object _4299 = NOVALUE;
    object _4298 = NOVALUE;
    object _4296 = NOVALUE;
    object _4295 = NOVALUE;
    object _4294 = NOVALUE;
    object _4293 = NOVALUE;
    object _4291 = NOVALUE;
    object _4290 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:123		if length(a) < length(b) then*/
    if (IS_SEQUENCE(_a_7882)){
            _4290 = SEQ_PTR(_a_7882)->length;
    }
    else {
        _4290 = 1;
    }
    if (IS_SEQUENCE(_b_7883)){
            _4291 = SEQ_PTR(_b_7883)->length;
    }
    else {
        _4291 = 1;
    }
    if (_4290 >= _4291)
    goto L1; // [13] 40

    /** scinot.e:124			a &= repeat( 0, length(b) - length(a) )*/
    if (IS_SEQUENCE(_b_7883)){
            _4293 = SEQ_PTR(_b_7883)->length;
    }
    else {
        _4293 = 1;
    }
    if (IS_SEQUENCE(_a_7882)){
            _4294 = SEQ_PTR(_a_7882)->length;
    }
    else {
        _4294 = 1;
    }
    _4295 = _4293 - _4294;
    _4293 = NOVALUE;
    _4294 = NOVALUE;
    _4296 = Repeat(0LL, _4295);
    _4295 = NOVALUE;
    Concat((object_ptr)&_a_7882, _a_7882, _4296);
    DeRefDS(_4296);
    _4296 = NOVALUE;
    goto L2; // [37] 74
L1: 

    /** scinot.e:125		elsif length(b) < length(a) then*/
    if (IS_SEQUENCE(_b_7883)){
            _4298 = SEQ_PTR(_b_7883)->length;
    }
    else {
        _4298 = 1;
    }
    if (IS_SEQUENCE(_a_7882)){
            _4299 = SEQ_PTR(_a_7882)->length;
    }
    else {
        _4299 = 1;
    }
    if (_4298 >= _4299)
    goto L3; // [48] 73

    /** scinot.e:126			b &= repeat( 0, length(a) - length(b) )*/
    if (IS_SEQUENCE(_a_7882)){
            _4301 = SEQ_PTR(_a_7882)->length;
    }
    else {
        _4301 = 1;
    }
    if (IS_SEQUENCE(_b_7883)){
            _4302 = SEQ_PTR(_b_7883)->length;
    }
    else {
        _4302 = 1;
    }
    _4303 = _4301 - _4302;
    _4301 = NOVALUE;
    _4302 = NOVALUE;
    _4304 = Repeat(0LL, _4303);
    _4303 = NOVALUE;
    Concat((object_ptr)&_b_7883, _b_7883, _4304);
    DeRefDS(_4304);
    _4304 = NOVALUE;
L3: 
L2: 

    /** scinot.e:129		return a + b*/
    _4306 = binary_op(PLUS, _a_7882, _b_7883);
    DeRefDS(_a_7882);
    DeRefDS(_b_7883);
    return _4306;
    ;
}


object _27borrow(object _a_7905, object _radix_7906)
{
    object _4314 = NOVALUE;
    object _4313 = NOVALUE;
    object _4312 = NOVALUE;
    object _4311 = NOVALUE;
    object _4310 = NOVALUE;
    object _4308 = NOVALUE;
    object _4307 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:134		for i = length(a) to 2 by -1 do*/
    if (IS_SEQUENCE(_a_7905)){
            _4307 = SEQ_PTR(_a_7905)->length;
    }
    else {
        _4307 = 1;
    }
    {
        object _i_7908;
        _i_7908 = _4307;
L1: 
        if (_i_7908 < 2LL){
            goto L2; // [10] 67
        }

        /** scinot.e:135			if a[i] < 0 then*/
        _2 = (object)SEQ_PTR(_a_7905);
        _4308 = (object)*(((s1_ptr)_2)->base + _i_7908);
        if (binary_op_a(GREATEREQ, _4308, 0LL)){
            _4308 = NOVALUE;
            goto L3; // [23] 60
        }
        _4308 = NOVALUE;

        /** scinot.e:136				a[i] += radix*/
        _2 = (object)SEQ_PTR(_a_7905);
        _4310 = (object)*(((s1_ptr)_2)->base + _i_7908);
        if (IS_ATOM_INT(_4310)) {
            _4311 = _4310 + _radix_7906;
            if ((object)((uintptr_t)_4311 + (uintptr_t)HIGH_BITS) >= 0){
                _4311 = NewDouble((eudouble)_4311);
            }
        }
        else {
            _4311 = binary_op(PLUS, _4310, _radix_7906);
        }
        _4310 = NOVALUE;
        _2 = (object)SEQ_PTR(_a_7905);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _a_7905 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_7908);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _4311;
        if( _1 != _4311 ){
            DeRef(_1);
        }
        _4311 = NOVALUE;

        /** scinot.e:137				a[i-1] -= 1*/
        _4312 = _i_7908 - 1LL;
        _2 = (object)SEQ_PTR(_a_7905);
        _4313 = (object)*(((s1_ptr)_2)->base + _4312);
        if (IS_ATOM_INT(_4313)) {
            _4314 = _4313 - 1LL;
            if ((object)((uintptr_t)_4314 +(uintptr_t) HIGH_BITS) >= 0){
                _4314 = NewDouble((eudouble)_4314);
            }
        }
        else {
            _4314 = binary_op(MINUS, _4313, 1LL);
        }
        _4313 = NOVALUE;
        _2 = (object)SEQ_PTR(_a_7905);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _a_7905 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _4312);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _4314;
        if( _1 != _4314 ){
            DeRef(_1);
        }
        _4314 = NOVALUE;
L3: 

        /** scinot.e:139		end for*/
        _i_7908 = _i_7908 + -1LL;
        goto L1; // [62] 17
L2: 
        ;
    }

    /** scinot.e:140		return a*/
    DeRef(_4312);
    _4312 = NOVALUE;
    return _a_7905;
    ;
}


object _27bits_to_bytes(object _bits_7920)
{
    object _bytes_7921 = NOVALUE;
    object _r_7922 = NOVALUE;
    object _4323 = NOVALUE;
    object _4322 = NOVALUE;
    object _4321 = NOVALUE;
    object _4320 = NOVALUE;
    object _4318 = NOVALUE;
    object _4317 = NOVALUE;
    object _4315 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:155		r = remainder( length(bits), 8 )*/
    if (IS_SEQUENCE(_bits_7920)){
            _4315 = SEQ_PTR(_bits_7920)->length;
    }
    else {
        _4315 = 1;
    }
    _r_7922 = (_4315 % 8LL);
    _4315 = NOVALUE;

    /** scinot.e:156		if r  then*/
    if (_r_7922 == 0)
    {
        goto L1; // [14] 32
    }
    else{
    }

    /** scinot.e:157			bits &= repeat( 0, 8 - r )*/
    _4317 = 8LL - _r_7922;
    _4318 = Repeat(0LL, _4317);
    _4317 = NOVALUE;
    Concat((object_ptr)&_bits_7920, _bits_7920, _4318);
    DeRefDS(_4318);
    _4318 = NOVALUE;
L1: 

    /** scinot.e:160		bytes = {}*/
    RefDS(_5);
    DeRef(_bytes_7921);
    _bytes_7921 = _5;

    /** scinot.e:161		for i = 1 to length(bits) by 8 do*/
    if (IS_SEQUENCE(_bits_7920)){
            _4320 = SEQ_PTR(_bits_7920)->length;
    }
    else {
        _4320 = 1;
    }
    {
        object _i_7930;
        _i_7930 = 1LL;
L2: 
        if (_i_7930 > _4320){
            goto L3; // [44] 77
        }

        /** scinot.e:162			bytes &= bits_to_int( bits[i..i+7] )*/
        _4321 = _i_7930 + 7LL;
        rhs_slice_target = (object_ptr)&_4322;
        RHS_Slice(_bits_7920, _i_7930, _4321);
        _4323 = _19bits_to_int(_4322);
        _4322 = NOVALUE;
        if (IS_SEQUENCE(_bytes_7921) && IS_ATOM(_4323)) {
            Ref(_4323);
            Append(&_bytes_7921, _bytes_7921, _4323);
        }
        else if (IS_ATOM(_bytes_7921) && IS_SEQUENCE(_4323)) {
        }
        else {
            Concat((object_ptr)&_bytes_7921, _bytes_7921, _4323);
        }
        DeRef(_4323);
        _4323 = NOVALUE;

        /** scinot.e:163		end for*/
        _i_7930 = _i_7930 + 8LL;
        goto L2; // [72] 51
L3: 
        ;
    }

    /** scinot.e:164		return bytes*/
    DeRefDS(_bits_7920);
    DeRef(_4321);
    _4321 = NOVALUE;
    return _bytes_7921;
    ;
}


object _27bytes_to_bits(object _bytes_7939)
{
    object _bits_7940 = NOVALUE;
    object _4327 = NOVALUE;
    object _4326 = NOVALUE;
    object _4325 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:179		bits = {}*/
    RefDS(_5);
    DeRef(_bits_7940);
    _bits_7940 = _5;

    /** scinot.e:180		for i = 1 to length(bytes) do*/
    if (IS_SEQUENCE(_bytes_7939)){
            _4325 = SEQ_PTR(_bytes_7939)->length;
    }
    else {
        _4325 = 1;
    }
    {
        object _i_7942;
        _i_7942 = 1LL;
L1: 
        if (_i_7942 > _4325){
            goto L2; // [15] 44
        }

        /** scinot.e:181			bits &= int_to_bits( bytes[i], 8 )*/
        _2 = (object)SEQ_PTR(_bytes_7939);
        _4326 = (object)*(((s1_ptr)_2)->base + _i_7942);
        Ref(_4326);
        _4327 = _19int_to_bits(_4326, 8LL);
        _4326 = NOVALUE;
        if (IS_SEQUENCE(_bits_7940) && IS_ATOM(_4327)) {
            Ref(_4327);
            Append(&_bits_7940, _bits_7940, _4327);
        }
        else if (IS_ATOM(_bits_7940) && IS_SEQUENCE(_4327)) {
        }
        else {
            Concat((object_ptr)&_bits_7940, _bits_7940, _4327);
        }
        DeRef(_4327);
        _4327 = NOVALUE;

        /** scinot.e:182		end for*/
        _i_7942 = _i_7942 + 1LL;
        goto L1; // [39] 22
L2: 
        ;
    }

    /** scinot.e:184		return bits*/
    DeRefDS(_bytes_7939);
    return _bits_7940;
    ;
}


object _27convert_radix(object _number_7950, object _from_radix_7951, object _to_radix_7952)
{
    object _target_7953 = NOVALUE;
    object _base_7954 = NOVALUE;
    object _4334 = NOVALUE;
    object _4333 = NOVALUE;
    object _4332 = NOVALUE;
    object _4331 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:190		base = {1}*/
    RefDS(_4329);
    DeRef(_base_7954);
    _base_7954 = _4329;

    /** scinot.e:191		target = {0}*/
    _0 = _target_7953;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0LL;
    _target_7953 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scinot.e:192		for i = 1 to length(number) do*/
    if (IS_SEQUENCE(_number_7950)){
            _4331 = SEQ_PTR(_number_7950)->length;
    }
    else {
        _4331 = 1;
    }
    {
        object _i_7958;
        _i_7958 = 1LL;
L1: 
        if (_i_7958 > _4331){
            goto L2; // [25] 78
        }

        /** scinot.e:193			target = carry( add( base * number[i], target ), to_radix )*/
        _2 = (object)SEQ_PTR(_number_7950);
        _4332 = (object)*(((s1_ptr)_2)->base + _i_7958);
        _4333 = binary_op(MULTIPLY, _base_7954, _4332);
        _4332 = NOVALUE;
        RefDS(_target_7953);
        _4334 = _27add(_4333, _target_7953);
        _4333 = NOVALUE;
        _0 = _target_7953;
        _target_7953 = _27carry(_4334, _to_radix_7952);
        DeRefDS(_0);
        _4334 = NOVALUE;

        /** scinot.e:194			base *= from_radix*/
        _0 = _base_7954;
        _base_7954 = binary_op(MULTIPLY, _base_7954, _from_radix_7951);
        DeRefDS(_0);

        /** scinot.e:195			base = carry( base, to_radix )*/
        RefDS(_base_7954);
        _0 = _base_7954;
        _base_7954 = _27carry(_base_7954, _to_radix_7952);
        DeRefDS(_0);

        /** scinot.e:196		end for*/
        _i_7958 = _i_7958 + 1LL;
        goto L1; // [73] 32
L2: 
        ;
    }

    /** scinot.e:198		return target*/
    DeRefDS(_number_7950);
    DeRef(_base_7954);
    return _target_7953;
    ;
}


object _27half(object _decimal_7968)
{
    object _quotient_7969 = NOVALUE;
    object _q_7970 = NOVALUE;
    object _Q_7971 = NOVALUE;
    object _4355 = NOVALUE;
    object _4354 = NOVALUE;
    object _4353 = NOVALUE;
    object _4352 = NOVALUE;
    object _4351 = NOVALUE;
    object _4350 = NOVALUE;
    object _4347 = NOVALUE;
    object _4345 = NOVALUE;
    object _4344 = NOVALUE;
    object _4341 = NOVALUE;
    object _4340 = NOVALUE;
    object _4338 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:205		quotient = repeat( 0, length(decimal) )*/
    if (IS_SEQUENCE(_decimal_7968)){
            _4338 = SEQ_PTR(_decimal_7968)->length;
    }
    else {
        _4338 = 1;
    }
    DeRef(_quotient_7969);
    _quotient_7969 = Repeat(0LL, _4338);
    _4338 = NOVALUE;

    /** scinot.e:206		for i = 1 to length( decimal ) do*/
    if (IS_SEQUENCE(_decimal_7968)){
            _4340 = SEQ_PTR(_decimal_7968)->length;
    }
    else {
        _4340 = 1;
    }
    {
        object _i_7975;
        _i_7975 = 1LL;
L1: 
        if (_i_7975 > _4340){
            goto L2; // [17] 101
        }

        /** scinot.e:207			q = decimal[i] / 2*/
        _2 = (object)SEQ_PTR(_decimal_7968);
        _4341 = (object)*(((s1_ptr)_2)->base + _i_7975);
        DeRef(_q_7970);
        if (IS_ATOM_INT(_4341)) {
            if (_4341 & 1) {
                _q_7970 = NewDouble((_4341 >> 1) + 0.5);
            }
            else
            _q_7970 = _4341 >> 1;
        }
        else {
            _q_7970 = binary_op(DIVIDE, _4341, 2);
        }
        _4341 = NOVALUE;

        /** scinot.e:208			Q = floor( q )*/
        DeRef(_Q_7971);
        if (IS_ATOM_INT(_q_7970))
        _Q_7971 = e_floor(_q_7970);
        else
        _Q_7971 = unary_op(FLOOR, _q_7970);

        /** scinot.e:209			quotient[i] +=  Q*/
        _2 = (object)SEQ_PTR(_quotient_7969);
        _4344 = (object)*(((s1_ptr)_2)->base + _i_7975);
        if (IS_ATOM_INT(_4344) && IS_ATOM_INT(_Q_7971)) {
            _4345 = _4344 + _Q_7971;
            if ((object)((uintptr_t)_4345 + (uintptr_t)HIGH_BITS) >= 0){
                _4345 = NewDouble((eudouble)_4345);
            }
        }
        else {
            _4345 = binary_op(PLUS, _4344, _Q_7971);
        }
        _4344 = NOVALUE;
        _2 = (object)SEQ_PTR(_quotient_7969);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _quotient_7969 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_7975);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _4345;
        if( _1 != _4345 ){
            DeRef(_1);
        }
        _4345 = NOVALUE;

        /** scinot.e:211			if q != Q then*/
        if (binary_op_a(EQUALS, _q_7970, _Q_7971)){
            goto L3; // [55] 94
        }

        /** scinot.e:212				if length(quotient) = i then*/
        if (IS_SEQUENCE(_quotient_7969)){
                _4347 = SEQ_PTR(_quotient_7969)->length;
        }
        else {
            _4347 = 1;
        }
        if (_4347 != _i_7975)
        goto L4; // [64] 75

        /** scinot.e:213					quotient &= 0*/
        Append(&_quotient_7969, _quotient_7969, 0LL);
L4: 

        /** scinot.e:215				quotient[i+1] += 5*/
        _4350 = _i_7975 + 1;
        _2 = (object)SEQ_PTR(_quotient_7969);
        _4351 = (object)*(((s1_ptr)_2)->base + _4350);
        if (IS_ATOM_INT(_4351)) {
            _4352 = _4351 + 5LL;
            if ((object)((uintptr_t)_4352 + (uintptr_t)HIGH_BITS) >= 0){
                _4352 = NewDouble((eudouble)_4352);
            }
        }
        else {
            _4352 = binary_op(PLUS, _4351, 5LL);
        }
        _4351 = NOVALUE;
        _2 = (object)SEQ_PTR(_quotient_7969);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _quotient_7969 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _4350);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _4352;
        if( _1 != _4352 ){
            DeRef(_1);
        }
        _4352 = NOVALUE;
L3: 

        /** scinot.e:217		end for*/
        _i_7975 = _i_7975 + 1LL;
        goto L1; // [96] 24
L2: 
        ;
    }

    /** scinot.e:218		return reverse( carry( reverse( quotient ), 10 ) )*/
    RefDS(_quotient_7969);
    _4353 = _27reverse(_quotient_7969);
    _4354 = _27carry(_4353, 10LL);
    _4353 = NOVALUE;
    _4355 = _27reverse(_4354);
    _4354 = NOVALUE;
    DeRefDS(_decimal_7968);
    DeRefDS(_quotient_7969);
    DeRef(_q_7970);
    DeRef(_Q_7971);
    DeRef(_4350);
    _4350 = NOVALUE;
    return _4355;
    ;
}


object _27decimals_to_bits(object _decimals_8004, object _size_8005)
{
    object _sub_8006 = NOVALUE;
    object _bits_8007 = NOVALUE;
    object _bit_8008 = NOVALUE;
    object _assigned_8009 = NOVALUE;
    object _4383 = NOVALUE;
    object _4379 = NOVALUE;
    object _4378 = NOVALUE;
    object _4377 = NOVALUE;
    object _4376 = NOVALUE;
    object _4374 = NOVALUE;
    object _4373 = NOVALUE;
    object _4372 = NOVALUE;
    object _4370 = NOVALUE;
    object _4368 = NOVALUE;
    object _4367 = NOVALUE;
    object _4366 = NOVALUE;
    object _4365 = NOVALUE;
    object _4364 = NOVALUE;
    object _4362 = NOVALUE;
    object _4360 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:233		sub = {5}*/
    RefDS(_4358);
    DeRef(_sub_8006);
    _sub_8006 = _4358;

    /** scinot.e:234		bits = repeat( 0, size )*/
    DeRef(_bits_8007);
    _bits_8007 = Repeat(0LL, _size_8005);

    /** scinot.e:235		bit = 1*/
    _bit_8008 = 1LL;

    /** scinot.e:236		assigned = 0*/
    _assigned_8009 = 0LL;

    /** scinot.e:240		if compare(decimals, bits) > 0 then */
    if (IS_ATOM_INT(_decimals_8004) && IS_ATOM_INT(_bits_8007)){
        _4360 = (_decimals_8004 < _bits_8007) ? -1 : (_decimals_8004 > _bits_8007);
    }
    else{
        _4360 = compare(_decimals_8004, _bits_8007);
    }
    if (_4360 <= 0LL)
    goto L1; // [34] 166

    /** scinot.e:242			while (not assigned) or (bit < find( 1, bits ) + size + 1)  do*/
L2: 
    _4362 = (_assigned_8009 == 0);
    if (_4362 != 0) {
        goto L3; // [46] 72
    }
    _4364 = find_from(1LL, _bits_8007, 1LL);
    _4365 = _4364 + _size_8005;
    if ((object)((uintptr_t)_4365 + (uintptr_t)HIGH_BITS) >= 0){
        _4365 = NewDouble((eudouble)_4365);
    }
    _4364 = NOVALUE;
    if (IS_ATOM_INT(_4365)) {
        _4366 = _4365 + 1;
        if (_4366 > MAXINT){
            _4366 = NewDouble((eudouble)_4366);
        }
    }
    else
    _4366 = binary_op(PLUS, 1, _4365);
    DeRef(_4365);
    _4365 = NOVALUE;
    if (IS_ATOM_INT(_4366)) {
        _4367 = (_bit_8008 < _4366);
    }
    else {
        _4367 = ((eudouble)_bit_8008 < DBL_PTR(_4366)->dbl);
    }
    DeRef(_4366);
    _4366 = NOVALUE;
    if (_4367 == 0)
    {
        DeRef(_4367);
        _4367 = NOVALUE;
        goto L4; // [68] 165
    }
    else{
        DeRef(_4367);
        _4367 = NOVALUE;
    }
L3: 

    /** scinot.e:243				if compare( sub, decimals ) <= 0 then*/
    if (IS_ATOM_INT(_sub_8006) && IS_ATOM_INT(_decimals_8004)){
        _4368 = (_sub_8006 < _decimals_8004) ? -1 : (_sub_8006 > _decimals_8004);
    }
    else{
        _4368 = compare(_sub_8006, _decimals_8004);
    }
    if (_4368 > 0LL)
    goto L5; // [78] 146

    /** scinot.e:244					assigned = 1*/
    _assigned_8009 = 1LL;

    /** scinot.e:245					if length( bits ) < bit then*/
    if (IS_SEQUENCE(_bits_8007)){
            _4370 = SEQ_PTR(_bits_8007)->length;
    }
    else {
        _4370 = 1;
    }
    if (_4370 >= _bit_8008)
    goto L6; // [92] 114

    /** scinot.e:246						bits &= repeat( 0, bit - length(bits)) */
    if (IS_SEQUENCE(_bits_8007)){
            _4372 = SEQ_PTR(_bits_8007)->length;
    }
    else {
        _4372 = 1;
    }
    _4373 = _bit_8008 - _4372;
    _4372 = NOVALUE;
    _4374 = Repeat(0LL, _4373);
    _4373 = NOVALUE;
    Concat((object_ptr)&_bits_8007, _bits_8007, _4374);
    DeRefDS(_4374);
    _4374 = NOVALUE;
L6: 

    /** scinot.e:249					bits[bit] += 1*/
    _2 = (object)SEQ_PTR(_bits_8007);
    _4376 = (object)*(((s1_ptr)_2)->base + _bit_8008);
    if (IS_ATOM_INT(_4376)) {
        _4377 = _4376 + 1;
        if (_4377 > MAXINT){
            _4377 = NewDouble((eudouble)_4377);
        }
    }
    else
    _4377 = binary_op(PLUS, 1, _4376);
    _4376 = NOVALUE;
    _2 = (object)SEQ_PTR(_bits_8007);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bits_8007 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _bit_8008);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _4377;
    if( _1 != _4377 ){
        DeRef(_1);
    }
    _4377 = NOVALUE;

    /** scinot.e:250					decimals = borrow( add( decimals, -sub ), 10 )*/
    _4378 = unary_op(UMINUS, _sub_8006);
    RefDS(_decimals_8004);
    _4379 = _27add(_decimals_8004, _4378);
    _4378 = NOVALUE;
    _0 = _decimals_8004;
    _decimals_8004 = _27borrow(_4379, 10LL);
    DeRefDS(_0);
    _4379 = NOVALUE;
L5: 

    /** scinot.e:252				sub = half( sub )*/
    RefDS(_sub_8006);
    _0 = _sub_8006;
    _sub_8006 = _27half(_sub_8006);
    DeRefDS(_0);

    /** scinot.e:254				bit += 1*/
    _bit_8008 = _bit_8008 + 1;

    /** scinot.e:255			end while*/
    goto L2; // [162] 43
L4: 
L1: 

    /** scinot.e:258		return reverse(bits)*/
    RefDS(_bits_8007);
    _4383 = _27reverse(_bits_8007);
    DeRefDS(_decimals_8004);
    DeRef(_sub_8006);
    DeRefDS(_bits_8007);
    DeRef(_4362);
    _4362 = NOVALUE;
    return _4383;
    ;
}


object _27string_to_int(object _s_8042)
{
    object _int_8043 = NOVALUE;
    object _4387 = NOVALUE;
    object _4386 = NOVALUE;
    object _4384 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:263		int = 0*/
    _int_8043 = 0LL;

    /** scinot.e:264		for i = 1 to length(s) do*/
    if (IS_SEQUENCE(_s_8042)){
            _4384 = SEQ_PTR(_s_8042)->length;
    }
    else {
        _4384 = 1;
    }
    {
        object _i_8045;
        _i_8045 = 1LL;
L1: 
        if (_i_8045 > _4384){
            goto L2; // [13] 51
        }

        /** scinot.e:265			int *= 10*/
        _int_8043 = _int_8043 * 10LL;

        /** scinot.e:266			int += s[i] - '0'*/
        _2 = (object)SEQ_PTR(_s_8042);
        _4386 = (object)*(((s1_ptr)_2)->base + _i_8045);
        if (IS_ATOM_INT(_4386)) {
            _4387 = _4386 - 48LL;
            if ((object)((uintptr_t)_4387 +(uintptr_t) HIGH_BITS) >= 0){
                _4387 = NewDouble((eudouble)_4387);
            }
        }
        else {
            _4387 = binary_op(MINUS, _4386, 48LL);
        }
        _4386 = NOVALUE;
        if (IS_ATOM_INT(_4387)) {
            _int_8043 = _int_8043 + _4387;
        }
        else {
            _int_8043 = binary_op(PLUS, _int_8043, _4387);
        }
        DeRef(_4387);
        _4387 = NOVALUE;
        if (!IS_ATOM_INT(_int_8043)) {
            _1 = (object)(DBL_PTR(_int_8043)->dbl);
            DeRefDS(_int_8043);
            _int_8043 = _1;
        }

        /** scinot.e:267		end for*/
        _i_8045 = _i_8045 + 1LL;
        goto L1; // [46] 20
L2: 
        ;
    }

    /** scinot.e:268		return int*/
    DeRefDS(_s_8042);
    return _int_8043;
    ;
}


object _27trim_bits(object _bits_8053)
{
    object _4394 = NOVALUE;
    object _4393 = NOVALUE;
    object _4392 = NOVALUE;
    object _4391 = NOVALUE;
    object _4390 = NOVALUE;
    object _4389 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:272			while length(bits) and not bits[$] do*/
L1: 
    if (IS_SEQUENCE(_bits_8053)){
            _4389 = SEQ_PTR(_bits_8053)->length;
    }
    else {
        _4389 = 1;
    }
    if (_4389 == 0) {
        goto L2; // [11] 44
    }
    if (IS_SEQUENCE(_bits_8053)){
            _4391 = SEQ_PTR(_bits_8053)->length;
    }
    else {
        _4391 = 1;
    }
    _2 = (object)SEQ_PTR(_bits_8053);
    _4392 = (object)*(((s1_ptr)_2)->base + _4391);
    if (IS_ATOM_INT(_4392)) {
        _4393 = (_4392 == 0);
    }
    else {
        _4393 = unary_op(NOT, _4392);
    }
    _4392 = NOVALUE;
    if (_4393 <= 0) {
        if (_4393 == 0) {
            DeRef(_4393);
            _4393 = NOVALUE;
            goto L2; // [26] 44
        }
        else {
            if (!IS_ATOM_INT(_4393) && DBL_PTR(_4393)->dbl == 0.0){
                DeRef(_4393);
                _4393 = NOVALUE;
                goto L2; // [26] 44
            }
            DeRef(_4393);
            _4393 = NOVALUE;
        }
    }
    DeRef(_4393);
    _4393 = NOVALUE;

    /** scinot.e:273				bits = remove( bits, length( bits ) )*/
    if (IS_SEQUENCE(_bits_8053)){
            _4394 = SEQ_PTR(_bits_8053)->length;
    }
    else {
        _4394 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_bits_8053);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_4394)) ? _4394 : (object)(DBL_PTR(_4394)->dbl);
        int stop = (IS_ATOM_INT(_4394)) ? _4394 : (object)(DBL_PTR(_4394)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_bits_8053), start, &_bits_8053 );
            }
            else Tail(SEQ_PTR(_bits_8053), stop+1, &_bits_8053);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_bits_8053), start, &_bits_8053);
        }
        else {
            assign_slice_seq = &assign_space;
            _bits_8053 = Remove_elements(start, stop, (SEQ_PTR(_bits_8053)->ref == 1));
        }
    }
    _4394 = NOVALUE;
    _4394 = NOVALUE;

    /** scinot.e:274			end while*/
    goto L1; // [41] 8
L2: 

    /** scinot.e:275			return bits*/
    return _bits_8053;
    ;
}


object _27scientific_to_float(object _s_8076, object _fp_8077)
{
    object _dp_8078 = NOVALUE;
    object _e_8079 = NOVALUE;
    object _exp_8080 = NOVALUE;
    object _int_bits_8081 = NOVALUE;
    object _frac_bits_8082 = NOVALUE;
    object _mbits_8083 = NOVALUE;
    object _ebits_8084 = NOVALUE;
    object _sbits_8085 = NOVALUE;
    object _significand_8086 = NOVALUE;
    object _exponent_8087 = NOVALUE;
    object _min_exp_8088 = NOVALUE;
    object _exp_bias_8089 = NOVALUE;
    object _4553 = NOVALUE;
    object _4552 = NOVALUE;
    object _4550 = NOVALUE;
    object _4548 = NOVALUE;
    object _4547 = NOVALUE;
    object _4545 = NOVALUE;
    object _4544 = NOVALUE;
    object _4543 = NOVALUE;
    object _4542 = NOVALUE;
    object _4541 = NOVALUE;
    object _4540 = NOVALUE;
    object _4539 = NOVALUE;
    object _4537 = NOVALUE;
    object _4536 = NOVALUE;
    object _4534 = NOVALUE;
    object _4533 = NOVALUE;
    object _4532 = NOVALUE;
    object _4531 = NOVALUE;
    object _4528 = NOVALUE;
    object _4527 = NOVALUE;
    object _4526 = NOVALUE;
    object _4525 = NOVALUE;
    object _4524 = NOVALUE;
    object _4523 = NOVALUE;
    object _4522 = NOVALUE;
    object _4521 = NOVALUE;
    object _4518 = NOVALUE;
    object _4517 = NOVALUE;
    object _4514 = NOVALUE;
    object _4513 = NOVALUE;
    object _4512 = NOVALUE;
    object _4511 = NOVALUE;
    object _4508 = NOVALUE;
    object _4507 = NOVALUE;
    object _4505 = NOVALUE;
    object _4504 = NOVALUE;
    object _4502 = NOVALUE;
    object _4500 = NOVALUE;
    object _4499 = NOVALUE;
    object _4498 = NOVALUE;
    object _4497 = NOVALUE;
    object _4496 = NOVALUE;
    object _4495 = NOVALUE;
    object _4494 = NOVALUE;
    object _4493 = NOVALUE;
    object _4492 = NOVALUE;
    object _4491 = NOVALUE;
    object _4489 = NOVALUE;
    object _4488 = NOVALUE;
    object _4487 = NOVALUE;
    object _4486 = NOVALUE;
    object _4484 = NOVALUE;
    object _4483 = NOVALUE;
    object _4482 = NOVALUE;
    object _4481 = NOVALUE;
    object _4478 = NOVALUE;
    object _4476 = NOVALUE;
    object _4475 = NOVALUE;
    object _4474 = NOVALUE;
    object _4473 = NOVALUE;
    object _4472 = NOVALUE;
    object _4470 = NOVALUE;
    object _4469 = NOVALUE;
    object _4468 = NOVALUE;
    object _4467 = NOVALUE;
    object _4466 = NOVALUE;
    object _4465 = NOVALUE;
    object _4463 = NOVALUE;
    object _4462 = NOVALUE;
    object _4461 = NOVALUE;
    object _4460 = NOVALUE;
    object _4459 = NOVALUE;
    object _4457 = NOVALUE;
    object _4456 = NOVALUE;
    object _4454 = NOVALUE;
    object _4453 = NOVALUE;
    object _4452 = NOVALUE;
    object _4451 = NOVALUE;
    object _4450 = NOVALUE;
    object _4448 = NOVALUE;
    object _4446 = NOVALUE;
    object _4443 = NOVALUE;
    object _4442 = NOVALUE;
    object _4440 = NOVALUE;
    object _4439 = NOVALUE;
    object _4437 = NOVALUE;
    object _4433 = NOVALUE;
    object _4432 = NOVALUE;
    object _4431 = NOVALUE;
    object _4430 = NOVALUE;
    object _4428 = NOVALUE;
    object _4427 = NOVALUE;
    object _4426 = NOVALUE;
    object _4425 = NOVALUE;
    object _4423 = NOVALUE;
    object _4422 = NOVALUE;
    object _4420 = NOVALUE;
    object _4419 = NOVALUE;
    object _4418 = NOVALUE;
    object _4417 = NOVALUE;
    object _4415 = NOVALUE;
    object _4414 = NOVALUE;
    object _4407 = NOVALUE;
    object _4403 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:316		if fp = NATIVE then*/
    if (_fp_8077 != 1LL)
    goto L1; // [5] 17

    /** scinot.e:317			fp = NATIVE_FORMAT*/
    _fp_8077 = _27NATIVE_FORMAT_7831;
L1: 

    /** scinot.e:319		if fp = DOUBLE then*/
    if (_fp_8077 != 2LL)
    goto L2; // [19] 46

    /** scinot.e:320			significand = DOUBLE_SIGNIFICAND*/
    _significand_8086 = 52LL;

    /** scinot.e:321			exponent    = DOUBLE_EXPONENT*/
    _exponent_8087 = 11LL;

    /** scinot.e:322			min_exp     = DOUBLE_MIN_EXP*/
    _min_exp_8088 = -1023LL;

    /** scinot.e:323			exp_bias    = DOUBLE_EXP_BIAS*/
    _exp_bias_8089 = 1023LL;
    goto L3; // [43] 74
L2: 

    /** scinot.e:325		elsif fp = EXTENDED then*/
    if (_fp_8077 != 3LL)
    goto L4; // [48] 73

    /** scinot.e:326			significand = EXTENDED_SIGNIFICAND*/
    _significand_8086 = 64LL;

    /** scinot.e:327			exponent    = EXTENDED_EXPONENT*/
    _exponent_8087 = 15LL;

    /** scinot.e:328			min_exp     = EXTENDED_MIN_EXP*/
    _min_exp_8088 = -16383LL;

    /** scinot.e:329			exp_bias    = EXTENDED_EXP_BIAS*/
    _exp_bias_8089 = 16383LL;
L4: 
L3: 

    /** scinot.e:333		if s[1] = '-' then*/
    _2 = (object)SEQ_PTR(_s_8076);
    _4403 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _4403, 45LL)){
        _4403 = NOVALUE;
        goto L5; // [80] 101
    }
    _4403 = NOVALUE;

    /** scinot.e:334			sbits = {1}*/
    RefDS(_4329);
    DeRefi(_sbits_8085);
    _sbits_8085 = _4329;

    /** scinot.e:335			s = remove( s, 1 )*/
    {
        s1_ptr assign_space = SEQ_PTR(_s_8076);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(1LL)) ? 1LL : (object)(DBL_PTR(1LL)->dbl);
        int stop = (IS_ATOM_INT(1LL)) ? 1LL : (object)(DBL_PTR(1LL)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_s_8076), start, &_s_8076 );
            }
            else Tail(SEQ_PTR(_s_8076), stop+1, &_s_8076);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_s_8076), start, &_s_8076);
        }
        else {
            assign_slice_seq = &assign_space;
            _s_8076 = Remove_elements(start, stop, (SEQ_PTR(_s_8076)->ref == 1));
        }
    }
    goto L6; // [98] 126
L5: 

    /** scinot.e:337			sbits = {0}*/
    _0 = _sbits_8085;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0LL;
    _sbits_8085 = MAKE_SEQ(_1);
    DeRefi(_0);

    /** scinot.e:338			if s[1] = '+' then*/
    _2 = (object)SEQ_PTR(_s_8076);
    _4407 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _4407, 43LL)){
        _4407 = NOVALUE;
        goto L7; // [113] 125
    }
    _4407 = NOVALUE;

    /** scinot.e:339				s = remove( s, 1 )*/
    {
        s1_ptr assign_space = SEQ_PTR(_s_8076);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(1LL)) ? 1LL : (object)(DBL_PTR(1LL)->dbl);
        int stop = (IS_ATOM_INT(1LL)) ? 1LL : (object)(DBL_PTR(1LL)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_s_8076), start, &_s_8076 );
            }
            else Tail(SEQ_PTR(_s_8076), stop+1, &_s_8076);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_s_8076), start, &_s_8076);
        }
        else {
            assign_slice_seq = &assign_space;
            _s_8076 = Remove_elements(start, stop, (SEQ_PTR(_s_8076)->ref == 1));
        }
    }
L7: 
L6: 

    /** scinot.e:344		dp = find('.', s)*/
    _dp_8078 = find_from(46LL, _s_8076, 1LL);

    /** scinot.e:345		e = find( 'e', s )*/
    _e_8079 = find_from(101LL, _s_8076, 1LL);

    /** scinot.e:346		if not e then*/
    if (_e_8079 != 0)
    goto L8; // [142] 153

    /** scinot.e:347			e = find('E', s )*/
    _e_8079 = find_from(69LL, _s_8076, 1LL);
L8: 

    /** scinot.e:351		exp = 0*/
    _exp_8080 = 0LL;

    /** scinot.e:352		if s[e+1] = '-' then*/
    _4414 = _e_8079 + 1;
    _2 = (object)SEQ_PTR(_s_8076);
    _4415 = (object)*(((s1_ptr)_2)->base + _4414);
    if (binary_op_a(NOTEQ, _4415, 45LL)){
        _4415 = NOVALUE;
        goto L9; // [168] 199
    }
    _4415 = NOVALUE;

    /** scinot.e:353			exp -= string_to_int( s[e+2..$] )*/
    _4417 = _e_8079 + 2LL;
    if ((object)((uintptr_t)_4417 + (uintptr_t)HIGH_BITS) >= 0){
        _4417 = NewDouble((eudouble)_4417);
    }
    if (IS_SEQUENCE(_s_8076)){
            _4418 = SEQ_PTR(_s_8076)->length;
    }
    else {
        _4418 = 1;
    }
    rhs_slice_target = (object_ptr)&_4419;
    RHS_Slice(_s_8076, _4417, _4418);
    _4420 = _27string_to_int(_4419);
    _4419 = NOVALUE;
    if (IS_ATOM_INT(_4420)) {
        _exp_8080 = _exp_8080 - _4420;
    }
    else {
        _exp_8080 = binary_op(MINUS, _exp_8080, _4420);
    }
    DeRef(_4420);
    _4420 = NOVALUE;
    if (!IS_ATOM_INT(_exp_8080)) {
        _1 = (object)(DBL_PTR(_exp_8080)->dbl);
        DeRefDS(_exp_8080);
        _exp_8080 = _1;
    }
    goto LA; // [196] 266
L9: 

    /** scinot.e:356			if s[e+1] = '+' then*/
    _4422 = _e_8079 + 1;
    _2 = (object)SEQ_PTR(_s_8076);
    _4423 = (object)*(((s1_ptr)_2)->base + _4422);
    if (binary_op_a(NOTEQ, _4423, 43LL)){
        _4423 = NOVALUE;
        goto LB; // [209] 240
    }
    _4423 = NOVALUE;

    /** scinot.e:357				exp += string_to_int( s[e+2..$] )*/
    _4425 = _e_8079 + 2LL;
    if ((object)((uintptr_t)_4425 + (uintptr_t)HIGH_BITS) >= 0){
        _4425 = NewDouble((eudouble)_4425);
    }
    if (IS_SEQUENCE(_s_8076)){
            _4426 = SEQ_PTR(_s_8076)->length;
    }
    else {
        _4426 = 1;
    }
    rhs_slice_target = (object_ptr)&_4427;
    RHS_Slice(_s_8076, _4425, _4426);
    _4428 = _27string_to_int(_4427);
    _4427 = NOVALUE;
    if (IS_ATOM_INT(_4428)) {
        _exp_8080 = _exp_8080 + _4428;
    }
    else {
        _exp_8080 = binary_op(PLUS, _exp_8080, _4428);
    }
    DeRef(_4428);
    _4428 = NOVALUE;
    if (!IS_ATOM_INT(_exp_8080)) {
        _1 = (object)(DBL_PTR(_exp_8080)->dbl);
        DeRefDS(_exp_8080);
        _exp_8080 = _1;
    }
    goto LC; // [237] 265
LB: 

    /** scinot.e:359				exp += string_to_int( s[e+1..$] )*/
    _4430 = _e_8079 + 1;
    if (_4430 > MAXINT){
        _4430 = NewDouble((eudouble)_4430);
    }
    if (IS_SEQUENCE(_s_8076)){
            _4431 = SEQ_PTR(_s_8076)->length;
    }
    else {
        _4431 = 1;
    }
    rhs_slice_target = (object_ptr)&_4432;
    RHS_Slice(_s_8076, _4430, _4431);
    _4433 = _27string_to_int(_4432);
    _4432 = NOVALUE;
    if (IS_ATOM_INT(_4433)) {
        _exp_8080 = _exp_8080 + _4433;
    }
    else {
        _exp_8080 = binary_op(PLUS, _exp_8080, _4433);
    }
    DeRef(_4433);
    _4433 = NOVALUE;
    if (!IS_ATOM_INT(_exp_8080)) {
        _1 = (object)(DBL_PTR(_exp_8080)->dbl);
        DeRefDS(_exp_8080);
        _exp_8080 = _1;
    }
LC: 
LA: 

    /** scinot.e:363		if dp then*/
    if (_dp_8078 == 0)
    {
        goto LD; // [268] 297
    }
    else{
    }

    /** scinot.e:365			s = remove( s, dp )*/
    {
        s1_ptr assign_space = SEQ_PTR(_s_8076);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_dp_8078)) ? _dp_8078 : (object)(DBL_PTR(_dp_8078)->dbl);
        int stop = (IS_ATOM_INT(_dp_8078)) ? _dp_8078 : (object)(DBL_PTR(_dp_8078)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_s_8076), start, &_s_8076 );
            }
            else Tail(SEQ_PTR(_s_8076), stop+1, &_s_8076);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_s_8076), start, &_s_8076);
        }
        else {
            assign_slice_seq = &assign_space;
            _s_8076 = Remove_elements(start, stop, (SEQ_PTR(_s_8076)->ref == 1));
        }
    }

    /** scinot.e:366			e -= 1*/
    _e_8079 = _e_8079 - 1LL;

    /** scinot.e:369			exp -= e - dp*/
    _4437 = _e_8079 - _dp_8078;
    if ((object)((uintptr_t)_4437 +(uintptr_t) HIGH_BITS) >= 0){
        _4437 = NewDouble((eudouble)_4437);
    }
    if (IS_ATOM_INT(_4437)) {
        _exp_8080 = _exp_8080 - _4437;
    }
    else {
        _exp_8080 = NewDouble((eudouble)_exp_8080 - DBL_PTR(_4437)->dbl);
    }
    DeRef(_4437);
    _4437 = NOVALUE;
    if (!IS_ATOM_INT(_exp_8080)) {
        _1 = (object)(DBL_PTR(_exp_8080)->dbl);
        DeRefDS(_exp_8080);
        _exp_8080 = _1;
    }
LD: 

    /** scinot.e:374		s = s[1..e-1] - '0'*/
    _4439 = _e_8079 - 1LL;
    rhs_slice_target = (object_ptr)&_4440;
    RHS_Slice(_s_8076, 1LL, _4439);
    DeRefDS(_s_8076);
    _s_8076 = binary_op(MINUS, _4440, 48LL);
    DeRefDS(_4440);
    _4440 = NOVALUE;

    /** scinot.e:377		if not find(0, s = 0) then*/
    _4442 = binary_op(EQUALS, _s_8076, 0LL);
    _4443 = find_from(0LL, _4442, 1LL);
    DeRefDS(_4442);
    _4442 = NOVALUE;
    if (_4443 != 0)
    goto LE; // [325] 366
    _4443 = NOVALUE;

    /** scinot.e:378			if fp = DOUBLE then*/
    if (_fp_8077 != 2LL)
    goto LF; // [330] 347

    /** scinot.e:379				return atom_to_float64(0)*/
    _4446 = _19atom_to_float64(0LL);
    DeRefDS(_s_8076);
    DeRef(_int_bits_8081);
    DeRef(_frac_bits_8082);
    DeRef(_mbits_8083);
    DeRef(_ebits_8084);
    DeRefi(_sbits_8085);
    DeRef(_4417);
    _4417 = NOVALUE;
    DeRef(_4422);
    _4422 = NOVALUE;
    _4439 = NOVALUE;
    DeRef(_4430);
    _4430 = NOVALUE;
    DeRef(_4425);
    _4425 = NOVALUE;
    DeRef(_4414);
    _4414 = NOVALUE;
    return _4446;
    goto L10; // [344] 365
LF: 

    /** scinot.e:380			elsif fp = EXTENDED then*/
    if (_fp_8077 != 3LL)
    goto L11; // [349] 364

    /** scinot.e:381				return atom_to_float80(0)*/
    _4448 = _19atom_to_float80(0LL);
    DeRefDS(_s_8076);
    DeRef(_int_bits_8081);
    DeRef(_frac_bits_8082);
    DeRef(_mbits_8083);
    DeRef(_ebits_8084);
    DeRefi(_sbits_8085);
    DeRef(_4417);
    _4417 = NOVALUE;
    DeRef(_4422);
    _4422 = NOVALUE;
    DeRef(_4439);
    _4439 = NOVALUE;
    DeRef(_4430);
    _4430 = NOVALUE;
    DeRef(_4425);
    _4425 = NOVALUE;
    DeRef(_4414);
    _4414 = NOVALUE;
    DeRef(_4446);
    _4446 = NOVALUE;
    return _4448;
L11: 
L10: 
LE: 

    /** scinot.e:385		if exp >= 0 then*/
    if (_exp_8080 < 0LL)
    goto L12; // [368] 412

    /** scinot.e:388			int_bits = trim_bits( bytes_to_bits( convert_radix( repeat( 0, exp ) & reverse( s ), 10, #100 ) ) )*/
    _4450 = Repeat(0LL, _exp_8080);
    RefDS(_s_8076);
    _4451 = _27reverse(_s_8076);
    if (IS_SEQUENCE(_4450) && IS_ATOM(_4451)) {
        Ref(_4451);
        Append(&_4452, _4450, _4451);
    }
    else if (IS_ATOM(_4450) && IS_SEQUENCE(_4451)) {
    }
    else {
        Concat((object_ptr)&_4452, _4450, _4451);
        DeRefDS(_4450);
        _4450 = NOVALUE;
    }
    DeRef(_4450);
    _4450 = NOVALUE;
    DeRef(_4451);
    _4451 = NOVALUE;
    _4453 = _27convert_radix(_4452, 10LL, 256LL);
    _4452 = NOVALUE;
    _4454 = _27bytes_to_bits(_4453);
    _4453 = NOVALUE;
    _0 = _int_bits_8081;
    _int_bits_8081 = _27trim_bits(_4454);
    DeRef(_0);
    _4454 = NOVALUE;

    /** scinot.e:389			frac_bits = {}*/
    RefDS(_5);
    DeRef(_frac_bits_8082);
    _frac_bits_8082 = _5;
    goto L13; // [409] 529
L12: 

    /** scinot.e:391			if -exp > length(s) then*/
    if ((uintptr_t)_exp_8080 == (uintptr_t)HIGH_BITS){
        _4456 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _4456 = - _exp_8080;
    }
    if (IS_SEQUENCE(_s_8076)){
            _4457 = SEQ_PTR(_s_8076)->length;
    }
    else {
        _4457 = 1;
    }
    if (binary_op_a(LESSEQ, _4456, _4457)){
        DeRef(_4456);
        _4456 = NOVALUE;
        _4457 = NOVALUE;
        goto L14; // [420] 463
    }
    DeRef(_4456);
    _4456 = NOVALUE;
    _4457 = NOVALUE;

    /** scinot.e:393				int_bits = {}*/
    RefDS(_5);
    DeRef(_int_bits_8081);
    _int_bits_8081 = _5;

    /** scinot.e:394				frac_bits = decimals_to_bits( repeat( 0, -exp-length(s) ) & s, significand ) */
    if ((uintptr_t)_exp_8080 == (uintptr_t)HIGH_BITS){
        _4459 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _4459 = - _exp_8080;
    }
    if (IS_SEQUENCE(_s_8076)){
            _4460 = SEQ_PTR(_s_8076)->length;
    }
    else {
        _4460 = 1;
    }
    if (IS_ATOM_INT(_4459)) {
        _4461 = _4459 - _4460;
    }
    else {
        _4461 = NewDouble(DBL_PTR(_4459)->dbl - (eudouble)_4460);
    }
    DeRef(_4459);
    _4459 = NOVALUE;
    _4460 = NOVALUE;
    _4462 = Repeat(0LL, _4461);
    DeRef(_4461);
    _4461 = NOVALUE;
    Concat((object_ptr)&_4463, _4462, _s_8076);
    DeRefDS(_4462);
    _4462 = NOVALUE;
    DeRef(_4462);
    _4462 = NOVALUE;
    _0 = _frac_bits_8082;
    _frac_bits_8082 = _27decimals_to_bits(_4463, _significand_8086);
    DeRef(_0);
    _4463 = NOVALUE;
    goto L15; // [460] 528
L14: 

    /** scinot.e:398				int_bits = trim_bits( bytes_to_bits( convert_radix( reverse( s[1..$+exp] ), 10, #100 ) ) )*/
    if (IS_SEQUENCE(_s_8076)){
            _4465 = SEQ_PTR(_s_8076)->length;
    }
    else {
        _4465 = 1;
    }
    _4466 = _4465 + _exp_8080;
    _4465 = NOVALUE;
    rhs_slice_target = (object_ptr)&_4467;
    RHS_Slice(_s_8076, 1LL, _4466);
    _4468 = _27reverse(_4467);
    _4467 = NOVALUE;
    _4469 = _27convert_radix(_4468, 10LL, 256LL);
    _4468 = NOVALUE;
    _4470 = _27bytes_to_bits(_4469);
    _4469 = NOVALUE;
    _0 = _int_bits_8081;
    _int_bits_8081 = _27trim_bits(_4470);
    DeRef(_0);
    _4470 = NOVALUE;

    /** scinot.e:399				frac_bits =  decimals_to_bits( s[$+exp+1..$], significand )*/
    if (IS_SEQUENCE(_s_8076)){
            _4472 = SEQ_PTR(_s_8076)->length;
    }
    else {
        _4472 = 1;
    }
    _4473 = _4472 + _exp_8080;
    if ((object)((uintptr_t)_4473 + (uintptr_t)HIGH_BITS) >= 0){
        _4473 = NewDouble((eudouble)_4473);
    }
    _4472 = NOVALUE;
    if (IS_ATOM_INT(_4473)) {
        _4474 = _4473 + 1;
        if (_4474 > MAXINT){
            _4474 = NewDouble((eudouble)_4474);
        }
    }
    else
    _4474 = binary_op(PLUS, 1, _4473);
    DeRef(_4473);
    _4473 = NOVALUE;
    if (IS_SEQUENCE(_s_8076)){
            _4475 = SEQ_PTR(_s_8076)->length;
    }
    else {
        _4475 = 1;
    }
    rhs_slice_target = (object_ptr)&_4476;
    RHS_Slice(_s_8076, _4474, _4475);
    _0 = _frac_bits_8082;
    _frac_bits_8082 = _27decimals_to_bits(_4476, _significand_8086);
    DeRef(_0);
    _4476 = NOVALUE;
L15: 
L13: 

    /** scinot.e:403		if length(int_bits) > significand then*/
    if (IS_SEQUENCE(_int_bits_8081)){
            _4478 = SEQ_PTR(_int_bits_8081)->length;
    }
    else {
        _4478 = 1;
    }
    if (_4478 <= _significand_8086)
    goto L16; // [538] 668

    /** scinot.e:406			if fp = DOUBLE then*/
    if (_fp_8077 != 2LL)
    goto L17; // [544] 572

    /** scinot.e:408				mbits = int_bits[$-significand..$-1]*/
    if (IS_SEQUENCE(_int_bits_8081)){
            _4481 = SEQ_PTR(_int_bits_8081)->length;
    }
    else {
        _4481 = 1;
    }
    _4482 = _4481 - _significand_8086;
    if ((object)((uintptr_t)_4482 +(uintptr_t) HIGH_BITS) >= 0){
        _4482 = NewDouble((eudouble)_4482);
    }
    _4481 = NOVALUE;
    if (IS_SEQUENCE(_int_bits_8081)){
            _4483 = SEQ_PTR(_int_bits_8081)->length;
    }
    else {
        _4483 = 1;
    }
    _4484 = _4483 - 1LL;
    _4483 = NOVALUE;
    rhs_slice_target = (object_ptr)&_mbits_8083;
    RHS_Slice(_int_bits_8081, _4482, _4484);
    goto L18; // [569] 594
L17: 

    /** scinot.e:411				mbits = int_bits[$-significand+1..$]*/
    if (IS_SEQUENCE(_int_bits_8081)){
            _4486 = SEQ_PTR(_int_bits_8081)->length;
    }
    else {
        _4486 = 1;
    }
    _4487 = _4486 - _significand_8086;
    if ((object)((uintptr_t)_4487 +(uintptr_t) HIGH_BITS) >= 0){
        _4487 = NewDouble((eudouble)_4487);
    }
    _4486 = NOVALUE;
    if (IS_ATOM_INT(_4487)) {
        _4488 = _4487 + 1;
        if (_4488 > MAXINT){
            _4488 = NewDouble((eudouble)_4488);
        }
    }
    else
    _4488 = binary_op(PLUS, 1, _4487);
    DeRef(_4487);
    _4487 = NOVALUE;
    if (IS_SEQUENCE(_int_bits_8081)){
            _4489 = SEQ_PTR(_int_bits_8081)->length;
    }
    else {
        _4489 = 1;
    }
    rhs_slice_target = (object_ptr)&_mbits_8083;
    RHS_Slice(_int_bits_8081, _4488, _4489);
L18: 

    /** scinot.e:414			if length(int_bits) > significand + 1 and int_bits[$-(significand+1)] then*/
    if (IS_SEQUENCE(_int_bits_8081)){
            _4491 = SEQ_PTR(_int_bits_8081)->length;
    }
    else {
        _4491 = 1;
    }
    _4492 = _significand_8086 + 1;
    if (_4492 > MAXINT){
        _4492 = NewDouble((eudouble)_4492);
    }
    if (IS_ATOM_INT(_4492)) {
        _4493 = (_4491 > _4492);
    }
    else {
        _4493 = ((eudouble)_4491 > DBL_PTR(_4492)->dbl);
    }
    _4491 = NOVALUE;
    DeRef(_4492);
    _4492 = NOVALUE;
    if (_4493 == 0) {
        goto L19; // [607] 656
    }
    if (IS_SEQUENCE(_int_bits_8081)){
            _4495 = SEQ_PTR(_int_bits_8081)->length;
    }
    else {
        _4495 = 1;
    }
    _4496 = _significand_8086 + 1;
    if (_4496 > MAXINT){
        _4496 = NewDouble((eudouble)_4496);
    }
    if (IS_ATOM_INT(_4496)) {
        _4497 = _4495 - _4496;
    }
    else {
        _4497 = NewDouble((eudouble)_4495 - DBL_PTR(_4496)->dbl);
    }
    _4495 = NOVALUE;
    DeRef(_4496);
    _4496 = NOVALUE;
    _2 = (object)SEQ_PTR(_int_bits_8081);
    if (!IS_ATOM_INT(_4497)){
        _4498 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_4497)->dbl));
    }
    else{
        _4498 = (object)*(((s1_ptr)_2)->base + _4497);
    }
    if (_4498 == 0) {
        _4498 = NOVALUE;
        goto L19; // [627] 656
    }
    else {
        if (!IS_ATOM_INT(_4498) && DBL_PTR(_4498)->dbl == 0.0){
            _4498 = NOVALUE;
            goto L19; // [627] 656
        }
        _4498 = NOVALUE;
    }
    _4498 = NOVALUE;

    /** scinot.e:416				mbits[1] += 1*/
    _2 = (object)SEQ_PTR(_mbits_8083);
    _4499 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_4499)) {
        _4500 = _4499 + 1;
        if (_4500 > MAXINT){
            _4500 = NewDouble((eudouble)_4500);
        }
    }
    else
    _4500 = binary_op(PLUS, 1, _4499);
    _4499 = NOVALUE;
    _2 = (object)SEQ_PTR(_mbits_8083);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _mbits_8083 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _4500;
    if( _1 != _4500 ){
        DeRef(_1);
    }
    _4500 = NOVALUE;

    /** scinot.e:417				mbits = carry( mbits, 2 )*/
    RefDS(_mbits_8083);
    _0 = _mbits_8083;
    _mbits_8083 = _27carry(_mbits_8083, 2LL);
    DeRefDS(_0);
L19: 

    /** scinot.e:419			exp = length(int_bits)-1*/
    if (IS_SEQUENCE(_int_bits_8081)){
            _4502 = SEQ_PTR(_int_bits_8081)->length;
    }
    else {
        _4502 = 1;
    }
    _exp_8080 = _4502 - 1LL;
    _4502 = NOVALUE;
    goto L1A; // [665] 940
L16: 

    /** scinot.e:422			if length(int_bits) then*/
    if (IS_SEQUENCE(_int_bits_8081)){
            _4504 = SEQ_PTR(_int_bits_8081)->length;
    }
    else {
        _4504 = 1;
    }
    if (_4504 == 0)
    {
        _4504 = NOVALUE;
        goto L1B; // [673] 688
    }
    else{
        _4504 = NOVALUE;
    }

    /** scinot.e:424				exp = length(int_bits)-1*/
    if (IS_SEQUENCE(_int_bits_8081)){
            _4505 = SEQ_PTR(_int_bits_8081)->length;
    }
    else {
        _4505 = 1;
    }
    _exp_8080 = _4505 - 1LL;
    _4505 = NOVALUE;
    goto L1C; // [685] 748
L1B: 

    /** scinot.e:428				exp = - find( 1, reverse( frac_bits ) )*/
    RefDS(_frac_bits_8082);
    _4507 = _27reverse(_frac_bits_8082);
    _4508 = find_from(1LL, _4507, 1LL);
    DeRef(_4507);
    _4507 = NOVALUE;
    _exp_8080 = - _4508;

    /** scinot.e:429				if exp < min_exp then*/
    if (_exp_8080 >= _min_exp_8088)
    goto L1D; // [710] 720

    /** scinot.e:432					exp = min_exp*/
    _exp_8080 = _min_exp_8088;
L1D: 

    /** scinot.e:435				if exp then*/
    if (_exp_8080 == 0)
    {
        goto L1E; // [722] 747
    }
    else{
    }

    /** scinot.e:437					frac_bits = remove( frac_bits, length(frac_bits) + exp + 2, length( frac_bits ) )*/
    if (IS_SEQUENCE(_frac_bits_8082)){
            _4511 = SEQ_PTR(_frac_bits_8082)->length;
    }
    else {
        _4511 = 1;
    }
    _4512 = _4511 + _exp_8080;
    if ((object)((uintptr_t)_4512 + (uintptr_t)HIGH_BITS) >= 0){
        _4512 = NewDouble((eudouble)_4512);
    }
    _4511 = NOVALUE;
    if (IS_ATOM_INT(_4512)) {
        _4513 = _4512 + 2LL;
        if ((object)((uintptr_t)_4513 + (uintptr_t)HIGH_BITS) >= 0){
            _4513 = NewDouble((eudouble)_4513);
        }
    }
    else {
        _4513 = NewDouble(DBL_PTR(_4512)->dbl + (eudouble)2LL);
    }
    DeRef(_4512);
    _4512 = NOVALUE;
    if (IS_SEQUENCE(_frac_bits_8082)){
            _4514 = SEQ_PTR(_frac_bits_8082)->length;
    }
    else {
        _4514 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_frac_bits_8082);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_4513)) ? _4513 : (object)(DBL_PTR(_4513)->dbl);
        int stop = (IS_ATOM_INT(_4514)) ? _4514 : (object)(DBL_PTR(_4514)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_frac_bits_8082), start, &_frac_bits_8082 );
            }
            else Tail(SEQ_PTR(_frac_bits_8082), stop+1, &_frac_bits_8082);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_frac_bits_8082), start, &_frac_bits_8082);
        }
        else {
            assign_slice_seq = &assign_space;
            _frac_bits_8082 = Remove_elements(start, stop, (SEQ_PTR(_frac_bits_8082)->ref == 1));
        }
    }
    DeRef(_4513);
    _4513 = NOVALUE;
    _4514 = NOVALUE;
L1E: 
L1C: 

    /** scinot.e:444			mbits = frac_bits & int_bits*/
    Concat((object_ptr)&_mbits_8083, _frac_bits_8082, _int_bits_8081);

    /** scinot.e:445			mbits = repeat( 0, significand + 1 ) & mbits*/
    _4517 = _significand_8086 + 1;
    _4518 = Repeat(0LL, _4517);
    _4517 = NOVALUE;
    Concat((object_ptr)&_mbits_8083, _4518, _mbits_8083);
    DeRefDS(_4518);
    _4518 = NOVALUE;
    DeRef(_4518);
    _4518 = NOVALUE;

    /** scinot.e:447			if exp > min_exp then*/
    if (_exp_8080 <= _min_exp_8088)
    goto L1F; // [774] 877

    /** scinot.e:449				if mbits[$-(significand+1)] then*/
    if (IS_SEQUENCE(_mbits_8083)){
            _4521 = SEQ_PTR(_mbits_8083)->length;
    }
    else {
        _4521 = 1;
    }
    _4522 = _significand_8086 + 1;
    if (_4522 > MAXINT){
        _4522 = NewDouble((eudouble)_4522);
    }
    if (IS_ATOM_INT(_4522)) {
        _4523 = _4521 - _4522;
    }
    else {
        _4523 = NewDouble((eudouble)_4521 - DBL_PTR(_4522)->dbl);
    }
    _4521 = NOVALUE;
    DeRef(_4522);
    _4522 = NOVALUE;
    _2 = (object)SEQ_PTR(_mbits_8083);
    if (!IS_ATOM_INT(_4523)){
        _4524 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_4523)->dbl));
    }
    else{
        _4524 = (object)*(((s1_ptr)_2)->base + _4523);
    }
    if (_4524 == 0) {
        _4524 = NOVALUE;
        goto L20; // [795] 829
    }
    else {
        if (!IS_ATOM_INT(_4524) && DBL_PTR(_4524)->dbl == 0.0){
            _4524 = NOVALUE;
            goto L20; // [795] 829
        }
        _4524 = NOVALUE;
    }
    _4524 = NOVALUE;

    /** scinot.e:451					mbits[$-significand] += 1*/
    if (IS_SEQUENCE(_mbits_8083)){
            _4525 = SEQ_PTR(_mbits_8083)->length;
    }
    else {
        _4525 = 1;
    }
    _4526 = _4525 - _significand_8086;
    _4525 = NOVALUE;
    _2 = (object)SEQ_PTR(_mbits_8083);
    _4527 = (object)*(((s1_ptr)_2)->base + _4526);
    if (IS_ATOM_INT(_4527)) {
        _4528 = _4527 + 1;
        if (_4528 > MAXINT){
            _4528 = NewDouble((eudouble)_4528);
        }
    }
    else
    _4528 = binary_op(PLUS, 1, _4527);
    _4527 = NOVALUE;
    _2 = (object)SEQ_PTR(_mbits_8083);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _mbits_8083 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _4526);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _4528;
    if( _1 != _4528 ){
        DeRef(_1);
    }
    _4528 = NOVALUE;

    /** scinot.e:452					mbits = carry( mbits, 2 )*/
    RefDS(_mbits_8083);
    _0 = _mbits_8083;
    _mbits_8083 = _27carry(_mbits_8083, 2LL);
    DeRefDS(_0);
L20: 

    /** scinot.e:454				if fp = DOUBLE then*/
    if (_fp_8077 != 2LL)
    goto L21; // [831] 859

    /** scinot.e:456					mbits = mbits[$-significand..$-1]*/
    if (IS_SEQUENCE(_mbits_8083)){
            _4531 = SEQ_PTR(_mbits_8083)->length;
    }
    else {
        _4531 = 1;
    }
    _4532 = _4531 - _significand_8086;
    if ((object)((uintptr_t)_4532 +(uintptr_t) HIGH_BITS) >= 0){
        _4532 = NewDouble((eudouble)_4532);
    }
    _4531 = NOVALUE;
    if (IS_SEQUENCE(_mbits_8083)){
            _4533 = SEQ_PTR(_mbits_8083)->length;
    }
    else {
        _4533 = 1;
    }
    _4534 = _4533 - 1LL;
    _4533 = NOVALUE;
    rhs_slice_target = (object_ptr)&_mbits_8083;
    RHS_Slice(_mbits_8083, _4532, _4534);
    goto L22; // [856] 939
L21: 

    /** scinot.e:459					mbits = remove( mbits, 1, length(mbits) - significand )*/
    if (IS_SEQUENCE(_mbits_8083)){
            _4536 = SEQ_PTR(_mbits_8083)->length;
    }
    else {
        _4536 = 1;
    }
    _4537 = _4536 - _significand_8086;
    if ((object)((uintptr_t)_4537 +(uintptr_t) HIGH_BITS) >= 0){
        _4537 = NewDouble((eudouble)_4537);
    }
    _4536 = NOVALUE;
    {
        s1_ptr assign_space = SEQ_PTR(_mbits_8083);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(1LL)) ? 1LL : (object)(DBL_PTR(1LL)->dbl);
        int stop = (IS_ATOM_INT(_4537)) ? _4537 : (object)(DBL_PTR(_4537)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_mbits_8083), start, &_mbits_8083 );
            }
            else Tail(SEQ_PTR(_mbits_8083), stop+1, &_mbits_8083);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_mbits_8083), start, &_mbits_8083);
        }
        else {
            assign_slice_seq = &assign_space;
            _mbits_8083 = Remove_elements(start, stop, (SEQ_PTR(_mbits_8083)->ref == 1));
        }
    }
    DeRef(_4537);
    _4537 = NOVALUE;
    goto L22; // [874] 939
L1F: 

    /** scinot.e:463				if mbits[$-significand] then*/
    if (IS_SEQUENCE(_mbits_8083)){
            _4539 = SEQ_PTR(_mbits_8083)->length;
    }
    else {
        _4539 = 1;
    }
    _4540 = _4539 - _significand_8086;
    _4539 = NOVALUE;
    _2 = (object)SEQ_PTR(_mbits_8083);
    _4541 = (object)*(((s1_ptr)_2)->base + _4540);
    if (_4541 == 0) {
        _4541 = NOVALUE;
        goto L23; // [890] 924
    }
    else {
        if (!IS_ATOM_INT(_4541) && DBL_PTR(_4541)->dbl == 0.0){
            _4541 = NOVALUE;
            goto L23; // [890] 924
        }
        _4541 = NOVALUE;
    }
    _4541 = NOVALUE;

    /** scinot.e:465					mbits[$-significand] += 1*/
    if (IS_SEQUENCE(_mbits_8083)){
            _4542 = SEQ_PTR(_mbits_8083)->length;
    }
    else {
        _4542 = 1;
    }
    _4543 = _4542 - _significand_8086;
    _4542 = NOVALUE;
    _2 = (object)SEQ_PTR(_mbits_8083);
    _4544 = (object)*(((s1_ptr)_2)->base + _4543);
    if (IS_ATOM_INT(_4544)) {
        _4545 = _4544 + 1;
        if (_4545 > MAXINT){
            _4545 = NewDouble((eudouble)_4545);
        }
    }
    else
    _4545 = binary_op(PLUS, 1, _4544);
    _4544 = NOVALUE;
    _2 = (object)SEQ_PTR(_mbits_8083);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _mbits_8083 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _4543);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _4545;
    if( _1 != _4545 ){
        DeRef(_1);
    }
    _4545 = NOVALUE;

    /** scinot.e:466					mbits = carry( mbits, 2 )*/
    RefDS(_mbits_8083);
    _0 = _mbits_8083;
    _mbits_8083 = _27carry(_mbits_8083, 2LL);
    DeRefDS(_0);
L23: 

    /** scinot.e:468				mbits = remove( mbits, 1, length(mbits) - significand )*/
    if (IS_SEQUENCE(_mbits_8083)){
            _4547 = SEQ_PTR(_mbits_8083)->length;
    }
    else {
        _4547 = 1;
    }
    _4548 = _4547 - _significand_8086;
    if ((object)((uintptr_t)_4548 +(uintptr_t) HIGH_BITS) >= 0){
        _4548 = NewDouble((eudouble)_4548);
    }
    _4547 = NOVALUE;
    {
        s1_ptr assign_space = SEQ_PTR(_mbits_8083);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(1LL)) ? 1LL : (object)(DBL_PTR(1LL)->dbl);
        int stop = (IS_ATOM_INT(_4548)) ? _4548 : (object)(DBL_PTR(_4548)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_mbits_8083), start, &_mbits_8083 );
            }
            else Tail(SEQ_PTR(_mbits_8083), stop+1, &_mbits_8083);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_mbits_8083), start, &_mbits_8083);
        }
        else {
            assign_slice_seq = &assign_space;
            _mbits_8083 = Remove_elements(start, stop, (SEQ_PTR(_mbits_8083)->ref == 1));
        }
    }
    DeRef(_4548);
    _4548 = NOVALUE;
L22: 
L1A: 

    /** scinot.e:474		ebits = int_to_bits( exp + exp_bias, exponent )*/
    _4550 = _exp_8080 + _exp_bias_8089;
    if ((object)((uintptr_t)_4550 + (uintptr_t)HIGH_BITS) >= 0){
        _4550 = NewDouble((eudouble)_4550);
    }
    _0 = _ebits_8084;
    _ebits_8084 = _19int_to_bits(_4550, _exponent_8087);
    DeRef(_0);
    _4550 = NOVALUE;

    /** scinot.e:477		return bits_to_bytes( mbits & ebits & sbits )*/
    {
        object concat_list[3];

        concat_list[0] = _sbits_8085;
        concat_list[1] = _ebits_8084;
        concat_list[2] = _mbits_8083;
        Concat_N((object_ptr)&_4552, concat_list, 3);
    }
    _4553 = _27bits_to_bytes(_4552);
    _4552 = NOVALUE;
    DeRefDS(_s_8076);
    DeRef(_int_bits_8081);
    DeRef(_frac_bits_8082);
    DeRefDS(_mbits_8083);
    DeRefDS(_ebits_8084);
    DeRefDSi(_sbits_8085);
    DeRef(_4466);
    _4466 = NOVALUE;
    DeRef(_4417);
    _4417 = NOVALUE;
    DeRef(_4422);
    _4422 = NOVALUE;
    DeRef(_4497);
    _4497 = NOVALUE;
    DeRef(_4532);
    _4532 = NOVALUE;
    DeRef(_4540);
    _4540 = NOVALUE;
    DeRef(_4439);
    _4439 = NOVALUE;
    DeRef(_4448);
    _4448 = NOVALUE;
    DeRef(_4430);
    _4430 = NOVALUE;
    DeRef(_4523);
    _4523 = NOVALUE;
    DeRef(_4534);
    _4534 = NOVALUE;
    DeRef(_4425);
    _4425 = NOVALUE;
    DeRef(_4414);
    _4414 = NOVALUE;
    DeRef(_4474);
    _4474 = NOVALUE;
    DeRef(_4526);
    _4526 = NOVALUE;
    DeRef(_4543);
    _4543 = NOVALUE;
    DeRef(_4446);
    _4446 = NOVALUE;
    DeRef(_4484);
    _4484 = NOVALUE;
    DeRef(_4488);
    _4488 = NOVALUE;
    DeRef(_4493);
    _4493 = NOVALUE;
    DeRef(_4482);
    _4482 = NOVALUE;
    return _4553;
    ;
}


object _27scientific_to_atom(object _s_8283, object _fp_8284)
{
    object _float_8287 = NOVALUE;
    object _4559 = NOVALUE;
    object _4557 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:495		if fp = NATIVE then*/
    if (_fp_8284 != 1LL)
    goto L1; // [5] 17

    /** scinot.e:496			fp = NATIVE_FORMAT*/
    _fp_8284 = _27NATIVE_FORMAT_7831;
L1: 

    /** scinot.e:498		sequence float = scientific_to_float( s, fp )*/
    RefDS(_s_8283);
    _0 = _float_8287;
    _float_8287 = _27scientific_to_float(_s_8283, _fp_8284);
    DeRef(_0);

    /** scinot.e:499		if fp = DOUBLE then*/
    if (_fp_8284 != 2LL)
    goto L2; // [28] 45

    /** scinot.e:500			return float64_to_atom( float )*/
    RefDS(_float_8287);
    _4557 = _19float64_to_atom(_float_8287);
    DeRefDS(_s_8283);
    DeRefDS(_float_8287);
    return _4557;
    goto L3; // [42] 63
L2: 

    /** scinot.e:501		elsif fp = EXTENDED then*/
    if (_fp_8284 != 3LL)
    goto L4; // [47] 62

    /** scinot.e:502			return float80_to_atom( float )*/
    RefDS(_float_8287);
    _4559 = _19float80_to_atom(_float_8287);
    DeRefDS(_s_8283);
    DeRefDS(_float_8287);
    DeRef(_4557);
    _4557 = NOVALUE;
    return _4559;
L4: 
L3: 
    ;
}



// 0xB2C9B758
