// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _42clear_fwd_refs()
{
    object _0, _1, _2;
    

    /** fwdref.e:70		fwdref_count = 0*/
    _42fwdref_count_62884 = 0LL;

    /** fwdref.e:71	end procedure*/
    return;
    ;
}


object _42get_fwdref_count()
{
    object _0, _1, _2;
    

    /** fwdref.e:74		return fwdref_count*/
    return _42fwdref_count_62884;
    ;
}


void _42set_glabel_block(object _ref_62891, object _block_62893)
{
    object _30921 = NOVALUE;
    object _30920 = NOVALUE;
    object _30918 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_62891)) {
        _1 = (object)(DBL_PTR(_ref_62891)->dbl);
        DeRefDS(_ref_62891);
        _ref_62891 = _1;
    }
    if (!IS_ATOM_INT(_block_62893)) {
        _1 = (object)(DBL_PTR(_block_62893)->dbl);
        DeRefDS(_block_62893);
        _block_62893 = _1;
    }

    /** fwdref.e:78		forward_references[ref][FR_DATA] &= block*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_62864 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_62891 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _30920 = (object)*(((s1_ptr)_2)->base + 12LL);
    _30918 = NOVALUE;
    if (IS_SEQUENCE(_30920) && IS_ATOM(_block_62893)) {
        Append(&_30921, _30920, _block_62893);
    }
    else if (IS_ATOM(_30920) && IS_SEQUENCE(_block_62893)) {
    }
    else {
        Concat((object_ptr)&_30921, _30920, _block_62893);
        _30920 = NOVALUE;
    }
    _30920 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30921;
    if( _1 != _30921 ){
        DeRef(_1);
    }
    _30921 = NOVALUE;
    _30918 = NOVALUE;

    /** fwdref.e:79	end procedure*/
    return;
    ;
}


void _42replace_code(object _code_62905, object _start_62906, object _finish_62907, object _subprog_62908)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_finish_62907)) {
        _1 = (object)(DBL_PTR(_finish_62907)->dbl);
        DeRefDS(_finish_62907);
        _finish_62907 = _1;
    }
    if (!IS_ATOM_INT(_subprog_62908)) {
        _1 = (object)(DBL_PTR(_subprog_62908)->dbl);
        DeRefDS(_subprog_62908);
        _subprog_62908 = _1;
    }

    /** fwdref.e:88		shifting_sub = subprog*/
    _42shifting_sub_62883 = _subprog_62908;

    /** fwdref.e:89		shift:replace_code( code, start, finish )*/
    RefDS(_code_62905);
    _65replace_code(_code_62905, _start_62906, _finish_62907);

    /** fwdref.e:90		shifting_sub = 0*/
    _42shifting_sub_62883 = 0LL;

    /** fwdref.e:91	end procedure*/
    DeRefDS(_code_62905);
    return;
    ;
}


void _42resolved_reference(object _ref_62911)
{
    object _file_62912 = NOVALUE;
    object _subprog_62915 = NOVALUE;
    object _tx_62918 = NOVALUE;
    object _ax_62919 = NOVALUE;
    object _sp_62920 = NOVALUE;
    object _r_62935 = NOVALUE;
    object _r_62953 = NOVALUE;
    object _30945 = NOVALUE;
    object _30944 = NOVALUE;
    object _30943 = NOVALUE;
    object _30941 = NOVALUE;
    object _30938 = NOVALUE;
    object _30936 = NOVALUE;
    object _30934 = NOVALUE;
    object _30933 = NOVALUE;
    object _30931 = NOVALUE;
    object _30929 = NOVALUE;
    object _30927 = NOVALUE;
    object _30926 = NOVALUE;
    object _30924 = NOVALUE;
    object _30922 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:95			file    = forward_references[ref][FR_FILE],*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    _30922 = (object)*(((s1_ptr)_2)->base + _ref_62911);
    _2 = (object)SEQ_PTR(_30922);
    _file_62912 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_file_62912)){
        _file_62912 = (object)DBL_PTR(_file_62912)->dbl;
    }
    _30922 = NOVALUE;

    /** fwdref.e:96			subprog = forward_references[ref][FR_SUBPROG]*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    _30924 = (object)*(((s1_ptr)_2)->base + _ref_62911);
    _2 = (object)SEQ_PTR(_30924);
    _subprog_62915 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_subprog_62915)){
        _subprog_62915 = (object)DBL_PTR(_subprog_62915)->dbl;
    }
    _30924 = NOVALUE;

    /** fwdref.e:99			tx = 0,*/
    _tx_62918 = 0LL;

    /** fwdref.e:100			ax = 0,*/
    _ax_62919 = 0LL;

    /** fwdref.e:101			sp = 0*/
    _sp_62920 = 0LL;

    /** fwdref.e:103		if forward_references[ref][FR_SUBPROG] = TopLevelSub then*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    _30926 = (object)*(((s1_ptr)_2)->base + _ref_62911);
    _2 = (object)SEQ_PTR(_30926);
    _30927 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30926 = NOVALUE;
    if (binary_op_a(NOTEQ, _30927, _12TopLevelSub_20233)){
        _30927 = NOVALUE;
        goto L1; // [60] 80
    }
    _30927 = NOVALUE;

    /** fwdref.e:104			tx = find( ref, toplevel_references[file] )*/
    _2 = (object)SEQ_PTR(_42toplevel_references_62867);
    _30929 = (object)*(((s1_ptr)_2)->base + _file_62912);
    _tx_62918 = find_from(_ref_62911, _30929, 1LL);
    _30929 = NOVALUE;
    goto L2; // [77] 111
L1: 

    /** fwdref.e:106			sp = find( subprog, active_subprogs[file] )*/
    _2 = (object)SEQ_PTR(_42active_subprogs_62865);
    _30931 = (object)*(((s1_ptr)_2)->base + _file_62912);
    _sp_62920 = find_from(_subprog_62915, _30931, 1LL);
    _30931 = NOVALUE;

    /** fwdref.e:107			ax = find( ref, active_references[file][sp] )*/
    _2 = (object)SEQ_PTR(_42active_references_62866);
    _30933 = (object)*(((s1_ptr)_2)->base + _file_62912);
    _2 = (object)SEQ_PTR(_30933);
    _30934 = (object)*(((s1_ptr)_2)->base + _sp_62920);
    _30933 = NOVALUE;
    _ax_62919 = find_from(_ref_62911, _30934, 1LL);
    _30934 = NOVALUE;
L2: 

    /** fwdref.e:110		if ax then*/
    if (_ax_62919 == 0)
    {
        goto L3; // [113] 253
    }
    else{
    }

    /** fwdref.e:111			sequence r = active_references[file][sp] */
    _2 = (object)SEQ_PTR(_42active_references_62866);
    _30936 = (object)*(((s1_ptr)_2)->base + _file_62912);
    DeRef(_r_62935);
    _2 = (object)SEQ_PTR(_30936);
    _r_62935 = (object)*(((s1_ptr)_2)->base + _sp_62920);
    Ref(_r_62935);
    _30936 = NOVALUE;

    /** fwdref.e:112			active_references[file][sp] = 0*/
    _2 = (object)SEQ_PTR(_42active_references_62866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42active_references_62866 = MAKE_SEQ(_2);
    }
    _3 = (object)(_file_62912 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _sp_62920);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30938 = NOVALUE;

    /** fwdref.e:113			r = remove( r, ax )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_62935);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ax_62919)) ? _ax_62919 : (object)(DBL_PTR(_ax_62919)->dbl);
        int stop = (IS_ATOM_INT(_ax_62919)) ? _ax_62919 : (object)(DBL_PTR(_ax_62919)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_62935), start, &_r_62935 );
            }
            else Tail(SEQ_PTR(_r_62935), stop+1, &_r_62935);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_62935), start, &_r_62935);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_62935 = Remove_elements(start, stop, (SEQ_PTR(_r_62935)->ref == 1));
        }
    }

    /** fwdref.e:114			active_references[file][sp] = r*/
    _2 = (object)SEQ_PTR(_42active_references_62866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42active_references_62866 = MAKE_SEQ(_2);
    }
    _3 = (object)(_file_62912 + ((s1_ptr)_2)->base);
    RefDS(_r_62935);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _sp_62920);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_62935;
    DeRef(_1);
    _30941 = NOVALUE;

    /** fwdref.e:116			if not length( active_references[file][sp] ) then*/
    _2 = (object)SEQ_PTR(_42active_references_62866);
    _30943 = (object)*(((s1_ptr)_2)->base + _file_62912);
    _2 = (object)SEQ_PTR(_30943);
    _30944 = (object)*(((s1_ptr)_2)->base + _sp_62920);
    _30943 = NOVALUE;
    if (IS_SEQUENCE(_30944)){
            _30945 = SEQ_PTR(_30944)->length;
    }
    else {
        _30945 = 1;
    }
    _30944 = NOVALUE;
    if (_30945 != 0)
    goto L4; // [178] 248
    _30945 = NOVALUE;

    /** fwdref.e:117				r = active_references[file]*/
    DeRefDS(_r_62935);
    _2 = (object)SEQ_PTR(_42active_references_62866);
    _r_62935 = (object)*(((s1_ptr)_2)->base + _file_62912);
    Ref(_r_62935);

    /** fwdref.e:118				active_references[file] = 0*/
    _2 = (object)SEQ_PTR(_42active_references_62866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42active_references_62866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_62912);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** fwdref.e:119				r = remove( r, sp )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_62935);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_sp_62920)) ? _sp_62920 : (object)(DBL_PTR(_sp_62920)->dbl);
        int stop = (IS_ATOM_INT(_sp_62920)) ? _sp_62920 : (object)(DBL_PTR(_sp_62920)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_62935), start, &_r_62935 );
            }
            else Tail(SEQ_PTR(_r_62935), stop+1, &_r_62935);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_62935), start, &_r_62935);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_62935 = Remove_elements(start, stop, (SEQ_PTR(_r_62935)->ref == 1));
        }
    }

    /** fwdref.e:120				active_references[file] = r*/
    RefDS(_r_62935);
    _2 = (object)SEQ_PTR(_42active_references_62866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42active_references_62866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_62912);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_62935;
    DeRef(_1);

    /** fwdref.e:122				r = active_subprogs[file]*/
    DeRefDS(_r_62935);
    _2 = (object)SEQ_PTR(_42active_subprogs_62865);
    _r_62935 = (object)*(((s1_ptr)_2)->base + _file_62912);
    Ref(_r_62935);

    /** fwdref.e:123				active_subprogs[file] = 0*/
    _2 = (object)SEQ_PTR(_42active_subprogs_62865);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42active_subprogs_62865 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_62912);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** fwdref.e:124				r = remove( r,   sp )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_62935);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_sp_62920)) ? _sp_62920 : (object)(DBL_PTR(_sp_62920)->dbl);
        int stop = (IS_ATOM_INT(_sp_62920)) ? _sp_62920 : (object)(DBL_PTR(_sp_62920)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_62935), start, &_r_62935 );
            }
            else Tail(SEQ_PTR(_r_62935), stop+1, &_r_62935);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_62935), start, &_r_62935);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_62935 = Remove_elements(start, stop, (SEQ_PTR(_r_62935)->ref == 1));
        }
    }

    /** fwdref.e:125				active_subprogs[file] = r*/
    RefDS(_r_62935);
    _2 = (object)SEQ_PTR(_42active_subprogs_62865);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42active_subprogs_62865 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_62912);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_62935;
    DeRef(_1);
L4: 
    DeRef(_r_62935);
    _r_62935 = NOVALUE;
    goto L5; // [250] 303
L3: 

    /** fwdref.e:127		elsif tx then*/
    if (_tx_62918 == 0)
    {
        goto L6; // [255] 296
    }
    else{
    }

    /** fwdref.e:128			sequence r = toplevel_references[file]*/
    DeRef(_r_62953);
    _2 = (object)SEQ_PTR(_42toplevel_references_62867);
    _r_62953 = (object)*(((s1_ptr)_2)->base + _file_62912);
    Ref(_r_62953);

    /** fwdref.e:129			toplevel_references[file] = 0*/
    _2 = (object)SEQ_PTR(_42toplevel_references_62867);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42toplevel_references_62867 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_62912);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** fwdref.e:130			r = remove( r, tx )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_62953);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_tx_62918)) ? _tx_62918 : (object)(DBL_PTR(_tx_62918)->dbl);
        int stop = (IS_ATOM_INT(_tx_62918)) ? _tx_62918 : (object)(DBL_PTR(_tx_62918)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_62953), start, &_r_62953 );
            }
            else Tail(SEQ_PTR(_r_62953), stop+1, &_r_62953);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_62953), start, &_r_62953);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_62953 = Remove_elements(start, stop, (SEQ_PTR(_r_62953)->ref == 1));
        }
    }

    /** fwdref.e:131			toplevel_references[file] = r*/
    RefDS(_r_62953);
    _2 = (object)SEQ_PTR(_42toplevel_references_62867);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42toplevel_references_62867 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_62912);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_62953;
    DeRef(_1);
    DeRefDS(_r_62953);
    _r_62953 = NOVALUE;
    goto L5; // [293] 303
L6: 

    /** fwdref.e:134			InternalErr( 260 )*/
    RefDS(_22024);
    _49InternalErr(260LL, _22024);
L5: 

    /** fwdref.e:136		inactive_references &= ref*/
    Append(&_42inactive_references_62868, _42inactive_references_62868, _ref_62911);

    /** fwdref.e:137		forward_references[ref] = 0*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_62864 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _ref_62911);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** fwdref.e:138	end procedure*/
    _30944 = NOVALUE;
    return;
    ;
}


void _42set_code(object _ref_62967)
{
    object _30970 = NOVALUE;
    object _30968 = NOVALUE;
    object _30967 = NOVALUE;
    object _30966 = NOVALUE;
    object _30965 = NOVALUE;
    object _30963 = NOVALUE;
    object _30961 = NOVALUE;
    object _30959 = NOVALUE;
    object _30957 = NOVALUE;
    object _30954 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:146		patch_code_sub = forward_references[ref][FR_SUBPROG]*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    _30954 = (object)*(((s1_ptr)_2)->base + _ref_62967);
    _2 = (object)SEQ_PTR(_30954);
    _42patch_code_sub_62962 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_42patch_code_sub_62962)){
        _42patch_code_sub_62962 = (object)DBL_PTR(_42patch_code_sub_62962)->dbl;
    }
    _30954 = NOVALUE;

    /** fwdref.e:147		if patch_code_sub != CurrentSub then*/
    if (_42patch_code_sub_62962 == _12CurrentSub_20234)
    goto L1; // [23] 136

    /** fwdref.e:149			patch_code_temp = Code*/
    RefDS(_12Code_20315);
    DeRef(_42patch_code_temp_62959);
    _42patch_code_temp_62959 = _12Code_20315;

    /** fwdref.e:150			patch_linetab_temp = LineTable*/
    RefDS(_12LineTable_20316);
    DeRef(_42patch_linetab_temp_62960);
    _42patch_linetab_temp_62960 = _12LineTable_20316;

    /** fwdref.e:152			Code = SymTab[patch_code_sub][S_CODE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30957 = (object)*(((s1_ptr)_2)->base + _42patch_code_sub_62962);
    DeRefDS(_12Code_20315);
    _2 = (object)SEQ_PTR(_30957);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _12Code_20315 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    Ref(_12Code_20315);
    _30957 = NOVALUE;

    /** fwdref.e:153			SymTab[patch_code_sub][S_CODE] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_42patch_code_sub_62962 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_19876))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30959 = NOVALUE;

    /** fwdref.e:154			LineTable = SymTab[patch_code_sub][S_LINETAB]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30961 = (object)*(((s1_ptr)_2)->base + _42patch_code_sub_62962);
    DeRefDS(_12LineTable_20316);
    _2 = (object)SEQ_PTR(_30961);
    if (!IS_ATOM_INT(_12S_LINETAB_19899)){
        _12LineTable_20316 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_LINETAB_19899)->dbl));
    }
    else{
        _12LineTable_20316 = (object)*(((s1_ptr)_2)->base + _12S_LINETAB_19899);
    }
    Ref(_12LineTable_20316);
    _30961 = NOVALUE;

    /** fwdref.e:155			SymTab[patch_code_sub][S_LINETAB] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_42patch_code_sub_62962 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_LINETAB_19899))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_LINETAB_19899)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_LINETAB_19899);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30963 = NOVALUE;

    /** fwdref.e:157			patch_current_sub = CurrentSub*/
    _42patch_current_sub_62964 = _12CurrentSub_20234;

    /** fwdref.e:158			CurrentSub = patch_code_sub*/
    _12CurrentSub_20234 = _42patch_code_sub_62962;
    goto L2; // [133] 203
L1: 

    /** fwdref.e:160			patch_current_sub = patch_code_sub*/
    _42patch_current_sub_62964 = _42patch_code_sub_62962;

    /** fwdref.e:161			if sequence( SymTab[patch_current_sub][S_CODE] ) then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _30965 = (object)*(((s1_ptr)_2)->base + _42patch_current_sub_62964);
    _2 = (object)SEQ_PTR(_30965);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _30966 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _30966 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    _30965 = NOVALUE;
    _30967 = IS_SEQUENCE(_30966);
    _30966 = NOVALUE;
    if (_30967 == 0)
    {
        _30967 = NOVALUE;
        goto L3; // [164] 202
    }
    else{
        _30967 = NOVALUE;
    }

    /** fwdref.e:162				SymTab[patch_code_sub][S_CODE] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_42patch_code_sub_62962 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_19876))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30968 = NOVALUE;

    /** fwdref.e:163				SymTab[patch_code_sub][S_LINETAB] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_42patch_code_sub_62962 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_LINETAB_19899))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_LINETAB_19899)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_LINETAB_19899);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30970 = NOVALUE;
L3: 
L2: 

    /** fwdref.e:166	end procedure*/
    return;
    ;
}


void _42reset_code()
{
    object _30975 = NOVALUE;
    object _30973 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:169		if patch_code_sub != patch_current_sub then*/
    if (_42patch_code_sub_62962 == _42patch_current_sub_62964)
    goto L1; // [7] 77

    /** fwdref.e:171			SymTab[patch_code_sub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_42patch_code_sub_62962 + ((s1_ptr)_2)->base);
    RefDS(_12Code_20315);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_19876))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12Code_20315;
    DeRef(_1);
    _30973 = NOVALUE;

    /** fwdref.e:172			SymTab[patch_code_sub][S_LINETAB] = LineTable*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_42patch_code_sub_62962 + ((s1_ptr)_2)->base);
    RefDS(_12LineTable_20316);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_LINETAB_19899))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_LINETAB_19899)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_LINETAB_19899);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12LineTable_20316;
    DeRef(_1);
    _30975 = NOVALUE;

    /** fwdref.e:175			CurrentSub = patch_current_sub*/
    _12CurrentSub_20234 = _42patch_current_sub_62964;

    /** fwdref.e:176			Code = patch_code_temp*/
    RefDS(_42patch_code_temp_62959);
    DeRefDS(_12Code_20315);
    _12Code_20315 = _42patch_code_temp_62959;

    /** fwdref.e:177			LineTable = patch_linetab_temp*/
    RefDS(_42patch_linetab_temp_62960);
    DeRefDS(_12LineTable_20316);
    _12LineTable_20316 = _42patch_linetab_temp_62960;
L1: 

    /** fwdref.e:181		patch_code_temp = {}*/
    RefDS(_22024);
    DeRef(_42patch_code_temp_62959);
    _42patch_code_temp_62959 = _22024;

    /** fwdref.e:182		patch_linetab_temp = {}*/
    RefDS(_22024);
    DeRef(_42patch_linetab_temp_62960);
    _42patch_linetab_temp_62960 = _22024;

    /** fwdref.e:183	end procedure*/
    return;
    ;
}


void _42set_data(object _ref_63029, object _data_63030)
{
    object _30977 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:186		forward_references[ref][FR_DATA] = data*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_62864 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63029 + ((s1_ptr)_2)->base);
    Ref(_data_63030);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _data_63030;
    DeRef(_1);
    _30977 = NOVALUE;

    /** fwdref.e:187	end procedure*/
    DeRef(_data_63030);
    return;
    ;
}


void _42add_data(object _ref_63035, object _data_63036)
{
    object _30983 = NOVALUE;
    object _30982 = NOVALUE;
    object _30981 = NOVALUE;
    object _30979 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_63035)) {
        _1 = (object)(DBL_PTR(_ref_63035)->dbl);
        DeRefDS(_ref_63035);
        _ref_63035 = _1;
    }

    /** fwdref.e:190		forward_references[ref][FR_DATA] = append( forward_references[ref][FR_DATA], data )*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_62864 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63035 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    _30981 = (object)*(((s1_ptr)_2)->base + _ref_63035);
    _2 = (object)SEQ_PTR(_30981);
    _30982 = (object)*(((s1_ptr)_2)->base + 12LL);
    _30981 = NOVALUE;
    Ref(_data_63036);
    Append(&_30983, _30982, _data_63036);
    _30982 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30983;
    if( _1 != _30983 ){
        DeRef(_1);
    }
    _30983 = NOVALUE;
    _30979 = NOVALUE;

    /** fwdref.e:191	end procedure*/
    DeRef(_data_63036);
    return;
    ;
}


void _42set_line(object _ref_63044, object _line_no_63045, object _this_line_63046, object _bp_63047)
{
    object _30988 = NOVALUE;
    object _30986 = NOVALUE;
    object _30984 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_63044)) {
        _1 = (object)(DBL_PTR(_ref_63044)->dbl);
        DeRefDS(_ref_63044);
        _ref_63044 = _1;
    }

    /** fwdref.e:194		forward_references[ref][FR_LINE] = line_no*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_62864 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63044 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _line_no_63045;
    DeRef(_1);
    _30984 = NOVALUE;

    /** fwdref.e:195		forward_references[ref][FR_THISLINE] = this_line*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_62864 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63044 + ((s1_ptr)_2)->base);
    RefDS(_this_line_63046);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 7LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _this_line_63046;
    DeRef(_1);
    _30986 = NOVALUE;

    /** fwdref.e:196		forward_references[ref][FR_BP] = bp*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_62864 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63044 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 8LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _bp_63047;
    DeRef(_1);
    _30988 = NOVALUE;

    /** fwdref.e:198	end procedure*/
    DeRefDS(_this_line_63046);
    return;
    ;
}


void _42add_private_symbol(object _sym_63059, object _name_63060)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_63059)) {
        _1 = (object)(DBL_PTR(_sym_63059)->dbl);
        DeRefDS(_sym_63059);
        _sym_63059 = _1;
    }

    /** fwdref.e:206		fwd_private_sym &= sym*/
    Append(&_42fwd_private_sym_63054, _42fwd_private_sym_63054, _sym_63059);

    /** fwdref.e:207		fwd_private_name = append( fwd_private_name, name )*/
    RefDS(_name_63060);
    Append(&_42fwd_private_name_63055, _42fwd_private_name_63055, _name_63060);

    /** fwdref.e:209	end procedure*/
    DeRefDS(_name_63060);
    return;
    ;
}


void _42patch_forward_goto(object _tok_63068, object _ref_63069)
{
    object _fr_63070 = NOVALUE;
    object _31004 = NOVALUE;
    object _31003 = NOVALUE;
    object _31002 = NOVALUE;
    object _31001 = NOVALUE;
    object _31000 = NOVALUE;
    object _30999 = NOVALUE;
    object _30998 = NOVALUE;
    object _30997 = NOVALUE;
    object _30995 = NOVALUE;
    object _30994 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:217		sequence fr = forward_references[ref]*/
    DeRef(_fr_63070);
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    _fr_63070 = (object)*(((s1_ptr)_2)->base + _ref_63069);
    Ref(_fr_63070);

    /** fwdref.e:218		set_code( ref )*/
    _42set_code(_ref_63069);

    /** fwdref.e:220		shifting_sub = fr[FR_SUBPROG]*/
    _2 = (object)SEQ_PTR(_fr_63070);
    _42shifting_sub_62883 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_42shifting_sub_62883))
    _42shifting_sub_62883 = (object)DBL_PTR(_42shifting_sub_62883)->dbl;

    /** fwdref.e:222		if length( fr[FR_DATA] ) = 2 then*/
    _2 = (object)SEQ_PTR(_fr_63070);
    _30994 = (object)*(((s1_ptr)_2)->base + 12LL);
    if (IS_SEQUENCE(_30994)){
            _30995 = SEQ_PTR(_30994)->length;
    }
    else {
        _30995 = 1;
    }
    _30994 = NOVALUE;
    if (_30995 != 2LL)
    goto L1; // [33] 64

    /** fwdref.e:223			prep_forward_error( ref )*/
    _42prep_forward_error(_ref_63069);

    /** fwdref.e:224			CompileErr( UNKNOWN_LABEL_1, { fr[FR_DATA][2] })*/
    _2 = (object)SEQ_PTR(_fr_63070);
    _30997 = (object)*(((s1_ptr)_2)->base + 12LL);
    _2 = (object)SEQ_PTR(_30997);
    _30998 = (object)*(((s1_ptr)_2)->base + 2LL);
    _30997 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_30998);
    ((intptr_t*)_2)[1] = _30998;
    _30999 = MAKE_SEQ(_1);
    _30998 = NOVALUE;
    _49CompileErr(156LL, _30999, 0LL);
    _30999 = NOVALUE;
L1: 

    /** fwdref.e:227		Goto_block(  fr[FR_DATA][1], fr[FR_DATA][3], fr[FR_PC] )*/
    _2 = (object)SEQ_PTR(_fr_63070);
    _31000 = (object)*(((s1_ptr)_2)->base + 12LL);
    _2 = (object)SEQ_PTR(_31000);
    _31001 = (object)*(((s1_ptr)_2)->base + 1LL);
    _31000 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_63070);
    _31002 = (object)*(((s1_ptr)_2)->base + 12LL);
    _2 = (object)SEQ_PTR(_31002);
    _31003 = (object)*(((s1_ptr)_2)->base + 3LL);
    _31002 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_63070);
    _31004 = (object)*(((s1_ptr)_2)->base + 5LL);
    Ref(_31001);
    Ref(_31003);
    Ref(_31004);
    _64Goto_block(_31001, _31003, _31004);
    _31001 = NOVALUE;
    _31003 = NOVALUE;
    _31004 = NOVALUE;

    /** fwdref.e:229		shifting_sub = 0*/
    _42shifting_sub_62883 = 0LL;

    /** fwdref.e:231		reset_code()*/
    _42reset_code();

    /** fwdref.e:232		resolved_reference( ref )*/
    _42resolved_reference(_ref_63069);

    /** fwdref.e:233	end procedure*/
    DeRefDS(_fr_63070);
    _30994 = NOVALUE;
    return;
    ;
}


void _42patch_forward_call(object _tok_63092, object _ref_63093)
{
    object _fr_63094 = NOVALUE;
    object _sub_63097 = NOVALUE;
    object _defarg_63103 = NOVALUE;
    object _paramsym_63107 = NOVALUE;
    object _old_63110 = NOVALUE;
    object _tx_63114 = NOVALUE;
    object _code_sub_63124 = NOVALUE;
    object _args_63126 = NOVALUE;
    object _is_func_63131 = NOVALUE;
    object _real_file_63145 = NOVALUE;
    object _code_63149 = NOVALUE;
    object _temp_sub_63151 = NOVALUE;
    object _pc_63153 = NOVALUE;
    object _next_pc_63155 = NOVALUE;
    object _supplied_args_63156 = NOVALUE;
    object _name_63159 = NOVALUE;
    object _old_temps_allocated_63195 = NOVALUE;
    object _temp_target_63204 = NOVALUE;
    object _converted_code_63207 = NOVALUE;
    object _target_63223 = NOVALUE;
    object _has_defaults_63229 = NOVALUE;
    object _goto_target_63230 = NOVALUE;
    object _defarg_63233 = NOVALUE;
    object _code_len_63234 = NOVALUE;
    object _extra_default_args_63236 = NOVALUE;
    object _param_sym_63239 = NOVALUE;
    object _params_63240 = NOVALUE;
    object _orig_code_63242 = NOVALUE;
    object _orig_linetable_63243 = NOVALUE;
    object _ar_sp_63247 = NOVALUE;
    object _pre_refs_63251 = NOVALUE;
    object _old_fwd_params_63266 = NOVALUE;
    object _temp_shifting_sub_63307 = NOVALUE;
    object _new_code_63311 = NOVALUE;
    object _routine_type_63320 = NOVALUE;
    object _31763 = NOVALUE;
    object _31145 = NOVALUE;
    object _31144 = NOVALUE;
    object _31143 = NOVALUE;
    object _31141 = NOVALUE;
    object _31140 = NOVALUE;
    object _31139 = NOVALUE;
    object _31138 = NOVALUE;
    object _31137 = NOVALUE;
    object _31136 = NOVALUE;
    object _31135 = NOVALUE;
    object _31134 = NOVALUE;
    object _31133 = NOVALUE;
    object _31132 = NOVALUE;
    object _31131 = NOVALUE;
    object _31130 = NOVALUE;
    object _31129 = NOVALUE;
    object _31127 = NOVALUE;
    object _31126 = NOVALUE;
    object _31125 = NOVALUE;
    object _31124 = NOVALUE;
    object _31123 = NOVALUE;
    object _31122 = NOVALUE;
    object _31121 = NOVALUE;
    object _31120 = NOVALUE;
    object _31118 = NOVALUE;
    object _31115 = NOVALUE;
    object _31114 = NOVALUE;
    object _31113 = NOVALUE;
    object _31112 = NOVALUE;
    object _31108 = NOVALUE;
    object _31107 = NOVALUE;
    object _31106 = NOVALUE;
    object _31105 = NOVALUE;
    object _31104 = NOVALUE;
    object _31102 = NOVALUE;
    object _31101 = NOVALUE;
    object _31100 = NOVALUE;
    object _31099 = NOVALUE;
    object _31098 = NOVALUE;
    object _31097 = NOVALUE;
    object _31095 = NOVALUE;
    object _31094 = NOVALUE;
    object _31092 = NOVALUE;
    object _31091 = NOVALUE;
    object _31090 = NOVALUE;
    object _31089 = NOVALUE;
    object _31087 = NOVALUE;
    object _31085 = NOVALUE;
    object _31084 = NOVALUE;
    object _31083 = NOVALUE;
    object _31081 = NOVALUE;
    object _31080 = NOVALUE;
    object _31078 = NOVALUE;
    object _31076 = NOVALUE;
    object _31073 = NOVALUE;
    object _31069 = NOVALUE;
    object _31067 = NOVALUE;
    object _31066 = NOVALUE;
    object _31064 = NOVALUE;
    object _31063 = NOVALUE;
    object _31062 = NOVALUE;
    object _31061 = NOVALUE;
    object _31059 = NOVALUE;
    object _31058 = NOVALUE;
    object _31057 = NOVALUE;
    object _31056 = NOVALUE;
    object _31055 = NOVALUE;
    object _31053 = NOVALUE;
    object _31052 = NOVALUE;
    object _31051 = NOVALUE;
    object _31050 = NOVALUE;
    object _31049 = NOVALUE;
    object _31048 = NOVALUE;
    object _31047 = NOVALUE;
    object _31046 = NOVALUE;
    object _31045 = NOVALUE;
    object _31044 = NOVALUE;
    object _31043 = NOVALUE;
    object _31042 = NOVALUE;
    object _31041 = NOVALUE;
    object _31040 = NOVALUE;
    object _31038 = NOVALUE;
    object _31037 = NOVALUE;
    object _31036 = NOVALUE;
    object _31035 = NOVALUE;
    object _31034 = NOVALUE;
    object _31031 = NOVALUE;
    object _31027 = NOVALUE;
    object _31026 = NOVALUE;
    object _31025 = NOVALUE;
    object _31024 = NOVALUE;
    object _31023 = NOVALUE;
    object _31022 = NOVALUE;
    object _31020 = NOVALUE;
    object _31017 = NOVALUE;
    object _31015 = NOVALUE;
    object _31014 = NOVALUE;
    object _31012 = NOVALUE;
    object _31009 = NOVALUE;
    object _31008 = NOVALUE;
    object _31007 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:242		sequence fr = forward_references[ref]*/
    DeRef(_fr_63094);
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    _fr_63094 = (object)*(((s1_ptr)_2)->base + _ref_63093);
    Ref(_fr_63094);

    /** fwdref.e:243		symtab_index sub = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63092);
    _sub_63097 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_sub_63097)){
        _sub_63097 = (object)DBL_PTR(_sub_63097)->dbl;
    }

    /** fwdref.e:245		if sequence( fr[FR_DATA] ) then*/
    _2 = (object)SEQ_PTR(_fr_63094);
    _31007 = (object)*(((s1_ptr)_2)->base + 12LL);
    _31008 = IS_SEQUENCE(_31007);
    _31007 = NOVALUE;
    if (_31008 == 0)
    {
        _31008 = NOVALUE;
        goto L1; // [32] 117
    }
    else{
        _31008 = NOVALUE;
    }

    /** fwdref.e:246			sequence defarg = fr[FR_DATA][1]*/
    _2 = (object)SEQ_PTR(_fr_63094);
    _31009 = (object)*(((s1_ptr)_2)->base + 12LL);
    DeRef(_defarg_63103);
    _2 = (object)SEQ_PTR(_31009);
    _defarg_63103 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_defarg_63103);
    _31009 = NOVALUE;

    /** fwdref.e:247			symtab_index paramsym = defarg[2]*/
    _2 = (object)SEQ_PTR(_defarg_63103);
    _paramsym_63107 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_paramsym_63107)){
        _paramsym_63107 = (object)DBL_PTR(_paramsym_63107)->dbl;
    }

    /** fwdref.e:248			token old = { RECORDED, defarg[3] }*/
    _2 = (object)SEQ_PTR(_defarg_63103);
    _31012 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_31012);
    DeRef(_old_63110);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 508LL;
    ((intptr_t *)_2)[2] = _31012;
    _old_63110 = MAKE_SEQ(_1);
    _31012 = NOVALUE;

    /** fwdref.e:249			integer tx = find( old, SymTab[paramsym][S_CODE] )*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31014 = (object)*(((s1_ptr)_2)->base + _paramsym_63107);
    _2 = (object)SEQ_PTR(_31014);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _31015 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _31015 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    _31014 = NOVALUE;
    _tx_63114 = find_from(_old_63110, _31015, 1LL);
    _31015 = NOVALUE;

    /** fwdref.e:250			SymTab[paramsym][S_CODE][tx] = tok*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_paramsym_63107 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_19876))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    else
    _3 = (object)(_12S_CODE_19876 + ((s1_ptr)_2)->base);
    _31017 = NOVALUE;
    Ref(_tok_63092);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _tx_63114);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _tok_63092;
    DeRef(_1);
    _31017 = NOVALUE;

    /** fwdref.e:251			resolved_reference( ref )*/
    _42resolved_reference(_ref_63093);

    /** fwdref.e:252			return*/
    DeRefDS(_defarg_63103);
    DeRefDS(_old_63110);
    DeRef(_tok_63092);
    DeRefDS(_fr_63094);
    DeRef(_code_63149);
    DeRef(_name_63159);
    DeRef(_params_63240);
    DeRef(_orig_code_63242);
    DeRef(_orig_linetable_63243);
    DeRef(_old_fwd_params_63266);
    DeRef(_new_code_63311);
    return;
L1: 
    DeRef(_defarg_63103);
    _defarg_63103 = NOVALUE;
    DeRef(_old_63110);
    _old_63110 = NOVALUE;

    /** fwdref.e:255		integer code_sub = fr[FR_SUBPROG]*/
    _2 = (object)SEQ_PTR(_fr_63094);
    _code_sub_63124 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_code_sub_63124))
    _code_sub_63124 = (object)DBL_PTR(_code_sub_63124)->dbl;

    /** fwdref.e:257		integer args = SymTab[sub][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31020 = (object)*(((s1_ptr)_2)->base + _sub_63097);
    _2 = (object)SEQ_PTR(_31020);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _args_63126 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _args_63126 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    if (!IS_ATOM_INT(_args_63126)){
        _args_63126 = (object)DBL_PTR(_args_63126)->dbl;
    }
    _31020 = NOVALUE;

    /** fwdref.e:258		integer is_func = (SymTab[sub][S_TOKEN] = FUNC) or (SymTab[sub][S_TOKEN] = TYPE)*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31022 = (object)*(((s1_ptr)_2)->base + _sub_63097);
    _2 = (object)SEQ_PTR(_31022);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _31023 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _31023 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _31022 = NOVALUE;
    if (IS_ATOM_INT(_31023)) {
        _31024 = (_31023 == 501LL);
    }
    else {
        _31024 = binary_op(EQUALS, _31023, 501LL);
    }
    _31023 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31025 = (object)*(((s1_ptr)_2)->base + _sub_63097);
    _2 = (object)SEQ_PTR(_31025);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _31026 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _31026 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _31025 = NOVALUE;
    if (IS_ATOM_INT(_31026)) {
        _31027 = (_31026 == 504LL);
    }
    else {
        _31027 = binary_op(EQUALS, _31026, 504LL);
    }
    _31026 = NOVALUE;
    if (IS_ATOM_INT(_31024) && IS_ATOM_INT(_31027)) {
        _is_func_63131 = (_31024 != 0 || _31027 != 0);
    }
    else {
        _is_func_63131 = binary_op(OR, _31024, _31027);
    }
    DeRef(_31024);
    _31024 = NOVALUE;
    DeRef(_31027);
    _31027 = NOVALUE;
    if (!IS_ATOM_INT(_is_func_63131)) {
        _1 = (object)(DBL_PTR(_is_func_63131)->dbl);
        DeRefDS(_is_func_63131);
        _is_func_63131 = _1;
    }

    /** fwdref.e:260		integer real_file = current_file_no*/
    _real_file_63145 = _12current_file_no_20226;

    /** fwdref.e:261		current_file_no = fr[FR_FILE]*/
    _2 = (object)SEQ_PTR(_fr_63094);
    _12current_file_no_20226 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_12current_file_no_20226)){
        _12current_file_no_20226 = (object)DBL_PTR(_12current_file_no_20226)->dbl;
    }

    /** fwdref.e:263		set_code( ref )*/
    _42set_code(_ref_63093);

    /** fwdref.e:264		sequence code = Code*/
    RefDS(_12Code_20315);
    DeRef(_code_63149);
    _code_63149 = _12Code_20315;

    /** fwdref.e:265		integer temp_sub = CurrentSub*/
    _temp_sub_63151 = _12CurrentSub_20234;

    /** fwdref.e:267		integer pc = fr[FR_PC]*/
    _2 = (object)SEQ_PTR(_fr_63094);
    _pc_63153 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (!IS_ATOM_INT(_pc_63153))
    _pc_63153 = (object)DBL_PTR(_pc_63153)->dbl;

    /** fwdref.e:268		integer next_pc = pc*/
    _next_pc_63155 = _pc_63153;

    /** fwdref.e:269		integer supplied_args = code[pc+2]*/
    _31031 = _pc_63153 + 2LL;
    _2 = (object)SEQ_PTR(_code_63149);
    _supplied_args_63156 = (object)*(((s1_ptr)_2)->base + _31031);
    if (!IS_ATOM_INT(_supplied_args_63156))
    _supplied_args_63156 = (object)DBL_PTR(_supplied_args_63156)->dbl;

    /** fwdref.e:270		sequence name = fr[FR_NAME]*/
    DeRef(_name_63159);
    _2 = (object)SEQ_PTR(_fr_63094);
    _name_63159 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_name_63159);

    /** fwdref.e:272		if Code[pc] != FUNC_FORWARD and Code[pc] != PROC_FORWARD then*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    _31034 = (object)*(((s1_ptr)_2)->base + _pc_63153);
    if (IS_ATOM_INT(_31034)) {
        _31035 = (_31034 != 196LL);
    }
    else {
        _31035 = binary_op(NOTEQ, _31034, 196LL);
    }
    _31034 = NOVALUE;
    if (IS_ATOM_INT(_31035)) {
        if (_31035 == 0) {
            goto L2; // [268] 332
        }
    }
    else {
        if (DBL_PTR(_31035)->dbl == 0.0) {
            goto L2; // [268] 332
        }
    }
    _2 = (object)SEQ_PTR(_12Code_20315);
    _31037 = (object)*(((s1_ptr)_2)->base + _pc_63153);
    if (IS_ATOM_INT(_31037)) {
        _31038 = (_31037 != 195LL);
    }
    else {
        _31038 = binary_op(NOTEQ, _31037, 195LL);
    }
    _31037 = NOVALUE;
    if (_31038 == 0) {
        DeRef(_31038);
        _31038 = NOVALUE;
        goto L2; // [285] 332
    }
    else {
        if (!IS_ATOM_INT(_31038) && DBL_PTR(_31038)->dbl == 0.0){
            DeRef(_31038);
            _31038 = NOVALUE;
            goto L2; // [285] 332
        }
        DeRef(_31038);
        _31038 = NOVALUE;
    }
    DeRef(_31038);
    _31038 = NOVALUE;

    /** fwdref.e:273			prep_forward_error( ref )*/
    _42prep_forward_error(_ref_63093);

    /** fwdref.e:274			CompileErr( "The forward call to [4] wasn't where we thought it would be: [1]:[2]:[3]",*/
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _31040 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    _2 = (object)SEQ_PTR(_fr_63094);
    _31041 = (object)*(((s1_ptr)_2)->base + 4LL);
    Ref(_31041);
    _31042 = _53sym_name(_31041);
    _31041 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_63094);
    _31043 = (object)*(((s1_ptr)_2)->base + 6LL);
    _2 = (object)SEQ_PTR(_fr_63094);
    _31044 = (object)*(((s1_ptr)_2)->base + 2LL);
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_31040);
    ((intptr_t*)_2)[1] = _31040;
    ((intptr_t*)_2)[2] = _31042;
    Ref(_31043);
    ((intptr_t*)_2)[3] = _31043;
    Ref(_31044);
    ((intptr_t*)_2)[4] = _31044;
    _31045 = MAKE_SEQ(_1);
    _31044 = NOVALUE;
    _31043 = NOVALUE;
    _31042 = NOVALUE;
    _31040 = NOVALUE;
    RefDS(_31039);
    _49CompileErr(_31039, _31045, 0LL);
    _31045 = NOVALUE;
L2: 

    /** fwdref.e:278		if SymTab[sub][S_DEPRECATED] then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31046 = (object)*(((s1_ptr)_2)->base + _sub_63097);
    _2 = (object)SEQ_PTR(_31046);
    _31047 = (object)*(((s1_ptr)_2)->base + 30LL);
    _31046 = NOVALUE;
    if (_31047 == 0) {
        _31047 = NOVALUE;
        goto L3; // [346] 375
    }
    else {
        if (!IS_ATOM_INT(_31047) && DBL_PTR(_31047)->dbl == 0.0){
            _31047 = NOVALUE;
            goto L3; // [346] 375
        }
        _31047 = NOVALUE;
    }
    _31047 = NOVALUE;

    /** fwdref.e:279			Warning(327, deprecated_warning_flag, { SymTab[sub][S_NAME] })*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31048 = (object)*(((s1_ptr)_2)->base + _sub_63097);
    _2 = (object)SEQ_PTR(_31048);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _31049 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _31049 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _31048 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_31049);
    ((intptr_t*)_2)[1] = _31049;
    _31050 = MAKE_SEQ(_1);
    _31049 = NOVALUE;
    _49Warning(327LL, 16384LL, _31050);
    _31050 = NOVALUE;
L3: 

    /** fwdref.e:282		integer old_temps_allocated = temps_allocated*/
    _old_temps_allocated_63195 = _53temps_allocated_47379;

    /** fwdref.e:283		temps_allocated = 0*/
    _53temps_allocated_47379 = 0LL;

    /** fwdref.e:285		if is_func and fr[FR_OP] = PROC then*/
    if (_is_func_63131 == 0) {
        goto L4; // [393] 481
    }
    _2 = (object)SEQ_PTR(_fr_63094);
    _31052 = (object)*(((s1_ptr)_2)->base + 10LL);
    if (IS_ATOM_INT(_31052)) {
        _31053 = (_31052 == 27LL);
    }
    else {
        _31053 = binary_op(EQUALS, _31052, 27LL);
    }
    _31052 = NOVALUE;
    if (_31053 == 0) {
        DeRef(_31053);
        _31053 = NOVALUE;
        goto L4; // [408] 481
    }
    else {
        if (!IS_ATOM_INT(_31053) && DBL_PTR(_31053)->dbl == 0.0){
            DeRef(_31053);
            _31053 = NOVALUE;
            goto L4; // [408] 481
        }
        DeRef(_31053);
        _31053 = NOVALUE;
    }
    DeRef(_31053);
    _31053 = NOVALUE;

    /** fwdref.e:288			symtab_index temp_target = NewTempSym()*/
    _temp_target_63204 = _53NewTempSym(0LL);
    if (!IS_ATOM_INT(_temp_target_63204)) {
        _1 = (object)(DBL_PTR(_temp_target_63204)->dbl);
        DeRefDS(_temp_target_63204);
        _temp_target_63204 = _1;
    }

    /** fwdref.e:289			sequence converted_code = */
    _31055 = _pc_63153 + 1;
    if (_31055 > MAXINT){
        _31055 = NewDouble((eudouble)_31055);
    }
    _31056 = _pc_63153 + 2LL;
    if ((object)((uintptr_t)_31056 + (uintptr_t)HIGH_BITS) >= 0){
        _31056 = NewDouble((eudouble)_31056);
    }
    if (IS_ATOM_INT(_31056)) {
        _31057 = _31056 + _supplied_args_63156;
    }
    else {
        _31057 = NewDouble(DBL_PTR(_31056)->dbl + (eudouble)_supplied_args_63156);
    }
    DeRef(_31056);
    _31056 = NOVALUE;
    rhs_slice_target = (object_ptr)&_31058;
    RHS_Slice(_12Code_20315, _31055, _31057);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 208LL;
    ((intptr_t *)_2)[2] = _temp_target_63204;
    _31059 = MAKE_SEQ(_1);
    {
        object concat_list[4];

        concat_list[0] = _31059;
        concat_list[1] = _temp_target_63204;
        concat_list[2] = _31058;
        concat_list[3] = 196LL;
        Concat_N((object_ptr)&_converted_code_63207, concat_list, 4);
    }
    DeRefDS(_31059);
    _31059 = NOVALUE;
    DeRefDS(_31058);
    _31058 = NOVALUE;

    /** fwdref.e:295			replace_code( converted_code, pc, pc + 2 + supplied_args, code_sub )*/
    _31061 = _pc_63153 + 2LL;
    if ((object)((uintptr_t)_31061 + (uintptr_t)HIGH_BITS) >= 0){
        _31061 = NewDouble((eudouble)_31061);
    }
    if (IS_ATOM_INT(_31061)) {
        _31062 = _31061 + _supplied_args_63156;
        if ((object)((uintptr_t)_31062 + (uintptr_t)HIGH_BITS) >= 0){
            _31062 = NewDouble((eudouble)_31062);
        }
    }
    else {
        _31062 = NewDouble(DBL_PTR(_31061)->dbl + (eudouble)_supplied_args_63156);
    }
    DeRef(_31061);
    _31061 = NOVALUE;
    RefDS(_converted_code_63207);
    _42replace_code(_converted_code_63207, _pc_63153, _31062, _code_sub_63124);
    _31062 = NOVALUE;

    /** fwdref.e:297			code = Code*/
    RefDS(_12Code_20315);
    DeRef(_code_63149);
    _code_63149 = _12Code_20315;
L4: 
    DeRef(_converted_code_63207);
    _converted_code_63207 = NOVALUE;

    /** fwdref.e:299		next_pc +=*/
    _31063 = 3LL + _supplied_args_63156;
    if ((object)((uintptr_t)_31063 + (uintptr_t)HIGH_BITS) >= 0){
        _31063 = NewDouble((eudouble)_31063);
    }
    if (IS_ATOM_INT(_31063)) {
        _31064 = _31063 + _is_func_63131;
        if ((object)((uintptr_t)_31064 + (uintptr_t)HIGH_BITS) >= 0){
            _31064 = NewDouble((eudouble)_31064);
        }
    }
    else {
        _31064 = NewDouble(DBL_PTR(_31063)->dbl + (eudouble)_is_func_63131);
    }
    DeRef(_31063);
    _31063 = NOVALUE;
    if (IS_ATOM_INT(_31064)) {
        _next_pc_63155 = _next_pc_63155 + _31064;
    }
    else {
        _next_pc_63155 = NewDouble((eudouble)_next_pc_63155 + DBL_PTR(_31064)->dbl);
    }
    DeRef(_31064);
    _31064 = NOVALUE;
    if (!IS_ATOM_INT(_next_pc_63155)) {
        _1 = (object)(DBL_PTR(_next_pc_63155)->dbl);
        DeRefDS(_next_pc_63155);
        _next_pc_63155 = _1;
    }

    /** fwdref.e:303		integer target*/

    /** fwdref.e:304		if is_func then*/
    if (_is_func_63131 == 0)
    {
        goto L5; // [503] 525
    }
    else{
    }

    /** fwdref.e:305			target = Code[pc + 3 + supplied_args]*/
    _31066 = _pc_63153 + 3LL;
    if ((object)((uintptr_t)_31066 + (uintptr_t)HIGH_BITS) >= 0){
        _31066 = NewDouble((eudouble)_31066);
    }
    if (IS_ATOM_INT(_31066)) {
        _31067 = _31066 + _supplied_args_63156;
    }
    else {
        _31067 = NewDouble(DBL_PTR(_31066)->dbl + (eudouble)_supplied_args_63156);
    }
    DeRef(_31066);
    _31066 = NOVALUE;
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!IS_ATOM_INT(_31067)){
        _target_63223 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31067)->dbl));
    }
    else{
        _target_63223 = (object)*(((s1_ptr)_2)->base + _31067);
    }
    if (!IS_ATOM_INT(_target_63223)){
        _target_63223 = (object)DBL_PTR(_target_63223)->dbl;
    }
L5: 

    /** fwdref.e:307		integer has_defaults = 0*/
    _has_defaults_63229 = 0LL;

    /** fwdref.e:308		integer goto_target = length( code ) + 1*/
    if (IS_SEQUENCE(_code_63149)){
            _31069 = SEQ_PTR(_code_63149)->length;
    }
    else {
        _31069 = 1;
    }
    _goto_target_63230 = _31069 + 1;
    _31069 = NOVALUE;

    /** fwdref.e:309		integer defarg = 0*/
    _defarg_63233 = 0LL;

    /** fwdref.e:310		integer code_len = length(code)*/
    if (IS_SEQUENCE(_code_63149)){
            _code_len_63234 = SEQ_PTR(_code_63149)->length;
    }
    else {
        _code_len_63234 = 1;
    }

    /** fwdref.e:312		integer extra_default_args = 0*/
    _extra_default_args_63236 = 0LL;

    /** fwdref.e:313		set_dont_read( 1 )*/
    _61set_dont_read(1LL);

    /** fwdref.e:314		reset_private_lists()*/

    /** fwdref.e:212		fwd_private_sym  = {}*/
    RefDS(_22024);
    DeRefi(_42fwd_private_sym_63054);
    _42fwd_private_sym_63054 = _22024;

    /** fwdref.e:213		fwd_private_name = {}*/
    RefDS(_22024);
    DeRef(_42fwd_private_name_63055);
    _42fwd_private_name_63055 = _22024;

    /** fwdref.e:214	end procedure*/
    goto L6; // [577] 580
L6: 

    /** fwdref.e:315		integer param_sym = sub*/
    _param_sym_63239 = _sub_63097;

    /** fwdref.e:316		sequence params = repeat( 0, args )*/
    DeRef(_params_63240);
    _params_63240 = Repeat(0LL, _args_63126);

    /** fwdref.e:317		sequence orig_code = code*/
    RefDS(_code_63149);
    DeRef(_orig_code_63242);
    _orig_code_63242 = _code_63149;

    /** fwdref.e:318		sequence orig_linetable = LineTable*/
    RefDS(_12LineTable_20316);
    DeRef(_orig_linetable_63243);
    _orig_linetable_63243 = _12LineTable_20316;

    /** fwdref.e:319		LineTable = {}*/
    RefDS(_22024);
    DeRefDS(_12LineTable_20316);
    _12LineTable_20316 = _22024;

    /** fwdref.e:320		Code = {}*/
    RefDS(_22024);
    DeRef(_12Code_20315);
    _12Code_20315 = _22024;

    /** fwdref.e:323		integer ar_sp = find( code_sub, active_subprogs[current_file_no] )*/
    _2 = (object)SEQ_PTR(_42active_subprogs_62865);
    _31073 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    _ar_sp_63247 = find_from(_code_sub_63124, _31073, 1LL);
    _31073 = NOVALUE;

    /** fwdref.e:324		integer pre_refs*/

    /** fwdref.e:326		if code_sub = TopLevelSub then*/
    if (_code_sub_63124 != _12TopLevelSub_20233)
    goto L7; // [644] 664

    /** fwdref.e:327			pre_refs = length( toplevel_references[current_file_no] )*/
    _2 = (object)SEQ_PTR(_42toplevel_references_62867);
    _31076 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    if (IS_SEQUENCE(_31076)){
            _pre_refs_63251 = SEQ_PTR(_31076)->length;
    }
    else {
        _pre_refs_63251 = 1;
    }
    _31076 = NOVALUE;
    goto L8; // [661] 697
L7: 

    /** fwdref.e:329			ar_sp = find( code_sub, active_subprogs[current_file_no] )*/
    _2 = (object)SEQ_PTR(_42active_subprogs_62865);
    _31078 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    _ar_sp_63247 = find_from(_code_sub_63124, _31078, 1LL);
    _31078 = NOVALUE;

    /** fwdref.e:330			pre_refs = length( active_references[current_file_no][ar_sp] )*/
    _2 = (object)SEQ_PTR(_42active_references_62866);
    _31080 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    _2 = (object)SEQ_PTR(_31080);
    _31081 = (object)*(((s1_ptr)_2)->base + _ar_sp_63247);
    _31080 = NOVALUE;
    if (IS_SEQUENCE(_31081)){
            _pre_refs_63251 = SEQ_PTR(_31081)->length;
    }
    else {
        _pre_refs_63251 = 1;
    }
    _31081 = NOVALUE;
L8: 

    /** fwdref.e:333		sequence old_fwd_params = {}*/
    RefDS(_22024);
    DeRef(_old_fwd_params_63266);
    _old_fwd_params_63266 = _22024;

    /** fwdref.e:334		for i = pc + 3 to pc + args + 2 do*/
    _31083 = _pc_63153 + 3LL;
    if ((object)((uintptr_t)_31083 + (uintptr_t)HIGH_BITS) >= 0){
        _31083 = NewDouble((eudouble)_31083);
    }
    _31084 = _pc_63153 + _args_63126;
    if ((object)((uintptr_t)_31084 + (uintptr_t)HIGH_BITS) >= 0){
        _31084 = NewDouble((eudouble)_31084);
    }
    if (IS_ATOM_INT(_31084)) {
        _31085 = _31084 + 2LL;
        if ((object)((uintptr_t)_31085 + (uintptr_t)HIGH_BITS) >= 0){
            _31085 = NewDouble((eudouble)_31085);
        }
    }
    else {
        _31085 = NewDouble(DBL_PTR(_31084)->dbl + (eudouble)2LL);
    }
    DeRef(_31084);
    _31084 = NOVALUE;
    {
        object _i_63268;
        Ref(_31083);
        _i_63268 = _31083;
L9: 
        if (binary_op_a(GREATER, _i_63268, _31085)){
            goto LA; // [718] 879
        }

        /** fwdref.e:335			defarg += 1*/
        _defarg_63233 = _defarg_63233 + 1;

        /** fwdref.e:336			param_sym = SymTab[param_sym][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _31087 = (object)*(((s1_ptr)_2)->base + _param_sym_63239);
        _2 = (object)SEQ_PTR(_31087);
        _param_sym_63239 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_param_sym_63239)){
            _param_sym_63239 = (object)DBL_PTR(_param_sym_63239)->dbl;
        }
        _31087 = NOVALUE;

        /** fwdref.e:337			if defarg > supplied_args or i > length( code ) or not code[i] then*/
        _31089 = (_defarg_63233 > _supplied_args_63156);
        if (_31089 != 0) {
            _31090 = 1;
            goto LB; // [753] 768
        }
        if (IS_SEQUENCE(_code_63149)){
                _31091 = SEQ_PTR(_code_63149)->length;
        }
        else {
            _31091 = 1;
        }
        if (IS_ATOM_INT(_i_63268)) {
            _31092 = (_i_63268 > _31091);
        }
        else {
            _31092 = (DBL_PTR(_i_63268)->dbl > (eudouble)_31091);
        }
        _31091 = NOVALUE;
        _31090 = (_31092 != 0);
LB: 
        if (_31090 != 0) {
            goto LC; // [768] 784
        }
        _2 = (object)SEQ_PTR(_code_63149);
        if (!IS_ATOM_INT(_i_63268)){
            _31094 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63268)->dbl));
        }
        else{
            _31094 = (object)*(((s1_ptr)_2)->base + _i_63268);
        }
        if (IS_ATOM_INT(_31094)) {
            _31095 = (_31094 == 0);
        }
        else {
            _31095 = unary_op(NOT, _31094);
        }
        _31094 = NOVALUE;
        if (_31095 == 0) {
            DeRef(_31095);
            _31095 = NOVALUE;
            goto LD; // [780] 834
        }
        else {
            if (!IS_ATOM_INT(_31095) && DBL_PTR(_31095)->dbl == 0.0){
                DeRef(_31095);
                _31095 = NOVALUE;
                goto LD; // [780] 834
            }
            DeRef(_31095);
            _31095 = NOVALUE;
        }
        DeRef(_31095);
        _31095 = NOVALUE;
LC: 

        /** fwdref.e:339				has_defaults = 1*/
        _has_defaults_63229 = 1LL;

        /** fwdref.e:340				extra_default_args += 1*/
        _extra_default_args_63236 = _extra_default_args_63236 + 1;

        /** fwdref.e:345				show_params( sub )*/
        _53show_params(_sub_63097);

        /** fwdref.e:346				set_error_info( ref )*/
        _42set_error_info(_ref_63093);

        /** fwdref.e:347				Parse_default_arg(sub, defarg, fwd_private_name, fwd_private_sym) --call_proc( parse_arg_rid, { sub, defarg, fwd_private_name, fwd_private_sym } )*/
        RefDS(_42fwd_private_name_63055);
        RefDS(_42fwd_private_sym_63054);
        _43Parse_default_arg(_sub_63097, _defarg_63233, _42fwd_private_name_63055, _42fwd_private_sym_63054);

        /** fwdref.e:348				hide_params( sub )*/
        _53hide_params(_sub_63097);

        /** fwdref.e:349				params[defarg] = Pop()*/
        _31097 = _45Pop();
        _2 = (object)SEQ_PTR(_params_63240);
        _2 = (object)(((s1_ptr)_2)->base + _defarg_63233);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31097;
        if( _1 != _31097 ){
            DeRef(_1);
        }
        _31097 = NOVALUE;
        goto LE; // [831] 872
LD: 

        /** fwdref.e:351				extra_default_args = 0*/
        _extra_default_args_63236 = 0LL;

        /** fwdref.e:352				add_private_symbol( code[i], SymTab[param_sym][S_NAME] )*/
        _2 = (object)SEQ_PTR(_code_63149);
        if (!IS_ATOM_INT(_i_63268)){
            _31098 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63268)->dbl));
        }
        else{
            _31098 = (object)*(((s1_ptr)_2)->base + _i_63268);
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _31099 = (object)*(((s1_ptr)_2)->base + _param_sym_63239);
        _2 = (object)SEQ_PTR(_31099);
        if (!IS_ATOM_INT(_12S_NAME_19864)){
            _31100 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
        }
        else{
            _31100 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
        }
        _31099 = NOVALUE;
        Ref(_31098);
        Ref(_31100);
        _42add_private_symbol(_31098, _31100);
        _31098 = NOVALUE;
        _31100 = NOVALUE;

        /** fwdref.e:353				params[defarg] = code[i]*/
        _2 = (object)SEQ_PTR(_code_63149);
        if (!IS_ATOM_INT(_i_63268)){
            _31101 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63268)->dbl));
        }
        else{
            _31101 = (object)*(((s1_ptr)_2)->base + _i_63268);
        }
        Ref(_31101);
        _2 = (object)SEQ_PTR(_params_63240);
        _2 = (object)(((s1_ptr)_2)->base + _defarg_63233);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31101;
        if( _1 != _31101 ){
            DeRef(_1);
        }
        _31101 = NOVALUE;
LE: 

        /** fwdref.e:355		end for*/
        _0 = _i_63268;
        if (IS_ATOM_INT(_i_63268)) {
            _i_63268 = _i_63268 + 1LL;
            if ((object)((uintptr_t)_i_63268 +(uintptr_t) HIGH_BITS) >= 0){
                _i_63268 = NewDouble((eudouble)_i_63268);
            }
        }
        else {
            _i_63268 = binary_op_a(PLUS, _i_63268, 1LL);
        }
        DeRef(_0);
        goto L9; // [874] 725
LA: 
        ;
        DeRef(_i_63268);
    }

    /** fwdref.e:357		SymTab[code_sub][S_STACK_SPACE] += temps_allocated*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_code_sub_63124 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_12S_STACK_SPACE_19924)){
        _31104 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_STACK_SPACE_19924)->dbl));
    }
    else{
        _31104 = (object)*(((s1_ptr)_2)->base + _12S_STACK_SPACE_19924);
    }
    _31102 = NOVALUE;
    if (IS_ATOM_INT(_31104)) {
        _31105 = _31104 + _53temps_allocated_47379;
        if ((object)((uintptr_t)_31105 + (uintptr_t)HIGH_BITS) >= 0){
            _31105 = NewDouble((eudouble)_31105);
        }
    }
    else {
        _31105 = binary_op(PLUS, _31104, _53temps_allocated_47379);
    }
    _31104 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_STACK_SPACE_19924))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_STACK_SPACE_19924)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_STACK_SPACE_19924);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31105;
    if( _1 != _31105 ){
        DeRef(_1);
    }
    _31105 = NOVALUE;
    _31102 = NOVALUE;

    /** fwdref.e:358		temps_allocated = old_temps_allocated*/
    _53temps_allocated_47379 = _old_temps_allocated_63195;

    /** fwdref.e:363		integer temp_shifting_sub = shifting_sub*/
    _temp_shifting_sub_63307 = _42shifting_sub_62883;

    /** fwdref.e:364		shift( -pc, pc-1 )*/
    if ((uintptr_t)_pc_63153 == (uintptr_t)HIGH_BITS){
        _31106 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31106 = - _pc_63153;
    }
    _31107 = _pc_63153 - 1LL;
    if ((object)((uintptr_t)_31107 +(uintptr_t) HIGH_BITS) >= 0){
        _31107 = NewDouble((eudouble)_31107);
    }
    Ref(_31106);
    DeRef(_31763);
    _31763 = _31106;
    _65shift(_31106, _31107, _31763);
    _31106 = NOVALUE;
    _31107 = NOVALUE;
    _31763 = NOVALUE;

    /** fwdref.e:366		sequence new_code = Code*/
    RefDS(_12Code_20315);
    DeRef(_new_code_63311);
    _new_code_63311 = _12Code_20315;

    /** fwdref.e:367		Code = orig_code*/
    RefDS(_orig_code_63242);
    DeRefDS(_12Code_20315);
    _12Code_20315 = _orig_code_63242;

    /** fwdref.e:368		orig_code = {}*/
    RefDS(_22024);
    DeRefDS(_orig_code_63242);
    _orig_code_63242 = _22024;

    /** fwdref.e:369		LineTable = orig_linetable*/
    RefDS(_orig_linetable_63243);
    DeRef(_12LineTable_20316);
    _12LineTable_20316 = _orig_linetable_63243;

    /** fwdref.e:370		orig_linetable = {}*/
    RefDS(_22024);
    DeRefDS(_orig_linetable_63243);
    _orig_linetable_63243 = _22024;

    /** fwdref.e:371		set_dont_read( 0 )*/
    _61set_dont_read(0LL);

    /** fwdref.e:372		current_file_no = real_file*/
    _12current_file_no_20226 = _real_file_63145;

    /** fwdref.e:374		if args != ( supplied_args + extra_default_args ) then*/
    _31108 = _supplied_args_63156 + _extra_default_args_63236;
    if ((object)((uintptr_t)_31108 + (uintptr_t)HIGH_BITS) >= 0){
        _31108 = NewDouble((eudouble)_31108);
    }
    if (binary_op_a(EQUALS, _args_63126, _31108)){
        DeRef(_31108);
        _31108 = NOVALUE;
        goto LF; // [990] 1070
    }
    DeRef(_31108);
    _31108 = NOVALUE;

    /** fwdref.e:375			sequence routine_type*/

    /** fwdref.e:377			if is_func then */
    if (_is_func_63131 == 0)
    {
        goto L10; // [998] 1011
    }
    else{
    }

    /** fwdref.e:378				routine_type = "function"*/
    RefDS(_26274);
    DeRefi(_routine_type_63320);
    _routine_type_63320 = _26274;
    goto L11; // [1008] 1019
L10: 

    /** fwdref.e:380				routine_type = "procedure"*/
    RefDS(_26328);
    DeRefi(_routine_type_63320);
    _routine_type_63320 = _26328;
L11: 

    /** fwdref.e:382			current_file_no = fr[FR_FILE]*/
    _2 = (object)SEQ_PTR(_fr_63094);
    _12current_file_no_20226 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_12current_file_no_20226)){
        _12current_file_no_20226 = (object)DBL_PTR(_12current_file_no_20226)->dbl;
    }

    /** fwdref.e:383			line_number = fr[FR_LINE]*/
    _2 = (object)SEQ_PTR(_fr_63094);
    _12line_number_20227 = (object)*(((s1_ptr)_2)->base + 6LL);
    if (!IS_ATOM_INT(_12line_number_20227)){
        _12line_number_20227 = (object)DBL_PTR(_12line_number_20227)->dbl;
    }

    /** fwdref.e:384			CompileErr( WRONG_NUMBER_OF_ARGUMENTS_SUPPLIED_FOR_FORWARD_REFERENCET1_2_3_4__EXPECTED_5_BUT_FOUND_6,*/
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _31112 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    _31113 = _supplied_args_63156 + _extra_default_args_63236;
    if ((object)((uintptr_t)_31113 + (uintptr_t)HIGH_BITS) >= 0){
        _31113 = NewDouble((eudouble)_31113);
    }
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_31112);
    ((intptr_t*)_2)[1] = _31112;
    ((intptr_t*)_2)[2] = _12line_number_20227;
    RefDS(_routine_type_63320);
    ((intptr_t*)_2)[3] = _routine_type_63320;
    RefDS(_name_63159);
    ((intptr_t*)_2)[4] = _name_63159;
    ((intptr_t*)_2)[5] = _args_63126;
    ((intptr_t*)_2)[6] = _31113;
    _31114 = MAKE_SEQ(_1);
    _31113 = NOVALUE;
    _31112 = NOVALUE;
    _49CompileErr(158LL, _31114, 0LL);
    _31114 = NOVALUE;
LF: 
    DeRefi(_routine_type_63320);
    _routine_type_63320 = NOVALUE;

    /** fwdref.e:388		new_code &= PROC & sub & params*/
    {
        object concat_list[3];

        concat_list[0] = _params_63240;
        concat_list[1] = _sub_63097;
        concat_list[2] = 27LL;
        Concat_N((object_ptr)&_31115, concat_list, 3);
    }
    Concat((object_ptr)&_new_code_63311, _new_code_63311, _31115);
    DeRefDS(_31115);
    _31115 = NOVALUE;

    /** fwdref.e:389		if is_func then*/
    if (_is_func_63131 == 0)
    {
        goto L12; // [1088] 1100
    }
    else{
    }

    /** fwdref.e:390			new_code &= target*/
    Append(&_new_code_63311, _new_code_63311, _target_63223);
L12: 

    /** fwdref.e:393		replace_code( new_code, pc, next_pc - 1, code_sub )*/
    _31118 = _next_pc_63155 - 1LL;
    if ((object)((uintptr_t)_31118 +(uintptr_t) HIGH_BITS) >= 0){
        _31118 = NewDouble((eudouble)_31118);
    }
    RefDS(_new_code_63311);
    _42replace_code(_new_code_63311, _pc_63153, _31118, _code_sub_63124);
    _31118 = NOVALUE;

    /** fwdref.e:395		if code_sub = TopLevelSub then*/
    if (_code_sub_63124 != _12TopLevelSub_20233)
    goto L13; // [1116] 1197

    /** fwdref.e:396			for i = pre_refs + 1 to length( toplevel_references[fr[FR_FILE]] ) do*/
    _31120 = _pre_refs_63251 + 1;
    if (_31120 > MAXINT){
        _31120 = NewDouble((eudouble)_31120);
    }
    _2 = (object)SEQ_PTR(_fr_63094);
    _31121 = (object)*(((s1_ptr)_2)->base + 3LL);
    _2 = (object)SEQ_PTR(_42toplevel_references_62867);
    if (!IS_ATOM_INT(_31121)){
        _31122 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31121)->dbl));
    }
    else{
        _31122 = (object)*(((s1_ptr)_2)->base + _31121);
    }
    if (IS_SEQUENCE(_31122)){
            _31123 = SEQ_PTR(_31122)->length;
    }
    else {
        _31123 = 1;
    }
    _31122 = NOVALUE;
    {
        object _i_63345;
        Ref(_31120);
        _i_63345 = _31120;
L14: 
        if (binary_op_a(GREATER, _i_63345, _31123)){
            goto L15; // [1141] 1194
        }

        /** fwdref.e:397				forward_references[toplevel_references[fr[FR_FILE]][i]][FR_PC] += pc - 1*/
        _2 = (object)SEQ_PTR(_fr_63094);
        _31124 = (object)*(((s1_ptr)_2)->base + 3LL);
        _2 = (object)SEQ_PTR(_42toplevel_references_62867);
        if (!IS_ATOM_INT(_31124)){
            _31125 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31124)->dbl));
        }
        else{
            _31125 = (object)*(((s1_ptr)_2)->base + _31124);
        }
        _2 = (object)SEQ_PTR(_31125);
        if (!IS_ATOM_INT(_i_63345)){
            _31126 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63345)->dbl));
        }
        else{
            _31126 = (object)*(((s1_ptr)_2)->base + _i_63345);
        }
        _31125 = NOVALUE;
        _2 = (object)SEQ_PTR(_42forward_references_62864);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _42forward_references_62864 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31126))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31126)->dbl));
        else
        _3 = (object)(_31126 + ((s1_ptr)_2)->base);
        _31129 = _pc_63153 - 1LL;
        if ((object)((uintptr_t)_31129 +(uintptr_t) HIGH_BITS) >= 0){
            _31129 = NewDouble((eudouble)_31129);
        }
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _31130 = (object)*(((s1_ptr)_2)->base + 5LL);
        _31127 = NOVALUE;
        if (IS_ATOM_INT(_31130) && IS_ATOM_INT(_31129)) {
            _31131 = _31130 + _31129;
            if ((object)((uintptr_t)_31131 + (uintptr_t)HIGH_BITS) >= 0){
                _31131 = NewDouble((eudouble)_31131);
            }
        }
        else {
            _31131 = binary_op(PLUS, _31130, _31129);
        }
        _31130 = NOVALUE;
        DeRef(_31129);
        _31129 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31131;
        if( _1 != _31131 ){
            DeRef(_1);
        }
        _31131 = NOVALUE;
        _31127 = NOVALUE;

        /** fwdref.e:398			end for*/
        _0 = _i_63345;
        if (IS_ATOM_INT(_i_63345)) {
            _i_63345 = _i_63345 + 1LL;
            if ((object)((uintptr_t)_i_63345 +(uintptr_t) HIGH_BITS) >= 0){
                _i_63345 = NewDouble((eudouble)_i_63345);
            }
        }
        else {
            _i_63345 = binary_op_a(PLUS, _i_63345, 1LL);
        }
        DeRef(_0);
        goto L14; // [1189] 1148
L15: 
        ;
        DeRef(_i_63345);
    }
    goto L16; // [1194] 1280
L13: 

    /** fwdref.e:400			for i = pre_refs + 1 to length( active_references[fr[FR_FILE]][ar_sp] ) do*/
    _31132 = _pre_refs_63251 + 1;
    if (_31132 > MAXINT){
        _31132 = NewDouble((eudouble)_31132);
    }
    _2 = (object)SEQ_PTR(_fr_63094);
    _31133 = (object)*(((s1_ptr)_2)->base + 3LL);
    _2 = (object)SEQ_PTR(_42active_references_62866);
    if (!IS_ATOM_INT(_31133)){
        _31134 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31133)->dbl));
    }
    else{
        _31134 = (object)*(((s1_ptr)_2)->base + _31133);
    }
    _2 = (object)SEQ_PTR(_31134);
    _31135 = (object)*(((s1_ptr)_2)->base + _ar_sp_63247);
    _31134 = NOVALUE;
    if (IS_SEQUENCE(_31135)){
            _31136 = SEQ_PTR(_31135)->length;
    }
    else {
        _31136 = 1;
    }
    _31135 = NOVALUE;
    {
        object _i_63360;
        Ref(_31132);
        _i_63360 = _31132;
L17: 
        if (binary_op_a(GREATER, _i_63360, _31136)){
            goto L18; // [1222] 1279
        }

        /** fwdref.e:401				forward_references[active_references[fr[FR_FILE]][ar_sp][i]][FR_PC] += pc - 1*/
        _2 = (object)SEQ_PTR(_fr_63094);
        _31137 = (object)*(((s1_ptr)_2)->base + 3LL);
        _2 = (object)SEQ_PTR(_42active_references_62866);
        if (!IS_ATOM_INT(_31137)){
            _31138 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31137)->dbl));
        }
        else{
            _31138 = (object)*(((s1_ptr)_2)->base + _31137);
        }
        _2 = (object)SEQ_PTR(_31138);
        _31139 = (object)*(((s1_ptr)_2)->base + _ar_sp_63247);
        _31138 = NOVALUE;
        _2 = (object)SEQ_PTR(_31139);
        if (!IS_ATOM_INT(_i_63360)){
            _31140 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63360)->dbl));
        }
        else{
            _31140 = (object)*(((s1_ptr)_2)->base + _i_63360);
        }
        _31139 = NOVALUE;
        _2 = (object)SEQ_PTR(_42forward_references_62864);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _42forward_references_62864 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31140))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31140)->dbl));
        else
        _3 = (object)(_31140 + ((s1_ptr)_2)->base);
        _31143 = _pc_63153 - 1LL;
        if ((object)((uintptr_t)_31143 +(uintptr_t) HIGH_BITS) >= 0){
            _31143 = NewDouble((eudouble)_31143);
        }
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _31144 = (object)*(((s1_ptr)_2)->base + 5LL);
        _31141 = NOVALUE;
        if (IS_ATOM_INT(_31144) && IS_ATOM_INT(_31143)) {
            _31145 = _31144 + _31143;
            if ((object)((uintptr_t)_31145 + (uintptr_t)HIGH_BITS) >= 0){
                _31145 = NewDouble((eudouble)_31145);
            }
        }
        else {
            _31145 = binary_op(PLUS, _31144, _31143);
        }
        _31144 = NOVALUE;
        DeRef(_31143);
        _31143 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31145;
        if( _1 != _31145 ){
            DeRef(_1);
        }
        _31145 = NOVALUE;
        _31141 = NOVALUE;

        /** fwdref.e:402			end for*/
        _0 = _i_63360;
        if (IS_ATOM_INT(_i_63360)) {
            _i_63360 = _i_63360 + 1LL;
            if ((object)((uintptr_t)_i_63360 +(uintptr_t) HIGH_BITS) >= 0){
                _i_63360 = NewDouble((eudouble)_i_63360);
            }
        }
        else {
            _i_63360 = binary_op_a(PLUS, _i_63360, 1LL);
        }
        DeRef(_0);
        goto L17; // [1274] 1229
L18: 
        ;
        DeRef(_i_63360);
    }
L16: 

    /** fwdref.e:405		reset_code()*/
    _42reset_code();

    /** fwdref.e:408		resolved_reference( ref )*/
    _42resolved_reference(_ref_63093);

    /** fwdref.e:409	end procedure*/
    DeRef(_tok_63092);
    DeRef(_fr_63094);
    DeRef(_code_63149);
    DeRef(_name_63159);
    DeRef(_params_63240);
    DeRef(_orig_code_63242);
    DeRef(_orig_linetable_63243);
    DeRef(_old_fwd_params_63266);
    DeRef(_new_code_63311);
    _31081 = NOVALUE;
    _31137 = NOVALUE;
    _31140 = NOVALUE;
    _31135 = NOVALUE;
    _31126 = NOVALUE;
    DeRef(_31067);
    _31067 = NOVALUE;
    _31133 = NOVALUE;
    DeRef(_31085);
    _31085 = NOVALUE;
    DeRef(_31092);
    _31092 = NOVALUE;
    _31121 = NOVALUE;
    DeRef(_31035);
    _31035 = NOVALUE;
    DeRef(_31132);
    _31132 = NOVALUE;
    DeRef(_31055);
    _31055 = NOVALUE;
    _31076 = NOVALUE;
    DeRef(_31057);
    _31057 = NOVALUE;
    _31122 = NOVALUE;
    DeRef(_31031);
    _31031 = NOVALUE;
    DeRef(_31120);
    _31120 = NOVALUE;
    DeRef(_31083);
    _31083 = NOVALUE;
    _31124 = NOVALUE;
    DeRef(_31089);
    _31089 = NOVALUE;
    return;
    ;
}


void _42set_error_info(object _ref_63377)
{
    object _fr_63378 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:412		sequence fr = forward_references[ref]*/
    DeRef(_fr_63378);
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    _fr_63378 = (object)*(((s1_ptr)_2)->base + _ref_63377);
    Ref(_fr_63378);

    /** fwdref.e:413		ThisLine        = fr[FR_THISLINE]*/
    DeRef(_49ThisLine_49312);
    _2 = (object)SEQ_PTR(_fr_63378);
    _49ThisLine_49312 = (object)*(((s1_ptr)_2)->base + 7LL);
    Ref(_49ThisLine_49312);

    /** fwdref.e:414		bp              = fr[FR_BP]*/
    _2 = (object)SEQ_PTR(_fr_63378);
    _49bp_49316 = (object)*(((s1_ptr)_2)->base + 8LL);
    if (!IS_ATOM_INT(_49bp_49316)){
        _49bp_49316 = (object)DBL_PTR(_49bp_49316)->dbl;
    }

    /** fwdref.e:415		line_number     = fr[FR_LINE]*/
    _2 = (object)SEQ_PTR(_fr_63378);
    _12line_number_20227 = (object)*(((s1_ptr)_2)->base + 6LL);
    if (!IS_ATOM_INT(_12line_number_20227)){
        _12line_number_20227 = (object)DBL_PTR(_12line_number_20227)->dbl;
    }

    /** fwdref.e:416		current_file_no = fr[FR_FILE]*/
    _2 = (object)SEQ_PTR(_fr_63378);
    _12current_file_no_20226 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_12current_file_no_20226)){
        _12current_file_no_20226 = (object)DBL_PTR(_12current_file_no_20226)->dbl;
    }

    /** fwdref.e:417	end procedure*/
    DeRefDS(_fr_63378);
    return;
    ;
}


void _42patch_forward_variable(object _tok_63391, object _ref_63392)
{
    object _fr_63393 = NOVALUE;
    object _sym_63396 = NOVALUE;
    object _pc_63449 = NOVALUE;
    object _vx_63453 = NOVALUE;
    object _d_63470 = NOVALUE;
    object _param_63480 = NOVALUE;
    object _old_63483 = NOVALUE;
    object _new_63488 = NOVALUE;
    object _31202 = NOVALUE;
    object _31201 = NOVALUE;
    object _31200 = NOVALUE;
    object _31198 = NOVALUE;
    object _31195 = NOVALUE;
    object _31193 = NOVALUE;
    object _31192 = NOVALUE;
    object _31191 = NOVALUE;
    object _31190 = NOVALUE;
    object _31188 = NOVALUE;
    object _31187 = NOVALUE;
    object _31186 = NOVALUE;
    object _31185 = NOVALUE;
    object _31184 = NOVALUE;
    object _31182 = NOVALUE;
    object _31180 = NOVALUE;
    object _31177 = NOVALUE;
    object _31176 = NOVALUE;
    object _31175 = NOVALUE;
    object _31173 = NOVALUE;
    object _31172 = NOVALUE;
    object _31171 = NOVALUE;
    object _31170 = NOVALUE;
    object _31168 = NOVALUE;
    object _31166 = NOVALUE;
    object _31165 = NOVALUE;
    object _31164 = NOVALUE;
    object _31163 = NOVALUE;
    object _31162 = NOVALUE;
    object _31161 = NOVALUE;
    object _31160 = NOVALUE;
    object _31159 = NOVALUE;
    object _31158 = NOVALUE;
    object _31157 = NOVALUE;
    object _31156 = NOVALUE;
    object _31155 = NOVALUE;
    object _31154 = NOVALUE;
    object _31153 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:421		sequence fr = forward_references[ref]*/
    DeRef(_fr_63393);
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    _fr_63393 = (object)*(((s1_ptr)_2)->base + _ref_63392);
    Ref(_fr_63393);

    /** fwdref.e:422		symtab_index sym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63391);
    _sym_63396 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_sym_63396)){
        _sym_63396 = (object)DBL_PTR(_sym_63396)->dbl;
    }

    /** fwdref.e:424		if SymTab[sym][S_FILE_NO] = fr[FR_FILE] */
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31153 = (object)*(((s1_ptr)_2)->base + _sym_63396);
    _2 = (object)SEQ_PTR(_31153);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _31154 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _31154 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _31153 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_63393);
    _31155 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (IS_ATOM_INT(_31154) && IS_ATOM_INT(_31155)) {
        _31156 = (_31154 == _31155);
    }
    else {
        _31156 = binary_op(EQUALS, _31154, _31155);
    }
    _31154 = NOVALUE;
    _31155 = NOVALUE;
    if (IS_ATOM_INT(_31156)) {
        if (_31156 == 0) {
            goto L1; // [45] 69
        }
    }
    else {
        if (DBL_PTR(_31156)->dbl == 0.0) {
            goto L1; // [45] 69
        }
    }
    _2 = (object)SEQ_PTR(_fr_63393);
    _31158 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_31158)) {
        _31159 = (_31158 == _12TopLevelSub_20233);
    }
    else {
        _31159 = binary_op(EQUALS, _31158, _12TopLevelSub_20233);
    }
    _31158 = NOVALUE;
    if (_31159 == 0) {
        DeRef(_31159);
        _31159 = NOVALUE;
        goto L1; // [60] 69
    }
    else {
        if (!IS_ATOM_INT(_31159) && DBL_PTR(_31159)->dbl == 0.0){
            DeRef(_31159);
            _31159 = NOVALUE;
            goto L1; // [60] 69
        }
        DeRef(_31159);
        _31159 = NOVALUE;
    }
    DeRef(_31159);
    _31159 = NOVALUE;

    /** fwdref.e:426			return*/
    DeRef(_tok_63391);
    DeRef(_fr_63393);
    DeRef(_31156);
    _31156 = NOVALUE;
    return;
L1: 

    /** fwdref.e:429		if fr[FR_OP] = ASSIGN and SymTab[sym][S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_fr_63393);
    _31160 = (object)*(((s1_ptr)_2)->base + 10LL);
    if (IS_ATOM_INT(_31160)) {
        _31161 = (_31160 == 18LL);
    }
    else {
        _31161 = binary_op(EQUALS, _31160, 18LL);
    }
    _31160 = NOVALUE;
    if (IS_ATOM_INT(_31161)) {
        if (_31161 == 0) {
            goto L2; // [81] 122
        }
    }
    else {
        if (DBL_PTR(_31161)->dbl == 0.0) {
            goto L2; // [81] 122
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31163 = (object)*(((s1_ptr)_2)->base + _sym_63396);
    _2 = (object)SEQ_PTR(_31163);
    _31164 = (object)*(((s1_ptr)_2)->base + 3LL);
    _31163 = NOVALUE;
    if (IS_ATOM_INT(_31164)) {
        _31165 = (_31164 == 2LL);
    }
    else {
        _31165 = binary_op(EQUALS, _31164, 2LL);
    }
    _31164 = NOVALUE;
    if (_31165 == 0) {
        DeRef(_31165);
        _31165 = NOVALUE;
        goto L2; // [104] 122
    }
    else {
        if (!IS_ATOM_INT(_31165) && DBL_PTR(_31165)->dbl == 0.0){
            DeRef(_31165);
            _31165 = NOVALUE;
            goto L2; // [104] 122
        }
        DeRef(_31165);
        _31165 = NOVALUE;
    }
    DeRef(_31165);
    _31165 = NOVALUE;

    /** fwdref.e:430			prep_forward_error( ref )*/
    _42prep_forward_error(_ref_63392);

    /** fwdref.e:431			CompileErr( MAY_NOT_CHANGE_THE_VALUE_OF_A_CONSTANT)*/
    RefDS(_22024);
    _49CompileErr(110LL, _22024, 0LL);
L2: 

    /** fwdref.e:434		if fr[FR_OP] = ASSIGN then*/
    _2 = (object)SEQ_PTR(_fr_63393);
    _31166 = (object)*(((s1_ptr)_2)->base + 10LL);
    if (binary_op_a(NOTEQ, _31166, 18LL)){
        _31166 = NOVALUE;
        goto L3; // [130] 170
    }
    _31166 = NOVALUE;

    /** fwdref.e:435			SymTab[sym][S_USAGE] = or_bits( U_WRITTEN, SymTab[sym][S_USAGE] )*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_63396 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31170 = (object)*(((s1_ptr)_2)->base + _sym_63396);
    _2 = (object)SEQ_PTR(_31170);
    _31171 = (object)*(((s1_ptr)_2)->base + 5LL);
    _31170 = NOVALUE;
    if (IS_ATOM_INT(_31171)) {
        {uintptr_t tu;
             tu = (uintptr_t)2LL | (uintptr_t)_31171;
             _31172 = MAKE_UINT(tu);
        }
    }
    else {
        _31172 = binary_op(OR_BITS, 2LL, _31171);
    }
    _31171 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31172;
    if( _1 != _31172 ){
        DeRef(_1);
    }
    _31172 = NOVALUE;
    _31168 = NOVALUE;
    goto L4; // [167] 204
L3: 

    /** fwdref.e:437			SymTab[sym][S_USAGE] = or_bits( U_READ, SymTab[sym][S_USAGE] )*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_63396 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31175 = (object)*(((s1_ptr)_2)->base + _sym_63396);
    _2 = (object)SEQ_PTR(_31175);
    _31176 = (object)*(((s1_ptr)_2)->base + 5LL);
    _31175 = NOVALUE;
    if (IS_ATOM_INT(_31176)) {
        {uintptr_t tu;
             tu = (uintptr_t)1LL | (uintptr_t)_31176;
             _31177 = MAKE_UINT(tu);
        }
    }
    else {
        _31177 = binary_op(OR_BITS, 1LL, _31176);
    }
    _31176 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31177;
    if( _1 != _31177 ){
        DeRef(_1);
    }
    _31177 = NOVALUE;
    _31173 = NOVALUE;
L4: 

    /** fwdref.e:440		set_code( ref )*/
    _42set_code(_ref_63392);

    /** fwdref.e:441		integer pc = fr[FR_PC]*/
    _2 = (object)SEQ_PTR(_fr_63393);
    _pc_63449 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (!IS_ATOM_INT(_pc_63449))
    _pc_63449 = (object)DBL_PTR(_pc_63449)->dbl;

    /** fwdref.e:442		if pc < 1 then*/
    if (_pc_63449 >= 1LL)
    goto L5; // [217] 227

    /** fwdref.e:443			pc = 1*/
    _pc_63449 = 1LL;
L5: 

    /** fwdref.e:445		integer vx = find( -ref, Code, pc )*/
    if ((uintptr_t)_ref_63392 == (uintptr_t)HIGH_BITS){
        _31180 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31180 = - _ref_63392;
    }
    _vx_63453 = find_from(_31180, _12Code_20315, _pc_63449);
    DeRef(_31180);
    _31180 = NOVALUE;

    /** fwdref.e:446		if vx then*/
    if (_vx_63453 == 0)
    {
        goto L6; // [241] 283
    }
    else{
    }

    /** fwdref.e:447			while vx do*/
L7: 
    if (_vx_63453 == 0)
    {
        goto L8; // [249] 277
    }
    else{
    }

    /** fwdref.e:450				Code[vx] = sym*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _vx_63453);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_63396;
    DeRef(_1);

    /** fwdref.e:451				vx = find( -ref, Code, vx )*/
    if ((uintptr_t)_ref_63392 == (uintptr_t)HIGH_BITS){
        _31182 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31182 = - _ref_63392;
    }
    _vx_63453 = find_from(_31182, _12Code_20315, _vx_63453);
    DeRef(_31182);
    _31182 = NOVALUE;

    /** fwdref.e:452			end while*/
    goto L7; // [274] 249
L8: 

    /** fwdref.e:453			resolved_reference( ref )*/
    _42resolved_reference(_ref_63392);
L6: 

    /** fwdref.e:456		if sequence( fr[FR_DATA] ) then*/
    _2 = (object)SEQ_PTR(_fr_63393);
    _31184 = (object)*(((s1_ptr)_2)->base + 12LL);
    _31185 = IS_SEQUENCE(_31184);
    _31184 = NOVALUE;
    if (_31185 == 0)
    {
        _31185 = NOVALUE;
        goto L9; // [292] 424
    }
    else{
        _31185 = NOVALUE;
    }

    /** fwdref.e:457			for i = 1 to length( fr[FR_DATA] ) do*/
    _2 = (object)SEQ_PTR(_fr_63393);
    _31186 = (object)*(((s1_ptr)_2)->base + 12LL);
    if (IS_SEQUENCE(_31186)){
            _31187 = SEQ_PTR(_31186)->length;
    }
    else {
        _31187 = 1;
    }
    _31186 = NOVALUE;
    {
        object _i_63467;
        _i_63467 = 1LL;
LA: 
        if (_i_63467 > _31187){
            goto LB; // [304] 418
        }

        /** fwdref.e:458				object d = fr[FR_DATA][i]*/
        _2 = (object)SEQ_PTR(_fr_63393);
        _31188 = (object)*(((s1_ptr)_2)->base + 12LL);
        DeRef(_d_63470);
        _2 = (object)SEQ_PTR(_31188);
        _d_63470 = (object)*(((s1_ptr)_2)->base + _i_63467);
        Ref(_d_63470);
        _31188 = NOVALUE;

        /** fwdref.e:459				if sequence( d ) and d[1] = PAM_RECORD then*/
        _31190 = IS_SEQUENCE(_d_63470);
        if (_31190 == 0) {
            goto LC; // [326] 407
        }
        _2 = (object)SEQ_PTR(_d_63470);
        _31192 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_31192)) {
            _31193 = (_31192 == 1LL);
        }
        else {
            _31193 = binary_op(EQUALS, _31192, 1LL);
        }
        _31192 = NOVALUE;
        if (_31193 == 0) {
            DeRef(_31193);
            _31193 = NOVALUE;
            goto LC; // [341] 407
        }
        else {
            if (!IS_ATOM_INT(_31193) && DBL_PTR(_31193)->dbl == 0.0){
                DeRef(_31193);
                _31193 = NOVALUE;
                goto LC; // [341] 407
            }
            DeRef(_31193);
            _31193 = NOVALUE;
        }
        DeRef(_31193);
        _31193 = NOVALUE;

        /** fwdref.e:461					symtab_index param = d[2]*/
        _2 = (object)SEQ_PTR(_d_63470);
        _param_63480 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_param_63480)){
            _param_63480 = (object)DBL_PTR(_param_63480)->dbl;
        }

        /** fwdref.e:462					token old = {RECORDED, d[3]}*/
        _2 = (object)SEQ_PTR(_d_63470);
        _31195 = (object)*(((s1_ptr)_2)->base + 3LL);
        Ref(_31195);
        DeRef(_old_63483);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 508LL;
        ((intptr_t *)_2)[2] = _31195;
        _old_63483 = MAKE_SEQ(_1);
        _31195 = NOVALUE;

        /** fwdref.e:463					token new = {VARIABLE, sym}*/
        DeRefi(_new_63488);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -100LL;
        ((intptr_t *)_2)[2] = _sym_63396;
        _new_63488 = MAKE_SEQ(_1);

        /** fwdref.e:464					SymTab[param][S_CODE] = find_replace( old, SymTab[param][S_CODE], new )*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_param_63480 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _31200 = (object)*(((s1_ptr)_2)->base + _param_63480);
        _2 = (object)SEQ_PTR(_31200);
        if (!IS_ATOM_INT(_12S_CODE_19876)){
            _31201 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
        }
        else{
            _31201 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
        }
        _31200 = NOVALUE;
        RefDS(_old_63483);
        Ref(_31201);
        RefDS(_new_63488);
        _31202 = _20find_replace(_old_63483, _31201, _new_63488, 0LL);
        _31201 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_12S_CODE_19876))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31202;
        if( _1 != _31202 ){
            DeRef(_1);
        }
        _31202 = NOVALUE;
        _31198 = NOVALUE;
LC: 
        DeRef(_old_63483);
        _old_63483 = NOVALUE;
        DeRefi(_new_63488);
        _new_63488 = NOVALUE;
        DeRef(_d_63470);
        _d_63470 = NOVALUE;

        /** fwdref.e:466			end for*/
        _i_63467 = _i_63467 + 1LL;
        goto LA; // [413] 311
LB: 
        ;
    }

    /** fwdref.e:467			resolved_reference( ref )*/
    _42resolved_reference(_ref_63392);
L9: 

    /** fwdref.e:469		reset_code()*/
    _42reset_code();

    /** fwdref.e:470	end procedure*/
    DeRef(_tok_63391);
    DeRef(_fr_63393);
    DeRef(_31156);
    _31156 = NOVALUE;
    DeRef(_31161);
    _31161 = NOVALUE;
    _31186 = NOVALUE;
    return;
    ;
}


void _42patch_forward_init_check(object _tok_63504, object _ref_63505)
{
    object _fr_63506 = NOVALUE;
    object _31210 = NOVALUE;
    object _31209 = NOVALUE;
    object _31208 = NOVALUE;
    object _31206 = NOVALUE;
    object _31205 = NOVALUE;
    object _31204 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:474		sequence fr = forward_references[ref]*/
    DeRef(_fr_63506);
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    _fr_63506 = (object)*(((s1_ptr)_2)->base + _ref_63505);
    Ref(_fr_63506);

    /** fwdref.e:475		set_code( ref )*/
    _42set_code(_ref_63505);

    /** fwdref.e:476		if sequence( fr[FR_DATA] ) then*/
    _2 = (object)SEQ_PTR(_fr_63506);
    _31204 = (object)*(((s1_ptr)_2)->base + 12LL);
    _31205 = IS_SEQUENCE(_31204);
    _31204 = NOVALUE;
    if (_31205 == 0)
    {
        _31205 = NOVALUE;
        goto L1; // [27] 38
    }
    else{
        _31205 = NOVALUE;
    }

    /** fwdref.e:478			resolved_reference( ref )*/
    _42resolved_reference(_ref_63505);
    goto L2; // [35] 85
L1: 

    /** fwdref.e:479		elsif fr[FR_PC] > 0 then*/
    _2 = (object)SEQ_PTR(_fr_63506);
    _31206 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (binary_op_a(LESSEQ, _31206, 0LL)){
        _31206 = NOVALUE;
        goto L3; // [44] 78
    }
    _31206 = NOVALUE;

    /** fwdref.e:480			Code[fr[FR_PC]+1] = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_fr_63506);
    _31208 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (IS_ATOM_INT(_31208)) {
        _31209 = _31208 + 1;
        if (_31209 > MAXINT){
            _31209 = NewDouble((eudouble)_31209);
        }
    }
    else
    _31209 = binary_op(PLUS, 1, _31208);
    _31208 = NOVALUE;
    _2 = (object)SEQ_PTR(_tok_63504);
    _31210 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_31210);
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_31209))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31209)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _31209);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31210;
    if( _1 != _31210 ){
        DeRef(_1);
    }
    _31210 = NOVALUE;

    /** fwdref.e:481			resolved_reference( ref )*/
    _42resolved_reference(_ref_63505);
    goto L2; // [75] 85
L3: 

    /** fwdref.e:483			forward_error( tok, ref )*/
    Ref(_tok_63504);
    _42forward_error(_tok_63504, _ref_63505);
L2: 

    /** fwdref.e:485		reset_code()*/
    _42reset_code();

    /** fwdref.e:486	end procedure*/
    DeRef(_tok_63504);
    DeRef(_fr_63506);
    DeRef(_31209);
    _31209 = NOVALUE;
    return;
    ;
}


object _42expected_name(object _id_63523)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_63523)) {
        _1 = (object)(DBL_PTR(_id_63523)->dbl);
        DeRefDS(_id_63523);
        _id_63523 = _1;
    }

    /** fwdref.e:491		switch id with fallthru do*/
    _0 = _id_63523;
    switch ( _0 ){ 

        /** fwdref.e:492			case PROC then*/
        case 27:
        case 195:

        /** fwdref.e:494				return "a procedure"*/
        RefDS(_26326);
        return _26326;

        /** fwdref.e:496			case FUNC then*/
        case 501:
        case 196:

        /** fwdref.e:498				return "a function"*/
        RefDS(_26272);
        return _26272;

        /** fwdref.e:500			case VARIABLE then*/
        case -100:

        /** fwdref.e:501				return "a variable, constant or enum"*/
        RefDS(_31213);
        return _31213;

        /** fwdref.e:502			case else*/
        default:

        /** fwdref.e:503				return "something"*/
        RefDS(_31214);
        return _31214;
    ;}    ;
}


void _42patch_forward_type(object _tok_63540, object _ref_63541)
{
    object _fr_63542 = NOVALUE;
    object _syms_63544 = NOVALUE;
    object _31226 = NOVALUE;
    object _31225 = NOVALUE;
    object _31223 = NOVALUE;
    object _31222 = NOVALUE;
    object _31221 = NOVALUE;
    object _31219 = NOVALUE;
    object _31218 = NOVALUE;
    object _31217 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:510		sequence fr = forward_references[ref]*/
    DeRef(_fr_63542);
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    _fr_63542 = (object)*(((s1_ptr)_2)->base + _ref_63541);
    Ref(_fr_63542);

    /** fwdref.e:511		sequence syms = fr[FR_DATA]*/
    DeRef(_syms_63544);
    _2 = (object)SEQ_PTR(_fr_63542);
    _syms_63544 = (object)*(((s1_ptr)_2)->base + 12LL);
    Ref(_syms_63544);

    /** fwdref.e:512		for i = 2 to length( syms ) do*/
    if (IS_SEQUENCE(_syms_63544)){
            _31217 = SEQ_PTR(_syms_63544)->length;
    }
    else {
        _31217 = 1;
    }
    {
        object _i_63547;
        _i_63547 = 2LL;
L1: 
        if (_i_63547 > _31217){
            goto L2; // [26] 102
        }

        /** fwdref.e:513			SymTab[syms[i]][S_VTYPE] = tok[T_SYM]*/
        _2 = (object)SEQ_PTR(_syms_63544);
        _31218 = (object)*(((s1_ptr)_2)->base + _i_63547);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31218))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31218)->dbl));
        else
        _3 = (object)(_31218 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_tok_63540);
        _31221 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_31221);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 15LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31221;
        if( _1 != _31221 ){
            DeRef(_1);
        }
        _31221 = NOVALUE;
        _31219 = NOVALUE;

        /** fwdref.e:514			if TRANSLATE then*/
        if (_12TRANSLATE_19834 == 0)
        {
            goto L3; // [62] 95
        }
        else{
        }

        /** fwdref.e:515				SymTab[syms[i]][S_GTYPE] = CompileType(tok[T_SYM])*/
        _2 = (object)SEQ_PTR(_syms_63544);
        _31222 = (object)*(((s1_ptr)_2)->base + _i_63547);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31222))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31222)->dbl));
        else
        _3 = (object)(_31222 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_tok_63540);
        _31225 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_31225);
        _31226 = _43CompileType(_31225);
        _31225 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 36LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31226;
        if( _1 != _31226 ){
            DeRef(_1);
        }
        _31226 = NOVALUE;
        _31223 = NOVALUE;
L3: 

        /** fwdref.e:517		end for*/
        _i_63547 = _i_63547 + 1LL;
        goto L1; // [97] 33
L2: 
        ;
    }

    /** fwdref.e:518		resolved_reference( ref )*/
    _42resolved_reference(_ref_63541);

    /** fwdref.e:519	end procedure*/
    DeRef(_tok_63540);
    DeRef(_fr_63542);
    DeRef(_syms_63544);
    _31222 = NOVALUE;
    _31218 = NOVALUE;
    return;
    ;
}


void _42patch_forward_case(object _tok_63570, object _ref_63571)
{
    object _fr_63572 = NOVALUE;
    object _switch_pc_63574 = NOVALUE;
    object _case_sym_63577 = NOVALUE;
    object _case_values_63606 = NOVALUE;
    object _cx_63611 = NOVALUE;
    object _negative_63619 = NOVALUE;
    object _31264 = NOVALUE;
    object _31263 = NOVALUE;
    object _31262 = NOVALUE;
    object _31261 = NOVALUE;
    object _31260 = NOVALUE;
    object _31259 = NOVALUE;
    object _31257 = NOVALUE;
    object _31255 = NOVALUE;
    object _31254 = NOVALUE;
    object _31252 = NOVALUE;
    object _31251 = NOVALUE;
    object _31248 = NOVALUE;
    object _31246 = NOVALUE;
    object _31245 = NOVALUE;
    object _31244 = NOVALUE;
    object _31243 = NOVALUE;
    object _31242 = NOVALUE;
    object _31241 = NOVALUE;
    object _31240 = NOVALUE;
    object _31239 = NOVALUE;
    object _31238 = NOVALUE;
    object _31236 = NOVALUE;
    object _31235 = NOVALUE;
    object _31234 = NOVALUE;
    object _31233 = NOVALUE;
    object _31231 = NOVALUE;
    object _31229 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:522		sequence fr = forward_references[ref]*/
    DeRef(_fr_63572);
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    _fr_63572 = (object)*(((s1_ptr)_2)->base + _ref_63571);
    Ref(_fr_63572);

    /** fwdref.e:524		integer switch_pc = fr[FR_DATA]*/
    _2 = (object)SEQ_PTR(_fr_63572);
    _switch_pc_63574 = (object)*(((s1_ptr)_2)->base + 12LL);
    if (!IS_ATOM_INT(_switch_pc_63574))
    _switch_pc_63574 = (object)DBL_PTR(_switch_pc_63574)->dbl;

    /** fwdref.e:527		if fr[FR_SUBPROG] = TopLevelSub then*/
    _2 = (object)SEQ_PTR(_fr_63572);
    _31229 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (binary_op_a(NOTEQ, _31229, _12TopLevelSub_20233)){
        _31229 = NOVALUE;
        goto L1; // [27] 48
    }
    _31229 = NOVALUE;

    /** fwdref.e:528			case_sym = Code[switch_pc + 2]*/
    _31231 = _switch_pc_63574 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _case_sym_63577 = (object)*(((s1_ptr)_2)->base + _31231);
    if (!IS_ATOM_INT(_case_sym_63577)){
        _case_sym_63577 = (object)DBL_PTR(_case_sym_63577)->dbl;
    }
    goto L2; // [45] 77
L1: 

    /** fwdref.e:530			case_sym = SymTab[fr[FR_SUBPROG]][S_CODE][switch_pc + 2]*/
    _2 = (object)SEQ_PTR(_fr_63572);
    _31233 = (object)*(((s1_ptr)_2)->base + 4LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_31233)){
        _31234 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31233)->dbl));
    }
    else{
        _31234 = (object)*(((s1_ptr)_2)->base + _31233);
    }
    _2 = (object)SEQ_PTR(_31234);
    if (!IS_ATOM_INT(_12S_CODE_19876)){
        _31235 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
    }
    else{
        _31235 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
    }
    _31234 = NOVALUE;
    _31236 = _switch_pc_63574 + 2LL;
    _2 = (object)SEQ_PTR(_31235);
    _case_sym_63577 = (object)*(((s1_ptr)_2)->base + _31236);
    if (!IS_ATOM_INT(_case_sym_63577)){
        _case_sym_63577 = (object)DBL_PTR(_case_sym_63577)->dbl;
    }
    _31235 = NOVALUE;
L2: 

    /** fwdref.e:533		if SymTab[tok[T_SYM]][S_FILE_NO] = fr[FR_FILE] and fr[FR_SUBPROG] = TopLevelSub then*/
    _2 = (object)SEQ_PTR(_tok_63570);
    _31238 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_31238)){
        _31239 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31238)->dbl));
    }
    else{
        _31239 = (object)*(((s1_ptr)_2)->base + _31238);
    }
    _2 = (object)SEQ_PTR(_31239);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _31240 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _31240 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _31239 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_63572);
    _31241 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (IS_ATOM_INT(_31240) && IS_ATOM_INT(_31241)) {
        _31242 = (_31240 == _31241);
    }
    else {
        _31242 = binary_op(EQUALS, _31240, _31241);
    }
    _31240 = NOVALUE;
    _31241 = NOVALUE;
    if (IS_ATOM_INT(_31242)) {
        if (_31242 == 0) {
            goto L3; // [105] 129
        }
    }
    else {
        if (DBL_PTR(_31242)->dbl == 0.0) {
            goto L3; // [105] 129
        }
    }
    _2 = (object)SEQ_PTR(_fr_63572);
    _31244 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_31244)) {
        _31245 = (_31244 == _12TopLevelSub_20233);
    }
    else {
        _31245 = binary_op(EQUALS, _31244, _12TopLevelSub_20233);
    }
    _31244 = NOVALUE;
    if (_31245 == 0) {
        DeRef(_31245);
        _31245 = NOVALUE;
        goto L3; // [120] 129
    }
    else {
        if (!IS_ATOM_INT(_31245) && DBL_PTR(_31245)->dbl == 0.0){
            DeRef(_31245);
            _31245 = NOVALUE;
            goto L3; // [120] 129
        }
        DeRef(_31245);
        _31245 = NOVALUE;
    }
    DeRef(_31245);
    _31245 = NOVALUE;

    /** fwdref.e:534			return*/
    DeRef(_tok_63570);
    DeRef(_fr_63572);
    DeRef(_case_values_63606);
    DeRef(_31242);
    _31242 = NOVALUE;
    DeRef(_31231);
    _31231 = NOVALUE;
    _31238 = NOVALUE;
    _31233 = NOVALUE;
    DeRef(_31236);
    _31236 = NOVALUE;
    return;
L3: 

    /** fwdref.e:537		sequence case_values = SymTab[case_sym][S_OBJ]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31246 = (object)*(((s1_ptr)_2)->base + _case_sym_63577);
    DeRef(_case_values_63606);
    _2 = (object)SEQ_PTR(_31246);
    _case_values_63606 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_case_values_63606);
    _31246 = NOVALUE;

    /** fwdref.e:539		integer cx = find( { ref }, case_values )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _ref_63571;
    _31248 = MAKE_SEQ(_1);
    _cx_63611 = find_from(_31248, _case_values_63606, 1LL);
    DeRefDS(_31248);
    _31248 = NOVALUE;

    /** fwdref.e:540		if not cx then*/
    if (_cx_63611 != 0)
    goto L4; // [160] 178

    /** fwdref.e:541			cx = find( { -ref }, case_values )*/
    if ((uintptr_t)_ref_63571 == (uintptr_t)HIGH_BITS){
        _31251 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31251 = - _ref_63571;
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _31251;
    _31252 = MAKE_SEQ(_1);
    _31251 = NOVALUE;
    _cx_63611 = find_from(_31252, _case_values_63606, 1LL);
    DeRefDS(_31252);
    _31252 = NOVALUE;
L4: 

    /** fwdref.e:544	 	ifdef DEBUG then	*/

    /** fwdref.e:551		integer negative = 0*/
    _negative_63619 = 0LL;

    /** fwdref.e:552		if case_values[cx][1] < 0 then*/
    _2 = (object)SEQ_PTR(_case_values_63606);
    _31254 = (object)*(((s1_ptr)_2)->base + _cx_63611);
    _2 = (object)SEQ_PTR(_31254);
    _31255 = (object)*(((s1_ptr)_2)->base + 1LL);
    _31254 = NOVALUE;
    if (binary_op_a(GREATEREQ, _31255, 0LL)){
        _31255 = NOVALUE;
        goto L5; // [195] 224
    }
    _31255 = NOVALUE;

    /** fwdref.e:553			negative = 1*/
    _negative_63619 = 1LL;

    /** fwdref.e:554			case_values[cx][1] *= -1*/
    _2 = (object)SEQ_PTR(_case_values_63606);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _case_values_63606 = MAKE_SEQ(_2);
    }
    _3 = (object)(_cx_63611 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _31259 = (object)*(((s1_ptr)_2)->base + 1LL);
    _31257 = NOVALUE;
    if (IS_ATOM_INT(_31259)) {
        {
            int128_t p128 = (int128_t)_31259 * (int128_t)-1LL;
            if( p128 != (int128_t)(_31260 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _31260 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _31260 = binary_op(MULTIPLY, _31259, -1LL);
    }
    _31259 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31260;
    if( _1 != _31260 ){
        DeRef(_1);
    }
    _31260 = NOVALUE;
    _31257 = NOVALUE;
L5: 

    /** fwdref.e:557		if negative then*/
    if (_negative_63619 == 0)
    {
        goto L6; // [226] 247
    }
    else{
    }

    /** fwdref.e:558			case_values[cx] = - tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63570);
    _31261 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_31261)) {
        if ((uintptr_t)_31261 == (uintptr_t)HIGH_BITS){
            _31262 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _31262 = - _31261;
        }
    }
    else {
        _31262 = unary_op(UMINUS, _31261);
    }
    _31261 = NOVALUE;
    _2 = (object)SEQ_PTR(_case_values_63606);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _case_values_63606 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _cx_63611);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31262;
    if( _1 != _31262 ){
        DeRef(_1);
    }
    _31262 = NOVALUE;
    goto L7; // [244] 260
L6: 

    /** fwdref.e:560			case_values[cx] = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63570);
    _31263 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_31263);
    _2 = (object)SEQ_PTR(_case_values_63606);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _case_values_63606 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _cx_63611);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31263;
    if( _1 != _31263 ){
        DeRef(_1);
    }
    _31263 = NOVALUE;
L7: 

    /** fwdref.e:562		SymTab[case_sym][S_OBJ] = case_values*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_case_sym_63577 + ((s1_ptr)_2)->base);
    RefDS(_case_values_63606);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _case_values_63606;
    DeRef(_1);
    _31264 = NOVALUE;

    /** fwdref.e:563		resolved_reference( ref )*/
    _42resolved_reference(_ref_63571);

    /** fwdref.e:564	end procedure*/
    DeRef(_tok_63570);
    DeRef(_fr_63572);
    DeRefDS(_case_values_63606);
    DeRef(_31242);
    _31242 = NOVALUE;
    DeRef(_31231);
    _31231 = NOVALUE;
    _31238 = NOVALUE;
    _31233 = NOVALUE;
    DeRef(_31236);
    _31236 = NOVALUE;
    return;
    ;
}


void _42patch_forward_type_check(object _tok_63642, object _ref_63643)
{
    object _fr_63644 = NOVALUE;
    object _which_type_63647 = NOVALUE;
    object _var_63649 = NOVALUE;
    object _pc_63682 = NOVALUE;
    object _with_type_check_63684 = NOVALUE;
    object _c_63714 = NOVALUE;
    object _subprog_inlined_insert_code_at_332_63723 = NOVALUE;
    object _code_inlined_insert_code_at_329_63722 = NOVALUE;
    object _subprog_inlined_insert_code_at_415_63739 = NOVALUE;
    object _code_inlined_insert_code_at_412_63738 = NOVALUE;
    object _subprog_inlined_insert_code_at_477_63749 = NOVALUE;
    object _code_inlined_insert_code_at_474_63748 = NOVALUE;
    object _subprog_inlined_insert_code_at_539_63759 = NOVALUE;
    object _code_inlined_insert_code_at_536_63758 = NOVALUE;
    object _start_pc_63766 = NOVALUE;
    object _subprog_inlined_insert_code_at_647_63783 = NOVALUE;
    object _code_inlined_insert_code_at_644_63782 = NOVALUE;
    object _c_63786 = NOVALUE;
    object _subprog_inlined_insert_code_at_741_63802 = NOVALUE;
    object _code_inlined_insert_code_at_738_63801 = NOVALUE;
    object _start_pc_63813 = NOVALUE;
    object _subprog_inlined_insert_code_at_886_63833 = NOVALUE;
    object _code_inlined_insert_code_at_883_63832 = NOVALUE;
    object _subprog_inlined_insert_code_at_987_63854 = NOVALUE;
    object _code_inlined_insert_code_at_984_63853 = NOVALUE;
    object _31354 = NOVALUE;
    object _31353 = NOVALUE;
    object _31352 = NOVALUE;
    object _31351 = NOVALUE;
    object _31350 = NOVALUE;
    object _31349 = NOVALUE;
    object _31348 = NOVALUE;
    object _31346 = NOVALUE;
    object _31344 = NOVALUE;
    object _31343 = NOVALUE;
    object _31342 = NOVALUE;
    object _31341 = NOVALUE;
    object _31340 = NOVALUE;
    object _31339 = NOVALUE;
    object _31338 = NOVALUE;
    object _31336 = NOVALUE;
    object _31335 = NOVALUE;
    object _31334 = NOVALUE;
    object _31333 = NOVALUE;
    object _31332 = NOVALUE;
    object _31331 = NOVALUE;
    object _31329 = NOVALUE;
    object _31328 = NOVALUE;
    object _31327 = NOVALUE;
    object _31326 = NOVALUE;
    object _31324 = NOVALUE;
    object _31323 = NOVALUE;
    object _31320 = NOVALUE;
    object _31319 = NOVALUE;
    object _31317 = NOVALUE;
    object _31316 = NOVALUE;
    object _31315 = NOVALUE;
    object _31314 = NOVALUE;
    object _31313 = NOVALUE;
    object _31312 = NOVALUE;
    object _31310 = NOVALUE;
    object _31309 = NOVALUE;
    object _31306 = NOVALUE;
    object _31305 = NOVALUE;
    object _31302 = NOVALUE;
    object _31301 = NOVALUE;
    object _31297 = NOVALUE;
    object _31296 = NOVALUE;
    object _31294 = NOVALUE;
    object _31293 = NOVALUE;
    object _31291 = NOVALUE;
    object _31290 = NOVALUE;
    object _31287 = NOVALUE;
    object _31284 = NOVALUE;
    object _31282 = NOVALUE;
    object _31279 = NOVALUE;
    object _31278 = NOVALUE;
    object _31275 = NOVALUE;
    object _31270 = NOVALUE;
    object _31269 = NOVALUE;
    object _31267 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:568		sequence fr = forward_references[ref]*/
    DeRef(_fr_63644);
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    _fr_63644 = (object)*(((s1_ptr)_2)->base + _ref_63643);
    Ref(_fr_63644);

    /** fwdref.e:572		if fr[FR_OP] = TYPE_CHECK_FORWARD then*/
    _2 = (object)SEQ_PTR(_fr_63644);
    _31267 = (object)*(((s1_ptr)_2)->base + 10LL);
    if (binary_op_a(NOTEQ, _31267, 197LL)){
        _31267 = NOVALUE;
        goto L1; // [21] 86
    }
    _31267 = NOVALUE;

    /** fwdref.e:573			which_type = SymTab[tok[T_SYM]][S_VTYPE]*/
    _2 = (object)SEQ_PTR(_tok_63642);
    _31269 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_31269)){
        _31270 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31269)->dbl));
    }
    else{
        _31270 = (object)*(((s1_ptr)_2)->base + _31269);
    }
    _2 = (object)SEQ_PTR(_31270);
    _which_type_63647 = (object)*(((s1_ptr)_2)->base + 15LL);
    if (!IS_ATOM_INT(_which_type_63647)){
        _which_type_63647 = (object)DBL_PTR(_which_type_63647)->dbl;
    }
    _31270 = NOVALUE;

    /** fwdref.e:574			if not which_type then*/
    if (_which_type_63647 != 0)
    goto L2; // [49] 72

    /** fwdref.e:575				which_type = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63642);
    _which_type_63647 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_which_type_63647)){
        _which_type_63647 = (object)DBL_PTR(_which_type_63647)->dbl;
    }

    /** fwdref.e:576				var = 0*/
    _var_63649 = 0LL;
    goto L3; // [69] 144
L2: 

    /** fwdref.e:578				var = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63642);
    _var_63649 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_var_63649)){
        _var_63649 = (object)DBL_PTR(_var_63649)->dbl;
    }
    goto L3; // [83] 144
L1: 

    /** fwdref.e:582		elsif fr[FR_OP] = TYPE then*/
    _2 = (object)SEQ_PTR(_fr_63644);
    _31275 = (object)*(((s1_ptr)_2)->base + 10LL);
    if (binary_op_a(NOTEQ, _31275, 504LL)){
        _31275 = NOVALUE;
        goto L4; // [94] 118
    }
    _31275 = NOVALUE;

    /** fwdref.e:583			which_type = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63642);
    _which_type_63647 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_which_type_63647)){
        _which_type_63647 = (object)DBL_PTR(_which_type_63647)->dbl;
    }

    /** fwdref.e:584			var = 0*/
    _var_63649 = 0LL;
    goto L3; // [115] 144
L4: 

    /** fwdref.e:587			prep_forward_error( ref )*/
    _42prep_forward_error(_ref_63643);

    /** fwdref.e:588			InternalErr( 262, { TYPE_CHECK, TYPE_CHECK_FORWARD, fr[FR_OP] })*/
    _2 = (object)SEQ_PTR(_fr_63644);
    _31278 = (object)*(((s1_ptr)_2)->base + 10LL);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 65LL;
    ((intptr_t*)_2)[2] = 197LL;
    Ref(_31278);
    ((intptr_t*)_2)[3] = _31278;
    _31279 = MAKE_SEQ(_1);
    _31278 = NOVALUE;
    _49InternalErr(262LL, _31279);
    _31279 = NOVALUE;
L3: 

    /** fwdref.e:591		if which_type < 0 then*/
    if (_which_type_63647 >= 0LL)
    goto L5; // [148] 158

    /** fwdref.e:593			return*/
    DeRef(_tok_63642);
    DeRef(_fr_63644);
    _31269 = NOVALUE;
    return;
L5: 

    /** fwdref.e:596		set_code( ref )*/
    _42set_code(_ref_63643);

    /** fwdref.e:598		integer pc = fr[FR_PC]*/
    _2 = (object)SEQ_PTR(_fr_63644);
    _pc_63682 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (!IS_ATOM_INT(_pc_63682))
    _pc_63682 = (object)DBL_PTR(_pc_63682)->dbl;

    /** fwdref.e:599		integer with_type_check = Code[pc + 2]*/
    _31282 = _pc_63682 + 2LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _with_type_check_63684 = (object)*(((s1_ptr)_2)->base + _31282);
    if (!IS_ATOM_INT(_with_type_check_63684)){
        _with_type_check_63684 = (object)DBL_PTR(_with_type_check_63684)->dbl;
    }

    /** fwdref.e:601		if Code[pc] != TYPE_CHECK_FORWARD then*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    _31284 = (object)*(((s1_ptr)_2)->base + _pc_63682);
    if (binary_op_a(EQUALS, _31284, 197LL)){
        _31284 = NOVALUE;
        goto L6; // [193] 204
    }
    _31284 = NOVALUE;

    /** fwdref.e:602			forward_error( tok, ref )*/
    Ref(_tok_63642);
    _42forward_error(_tok_63642, _ref_63643);
L6: 

    /** fwdref.e:604		if not var then*/
    if (_var_63649 != 0)
    goto L7; // [208] 226

    /** fwdref.e:606			var = Code[pc+1]*/
    _31287 = _pc_63682 + 1;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _var_63649 = (object)*(((s1_ptr)_2)->base + _31287);
    if (!IS_ATOM_INT(_var_63649)){
        _var_63649 = (object)DBL_PTR(_var_63649)->dbl;
    }
L7: 

    /** fwdref.e:609		if var < 0 then*/
    if (_var_63649 >= 0LL)
    goto L8; // [228] 238

    /** fwdref.e:611			return*/
    DeRef(_tok_63642);
    DeRef(_fr_63644);
    DeRef(_31287);
    _31287 = NOVALUE;
    DeRef(_31282);
    _31282 = NOVALUE;
    _31269 = NOVALUE;
    return;
L8: 

    /** fwdref.e:615		replace_code( {}, pc, pc + 2, fr[FR_SUBPROG])*/
    _31290 = _pc_63682 + 2LL;
    if ((object)((uintptr_t)_31290 + (uintptr_t)HIGH_BITS) >= 0){
        _31290 = NewDouble((eudouble)_31290);
    }
    _2 = (object)SEQ_PTR(_fr_63644);
    _31291 = (object)*(((s1_ptr)_2)->base + 4LL);
    RefDS(_22024);
    Ref(_31291);
    _42replace_code(_22024, _pc_63682, _31290, _31291);
    _31290 = NOVALUE;
    _31291 = NOVALUE;

    /** fwdref.e:617		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L9; // [258] 364
    }
    else{
    }

    /** fwdref.e:618			if with_type_check then*/
    if (_with_type_check_63684 == 0)
    {
        goto LA; // [263] 771
    }
    else{
    }

    /** fwdref.e:619				if which_type != object_type then*/
    if (_which_type_63647 == _53object_type_46846)
    goto LA; // [270] 771

    /** fwdref.e:620					if SymTab[which_type][S_EFFECT] then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31293 = (object)*(((s1_ptr)_2)->base + _which_type_63647);
    _2 = (object)SEQ_PTR(_31293);
    _31294 = (object)*(((s1_ptr)_2)->base + 23LL);
    _31293 = NOVALUE;
    if (_31294 == 0) {
        _31294 = NOVALUE;
        goto LB; // [288] 357
    }
    else {
        if (!IS_ATOM_INT(_31294) && DBL_PTR(_31294)->dbl == 0.0){
            _31294 = NOVALUE;
            goto LB; // [288] 357
        }
        _31294 = NOVALUE;
    }
    _31294 = NOVALUE;

    /** fwdref.e:622						integer c = NewTempSym()*/
    _c_63714 = _53NewTempSym(0LL);
    if (!IS_ATOM_INT(_c_63714)) {
        _1 = (object)(DBL_PTR(_c_63714)->dbl);
        DeRefDS(_c_63714);
        _c_63714 = _1;
    }

    /** fwdref.e:623						insert_code( { PROC, which_type, var, c, TYPE_CHECK }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 27LL;
    ((intptr_t*)_2)[2] = _which_type_63647;
    ((intptr_t*)_2)[3] = _var_63649;
    ((intptr_t*)_2)[4] = _c_63714;
    ((intptr_t*)_2)[5] = 65LL;
    _31296 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63644);
    _31297 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_329_63722);
    _code_inlined_insert_code_at_329_63722 = _31296;
    _31296 = NOVALUE;
    Ref(_31297);
    DeRef(_subprog_inlined_insert_code_at_332_63723);
    _subprog_inlined_insert_code_at_332_63723 = _31297;
    _31297 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_332_63723)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_332_63723)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_332_63723);
        _subprog_inlined_insert_code_at_332_63723 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _42shifting_sub_62883 = _subprog_inlined_insert_code_at_332_63723;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_329_63722);
    _65insert_code(_code_inlined_insert_code_at_329_63722, _pc_63682);

    /** fwdref.e:84		shifting_sub = 0*/
    _42shifting_sub_62883 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto LC; // [345] 348
LC: 
    DeRefi(_code_inlined_insert_code_at_329_63722);
    _code_inlined_insert_code_at_329_63722 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_332_63723);
    _subprog_inlined_insert_code_at_332_63723 = NOVALUE;

    /** fwdref.e:624						pc += 5*/
    _pc_63682 = _pc_63682 + 5LL;
LB: 
    goto LA; // [361] 771
L9: 

    /** fwdref.e:630			if with_type_check then*/
    if (_with_type_check_63684 == 0)
    {
        goto LD; // [366] 770
    }
    else{
    }

    /** fwdref.e:632				if which_type = object_type then*/
    if (_which_type_63647 != _53object_type_46846)
    goto LE; // [373] 380
    goto LF; // [377] 769
LE: 

    /** fwdref.e:636					if which_type = integer_type then*/
    if (_which_type_63647 != _53integer_type_46852)
    goto L10; // [384] 442

    /** fwdref.e:637						insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 96LL;
    ((intptr_t *)_2)[2] = _var_63649;
    _31301 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63644);
    _31302 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_412_63738);
    _code_inlined_insert_code_at_412_63738 = _31301;
    _31301 = NOVALUE;
    Ref(_31302);
    DeRef(_subprog_inlined_insert_code_at_415_63739);
    _subprog_inlined_insert_code_at_415_63739 = _31302;
    _31302 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_415_63739)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_415_63739)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_415_63739);
        _subprog_inlined_insert_code_at_415_63739 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _42shifting_sub_62883 = _subprog_inlined_insert_code_at_415_63739;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_412_63738);
    _65insert_code(_code_inlined_insert_code_at_412_63738, _pc_63682);

    /** fwdref.e:84		shifting_sub = 0*/
    _42shifting_sub_62883 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto L11; // [428] 431
L11: 
    DeRefi(_code_inlined_insert_code_at_412_63738);
    _code_inlined_insert_code_at_412_63738 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_415_63739);
    _subprog_inlined_insert_code_at_415_63739 = NOVALUE;

    /** fwdref.e:638						pc += 2*/
    _pc_63682 = _pc_63682 + 2LL;
    goto L12; // [439] 768
L10: 

    /** fwdref.e:640					elsif which_type = sequence_type then*/
    if (_which_type_63647 != _53sequence_type_46850)
    goto L13; // [446] 504

    /** fwdref.e:641						insert_code( { SEQUENCE_CHECK, var }, pc, fr[FR_SUBPROG])*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 97LL;
    ((intptr_t *)_2)[2] = _var_63649;
    _31305 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63644);
    _31306 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_474_63748);
    _code_inlined_insert_code_at_474_63748 = _31305;
    _31305 = NOVALUE;
    Ref(_31306);
    DeRef(_subprog_inlined_insert_code_at_477_63749);
    _subprog_inlined_insert_code_at_477_63749 = _31306;
    _31306 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_477_63749)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_477_63749)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_477_63749);
        _subprog_inlined_insert_code_at_477_63749 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _42shifting_sub_62883 = _subprog_inlined_insert_code_at_477_63749;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_474_63748);
    _65insert_code(_code_inlined_insert_code_at_474_63748, _pc_63682);

    /** fwdref.e:84		shifting_sub = 0*/
    _42shifting_sub_62883 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto L14; // [490] 493
L14: 
    DeRefi(_code_inlined_insert_code_at_474_63748);
    _code_inlined_insert_code_at_474_63748 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_477_63749);
    _subprog_inlined_insert_code_at_477_63749 = NOVALUE;

    /** fwdref.e:642						pc += 2*/
    _pc_63682 = _pc_63682 + 2LL;
    goto L12; // [501] 768
L13: 

    /** fwdref.e:644					elsif which_type = atom_type then*/
    if (_which_type_63647 != _53atom_type_46848)
    goto L15; // [508] 566

    /** fwdref.e:645						insert_code( { ATOM_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 101LL;
    ((intptr_t *)_2)[2] = _var_63649;
    _31309 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63644);
    _31310 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_536_63758);
    _code_inlined_insert_code_at_536_63758 = _31309;
    _31309 = NOVALUE;
    Ref(_31310);
    DeRef(_subprog_inlined_insert_code_at_539_63759);
    _subprog_inlined_insert_code_at_539_63759 = _31310;
    _31310 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_539_63759)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_539_63759)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_539_63759);
        _subprog_inlined_insert_code_at_539_63759 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _42shifting_sub_62883 = _subprog_inlined_insert_code_at_539_63759;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_536_63758);
    _65insert_code(_code_inlined_insert_code_at_536_63758, _pc_63682);

    /** fwdref.e:84		shifting_sub = 0*/
    _42shifting_sub_62883 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto L16; // [552] 555
L16: 
    DeRefi(_code_inlined_insert_code_at_536_63758);
    _code_inlined_insert_code_at_536_63758 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_539_63759);
    _subprog_inlined_insert_code_at_539_63759 = NOVALUE;

    /** fwdref.e:646						pc += 2*/
    _pc_63682 = _pc_63682 + 2LL;
    goto L12; // [563] 768
L15: 

    /** fwdref.e:648					elsif SymTab[which_type][S_NEXT] then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31312 = (object)*(((s1_ptr)_2)->base + _which_type_63647);
    _2 = (object)SEQ_PTR(_31312);
    _31313 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31312 = NOVALUE;
    if (_31313 == 0) {
        _31313 = NOVALUE;
        goto L17; // [580] 765
    }
    else {
        if (!IS_ATOM_INT(_31313) && DBL_PTR(_31313)->dbl == 0.0){
            _31313 = NOVALUE;
            goto L17; // [580] 765
        }
        _31313 = NOVALUE;
    }
    _31313 = NOVALUE;

    /** fwdref.e:649						integer start_pc = pc*/
    _start_pc_63766 = _pc_63682;

    /** fwdref.e:652						if SymTab[SymTab[which_type][S_NEXT]][S_VTYPE] = integer_type then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31314 = (object)*(((s1_ptr)_2)->base + _which_type_63647);
    _2 = (object)SEQ_PTR(_31314);
    _31315 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31314 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_31315)){
        _31316 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31315)->dbl));
    }
    else{
        _31316 = (object)*(((s1_ptr)_2)->base + _31315);
    }
    _2 = (object)SEQ_PTR(_31316);
    _31317 = (object)*(((s1_ptr)_2)->base + 15LL);
    _31316 = NOVALUE;
    if (binary_op_a(NOTEQ, _31317, _53integer_type_46852)){
        _31317 = NOVALUE;
        goto L18; // [616] 672
    }
    _31317 = NOVALUE;

    /** fwdref.e:654							insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 96LL;
    ((intptr_t *)_2)[2] = _var_63649;
    _31319 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63644);
    _31320 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_644_63782);
    _code_inlined_insert_code_at_644_63782 = _31319;
    _31319 = NOVALUE;
    Ref(_31320);
    DeRef(_subprog_inlined_insert_code_at_647_63783);
    _subprog_inlined_insert_code_at_647_63783 = _31320;
    _31320 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_647_63783)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_647_63783)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_647_63783);
        _subprog_inlined_insert_code_at_647_63783 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _42shifting_sub_62883 = _subprog_inlined_insert_code_at_647_63783;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_644_63782);
    _65insert_code(_code_inlined_insert_code_at_644_63782, _pc_63682);

    /** fwdref.e:84		shifting_sub = 0*/
    _42shifting_sub_62883 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto L19; // [660] 663
L19: 
    DeRefi(_code_inlined_insert_code_at_644_63782);
    _code_inlined_insert_code_at_644_63782 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_647_63783);
    _subprog_inlined_insert_code_at_647_63783 = NOVALUE;

    /** fwdref.e:656							pc += 2*/
    _pc_63682 = _pc_63682 + 2LL;
L18: 

    /** fwdref.e:658						symtab_index c = NewTempSym()*/
    _c_63786 = _53NewTempSym(0LL);
    if (!IS_ATOM_INT(_c_63786)) {
        _1 = (object)(DBL_PTR(_c_63786)->dbl);
        DeRefDS(_c_63786);
        _c_63786 = _1;
    }

    /** fwdref.e:659						SymTab[fr[FR_SUBPROG]][S_STACK_SPACE] += 1*/
    _2 = (object)SEQ_PTR(_fr_63644);
    _31323 = (object)*(((s1_ptr)_2)->base + 4LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_31323))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31323)->dbl));
    else
    _3 = (object)(_31323 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_12S_STACK_SPACE_19924)){
        _31326 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_STACK_SPACE_19924)->dbl));
    }
    else{
        _31326 = (object)*(((s1_ptr)_2)->base + _12S_STACK_SPACE_19924);
    }
    _31324 = NOVALUE;
    if (IS_ATOM_INT(_31326)) {
        _31327 = _31326 + 1;
        if (_31327 > MAXINT){
            _31327 = NewDouble((eudouble)_31327);
        }
    }
    else
    _31327 = binary_op(PLUS, 1, _31326);
    _31326 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_STACK_SPACE_19924))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_STACK_SPACE_19924)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_STACK_SPACE_19924);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31327;
    if( _1 != _31327 ){
        DeRef(_1);
    }
    _31327 = NOVALUE;
    _31324 = NOVALUE;

    /** fwdref.e:660						insert_code( { PROC, which_type, var, c, TYPE_CHECK }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 27LL;
    ((intptr_t*)_2)[2] = _which_type_63647;
    ((intptr_t*)_2)[3] = _var_63649;
    ((intptr_t*)_2)[4] = _c_63786;
    ((intptr_t*)_2)[5] = 65LL;
    _31328 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63644);
    _31329 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_738_63801);
    _code_inlined_insert_code_at_738_63801 = _31328;
    _31328 = NOVALUE;
    Ref(_31329);
    DeRef(_subprog_inlined_insert_code_at_741_63802);
    _subprog_inlined_insert_code_at_741_63802 = _31329;
    _31329 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_741_63802)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_741_63802)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_741_63802);
        _subprog_inlined_insert_code_at_741_63802 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _42shifting_sub_62883 = _subprog_inlined_insert_code_at_741_63802;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_738_63801);
    _65insert_code(_code_inlined_insert_code_at_738_63801, _pc_63682);

    /** fwdref.e:84		shifting_sub = 0*/
    _42shifting_sub_62883 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto L1A; // [753] 756
L1A: 
    DeRefi(_code_inlined_insert_code_at_738_63801);
    _code_inlined_insert_code_at_738_63801 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_741_63802);
    _subprog_inlined_insert_code_at_741_63802 = NOVALUE;

    /** fwdref.e:661						pc += 4*/
    _pc_63682 = _pc_63682 + 4LL;
L17: 
L12: 
LF: 
LD: 
LA: 

    /** fwdref.e:668		if (TRANSLATE or not with_type_check) and SymTab[which_type][S_NEXT] then*/
    if (_12TRANSLATE_19834 != 0) {
        _31331 = 1;
        goto L1B; // [775] 786
    }
    _31332 = (_with_type_check_63684 == 0);
    _31331 = (_31332 != 0);
L1B: 
    if (_31331 == 0) {
        goto L1C; // [786] 1013
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31334 = (object)*(((s1_ptr)_2)->base + _which_type_63647);
    _2 = (object)SEQ_PTR(_31334);
    _31335 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31334 = NOVALUE;
    if (_31335 == 0) {
        _31335 = NOVALUE;
        goto L1C; // [803] 1013
    }
    else {
        if (!IS_ATOM_INT(_31335) && DBL_PTR(_31335)->dbl == 0.0){
            _31335 = NOVALUE;
            goto L1C; // [803] 1013
        }
        _31335 = NOVALUE;
    }
    _31335 = NOVALUE;

    /** fwdref.e:669			integer start_pc = pc*/
    _start_pc_63813 = _pc_63682;

    /** fwdref.e:671			if which_type = sequence_type or*/
    _31336 = (_which_type_63647 == _53sequence_type_46850);
    if (_31336 != 0) {
        goto L1D; // [819] 858
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31338 = (object)*(((s1_ptr)_2)->base + _which_type_63647);
    _2 = (object)SEQ_PTR(_31338);
    _31339 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31338 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_31339)){
        _31340 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31339)->dbl));
    }
    else{
        _31340 = (object)*(((s1_ptr)_2)->base + _31339);
    }
    _2 = (object)SEQ_PTR(_31340);
    _31341 = (object)*(((s1_ptr)_2)->base + 15LL);
    _31340 = NOVALUE;
    if (IS_ATOM_INT(_31341)) {
        _31342 = (_31341 == _53sequence_type_46850);
    }
    else {
        _31342 = binary_op(EQUALS, _31341, _53sequence_type_46850);
    }
    _31341 = NOVALUE;
    if (_31342 == 0) {
        DeRef(_31342);
        _31342 = NOVALUE;
        goto L1E; // [854] 912
    }
    else {
        if (!IS_ATOM_INT(_31342) && DBL_PTR(_31342)->dbl == 0.0){
            DeRef(_31342);
            _31342 = NOVALUE;
            goto L1E; // [854] 912
        }
        DeRef(_31342);
        _31342 = NOVALUE;
    }
    DeRef(_31342);
    _31342 = NOVALUE;
L1D: 

    /** fwdref.e:674				insert_code( { SEQUENCE_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 97LL;
    ((intptr_t *)_2)[2] = _var_63649;
    _31343 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63644);
    _31344 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_883_63832);
    _code_inlined_insert_code_at_883_63832 = _31343;
    _31343 = NOVALUE;
    Ref(_31344);
    DeRef(_subprog_inlined_insert_code_at_886_63833);
    _subprog_inlined_insert_code_at_886_63833 = _31344;
    _31344 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_886_63833)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_886_63833)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_886_63833);
        _subprog_inlined_insert_code_at_886_63833 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _42shifting_sub_62883 = _subprog_inlined_insert_code_at_886_63833;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_883_63832);
    _65insert_code(_code_inlined_insert_code_at_883_63832, _pc_63682);

    /** fwdref.e:84		shifting_sub = 0*/
    _42shifting_sub_62883 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto L1F; // [898] 901
L1F: 
    DeRefi(_code_inlined_insert_code_at_883_63832);
    _code_inlined_insert_code_at_883_63832 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_886_63833);
    _subprog_inlined_insert_code_at_886_63833 = NOVALUE;

    /** fwdref.e:675				pc += 2*/
    _pc_63682 = _pc_63682 + 2LL;
    goto L20; // [909] 1012
L1E: 

    /** fwdref.e:677			elsif which_type = integer_type or*/
    _31346 = (_which_type_63647 == _53integer_type_46852);
    if (_31346 != 0) {
        goto L21; // [920] 959
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31348 = (object)*(((s1_ptr)_2)->base + _which_type_63647);
    _2 = (object)SEQ_PTR(_31348);
    _31349 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31348 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_31349)){
        _31350 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31349)->dbl));
    }
    else{
        _31350 = (object)*(((s1_ptr)_2)->base + _31349);
    }
    _2 = (object)SEQ_PTR(_31350);
    _31351 = (object)*(((s1_ptr)_2)->base + 15LL);
    _31350 = NOVALUE;
    if (IS_ATOM_INT(_31351)) {
        _31352 = (_31351 == _53integer_type_46852);
    }
    else {
        _31352 = binary_op(EQUALS, _31351, _53integer_type_46852);
    }
    _31351 = NOVALUE;
    if (_31352 == 0) {
        DeRef(_31352);
        _31352 = NOVALUE;
        goto L22; // [955] 1011
    }
    else {
        if (!IS_ATOM_INT(_31352) && DBL_PTR(_31352)->dbl == 0.0){
            DeRef(_31352);
            _31352 = NOVALUE;
            goto L22; // [955] 1011
        }
        DeRef(_31352);
        _31352 = NOVALUE;
    }
    DeRef(_31352);
    _31352 = NOVALUE;
L21: 

    /** fwdref.e:680				insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 96LL;
    ((intptr_t *)_2)[2] = _var_63649;
    _31353 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63644);
    _31354 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_984_63853);
    _code_inlined_insert_code_at_984_63853 = _31353;
    _31353 = NOVALUE;
    Ref(_31354);
    DeRef(_subprog_inlined_insert_code_at_987_63854);
    _subprog_inlined_insert_code_at_987_63854 = _31354;
    _31354 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_987_63854)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_987_63854)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_987_63854);
        _subprog_inlined_insert_code_at_987_63854 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _42shifting_sub_62883 = _subprog_inlined_insert_code_at_987_63854;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_984_63853);
    _65insert_code(_code_inlined_insert_code_at_984_63853, _pc_63682);

    /** fwdref.e:84		shifting_sub = 0*/
    _42shifting_sub_62883 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto L23; // [999] 1002
L23: 
    DeRefi(_code_inlined_insert_code_at_984_63853);
    _code_inlined_insert_code_at_984_63853 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_987_63854);
    _subprog_inlined_insert_code_at_987_63854 = NOVALUE;

    /** fwdref.e:681				pc += 4*/
    _pc_63682 = _pc_63682 + 4LL;
L22: 
L20: 
L1C: 

    /** fwdref.e:686		resolved_reference( ref )*/
    _42resolved_reference(_ref_63643);

    /** fwdref.e:687		reset_code()*/
    _42reset_code();

    /** fwdref.e:688	end procedure*/
    DeRef(_tok_63642);
    DeRef(_fr_63644);
    DeRef(_31346);
    _31346 = NOVALUE;
    _31339 = NOVALUE;
    DeRef(_31287);
    _31287 = NOVALUE;
    DeRef(_31282);
    _31282 = NOVALUE;
    DeRef(_31336);
    _31336 = NOVALUE;
    DeRef(_31332);
    _31332 = NOVALUE;
    _31315 = NOVALUE;
    _31349 = NOVALUE;
    _31323 = NOVALUE;
    _31269 = NOVALUE;
    return;
    ;
}


void _42prep_forward_error(object _ref_63858)
{
    object _31362 = NOVALUE;
    object _31360 = NOVALUE;
    object _31358 = NOVALUE;
    object _31356 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_ref_63858)) {
        _1 = (object)(DBL_PTR(_ref_63858)->dbl);
        DeRefDS(_ref_63858);
        _ref_63858 = _1;
    }

    /** fwdref.e:691		ThisLine = forward_references[ref][FR_THISLINE]*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    _31356 = (object)*(((s1_ptr)_2)->base + _ref_63858);
    DeRef(_49ThisLine_49312);
    _2 = (object)SEQ_PTR(_31356);
    _49ThisLine_49312 = (object)*(((s1_ptr)_2)->base + 7LL);
    Ref(_49ThisLine_49312);
    _31356 = NOVALUE;

    /** fwdref.e:692		bp = forward_references[ref][FR_BP]*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    _31358 = (object)*(((s1_ptr)_2)->base + _ref_63858);
    _2 = (object)SEQ_PTR(_31358);
    _49bp_49316 = (object)*(((s1_ptr)_2)->base + 8LL);
    if (!IS_ATOM_INT(_49bp_49316)){
        _49bp_49316 = (object)DBL_PTR(_49bp_49316)->dbl;
    }
    _31358 = NOVALUE;

    /** fwdref.e:693		line_number = forward_references[ref][FR_LINE]*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    _31360 = (object)*(((s1_ptr)_2)->base + _ref_63858);
    _2 = (object)SEQ_PTR(_31360);
    _12line_number_20227 = (object)*(((s1_ptr)_2)->base + 6LL);
    if (!IS_ATOM_INT(_12line_number_20227)){
        _12line_number_20227 = (object)DBL_PTR(_12line_number_20227)->dbl;
    }
    _31360 = NOVALUE;

    /** fwdref.e:694		current_file_no = forward_references[ref][FR_FILE]*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    _31362 = (object)*(((s1_ptr)_2)->base + _ref_63858);
    _2 = (object)SEQ_PTR(_31362);
    _12current_file_no_20226 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_12current_file_no_20226)){
        _12current_file_no_20226 = (object)DBL_PTR(_12current_file_no_20226)->dbl;
    }
    _31362 = NOVALUE;

    /** fwdref.e:695	end procedure*/
    return;
    ;
}


void _42forward_error(object _tok_63874, object _ref_63875)
{
    object _31369 = NOVALUE;
    object _31368 = NOVALUE;
    object _31367 = NOVALUE;
    object _31366 = NOVALUE;
    object _31365 = NOVALUE;
    object _31364 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:698		prep_forward_error( ref )*/
    _42prep_forward_error(_ref_63875);

    /** fwdref.e:699		CompileErr(EXPECTED_1_NOT_2, { expected_name( forward_references[ref][FR_TYPE] ),*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    _31364 = (object)*(((s1_ptr)_2)->base + _ref_63875);
    _2 = (object)SEQ_PTR(_31364);
    _31365 = (object)*(((s1_ptr)_2)->base + 1LL);
    _31364 = NOVALUE;
    Ref(_31365);
    _31366 = _42expected_name(_31365);
    _31365 = NOVALUE;
    _2 = (object)SEQ_PTR(_tok_63874);
    _31367 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_31367);
    _31368 = _42expected_name(_31367);
    _31367 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _31366;
    ((intptr_t *)_2)[2] = _31368;
    _31369 = MAKE_SEQ(_1);
    _31368 = NOVALUE;
    _31366 = NOVALUE;
    _49CompileErr(68LL, _31369, 0LL);
    _31369 = NOVALUE;

    /** fwdref.e:701	end procedure*/
    DeRef(_tok_63874);
    return;
    ;
}


object _42find_reference(object _fr_63887)
{
    object _name_63888 = NOVALUE;
    object _file_63890 = NOVALUE;
    object _ns_file_63892 = NOVALUE;
    object _ix_63893 = NOVALUE;
    object _ns_63896 = NOVALUE;
    object _ns_tok_63900 = NOVALUE;
    object _tok_63912 = NOVALUE;
    object _31380 = NOVALUE;
    object _31377 = NOVALUE;
    object _31375 = NOVALUE;
    object _31373 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:706		sequence name = fr[FR_NAME]*/
    DeRef(_name_63888);
    _2 = (object)SEQ_PTR(_fr_63887);
    _name_63888 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_name_63888);

    /** fwdref.e:707		integer file  = fr[FR_FILE]*/
    _2 = (object)SEQ_PTR(_fr_63887);
    _file_63890 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_file_63890))
    _file_63890 = (object)DBL_PTR(_file_63890)->dbl;

    /** fwdref.e:709		integer ns_file = -1*/
    _ns_file_63892 = -1LL;

    /** fwdref.e:710		integer ix = find( ':', name )*/
    _ix_63893 = find_from(58LL, _name_63888, 1LL);

    /** fwdref.e:711		if ix then*/
    if (_ix_63893 == 0)
    {
        goto L1; // [31] 85
    }
    else{
    }

    /** fwdref.e:712			sequence ns = name[1..ix-1]*/
    _31373 = _ix_63893 - 1LL;
    rhs_slice_target = (object_ptr)&_ns_63896;
    RHS_Slice(_name_63888, 1LL, _31373);

    /** fwdref.e:713			token ns_tok = keyfind( ns, ns_file, file, 1, fr[FR_HASHVAL] )*/
    _2 = (object)SEQ_PTR(_fr_63887);
    _31375 = (object)*(((s1_ptr)_2)->base + 11LL);
    RefDS(_ns_63896);
    Ref(_31375);
    _0 = _ns_tok_63900;
    _ns_tok_63900 = _53keyfind(_ns_63896, -1LL, _file_63890, 1LL, _31375);
    DeRef(_0);
    _31375 = NOVALUE;

    /** fwdref.e:714			if ns_tok[T_ID] != NAMESPACE then*/
    _2 = (object)SEQ_PTR(_ns_tok_63900);
    _31377 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _31377, 523LL)){
        _31377 = NOVALUE;
        goto L2; // [69] 80
    }
    _31377 = NOVALUE;

    /** fwdref.e:715				return ns_tok*/
    DeRefDS(_ns_63896);
    DeRefDS(_fr_63887);
    DeRefDS(_name_63888);
    DeRef(_tok_63912);
    _31373 = NOVALUE;
    return _ns_tok_63900;
L2: 
    DeRef(_ns_63896);
    _ns_63896 = NOVALUE;
    DeRef(_ns_tok_63900);
    _ns_tok_63900 = NOVALUE;
    goto L3; // [82] 92
L1: 

    /** fwdref.e:718			ns_file = fr[FR_QUALIFIED]*/
    _2 = (object)SEQ_PTR(_fr_63887);
    _ns_file_63892 = (object)*(((s1_ptr)_2)->base + 9LL);
    if (!IS_ATOM_INT(_ns_file_63892))
    _ns_file_63892 = (object)DBL_PTR(_ns_file_63892)->dbl;
L3: 

    /** fwdref.e:721		No_new_entry = 1*/
    _53No_new_entry_48046 = 1LL;

    /** fwdref.e:722		object tok = keyfind( name, ns_file, file, , fr[FR_HASHVAL] )*/
    _2 = (object)SEQ_PTR(_fr_63887);
    _31380 = (object)*(((s1_ptr)_2)->base + 11LL);
    RefDS(_name_63888);
    Ref(_31380);
    _0 = _tok_63912;
    _tok_63912 = _53keyfind(_name_63888, _ns_file_63892, _file_63890, 0LL, _31380);
    DeRef(_0);
    _31380 = NOVALUE;

    /** fwdref.e:723		No_new_entry = 0*/
    _53No_new_entry_48046 = 0LL;

    /** fwdref.e:724		return tok*/
    DeRefDS(_fr_63887);
    DeRefDS(_name_63888);
    DeRef(_31373);
    _31373 = NOVALUE;
    return _tok_63912;
    ;
}


void _42register_forward_type(object _sym_63920, object _ref_63921)
{
    object _31387 = NOVALUE;
    object _31386 = NOVALUE;
    object _31384 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:729		if ref < 0 then*/
    if (_ref_63921 >= 0LL)
    goto L1; // [7] 19

    /** fwdref.e:730			ref = -ref*/
    _ref_63921 = - _ref_63921;
L1: 

    /** fwdref.e:732		forward_references[ref][FR_DATA] &= sym*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_62864 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63921 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _31386 = (object)*(((s1_ptr)_2)->base + 12LL);
    _31384 = NOVALUE;
    if (IS_SEQUENCE(_31386) && IS_ATOM(_sym_63920)) {
        Append(&_31387, _31386, _sym_63920);
    }
    else if (IS_ATOM(_31386) && IS_SEQUENCE(_sym_63920)) {
    }
    else {
        Concat((object_ptr)&_31387, _31386, _sym_63920);
        _31386 = NOVALUE;
    }
    _31386 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31387;
    if( _1 != _31387 ){
        DeRef(_1);
    }
    _31387 = NOVALUE;
    _31384 = NOVALUE;

    /** fwdref.e:733	end procedure*/
    return;
    ;
}


object _42new_forward_reference(object _fwd_op_63951, object _sym_63953, object _op_63954)
{
    object _ref_63955 = NOVALUE;
    object _len_63956 = NOVALUE;
    object _hashval_63986 = NOVALUE;
    object _default_sym_64061 = NOVALUE;
    object _param_64064 = NOVALUE;
    object _set_data_2__tmp_at578_64081 = NOVALUE;
    object _set_data_1__tmp_at578_64080 = NOVALUE;
    object _data_inlined_set_data_at_575_64079 = NOVALUE;
    object _31473 = NOVALUE;
    object _31472 = NOVALUE;
    object _31471 = NOVALUE;
    object _31468 = NOVALUE;
    object _31466 = NOVALUE;
    object _31465 = NOVALUE;
    object _31463 = NOVALUE;
    object _31462 = NOVALUE;
    object _31461 = NOVALUE;
    object _31459 = NOVALUE;
    object _31457 = NOVALUE;
    object _31455 = NOVALUE;
    object _31452 = NOVALUE;
    object _31451 = NOVALUE;
    object _31449 = NOVALUE;
    object _31447 = NOVALUE;
    object _31445 = NOVALUE;
    object _31443 = NOVALUE;
    object _31442 = NOVALUE;
    object _31441 = NOVALUE;
    object _31439 = NOVALUE;
    object _31436 = NOVALUE;
    object _31434 = NOVALUE;
    object _31432 = NOVALUE;
    object _31431 = NOVALUE;
    object _31430 = NOVALUE;
    object _31429 = NOVALUE;
    object _31427 = NOVALUE;
    object _31424 = NOVALUE;
    object _31423 = NOVALUE;
    object _31422 = NOVALUE;
    object _31420 = NOVALUE;
    object _31419 = NOVALUE;
    object _31418 = NOVALUE;
    object _31417 = NOVALUE;
    object _31415 = NOVALUE;
    object _31414 = NOVALUE;
    object _31413 = NOVALUE;
    object _31412 = NOVALUE;
    object _31410 = NOVALUE;
    object _31407 = NOVALUE;
    object _31406 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_63953)) {
        _1 = (object)(DBL_PTR(_sym_63953)->dbl);
        DeRefDS(_sym_63953);
        _sym_63953 = _1;
    }

    /** fwdref.e:754			len = length( inactive_references )*/
    if (IS_SEQUENCE(_42inactive_references_62868)){
            _len_63956 = SEQ_PTR(_42inactive_references_62868)->length;
    }
    else {
        _len_63956 = 1;
    }

    /** fwdref.e:757		if len then*/
    if (_len_63956 == 0)
    {
        goto L1; // [16] 39
    }
    else{
    }

    /** fwdref.e:758			ref = inactive_references[len]*/
    _2 = (object)SEQ_PTR(_42inactive_references_62868);
    _ref_63955 = (object)*(((s1_ptr)_2)->base + _len_63956);
    if (!IS_ATOM_INT(_ref_63955))
    _ref_63955 = (object)DBL_PTR(_ref_63955)->dbl;

    /** fwdref.e:759			inactive_references = remove( inactive_references, len, len )*/
    {
        s1_ptr assign_space = SEQ_PTR(_42inactive_references_62868);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_len_63956)) ? _len_63956 : (object)(DBL_PTR(_len_63956)->dbl);
        int stop = (IS_ATOM_INT(_len_63956)) ? _len_63956 : (object)(DBL_PTR(_len_63956)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_42inactive_references_62868), start, &_42inactive_references_62868 );
            }
            else Tail(SEQ_PTR(_42inactive_references_62868), stop+1, &_42inactive_references_62868);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_42inactive_references_62868), start, &_42inactive_references_62868);
        }
        else {
            assign_slice_seq = &assign_space;
            _42inactive_references_62868 = Remove_elements(start, stop, (SEQ_PTR(_42inactive_references_62868)->ref == 1));
        }
    }
    goto L2; // [36] 55
L1: 

    /** fwdref.e:761			forward_references &= 0*/
    Append(&_42forward_references_62864, _42forward_references_62864, 0LL);

    /** fwdref.e:762			ref = length( forward_references )*/
    if (IS_SEQUENCE(_42forward_references_62864)){
            _ref_63955 = SEQ_PTR(_42forward_references_62864)->length;
    }
    else {
        _ref_63955 = 1;
    }
L2: 

    /** fwdref.e:764		forward_references[ref] = repeat( 0, FR_SIZE )*/
    _31406 = Repeat(0LL, 12LL);
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_62864 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _ref_63955);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31406;
    if( _1 != _31406 ){
        DeRef(_1);
    }
    _31406 = NOVALUE;

    /** fwdref.e:766		forward_references[ref][FR_TYPE]      = fwd_op*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_62864 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63955 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _fwd_op_63951;
    DeRef(_1);
    _31407 = NOVALUE;

    /** fwdref.e:767		if sym < 0 then*/
    if (_sym_63953 >= 0LL)
    goto L3; // [84] 143

    /** fwdref.e:768			forward_references[ref][FR_NAME] = forward_references[-sym][FR_NAME]*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_62864 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63955 + ((s1_ptr)_2)->base);
    if ((uintptr_t)_sym_63953 == (uintptr_t)HIGH_BITS){
        _31412 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31412 = - _sym_63953;
    }
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    if (!IS_ATOM_INT(_31412)){
        _31413 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31412)->dbl));
    }
    else{
        _31413 = (object)*(((s1_ptr)_2)->base + _31412);
    }
    _2 = (object)SEQ_PTR(_31413);
    _31414 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31413 = NOVALUE;
    Ref(_31414);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31414;
    if( _1 != _31414 ){
        DeRef(_1);
    }
    _31414 = NOVALUE;
    _31410 = NOVALUE;

    /** fwdref.e:769			forward_references[ref][FR_HASHVAL] = forward_references[-sym][FR_HASHVAL]*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_62864 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63955 + ((s1_ptr)_2)->base);
    if ((uintptr_t)_sym_63953 == (uintptr_t)HIGH_BITS){
        _31417 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31417 = - _sym_63953;
    }
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    if (!IS_ATOM_INT(_31417)){
        _31418 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31417)->dbl));
    }
    else{
        _31418 = (object)*(((s1_ptr)_2)->base + _31417);
    }
    _2 = (object)SEQ_PTR(_31418);
    _31419 = (object)*(((s1_ptr)_2)->base + 11LL);
    _31418 = NOVALUE;
    Ref(_31419);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31419;
    if( _1 != _31419 ){
        DeRef(_1);
    }
    _31419 = NOVALUE;
    _31415 = NOVALUE;
    goto L4; // [140] 242
L3: 

    /** fwdref.e:771			forward_references[ref][FR_NAME] = SymTab[sym][S_NAME]*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_62864 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63955 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31422 = (object)*(((s1_ptr)_2)->base + _sym_63953);
    _2 = (object)SEQ_PTR(_31422);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _31423 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _31423 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _31422 = NOVALUE;
    Ref(_31423);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31423;
    if( _1 != _31423 ){
        DeRef(_1);
    }
    _31423 = NOVALUE;
    _31420 = NOVALUE;

    /** fwdref.e:772			integer hashval = SymTab[sym][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31424 = (object)*(((s1_ptr)_2)->base + _sym_63953);
    _2 = (object)SEQ_PTR(_31424);
    _hashval_63986 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (!IS_ATOM_INT(_hashval_63986)){
        _hashval_63986 = (object)DBL_PTR(_hashval_63986)->dbl;
    }
    _31424 = NOVALUE;

    /** fwdref.e:773			if 0 = hashval then*/
    if (0LL != _hashval_63986)
    goto L5; // [186] 220

    /** fwdref.e:774				forward_references[ref][FR_HASHVAL] = hashfn( forward_references[ref][FR_NAME] )*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_62864 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63955 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    _31429 = (object)*(((s1_ptr)_2)->base + _ref_63955);
    _2 = (object)SEQ_PTR(_31429);
    _31430 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31429 = NOVALUE;
    Ref(_31430);
    _31431 = _53hashfn(_31430);
    _31430 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31431;
    if( _1 != _31431 ){
        DeRef(_1);
    }
    _31431 = NOVALUE;
    _31427 = NOVALUE;
    goto L6; // [217] 239
L5: 

    /** fwdref.e:776				forward_references[ref][FR_HASHVAL] = hashval*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_62864 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63955 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _hashval_63986;
    DeRef(_1);
    _31432 = NOVALUE;

    /** fwdref.e:777				remove_symbol( sym )*/
    _53remove_symbol(_sym_63953);
L6: 
L4: 

    /** fwdref.e:782		forward_references[ref][FR_FILE]      = current_file_no*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_62864 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63955 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12current_file_no_20226;
    DeRef(_1);
    _31434 = NOVALUE;

    /** fwdref.e:783		forward_references[ref][FR_SUBPROG]   = CurrentSub*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_62864 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63955 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12CurrentSub_20234;
    DeRef(_1);
    _31436 = NOVALUE;

    /** fwdref.e:785		if fwd_op != TYPE then*/
    if (_fwd_op_63951 == 504LL)
    goto L7; // [276] 303

    /** fwdref.e:786			forward_references[ref][FR_PC]        = length( Code ) + 1*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_62864 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63955 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_12Code_20315)){
            _31441 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _31441 = 1;
    }
    _31442 = _31441 + 1;
    _31441 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31442;
    if( _1 != _31442 ){
        DeRef(_1);
    }
    _31442 = NOVALUE;
    _31439 = NOVALUE;
L7: 

    /** fwdref.e:789		forward_references[ref][FR_LINE]      = fwd_line_number*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_62864 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63955 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12fwd_line_number_20228;
    DeRef(_1);
    _31443 = NOVALUE;

    /** fwdref.e:790		forward_references[ref][FR_THISLINE]  = ForwardLine*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_62864 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63955 + ((s1_ptr)_2)->base);
    Ref(_49ForwardLine_49313);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 7LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _49ForwardLine_49313;
    DeRef(_1);
    _31445 = NOVALUE;

    /** fwdref.e:791		forward_references[ref][FR_BP]        = forward_bp*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_62864 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63955 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 8LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _49forward_bp_49317;
    DeRef(_1);
    _31447 = NOVALUE;

    /** fwdref.e:792		forward_references[ref][FR_QUALIFIED] = get_qualified_fwd()*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_62864 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63955 + ((s1_ptr)_2)->base);
    _31451 = _61get_qualified_fwd();
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31451;
    if( _1 != _31451 ){
        DeRef(_1);
    }
    _31451 = NOVALUE;
    _31449 = NOVALUE;

    /** fwdref.e:793		forward_references[ref][FR_OP]        = op*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_62864 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63955 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _op_63954;
    DeRef(_1);
    _31452 = NOVALUE;

    /** fwdref.e:795		if op = GOTO then*/
    if (_op_63954 != 188LL)
    goto L8; // [381] 403

    /** fwdref.e:796			forward_references[ref][FR_DATA] = { sym }*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_62864 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63955 + ((s1_ptr)_2)->base);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _sym_63953;
    _31457 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31457;
    if( _1 != _31457 ){
        DeRef(_1);
    }
    _31457 = NOVALUE;
    _31455 = NOVALUE;
L8: 

    /** fwdref.e:803		if CurrentSub = TopLevelSub then*/
    if (_12CurrentSub_20234 != _12TopLevelSub_20233)
    goto L9; // [409] 471

    /** fwdref.e:804			if length( toplevel_references ) < current_file_no then*/
    if (IS_SEQUENCE(_42toplevel_references_62867)){
            _31459 = SEQ_PTR(_42toplevel_references_62867)->length;
    }
    else {
        _31459 = 1;
    }
    if (_31459 >= _12current_file_no_20226)
    goto LA; // [422] 450

    /** fwdref.e:805				toplevel_references &= repeat( {}, current_file_no - length( toplevel_references ) )*/
    if (IS_SEQUENCE(_42toplevel_references_62867)){
            _31461 = SEQ_PTR(_42toplevel_references_62867)->length;
    }
    else {
        _31461 = 1;
    }
    _31462 = _12current_file_no_20226 - _31461;
    _31461 = NOVALUE;
    _31463 = Repeat(_22024, _31462);
    _31462 = NOVALUE;
    Concat((object_ptr)&_42toplevel_references_62867, _42toplevel_references_62867, _31463);
    DeRefDS(_31463);
    _31463 = NOVALUE;
LA: 

    /** fwdref.e:807			toplevel_references[current_file_no] &= ref*/
    _2 = (object)SEQ_PTR(_42toplevel_references_62867);
    _31465 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    if (IS_SEQUENCE(_31465) && IS_ATOM(_ref_63955)) {
        Append(&_31466, _31465, _ref_63955);
    }
    else if (IS_ATOM(_31465) && IS_SEQUENCE(_ref_63955)) {
    }
    else {
        Concat((object_ptr)&_31466, _31465, _ref_63955);
        _31465 = NOVALUE;
    }
    _31465 = NOVALUE;
    _2 = (object)SEQ_PTR(_42toplevel_references_62867);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42toplevel_references_62867 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _12current_file_no_20226);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31466;
    if( _1 != _31466 ){
        DeRef(_1);
    }
    _31466 = NOVALUE;
    goto LB; // [468] 595
L9: 

    /** fwdref.e:809			add_active_reference( ref )*/
    _42add_active_reference(_ref_63955, _12current_file_no_20226);

    /** fwdref.e:811			if Parser_mode = PAM_RECORD then*/
    if (_12Parser_mode_20332 != 1LL)
    goto LC; // [485] 592

    /** fwdref.e:812				symtab_pointer default_sym = CurrentSub*/
    _default_sym_64061 = _12CurrentSub_20234;

    /** fwdref.e:813				symtab_pointer param = 0*/
    _param_64064 = 0LL;

    /** fwdref.e:814				while default_sym with entry do*/
    goto LD; // [507] 536
LE: 
    if (_default_sym_64061 == 0)
    {
        goto LF; // [510] 549
    }
    else{
    }

    /** fwdref.e:815					if sym_scope( default_sym ) = SC_PRIVATE then*/
    _31468 = _53sym_scope(_default_sym_64061);
    if (binary_op_a(NOTEQ, _31468, 3LL)){
        DeRef(_31468);
        _31468 = NOVALUE;
        goto L10; // [521] 533
    }
    DeRef(_31468);
    _31468 = NOVALUE;

    /** fwdref.e:816						param = default_sym*/
    _param_64064 = _default_sym_64061;
L10: 

    /** fwdref.e:818				entry*/
LD: 

    /** fwdref.e:819					default_sym = sym_next( default_sym )*/
    _default_sym_64061 = _53sym_next(_default_sym_64061);
    if (!IS_ATOM_INT(_default_sym_64061)) {
        _1 = (object)(DBL_PTR(_default_sym_64061)->dbl);
        DeRefDS(_default_sym_64061);
        _default_sym_64061 = _1;
    }

    /** fwdref.e:820				end while*/
    goto LE; // [546] 510
LF: 

    /** fwdref.e:821				set_data( ref, {{ PAM_RECORD, param, length( Recorded_sym ) }} )*/
    if (IS_SEQUENCE(_12Recorded_sym_20335)){
            _31471 = SEQ_PTR(_12Recorded_sym_20335)->length;
    }
    else {
        _31471 = 1;
    }
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = _param_64064;
    ((intptr_t*)_2)[3] = _31471;
    _31472 = MAKE_SEQ(_1);
    _31471 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _31472;
    _31473 = MAKE_SEQ(_1);
    _31472 = NOVALUE;
    DeRef(_data_inlined_set_data_at_575_64079);
    _data_inlined_set_data_at_575_64079 = _31473;
    _31473 = NOVALUE;

    /** fwdref.e:186		forward_references[ref][FR_DATA] = data*/
    _2 = (object)SEQ_PTR(_42forward_references_62864);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_62864 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63955 + ((s1_ptr)_2)->base);
    RefDS(_data_inlined_set_data_at_575_64079);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _data_inlined_set_data_at_575_64079;
    DeRef(_1);

    /** fwdref.e:187	end procedure*/
    goto L11; // [586] 589
L11: 
    DeRef(_data_inlined_set_data_at_575_64079);
    _data_inlined_set_data_at_575_64079 = NOVALUE;
LC: 
LB: 

    /** fwdref.e:824		fwdref_count += 1*/
    _42fwdref_count_62884 = _42fwdref_count_62884 + 1;

    /** fwdref.e:826		ifdef EUDIS then*/

    /** fwdref.e:839		return ref*/
    DeRef(_31412);
    _31412 = NOVALUE;
    DeRef(_31417);
    _31417 = NOVALUE;
    return _ref_63955;
    ;
}


void _42add_active_reference(object _ref_64085, object _file_no_64086)
{
    object _sp_64100 = NOVALUE;
    object _31497 = NOVALUE;
    object _31496 = NOVALUE;
    object _31494 = NOVALUE;
    object _31493 = NOVALUE;
    object _31492 = NOVALUE;
    object _31490 = NOVALUE;
    object _31489 = NOVALUE;
    object _31488 = NOVALUE;
    object _31485 = NOVALUE;
    object _31483 = NOVALUE;
    object _31482 = NOVALUE;
    object _31481 = NOVALUE;
    object _31479 = NOVALUE;
    object _31478 = NOVALUE;
    object _31477 = NOVALUE;
    object _31475 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:843		if length( active_references ) < file_no then*/
    if (IS_SEQUENCE(_42active_references_62866)){
            _31475 = SEQ_PTR(_42active_references_62866)->length;
    }
    else {
        _31475 = 1;
    }
    if (_31475 >= _file_no_64086)
    goto L1; // [12] 59

    /** fwdref.e:844			active_references &= repeat( {}, file_no - length( active_references ) )*/
    if (IS_SEQUENCE(_42active_references_62866)){
            _31477 = SEQ_PTR(_42active_references_62866)->length;
    }
    else {
        _31477 = 1;
    }
    _31478 = _file_no_64086 - _31477;
    _31477 = NOVALUE;
    _31479 = Repeat(_22024, _31478);
    _31478 = NOVALUE;
    Concat((object_ptr)&_42active_references_62866, _42active_references_62866, _31479);
    DeRefDS(_31479);
    _31479 = NOVALUE;

    /** fwdref.e:845			active_subprogs   &= repeat( {}, file_no - length( active_subprogs ) )*/
    if (IS_SEQUENCE(_42active_subprogs_62865)){
            _31481 = SEQ_PTR(_42active_subprogs_62865)->length;
    }
    else {
        _31481 = 1;
    }
    _31482 = _file_no_64086 - _31481;
    _31481 = NOVALUE;
    _31483 = Repeat(_22024, _31482);
    _31482 = NOVALUE;
    Concat((object_ptr)&_42active_subprogs_62865, _42active_subprogs_62865, _31483);
    DeRefDS(_31483);
    _31483 = NOVALUE;
L1: 

    /** fwdref.e:847		integer sp = find( CurrentSub, active_subprogs[file_no] )*/
    _2 = (object)SEQ_PTR(_42active_subprogs_62865);
    _31485 = (object)*(((s1_ptr)_2)->base + _file_no_64086);
    _sp_64100 = find_from(_12CurrentSub_20234, _31485, 1LL);
    _31485 = NOVALUE;

    /** fwdref.e:848		if not sp then*/
    if (_sp_64100 != 0)
    goto L2; // [76] 127

    /** fwdref.e:849			active_subprogs[file_no] &= CurrentSub*/
    _2 = (object)SEQ_PTR(_42active_subprogs_62865);
    _31488 = (object)*(((s1_ptr)_2)->base + _file_no_64086);
    if (IS_SEQUENCE(_31488) && IS_ATOM(_12CurrentSub_20234)) {
        Append(&_31489, _31488, _12CurrentSub_20234);
    }
    else if (IS_ATOM(_31488) && IS_SEQUENCE(_12CurrentSub_20234)) {
    }
    else {
        Concat((object_ptr)&_31489, _31488, _12CurrentSub_20234);
        _31488 = NOVALUE;
    }
    _31488 = NOVALUE;
    _2 = (object)SEQ_PTR(_42active_subprogs_62865);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42active_subprogs_62865 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_no_64086);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31489;
    if( _1 != _31489 ){
        DeRef(_1);
    }
    _31489 = NOVALUE;

    /** fwdref.e:850			sp = length( active_subprogs[file_no] )*/
    _2 = (object)SEQ_PTR(_42active_subprogs_62865);
    _31490 = (object)*(((s1_ptr)_2)->base + _file_no_64086);
    if (IS_SEQUENCE(_31490)){
            _sp_64100 = SEQ_PTR(_31490)->length;
    }
    else {
        _sp_64100 = 1;
    }
    _31490 = NOVALUE;

    /** fwdref.e:852			active_references[file_no] = append( active_references[file_no], {} )*/
    _2 = (object)SEQ_PTR(_42active_references_62866);
    _31492 = (object)*(((s1_ptr)_2)->base + _file_no_64086);
    RefDS(_22024);
    Append(&_31493, _31492, _22024);
    _31492 = NOVALUE;
    _2 = (object)SEQ_PTR(_42active_references_62866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42active_references_62866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_no_64086);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31493;
    if( _1 != _31493 ){
        DeRef(_1);
    }
    _31493 = NOVALUE;
L2: 

    /** fwdref.e:854		active_references[file_no][sp] &= ref*/
    _2 = (object)SEQ_PTR(_42active_references_62866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42active_references_62866 = MAKE_SEQ(_2);
    }
    _3 = (object)(_file_no_64086 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _31496 = (object)*(((s1_ptr)_2)->base + _sp_64100);
    _31494 = NOVALUE;
    if (IS_SEQUENCE(_31496) && IS_ATOM(_ref_64085)) {
        Append(&_31497, _31496, _ref_64085);
    }
    else if (IS_ATOM(_31496) && IS_SEQUENCE(_ref_64085)) {
    }
    else {
        Concat((object_ptr)&_31497, _31496, _ref_64085);
        _31496 = NOVALUE;
    }
    _31496 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _sp_64100);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31497;
    if( _1 != _31497 ){
        DeRef(_1);
    }
    _31497 = NOVALUE;
    _31494 = NOVALUE;

    /** fwdref.e:855	end procedure*/
    _31490 = NOVALUE;
    return;
    ;
}


object _42resolve_file(object _refs_64137, object _report_errors_64138, object _unincluded_ok_64139)
{
    object _errors_64140 = NOVALUE;
    object _ref_64144 = NOVALUE;
    object _fr_64146 = NOVALUE;
    object _tok_64159 = NOVALUE;
    object _code_sub_64167 = NOVALUE;
    object _fr_type_64169 = NOVALUE;
    object _sym_tok_64171 = NOVALUE;
    object _31551 = NOVALUE;
    object _31550 = NOVALUE;
    object _31549 = NOVALUE;
    object _31548 = NOVALUE;
    object _31547 = NOVALUE;
    object _31546 = NOVALUE;
    object _31541 = NOVALUE;
    object _31540 = NOVALUE;
    object _31539 = NOVALUE;
    object _31537 = NOVALUE;
    object _31536 = NOVALUE;
    object _31533 = NOVALUE;
    object _31532 = NOVALUE;
    object _31531 = NOVALUE;
    object _31527 = NOVALUE;
    object _31526 = NOVALUE;
    object _31518 = NOVALUE;
    object _31516 = NOVALUE;
    object _31515 = NOVALUE;
    object _31514 = NOVALUE;
    object _31513 = NOVALUE;
    object _31512 = NOVALUE;
    object _31511 = NOVALUE;
    object _31508 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:864		sequence errors = {}*/
    RefDS(_22024);
    DeRefi(_errors_64140);
    _errors_64140 = _22024;

    /** fwdref.e:865		for ar = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_64137)){
            _31508 = SEQ_PTR(_refs_64137)->length;
    }
    else {
        _31508 = 1;
    }
    {
        object _ar_64142;
        _ar_64142 = _31508;
L1: 
        if (_ar_64142 < 1LL){
            goto L2; // [19] 481
        }

        /** fwdref.e:866			integer ref = refs[ar]*/
        _2 = (object)SEQ_PTR(_refs_64137);
        _ref_64144 = (object)*(((s1_ptr)_2)->base + _ar_64142);
        if (!IS_ATOM_INT(_ref_64144))
        _ref_64144 = (object)DBL_PTR(_ref_64144)->dbl;

        /** fwdref.e:868			sequence fr = forward_references[ref]*/
        DeRef(_fr_64146);
        _2 = (object)SEQ_PTR(_42forward_references_62864);
        _fr_64146 = (object)*(((s1_ptr)_2)->base + _ref_64144);
        Ref(_fr_64146);

        /** fwdref.e:869			if include_matrix[fr[FR_FILE]][current_file_no] = NOT_INCLUDED and not unincluded_ok then*/
        _2 = (object)SEQ_PTR(_fr_64146);
        _31511 = (object)*(((s1_ptr)_2)->base + 3LL);
        _2 = (object)SEQ_PTR(_13include_matrix_11323);
        if (!IS_ATOM_INT(_31511)){
            _31512 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31511)->dbl));
        }
        else{
            _31512 = (object)*(((s1_ptr)_2)->base + _31511);
        }
        _2 = (object)SEQ_PTR(_31512);
        _31513 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
        _31512 = NOVALUE;
        if (IS_ATOM_INT(_31513)) {
            _31514 = (_31513 == 0LL);
        }
        else {
            _31514 = binary_op(EQUALS, _31513, 0LL);
        }
        _31513 = NOVALUE;
        if (IS_ATOM_INT(_31514)) {
            if (_31514 == 0) {
                goto L3; // [66] 84
            }
        }
        else {
            if (DBL_PTR(_31514)->dbl == 0.0) {
                goto L3; // [66] 84
            }
        }
        _31516 = (_unincluded_ok_64139 == 0);
        if (_31516 == 0)
        {
            DeRef(_31516);
            _31516 = NOVALUE;
            goto L3; // [74] 84
        }
        else{
            DeRef(_31516);
            _31516 = NOVALUE;
        }

        /** fwdref.e:870				continue*/
        DeRef(_fr_64146);
        _fr_64146 = NOVALUE;
        DeRef(_tok_64159);
        _tok_64159 = NOVALUE;
        goto L4; // [81] 476
L3: 

        /** fwdref.e:873			token tok = find_reference( fr )*/
        RefDS(_fr_64146);
        _0 = _tok_64159;
        _tok_64159 = _42find_reference(_fr_64146);
        DeRef(_0);

        /** fwdref.e:874			if tok[T_ID] = IGNORED then*/
        _2 = (object)SEQ_PTR(_tok_64159);
        _31518 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _31518, 509LL)){
            _31518 = NOVALUE;
            goto L5; // [100] 117
        }
        _31518 = NOVALUE;

        /** fwdref.e:875				errors &= ref*/
        Append(&_errors_64140, _errors_64140, _ref_64144);

        /** fwdref.e:876				continue*/
        DeRefDS(_fr_64146);
        _fr_64146 = NOVALUE;
        DeRef(_tok_64159);
        _tok_64159 = NOVALUE;
        goto L4; // [114] 476
L5: 

        /** fwdref.e:880			integer code_sub = fr[FR_SUBPROG]*/
        _2 = (object)SEQ_PTR(_fr_64146);
        _code_sub_64167 = (object)*(((s1_ptr)_2)->base + 4LL);
        if (!IS_ATOM_INT(_code_sub_64167))
        _code_sub_64167 = (object)DBL_PTR(_code_sub_64167)->dbl;

        /** fwdref.e:881			integer fr_type  = fr[FR_TYPE]*/
        _2 = (object)SEQ_PTR(_fr_64146);
        _fr_type_64169 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (!IS_ATOM_INT(_fr_type_64169))
        _fr_type_64169 = (object)DBL_PTR(_fr_type_64169)->dbl;

        /** fwdref.e:882			integer sym_tok*/

        /** fwdref.e:884			switch fr_type label "fr_type" do*/
        _0 = _fr_type_64169;
        switch ( _0 ){ 

            /** fwdref.e:885				case PROC, FUNC then*/
            case 27:
            case 501:

            /** fwdref.e:887					sym_tok = SymTab[tok[T_SYM]][S_TOKEN]*/
            _2 = (object)SEQ_PTR(_tok_64159);
            _31526 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            if (!IS_ATOM_INT(_31526)){
                _31527 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31526)->dbl));
            }
            else{
                _31527 = (object)*(((s1_ptr)_2)->base + _31526);
            }
            _2 = (object)SEQ_PTR(_31527);
            if (!IS_ATOM_INT(_12S_TOKEN_19869)){
                _sym_tok_64171 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
            }
            else{
                _sym_tok_64171 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
            }
            if (!IS_ATOM_INT(_sym_tok_64171)){
                _sym_tok_64171 = (object)DBL_PTR(_sym_tok_64171)->dbl;
            }
            _31527 = NOVALUE;

            /** fwdref.e:888					if sym_tok = TYPE then*/
            if (_sym_tok_64171 != 504LL)
            goto L6; // [170] 184

            /** fwdref.e:889						sym_tok = FUNC*/
            _sym_tok_64171 = 501LL;
L6: 

            /** fwdref.e:891					if sym_tok != fr_type then*/
            if (_sym_tok_64171 == _fr_type_64169)
            goto L7; // [186] 220

            /** fwdref.e:892						if sym_tok != FUNC and fr_type != PROC then*/
            _31531 = (_sym_tok_64171 != 501LL);
            if (_31531 == 0) {
                goto L8; // [198] 219
            }
            _31533 = (_fr_type_64169 != 27LL);
            if (_31533 == 0)
            {
                DeRef(_31533);
                _31533 = NOVALUE;
                goto L8; // [209] 219
            }
            else{
                DeRef(_31533);
                _31533 = NOVALUE;
            }

            /** fwdref.e:893							forward_error( tok, ref )*/
            Ref(_tok_64159);
            _42forward_error(_tok_64159, _ref_64144);
L8: 
L7: 

            /** fwdref.e:896					switch sym_tok do*/
            _0 = _sym_tok_64171;
            switch ( _0 ){ 

                /** fwdref.e:897						case PROC, FUNC then*/
                case 27:
                case 501:

                /** fwdref.e:898							patch_forward_call( tok, ref )*/
                Ref(_tok_64159);
                _42patch_forward_call(_tok_64159, _ref_64144);

                /** fwdref.e:899							break "fr_type"*/
                goto L9; // [241] 446
                goto L9; // [243] 446

                /** fwdref.e:901						case else*/
                default:

                /** fwdref.e:902							forward_error( tok, ref )*/
                Ref(_tok_64159);
                _42forward_error(_tok_64159, _ref_64144);
            ;}            goto L9; // [256] 446

            /** fwdref.e:906				case VARIABLE then*/
            case -100:

            /** fwdref.e:907					sym_tok = SymTab[tok[T_SYM]][S_TOKEN]*/
            _2 = (object)SEQ_PTR(_tok_64159);
            _31536 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            if (!IS_ATOM_INT(_31536)){
                _31537 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31536)->dbl));
            }
            else{
                _31537 = (object)*(((s1_ptr)_2)->base + _31536);
            }
            _2 = (object)SEQ_PTR(_31537);
            if (!IS_ATOM_INT(_12S_TOKEN_19869)){
                _sym_tok_64171 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
            }
            else{
                _sym_tok_64171 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
            }
            if (!IS_ATOM_INT(_sym_tok_64171)){
                _sym_tok_64171 = (object)DBL_PTR(_sym_tok_64171)->dbl;
            }
            _31537 = NOVALUE;

            /** fwdref.e:908					if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
            _2 = (object)SEQ_PTR(_tok_64159);
            _31539 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_13SymTab_11316);
            if (!IS_ATOM_INT(_31539)){
                _31540 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31539)->dbl));
            }
            else{
                _31540 = (object)*(((s1_ptr)_2)->base + _31539);
            }
            _2 = (object)SEQ_PTR(_31540);
            _31541 = (object)*(((s1_ptr)_2)->base + 4LL);
            _31540 = NOVALUE;
            if (binary_op_a(NOTEQ, _31541, 9LL)){
                _31541 = NOVALUE;
                goto LA; // [306] 323
            }
            _31541 = NOVALUE;

            /** fwdref.e:909						errors &= ref*/
            Append(&_errors_64140, _errors_64140, _ref_64144);

            /** fwdref.e:910						continue*/
            DeRef(_fr_64146);
            _fr_64146 = NOVALUE;
            DeRef(_tok_64159);
            _tok_64159 = NOVALUE;
            goto L4; // [320] 476
LA: 

            /** fwdref.e:913					switch sym_tok do*/
            _0 = _sym_tok_64171;
            switch ( _0 ){ 

                /** fwdref.e:914						case CONSTANT, ENUM, VARIABLE then*/
                case 417:
                case 427:
                case -100:

                /** fwdref.e:915							patch_forward_variable( tok, ref )*/
                Ref(_tok_64159);
                _42patch_forward_variable(_tok_64159, _ref_64144);

                /** fwdref.e:916							break "fr_type"*/
                goto L9; // [346] 446
                goto L9; // [348] 446

                /** fwdref.e:917						case else*/
                default:

                /** fwdref.e:918							forward_error( tok, ref )*/
                Ref(_tok_64159);
                _42forward_error(_tok_64159, _ref_64144);
            ;}            goto L9; // [361] 446

            /** fwdref.e:921				case TYPE_CHECK then*/
            case 65:

            /** fwdref.e:922					patch_forward_type_check( tok, ref )*/
            Ref(_tok_64159);
            _42patch_forward_type_check(_tok_64159, _ref_64144);
            goto L9; // [373] 446

            /** fwdref.e:924				case GLOBAL_INIT_CHECK then*/
            case 109:

            /** fwdref.e:925					patch_forward_init_check( tok, ref )*/
            Ref(_tok_64159);
            _42patch_forward_init_check(_tok_64159, _ref_64144);
            goto L9; // [385] 446

            /** fwdref.e:927				case CASE then*/
            case 186:

            /** fwdref.e:928					patch_forward_case( tok, ref )*/
            Ref(_tok_64159);
            _42patch_forward_case(_tok_64159, _ref_64144);
            goto L9; // [397] 446

            /** fwdref.e:930				case TYPE then*/
            case 504:

            /** fwdref.e:931					patch_forward_type( tok, ref )*/
            Ref(_tok_64159);
            _42patch_forward_type(_tok_64159, _ref_64144);
            goto L9; // [409] 446

            /** fwdref.e:933				case GOTO then*/
            case 188:

            /** fwdref.e:934					patch_forward_goto( tok, ref )*/
            Ref(_tok_64159);
            _42patch_forward_goto(_tok_64159, _ref_64144);
            goto L9; // [421] 446

            /** fwdref.e:936				case else*/
            default:

            /** fwdref.e:938					InternalErr( 263, {fr[FR_TYPE], fr[FR_NAME]})*/
            _2 = (object)SEQ_PTR(_fr_64146);
            _31546 = (object)*(((s1_ptr)_2)->base + 1LL);
            _2 = (object)SEQ_PTR(_fr_64146);
            _31547 = (object)*(((s1_ptr)_2)->base + 2LL);
            Ref(_31547);
            Ref(_31546);
            _1 = NewS1(2);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t *)_2)[1] = _31546;
            ((intptr_t *)_2)[2] = _31547;
            _31548 = MAKE_SEQ(_1);
            _31547 = NOVALUE;
            _31546 = NOVALUE;
            _49InternalErr(263LL, _31548);
            _31548 = NOVALUE;
        ;}L9: 

        /** fwdref.e:940			if report_errors and sequence( forward_references[ref] ) then*/
        if (_report_errors_64138 == 0) {
            goto LB; // [448] 472
        }
        _2 = (object)SEQ_PTR(_42forward_references_62864);
        _31550 = (object)*(((s1_ptr)_2)->base + _ref_64144);
        _31551 = IS_SEQUENCE(_31550);
        _31550 = NOVALUE;
        if (_31551 == 0)
        {
            _31551 = NOVALUE;
            goto LB; // [462] 472
        }
        else{
            _31551 = NOVALUE;
        }

        /** fwdref.e:941				errors &= ref*/
        Append(&_errors_64140, _errors_64140, _ref_64144);
LB: 
        DeRef(_fr_64146);
        _fr_64146 = NOVALUE;
        DeRef(_tok_64159);
        _tok_64159 = NOVALUE;

        /** fwdref.e:944		end for*/
L4: 
        _ar_64142 = _ar_64142 + -1LL;
        goto L1; // [476] 26
L2: 
        ;
    }

    /** fwdref.e:945		return errors*/
    DeRefDS(_refs_64137);
    _31539 = NOVALUE;
    _31526 = NOVALUE;
    _31511 = NOVALUE;
    DeRef(_31531);
    _31531 = NOVALUE;
    _31536 = NOVALUE;
    DeRef(_31514);
    _31514 = NOVALUE;
    return _errors_64140;
    ;
}


object _42file_name_based_symindex_compare(object _si1_64249, object _si2_64250)
{
    object _fn1_64271 = NOVALUE;
    object _fn2_64276 = NOVALUE;
    object _31580 = NOVALUE;
    object _31579 = NOVALUE;
    object _31578 = NOVALUE;
    object _31577 = NOVALUE;
    object _31576 = NOVALUE;
    object _31575 = NOVALUE;
    object _31574 = NOVALUE;
    object _31573 = NOVALUE;
    object _31572 = NOVALUE;
    object _31571 = NOVALUE;
    object _31570 = NOVALUE;
    object _31569 = NOVALUE;
    object _31567 = NOVALUE;
    object _31565 = NOVALUE;
    object _31564 = NOVALUE;
    object _31563 = NOVALUE;
    object _31562 = NOVALUE;
    object _31561 = NOVALUE;
    object _31560 = NOVALUE;
    object _31559 = NOVALUE;
    object _31558 = NOVALUE;
    object _31557 = NOVALUE;
    object _31556 = NOVALUE;
    object _31554 = NOVALUE;
    object _31553 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_si1_64249)) {
        _1 = (object)(DBL_PTR(_si1_64249)->dbl);
        DeRefDS(_si1_64249);
        _si1_64249 = _1;
    }
    if (!IS_ATOM_INT(_si2_64250)) {
        _1 = (object)(DBL_PTR(_si2_64250)->dbl);
        DeRefDS(_si2_64250);
        _si2_64250 = _1;
    }

    /** fwdref.e:949		if not symtab_index(si1) or not symtab_index(si2) then*/
    _31553 = _12symtab_index(_si1_64249);
    if (IS_ATOM_INT(_31553)) {
        _31554 = (_31553 == 0);
    }
    else {
        _31554 = unary_op(NOT, _31553);
    }
    DeRef(_31553);
    _31553 = NOVALUE;
    if (IS_ATOM_INT(_31554)) {
        if (_31554 != 0) {
            goto L1; // [14] 30
        }
    }
    else {
        if (DBL_PTR(_31554)->dbl != 0.0) {
            goto L1; // [14] 30
        }
    }
    _31556 = _12symtab_index(_si2_64250);
    if (IS_ATOM_INT(_31556)) {
        _31557 = (_31556 == 0);
    }
    else {
        _31557 = unary_op(NOT, _31556);
    }
    DeRef(_31556);
    _31556 = NOVALUE;
    if (_31557 == 0) {
        DeRef(_31557);
        _31557 = NOVALUE;
        goto L2; // [26] 37
    }
    else {
        if (!IS_ATOM_INT(_31557) && DBL_PTR(_31557)->dbl == 0.0){
            DeRef(_31557);
            _31557 = NOVALUE;
            goto L2; // [26] 37
        }
        DeRef(_31557);
        _31557 = NOVALUE;
    }
    DeRef(_31557);
    _31557 = NOVALUE;
L1: 

    /** fwdref.e:950			return 1 -- put non symbols last*/
    DeRef(_31554);
    _31554 = NOVALUE;
    return 1LL;
L2: 

    /** fwdref.e:952		if S_FILE_NO <= length(SymTab[si1]) and S_FILE_NO <= length(SymTab[si2]) then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31558 = (object)*(((s1_ptr)_2)->base + _si1_64249);
    if (IS_SEQUENCE(_31558)){
            _31559 = SEQ_PTR(_31558)->length;
    }
    else {
        _31559 = 1;
    }
    _31558 = NOVALUE;
    if (IS_ATOM_INT(_12S_FILE_NO_19860)) {
        _31560 = (_12S_FILE_NO_19860 <= _31559);
    }
    else {
        _31560 = binary_op(LESSEQ, _12S_FILE_NO_19860, _31559);
    }
    _31559 = NOVALUE;
    if (IS_ATOM_INT(_31560)) {
        if (_31560 == 0) {
            goto L3; // [54] 186
        }
    }
    else {
        if (DBL_PTR(_31560)->dbl == 0.0) {
            goto L3; // [54] 186
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31562 = (object)*(((s1_ptr)_2)->base + _si2_64250);
    if (IS_SEQUENCE(_31562)){
            _31563 = SEQ_PTR(_31562)->length;
    }
    else {
        _31563 = 1;
    }
    _31562 = NOVALUE;
    if (IS_ATOM_INT(_12S_FILE_NO_19860)) {
        _31564 = (_12S_FILE_NO_19860 <= _31563);
    }
    else {
        _31564 = binary_op(LESSEQ, _12S_FILE_NO_19860, _31563);
    }
    _31563 = NOVALUE;
    if (_31564 == 0) {
        DeRef(_31564);
        _31564 = NOVALUE;
        goto L3; // [74] 186
    }
    else {
        if (!IS_ATOM_INT(_31564) && DBL_PTR(_31564)->dbl == 0.0){
            DeRef(_31564);
            _31564 = NOVALUE;
            goto L3; // [74] 186
        }
        DeRef(_31564);
        _31564 = NOVALUE;
    }
    DeRef(_31564);
    _31564 = NOVALUE;

    /** fwdref.e:953			integer fn1 = SymTab[si1][S_FILE_NO], fn2 = SymTab[si2][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31565 = (object)*(((s1_ptr)_2)->base + _si1_64249);
    _2 = (object)SEQ_PTR(_31565);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _fn1_64271 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _fn1_64271 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    if (!IS_ATOM_INT(_fn1_64271)){
        _fn1_64271 = (object)DBL_PTR(_fn1_64271)->dbl;
    }
    _31565 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31567 = (object)*(((s1_ptr)_2)->base + _si2_64250);
    _2 = (object)SEQ_PTR(_31567);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _fn2_64276 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _fn2_64276 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    if (!IS_ATOM_INT(_fn2_64276)){
        _fn2_64276 = (object)DBL_PTR(_fn2_64276)->dbl;
    }
    _31567 = NOVALUE;

    /** fwdref.e:954			if find(1,{fn1,fn2} > length(known_files) or {fn1,fn2} <= 0) then*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _fn1_64271;
    ((intptr_t *)_2)[2] = _fn2_64276;
    _31569 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_13known_files_11317)){
            _31570 = SEQ_PTR(_13known_files_11317)->length;
    }
    else {
        _31570 = 1;
    }
    _31571 = binary_op(GREATER, _31569, _31570);
    DeRefDS(_31569);
    _31569 = NOVALUE;
    _31570 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _fn1_64271;
    ((intptr_t *)_2)[2] = _fn2_64276;
    _31572 = MAKE_SEQ(_1);
    _31573 = binary_op(LESSEQ, _31572, 0LL);
    DeRefDS(_31572);
    _31572 = NOVALUE;
    _31574 = binary_op(OR, _31571, _31573);
    DeRefDS(_31571);
    _31571 = NOVALUE;
    DeRefDS(_31573);
    _31573 = NOVALUE;
    _31575 = find_from(1LL, _31574, 1LL);
    DeRefDS(_31574);
    _31574 = NOVALUE;
    if (_31575 == 0)
    {
        _31575 = NOVALUE;
        goto L4; // [139] 149
    }
    else{
        _31575 = NOVALUE;
    }

    /** fwdref.e:956				return 1*/
    _31562 = NOVALUE;
    DeRef(_31560);
    _31560 = NOVALUE;
    _31558 = NOVALUE;
    DeRef(_31554);
    _31554 = NOVALUE;
    return 1LL;
L4: 

    /** fwdref.e:958			return compare(abbreviate_path(known_files[fn1]),*/
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _31576 = (object)*(((s1_ptr)_2)->base + _fn1_64271);
    Ref(_31576);
    RefDS(_22024);
    _31577 = _14abbreviate_path(_31576, _22024);
    _31576 = NOVALUE;
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _31578 = (object)*(((s1_ptr)_2)->base + _fn2_64276);
    Ref(_31578);
    RefDS(_22024);
    _31579 = _14abbreviate_path(_31578, _22024);
    _31578 = NOVALUE;
    if (IS_ATOM_INT(_31577) && IS_ATOM_INT(_31579)){
        _31580 = (_31577 < _31579) ? -1 : (_31577 > _31579);
    }
    else{
        _31580 = compare(_31577, _31579);
    }
    DeRef(_31577);
    _31577 = NOVALUE;
    DeRef(_31579);
    _31579 = NOVALUE;
    _31562 = NOVALUE;
    DeRef(_31560);
    _31560 = NOVALUE;
    _31558 = NOVALUE;
    DeRef(_31554);
    _31554 = NOVALUE;
    return _31580;
    goto L5; // [183] 193
L3: 

    /** fwdref.e:961			return 1 -- put non-names last*/
    _31562 = NOVALUE;
    DeRef(_31560);
    _31560 = NOVALUE;
    _31558 = NOVALUE;
    DeRef(_31554);
    _31554 = NOVALUE;
    return 1LL;
L5: 
    ;
}


void _42Resolve_forward_references(object _report_errors_64302)
{
    object _errors_64303 = NOVALUE;
    object _unincluded_ok_64304 = NOVALUE;
    object _msg_64365 = NOVALUE;
    object _errloc_64366 = NOVALUE;
    object _ref_64371 = NOVALUE;
    object _tok_64387 = NOVALUE;
    object _THIS_SCOPE_64389 = NOVALUE;
    object _THESE_GLOBALS_64390 = NOVALUE;
    object _syms_64448 = NOVALUE;
    object _s_64469 = NOVALUE;
    object _31713 = NOVALUE;
    object _31712 = NOVALUE;
    object _31711 = NOVALUE;
    object _31709 = NOVALUE;
    object _31704 = NOVALUE;
    object _31701 = NOVALUE;
    object _31699 = NOVALUE;
    object _31698 = NOVALUE;
    object _31697 = NOVALUE;
    object _31696 = NOVALUE;
    object _31695 = NOVALUE;
    object _31694 = NOVALUE;
    object _31693 = NOVALUE;
    object _31691 = NOVALUE;
    object _31690 = NOVALUE;
    object _31689 = NOVALUE;
    object _31687 = NOVALUE;
    object _31685 = NOVALUE;
    object _31684 = NOVALUE;
    object _31683 = NOVALUE;
    object _31682 = NOVALUE;
    object _31681 = NOVALUE;
    object _31680 = NOVALUE;
    object _31677 = NOVALUE;
    object _31673 = NOVALUE;
    object _31672 = NOVALUE;
    object _31671 = NOVALUE;
    object _31670 = NOVALUE;
    object _31669 = NOVALUE;
    object _31668 = NOVALUE;
    object _31665 = NOVALUE;
    object _31664 = NOVALUE;
    object _31663 = NOVALUE;
    object _31662 = NOVALUE;
    object _31661 = NOVALUE;
    object _31660 = NOVALUE;
    object _31657 = NOVALUE;
    object _31656 = NOVALUE;
    object _31655 = NOVALUE;
    object _31654 = NOVALUE;
    object _31653 = NOVALUE;
    object _31652 = NOVALUE;
    object _31651 = NOVALUE;
    object _31650 = NOVALUE;
    object _31649 = NOVALUE;
    object _31648 = NOVALUE;
    object _31645 = NOVALUE;
    object _31643 = NOVALUE;
    object _31640 = NOVALUE;
    object _31638 = NOVALUE;
    object _31636 = NOVALUE;
    object _31635 = NOVALUE;
    object _31633 = NOVALUE;
    object _31632 = NOVALUE;
    object _31631 = NOVALUE;
    object _31630 = NOVALUE;
    object _31629 = NOVALUE;
    object _31627 = NOVALUE;
    object _31626 = NOVALUE;
    object _31624 = NOVALUE;
    object _31623 = NOVALUE;
    object _31621 = NOVALUE;
    object _31620 = NOVALUE;
    object _31618 = NOVALUE;
    object _31617 = NOVALUE;
    object _31616 = NOVALUE;
    object _31615 = NOVALUE;
    object _31614 = NOVALUE;
    object _31613 = NOVALUE;
    object _31612 = NOVALUE;
    object _31611 = NOVALUE;
    object _31610 = NOVALUE;
    object _31609 = NOVALUE;
    object _31608 = NOVALUE;
    object _31607 = NOVALUE;
    object _31606 = NOVALUE;
    object _31605 = NOVALUE;
    object _31604 = NOVALUE;
    object _31603 = NOVALUE;
    object _31601 = NOVALUE;
    object _31600 = NOVALUE;
    object _31599 = NOVALUE;
    object _31598 = NOVALUE;
    object _31596 = NOVALUE;
    object _31595 = NOVALUE;
    object _31593 = NOVALUE;
    object _31592 = NOVALUE;
    object _31591 = NOVALUE;
    object _31590 = NOVALUE;
    object _31588 = NOVALUE;
    object _31587 = NOVALUE;
    object _31586 = NOVALUE;
    object _31585 = NOVALUE;
    object _31583 = NOVALUE;
    object _31582 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:966		sequence errors = {}*/
    RefDS(_22024);
    DeRef(_errors_64303);
    _errors_64303 = _22024;

    /** fwdref.e:967		integer unincluded_ok = get_resolve_unincluded_globals()*/
    _unincluded_ok_64304 = _53get_resolve_unincluded_globals();
    if (!IS_ATOM_INT(_unincluded_ok_64304)) {
        _1 = (object)(DBL_PTR(_unincluded_ok_64304)->dbl);
        DeRefDS(_unincluded_ok_64304);
        _unincluded_ok_64304 = _1;
    }

    /** fwdref.e:969		if length( active_references ) < length( known_files ) then*/
    if (IS_SEQUENCE(_42active_references_62866)){
            _31582 = SEQ_PTR(_42active_references_62866)->length;
    }
    else {
        _31582 = 1;
    }
    if (IS_SEQUENCE(_13known_files_11317)){
            _31583 = SEQ_PTR(_13known_files_11317)->length;
    }
    else {
        _31583 = 1;
    }
    if (_31582 >= _31583)
    goto L1; // [29] 86

    /** fwdref.e:970			active_references &= repeat( {}, length( known_files ) - length( active_references ) )*/
    if (IS_SEQUENCE(_13known_files_11317)){
            _31585 = SEQ_PTR(_13known_files_11317)->length;
    }
    else {
        _31585 = 1;
    }
    if (IS_SEQUENCE(_42active_references_62866)){
            _31586 = SEQ_PTR(_42active_references_62866)->length;
    }
    else {
        _31586 = 1;
    }
    _31587 = _31585 - _31586;
    _31585 = NOVALUE;
    _31586 = NOVALUE;
    _31588 = Repeat(_22024, _31587);
    _31587 = NOVALUE;
    Concat((object_ptr)&_42active_references_62866, _42active_references_62866, _31588);
    DeRefDS(_31588);
    _31588 = NOVALUE;

    /** fwdref.e:971			active_subprogs   &= repeat( {}, length( known_files ) - length( active_subprogs ) )*/
    if (IS_SEQUENCE(_13known_files_11317)){
            _31590 = SEQ_PTR(_13known_files_11317)->length;
    }
    else {
        _31590 = 1;
    }
    if (IS_SEQUENCE(_42active_subprogs_62865)){
            _31591 = SEQ_PTR(_42active_subprogs_62865)->length;
    }
    else {
        _31591 = 1;
    }
    _31592 = _31590 - _31591;
    _31590 = NOVALUE;
    _31591 = NOVALUE;
    _31593 = Repeat(_22024, _31592);
    _31592 = NOVALUE;
    Concat((object_ptr)&_42active_subprogs_62865, _42active_subprogs_62865, _31593);
    DeRefDS(_31593);
    _31593 = NOVALUE;
L1: 

    /** fwdref.e:974		if length( toplevel_references ) < length( known_files ) then*/
    if (IS_SEQUENCE(_42toplevel_references_62867)){
            _31595 = SEQ_PTR(_42toplevel_references_62867)->length;
    }
    else {
        _31595 = 1;
    }
    if (IS_SEQUENCE(_13known_files_11317)){
            _31596 = SEQ_PTR(_13known_files_11317)->length;
    }
    else {
        _31596 = 1;
    }
    if (_31595 >= _31596)
    goto L2; // [98] 129

    /** fwdref.e:975			toplevel_references &= repeat( {}, length( known_files ) - length( toplevel_references ) )*/
    if (IS_SEQUENCE(_13known_files_11317)){
            _31598 = SEQ_PTR(_13known_files_11317)->length;
    }
    else {
        _31598 = 1;
    }
    if (IS_SEQUENCE(_42toplevel_references_62867)){
            _31599 = SEQ_PTR(_42toplevel_references_62867)->length;
    }
    else {
        _31599 = 1;
    }
    _31600 = _31598 - _31599;
    _31598 = NOVALUE;
    _31599 = NOVALUE;
    _31601 = Repeat(_22024, _31600);
    _31600 = NOVALUE;
    Concat((object_ptr)&_42toplevel_references_62867, _42toplevel_references_62867, _31601);
    DeRefDS(_31601);
    _31601 = NOVALUE;
L2: 

    /** fwdref.e:978		for i = 1 to length( active_subprogs ) do*/
    if (IS_SEQUENCE(_42active_subprogs_62865)){
            _31603 = SEQ_PTR(_42active_subprogs_62865)->length;
    }
    else {
        _31603 = 1;
    }
    {
        object _i_64336;
        _i_64336 = 1LL;
L3: 
        if (_i_64336 > _31603){
            goto L4; // [136] 280
        }

        /** fwdref.e:979			if (length( active_subprogs[i] ) or length(toplevel_references[i])) */
        _2 = (object)SEQ_PTR(_42active_subprogs_62865);
        _31604 = (object)*(((s1_ptr)_2)->base + _i_64336);
        if (IS_SEQUENCE(_31604)){
                _31605 = SEQ_PTR(_31604)->length;
        }
        else {
            _31605 = 1;
        }
        _31604 = NOVALUE;
        if (_31605 != 0) {
            _31606 = 1;
            goto L5; // [154] 171
        }
        _2 = (object)SEQ_PTR(_42toplevel_references_62867);
        _31607 = (object)*(((s1_ptr)_2)->base + _i_64336);
        if (IS_SEQUENCE(_31607)){
                _31608 = SEQ_PTR(_31607)->length;
        }
        else {
            _31608 = 1;
        }
        _31607 = NOVALUE;
        _31606 = (_31608 != 0);
L5: 
        if (_31606 == 0) {
            goto L6; // [171] 273
        }
        _31610 = (_i_64336 == _12current_file_no_20226);
        if (_31610 != 0) {
            _31611 = 1;
            goto L7; // [181] 195
        }
        _2 = (object)SEQ_PTR(_13finished_files_11319);
        _31612 = (object)*(((s1_ptr)_2)->base + _i_64336);
        _31611 = (_31612 != 0);
L7: 
        if (_31611 != 0) {
            DeRef(_31613);
            _31613 = 1;
            goto L8; // [195] 203
        }
        _31613 = (_unincluded_ok_64304 != 0);
L8: 
        if (_31613 == 0)
        {
            _31613 = NOVALUE;
            goto L6; // [204] 273
        }
        else{
            _31613 = NOVALUE;
        }

        /** fwdref.e:982				for j = length( active_references[i] ) to 1 by -1 do*/
        _2 = (object)SEQ_PTR(_42active_references_62866);
        _31614 = (object)*(((s1_ptr)_2)->base + _i_64336);
        if (IS_SEQUENCE(_31614)){
                _31615 = SEQ_PTR(_31614)->length;
        }
        else {
            _31615 = 1;
        }
        _31614 = NOVALUE;
        {
            object _j_64352;
            _j_64352 = _31615;
L9: 
            if (_j_64352 < 1LL){
                goto LA; // [218] 254
            }

            /** fwdref.e:983					errors &= resolve_file( active_references[i][j], report_errors, unincluded_ok )*/
            _2 = (object)SEQ_PTR(_42active_references_62866);
            _31616 = (object)*(((s1_ptr)_2)->base + _i_64336);
            _2 = (object)SEQ_PTR(_31616);
            _31617 = (object)*(((s1_ptr)_2)->base + _j_64352);
            _31616 = NOVALUE;
            Ref(_31617);
            _31618 = _42resolve_file(_31617, _report_errors_64302, _unincluded_ok_64304);
            _31617 = NOVALUE;
            if (IS_SEQUENCE(_errors_64303) && IS_ATOM(_31618)) {
                Ref(_31618);
                Append(&_errors_64303, _errors_64303, _31618);
            }
            else if (IS_ATOM(_errors_64303) && IS_SEQUENCE(_31618)) {
            }
            else {
                Concat((object_ptr)&_errors_64303, _errors_64303, _31618);
            }
            DeRef(_31618);
            _31618 = NOVALUE;

            /** fwdref.e:984				end for*/
            _j_64352 = _j_64352 + -1LL;
            goto L9; // [249] 225
LA: 
            ;
        }

        /** fwdref.e:985				errors &= resolve_file( toplevel_references[i], report_errors, unincluded_ok )*/
        _2 = (object)SEQ_PTR(_42toplevel_references_62867);
        _31620 = (object)*(((s1_ptr)_2)->base + _i_64336);
        Ref(_31620);
        _31621 = _42resolve_file(_31620, _report_errors_64302, _unincluded_ok_64304);
        _31620 = NOVALUE;
        if (IS_SEQUENCE(_errors_64303) && IS_ATOM(_31621)) {
            Ref(_31621);
            Append(&_errors_64303, _errors_64303, _31621);
        }
        else if (IS_ATOM(_errors_64303) && IS_SEQUENCE(_31621)) {
        }
        else {
            Concat((object_ptr)&_errors_64303, _errors_64303, _31621);
        }
        DeRef(_31621);
        _31621 = NOVALUE;
L6: 

        /** fwdref.e:987		end for*/
        _i_64336 = _i_64336 + 1LL;
        goto L3; // [275] 143
L4: 
        ;
    }

    /** fwdref.e:989		if report_errors and length( errors ) then*/
    if (_report_errors_64302 == 0) {
        goto LB; // [282] 856
    }
    if (IS_SEQUENCE(_errors_64303)){
            _31624 = SEQ_PTR(_errors_64303)->length;
    }
    else {
        _31624 = 1;
    }
    if (_31624 == 0)
    {
        _31624 = NOVALUE;
        goto LB; // [290] 856
    }
    else{
        _31624 = NOVALUE;
    }

    /** fwdref.e:990			sequence msg = ""*/
    RefDS(_22024);
    DeRefi(_msg_64365);
    _msg_64365 = _22024;

    /** fwdref.e:991			sequence errloc = "Internal Error - Unknown Error Message"*/
    RefDS(_31625);
    DeRefi(_errloc_64366);
    _errloc_64366 = _31625;

    /** fwdref.e:993			for e = length(errors) to 1 by -1 do*/
    if (IS_SEQUENCE(_errors_64303)){
            _31626 = SEQ_PTR(_errors_64303)->length;
    }
    else {
        _31626 = 1;
    }
    {
        object _e_64369;
        _e_64369 = _31626;
LC: 
        if (_e_64369 < 1LL){
            goto LD; // [312] 828
        }

        /** fwdref.e:994				sequence ref = forward_references[errors[e]]*/
        _2 = (object)SEQ_PTR(_errors_64303);
        _31627 = (object)*(((s1_ptr)_2)->base + _e_64369);
        DeRef(_ref_64371);
        _2 = (object)SEQ_PTR(_42forward_references_62864);
        if (!IS_ATOM_INT(_31627)){
            _ref_64371 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31627)->dbl));
        }
        else{
            _ref_64371 = (object)*(((s1_ptr)_2)->base + _31627);
        }
        Ref(_ref_64371);

        /** fwdref.e:995				if (ref[FR_TYPE] = TYPE_CHECK and ref[FR_OP] = TYPE_CHECK) or ref[FR_TYPE] = GLOBAL_INIT_CHECK then*/
        _2 = (object)SEQ_PTR(_ref_64371);
        _31629 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_31629)) {
            _31630 = (_31629 == 65LL);
        }
        else {
            _31630 = binary_op(EQUALS, _31629, 65LL);
        }
        _31629 = NOVALUE;
        if (IS_ATOM_INT(_31630)) {
            if (_31630 == 0) {
                DeRef(_31631);
                _31631 = 0;
                goto LE; // [345] 363
            }
        }
        else {
            if (DBL_PTR(_31630)->dbl == 0.0) {
                DeRef(_31631);
                _31631 = 0;
                goto LE; // [345] 363
            }
        }
        _2 = (object)SEQ_PTR(_ref_64371);
        _31632 = (object)*(((s1_ptr)_2)->base + 10LL);
        if (IS_ATOM_INT(_31632)) {
            _31633 = (_31632 == 65LL);
        }
        else {
            _31633 = binary_op(EQUALS, _31632, 65LL);
        }
        _31632 = NOVALUE;
        DeRef(_31631);
        if (IS_ATOM_INT(_31633))
        _31631 = (_31633 != 0);
        else
        _31631 = DBL_PTR(_31633)->dbl != 0.0;
LE: 
        if (_31631 != 0) {
            goto LF; // [363] 382
        }
        _2 = (object)SEQ_PTR(_ref_64371);
        _31635 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_31635)) {
            _31636 = (_31635 == 109LL);
        }
        else {
            _31636 = binary_op(EQUALS, _31635, 109LL);
        }
        _31635 = NOVALUE;
        if (_31636 == 0) {
            DeRef(_31636);
            _31636 = NOVALUE;
            goto L10; // [378] 391
        }
        else {
            if (!IS_ATOM_INT(_31636) && DBL_PTR(_31636)->dbl == 0.0){
                DeRef(_31636);
                _31636 = NOVALUE;
                goto L10; // [378] 391
            }
            DeRef(_31636);
            _31636 = NOVALUE;
        }
        DeRef(_31636);
        _31636 = NOVALUE;
LF: 

        /** fwdref.e:997					continue*/
        DeRef(_ref_64371);
        _ref_64371 = NOVALUE;
        goto L11; // [386] 823
        goto L12; // [388] 789
L10: 

        /** fwdref.e:1001					object tok = find_reference(ref)*/
        RefDS(_ref_64371);
        _0 = _tok_64387;
        _tok_64387 = _42find_reference(_ref_64371);
        DeRef(_0);

        /** fwdref.e:1002					integer THIS_SCOPE = 3*/
        _THIS_SCOPE_64389 = 3LL;

        /** fwdref.e:1003					integer THESE_GLOBALS = 4*/
        _THESE_GLOBALS_64390 = 4LL;

        /** fwdref.e:1004					if tok[T_ID] = IGNORED then*/
        _2 = (object)SEQ_PTR(_tok_64387);
        _31638 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _31638, 509LL)){
            _31638 = NOVALUE;
            goto L13; // [417] 760
        }
        _31638 = NOVALUE;

        /** fwdref.e:1006						switch tok[THIS_SCOPE] do*/
        _2 = (object)SEQ_PTR(_tok_64387);
        _31640 = (object)*(((s1_ptr)_2)->base + 3LL);
        if (IS_SEQUENCE(_31640) ){
            goto L14; // [427] 756
        }
        if(!IS_ATOM_INT(_31640)){
            if( (DBL_PTR(_31640)->dbl != (eudouble) ((object) DBL_PTR(_31640)->dbl) ) ){
                goto L14; // [427] 756
            }
            _0 = (object) DBL_PTR(_31640)->dbl;
        }
        else {
            _0 = _31640;
        };
        _31640 = NOVALUE;
        switch ( _0 ){ 

            /** fwdref.e:1007							case SC_UNDEFINED then*/
            case 9:

            /** fwdref.e:1008								if ref[FR_QUALIFIED] != -1 then*/
            _2 = (object)SEQ_PTR(_ref_64371);
            _31643 = (object)*(((s1_ptr)_2)->base + 9LL);
            if (binary_op_a(EQUALS, _31643, -1LL)){
                _31643 = NOVALUE;
                goto L15; // [442] 556
            }
            _31643 = NOVALUE;

            /** fwdref.e:1009									if ref[FR_QUALIFIED] > 0 then*/
            _2 = (object)SEQ_PTR(_ref_64371);
            _31645 = (object)*(((s1_ptr)_2)->base + 9LL);
            if (binary_op_a(LESSEQ, _31645, 0LL)){
                _31645 = NOVALUE;
                goto L16; // [452] 517
            }
            _31645 = NOVALUE;

            /** fwdref.e:1011										errloc = sprintf("\t\'%s\' (%s:%d) was not declared in \'%s\'.\n", */
            _2 = (object)SEQ_PTR(_ref_64371);
            _31648 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_ref_64371);
            _31649 = (object)*(((s1_ptr)_2)->base + 3LL);
            _2 = (object)SEQ_PTR(_13known_files_11317);
            if (!IS_ATOM_INT(_31649)){
                _31650 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31649)->dbl));
            }
            else{
                _31650 = (object)*(((s1_ptr)_2)->base + _31649);
            }
            Ref(_31650);
            RefDS(_22024);
            _31651 = _14abbreviate_path(_31650, _22024);
            _31650 = NOVALUE;
            _2 = (object)SEQ_PTR(_ref_64371);
            _31652 = (object)*(((s1_ptr)_2)->base + 6LL);
            _2 = (object)SEQ_PTR(_ref_64371);
            _31653 = (object)*(((s1_ptr)_2)->base + 9LL);
            _2 = (object)SEQ_PTR(_13known_files_11317);
            if (!IS_ATOM_INT(_31653)){
                _31654 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31653)->dbl));
            }
            else{
                _31654 = (object)*(((s1_ptr)_2)->base + _31653);
            }
            Ref(_31654);
            RefDS(_22024);
            _31655 = _14abbreviate_path(_31654, _22024);
            _31654 = NOVALUE;
            _31656 = _20find_replace(92LL, _31655, 47LL, 0LL);
            _31655 = NOVALUE;
            _1 = NewS1(4);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_31648);
            ((intptr_t*)_2)[1] = _31648;
            ((intptr_t*)_2)[2] = _31651;
            Ref(_31652);
            ((intptr_t*)_2)[3] = _31652;
            ((intptr_t*)_2)[4] = _31656;
            _31657 = MAKE_SEQ(_1);
            _31656 = NOVALUE;
            _31652 = NOVALUE;
            _31651 = NOVALUE;
            _31648 = NOVALUE;
            DeRefi(_errloc_64366);
            _errloc_64366 = EPrintf(-9999999, _31647, _31657);
            DeRefDS(_31657);
            _31657 = NOVALUE;
            goto L17; // [514] 759
L16: 

            /** fwdref.e:1016										errloc = sprintf("\t\'%s\' (%s:%d) is not a builtin.\n", */
            _2 = (object)SEQ_PTR(_ref_64371);
            _31660 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_ref_64371);
            _31661 = (object)*(((s1_ptr)_2)->base + 3LL);
            _2 = (object)SEQ_PTR(_13known_files_11317);
            if (!IS_ATOM_INT(_31661)){
                _31662 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31661)->dbl));
            }
            else{
                _31662 = (object)*(((s1_ptr)_2)->base + _31661);
            }
            Ref(_31662);
            RefDS(_22024);
            _31663 = _14abbreviate_path(_31662, _22024);
            _31662 = NOVALUE;
            _2 = (object)SEQ_PTR(_ref_64371);
            _31664 = (object)*(((s1_ptr)_2)->base + 6LL);
            _1 = NewS1(3);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_31660);
            ((intptr_t*)_2)[1] = _31660;
            ((intptr_t*)_2)[2] = _31663;
            Ref(_31664);
            ((intptr_t*)_2)[3] = _31664;
            _31665 = MAKE_SEQ(_1);
            _31664 = NOVALUE;
            _31663 = NOVALUE;
            _31660 = NOVALUE;
            DeRefi(_errloc_64366);
            _errloc_64366 = EPrintf(-9999999, _31659, _31665);
            DeRefDS(_31665);
            _31665 = NOVALUE;
            goto L17; // [553] 759
L15: 

            /** fwdref.e:1021									errloc = sprintf("\t\'%s\' (%s:%d) has not been declared.\n", */
            _2 = (object)SEQ_PTR(_ref_64371);
            _31668 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_ref_64371);
            _31669 = (object)*(((s1_ptr)_2)->base + 3LL);
            _2 = (object)SEQ_PTR(_13known_files_11317);
            if (!IS_ATOM_INT(_31669)){
                _31670 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31669)->dbl));
            }
            else{
                _31670 = (object)*(((s1_ptr)_2)->base + _31669);
            }
            Ref(_31670);
            RefDS(_22024);
            _31671 = _14abbreviate_path(_31670, _22024);
            _31670 = NOVALUE;
            _2 = (object)SEQ_PTR(_ref_64371);
            _31672 = (object)*(((s1_ptr)_2)->base + 6LL);
            _1 = NewS1(3);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_31668);
            ((intptr_t*)_2)[1] = _31668;
            ((intptr_t*)_2)[2] = _31671;
            Ref(_31672);
            ((intptr_t*)_2)[3] = _31672;
            _31673 = MAKE_SEQ(_1);
            _31672 = NOVALUE;
            _31671 = NOVALUE;
            _31668 = NOVALUE;
            DeRefi(_errloc_64366);
            _errloc_64366 = EPrintf(-9999999, _31667, _31673);
            DeRefDS(_31673);
            _31673 = NOVALUE;
            goto L17; // [592] 759

            /** fwdref.e:1024							case SC_MULTIPLY_DEFINED then*/
            case 10:

            /** fwdref.e:1025								sequence syms = tok[THESE_GLOBALS] -- there should be no forward references in here.*/
            DeRef(_syms_64448);
            _2 = (object)SEQ_PTR(_tok_64387);
            _syms_64448 = (object)*(((s1_ptr)_2)->base + _THESE_GLOBALS_64390);
            Ref(_syms_64448);

            /** fwdref.e:1026								syms = custom_sort(routine_id("file_name_based_symindex_compare"), syms,, ASCENDING)*/
            _31677 = CRoutineId(1382, 42, _31676);
            RefDS(_syms_64448);
            RefDS(_22024);
            _0 = _syms_64448;
            _syms_64448 = _25custom_sort(_31677, _syms_64448, _22024, 1LL);
            DeRefDS(_0);
            _31677 = NOVALUE;

            /** fwdref.e:1027								errloc = sprintf("\t\'%s\' (%s:%d) has been declared more than once.\n", */
            _2 = (object)SEQ_PTR(_ref_64371);
            _31680 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_ref_64371);
            _31681 = (object)*(((s1_ptr)_2)->base + 3LL);
            _2 = (object)SEQ_PTR(_13known_files_11317);
            if (!IS_ATOM_INT(_31681)){
                _31682 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31681)->dbl));
            }
            else{
                _31682 = (object)*(((s1_ptr)_2)->base + _31681);
            }
            Ref(_31682);
            RefDS(_22024);
            _31683 = _14abbreviate_path(_31682, _22024);
            _31682 = NOVALUE;
            _2 = (object)SEQ_PTR(_ref_64371);
            _31684 = (object)*(((s1_ptr)_2)->base + 6LL);
            _1 = NewS1(3);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_31680);
            ((intptr_t*)_2)[1] = _31680;
            ((intptr_t*)_2)[2] = _31683;
            Ref(_31684);
            ((intptr_t*)_2)[3] = _31684;
            _31685 = MAKE_SEQ(_1);
            _31684 = NOVALUE;
            _31683 = NOVALUE;
            _31680 = NOVALUE;
            DeRefi(_errloc_64366);
            _errloc_64366 = EPrintf(-9999999, _31679, _31685);
            DeRefDS(_31685);
            _31685 = NOVALUE;

            /** fwdref.e:1029								for si = 1 to length(syms) do*/
            if (IS_SEQUENCE(_syms_64448)){
                    _31687 = SEQ_PTR(_syms_64448)->length;
            }
            else {
                _31687 = 1;
            }
            {
                object _si_64466;
                _si_64466 = 1LL;
L18: 
                if (_si_64466 > _31687){
                    goto L19; // [664] 750
                }

                /** fwdref.e:1030									symtab_index s = syms[si] */
                _2 = (object)SEQ_PTR(_syms_64448);
                _s_64469 = (object)*(((s1_ptr)_2)->base + _si_64466);
                if (!IS_ATOM_INT(_s_64469)){
                    _s_64469 = (object)DBL_PTR(_s_64469)->dbl;
                }

                /** fwdref.e:1031									if equal(ref[FR_NAME], sym_name(s)) then*/
                _2 = (object)SEQ_PTR(_ref_64371);
                _31689 = (object)*(((s1_ptr)_2)->base + 2LL);
                _31690 = _53sym_name(_s_64469);
                if (_31689 == _31690)
                _31691 = 1;
                else if (IS_ATOM_INT(_31689) && IS_ATOM_INT(_31690))
                _31691 = 0;
                else
                _31691 = (compare(_31689, _31690) == 0);
                _31689 = NOVALUE;
                DeRef(_31690);
                _31690 = NOVALUE;
                if (_31691 == 0)
                {
                    _31691 = NOVALUE;
                    goto L1A; // [693] 741
                }
                else{
                    _31691 = NOVALUE;
                }

                /** fwdref.e:1032										errloc &= sprintf("\t\tin %s\n", */
                _2 = (object)SEQ_PTR(_13SymTab_11316);
                _31693 = (object)*(((s1_ptr)_2)->base + _s_64469);
                _2 = (object)SEQ_PTR(_31693);
                if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
                    _31694 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
                }
                else{
                    _31694 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
                }
                _31693 = NOVALUE;
                _2 = (object)SEQ_PTR(_13known_files_11317);
                if (!IS_ATOM_INT(_31694)){
                    _31695 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31694)->dbl));
                }
                else{
                    _31695 = (object)*(((s1_ptr)_2)->base + _31694);
                }
                Ref(_31695);
                RefDS(_22024);
                _31696 = _14abbreviate_path(_31695, _22024);
                _31695 = NOVALUE;
                _31697 = _20find_replace(92LL, _31696, 47LL, 0LL);
                _31696 = NOVALUE;
                _1 = NewS1(1);
                _2 = (object)((s1_ptr)_1)->base;
                ((intptr_t*)_2)[1] = _31697;
                _31698 = MAKE_SEQ(_1);
                _31697 = NOVALUE;
                _31699 = EPrintf(-9999999, _31692, _31698);
                DeRefDS(_31698);
                _31698 = NOVALUE;
                Concat((object_ptr)&_errloc_64366, _errloc_64366, _31699);
                DeRefDS(_31699);
                _31699 = NOVALUE;
L1A: 

                /** fwdref.e:1035								end for*/
                _si_64466 = _si_64466 + 1LL;
                goto L18; // [745] 671
L19: 
                ;
            }
            DeRef(_syms_64448);
            _syms_64448 = NOVALUE;
            goto L17; // [752] 759

            /** fwdref.e:1036							case else */
            default:
L14: 
        ;}L17: 
L13: 

        /** fwdref.e:1040					if not match(errloc, msg) then*/
        _31701 = e_match_from(_errloc_64366, _msg_64365, 1LL);
        if (_31701 != 0)
        goto L1B; // [767] 786
        _31701 = NOVALUE;

        /** fwdref.e:1041						msg &= errloc*/
        Concat((object_ptr)&_msg_64365, _msg_64365, _errloc_64366);

        /** fwdref.e:1042						prep_forward_error( errors[e] )*/
        _2 = (object)SEQ_PTR(_errors_64303);
        _31704 = (object)*(((s1_ptr)_2)->base + _e_64369);
        Ref(_31704);
        _42prep_forward_error(_31704);
        _31704 = NOVALUE;
L1B: 
        DeRef(_tok_64387);
        _tok_64387 = NOVALUE;
L12: 

        /** fwdref.e:1045				ThisLine    = ref[FR_THISLINE]*/
        DeRef(_49ThisLine_49312);
        _2 = (object)SEQ_PTR(_ref_64371);
        _49ThisLine_49312 = (object)*(((s1_ptr)_2)->base + 7LL);
        Ref(_49ThisLine_49312);

        /** fwdref.e:1046				bp          = ref[FR_BP]*/
        _2 = (object)SEQ_PTR(_ref_64371);
        _49bp_49316 = (object)*(((s1_ptr)_2)->base + 8LL);
        if (!IS_ATOM_INT(_49bp_49316)){
            _49bp_49316 = (object)DBL_PTR(_49bp_49316)->dbl;
        }

        /** fwdref.e:1047				CurrentSub  = ref[FR_SUBPROG]*/
        _2 = (object)SEQ_PTR(_ref_64371);
        _12CurrentSub_20234 = (object)*(((s1_ptr)_2)->base + 4LL);
        if (!IS_ATOM_INT(_12CurrentSub_20234)){
            _12CurrentSub_20234 = (object)DBL_PTR(_12CurrentSub_20234)->dbl;
        }

        /** fwdref.e:1048				line_number = ref[FR_LINE]*/
        _2 = (object)SEQ_PTR(_ref_64371);
        _12line_number_20227 = (object)*(((s1_ptr)_2)->base + 6LL);
        if (!IS_ATOM_INT(_12line_number_20227)){
            _12line_number_20227 = (object)DBL_PTR(_12line_number_20227)->dbl;
        }
        DeRefDS(_ref_64371);
        _ref_64371 = NOVALUE;

        /** fwdref.e:1049			end for*/
L11: 
        _e_64369 = _e_64369 + -1LL;
        goto LC; // [823] 319
LD: 
        ;
    }

    /** fwdref.e:1050			if length(msg) > 0 then*/
    if (IS_SEQUENCE(_msg_64365)){
            _31709 = SEQ_PTR(_msg_64365)->length;
    }
    else {
        _31709 = 1;
    }
    if (_31709 <= 0LL)
    goto L1C; // [833] 851

    /** fwdref.e:1051				CompileErr( ERRORS_RESOLVING_THE_FOLLOWING_REFERENCES1, {msg} )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_msg_64365);
    ((intptr_t*)_2)[1] = _msg_64365;
    _31711 = MAKE_SEQ(_1);
    _49CompileErr(74LL, _31711, 0LL);
    _31711 = NOVALUE;
L1C: 
    DeRefi(_msg_64365);
    _msg_64365 = NOVALUE;
    DeRefi(_errloc_64366);
    _errloc_64366 = NOVALUE;
    goto L1D; // [853] 901
LB: 

    /** fwdref.e:1053		elsif report_errors and not repl then*/
    if (_report_errors_64302 == 0) {
        goto L1E; // [858] 900
    }
    _31713 = (0LL == 0);
    if (_31713 == 0)
    {
        DeRef(_31713);
        _31713 = NOVALUE;
        goto L1E; // [868] 900
    }
    else{
        DeRef(_31713);
        _31713 = NOVALUE;
    }

    /** fwdref.e:1055			forward_references  = {}*/
    RefDS(_22024);
    DeRef(_42forward_references_62864);
    _42forward_references_62864 = _22024;

    /** fwdref.e:1056			active_references   = {}*/
    RefDS(_22024);
    DeRef(_42active_references_62866);
    _42active_references_62866 = _22024;

    /** fwdref.e:1057			toplevel_references = {}*/
    RefDS(_22024);
    DeRef(_42toplevel_references_62867);
    _42toplevel_references_62867 = _22024;

    /** fwdref.e:1058			inactive_references = {}*/
    RefDS(_22024);
    DeRef(_42inactive_references_62868);
    _42inactive_references_62868 = _22024;
L1E: 
L1D: 

    /** fwdref.e:1060		clear_last()*/
    _45clear_last();

    /** fwdref.e:1061	end procedure*/
    DeRef(_errors_64303);
    _31627 = NOVALUE;
    _31612 = NOVALUE;
    _31661 = NOVALUE;
    _31649 = NOVALUE;
    DeRef(_31630);
    _31630 = NOVALUE;
    _31614 = NOVALUE;
    _31607 = NOVALUE;
    _31694 = NOVALUE;
    DeRef(_31610);
    _31610 = NOVALUE;
    DeRef(_31633);
    _31633 = NOVALUE;
    _31669 = NOVALUE;
    _31653 = NOVALUE;
    _31681 = NOVALUE;
    _31604 = NOVALUE;
    return;
    ;
}


void _42shift_these(object _refs_64517, object _pc_64518, object _amount_64519)
{
    object _fr_64523 = NOVALUE;
    object _31731 = NOVALUE;
    object _31730 = NOVALUE;
    object _31729 = NOVALUE;
    object _31728 = NOVALUE;
    object _31727 = NOVALUE;
    object _31726 = NOVALUE;
    object _31725 = NOVALUE;
    object _31724 = NOVALUE;
    object _31723 = NOVALUE;
    object _31722 = NOVALUE;
    object _31720 = NOVALUE;
    object _31718 = NOVALUE;
    object _31717 = NOVALUE;
    object _31715 = NOVALUE;
    object _31714 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:1064		for i = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_64517)){
            _31714 = SEQ_PTR(_refs_64517)->length;
    }
    else {
        _31714 = 1;
    }
    {
        object _i_64521;
        _i_64521 = _31714;
L1: 
        if (_i_64521 < 1LL){
            goto L2; // [12] 147
        }

        /** fwdref.e:1065			sequence fr = forward_references[refs[i]]*/
        _2 = (object)SEQ_PTR(_refs_64517);
        _31715 = (object)*(((s1_ptr)_2)->base + _i_64521);
        DeRef(_fr_64523);
        _2 = (object)SEQ_PTR(_42forward_references_62864);
        if (!IS_ATOM_INT(_31715)){
            _fr_64523 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31715)->dbl));
        }
        else{
            _fr_64523 = (object)*(((s1_ptr)_2)->base + _31715);
        }
        Ref(_fr_64523);

        /** fwdref.e:1066			forward_references[refs[i]] = 0*/
        _2 = (object)SEQ_PTR(_refs_64517);
        _31717 = (object)*(((s1_ptr)_2)->base + _i_64521);
        _2 = (object)SEQ_PTR(_42forward_references_62864);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _42forward_references_62864 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31717))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31717)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _31717);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0LL;
        DeRef(_1);

        /** fwdref.e:1067			if fr[FR_SUBPROG] = shifting_sub then*/
        _2 = (object)SEQ_PTR(_fr_64523);
        _31718 = (object)*(((s1_ptr)_2)->base + 4LL);
        if (binary_op_a(NOTEQ, _31718, _42shifting_sub_62883)){
            _31718 = NOVALUE;
            goto L3; // [53] 126
        }
        _31718 = NOVALUE;

        /** fwdref.e:1068				if fr[FR_PC] >= pc then*/
        _2 = (object)SEQ_PTR(_fr_64523);
        _31720 = (object)*(((s1_ptr)_2)->base + 5LL);
        if (binary_op_a(LESS, _31720, _pc_64518)){
            _31720 = NOVALUE;
            goto L4; // [63] 125
        }
        _31720 = NOVALUE;

        /** fwdref.e:1069					fr[FR_PC] += amount*/
        _2 = (object)SEQ_PTR(_fr_64523);
        _31722 = (object)*(((s1_ptr)_2)->base + 5LL);
        if (IS_ATOM_INT(_31722)) {
            _31723 = _31722 + _amount_64519;
            if ((object)((uintptr_t)_31723 + (uintptr_t)HIGH_BITS) >= 0){
                _31723 = NewDouble((eudouble)_31723);
            }
        }
        else {
            _31723 = binary_op(PLUS, _31722, _amount_64519);
        }
        _31722 = NOVALUE;
        _2 = (object)SEQ_PTR(_fr_64523);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _fr_64523 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31723;
        if( _1 != _31723 ){
            DeRef(_1);
        }
        _31723 = NOVALUE;

        /** fwdref.e:1070					if fr[FR_TYPE] = CASE*/
        _2 = (object)SEQ_PTR(_fr_64523);
        _31724 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_31724)) {
            _31725 = (_31724 == 186LL);
        }
        else {
            _31725 = binary_op(EQUALS, _31724, 186LL);
        }
        _31724 = NOVALUE;
        if (IS_ATOM_INT(_31725)) {
            if (_31725 == 0) {
                goto L5; // [93] 124
            }
        }
        else {
            if (DBL_PTR(_31725)->dbl == 0.0) {
                goto L5; // [93] 124
            }
        }
        _2 = (object)SEQ_PTR(_fr_64523);
        _31727 = (object)*(((s1_ptr)_2)->base + 12LL);
        if (IS_ATOM_INT(_31727)) {
            _31728 = (_31727 >= _pc_64518);
        }
        else {
            _31728 = binary_op(GREATEREQ, _31727, _pc_64518);
        }
        _31727 = NOVALUE;
        if (_31728 == 0) {
            DeRef(_31728);
            _31728 = NOVALUE;
            goto L5; // [106] 124
        }
        else {
            if (!IS_ATOM_INT(_31728) && DBL_PTR(_31728)->dbl == 0.0){
                DeRef(_31728);
                _31728 = NOVALUE;
                goto L5; // [106] 124
            }
            DeRef(_31728);
            _31728 = NOVALUE;
        }
        DeRef(_31728);
        _31728 = NOVALUE;

        /** fwdref.e:1073						fr[FR_DATA] += amount*/
        _2 = (object)SEQ_PTR(_fr_64523);
        _31729 = (object)*(((s1_ptr)_2)->base + 12LL);
        if (IS_ATOM_INT(_31729)) {
            _31730 = _31729 + _amount_64519;
            if ((object)((uintptr_t)_31730 + (uintptr_t)HIGH_BITS) >= 0){
                _31730 = NewDouble((eudouble)_31730);
            }
        }
        else {
            _31730 = binary_op(PLUS, _31729, _amount_64519);
        }
        _31729 = NOVALUE;
        _2 = (object)SEQ_PTR(_fr_64523);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _fr_64523 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 12LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31730;
        if( _1 != _31730 ){
            DeRef(_1);
        }
        _31730 = NOVALUE;
L5: 
L4: 
L3: 

        /** fwdref.e:1077			forward_references[refs[i]] = fr*/
        _2 = (object)SEQ_PTR(_refs_64517);
        _31731 = (object)*(((s1_ptr)_2)->base + _i_64521);
        RefDS(_fr_64523);
        _2 = (object)SEQ_PTR(_42forward_references_62864);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _42forward_references_62864 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31731))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31731)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _31731);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _fr_64523;
        DeRef(_1);
        DeRefDS(_fr_64523);
        _fr_64523 = NOVALUE;

        /** fwdref.e:1078		end for*/
        _i_64521 = _i_64521 + -1LL;
        goto L1; // [142] 19
L2: 
        ;
    }

    /** fwdref.e:1079	end procedure*/
    DeRefDS(_refs_64517);
    _31717 = NOVALUE;
    _31731 = NOVALUE;
    DeRef(_31725);
    _31725 = NOVALUE;
    _31715 = NOVALUE;
    return;
    ;
}


void _42shift_top(object _refs_64547, object _pc_64548, object _amount_64549)
{
    object _fr_64553 = NOVALUE;
    object _31747 = NOVALUE;
    object _31746 = NOVALUE;
    object _31745 = NOVALUE;
    object _31744 = NOVALUE;
    object _31743 = NOVALUE;
    object _31742 = NOVALUE;
    object _31741 = NOVALUE;
    object _31740 = NOVALUE;
    object _31739 = NOVALUE;
    object _31738 = NOVALUE;
    object _31736 = NOVALUE;
    object _31735 = NOVALUE;
    object _31733 = NOVALUE;
    object _31732 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:1083		for i = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_64547)){
            _31732 = SEQ_PTR(_refs_64547)->length;
    }
    else {
        _31732 = 1;
    }
    {
        object _i_64551;
        _i_64551 = _31732;
L1: 
        if (_i_64551 < 1LL){
            goto L2; // [12] 134
        }

        /** fwdref.e:1084			sequence fr = forward_references[refs[i]]*/
        _2 = (object)SEQ_PTR(_refs_64547);
        _31733 = (object)*(((s1_ptr)_2)->base + _i_64551);
        DeRef(_fr_64553);
        _2 = (object)SEQ_PTR(_42forward_references_62864);
        if (!IS_ATOM_INT(_31733)){
            _fr_64553 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31733)->dbl));
        }
        else{
            _fr_64553 = (object)*(((s1_ptr)_2)->base + _31733);
        }
        Ref(_fr_64553);

        /** fwdref.e:1085			forward_references[refs[i]] = 0*/
        _2 = (object)SEQ_PTR(_refs_64547);
        _31735 = (object)*(((s1_ptr)_2)->base + _i_64551);
        _2 = (object)SEQ_PTR(_42forward_references_62864);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _42forward_references_62864 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31735))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31735)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _31735);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0LL;
        DeRef(_1);

        /** fwdref.e:1086			if fr[FR_PC] >= pc then*/
        _2 = (object)SEQ_PTR(_fr_64553);
        _31736 = (object)*(((s1_ptr)_2)->base + 5LL);
        if (binary_op_a(LESS, _31736, _pc_64548)){
            _31736 = NOVALUE;
            goto L3; // [51] 113
        }
        _31736 = NOVALUE;

        /** fwdref.e:1087				fr[FR_PC] += amount*/
        _2 = (object)SEQ_PTR(_fr_64553);
        _31738 = (object)*(((s1_ptr)_2)->base + 5LL);
        if (IS_ATOM_INT(_31738)) {
            _31739 = _31738 + _amount_64549;
            if ((object)((uintptr_t)_31739 + (uintptr_t)HIGH_BITS) >= 0){
                _31739 = NewDouble((eudouble)_31739);
            }
        }
        else {
            _31739 = binary_op(PLUS, _31738, _amount_64549);
        }
        _31738 = NOVALUE;
        _2 = (object)SEQ_PTR(_fr_64553);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _fr_64553 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31739;
        if( _1 != _31739 ){
            DeRef(_1);
        }
        _31739 = NOVALUE;

        /** fwdref.e:1088				if fr[FR_TYPE] = CASE*/
        _2 = (object)SEQ_PTR(_fr_64553);
        _31740 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_31740)) {
            _31741 = (_31740 == 186LL);
        }
        else {
            _31741 = binary_op(EQUALS, _31740, 186LL);
        }
        _31740 = NOVALUE;
        if (IS_ATOM_INT(_31741)) {
            if (_31741 == 0) {
                goto L4; // [81] 112
            }
        }
        else {
            if (DBL_PTR(_31741)->dbl == 0.0) {
                goto L4; // [81] 112
            }
        }
        _2 = (object)SEQ_PTR(_fr_64553);
        _31743 = (object)*(((s1_ptr)_2)->base + 12LL);
        if (IS_ATOM_INT(_31743)) {
            _31744 = (_31743 >= _pc_64548);
        }
        else {
            _31744 = binary_op(GREATEREQ, _31743, _pc_64548);
        }
        _31743 = NOVALUE;
        if (_31744 == 0) {
            DeRef(_31744);
            _31744 = NOVALUE;
            goto L4; // [94] 112
        }
        else {
            if (!IS_ATOM_INT(_31744) && DBL_PTR(_31744)->dbl == 0.0){
                DeRef(_31744);
                _31744 = NOVALUE;
                goto L4; // [94] 112
            }
            DeRef(_31744);
            _31744 = NOVALUE;
        }
        DeRef(_31744);
        _31744 = NOVALUE;

        /** fwdref.e:1091					fr[FR_DATA] += amount*/
        _2 = (object)SEQ_PTR(_fr_64553);
        _31745 = (object)*(((s1_ptr)_2)->base + 12LL);
        if (IS_ATOM_INT(_31745)) {
            _31746 = _31745 + _amount_64549;
            if ((object)((uintptr_t)_31746 + (uintptr_t)HIGH_BITS) >= 0){
                _31746 = NewDouble((eudouble)_31746);
            }
        }
        else {
            _31746 = binary_op(PLUS, _31745, _amount_64549);
        }
        _31745 = NOVALUE;
        _2 = (object)SEQ_PTR(_fr_64553);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _fr_64553 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 12LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31746;
        if( _1 != _31746 ){
            DeRef(_1);
        }
        _31746 = NOVALUE;
L4: 
L3: 

        /** fwdref.e:1094			forward_references[refs[i]] = fr*/
        _2 = (object)SEQ_PTR(_refs_64547);
        _31747 = (object)*(((s1_ptr)_2)->base + _i_64551);
        RefDS(_fr_64553);
        _2 = (object)SEQ_PTR(_42forward_references_62864);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _42forward_references_62864 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31747))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31747)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _31747);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _fr_64553;
        DeRef(_1);
        DeRefDS(_fr_64553);
        _fr_64553 = NOVALUE;

        /** fwdref.e:1095		end for*/
        _i_64551 = _i_64551 + -1LL;
        goto L1; // [129] 19
L2: 
        ;
    }

    /** fwdref.e:1096	end procedure*/
    DeRefDS(_refs_64547);
    _31735 = NOVALUE;
    _31747 = NOVALUE;
    _31733 = NOVALUE;
    DeRef(_31741);
    _31741 = NOVALUE;
    return;
    ;
}


void _42shift_fwd_refs(object _pc_64574, object _amount_64575)
{
    object _file_64586 = NOVALUE;
    object _sp_64591 = NOVALUE;
    object _31757 = NOVALUE;
    object _31756 = NOVALUE;
    object _31754 = NOVALUE;
    object _31752 = NOVALUE;
    object _31751 = NOVALUE;
    object _31750 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:1099		if not shifting_sub then*/
    if (_42shifting_sub_62883 != 0)
    goto L1; // [9] 18

    /** fwdref.e:1100			return*/
    return;
L1: 

    /** fwdref.e:1103		if shifting_sub = TopLevelSub then*/
    if (_42shifting_sub_62883 != _12TopLevelSub_20233)
    goto L2; // [24] 65

    /** fwdref.e:1104			for file = 1 to length( toplevel_references ) do*/
    if (IS_SEQUENCE(_42toplevel_references_62867)){
            _31750 = SEQ_PTR(_42toplevel_references_62867)->length;
    }
    else {
        _31750 = 1;
    }
    {
        object _file_64582;
        _file_64582 = 1LL;
L3: 
        if (_file_64582 > _31750){
            goto L4; // [35] 62
        }

        /** fwdref.e:1105				shift_top( toplevel_references[file], pc, amount )*/
        _2 = (object)SEQ_PTR(_42toplevel_references_62867);
        _31751 = (object)*(((s1_ptr)_2)->base + _file_64582);
        Ref(_31751);
        _42shift_top(_31751, _pc_64574, _amount_64575);
        _31751 = NOVALUE;

        /** fwdref.e:1106			end for*/
        _file_64582 = _file_64582 + 1LL;
        goto L3; // [57] 42
L4: 
        ;
    }
    goto L5; // [62] 118
L2: 

    /** fwdref.e:1108			integer file = SymTab[shifting_sub][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _31752 = (object)*(((s1_ptr)_2)->base + _42shifting_sub_62883);
    _2 = (object)SEQ_PTR(_31752);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _file_64586 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _file_64586 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    if (!IS_ATOM_INT(_file_64586)){
        _file_64586 = (object)DBL_PTR(_file_64586)->dbl;
    }
    _31752 = NOVALUE;

    /** fwdref.e:1109			integer sp   = find( shifting_sub, active_subprogs[file] )*/
    _2 = (object)SEQ_PTR(_42active_subprogs_62865);
    _31754 = (object)*(((s1_ptr)_2)->base + _file_64586);
    _sp_64591 = find_from(_42shifting_sub_62883, _31754, 1LL);
    _31754 = NOVALUE;

    /** fwdref.e:1110			shift_these( active_references[file][sp], pc, amount )*/
    _2 = (object)SEQ_PTR(_42active_references_62866);
    _31756 = (object)*(((s1_ptr)_2)->base + _file_64586);
    _2 = (object)SEQ_PTR(_31756);
    _31757 = (object)*(((s1_ptr)_2)->base + _sp_64591);
    _31756 = NOVALUE;
    Ref(_31757);
    _42shift_these(_31757, _pc_64574, _amount_64575);
    _31757 = NOVALUE;
L5: 

    /** fwdref.e:1112	end procedure*/
    return;
    ;
}



// 0xB29FA341
