// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _6deallocate(object _addr_353)
{
    object _0, _1, _2;
    

    /** memory.e:71		ifdef DATA_EXECUTE then*/

    /** memory.e:82	   	machine_proc( memconst:M_FREE, addr)*/
    machine(17LL, _addr_353);

    /** memory.e:83	end procedure*/
    DeRef(_addr_353);
    return;
    ;
}


object _6prepare_block(object _addr_379, object _a_380, object _protection_381)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_protection_381)) {
        _1 = (object)(DBL_PTR(_protection_381)->dbl);
        DeRefDS(_protection_381);
        _protection_381 = _1;
    }

    /** memory.e:134		return addr*/
    return _addr_379;
    ;
}



// 0x58589961
