// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _44host_platform()
{
    object _0, _1, _2;
    

    /** platform.e:113		return ihost_platform*/
    return 3LL;
    ;
}


object _44GetPlatformDefines(object _for_translator_20442)
{
    object _local_defines_20443 = NOVALUE;
    object _lcmds_20453 = NOVALUE;
    object _fh_20455 = NOVALUE;
    object _sk_20475 = NOVALUE;
    object _11577 = NOVALUE;
    object _11576 = NOVALUE;
    object _11574 = NOVALUE;
    object _11571 = NOVALUE;
    object _11570 = NOVALUE;
    object _11568 = NOVALUE;
    object _11567 = NOVALUE;
    object _11565 = NOVALUE;
    object _11562 = NOVALUE;
    object _11561 = NOVALUE;
    object _11559 = NOVALUE;
    object _11558 = NOVALUE;
    object _11556 = NOVALUE;
    object _11554 = NOVALUE;
    object _11552 = NOVALUE;
    object _11551 = NOVALUE;
    object _11549 = NOVALUE;
    object _11546 = NOVALUE;
    object _11544 = NOVALUE;
    object _11543 = NOVALUE;
    object _11541 = NOVALUE;
    object _11539 = NOVALUE;
    object _11537 = NOVALUE;
    object _11536 = NOVALUE;
    object _11534 = NOVALUE;
    object _11532 = NOVALUE;
    object _11530 = NOVALUE;
    object _11529 = NOVALUE;
    object _11527 = NOVALUE;
    object _11525 = NOVALUE;
    object _11523 = NOVALUE;
    object _11522 = NOVALUE;
    object _11520 = NOVALUE;
    object _11517 = NOVALUE;
    object _11515 = NOVALUE;
    object _11514 = NOVALUE;
    object _11512 = NOVALUE;
    object _11510 = NOVALUE;
    object _11508 = NOVALUE;
    object _11507 = NOVALUE;
    object _11504 = NOVALUE;
    object _11501 = NOVALUE;
    object _11498 = NOVALUE;
    object _11494 = NOVALUE;
    object _11493 = NOVALUE;
    object _11488 = NOVALUE;
    object _11487 = NOVALUE;
    object _11474 = NOVALUE;
    object _11471 = NOVALUE;
    object _11468 = NOVALUE;
    object _11467 = NOVALUE;
    object _11466 = NOVALUE;
    object _11462 = NOVALUE;
    object _11459 = NOVALUE;
    object _11456 = NOVALUE;
    object _11454 = NOVALUE;
    object _11453 = NOVALUE;
    object _0, _1, _2;
    

    /** platform.e:174		sequence local_defines = {}*/
    RefDS(_5);
    DeRef(_local_defines_20443);
    _local_defines_20443 = _5;

    /** platform.e:176		if (IWINDOWS and not for_translator) or (TWINDOWS and for_translator) then*/
    if (0LL == 0) {
        _11453 = 0;
        goto L1; // [14] 25
    }
    _11454 = (0LL == 0);
    _11453 = (_11454 != 0);
L1: 
    if (_11453 != 0) {
        goto L2; // [25] 44
    }
    if (0LL == 0) {
        DeRef(_11456);
        _11456 = 0;
        goto L3; // [31] 39
    }
    _11456 = (_for_translator_20442 != 0);
L3: 
    if (_11456 == 0)
    {
        _11456 = NOVALUE;
        goto L4; // [40] 326
    }
    else{
        _11456 = NOVALUE;
    }
L2: 

    /** platform.e:177			local_defines &= {"WINDOWS", "WIN32"}*/
    RefDS(_11458);
    RefDS(_11457);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _11457;
    ((intptr_t *)_2)[2] = _11458;
    _11459 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20443, _local_defines_20443, _11459);
    DeRefDS(_11459);
    _11459 = NOVALUE;

    /** platform.e:178			sequence lcmds = command_line()*/
    DeRef(_lcmds_20453);
    _lcmds_20453 = Command_Line();

    /** platform.e:181			integer fh*/

    /** platform.e:182			fh = open(lcmds[1], "rb")*/
    _2 = (object)SEQ_PTR(_lcmds_20453);
    _11462 = (object)*(((s1_ptr)_2)->base + 1LL);
    _fh_20455 = EOpen(_11462, _8726, 0LL);
    _11462 = NOVALUE;

    /** platform.e:183			if fh = -1 then*/
    if (_fh_20455 != -1LL)
    goto L5; // [73] 123

    /** platform.e:185	 			if match("euiw", lower(lcmds[1])) != 0 then*/
    _2 = (object)SEQ_PTR(_lcmds_20453);
    _11466 = (object)*(((s1_ptr)_2)->base + 1LL);
    RefDS(_11466);
    _11467 = _18lower(_11466);
    _11466 = NOVALUE;
    _11468 = e_match_from(_11465, _11467, 1LL);
    DeRef(_11467);
    _11467 = NOVALUE;
    if (_11468 == 0LL)
    goto L6; // [92] 109

    /** platform.e:186	 				local_defines &= { "GUI" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11470);
    ((intptr_t*)_2)[1] = _11470;
    _11471 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20443, _local_defines_20443, _11471);
    DeRefDS(_11471);
    _11471 = NOVALUE;
    goto L7; // [106] 321
L6: 

    /** platform.e:188	 				local_defines &= { "CONSOLE" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11473);
    ((intptr_t*)_2)[1] = _11473;
    _11474 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20443, _local_defines_20443, _11474);
    DeRefDS(_11474);
    _11474 = NOVALUE;
    goto L7; // [120] 321
L5: 

    /** platform.e:191				atom sk*/

    /** platform.e:192				sk = seek(fh, #18) -- Fixed location of relocation table.*/
    _0 = _sk_20475;
    _sk_20475 = _17seek(_fh_20455, 24LL);
    DeRef(_0);

    /** platform.e:193				sk = get_integer16(fh)*/
    _0 = _sk_20475;
    _sk_20475 = _17get_integer16(_fh_20455);
    DeRef(_0);

    /** platform.e:194				if sk = #40 then*/
    if (binary_op_a(NOTEQ, _sk_20475, 64LL)){
        goto L8; // [140] 259
    }

    /** platform.e:196					sk = seek(fh, #3C) -- Fixed location of COFF signature offset.*/
    _0 = _sk_20475;
    _sk_20475 = _17seek(_fh_20455, 60LL);
    DeRef(_0);

    /** platform.e:197					sk = get_integer32(fh)*/
    _0 = _sk_20475;
    _sk_20475 = _17get_integer32(_fh_20455);
    DeRef(_0);

    /** platform.e:198					sk = seek(fh, sk)*/
    Ref(_sk_20475);
    _0 = _sk_20475;
    _sk_20475 = _17seek(_fh_20455, _sk_20475);
    DeRef(_0);

    /** platform.e:199					sk = get_integer16(fh)*/
    _0 = _sk_20475;
    _sk_20475 = _17get_integer16(_fh_20455);
    DeRef(_0);

    /** platform.e:200					if sk = #4550 then -- "PE" in intel endian*/
    if (binary_op_a(NOTEQ, _sk_20475, 17744LL)){
        goto L9; // [172] 221
    }

    /** platform.e:201						sk = get_integer16(fh)*/
    _0 = _sk_20475;
    _sk_20475 = _17get_integer16(_fh_20455);
    DeRef(_0);

    /** platform.e:202						if sk = 0 then*/
    if (binary_op_a(NOTEQ, _sk_20475, 0LL)){
        goto LA; // [184] 212
    }

    /** platform.e:204							sk = seek(fh, where(fh) + 88 )*/
    _11487 = _17where(_fh_20455);
    if (IS_ATOM_INT(_11487)) {
        _11488 = _11487 + 88LL;
        if ((object)((uintptr_t)_11488 + (uintptr_t)HIGH_BITS) >= 0){
            _11488 = NewDouble((eudouble)_11488);
        }
    }
    else {
        _11488 = binary_op(PLUS, _11487, 88LL);
    }
    DeRef(_11487);
    _11487 = NOVALUE;
    _0 = _sk_20475;
    _sk_20475 = _17seek(_fh_20455, _11488);
    DeRef(_0);
    _11488 = NOVALUE;

    /** platform.e:205							sk = get_integer16(fh)*/
    _0 = _sk_20475;
    _sk_20475 = _17get_integer16(_fh_20455);
    DeRef(_0);
    goto LB; // [209] 265
LA: 

    /** platform.e:207							sk = 0	-- Don't know this format.*/
    DeRef(_sk_20475);
    _sk_20475 = 0LL;
    goto LB; // [218] 265
L9: 

    /** platform.e:209					elsif sk = #454E then -- "NE" in intel endian*/
    if (binary_op_a(NOTEQ, _sk_20475, 17742LL)){
        goto LC; // [223] 250
    }

    /** platform.e:211						sk = seek(fh, where(fh) + 54 )*/
    _11493 = _17where(_fh_20455);
    if (IS_ATOM_INT(_11493)) {
        _11494 = _11493 + 54LL;
        if ((object)((uintptr_t)_11494 + (uintptr_t)HIGH_BITS) >= 0){
            _11494 = NewDouble((eudouble)_11494);
        }
    }
    else {
        _11494 = binary_op(PLUS, _11493, 54LL);
    }
    DeRef(_11493);
    _11493 = NOVALUE;
    _0 = _sk_20475;
    _sk_20475 = _17seek(_fh_20455, _11494);
    DeRef(_0);
    _11494 = NOVALUE;

    /** platform.e:212						sk = getc(fh)*/
    DeRef(_sk_20475);
    if (_fh_20455 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_20455, EF_READ);
        last_r_file_no = _fh_20455;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _sk_20475 = getc((FILE*)xstdin);
        }
        else{
            _sk_20475 = getc(last_r_file_ptr);
        }
    }
    else{
        _sk_20475 = getc(last_r_file_ptr);
    }
    goto LB; // [247] 265
LC: 

    /** platform.e:214						sk = 0*/
    DeRef(_sk_20475);
    _sk_20475 = 0LL;
    goto LB; // [256] 265
L8: 

    /** platform.e:217					sk = 0*/
    DeRef(_sk_20475);
    _sk_20475 = 0LL;
LB: 

    /** platform.e:219				if sk = 2 then*/
    if (binary_op_a(NOTEQ, _sk_20475, 2LL)){
        goto LD; // [267] 284
    }

    /** platform.e:220					local_defines &= { "GUI" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11470);
    ((intptr_t*)_2)[1] = _11470;
    _11498 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20443, _local_defines_20443, _11498);
    DeRefDS(_11498);
    _11498 = NOVALUE;
    goto LE; // [281] 314
LD: 

    /** platform.e:221				elsif sk = 3 then*/
    if (binary_op_a(NOTEQ, _sk_20475, 3LL)){
        goto LF; // [286] 303
    }

    /** platform.e:222					local_defines &= { "CONSOLE" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11473);
    ((intptr_t*)_2)[1] = _11473;
    _11501 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20443, _local_defines_20443, _11501);
    DeRefDS(_11501);
    _11501 = NOVALUE;
    goto LE; // [300] 314
LF: 

    /** platform.e:224					local_defines &= { "UNKNOWN" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11503);
    ((intptr_t*)_2)[1] = _11503;
    _11504 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20443, _local_defines_20443, _11504);
    DeRefDS(_11504);
    _11504 = NOVALUE;
LE: 

    /** platform.e:226				close(fh)*/
    EClose(_fh_20455);
    DeRef(_sk_20475);
    _sk_20475 = NOVALUE;
L7: 
    DeRef(_lcmds_20453);
    _lcmds_20453 = NOVALUE;
    goto L10; // [323] 575
L4: 

    /** platform.e:229			local_defines = append( local_defines, "CONSOLE" )*/
    RefDS(_11473);
    Append(&_local_defines_20443, _local_defines_20443, _11473);

    /** platform.e:230			if (ILINUX and not for_translator) or (TLINUX and for_translator) then*/
    if (_44ILINUX_20371 == 0) {
        _11507 = 0;
        goto L11; // [336] 347
    }
    _11508 = (_for_translator_20442 == 0);
    _11507 = (_11508 != 0);
L11: 
    if (_11507 != 0) {
        goto L12; // [347] 366
    }
    if (_44TLINUX_20372 == 0) {
        DeRef(_11510);
        _11510 = 0;
        goto L13; // [353] 361
    }
    _11510 = (_for_translator_20442 != 0);
L13: 
    if (_11510 == 0)
    {
        _11510 = NOVALUE;
        goto L14; // [362] 379
    }
    else{
        _11510 = NOVALUE;
    }
L12: 

    /** platform.e:231				local_defines &= {"UNIX", "LINUX"}*/
    RefDS(_11511);
    RefDS(_11244);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _11244;
    ((intptr_t *)_2)[2] = _11511;
    _11512 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20443, _local_defines_20443, _11512);
    DeRefDS(_11512);
    _11512 = NOVALUE;
    goto L15; // [376] 574
L14: 

    /** platform.e:232			elsif (IOSX and not for_translator) or (TOSX and for_translator) then*/
    if (0LL == 0) {
        _11514 = 0;
        goto L16; // [383] 394
    }
    _11515 = (_for_translator_20442 == 0);
    _11514 = (_11515 != 0);
L16: 
    if (_11514 != 0) {
        goto L17; // [394] 413
    }
    if (0LL == 0) {
        DeRef(_11517);
        _11517 = 0;
        goto L18; // [400] 408
    }
    _11517 = (_for_translator_20442 != 0);
L18: 
    if (_11517 == 0)
    {
        _11517 = NOVALUE;
        goto L19; // [409] 428
    }
    else{
        _11517 = NOVALUE;
    }
L17: 

    /** platform.e:233				local_defines &= {"UNIX", "BSD", "OSX"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11244);
    ((intptr_t*)_2)[1] = _11244;
    RefDS(_11518);
    ((intptr_t*)_2)[2] = _11518;
    RefDS(_11519);
    ((intptr_t*)_2)[3] = _11519;
    _11520 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20443, _local_defines_20443, _11520);
    DeRefDS(_11520);
    _11520 = NOVALUE;
    goto L15; // [425] 574
L19: 

    /** platform.e:234			elsif (IOPENBSD and not for_translator) or (TOPENBSD and for_translator) then*/
    if (0LL == 0) {
        _11522 = 0;
        goto L1A; // [432] 443
    }
    _11523 = (_for_translator_20442 == 0);
    _11522 = (_11523 != 0);
L1A: 
    if (_11522 != 0) {
        goto L1B; // [443] 462
    }
    if (0LL == 0) {
        DeRef(_11525);
        _11525 = 0;
        goto L1C; // [449] 457
    }
    _11525 = (_for_translator_20442 != 0);
L1C: 
    if (_11525 == 0)
    {
        _11525 = NOVALUE;
        goto L1D; // [458] 477
    }
    else{
        _11525 = NOVALUE;
    }
L1B: 

    /** platform.e:235				local_defines &= { "UNIX", "BSD", "OPENBSD"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11244);
    ((intptr_t*)_2)[1] = _11244;
    RefDS(_11518);
    ((intptr_t*)_2)[2] = _11518;
    RefDS(_11526);
    ((intptr_t*)_2)[3] = _11526;
    _11527 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20443, _local_defines_20443, _11527);
    DeRefDS(_11527);
    _11527 = NOVALUE;
    goto L15; // [474] 574
L1D: 

    /** platform.e:236			elsif (INETBSD and not for_translator) or (TNETBSD and for_translator) then*/
    if (0LL == 0) {
        _11529 = 0;
        goto L1E; // [481] 492
    }
    _11530 = (_for_translator_20442 == 0);
    _11529 = (_11530 != 0);
L1E: 
    if (_11529 != 0) {
        goto L1F; // [492] 511
    }
    if (0LL == 0) {
        DeRef(_11532);
        _11532 = 0;
        goto L20; // [498] 506
    }
    _11532 = (_for_translator_20442 != 0);
L20: 
    if (_11532 == 0)
    {
        _11532 = NOVALUE;
        goto L21; // [507] 526
    }
    else{
        _11532 = NOVALUE;
    }
L1F: 

    /** platform.e:237				local_defines &= { "UNIX", "BSD", "NETBSD"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11244);
    ((intptr_t*)_2)[1] = _11244;
    RefDS(_11518);
    ((intptr_t*)_2)[2] = _11518;
    RefDS(_11533);
    ((intptr_t*)_2)[3] = _11533;
    _11534 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20443, _local_defines_20443, _11534);
    DeRefDS(_11534);
    _11534 = NOVALUE;
    goto L15; // [523] 574
L21: 

    /** platform.e:238			elsif (IBSD and not for_translator) or (TBSD and for_translator) then*/
    if (0LL == 0) {
        _11536 = 0;
        goto L22; // [530] 541
    }
    _11537 = (_for_translator_20442 == 0);
    _11536 = (_11537 != 0);
L22: 
    if (_11536 != 0) {
        goto L23; // [541] 560
    }
    if (0LL == 0) {
        DeRef(_11539);
        _11539 = 0;
        goto L24; // [547] 555
    }
    _11539 = (_for_translator_20442 != 0);
L24: 
    if (_11539 == 0)
    {
        _11539 = NOVALUE;
        goto L25; // [556] 573
    }
    else{
        _11539 = NOVALUE;
    }
L23: 

    /** platform.e:239				local_defines &= {"UNIX", "BSD", "FREEBSD"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11244);
    ((intptr_t*)_2)[1] = _11244;
    RefDS(_11518);
    ((intptr_t*)_2)[2] = _11518;
    RefDS(_11540);
    ((intptr_t*)_2)[3] = _11540;
    _11541 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20443, _local_defines_20443, _11541);
    DeRefDS(_11541);
    _11541 = NOVALUE;
L25: 
L15: 
L10: 

    /** platform.e:243		if (IX86 and not for_translator) or (TX86 and for_translator) then*/
    if (0LL == 0) {
        _11543 = 0;
        goto L26; // [579] 590
    }
    _11544 = (_for_translator_20442 == 0);
    _11543 = (_11544 != 0);
L26: 
    if (_11543 != 0) {
        goto L27; // [590] 609
    }
    if (0LL == 0) {
        DeRef(_11546);
        _11546 = 0;
        goto L28; // [596] 604
    }
    _11546 = (_for_translator_20442 != 0);
L28: 
    if (_11546 == 0)
    {
        _11546 = NOVALUE;
        goto L29; // [605] 624
    }
    else{
        _11546 = NOVALUE;
    }
L27: 

    /** platform.e:244			local_defines &= {"X86", "BITS32", "LONG32"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11446);
    ((intptr_t*)_2)[1] = _11446;
    RefDS(_11547);
    ((intptr_t*)_2)[2] = _11547;
    RefDS(_11548);
    ((intptr_t*)_2)[3] = _11548;
    _11549 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20443, _local_defines_20443, _11549);
    DeRefDS(_11549);
    _11549 = NOVALUE;
    goto L2A; // [621] 777
L29: 

    /** platform.e:246		elsif (IX86_64 and not for_translator) or (TX86_64 and for_translator) then*/
    if (_44IX86_64_20385 == 0) {
        _11551 = 0;
        goto L2B; // [628] 639
    }
    _11552 = (_for_translator_20442 == 0);
    _11551 = (_11552 != 0);
L2B: 
    if (_11551 != 0) {
        goto L2C; // [639] 658
    }
    if (_44TX86_64_20386 == 0) {
        DeRef(_11554);
        _11554 = 0;
        goto L2D; // [645] 653
    }
    _11554 = (_for_translator_20442 != 0);
L2D: 
    if (_11554 == 0)
    {
        _11554 = NOVALUE;
        goto L2E; // [654] 729
    }
    else{
        _11554 = NOVALUE;
    }
L2C: 

    /** platform.e:247			local_defines &= {"X86_64", "BITS64"}*/
    RefDS(_11555);
    RefDS(_11448);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _11448;
    ((intptr_t *)_2)[2] = _11555;
    _11556 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20443, _local_defines_20443, _11556);
    DeRefDS(_11556);
    _11556 = NOVALUE;

    /** platform.e:248			if (IWINDOWS and not for_translator) or (TWINDOWS and for_translator) then*/
    if (0LL == 0) {
        _11558 = 0;
        goto L2F; // [672] 683
    }
    _11559 = (_for_translator_20442 == 0);
    _11558 = (_11559 != 0);
L2F: 
    if (_11558 != 0) {
        goto L30; // [683] 702
    }
    if (0LL == 0) {
        DeRef(_11561);
        _11561 = 0;
        goto L31; // [689] 697
    }
    _11561 = (_for_translator_20442 != 0);
L31: 
    if (_11561 == 0)
    {
        _11561 = NOVALUE;
        goto L32; // [698] 715
    }
    else{
        _11561 = NOVALUE;
    }
L30: 

    /** platform.e:249				local_defines &= {"LONG32"}*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11548);
    ((intptr_t*)_2)[1] = _11548;
    _11562 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20443, _local_defines_20443, _11562);
    DeRefDS(_11562);
    _11562 = NOVALUE;
    goto L2A; // [712] 777
L32: 

    /** platform.e:251				local_defines &= {"LONG64"}*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11564);
    ((intptr_t*)_2)[1] = _11564;
    _11565 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20443, _local_defines_20443, _11565);
    DeRefDS(_11565);
    _11565 = NOVALUE;
    goto L2A; // [726] 777
L2E: 

    /** platform.e:253		elsif (IARM and not for_translator) or (TARM and for_translator) then*/
    if (0LL == 0) {
        _11567 = 0;
        goto L33; // [733] 744
    }
    _11568 = (_for_translator_20442 == 0);
    _11567 = (_11568 != 0);
L33: 
    if (_11567 != 0) {
        goto L34; // [744] 763
    }
    if (0LL == 0) {
        DeRef(_11570);
        _11570 = 0;
        goto L35; // [750] 758
    }
    _11570 = (_for_translator_20442 != 0);
L35: 
    if (_11570 == 0)
    {
        _11570 = NOVALUE;
        goto L36; // [759] 776
    }
    else{
        _11570 = NOVALUE;
    }
L34: 

    /** platform.e:254			local_defines &= {"ARM", "BITS32", "LONG32"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11450);
    ((intptr_t*)_2)[1] = _11450;
    RefDS(_11547);
    ((intptr_t*)_2)[2] = _11547;
    RefDS(_11548);
    ((intptr_t*)_2)[3] = _11548;
    _11571 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_20443, _local_defines_20443, _11571);
    DeRefDS(_11571);
    _11571 = NOVALUE;
L36: 
L2A: 

    /** platform.e:259		return { "_PLAT_START" } & local_defines & { "_PLAT_STOP" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11573);
    ((intptr_t*)_2)[1] = _11573;
    _11574 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11575);
    ((intptr_t*)_2)[1] = _11575;
    _11576 = MAKE_SEQ(_1);
    {
        object concat_list[3];

        concat_list[0] = _11576;
        concat_list[1] = _local_defines_20443;
        concat_list[2] = _11574;
        Concat_N((object_ptr)&_11577, concat_list, 3);
    }
    DeRefDS(_11576);
    _11576 = NOVALUE;
    DeRefDS(_11574);
    _11574 = NOVALUE;
    DeRefDS(_local_defines_20443);
    DeRef(_11568);
    _11568 = NOVALUE;
    DeRef(_11523);
    _11523 = NOVALUE;
    DeRef(_11515);
    _11515 = NOVALUE;
    DeRef(_11508);
    _11508 = NOVALUE;
    DeRef(_11559);
    _11559 = NOVALUE;
    DeRef(_11454);
    _11454 = NOVALUE;
    DeRef(_11544);
    _11544 = NOVALUE;
    DeRef(_11552);
    _11552 = NOVALUE;
    DeRef(_11530);
    _11530 = NOVALUE;
    DeRef(_11537);
    _11537 = NOVALUE;
    return _11577;
    ;
}



// 0xC93B398E
