// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _21abs(object _a_2800)
{
    object _t_2801 = NOVALUE;
    object _1273 = NOVALUE;
    object _1272 = NOVALUE;
    object _1271 = NOVALUE;
    object _1269 = NOVALUE;
    object _1267 = NOVALUE;
    object _1266 = NOVALUE;
    object _1264 = NOVALUE;
    object _0, _1, _2;
    

    /** math.e:58		if atom(a) then*/
    _1264 = IS_ATOM(_a_2800);
    if (_1264 == 0)
    {
        _1264 = NOVALUE;
        goto L1; // [6] 35
    }
    else{
        _1264 = NOVALUE;
    }

    /** math.e:59			if a >= 0 then*/
    if (binary_op_a(LESS, _a_2800, 0LL)){
        goto L2; // [11] 24
    }

    /** math.e:60				return a*/
    DeRef(_t_2801);
    return _a_2800;
    goto L3; // [21] 34
L2: 

    /** math.e:62				return - a*/
    if (IS_ATOM_INT(_a_2800)) {
        if ((uintptr_t)_a_2800 == (uintptr_t)HIGH_BITS){
            _1266 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _1266 = - _a_2800;
        }
    }
    else {
        _1266 = unary_op(UMINUS, _a_2800);
    }
    DeRef(_a_2800);
    DeRef(_t_2801);
    return _1266;
L3: 
L1: 

    /** math.e:65		for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_2800)){
            _1267 = SEQ_PTR(_a_2800)->length;
    }
    else {
        _1267 = 1;
    }
    {
        object _i_2809;
        _i_2809 = 1LL;
L4: 
        if (_i_2809 > _1267){
            goto L5; // [40] 101
        }

        /** math.e:66			t = a[i]*/
        DeRef(_t_2801);
        _2 = (object)SEQ_PTR(_a_2800);
        _t_2801 = (object)*(((s1_ptr)_2)->base + _i_2809);
        Ref(_t_2801);

        /** math.e:67			if atom(t) then*/
        _1269 = IS_ATOM(_t_2801);
        if (_1269 == 0)
        {
            _1269 = NOVALUE;
            goto L6; // [58] 80
        }
        else{
            _1269 = NOVALUE;
        }

        /** math.e:68				if t < 0 then*/
        if (binary_op_a(GREATEREQ, _t_2801, 0LL)){
            goto L7; // [63] 94
        }

        /** math.e:69					a[i] = - t*/
        if (IS_ATOM_INT(_t_2801)) {
            if ((uintptr_t)_t_2801 == (uintptr_t)HIGH_BITS){
                _1271 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _1271 = - _t_2801;
            }
        }
        else {
            _1271 = unary_op(UMINUS, _t_2801);
        }
        _2 = (object)SEQ_PTR(_a_2800);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _a_2800 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_2809);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _1271;
        if( _1 != _1271 ){
            DeRef(_1);
        }
        _1271 = NOVALUE;
        goto L7; // [77] 94
L6: 

        /** math.e:72				a[i] = abs(t)*/
        Ref(_t_2801);
        DeRef(_1272);
        _1272 = _t_2801;
        _1273 = _21abs(_1272);
        _1272 = NOVALUE;
        _2 = (object)SEQ_PTR(_a_2800);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _a_2800 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_2809);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _1273;
        if( _1 != _1273 ){
            DeRef(_1);
        }
        _1273 = NOVALUE;
L7: 

        /** math.e:74		end for*/
        _i_2809 = _i_2809 + 1LL;
        goto L4; // [96] 47
L5: 
        ;
    }

    /** math.e:75		return a*/
    DeRef(_t_2801);
    DeRef(_1266);
    _1266 = NOVALUE;
    return _a_2800;
    ;
}


object _21max(object _a_2844)
{
    object _b_2845 = NOVALUE;
    object _c_2846 = NOVALUE;
    object _1283 = NOVALUE;
    object _1282 = NOVALUE;
    object _1281 = NOVALUE;
    object _0, _1, _2;
    

    /** math.e:199		if atom(a) then*/
    _1281 = IS_ATOM(_a_2844);
    if (_1281 == 0)
    {
        _1281 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _1281 = NOVALUE;
    }

    /** math.e:200			return a*/
    DeRef(_b_2845);
    DeRef(_c_2846);
    return _a_2844;
L1: 

    /** math.e:202		b = mathcons:MINF*/
    Ref(_23MINF_2778);
    DeRef(_b_2845);
    _b_2845 = _23MINF_2778;

    /** math.e:203		for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_2844)){
            _1282 = SEQ_PTR(_a_2844)->length;
    }
    else {
        _1282 = 1;
    }
    {
        object _i_2850;
        _i_2850 = 1LL;
L2: 
        if (_i_2850 > _1282){
            goto L3; // [28] 64
        }

        /** math.e:204			c = max(a[i])*/
        _2 = (object)SEQ_PTR(_a_2844);
        _1283 = (object)*(((s1_ptr)_2)->base + _i_2850);
        Ref(_1283);
        _0 = _c_2846;
        _c_2846 = _21max(_1283);
        DeRef(_0);
        _1283 = NOVALUE;

        /** math.e:205			if c > b then*/
        if (binary_op_a(LESSEQ, _c_2846, _b_2845)){
            goto L4; // [47] 57
        }

        /** math.e:206				b = c*/
        Ref(_c_2846);
        DeRef(_b_2845);
        _b_2845 = _c_2846;
L4: 

        /** math.e:208		end for*/
        _i_2850 = _i_2850 + 1LL;
        goto L2; // [59] 35
L3: 
        ;
    }

    /** math.e:209		return b*/
    DeRef(_a_2844);
    DeRef(_c_2846);
    return _b_2845;
    ;
}


object _21min(object _a_2858)
{
    object _b_2859 = NOVALUE;
    object _c_2860 = NOVALUE;
    object _1288 = NOVALUE;
    object _1287 = NOVALUE;
    object _1286 = NOVALUE;
    object _0, _1, _2;
    

    /** math.e:232		if atom(a) then*/
    _1286 = IS_ATOM(_a_2858);
    if (_1286 == 0)
    {
        _1286 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _1286 = NOVALUE;
    }

    /** math.e:233				return a*/
    DeRef(_b_2859);
    DeRef(_c_2860);
    return _a_2858;
L1: 

    /** math.e:235		b = mathcons:PINF*/
    Ref(_23PINF_2776);
    DeRef(_b_2859);
    _b_2859 = _23PINF_2776;

    /** math.e:236		for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_2858)){
            _1287 = SEQ_PTR(_a_2858)->length;
    }
    else {
        _1287 = 1;
    }
    {
        object _i_2864;
        _i_2864 = 1LL;
L2: 
        if (_i_2864 > _1287){
            goto L3; // [28] 64
        }

        /** math.e:237			c = min(a[i])*/
        _2 = (object)SEQ_PTR(_a_2858);
        _1288 = (object)*(((s1_ptr)_2)->base + _i_2864);
        Ref(_1288);
        _0 = _c_2860;
        _c_2860 = _21min(_1288);
        DeRef(_0);
        _1288 = NOVALUE;

        /** math.e:238				if c < b then*/
        if (binary_op_a(GREATEREQ, _c_2860, _b_2859)){
            goto L4; // [47] 57
        }

        /** math.e:239					b = c*/
        Ref(_c_2860);
        DeRef(_b_2859);
        _b_2859 = _c_2860;
L4: 

        /** math.e:241		end for*/
        _i_2864 = _i_2864 + 1LL;
        goto L2; // [59] 35
L3: 
        ;
    }

    /** math.e:242		return b*/
    DeRef(_a_2858);
    DeRef(_c_2860);
    return _b_2859;
    ;
}


object _21or_all(object _a_3237)
{
    object _b_3238 = NOVALUE;
    object _1487 = NOVALUE;
    object _1486 = NOVALUE;
    object _1484 = NOVALUE;
    object _1483 = NOVALUE;
    object _1482 = NOVALUE;
    object _1481 = NOVALUE;
    object _1480 = NOVALUE;
    object _0, _1, _2;
    

    /** math.e:1469		if atom(a) then*/
    _1480 = IS_ATOM(_a_3237);
    if (_1480 == 0)
    {
        _1480 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _1480 = NOVALUE;
    }

    /** math.e:1470			return a*/
    DeRef(_b_3238);
    return _a_3237;
L1: 

    /** math.e:1472		b = 0*/
    DeRef(_b_3238);
    _b_3238 = 0LL;

    /** math.e:1473		for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_3237)){
            _1481 = SEQ_PTR(_a_3237)->length;
    }
    else {
        _1481 = 1;
    }
    {
        object _i_3242;
        _i_3242 = 1LL;
L2: 
        if (_i_3242 > _1481){
            goto L3; // [26] 80
        }

        /** math.e:1474			if atom(a[i]) then*/
        _2 = (object)SEQ_PTR(_a_3237);
        _1482 = (object)*(((s1_ptr)_2)->base + _i_3242);
        _1483 = IS_ATOM(_1482);
        _1482 = NOVALUE;
        if (_1483 == 0)
        {
            _1483 = NOVALUE;
            goto L4; // [42] 58
        }
        else{
            _1483 = NOVALUE;
        }

        /** math.e:1475				b = or_bits(b, a[i])*/
        _2 = (object)SEQ_PTR(_a_3237);
        _1484 = (object)*(((s1_ptr)_2)->base + _i_3242);
        _0 = _b_3238;
        if (IS_ATOM_INT(_b_3238) && IS_ATOM_INT(_1484)) {
            {uintptr_t tu;
                 tu = (uintptr_t)_b_3238 | (uintptr_t)_1484;
                 _b_3238 = MAKE_UINT(tu);
            }
        }
        else {
            _b_3238 = binary_op(OR_BITS, _b_3238, _1484);
        }
        DeRef(_0);
        _1484 = NOVALUE;
        goto L5; // [55] 73
L4: 

        /** math.e:1477				b = or_bits(b, or_all(a[i]))*/
        _2 = (object)SEQ_PTR(_a_3237);
        _1486 = (object)*(((s1_ptr)_2)->base + _i_3242);
        Ref(_1486);
        _1487 = _21or_all(_1486);
        _1486 = NOVALUE;
        _0 = _b_3238;
        if (IS_ATOM_INT(_b_3238) && IS_ATOM_INT(_1487)) {
            {uintptr_t tu;
                 tu = (uintptr_t)_b_3238 | (uintptr_t)_1487;
                 _b_3238 = MAKE_UINT(tu);
            }
        }
        else {
            _b_3238 = binary_op(OR_BITS, _b_3238, _1487);
        }
        DeRef(_0);
        DeRef(_1487);
        _1487 = NOVALUE;
L5: 

        /** math.e:1479		end for*/
        _i_3242 = _i_3242 + 1LL;
        goto L2; // [75] 33
L3: 
        ;
    }

    /** math.e:1480		return b*/
    DeRef(_a_3237);
    return _b_3238;
    ;
}



// 0x107B78D2
