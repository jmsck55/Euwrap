// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _54c_putc(object _c_46696)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_c_46696)) {
        _1 = (object)(DBL_PTR(_c_46696)->dbl);
        DeRefDS(_c_46696);
        _c_46696 = _1;
    }

    /** c_out.e:62		if emit_c_output then*/
    if (_54emit_c_output_46683 == 0)
    {
        goto L1; // [7] 23
    }
    else{
    }

    /** c_out.e:63			puts(c_code, c)*/
    EPuts(_54c_code_46686, _c_46696); // DJP 

    /** c_out.e:64			update_checksum( c )*/
    _55update_checksum(_c_46696);
L1: 

    /** c_out.e:66	end procedure*/
    return;
    ;
}


void _54c_hputs(object _c_source_46701)
{
    object _0, _1, _2;
    

    /** c_out.e:71		if emit_c_output then*/
    if (_54emit_c_output_46683 == 0)
    {
        goto L1; // [7] 18
    }
    else{
    }

    /** c_out.e:72			puts(c_h, c_source)    */
    EPuts(_54c_h_46687, _c_source_46701); // DJP 
L1: 

    /** c_out.e:74	end procedure*/
    DeRefDS(_c_source_46701);
    return;
    ;
}


void _54c_puts(object _c_source_46705)
{
    object _0, _1, _2;
    

    /** c_out.e:79		if emit_c_output then*/
    if (_54emit_c_output_46683 == 0)
    {
        goto L1; // [7] 23
    }
    else{
    }

    /** c_out.e:80			puts(c_code, c_source)*/
    EPuts(_54c_code_46686, _c_source_46705); // DJP 

    /** c_out.e:81			update_checksum( c_source )*/
    RefDS(_c_source_46705);
    _55update_checksum(_c_source_46705);
L1: 

    /** c_out.e:83	end procedure*/
    DeRefDS(_c_source_46705);
    return;
    ;
}


void _54c_hprintf(object _format_46710, object _value_46711)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_value_46711)) {
        _1 = (object)(DBL_PTR(_value_46711)->dbl);
        DeRefDS(_value_46711);
        _value_46711 = _1;
    }

    /** c_out.e:88		if emit_c_output then*/
    if (_54emit_c_output_46683 == 0)
    {
        goto L1; // [9] 21
    }
    else{
    }

    /** c_out.e:89			printf(c_h, format, value)*/
    EPrintf(_54c_h_46687, _format_46710, _value_46711);
L1: 

    /** c_out.e:91	end procedure*/
    DeRefDSi(_format_46710);
    return;
    ;
}


void _54c_printf(object _format_46715, object _value_46716)
{
    object _text_46718 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:96		if emit_c_output then*/
    if (_54emit_c_output_46683 == 0)
    {
        goto L1; // [7] 29
    }
    else{
    }

    /** c_out.e:97			sequence text = sprintf( format, value )*/
    DeRefi(_text_46718);
    _text_46718 = EPrintf(-9999999, _format_46715, _value_46716);

    /** c_out.e:98			puts(c_code, text)*/
    EPuts(_54c_code_46686, _text_46718); // DJP 

    /** c_out.e:99			update_checksum( text )*/
    RefDS(_text_46718);
    _55update_checksum(_text_46718);
L1: 
    DeRefi(_text_46718);
    _text_46718 = NOVALUE;

    /** c_out.e:101	end procedure*/
    DeRefDSi(_format_46715);
    DeRef(_value_46716);
    return;
    ;
}


void _54c_printf8(object _value_46729)
{
    object _buff_46730 = NOVALUE;
    object _neg_46731 = NOVALUE;
    object _p_46732 = NOVALUE;
    object _24297 = NOVALUE;
    object _24295 = NOVALUE;
    object _24293 = NOVALUE;
    object _24291 = NOVALUE;
    object _24289 = NOVALUE;
    object _24287 = NOVALUE;
    object _24285 = NOVALUE;
    object _24283 = NOVALUE;
    object _24280 = NOVALUE;
    object _24278 = NOVALUE;
    object _24276 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:115		if emit_c_output then*/
    if (_54emit_c_output_46683 == 0)
    {
        goto L1; // [5] 182
    }
    else{
    }

    /** c_out.e:116			neg = 0*/
    _neg_46731 = 0LL;

    /** c_out.e:117			buff = sprintf("%.20eL", value)*/
    DeRef(_buff_46730);
    _buff_46730 = EPrintf(-9999999, _24274, _value_46729);

    /** c_out.e:118			if length(buff) < 10 then*/
    if (IS_SEQUENCE(_buff_46730)){
            _24276 = SEQ_PTR(_buff_46730)->length;
    }
    else {
        _24276 = 1;
    }
    if (_24276 >= 10LL)
    goto L2; // [24] 174

    /** c_out.e:120				p = 1*/
    _p_46732 = 1LL;

    /** c_out.e:121				while p <= length(buff) do*/
L3: 
    if (IS_SEQUENCE(_buff_46730)){
            _24278 = SEQ_PTR(_buff_46730)->length;
    }
    else {
        _24278 = 1;
    }
    if (_p_46732 > _24278)
    goto L4; // [41] 173

    /** c_out.e:122					if buff[p] = '-' then*/
    _2 = (object)SEQ_PTR(_buff_46730);
    _24280 = (object)*(((s1_ptr)_2)->base + _p_46732);
    if (binary_op_a(NOTEQ, _24280, 45LL)){
        _24280 = NOVALUE;
        goto L5; // [51] 63
    }
    _24280 = NOVALUE;

    /** c_out.e:123						neg = 1*/
    _neg_46731 = 1LL;
    goto L6; // [60] 162
L5: 

    /** c_out.e:125					elsif buff[p] = 'i' or buff[p] = 'I' then*/
    _2 = (object)SEQ_PTR(_buff_46730);
    _24283 = (object)*(((s1_ptr)_2)->base + _p_46732);
    if (IS_ATOM_INT(_24283)) {
        _24285 = (_24283 == 105LL);
    }
    else {
        _24285 = binary_op(EQUALS, _24283, 105LL);
    }
    _24283 = NOVALUE;
    if (IS_ATOM_INT(_24285)) {
        if (_24285 != 0) {
            goto L7; // [73] 90
        }
    }
    else {
        if (DBL_PTR(_24285)->dbl != 0.0) {
            goto L7; // [73] 90
        }
    }
    _2 = (object)SEQ_PTR(_buff_46730);
    _24287 = (object)*(((s1_ptr)_2)->base + _p_46732);
    if (IS_ATOM_INT(_24287)) {
        _24289 = (_24287 == 73LL);
    }
    else {
        _24289 = binary_op(EQUALS, _24287, 73LL);
    }
    _24287 = NOVALUE;
    if (_24289 == 0) {
        DeRef(_24289);
        _24289 = NOVALUE;
        goto L8; // [86] 114
    }
    else {
        if (!IS_ATOM_INT(_24289) && DBL_PTR(_24289)->dbl == 0.0){
            DeRef(_24289);
            _24289 = NOVALUE;
            goto L8; // [86] 114
        }
        DeRef(_24289);
        _24289 = NOVALUE;
    }
    DeRef(_24289);
    _24289 = NOVALUE;
L7: 

    /** c_out.e:127						buff = CREATE_INF*/
    RefDS(_54CREATE_INF_46721);
    DeRef(_buff_46730);
    _buff_46730 = _54CREATE_INF_46721;

    /** c_out.e:128						if neg then*/
    if (_neg_46731 == 0)
    {
        goto L4; // [97] 173
    }
    else{
    }

    /** c_out.e:129							buff = prepend(buff, '-')*/
    Prepend(&_buff_46730, _buff_46730, 45LL);

    /** c_out.e:131						exit*/
    goto L4; // [109] 173
    goto L6; // [111] 162
L8: 

    /** c_out.e:133					elsif buff[p] = 'n' or buff[p] = 'N' then*/
    _2 = (object)SEQ_PTR(_buff_46730);
    _24291 = (object)*(((s1_ptr)_2)->base + _p_46732);
    if (IS_ATOM_INT(_24291)) {
        _24293 = (_24291 == 110LL);
    }
    else {
        _24293 = binary_op(EQUALS, _24291, 110LL);
    }
    _24291 = NOVALUE;
    if (IS_ATOM_INT(_24293)) {
        if (_24293 != 0) {
            goto L9; // [124] 141
        }
    }
    else {
        if (DBL_PTR(_24293)->dbl != 0.0) {
            goto L9; // [124] 141
        }
    }
    _2 = (object)SEQ_PTR(_buff_46730);
    _24295 = (object)*(((s1_ptr)_2)->base + _p_46732);
    if (IS_ATOM_INT(_24295)) {
        _24297 = (_24295 == 78LL);
    }
    else {
        _24297 = binary_op(EQUALS, _24295, 78LL);
    }
    _24295 = NOVALUE;
    if (_24297 == 0) {
        DeRef(_24297);
        _24297 = NOVALUE;
        goto LA; // [137] 161
    }
    else {
        if (!IS_ATOM_INT(_24297) && DBL_PTR(_24297)->dbl == 0.0){
            DeRef(_24297);
            _24297 = NOVALUE;
            goto LA; // [137] 161
        }
        DeRef(_24297);
        _24297 = NOVALUE;
    }
    DeRef(_24297);
    _24297 = NOVALUE;
L9: 

    /** c_out.e:135						ifdef UNIX then*/

    /** c_out.e:136							buff = CREATE_NAN1*/
    RefDS(_54CREATE_NAN1_46723);
    DeRef(_buff_46730);
    _buff_46730 = _54CREATE_NAN1_46723;

    /** c_out.e:137							if neg then*/
    if (_neg_46731 == 0)
    {
        goto LB; // [150] 160
    }
    else{
    }

    /** c_out.e:138								buff = prepend(buff, '-')*/
    Prepend(&_buff_46730, _buff_46730, 45LL);
LB: 
LA: 
L6: 

    /** c_out.e:156					p += 1*/
    _p_46732 = _p_46732 + 1;

    /** c_out.e:157				end while*/
    goto L3; // [170] 38
L4: 
L2: 

    /** c_out.e:159			puts(c_code, buff)*/
    EPuts(_54c_code_46686, _buff_46730); // DJP 
L1: 

    /** c_out.e:161	end procedure*/
    DeRef(_value_46729);
    DeRef(_buff_46730);
    DeRef(_24293);
    _24293 = NOVALUE;
    DeRef(_24285);
    _24285 = NOVALUE;
    return;
    ;
}


void _54adjust_indent_before(object _stmt_46773)
{
    object _i_46774 = NOVALUE;
    object _lb_46776 = NOVALUE;
    object _rb_46777 = NOVALUE;
    object _24314 = NOVALUE;
    object _24312 = NOVALUE;
    object _24310 = NOVALUE;
    object _24302 = NOVALUE;
    object _24301 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:177		lb = FALSE*/
    _lb_46776 = _9FALSE_444;

    /** c_out.e:178		rb = FALSE*/
    _rb_46777 = _9FALSE_444;

    /** c_out.e:180		for p = 1 to length(stmt) do*/
    if (IS_SEQUENCE(_stmt_46773)){
            _24301 = SEQ_PTR(_stmt_46773)->length;
    }
    else {
        _24301 = 1;
    }
    {
        object _p_46781;
        _p_46781 = 1LL;
L1: 
        if (_p_46781 > _24301){
            goto L2; // [22] 102
        }

        /** c_out.e:181			switch stmt[p] do*/
        _2 = (object)SEQ_PTR(_stmt_46773);
        _24302 = (object)*(((s1_ptr)_2)->base + _p_46781);
        if (IS_SEQUENCE(_24302) ){
            goto L3; // [35] 95
        }
        if(!IS_ATOM_INT(_24302)){
            if( (DBL_PTR(_24302)->dbl != (eudouble) ((object) DBL_PTR(_24302)->dbl) ) ){
                goto L3; // [35] 95
            }
            _0 = (object) DBL_PTR(_24302)->dbl;
        }
        else {
            _0 = _24302;
        };
        _24302 = NOVALUE;
        switch ( _0 ){ 

            /** c_out.e:182				case '\n' then*/
            case 10:

            /** c_out.e:183					exit*/
            goto L2; // [46] 102
            goto L3; // [48] 95

            /** c_out.e:185				case  '}' then*/
            case 125:

            /** c_out.e:186					rb = TRUE*/
            _rb_46777 = _9TRUE_446;

            /** c_out.e:187					if lb then*/
            if (_lb_46776 == 0)
            {
                goto L3; // [63] 95
            }
            else{
            }

            /** c_out.e:188						exit*/
            goto L2; // [68] 102
            goto L3; // [71] 95

            /** c_out.e:191				case '{' then*/
            case 123:

            /** c_out.e:192					lb = TRUE*/
            _lb_46776 = _9TRUE_446;

            /** c_out.e:193					if rb then */
            if (_rb_46777 == 0)
            {
                goto L4; // [86] 94
            }
            else{
            }

            /** c_out.e:194						exit*/
            goto L2; // [91] 102
L4: 
        ;}L3: 

        /** c_out.e:198		end for*/
        _p_46781 = _p_46781 + 1LL;
        goto L1; // [97] 29
L2: 
        ;
    }

    /** c_out.e:200		if rb then*/
    if (_rb_46777 == 0)
    {
        goto L5; // [104] 122
    }
    else{
    }

    /** c_out.e:201			if not lb then*/
    if (_lb_46776 != 0)
    goto L6; // [109] 121

    /** c_out.e:202				indent -= 4*/
    _54indent_46767 = _54indent_46767 - 4LL;
L6: 
L5: 

    /** c_out.e:206		i = indent + temp_indent*/
    _i_46774 = _54indent_46767 + _54temp_indent_46768;

    /** c_out.e:207		while i >= length(big_blanks) do*/
L7: 
    if (IS_SEQUENCE(_54big_blanks_46769)){
            _24310 = SEQ_PTR(_54big_blanks_46769)->length;
    }
    else {
        _24310 = 1;
    }
    if (_i_46774 < _24310)
    goto L8; // [140] 163

    /** c_out.e:208			c_puts(big_blanks)*/
    RefDS(_54big_blanks_46769);
    _54c_puts(_54big_blanks_46769);

    /** c_out.e:209			i -= length(big_blanks)*/
    if (IS_SEQUENCE(_54big_blanks_46769)){
            _24312 = SEQ_PTR(_54big_blanks_46769)->length;
    }
    else {
        _24312 = 1;
    }
    _i_46774 = _i_46774 - _24312;
    _24312 = NOVALUE;

    /** c_out.e:210		end while*/
    goto L7; // [160] 137
L8: 

    /** c_out.e:212		c_puts(big_blanks[1..i])*/
    rhs_slice_target = (object_ptr)&_24314;
    RHS_Slice(_54big_blanks_46769, 1LL, _i_46774);
    _54c_puts(_24314);
    _24314 = NOVALUE;

    /** c_out.e:214		temp_indent = 0    */
    _54temp_indent_46768 = 0LL;

    /** c_out.e:215	end procedure*/
    DeRefDS(_stmt_46773);
    return;
    ;
}


void _54adjust_indent_after(object _stmt_46808)
{
    object _24335 = NOVALUE;
    object _24334 = NOVALUE;
    object _24332 = NOVALUE;
    object _24330 = NOVALUE;
    object _24329 = NOVALUE;
    object _24326 = NOVALUE;
    object _24324 = NOVALUE;
    object _24323 = NOVALUE;
    object _24320 = NOVALUE;
    object _24316 = NOVALUE;
    object _24315 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:221		for p = 1 to length(stmt) do*/
    if (IS_SEQUENCE(_stmt_46808)){
            _24315 = SEQ_PTR(_stmt_46808)->length;
    }
    else {
        _24315 = 1;
    }
    {
        object _p_46810;
        _p_46810 = 1LL;
L1: 
        if (_p_46810 > _24315){
            goto L2; // [8] 61
        }

        /** c_out.e:222			switch stmt[p] do*/
        _2 = (object)SEQ_PTR(_stmt_46808);
        _24316 = (object)*(((s1_ptr)_2)->base + _p_46810);
        if (IS_SEQUENCE(_24316) ){
            goto L3; // [21] 54
        }
        if(!IS_ATOM_INT(_24316)){
            if( (DBL_PTR(_24316)->dbl != (eudouble) ((object) DBL_PTR(_24316)->dbl) ) ){
                goto L3; // [21] 54
            }
            _0 = (object) DBL_PTR(_24316)->dbl;
        }
        else {
            _0 = _24316;
        };
        _24316 = NOVALUE;
        switch ( _0 ){ 

            /** c_out.e:223				case '\n' then*/
            case 10:

            /** c_out.e:224					exit*/
            goto L2; // [32] 61
            goto L3; // [34] 54

            /** c_out.e:226				case '{' then*/
            case 123:

            /** c_out.e:227					indent += 4*/
            _54indent_46767 = _54indent_46767 + 4LL;

            /** c_out.e:228					return*/
            DeRefDS(_stmt_46808);
            return;
        ;}L3: 

        /** c_out.e:230		end for*/
        _p_46810 = _p_46810 + 1LL;
        goto L1; // [56] 15
L2: 
        ;
    }

    /** c_out.e:232		if length(stmt) < 3 then*/
    if (IS_SEQUENCE(_stmt_46808)){
            _24320 = SEQ_PTR(_stmt_46808)->length;
    }
    else {
        _24320 = 1;
    }
    if (_24320 >= 3LL)
    goto L4; // [66] 76

    /** c_out.e:233			return*/
    DeRefDS(_stmt_46808);
    return;
L4: 

    /** c_out.e:236		if not equal("if ", stmt[1..3]) then*/
    rhs_slice_target = (object_ptr)&_24323;
    RHS_Slice(_stmt_46808, 1LL, 3LL);
    if (_24322 == _24323)
    _24324 = 1;
    else if (IS_ATOM_INT(_24322) && IS_ATOM_INT(_24323))
    _24324 = 0;
    else
    _24324 = (compare(_24322, _24323) == 0);
    DeRefDS(_24323);
    _24323 = NOVALUE;
    if (_24324 != 0)
    goto L5; // [87] 96
    _24324 = NOVALUE;

    /** c_out.e:237			return*/
    DeRefDS(_stmt_46808);
    return;
L5: 

    /** c_out.e:240		if length(stmt) < 5 then*/
    if (IS_SEQUENCE(_stmt_46808)){
            _24326 = SEQ_PTR(_stmt_46808)->length;
    }
    else {
        _24326 = 1;
    }
    if (_24326 >= 5LL)
    goto L6; // [101] 111

    /** c_out.e:241			return*/
    DeRefDS(_stmt_46808);
    return;
L6: 

    /** c_out.e:244		if not equal("else", stmt[1..4]) then*/
    rhs_slice_target = (object_ptr)&_24329;
    RHS_Slice(_stmt_46808, 1LL, 4LL);
    if (_24328 == _24329)
    _24330 = 1;
    else if (IS_ATOM_INT(_24328) && IS_ATOM_INT(_24329))
    _24330 = 0;
    else
    _24330 = (compare(_24328, _24329) == 0);
    DeRefDS(_24329);
    _24329 = NOVALUE;
    if (_24330 != 0)
    goto L7; // [122] 131
    _24330 = NOVALUE;

    /** c_out.e:245			return*/
    DeRefDS(_stmt_46808);
    return;
L7: 

    /** c_out.e:248		if not find(stmt[5], {" \n"}) then*/
    _2 = (object)SEQ_PTR(_stmt_46808);
    _24332 = (object)*(((s1_ptr)_2)->base + 5LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_24333);
    ((intptr_t*)_2)[1] = _24333;
    _24334 = MAKE_SEQ(_1);
    _24335 = find_from(_24332, _24334, 1LL);
    _24332 = NOVALUE;
    DeRefDS(_24334);
    _24334 = NOVALUE;
    if (_24335 != 0)
    goto L8; // [146] 155
    _24335 = NOVALUE;

    /** c_out.e:249			return*/
    DeRefDS(_stmt_46808);
    return;
L8: 

    /** c_out.e:252		temp_indent = 4*/
    _54temp_indent_46768 = 4LL;

    /** c_out.e:254	end procedure*/
    DeRefDS(_stmt_46808);
    return;
    ;
}



// 0xD9480AAD
