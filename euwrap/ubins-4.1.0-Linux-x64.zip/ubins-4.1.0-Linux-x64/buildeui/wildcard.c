// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _11qmatch(object _p_1625, object _s_1626)
{
    object _k_1627 = NOVALUE;
    object _692 = NOVALUE;
    object _691 = NOVALUE;
    object _690 = NOVALUE;
    object _689 = NOVALUE;
    object _688 = NOVALUE;
    object _687 = NOVALUE;
    object _686 = NOVALUE;
    object _685 = NOVALUE;
    object _684 = NOVALUE;
    object _683 = NOVALUE;
    object _682 = NOVALUE;
    object _681 = NOVALUE;
    object _679 = NOVALUE;
    object _0, _1, _2;
    

    /** wildcard.e:21		if not find('?', p) then*/
    _679 = find_from(63LL, _p_1625, 1LL);
    if (_679 != 0)
    goto L1; // [12] 27
    _679 = NOVALUE;

    /** wildcard.e:22			return match(p, s) -- fast*/
    _681 = e_match_from(_p_1625, _s_1626, 1LL);
    DeRefDS(_p_1625);
    DeRefDS(_s_1626);
    return _681;
L1: 

    /** wildcard.e:25		for i = 1 to length(s) - length(p) + 1 do*/
    if (IS_SEQUENCE(_s_1626)){
            _682 = SEQ_PTR(_s_1626)->length;
    }
    else {
        _682 = 1;
    }
    if (IS_SEQUENCE(_p_1625)){
            _683 = SEQ_PTR(_p_1625)->length;
    }
    else {
        _683 = 1;
    }
    _684 = _682 - _683;
    _682 = NOVALUE;
    _683 = NOVALUE;
    _685 = _684 + 1;
    _684 = NOVALUE;
    {
        object _i_1633;
        _i_1633 = 1LL;
L2: 
        if (_i_1633 > _685){
            goto L3; // [43] 142
        }

        /** wildcard.e:26			k = i*/
        _k_1627 = _i_1633;

        /** wildcard.e:27			for j = 1 to length(p) do*/
        if (IS_SEQUENCE(_p_1625)){
                _686 = SEQ_PTR(_p_1625)->length;
        }
        else {
            _686 = 1;
        }
        {
            object _j_1639;
            _j_1639 = 1LL;
L4: 
            if (_j_1639 > _686){
                goto L5; // [62] 122
            }

            /** wildcard.e:28				if p[j] != s[k] and p[j] != '?' then*/
            _2 = (object)SEQ_PTR(_p_1625);
            _687 = (object)*(((s1_ptr)_2)->base + _j_1639);
            _2 = (object)SEQ_PTR(_s_1626);
            _688 = (object)*(((s1_ptr)_2)->base + _k_1627);
            if (IS_ATOM_INT(_687) && IS_ATOM_INT(_688)) {
                _689 = (_687 != _688);
            }
            else {
                _689 = binary_op(NOTEQ, _687, _688);
            }
            _687 = NOVALUE;
            _688 = NOVALUE;
            if (IS_ATOM_INT(_689)) {
                if (_689 == 0) {
                    goto L6; // [83] 109
                }
            }
            else {
                if (DBL_PTR(_689)->dbl == 0.0) {
                    goto L6; // [83] 109
                }
            }
            _2 = (object)SEQ_PTR(_p_1625);
            _691 = (object)*(((s1_ptr)_2)->base + _j_1639);
            if (IS_ATOM_INT(_691)) {
                _692 = (_691 != 63LL);
            }
            else {
                _692 = binary_op(NOTEQ, _691, 63LL);
            }
            _691 = NOVALUE;
            if (_692 == 0) {
                DeRef(_692);
                _692 = NOVALUE;
                goto L6; // [96] 109
            }
            else {
                if (!IS_ATOM_INT(_692) && DBL_PTR(_692)->dbl == 0.0){
                    DeRef(_692);
                    _692 = NOVALUE;
                    goto L6; // [96] 109
                }
                DeRef(_692);
                _692 = NOVALUE;
            }
            DeRef(_692);
            _692 = NOVALUE;

            /** wildcard.e:29					k = 0*/
            _k_1627 = 0LL;

            /** wildcard.e:30					exit*/
            goto L5; // [106] 122
L6: 

            /** wildcard.e:32				k += 1*/
            _k_1627 = _k_1627 + 1;

            /** wildcard.e:33			end for*/
            _j_1639 = _j_1639 + 1LL;
            goto L4; // [117] 69
L5: 
            ;
        }

        /** wildcard.e:34			if k != 0 then*/
        if (_k_1627 == 0LL)
        goto L7; // [124] 135

        /** wildcard.e:35				return i*/
        DeRefDS(_p_1625);
        DeRefDS(_s_1626);
        DeRef(_689);
        _689 = NOVALUE;
        DeRef(_685);
        _685 = NOVALUE;
        return _i_1633;
L7: 

        /** wildcard.e:37		end for*/
        _i_1633 = _i_1633 + 1LL;
        goto L2; // [137] 50
L3: 
        ;
    }

    /** wildcard.e:38		return 0*/
    DeRefDS(_p_1625);
    DeRefDS(_s_1626);
    DeRef(_689);
    _689 = NOVALUE;
    DeRef(_685);
    _685 = NOVALUE;
    return 0LL;
    ;
}


object _11is_match(object _pattern_1654, object _string_1655)
{
    object _p_1656 = NOVALUE;
    object _f_1657 = NOVALUE;
    object _t_1658 = NOVALUE;
    object _match_string_1659 = NOVALUE;
    object _735 = NOVALUE;
    object _734 = NOVALUE;
    object _732 = NOVALUE;
    object _728 = NOVALUE;
    object _727 = NOVALUE;
    object _726 = NOVALUE;
    object _723 = NOVALUE;
    object _722 = NOVALUE;
    object _719 = NOVALUE;
    object _716 = NOVALUE;
    object _714 = NOVALUE;
    object _712 = NOVALUE;
    object _710 = NOVALUE;
    object _707 = NOVALUE;
    object _704 = NOVALUE;
    object _702 = NOVALUE;
    object _701 = NOVALUE;
    object _700 = NOVALUE;
    object _699 = NOVALUE;
    object _697 = NOVALUE;
    object _0, _1, _2;
    

    /** wildcard.e:95		pattern = pattern & END_MARKER*/
    Append(&_pattern_1654, _pattern_1654, -1LL);

    /** wildcard.e:96		string = string & END_MARKER*/
    Append(&_string_1655, _string_1655, -1LL);

    /** wildcard.e:97		p = 1*/
    _p_1656 = 1LL;

    /** wildcard.e:98		f = 1*/
    _f_1657 = 1LL;

    /** wildcard.e:99		while f <= length(string) do*/
L1: 
    if (IS_SEQUENCE(_string_1655)){
            _697 = SEQ_PTR(_string_1655)->length;
    }
    else {
        _697 = 1;
    }
    if (_f_1657 > _697)
    goto L2; // [35] 288

    /** wildcard.e:100			if not find(pattern[p], {string[f], '?'}) then*/
    _2 = (object)SEQ_PTR(_pattern_1654);
    _699 = (object)*(((s1_ptr)_2)->base + _p_1656);
    _2 = (object)SEQ_PTR(_string_1655);
    _700 = (object)*(((s1_ptr)_2)->base + _f_1657);
    Ref(_700);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _700;
    ((intptr_t *)_2)[2] = 63LL;
    _701 = MAKE_SEQ(_1);
    _700 = NOVALUE;
    _702 = find_from(_699, _701, 1LL);
    _699 = NOVALUE;
    DeRefDS(_701);
    _701 = NOVALUE;
    if (_702 != 0)
    goto L3; // [58] 248
    _702 = NOVALUE;

    /** wildcard.e:101				if pattern[p] = '*' then*/
    _2 = (object)SEQ_PTR(_pattern_1654);
    _704 = (object)*(((s1_ptr)_2)->base + _p_1656);
    if (binary_op_a(NOTEQ, _704, 42LL)){
        _704 = NOVALUE;
        goto L4; // [67] 240
    }
    _704 = NOVALUE;

    /** wildcard.e:102					while pattern[p] = '*' do*/
L5: 
    _2 = (object)SEQ_PTR(_pattern_1654);
    _707 = (object)*(((s1_ptr)_2)->base + _p_1656);
    if (binary_op_a(NOTEQ, _707, 42LL)){
        _707 = NOVALUE;
        goto L6; // [80] 95
    }
    _707 = NOVALUE;

    /** wildcard.e:103						p += 1*/
    _p_1656 = _p_1656 + 1;

    /** wildcard.e:104					end while*/
    goto L5; // [92] 76
L6: 

    /** wildcard.e:105					if pattern[p] = END_MARKER then*/
    _2 = (object)SEQ_PTR(_pattern_1654);
    _710 = (object)*(((s1_ptr)_2)->base + _p_1656);
    if (binary_op_a(NOTEQ, _710, -1LL)){
        _710 = NOVALUE;
        goto L7; // [101] 112
    }
    _710 = NOVALUE;

    /** wildcard.e:106						return 1*/
    DeRefDS(_pattern_1654);
    DeRefDS(_string_1655);
    DeRef(_match_string_1659);
    return 1LL;
L7: 

    /** wildcard.e:108					match_string = ""*/
    RefDS(_5);
    DeRef(_match_string_1659);
    _match_string_1659 = _5;

    /** wildcard.e:109					while pattern[p] != '*' do*/
L8: 
    _2 = (object)SEQ_PTR(_pattern_1654);
    _712 = (object)*(((s1_ptr)_2)->base + _p_1656);
    if (binary_op_a(EQUALS, _712, 42LL)){
        _712 = NOVALUE;
        goto L9; // [128] 168
    }
    _712 = NOVALUE;

    /** wildcard.e:110						match_string = match_string & pattern[p]*/
    _2 = (object)SEQ_PTR(_pattern_1654);
    _714 = (object)*(((s1_ptr)_2)->base + _p_1656);
    if (IS_SEQUENCE(_match_string_1659) && IS_ATOM(_714)) {
        Ref(_714);
        Append(&_match_string_1659, _match_string_1659, _714);
    }
    else if (IS_ATOM(_match_string_1659) && IS_SEQUENCE(_714)) {
    }
    else {
        Concat((object_ptr)&_match_string_1659, _match_string_1659, _714);
    }
    _714 = NOVALUE;

    /** wildcard.e:111						if pattern[p] = END_MARKER then*/
    _2 = (object)SEQ_PTR(_pattern_1654);
    _716 = (object)*(((s1_ptr)_2)->base + _p_1656);
    if (binary_op_a(NOTEQ, _716, -1LL)){
        _716 = NOVALUE;
        goto LA; // [148] 157
    }
    _716 = NOVALUE;

    /** wildcard.e:112							exit*/
    goto L9; // [154] 168
LA: 

    /** wildcard.e:114						p += 1*/
    _p_1656 = _p_1656 + 1;

    /** wildcard.e:115					end while*/
    goto L8; // [165] 124
L9: 

    /** wildcard.e:116					if pattern[p] = '*' then*/
    _2 = (object)SEQ_PTR(_pattern_1654);
    _719 = (object)*(((s1_ptr)_2)->base + _p_1656);
    if (binary_op_a(NOTEQ, _719, 42LL)){
        _719 = NOVALUE;
        goto LB; // [174] 185
    }
    _719 = NOVALUE;

    /** wildcard.e:117						p -= 1*/
    _p_1656 = _p_1656 - 1LL;
LB: 

    /** wildcard.e:119					t = qmatch(match_string, string[f..$])*/
    if (IS_SEQUENCE(_string_1655)){
            _722 = SEQ_PTR(_string_1655)->length;
    }
    else {
        _722 = 1;
    }
    rhs_slice_target = (object_ptr)&_723;
    RHS_Slice(_string_1655, _f_1657, _722);
    RefDS(_match_string_1659);
    _t_1658 = _11qmatch(_match_string_1659, _723);
    _723 = NOVALUE;
    if (!IS_ATOM_INT(_t_1658)) {
        _1 = (object)(DBL_PTR(_t_1658)->dbl);
        DeRefDS(_t_1658);
        _t_1658 = _1;
    }

    /** wildcard.e:120					if t = 0 then*/
    if (_t_1658 != 0LL)
    goto LC; // [204] 217

    /** wildcard.e:121						return 0*/
    DeRefDS(_pattern_1654);
    DeRefDS(_string_1655);
    DeRefDS(_match_string_1659);
    return 0LL;
    goto LD; // [214] 247
LC: 

    /** wildcard.e:123						f += t + length(match_string) - 2*/
    if (IS_SEQUENCE(_match_string_1659)){
            _726 = SEQ_PTR(_match_string_1659)->length;
    }
    else {
        _726 = 1;
    }
    _727 = _t_1658 + _726;
    if ((object)((uintptr_t)_727 + (uintptr_t)HIGH_BITS) >= 0){
        _727 = NewDouble((eudouble)_727);
    }
    _726 = NOVALUE;
    if (IS_ATOM_INT(_727)) {
        _728 = _727 - 2LL;
        if ((object)((uintptr_t)_728 +(uintptr_t) HIGH_BITS) >= 0){
            _728 = NewDouble((eudouble)_728);
        }
    }
    else {
        _728 = NewDouble(DBL_PTR(_727)->dbl - (eudouble)2LL);
    }
    DeRef(_727);
    _727 = NOVALUE;
    if (IS_ATOM_INT(_728)) {
        _f_1657 = _f_1657 + _728;
    }
    else {
        _f_1657 = NewDouble((eudouble)_f_1657 + DBL_PTR(_728)->dbl);
    }
    DeRef(_728);
    _728 = NOVALUE;
    if (!IS_ATOM_INT(_f_1657)) {
        _1 = (object)(DBL_PTR(_f_1657)->dbl);
        DeRefDS(_f_1657);
        _f_1657 = _1;
    }
    goto LD; // [237] 247
L4: 

    /** wildcard.e:126					return 0*/
    DeRefDS(_pattern_1654);
    DeRefDS(_string_1655);
    DeRef(_match_string_1659);
    return 0LL;
LD: 
L3: 

    /** wildcard.e:129			p += 1*/
    _p_1656 = _p_1656 + 1;

    /** wildcard.e:130			f += 1*/
    _f_1657 = _f_1657 + 1;

    /** wildcard.e:131			if p > length(pattern) then*/
    if (IS_SEQUENCE(_pattern_1654)){
            _732 = SEQ_PTR(_pattern_1654)->length;
    }
    else {
        _732 = 1;
    }
    if (_p_1656 <= _732)
    goto L1; // [265] 32

    /** wildcard.e:132				return f > length(string) */
    if (IS_SEQUENCE(_string_1655)){
            _734 = SEQ_PTR(_string_1655)->length;
    }
    else {
        _734 = 1;
    }
    _735 = (_f_1657 > _734);
    _734 = NOVALUE;
    DeRefDS(_pattern_1654);
    DeRefDS(_string_1655);
    DeRef(_match_string_1659);
    return _735;

    /** wildcard.e:134		end while*/
    goto L1; // [285] 32
L2: 

    /** wildcard.e:135		return 0*/
    DeRefDS(_pattern_1654);
    DeRefDS(_string_1655);
    DeRef(_match_string_1659);
    DeRef(_735);
    _735 = NOVALUE;
    return 0LL;
    ;
}



// 0x285C395C
