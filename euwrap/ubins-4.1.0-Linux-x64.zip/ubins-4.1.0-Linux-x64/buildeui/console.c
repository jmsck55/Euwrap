// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _38any_key(object _prompt_14290, object _con_14292)
{
    object _wait_key_inlined_wait_key_at_27_14298 = NOVALUE;
    object _8195 = NOVALUE;
    object _0, _1, _2;
    

    /** console.e:883		if not find(con, {1,2}) then*/
    _8195 = find_from(_con_14292, _8194, 1LL);
    if (_8195 != 0)
    goto L1; // [12] 21
    _8195 = NOVALUE;

    /** console.e:884			con = 1*/
    _con_14292 = 1LL;
L1: 

    /** console.e:886		puts(con, prompt)*/
    EPuts(_con_14292, _prompt_14290); // DJP 

    /** console.e:887		wait_key()*/

    /** console.e:854		return machine_func(M_WAIT_KEY, 0)*/
    _wait_key_inlined_wait_key_at_27_14298 = machine(26LL, 0LL);

    /** console.e:888		puts(con, "\n")*/
    EPuts(_con_14292, _8197); // DJP 

    /** console.e:889	end procedure*/
    DeRefDS(_prompt_14290);
    return;
    ;
}


void _38maybe_any_key(object _prompt_14302, object _con_14303)
{
    object _has_console_inlined_has_console_at_6_14306 = NOVALUE;
    object _0, _1, _2;
    

    /** console.e:923		if not has_console() then*/

    /** console.e:59		return machine_func(M_HAS_CONSOLE, 0)*/
    DeRef(_has_console_inlined_has_console_at_6_14306);
    _has_console_inlined_has_console_at_6_14306 = machine(99LL, 0LL);
    if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_14306)) {
        if (_has_console_inlined_has_console_at_6_14306 != 0){
            goto L1; // [14] 24
        }
    }
    else {
        if (DBL_PTR(_has_console_inlined_has_console_at_6_14306)->dbl != 0.0){
            goto L1; // [14] 24
        }
    }

    /** console.e:924			any_key(prompt, con)*/
    RefDS(_prompt_14302);
    _38any_key(_prompt_14302, _con_14303);
L1: 

    /** console.e:926	end procedure*/
    DeRefDS(_prompt_14302);
    return;
    ;
}



// 0x67470E63
