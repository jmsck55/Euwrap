// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _53hashfn(object _name_46861)
{
    object _len_46862 = NOVALUE;
    object _val_46863 = NOVALUE;
    object _int_46864 = NOVALUE;
    object _24362 = NOVALUE;
    object _24361 = NOVALUE;
    object _24358 = NOVALUE;
    object _24357 = NOVALUE;
    object _24346 = NOVALUE;
    object _24342 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:49		len = length(name)*/
    if (IS_SEQUENCE(_name_46861)){
            _len_46862 = SEQ_PTR(_name_46861)->length;
    }
    else {
        _len_46862 = 1;
    }

    /** symtab.e:51		val = name[1]*/
    _2 = (object)SEQ_PTR(_name_46861);
    _val_46863 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_val_46863))
    _val_46863 = (object)DBL_PTR(_val_46863)->dbl;

    /** symtab.e:52		int = name[$]*/
    if (IS_SEQUENCE(_name_46861)){
            _24342 = SEQ_PTR(_name_46861)->length;
    }
    else {
        _24342 = 1;
    }
    _2 = (object)SEQ_PTR(_name_46861);
    _int_46864 = (object)*(((s1_ptr)_2)->base + _24342);
    if (!IS_ATOM_INT(_int_46864))
    _int_46864 = (object)DBL_PTR(_int_46864)->dbl;

    /** symtab.e:53		int *= 256*/
    _int_46864 = _int_46864 * 256LL;

    /** symtab.e:54		val *= 2*/
    _val_46863 = _val_46863 + _val_46863;

    /** symtab.e:55		val += int + len*/
    _24346 = _int_46864 + _len_46862;
    if ((object)((uintptr_t)_24346 + (uintptr_t)HIGH_BITS) >= 0){
        _24346 = NewDouble((eudouble)_24346);
    }
    if (IS_ATOM_INT(_24346)) {
        _val_46863 = _val_46863 + _24346;
    }
    else {
        _val_46863 = NewDouble((eudouble)_val_46863 + DBL_PTR(_24346)->dbl);
    }
    DeRef(_24346);
    _24346 = NOVALUE;
    if (!IS_ATOM_INT(_val_46863)) {
        _1 = (object)(DBL_PTR(_val_46863)->dbl);
        DeRefDS(_val_46863);
        _val_46863 = _1;
    }

    /** symtab.e:57		if len = 3 then*/
    if (_len_46862 != 3LL)
    goto L1; // [51] 78

    /** symtab.e:58			val *= 32*/
    _val_46863 = _val_46863 * 32LL;

    /** symtab.e:59			int = name[2]*/
    _2 = (object)SEQ_PTR(_name_46861);
    _int_46864 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_int_46864))
    _int_46864 = (object)DBL_PTR(_int_46864)->dbl;

    /** symtab.e:60			val += int*/
    _val_46863 = _val_46863 + _int_46864;
    goto L2; // [75] 133
L1: 

    /** symtab.e:61		elsif len > 3 then*/
    if (_len_46862 <= 3LL)
    goto L3; // [80] 132

    /** symtab.e:62			val *= 32*/
    _val_46863 = _val_46863 * 32LL;

    /** symtab.e:63			int = name[2]*/
    _2 = (object)SEQ_PTR(_name_46861);
    _int_46864 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_int_46864))
    _int_46864 = (object)DBL_PTR(_int_46864)->dbl;

    /** symtab.e:64			val += int*/
    _val_46863 = _val_46863 + _int_46864;

    /** symtab.e:66			val *= 32*/
    _val_46863 = _val_46863 * 32LL;

    /** symtab.e:67			int = name[$-1]*/
    if (IS_SEQUENCE(_name_46861)){
            _24357 = SEQ_PTR(_name_46861)->length;
    }
    else {
        _24357 = 1;
    }
    _24358 = _24357 - 1LL;
    _24357 = NOVALUE;
    _2 = (object)SEQ_PTR(_name_46861);
    _int_46864 = (object)*(((s1_ptr)_2)->base + _24358);
    if (!IS_ATOM_INT(_int_46864))
    _int_46864 = (object)DBL_PTR(_int_46864)->dbl;

    /** symtab.e:68			val += int*/
    _val_46863 = _val_46863 + _int_46864;
L3: 
L2: 

    /** symtab.e:70		return remainder(val, NBUCKETS) + 1*/
    _24361 = (_val_46863 % 2003LL);
    _24362 = _24361 + 1;
    _24361 = NOVALUE;
    DeRefDS(_name_46861);
    DeRef(_24358);
    _24358 = NOVALUE;
    return _24362;
    ;
}


void _53remove_symbol(object _sym_46893)
{
    object _hash_46894 = NOVALUE;
    object _st_ptr_46895 = NOVALUE;
    object _24377 = NOVALUE;
    object _24376 = NOVALUE;
    object _24374 = NOVALUE;
    object _24373 = NOVALUE;
    object _24372 = NOVALUE;
    object _24370 = NOVALUE;
    object _24368 = NOVALUE;
    object _24367 = NOVALUE;
    object _24366 = NOVALUE;
    object _24363 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:79		hash = SymTab[sym][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24363 = (object)*(((s1_ptr)_2)->base + _sym_46893);
    _2 = (object)SEQ_PTR(_24363);
    _hash_46894 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (!IS_ATOM_INT(_hash_46894)){
        _hash_46894 = (object)DBL_PTR(_hash_46894)->dbl;
    }
    _24363 = NOVALUE;

    /** symtab.e:80		st_ptr = buckets[hash]*/
    _2 = (object)SEQ_PTR(_53buckets_46842);
    _st_ptr_46895 = (object)*(((s1_ptr)_2)->base + _hash_46894);
    if (!IS_ATOM_INT(_st_ptr_46895))
    _st_ptr_46895 = (object)DBL_PTR(_st_ptr_46895)->dbl;

    /** symtab.e:82		while st_ptr and st_ptr != sym do*/
L1: 
    if (_st_ptr_46895 == 0) {
        goto L2; // [32] 65
    }
    _24367 = (_st_ptr_46895 != _sym_46893);
    if (_24367 == 0)
    {
        DeRef(_24367);
        _24367 = NOVALUE;
        goto L2; // [41] 65
    }
    else{
        DeRef(_24367);
        _24367 = NOVALUE;
    }

    /** symtab.e:83			st_ptr = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24368 = (object)*(((s1_ptr)_2)->base + _st_ptr_46895);
    _2 = (object)SEQ_PTR(_24368);
    _st_ptr_46895 = (object)*(((s1_ptr)_2)->base + 9LL);
    if (!IS_ATOM_INT(_st_ptr_46895)){
        _st_ptr_46895 = (object)DBL_PTR(_st_ptr_46895)->dbl;
    }
    _24368 = NOVALUE;

    /** symtab.e:84		end while*/
    goto L1; // [62] 32
L2: 

    /** symtab.e:86		if st_ptr then*/
    if (_st_ptr_46895 == 0)
    {
        goto L3; // [67] 134
    }
    else{
    }

    /** symtab.e:87			if st_ptr = buckets[hash] then*/
    _2 = (object)SEQ_PTR(_53buckets_46842);
    _24370 = (object)*(((s1_ptr)_2)->base + _hash_46894);
    if (binary_op_a(NOTEQ, _st_ptr_46895, _24370)){
        _24370 = NOVALUE;
        goto L4; // [78] 105
    }
    _24370 = NOVALUE;

    /** symtab.e:89				buckets[hash] = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24372 = (object)*(((s1_ptr)_2)->base + _st_ptr_46895);
    _2 = (object)SEQ_PTR(_24372);
    _24373 = (object)*(((s1_ptr)_2)->base + 9LL);
    _24372 = NOVALUE;
    Ref(_24373);
    _2 = (object)SEQ_PTR(_53buckets_46842);
    _2 = (object)(((s1_ptr)_2)->base + _hash_46894);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24373;
    if( _1 != _24373 ){
        DeRef(_1);
    }
    _24373 = NOVALUE;
    goto L5; // [102] 133
L4: 

    /** symtab.e:92				SymTab[st_ptr][S_SAMEHASH] = SymTab[sym][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_st_ptr_46895 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24376 = (object)*(((s1_ptr)_2)->base + _sym_46893);
    _2 = (object)SEQ_PTR(_24376);
    _24377 = (object)*(((s1_ptr)_2)->base + 9LL);
    _24376 = NOVALUE;
    Ref(_24377);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24377;
    if( _1 != _24377 ){
        DeRef(_1);
    }
    _24377 = NOVALUE;
    _24374 = NOVALUE;
L5: 
L3: 

    /** symtab.e:95	end procedure*/
    return;
    ;
}


object _53NewBasicEntry(object _name_46927, object _varnum_46928, object _scope_46929, object _token_46930, object _hashval_46931, object _samehash_46933, object _type_sym_46935)
{
    object _new_46936 = NOVALUE;
    object _24386 = NOVALUE;
    object _24384 = NOVALUE;
    object _24383 = NOVALUE;
    object _24382 = NOVALUE;
    object _24381 = NOVALUE;
    object _24380 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:105		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L1; // [19] 33
    }
    else{
    }

    /** symtab.e:106			new = repeat(0, SIZEOF_ROUTINE_ENTRY)*/
    DeRef(_new_46936);
    _new_46936 = Repeat(0LL, _12SIZEOF_ROUTINE_ENTRY_19990);
    goto L2; // [30] 42
L1: 

    /** symtab.e:108			new = repeat(0, SIZEOF_VAR_ENTRY)*/
    DeRef(_new_46936);
    _new_46936 = Repeat(0LL, _12SIZEOF_VAR_ENTRY_19993);
L2: 

    /** symtab.e:111		new[S_NEXT] = 0*/
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:112		new[S_NAME] = name*/
    RefDS(_name_46927);
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_NAME_19864))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_NAME_19864);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _name_46927;
    DeRef(_1);

    /** symtab.e:113		new[S_SCOPE] = scope*/
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _scope_46929;
    DeRef(_1);

    /** symtab.e:114		new[S_MODE] = M_NORMAL*/
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);

    /** symtab.e:115		new[S_USAGE] = U_UNUSED*/
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:116		new[S_FILE_NO] = current_file_no*/
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_FILE_NO_19860))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12current_file_no_20226;
    DeRef(_1);

    /** symtab.e:118		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L3; // [102] 327
    }
    else{
    }

    /** symtab.e:120			new[S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);

    /** symtab.e:121			new[S_GTYPE_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 38LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:123			new[S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);

    /** symtab.e:124			new[S_SEQ_ELEM_NEW] = TYPE_NULL -- starting point for ORing*/
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:126			new[S_ARG_TYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 43LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);

    /** symtab.e:127			new[S_ARG_TYPE_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 44LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:128			new[S_ARG_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 45LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);

    /** symtab.e:129			new[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 46LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:131			new[S_ARG_MIN] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 47LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);

    /** symtab.e:132			new[S_ARG_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_12NOVALUE_20081)) {
        if ((uintptr_t)_12NOVALUE_20081 == (uintptr_t)HIGH_BITS){
            _24380 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24380 = - _12NOVALUE_20081;
        }
    }
    else {
        _24380 = unary_op(UMINUS, _12NOVALUE_20081);
    }
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 49LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24380;
    if( _1 != _24380 ){
        DeRef(_1);
    }
    _24380 = NOVALUE;

    /** symtab.e:134			new[S_ARG_SEQ_LEN] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 51LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);

    /** symtab.e:135			new[S_ARG_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_12NOVALUE_20081)) {
        if ((uintptr_t)_12NOVALUE_20081 == (uintptr_t)HIGH_BITS){
            _24381 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24381 = - _12NOVALUE_20081;
        }
    }
    else {
        _24381 = unary_op(UMINUS, _12NOVALUE_20081);
    }
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 52LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24381;
    if( _1 != _24381 ){
        DeRef(_1);
    }
    _24381 = NOVALUE;

    /** symtab.e:137			new[S_SEQ_LEN] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);

    /** symtab.e:138			new[S_SEQ_LEN_NEW] = -NOVALUE -- no idea yet*/
    if (IS_ATOM_INT(_12NOVALUE_20081)) {
        if ((uintptr_t)_12NOVALUE_20081 == (uintptr_t)HIGH_BITS){
            _24382 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24382 = - _12NOVALUE_20081;
        }
    }
    else {
        _24382 = unary_op(UMINUS, _12NOVALUE_20081);
    }
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24382;
    if( _1 != _24382 ){
        DeRef(_1);
    }
    _24382 = NOVALUE;

    /** symtab.e:140			new[S_NREFS] = 0*/
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:141			new[S_ONE_REF] = TRUE          -- assume TRUE until we find otherwise*/
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 35LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _9TRUE_446;
    DeRef(_1);

    /** symtab.e:142			new[S_RI_TARGET] = 0*/
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 53LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:144			new[S_OBJ_MIN] = MININT*/
    Ref(_12MININT_20051);
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12MININT_20051;
    DeRef(_1);

    /** symtab.e:145			new[S_OBJ_MIN_NEW] = -NOVALUE -- no idea yet*/
    if (IS_ATOM_INT(_12NOVALUE_20081)) {
        if ((uintptr_t)_12NOVALUE_20081 == (uintptr_t)HIGH_BITS){
            _24383 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24383 = - _12NOVALUE_20081;
        }
    }
    else {
        _24383 = unary_op(UMINUS, _12NOVALUE_20081);
    }
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24383;
    if( _1 != _24383 ){
        DeRef(_1);
    }
    _24383 = NOVALUE;

    /** symtab.e:147			new[S_OBJ_MAX] = MAXINT*/
    Ref(_12MAXINT_20050);
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12MAXINT_20050;
    DeRef(_1);

    /** symtab.e:148			new[S_OBJ_MAX_NEW] = -NOVALUE -- missing from C code? (not needed)*/
    if (IS_ATOM_INT(_12NOVALUE_20081)) {
        if ((uintptr_t)_12NOVALUE_20081 == (uintptr_t)HIGH_BITS){
            _24384 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24384 = - _12NOVALUE_20081;
        }
    }
    else {
        _24384 = unary_op(UMINUS, _12NOVALUE_20081);
    }
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 42LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24384;
    if( _1 != _24384 ){
        DeRef(_1);
    }
    _24384 = NOVALUE;
L3: 

    /** symtab.e:151		new[S_TOKEN] = token*/
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_TOKEN_19869))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _token_46930;
    DeRef(_1);

    /** symtab.e:152		new[S_VARNUM] = varnum*/
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 16LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _varnum_46928;
    DeRef(_1);

    /** symtab.e:153		new[S_INITLEVEL] = -1*/
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1LL;
    DeRef(_1);

    /** symtab.e:154		new[S_VTYPE] = type_sym*/
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _type_sym_46935;
    DeRef(_1);

    /** symtab.e:156		new[S_HASHVAL] = hashval*/
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _hashval_46931;
    DeRef(_1);

    /** symtab.e:157		new[S_SAMEHASH] = samehash*/
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _samehash_46933;
    DeRef(_1);

    /** symtab.e:159		new[S_OBJ] = NOVALUE -- important*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_new_46936);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46936 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);

    /** symtab.e:162		SymTab = append(SymTab, new)*/
    RefDS(_new_46936);
    Append(&_13SymTab_11316, _13SymTab_11316, _new_46936);

    /** symtab.e:164		return length(SymTab)*/
    if (IS_SEQUENCE(_13SymTab_11316)){
            _24386 = SEQ_PTR(_13SymTab_11316)->length;
    }
    else {
        _24386 = 1;
    }
    DeRefDS(_name_46927);
    DeRefDS(_new_46936);
    return _24386;
    ;
}


object _53NewEntry(object _name_47015, object _varnum_47016, object _scope_47017, object _token_47018, object _hashval_47019, object _samehash_47021, object _type_sym_47023)
{
    object _new_47025 = NOVALUE;
    object _24388 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_scope_47017)) {
        _1 = (object)(DBL_PTR(_scope_47017)->dbl);
        DeRefDS(_scope_47017);
        _scope_47017 = _1;
    }
    if (!IS_ATOM_INT(_token_47018)) {
        _1 = (object)(DBL_PTR(_token_47018)->dbl);
        DeRefDS(_token_47018);
        _token_47018 = _1;
    }
    if (!IS_ATOM_INT(_samehash_47021)) {
        _1 = (object)(DBL_PTR(_samehash_47021)->dbl);
        DeRefDS(_samehash_47021);
        _samehash_47021 = _1;
    }

    /** symtab.e:171		symtab_index new = NewBasicEntry( name, varnum, scope, token, hashval, samehash, type_sym )*/
    RefDS(_name_47015);
    _new_47025 = _53NewBasicEntry(_name_47015, _varnum_47016, _scope_47017, _token_47018, _hashval_47019, _samehash_47021, _type_sym_47023);
    if (!IS_ATOM_INT(_new_47025)) {
        _1 = (object)(DBL_PTR(_new_47025)->dbl);
        DeRefDS(_new_47025);
        _new_47025 = _1;
    }

    /** symtab.e:174		if last_sym then*/
    if (_53last_sym_46855 == 0)
    {
        goto L1; // [33] 54
    }
    else{
    }

    /** symtab.e:175			SymTab[last_sym][S_NEXT] = new*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_53last_sym_46855 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _new_47025;
    DeRef(_1);
    _24388 = NOVALUE;
L1: 

    /** symtab.e:177		last_sym = new*/
    _53last_sym_46855 = _new_47025;

    /** symtab.e:178		if type_sym < 0 then*/
    if (_type_sym_47023 >= 0LL)
    goto L2; // [63] 76

    /** symtab.e:179			register_forward_type( last_sym, type_sym )*/
    _42register_forward_type(_53last_sym_46855, _type_sym_47023);
L2: 

    /** symtab.e:181		return last_sym*/
    DeRefDS(_name_47015);
    return _53last_sym_46855;
    ;
}


object _53tmp_alloc()
{
    object _new_entry_47040 = NOVALUE;
    object _24402 = NOVALUE;
    object _24400 = NOVALUE;
    object _24397 = NOVALUE;
    object _24394 = NOVALUE;
    object _24393 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:188		sequence new_entry = repeat( 0, SIZEOF_TEMP_ENTRY )*/
    DeRef(_new_entry_47040);
    _new_entry_47040 = Repeat(0LL, _12SIZEOF_TEMP_ENTRY_19999);

    /** symtab.e:192		new_entry[S_USAGE] = T_UNKNOWN*/
    _2 = (object)SEQ_PTR(_new_entry_47040);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47040 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    *(intptr_t *)_2 = 4LL;

    /** symtab.e:194		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L1; // [23] 132
    }
    else{
    }

    /** symtab.e:195			new_entry[S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_entry_47040);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47040 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    *(intptr_t *)_2 = 16LL;

    /** symtab.e:196			new_entry[S_OBJ_MIN] = MININT*/
    Ref(_12MININT_20051);
    _2 = (object)SEQ_PTR(_new_entry_47040);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47040 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    *(intptr_t *)_2 = _12MININT_20051;

    /** symtab.e:197			new_entry[S_OBJ_MAX] = MAXINT*/
    Ref(_12MAXINT_20050);
    _2 = (object)SEQ_PTR(_new_entry_47040);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47040 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12MAXINT_20050;
    DeRef(_1);

    /** symtab.e:198			new_entry[S_SEQ_LEN] = NOVALUE*/
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(_new_entry_47040);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47040 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);

    /** symtab.e:199			new_entry[S_SEQ_ELEM] = TYPE_OBJECT  -- other fields set later*/
    _2 = (object)SEQ_PTR(_new_entry_47040);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47040 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);

    /** symtab.e:200			if length(temp_name_type)+1 = 8087 then*/
    if (IS_SEQUENCE(_12temp_name_type_20309)){
            _24393 = SEQ_PTR(_12temp_name_type_20309)->length;
    }
    else {
        _24393 = 1;
    }
    _24394 = _24393 + 1;
    _24393 = NOVALUE;
    if (_24394 != 8087LL)
    goto L2; // [87] 106

    /** symtab.e:202				temp_name_type = append(temp_name_type, {0, 0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = 0LL;
    _24397 = MAKE_SEQ(_1);
    RefDS(_24397);
    Append(&_12temp_name_type_20309, _12temp_name_type_20309, _24397);
    DeRefDS(_24397);
    _24397 = NOVALUE;
L2: 

    /** symtab.e:204			temp_name_type = append(temp_name_type, TYPES_OBNL)*/
    RefDS(_54TYPES_OBNL_46680);
    Append(&_12temp_name_type_20309, _12temp_name_type_20309, _54TYPES_OBNL_46680);

    /** symtab.e:205			new_entry[S_TEMP_NAME] = length(temp_name_type)*/
    if (IS_SEQUENCE(_12temp_name_type_20309)){
            _24400 = SEQ_PTR(_12temp_name_type_20309)->length;
    }
    else {
        _24400 = 1;
    }
    _2 = (object)SEQ_PTR(_new_entry_47040);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47040 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 34LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24400;
    if( _1 != _24400 ){
        DeRef(_1);
    }
    _24400 = NOVALUE;
L1: 

    /** symtab.e:208		SymTab = append(SymTab, new_entry )*/
    RefDS(_new_entry_47040);
    Append(&_13SymTab_11316, _13SymTab_11316, _new_entry_47040);

    /** symtab.e:210		return length( SymTab )*/
    if (IS_SEQUENCE(_13SymTab_11316)){
            _24402 = SEQ_PTR(_13SymTab_11316)->length;
    }
    else {
        _24402 = 1;
    }
    DeRefDS(_new_entry_47040);
    DeRef(_24394);
    _24394 = NOVALUE;
    return _24402;
    ;
}


void _53DefinedYet(object _sym_47109)
{
    object _24422 = NOVALUE;
    object _24421 = NOVALUE;
    object _24420 = NOVALUE;
    object _24418 = NOVALUE;
    object _24417 = NOVALUE;
    object _24415 = NOVALUE;
    object _24414 = NOVALUE;
    object _24413 = NOVALUE;
    object _24412 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:230		if not find(SymTab[sym][S_SCOPE],*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24412 = (object)*(((s1_ptr)_2)->base + _sym_47109);
    _2 = (object)SEQ_PTR(_24412);
    _24413 = (object)*(((s1_ptr)_2)->base + 4LL);
    _24412 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 9LL;
    ((intptr_t*)_2)[2] = 10LL;
    ((intptr_t*)_2)[3] = 7LL;
    _24414 = MAKE_SEQ(_1);
    _24415 = find_from(_24413, _24414, 1LL);
    _24413 = NOVALUE;
    DeRefDS(_24414);
    _24414 = NOVALUE;
    if (_24415 != 0)
    goto L1; // [34] 84
    _24415 = NOVALUE;

    /** symtab.e:232			if SymTab[sym][S_FILE_NO] = current_file_no then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24417 = (object)*(((s1_ptr)_2)->base + _sym_47109);
    _2 = (object)SEQ_PTR(_24417);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _24418 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _24418 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _24417 = NOVALUE;
    if (binary_op_a(NOTEQ, _24418, _12current_file_no_20226)){
        _24418 = NOVALUE;
        goto L2; // [53] 83
    }
    _24418 = NOVALUE;

    /** symtab.e:233				CompileErr(ATTEMPT_TO_REDEFINE_1, {SymTab[sym][S_NAME]})*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24420 = (object)*(((s1_ptr)_2)->base + _sym_47109);
    _2 = (object)SEQ_PTR(_24420);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _24421 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _24421 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _24420 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24421);
    ((intptr_t*)_2)[1] = _24421;
    _24422 = MAKE_SEQ(_1);
    _24421 = NOVALUE;
    _49CompileErr(31LL, _24422, 0LL);
    _24422 = NOVALUE;
L2: 
L1: 

    /** symtab.e:236	end procedure*/
    return;
    ;
}


object _53name_ext(object _s_47137)
{
    object _24429 = NOVALUE;
    object _24428 = NOVALUE;
    object _24427 = NOVALUE;
    object _24426 = NOVALUE;
    object _24424 = NOVALUE;
    object _24423 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:241		for i = length(s) to 1 by -1 do*/
    if (IS_SEQUENCE(_s_47137)){
            _24423 = SEQ_PTR(_s_47137)->length;
    }
    else {
        _24423 = 1;
    }
    {
        object _i_47139;
        _i_47139 = _24423;
L1: 
        if (_i_47139 < 1LL){
            goto L2; // [8] 55
        }

        /** symtab.e:242			if find(s[i], "/\\:") then*/
        _2 = (object)SEQ_PTR(_s_47137);
        _24424 = (object)*(((s1_ptr)_2)->base + _i_47139);
        _24426 = find_from(_24424, _24425, 1LL);
        _24424 = NOVALUE;
        if (_24426 == 0)
        {
            _24426 = NOVALUE;
            goto L3; // [26] 48
        }
        else{
            _24426 = NOVALUE;
        }

        /** symtab.e:243				return s[i+1 .. $]*/
        _24427 = _i_47139 + 1;
        if (IS_SEQUENCE(_s_47137)){
                _24428 = SEQ_PTR(_s_47137)->length;
        }
        else {
            _24428 = 1;
        }
        rhs_slice_target = (object_ptr)&_24429;
        RHS_Slice(_s_47137, _24427, _24428);
        DeRefDS(_s_47137);
        _24427 = NOVALUE;
        return _24429;
L3: 

        /** symtab.e:245		end for*/
        _i_47139 = _i_47139 + -1LL;
        goto L1; // [50] 15
L2: 
        ;
    }

    /** symtab.e:247		return s*/
    DeRef(_24429);
    _24429 = NOVALUE;
    DeRef(_24427);
    _24427 = NOVALUE;
    return _s_47137;
    ;
}


object _53NewStringSym(object _s_47158)
{
    object _p_47160 = NOVALUE;
    object _tp_47161 = NOVALUE;
    object _prev_47162 = NOVALUE;
    object _search_count_47163 = NOVALUE;
    object _24475 = NOVALUE;
    object _24473 = NOVALUE;
    object _24472 = NOVALUE;
    object _24471 = NOVALUE;
    object _24469 = NOVALUE;
    object _24468 = NOVALUE;
    object _24465 = NOVALUE;
    object _24463 = NOVALUE;
    object _24461 = NOVALUE;
    object _24460 = NOVALUE;
    object _24459 = NOVALUE;
    object _24457 = NOVALUE;
    object _24455 = NOVALUE;
    object _24453 = NOVALUE;
    object _24451 = NOVALUE;
    object _24448 = NOVALUE;
    object _24446 = NOVALUE;
    object _24445 = NOVALUE;
    object _24444 = NOVALUE;
    object _24442 = NOVALUE;
    object _24440 = NOVALUE;
    object _24439 = NOVALUE;
    object _24438 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:255		integer search_count*/

    /** symtab.e:258		tp = literal_init*/
    _tp_47161 = _53literal_init_46854;

    /** symtab.e:259		prev = 0*/
    _prev_47162 = 0LL;

    /** symtab.e:260		search_count = 0*/
    _search_count_47163 = 0LL;

    /** symtab.e:261		while tp != 0 do*/
L1: 
    if (_tp_47161 == 0LL)
    goto L2; // [31] 170

    /** symtab.e:262			search_count += 1*/
    _search_count_47163 = _search_count_47163 + 1;

    /** symtab.e:263			if search_count > SEARCH_LIMIT then  -- avoid n-squared algorithm*/
    if (binary_op_a(LESSEQ, _search_count_47163, _53SEARCH_LIMIT_47148)){
        goto L3; // [45] 54
    }

    /** symtab.e:264				exit*/
    goto L2; // [51] 170
L3: 

    /** symtab.e:266			if equal(s, SymTab[tp][S_OBJ]) then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24438 = (object)*(((s1_ptr)_2)->base + _tp_47161);
    _2 = (object)SEQ_PTR(_24438);
    _24439 = (object)*(((s1_ptr)_2)->base + 1LL);
    _24438 = NOVALUE;
    if (_s_47158 == _24439)
    _24440 = 1;
    else if (IS_ATOM_INT(_s_47158) && IS_ATOM_INT(_24439))
    _24440 = 0;
    else
    _24440 = (compare(_s_47158, _24439) == 0);
    _24439 = NOVALUE;
    if (_24440 == 0)
    {
        _24440 = NOVALUE;
        goto L4; // [72] 142
    }
    else{
        _24440 = NOVALUE;
    }

    /** symtab.e:268				if tp != literal_init then*/
    if (_tp_47161 == _53literal_init_46854)
    goto L5; // [79] 135

    /** symtab.e:269					SymTab[prev][S_NEXT] = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_47162 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24444 = (object)*(((s1_ptr)_2)->base + _tp_47161);
    _2 = (object)SEQ_PTR(_24444);
    _24445 = (object)*(((s1_ptr)_2)->base + 2LL);
    _24444 = NOVALUE;
    Ref(_24445);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24445;
    if( _1 != _24445 ){
        DeRef(_1);
    }
    _24445 = NOVALUE;
    _24442 = NOVALUE;

    /** symtab.e:270					SymTab[tp][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_tp_47161 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _53literal_init_46854;
    DeRef(_1);
    _24446 = NOVALUE;

    /** symtab.e:271					literal_init = tp*/
    _53literal_init_46854 = _tp_47161;
L5: 

    /** symtab.e:273				return tp*/
    DeRefDS(_s_47158);
    return _tp_47161;
L4: 

    /** symtab.e:275			prev = tp*/
    _prev_47162 = _tp_47161;

    /** symtab.e:276			tp = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24448 = (object)*(((s1_ptr)_2)->base + _tp_47161);
    _2 = (object)SEQ_PTR(_24448);
    _tp_47161 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_tp_47161)){
        _tp_47161 = (object)DBL_PTR(_tp_47161)->dbl;
    }
    _24448 = NOVALUE;

    /** symtab.e:277		end while*/
    goto L1; // [167] 31
L2: 

    /** symtab.e:279		p = tmp_alloc()*/
    _p_47160 = _53tmp_alloc();
    if (!IS_ATOM_INT(_p_47160)) {
        _1 = (object)(DBL_PTR(_p_47160)->dbl);
        DeRefDS(_p_47160);
        _p_47160 = _1;
    }

    /** symtab.e:280		SymTab[p][S_OBJ] = s*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47160 + ((s1_ptr)_2)->base);
    RefDS(_s_47158);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_47158;
    DeRef(_1);
    _24451 = NOVALUE;

    /** symtab.e:282		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L6; // [196] 346
    }
    else{
    }

    /** symtab.e:283			SymTab[p][S_MODE] = M_TEMP    -- override CONSTANT for compile*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47160 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3LL;
    DeRef(_1);
    _24453 = NOVALUE;

    /** symtab.e:284			SymTab[p][S_GTYPE] = TYPE_SEQUENCE*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47160 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 8LL;
    DeRef(_1);
    _24455 = NOVALUE;

    /** symtab.e:285			SymTab[p][S_SEQ_LEN] = length(s)*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47160 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_s_47158)){
            _24459 = SEQ_PTR(_s_47158)->length;
    }
    else {
        _24459 = 1;
    }
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24459;
    if( _1 != _24459 ){
        DeRef(_1);
    }
    _24459 = NOVALUE;
    _24457 = NOVALUE;

    /** symtab.e:286			if SymTab[p][S_SEQ_LEN] > 0 then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24460 = (object)*(((s1_ptr)_2)->base + _p_47160);
    _2 = (object)SEQ_PTR(_24460);
    _24461 = (object)*(((s1_ptr)_2)->base + 32LL);
    _24460 = NOVALUE;
    if (binary_op_a(LESSEQ, _24461, 0LL)){
        _24461 = NOVALUE;
        goto L7; // [265] 289
    }
    _24461 = NOVALUE;

    /** symtab.e:287				SymTab[p][S_SEQ_ELEM] = TYPE_INTEGER*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47160 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _24463 = NOVALUE;
    goto L8; // [286] 307
L7: 

    /** symtab.e:289				SymTab[p][S_SEQ_ELEM] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47160 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _24465 = NOVALUE;
L8: 

    /** symtab.e:291			c_printf("object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24468 = (object)*(((s1_ptr)_2)->base + _p_47160);
    _2 = (object)SEQ_PTR(_24468);
    _24469 = (object)*(((s1_ptr)_2)->base + 34LL);
    _24468 = NOVALUE;
    RefDS(_24467);
    Ref(_24469);
    _54c_printf(_24467, _24469);
    _24469 = NOVALUE;

    /** symtab.e:292			c_hprintf("extern object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24471 = (object)*(((s1_ptr)_2)->base + _p_47160);
    _2 = (object)SEQ_PTR(_24471);
    _24472 = (object)*(((s1_ptr)_2)->base + 34LL);
    _24471 = NOVALUE;
    RefDS(_24470);
    Ref(_24472);
    _54c_hprintf(_24470, _24472);
    _24472 = NOVALUE;
    goto L9; // [343] 364
L6: 

    /** symtab.e:295			SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47160 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _24473 = NOVALUE;
L9: 

    /** symtab.e:299		SymTab[p][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47160 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _53literal_init_46854;
    DeRef(_1);
    _24475 = NOVALUE;

    /** symtab.e:300		literal_init = p*/
    _53literal_init_46854 = _p_47160;

    /** symtab.e:301		return p*/
    DeRefDS(_s_47158);
    return _p_47160;
    ;
}


object _53NewIntSym(object _int_val_47256)
{
    object _p_47258 = NOVALUE;
    object _x_47259 = NOVALUE;
    object _24499 = NOVALUE;
    object _24497 = NOVALUE;
    object _24493 = NOVALUE;
    object _24491 = NOVALUE;
    object _24489 = NOVALUE;
    object _24487 = NOVALUE;
    object _24485 = NOVALUE;
    object _24483 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:308		integer x*/

    /** symtab.e:310		x = find(int_val, lastintval)*/
    _x_47259 = find_from(_int_val_47256, _53lastintval_46856, 1LL);

    /** symtab.e:311		if x then*/
    if (_x_47259 == 0)
    {
        goto L1; // [14] 75
    }
    else{
    }

    /** symtab.e:312			if repl then*/

    /** symtab.e:317			return lastintsym[x]  -- saves space, helps Translator reduce code size*/
    _2 = (object)SEQ_PTR(_53lastintsym_46857);
    _24483 = (object)*(((s1_ptr)_2)->base + _x_47259);
    DeRef(_int_val_47256);
    return _24483;
    goto L2; // [72] 225
L1: 

    /** symtab.e:320			label "lolol"*/
G3:

    /** symtab.e:321			p = tmp_alloc()*/
    _p_47258 = _53tmp_alloc();
    if (!IS_ATOM_INT(_p_47258)) {
        _1 = (object)(DBL_PTR(_p_47258)->dbl);
        DeRefDS(_p_47258);
        _p_47258 = _1;
    }

    /** symtab.e:322			SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47258 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _24485 = NOVALUE;

    /** symtab.e:323			SymTab[p][S_OBJ] = int_val*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47258 + ((s1_ptr)_2)->base);
    Ref(_int_val_47256);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_val_47256;
    DeRef(_1);
    _24487 = NOVALUE;

    /** symtab.e:325			if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L4; // [122] 173
    }
    else{
    }

    /** symtab.e:326				SymTab[p][S_OBJ_MIN] = int_val*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47258 + ((s1_ptr)_2)->base);
    Ref(_int_val_47256);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_val_47256;
    DeRef(_1);
    _24489 = NOVALUE;

    /** symtab.e:327				SymTab[p][S_OBJ_MAX] = int_val*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47258 + ((s1_ptr)_2)->base);
    Ref(_int_val_47256);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_val_47256;
    DeRef(_1);
    _24491 = NOVALUE;

    /** symtab.e:328				SymTab[p][S_GTYPE] = TYPE_INTEGER*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47258 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _24493 = NOVALUE;
L4: 

    /** symtab.e:331			lastintval = prepend(lastintval, int_val)*/
    Ref(_int_val_47256);
    Prepend(&_53lastintval_46856, _53lastintval_46856, _int_val_47256);

    /** symtab.e:332			lastintsym = prepend(lastintsym, p)*/
    Prepend(&_53lastintsym_46857, _53lastintsym_46857, _p_47258);

    /** symtab.e:333			if length(lastintval) > SEARCH_LIMIT then*/
    if (IS_SEQUENCE(_53lastintval_46856)){
            _24497 = SEQ_PTR(_53lastintval_46856)->length;
    }
    else {
        _24497 = 1;
    }
    if (binary_op_a(LESSEQ, _24497, _53SEARCH_LIMIT_47148)){
        _24497 = NOVALUE;
        goto L5; // [198] 218
    }
    _24497 = NOVALUE;

    /** symtab.e:334				lastintval = lastintval[1..floor(SEARCH_LIMIT/2)]*/
    if (IS_ATOM_INT(_53SEARCH_LIMIT_47148)) {
        _24499 = _53SEARCH_LIMIT_47148 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _53SEARCH_LIMIT_47148, 2);
        _24499 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    rhs_slice_target = (object_ptr)&_53lastintval_46856;
    RHS_Slice(_53lastintval_46856, 1LL, _24499);
L5: 

    /** symtab.e:336			return p*/
    DeRef(_int_val_47256);
    _24483 = NOVALUE;
    DeRef(_24499);
    _24499 = NOVALUE;
    return _p_47258;
L2: 
    ;
}


object _53NewDoubleSym(object _d_47308)
{
    object _p_47310 = NOVALUE;
    object _tp_47311 = NOVALUE;
    object _prev_47312 = NOVALUE;
    object _search_count_47313 = NOVALUE;
    object _24529 = NOVALUE;
    object _24528 = NOVALUE;
    object _24527 = NOVALUE;
    object _24526 = NOVALUE;
    object _24525 = NOVALUE;
    object _24523 = NOVALUE;
    object _24521 = NOVALUE;
    object _24519 = NOVALUE;
    object _24517 = NOVALUE;
    object _24514 = NOVALUE;
    object _24512 = NOVALUE;
    object _24511 = NOVALUE;
    object _24510 = NOVALUE;
    object _24508 = NOVALUE;
    object _24506 = NOVALUE;
    object _24505 = NOVALUE;
    object _24504 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:343		integer search_count*/

    /** symtab.e:346		tp = literal_init*/
    _tp_47311 = _53literal_init_46854;

    /** symtab.e:347		prev = 0*/
    _prev_47312 = 0LL;

    /** symtab.e:348		search_count = 0*/
    _search_count_47313 = 0LL;

    /** symtab.e:349		while tp != 0 do*/
L1: 
    if (_tp_47311 == 0LL)
    goto L2; // [29] 168

    /** symtab.e:350			search_count += 1*/
    _search_count_47313 = _search_count_47313 + 1;

    /** symtab.e:351			if search_count > SEARCH_LIMIT then  -- avoid n-squared algorithm*/
    if (binary_op_a(LESSEQ, _search_count_47313, _53SEARCH_LIMIT_47148)){
        goto L3; // [43] 52
    }

    /** symtab.e:352				exit*/
    goto L2; // [49] 168
L3: 

    /** symtab.e:354			if equal(d, SymTab[tp][S_OBJ]) then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24504 = (object)*(((s1_ptr)_2)->base + _tp_47311);
    _2 = (object)SEQ_PTR(_24504);
    _24505 = (object)*(((s1_ptr)_2)->base + 1LL);
    _24504 = NOVALUE;
    if (_d_47308 == _24505)
    _24506 = 1;
    else if (IS_ATOM_INT(_d_47308) && IS_ATOM_INT(_24505))
    _24506 = 0;
    else
    _24506 = (compare(_d_47308, _24505) == 0);
    _24505 = NOVALUE;
    if (_24506 == 0)
    {
        _24506 = NOVALUE;
        goto L4; // [70] 140
    }
    else{
        _24506 = NOVALUE;
    }

    /** symtab.e:356				if tp != literal_init then*/
    if (_tp_47311 == _53literal_init_46854)
    goto L5; // [77] 133

    /** symtab.e:358					SymTab[prev][S_NEXT] = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_47312 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24510 = (object)*(((s1_ptr)_2)->base + _tp_47311);
    _2 = (object)SEQ_PTR(_24510);
    _24511 = (object)*(((s1_ptr)_2)->base + 2LL);
    _24510 = NOVALUE;
    Ref(_24511);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24511;
    if( _1 != _24511 ){
        DeRef(_1);
    }
    _24511 = NOVALUE;
    _24508 = NOVALUE;

    /** symtab.e:359					SymTab[tp][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_tp_47311 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _53literal_init_46854;
    DeRef(_1);
    _24512 = NOVALUE;

    /** symtab.e:360					literal_init = tp*/
    _53literal_init_46854 = _tp_47311;
L5: 

    /** symtab.e:362				return tp*/
    DeRef(_d_47308);
    return _tp_47311;
L4: 

    /** symtab.e:364			prev = tp*/
    _prev_47312 = _tp_47311;

    /** symtab.e:365			tp = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24514 = (object)*(((s1_ptr)_2)->base + _tp_47311);
    _2 = (object)SEQ_PTR(_24514);
    _tp_47311 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_tp_47311)){
        _tp_47311 = (object)DBL_PTR(_tp_47311)->dbl;
    }
    _24514 = NOVALUE;

    /** symtab.e:366		end while*/
    goto L1; // [165] 29
L2: 

    /** symtab.e:368		p = tmp_alloc()*/
    _p_47310 = _53tmp_alloc();
    if (!IS_ATOM_INT(_p_47310)) {
        _1 = (object)(DBL_PTR(_p_47310)->dbl);
        DeRefDS(_p_47310);
        _p_47310 = _1;
    }

    /** symtab.e:369		SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47310 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _24517 = NOVALUE;

    /** symtab.e:370		SymTab[p][S_OBJ] = d*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47310 + ((s1_ptr)_2)->base);
    Ref(_d_47308);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _d_47308;
    DeRef(_1);
    _24519 = NOVALUE;

    /** symtab.e:372		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L6; // [211] 285
    }
    else{
    }

    /** symtab.e:373			SymTab[p][S_MODE] = M_TEMP  -- override CONSTANT for compile*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47310 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3LL;
    DeRef(_1);
    _24521 = NOVALUE;

    /** symtab.e:374			SymTab[p][S_GTYPE] = TYPE_DOUBLE*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47310 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _24523 = NOVALUE;

    /** symtab.e:375			c_printf("object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24525 = (object)*(((s1_ptr)_2)->base + _p_47310);
    _2 = (object)SEQ_PTR(_24525);
    _24526 = (object)*(((s1_ptr)_2)->base + 34LL);
    _24525 = NOVALUE;
    RefDS(_24467);
    Ref(_24526);
    _54c_printf(_24467, _24526);
    _24526 = NOVALUE;

    /** symtab.e:376			c_hprintf("extern object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24527 = (object)*(((s1_ptr)_2)->base + _p_47310);
    _2 = (object)SEQ_PTR(_24527);
    _24528 = (object)*(((s1_ptr)_2)->base + 34LL);
    _24527 = NOVALUE;
    RefDS(_24470);
    Ref(_24528);
    _54c_hprintf(_24470, _24528);
    _24528 = NOVALUE;
L6: 

    /** symtab.e:379		SymTab[p][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47310 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _53literal_init_46854;
    DeRef(_1);
    _24529 = NOVALUE;

    /** symtab.e:380		literal_init = p*/
    _53literal_init_46854 = _p_47310;

    /** symtab.e:381		return p*/
    DeRef(_d_47308);
    return _p_47310;
    ;
}


object _53NewTempSym(object _inlining_47382)
{
    object _p_47384 = NOVALUE;
    object _q_47385 = NOVALUE;
    object _24578 = NOVALUE;
    object _24576 = NOVALUE;
    object _24574 = NOVALUE;
    object _24572 = NOVALUE;
    object _24570 = NOVALUE;
    object _24568 = NOVALUE;
    object _24567 = NOVALUE;
    object _24566 = NOVALUE;
    object _24564 = NOVALUE;
    object _24563 = NOVALUE;
    object _24562 = NOVALUE;
    object _24560 = NOVALUE;
    object _24558 = NOVALUE;
    object _24555 = NOVALUE;
    object _24554 = NOVALUE;
    object _24553 = NOVALUE;
    object _24551 = NOVALUE;
    object _24549 = NOVALUE;
    object _24548 = NOVALUE;
    object _24547 = NOVALUE;
    object _24545 = NOVALUE;
    object _24543 = NOVALUE;
    object _24538 = NOVALUE;
    object _24537 = NOVALUE;
    object _24536 = NOVALUE;
    object _24535 = NOVALUE;
    object _24534 = NOVALUE;
    object _24533 = NOVALUE;
    object _24531 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:392		if inlining then*/
    if (_inlining_47382 == 0)
    {
        goto L1; // [5] 85
    }
    else{
    }

    /** symtab.e:393			p = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24531 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_24531);
    if (!IS_ATOM_INT(_12S_TEMPS_19909)){
        _p_47384 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TEMPS_19909)->dbl));
    }
    else{
        _p_47384 = (object)*(((s1_ptr)_2)->base + _12S_TEMPS_19909);
    }
    if (!IS_ATOM_INT(_p_47384)){
        _p_47384 = (object)DBL_PTR(_p_47384)->dbl;
    }
    _24531 = NOVALUE;

    /** symtab.e:394			while p != 0 and SymTab[p][S_SCOPE] != FREE do*/
L2: 
    _24533 = (_p_47384 != 0LL);
    if (_24533 == 0) {
        goto L3; // [35] 93
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24535 = (object)*(((s1_ptr)_2)->base + _p_47384);
    _2 = (object)SEQ_PTR(_24535);
    _24536 = (object)*(((s1_ptr)_2)->base + 4LL);
    _24535 = NOVALUE;
    if (IS_ATOM_INT(_24536)) {
        _24537 = (_24536 != 0LL);
    }
    else {
        _24537 = binary_op(NOTEQ, _24536, 0LL);
    }
    _24536 = NOVALUE;
    if (_24537 <= 0) {
        if (_24537 == 0) {
            DeRef(_24537);
            _24537 = NOVALUE;
            goto L3; // [58] 93
        }
        else {
            if (!IS_ATOM_INT(_24537) && DBL_PTR(_24537)->dbl == 0.0){
                DeRef(_24537);
                _24537 = NOVALUE;
                goto L3; // [58] 93
            }
            DeRef(_24537);
            _24537 = NOVALUE;
        }
    }
    DeRef(_24537);
    _24537 = NOVALUE;

    /** symtab.e:395				p = SymTab[p][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24538 = (object)*(((s1_ptr)_2)->base + _p_47384);
    _2 = (object)SEQ_PTR(_24538);
    _p_47384 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_p_47384)){
        _p_47384 = (object)DBL_PTR(_p_47384)->dbl;
    }
    _24538 = NOVALUE;

    /** symtab.e:396			end while*/
    goto L2; // [79] 31
    goto L3; // [82] 93
L1: 

    /** symtab.e:398			p = 0*/
    _p_47384 = 0LL;
L3: 

    /** symtab.e:401		if p = 0 then*/
    if (_p_47384 != 0LL)
    goto L4; // [97] 213

    /** symtab.e:403			temps_allocated += 1*/
    _53temps_allocated_47379 = _53temps_allocated_47379 + 1;

    /** symtab.e:404			p = tmp_alloc()*/
    _p_47384 = _53tmp_alloc();
    if (!IS_ATOM_INT(_p_47384)) {
        _1 = (object)(DBL_PTR(_p_47384)->dbl);
        DeRefDS(_p_47384);
        _p_47384 = _1;
    }

    /** symtab.e:405			SymTab[p][S_MODE] = M_TEMP*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47384 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3LL;
    DeRef(_1);
    _24543 = NOVALUE;

    /** symtab.e:406			SymTab[p][S_NEXT] = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47384 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24547 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_24547);
    if (!IS_ATOM_INT(_12S_TEMPS_19909)){
        _24548 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TEMPS_19909)->dbl));
    }
    else{
        _24548 = (object)*(((s1_ptr)_2)->base + _12S_TEMPS_19909);
    }
    _24547 = NOVALUE;
    Ref(_24548);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24548;
    if( _1 != _24548 ){
        DeRef(_1);
    }
    _24548 = NOVALUE;
    _24545 = NOVALUE;

    /** symtab.e:407			SymTab[CurrentSub][S_TEMPS] = p*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12CurrentSub_20234 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_TEMPS_19909))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TEMPS_19909)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_TEMPS_19909);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _p_47384;
    DeRef(_1);
    _24549 = NOVALUE;

    /** symtab.e:409			if inlining then*/
    if (_inlining_47382 == 0)
    {
        goto L5; // [181] 343
    }
    else{
    }

    /** symtab.e:410				SymTab[CurrentSub][S_STACK_SPACE] += 1*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12CurrentSub_20234 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_12S_STACK_SPACE_19924)){
        _24553 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_STACK_SPACE_19924)->dbl));
    }
    else{
        _24553 = (object)*(((s1_ptr)_2)->base + _12S_STACK_SPACE_19924);
    }
    _24551 = NOVALUE;
    if (IS_ATOM_INT(_24553)) {
        _24554 = _24553 + 1;
        if (_24554 > MAXINT){
            _24554 = NewDouble((eudouble)_24554);
        }
    }
    else
    _24554 = binary_op(PLUS, 1, _24553);
    _24553 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_STACK_SPACE_19924))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_STACK_SPACE_19924)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_STACK_SPACE_19924);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24554;
    if( _1 != _24554 ){
        DeRef(_1);
    }
    _24554 = NOVALUE;
    _24551 = NOVALUE;
    goto L5; // [210] 343
L4: 

    /** symtab.e:413		elsif TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L6; // [217] 342
    }
    else{
    }

    /** symtab.e:418			SymTab[p][S_SCOPE] = DELETED*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47384 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _24555 = NOVALUE;

    /** symtab.e:420			q = tmp_alloc()*/
    _q_47385 = _53tmp_alloc();
    if (!IS_ATOM_INT(_q_47385)) {
        _1 = (object)(DBL_PTR(_q_47385)->dbl);
        DeRefDS(_q_47385);
        _q_47385 = _1;
    }

    /** symtab.e:421			SymTab[q][S_MODE] = M_TEMP*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_q_47385 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3LL;
    DeRef(_1);
    _24558 = NOVALUE;

    /** symtab.e:422			SymTab[q][S_TEMP_NAME] = SymTab[p][S_TEMP_NAME]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_q_47385 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24562 = (object)*(((s1_ptr)_2)->base + _p_47384);
    _2 = (object)SEQ_PTR(_24562);
    _24563 = (object)*(((s1_ptr)_2)->base + 34LL);
    _24562 = NOVALUE;
    Ref(_24563);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 34LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24563;
    if( _1 != _24563 ){
        DeRef(_1);
    }
    _24563 = NOVALUE;
    _24560 = NOVALUE;

    /** symtab.e:423			SymTab[q][S_NEXT] = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_q_47385 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24566 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_24566);
    if (!IS_ATOM_INT(_12S_TEMPS_19909)){
        _24567 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TEMPS_19909)->dbl));
    }
    else{
        _24567 = (object)*(((s1_ptr)_2)->base + _12S_TEMPS_19909);
    }
    _24566 = NOVALUE;
    Ref(_24567);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24567;
    if( _1 != _24567 ){
        DeRef(_1);
    }
    _24567 = NOVALUE;
    _24564 = NOVALUE;

    /** symtab.e:424			SymTab[CurrentSub][S_TEMPS] = q*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12CurrentSub_20234 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_TEMPS_19909))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TEMPS_19909)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_TEMPS_19909);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _q_47385;
    DeRef(_1);
    _24568 = NOVALUE;

    /** symtab.e:425			p = q*/
    _p_47384 = _q_47385;
L6: 
L5: 

    /** symtab.e:428		if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L7; // [347] 385
    }
    else{
    }

    /** symtab.e:429			SymTab[p][S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47384 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);
    _24570 = NOVALUE;

    /** symtab.e:430			SymTab[p][S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47384 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);
    _24572 = NOVALUE;
L7: 

    /** symtab.e:433		SymTab[p][S_OBJ] = NOVALUE*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47384 + ((s1_ptr)_2)->base);
    Ref(_12NOVALUE_20081);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12NOVALUE_20081;
    DeRef(_1);
    _24574 = NOVALUE;

    /** symtab.e:434		SymTab[p][S_USAGE] = T_UNKNOWN*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47384 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 4LL;
    DeRef(_1);
    _24576 = NOVALUE;

    /** symtab.e:435		SymTab[p][S_SCOPE] = IN_USE*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47384 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _24578 = NOVALUE;

    /** symtab.e:437		return p*/
    DeRef(_24533);
    _24533 = NOVALUE;
    return _p_47384;
    ;
}


void _53InitSymTab()
{
    object _hashval_47501 = NOVALUE;
    object _len_47502 = NOVALUE;
    object _s_47504 = NOVALUE;
    object _st_index_47505 = NOVALUE;
    object _kname_47506 = NOVALUE;
    object _fixups_47507 = NOVALUE;
    object _si_47646 = NOVALUE;
    object _sj_47647 = NOVALUE;
    object _25167 = NOVALUE;
    object _25166 = NOVALUE;
    object _24693 = NOVALUE;
    object _24692 = NOVALUE;
    object _24691 = NOVALUE;
    object _24690 = NOVALUE;
    object _24689 = NOVALUE;
    object _24687 = NOVALUE;
    object _24686 = NOVALUE;
    object _24685 = NOVALUE;
    object _24684 = NOVALUE;
    object _24682 = NOVALUE;
    object _24680 = NOVALUE;
    object _24678 = NOVALUE;
    object _24677 = NOVALUE;
    object _24675 = NOVALUE;
    object _24673 = NOVALUE;
    object _24671 = NOVALUE;
    object _24670 = NOVALUE;
    object _24668 = NOVALUE;
    object _24667 = NOVALUE;
    object _24666 = NOVALUE;
    object _24665 = NOVALUE;
    object _24664 = NOVALUE;
    object _24661 = NOVALUE;
    object _24660 = NOVALUE;
    object _24659 = NOVALUE;
    object _24657 = NOVALUE;
    object _24656 = NOVALUE;
    object _24655 = NOVALUE;
    object _24653 = NOVALUE;
    object _24652 = NOVALUE;
    object _24651 = NOVALUE;
    object _24648 = NOVALUE;
    object _24646 = NOVALUE;
    object _24644 = NOVALUE;
    object _24643 = NOVALUE;
    object _24640 = NOVALUE;
    object _24639 = NOVALUE;
    object _24637 = NOVALUE;
    object _24635 = NOVALUE;
    object _24633 = NOVALUE;
    object _24631 = NOVALUE;
    object _24630 = NOVALUE;
    object _24629 = NOVALUE;
    object _24626 = NOVALUE;
    object _24625 = NOVALUE;
    object _24623 = NOVALUE;
    object _24622 = NOVALUE;
    object _24620 = NOVALUE;
    object _24619 = NOVALUE;
    object _24618 = NOVALUE;
    object _24616 = NOVALUE;
    object _24614 = NOVALUE;
    object _24613 = NOVALUE;
    object _24611 = NOVALUE;
    object _24610 = NOVALUE;
    object _24609 = NOVALUE;
    object _24607 = NOVALUE;
    object _24606 = NOVALUE;
    object _24605 = NOVALUE;
    object _24603 = NOVALUE;
    object _24602 = NOVALUE;
    object _24601 = NOVALUE;
    object _24599 = NOVALUE;
    object _24598 = NOVALUE;
    object _24597 = NOVALUE;
    object _24596 = NOVALUE;
    object _24595 = NOVALUE;
    object _24594 = NOVALUE;
    object _24593 = NOVALUE;
    object _24592 = NOVALUE;
    object _24591 = NOVALUE;
    object _24590 = NOVALUE;
    object _24588 = NOVALUE;
    object _24587 = NOVALUE;
    object _24586 = NOVALUE;
    object _24585 = NOVALUE;
    object _24581 = NOVALUE;
    object _24580 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:445		sequence kname, fixups = {}*/
    RefDS(_22024);
    DeRefi(_fixups_47507);
    _fixups_47507 = _22024;

    /** symtab.e:447		for k = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_62keylist_23148)){
            _24580 = SEQ_PTR(_62keylist_23148)->length;
    }
    else {
        _24580 = 1;
    }
    {
        object _k_47509;
        _k_47509 = 1LL;
L1: 
        if (_k_47509 > _24580){
            goto L2; // [15] 560
        }

        /** symtab.e:448			kname = keylist[k][K_NAME]*/
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _24581 = (object)*(((s1_ptr)_2)->base + _k_47509);
        DeRef(_kname_47506);
        _2 = (object)SEQ_PTR(_24581);
        _kname_47506 = (object)*(((s1_ptr)_2)->base + 1LL);
        Ref(_kname_47506);
        _24581 = NOVALUE;

        /** symtab.e:449			len = length(kname)*/
        if (IS_SEQUENCE(_kname_47506)){
                _len_47502 = SEQ_PTR(_kname_47506)->length;
        }
        else {
            _len_47502 = 1;
        }

        /** symtab.e:450			hashval = hashfn(kname)*/
        RefDS(_kname_47506);
        _hashval_47501 = _53hashfn(_kname_47506);
        if (!IS_ATOM_INT(_hashval_47501)) {
            _1 = (object)(DBL_PTR(_hashval_47501)->dbl);
            DeRefDS(_hashval_47501);
            _hashval_47501 = _1;
        }

        /** symtab.e:451			st_index = NewEntry(kname,*/
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _24585 = (object)*(((s1_ptr)_2)->base + _k_47509);
        _2 = (object)SEQ_PTR(_24585);
        _24586 = (object)*(((s1_ptr)_2)->base + 2LL);
        _24585 = NOVALUE;
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _24587 = (object)*(((s1_ptr)_2)->base + _k_47509);
        _2 = (object)SEQ_PTR(_24587);
        _24588 = (object)*(((s1_ptr)_2)->base + 3LL);
        _24587 = NOVALUE;
        RefDS(_kname_47506);
        Ref(_24586);
        Ref(_24588);
        _st_index_47505 = _53NewEntry(_kname_47506, 0LL, _24586, _24588, _hashval_47501, 0LL, 0LL);
        _24586 = NOVALUE;
        _24588 = NOVALUE;
        if (!IS_ATOM_INT(_st_index_47505)) {
            _1 = (object)(DBL_PTR(_st_index_47505)->dbl);
            DeRefDS(_st_index_47505);
            _st_index_47505 = _1;
        }

        /** symtab.e:456			if find(keylist[k][K_TOKEN], RTN_TOKS) then*/
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _24590 = (object)*(((s1_ptr)_2)->base + _k_47509);
        _2 = (object)SEQ_PTR(_24590);
        _24591 = (object)*(((s1_ptr)_2)->base + 3LL);
        _24590 = NOVALUE;
        _24592 = find_from(_24591, _29RTN_TOKS_12006, 1LL);
        _24591 = NOVALUE;
        if (_24592 == 0)
        {
            _24592 = NOVALUE;
            goto L3; // [110] 325
        }
        else{
            _24592 = NOVALUE;
        }

        /** symtab.e:457				SymTab[st_index] = SymTab[st_index] &*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _24593 = (object)*(((s1_ptr)_2)->base + _st_index_47505);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _24594 = (object)*(((s1_ptr)_2)->base + _st_index_47505);
        if (IS_SEQUENCE(_24594)){
                _24595 = SEQ_PTR(_24594)->length;
        }
        else {
            _24595 = 1;
        }
        _24594 = NOVALUE;
        _24596 = _12SIZEOF_ROUTINE_ENTRY_19990 - _24595;
        _24595 = NOVALUE;
        _24597 = Repeat(0LL, _24596);
        _24596 = NOVALUE;
        if (IS_SEQUENCE(_24593) && IS_ATOM(_24597)) {
        }
        else if (IS_ATOM(_24593) && IS_SEQUENCE(_24597)) {
            Ref(_24593);
            Prepend(&_24598, _24597, _24593);
        }
        else {
            Concat((object_ptr)&_24598, _24593, _24597);
            _24593 = NOVALUE;
        }
        _24593 = NOVALUE;
        DeRefDS(_24597);
        _24597 = NOVALUE;
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _st_index_47505);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24598;
        if( _1 != _24598 ){
            DeRef(_1);
        }
        _24598 = NOVALUE;

        /** symtab.e:460				SymTab[st_index][S_NUM_ARGS] = keylist[k][K_NUM_ARGS]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47505 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _24601 = (object)*(((s1_ptr)_2)->base + _k_47509);
        _2 = (object)SEQ_PTR(_24601);
        _24602 = (object)*(((s1_ptr)_2)->base + 5LL);
        _24601 = NOVALUE;
        Ref(_24602);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_12S_NUM_ARGS_19915))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24602;
        if( _1 != _24602 ){
            DeRef(_1);
        }
        _24602 = NOVALUE;
        _24599 = NOVALUE;

        /** symtab.e:461				SymTab[st_index][S_OPCODE] = keylist[k][K_OPCODE]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47505 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _24605 = (object)*(((s1_ptr)_2)->base + _k_47509);
        _2 = (object)SEQ_PTR(_24605);
        _24606 = (object)*(((s1_ptr)_2)->base + 4LL);
        _24605 = NOVALUE;
        Ref(_24606);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 21LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24606;
        if( _1 != _24606 ){
            DeRef(_1);
        }
        _24606 = NOVALUE;
        _24603 = NOVALUE;

        /** symtab.e:462				SymTab[st_index][S_EFFECT] = keylist[k][K_EFFECT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47505 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _24609 = (object)*(((s1_ptr)_2)->base + _k_47509);
        _2 = (object)SEQ_PTR(_24609);
        _24610 = (object)*(((s1_ptr)_2)->base + 6LL);
        _24609 = NOVALUE;
        Ref(_24610);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 23LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24610;
        if( _1 != _24610 ){
            DeRef(_1);
        }
        _24610 = NOVALUE;
        _24607 = NOVALUE;

        /** symtab.e:463				SymTab[st_index][S_REFLIST] = {}*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47505 + ((s1_ptr)_2)->base);
        RefDS(_22024);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 24LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _22024;
        DeRef(_1);
        _24611 = NOVALUE;

        /** symtab.e:464				if length(keylist[k]) > K_EFFECT then*/
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _24613 = (object)*(((s1_ptr)_2)->base + _k_47509);
        if (IS_SEQUENCE(_24613)){
                _24614 = SEQ_PTR(_24613)->length;
        }
        else {
            _24614 = 1;
        }
        _24613 = NOVALUE;
        if (_24614 <= 6LL)
        goto L4; // [259] 324

        /** symtab.e:465				    SymTab[st_index][S_CODE] = keylist[k][K_CODE]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47505 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _24618 = (object)*(((s1_ptr)_2)->base + _k_47509);
        _2 = (object)SEQ_PTR(_24618);
        _24619 = (object)*(((s1_ptr)_2)->base + 7LL);
        _24618 = NOVALUE;
        Ref(_24619);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_12S_CODE_19876))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24619;
        if( _1 != _24619 ){
            DeRef(_1);
        }
        _24619 = NOVALUE;
        _24616 = NOVALUE;

        /** symtab.e:466				    SymTab[st_index][S_DEF_ARGS] = keylist[k][K_DEF_ARGS]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47505 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _24622 = (object)*(((s1_ptr)_2)->base + _k_47509);
        _2 = (object)SEQ_PTR(_24622);
        _24623 = (object)*(((s1_ptr)_2)->base + 8LL);
        _24622 = NOVALUE;
        Ref(_24623);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 28LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24623;
        if( _1 != _24623 ){
            DeRef(_1);
        }
        _24623 = NOVALUE;
        _24620 = NOVALUE;

        /** symtab.e:467				    fixups &= st_index*/
        Append(&_fixups_47507, _fixups_47507, _st_index_47505);
L4: 
L3: 

        /** symtab.e:470			if keylist[k][K_TOKEN] = PROC then*/
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _24625 = (object)*(((s1_ptr)_2)->base + _k_47509);
        _2 = (object)SEQ_PTR(_24625);
        _24626 = (object)*(((s1_ptr)_2)->base + 3LL);
        _24625 = NOVALUE;
        if (binary_op_a(NOTEQ, _24626, 27LL)){
            _24626 = NOVALUE;
            goto L5; // [341] 365
        }
        _24626 = NOVALUE;

        /** symtab.e:471				if equal(kname, "<TopLevel>") then*/
        if (_kname_47506 == _24628)
        _24629 = 1;
        else if (IS_ATOM_INT(_kname_47506) && IS_ATOM_INT(_24628))
        _24629 = 0;
        else
        _24629 = (compare(_kname_47506, _24628) == 0);
        if (_24629 == 0)
        {
            _24629 = NOVALUE;
            goto L6; // [351] 462
        }
        else{
            _24629 = NOVALUE;
        }

        /** symtab.e:472					TopLevelSub = st_index*/
        _12TopLevelSub_20233 = _st_index_47505;
        goto L6; // [362] 462
L5: 

        /** symtab.e:474			elsif keylist[k][K_TOKEN] = TYPE then*/
        _2 = (object)SEQ_PTR(_62keylist_23148);
        _24630 = (object)*(((s1_ptr)_2)->base + _k_47509);
        _2 = (object)SEQ_PTR(_24630);
        _24631 = (object)*(((s1_ptr)_2)->base + 3LL);
        _24630 = NOVALUE;
        if (binary_op_a(NOTEQ, _24631, 504LL)){
            _24631 = NOVALUE;
            goto L7; // [381] 461
        }
        _24631 = NOVALUE;

        /** symtab.e:475				if equal(kname, "object") then*/
        if (_kname_47506 == _23004)
        _24633 = 1;
        else if (IS_ATOM_INT(_kname_47506) && IS_ATOM_INT(_23004))
        _24633 = 0;
        else
        _24633 = (compare(_kname_47506, _23004) == 0);
        if (_24633 == 0)
        {
            _24633 = NOVALUE;
            goto L8; // [391] 404
        }
        else{
            _24633 = NOVALUE;
        }

        /** symtab.e:476					object_type = st_index*/
        _53object_type_46846 = _st_index_47505;
        goto L9; // [401] 460
L8: 

        /** symtab.e:477				elsif equal(kname, "atom") then*/
        if (_kname_47506 == _24634)
        _24635 = 1;
        else if (IS_ATOM_INT(_kname_47506) && IS_ATOM_INT(_24634))
        _24635 = 0;
        else
        _24635 = (compare(_kname_47506, _24634) == 0);
        if (_24635 == 0)
        {
            _24635 = NOVALUE;
            goto LA; // [410] 423
        }
        else{
            _24635 = NOVALUE;
        }

        /** symtab.e:478					atom_type = st_index*/
        _53atom_type_46848 = _st_index_47505;
        goto L9; // [420] 460
LA: 

        /** symtab.e:479				elsif equal(kname, "integer") then*/
        if (_kname_47506 == _24636)
        _24637 = 1;
        else if (IS_ATOM_INT(_kname_47506) && IS_ATOM_INT(_24636))
        _24637 = 0;
        else
        _24637 = (compare(_kname_47506, _24636) == 0);
        if (_24637 == 0)
        {
            _24637 = NOVALUE;
            goto LB; // [429] 442
        }
        else{
            _24637 = NOVALUE;
        }

        /** symtab.e:480					integer_type = st_index*/
        _53integer_type_46852 = _st_index_47505;
        goto L9; // [439] 460
LB: 

        /** symtab.e:481				elsif equal(kname, "sequence") then*/
        if (_kname_47506 == _24638)
        _24639 = 1;
        else if (IS_ATOM_INT(_kname_47506) && IS_ATOM_INT(_24638))
        _24639 = 0;
        else
        _24639 = (compare(_kname_47506, _24638) == 0);
        if (_24639 == 0)
        {
            _24639 = NOVALUE;
            goto LC; // [448] 459
        }
        else{
            _24639 = NOVALUE;
        }

        /** symtab.e:482					sequence_type = st_index*/
        _53sequence_type_46850 = _st_index_47505;
LC: 
L9: 
L7: 
L6: 

        /** symtab.e:485			if buckets[hashval] = 0 then*/
        _2 = (object)SEQ_PTR(_53buckets_46842);
        _24640 = (object)*(((s1_ptr)_2)->base + _hashval_47501);
        if (binary_op_a(NOTEQ, _24640, 0LL)){
            _24640 = NOVALUE;
            goto LD; // [470] 485
        }
        _24640 = NOVALUE;

        /** symtab.e:486				buckets[hashval] = st_index*/
        _2 = (object)SEQ_PTR(_53buckets_46842);
        _2 = (object)(((s1_ptr)_2)->base + _hashval_47501);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _st_index_47505;
        DeRef(_1);
        goto LE; // [482] 553
LD: 

        /** symtab.e:488				s = buckets[hashval]*/
        _2 = (object)SEQ_PTR(_53buckets_46842);
        _s_47504 = (object)*(((s1_ptr)_2)->base + _hashval_47501);
        if (!IS_ATOM_INT(_s_47504)){
            _s_47504 = (object)DBL_PTR(_s_47504)->dbl;
        }

        /** symtab.e:489				while SymTab[s][S_SAMEHASH] != 0 do*/
LF: 
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _24643 = (object)*(((s1_ptr)_2)->base + _s_47504);
        _2 = (object)SEQ_PTR(_24643);
        _24644 = (object)*(((s1_ptr)_2)->base + 9LL);
        _24643 = NOVALUE;
        if (binary_op_a(EQUALS, _24644, 0LL)){
            _24644 = NOVALUE;
            goto L10; // [512] 537
        }
        _24644 = NOVALUE;

        /** symtab.e:490					s = SymTab[s][S_SAMEHASH]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _24646 = (object)*(((s1_ptr)_2)->base + _s_47504);
        _2 = (object)SEQ_PTR(_24646);
        _s_47504 = (object)*(((s1_ptr)_2)->base + 9LL);
        if (!IS_ATOM_INT(_s_47504)){
            _s_47504 = (object)DBL_PTR(_s_47504)->dbl;
        }
        _24646 = NOVALUE;

        /** symtab.e:491				end while*/
        goto LF; // [534] 500
L10: 

        /** symtab.e:492				SymTab[s][S_SAMEHASH] = st_index*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_s_47504 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 9LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _st_index_47505;
        DeRef(_1);
        _24648 = NOVALUE;
LE: 

        /** symtab.e:494		end for*/
        _k_47509 = _k_47509 + 1LL;
        goto L1; // [555] 22
L2: 
        ;
    }

    /** symtab.e:495		file_start_sym = length(SymTab)*/
    if (IS_SEQUENCE(_13SymTab_11316)){
            _12file_start_sym_20232 = SEQ_PTR(_13SymTab_11316)->length;
    }
    else {
        _12file_start_sym_20232 = 1;
    }

    /** symtab.e:497		sequence si, sj*/

    /** symtab.e:498		CurrentSub = TopLevelSub*/
    _12CurrentSub_20234 = _12TopLevelSub_20233;

    /** symtab.e:499		for i=1 to length(fixups) do*/
    if (IS_SEQUENCE(_fixups_47507)){
            _24651 = SEQ_PTR(_fixups_47507)->length;
    }
    else {
        _24651 = 1;
    }
    {
        object _i_47651;
        _i_47651 = 1LL;
L11: 
        if (_i_47651 > _24651){
            goto L12; // [585] 946
        }

        /** symtab.e:500		    si = SymTab[fixups[i]][S_CODE] -- seq of either 0's or sequences of tokens*/
        _2 = (object)SEQ_PTR(_fixups_47507);
        _24652 = (object)*(((s1_ptr)_2)->base + _i_47651);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _24653 = (object)*(((s1_ptr)_2)->base + _24652);
        DeRef(_si_47646);
        _2 = (object)SEQ_PTR(_24653);
        if (!IS_ATOM_INT(_12S_CODE_19876)){
            _si_47646 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
        }
        else{
            _si_47646 = (object)*(((s1_ptr)_2)->base + _12S_CODE_19876);
        }
        Ref(_si_47646);
        _24653 = NOVALUE;

        /** symtab.e:501		    for j=1 to length(si) do*/
        if (IS_SEQUENCE(_si_47646)){
                _24655 = SEQ_PTR(_si_47646)->length;
        }
        else {
            _24655 = 1;
        }
        {
            object _j_47659;
            _j_47659 = 1LL;
L13: 
            if (_j_47659 > _24655){
                goto L14; // [617] 920
            }

            /** symtab.e:502		        if sequence(si[j]) then*/
            _2 = (object)SEQ_PTR(_si_47646);
            _24656 = (object)*(((s1_ptr)_2)->base + _j_47659);
            _24657 = IS_SEQUENCE(_24656);
            _24656 = NOVALUE;
            if (_24657 == 0)
            {
                _24657 = NOVALUE;
                goto L15; // [633] 913
            }
            else{
                _24657 = NOVALUE;
            }

            /** symtab.e:503		            sj = si[j] -- a sequence of tokens*/
            DeRef(_sj_47647);
            _2 = (object)SEQ_PTR(_si_47646);
            _sj_47647 = (object)*(((s1_ptr)_2)->base + _j_47659);
            Ref(_sj_47647);

            /** symtab.e:504					for ij=1 to length(sj) do*/
            if (IS_SEQUENCE(_sj_47647)){
                    _24659 = SEQ_PTR(_sj_47647)->length;
            }
            else {
                _24659 = 1;
            }
            {
                object _ij_47666;
                _ij_47666 = 1LL;
L16: 
                if (_ij_47666 > _24659){
                    goto L17; // [649] 906
                }

                /** symtab.e:505		                switch sj[ij][T_ID] with fallthru do*/
                _2 = (object)SEQ_PTR(_sj_47647);
                _24660 = (object)*(((s1_ptr)_2)->base + _ij_47666);
                _2 = (object)SEQ_PTR(_24660);
                _24661 = (object)*(((s1_ptr)_2)->base + 1LL);
                _24660 = NOVALUE;
                if (IS_SEQUENCE(_24661) ){
                    goto L18; // [668] 899
                }
                if(!IS_ATOM_INT(_24661)){
                    if( (DBL_PTR(_24661)->dbl != (eudouble) ((object) DBL_PTR(_24661)->dbl) ) ){
                        goto L18; // [668] 899
                    }
                    _0 = (object) DBL_PTR(_24661)->dbl;
                }
                else {
                    _0 = _24661;
                };
                _24661 = NOVALUE;
                switch ( _0 ){ 

                    /** symtab.e:506		                    case ATOM then -- must create a lasting temp*/
                    case 502:

                    /** symtab.e:507		                    	if is_integer(sj[ij][T_SYM]) then*/
                    _2 = (object)SEQ_PTR(_sj_47647);
                    _24664 = (object)*(((s1_ptr)_2)->base + _ij_47666);
                    _2 = (object)SEQ_PTR(_24664);
                    _24665 = (object)*(((s1_ptr)_2)->base + 2LL);
                    _24664 = NOVALUE;
                    Ref(_24665);
                    _24666 = _12is_integer(_24665);
                    _24665 = NOVALUE;
                    if (_24666 == 0) {
                        DeRef(_24666);
                        _24666 = NOVALUE;
                        goto L19; // [693] 717
                    }
                    else {
                        if (!IS_ATOM_INT(_24666) && DBL_PTR(_24666)->dbl == 0.0){
                            DeRef(_24666);
                            _24666 = NOVALUE;
                            goto L19; // [693] 717
                        }
                        DeRef(_24666);
                        _24666 = NOVALUE;
                    }
                    DeRef(_24666);
                    _24666 = NOVALUE;

                    /** symtab.e:508									st_index = NewIntSym(sj[ij][T_SYM])*/
                    _2 = (object)SEQ_PTR(_sj_47647);
                    _24667 = (object)*(((s1_ptr)_2)->base + _ij_47666);
                    _2 = (object)SEQ_PTR(_24667);
                    _24668 = (object)*(((s1_ptr)_2)->base + 2LL);
                    _24667 = NOVALUE;
                    Ref(_24668);
                    _st_index_47505 = _53NewIntSym(_24668);
                    _24668 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_47505)) {
                        _1 = (object)(DBL_PTR(_st_index_47505)->dbl);
                        DeRefDS(_st_index_47505);
                        _st_index_47505 = _1;
                    }
                    goto L1A; // [714] 736
L19: 

                    /** symtab.e:510									st_index = NewDoubleSym(sj[ij][T_SYM])*/
                    _2 = (object)SEQ_PTR(_sj_47647);
                    _24670 = (object)*(((s1_ptr)_2)->base + _ij_47666);
                    _2 = (object)SEQ_PTR(_24670);
                    _24671 = (object)*(((s1_ptr)_2)->base + 2LL);
                    _24670 = NOVALUE;
                    Ref(_24671);
                    _st_index_47505 = _53NewDoubleSym(_24671);
                    _24671 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_47505)) {
                        _1 = (object)(DBL_PTR(_st_index_47505)->dbl);
                        DeRefDS(_st_index_47505);
                        _st_index_47505 = _1;
                    }
L1A: 

                    /** symtab.e:512								SymTab[st_index][S_SCOPE] = IN_USE -- TempKeep()*/
                    _2 = (object)SEQ_PTR(_13SymTab_11316);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _13SymTab_11316 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_st_index_47505 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 4LL);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = 1LL;
                    DeRef(_1);
                    _24673 = NOVALUE;

                    /** symtab.e:513								sj[ij][T_SYM] = st_index*/
                    _2 = (object)SEQ_PTR(_sj_47647);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_47647 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_ij_47666 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 2LL);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _st_index_47505;
                    DeRef(_1);
                    _24675 = NOVALUE;

                    /** symtab.e:514								break*/
                    goto L18; // [770] 899

                    /** symtab.e:515							case STRING then -- same*/
                    case 503:

                    /** symtab.e:516		                    	st_index = NewStringSym(sj[ij][T_SYM])*/
                    _2 = (object)SEQ_PTR(_sj_47647);
                    _24677 = (object)*(((s1_ptr)_2)->base + _ij_47666);
                    _2 = (object)SEQ_PTR(_24677);
                    _24678 = (object)*(((s1_ptr)_2)->base + 2LL);
                    _24677 = NOVALUE;
                    Ref(_24678);
                    _st_index_47505 = _53NewStringSym(_24678);
                    _24678 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_47505)) {
                        _1 = (object)(DBL_PTR(_st_index_47505)->dbl);
                        DeRefDS(_st_index_47505);
                        _st_index_47505 = _1;
                    }

                    /** symtab.e:517								SymTab[st_index][S_SCOPE] = IN_USE -- TempKeep()*/
                    _2 = (object)SEQ_PTR(_13SymTab_11316);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _13SymTab_11316 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_st_index_47505 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 4LL);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = 1LL;
                    DeRef(_1);
                    _24680 = NOVALUE;

                    /** symtab.e:518								sj[ij][T_SYM] = st_index*/
                    _2 = (object)SEQ_PTR(_sj_47647);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_47647 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_ij_47666 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 2LL);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _st_index_47505;
                    DeRef(_1);
                    _24682 = NOVALUE;

                    /** symtab.e:519								break*/
                    goto L18; // [826] 899

                    /** symtab.e:520							case BUILT_IN then -- name of a builtin in econd field*/
                    case 511:

                    /** symtab.e:521	                            sj[ij] = keyfind(sj[ij][T_SYM],-1)*/
                    _2 = (object)SEQ_PTR(_sj_47647);
                    _24684 = (object)*(((s1_ptr)_2)->base + _ij_47666);
                    _2 = (object)SEQ_PTR(_24684);
                    _24685 = (object)*(((s1_ptr)_2)->base + 2LL);
                    _24684 = NOVALUE;
                    Ref(_24685);
                    DeRef(_25166);
                    _25166 = _24685;
                    _25167 = _53hashfn(_25166);
                    _25166 = NOVALUE;
                    Ref(_24685);
                    _24686 = _53keyfind(_24685, -1LL, _12current_file_no_20226, 0LL, _25167);
                    _24685 = NOVALUE;
                    _25167 = NOVALUE;
                    _2 = (object)SEQ_PTR(_sj_47647);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_47647 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + _ij_47666);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _24686;
                    if( _1 != _24686 ){
                        DeRef(_1);
                    }
                    _24686 = NOVALUE;

                    /** symtab.e:522								break*/
                    goto L18; // [867] 899

                    /** symtab.e:523							case DEF_PARAM then*/
                    case 510:

                    /** symtab.e:524								sj[ij][T_SYM] &= fixups[i]*/
                    _2 = (object)SEQ_PTR(_sj_47647);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_47647 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_ij_47666 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(_fixups_47507);
                    _24689 = (object)*(((s1_ptr)_2)->base + _i_47651);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    _24690 = (object)*(((s1_ptr)_2)->base + 2LL);
                    _24687 = NOVALUE;
                    if (IS_SEQUENCE(_24690) && IS_ATOM(_24689)) {
                        Append(&_24691, _24690, _24689);
                    }
                    else if (IS_ATOM(_24690) && IS_SEQUENCE(_24689)) {
                    }
                    else {
                        Concat((object_ptr)&_24691, _24690, _24689);
                        _24690 = NOVALUE;
                    }
                    _24690 = NOVALUE;
                    _24689 = NOVALUE;
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 2LL);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _24691;
                    if( _1 != _24691 ){
                        DeRef(_1);
                    }
                    _24691 = NOVALUE;
                    _24687 = NOVALUE;
                ;}L18: 

                /** symtab.e:526					end for*/
                _ij_47666 = _ij_47666 + 1LL;
                goto L16; // [901] 656
L17: 
                ;
            }

            /** symtab.e:527					si[j] = sj*/
            RefDS(_sj_47647);
            _2 = (object)SEQ_PTR(_si_47646);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _si_47646 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _j_47659);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _sj_47647;
            DeRef(_1);
L15: 

            /** symtab.e:529			end for*/
            _j_47659 = _j_47659 + 1LL;
            goto L13; // [915] 624
L14: 
            ;
        }

        /** symtab.e:530			SymTab[fixups[i]][S_CODE] = si*/
        _2 = (object)SEQ_PTR(_fixups_47507);
        _24692 = (object)*(((s1_ptr)_2)->base + _i_47651);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_24692 + ((s1_ptr)_2)->base);
        RefDS(_si_47646);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_12S_CODE_19876))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_CODE_19876)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _12S_CODE_19876);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _si_47646;
        DeRef(_1);
        _24693 = NOVALUE;

        /** symtab.e:531		end for*/
        _i_47651 = _i_47651 + 1LL;
        goto L11; // [941] 592
L12: 
        ;
    }

    /** symtab.e:532	end procedure*/
    DeRef(_kname_47506);
    DeRefi(_fixups_47507);
    DeRef(_si_47646);
    DeRef(_sj_47647);
    _24594 = NOVALUE;
    _24613 = NOVALUE;
    _24652 = NOVALUE;
    _24692 = NOVALUE;
    return;
    ;
}


void _53add_ref(object _tok_47735)
{
    object _s_47737 = NOVALUE;
    object _24709 = NOVALUE;
    object _24708 = NOVALUE;
    object _24706 = NOVALUE;
    object _24705 = NOVALUE;
    object _24704 = NOVALUE;
    object _24702 = NOVALUE;
    object _24701 = NOVALUE;
    object _24700 = NOVALUE;
    object _24699 = NOVALUE;
    object _24698 = NOVALUE;
    object _24697 = NOVALUE;
    object _24696 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:538		s = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_47735);
    _s_47737 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_47737)){
        _s_47737 = (object)DBL_PTR(_s_47737)->dbl;
    }

    /** symtab.e:539		if s != CurrentSub and -- ignore self-ref's*/
    _24696 = (_s_47737 != _12CurrentSub_20234);
    if (_24696 == 0) {
        goto L1; // [19] 98
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24698 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_24698);
    _24699 = (object)*(((s1_ptr)_2)->base + 24LL);
    _24698 = NOVALUE;
    _24700 = find_from(_s_47737, _24699, 1LL);
    _24699 = NOVALUE;
    _24701 = (_24700 == 0);
    _24700 = NOVALUE;
    if (_24701 == 0)
    {
        DeRef(_24701);
        _24701 = NOVALUE;
        goto L1; // [46] 98
    }
    else{
        DeRef(_24701);
        _24701 = NOVALUE;
    }

    /** symtab.e:542			SymTab[s][S_NREFS] += 1*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_47737 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _24704 = (object)*(((s1_ptr)_2)->base + 12LL);
    _24702 = NOVALUE;
    if (IS_ATOM_INT(_24704)) {
        _24705 = _24704 + 1;
        if (_24705 > MAXINT){
            _24705 = NewDouble((eudouble)_24705);
        }
    }
    else
    _24705 = binary_op(PLUS, 1, _24704);
    _24704 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24705;
    if( _1 != _24705 ){
        DeRef(_1);
    }
    _24705 = NOVALUE;
    _24702 = NOVALUE;

    /** symtab.e:543			SymTab[CurrentSub][S_REFLIST] &= s*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_12CurrentSub_20234 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _24708 = (object)*(((s1_ptr)_2)->base + 24LL);
    _24706 = NOVALUE;
    if (IS_SEQUENCE(_24708) && IS_ATOM(_s_47737)) {
        Append(&_24709, _24708, _s_47737);
    }
    else if (IS_ATOM(_24708) && IS_SEQUENCE(_s_47737)) {
    }
    else {
        Concat((object_ptr)&_24709, _24708, _s_47737);
        _24708 = NOVALUE;
    }
    _24708 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 24LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24709;
    if( _1 != _24709 ){
        DeRef(_1);
    }
    _24709 = NOVALUE;
    _24706 = NOVALUE;
L1: 

    /** symtab.e:545	end procedure*/
    DeRef(_tok_47735);
    DeRef(_24696);
    _24696 = NOVALUE;
    return;
    ;
}


void _53mark_all(object _attribute_47767)
{
    object _p_47770 = NOVALUE;
    object _sym_file_47777 = NOVALUE;
    object _scope_47794 = NOVALUE;
    object _24741 = NOVALUE;
    object _24740 = NOVALUE;
    object _24739 = NOVALUE;
    object _24737 = NOVALUE;
    object _24735 = NOVALUE;
    object _24734 = NOVALUE;
    object _24733 = NOVALUE;
    object _24732 = NOVALUE;
    object _24731 = NOVALUE;
    object _24729 = NOVALUE;
    object _24728 = NOVALUE;
    object _24727 = NOVALUE;
    object _24726 = NOVALUE;
    object _24722 = NOVALUE;
    object _24721 = NOVALUE;
    object _24720 = NOVALUE;
    object _24718 = NOVALUE;
    object _24717 = NOVALUE;
    object _24715 = NOVALUE;
    object _24713 = NOVALUE;
    object _24710 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:550		if just_mark_everything_from then*/
    if (_53just_mark_everything_from_47764 == 0)
    {
        goto L1; // [7] 270
    }
    else{
    }

    /** symtab.e:551			symtab_pointer p = SymTab[just_mark_everything_from][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24710 = (object)*(((s1_ptr)_2)->base + _53just_mark_everything_from_47764);
    _2 = (object)SEQ_PTR(_24710);
    _p_47770 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_p_47770)){
        _p_47770 = (object)DBL_PTR(_p_47770)->dbl;
    }
    _24710 = NOVALUE;

    /** symtab.e:552			while p != 0 do*/
L2: 
    if (_p_47770 == 0LL)
    goto L3; // [33] 269

    /** symtab.e:553				integer sym_file = SymTab[p][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24713 = (object)*(((s1_ptr)_2)->base + _p_47770);
    _2 = (object)SEQ_PTR(_24713);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _sym_file_47777 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _sym_file_47777 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    if (!IS_ATOM_INT(_sym_file_47777)){
        _sym_file_47777 = (object)DBL_PTR(_sym_file_47777)->dbl;
    }
    _24713 = NOVALUE;

    /** symtab.e:554				just_mark_everything_from = p*/
    _53just_mark_everything_from_47764 = _p_47770;

    /** symtab.e:555				if sym_file = current_file_no or map:has( recheck_routines, sym_file ) then*/
    _24715 = (_sym_file_47777 == _12current_file_no_20226);
    if (_24715 != 0) {
        goto L4; // [68] 84
    }
    Ref(_53recheck_routines_47837);
    _24717 = _34has(_53recheck_routines_47837, _sym_file_47777);
    if (_24717 == 0) {
        DeRef(_24717);
        _24717 = NOVALUE;
        goto L5; // [80] 108
    }
    else {
        if (!IS_ATOM_INT(_24717) && DBL_PTR(_24717)->dbl == 0.0){
            DeRef(_24717);
            _24717 = NOVALUE;
            goto L5; // [80] 108
        }
        DeRef(_24717);
        _24717 = NOVALUE;
    }
    DeRef(_24717);
    _24717 = NOVALUE;
L4: 

    /** symtab.e:556					SymTab[p][attribute] += 1*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47770 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _24720 = (object)*(((s1_ptr)_2)->base + _attribute_47767);
    _24718 = NOVALUE;
    if (IS_ATOM_INT(_24720)) {
        _24721 = _24720 + 1;
        if (_24721 > MAXINT){
            _24721 = NewDouble((eudouble)_24721);
        }
    }
    else
    _24721 = binary_op(PLUS, 1, _24720);
    _24720 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _attribute_47767);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24721;
    if( _1 != _24721 ){
        DeRef(_1);
    }
    _24721 = NOVALUE;
    _24718 = NOVALUE;
    goto L6; // [105] 246
L5: 

    /** symtab.e:558					integer scope = SymTab[p][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24722 = (object)*(((s1_ptr)_2)->base + _p_47770);
    _2 = (object)SEQ_PTR(_24722);
    _scope_47794 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_scope_47794)){
        _scope_47794 = (object)DBL_PTR(_scope_47794)->dbl;
    }
    _24722 = NOVALUE;

    /** symtab.e:559					switch scope with fallthru do*/
    _0 = _scope_47794;
    switch ( _0 ){ 

        /** symtab.e:560						case SC_PUBLIC then*/
        case 13:

        /** symtab.e:561							if and_bits( DIRECT_OR_PUBLIC_INCLUDE, include_matrix[current_file_no][sym_file] ) then*/
        _2 = (object)SEQ_PTR(_13include_matrix_11323);
        _24726 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
        _2 = (object)SEQ_PTR(_24726);
        _24727 = (object)*(((s1_ptr)_2)->base + _sym_file_47777);
        _24726 = NOVALUE;
        if (IS_ATOM_INT(_24727)) {
            {uintptr_t tu;
                 tu = (uintptr_t)6LL & (uintptr_t)_24727;
                 _24728 = MAKE_UINT(tu);
            }
        }
        else {
            _24728 = binary_op(AND_BITS, 6LL, _24727);
        }
        _24727 = NOVALUE;
        if (_24728 == 0) {
            DeRef(_24728);
            _24728 = NOVALUE;
            goto L7; // [155] 243
        }
        else {
            if (!IS_ATOM_INT(_24728) && DBL_PTR(_24728)->dbl == 0.0){
                DeRef(_24728);
                _24728 = NOVALUE;
                goto L7; // [155] 243
            }
            DeRef(_24728);
            _24728 = NOVALUE;
        }
        DeRef(_24728);
        _24728 = NOVALUE;

        /** symtab.e:562								SymTab[p][attribute] += 1*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_47770 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _24731 = (object)*(((s1_ptr)_2)->base + _attribute_47767);
        _24729 = NOVALUE;
        if (IS_ATOM_INT(_24731)) {
            _24732 = _24731 + 1;
            if (_24732 > MAXINT){
                _24732 = NewDouble((eudouble)_24732);
            }
        }
        else
        _24732 = binary_op(PLUS, 1, _24731);
        _24731 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _attribute_47767);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24732;
        if( _1 != _24732 ){
            DeRef(_1);
        }
        _24732 = NOVALUE;
        _24729 = NOVALUE;

        /** symtab.e:564							break*/
        goto L7; // [182] 243

        /** symtab.e:565						case SC_EXPORT then*/
        case 11:

        /** symtab.e:566							if not and_bits( DIRECT_INCLUDE, include_matrix[current_file_no][sym_file] ) then*/
        _2 = (object)SEQ_PTR(_13include_matrix_11323);
        _24733 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
        _2 = (object)SEQ_PTR(_24733);
        _24734 = (object)*(((s1_ptr)_2)->base + _sym_file_47777);
        _24733 = NOVALUE;
        if (IS_ATOM_INT(_24734)) {
            {uintptr_t tu;
                 tu = (uintptr_t)2LL & (uintptr_t)_24734;
                 _24735 = MAKE_UINT(tu);
            }
        }
        else {
            _24735 = binary_op(AND_BITS, 2LL, _24734);
        }
        _24734 = NOVALUE;
        if (IS_ATOM_INT(_24735)) {
            if (_24735 != 0){
                DeRef(_24735);
                _24735 = NOVALUE;
                goto L8; // [208] 216
            }
        }
        else {
            if (DBL_PTR(_24735)->dbl != 0.0){
                DeRef(_24735);
                _24735 = NOVALUE;
                goto L8; // [208] 216
            }
        }
        DeRef(_24735);
        _24735 = NOVALUE;

        /** symtab.e:567								break*/
        goto L9; // [213] 217
L8: 
L9: 

        /** symtab.e:570						case SC_GLOBAL then*/
        case 6:

        /** symtab.e:571							SymTab[p][attribute] += 1*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _13SymTab_11316 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_47770 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _24739 = (object)*(((s1_ptr)_2)->base + _attribute_47767);
        _24737 = NOVALUE;
        if (IS_ATOM_INT(_24739)) {
            _24740 = _24739 + 1;
            if (_24740 > MAXINT){
                _24740 = NewDouble((eudouble)_24740);
            }
        }
        else
        _24740 = binary_op(PLUS, 1, _24739);
        _24739 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _attribute_47767);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24740;
        if( _1 != _24740 ){
            DeRef(_1);
        }
        _24740 = NOVALUE;
        _24737 = NOVALUE;
    ;}L7: 
L6: 

    /** symtab.e:575				p = SymTab[p][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24741 = (object)*(((s1_ptr)_2)->base + _p_47770);
    _2 = (object)SEQ_PTR(_24741);
    _p_47770 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_p_47770)){
        _p_47770 = (object)DBL_PTR(_p_47770)->dbl;
    }
    _24741 = NOVALUE;

    /** symtab.e:576			end while*/
    goto L2; // [266] 33
L3: 
L1: 

    /** symtab.e:578	end procedure*/
    DeRef(_24715);
    _24715 = NOVALUE;
    return;
    ;
}


void _53mark_rechecks(object _file_no_47843)
{
    object _recheck_targets_47846 = NOVALUE;
    object _remaining_47850 = NOVALUE;
    object _marked_47854 = NOVALUE;
    object _24748 = NOVALUE;
    object _24746 = NOVALUE;
    object _24745 = NOVALUE;
    object _24744 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_file_no_47843)) {
        _1 = (object)(DBL_PTR(_file_no_47843)->dbl);
        DeRefDS(_file_no_47843);
        _file_no_47843 = _1;
    }

    /** symtab.e:584		sequence recheck_targets = map:get( recheck_routines, file_no, {} )*/
    Ref(_53recheck_routines_47837);
    RefDS(_22024);
    _0 = _recheck_targets_47846;
    _recheck_targets_47846 = _34get(_53recheck_routines_47837, _file_no_47843, _22024);
    DeRef(_0);

    /** symtab.e:585		if length( recheck_targets ) then*/
    if (IS_SEQUENCE(_recheck_targets_47846)){
            _24744 = SEQ_PTR(_recheck_targets_47846)->length;
    }
    else {
        _24744 = 1;
    }
    if (_24744 == 0)
    {
        _24744 = NOVALUE;
        goto L1; // [20] 129
    }
    else{
        _24744 = NOVALUE;
    }

    /** symtab.e:586			sequence remaining = {}*/
    RefDS(_22024);
    DeRefi(_remaining_47850);
    _remaining_47850 = _22024;

    /** symtab.e:587			for i = length( recheck_targets ) to 1 by -1 do*/
    if (IS_SEQUENCE(_recheck_targets_47846)){
            _24745 = SEQ_PTR(_recheck_targets_47846)->length;
    }
    else {
        _24745 = 1;
    }
    {
        object _i_47852;
        _i_47852 = _24745;
L2: 
        if (_i_47852 < 1LL){
            goto L3; // [35] 117
        }

        /** symtab.e:588				integer marked = 0*/
        _marked_47854 = 0LL;

        /** symtab.e:589				if TRANSLATE then*/
        if (_12TRANSLATE_19834 == 0)
        {
            goto L4; // [51] 72
        }
        else{
        }

        /** symtab.e:590					marked = MarkTargets( recheck_targets[i], S_RI_TARGET )*/
        _2 = (object)SEQ_PTR(_recheck_targets_47846);
        _24746 = (object)*(((s1_ptr)_2)->base + _i_47852);
        Ref(_24746);
        _marked_47854 = _53MarkTargets(_24746, 53LL);
        _24746 = NOVALUE;
        if (!IS_ATOM_INT(_marked_47854)) {
            _1 = (object)(DBL_PTR(_marked_47854)->dbl);
            DeRefDS(_marked_47854);
            _marked_47854 = _1;
        }
        goto L5; // [69] 96
L4: 

        /** symtab.e:591				elsif BIND then*/
        if (_12BIND_19837 == 0)
        {
            goto L6; // [76] 95
        }
        else{
        }

        /** symtab.e:592					marked = MarkTargets( recheck_targets[i], S_NREFS )*/
        _2 = (object)SEQ_PTR(_recheck_targets_47846);
        _24748 = (object)*(((s1_ptr)_2)->base + _i_47852);
        Ref(_24748);
        _marked_47854 = _53MarkTargets(_24748, 12LL);
        _24748 = NOVALUE;
        if (!IS_ATOM_INT(_marked_47854)) {
            _1 = (object)(DBL_PTR(_marked_47854)->dbl);
            DeRefDS(_marked_47854);
            _marked_47854 = _1;
        }
L6: 
L5: 

        /** symtab.e:594				if not marked then*/
        if (_marked_47854 != 0)
        goto L7; // [98] 108

        /** symtab.e:595					remaining &= file_no*/
        Append(&_remaining_47850, _remaining_47850, _file_no_47843);
L7: 

        /** symtab.e:597			end for*/
        _i_47852 = _i_47852 + -1LL;
        goto L2; // [112] 42
L3: 
        ;
    }

    /** symtab.e:598			map:put( recheck_routines, file_no, recheck_targets )*/
    Ref(_53recheck_routines_47837);
    RefDS(_recheck_targets_47846);
    _34put(_53recheck_routines_47837, _file_no_47843, _recheck_targets_47846, 1LL, 0LL);
L1: 
    DeRefi(_remaining_47850);
    _remaining_47850 = NOVALUE;

    /** symtab.e:600	end procedure*/
    DeRef(_recheck_targets_47846);
    return;
    ;
}


void _53mark_final_targets()
{
    object _size_1__tmp_at47_47882 = NOVALUE;
    object _size_inlined_size_at_47_47881 = NOVALUE;
    object _recheck_files_47883 = NOVALUE;
    object _24754 = NOVALUE;
    object _24753 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:603		if just_mark_everything_from then*/
    if (_53just_mark_everything_from_47764 == 0)
    {
        goto L1; // [5] 44
    }
    else{
    }

    /** symtab.e:604			if TRANSLATE then*/
    if (_12TRANSLATE_19834 == 0)
    {
        goto L2; // [12] 25
    }
    else{
    }

    /** symtab.e:605				mark_all( S_RI_TARGET )*/
    _53mark_all(53LL);
    goto L3; // [22] 109
L2: 

    /** symtab.e:606			elsif BIND then*/
    if (_12BIND_19837 == 0)
    {
        goto L3; // [29] 109
    }
    else{
    }

    /** symtab.e:607				mark_all( S_NREFS )*/
    _53mark_all(12LL);
    goto L3; // [41] 109
L1: 

    /** symtab.e:609		elsif map:size( recheck_routines ) then*/

    /** map.e:800		return eumem:ram_space[the_map_p][MAP_SIZE]*/
    DeRef(_size_1__tmp_at47_47882);
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!IS_ATOM_INT(_53recheck_routines_47837)){
        _size_1__tmp_at47_47882 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_53recheck_routines_47837)->dbl));
    }
    else{
        _size_1__tmp_at47_47882 = (object)*(((s1_ptr)_2)->base + _53recheck_routines_47837);
    }
    Ref(_size_1__tmp_at47_47882);
    DeRef(_size_inlined_size_at_47_47881);
    _2 = (object)SEQ_PTR(_size_1__tmp_at47_47882);
    _size_inlined_size_at_47_47881 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_size_inlined_size_at_47_47881);
    DeRef(_size_1__tmp_at47_47882);
    _size_1__tmp_at47_47882 = NOVALUE;
    if (_size_inlined_size_at_47_47881 == 0) {
        goto L4; // [63] 106
    }
    else {
        if (!IS_ATOM_INT(_size_inlined_size_at_47_47881) && DBL_PTR(_size_inlined_size_at_47_47881)->dbl == 0.0){
            goto L4; // [63] 106
        }
    }

    /** symtab.e:610			sequence recheck_files = map:keys( recheck_routines )*/
    Ref(_53recheck_routines_47837);
    _0 = _recheck_files_47883;
    _recheck_files_47883 = _34keys(_53recheck_routines_47837, 0LL);
    DeRef(_0);

    /** symtab.e:611			for i = 1 to length( recheck_files ) do*/
    if (IS_SEQUENCE(_recheck_files_47883)){
            _24753 = SEQ_PTR(_recheck_files_47883)->length;
    }
    else {
        _24753 = 1;
    }
    {
        object _i_47886;
        _i_47886 = 1LL;
L5: 
        if (_i_47886 > _24753){
            goto L6; // [82] 105
        }

        /** symtab.e:612				mark_rechecks( recheck_files[i] )*/
        _2 = (object)SEQ_PTR(_recheck_files_47883);
        _24754 = (object)*(((s1_ptr)_2)->base + _i_47886);
        Ref(_24754);
        _53mark_rechecks(_24754);
        _24754 = NOVALUE;

        /** symtab.e:613			end for*/
        _i_47886 = _i_47886 + 1LL;
        goto L5; // [100] 89
L6: 
        ;
    }
L4: 
    DeRef(_recheck_files_47883);
    _recheck_files_47883 = NOVALUE;
L3: 

    /** symtab.e:615	end procedure*/
    return;
    ;
}


object _53is_routine(object _sym_47892)
{
    object _tok_47893 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:618		integer tok = sym_token( sym )*/
    _tok_47893 = _53sym_token(_sym_47892);
    if (!IS_ATOM_INT(_tok_47893)) {
        _1 = (object)(DBL_PTR(_tok_47893)->dbl);
        DeRefDS(_tok_47893);
        _tok_47893 = _1;
    }

    /** symtab.e:619		switch tok do*/
    _0 = _tok_47893;
    switch ( _0 ){ 

        /** symtab.e:620			case FUNC, PROC, TYPE then*/
        case 501:
        case 27:
        case 504:

        /** symtab.e:621				return 1*/
        return 1LL;
        goto L1; // [32] 45

        /** symtab.e:622			case else*/
        default:

        /** symtab.e:623				return 0*/
        return 0LL;
    ;}L1: 
    ;
}


object _53is_visible(object _sym_47906, object _from_file_47907)
{
    object _scope_47908 = NOVALUE;
    object _sym_file_47911 = NOVALUE;
    object _visible_mask_47916 = NOVALUE;
    object _24766 = NOVALUE;
    object _24765 = NOVALUE;
    object _24764 = NOVALUE;
    object _24763 = NOVALUE;
    object _24759 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:628		integer scope = sym_scope( sym )*/
    _scope_47908 = _53sym_scope(_sym_47906);
    if (!IS_ATOM_INT(_scope_47908)) {
        _1 = (object)(DBL_PTR(_scope_47908)->dbl);
        DeRefDS(_scope_47908);
        _scope_47908 = _1;
    }

    /** symtab.e:629		integer sym_file = SymTab[sym][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24759 = (object)*(((s1_ptr)_2)->base + _sym_47906);
    _2 = (object)SEQ_PTR(_24759);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _sym_file_47911 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _sym_file_47911 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    if (!IS_ATOM_INT(_sym_file_47911)){
        _sym_file_47911 = (object)DBL_PTR(_sym_file_47911)->dbl;
    }
    _24759 = NOVALUE;

    /** symtab.e:631		switch scope do*/
    _0 = _scope_47908;
    switch ( _0 ){ 

        /** symtab.e:632			case SC_PUBLIC then*/
        case 13:

        /** symtab.e:633				visible_mask = DIRECT_OR_PUBLIC_INCLUDE*/
        _visible_mask_47916 = 6LL;
        goto L1; // [49] 93

        /** symtab.e:634			case SC_EXPORT then*/
        case 11:

        /** symtab.e:635				visible_mask = DIRECT_INCLUDE*/
        _visible_mask_47916 = 2LL;
        goto L1; // [64] 93

        /** symtab.e:636			case SC_GLOBAL then*/
        case 6:

        /** symtab.e:637				return 1*/
        return 1LL;
        goto L1; // [76] 93

        /** symtab.e:638			case else*/
        default:

        /** symtab.e:639				return from_file = sym_file*/
        _24763 = (_from_file_47907 == _sym_file_47911);
        return _24763;
    ;}L1: 

    /** symtab.e:641		return and_bits( visible_mask, include_matrix[from_file][sym_file] )*/
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _24764 = (object)*(((s1_ptr)_2)->base + _from_file_47907);
    _2 = (object)SEQ_PTR(_24764);
    _24765 = (object)*(((s1_ptr)_2)->base + _sym_file_47911);
    _24764 = NOVALUE;
    if (IS_ATOM_INT(_24765)) {
        {uintptr_t tu;
             tu = (uintptr_t)_visible_mask_47916 & (uintptr_t)_24765;
             _24766 = MAKE_UINT(tu);
        }
    }
    else {
        _24766 = binary_op(AND_BITS, _visible_mask_47916, _24765);
    }
    _24765 = NOVALUE;
    DeRef(_24763);
    _24763 = NOVALUE;
    return _24766;
    ;
}


object _53MarkTargets(object _s_47936, object _attribute_47937)
{
    object _p_47939 = NOVALUE;
    object _sname_47940 = NOVALUE;
    object _string_47941 = NOVALUE;
    object _colon_47942 = NOVALUE;
    object _h_47943 = NOVALUE;
    object _scope_47944 = NOVALUE;
    object _found_47965 = NOVALUE;
    object _24814 = NOVALUE;
    object _24812 = NOVALUE;
    object _24811 = NOVALUE;
    object _24810 = NOVALUE;
    object _24809 = NOVALUE;
    object _24807 = NOVALUE;
    object _24806 = NOVALUE;
    object _24805 = NOVALUE;
    object _24804 = NOVALUE;
    object _24803 = NOVALUE;
    object _24801 = NOVALUE;
    object _24800 = NOVALUE;
    object _24799 = NOVALUE;
    object _24797 = NOVALUE;
    object _24795 = NOVALUE;
    object _24793 = NOVALUE;
    object _24792 = NOVALUE;
    object _24791 = NOVALUE;
    object _24790 = NOVALUE;
    object _24788 = NOVALUE;
    object _24787 = NOVALUE;
    object _24786 = NOVALUE;
    object _24785 = NOVALUE;
    object _24783 = NOVALUE;
    object _24782 = NOVALUE;
    object _24778 = NOVALUE;
    object _24777 = NOVALUE;
    object _24776 = NOVALUE;
    object _24775 = NOVALUE;
    object _24774 = NOVALUE;
    object _24773 = NOVALUE;
    object _24772 = NOVALUE;
    object _24771 = NOVALUE;
    object _24770 = NOVALUE;
    object _24769 = NOVALUE;
    object _24768 = NOVALUE;
    object _24767 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_47936)) {
        _1 = (object)(DBL_PTR(_s_47936)->dbl);
        DeRefDS(_s_47936);
        _s_47936 = _1;
    }

    /** symtab.e:648		sequence sname*/

    /** symtab.e:649		sequence string*/

    /** symtab.e:650		integer colon, h*/

    /** symtab.e:651		integer scope*/

    /** symtab.e:653		if (SymTab[s][S_MODE] = M_TEMP or*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24767 = (object)*(((s1_ptr)_2)->base + _s_47936);
    _2 = (object)SEQ_PTR(_24767);
    _24768 = (object)*(((s1_ptr)_2)->base + 3LL);
    _24767 = NOVALUE;
    if (IS_ATOM_INT(_24768)) {
        _24769 = (_24768 == 3LL);
    }
    else {
        _24769 = binary_op(EQUALS, _24768, 3LL);
    }
    _24768 = NOVALUE;
    if (IS_ATOM_INT(_24769)) {
        if (_24769 != 0) {
            _24770 = 1;
            goto L1; // [33] 59
        }
    }
    else {
        if (DBL_PTR(_24769)->dbl != 0.0) {
            _24770 = 1;
            goto L1; // [33] 59
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24771 = (object)*(((s1_ptr)_2)->base + _s_47936);
    _2 = (object)SEQ_PTR(_24771);
    _24772 = (object)*(((s1_ptr)_2)->base + 3LL);
    _24771 = NOVALUE;
    if (IS_ATOM_INT(_24772)) {
        _24773 = (_24772 == 2LL);
    }
    else {
        _24773 = binary_op(EQUALS, _24772, 2LL);
    }
    _24772 = NOVALUE;
    DeRef(_24770);
    if (IS_ATOM_INT(_24773))
    _24770 = (_24773 != 0);
    else
    _24770 = DBL_PTR(_24773)->dbl != 0.0;
L1: 
    if (_24770 == 0) {
        goto L2; // [59] 411
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24775 = (object)*(((s1_ptr)_2)->base + _s_47936);
    _2 = (object)SEQ_PTR(_24775);
    _24776 = (object)*(((s1_ptr)_2)->base + 1LL);
    _24775 = NOVALUE;
    _24777 = IS_SEQUENCE(_24776);
    _24776 = NOVALUE;
    if (_24777 == 0)
    {
        _24777 = NOVALUE;
        goto L2; // [79] 411
    }
    else{
        _24777 = NOVALUE;
    }

    /** symtab.e:658			integer found = 0*/
    _found_47965 = 0LL;

    /** symtab.e:660			string = SymTab[s][S_OBJ]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24778 = (object)*(((s1_ptr)_2)->base + _s_47936);
    DeRef(_string_47941);
    _2 = (object)SEQ_PTR(_24778);
    _string_47941 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_string_47941);
    _24778 = NOVALUE;

    /** symtab.e:661			colon = find(':', string)*/
    _colon_47942 = find_from(58LL, _string_47941, 1LL);

    /** symtab.e:662			if colon = 0 then*/
    if (_colon_47942 != 0LL)
    goto L3; // [112] 126

    /** symtab.e:663				sname = string*/
    RefDS(_string_47941);
    DeRef(_sname_47940);
    _sname_47940 = _string_47941;
    goto L4; // [123] 200
L3: 

    /** symtab.e:665				sname = string[colon+1..$]  -- ignore namespace part*/
    _24782 = _colon_47942 + 1;
    if (_24782 > MAXINT){
        _24782 = NewDouble((eudouble)_24782);
    }
    if (IS_SEQUENCE(_string_47941)){
            _24783 = SEQ_PTR(_string_47941)->length;
    }
    else {
        _24783 = 1;
    }
    rhs_slice_target = (object_ptr)&_sname_47940;
    RHS_Slice(_string_47941, _24782, _24783);

    /** symtab.e:666				while length(sname) and sname[1] = ' ' or sname[1] = '\t' do*/
L5: 
    if (IS_SEQUENCE(_sname_47940)){
            _24785 = SEQ_PTR(_sname_47940)->length;
    }
    else {
        _24785 = 1;
    }
    if (_24785 == 0) {
        _24786 = 0;
        goto L6; // [148] 164
    }
    _2 = (object)SEQ_PTR(_sname_47940);
    _24787 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_24787)) {
        _24788 = (_24787 == 32LL);
    }
    else {
        _24788 = binary_op(EQUALS, _24787, 32LL);
    }
    _24787 = NOVALUE;
    if (IS_ATOM_INT(_24788))
    _24786 = (_24788 != 0);
    else
    _24786 = DBL_PTR(_24788)->dbl != 0.0;
L6: 
    if (_24786 != 0) {
        goto L7; // [164] 181
    }
    _2 = (object)SEQ_PTR(_sname_47940);
    _24790 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_24790)) {
        _24791 = (_24790 == 9LL);
    }
    else {
        _24791 = binary_op(EQUALS, _24790, 9LL);
    }
    _24790 = NOVALUE;
    if (_24791 <= 0) {
        if (_24791 == 0) {
            DeRef(_24791);
            _24791 = NOVALUE;
            goto L8; // [177] 199
        }
        else {
            if (!IS_ATOM_INT(_24791) && DBL_PTR(_24791)->dbl == 0.0){
                DeRef(_24791);
                _24791 = NOVALUE;
                goto L8; // [177] 199
            }
            DeRef(_24791);
            _24791 = NOVALUE;
        }
    }
    DeRef(_24791);
    _24791 = NOVALUE;
L7: 

    /** symtab.e:667					sname = tail( sname, length( sname ) -1 )*/
    if (IS_SEQUENCE(_sname_47940)){
            _24792 = SEQ_PTR(_sname_47940)->length;
    }
    else {
        _24792 = 1;
    }
    _24793 = _24792 - 1LL;
    _24792 = NOVALUE;
    {
        int len = SEQ_PTR(_sname_47940)->length;
        int size = (IS_ATOM_INT(_24793)) ? _24793 : (object)(DBL_PTR(_24793)->dbl);
        if (size <= 0) {
            DeRef(_sname_47940);
            _sname_47940 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_sname_47940);
            DeRef(_sname_47940);
            _sname_47940 = _sname_47940;
        }
        else Tail(SEQ_PTR(_sname_47940), len-size+1, &_sname_47940);
    }
    _24793 = NOVALUE;

    /** symtab.e:668				end while*/
    goto L5; // [196] 145
L8: 
L4: 

    /** symtab.e:671			if length(sname) = 0 then*/
    if (IS_SEQUENCE(_sname_47940)){
            _24795 = SEQ_PTR(_sname_47940)->length;
    }
    else {
        _24795 = 1;
    }
    if (_24795 != 0LL)
    goto L9; // [207] 218

    /** symtab.e:672				return 1*/
    DeRefDS(_sname_47940);
    DeRef(_string_47941);
    DeRef(_24769);
    _24769 = NOVALUE;
    DeRef(_24782);
    _24782 = NOVALUE;
    DeRef(_24788);
    _24788 = NOVALUE;
    DeRef(_24773);
    _24773 = NOVALUE;
    return 1LL;
L9: 

    /** symtab.e:674			h = buckets[hashfn(sname)]*/
    RefDS(_sname_47940);
    _24797 = _53hashfn(_sname_47940);
    _2 = (object)SEQ_PTR(_53buckets_46842);
    if (!IS_ATOM_INT(_24797)){
        _h_47943 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24797)->dbl));
    }
    else{
        _h_47943 = (object)*(((s1_ptr)_2)->base + _24797);
    }
    if (!IS_ATOM_INT(_h_47943))
    _h_47943 = (object)DBL_PTR(_h_47943)->dbl;

    /** symtab.e:675			while h do*/
LA: 
    if (_h_47943 == 0)
    {
        goto LB; // [235] 381
    }
    else{
    }

    /** symtab.e:676				if equal(sname, SymTab[h][S_NAME]) then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24799 = (object)*(((s1_ptr)_2)->base + _h_47943);
    _2 = (object)SEQ_PTR(_24799);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _24800 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _24800 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _24799 = NOVALUE;
    if (_sname_47940 == _24800)
    _24801 = 1;
    else if (IS_ATOM_INT(_sname_47940) && IS_ATOM_INT(_24800))
    _24801 = 0;
    else
    _24801 = (compare(_sname_47940, _24800) == 0);
    _24800 = NOVALUE;
    if (_24801 == 0)
    {
        _24801 = NOVALUE;
        goto LC; // [256] 360
    }
    else{
        _24801 = NOVALUE;
    }

    /** symtab.e:677					if attribute = S_NREFS then*/
    if (_attribute_47937 != 12LL)
    goto LD; // [263] 289

    /** symtab.e:678						if BIND then*/
    if (_12BIND_19837 == 0)
    {
        goto LE; // [271] 359
    }
    else{
    }

    /** symtab.e:679							add_ref({PROC, h})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 27LL;
    ((intptr_t *)_2)[2] = _h_47943;
    _24803 = MAKE_SEQ(_1);
    _53add_ref(_24803);
    _24803 = NOVALUE;
    goto LE; // [286] 359
LD: 

    /** symtab.e:681					elsif is_routine( h ) and is_visible( h, current_file_no ) then*/
    _24804 = _53is_routine(_h_47943);
    if (IS_ATOM_INT(_24804)) {
        if (_24804 == 0) {
            goto LF; // [295] 358
        }
    }
    else {
        if (DBL_PTR(_24804)->dbl == 0.0) {
            goto LF; // [295] 358
        }
    }
    _24806 = _53is_visible(_h_47943, _12current_file_no_20226);
    if (_24806 == 0) {
        DeRef(_24806);
        _24806 = NOVALUE;
        goto LF; // [307] 358
    }
    else {
        if (!IS_ATOM_INT(_24806) && DBL_PTR(_24806)->dbl == 0.0){
            DeRef(_24806);
            _24806 = NOVALUE;
            goto LF; // [307] 358
        }
        DeRef(_24806);
        _24806 = NOVALUE;
    }
    DeRef(_24806);
    _24806 = NOVALUE;

    /** symtab.e:682						SymTab[h][attribute] += 1*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_h_47943 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _24809 = (object)*(((s1_ptr)_2)->base + _attribute_47937);
    _24807 = NOVALUE;
    if (IS_ATOM_INT(_24809)) {
        _24810 = _24809 + 1;
        if (_24810 > MAXINT){
            _24810 = NewDouble((eudouble)_24810);
        }
    }
    else
    _24810 = binary_op(PLUS, 1, _24809);
    _24809 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _attribute_47937);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24810;
    if( _1 != _24810 ){
        DeRef(_1);
    }
    _24810 = NOVALUE;
    _24807 = NOVALUE;

    /** symtab.e:683						if current_file_no = SymTab[h][S_FILE_NO] then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24811 = (object)*(((s1_ptr)_2)->base + _h_47943);
    _2 = (object)SEQ_PTR(_24811);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _24812 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _24812 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _24811 = NOVALUE;
    if (binary_op_a(NOTEQ, _12current_file_no_20226, _24812)){
        _24812 = NOVALUE;
        goto L10; // [347] 357
    }
    _24812 = NOVALUE;

    /** symtab.e:684							found = 1*/
    _found_47965 = 1LL;
L10: 
LF: 
LE: 
LC: 

    /** symtab.e:688				h = SymTab[h][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24814 = (object)*(((s1_ptr)_2)->base + _h_47943);
    _2 = (object)SEQ_PTR(_24814);
    _h_47943 = (object)*(((s1_ptr)_2)->base + 9LL);
    if (!IS_ATOM_INT(_h_47943)){
        _h_47943 = (object)DBL_PTR(_h_47943)->dbl;
    }
    _24814 = NOVALUE;

    /** symtab.e:689			end while*/
    goto LA; // [378] 235
LB: 

    /** symtab.e:691			if not found then*/
    if (_found_47965 != 0)
    goto L11; // [383] 400

    /** symtab.e:692				map:put( recheck_routines, current_file_no, s, map:APPEND )*/
    Ref(_53recheck_routines_47837);
    _34put(_53recheck_routines_47837, _12current_file_no_20226, _s_47936, 6LL, 0LL);
L11: 

    /** symtab.e:694			return found*/
    DeRef(_sname_47940);
    DeRef(_string_47941);
    DeRef(_24769);
    _24769 = NOVALUE;
    DeRef(_24804);
    _24804 = NOVALUE;
    DeRef(_24782);
    _24782 = NOVALUE;
    DeRef(_24797);
    _24797 = NOVALUE;
    DeRef(_24788);
    _24788 = NOVALUE;
    DeRef(_24773);
    _24773 = NOVALUE;
    return _found_47965;
    goto L12; // [408] 440
L2: 

    /** symtab.e:696			if not just_mark_everything_from then*/
    if (_53just_mark_everything_from_47764 != 0)
    goto L13; // [415] 428

    /** symtab.e:697				just_mark_everything_from = TopLevelSub*/
    _53just_mark_everything_from_47764 = _12TopLevelSub_20233;
L13: 

    /** symtab.e:699			mark_all( attribute )*/
    _53mark_all(_attribute_47937);

    /** symtab.e:700			return 1*/
    DeRef(_sname_47940);
    DeRef(_string_47941);
    DeRef(_24769);
    _24769 = NOVALUE;
    DeRef(_24804);
    _24804 = NOVALUE;
    DeRef(_24782);
    _24782 = NOVALUE;
    DeRef(_24797);
    _24797 = NOVALUE;
    DeRef(_24788);
    _24788 = NOVALUE;
    DeRef(_24773);
    _24773 = NOVALUE;
    return 1LL;
L12: 
    ;
}


void _53resolve_unincluded_globals(object _ok_48043)
{
    object _0, _1, _2;
    

    /** symtab.e:724		Resolve_unincluded_globals = ok*/
    _53Resolve_unincluded_globals_48040 = 1LL;

    /** symtab.e:725	end procedure*/
    return;
    ;
}


object _53get_resolve_unincluded_globals()
{
    object _0, _1, _2;
    

    /** symtab.e:728		return Resolve_unincluded_globals*/
    return _53Resolve_unincluded_globals_48040;
    ;
}


object _53keyfind(object _word_48049, object _file_no_48050, object _scanning_file_48051, object _namespace_ok_48054, object _hashval_48055)
{
    object _msg_48057 = NOVALUE;
    object _b_name_48058 = NOVALUE;
    object _scope_48059 = NOVALUE;
    object _defined_48060 = NOVALUE;
    object _ix_48061 = NOVALUE;
    object _st_ptr_48063 = NOVALUE;
    object _st_builtin_48064 = NOVALUE;
    object _tok_48066 = NOVALUE;
    object _gtok_48067 = NOVALUE;
    object _any_symbol_48070 = NOVALUE;
    object _tok_file_48238 = NOVALUE;
    object _good_48245 = NOVALUE;
    object _include_type_48255 = NOVALUE;
    object _msg_file_48311 = NOVALUE;
    object _25009 = NOVALUE;
    object _25008 = NOVALUE;
    object _25006 = NOVALUE;
    object _25004 = NOVALUE;
    object _25003 = NOVALUE;
    object _25002 = NOVALUE;
    object _25001 = NOVALUE;
    object _25000 = NOVALUE;
    object _24998 = NOVALUE;
    object _24996 = NOVALUE;
    object _24995 = NOVALUE;
    object _24994 = NOVALUE;
    object _24993 = NOVALUE;
    object _24992 = NOVALUE;
    object _24991 = NOVALUE;
    object _24990 = NOVALUE;
    object _24989 = NOVALUE;
    object _24987 = NOVALUE;
    object _24986 = NOVALUE;
    object _24985 = NOVALUE;
    object _24984 = NOVALUE;
    object _24983 = NOVALUE;
    object _24982 = NOVALUE;
    object _24981 = NOVALUE;
    object _24980 = NOVALUE;
    object _24979 = NOVALUE;
    object _24978 = NOVALUE;
    object _24977 = NOVALUE;
    object _24976 = NOVALUE;
    object _24975 = NOVALUE;
    object _24974 = NOVALUE;
    object _24973 = NOVALUE;
    object _24972 = NOVALUE;
    object _24971 = NOVALUE;
    object _24969 = NOVALUE;
    object _24968 = NOVALUE;
    object _24965 = NOVALUE;
    object _24961 = NOVALUE;
    object _24959 = NOVALUE;
    object _24958 = NOVALUE;
    object _24957 = NOVALUE;
    object _24956 = NOVALUE;
    object _24955 = NOVALUE;
    object _24953 = NOVALUE;
    object _24952 = NOVALUE;
    object _24951 = NOVALUE;
    object _24950 = NOVALUE;
    object _24948 = NOVALUE;
    object _24945 = NOVALUE;
    object _24944 = NOVALUE;
    object _24943 = NOVALUE;
    object _24942 = NOVALUE;
    object _24940 = NOVALUE;
    object _24937 = NOVALUE;
    object _24936 = NOVALUE;
    object _24935 = NOVALUE;
    object _24934 = NOVALUE;
    object _24933 = NOVALUE;
    object _24932 = NOVALUE;
    object _24931 = NOVALUE;
    object _24928 = NOVALUE;
    object _24927 = NOVALUE;
    object _24925 = NOVALUE;
    object _24923 = NOVALUE;
    object _24921 = NOVALUE;
    object _24920 = NOVALUE;
    object _24919 = NOVALUE;
    object _24915 = NOVALUE;
    object _24914 = NOVALUE;
    object _24909 = NOVALUE;
    object _24907 = NOVALUE;
    object _24905 = NOVALUE;
    object _24904 = NOVALUE;
    object _24900 = NOVALUE;
    object _24899 = NOVALUE;
    object _24897 = NOVALUE;
    object _24896 = NOVALUE;
    object _24894 = NOVALUE;
    object _24893 = NOVALUE;
    object _24892 = NOVALUE;
    object _24891 = NOVALUE;
    object _24890 = NOVALUE;
    object _24888 = NOVALUE;
    object _24887 = NOVALUE;
    object _24886 = NOVALUE;
    object _24885 = NOVALUE;
    object _24884 = NOVALUE;
    object _24883 = NOVALUE;
    object _24882 = NOVALUE;
    object _24881 = NOVALUE;
    object _24880 = NOVALUE;
    object _24879 = NOVALUE;
    object _24878 = NOVALUE;
    object _24877 = NOVALUE;
    object _24876 = NOVALUE;
    object _24875 = NOVALUE;
    object _24874 = NOVALUE;
    object _24873 = NOVALUE;
    object _24872 = NOVALUE;
    object _24871 = NOVALUE;
    object _24870 = NOVALUE;
    object _24869 = NOVALUE;
    object _24868 = NOVALUE;
    object _24867 = NOVALUE;
    object _24865 = NOVALUE;
    object _24864 = NOVALUE;
    object _24862 = NOVALUE;
    object _24861 = NOVALUE;
    object _24860 = NOVALUE;
    object _24859 = NOVALUE;
    object _24858 = NOVALUE;
    object _24856 = NOVALUE;
    object _24855 = NOVALUE;
    object _24854 = NOVALUE;
    object _24852 = NOVALUE;
    object _24851 = NOVALUE;
    object _24850 = NOVALUE;
    object _24849 = NOVALUE;
    object _24848 = NOVALUE;
    object _24847 = NOVALUE;
    object _24846 = NOVALUE;
    object _24844 = NOVALUE;
    object _24843 = NOVALUE;
    object _24838 = NOVALUE;
    object _24835 = NOVALUE;
    object _24834 = NOVALUE;
    object _24833 = NOVALUE;
    object _24832 = NOVALUE;
    object _24831 = NOVALUE;
    object _24830 = NOVALUE;
    object _24829 = NOVALUE;
    object _24828 = NOVALUE;
    object _24827 = NOVALUE;
    object _24826 = NOVALUE;
    object _24825 = NOVALUE;
    object _24824 = NOVALUE;
    object _24823 = NOVALUE;
    object _24822 = NOVALUE;
    object _24821 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_file_no_48050)) {
        _1 = (object)(DBL_PTR(_file_no_48050)->dbl);
        DeRefDS(_file_no_48050);
        _file_no_48050 = _1;
    }
    if (!IS_ATOM_INT(_hashval_48055)) {
        _1 = (object)(DBL_PTR(_hashval_48055)->dbl);
        DeRefDS(_hashval_48055);
        _hashval_48055 = _1;
    }

    /** symtab.e:750		dup_globals = {}*/
    RefDS(_22024);
    DeRef(_53dup_globals_48035);
    _53dup_globals_48035 = _22024;

    /** symtab.e:751		dup_overrides = {}*/
    RefDS(_22024);
    DeRefi(_53dup_overrides_48036);
    _53dup_overrides_48036 = _22024;

    /** symtab.e:752		in_include_path = {}*/
    RefDS(_22024);
    DeRef(_53in_include_path_48037);
    _53in_include_path_48037 = _22024;

    /** symtab.e:753		symbol_resolution_warning = ""*/
    RefDS(_22024);
    DeRef(_12symbol_resolution_warning_20328);
    _12symbol_resolution_warning_20328 = _22024;

    /** symtab.e:754		st_builtin = 0*/
    _st_builtin_48064 = 0LL;

    /** symtab.e:756		ifdef EUDIS then*/

    /** symtab.e:759		st_ptr = buckets[hashval]*/
    _2 = (object)SEQ_PTR(_53buckets_46842);
    _st_ptr_48063 = (object)*(((s1_ptr)_2)->base + _hashval_48055);
    if (!IS_ATOM_INT(_st_ptr_48063)){
        _st_ptr_48063 = (object)DBL_PTR(_st_ptr_48063)->dbl;
    }

    /** symtab.e:760		integer any_symbol = namespace_ok = -1*/
    _any_symbol_48070 = (_namespace_ok_48054 == -1LL);

    /** symtab.e:761		while st_ptr do*/
L1: 
    if (_st_ptr_48063 == 0)
    {
        goto L2; // [69] 1033
    }
    else{
    }

    /** symtab.e:762			if SymTab[st_ptr][S_SCOPE] != SC_UNDEFINED */
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24821 = (object)*(((s1_ptr)_2)->base + _st_ptr_48063);
    _2 = (object)SEQ_PTR(_24821);
    _24822 = (object)*(((s1_ptr)_2)->base + 4LL);
    _24821 = NOVALUE;
    if (IS_ATOM_INT(_24822)) {
        _24823 = (_24822 != 9LL);
    }
    else {
        _24823 = binary_op(NOTEQ, _24822, 9LL);
    }
    _24822 = NOVALUE;
    if (IS_ATOM_INT(_24823)) {
        if (_24823 == 0) {
            DeRef(_24824);
            _24824 = 0;
            goto L3; // [92] 116
        }
    }
    else {
        if (DBL_PTR(_24823)->dbl == 0.0) {
            DeRef(_24824);
            _24824 = 0;
            goto L3; // [92] 116
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24825 = (object)*(((s1_ptr)_2)->base + _st_ptr_48063);
    _2 = (object)SEQ_PTR(_24825);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _24826 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _24826 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _24825 = NOVALUE;
    if (_word_48049 == _24826)
    _24827 = 1;
    else if (IS_ATOM_INT(_word_48049) && IS_ATOM_INT(_24826))
    _24827 = 0;
    else
    _24827 = (compare(_word_48049, _24826) == 0);
    _24826 = NOVALUE;
    DeRef(_24824);
    _24824 = (_24827 != 0);
L3: 
    if (_24824 == 0) {
        goto L4; // [116] 1012
    }
    if (_any_symbol_48070 != 0) {
        DeRef(_24829);
        _24829 = 1;
        goto L5; // [120] 150
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24830 = (object)*(((s1_ptr)_2)->base + _st_ptr_48063);
    _2 = (object)SEQ_PTR(_24830);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _24831 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _24831 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _24830 = NOVALUE;
    if (IS_ATOM_INT(_24831)) {
        _24832 = (_24831 == 523LL);
    }
    else {
        _24832 = binary_op(EQUALS, _24831, 523LL);
    }
    _24831 = NOVALUE;
    if (IS_ATOM_INT(_24832)) {
        _24833 = (_namespace_ok_48054 == _24832);
    }
    else {
        _24833 = binary_op(EQUALS, _namespace_ok_48054, _24832);
    }
    DeRef(_24832);
    _24832 = NOVALUE;
    if (IS_ATOM_INT(_24833))
    _24829 = (_24833 != 0);
    else
    _24829 = DBL_PTR(_24833)->dbl != 0.0;
L5: 
    if (_24829 == 0)
    {
        _24829 = NOVALUE;
        goto L4; // [151] 1012
    }
    else{
        _24829 = NOVALUE;
    }

    /** symtab.e:767				tok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24834 = (object)*(((s1_ptr)_2)->base + _st_ptr_48063);
    _2 = (object)SEQ_PTR(_24834);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _24835 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _24835 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _24834 = NOVALUE;
    Ref(_24835);
    DeRef(_tok_48066);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24835;
    ((intptr_t *)_2)[2] = _st_ptr_48063;
    _tok_48066 = MAKE_SEQ(_1);
    _24835 = NOVALUE;

    /** symtab.e:769				if file_no = -1 then*/
    if (_file_no_48050 != -1LL)
    goto L6; // [174] 714

    /** symtab.e:774					scope = SymTab[st_ptr][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24838 = (object)*(((s1_ptr)_2)->base + _st_ptr_48063);
    _2 = (object)SEQ_PTR(_24838);
    _scope_48059 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_scope_48059)){
        _scope_48059 = (object)DBL_PTR(_scope_48059)->dbl;
    }
    _24838 = NOVALUE;

    /** symtab.e:776					switch scope with fallthru do*/
    _0 = _scope_48059;
    switch ( _0 ){ 

        /** symtab.e:777					case SC_OVERRIDE then*/
        case 12:

        /** symtab.e:778						dup_overrides &= st_ptr*/
        Append(&_53dup_overrides_48036, _53dup_overrides_48036, _st_ptr_48063);

        /** symtab.e:779						break*/
        goto L7; // [215] 1011

        /** symtab.e:781					case SC_PREDEF then*/
        case 7:

        /** symtab.e:782						st_builtin = st_ptr*/
        _st_builtin_48064 = _st_ptr_48063;

        /** symtab.e:783						break*/
        goto L7; // [230] 1011

        /** symtab.e:784					case SC_GLOBAL then*/
        case 6:

        /** symtab.e:785						if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _24843 = (object)*(((s1_ptr)_2)->base + _st_ptr_48063);
        _2 = (object)SEQ_PTR(_24843);
        if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
            _24844 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
        }
        else{
            _24844 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
        }
        _24843 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_48051, _24844)){
            _24844 = NOVALUE;
            goto L8; // [250] 274
        }
        _24844 = NOVALUE;

        /** symtab.e:788							if BIND then*/
        if (_12BIND_19837 == 0)
        {
            goto L9; // [258] 267
        }
        else{
        }

        /** symtab.e:789								add_ref(tok)*/
        Ref(_tok_48066);
        _53add_ref(_tok_48066);
L9: 

        /** symtab.e:792							return tok*/
        DeRefDS(_word_48049);
        DeRef(_msg_48057);
        DeRef(_b_name_48058);
        DeRef(_gtok_48067);
        DeRef(_24833);
        _24833 = NOVALUE;
        DeRef(_24823);
        _24823 = NOVALUE;
        return _tok_48066;
L8: 

        /** symtab.e:796						if Resolve_unincluded_globals */
        if (_53Resolve_unincluded_globals_48040 != 0) {
            _24846 = 1;
            goto LA; // [278] 322
        }
        _2 = (object)SEQ_PTR(_13finished_files_11319);
        _24847 = (object)*(((s1_ptr)_2)->base + _scanning_file_48051);
        if (_24847 == 0) {
            _24848 = 0;
            goto LB; // [288] 318
        }
        _2 = (object)SEQ_PTR(_13include_matrix_11323);
        _24849 = (object)*(((s1_ptr)_2)->base + _scanning_file_48051);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _24850 = (object)*(((s1_ptr)_2)->base + _st_ptr_48063);
        _2 = (object)SEQ_PTR(_24850);
        if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
            _24851 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
        }
        else{
            _24851 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
        }
        _24850 = NOVALUE;
        _2 = (object)SEQ_PTR(_24849);
        if (!IS_ATOM_INT(_24851)){
            _24852 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24851)->dbl));
        }
        else{
            _24852 = (object)*(((s1_ptr)_2)->base + _24851);
        }
        _24849 = NOVALUE;
        if (IS_ATOM_INT(_24852))
        _24848 = (_24852 != 0);
        else
        _24848 = DBL_PTR(_24852)->dbl != 0.0;
LB: 
        _24846 = (_24848 != 0);
LA: 
        if (_24846 != 0) {
            goto LC; // [322] 349
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _24854 = (object)*(((s1_ptr)_2)->base + _st_ptr_48063);
        _2 = (object)SEQ_PTR(_24854);
        if (!IS_ATOM_INT(_12S_TOKEN_19869)){
            _24855 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
        }
        else{
            _24855 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
        }
        _24854 = NOVALUE;
        if (IS_ATOM_INT(_24855)) {
            _24856 = (_24855 == 523LL);
        }
        else {
            _24856 = binary_op(EQUALS, _24855, 523LL);
        }
        _24855 = NOVALUE;
        if (_24856 == 0) {
            DeRef(_24856);
            _24856 = NOVALUE;
            goto L7; // [345] 1011
        }
        else {
            if (!IS_ATOM_INT(_24856) && DBL_PTR(_24856)->dbl == 0.0){
                DeRef(_24856);
                _24856 = NOVALUE;
                goto L7; // [345] 1011
            }
            DeRef(_24856);
            _24856 = NOVALUE;
        }
        DeRef(_24856);
        _24856 = NOVALUE;
LC: 

        /** symtab.e:800							gtok = tok*/
        Ref(_tok_48066);
        DeRef(_gtok_48067);
        _gtok_48067 = _tok_48066;

        /** symtab.e:801							dup_globals &= st_ptr*/
        Append(&_53dup_globals_48035, _53dup_globals_48035, _st_ptr_48063);

        /** symtab.e:802							in_include_path &= include_matrix[scanning_file][SymTab[st_ptr][S_FILE_NO]] != 0*/
        _2 = (object)SEQ_PTR(_13include_matrix_11323);
        _24858 = (object)*(((s1_ptr)_2)->base + _scanning_file_48051);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _24859 = (object)*(((s1_ptr)_2)->base + _st_ptr_48063);
        _2 = (object)SEQ_PTR(_24859);
        if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
            _24860 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
        }
        else{
            _24860 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
        }
        _24859 = NOVALUE;
        _2 = (object)SEQ_PTR(_24858);
        if (!IS_ATOM_INT(_24860)){
            _24861 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24860)->dbl));
        }
        else{
            _24861 = (object)*(((s1_ptr)_2)->base + _24860);
        }
        _24858 = NOVALUE;
        if (IS_ATOM_INT(_24861)) {
            _24862 = (_24861 != 0LL);
        }
        else {
            _24862 = binary_op(NOTEQ, _24861, 0LL);
        }
        _24861 = NOVALUE;
        if (IS_SEQUENCE(_53in_include_path_48037) && IS_ATOM(_24862)) {
            Ref(_24862);
            Append(&_53in_include_path_48037, _53in_include_path_48037, _24862);
        }
        else if (IS_ATOM(_53in_include_path_48037) && IS_SEQUENCE(_24862)) {
        }
        else {
            Concat((object_ptr)&_53in_include_path_48037, _53in_include_path_48037, _24862);
        }
        DeRef(_24862);
        _24862 = NOVALUE;

        /** symtab.e:804						break*/
        goto L7; // [399] 1011

        /** symtab.e:807					case SC_PUBLIC, SC_EXPORT then*/
        case 13:
        case 11:

        /** symtab.e:809						if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _24864 = (object)*(((s1_ptr)_2)->base + _st_ptr_48063);
        _2 = (object)SEQ_PTR(_24864);
        if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
            _24865 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
        }
        else{
            _24865 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
        }
        _24864 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_48051, _24865)){
            _24865 = NOVALUE;
            goto LD; // [421] 445
        }
        _24865 = NOVALUE;

        /** symtab.e:811							if BIND then*/
        if (_12BIND_19837 == 0)
        {
            goto LE; // [429] 438
        }
        else{
        }

        /** symtab.e:812								add_ref(tok)*/
        Ref(_tok_48066);
        _53add_ref(_tok_48066);
LE: 

        /** symtab.e:815							return tok*/
        DeRefDS(_word_48049);
        DeRef(_msg_48057);
        DeRef(_b_name_48058);
        DeRef(_gtok_48067);
        DeRef(_24833);
        _24833 = NOVALUE;
        _24851 = NOVALUE;
        _24852 = NOVALUE;
        DeRef(_24823);
        _24823 = NOVALUE;
        _24860 = NOVALUE;
        _24847 = NOVALUE;
        return _tok_48066;
LD: 

        /** symtab.e:818						if (finished_files[scanning_file] -- everything this file needs has been read in*/
        _2 = (object)SEQ_PTR(_13finished_files_11319);
        _24867 = (object)*(((s1_ptr)_2)->base + _scanning_file_48051);
        if (_24867 != 0) {
            _24868 = 1;
            goto LF; // [453] 487
        }
        if (_namespace_ok_48054 == 0) {
            _24869 = 0;
            goto L10; // [457] 483
        }
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _24870 = (object)*(((s1_ptr)_2)->base + _st_ptr_48063);
        _2 = (object)SEQ_PTR(_24870);
        if (!IS_ATOM_INT(_12S_TOKEN_19869)){
            _24871 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
        }
        else{
            _24871 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
        }
        _24870 = NOVALUE;
        if (IS_ATOM_INT(_24871)) {
            _24872 = (_24871 == 523LL);
        }
        else {
            _24872 = binary_op(EQUALS, _24871, 523LL);
        }
        _24871 = NOVALUE;
        if (IS_ATOM_INT(_24872))
        _24869 = (_24872 != 0);
        else
        _24869 = DBL_PTR(_24872)->dbl != 0.0;
L10: 
        _24868 = (_24869 != 0);
LF: 
        if (_24868 == 0) {
            goto L7; // [487] 1011
        }
        _24874 = (_scope_48059 == 13LL);
        if (_24874 == 0) {
            _24875 = 0;
            goto L11; // [497] 533
        }
        _2 = (object)SEQ_PTR(_13include_matrix_11323);
        _24876 = (object)*(((s1_ptr)_2)->base + _scanning_file_48051);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _24877 = (object)*(((s1_ptr)_2)->base + _st_ptr_48063);
        _2 = (object)SEQ_PTR(_24877);
        if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
            _24878 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
        }
        else{
            _24878 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
        }
        _24877 = NOVALUE;
        _2 = (object)SEQ_PTR(_24876);
        if (!IS_ATOM_INT(_24878)){
            _24879 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24878)->dbl));
        }
        else{
            _24879 = (object)*(((s1_ptr)_2)->base + _24878);
        }
        _24876 = NOVALUE;
        if (IS_ATOM_INT(_24879)) {
            {uintptr_t tu;
                 tu = (uintptr_t)6LL & (uintptr_t)_24879;
                 _24880 = MAKE_UINT(tu);
            }
        }
        else {
            _24880 = binary_op(AND_BITS, 6LL, _24879);
        }
        _24879 = NOVALUE;
        if (IS_ATOM_INT(_24880))
        _24875 = (_24880 != 0);
        else
        _24875 = DBL_PTR(_24880)->dbl != 0.0;
L11: 
        if (_24875 != 0) {
            DeRef(_24881);
            _24881 = 1;
            goto L12; // [533] 583
        }
        _24882 = (_scope_48059 == 11LL);
        if (_24882 == 0) {
            _24883 = 0;
            goto L13; // [543] 579
        }
        _2 = (object)SEQ_PTR(_13include_matrix_11323);
        _24884 = (object)*(((s1_ptr)_2)->base + _scanning_file_48051);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _24885 = (object)*(((s1_ptr)_2)->base + _st_ptr_48063);
        _2 = (object)SEQ_PTR(_24885);
        if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
            _24886 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
        }
        else{
            _24886 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
        }
        _24885 = NOVALUE;
        _2 = (object)SEQ_PTR(_24884);
        if (!IS_ATOM_INT(_24886)){
            _24887 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24886)->dbl));
        }
        else{
            _24887 = (object)*(((s1_ptr)_2)->base + _24886);
        }
        _24884 = NOVALUE;
        if (IS_ATOM_INT(_24887)) {
            {uintptr_t tu;
                 tu = (uintptr_t)2LL & (uintptr_t)_24887;
                 _24888 = MAKE_UINT(tu);
            }
        }
        else {
            _24888 = binary_op(AND_BITS, 2LL, _24887);
        }
        _24887 = NOVALUE;
        if (IS_ATOM_INT(_24888))
        _24883 = (_24888 != 0);
        else
        _24883 = DBL_PTR(_24888)->dbl != 0.0;
L13: 
        DeRef(_24881);
        _24881 = (_24883 != 0);
L12: 
        if (_24881 == 0)
        {
            _24881 = NOVALUE;
            goto L7; // [584] 1011
        }
        else{
            _24881 = NOVALUE;
        }

        /** symtab.e:826							gtok = tok*/
        Ref(_tok_48066);
        DeRef(_gtok_48067);
        _gtok_48067 = _tok_48066;

        /** symtab.e:827							dup_globals &= st_ptr*/
        Append(&_53dup_globals_48035, _53dup_globals_48035, _st_ptr_48063);

        /** symtab.e:828							in_include_path &= include_matrix[scanning_file][SymTab[st_ptr][S_FILE_NO]] != 0 --symbol_in_include_path( st_ptr, scanning_file, {} )*/
        _2 = (object)SEQ_PTR(_13include_matrix_11323);
        _24890 = (object)*(((s1_ptr)_2)->base + _scanning_file_48051);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _24891 = (object)*(((s1_ptr)_2)->base + _st_ptr_48063);
        _2 = (object)SEQ_PTR(_24891);
        if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
            _24892 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
        }
        else{
            _24892 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
        }
        _24891 = NOVALUE;
        _2 = (object)SEQ_PTR(_24890);
        if (!IS_ATOM_INT(_24892)){
            _24893 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24892)->dbl));
        }
        else{
            _24893 = (object)*(((s1_ptr)_2)->base + _24892);
        }
        _24890 = NOVALUE;
        if (IS_ATOM_INT(_24893)) {
            _24894 = (_24893 != 0LL);
        }
        else {
            _24894 = binary_op(NOTEQ, _24893, 0LL);
        }
        _24893 = NOVALUE;
        if (IS_SEQUENCE(_53in_include_path_48037) && IS_ATOM(_24894)) {
            Ref(_24894);
            Append(&_53in_include_path_48037, _53in_include_path_48037, _24894);
        }
        else if (IS_ATOM(_53in_include_path_48037) && IS_SEQUENCE(_24894)) {
        }
        else {
            Concat((object_ptr)&_53in_include_path_48037, _53in_include_path_48037, _24894);
        }
        DeRef(_24894);
        _24894 = NOVALUE;

        /** symtab.e:831	ifdef STDDEBUG then*/

        /** symtab.e:852						break*/
        goto L7; // [639] 1011

        /** symtab.e:853					case SC_LOCAL then*/
        case 5:

        /** symtab.e:854						if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _24896 = (object)*(((s1_ptr)_2)->base + _st_ptr_48063);
        _2 = (object)SEQ_PTR(_24896);
        if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
            _24897 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
        }
        else{
            _24897 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
        }
        _24896 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_48051, _24897)){
            _24897 = NOVALUE;
            goto L7; // [659] 1011
        }
        _24897 = NOVALUE;

        /** symtab.e:857							if BIND then*/
        if (_12BIND_19837 == 0)
        {
            goto L14; // [667] 676
        }
        else{
        }

        /** symtab.e:858								add_ref(tok)*/
        Ref(_tok_48066);
        _53add_ref(_tok_48066);
L14: 

        /** symtab.e:861							return tok*/
        DeRefDS(_word_48049);
        DeRef(_msg_48057);
        DeRef(_b_name_48058);
        DeRef(_gtok_48067);
        _24892 = NOVALUE;
        DeRef(_24882);
        _24882 = NOVALUE;
        DeRef(_24833);
        _24833 = NOVALUE;
        _24851 = NOVALUE;
        _24852 = NOVALUE;
        DeRef(_24823);
        _24823 = NOVALUE;
        DeRef(_24888);
        _24888 = NOVALUE;
        _24878 = NOVALUE;
        _24860 = NOVALUE;
        DeRef(_24880);
        _24880 = NOVALUE;
        _24886 = NOVALUE;
        DeRef(_24874);
        _24874 = NOVALUE;
        DeRef(_24872);
        _24872 = NOVALUE;
        _24867 = NOVALUE;
        _24847 = NOVALUE;
        return _tok_48066;

        /** symtab.e:863						break*/
        goto L7; // [685] 1011

        /** symtab.e:864					case else*/
        default:

        /** symtab.e:866						if BIND then*/
        if (_12BIND_19837 == 0)
        {
            goto L15; // [695] 704
        }
        else{
        }

        /** symtab.e:867							add_ref(tok)*/
        Ref(_tok_48066);
        _53add_ref(_tok_48066);
L15: 

        /** symtab.e:870						return tok -- keyword, private*/
        DeRefDS(_word_48049);
        DeRef(_msg_48057);
        DeRef(_b_name_48058);
        DeRef(_gtok_48067);
        _24892 = NOVALUE;
        DeRef(_24882);
        _24882 = NOVALUE;
        DeRef(_24833);
        _24833 = NOVALUE;
        _24851 = NOVALUE;
        _24852 = NOVALUE;
        DeRef(_24823);
        _24823 = NOVALUE;
        DeRef(_24888);
        _24888 = NOVALUE;
        _24878 = NOVALUE;
        _24860 = NOVALUE;
        DeRef(_24880);
        _24880 = NOVALUE;
        _24886 = NOVALUE;
        DeRef(_24874);
        _24874 = NOVALUE;
        DeRef(_24872);
        _24872 = NOVALUE;
        _24867 = NOVALUE;
        _24847 = NOVALUE;
        return _tok_48066;
    ;}    goto L7; // [711] 1011
L6: 

    /** symtab.e:877					scope = SymTab[tok[T_SYM]][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_tok_48066);
    _24899 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_24899)){
        _24900 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24899)->dbl));
    }
    else{
        _24900 = (object)*(((s1_ptr)_2)->base + _24899);
    }
    _2 = (object)SEQ_PTR(_24900);
    _scope_48059 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_scope_48059)){
        _scope_48059 = (object)DBL_PTR(_scope_48059)->dbl;
    }
    _24900 = NOVALUE;

    /** symtab.e:878					if not file_no then*/
    if (_file_no_48050 != 0)
    goto L16; // [738] 772

    /** symtab.e:880						if scope = SC_PREDEF then*/
    if (_scope_48059 != 7LL)
    goto L17; // [745] 1010

    /** symtab.e:881							if BIND then*/
    if (_12BIND_19837 == 0)
    {
        goto L18; // [753] 762
    }
    else{
    }

    /** symtab.e:882								add_ref( tok )*/
    Ref(_tok_48066);
    _53add_ref(_tok_48066);
L18: 

    /** symtab.e:884							return tok*/
    DeRefDS(_word_48049);
    DeRef(_msg_48057);
    DeRef(_b_name_48058);
    DeRef(_gtok_48067);
    _24899 = NOVALUE;
    _24892 = NOVALUE;
    DeRef(_24882);
    _24882 = NOVALUE;
    DeRef(_24833);
    _24833 = NOVALUE;
    _24851 = NOVALUE;
    _24852 = NOVALUE;
    DeRef(_24823);
    _24823 = NOVALUE;
    DeRef(_24888);
    _24888 = NOVALUE;
    _24878 = NOVALUE;
    _24860 = NOVALUE;
    DeRef(_24880);
    _24880 = NOVALUE;
    _24886 = NOVALUE;
    DeRef(_24874);
    _24874 = NOVALUE;
    DeRef(_24872);
    _24872 = NOVALUE;
    _24867 = NOVALUE;
    _24847 = NOVALUE;
    return _tok_48066;
    goto L17; // [769] 1010
L16: 

    /** symtab.e:887						integer tok_file = SymTab[tok[T_SYM]][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_tok_48066);
    _24904 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_24904)){
        _24905 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24904)->dbl));
    }
    else{
        _24905 = (object)*(((s1_ptr)_2)->base + _24904);
    }
    _2 = (object)SEQ_PTR(_24905);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _tok_file_48238 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _tok_file_48238 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    if (!IS_ATOM_INT(_tok_file_48238)){
        _tok_file_48238 = (object)DBL_PTR(_tok_file_48238)->dbl;
    }
    _24905 = NOVALUE;

    /** symtab.e:888						integer good = 0*/
    _good_48245 = 0LL;

    /** symtab.e:889						if scope = SC_PRIVATE or scope = SC_PREDEF then*/
    _24907 = (_scope_48059 == 3LL);
    if (_24907 != 0) {
        goto L19; // [807] 940
    }
    _24909 = (_scope_48059 == 7LL);
    if (_24909 == 0)
    {
        DeRef(_24909);
        _24909 = NOVALUE;
        goto L1A; // [818] 825
    }
    else{
        DeRef(_24909);
        _24909 = NOVALUE;
    }
    goto L19; // [822] 940
L1A: 

    /** symtab.e:892						elsif file_no = tok_file then*/
    if (_file_no_48050 != _tok_file_48238)
    goto L1B; // [827] 839

    /** symtab.e:893							good = 1*/
    _good_48245 = 1LL;
    goto L19; // [836] 940
L1B: 

    /** symtab.e:896							integer include_type = 0*/
    _include_type_48255 = 0LL;

    /** symtab.e:897							switch scope do*/
    _0 = _scope_48059;
    switch ( _0 ){ 

        /** symtab.e:898								case SC_GLOBAL then*/
        case 6:

        /** symtab.e:899									if Resolve_unincluded_globals then*/
        if (_53Resolve_unincluded_globals_48040 == 0)
        {
            goto L1C; // [859] 874
        }
        else{
        }

        /** symtab.e:900										include_type = ANY_INCLUDE*/
        _include_type_48255 = 7LL;
        goto L1D; // [871] 919
L1C: 

        /** symtab.e:902										include_type = DIRECT_OR_PUBLIC_INCLUDE*/
        _include_type_48255 = 6LL;
        goto L1D; // [884] 919

        /** symtab.e:905								case SC_PUBLIC then*/
        case 13:

        /** symtab.e:907									if tok_file != file_no then*/
        if (_tok_file_48238 == _file_no_48050)
        goto L1E; // [892] 908

        /** symtab.e:908										include_type = PUBLIC_INCLUDE*/
        _include_type_48255 = 4LL;
        goto L1F; // [905] 918
L1E: 

        /** symtab.e:910										include_type = DIRECT_OR_PUBLIC_INCLUDE*/
        _include_type_48255 = 6LL;
L1F: 
    ;}L1D: 

    /** symtab.e:914							good = and_bits( include_type, include_matrix[file_no][tok_file] )*/
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _24914 = (object)*(((s1_ptr)_2)->base + _file_no_48050);
    _2 = (object)SEQ_PTR(_24914);
    _24915 = (object)*(((s1_ptr)_2)->base + _tok_file_48238);
    _24914 = NOVALUE;
    if (IS_ATOM_INT(_24915)) {
        {uintptr_t tu;
             tu = (uintptr_t)_include_type_48255 & (uintptr_t)_24915;
             _good_48245 = MAKE_UINT(tu);
        }
    }
    else {
        _good_48245 = binary_op(AND_BITS, _include_type_48255, _24915);
    }
    _24915 = NOVALUE;
    if (!IS_ATOM_INT(_good_48245)) {
        _1 = (object)(DBL_PTR(_good_48245)->dbl);
        DeRefDS(_good_48245);
        _good_48245 = _1;
    }
L19: 

    /** symtab.e:917						if good then*/
    if (_good_48245 == 0)
    {
        goto L20; // [942] 1007
    }
    else{
    }

    /** symtab.e:919							if file_no = tok_file then*/
    if (_file_no_48050 != _tok_file_48238)
    goto L21; // [947] 971

    /** symtab.e:920								if BIND then*/
    if (_12BIND_19837 == 0)
    {
        goto L22; // [955] 964
    }
    else{
    }

    /** symtab.e:921									add_ref(tok)*/
    Ref(_tok_48066);
    _53add_ref(_tok_48066);
L22: 

    /** symtab.e:923								return tok*/
    DeRefDS(_word_48049);
    DeRef(_msg_48057);
    DeRef(_b_name_48058);
    DeRef(_gtok_48067);
    _24899 = NOVALUE;
    DeRef(_24907);
    _24907 = NOVALUE;
    _24904 = NOVALUE;
    _24892 = NOVALUE;
    DeRef(_24882);
    _24882 = NOVALUE;
    DeRef(_24833);
    _24833 = NOVALUE;
    _24851 = NOVALUE;
    _24852 = NOVALUE;
    DeRef(_24823);
    _24823 = NOVALUE;
    DeRef(_24888);
    _24888 = NOVALUE;
    _24878 = NOVALUE;
    _24860 = NOVALUE;
    DeRef(_24880);
    _24880 = NOVALUE;
    _24886 = NOVALUE;
    DeRef(_24874);
    _24874 = NOVALUE;
    DeRef(_24872);
    _24872 = NOVALUE;
    _24867 = NOVALUE;
    _24847 = NOVALUE;
    return _tok_48066;
L21: 

    /** symtab.e:926							gtok = tok*/
    Ref(_tok_48066);
    DeRef(_gtok_48067);
    _gtok_48067 = _tok_48066;

    /** symtab.e:927							dup_globals &= st_ptr*/
    Append(&_53dup_globals_48035, _53dup_globals_48035, _st_ptr_48063);

    /** symtab.e:928							in_include_path &= include_matrix[scanning_file][tok_file] != 0*/
    _2 = (object)SEQ_PTR(_13include_matrix_11323);
    _24919 = (object)*(((s1_ptr)_2)->base + _scanning_file_48051);
    _2 = (object)SEQ_PTR(_24919);
    _24920 = (object)*(((s1_ptr)_2)->base + _tok_file_48238);
    _24919 = NOVALUE;
    if (IS_ATOM_INT(_24920)) {
        _24921 = (_24920 != 0LL);
    }
    else {
        _24921 = binary_op(NOTEQ, _24920, 0LL);
    }
    _24920 = NOVALUE;
    if (IS_SEQUENCE(_53in_include_path_48037) && IS_ATOM(_24921)) {
        Ref(_24921);
        Append(&_53in_include_path_48037, _53in_include_path_48037, _24921);
    }
    else if (IS_ATOM(_53in_include_path_48037) && IS_SEQUENCE(_24921)) {
    }
    else {
        Concat((object_ptr)&_53in_include_path_48037, _53in_include_path_48037, _24921);
    }
    DeRef(_24921);
    _24921 = NOVALUE;
L20: 
L17: 
L7: 
L4: 

    /** symtab.e:936			st_ptr = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24923 = (object)*(((s1_ptr)_2)->base + _st_ptr_48063);
    _2 = (object)SEQ_PTR(_24923);
    _st_ptr_48063 = (object)*(((s1_ptr)_2)->base + 9LL);
    if (!IS_ATOM_INT(_st_ptr_48063)){
        _st_ptr_48063 = (object)DBL_PTR(_st_ptr_48063)->dbl;
    }
    _24923 = NOVALUE;

    /** symtab.e:937		end while*/
    goto L1; // [1030] 69
L2: 

    /** symtab.e:939		if length(dup_overrides) then*/
    if (IS_SEQUENCE(_53dup_overrides_48036)){
            _24925 = SEQ_PTR(_53dup_overrides_48036)->length;
    }
    else {
        _24925 = 1;
    }
    if (_24925 == 0)
    {
        _24925 = NOVALUE;
        goto L23; // [1040] 1093
    }
    else{
        _24925 = NOVALUE;
    }

    /** symtab.e:940			st_ptr = dup_overrides[1]*/
    _2 = (object)SEQ_PTR(_53dup_overrides_48036);
    _st_ptr_48063 = (object)*(((s1_ptr)_2)->base + 1LL);

    /** symtab.e:941			tok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24927 = (object)*(((s1_ptr)_2)->base + _st_ptr_48063);
    _2 = (object)SEQ_PTR(_24927);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _24928 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _24928 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _24927 = NOVALUE;
    Ref(_24928);
    DeRef(_tok_48066);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24928;
    ((intptr_t *)_2)[2] = _st_ptr_48063;
    _tok_48066 = MAKE_SEQ(_1);
    _24928 = NOVALUE;

    /** symtab.e:944				if BIND then*/
    if (_12BIND_19837 == 0)
    {
        goto L24; // [1075] 1084
    }
    else{
    }

    /** symtab.e:945					add_ref(tok)*/
    RefDS(_tok_48066);
    _53add_ref(_tok_48066);
L24: 

    /** symtab.e:948				return tok*/
    DeRefDS(_word_48049);
    DeRef(_msg_48057);
    DeRef(_b_name_48058);
    DeRef(_gtok_48067);
    _24899 = NOVALUE;
    DeRef(_24907);
    _24907 = NOVALUE;
    _24904 = NOVALUE;
    _24892 = NOVALUE;
    DeRef(_24882);
    _24882 = NOVALUE;
    DeRef(_24833);
    _24833 = NOVALUE;
    _24851 = NOVALUE;
    _24852 = NOVALUE;
    DeRef(_24823);
    _24823 = NOVALUE;
    DeRef(_24888);
    _24888 = NOVALUE;
    _24878 = NOVALUE;
    _24860 = NOVALUE;
    DeRef(_24880);
    _24880 = NOVALUE;
    _24886 = NOVALUE;
    DeRef(_24874);
    _24874 = NOVALUE;
    DeRef(_24872);
    _24872 = NOVALUE;
    _24867 = NOVALUE;
    _24847 = NOVALUE;
    return _tok_48066;
    goto L25; // [1090] 1320
L23: 

    /** symtab.e:951		elsif st_builtin != 0 then*/
    if (_st_builtin_48064 == 0LL)
    goto L26; // [1095] 1319

    /** symtab.e:952			if length(dup_globals) and find(SymTab[st_builtin][S_NAME], builtin_warnings) = 0 then*/
    if (IS_SEQUENCE(_53dup_globals_48035)){
            _24931 = SEQ_PTR(_53dup_globals_48035)->length;
    }
    else {
        _24931 = 1;
    }
    if (_24931 == 0) {
        goto L27; // [1106] 1279
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24933 = (object)*(((s1_ptr)_2)->base + _st_builtin_48064);
    _2 = (object)SEQ_PTR(_24933);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _24934 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _24934 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _24933 = NOVALUE;
    _24935 = find_from(_24934, _53builtin_warnings_48039, 1LL);
    _24934 = NOVALUE;
    _24936 = (_24935 == 0LL);
    _24935 = NOVALUE;
    if (_24936 == 0)
    {
        DeRef(_24936);
        _24936 = NOVALUE;
        goto L27; // [1134] 1279
    }
    else{
        DeRef(_24936);
        _24936 = NOVALUE;
    }

    /** symtab.e:953				sequence msg_file */

    /** symtab.e:955				b_name = SymTab[st_builtin][S_NAME]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24937 = (object)*(((s1_ptr)_2)->base + _st_builtin_48064);
    DeRef(_b_name_48058);
    _2 = (object)SEQ_PTR(_24937);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _b_name_48058 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _b_name_48058 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    Ref(_b_name_48058);
    _24937 = NOVALUE;

    /** symtab.e:956				builtin_warnings = append(builtin_warnings, b_name)*/
    RefDS(_b_name_48058);
    Append(&_53builtin_warnings_48039, _53builtin_warnings_48039, _b_name_48058);

    /** symtab.e:958				if length(dup_globals) > 1 then*/
    if (IS_SEQUENCE(_53dup_globals_48035)){
            _24940 = SEQ_PTR(_53dup_globals_48035)->length;
    }
    else {
        _24940 = 1;
    }
    if (_24940 <= 1LL)
    goto L28; // [1170] 1184

    /** symtab.e:959					msg = "\n"*/
    RefDS(_22231);
    DeRef(_msg_48057);
    _msg_48057 = _22231;
    goto L29; // [1181] 1192
L28: 

    /** symtab.e:961					msg = ""*/
    RefDS(_22024);
    DeRef(_msg_48057);
    _msg_48057 = _22024;
L29: 

    /** symtab.e:964				for i = 1 to length(dup_globals) do*/
    if (IS_SEQUENCE(_53dup_globals_48035)){
            _24942 = SEQ_PTR(_53dup_globals_48035)->length;
    }
    else {
        _24942 = 1;
    }
    {
        object _i_48322;
        _i_48322 = 1LL;
L2A: 
        if (_i_48322 > _24942){
            goto L2B; // [1199] 1255
        }

        /** symtab.e:965					msg_file = known_files[SymTab[dup_globals[i]][S_FILE_NO]]*/
        _2 = (object)SEQ_PTR(_53dup_globals_48035);
        _24943 = (object)*(((s1_ptr)_2)->base + _i_48322);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!IS_ATOM_INT(_24943)){
            _24944 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24943)->dbl));
        }
        else{
            _24944 = (object)*(((s1_ptr)_2)->base + _24943);
        }
        _2 = (object)SEQ_PTR(_24944);
        if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
            _24945 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
        }
        else{
            _24945 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
        }
        _24944 = NOVALUE;
        DeRef(_msg_file_48311);
        _2 = (object)SEQ_PTR(_13known_files_11317);
        if (!IS_ATOM_INT(_24945)){
            _msg_file_48311 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24945)->dbl));
        }
        else{
            _msg_file_48311 = (object)*(((s1_ptr)_2)->base + _24945);
        }
        Ref(_msg_file_48311);

        /** symtab.e:966					msg &= "    " & msg_file & "\n"*/
        {
            object concat_list[3];

            concat_list[0] = _22231;
            concat_list[1] = _msg_file_48311;
            concat_list[2] = _24947;
            Concat_N((object_ptr)&_24948, concat_list, 3);
        }
        Concat((object_ptr)&_msg_48057, _msg_48057, _24948);
        DeRefDS(_24948);
        _24948 = NOVALUE;

        /** symtab.e:967				end for*/
        _i_48322 = _i_48322 + 1LL;
        goto L2A; // [1250] 1206
L2B: 
        ;
    }

    /** symtab.e:969				Warning(234, builtin_chosen_warning_flag, {b_name, known_files[scanning_file], msg})*/
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _24950 = (object)*(((s1_ptr)_2)->base + _scanning_file_48051);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_b_name_48058);
    ((intptr_t*)_2)[1] = _b_name_48058;
    Ref(_24950);
    ((intptr_t*)_2)[2] = _24950;
    RefDS(_msg_48057);
    ((intptr_t*)_2)[3] = _msg_48057;
    _24951 = MAKE_SEQ(_1);
    _24950 = NOVALUE;
    _49Warning(234LL, 8LL, _24951);
    _24951 = NOVALUE;
L27: 
    DeRef(_msg_file_48311);
    _msg_file_48311 = NOVALUE;

    /** symtab.e:972			tok = {SymTab[st_builtin][S_TOKEN], st_builtin}*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24952 = (object)*(((s1_ptr)_2)->base + _st_builtin_48064);
    _2 = (object)SEQ_PTR(_24952);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _24953 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _24953 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _24952 = NOVALUE;
    Ref(_24953);
    DeRef(_tok_48066);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24953;
    ((intptr_t *)_2)[2] = _st_builtin_48064;
    _tok_48066 = MAKE_SEQ(_1);
    _24953 = NOVALUE;

    /** symtab.e:974			if BIND then*/
    if (_12BIND_19837 == 0)
    {
        goto L2C; // [1303] 1312
    }
    else{
    }

    /** symtab.e:975				add_ref(tok)*/
    RefDS(_tok_48066);
    _53add_ref(_tok_48066);
L2C: 

    /** symtab.e:978			return tok*/
    DeRefDS(_word_48049);
    DeRef(_msg_48057);
    DeRef(_b_name_48058);
    DeRef(_gtok_48067);
    _24899 = NOVALUE;
    DeRef(_24907);
    _24907 = NOVALUE;
    _24904 = NOVALUE;
    _24892 = NOVALUE;
    DeRef(_24882);
    _24882 = NOVALUE;
    _24945 = NOVALUE;
    DeRef(_24833);
    _24833 = NOVALUE;
    _24851 = NOVALUE;
    _24852 = NOVALUE;
    DeRef(_24823);
    _24823 = NOVALUE;
    DeRef(_24888);
    _24888 = NOVALUE;
    _24878 = NOVALUE;
    _24860 = NOVALUE;
    DeRef(_24880);
    _24880 = NOVALUE;
    _24886 = NOVALUE;
    DeRef(_24874);
    _24874 = NOVALUE;
    DeRef(_24872);
    _24872 = NOVALUE;
    _24867 = NOVALUE;
    _24943 = NOVALUE;
    _24847 = NOVALUE;
    return _tok_48066;
L26: 
L25: 

    /** symtab.e:981	ifdef STDDEBUG then*/

    /** symtab.e:996		if length(dup_globals) > 1 and find( 1, in_include_path ) then*/
    if (IS_SEQUENCE(_53dup_globals_48035)){
            _24955 = SEQ_PTR(_53dup_globals_48035)->length;
    }
    else {
        _24955 = 1;
    }
    _24956 = (_24955 > 1LL);
    _24955 = NOVALUE;
    if (_24956 == 0) {
        goto L2D; // [1333] 1452
    }
    _24958 = find_from(1LL, _53in_include_path_48037, 1LL);
    if (_24958 == 0)
    {
        _24958 = NOVALUE;
        goto L2D; // [1345] 1452
    }
    else{
        _24958 = NOVALUE;
    }

    /** symtab.e:998			ix = 1*/
    _ix_48061 = 1LL;

    /** symtab.e:999			while ix <= length(dup_globals) do*/
L2E: 
    if (IS_SEQUENCE(_53dup_globals_48035)){
            _24959 = SEQ_PTR(_53dup_globals_48035)->length;
    }
    else {
        _24959 = 1;
    }
    if (_ix_48061 > _24959)
    goto L2F; // [1363] 1411

    /** symtab.e:1000				if in_include_path[ix] then*/
    _2 = (object)SEQ_PTR(_53in_include_path_48037);
    _24961 = (object)*(((s1_ptr)_2)->base + _ix_48061);
    if (_24961 == 0) {
        _24961 = NOVALUE;
        goto L30; // [1375] 1387
    }
    else {
        if (!IS_ATOM_INT(_24961) && DBL_PTR(_24961)->dbl == 0.0){
            _24961 = NOVALUE;
            goto L30; // [1375] 1387
        }
        _24961 = NOVALUE;
    }
    _24961 = NOVALUE;

    /** symtab.e:1001					ix += 1*/
    _ix_48061 = _ix_48061 + 1;
    goto L2E; // [1384] 1358
L30: 

    /** symtab.e:1003					dup_globals     = remove( dup_globals, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_53dup_globals_48035);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_48061)) ? _ix_48061 : (object)(DBL_PTR(_ix_48061)->dbl);
        int stop = (IS_ATOM_INT(_ix_48061)) ? _ix_48061 : (object)(DBL_PTR(_ix_48061)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_53dup_globals_48035), start, &_53dup_globals_48035 );
            }
            else Tail(SEQ_PTR(_53dup_globals_48035), stop+1, &_53dup_globals_48035);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_53dup_globals_48035), start, &_53dup_globals_48035);
        }
        else {
            assign_slice_seq = &assign_space;
            _53dup_globals_48035 = Remove_elements(start, stop, (SEQ_PTR(_53dup_globals_48035)->ref == 1));
        }
    }

    /** symtab.e:1004					in_include_path = remove( in_include_path, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_53in_include_path_48037);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_48061)) ? _ix_48061 : (object)(DBL_PTR(_ix_48061)->dbl);
        int stop = (IS_ATOM_INT(_ix_48061)) ? _ix_48061 : (object)(DBL_PTR(_ix_48061)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_53in_include_path_48037), start, &_53in_include_path_48037 );
            }
            else Tail(SEQ_PTR(_53in_include_path_48037), stop+1, &_53in_include_path_48037);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_53in_include_path_48037), start, &_53in_include_path_48037);
        }
        else {
            assign_slice_seq = &assign_space;
            _53in_include_path_48037 = Remove_elements(start, stop, (SEQ_PTR(_53in_include_path_48037)->ref == 1));
        }
    }

    /** symtab.e:1006			end while*/
    goto L2E; // [1408] 1358
L2F: 

    /** symtab.e:1008			if length(dup_globals) = 1 then*/
    if (IS_SEQUENCE(_53dup_globals_48035)){
            _24965 = SEQ_PTR(_53dup_globals_48035)->length;
    }
    else {
        _24965 = 1;
    }
    if (_24965 != 1LL)
    goto L31; // [1418] 1451

    /** symtab.e:1009					st_ptr = dup_globals[1]*/
    _2 = (object)SEQ_PTR(_53dup_globals_48035);
    _st_ptr_48063 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_st_ptr_48063)){
        _st_ptr_48063 = (object)DBL_PTR(_st_ptr_48063)->dbl;
    }

    /** symtab.e:1010					gtok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _24968 = (object)*(((s1_ptr)_2)->base + _st_ptr_48063);
    _2 = (object)SEQ_PTR(_24968);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _24969 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _24969 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _24968 = NOVALUE;
    Ref(_24969);
    DeRef(_gtok_48067);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24969;
    ((intptr_t *)_2)[2] = _st_ptr_48063;
    _gtok_48067 = MAKE_SEQ(_1);
    _24969 = NOVALUE;
L31: 
L2D: 

    /** symtab.e:1014	ifdef STDDEBUG then*/

    /** symtab.e:1023		if length(dup_globals) = 1 and st_builtin = 0 then*/
    if (IS_SEQUENCE(_53dup_globals_48035)){
            _24971 = SEQ_PTR(_53dup_globals_48035)->length;
    }
    else {
        _24971 = 1;
    }
    _24972 = (_24971 == 1LL);
    _24971 = NOVALUE;
    if (_24972 == 0) {
        goto L32; // [1465] 1644
    }
    _24974 = (_st_builtin_48064 == 0LL);
    if (_24974 == 0)
    {
        DeRef(_24974);
        _24974 = NOVALUE;
        goto L32; // [1474] 1644
    }
    else{
        DeRef(_24974);
        _24974 = NOVALUE;
    }

    /** symtab.e:1026			if BIND then*/
    if (_12BIND_19837 == 0)
    {
        goto L33; // [1481] 1492
    }
    else{
    }

    /** symtab.e:1027				add_ref(gtok)*/
    Ref(_gtok_48067);
    _53add_ref(_gtok_48067);
L33: 

    /** symtab.e:1029			if not in_include_path[1] and*/
    _2 = (object)SEQ_PTR(_53in_include_path_48037);
    _24975 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_24975)) {
        _24976 = (_24975 == 0);
    }
    else {
        _24976 = unary_op(NOT, _24975);
    }
    _24975 = NOVALUE;
    if (IS_ATOM_INT(_24976)) {
        if (_24976 == 0) {
            goto L34; // [1503] 1637
        }
    }
    else {
        if (DBL_PTR(_24976)->dbl == 0.0) {
            goto L34; // [1503] 1637
        }
    }
    _2 = (object)SEQ_PTR(_gtok_48067);
    _24978 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_24978)){
        _24979 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24978)->dbl));
    }
    else{
        _24979 = (object)*(((s1_ptr)_2)->base + _24978);
    }
    _2 = (object)SEQ_PTR(_24979);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _24980 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _24980 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _24979 = NOVALUE;
    Ref(_24980);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _scanning_file_48051;
    ((intptr_t *)_2)[2] = _24980;
    _24981 = MAKE_SEQ(_1);
    _24980 = NOVALUE;
    _24982 = find_from(_24981, _53include_warnings_48038, 1LL);
    DeRefDS(_24981);
    _24981 = NOVALUE;
    _24983 = (_24982 == 0);
    _24982 = NOVALUE;
    if (_24983 == 0)
    {
        DeRef(_24983);
        _24983 = NOVALUE;
        goto L34; // [1542] 1637
    }
    else{
        DeRef(_24983);
        _24983 = NOVALUE;
    }

    /** symtab.e:1032				include_warnings = prepend( include_warnings,*/
    _2 = (object)SEQ_PTR(_gtok_48067);
    _24984 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_24984)){
        _24985 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24984)->dbl));
    }
    else{
        _24985 = (object)*(((s1_ptr)_2)->base + _24984);
    }
    _2 = (object)SEQ_PTR(_24985);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _24986 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _24986 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _24985 = NOVALUE;
    Ref(_24986);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _scanning_file_48051;
    ((intptr_t *)_2)[2] = _24986;
    _24987 = MAKE_SEQ(_1);
    _24986 = NOVALUE;
    RefDS(_24987);
    Prepend(&_53include_warnings_48038, _53include_warnings_48038, _24987);
    DeRefDS(_24987);
    _24987 = NOVALUE;

    /** symtab.e:1034	ifdef STDDEBUG then*/

    /** symtab.e:1040					symbol_resolution_warning = GetMsgText(MSG_12__IDENTIFIER_3_IN_4_IS_NOT_INCLUDED,0,*/
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _24989 = (object)*(((s1_ptr)_2)->base + _scanning_file_48051);
    Ref(_24989);
    _24990 = _53name_ext(_24989);
    _24989 = NOVALUE;
    _2 = (object)SEQ_PTR(_gtok_48067);
    _24991 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_24991)){
        _24992 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24991)->dbl));
    }
    else{
        _24992 = (object)*(((s1_ptr)_2)->base + _24991);
    }
    _2 = (object)SEQ_PTR(_24992);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _24993 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _24993 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _24992 = NOVALUE;
    _2 = (object)SEQ_PTR(_13known_files_11317);
    if (!IS_ATOM_INT(_24993)){
        _24994 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24993)->dbl));
    }
    else{
        _24994 = (object)*(((s1_ptr)_2)->base + _24993);
    }
    Ref(_24994);
    _24995 = _53name_ext(_24994);
    _24994 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24990;
    ((intptr_t*)_2)[2] = _12line_number_20227;
    RefDS(_word_48049);
    ((intptr_t*)_2)[3] = _word_48049;
    ((intptr_t*)_2)[4] = _24995;
    _24996 = MAKE_SEQ(_1);
    _24995 = NOVALUE;
    _24990 = NOVALUE;
    _0 = _30GetMsgText(233LL, 0LL, _24996);
    DeRef(_12symbol_resolution_warning_20328);
    _12symbol_resolution_warning_20328 = _0;
    _24996 = NOVALUE;
L34: 

    /** symtab.e:1047			return gtok*/
    DeRefDS(_word_48049);
    DeRef(_msg_48057);
    DeRef(_b_name_48058);
    DeRef(_tok_48066);
    DeRef(_24956);
    _24956 = NOVALUE;
    _24899 = NOVALUE;
    DeRef(_24907);
    _24907 = NOVALUE;
    _24984 = NOVALUE;
    _24904 = NOVALUE;
    _24892 = NOVALUE;
    DeRef(_24882);
    _24882 = NOVALUE;
    _24945 = NOVALUE;
    DeRef(_24833);
    _24833 = NOVALUE;
    _24851 = NOVALUE;
    _24852 = NOVALUE;
    DeRef(_24976);
    _24976 = NOVALUE;
    DeRef(_24823);
    _24823 = NOVALUE;
    DeRef(_24888);
    _24888 = NOVALUE;
    _24878 = NOVALUE;
    _24993 = NOVALUE;
    _24860 = NOVALUE;
    DeRef(_24880);
    _24880 = NOVALUE;
    _24886 = NOVALUE;
    _24978 = NOVALUE;
    DeRef(_24874);
    _24874 = NOVALUE;
    DeRef(_24872);
    _24872 = NOVALUE;
    _24867 = NOVALUE;
    _24943 = NOVALUE;
    DeRef(_24972);
    _24972 = NOVALUE;
    _24847 = NOVALUE;
    _24991 = NOVALUE;
    return _gtok_48067;
L32: 

    /** symtab.e:1051		if length(dup_globals) = 0 then*/
    if (IS_SEQUENCE(_53dup_globals_48035)){
            _24998 = SEQ_PTR(_53dup_globals_48035)->length;
    }
    else {
        _24998 = 1;
    }
    if (_24998 != 0LL)
    goto L35; // [1651] 1725

    /** symtab.e:1052			defined = SC_UNDEFINED*/
    _defined_48060 = 9LL;

    /** symtab.e:1054			if fwd_line_number then*/
    if (_12fwd_line_number_20228 == 0)
    {
        goto L36; // [1668] 1697
    }
    else{
    }

    /** symtab.e:1055				last_ForwardLine     = ForwardLine*/
    Ref(_49ForwardLine_49313);
    DeRef(_49last_ForwardLine_49315);
    _49last_ForwardLine_49315 = _49ForwardLine_49313;

    /** symtab.e:1056				last_forward_bp      = forward_bp*/
    _49last_forward_bp_49319 = _49forward_bp_49317;

    /** symtab.e:1057				last_fwd_line_number = fwd_line_number*/
    _12last_fwd_line_number_20230 = _12fwd_line_number_20228;
L36: 

    /** symtab.e:1060			ForwardLine = ThisLine*/
    Ref(_49ThisLine_49312);
    DeRef(_49ForwardLine_49313);
    _49ForwardLine_49313 = _49ThisLine_49312;

    /** symtab.e:1061			forward_bp = bp*/
    _49forward_bp_49317 = _49bp_49316;

    /** symtab.e:1062			fwd_line_number = line_number*/
    _12fwd_line_number_20228 = _12line_number_20227;
    goto L37; // [1722] 1768
L35: 

    /** symtab.e:1064		elsif length(dup_globals) then*/
    if (IS_SEQUENCE(_53dup_globals_48035)){
            _25000 = SEQ_PTR(_53dup_globals_48035)->length;
    }
    else {
        _25000 = 1;
    }
    if (_25000 == 0)
    {
        _25000 = NOVALUE;
        goto L38; // [1732] 1747
    }
    else{
        _25000 = NOVALUE;
    }

    /** symtab.e:1065			defined = SC_MULTIPLY_DEFINED*/
    _defined_48060 = 10LL;
    goto L37; // [1744] 1768
L38: 

    /** symtab.e:1066		elsif length(dup_overrides) then*/
    if (IS_SEQUENCE(_53dup_overrides_48036)){
            _25001 = SEQ_PTR(_53dup_overrides_48036)->length;
    }
    else {
        _25001 = 1;
    }
    if (_25001 == 0)
    {
        _25001 = NOVALUE;
        goto L39; // [1754] 1767
    }
    else{
        _25001 = NOVALUE;
    }

    /** symtab.e:1067			defined = SC_OVERRIDE*/
    _defined_48060 = 12LL;
L39: 
L37: 

    /** symtab.e:1070		if No_new_entry then*/
    if (_53No_new_entry_48046 == 0)
    {
        goto L3A; // [1772] 1795
    }
    else{
    }

    /** symtab.e:1071			return {IGNORED,word,defined,dup_globals}*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 509LL;
    RefDS(_word_48049);
    ((intptr_t*)_2)[2] = _word_48049;
    ((intptr_t*)_2)[3] = _defined_48060;
    RefDS(_53dup_globals_48035);
    ((intptr_t*)_2)[4] = _53dup_globals_48035;
    _25002 = MAKE_SEQ(_1);
    DeRefDS(_word_48049);
    DeRef(_msg_48057);
    DeRef(_b_name_48058);
    DeRef(_tok_48066);
    DeRef(_gtok_48067);
    DeRef(_24956);
    _24956 = NOVALUE;
    _24899 = NOVALUE;
    DeRef(_24907);
    _24907 = NOVALUE;
    _24984 = NOVALUE;
    _24904 = NOVALUE;
    _24892 = NOVALUE;
    DeRef(_24882);
    _24882 = NOVALUE;
    _24945 = NOVALUE;
    DeRef(_24833);
    _24833 = NOVALUE;
    _24851 = NOVALUE;
    _24852 = NOVALUE;
    DeRef(_24976);
    _24976 = NOVALUE;
    DeRef(_24823);
    _24823 = NOVALUE;
    DeRef(_24888);
    _24888 = NOVALUE;
    _24878 = NOVALUE;
    _24993 = NOVALUE;
    _24860 = NOVALUE;
    DeRef(_24880);
    _24880 = NOVALUE;
    _24886 = NOVALUE;
    _24978 = NOVALUE;
    DeRef(_24874);
    _24874 = NOVALUE;
    DeRef(_24872);
    _24872 = NOVALUE;
    _24867 = NOVALUE;
    _24943 = NOVALUE;
    DeRef(_24972);
    _24972 = NOVALUE;
    _24847 = NOVALUE;
    _24991 = NOVALUE;
    return _25002;
L3A: 

    /** symtab.e:1074		tok = {VARIABLE, NewEntry(word, 0, defined,*/
    _2 = (object)SEQ_PTR(_53buckets_46842);
    _25003 = (object)*(((s1_ptr)_2)->base + _hashval_48055);
    RefDS(_word_48049);
    Ref(_25003);
    _25004 = _53NewEntry(_word_48049, 0LL, _defined_48060, -100LL, _hashval_48055, _25003, 0LL);
    _25003 = NOVALUE;
    DeRef(_tok_48066);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100LL;
    ((intptr_t *)_2)[2] = _25004;
    _tok_48066 = MAKE_SEQ(_1);
    _25004 = NOVALUE;

    /** symtab.e:1076		buckets[hashval] = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_48066);
    _25006 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_25006);
    _2 = (object)SEQ_PTR(_53buckets_46842);
    _2 = (object)(((s1_ptr)_2)->base + _hashval_48055);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25006;
    if( _1 != _25006 ){
        DeRef(_1);
    }
    _25006 = NOVALUE;

    /** symtab.e:1078		if file_no != -1 then*/
    if (_file_no_48050 == -1LL)
    goto L3B; // [1839] 1865

    /** symtab.e:1079			SymTab[tok[T_SYM]][S_FILE_NO] = file_no*/
    _2 = (object)SEQ_PTR(_tok_48066);
    _25008 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_25008))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_25008)->dbl));
    else
    _3 = (object)(_25008 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_FILE_NO_19860))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _file_no_48050;
    DeRef(_1);
    _25009 = NOVALUE;
L3B: 

    /** symtab.e:1081		return tok  -- no ref on newly declared symbol*/
    DeRefDS(_word_48049);
    DeRef(_msg_48057);
    DeRef(_b_name_48058);
    DeRef(_gtok_48067);
    DeRef(_24956);
    _24956 = NOVALUE;
    _25008 = NOVALUE;
    _24899 = NOVALUE;
    DeRef(_24907);
    _24907 = NOVALUE;
    _24984 = NOVALUE;
    _24904 = NOVALUE;
    _24892 = NOVALUE;
    DeRef(_24882);
    _24882 = NOVALUE;
    _24945 = NOVALUE;
    DeRef(_24833);
    _24833 = NOVALUE;
    _24851 = NOVALUE;
    _24852 = NOVALUE;
    DeRef(_24976);
    _24976 = NOVALUE;
    DeRef(_24823);
    _24823 = NOVALUE;
    DeRef(_24888);
    _24888 = NOVALUE;
    _24878 = NOVALUE;
    _24993 = NOVALUE;
    _24860 = NOVALUE;
    DeRef(_25002);
    _25002 = NOVALUE;
    DeRef(_24880);
    _24880 = NOVALUE;
    _24886 = NOVALUE;
    _24978 = NOVALUE;
    DeRef(_24874);
    _24874 = NOVALUE;
    DeRef(_24872);
    _24872 = NOVALUE;
    _24867 = NOVALUE;
    _24943 = NOVALUE;
    DeRef(_24972);
    _24972 = NOVALUE;
    _24847 = NOVALUE;
    _24991 = NOVALUE;
    return _tok_48066;
    ;
}


void _53Hide(object _s_48460)
{
    object _prev_48462 = NOVALUE;
    object _p_48463 = NOVALUE;
    object _25029 = NOVALUE;
    object _25028 = NOVALUE;
    object _25027 = NOVALUE;
    object _25025 = NOVALUE;
    object _25024 = NOVALUE;
    object _25023 = NOVALUE;
    object _25022 = NOVALUE;
    object _25021 = NOVALUE;
    object _25017 = NOVALUE;
    object _25016 = NOVALUE;
    object _25015 = NOVALUE;
    object _25014 = NOVALUE;
    object _25012 = NOVALUE;
    object _25011 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_48460)) {
        _1 = (object)(DBL_PTR(_s_48460)->dbl);
        DeRefDS(_s_48460);
        _s_48460 = _1;
    }

    /** symtab.e:1090		p = buckets[SymTab[s][S_HASHVAL]]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25011 = (object)*(((s1_ptr)_2)->base + _s_48460);
    _2 = (object)SEQ_PTR(_25011);
    _25012 = (object)*(((s1_ptr)_2)->base + 11LL);
    _25011 = NOVALUE;
    _2 = (object)SEQ_PTR(_53buckets_46842);
    if (!IS_ATOM_INT(_25012)){
        _p_48463 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25012)->dbl));
    }
    else{
        _p_48463 = (object)*(((s1_ptr)_2)->base + _25012);
    }
    if (!IS_ATOM_INT(_p_48463)){
        _p_48463 = (object)DBL_PTR(_p_48463)->dbl;
    }

    /** symtab.e:1091		prev = 0*/
    _prev_48462 = 0LL;

    /** symtab.e:1093		while p != s and p != 0 do*/
L1: 
    _25014 = (_p_48463 != _s_48460);
    if (_25014 == 0) {
        goto L2; // [41] 81
    }
    _25016 = (_p_48463 != 0LL);
    if (_25016 == 0)
    {
        DeRef(_25016);
        _25016 = NOVALUE;
        goto L2; // [50] 81
    }
    else{
        DeRef(_25016);
        _25016 = NOVALUE;
    }

    /** symtab.e:1094			prev = p*/
    _prev_48462 = _p_48463;

    /** symtab.e:1095			p = SymTab[p][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25017 = (object)*(((s1_ptr)_2)->base + _p_48463);
    _2 = (object)SEQ_PTR(_25017);
    _p_48463 = (object)*(((s1_ptr)_2)->base + 9LL);
    if (!IS_ATOM_INT(_p_48463)){
        _p_48463 = (object)DBL_PTR(_p_48463)->dbl;
    }
    _25017 = NOVALUE;

    /** symtab.e:1096		end while*/
    goto L1; // [78] 37
L2: 

    /** symtab.e:1098		if p = 0 then*/
    if (_p_48463 != 0LL)
    goto L3; // [83] 93

    /** symtab.e:1099			return -- already hidden*/
    _25012 = NOVALUE;
    DeRef(_25014);
    _25014 = NOVALUE;
    return;
L3: 

    /** symtab.e:1101		if prev = 0 then*/
    if (_prev_48462 != 0LL)
    goto L4; // [95] 134

    /** symtab.e:1102			buckets[SymTab[s][S_HASHVAL]] = SymTab[s][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25021 = (object)*(((s1_ptr)_2)->base + _s_48460);
    _2 = (object)SEQ_PTR(_25021);
    _25022 = (object)*(((s1_ptr)_2)->base + 11LL);
    _25021 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25023 = (object)*(((s1_ptr)_2)->base + _s_48460);
    _2 = (object)SEQ_PTR(_25023);
    _25024 = (object)*(((s1_ptr)_2)->base + 9LL);
    _25023 = NOVALUE;
    Ref(_25024);
    _2 = (object)SEQ_PTR(_53buckets_46842);
    if (!IS_ATOM_INT(_25022))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_25022)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _25022);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25024;
    if( _1 != _25024 ){
        DeRef(_1);
    }
    _25024 = NOVALUE;
    goto L5; // [131] 162
L4: 

    /** symtab.e:1104			SymTab[prev][S_SAMEHASH] = SymTab[s][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_48462 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25027 = (object)*(((s1_ptr)_2)->base + _s_48460);
    _2 = (object)SEQ_PTR(_25027);
    _25028 = (object)*(((s1_ptr)_2)->base + 9LL);
    _25027 = NOVALUE;
    Ref(_25028);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25028;
    if( _1 != _25028 ){
        DeRef(_1);
    }
    _25028 = NOVALUE;
    _25025 = NOVALUE;
L5: 

    /** symtab.e:1106		SymTab[s][S_SAMEHASH] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_48460 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _25029 = NOVALUE;

    /** symtab.e:1107	end procedure*/
    _25012 = NOVALUE;
    DeRef(_25014);
    _25014 = NOVALUE;
    _25022 = NOVALUE;
    return;
    ;
}


void _53Show(object _s_48505)
{
    object _p_48507 = NOVALUE;
    object _25041 = NOVALUE;
    object _25040 = NOVALUE;
    object _25038 = NOVALUE;
    object _25037 = NOVALUE;
    object _25035 = NOVALUE;
    object _25034 = NOVALUE;
    object _25032 = NOVALUE;
    object _25031 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:1114		p = buckets[SymTab[s][S_HASHVAL]]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25031 = (object)*(((s1_ptr)_2)->base + _s_48505);
    _2 = (object)SEQ_PTR(_25031);
    _25032 = (object)*(((s1_ptr)_2)->base + 11LL);
    _25031 = NOVALUE;
    _2 = (object)SEQ_PTR(_53buckets_46842);
    if (!IS_ATOM_INT(_25032)){
        _p_48507 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25032)->dbl));
    }
    else{
        _p_48507 = (object)*(((s1_ptr)_2)->base + _25032);
    }
    if (!IS_ATOM_INT(_p_48507)){
        _p_48507 = (object)DBL_PTR(_p_48507)->dbl;
    }

    /** symtab.e:1116		if SymTab[s][S_SAMEHASH] or p = s then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25034 = (object)*(((s1_ptr)_2)->base + _s_48505);
    _2 = (object)SEQ_PTR(_25034);
    _25035 = (object)*(((s1_ptr)_2)->base + 9LL);
    _25034 = NOVALUE;
    if (IS_ATOM_INT(_25035)) {
        if (_25035 != 0) {
            goto L1; // [39] 52
        }
    }
    else {
        if (DBL_PTR(_25035)->dbl != 0.0) {
            goto L1; // [39] 52
        }
    }
    _25037 = (_p_48507 == _s_48505);
    if (_25037 == 0)
    {
        DeRef(_25037);
        _25037 = NOVALUE;
        goto L2; // [48] 58
    }
    else{
        DeRef(_25037);
        _25037 = NOVALUE;
    }
L1: 

    /** symtab.e:1118			return*/
    _25032 = NOVALUE;
    _25035 = NOVALUE;
    return;
L2: 

    /** symtab.e:1121		SymTab[s][S_SAMEHASH] = p*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_48505 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _p_48507;
    DeRef(_1);
    _25038 = NOVALUE;

    /** symtab.e:1122		buckets[SymTab[s][S_HASHVAL]] = s*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25040 = (object)*(((s1_ptr)_2)->base + _s_48505);
    _2 = (object)SEQ_PTR(_25040);
    _25041 = (object)*(((s1_ptr)_2)->base + 11LL);
    _25040 = NOVALUE;
    _2 = (object)SEQ_PTR(_53buckets_46842);
    if (!IS_ATOM_INT(_25041))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_25041)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _25041);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_48505;
    DeRef(_1);

    /** symtab.e:1124	end procedure*/
    _25032 = NOVALUE;
    _25041 = NOVALUE;
    _25035 = NOVALUE;
    return;
    ;
}


void _53hide_params(object _s_48531)
{
    object _param_48533 = NOVALUE;
    object _25044 = NOVALUE;
    object _25043 = NOVALUE;
    object _25042 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1127		symtab_index param = s*/
    _param_48533 = _s_48531;

    /** symtab.e:1128		for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25042 = (object)*(((s1_ptr)_2)->base + _s_48531);
    _2 = (object)SEQ_PTR(_25042);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _25043 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _25043 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _25042 = NOVALUE;
    {
        object _i_48535;
        _i_48535 = 1LL;
L1: 
        if (binary_op_a(GREATER, _i_48535, _25043)){
            goto L2; // [24] 59
        }

        /** symtab.e:1129			param = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _25044 = (object)*(((s1_ptr)_2)->base + _s_48531);
        _2 = (object)SEQ_PTR(_25044);
        _param_48533 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_param_48533)){
            _param_48533 = (object)DBL_PTR(_param_48533)->dbl;
        }
        _25044 = NOVALUE;

        /** symtab.e:1130			Hide( param )*/
        _53Hide(_param_48533);

        /** symtab.e:1131		end for*/
        _0 = _i_48535;
        if (IS_ATOM_INT(_i_48535)) {
            _i_48535 = _i_48535 + 1LL;
            if ((object)((uintptr_t)_i_48535 +(uintptr_t) HIGH_BITS) >= 0){
                _i_48535 = NewDouble((eudouble)_i_48535);
            }
        }
        else {
            _i_48535 = binary_op_a(PLUS, _i_48535, 1LL);
        }
        DeRef(_0);
        goto L1; // [54] 31
L2: 
        ;
        DeRef(_i_48535);
    }

    /** symtab.e:1132	end procedure*/
    _25043 = NOVALUE;
    return;
    ;
}


void _53show_params(object _s_48547)
{
    object _param_48549 = NOVALUE;
    object _25048 = NOVALUE;
    object _25047 = NOVALUE;
    object _25046 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1135		symtab_index param = s*/
    _param_48549 = _s_48547;

    /** symtab.e:1136		for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25046 = (object)*(((s1_ptr)_2)->base + _s_48547);
    _2 = (object)SEQ_PTR(_25046);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _25047 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _25047 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _25046 = NOVALUE;
    {
        object _i_48551;
        _i_48551 = 1LL;
L1: 
        if (binary_op_a(GREATER, _i_48551, _25047)){
            goto L2; // [24] 59
        }

        /** symtab.e:1137			param = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _25048 = (object)*(((s1_ptr)_2)->base + _s_48547);
        _2 = (object)SEQ_PTR(_25048);
        _param_48549 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_param_48549)){
            _param_48549 = (object)DBL_PTR(_param_48549)->dbl;
        }
        _25048 = NOVALUE;

        /** symtab.e:1138			Show( param )*/
        _53Show(_param_48549);

        /** symtab.e:1139		end for*/
        _0 = _i_48551;
        if (IS_ATOM_INT(_i_48551)) {
            _i_48551 = _i_48551 + 1LL;
            if ((object)((uintptr_t)_i_48551 +(uintptr_t) HIGH_BITS) >= 0){
                _i_48551 = NewDouble((eudouble)_i_48551);
            }
        }
        else {
            _i_48551 = binary_op_a(PLUS, _i_48551, 1LL);
        }
        DeRef(_0);
        goto L1; // [54] 31
L2: 
        ;
        DeRef(_i_48551);
    }

    /** symtab.e:1140	end procedure*/
    _25047 = NOVALUE;
    return;
    ;
}


void _53LintCheck(object _s_48563)
{
    object _warn_level_48564 = NOVALUE;
    object _file_48565 = NOVALUE;
    object _vscope_48566 = NOVALUE;
    object _vname_48567 = NOVALUE;
    object _vusage_48568 = NOVALUE;
    object _25112 = NOVALUE;
    object _25111 = NOVALUE;
    object _25110 = NOVALUE;
    object _25109 = NOVALUE;
    object _25108 = NOVALUE;
    object _25107 = NOVALUE;
    object _25104 = NOVALUE;
    object _25103 = NOVALUE;
    object _25102 = NOVALUE;
    object _25101 = NOVALUE;
    object _25100 = NOVALUE;
    object _25099 = NOVALUE;
    object _25096 = NOVALUE;
    object _25095 = NOVALUE;
    object _25094 = NOVALUE;
    object _25093 = NOVALUE;
    object _25092 = NOVALUE;
    object _25091 = NOVALUE;
    object _25088 = NOVALUE;
    object _25086 = NOVALUE;
    object _25085 = NOVALUE;
    object _25083 = NOVALUE;
    object _25082 = NOVALUE;
    object _25080 = NOVALUE;
    object _25079 = NOVALUE;
    object _25078 = NOVALUE;
    object _25077 = NOVALUE;
    object _25074 = NOVALUE;
    object _25073 = NOVALUE;
    object _25069 = NOVALUE;
    object _25066 = NOVALUE;
    object _25065 = NOVALUE;
    object _25064 = NOVALUE;
    object _25063 = NOVALUE;
    object _25060 = NOVALUE;
    object _25059 = NOVALUE;
    object _25054 = NOVALUE;
    object _25052 = NOVALUE;
    object _25050 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_48563)) {
        _1 = (object)(DBL_PTR(_s_48563)->dbl);
        DeRefDS(_s_48563);
        _s_48563 = _1;
    }

    /** symtab.e:1150		vusage = SymTab[s][S_USAGE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25050 = (object)*(((s1_ptr)_2)->base + _s_48563);
    _2 = (object)SEQ_PTR(_25050);
    _vusage_48568 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (!IS_ATOM_INT(_vusage_48568)){
        _vusage_48568 = (object)DBL_PTR(_vusage_48568)->dbl;
    }
    _25050 = NOVALUE;

    /** symtab.e:1151		vscope = SymTab[s][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25052 = (object)*(((s1_ptr)_2)->base + _s_48563);
    _2 = (object)SEQ_PTR(_25052);
    _vscope_48566 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_vscope_48566)){
        _vscope_48566 = (object)DBL_PTR(_vscope_48566)->dbl;
    }
    _25052 = NOVALUE;

    /** symtab.e:1152		vname = SymTab[s][S_NAME]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25054 = (object)*(((s1_ptr)_2)->base + _s_48563);
    DeRef(_vname_48567);
    _2 = (object)SEQ_PTR(_25054);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _vname_48567 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _vname_48567 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    Ref(_vname_48567);
    _25054 = NOVALUE;

    /** symtab.e:1154		switch vusage do*/
    _0 = _vusage_48568;
    switch ( _0 ){ 

        /** symtab.e:1156			case U_UNUSED then*/
        case 0:

        /** symtab.e:1157				warn_level = 1*/
        _warn_level_48564 = 1LL;
        goto L1; // [67] 193

        /** symtab.e:1159			case U_WRITTEN then -- Set but never read*/
        case 2:

        /** symtab.e:1160				warn_level = 2*/
        _warn_level_48564 = 2LL;

        /** symtab.e:1162				if vscope > SC_LOCAL then*/
        if (_vscope_48566 <= 5LL)
        goto L2; // [82] 94

        /** symtab.e:1164					warn_level = 0 */
        _warn_level_48564 = 0LL;
        goto L1; // [91] 193
L2: 

        /** symtab.e:1166				elsif SymTab[s][S_MODE] = M_CONSTANT then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _25059 = (object)*(((s1_ptr)_2)->base + _s_48563);
        _2 = (object)SEQ_PTR(_25059);
        _25060 = (object)*(((s1_ptr)_2)->base + 3LL);
        _25059 = NOVALUE;
        if (binary_op_a(NOTEQ, _25060, 2LL)){
            _25060 = NOVALUE;
            goto L1; // [110] 193
        }
        _25060 = NOVALUE;

        /** symtab.e:1167					if not Strict_is_on then*/
        if (_12Strict_is_on_20292 != 0)
        goto L1; // [118] 193

        /** symtab.e:1170						warn_level = 0 */
        _warn_level_48564 = 0LL;
        goto L1; // [129] 193

        /** symtab.e:1174			case U_READ then -- Read but never set*/
        case 1:

        /** symtab.e:1175				if SymTab[s][S_VARNUM] >= SymTab[CurrentSub][S_NUM_ARGS] then*/
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _25063 = (object)*(((s1_ptr)_2)->base + _s_48563);
        _2 = (object)SEQ_PTR(_25063);
        _25064 = (object)*(((s1_ptr)_2)->base + 16LL);
        _25063 = NOVALUE;
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        _25065 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
        _2 = (object)SEQ_PTR(_25065);
        if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
            _25066 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
        }
        else{
            _25066 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
        }
        _25065 = NOVALUE;
        if (binary_op_a(LESS, _25064, _25066)){
            _25064 = NOVALUE;
            _25066 = NOVALUE;
            goto L3; // [163] 175
        }
        _25064 = NOVALUE;
        _25066 = NOVALUE;

        /** symtab.e:1176			    	warn_level = 3*/
        _warn_level_48564 = 3LL;
        goto L1; // [172] 193
L3: 

        /** symtab.e:1179			    	warn_level = 0*/
        _warn_level_48564 = 0LL;
        goto L1; // [181] 193

        /** symtab.e:1182		    case else*/
        default:

        /** symtab.e:1183		    	warn_level = 0*/
        _warn_level_48564 = 0LL;
    ;}L1: 

    /** symtab.e:1186		if warn_level = 0 then*/
    if (_warn_level_48564 != 0LL)
    goto L4; // [197] 207

    /** symtab.e:1187			return*/
    DeRef(_file_48565);
    DeRef(_vname_48567);
    return;
L4: 

    /** symtab.e:1191		file = abbreviate_path(known_files[current_file_no])*/
    _2 = (object)SEQ_PTR(_13known_files_11317);
    _25069 = (object)*(((s1_ptr)_2)->base + _12current_file_no_20226);
    Ref(_25069);
    RefDS(_22024);
    _0 = _file_48565;
    _file_48565 = _14abbreviate_path(_25069, _22024);
    DeRef(_0);
    _25069 = NOVALUE;

    /** symtab.e:1192		if warn_level = 3 then*/
    if (_warn_level_48564 != 3LL)
    goto L5; // [226] 308

    /** symtab.e:1193			if vscope = SC_LOCAL then*/
    if (_vscope_48566 != 5LL)
    goto L6; // [234] 275

    /** symtab.e:1194				if current_file_no = SymTab[s][S_FILE_NO] then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25073 = (object)*(((s1_ptr)_2)->base + _s_48563);
    _2 = (object)SEQ_PTR(_25073);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _25074 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _25074 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _25073 = NOVALUE;
    if (binary_op_a(NOTEQ, _12current_file_no_20226, _25074)){
        _25074 = NOVALUE;
        goto L7; // [254] 602
    }
    _25074 = NOVALUE;

    /** symtab.e:1195					Warning(226, no_value_warning_flag, {file,  vname})*/
    RefDS(_vname_48567);
    RefDS(_file_48565);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48565;
    ((intptr_t *)_2)[2] = _vname_48567;
    _25077 = MAKE_SEQ(_1);
    _49Warning(226LL, 32LL, _25077);
    _25077 = NOVALUE;
    goto L7; // [272] 602
L6: 

    /** symtab.e:1198				Warning(227, no_value_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25078 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_25078);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _25079 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _25079 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _25078 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48565);
    ((intptr_t*)_2)[1] = _file_48565;
    RefDS(_vname_48567);
    ((intptr_t*)_2)[2] = _vname_48567;
    Ref(_25079);
    ((intptr_t*)_2)[3] = _25079;
    _25080 = MAKE_SEQ(_1);
    _25079 = NOVALUE;
    _49Warning(227LL, 32LL, _25080);
    _25080 = NOVALUE;
    goto L7; // [305] 602
L5: 

    /** symtab.e:1201			if vscope = SC_LOCAL then*/
    if (_vscope_48566 != 5LL)
    goto L8; // [312] 412

    /** symtab.e:1202				if current_file_no = SymTab[s][S_FILE_NO] then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25082 = (object)*(((s1_ptr)_2)->base + _s_48563);
    _2 = (object)SEQ_PTR(_25082);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _25083 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _25083 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _25082 = NOVALUE;
    if (binary_op_a(NOTEQ, _12current_file_no_20226, _25083)){
        _25083 = NOVALUE;
        goto L9; // [332] 601
    }
    _25083 = NOVALUE;

    /** symtab.e:1203					if SymTab[s][S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25085 = (object)*(((s1_ptr)_2)->base + _s_48563);
    _2 = (object)SEQ_PTR(_25085);
    _25086 = (object)*(((s1_ptr)_2)->base + 3LL);
    _25085 = NOVALUE;
    if (binary_op_a(NOTEQ, _25086, 2LL)){
        _25086 = NOVALUE;
        goto LA; // [352] 372
    }
    _25086 = NOVALUE;

    /** symtab.e:1204						Warning(228, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_48567);
    RefDS(_file_48565);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48565;
    ((intptr_t *)_2)[2] = _vname_48567;
    _25088 = MAKE_SEQ(_1);
    _49Warning(228LL, 16LL, _25088);
    _25088 = NOVALUE;
    goto L9; // [369] 601
LA: 

    /** symtab.e:1206					elsif warn_level = 1 then*/
    if (_warn_level_48564 != 1LL)
    goto LB; // [374] 394

    /** symtab.e:1207						Warning(229, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_48567);
    RefDS(_file_48565);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48565;
    ((intptr_t *)_2)[2] = _vname_48567;
    _25091 = MAKE_SEQ(_1);
    _49Warning(229LL, 16LL, _25091);
    _25091 = NOVALUE;
    goto L9; // [391] 601
LB: 

    /** symtab.e:1210						Warning(320, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_48567);
    RefDS(_file_48565);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48565;
    ((intptr_t *)_2)[2] = _vname_48567;
    _25092 = MAKE_SEQ(_1);
    _49Warning(320LL, 16LL, _25092);
    _25092 = NOVALUE;
    goto L9; // [409] 601
L8: 

    /** symtab.e:1214				if SymTab[s][S_VARNUM] < SymTab[CurrentSub][S_NUM_ARGS] then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25093 = (object)*(((s1_ptr)_2)->base + _s_48563);
    _2 = (object)SEQ_PTR(_25093);
    _25094 = (object)*(((s1_ptr)_2)->base + 16LL);
    _25093 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25095 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_25095);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _25096 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _25096 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _25095 = NOVALUE;
    if (binary_op_a(GREATEREQ, _25094, _25096)){
        _25094 = NOVALUE;
        _25096 = NOVALUE;
        goto LC; // [440] 523
    }
    _25094 = NOVALUE;
    _25096 = NOVALUE;

    /** symtab.e:1216					if warn_level = 1 then*/
    if (_warn_level_48564 != 1LL)
    goto LD; // [446] 490

    /** symtab.e:1217						if Strict_is_on then*/
    if (_12Strict_is_on_20292 == 0)
    {
        goto LE; // [454] 600
    }
    else{
    }

    /** symtab.e:1219							Warning(230, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25099 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_25099);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _25100 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _25100 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _25099 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48565);
    ((intptr_t*)_2)[1] = _file_48565;
    RefDS(_vname_48567);
    ((intptr_t*)_2)[2] = _vname_48567;
    Ref(_25100);
    ((intptr_t*)_2)[3] = _25100;
    _25101 = MAKE_SEQ(_1);
    _25100 = NOVALUE;
    _49Warning(230LL, 16LL, _25101);
    _25101 = NOVALUE;
    goto LE; // [487] 600
LD: 

    /** symtab.e:1222						Warning(321, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25102 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_25102);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _25103 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _25103 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _25102 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48565);
    ((intptr_t*)_2)[1] = _file_48565;
    RefDS(_vname_48567);
    ((intptr_t*)_2)[2] = _vname_48567;
    Ref(_25103);
    ((intptr_t*)_2)[3] = _25103;
    _25104 = MAKE_SEQ(_1);
    _25103 = NOVALUE;
    _49Warning(321LL, 16LL, _25104);
    _25104 = NOVALUE;
    goto LE; // [520] 600
LC: 

    /** symtab.e:1226					if warn_level = 1 then*/
    if (_warn_level_48564 != 1LL)
    goto LF; // [525] 569

    /** symtab.e:1227						if Strict_is_on then*/
    if (_12Strict_is_on_20292 == 0)
    {
        goto L10; // [533] 599
    }
    else{
    }

    /** symtab.e:1229							Warning(231, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25107 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_25107);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _25108 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _25108 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _25107 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48565);
    ((intptr_t*)_2)[1] = _file_48565;
    RefDS(_vname_48567);
    ((intptr_t*)_2)[2] = _vname_48567;
    Ref(_25108);
    ((intptr_t*)_2)[3] = _25108;
    _25109 = MAKE_SEQ(_1);
    _25108 = NOVALUE;
    _49Warning(231LL, 16LL, _25109);
    _25109 = NOVALUE;
    goto L10; // [566] 599
LF: 

    /** symtab.e:1232						Warning(322, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25110 = (object)*(((s1_ptr)_2)->base + _12CurrentSub_20234);
    _2 = (object)SEQ_PTR(_25110);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _25111 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _25111 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _25110 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48565);
    ((intptr_t*)_2)[1] = _file_48565;
    RefDS(_vname_48567);
    ((intptr_t*)_2)[2] = _vname_48567;
    Ref(_25111);
    ((intptr_t*)_2)[3] = _25111;
    _25112 = MAKE_SEQ(_1);
    _25111 = NOVALUE;
    _49Warning(322LL, 16LL, _25112);
    _25112 = NOVALUE;
L10: 
LE: 
L9: 
L7: 

    /** symtab.e:1238	end procedure*/
    DeRef(_file_48565);
    DeRef(_vname_48567);
    return;
    ;
}


void _53HideLocals()
{
    object _s_48737 = NOVALUE;
    object _25125 = NOVALUE;
    object _25123 = NOVALUE;
    object _25122 = NOVALUE;
    object _25121 = NOVALUE;
    object _25120 = NOVALUE;
    object _25119 = NOVALUE;
    object _25118 = NOVALUE;
    object _25117 = NOVALUE;
    object _25116 = NOVALUE;
    object _25115 = NOVALUE;
    object _25114 = NOVALUE;
    object _25113 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1244		mark_rechecks()*/
    _53mark_rechecks(_12current_file_no_20226);

    /** symtab.e:1245		s = file_start_sym*/
    _s_48737 = _12file_start_sym_20232;

    /** symtab.e:1246		while s do*/
L1: 
    if (_s_48737 == 0)
    {
        goto L2; // [22] 148
    }
    else{
    }

    /** symtab.e:1247			if SymTab[s][S_SCOPE] = SC_LOCAL and*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25113 = (object)*(((s1_ptr)_2)->base + _s_48737);
    _2 = (object)SEQ_PTR(_25113);
    _25114 = (object)*(((s1_ptr)_2)->base + 4LL);
    _25113 = NOVALUE;
    if (IS_ATOM_INT(_25114)) {
        _25115 = (_25114 == 5LL);
    }
    else {
        _25115 = binary_op(EQUALS, _25114, 5LL);
    }
    _25114 = NOVALUE;
    if (IS_ATOM_INT(_25115)) {
        if (_25115 == 0) {
            goto L3; // [45] 127
        }
    }
    else {
        if (DBL_PTR(_25115)->dbl == 0.0) {
            goto L3; // [45] 127
        }
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25117 = (object)*(((s1_ptr)_2)->base + _s_48737);
    _2 = (object)SEQ_PTR(_25117);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _25118 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _25118 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _25117 = NOVALUE;
    if (IS_ATOM_INT(_25118)) {
        _25119 = (_25118 == _12current_file_no_20226);
    }
    else {
        _25119 = binary_op(EQUALS, _25118, _12current_file_no_20226);
    }
    _25118 = NOVALUE;
    if (_25119 == 0) {
        DeRef(_25119);
        _25119 = NOVALUE;
        goto L3; // [68] 127
    }
    else {
        if (!IS_ATOM_INT(_25119) && DBL_PTR(_25119)->dbl == 0.0){
            DeRef(_25119);
            _25119 = NOVALUE;
            goto L3; // [68] 127
        }
        DeRef(_25119);
        _25119 = NOVALUE;
    }
    DeRef(_25119);
    _25119 = NOVALUE;

    /** symtab.e:1249			   	if current_block = top_level_block and repl then*/
    _25120 = (_64current_block_25147 == _64top_level_block_25148);
    if (_25120 == 0) {
        goto L4; // [81] 94
    }
    goto L4; // [88] 94
    goto L5; // [91] 100
L4: 

    /** symtab.e:1251				Hide(s)*/
    _53Hide(_s_48737);
L5: 

    /** symtab.e:1253				if SymTab[s][S_TOKEN] = VARIABLE then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25122 = (object)*(((s1_ptr)_2)->base + _s_48737);
    _2 = (object)SEQ_PTR(_25122);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _25123 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _25123 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _25122 = NOVALUE;
    if (binary_op_a(NOTEQ, _25123, -100LL)){
        _25123 = NOVALUE;
        goto L6; // [116] 126
    }
    _25123 = NOVALUE;

    /** symtab.e:1254					LintCheck(s)*/
    _53LintCheck(_s_48737);
L6: 
L3: 

    /** symtab.e:1257			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25125 = (object)*(((s1_ptr)_2)->base + _s_48737);
    _2 = (object)SEQ_PTR(_25125);
    _s_48737 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_48737)){
        _s_48737 = (object)DBL_PTR(_s_48737)->dbl;
    }
    _25125 = NOVALUE;

    /** symtab.e:1258		end while*/
    goto L1; // [145] 22
L2: 

    /** symtab.e:1259	end procedure*/
    DeRef(_25120);
    _25120 = NOVALUE;
    DeRef(_25115);
    _25115 = NOVALUE;
    return;
    ;
}


object _53sym_name(object _sym_48776)
{
    object _25128 = NOVALUE;
    object _25127 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48776)) {
        _1 = (object)(DBL_PTR(_sym_48776)->dbl);
        DeRefDS(_sym_48776);
        _sym_48776 = _1;
    }

    /** symtab.e:1262		return SymTab[sym][S_NAME]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25127 = (object)*(((s1_ptr)_2)->base + _sym_48776);
    _2 = (object)SEQ_PTR(_25127);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _25128 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _25128 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _25127 = NOVALUE;
    Ref(_25128);
    return _25128;
    ;
}


object _53sym_token(object _sym_48784)
{
    object _25130 = NOVALUE;
    object _25129 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48784)) {
        _1 = (object)(DBL_PTR(_sym_48784)->dbl);
        DeRefDS(_sym_48784);
        _sym_48784 = _1;
    }

    /** symtab.e:1266		return SymTab[sym][S_TOKEN]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25129 = (object)*(((s1_ptr)_2)->base + _sym_48784);
    _2 = (object)SEQ_PTR(_25129);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _25130 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _25130 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _25129 = NOVALUE;
    Ref(_25130);
    return _25130;
    ;
}


object _53sym_scope(object _sym_48792)
{
    object _25132 = NOVALUE;
    object _25131 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48792)) {
        _1 = (object)(DBL_PTR(_sym_48792)->dbl);
        DeRefDS(_sym_48792);
        _sym_48792 = _1;
    }

    /** symtab.e:1270		return SymTab[sym][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25131 = (object)*(((s1_ptr)_2)->base + _sym_48792);
    _2 = (object)SEQ_PTR(_25131);
    _25132 = (object)*(((s1_ptr)_2)->base + 4LL);
    _25131 = NOVALUE;
    Ref(_25132);
    return _25132;
    ;
}


object _53sym_mode(object _sym_48800)
{
    object _25134 = NOVALUE;
    object _25133 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48800)) {
        _1 = (object)(DBL_PTR(_sym_48800)->dbl);
        DeRefDS(_sym_48800);
        _sym_48800 = _1;
    }

    /** symtab.e:1274		return SymTab[sym][S_MODE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25133 = (object)*(((s1_ptr)_2)->base + _sym_48800);
    _2 = (object)SEQ_PTR(_25133);
    _25134 = (object)*(((s1_ptr)_2)->base + 3LL);
    _25133 = NOVALUE;
    Ref(_25134);
    return _25134;
    ;
}


object _53sym_obj(object _sym_48808)
{
    object _25136 = NOVALUE;
    object _25135 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48808)) {
        _1 = (object)(DBL_PTR(_sym_48808)->dbl);
        DeRefDS(_sym_48808);
        _sym_48808 = _1;
    }

    /** symtab.e:1278		return SymTab[sym][S_OBJ]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25135 = (object)*(((s1_ptr)_2)->base + _sym_48808);
    _2 = (object)SEQ_PTR(_25135);
    _25136 = (object)*(((s1_ptr)_2)->base + 1LL);
    _25135 = NOVALUE;
    Ref(_25136);
    return _25136;
    ;
}


object _53sym_next(object _sym_48816)
{
    object _25138 = NOVALUE;
    object _25137 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1282		return SymTab[sym][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25137 = (object)*(((s1_ptr)_2)->base + _sym_48816);
    _2 = (object)SEQ_PTR(_25137);
    _25138 = (object)*(((s1_ptr)_2)->base + 2LL);
    _25137 = NOVALUE;
    Ref(_25138);
    return _25138;
    ;
}


object _53sym_block(object _sym_48824)
{
    object _25140 = NOVALUE;
    object _25139 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1286		return SymTab[sym][S_BLOCK]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25139 = (object)*(((s1_ptr)_2)->base + _sym_48824);
    _2 = (object)SEQ_PTR(_25139);
    if (!IS_ATOM_INT(_12S_BLOCK_19884)){
        _25140 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_BLOCK_19884)->dbl));
    }
    else{
        _25140 = (object)*(((s1_ptr)_2)->base + _12S_BLOCK_19884);
    }
    _25139 = NOVALUE;
    Ref(_25140);
    return _25140;
    ;
}


object _53sym_next_in_block(object _sym_48832)
{
    object _25142 = NOVALUE;
    object _25141 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1290		return SymTab[sym][S_NEXT_IN_BLOCK]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25141 = (object)*(((s1_ptr)_2)->base + _sym_48832);
    _2 = (object)SEQ_PTR(_25141);
    if (!IS_ATOM_INT(_12S_NEXT_IN_BLOCK_19856)){
        _25142 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NEXT_IN_BLOCK_19856)->dbl));
    }
    else{
        _25142 = (object)*(((s1_ptr)_2)->base + _12S_NEXT_IN_BLOCK_19856);
    }
    _25141 = NOVALUE;
    Ref(_25142);
    return _25142;
    ;
}


object _53sym_usage(object _sym_48840)
{
    object _25144 = NOVALUE;
    object _25143 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1294		return SymTab[sym][S_USAGE]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _25143 = (object)*(((s1_ptr)_2)->base + _sym_48840);
    _2 = (object)SEQ_PTR(_25143);
    _25144 = (object)*(((s1_ptr)_2)->base + 5LL);
    _25143 = NOVALUE;
    Ref(_25144);
    return _25144;
    ;
}



// 0xAF6C1C78
