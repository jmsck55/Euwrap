// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _68intoptions()
{
    object _pause_msg_64717 = NOVALUE;
    object _opts_array_64728 = NOVALUE;
    object _opts_64733 = NOVALUE;
    object _opt_keys_64742 = NOVALUE;
    object _option_w_64744 = NOVALUE;
    object _key_64748 = NOVALUE;
    object _val_64750 = NOVALUE;
    object _31862 = NOVALUE;
    object _31860 = NOVALUE;
    object _31859 = NOVALUE;
    object _31858 = NOVALUE;
    object _31857 = NOVALUE;
    object _31856 = NOVALUE;
    object _31855 = NOVALUE;
    object _31854 = NOVALUE;
    object _31853 = NOVALUE;
    object _31852 = NOVALUE;
    object _31851 = NOVALUE;
    object _31846 = NOVALUE;
    object _31843 = NOVALUE;
    object _31841 = NOVALUE;
    object _0, _1, _2;
    

    /** intinit.e:43		sequence pause_msg = GetMsgText(MSG_PRESS_ANY_KEY_AND_WINDOW_WILL_CLOSE, 0)*/
    RefDS(_22024);
    _0 = _pause_msg_64717;
    _pause_msg_64717 = _30GetMsgText(278LL, 0LL, _22024);
    DeRef(_0);

    /** intinit.e:45		Argv = expand_config_options(Argv)*/
    RefDS(_12Argv_20237);
    _0 = _47expand_config_options(_12Argv_20237);
    DeRefDS(_12Argv_20237);
    _12Argv_20237 = _0;

    /** intinit.e:46		Argc = length(Argv)*/
    if (IS_SEQUENCE(_12Argv_20237)){
            _12Argc_20236 = SEQ_PTR(_12Argv_20237)->length;
    }
    else {
        _12Argc_20236 = 1;
    }

    /** intinit.e:48		sequence opts_array = sort( get_options() )*/
    _31841 = _47get_options();
    _0 = _opts_array_64728;
    _opts_array_64728 = _25sort(_31841, 1LL);
    DeRef(_0);
    _31841 = NOVALUE;

    /** intinit.e:50		m:map opts = cmd_parse( opts_array, */
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 10LL;
    ((intptr_t*)_2)[2] = 4LL;
    ((intptr_t*)_2)[3] = 8LL;
    RefDS(_pause_msg_64717);
    ((intptr_t*)_2)[4] = _pause_msg_64717;
    _31843 = MAKE_SEQ(_1);
    RefDS(_opts_array_64728);
    RefDS(_12Argv_20237);
    _0 = _opts_64733;
    _opts_64733 = _48cmd_parse(_opts_array_64728, _31843, _12Argv_20237);
    DeRef(_0);
    _31843 = NOVALUE;

    /** intinit.e:53		handle_common_options(opts)*/
    Ref(_opts_64733);
    _47handle_common_options(_opts_64733);

    /** intinit.e:55		sequence opt_keys = map:keys(opts)*/
    Ref(_opts_64733);
    _0 = _opt_keys_64742;
    _opt_keys_64742 = _34keys(_opts_64733, 0LL);
    DeRef(_0);

    /** intinit.e:56		integer option_w = 0*/
    _option_w_64744 = 0LL;

    /** intinit.e:58		for idx = 1 to length(opt_keys) do*/
    if (IS_SEQUENCE(_opt_keys_64742)){
            _31846 = SEQ_PTR(_opt_keys_64742)->length;
    }
    else {
        _31846 = 1;
    }
    {
        object _idx_64746;
        _idx_64746 = 1LL;
L1: 
        if (_idx_64746 > _31846){
            goto L2; // [91] 206
        }

        /** intinit.e:59			sequence key = opt_keys[idx]*/
        DeRef(_key_64748);
        _2 = (object)SEQ_PTR(_opt_keys_64742);
        _key_64748 = (object)*(((s1_ptr)_2)->base + _idx_64746);
        Ref(_key_64748);

        /** intinit.e:60			object val = map:get(opts, key)*/
        Ref(_opts_64733);
        RefDS(_key_64748);
        _0 = _val_64750;
        _val_64750 = _34get(_opts_64733, _key_64748, 0LL);
        DeRef(_0);

        /** intinit.e:62			switch key do*/
        _1 = find(_key_64748, _31849);
        switch ( _1 ){ 

            /** intinit.e:63				case "coverage" then*/
            case 1:

            /** intinit.e:64					for i = 1 to length( val ) do*/
            if (IS_SEQUENCE(_val_64750)){
                    _31851 = SEQ_PTR(_val_64750)->length;
            }
            else {
                _31851 = 1;
            }
            {
                object _i_64756;
                _i_64756 = 1LL;
L3: 
                if (_i_64756 > _31851){
                    goto L4; // [130] 153
                }

                /** intinit.e:65						add_coverage( val[i] )*/
                _2 = (object)SEQ_PTR(_val_64750);
                _31852 = (object)*(((s1_ptr)_2)->base + _i_64756);
                Ref(_31852);
                _50add_coverage(_31852);
                _31852 = NOVALUE;

                /** intinit.e:66					end for*/
                _i_64756 = _i_64756 + 1LL;
                goto L3; // [148] 137
L4: 
                ;
            }
            goto L5; // [153] 197

            /** intinit.e:68				case "coverage-db" then*/
            case 2:

            /** intinit.e:69					coverage_db( val )*/
            Ref(_val_64750);
            _50coverage_db(_val_64750);
            goto L5; // [164] 197

            /** intinit.e:71				case "coverage-erase" then*/
            case 3:

            /** intinit.e:72					new_coverage_db()*/
            _50new_coverage_db();
            goto L5; // [174] 197

            /** intinit.e:74				case "coverage-exclude" then*/
            case 4:

            /** intinit.e:75					coverage_exclude( val )*/
            Ref(_val_64750);
            _50coverage_exclude(_val_64750);
            goto L5; // [185] 197

            /** intinit.e:77				case "debugger" then*/
            case 5:

            /** intinit.e:78					external_debugger = val*/
            Ref(_val_64750);
            DeRef(_68external_debugger_64714);
            _68external_debugger_64714 = _val_64750;
        ;}L5: 
        DeRef(_key_64748);
        _key_64748 = NOVALUE;
        DeRef(_val_64750);
        _val_64750 = NOVALUE;

        /** intinit.e:81		end for*/
        _idx_64746 = _idx_64746 + 1LL;
        goto L1; // [201] 98
L2: 
        ;
    }

    /** intinit.e:83		if length(m:get(opts, cmdline:EXTRAS)) = 0 and not repl then*/
    Ref(_opts_64733);
    RefDS(_48EXTRAS_20639);
    _31853 = _34get(_opts_64733, _48EXTRAS_20639, 0LL);
    if (IS_SEQUENCE(_31853)){
            _31854 = SEQ_PTR(_31853)->length;
    }
    else {
        _31854 = 1;
    }
    DeRef(_31853);
    _31853 = NOVALUE;
    _31855 = (_31854 == 0LL);
    _31854 = NOVALUE;
    if (_31855 == 0) {
        goto L6; // [223] 282
    }
    _31857 = (0LL == 0);
    if (_31857 == 0)
    {
        DeRef(_31857);
        _31857 = NOVALUE;
        goto L6; // [233] 282
    }
    else{
        DeRef(_31857);
        _31857 = NOVALUE;
    }

    /** intinit.e:84			show_banner()*/
    _47show_banner();

    /** intinit.e:85			ShowMsg(2, ERROR_MUST_SPECIFY_THE_FILE_TO_BE_INTERPRETED_ON_THE_COMMAND_LINE)*/
    RefDS(_22024);
    _30ShowMsg(2LL, 249LL, _22024, 1LL);

    /** intinit.e:87			if not batch_job and not test_only then*/
    _31858 = (_12batch_job_20239 == 0);
    if (_31858 == 0) {
        goto L7; // [257] 277
    }
    _31860 = (_12test_only_20238 == 0);
    if (_31860 == 0)
    {
        DeRef(_31860);
        _31860 = NOVALUE;
        goto L7; // [267] 277
    }
    else{
        DeRef(_31860);
        _31860 = NOVALUE;
    }

    /** intinit.e:88				maybe_any_key(pause_msg)*/
    RefDS(_pause_msg_64717);
    _38maybe_any_key(_pause_msg_64717, 1LL);
L7: 

    /** intinit.e:91			abort(1)*/
    UserCleanup(1LL);
L6: 

    /** intinit.e:94		OpDefines &= { "EUI" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_31861);
    ((intptr_t*)_2)[1] = _31861;
    _31862 = MAKE_SEQ(_1);
    Concat((object_ptr)&_12OpDefines_20300, _12OpDefines_20300, _31862);
    DeRefDS(_31862);
    _31862 = NOVALUE;

    /** intinit.e:96		finalize_command_line(opts)*/
    Ref(_opts_64733);
    _47finalize_command_line(_opts_64733);

    /** intinit.e:97	end procedure*/
    DeRef(_pause_msg_64717);
    DeRef(_opts_array_64728);
    DeRef(_opts_64733);
    DeRef(_opt_keys_64742);
    DeRef(_31858);
    _31858 = NOVALUE;
    _31853 = NOVALUE;
    DeRef(_31855);
    _31855 = NOVALUE;
    return;
    ;
}



// 0x0A27E38C
