// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _17get_bytes(object _fn_7379, object _n_7380)
{
    object _s_7381 = NOVALUE;
    object _c_7382 = NOVALUE;
    object _first_7383 = NOVALUE;
    object _last_7384 = NOVALUE;
    object _4065 = NOVALUE;
    object _4062 = NOVALUE;
    object _4060 = NOVALUE;
    object _4059 = NOVALUE;
    object _4058 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_n_7380)) {
        _1 = (object)(DBL_PTR(_n_7380)->dbl);
        DeRefDS(_n_7380);
        _n_7380 = _1;
    }

    /** io.e:455		if n = 0 then*/
    if (_n_7380 != 0LL)
    goto L1; // [7] 18

    /** io.e:456			return {}*/
    RefDS(_5);
    DeRefi(_s_7381);
    return _5;
L1: 

    /** io.e:459		c = getc(fn)*/
    if (_fn_7379 != last_r_file_no) {
        last_r_file_ptr = which_file(_fn_7379, EF_READ);
        last_r_file_no = _fn_7379;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_7382 = getc((FILE*)xstdin);
        }
        else{
            _c_7382 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_7382 = getc(last_r_file_ptr);
    }

    /** io.e:460		if c = EOF then*/
    if (_c_7382 != -1LL)
    goto L2; // [25] 36

    /** io.e:461			return {}*/
    RefDS(_5);
    DeRefi(_s_7381);
    return _5;
L2: 

    /** io.e:464		s = repeat(c, n)*/
    DeRefi(_s_7381);
    _s_7381 = Repeat(_c_7382, _n_7380);

    /** io.e:466		last = 1*/
    _last_7384 = 1LL;

    /** io.e:467		while last < n do*/
L3: 
    if (_last_7384 >= _n_7380)
    goto L4; // [52] 159

    /** io.e:469			first = last+1*/
    _first_7383 = _last_7384 + 1;

    /** io.e:470			last  = last+CHUNK*/
    _last_7384 = _last_7384 + 100LL;

    /** io.e:471			if last > n then*/
    if (_last_7384 <= _n_7380)
    goto L5; // [70] 80

    /** io.e:472				last = n*/
    _last_7384 = _n_7380;
L5: 

    /** io.e:474			for i = first to last do*/
    _4058 = _last_7384;
    {
        object _i_7398;
        _i_7398 = _first_7383;
L6: 
        if (_i_7398 > _4058){
            goto L7; // [85] 108
        }

        /** io.e:475				s[i] = getc(fn)*/
        if (_fn_7379 != last_r_file_no) {
            last_r_file_ptr = which_file(_fn_7379, EF_READ);
            last_r_file_no = _fn_7379;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4059 = getc((FILE*)xstdin);
            }
            else{
                _4059 = getc(last_r_file_ptr);
            }
        }
        else{
            _4059 = getc(last_r_file_ptr);
        }
        _2 = (object)SEQ_PTR(_s_7381);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _s_7381 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_7398);
        *(intptr_t *)_2 = _4059;
        if( _1 != _4059 ){
        }
        _4059 = NOVALUE;

        /** io.e:476			end for*/
        _i_7398 = _i_7398 + 1LL;
        goto L6; // [103] 92
L7: 
        ;
    }

    /** io.e:478			if s[last] = EOF then*/
    _2 = (object)SEQ_PTR(_s_7381);
    _4060 = (object)*(((s1_ptr)_2)->base + _last_7384);
    if (_4060 != -1LL)
    goto L3; // [114] 52

    /** io.e:480				while s[last] = EOF do*/
L8: 
    _2 = (object)SEQ_PTR(_s_7381);
    _4062 = (object)*(((s1_ptr)_2)->base + _last_7384);
    if (_4062 != -1LL)
    goto L9; // [127] 142

    /** io.e:481					last -= 1*/
    _last_7384 = _last_7384 - 1LL;

    /** io.e:482				end while*/
    goto L8; // [139] 123
L9: 

    /** io.e:483				return s[1..last]*/
    rhs_slice_target = (object_ptr)&_4065;
    RHS_Slice(_s_7381, 1LL, _last_7384);
    DeRefDSi(_s_7381);
    _4060 = NOVALUE;
    _4062 = NOVALUE;
    return _4065;

    /** io.e:485		end while*/
    goto L3; // [156] 52
L4: 

    /** io.e:486		return s*/
    DeRef(_4065);
    _4065 = NOVALUE;
    _4060 = NOVALUE;
    _4062 = NOVALUE;
    return _s_7381;
    ;
}


object _17get_integer32(object _fh_7419)
{
    object _c_7420 = NOVALUE;
    object _4075 = NOVALUE;
    object _0, _1, _2;
    

    /** io.e:525		c = getc(fh)*/
    if (_fh_7419 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_7419, EF_READ);
        last_r_file_no = _fh_7419;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_7420 = getc((FILE*)xstdin);
        }
        else{
            _c_7420 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_7420 = getc(last_r_file_ptr);
    }

    /** io.e:526		poke(mem0, c)*/
    if (IS_ATOM_INT(_17mem0_7409)){
        poke_addr = (uint8_t *)_17mem0_7409;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_17mem0_7409)->dbl);
    }
    *poke_addr = (uint8_t)_c_7420;

    /** io.e:527		c = getc(fh)*/
    if (_fh_7419 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_7419, EF_READ);
        last_r_file_no = _fh_7419;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_7420 = getc((FILE*)xstdin);
        }
        else{
            _c_7420 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_7420 = getc(last_r_file_ptr);
    }

    /** io.e:528		poke(mem1, c)*/
    if (IS_ATOM_INT(_17mem1_7410)){
        poke_addr = (uint8_t *)_17mem1_7410;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_17mem1_7410)->dbl);
    }
    *poke_addr = (uint8_t)_c_7420;

    /** io.e:529		c = getc(fh)*/
    if (_fh_7419 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_7419, EF_READ);
        last_r_file_no = _fh_7419;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_7420 = getc((FILE*)xstdin);
        }
        else{
            _c_7420 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_7420 = getc(last_r_file_ptr);
    }

    /** io.e:530		poke(mem2, c)*/
    if (IS_ATOM_INT(_17mem2_7411)){
        poke_addr = (uint8_t *)_17mem2_7411;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_17mem2_7411)->dbl);
    }
    *poke_addr = (uint8_t)_c_7420;

    /** io.e:531		c = getc(fh)*/
    if (_fh_7419 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_7419, EF_READ);
        last_r_file_no = _fh_7419;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_7420 = getc((FILE*)xstdin);
        }
        else{
            _c_7420 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_7420 = getc(last_r_file_ptr);
    }

    /** io.e:532		if c = -1 then*/
    if (_c_7420 != -1LL)
    goto L1; // [46] 57

    /** io.e:533			return -1*/
    return -1LL;
L1: 

    /** io.e:535		poke(mem3, c)*/
    if (IS_ATOM_INT(_17mem3_7412)){
        poke_addr = (uint8_t *)_17mem3_7412;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_17mem3_7412)->dbl);
    }
    *poke_addr = (uint8_t)_c_7420;

    /** io.e:536		return peek4u(mem0)*/
    if (IS_ATOM_INT(_17mem0_7409)) {
        _4075 = (object)*(uint32_t *)_17mem0_7409;
        if ((uintptr_t)_4075 > (uintptr_t)MAXINT){
            _4075 = NewDouble((eudouble)(uintptr_t)_4075);
        }
    }
    else {
        _4075 = (object)*(uint32_t *)(uintptr_t)(DBL_PTR(_17mem0_7409)->dbl);
        if ((uintptr_t)_4075 > (uintptr_t)MAXINT){
            _4075 = NewDouble((eudouble)(uintptr_t)_4075);
        }
    }
    return _4075;
    ;
}


object _17get_integer16(object _fh_7430)
{
    object _c_7431 = NOVALUE;
    object _4079 = NOVALUE;
    object _0, _1, _2;
    

    /** io.e:568		c = getc(fh)*/
    if (_fh_7430 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_7430, EF_READ);
        last_r_file_no = _fh_7430;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_7431 = getc((FILE*)xstdin);
        }
        else{
            _c_7431 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_7431 = getc(last_r_file_ptr);
    }

    /** io.e:569		poke(mem0, c)*/
    if (IS_ATOM_INT(_17mem0_7409)){
        poke_addr = (uint8_t *)_17mem0_7409;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_17mem0_7409)->dbl);
    }
    *poke_addr = (uint8_t)_c_7431;

    /** io.e:570		c = getc(fh)*/
    if (_fh_7430 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_7430, EF_READ);
        last_r_file_no = _fh_7430;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_7431 = getc((FILE*)xstdin);
        }
        else{
            _c_7431 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_7431 = getc(last_r_file_ptr);
    }

    /** io.e:571		if c = -1 then*/
    if (_c_7431 != -1LL)
    goto L1; // [22] 33

    /** io.e:572			return -1*/
    return -1LL;
L1: 

    /** io.e:574		poke(mem1, c)*/
    if (IS_ATOM_INT(_17mem1_7410)){
        poke_addr = (uint8_t *)_17mem1_7410;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_17mem1_7410)->dbl);
    }
    *poke_addr = (uint8_t)_c_7431;

    /** io.e:575		return peek2u(mem0)*/
    if (IS_ATOM_INT(_17mem0_7409)) {
        _4079 = *(uint16_t *)_17mem0_7409;
    }
    else {
        _4079 = *(uint16_t *)(uintptr_t)(DBL_PTR(_17mem0_7409)->dbl);
    }
    return _4079;
    ;
}


object _17seek(object _fn_7526, object _pos_7527)
{
    object _4125 = NOVALUE;
    object _4124 = NOVALUE;
    object _0, _1, _2;
    

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_7527);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _fn_7526;
    ((intptr_t *)_2)[2] = _pos_7527;
    _4124 = MAKE_SEQ(_1);
    _4125 = machine(19LL, _4124);
    DeRefDS(_4124);
    _4124 = NOVALUE;
    DeRef(_pos_7527);
    return _4125;
    ;
}


object _17where(object _fn_7532)
{
    object _4126 = NOVALUE;
    object _0, _1, _2;
    

    /** io.e:932		return machine_func(M_WHERE, fn)*/
    _4126 = machine(20LL, _fn_7532);
    return _4126;
    ;
}


void _17flush(object _fn_7536)
{
    object _0, _1, _2;
    

    /** io.e:975		machine_proc(M_FLUSH, fn)*/
    machine(60LL, _fn_7536);

    /** io.e:976	end procedure*/
    return;
    ;
}


object _17read_lines(object _file_7551)
{
    object _fn_7552 = NOVALUE;
    object _ret_7553 = NOVALUE;
    object _y_7554 = NOVALUE;
    object _4156 = NOVALUE;
    object _4155 = NOVALUE;
    object _4154 = NOVALUE;
    object _4153 = NOVALUE;
    object _4148 = NOVALUE;
    object _4147 = NOVALUE;
    object _4145 = NOVALUE;
    object _4144 = NOVALUE;
    object _4143 = NOVALUE;
    object _4141 = NOVALUE;
    object _4140 = NOVALUE;
    object _4138 = NOVALUE;
    object _4137 = NOVALUE;
    object _4136 = NOVALUE;
    object _4131 = NOVALUE;
    object _4130 = NOVALUE;
    object _0, _1, _2;
    

    /** io.e:1127		if sequence(file) then*/
    _4130 = 1;
    if (_4130 == 0)
    {
        _4130 = NOVALUE;
        goto L1; // [6] 37
    }
    else{
        _4130 = NOVALUE;
    }

    /** io.e:1128			if length(file) = 0 then*/
    if (IS_SEQUENCE(_file_7551)){
            _4131 = SEQ_PTR(_file_7551)->length;
    }
    else {
        _4131 = 1;
    }
    if (_4131 != 0LL)
    goto L2; // [14] 26

    /** io.e:1129				fn = 0*/
    DeRef(_fn_7552);
    _fn_7552 = 0LL;
    goto L3; // [23] 43
L2: 

    /** io.e:1131				fn = open(file, "r")*/
    DeRef(_fn_7552);
    _fn_7552 = EOpen(_file_7551, _4133, 0LL);
    goto L3; // [34] 43
L1: 

    /** io.e:1134			fn = file*/
    Ref(_file_7551);
    DeRef(_fn_7552);
    _fn_7552 = _file_7551;
L3: 

    /** io.e:1136		if fn < 0 then return -1 end if*/
    if (binary_op_a(GREATEREQ, _fn_7552, 0LL)){
        goto L4; // [47] 56
    }
    DeRef(_file_7551);
    DeRef(_fn_7552);
    DeRef(_ret_7553);
    DeRefi(_y_7554);
    return -1LL;
L4: 

    /** io.e:1138		ret = {}*/
    RefDS(_5);
    DeRef(_ret_7553);
    _ret_7553 = _5;

    /** io.e:1139		while sequence(y) with entry do*/
    goto L5; // [63] 162
L6: 
    _4136 = IS_SEQUENCE(_y_7554);
    if (_4136 == 0)
    {
        _4136 = NOVALUE;
        goto L7; // [71] 172
    }
    else{
        _4136 = NOVALUE;
    }

    /** io.e:1140			if y[$] = '\n' then*/
    if (IS_SEQUENCE(_y_7554)){
            _4137 = SEQ_PTR(_y_7554)->length;
    }
    else {
        _4137 = 1;
    }
    _2 = (object)SEQ_PTR(_y_7554);
    _4138 = (object)*(((s1_ptr)_2)->base + _4137);
    if (_4138 != 10LL)
    goto L8; // [83] 141

    /** io.e:1141				y = y[1..$-1]*/
    if (IS_SEQUENCE(_y_7554)){
            _4140 = SEQ_PTR(_y_7554)->length;
    }
    else {
        _4140 = 1;
    }
    _4141 = _4140 - 1LL;
    _4140 = NOVALUE;
    rhs_slice_target = (object_ptr)&_y_7554;
    RHS_Slice(_y_7554, 1LL, _4141);

    /** io.e:1142				ifdef UNIX then*/

    /** io.e:1143					if length(y) then*/
    if (IS_SEQUENCE(_y_7554)){
            _4143 = SEQ_PTR(_y_7554)->length;
    }
    else {
        _4143 = 1;
    }
    if (_4143 == 0)
    {
        _4143 = NOVALUE;
        goto L9; // [108] 140
    }
    else{
        _4143 = NOVALUE;
    }

    /** io.e:1144						if y[$] = '\r' then*/
    if (IS_SEQUENCE(_y_7554)){
            _4144 = SEQ_PTR(_y_7554)->length;
    }
    else {
        _4144 = 1;
    }
    _2 = (object)SEQ_PTR(_y_7554);
    _4145 = (object)*(((s1_ptr)_2)->base + _4144);
    if (_4145 != 13LL)
    goto LA; // [120] 139

    /** io.e:1145							y = y[1..$-1]*/
    if (IS_SEQUENCE(_y_7554)){
            _4147 = SEQ_PTR(_y_7554)->length;
    }
    else {
        _4147 = 1;
    }
    _4148 = _4147 - 1LL;
    _4147 = NOVALUE;
    rhs_slice_target = (object_ptr)&_y_7554;
    RHS_Slice(_y_7554, 1LL, _4148);
LA: 
L9: 
L8: 

    /** io.e:1150			ret = append(ret, y)*/
    Ref(_y_7554);
    Append(&_ret_7553, _ret_7553, _y_7554);

    /** io.e:1151			if fn = 0 then*/
    if (binary_op_a(NOTEQ, _fn_7552, 0LL)){
        goto LB; // [149] 159
    }

    /** io.e:1152				puts(2, '\n')*/
    EPuts(2LL, 10LL); // DJP 
LB: 

    /** io.e:1154		entry*/
L5: 

    /** io.e:1155			y = gets(fn)*/
    DeRefi(_y_7554);
    _y_7554 = EGets(_fn_7552);

    /** io.e:1156		end while*/
    goto L6; // [169] 66
L7: 

    /** io.e:1158		if sequence(file) and length(file) != 0 then*/
    _4153 = IS_SEQUENCE(_file_7551);
    if (_4153 == 0) {
        goto LC; // [177] 197
    }
    if (IS_SEQUENCE(_file_7551)){
            _4155 = SEQ_PTR(_file_7551)->length;
    }
    else {
        _4155 = 1;
    }
    _4156 = (_4155 != 0LL);
    _4155 = NOVALUE;
    if (_4156 == 0)
    {
        DeRef(_4156);
        _4156 = NOVALUE;
        goto LC; // [189] 197
    }
    else{
        DeRef(_4156);
        _4156 = NOVALUE;
    }

    /** io.e:1159			close(fn)*/
    if (IS_ATOM_INT(_fn_7552))
    EClose(_fn_7552);
    else
    EClose((object)DBL_PTR(_fn_7552)->dbl);
LC: 

    /** io.e:1162		return ret*/
    DeRef(_file_7551);
    DeRef(_fn_7552);
    DeRefi(_y_7554);
    DeRef(_4141);
    _4141 = NOVALUE;
    DeRef(_4148);
    _4148 = NOVALUE;
    _4138 = NOVALUE;
    _4145 = NOVALUE;
    return _ret_7553;
    ;
}


object _17write_lines(object _file_7646, object _lines_7647)
{
    object _fn_7648 = NOVALUE;
    object _4193 = NOVALUE;
    object _4192 = NOVALUE;
    object _4191 = NOVALUE;
    object _4187 = NOVALUE;
    object _0, _1, _2;
    

    /** io.e:1285		if sequence(file) then*/
    _4187 = 1;
    if (_4187 == 0)
    {
        _4187 = NOVALUE;
        goto L1; // [8] 21
    }
    else{
        _4187 = NOVALUE;
    }

    /** io.e:1286	    	fn = open(file, "w")*/
    DeRef(_fn_7648);
    _fn_7648 = EOpen(_file_7646, _4188, 0LL);
    goto L2; // [18] 27
L1: 

    /** io.e:1288			fn = file*/
    Ref(_file_7646);
    DeRef(_fn_7648);
    _fn_7648 = _file_7646;
L2: 

    /** io.e:1290		if fn < 0 then return -1 end if*/
    if (binary_op_a(GREATEREQ, _fn_7648, 0LL)){
        goto L3; // [31] 40
    }
    DeRef(_file_7646);
    DeRefDS(_lines_7647);
    DeRef(_fn_7648);
    return -1LL;
L3: 

    /** io.e:1292		for i = 1 to length(lines) do*/
    if (IS_SEQUENCE(_lines_7647)){
            _4191 = SEQ_PTR(_lines_7647)->length;
    }
    else {
        _4191 = 1;
    }
    {
        object _i_7657;
        _i_7657 = 1LL;
L4: 
        if (_i_7657 > _4191){
            goto L5; // [45] 73
        }

        /** io.e:1293			puts(fn, lines[i])*/
        _2 = (object)SEQ_PTR(_lines_7647);
        _4192 = (object)*(((s1_ptr)_2)->base + _i_7657);
        EPuts(_fn_7648, _4192); // DJP 
        _4192 = NOVALUE;

        /** io.e:1294			puts(fn, '\n')*/
        EPuts(_fn_7648, 10LL); // DJP 

        /** io.e:1295		end for*/
        _i_7657 = _i_7657 + 1LL;
        goto L4; // [68] 52
L5: 
        ;
    }

    /** io.e:1297		if sequence(file) then*/
    _4193 = IS_SEQUENCE(_file_7646);
    if (_4193 == 0)
    {
        _4193 = NOVALUE;
        goto L6; // [78] 86
    }
    else{
        _4193 = NOVALUE;
    }

    /** io.e:1298			close(fn)*/
    if (IS_ATOM_INT(_fn_7648))
    EClose(_fn_7648);
    else
    EClose((object)DBL_PTR(_fn_7648)->dbl);
L6: 

    /** io.e:1301		return 1*/
    DeRef(_file_7646);
    DeRefDS(_lines_7647);
    DeRef(_fn_7648);
    return 1LL;
    ;
}


void _17writef(object _fm_7769, object _data_7770, object _fn_7771, object _data_not_string_7772)
{
    object _real_fn_7773 = NOVALUE;
    object _close_fn_7774 = NOVALUE;
    object _out_style_7775 = NOVALUE;
    object _ts_7778 = NOVALUE;
    object _msg_inlined_crash_at_163_7803 = NOVALUE;
    object _data_inlined_crash_at_160_7802 = NOVALUE;
    object _4260 = NOVALUE;
    object _4258 = NOVALUE;
    object _4257 = NOVALUE;
    object _4256 = NOVALUE;
    object _4250 = NOVALUE;
    object _4249 = NOVALUE;
    object _4248 = NOVALUE;
    object _4247 = NOVALUE;
    object _4246 = NOVALUE;
    object _4245 = NOVALUE;
    object _4243 = NOVALUE;
    object _4242 = NOVALUE;
    object _4241 = NOVALUE;
    object _0, _1, _2;
    

    /** io.e:1608		integer real_fn = 0*/
    _real_fn_7773 = 0LL;

    /** io.e:1609		integer close_fn = 0*/
    _close_fn_7774 = 0LL;

    /** io.e:1610		sequence out_style = "w"*/
    RefDS(_4188);
    DeRefi(_out_style_7775);
    _out_style_7775 = _4188;

    /** io.e:1612		if integer(fm) then*/
    _4241 = 1;
    if (_4241 == 0)
    {
        _4241 = NOVALUE;
        goto L1; // [23] 49
    }
    else{
        _4241 = NOVALUE;
    }

    /** io.e:1613			object ts*/

    /** io.e:1615			ts = fm*/
    _ts_7778 = _fm_7769;

    /** io.e:1616			fm = data*/
    RefDS(_data_7770);
    _fm_7769 = _data_7770;

    /** io.e:1617			data = fn*/
    RefDS(_fn_7771);
    DeRefDS(_data_7770);
    _data_7770 = _fn_7771;

    /** io.e:1618			fn = ts*/
    DeRefDS(_fn_7771);
    _fn_7771 = _ts_7778;
L1: 

    /** io.e:1621		if sequence(fn) then*/
    _4242 = IS_SEQUENCE(_fn_7771);
    if (_4242 == 0)
    {
        _4242 = NOVALUE;
        goto L2; // [56] 191
    }
    else{
        _4242 = NOVALUE;
    }

    /** io.e:1622			if length(fn) = 2 then*/
    if (IS_SEQUENCE(_fn_7771)){
            _4243 = SEQ_PTR(_fn_7771)->length;
    }
    else {
        _4243 = 1;
    }
    if (_4243 != 2LL)
    goto L3; // [64] 142

    /** io.e:1623				if sequence(fn[1]) then*/
    _2 = (object)SEQ_PTR(_fn_7771);
    _4245 = (object)*(((s1_ptr)_2)->base + 1LL);
    _4246 = IS_SEQUENCE(_4245);
    _4245 = NOVALUE;
    if (_4246 == 0)
    {
        _4246 = NOVALUE;
        goto L4; // [77] 141
    }
    else{
        _4246 = NOVALUE;
    }

    /** io.e:1624					if equal(fn[2], 'a') then*/
    _2 = (object)SEQ_PTR(_fn_7771);
    _4247 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (_4247 == 97LL)
    _4248 = 1;
    else if (IS_ATOM_INT(_4247) && IS_ATOM_INT(97LL))
    _4248 = 0;
    else
    _4248 = (compare(_4247, 97LL) == 0);
    _4247 = NOVALUE;
    if (_4248 == 0)
    {
        _4248 = NOVALUE;
        goto L5; // [90] 103
    }
    else{
        _4248 = NOVALUE;
    }

    /** io.e:1625						out_style = "a"*/
    RefDS(_4194);
    DeRefi(_out_style_7775);
    _out_style_7775 = _4194;
    goto L6; // [100] 134
L5: 

    /** io.e:1626					elsif not equal(fn[2], "a") then*/
    _2 = (object)SEQ_PTR(_fn_7771);
    _4249 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (_4249 == _4194)
    _4250 = 1;
    else if (IS_ATOM_INT(_4249) && IS_ATOM_INT(_4194))
    _4250 = 0;
    else
    _4250 = (compare(_4249, _4194) == 0);
    _4249 = NOVALUE;
    if (_4250 != 0)
    goto L7; // [113] 126
    _4250 = NOVALUE;

    /** io.e:1627						out_style = "w"*/
    RefDS(_4188);
    DeRefi(_out_style_7775);
    _out_style_7775 = _4188;
    goto L6; // [123] 134
L7: 

    /** io.e:1629						out_style = "a"*/
    RefDS(_4194);
    DeRefi(_out_style_7775);
    _out_style_7775 = _4194;
L6: 

    /** io.e:1631					fn = fn[1]*/
    _0 = _fn_7771;
    _2 = (object)SEQ_PTR(_fn_7771);
    _fn_7771 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_fn_7771);
    DeRef(_0);
L4: 
L3: 

    /** io.e:1634			real_fn = open(fn, out_style)*/
    _real_fn_7773 = EOpen(_fn_7771, _out_style_7775, 0LL);

    /** io.e:1636			if real_fn = -1 then*/
    if (_real_fn_7773 != -1LL)
    goto L8; // [151] 183

    /** io.e:1637				error:crash("Unable to write to '%s'", {fn})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_fn_7771);
    ((intptr_t*)_2)[1] = _fn_7771;
    _4256 = MAKE_SEQ(_1);
    DeRef(_data_inlined_crash_at_160_7802);
    _data_inlined_crash_at_160_7802 = _4256;
    _4256 = NOVALUE;

    /** error.e:51		msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_163_7803);
    _msg_inlined_crash_at_163_7803 = EPrintf(-9999999, _4255, _data_inlined_crash_at_160_7802);

    /** error.e:52		machine_proc(M_CRASH, msg)*/
    machine(67LL, _msg_inlined_crash_at_163_7803);

    /** error.e:53	end procedure*/
    goto L9; // [177] 180
L9: 
    DeRef(_data_inlined_crash_at_160_7802);
    _data_inlined_crash_at_160_7802 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_163_7803);
    _msg_inlined_crash_at_163_7803 = NOVALUE;
L8: 

    /** io.e:1639			close_fn = 1*/
    _close_fn_7774 = 1LL;
    goto LA; // [188] 199
L2: 

    /** io.e:1641			real_fn = fn*/
    Ref(_fn_7771);
    _real_fn_7773 = _fn_7771;
    if (!IS_ATOM_INT(_real_fn_7773)) {
        _1 = (object)(DBL_PTR(_real_fn_7773)->dbl);
        DeRefDS(_real_fn_7773);
        _real_fn_7773 = _1;
    }
LA: 

    /** io.e:1644		if equal(data_not_string, 0) then*/
    if (_data_not_string_7772 == 0LL)
    _4257 = 1;
    else if (IS_ATOM_INT(_data_not_string_7772) && IS_ATOM_INT(0LL))
    _4257 = 0;
    else
    _4257 = (compare(_data_not_string_7772, 0LL) == 0);
    if (_4257 == 0)
    {
        _4257 = NOVALUE;
        goto LB; // [205] 225
    }
    else{
        _4257 = NOVALUE;
    }

    /** io.e:1645			if types:t_display(data) then*/
    Ref(_data_7770);
    _4258 = _9t_display(_data_7770);
    if (_4258 == 0) {
        DeRef(_4258);
        _4258 = NOVALUE;
        goto LC; // [214] 224
    }
    else {
        if (!IS_ATOM_INT(_4258) && DBL_PTR(_4258)->dbl == 0.0){
            DeRef(_4258);
            _4258 = NOVALUE;
            goto LC; // [214] 224
        }
        DeRef(_4258);
        _4258 = NOVALUE;
    }
    DeRef(_4258);
    _4258 = NOVALUE;

    /** io.e:1646				data = {data}*/
    _0 = _data_7770;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_data_7770);
    ((intptr_t*)_2)[1] = _data_7770;
    _data_7770 = MAKE_SEQ(_1);
    DeRef(_0);
LC: 
LB: 

    /** io.e:1649	    puts(real_fn, text:format( fm, data ) )*/
    Ref(_fm_7769);
    Ref(_data_7770);
    _4260 = _18format(_fm_7769, _data_7770);
    EPuts(_real_fn_7773, _4260); // DJP 
    DeRef(_4260);
    _4260 = NOVALUE;

    /** io.e:1650	    if close_fn then*/
    if (_close_fn_7774 == 0)
    {
        goto LD; // [237] 245
    }
    else{
    }

    /** io.e:1651	    	close(real_fn)*/
    EClose(_real_fn_7773);
LD: 

    /** io.e:1653	end procedure*/
    DeRef(_fm_7769);
    DeRef(_data_7770);
    DeRef(_fn_7771);
    DeRefi(_out_style_7775);
    return;
    ;
}



// 0x58D97DD4
