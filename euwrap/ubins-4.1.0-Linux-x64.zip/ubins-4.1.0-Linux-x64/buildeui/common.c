// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _13open_locked(object _file_path_11347)
{
    object _fh_11348 = NOVALUE;
    object _0, _1, _2;
    

    /** common.e:55		fh = open(file_path, "u")*/
    _fh_11348 = EOpen(_file_path_11347, _6372, 0LL);

    /** common.e:57		if fh = -1 then*/
    if (_fh_11348 != -1LL)
    goto L1; // [12] 24

    /** common.e:58			fh = open(file_path, "r")*/
    _fh_11348 = EOpen(_file_path_11347, _4133, 0LL);
L1: 

    /** common.e:61		return fh*/
    DeRefDS(_file_path_11347);
    return _fh_11348;
    ;
}


object _13get_eudir()
{
    object _possible_paths_11361 = NOVALUE;
    object _home_11366 = NOVALUE;
    object _possible_path_11380 = NOVALUE;
    object _possible_path_11394 = NOVALUE;
    object _file_check_11408 = NOVALUE;
    object _6413 = NOVALUE;
    object _6412 = NOVALUE;
    object _6411 = NOVALUE;
    object _6409 = NOVALUE;
    object _6407 = NOVALUE;
    object _6405 = NOVALUE;
    object _6404 = NOVALUE;
    object _6403 = NOVALUE;
    object _6402 = NOVALUE;
    object _6401 = NOVALUE;
    object _6399 = NOVALUE;
    object _6397 = NOVALUE;
    object _6396 = NOVALUE;
    object _6392 = NOVALUE;
    object _6386 = NOVALUE;
    object _6384 = NOVALUE;
    object _6378 = NOVALUE;
    object _6376 = NOVALUE;
    object _0, _1, _2;
    

    /** common.e:82		if sequence(eudir) then*/
    _6376 = IS_SEQUENCE(_13eudir_11343);
    if (_6376 == 0)
    {
        _6376 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _6376 = NOVALUE;
    }

    /** common.e:83			return eudir*/
    Ref(_13eudir_11343);
    DeRef(_possible_paths_11361);
    DeRefi(_home_11366);
    return _13eudir_11343;
L1: 

    /** common.e:86		eudir = getenv("EUDIR")*/
    DeRef(_13eudir_11343);
    _13eudir_11343 = EGetEnv(_6081);

    /** common.e:87		if sequence(eudir) then*/
    _6378 = IS_SEQUENCE(_13eudir_11343);
    if (_6378 == 0)
    {
        _6378 = NOVALUE;
        goto L2; // [32] 44
    }
    else{
        _6378 = NOVALUE;
    }

    /** common.e:88			return eudir*/
    Ref(_13eudir_11343);
    DeRef(_possible_paths_11361);
    DeRefi(_home_11366);
    return _13eudir_11343;
L2: 

    /** common.e:91		ifdef UNIX then*/

    /** common.e:92			sequence possible_paths = {*/
    _0 = _possible_paths_11361;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_6379);
    ((intptr_t*)_2)[1] = _6379;
    RefDS(_6380);
    ((intptr_t*)_2)[2] = _6380;
    RefDS(_6381);
    ((intptr_t*)_2)[3] = _6381;
    _possible_paths_11361 = MAKE_SEQ(_1);
    DeRef(_0);

    /** common.e:97			object home = getenv("HOME")*/
    DeRefi(_home_11366);
    _home_11366 = EGetEnv(_5729);

    /** common.e:98			if sequence(home) then*/
    _6384 = IS_SEQUENCE(_home_11366);
    if (_6384 == 0)
    {
        _6384 = NOVALUE;
        goto L3; // [64] 78
    }
    else{
        _6384 = NOVALUE;
    }

    /** common.e:99				possible_paths = append(possible_paths, home & "/euphoria")*/
    if (IS_SEQUENCE(_home_11366) && IS_ATOM(_6385)) {
    }
    else if (IS_ATOM(_home_11366) && IS_SEQUENCE(_6385)) {
        Ref(_home_11366);
        Prepend(&_6386, _6385, _home_11366);
    }
    else {
        Concat((object_ptr)&_6386, _home_11366, _6385);
    }
    RefDS(_6386);
    Append(&_possible_paths_11361, _possible_paths_11361, _6386);
    DeRefDS(_6386);
    _6386 = NOVALUE;
L3: 

    /** common.e:118		for i = 1 to length(possible_paths) do*/
    if (IS_SEQUENCE(_possible_paths_11361)){
            _6392 = SEQ_PTR(_possible_paths_11361)->length;
    }
    else {
        _6392 = 1;
    }
    {
        object _i_11378;
        _i_11378 = 1LL;
L4: 
        if (_i_11378 > _6392){
            goto L5; // [85] 144
        }

        /** common.e:119			sequence possible_path = possible_paths[i]*/
        DeRef(_possible_path_11380);
        _2 = (object)SEQ_PTR(_possible_paths_11361);
        _possible_path_11380 = (object)*(((s1_ptr)_2)->base + _i_11378);
        RefDS(_possible_path_11380);

        /** common.e:121			if file_exists(possible_path & SLASH & "include" & SLASH & "euphoria.h") then*/
        {
            object concat_list[5];

            concat_list[0] = _6395;
            concat_list[1] = 47LL;
            concat_list[2] = _6394;
            concat_list[3] = 47LL;
            concat_list[4] = _possible_path_11380;
            Concat_N((object_ptr)&_6396, concat_list, 5);
        }
        _6397 = _14file_exists(_6396);
        _6396 = NOVALUE;
        if (_6397 == 0) {
            DeRef(_6397);
            _6397 = NOVALUE;
            goto L6; // [118] 135
        }
        else {
            if (!IS_ATOM_INT(_6397) && DBL_PTR(_6397)->dbl == 0.0){
                DeRef(_6397);
                _6397 = NOVALUE;
                goto L6; // [118] 135
            }
            DeRef(_6397);
            _6397 = NOVALUE;
        }
        DeRef(_6397);
        _6397 = NOVALUE;

        /** common.e:122				eudir = possible_path*/
        RefDS(_possible_path_11380);
        DeRef(_13eudir_11343);
        _13eudir_11343 = _possible_path_11380;

        /** common.e:123				return eudir*/
        RefDS(_13eudir_11343);
        DeRefDS(_possible_path_11380);
        DeRefDS(_possible_paths_11361);
        DeRefi(_home_11366);
        return _13eudir_11343;
L6: 
        DeRef(_possible_path_11380);
        _possible_path_11380 = NOVALUE;

        /** common.e:125		end for*/
        _i_11378 = _i_11378 + 1LL;
        goto L4; // [139] 92
L5: 
        ;
    }

    /** common.e:127		possible_paths = include_paths(0)*/
    _0 = _possible_paths_11361;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_6106);
    ((intptr_t*)_2)[1] = _6106;
    RefDS(_6105);
    ((intptr_t*)_2)[2] = _6105;
    _possible_paths_11361 = MAKE_SEQ(_1);
    DeRef(_0);

    /** common.e:128		for i = 1 to length(possible_paths) do*/
    _6399 = 2;
    {
        object _i_11392;
        _i_11392 = 1LL;
L7: 
        if (_i_11392 > 2LL){
            goto L8; // [156] 281
        }

        /** common.e:129			sequence possible_path = possible_paths[i]*/
        DeRef(_possible_path_11394);
        _2 = (object)SEQ_PTR(_possible_paths_11361);
        _possible_path_11394 = (object)*(((s1_ptr)_2)->base + _i_11392);
        RefDS(_possible_path_11394);

        /** common.e:130			if equal(possible_path[$], SLASH) then*/
        if (IS_SEQUENCE(_possible_path_11394)){
                _6401 = SEQ_PTR(_possible_path_11394)->length;
        }
        else {
            _6401 = 1;
        }
        _2 = (object)SEQ_PTR(_possible_path_11394);
        _6402 = (object)*(((s1_ptr)_2)->base + _6401);
        if (_6402 == 47LL)
        _6403 = 1;
        else if (IS_ATOM_INT(_6402) && IS_ATOM_INT(47LL))
        _6403 = 0;
        else
        _6403 = (compare(_6402, 47LL) == 0);
        _6402 = NOVALUE;
        if (_6403 == 0)
        {
            _6403 = NOVALUE;
            goto L9; // [186] 204
        }
        else{
            _6403 = NOVALUE;
        }

        /** common.e:131				possible_path = possible_path[1..$-1]*/
        if (IS_SEQUENCE(_possible_path_11394)){
                _6404 = SEQ_PTR(_possible_path_11394)->length;
        }
        else {
            _6404 = 1;
        }
        _6405 = _6404 - 1LL;
        _6404 = NOVALUE;
        rhs_slice_target = (object_ptr)&_possible_path_11394;
        RHS_Slice(_possible_path_11394, 1LL, _6405);
L9: 

        /** common.e:134			if not ends("include", possible_path) then*/
        RefDS(_6394);
        RefDS(_possible_path_11394);
        _6407 = _20ends(_6394, _possible_path_11394);
        if (IS_ATOM_INT(_6407)) {
            if (_6407 != 0){
                DeRef(_6407);
                _6407 = NOVALUE;
                goto LA; // [211] 221
            }
        }
        else {
            if (DBL_PTR(_6407)->dbl != 0.0){
                DeRef(_6407);
                _6407 = NOVALUE;
                goto LA; // [211] 221
            }
        }
        DeRef(_6407);
        _6407 = NOVALUE;

        /** common.e:135				continue*/
        DeRefDS(_possible_path_11394);
        _possible_path_11394 = NOVALUE;
        DeRef(_file_check_11408);
        _file_check_11408 = NOVALUE;
        goto LB; // [218] 276
LA: 

        /** common.e:138			sequence file_check = possible_path*/
        RefDS(_possible_path_11394);
        DeRef(_file_check_11408);
        _file_check_11408 = _possible_path_11394;

        /** common.e:139			file_check &= SLASH & "euphoria.h"*/
        Prepend(&_6409, _6395, 47LL);
        Concat((object_ptr)&_file_check_11408, _file_check_11408, _6409);
        DeRefDS(_6409);
        _6409 = NOVALUE;

        /** common.e:141			if file_exists(file_check) then*/
        RefDS(_file_check_11408);
        _6411 = _14file_exists(_file_check_11408);
        if (_6411 == 0) {
            DeRef(_6411);
            _6411 = NOVALUE;
            goto LC; // [246] 272
        }
        else {
            if (!IS_ATOM_INT(_6411) && DBL_PTR(_6411)->dbl == 0.0){
                DeRef(_6411);
                _6411 = NOVALUE;
                goto LC; // [246] 272
            }
            DeRef(_6411);
            _6411 = NOVALUE;
        }
        DeRef(_6411);
        _6411 = NOVALUE;

        /** common.e:142				eudir = possible_path[1..$-8] -- strip SLASH & "include"*/
        if (IS_SEQUENCE(_possible_path_11394)){
                _6412 = SEQ_PTR(_possible_path_11394)->length;
        }
        else {
            _6412 = 1;
        }
        _6413 = _6412 - 8LL;
        _6412 = NOVALUE;
        rhs_slice_target = (object_ptr)&_13eudir_11343;
        RHS_Slice(_possible_path_11394, 1LL, _6413);

        /** common.e:143				return eudir*/
        RefDS(_13eudir_11343);
        DeRefDS(_possible_path_11394);
        DeRefDS(_file_check_11408);
        DeRef(_possible_paths_11361);
        DeRefi(_home_11366);
        _6413 = NOVALUE;
        DeRef(_6405);
        _6405 = NOVALUE;
        return _13eudir_11343;
LC: 
        DeRef(_possible_path_11394);
        _possible_path_11394 = NOVALUE;
        DeRef(_file_check_11408);
        _file_check_11408 = NOVALUE;

        /** common.e:145		end for*/
LB: 
        _i_11392 = _i_11392 + 1LL;
        goto L7; // [276] 163
L8: 
        ;
    }

    /** common.e:147		return ""*/
    RefDS(_5);
    DeRef(_possible_paths_11361);
    DeRefi(_home_11366);
    DeRef(_6413);
    _6413 = NOVALUE;
    DeRef(_6405);
    _6405 = NOVALUE;
    return _5;
    ;
}


void _13set_eudir(object _new_eudir_11420)
{
    object _0, _1, _2;
    

    /** common.e:151		eudir = new_eudir*/
    RefDS(_new_eudir_11420);
    DeRef(_13eudir_11343);
    _13eudir_11343 = _new_eudir_11420;

    /** common.e:152		cmdline_eudir = 1*/
    _13cmdline_eudir_11344 = 1LL;

    /** common.e:153	end procedure*/
    DeRefDS(_new_eudir_11420);
    return;
    ;
}


object _13is_eudir_from_cmdline()
{
    object _0, _1, _2;
    

    /** common.e:156		return cmdline_eudir*/
    return _13cmdline_eudir_11344;
    ;
}



// 0x8DD5A64C
