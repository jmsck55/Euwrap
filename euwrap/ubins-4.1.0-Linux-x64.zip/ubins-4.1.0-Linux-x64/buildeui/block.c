// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _64block_type_name(object _opcode_25151)
{
    object _14065 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_opcode_25151)) {
        _1 = (object)(DBL_PTR(_opcode_25151)->dbl);
        DeRefDS(_opcode_25151);
        _opcode_25151 = _1;
    }

    /** block.e:51		switch opcode do*/
    _0 = _opcode_25151;
    switch ( _0 ){ 

        /** block.e:52			case LOOP then*/
        case 422:

        /** block.e:53				return "LOOP"*/
        RefDS(_14063);
        return _14063;
        goto L1; // [20] 63

        /** block.e:54			case PROC then*/
        case 27:

        /** block.e:55				return "PROC"*/
        RefDS(_12970);
        return _12970;
        goto L1; // [32] 63

        /** block.e:56			case FUNC then*/
        case 501:

        /** block.e:57				return "FUNC"*/
        RefDS(_14064);
        return _14064;
        goto L1; // [44] 63

        /** block.e:58			case else*/
        default:

        /** block.e:59				return opnames[opcode]*/
        _2 = (object)SEQ_PTR(_60opnames_22918);
        _14065 = (object)*(((s1_ptr)_2)->base + _opcode_25151);
        RefDS(_14065);
        return _14065;
    ;}L1: 
    ;
}


void _64check_block(object _got_25167)
{
    object _expected_25168 = NOVALUE;
    object _14073 = NOVALUE;
    object _14072 = NOVALUE;
    object _14071 = NOVALUE;
    object _14067 = NOVALUE;
    object _14066 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:64		integer expected = block_stack[$][BLOCK_OPCODE]*/
    if (IS_SEQUENCE(_64block_stack_25140)){
            _14066 = SEQ_PTR(_64block_stack_25140)->length;
    }
    else {
        _14066 = 1;
    }
    _2 = (object)SEQ_PTR(_64block_stack_25140);
    _14067 = (object)*(((s1_ptr)_2)->base + _14066);
    _2 = (object)SEQ_PTR(_14067);
    _expected_25168 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_expected_25168)){
        _expected_25168 = (object)DBL_PTR(_expected_25168)->dbl;
    }
    _14067 = NOVALUE;

    /** block.e:65		if got = FUNC then*/
    if (_got_25167 != 501LL)
    goto L1; // [24] 38

    /** block.e:66			got = PROC*/
    _got_25167 = 27LL;
L1: 

    /** block.e:68		if got != expected then*/
    if (_got_25167 == _expected_25168)
    goto L2; // [40] 66

    /** block.e:69			CompileErr( EXPECTED_END_OF_1_BLOCK_NOT_2, {block_type_name( expected ), block_type_name( got)} )*/
    _14071 = _64block_type_name(_expected_25168);
    _14072 = _64block_type_name(_got_25167);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _14071;
    ((intptr_t *)_2)[2] = _14072;
    _14073 = MAKE_SEQ(_1);
    _14072 = NOVALUE;
    _14071 = NOVALUE;
    _49CompileErr(79LL, _14073, 0LL);
    _14073 = NOVALUE;
L2: 

    /** block.e:71	end procedure*/
    return;
    ;
}


void _64Block_var(object _sym_25186)
{
    object _block_25187 = NOVALUE;
    object _14094 = NOVALUE;
    object _14093 = NOVALUE;
    object _14092 = NOVALUE;
    object _14090 = NOVALUE;
    object _14089 = NOVALUE;
    object _14087 = NOVALUE;
    object _14086 = NOVALUE;
    object _14085 = NOVALUE;
    object _14084 = NOVALUE;
    object _14083 = NOVALUE;
    object _14082 = NOVALUE;
    object _14081 = NOVALUE;
    object _14079 = NOVALUE;
    object _14077 = NOVALUE;
    object _14076 = NOVALUE;
    object _14074 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_25186)) {
        _1 = (object)(DBL_PTR(_sym_25186)->dbl);
        DeRefDS(_sym_25186);
        _sym_25186 = _1;
    }

    /** block.e:75		sequence block = block_stack[$]*/
    if (IS_SEQUENCE(_64block_stack_25140)){
            _14074 = SEQ_PTR(_64block_stack_25140)->length;
    }
    else {
        _14074 = 1;
    }
    DeRef(_block_25187);
    _2 = (object)SEQ_PTR(_64block_stack_25140);
    _block_25187 = (object)*(((s1_ptr)_2)->base + _14074);
    Ref(_block_25187);

    /** block.e:76		block_stack[$] = 0*/
    if (IS_SEQUENCE(_64block_stack_25140)){
            _14076 = SEQ_PTR(_64block_stack_25140)->length;
    }
    else {
        _14076 = 1;
    }
    _2 = (object)SEQ_PTR(_64block_stack_25140);
    _2 = (object)(((s1_ptr)_2)->base + _14076);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** block.e:77		if length(block_stack) > 1 then*/
    if (IS_SEQUENCE(_64block_stack_25140)){
            _14077 = SEQ_PTR(_64block_stack_25140)->length;
    }
    else {
        _14077 = 1;
    }
    if (_14077 <= 1LL)
    goto L1; // [34] 58

    /** block.e:79			SymTab[sym][S_BLOCK] = block[BLOCK_SYM]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_25186 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_block_25187);
    _14081 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_14081);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_BLOCK_19884))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_BLOCK_19884)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_BLOCK_19884);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14081;
    if( _1 != _14081 ){
        DeRef(_1);
    }
    _14081 = NOVALUE;
    _14079 = NOVALUE;
L1: 

    /** block.e:82		if length(block[BLOCK_VARS]) then*/
    _2 = (object)SEQ_PTR(_block_25187);
    _14082 = (object)*(((s1_ptr)_2)->base + 6LL);
    if (IS_SEQUENCE(_14082)){
            _14083 = SEQ_PTR(_14082)->length;
    }
    else {
        _14083 = 1;
    }
    _14082 = NOVALUE;
    if (_14083 == 0)
    {
        _14083 = NOVALUE;
        goto L2; // [67] 99
    }
    else{
        _14083 = NOVALUE;
    }

    /** block.e:83			SymTab[block[BLOCK_VARS][$]][S_NEXT_IN_BLOCK] = sym*/
    _2 = (object)SEQ_PTR(_block_25187);
    _14084 = (object)*(((s1_ptr)_2)->base + 6LL);
    if (IS_SEQUENCE(_14084)){
            _14085 = SEQ_PTR(_14084)->length;
    }
    else {
        _14085 = 1;
    }
    _2 = (object)SEQ_PTR(_14084);
    _14086 = (object)*(((s1_ptr)_2)->base + _14085);
    _14084 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_14086))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14086)->dbl));
    else
    _3 = (object)(_14086 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_NEXT_IN_BLOCK_19856))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NEXT_IN_BLOCK_19856)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_NEXT_IN_BLOCK_19856);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_25186;
    DeRef(_1);
    _14087 = NOVALUE;
    goto L3; // [96] 119
L2: 

    /** block.e:85			SymTab[block[BLOCK_SYM]][S_NEXT_IN_BLOCK] = sym*/
    _2 = (object)SEQ_PTR(_block_25187);
    _14089 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_14089))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14089)->dbl));
    else
    _3 = (object)(_14089 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_NEXT_IN_BLOCK_19856))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NEXT_IN_BLOCK_19856)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_NEXT_IN_BLOCK_19856);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_25186;
    DeRef(_1);
    _14090 = NOVALUE;
L3: 

    /** block.e:88		block[BLOCK_VARS] &= sym*/
    _2 = (object)SEQ_PTR(_block_25187);
    _14092 = (object)*(((s1_ptr)_2)->base + 6LL);
    if (IS_SEQUENCE(_14092) && IS_ATOM(_sym_25186)) {
        Append(&_14093, _14092, _sym_25186);
    }
    else if (IS_ATOM(_14092) && IS_SEQUENCE(_sym_25186)) {
    }
    else {
        Concat((object_ptr)&_14093, _14092, _sym_25186);
        _14092 = NOVALUE;
    }
    _14092 = NOVALUE;
    _2 = (object)SEQ_PTR(_block_25187);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25187 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14093;
    if( _1 != _14093 ){
        DeRef(_1);
    }
    _14093 = NOVALUE;

    /** block.e:90		block_stack[$] = block*/
    if (IS_SEQUENCE(_64block_stack_25140)){
            _14094 = SEQ_PTR(_64block_stack_25140)->length;
    }
    else {
        _14094 = 1;
    }
    RefDS(_block_25187);
    _2 = (object)SEQ_PTR(_64block_stack_25140);
    _2 = (object)(((s1_ptr)_2)->base + _14094);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _block_25187;
    DeRef(_1);

    /** block.e:91		ifdef BDEBUG then*/

    /** block.e:96	end procedure*/
    DeRefDS(_block_25187);
    _14089 = NOVALUE;
    _14086 = NOVALUE;
    _14082 = NOVALUE;
    return;
    ;
}


void _64NewBlock(object _opcode_25221, object _block_label_25222)
{
    object _block_25240 = NOVALUE;
    object _14108 = NOVALUE;
    object _14107 = NOVALUE;
    object _14106 = NOVALUE;
    object _14104 = NOVALUE;
    object _14102 = NOVALUE;
    object _14101 = NOVALUE;
    object _14099 = NOVALUE;
    object _14098 = NOVALUE;
    object _14096 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** block.e:101		SymTab = append( SymTab, repeat( 0, SIZEOF_BLOCK_ENTRY ) )*/
    _14096 = Repeat(0LL, _12SIZEOF_BLOCK_ENTRY_19996);
    RefDS(_14096);
    Append(&_13SymTab_11316, _13SymTab_11316, _14096);
    DeRefDS(_14096);
    _14096 = NOVALUE;

    /** block.e:102		SymTab[$][S_MODE] = M_BLOCK*/
    if (IS_SEQUENCE(_13SymTab_11316)){
            _14098 = SEQ_PTR(_13SymTab_11316)->length;
    }
    else {
        _14098 = 1;
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14098 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 4LL;
    DeRef(_1);
    _14099 = NOVALUE;

    /** block.e:103		SymTab[$][S_FIRST_LINE] = gline_number*/
    if (IS_SEQUENCE(_13SymTab_11316)){
            _14101 = SEQ_PTR(_13SymTab_11316)->length;
    }
    else {
        _14101 = 1;
    }
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14101 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_FIRST_LINE_19889))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FIRST_LINE_19889)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_FIRST_LINE_19889);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12gline_number_20231;
    DeRef(_1);
    _14102 = NOVALUE;

    /** block.e:105		sequence block = repeat( 0, BLOCK_SIZE-1 )*/
    _14104 = 6LL;
    DeRef(_block_25240);
    _block_25240 = Repeat(0LL, 6LL);
    _14104 = NOVALUE;

    /** block.e:106		block[BLOCK_SYM]    = length(SymTab)*/
    if (IS_SEQUENCE(_13SymTab_11316)){
            _14106 = SEQ_PTR(_13SymTab_11316)->length;
    }
    else {
        _14106 = 1;
    }
    _2 = (object)SEQ_PTR(_block_25240);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25240 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    *(intptr_t *)_2 = _14106;
    if( _1 != _14106 ){
    }
    _14106 = NOVALUE;

    /** block.e:107		block[BLOCK_OPCODE] = opcode*/
    _2 = (object)SEQ_PTR(_block_25240);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25240 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    *(intptr_t *)_2 = _opcode_25221;

    /** block.e:108		block[BLOCK_LABEL]  = block_label*/
    Ref(_block_label_25222);
    _2 = (object)SEQ_PTR(_block_25240);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25240 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    *(intptr_t *)_2 = _block_label_25222;

    /** block.e:109		block[BLOCK_START]  = length(Code) + 1*/
    if (IS_SEQUENCE(_12Code_20315)){
            _14107 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _14107 = 1;
    }
    _14108 = _14107 + 1;
    _14107 = NOVALUE;
    _2 = (object)SEQ_PTR(_block_25240);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25240 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14108;
    if( _1 != _14108 ){
        DeRef(_1);
    }
    _14108 = NOVALUE;

    /** block.e:110		block[BLOCK_VARS]   = {}*/
    RefDS(_5);
    _2 = (object)SEQ_PTR(_block_25240);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25240 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _5;
    DeRef(_1);

    /** block.e:112		block_stack = append( block_stack, block )*/
    RefDS(_block_25240);
    Append(&_64block_stack_25140, _64block_stack_25140, _block_25240);

    /** block.e:113		current_block = length(SymTab)*/
    if (IS_SEQUENCE(_13SymTab_11316)){
            _64current_block_25147 = SEQ_PTR(_13SymTab_11316)->length;
    }
    else {
        _64current_block_25147 = 1;
    }

    /** block.e:114	end procedure*/
    DeRefi(_block_label_25222);
    DeRefDS(_block_25240);
    return;
    ;
}


void _64Start_block(object _opcode_25253, object _block_label_25254)
{
    object _last_block_25256 = NOVALUE;
    object _label_name_25284 = NOVALUE;
    object _14130 = NOVALUE;
    object _14129 = NOVALUE;
    object _14128 = NOVALUE;
    object _14125 = NOVALUE;
    object _14124 = NOVALUE;
    object _14122 = NOVALUE;
    object _14121 = NOVALUE;
    object _14120 = NOVALUE;
    object _14119 = NOVALUE;
    object _14118 = NOVALUE;
    object _14115 = NOVALUE;
    object _14113 = NOVALUE;
    object _14112 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** block.e:120		symtab_index last_block = current_block*/
    _last_block_25256 = _64current_block_25147;

    /** block.e:121		if opcode = FUNC then*/
    if (_opcode_25253 != 501LL)
    goto L1; // [16] 30

    /** block.e:122			opcode = PROC*/
    _opcode_25253 = 27LL;
L1: 

    /** block.e:124		NewBlock( opcode, block_label )*/
    Ref(_block_label_25254);
    _64NewBlock(_opcode_25253, _block_label_25254);

    /** block.e:126		if find(opcode, RTN_TOKS) then*/
    _14112 = find_from(_opcode_25253, _29RTN_TOKS_12006, 1LL);
    if (_14112 == 0)
    {
        _14112 = NOVALUE;
        goto L2; // [45] 105
    }
    else{
        _14112 = NOVALUE;
    }

    /** block.e:127			SymTab[block_label][S_BLOCK] = current_block*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_block_label_25254))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_block_label_25254)->dbl));
    else
    _3 = (object)(_block_label_25254 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_BLOCK_19884))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_BLOCK_19884)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_BLOCK_19884);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _64current_block_25147;
    DeRef(_1);
    _14113 = NOVALUE;

    /** block.e:128			SymTab[current_block][S_NAME] = sprintf("BLOCK: %s", {SymTab[block_label][S_NAME]})*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_64current_block_25147 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_block_label_25254)){
        _14118 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_block_label_25254)->dbl));
    }
    else{
        _14118 = (object)*(((s1_ptr)_2)->base + _block_label_25254);
    }
    _2 = (object)SEQ_PTR(_14118);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _14119 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _14119 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _14118 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_14119);
    ((intptr_t*)_2)[1] = _14119;
    _14120 = MAKE_SEQ(_1);
    _14119 = NOVALUE;
    _14121 = EPrintf(-9999999, _14117, _14120);
    DeRefDS(_14120);
    _14120 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_NAME_19864))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_NAME_19864);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14121;
    if( _1 != _14121 ){
        DeRef(_1);
    }
    _14121 = NOVALUE;
    _14115 = NOVALUE;
    goto L3; // [102] 185
L2: 

    /** block.e:129		elsif current_block then*/
    if (_64current_block_25147 == 0)
    {
        goto L4; // [109] 182
    }
    else{
    }

    /** block.e:135			SymTab[current_block][S_BLOCK] = last_block*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_64current_block_25147 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_BLOCK_19884))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_BLOCK_19884)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_BLOCK_19884);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _last_block_25256;
    DeRef(_1);
    _14122 = NOVALUE;

    /** block.e:136			sequence label_name = ""*/
    RefDS(_5);
    DeRefi(_label_name_25284);
    _label_name_25284 = _5;

    /** block.e:137			if sequence(block_label) then*/
    _14124 = IS_SEQUENCE(_block_label_25254);
    if (_14124 == 0)
    {
        _14124 = NOVALUE;
        goto L5; // [141] 152
    }
    else{
        _14124 = NOVALUE;
    }

    /** block.e:138				label_name = block_label*/
    Ref(_block_label_25254);
    DeRefDSi(_label_name_25284);
    _label_name_25284 = _block_label_25254;
L5: 

    /** block.e:141			SymTab[current_block][S_NAME] = sprintf( "BLOCK: %s-%s", {block_type_name(opcode), label_name})*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_64current_block_25147 + ((s1_ptr)_2)->base);
    _14128 = _64block_type_name(_opcode_25253);
    RefDS(_label_name_25284);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _14128;
    ((intptr_t *)_2)[2] = _label_name_25284;
    _14129 = MAKE_SEQ(_1);
    _14128 = NOVALUE;
    _14130 = EPrintf(-9999999, _14127, _14129);
    DeRefDS(_14129);
    _14129 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_NAME_19864))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_NAME_19864);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14130;
    if( _1 != _14130 ){
        DeRef(_1);
    }
    _14130 = NOVALUE;
    _14125 = NOVALUE;
L4: 
    DeRefi(_label_name_25284);
    _label_name_25284 = NOVALUE;
L3: 

    /** block.e:144		ifdef BDEBUG then*/

    /** block.e:153	end procedure*/
    DeRefi(_block_label_25254);
    return;
    ;
}


void _64block_label(object _label_name_25300)
{
    object _14144 = NOVALUE;
    object _14143 = NOVALUE;
    object _14142 = NOVALUE;
    object _14141 = NOVALUE;
    object _14140 = NOVALUE;
    object _14139 = NOVALUE;
    object _14137 = NOVALUE;
    object _14135 = NOVALUE;
    object _14134 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** block.e:157		block_stack[$][BLOCK_LABEL] = label_name*/
    if (IS_SEQUENCE(_64block_stack_25140)){
            _14134 = SEQ_PTR(_64block_stack_25140)->length;
    }
    else {
        _14134 = 1;
    }
    _2 = (object)SEQ_PTR(_64block_stack_25140);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _64block_stack_25140 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14134 + ((s1_ptr)_2)->base);
    RefDS(_label_name_25300);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _label_name_25300;
    DeRef(_1);
    _14135 = NOVALUE;

    /** block.e:158		SymTab[current_block][S_NAME] = sprintf( "BLOCK: %s-%s", */
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_64current_block_25147 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_64block_stack_25140)){
            _14139 = SEQ_PTR(_64block_stack_25140)->length;
    }
    else {
        _14139 = 1;
    }
    _2 = (object)SEQ_PTR(_64block_stack_25140);
    _14140 = (object)*(((s1_ptr)_2)->base + _14139);
    _2 = (object)SEQ_PTR(_14140);
    _14141 = (object)*(((s1_ptr)_2)->base + 2LL);
    _14140 = NOVALUE;
    Ref(_14141);
    _14142 = _64block_type_name(_14141);
    _14141 = NOVALUE;
    RefDS(_label_name_25300);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _14142;
    ((intptr_t *)_2)[2] = _label_name_25300;
    _14143 = MAKE_SEQ(_1);
    _14142 = NOVALUE;
    _14144 = EPrintf(-9999999, _14127, _14143);
    DeRefDS(_14143);
    _14143 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_NAME_19864))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_NAME_19864);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14144;
    if( _1 != _14144 ){
        DeRef(_1);
    }
    _14144 = NOVALUE;
    _14137 = NOVALUE;

    /** block.e:160	end procedure*/
    DeRefDS(_label_name_25300);
    return;
    ;
}


object _64pop_block()
{
    object _block_25319 = NOVALUE;
    object _block_vars_25332 = NOVALUE;
    object _14173 = NOVALUE;
    object _14171 = NOVALUE;
    object _14170 = NOVALUE;
    object _14169 = NOVALUE;
    object _14168 = NOVALUE;
    object _14166 = NOVALUE;
    object _14165 = NOVALUE;
    object _14164 = NOVALUE;
    object _14163 = NOVALUE;
    object _14162 = NOVALUE;
    object _14161 = NOVALUE;
    object _14160 = NOVALUE;
    object _14159 = NOVALUE;
    object _14158 = NOVALUE;
    object _14157 = NOVALUE;
    object _14153 = NOVALUE;
    object _14152 = NOVALUE;
    object _14150 = NOVALUE;
    object _14149 = NOVALUE;
    object _14147 = NOVALUE;
    object _14145 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** block.e:164		if not length(block_stack) then*/
    if (IS_SEQUENCE(_64block_stack_25140)){
            _14145 = SEQ_PTR(_64block_stack_25140)->length;
    }
    else {
        _14145 = 1;
    }
    if (_14145 != 0)
    goto L1; // [8] 18
    _14145 = NOVALUE;

    /** block.e:165			return 0*/
    DeRef(_block_25319);
    DeRef(_block_vars_25332);
    return 0LL;
L1: 

    /** block.e:168		sequence  block = block_stack[$]*/
    if (IS_SEQUENCE(_64block_stack_25140)){
            _14147 = SEQ_PTR(_64block_stack_25140)->length;
    }
    else {
        _14147 = 1;
    }
    DeRef(_block_25319);
    _2 = (object)SEQ_PTR(_64block_stack_25140);
    _block_25319 = (object)*(((s1_ptr)_2)->base + _14147);
    Ref(_block_25319);

    /** block.e:169		block_stack = block_stack[1..$-1]*/
    if (IS_SEQUENCE(_64block_stack_25140)){
            _14149 = SEQ_PTR(_64block_stack_25140)->length;
    }
    else {
        _14149 = 1;
    }
    _14150 = _14149 - 1LL;
    _14149 = NOVALUE;
    rhs_slice_target = (object_ptr)&_64block_stack_25140;
    RHS_Slice(_64block_stack_25140, 1LL, _14150);

    /** block.e:170		SymTab[block[BLOCK_SYM]][S_LAST_LINE] = gline_number*/
    _2 = (object)SEQ_PTR(_block_25319);
    _14152 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_14152))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14152)->dbl));
    else
    _3 = (object)(_14152 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_LAST_LINE_19894))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_LAST_LINE_19894)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_LAST_LINE_19894);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12gline_number_20231;
    DeRef(_1);
    _14153 = NOVALUE;

    /** block.e:172		ifdef BDEBUG then*/

    /** block.e:177		sequence block_vars = block[BLOCK_VARS]*/
    DeRef(_block_vars_25332);
    _2 = (object)SEQ_PTR(_block_25319);
    _block_vars_25332 = (object)*(((s1_ptr)_2)->base + 6LL);
    Ref(_block_vars_25332);

    /** block.e:178		for sx = 1 to length( block_vars ) do*/
    if (IS_SEQUENCE(_block_vars_25332)){
            _14157 = SEQ_PTR(_block_vars_25332)->length;
    }
    else {
        _14157 = 1;
    }
    {
        object _sx_25335;
        _sx_25335 = 1LL;
L2: 
        if (_sx_25335 > _14157){
            goto L3; // [83] 172
        }

        /** block.e:180			if SymTab[block_vars[sx]][S_MODE] = M_NORMAL */
        _2 = (object)SEQ_PTR(_block_vars_25332);
        _14158 = (object)*(((s1_ptr)_2)->base + _sx_25335);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!IS_ATOM_INT(_14158)){
            _14159 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14158)->dbl));
        }
        else{
            _14159 = (object)*(((s1_ptr)_2)->base + _14158);
        }
        _2 = (object)SEQ_PTR(_14159);
        _14160 = (object)*(((s1_ptr)_2)->base + 3LL);
        _14159 = NOVALUE;
        if (IS_ATOM_INT(_14160)) {
            _14161 = (_14160 == 1LL);
        }
        else {
            _14161 = binary_op(EQUALS, _14160, 1LL);
        }
        _14160 = NOVALUE;
        if (IS_ATOM_INT(_14161)) {
            if (_14161 == 0) {
                goto L4; // [114] 165
            }
        }
        else {
            if (DBL_PTR(_14161)->dbl == 0.0) {
                goto L4; // [114] 165
            }
        }
        _2 = (object)SEQ_PTR(_block_vars_25332);
        _14163 = (object)*(((s1_ptr)_2)->base + _sx_25335);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!IS_ATOM_INT(_14163)){
            _14164 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14163)->dbl));
        }
        else{
            _14164 = (object)*(((s1_ptr)_2)->base + _14163);
        }
        _2 = (object)SEQ_PTR(_14164);
        _14165 = (object)*(((s1_ptr)_2)->base + 4LL);
        _14164 = NOVALUE;
        if (IS_ATOM_INT(_14165)) {
            _14166 = (_14165 <= 5LL);
        }
        else {
            _14166 = binary_op(LESSEQ, _14165, 5LL);
        }
        _14165 = NOVALUE;
        if (_14166 == 0) {
            DeRef(_14166);
            _14166 = NOVALUE;
            goto L4; // [141] 165
        }
        else {
            if (!IS_ATOM_INT(_14166) && DBL_PTR(_14166)->dbl == 0.0){
                DeRef(_14166);
                _14166 = NOVALUE;
                goto L4; // [141] 165
            }
            DeRef(_14166);
            _14166 = NOVALUE;
        }
        DeRef(_14166);
        _14166 = NOVALUE;

        /** block.e:182				ifdef BDEBUG then*/

        /** block.e:187				Hide( block_vars[sx] )*/
        _2 = (object)SEQ_PTR(_block_vars_25332);
        _14168 = (object)*(((s1_ptr)_2)->base + _sx_25335);
        Ref(_14168);
        _53Hide(_14168);
        _14168 = NOVALUE;

        /** block.e:188				LintCheck( block_vars[sx] )*/
        _2 = (object)SEQ_PTR(_block_vars_25332);
        _14169 = (object)*(((s1_ptr)_2)->base + _sx_25335);
        Ref(_14169);
        _53LintCheck(_14169);
        _14169 = NOVALUE;
L4: 

        /** block.e:191		end for*/
        _sx_25335 = _sx_25335 + 1LL;
        goto L2; // [167] 90
L3: 
        ;
    }

    /** block.e:213		current_block = block_stack[$][BLOCK_SYM]*/
    if (IS_SEQUENCE(_64block_stack_25140)){
            _14170 = SEQ_PTR(_64block_stack_25140)->length;
    }
    else {
        _14170 = 1;
    }
    _2 = (object)SEQ_PTR(_64block_stack_25140);
    _14171 = (object)*(((s1_ptr)_2)->base + _14170);
    _2 = (object)SEQ_PTR(_14171);
    _64current_block_25147 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_64current_block_25147)){
        _64current_block_25147 = (object)DBL_PTR(_64current_block_25147)->dbl;
    }
    _14171 = NOVALUE;

    /** block.e:214		return block[BLOCK_SYM]*/
    _2 = (object)SEQ_PTR(_block_25319);
    _14173 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_14173);
    DeRefDS(_block_25319);
    DeRef(_block_vars_25332);
    _14152 = NOVALUE;
    DeRef(_14161);
    _14161 = NOVALUE;
    _14163 = NOVALUE;
    DeRef(_14150);
    _14150 = NOVALUE;
    _14158 = NOVALUE;
    return _14173;
    ;
}


object _64top_block(object _offset_25364)
{
    object _14181 = NOVALUE;
    object _14180 = NOVALUE;
    object _14179 = NOVALUE;
    object _14178 = NOVALUE;
    object _14177 = NOVALUE;
    object _14176 = NOVALUE;
    object _14174 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:219		if offset >= length(block_stack) then*/
    if (IS_SEQUENCE(_64block_stack_25140)){
            _14174 = SEQ_PTR(_64block_stack_25140)->length;
    }
    else {
        _14174 = 1;
    }
    if (_offset_25364 < _14174)
    goto L1; // [10] 35

    /** block.e:220			CompileErr(LEAVING_TOO_MANY_BLOCKS_1__2, {offset,length(block_stack)})*/
    if (IS_SEQUENCE(_64block_stack_25140)){
            _14176 = SEQ_PTR(_64block_stack_25140)->length;
    }
    else {
        _14176 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _offset_25364;
    ((intptr_t *)_2)[2] = _14176;
    _14177 = MAKE_SEQ(_1);
    _14176 = NOVALUE;
    _49CompileErr(107LL, _14177, 0LL);
    _14177 = NOVALUE;
    goto L2; // [32] 59
L1: 

    /** block.e:222			return block_stack[$-offset][BLOCK_SYM]*/
    if (IS_SEQUENCE(_64block_stack_25140)){
            _14178 = SEQ_PTR(_64block_stack_25140)->length;
    }
    else {
        _14178 = 1;
    }
    _14179 = _14178 - _offset_25364;
    _14178 = NOVALUE;
    _2 = (object)SEQ_PTR(_64block_stack_25140);
    _14180 = (object)*(((s1_ptr)_2)->base + _14179);
    _2 = (object)SEQ_PTR(_14180);
    _14181 = (object)*(((s1_ptr)_2)->base + 1LL);
    _14180 = NOVALUE;
    Ref(_14181);
    _14179 = NOVALUE;
    return _14181;
L2: 
    ;
}


void _64End_block(object _opcode_25379)
{
    object _ix_25390 = NOVALUE;
    object _14189 = NOVALUE;
    object _14186 = NOVALUE;
    object _14185 = NOVALUE;
    object _14184 = NOVALUE;
    object _14183 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:229		if opcode = FUNC then*/

    /** block.e:232		check_block( opcode )*/
    _64check_block(_opcode_25379);

    /** block.e:233		if not length(block_stack[$][BLOCK_VARS]) then*/
    if (IS_SEQUENCE(_64block_stack_25140)){
            _14183 = SEQ_PTR(_64block_stack_25140)->length;
    }
    else {
        _14183 = 1;
    }
    _2 = (object)SEQ_PTR(_64block_stack_25140);
    _14184 = (object)*(((s1_ptr)_2)->base + _14183);
    _2 = (object)SEQ_PTR(_14184);
    _14185 = (object)*(((s1_ptr)_2)->base + 6LL);
    _14184 = NOVALUE;
    if (IS_SEQUENCE(_14185)){
            _14186 = SEQ_PTR(_14185)->length;
    }
    else {
        _14186 = 1;
    }
    _14185 = NOVALUE;
    if (_14186 != 0)
    goto L1; // [44] 64
    _14186 = NOVALUE;

    /** block.e:234			integer ix = 1*/
    _ix_25390 = 1LL;

    /** block.e:235			ix = pop_block()*/
    _ix_25390 = _64pop_block();
    if (!IS_ATOM_INT(_ix_25390)) {
        _1 = (object)(DBL_PTR(_ix_25390)->dbl);
        DeRefDS(_ix_25390);
        _ix_25390 = _1;
    }
    goto L2; // [61] 80
L1: 

    /** block.e:237			Push( pop_block() )*/
    _14189 = _64pop_block();
    _45Push(_14189);
    _14189 = NOVALUE;

    /** block.e:238			emit_op( EXIT_BLOCK )*/
    _45emit_op(206LL);
L2: 

    /** block.e:241	end procedure*/
    _14185 = NOVALUE;
    return;
    ;
}


object _64End_inline_block(object _opcode_25399)
{
    object _14196 = NOVALUE;
    object _14195 = NOVALUE;
    object _14194 = NOVALUE;
    object _14193 = NOVALUE;
    object _14192 = NOVALUE;
    object _14191 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:246		if opcode = FUNC then*/

    /** block.e:249		if length(block_stack[$][BLOCK_VARS]) then*/
    if (IS_SEQUENCE(_64block_stack_25140)){
            _14191 = SEQ_PTR(_64block_stack_25140)->length;
    }
    else {
        _14191 = 1;
    }
    _2 = (object)SEQ_PTR(_64block_stack_25140);
    _14192 = (object)*(((s1_ptr)_2)->base + _14191);
    _2 = (object)SEQ_PTR(_14192);
    _14193 = (object)*(((s1_ptr)_2)->base + 6LL);
    _14192 = NOVALUE;
    if (IS_SEQUENCE(_14193)){
            _14194 = SEQ_PTR(_14193)->length;
    }
    else {
        _14194 = 1;
    }
    _14193 = NOVALUE;
    if (_14194 == 0)
    {
        _14194 = NOVALUE;
        goto L1; // [39] 60
    }
    else{
        _14194 = NOVALUE;
    }

    /** block.e:250			return { EXIT_BLOCK, pop_block() }*/
    _14195 = _64pop_block();
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 206LL;
    ((intptr_t *)_2)[2] = _14195;
    _14196 = MAKE_SEQ(_1);
    _14195 = NOVALUE;
    _14193 = NOVALUE;
    return _14196;
    goto L2; // [57] 72
L1: 

    /** block.e:252			Drop_block( opcode )*/
    _64Drop_block(_opcode_25399);

    /** block.e:253			return {}*/
    RefDS(_5);
    DeRef(_14196);
    _14196 = NOVALUE;
    _14193 = NOVALUE;
    return _5;
L2: 
    ;
}


void _64Sibling_block(object _opcode_25416)
{
    object _0, _1, _2;
    

    /** block.e:261		End_block( opcode )*/
    _64End_block(_opcode_25416);

    /** block.e:262		Start_block( opcode )*/
    _64Start_block(_opcode_25416, 0LL);

    /** block.e:263	end procedure*/
    return;
    ;
}


void _64Leave_block(object _offset_25419)
{
    object _14202 = NOVALUE;
    object _14201 = NOVALUE;
    object _14200 = NOVALUE;
    object _14199 = NOVALUE;
    object _14198 = NOVALUE;
    object _14197 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_offset_25419)) {
        _1 = (object)(DBL_PTR(_offset_25419)->dbl);
        DeRefDS(_offset_25419);
        _offset_25419 = _1;
    }

    /** block.e:268		if length( block_stack[$-offset][BLOCK_VARS]) then*/
    if (IS_SEQUENCE(_64block_stack_25140)){
            _14197 = SEQ_PTR(_64block_stack_25140)->length;
    }
    else {
        _14197 = 1;
    }
    _14198 = _14197 - _offset_25419;
    _14197 = NOVALUE;
    _2 = (object)SEQ_PTR(_64block_stack_25140);
    _14199 = (object)*(((s1_ptr)_2)->base + _14198);
    _2 = (object)SEQ_PTR(_14199);
    _14200 = (object)*(((s1_ptr)_2)->base + 6LL);
    _14199 = NOVALUE;
    if (IS_SEQUENCE(_14200)){
            _14201 = SEQ_PTR(_14200)->length;
    }
    else {
        _14201 = 1;
    }
    _14200 = NOVALUE;
    if (_14201 == 0)
    {
        _14201 = NOVALUE;
        goto L1; // [25] 45
    }
    else{
        _14201 = NOVALUE;
    }

    /** block.e:269			Push( top_block( offset ) )*/
    _14202 = _64top_block(_offset_25419);
    _45Push(_14202);
    _14202 = NOVALUE;

    /** block.e:270			emit_op( EXIT_BLOCK )*/
    _45emit_op(206LL);
L1: 

    /** block.e:272	end procedure*/
    DeRef(_14198);
    _14198 = NOVALUE;
    _14200 = NOVALUE;
    return;
    ;
}


void _64Leave_blocks(object _blocks_25439, object _block_type_25440)
{
    object _bx_25441 = NOVALUE;
    object _Block_opcode_3__tmp_at29_25448 = NOVALUE;
    object _Block_opcode_2__tmp_at29_25447 = NOVALUE;
    object _Block_opcode_1__tmp_at29_25446 = NOVALUE;
    object _Block_opcode_inlined_Block_opcode_at_29_25445 = NOVALUE;
    object _14215 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_blocks_25439)) {
        _1 = (object)(DBL_PTR(_blocks_25439)->dbl);
        DeRefDS(_blocks_25439);
        _blocks_25439 = _1;
    }

    /** block.e:284		integer bx = 0*/
    _bx_25441 = 0LL;

    /** block.e:285		while blocks do*/
L1: 
    if (_blocks_25439 == 0)
    {
        goto L2; // [15] 119
    }
    else{
    }

    /** block.e:286			Leave_block( bx )*/
    _64Leave_block(_bx_25441);

    /** block.e:288			if block_type then*/
    if (_block_type_25440 == 0)
    {
        goto L3; // [25] 101
    }
    else{
    }

    /** block.e:289				switch Block_opcode( bx ) do*/

    /** block.e:276		return block_stack[$-bx][BLOCK_OPCODE]*/
    if (IS_SEQUENCE(_64block_stack_25140)){
            _Block_opcode_1__tmp_at29_25446 = SEQ_PTR(_64block_stack_25140)->length;
    }
    else {
        _Block_opcode_1__tmp_at29_25446 = 1;
    }
    _Block_opcode_2__tmp_at29_25447 = _Block_opcode_1__tmp_at29_25446 - _bx_25441;
    DeRef(_Block_opcode_3__tmp_at29_25448);
    _2 = (object)SEQ_PTR(_64block_stack_25140);
    _Block_opcode_3__tmp_at29_25448 = (object)*(((s1_ptr)_2)->base + _Block_opcode_2__tmp_at29_25447);
    Ref(_Block_opcode_3__tmp_at29_25448);
    DeRef(_Block_opcode_inlined_Block_opcode_at_29_25445);
    _2 = (object)SEQ_PTR(_Block_opcode_3__tmp_at29_25448);
    _Block_opcode_inlined_Block_opcode_at_29_25445 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_Block_opcode_inlined_Block_opcode_at_29_25445);
    DeRef(_Block_opcode_3__tmp_at29_25448);
    _Block_opcode_3__tmp_at29_25448 = NOVALUE;
    if (IS_SEQUENCE(_Block_opcode_inlined_Block_opcode_at_29_25445) ){
        goto L4; // [52] 82
    }
    if(!IS_ATOM_INT(_Block_opcode_inlined_Block_opcode_at_29_25445)){
        if( (DBL_PTR(_Block_opcode_inlined_Block_opcode_at_29_25445)->dbl != (eudouble) ((object) DBL_PTR(_Block_opcode_inlined_Block_opcode_at_29_25445)->dbl) ) ){
            goto L4; // [52] 82
        }
        _0 = (object) DBL_PTR(_Block_opcode_inlined_Block_opcode_at_29_25445)->dbl;
    }
    else {
        _0 = _Block_opcode_inlined_Block_opcode_at_29_25445;
    };
    switch ( _0 ){ 

        /** block.e:290					case FOR, WHILE, LOOP then*/
        case 21:
        case 47:
        case 422:

        /** block.e:291						if block_type = LOOP_BLOCK then*/
        if (_block_type_25440 != 1LL)
        goto L5; // [67] 108

        /** block.e:292							blocks -= 1*/
        _blocks_25439 = _blocks_25439 - 1LL;
        goto L5; // [78] 108

        /** block.e:294					case else*/
        default:
L4: 

        /** block.e:295						if block_type = CONDITIONAL_BLOCK then*/
        if (_block_type_25440 != 2LL)
        goto L6; // [86] 97

        /** block.e:296							blocks -= 1*/
        _blocks_25439 = _blocks_25439 - 1LL;
L6: 
    ;}    goto L5; // [98] 108
L3: 

    /** block.e:300				blocks -= 1*/
    _blocks_25439 = _blocks_25439 - 1LL;
L5: 

    /** block.e:302			bx += 1*/
    _bx_25441 = _bx_25441 + 1;

    /** block.e:303		end while*/
    goto L1; // [116] 15
L2: 

    /** block.e:304		for i = 0 to blocks - 1 do*/
    _14215 = _blocks_25439 - 1LL;
    if ((object)((uintptr_t)_14215 +(uintptr_t) HIGH_BITS) >= 0){
        _14215 = NewDouble((eudouble)_14215);
    }
    {
        object _i_25466;
        _i_25466 = 0LL;
L7: 
        if (binary_op_a(GREATER, _i_25466, _14215)){
            goto L8; // [125] 144
        }

        /** block.e:305			Leave_block( i )*/
        Ref(_i_25466);
        _64Leave_block(_i_25466);

        /** block.e:306		end for*/
        _0 = _i_25466;
        if (IS_ATOM_INT(_i_25466)) {
            _i_25466 = _i_25466 + 1LL;
            if ((object)((uintptr_t)_i_25466 +(uintptr_t) HIGH_BITS) >= 0){
                _i_25466 = NewDouble((eudouble)_i_25466);
            }
        }
        else {
            _i_25466 = binary_op_a(PLUS, _i_25466, 1LL);
        }
        DeRef(_0);
        goto L7; // [139] 132
L8: 
        ;
        DeRef(_i_25466);
    }

    /** block.e:307	end procedure*/
    DeRef(_14215);
    _14215 = NOVALUE;
    return;
    ;
}


void _64Drop_block(object _opcode_25470)
{
    object _x_25472 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:311		check_block( opcode )*/
    _64check_block(_opcode_25470);

    /** block.e:312		symtab_index x = pop_block()*/
    _x_25472 = _64pop_block();
    if (!IS_ATOM_INT(_x_25472)) {
        _1 = (object)(DBL_PTR(_x_25472)->dbl);
        DeRefDS(_x_25472);
        _x_25472 = _1;
    }

    /** block.e:313	end procedure*/
    return;
    ;
}


void _64Pop_block_var()
{
    object _sym_25477 = NOVALUE;
    object _block_sym_25484 = NOVALUE;
    object _14243 = NOVALUE;
    object _14242 = NOVALUE;
    object _14241 = NOVALUE;
    object _14240 = NOVALUE;
    object _14239 = NOVALUE;
    object _14238 = NOVALUE;
    object _14237 = NOVALUE;
    object _14236 = NOVALUE;
    object _14234 = NOVALUE;
    object _14233 = NOVALUE;
    object _14231 = NOVALUE;
    object _14230 = NOVALUE;
    object _14228 = NOVALUE;
    object _14225 = NOVALUE;
    object _14223 = NOVALUE;
    object _14222 = NOVALUE;
    object _14220 = NOVALUE;
    object _14219 = NOVALUE;
    object _14218 = NOVALUE;
    object _14217 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** block.e:316		symtab_index sym = block_stack[$][BLOCK_VARS][$]*/
    if (IS_SEQUENCE(_64block_stack_25140)){
            _14217 = SEQ_PTR(_64block_stack_25140)->length;
    }
    else {
        _14217 = 1;
    }
    _2 = (object)SEQ_PTR(_64block_stack_25140);
    _14218 = (object)*(((s1_ptr)_2)->base + _14217);
    _2 = (object)SEQ_PTR(_14218);
    _14219 = (object)*(((s1_ptr)_2)->base + 6LL);
    _14218 = NOVALUE;
    if (IS_SEQUENCE(_14219)){
            _14220 = SEQ_PTR(_14219)->length;
    }
    else {
        _14220 = 1;
    }
    _2 = (object)SEQ_PTR(_14219);
    _sym_25477 = (object)*(((s1_ptr)_2)->base + _14220);
    if (!IS_ATOM_INT(_sym_25477)){
        _sym_25477 = (object)DBL_PTR(_sym_25477)->dbl;
    }
    _14219 = NOVALUE;

    /** block.e:317		symtab_index block_sym = block_stack[$][BLOCK_SYM]*/
    if (IS_SEQUENCE(_64block_stack_25140)){
            _14222 = SEQ_PTR(_64block_stack_25140)->length;
    }
    else {
        _14222 = 1;
    }
    _2 = (object)SEQ_PTR(_64block_stack_25140);
    _14223 = (object)*(((s1_ptr)_2)->base + _14222);
    _2 = (object)SEQ_PTR(_14223);
    _block_sym_25484 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_block_sym_25484)){
        _block_sym_25484 = (object)DBL_PTR(_block_sym_25484)->dbl;
    }
    _14223 = NOVALUE;

    /** block.e:318		while sym_next_in_block( block_sym ) != sym do*/
L1: 
    _14225 = _53sym_next_in_block(_block_sym_25484);
    if (binary_op_a(EQUALS, _14225, _sym_25477)){
        DeRef(_14225);
        _14225 = NOVALUE;
        goto L2; // [51] 68
    }
    DeRef(_14225);
    _14225 = NOVALUE;

    /** block.e:319			block_sym = sym_next_in_block( block_sym )*/
    _block_sym_25484 = _53sym_next_in_block(_block_sym_25484);
    if (!IS_ATOM_INT(_block_sym_25484)) {
        _1 = (object)(DBL_PTR(_block_sym_25484)->dbl);
        DeRefDS(_block_sym_25484);
        _block_sym_25484 = _1;
    }

    /** block.e:320		end while*/
    goto L1; // [65] 47
L2: 

    /** block.e:322		SymTab[block_sym][S_NEXT_IN_BLOCK] = sym_next_in_block( sym )*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_block_sym_25484 + ((s1_ptr)_2)->base);
    _14230 = _53sym_next_in_block(_sym_25477);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_NEXT_IN_BLOCK_19856))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NEXT_IN_BLOCK_19856)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_NEXT_IN_BLOCK_19856);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14230;
    if( _1 != _14230 ){
        DeRef(_1);
    }
    _14230 = NOVALUE;
    _14228 = NOVALUE;

    /** block.e:323		SymTab[sym][S_NEXT_IN_BLOCK] = 0*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_25477 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_NEXT_IN_BLOCK_19856))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NEXT_IN_BLOCK_19856)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _12S_NEXT_IN_BLOCK_19856);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _14231 = NOVALUE;

    /** block.e:325		block_stack[$][BLOCK_VARS] = eu:remove( block_stack[$][BLOCK_VARS], */
    if (IS_SEQUENCE(_64block_stack_25140)){
            _14233 = SEQ_PTR(_64block_stack_25140)->length;
    }
    else {
        _14233 = 1;
    }
    _2 = (object)SEQ_PTR(_64block_stack_25140);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _64block_stack_25140 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14233 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_64block_stack_25140)){
            _14236 = SEQ_PTR(_64block_stack_25140)->length;
    }
    else {
        _14236 = 1;
    }
    _2 = (object)SEQ_PTR(_64block_stack_25140);
    _14237 = (object)*(((s1_ptr)_2)->base + _14236);
    _2 = (object)SEQ_PTR(_14237);
    _14238 = (object)*(((s1_ptr)_2)->base + 6LL);
    _14237 = NOVALUE;
    if (IS_SEQUENCE(_64block_stack_25140)){
            _14239 = SEQ_PTR(_64block_stack_25140)->length;
    }
    else {
        _14239 = 1;
    }
    _2 = (object)SEQ_PTR(_64block_stack_25140);
    _14240 = (object)*(((s1_ptr)_2)->base + _14239);
    _2 = (object)SEQ_PTR(_14240);
    _14241 = (object)*(((s1_ptr)_2)->base + 6LL);
    _14240 = NOVALUE;
    if (IS_SEQUENCE(_14241)){
            _14242 = SEQ_PTR(_14241)->length;
    }
    else {
        _14242 = 1;
    }
    _14241 = NOVALUE;
    {
        s1_ptr assign_space = SEQ_PTR(_14238);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_14242)) ? _14242 : (object)(DBL_PTR(_14242)->dbl);
        int stop = (IS_ATOM_INT(_14242)) ? _14242 : (object)(DBL_PTR(_14242)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
            RefDS(_14238);
            DeRef(_14243);
            _14243 = _14238;
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_14238), start, &_14243 );
            }
            else Tail(SEQ_PTR(_14238), stop+1, &_14243);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_14238), start, &_14243);
        }
        else {
            assign_slice_seq = &assign_space;
            _1 = Remove_elements(start, stop, 0);
            DeRef(_14243);
            _14243 = _1;
        }
    }
    _14238 = NOVALUE;
    _14242 = NOVALUE;
    _14242 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14243;
    if( _1 != _14243 ){
        DeRef(_1);
    }
    _14243 = NOVALUE;
    _14234 = NOVALUE;

    /** block.e:327	end procedure*/
    _14241 = NOVALUE;
    return;
    ;
}


void _64Goto_block(object _from_block_25518, object _to_block_25520, object _pc_25521)
{
    object _code_25522 = NOVALUE;
    object _next_block_25524 = NOVALUE;
    object _14254 = NOVALUE;
    object _14251 = NOVALUE;
    object _14250 = NOVALUE;
    object _14249 = NOVALUE;
    object _14248 = NOVALUE;
    object _14247 = NOVALUE;
    object _14246 = NOVALUE;
    object _14245 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_from_block_25518)) {
        _1 = (object)(DBL_PTR(_from_block_25518)->dbl);
        DeRefDS(_from_block_25518);
        _from_block_25518 = _1;
    }
    if (!IS_ATOM_INT(_to_block_25520)) {
        _1 = (object)(DBL_PTR(_to_block_25520)->dbl);
        DeRefDS(_to_block_25520);
        _to_block_25520 = _1;
    }
    if (!IS_ATOM_INT(_pc_25521)) {
        _1 = (object)(DBL_PTR(_pc_25521)->dbl);
        DeRefDS(_pc_25521);
        _pc_25521 = _1;
    }

    /** block.e:330		sequence code = {}*/
    RefDS(_5);
    DeRefi(_code_25522);
    _code_25522 = _5;

    /** block.e:331		symtab_index next_block = sym_block( from_block )*/
    _next_block_25524 = _53sym_block(_from_block_25518);
    if (!IS_ATOM_INT(_next_block_25524)) {
        _1 = (object)(DBL_PTR(_next_block_25524)->dbl);
        DeRefDS(_next_block_25524);
        _next_block_25524 = _1;
    }

    /** block.e:332		while next_block */
L1: 
    if (_next_block_25524 == 0) {
        _14245 = 0;
        goto L2; // [27] 39
    }
    _14246 = (_from_block_25518 != _to_block_25520);
    _14245 = (_14246 != 0);
L2: 
    if (_14245 == 0) {
        goto L3; // [39] 93
    }
    _14248 = _53sym_token(_next_block_25524);
    _14249 = find_from(_14248, _29RTN_TOKS_12006, 1LL);
    DeRef(_14248);
    _14248 = NOVALUE;
    _14250 = (_14249 == 0);
    _14249 = NOVALUE;
    if (_14250 == 0)
    {
        DeRef(_14250);
        _14250 = NOVALUE;
        goto L3; // [58] 93
    }
    else{
        DeRef(_14250);
        _14250 = NOVALUE;
    }

    /** block.e:335			code &= { EXIT_BLOCK, from_block }*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 206LL;
    ((intptr_t *)_2)[2] = _from_block_25518;
    _14251 = MAKE_SEQ(_1);
    Concat((object_ptr)&_code_25522, _code_25522, _14251);
    DeRefDS(_14251);
    _14251 = NOVALUE;

    /** block.e:336			from_block = next_block*/
    _from_block_25518 = _next_block_25524;

    /** block.e:337			next_block = sym_block( next_block )*/
    _next_block_25524 = _53sym_block(_next_block_25524);
    if (!IS_ATOM_INT(_next_block_25524)) {
        _1 = (object)(DBL_PTR(_next_block_25524)->dbl);
        DeRefDS(_next_block_25524);
        _next_block_25524 = _1;
    }

    /** block.e:338		end while*/
    goto L1; // [90] 27
L3: 

    /** block.e:340		if length(code) then*/
    if (IS_SEQUENCE(_code_25522)){
            _14254 = SEQ_PTR(_code_25522)->length;
    }
    else {
        _14254 = 1;
    }
    if (_14254 == 0)
    {
        _14254 = NOVALUE;
        goto L4; // [98] 127
    }
    else{
        _14254 = NOVALUE;
    }

    /** block.e:341			if pc then*/
    if (_pc_25521 == 0)
    {
        goto L5; // [103] 115
    }
    else{
    }

    /** block.e:342				insert_code( code, pc )*/
    RefDS(_code_25522);
    _65insert_code(_code_25522, _pc_25521);
    goto L6; // [112] 126
L5: 

    /** block.e:344				Code &= code*/
    Concat((object_ptr)&_12Code_20315, _12Code_20315, _code_25522);
L6: 
L4: 

    /** block.e:348	end procedure*/
    DeRefi(_code_25522);
    DeRef(_14246);
    _14246 = NOVALUE;
    return;
    ;
}


object _64Least_block()
{
    object _ix_25552 = NOVALUE;
    object _sub_block_25555 = NOVALUE;
    object _14268 = NOVALUE;
    object _14267 = NOVALUE;
    object _14265 = NOVALUE;
    object _14264 = NOVALUE;
    object _14263 = NOVALUE;
    object _14262 = NOVALUE;
    object _14261 = NOVALUE;
    object _14260 = NOVALUE;
    object _14259 = NOVALUE;
    object _14258 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:358		integer ix = length( block_stack )*/
    if (IS_SEQUENCE(_64block_stack_25140)){
            _ix_25552 = SEQ_PTR(_64block_stack_25140)->length;
    }
    else {
        _ix_25552 = 1;
    }

    /** block.e:359		symtab_index sub_block = sym_block( CurrentSub )*/
    _sub_block_25555 = _53sym_block(_12CurrentSub_20234);
    if (!IS_ATOM_INT(_sub_block_25555)) {
        _1 = (object)(DBL_PTR(_sub_block_25555)->dbl);
        DeRefDS(_sub_block_25555);
        _sub_block_25555 = _1;
    }

    /** block.e:360		while not length( block_stack[ix][BLOCK_VARS] ) */
L1: 
    _2 = (object)SEQ_PTR(_64block_stack_25140);
    _14258 = (object)*(((s1_ptr)_2)->base + _ix_25552);
    _2 = (object)SEQ_PTR(_14258);
    _14259 = (object)*(((s1_ptr)_2)->base + 6LL);
    _14258 = NOVALUE;
    if (IS_SEQUENCE(_14259)){
            _14260 = SEQ_PTR(_14259)->length;
    }
    else {
        _14260 = 1;
    }
    _14259 = NOVALUE;
    _14261 = (_14260 == 0);
    _14260 = NOVALUE;
    if (_14261 == 0) {
        goto L2; // [39] 72
    }
    _2 = (object)SEQ_PTR(_64block_stack_25140);
    _14263 = (object)*(((s1_ptr)_2)->base + _ix_25552);
    _2 = (object)SEQ_PTR(_14263);
    _14264 = (object)*(((s1_ptr)_2)->base + 1LL);
    _14263 = NOVALUE;
    if (IS_ATOM_INT(_14264)) {
        _14265 = (_14264 != _sub_block_25555);
    }
    else {
        _14265 = binary_op(NOTEQ, _14264, _sub_block_25555);
    }
    _14264 = NOVALUE;
    if (_14265 <= 0) {
        if (_14265 == 0) {
            DeRef(_14265);
            _14265 = NOVALUE;
            goto L2; // [58] 72
        }
        else {
            if (!IS_ATOM_INT(_14265) && DBL_PTR(_14265)->dbl == 0.0){
                DeRef(_14265);
                _14265 = NOVALUE;
                goto L2; // [58] 72
            }
            DeRef(_14265);
            _14265 = NOVALUE;
        }
    }
    DeRef(_14265);
    _14265 = NOVALUE;

    /** block.e:362			ix -= 1	*/
    _ix_25552 = _ix_25552 - 1LL;

    /** block.e:363		end while*/
    goto L1; // [69] 23
L2: 

    /** block.e:364		return block_stack[ix][BLOCK_SYM]*/
    _2 = (object)SEQ_PTR(_64block_stack_25140);
    _14267 = (object)*(((s1_ptr)_2)->base + _ix_25552);
    _2 = (object)SEQ_PTR(_14267);
    _14268 = (object)*(((s1_ptr)_2)->base + 1LL);
    _14267 = NOVALUE;
    Ref(_14268);
    DeRef(_14261);
    _14261 = NOVALUE;
    _14259 = NOVALUE;
    return _14268;
    ;
}



// 0x6AE4E160
