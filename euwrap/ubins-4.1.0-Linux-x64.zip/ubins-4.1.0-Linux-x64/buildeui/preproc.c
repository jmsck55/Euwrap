// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _63is_file_newer(object _f1_24069, object _f2_24070)
{
    object _d1_24071 = NOVALUE;
    object _d2_24074 = NOVALUE;
    object _diff_2__tmp_at33_24083 = NOVALUE;
    object _diff_1__tmp_at33_24082 = NOVALUE;
    object _diff_inlined_diff_at_33_24081 = NOVALUE;
    object _13545 = NOVALUE;
    object _0, _1, _2;
    

    /** preproc.e:22		object d1 = file_timestamp(f1)*/
    RefDS(_f1_24069);
    _0 = _d1_24071;
    _d1_24071 = _14file_timestamp(_f1_24069);
    DeRef(_0);

    /** preproc.e:23		object d2 = file_timestamp(f2)*/
    RefDS(_f2_24070);
    _0 = _d2_24074;
    _d2_24074 = _14file_timestamp(_f2_24070);
    DeRef(_0);

    /** preproc.e:25		if atom(d2) then return 1 end if*/
    _13545 = IS_ATOM(_d2_24074);
    if (_13545 == 0)
    {
        _13545 = NOVALUE;
        goto L1; // [22] 30
    }
    else{
        _13545 = NOVALUE;
    }
    DeRefDS(_f1_24069);
    DeRefDS(_f2_24070);
    DeRef(_d1_24071);
    DeRef(_d2_24074);
    return 1LL;
L1: 

    /** preproc.e:27		if dt:diff(d1, d2) < 0 then*/

    /** datetime.e:1253		return datetimeToSeconds(dt2) - datetimeToSeconds(dt1)*/
    Ref(_d2_24074);
    _0 = _diff_1__tmp_at33_24082;
    _diff_1__tmp_at33_24082 = _15datetimeToSeconds(_d2_24074);
    DeRef(_0);
    Ref(_d1_24071);
    _0 = _diff_2__tmp_at33_24083;
    _diff_2__tmp_at33_24083 = _15datetimeToSeconds(_d1_24071);
    DeRef(_0);
    DeRef(_diff_inlined_diff_at_33_24081);
    if (IS_ATOM_INT(_diff_1__tmp_at33_24082) && IS_ATOM_INT(_diff_2__tmp_at33_24083)) {
        _diff_inlined_diff_at_33_24081 = _diff_1__tmp_at33_24082 - _diff_2__tmp_at33_24083;
        if ((object)((uintptr_t)_diff_inlined_diff_at_33_24081 +(uintptr_t) HIGH_BITS) >= 0){
            _diff_inlined_diff_at_33_24081 = NewDouble((eudouble)_diff_inlined_diff_at_33_24081);
        }
    }
    else {
        _diff_inlined_diff_at_33_24081 = binary_op(MINUS, _diff_1__tmp_at33_24082, _diff_2__tmp_at33_24083);
    }
    DeRef(_diff_1__tmp_at33_24082);
    _diff_1__tmp_at33_24082 = NOVALUE;
    DeRef(_diff_2__tmp_at33_24083);
    _diff_2__tmp_at33_24083 = NOVALUE;
    if (binary_op_a(GREATEREQ, _diff_inlined_diff_at_33_24081, 0LL)){
        goto L2; // [49] 60
    }

    /** preproc.e:28			return 1*/
    DeRefDS(_f1_24069);
    DeRefDS(_f2_24070);
    DeRef(_d1_24071);
    DeRef(_d2_24074);
    return 1LL;
L2: 

    /** preproc.e:31		return 0*/
    DeRefDS(_f1_24069);
    DeRefDS(_f2_24070);
    DeRef(_d1_24071);
    DeRef(_d2_24074);
    return 0LL;
    ;
}


void _63add_preprocessor(object _file_ext_24087, object _command_24088, object _params_24089)
{
    object _tmp_24092 = NOVALUE;
    object _file_exts_24102 = NOVALUE;
    object _exts_24108 = NOVALUE;
    object _13562 = NOVALUE;
    object _13561 = NOVALUE;
    object _13560 = NOVALUE;
    object _13559 = NOVALUE;
    object _13557 = NOVALUE;
    object _13552 = NOVALUE;
    object _13547 = NOVALUE;
    object _0, _1, _2;
    

    /** preproc.e:46		if atom(command) then*/
    _13547 = 1;
    if (_13547 == 0)
    {
        _13547 = NOVALUE;
        goto L1; // [8] 53
    }
    else{
        _13547 = NOVALUE;
    }

    /** preproc.e:47			sequence tmp = split( file_ext, ":")*/
    RefDS(_file_ext_24087);
    RefDS(_13548);
    _0 = _tmp_24092;
    _tmp_24092 = _24split(_file_ext_24087, _13548, 0LL, 0LL);
    DeRef(_0);

    /** preproc.e:48			file_ext = tmp[1]*/
    DeRefDS(_file_ext_24087);
    _2 = (object)SEQ_PTR(_tmp_24092);
    _file_ext_24087 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_file_ext_24087);

    /** preproc.e:49			command = tmp[2]*/
    _2 = (object)SEQ_PTR(_tmp_24092);
    _command_24088 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_command_24088);

    /** preproc.e:50			if length(tmp) >= 3 then*/
    if (IS_SEQUENCE(_tmp_24092)){
            _13552 = SEQ_PTR(_tmp_24092)->length;
    }
    else {
        _13552 = 1;
    }
    if (_13552 < 3LL)
    goto L2; // [41] 52

    /** preproc.e:51				params = tmp[3]*/
    _2 = (object)SEQ_PTR(_tmp_24092);
    _params_24089 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_params_24089);
L2: 
L1: 
    DeRef(_tmp_24092);
    _tmp_24092 = NOVALUE;

    /** preproc.e:55		sequence file_exts = split( file_ext, "," )*/
    RefDS(_file_ext_24087);
    RefDS(_13555);
    _0 = _file_exts_24102;
    _file_exts_24102 = _24split(_file_ext_24087, _13555, 0LL, 0LL);
    DeRef(_0);

    /** preproc.e:57		if atom(params) then*/
    _13557 = IS_ATOM(_params_24089);
    if (_13557 == 0)
    {
        _13557 = NOVALUE;
        goto L3; // [71] 80
    }
    else{
        _13557 = NOVALUE;
    }

    /** preproc.e:58			params = ""*/
    RefDS(_5);
    DeRef(_params_24089);
    _params_24089 = _5;
L3: 

    /** preproc.e:61		sequence exts = split(file_ext, ",")*/
    RefDS(_file_ext_24087);
    RefDS(_13555);
    _0 = _exts_24108;
    _exts_24108 = _24split(_file_ext_24087, _13555, 0LL, 0LL);
    DeRef(_0);

    /** preproc.e:62		for i = 1 to length(exts) do*/
    if (IS_SEQUENCE(_exts_24108)){
            _13559 = SEQ_PTR(_exts_24108)->length;
    }
    else {
        _13559 = 1;
    }
    {
        object _i_24112;
        _i_24112 = 1LL;
L4: 
        if (_i_24112 > _13559){
            goto L5; // [96] 135
        }

        /** preproc.e:63			preprocessors &= { { exts[i], command, params, -1 } }*/
        _2 = (object)SEQ_PTR(_exts_24108);
        _13560 = (object)*(((s1_ptr)_2)->base + _i_24112);
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_13560);
        ((intptr_t*)_2)[1] = _13560;
        Ref(_command_24088);
        ((intptr_t*)_2)[2] = _command_24088;
        Ref(_params_24089);
        ((intptr_t*)_2)[3] = _params_24089;
        ((intptr_t*)_2)[4] = -1LL;
        _13561 = MAKE_SEQ(_1);
        _13560 = NOVALUE;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _13561;
        _13562 = MAKE_SEQ(_1);
        _13561 = NOVALUE;
        Concat((object_ptr)&_13preprocessors_11334, _13preprocessors_11334, _13562);
        DeRefDS(_13562);
        _13562 = NOVALUE;

        /** preproc.e:64		end for*/
        _i_24112 = _i_24112 + 1LL;
        goto L4; // [130] 103
L5: 
        ;
    }

    /** preproc.e:65	end procedure */
    DeRefDS(_file_ext_24087);
    DeRef(_command_24088);
    DeRef(_params_24089);
    DeRef(_file_exts_24102);
    DeRef(_exts_24108);
    return;
    ;
}


object _63maybe_preprocess(object _fname_24121)
{
    object _pp_24122 = NOVALUE;
    object _pp_id_24123 = NOVALUE;
    object _fext_24127 = NOVALUE;
    object _post_fname_24144 = NOVALUE;
    object _rid_24172 = NOVALUE;
    object _dll_id_24176 = NOVALUE;
    object _public_cmd_args_24212 = NOVALUE;
    object _cmd_args_24215 = NOVALUE;
    object _cmd_24244 = NOVALUE;
    object _pcmd_24249 = NOVALUE;
    object _result_24254 = NOVALUE;
    object _13641 = NOVALUE;
    object _13640 = NOVALUE;
    object _13635 = NOVALUE;
    object _13634 = NOVALUE;
    object _13632 = NOVALUE;
    object _13631 = NOVALUE;
    object _13629 = NOVALUE;
    object _13627 = NOVALUE;
    object _13626 = NOVALUE;
    object _13624 = NOVALUE;
    object _13621 = NOVALUE;
    object _13619 = NOVALUE;
    object _13617 = NOVALUE;
    object _13615 = NOVALUE;
    object _13614 = NOVALUE;
    object _13612 = NOVALUE;
    object _13611 = NOVALUE;
    object _13609 = NOVALUE;
    object _13606 = NOVALUE;
    object _13605 = NOVALUE;
    object _13604 = NOVALUE;
    object _13602 = NOVALUE;
    object _13598 = NOVALUE;
    object _13596 = NOVALUE;
    object _13595 = NOVALUE;
    object _13594 = NOVALUE;
    object _13590 = NOVALUE;
    object _13587 = NOVALUE;
    object _13586 = NOVALUE;
    object _13585 = NOVALUE;
    object _13583 = NOVALUE;
    object _13580 = NOVALUE;
    object _13578 = NOVALUE;
    object _13577 = NOVALUE;
    object _13575 = NOVALUE;
    object _13573 = NOVALUE;
    object _13571 = NOVALUE;
    object _13569 = NOVALUE;
    object _13568 = NOVALUE;
    object _13567 = NOVALUE;
    object _13566 = NOVALUE;
    object _13564 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** preproc.e:81		sequence pp = {}*/
    RefDS(_5);
    DeRef(_pp_24122);
    _pp_24122 = _5;

    /** preproc.e:84		if length(preprocessors) then*/
    if (IS_SEQUENCE(_13preprocessors_11334)){
            _13564 = SEQ_PTR(_13preprocessors_11334)->length;
    }
    else {
        _13564 = 1;
    }
    if (_13564 == 0)
    {
        _13564 = NOVALUE;
        goto L1; // [17] 89
    }
    else{
        _13564 = NOVALUE;
    }

    /** preproc.e:85			sequence fext = fileext(fname)*/
    RefDS(_fname_24121);
    _0 = _fext_24127;
    _fext_24127 = _14fileext(_fname_24121);
    DeRef(_0);

    /** preproc.e:87			for i = 1 to length(preprocessors) do*/
    if (IS_SEQUENCE(_13preprocessors_11334)){
            _13566 = SEQ_PTR(_13preprocessors_11334)->length;
    }
    else {
        _13566 = 1;
    }
    {
        object _i_24131;
        _i_24131 = 1LL;
L2: 
        if (_i_24131 > _13566){
            goto L3; // [35] 88
        }

        /** preproc.e:88				if equal(fext, preprocessors[i][1]) then*/
        _2 = (object)SEQ_PTR(_13preprocessors_11334);
        _13567 = (object)*(((s1_ptr)_2)->base + _i_24131);
        _2 = (object)SEQ_PTR(_13567);
        _13568 = (object)*(((s1_ptr)_2)->base + 1LL);
        _13567 = NOVALUE;
        if (_fext_24127 == _13568)
        _13569 = 1;
        else if (IS_ATOM_INT(_fext_24127) && IS_ATOM_INT(_13568))
        _13569 = 0;
        else
        _13569 = (compare(_fext_24127, _13568) == 0);
        _13568 = NOVALUE;
        if (_13569 == 0)
        {
            _13569 = NOVALUE;
            goto L4; // [58] 81
        }
        else{
            _13569 = NOVALUE;
        }

        /** preproc.e:89					pp_id = i*/
        _pp_id_24123 = _i_24131;

        /** preproc.e:90					pp = preprocessors[pp_id]*/
        DeRef(_pp_24122);
        _2 = (object)SEQ_PTR(_13preprocessors_11334);
        _pp_24122 = (object)*(((s1_ptr)_2)->base + _pp_id_24123);
        RefDS(_pp_24122);

        /** preproc.e:91					exit*/
        goto L3; // [78] 88
L4: 

        /** preproc.e:93			end for*/
        _i_24131 = _i_24131 + 1LL;
        goto L2; // [83] 42
L3: 
        ;
    }
L1: 
    DeRef(_fext_24127);
    _fext_24127 = NOVALUE;

    /** preproc.e:96		if length(pp) = 0 then */
    if (IS_SEQUENCE(_pp_24122)){
            _13571 = SEQ_PTR(_pp_24122)->length;
    }
    else {
        _13571 = 1;
    }
    if (_13571 != 0LL)
    goto L5; // [96] 107

    /** preproc.e:97			return fname*/
    DeRefDS(_pp_24122);
    DeRef(_post_fname_24144);
    return _fname_24121;
L5: 

    /** preproc.e:100		sequence post_fname = filebase(fname) & ".pp." & fileext(fname)*/
    RefDS(_fname_24121);
    _13573 = _14filebase(_fname_24121);
    RefDS(_fname_24121);
    _13575 = _14fileext(_fname_24121);
    {
        object concat_list[3];

        concat_list[0] = _13575;
        concat_list[1] = _13574;
        concat_list[2] = _13573;
        Concat_N((object_ptr)&_post_fname_24144, concat_list, 3);
    }
    DeRef(_13575);
    _13575 = NOVALUE;
    DeRef(_13573);
    _13573 = NOVALUE;

    /** preproc.e:101		if length(dirname(fname)) > 0 then*/
    RefDS(_fname_24121);
    _13577 = _14dirname(_fname_24121, 0LL);
    if (IS_SEQUENCE(_13577)){
            _13578 = SEQ_PTR(_13577)->length;
    }
    else {
        _13578 = 1;
    }
    DeRef(_13577);
    _13577 = NOVALUE;
    if (_13578 <= 0LL)
    goto L6; // [133] 153

    /** preproc.e:102			post_fname = dirname(fname) & SLASH & post_fname*/
    RefDS(_fname_24121);
    _13580 = _14dirname(_fname_24121, 0LL);
    {
        object concat_list[3];

        concat_list[0] = _post_fname_24144;
        concat_list[1] = 47LL;
        concat_list[2] = _13580;
        Concat_N((object_ptr)&_post_fname_24144, concat_list, 3);
    }
    DeRef(_13580);
    _13580 = NOVALUE;
L6: 

    /** preproc.e:105		if not force_preprocessor then*/
    if (_13force_preprocessor_11335 != 0)
    goto L7; // [157] 178

    /** preproc.e:106			if not is_file_newer(fname, post_fname) then*/
    RefDS(_fname_24121);
    RefDS(_post_fname_24144);
    _13583 = _63is_file_newer(_fname_24121, _post_fname_24144);
    if (IS_ATOM_INT(_13583)) {
        if (_13583 != 0){
            DeRef(_13583);
            _13583 = NOVALUE;
            goto L8; // [167] 177
        }
    }
    else {
        if (DBL_PTR(_13583)->dbl != 0.0){
            DeRef(_13583);
            _13583 = NOVALUE;
            goto L8; // [167] 177
        }
    }
    DeRef(_13583);
    _13583 = NOVALUE;

    /** preproc.e:107				return post_fname*/
    DeRefDS(_fname_24121);
    DeRef(_pp_24122);
    _13577 = NOVALUE;
    return _post_fname_24144;
L8: 
L7: 

    /** preproc.e:112		if equal(fileext(pp[PP_COMMAND]), SHARED_LIB_EXT) then*/
    _2 = (object)SEQ_PTR(_pp_24122);
    _13585 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_13585);
    _13586 = _14fileext(_13585);
    _13585 = NOVALUE;
    if (_13586 == _14SHARED_LIB_EXT_9760)
    _13587 = 1;
    else if (IS_ATOM_INT(_13586) && IS_ATOM_INT(_14SHARED_LIB_EXT_9760))
    _13587 = 0;
    else
    _13587 = (compare(_13586, _14SHARED_LIB_EXT_9760) == 0);
    DeRef(_13586);
    _13586 = NOVALUE;
    if (_13587 == 0)
    {
        _13587 = NOVALUE;
        goto L9; // [194] 348
    }
    else{
        _13587 = NOVALUE;
    }

    /** preproc.e:113			integer rid = pp[PP_RID]*/
    _2 = (object)SEQ_PTR(_pp_24122);
    _rid_24172 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_rid_24172))
    _rid_24172 = (object)DBL_PTR(_rid_24172)->dbl;

    /** preproc.e:114			if rid = -1 then*/
    if (_rid_24172 != -1LL)
    goto LA; // [205] 307

    /** preproc.e:115				integer dll_id = open_dll(pp[PP_COMMAND])*/
    _2 = (object)SEQ_PTR(_pp_24122);
    _13590 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_13590);
    _dll_id_24176 = _7open_dll(_13590);
    _13590 = NOVALUE;
    if (!IS_ATOM_INT(_dll_id_24176)) {
        _1 = (object)(DBL_PTR(_dll_id_24176)->dbl);
        DeRefDS(_dll_id_24176);
        _dll_id_24176 = _1;
    }

    /** preproc.e:116				if dll_id = -1 then*/
    if (_dll_id_24176 != -1LL)
    goto LB; // [223] 247

    /** preproc.e:117					CompileErr(sprintf("Preprocessor shared library '%s' could not be loaded\n",*/
    _2 = (object)SEQ_PTR(_pp_24122);
    _13594 = (object)*(((s1_ptr)_2)->base + 2LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_13594);
    ((intptr_t*)_2)[1] = _13594;
    _13595 = MAKE_SEQ(_1);
    _13594 = NOVALUE;
    _13596 = EPrintf(-9999999, _13593, _13595);
    DeRefDS(_13595);
    _13595 = NOVALUE;
    RefDS(_22024);
    _49CompileErr(_13596, _22024, 1LL);
    _13596 = NOVALUE;
LB: 

    /** preproc.e:121				rid = define_c_func(dll_id, "preprocess", { E_SEQUENCE, E_SEQUENCE, E_SEQUENCE }, */
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 134217732LL;
    ((intptr_t*)_2)[2] = 134217732LL;
    ((intptr_t*)_2)[3] = 134217732LL;
    _13598 = MAKE_SEQ(_1);
    RefDS(_13597);
    _rid_24172 = _7define_c_func(_dll_id_24176, _13597, _13598, 100663300LL);
    _13598 = NOVALUE;
    if (!IS_ATOM_INT(_rid_24172)) {
        _1 = (object)(DBL_PTR(_rid_24172)->dbl);
        DeRefDS(_rid_24172);
        _rid_24172 = _1;
    }

    /** preproc.e:123				if rid = -1 then*/
    if (_rid_24172 != -1LL)
    goto LC; // [274] 291

    /** preproc.e:124					CompileErr("Preprocessor entry point cound not be found\n",,1)*/
    RefDS(_13601);
    RefDS(_22024);
    _49CompileErr(_13601, _22024, 1LL);

    /** preproc.e:126					Cleanup(1)*/
    _49Cleanup(1LL);
LC: 

    /** preproc.e:129				preprocessors[pp_id][PP_RID] = rid*/
    _2 = (object)SEQ_PTR(_13preprocessors_11334);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13preprocessors_11334 = MAKE_SEQ(_2);
    }
    _3 = (object)(_pp_id_24123 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _rid_24172;
    DeRef(_1);
    _13602 = NOVALUE;
LA: 

    /** preproc.e:132			if c_func(rid, { fname, post_fname, pp[PP_PARAMS] }) != 0 then*/
    _2 = (object)SEQ_PTR(_pp_24122);
    _13604 = (object)*(((s1_ptr)_2)->base + 3LL);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_fname_24121);
    ((intptr_t*)_2)[1] = _fname_24121;
    RefDS(_post_fname_24144);
    ((intptr_t*)_2)[2] = _post_fname_24144;
    Ref(_13604);
    ((intptr_t*)_2)[3] = _13604;
    _13605 = MAKE_SEQ(_1);
    _13604 = NOVALUE;
    _13606 = call_c(1, _rid_24172, _13605);
    DeRefDS(_13605);
    _13605 = NOVALUE;
    if (binary_op_a(EQUALS, _13606, 0LL)){
        DeRef(_13606);
        _13606 = NOVALUE;
        goto LD; // [326] 343
    }
    DeRef(_13606);
    _13606 = NOVALUE;

    /** preproc.e:133				CompileErr("Preprocessor call failed\n",,1)*/
    RefDS(_13608);
    RefDS(_22024);
    _49CompileErr(_13608, _22024, 1LL);

    /** preproc.e:135				Cleanup(1)*/
    _49Cleanup(1LL);
LD: 
    goto LE; // [345] 520
L9: 

    /** preproc.e:138			sequence public_cmd_args = {pp[PP_COMMAND]}*/
    _2 = (object)SEQ_PTR(_pp_24122);
    _13609 = (object)*(((s1_ptr)_2)->base + 2LL);
    _0 = _public_cmd_args_24212;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_13609);
    ((intptr_t*)_2)[1] = _13609;
    _public_cmd_args_24212 = MAKE_SEQ(_1);
    DeRef(_0);
    _13609 = NOVALUE;

    /** preproc.e:139			sequence cmd_args = {canonical_path(pp[PP_COMMAND],,TO_SHORT)}*/
    _2 = (object)SEQ_PTR(_pp_24122);
    _13611 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_13611);
    _13612 = _14canonical_path(_13611, 0LL, 4LL);
    _13611 = NOVALUE;
    _0 = _cmd_args_24215;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _13612;
    _cmd_args_24215 = MAKE_SEQ(_1);
    DeRef(_0);
    _13612 = NOVALUE;

    /** preproc.e:141			if equal(fileext(pp[PP_COMMAND]), "ex") then*/
    _2 = (object)SEQ_PTR(_pp_24122);
    _13614 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_13614);
    _13615 = _14fileext(_13614);
    _13614 = NOVALUE;
    if (_13615 == _13616)
    _13617 = 1;
    else if (IS_ATOM_INT(_13615) && IS_ATOM_INT(_13616))
    _13617 = 0;
    else
    _13617 = (compare(_13615, _13616) == 0);
    DeRef(_13615);
    _13615 = NOVALUE;
    if (_13617 == 0)
    {
        _13617 = NOVALUE;
        goto LF; // [390] 414
    }
    else{
        _13617 = NOVALUE;
    }

    /** preproc.e:142				public_cmd_args = { "eui" } & public_cmd_args*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_13618);
    ((intptr_t*)_2)[1] = _13618;
    _13619 = MAKE_SEQ(_1);
    Concat((object_ptr)&_public_cmd_args_24212, _13619, _public_cmd_args_24212);
    DeRefDS(_13619);
    _13619 = NOVALUE;
    DeRef(_13619);
    _13619 = NOVALUE;

    /** preproc.e:143				cmd_args = { "eui" } & cmd_args*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_13618);
    ((intptr_t*)_2)[1] = _13618;
    _13621 = MAKE_SEQ(_1);
    Concat((object_ptr)&_cmd_args_24215, _13621, _cmd_args_24215);
    DeRefDS(_13621);
    _13621 = NOVALUE;
    DeRef(_13621);
    _13621 = NOVALUE;
LF: 

    /** preproc.e:146			cmd_args &= { "-i", canonical_path(fname,,TO_SHORT), "-o", canonical_path(post_fname,,TO_SHORT) }*/
    RefDS(_fname_24121);
    _13624 = _14canonical_path(_fname_24121, 0LL, 4LL);
    RefDS(_post_fname_24144);
    _13626 = _14canonical_path(_post_fname_24144, 0LL, 4LL);
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_13623);
    ((intptr_t*)_2)[1] = _13623;
    ((intptr_t*)_2)[2] = _13624;
    RefDS(_13625);
    ((intptr_t*)_2)[3] = _13625;
    ((intptr_t*)_2)[4] = _13626;
    _13627 = MAKE_SEQ(_1);
    _13626 = NOVALUE;
    _13624 = NOVALUE;
    Concat((object_ptr)&_cmd_args_24215, _cmd_args_24215, _13627);
    DeRefDS(_13627);
    _13627 = NOVALUE;

    /** preproc.e:147			public_cmd_args &= { "-i", fname, "-o", post_fname }*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_13623);
    ((intptr_t*)_2)[1] = _13623;
    RefDS(_fname_24121);
    ((intptr_t*)_2)[2] = _fname_24121;
    RefDS(_13625);
    ((intptr_t*)_2)[3] = _13625;
    RefDS(_post_fname_24144);
    ((intptr_t*)_2)[4] = _post_fname_24144;
    _13629 = MAKE_SEQ(_1);
    Concat((object_ptr)&_public_cmd_args_24212, _public_cmd_args_24212, _13629);
    DeRefDS(_13629);
    _13629 = NOVALUE;

    /** preproc.e:148			sequence cmd = build_commandline( cmd_args ) & pp[PP_PARAMS]*/
    RefDS(_cmd_args_24215);
    _13631 = _48build_commandline(_cmd_args_24215);
    _2 = (object)SEQ_PTR(_pp_24122);
    _13632 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (IS_SEQUENCE(_13631) && IS_ATOM(_13632)) {
        Ref(_13632);
        Append(&_cmd_24244, _13631, _13632);
    }
    else if (IS_ATOM(_13631) && IS_SEQUENCE(_13632)) {
        Ref(_13631);
        Prepend(&_cmd_24244, _13632, _13631);
    }
    else {
        Concat((object_ptr)&_cmd_24244, _13631, _13632);
        DeRef(_13631);
        _13631 = NOVALUE;
    }
    DeRef(_13631);
    _13631 = NOVALUE;
    _13632 = NOVALUE;

    /** preproc.e:149			sequence pcmd = build_commandline(public_cmd_args) & pp[PP_PARAMS]*/
    RefDS(_public_cmd_args_24212);
    _13634 = _48build_commandline(_public_cmd_args_24212);
    _2 = (object)SEQ_PTR(_pp_24122);
    _13635 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (IS_SEQUENCE(_13634) && IS_ATOM(_13635)) {
        Ref(_13635);
        Append(&_pcmd_24249, _13634, _13635);
    }
    else if (IS_ATOM(_13634) && IS_SEQUENCE(_13635)) {
        Ref(_13634);
        Prepend(&_pcmd_24249, _13635, _13634);
    }
    else {
        Concat((object_ptr)&_pcmd_24249, _13634, _13635);
        DeRef(_13634);
        _13634 = NOVALUE;
    }
    DeRef(_13634);
    _13634 = NOVALUE;
    _13635 = NOVALUE;

    /** preproc.e:150			integer result = system_exec(cmd, 2)*/
    _result_24254 = system_exec_call(_cmd_24244, 2LL);

    /** preproc.e:151			if result != 0 then*/
    if (_result_24254 == 0LL)
    goto L10; // [492] 517

    /** preproc.e:152				CompileErr(sprintf("Preprocessor command failed (%d): %s\n", { result, pcmd } ),,1)*/
    RefDS(_pcmd_24249);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _result_24254;
    ((intptr_t *)_2)[2] = _pcmd_24249;
    _13640 = MAKE_SEQ(_1);
    _13641 = EPrintf(-9999999, _13639, _13640);
    DeRefDS(_13640);
    _13640 = NOVALUE;
    RefDS(_22024);
    _49CompileErr(_13641, _22024, 1LL);
    _13641 = NOVALUE;

    /** preproc.e:154				Cleanup(1)*/
    _49Cleanup(1LL);
L10: 
    DeRef(_public_cmd_args_24212);
    _public_cmd_args_24212 = NOVALUE;
    DeRef(_cmd_args_24215);
    _cmd_args_24215 = NOVALUE;
    DeRef(_cmd_24244);
    _cmd_24244 = NOVALUE;
    DeRef(_pcmd_24249);
    _pcmd_24249 = NOVALUE;
LE: 

    /** preproc.e:158		return post_fname*/
    DeRefDS(_fname_24121);
    DeRef(_pp_24122);
    _13577 = NOVALUE;
    return _post_fname_24144;
    ;
}



// 0x848046B4
