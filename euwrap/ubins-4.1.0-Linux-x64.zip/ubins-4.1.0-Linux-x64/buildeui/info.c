// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _40arch_bits()
{
    object _8364 = NOVALUE;
    object _8363 = NOVALUE;
    object _8362 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:72		return sprintf( "%d-bit", 8 * sizeof( C_POINTER ) )*/
    _8362 = eu_sizeof( 50331649LL );
    {
        int128_t p128 = (int128_t)8LL * (int128_t)_8362;
        if( p128 != (int128_t)(_8363 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
            _8363 = NewDouble( (eudouble)p128 );
        }
    }
    _8362 = NOVALUE;
    _8364 = EPrintf(-9999999, _8361, _8363);
    DeRef(_8363);
    _8363 = NOVALUE;
    return _8364;
    ;
}


object _40version_major()
{
    object _8373 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:100		return version_info[MAJ_VER]*/
    _2 = (object)SEQ_PTR(_40version_info_14582);
    _8373 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_8373);
    return _8373;
    ;
}


object _40version_minor()
{
    object _8374 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:112		return version_info[MIN_VER]*/
    _2 = (object)SEQ_PTR(_40version_info_14582);
    _8374 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_8374);
    return _8374;
    ;
}


object _40version_patch()
{
    object _8375 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:124		return version_info[PAT_VER]*/
    _2 = (object)SEQ_PTR(_40version_info_14582);
    _8375 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_8375);
    return _8375;
    ;
}


object _40version_node(object _full_14627)
{
    object _8382 = NOVALUE;
    object _8381 = NOVALUE;
    object _8380 = NOVALUE;
    object _8379 = NOVALUE;
    object _8378 = NOVALUE;
    object _8377 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:141		if full or length(version_info[NODE]) < 12 then*/
    if (0LL != 0) {
        goto L1; // [5] 27
    }
    _2 = (object)SEQ_PTR(_40version_info_14582);
    _8377 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (IS_SEQUENCE(_8377)){
            _8378 = SEQ_PTR(_8377)->length;
    }
    else {
        _8378 = 1;
    }
    _8377 = NOVALUE;
    _8379 = (_8378 < 12LL);
    _8378 = NOVALUE;
    if (_8379 == 0)
    {
        DeRef(_8379);
        _8379 = NOVALUE;
        goto L2; // [23] 40
    }
    else{
        DeRef(_8379);
        _8379 = NOVALUE;
    }
L1: 

    /** info.e:142			return version_info[NODE]*/
    _2 = (object)SEQ_PTR(_40version_info_14582);
    _8380 = (object)*(((s1_ptr)_2)->base + 5LL);
    Ref(_8380);
    _8377 = NOVALUE;
    return _8380;
L2: 

    /** info.e:145		return version_info[NODE][1..12]*/
    _2 = (object)SEQ_PTR(_40version_info_14582);
    _8381 = (object)*(((s1_ptr)_2)->base + 5LL);
    rhs_slice_target = (object_ptr)&_8382;
    RHS_Slice(_8381, 1LL, 12LL);
    _8381 = NOVALUE;
    _8380 = NOVALUE;
    _8377 = NOVALUE;
    return _8382;
    ;
}


object _40version_date(object _full_14641)
{
    object _8391 = NOVALUE;
    object _8390 = NOVALUE;
    object _8389 = NOVALUE;
    object _8388 = NOVALUE;
    object _8387 = NOVALUE;
    object _8386 = NOVALUE;
    object _8384 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:181		if full or is_developmental or length(version_info[REVISION_DATE]) < 10 then*/
    if (_full_14641 != 0) {
        _8384 = 1;
        goto L1; // [5] 15
    }
    _8384 = (_40is_developmental_14584 != 0);
L1: 
    if (_8384 != 0) {
        goto L2; // [15] 37
    }
    _2 = (object)SEQ_PTR(_40version_info_14582);
    _8386 = (object)*(((s1_ptr)_2)->base + 7LL);
    if (IS_SEQUENCE(_8386)){
            _8387 = SEQ_PTR(_8386)->length;
    }
    else {
        _8387 = 1;
    }
    _8386 = NOVALUE;
    _8388 = (_8387 < 10LL);
    _8387 = NOVALUE;
    if (_8388 == 0)
    {
        DeRef(_8388);
        _8388 = NOVALUE;
        goto L3; // [33] 50
    }
    else{
        DeRef(_8388);
        _8388 = NOVALUE;
    }
L2: 

    /** info.e:182			return version_info[REVISION_DATE]*/
    _2 = (object)SEQ_PTR(_40version_info_14582);
    _8389 = (object)*(((s1_ptr)_2)->base + 7LL);
    Ref(_8389);
    _8386 = NOVALUE;
    return _8389;
L3: 

    /** info.e:185		return version_info[REVISION_DATE][1..10]*/
    _2 = (object)SEQ_PTR(_40version_info_14582);
    _8390 = (object)*(((s1_ptr)_2)->base + 7LL);
    rhs_slice_target = (object_ptr)&_8391;
    RHS_Slice(_8390, 1LL, 10LL);
    _8390 = NOVALUE;
    _8386 = NOVALUE;
    _8389 = NOVALUE;
    return _8391;
    ;
}


object _40version_string(object _full_14656)
{
    object _version_revision_inlined_version_revision_at_41_14665 = NOVALUE;
    object _8411 = NOVALUE;
    object _8410 = NOVALUE;
    object _8409 = NOVALUE;
    object _8408 = NOVALUE;
    object _8407 = NOVALUE;
    object _8406 = NOVALUE;
    object _8405 = NOVALUE;
    object _8404 = NOVALUE;
    object _8402 = NOVALUE;
    object _8401 = NOVALUE;
    object _8400 = NOVALUE;
    object _8399 = NOVALUE;
    object _8398 = NOVALUE;
    object _8397 = NOVALUE;
    object _8396 = NOVALUE;
    object _8395 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:225		if full or is_developmental then*/
    if (0LL != 0) {
        goto L1; // [5] 16
    }
    if (_40is_developmental_14584 == 0)
    {
        goto L2; // [12] 80
    }
    else{
    }
L1: 

    /** info.e:226			return sprintf("%d.%d.%d %s (%d:%s, %s)", {*/
    _2 = (object)SEQ_PTR(_40version_info_14582);
    _8395 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_40version_info_14582);
    _8396 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_40version_info_14582);
    _8397 = (object)*(((s1_ptr)_2)->base + 3LL);
    _2 = (object)SEQ_PTR(_40version_info_14582);
    _8398 = (object)*(((s1_ptr)_2)->base + 4LL);

    /** info.e:157		return version_info[REVISION]*/
    DeRef(_version_revision_inlined_version_revision_at_41_14665);
    _2 = (object)SEQ_PTR(_40version_info_14582);
    _version_revision_inlined_version_revision_at_41_14665 = (object)*(((s1_ptr)_2)->base + 6LL);
    Ref(_version_revision_inlined_version_revision_at_41_14665);
    _8399 = _40version_node(0LL);
    _8400 = _40version_date(_full_14656);
    _1 = NewS1(7);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_8395);
    ((intptr_t*)_2)[1] = _8395;
    Ref(_8396);
    ((intptr_t*)_2)[2] = _8396;
    Ref(_8397);
    ((intptr_t*)_2)[3] = _8397;
    Ref(_8398);
    ((intptr_t*)_2)[4] = _8398;
    Ref(_version_revision_inlined_version_revision_at_41_14665);
    ((intptr_t*)_2)[5] = _version_revision_inlined_version_revision_at_41_14665;
    ((intptr_t*)_2)[6] = _8399;
    ((intptr_t*)_2)[7] = _8400;
    _8401 = MAKE_SEQ(_1);
    _8400 = NOVALUE;
    _8399 = NOVALUE;
    _8398 = NOVALUE;
    _8397 = NOVALUE;
    _8396 = NOVALUE;
    _8395 = NOVALUE;
    _8402 = EPrintf(-9999999, _8394, _8401);
    DeRefDS(_8401);
    _8401 = NOVALUE;
    return _8402;
    goto L3; // [77] 132
L2: 

    /** info.e:236			return sprintf("%d.%d.%d %s (%s, %s)", {*/
    _2 = (object)SEQ_PTR(_40version_info_14582);
    _8404 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_40version_info_14582);
    _8405 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_40version_info_14582);
    _8406 = (object)*(((s1_ptr)_2)->base + 3LL);
    _2 = (object)SEQ_PTR(_40version_info_14582);
    _8407 = (object)*(((s1_ptr)_2)->base + 4LL);
    _8408 = _40version_node(0LL);
    _8409 = _40version_date(_full_14656);
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_8404);
    ((intptr_t*)_2)[1] = _8404;
    Ref(_8405);
    ((intptr_t*)_2)[2] = _8405;
    Ref(_8406);
    ((intptr_t*)_2)[3] = _8406;
    Ref(_8407);
    ((intptr_t*)_2)[4] = _8407;
    ((intptr_t*)_2)[5] = _8408;
    ((intptr_t*)_2)[6] = _8409;
    _8410 = MAKE_SEQ(_1);
    _8409 = NOVALUE;
    _8408 = NOVALUE;
    _8407 = NOVALUE;
    _8406 = NOVALUE;
    _8405 = NOVALUE;
    _8404 = NOVALUE;
    _8411 = EPrintf(-9999999, _8403, _8410);
    DeRefDS(_8410);
    _8410 = NOVALUE;
    DeRef(_8402);
    _8402 = NOVALUE;
    return _8411;
L3: 
    ;
}


object _40version_string_long(object _full_14687)
{
    object _platform_name_inlined_platform_name_at_8_14691 = NOVALUE;
    object _8419 = NOVALUE;
    object _8418 = NOVALUE;
    object _8415 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:284		return version_string(full) & " for " & platform_name() & " " & arch_bits()*/
    _8415 = _40version_string(0LL);

    /** info.e:48		ifdef WINDOWS then*/

    /** info.e:51			return "Linux"*/
    RefDS(_8355);
    DeRefi(_platform_name_inlined_platform_name_at_8_14691);
    _platform_name_inlined_platform_name_at_8_14691 = _8355;
    _8418 = _40arch_bits();
    {
        object concat_list[5];

        concat_list[0] = _8418;
        concat_list[1] = _8417;
        concat_list[2] = _platform_name_inlined_platform_name_at_8_14691;
        concat_list[3] = _8416;
        concat_list[4] = _8415;
        Concat_N((object_ptr)&_8419, concat_list, 5);
    }
    DeRef(_8418);
    _8418 = NOVALUE;
    DeRef(_8415);
    _8415 = NOVALUE;
    return _8419;
    ;
}


object _40all_copyrights()
{
    object _pcre_copyright_inlined_pcre_copyright_at_19_14714 = NOVALUE;
    object _euphoria_copyright_2__tmp_at2_14712 = NOVALUE;
    object _euphoria_copyright_1__tmp_at2_14711 = NOVALUE;
    object _euphoria_copyright_inlined_euphoria_copyright_at_2_14710 = NOVALUE;
    object _8428 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:355		return {*/

    /** info.e:309		return {*/
    _0 = _euphoria_copyright_1__tmp_at2_14711;
    _euphoria_copyright_1__tmp_at2_14711 = _40version_string_long(0LL);
    DeRef(_0);
    if (IS_SEQUENCE(_8420) && IS_ATOM(_euphoria_copyright_1__tmp_at2_14711)) {
        Ref(_euphoria_copyright_1__tmp_at2_14711);
        Append(&_euphoria_copyright_2__tmp_at2_14712, _8420, _euphoria_copyright_1__tmp_at2_14711);
    }
    else if (IS_ATOM(_8420) && IS_SEQUENCE(_euphoria_copyright_1__tmp_at2_14711)) {
    }
    else {
        Concat((object_ptr)&_euphoria_copyright_2__tmp_at2_14712, _8420, _euphoria_copyright_1__tmp_at2_14711);
    }
    RefDS(_8423);
    RefDS(_euphoria_copyright_2__tmp_at2_14712);
    DeRef(_euphoria_copyright_inlined_euphoria_copyright_at_2_14710);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _euphoria_copyright_2__tmp_at2_14712;
    ((intptr_t *)_2)[2] = _8423;
    _euphoria_copyright_inlined_euphoria_copyright_at_2_14710 = MAKE_SEQ(_1);
    DeRef(_euphoria_copyright_1__tmp_at2_14711);
    _euphoria_copyright_1__tmp_at2_14711 = NOVALUE;
    DeRef(_euphoria_copyright_2__tmp_at2_14712);
    _euphoria_copyright_2__tmp_at2_14712 = NOVALUE;

    /** info.e:331		return {*/
    RefDS(_8426);
    RefDS(_8425);
    DeRef(_pcre_copyright_inlined_pcre_copyright_at_19_14714);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _8425;
    ((intptr_t *)_2)[2] = _8426;
    _pcre_copyright_inlined_pcre_copyright_at_19_14714 = MAKE_SEQ(_1);
    RefDS(_pcre_copyright_inlined_pcre_copyright_at_19_14714);
    RefDS(_euphoria_copyright_inlined_euphoria_copyright_at_2_14710);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _euphoria_copyright_inlined_euphoria_copyright_at_2_14710;
    ((intptr_t *)_2)[2] = _pcre_copyright_inlined_pcre_copyright_at_19_14714;
    _8428 = MAKE_SEQ(_1);
    return _8428;
    ;
}



// 0x5E0000E3
