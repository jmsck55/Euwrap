// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _65init_op_info()
{
    object _SHORT_CIRCUIT_24695 = NOVALUE;
    object _info_24740 = NOVALUE;
    object _13877 = NOVALUE;
    object _13876 = NOVALUE;
    object _13875 = NOVALUE;
    object _13874 = NOVALUE;
    object _13873 = NOVALUE;
    object _13872 = NOVALUE;
    object _13870 = NOVALUE;
    object _13869 = NOVALUE;
    object _13868 = NOVALUE;
    object _13867 = NOVALUE;
    object _13866 = NOVALUE;
    object _13865 = NOVALUE;
    object _13864 = NOVALUE;
    object _13863 = NOVALUE;
    object _13862 = NOVALUE;
    object _13861 = NOVALUE;
    object _13860 = NOVALUE;
    object _13859 = NOVALUE;
    object _13858 = NOVALUE;
    object _13857 = NOVALUE;
    object _13856 = NOVALUE;
    object _13855 = NOVALUE;
    object _13854 = NOVALUE;
    object _13853 = NOVALUE;
    object _13851 = NOVALUE;
    object _13850 = NOVALUE;
    object _13849 = NOVALUE;
    object _13848 = NOVALUE;
    object _13847 = NOVALUE;
    object _13846 = NOVALUE;
    object _13845 = NOVALUE;
    object _13844 = NOVALUE;
    object _13843 = NOVALUE;
    object _13842 = NOVALUE;
    object _13841 = NOVALUE;
    object _13840 = NOVALUE;
    object _13839 = NOVALUE;
    object _13838 = NOVALUE;
    object _13837 = NOVALUE;
    object _13836 = NOVALUE;
    object _13835 = NOVALUE;
    object _13834 = NOVALUE;
    object _13833 = NOVALUE;
    object _13832 = NOVALUE;
    object _13831 = NOVALUE;
    object _13830 = NOVALUE;
    object _13829 = NOVALUE;
    object _13828 = NOVALUE;
    object _13827 = NOVALUE;
    object _13826 = NOVALUE;
    object _13825 = NOVALUE;
    object _13824 = NOVALUE;
    object _13823 = NOVALUE;
    object _13822 = NOVALUE;
    object _13821 = NOVALUE;
    object _13820 = NOVALUE;
    object _13819 = NOVALUE;
    object _13818 = NOVALUE;
    object _13817 = NOVALUE;
    object _13816 = NOVALUE;
    object _13815 = NOVALUE;
    object _13814 = NOVALUE;
    object _13813 = NOVALUE;
    object _13812 = NOVALUE;
    object _13811 = NOVALUE;
    object _13810 = NOVALUE;
    object _13809 = NOVALUE;
    object _13808 = NOVALUE;
    object _13807 = NOVALUE;
    object _13806 = NOVALUE;
    object _13805 = NOVALUE;
    object _13804 = NOVALUE;
    object _13802 = NOVALUE;
    object _13801 = NOVALUE;
    object _13800 = NOVALUE;
    object _13799 = NOVALUE;
    object _13798 = NOVALUE;
    object _13797 = NOVALUE;
    object _13796 = NOVALUE;
    object _13795 = NOVALUE;
    object _13794 = NOVALUE;
    object _13793 = NOVALUE;
    object _13792 = NOVALUE;
    object _13791 = NOVALUE;
    object _13790 = NOVALUE;
    object _13789 = NOVALUE;
    object _13788 = NOVALUE;
    object _13787 = NOVALUE;
    object _13786 = NOVALUE;
    object _13785 = NOVALUE;
    object _13784 = NOVALUE;
    object _13783 = NOVALUE;
    object _13782 = NOVALUE;
    object _13781 = NOVALUE;
    object _13780 = NOVALUE;
    object _13779 = NOVALUE;
    object _13778 = NOVALUE;
    object _13777 = NOVALUE;
    object _13776 = NOVALUE;
    object _13775 = NOVALUE;
    object _13774 = NOVALUE;
    object _13773 = NOVALUE;
    object _13772 = NOVALUE;
    object _13771 = NOVALUE;
    object _13770 = NOVALUE;
    object _13769 = NOVALUE;
    object _13768 = NOVALUE;
    object _13767 = NOVALUE;
    object _13766 = NOVALUE;
    object _13765 = NOVALUE;
    object _13764 = NOVALUE;
    object _13763 = NOVALUE;
    object _13762 = NOVALUE;
    object _13761 = NOVALUE;
    object _13760 = NOVALUE;
    object _13759 = NOVALUE;
    object _13758 = NOVALUE;
    object _13757 = NOVALUE;
    object _13756 = NOVALUE;
    object _13755 = NOVALUE;
    object _13754 = NOVALUE;
    object _13753 = NOVALUE;
    object _13752 = NOVALUE;
    object _13751 = NOVALUE;
    object _13750 = NOVALUE;
    object _13749 = NOVALUE;
    object _13748 = NOVALUE;
    object _13747 = NOVALUE;
    object _13746 = NOVALUE;
    object _13745 = NOVALUE;
    object _13744 = NOVALUE;
    object _13743 = NOVALUE;
    object _13742 = NOVALUE;
    object _13741 = NOVALUE;
    object _13740 = NOVALUE;
    object _13739 = NOVALUE;
    object _13738 = NOVALUE;
    object _13737 = NOVALUE;
    object _13736 = NOVALUE;
    object _13735 = NOVALUE;
    object _13734 = NOVALUE;
    object _13733 = NOVALUE;
    object _13731 = NOVALUE;
    object _13730 = NOVALUE;
    object _13729 = NOVALUE;
    object _13728 = NOVALUE;
    object _13727 = NOVALUE;
    object _13726 = NOVALUE;
    object _13725 = NOVALUE;
    object _13724 = NOVALUE;
    object _13723 = NOVALUE;
    object _13722 = NOVALUE;
    object _13721 = NOVALUE;
    object _13720 = NOVALUE;
    object _13719 = NOVALUE;
    object _13718 = NOVALUE;
    object _13717 = NOVALUE;
    object _13716 = NOVALUE;
    object _13715 = NOVALUE;
    object _13714 = NOVALUE;
    object _13713 = NOVALUE;
    object _13712 = NOVALUE;
    object _13711 = NOVALUE;
    object _13710 = NOVALUE;
    object _13709 = NOVALUE;
    object _13708 = NOVALUE;
    object _13707 = NOVALUE;
    object _13706 = NOVALUE;
    object _13705 = NOVALUE;
    object _13703 = NOVALUE;
    object _13702 = NOVALUE;
    object _13701 = NOVALUE;
    object _13700 = NOVALUE;
    object _13699 = NOVALUE;
    object _13698 = NOVALUE;
    object _13697 = NOVALUE;
    object _13696 = NOVALUE;
    object _13695 = NOVALUE;
    object _13694 = NOVALUE;
    object _13693 = NOVALUE;
    object _13692 = NOVALUE;
    object _13691 = NOVALUE;
    object _13690 = NOVALUE;
    object _13689 = NOVALUE;
    object _13688 = NOVALUE;
    object _13687 = NOVALUE;
    object _13686 = NOVALUE;
    object _13685 = NOVALUE;
    object _13684 = NOVALUE;
    object _13683 = NOVALUE;
    object _13682 = NOVALUE;
    object _13681 = NOVALUE;
    object _13680 = NOVALUE;
    object _13679 = NOVALUE;
    object _13678 = NOVALUE;
    object _13677 = NOVALUE;
    object _13676 = NOVALUE;
    object _13675 = NOVALUE;
    object _13674 = NOVALUE;
    object _13673 = NOVALUE;
    object _13672 = NOVALUE;
    object _13671 = NOVALUE;
    object _13670 = NOVALUE;
    object _13669 = NOVALUE;
    object _13668 = NOVALUE;
    object _13667 = NOVALUE;
    object _13666 = NOVALUE;
    object _13665 = NOVALUE;
    object _13664 = NOVALUE;
    object _13663 = NOVALUE;
    object _13662 = NOVALUE;
    object _13661 = NOVALUE;
    object _13660 = NOVALUE;
    object _13659 = NOVALUE;
    object _13658 = NOVALUE;
    object _13656 = NOVALUE;
    object _13655 = NOVALUE;
    object _13654 = NOVALUE;
    object _13653 = NOVALUE;
    object _13652 = NOVALUE;
    object _13651 = NOVALUE;
    object _13650 = NOVALUE;
    object _13649 = NOVALUE;
    object _13648 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:44		op_info = repeat( 0, MAX_OPCODE )*/
    DeRef(_65op_info_24268);
    _65op_info_24268 = Repeat(0LL, 218LL);

    /** shift.e:45		op_info_size_type = repeat( 0, MAX_OPCODE )*/
    DeRef(_65op_info_size_type_24274);
    _65op_info_size_type_24274 = Repeat(0LL, 218LL);

    /** shift.e:46		op_info_size = repeat( 0, MAX_OPCODE )*/
    DeRef(_65op_info_size_24275);
    _65op_info_size_24275 = Repeat(0LL, 218LL);

    /** shift.e:47		op_info_addr = repeat( 0, MAX_OPCODE )*/
    DeRef(_65op_info_addr_24276);
    _65op_info_addr_24276 = Repeat(0LL, 218LL);

    /** shift.e:48		op_info_target = repeat( 0, MAX_OPCODE )*/
    DeRef(_65op_info_target_24277);
    _65op_info_target_24277 = Repeat(0LL, 218LL);

    /** shift.e:49		op_info_sub = repeat( 0, MAX_OPCODE )*/
    DeRef(_65op_info_sub_24278);
    _65op_info_sub_24278 = Repeat(0LL, 218LL);

    /** shift.e:51		op_info[ABORT               ] = { FIXED_SIZE, 2, {}, {}, {} }   -- ary: pun*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13648 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 126LL);
    *(intptr_t *)_2 = _13648;
    if( _1 != _13648 ){
    }
    _13648 = NOVALUE;

    /** shift.e:52		op_info[AND                 ] = { FIXED_SIZE, 4, {}, {}, {} }   -- ary: bin*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13649 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 8LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13649;
    if( _1 != _13649 ){
        DeRef(_1);
    }
    _13649 = NOVALUE;

    /** shift.e:53		op_info[AND_BITS            ] = { FIXED_SIZE, 4, {}, {3}, {} }   -- ary: bin*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13650 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 56LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13650;
    if( _1 != _13650 ){
        DeRef(_1);
    }
    _13650 = NOVALUE;

    /** shift.e:54		op_info[APPEND              ] = { FIXED_SIZE, 4, {}, {3}, {} }   -- ary: bin*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13651 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 35LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13651;
    if( _1 != _13651 ){
        DeRef(_1);
    }
    _13651 = NOVALUE;

    /** shift.e:55		op_info[ARCTAN              ] = { FIXED_SIZE, 3, {}, {2}, {} }   -- ary: un*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13652 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 73LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13652;
    if( _1 != _13652 ){
        DeRef(_1);
    }
    _13652 = NOVALUE;

    /** shift.e:56		op_info[ASSIGN              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13653 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 18LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13653;
    if( _1 != _13653 ){
        DeRef(_1);
    }
    _13653 = NOVALUE;

    /** shift.e:57		op_info[ASSIGN_I            ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13654 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 113LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13654;
    if( _1 != _13654 ){
        DeRef(_1);
    }
    _13654 = NOVALUE;

    /** shift.e:58		op_info[ASSIGN_OP_SLICE     ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13491);
    ((intptr_t*)_2)[4] = _13491;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13655 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 150LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13655;
    if( _1 != _13655 ){
        DeRef(_1);
    }
    _13655 = NOVALUE;

    /** shift.e:59		op_info[ASSIGN_OP_SUBS      ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13656 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 149LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13656;
    if( _1 != _13656 ){
        DeRef(_1);
    }
    _13656 = NOVALUE;

    /** shift.e:60		op_info[ASSIGN_SLICE        ] = { FIXED_SIZE, 5, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13657);
    ((intptr_t*)_2)[4] = _13657;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13658 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 45LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13658;
    if( _1 != _13658 ){
        DeRef(_1);
    }
    _13658 = NOVALUE;

    /** shift.e:61		op_info[ASSIGN_SUBS         ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13657);
    ((intptr_t*)_2)[4] = _13657;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13659 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 16LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13659;
    if( _1 != _13659 ){
        DeRef(_1);
    }
    _13659 = NOVALUE;

    /** shift.e:62		op_info[ASSIGN_SUBS_CHECK   ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13657);
    ((intptr_t*)_2)[4] = _13657;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13660 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 84LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13660;
    if( _1 != _13660 ){
        DeRef(_1);
    }
    _13660 = NOVALUE;

    /** shift.e:63		op_info[ASSIGN_SUBS_I       ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13657);
    ((intptr_t*)_2)[4] = _13657;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13661 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 118LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13661;
    if( _1 != _13661 ){
        DeRef(_1);
    }
    _13661 = NOVALUE;

    /** shift.e:64		op_info[BADRETURNF          ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13662 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 43LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13662;
    if( _1 != _13662 ){
        DeRef(_1);
    }
    _13662 = NOVALUE;

    /** shift.e:65		op_info[CALL                ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13663 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 129LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13663;
    if( _1 != _13663 ){
        DeRef(_1);
    }
    _13663 = NOVALUE;

    /** shift.e:66		op_info[CALL_PROC           ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13664 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 136LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13664;
    if( _1 != _13664 ){
        DeRef(_1);
    }
    _13664 = NOVALUE;

    /** shift.e:67		op_info[CALL_FUNC           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13665 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 137LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13665;
    if( _1 != _13665 ){
        DeRef(_1);
    }
    _13665 = NOVALUE;

    /** shift.e:68		op_info[CASE                ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13666 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 186LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13666;
    if( _1 != _13666 ){
        DeRef(_1);
    }
    _13666 = NOVALUE;

    /** shift.e:69		op_info[CLEAR_SCREEN        ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13667 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 59LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13667;
    if( _1 != _13667 ){
        DeRef(_1);
    }
    _13667 = NOVALUE;

    /** shift.e:70		op_info[CLOSE               ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13668 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 86LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13668;
    if( _1 != _13668 ){
        DeRef(_1);
    }
    _13668 = NOVALUE;

    /** shift.e:71		op_info[COMMAND_LINE        ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13657);
    ((intptr_t*)_2)[4] = _13657;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13669 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 100LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13669;
    if( _1 != _13669 ){
        DeRef(_1);
    }
    _13669 = NOVALUE;

    /** shift.e:72		op_info[COMPARE             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13670 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 76LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13670;
    if( _1 != _13670 ){
        DeRef(_1);
    }
    _13670 = NOVALUE;

    /** shift.e:73		op_info[CONCAT              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13671 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13671;
    if( _1 != _13671 ){
        DeRef(_1);
    }
    _13671 = NOVALUE;

    /** shift.e:74		op_info[COS                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13672 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 81LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13672;
    if( _1 != _13672 ){
        DeRef(_1);
    }
    _13672 = NOVALUE;

    /** shift.e:75		op_info[COVERAGE_LINE       ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13673 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 210LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13673;
    if( _1 != _13673 ){
        DeRef(_1);
    }
    _13673 = NOVALUE;

    /** shift.e:76		op_info[COVERAGE_ROUTINE    ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13674 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 211LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13674;
    if( _1 != _13674 ){
        DeRef(_1);
    }
    _13674 = NOVALUE;

    /** shift.e:77		op_info[C_FUNC              ] = { FIXED_SIZE, 5, {}, {4}, {3} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13491);
    ((intptr_t*)_2)[4] = _13491;
    RefDS(_13268);
    ((intptr_t*)_2)[5] = _13268;
    _13675 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 133LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13675;
    if( _1 != _13675 ){
        DeRef(_1);
    }
    _13675 = NOVALUE;

    /** shift.e:78		op_info[C_PROC              ] = { FIXED_SIZE, 4, {}, {}, {3} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[5] = _13268;
    _13676 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 132LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13676;
    if( _1 != _13676 ){
        DeRef(_1);
    }
    _13676 = NOVALUE;

    /** shift.e:79		op_info[DATE                ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13657);
    ((intptr_t*)_2)[4] = _13657;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13677 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 69LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13677;
    if( _1 != _13677 ){
        DeRef(_1);
    }
    _13677 = NOVALUE;

    /** shift.e:80		op_info[DELETE_ROUTINE      ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13678 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 204LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13678;
    if( _1 != _13678 ){
        DeRef(_1);
    }
    _13678 = NOVALUE;

    /** shift.e:81		op_info[DELETE_OBJECT       ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13679 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 205LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13679;
    if( _1 != _13679 ){
        DeRef(_1);
    }
    _13679 = NOVALUE;

    /** shift.e:82		op_info[DIV2                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13680 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 98LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13680;
    if( _1 != _13680 ){
        DeRef(_1);
    }
    _13680 = NOVALUE;

    /** shift.e:83		op_info[DIVIDE              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13681 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13681;
    if( _1 != _13681 ){
        DeRef(_1);
    }
    _13681 = NOVALUE;

    /** shift.e:84		op_info[ELSE                ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_13657);
    ((intptr_t*)_2)[3] = _13657;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13682 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13682;
    if( _1 != _13682 ){
        DeRef(_1);
    }
    _13682 = NOVALUE;

    /** shift.e:85		op_info[EXIT                ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_13657);
    ((intptr_t*)_2)[3] = _13657;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13683 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 61LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13683;
    if( _1 != _13683 ){
        DeRef(_1);
    }
    _13683 = NOVALUE;

    /** shift.e:86		op_info[EXIT_BLOCK          ] = { FIXED_SIZE, 2, {},  {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13684 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 206LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13684;
    if( _1 != _13684 ){
        DeRef(_1);
    }
    _13684 = NOVALUE;

    /** shift.e:87		op_info[ENDWHILE            ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_13657);
    ((intptr_t*)_2)[3] = _13657;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13685 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 22LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13685;
    if( _1 != _13685 ){
        DeRef(_1);
    }
    _13685 = NOVALUE;

    /** shift.e:88		op_info[RETRY               ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_13657);
    ((intptr_t*)_2)[3] = _13657;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13686 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 184LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13686;
    if( _1 != _13686 ){
        DeRef(_1);
    }
    _13686 = NOVALUE;

    /** shift.e:89		op_info[GOTO                ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_13657);
    ((intptr_t*)_2)[3] = _13657;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13687 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 188LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13687;
    if( _1 != _13687 ){
        DeRef(_1);
    }
    _13687 = NOVALUE;

    /** shift.e:90		op_info[ENDFOR_GENERAL      ] = { FIXED_SIZE, 5, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_13657);
    ((intptr_t*)_2)[3] = _13657;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13688 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13688;
    if( _1 != _13688 ){
        DeRef(_1);
    }
    _13688 = NOVALUE;

    /** shift.e:91		op_info[ENDFOR_UP           ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13657);
    ((intptr_t*)_2)[3] = _13657;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13689 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 49LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13689;
    if( _1 != _13689 ){
        DeRef(_1);
    }
    _13689 = NOVALUE;

    /** shift.e:92		op_info[ENDFOR_DOWN         ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13657);
    ((intptr_t*)_2)[3] = _13657;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13690 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 50LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13690;
    if( _1 != _13690 ){
        DeRef(_1);
    }
    _13690 = NOVALUE;

    /** shift.e:93		op_info[ENDFOR_INT_UP       ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13657);
    ((intptr_t*)_2)[3] = _13657;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13691 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 48LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13691;
    if( _1 != _13691 ){
        DeRef(_1);
    }
    _13691 = NOVALUE;

    /** shift.e:94		op_info[ENDFOR_INT_DOWN     ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13657);
    ((intptr_t*)_2)[3] = _13657;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13692 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 52LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13692;
    if( _1 != _13692 ){
        DeRef(_1);
    }
    _13692 = NOVALUE;

    /** shift.e:95		op_info[ENDFOR_INT_DOWN1    ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13657);
    ((intptr_t*)_2)[3] = _13657;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13693 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 55LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13693;
    if( _1 != _13693 ){
        DeRef(_1);
    }
    _13693 = NOVALUE;

    /** shift.e:96		op_info[ENDFOR_INT_UP1      ] = { FIXED_SIZE, 5, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_13657);
    ((intptr_t*)_2)[3] = _13657;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13694 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 54LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13694;
    if( _1 != _13694 ){
        DeRef(_1);
    }
    _13694 = NOVALUE;

    /** shift.e:97		op_info[EQUAL               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13695 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 153LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13695;
    if( _1 != _13695 ){
        DeRef(_1);
    }
    _13695 = NOVALUE;

    /** shift.e:98		op_info[EQUALS              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13696 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13696;
    if( _1 != _13696 ){
        DeRef(_1);
    }
    _13696 = NOVALUE;

    /** shift.e:99		op_info[EQUALS_IFW          ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13268);
    ((intptr_t*)_2)[3] = _13268;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13697 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 104LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13697;
    if( _1 != _13697 ){
        DeRef(_1);
    }
    _13697 = NOVALUE;

    /** shift.e:100		op_info[EQUALS_IFW_I        ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13268);
    ((intptr_t*)_2)[3] = _13268;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13698 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 121LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13698;
    if( _1 != _13698 ){
        DeRef(_1);
    }
    _13698 = NOVALUE;

    /** shift.e:101		op_info[FIND                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13699 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 77LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13699;
    if( _1 != _13699 ){
        DeRef(_1);
    }
    _13699 = NOVALUE;

    /** shift.e:102		op_info[FIND_FROM           ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13491);
    ((intptr_t*)_2)[4] = _13491;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13700 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 176LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13700;
    if( _1 != _13700 ){
        DeRef(_1);
    }
    _13700 = NOVALUE;

    /** shift.e:103		op_info[FLOOR               ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13701 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 83LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13701;
    if( _1 != _13701 ){
        DeRef(_1);
    }
    _13701 = NOVALUE;

    /** shift.e:104		op_info[FLOOR_DIV           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13702 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 63LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13702;
    if( _1 != _13702 ){
        DeRef(_1);
    }
    _13702 = NOVALUE;

    /** shift.e:105		op_info[FLOOR_DIV2          ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13703 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 66LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13703;
    if( _1 != _13703 ){
        DeRef(_1);
    }
    _13703 = NOVALUE;

    /** shift.e:106		op_info[FOR                 ] = { FIXED_SIZE, 7, {6}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 7LL;
    RefDS(_13704);
    ((intptr_t*)_2)[3] = _13704;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13705 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 21LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13705;
    if( _1 != _13705 ){
        DeRef(_1);
    }
    _13705 = NOVALUE;

    /** shift.e:107		op_info[FOR_I               ] = { FIXED_SIZE, 7, {6}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 7LL;
    RefDS(_13704);
    ((intptr_t*)_2)[3] = _13704;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13706 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 125LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13706;
    if( _1 != _13706 ){
        DeRef(_1);
    }
    _13706 = NOVALUE;

    /** shift.e:108		op_info[GETC                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13707 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13707;
    if( _1 != _13707 ){
        DeRef(_1);
    }
    _13707 = NOVALUE;

    /** shift.e:109		op_info[GETENV              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13708 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 91LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13708;
    if( _1 != _13708 ){
        DeRef(_1);
    }
    _13708 = NOVALUE;

    /** shift.e:110		op_info[GETS                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13709 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 17LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13709;
    if( _1 != _13709 ){
        DeRef(_1);
    }
    _13709 = NOVALUE;

    /** shift.e:111		op_info[GET_KEY             ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13657);
    ((intptr_t*)_2)[4] = _13657;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13710 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 79LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13710;
    if( _1 != _13710 ){
        DeRef(_1);
    }
    _13710 = NOVALUE;

    /** shift.e:112		op_info[GLABEL              ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_13657);
    ((intptr_t*)_2)[3] = _13657;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13711 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 189LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13711;
    if( _1 != _13711 ){
        DeRef(_1);
    }
    _13711 = NOVALUE;

    /** shift.e:113		op_info[GLOBAL_INIT_CHECK   ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13712 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 109LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13712;
    if( _1 != _13712 ){
        DeRef(_1);
    }
    _13712 = NOVALUE;

    /** shift.e:114		op_info[PRIVATE_INIT_CHECK  ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13713 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13713;
    if( _1 != _13713 ){
        DeRef(_1);
    }
    _13713 = NOVALUE;

    /** shift.e:115		op_info[GREATER             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13714 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13714;
    if( _1 != _13714 ){
        DeRef(_1);
    }
    _13714 = NOVALUE;

    /** shift.e:116		op_info[GREATEREQ           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13715 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13715;
    if( _1 != _13715 ){
        DeRef(_1);
    }
    _13715 = NOVALUE;

    /** shift.e:117		op_info[GREATEREQ_IFW       ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13268);
    ((intptr_t*)_2)[3] = _13268;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13716 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 103LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13716;
    if( _1 != _13716 ){
        DeRef(_1);
    }
    _13716 = NOVALUE;

    /** shift.e:118		op_info[GREATEREQ_IFW_I     ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13268);
    ((intptr_t*)_2)[3] = _13268;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13717 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 120LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13717;
    if( _1 != _13717 ){
        DeRef(_1);
    }
    _13717 = NOVALUE;

    /** shift.e:119		op_info[GREATER_IFW         ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13268);
    ((intptr_t*)_2)[3] = _13268;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13718 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 107LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13718;
    if( _1 != _13718 ){
        DeRef(_1);
    }
    _13718 = NOVALUE;

    /** shift.e:120		op_info[GREATER_IFW_I       ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13268);
    ((intptr_t*)_2)[3] = _13268;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13719 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 124LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13719;
    if( _1 != _13719 ){
        DeRef(_1);
    }
    _13719 = NOVALUE;

    /** shift.e:121		op_info[HASH                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13720 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 194LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13720;
    if( _1 != _13720 ){
        DeRef(_1);
    }
    _13720 = NOVALUE;

    /** shift.e:122		op_info[HEAD                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13721 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 198LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13721;
    if( _1 != _13721 ){
        DeRef(_1);
    }
    _13721 = NOVALUE;

    /** shift.e:123		op_info[IF                  ] = { FIXED_SIZE, 3, {2}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_13331);
    ((intptr_t*)_2)[3] = _13331;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13722 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 20LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13722;
    if( _1 != _13722 ){
        DeRef(_1);
    }
    _13722 = NOVALUE;

    /** shift.e:124		op_info[INSERT              ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13491);
    ((intptr_t*)_2)[4] = _13491;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13723 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 191LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13723;
    if( _1 != _13723 ){
        DeRef(_1);
    }
    _13723 = NOVALUE;

    /** shift.e:125		op_info[LENGTH              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13724 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 42LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13724;
    if( _1 != _13724 ){
        DeRef(_1);
    }
    _13724 = NOVALUE;

    /** shift.e:126		op_info[LESS                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13725 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13725;
    if( _1 != _13725 ){
        DeRef(_1);
    }
    _13725 = NOVALUE;

    /** shift.e:127		op_info[LESSEQ              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13726 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13726;
    if( _1 != _13726 ){
        DeRef(_1);
    }
    _13726 = NOVALUE;

    /** shift.e:128		op_info[LESSEQ_IFW          ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13268);
    ((intptr_t*)_2)[3] = _13268;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13727 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 106LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13727;
    if( _1 != _13727 ){
        DeRef(_1);
    }
    _13727 = NOVALUE;

    /** shift.e:129		op_info[LESSEQ_IFW_I        ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13268);
    ((intptr_t*)_2)[3] = _13268;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13728 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 123LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13728;
    if( _1 != _13728 ){
        DeRef(_1);
    }
    _13728 = NOVALUE;

    /** shift.e:130		op_info[LESS_IFW            ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13268);
    ((intptr_t*)_2)[3] = _13268;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13729 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 102LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13729;
    if( _1 != _13729 ){
        DeRef(_1);
    }
    _13729 = NOVALUE;

    /** shift.e:131		op_info[LESS_IFW_I          ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13268);
    ((intptr_t*)_2)[3] = _13268;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13730 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 119LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13730;
    if( _1 != _13730 ){
        DeRef(_1);
    }
    _13730 = NOVALUE;

    /** shift.e:132		op_info[LHS_SUBS            ] = { FIXED_SIZE, 5, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13731 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 95LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13731;
    if( _1 != _13731 ){
        DeRef(_1);
    }
    _13731 = NOVALUE;

    /** shift.e:133		op_info[LHS_SUBS1           ] = { FIXED_SIZE, 5, {}, {3,4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13732);
    ((intptr_t*)_2)[4] = _13732;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13733 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 161LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13733;
    if( _1 != _13733 ){
        DeRef(_1);
    }
    _13733 = NOVALUE;

    /** shift.e:134		op_info[LHS_SUBS1_COPY      ] = { FIXED_SIZE, 5, {}, {3,4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13732);
    ((intptr_t*)_2)[4] = _13732;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13734 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 166LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13734;
    if( _1 != _13734 ){
        DeRef(_1);
    }
    _13734 = NOVALUE;

    /** shift.e:135		op_info[LOG                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13735 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 74LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13735;
    if( _1 != _13735 ){
        DeRef(_1);
    }
    _13735 = NOVALUE;

    /** shift.e:136		op_info[MACHINE_FUNC        ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13736 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 111LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13736;
    if( _1 != _13736 ){
        DeRef(_1);
    }
    _13736 = NOVALUE;

    /** shift.e:137		op_info[MACHINE_PROC        ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13737 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 112LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13737;
    if( _1 != _13737 ){
        DeRef(_1);
    }
    _13737 = NOVALUE;

    /** shift.e:138		op_info[MATCH               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13738 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 78LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13738;
    if( _1 != _13738 ){
        DeRef(_1);
    }
    _13738 = NOVALUE;

    /** shift.e:139		op_info[MATCH_FROM          ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13491);
    ((intptr_t*)_2)[4] = _13491;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13739 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 177LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13739;
    if( _1 != _13739 ){
        DeRef(_1);
    }
    _13739 = NOVALUE;

    /** shift.e:140		op_info[MEM_COPY            ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13740 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 130LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13740;
    if( _1 != _13740 ){
        DeRef(_1);
    }
    _13740 = NOVALUE;

    /** shift.e:141		op_info[MEM_SET             ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13741 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 131LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13741;
    if( _1 != _13741 ){
        DeRef(_1);
    }
    _13741 = NOVALUE;

    /** shift.e:142		op_info[MINUS               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13742 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13742;
    if( _1 != _13742 ){
        DeRef(_1);
    }
    _13742 = NOVALUE;

    /** shift.e:143		op_info[MINUS_I             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13743 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 116LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13743;
    if( _1 != _13743 ){
        DeRef(_1);
    }
    _13743 = NOVALUE;

    /** shift.e:144		op_info[MULTIPLY            ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13744 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 13LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13744;
    if( _1 != _13744 ){
        DeRef(_1);
    }
    _13744 = NOVALUE;

    /** shift.e:145		op_info[NOP1                ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13745 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 159LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13745;
    if( _1 != _13745 ){
        DeRef(_1);
    }
    _13745 = NOVALUE;

    /** shift.e:146		op_info[NOPWHILE            ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13746 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 158LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13746;
    if( _1 != _13746 ){
        DeRef(_1);
    }
    _13746 = NOVALUE;

    /** shift.e:147		op_info[NOP2                ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13747 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 110LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13747;
    if( _1 != _13747 ){
        DeRef(_1);
    }
    _13747 = NOVALUE;

    /** shift.e:148		op_info[SC2_NULL            ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13748 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 145LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13748;
    if( _1 != _13748 ){
        DeRef(_1);
    }
    _13748 = NOVALUE;

    /** shift.e:149		op_info[ASSIGN_SUBS2        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13749 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 148LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13749;
    if( _1 != _13749 ){
        DeRef(_1);
    }
    _13749 = NOVALUE;

    /** shift.e:150		op_info[PLATFORM            ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13657);
    ((intptr_t*)_2)[4] = _13657;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13750 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 155LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13750;
    if( _1 != _13750 ){
        DeRef(_1);
    }
    _13750 = NOVALUE;

    /** shift.e:151		op_info[END_PARAM_CHECK     ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13751 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 156LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13751;
    if( _1 != _13751 ){
        DeRef(_1);
    }
    _13751 = NOVALUE;

    /** shift.e:153		op_info[NOPSWITCH           ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13752 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 187LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13752;
    if( _1 != _13752 ){
        DeRef(_1);
    }
    _13752 = NOVALUE;

    /** shift.e:154		op_info[NOT                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13753 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 7LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13753;
    if( _1 != _13753 ){
        DeRef(_1);
    }
    _13753 = NOVALUE;

    /** shift.e:155		op_info[NOTEQ               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13754 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13754;
    if( _1 != _13754 ){
        DeRef(_1);
    }
    _13754 = NOVALUE;

    /** shift.e:156		op_info[NOTEQ_IFW           ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13268);
    ((intptr_t*)_2)[3] = _13268;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13755 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 105LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13755;
    if( _1 != _13755 ){
        DeRef(_1);
    }
    _13755 = NOVALUE;

    /** shift.e:157		op_info[NOTEQ_IFW_I         ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13268);
    ((intptr_t*)_2)[3] = _13268;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13756 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 122LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13756;
    if( _1 != _13756 ){
        DeRef(_1);
    }
    _13756 = NOVALUE;

    /** shift.e:158		op_info[NOT_BITS            ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13757 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 51LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13757;
    if( _1 != _13757 ){
        DeRef(_1);
    }
    _13757 = NOVALUE;

    /** shift.e:159		op_info[NOT_IFW             ] = { FIXED_SIZE, 3, {2}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_13331);
    ((intptr_t*)_2)[3] = _13331;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13758 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 108LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13758;
    if( _1 != _13758 ){
        DeRef(_1);
    }
    _13758 = NOVALUE;

    /** shift.e:160		op_info[OPEN                ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13491);
    ((intptr_t*)_2)[4] = _13491;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13759 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 37LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13759;
    if( _1 != _13759 ){
        DeRef(_1);
    }
    _13759 = NOVALUE;

    /** shift.e:161		op_info[OPTION_SWITCHES     ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13657);
    ((intptr_t*)_2)[4] = _13657;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13760 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 183LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13760;
    if( _1 != _13760 ){
        DeRef(_1);
    }
    _13760 = NOVALUE;

    /** shift.e:162		op_info[OR                  ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13761 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13761;
    if( _1 != _13761 ){
        DeRef(_1);
    }
    _13761 = NOVALUE;

    /** shift.e:163		op_info[OR_BITS             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13762 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 24LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13762;
    if( _1 != _13762 ){
        DeRef(_1);
    }
    _13762 = NOVALUE;

    /** shift.e:164		op_info[PASSIGN_OP_SLICE    ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13491);
    ((intptr_t*)_2)[4] = _13491;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13763 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 165LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13763;
    if( _1 != _13763 ){
        DeRef(_1);
    }
    _13763 = NOVALUE;

    /** shift.e:165		op_info[PASSIGN_OP_SUBS     ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13764 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 164LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13764;
    if( _1 != _13764 ){
        DeRef(_1);
    }
    _13764 = NOVALUE;

    /** shift.e:166		op_info[PASSIGN_SLICE       ] = { FIXED_SIZE, 5, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13657);
    ((intptr_t*)_2)[4] = _13657;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13765 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 163LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13765;
    if( _1 != _13765 ){
        DeRef(_1);
    }
    _13765 = NOVALUE;

    /** shift.e:167		op_info[PASSIGN_SUBS        ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13657);
    ((intptr_t*)_2)[4] = _13657;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13766 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 162LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13766;
    if( _1 != _13766 ){
        DeRef(_1);
    }
    _13766 = NOVALUE;

    /** shift.e:168		op_info[PEEK_STRING         ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13767 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 182LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13767;
    if( _1 != _13767 ){
        DeRef(_1);
    }
    _13767 = NOVALUE;

    /** shift.e:169		op_info[PEEK8U              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13768 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 214LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13768;
    if( _1 != _13768 ){
        DeRef(_1);
    }
    _13768 = NOVALUE;

    /** shift.e:170		op_info[PEEK8S              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13769 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 213LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13769;
    if( _1 != _13769 ){
        DeRef(_1);
    }
    _13769 = NOVALUE;

    /** shift.e:171		op_info[PEEK2U              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13770 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 180LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13770;
    if( _1 != _13770 ){
        DeRef(_1);
    }
    _13770 = NOVALUE;

    /** shift.e:172		op_info[PEEK2S              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13771 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 179LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13771;
    if( _1 != _13771 ){
        DeRef(_1);
    }
    _13771 = NOVALUE;

    /** shift.e:173		op_info[PEEK4U              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13772 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 140LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13772;
    if( _1 != _13772 ){
        DeRef(_1);
    }
    _13772 = NOVALUE;

    /** shift.e:174		op_info[PEEK4S              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13773 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 139LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13773;
    if( _1 != _13773 ){
        DeRef(_1);
    }
    _13773 = NOVALUE;

    /** shift.e:175		op_info[PEEKS               ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13774 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 181LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13774;
    if( _1 != _13774 ){
        DeRef(_1);
    }
    _13774 = NOVALUE;

    /** shift.e:176		op_info[PEEK                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13775 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 127LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13775;
    if( _1 != _13775 ){
        DeRef(_1);
    }
    _13775 = NOVALUE;

    /** shift.e:177		op_info[SIZEOF              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13776 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 217LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13776;
    if( _1 != _13776 ){
        DeRef(_1);
    }
    _13776 = NOVALUE;

    /** shift.e:178		op_info[PEEK_POINTER        ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13777 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 216LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13777;
    if( _1 != _13777 ){
        DeRef(_1);
    }
    _13777 = NOVALUE;

    /** shift.e:179		op_info[PLENGTH             ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13778 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 160LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13778;
    if( _1 != _13778 ){
        DeRef(_1);
    }
    _13778 = NOVALUE;

    /** shift.e:180		op_info[PLUS                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13779 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13779;
    if( _1 != _13779 ){
        DeRef(_1);
    }
    _13779 = NOVALUE;

    /** shift.e:181		op_info[PLUS_I              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13780 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 115LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13780;
    if( _1 != _13780 ){
        DeRef(_1);
    }
    _13780 = NOVALUE;

    /** shift.e:182		op_info[PLUS1               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13781 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 93LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13781;
    if( _1 != _13781 ){
        DeRef(_1);
    }
    _13781 = NOVALUE;

    /** shift.e:183		op_info[PLUS1_I             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13782 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 117LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13782;
    if( _1 != _13782 ){
        DeRef(_1);
    }
    _13782 = NOVALUE;

    /** shift.e:184		op_info[POKE                ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13783 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 128LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13783;
    if( _1 != _13783 ){
        DeRef(_1);
    }
    _13783 = NOVALUE;

    /** shift.e:185		op_info[POKE2               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13784 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 178LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13784;
    if( _1 != _13784 ){
        DeRef(_1);
    }
    _13784 = NOVALUE;

    /** shift.e:186		op_info[POKE4               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13785 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 138LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13785;
    if( _1 != _13785 ){
        DeRef(_1);
    }
    _13785 = NOVALUE;

    /** shift.e:187		op_info[POKE8               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13786 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 212LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13786;
    if( _1 != _13786 ){
        DeRef(_1);
    }
    _13786 = NOVALUE;

    /** shift.e:188		op_info[POKE_POINTER        ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13787 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 215LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13787;
    if( _1 != _13787 ){
        DeRef(_1);
    }
    _13787 = NOVALUE;

    /** shift.e:189		op_info[POSITION            ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13788 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 60LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13788;
    if( _1 != _13788 ){
        DeRef(_1);
    }
    _13788 = NOVALUE;

    /** shift.e:190		op_info[POWER               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13789 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 72LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13789;
    if( _1 != _13789 ){
        DeRef(_1);
    }
    _13789 = NOVALUE;

    /** shift.e:191		op_info[PREPEND             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13790 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 57LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13790;
    if( _1 != _13790 ){
        DeRef(_1);
    }
    _13790 = NOVALUE;

    /** shift.e:192		op_info[PRINT               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13791 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 19LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13791;
    if( _1 != _13791 ){
        DeRef(_1);
    }
    _13791 = NOVALUE;

    /** shift.e:193		op_info[PRINTF              ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13792 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 38LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13792;
    if( _1 != _13792 ){
        DeRef(_1);
    }
    _13792 = NOVALUE;

    /** shift.e:194		op_info[PROFILE             ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13793 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 151LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13793;
    if( _1 != _13793 ){
        DeRef(_1);
    }
    _13793 = NOVALUE;

    /** shift.e:195		op_info[DISPLAY_VAR         ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13794 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 87LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13794;
    if( _1 != _13794 ){
        DeRef(_1);
    }
    _13794 = NOVALUE;

    /** shift.e:196		op_info[ERASE_PRIVATE_NAMES ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13795 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 88LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13795;
    if( _1 != _13795 ){
        DeRef(_1);
    }
    _13795 = NOVALUE;

    /** shift.e:197		op_info[ERASE_SYMBOL        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13796 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 90LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13796;
    if( _1 != _13796 ){
        DeRef(_1);
    }
    _13796 = NOVALUE;

    /** shift.e:198		op_info[PUTS                ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13797 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 44LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13797;
    if( _1 != _13797 ){
        DeRef(_1);
    }
    _13797 = NOVALUE;

    /** shift.e:199		op_info[QPRINT              ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13798 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13798;
    if( _1 != _13798 ){
        DeRef(_1);
    }
    _13798 = NOVALUE;

    /** shift.e:200		op_info[RAND                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13799 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 62LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13799;
    if( _1 != _13799 ){
        DeRef(_1);
    }
    _13799 = NOVALUE;

    /** shift.e:201		op_info[REMAINDER           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13800 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 71LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13800;
    if( _1 != _13800 ){
        DeRef(_1);
    }
    _13800 = NOVALUE;

    /** shift.e:202		op_info[REMOVE              ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13491);
    ((intptr_t*)_2)[4] = _13491;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13801 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 200LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13801;
    if( _1 != _13801 ){
        DeRef(_1);
    }
    _13801 = NOVALUE;

    /** shift.e:203		op_info[REPEAT              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13802 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13802;
    if( _1 != _13802 ){
        DeRef(_1);
    }
    _13802 = NOVALUE;

    /** shift.e:204		op_info[REPLACE             ] = { FIXED_SIZE, 6, {}, {5}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 6LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13803);
    ((intptr_t*)_2)[4] = _13803;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13804 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 201LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13804;
    if( _1 != _13804 ){
        DeRef(_1);
    }
    _13804 = NOVALUE;

    /** shift.e:205		op_info[RETURNF             ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13805 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 28LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13805;
    if( _1 != _13805 ){
        DeRef(_1);
    }
    _13805 = NOVALUE;

    /** shift.e:206		op_info[RETURNP             ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13806 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 29LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13806;
    if( _1 != _13806 ){
        DeRef(_1);
    }
    _13806 = NOVALUE;

    /** shift.e:207		op_info[RETURNT             ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13807 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 34LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13807;
    if( _1 != _13807 ){
        DeRef(_1);
    }
    _13807 = NOVALUE;

    /** shift.e:208		op_info[RHS_SLICE           ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13491);
    ((intptr_t*)_2)[4] = _13491;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13808 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 46LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13808;
    if( _1 != _13808 ){
        DeRef(_1);
    }
    _13808 = NOVALUE;

    /** shift.e:209		op_info[RHS_SUBS            ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13809 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13809;
    if( _1 != _13809 ){
        DeRef(_1);
    }
    _13809 = NOVALUE;

    /** shift.e:210		op_info[RHS_SUBS_I          ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13810 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 114LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13810;
    if( _1 != _13810 ){
        DeRef(_1);
    }
    _13810 = NOVALUE;

    /** shift.e:211		op_info[RHS_SUBS_CHECK      ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13811 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 92LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13811;
    if( _1 != _13811 ){
        DeRef(_1);
    }
    _13811 = NOVALUE;

    /** shift.e:212		op_info[RIGHT_BRACE_2       ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13812 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 85LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13812;
    if( _1 != _13812 ){
        DeRef(_1);
    }
    _13812 = NOVALUE;

    /** shift.e:214		op_info[ROUTINE_ID          ] = { FIXED_SIZE, 6 - TRANSLATE, {}, { 4 + not TRANSLATE }, {} }*/
    _13813 = 6LL - _12TRANSLATE_19834;
    _13814 = (_12TRANSLATE_19834 == 0);
    _13815 = 4LL + _13814;
    if ((object)((uintptr_t)_13815 + (uintptr_t)HIGH_BITS) >= 0){
        _13815 = NewDouble((eudouble)_13815);
    }
    _13814 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _13815;
    _13816 = MAKE_SEQ(_1);
    _13815 = NOVALUE;
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = _13813;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _13816;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13817 = MAKE_SEQ(_1);
    _13816 = NOVALUE;
    _13813 = NOVALUE;
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 134LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13817;
    if( _1 != _13817 ){
        DeRef(_1);
    }
    _13817 = NOVALUE;

    /** shift.e:215		op_info[SC2_OR              ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13818 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 144LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13818;
    if( _1 != _13818 ){
        DeRef(_1);
    }
    _13818 = NOVALUE;

    /** shift.e:216		op_info[SC2_AND             ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13819 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 142LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13819;
    if( _1 != _13819 ){
        DeRef(_1);
    }
    _13819 = NOVALUE;

    /** shift.e:217		op_info[SIN                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13820 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 80LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13820;
    if( _1 != _13820 ){
        DeRef(_1);
    }
    _13820 = NOVALUE;

    /** shift.e:218		op_info[SPACE_USED          ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13821 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 75LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13821;
    if( _1 != _13821 ){
        DeRef(_1);
    }
    _13821 = NOVALUE;

    /** shift.e:219		op_info[SPLICE              ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13491);
    ((intptr_t*)_2)[4] = _13491;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13822 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 190LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13822;
    if( _1 != _13822 ){
        DeRef(_1);
    }
    _13822 = NOVALUE;

    /** shift.e:220		op_info[SPRINTF             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13823 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 53LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13823;
    if( _1 != _13823 ){
        DeRef(_1);
    }
    _13823 = NOVALUE;

    /** shift.e:221		op_info[SQRT                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13824 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13824;
    if( _1 != _13824 ){
        DeRef(_1);
    }
    _13824 = NOVALUE;

    /** shift.e:222		op_info[STARTLINE           ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13825 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 58LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13825;
    if( _1 != _13825 ){
        DeRef(_1);
    }
    _13825 = NOVALUE;

    /** shift.e:223		op_info[SWITCH              ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_13491);
    ((intptr_t*)_2)[3] = _13491;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13826 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 185LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13826;
    if( _1 != _13826 ){
        DeRef(_1);
    }
    _13826 = NOVALUE;

    /** shift.e:224		op_info[SWITCH_I            ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_13491);
    ((intptr_t*)_2)[3] = _13491;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13827 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 193LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13827;
    if( _1 != _13827 ){
        DeRef(_1);
    }
    _13827 = NOVALUE;

    /** shift.e:225		op_info[SWITCH_SPI          ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_13491);
    ((intptr_t*)_2)[3] = _13491;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13828 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 192LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13828;
    if( _1 != _13828 ){
        DeRef(_1);
    }
    _13828 = NOVALUE;

    /** shift.e:226		op_info[SWITCH_RT           ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_13491);
    ((intptr_t*)_2)[3] = _13491;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13829 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 202LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13829;
    if( _1 != _13829 ){
        DeRef(_1);
    }
    _13829 = NOVALUE;

    /** shift.e:227		op_info[SYSTEM              ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13830 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 99LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13830;
    if( _1 != _13830 ){
        DeRef(_1);
    }
    _13830 = NOVALUE;

    /** shift.e:228		op_info[SYSTEM_EXEC         ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13831 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 154LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13831;
    if( _1 != _13831 ){
        DeRef(_1);
    }
    _13831 = NOVALUE;

    /** shift.e:229		op_info[TAIL                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13832 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 199LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13832;
    if( _1 != _13832 ){
        DeRef(_1);
    }
    _13832 = NOVALUE;

    /** shift.e:230		op_info[TAN                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13833 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 82LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13833;
    if( _1 != _13833 ){
        DeRef(_1);
    }
    _13833 = NOVALUE;

    /** shift.e:231		op_info[TASK_CLOCK_START    ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13834 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 175LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13834;
    if( _1 != _13834 ){
        DeRef(_1);
    }
    _13834 = NOVALUE;

    /** shift.e:232		op_info[TASK_CLOCK_STOP     ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13835 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 174LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13835;
    if( _1 != _13835 ){
        DeRef(_1);
    }
    _13835 = NOVALUE;

    /** shift.e:233		op_info[TASK_CREATE         ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13836 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 167LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13836;
    if( _1 != _13836 ){
        DeRef(_1);
    }
    _13836 = NOVALUE;

    /** shift.e:234		op_info[TASK_LIST           ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13657);
    ((intptr_t*)_2)[4] = _13657;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13837 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 172LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13837;
    if( _1 != _13837 ){
        DeRef(_1);
    }
    _13837 = NOVALUE;

    /** shift.e:235		op_info[TASK_SCHEDULE       ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13838 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 168LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13838;
    if( _1 != _13838 ){
        DeRef(_1);
    }
    _13838 = NOVALUE;

    /** shift.e:236		op_info[TASK_SELF           ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13657);
    ((intptr_t*)_2)[4] = _13657;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13839 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 170LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13839;
    if( _1 != _13839 ){
        DeRef(_1);
    }
    _13839 = NOVALUE;

    /** shift.e:237		op_info[TASK_STATUS         ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13840 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 173LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13840;
    if( _1 != _13840 ){
        DeRef(_1);
    }
    _13840 = NOVALUE;

    /** shift.e:238		op_info[TASK_SUSPEND        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13841 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 171LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13841;
    if( _1 != _13841 ){
        DeRef(_1);
    }
    _13841 = NOVALUE;

    /** shift.e:239		op_info[TASK_YIELD          ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13842 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 169LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13842;
    if( _1 != _13842 ){
        DeRef(_1);
    }
    _13842 = NOVALUE;

    /** shift.e:240		op_info[TIME                ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13657);
    ((intptr_t*)_2)[4] = _13657;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13843 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 70LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13843;
    if( _1 != _13843 ){
        DeRef(_1);
    }
    _13843 = NOVALUE;

    /** shift.e:241		op_info[TRACE               ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13844 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 64LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13844;
    if( _1 != _13844 ){
        DeRef(_1);
    }
    _13844 = NOVALUE;

    /** shift.e:242		op_info[TYPE_CHECK          ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13845 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 65LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13845;
    if( _1 != _13845 ){
        DeRef(_1);
    }
    _13845 = NOVALUE;

    /** shift.e:243		op_info[UMINUS              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13846 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13846;
    if( _1 != _13846 ){
        DeRef(_1);
    }
    _13846 = NOVALUE;

    /** shift.e:244		op_info[UPDATE_GLOBALS      ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13847 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 89LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13847;
    if( _1 != _13847 ){
        DeRef(_1);
    }
    _13847 = NOVALUE;

    /** shift.e:245		op_info[WHILE               ] = { FIXED_SIZE, 3, {2}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_13331);
    ((intptr_t*)_2)[3] = _13331;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13848 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 47LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13848;
    if( _1 != _13848 ){
        DeRef(_1);
    }
    _13848 = NOVALUE;

    /** shift.e:246		op_info[XOR                 ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13849 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 152LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13849;
    if( _1 != _13849 ){
        DeRef(_1);
    }
    _13849 = NOVALUE;

    /** shift.e:247		op_info[XOR_BITS            ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13268);
    ((intptr_t*)_2)[4] = _13268;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13850 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 26LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13850;
    if( _1 != _13850 ){
        DeRef(_1);
    }
    _13850 = NOVALUE;

    /** shift.e:249		op_info[TYPE_CHECK_FORWARD  ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13851 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 197LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13851;
    if( _1 != _13851 ){
        DeRef(_1);
    }
    _13851 = NOVALUE;

    /** shift.e:251		sequence SHORT_CIRCUIT = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _0 = _SHORT_CIRCUIT_24695;
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13268);
    ((intptr_t*)_2)[3] = _13268;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _SHORT_CIRCUIT_24695 = MAKE_SEQ(_1);
    DeRef(_0);

    /** shift.e:252		op_info[SC1_AND_IF          ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_24695);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 146LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _SHORT_CIRCUIT_24695;
    DeRef(_1);

    /** shift.e:253		op_info[SC1_OR_IF           ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_24695);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 147LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _SHORT_CIRCUIT_24695;
    DeRef(_1);

    /** shift.e:254		op_info[SC1_AND             ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_24695);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 141LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _SHORT_CIRCUIT_24695;
    DeRef(_1);

    /** shift.e:255		op_info[SC1_OR              ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_24695);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 143LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _SHORT_CIRCUIT_24695;
    DeRef(_1);

    /** shift.e:257		op_info[ATOM_CHECK          ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13853 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 101LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13853;
    if( _1 != _13853 ){
        DeRef(_1);
    }
    _13853 = NOVALUE;

    /** shift.e:258		op_info[INTEGER_CHECK       ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13854 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 96LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13854;
    if( _1 != _13854 ){
        DeRef(_1);
    }
    _13854 = NOVALUE;

    /** shift.e:259		op_info[SEQUENCE_CHECK      ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13855 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 97LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13855;
    if( _1 != _13855 ){
        DeRef(_1);
    }
    _13855 = NOVALUE;

    /** shift.e:261		op_info[IS_AN_INTEGER       ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13856 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 94LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13856;
    if( _1 != _13856 ){
        DeRef(_1);
    }
    _13856 = NOVALUE;

    /** shift.e:262		op_info[IS_AN_ATOM          ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13857 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 67LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13857;
    if( _1 != _13857 ){
        DeRef(_1);
    }
    _13857 = NOVALUE;

    /** shift.e:263		op_info[IS_A_SEQUENCE       ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13858 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 68LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13858;
    if( _1 != _13858 ){
        DeRef(_1);
    }
    _13858 = NOVALUE;

    /** shift.e:264		op_info[IS_AN_OBJECT        ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13331);
    ((intptr_t*)_2)[4] = _13331;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13859 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13859;
    if( _1 != _13859 ){
        DeRef(_1);
    }
    _13859 = NOVALUE;

    /** shift.e:266		op_info[CALL_BACK_RETURN    ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13860 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 135LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13860;
    if( _1 != _13860 ){
        DeRef(_1);
    }
    _13860 = NOVALUE;

    /** shift.e:268		op_info[REF_TEMP            ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13861 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 207LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13861;
    if( _1 != _13861 ){
        DeRef(_1);
    }
    _13861 = NOVALUE;

    /** shift.e:269		op_info[DEREF_TEMP          ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13862 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 208LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13862;
    if( _1 != _13862 ){
        DeRef(_1);
    }
    _13862 = NOVALUE;

    /** shift.e:270		op_info[NOVALUE_TEMP        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13863 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 209LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13863;
    if( _1 != _13863 ){
        DeRef(_1);
    }
    _13863 = NOVALUE;

    /** shift.e:272		op_info[PROC_FORWARD        ] = { VARIABLE_SIZE, 0, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 2LL;
    ((intptr_t*)_2)[2] = 0LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13864 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 195LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13864;
    if( _1 != _13864 ){
        DeRef(_1);
    }
    _13864 = NOVALUE;

    /** shift.e:273		op_info[FUNC_FORWARD        ] = { VARIABLE_SIZE, 0, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 2LL;
    ((intptr_t*)_2)[2] = 0LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13865 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 196LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13865;
    if( _1 != _13865 ){
        DeRef(_1);
    }
    _13865 = NOVALUE;

    /** shift.e:275		op_info[RIGHT_BRACE_N       ] = { VARIABLE_SIZE, 3, {}, {}, {} } -- target: [pc+1] + 2*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 2LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13866 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13866;
    if( _1 != _13866 ){
        DeRef(_1);
    }
    _13866 = NOVALUE;

    /** shift.e:276		op_info[CONCAT_N            ] = { VARIABLE_SIZE, 0, {}, {}, {} } -- target: [pc+1] + 2*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 2LL;
    ((intptr_t*)_2)[2] = 0LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13867 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 157LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13867;
    if( _1 != _13867 ){
        DeRef(_1);
    }
    _13867 = NOVALUE;

    /** shift.e:277		op_info[PROC                ] = { VARIABLE_SIZE, 0, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 2LL;
    ((intptr_t*)_2)[2] = 0LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13868 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 27LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13868;
    if( _1 != _13868 ){
        DeRef(_1);
    }
    _13868 = NOVALUE;

    /** shift.e:278		op_info[PROC_TAIL           ] = op_info[PROC]*/
    _2 = (object)SEQ_PTR(_65op_info_24268);
    _13869 = (object)*(((s1_ptr)_2)->base + 27LL);
    Ref(_13869);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65op_info_24268 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 203LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13869;
    if( _1 != _13869 ){
        DeRef(_1);
    }
    _13869 = NOVALUE;

    /** shift.e:281		for i = 1 to MAX_OPCODE do*/
    _13870 = 218LL;
    {
        object _i_24737;
        _i_24737 = 1LL;
L1: 
        if (_i_24737 > 218LL){
            goto L2; // [3959] 4052
        }

        /** shift.e:282			object info = op_info[i]*/
        DeRef(_info_24740);
        _2 = (object)SEQ_PTR(_65op_info_24268);
        _info_24740 = (object)*(((s1_ptr)_2)->base + _i_24737);
        Ref(_info_24740);

        /** shift.e:283			if sequence( info ) then*/
        _13872 = IS_SEQUENCE(_info_24740);
        if (_13872 == 0)
        {
            _13872 = NOVALUE;
            goto L3; // [3979] 4043
        }
        else{
            _13872 = NOVALUE;
        }

        /** shift.e:284				op_info_size_type[i] = info[OP_SIZE_TYPE]*/
        _2 = (object)SEQ_PTR(_info_24740);
        _13873 = (object)*(((s1_ptr)_2)->base + 1LL);
        Ref(_13873);
        _2 = (object)SEQ_PTR(_65op_info_size_type_24274);
        _2 = (object)(((s1_ptr)_2)->base + _i_24737);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _13873;
        if( _1 != _13873 ){
            DeRef(_1);
        }
        _13873 = NOVALUE;

        /** shift.e:285				op_info_size[i] = info[OP_SIZE]*/
        _2 = (object)SEQ_PTR(_info_24740);
        _13874 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_13874);
        _2 = (object)SEQ_PTR(_65op_info_size_24275);
        _2 = (object)(((s1_ptr)_2)->base + _i_24737);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _13874;
        if( _1 != _13874 ){
            DeRef(_1);
        }
        _13874 = NOVALUE;

        /** shift.e:286				op_info_addr[i] = info[OP_ADDR]*/
        _2 = (object)SEQ_PTR(_info_24740);
        _13875 = (object)*(((s1_ptr)_2)->base + 3LL);
        Ref(_13875);
        _2 = (object)SEQ_PTR(_65op_info_addr_24276);
        _2 = (object)(((s1_ptr)_2)->base + _i_24737);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _13875;
        if( _1 != _13875 ){
            DeRef(_1);
        }
        _13875 = NOVALUE;

        /** shift.e:287				op_info_target[i] = info[OP_TARGET]*/
        _2 = (object)SEQ_PTR(_info_24740);
        _13876 = (object)*(((s1_ptr)_2)->base + 4LL);
        Ref(_13876);
        _2 = (object)SEQ_PTR(_65op_info_target_24277);
        _2 = (object)(((s1_ptr)_2)->base + _i_24737);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _13876;
        if( _1 != _13876 ){
            DeRef(_1);
        }
        _13876 = NOVALUE;

        /** shift.e:288				op_info_sub[i] = info[OP_SUB]*/
        _2 = (object)SEQ_PTR(_info_24740);
        _13877 = (object)*(((s1_ptr)_2)->base + 5LL);
        Ref(_13877);
        _2 = (object)SEQ_PTR(_65op_info_sub_24278);
        _2 = (object)(((s1_ptr)_2)->base + _i_24737);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _13877;
        if( _1 != _13877 ){
            DeRef(_1);
        }
        _13877 = NOVALUE;
L3: 
        DeRef(_info_24740);
        _info_24740 = NOVALUE;

        /** shift.e:290		end for*/
        _i_24737 = _i_24737 + 1LL;
        goto L1; // [4047] 3966
L2: 
        ;
    }

    /** shift.e:291	end procedure*/
    DeRef(_SHORT_CIRCUIT_24695);
    return;
    ;
}


object _65variable_op_size(object _pc_24751, object _op_24752, object _code_24753)
{
    object _int_24756 = NOVALUE;
    object _info_24762 = NOVALUE;
    object _13897 = NOVALUE;
    object _13894 = NOVALUE;
    object _13891 = NOVALUE;
    object _13888 = NOVALUE;
    object _13887 = NOVALUE;
    object _13886 = NOVALUE;
    object _13885 = NOVALUE;
    object _13884 = NOVALUE;
    object _13883 = NOVALUE;
    object _13881 = NOVALUE;
    object _13880 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:297		switch op do*/
    _0 = _op_24752;
    switch ( _0 ){ 

        /** shift.e:298			case PROC, PROC_TAIL then*/
        case 27:
        case 203:

        /** shift.e:299				sequence info = SymTab[code[pc+1]]*/
        _13880 = _pc_24751 + 1;
        _2 = (object)SEQ_PTR(_code_24753);
        _13881 = (object)*(((s1_ptr)_2)->base + _13880);
        DeRef(_info_24762);
        _2 = (object)SEQ_PTR(_13SymTab_11316);
        if (!IS_ATOM_INT(_13881)){
            _info_24762 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_13881)->dbl));
        }
        else{
            _info_24762 = (object)*(((s1_ptr)_2)->base + _13881);
        }
        Ref(_info_24762);

        /** shift.e:300				return info[S_NUM_ARGS] + 2 + (info[S_TOKEN] != PROC)*/
        _2 = (object)SEQ_PTR(_info_24762);
        if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
            _13883 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
        }
        else{
            _13883 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
        }
        if (IS_ATOM_INT(_13883)) {
            _13884 = _13883 + 2LL;
            if ((object)((uintptr_t)_13884 + (uintptr_t)HIGH_BITS) >= 0){
                _13884 = NewDouble((eudouble)_13884);
            }
        }
        else {
            _13884 = binary_op(PLUS, _13883, 2LL);
        }
        _13883 = NOVALUE;
        _2 = (object)SEQ_PTR(_info_24762);
        if (!IS_ATOM_INT(_12S_TOKEN_19869)){
            _13885 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
        }
        else{
            _13885 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
        }
        if (IS_ATOM_INT(_13885)) {
            _13886 = (_13885 != 27LL);
        }
        else {
            _13886 = binary_op(NOTEQ, _13885, 27LL);
        }
        _13885 = NOVALUE;
        if (IS_ATOM_INT(_13884) && IS_ATOM_INT(_13886)) {
            _13887 = _13884 + _13886;
            if ((object)((uintptr_t)_13887 + (uintptr_t)HIGH_BITS) >= 0){
                _13887 = NewDouble((eudouble)_13887);
            }
        }
        else {
            _13887 = binary_op(PLUS, _13884, _13886);
        }
        DeRef(_13884);
        _13884 = NOVALUE;
        DeRef(_13886);
        _13886 = NOVALUE;
        DeRefDS(_info_24762);
        DeRefDS(_code_24753);
        _13880 = NOVALUE;
        _13881 = NOVALUE;
        return _13887;
        goto L1; // [72] 157

        /** shift.e:302			case PROC_FORWARD then*/
        case 195:

        /** shift.e:303				int = code[pc+2]*/
        _13888 = _pc_24751 + 2LL;
        _2 = (object)SEQ_PTR(_code_24753);
        _int_24756 = (object)*(((s1_ptr)_2)->base + _13888);
        if (!IS_ATOM_INT(_int_24756))
        _int_24756 = (object)DBL_PTR(_int_24756)->dbl;

        /** shift.e:304				int += 3*/
        _int_24756 = _int_24756 + 3LL;
        goto L1; // [94] 157

        /** shift.e:305			case FUNC_FORWARD then*/
        case 196:

        /** shift.e:306				int = code[pc+2]*/
        _13891 = _pc_24751 + 2LL;
        _2 = (object)SEQ_PTR(_code_24753);
        _int_24756 = (object)*(((s1_ptr)_2)->base + _13891);
        if (!IS_ATOM_INT(_int_24756))
        _int_24756 = (object)DBL_PTR(_int_24756)->dbl;

        /** shift.e:307				int += 4*/
        _int_24756 = _int_24756 + 4LL;
        goto L1; // [116] 157

        /** shift.e:308			case RIGHT_BRACE_N, CONCAT_N then*/
        case 31:
        case 157:

        /** shift.e:309				int = code[pc+1]*/
        _13894 = _pc_24751 + 1;
        _2 = (object)SEQ_PTR(_code_24753);
        _int_24756 = (object)*(((s1_ptr)_2)->base + _13894);
        if (!IS_ATOM_INT(_int_24756))
        _int_24756 = (object)DBL_PTR(_int_24756)->dbl;

        /** shift.e:310				int += 3*/
        _int_24756 = _int_24756 + 3LL;
        goto L1; // [140] 157

        /** shift.e:311			case else*/
        default:

        /** shift.e:312				InternalErr( 269, {op} )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _op_24752;
        _13897 = MAKE_SEQ(_1);
        _49InternalErr(269LL, _13897);
        _13897 = NOVALUE;
    ;}L1: 

    /** shift.e:314		return int*/
    DeRefDS(_code_24753);
    DeRef(_13880);
    _13880 = NOVALUE;
    _13881 = NOVALUE;
    DeRef(_13887);
    _13887 = NOVALUE;
    DeRef(_13891);
    _13891 = NOVALUE;
    DeRef(_13888);
    _13888 = NOVALUE;
    DeRef(_13894);
    _13894 = NOVALUE;
    return _int_24756;
    ;
}


object _65op_size(object _pc_24796, object _code_24797)
{
    object _op_24800 = NOVALUE;
    object _int_24802 = NOVALUE;
    object _13902 = NOVALUE;
    object _13901 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:318		integer op = code[pc]*/
    _2 = (object)SEQ_PTR(_code_24797);
    _op_24800 = (object)*(((s1_ptr)_2)->base + _pc_24796);
    if (!IS_ATOM_INT(_op_24800))
    _op_24800 = (object)DBL_PTR(_op_24800)->dbl;

    /** shift.e:319		integer int = op_info_size_type[op]*/
    _2 = (object)SEQ_PTR(_65op_info_size_type_24274);
    _int_24802 = (object)*(((s1_ptr)_2)->base + _op_24800);
    if (!IS_ATOM_INT(_int_24802))
    _int_24802 = (object)DBL_PTR(_int_24802)->dbl;

    /** shift.e:321		if int = FIXED_SIZE then*/
    if (_int_24802 != 1LL)
    goto L1; // [21] 40

    /** shift.e:322			return op_info_size[op]*/
    _2 = (object)SEQ_PTR(_65op_info_size_24275);
    _13901 = (object)*(((s1_ptr)_2)->base + _op_24800);
    Ref(_13901);
    DeRefDS(_code_24797);
    return _13901;
    goto L2; // [37] 53
L1: 

    /** shift.e:324			return variable_op_size( pc, op, code )*/
    RefDS(_code_24797);
    _13902 = _65variable_op_size(_pc_24796, _op_24800, _code_24797);
    DeRefDS(_code_24797);
    _13901 = NOVALUE;
    return _13902;
L2: 
    ;
}


object _65advance(object _pc_24811, object _code_24812)
{
    object _size_24815 = NOVALUE;
    object _13904 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:329		integer size = op_size( pc, code )*/
    RefDS(_code_24812);
    _size_24815 = _65op_size(_pc_24811, _code_24812);
    if (!IS_ATOM_INT(_size_24815)) {
        _1 = (object)(DBL_PTR(_size_24815)->dbl);
        DeRefDS(_size_24815);
        _size_24815 = _1;
    }

    /** shift.e:330		return pc + size*/
    _13904 = _pc_24811 + _size_24815;
    if ((object)((uintptr_t)_13904 + (uintptr_t)HIGH_BITS) >= 0){
        _13904 = NewDouble((eudouble)_13904);
    }
    DeRefDS(_code_24812);
    return _13904;
    ;
}


void _65shift_switch(object _pc_24820, object _start_24821, object _amount_24822)
{
    object _addr_24823 = NOVALUE;
    object _jump_24855 = NOVALUE;
    object _13939 = NOVALUE;
    object _13938 = NOVALUE;
    object _13937 = NOVALUE;
    object _13936 = NOVALUE;
    object _13935 = NOVALUE;
    object _13934 = NOVALUE;
    object _13933 = NOVALUE;
    object _13932 = NOVALUE;
    object _13931 = NOVALUE;
    object _13930 = NOVALUE;
    object _13929 = NOVALUE;
    object _13927 = NOVALUE;
    object _13926 = NOVALUE;
    object _13925 = NOVALUE;
    object _13924 = NOVALUE;
    object _13923 = NOVALUE;
    object _13922 = NOVALUE;
    object _13921 = NOVALUE;
    object _13920 = NOVALUE;
    object _13918 = NOVALUE;
    object _13917 = NOVALUE;
    object _13916 = NOVALUE;
    object _13915 = NOVALUE;
    object _13914 = NOVALUE;
    object _13911 = NOVALUE;
    object _13909 = NOVALUE;
    object _13908 = NOVALUE;
    object _13907 = NOVALUE;
    object _13906 = NOVALUE;
    object _13905 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** shift.e:336		if sequence( Code[pc+4] ) then*/
    _13905 = _pc_24820 + 4LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _13906 = (object)*(((s1_ptr)_2)->base + _13905);
    _13907 = IS_SEQUENCE(_13906);
    _13906 = NOVALUE;
    if (_13907 == 0)
    {
        _13907 = NOVALUE;
        goto L1; // [22] 46
    }
    else{
        _13907 = NOVALUE;
    }

    /** shift.e:337			addr = Code[pc+4][2]*/
    _13908 = _pc_24820 + 4LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _13909 = (object)*(((s1_ptr)_2)->base + _13908);
    _2 = (object)SEQ_PTR(_13909);
    _addr_24823 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_addr_24823)){
        _addr_24823 = (object)DBL_PTR(_addr_24823)->dbl;
    }
    _13909 = NOVALUE;
    goto L2; // [43] 61
L1: 

    /** shift.e:339			addr = Code[pc+4]*/
    _13911 = _pc_24820 + 4LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _addr_24823 = (object)*(((s1_ptr)_2)->base + _13911);
    if (!IS_ATOM_INT(_addr_24823)){
        _addr_24823 = (object)DBL_PTR(_addr_24823)->dbl;
    }
L2: 

    /** shift.e:343		if start < addr then*/
    if (_start_24821 >= _addr_24823)
    goto L3; // [65] 137

    /** shift.e:344			if sequence( Code[pc+4] ) then*/
    _13914 = _pc_24820 + 4LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _13915 = (object)*(((s1_ptr)_2)->base + _13914);
    _13916 = IS_SEQUENCE(_13915);
    _13915 = NOVALUE;
    if (_13916 == 0)
    {
        _13916 = NOVALUE;
        goto L4; // [84] 115
    }
    else{
        _13916 = NOVALUE;
    }

    /** shift.e:345				Code[pc+4][2] += amount*/
    _13917 = _pc_24820 + 4LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    _3 = (object)(_13917 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _13920 = (object)*(((s1_ptr)_2)->base + 2LL);
    _13918 = NOVALUE;
    if (IS_ATOM_INT(_13920)) {
        _13921 = _13920 + _amount_24822;
        if ((object)((uintptr_t)_13921 + (uintptr_t)HIGH_BITS) >= 0){
            _13921 = NewDouble((eudouble)_13921);
        }
    }
    else {
        _13921 = binary_op(PLUS, _13920, _amount_24822);
    }
    _13920 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13921;
    if( _1 != _13921 ){
        DeRef(_1);
    }
    _13921 = NOVALUE;
    _13918 = NOVALUE;
    goto L5; // [112] 136
L4: 

    /** shift.e:347				Code[pc+4] += amount*/
    _13922 = _pc_24820 + 4LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _13923 = (object)*(((s1_ptr)_2)->base + _13922);
    if (IS_ATOM_INT(_13923)) {
        _13924 = _13923 + _amount_24822;
        if ((object)((uintptr_t)_13924 + (uintptr_t)HIGH_BITS) >= 0){
            _13924 = NewDouble((eudouble)_13924);
        }
    }
    else {
        _13924 = binary_op(PLUS, _13923, _amount_24822);
    }
    _13923 = NOVALUE;
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _13922);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13924;
    if( _1 != _13924 ){
        DeRef(_1);
    }
    _13924 = NOVALUE;
L5: 
L3: 

    /** shift.e:351		sequence jump = SymTab[Code[pc+3]][S_OBJ]*/
    _13925 = _pc_24820 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _13926 = (object)*(((s1_ptr)_2)->base + _13925);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_13926)){
        _13927 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_13926)->dbl));
    }
    else{
        _13927 = (object)*(((s1_ptr)_2)->base + _13926);
    }
    DeRef(_jump_24855);
    _2 = (object)SEQ_PTR(_13927);
    _jump_24855 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_jump_24855);
    _13927 = NOVALUE;

    /** shift.e:352		for i = 1 to length(jump) do*/
    if (IS_SEQUENCE(_jump_24855)){
            _13929 = SEQ_PTR(_jump_24855)->length;
    }
    else {
        _13929 = 1;
    }
    {
        object _i_24864;
        _i_24864 = 1LL;
L6: 
        if (_i_24864 > _13929){
            goto L7; // [168] 223
        }

        /** shift.e:353			if start > pc and start < pc + jump[i] then*/
        _13930 = (_start_24821 > _pc_24820);
        if (_13930 == 0) {
            goto L8; // [181] 216
        }
        _2 = (object)SEQ_PTR(_jump_24855);
        _13932 = (object)*(((s1_ptr)_2)->base + _i_24864);
        if (IS_ATOM_INT(_13932)) {
            _13933 = _pc_24820 + _13932;
            if ((object)((uintptr_t)_13933 + (uintptr_t)HIGH_BITS) >= 0){
                _13933 = NewDouble((eudouble)_13933);
            }
        }
        else {
            _13933 = binary_op(PLUS, _pc_24820, _13932);
        }
        _13932 = NOVALUE;
        if (IS_ATOM_INT(_13933)) {
            _13934 = (_start_24821 < _13933);
        }
        else {
            _13934 = binary_op(LESS, _start_24821, _13933);
        }
        DeRef(_13933);
        _13933 = NOVALUE;
        if (_13934 == 0) {
            DeRef(_13934);
            _13934 = NOVALUE;
            goto L8; // [198] 216
        }
        else {
            if (!IS_ATOM_INT(_13934) && DBL_PTR(_13934)->dbl == 0.0){
                DeRef(_13934);
                _13934 = NOVALUE;
                goto L8; // [198] 216
            }
            DeRef(_13934);
            _13934 = NOVALUE;
        }
        DeRef(_13934);
        _13934 = NOVALUE;

        /** shift.e:354				jump[i] += amount*/
        _2 = (object)SEQ_PTR(_jump_24855);
        _13935 = (object)*(((s1_ptr)_2)->base + _i_24864);
        if (IS_ATOM_INT(_13935)) {
            _13936 = _13935 + _amount_24822;
            if ((object)((uintptr_t)_13936 + (uintptr_t)HIGH_BITS) >= 0){
                _13936 = NewDouble((eudouble)_13936);
            }
        }
        else {
            _13936 = binary_op(PLUS, _13935, _amount_24822);
        }
        _13935 = NOVALUE;
        _2 = (object)SEQ_PTR(_jump_24855);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _jump_24855 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_24864);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _13936;
        if( _1 != _13936 ){
            DeRef(_1);
        }
        _13936 = NOVALUE;
L8: 

        /** shift.e:356		end for*/
        _i_24864 = _i_24864 + 1LL;
        goto L6; // [218] 175
L7: 
        ;
    }

    /** shift.e:357		SymTab[Code[pc+3]][S_OBJ] = jump*/
    _13937 = _pc_24820 + 3LL;
    _2 = (object)SEQ_PTR(_12Code_20315);
    _13938 = (object)*(((s1_ptr)_2)->base + _13937);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _13SymTab_11316 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_13938))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_13938)->dbl));
    else
    _3 = (object)(_13938 + ((s1_ptr)_2)->base);
    RefDS(_jump_24855);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _jump_24855;
    DeRef(_1);
    _13939 = NOVALUE;

    /** shift.e:358	end procedure*/
    DeRefDS(_jump_24855);
    DeRef(_13911);
    _13911 = NOVALUE;
    _13937 = NOVALUE;
    DeRef(_13917);
    _13917 = NOVALUE;
    _13926 = NOVALUE;
    _13938 = NOVALUE;
    DeRef(_13914);
    _13914 = NOVALUE;
    DeRef(_13908);
    _13908 = NOVALUE;
    DeRef(_13925);
    _13925 = NOVALUE;
    DeRef(_13905);
    _13905 = NOVALUE;
    DeRef(_13922);
    _13922 = NOVALUE;
    DeRef(_13930);
    _13930 = NOVALUE;
    return;
    ;
}


void _65shift_addr(object _pc_24883, object _amount_24884, object _start_24885, object _bound_24886)
{
    object _int_24887 = NOVALUE;
    object _13954 = NOVALUE;
    object _13951 = NOVALUE;
    object _13947 = NOVALUE;
    object _13942 = NOVALUE;
    object _13941 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_pc_24883)) {
        _1 = (object)(DBL_PTR(_pc_24883)->dbl);
        DeRefDS(_pc_24883);
        _pc_24883 = _1;
    }

    /** shift.e:362		if atom( Code[pc] ) then*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    _13941 = (object)*(((s1_ptr)_2)->base + _pc_24883);
    _13942 = IS_ATOM(_13941);
    _13941 = NOVALUE;
    if (_13942 == 0)
    {
        _13942 = NOVALUE;
        goto L1; // [20] 75
    }
    else{
        _13942 = NOVALUE;
    }

    /** shift.e:363			int = Code[pc]*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    _int_24887 = (object)*(((s1_ptr)_2)->base + _pc_24883);
    if (!IS_ATOM_INT(_int_24887)){
        _int_24887 = (object)DBL_PTR(_int_24887)->dbl;
    }

    /** shift.e:364			if int >= start then*/
    if (_int_24887 < _start_24885)
    goto L2; // [35] 139

    /** shift.e:365				if int < bound then*/
    if (_int_24887 >= _bound_24886)
    goto L3; // [41] 56

    /** shift.e:366					Code[pc] = start*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _pc_24883);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _start_24885;
    DeRef(_1);
    goto L2; // [53] 139
L3: 

    /** shift.e:368					int += amount*/
    _int_24887 = _int_24887 + _amount_24884;

    /** shift.e:369					Code[pc] = int*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _pc_24883);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_24887;
    DeRef(_1);
    goto L2; // [72] 139
L1: 

    /** shift.e:373			int = Code[pc][2]*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    _13947 = (object)*(((s1_ptr)_2)->base + _pc_24883);
    _2 = (object)SEQ_PTR(_13947);
    _int_24887 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_int_24887)){
        _int_24887 = (object)DBL_PTR(_int_24887)->dbl;
    }
    _13947 = NOVALUE;

    /** shift.e:374			if int >= start then*/
    if (_int_24887 < _start_24885)
    goto L4; // [91] 138

    /** shift.e:375				if int < bound then*/
    if (_int_24887 >= _bound_24886)
    goto L5; // [97] 117

    /** shift.e:376					Code[pc][2] = start*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    _3 = (object)(_pc_24883 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _start_24885;
    DeRef(_1);
    _13951 = NOVALUE;
    goto L6; // [114] 137
L5: 

    /** shift.e:378					int += amount*/
    _int_24887 = _int_24887 + _amount_24884;

    /** shift.e:379					Code[pc][2] = int*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _12Code_20315 = MAKE_SEQ(_2);
    }
    _3 = (object)(_pc_24883 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_24887;
    DeRef(_1);
    _13954 = NOVALUE;
L6: 
L4: 
L2: 

    /** shift.e:383	end procedure*/
    return;
    ;
}


void _65shift(object _start_24920, object _amount_24921, object _bound_24922)
{
    object _int_24925 = NOVALUE;
    object _pc_24938 = NOVALUE;
    object _op_24939 = NOVALUE;
    object _finish_24940 = NOVALUE;
    object _len_24943 = NOVALUE;
    object _size_type_24968 = NOVALUE;
    object _13981 = NOVALUE;
    object _13979 = NOVALUE;
    object _13976 = NOVALUE;
    object _13974 = NOVALUE;
    object _13971 = NOVALUE;
    object _13970 = NOVALUE;
    object _13969 = NOVALUE;
    object _13967 = NOVALUE;
    object _13962 = NOVALUE;
    object _13957 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_24920)) {
        _1 = (object)(DBL_PTR(_start_24920)->dbl);
        DeRefDS(_start_24920);
        _start_24920 = _1;
    }
    if (!IS_ATOM_INT(_amount_24921)) {
        _1 = (object)(DBL_PTR(_amount_24921)->dbl);
        DeRefDS(_amount_24921);
        _amount_24921 = _1;
    }
    if (!IS_ATOM_INT(_bound_24922)) {
        _1 = (object)(DBL_PTR(_bound_24922)->dbl);
        DeRefDS(_bound_24922);
        _bound_24922 = _1;
    }

    /** shift.e:388		if amount = 0 then*/
    if (_amount_24921 != 0LL)
    goto L1; // [9] 19

    /** shift.e:389			return*/
    return;
L1: 

    /** shift.e:392		integer int*/

    /** shift.e:393		for i = length( LineTable ) to 1 by -1 do*/
    if (IS_SEQUENCE(_12LineTable_20316)){
            _13957 = SEQ_PTR(_12LineTable_20316)->length;
    }
    else {
        _13957 = 1;
    }
    {
        object _i_24927;
        _i_24927 = _13957;
L2: 
        if (_i_24927 < 1LL){
            goto L3; // [28] 84
        }

        /** shift.e:394			int = LineTable[i]*/
        _2 = (object)SEQ_PTR(_12LineTable_20316);
        _int_24925 = (object)*(((s1_ptr)_2)->base + _i_24927);
        if (!IS_ATOM_INT(_int_24925)){
            _int_24925 = (object)DBL_PTR(_int_24925)->dbl;
        }

        /** shift.e:395			if int > 0 then*/
        if (_int_24925 <= 0LL)
        goto L4; // [47] 77

        /** shift.e:396				if int < start then*/
        if (_int_24925 >= _start_24920)
        goto L5; // [53] 62

        /** shift.e:397					exit*/
        goto L3; // [59] 84
L5: 

        /** shift.e:399				int += amount*/
        _int_24925 = _int_24925 + _amount_24921;

        /** shift.e:400				LineTable[i] = int*/
        _2 = (object)SEQ_PTR(_12LineTable_20316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _12LineTable_20316 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_24927);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _int_24925;
        DeRef(_1);
L4: 

        /** shift.e:402		end for*/
        _i_24927 = _i_24927 + -1LL;
        goto L2; // [79] 35
L3: 
        ;
    }

    /** shift.e:404		integer pc = 1*/
    _pc_24938 = 1LL;

    /** shift.e:405		integer op*/

    /** shift.e:406		integer finish = start + amount - 1*/
    _13962 = _start_24920 + _amount_24921;
    if ((object)((uintptr_t)_13962 + (uintptr_t)HIGH_BITS) >= 0){
        _13962 = NewDouble((eudouble)_13962);
    }
    if (IS_ATOM_INT(_13962)) {
        _finish_24940 = _13962 - 1LL;
    }
    else {
        _finish_24940 = NewDouble(DBL_PTR(_13962)->dbl - (eudouble)1LL);
    }
    DeRef(_13962);
    _13962 = NOVALUE;
    if (!IS_ATOM_INT(_finish_24940)) {
        _1 = (object)(DBL_PTR(_finish_24940)->dbl);
        DeRefDS(_finish_24940);
        _finish_24940 = _1;
    }

    /** shift.e:407		integer len = length( Code )*/
    if (IS_SEQUENCE(_12Code_20315)){
            _len_24943 = SEQ_PTR(_12Code_20315)->length;
    }
    else {
        _len_24943 = 1;
    }

    /** shift.e:408		while pc <= len do*/
L6: 
    if (_pc_24938 > _len_24943)
    goto L7; // [115] 278

    /** shift.e:409			op = Code[pc]*/
    _2 = (object)SEQ_PTR(_12Code_20315);
    _op_24939 = (object)*(((s1_ptr)_2)->base + _pc_24938);
    if (!IS_ATOM_INT(_op_24939)){
        _op_24939 = (object)DBL_PTR(_op_24939)->dbl;
    }

    /** shift.e:410			if pc < start or pc > finish then*/
    _13967 = (_pc_24938 < _start_24920);
    if (_13967 != 0) {
        goto L8; // [135] 148
    }
    _13969 = (_pc_24938 > _finish_24940);
    if (_13969 == 0)
    {
        DeRef(_13969);
        _13969 = NOVALUE;
        goto L9; // [144] 223
    }
    else{
        DeRef(_13969);
        _13969 = NOVALUE;
    }
L8: 

    /** shift.e:412				if length( op_info_addr[op] ) then*/
    _2 = (object)SEQ_PTR(_65op_info_addr_24276);
    _13970 = (object)*(((s1_ptr)_2)->base + _op_24939);
    if (IS_SEQUENCE(_13970)){
            _13971 = SEQ_PTR(_13970)->length;
    }
    else {
        _13971 = 1;
    }
    _13970 = NOVALUE;
    if (_13971 == 0)
    {
        _13971 = NOVALUE;
        goto LA; // [159] 222
    }
    else{
        _13971 = NOVALUE;
    }

    /** shift.e:414					switch op with fallthru do*/
    _0 = _op_24939;
    switch ( _0 ){ 

        /** shift.e:415						case SWITCH then*/
        case 185:
        case 193:
        case 192:
        case 202:

        /** shift.e:420							shift_switch( pc, start, amount )*/
        _65shift_switch(_pc_24938, _start_24920, _amount_24921);

        /** shift.e:421							break*/
        goto LB; // [188] 221

        /** shift.e:423						case else*/
        default:

        /** shift.e:424							int = op_info_addr[op][1]*/
        _2 = (object)SEQ_PTR(_65op_info_addr_24276);
        _13974 = (object)*(((s1_ptr)_2)->base + _op_24939);
        _2 = (object)SEQ_PTR(_13974);
        _int_24925 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (!IS_ATOM_INT(_int_24925)){
            _int_24925 = (object)DBL_PTR(_int_24925)->dbl;
        }
        _13974 = NOVALUE;

        /** shift.e:425							shift_addr( pc + int, amount, start, bound )*/
        _13976 = _pc_24938 + _int_24925;
        if ((object)((uintptr_t)_13976 + (uintptr_t)HIGH_BITS) >= 0){
            _13976 = NewDouble((eudouble)_13976);
        }
        _65shift_addr(_13976, _amount_24921, _start_24920, _bound_24922);
        _13976 = NOVALUE;
    ;}LB: 
LA: 
L9: 

    /** shift.e:430			integer size_type = op_info_size_type[op]*/
    _2 = (object)SEQ_PTR(_65op_info_size_type_24274);
    _size_type_24968 = (object)*(((s1_ptr)_2)->base + _op_24939);
    if (!IS_ATOM_INT(_size_type_24968))
    _size_type_24968 = (object)DBL_PTR(_size_type_24968)->dbl;

    /** shift.e:431			if size_type = FIXED_SIZE then*/
    if (_size_type_24968 != 1LL)
    goto LC; // [233] 254

    /** shift.e:433				pc += op_info_size[op]*/
    _2 = (object)SEQ_PTR(_65op_info_size_24275);
    _13979 = (object)*(((s1_ptr)_2)->base + _op_24939);
    if (IS_ATOM_INT(_13979)) {
        _pc_24938 = _pc_24938 + _13979;
    }
    else {
        _pc_24938 = binary_op(PLUS, _pc_24938, _13979);
    }
    _13979 = NOVALUE;
    if (!IS_ATOM_INT(_pc_24938)) {
        _1 = (object)(DBL_PTR(_pc_24938)->dbl);
        DeRefDS(_pc_24938);
        _pc_24938 = _1;
    }
    goto LD; // [251] 271
LC: 

    /** shift.e:435				pc += variable_op_size( pc, op )*/
    RefDS(_12Code_20315);
    _13981 = _65variable_op_size(_pc_24938, _op_24939, _12Code_20315);
    if (IS_ATOM_INT(_13981)) {
        _pc_24938 = _pc_24938 + _13981;
    }
    else {
        _pc_24938 = binary_op(PLUS, _pc_24938, _13981);
    }
    DeRef(_13981);
    _13981 = NOVALUE;
    if (!IS_ATOM_INT(_pc_24938)) {
        _1 = (object)(DBL_PTR(_pc_24938)->dbl);
        DeRefDS(_pc_24938);
        _pc_24938 = _1;
    }
LD: 

    /** shift.e:437		end while*/
    goto L6; // [275] 115
L7: 

    /** shift.e:438		shift_fwd_refs( start, amount )*/
    _42shift_fwd_refs(_start_24920, _amount_24921);

    /** shift.e:439		move_last_pc( amount )*/
    _45move_last_pc(_amount_24921);

    /** shift.e:440	end procedure*/
    DeRef(_13967);
    _13967 = NOVALUE;
    _13970 = NOVALUE;
    return;
    ;
}


void _65insert_code(object _code_24982, object _index_24983)
{
    object _13984 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:443		Code = splice( Code, code, index )*/
    {
        s1_ptr assign_space;
        insert_pos = _index_24983;
        if (insert_pos <= 0) {
            Concat(&_12Code_20315,_code_24982,_12Code_20315);
        }
        else if (insert_pos > SEQ_PTR(_12Code_20315)->length){
            Concat(&_12Code_20315,_12Code_20315,_code_24982);
        }
        else if (IS_SEQUENCE(_code_24982)) {
            if( _12Code_20315 != _12Code_20315 || SEQ_PTR( _12Code_20315 )->ref != 1 ){
                DeRef( _12Code_20315 );
                RefDS( _12Code_20315 );
            }
            assign_space = Add_internal_space( _12Code_20315, insert_pos,((s1_ptr)SEQ_PTR(_code_24982))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_code_24982), _12Code_20315 == _12Code_20315 );
            _12Code_20315 = MAKE_SEQ( assign_space );
        }
        else {
            if( _12Code_20315 == _12Code_20315 && SEQ_PTR( _12Code_20315 )->ref == 1 ){
                _12Code_20315 = Insert( _12Code_20315, _code_24982, insert_pos);
            }
            else {
                DeRef( _12Code_20315 );
                RefDS( _12Code_20315 );
                _12Code_20315 = Insert( _12Code_20315, _code_24982, insert_pos);
            }
        }
    }

    /** shift.e:444		shift( index, length( code ) )*/
    if (IS_SEQUENCE(_code_24982)){
            _13984 = SEQ_PTR(_code_24982)->length;
    }
    else {
        _13984 = 1;
    }
    _65shift(_index_24983, _13984, _index_24983);
    _13984 = NOVALUE;

    /** shift.e:445	end procedure*/
    DeRefDSi(_code_24982);
    return;
    ;
}


void _65replace_code(object _code_24990, object _start_24991, object _finish_24992)
{
    object _13989 = NOVALUE;
    object _13988 = NOVALUE;
    object _13987 = NOVALUE;
    object _13986 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_24991)) {
        _1 = (object)(DBL_PTR(_start_24991)->dbl);
        DeRefDS(_start_24991);
        _start_24991 = _1;
    }
    if (!IS_ATOM_INT(_finish_24992)) {
        _1 = (object)(DBL_PTR(_finish_24992)->dbl);
        DeRefDS(_finish_24992);
        _finish_24992 = _1;
    }

    /** shift.e:448		Code = replace( Code, code, start, finish )*/
    {
        intptr_t p1 = _12Code_20315;
        intptr_t p2 = _code_24990;
        intptr_t p3 = _start_24991;
        intptr_t p4 = _finish_24992;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_12Code_20315;
        Replace( &replace_params );
    }

    /** shift.e:449		shift( start, length( code ) - (finish - start + 1), finish )*/
    if (IS_SEQUENCE(_code_24990)){
            _13986 = SEQ_PTR(_code_24990)->length;
    }
    else {
        _13986 = 1;
    }
    _13987 = _finish_24992 - _start_24991;
    if ((object)((uintptr_t)_13987 +(uintptr_t) HIGH_BITS) >= 0){
        _13987 = NewDouble((eudouble)_13987);
    }
    if (IS_ATOM_INT(_13987)) {
        _13988 = _13987 + 1;
        if (_13988 > MAXINT){
            _13988 = NewDouble((eudouble)_13988);
        }
    }
    else
    _13988 = binary_op(PLUS, 1, _13987);
    DeRef(_13987);
    _13987 = NOVALUE;
    if (IS_ATOM_INT(_13988)) {
        _13989 = _13986 - _13988;
        if ((object)((uintptr_t)_13989 +(uintptr_t) HIGH_BITS) >= 0){
            _13989 = NewDouble((eudouble)_13989);
        }
    }
    else {
        _13989 = NewDouble((eudouble)_13986 - DBL_PTR(_13988)->dbl);
    }
    _13986 = NOVALUE;
    DeRef(_13988);
    _13988 = NOVALUE;
    _65shift(_start_24991, _13989, _finish_24992);
    _13989 = NOVALUE;

    /** shift.e:450	end procedure*/
    DeRefDS(_code_24990);
    return;
    ;
}


object _65current_op(object _pc_25002, object _code_25003)
{
    object _13997 = NOVALUE;
    object _13996 = NOVALUE;
    object _13995 = NOVALUE;
    object _13994 = NOVALUE;
    object _13993 = NOVALUE;
    object _13991 = NOVALUE;
    object _13990 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:456		if pc > length(code) or pc < 1 then*/
    if (IS_SEQUENCE(_code_25003)){
            _13990 = SEQ_PTR(_code_25003)->length;
    }
    else {
        _13990 = 1;
    }
    _13991 = (_pc_25002 > _13990);
    _13990 = NOVALUE;
    if (_13991 != 0) {
        goto L1; // [14] 27
    }
    _13993 = (_pc_25002 < 1LL);
    if (_13993 == 0)
    {
        DeRef(_13993);
        _13993 = NOVALUE;
        goto L2; // [23] 34
    }
    else{
        DeRef(_13993);
        _13993 = NOVALUE;
    }
L1: 

    /** shift.e:457			return {}*/
    RefDS(_5);
    DeRefDS(_code_25003);
    DeRef(_13991);
    _13991 = NOVALUE;
    return _5;
L2: 

    /** shift.e:459		return code[pc..pc-1+op_size( pc, code )]*/
    _13994 = _pc_25002 - 1LL;
    if ((object)((uintptr_t)_13994 +(uintptr_t) HIGH_BITS) >= 0){
        _13994 = NewDouble((eudouble)_13994);
    }
    RefDS(_code_25003);
    _13995 = _65op_size(_pc_25002, _code_25003);
    if (IS_ATOM_INT(_13994) && IS_ATOM_INT(_13995)) {
        _13996 = _13994 + _13995;
    }
    else {
        _13996 = binary_op(PLUS, _13994, _13995);
    }
    DeRef(_13994);
    _13994 = NOVALUE;
    DeRef(_13995);
    _13995 = NOVALUE;
    rhs_slice_target = (object_ptr)&_13997;
    RHS_Slice(_code_25003, _pc_25002, _13996);
    DeRefDS(_code_25003);
    DeRef(_13991);
    _13991 = NOVALUE;
    DeRef(_13996);
    _13996 = NOVALUE;
    return _13997;
    ;
}


object _65get_ops(object _pc_25017, object _offset_25018, object _num_ops_25019, object _code_25020)
{
    object _sign_25023 = NOVALUE;
    object _ops_25032 = NOVALUE;
    object _opx_25034 = NOVALUE;
    object _14014 = NOVALUE;
    object _14013 = NOVALUE;
    object _14009 = NOVALUE;
    object _14008 = NOVALUE;
    object _14007 = NOVALUE;
    object _14006 = NOVALUE;
    object _14005 = NOVALUE;
    object _14004 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:466		integer sign = offset >= 0*/
    _sign_25023 = (_offset_25018 >= 0LL);

    /** shift.e:467		if not sign then*/
    if (_sign_25023 != 0)
    goto L1; // [17] 33

    /** shift.e:468			offset = -offset*/
    _offset_25018 = - _offset_25018;

    /** shift.e:469			sign = -1*/
    _sign_25023 = -1LL;
L1: 

    /** shift.e:472		while offset do*/
L2: 
    if (_offset_25018 == 0)
    {
        goto L3; // [38] 63
    }
    else{
    }

    /** shift.e:473			pc = advance( pc )*/
    RefDS(_12Code_20315);
    _pc_25017 = _65advance(_pc_25017, _12Code_20315);
    if (!IS_ATOM_INT(_pc_25017)) {
        _1 = (object)(DBL_PTR(_pc_25017)->dbl);
        DeRefDS(_pc_25017);
        _pc_25017 = _1;
    }

    /** shift.e:474			offset -= sign*/
    _offset_25018 = _offset_25018 - _sign_25023;

    /** shift.e:475		end while*/
    goto L2; // [60] 38
L3: 

    /** shift.e:477		sequence ops = repeat( 0, num_ops )*/
    DeRef(_ops_25032);
    _ops_25032 = Repeat(0LL, _num_ops_25019);

    /** shift.e:478		integer opx = 1*/
    _opx_25034 = 1LL;

    /** shift.e:479		while num_ops and pc <= length(code) do*/
L4: 
    if (_num_ops_25019 == 0) {
        goto L5; // [79] 137
    }
    if (IS_SEQUENCE(_code_25020)){
            _14005 = SEQ_PTR(_code_25020)->length;
    }
    else {
        _14005 = 1;
    }
    _14006 = (_pc_25017 <= _14005);
    _14005 = NOVALUE;
    if (_14006 == 0)
    {
        DeRef(_14006);
        _14006 = NOVALUE;
        goto L5; // [91] 137
    }
    else{
        DeRef(_14006);
        _14006 = NOVALUE;
    }

    /** shift.e:480			ops[opx] = current_op( pc )*/
    RefDS(_12Code_20315);
    _14007 = _65current_op(_pc_25017, _12Code_20315);
    _2 = (object)SEQ_PTR(_ops_25032);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _ops_25032 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _opx_25034);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14007;
    if( _1 != _14007 ){
        DeRef(_1);
    }
    _14007 = NOVALUE;

    /** shift.e:481			pc += length( ops[opx] )*/
    _2 = (object)SEQ_PTR(_ops_25032);
    _14008 = (object)*(((s1_ptr)_2)->base + _opx_25034);
    if (IS_SEQUENCE(_14008)){
            _14009 = SEQ_PTR(_14008)->length;
    }
    else {
        _14009 = 1;
    }
    _14008 = NOVALUE;
    _pc_25017 = _pc_25017 + _14009;
    _14009 = NOVALUE;

    /** shift.e:482			opx += 1*/
    _opx_25034 = _opx_25034 + 1;

    /** shift.e:483			num_ops -= 1*/
    _num_ops_25019 = _num_ops_25019 - 1LL;

    /** shift.e:484		end while*/
    goto L4; // [134] 79
L5: 

    /** shift.e:485		if num_ops then*/
    if (_num_ops_25019 == 0)
    {
        goto L6; // [139] 156
    }
    else{
    }

    /** shift.e:486			ops = head( ops, length( ops ) - num_ops )*/
    if (IS_SEQUENCE(_ops_25032)){
            _14013 = SEQ_PTR(_ops_25032)->length;
    }
    else {
        _14013 = 1;
    }
    _14014 = _14013 - _num_ops_25019;
    if ((object)((uintptr_t)_14014 +(uintptr_t) HIGH_BITS) >= 0){
        _14014 = NewDouble((eudouble)_14014);
    }
    _14013 = NOVALUE;
    {
        int len = SEQ_PTR(_ops_25032)->length;
        int size = (IS_ATOM_INT(_14014)) ? _14014 : (object)(DBL_PTR(_14014)->dbl);
        if (size <= 0){
            DeRef( _ops_25032 );
            _ops_25032 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_ops_25032);
            DeRef(_ops_25032);
            _ops_25032 = _ops_25032;
        }
        else{
            Head(SEQ_PTR(_ops_25032),size+1,&_ops_25032);
        }
    }
    DeRef(_14014);
    _14014 = NOVALUE;
L6: 

    /** shift.e:488		return ops*/
    DeRefDS(_code_25020);
    _14008 = NOVALUE;
    return _ops_25032;
    ;
}


object _65find_ops(object _pc_25052, object _op_25053, object _code_25054)
{
    object _ops_25057 = NOVALUE;
    object _found_op_25061 = NOVALUE;
    object _14023 = NOVALUE;
    object _14021 = NOVALUE;
    object _14019 = NOVALUE;
    object _14016 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:492		sequence ops = {}*/
    RefDS(_5);
    DeRef(_ops_25057);
    _ops_25057 = _5;

    /** shift.e:493		while pc <= length(code) do*/
L1: 
    if (IS_SEQUENCE(_code_25054)){
            _14016 = SEQ_PTR(_code_25054)->length;
    }
    else {
        _14016 = 1;
    }
    if (_pc_25052 > _14016)
    goto L2; // [22] 74

    /** shift.e:494			sequence found_op = current_op( pc )*/
    RefDS(_12Code_20315);
    _0 = _found_op_25061;
    _found_op_25061 = _65current_op(_pc_25052, _12Code_20315);
    DeRef(_0);

    /** shift.e:495			if found_op[1] = op then*/
    _2 = (object)SEQ_PTR(_found_op_25061);
    _14019 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _14019, _op_25053)){
        _14019 = NOVALUE;
        goto L3; // [43] 58
    }
    _14019 = NOVALUE;

    /** shift.e:496				ops = append( ops, { pc, found_op } )*/
    RefDS(_found_op_25061);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _pc_25052;
    ((intptr_t *)_2)[2] = _found_op_25061;
    _14021 = MAKE_SEQ(_1);
    RefDS(_14021);
    Append(&_ops_25057, _ops_25057, _14021);
    DeRefDS(_14021);
    _14021 = NOVALUE;
L3: 

    /** shift.e:498			pc += length( found_op )*/
    if (IS_SEQUENCE(_found_op_25061)){
            _14023 = SEQ_PTR(_found_op_25061)->length;
    }
    else {
        _14023 = 1;
    }
    _pc_25052 = _pc_25052 + _14023;
    _14023 = NOVALUE;
    DeRefDS(_found_op_25061);
    _found_op_25061 = NOVALUE;

    /** shift.e:499		end while*/
    goto L1; // [71] 19
L2: 

    /** shift.e:500		return ops*/
    DeRefDS(_code_25054);
    return _ops_25057;
    ;
}


object _65get_target_sym(object _opseq_25073)
{
    object _op_25077 = NOVALUE;
    object _info_25079 = NOVALUE;
    object _targets_25095 = NOVALUE;
    object _sub_25110 = NOVALUE;
    object _14055 = NOVALUE;
    object _14054 = NOVALUE;
    object _14053 = NOVALUE;
    object _14052 = NOVALUE;
    object _14051 = NOVALUE;
    object _14050 = NOVALUE;
    object _14049 = NOVALUE;
    object _14047 = NOVALUE;
    object _14043 = NOVALUE;
    object _14042 = NOVALUE;
    object _14041 = NOVALUE;
    object _14040 = NOVALUE;
    object _14038 = NOVALUE;
    object _14037 = NOVALUE;
    object _14036 = NOVALUE;
    object _14035 = NOVALUE;
    object _14032 = NOVALUE;
    object _14031 = NOVALUE;
    object _14029 = NOVALUE;
    object _14025 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:509		if not length( opseq ) then*/
    if (IS_SEQUENCE(_opseq_25073)){
            _14025 = SEQ_PTR(_opseq_25073)->length;
    }
    else {
        _14025 = 1;
    }
    if (_14025 != 0)
    goto L1; // [8] 18
    _14025 = NOVALUE;

    /** shift.e:510			return 0*/
    DeRefDS(_opseq_25073);
    DeRef(_info_25079);
    return 0LL;
L1: 

    /** shift.e:512		integer op = opseq[1]*/
    _2 = (object)SEQ_PTR(_opseq_25073);
    _op_25077 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_op_25077))
    _op_25077 = (object)DBL_PTR(_op_25077)->dbl;

    /** shift.e:513		sequence info = op_info[op]*/
    DeRef(_info_25079);
    _2 = (object)SEQ_PTR(_65op_info_24268);
    _info_25079 = (object)*(((s1_ptr)_2)->base + _op_25077);
    Ref(_info_25079);

    /** shift.e:515		if info[OP_SIZE_TYPE] = FIXED_SIZE then*/
    _2 = (object)SEQ_PTR(_info_25079);
    _14029 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _14029, 1LL)){
        _14029 = NOVALUE;
        goto L2; // [40] 157
    }
    _14029 = NOVALUE;

    /** shift.e:516			switch length( info[OP_TARGET] ) do*/
    _2 = (object)SEQ_PTR(_info_25079);
    _14031 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_SEQUENCE(_14031)){
            _14032 = SEQ_PTR(_14031)->length;
    }
    else {
        _14032 = 1;
    }
    _14031 = NOVALUE;
    _0 = _14032;
    _14032 = NOVALUE;
    switch ( _0 ){ 

        /** shift.e:517				case 0 then*/
        case 0:

        /** shift.e:518					break*/
        goto L3; // [64] 152
        goto L3; // [66] 152

        /** shift.e:520				case 1 then*/
        case 1:

        /** shift.e:521					return opseq[info[OP_TARGET][1]+1]*/
        _2 = (object)SEQ_PTR(_info_25079);
        _14035 = (object)*(((s1_ptr)_2)->base + 4LL);
        _2 = (object)SEQ_PTR(_14035);
        _14036 = (object)*(((s1_ptr)_2)->base + 1LL);
        _14035 = NOVALUE;
        if (IS_ATOM_INT(_14036)) {
            _14037 = _14036 + 1;
        }
        else
        _14037 = binary_op(PLUS, 1, _14036);
        _14036 = NOVALUE;
        _2 = (object)SEQ_PTR(_opseq_25073);
        if (!IS_ATOM_INT(_14037)){
            _14038 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14037)->dbl));
        }
        else{
            _14038 = (object)*(((s1_ptr)_2)->base + _14037);
        }
        Ref(_14038);
        DeRefDS(_opseq_25073);
        DeRefDS(_info_25079);
        _14031 = NOVALUE;
        DeRef(_14037);
        _14037 = NOVALUE;
        return _14038;
        goto L3; // [94] 152

        /** shift.e:523				case else*/
        default:

        /** shift.e:524					sequence targets = info[OP_TARGET]*/
        DeRef(_targets_25095);
        _2 = (object)SEQ_PTR(_info_25079);
        _targets_25095 = (object)*(((s1_ptr)_2)->base + 4LL);
        Ref(_targets_25095);

        /** shift.e:525					for i = 1 to length( targets ) do*/
        if (IS_SEQUENCE(_targets_25095)){
                _14040 = SEQ_PTR(_targets_25095)->length;
        }
        else {
            _14040 = 1;
        }
        {
            object _i_25098;
            _i_25098 = 1LL;
L4: 
            if (_i_25098 > _14040){
                goto L5; // [113] 145
            }

            /** shift.e:526						targets[i] = opseq[targets[i] + 1]*/
            _2 = (object)SEQ_PTR(_targets_25095);
            _14041 = (object)*(((s1_ptr)_2)->base + _i_25098);
            if (IS_ATOM_INT(_14041)) {
                _14042 = _14041 + 1;
            }
            else
            _14042 = binary_op(PLUS, 1, _14041);
            _14041 = NOVALUE;
            _2 = (object)SEQ_PTR(_opseq_25073);
            if (!IS_ATOM_INT(_14042)){
                _14043 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14042)->dbl));
            }
            else{
                _14043 = (object)*(((s1_ptr)_2)->base + _14042);
            }
            Ref(_14043);
            _2 = (object)SEQ_PTR(_targets_25095);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _targets_25095 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _i_25098);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _14043;
            if( _1 != _14043 ){
                DeRef(_1);
            }
            _14043 = NOVALUE;

            /** shift.e:527					end for*/
            _i_25098 = _i_25098 + 1LL;
            goto L4; // [140] 120
L5: 
            ;
        }

        /** shift.e:529					return targets*/
        DeRefDS(_opseq_25073);
        DeRef(_info_25079);
        _14031 = NOVALUE;
        DeRef(_14042);
        _14042 = NOVALUE;
        _14038 = NOVALUE;
        DeRef(_14037);
        _14037 = NOVALUE;
        return _targets_25095;
    ;}L3: 
    DeRef(_targets_25095);
    _targets_25095 = NOVALUE;
    goto L6; // [154] 253
L2: 

    /** shift.e:535			switch op do*/
    _0 = _op_25077;
    switch ( _0 ){ 

        /** shift.e:536				case PROC, PROC_TAIL then*/
        case 27:
        case 203:

        /** shift.e:537					symtab_index sub = opseq[2]*/
        _2 = (object)SEQ_PTR(_opseq_25073);
        _sub_25110 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_sub_25110)){
            _sub_25110 = (object)DBL_PTR(_sub_25110)->dbl;
        }

        /** shift.e:538					if sym_token( sub ) = FUNC then*/
        _14047 = _53sym_token(_sub_25110);
        if (binary_op_a(NOTEQ, _14047, 501LL)){
            DeRef(_14047);
            _14047 = NOVALUE;
            goto L7; // [186] 204
        }
        DeRef(_14047);
        _14047 = NOVALUE;

        /** shift.e:539						return opseq[$]*/
        if (IS_SEQUENCE(_opseq_25073)){
                _14049 = SEQ_PTR(_opseq_25073)->length;
        }
        else {
            _14049 = 1;
        }
        _2 = (object)SEQ_PTR(_opseq_25073);
        _14050 = (object)*(((s1_ptr)_2)->base + _14049);
        Ref(_14050);
        DeRefDS(_opseq_25073);
        DeRef(_info_25079);
        _14031 = NOVALUE;
        DeRef(_14042);
        _14042 = NOVALUE;
        _14038 = NOVALUE;
        DeRef(_14037);
        _14037 = NOVALUE;
        return _14050;
L7: 
        goto L8; // [206] 252

        /** shift.e:542				case FUNC_FORWARD then*/
        case 196:

        /** shift.e:543					return opseq[$]*/
        if (IS_SEQUENCE(_opseq_25073)){
                _14051 = SEQ_PTR(_opseq_25073)->length;
        }
        else {
            _14051 = 1;
        }
        _2 = (object)SEQ_PTR(_opseq_25073);
        _14052 = (object)*(((s1_ptr)_2)->base + _14051);
        Ref(_14052);
        DeRefDS(_opseq_25073);
        DeRef(_info_25079);
        _14031 = NOVALUE;
        _14050 = NOVALUE;
        DeRef(_14042);
        _14042 = NOVALUE;
        _14038 = NOVALUE;
        DeRef(_14037);
        _14037 = NOVALUE;
        return _14052;
        goto L8; // [225] 252

        /** shift.e:545				case RIGHT_BRACE_N, CONCAT_N then*/
        case 31:
        case 157:

        /** shift.e:546					return opseq[opseq[2]+2]*/
        _2 = (object)SEQ_PTR(_opseq_25073);
        _14053 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (IS_ATOM_INT(_14053)) {
            _14054 = _14053 + 2LL;
        }
        else {
            _14054 = binary_op(PLUS, _14053, 2LL);
        }
        _14053 = NOVALUE;
        _2 = (object)SEQ_PTR(_opseq_25073);
        if (!IS_ATOM_INT(_14054)){
            _14055 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14054)->dbl));
        }
        else{
            _14055 = (object)*(((s1_ptr)_2)->base + _14054);
        }
        Ref(_14055);
        DeRefDS(_opseq_25073);
        DeRef(_info_25079);
        _14052 = NOVALUE;
        _14031 = NOVALUE;
        _14050 = NOVALUE;
        DeRef(_14042);
        _14042 = NOVALUE;
        DeRef(_14054);
        _14054 = NOVALUE;
        _14038 = NOVALUE;
        DeRef(_14037);
        _14037 = NOVALUE;
        return _14055;
    ;}L8: 
L6: 

    /** shift.e:551		return 0*/
    DeRefDS(_opseq_25073);
    DeRef(_info_25079);
    _14052 = NOVALUE;
    _14031 = NOVALUE;
    _14055 = NOVALUE;
    _14050 = NOVALUE;
    DeRef(_14042);
    _14042 = NOVALUE;
    DeRef(_14054);
    _14054 = NOVALUE;
    _14038 = NOVALUE;
    DeRef(_14037);
    _14037 = NOVALUE;
    return 0LL;
    ;
}



// 0x6CAE49D0
