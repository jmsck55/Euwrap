// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _34map(object _m_14754)
{
    object _8454 = NOVALUE;
    object _8453 = NOVALUE;
    object _8452 = NOVALUE;
    object _8450 = NOVALUE;
    object _8449 = NOVALUE;
    object _8448 = NOVALUE;
    object _8446 = NOVALUE;
    object _8445 = NOVALUE;
    object _8444 = NOVALUE;
    object _8442 = NOVALUE;
    object _8441 = NOVALUE;
    object _8438 = NOVALUE;
    object _8436 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:126		if not atom( m ) then*/
    _8436 = IS_ATOM(_m_14754);
    if (_8436 != 0)
    goto L1; // [6] 16
    _8436 = NOVALUE;

    /** map.e:127			return 0*/
    DeRef(_m_14754);
    return 0LL;
L1: 

    /** map.e:129		if length( eumem:ram_space ) < m then*/
    if (IS_SEQUENCE(_35ram_space_12732)){
            _8438 = SEQ_PTR(_35ram_space_12732)->length;
    }
    else {
        _8438 = 1;
    }
    if (binary_op_a(GREATEREQ, _8438, _m_14754)){
        _8438 = NOVALUE;
        goto L2; // [23] 34
    }
    _8438 = NOVALUE;

    /** map.e:130			return 0*/
    DeRef(_m_14754);
    return 0LL;
L2: 

    /** map.e:132		if m < 1 then*/
    if (binary_op_a(GREATEREQ, _m_14754, 1LL)){
        goto L3; // [36] 47
    }

    /** map.e:133			return 0*/
    DeRef(_m_14754);
    return 0LL;
L3: 

    /** map.e:135		if length( eumem:ram_space[m] ) != MAP_MAX then*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!IS_ATOM_INT(_m_14754)){
        _8441 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_m_14754)->dbl));
    }
    else{
        _8441 = (object)*(((s1_ptr)_2)->base + _m_14754);
    }
    if (IS_SEQUENCE(_8441)){
            _8442 = SEQ_PTR(_8441)->length;
    }
    else {
        _8442 = 1;
    }
    _8441 = NOVALUE;
    if (_8442 == 3LL)
    goto L4; // [58] 69

    /** map.e:136			return 0*/
    DeRef(_m_14754);
    _8441 = NOVALUE;
    return 0LL;
L4: 

    /** map.e:138		if not atom( eumem:ram_space[m][MAP_SIZE] ) then*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!IS_ATOM_INT(_m_14754)){
        _8444 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_m_14754)->dbl));
    }
    else{
        _8444 = (object)*(((s1_ptr)_2)->base + _m_14754);
    }
    _2 = (object)SEQ_PTR(_8444);
    _8445 = (object)*(((s1_ptr)_2)->base + 1LL);
    _8444 = NOVALUE;
    _8446 = IS_ATOM(_8445);
    _8445 = NOVALUE;
    if (_8446 != 0)
    goto L5; // [84] 94
    _8446 = NOVALUE;

    /** map.e:139			return 0*/
    DeRef(_m_14754);
    _8441 = NOVALUE;
    return 0LL;
L5: 

    /** map.e:141		if not sequence( eumem:ram_space[m][MAP_SLOTS] ) then*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!IS_ATOM_INT(_m_14754)){
        _8448 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_m_14754)->dbl));
    }
    else{
        _8448 = (object)*(((s1_ptr)_2)->base + _m_14754);
    }
    _2 = (object)SEQ_PTR(_8448);
    _8449 = (object)*(((s1_ptr)_2)->base + 2LL);
    _8448 = NOVALUE;
    _8450 = IS_SEQUENCE(_8449);
    _8449 = NOVALUE;
    if (_8450 != 0)
    goto L6; // [109] 119
    _8450 = NOVALUE;

    /** map.e:142			return 0*/
    DeRef(_m_14754);
    _8441 = NOVALUE;
    return 0LL;
L6: 

    /** map.e:144		if not atom( eumem:ram_space[m][MAP_MAX] ) then*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!IS_ATOM_INT(_m_14754)){
        _8452 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_m_14754)->dbl));
    }
    else{
        _8452 = (object)*(((s1_ptr)_2)->base + _m_14754);
    }
    _2 = (object)SEQ_PTR(_8452);
    _8453 = (object)*(((s1_ptr)_2)->base + 3LL);
    _8452 = NOVALUE;
    _8454 = IS_ATOM(_8453);
    _8453 = NOVALUE;
    if (_8454 != 0)
    goto L7; // [134] 144
    _8454 = NOVALUE;

    /** map.e:145			return 0*/
    DeRef(_m_14754);
    _8441 = NOVALUE;
    return 0LL;
L7: 

    /** map.e:147		return 1*/
    DeRef(_m_14754);
    _8441 = NOVALUE;
    return 1LL;
    ;
}


object _34new_map_seq(object _size_14785)
{
    object _slots_14786 = NOVALUE;
    object _8466 = NOVALUE;
    object _8465 = NOVALUE;
    object _8464 = NOVALUE;
    object _8463 = NOVALUE;
    object _8459 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:155		integer slots = DEFAULT_SIZE * 2*/
    _slots_14786 = 16LL;

    /** map.e:156		if size <= DEFAULT_SIZE then*/
    if (_size_14785 > 8LL)
    goto L1; // [11] 23

    /** map.e:157			size = DEFAULT_SIZE*/
    _size_14785 = 8LL;
    goto L2; // [20] 55
L1: 

    /** map.e:159			size = floor( size * 1.5 )*/
    _8459 = NewDouble((eudouble)_size_14785 * DBL_PTR(_8458)->dbl);
    _size_14785 = unary_op(FLOOR, _8459);
    DeRefDS(_8459);
    _8459 = NOVALUE;
    if (!IS_ATOM_INT(_size_14785)) {
        _1 = (object)(DBL_PTR(_size_14785)->dbl);
        DeRefDS(_size_14785);
        _size_14785 = _1;
    }

    /** map.e:160			while slots < size do*/
L3: 
    if (_slots_14786 >= _size_14785)
    goto L4; // [39] 54

    /** map.e:162				slots *= 2*/
    _slots_14786 = _slots_14786 + _slots_14786;

    /** map.e:163			end while*/
    goto L3; // [51] 39
L4: 
L2: 

    /** map.e:165		return { 0, repeat( EMPTY_SLOT, slots ), floor( size * 2/3 ) }*/
    _8463 = Repeat(_34EMPTY_SLOT_14742, _slots_14786);
    _8464 = _size_14785 + _size_14785;
    if ((object)((uintptr_t)_8464 + (uintptr_t)HIGH_BITS) >= 0){
        _8464 = NewDouble((eudouble)_8464);
    }
    if (IS_ATOM_INT(_8464)) {
        if (3LL > 0 && _8464 >= 0) {
            _8465 = _8464 / 3LL;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_8464 / (eudouble)3LL);
            if (_8464 != MININT)
            _8465 = (object)temp_dbl;
            else
            _8465 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _8464, 3LL);
        _8465 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_8464);
    _8464 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0LL;
    ((intptr_t*)_2)[2] = _8463;
    ((intptr_t*)_2)[3] = _8465;
    _8466 = MAKE_SEQ(_1);
    _8465 = NOVALUE;
    _8463 = NOVALUE;
    return _8466;
    ;
}


object _34lookup(object _key_14829, object _hashval_14830, object _slots_14832)
{
    object _mask_14833 = NOVALUE;
    object _index_14836 = NOVALUE;
    object _index_hash_14839 = NOVALUE;
    object _slot_14840 = NOVALUE;
    object _perturb_14841 = NOVALUE;
    object _this_hash_14842 = NOVALUE;
    object _this_key_14843 = NOVALUE;
    object _looks_14844 = NOVALUE;
    object _removed_slot_14845 = NOVALUE;
    object _8495 = NOVALUE;
    object _8482 = NOVALUE;
    object _8481 = NOVALUE;
    object _8480 = NOVALUE;
    object _8479 = NOVALUE;
    object _8477 = NOVALUE;
    object _8475 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:275		integer mask = length( slots ) - 1*/
    if (IS_SEQUENCE(_slots_14832)){
            _8475 = SEQ_PTR(_slots_14832)->length;
    }
    else {
        _8475 = 1;
    }
    _mask_14833 = _8475 - 1LL;
    _8475 = NOVALUE;

    /** map.e:276		integer index = and_bits( hashval, mask ) + 1*/
    {uintptr_t tu;
         tu = (uintptr_t)_hashval_14830 & (uintptr_t)_mask_14833;
         _8477 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_8477)) {
        _index_14836 = _8477 + 1;
    }
    else
    { // coercing _index_14836 to an integer 1
        _index_14836 = 1+(object)(DBL_PTR(_8477)->dbl);
        if( !IS_ATOM_INT(_index_14836) ){
            _index_14836 = (object)DBL_PTR(_index_14836)->dbl;
        }
    }
    DeRef(_8477);
    _8477 = NOVALUE;

    /** map.e:277		ifdef BITS64 then*/

    /** map.e:278			integer index_hash = index*/
    _index_hash_14839 = _index_14836;

    /** map.e:282		sequence slot*/

    /** map.e:284		integer perturb = hashval*/
    _perturb_14841 = _hashval_14830;

    /** map.e:285		integer this_hash*/

    /** map.e:286		object this_key*/

    /** map.e:287		integer looks = 0*/
    _looks_14844 = 0LL;

    /** map.e:288		integer removed_slot = 0*/
    _removed_slot_14845 = 0LL;

    /** map.e:289		while this_hash != hashval or not equal( this_key, key ) with entry do*/
    goto L1; // [54] 140
L2: 
    _8479 = (_this_hash_14842 != _hashval_14830);
    if (_8479 != 0) {
        DeRef(_8480);
        _8480 = 1;
        goto L3; // [63] 80
    }
    if (_this_key_14843 == _key_14829)
    _8481 = 1;
    else if (IS_ATOM_INT(_this_key_14843) && IS_ATOM_INT(_key_14829))
    _8481 = 0;
    else
    _8481 = (compare(_this_key_14843, _key_14829) == 0);
    _8482 = (_8481 == 0);
    _8481 = NOVALUE;
    _8480 = (_8482 != 0);
L3: 
    if (_8480 == 0)
    {
        _8480 = NOVALUE;
        goto L4; // [80] 217
    }
    else{
        _8480 = NOVALUE;
    }

    /** map.e:290			index_hash *= 4*/
    _index_hash_14839 = _index_hash_14839 * 4LL;

    /** map.e:291			index_hash += index*/
    _index_hash_14839 = _index_hash_14839 + _index_14836;

    /** map.e:292			index_hash += perturb*/
    _index_hash_14839 = _index_hash_14839 + _perturb_14841;

    /** map.e:293			index_hash += 1*/
    _index_hash_14839 = _index_hash_14839 + 1;

    /** map.e:294			index_hash = and_bits( 0xffff_ffff, index_hash )*/
    {uintptr_t tu;
         tu = (uintptr_t)4294967295LL & (uintptr_t)_index_hash_14839;
         _index_hash_14839 = MAKE_UINT(tu);
    }

    /** map.e:295			index = and_bits( mask, index_hash )*/
    {uintptr_t tu;
         tu = (uintptr_t)_mask_14833 & (uintptr_t)_index_hash_14839;
         _index_14836 = MAKE_UINT(tu);
    }

    /** map.e:296			index += 1*/
    _index_14836 = _index_14836 + 1;

    /** map.e:297			perturb = floor( perturb / 32 )*/
    if (32LL > 0 && _perturb_14841 >= 0) {
        _perturb_14841 = _perturb_14841 / 32LL;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_perturb_14841 / (eudouble)32LL);
        _perturb_14841 = (object)temp_dbl;
    }

    /** map.e:298		entry*/
L1: 

    /** map.e:299			slot = slots[index]*/
    DeRef(_slot_14840);
    _2 = (object)SEQ_PTR(_slots_14832);
    _slot_14840 = (object)*(((s1_ptr)_2)->base + _index_14836);
    Ref(_slot_14840);

    /** map.e:300			this_hash = slot[SLOT_HASH]*/
    _2 = (object)SEQ_PTR(_slot_14840);
    _this_hash_14842 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_this_hash_14842))
    _this_hash_14842 = (object)DBL_PTR(_this_hash_14842)->dbl;

    /** map.e:301			if this_hash = EMPTY then*/
    if (_this_hash_14842 != -2LL)
    goto L5; // [156] 169

    /** map.e:302				return index*/
    DeRef(_key_14829);
    DeRefDS(_slots_14832);
    DeRefDS(_slot_14840);
    DeRef(_this_key_14843);
    DeRef(_8479);
    _8479 = NOVALUE;
    DeRef(_8482);
    _8482 = NOVALUE;
    return _index_14836;
    goto L6; // [166] 200
L5: 

    /** map.e:303			elsif looks > length( slots ) then*/
    if (IS_SEQUENCE(_slots_14832)){
            _8495 = SEQ_PTR(_slots_14832)->length;
    }
    else {
        _8495 = 1;
    }
    if (_looks_14844 <= _8495)
    goto L7; // [174] 187

    /** map.e:304				return removed_slot*/
    DeRef(_key_14829);
    DeRefDS(_slots_14832);
    DeRef(_slot_14840);
    DeRef(_this_key_14843);
    DeRef(_8479);
    _8479 = NOVALUE;
    DeRef(_8482);
    _8482 = NOVALUE;
    return _removed_slot_14845;
    goto L6; // [184] 200
L7: 

    /** map.e:305			elsif this_hash = REMOVED then*/
    if (_this_hash_14842 != -1LL)
    goto L8; // [189] 199

    /** map.e:306				removed_slot = index*/
    _removed_slot_14845 = _index_14836;
L8: 
L6: 

    /** map.e:308			this_key = slot[SLOT_KEY]*/
    DeRef(_this_key_14843);
    _2 = (object)SEQ_PTR(_slot_14840);
    _this_key_14843 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_this_key_14843);

    /** map.e:309			looks += 1*/
    _looks_14844 = _looks_14844 + 1;

    /** map.e:310		end while*/
    goto L2; // [214] 57
L4: 

    /** map.e:311		return index*/
    DeRef(_key_14829);
    DeRefDS(_slots_14832);
    DeRef(_slot_14840);
    DeRef(_this_key_14843);
    DeRef(_8479);
    _8479 = NOVALUE;
    DeRef(_8482);
    _8482 = NOVALUE;
    return _index_14836;
    ;
}


object _34rehash_seq(object _old_map_14873, object _size_14874)
{
    object _old_size_14875 = NOVALUE;
    object _index_14877 = NOVALUE;
    object _new_map_14890 = NOVALUE;
    object _slots_14892 = NOVALUE;
    object _old_slots_14895 = NOVALUE;
    object _old_slot_14900 = NOVALUE;
    object _old_hash_14902 = NOVALUE;
    object _8516 = NOVALUE;
    object _8512 = NOVALUE;
    object _8510 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:316		integer old_size = old_map[MAP_SIZE]*/
    _2 = (object)SEQ_PTR(_old_map_14873);
    _old_size_14875 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_old_size_14875))
    _old_size_14875 = (object)DBL_PTR(_old_size_14875)->dbl;

    /** map.e:319		if size = 0 then*/

    /** map.e:320			if old_size > 50_000 then*/
    if (_old_size_14875 <= 50000LL)
    goto L1; // [19] 32

    /** map.e:321				size = old_size * 2*/
    _size_14874 = _old_size_14875 + _old_size_14875;
    goto L2; // [29] 69
L1: 

    /** map.e:323				size = old_size * 4*/
    _size_14874 = _old_size_14875 * 4LL;
    goto L2; // [41] 69

    /** map.e:325		elsif size < old_size then*/
    if (_size_14874 >= _old_size_14875)
    goto L3; // [46] 68

    /** map.e:326			size = old_size*/
    _size_14874 = _old_size_14875;

    /** map.e:327			if size < DEFAULT_SIZE then*/
    if (_size_14874 >= 8LL)
    goto L4; // [57] 67

    /** map.e:328				size = DEFAULT_SIZE*/
    _size_14874 = 8LL;
L4: 
L3: 
L2: 

    /** map.e:332		sequence new_map = new_map_seq( size )*/
    _0 = _new_map_14890;
    _new_map_14890 = _34new_map_seq(_size_14874);
    DeRef(_0);

    /** map.e:333		sequence slots = new_map[MAP_SLOTS]*/
    DeRef(_slots_14892);
    _2 = (object)SEQ_PTR(_new_map_14890);
    _slots_14892 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_slots_14892);

    /** map.e:334		new_map[MAP_SLOTS] = 0*/
    _2 = (object)SEQ_PTR(_new_map_14890);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_map_14890 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** map.e:335		new_map[MAP_SIZE] = old_map[MAP_SIZE]*/
    _2 = (object)SEQ_PTR(_old_map_14873);
    _8510 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_8510);
    _2 = (object)SEQ_PTR(_new_map_14890);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_map_14890 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _8510;
    if( _1 != _8510 ){
        DeRef(_1);
    }
    _8510 = NOVALUE;

    /** map.e:337		sequence old_slots = old_map[MAP_SLOTS]*/
    DeRef(_old_slots_14895);
    _2 = (object)SEQ_PTR(_old_map_14873);
    _old_slots_14895 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_old_slots_14895);

    /** map.e:338		for i = 1 to length( old_slots ) do*/
    if (IS_SEQUENCE(_old_slots_14895)){
            _8512 = SEQ_PTR(_old_slots_14895)->length;
    }
    else {
        _8512 = 1;
    }
    {
        object _i_14898;
        _i_14898 = 1LL;
L5: 
        if (_i_14898 > _8512){
            goto L6; // [114] 171
        }

        /** map.e:339			sequence old_slot = old_slots[i]*/
        DeRef(_old_slot_14900);
        _2 = (object)SEQ_PTR(_old_slots_14895);
        _old_slot_14900 = (object)*(((s1_ptr)_2)->base + _i_14898);
        Ref(_old_slot_14900);

        /** map.e:340			integer old_hash = old_slot[SLOT_HASH]*/
        _2 = (object)SEQ_PTR(_old_slot_14900);
        _old_hash_14902 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (!IS_ATOM_INT(_old_hash_14902))
        _old_hash_14902 = (object)DBL_PTR(_old_hash_14902)->dbl;

        /** map.e:341			if old_hash != -1 then*/
        if (_old_hash_14902 == -1LL)
        goto L7; // [137] 162

        /** map.e:342				index = lookup( old_slot[SLOT_KEY], old_hash, slots )*/
        _2 = (object)SEQ_PTR(_old_slot_14900);
        _8516 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_8516);
        RefDS(_slots_14892);
        _index_14877 = _34lookup(_8516, _old_hash_14902, _slots_14892);
        _8516 = NOVALUE;
        if (!IS_ATOM_INT(_index_14877)) {
            _1 = (object)(DBL_PTR(_index_14877)->dbl);
            DeRefDS(_index_14877);
            _index_14877 = _1;
        }

        /** map.e:343				slots[index] = old_slot*/
        RefDS(_old_slot_14900);
        _2 = (object)SEQ_PTR(_slots_14892);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_14892 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_14877);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _old_slot_14900;
        DeRef(_1);
L7: 
        DeRef(_old_slot_14900);
        _old_slot_14900 = NOVALUE;

        /** map.e:345		end for*/
        _i_14898 = _i_14898 + 1LL;
        goto L5; // [166] 121
L6: 
        ;
    }

    /** map.e:346		new_map[MAP_SLOTS] = slots*/
    RefDS(_slots_14892);
    _2 = (object)SEQ_PTR(_new_map_14890);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_map_14890 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _slots_14892;
    DeRef(_1);

    /** map.e:347		return new_map*/
    DeRefDS(_old_map_14873);
    DeRefDS(_slots_14892);
    DeRef(_old_slots_14895);
    return _new_map_14890;
    ;
}


object _34new_extra(object _the_map_p_14910, object _initial_size_p_14911)
{
    object _new_1__tmp_at22_14917 = NOVALUE;
    object _new_inlined_new_at_22_14916 = NOVALUE;
    object _8518 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:376		if map(the_map_p) then*/
    Ref(_the_map_p_14910);
    _8518 = _34map(_the_map_p_14910);
    if (_8518 == 0) {
        DeRef(_8518);
        _8518 = NOVALUE;
        goto L1; // [9] 21
    }
    else {
        if (!IS_ATOM_INT(_8518) && DBL_PTR(_8518)->dbl == 0.0){
            DeRef(_8518);
            _8518 = NOVALUE;
            goto L1; // [9] 21
        }
        DeRef(_8518);
        _8518 = NOVALUE;
    }
    DeRef(_8518);
    _8518 = NOVALUE;

    /** map.e:377			return the_map_p*/
    return _the_map_p_14910;
    goto L2; // [18] 42
L1: 

    /** map.e:379			return new(initial_size_p)*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at22_14917;
    _new_1__tmp_at22_14917 = _34new_map_seq(_initial_size_p_14911);
    DeRef(_0);
    Ref(_new_1__tmp_at22_14917);
    _0 = _new_inlined_new_at_22_14916;
    _new_inlined_new_at_22_14916 = _35malloc(_new_1__tmp_at22_14917, 1LL);
    DeRef(_0);
    DeRef(_new_1__tmp_at22_14917);
    _new_1__tmp_at22_14917 = NOVALUE;
    DeRef(_the_map_p_14910);
    return _new_inlined_new_at_22_14916;
L2: 
    ;
}


object _34has(object _the_map_p_14951, object _key_14952)
{
    object _hashval_14953 = NOVALUE;
    object _hash_inlined_hash_at_2_14955 = NOVALUE;
    object _slots_14956 = NOVALUE;
    object _index_14959 = NOVALUE;
    object _8537 = NOVALUE;
    object _8536 = NOVALUE;
    object _8535 = NOVALUE;
    object _8532 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:464		integer hashval = hash( key )*/

    /** map.e:107		return eu:hash( x, DEFAULT_HASH )*/
    _hashval_14953 = calc_hash(_key_14952, -6LL);

    /** map.e:465		sequence slots = eumem:ram_space[the_map_p][MAP_SLOTS]*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!IS_ATOM_INT(_the_map_p_14951)){
        _8532 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_14951)->dbl));
    }
    else{
        _8532 = (object)*(((s1_ptr)_2)->base + _the_map_p_14951);
    }
    DeRef(_slots_14956);
    _2 = (object)SEQ_PTR(_8532);
    _slots_14956 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_slots_14956);
    _8532 = NOVALUE;

    /** map.e:466		integer index = lookup( key, hashval, slots )*/
    Ref(_key_14952);
    RefDS(_slots_14956);
    _index_14959 = _34lookup(_key_14952, _hashval_14953, _slots_14956);
    if (!IS_ATOM_INT(_index_14959)) {
        _1 = (object)(DBL_PTR(_index_14959)->dbl);
        DeRefDS(_index_14959);
        _index_14959 = _1;
    }

    /** map.e:468		return hashval = slots[index][SLOT_HASH]*/
    _2 = (object)SEQ_PTR(_slots_14956);
    _8535 = (object)*(((s1_ptr)_2)->base + _index_14959);
    _2 = (object)SEQ_PTR(_8535);
    _8536 = (object)*(((s1_ptr)_2)->base + 1LL);
    _8535 = NOVALUE;
    if (IS_ATOM_INT(_8536)) {
        _8537 = (_hashval_14953 == _8536);
    }
    else {
        _8537 = binary_op(EQUALS, _hashval_14953, _8536);
    }
    _8536 = NOVALUE;
    DeRef(_the_map_p_14951);
    DeRef(_key_14952);
    DeRefDS(_slots_14956);
    return _8537;
    ;
}


object _34get(object _the_map_p_14966, object _key_14967, object _default_14968)
{
    object _hashval_14969 = NOVALUE;
    object _hash_inlined_hash_at_2_14971 = NOVALUE;
    object _slots_14972 = NOVALUE;
    object _index_14975 = NOVALUE;
    object _slot_14977 = NOVALUE;
    object _8544 = NOVALUE;
    object _8542 = NOVALUE;
    object _8538 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:505		integer hashval = hash( key )*/

    /** map.e:107		return eu:hash( x, DEFAULT_HASH )*/
    _hashval_14969 = calc_hash(_key_14967, -6LL);

    /** map.e:506		sequence slots = eumem:ram_space[the_map_p][MAP_SLOTS]*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!IS_ATOM_INT(_the_map_p_14966)){
        _8538 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_14966)->dbl));
    }
    else{
        _8538 = (object)*(((s1_ptr)_2)->base + _the_map_p_14966);
    }
    DeRef(_slots_14972);
    _2 = (object)SEQ_PTR(_8538);
    _slots_14972 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_slots_14972);
    _8538 = NOVALUE;

    /** map.e:507		integer index = lookup( key, hashval, slots )*/
    Ref(_key_14967);
    RefDS(_slots_14972);
    _index_14975 = _34lookup(_key_14967, _hashval_14969, _slots_14972);
    if (!IS_ATOM_INT(_index_14975)) {
        _1 = (object)(DBL_PTR(_index_14975)->dbl);
        DeRefDS(_index_14975);
        _index_14975 = _1;
    }

    /** map.e:508		sequence slot = slots[index]*/
    DeRef(_slot_14977);
    _2 = (object)SEQ_PTR(_slots_14972);
    _slot_14977 = (object)*(((s1_ptr)_2)->base + _index_14975);
    Ref(_slot_14977);

    /** map.e:509		if hashval = slot[SLOT_HASH] then*/
    _2 = (object)SEQ_PTR(_slot_14977);
    _8542 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _hashval_14969, _8542)){
        _8542 = NOVALUE;
        goto L1; // [50] 65
    }
    _8542 = NOVALUE;

    /** map.e:510			return slot[SLOT_VALUE]*/
    _2 = (object)SEQ_PTR(_slot_14977);
    _8544 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_8544);
    DeRef(_the_map_p_14966);
    DeRef(_key_14967);
    DeRef(_default_14968);
    DeRefDS(_slots_14972);
    DeRefDS(_slot_14977);
    return _8544;
L1: 

    /** map.e:512		return default*/
    DeRef(_the_map_p_14966);
    DeRef(_key_14967);
    DeRef(_slots_14972);
    DeRef(_slot_14977);
    _8544 = NOVALUE;
    return _default_14968;
    ;
}


void _34put(object _the_map_p_15005, object _key_15006, object _val_15007, object _op_15008, object _deprecated_15009)
{
    object _hashval_15010 = NOVALUE;
    object _hash_inlined_hash_at_2_15012 = NOVALUE;
    object _the_map_seq_15013 = NOVALUE;
    object _slots_15015 = NOVALUE;
    object _index_15017 = NOVALUE;
    object _old_hash_15019 = NOVALUE;
    object _msg_inlined_crash_at_288_15062 = NOVALUE;
    object _msg_inlined_crash_at_348_15072 = NOVALUE;
    object _msg_inlined_crash_at_535_15104 = NOVALUE;
    object _8611 = NOVALUE;
    object _8609 = NOVALUE;
    object _8608 = NOVALUE;
    object _8607 = NOVALUE;
    object _8606 = NOVALUE;
    object _8605 = NOVALUE;
    object _8603 = NOVALUE;
    object _8602 = NOVALUE;
    object _8601 = NOVALUE;
    object _8600 = NOVALUE;
    object _8599 = NOVALUE;
    object _8598 = NOVALUE;
    object _8596 = NOVALUE;
    object _8595 = NOVALUE;
    object _8594 = NOVALUE;
    object _8593 = NOVALUE;
    object _8591 = NOVALUE;
    object _8590 = NOVALUE;
    object _8589 = NOVALUE;
    object _8588 = NOVALUE;
    object _8585 = NOVALUE;
    object _8584 = NOVALUE;
    object _8583 = NOVALUE;
    object _8582 = NOVALUE;
    object _8581 = NOVALUE;
    object _8579 = NOVALUE;
    object _8578 = NOVALUE;
    object _8577 = NOVALUE;
    object _8576 = NOVALUE;
    object _8575 = NOVALUE;
    object _8573 = NOVALUE;
    object _8570 = NOVALUE;
    object _8569 = NOVALUE;
    object _8567 = NOVALUE;
    object _8562 = NOVALUE;
    object _8561 = NOVALUE;
    object _8558 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:579		integer hashval = hash( key )*/

    /** map.e:107		return eu:hash( x, DEFAULT_HASH )*/
    _hashval_15010 = calc_hash(_key_15006, -6LL);

    /** map.e:580		sequence the_map_seq = eumem:ram_space[the_map_p]*/
    DeRef(_the_map_seq_15013);
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!IS_ATOM_INT(_the_map_p_15005)){
        _the_map_seq_15013 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15005)->dbl));
    }
    else{
        _the_map_seq_15013 = (object)*(((s1_ptr)_2)->base + _the_map_p_15005);
    }
    Ref(_the_map_seq_15013);

    /** map.e:581		eumem:ram_space[the_map_p] = 0*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_12732 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_15005))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15005)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _the_map_p_15005);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** map.e:582		sequence slots = the_map_seq[MAP_SLOTS]*/
    DeRef(_slots_15015);
    _2 = (object)SEQ_PTR(_the_map_seq_15013);
    _slots_15015 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_slots_15015);

    /** map.e:584		integer index = lookup( key, hashval, slots )*/
    Ref(_key_15006);
    RefDS(_slots_15015);
    _index_15017 = _34lookup(_key_15006, _hashval_15010, _slots_15015);
    if (!IS_ATOM_INT(_index_15017)) {
        _1 = (object)(DBL_PTR(_index_15017)->dbl);
        DeRefDS(_index_15017);
        _index_15017 = _1;
    }

    /** map.e:585		integer old_hash = slots[index][SLOT_HASH]*/
    _2 = (object)SEQ_PTR(_slots_15015);
    _8558 = (object)*(((s1_ptr)_2)->base + _index_15017);
    _2 = (object)SEQ_PTR(_8558);
    _old_hash_15019 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_old_hash_15019)){
        _old_hash_15019 = (object)DBL_PTR(_old_hash_15019)->dbl;
    }
    _8558 = NOVALUE;

    /** map.e:587		if old_hash < 0 then*/
    if (_old_hash_15019 >= 0LL)
    goto L1; // [62] 142

    /** map.e:589			if the_map_seq[MAP_SIZE] > the_map_seq[MAP_MAX] then*/
    _2 = (object)SEQ_PTR(_the_map_seq_15013);
    _8561 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_the_map_seq_15013);
    _8562 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (binary_op_a(LESSEQ, _8561, _8562)){
        _8561 = NOVALUE;
        _8562 = NOVALUE;
        goto L2; // [76] 127
    }
    _8561 = NOVALUE;
    _8562 = NOVALUE;

    /** map.e:590				slots = {}*/
    RefDS(_5);
    DeRefDS(_slots_15015);
    _slots_15015 = _5;

    /** map.e:591				the_map_seq = rehash_seq( the_map_seq )*/
    RefDS(_the_map_seq_15013);
    _0 = _the_map_seq_15013;
    _the_map_seq_15013 = _34rehash_seq(_the_map_seq_15013, 0LL);
    DeRefDS(_0);

    /** map.e:592				slots = the_map_seq[MAP_SLOTS]*/
    DeRefDS(_slots_15015);
    _2 = (object)SEQ_PTR(_the_map_seq_15013);
    _slots_15015 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_slots_15015);

    /** map.e:593				index = lookup( key, hashval, slots )*/
    Ref(_key_15006);
    RefDS(_slots_15015);
    _index_15017 = _34lookup(_key_15006, _hashval_15010, _slots_15015);
    if (!IS_ATOM_INT(_index_15017)) {
        _1 = (object)(DBL_PTR(_index_15017)->dbl);
        DeRefDS(_index_15017);
        _index_15017 = _1;
    }

    /** map.e:594				old_hash = slots[index][SLOT_HASH]*/
    _2 = (object)SEQ_PTR(_slots_15015);
    _8567 = (object)*(((s1_ptr)_2)->base + _index_15017);
    _2 = (object)SEQ_PTR(_8567);
    _old_hash_15019 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_old_hash_15019)){
        _old_hash_15019 = (object)DBL_PTR(_old_hash_15019)->dbl;
    }
    _8567 = NOVALUE;
L2: 

    /** map.e:596			the_map_seq[MAP_SIZE] += 1*/
    _2 = (object)SEQ_PTR(_the_map_seq_15013);
    _8569 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_8569)) {
        _8570 = _8569 + 1;
        if (_8570 > MAXINT){
            _8570 = NewDouble((eudouble)_8570);
        }
    }
    else
    _8570 = binary_op(PLUS, 1, _8569);
    _8569 = NOVALUE;
    _2 = (object)SEQ_PTR(_the_map_seq_15013);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _the_map_seq_15013 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _8570;
    if( _1 != _8570 ){
        DeRef(_1);
    }
    _8570 = NOVALUE;
L1: 

    /** map.e:599		the_map_seq[MAP_SLOTS] = 0*/
    _2 = (object)SEQ_PTR(_the_map_seq_15013);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _the_map_seq_15013 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** map.e:601		switch op do*/
    _0 = _op_15008;
    switch ( _0 ){ 

        /** map.e:602			case PUT then*/
        case 1:

        /** map.e:603				slots[index] = { hashval, key, val }*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15010;
        Ref(_key_15006);
        ((intptr_t*)_2)[2] = _key_15006;
        Ref(_val_15007);
        ((intptr_t*)_2)[3] = _val_15007;
        _8573 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_slots_15015);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15015 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15017);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8573;
        if( _1 != _8573 ){
            DeRef(_1);
        }
        _8573 = NOVALUE;
        goto L3; // [171] 555

        /** map.e:604			case ADD then*/
        case 2:

        /** map.e:605				if old_hash < 0 then*/
        if (_old_hash_15019 >= 0LL)
        goto L4; // [179] 198

        /** map.e:606					slots[index] = { hashval, key, val }*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15010;
        Ref(_key_15006);
        ((intptr_t*)_2)[2] = _key_15006;
        Ref(_val_15007);
        ((intptr_t*)_2)[3] = _val_15007;
        _8575 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_slots_15015);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15015 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15017);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8575;
        if( _1 != _8575 ){
            DeRef(_1);
        }
        _8575 = NOVALUE;
        goto L3; // [195] 555
L4: 

        /** map.e:608					slots[index] = { hashval, key, val + slots[index][SLOT_VALUE] }*/
        _2 = (object)SEQ_PTR(_slots_15015);
        _8576 = (object)*(((s1_ptr)_2)->base + _index_15017);
        _2 = (object)SEQ_PTR(_8576);
        _8577 = (object)*(((s1_ptr)_2)->base + 3LL);
        _8576 = NOVALUE;
        if (IS_ATOM_INT(_val_15007) && IS_ATOM_INT(_8577)) {
            _8578 = _val_15007 + _8577;
            if ((object)((uintptr_t)_8578 + (uintptr_t)HIGH_BITS) >= 0){
                _8578 = NewDouble((eudouble)_8578);
            }
        }
        else {
            _8578 = binary_op(PLUS, _val_15007, _8577);
        }
        _8577 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15010;
        Ref(_key_15006);
        ((intptr_t*)_2)[2] = _key_15006;
        ((intptr_t*)_2)[3] = _8578;
        _8579 = MAKE_SEQ(_1);
        _8578 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15015);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15015 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15017);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8579;
        if( _1 != _8579 ){
            DeRef(_1);
        }
        _8579 = NOVALUE;
        goto L3; // [223] 555

        /** map.e:610			case SUBTRACT then*/
        case 3:

        /** map.e:611				if old_hash < 0 then*/
        if (_old_hash_15019 >= 0LL)
        goto L5; // [231] 250

        /** map.e:612					slots[index] = { hashval, key, val }*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15010;
        Ref(_key_15006);
        ((intptr_t*)_2)[2] = _key_15006;
        Ref(_val_15007);
        ((intptr_t*)_2)[3] = _val_15007;
        _8581 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_slots_15015);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15015 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15017);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8581;
        if( _1 != _8581 ){
            DeRef(_1);
        }
        _8581 = NOVALUE;
        goto L3; // [247] 555
L5: 

        /** map.e:614					slots[index] = { hashval, key, slots[index][SLOT_VALUE] - val }*/
        _2 = (object)SEQ_PTR(_slots_15015);
        _8582 = (object)*(((s1_ptr)_2)->base + _index_15017);
        _2 = (object)SEQ_PTR(_8582);
        _8583 = (object)*(((s1_ptr)_2)->base + 3LL);
        _8582 = NOVALUE;
        if (IS_ATOM_INT(_8583) && IS_ATOM_INT(_val_15007)) {
            _8584 = _8583 - _val_15007;
            if ((object)((uintptr_t)_8584 +(uintptr_t) HIGH_BITS) >= 0){
                _8584 = NewDouble((eudouble)_8584);
            }
        }
        else {
            _8584 = binary_op(MINUS, _8583, _val_15007);
        }
        _8583 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15010;
        Ref(_key_15006);
        ((intptr_t*)_2)[2] = _key_15006;
        ((intptr_t*)_2)[3] = _8584;
        _8585 = MAKE_SEQ(_1);
        _8584 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15015);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15015 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15017);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8585;
        if( _1 != _8585 ){
            DeRef(_1);
        }
        _8585 = NOVALUE;
        goto L3; // [275] 555

        /** map.e:617			case MULTIPLY then*/
        case 4:

        /** map.e:618				if old_hash < 0 then*/
        if (_old_hash_15019 >= 0LL)
        goto L6; // [283] 310

        /** map.e:619					error:crash("Inappropriate initial operation given to map.e:put()")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_288_15062);
        _msg_inlined_crash_at_288_15062 = EPrintf(-9999999, _8587, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67LL, _msg_inlined_crash_at_288_15062);

        /** error.e:53	end procedure*/
        goto L7; // [302] 305
L7: 
        DeRefi(_msg_inlined_crash_at_288_15062);
        _msg_inlined_crash_at_288_15062 = NOVALUE;
        goto L3; // [307] 555
L6: 

        /** map.e:621					slots[index] = { hashval, key, val * slots[index][SLOT_VALUE] }*/
        _2 = (object)SEQ_PTR(_slots_15015);
        _8588 = (object)*(((s1_ptr)_2)->base + _index_15017);
        _2 = (object)SEQ_PTR(_8588);
        _8589 = (object)*(((s1_ptr)_2)->base + 3LL);
        _8588 = NOVALUE;
        if (IS_ATOM_INT(_val_15007) && IS_ATOM_INT(_8589)) {
            {
                int128_t p128 = (int128_t)_val_15007 * (int128_t)_8589;
                if( p128 != (int128_t)(_8590 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                    _8590 = NewDouble( (eudouble)p128 );
                }
            }
        }
        else {
            _8590 = binary_op(MULTIPLY, _val_15007, _8589);
        }
        _8589 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15010;
        Ref(_key_15006);
        ((intptr_t*)_2)[2] = _key_15006;
        ((intptr_t*)_2)[3] = _8590;
        _8591 = MAKE_SEQ(_1);
        _8590 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15015);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15015 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15017);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8591;
        if( _1 != _8591 ){
            DeRef(_1);
        }
        _8591 = NOVALUE;
        goto L3; // [335] 555

        /** map.e:624			case DIVIDE then*/
        case 5:

        /** map.e:625				if old_hash < 0 then*/
        if (_old_hash_15019 >= 0LL)
        goto L8; // [343] 370

        /** map.e:626					error:crash("Inappropriate initial operation given to map.e:put()")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_348_15072);
        _msg_inlined_crash_at_348_15072 = EPrintf(-9999999, _8587, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67LL, _msg_inlined_crash_at_348_15072);

        /** error.e:53	end procedure*/
        goto L9; // [362] 365
L9: 
        DeRefi(_msg_inlined_crash_at_348_15072);
        _msg_inlined_crash_at_348_15072 = NOVALUE;
        goto L3; // [367] 555
L8: 

        /** map.e:628					slots[index] = { hashval, key, slots[index][SLOT_VALUE] / val }*/
        _2 = (object)SEQ_PTR(_slots_15015);
        _8593 = (object)*(((s1_ptr)_2)->base + _index_15017);
        _2 = (object)SEQ_PTR(_8593);
        _8594 = (object)*(((s1_ptr)_2)->base + 3LL);
        _8593 = NOVALUE;
        if (IS_ATOM_INT(_8594) && IS_ATOM_INT(_val_15007)) {
            _8595 = (_8594 % _val_15007) ? NewDouble((eudouble)_8594 / _val_15007) : (_8594 / _val_15007);
        }
        else {
            _8595 = binary_op(DIVIDE, _8594, _val_15007);
        }
        _8594 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15010;
        Ref(_key_15006);
        ((intptr_t*)_2)[2] = _key_15006;
        ((intptr_t*)_2)[3] = _8595;
        _8596 = MAKE_SEQ(_1);
        _8595 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15015);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15015 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15017);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8596;
        if( _1 != _8596 ){
            DeRef(_1);
        }
        _8596 = NOVALUE;
        goto L3; // [395] 555

        /** map.e:631			case APPEND then*/
        case 6:

        /** map.e:632				if old_hash < 0 then*/
        if (_old_hash_15019 >= 0LL)
        goto LA; // [403] 426

        /** map.e:633					slots[index] = { hashval, key, {val} }*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_val_15007);
        ((intptr_t*)_2)[1] = _val_15007;
        _8598 = MAKE_SEQ(_1);
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15010;
        Ref(_key_15006);
        ((intptr_t*)_2)[2] = _key_15006;
        ((intptr_t*)_2)[3] = _8598;
        _8599 = MAKE_SEQ(_1);
        _8598 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15015);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15015 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15017);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8599;
        if( _1 != _8599 ){
            DeRef(_1);
        }
        _8599 = NOVALUE;
        goto L3; // [423] 555
LA: 

        /** map.e:635					slots[index] = { hashval, key, append( slots[index][SLOT_VALUE], val ) }*/
        _2 = (object)SEQ_PTR(_slots_15015);
        _8600 = (object)*(((s1_ptr)_2)->base + _index_15017);
        _2 = (object)SEQ_PTR(_8600);
        _8601 = (object)*(((s1_ptr)_2)->base + 3LL);
        _8600 = NOVALUE;
        Ref(_val_15007);
        Append(&_8602, _8601, _val_15007);
        _8601 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15010;
        Ref(_key_15006);
        ((intptr_t*)_2)[2] = _key_15006;
        ((intptr_t*)_2)[3] = _8602;
        _8603 = MAKE_SEQ(_1);
        _8602 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15015);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15015 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15017);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8603;
        if( _1 != _8603 ){
            DeRef(_1);
        }
        _8603 = NOVALUE;
        goto L3; // [451] 555

        /** map.e:638			case CONCAT then*/
        case 7:

        /** map.e:639				if old_hash < 0 then*/
        if (_old_hash_15019 >= 0LL)
        goto LB; // [459] 478

        /** map.e:640					slots[index] = { hashval, key, val }*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15010;
        Ref(_key_15006);
        ((intptr_t*)_2)[2] = _key_15006;
        Ref(_val_15007);
        ((intptr_t*)_2)[3] = _val_15007;
        _8605 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_slots_15015);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15015 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15017);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8605;
        if( _1 != _8605 ){
            DeRef(_1);
        }
        _8605 = NOVALUE;
        goto L3; // [475] 555
LB: 

        /** map.e:642					slots[index] = { hashval, key, slots[index][SLOT_VALUE] & val }*/
        _2 = (object)SEQ_PTR(_slots_15015);
        _8606 = (object)*(((s1_ptr)_2)->base + _index_15017);
        _2 = (object)SEQ_PTR(_8606);
        _8607 = (object)*(((s1_ptr)_2)->base + 3LL);
        _8606 = NOVALUE;
        if (IS_SEQUENCE(_8607) && IS_ATOM(_val_15007)) {
            Ref(_val_15007);
            Append(&_8608, _8607, _val_15007);
        }
        else if (IS_ATOM(_8607) && IS_SEQUENCE(_val_15007)) {
            Ref(_8607);
            Prepend(&_8608, _val_15007, _8607);
        }
        else {
            Concat((object_ptr)&_8608, _8607, _val_15007);
            _8607 = NOVALUE;
        }
        _8607 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15010;
        Ref(_key_15006);
        ((intptr_t*)_2)[2] = _key_15006;
        ((intptr_t*)_2)[3] = _8608;
        _8609 = MAKE_SEQ(_1);
        _8608 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15015);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15015 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15017);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8609;
        if( _1 != _8609 ){
            DeRef(_1);
        }
        _8609 = NOVALUE;
        goto L3; // [503] 555

        /** map.e:645			case LEAVE then*/
        case 8:

        /** map.e:646				if old_hash < 0 then*/
        if (_old_hash_15019 >= 0LL)
        goto L3; // [511] 555

        /** map.e:647					slots[index] = { hashval, key, val }*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15010;
        Ref(_key_15006);
        ((intptr_t*)_2)[2] = _key_15006;
        Ref(_val_15007);
        ((intptr_t*)_2)[3] = _val_15007;
        _8611 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_slots_15015);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15015 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15017);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8611;
        if( _1 != _8611 ){
            DeRef(_1);
        }
        _8611 = NOVALUE;
        goto L3; // [528] 555

        /** map.e:649			case else*/
        default:

        /** map.e:650				error:crash("Unknown operation given to map.e:put()")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_535_15104);
        _msg_inlined_crash_at_535_15104 = EPrintf(-9999999, _8612, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67LL, _msg_inlined_crash_at_535_15104);

        /** error.e:53	end procedure*/
        goto LC; // [549] 552
LC: 
        DeRefi(_msg_inlined_crash_at_535_15104);
        _msg_inlined_crash_at_535_15104 = NOVALUE;
    ;}L3: 

    /** map.e:654		the_map_seq[MAP_SLOTS] = slots*/
    RefDS(_slots_15015);
    _2 = (object)SEQ_PTR(_the_map_seq_15013);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _the_map_seq_15013 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _slots_15015;
    DeRef(_1);

    /** map.e:655		eumem:ram_space[the_map_p] = the_map_seq*/
    RefDS(_the_map_seq_15013);
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_12732 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_15005))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15005)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _the_map_p_15005);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _the_map_seq_15013;
    DeRef(_1);

    /** map.e:656	end procedure*/
    DeRef(_the_map_p_15005);
    DeRef(_key_15006);
    DeRef(_val_15007);
    DeRefDS(_the_map_seq_15013);
    DeRefDS(_slots_15015);
    return;
    ;
}


void _34nested_put(object _the_map_p_15107, object _the_keys_p_15108, object _the_value_p_15109, object _operation_p_15110, object _deprecated_trigger_p_15111)
{
    object _temp_map__15112 = NOVALUE;
    object _8623 = NOVALUE;
    object _8622 = NOVALUE;
    object _8621 = NOVALUE;
    object _8620 = NOVALUE;
    object _8619 = NOVALUE;
    object _8617 = NOVALUE;
    object _8616 = NOVALUE;
    object _8615 = NOVALUE;
    object _8613 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:701		if length( the_keys_p ) = 1 then*/
    if (IS_SEQUENCE(_the_keys_p_15108)){
            _8613 = SEQ_PTR(_the_keys_p_15108)->length;
    }
    else {
        _8613 = 1;
    }
    if (_8613 != 1LL)
    goto L1; // [10] 30

    /** map.e:702			put( the_map_p, the_keys_p[1], the_value_p, operation_p )*/
    _2 = (object)SEQ_PTR(_the_keys_p_15108);
    _8615 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_the_map_p_15107);
    Ref(_8615);
    Ref(_the_value_p_15109);
    _34put(_the_map_p_15107, _8615, _the_value_p_15109, _operation_p_15110, 0LL);
    _8615 = NOVALUE;
    goto L2; // [27] 84
L1: 

    /** map.e:704			temp_map_ = new_extra( get( the_map_p, the_keys_p[1] ) )*/
    _2 = (object)SEQ_PTR(_the_keys_p_15108);
    _8616 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_the_map_p_15107);
    Ref(_8616);
    _8617 = _34get(_the_map_p_15107, _8616, 0LL);
    _8616 = NOVALUE;
    _0 = _temp_map__15112;
    _temp_map__15112 = _34new_extra(_8617, 8LL);
    DeRef(_0);
    _8617 = NOVALUE;

    /** map.e:705			nested_put( temp_map_, the_keys_p[2..$], the_value_p, operation_p )*/
    if (IS_SEQUENCE(_the_keys_p_15108)){
            _8619 = SEQ_PTR(_the_keys_p_15108)->length;
    }
    else {
        _8619 = 1;
    }
    rhs_slice_target = (object_ptr)&_8620;
    RHS_Slice(_the_keys_p_15108, 2LL, _8619);
    Ref(_the_value_p_15109);
    DeRef(_8621);
    _8621 = _the_value_p_15109;
    DeRef(_8622);
    _8622 = _operation_p_15110;
    Ref(_temp_map__15112);
    _34nested_put(_temp_map__15112, _8620, _8621, _8622, 0LL);
    _8620 = NOVALUE;
    _8621 = NOVALUE;
    _8622 = NOVALUE;

    /** map.e:706			put( the_map_p, the_keys_p[1], temp_map_, PUT )*/
    _2 = (object)SEQ_PTR(_the_keys_p_15108);
    _8623 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_the_map_p_15107);
    Ref(_8623);
    Ref(_temp_map__15112);
    _34put(_the_map_p_15107, _8623, _temp_map__15112, 1LL, 0LL);
    _8623 = NOVALUE;
L2: 

    /** map.e:708	end procedure*/
    DeRef(_the_map_p_15107);
    DeRefDS(_the_keys_p_15108);
    DeRef(_the_value_p_15109);
    DeRef(_temp_map__15112);
    return;
    ;
}


void _34remove(object _the_map_p_15128, object _key_15129)
{
    object _hashval_15130 = NOVALUE;
    object _hash_inlined_hash_at_2_15132 = NOVALUE;
    object _slots_15133 = NOVALUE;
    object _index_15136 = NOVALUE;
    object _8635 = NOVALUE;
    object _8634 = NOVALUE;
    object _8632 = NOVALUE;
    object _8630 = NOVALUE;
    object _8628 = NOVALUE;
    object _8627 = NOVALUE;
    object _8624 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** map.e:733		integer hashval = hash( key )*/

    /** map.e:107		return eu:hash( x, DEFAULT_HASH )*/
    _hashval_15130 = calc_hash(_key_15129, -6LL);

    /** map.e:734		sequence slots = eumem:ram_space[the_map_p][MAP_SLOTS]*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!IS_ATOM_INT(_the_map_p_15128)){
        _8624 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15128)->dbl));
    }
    else{
        _8624 = (object)*(((s1_ptr)_2)->base + _the_map_p_15128);
    }
    DeRef(_slots_15133);
    _2 = (object)SEQ_PTR(_8624);
    _slots_15133 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_slots_15133);
    _8624 = NOVALUE;

    /** map.e:736		integer index = lookup( key, hashval, slots )*/
    Ref(_key_15129);
    RefDS(_slots_15133);
    _index_15136 = _34lookup(_key_15129, _hashval_15130, _slots_15133);
    if (!IS_ATOM_INT(_index_15136)) {
        _1 = (object)(DBL_PTR(_index_15136)->dbl);
        DeRefDS(_index_15136);
        _index_15136 = _1;
    }

    /** map.e:737		if hashval = slots[index][SLOT_HASH] then*/
    _2 = (object)SEQ_PTR(_slots_15133);
    _8627 = (object)*(((s1_ptr)_2)->base + _index_15136);
    _2 = (object)SEQ_PTR(_8627);
    _8628 = (object)*(((s1_ptr)_2)->base + 1LL);
    _8627 = NOVALUE;
    if (binary_op_a(NOTEQ, _hashval_15130, _8628)){
        _8628 = NOVALUE;
        goto L1; // [46] 99
    }
    _8628 = NOVALUE;

    /** map.e:738			slots = {}*/
    RefDS(_5);
    DeRefDS(_slots_15133);
    _slots_15133 = _5;

    /** map.e:739			eumem:ram_space[the_map_p][MAP_SLOTS][index] = REMOVED_SLOT*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_12732 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_15128))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15128)->dbl));
    else
    _3 = (object)(_the_map_p_15128 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (object)(2LL + ((s1_ptr)_2)->base);
    _8630 = NOVALUE;
    RefDS(_34REMOVED_SLOT_14744);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _index_15136);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34REMOVED_SLOT_14744;
    DeRef(_1);
    _8630 = NOVALUE;

    /** map.e:740			eumem:ram_space[the_map_p][MAP_SIZE] -= 1*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_12732 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_15128))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15128)->dbl));
    else
    _3 = (object)(_the_map_p_15128 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _8634 = (object)*(((s1_ptr)_2)->base + 1LL);
    _8632 = NOVALUE;
    if (IS_ATOM_INT(_8634)) {
        _8635 = _8634 - 1LL;
        if ((object)((uintptr_t)_8635 +(uintptr_t) HIGH_BITS) >= 0){
            _8635 = NewDouble((eudouble)_8635);
        }
    }
    else {
        _8635 = binary_op(MINUS, _8634, 1LL);
    }
    _8634 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _8635;
    if( _1 != _8635 ){
        DeRef(_1);
    }
    _8635 = NOVALUE;
    _8632 = NOVALUE;
L1: 

    /** map.e:742	end procedure*/
    DeRef(_the_map_p_15128);
    DeRef(_key_15129);
    DeRef(_slots_15133);
    return;
    ;
}


void _34clear(object _the_map_p_15150)
{
    object _8642 = NOVALUE;
    object _8641 = NOVALUE;
    object _8640 = NOVALUE;
    object _8639 = NOVALUE;
    object _8638 = NOVALUE;
    object _8636 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** map.e:771		eumem:ram_space[the_map_p][MAP_SLOTS] = repeat( EMPTY_SLOT, length( eumem:ram_space[the_map_p][MAP_SLOTS] ) )*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_12732 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_15150))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15150)->dbl));
    else
    _3 = (object)(_the_map_p_15150 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!IS_ATOM_INT(_the_map_p_15150)){
        _8638 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15150)->dbl));
    }
    else{
        _8638 = (object)*(((s1_ptr)_2)->base + _the_map_p_15150);
    }
    _2 = (object)SEQ_PTR(_8638);
    _8639 = (object)*(((s1_ptr)_2)->base + 2LL);
    _8638 = NOVALUE;
    if (IS_SEQUENCE(_8639)){
            _8640 = SEQ_PTR(_8639)->length;
    }
    else {
        _8640 = 1;
    }
    _8639 = NOVALUE;
    _8641 = Repeat(_34EMPTY_SLOT_14742, _8640);
    _8640 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _8641;
    if( _1 != _8641 ){
        DeRef(_1);
    }
    _8641 = NOVALUE;
    _8636 = NOVALUE;

    /** map.e:772		eumem:ram_space[the_map_p][MAP_SIZE]  = 0*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_12732 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_15150))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15150)->dbl));
    else
    _3 = (object)(_the_map_p_15150 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _8642 = NOVALUE;

    /** map.e:773	end procedure*/
    DeRef(_the_map_p_15150);
    _8639 = NOVALUE;
    return;
    ;
}


object _34keys(object _the_map_p_15205, object _sorted_result_15206)
{
    object _slots_15207 = NOVALUE;
    object _keys_15210 = NOVALUE;
    object _kx_15214 = NOVALUE;
    object _8673 = NOVALUE;
    object _8671 = NOVALUE;
    object _8670 = NOVALUE;
    object _8669 = NOVALUE;
    object _8666 = NOVALUE;
    object _8665 = NOVALUE;
    object _8664 = NOVALUE;
    object _8662 = NOVALUE;
    object _8661 = NOVALUE;
    object _8659 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:901		sequence slots = eumem:ram_space[the_map_p][MAP_SLOTS]*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!IS_ATOM_INT(_the_map_p_15205)){
        _8659 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15205)->dbl));
    }
    else{
        _8659 = (object)*(((s1_ptr)_2)->base + _the_map_p_15205);
    }
    DeRef(_slots_15207);
    _2 = (object)SEQ_PTR(_8659);
    _slots_15207 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_slots_15207);
    _8659 = NOVALUE;

    /** map.e:902		sequence keys = repeat( 0, eumem:ram_space[the_map_p][MAP_SIZE] )*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!IS_ATOM_INT(_the_map_p_15205)){
        _8661 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15205)->dbl));
    }
    else{
        _8661 = (object)*(((s1_ptr)_2)->base + _the_map_p_15205);
    }
    _2 = (object)SEQ_PTR(_8661);
    _8662 = (object)*(((s1_ptr)_2)->base + 1LL);
    _8661 = NOVALUE;
    DeRef(_keys_15210);
    _keys_15210 = Repeat(0LL, _8662);
    _8662 = NOVALUE;

    /** map.e:903		integer kx = 0*/
    _kx_15214 = 0LL;

    /** map.e:904		for i = 1 to length( slots ) do*/
    if (IS_SEQUENCE(_slots_15207)){
            _8664 = SEQ_PTR(_slots_15207)->length;
    }
    else {
        _8664 = 1;
    }
    {
        object _i_15216;
        _i_15216 = 1LL;
L1: 
        if (_i_15216 > _8664){
            goto L2; // [43] 106
        }

        /** map.e:905			if slots[i][SLOT_HASH] >= 0 then*/
        _2 = (object)SEQ_PTR(_slots_15207);
        _8665 = (object)*(((s1_ptr)_2)->base + _i_15216);
        _2 = (object)SEQ_PTR(_8665);
        _8666 = (object)*(((s1_ptr)_2)->base + 1LL);
        _8665 = NOVALUE;
        if (binary_op_a(LESS, _8666, 0LL)){
            _8666 = NOVALUE;
            goto L3; // [60] 99
        }
        _8666 = NOVALUE;

        /** map.e:906				kx += 1*/
        _kx_15214 = _kx_15214 + 1;

        /** map.e:907				keys[kx] = slots[i][SLOT_KEY]*/
        _2 = (object)SEQ_PTR(_slots_15207);
        _8669 = (object)*(((s1_ptr)_2)->base + _i_15216);
        _2 = (object)SEQ_PTR(_8669);
        _8670 = (object)*(((s1_ptr)_2)->base + 2LL);
        _8669 = NOVALUE;
        Ref(_8670);
        _2 = (object)SEQ_PTR(_keys_15210);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _keys_15210 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _kx_15214);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8670;
        if( _1 != _8670 ){
            DeRef(_1);
        }
        _8670 = NOVALUE;

        /** map.e:908				if kx = length( keys ) then*/
        if (IS_SEQUENCE(_keys_15210)){
                _8671 = SEQ_PTR(_keys_15210)->length;
        }
        else {
            _8671 = 1;
        }
        if (_kx_15214 != _8671)
        goto L4; // [89] 98

        /** map.e:909					exit*/
        goto L2; // [95] 106
L4: 
L3: 

        /** map.e:912		end for*/
        _i_15216 = _i_15216 + 1LL;
        goto L1; // [101] 50
L2: 
        ;
    }

    /** map.e:913		if sorted_result then*/
    if (_sorted_result_15206 == 0)
    {
        goto L5; // [108] 123
    }
    else{
    }

    /** map.e:914			return stdsort:sort( keys )*/
    RefDS(_keys_15210);
    _8673 = _25sort(_keys_15210, 1LL);
    DeRef(_the_map_p_15205);
    DeRef(_slots_15207);
    DeRefDS(_keys_15210);
    return _8673;
L5: 

    /** map.e:916		return keys*/
    DeRef(_the_map_p_15205);
    DeRef(_slots_15207);
    DeRef(_8673);
    _8673 = NOVALUE;
    return _keys_15210;
    ;
}


object _34pairs(object _the_map_15281, object _sorted_result_15282)
{
    object _slots_15283 = NOVALUE;
    object _pairs_15286 = NOVALUE;
    object _px_15290 = NOVALUE;
    object _8723 = NOVALUE;
    object _8721 = NOVALUE;
    object _8720 = NOVALUE;
    object _8719 = NOVALUE;
    object _8718 = NOVALUE;
    object _8717 = NOVALUE;
    object _8716 = NOVALUE;
    object _8713 = NOVALUE;
    object _8712 = NOVALUE;
    object _8711 = NOVALUE;
    object _8709 = NOVALUE;
    object _8708 = NOVALUE;
    object _8706 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:1045		sequence slots = eumem:ram_space[the_map][MAP_SLOTS]*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!IS_ATOM_INT(_the_map_15281)){
        _8706 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_15281)->dbl));
    }
    else{
        _8706 = (object)*(((s1_ptr)_2)->base + _the_map_15281);
    }
    DeRef(_slots_15283);
    _2 = (object)SEQ_PTR(_8706);
    _slots_15283 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_slots_15283);
    _8706 = NOVALUE;

    /** map.e:1046		sequence pairs = repeat( 0, eumem:ram_space[the_map][MAP_SIZE] )*/
    _2 = (object)SEQ_PTR(_35ram_space_12732);
    if (!IS_ATOM_INT(_the_map_15281)){
        _8708 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_15281)->dbl));
    }
    else{
        _8708 = (object)*(((s1_ptr)_2)->base + _the_map_15281);
    }
    _2 = (object)SEQ_PTR(_8708);
    _8709 = (object)*(((s1_ptr)_2)->base + 1LL);
    _8708 = NOVALUE;
    DeRef(_pairs_15286);
    _pairs_15286 = Repeat(0LL, _8709);
    _8709 = NOVALUE;

    /** map.e:1047		integer px = 0*/
    _px_15290 = 0LL;

    /** map.e:1048		for i = 1 to length( slots ) do*/
    if (IS_SEQUENCE(_slots_15283)){
            _8711 = SEQ_PTR(_slots_15283)->length;
    }
    else {
        _8711 = 1;
    }
    {
        object _i_15292;
        _i_15292 = 1LL;
L1: 
        if (_i_15292 > _8711){
            goto L2; // [43] 118
        }

        /** map.e:1049			if slots[i][SLOT_HASH] >= 0 then*/
        _2 = (object)SEQ_PTR(_slots_15283);
        _8712 = (object)*(((s1_ptr)_2)->base + _i_15292);
        _2 = (object)SEQ_PTR(_8712);
        _8713 = (object)*(((s1_ptr)_2)->base + 1LL);
        _8712 = NOVALUE;
        if (binary_op_a(LESS, _8713, 0LL)){
            _8713 = NOVALUE;
            goto L3; // [60] 111
        }
        _8713 = NOVALUE;

        /** map.e:1050				px += 1*/
        _px_15290 = _px_15290 + 1;

        /** map.e:1051				pairs[px] = { slots[i][SLOT_KEY], slots[i][SLOT_VALUE] }*/
        _2 = (object)SEQ_PTR(_slots_15283);
        _8716 = (object)*(((s1_ptr)_2)->base + _i_15292);
        _2 = (object)SEQ_PTR(_8716);
        _8717 = (object)*(((s1_ptr)_2)->base + 2LL);
        _8716 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15283);
        _8718 = (object)*(((s1_ptr)_2)->base + _i_15292);
        _2 = (object)SEQ_PTR(_8718);
        _8719 = (object)*(((s1_ptr)_2)->base + 3LL);
        _8718 = NOVALUE;
        Ref(_8719);
        Ref(_8717);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _8717;
        ((intptr_t *)_2)[2] = _8719;
        _8720 = MAKE_SEQ(_1);
        _8719 = NOVALUE;
        _8717 = NOVALUE;
        _2 = (object)SEQ_PTR(_pairs_15286);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _pairs_15286 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _px_15290);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8720;
        if( _1 != _8720 ){
            DeRef(_1);
        }
        _8720 = NOVALUE;

        /** map.e:1052				if px = length( pairs ) then*/
        if (IS_SEQUENCE(_pairs_15286)){
                _8721 = SEQ_PTR(_pairs_15286)->length;
        }
        else {
            _8721 = 1;
        }
        if (_px_15290 != _8721)
        goto L4; // [101] 110

        /** map.e:1053					exit*/
        goto L2; // [107] 118
L4: 
L3: 

        /** map.e:1056		end for*/
        _i_15292 = _i_15292 + 1LL;
        goto L1; // [113] 50
L2: 
        ;
    }

    /** map.e:1057		if sorted_result then*/
    if (_sorted_result_15282 == 0)
    {
        goto L5; // [120] 135
    }
    else{
    }

    /** map.e:1058			return stdsort:sort( pairs )*/
    RefDS(_pairs_15286);
    _8723 = _25sort(_pairs_15286, 1LL);
    DeRef(_the_map_15281);
    DeRef(_slots_15283);
    DeRefDS(_pairs_15286);
    return _8723;
L5: 

    /** map.e:1060		return pairs*/
    DeRef(_the_map_15281);
    DeRef(_slots_15283);
    DeRef(_8723);
    _8723 = NOVALUE;
    return _pairs_15286;
    ;
}



// 0xF31CA606
