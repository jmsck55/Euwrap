// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _55update_checksum(object _raw_data_45485)
{
    object _23666 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:213		cfile_check = xor_bits(cfile_check, hash( raw_data, stdhash:HSIEH32))*/
    _23666 = calc_hash(_raw_data_45485, -5LL);
    _0 = _55cfile_check_45466;
    if (IS_ATOM_INT(_55cfile_check_45466) && IS_ATOM_INT(_23666)) {
        {uintptr_t tu;
             tu = (uintptr_t)_55cfile_check_45466 ^ (uintptr_t)_23666;
             _55cfile_check_45466 = MAKE_UINT(tu);
        }
    }
    else {
        if (IS_ATOM_INT(_55cfile_check_45466)) {
            temp_d.dbl = (eudouble)_55cfile_check_45466;
            _55cfile_check_45466 = Dxor_bits(&temp_d, DBL_PTR(_23666));
        }
        else {
            if (IS_ATOM_INT(_23666)) {
                temp_d.dbl = (eudouble)_23666;
                _55cfile_check_45466 = Dxor_bits(DBL_PTR(_55cfile_check_45466), &temp_d);
            }
            else
            _55cfile_check_45466 = Dxor_bits(DBL_PTR(_55cfile_check_45466), DBL_PTR(_23666));
        }
    }
    DeRef(_0);
    DeRef(_23666);
    _23666 = NOVALUE;

    /** buildsys.e:214	end procedure*/
    DeRef(_raw_data_45485);
    return;
    ;
}


void _55write_checksum(object _file_45490)
{
    object _0, _1, _2;
    

    /** buildsys.e:219		printf( file, "\n// 0x%08x\n", cfile_check )*/
    EPrintf(_file_45490, _23668, _55cfile_check_45466);

    /** buildsys.e:220		cfile_check = 0*/
    DeRef(_55cfile_check_45466);
    _55cfile_check_45466 = 0LL;

    /** buildsys.e:221	end procedure*/
    return;
    ;
}


object _55adjust_for_command_line_passing(object _long_path_45538)
{
    object _slash_45539 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:310		if compiler_type = COMPILER_GCC then*/

    /** buildsys.e:312		elsif compiler_type = COMPILER_WATCOM then*/

    /** buildsys.e:315			slash = SLASH*/
    _slash_45539 = 47LL;

    /** buildsys.e:317		ifdef UNIX then*/

    /** buildsys.e:318			return long_path*/
    return _long_path_45538;
    ;
}


object _55adjust_for_build_file(object _long_path_45549)
{
    object _short_path_45550 = NOVALUE;
    object _23699 = NOVALUE;
    object _23698 = NOVALUE;
    object _23697 = NOVALUE;
    object _23696 = NOVALUE;
    object _23695 = NOVALUE;
    object _23694 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:355	    object short_path = adjust_for_command_line_passing(long_path)*/
    RefDS(_long_path_45549);
    _0 = _short_path_45550;
    _short_path_45550 = _55adjust_for_command_line_passing(_long_path_45549);
    DeRef(_0);

    /** buildsys.e:356	    if atom(short_path) then*/
    _23694 = IS_ATOM(_short_path_45550);
    if (_23694 == 0)
    {
        _23694 = NOVALUE;
        goto L1; // [14] 24
    }
    else{
        _23694 = NOVALUE;
    }

    /** buildsys.e:357	    	return short_path*/
    DeRefDS(_long_path_45549);
    return _short_path_45550;
L1: 

    /** buildsys.e:359		if compiler_type = COMPILER_GCC and build_system_type != BUILD_DIRECT and TWINDOWS then*/
    _23695 = (0LL == 1LL);
    if (_23695 == 0) {
        _23696 = 0;
        goto L2; // [32] 46
    }
    _23697 = (3LL != 3LL);
    _23696 = (_23697 != 0);
L2: 
    if (_23696 == 0) {
        goto L3; // [46] 69
    }
    goto L3; // [53] 69

    /** buildsys.e:360			return windows_to_mingw_path(short_path)*/
    Ref(_short_path_45550);
    _23699 = _55windows_to_mingw_path(_short_path_45550);
    DeRefDS(_long_path_45549);
    DeRef(_short_path_45550);
    DeRef(_23697);
    _23697 = NOVALUE;
    DeRef(_23695);
    _23695 = NOVALUE;
    return _23699;
    goto L4; // [66] 76
L3: 

    /** buildsys.e:362			return short_path*/
    DeRefDS(_long_path_45549);
    DeRef(_23699);
    _23699 = NOVALUE;
    DeRef(_23697);
    _23697 = NOVALUE;
    DeRef(_23695);
    _23695 = NOVALUE;
    return _short_path_45550;
L4: 
    ;
}


object _55setup_build()
{
    object _c_exe_45565 = NOVALUE;
    object _c_flags_45566 = NOVALUE;
    object _l_exe_45567 = NOVALUE;
    object _l_flags_45568 = NOVALUE;
    object _obj_ext_45569 = NOVALUE;
    object _exe_ext_45570 = NOVALUE;
    object _l_flags_begin_45571 = NOVALUE;
    object _rc_comp_45572 = NOVALUE;
    object _l_names_45573 = NOVALUE;
    object _l_ext_45574 = NOVALUE;
    object _t_slash_45575 = NOVALUE;
    object _eudir_45617 = NOVALUE;
    object _locations_45642 = NOVALUE;
    object _compile_dir_45694 = NOVALUE;
    object _bits_45705 = NOVALUE;
    object _m_flag_45715 = NOVALUE;
    object _23868 = NOVALUE;
    object _23865 = NOVALUE;
    object _23864 = NOVALUE;
    object _23861 = NOVALUE;
    object _23860 = NOVALUE;
    object _23857 = NOVALUE;
    object _23856 = NOVALUE;
    object _23853 = NOVALUE;
    object _23852 = NOVALUE;
    object _23845 = NOVALUE;
    object _23844 = NOVALUE;
    object _23839 = NOVALUE;
    object _23838 = NOVALUE;
    object _23833 = NOVALUE;
    object _23832 = NOVALUE;
    object _23829 = NOVALUE;
    object _23828 = NOVALUE;
    object _23816 = NOVALUE;
    object _23815 = NOVALUE;
    object _23800 = NOVALUE;
    object _23799 = NOVALUE;
    object _23791 = NOVALUE;
    object _23789 = NOVALUE;
    object _23788 = NOVALUE;
    object _23787 = NOVALUE;
    object _23786 = NOVALUE;
    object _23782 = NOVALUE;
    object _23781 = NOVALUE;
    object _23767 = NOVALUE;
    object _23766 = NOVALUE;
    object _23763 = NOVALUE;
    object _23751 = NOVALUE;
    object _23749 = NOVALUE;
    object _23748 = NOVALUE;
    object _23747 = NOVALUE;
    object _23746 = NOVALUE;
    object _23745 = NOVALUE;
    object _23744 = NOVALUE;
    object _23743 = NOVALUE;
    object _23742 = NOVALUE;
    object _23741 = NOVALUE;
    object _23740 = NOVALUE;
    object _23735 = NOVALUE;
    object _23732 = NOVALUE;
    object _23731 = NOVALUE;
    object _23730 = NOVALUE;
    object _23727 = NOVALUE;
    object _23726 = NOVALUE;
    object _23725 = NOVALUE;
    object _23722 = NOVALUE;
    object _23718 = NOVALUE;
    object _23717 = NOVALUE;
    object _23715 = NOVALUE;
    object _23714 = NOVALUE;
    object _23713 = NOVALUE;
    object _23712 = NOVALUE;
    object _23705 = NOVALUE;
    object _23704 = NOVALUE;
    object _23703 = NOVALUE;
    object _23702 = NOVALUE;
    object _23701 = NOVALUE;
    object _23700 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:373			c_exe   = "",*/
    RefDS(_22024);
    DeRef(_c_exe_45565);
    _c_exe_45565 = _22024;

    /** buildsys.e:374			c_flags = "",*/
    RefDS(_22024);
    DeRef(_c_flags_45566);
    _c_flags_45566 = _22024;

    /** buildsys.e:375			l_exe   = "",*/
    RefDS(_22024);
    DeRef(_l_exe_45567);
    _l_exe_45567 = _22024;

    /** buildsys.e:376			l_flags = "",*/
    RefDS(_22024);
    DeRefi(_l_flags_45568);
    _l_flags_45568 = _22024;

    /** buildsys.e:377			obj_ext = "",*/
    RefDS(_22024);
    DeRefi(_obj_ext_45569);
    _obj_ext_45569 = _22024;

    /** buildsys.e:378			exe_ext = "",*/
    RefDS(_22024);
    DeRefi(_exe_ext_45570);
    _exe_ext_45570 = _22024;

    /** buildsys.e:379			l_flags_begin = "",*/
    RefDS(_22024);
    DeRefi(_l_flags_begin_45571);
    _l_flags_begin_45571 = _22024;

    /** buildsys.e:380			rc_comp = "",*/
    RefDS(_22024);
    DeRef(_rc_comp_45572);
    _rc_comp_45572 = _22024;

    /** buildsys.e:385		if dll_option*/
    if (_57dll_option_42612 == 0) {
        _23700 = 0;
        goto L1; // [61] 78
    }
    _23701 = 0;
    _23702 = (0LL > 0LL);
    _23701 = NOVALUE;
    _23700 = (_23702 != 0);
L1: 
    if (_23700 == 0) {
        goto L2; // [78] 101
    }
    _23704 = (0LL == 0);
    if (_23704 == 0)
    {
        DeRef(_23704);
        _23704 = NOVALUE;
        goto L2; // [88] 101
    }
    else{
        DeRef(_23704);
        _23704 = NOVALUE;
    }

    /** buildsys.e:388			user_library = user_pic_library*/
    RefDS(_57user_pic_library_42625);
    DeRef(_57user_library_42624);
    _57user_library_42624 = _57user_pic_library_42625;
L2: 

    /** buildsys.e:391		if length(user_library) = 0 then*/
    if (IS_SEQUENCE(_57user_library_42624)){
            _23705 = SEQ_PTR(_57user_library_42624)->length;
    }
    else {
        _23705 = 1;
    }
    if (_23705 != 0LL)
    goto L3; // [108] 456

    /** buildsys.e:392			if debug_option then*/
    if (_57debug_option_42622 == 0)
    {
        goto L4; // [116] 128
    }
    else{
    }

    /** buildsys.e:393				l_names = { "eudbg", "eu" }*/
    RefDS(_23708);
    RefDS(_23707);
    DeRef(_l_names_45573);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _23707;
    ((intptr_t *)_2)[2] = _23708;
    _l_names_45573 = MAKE_SEQ(_1);
    goto L5; // [125] 135
L4: 

    /** buildsys.e:395				l_names = { "eu", "eudbg" }*/
    RefDS(_23707);
    RefDS(_23708);
    DeRef(_l_names_45573);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _23708;
    ((intptr_t *)_2)[2] = _23707;
    _l_names_45573 = MAKE_SEQ(_1);
L5: 

    /** buildsys.e:400			if TUNIX or compiler_type = COMPILER_GCC then*/
    if (_44TUNIX_20374 != 0) {
        goto L6; // [139] 154
    }
    _23712 = (0LL == 1LL);
    if (_23712 == 0)
    {
        DeRef(_23712);
        _23712 = NOVALUE;
        goto L7; // [150] 224
    }
    else{
        DeRef(_23712);
        _23712 = NOVALUE;
    }
L6: 

    /** buildsys.e:401				l_ext = "a"*/
    RefDS(_22317);
    DeRefi(_l_ext_45574);
    _l_ext_45574 = _22317;

    /** buildsys.e:402				t_slash = "/"*/
    RefDS(_23629);
    DeRefi(_t_slash_45575);
    _t_slash_45575 = _23629;

    /** buildsys.e:403				if dll_option and not TWINDOWS then*/
    if (_57dll_option_42612 == 0) {
        goto L8; // [172] 247
    }
    _23714 = (0LL == 0);
    if (_23714 == 0)
    {
        DeRef(_23714);
        _23714 = NOVALUE;
        goto L8; // [182] 247
    }
    else{
        DeRef(_23714);
        _23714 = NOVALUE;
    }

    /** buildsys.e:404					for i = 1 to length( l_names ) do*/
    if (IS_SEQUENCE(_l_names_45573)){
            _23715 = SEQ_PTR(_l_names_45573)->length;
    }
    else {
        _23715 = 1;
    }
    {
        object _i_45608;
        _i_45608 = 1LL;
L9: 
        if (_i_45608 > _23715){
            goto LA; // [192] 220
        }

        /** buildsys.e:406						l_names[i] &= "so"*/
        _2 = (object)SEQ_PTR(_l_names_45573);
        _23717 = (object)*(((s1_ptr)_2)->base + _i_45608);
        if (IS_SEQUENCE(_23717) && IS_ATOM(_23716)) {
        }
        else if (IS_ATOM(_23717) && IS_SEQUENCE(_23716)) {
            Ref(_23717);
            Prepend(&_23718, _23716, _23717);
        }
        else {
            Concat((object_ptr)&_23718, _23717, _23716);
            _23717 = NOVALUE;
        }
        _23717 = NOVALUE;
        _2 = (object)SEQ_PTR(_l_names_45573);
        _2 = (object)(((s1_ptr)_2)->base + _i_45608);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _23718;
        if( _1 != _23718 ){
            DeRef(_1);
        }
        _23718 = NOVALUE;

        /** buildsys.e:407					end for*/
        _i_45608 = _i_45608 + 1LL;
        goto L9; // [215] 199
LA: 
        ;
    }
    goto L8; // [221] 247
L7: 

    /** buildsys.e:409			elsif TWINDOWS then*/
L8: 

    /** buildsys.e:414			object eudir = get_eucompiledir()*/
    _0 = _eudir_45617;
    _eudir_45617 = _57get_eucompiledir();
    DeRef(_0);

    /** buildsys.e:415			if not file_exists(eudir) then*/
    Ref(_eudir_45617);
    _23722 = _14file_exists(_eudir_45617);
    if (IS_ATOM_INT(_23722)) {
        if (_23722 != 0){
            DeRef(_23722);
            _23722 = NOVALUE;
            goto LB; // [258] 279
        }
    }
    else {
        if (DBL_PTR(_23722)->dbl != 0.0){
            DeRef(_23722);
            _23722 = NOVALUE;
            goto LB; // [258] 279
        }
    }
    DeRef(_23722);
    _23722 = NOVALUE;

    /** buildsys.e:416				printf(2,"Supplied directory \'%s\' is not a valid EUDIR\n",{get_eucompiledir()})*/
    _23725 = _57get_eucompiledir();
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _23725;
    _23726 = MAKE_SEQ(_1);
    _23725 = NOVALUE;
    EPrintf(2LL, _23724, _23726);
    DeRefDS(_23726);
    _23726 = NOVALUE;

    /** buildsys.e:417				abort(1)*/
    UserCleanup(1LL);
LB: 

    /** buildsys.e:419			for tk = 1 to length(l_names) label "translation kind" do*/
    if (IS_SEQUENCE(_l_names_45573)){
            _23727 = SEQ_PTR(_l_names_45573)->length;
    }
    else {
        _23727 = 1;
    }
    {
        object _tk_45629;
        _tk_45629 = 1LL;
LC: 
        if (_tk_45629 > _23727){
            goto LD; // [286] 455
        }

        /** buildsys.e:420				user_library = eudir & sprintf("%sbin%s%s.%s",{t_slash, t_slash, l_names[tk],l_ext})*/
        _2 = (object)SEQ_PTR(_l_names_45573);
        _23730 = (object)*(((s1_ptr)_2)->base + _tk_45629);
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        RefDSn(_t_slash_45575, 2);
        ((intptr_t*)_2)[1] = _t_slash_45575;
        ((intptr_t*)_2)[2] = _t_slash_45575;
        Ref(_23730);
        ((intptr_t*)_2)[3] = _23730;
        RefDS(_l_ext_45574);
        ((intptr_t*)_2)[4] = _l_ext_45574;
        _23731 = MAKE_SEQ(_1);
        _23730 = NOVALUE;
        _23732 = EPrintf(-9999999, _23729, _23731);
        DeRefDS(_23731);
        _23731 = NOVALUE;
        if (IS_SEQUENCE(_eudir_45617) && IS_ATOM(_23732)) {
        }
        else if (IS_ATOM(_eudir_45617) && IS_SEQUENCE(_23732)) {
            Ref(_eudir_45617);
            Prepend(&_57user_library_42624, _23732, _eudir_45617);
        }
        else {
            Concat((object_ptr)&_57user_library_42624, _eudir_45617, _23732);
        }
        DeRefDS(_23732);
        _23732 = NOVALUE;

        /** buildsys.e:421				if TUNIX or compiler_type = COMPILER_GCC then*/
        if (_44TUNIX_20374 != 0) {
            goto LE; // [324] 339
        }
        _23735 = (0LL == 1LL);
        if (_23735 == 0)
        {
            DeRef(_23735);
            _23735 = NOVALUE;
            goto LF; // [335] 430
        }
        else{
            DeRef(_23735);
            _23735 = NOVALUE;
        }
LE: 

        /** buildsys.e:422					ifdef UNIX then*/

        /** buildsys.e:423						sequence locations = { "/usr/local/lib/%s.a", "/usr/lib/%s.a"}*/
        RefDS(_23737);
        RefDS(_23736);
        DeRef(_locations_45642);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _23736;
        ((intptr_t *)_2)[2] = _23737;
        _locations_45642 = MAKE_SEQ(_1);

        /** buildsys.e:424						if match( "/share/euphoria", eudir ) then*/
        _23740 = e_match_from(_23739, _eudir_45617, 1LL);
        if (_23740 == 0)
        {
            _23740 = NOVALUE;
            goto L10; // [354] 429
        }
        else{
            _23740 = NOVALUE;
        }

        /** buildsys.e:426							for i = 1 to length(locations) do*/
        _23741 = 2;
        {
            object _i_45650;
            _i_45650 = 1LL;
L11: 
            if (_i_45650 > 2LL){
                goto L12; // [362] 428
            }

            /** buildsys.e:427								if file_exists( sprintf(locations[i],{l_names[tk]}) ) then*/
            _2 = (object)SEQ_PTR(_locations_45642);
            _23742 = (object)*(((s1_ptr)_2)->base + _i_45650);
            _2 = (object)SEQ_PTR(_l_names_45573);
            _23743 = (object)*(((s1_ptr)_2)->base + _tk_45629);
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_23743);
            ((intptr_t*)_2)[1] = _23743;
            _23744 = MAKE_SEQ(_1);
            _23743 = NOVALUE;
            _23745 = EPrintf(-9999999, _23742, _23744);
            _23742 = NOVALUE;
            DeRefDS(_23744);
            _23744 = NOVALUE;
            _23746 = _14file_exists(_23745);
            _23745 = NOVALUE;
            if (_23746 == 0) {
                DeRef(_23746);
                _23746 = NOVALUE;
                goto L13; // [391] 421
            }
            else {
                if (!IS_ATOM_INT(_23746) && DBL_PTR(_23746)->dbl == 0.0){
                    DeRef(_23746);
                    _23746 = NOVALUE;
                    goto L13; // [391] 421
                }
                DeRef(_23746);
                _23746 = NOVALUE;
            }
            DeRef(_23746);
            _23746 = NOVALUE;

            /** buildsys.e:428									user_library = sprintf(locations[i],{l_names[tk]})*/
            _2 = (object)SEQ_PTR(_locations_45642);
            _23747 = (object)*(((s1_ptr)_2)->base + _i_45650);
            _2 = (object)SEQ_PTR(_l_names_45573);
            _23748 = (object)*(((s1_ptr)_2)->base + _tk_45629);
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_23748);
            ((intptr_t*)_2)[1] = _23748;
            _23749 = MAKE_SEQ(_1);
            _23748 = NOVALUE;
            DeRef(_57user_library_42624);
            _57user_library_42624 = EPrintf(-9999999, _23747, _23749);
            _23747 = NOVALUE;
            DeRefDS(_23749);
            _23749 = NOVALUE;

            /** buildsys.e:429									exit "translation kind"*/
            DeRefDS(_locations_45642);
            _locations_45642 = NOVALUE;
            goto LD; // [418] 455
L13: 

            /** buildsys.e:431							end for*/
            _i_45650 = _i_45650 + 1LL;
            goto L11; // [423] 369
L12: 
            ;
        }
L10: 
LF: 
        DeRef(_locations_45642);
        _locations_45642 = NOVALUE;

        /** buildsys.e:436				if file_exists(user_library) then*/
        RefDS(_57user_library_42624);
        _23751 = _14file_exists(_57user_library_42624);
        if (_23751 == 0) {
            DeRef(_23751);
            _23751 = NOVALUE;
            goto L14; // [440] 448
        }
        else {
            if (!IS_ATOM_INT(_23751) && DBL_PTR(_23751)->dbl == 0.0){
                DeRef(_23751);
                _23751 = NOVALUE;
                goto L14; // [440] 448
            }
            DeRef(_23751);
            _23751 = NOVALUE;
        }
        DeRef(_23751);
        _23751 = NOVALUE;

        /** buildsys.e:437					exit "translation kind"*/
        goto LD; // [445] 455
L14: 

        /** buildsys.e:439			end for -- tk*/
        _tk_45629 = _tk_45629 + 1LL;
        goto LC; // [450] 293
LD: 
        ;
    }
L3: 
    DeRef(_eudir_45617);
    _eudir_45617 = NOVALUE;

    /** buildsys.e:441		user_library = adjust_for_build_file(user_library)*/
    RefDS(_57user_library_42624);
    _0 = _55adjust_for_build_file(_57user_library_42624);
    DeRefDS(_57user_library_42624);
    _57user_library_42624 = _0;

    /** buildsys.e:443		if TWINDOWS then*/

    /** buildsys.e:455		elsif TOSX then*/

    /** buildsys.e:460			if dll_option then*/
    if (_57dll_option_42612 == 0)
    {
        goto L15; // [556] 567
    }
    else{
    }

    /** buildsys.e:461				exe_ext = ".so"*/
    RefDS(_23761);
    DeRefi(_exe_ext_45570);
    _exe_ext_45570 = _23761;
L15: 

    /** buildsys.e:465		object compile_dir = get_eucompiledir()*/
    _0 = _compile_dir_45694;
    _compile_dir_45694 = _57get_eucompiledir();
    DeRef(_0);

    /** buildsys.e:466		if not file_exists(compile_dir) then*/
    Ref(_compile_dir_45694);
    _23763 = _14file_exists(_compile_dir_45694);
    if (IS_ATOM_INT(_23763)) {
        if (_23763 != 0){
            DeRef(_23763);
            _23763 = NOVALUE;
            goto L16; // [579] 600
        }
    }
    else {
        if (DBL_PTR(_23763)->dbl != 0.0){
            DeRef(_23763);
            _23763 = NOVALUE;
            goto L16; // [579] 600
        }
    }
    DeRef(_23763);
    _23763 = NOVALUE;

    /** buildsys.e:467			printf(2,"Couldn't get include directory '%s'",{get_eucompiledir()})*/
    _23766 = _57get_eucompiledir();
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _23766;
    _23767 = MAKE_SEQ(_1);
    _23766 = NOVALUE;
    EPrintf(2LL, _23765, _23767);
    DeRefDS(_23767);
    _23767 = NOVALUE;

    /** buildsys.e:468			abort(1)*/
    UserCleanup(1LL);
L16: 

    /** buildsys.e:471		integer bits = 32*/
    _bits_45705 = 32LL;

    /** buildsys.e:472		if TX86_64 then*/
    if (_44TX86_64_20386 == 0)
    {
        goto L17; // [609] 618
    }
    else{
    }

    /** buildsys.e:473			bits = 64*/
    _bits_45705 = 64LL;
L17: 

    /** buildsys.e:476		switch compiler_type do*/
    _0 = 0LL;
    switch ( _0 ){ 

        /** buildsys.e:477			case COMPILER_GCC then*/
        case 1:

        /** buildsys.e:478				c_exe = compiler_prefix & "gcc"*/
        Concat((object_ptr)&_c_exe_45565, _55compiler_prefix_45450, _23770);

        /** buildsys.e:479				l_exe = compiler_prefix & "gcc"*/
        Concat((object_ptr)&_l_exe_45567, _55compiler_prefix_45450, _23770);

        /** buildsys.e:480				obj_ext = "o"*/
        RefDS(_23773);
        DeRefi(_obj_ext_45569);
        _obj_ext_45569 = _23773;

        /** buildsys.e:482				sequence m_flag = ""*/
        RefDS(_22024);
        DeRefi(_m_flag_45715);
        _m_flag_45715 = _22024;

        /** buildsys.e:483				if not TARM then*/

        /** buildsys.e:485					m_flag = sprintf( "-m%d", bits )*/
        DeRefDSi(_m_flag_45715);
        _m_flag_45715 = EPrintf(-9999999, _23775, _bits_45705);

        /** buildsys.e:488				if debug_option then*/
        if (_57debug_option_42622 == 0)
        {
            goto L18; // [679] 691
        }
        else{
        }

        /** buildsys.e:489					c_flags &= " -g3"*/
        Concat((object_ptr)&_c_flags_45566, _c_flags_45566, _23777);
        goto L19; // [688] 698
L18: 

        /** buildsys.e:491					c_flags &= " -fomit-frame-pointer"*/
        Concat((object_ptr)&_c_flags_45566, _c_flags_45566, _23779);
L19: 

        /** buildsys.e:494				if dll_option and not TWINDOWS then*/
        if (_57dll_option_42612 == 0) {
            goto L1A; // [702] 722
        }
        _23782 = (0LL == 0);
        if (_23782 == 0)
        {
            DeRef(_23782);
            _23782 = NOVALUE;
            goto L1A; // [712] 722
        }
        else{
            DeRef(_23782);
            _23782 = NOVALUE;
        }

        /** buildsys.e:495					c_flags &= " -fPIC"*/
        Concat((object_ptr)&_c_flags_45566, _c_flags_45566, _23783);
L1A: 

        /** buildsys.e:498				c_flags &= sprintf(" -c -w -fsigned-char -O2 %s -I%s -ffast-math",*/
        _23786 = _57get_eucompiledir();
        _23787 = _55adjust_for_build_file(_23786);
        _23786 = NOVALUE;
        RefDS(_m_flag_45715);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _m_flag_45715;
        ((intptr_t *)_2)[2] = _23787;
        _23788 = MAKE_SEQ(_1);
        _23787 = NOVALUE;
        _23789 = EPrintf(-9999999, _23785, _23788);
        DeRefDS(_23788);
        _23788 = NOVALUE;
        Concat((object_ptr)&_c_flags_45566, _c_flags_45566, _23789);
        DeRefDS(_23789);
        _23789 = NOVALUE;

        /** buildsys.e:501				if TWINDOWS and mno_cygwin then*/
        if (0LL == 0) {
            goto L1B; // [747] 764
        }
        goto L1B; // [754] 764

        /** buildsys.e:504					c_flags &= " -mno-cygwin"*/
        Concat((object_ptr)&_c_flags_45566, _c_flags_45566, _23792);
L1B: 

        /** buildsys.e:507				if build_system_type != BUILD_DIRECT then*/

        /** buildsys.e:510					l_flags = sprintf( " %s %s",*/
        RefDS(_57user_library_42624);
        _23799 = _55adjust_for_command_line_passing(_57user_library_42624);
        RefDS(_m_flag_45715);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _23799;
        ((intptr_t *)_2)[2] = _m_flag_45715;
        _23800 = MAKE_SEQ(_1);
        _23799 = NOVALUE;
        DeRefi(_l_flags_45568);
        _l_flags_45568 = EPrintf(-9999999, _23798, _23800);
        DeRefDS(_23800);
        _23800 = NOVALUE;

        /** buildsys.e:514				if dll_option then*/
        if (_57dll_option_42612 == 0)
        {
            goto L1C; // [806] 816
        }
        else{
        }

        /** buildsys.e:515					l_flags &= " -shared "*/
        Concat((object_ptr)&_l_flags_45568, _l_flags_45568, _23802);
L1C: 

        /** buildsys.e:518				if TLINUX then*/
        if (_44TLINUX_20372 == 0)
        {
            goto L1D; // [820] 832
        }
        else{
        }

        /** buildsys.e:519					l_flags &= " -ldl -lm -lpthread"*/
        Concat((object_ptr)&_l_flags_45568, _l_flags_45568, _23804);
        goto L1E; // [829] 901
L1D: 

        /** buildsys.e:520				elsif TBSD then*/

        /** buildsys.e:522				elsif TOSX then*/

        /** buildsys.e:524				elsif TWINDOWS then*/
L1E: 

        /** buildsys.e:537				rc_comp = compiler_prefix & "windres -DSRCDIR=\"" & adjust_for_build_file(current_dir()) & "\" [1] -O coff -o [2]"*/
        _23815 = _14current_dir();
        _23816 = _55adjust_for_build_file(_23815);
        _23815 = NOVALUE;
        {
            object concat_list[4];

            concat_list[0] = _23817;
            concat_list[1] = _23816;
            concat_list[2] = _23814;
            concat_list[3] = _55compiler_prefix_45450;
            Concat_N((object_ptr)&_rc_comp_45572, concat_list, 4);
        }
        DeRef(_23816);
        _23816 = NOVALUE;
        DeRefi(_m_flag_45715);
        _m_flag_45715 = NOVALUE;
        goto L1F; // [921] 1127

        /** buildsys.e:539			case COMPILER_WATCOM then*/
        case 2:

        /** buildsys.e:540				c_exe = compiler_prefix & "wcc386"*/
        Concat((object_ptr)&_c_exe_45565, _55compiler_prefix_45450, _23819);

        /** buildsys.e:541				l_exe = compiler_prefix & "wlink"*/
        Concat((object_ptr)&_l_exe_45567, _55compiler_prefix_45450, _23821);

        /** buildsys.e:542				obj_ext = "obj"*/
        RefDS(_23823);
        DeRefi(_obj_ext_45569);
        _obj_ext_45569 = _23823;

        /** buildsys.e:544				if debug_option then*/
        if (_57debug_option_42622 == 0)
        {
            goto L20; // [954] 971
        }
        else{
        }

        /** buildsys.e:545					c_flags = " /d3"*/
        RefDS(_23824);
        DeRef(_c_flags_45566);
        _c_flags_45566 = _23824;

        /** buildsys.e:546					l_flags_begin &= " DEBUG ALL "*/
        Concat((object_ptr)&_l_flags_begin_45571, _l_flags_begin_45571, _23825);
L20: 

        /** buildsys.e:549				l_flags &= sprintf(" OPTION STACK=%d ", { total_stack_size })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _57total_stack_size_42627;
        _23828 = MAKE_SEQ(_1);
        _23829 = EPrintf(-9999999, _23827, _23828);
        DeRefDS(_23828);
        _23828 = NOVALUE;
        Concat((object_ptr)&_l_flags_45568, _l_flags_45568, _23829);
        DeRefDS(_23829);
        _23829 = NOVALUE;

        /** buildsys.e:550				l_flags &= sprintf(" COMMIT STACK=%d ", { total_stack_size })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _57total_stack_size_42627;
        _23832 = MAKE_SEQ(_1);
        _23833 = EPrintf(-9999999, _23831, _23832);
        DeRefDS(_23832);
        _23832 = NOVALUE;
        Concat((object_ptr)&_l_flags_45568, _l_flags_45568, _23833);
        DeRefDS(_23833);
        _23833 = NOVALUE;

        /** buildsys.e:551				l_flags &= " OPTION QUIET OPTION ELIMINATE OPTION CASEEXACT"*/
        Concat((object_ptr)&_l_flags_45568, _l_flags_45568, _23835);

        /** buildsys.e:553				if dll_option then*/
        if (_57dll_option_42612 == 0)
        {
            goto L21; // [1013] 1039
        }
        else{
        }

        /** buildsys.e:554					c_flags &= " /bd /bt=nt /mf /w0 /zq /j /zp4 /fp5 /fpi87 /5r /otimra /s /I" & adjust_for_build_file(compile_dir) */
        Ref(_compile_dir_45694);
        _23838 = _55adjust_for_build_file(_compile_dir_45694);
        if (IS_SEQUENCE(_23837) && IS_ATOM(_23838)) {
            Ref(_23838);
            Append(&_23839, _23837, _23838);
        }
        else if (IS_ATOM(_23837) && IS_SEQUENCE(_23838)) {
        }
        else {
            Concat((object_ptr)&_23839, _23837, _23838);
        }
        DeRef(_23838);
        _23838 = NOVALUE;
        Concat((object_ptr)&_c_flags_45566, _c_flags_45566, _23839);
        DeRefDS(_23839);
        _23839 = NOVALUE;

        /** buildsys.e:555					l_flags &= " SYSTEM NT_DLL initinstance terminstance"*/
        Concat((object_ptr)&_l_flags_45568, _l_flags_45568, _23841);
        goto L22; // [1036] 1077
L21: 

        /** buildsys.e:557					c_flags &= " /bt=nt /mf /w0 /zq /j /zp4 /fp5 /fpi87 /5r /otimra /s /I" & adjust_for_build_file(compile_dir)*/
        Ref(_compile_dir_45694);
        _23844 = _55adjust_for_build_file(_compile_dir_45694);
        if (IS_SEQUENCE(_23843) && IS_ATOM(_23844)) {
            Ref(_23844);
            Append(&_23845, _23843, _23844);
        }
        else if (IS_ATOM(_23843) && IS_SEQUENCE(_23844)) {
        }
        else {
            Concat((object_ptr)&_23845, _23843, _23844);
        }
        DeRef(_23844);
        _23844 = NOVALUE;
        Concat((object_ptr)&_c_flags_45566, _c_flags_45566, _23845);
        DeRefDS(_23845);
        _23845 = NOVALUE;

        /** buildsys.e:558					if con_option then*/
        if (_57con_option_42614 == 0)
        {
            goto L23; // [1057] 1069
        }
        else{
        }

        /** buildsys.e:560						l_flags = " SYSTEM NT" & l_flags*/
        Concat((object_ptr)&_l_flags_45568, _23847, _l_flags_45568);
        goto L24; // [1066] 1076
L23: 

        /** buildsys.e:562						l_flags = " SYSTEM NT_WIN RUNTIME WINDOWS=4.0" & l_flags*/
        Concat((object_ptr)&_l_flags_45568, _23849, _l_flags_45568);
L24: 
L22: 

        /** buildsys.e:566				l_flags &= sprintf(" FILE %s", { (user_library) })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_57user_library_42624);
        ((intptr_t*)_2)[1] = _57user_library_42624;
        _23852 = MAKE_SEQ(_1);
        _23853 = EPrintf(-9999999, _23851, _23852);
        DeRefDS(_23852);
        _23852 = NOVALUE;
        Concat((object_ptr)&_l_flags_45568, _l_flags_45568, _23853);
        DeRefDS(_23853);
        _23853 = NOVALUE;

        /** buildsys.e:570				rc_comp = compiler_prefix &"wrc -DSRCDIR=\"" & adjust_for_build_file(current_dir()) & "\" -q -fo=[2] -ad [1] [3]"*/
        _23856 = _14current_dir();
        _23857 = _55adjust_for_build_file(_23856);
        _23856 = NOVALUE;
        {
            object concat_list[4];

            concat_list[0] = _23858;
            concat_list[1] = _23857;
            concat_list[2] = _23855;
            concat_list[3] = _55compiler_prefix_45450;
            Concat_N((object_ptr)&_rc_comp_45572, concat_list, 4);
        }
        DeRef(_23857);
        _23857 = NOVALUE;
        goto L1F; // [1111] 1127

        /** buildsys.e:571			case else*/
        default:

        /** buildsys.e:572				CompileErr(COMPILER_IS_UNKNOWN)*/
        RefDS(_22024);
        _49CompileErr(43LL, _22024, 0LL);
    ;}L1F: 

    /** buildsys.e:575		if length(cflags) then*/
    _23860 = 0;

    /** buildsys.e:580		if length(extra_cflags) then*/
    _23861 = 0;

    /** buildsys.e:584		if length(lflags) then*/
    _23864 = 0;

    /** buildsys.e:589		if length(extra_lflags) then*/
    _23865 = 0;

    /** buildsys.e:593		return { */
    _1 = NewS1(9);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_c_exe_45565);
    ((intptr_t*)_2)[1] = _c_exe_45565;
    RefDS(_c_flags_45566);
    ((intptr_t*)_2)[2] = _c_flags_45566;
    RefDS(_l_exe_45567);
    ((intptr_t*)_2)[3] = _l_exe_45567;
    RefDS(_l_flags_45568);
    ((intptr_t*)_2)[4] = _l_flags_45568;
    RefDS(_obj_ext_45569);
    ((intptr_t*)_2)[5] = _obj_ext_45569;
    RefDS(_exe_ext_45570);
    ((intptr_t*)_2)[6] = _exe_ext_45570;
    RefDS(_l_flags_begin_45571);
    ((intptr_t*)_2)[7] = _l_flags_begin_45571;
    RefDS(_rc_comp_45572);
    ((intptr_t*)_2)[8] = _rc_comp_45572;
    RefDS(_57user_library_42624);
    ((intptr_t*)_2)[9] = _57user_library_42624;
    _23868 = MAKE_SEQ(_1);
    DeRefDS(_c_exe_45565);
    DeRefDS(_c_flags_45566);
    DeRefDS(_l_exe_45567);
    DeRefDSi(_l_flags_45568);
    DeRefDSi(_obj_ext_45569);
    DeRefDSi(_exe_ext_45570);
    DeRefDSi(_l_flags_begin_45571);
    DeRefDS(_rc_comp_45572);
    DeRef(_l_names_45573);
    DeRefi(_l_ext_45574);
    DeRefi(_t_slash_45575);
    DeRef(_compile_dir_45694);
    DeRef(_23702);
    _23702 = NOVALUE;
    return _23868;
    ;
}


void _55ensure_exename(object _ext_45862)
{
    object _23875 = NOVALUE;
    object _23874 = NOVALUE;
    object _23873 = NOVALUE;
    object _23872 = NOVALUE;
    object _23870 = NOVALUE;
    object _23869 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:602		if length(exe_name[D_ALTNAME]) = 0 then*/
    _2 = (object)SEQ_PTR(_55exe_name_45452);
    _23869 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (IS_SEQUENCE(_23869)){
            _23870 = SEQ_PTR(_23869)->length;
    }
    else {
        _23870 = 1;
    }
    _23869 = NOVALUE;
    if (_23870 != 0LL)
    goto L1; // [16] 67

    /** buildsys.e:603			exe_name[D_NAME] = current_dir() & SLASH & file0 & ext*/
    _23872 = _14current_dir();
    {
        object concat_list[4];

        concat_list[0] = _ext_45862;
        concat_list[1] = _57file0_44585;
        concat_list[2] = 47LL;
        concat_list[3] = _23872;
        Concat_N((object_ptr)&_23873, concat_list, 4);
    }
    DeRef(_23872);
    _23872 = NOVALUE;
    _2 = (object)SEQ_PTR(_55exe_name_45452);
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23873;
    if( _1 != _23873 ){
        DeRef(_1);
    }
    _23873 = NOVALUE;

    /** buildsys.e:604			exe_name[D_ALTNAME] = adjust_for_command_line_passing(exe_name[D_NAME])*/
    _2 = (object)SEQ_PTR(_55exe_name_45452);
    _23874 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_23874);
    _23875 = _55adjust_for_command_line_passing(_23874);
    _23874 = NOVALUE;
    _2 = (object)SEQ_PTR(_55exe_name_45452);
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23875;
    if( _1 != _23875 ){
        DeRef(_1);
    }
    _23875 = NOVALUE;
L1: 

    /** buildsys.e:606	end procedure*/
    DeRefDS(_ext_45862);
    _23869 = NOVALUE;
    return;
    ;
}


void _55write_objlink_file()
{
    object _settings_45880 = NOVALUE;
    object _fh_45882 = NOVALUE;
    object _s_45930 = NOVALUE;
    object _23924 = NOVALUE;
    object _23922 = NOVALUE;
    object _23921 = NOVALUE;
    object _23920 = NOVALUE;
    object _23919 = NOVALUE;
    object _23918 = NOVALUE;
    object _23917 = NOVALUE;
    object _23916 = NOVALUE;
    object _23915 = NOVALUE;
    object _23914 = NOVALUE;
    object _23913 = NOVALUE;
    object _23912 = NOVALUE;
    object _23911 = NOVALUE;
    object _23909 = NOVALUE;
    object _23908 = NOVALUE;
    object _23907 = NOVALUE;
    object _23906 = NOVALUE;
    object _23904 = NOVALUE;
    object _23903 = NOVALUE;
    object _23902 = NOVALUE;
    object _23901 = NOVALUE;
    object _23900 = NOVALUE;
    object _23899 = NOVALUE;
    object _23893 = NOVALUE;
    object _23892 = NOVALUE;
    object _23889 = NOVALUE;
    object _23888 = NOVALUE;
    object _23887 = NOVALUE;
    object _23886 = NOVALUE;
    object _23885 = NOVALUE;
    object _23883 = NOVALUE;
    object _23882 = NOVALUE;
    object _23881 = NOVALUE;
    object _23878 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:612		sequence settings = setup_build()*/
    _0 = _settings_45880;
    _settings_45880 = _55setup_build();
    DeRef(_0);

    /** buildsys.e:613		integer fh = open(output_dir & file0 & ".lnk", "wb")*/
    {
        object concat_list[3];

        concat_list[0] = _23877;
        concat_list[1] = _57file0_44585;
        concat_list[2] = _57output_dir_42626;
        Concat_N((object_ptr)&_23878, concat_list, 3);
    }
    _fh_45882 = EOpen(_23878, _23879, 0LL);
    DeRefDS(_23878);
    _23878 = NOVALUE;

    /** buildsys.e:615		ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (object)SEQ_PTR(_settings_45880);
    _23881 = (object)*(((s1_ptr)_2)->base + 6LL);
    Ref(_23881);
    _55ensure_exename(_23881);
    _23881 = NOVALUE;

    /** buildsys.e:617		if length(settings[SETUP_LFLAGS_BEGIN]) > 0 then*/
    _2 = (object)SEQ_PTR(_settings_45880);
    _23882 = (object)*(((s1_ptr)_2)->base + 7LL);
    if (IS_SEQUENCE(_23882)){
            _23883 = SEQ_PTR(_23882)->length;
    }
    else {
        _23883 = 1;
    }
    _23882 = NOVALUE;
    if (_23883 <= 0LL)
    goto L1; // [43] 63

    /** buildsys.e:618			puts(fh, settings[SETUP_LFLAGS_BEGIN] & HOSTNL)*/
    _2 = (object)SEQ_PTR(_settings_45880);
    _23885 = (object)*(((s1_ptr)_2)->base + 7LL);
    if (IS_SEQUENCE(_23885) && IS_ATOM(_44HOSTNL_20392)) {
    }
    else if (IS_ATOM(_23885) && IS_SEQUENCE(_44HOSTNL_20392)) {
        Ref(_23885);
        Prepend(&_23886, _44HOSTNL_20392, _23885);
    }
    else {
        Concat((object_ptr)&_23886, _23885, _44HOSTNL_20392);
        _23885 = NOVALUE;
    }
    _23885 = NOVALUE;
    EPuts(_fh_45882, _23886); // DJP 
    DeRefDS(_23886);
    _23886 = NOVALUE;
L1: 

    /** buildsys.e:621		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_42616)){
            _23887 = SEQ_PTR(_57generated_files_42616)->length;
    }
    else {
        _23887 = 1;
    }
    {
        object _i_45898;
        _i_45898 = 1LL;
L2: 
        if (_i_45898 > _23887){
            goto L3; // [70] 132
        }

        /** buildsys.e:622			if match(".o", generated_files[i]) then*/
        _2 = (object)SEQ_PTR(_57generated_files_42616);
        _23888 = (object)*(((s1_ptr)_2)->base + _i_45898);
        _23889 = e_match_from(_23193, _23888, 1LL);
        _23888 = NOVALUE;
        if (_23889 == 0)
        {
            _23889 = NOVALUE;
            goto L4; // [90] 125
        }
        else{
            _23889 = NOVALUE;
        }

        /** buildsys.e:623				if compiler_type = COMPILER_WATCOM then*/

        /** buildsys.e:627				puts(fh, generated_files[i] & HOSTNL)*/
        _2 = (object)SEQ_PTR(_57generated_files_42616);
        _23892 = (object)*(((s1_ptr)_2)->base + _i_45898);
        Concat((object_ptr)&_23893, _23892, _44HOSTNL_20392);
        _23892 = NOVALUE;
        _23892 = NOVALUE;
        EPuts(_fh_45882, _23893); // DJP 
        DeRefDS(_23893);
        _23893 = NOVALUE;
L4: 

        /** buildsys.e:629		end for*/
        _i_45898 = _i_45898 + 1LL;
        goto L2; // [127] 77
L3: 
        ;
    }

    /** buildsys.e:631		if compiler_type = COMPILER_WATCOM then*/

    /** buildsys.e:635		puts(fh, trim(settings[SETUP_LFLAGS] & HOSTNL))*/
    _2 = (object)SEQ_PTR(_settings_45880);
    _23899 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_SEQUENCE(_23899) && IS_ATOM(_44HOSTNL_20392)) {
    }
    else if (IS_ATOM(_23899) && IS_SEQUENCE(_44HOSTNL_20392)) {
        Ref(_23899);
        Prepend(&_23900, _44HOSTNL_20392, _23899);
    }
    else {
        Concat((object_ptr)&_23900, _23899, _44HOSTNL_20392);
        _23899 = NOVALUE;
    }
    _23899 = NOVALUE;
    RefDS(_3010);
    _23901 = _18trim(_23900, _3010, 0LL);
    _23900 = NOVALUE;
    EPuts(_fh_45882, _23901); // DJP 
    DeRef(_23901);
    _23901 = NOVALUE;

    /** buildsys.e:637		if compiler_type = COMPILER_WATCOM and dll_option then*/
    _23902 = (0LL == 2LL);
    if (_23902 == 0) {
        goto L5; // [194] 361
    }
    if (_57dll_option_42612 == 0)
    {
        goto L5; // [201] 361
    }
    else{
    }

    /** buildsys.e:638			puts(fh, HOSTNL)*/
    EPuts(_fh_45882, _44HOSTNL_20392); // DJP 

    /** buildsys.e:640			object s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    _23904 = (object)*(((s1_ptr)_2)->base + _12TopLevelSub_20233);
    DeRef(_s_45930);
    _2 = (object)SEQ_PTR(_23904);
    _s_45930 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_s_45930);
    _23904 = NOVALUE;

    /** buildsys.e:641			while s do*/
L6: 
    if (_s_45930 <= 0) {
        if (_s_45930 == 0) {
            goto L7; // [232] 360
        }
        else {
            if (!IS_ATOM_INT(_s_45930) && DBL_PTR(_s_45930)->dbl == 0.0){
                goto L7; // [232] 360
            }
        }
    }

    /** buildsys.e:642				if eu:find(SymTab[s][S_TOKEN], RTN_TOKS) then*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_s_45930)){
        _23906 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_45930)->dbl));
    }
    else{
        _23906 = (object)*(((s1_ptr)_2)->base + _s_45930);
    }
    _2 = (object)SEQ_PTR(_23906);
    if (!IS_ATOM_INT(_12S_TOKEN_19869)){
        _23907 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_TOKEN_19869)->dbl));
    }
    else{
        _23907 = (object)*(((s1_ptr)_2)->base + _12S_TOKEN_19869);
    }
    _23906 = NOVALUE;
    _23908 = find_from(_23907, _29RTN_TOKS_12006, 1LL);
    _23907 = NOVALUE;
    if (_23908 == 0)
    {
        _23908 = NOVALUE;
        goto L8; // [256] 341
    }
    else{
        _23908 = NOVALUE;
    }

    /** buildsys.e:643					if is_exported( s ) then*/
    Ref(_s_45930);
    _23909 = _57is_exported(_s_45930);
    if (_23909 == 0) {
        DeRef(_23909);
        _23909 = NOVALUE;
        goto L9; // [265] 340
    }
    else {
        if (!IS_ATOM_INT(_23909) && DBL_PTR(_23909)->dbl == 0.0){
            DeRef(_23909);
            _23909 = NOVALUE;
            goto L9; // [265] 340
        }
        DeRef(_23909);
        _23909 = NOVALUE;
    }
    DeRef(_23909);
    _23909 = NOVALUE;

    /** buildsys.e:644						printf(fh, "EXPORT %s='__%d%s@%d'" & HOSTNL,*/
    Concat((object_ptr)&_23911, _23910, _44HOSTNL_20392);
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_s_45930)){
        _23912 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_45930)->dbl));
    }
    else{
        _23912 = (object)*(((s1_ptr)_2)->base + _s_45930);
    }
    _2 = (object)SEQ_PTR(_23912);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _23913 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _23913 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _23912 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_s_45930)){
        _23914 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_45930)->dbl));
    }
    else{
        _23914 = (object)*(((s1_ptr)_2)->base + _s_45930);
    }
    _2 = (object)SEQ_PTR(_23914);
    if (!IS_ATOM_INT(_12S_FILE_NO_19860)){
        _23915 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_FILE_NO_19860)->dbl));
    }
    else{
        _23915 = (object)*(((s1_ptr)_2)->base + _12S_FILE_NO_19860);
    }
    _23914 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_s_45930)){
        _23916 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_45930)->dbl));
    }
    else{
        _23916 = (object)*(((s1_ptr)_2)->base + _s_45930);
    }
    _2 = (object)SEQ_PTR(_23916);
    if (!IS_ATOM_INT(_12S_NAME_19864)){
        _23917 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NAME_19864)->dbl));
    }
    else{
        _23917 = (object)*(((s1_ptr)_2)->base + _12S_NAME_19864);
    }
    _23916 = NOVALUE;
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_s_45930)){
        _23918 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_45930)->dbl));
    }
    else{
        _23918 = (object)*(((s1_ptr)_2)->base + _s_45930);
    }
    _2 = (object)SEQ_PTR(_23918);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_19915)){
        _23919 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12S_NUM_ARGS_19915)->dbl));
    }
    else{
        _23919 = (object)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_19915);
    }
    _23918 = NOVALUE;
    if (IS_ATOM_INT(_23919)) {
        {
            int128_t p128 = (int128_t)_23919 * (int128_t)4LL;
            if( p128 != (int128_t)(_23920 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _23920 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _23920 = binary_op(MULTIPLY, _23919, 4LL);
    }
    _23919 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23913);
    ((intptr_t*)_2)[1] = _23913;
    Ref(_23915);
    ((intptr_t*)_2)[2] = _23915;
    Ref(_23917);
    ((intptr_t*)_2)[3] = _23917;
    ((intptr_t*)_2)[4] = _23920;
    _23921 = MAKE_SEQ(_1);
    _23920 = NOVALUE;
    _23917 = NOVALUE;
    _23915 = NOVALUE;
    _23913 = NOVALUE;
    EPrintf(_fh_45882, _23911, _23921);
    DeRefDS(_23911);
    _23911 = NOVALUE;
    DeRefDS(_23921);
    _23921 = NOVALUE;
L9: 
L8: 

    /** buildsys.e:649				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_13SymTab_11316);
    if (!IS_ATOM_INT(_s_45930)){
        _23922 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_45930)->dbl));
    }
    else{
        _23922 = (object)*(((s1_ptr)_2)->base + _s_45930);
    }
    DeRef(_s_45930);
    _2 = (object)SEQ_PTR(_23922);
    _s_45930 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_s_45930);
    _23922 = NOVALUE;

    /** buildsys.e:650			end while*/
    goto L6; // [357] 232
L7: 
L5: 
    DeRef(_s_45930);
    _s_45930 = NOVALUE;

    /** buildsys.e:653		close(fh)*/
    EClose(_fh_45882);

    /** buildsys.e:655		generated_files = append(generated_files, file0 & ".lnk")*/
    Concat((object_ptr)&_23924, _57file0_44585, _23877);
    RefDS(_23924);
    Append(&_57generated_files_42616, _57generated_files_42616, _23924);
    DeRefDS(_23924);
    _23924 = NOVALUE;

    /** buildsys.e:656	end procedure*/
    DeRef(_settings_45880);
    DeRef(_23902);
    _23902 = NOVALUE;
    _23882 = NOVALUE;
    return;
    ;
}


void _55write_makefile_srcobj_list(object _fh_45979)
{
    object _file_count_46010 = NOVALUE;
    object _23957 = NOVALUE;
    object _23956 = NOVALUE;
    object _23955 = NOVALUE;
    object _23953 = NOVALUE;
    object _23952 = NOVALUE;
    object _23951 = NOVALUE;
    object _23949 = NOVALUE;
    object _23948 = NOVALUE;
    object _23946 = NOVALUE;
    object _23945 = NOVALUE;
    object _23944 = NOVALUE;
    object _23943 = NOVALUE;
    object _23942 = NOVALUE;
    object _23941 = NOVALUE;
    object _23939 = NOVALUE;
    object _23938 = NOVALUE;
    object _23937 = NOVALUE;
    object _23932 = NOVALUE;
    object _23931 = NOVALUE;
    object _23930 = NOVALUE;
    object _23929 = NOVALUE;
    object _23928 = NOVALUE;
    object _23927 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:660		printf(fh, "%s_SOURCES =", { upper(file0) })*/
    RefDS(_57file0_44585);
    _23927 = _18upper(_57file0_44585);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _23927;
    _23928 = MAKE_SEQ(_1);
    _23927 = NOVALUE;
    EPrintf(_fh_45979, _23926, _23928);
    DeRefDS(_23928);
    _23928 = NOVALUE;

    /** buildsys.e:661		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_42616)){
            _23929 = SEQ_PTR(_57generated_files_42616)->length;
    }
    else {
        _23929 = 1;
    }
    {
        object _i_45986;
        _i_45986 = 1LL;
L1: 
        if (_i_45986 > _23929){
            goto L2; // [26] 94
        }

        /** buildsys.e:662			if generated_files[i][$] = 'c' then*/
        _2 = (object)SEQ_PTR(_57generated_files_42616);
        _23930 = (object)*(((s1_ptr)_2)->base + _i_45986);
        if (IS_SEQUENCE(_23930)){
                _23931 = SEQ_PTR(_23930)->length;
        }
        else {
            _23931 = 1;
        }
        _2 = (object)SEQ_PTR(_23930);
        _23932 = (object)*(((s1_ptr)_2)->base + _23931);
        _23930 = NOVALUE;
        if (binary_op_a(NOTEQ, _23932, 99LL)){
            _23932 = NOVALUE;
            goto L3; // [48] 87
        }
        _23932 = NOVALUE;

        /** buildsys.e:663				if i > 1 then*/
        if (_i_45986 <= 1LL)
        goto L4; // [54] 71

        /** buildsys.e:664					printf(fh, " \\%s\t", { HOSTNL }  )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_44HOSTNL_20392);
        ((intptr_t*)_2)[1] = _44HOSTNL_20392;
        _23937 = MAKE_SEQ(_1);
        EPrintf(_fh_45979, _23936, _23937);
        DeRefDS(_23937);
        _23937 = NOVALUE;
L4: 

        /** buildsys.e:666				puts(fh, " " & generated_files[i])*/
        _2 = (object)SEQ_PTR(_57generated_files_42616);
        _23938 = (object)*(((s1_ptr)_2)->base + _i_45986);
        Concat((object_ptr)&_23939, _23438, _23938);
        _23938 = NOVALUE;
        EPuts(_fh_45979, _23939); // DJP 
        DeRefDS(_23939);
        _23939 = NOVALUE;
L3: 

        /** buildsys.e:668		end for*/
        _i_45986 = _i_45986 + 1LL;
        goto L1; // [89] 33
L2: 
        ;
    }

    /** buildsys.e:669		puts(fh, HOSTNL)*/
    EPuts(_fh_45979, _44HOSTNL_20392); // DJP 

    /** buildsys.e:671		printf(fh, "%s_OBJECTS =", { upper(file0) })*/
    RefDS(_57file0_44585);
    _23941 = _18upper(_57file0_44585);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _23941;
    _23942 = MAKE_SEQ(_1);
    _23941 = NOVALUE;
    EPrintf(_fh_45979, _23940, _23942);
    DeRefDS(_23942);
    _23942 = NOVALUE;

    /** buildsys.e:672		integer file_count = 0*/
    _file_count_46010 = 0LL;

    /** buildsys.e:673		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_42616)){
            _23943 = SEQ_PTR(_57generated_files_42616)->length;
    }
    else {
        _23943 = 1;
    }
    {
        object _i_46012;
        _i_46012 = 1LL;
L5: 
        if (_i_46012 > _23943){
            goto L6; // [129] 199
        }

        /** buildsys.e:674			if match(".o", generated_files[i]) then*/
        _2 = (object)SEQ_PTR(_57generated_files_42616);
        _23944 = (object)*(((s1_ptr)_2)->base + _i_46012);
        _23945 = e_match_from(_23193, _23944, 1LL);
        _23944 = NOVALUE;
        if (_23945 == 0)
        {
            _23945 = NOVALUE;
            goto L7; // [149] 192
        }
        else{
            _23945 = NOVALUE;
        }

        /** buildsys.e:675				if file_count then*/
        if (_file_count_46010 == 0)
        {
            goto L8; // [154] 170
        }
        else{
        }

        /** buildsys.e:676					printf(fh, " \\%s\t", { HOSTNL }  )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_44HOSTNL_20392);
        ((intptr_t*)_2)[1] = _44HOSTNL_20392;
        _23946 = MAKE_SEQ(_1);
        EPrintf(_fh_45979, _23936, _23946);
        DeRefDS(_23946);
        _23946 = NOVALUE;
L8: 

        /** buildsys.e:678				file_count += 1*/
        _file_count_46010 = _file_count_46010 + 1;

        /** buildsys.e:679				puts(fh, " " & generated_files[i])*/
        _2 = (object)SEQ_PTR(_57generated_files_42616);
        _23948 = (object)*(((s1_ptr)_2)->base + _i_46012);
        Concat((object_ptr)&_23949, _23438, _23948);
        _23948 = NOVALUE;
        EPuts(_fh_45979, _23949); // DJP 
        DeRefDS(_23949);
        _23949 = NOVALUE;
L7: 

        /** buildsys.e:681		end for*/
        _i_46012 = _i_46012 + 1LL;
        goto L5; // [194] 136
L6: 
        ;
    }

    /** buildsys.e:682		puts(fh, HOSTNL)*/
    EPuts(_fh_45979, _44HOSTNL_20392); // DJP 

    /** buildsys.e:684		printf(fh, "%s_GENERATED_FILES = ", { upper(file0) })*/
    RefDS(_57file0_44585);
    _23951 = _18upper(_57file0_44585);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _23951;
    _23952 = MAKE_SEQ(_1);
    _23951 = NOVALUE;
    EPrintf(_fh_45979, _23950, _23952);
    DeRefDS(_23952);
    _23952 = NOVALUE;

    /** buildsys.e:685		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_42616)){
            _23953 = SEQ_PTR(_57generated_files_42616)->length;
    }
    else {
        _23953 = 1;
    }
    {
        object _i_46033;
        _i_46033 = 1LL;
L9: 
        if (_i_46033 > _23953){
            goto LA; // [229] 277
        }

        /** buildsys.e:686			if i > 1 then*/
        if (_i_46033 <= 1LL)
        goto LB; // [238] 255

        /** buildsys.e:687				printf(fh, " \\%s\t", { HOSTNL }  )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_44HOSTNL_20392);
        ((intptr_t*)_2)[1] = _44HOSTNL_20392;
        _23955 = MAKE_SEQ(_1);
        EPrintf(_fh_45979, _23936, _23955);
        DeRefDS(_23955);
        _23955 = NOVALUE;
LB: 

        /** buildsys.e:689			puts(fh, " " & generated_files[i])*/
        _2 = (object)SEQ_PTR(_57generated_files_42616);
        _23956 = (object)*(((s1_ptr)_2)->base + _i_46033);
        Concat((object_ptr)&_23957, _23438, _23956);
        _23956 = NOVALUE;
        EPuts(_fh_45979, _23957); // DJP 
        DeRefDS(_23957);
        _23957 = NOVALUE;

        /** buildsys.e:690		end for*/
        _i_46033 = _i_46033 + 1LL;
        goto L9; // [272] 236
LA: 
        ;
    }

    /** buildsys.e:691		puts(fh, HOSTNL)*/
    EPuts(_fh_45979, _44HOSTNL_20392); // DJP 

    /** buildsys.e:692	end procedure*/
    return;
    ;
}


object _55windows_to_mingw_path(object _s_46046)
{
    object _23959 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:701		ifdef TEST_FOR_WIN9X_ON_MING then*/

    /** buildsys.e:711		return search:find_replace('\\',s,'/')*/
    RefDS(_s_46046);
    _23959 = _20find_replace(92LL, _s_46046, 47LL, 0LL);
    DeRefDS(_s_46046);
    return _23959;
    ;
}


void _55write_makefile_full()
{
    object _settings_46051 = NOVALUE;
    object _fh_46054 = NOVALUE;
    object _24086 = NOVALUE;
    object _24084 = NOVALUE;
    object _24082 = NOVALUE;
    object _24081 = NOVALUE;
    object _24080 = NOVALUE;
    object _24079 = NOVALUE;
    object _24078 = NOVALUE;
    object _24076 = NOVALUE;
    object _24075 = NOVALUE;
    object _24073 = NOVALUE;
    object _24072 = NOVALUE;
    object _24071 = NOVALUE;
    object _24070 = NOVALUE;
    object _24068 = NOVALUE;
    object _24067 = NOVALUE;
    object _24065 = NOVALUE;
    object _24064 = NOVALUE;
    object _24062 = NOVALUE;
    object _24061 = NOVALUE;
    object _24060 = NOVALUE;
    object _24059 = NOVALUE;
    object _24058 = NOVALUE;
    object _24057 = NOVALUE;
    object _24056 = NOVALUE;
    object _24055 = NOVALUE;
    object _24053 = NOVALUE;
    object _24052 = NOVALUE;
    object _24051 = NOVALUE;
    object _24050 = NOVALUE;
    object _24049 = NOVALUE;
    object _24048 = NOVALUE;
    object _24047 = NOVALUE;
    object _24046 = NOVALUE;
    object _24045 = NOVALUE;
    object _24044 = NOVALUE;
    object _24043 = NOVALUE;
    object _24042 = NOVALUE;
    object _24041 = NOVALUE;
    object _24039 = NOVALUE;
    object _24038 = NOVALUE;
    object _23976 = NOVALUE;
    object _23975 = NOVALUE;
    object _23974 = NOVALUE;
    object _23972 = NOVALUE;
    object _23971 = NOVALUE;
    object _23970 = NOVALUE;
    object _23968 = NOVALUE;
    object _23967 = NOVALUE;
    object _23966 = NOVALUE;
    object _23963 = NOVALUE;
    object _23961 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:718		sequence settings = setup_build()*/
    _0 = _settings_46051;
    _settings_46051 = _55setup_build();
    DeRef(_0);

    /** buildsys.e:720		ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (object)SEQ_PTR(_settings_46051);
    _23961 = (object)*(((s1_ptr)_2)->base + 6LL);
    Ref(_23961);
    _55ensure_exename(_23961);
    _23961 = NOVALUE;

    /** buildsys.e:722		integer fh = open(output_dir & file0 & ".mak", "wb")*/
    {
        object concat_list[3];

        concat_list[0] = _23962;
        concat_list[1] = _57file0_44585;
        concat_list[2] = _57output_dir_42626;
        Concat_N((object_ptr)&_23963, concat_list, 3);
    }
    _fh_46054 = EOpen(_23963, _23879, 0LL);
    DeRefDS(_23963);
    _23963 = NOVALUE;

    /** buildsys.e:724		printf(fh, "CC     = %s" & HOSTNL, { settings[SETUP_CEXE] })*/
    Concat((object_ptr)&_23966, _23965, _44HOSTNL_20392);
    _2 = (object)SEQ_PTR(_settings_46051);
    _23967 = (object)*(((s1_ptr)_2)->base + 1LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23967);
    ((intptr_t*)_2)[1] = _23967;
    _23968 = MAKE_SEQ(_1);
    _23967 = NOVALUE;
    EPrintf(_fh_46054, _23966, _23968);
    DeRefDS(_23966);
    _23966 = NOVALUE;
    DeRefDS(_23968);
    _23968 = NOVALUE;

    /** buildsys.e:725		printf(fh, "CFLAGS = %s" & HOSTNL, { settings[SETUP_CFLAGS] })*/
    Concat((object_ptr)&_23970, _23969, _44HOSTNL_20392);
    _2 = (object)SEQ_PTR(_settings_46051);
    _23971 = (object)*(((s1_ptr)_2)->base + 2LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23971);
    ((intptr_t*)_2)[1] = _23971;
    _23972 = MAKE_SEQ(_1);
    _23971 = NOVALUE;
    EPrintf(_fh_46054, _23970, _23972);
    DeRefDS(_23970);
    _23970 = NOVALUE;
    DeRefDS(_23972);
    _23972 = NOVALUE;

    /** buildsys.e:726		printf(fh, "LINKER = %s" & HOSTNL, { settings[SETUP_LEXE] })*/
    Concat((object_ptr)&_23974, _23973, _44HOSTNL_20392);
    _2 = (object)SEQ_PTR(_settings_46051);
    _23975 = (object)*(((s1_ptr)_2)->base + 3LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23975);
    ((intptr_t*)_2)[1] = _23975;
    _23976 = MAKE_SEQ(_1);
    _23975 = NOVALUE;
    EPrintf(_fh_46054, _23974, _23976);
    DeRefDS(_23974);
    _23974 = NOVALUE;
    DeRefDS(_23976);
    _23976 = NOVALUE;

    /** buildsys.e:728		if compiler_type = COMPILER_GCC then*/

    /** buildsys.e:731			write_objlink_file()*/
    _55write_objlink_file();

    /** buildsys.e:734		write_makefile_srcobj_list(fh)*/
    _55write_makefile_srcobj_list(_fh_46054);

    /** buildsys.e:735		puts(fh, HOSTNL)*/
    EPuts(_fh_46054, _44HOSTNL_20392); // DJP 

    /** buildsys.e:737		if compiler_type = COMPILER_WATCOM then*/

    /** buildsys.e:770			printf(fh, "RUNTIME_LIBRARY=%s\n", { settings[SETUP_RUNTIME_LIBRARY] } )*/
    _2 = (object)SEQ_PTR(_settings_46051);
    _24038 = (object)*(((s1_ptr)_2)->base + 9LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24038);
    ((intptr_t*)_2)[1] = _24038;
    _24039 = MAKE_SEQ(_1);
    _24038 = NOVALUE;
    EPrintf(_fh_46054, _24037, _24039);
    DeRefDS(_24039);
    _24039 = NOVALUE;

    /** buildsys.e:771			printf(fh, "%s: $(%s_OBJECTS) $(RUNTIME_LIBRARY) %s " & HOSTNL, { adjust_for_build_file(exe_name[D_ALTNAME]), upper(file0), rc_file[D_ALTNAME] })*/
    Concat((object_ptr)&_24041, _24040, _44HOSTNL_20392);
    _2 = (object)SEQ_PTR(_55exe_name_45452);
    _24042 = (object)*(((s1_ptr)_2)->base + 11LL);
    Ref(_24042);
    _24043 = _55adjust_for_build_file(_24042);
    _24042 = NOVALUE;
    RefDS(_57file0_44585);
    _24044 = _18upper(_57file0_44585);
    _2 = (object)SEQ_PTR(_55rc_file_45458);
    _24045 = (object)*(((s1_ptr)_2)->base + 11LL);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24043;
    ((intptr_t*)_2)[2] = _24044;
    RefDS(_24045);
    ((intptr_t*)_2)[3] = _24045;
    _24046 = MAKE_SEQ(_1);
    _24045 = NOVALUE;
    _24044 = NOVALUE;
    _24043 = NOVALUE;
    EPrintf(_fh_46054, _24041, _24046);
    DeRefDS(_24041);
    _24041 = NOVALUE;
    DeRefDS(_24046);
    _24046 = NOVALUE;

    /** buildsys.e:772			if length(rc_file[D_ALTNAME]) then*/
    _2 = (object)SEQ_PTR(_55rc_file_45458);
    _24047 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (IS_SEQUENCE(_24047)){
            _24048 = SEQ_PTR(_24047)->length;
    }
    else {
        _24048 = 1;
    }
    _24047 = NOVALUE;
    if (_24048 == 0)
    {
        _24048 = NOVALUE;
        goto L1; // [646] 690
    }
    else{
        _24048 = NOVALUE;
    }

    /** buildsys.e:773				writef(fh, "\t" & settings[SETUP_RC_COMPILER] & HOSTNL, { rc_file[D_ALTNAME], res_file[D_ALTNAME] })*/
    _2 = (object)SEQ_PTR(_settings_46051);
    _24049 = (object)*(((s1_ptr)_2)->base + 8LL);
    {
        object concat_list[3];

        concat_list[0] = _44HOSTNL_20392;
        concat_list[1] = _24049;
        concat_list[2] = _23996;
        Concat_N((object_ptr)&_24050, concat_list, 3);
    }
    _24049 = NOVALUE;
    _2 = (object)SEQ_PTR(_55rc_file_45458);
    _24051 = (object)*(((s1_ptr)_2)->base + 11LL);
    _2 = (object)SEQ_PTR(_55res_file_45464);
    _24052 = (object)*(((s1_ptr)_2)->base + 11LL);
    RefDS(_24052);
    RefDS(_24051);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24051;
    ((intptr_t *)_2)[2] = _24052;
    _24053 = MAKE_SEQ(_1);
    _24052 = NOVALUE;
    _24051 = NOVALUE;
    _17writef(_fh_46054, _24050, _24053, 0LL);
    _24050 = NOVALUE;
    _24053 = NOVALUE;
L1: 

    /** buildsys.e:775			printf(fh, "\t$(LINKER) -o %s $(%s_OBJECTS) %s $(LFLAGS)" & HOSTNL, {*/
    Concat((object_ptr)&_24055, _24054, _44HOSTNL_20392);
    _2 = (object)SEQ_PTR(_55exe_name_45452);
    _24056 = (object)*(((s1_ptr)_2)->base + 11LL);
    RefDS(_57file0_44585);
    _24057 = _18upper(_57file0_44585);
    _2 = (object)SEQ_PTR(_55res_file_45464);
    _24058 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (IS_SEQUENCE(_24058)){
            _24059 = SEQ_PTR(_24058)->length;
    }
    else {
        _24059 = 1;
    }
    _24058 = NOVALUE;
    _2 = (object)SEQ_PTR(_55res_file_45464);
    _24060 = (object)*(((s1_ptr)_2)->base + 11LL);
    RefDS(_24060);
    RefDS(_22024);
    _24061 = _56iif(_24059, _24060, _22024);
    _24059 = NOVALUE;
    _24060 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24056);
    ((intptr_t*)_2)[1] = _24056;
    ((intptr_t*)_2)[2] = _24057;
    ((intptr_t*)_2)[3] = _24061;
    _24062 = MAKE_SEQ(_1);
    _24061 = NOVALUE;
    _24057 = NOVALUE;
    _24056 = NOVALUE;
    EPrintf(_fh_46054, _24055, _24062);
    DeRefDS(_24055);
    _24055 = NOVALUE;
    DeRefDS(_24062);
    _24062 = NOVALUE;

    /** buildsys.e:777			puts(fh, HOSTNL)*/
    EPuts(_fh_46054, _44HOSTNL_20392); // DJP 

    /** buildsys.e:778			printf(fh, ".PHONY: %s-clean %s-clean-all" & HOSTNL, { file0, file0 })*/
    Concat((object_ptr)&_24064, _24063, _44HOSTNL_20392);
    RefDS(_57file0_44585);
    RefDS(_57file0_44585);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _57file0_44585;
    ((intptr_t *)_2)[2] = _57file0_44585;
    _24065 = MAKE_SEQ(_1);
    EPrintf(_fh_46054, _24064, _24065);
    DeRefDS(_24064);
    _24064 = NOVALUE;
    DeRefDS(_24065);
    _24065 = NOVALUE;

    /** buildsys.e:779			puts(fh, HOSTNL)*/
    EPuts(_fh_46054, _44HOSTNL_20392); // DJP 

    /** buildsys.e:780			printf(fh, "%s-clean:" & HOSTNL, { file0 })*/
    Concat((object_ptr)&_24067, _24066, _44HOSTNL_20392);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_57file0_44585);
    ((intptr_t*)_2)[1] = _57file0_44585;
    _24068 = MAKE_SEQ(_1);
    EPrintf(_fh_46054, _24067, _24068);
    DeRefDS(_24067);
    _24067 = NOVALUE;
    DeRefDS(_24068);
    _24068 = NOVALUE;

    /** buildsys.e:781			printf(fh, "\trm -rf $(%s_OBJECTS) %s" & HOSTNL, { upper(file0), res_file[D_ALTNAME] })*/
    Concat((object_ptr)&_24070, _24069, _44HOSTNL_20392);
    RefDS(_57file0_44585);
    _24071 = _18upper(_57file0_44585);
    _2 = (object)SEQ_PTR(_55res_file_45464);
    _24072 = (object)*(((s1_ptr)_2)->base + 11LL);
    RefDS(_24072);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24071;
    ((intptr_t *)_2)[2] = _24072;
    _24073 = MAKE_SEQ(_1);
    _24072 = NOVALUE;
    _24071 = NOVALUE;
    EPrintf(_fh_46054, _24070, _24073);
    DeRefDS(_24070);
    _24070 = NOVALUE;
    DeRefDS(_24073);
    _24073 = NOVALUE;

    /** buildsys.e:782			puts(fh, HOSTNL)*/
    EPuts(_fh_46054, _44HOSTNL_20392); // DJP 

    /** buildsys.e:783			printf(fh, "%s-clean-all: %s-clean" & HOSTNL, { file0, file0 })*/
    Concat((object_ptr)&_24075, _24074, _44HOSTNL_20392);
    RefDS(_57file0_44585);
    RefDS(_57file0_44585);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _57file0_44585;
    ((intptr_t *)_2)[2] = _57file0_44585;
    _24076 = MAKE_SEQ(_1);
    EPrintf(_fh_46054, _24075, _24076);
    DeRefDS(_24075);
    _24075 = NOVALUE;
    DeRefDS(_24076);
    _24076 = NOVALUE;

    /** buildsys.e:784			printf(fh, "\trm -rf $(%s_SOURCES) %s %s" & HOSTNL, { upper(file0), res_file[D_ALTNAME], exe_name[D_ALTNAME] })*/
    Concat((object_ptr)&_24078, _24077, _44HOSTNL_20392);
    RefDS(_57file0_44585);
    _24079 = _18upper(_57file0_44585);
    _2 = (object)SEQ_PTR(_55res_file_45464);
    _24080 = (object)*(((s1_ptr)_2)->base + 11LL);
    _2 = (object)SEQ_PTR(_55exe_name_45452);
    _24081 = (object)*(((s1_ptr)_2)->base + 11LL);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24079;
    RefDS(_24080);
    ((intptr_t*)_2)[2] = _24080;
    Ref(_24081);
    ((intptr_t*)_2)[3] = _24081;
    _24082 = MAKE_SEQ(_1);
    _24081 = NOVALUE;
    _24080 = NOVALUE;
    _24079 = NOVALUE;
    EPrintf(_fh_46054, _24078, _24082);
    DeRefDS(_24078);
    _24078 = NOVALUE;
    DeRefDS(_24082);
    _24082 = NOVALUE;

    /** buildsys.e:785			puts(fh, HOSTNL)*/
    EPuts(_fh_46054, _44HOSTNL_20392); // DJP 

    /** buildsys.e:786			puts(fh, "%.o: %.c" & HOSTNL)*/
    Concat((object_ptr)&_24084, _24083, _44HOSTNL_20392);
    EPuts(_fh_46054, _24084); // DJP 
    DeRefDS(_24084);
    _24084 = NOVALUE;

    /** buildsys.e:787			puts(fh, "\t$(CC) $(CFLAGS) $*.c -o $*.o" & HOSTNL)*/
    Concat((object_ptr)&_24086, _24085, _44HOSTNL_20392);
    EPuts(_fh_46054, _24086); // DJP 
    DeRefDS(_24086);
    _24086 = NOVALUE;

    /** buildsys.e:788			puts(fh, HOSTNL)*/
    EPuts(_fh_46054, _44HOSTNL_20392); // DJP 

    /** buildsys.e:791		close(fh)*/
    EClose(_fh_46054);

    /** buildsys.e:792	end procedure*/
    DeRef(_settings_46051);
    _24058 = NOVALUE;
    _24047 = NOVALUE;
    return;
    ;
}


void _55write_makefile_partial()
{
    object _settings_46280 = NOVALUE;
    object _fh_46282 = NOVALUE;
    object _24088 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:798		sequence settings = setup_build()*/
    _0 = _settings_46280;
    _settings_46280 = _55setup_build();
    DeRef(_0);

    /** buildsys.e:799		integer fh = open(output_dir & file0 & ".mak", "wb")*/
    {
        object concat_list[3];

        concat_list[0] = _23962;
        concat_list[1] = _57file0_44585;
        concat_list[2] = _57output_dir_42626;
        Concat_N((object_ptr)&_24088, concat_list, 3);
    }
    _fh_46282 = EOpen(_24088, _23879, 0LL);
    DeRefDS(_24088);
    _24088 = NOVALUE;

    /** buildsys.e:801		write_makefile_srcobj_list(fh)*/
    _55write_makefile_srcobj_list(_fh_46282);

    /** buildsys.e:803		close(fh)*/
    EClose(_fh_46282);

    /** buildsys.e:804	end procedure*/
    DeRefDS(_settings_46280);
    return;
    ;
}


void _55build_direct(object _link_only_46289, object _the_file0_46290)
{
    object _cmd_46296 = NOVALUE;
    object _objs_46297 = NOVALUE;
    object _settings_46298 = NOVALUE;
    object _cwd_46300 = NOVALUE;
    object _status_46303 = NOVALUE;
    object _link_files_46334 = NOVALUE;
    object _pdone_46360 = NOVALUE;
    object _files_46412 = NOVALUE;
    object _31801 = NOVALUE;
    object _31800 = NOVALUE;
    object _31799 = NOVALUE;
    object _31798 = NOVALUE;
    object _31797 = NOVALUE;
    object _31795 = NOVALUE;
    object _24233 = NOVALUE;
    object _24232 = NOVALUE;
    object _24231 = NOVALUE;
    object _24230 = NOVALUE;
    object _24229 = NOVALUE;
    object _24228 = NOVALUE;
    object _24227 = NOVALUE;
    object _24225 = NOVALUE;
    object _24224 = NOVALUE;
    object _24223 = NOVALUE;
    object _24222 = NOVALUE;
    object _24218 = NOVALUE;
    object _24217 = NOVALUE;
    object _24216 = NOVALUE;
    object _24215 = NOVALUE;
    object _24214 = NOVALUE;
    object _24213 = NOVALUE;
    object _24212 = NOVALUE;
    object _24211 = NOVALUE;
    object _24210 = NOVALUE;
    object _24209 = NOVALUE;
    object _24208 = NOVALUE;
    object _24207 = NOVALUE;
    object _24206 = NOVALUE;
    object _24205 = NOVALUE;
    object _24204 = NOVALUE;
    object _24201 = NOVALUE;
    object _24200 = NOVALUE;
    object _24199 = NOVALUE;
    object _24198 = NOVALUE;
    object _24195 = NOVALUE;
    object _24193 = NOVALUE;
    object _24192 = NOVALUE;
    object _24191 = NOVALUE;
    object _24190 = NOVALUE;
    object _24189 = NOVALUE;
    object _24188 = NOVALUE;
    object _24185 = NOVALUE;
    object _24184 = NOVALUE;
    object _24180 = NOVALUE;
    object _24179 = NOVALUE;
    object _24178 = NOVALUE;
    object _24174 = NOVALUE;
    object _24173 = NOVALUE;
    object _24172 = NOVALUE;
    object _24171 = NOVALUE;
    object _24170 = NOVALUE;
    object _24169 = NOVALUE;
    object _24168 = NOVALUE;
    object _24167 = NOVALUE;
    object _24166 = NOVALUE;
    object _24165 = NOVALUE;
    object _24164 = NOVALUE;
    object _24163 = NOVALUE;
    object _24161 = NOVALUE;
    object _24160 = NOVALUE;
    object _24159 = NOVALUE;
    object _24158 = NOVALUE;
    object _24157 = NOVALUE;
    object _24155 = NOVALUE;
    object _24154 = NOVALUE;
    object _24153 = NOVALUE;
    object _24152 = NOVALUE;
    object _24151 = NOVALUE;
    object _24149 = NOVALUE;
    object _24147 = NOVALUE;
    object _24146 = NOVALUE;
    object _24145 = NOVALUE;
    object _24144 = NOVALUE;
    object _24142 = NOVALUE;
    object _24141 = NOVALUE;
    object _24140 = NOVALUE;
    object _24137 = NOVALUE;
    object _24136 = NOVALUE;
    object _24135 = NOVALUE;
    object _24134 = NOVALUE;
    object _24133 = NOVALUE;
    object _24132 = NOVALUE;
    object _24131 = NOVALUE;
    object _24130 = NOVALUE;
    object _24129 = NOVALUE;
    object _24128 = NOVALUE;
    object _24125 = NOVALUE;
    object _24124 = NOVALUE;
    object _24120 = NOVALUE;
    object _24118 = NOVALUE;
    object _24117 = NOVALUE;
    object _24116 = NOVALUE;
    object _24115 = NOVALUE;
    object _24112 = NOVALUE;
    object _24111 = NOVALUE;
    object _24110 = NOVALUE;
    object _24109 = NOVALUE;
    object _24107 = NOVALUE;
    object _24106 = NOVALUE;
    object _24105 = NOVALUE;
    object _24104 = NOVALUE;
    object _24103 = NOVALUE;
    object _24100 = NOVALUE;
    object _24094 = NOVALUE;
    object _24090 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:810		if length(the_file0) then*/
    _24090 = 0;

    /** buildsys.e:813		sequence cmd, objs = "", settings = setup_build(), cwd = current_dir()*/
    RefDS(_22024);
    DeRef(_objs_46297);
    _objs_46297 = _22024;
    _0 = _settings_46298;
    _settings_46298 = _55setup_build();
    DeRef(_0);
    _0 = _cwd_46300;
    _cwd_46300 = _14current_dir();
    DeRef(_0);

    /** buildsys.e:814		integer status*/

    /** buildsys.e:816		ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (object)SEQ_PTR(_settings_46298);
    _24094 = (object)*(((s1_ptr)_2)->base + 6LL);
    Ref(_24094);
    _55ensure_exename(_24094);
    _24094 = NOVALUE;

    /** buildsys.e:818		if not link_only then*/

    /** buildsys.e:819			switch compiler_type do*/
    _0 = 0LL;
    switch ( _0 ){ 

        /** buildsys.e:820				case COMPILER_GCC then*/
        case 1:

        /** buildsys.e:821					if not silent then*/
        if (_12silent_20342 != 0)
        goto L1; // [72] 123

        /** buildsys.e:822						ShowMsg(1, COMPILING_WITH_1, {"GCC"})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24099);
        ((intptr_t*)_2)[1] = _24099;
        _24100 = MAKE_SEQ(_1);
        _30ShowMsg(1LL, 176LL, _24100, 1LL);
        _24100 = NOVALUE;
        goto L1; // [90] 123

        /** buildsys.e:825				case COMPILER_WATCOM then*/
        case 2:

        /** buildsys.e:826					write_objlink_file()*/
        _55write_objlink_file();

        /** buildsys.e:828					if not silent then*/
        if (_12silent_20342 != 0)
        goto L2; // [104] 122

        /** buildsys.e:829						ShowMsg(1, COMPILING_WITH_1, {"Watcom"})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24102);
        ((intptr_t*)_2)[1] = _24102;
        _24103 = MAKE_SEQ(_1);
        _30ShowMsg(1LL, 176LL, _24103, 1LL);
        _24103 = NOVALUE;
L2: 
    ;}L1: 

    /** buildsys.e:834		if sequence(output_dir) and length(output_dir) > 0 then*/
    _24104 = 1;
    if (_24104 == 0) {
        goto L3; // [131] 159
    }
    _24106 = 0;
    _24107 = (0LL > 0LL);
    _24106 = NOVALUE;
    if (_24107 == 0)
    {
        DeRef(_24107);
        _24107 = NOVALUE;
        goto L3; // [145] 159
    }
    else{
        DeRef(_24107);
        _24107 = NOVALUE;
    }

    /** buildsys.e:835			chdir(output_dir)*/
    RefDS(_57output_dir_42626);
    _31801 = _14chdir(_57output_dir_42626);
    DeRef(_31801);
    _31801 = NOVALUE;
L3: 

    /** buildsys.e:838		sequence link_files = {}*/
    RefDS(_22024);
    DeRef(_link_files_46334);
    _link_files_46334 = _22024;

    /** buildsys.e:840		if not link_only then*/
    if (_link_only_46289 != 0)
    goto L4; // [168] 482

    /** buildsys.e:841			for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_42616)){
            _24109 = SEQ_PTR(_57generated_files_42616)->length;
    }
    else {
        _24109 = 1;
    }
    {
        object _i_46338;
        _i_46338 = 1LL;
L5: 
        if (_i_46338 > _24109){
            goto L6; // [178] 479
        }

        /** buildsys.e:842				if generated_files[i][$] = 'c' then*/
        _2 = (object)SEQ_PTR(_57generated_files_42616);
        _24110 = (object)*(((s1_ptr)_2)->base + _i_46338);
        if (IS_SEQUENCE(_24110)){
                _24111 = SEQ_PTR(_24110)->length;
        }
        else {
            _24111 = 1;
        }
        _2 = (object)SEQ_PTR(_24110);
        _24112 = (object)*(((s1_ptr)_2)->base + _24111);
        _24110 = NOVALUE;
        if (binary_op_a(NOTEQ, _24112, 99LL)){
            _24112 = NOVALUE;
            goto L7; // [200] 438
        }
        _24112 = NOVALUE;

        /** buildsys.e:843					cmd = sprintf("%s %s %s", { settings[SETUP_CEXE], settings[SETUP_CFLAGS],*/
        _2 = (object)SEQ_PTR(_settings_46298);
        _24115 = (object)*(((s1_ptr)_2)->base + 1LL);
        _2 = (object)SEQ_PTR(_settings_46298);
        _24116 = (object)*(((s1_ptr)_2)->base + 2LL);
        _2 = (object)SEQ_PTR(_57generated_files_42616);
        _24117 = (object)*(((s1_ptr)_2)->base + _i_46338);
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_24115);
        ((intptr_t*)_2)[1] = _24115;
        Ref(_24116);
        ((intptr_t*)_2)[2] = _24116;
        RefDS(_24117);
        ((intptr_t*)_2)[3] = _24117;
        _24118 = MAKE_SEQ(_1);
        _24117 = NOVALUE;
        _24116 = NOVALUE;
        _24115 = NOVALUE;
        DeRef(_cmd_46296);
        _cmd_46296 = EPrintf(-9999999, _24114, _24118);
        DeRefDS(_24118);
        _24118 = NOVALUE;

        /** buildsys.e:846					link_files = append(link_files, generated_files[i])*/
        _2 = (object)SEQ_PTR(_57generated_files_42616);
        _24120 = (object)*(((s1_ptr)_2)->base + _i_46338);
        RefDS(_24120);
        Append(&_link_files_46334, _link_files_46334, _24120);
        _24120 = NOVALUE;

        /** buildsys.e:848					if not silent then*/
        if (_12silent_20342 != 0)
        goto L8; // [246] 374

        /** buildsys.e:849						atom pdone = 100 * (i / length(generated_files))*/
        if (IS_SEQUENCE(_57generated_files_42616)){
                _24124 = SEQ_PTR(_57generated_files_42616)->length;
        }
        else {
            _24124 = 1;
        }
        _24125 = (_i_46338 % _24124) ? NewDouble((eudouble)_i_46338 / _24124) : (_i_46338 / _24124);
        _24124 = NOVALUE;
        DeRef(_pdone_46360);
        if (IS_ATOM_INT(_24125)) {
            {
                int128_t p128 = (int128_t)100LL * (int128_t)_24125;
                if( p128 != (int128_t)(_pdone_46360 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                    _pdone_46360 = NewDouble( (eudouble)p128 );
                }
            }
        }
        else {
            _pdone_46360 = NewDouble((eudouble)100LL * DBL_PTR(_24125)->dbl);
        }
        DeRef(_24125);
        _24125 = NOVALUE;

        /** buildsys.e:850						if not verbose then*/
        if (_12verbose_20345 != 0)
        goto L9; // [268] 358

        /** buildsys.e:853							if 0 and outdated_files[i] = 0 and force_build = 0 then*/
        if (0LL == 0) {
            _24128 = 0;
            goto LA; // [273] 291
        }
        _2 = (object)SEQ_PTR(_57outdated_files_42617);
        _24129 = (object)*(((s1_ptr)_2)->base + _i_46338);
        if (IS_ATOM_INT(_24129)) {
            _24130 = (_24129 == 0LL);
        }
        else {
            _24130 = binary_op(EQUALS, _24129, 0LL);
        }
        _24129 = NOVALUE;
        if (IS_ATOM_INT(_24130))
        _24128 = (_24130 != 0);
        else
        _24128 = DBL_PTR(_24130)->dbl != 0.0;
LA: 
        if (_24128 == 0) {
            goto LB; // [291] 334
        }
        _24132 = (0LL == 0LL);
        if (_24132 == 0)
        {
            DeRef(_24132);
            _24132 = NOVALUE;
            goto LB; // [302] 334
        }
        else{
            DeRef(_24132);
            _24132 = NOVALUE;
        }

        /** buildsys.e:854								ShowMsg(1, SKIPPING__130_2_UPTODATE, { pdone, generated_files[i] })*/
        _2 = (object)SEQ_PTR(_57generated_files_42616);
        _24133 = (object)*(((s1_ptr)_2)->base + _i_46338);
        RefDS(_24133);
        Ref(_pdone_46360);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _pdone_46360;
        ((intptr_t *)_2)[2] = _24133;
        _24134 = MAKE_SEQ(_1);
        _24133 = NOVALUE;
        _30ShowMsg(1LL, 325LL, _24134, 1LL);
        _24134 = NOVALUE;

        /** buildsys.e:855								continue*/
        DeRef(_pdone_46360);
        _pdone_46360 = NOVALUE;
        goto LC; // [329] 474
        goto LD; // [331] 373
LB: 

        /** buildsys.e:857								ShowMsg(1, COMPILING_130_2, { pdone, generated_files[i] })*/
        _2 = (object)SEQ_PTR(_57generated_files_42616);
        _24135 = (object)*(((s1_ptr)_2)->base + _i_46338);
        RefDS(_24135);
        Ref(_pdone_46360);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _pdone_46360;
        ((intptr_t *)_2)[2] = _24135;
        _24136 = MAKE_SEQ(_1);
        _24135 = NOVALUE;
        _30ShowMsg(1LL, 163LL, _24136, 1LL);
        _24136 = NOVALUE;
        goto LD; // [355] 373
L9: 

        /** buildsys.e:860							ShowMsg(1, COMPILING_130_2, { pdone, cmd })*/
        RefDS(_cmd_46296);
        Ref(_pdone_46360);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _pdone_46360;
        ((intptr_t *)_2)[2] = _cmd_46296;
        _24137 = MAKE_SEQ(_1);
        _30ShowMsg(1LL, 163LL, _24137, 1LL);
        _24137 = NOVALUE;
LD: 
L8: 
        DeRef(_pdone_46360);
        _pdone_46360 = NOVALUE;

        /** buildsys.e:865					status = system_exec(cmd, 0)*/
        _status_46303 = system_exec_call(_cmd_46296, 0LL);

        /** buildsys.e:866					if status != 0 then*/
        if (_status_46303 == 0LL)
        goto LE; // [384] 472

        /** buildsys.e:867						ShowMsg(2, COULDNT_COMPILE_FILE_1, { generated_files[i] })*/
        _2 = (object)SEQ_PTR(_57generated_files_42616);
        _24140 = (object)*(((s1_ptr)_2)->base + _i_46338);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24140);
        ((intptr_t*)_2)[1] = _24140;
        _24141 = MAKE_SEQ(_1);
        _24140 = NOVALUE;
        _30ShowMsg(2LL, 164LL, _24141, 1LL);
        _24141 = NOVALUE;

        /** buildsys.e:868						ShowMsg(2, STATUS_1_COMMAND_2, { status, cmd })*/
        RefDS(_cmd_46296);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _status_46303;
        ((intptr_t *)_2)[2] = _cmd_46296;
        _24142 = MAKE_SEQ(_1);
        _30ShowMsg(2LL, 165LL, _24142, 1LL);
        _24142 = NOVALUE;

        /** buildsys.e:869						goto "build_direct_cleanup"*/
        goto GF;
        goto LE; // [435] 472
L7: 

        /** buildsys.e:871				elsif match(".o", generated_files[i]) then*/
        _2 = (object)SEQ_PTR(_57generated_files_42616);
        _24144 = (object)*(((s1_ptr)_2)->base + _i_46338);
        _24145 = e_match_from(_23193, _24144, 1LL);
        _24144 = NOVALUE;
        if (_24145 == 0)
        {
            _24145 = NOVALUE;
            goto L10; // [451] 471
        }
        else{
            _24145 = NOVALUE;
        }

        /** buildsys.e:872					objs &= " " & generated_files[i]*/
        _2 = (object)SEQ_PTR(_57generated_files_42616);
        _24146 = (object)*(((s1_ptr)_2)->base + _i_46338);
        Concat((object_ptr)&_24147, _23438, _24146);
        _24146 = NOVALUE;
        Concat((object_ptr)&_objs_46297, _objs_46297, _24147);
        DeRefDS(_24147);
        _24147 = NOVALUE;
L10: 
LE: 

        /** buildsys.e:874			end for*/
LC: 
        _i_46338 = _i_46338 + 1LL;
        goto L5; // [474] 185
L6: 
        ;
    }
    goto L11; // [479] 541
L4: 

    /** buildsys.e:876			object files = read_lines(file0 & ".bld")*/
    Concat((object_ptr)&_24149, _57file0_44585, _23649);
    _0 = _files_46412;
    _files_46412 = _17read_lines(_24149);
    DeRef(_0);
    _24149 = NOVALUE;

    /** buildsys.e:877			for i = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_46412)){
            _24151 = SEQ_PTR(_files_46412)->length;
    }
    else {
        _24151 = 1;
    }
    {
        object _i_46418;
        _i_46418 = 1LL;
L12: 
        if (_i_46418 > _24151){
            goto L13; // [499] 538
        }

        /** buildsys.e:878				objs &= " " & filebase(files[i]) & "." & settings[SETUP_OBJ_EXT]*/
        _2 = (object)SEQ_PTR(_files_46412);
        _24152 = (object)*(((s1_ptr)_2)->base + _i_46418);
        Ref(_24152);
        _24153 = _14filebase(_24152);
        _24152 = NOVALUE;
        _2 = (object)SEQ_PTR(_settings_46298);
        _24154 = (object)*(((s1_ptr)_2)->base + 5LL);
        {
            object concat_list[4];

            concat_list[0] = _24154;
            concat_list[1] = _23234;
            concat_list[2] = _24153;
            concat_list[3] = _23438;
            Concat_N((object_ptr)&_24155, concat_list, 4);
        }
        _24154 = NOVALUE;
        DeRef(_24153);
        _24153 = NOVALUE;
        Concat((object_ptr)&_objs_46297, _objs_46297, _24155);
        DeRefDS(_24155);
        _24155 = NOVALUE;

        /** buildsys.e:879			end for*/
        _i_46418 = _i_46418 + 1LL;
        goto L12; // [533] 506
L13: 
        ;
    }
    DeRef(_files_46412);
    _files_46412 = NOVALUE;
L11: 

    /** buildsys.e:882		if keep and not link_only and length(link_files) then*/
    if (_57keep_42619 == 0) {
        _24157 = 0;
        goto L14; // [545] 556
    }
    _24158 = (_link_only_46289 == 0);
    _24157 = (_24158 != 0);
L14: 
    if (_24157 == 0) {
        goto L15; // [556] 585
    }
    if (IS_SEQUENCE(_link_files_46334)){
            _24160 = SEQ_PTR(_link_files_46334)->length;
    }
    else {
        _24160 = 1;
    }
    if (_24160 == 0)
    {
        _24160 = NOVALUE;
        goto L15; // [564] 585
    }
    else{
        _24160 = NOVALUE;
    }

    /** buildsys.e:883			write_lines(file0 & ".bld", link_files)*/
    Concat((object_ptr)&_24161, _57file0_44585, _23649);
    RefDS(_link_files_46334);
    _31800 = _17write_lines(_24161, _link_files_46334);
    _24161 = NOVALUE;
    DeRef(_31800);
    _31800 = NOVALUE;
    goto L16; // [582] 609
L15: 

    /** buildsys.e:884		elsif keep = 0 then*/
    if (_57keep_42619 != 0LL)
    goto L17; // [589] 608

    /** buildsys.e:886			delete_file(file0 & ".bld")*/
    Concat((object_ptr)&_24163, _57file0_44585, _23649);
    _31799 = _14delete_file(_24163);
    _24163 = NOVALUE;
    DeRef(_31799);
    _31799 = NOVALUE;
L17: 
L16: 

    /** buildsys.e:890		if length(rc_file[D_ALTNAME]) and length(settings[SETUP_RC_COMPILER]) and compiler_type = COMPILER_GCC then*/
    _2 = (object)SEQ_PTR(_55rc_file_45458);
    _24164 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (IS_SEQUENCE(_24164)){
            _24165 = SEQ_PTR(_24164)->length;
    }
    else {
        _24165 = 1;
    }
    _24164 = NOVALUE;
    if (_24165 == 0) {
        _24166 = 0;
        goto L18; // [622] 637
    }
    _2 = (object)SEQ_PTR(_settings_46298);
    _24167 = (object)*(((s1_ptr)_2)->base + 8LL);
    if (IS_SEQUENCE(_24167)){
            _24168 = SEQ_PTR(_24167)->length;
    }
    else {
        _24168 = 1;
    }
    _24167 = NOVALUE;
    _24166 = (_24168 != 0);
L18: 
    if (_24166 == 0) {
        goto L19; // [637] 742
    }
    _24170 = (0LL == 1LL);
    if (_24170 == 0)
    {
        DeRef(_24170);
        _24170 = NOVALUE;
        goto L19; // [648] 742
    }
    else{
        DeRef(_24170);
        _24170 = NOVALUE;
    }

    /** buildsys.e:891			cmd = text:format(settings[SETUP_RC_COMPILER], { rc_file[D_ALTNAME], res_file[D_ALTNAME] })*/
    _2 = (object)SEQ_PTR(_settings_46298);
    _24171 = (object)*(((s1_ptr)_2)->base + 8LL);
    _2 = (object)SEQ_PTR(_55rc_file_45458);
    _24172 = (object)*(((s1_ptr)_2)->base + 11LL);
    _2 = (object)SEQ_PTR(_55res_file_45464);
    _24173 = (object)*(((s1_ptr)_2)->base + 11LL);
    RefDS(_24173);
    RefDS(_24172);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24172;
    ((intptr_t *)_2)[2] = _24173;
    _24174 = MAKE_SEQ(_1);
    _24173 = NOVALUE;
    _24172 = NOVALUE;
    Ref(_24171);
    _0 = _cmd_46296;
    _cmd_46296 = _18format(_24171, _24174);
    DeRef(_0);
    _24171 = NOVALUE;
    _24174 = NOVALUE;

    /** buildsys.e:892			status = system_exec(cmd, 0)*/
    _status_46303 = system_exec_call(_cmd_46296, 0LL);

    /** buildsys.e:893			if status != 0 then*/
    if (_status_46303 == 0LL)
    goto L1A; // [692] 741

    /** buildsys.e:894				ShowMsg(2, UNABLE_TO_COMPILE_RESOURCE_FILE_1, { rc_file[D_NAME] })*/
    _2 = (object)SEQ_PTR(_55rc_file_45458);
    _24178 = (object)*(((s1_ptr)_2)->base + 1LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_24178);
    ((intptr_t*)_2)[1] = _24178;
    _24179 = MAKE_SEQ(_1);
    _24178 = NOVALUE;
    _30ShowMsg(2LL, 350LL, _24179, 1LL);
    _24179 = NOVALUE;

    /** buildsys.e:895				ShowMsg(2, STATUS_1_COMMAND_2_A, { status, cmd })*/
    RefDS(_cmd_46296);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _status_46303;
    ((intptr_t *)_2)[2] = _cmd_46296;
    _24180 = MAKE_SEQ(_1);
    _30ShowMsg(2LL, 169LL, _24180, 1LL);
    _24180 = NOVALUE;

    /** buildsys.e:897				goto "build_direct_cleanup"*/
    goto GF;
L1A: 
L19: 

    /** buildsys.e:901		switch compiler_type do*/
    _0 = 0LL;
    switch ( _0 ){ 

        /** buildsys.e:902			case COMPILER_WATCOM then*/
        case 2:

        /** buildsys.e:903				cmd = sprintf("%s @%s.lnk", { settings[SETUP_LEXE], file0 })*/
        _2 = (object)SEQ_PTR(_settings_46298);
        _24184 = (object)*(((s1_ptr)_2)->base + 3LL);
        RefDS(_57file0_44585);
        Ref(_24184);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _24184;
        ((intptr_t *)_2)[2] = _57file0_44585;
        _24185 = MAKE_SEQ(_1);
        _24184 = NOVALUE;
        DeRef(_cmd_46296);
        _cmd_46296 = EPrintf(-9999999, _24183, _24185);
        DeRefDS(_24185);
        _24185 = NOVALUE;
        goto L1B; // [771] 848

        /** buildsys.e:905			case COMPILER_GCC then*/
        case 1:

        /** buildsys.e:906				cmd = sprintf("%s -o %s %s %s %s", { */
        _2 = (object)SEQ_PTR(_settings_46298);
        _24188 = (object)*(((s1_ptr)_2)->base + 3LL);
        _2 = (object)SEQ_PTR(_55exe_name_45452);
        _24189 = (object)*(((s1_ptr)_2)->base + 11LL);
        Ref(_24189);
        _24190 = _55adjust_for_build_file(_24189);
        _24189 = NOVALUE;
        _2 = (object)SEQ_PTR(_55res_file_45464);
        _24191 = (object)*(((s1_ptr)_2)->base + 11LL);
        _2 = (object)SEQ_PTR(_settings_46298);
        _24192 = (object)*(((s1_ptr)_2)->base + 4LL);
        _1 = NewS1(5);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_24188);
        ((intptr_t*)_2)[1] = _24188;
        ((intptr_t*)_2)[2] = _24190;
        RefDS(_objs_46297);
        ((intptr_t*)_2)[3] = _objs_46297;
        RefDS(_24191);
        ((intptr_t*)_2)[4] = _24191;
        Ref(_24192);
        ((intptr_t*)_2)[5] = _24192;
        _24193 = MAKE_SEQ(_1);
        _24192 = NOVALUE;
        _24191 = NOVALUE;
        _24190 = NOVALUE;
        _24188 = NOVALUE;
        DeRef(_cmd_46296);
        _cmd_46296 = EPrintf(-9999999, _24187, _24193);
        DeRefDS(_24193);
        _24193 = NOVALUE;
        goto L1B; // [819] 848

        /** buildsys.e:915			case else*/
        default:

        /** buildsys.e:916				ShowMsg(2, UNKNOWN_COMPILER_TYPE_1, { compiler_type })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = 0LL;
        _24195 = MAKE_SEQ(_1);
        _30ShowMsg(2LL, 167LL, _24195, 1LL);
        _24195 = NOVALUE;

        /** buildsys.e:918				goto "build_direct_cleanup"*/
        goto GF;
    ;}L1B: 

    /** buildsys.e:921		if not silent then*/
    if (_12silent_20342 != 0)
    goto L1C; // [852] 910

    /** buildsys.e:922			if not verbose then*/
    if (_12verbose_20345 != 0)
    goto L1D; // [859] 892

    /** buildsys.e:923				ShowMsg(1, LINKING_100_1, { abbreviate_path(exe_name[D_NAME]) })*/
    _2 = (object)SEQ_PTR(_55exe_name_45452);
    _24198 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_24198);
    RefDS(_22024);
    _24199 = _14abbreviate_path(_24198, _22024);
    _24198 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24199;
    _24200 = MAKE_SEQ(_1);
    _24199 = NOVALUE;
    _30ShowMsg(1LL, 166LL, _24200, 1LL);
    _24200 = NOVALUE;
    goto L1E; // [889] 909
L1D: 

    /** buildsys.e:925				ShowMsg(1, LINKING_100_1, { cmd })*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_cmd_46296);
    ((intptr_t*)_2)[1] = _cmd_46296;
    _24201 = MAKE_SEQ(_1);
    _30ShowMsg(1LL, 166LL, _24201, 1LL);
    _24201 = NOVALUE;
L1E: 
L1C: 

    /** buildsys.e:929		status = system_exec(cmd, 0)*/
    _status_46303 = system_exec_call(_cmd_46296, 0LL);

    /** buildsys.e:930		if status != 0 then*/
    if (_status_46303 == 0LL)
    goto L1F; // [920] 967

    /** buildsys.e:931			ShowMsg(2, UNABLE_TO_LINK_1, { exe_name[D_NAME] })*/
    _2 = (object)SEQ_PTR(_55exe_name_45452);
    _24204 = (object)*(((s1_ptr)_2)->base + 1LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24204);
    ((intptr_t*)_2)[1] = _24204;
    _24205 = MAKE_SEQ(_1);
    _24204 = NOVALUE;
    _30ShowMsg(2LL, 168LL, _24205, 1LL);
    _24205 = NOVALUE;

    /** buildsys.e:932			ShowMsg(2, STATUS_1_COMMAND_2_A, { status, cmd })*/
    RefDS(_cmd_46296);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _status_46303;
    ((intptr_t *)_2)[2] = _cmd_46296;
    _24206 = MAKE_SEQ(_1);
    _30ShowMsg(2LL, 169LL, _24206, 1LL);
    _24206 = NOVALUE;

    /** buildsys.e:934			goto "build_direct_cleanup"*/
    goto GF;
L1F: 

    /** buildsys.e:938		if length(rc_file[D_ALTNAME]) and length(settings[SETUP_RC_COMPILER]) and compiler_type = COMPILER_WATCOM then*/
    _2 = (object)SEQ_PTR(_55rc_file_45458);
    _24207 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (IS_SEQUENCE(_24207)){
            _24208 = SEQ_PTR(_24207)->length;
    }
    else {
        _24208 = 1;
    }
    _24207 = NOVALUE;
    if (_24208 == 0) {
        _24209 = 0;
        goto L20; // [980] 995
    }
    _2 = (object)SEQ_PTR(_settings_46298);
    _24210 = (object)*(((s1_ptr)_2)->base + 8LL);
    if (IS_SEQUENCE(_24210)){
            _24211 = SEQ_PTR(_24210)->length;
    }
    else {
        _24211 = 1;
    }
    _24210 = NOVALUE;
    _24209 = (_24211 != 0);
L20: 
    if (_24209 == 0) {
        goto L21; // [995] 1118
    }
    _24213 = (0LL == 2LL);
    if (_24213 == 0)
    {
        DeRef(_24213);
        _24213 = NOVALUE;
        goto L21; // [1006] 1118
    }
    else{
        DeRef(_24213);
        _24213 = NOVALUE;
    }

    /** buildsys.e:939			cmd = text:format(settings[SETUP_RC_COMPILER], { rc_file[D_ALTNAME], res_file[D_ALTNAME], exe_name[D_ALTNAME] })*/
    _2 = (object)SEQ_PTR(_settings_46298);
    _24214 = (object)*(((s1_ptr)_2)->base + 8LL);
    _2 = (object)SEQ_PTR(_55rc_file_45458);
    _24215 = (object)*(((s1_ptr)_2)->base + 11LL);
    _2 = (object)SEQ_PTR(_55res_file_45464);
    _24216 = (object)*(((s1_ptr)_2)->base + 11LL);
    _2 = (object)SEQ_PTR(_55exe_name_45452);
    _24217 = (object)*(((s1_ptr)_2)->base + 11LL);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_24215);
    ((intptr_t*)_2)[1] = _24215;
    RefDS(_24216);
    ((intptr_t*)_2)[2] = _24216;
    Ref(_24217);
    ((intptr_t*)_2)[3] = _24217;
    _24218 = MAKE_SEQ(_1);
    _24217 = NOVALUE;
    _24216 = NOVALUE;
    _24215 = NOVALUE;
    Ref(_24214);
    _0 = _cmd_46296;
    _cmd_46296 = _18format(_24214, _24218);
    DeRef(_0);
    _24214 = NOVALUE;
    _24218 = NOVALUE;

    /** buildsys.e:940			status = system_exec(cmd, 0)*/
    _status_46303 = system_exec_call(_cmd_46296, 0LL);

    /** buildsys.e:941			if status != 0 then*/
    if (_status_46303 == 0LL)
    goto L22; // [1060] 1117

    /** buildsys.e:942				ShowMsg(2, UNABLE_TO_LINK_RESOURCE_FILE_1_INTO_EXECUTABLE_2, { rc_file[D_NAME], exe_name[D_NAME] })*/
    _2 = (object)SEQ_PTR(_55rc_file_45458);
    _24222 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_55exe_name_45452);
    _24223 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_24223);
    RefDS(_24222);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24222;
    ((intptr_t *)_2)[2] = _24223;
    _24224 = MAKE_SEQ(_1);
    _24223 = NOVALUE;
    _24222 = NOVALUE;
    _30ShowMsg(2LL, 187LL, _24224, 1LL);
    _24224 = NOVALUE;

    /** buildsys.e:943				ShowMsg(2, STATUS_1_COMMAND_2_A, { status, cmd })*/
    RefDS(_cmd_46296);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _status_46303;
    ((intptr_t *)_2)[2] = _cmd_46296;
    _24225 = MAKE_SEQ(_1);
    _30ShowMsg(2LL, 169LL, _24225, 1LL);
    _24225 = NOVALUE;

    /** buildsys.e:945				goto "build_direct_cleanup"*/
    goto GF;
L22: 
L21: 

    /** buildsys.e:949	label "build_direct_cleanup"*/
GF:

    /** buildsys.e:950		if keep = 0 then*/
    if (_57keep_42619 != 0LL)
    goto L23; // [1126] 1277

    /** buildsys.e:951			for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_42616)){
            _24227 = SEQ_PTR(_57generated_files_42616)->length;
    }
    else {
        _24227 = 1;
    }
    {
        object _i_46554;
        _i_46554 = 1LL;
L24: 
        if (_i_46554 > _24227){
            goto L25; // [1137] 1193
        }

        /** buildsys.e:952				if verbose then*/
        if (_12verbose_20345 == 0)
        {
            goto L26; // [1148] 1172
        }
        else{
        }

        /** buildsys.e:953					ShowMsg(1, DELETING_1, { generated_files[i] })*/
        _2 = (object)SEQ_PTR(_57generated_files_42616);
        _24228 = (object)*(((s1_ptr)_2)->base + _i_46554);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24228);
        ((intptr_t*)_2)[1] = _24228;
        _24229 = MAKE_SEQ(_1);
        _24228 = NOVALUE;
        _30ShowMsg(1LL, 347LL, _24229, 1LL);
        _24229 = NOVALUE;
L26: 

        /** buildsys.e:955				delete_file(generated_files[i])*/
        _2 = (object)SEQ_PTR(_57generated_files_42616);
        _24230 = (object)*(((s1_ptr)_2)->base + _i_46554);
        RefDS(_24230);
        _31798 = _14delete_file(_24230);
        _24230 = NOVALUE;
        DeRef(_31798);
        _31798 = NOVALUE;

        /** buildsys.e:956			end for*/
        _i_46554 = _i_46554 + 1LL;
        goto L24; // [1188] 1144
L25: 
        ;
    }

    /** buildsys.e:958			if length(res_file[D_ALTNAME]) then*/
    _2 = (object)SEQ_PTR(_55res_file_45464);
    _24231 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (IS_SEQUENCE(_24231)){
            _24232 = SEQ_PTR(_24231)->length;
    }
    else {
        _24232 = 1;
    }
    _24231 = NOVALUE;
    if (_24232 == 0)
    {
        _24232 = NOVALUE;
        goto L27; // [1206] 1226
    }
    else{
        _24232 = NOVALUE;
    }

    /** buildsys.e:959				delete_file(res_file[D_ALTNAME])*/
    _2 = (object)SEQ_PTR(_55res_file_45464);
    _24233 = (object)*(((s1_ptr)_2)->base + 11LL);
    RefDS(_24233);
    _31797 = _14delete_file(_24233);
    _24233 = NOVALUE;
    DeRef(_31797);
    _31797 = NOVALUE;
L27: 

    /** buildsys.e:962			if remove_output_dir then*/
L23: 

    /** buildsys.e:972		chdir(cwd)*/
    RefDS(_cwd_46300);
    _31795 = _14chdir(_cwd_46300);
    DeRef(_31795);
    _31795 = NOVALUE;

    /** buildsys.e:973	end procedure*/
    DeRefDS(_the_file0_46290);
    DeRef(_cmd_46296);
    DeRef(_objs_46297);
    DeRef(_settings_46298);
    DeRefDS(_cwd_46300);
    DeRef(_link_files_46334);
    _24207 = NOVALUE;
    _24164 = NOVALUE;
    _24167 = NOVALUE;
    _24210 = NOVALUE;
    DeRef(_24130);
    _24130 = NOVALUE;
    DeRef(_24158);
    _24158 = NOVALUE;
    _24231 = NOVALUE;
    return;
    ;
}


void _55write_buildfile()
{
    object _make_command_46596 = NOVALUE;
    object _settings_46641 = NOVALUE;
    object _24260 = NOVALUE;
    object _24259 = NOVALUE;
    object _24255 = NOVALUE;
    object _24254 = NOVALUE;
    object _24253 = NOVALUE;
    object _24251 = NOVALUE;
    object _24250 = NOVALUE;
    object _24249 = NOVALUE;
    object _24248 = NOVALUE;
    object _24247 = NOVALUE;
    object _24246 = NOVALUE;
    object _24245 = NOVALUE;
    object _24244 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:982		switch build_system_type do*/
    _0 = 3LL;
    switch ( _0 ){ 

        /** buildsys.e:983			case BUILD_MAKEFILE_FULL then*/
        case 2:

        /** buildsys.e:984				write_makefile_full()*/
        _55write_makefile_full();

        /** buildsys.e:986				if not silent then*/
        if (_12silent_20342 != 0)
        goto L1; // [22] 142

        /** buildsys.e:987					sequence make_command*/

        /** buildsys.e:988					if compiler_type = COMPILER_WATCOM then*/

        /** buildsys.e:991						make_command = "make -f "*/
        RefDS(_24243);
        DeRefi(_make_command_46596);
        _make_command_46596 = _24243;

        /** buildsys.e:994					ShowMsg(1, MSG_1C_FILES_WERE_CREATED, { cfile_count + 2 })*/
        _24244 = _12cfile_count_20305 + 2LL;
        if ((object)((uintptr_t)_24244 + (uintptr_t)HIGH_BITS) >= 0){
            _24244 = NewDouble((eudouble)_24244);
        }
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _24244;
        _24245 = MAKE_SEQ(_1);
        _24244 = NOVALUE;
        _30ShowMsg(1LL, 170LL, _24245, 1LL);
        _24245 = NOVALUE;

        /** buildsys.e:996					if sequence(output_dir) and length(output_dir) > 0 then*/
        _24246 = 1;
        if (_24246 == 0) {
            goto L2; // [80] 122
        }
        _24248 = 0;
        _24249 = (0LL > 0LL);
        _24248 = NOVALUE;
        if (_24249 == 0)
        {
            DeRef(_24249);
            _24249 = NOVALUE;
            goto L2; // [94] 122
        }
        else{
            DeRef(_24249);
            _24249 = NOVALUE;
        }

        /** buildsys.e:997						ShowMsg(1, TO_BUILD_YOUR_PROJECT_CHANGE_DIRECTORY_TO_1_AND_TYPE_23MAK, { output_dir, make_command, file0 })*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_57output_dir_42626);
        ((intptr_t*)_2)[1] = _57output_dir_42626;
        RefDS(_make_command_46596);
        ((intptr_t*)_2)[2] = _make_command_46596;
        RefDS(_57file0_44585);
        ((intptr_t*)_2)[3] = _57file0_44585;
        _24250 = MAKE_SEQ(_1);
        _30ShowMsg(1LL, 174LL, _24250, 1LL);
        _24250 = NOVALUE;
        goto L3; // [119] 141
L2: 

        /** buildsys.e:999						ShowMsg(1, TO_BUILD_YOUR_PROJECT_TYPE_12MAK, { make_command, file0 })*/
        RefDS(_57file0_44585);
        RefDS(_make_command_46596);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _make_command_46596;
        ((intptr_t *)_2)[2] = _57file0_44585;
        _24251 = MAKE_SEQ(_1);
        _30ShowMsg(1LL, 172LL, _24251, 1LL);
        _24251 = NOVALUE;
L3: 
L1: 
        DeRefi(_make_command_46596);
        _make_command_46596 = NOVALUE;
        goto L4; // [144] 277

        /** buildsys.e:1003			case BUILD_MAKEFILE_PARTIAL then*/
        case 1:

        /** buildsys.e:1004				write_makefile_partial()*/
        _55write_makefile_partial();

        /** buildsys.e:1006				if not silent then*/
        if (_12silent_20342 != 0)
        goto L4; // [158] 277

        /** buildsys.e:1007					ShowMsg(1, MSG_1C_FILES_WERE_CREATED, { cfile_count + 2 })*/
        _24253 = _12cfile_count_20305 + 2LL;
        if ((object)((uintptr_t)_24253 + (uintptr_t)HIGH_BITS) >= 0){
            _24253 = NewDouble((eudouble)_24253);
        }
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _24253;
        _24254 = MAKE_SEQ(_1);
        _24253 = NOVALUE;
        _30ShowMsg(1LL, 170LL, _24254, 1LL);
        _24254 = NOVALUE;

        /** buildsys.e:1008					ShowMsg(1, TO_BUILD_YOUR_PROJECT_INCLUDE_1MAK_INTO_A_LARGER_MAKEFILE_PROJECT, { file0 })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_57file0_44585);
        ((intptr_t*)_2)[1] = _57file0_44585;
        _24255 = MAKE_SEQ(_1);
        _30ShowMsg(1LL, 173LL, _24255, 1LL);
        _24255 = NOVALUE;
        goto L4; // [198] 277

        /** buildsys.e:1011			case BUILD_DIRECT then*/
        case 3:

        /** buildsys.e:1012				build_direct()*/
        RefDS(_22024);
        _55build_direct(0LL, _22024);

        /** buildsys.e:1014				if not silent then*/
        if (_12silent_20342 != 0)
        goto L5; // [214] 225

        /** buildsys.e:1015					sequence settings = setup_build()*/
        _0 = _settings_46641;
        _settings_46641 = _55setup_build();
        DeRef(_0);
L5: 
        DeRef(_settings_46641);
        _settings_46641 = NOVALUE;
        goto L4; // [227] 277

        /** buildsys.e:1019			case BUILD_NONE then*/
        case 0:

        /** buildsys.e:1020				if not silent then*/
        if (_12silent_20342 != 0)
        goto L4; // [237] 277

        /** buildsys.e:1021					ShowMsg(1, MSG_1C_FILES_WERE_CREATED, { cfile_count + 2 })*/
        _24259 = _12cfile_count_20305 + 2LL;
        if ((object)((uintptr_t)_24259 + (uintptr_t)HIGH_BITS) >= 0){
            _24259 = NewDouble((eudouble)_24259);
        }
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _24259;
        _24260 = MAKE_SEQ(_1);
        _24259 = NOVALUE;
        _30ShowMsg(1LL, 170LL, _24260, 1LL);
        _24260 = NOVALUE;
        goto L4; // [261] 277

        /** buildsys.e:1026			case else*/
        default:

        /** buildsys.e:1027				CompileErr(UNKNOWN_BUILD_FILE_TYPE)*/
        RefDS(_22024);
        _49CompileErr(151LL, _22024, 0LL);
    ;}L4: 

    /** buildsys.e:1029	end procedure*/
    return;
    ;
}



// 0x2081308A
