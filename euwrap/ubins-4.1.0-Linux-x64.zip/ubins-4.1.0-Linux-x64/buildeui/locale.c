// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _31get_text(object _MsgNum_18401, object _LocalQuals_18402, object _DBBase_18403)
{
    object _db_res_18405 = NOVALUE;
    object _lMsgText_18406 = NOVALUE;
    object _dbname_18407 = NOVALUE;
    object _10271 = NOVALUE;
    object _10269 = NOVALUE;
    object _10267 = NOVALUE;
    object _10266 = NOVALUE;
    object _10265 = NOVALUE;
    object _10263 = NOVALUE;
    object _10262 = NOVALUE;
    object _10261 = NOVALUE;
    object _10255 = NOVALUE;
    object _10254 = NOVALUE;
    object _10253 = NOVALUE;
    object _10246 = NOVALUE;
    object _10243 = NOVALUE;
    object _10241 = NOVALUE;
    object _10239 = NOVALUE;
    object _10238 = NOVALUE;
    object _10237 = NOVALUE;
    object _10236 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_MsgNum_18401)) {
        _1 = (object)(DBL_PTR(_MsgNum_18401)->dbl);
        DeRefDS(_MsgNum_18401);
        _MsgNum_18401 = _1;
    }

    /** locale.e:798		db_res = -1*/
    _db_res_18405 = -1LL;

    /** locale.e:799		lMsgText = 0*/
    DeRef(_lMsgText_18406);
    _lMsgText_18406 = 0LL;

    /** locale.e:801		if string(LocalQuals) and length(LocalQuals) > 0 then*/
    RefDS(_LocalQuals_18402);
    _10236 = _9string(_LocalQuals_18402);
    if (IS_ATOM_INT(_10236)) {
        if (_10236 == 0) {
            goto L1; // [23] 45
        }
    }
    else {
        if (DBL_PTR(_10236)->dbl == 0.0) {
            goto L1; // [23] 45
        }
    }
    if (IS_SEQUENCE(_LocalQuals_18402)){
            _10238 = SEQ_PTR(_LocalQuals_18402)->length;
    }
    else {
        _10238 = 1;
    }
    _10239 = (_10238 > 0LL);
    _10238 = NOVALUE;
    if (_10239 == 0)
    {
        DeRef(_10239);
        _10239 = NOVALUE;
        goto L1; // [35] 45
    }
    else{
        DeRef(_10239);
        _10239 = NOVALUE;
    }

    /** locale.e:802			LocalQuals = {LocalQuals}*/
    _0 = _LocalQuals_18402;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_LocalQuals_18402);
    ((intptr_t*)_2)[1] = _LocalQuals_18402;
    _LocalQuals_18402 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1: 

    /** locale.e:804		for i = 1 to length(LocalQuals) do*/
    if (IS_SEQUENCE(_LocalQuals_18402)){
            _10241 = SEQ_PTR(_LocalQuals_18402)->length;
    }
    else {
        _10241 = 1;
    }
    {
        object _i_18416;
        _i_18416 = 1LL;
L2: 
        if (_i_18416 > _10241){
            goto L3; // [50] 136
        }

        /** locale.e:805			dbname = DBBase & "_" & LocalQuals[i] & ".edb"*/
        _2 = (object)SEQ_PTR(_LocalQuals_18402);
        _10243 = (object)*(((s1_ptr)_2)->base + _i_18416);
        {
            object concat_list[4];

            concat_list[0] = _10244;
            concat_list[1] = _10243;
            concat_list[2] = _10242;
            concat_list[3] = _DBBase_18403;
            Concat_N((object_ptr)&_dbname_18407, concat_list, 4);
        }
        _10243 = NOVALUE;

        /** locale.e:806			db_res = eds:db_select( filesys:locate_file( dbname ), eds:DB_LOCK_READ_ONLY)*/
        RefDS(_dbname_18407);
        RefDS(_5);
        RefDS(_5);
        _10246 = _14locate_file(_dbname_18407, _5, _5);
        _db_res_18405 = _41db_select(_10246, 3LL);
        _10246 = NOVALUE;
        if (!IS_ATOM_INT(_db_res_18405)) {
            _1 = (object)(DBL_PTR(_db_res_18405)->dbl);
            DeRefDS(_db_res_18405);
            _db_res_18405 = _1;
        }

        /** locale.e:807			if db_res = eds:DB_OK then*/
        if (_db_res_18405 != 0LL)
        goto L4; // [87] 129

        /** locale.e:808				db_res = eds:db_select_table("1")*/
        RefDS(_10249);
        _db_res_18405 = _41db_select_table(_10249);
        if (!IS_ATOM_INT(_db_res_18405)) {
            _1 = (object)(DBL_PTR(_db_res_18405)->dbl);
            DeRefDS(_db_res_18405);
            _db_res_18405 = _1;
        }

        /** locale.e:809				if db_res = eds:DB_OK then*/
        if (_db_res_18405 != 0LL)
        goto L5; // [101] 128

        /** locale.e:810					lMsgText = eds:db_fetch_record(MsgNum)*/
        RefDS(_41current_table_name_15729);
        _0 = _lMsgText_18406;
        _lMsgText_18406 = _41db_fetch_record(_MsgNum_18401, _41current_table_name_15729);
        DeRef(_0);

        /** locale.e:811					if sequence(lMsgText) then*/
        _10253 = IS_SEQUENCE(_lMsgText_18406);
        if (_10253 == 0)
        {
            _10253 = NOVALUE;
            goto L6; // [119] 127
        }
        else{
            _10253 = NOVALUE;
        }

        /** locale.e:812						exit*/
        goto L3; // [124] 136
L6: 
L5: 
L4: 

        /** locale.e:816		end for*/
        _i_18416 = _i_18416 + 1LL;
        goto L2; // [131] 57
L3: 
        ;
    }

    /** locale.e:819		if atom(lMsgText) then*/
    _10254 = IS_ATOM(_lMsgText_18406);
    if (_10254 == 0)
    {
        _10254 = NOVALUE;
        goto L7; // [141] 281
    }
    else{
        _10254 = NOVALUE;
    }

    /** locale.e:820			dbname = filesys:locate_file( DBBase & ".edb" )*/
    Concat((object_ptr)&_10255, _DBBase_18403, _10244);
    RefDS(_5);
    RefDS(_5);
    _0 = _dbname_18407;
    _dbname_18407 = _14locate_file(_10255, _5, _5);
    DeRef(_0);
    _10255 = NOVALUE;

    /** locale.e:821			db_res = eds:db_select(	dbname, DB_LOCK_READ_ONLY)*/
    RefDS(_dbname_18407);
    _db_res_18405 = _41db_select(_dbname_18407, 3LL);
    if (!IS_ATOM_INT(_db_res_18405)) {
        _1 = (object)(DBL_PTR(_db_res_18405)->dbl);
        DeRefDS(_db_res_18405);
        _db_res_18405 = _1;
    }

    /** locale.e:822			if db_res = eds:DB_OK then*/
    if (_db_res_18405 != 0LL)
    goto L8; // [171] 280

    /** locale.e:823				db_res = eds:db_select_table("1")*/
    RefDS(_10249);
    _db_res_18405 = _41db_select_table(_10249);
    if (!IS_ATOM_INT(_db_res_18405)) {
        _1 = (object)(DBL_PTR(_db_res_18405)->dbl);
        DeRefDS(_db_res_18405);
        _db_res_18405 = _1;
    }

    /** locale.e:824				if db_res = eds:DB_OK then*/
    if (_db_res_18405 != 0LL)
    goto L9; // [185] 279

    /** locale.e:825					for i = 1 to length(LocalQuals) do*/
    if (IS_SEQUENCE(_LocalQuals_18402)){
            _10261 = SEQ_PTR(_LocalQuals_18402)->length;
    }
    else {
        _10261 = 1;
    }
    {
        object _i_18445;
        _i_18445 = 1LL;
LA: 
        if (_i_18445 > _10261){
            goto LB; // [194] 238
        }

        /** locale.e:826						lMsgText = eds:db_fetch_record({LocalQuals[i],MsgNum})*/
        _2 = (object)SEQ_PTR(_LocalQuals_18402);
        _10262 = (object)*(((s1_ptr)_2)->base + _i_18445);
        Ref(_10262);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _10262;
        ((intptr_t *)_2)[2] = _MsgNum_18401;
        _10263 = MAKE_SEQ(_1);
        _10262 = NOVALUE;
        RefDS(_41current_table_name_15729);
        _0 = _lMsgText_18406;
        _lMsgText_18406 = _41db_fetch_record(_10263, _41current_table_name_15729);
        DeRef(_0);
        _10263 = NOVALUE;

        /** locale.e:827						if sequence(lMsgText) then*/
        _10265 = IS_SEQUENCE(_lMsgText_18406);
        if (_10265 == 0)
        {
            _10265 = NOVALUE;
            goto LC; // [223] 231
        }
        else{
            _10265 = NOVALUE;
        }

        /** locale.e:828							exit*/
        goto LB; // [228] 238
LC: 

        /** locale.e:830					end for*/
        _i_18445 = _i_18445 + 1LL;
        goto LA; // [233] 201
LB: 
        ;
    }

    /** locale.e:831					if atom(lMsgText) then*/
    _10266 = IS_ATOM(_lMsgText_18406);
    if (_10266 == 0)
    {
        _10266 = NOVALUE;
        goto LD; // [243] 260
    }
    else{
        _10266 = NOVALUE;
    }

    /** locale.e:832						lMsgText = eds:db_fetch_record({"",MsgNum})*/
    RefDS(_5);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _5;
    ((intptr_t *)_2)[2] = _MsgNum_18401;
    _10267 = MAKE_SEQ(_1);
    RefDS(_41current_table_name_15729);
    _0 = _lMsgText_18406;
    _lMsgText_18406 = _41db_fetch_record(_10267, _41current_table_name_15729);
    DeRef(_0);
    _10267 = NOVALUE;
LD: 

    /** locale.e:834					if atom(lMsgText) then*/
    _10269 = IS_ATOM(_lMsgText_18406);
    if (_10269 == 0)
    {
        _10269 = NOVALUE;
        goto LE; // [265] 278
    }
    else{
        _10269 = NOVALUE;
    }

    /** locale.e:835						lMsgText = eds:db_fetch_record(MsgNum)*/
    RefDS(_41current_table_name_15729);
    _0 = _lMsgText_18406;
    _lMsgText_18406 = _41db_fetch_record(_MsgNum_18401, _41current_table_name_15729);
    DeRef(_0);
LE: 
L9: 
L8: 
L7: 

    /** locale.e:840		if atom(lMsgText) then*/
    _10271 = IS_ATOM(_lMsgText_18406);
    if (_10271 == 0)
    {
        _10271 = NOVALUE;
        goto LF; // [286] 298
    }
    else{
        _10271 = NOVALUE;
    }

    /** locale.e:841			return 0*/
    DeRefDS(_LocalQuals_18402);
    DeRefDS(_DBBase_18403);
    DeRef(_lMsgText_18406);
    DeRef(_dbname_18407);
    DeRef(_10236);
    _10236 = NOVALUE;
    return 0LL;
    goto L10; // [295] 305
LF: 

    /** locale.e:843			return lMsgText*/
    DeRefDS(_LocalQuals_18402);
    DeRefDS(_DBBase_18403);
    DeRef(_dbname_18407);
    DeRef(_10236);
    _10236 = NOVALUE;
    return _lMsgText_18406;
L10: 
    ;
}



// 0x821FF03E
