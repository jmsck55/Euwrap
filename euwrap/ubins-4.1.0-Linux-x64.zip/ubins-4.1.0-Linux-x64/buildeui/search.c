// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _20find_all(object _needle_1775, object _haystack_1776, object _start_1777)
{
    object _kx_1778 = NOVALUE;
    object _757 = NOVALUE;
    object _756 = NOVALUE;
    object _0, _1, _2;
    

    /** search.e:292		integer kx = 0*/
    _kx_1778 = 0LL;

    /** search.e:293		while start with entry do*/
    goto L1; // [12] 39
L2: 
    if (_start_1777 == 0)
    {
        goto L3; // [15] 51
    }
    else{
    }

    /** search.e:294			kx += 1*/
    _kx_1778 = _kx_1778 + 1;

    /** search.e:295			haystack[kx] = start*/
    _2 = (object)SEQ_PTR(_haystack_1776);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _haystack_1776 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _kx_1778);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _start_1777;
    DeRef(_1);

    /** search.e:296			start += 1*/
    _start_1777 = _start_1777 + 1;

    /** search.e:297		entry*/
L1: 

    /** search.e:298			start = find(needle, haystack, start)*/
    _start_1777 = find_from(_needle_1775, _haystack_1776, _start_1777);

    /** search.e:299		end while*/
    goto L2; // [48] 15
L3: 

    /** search.e:301		haystack = remove( haystack, kx+1, length( haystack ) )*/
    _756 = _kx_1778 + 1;
    if (_756 > MAXINT){
        _756 = NewDouble((eudouble)_756);
    }
    if (IS_SEQUENCE(_haystack_1776)){
            _757 = SEQ_PTR(_haystack_1776)->length;
    }
    else {
        _757 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_haystack_1776);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_756)) ? _756 : (object)(DBL_PTR(_756)->dbl);
        int stop = (IS_ATOM_INT(_757)) ? _757 : (object)(DBL_PTR(_757)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_haystack_1776), start, &_haystack_1776 );
            }
            else Tail(SEQ_PTR(_haystack_1776), stop+1, &_haystack_1776);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_haystack_1776), start, &_haystack_1776);
        }
        else {
            assign_slice_seq = &assign_space;
            _haystack_1776 = Remove_elements(start, stop, (SEQ_PTR(_haystack_1776)->ref == 1));
        }
    }
    DeRef(_756);
    _756 = NOVALUE;
    _757 = NOVALUE;

    /** search.e:302		return haystack*/
    return _haystack_1776;
    ;
}


object _20rfind(object _needle_1893, object _haystack_1894, object _start_1895)
{
    object _len_1897 = NOVALUE;
    object _818 = NOVALUE;
    object _817 = NOVALUE;
    object _814 = NOVALUE;
    object _813 = NOVALUE;
    object _811 = NOVALUE;
    object _0, _1, _2;
    

    /** search.e:550		integer len = length(haystack)*/
    if (IS_SEQUENCE(_haystack_1894)){
            _len_1897 = SEQ_PTR(_haystack_1894)->length;
    }
    else {
        _len_1897 = 1;
    }

    /** search.e:552		if start = 0 then start = len end if*/
    if (_start_1895 != 0LL)
    goto L1; // [12] 20
    _start_1895 = _len_1897;
L1: 

    /** search.e:553		if (start > len) or (len + start < 1) then*/
    _811 = (_start_1895 > _len_1897);
    if (_811 != 0) {
        goto L2; // [26] 43
    }
    _813 = _len_1897 + _start_1895;
    if ((object)((uintptr_t)_813 + (uintptr_t)HIGH_BITS) >= 0){
        _813 = NewDouble((eudouble)_813);
    }
    if (IS_ATOM_INT(_813)) {
        _814 = (_813 < 1LL);
    }
    else {
        _814 = (DBL_PTR(_813)->dbl < (eudouble)1LL);
    }
    DeRef(_813);
    _813 = NOVALUE;
    if (_814 == 0)
    {
        DeRef(_814);
        _814 = NOVALUE;
        goto L3; // [39] 50
    }
    else{
        DeRef(_814);
        _814 = NOVALUE;
    }
L2: 

    /** search.e:554			return 0*/
    DeRef(_needle_1893);
    DeRefDS(_haystack_1894);
    DeRef(_811);
    _811 = NOVALUE;
    return 0LL;
L3: 

    /** search.e:557		if start < 1 then*/
    if (_start_1895 >= 1LL)
    goto L4; // [52] 63

    /** search.e:558			start = len + start*/
    _start_1895 = _len_1897 + _start_1895;
L4: 

    /** search.e:561		for i = start to 1 by -1 do*/
    {
        object _i_1910;
        _i_1910 = _start_1895;
L5: 
        if (_i_1910 < 1LL){
            goto L6; // [65] 99
        }

        /** search.e:562			if equal(haystack[i], needle) then*/
        _2 = (object)SEQ_PTR(_haystack_1894);
        _817 = (object)*(((s1_ptr)_2)->base + _i_1910);
        if (_817 == _needle_1893)
        _818 = 1;
        else if (IS_ATOM_INT(_817) && IS_ATOM_INT(_needle_1893))
        _818 = 0;
        else
        _818 = (compare(_817, _needle_1893) == 0);
        _817 = NOVALUE;
        if (_818 == 0)
        {
            _818 = NOVALUE;
            goto L7; // [82] 92
        }
        else{
            _818 = NOVALUE;
        }

        /** search.e:563				return i*/
        DeRef(_needle_1893);
        DeRefDS(_haystack_1894);
        DeRef(_811);
        _811 = NOVALUE;
        return _i_1910;
L7: 

        /** search.e:565		end for*/
        _i_1910 = _i_1910 + -1LL;
        goto L5; // [94] 72
L6: 
        ;
    }

    /** search.e:567		return 0*/
    DeRef(_needle_1893);
    DeRefDS(_haystack_1894);
    DeRef(_811);
    _811 = NOVALUE;
    return 0LL;
    ;
}


object _20find_replace(object _needle_1916, object _haystack_1917, object _replacement_1918, object _max_1919)
{
    object _posn_1920 = NOVALUE;
    object _822 = NOVALUE;
    object _0, _1, _2;
    

    /** search.e:612		integer posn = 0*/
    _posn_1920 = 0LL;

    /** search.e:614		while posn != 0 entry do */
    goto L1; // [12] 45
L2: 
    if (_posn_1920 == 0LL)
    goto L3; // [15] 61

    /** search.e:615			haystack[posn] = replacement*/
    Ref(_replacement_1918);
    _2 = (object)SEQ_PTR(_haystack_1917);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _haystack_1917 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _posn_1920);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _replacement_1918;
    DeRef(_1);

    /** search.e:616			max -= 1*/
    _max_1919 = _max_1919 - 1LL;

    /** search.e:617			if max = 0 then*/
    if (_max_1919 != 0LL)
    goto L4; // [33] 42

    /** search.e:618				exit*/
    goto L3; // [39] 61
L4: 

    /** search.e:620		entry*/
L1: 

    /** search.e:621			posn = find(needle, haystack, posn + 1)*/
    _822 = _posn_1920 + 1;
    if (_822 > MAXINT){
        _822 = NewDouble((eudouble)_822);
    }
    _posn_1920 = find_from(_needle_1916, _haystack_1917, _822);
    DeRef(_822);
    _822 = NOVALUE;

    /** search.e:622		end while*/
    goto L2; // [58] 15
L3: 

    /** search.e:624		return haystack*/
    DeRef(_needle_1916);
    DeRefi(_replacement_1918);
    return _haystack_1917;
    ;
}


object _20match_replace(object _needle_1930, object _haystack_1931, object _replacement_1932, object _max_1933)
{
    object _posn_1934 = NOVALUE;
    object _needle_len_1935 = NOVALUE;
    object _replacement_len_1936 = NOVALUE;
    object _scan_from_1937 = NOVALUE;
    object _cnt_1938 = NOVALUE;
    object _834 = NOVALUE;
    object _831 = NOVALUE;
    object _829 = NOVALUE;
    object _827 = NOVALUE;
    object _0, _1, _2;
    

    /** search.e:692		if max < 0 then*/

    /** search.e:696		cnt = length(haystack)*/
    if (IS_SEQUENCE(_haystack_1931)){
            _cnt_1938 = SEQ_PTR(_haystack_1931)->length;
    }
    else {
        _cnt_1938 = 1;
    }

    /** search.e:697		if max != 0 then*/

    /** search.e:701		if atom(needle) then*/
    _827 = IS_ATOM(_needle_1930);
    if (_827 == 0)
    {
        _827 = NOVALUE;
        goto L1; // [40] 50
    }
    else{
        _827 = NOVALUE;
    }

    /** search.e:702			needle = {needle}*/
    _0 = _needle_1930;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_needle_1930);
    ((intptr_t*)_2)[1] = _needle_1930;
    _needle_1930 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** search.e:704		if atom(replacement) then*/
    _829 = IS_ATOM(_replacement_1932);
    if (_829 == 0)
    {
        _829 = NOVALUE;
        goto L2; // [55] 65
    }
    else{
        _829 = NOVALUE;
    }

    /** search.e:705			replacement = {replacement}*/
    _0 = _replacement_1932;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_replacement_1932);
    ((intptr_t*)_2)[1] = _replacement_1932;
    _replacement_1932 = MAKE_SEQ(_1);
    DeRef(_0);
L2: 

    /** search.e:708		needle_len = length(needle) - 1*/
    if (IS_SEQUENCE(_needle_1930)){
            _831 = SEQ_PTR(_needle_1930)->length;
    }
    else {
        _831 = 1;
    }
    _needle_len_1935 = _831 - 1LL;
    _831 = NOVALUE;

    /** search.e:709		replacement_len = length(replacement)*/
    if (IS_SEQUENCE(_replacement_1932)){
            _replacement_len_1936 = SEQ_PTR(_replacement_1932)->length;
    }
    else {
        _replacement_len_1936 = 1;
    }

    /** search.e:711		scan_from = 1*/
    _scan_from_1937 = 1LL;

    /** search.e:712		while posn with entry do*/
    goto L3; // [86] 132
L4: 
    if (_posn_1934 == 0)
    {
        goto L5; // [91] 144
    }
    else{
    }

    /** search.e:713			haystack = replace(haystack, replacement, posn, posn + needle_len)*/
    _834 = _posn_1934 + _needle_len_1935;
    if ((object)((uintptr_t)_834 + (uintptr_t)HIGH_BITS) >= 0){
        _834 = NewDouble((eudouble)_834);
    }
    {
        intptr_t p1 = _haystack_1931;
        intptr_t p2 = _replacement_1932;
        intptr_t p3 = _posn_1934;
        intptr_t p4 = _834;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_haystack_1931;
        Replace( &replace_params );
    }
    DeRef(_834);
    _834 = NOVALUE;

    /** search.e:715			cnt -= 1*/
    _cnt_1938 = _cnt_1938 - 1LL;

    /** search.e:716			if cnt = 0 then*/
    if (_cnt_1938 != 0LL)
    goto L6; // [114] 123

    /** search.e:717				exit*/
    goto L5; // [120] 144
L6: 

    /** search.e:719			scan_from = posn + replacement_len*/
    _scan_from_1937 = _posn_1934 + _replacement_len_1936;

    /** search.e:720		entry*/
L3: 

    /** search.e:721			posn = match(needle, haystack, scan_from)*/
    _posn_1934 = e_match_from(_needle_1930, _haystack_1931, _scan_from_1937);

    /** search.e:722		end while*/
    goto L4; // [141] 89
L5: 

    /** search.e:724		return haystack*/
    DeRef(_needle_1930);
    DeRef(_replacement_1932);
    return _haystack_1931;
    ;
}


object _20begins(object _sub_text_2051, object _full_text_2052)
{
    object _898 = NOVALUE;
    object _897 = NOVALUE;
    object _896 = NOVALUE;
    object _894 = NOVALUE;
    object _893 = NOVALUE;
    object _892 = NOVALUE;
    object _891 = NOVALUE;
    object _890 = NOVALUE;
    object _888 = NOVALUE;
    object _0, _1, _2;
    

    /** search.e:976		if length(full_text) = 0 then*/
    if (IS_SEQUENCE(_full_text_2052)){
            _888 = SEQ_PTR(_full_text_2052)->length;
    }
    else {
        _888 = 1;
    }
    if (_888 != 0LL)
    goto L1; // [8] 19

    /** search.e:977			return 0*/
    DeRef(_sub_text_2051);
    DeRefDS(_full_text_2052);
    return 0LL;
L1: 

    /** search.e:980		if atom(sub_text) then*/
    _890 = IS_ATOM(_sub_text_2051);
    if (_890 == 0)
    {
        _890 = NOVALUE;
        goto L2; // [24] 57
    }
    else{
        _890 = NOVALUE;
    }

    /** search.e:981			if equal(sub_text, full_text[1]) then*/
    _2 = (object)SEQ_PTR(_full_text_2052);
    _891 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (_sub_text_2051 == _891)
    _892 = 1;
    else if (IS_ATOM_INT(_sub_text_2051) && IS_ATOM_INT(_891))
    _892 = 0;
    else
    _892 = (compare(_sub_text_2051, _891) == 0);
    _891 = NOVALUE;
    if (_892 == 0)
    {
        _892 = NOVALUE;
        goto L3; // [37] 49
    }
    else{
        _892 = NOVALUE;
    }

    /** search.e:982				return 1*/
    DeRef(_sub_text_2051);
    DeRefDS(_full_text_2052);
    return 1LL;
    goto L4; // [46] 56
L3: 

    /** search.e:984				return 0*/
    DeRef(_sub_text_2051);
    DeRefDS(_full_text_2052);
    return 0LL;
L4: 
L2: 

    /** search.e:988		if length(sub_text) > length(full_text) then*/
    if (IS_SEQUENCE(_sub_text_2051)){
            _893 = SEQ_PTR(_sub_text_2051)->length;
    }
    else {
        _893 = 1;
    }
    if (IS_SEQUENCE(_full_text_2052)){
            _894 = SEQ_PTR(_full_text_2052)->length;
    }
    else {
        _894 = 1;
    }
    if (_893 <= _894)
    goto L5; // [65] 76

    /** search.e:989			return 0*/
    DeRef(_sub_text_2051);
    DeRefDS(_full_text_2052);
    return 0LL;
L5: 

    /** search.e:992		if equal(sub_text, full_text[1.. length(sub_text)]) then*/
    if (IS_SEQUENCE(_sub_text_2051)){
            _896 = SEQ_PTR(_sub_text_2051)->length;
    }
    else {
        _896 = 1;
    }
    rhs_slice_target = (object_ptr)&_897;
    RHS_Slice(_full_text_2052, 1LL, _896);
    if (_sub_text_2051 == _897)
    _898 = 1;
    else if (IS_ATOM_INT(_sub_text_2051) && IS_ATOM_INT(_897))
    _898 = 0;
    else
    _898 = (compare(_sub_text_2051, _897) == 0);
    DeRefDS(_897);
    _897 = NOVALUE;
    if (_898 == 0)
    {
        _898 = NOVALUE;
        goto L6; // [90] 102
    }
    else{
        _898 = NOVALUE;
    }

    /** search.e:993			return 1*/
    DeRef(_sub_text_2051);
    DeRefDS(_full_text_2052);
    return 1LL;
    goto L7; // [99] 109
L6: 

    /** search.e:995			return 0*/
    DeRef(_sub_text_2051);
    DeRefDS(_full_text_2052);
    return 0LL;
L7: 
    ;
}


object _20ends(object _sub_text_2073, object _full_text_2074)
{
    object _914 = NOVALUE;
    object _913 = NOVALUE;
    object _912 = NOVALUE;
    object _911 = NOVALUE;
    object _910 = NOVALUE;
    object _909 = NOVALUE;
    object _908 = NOVALUE;
    object _906 = NOVALUE;
    object _905 = NOVALUE;
    object _904 = NOVALUE;
    object _903 = NOVALUE;
    object _902 = NOVALUE;
    object _901 = NOVALUE;
    object _899 = NOVALUE;
    object _0, _1, _2;
    

    /** search.e:1026		if length(full_text) = 0 then*/
    if (IS_SEQUENCE(_full_text_2074)){
            _899 = SEQ_PTR(_full_text_2074)->length;
    }
    else {
        _899 = 1;
    }
    if (_899 != 0LL)
    goto L1; // [8] 19

    /** search.e:1027			return 0*/
    DeRefDSi(_sub_text_2073);
    DeRefDS(_full_text_2074);
    return 0LL;
L1: 

    /** search.e:1030		if atom(sub_text) then*/
    _901 = IS_ATOM(_sub_text_2073);
    if (_901 == 0)
    {
        _901 = NOVALUE;
        goto L2; // [24] 60
    }
    else{
        _901 = NOVALUE;
    }

    /** search.e:1031			if equal(sub_text, full_text[$]) then*/
    if (IS_SEQUENCE(_full_text_2074)){
            _902 = SEQ_PTR(_full_text_2074)->length;
    }
    else {
        _902 = 1;
    }
    _2 = (object)SEQ_PTR(_full_text_2074);
    _903 = (object)*(((s1_ptr)_2)->base + _902);
    if (_sub_text_2073 == _903)
    _904 = 1;
    else if (IS_ATOM_INT(_sub_text_2073) && IS_ATOM_INT(_903))
    _904 = 0;
    else
    _904 = (compare(_sub_text_2073, _903) == 0);
    _903 = NOVALUE;
    if (_904 == 0)
    {
        _904 = NOVALUE;
        goto L3; // [40] 52
    }
    else{
        _904 = NOVALUE;
    }

    /** search.e:1032				return 1*/
    DeRefi(_sub_text_2073);
    DeRefDS(_full_text_2074);
    return 1LL;
    goto L4; // [49] 59
L3: 

    /** search.e:1034				return 0*/
    DeRefi(_sub_text_2073);
    DeRefDS(_full_text_2074);
    return 0LL;
L4: 
L2: 

    /** search.e:1038		if length(sub_text) > length(full_text) then*/
    if (IS_SEQUENCE(_sub_text_2073)){
            _905 = SEQ_PTR(_sub_text_2073)->length;
    }
    else {
        _905 = 1;
    }
    if (IS_SEQUENCE(_full_text_2074)){
            _906 = SEQ_PTR(_full_text_2074)->length;
    }
    else {
        _906 = 1;
    }
    if (_905 <= _906)
    goto L5; // [68] 79

    /** search.e:1039			return 0*/
    DeRefi(_sub_text_2073);
    DeRefDS(_full_text_2074);
    return 0LL;
L5: 

    /** search.e:1042		if equal(sub_text, full_text[$ - length(sub_text) + 1 .. $]) then*/
    if (IS_SEQUENCE(_full_text_2074)){
            _908 = SEQ_PTR(_full_text_2074)->length;
    }
    else {
        _908 = 1;
    }
    if (IS_SEQUENCE(_sub_text_2073)){
            _909 = SEQ_PTR(_sub_text_2073)->length;
    }
    else {
        _909 = 1;
    }
    _910 = _908 - _909;
    _908 = NOVALUE;
    _909 = NOVALUE;
    _911 = _910 + 1;
    _910 = NOVALUE;
    if (IS_SEQUENCE(_full_text_2074)){
            _912 = SEQ_PTR(_full_text_2074)->length;
    }
    else {
        _912 = 1;
    }
    rhs_slice_target = (object_ptr)&_913;
    RHS_Slice(_full_text_2074, _911, _912);
    if (_sub_text_2073 == _913)
    _914 = 1;
    else if (IS_ATOM_INT(_sub_text_2073) && IS_ATOM_INT(_913))
    _914 = 0;
    else
    _914 = (compare(_sub_text_2073, _913) == 0);
    DeRefDS(_913);
    _913 = NOVALUE;
    if (_914 == 0)
    {
        _914 = NOVALUE;
        goto L6; // [107] 119
    }
    else{
        _914 = NOVALUE;
    }

    /** search.e:1043			return 1*/
    DeRefi(_sub_text_2073);
    DeRefDS(_full_text_2074);
    _911 = NOVALUE;
    return 1LL;
    goto L7; // [116] 126
L6: 

    /** search.e:1045			return 0*/
    DeRefi(_sub_text_2073);
    DeRefDS(_full_text_2074);
    DeRef(_911);
    _911 = NOVALUE;
    return 0LL;
L7: 
    ;
}



// 0x38104214
