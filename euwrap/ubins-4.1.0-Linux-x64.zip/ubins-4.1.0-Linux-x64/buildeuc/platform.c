// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _46host_platform()
{
    object _0, _1, _2;
    

    /** platform.e:113		return ihost_platform*/
    return _46ihost_platform_21611;
    ;
}


void _46set_host_platform(object _plat_21618)
{
    object _12168 = NOVALUE;
    object _0, _1, _2;
    

    /** platform.e:119		ihost_platform = floor(plat)*/
    _46ihost_platform_21611 = e_floor(_plat_21618);

    /** platform.e:121		TUNIX    = (find(ihost_platform, unices) != 0) */
    _12168 = find_from(_46ihost_platform_21611, _46unices_21614, 1LL);
    _46TUNIX_21590 = (_12168 != 0LL);
    _12168 = NOVALUE;

    /** platform.e:122		TWINDOWS = (ihost_platform = WIN32)*/
    _46TWINDOWS_21586 = (_46ihost_platform_21611 == 2LL);

    /** platform.e:123		TBSD     = (ihost_platform = UFREEBSD)*/
    _46TBSD_21592 = (_46ihost_platform_21611 == 8LL);

    /** platform.e:124		TOSX     = (ihost_platform = UOSX)*/
    _46TOSX_21594 = (_46ihost_platform_21611 == 4LL);

    /** platform.e:125		TLINUX   = (ihost_platform = ULINUX)*/
    _46TLINUX_21588 = (_46ihost_platform_21611 == 3LL);

    /** platform.e:126		TOPENBSD = (ihost_platform = UOPENBSD)*/
    _46TOPENBSD_21596 = (_46ihost_platform_21611 == 6LL);

    /** platform.e:127		TNETBSD  = (ihost_platform = UNETBSD)*/
    _46TNETBSD_21598 = (_46ihost_platform_21611 == 7LL);

    /** platform.e:128		IUNIX    = TUNIX*/
    _46IUNIX_21589 = _46TUNIX_21590;

    /** platform.e:129		IWINDOWS = TWINDOWS*/
    _46IWINDOWS_21585 = _46TWINDOWS_21586;

    /** platform.e:130		IBSD     = TBSD*/
    _46IBSD_21591 = _46TBSD_21592;

    /** platform.e:131		IOSX     = TOSX*/
    _46IOSX_21593 = _46TOSX_21594;

    /** platform.e:132		ILINUX   = TLINUX*/
    _46ILINUX_21587 = _46TLINUX_21588;

    /** platform.e:133		IOPENBSD = TOPENBSD*/
    _46IOPENBSD_21595 = _46TOPENBSD_21596;

    /** platform.e:134		INETBSD  = TNETBSD*/
    _46INETBSD_21597 = _46TNETBSD_21598;

    /** platform.e:136		if TUNIX then*/
    if (_46TUNIX_21590 == 0)
    {
        goto L1; // [148] 161
    }
    else{
    }

    /** platform.e:137			HOSTNL = "\n"*/
    RefDS(_9772);
    DeRefi(_46HOSTNL_21608);
    _46HOSTNL_21608 = _9772;
    goto L2; // [158] 169
L1: 

    /** platform.e:139			HOSTNL = "\r\n"*/
    RefDS(_12165);
    DeRefi(_46HOSTNL_21608);
    _46HOSTNL_21608 = _12165;
L2: 

    /** platform.e:141	end procedure*/
    return;
    ;
}


void _46set_target_arch(object _arch_21633)
{
    object _12185 = NOVALUE;
    object _12176 = NOVALUE;
    object _0, _1, _2;
    

    /** platform.e:144		IX86    = 0*/
    _46IX86_21599 = 0LL;

    /** platform.e:145		TX86    = 0*/
    _46TX86_21600 = 0LL;

    /** platform.e:146		IX86_64 = 0*/
    _46IX86_64_21601 = 0LL;

    /** platform.e:147		TX86_64 = 0*/
    _46TX86_64_21602 = 0LL;

    /** platform.e:148		IARM    = 0*/
    _46IARM_21603 = 0LL;

    /** platform.e:149		TARM    = 0*/
    _46TARM_21604 = 0LL;

    /** platform.e:150		switch upper( arch ) do*/
    RefDS(_arch_21633);
    _12176 = _14upper(_arch_21633);
    _1 = find(_12176, _12177);
    DeRef(_12176);
    _12176 = NOVALUE;
    switch ( _1 ){ 

        /** platform.e:151			case "X86", "IX86" then*/
        case 1:
        case 2:

        /** platform.e:152				IX86    = 1*/
        _46IX86_21599 = 1LL;

        /** platform.e:153				TX86    = 1*/
        _46TX86_21600 = 1LL;

        /** platform.e:154				TARGET_SIZEOF_POINTER = 4*/
        _36TARGET_SIZEOF_POINTER_21261 = 4LL;
        goto L1; // [67] 140

        /** platform.e:156			case "X86_64", "IX86_64" then*/
        case 3:
        case 4:

        /** platform.e:157				IX86_64 = 1*/
        _46IX86_64_21601 = 1LL;

        /** platform.e:158				TX86_64 = 1*/
        _46TX86_64_21602 = 1LL;

        /** platform.e:159				TARGET_SIZEOF_POINTER = 8*/
        _36TARGET_SIZEOF_POINTER_21261 = 8LL;
        goto L1; // [92] 140

        /** platform.e:161			case "ARM" then*/
        case 5:

        /** platform.e:162				IARM = 1*/
        _46IARM_21603 = 1LL;

        /** platform.e:163				TARM = 1*/
        _46TARM_21604 = 1LL;

        /** platform.e:164				TARGET_SIZEOF_POINTER = 4*/
        _36TARGET_SIZEOF_POINTER_21261 = 4LL;
        goto L1; // [115] 140

        /** platform.e:166			case else*/
        case 0:

        /** platform.e:167				ShowMsg( 2, UNKNOWN_ARCHITECTURE_1__SUPPORTED_ARCHITECTURES_ARE_2, { arch, "X86, X86_64, ARM" } )*/
        RefDS(_12184);
        RefDS(_arch_21633);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _arch_21633;
        ((intptr_t *)_2)[2] = _12184;
        _12185 = MAKE_SEQ(_1);
        _39ShowMsg(2LL, 357LL, _12185, 1LL);
        _12185 = NOVALUE;

        /** platform.e:168				abort( 1 )*/
        UserCleanup(1LL);
    ;}L1: 

    /** platform.e:170		set_target_integer_size( TARGET_SIZEOF_POINTER )	*/
    _36set_target_integer_size(_36TARGET_SIZEOF_POINTER_21261);

    /** platform.e:171	end procedure*/
    DeRefDS(_arch_21633);
    return;
    ;
}


object _46GetPlatformDefines(object _for_translator_21658)
{
    object _local_defines_21659 = NOVALUE;
    object _lcmds_21669 = NOVALUE;
    object _fh_21671 = NOVALUE;
    object _sk_21691 = NOVALUE;
    object _12310 = NOVALUE;
    object _12309 = NOVALUE;
    object _12307 = NOVALUE;
    object _12304 = NOVALUE;
    object _12303 = NOVALUE;
    object _12301 = NOVALUE;
    object _12300 = NOVALUE;
    object _12298 = NOVALUE;
    object _12295 = NOVALUE;
    object _12294 = NOVALUE;
    object _12292 = NOVALUE;
    object _12291 = NOVALUE;
    object _12289 = NOVALUE;
    object _12287 = NOVALUE;
    object _12285 = NOVALUE;
    object _12284 = NOVALUE;
    object _12282 = NOVALUE;
    object _12279 = NOVALUE;
    object _12277 = NOVALUE;
    object _12276 = NOVALUE;
    object _12274 = NOVALUE;
    object _12272 = NOVALUE;
    object _12270 = NOVALUE;
    object _12269 = NOVALUE;
    object _12267 = NOVALUE;
    object _12265 = NOVALUE;
    object _12263 = NOVALUE;
    object _12262 = NOVALUE;
    object _12260 = NOVALUE;
    object _12258 = NOVALUE;
    object _12256 = NOVALUE;
    object _12255 = NOVALUE;
    object _12253 = NOVALUE;
    object _12250 = NOVALUE;
    object _12248 = NOVALUE;
    object _12247 = NOVALUE;
    object _12245 = NOVALUE;
    object _12243 = NOVALUE;
    object _12241 = NOVALUE;
    object _12240 = NOVALUE;
    object _12237 = NOVALUE;
    object _12234 = NOVALUE;
    object _12231 = NOVALUE;
    object _12227 = NOVALUE;
    object _12226 = NOVALUE;
    object _12221 = NOVALUE;
    object _12220 = NOVALUE;
    object _12207 = NOVALUE;
    object _12204 = NOVALUE;
    object _12201 = NOVALUE;
    object _12200 = NOVALUE;
    object _12199 = NOVALUE;
    object _12195 = NOVALUE;
    object _12192 = NOVALUE;
    object _12189 = NOVALUE;
    object _12187 = NOVALUE;
    object _12186 = NOVALUE;
    object _0, _1, _2;
    

    /** platform.e:174		sequence local_defines = {}*/
    RefDS(_5);
    DeRef(_local_defines_21659);
    _local_defines_21659 = _5;

    /** platform.e:176		if (IWINDOWS and not for_translator) or (TWINDOWS and for_translator) then*/
    if (_46IWINDOWS_21585 == 0) {
        _12186 = 0;
        goto L1; // [14] 25
    }
    _12187 = (_for_translator_21658 == 0);
    _12186 = (_12187 != 0);
L1: 
    if (_12186 != 0) {
        goto L2; // [25] 44
    }
    if (_46TWINDOWS_21586 == 0) {
        DeRef(_12189);
        _12189 = 0;
        goto L3; // [31] 39
    }
    _12189 = (_for_translator_21658 != 0);
L3: 
    if (_12189 == 0)
    {
        _12189 = NOVALUE;
        goto L4; // [40] 326
    }
    else{
        _12189 = NOVALUE;
    }
L2: 

    /** platform.e:177			local_defines &= {"WINDOWS", "WIN32"}*/
    RefDS(_12191);
    RefDS(_12190);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _12190;
    ((intptr_t *)_2)[2] = _12191;
    _12192 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21659, _local_defines_21659, _12192);
    DeRefDS(_12192);
    _12192 = NOVALUE;

    /** platform.e:178			sequence lcmds = command_line()*/
    DeRef(_lcmds_21669);
    _lcmds_21669 = Command_Line();

    /** platform.e:181			integer fh*/

    /** platform.e:182			fh = open(lcmds[1], "rb")*/
    _2 = (object)SEQ_PTR(_lcmds_21669);
    _12195 = (object)*(((s1_ptr)_2)->base + 1LL);
    _fh_21671 = EOpen(_12195, _10093, 0LL);
    _12195 = NOVALUE;

    /** platform.e:183			if fh = -1 then*/
    if (_fh_21671 != -1LL)
    goto L5; // [73] 123

    /** platform.e:185	 			if match("euiw", lower(lcmds[1])) != 0 then*/
    _2 = (object)SEQ_PTR(_lcmds_21669);
    _12199 = (object)*(((s1_ptr)_2)->base + 1LL);
    RefDS(_12199);
    _12200 = _14lower(_12199);
    _12199 = NOVALUE;
    _12201 = e_match_from(_12198, _12200, 1LL);
    DeRef(_12200);
    _12200 = NOVALUE;
    if (_12201 == 0LL)
    goto L6; // [92] 109

    /** platform.e:186	 				local_defines &= { "GUI" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12203);
    ((intptr_t*)_2)[1] = _12203;
    _12204 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21659, _local_defines_21659, _12204);
    DeRefDS(_12204);
    _12204 = NOVALUE;
    goto L7; // [106] 321
L6: 

    /** platform.e:188	 				local_defines &= { "CONSOLE" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12206);
    ((intptr_t*)_2)[1] = _12206;
    _12207 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21659, _local_defines_21659, _12207);
    DeRefDS(_12207);
    _12207 = NOVALUE;
    goto L7; // [120] 321
L5: 

    /** platform.e:191				atom sk*/

    /** platform.e:192				sk = seek(fh, #18) -- Fixed location of relocation table.*/
    _0 = _sk_21691;
    _sk_21691 = _8seek(_fh_21671, 24LL);
    DeRef(_0);

    /** platform.e:193				sk = get_integer16(fh)*/
    _0 = _sk_21691;
    _sk_21691 = _8get_integer16(_fh_21671);
    DeRef(_0);

    /** platform.e:194				if sk = #40 then*/
    if (binary_op_a(NOTEQ, _sk_21691, 64LL)){
        goto L8; // [140] 259
    }

    /** platform.e:196					sk = seek(fh, #3C) -- Fixed location of COFF signature offset.*/
    _0 = _sk_21691;
    _sk_21691 = _8seek(_fh_21671, 60LL);
    DeRef(_0);

    /** platform.e:197					sk = get_integer32(fh)*/
    _0 = _sk_21691;
    _sk_21691 = _8get_integer32(_fh_21671);
    DeRef(_0);

    /** platform.e:198					sk = seek(fh, sk)*/
    Ref(_sk_21691);
    _0 = _sk_21691;
    _sk_21691 = _8seek(_fh_21671, _sk_21691);
    DeRef(_0);

    /** platform.e:199					sk = get_integer16(fh)*/
    _0 = _sk_21691;
    _sk_21691 = _8get_integer16(_fh_21671);
    DeRef(_0);

    /** platform.e:200					if sk = #4550 then -- "PE" in intel endian*/
    if (binary_op_a(NOTEQ, _sk_21691, 17744LL)){
        goto L9; // [172] 221
    }

    /** platform.e:201						sk = get_integer16(fh)*/
    _0 = _sk_21691;
    _sk_21691 = _8get_integer16(_fh_21671);
    DeRef(_0);

    /** platform.e:202						if sk = 0 then*/
    if (binary_op_a(NOTEQ, _sk_21691, 0LL)){
        goto LA; // [184] 212
    }

    /** platform.e:204							sk = seek(fh, where(fh) + 88 )*/
    _12220 = _8where(_fh_21671);
    if (IS_ATOM_INT(_12220)) {
        _12221 = _12220 + 88LL;
        if ((object)((uintptr_t)_12221 + (uintptr_t)HIGH_BITS) >= 0){
            _12221 = NewDouble((eudouble)_12221);
        }
    }
    else {
        _12221 = binary_op(PLUS, _12220, 88LL);
    }
    DeRef(_12220);
    _12220 = NOVALUE;
    _0 = _sk_21691;
    _sk_21691 = _8seek(_fh_21671, _12221);
    DeRef(_0);
    _12221 = NOVALUE;

    /** platform.e:205							sk = get_integer16(fh)*/
    _0 = _sk_21691;
    _sk_21691 = _8get_integer16(_fh_21671);
    DeRef(_0);
    goto LB; // [209] 265
LA: 

    /** platform.e:207							sk = 0	-- Don't know this format.*/
    DeRef(_sk_21691);
    _sk_21691 = 0LL;
    goto LB; // [218] 265
L9: 

    /** platform.e:209					elsif sk = #454E then -- "NE" in intel endian*/
    if (binary_op_a(NOTEQ, _sk_21691, 17742LL)){
        goto LC; // [223] 250
    }

    /** platform.e:211						sk = seek(fh, where(fh) + 54 )*/
    _12226 = _8where(_fh_21671);
    if (IS_ATOM_INT(_12226)) {
        _12227 = _12226 + 54LL;
        if ((object)((uintptr_t)_12227 + (uintptr_t)HIGH_BITS) >= 0){
            _12227 = NewDouble((eudouble)_12227);
        }
    }
    else {
        _12227 = binary_op(PLUS, _12226, 54LL);
    }
    DeRef(_12226);
    _12226 = NOVALUE;
    _0 = _sk_21691;
    _sk_21691 = _8seek(_fh_21671, _12227);
    DeRef(_0);
    _12227 = NOVALUE;

    /** platform.e:212						sk = getc(fh)*/
    DeRef(_sk_21691);
    if (_fh_21671 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_21671, EF_READ);
        last_r_file_no = _fh_21671;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _sk_21691 = getc((FILE*)xstdin);
        }
        else{
            _sk_21691 = getc(last_r_file_ptr);
        }
    }
    else{
        _sk_21691 = getc(last_r_file_ptr);
    }
    goto LB; // [247] 265
LC: 

    /** platform.e:214						sk = 0*/
    DeRef(_sk_21691);
    _sk_21691 = 0LL;
    goto LB; // [256] 265
L8: 

    /** platform.e:217					sk = 0*/
    DeRef(_sk_21691);
    _sk_21691 = 0LL;
LB: 

    /** platform.e:219				if sk = 2 then*/
    if (binary_op_a(NOTEQ, _sk_21691, 2LL)){
        goto LD; // [267] 284
    }

    /** platform.e:220					local_defines &= { "GUI" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12203);
    ((intptr_t*)_2)[1] = _12203;
    _12231 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21659, _local_defines_21659, _12231);
    DeRefDS(_12231);
    _12231 = NOVALUE;
    goto LE; // [281] 314
LD: 

    /** platform.e:221				elsif sk = 3 then*/
    if (binary_op_a(NOTEQ, _sk_21691, 3LL)){
        goto LF; // [286] 303
    }

    /** platform.e:222					local_defines &= { "CONSOLE" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12206);
    ((intptr_t*)_2)[1] = _12206;
    _12234 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21659, _local_defines_21659, _12234);
    DeRefDS(_12234);
    _12234 = NOVALUE;
    goto LE; // [300] 314
LF: 

    /** platform.e:224					local_defines &= { "UNKNOWN" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12236);
    ((intptr_t*)_2)[1] = _12236;
    _12237 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21659, _local_defines_21659, _12237);
    DeRefDS(_12237);
    _12237 = NOVALUE;
LE: 

    /** platform.e:226				close(fh)*/
    EClose(_fh_21671);
    DeRef(_sk_21691);
    _sk_21691 = NOVALUE;
L7: 
    DeRef(_lcmds_21669);
    _lcmds_21669 = NOVALUE;
    goto L10; // [323] 575
L4: 

    /** platform.e:229			local_defines = append( local_defines, "CONSOLE" )*/
    RefDS(_12206);
    Append(&_local_defines_21659, _local_defines_21659, _12206);

    /** platform.e:230			if (ILINUX and not for_translator) or (TLINUX and for_translator) then*/
    if (_46ILINUX_21587 == 0) {
        _12240 = 0;
        goto L11; // [336] 347
    }
    _12241 = (_for_translator_21658 == 0);
    _12240 = (_12241 != 0);
L11: 
    if (_12240 != 0) {
        goto L12; // [347] 366
    }
    if (_46TLINUX_21588 == 0) {
        DeRef(_12243);
        _12243 = 0;
        goto L13; // [353] 361
    }
    _12243 = (_for_translator_21658 != 0);
L13: 
    if (_12243 == 0)
    {
        _12243 = NOVALUE;
        goto L14; // [362] 379
    }
    else{
        _12243 = NOVALUE;
    }
L12: 

    /** platform.e:231				local_defines &= {"UNIX", "LINUX"}*/
    RefDS(_12244);
    RefDS(_11973);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _11973;
    ((intptr_t *)_2)[2] = _12244;
    _12245 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21659, _local_defines_21659, _12245);
    DeRefDS(_12245);
    _12245 = NOVALUE;
    goto L15; // [376] 574
L14: 

    /** platform.e:232			elsif (IOSX and not for_translator) or (TOSX and for_translator) then*/
    if (_46IOSX_21593 == 0) {
        _12247 = 0;
        goto L16; // [383] 394
    }
    _12248 = (_for_translator_21658 == 0);
    _12247 = (_12248 != 0);
L16: 
    if (_12247 != 0) {
        goto L17; // [394] 413
    }
    if (_46TOSX_21594 == 0) {
        DeRef(_12250);
        _12250 = 0;
        goto L18; // [400] 408
    }
    _12250 = (_for_translator_21658 != 0);
L18: 
    if (_12250 == 0)
    {
        _12250 = NOVALUE;
        goto L19; // [409] 428
    }
    else{
        _12250 = NOVALUE;
    }
L17: 

    /** platform.e:233				local_defines &= {"UNIX", "BSD", "OSX"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11973);
    ((intptr_t*)_2)[1] = _11973;
    RefDS(_12251);
    ((intptr_t*)_2)[2] = _12251;
    RefDS(_12252);
    ((intptr_t*)_2)[3] = _12252;
    _12253 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21659, _local_defines_21659, _12253);
    DeRefDS(_12253);
    _12253 = NOVALUE;
    goto L15; // [425] 574
L19: 

    /** platform.e:234			elsif (IOPENBSD and not for_translator) or (TOPENBSD and for_translator) then*/
    if (_46IOPENBSD_21595 == 0) {
        _12255 = 0;
        goto L1A; // [432] 443
    }
    _12256 = (_for_translator_21658 == 0);
    _12255 = (_12256 != 0);
L1A: 
    if (_12255 != 0) {
        goto L1B; // [443] 462
    }
    if (_46TOPENBSD_21596 == 0) {
        DeRef(_12258);
        _12258 = 0;
        goto L1C; // [449] 457
    }
    _12258 = (_for_translator_21658 != 0);
L1C: 
    if (_12258 == 0)
    {
        _12258 = NOVALUE;
        goto L1D; // [458] 477
    }
    else{
        _12258 = NOVALUE;
    }
L1B: 

    /** platform.e:235				local_defines &= { "UNIX", "BSD", "OPENBSD"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11973);
    ((intptr_t*)_2)[1] = _11973;
    RefDS(_12251);
    ((intptr_t*)_2)[2] = _12251;
    RefDS(_12259);
    ((intptr_t*)_2)[3] = _12259;
    _12260 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21659, _local_defines_21659, _12260);
    DeRefDS(_12260);
    _12260 = NOVALUE;
    goto L15; // [474] 574
L1D: 

    /** platform.e:236			elsif (INETBSD and not for_translator) or (TNETBSD and for_translator) then*/
    if (_46INETBSD_21597 == 0) {
        _12262 = 0;
        goto L1E; // [481] 492
    }
    _12263 = (_for_translator_21658 == 0);
    _12262 = (_12263 != 0);
L1E: 
    if (_12262 != 0) {
        goto L1F; // [492] 511
    }
    if (_46TNETBSD_21598 == 0) {
        DeRef(_12265);
        _12265 = 0;
        goto L20; // [498] 506
    }
    _12265 = (_for_translator_21658 != 0);
L20: 
    if (_12265 == 0)
    {
        _12265 = NOVALUE;
        goto L21; // [507] 526
    }
    else{
        _12265 = NOVALUE;
    }
L1F: 

    /** platform.e:237				local_defines &= { "UNIX", "BSD", "NETBSD"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11973);
    ((intptr_t*)_2)[1] = _11973;
    RefDS(_12251);
    ((intptr_t*)_2)[2] = _12251;
    RefDS(_12266);
    ((intptr_t*)_2)[3] = _12266;
    _12267 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21659, _local_defines_21659, _12267);
    DeRefDS(_12267);
    _12267 = NOVALUE;
    goto L15; // [523] 574
L21: 

    /** platform.e:238			elsif (IBSD and not for_translator) or (TBSD and for_translator) then*/
    if (_46IBSD_21591 == 0) {
        _12269 = 0;
        goto L22; // [530] 541
    }
    _12270 = (_for_translator_21658 == 0);
    _12269 = (_12270 != 0);
L22: 
    if (_12269 != 0) {
        goto L23; // [541] 560
    }
    if (_46TBSD_21592 == 0) {
        DeRef(_12272);
        _12272 = 0;
        goto L24; // [547] 555
    }
    _12272 = (_for_translator_21658 != 0);
L24: 
    if (_12272 == 0)
    {
        _12272 = NOVALUE;
        goto L25; // [556] 573
    }
    else{
        _12272 = NOVALUE;
    }
L23: 

    /** platform.e:239				local_defines &= {"UNIX", "BSD", "FREEBSD"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11973);
    ((intptr_t*)_2)[1] = _11973;
    RefDS(_12251);
    ((intptr_t*)_2)[2] = _12251;
    RefDS(_12273);
    ((intptr_t*)_2)[3] = _12273;
    _12274 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21659, _local_defines_21659, _12274);
    DeRefDS(_12274);
    _12274 = NOVALUE;
L25: 
L15: 
L10: 

    /** platform.e:243		if (IX86 and not for_translator) or (TX86 and for_translator) then*/
    if (_46IX86_21599 == 0) {
        _12276 = 0;
        goto L26; // [579] 590
    }
    _12277 = (_for_translator_21658 == 0);
    _12276 = (_12277 != 0);
L26: 
    if (_12276 != 0) {
        goto L27; // [590] 609
    }
    if (_46TX86_21600 == 0) {
        DeRef(_12279);
        _12279 = 0;
        goto L28; // [596] 604
    }
    _12279 = (_for_translator_21658 != 0);
L28: 
    if (_12279 == 0)
    {
        _12279 = NOVALUE;
        goto L29; // [605] 624
    }
    else{
        _12279 = NOVALUE;
    }
L27: 

    /** platform.e:244			local_defines &= {"X86", "BITS32", "LONG32"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12179);
    ((intptr_t*)_2)[1] = _12179;
    RefDS(_12280);
    ((intptr_t*)_2)[2] = _12280;
    RefDS(_12281);
    ((intptr_t*)_2)[3] = _12281;
    _12282 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21659, _local_defines_21659, _12282);
    DeRefDS(_12282);
    _12282 = NOVALUE;
    goto L2A; // [621] 777
L29: 

    /** platform.e:246		elsif (IX86_64 and not for_translator) or (TX86_64 and for_translator) then*/
    if (_46IX86_64_21601 == 0) {
        _12284 = 0;
        goto L2B; // [628] 639
    }
    _12285 = (_for_translator_21658 == 0);
    _12284 = (_12285 != 0);
L2B: 
    if (_12284 != 0) {
        goto L2C; // [639] 658
    }
    if (_46TX86_64_21602 == 0) {
        DeRef(_12287);
        _12287 = 0;
        goto L2D; // [645] 653
    }
    _12287 = (_for_translator_21658 != 0);
L2D: 
    if (_12287 == 0)
    {
        _12287 = NOVALUE;
        goto L2E; // [654] 729
    }
    else{
        _12287 = NOVALUE;
    }
L2C: 

    /** platform.e:247			local_defines &= {"X86_64", "BITS64"}*/
    RefDS(_12288);
    RefDS(_12181);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _12181;
    ((intptr_t *)_2)[2] = _12288;
    _12289 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21659, _local_defines_21659, _12289);
    DeRefDS(_12289);
    _12289 = NOVALUE;

    /** platform.e:248			if (IWINDOWS and not for_translator) or (TWINDOWS and for_translator) then*/
    if (_46IWINDOWS_21585 == 0) {
        _12291 = 0;
        goto L2F; // [672] 683
    }
    _12292 = (_for_translator_21658 == 0);
    _12291 = (_12292 != 0);
L2F: 
    if (_12291 != 0) {
        goto L30; // [683] 702
    }
    if (_46TWINDOWS_21586 == 0) {
        DeRef(_12294);
        _12294 = 0;
        goto L31; // [689] 697
    }
    _12294 = (_for_translator_21658 != 0);
L31: 
    if (_12294 == 0)
    {
        _12294 = NOVALUE;
        goto L32; // [698] 715
    }
    else{
        _12294 = NOVALUE;
    }
L30: 

    /** platform.e:249				local_defines &= {"LONG32"}*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12281);
    ((intptr_t*)_2)[1] = _12281;
    _12295 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21659, _local_defines_21659, _12295);
    DeRefDS(_12295);
    _12295 = NOVALUE;
    goto L2A; // [712] 777
L32: 

    /** platform.e:251				local_defines &= {"LONG64"}*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12297);
    ((intptr_t*)_2)[1] = _12297;
    _12298 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21659, _local_defines_21659, _12298);
    DeRefDS(_12298);
    _12298 = NOVALUE;
    goto L2A; // [726] 777
L2E: 

    /** platform.e:253		elsif (IARM and not for_translator) or (TARM and for_translator) then*/
    if (_46IARM_21603 == 0) {
        _12300 = 0;
        goto L33; // [733] 744
    }
    _12301 = (_for_translator_21658 == 0);
    _12300 = (_12301 != 0);
L33: 
    if (_12300 != 0) {
        goto L34; // [744] 763
    }
    if (_46TARM_21604 == 0) {
        DeRef(_12303);
        _12303 = 0;
        goto L35; // [750] 758
    }
    _12303 = (_for_translator_21658 != 0);
L35: 
    if (_12303 == 0)
    {
        _12303 = NOVALUE;
        goto L36; // [759] 776
    }
    else{
        _12303 = NOVALUE;
    }
L34: 

    /** platform.e:254			local_defines &= {"ARM", "BITS32", "LONG32"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12183);
    ((intptr_t*)_2)[1] = _12183;
    RefDS(_12280);
    ((intptr_t*)_2)[2] = _12280;
    RefDS(_12281);
    ((intptr_t*)_2)[3] = _12281;
    _12304 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21659, _local_defines_21659, _12304);
    DeRefDS(_12304);
    _12304 = NOVALUE;
L36: 
L2A: 

    /** platform.e:259		return { "_PLAT_START" } & local_defines & { "_PLAT_STOP" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12306);
    ((intptr_t*)_2)[1] = _12306;
    _12307 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12308);
    ((intptr_t*)_2)[1] = _12308;
    _12309 = MAKE_SEQ(_1);
    {
        object concat_list[3];

        concat_list[0] = _12309;
        concat_list[1] = _local_defines_21659;
        concat_list[2] = _12307;
        Concat_N((object_ptr)&_12310, concat_list, 3);
    }
    DeRefDS(_12309);
    _12309 = NOVALUE;
    DeRefDS(_12307);
    _12307 = NOVALUE;
    DeRefDS(_local_defines_21659);
    DeRef(_12285);
    _12285 = NOVALUE;
    DeRef(_12292);
    _12292 = NOVALUE;
    DeRef(_12270);
    _12270 = NOVALUE;
    DeRef(_12241);
    _12241 = NOVALUE;
    DeRef(_12256);
    _12256 = NOVALUE;
    DeRef(_12277);
    _12277 = NOVALUE;
    DeRef(_12248);
    _12248 = NOVALUE;
    DeRef(_12263);
    _12263 = NOVALUE;
    DeRef(_12301);
    _12301 = NOVALUE;
    DeRef(_12187);
    _12187 = NOVALUE;
    return _12310;
    ;
}



// 0x4F4E86CB
