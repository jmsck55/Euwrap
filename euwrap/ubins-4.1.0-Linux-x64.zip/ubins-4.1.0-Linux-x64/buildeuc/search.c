// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _16find_all(object _needle_1386, object _haystack_1387, object _start_1388)
{
    object _kx_1389 = NOVALUE;
    object _547 = NOVALUE;
    object _546 = NOVALUE;
    object _0, _1, _2;
    

    /** search.e:292		integer kx = 0*/
    _kx_1389 = 0LL;

    /** search.e:293		while start with entry do*/
    goto L1; // [12] 39
L2: 
    if (_start_1388 == 0)
    {
        goto L3; // [15] 51
    }
    else{
    }

    /** search.e:294			kx += 1*/
    _kx_1389 = _kx_1389 + 1;

    /** search.e:295			haystack[kx] = start*/
    _2 = (object)SEQ_PTR(_haystack_1387);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _haystack_1387 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _kx_1389);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _start_1388;
    DeRef(_1);

    /** search.e:296			start += 1*/
    _start_1388 = _start_1388 + 1;

    /** search.e:297		entry*/
L1: 

    /** search.e:298			start = find(needle, haystack, start)*/
    _start_1388 = find_from(_needle_1386, _haystack_1387, _start_1388);

    /** search.e:299		end while*/
    goto L2; // [48] 15
L3: 

    /** search.e:301		haystack = remove( haystack, kx+1, length( haystack ) )*/
    _546 = _kx_1389 + 1;
    if (_546 > MAXINT){
        _546 = NewDouble((eudouble)_546);
    }
    if (IS_SEQUENCE(_haystack_1387)){
            _547 = SEQ_PTR(_haystack_1387)->length;
    }
    else {
        _547 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_haystack_1387);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_546)) ? _546 : (object)(DBL_PTR(_546)->dbl);
        int stop = (IS_ATOM_INT(_547)) ? _547 : (object)(DBL_PTR(_547)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_haystack_1387), start, &_haystack_1387 );
            }
            else Tail(SEQ_PTR(_haystack_1387), stop+1, &_haystack_1387);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_haystack_1387), start, &_haystack_1387);
        }
        else {
            assign_slice_seq = &assign_space;
            _haystack_1387 = Remove_elements(start, stop, (SEQ_PTR(_haystack_1387)->ref == 1));
        }
    }
    DeRef(_546);
    _546 = NOVALUE;
    _547 = NOVALUE;

    /** search.e:302		return haystack*/
    return _haystack_1387;
    ;
}


object _16rfind(object _needle_1504, object _haystack_1505, object _start_1506)
{
    object _len_1508 = NOVALUE;
    object _608 = NOVALUE;
    object _607 = NOVALUE;
    object _604 = NOVALUE;
    object _603 = NOVALUE;
    object _601 = NOVALUE;
    object _0, _1, _2;
    

    /** search.e:550		integer len = length(haystack)*/
    if (IS_SEQUENCE(_haystack_1505)){
            _len_1508 = SEQ_PTR(_haystack_1505)->length;
    }
    else {
        _len_1508 = 1;
    }

    /** search.e:552		if start = 0 then start = len end if*/
    if (_start_1506 != 0LL)
    goto L1; // [12] 20
    _start_1506 = _len_1508;
L1: 

    /** search.e:553		if (start > len) or (len + start < 1) then*/
    _601 = (_start_1506 > _len_1508);
    if (_601 != 0) {
        goto L2; // [26] 43
    }
    _603 = _len_1508 + _start_1506;
    if ((object)((uintptr_t)_603 + (uintptr_t)HIGH_BITS) >= 0){
        _603 = NewDouble((eudouble)_603);
    }
    if (IS_ATOM_INT(_603)) {
        _604 = (_603 < 1LL);
    }
    else {
        _604 = (DBL_PTR(_603)->dbl < (eudouble)1LL);
    }
    DeRef(_603);
    _603 = NOVALUE;
    if (_604 == 0)
    {
        DeRef(_604);
        _604 = NOVALUE;
        goto L3; // [39] 50
    }
    else{
        DeRef(_604);
        _604 = NOVALUE;
    }
L2: 

    /** search.e:554			return 0*/
    DeRef(_needle_1504);
    DeRefDS(_haystack_1505);
    DeRef(_601);
    _601 = NOVALUE;
    return 0LL;
L3: 

    /** search.e:557		if start < 1 then*/
    if (_start_1506 >= 1LL)
    goto L4; // [52] 63

    /** search.e:558			start = len + start*/
    _start_1506 = _len_1508 + _start_1506;
L4: 

    /** search.e:561		for i = start to 1 by -1 do*/
    {
        object _i_1521;
        _i_1521 = _start_1506;
L5: 
        if (_i_1521 < 1LL){
            goto L6; // [65] 99
        }

        /** search.e:562			if equal(haystack[i], needle) then*/
        _2 = (object)SEQ_PTR(_haystack_1505);
        _607 = (object)*(((s1_ptr)_2)->base + _i_1521);
        if (_607 == _needle_1504)
        _608 = 1;
        else if (IS_ATOM_INT(_607) && IS_ATOM_INT(_needle_1504))
        _608 = 0;
        else
        _608 = (compare(_607, _needle_1504) == 0);
        _607 = NOVALUE;
        if (_608 == 0)
        {
            _608 = NOVALUE;
            goto L7; // [82] 92
        }
        else{
            _608 = NOVALUE;
        }

        /** search.e:563				return i*/
        DeRef(_needle_1504);
        DeRefDS(_haystack_1505);
        DeRef(_601);
        _601 = NOVALUE;
        return _i_1521;
L7: 

        /** search.e:565		end for*/
        _i_1521 = _i_1521 + -1LL;
        goto L5; // [94] 72
L6: 
        ;
    }

    /** search.e:567		return 0*/
    DeRef(_needle_1504);
    DeRefDS(_haystack_1505);
    DeRef(_601);
    _601 = NOVALUE;
    return 0LL;
    ;
}


object _16find_replace(object _needle_1527, object _haystack_1528, object _replacement_1529, object _max_1530)
{
    object _posn_1531 = NOVALUE;
    object _612 = NOVALUE;
    object _0, _1, _2;
    

    /** search.e:612		integer posn = 0*/
    _posn_1531 = 0LL;

    /** search.e:614		while posn != 0 entry do */
    goto L1; // [12] 45
L2: 
    if (_posn_1531 == 0LL)
    goto L3; // [15] 61

    /** search.e:615			haystack[posn] = replacement*/
    Ref(_replacement_1529);
    _2 = (object)SEQ_PTR(_haystack_1528);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _haystack_1528 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _posn_1531);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _replacement_1529;
    DeRef(_1);

    /** search.e:616			max -= 1*/
    _max_1530 = _max_1530 - 1LL;

    /** search.e:617			if max = 0 then*/
    if (_max_1530 != 0LL)
    goto L4; // [33] 42

    /** search.e:618				exit*/
    goto L3; // [39] 61
L4: 

    /** search.e:620		entry*/
L1: 

    /** search.e:621			posn = find(needle, haystack, posn + 1)*/
    _612 = _posn_1531 + 1;
    if (_612 > MAXINT){
        _612 = NewDouble((eudouble)_612);
    }
    _posn_1531 = find_from(_needle_1527, _haystack_1528, _612);
    DeRef(_612);
    _612 = NOVALUE;

    /** search.e:622		end while*/
    goto L2; // [58] 15
L3: 

    /** search.e:624		return haystack*/
    DeRef(_needle_1527);
    DeRefi(_replacement_1529);
    return _haystack_1528;
    ;
}


object _16match_replace(object _needle_1541, object _haystack_1542, object _replacement_1543, object _max_1544)
{
    object _posn_1545 = NOVALUE;
    object _needle_len_1546 = NOVALUE;
    object _replacement_len_1547 = NOVALUE;
    object _scan_from_1548 = NOVALUE;
    object _cnt_1549 = NOVALUE;
    object _624 = NOVALUE;
    object _621 = NOVALUE;
    object _619 = NOVALUE;
    object _617 = NOVALUE;
    object _0, _1, _2;
    

    /** search.e:692		if max < 0 then*/

    /** search.e:696		cnt = length(haystack)*/
    if (IS_SEQUENCE(_haystack_1542)){
            _cnt_1549 = SEQ_PTR(_haystack_1542)->length;
    }
    else {
        _cnt_1549 = 1;
    }

    /** search.e:697		if max != 0 then*/

    /** search.e:701		if atom(needle) then*/
    _617 = IS_ATOM(_needle_1541);
    if (_617 == 0)
    {
        _617 = NOVALUE;
        goto L1; // [40] 50
    }
    else{
        _617 = NOVALUE;
    }

    /** search.e:702			needle = {needle}*/
    _0 = _needle_1541;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_needle_1541);
    ((intptr_t*)_2)[1] = _needle_1541;
    _needle_1541 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** search.e:704		if atom(replacement) then*/
    _619 = IS_ATOM(_replacement_1543);
    if (_619 == 0)
    {
        _619 = NOVALUE;
        goto L2; // [55] 65
    }
    else{
        _619 = NOVALUE;
    }

    /** search.e:705			replacement = {replacement}*/
    _0 = _replacement_1543;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_replacement_1543);
    ((intptr_t*)_2)[1] = _replacement_1543;
    _replacement_1543 = MAKE_SEQ(_1);
    DeRef(_0);
L2: 

    /** search.e:708		needle_len = length(needle) - 1*/
    if (IS_SEQUENCE(_needle_1541)){
            _621 = SEQ_PTR(_needle_1541)->length;
    }
    else {
        _621 = 1;
    }
    _needle_len_1546 = _621 - 1LL;
    _621 = NOVALUE;

    /** search.e:709		replacement_len = length(replacement)*/
    if (IS_SEQUENCE(_replacement_1543)){
            _replacement_len_1547 = SEQ_PTR(_replacement_1543)->length;
    }
    else {
        _replacement_len_1547 = 1;
    }

    /** search.e:711		scan_from = 1*/
    _scan_from_1548 = 1LL;

    /** search.e:712		while posn with entry do*/
    goto L3; // [86] 132
L4: 
    if (_posn_1545 == 0)
    {
        goto L5; // [91] 144
    }
    else{
    }

    /** search.e:713			haystack = replace(haystack, replacement, posn, posn + needle_len)*/
    _624 = _posn_1545 + _needle_len_1546;
    if ((object)((uintptr_t)_624 + (uintptr_t)HIGH_BITS) >= 0){
        _624 = NewDouble((eudouble)_624);
    }
    {
        intptr_t p1 = _haystack_1542;
        intptr_t p2 = _replacement_1543;
        intptr_t p3 = _posn_1545;
        intptr_t p4 = _624;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_haystack_1542;
        Replace( &replace_params );
    }
    DeRef(_624);
    _624 = NOVALUE;

    /** search.e:715			cnt -= 1*/
    _cnt_1549 = _cnt_1549 - 1LL;

    /** search.e:716			if cnt = 0 then*/
    if (_cnt_1549 != 0LL)
    goto L6; // [114] 123

    /** search.e:717				exit*/
    goto L5; // [120] 144
L6: 

    /** search.e:719			scan_from = posn + replacement_len*/
    _scan_from_1548 = _posn_1545 + _replacement_len_1547;

    /** search.e:720		entry*/
L3: 

    /** search.e:721			posn = match(needle, haystack, scan_from)*/
    _posn_1545 = e_match_from(_needle_1541, _haystack_1542, _scan_from_1548);

    /** search.e:722		end while*/
    goto L4; // [141] 89
L5: 

    /** search.e:724		return haystack*/
    DeRef(_needle_1541);
    DeRef(_replacement_1543);
    return _haystack_1542;
    ;
}


object _16begins(object _sub_text_1662, object _full_text_1663)
{
    object _688 = NOVALUE;
    object _687 = NOVALUE;
    object _686 = NOVALUE;
    object _684 = NOVALUE;
    object _683 = NOVALUE;
    object _682 = NOVALUE;
    object _681 = NOVALUE;
    object _680 = NOVALUE;
    object _678 = NOVALUE;
    object _0, _1, _2;
    

    /** search.e:976		if length(full_text) = 0 then*/
    if (IS_SEQUENCE(_full_text_1663)){
            _678 = SEQ_PTR(_full_text_1663)->length;
    }
    else {
        _678 = 1;
    }
    if (_678 != 0LL)
    goto L1; // [8] 19

    /** search.e:977			return 0*/
    DeRef(_sub_text_1662);
    DeRefDS(_full_text_1663);
    return 0LL;
L1: 

    /** search.e:980		if atom(sub_text) then*/
    _680 = IS_ATOM(_sub_text_1662);
    if (_680 == 0)
    {
        _680 = NOVALUE;
        goto L2; // [24] 57
    }
    else{
        _680 = NOVALUE;
    }

    /** search.e:981			if equal(sub_text, full_text[1]) then*/
    _2 = (object)SEQ_PTR(_full_text_1663);
    _681 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (_sub_text_1662 == _681)
    _682 = 1;
    else if (IS_ATOM_INT(_sub_text_1662) && IS_ATOM_INT(_681))
    _682 = 0;
    else
    _682 = (compare(_sub_text_1662, _681) == 0);
    _681 = NOVALUE;
    if (_682 == 0)
    {
        _682 = NOVALUE;
        goto L3; // [37] 49
    }
    else{
        _682 = NOVALUE;
    }

    /** search.e:982				return 1*/
    DeRef(_sub_text_1662);
    DeRefDS(_full_text_1663);
    return 1LL;
    goto L4; // [46] 56
L3: 

    /** search.e:984				return 0*/
    DeRef(_sub_text_1662);
    DeRefDS(_full_text_1663);
    return 0LL;
L4: 
L2: 

    /** search.e:988		if length(sub_text) > length(full_text) then*/
    if (IS_SEQUENCE(_sub_text_1662)){
            _683 = SEQ_PTR(_sub_text_1662)->length;
    }
    else {
        _683 = 1;
    }
    if (IS_SEQUENCE(_full_text_1663)){
            _684 = SEQ_PTR(_full_text_1663)->length;
    }
    else {
        _684 = 1;
    }
    if (_683 <= _684)
    goto L5; // [65] 76

    /** search.e:989			return 0*/
    DeRef(_sub_text_1662);
    DeRefDS(_full_text_1663);
    return 0LL;
L5: 

    /** search.e:992		if equal(sub_text, full_text[1.. length(sub_text)]) then*/
    if (IS_SEQUENCE(_sub_text_1662)){
            _686 = SEQ_PTR(_sub_text_1662)->length;
    }
    else {
        _686 = 1;
    }
    rhs_slice_target = (object_ptr)&_687;
    RHS_Slice(_full_text_1663, 1LL, _686);
    if (_sub_text_1662 == _687)
    _688 = 1;
    else if (IS_ATOM_INT(_sub_text_1662) && IS_ATOM_INT(_687))
    _688 = 0;
    else
    _688 = (compare(_sub_text_1662, _687) == 0);
    DeRefDS(_687);
    _687 = NOVALUE;
    if (_688 == 0)
    {
        _688 = NOVALUE;
        goto L6; // [90] 102
    }
    else{
        _688 = NOVALUE;
    }

    /** search.e:993			return 1*/
    DeRef(_sub_text_1662);
    DeRefDS(_full_text_1663);
    return 1LL;
    goto L7; // [99] 109
L6: 

    /** search.e:995			return 0*/
    DeRef(_sub_text_1662);
    DeRefDS(_full_text_1663);
    return 0LL;
L7: 
    ;
}


object _16ends(object _sub_text_1684, object _full_text_1685)
{
    object _704 = NOVALUE;
    object _703 = NOVALUE;
    object _702 = NOVALUE;
    object _701 = NOVALUE;
    object _700 = NOVALUE;
    object _699 = NOVALUE;
    object _698 = NOVALUE;
    object _696 = NOVALUE;
    object _695 = NOVALUE;
    object _694 = NOVALUE;
    object _693 = NOVALUE;
    object _692 = NOVALUE;
    object _691 = NOVALUE;
    object _689 = NOVALUE;
    object _0, _1, _2;
    

    /** search.e:1026		if length(full_text) = 0 then*/
    if (IS_SEQUENCE(_full_text_1685)){
            _689 = SEQ_PTR(_full_text_1685)->length;
    }
    else {
        _689 = 1;
    }
    if (_689 != 0LL)
    goto L1; // [8] 19

    /** search.e:1027			return 0*/
    DeRefDSi(_sub_text_1684);
    DeRefDS(_full_text_1685);
    return 0LL;
L1: 

    /** search.e:1030		if atom(sub_text) then*/
    _691 = IS_ATOM(_sub_text_1684);
    if (_691 == 0)
    {
        _691 = NOVALUE;
        goto L2; // [24] 60
    }
    else{
        _691 = NOVALUE;
    }

    /** search.e:1031			if equal(sub_text, full_text[$]) then*/
    if (IS_SEQUENCE(_full_text_1685)){
            _692 = SEQ_PTR(_full_text_1685)->length;
    }
    else {
        _692 = 1;
    }
    _2 = (object)SEQ_PTR(_full_text_1685);
    _693 = (object)*(((s1_ptr)_2)->base + _692);
    if (_sub_text_1684 == _693)
    _694 = 1;
    else if (IS_ATOM_INT(_sub_text_1684) && IS_ATOM_INT(_693))
    _694 = 0;
    else
    _694 = (compare(_sub_text_1684, _693) == 0);
    _693 = NOVALUE;
    if (_694 == 0)
    {
        _694 = NOVALUE;
        goto L3; // [40] 52
    }
    else{
        _694 = NOVALUE;
    }

    /** search.e:1032				return 1*/
    DeRefi(_sub_text_1684);
    DeRefDS(_full_text_1685);
    return 1LL;
    goto L4; // [49] 59
L3: 

    /** search.e:1034				return 0*/
    DeRefi(_sub_text_1684);
    DeRefDS(_full_text_1685);
    return 0LL;
L4: 
L2: 

    /** search.e:1038		if length(sub_text) > length(full_text) then*/
    if (IS_SEQUENCE(_sub_text_1684)){
            _695 = SEQ_PTR(_sub_text_1684)->length;
    }
    else {
        _695 = 1;
    }
    if (IS_SEQUENCE(_full_text_1685)){
            _696 = SEQ_PTR(_full_text_1685)->length;
    }
    else {
        _696 = 1;
    }
    if (_695 <= _696)
    goto L5; // [68] 79

    /** search.e:1039			return 0*/
    DeRefi(_sub_text_1684);
    DeRefDS(_full_text_1685);
    return 0LL;
L5: 

    /** search.e:1042		if equal(sub_text, full_text[$ - length(sub_text) + 1 .. $]) then*/
    if (IS_SEQUENCE(_full_text_1685)){
            _698 = SEQ_PTR(_full_text_1685)->length;
    }
    else {
        _698 = 1;
    }
    if (IS_SEQUENCE(_sub_text_1684)){
            _699 = SEQ_PTR(_sub_text_1684)->length;
    }
    else {
        _699 = 1;
    }
    _700 = _698 - _699;
    _698 = NOVALUE;
    _699 = NOVALUE;
    _701 = _700 + 1;
    _700 = NOVALUE;
    if (IS_SEQUENCE(_full_text_1685)){
            _702 = SEQ_PTR(_full_text_1685)->length;
    }
    else {
        _702 = 1;
    }
    rhs_slice_target = (object_ptr)&_703;
    RHS_Slice(_full_text_1685, _701, _702);
    if (_sub_text_1684 == _703)
    _704 = 1;
    else if (IS_ATOM_INT(_sub_text_1684) && IS_ATOM_INT(_703))
    _704 = 0;
    else
    _704 = (compare(_sub_text_1684, _703) == 0);
    DeRefDS(_703);
    _703 = NOVALUE;
    if (_704 == 0)
    {
        _704 = NOVALUE;
        goto L6; // [107] 119
    }
    else{
        _704 = NOVALUE;
    }

    /** search.e:1043			return 1*/
    DeRefi(_sub_text_1684);
    DeRefDS(_full_text_1685);
    _701 = NOVALUE;
    return 1LL;
    goto L7; // [116] 126
L6: 

    /** search.e:1045			return 0*/
    DeRefi(_sub_text_1684);
    DeRefDS(_full_text_1685);
    DeRef(_701);
    _701 = NOVALUE;
    return 0LL;
L7: 
    ;
}



// 0x13F4316E
