// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _48exe_path()
{
    object _25808 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:70		if sequence(exe_path_cache) then*/
    _25808 = IS_SEQUENCE(_48exe_path_cache_50360);
    if (_25808 == 0)
    {
        _25808 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _25808 = NOVALUE;
    }

    /** pathopen.e:71			return exe_path_cache*/
    Ref(_48exe_path_cache_50360);
    return _48exe_path_cache_50360;
L1: 

    /** pathopen.e:74		exe_path_cache = command_line()*/
    DeRef(_48exe_path_cache_50360);
    _48exe_path_cache_50360 = Command_Line();

    /** pathopen.e:75		exe_path_cache = exe_path_cache[1]*/
    _0 = _48exe_path_cache_50360;
    _2 = (object)SEQ_PTR(_48exe_path_cache_50360);
    _48exe_path_cache_50360 = (object)*(((s1_ptr)_2)->base + 1LL);
    RefDS(_48exe_path_cache_50360);
    DeRefDS(_0);

    /** pathopen.e:77		return exe_path_cache*/
    RefDS(_48exe_path_cache_50360);
    return _48exe_path_cache_50360;
    ;
}


object _48check_cache(object _env_50372, object _inc_path_50373)
{
    object _delim_50374 = NOVALUE;
    object _pos_50375 = NOVALUE;
    object _25856 = NOVALUE;
    object _25855 = NOVALUE;
    object _25854 = NOVALUE;
    object _25853 = NOVALUE;
    object _25851 = NOVALUE;
    object _25850 = NOVALUE;
    object _25849 = NOVALUE;
    object _25848 = NOVALUE;
    object _25847 = NOVALUE;
    object _25846 = NOVALUE;
    object _25845 = NOVALUE;
    object _25844 = NOVALUE;
    object _25843 = NOVALUE;
    object _25839 = NOVALUE;
    object _25838 = NOVALUE;
    object _25837 = NOVALUE;
    object _25836 = NOVALUE;
    object _25835 = NOVALUE;
    object _25834 = NOVALUE;
    object _25833 = NOVALUE;
    object _25832 = NOVALUE;
    object _25830 = NOVALUE;
    object _25829 = NOVALUE;
    object _25828 = NOVALUE;
    object _25827 = NOVALUE;
    object _25826 = NOVALUE;
    object _25825 = NOVALUE;
    object _25823 = NOVALUE;
    object _25822 = NOVALUE;
    object _25821 = NOVALUE;
    object _25820 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:83		if not num_var then -- first time the var is accessed, add cache entry*/
    if (_48num_var_50349 != 0)
    goto L1; // [9] 86

    /** pathopen.e:84			cache_vars = append(cache_vars,env)*/
    RefDS(_env_50372);
    Append(&_48cache_vars_50350, _48cache_vars_50350, _env_50372);

    /** pathopen.e:85			cache_strings = append(cache_strings,inc_path)*/
    RefDS(_inc_path_50373);
    Append(&_48cache_strings_50351, _48cache_strings_50351, _inc_path_50373);

    /** pathopen.e:86			cache_substrings = append(cache_substrings,{})*/
    RefDS(_21993);
    Append(&_48cache_substrings_50352, _48cache_substrings_50352, _21993);

    /** pathopen.e:87			cache_starts = append(cache_starts,{})*/
    RefDS(_21993);
    Append(&_48cache_starts_50353, _48cache_starts_50353, _21993);

    /** pathopen.e:88			cache_ends = append(cache_ends,{})*/
    RefDS(_21993);
    Append(&_48cache_ends_50354, _48cache_ends_50354, _21993);

    /** pathopen.e:89			ifdef WINDOWS then*/

    /** pathopen.e:92			num_var = length(cache_vars)*/
    if (IS_SEQUENCE(_48cache_vars_50350)){
            _48num_var_50349 = SEQ_PTR(_48cache_vars_50350)->length;
    }
    else {
        _48num_var_50349 = 1;
    }

    /** pathopen.e:93			cache_complete &= 0*/
    Append(&_48cache_complete_50356, _48cache_complete_50356, 0LL);

    /** pathopen.e:94			cache_delims &= 0*/
    Append(&_48cache_delims_50357, _48cache_delims_50357, 0LL);

    /** pathopen.e:95			return 0*/
    DeRefDSi(_env_50372);
    DeRefDSi(_inc_path_50373);
    return 0LL;
    goto L2; // [83] 425
L1: 

    /** pathopen.e:97			if compare(inc_path,cache_strings[num_var]) then*/
    _2 = (object)SEQ_PTR(_48cache_strings_50351);
    _25820 = (object)*(((s1_ptr)_2)->base + _48num_var_50349);
    if (IS_ATOM_INT(_inc_path_50373) && IS_ATOM_INT(_25820)){
        _25821 = (_inc_path_50373 < _25820) ? -1 : (_inc_path_50373 > _25820);
    }
    else{
        _25821 = compare(_inc_path_50373, _25820);
    }
    _25820 = NOVALUE;
    if (_25821 == 0)
    {
        _25821 = NOVALUE;
        goto L3; // [100] 424
    }
    else{
        _25821 = NOVALUE;
    }

    /** pathopen.e:98				cache_strings[num_var] = inc_path*/
    RefDS(_inc_path_50373);
    _2 = (object)SEQ_PTR(_48cache_strings_50351);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _48cache_strings_50351 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _48num_var_50349);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _inc_path_50373;
    DeRefDS(_1);

    /** pathopen.e:99				cache_complete[num_var] = 0*/
    _2 = (object)SEQ_PTR(_48cache_complete_50356);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _48cache_complete_50356 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _48num_var_50349);
    *(intptr_t *)_2 = 0LL;

    /** pathopen.e:100				if match(cache_strings[num_var],inc_path)!=1 then -- try to salvage what we can*/
    _2 = (object)SEQ_PTR(_48cache_strings_50351);
    _25822 = (object)*(((s1_ptr)_2)->base + _48num_var_50349);
    _25823 = e_match_from(_25822, _inc_path_50373, 1LL);
    _25822 = NOVALUE;
    if (_25823 == 1LL)
    goto L4; // [138] 423

    /** pathopen.e:101					pos = -1*/
    _pos_50375 = -1LL;

    /** pathopen.e:102					for i=1 to length(cache_strings[num_var]) do*/
    _2 = (object)SEQ_PTR(_48cache_strings_50351);
    _25825 = (object)*(((s1_ptr)_2)->base + _48num_var_50349);
    if (IS_SEQUENCE(_25825)){
            _25826 = SEQ_PTR(_25825)->length;
    }
    else {
        _25826 = 1;
    }
    _25825 = NOVALUE;
    {
        object _i_50395;
        _i_50395 = 1LL;
L5: 
        if (_i_50395 > _25826){
            goto L6; // [160] 422
        }

        /** pathopen.e:103						if cache_ends[num_var][i] > length(inc_path) or */
        _2 = (object)SEQ_PTR(_48cache_ends_50354);
        _25827 = (object)*(((s1_ptr)_2)->base + _48num_var_50349);
        _2 = (object)SEQ_PTR(_25827);
        _25828 = (object)*(((s1_ptr)_2)->base + _i_50395);
        _25827 = NOVALUE;
        if (IS_SEQUENCE(_inc_path_50373)){
                _25829 = SEQ_PTR(_inc_path_50373)->length;
        }
        else {
            _25829 = 1;
        }
        if (IS_ATOM_INT(_25828)) {
            _25830 = (_25828 > _25829);
        }
        else {
            _25830 = binary_op(GREATER, _25828, _25829);
        }
        _25828 = NOVALUE;
        _25829 = NOVALUE;
        if (IS_ATOM_INT(_25830)) {
            if (_25830 != 0) {
                goto L7; // [188] 242
            }
        }
        else {
            if (DBL_PTR(_25830)->dbl != 0.0) {
                goto L7; // [188] 242
            }
        }
        _2 = (object)SEQ_PTR(_48cache_substrings_50352);
        _25832 = (object)*(((s1_ptr)_2)->base + _48num_var_50349);
        _2 = (object)SEQ_PTR(_25832);
        _25833 = (object)*(((s1_ptr)_2)->base + _i_50395);
        _25832 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_starts_50353);
        _25834 = (object)*(((s1_ptr)_2)->base + _48num_var_50349);
        _2 = (object)SEQ_PTR(_25834);
        _25835 = (object)*(((s1_ptr)_2)->base + _i_50395);
        _25834 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_ends_50354);
        _25836 = (object)*(((s1_ptr)_2)->base + _48num_var_50349);
        _2 = (object)SEQ_PTR(_25836);
        _25837 = (object)*(((s1_ptr)_2)->base + _i_50395);
        _25836 = NOVALUE;
        rhs_slice_target = (object_ptr)&_25838;
        RHS_Slice(_inc_path_50373, _25835, _25837);
        if (IS_ATOM_INT(_25833) && IS_ATOM_INT(_25838)){
            _25839 = (_25833 < _25838) ? -1 : (_25833 > _25838);
        }
        else{
            _25839 = compare(_25833, _25838);
        }
        _25833 = NOVALUE;
        DeRefDS(_25838);
        _25838 = NOVALUE;
        if (_25839 == 0)
        {
            _25839 = NOVALUE;
            goto L8; // [238] 253
        }
        else{
            _25839 = NOVALUE;
        }
L7: 

        /** pathopen.e:107							pos = i-1*/
        _pos_50375 = _i_50395 - 1LL;

        /** pathopen.e:108							exit*/
        goto L6; // [250] 422
L8: 

        /** pathopen.e:110						if pos = 0 then*/
        if (_pos_50375 != 0LL)
        goto L9; // [255] 268

        /** pathopen.e:111							return 0*/
        DeRefDSi(_env_50372);
        DeRefDSi(_inc_path_50373);
        _25837 = NOVALUE;
        _25825 = NOVALUE;
        DeRef(_25830);
        _25830 = NOVALUE;
        _25835 = NOVALUE;
        return 0LL;
        goto LA; // [265] 415
L9: 

        /** pathopen.e:112						elsif pos >0 then -- crop cache data*/
        if (_pos_50375 <= 0LL)
        goto LB; // [270] 414

        /** pathopen.e:113							cache_substrings[num_var] = cache_substrings[num_var][1..pos]*/
        _2 = (object)SEQ_PTR(_48cache_substrings_50352);
        _25843 = (object)*(((s1_ptr)_2)->base + _48num_var_50349);
        rhs_slice_target = (object_ptr)&_25844;
        RHS_Slice(_25843, 1LL, _pos_50375);
        _25843 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_substrings_50352);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_substrings_50352 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50349);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _25844;
        if( _1 != _25844 ){
            DeRefDS(_1);
        }
        _25844 = NOVALUE;

        /** pathopen.e:114							cache_starts[num_var] = cache_starts[num_var][1..pos]*/
        _2 = (object)SEQ_PTR(_48cache_starts_50353);
        _25845 = (object)*(((s1_ptr)_2)->base + _48num_var_50349);
        rhs_slice_target = (object_ptr)&_25846;
        RHS_Slice(_25845, 1LL, _pos_50375);
        _25845 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_starts_50353);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_starts_50353 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50349);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _25846;
        if( _1 != _25846 ){
            DeRef(_1);
        }
        _25846 = NOVALUE;

        /** pathopen.e:115							cache_ends[num_var] = cache_ends[num_var][1..pos]*/
        _2 = (object)SEQ_PTR(_48cache_ends_50354);
        _25847 = (object)*(((s1_ptr)_2)->base + _48num_var_50349);
        rhs_slice_target = (object_ptr)&_25848;
        RHS_Slice(_25847, 1LL, _pos_50375);
        _25847 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_ends_50354);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_ends_50354 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50349);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _25848;
        if( _1 != _25848 ){
            DeRef(_1);
        }
        _25848 = NOVALUE;

        /** pathopen.e:116							ifdef WINDOWS then*/

        /** pathopen.e:119							delim = cache_ends[num_var][$]+1*/
        _2 = (object)SEQ_PTR(_48cache_ends_50354);
        _25849 = (object)*(((s1_ptr)_2)->base + _48num_var_50349);
        if (IS_SEQUENCE(_25849)){
                _25850 = SEQ_PTR(_25849)->length;
        }
        else {
            _25850 = 1;
        }
        _2 = (object)SEQ_PTR(_25849);
        _25851 = (object)*(((s1_ptr)_2)->base + _25850);
        _25849 = NOVALUE;
        if (IS_ATOM_INT(_25851)) {
            _delim_50374 = _25851 + 1;
        }
        else
        { // coercing _delim_50374 to an integer 1
            _delim_50374 = 1+(object)(DBL_PTR(_25851)->dbl);
            if( !IS_ATOM_INT(_delim_50374) ){
                _delim_50374 = (object)DBL_PTR(_delim_50374)->dbl;
            }
        }
        _25851 = NOVALUE;

        /** pathopen.e:120							while delim <= length(inc_path) and delim != PATH_SEPARATOR do*/
LC: 
        if (IS_SEQUENCE(_inc_path_50373)){
                _25853 = SEQ_PTR(_inc_path_50373)->length;
        }
        else {
            _25853 = 1;
        }
        _25854 = (_delim_50374 <= _25853);
        _25853 = NOVALUE;
        if (_25854 == 0) {
            goto LD; // [378] 403
        }
        _25856 = (_delim_50374 != 58LL);
        if (_25856 == 0)
        {
            DeRef(_25856);
            _25856 = NOVALUE;
            goto LD; // [389] 403
        }
        else{
            DeRef(_25856);
            _25856 = NOVALUE;
        }

        /** pathopen.e:121								delim+=1*/
        _delim_50374 = _delim_50374 + 1;

        /** pathopen.e:122							end while*/
        goto LC; // [400] 371
LD: 

        /** pathopen.e:123							cache_delims[num_var] = delim*/
        _2 = (object)SEQ_PTR(_48cache_delims_50357);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_delims_50357 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50349);
        *(intptr_t *)_2 = _delim_50374;
LB: 
LA: 

        /** pathopen.e:125					end for*/
        _i_50395 = _i_50395 + 1LL;
        goto L5; // [417] 167
L6: 
        ;
    }
L4: 
L3: 
L2: 

    /** pathopen.e:129		return 1*/
    DeRefDSi(_env_50372);
    DeRefDSi(_inc_path_50373);
    _25837 = NOVALUE;
    _25825 = NOVALUE;
    DeRef(_25830);
    _25830 = NOVALUE;
    DeRef(_25854);
    _25854 = NOVALUE;
    _25835 = NOVALUE;
    return 1LL;
    ;
}


object _48get_conf_dirs()
{
    object _delimiter_50436 = NOVALUE;
    object _dirs_50437 = NOVALUE;
    object _25861 = NOVALUE;
    object _25859 = NOVALUE;
    object _25858 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:136		ifdef UNIX then*/

    /** pathopen.e:137			delimiter = ':'*/
    _delimiter_50436 = 58LL;

    /** pathopen.e:142		dirs = ""*/
    RefDS(_21993);
    DeRef(_dirs_50437);
    _dirs_50437 = _21993;

    /** pathopen.e:143		for i = 1 to length(config_inc_paths) do*/
    if (IS_SEQUENCE(_48config_inc_paths_50358)){
            _25858 = SEQ_PTR(_48config_inc_paths_50358)->length;
    }
    else {
        _25858 = 1;
    }
    {
        object _i_50439;
        _i_50439 = 1LL;
L1: 
        if (_i_50439 > _25858){
            goto L2; // [22] 68
        }

        /** pathopen.e:144			dirs &= config_inc_paths[i]*/
        _2 = (object)SEQ_PTR(_48config_inc_paths_50358);
        _25859 = (object)*(((s1_ptr)_2)->base + _i_50439);
        Concat((object_ptr)&_dirs_50437, _dirs_50437, _25859);
        _25859 = NOVALUE;

        /** pathopen.e:145			if i != length(config_inc_paths) then*/
        if (IS_SEQUENCE(_48config_inc_paths_50358)){
                _25861 = SEQ_PTR(_48config_inc_paths_50358)->length;
        }
        else {
            _25861 = 1;
        }
        if (_i_50439 == _25861)
        goto L3; // [48] 61

        /** pathopen.e:146				dirs &= delimiter*/
        Append(&_dirs_50437, _dirs_50437, _delimiter_50436);
L3: 

        /** pathopen.e:148		end for*/
        _i_50439 = _i_50439 + 1LL;
        goto L1; // [63] 29
L2: 
        ;
    }

    /** pathopen.e:150		return dirs*/
    return _dirs_50437;
    ;
}


object _48strip_file_from_path(object _full_path_50449)
{
    object _25867 = NOVALUE;
    object _25865 = NOVALUE;
    object _25864 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:156		for i = length(full_path) to 1 by -1 do*/
    if (IS_SEQUENCE(_full_path_50449)){
            _25864 = SEQ_PTR(_full_path_50449)->length;
    }
    else {
        _25864 = 1;
    }
    {
        object _i_50451;
        _i_50451 = _25864;
L1: 
        if (_i_50451 < 1LL){
            goto L2; // [8] 46
        }

        /** pathopen.e:157			if full_path[i] = SLASH then*/
        _2 = (object)SEQ_PTR(_full_path_50449);
        _25865 = (object)*(((s1_ptr)_2)->base + _i_50451);
        if (binary_op_a(NOTEQ, _25865, 47LL)){
            _25865 = NOVALUE;
            goto L3; // [23] 39
        }
        _25865 = NOVALUE;

        /** pathopen.e:158				return full_path[1..i]*/
        rhs_slice_target = (object_ptr)&_25867;
        RHS_Slice(_full_path_50449, 1LL, _i_50451);
        DeRefDS(_full_path_50449);
        return _25867;
L3: 

        /** pathopen.e:160		end for*/
        _i_50451 = _i_50451 + -1LL;
        goto L1; // [41] 15
L2: 
        ;
    }

    /** pathopen.e:162		return ""*/
    RefDS(_21993);
    DeRefDS(_full_path_50449);
    DeRef(_25867);
    _25867 = NOVALUE;
    return _21993;
    ;
}


object _48expand_path(object _path_50460, object _prefix_50461)
{
    object _absolute_50462 = NOVALUE;
    object _home_50466 = NOVALUE;
    object _25891 = NOVALUE;
    object _25890 = NOVALUE;
    object _25889 = NOVALUE;
    object _25888 = NOVALUE;
    object _25887 = NOVALUE;
    object _25886 = NOVALUE;
    object _25882 = NOVALUE;
    object _25880 = NOVALUE;
    object _25879 = NOVALUE;
    object _25878 = NOVALUE;
    object _25877 = NOVALUE;
    object _25876 = NOVALUE;
    object _25873 = NOVALUE;
    object _25872 = NOVALUE;
    object _25871 = NOVALUE;
    object _25870 = NOVALUE;
    object _25868 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:169		if not length(path) then*/
    if (IS_SEQUENCE(_path_50460)){
            _25868 = SEQ_PTR(_path_50460)->length;
    }
    else {
        _25868 = 1;
    }
    if (_25868 != 0)
    goto L1; // [10] 22
    _25868 = NOVALUE;

    /** pathopen.e:170			return pwd*/
    RefDS(_48pwd_50361);
    DeRefDS(_path_50460);
    DeRefDS(_prefix_50461);
    DeRefi(_home_50466);
    return _48pwd_50361;
L1: 

    /** pathopen.e:174		ifdef UNIX then*/

    /** pathopen.e:175			object home*/

    /** pathopen.e:176			if length(path) and path[1] = '~' then*/
    if (IS_SEQUENCE(_path_50460)){
            _25870 = SEQ_PTR(_path_50460)->length;
    }
    else {
        _25870 = 1;
    }
    if (_25870 == 0) {
        goto L2; // [31] 84
    }
    _2 = (object)SEQ_PTR(_path_50460);
    _25872 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_25872)) {
        _25873 = (_25872 == 126LL);
    }
    else {
        _25873 = binary_op(EQUALS, _25872, 126LL);
    }
    _25872 = NOVALUE;
    if (_25873 == 0) {
        DeRef(_25873);
        _25873 = NOVALUE;
        goto L2; // [44] 84
    }
    else {
        if (!IS_ATOM_INT(_25873) && DBL_PTR(_25873)->dbl == 0.0){
            DeRef(_25873);
            _25873 = NOVALUE;
            goto L2; // [44] 84
        }
        DeRef(_25873);
        _25873 = NOVALUE;
    }
    DeRef(_25873);
    _25873 = NOVALUE;

    /** pathopen.e:177				home = getenv("HOME")*/
    DeRefi(_home_50466);
    _home_50466 = EGetEnv(_25874);

    /** pathopen.e:178				if sequence(home) and length(home) then*/
    _25876 = IS_SEQUENCE(_home_50466);
    if (_25876 == 0) {
        goto L3; // [57] 83
    }
    if (IS_SEQUENCE(_home_50466)){
            _25878 = SEQ_PTR(_home_50466)->length;
    }
    else {
        _25878 = 1;
    }
    if (_25878 == 0)
    {
        _25878 = NOVALUE;
        goto L3; // [65] 83
    }
    else{
        _25878 = NOVALUE;
    }

    /** pathopen.e:179					path = home & path[2..$]*/
    if (IS_SEQUENCE(_path_50460)){
            _25879 = SEQ_PTR(_path_50460)->length;
    }
    else {
        _25879 = 1;
    }
    rhs_slice_target = (object_ptr)&_25880;
    RHS_Slice(_path_50460, 2LL, _25879);
    if (IS_SEQUENCE(_home_50466) && IS_ATOM(_25880)) {
    }
    else if (IS_ATOM(_home_50466) && IS_SEQUENCE(_25880)) {
        Ref(_home_50466);
        Prepend(&_path_50460, _25880, _home_50466);
    }
    else {
        Concat((object_ptr)&_path_50460, _home_50466, _25880);
    }
    DeRefDS(_25880);
    _25880 = NOVALUE;
L3: 
L2: 

    /** pathopen.e:183			absolute = find(path[1], SLASH_CHARS)*/
    _2 = (object)SEQ_PTR(_path_50460);
    _25882 = (object)*(((s1_ptr)_2)->base + 1LL);
    _absolute_50462 = find_from(_25882, _46SLASH_CHARS_21606, 1LL);
    _25882 = NOVALUE;

    /** pathopen.e:188		if not absolute then*/
    if (_absolute_50462 != 0)
    goto L4; // [101] 115

    /** pathopen.e:189			path = prefix & SLASH & path*/
    {
        object concat_list[3];

        concat_list[0] = _path_50460;
        concat_list[1] = 47LL;
        concat_list[2] = _prefix_50461;
        Concat_N((object_ptr)&_path_50460, concat_list, 3);
    }
L4: 

    /** pathopen.e:192		if length(path) and not find(path[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_path_50460)){
            _25886 = SEQ_PTR(_path_50460)->length;
    }
    else {
        _25886 = 1;
    }
    if (_25886 == 0) {
        goto L5; // [120] 154
    }
    if (IS_SEQUENCE(_path_50460)){
            _25888 = SEQ_PTR(_path_50460)->length;
    }
    else {
        _25888 = 1;
    }
    _2 = (object)SEQ_PTR(_path_50460);
    _25889 = (object)*(((s1_ptr)_2)->base + _25888);
    _25890 = find_from(_25889, _46SLASH_CHARS_21606, 1LL);
    _25889 = NOVALUE;
    _25891 = (_25890 == 0);
    _25890 = NOVALUE;
    if (_25891 == 0)
    {
        DeRef(_25891);
        _25891 = NOVALUE;
        goto L5; // [142] 154
    }
    else{
        DeRef(_25891);
        _25891 = NOVALUE;
    }

    /** pathopen.e:193			path &= SLASH*/
    Append(&_path_50460, _path_50460, 47LL);
L5: 

    /** pathopen.e:196		return path*/
    DeRefDS(_prefix_50461);
    DeRefi(_home_50466);
    return _path_50460;
    ;
}


void _48add_include_directory(object _path_50500)
{
    object _25894 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:200		path = expand_path( path, pwd )*/
    RefDS(_path_50500);
    RefDS(_48pwd_50361);
    _0 = _path_50500;
    _path_50500 = _48expand_path(_path_50500, _48pwd_50361);
    DeRefDS(_0);

    /** pathopen.e:202		if not find( path, config_inc_paths ) then*/
    _25894 = find_from(_path_50500, _48config_inc_paths_50358, 1LL);
    if (_25894 != 0)
    goto L1; // [23] 35
    _25894 = NOVALUE;

    /** pathopen.e:203			config_inc_paths = append( config_inc_paths, path )*/
    RefDS(_path_50500);
    Append(&_48config_inc_paths_50358, _48config_inc_paths_50358, _path_50500);
L1: 

    /** pathopen.e:205	end procedure*/
    DeRefDS(_path_50500);
    return;
    ;
}


object _48load_euphoria_config(object _file_50509)
{
    object _fn_50510 = NOVALUE;
    object _in_50511 = NOVALUE;
    object _spos_50512 = NOVALUE;
    object _epos_50513 = NOVALUE;
    object _conf_path_50514 = NOVALUE;
    object _new_args_50515 = NOVALUE;
    object _arg_50516 = NOVALUE;
    object _parm_50517 = NOVALUE;
    object _section_50518 = NOVALUE;
    object _needed_50615 = NOVALUE;
    object _25991 = NOVALUE;
    object _25990 = NOVALUE;
    object _25987 = NOVALUE;
    object _25985 = NOVALUE;
    object _25984 = NOVALUE;
    object _25962 = NOVALUE;
    object _25959 = NOVALUE;
    object _25958 = NOVALUE;
    object _25956 = NOVALUE;
    object _25952 = NOVALUE;
    object _25950 = NOVALUE;
    object _25948 = NOVALUE;
    object _25946 = NOVALUE;
    object _25944 = NOVALUE;
    object _25942 = NOVALUE;
    object _25941 = NOVALUE;
    object _25940 = NOVALUE;
    object _25939 = NOVALUE;
    object _25938 = NOVALUE;
    object _25937 = NOVALUE;
    object _25936 = NOVALUE;
    object _25935 = NOVALUE;
    object _25933 = NOVALUE;
    object _25931 = NOVALUE;
    object _25929 = NOVALUE;
    object _25925 = NOVALUE;
    object _25924 = NOVALUE;
    object _25919 = NOVALUE;
    object _25917 = NOVALUE;
    object _25915 = NOVALUE;
    object _25914 = NOVALUE;
    object _25906 = NOVALUE;
    object _25900 = NOVALUE;
    object _25899 = NOVALUE;
    object _25897 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:213		sequence new_args = {}*/
    RefDS(_21993);
    DeRef(_new_args_50515);
    _new_args_50515 = _21993;

    /** pathopen.e:219		if file_type(file) = FILETYPE_DIRECTORY then*/
    RefDS(_file_50509);
    _25897 = _17file_type(_file_50509);
    if (binary_op_a(NOTEQ, _25897, 2LL)){
        DeRef(_25897);
        _25897 = NOVALUE;
        goto L1; // [18] 53
    }
    DeRef(_25897);
    _25897 = NOVALUE;

    /** pathopen.e:220			if file[$] != SLASH then*/
    if (IS_SEQUENCE(_file_50509)){
            _25899 = SEQ_PTR(_file_50509)->length;
    }
    else {
        _25899 = 1;
    }
    _2 = (object)SEQ_PTR(_file_50509);
    _25900 = (object)*(((s1_ptr)_2)->base + _25899);
    if (binary_op_a(EQUALS, _25900, 47LL)){
        _25900 = NOVALUE;
        goto L2; // [33] 46
    }
    _25900 = NOVALUE;

    /** pathopen.e:221				file &= SLASH*/
    Append(&_file_50509, _file_50509, 47LL);
L2: 

    /** pathopen.e:223			file &= "eu.cfg"*/
    Concat((object_ptr)&_file_50509, _file_50509, _25903);
L1: 

    /** pathopen.e:226		conf_path = canonical_path( file,,CORRECT )*/
    RefDS(_file_50509);
    _0 = _conf_path_50514;
    _conf_path_50514 = _17canonical_path(_file_50509, 0LL, 2LL);
    DeRef(_0);

    /** pathopen.e:229		if find(conf_path, seen_conf) != 0 then*/
    _25906 = find_from(_conf_path_50514, _48seen_conf_50506, 1LL);
    if (_25906 == 0LL)
    goto L3; // [74] 85

    /** pathopen.e:230			return {}*/
    RefDS(_21993);
    DeRefDS(_file_50509);
    DeRefi(_in_50511);
    DeRefDS(_conf_path_50514);
    DeRef(_new_args_50515);
    DeRefi(_arg_50516);
    DeRefi(_parm_50517);
    DeRef(_section_50518);
    return _21993;
L3: 

    /** pathopen.e:232		seen_conf = append(seen_conf, conf_path)*/
    RefDS(_conf_path_50514);
    Append(&_48seen_conf_50506, _48seen_conf_50506, _conf_path_50514);

    /** pathopen.e:234		section = "all"*/
    RefDS(_25909);
    DeRef(_section_50518);
    _section_50518 = _25909;

    /** pathopen.e:235		fn = open( conf_path, "r" )*/
    _fn_50510 = EOpen(_conf_path_50514, _25910, 0LL);

    /** pathopen.e:236		if fn = -1 then return {} end if*/
    if (_fn_50510 != -1LL)
    goto L4; // [109] 118
    RefDS(_21993);
    DeRefDS(_file_50509);
    DeRefi(_in_50511);
    DeRefDS(_conf_path_50514);
    DeRef(_new_args_50515);
    DeRefi(_arg_50516);
    DeRefi(_parm_50517);
    DeRefDSi(_section_50518);
    return _21993;
L4: 

    /** pathopen.e:238		in = gets( fn )*/
    DeRefi(_in_50511);
    _in_50511 = EGets(_fn_50510);

    /** pathopen.e:239		while sequence( in ) do*/
L5: 
    _25914 = IS_SEQUENCE(_in_50511);
    if (_25914 == 0)
    {
        _25914 = NOVALUE;
        goto L6; // [131] 768
    }
    else{
        _25914 = NOVALUE;
    }

    /** pathopen.e:241			spos = 1*/
    _spos_50512 = 1LL;

    /** pathopen.e:242			while spos <= length(in) do*/
L7: 
    if (IS_SEQUENCE(_in_50511)){
            _25915 = SEQ_PTR(_in_50511)->length;
    }
    else {
        _25915 = 1;
    }
    if (_spos_50512 > _25915)
    goto L8; // [147] 182

    /** pathopen.e:243				if find( in[spos], "\n\r \t" ) = 0 then*/
    _2 = (object)SEQ_PTR(_in_50511);
    _25917 = (object)*(((s1_ptr)_2)->base + _spos_50512);
    _25919 = find_from(_25917, _25918, 1LL);
    _25917 = NOVALUE;
    if (_25919 != 0LL)
    goto L9; // [162] 171

    /** pathopen.e:244					exit*/
    goto L8; // [168] 182
L9: 

    /** pathopen.e:246				spos += 1*/
    _spos_50512 = _spos_50512 + 1;

    /** pathopen.e:247			end while*/
    goto L7; // [179] 144
L8: 

    /** pathopen.e:249			epos = length(in)*/
    if (IS_SEQUENCE(_in_50511)){
            _epos_50513 = SEQ_PTR(_in_50511)->length;
    }
    else {
        _epos_50513 = 1;
    }

    /** pathopen.e:250			while epos >= spos do*/
LA: 
    if (_epos_50513 < _spos_50512)
    goto LB; // [192] 227

    /** pathopen.e:251				if find( in[epos], "\n\r \t" ) = 0 then*/
    _2 = (object)SEQ_PTR(_in_50511);
    _25924 = (object)*(((s1_ptr)_2)->base + _epos_50513);
    _25925 = find_from(_25924, _25918, 1LL);
    _25924 = NOVALUE;
    if (_25925 != 0LL)
    goto LC; // [207] 216

    /** pathopen.e:252					exit*/
    goto LB; // [213] 227
LC: 

    /** pathopen.e:254				epos -= 1*/
    _epos_50513 = _epos_50513 - 1LL;

    /** pathopen.e:255			end while*/
    goto LA; // [224] 192
LB: 

    /** pathopen.e:257			in = in[spos .. epos]		*/
    rhs_slice_target = (object_ptr)&_in_50511;
    RHS_Slice(_in_50511, _spos_50512, _epos_50513);

    /** pathopen.e:260			arg = ""*/
    RefDS(_21993);
    DeRefi(_arg_50516);
    _arg_50516 = _21993;

    /** pathopen.e:261			parm = ""*/
    RefDS(_21993);
    DeRefi(_parm_50517);
    _parm_50517 = _21993;

    /** pathopen.e:269			if length(in) > 0 then*/
    if (IS_SEQUENCE(_in_50511)){
            _25929 = SEQ_PTR(_in_50511)->length;
    }
    else {
        _25929 = 1;
    }
    if (_25929 <= 0LL)
    goto LD; // [253] 477

    /** pathopen.e:270				if in[1] = '[' then*/
    _2 = (object)SEQ_PTR(_in_50511);
    _25931 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (_25931 != 91LL)
    goto LE; // [263] 354

    /** pathopen.e:272					section = in[2..$]*/
    if (IS_SEQUENCE(_in_50511)){
            _25933 = SEQ_PTR(_in_50511)->length;
    }
    else {
        _25933 = 1;
    }
    rhs_slice_target = (object_ptr)&_section_50518;
    RHS_Slice(_in_50511, 2LL, _25933);

    /** pathopen.e:273					if length(section) > 0 and section[$] = ']' then*/
    if (IS_SEQUENCE(_section_50518)){
            _25935 = SEQ_PTR(_section_50518)->length;
    }
    else {
        _25935 = 1;
    }
    _25936 = (_25935 > 0LL);
    _25935 = NOVALUE;
    if (_25936 == 0) {
        goto LF; // [286] 320
    }
    if (IS_SEQUENCE(_section_50518)){
            _25938 = SEQ_PTR(_section_50518)->length;
    }
    else {
        _25938 = 1;
    }
    _2 = (object)SEQ_PTR(_section_50518);
    _25939 = (object)*(((s1_ptr)_2)->base + _25938);
    _25940 = (_25939 == 93LL);
    _25939 = NOVALUE;
    if (_25940 == 0)
    {
        DeRef(_25940);
        _25940 = NOVALUE;
        goto LF; // [302] 320
    }
    else{
        DeRef(_25940);
        _25940 = NOVALUE;
    }

    /** pathopen.e:274						section = section[1..$-1]*/
    if (IS_SEQUENCE(_section_50518)){
            _25941 = SEQ_PTR(_section_50518)->length;
    }
    else {
        _25941 = 1;
    }
    _25942 = _25941 - 1LL;
    _25941 = NOVALUE;
    rhs_slice_target = (object_ptr)&_section_50518;
    RHS_Slice(_section_50518, 1LL, _25942);
LF: 

    /** pathopen.e:276					section = lower(trim(section))*/
    RefDS(_section_50518);
    RefDS(_3871);
    _25944 = _14trim(_section_50518, _3871, 0LL);
    _0 = _section_50518;
    _section_50518 = _14lower(_25944);
    DeRefDS(_0);
    _25944 = NOVALUE;

    /** pathopen.e:277					if length(section) = 0 then*/
    if (IS_SEQUENCE(_section_50518)){
            _25946 = SEQ_PTR(_section_50518)->length;
    }
    else {
        _25946 = 1;
    }
    if (_25946 != 0LL)
    goto L10; // [339] 476

    /** pathopen.e:278						section = "all"*/
    RefDS(_25909);
    DeRefDS(_section_50518);
    _section_50518 = _25909;
    goto L10; // [351] 476
LE: 

    /** pathopen.e:281				elsif length(in) > 2 then*/
    if (IS_SEQUENCE(_in_50511)){
            _25948 = SEQ_PTR(_in_50511)->length;
    }
    else {
        _25948 = 1;
    }
    if (_25948 <= 2LL)
    goto L11; // [359] 461

    /** pathopen.e:282					if in[1] = '-' then*/
    _2 = (object)SEQ_PTR(_in_50511);
    _25950 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (_25950 != 45LL)
    goto L12; // [369] 443

    /** pathopen.e:283						if in[2] != '-' then*/
    _2 = (object)SEQ_PTR(_in_50511);
    _25952 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (_25952 == 45LL)
    goto L10; // [379] 476

    /** pathopen.e:284							spos = find(' ', in)*/
    _spos_50512 = find_from(32LL, _in_50511, 1LL);

    /** pathopen.e:285							if spos = 0 then*/
    if (_spos_50512 != 0LL)
    goto L13; // [392] 413

    /** pathopen.e:286								arg = in*/
    Ref(_in_50511);
    DeRefi(_arg_50516);
    _arg_50516 = _in_50511;

    /** pathopen.e:287								parm = ""*/
    RefDS(_21993);
    DeRefi(_parm_50517);
    _parm_50517 = _21993;
    goto L10; // [410] 476
L13: 

    /** pathopen.e:289								arg = in[1..spos - 1]*/
    _25956 = _spos_50512 - 1LL;
    rhs_slice_target = (object_ptr)&_arg_50516;
    RHS_Slice(_in_50511, 1LL, _25956);

    /** pathopen.e:290								parm = in[spos + 1 .. $]*/
    _25958 = _spos_50512 + 1;
    if (_25958 > MAXINT){
        _25958 = NewDouble((eudouble)_25958);
    }
    if (IS_SEQUENCE(_in_50511)){
            _25959 = SEQ_PTR(_in_50511)->length;
    }
    else {
        _25959 = 1;
    }
    rhs_slice_target = (object_ptr)&_parm_50517;
    RHS_Slice(_in_50511, _25958, _25959);
    goto L10; // [440] 476
L12: 

    /** pathopen.e:294						arg = "-i"*/
    RefDS(_25961);
    DeRefi(_arg_50516);
    _arg_50516 = _25961;

    /** pathopen.e:295						parm = in*/
    Ref(_in_50511);
    DeRefi(_parm_50517);
    _parm_50517 = _in_50511;
    goto L10; // [458] 476
L11: 

    /** pathopen.e:298					arg = "-i"*/
    RefDS(_25961);
    DeRefi(_arg_50516);
    _arg_50516 = _25961;

    /** pathopen.e:299					parm = in*/
    Ref(_in_50511);
    DeRefi(_parm_50517);
    _parm_50517 = _in_50511;
L10: 
LD: 

    /** pathopen.e:303			if length(arg) > 0 then*/
    if (IS_SEQUENCE(_arg_50516)){
            _25962 = SEQ_PTR(_arg_50516)->length;
    }
    else {
        _25962 = 1;
    }
    if (_25962 <= 0LL)
    goto L14; // [482] 756

    /** pathopen.e:304				integer needed = 0*/
    _needed_50615 = 0LL;

    /** pathopen.e:305				switch section do*/
    _1 = find(_section_50518, _25964);
    switch ( _1 ){ 

        /** pathopen.e:306					case "all" then*/
        case 1:

        /** pathopen.e:307						needed = 1*/
        _needed_50615 = 1LL;
        goto L15; // [507] 691

        /** pathopen.e:309					case "windows" then*/
        case 2:

        /** pathopen.e:310						needed = TWINDOWS*/
        _needed_50615 = _46TWINDOWS_21586;
        goto L15; // [522] 691

        /** pathopen.e:312					case "unix" then*/
        case 3:

        /** pathopen.e:313						needed = TUNIX*/
        _needed_50615 = _46TUNIX_21590;
        goto L15; // [537] 691

        /** pathopen.e:315					case "translate" then*/
        case 4:

        /** pathopen.e:316						needed = TRANSLATE*/
        _needed_50615 = _36TRANSLATE_21041;
        goto L15; // [552] 691

        /** pathopen.e:318					case "translate:windows" then*/
        case 5:

        /** pathopen.e:319						needed = TRANSLATE and TWINDOWS*/
        _needed_50615 = (_36TRANSLATE_21041 != 0 && _46TWINDOWS_21586 != 0);
        goto L15; // [570] 691

        /** pathopen.e:321					case "translate:unix" then*/
        case 6:

        /** pathopen.e:322						needed = TRANSLATE and TUNIX*/
        _needed_50615 = (_36TRANSLATE_21041 != 0 && _46TUNIX_21590 != 0);
        goto L15; // [588] 691

        /** pathopen.e:324					case "interpret" then*/
        case 7:

        /** pathopen.e:325						needed = INTERPRET*/
        _needed_50615 = _36INTERPRET_21038;
        goto L15; // [603] 691

        /** pathopen.e:327					case "interpret:windows" then*/
        case 8:

        /** pathopen.e:328						needed = INTERPRET and TWINDOWS*/
        _needed_50615 = (_36INTERPRET_21038 != 0 && _46TWINDOWS_21586 != 0);
        goto L15; // [621] 691

        /** pathopen.e:330					case "interpret:unix" then*/
        case 9:

        /** pathopen.e:331						needed = INTERPRET and TUNIX*/
        _needed_50615 = (_36INTERPRET_21038 != 0 && _46TUNIX_21590 != 0);
        goto L15; // [639] 691

        /** pathopen.e:333					case "bind" then*/
        case 10:

        /** pathopen.e:334						needed = BIND*/
        _needed_50615 = _36BIND_21044;
        goto L15; // [654] 691

        /** pathopen.e:336					case "bind:windows" then*/
        case 11:

        /** pathopen.e:337						needed = BIND and TWINDOWS*/
        _needed_50615 = (_36BIND_21044 != 0 && _46TWINDOWS_21586 != 0);
        goto L15; // [672] 691

        /** pathopen.e:339					case "bind:unix" then*/
        case 12:

        /** pathopen.e:340						needed = BIND and TUNIX*/
        _needed_50615 = (_36BIND_21044 != 0 && _46TUNIX_21590 != 0);
    ;}L15: 

    /** pathopen.e:344				if needed then*/
    if (_needed_50615 == 0)
    {
        goto L16; // [693] 755
    }
    else{
    }

    /** pathopen.e:345					if equal(arg, "-c") then*/
    if (_arg_50516 == _25983)
    _25984 = 1;
    else if (IS_ATOM_INT(_arg_50516) && IS_ATOM_INT(_25983))
    _25984 = 0;
    else
    _25984 = (compare(_arg_50516, _25983) == 0);
    if (_25984 == 0)
    {
        _25984 = NOVALUE;
        goto L17; // [702] 728
    }
    else{
        _25984 = NOVALUE;
    }

    /** pathopen.e:346						if length(parm) > 0 then*/
    if (IS_SEQUENCE(_parm_50517)){
            _25985 = SEQ_PTR(_parm_50517)->length;
    }
    else {
        _25985 = 1;
    }
    if (_25985 <= 0LL)
    goto L18; // [710] 754

    /** pathopen.e:347							new_args &= load_euphoria_config(parm)*/
    RefDS(_parm_50517);
    _25987 = _48load_euphoria_config(_parm_50517);
    if (IS_SEQUENCE(_new_args_50515) && IS_ATOM(_25987)) {
        Ref(_25987);
        Append(&_new_args_50515, _new_args_50515, _25987);
    }
    else if (IS_ATOM(_new_args_50515) && IS_SEQUENCE(_25987)) {
    }
    else {
        Concat((object_ptr)&_new_args_50515, _new_args_50515, _25987);
    }
    DeRef(_25987);
    _25987 = NOVALUE;
    goto L18; // [725] 754
L17: 

    /** pathopen.e:350						new_args = append(new_args, arg)*/
    RefDS(_arg_50516);
    Append(&_new_args_50515, _new_args_50515, _arg_50516);

    /** pathopen.e:351						if length(parm > 0) then*/
    _25990 = binary_op(GREATER, _parm_50517, 0LL);
    if (IS_SEQUENCE(_25990)){
            _25991 = SEQ_PTR(_25990)->length;
    }
    else {
        _25991 = 1;
    }
    DeRefDS(_25990);
    _25990 = NOVALUE;
    if (_25991 == 0)
    {
        _25991 = NOVALUE;
        goto L19; // [743] 753
    }
    else{
        _25991 = NOVALUE;
    }

    /** pathopen.e:352							new_args = append(new_args, parm)*/
    RefDS(_parm_50517);
    Append(&_new_args_50515, _new_args_50515, _parm_50517);
L19: 
L18: 
L16: 
L14: 

    /** pathopen.e:358			in = gets( fn )*/
    DeRefi(_in_50511);
    _in_50511 = EGets(_fn_50510);

    /** pathopen.e:359		end while*/
    goto L5; // [765] 128
L6: 

    /** pathopen.e:360		close(fn)*/
    EClose(_fn_50510);

    /** pathopen.e:362		return new_args*/
    DeRefDS(_file_50509);
    DeRefi(_in_50511);
    DeRef(_conf_path_50514);
    DeRefi(_arg_50516);
    DeRefi(_parm_50517);
    DeRef(_section_50518);
    _25952 = NOVALUE;
    DeRef(_25936);
    _25936 = NOVALUE;
    DeRef(_25956);
    _25956 = NOVALUE;
    DeRef(_25958);
    _25958 = NOVALUE;
    _25950 = NOVALUE;
    _25990 = NOVALUE;
    _25931 = NOVALUE;
    DeRef(_25942);
    _25942 = NOVALUE;
    return _new_args_50515;
    ;
}


object _48GetDefaultArgs(object _user_files_50682)
{
    object _env_50683 = NOVALUE;
    object _default_args_50684 = NOVALUE;
    object _conf_file_50685 = NOVALUE;
    object _cmd_options_50687 = NOVALUE;
    object _user_config_50693 = NOVALUE;
    object _26026 = NOVALUE;
    object _26025 = NOVALUE;
    object _26024 = NOVALUE;
    object _26016 = NOVALUE;
    object _26015 = NOVALUE;
    object _26013 = NOVALUE;
    object _26010 = NOVALUE;
    object _26009 = NOVALUE;
    object _26006 = NOVALUE;
    object _26005 = NOVALUE;
    object _26003 = NOVALUE;
    object _26001 = NOVALUE;
    object _26000 = NOVALUE;
    object _25996 = NOVALUE;
    object _25995 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:367		sequence default_args = {}*/
    RefDS(_21993);
    DeRef(_default_args_50684);
    _default_args_50684 = _21993;

    /** pathopen.e:368		sequence conf_file = "eu.cfg"*/
    RefDS(_25903);
    DeRefi(_conf_file_50685);
    _conf_file_50685 = _25903;

    /** pathopen.e:370		if loaded_config_inc_paths then return "" end if*/
    if (_48loaded_config_inc_paths_50359 == 0)
    {
        goto L1; // [21] 29
    }
    else{
    }
    RefDS(_21993);
    DeRefDS(_user_files_50682);
    DeRef(_env_50683);
    DeRefDS(_default_args_50684);
    DeRefDSi(_conf_file_50685);
    DeRef(_cmd_options_50687);
    return _21993;
L1: 

    /** pathopen.e:371		loaded_config_inc_paths = 1*/
    _48loaded_config_inc_paths_50359 = 1LL;

    /** pathopen.e:380		sequence cmd_options = get_options()*/
    _0 = _cmd_options_50687;
    _cmd_options_50687 = _49get_options();
    DeRef(_0);

    /** pathopen.e:382		default_args = {}*/
    RefDS(_21993);
    DeRef(_default_args_50684);
    _default_args_50684 = _21993;

    /** pathopen.e:385		for i = 1 to length( user_files ) do*/
    if (IS_SEQUENCE(_user_files_50682)){
            _25995 = SEQ_PTR(_user_files_50682)->length;
    }
    else {
        _25995 = 1;
    }
    {
        object _i_50691;
        _i_50691 = 1LL;
L2: 
        if (_i_50691 > _25995){
            goto L3; // [53] 92
        }

        /** pathopen.e:386			sequence user_config = load_euphoria_config( user_files[i] )*/
        _2 = (object)SEQ_PTR(_user_files_50682);
        _25996 = (object)*(((s1_ptr)_2)->base + _i_50691);
        Ref(_25996);
        _0 = _user_config_50693;
        _user_config_50693 = _48load_euphoria_config(_25996);
        DeRef(_0);
        _25996 = NOVALUE;

        /** pathopen.e:387			default_args = merge_parameters( user_config, default_args, cmd_options, 1 )*/
        RefDS(_user_config_50693);
        RefDS(_default_args_50684);
        RefDS(_cmd_options_50687);
        _0 = _default_args_50684;
        _default_args_50684 = _49merge_parameters(_user_config_50693, _default_args_50684, _cmd_options_50687, 1LL);
        DeRefDS(_0);
        DeRefDS(_user_config_50693);
        _user_config_50693 = NOVALUE;

        /** pathopen.e:388		end for*/
        _i_50691 = _i_50691 + 1LL;
        goto L2; // [87] 60
L3: 
        ;
    }

    /** pathopen.e:391		default_args = merge_parameters( load_euphoria_config("./" & conf_file), default_args, cmd_options, 1 )*/
    Concat((object_ptr)&_26000, _25999, _conf_file_50685);
    _26001 = _48load_euphoria_config(_26000);
    _26000 = NOVALUE;
    RefDS(_default_args_50684);
    RefDS(_cmd_options_50687);
    _0 = _default_args_50684;
    _default_args_50684 = _49merge_parameters(_26001, _default_args_50684, _cmd_options_50687, 1LL);
    DeRefDS(_0);
    _26001 = NOVALUE;

    /** pathopen.e:394		env = strip_file_from_path( exe_path() )*/
    _26003 = _48exe_path();
    _0 = _env_50683;
    _env_50683 = _48strip_file_from_path(_26003);
    DeRef(_0);
    _26003 = NOVALUE;

    /** pathopen.e:395		default_args = merge_parameters( load_euphoria_config( env & conf_file ), default_args, cmd_options, 1 )*/
    if (IS_SEQUENCE(_env_50683) && IS_ATOM(_conf_file_50685)) {
    }
    else if (IS_ATOM(_env_50683) && IS_SEQUENCE(_conf_file_50685)) {
        Ref(_env_50683);
        Prepend(&_26005, _conf_file_50685, _env_50683);
    }
    else {
        Concat((object_ptr)&_26005, _env_50683, _conf_file_50685);
    }
    _26006 = _48load_euphoria_config(_26005);
    _26005 = NOVALUE;
    RefDS(_default_args_50684);
    RefDS(_cmd_options_50687);
    _0 = _default_args_50684;
    _default_args_50684 = _49merge_parameters(_26006, _default_args_50684, _cmd_options_50687, 1LL);
    DeRefDS(_0);
    _26006 = NOVALUE;

    /** pathopen.e:398		ifdef UNIX then*/

    /** pathopen.e:399			default_args = merge_parameters( load_euphoria_config( "/etc/euphoria/" & conf_file ), default_args, cmd_options, 1 )*/
    Concat((object_ptr)&_26009, _26008, _conf_file_50685);
    _26010 = _48load_euphoria_config(_26009);
    _26009 = NOVALUE;
    RefDS(_default_args_50684);
    RefDS(_cmd_options_50687);
    _0 = _default_args_50684;
    _default_args_50684 = _49merge_parameters(_26010, _default_args_50684, _cmd_options_50687, 1LL);
    DeRefDS(_0);
    _26010 = NOVALUE;

    /** pathopen.e:401			env = getenv( "HOME" )*/
    DeRef(_env_50683);
    _env_50683 = EGetEnv(_25874);

    /** pathopen.e:402			if sequence(env) then*/
    _26013 = IS_SEQUENCE(_env_50683);
    if (_26013 == 0)
    {
        _26013 = NOVALUE;
        goto L4; // [170] 195
    }
    else{
        _26013 = NOVALUE;
    }

    /** pathopen.e:403				default_args = merge_parameters( load_euphoria_config( env & "/." & conf_file ), default_args, cmd_options, 1 )*/
    {
        object concat_list[3];

        concat_list[0] = _conf_file_50685;
        concat_list[1] = _26014;
        concat_list[2] = _env_50683;
        Concat_N((object_ptr)&_26015, concat_list, 3);
    }
    _26016 = _48load_euphoria_config(_26015);
    _26015 = NOVALUE;
    RefDS(_default_args_50684);
    RefDS(_cmd_options_50687);
    _0 = _default_args_50684;
    _default_args_50684 = _49merge_parameters(_26016, _default_args_50684, _cmd_options_50687, 1LL);
    DeRefDS(_0);
    _26016 = NOVALUE;
L4: 

    /** pathopen.e:427		env = get_eudir()*/
    _0 = _env_50683;
    _env_50683 = _37get_eudir();
    DeRef(_0);

    /** pathopen.e:428		if sequence(env) then*/
    _26024 = IS_SEQUENCE(_env_50683);
    if (_26024 == 0)
    {
        _26024 = NOVALUE;
        goto L5; // [205] 230
    }
    else{
        _26024 = NOVALUE;
    }

    /** pathopen.e:429			default_args = merge_parameters( load_euphoria_config(env & "/" & conf_file), default_args, cmd_options, 1 )*/
    {
        object concat_list[3];

        concat_list[0] = _conf_file_50685;
        concat_list[1] = _23574;
        concat_list[2] = _env_50683;
        Concat_N((object_ptr)&_26025, concat_list, 3);
    }
    _26026 = _48load_euphoria_config(_26025);
    _26025 = NOVALUE;
    RefDS(_default_args_50684);
    RefDS(_cmd_options_50687);
    _0 = _default_args_50684;
    _default_args_50684 = _49merge_parameters(_26026, _default_args_50684, _cmd_options_50687, 1LL);
    DeRefDS(_0);
    _26026 = NOVALUE;
L5: 

    /** pathopen.e:432		return default_args*/
    DeRefDS(_user_files_50682);
    DeRef(_env_50683);
    DeRefi(_conf_file_50685);
    DeRef(_cmd_options_50687);
    return _default_args_50684;
    ;
}


object _48ConfPath(object _file_name_50737)
{
    object _file_path_50738 = NOVALUE;
    object _try_50739 = NOVALUE;
    object _26033 = NOVALUE;
    object _26029 = NOVALUE;
    object _26028 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:440		for i = 1 to length(config_inc_paths) do*/
    if (IS_SEQUENCE(_48config_inc_paths_50358)){
            _26028 = SEQ_PTR(_48config_inc_paths_50358)->length;
    }
    else {
        _26028 = 1;
    }
    {
        object _i_50741;
        _i_50741 = 1LL;
L1: 
        if (_i_50741 > _26028){
            goto L2; // [10] 60
        }

        /** pathopen.e:441			file_path = config_inc_paths[i] & file_name*/
        _2 = (object)SEQ_PTR(_48config_inc_paths_50358);
        _26029 = (object)*(((s1_ptr)_2)->base + _i_50741);
        Concat((object_ptr)&_file_path_50738, _26029, _file_name_50737);
        _26029 = NOVALUE;
        _26029 = NOVALUE;

        /** pathopen.e:442			try = open( file_path, "r" )*/
        _try_50739 = EOpen(_file_path_50738, _25910, 0LL);

        /** pathopen.e:443			if try != -1 then*/
        if (_try_50739 == -1LL)
        goto L3; // [38] 53

        /** pathopen.e:444				return {file_path, try}*/
        RefDS(_file_path_50738);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_50738;
        ((intptr_t *)_2)[2] = _try_50739;
        _26033 = MAKE_SEQ(_1);
        DeRefDS(_file_name_50737);
        DeRefDS(_file_path_50738);
        return _26033;
L3: 

        /** pathopen.e:446		end for*/
        _i_50741 = _i_50741 + 1LL;
        goto L1; // [55] 17
L2: 
        ;
    }

    /** pathopen.e:447		return -1*/
    DeRefDS(_file_name_50737);
    DeRef(_file_path_50738);
    DeRef(_26033);
    _26033 = NOVALUE;
    return -1LL;
    ;
}


object _48ScanPath(object _file_name_50751, object _env_50752, object _flag_50753)
{
    object _inc_path_50754 = NOVALUE;
    object _full_path_50755 = NOVALUE;
    object _file_path_50756 = NOVALUE;
    object _strings_50757 = NOVALUE;
    object _end_path_50758 = NOVALUE;
    object _start_path_50759 = NOVALUE;
    object _try_50760 = NOVALUE;
    object _use_cache_50761 = NOVALUE;
    object _pos_50762 = NOVALUE;
    object _26081 = NOVALUE;
    object _26080 = NOVALUE;
    object _26079 = NOVALUE;
    object _26078 = NOVALUE;
    object _26077 = NOVALUE;
    object _26076 = NOVALUE;
    object _26075 = NOVALUE;
    object _26074 = NOVALUE;
    object _26070 = NOVALUE;
    object _26069 = NOVALUE;
    object _26068 = NOVALUE;
    object _26067 = NOVALUE;
    object _26066 = NOVALUE;
    object _26065 = NOVALUE;
    object _26063 = NOVALUE;
    object _26061 = NOVALUE;
    object _26060 = NOVALUE;
    object _26058 = NOVALUE;
    object _26057 = NOVALUE;
    object _26056 = NOVALUE;
    object _26053 = NOVALUE;
    object _26052 = NOVALUE;
    object _26050 = NOVALUE;
    object _26049 = NOVALUE;
    object _26048 = NOVALUE;
    object _26043 = NOVALUE;
    object _26035 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:459		inc_path = getenv(env)*/
    DeRefi(_inc_path_50754);
    _inc_path_50754 = EGetEnv(_env_50752);

    /** pathopen.e:460		if compare(inc_path,{})!=1 then -- nothing to do, just fail*/
    if (IS_ATOM_INT(_inc_path_50754) && IS_ATOM_INT(_21993)){
        _26035 = (_inc_path_50754 < _21993) ? -1 : (_inc_path_50754 > _21993);
    }
    else{
        _26035 = compare(_inc_path_50754, _21993);
    }
    if (_26035 == 1LL)
    goto L1; // [18] 29

    /** pathopen.e:461			return -1*/
    DeRefDS(_file_name_50751);
    DeRefDSi(_env_50752);
    DeRefi(_inc_path_50754);
    DeRef(_full_path_50755);
    DeRef(_file_path_50756);
    DeRef(_strings_50757);
    return -1LL;
L1: 

    /** pathopen.e:464		num_var = find(env,cache_vars)*/
    _48num_var_50349 = find_from(_env_50752, _48cache_vars_50350, 1LL);

    /** pathopen.e:465		use_cache = check_cache(env,inc_path)*/
    RefDS(_env_50752);
    Ref(_inc_path_50754);
    _use_cache_50761 = _48check_cache(_env_50752, _inc_path_50754);
    if (!IS_ATOM_INT(_use_cache_50761)) {
        _1 = (object)(DBL_PTR(_use_cache_50761)->dbl);
        DeRefDS(_use_cache_50761);
        _use_cache_50761 = _1;
    }

    /** pathopen.e:466		inc_path = append(inc_path, PATH_SEPARATOR)*/
    Append(&_inc_path_50754, _inc_path_50754, 58LL);

    /** pathopen.e:468		file_name = SLASH & file_name*/
    Prepend(&_file_name_50751, _file_name_50751, 47LL);

    /** pathopen.e:469		if flag then*/
    if (_flag_50753 == 0)
    {
        goto L2; // [65] 77
    }
    else{
    }

    /** pathopen.e:470			file_name = include_subfolder & file_name*/
    Concat((object_ptr)&_file_name_50751, _48include_subfolder_50345, _file_name_50751);
L2: 

    /** pathopen.e:472		strings = cache_substrings[num_var]*/
    DeRef(_strings_50757);
    _2 = (object)SEQ_PTR(_48cache_substrings_50352);
    _strings_50757 = (object)*(((s1_ptr)_2)->base + _48num_var_50349);
    RefDS(_strings_50757);

    /** pathopen.e:474		if use_cache then*/
    if (_use_cache_50761 == 0)
    {
        goto L3; // [91] 194
    }
    else{
    }

    /** pathopen.e:475			for i=1 to length(strings) do*/
    if (IS_SEQUENCE(_strings_50757)){
            _26043 = SEQ_PTR(_strings_50757)->length;
    }
    else {
        _26043 = 1;
    }
    {
        object _i_50778;
        _i_50778 = 1LL;
L4: 
        if (_i_50778 > _26043){
            goto L5; // [99] 154
        }

        /** pathopen.e:476				full_path = strings[i]*/
        DeRef(_full_path_50755);
        _2 = (object)SEQ_PTR(_strings_50757);
        _full_path_50755 = (object)*(((s1_ptr)_2)->base + _i_50778);
        Ref(_full_path_50755);

        /** pathopen.e:477				file_path = full_path & file_name*/
        Concat((object_ptr)&_file_path_50756, _full_path_50755, _file_name_50751);

        /** pathopen.e:478				try = open_locked(file_path)    */
        RefDS(_file_path_50756);
        _try_50760 = _37open_locked(_file_path_50756);
        if (!IS_ATOM_INT(_try_50760)) {
            _1 = (object)(DBL_PTR(_try_50760)->dbl);
            DeRefDS(_try_50760);
            _try_50760 = _1;
        }

        /** pathopen.e:479				if try != -1 then*/
        if (_try_50760 == -1LL)
        goto L6; // [130] 145

        /** pathopen.e:480					return {file_path,try}*/
        RefDS(_file_path_50756);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_50756;
        ((intptr_t *)_2)[2] = _try_50760;
        _26048 = MAKE_SEQ(_1);
        DeRefDS(_file_name_50751);
        DeRefDSi(_env_50752);
        DeRefi(_inc_path_50754);
        DeRefDS(_full_path_50755);
        DeRefDS(_file_path_50756);
        DeRefDS(_strings_50757);
        return _26048;
L6: 

        /** pathopen.e:482				ifdef WINDOWS then */

        /** pathopen.e:496			end for*/
        _i_50778 = _i_50778 + 1LL;
        goto L4; // [149] 106
L5: 
        ;
    }

    /** pathopen.e:497			if cache_complete[num_var] then -- nothing to scan*/
    _2 = (object)SEQ_PTR(_48cache_complete_50356);
    _26049 = (object)*(((s1_ptr)_2)->base + _48num_var_50349);
    if (_26049 == 0)
    {
        _26049 = NOVALUE;
        goto L7; // [164] 176
    }
    else{
        _26049 = NOVALUE;
    }

    /** pathopen.e:498				return -1*/
    DeRefDS(_file_name_50751);
    DeRefDSi(_env_50752);
    DeRefi(_inc_path_50754);
    DeRef(_full_path_50755);
    DeRef(_file_path_50756);
    DeRef(_strings_50757);
    DeRef(_26048);
    _26048 = NOVALUE;
    return -1LL;
    goto L8; // [173] 200
L7: 

    /** pathopen.e:500				pos = cache_delims[num_var]+1 -- scan remainder, starting from as far sa possible*/
    _2 = (object)SEQ_PTR(_48cache_delims_50357);
    _26050 = (object)*(((s1_ptr)_2)->base + _48num_var_50349);
    _pos_50762 = _26050 + 1;
    _26050 = NOVALUE;
    goto L8; // [191] 200
L3: 

    /** pathopen.e:503			pos = 1*/
    _pos_50762 = 1LL;
L8: 

    /** pathopen.e:506		start_path = 0*/
    _start_path_50759 = 0LL;

    /** pathopen.e:507		for p = pos to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_50754)){
            _26052 = SEQ_PTR(_inc_path_50754)->length;
    }
    else {
        _26052 = 1;
    }
    {
        object _p_50794;
        _p_50794 = _pos_50762;
L9: 
        if (_p_50794 > _26052){
            goto LA; // [212] 460
        }

        /** pathopen.e:508			if inc_path[p] = PATH_SEPARATOR then*/
        _2 = (object)SEQ_PTR(_inc_path_50754);
        _26053 = (object)*(((s1_ptr)_2)->base + _p_50794);
        if (_26053 != 58LL)
        goto LB; // [227] 409

        /** pathopen.e:510				cache_delims[num_var] = p*/
        _2 = (object)SEQ_PTR(_48cache_delims_50357);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_delims_50357 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50349);
        *(intptr_t *)_2 = _p_50794;

        /** pathopen.e:512				end_path = p-1*/
        _end_path_50758 = _p_50794 - 1LL;

        /** pathopen.e:513				while end_path >= start_path and find(inc_path[end_path], " \t" & SLASH_CHARS) do*/
LC: 
        _26056 = (_end_path_50758 >= _start_path_50759);
        if (_26056 == 0) {
            goto LD; // [256] 290
        }
        _2 = (object)SEQ_PTR(_inc_path_50754);
        _26058 = (object)*(((s1_ptr)_2)->base + _end_path_50758);
        Concat((object_ptr)&_26060, _26059, _46SLASH_CHARS_21606);
        _26061 = find_from(_26058, _26060, 1LL);
        _26058 = NOVALUE;
        DeRefDS(_26060);
        _26060 = NOVALUE;
        if (_26061 == 0)
        {
            _26061 = NOVALUE;
            goto LD; // [276] 290
        }
        else{
            _26061 = NOVALUE;
        }

        /** pathopen.e:514					end_path-=1*/
        _end_path_50758 = _end_path_50758 - 1LL;

        /** pathopen.e:515				end while*/
        goto LC; // [287] 252
LD: 

        /** pathopen.e:517				if start_path and end_path then*/
        if (_start_path_50759 == 0) {
            goto LE; // [292] 453
        }
        if (_end_path_50758 == 0)
        {
            goto LE; // [297] 453
        }
        else{
        }

        /** pathopen.e:518					full_path = inc_path[start_path..end_path]*/
        rhs_slice_target = (object_ptr)&_full_path_50755;
        RHS_Slice(_inc_path_50754, _start_path_50759, _end_path_50758);

        /** pathopen.e:519					cache_substrings[num_var] = append(cache_substrings[num_var],full_path)*/
        _2 = (object)SEQ_PTR(_48cache_substrings_50352);
        _26065 = (object)*(((s1_ptr)_2)->base + _48num_var_50349);
        RefDS(_full_path_50755);
        Append(&_26066, _26065, _full_path_50755);
        _26065 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_substrings_50352);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_substrings_50352 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50349);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26066;
        if( _1 != _26066 ){
            DeRefDS(_1);
        }
        _26066 = NOVALUE;

        /** pathopen.e:520					cache_starts[num_var] &= start_path*/
        _2 = (object)SEQ_PTR(_48cache_starts_50353);
        _26067 = (object)*(((s1_ptr)_2)->base + _48num_var_50349);
        if (IS_SEQUENCE(_26067) && IS_ATOM(_start_path_50759)) {
            Append(&_26068, _26067, _start_path_50759);
        }
        else if (IS_ATOM(_26067) && IS_SEQUENCE(_start_path_50759)) {
        }
        else {
            Concat((object_ptr)&_26068, _26067, _start_path_50759);
            _26067 = NOVALUE;
        }
        _26067 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_starts_50353);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_starts_50353 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50349);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26068;
        if( _1 != _26068 ){
            DeRef(_1);
        }
        _26068 = NOVALUE;

        /** pathopen.e:521					cache_ends[num_var] &= end_path*/
        _2 = (object)SEQ_PTR(_48cache_ends_50354);
        _26069 = (object)*(((s1_ptr)_2)->base + _48num_var_50349);
        if (IS_SEQUENCE(_26069) && IS_ATOM(_end_path_50758)) {
            Append(&_26070, _26069, _end_path_50758);
        }
        else if (IS_ATOM(_26069) && IS_SEQUENCE(_end_path_50758)) {
        }
        else {
            Concat((object_ptr)&_26070, _26069, _end_path_50758);
            _26069 = NOVALUE;
        }
        _26069 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_ends_50354);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_ends_50354 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50349);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26070;
        if( _1 != _26070 ){
            DeRef(_1);
        }
        _26070 = NOVALUE;

        /** pathopen.e:522					file_path = full_path & file_name  */
        Concat((object_ptr)&_file_path_50756, _full_path_50755, _file_name_50751);

        /** pathopen.e:523					try = open_locked(file_path)*/
        RefDS(_file_path_50756);
        _try_50760 = _37open_locked(_file_path_50756);
        if (!IS_ATOM_INT(_try_50760)) {
            _1 = (object)(DBL_PTR(_try_50760)->dbl);
            DeRefDS(_try_50760);
            _try_50760 = _1;
        }

        /** pathopen.e:524					if try != -1 then -- valid path, no point trying to convert*/
        if (_try_50760 == -1LL)
        goto LF; // [381] 398

        /** pathopen.e:525						ifdef WINDOWS then*/

        /** pathopen.e:528						return {file_path,try}*/
        RefDS(_file_path_50756);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_50756;
        ((intptr_t *)_2)[2] = _try_50760;
        _26074 = MAKE_SEQ(_1);
        DeRefDS(_file_name_50751);
        DeRefDSi(_env_50752);
        DeRefi(_inc_path_50754);
        DeRefDSi(_full_path_50755);
        DeRefDS(_file_path_50756);
        DeRef(_strings_50757);
        _26053 = NOVALUE;
        DeRef(_26056);
        _26056 = NOVALUE;
        DeRef(_26048);
        _26048 = NOVALUE;
        return _26074;
LF: 

        /** pathopen.e:530					ifdef WINDOWS then*/

        /** pathopen.e:547					start_path = 0*/
        _start_path_50759 = 0LL;
        goto LE; // [406] 453
LB: 

        /** pathopen.e:549			elsif not start_path and (inc_path[p] != ' ' and inc_path[p] != '\t') then*/
        _26075 = (_start_path_50759 == 0);
        if (_26075 == 0) {
            goto L10; // [414] 452
        }
        _2 = (object)SEQ_PTR(_inc_path_50754);
        _26077 = (object)*(((s1_ptr)_2)->base + _p_50794);
        _26078 = (_26077 != 32LL);
        _26077 = NOVALUE;
        if (_26078 == 0) {
            DeRef(_26079);
            _26079 = 0;
            goto L11; // [426] 442
        }
        _2 = (object)SEQ_PTR(_inc_path_50754);
        _26080 = (object)*(((s1_ptr)_2)->base + _p_50794);
        _26081 = (_26080 != 9LL);
        _26080 = NOVALUE;
        _26079 = (_26081 != 0);
L11: 
        if (_26079 == 0)
        {
            _26079 = NOVALUE;
            goto L10; // [443] 452
        }
        else{
            _26079 = NOVALUE;
        }

        /** pathopen.e:550				start_path = p*/
        _start_path_50759 = _p_50794;
L10: 
LE: 

        /** pathopen.e:552		end for*/
        _p_50794 = _p_50794 + 1LL;
        goto L9; // [455] 219
LA: 
        ;
    }

    /** pathopen.e:554		cache_complete[num_var] = 1*/
    _2 = (object)SEQ_PTR(_48cache_complete_50356);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _48cache_complete_50356 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _48num_var_50349);
    *(intptr_t *)_2 = 1LL;

    /** pathopen.e:555		return -1*/
    DeRefDS(_file_name_50751);
    DeRefDSi(_env_50752);
    DeRefi(_inc_path_50754);
    DeRef(_full_path_50755);
    DeRef(_file_path_50756);
    DeRef(_strings_50757);
    _26053 = NOVALUE;
    DeRef(_26081);
    _26081 = NOVALUE;
    DeRef(_26075);
    _26075 = NOVALUE;
    DeRef(_26078);
    _26078 = NOVALUE;
    DeRef(_26056);
    _26056 = NOVALUE;
    DeRef(_26074);
    _26074 = NOVALUE;
    DeRef(_26048);
    _26048 = NOVALUE;
    return -1LL;
    ;
}


object _48Include_paths(object _add_converted_50836)
{
    object _status_50837 = NOVALUE;
    object _pos_50838 = NOVALUE;
    object _inc_path_50839 = NOVALUE;
    object _full_path_50840 = NOVALUE;
    object _start_path_50841 = NOVALUE;
    object _end_path_50842 = NOVALUE;
    object _eudir_path_50858 = NOVALUE;
    object _26127 = NOVALUE;
    object _26126 = NOVALUE;
    object _26125 = NOVALUE;
    object _26124 = NOVALUE;
    object _26123 = NOVALUE;
    object _26122 = NOVALUE;
    object _26121 = NOVALUE;
    object _26120 = NOVALUE;
    object _26119 = NOVALUE;
    object _26118 = NOVALUE;
    object _26117 = NOVALUE;
    object _26116 = NOVALUE;
    object _26115 = NOVALUE;
    object _26114 = NOVALUE;
    object _26112 = NOVALUE;
    object _26110 = NOVALUE;
    object _26109 = NOVALUE;
    object _26108 = NOVALUE;
    object _26107 = NOVALUE;
    object _26106 = NOVALUE;
    object _26103 = NOVALUE;
    object _26102 = NOVALUE;
    object _26100 = NOVALUE;
    object _26098 = NOVALUE;
    object _26096 = NOVALUE;
    object _26095 = NOVALUE;
    object _26093 = NOVALUE;
    object _26090 = NOVALUE;
    object _26088 = NOVALUE;
    object _26083 = NOVALUE;
    object _26082 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_add_converted_50836)) {
        _1 = (object)(DBL_PTR(_add_converted_50836)->dbl);
        DeRefDS(_add_converted_50836);
        _add_converted_50836 = _1;
    }

    /** pathopen.e:566		if length(include_Paths) then*/
    if (IS_SEQUENCE(_48include_Paths_50833)){
            _26082 = SEQ_PTR(_48include_Paths_50833)->length;
    }
    else {
        _26082 = 1;
    }
    if (_26082 == 0)
    {
        _26082 = NOVALUE;
        goto L1; // [10] 22
    }
    else{
        _26082 = NOVALUE;
    }

    /** pathopen.e:567			return include_Paths*/
    RefDS(_48include_Paths_50833);
    DeRefi(_inc_path_50839);
    DeRefi(_full_path_50840);
    DeRef(_eudir_path_50858);
    return _48include_Paths_50833;
L1: 

    /** pathopen.e:570		include_Paths = append(config_inc_paths, current_dir())*/
    _26083 = _17current_dir();
    Ref(_26083);
    Append(&_48include_Paths_50833, _48config_inc_paths_50358, _26083);
    DeRef(_26083);
    _26083 = NOVALUE;

    /** pathopen.e:571		num_var = find("EUINC", cache_vars)*/
    _48num_var_50349 = find_from(_26085, _48cache_vars_50350, 1LL);

    /** pathopen.e:572		inc_path = getenv("EUINC")*/
    DeRefi(_inc_path_50839);
    _inc_path_50839 = EGetEnv(_26085);

    /** pathopen.e:573		if atom(inc_path) then*/
    _26088 = IS_ATOM(_inc_path_50839);
    if (_26088 == 0)
    {
        _26088 = NOVALUE;
        goto L2; // [52] 61
    }
    else{
        _26088 = NOVALUE;
    }

    /** pathopen.e:574			inc_path = ""*/
    RefDS(_21993);
    DeRefi(_inc_path_50839);
    _inc_path_50839 = _21993;
L2: 

    /** pathopen.e:576		status = check_cache("EUINC", inc_path)*/
    RefDS(_26085);
    Ref(_inc_path_50839);
    _status_50837 = _48check_cache(_26085, _inc_path_50839);
    if (!IS_ATOM_INT(_status_50837)) {
        _1 = (object)(DBL_PTR(_status_50837)->dbl);
        DeRefDS(_status_50837);
        _status_50837 = _1;
    }

    /** pathopen.e:577		if length(inc_path) then*/
    if (IS_SEQUENCE(_inc_path_50839)){
            _26090 = SEQ_PTR(_inc_path_50839)->length;
    }
    else {
        _26090 = 1;
    }
    if (_26090 == 0)
    {
        _26090 = NOVALUE;
        goto L3; // [75] 87
    }
    else{
        _26090 = NOVALUE;
    }

    /** pathopen.e:578			inc_path = append(inc_path, PATH_SEPARATOR)*/
    Append(&_inc_path_50839, _inc_path_50839, 58LL);
L3: 

    /** pathopen.e:580		object eudir_path = get_eudir()*/
    _0 = _eudir_path_50858;
    _eudir_path_50858 = _37get_eudir();
    DeRef(_0);

    /** pathopen.e:581		if sequence(eudir_path) then*/
    _26093 = IS_SEQUENCE(_eudir_path_50858);
    if (_26093 == 0)
    {
        _26093 = NOVALUE;
        goto L4; // [97] 117
    }
    else{
        _26093 = NOVALUE;
    }

    /** pathopen.e:582			include_Paths = append(include_Paths, sprintf("%s/include", { eudir_path }))*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_eudir_path_50858);
    ((intptr_t*)_2)[1] = _eudir_path_50858;
    _26095 = MAKE_SEQ(_1);
    _26096 = EPrintf(-9999999, _26094, _26095);
    DeRefDS(_26095);
    _26095 = NOVALUE;
    RefDS(_26096);
    Append(&_48include_Paths_50833, _48include_Paths_50833, _26096);
    DeRefDS(_26096);
    _26096 = NOVALUE;
L4: 

    /** pathopen.e:585		if status then*/
    if (_status_50837 == 0)
    {
        goto L5; // [119] 161
    }
    else{
    }

    /** pathopen.e:587			if cache_complete[num_var] then*/
    _2 = (object)SEQ_PTR(_48cache_complete_50356);
    _26098 = (object)*(((s1_ptr)_2)->base + _48num_var_50349);
    if (_26098 == 0)
    {
        _26098 = NOVALUE;
        goto L6; // [132] 144
    }
    else{
        _26098 = NOVALUE;
    }

    /** pathopen.e:588				goto "cache done"*/
    goto G7;
L6: 

    /** pathopen.e:590			pos = cache_delims[num_var]+1*/
    _2 = (object)SEQ_PTR(_48cache_delims_50357);
    _26100 = (object)*(((s1_ptr)_2)->base + _48num_var_50349);
    _pos_50838 = _26100 + 1;
    _26100 = NOVALUE;
    goto L8; // [158] 167
L5: 

    /** pathopen.e:592	        pos = 1*/
    _pos_50838 = 1LL;
L8: 

    /** pathopen.e:594		start_path = 0*/
    _start_path_50841 = 0LL;

    /** pathopen.e:595		for p = pos to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_50839)){
            _26102 = SEQ_PTR(_inc_path_50839)->length;
    }
    else {
        _26102 = 1;
    }
    {
        object _p_50875;
        _p_50875 = _pos_50838;
L9: 
        if (_p_50875 > _26102){
            goto LA; // [179] 394
        }

        /** pathopen.e:596			if inc_path[p] = PATH_SEPARATOR then*/
        _2 = (object)SEQ_PTR(_inc_path_50839);
        _26103 = (object)*(((s1_ptr)_2)->base + _p_50875);
        if (_26103 != 58LL)
        goto LB; // [194] 343

        /** pathopen.e:598				cache_delims[num_var] = p*/
        _2 = (object)SEQ_PTR(_48cache_delims_50357);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_delims_50357 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50349);
        *(intptr_t *)_2 = _p_50875;

        /** pathopen.e:600				end_path = p-1*/
        _end_path_50842 = _p_50875 - 1LL;

        /** pathopen.e:601				while end_path >= start_path and find(inc_path[end_path]," \t" & SLASH_CHARS) do*/
LC: 
        _26106 = (_end_path_50842 >= _start_path_50841);
        if (_26106 == 0) {
            goto LD; // [223] 257
        }
        _2 = (object)SEQ_PTR(_inc_path_50839);
        _26108 = (object)*(((s1_ptr)_2)->base + _end_path_50842);
        Concat((object_ptr)&_26109, _26059, _46SLASH_CHARS_21606);
        _26110 = find_from(_26108, _26109, 1LL);
        _26108 = NOVALUE;
        DeRefDS(_26109);
        _26109 = NOVALUE;
        if (_26110 == 0)
        {
            _26110 = NOVALUE;
            goto LD; // [243] 257
        }
        else{
            _26110 = NOVALUE;
        }

        /** pathopen.e:602					end_path -= 1*/
        _end_path_50842 = _end_path_50842 - 1LL;

        /** pathopen.e:603				end while*/
        goto LC; // [254] 219
LD: 

        /** pathopen.e:605				if start_path and end_path then*/
        if (_start_path_50841 == 0) {
            goto LE; // [259] 387
        }
        if (_end_path_50842 == 0)
        {
            goto LE; // [264] 387
        }
        else{
        }

        /** pathopen.e:606					full_path = inc_path[start_path..end_path]*/
        rhs_slice_target = (object_ptr)&_full_path_50840;
        RHS_Slice(_inc_path_50839, _start_path_50841, _end_path_50842);

        /** pathopen.e:607					cache_substrings[num_var] = append(cache_substrings[num_var],full_path)*/
        _2 = (object)SEQ_PTR(_48cache_substrings_50352);
        _26114 = (object)*(((s1_ptr)_2)->base + _48num_var_50349);
        RefDS(_full_path_50840);
        Append(&_26115, _26114, _full_path_50840);
        _26114 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_substrings_50352);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_substrings_50352 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50349);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26115;
        if( _1 != _26115 ){
            DeRefDS(_1);
        }
        _26115 = NOVALUE;

        /** pathopen.e:608					cache_starts[num_var] &= start_path*/
        _2 = (object)SEQ_PTR(_48cache_starts_50353);
        _26116 = (object)*(((s1_ptr)_2)->base + _48num_var_50349);
        if (IS_SEQUENCE(_26116) && IS_ATOM(_start_path_50841)) {
            Append(&_26117, _26116, _start_path_50841);
        }
        else if (IS_ATOM(_26116) && IS_SEQUENCE(_start_path_50841)) {
        }
        else {
            Concat((object_ptr)&_26117, _26116, _start_path_50841);
            _26116 = NOVALUE;
        }
        _26116 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_starts_50353);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_starts_50353 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50349);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26117;
        if( _1 != _26117 ){
            DeRef(_1);
        }
        _26117 = NOVALUE;

        /** pathopen.e:609					cache_ends[num_var] &= end_path*/
        _2 = (object)SEQ_PTR(_48cache_ends_50354);
        _26118 = (object)*(((s1_ptr)_2)->base + _48num_var_50349);
        if (IS_SEQUENCE(_26118) && IS_ATOM(_end_path_50842)) {
            Append(&_26119, _26118, _end_path_50842);
        }
        else if (IS_ATOM(_26118) && IS_SEQUENCE(_end_path_50842)) {
        }
        else {
            Concat((object_ptr)&_26119, _26118, _end_path_50842);
            _26118 = NOVALUE;
        }
        _26118 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_ends_50354);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_ends_50354 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50349);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26119;
        if( _1 != _26119 ){
            DeRef(_1);
        }
        _26119 = NOVALUE;

        /** pathopen.e:610					ifdef WINDOWS then*/

        /** pathopen.e:620					start_path = 0*/
        _start_path_50841 = 0LL;
        goto LE; // [340] 387
LB: 

        /** pathopen.e:622			elsif not start_path and (inc_path[p] != ' ' and inc_path[p] != '\t') then*/
        _26120 = (_start_path_50841 == 0);
        if (_26120 == 0) {
            goto LF; // [348] 386
        }
        _2 = (object)SEQ_PTR(_inc_path_50839);
        _26122 = (object)*(((s1_ptr)_2)->base + _p_50875);
        _26123 = (_26122 != 32LL);
        _26122 = NOVALUE;
        if (_26123 == 0) {
            DeRef(_26124);
            _26124 = 0;
            goto L10; // [360] 376
        }
        _2 = (object)SEQ_PTR(_inc_path_50839);
        _26125 = (object)*(((s1_ptr)_2)->base + _p_50875);
        _26126 = (_26125 != 9LL);
        _26125 = NOVALUE;
        _26124 = (_26126 != 0);
L10: 
        if (_26124 == 0)
        {
            _26124 = NOVALUE;
            goto LF; // [377] 386
        }
        else{
            _26124 = NOVALUE;
        }

        /** pathopen.e:623				start_path = p*/
        _start_path_50841 = _p_50875;
LF: 
LE: 

        /** pathopen.e:625		end for*/
        _p_50875 = _p_50875 + 1LL;
        goto L9; // [389] 186
LA: 
        ;
    }

    /** pathopen.e:627	label "cache done"*/
G7:

    /** pathopen.e:628		include_Paths &= cache_substrings[num_var]*/
    _2 = (object)SEQ_PTR(_48cache_substrings_50352);
    _26127 = (object)*(((s1_ptr)_2)->base + _48num_var_50349);
    Concat((object_ptr)&_48include_Paths_50833, _48include_Paths_50833, _26127);
    _26127 = NOVALUE;

    /** pathopen.e:629		cache_complete[num_var] = 1*/
    _2 = (object)SEQ_PTR(_48cache_complete_50356);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _48cache_complete_50356 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _48num_var_50349);
    *(intptr_t *)_2 = 1LL;

    /** pathopen.e:631		ifdef WINDOWS then*/

    /** pathopen.e:640		return include_Paths*/
    RefDS(_48include_Paths_50833);
    DeRefi(_inc_path_50839);
    DeRefi(_full_path_50840);
    DeRef(_eudir_path_50858);
    DeRef(_26106);
    _26106 = NOVALUE;
    DeRef(_26123);
    _26123 = NOVALUE;
    _26103 = NOVALUE;
    DeRef(_26120);
    _26120 = NOVALUE;
    DeRef(_26126);
    _26126 = NOVALUE;
    return _48include_Paths_50833;
    ;
}


object _48e_path_find(object _name_50911)
{
    object _scan_result_50912 = NOVALUE;
    object _26137 = NOVALUE;
    object _26136 = NOVALUE;
    object _26135 = NOVALUE;
    object _26132 = NOVALUE;
    object _26131 = NOVALUE;
    object _26130 = NOVALUE;
    object _26129 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:656		if file_exists(name) then*/
    RefDS(_name_50911);
    _26129 = _17file_exists(_name_50911);
    if (_26129 == 0) {
        DeRef(_26129);
        _26129 = NOVALUE;
        goto L1; // [9] 19
    }
    else {
        if (!IS_ATOM_INT(_26129) && DBL_PTR(_26129)->dbl == 0.0){
            DeRef(_26129);
            _26129 = NOVALUE;
            goto L1; // [9] 19
        }
        DeRef(_26129);
        _26129 = NOVALUE;
    }
    DeRef(_26129);
    _26129 = NOVALUE;

    /** pathopen.e:657			return name*/
    DeRef(_scan_result_50912);
    return _name_50911;
L1: 

    /** pathopen.e:661		for i = 1 to length(SLASH_CHARS) do*/
    if (IS_SEQUENCE(_46SLASH_CHARS_21606)){
            _26130 = SEQ_PTR(_46SLASH_CHARS_21606)->length;
    }
    else {
        _26130 = 1;
    }
    {
        object _i_50917;
        _i_50917 = 1LL;
L2: 
        if (_i_50917 > _26130){
            goto L3; // [26] 63
        }

        /** pathopen.e:662			if find(SLASH_CHARS[i], name) then*/
        _2 = (object)SEQ_PTR(_46SLASH_CHARS_21606);
        _26131 = (object)*(((s1_ptr)_2)->base + _i_50917);
        _26132 = find_from(_26131, _name_50911, 1LL);
        _26131 = NOVALUE;
        if (_26132 == 0)
        {
            _26132 = NOVALUE;
            goto L4; // [46] 56
        }
        else{
            _26132 = NOVALUE;
        }

        /** pathopen.e:663				return -1*/
        DeRefDS(_name_50911);
        DeRef(_scan_result_50912);
        return -1LL;
L4: 

        /** pathopen.e:665		end for*/
        _i_50917 = _i_50917 + 1LL;
        goto L2; // [58] 33
L3: 
        ;
    }

    /** pathopen.e:667		scan_result = ScanPath(name, "PATH", 0)*/
    RefDS(_name_50911);
    RefDS(_26133);
    _0 = _scan_result_50912;
    _scan_result_50912 = _48ScanPath(_name_50911, _26133, 0LL);
    DeRef(_0);

    /** pathopen.e:668		if sequence(scan_result) then*/
    _26135 = IS_SEQUENCE(_scan_result_50912);
    if (_26135 == 0)
    {
        _26135 = NOVALUE;
        goto L5; // [76] 98
    }
    else{
        _26135 = NOVALUE;
    }

    /** pathopen.e:669			close(scan_result[2])*/
    _2 = (object)SEQ_PTR(_scan_result_50912);
    _26136 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_26136))
    EClose(_26136);
    else
    EClose((object)DBL_PTR(_26136)->dbl);
    _26136 = NOVALUE;

    /** pathopen.e:670			return scan_result[1]*/
    _2 = (object)SEQ_PTR(_scan_result_50912);
    _26137 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_26137);
    DeRefDS(_name_50911);
    DeRef(_scan_result_50912);
    return _26137;
L5: 

    /** pathopen.e:673		return -1*/
    DeRefDS(_name_50911);
    DeRef(_scan_result_50912);
    _26137 = NOVALUE;
    return -1LL;
    ;
}



// 0x573CB06F
