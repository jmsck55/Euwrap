// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _9allocate(object _n_1047, object _cleanup_1048)
{
    object _iaddr_1049 = NOVALUE;
    object _eaddr_1050 = NOVALUE;
    object _409 = NOVALUE;
    object _408 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:541		ifdef DATA_EXECUTE then*/

    /** machine.e:545			iaddr = eu:machine_func( memconst:M_ALLOC, n + memory:BORDER_SPACE * 2)*/
    _408 = 0LL;
    _409 = _n_1047 + 0LL;
    _408 = NOVALUE;
    DeRef(_iaddr_1049);
    _iaddr_1049 = machine(16LL, _409);
    _409 = NOVALUE;

    /** machine.e:546			eaddr = memory:prepare_block( iaddr, n, PAGE_READ_WRITE )*/
    Ref(_iaddr_1049);
    Ref(_10PAGE_READ_WRITE_300);
    _0 = _eaddr_1050;
    _eaddr_1050 = _11prepare_block(_iaddr_1049, _n_1047, _10PAGE_READ_WRITE_300);
    DeRef(_0);

    /** machine.e:548		if cleanup then*/

    /** machine.e:551		return eaddr*/
    DeRef(_iaddr_1049);
    return _eaddr_1050;
    ;
}


void _9free_pointer_array(object _pointers_array_1089)
{
    object _saved_1090 = NOVALUE;
    object _ptr_1091 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:661		atom saved = pointers_array*/
    Ref(_pointers_array_1089);
    DeRef(_saved_1090);
    _saved_1090 = _pointers_array_1089;

    /** machine.e:664		while ptr with entry do*/
    goto L1; // [8] 41
L2: 
    if (_ptr_1091 <= 0) {
        if (_ptr_1091 == 0) {
            goto L3; // [13] 51
        }
        else {
            if (!IS_ATOM_INT(_ptr_1091) && DBL_PTR(_ptr_1091)->dbl == 0.0){
                goto L3; // [13] 51
            }
        }
    }

    /** machine.e:665			memory:deallocate( ptr )*/

    /** memory.e:71		ifdef DATA_EXECUTE then*/

    /** memory.e:82	   	machine_proc( memconst:M_FREE, addr)*/
    machine(17LL, _ptr_1091);

    /** memory.e:83	end procedure*/
    goto L4; // [27] 30
L4: 

    /** machine.e:666			pointers_array += ADDRESS_LENGTH*/
    _0 = _pointers_array_1089;
    if (IS_ATOM_INT(_pointers_array_1089)) {
        _pointers_array_1089 = _pointers_array_1089 + _9ADDRESS_LENGTH_1017;
        if ((object)((uintptr_t)_pointers_array_1089 + (uintptr_t)HIGH_BITS) >= 0){
            _pointers_array_1089 = NewDouble((eudouble)_pointers_array_1089);
        }
    }
    else {
        _pointers_array_1089 = NewDouble(DBL_PTR(_pointers_array_1089)->dbl + (eudouble)_9ADDRESS_LENGTH_1017);
    }
    DeRef(_0);

    /** machine.e:668		entry*/
L1: 

    /** machine.e:669			ptr = peek_pointer(pointers_array)*/
    DeRef(_ptr_1091);
    if (IS_ATOM_INT(_pointers_array_1089)) {
        _ptr_1091 = *(intptr_t *)_pointers_array_1089;
        if ((uintptr_t)_ptr_1091 > (uintptr_t)MAXINT){
            _ptr_1091 = NewDouble((eudouble)(uintptr_t)_ptr_1091);
        }
    }
    else {
        _ptr_1091 = *(uintptr_t *)(uintptr_t)(DBL_PTR(_pointers_array_1089)->dbl);
        if ((uintptr_t)_ptr_1091 > (uintptr_t)MAXINT){
            _ptr_1091 = NewDouble((eudouble)(uintptr_t)_ptr_1091);
        }
    }

    /** machine.e:670		end while*/
    goto L2; // [48] 11
L3: 

    /** machine.e:672		free(saved)*/
    Ref(_saved_1090);
    _9free(_saved_1090);

    /** machine.e:673	end procedure*/
    DeRef(_pointers_array_1089);
    DeRef(_saved_1090);
    DeRef(_ptr_1091);
    return;
    ;
}


object _9allocate_string(object _s_1207, object _cleanup_1208)
{
    object _mem_1209 = NOVALUE;
    object _482 = NOVALUE;
    object _481 = NOVALUE;
    object _479 = NOVALUE;
    object _478 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:2096		mem = allocate( length(s) + 1) -- Thanks to Igor*/
    if (IS_SEQUENCE(_s_1207)){
            _478 = SEQ_PTR(_s_1207)->length;
    }
    else {
        _478 = 1;
    }
    _479 = _478 + 1;
    _478 = NOVALUE;
    _0 = _mem_1209;
    _mem_1209 = _9allocate(_479, 0LL);
    DeRef(_0);
    _479 = NOVALUE;

    /** machine.e:2098		if mem then*/
    if (_mem_1209 == 0) {
        goto L1; // [19] 54
    }
    else {
        if (!IS_ATOM_INT(_mem_1209) && DBL_PTR(_mem_1209)->dbl == 0.0){
            goto L1; // [19] 54
        }
    }

    /** machine.e:2099			poke(mem, s)*/
    if (IS_ATOM_INT(_mem_1209)){
        poke_addr = (uint8_t *)_mem_1209;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_mem_1209)->dbl);
    }
    _1 = (object)SEQ_PTR(_s_1207);
    _1 = (object)((s1_ptr)_1)->base;
    while (1) {
        _1 += sizeof(object);
        _2 = *((object *)_1);
        if (IS_ATOM_INT(_2)) {
            *poke_addr++ = (uint8_t)_2;
        }
        else if (_2 == NOVALUE) {
            break;
        }
        else {
            *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
        }
    }

    /** machine.e:2100			poke(mem+length(s), 0)  -- Thanks to Aku*/
    if (IS_SEQUENCE(_s_1207)){
            _481 = SEQ_PTR(_s_1207)->length;
    }
    else {
        _481 = 1;
    }
    if (IS_ATOM_INT(_mem_1209)) {
        _482 = _mem_1209 + _481;
        if ((object)((uintptr_t)_482 + (uintptr_t)HIGH_BITS) >= 0){
            _482 = NewDouble((eudouble)_482);
        }
    }
    else {
        _482 = NewDouble(DBL_PTR(_mem_1209)->dbl + (eudouble)_481);
    }
    _481 = NOVALUE;
    if (IS_ATOM_INT(_482)){
        poke_addr = (uint8_t *)_482;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_482)->dbl);
    }
    *poke_addr = (uint8_t)0LL;
    DeRef(_482);
    _482 = NOVALUE;

    /** machine.e:2101			if cleanup then*/
L1: 

    /** machine.e:2106		return mem*/
    DeRefDS(_s_1207);
    return _mem_1209;
    ;
}


void _9free(object _addr_1307)
{
    object _msg_inlined_crash_at_27_1316 = NOVALUE;
    object _data_inlined_crash_at_24_1315 = NOVALUE;
    object _addr_inlined_deallocate_at_64_1322 = NOVALUE;
    object _msg_inlined_crash_at_106_1327 = NOVALUE;
    object _522 = NOVALUE;
    object _521 = NOVALUE;
    object _520 = NOVALUE;
    object _519 = NOVALUE;
    object _517 = NOVALUE;
    object _516 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:2319		if types:number_array (addr) then*/
    Ref(_addr_1307);
    _516 = _13number_array(_addr_1307);
    if (_516 == 0) {
        DeRef(_516);
        _516 = NOVALUE;
        goto L1; // [7] 97
    }
    else {
        if (!IS_ATOM_INT(_516) && DBL_PTR(_516)->dbl == 0.0){
            DeRef(_516);
            _516 = NOVALUE;
            goto L1; // [7] 97
        }
        DeRef(_516);
        _516 = NOVALUE;
    }
    DeRef(_516);
    _516 = NOVALUE;

    /** machine.e:2320			if types:ascii_string(addr) then*/
    Ref(_addr_1307);
    _517 = _13ascii_string(_addr_1307);
    if (_517 == 0) {
        DeRef(_517);
        _517 = NOVALUE;
        goto L2; // [16] 47
    }
    else {
        if (!IS_ATOM_INT(_517) && DBL_PTR(_517)->dbl == 0.0){
            DeRef(_517);
            _517 = NOVALUE;
            goto L2; // [16] 47
        }
        DeRef(_517);
        _517 = NOVALUE;
    }
    DeRef(_517);
    _517 = NOVALUE;

    /** machine.e:2321				error:crash("free(\"%s\") is not a valid address", {addr})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_addr_1307);
    ((intptr_t*)_2)[1] = _addr_1307;
    _519 = MAKE_SEQ(_1);
    DeRef(_data_inlined_crash_at_24_1315);
    _data_inlined_crash_at_24_1315 = _519;
    _519 = NOVALUE;

    /** error.e:51		msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_27_1316);
    _msg_inlined_crash_at_27_1316 = EPrintf(-9999999, _518, _data_inlined_crash_at_24_1315);

    /** error.e:52		machine_proc(M_CRASH, msg)*/
    machine(67LL, _msg_inlined_crash_at_27_1316);

    /** error.e:53	end procedure*/
    goto L3; // [41] 44
L3: 
    DeRef(_data_inlined_crash_at_24_1315);
    _data_inlined_crash_at_24_1315 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_27_1316);
    _msg_inlined_crash_at_27_1316 = NOVALUE;
L2: 

    /** machine.e:2324			for i = 1 to length(addr) do*/
    if (IS_SEQUENCE(_addr_1307)){
            _520 = SEQ_PTR(_addr_1307)->length;
    }
    else {
        _520 = 1;
    }
    {
        object _i_1318;
        _i_1318 = 1LL;
L4: 
        if (_i_1318 > _520){
            goto L5; // [52] 89
        }

        /** machine.e:2325				memory:deallocate( addr[i] )*/
        _2 = (object)SEQ_PTR(_addr_1307);
        _521 = (object)*(((s1_ptr)_2)->base + _i_1318);
        Ref(_521);
        DeRef(_addr_inlined_deallocate_at_64_1322);
        _addr_inlined_deallocate_at_64_1322 = _521;
        _521 = NOVALUE;

        /** memory.e:71		ifdef DATA_EXECUTE then*/

        /** memory.e:82	   	machine_proc( memconst:M_FREE, addr)*/
        machine(17LL, _addr_inlined_deallocate_at_64_1322);

        /** memory.e:83	end procedure*/
        goto L6; // [77] 80
L6: 
        DeRef(_addr_inlined_deallocate_at_64_1322);
        _addr_inlined_deallocate_at_64_1322 = NOVALUE;

        /** machine.e:2326			end for*/
        _i_1318 = _i_1318 + 1LL;
        goto L4; // [84] 59
L5: 
        ;
    }

    /** machine.e:2327			return*/
    DeRef(_addr_1307);
    return;
    goto L7; // [94] 127
L1: 

    /** machine.e:2328		elsif sequence(addr) then*/
    _522 = IS_SEQUENCE(_addr_1307);
    if (_522 == 0)
    {
        _522 = NOVALUE;
        goto L8; // [102] 126
    }
    else{
        _522 = NOVALUE;
    }

    /** machine.e:2329			error:crash("free() called with nested sequence")*/

    /** error.e:51		msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_106_1327);
    _msg_inlined_crash_at_106_1327 = EPrintf(-9999999, _523, _5);

    /** error.e:52		machine_proc(M_CRASH, msg)*/
    machine(67LL, _msg_inlined_crash_at_106_1327);

    /** error.e:53	end procedure*/
    goto L9; // [120] 123
L9: 
    DeRefi(_msg_inlined_crash_at_106_1327);
    _msg_inlined_crash_at_106_1327 = NOVALUE;
L8: 
L7: 

    /** machine.e:2332		if addr = 0 then*/
    if (binary_op_a(NOTEQ, _addr_1307, 0LL)){
        goto LA; // [129] 139
    }

    /** machine.e:2335			return*/
    DeRef(_addr_1307);
    return;
LA: 

    /** machine.e:2338		memory:deallocate( addr )*/

    /** memory.e:71		ifdef DATA_EXECUTE then*/

    /** memory.e:82	   	machine_proc( memconst:M_FREE, addr)*/
    machine(17LL, _addr_1307);

    /** memory.e:83	end procedure*/
    goto LB; // [150] 153
LB: 

    /** machine.e:2339	end procedure*/
    DeRef(_addr_1307);
    return;
    ;
}



// 0xDAC01C94
