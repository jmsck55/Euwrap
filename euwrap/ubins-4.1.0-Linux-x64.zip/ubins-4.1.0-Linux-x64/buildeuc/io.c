// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _8get_integer32(object _fh_9835)
{
    object _c_9836 = NOVALUE;
    object _5537 = NOVALUE;
    object _0, _1, _2;
    

    /** io.e:525		c = getc(fh)*/
    if (_fh_9835 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_9835, EF_READ);
        last_r_file_no = _fh_9835;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_9836 = getc((FILE*)xstdin);
        }
        else{
            _c_9836 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_9836 = getc(last_r_file_ptr);
    }

    /** io.e:526		poke(mem0, c)*/
    if (IS_ATOM_INT(_8mem0_9825)){
        poke_addr = (uint8_t *)_8mem0_9825;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_8mem0_9825)->dbl);
    }
    *poke_addr = (uint8_t)_c_9836;

    /** io.e:527		c = getc(fh)*/
    if (_fh_9835 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_9835, EF_READ);
        last_r_file_no = _fh_9835;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_9836 = getc((FILE*)xstdin);
        }
        else{
            _c_9836 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_9836 = getc(last_r_file_ptr);
    }

    /** io.e:528		poke(mem1, c)*/
    if (IS_ATOM_INT(_8mem1_9826)){
        poke_addr = (uint8_t *)_8mem1_9826;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_8mem1_9826)->dbl);
    }
    *poke_addr = (uint8_t)_c_9836;

    /** io.e:529		c = getc(fh)*/
    if (_fh_9835 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_9835, EF_READ);
        last_r_file_no = _fh_9835;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_9836 = getc((FILE*)xstdin);
        }
        else{
            _c_9836 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_9836 = getc(last_r_file_ptr);
    }

    /** io.e:530		poke(mem2, c)*/
    if (IS_ATOM_INT(_8mem2_9827)){
        poke_addr = (uint8_t *)_8mem2_9827;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_8mem2_9827)->dbl);
    }
    *poke_addr = (uint8_t)_c_9836;

    /** io.e:531		c = getc(fh)*/
    if (_fh_9835 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_9835, EF_READ);
        last_r_file_no = _fh_9835;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_9836 = getc((FILE*)xstdin);
        }
        else{
            _c_9836 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_9836 = getc(last_r_file_ptr);
    }

    /** io.e:532		if c = -1 then*/
    if (_c_9836 != -1LL)
    goto L1; // [46] 57

    /** io.e:533			return -1*/
    return -1LL;
L1: 

    /** io.e:535		poke(mem3, c)*/
    if (IS_ATOM_INT(_8mem3_9828)){
        poke_addr = (uint8_t *)_8mem3_9828;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_8mem3_9828)->dbl);
    }
    *poke_addr = (uint8_t)_c_9836;

    /** io.e:536		return peek4u(mem0)*/
    if (IS_ATOM_INT(_8mem0_9825)) {
        _5537 = (object)*(uint32_t *)_8mem0_9825;
        if ((uintptr_t)_5537 > (uintptr_t)MAXINT){
            _5537 = NewDouble((eudouble)(uintptr_t)_5537);
        }
    }
    else {
        _5537 = (object)*(uint32_t *)(uintptr_t)(DBL_PTR(_8mem0_9825)->dbl);
        if ((uintptr_t)_5537 > (uintptr_t)MAXINT){
            _5537 = NewDouble((eudouble)(uintptr_t)_5537);
        }
    }
    return _5537;
    ;
}


object _8get_integer16(object _fh_9846)
{
    object _c_9847 = NOVALUE;
    object _5541 = NOVALUE;
    object _0, _1, _2;
    

    /** io.e:568		c = getc(fh)*/
    if (_fh_9846 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_9846, EF_READ);
        last_r_file_no = _fh_9846;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_9847 = getc((FILE*)xstdin);
        }
        else{
            _c_9847 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_9847 = getc(last_r_file_ptr);
    }

    /** io.e:569		poke(mem0, c)*/
    if (IS_ATOM_INT(_8mem0_9825)){
        poke_addr = (uint8_t *)_8mem0_9825;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_8mem0_9825)->dbl);
    }
    *poke_addr = (uint8_t)_c_9847;

    /** io.e:570		c = getc(fh)*/
    if (_fh_9846 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_9846, EF_READ);
        last_r_file_no = _fh_9846;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_9847 = getc((FILE*)xstdin);
        }
        else{
            _c_9847 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_9847 = getc(last_r_file_ptr);
    }

    /** io.e:571		if c = -1 then*/
    if (_c_9847 != -1LL)
    goto L1; // [22] 33

    /** io.e:572			return -1*/
    return -1LL;
L1: 

    /** io.e:574		poke(mem1, c)*/
    if (IS_ATOM_INT(_8mem1_9826)){
        poke_addr = (uint8_t *)_8mem1_9826;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_8mem1_9826)->dbl);
    }
    *poke_addr = (uint8_t)_c_9847;

    /** io.e:575		return peek2u(mem0)*/
    if (IS_ATOM_INT(_8mem0_9825)) {
        _5541 = *(uint16_t *)_8mem0_9825;
    }
    else {
        _5541 = *(uint16_t *)(uintptr_t)(DBL_PTR(_8mem0_9825)->dbl);
    }
    return _5541;
    ;
}


object _8seek(object _fn_9942, object _pos_9943)
{
    object _5587 = NOVALUE;
    object _5586 = NOVALUE;
    object _0, _1, _2;
    

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_9943);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _fn_9942;
    ((intptr_t *)_2)[2] = _pos_9943;
    _5586 = MAKE_SEQ(_1);
    _5587 = machine(19LL, _5586);
    DeRefDS(_5586);
    _5586 = NOVALUE;
    DeRef(_pos_9943);
    return _5587;
    ;
}


object _8where(object _fn_9948)
{
    object _5588 = NOVALUE;
    object _0, _1, _2;
    

    /** io.e:932		return machine_func(M_WHERE, fn)*/
    _5588 = machine(20LL, _fn_9948);
    return _5588;
    ;
}


object _8read_lines(object _file_9967)
{
    object _fn_9968 = NOVALUE;
    object _ret_9969 = NOVALUE;
    object _y_9970 = NOVALUE;
    object _5617 = NOVALUE;
    object _5616 = NOVALUE;
    object _5615 = NOVALUE;
    object _5614 = NOVALUE;
    object _5609 = NOVALUE;
    object _5608 = NOVALUE;
    object _5606 = NOVALUE;
    object _5605 = NOVALUE;
    object _5604 = NOVALUE;
    object _5602 = NOVALUE;
    object _5601 = NOVALUE;
    object _5599 = NOVALUE;
    object _5598 = NOVALUE;
    object _5597 = NOVALUE;
    object _5593 = NOVALUE;
    object _5592 = NOVALUE;
    object _0, _1, _2;
    

    /** io.e:1127		if sequence(file) then*/
    _5592 = 1;
    if (_5592 == 0)
    {
        _5592 = NOVALUE;
        goto L1; // [6] 37
    }
    else{
        _5592 = NOVALUE;
    }

    /** io.e:1128			if length(file) = 0 then*/
    if (IS_SEQUENCE(_file_9967)){
            _5593 = SEQ_PTR(_file_9967)->length;
    }
    else {
        _5593 = 1;
    }
    if (_5593 != 0LL)
    goto L2; // [14] 26

    /** io.e:1129				fn = 0*/
    DeRef(_fn_9968);
    _fn_9968 = 0LL;
    goto L3; // [23] 43
L2: 

    /** io.e:1131				fn = open(file, "r")*/
    DeRef(_fn_9968);
    _fn_9968 = EOpen(_file_9967, _3866, 0LL);
    goto L3; // [34] 43
L1: 

    /** io.e:1134			fn = file*/
    Ref(_file_9967);
    DeRef(_fn_9968);
    _fn_9968 = _file_9967;
L3: 

    /** io.e:1136		if fn < 0 then return -1 end if*/
    if (binary_op_a(GREATEREQ, _fn_9968, 0LL)){
        goto L4; // [47] 56
    }
    DeRef(_file_9967);
    DeRef(_fn_9968);
    DeRef(_ret_9969);
    DeRefi(_y_9970);
    return -1LL;
L4: 

    /** io.e:1138		ret = {}*/
    RefDS(_5);
    DeRef(_ret_9969);
    _ret_9969 = _5;

    /** io.e:1139		while sequence(y) with entry do*/
    goto L5; // [63] 162
L6: 
    _5597 = IS_SEQUENCE(_y_9970);
    if (_5597 == 0)
    {
        _5597 = NOVALUE;
        goto L7; // [71] 172
    }
    else{
        _5597 = NOVALUE;
    }

    /** io.e:1140			if y[$] = '\n' then*/
    if (IS_SEQUENCE(_y_9970)){
            _5598 = SEQ_PTR(_y_9970)->length;
    }
    else {
        _5598 = 1;
    }
    _2 = (object)SEQ_PTR(_y_9970);
    _5599 = (object)*(((s1_ptr)_2)->base + _5598);
    if (_5599 != 10LL)
    goto L8; // [83] 141

    /** io.e:1141				y = y[1..$-1]*/
    if (IS_SEQUENCE(_y_9970)){
            _5601 = SEQ_PTR(_y_9970)->length;
    }
    else {
        _5601 = 1;
    }
    _5602 = _5601 - 1LL;
    _5601 = NOVALUE;
    rhs_slice_target = (object_ptr)&_y_9970;
    RHS_Slice(_y_9970, 1LL, _5602);

    /** io.e:1142				ifdef UNIX then*/

    /** io.e:1143					if length(y) then*/
    if (IS_SEQUENCE(_y_9970)){
            _5604 = SEQ_PTR(_y_9970)->length;
    }
    else {
        _5604 = 1;
    }
    if (_5604 == 0)
    {
        _5604 = NOVALUE;
        goto L9; // [108] 140
    }
    else{
        _5604 = NOVALUE;
    }

    /** io.e:1144						if y[$] = '\r' then*/
    if (IS_SEQUENCE(_y_9970)){
            _5605 = SEQ_PTR(_y_9970)->length;
    }
    else {
        _5605 = 1;
    }
    _2 = (object)SEQ_PTR(_y_9970);
    _5606 = (object)*(((s1_ptr)_2)->base + _5605);
    if (_5606 != 13LL)
    goto LA; // [120] 139

    /** io.e:1145							y = y[1..$-1]*/
    if (IS_SEQUENCE(_y_9970)){
            _5608 = SEQ_PTR(_y_9970)->length;
    }
    else {
        _5608 = 1;
    }
    _5609 = _5608 - 1LL;
    _5608 = NOVALUE;
    rhs_slice_target = (object_ptr)&_y_9970;
    RHS_Slice(_y_9970, 1LL, _5609);
LA: 
L9: 
L8: 

    /** io.e:1150			ret = append(ret, y)*/
    Ref(_y_9970);
    Append(&_ret_9969, _ret_9969, _y_9970);

    /** io.e:1151			if fn = 0 then*/
    if (binary_op_a(NOTEQ, _fn_9968, 0LL)){
        goto LB; // [149] 159
    }

    /** io.e:1152				puts(2, '\n')*/
    EPuts(2LL, 10LL); // DJP 
LB: 

    /** io.e:1154		entry*/
L5: 

    /** io.e:1155			y = gets(fn)*/
    DeRefi(_y_9970);
    _y_9970 = EGets(_fn_9968);

    /** io.e:1156		end while*/
    goto L6; // [169] 66
L7: 

    /** io.e:1158		if sequence(file) and length(file) != 0 then*/
    _5614 = IS_SEQUENCE(_file_9967);
    if (_5614 == 0) {
        goto LC; // [177] 197
    }
    if (IS_SEQUENCE(_file_9967)){
            _5616 = SEQ_PTR(_file_9967)->length;
    }
    else {
        _5616 = 1;
    }
    _5617 = (_5616 != 0LL);
    _5616 = NOVALUE;
    if (_5617 == 0)
    {
        DeRef(_5617);
        _5617 = NOVALUE;
        goto LC; // [189] 197
    }
    else{
        DeRef(_5617);
        _5617 = NOVALUE;
    }

    /** io.e:1159			close(fn)*/
    if (IS_ATOM_INT(_fn_9968))
    EClose(_fn_9968);
    else
    EClose((object)DBL_PTR(_fn_9968)->dbl);
LC: 

    /** io.e:1162		return ret*/
    DeRef(_file_9967);
    DeRef(_fn_9968);
    DeRefi(_y_9970);
    _5606 = NOVALUE;
    DeRef(_5602);
    _5602 = NOVALUE;
    _5599 = NOVALUE;
    DeRef(_5609);
    _5609 = NOVALUE;
    return _ret_9969;
    ;
}


object _8write_lines(object _file_10061, object _lines_10062)
{
    object _fn_10063 = NOVALUE;
    object _5654 = NOVALUE;
    object _5653 = NOVALUE;
    object _5652 = NOVALUE;
    object _5648 = NOVALUE;
    object _0, _1, _2;
    

    /** io.e:1285		if sequence(file) then*/
    _5648 = 1;
    if (_5648 == 0)
    {
        _5648 = NOVALUE;
        goto L1; // [8] 21
    }
    else{
        _5648 = NOVALUE;
    }

    /** io.e:1286	    	fn = open(file, "w")*/
    DeRef(_fn_10063);
    _fn_10063 = EOpen(_file_10061, _5649, 0LL);
    goto L2; // [18] 27
L1: 

    /** io.e:1288			fn = file*/
    Ref(_file_10061);
    DeRef(_fn_10063);
    _fn_10063 = _file_10061;
L2: 

    /** io.e:1290		if fn < 0 then return -1 end if*/
    if (binary_op_a(GREATEREQ, _fn_10063, 0LL)){
        goto L3; // [31] 40
    }
    DeRef(_file_10061);
    DeRefDS(_lines_10062);
    DeRef(_fn_10063);
    return -1LL;
L3: 

    /** io.e:1292		for i = 1 to length(lines) do*/
    if (IS_SEQUENCE(_lines_10062)){
            _5652 = SEQ_PTR(_lines_10062)->length;
    }
    else {
        _5652 = 1;
    }
    {
        object _i_10072;
        _i_10072 = 1LL;
L4: 
        if (_i_10072 > _5652){
            goto L5; // [45] 73
        }

        /** io.e:1293			puts(fn, lines[i])*/
        _2 = (object)SEQ_PTR(_lines_10062);
        _5653 = (object)*(((s1_ptr)_2)->base + _i_10072);
        EPuts(_fn_10063, _5653); // DJP 
        _5653 = NOVALUE;

        /** io.e:1294			puts(fn, '\n')*/
        EPuts(_fn_10063, 10LL); // DJP 

        /** io.e:1295		end for*/
        _i_10072 = _i_10072 + 1LL;
        goto L4; // [68] 52
L5: 
        ;
    }

    /** io.e:1297		if sequence(file) then*/
    _5654 = IS_SEQUENCE(_file_10061);
    if (_5654 == 0)
    {
        _5654 = NOVALUE;
        goto L6; // [78] 86
    }
    else{
        _5654 = NOVALUE;
    }

    /** io.e:1298			close(fn)*/
    if (IS_ATOM_INT(_fn_10063))
    EClose(_fn_10063);
    else
    EClose((object)DBL_PTR(_fn_10063)->dbl);
L6: 

    /** io.e:1301		return 1*/
    DeRef(_file_10061);
    DeRefDS(_lines_10062);
    DeRef(_fn_10063);
    return 1LL;
    ;
}


object _8write_file(object _file_10140, object _data_10141, object _as_text_10142)
{
    object _fn_10143 = NOVALUE;
    object _5700 = NOVALUE;
    object _5695 = NOVALUE;
    object _0, _1, _2;
    

    /** io.e:1496		if as_text != BINARY_MODE then*/

    /** io.e:1525		if sequence(file) then*/
    _5695 = 1;
    if (_5695 == 0)
    {
        _5695 = NOVALUE;
        goto L1; // [151] 181
    }
    else{
        _5695 = NOVALUE;
    }

    /** io.e:1526			if as_text = TEXT_MODE then*/

    /** io.e:1529				fn = open(file, "wb")*/
    _fn_10143 = EOpen(_file_10140, _3257, 0LL);
    goto L2; // [178] 189
L1: 

    /** io.e:1532			fn = file*/
    Ref(_file_10140);
    _fn_10143 = _file_10140;
    if (!IS_ATOM_INT(_fn_10143)) {
        _1 = (object)(DBL_PTR(_fn_10143)->dbl);
        DeRefDS(_fn_10143);
        _fn_10143 = _1;
    }
L2: 

    /** io.e:1534		if fn < 0 then return -1 end if*/
    if (_fn_10143 >= 0LL)
    goto L3; // [193] 202
    DeRefi(_file_10140);
    DeRefDS(_data_10141);
    return -1LL;
L3: 

    /** io.e:1536		puts(fn, data)*/
    EPuts(_fn_10143, _data_10141); // DJP 

    /** io.e:1538		if sequence(file) then*/
    _5700 = IS_SEQUENCE(_file_10140);
    if (_5700 == 0)
    {
        _5700 = NOVALUE;
        goto L4; // [212] 220
    }
    else{
        _5700 = NOVALUE;
    }

    /** io.e:1539			close(fn)*/
    EClose(_fn_10143);
L4: 

    /** io.e:1542		return 1*/
    DeRefi(_file_10140);
    DeRefDS(_data_10141);
    return 1LL;
    ;
}


void _8writef(object _fm_10183, object _data_10184, object _fn_10185, object _data_not_string_10186)
{
    object _real_fn_10187 = NOVALUE;
    object _close_fn_10188 = NOVALUE;
    object _out_style_10189 = NOVALUE;
    object _ts_10192 = NOVALUE;
    object _msg_inlined_crash_at_163_10217 = NOVALUE;
    object _data_inlined_crash_at_160_10216 = NOVALUE;
    object _5720 = NOVALUE;
    object _5718 = NOVALUE;
    object _5717 = NOVALUE;
    object _5716 = NOVALUE;
    object _5710 = NOVALUE;
    object _5709 = NOVALUE;
    object _5708 = NOVALUE;
    object _5707 = NOVALUE;
    object _5706 = NOVALUE;
    object _5705 = NOVALUE;
    object _5703 = NOVALUE;
    object _5702 = NOVALUE;
    object _5701 = NOVALUE;
    object _0, _1, _2;
    

    /** io.e:1608		integer real_fn = 0*/
    _real_fn_10187 = 0LL;

    /** io.e:1609		integer close_fn = 0*/
    _close_fn_10188 = 0LL;

    /** io.e:1610		sequence out_style = "w"*/
    RefDS(_5649);
    DeRefi(_out_style_10189);
    _out_style_10189 = _5649;

    /** io.e:1612		if integer(fm) then*/
    _5701 = 1;
    if (_5701 == 0)
    {
        _5701 = NOVALUE;
        goto L1; // [23] 49
    }
    else{
        _5701 = NOVALUE;
    }

    /** io.e:1613			object ts*/

    /** io.e:1615			ts = fm*/
    _ts_10192 = _fm_10183;

    /** io.e:1616			fm = data*/
    RefDS(_data_10184);
    _fm_10183 = _data_10184;

    /** io.e:1617			data = fn*/
    RefDS(_fn_10185);
    DeRefDS(_data_10184);
    _data_10184 = _fn_10185;

    /** io.e:1618			fn = ts*/
    DeRefDS(_fn_10185);
    _fn_10185 = _ts_10192;
L1: 

    /** io.e:1621		if sequence(fn) then*/
    _5702 = IS_SEQUENCE(_fn_10185);
    if (_5702 == 0)
    {
        _5702 = NOVALUE;
        goto L2; // [56] 191
    }
    else{
        _5702 = NOVALUE;
    }

    /** io.e:1622			if length(fn) = 2 then*/
    if (IS_SEQUENCE(_fn_10185)){
            _5703 = SEQ_PTR(_fn_10185)->length;
    }
    else {
        _5703 = 1;
    }
    if (_5703 != 2LL)
    goto L3; // [64] 142

    /** io.e:1623				if sequence(fn[1]) then*/
    _2 = (object)SEQ_PTR(_fn_10185);
    _5705 = (object)*(((s1_ptr)_2)->base + 1LL);
    _5706 = IS_SEQUENCE(_5705);
    _5705 = NOVALUE;
    if (_5706 == 0)
    {
        _5706 = NOVALUE;
        goto L4; // [77] 141
    }
    else{
        _5706 = NOVALUE;
    }

    /** io.e:1624					if equal(fn[2], 'a') then*/
    _2 = (object)SEQ_PTR(_fn_10185);
    _5707 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (_5707 == 97LL)
    _5708 = 1;
    else if (IS_ATOM_INT(_5707) && IS_ATOM_INT(97LL))
    _5708 = 0;
    else
    _5708 = (compare(_5707, 97LL) == 0);
    _5707 = NOVALUE;
    if (_5708 == 0)
    {
        _5708 = NOVALUE;
        goto L5; // [90] 103
    }
    else{
        _5708 = NOVALUE;
    }

    /** io.e:1625						out_style = "a"*/
    RefDS(_5655);
    DeRefi(_out_style_10189);
    _out_style_10189 = _5655;
    goto L6; // [100] 134
L5: 

    /** io.e:1626					elsif not equal(fn[2], "a") then*/
    _2 = (object)SEQ_PTR(_fn_10185);
    _5709 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (_5709 == _5655)
    _5710 = 1;
    else if (IS_ATOM_INT(_5709) && IS_ATOM_INT(_5655))
    _5710 = 0;
    else
    _5710 = (compare(_5709, _5655) == 0);
    _5709 = NOVALUE;
    if (_5710 != 0)
    goto L7; // [113] 126
    _5710 = NOVALUE;

    /** io.e:1627						out_style = "w"*/
    RefDS(_5649);
    DeRefi(_out_style_10189);
    _out_style_10189 = _5649;
    goto L6; // [123] 134
L7: 

    /** io.e:1629						out_style = "a"*/
    RefDS(_5655);
    DeRefi(_out_style_10189);
    _out_style_10189 = _5655;
L6: 

    /** io.e:1631					fn = fn[1]*/
    _0 = _fn_10185;
    _2 = (object)SEQ_PTR(_fn_10185);
    _fn_10185 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_fn_10185);
    DeRef(_0);
L4: 
L3: 

    /** io.e:1634			real_fn = open(fn, out_style)*/
    _real_fn_10187 = EOpen(_fn_10185, _out_style_10189, 0LL);

    /** io.e:1636			if real_fn = -1 then*/
    if (_real_fn_10187 != -1LL)
    goto L8; // [151] 183

    /** io.e:1637				error:crash("Unable to write to '%s'", {fn})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_fn_10185);
    ((intptr_t*)_2)[1] = _fn_10185;
    _5716 = MAKE_SEQ(_1);
    DeRef(_data_inlined_crash_at_160_10216);
    _data_inlined_crash_at_160_10216 = _5716;
    _5716 = NOVALUE;

    /** error.e:51		msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_163_10217);
    _msg_inlined_crash_at_163_10217 = EPrintf(-9999999, _5715, _data_inlined_crash_at_160_10216);

    /** error.e:52		machine_proc(M_CRASH, msg)*/
    machine(67LL, _msg_inlined_crash_at_163_10217);

    /** error.e:53	end procedure*/
    goto L9; // [177] 180
L9: 
    DeRef(_data_inlined_crash_at_160_10216);
    _data_inlined_crash_at_160_10216 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_163_10217);
    _msg_inlined_crash_at_163_10217 = NOVALUE;
L8: 

    /** io.e:1639			close_fn = 1*/
    _close_fn_10188 = 1LL;
    goto LA; // [188] 199
L2: 

    /** io.e:1641			real_fn = fn*/
    Ref(_fn_10185);
    _real_fn_10187 = _fn_10185;
    if (!IS_ATOM_INT(_real_fn_10187)) {
        _1 = (object)(DBL_PTR(_real_fn_10187)->dbl);
        DeRefDS(_real_fn_10187);
        _real_fn_10187 = _1;
    }
LA: 

    /** io.e:1644		if equal(data_not_string, 0) then*/
    if (_data_not_string_10186 == 0LL)
    _5717 = 1;
    else if (IS_ATOM_INT(_data_not_string_10186) && IS_ATOM_INT(0LL))
    _5717 = 0;
    else
    _5717 = (compare(_data_not_string_10186, 0LL) == 0);
    if (_5717 == 0)
    {
        _5717 = NOVALUE;
        goto LB; // [205] 225
    }
    else{
        _5717 = NOVALUE;
    }

    /** io.e:1645			if types:t_display(data) then*/
    Ref(_data_10184);
    _5718 = _13t_display(_data_10184);
    if (_5718 == 0) {
        DeRef(_5718);
        _5718 = NOVALUE;
        goto LC; // [214] 224
    }
    else {
        if (!IS_ATOM_INT(_5718) && DBL_PTR(_5718)->dbl == 0.0){
            DeRef(_5718);
            _5718 = NOVALUE;
            goto LC; // [214] 224
        }
        DeRef(_5718);
        _5718 = NOVALUE;
    }
    DeRef(_5718);
    _5718 = NOVALUE;

    /** io.e:1646				data = {data}*/
    _0 = _data_10184;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_data_10184);
    ((intptr_t*)_2)[1] = _data_10184;
    _data_10184 = MAKE_SEQ(_1);
    DeRef(_0);
LC: 
LB: 

    /** io.e:1649	    puts(real_fn, text:format( fm, data ) )*/
    Ref(_fm_10183);
    Ref(_data_10184);
    _5720 = _14format(_fm_10183, _data_10184);
    EPuts(_real_fn_10187, _5720); // DJP 
    DeRef(_5720);
    _5720 = NOVALUE;

    /** io.e:1650	    if close_fn then*/
    if (_close_fn_10188 == 0)
    {
        goto LD; // [237] 245
    }
    else{
    }

    /** io.e:1651	    	close(real_fn)*/
    EClose(_real_fn_10187);
LD: 

    /** io.e:1653	end procedure*/
    DeRef(_fm_10183);
    DeRef(_data_10184);
    DeRef(_fn_10185);
    DeRefi(_out_style_10189);
    return;
    ;
}



// 0x3568F363
