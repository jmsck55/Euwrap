// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _39GetMsgText(object _MsgNum_20985, object _WithNum_20986, object _Args_20987)
{
    object _idx_20988 = NOVALUE;
    object _msgtext_20989 = NOVALUE;
    object _11958 = NOVALUE;
    object _11957 = NOVALUE;
    object _11953 = NOVALUE;
    object _11952 = NOVALUE;
    object _11950 = NOVALUE;
    object _11947 = NOVALUE;
    object _11945 = NOVALUE;
    object _11944 = NOVALUE;
    object _11943 = NOVALUE;
    object _11942 = NOVALUE;
    object _0, _1, _2;
    

    /** msgtext.e:757		integer idx = 1*/
    _idx_20988 = 1LL;

    /** msgtext.e:761		msgtext = get_text( MsgNum, LocalizeQual, LocalDB )*/
    Ref(_MsgNum_20985);
    RefDS(_37LocalizeQual_15425);
    RefDS(_37LocalDB_15426);
    _0 = _msgtext_20989;
    _msgtext_20989 = _40get_text(_MsgNum_20985, _37LocalizeQual_15425, _37LocalDB_15426);
    DeRef(_0);

    /** msgtext.e:764		if atom(msgtext) then*/
    _11942 = IS_ATOM(_msgtext_20989);
    if (_11942 == 0)
    {
        _11942 = NOVALUE;
        goto L1; // [25] 100
    }
    else{
        _11942 = NOVALUE;
    }

    /** msgtext.e:765			for i = 1 to length(StdErrMsgs) do*/
    _11943 = 365;
    {
        object _i_20997;
        _i_20997 = 1LL;
L2: 
        if (_i_20997 > 365LL){
            goto L3; // [35] 75
        }

        /** msgtext.e:766				if StdErrMsgs[i][1] = MsgNum then*/
        _2 = (object)SEQ_PTR(_39StdErrMsgs_20256);
        _11944 = (object)*(((s1_ptr)_2)->base + _i_20997);
        _2 = (object)SEQ_PTR(_11944);
        _11945 = (object)*(((s1_ptr)_2)->base + 1LL);
        _11944 = NOVALUE;
        if (binary_op_a(NOTEQ, _11945, _MsgNum_20985)){
            _11945 = NOVALUE;
            goto L4; // [54] 68
        }
        _11945 = NOVALUE;

        /** msgtext.e:767					idx = i*/
        _idx_20988 = _i_20997;

        /** msgtext.e:768					exit*/
        goto L3; // [65] 75
L4: 

        /** msgtext.e:770			end for*/
        _i_20997 = _i_20997 + 1LL;
        goto L2; // [70] 42
L3: 
        ;
    }

    /** msgtext.e:771			msgtext = StdErrMsgs[idx][2]*/
    _2 = (object)SEQ_PTR(_39StdErrMsgs_20256);
    _11947 = (object)*(((s1_ptr)_2)->base + _idx_20988);
    DeRef(_msgtext_20989);
    _2 = (object)SEQ_PTR(_11947);
    _msgtext_20989 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_msgtext_20989);
    _11947 = NOVALUE;

    /** msgtext.e:772			if idx = 1 then*/
    if (_idx_20988 != 1LL)
    goto L5; // [89] 99

    /** msgtext.e:773				Args = MsgNum*/
    Ref(_MsgNum_20985);
    DeRef(_Args_20987);
    _Args_20987 = _MsgNum_20985;
L5: 
L1: 

    /** msgtext.e:777		if atom(Args) or length(Args) != 0 then*/
    _11950 = IS_ATOM(_Args_20987);
    if (_11950 != 0) {
        goto L6; // [105] 121
    }
    if (IS_SEQUENCE(_Args_20987)){
            _11952 = SEQ_PTR(_Args_20987)->length;
    }
    else {
        _11952 = 1;
    }
    _11953 = (_11952 != 0LL);
    _11952 = NOVALUE;
    if (_11953 == 0)
    {
        DeRef(_11953);
        _11953 = NOVALUE;
        goto L7; // [117] 129
    }
    else{
        DeRef(_11953);
        _11953 = NOVALUE;
    }
L6: 

    /** msgtext.e:778			msgtext = format(msgtext, Args)*/
    Ref(_msgtext_20989);
    Ref(_Args_20987);
    _0 = _msgtext_20989;
    _msgtext_20989 = _14format(_msgtext_20989, _Args_20987);
    DeRef(_0);
L7: 

    /** msgtext.e:781		if WithNum != 0 then*/
    if (_WithNum_20986 == 0LL)
    goto L8; // [131] 152

    /** msgtext.e:782			return sprintf("<%04d>:: %s", {MsgNum, msgtext})*/
    Ref(_msgtext_20989);
    Ref(_MsgNum_20985);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _MsgNum_20985;
    ((intptr_t *)_2)[2] = _msgtext_20989;
    _11957 = MAKE_SEQ(_1);
    _11958 = EPrintf(-9999999, _11956, _11957);
    DeRefDS(_11957);
    _11957 = NOVALUE;
    DeRef(_MsgNum_20985);
    DeRef(_Args_20987);
    DeRef(_msgtext_20989);
    return _11958;
    goto L9; // [149] 159
L8: 

    /** msgtext.e:784			return msgtext*/
    DeRef(_MsgNum_20985);
    DeRef(_Args_20987);
    DeRef(_11958);
    _11958 = NOVALUE;
    return _msgtext_20989;
L9: 
    ;
}


void _39ShowMsg(object _Cons_21022, object _Msg_21023, object _Args_21024, object _NL_21025)
{
    object _11965 = NOVALUE;
    object _11964 = NOVALUE;
    object _11962 = NOVALUE;
    object _11960 = NOVALUE;
    object _11959 = NOVALUE;
    object _0, _1, _2;
    

    /** msgtext.e:790		if atom(Msg) then*/
    _11959 = 1;
    if (_11959 == 0)
    {
        _11959 = NOVALUE;
        goto L1; // [10] 25
    }
    else{
        _11959 = NOVALUE;
    }

    /** msgtext.e:791			Msg = GetMsgText(floor(Msg), 0)*/
    _11960 = e_floor(_Msg_21023);
    RefDS(_5);
    _Msg_21023 = _39GetMsgText(_11960, 0LL, _5);
    _11960 = NOVALUE;
L1: 

    /** msgtext.e:794		if atom(Args) or length(Args) != 0 then*/
    _11962 = IS_ATOM(_Args_21024);
    if (_11962 != 0) {
        goto L2; // [30] 46
    }
    if (IS_SEQUENCE(_Args_21024)){
            _11964 = SEQ_PTR(_Args_21024)->length;
    }
    else {
        _11964 = 1;
    }
    _11965 = (_11964 != 0LL);
    _11964 = NOVALUE;
    if (_11965 == 0)
    {
        DeRef(_11965);
        _11965 = NOVALUE;
        goto L3; // [42] 54
    }
    else{
        DeRef(_11965);
        _11965 = NOVALUE;
    }
L2: 

    /** msgtext.e:795			Msg = format(Msg, Args)*/
    Ref(_Msg_21023);
    Ref(_Args_21024);
    _0 = _Msg_21023;
    _Msg_21023 = _14format(_Msg_21023, _Args_21024);
    DeRef(_0);
L3: 

    /** msgtext.e:798		puts(Cons, Msg)*/
    EPuts(_Cons_21022, _Msg_21023); // DJP 

    /** msgtext.e:800		if NL then*/
    if (_NL_21025 == 0)
    {
        goto L4; // [61] 70
    }
    else{
    }

    /** msgtext.e:801			puts(Cons, '\n')*/
    EPuts(_Cons_21022, 10LL); // DJP 
L4: 

    /** msgtext.e:804	end procedure*/
    DeRef(_Msg_21023);
    DeRef(_Args_21024);
    return;
    ;
}



// 0x2AE55C49
