// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _36set_target_integer_size(object _sizeof_pointer_21274)
{
    object _12043 = NOVALUE;
    object _0, _1, _2;
    

    /** global.e:297		if sizeof_pointer = 4 then*/
    if (_sizeof_pointer_21274 != 4LL)
    goto L1; // [5] 17

    /** global.e:298			TMAXINT = max_int32*/
    DeRef(_36TMAXINT_21268);
    _36TMAXINT_21268 = 1073741823LL;
    goto L2; // [14] 25
L1: 

    /** global.e:300			TMAXINT = max_int64*/
    Ref(_36max_int64_21257);
    DeRef(_36TMAXINT_21268);
    _36TMAXINT_21268 = _36max_int64_21257;
L2: 

    /** global.e:303		TMININT = -TMAXINT - 1*/
    if (IS_ATOM_INT(_36TMAXINT_21268)) {
        if ((uintptr_t)_36TMAXINT_21268 == (uintptr_t)HIGH_BITS){
            _12043 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _12043 = - _36TMAXINT_21268;
        }
    }
    else {
        _12043 = unary_op(UMINUS, _36TMAXINT_21268);
    }
    DeRef(_36TMININT_21269);
    if (IS_ATOM_INT(_12043)) {
        _36TMININT_21269 = _12043 - 1LL;
        if ((object)((uintptr_t)_36TMININT_21269 +(uintptr_t) HIGH_BITS) >= 0){
            _36TMININT_21269 = NewDouble((eudouble)_36TMININT_21269);
        }
    }
    else {
        _36TMININT_21269 = NewDouble(DBL_PTR(_12043)->dbl - (eudouble)1LL);
    }
    DeRef(_12043);
    _12043 = NOVALUE;

    /** global.e:304		TMAXINT_DBL = TMAXINT*/
    Ref(_36TMAXINT_21268);
    DeRef(_36TMAXINT_DBL_21271);
    _36TMAXINT_DBL_21271 = _36TMAXINT_21268;

    /** global.e:305		TMININT_DBL = TMININT*/
    Ref(_36TMININT_21269);
    DeRef(_36TMININT_DBL_21270);
    _36TMININT_DBL_21270 = _36TMININT_21269;

    /** global.e:306	end procedure*/
    return;
    ;
}


object _36is_integer(object _o_21282)
{
    object _12051 = NOVALUE;
    object _12050 = NOVALUE;
    object _12049 = NOVALUE;
    object _12047 = NOVALUE;
    object _12045 = NOVALUE;
    object _0, _1, _2;
    

    /** global.e:310		if not atom( o ) then*/
    _12045 = IS_ATOM(_o_21282);
    if (_12045 != 0)
    goto L1; // [6] 16
    _12045 = NOVALUE;

    /** global.e:311			return 0*/
    DeRef(_o_21282);
    return 0LL;
L1: 

    /** global.e:314		if o = floor( o ) then*/
    if (IS_ATOM_INT(_o_21282))
    _12047 = e_floor(_o_21282);
    else
    _12047 = unary_op(FLOOR, _o_21282);
    if (binary_op_a(NOTEQ, _o_21282, _12047)){
        DeRef(_12047);
        _12047 = NOVALUE;
        goto L2; // [21] 55
    }
    DeRef(_12047);
    _12047 = NOVALUE;

    /** global.e:315			if o <= TMAXINT and o >= TMININT then*/
    if (IS_ATOM_INT(_o_21282) && IS_ATOM_INT(_36TMAXINT_21268)) {
        _12049 = (_o_21282 <= _36TMAXINT_21268);
    }
    else {
        _12049 = binary_op(LESSEQ, _o_21282, _36TMAXINT_21268);
    }
    if (IS_ATOM_INT(_12049)) {
        if (_12049 == 0) {
            goto L3; // [33] 54
        }
    }
    else {
        if (DBL_PTR(_12049)->dbl == 0.0) {
            goto L3; // [33] 54
        }
    }
    if (IS_ATOM_INT(_o_21282) && IS_ATOM_INT(_36TMININT_21269)) {
        _12051 = (_o_21282 >= _36TMININT_21269);
    }
    else {
        _12051 = binary_op(GREATEREQ, _o_21282, _36TMININT_21269);
    }
    if (_12051 == 0) {
        DeRef(_12051);
        _12051 = NOVALUE;
        goto L3; // [44] 54
    }
    else {
        if (!IS_ATOM_INT(_12051) && DBL_PTR(_12051)->dbl == 0.0){
            DeRef(_12051);
            _12051 = NOVALUE;
            goto L3; // [44] 54
        }
        DeRef(_12051);
        _12051 = NOVALUE;
    }
    DeRef(_12051);
    _12051 = NOVALUE;

    /** global.e:316				return 1*/
    DeRef(_o_21282);
    DeRef(_12049);
    _12049 = NOVALUE;
    return 1LL;
L3: 
L2: 

    /** global.e:319		return 0*/
    DeRef(_o_21282);
    DeRef(_12049);
    _12049 = NOVALUE;
    return 0LL;
    ;
}


object _36symtab_index(object _x_21306)
{
    object _12067 = NOVALUE;
    object _12066 = NOVALUE;
    object _12065 = NOVALUE;
    object _12064 = NOVALUE;
    object _12063 = NOVALUE;
    object _12062 = NOVALUE;
    object _12060 = NOVALUE;
    object _0, _1, _2;
    

    /** global.e:337		if x = 0 then*/
    if (_x_21306 != 0LL)
    goto L1; // [5] 18

    /** global.e:338			return TRUE -- NULL value*/
    return _13TRUE_452;
L1: 

    /** global.e:340		if x < 0 or x > length(SymTab) then*/
    _12060 = (_x_21306 < 0LL);
    if (_12060 != 0) {
        goto L2; // [24] 42
    }
    if (IS_SEQUENCE(_37SymTab_15406)){
            _12062 = SEQ_PTR(_37SymTab_15406)->length;
    }
    else {
        _12062 = 1;
    }
    _12063 = (_x_21306 > _12062);
    _12062 = NOVALUE;
    if (_12063 == 0)
    {
        DeRef(_12063);
        _12063 = NOVALUE;
        goto L3; // [38] 51
    }
    else{
        DeRef(_12063);
        _12063 = NOVALUE;
    }
L2: 

    /** global.e:341			return FALSE*/
    DeRef(_12060);
    _12060 = NOVALUE;
    return _13FALSE_450;
L3: 

    /** global.e:343		return find(length(SymTab[x]), {SIZEOF_VAR_ENTRY, SIZEOF_ROUTINE_ENTRY,*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _12064 = (object)*(((s1_ptr)_2)->base + _x_21306);
    if (IS_SEQUENCE(_12064)){
            _12065 = SEQ_PTR(_12064)->length;
    }
    else {
        _12065 = 1;
    }
    _12064 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _36SIZEOF_VAR_ENTRY_21205;
    ((intptr_t*)_2)[2] = _36SIZEOF_ROUTINE_ENTRY_21202;
    ((intptr_t*)_2)[3] = _36SIZEOF_TEMP_ENTRY_21211;
    ((intptr_t*)_2)[4] = _36SIZEOF_BLOCK_ENTRY_21208;
    _12066 = MAKE_SEQ(_1);
    _12067 = find_from(_12065, _12066, 1LL);
    _12065 = NOVALUE;
    DeRefDS(_12066);
    _12066 = NOVALUE;
    DeRef(_12060);
    _12060 = NOVALUE;
    _12064 = NOVALUE;
    return _12067;
    ;
}



// 0x3404BF26
