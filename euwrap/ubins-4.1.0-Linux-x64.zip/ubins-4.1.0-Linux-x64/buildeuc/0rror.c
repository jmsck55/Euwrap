// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _50screen_output(object _f_49245, object _msg_49246)
{
    object _0, _1, _2;
    

    /** error.e:44		puts(f, msg)*/
    EPuts(2LL, _msg_49246); // DJP 

    /** error.e:45	end procedure*/
    DeRefDS(_msg_49246);
    return;
    ;
}


void _50Warning(object _msg_49249, object _mask_49250, object _args_49251)
{
    object _orig_mask_49252 = NOVALUE;
    object _text_49253 = NOVALUE;
    object _w_name_49254 = NOVALUE;
    object _25292 = NOVALUE;
    object _25290 = NOVALUE;
    object _25288 = NOVALUE;
    object _25285 = NOVALUE;
    object _25280 = NOVALUE;
    object _25278 = NOVALUE;
    object _25277 = NOVALUE;
    object _25276 = NOVALUE;
    object _25275 = NOVALUE;
    object _25273 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:54		if display_warnings = 0 then*/

    /** error.e:58		if not Strict_is_on or Strict_Override then*/
    _25273 = (_36Strict_is_on_21508 == 0);
    if (_25273 != 0) {
        goto L1; // [26] 37
    }
    if (_36Strict_Override_21509 == 0)
    {
        goto L2; // [33] 56
    }
    else{
    }
L1: 

    /** error.e:59			if find(mask, strict_only_warnings) then*/
    _25275 = find_from(_mask_49250, _36strict_only_warnings_21506, 1LL);
    if (_25275 == 0)
    {
        _25275 = NOVALUE;
        goto L3; // [46] 55
    }
    else{
        _25275 = NOVALUE;
    }

    /** error.e:60				return*/
    DeRef(_msg_49249);
    DeRefDS(_args_49251);
    DeRef(_text_49253);
    DeRef(_w_name_49254);
    DeRef(_25273);
    _25273 = NOVALUE;
    return;
L3: 
L2: 

    /** error.e:64		orig_mask = mask -- =0 for non maskable warnings - none implemented so far*/
    _orig_mask_49252 = _mask_49250;

    /** error.e:65		if Strict_is_on and Strict_Override = 0 then*/
    if (_36Strict_is_on_21508 == 0) {
        goto L4; // [65] 85
    }
    _25277 = (_36Strict_Override_21509 == 0LL);
    if (_25277 == 0)
    {
        DeRef(_25277);
        _25277 = NOVALUE;
        goto L4; // [76] 85
    }
    else{
        DeRef(_25277);
        _25277 = NOVALUE;
    }

    /** error.e:66			mask = 0*/
    _mask_49250 = 0LL;
L4: 

    /** error.e:69		if mask = 0 or and_bits(OpWarning, mask) then*/
    _25278 = (_mask_49250 == 0LL);
    if (_25278 != 0) {
        goto L5; // [91] 106
    }
    {uintptr_t tu;
         tu = (uintptr_t)_36OpWarning_21510 & (uintptr_t)_mask_49250;
         _25280 = MAKE_UINT(tu);
    }
    if (_25280 == 0) {
        DeRef(_25280);
        _25280 = NOVALUE;
        goto L6; // [102] 215
    }
    else {
        if (!IS_ATOM_INT(_25280) && DBL_PTR(_25280)->dbl == 0.0){
            DeRef(_25280);
            _25280 = NOVALUE;
            goto L6; // [102] 215
        }
        DeRef(_25280);
        _25280 = NOVALUE;
    }
    DeRef(_25280);
    _25280 = NOVALUE;
L5: 

    /** error.e:70			if orig_mask != 0 then*/
    if (_orig_mask_49252 == 0LL)
    goto L7; // [108] 122

    /** error.e:71				orig_mask = find(orig_mask,warning_flags)*/
    _orig_mask_49252 = find_from(_orig_mask_49252, _36warning_flags_21485, 1LL);
L7: 

    /** error.e:74			if orig_mask != 0 then*/
    if (_orig_mask_49252 == 0LL)
    goto L8; // [124] 145

    /** error.e:75				w_name = "{ " & warning_names[orig_mask] & " }"*/
    _2 = (object)SEQ_PTR(_36warning_names_21487);
    _25285 = (object)*(((s1_ptr)_2)->base + _orig_mask_49252);
    {
        object concat_list[3];

        concat_list[0] = _25286;
        concat_list[1] = _25285;
        concat_list[2] = _25284;
        Concat_N((object_ptr)&_w_name_49254, concat_list, 3);
    }
    _25285 = NOVALUE;
    goto L9; // [142] 153
L8: 

    /** error.e:77				w_name = "" -- not maskable*/
    RefDS(_21993);
    DeRef(_w_name_49254);
    _w_name_49254 = _21993;
L9: 

    /** error.e:80			if atom(msg) then*/
    _25288 = IS_ATOM(_msg_49249);
    if (_25288 == 0)
    {
        _25288 = NOVALUE;
        goto LA; // [158] 170
    }
    else{
        _25288 = NOVALUE;
    }

    /** error.e:81				msg = GetMsgText(msg, 1, args)*/
    Ref(_msg_49249);
    RefDS(_args_49251);
    _0 = _msg_49249;
    _msg_49249 = _39GetMsgText(_msg_49249, 1LL, _args_49251);
    DeRef(_0);
LA: 

    /** error.e:84			text = GetMsgText(WARNING_1T2, 0, {w_name, msg})*/
    Ref(_msg_49249);
    RefDS(_w_name_49254);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _w_name_49254;
    ((intptr_t *)_2)[2] = _msg_49249;
    _25290 = MAKE_SEQ(_1);
    _0 = _text_49253;
    _text_49253 = _39GetMsgText(204LL, 0LL, _25290);
    DeRef(_0);
    _25290 = NOVALUE;

    /** error.e:85			if find(text, warning_list) then*/
    _25292 = find_from(_text_49253, _50warning_list_49242, 1LL);
    if (_25292 == 0)
    {
        _25292 = NOVALUE;
        goto LB; // [197] 206
    }
    else{
        _25292 = NOVALUE;
    }

    /** error.e:86				return -- duplicate*/
    DeRef(_msg_49249);
    DeRefDS(_args_49251);
    DeRefDS(_text_49253);
    DeRefDS(_w_name_49254);
    DeRef(_25273);
    _25273 = NOVALUE;
    DeRef(_25278);
    _25278 = NOVALUE;
    return;
LB: 

    /** error.e:89			warning_list = append(warning_list, text)*/
    RefDS(_text_49253);
    Append(&_50warning_list_49242, _50warning_list_49242, _text_49253);
L6: 

    /** error.e:91	end procedure*/
    DeRef(_msg_49249);
    DeRefDS(_args_49251);
    DeRef(_text_49253);
    DeRef(_w_name_49254);
    DeRef(_25273);
    _25273 = NOVALUE;
    DeRef(_25278);
    _25278 = NOVALUE;
    return;
    ;
}


object _50ShowWarnings()
{
    object _c_49319 = NOVALUE;
    object _errfile_49320 = NOVALUE;
    object _twf_49321 = NOVALUE;
    object _25331 = NOVALUE;
    object _25328 = NOVALUE;
    object _25327 = NOVALUE;
    object _25326 = NOVALUE;
    object _25325 = NOVALUE;
    object _25324 = NOVALUE;
    object _25323 = NOVALUE;
    object _25321 = NOVALUE;
    object _25320 = NOVALUE;
    object _25319 = NOVALUE;
    object _25317 = NOVALUE;
    object _25316 = NOVALUE;
    object _25315 = NOVALUE;
    object _25314 = NOVALUE;
    object _25312 = NOVALUE;
    object _25308 = NOVALUE;
    object _25306 = NOVALUE;
    object _25305 = NOVALUE;
    object _25304 = NOVALUE;
    object _25302 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:117		if display_warnings = 0 or length(warning_list) = 0 then*/
    _25302 = (1LL == 0LL);
    if (_25302 != 0) {
        goto L1; // [9] 27
    }
    if (IS_SEQUENCE(_50warning_list_49242)){
            _25304 = SEQ_PTR(_50warning_list_49242)->length;
    }
    else {
        _25304 = 1;
    }
    _25305 = (_25304 == 0LL);
    _25304 = NOVALUE;
    if (_25305 == 0)
    {
        DeRef(_25305);
        _25305 = NOVALUE;
        goto L2; // [23] 39
    }
    else{
        DeRef(_25305);
        _25305 = NOVALUE;
    }
L1: 

    /** error.e:118			return length(warning_list)*/
    if (IS_SEQUENCE(_50warning_list_49242)){
            _25306 = SEQ_PTR(_50warning_list_49242)->length;
    }
    else {
        _25306 = 1;
    }
    DeRef(_25302);
    _25302 = NOVALUE;
    return _25306;
L2: 

    /** error.e:121		if TempErrFile > 0 then*/
    if (_50TempErrFile_49231 <= 0LL)
    goto L3; // [43] 57

    /** error.e:122			errfile = TempErrFile*/
    _errfile_49320 = _50TempErrFile_49231;
    goto L4; // [54] 67
L3: 

    /** error.e:124			errfile = STDERR*/
    _errfile_49320 = 2LL;
L4: 

    /** error.e:127		if not integer(TempWarningName) then*/
    if (IS_ATOM_INT(_36TempWarningName_21453))
    _25308 = 1;
    else if (IS_ATOM_DBL(_36TempWarningName_21453))
    _25308 = IS_ATOM_INT(DoubleToInt(_36TempWarningName_21453));
    else
    _25308 = 0;
    if (_25308 != 0)
    goto L5; // [74] 183
    _25308 = NOVALUE;

    /** error.e:128			twf = open(TempWarningName,"w")*/
    _twf_49321 = EOpen(_36TempWarningName_21453, _22129, 0LL);

    /** error.e:129			if twf = -1 then*/
    if (_twf_49321 != -1LL)
    goto L6; // [88] 140

    /** error.e:130				ShowMsg(errfile, UNABLE_TO_CREATE_WARNING_FILE_1, {TempWarningName})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_36TempWarningName_21453);
    ((intptr_t*)_2)[1] = _36TempWarningName_21453;
    _25312 = MAKE_SEQ(_1);
    _39ShowMsg(_errfile_49320, 205LL, _25312, 1LL);
    _25312 = NOVALUE;

    /** error.e:131				if errfile != STDERR then*/
    if (_errfile_49320 == 2LL)
    goto L7; // [114] 177

    /** error.e:132					ShowMsg(STDERR, UNABLE_TO_CREATE_WARNING_FILE_1, {TempWarningName})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_36TempWarningName_21453);
    ((intptr_t*)_2)[1] = _36TempWarningName_21453;
    _25314 = MAKE_SEQ(_1);
    _39ShowMsg(2LL, 205LL, _25314, 1LL);
    _25314 = NOVALUE;
    goto L7; // [137] 177
L6: 

    /** error.e:135				for i = 1 to length(warning_list) do*/
    if (IS_SEQUENCE(_50warning_list_49242)){
            _25315 = SEQ_PTR(_50warning_list_49242)->length;
    }
    else {
        _25315 = 1;
    }
    {
        object _i_49354;
        _i_49354 = 1LL;
L8: 
        if (_i_49354 > _25315){
            goto L9; // [147] 172
        }

        /** error.e:136					puts(twf, warning_list[i])*/
        _2 = (object)SEQ_PTR(_50warning_list_49242);
        _25316 = (object)*(((s1_ptr)_2)->base + _i_49354);
        EPuts(_twf_49321, _25316); // DJP 
        _25316 = NOVALUE;

        /** error.e:137				end for*/
        _i_49354 = _i_49354 + 1LL;
        goto L8; // [167] 154
L9: 
        ;
    }

    /** error.e:138			    close(twf)*/
    EClose(_twf_49321);
L7: 

    /** error.e:140			TempWarningName = 99 -- Flag that we have done this already.*/
    DeRef(_36TempWarningName_21453);
    _36TempWarningName_21453 = 99LL;
L5: 

    /** error.e:143		if batch_job = 0 or errfile != STDERR then*/
    _25317 = (_36batch_job_21452 == 0LL);
    if (_25317 != 0) {
        goto LA; // [191] 208
    }
    _25319 = (_errfile_49320 != 2LL);
    if (_25319 == 0)
    {
        DeRef(_25319);
        _25319 = NOVALUE;
        goto LB; // [204] 317
    }
    else{
        DeRef(_25319);
        _25319 = NOVALUE;
    }
LA: 

    /** error.e:144			for i = 1 to length(warning_list) do*/
    if (IS_SEQUENCE(_50warning_list_49242)){
            _25320 = SEQ_PTR(_50warning_list_49242)->length;
    }
    else {
        _25320 = 1;
    }
    {
        object _i_49365;
        _i_49365 = 1LL;
LC: 
        if (_i_49365 > _25320){
            goto LD; // [215] 316
        }

        /** error.e:145				puts(errfile, warning_list[i])*/
        _2 = (object)SEQ_PTR(_50warning_list_49242);
        _25321 = (object)*(((s1_ptr)_2)->base + _i_49365);
        EPuts(_errfile_49320, _25321); // DJP 
        _25321 = NOVALUE;

        /** error.e:146				if errfile = STDERR then*/
        if (_errfile_49320 != 2LL)
        goto LE; // [239] 309

        /** error.e:147					if remainder(i, 20) = 0 and batch_job = 0 and test_only = 0 then*/
        _25323 = (_i_49365 % 20LL);
        _25324 = (_25323 == 0LL);
        _25323 = NOVALUE;
        if (_25324 == 0) {
            _25325 = 0;
            goto LF; // [253] 267
        }
        _25326 = (_36batch_job_21452 == 0LL);
        _25325 = (_25326 != 0);
LF: 
        if (_25325 == 0) {
            goto L10; // [267] 308
        }
        _25328 = (_36test_only_21451 == 0LL);
        if (_25328 == 0)
        {
            DeRef(_25328);
            _25328 = NOVALUE;
            goto L10; // [278] 308
        }
        else{
            DeRef(_25328);
            _25328 = NOVALUE;
        }

        /** error.e:148						ShowMsg(errfile, PRESS_ENTER_TO_CONTINUE_Q_TO_QUIT)*/
        RefDS(_21993);
        _39ShowMsg(_errfile_49320, 206LL, _21993, 1LL);

        /** error.e:149						c = getc(0)*/
        if (0LL != last_r_file_no) {
            last_r_file_ptr = which_file(0LL, EF_READ);
            last_r_file_no = 0LL;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _c_49319 = getc((FILE*)xstdin);
            }
            else{
                _c_49319 = getc(last_r_file_ptr);
            }
        }
        else{
            _c_49319 = getc(last_r_file_ptr);
        }

        /** error.e:150						if c = 'q' then*/
        if (_c_49319 != 113LL)
        goto L11; // [298] 307

        /** error.e:151							exit*/
        goto LD; // [304] 316
L11: 
L10: 
LE: 

        /** error.e:155			end for*/
        _i_49365 = _i_49365 + 1LL;
        goto LC; // [311] 222
LD: 
        ;
    }
LB: 

    /** error.e:158		return length(warning_list)*/
    if (IS_SEQUENCE(_50warning_list_49242)){
            _25331 = SEQ_PTR(_50warning_list_49242)->length;
    }
    else {
        _25331 = 1;
    }
    DeRef(_25317);
    _25317 = NOVALUE;
    DeRef(_25302);
    _25302 = NOVALUE;
    DeRef(_25324);
    _25324 = NOVALUE;
    DeRef(_25326);
    _25326 = NOVALUE;
    return _25331;
    ;
}


void _50ShowDefines(object _errfile_49388)
{
    object _c_49389 = NOVALUE;
    object _25345 = NOVALUE;
    object _25344 = NOVALUE;
    object _25342 = NOVALUE;
    object _25341 = NOVALUE;
    object _25338 = NOVALUE;
    object _25337 = NOVALUE;
    object _25336 = NOVALUE;
    object _25335 = NOVALUE;
    object _25334 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:164		if errfile=0 then*/
    if (_errfile_49388 != 0LL)
    goto L1; // [5] 19

    /** error.e:165			errfile = STDERR*/
    _errfile_49388 = 2LL;
L1: 

    /** error.e:168		puts(errfile, format("\n--- [1] ---\n", {GetMsgText(DEFINED_WORDS,0)}))*/
    RefDS(_21993);
    _25334 = _39GetMsgText(207LL, 0LL, _21993);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _25334;
    _25335 = MAKE_SEQ(_1);
    _25334 = NOVALUE;
    RefDS(_25333);
    _25336 = _14format(_25333, _25335);
    _25335 = NOVALUE;
    EPuts(_errfile_49388, _25336); // DJP 
    DeRef(_25336);
    _25336 = NOVALUE;

    /** error.e:170		for i = 1 to length(OpDefines) do*/
    if (IS_SEQUENCE(_36OpDefines_21516)){
            _25337 = SEQ_PTR(_36OpDefines_21516)->length;
    }
    else {
        _25337 = 1;
    }
    {
        object _i_49401;
        _i_49401 = 1LL;
L2: 
        if (_i_49401 > _25337){
            goto L3; // [48] 100
        }

        /** error.e:171			if find(OpDefines[i], {"_PLAT_START", "_PLAT_STOP"}) = 0 then*/
        _2 = (object)SEQ_PTR(_36OpDefines_21516);
        _25338 = (object)*(((s1_ptr)_2)->base + _i_49401);
        RefDS(_25340);
        RefDS(_25339);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _25339;
        ((intptr_t *)_2)[2] = _25340;
        _25341 = MAKE_SEQ(_1);
        _25342 = find_from(_25338, _25341, 1LL);
        _25338 = NOVALUE;
        DeRefDS(_25341);
        _25341 = NOVALUE;
        if (_25342 != 0LL)
        goto L4; // [72] 93

        /** error.e:172				printf(errfile, "%s\n", {OpDefines[i]})*/
        _2 = (object)SEQ_PTR(_36OpDefines_21516);
        _25344 = (object)*(((s1_ptr)_2)->base + _i_49401);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_25344);
        ((intptr_t*)_2)[1] = _25344;
        _25345 = MAKE_SEQ(_1);
        _25344 = NOVALUE;
        EPrintf(_errfile_49388, _25226, _25345);
        DeRefDS(_25345);
        _25345 = NOVALUE;
L4: 

        /** error.e:174		end for*/
        _i_49401 = _i_49401 + 1LL;
        goto L2; // [95] 55
L3: 
        ;
    }

    /** error.e:175		puts(errfile, "-------------------\n")*/
    EPuts(_errfile_49388, _25346); // DJP 

    /** error.e:177	end procedure*/
    return;
    ;
}


void _50Cleanup(object _status_49418)
{
    object _w_49419 = NOVALUE;
    object _show_error_49420 = NOVALUE;
    object _25364 = NOVALUE;
    object _25363 = NOVALUE;
    object _25362 = NOVALUE;
    object _25361 = NOVALUE;
    object _25360 = NOVALUE;
    object _25359 = NOVALUE;
    object _25358 = NOVALUE;
    object _25357 = NOVALUE;
    object _25356 = NOVALUE;
    object _25355 = NOVALUE;
    object _25353 = NOVALUE;
    object _25352 = NOVALUE;
    object _25351 = NOVALUE;
    object _25350 = NOVALUE;
    object _25349 = NOVALUE;
    object _25347 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:182		integer w, show_error = 0*/
    _show_error_49420 = 0LL;

    /** error.e:184		ifdef EU_EX then*/

    /** error.e:190		show_error = 1*/
    _show_error_49420 = 1LL;

    /** error.e:196		if object(src_file) = 0 then*/
    if( NOVALUE == _36src_file_21564 ){
        _25347 = 0;
    }
    else{
        _25347 = 1;
    }
    if (_25347 != 0LL)
    goto L1; // [20] 34

    /** error.e:197			src_file = -1*/
    _36src_file_21564 = -1LL;
    goto L2; // [31] 86
L1: 

    /** error.e:198		elsif src_file >= 0 and (src_file != repl_file or not repl) then*/
    _25349 = (_36src_file_21564 >= 0LL);
    if (_25349 == 0) {
        goto L3; // [42] 85
    }
    _25351 = (_36src_file_21564 != 5555LL);
    if (_25351 != 0) {
        DeRef(_25352);
        _25352 = 1;
        goto L4; // [54] 67
    }
    _25353 = (0LL == 0);
    _25352 = (_25353 != 0);
L4: 
    if (_25352 == 0)
    {
        _25352 = NOVALUE;
        goto L3; // [68] 85
    }
    else{
        _25352 = NOVALUE;
    }

    /** error.e:199			close(src_file)*/
    EClose(_36src_file_21564);

    /** error.e:200			src_file = -1*/
    _36src_file_21564 = -1LL;
L3: 
L2: 

    /** error.e:203		w = ShowWarnings()*/
    _w_49419 = _50ShowWarnings();
    if (!IS_ATOM_INT(_w_49419)) {
        _1 = (object)(DBL_PTR(_w_49419)->dbl);
        DeRefDS(_w_49419);
        _w_49419 = _1;
    }

    /** error.e:204		if not TRANSLATE and (BIND or show_error) and (w or Errors) then*/
    _25355 = (_36TRANSLATE_21041 == 0);
    if (_25355 == 0) {
        _25356 = 0;
        goto L5; // [100] 118
    }
    if (_36BIND_21044 != 0) {
        _25357 = 1;
        goto L6; // [106] 114
    }
    _25357 = (_show_error_49420 != 0);
L6: 
    _25356 = (_25357 != 0);
L5: 
    if (_25356 == 0) {
        goto L7; // [118] 179
    }
    if (_w_49419 != 0) {
        DeRef(_25359);
        _25359 = 1;
        goto L8; // [122] 132
    }
    _25359 = (_50Errors_49230 != 0);
L8: 
    if (_25359 == 0)
    {
        _25359 = NOVALUE;
        goto L7; // [133] 179
    }
    else{
        _25359 = NOVALUE;
    }

    /** error.e:205			if not batch_job and not test_only then*/
    _25360 = (_36batch_job_21452 == 0);
    if (_25360 == 0) {
        goto L9; // [143] 178
    }
    _25362 = (_36test_only_21451 == 0);
    if (_25362 == 0)
    {
        DeRef(_25362);
        _25362 = NOVALUE;
        goto L9; // [153] 178
    }
    else{
        DeRef(_25362);
        _25362 = NOVALUE;
    }

    /** error.e:206				screen_output(STDERR, GetMsgText(PRESS_ENTER,0))*/
    RefDS(_21993);
    _25363 = _39GetMsgText(208LL, 0LL, _21993);
    _50screen_output(2LL, _25363);
    _25363 = NOVALUE;

    /** error.e:207				getc(0) -- wait*/
    if (0LL != last_r_file_no) {
        last_r_file_ptr = which_file(0LL, EF_READ);
        last_r_file_no = 0LL;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _25364 = getc((FILE*)xstdin);
        }
        else{
            _25364 = getc(last_r_file_ptr);
        }
    }
    else{
        _25364 = getc(last_r_file_ptr);
    }
L9: 
L7: 

    /** error.e:212		cleanup_open_includes()*/
    _62cleanup_open_includes();

    /** error.e:213		abort(status)*/
    UserCleanup(_status_49418);

    /** error.e:214	end procedure*/
    DeRef(_25360);
    _25360 = NOVALUE;
    DeRef(_25351);
    _25351 = NOVALUE;
    DeRef(_25355);
    _25355 = NOVALUE;
    DeRef(_25353);
    _25353 = NOVALUE;
    DeRef(_25349);
    _25349 = NOVALUE;
    return;
    ;
}


void _50OpenErrFile()
{
    object _25371 = NOVALUE;
    object _25370 = NOVALUE;
    object _25368 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:219	    if TempErrFile != -1 then*/
    if (_50TempErrFile_49231 == -1LL)
    goto L1; // [5] 19

    /** error.e:220			TempErrFile = open(TempErrName, "w")*/
    _50TempErrFile_49231 = EOpen(_50TempErrName_49232, _22129, 0LL);
L1: 

    /** error.e:223		if TempErrFile = -1 then*/
    if (_50TempErrFile_49231 != -1LL)
    goto L2; // [23] 66

    /** error.e:224			if length(TempErrName) > 0 then*/
    _25368 = 6;

    /** error.e:225				screen_output(STDERR, GetMsgText(CANT_CREATE_ERROR_MESSAGE_FILE_1, 0, {TempErrName}))*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_50TempErrName_49232);
    ((intptr_t*)_2)[1] = _50TempErrName_49232;
    _25370 = MAKE_SEQ(_1);
    _25371 = _39GetMsgText(209LL, 0LL, _25370);
    _25370 = NOVALUE;
    _50screen_output(2LL, _25371);
    _25371 = NOVALUE;

    /** error.e:227			abort(1) -- with no clean up*/
    UserCleanup(1LL);
L2: 

    /** error.e:229	end procedure*/
    return;
    ;
}


void _50ShowErr(object _f_49476)
{
    object _msg_inlined_screen_output_at_43_49489 = NOVALUE;
    object _25378 = NOVALUE;
    object _25377 = NOVALUE;
    object _25376 = NOVALUE;
    object _25374 = NOVALUE;
    object _25372 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:234		if length(known_files) = 0 then*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _25372 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _25372 = 1;
    }
    if (_25372 != 0LL)
    goto L1; // [10] 20

    /** error.e:235			return*/
    return;
L1: 

    /** error.e:238		if ThisLine[1] = END_OF_FILE_CHAR then*/
    _2 = (object)SEQ_PTR(_50ThisLine_49234);
    _25374 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _25374, 26LL)){
        _25374 = NOVALUE;
        goto L2; // [30] 64
    }
    _25374 = NOVALUE;

    /** error.e:239			screen_output(f, GetMsgText(MSG_ENDOFFILE,0))*/
    RefDS(_21993);
    _25376 = _39GetMsgText(210LL, 0LL, _21993);
    DeRef(_msg_inlined_screen_output_at_43_49489);
    _msg_inlined_screen_output_at_43_49489 = _25376;
    _25376 = NOVALUE;

    /** error.e:44		puts(f, msg)*/
    EPuts(_f_49476, _msg_inlined_screen_output_at_43_49489); // DJP 

    /** error.e:45	end procedure*/
    goto L3; // [56] 59
L3: 
    DeRef(_msg_inlined_screen_output_at_43_49489);
    _msg_inlined_screen_output_at_43_49489 = NOVALUE;
    goto L4; // [61] 81
L2: 

    /** error.e:241			screen_output(f, ThisLine)*/

    /** error.e:44		puts(f, msg)*/
    EPuts(_f_49476, _50ThisLine_49234); // DJP 

    /** error.e:45	end procedure*/
    goto L5; // [77] 80
L5: 
L4: 

    /** error.e:244		for i = 1 to bp-2 do -- bp-1 points to last character read*/
    _25377 = _50bp_49238 - 2LL;
    if ((object)((uintptr_t)_25377 +(uintptr_t) HIGH_BITS) >= 0){
        _25377 = NewDouble((eudouble)_25377);
    }
    {
        object _i_49493;
        _i_49493 = 1LL;
L6: 
        if (binary_op_a(GREATER, _i_49493, _25377)){
            goto L7; // [89] 143
        }

        /** error.e:245			if ThisLine[i] = '\t' then*/
        _2 = (object)SEQ_PTR(_50ThisLine_49234);
        if (!IS_ATOM_INT(_i_49493)){
            _25378 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_49493)->dbl));
        }
        else{
            _25378 = (object)*(((s1_ptr)_2)->base + _i_49493);
        }
        if (binary_op_a(NOTEQ, _25378, 9LL)){
            _25378 = NOVALUE;
            goto L8; // [104] 123
        }
        _25378 = NOVALUE;

        /** error.e:246				screen_output(f, "\t")*/

        /** error.e:44		puts(f, msg)*/
        EPuts(_f_49476, _23939); // DJP 

        /** error.e:45	end procedure*/
        goto L9; // [117] 136
        goto L9; // [120] 136
L8: 

        /** error.e:248				screen_output(f, " ")*/

        /** error.e:44		puts(f, msg)*/
        EPuts(_f_49476, _23384); // DJP 

        /** error.e:45	end procedure*/
        goto LA; // [132] 135
LA: 
L9: 

        /** error.e:250		end for*/
        _0 = _i_49493;
        if (IS_ATOM_INT(_i_49493)) {
            _i_49493 = _i_49493 + 1LL;
            if ((object)((uintptr_t)_i_49493 +(uintptr_t) HIGH_BITS) >= 0){
                _i_49493 = NewDouble((eudouble)_i_49493);
            }
        }
        else {
            _i_49493 = binary_op_a(PLUS, _i_49493, 1LL);
        }
        DeRef(_0);
        goto L6; // [138] 96
L7: 
        ;
        DeRef(_i_49493);
    }

    /** error.e:252		screen_output(f, "^\n\n")*/

    /** error.e:44		puts(f, msg)*/
    EPuts(_f_49476, _25380); // DJP 

    /** error.e:45	end procedure*/
    goto LB; // [152] 155
LB: 

    /** error.e:253	end procedure*/
    DeRef(_25377);
    _25377 = NOVALUE;
    return;
    ;
}


void _50CompileErr(object _msg_49505, object _args_49506, object _preproc_49507)
{
    object _errmsg_49508 = NOVALUE;
    object _25401 = NOVALUE;
    object _25397 = NOVALUE;
    object _25396 = NOVALUE;
    object _25395 = NOVALUE;
    object _25394 = NOVALUE;
    object _25393 = NOVALUE;
    object _25392 = NOVALUE;
    object _25390 = NOVALUE;
    object _25389 = NOVALUE;
    object _25387 = NOVALUE;
    object _25386 = NOVALUE;
    object _25385 = NOVALUE;
    object _25381 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:260		if integer(msg) then*/
    if (IS_ATOM_INT(_msg_49505))
    _25381 = 1;
    else if (IS_ATOM_DBL(_msg_49505))
    _25381 = IS_ATOM_INT(DoubleToInt(_msg_49505));
    else
    _25381 = 0;
    if (_25381 == 0)
    {
        _25381 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _25381 = NOVALUE;
    }

    /** error.e:261			msg = GetMsgText(msg)*/
    Ref(_msg_49505);
    RefDS(_21993);
    _0 = _msg_49505;
    _msg_49505 = _39GetMsgText(_msg_49505, 1LL, _21993);
    DeRefi(_0);
L1: 

    /** error.e:264		msg = format(msg, args)*/
    Ref(_msg_49505);
    Ref(_args_49506);
    _0 = _msg_49505;
    _msg_49505 = _14format(_msg_49505, _args_49506);
    DeRef(_0);

    /** error.e:266		Errors += 1*/
    _50Errors_49230 = _50Errors_49230 + 1;

    /** error.e:267		if not preproc and length(known_files) then*/
    _25385 = (_preproc_49507 == 0);
    if (_25385 == 0) {
        goto L2; // [40] 78
    }
    if (IS_SEQUENCE(_37known_files_15407)){
            _25387 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _25387 = 1;
    }
    if (_25387 == 0)
    {
        _25387 = NOVALUE;
        goto L2; // [50] 78
    }
    else{
        _25387 = NOVALUE;
    }

    /** error.e:268			errmsg = sprintf("%s:%d\n%s\n", {known_files[current_file_no],*/
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _25389 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_25389);
    ((intptr_t*)_2)[1] = _25389;
    ((intptr_t*)_2)[2] = _36line_number_21440;
    Ref(_msg_49505);
    ((intptr_t*)_2)[3] = _msg_49505;
    _25390 = MAKE_SEQ(_1);
    _25389 = NOVALUE;
    DeRef(_errmsg_49508);
    _errmsg_49508 = EPrintf(-9999999, _25388, _25390);
    DeRefDS(_25390);
    _25390 = NOVALUE;
    goto L3; // [75] 121
L2: 

    /** error.e:271			errmsg = msg*/
    Ref(_msg_49505);
    DeRef(_errmsg_49508);
    _errmsg_49508 = _msg_49505;

    /** error.e:272			if length(msg) > 0 and msg[$] != '\n' then*/
    if (IS_SEQUENCE(_msg_49505)){
            _25392 = SEQ_PTR(_msg_49505)->length;
    }
    else {
        _25392 = 1;
    }
    _25393 = (_25392 > 0LL);
    _25392 = NOVALUE;
    if (_25393 == 0) {
        goto L4; // [94] 120
    }
    if (IS_SEQUENCE(_msg_49505)){
            _25395 = SEQ_PTR(_msg_49505)->length;
    }
    else {
        _25395 = 1;
    }
    _2 = (object)SEQ_PTR(_msg_49505);
    _25396 = (object)*(((s1_ptr)_2)->base + _25395);
    if (IS_ATOM_INT(_25396)) {
        _25397 = (_25396 != 10LL);
    }
    else {
        _25397 = binary_op(NOTEQ, _25396, 10LL);
    }
    _25396 = NOVALUE;
    if (_25397 == 0) {
        DeRef(_25397);
        _25397 = NOVALUE;
        goto L4; // [110] 120
    }
    else {
        if (!IS_ATOM_INT(_25397) && DBL_PTR(_25397)->dbl == 0.0){
            DeRef(_25397);
            _25397 = NOVALUE;
            goto L4; // [110] 120
        }
        DeRef(_25397);
        _25397 = NOVALUE;
    }
    DeRef(_25397);
    _25397 = NOVALUE;

    /** error.e:273				errmsg &= '\n'*/
    Append(&_errmsg_49508, _errmsg_49508, 10LL);
L4: 
L3: 

    /** error.e:277		if not preproc then*/
    if (_preproc_49507 != 0)
    goto L5; // [123] 131

    /** error.e:279			OpenErrFile() -- exits if error filename is ""*/
    _50OpenErrFile();
L5: 

    /** error.e:281		screen_output(STDERR, errmsg)*/
    RefDS(_errmsg_49508);
    _50screen_output(2LL, _errmsg_49508);

    /** error.e:283		if not preproc then*/
    if (_preproc_49507 != 0)
    goto L6; // [143] 198

    /** error.e:284			ShowErr(STDERR)*/
    _50ShowErr(2LL);

    /** error.e:286			puts(TempErrFile, errmsg)*/
    EPuts(_50TempErrFile_49231, _errmsg_49508); // DJP 

    /** error.e:288			ShowErr(TempErrFile)*/
    _50ShowErr(_50TempErrFile_49231);

    /** error.e:290			ShowWarnings()*/
    _25401 = _50ShowWarnings();

    /** error.e:292			ShowDefines(TempErrFile)*/
    _50ShowDefines(_50TempErrFile_49231);

    /** error.e:294			close(TempErrFile)*/
    EClose(_50TempErrFile_49231);

    /** error.e:295			TempErrFile = -2*/
    _50TempErrFile_49231 = -2LL;

    /** error.e:296			ifdef CRASH_ON_ERROR then*/

    /** error.e:299			Cleanup(1)*/
    _50Cleanup(1LL);
L6: 

    /** error.e:302	end procedure*/
    DeRef(_msg_49505);
    DeRef(_args_49506);
    DeRef(_errmsg_49508);
    DeRef(_25385);
    _25385 = NOVALUE;
    DeRef(_25401);
    _25401 = NOVALUE;
    DeRef(_25393);
    _25393 = NOVALUE;
    return;
    ;
}


void _50InternalErr(object _msgno_49552, object _args_49553)
{
    object _msg_49554 = NOVALUE;
    object _25416 = NOVALUE;
    object _25415 = NOVALUE;
    object _25414 = NOVALUE;
    object _25413 = NOVALUE;
    object _25412 = NOVALUE;
    object _25411 = NOVALUE;
    object _25410 = NOVALUE;
    object _25409 = NOVALUE;
    object _25408 = NOVALUE;
    object _25407 = NOVALUE;
    object _25406 = NOVALUE;
    object _25403 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:316		if atom(args) then*/
    _25403 = 0;
    if (_25403 == 0)
    {
        _25403 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _25403 = NOVALUE;
    }

    /** error.e:317			args = {args}*/
    _0 = _args_49553;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_args_49553);
    ((intptr_t*)_2)[1] = _args_49553;
    _args_49553 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1: 

    /** error.e:320		msg = GetMsgText(msgno, 1, args)*/
    Ref(_args_49553);
    _0 = _msg_49554;
    _msg_49554 = _39GetMsgText(_msgno_49552, 1LL, _args_49553);
    DeRef(_0);

    /** error.e:321		if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L2; // [32] 58
    }
    else{
    }

    /** error.e:322			screen_output(STDERR, GetMsgText(INTERNAL_ERRORT1, 1, {msg}))*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_msg_49554);
    ((intptr_t*)_2)[1] = _msg_49554;
    _25406 = MAKE_SEQ(_1);
    _25407 = _39GetMsgText(211LL, 1LL, _25406);
    _25406 = NOVALUE;
    _50screen_output(2LL, _25407);
    _25407 = NOVALUE;
    goto L3; // [55] 91
L2: 

    /** error.e:324			screen_output(STDERR, GetMsgText(INTERNAL_ERROR_AT_12T3, 1, {known_files[current_file_no], line_number, msg}))*/
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _25408 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_25408);
    ((intptr_t*)_2)[1] = _25408;
    ((intptr_t*)_2)[2] = _36line_number_21440;
    RefDS(_msg_49554);
    ((intptr_t*)_2)[3] = _msg_49554;
    _25409 = MAKE_SEQ(_1);
    _25408 = NOVALUE;
    _25410 = _39GetMsgText(212LL, 1LL, _25409);
    _25409 = NOVALUE;
    _50screen_output(2LL, _25410);
    _25410 = NOVALUE;
L3: 

    /** error.e:327		if not batch_job and not test_only then*/
    _25411 = (_36batch_job_21452 == 0);
    if (_25411 == 0) {
        goto L4; // [98] 133
    }
    _25413 = (_36test_only_21451 == 0);
    if (_25413 == 0)
    {
        DeRef(_25413);
        _25413 = NOVALUE;
        goto L4; // [108] 133
    }
    else{
        DeRef(_25413);
        _25413 = NOVALUE;
    }

    /** error.e:328			screen_output(STDERR, GetMsgText(PRESS_ENTER, 0))*/
    RefDS(_21993);
    _25414 = _39GetMsgText(208LL, 0LL, _21993);
    _50screen_output(2LL, _25414);
    _25414 = NOVALUE;

    /** error.e:329			getc(0)*/
    if (0LL != last_r_file_no) {
        last_r_file_ptr = which_file(0LL, EF_READ);
        last_r_file_no = 0LL;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _25415 = getc((FILE*)xstdin);
        }
        else{
            _25415 = getc(last_r_file_ptr);
        }
    }
    else{
        _25415 = getc(last_r_file_ptr);
    }
L4: 

    /** error.e:333		machine_proc(67, GetMsgText(FAILED_DUE_TO_INTERNAL_ERROR))*/
    RefDS(_21993);
    _25416 = _39GetMsgText(213LL, 1LL, _21993);
    machine(67LL, _25416);
    DeRef(_25416);
    _25416 = NOVALUE;

    /** error.e:334	end procedure*/
    DeRef(_args_49553);
    DeRef(_msg_49554);
    DeRef(_25411);
    _25411 = NOVALUE;
    return;
    ;
}



// 0x7BDFC882
