// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _47Push(object _x_51187)
{
    object _26293 = NOVALUE;
    object _26291 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_51187)) {
        _1 = (object)(DBL_PTR(_x_51187)->dbl);
        DeRefDS(_x_51187);
        _x_51187 = _1;
    }

    /** emit.e:135		cgi += 1*/
    _47cgi_50948 = _47cgi_50948 + 1;

    /** emit.e:136		if cgi > length(cg_stack) then*/
    if (IS_SEQUENCE(_47cg_stack_50947)){
            _26291 = SEQ_PTR(_47cg_stack_50947)->length;
    }
    else {
        _26291 = 1;
    }
    if (_47cgi_50948 <= _26291)
    goto L1; // [20] 37

    /** emit.e:137			cg_stack &= repeat(0, 400)*/
    _26293 = Repeat(0LL, 400LL);
    Concat((object_ptr)&_47cg_stack_50947, _47cg_stack_50947, _26293);
    DeRefDS(_26293);
    _26293 = NOVALUE;
L1: 

    /** emit.e:139		cg_stack[cgi] = x*/
    _2 = (object)SEQ_PTR(_47cg_stack_50947);
    _2 = (object)(((s1_ptr)_2)->base + _47cgi_50948);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _x_51187;
    DeRef(_1);

    /** emit.e:141	end procedure*/
    return;
    ;
}


object _47Top()
{
    object _26295 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:145		return cg_stack[cgi]*/
    _2 = (object)SEQ_PTR(_47cg_stack_50947);
    _26295 = (object)*(((s1_ptr)_2)->base + _47cgi_50948);
    Ref(_26295);
    return _26295;
    ;
}


object _47Pop()
{
    object _t_51200 = NOVALUE;
    object _s_51206 = NOVALUE;
    object _26307 = NOVALUE;
    object _26305 = NOVALUE;
    object _26303 = NOVALUE;
    object _26300 = NOVALUE;
    object _26299 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** emit.e:153		t = cg_stack[cgi]*/
    _2 = (object)SEQ_PTR(_47cg_stack_50947);
    _t_51200 = (object)*(((s1_ptr)_2)->base + _47cgi_50948);
    if (!IS_ATOM_INT(_t_51200)){
        _t_51200 = (object)DBL_PTR(_t_51200)->dbl;
    }

    /** emit.e:154		cgi -= 1*/
    _47cgi_50948 = _47cgi_50948 - 1LL;

    /** emit.e:155		if t > 0 then*/
    if (_t_51200 <= 0LL)
    goto L1; // [23] 116

    /** emit.e:156			symtab_index s = t -- for type checking*/
    _s_51206 = _t_51200;

    /** emit.e:157			if SymTab[t][S_MODE] = M_TEMP then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _26299 = (object)*(((s1_ptr)_2)->base + _t_51200);
    _2 = (object)SEQ_PTR(_26299);
    _26300 = (object)*(((s1_ptr)_2)->base + 3LL);
    _26299 = NOVALUE;
    if (binary_op_a(NOTEQ, _26300, 3LL)){
        _26300 = NOVALUE;
        goto L2; // [50] 115
    }
    _26300 = NOVALUE;

    /** emit.e:158				if use_private_list = 0 then  -- no problem with reusing the temp*/
    if (_36use_private_list_21556 != 0LL)
    goto L3; // [58] 82

    /** emit.e:159					SymTab[t][S_SCOPE] = FREE -- mark it as being free*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_t_51200 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _26303 = NOVALUE;
    goto L4; // [79] 114
L3: 

    /** emit.e:163				elsif find(t, private_sym) = 0 then*/
    _26305 = find_from(_t_51200, _36private_sym_21555, 1LL);
    if (_26305 != 0LL)
    goto L5; // [91] 113

    /** emit.e:165					SymTab[t][S_SCOPE] = FREE -- mark it as being free*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_t_51200 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _26307 = NOVALUE;
L5: 
L4: 
L2: 
L1: 

    /** emit.e:169		return t*/
    return _t_51200;
    ;
}


void _47TempKeep(object _x_51234)
{
    object _26314 = NOVALUE;
    object _26313 = NOVALUE;
    object _26312 = NOVALUE;
    object _26311 = NOVALUE;
    object _26310 = NOVALUE;
    object _26309 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** emit.e:173		if x > 0 and SymTab[x][S_MODE] = M_TEMP then*/
    _26309 = (_x_51234 > 0LL);
    if (_26309 == 0) {
        goto L1; // [9] 53
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _26311 = (object)*(((s1_ptr)_2)->base + _x_51234);
    _2 = (object)SEQ_PTR(_26311);
    _26312 = (object)*(((s1_ptr)_2)->base + 3LL);
    _26311 = NOVALUE;
    if (IS_ATOM_INT(_26312)) {
        _26313 = (_26312 == 3LL);
    }
    else {
        _26313 = binary_op(EQUALS, _26312, 3LL);
    }
    _26312 = NOVALUE;
    if (_26313 == 0) {
        DeRef(_26313);
        _26313 = NOVALUE;
        goto L1; // [32] 53
    }
    else {
        if (!IS_ATOM_INT(_26313) && DBL_PTR(_26313)->dbl == 0.0){
            DeRef(_26313);
            _26313 = NOVALUE;
            goto L1; // [32] 53
        }
        DeRef(_26313);
        _26313 = NOVALUE;
    }
    DeRef(_26313);
    _26313 = NOVALUE;

    /** emit.e:174			SymTab[x][S_SCOPE] = IN_USE*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_x_51234 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _26314 = NOVALUE;
L1: 

    /** emit.e:176	end procedure*/
    DeRef(_26309);
    _26309 = NOVALUE;
    return;
    ;
}


void _47TempFree(object _x_51252)
{
    object _26320 = NOVALUE;
    object _26318 = NOVALUE;
    object _26317 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** emit.e:179		if x > 0 then*/
    if (_x_51252 <= 0LL)
    goto L1; // [5] 53

    /** emit.e:180			if SymTab[x][S_MODE] = M_TEMP then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _26317 = (object)*(((s1_ptr)_2)->base + _x_51252);
    _2 = (object)SEQ_PTR(_26317);
    _26318 = (object)*(((s1_ptr)_2)->base + 3LL);
    _26317 = NOVALUE;
    if (binary_op_a(NOTEQ, _26318, 3LL)){
        _26318 = NOVALUE;
        goto L2; // [25] 52
    }
    _26318 = NOVALUE;

    /** emit.e:181				SymTab[x][S_SCOPE] = FREE*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_x_51252 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _26320 = NOVALUE;

    /** emit.e:182				clear_temp( x )*/
    _47clear_temp(_x_51252);
L2: 
L1: 

    /** emit.e:185	end procedure*/
    return;
    ;
}


void _47TempInteger(object _x_51271)
{
    object _26327 = NOVALUE;
    object _26326 = NOVALUE;
    object _26325 = NOVALUE;
    object _26324 = NOVALUE;
    object _26323 = NOVALUE;
    object _26322 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_x_51271)) {
        _1 = (object)(DBL_PTR(_x_51271)->dbl);
        DeRefDS(_x_51271);
        _x_51271 = _1;
    }

    /** emit.e:188		if x > 0 and SymTab[x][S_MODE] = M_TEMP then*/
    _26322 = (_x_51271 > 0LL);
    if (_26322 == 0) {
        goto L1; // [9] 53
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _26324 = (object)*(((s1_ptr)_2)->base + _x_51271);
    _2 = (object)SEQ_PTR(_26324);
    _26325 = (object)*(((s1_ptr)_2)->base + 3LL);
    _26324 = NOVALUE;
    if (IS_ATOM_INT(_26325)) {
        _26326 = (_26325 == 3LL);
    }
    else {
        _26326 = binary_op(EQUALS, _26325, 3LL);
    }
    _26325 = NOVALUE;
    if (_26326 == 0) {
        DeRef(_26326);
        _26326 = NOVALUE;
        goto L1; // [32] 53
    }
    else {
        if (!IS_ATOM_INT(_26326) && DBL_PTR(_26326)->dbl == 0.0){
            DeRef(_26326);
            _26326 = NOVALUE;
            goto L1; // [32] 53
        }
        DeRef(_26326);
        _26326 = NOVALUE;
    }
    DeRef(_26326);
    _26326 = NOVALUE;

    /** emit.e:189			SymTab[x][S_USAGE] = T_INTEGER*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_x_51271 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _26327 = NOVALUE;
L1: 

    /** emit.e:191	end procedure*/
    DeRef(_26322);
    _26322 = NOVALUE;
    return;
    ;
}


object _47LexName(object _t_51288, object _defname_51289)
{
    object _name_51291 = NOVALUE;
    object _26336 = NOVALUE;
    object _26334 = NOVALUE;
    object _26332 = NOVALUE;
    object _26331 = NOVALUE;
    object _26330 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_t_51288)) {
        _1 = (object)(DBL_PTR(_t_51288)->dbl);
        DeRefDS(_t_51288);
        _t_51288 = _1;
    }

    /** emit.e:197		for i = 1 to length(token_name) do*/
    _26330 = 80;
    {
        object _i_51293;
        _i_51293 = 1LL;
L1: 
        if (_i_51293 > 80LL){
            goto L2; // [12] 82
        }

        /** emit.e:198			if t = token_name[i][LEX_NUMBER] then*/
        _2 = (object)SEQ_PTR(_47token_name_50955);
        _26331 = (object)*(((s1_ptr)_2)->base + _i_51293);
        _2 = (object)SEQ_PTR(_26331);
        _26332 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26331 = NOVALUE;
        if (binary_op_a(NOTEQ, _t_51288, _26332)){
            _26332 = NOVALUE;
            goto L3; // [31] 75
        }
        _26332 = NOVALUE;

        /** emit.e:199				name = token_name[i][LEX_NAME]*/
        _2 = (object)SEQ_PTR(_47token_name_50955);
        _26334 = (object)*(((s1_ptr)_2)->base + _i_51293);
        DeRef(_name_51291);
        _2 = (object)SEQ_PTR(_26334);
        _name_51291 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_name_51291);
        _26334 = NOVALUE;

        /** emit.e:200				if not find(' ', name) then*/
        _26336 = find_from(32LL, _name_51291, 1LL);
        if (_26336 != 0)
        goto L4; // [56] 68
        _26336 = NOVALUE;

        /** emit.e:201					name = "'" & name & "'"*/
        {
            object concat_list[3];

            concat_list[0] = _26338;
            concat_list[1] = _name_51291;
            concat_list[2] = _26338;
            Concat_N((object_ptr)&_name_51291, concat_list, 3);
        }
L4: 

        /** emit.e:203				return name*/
        DeRefDSi(_defname_51289);
        return _name_51291;
L3: 

        /** emit.e:205		end for*/
        _i_51293 = _i_51293 + 1LL;
        goto L1; // [77] 19
L2: 
        ;
    }

    /** emit.e:206		return defname -- try to avoid this case*/
    DeRef(_name_51291);
    return _defname_51289;
    ;
}


void _47InitEmit()
{
    object _0, _1, _2;
    

    /** emit.e:212		cg_stack = repeat(0, 400)*/
    DeRef(_47cg_stack_50947);
    _47cg_stack_50947 = Repeat(0LL, 400LL);

    /** emit.e:213		cgi = 0*/
    _47cgi_50948 = 0LL;

    /** emit.e:214	end procedure*/
    return;
    ;
}


object _47IsInteger(object _sym_51312)
{
    object _mode_51313 = NOVALUE;
    object _t_51315 = NOVALUE;
    object _pt_51316 = NOVALUE;
    object _26361 = NOVALUE;
    object _26360 = NOVALUE;
    object _26358 = NOVALUE;
    object _26357 = NOVALUE;
    object _26356 = NOVALUE;
    object _26354 = NOVALUE;
    object _26353 = NOVALUE;
    object _26352 = NOVALUE;
    object _26351 = NOVALUE;
    object _26349 = NOVALUE;
    object _26345 = NOVALUE;
    object _26342 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_51312)) {
        _1 = (object)(DBL_PTR(_sym_51312)->dbl);
        DeRefDS(_sym_51312);
        _sym_51312 = _1;
    }

    /** emit.e:221		if sym < 1 then*/
    if (_sym_51312 >= 1LL)
    goto L1; // [5] 16

    /** emit.e:223			return 0*/
    return 0LL;
L1: 

    /** emit.e:226		mode = SymTab[sym][S_MODE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _26342 = (object)*(((s1_ptr)_2)->base + _sym_51312);
    _2 = (object)SEQ_PTR(_26342);
    _mode_51313 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_mode_51313)){
        _mode_51313 = (object)DBL_PTR(_mode_51313)->dbl;
    }
    _26342 = NOVALUE;

    /** emit.e:227		if mode = M_NORMAL then*/
    if (_mode_51313 != 1LL)
    goto L2; // [36] 136

    /** emit.e:228			t = SymTab[sym][S_VTYPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _26345 = (object)*(((s1_ptr)_2)->base + _sym_51312);
    _2 = (object)SEQ_PTR(_26345);
    _t_51315 = (object)*(((s1_ptr)_2)->base + 15LL);
    if (!IS_ATOM_INT(_t_51315)){
        _t_51315 = (object)DBL_PTR(_t_51315)->dbl;
    }
    _26345 = NOVALUE;

    /** emit.e:229			if t = integer_type then*/
    if (_t_51315 != _54integer_type_46782)
    goto L3; // [60] 73

    /** emit.e:230				return TRUE*/
    return _13TRUE_452;
L3: 

    /** emit.e:232			if t > 0 then*/
    if (_t_51315 <= 0LL)
    goto L4; // [75] 215

    /** emit.e:233				pt = SymTab[t][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _26349 = (object)*(((s1_ptr)_2)->base + _t_51315);
    _2 = (object)SEQ_PTR(_26349);
    _pt_51316 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_pt_51316)){
        _pt_51316 = (object)DBL_PTR(_pt_51316)->dbl;
    }
    _26349 = NOVALUE;

    /** emit.e:234				if pt and SymTab[pt][S_VTYPE] = integer_type then*/
    if (_pt_51316 == 0) {
        goto L4; // [97] 215
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _26352 = (object)*(((s1_ptr)_2)->base + _pt_51316);
    _2 = (object)SEQ_PTR(_26352);
    _26353 = (object)*(((s1_ptr)_2)->base + 15LL);
    _26352 = NOVALUE;
    if (IS_ATOM_INT(_26353)) {
        _26354 = (_26353 == _54integer_type_46782);
    }
    else {
        _26354 = binary_op(EQUALS, _26353, _54integer_type_46782);
    }
    _26353 = NOVALUE;
    if (_26354 == 0) {
        DeRef(_26354);
        _26354 = NOVALUE;
        goto L4; // [120] 215
    }
    else {
        if (!IS_ATOM_INT(_26354) && DBL_PTR(_26354)->dbl == 0.0){
            DeRef(_26354);
            _26354 = NOVALUE;
            goto L4; // [120] 215
        }
        DeRef(_26354);
        _26354 = NOVALUE;
    }
    DeRef(_26354);
    _26354 = NOVALUE;

    /** emit.e:235					return TRUE   -- usertype(integer x)*/
    return _13TRUE_452;
    goto L4; // [133] 215
L2: 

    /** emit.e:239		elsif mode = M_CONSTANT then*/
    if (_mode_51313 != 2LL)
    goto L5; // [140] 176

    /** emit.e:240			if integer(SymTab[sym][S_OBJ]) then  -- bug fixed: can't allow PLUS1_I op*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _26356 = (object)*(((s1_ptr)_2)->base + _sym_51312);
    _2 = (object)SEQ_PTR(_26356);
    _26357 = (object)*(((s1_ptr)_2)->base + 1LL);
    _26356 = NOVALUE;
    if (IS_ATOM_INT(_26357))
    _26358 = 1;
    else if (IS_ATOM_DBL(_26357))
    _26358 = IS_ATOM_INT(DoubleToInt(_26357));
    else
    _26358 = 0;
    _26357 = NOVALUE;
    if (_26358 == 0)
    {
        _26358 = NOVALUE;
        goto L4; // [161] 215
    }
    else{
        _26358 = NOVALUE;
    }

    /** emit.e:241				return TRUE*/
    return _13TRUE_452;
    goto L4; // [173] 215
L5: 

    /** emit.e:244		elsif mode = M_TEMP then*/
    if (_mode_51313 != 3LL)
    goto L6; // [180] 214

    /** emit.e:245			if SymTab[sym][S_USAGE] = T_INTEGER then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _26360 = (object)*(((s1_ptr)_2)->base + _sym_51312);
    _2 = (object)SEQ_PTR(_26360);
    _26361 = (object)*(((s1_ptr)_2)->base + 5LL);
    _26360 = NOVALUE;
    if (binary_op_a(NOTEQ, _26361, 1LL)){
        _26361 = NOVALUE;
        goto L7; // [200] 213
    }
    _26361 = NOVALUE;

    /** emit.e:246				return TRUE*/
    return _13TRUE_452;
L7: 
L6: 
L4: 

    /** emit.e:250		return FALSE*/
    return _13FALSE_450;
    ;
}


void _47emit(object _val_51373)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_val_51373)) {
        _1 = (object)(DBL_PTR(_val_51373)->dbl);
        DeRefDS(_val_51373);
        _val_51373 = _1;
    }

    /** emit.e:260		Code = append(Code, val)*/
    Append(&_36Code_21531, _36Code_21531, _val_51373);

    /** emit.e:261	end procedure*/
    return;
    ;
}


void _47emit_opnd(object _opnd_51380)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_opnd_51380)) {
        _1 = (object)(DBL_PTR(_opnd_51380)->dbl);
        DeRefDS(_opnd_51380);
        _opnd_51380 = _1;
    }

    /** emit.e:271			Push(opnd)*/
    _47Push(_opnd_51380);

    /** emit.e:272			previous_op = -1  -- N.B.*/
    _36previous_op_21541 = -1LL;

    /** emit.e:273	end procedure*/
    return;
    ;
}


void _47emit_addr(object _x_51384)
{
    object _0, _1, _2;
    

    /** emit.e:277			Code = append(Code, x)*/
    Ref(_x_51384);
    Append(&_36Code_21531, _36Code_21531, _x_51384);

    /** emit.e:278	end procedure*/
    DeRef(_x_51384);
    return;
    ;
}


void _47emit_opcode(object _op_51390)
{
    object _0, _1, _2;
    

    /** emit.e:282		Code = append(Code, op)*/
    Append(&_36Code_21531, _36Code_21531, _op_51390);

    /** emit.e:283	end procedure*/
    return;
    ;
}


void _47emit_temp(object _tempsym_51424, object _referenced_51425)
{
    object _26392 = NOVALUE;
    object _26391 = NOVALUE;
    object _26390 = NOVALUE;
    object _26389 = NOVALUE;
    object _26388 = NOVALUE;
    object _26387 = NOVALUE;
    object _26386 = NOVALUE;
    object _26385 = NOVALUE;
    object _26384 = NOVALUE;
    object _26383 = NOVALUE;
    object _26382 = NOVALUE;
    object _26381 = NOVALUE;
    object _26380 = NOVALUE;
    object _26379 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:307		if not TRANSLATE  then -- translator has its own way of handling temps*/
    if (_36TRANSLATE_21041 != 0)
    goto L1; // [7] 129

    /** emit.e:308			if sequence(tempsym) then*/
    _26379 = IS_SEQUENCE(_tempsym_51424);
    if (_26379 == 0)
    {
        _26379 = NOVALUE;
        goto L2; // [15] 53
    }
    else{
        _26379 = NOVALUE;
    }

    /** emit.e:309				for i = 1 to length(tempsym) do*/
    if (IS_SEQUENCE(_tempsym_51424)){
            _26380 = SEQ_PTR(_tempsym_51424)->length;
    }
    else {
        _26380 = 1;
    }
    {
        object _i_51432;
        _i_51432 = 1LL;
L3: 
        if (_i_51432 > _26380){
            goto L4; // [23] 50
        }

        /** emit.e:310					emit_temp( tempsym[i], referenced )*/
        _2 = (object)SEQ_PTR(_tempsym_51424);
        _26381 = (object)*(((s1_ptr)_2)->base + _i_51432);
        DeRef(_26382);
        _26382 = _referenced_51425;
        Ref(_26381);
        _47emit_temp(_26381, _26382);
        _26381 = NOVALUE;
        _26382 = NOVALUE;

        /** emit.e:311				end for*/
        _i_51432 = _i_51432 + 1LL;
        goto L3; // [45] 30
L4: 
        ;
    }
    goto L5; // [50] 128
L2: 

    /** emit.e:313			elsif tempsym > 0*/
    if (IS_ATOM_INT(_tempsym_51424)) {
        _26383 = (_tempsym_51424 > 0LL);
    }
    else {
        _26383 = binary_op(GREATER, _tempsym_51424, 0LL);
    }
    if (IS_ATOM_INT(_26383)) {
        if (_26383 == 0) {
            DeRef(_26384);
            _26384 = 0;
            goto L6; // [59] 77
        }
    }
    else {
        if (DBL_PTR(_26383)->dbl == 0.0) {
            DeRef(_26384);
            _26384 = 0;
            goto L6; // [59] 77
        }
    }
    Ref(_tempsym_51424);
    _26385 = _54sym_mode(_tempsym_51424);
    if (IS_ATOM_INT(_26385)) {
        _26386 = (_26385 == 3LL);
    }
    else {
        _26386 = binary_op(EQUALS, _26385, 3LL);
    }
    DeRef(_26385);
    _26385 = NOVALUE;
    DeRef(_26384);
    if (IS_ATOM_INT(_26386))
    _26384 = (_26386 != 0);
    else
    _26384 = DBL_PTR(_26386)->dbl != 0.0;
L6: 
    if (_26384 == 0) {
        _26387 = 0;
        goto L7; // [77] 92
    }
    Ref(_tempsym_51424);
    _26388 = _47IsInteger(_tempsym_51424);
    if (IS_ATOM_INT(_26388)) {
        _26389 = (_26388 == 0);
    }
    else {
        _26389 = unary_op(NOT, _26388);
    }
    DeRef(_26388);
    _26388 = NOVALUE;
    if (IS_ATOM_INT(_26389))
    _26387 = (_26389 != 0);
    else
    _26387 = DBL_PTR(_26389)->dbl != 0.0;
L7: 
    if (_26387 == 0) {
        goto L8; // [92] 127
    }
    _26391 = find_from(_tempsym_51424, _47emitted_temps_51420, 1LL);
    _26392 = (_26391 == 0);
    _26391 = NOVALUE;
    if (_26392 == 0)
    {
        DeRef(_26392);
        _26392 = NOVALUE;
        goto L8; // [107] 127
    }
    else{
        DeRef(_26392);
        _26392 = NOVALUE;
    }

    /** emit.e:319				emitted_temps &= tempsym*/
    if (IS_SEQUENCE(_47emitted_temps_51420) && IS_ATOM(_tempsym_51424)) {
        Ref(_tempsym_51424);
        Append(&_47emitted_temps_51420, _47emitted_temps_51420, _tempsym_51424);
    }
    else if (IS_ATOM(_47emitted_temps_51420) && IS_SEQUENCE(_tempsym_51424)) {
    }
    else {
        Concat((object_ptr)&_47emitted_temps_51420, _47emitted_temps_51420, _tempsym_51424);
    }

    /** emit.e:320				emitted_temp_referenced &= referenced*/
    Append(&_47emitted_temp_referenced_51421, _47emitted_temp_referenced_51421, _referenced_51425);
L8: 
L5: 
L1: 

    /** emit.e:323	end procedure*/
    DeRef(_tempsym_51424);
    DeRef(_26389);
    _26389 = NOVALUE;
    DeRef(_26383);
    _26383 = NOVALUE;
    DeRef(_26386);
    _26386 = NOVALUE;
    return;
    ;
}


void _47flush_temps(object _except_for_51454)
{
    object _refs_51457 = NOVALUE;
    object _novalues_51458 = NOVALUE;
    object _sym_51463 = NOVALUE;
    object _26407 = NOVALUE;
    object _26406 = NOVALUE;
    object _26405 = NOVALUE;
    object _26404 = NOVALUE;
    object _26402 = NOVALUE;
    object _26398 = NOVALUE;
    object _26397 = NOVALUE;
    object _26395 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:332		if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L1; // [7] 16
    }
    else{
    }

    /** emit.e:333			return*/
    DeRefDS(_except_for_51454);
    DeRef(_refs_51457);
    DeRefi(_novalues_51458);
    return;
L1: 

    /** emit.e:336		sequence*/

    /** emit.e:337			refs = {},*/
    RefDS(_21993);
    DeRef(_refs_51457);
    _refs_51457 = _21993;

    /** emit.e:338			novalues = {}*/
    RefDS(_21993);
    DeRefi(_novalues_51458);
    _novalues_51458 = _21993;

    /** emit.e:340		derefs = {}*/
    RefDS(_21993);
    DeRefi(_47derefs_51451);
    _47derefs_51451 = _21993;

    /** emit.e:341		for i = 1 to length( emitted_temps ) do*/
    if (IS_SEQUENCE(_47emitted_temps_51420)){
            _26395 = SEQ_PTR(_47emitted_temps_51420)->length;
    }
    else {
        _26395 = 1;
    }
    {
        object _i_51460;
        _i_51460 = 1LL;
L2: 
        if (_i_51460 > _26395){
            goto L3; // [46] 119
        }

        /** emit.e:342			symtab_index sym = emitted_temps[i]*/
        _2 = (object)SEQ_PTR(_47emitted_temps_51420);
        _sym_51463 = (object)*(((s1_ptr)_2)->base + _i_51460);
        if (!IS_ATOM_INT(_sym_51463)){
            _sym_51463 = (object)DBL_PTR(_sym_51463)->dbl;
        }

        /** emit.e:344			if find( sym, except_for ) then*/
        _26397 = find_from(_sym_51463, _except_for_51454, 1LL);
        if (_26397 == 0)
        {
            _26397 = NOVALUE;
            goto L4; // [70] 80
        }
        else{
            _26397 = NOVALUE;
        }

        /** emit.e:345				continue*/
        goto L5; // [77] 114
L4: 

        /** emit.e:348			if emitted_temp_referenced[i] = NEW_REFERENCE then*/
        _2 = (object)SEQ_PTR(_47emitted_temp_referenced_51421);
        _26398 = (object)*(((s1_ptr)_2)->base + _i_51460);
        if (binary_op_a(NOTEQ, _26398, 1LL)){
            _26398 = NOVALUE;
            goto L6; // [88] 103
        }
        _26398 = NOVALUE;

        /** emit.e:349				derefs &= sym*/
        Append(&_47derefs_51451, _47derefs_51451, _sym_51463);
        goto L7; // [100] 110
L6: 

        /** emit.e:351				novalues &= sym*/
        Append(&_novalues_51458, _novalues_51458, _sym_51463);
L7: 

        /** emit.e:353		end for*/
L5: 
        _i_51460 = _i_51460 + 1LL;
        goto L2; // [114] 53
L3: 
        ;
    }

    /** emit.e:355		if not length( except_for ) then*/
    if (IS_SEQUENCE(_except_for_51454)){
            _26402 = SEQ_PTR(_except_for_51454)->length;
    }
    else {
        _26402 = 1;
    }
    if (_26402 != 0)
    goto L8; // [124] 132
    _26402 = NOVALUE;

    /** emit.e:356			clear_last()*/
    _47clear_last();
L8: 

    /** emit.e:359		for i = 1 to length( derefs ) do*/
    if (IS_SEQUENCE(_47derefs_51451)){
            _26404 = SEQ_PTR(_47derefs_51451)->length;
    }
    else {
        _26404 = 1;
    }
    {
        object _i_51478;
        _i_51478 = 1LL;
L9: 
        if (_i_51478 > _26404){
            goto LA; // [139] 171
        }

        /** emit.e:360			emit( DEREF_TEMP )*/
        _47emit(208LL);

        /** emit.e:361			emit( derefs[i] )*/
        _2 = (object)SEQ_PTR(_47derefs_51451);
        _26405 = (object)*(((s1_ptr)_2)->base + _i_51478);
        _47emit(_26405);
        _26405 = NOVALUE;

        /** emit.e:362		end for*/
        _i_51478 = _i_51478 + 1LL;
        goto L9; // [166] 146
LA: 
        ;
    }

    /** emit.e:364		for i = 1 to length( novalues ) do*/
    if (IS_SEQUENCE(_novalues_51458)){
            _26406 = SEQ_PTR(_novalues_51458)->length;
    }
    else {
        _26406 = 1;
    }
    {
        object _i_51483;
        _i_51483 = 1LL;
LB: 
        if (_i_51483 > _26406){
            goto LC; // [176] 206
        }

        /** emit.e:365			emit( NOVALUE_TEMP )*/
        _47emit(209LL);

        /** emit.e:366			emit( novalues[i] )*/
        _2 = (object)SEQ_PTR(_novalues_51458);
        _26407 = (object)*(((s1_ptr)_2)->base + _i_51483);
        _47emit(_26407);
        _26407 = NOVALUE;

        /** emit.e:367		end for*/
        _i_51483 = _i_51483 + 1LL;
        goto LB; // [201] 183
LC: 
        ;
    }

    /** emit.e:369		emitted_temps = {}*/
    RefDS(_21993);
    DeRef(_47emitted_temps_51420);
    _47emitted_temps_51420 = _21993;

    /** emit.e:370		emitted_temp_referenced = {}*/
    RefDS(_21993);
    DeRef(_47emitted_temp_referenced_51421);
    _47emitted_temp_referenced_51421 = _21993;

    /** emit.e:371	end procedure*/
    DeRefDS(_except_for_51454);
    DeRef(_refs_51457);
    DeRefi(_novalues_51458);
    return;
    ;
}


void _47flush_temp(object _temp_51490)
{
    object _except_for_51491 = NOVALUE;
    object _ix_51492 = NOVALUE;
    object _26409 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_temp_51490)) {
        _1 = (object)(DBL_PTR(_temp_51490)->dbl);
        DeRefDS(_temp_51490);
        _temp_51490 = _1;
    }

    /** emit.e:374		sequence except_for = emitted_temps*/
    RefDS(_47emitted_temps_51420);
    DeRef(_except_for_51491);
    _except_for_51491 = _47emitted_temps_51420;

    /** emit.e:375		integer ix = find( temp, emitted_temps )*/
    _ix_51492 = find_from(_temp_51490, _47emitted_temps_51420, 1LL);

    /** emit.e:376		if ix then*/
    if (_ix_51492 == 0)
    {
        goto L1; // [23] 37
    }
    else{
    }

    /** emit.e:377			flush_temps( remove( except_for, ix ) )*/
    {
        s1_ptr assign_space = SEQ_PTR(_except_for_51491);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_51492)) ? _ix_51492 : (object)(DBL_PTR(_ix_51492)->dbl);
        int stop = (IS_ATOM_INT(_ix_51492)) ? _ix_51492 : (object)(DBL_PTR(_ix_51492)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
            RefDS(_except_for_51491);
            DeRef(_26409);
            _26409 = _except_for_51491;
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_except_for_51491), start, &_26409 );
            }
            else Tail(SEQ_PTR(_except_for_51491), stop+1, &_26409);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_except_for_51491), start, &_26409);
        }
        else {
            assign_slice_seq = &assign_space;
            _1 = Remove_elements(start, stop, 0);
            DeRef(_26409);
            _26409 = _1;
        }
    }
    _47flush_temps(_26409);
    _26409 = NOVALUE;
L1: 

    /** emit.e:379	end procedure*/
    DeRef(_except_for_51491);
    return;
    ;
}


void _47check_for_temps()
{
    object _26416 = NOVALUE;
    object _26415 = NOVALUE;
    object _26414 = NOVALUE;
    object _26413 = NOVALUE;
    object _26411 = NOVALUE;
    object _26410 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:382		if TRANSLATE or last_op < 1 or last_pc < 1 then*/
    if (_36TRANSLATE_21041 != 0) {
        _26410 = 1;
        goto L1; // [5] 19
    }
    _26411 = (_47last_op_51829 < 1LL);
    _26410 = (_26411 != 0);
L1: 
    if (_26410 != 0) {
        goto L2; // [19] 34
    }
    _26413 = (_47last_pc_51830 < 1LL);
    if (_26413 == 0)
    {
        DeRef(_26413);
        _26413 = NOVALUE;
        goto L3; // [30] 40
    }
    else{
        DeRef(_26413);
        _26413 = NOVALUE;
    }
L2: 

    /** emit.e:383			return*/
    DeRef(_26411);
    _26411 = NOVALUE;
    return;
L3: 

    /** emit.e:386		emit_temp( get_target_sym( current_op( last_pc ) ), op_temp_ref[last_op] )*/
    RefDS(_36Code_21531);
    _26414 = _66current_op(_47last_pc_51830, _36Code_21531);
    _26415 = _66get_target_sym(_26414);
    _26414 = NOVALUE;
    _2 = (object)SEQ_PTR(_47op_temp_ref_51642);
    _26416 = (object)*(((s1_ptr)_2)->base + _47last_op_51829);
    _47emit_temp(_26415, _26416);
    _26415 = NOVALUE;
    _26416 = NOVALUE;

    /** emit.e:388	end procedure*/
    DeRef(_26411);
    _26411 = NOVALUE;
    return;
    ;
}


void _47clear_temp(object _tempsym_51517)
{
    object _ix_51518 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_tempsym_51517)) {
        _1 = (object)(DBL_PTR(_tempsym_51517)->dbl);
        DeRefDS(_tempsym_51517);
        _tempsym_51517 = _1;
    }

    /** emit.e:391		integer ix = find( tempsym, emitted_temps )*/
    _ix_51518 = find_from(_tempsym_51517, _47emitted_temps_51420, 1LL);

    /** emit.e:392		if ix then*/
    if (_ix_51518 == 0)
    {
        goto L1; // [14] 36
    }
    else{
    }

    /** emit.e:393			emitted_temps = remove( emitted_temps, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_47emitted_temps_51420);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_51518)) ? _ix_51518 : (object)(DBL_PTR(_ix_51518)->dbl);
        int stop = (IS_ATOM_INT(_ix_51518)) ? _ix_51518 : (object)(DBL_PTR(_ix_51518)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_47emitted_temps_51420), start, &_47emitted_temps_51420 );
            }
            else Tail(SEQ_PTR(_47emitted_temps_51420), stop+1, &_47emitted_temps_51420);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_47emitted_temps_51420), start, &_47emitted_temps_51420);
        }
        else {
            assign_slice_seq = &assign_space;
            _47emitted_temps_51420 = Remove_elements(start, stop, (SEQ_PTR(_47emitted_temps_51420)->ref == 1));
        }
    }

    /** emit.e:394			emitted_temp_referenced = remove( emitted_temp_referenced, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_47emitted_temp_referenced_51421);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_51518)) ? _ix_51518 : (object)(DBL_PTR(_ix_51518)->dbl);
        int stop = (IS_ATOM_INT(_ix_51518)) ? _ix_51518 : (object)(DBL_PTR(_ix_51518)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_47emitted_temp_referenced_51421), start, &_47emitted_temp_referenced_51421 );
            }
            else Tail(SEQ_PTR(_47emitted_temp_referenced_51421), stop+1, &_47emitted_temp_referenced_51421);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_47emitted_temp_referenced_51421), start, &_47emitted_temp_referenced_51421);
        }
        else {
            assign_slice_seq = &assign_space;
            _47emitted_temp_referenced_51421 = Remove_elements(start, stop, (SEQ_PTR(_47emitted_temp_referenced_51421)->ref == 1));
        }
    }
L1: 

    /** emit.e:396	end procedure*/
    return;
    ;
}


object _47pop_temps()
{
    object _new_emitted_51525 = NOVALUE;
    object _new_referenced_51526 = NOVALUE;
    object _26420 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:402		sequence new_emitted  = emitted_temps*/
    RefDS(_47emitted_temps_51420);
    DeRef(_new_emitted_51525);
    _new_emitted_51525 = _47emitted_temps_51420;

    /** emit.e:403		sequence new_referenced = emitted_temp_referenced*/
    RefDS(_47emitted_temp_referenced_51421);
    DeRef(_new_referenced_51526);
    _new_referenced_51526 = _47emitted_temp_referenced_51421;

    /** emit.e:405		emitted_temps  = {}*/
    RefDS(_21993);
    DeRefDS(_47emitted_temps_51420);
    _47emitted_temps_51420 = _21993;

    /** emit.e:406		emitted_temp_referenced = {}*/
    RefDS(_21993);
    DeRefDS(_47emitted_temp_referenced_51421);
    _47emitted_temp_referenced_51421 = _21993;

    /** emit.e:407		return { new_emitted, new_referenced }*/
    RefDS(_new_referenced_51526);
    RefDS(_new_emitted_51525);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _new_emitted_51525;
    ((intptr_t *)_2)[2] = _new_referenced_51526;
    _26420 = MAKE_SEQ(_1);
    DeRefDS(_new_emitted_51525);
    DeRefDS(_new_referenced_51526);
    return _26420;
    ;
}


object _47get_temps(object _add_to_51530)
{
    object _26425 = NOVALUE;
    object _26424 = NOVALUE;
    object _26423 = NOVALUE;
    object _26422 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:416		add_to[1] &= emitted_temps*/
    _2 = (object)SEQ_PTR(_add_to_51530);
    _26422 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_26422) && IS_ATOM(_47emitted_temps_51420)) {
    }
    else if (IS_ATOM(_26422) && IS_SEQUENCE(_47emitted_temps_51420)) {
        Ref(_26422);
        Prepend(&_26423, _47emitted_temps_51420, _26422);
    }
    else {
        Concat((object_ptr)&_26423, _26422, _47emitted_temps_51420);
        _26422 = NOVALUE;
    }
    _26422 = NOVALUE;
    _2 = (object)SEQ_PTR(_add_to_51530);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _add_to_51530 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _26423;
    if( _1 != _26423 ){
        DeRef(_1);
    }
    _26423 = NOVALUE;

    /** emit.e:417		add_to[2] &= emitted_temp_referenced*/
    _2 = (object)SEQ_PTR(_add_to_51530);
    _26424 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_SEQUENCE(_26424) && IS_ATOM(_47emitted_temp_referenced_51421)) {
    }
    else if (IS_ATOM(_26424) && IS_SEQUENCE(_47emitted_temp_referenced_51421)) {
        Ref(_26424);
        Prepend(&_26425, _47emitted_temp_referenced_51421, _26424);
    }
    else {
        Concat((object_ptr)&_26425, _26424, _47emitted_temp_referenced_51421);
        _26424 = NOVALUE;
    }
    _26424 = NOVALUE;
    _2 = (object)SEQ_PTR(_add_to_51530);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _add_to_51530 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _26425;
    if( _1 != _26425 ){
        DeRef(_1);
    }
    _26425 = NOVALUE;

    /** emit.e:418		return add_to*/
    return _add_to_51530;
    ;
}


void _47push_temps(object _temps_51538)
{
    object _26428 = NOVALUE;
    object _26426 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:426		emitted_temps &= temps[1]*/
    _2 = (object)SEQ_PTR(_temps_51538);
    _26426 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_47emitted_temps_51420) && IS_ATOM(_26426)) {
        Ref(_26426);
        Append(&_47emitted_temps_51420, _47emitted_temps_51420, _26426);
    }
    else if (IS_ATOM(_47emitted_temps_51420) && IS_SEQUENCE(_26426)) {
    }
    else {
        Concat((object_ptr)&_47emitted_temps_51420, _47emitted_temps_51420, _26426);
    }
    _26426 = NOVALUE;

    /** emit.e:427		emitted_temp_referenced &= temps[2]*/
    _2 = (object)SEQ_PTR(_temps_51538);
    _26428 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_SEQUENCE(_47emitted_temp_referenced_51421) && IS_ATOM(_26428)) {
        Ref(_26428);
        Append(&_47emitted_temp_referenced_51421, _47emitted_temp_referenced_51421, _26428);
    }
    else if (IS_ATOM(_47emitted_temp_referenced_51421) && IS_SEQUENCE(_26428)) {
    }
    else {
        Concat((object_ptr)&_47emitted_temp_referenced_51421, _47emitted_temp_referenced_51421, _26428);
    }
    _26428 = NOVALUE;

    /** emit.e:428		flush_temps()*/
    RefDS(_21993);
    _47flush_temps(_21993);

    /** emit.e:429	end procedure*/
    DeRefDS(_temps_51538);
    return;
    ;
}


void _47backpatch(object _index_51545, object _val_51546)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_index_51545)) {
        _1 = (object)(DBL_PTR(_index_51545)->dbl);
        DeRefDS(_index_51545);
        _index_51545 = _1;
    }
    if (!IS_ATOM_INT(_val_51546)) {
        _1 = (object)(DBL_PTR(_val_51546)->dbl);
        DeRefDS(_val_51546);
        _val_51546 = _1;
    }

    /** emit.e:433			Code[index] = val*/
    _2 = (object)SEQ_PTR(_36Code_21531);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21531 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _index_51545);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _val_51546;
    DeRef(_1);

    /** emit.e:434	end procedure*/
    return;
    ;
}


void _47cont11ii(object _op_51730, object _ii_51732)
{
    object _t_51733 = NOVALUE;
    object _source_51734 = NOVALUE;
    object _c_51735 = NOVALUE;
    object _26437 = NOVALUE;
    object _26436 = NOVALUE;
    object _26434 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:580		emit_opcode(op)*/
    _47emit_opcode(_op_51730);

    /** emit.e:581		source = Pop()*/
    _source_51734 = _47Pop();
    if (!IS_ATOM_INT(_source_51734)) {
        _1 = (object)(DBL_PTR(_source_51734)->dbl);
        DeRefDS(_source_51734);
        _source_51734 = _1;
    }

    /** emit.e:582		emit_addr(source)*/
    _47emit_addr(_source_51734);

    /** emit.e:583		assignable = TRUE*/
    _47assignable_50950 = _13TRUE_452;

    /** emit.e:584		t = op_result[op]*/
    _2 = (object)SEQ_PTR(_47op_result_51548);
    _t_51733 = (object)*(((s1_ptr)_2)->base + _op_51730);

    /** emit.e:587		if t = T_INTEGER or (ii and IsInteger(source)) then*/
    _26434 = (_t_51733 == 1LL);
    if (_26434 != 0) {
        goto L1; // [43] 64
    }
    if (_ii_51732 == 0) {
        _26436 = 0;
        goto L2; // [47] 59
    }
    _26437 = _47IsInteger(_source_51734);
    if (IS_ATOM_INT(_26437))
    _26436 = (_26437 != 0);
    else
    _26436 = DBL_PTR(_26437)->dbl != 0.0;
L2: 
    if (_26436 == 0)
    {
        _26436 = NOVALUE;
        goto L3; // [60] 80
    }
    else{
        _26436 = NOVALUE;
    }
L1: 

    /** emit.e:588			c = NewTempSym()*/
    _c_51735 = _54NewTempSym(0LL);
    if (!IS_ATOM_INT(_c_51735)) {
        _1 = (object)(DBL_PTR(_c_51735)->dbl);
        DeRefDS(_c_51735);
        _c_51735 = _1;
    }

    /** emit.e:589			TempInteger(c)*/
    _47TempInteger(_c_51735);
    goto L4; // [77] 95
L3: 

    /** emit.e:591			c = NewTempSym() -- allocate *after* checking opnd type*/
    _c_51735 = _54NewTempSym(0LL);
    if (!IS_ATOM_INT(_c_51735)) {
        _1 = (object)(DBL_PTR(_c_51735)->dbl);
        DeRefDS(_c_51735);
        _c_51735 = _1;
    }

    /** emit.e:592			emit_temp( c, NEW_REFERENCE )*/
    _47emit_temp(_c_51735, 1LL);
L4: 

    /** emit.e:595		Push(c)*/
    _47Push(_c_51735);

    /** emit.e:596		emit_addr(c)*/
    _47emit_addr(_c_51735);

    /** emit.e:597	end procedure*/
    DeRef(_26434);
    _26434 = NOVALUE;
    DeRef(_26437);
    _26437 = NOVALUE;
    return;
    ;
}


void _47cont21d(object _op_51752, object _a_51753, object _b_51754, object _ii_51756)
{
    object _c_51757 = NOVALUE;
    object _t_51758 = NOVALUE;
    object _26447 = NOVALUE;
    object _26446 = NOVALUE;
    object _26445 = NOVALUE;
    object _26444 = NOVALUE;
    object _26442 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:602		assignable = TRUE*/
    _47assignable_50950 = _13TRUE_452;

    /** emit.e:603		t = op_result[op]*/
    _2 = (object)SEQ_PTR(_47op_result_51548);
    _t_51758 = (object)*(((s1_ptr)_2)->base + _op_51752);

    /** emit.e:604		if op = C_FUNC then*/
    if (_op_51752 != 133LL)
    goto L1; // [26] 38

    /** emit.e:605			emit_addr(CurrentSub)*/
    _47emit_addr(_36CurrentSub_21447);
L1: 

    /** emit.e:607		if t = T_INTEGER or (ii and IsInteger(a) and IsInteger(b)) then*/
    _26442 = (_t_51758 == 1LL);
    if (_26442 != 0) {
        goto L2; // [46] 79
    }
    if (_ii_51756 == 0) {
        _26444 = 0;
        goto L3; // [50] 62
    }
    _26445 = _47IsInteger(_a_51753);
    if (IS_ATOM_INT(_26445))
    _26444 = (_26445 != 0);
    else
    _26444 = DBL_PTR(_26445)->dbl != 0.0;
L3: 
    if (_26444 == 0) {
        DeRef(_26446);
        _26446 = 0;
        goto L4; // [62] 74
    }
    _26447 = _47IsInteger(_b_51754);
    if (IS_ATOM_INT(_26447))
    _26446 = (_26447 != 0);
    else
    _26446 = DBL_PTR(_26447)->dbl != 0.0;
L4: 
    if (_26446 == 0)
    {
        _26446 = NOVALUE;
        goto L5; // [75] 95
    }
    else{
        _26446 = NOVALUE;
    }
L2: 

    /** emit.e:608			c = NewTempSym()*/
    _c_51757 = _54NewTempSym(0LL);
    if (!IS_ATOM_INT(_c_51757)) {
        _1 = (object)(DBL_PTR(_c_51757)->dbl);
        DeRefDS(_c_51757);
        _c_51757 = _1;
    }

    /** emit.e:609			TempInteger(c)*/
    _47TempInteger(_c_51757);
    goto L6; // [92] 110
L5: 

    /** emit.e:611			c = NewTempSym() -- allocate *after* checking opnd types*/
    _c_51757 = _54NewTempSym(0LL);
    if (!IS_ATOM_INT(_c_51757)) {
        _1 = (object)(DBL_PTR(_c_51757)->dbl);
        DeRefDS(_c_51757);
        _c_51757 = _1;
    }

    /** emit.e:612			emit_temp( c, NEW_REFERENCE )*/
    _47emit_temp(_c_51757, 1LL);
L6: 

    /** emit.e:614		Push(c)*/
    _47Push(_c_51757);

    /** emit.e:615		emit_addr(c)*/
    _47emit_addr(_c_51757);

    /** emit.e:616	end procedure*/
    DeRef(_26445);
    _26445 = NOVALUE;
    DeRef(_26447);
    _26447 = NOVALUE;
    DeRef(_26442);
    _26442 = NOVALUE;
    return;
    ;
}


void _47cont21ii(object _op_51780, object _ii_51782)
{
    object _a_51783 = NOVALUE;
    object _b_51784 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:621		b = Pop()*/
    _b_51784 = _47Pop();
    if (!IS_ATOM_INT(_b_51784)) {
        _1 = (object)(DBL_PTR(_b_51784)->dbl);
        DeRefDS(_b_51784);
        _b_51784 = _1;
    }

    /** emit.e:622		emit_opcode(op)*/
    _47emit_opcode(_op_51780);

    /** emit.e:623		a = Pop()*/
    _a_51783 = _47Pop();
    if (!IS_ATOM_INT(_a_51783)) {
        _1 = (object)(DBL_PTR(_a_51783)->dbl);
        DeRefDS(_a_51783);
        _a_51783 = _1;
    }

    /** emit.e:624		emit_addr(a)*/
    _47emit_addr(_a_51783);

    /** emit.e:625		emit_addr(b)*/
    _47emit_addr(_b_51784);

    /** emit.e:626		cont21d(op, a, b, ii)*/
    _47cont21d(_op_51780, _a_51783, _b_51784, _ii_51782);

    /** emit.e:627	end procedure*/
    return;
    ;
}


object _47good_string(object _elements_51789)
{
    object _obj_51790 = NOVALUE;
    object _ep_51792 = NOVALUE;
    object _e_51794 = NOVALUE;
    object _element_vals_51795 = NOVALUE;
    object _26470 = NOVALUE;
    object _26469 = NOVALUE;
    object _26468 = NOVALUE;
    object _26467 = NOVALUE;
    object _26466 = NOVALUE;
    object _26465 = NOVALUE;
    object _26464 = NOVALUE;
    object _26463 = NOVALUE;
    object _26462 = NOVALUE;
    object _26461 = NOVALUE;
    object _26460 = NOVALUE;
    object _26458 = NOVALUE;
    object _26455 = NOVALUE;
    object _26454 = NOVALUE;
    object _26453 = NOVALUE;
    object _26452 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:634		sequence element_vals*/

    /** emit.e:636		if TRANSLATE and length(elements) > 10000 then*/
    if (_36TRANSLATE_21041 == 0) {
        goto L1; // [9] 31
    }
    if (IS_SEQUENCE(_elements_51789)){
            _26453 = SEQ_PTR(_elements_51789)->length;
    }
    else {
        _26453 = 1;
    }
    _26454 = (_26453 > 10000LL);
    _26453 = NOVALUE;
    if (_26454 == 0)
    {
        DeRef(_26454);
        _26454 = NOVALUE;
        goto L1; // [21] 31
    }
    else{
        DeRef(_26454);
        _26454 = NOVALUE;
    }

    /** emit.e:637			return -1 -- A huge string might upset the C compiler.*/
    DeRefDS(_elements_51789);
    DeRef(_obj_51790);
    DeRef(_element_vals_51795);
    return -1LL;
L1: 

    /** emit.e:639		element_vals = {}*/
    RefDS(_21993);
    DeRef(_element_vals_51795);
    _element_vals_51795 = _21993;

    /** emit.e:640		for i = 1 to length(elements) do*/
    if (IS_SEQUENCE(_elements_51789)){
            _26455 = SEQ_PTR(_elements_51789)->length;
    }
    else {
        _26455 = 1;
    }
    {
        object _i_51802;
        _i_51802 = 1LL;
L2: 
        if (_i_51802 > _26455){
            goto L3; // [43] 183
        }

        /** emit.e:641			ep = elements[i]*/
        _2 = (object)SEQ_PTR(_elements_51789);
        _ep_51792 = (object)*(((s1_ptr)_2)->base + _i_51802);
        if (!IS_ATOM_INT(_ep_51792)){
            _ep_51792 = (object)DBL_PTR(_ep_51792)->dbl;
        }

        /** emit.e:642			if ep < 1 then*/
        if (_ep_51792 >= 1LL)
        goto L4; // [60] 71

        /** emit.e:644				return -1*/
        DeRefDS(_elements_51789);
        DeRef(_obj_51790);
        DeRef(_element_vals_51795);
        return -1LL;
L4: 

        /** emit.e:646			e = ep*/
        _e_51794 = _ep_51792;

        /** emit.e:647			obj = SymTab[e][S_OBJ]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26458 = (object)*(((s1_ptr)_2)->base + _e_51794);
        DeRef(_obj_51790);
        _2 = (object)SEQ_PTR(_26458);
        _obj_51790 = (object)*(((s1_ptr)_2)->base + 1LL);
        Ref(_obj_51790);
        _26458 = NOVALUE;

        /** emit.e:648			if SymTab[e][S_MODE] = M_CONSTANT and*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26460 = (object)*(((s1_ptr)_2)->base + _e_51794);
        _2 = (object)SEQ_PTR(_26460);
        _26461 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26460 = NOVALUE;
        if (IS_ATOM_INT(_26461)) {
            _26462 = (_26461 == 2LL);
        }
        else {
            _26462 = binary_op(EQUALS, _26461, 2LL);
        }
        _26461 = NOVALUE;
        if (IS_ATOM_INT(_26462)) {
            if (_26462 == 0) {
                DeRef(_26463);
                _26463 = 0;
                goto L5; // [112] 123
            }
        }
        else {
            if (DBL_PTR(_26462)->dbl == 0.0) {
                DeRef(_26463);
                _26463 = 0;
                goto L5; // [112] 123
            }
        }
        if (IS_ATOM_INT(_obj_51790))
        _26464 = 1;
        else if (IS_ATOM_DBL(_obj_51790))
        _26464 = IS_ATOM_INT(DoubleToInt(_obj_51790));
        else
        _26464 = 0;
        DeRef(_26463);
        _26463 = (_26464 != 0);
L5: 
        if (_26463 == 0) {
            goto L6; // [123] 169
        }
        _26466 = (_36TRANSLATE_21041 == 0);
        if (_26466 != 0) {
            DeRef(_26467);
            _26467 = 1;
            goto L7; // [132] 156
        }
        if (IS_ATOM_INT(_obj_51790)) {
            _26468 = (_obj_51790 >= 1LL);
        }
        else {
            _26468 = binary_op(GREATEREQ, _obj_51790, 1LL);
        }
        if (IS_ATOM_INT(_26468)) {
            if (_26468 == 0) {
                DeRef(_26469);
                _26469 = 0;
                goto L8; // [140] 152
            }
        }
        else {
            if (DBL_PTR(_26468)->dbl == 0.0) {
                DeRef(_26469);
                _26469 = 0;
                goto L8; // [140] 152
            }
        }
        if (IS_ATOM_INT(_obj_51790)) {
            _26470 = (_obj_51790 <= 255LL);
        }
        else {
            _26470 = binary_op(LESSEQ, _obj_51790, 255LL);
        }
        DeRef(_26469);
        if (IS_ATOM_INT(_26470))
        _26469 = (_26470 != 0);
        else
        _26469 = DBL_PTR(_26470)->dbl != 0.0;
L8: 
        DeRef(_26467);
        _26467 = (_26469 != 0);
L7: 
        if (_26467 == 0)
        {
            _26467 = NOVALUE;
            goto L6; // [157] 169
        }
        else{
            _26467 = NOVALUE;
        }

        /** emit.e:653				element_vals = prepend(element_vals, obj)*/
        Ref(_obj_51790);
        Prepend(&_element_vals_51795, _element_vals_51795, _obj_51790);
        goto L9; // [166] 176
L6: 

        /** emit.e:655				return -1*/
        DeRefDS(_elements_51789);
        DeRef(_obj_51790);
        DeRef(_element_vals_51795);
        DeRef(_26466);
        _26466 = NOVALUE;
        DeRef(_26470);
        _26470 = NOVALUE;
        DeRef(_26468);
        _26468 = NOVALUE;
        DeRef(_26462);
        _26462 = NOVALUE;
        return -1LL;
L9: 

        /** emit.e:657		end for*/
        _i_51802 = _i_51802 + 1LL;
        goto L2; // [178] 50
L3: 
        ;
    }

    /** emit.e:658		return element_vals*/
    DeRefDS(_elements_51789);
    DeRef(_obj_51790);
    DeRef(_26466);
    _26466 = NOVALUE;
    DeRef(_26470);
    _26470 = NOVALUE;
    DeRef(_26468);
    _26468 = NOVALUE;
    DeRef(_26462);
    _26462 = NOVALUE;
    return _element_vals_51795;
    ;
}


object _47Last_op()
{
    object _0, _1, _2;
    

    /** emit.e:664		return last_op*/
    return _47last_op_51829;
    ;
}


object _47Last_pc()
{
    object _0, _1, _2;
    

    /** emit.e:668		return last_pc*/
    return _47last_pc_51830;
    ;
}


void _47move_last_pc(object _amount_51837)
{
    object _0, _1, _2;
    

    /** emit.e:672		if last_pc > 0 then*/
    if (_47last_pc_51830 <= 0LL)
    goto L1; // [7] 20

    /** emit.e:673			last_pc += amount*/
    _47last_pc_51830 = _47last_pc_51830 + _amount_51837;
L1: 

    /** emit.e:675	end procedure*/
    return;
    ;
}


void _47clear_last()
{
    object _0, _1, _2;
    

    /** emit.e:678		last_op = 0*/
    _47last_op_51829 = 0LL;

    /** emit.e:679		last_pc = 0*/
    _47last_pc_51830 = 0LL;

    /** emit.e:680	end procedure*/
    return;
    ;
}


void _47clear_op()
{
    object _0, _1, _2;
    

    /** emit.e:683		previous_op = -1*/
    _36previous_op_21541 = -1LL;

    /** emit.e:684		assignable = FALSE*/
    _47assignable_50950 = _13FALSE_450;

    /** emit.e:685	end procedure*/
    return;
    ;
}


void _47inlined_function()
{
    object _0, _1, _2;
    

    /** emit.e:689		previous_op = PROC*/
    _36previous_op_21541 = 27LL;

    /** emit.e:690		assignable = TRUE*/
    _47assignable_50950 = _13TRUE_452;

    /** emit.e:691		inlined = TRUE*/
    _47inlined_51848 = _13TRUE_452;

    /** emit.e:692	end procedure*/
    return;
    ;
}


void _47add_inline_target(object _pc_51859)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_51859)) {
        _1 = (object)(DBL_PTR(_pc_51859)->dbl);
        DeRefDS(_pc_51859);
        _pc_51859 = _1;
    }

    /** emit.e:696		inlined_targets &= pc*/
    Append(&_47inlined_targets_51856, _47inlined_targets_51856, _pc_51859);

    /** emit.e:697	end procedure*/
    return;
    ;
}


void _47clear_inline_targets()
{
    object _0, _1, _2;
    

    /** emit.e:700		inlined_targets = {}*/
    RefDS(_21993);
    DeRefi(_47inlined_targets_51856);
    _47inlined_targets_51856 = _21993;

    /** emit.e:701	end procedure*/
    return;
    ;
}


void _47emit_inline(object _code_51865)
{
    object _0, _1, _2;
    

    /** emit.e:704		last_pc = 0*/
    _47last_pc_51830 = 0LL;

    /** emit.e:705		last_op = 0*/
    _47last_op_51829 = 0LL;

    /** emit.e:706		Code &= code*/
    Concat((object_ptr)&_36Code_21531, _36Code_21531, _code_51865);

    /** emit.e:707	end procedure*/
    DeRefDS(_code_51865);
    return;
    ;
}


void _47emit_op(object _op_51870)
{
    object _a_51872 = NOVALUE;
    object _b_51873 = NOVALUE;
    object _c_51874 = NOVALUE;
    object _d_51875 = NOVALUE;
    object _source_51876 = NOVALUE;
    object _target_51877 = NOVALUE;
    object _subsym_51878 = NOVALUE;
    object _lhs_var_51880 = NOVALUE;
    object _ib_51881 = NOVALUE;
    object _ic_51882 = NOVALUE;
    object _n_51883 = NOVALUE;
    object _obj_51884 = NOVALUE;
    object _elements_51885 = NOVALUE;
    object _element_vals_51886 = NOVALUE;
    object _last_pc_backup_51887 = NOVALUE;
    object _last_op_backup_51888 = NOVALUE;
    object _temp_51897 = NOVALUE;
    object _real_op_52197 = NOVALUE;
    object _ref_52204 = NOVALUE;
    object _paths_52234 = NOVALUE;
    object _if_code_52314 = NOVALUE;
    object _if_code_52353 = NOVALUE;
    object _Top_inlined_Top_at_5482_52972 = NOVALUE;
    object _element_53043 = NOVALUE;
    object _Top_inlined_Top_at_7037_53190 = NOVALUE;
    object _31698 = NOVALUE;
    object _31697 = NOVALUE;
    object _27070 = NOVALUE;
    object _27069 = NOVALUE;
    object _27068 = NOVALUE;
    object _27064 = NOVALUE;
    object _27061 = NOVALUE;
    object _27059 = NOVALUE;
    object _27053 = NOVALUE;
    object _27052 = NOVALUE;
    object _27051 = NOVALUE;
    object _27049 = NOVALUE;
    object _27047 = NOVALUE;
    object _27046 = NOVALUE;
    object _27045 = NOVALUE;
    object _27044 = NOVALUE;
    object _27043 = NOVALUE;
    object _27042 = NOVALUE;
    object _27041 = NOVALUE;
    object _27040 = NOVALUE;
    object _27039 = NOVALUE;
    object _27038 = NOVALUE;
    object _27037 = NOVALUE;
    object _27035 = NOVALUE;
    object _27034 = NOVALUE;
    object _27033 = NOVALUE;
    object _27031 = NOVALUE;
    object _27030 = NOVALUE;
    object _27029 = NOVALUE;
    object _27028 = NOVALUE;
    object _27027 = NOVALUE;
    object _27026 = NOVALUE;
    object _27025 = NOVALUE;
    object _27024 = NOVALUE;
    object _27023 = NOVALUE;
    object _27020 = NOVALUE;
    object _27017 = NOVALUE;
    object _27016 = NOVALUE;
    object _27015 = NOVALUE;
    object _27014 = NOVALUE;
    object _27012 = NOVALUE;
    object _27010 = NOVALUE;
    object _26998 = NOVALUE;
    object _26990 = NOVALUE;
    object _26987 = NOVALUE;
    object _26986 = NOVALUE;
    object _26985 = NOVALUE;
    object _26984 = NOVALUE;
    object _26981 = NOVALUE;
    object _26980 = NOVALUE;
    object _26979 = NOVALUE;
    object _26978 = NOVALUE;
    object _26977 = NOVALUE;
    object _26976 = NOVALUE;
    object _26975 = NOVALUE;
    object _26974 = NOVALUE;
    object _26973 = NOVALUE;
    object _26972 = NOVALUE;
    object _26971 = NOVALUE;
    object _26969 = NOVALUE;
    object _26965 = NOVALUE;
    object _26964 = NOVALUE;
    object _26963 = NOVALUE;
    object _26962 = NOVALUE;
    object _26961 = NOVALUE;
    object _26960 = NOVALUE;
    object _26959 = NOVALUE;
    object _26958 = NOVALUE;
    object _26957 = NOVALUE;
    object _26956 = NOVALUE;
    object _26955 = NOVALUE;
    object _26953 = NOVALUE;
    object _26948 = NOVALUE;
    object _26947 = NOVALUE;
    object _26945 = NOVALUE;
    object _26944 = NOVALUE;
    object _26943 = NOVALUE;
    object _26941 = NOVALUE;
    object _26938 = NOVALUE;
    object _26934 = NOVALUE;
    object _26931 = NOVALUE;
    object _26930 = NOVALUE;
    object _26929 = NOVALUE;
    object _26928 = NOVALUE;
    object _26927 = NOVALUE;
    object _26926 = NOVALUE;
    object _26924 = NOVALUE;
    object _26923 = NOVALUE;
    object _26921 = NOVALUE;
    object _26920 = NOVALUE;
    object _26919 = NOVALUE;
    object _26918 = NOVALUE;
    object _26917 = NOVALUE;
    object _26916 = NOVALUE;
    object _26915 = NOVALUE;
    object _26914 = NOVALUE;
    object _26913 = NOVALUE;
    object _26912 = NOVALUE;
    object _26910 = NOVALUE;
    object _26909 = NOVALUE;
    object _26908 = NOVALUE;
    object _26907 = NOVALUE;
    object _26906 = NOVALUE;
    object _26905 = NOVALUE;
    object _26904 = NOVALUE;
    object _26903 = NOVALUE;
    object _26902 = NOVALUE;
    object _26901 = NOVALUE;
    object _26900 = NOVALUE;
    object _26899 = NOVALUE;
    object _26898 = NOVALUE;
    object _26897 = NOVALUE;
    object _26896 = NOVALUE;
    object _26894 = NOVALUE;
    object _26891 = NOVALUE;
    object _26890 = NOVALUE;
    object _26889 = NOVALUE;
    object _26888 = NOVALUE;
    object _26887 = NOVALUE;
    object _26886 = NOVALUE;
    object _26885 = NOVALUE;
    object _26884 = NOVALUE;
    object _26883 = NOVALUE;
    object _26882 = NOVALUE;
    object _26881 = NOVALUE;
    object _26880 = NOVALUE;
    object _26879 = NOVALUE;
    object _26878 = NOVALUE;
    object _26877 = NOVALUE;
    object _26875 = NOVALUE;
    object _26871 = NOVALUE;
    object _26869 = NOVALUE;
    object _26868 = NOVALUE;
    object _26866 = NOVALUE;
    object _26864 = NOVALUE;
    object _26862 = NOVALUE;
    object _26861 = NOVALUE;
    object _26859 = NOVALUE;
    object _26858 = NOVALUE;
    object _26857 = NOVALUE;
    object _26856 = NOVALUE;
    object _26855 = NOVALUE;
    object _26854 = NOVALUE;
    object _26853 = NOVALUE;
    object _26852 = NOVALUE;
    object _26851 = NOVALUE;
    object _26850 = NOVALUE;
    object _26849 = NOVALUE;
    object _26848 = NOVALUE;
    object _26847 = NOVALUE;
    object _26846 = NOVALUE;
    object _26845 = NOVALUE;
    object _26844 = NOVALUE;
    object _26843 = NOVALUE;
    object _26842 = NOVALUE;
    object _26841 = NOVALUE;
    object _26839 = NOVALUE;
    object _26837 = NOVALUE;
    object _26836 = NOVALUE;
    object _26834 = NOVALUE;
    object _26831 = NOVALUE;
    object _26830 = NOVALUE;
    object _26828 = NOVALUE;
    object _26827 = NOVALUE;
    object _26826 = NOVALUE;
    object _26824 = NOVALUE;
    object _26816 = NOVALUE;
    object _26815 = NOVALUE;
    object _26814 = NOVALUE;
    object _26813 = NOVALUE;
    object _26812 = NOVALUE;
    object _26811 = NOVALUE;
    object _26810 = NOVALUE;
    object _26809 = NOVALUE;
    object _26808 = NOVALUE;
    object _26807 = NOVALUE;
    object _26806 = NOVALUE;
    object _26805 = NOVALUE;
    object _26804 = NOVALUE;
    object _26803 = NOVALUE;
    object _26802 = NOVALUE;
    object _26801 = NOVALUE;
    object _26800 = NOVALUE;
    object _26799 = NOVALUE;
    object _26798 = NOVALUE;
    object _26797 = NOVALUE;
    object _26796 = NOVALUE;
    object _26795 = NOVALUE;
    object _26794 = NOVALUE;
    object _26793 = NOVALUE;
    object _26787 = NOVALUE;
    object _26786 = NOVALUE;
    object _26783 = NOVALUE;
    object _26780 = NOVALUE;
    object _26779 = NOVALUE;
    object _26778 = NOVALUE;
    object _26777 = NOVALUE;
    object _26776 = NOVALUE;
    object _26775 = NOVALUE;
    object _26774 = NOVALUE;
    object _26773 = NOVALUE;
    object _26772 = NOVALUE;
    object _26771 = NOVALUE;
    object _26769 = NOVALUE;
    object _26768 = NOVALUE;
    object _26767 = NOVALUE;
    object _26765 = NOVALUE;
    object _26763 = NOVALUE;
    object _26762 = NOVALUE;
    object _26761 = NOVALUE;
    object _26760 = NOVALUE;
    object _26759 = NOVALUE;
    object _26758 = NOVALUE;
    object _26757 = NOVALUE;
    object _26756 = NOVALUE;
    object _26755 = NOVALUE;
    object _26754 = NOVALUE;
    object _26752 = NOVALUE;
    object _26751 = NOVALUE;
    object _26749 = NOVALUE;
    object _26748 = NOVALUE;
    object _26747 = NOVALUE;
    object _26746 = NOVALUE;
    object _26745 = NOVALUE;
    object _26743 = NOVALUE;
    object _26742 = NOVALUE;
    object _26741 = NOVALUE;
    object _26740 = NOVALUE;
    object _26739 = NOVALUE;
    object _26738 = NOVALUE;
    object _26737 = NOVALUE;
    object _26736 = NOVALUE;
    object _26734 = NOVALUE;
    object _26733 = NOVALUE;
    object _26732 = NOVALUE;
    object _26731 = NOVALUE;
    object _26730 = NOVALUE;
    object _26728 = NOVALUE;
    object _26727 = NOVALUE;
    object _26725 = NOVALUE;
    object _26724 = NOVALUE;
    object _26723 = NOVALUE;
    object _26722 = NOVALUE;
    object _26721 = NOVALUE;
    object _26719 = NOVALUE;
    object _26717 = NOVALUE;
    object _26715 = NOVALUE;
    object _26714 = NOVALUE;
    object _26712 = NOVALUE;
    object _26711 = NOVALUE;
    object _26710 = NOVALUE;
    object _26709 = NOVALUE;
    object _26708 = NOVALUE;
    object _26707 = NOVALUE;
    object _26706 = NOVALUE;
    object _26705 = NOVALUE;
    object _26704 = NOVALUE;
    object _26703 = NOVALUE;
    object _26702 = NOVALUE;
    object _26701 = NOVALUE;
    object _26700 = NOVALUE;
    object _26699 = NOVALUE;
    object _26698 = NOVALUE;
    object _26697 = NOVALUE;
    object _26696 = NOVALUE;
    object _26693 = NOVALUE;
    object _26692 = NOVALUE;
    object _26690 = NOVALUE;
    object _26689 = NOVALUE;
    object _26688 = NOVALUE;
    object _26687 = NOVALUE;
    object _26686 = NOVALUE;
    object _26684 = NOVALUE;
    object _26682 = NOVALUE;
    object _26681 = NOVALUE;
    object _26680 = NOVALUE;
    object _26679 = NOVALUE;
    object _26678 = NOVALUE;
    object _26677 = NOVALUE;
    object _26676 = NOVALUE;
    object _26675 = NOVALUE;
    object _26674 = NOVALUE;
    object _26671 = NOVALUE;
    object _26670 = NOVALUE;
    object _26668 = NOVALUE;
    object _26667 = NOVALUE;
    object _26666 = NOVALUE;
    object _26665 = NOVALUE;
    object _26664 = NOVALUE;
    object _26661 = NOVALUE;
    object _26660 = NOVALUE;
    object _26659 = NOVALUE;
    object _26658 = NOVALUE;
    object _26657 = NOVALUE;
    object _26656 = NOVALUE;
    object _26655 = NOVALUE;
    object _26650 = NOVALUE;
    object _26649 = NOVALUE;
    object _26648 = NOVALUE;
    object _26646 = NOVALUE;
    object _26645 = NOVALUE;
    object _26643 = NOVALUE;
    object _26642 = NOVALUE;
    object _26637 = NOVALUE;
    object _26636 = NOVALUE;
    object _26635 = NOVALUE;
    object _26634 = NOVALUE;
    object _26633 = NOVALUE;
    object _26627 = NOVALUE;
    object _26626 = NOVALUE;
    object _26624 = NOVALUE;
    object _26623 = NOVALUE;
    object _26622 = NOVALUE;
    object _26621 = NOVALUE;
    object _26620 = NOVALUE;
    object _26619 = NOVALUE;
    object _26618 = NOVALUE;
    object _26617 = NOVALUE;
    object _26616 = NOVALUE;
    object _26615 = NOVALUE;
    object _26614 = NOVALUE;
    object _26612 = NOVALUE;
    object _26611 = NOVALUE;
    object _26610 = NOVALUE;
    object _26609 = NOVALUE;
    object _26608 = NOVALUE;
    object _26607 = NOVALUE;
    object _26606 = NOVALUE;
    object _26605 = NOVALUE;
    object _26604 = NOVALUE;
    object _26603 = NOVALUE;
    object _26602 = NOVALUE;
    object _26601 = NOVALUE;
    object _26600 = NOVALUE;
    object _26599 = NOVALUE;
    object _26597 = NOVALUE;
    object _26596 = NOVALUE;
    object _26595 = NOVALUE;
    object _26594 = NOVALUE;
    object _26591 = NOVALUE;
    object _26590 = NOVALUE;
    object _26589 = NOVALUE;
    object _26588 = NOVALUE;
    object _26586 = NOVALUE;
    object _26585 = NOVALUE;
    object _26584 = NOVALUE;
    object _26583 = NOVALUE;
    object _26581 = NOVALUE;
    object _26580 = NOVALUE;
    object _26579 = NOVALUE;
    object _26578 = NOVALUE;
    object _26577 = NOVALUE;
    object _26576 = NOVALUE;
    object _26575 = NOVALUE;
    object _26574 = NOVALUE;
    object _26573 = NOVALUE;
    object _26572 = NOVALUE;
    object _26571 = NOVALUE;
    object _26570 = NOVALUE;
    object _26569 = NOVALUE;
    object _26568 = NOVALUE;
    object _26566 = NOVALUE;
    object _26565 = NOVALUE;
    object _26564 = NOVALUE;
    object _26563 = NOVALUE;
    object _26562 = NOVALUE;
    object _26560 = NOVALUE;
    object _26559 = NOVALUE;
    object _26558 = NOVALUE;
    object _26557 = NOVALUE;
    object _26556 = NOVALUE;
    object _26552 = NOVALUE;
    object _26551 = NOVALUE;
    object _26550 = NOVALUE;
    object _26549 = NOVALUE;
    object _26548 = NOVALUE;
    object _26546 = NOVALUE;
    object _26545 = NOVALUE;
    object _26544 = NOVALUE;
    object _26543 = NOVALUE;
    object _26542 = NOVALUE;
    object _26541 = NOVALUE;
    object _26540 = NOVALUE;
    object _26539 = NOVALUE;
    object _26538 = NOVALUE;
    object _26537 = NOVALUE;
    object _26536 = NOVALUE;
    object _26535 = NOVALUE;
    object _26534 = NOVALUE;
    object _26533 = NOVALUE;
    object _26532 = NOVALUE;
    object _26531 = NOVALUE;
    object _26530 = NOVALUE;
    object _26529 = NOVALUE;
    object _26527 = NOVALUE;
    object _26526 = NOVALUE;
    object _26525 = NOVALUE;
    object _26524 = NOVALUE;
    object _26523 = NOVALUE;
    object _26522 = NOVALUE;
    object _26521 = NOVALUE;
    object _26520 = NOVALUE;
    object _26519 = NOVALUE;
    object _26517 = NOVALUE;
    object _26516 = NOVALUE;
    object _26515 = NOVALUE;
    object _26513 = NOVALUE;
    object _26512 = NOVALUE;
    object _26510 = NOVALUE;
    object _26508 = NOVALUE;
    object _26507 = NOVALUE;
    object _26506 = NOVALUE;
    object _26505 = NOVALUE;
    object _26504 = NOVALUE;
    object _26503 = NOVALUE;
    object _26499 = NOVALUE;
    object _26498 = NOVALUE;
    object _26497 = NOVALUE;
    object _26495 = NOVALUE;
    object _26494 = NOVALUE;
    object _26493 = NOVALUE;
    object _26492 = NOVALUE;
    object _26491 = NOVALUE;
    object _26490 = NOVALUE;
    object _26489 = NOVALUE;
    object _26488 = NOVALUE;
    object _26487 = NOVALUE;
    object _26486 = NOVALUE;
    object _26485 = NOVALUE;
    object _26484 = NOVALUE;
    object _26483 = NOVALUE;
    object _26482 = NOVALUE;
    object _26481 = NOVALUE;
    object _26476 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_op_51870)) {
        _1 = (object)(DBL_PTR(_op_51870)->dbl);
        DeRefDS(_op_51870);
        _op_51870 = _1;
    }

    /** emit.e:717		integer ib, ic, n*/

    /** emit.e:718		object obj*/

    /** emit.e:719		sequence elements*/

    /** emit.e:720		object element_vals*/

    /** emit.e:722		check_for_temps()*/
    _47check_for_temps();

    /** emit.e:723		integer last_pc_backup = last_pc*/
    _last_pc_backup_51887 = _47last_pc_51830;

    /** emit.e:724		integer last_op_backup = last_op*/
    _last_op_backup_51888 = _47last_op_51829;

    /** emit.e:726		last_op = op*/
    _47last_op_51829 = _op_51870;

    /** emit.e:727		last_pc = length(Code) + 1*/
    if (IS_SEQUENCE(_36Code_21531)){
            _26476 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _26476 = 1;
    }
    _47last_pc_51830 = _26476 + 1;
    _26476 = NOVALUE;

    /** emit.e:729		switch op label "EMIT" do*/
    _0 = _op_51870;
    switch ( _0 ){ 

        /** emit.e:730		case ASSIGN then*/
        case 18:

        /** emit.e:731			sequence temp = {}*/
        RefDS(_21993);
        DeRef(_temp_51897);
        _temp_51897 = _21993;

        /** emit.e:732			if not TRANSLATE and*/
        _26481 = (_36TRANSLATE_21041 == 0);
        if (_26481 == 0) {
            goto L1; // [70] 202
        }
        _26483 = (_36previous_op_21541 == 92LL);
        if (_26483 != 0) {
            DeRef(_26484);
            _26484 = 1;
            goto L2; // [82] 98
        }
        _26485 = (_36previous_op_21541 == 25LL);
        _26484 = (_26485 != 0);
L2: 
        if (_26484 == 0)
        {
            _26484 = NOVALUE;
            goto L1; // [99] 202
        }
        else{
            _26484 = NOVALUE;
        }

        /** emit.e:736				while Code[$-1] = DEREF_TEMP and find( Code[$], derefs ) do*/
L3: 
        if (IS_SEQUENCE(_36Code_21531)){
                _26486 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26486 = 1;
        }
        _26487 = _26486 - 1LL;
        _26486 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21531);
        _26488 = (object)*(((s1_ptr)_2)->base + _26487);
        if (IS_ATOM_INT(_26488)) {
            _26489 = (_26488 == 208LL);
        }
        else {
            _26489 = binary_op(EQUALS, _26488, 208LL);
        }
        _26488 = NOVALUE;
        if (IS_ATOM_INT(_26489)) {
            if (_26489 == 0) {
                goto L4; // [126] 201
            }
        }
        else {
            if (DBL_PTR(_26489)->dbl == 0.0) {
                goto L4; // [126] 201
            }
        }
        if (IS_SEQUENCE(_36Code_21531)){
                _26491 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26491 = 1;
        }
        _2 = (object)SEQ_PTR(_36Code_21531);
        _26492 = (object)*(((s1_ptr)_2)->base + _26491);
        _26493 = find_from(_26492, _47derefs_51451, 1LL);
        _26492 = NOVALUE;
        if (_26493 == 0)
        {
            _26493 = NOVALUE;
            goto L4; // [147] 201
        }
        else{
            _26493 = NOVALUE;
        }

        /** emit.e:739					temp &= Code[$]*/
        if (IS_SEQUENCE(_36Code_21531)){
                _26494 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26494 = 1;
        }
        _2 = (object)SEQ_PTR(_36Code_21531);
        _26495 = (object)*(((s1_ptr)_2)->base + _26494);
        if (IS_SEQUENCE(_temp_51897) && IS_ATOM(_26495)) {
            Ref(_26495);
            Append(&_temp_51897, _temp_51897, _26495);
        }
        else if (IS_ATOM(_temp_51897) && IS_SEQUENCE(_26495)) {
        }
        else {
            Concat((object_ptr)&_temp_51897, _temp_51897, _26495);
        }
        _26495 = NOVALUE;

        /** emit.e:740					Code = remove( Code, length(Code)-1, length(Code) )*/
        if (IS_SEQUENCE(_36Code_21531)){
                _26497 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26497 = 1;
        }
        _26498 = _26497 - 1LL;
        _26497 = NOVALUE;
        if (IS_SEQUENCE(_36Code_21531)){
                _26499 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26499 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_36Code_21531);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_26498)) ? _26498 : (object)(DBL_PTR(_26498)->dbl);
            int stop = (IS_ATOM_INT(_26499)) ? _26499 : (object)(DBL_PTR(_26499)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_36Code_21531), start, &_36Code_21531 );
                }
                else Tail(SEQ_PTR(_36Code_21531), stop+1, &_36Code_21531);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_36Code_21531), start, &_36Code_21531);
            }
            else {
                assign_slice_seq = &assign_space;
                _36Code_21531 = Remove_elements(start, stop, (SEQ_PTR(_36Code_21531)->ref == 1));
            }
        }
        _26498 = NOVALUE;
        _26499 = NOVALUE;

        /** emit.e:741					emit_temp( temp, NEW_REFERENCE )*/
        RefDS(_temp_51897);
        _47emit_temp(_temp_51897, 1LL);

        /** emit.e:742				end while*/
        goto L3; // [198] 107
L4: 
L1: 

        /** emit.e:746			source = Pop()*/
        _source_51876 = _47Pop();
        if (!IS_ATOM_INT(_source_51876)) {
            _1 = (object)(DBL_PTR(_source_51876)->dbl);
            DeRefDS(_source_51876);
            _source_51876 = _1;
        }

        /** emit.e:747			target = Pop()*/
        _target_51877 = _47Pop();
        if (!IS_ATOM_INT(_target_51877)) {
            _1 = (object)(DBL_PTR(_target_51877)->dbl);
            DeRefDS(_target_51877);
            _target_51877 = _1;
        }

        /** emit.e:748			if assignable then*/
        if (_47assignable_50950 == 0)
        {
            goto L5; // [220] 601
        }
        else{
        }

        /** emit.e:750				if inlined then*/
        if (_47inlined_51848 == 0)
        {
            goto L6; // [227] 326
        }
        else{
        }

        /** emit.e:751					inlined = 0*/
        _47inlined_51848 = 0LL;

        /** emit.e:752					if length( inlined_targets ) then*/
        if (IS_SEQUENCE(_47inlined_targets_51856)){
                _26503 = SEQ_PTR(_47inlined_targets_51856)->length;
        }
        else {
            _26503 = 1;
        }
        if (_26503 == 0)
        {
            _26503 = NOVALUE;
            goto L7; // [242] 295
        }
        else{
            _26503 = NOVALUE;
        }

        /** emit.e:753						for i = 1 to length( inlined_targets ) do*/
        if (IS_SEQUENCE(_47inlined_targets_51856)){
                _26504 = SEQ_PTR(_47inlined_targets_51856)->length;
        }
        else {
            _26504 = 1;
        }
        {
            object _i_51940;
            _i_51940 = 1LL;
L8: 
            if (_i_51940 > _26504){
                goto L9; // [252] 280
            }

            /** emit.e:754							Code[inlined_targets[i]] = target*/
            _2 = (object)SEQ_PTR(_47inlined_targets_51856);
            _26505 = (object)*(((s1_ptr)_2)->base + _i_51940);
            _2 = (object)SEQ_PTR(_36Code_21531);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _36Code_21531 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _26505);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _target_51877;
            DeRef(_1);

            /** emit.e:755						end for*/
            _i_51940 = _i_51940 + 1LL;
            goto L8; // [275] 259
L9: 
            ;
        }

        /** emit.e:756						clear_inline_targets()*/

        /** emit.e:700		inlined_targets = {}*/
        RefDS(_21993);
        DeRefi(_47inlined_targets_51856);
        _47inlined_targets_51856 = _21993;

        /** emit.e:701	end procedure*/
        goto LA; // [291] 294
LA: 
L7: 

        /** emit.e:759					assignable = FALSE*/
        _47assignable_50950 = _13FALSE_450;

        /** emit.e:760					clear_last()*/

        /** emit.e:678		last_op = 0*/
        _47last_op_51829 = 0LL;

        /** emit.e:679		last_pc = 0*/
        _47last_pc_51830 = 0LL;

        /** emit.e:680	end procedure*/
        goto LB; // [316] 319
LB: 

        /** emit.e:761					break "EMIT"*/
        DeRef(_temp_51897);
        _temp_51897 = NOVALUE;
        goto LC; // [323] 7739
L6: 

        /** emit.e:764				clear_temp( Code[$] )*/
        if (IS_SEQUENCE(_36Code_21531)){
                _26506 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26506 = 1;
        }
        _2 = (object)SEQ_PTR(_36Code_21531);
        _26507 = (object)*(((s1_ptr)_2)->base + _26506);
        Ref(_26507);
        _47clear_temp(_26507);
        _26507 = NOVALUE;

        /** emit.e:765				Code = remove( Code, length( Code ) ) -- drop previous target*/
        if (IS_SEQUENCE(_36Code_21531)){
                _26508 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26508 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_36Code_21531);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_26508)) ? _26508 : (object)(DBL_PTR(_26508)->dbl);
            int stop = (IS_ATOM_INT(_26508)) ? _26508 : (object)(DBL_PTR(_26508)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_36Code_21531), start, &_36Code_21531 );
                }
                else Tail(SEQ_PTR(_36Code_21531), stop+1, &_36Code_21531);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_36Code_21531), start, &_36Code_21531);
            }
            else {
                assign_slice_seq = &assign_space;
                _36Code_21531 = Remove_elements(start, stop, (SEQ_PTR(_36Code_21531)->ref == 1));
            }
        }
        _26508 = NOVALUE;
        _26508 = NOVALUE;

        /** emit.e:766				op = previous_op -- keep same previous op*/
        _op_51870 = _36previous_op_21541;

        /** emit.e:767				if IsInteger(target) then*/
        _26510 = _47IsInteger(_target_51877);
        if (_26510 == 0) {
            DeRef(_26510);
            _26510 = NOVALUE;
            goto LD; // [372] 588
        }
        else {
            if (!IS_ATOM_INT(_26510) && DBL_PTR(_26510)->dbl == 0.0){
                DeRef(_26510);
                _26510 = NOVALUE;
                goto LD; // [372] 588
            }
            DeRef(_26510);
            _26510 = NOVALUE;
        }
        DeRef(_26510);
        _26510 = NOVALUE;

        /** emit.e:768					if previous_op = RHS_SUBS then*/
        if (_36previous_op_21541 != 25LL)
        goto LE; // [381] 412

        /** emit.e:769						op = RHS_SUBS_I*/
        _op_51870 = 114LL;

        /** emit.e:770						backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_36Code_21531)){
                _26512 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26512 = 1;
        }
        _26513 = _26512 - 2LL;
        _26512 = NOVALUE;
        _47backpatch(_26513, 114LL);
        _26513 = NOVALUE;
        goto LF; // [409] 587
LE: 

        /** emit.e:772					elsif previous_op = PLUS1 then*/
        if (_36previous_op_21541 != 93LL)
        goto L10; // [418] 449

        /** emit.e:773						op = PLUS1_I*/
        _op_51870 = 117LL;

        /** emit.e:774						backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_36Code_21531)){
                _26515 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26515 = 1;
        }
        _26516 = _26515 - 2LL;
        _26515 = NOVALUE;
        _47backpatch(_26516, 117LL);
        _26516 = NOVALUE;
        goto LF; // [446] 587
L10: 

        /** emit.e:776					elsif previous_op = PLUS or previous_op = MINUS then*/
        _26517 = (_36previous_op_21541 == 11LL);
        if (_26517 != 0) {
            goto L11; // [459] 476
        }
        _26519 = (_36previous_op_21541 == 10LL);
        if (_26519 == 0)
        {
            DeRef(_26519);
            _26519 = NOVALUE;
            goto L12; // [472] 567
        }
        else{
            DeRef(_26519);
            _26519 = NOVALUE;
        }
L11: 

        /** emit.e:777						if IsInteger(Code[$]) and*/
        if (IS_SEQUENCE(_36Code_21531)){
                _26520 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26520 = 1;
        }
        _2 = (object)SEQ_PTR(_36Code_21531);
        _26521 = (object)*(((s1_ptr)_2)->base + _26520);
        Ref(_26521);
        _26522 = _47IsInteger(_26521);
        _26521 = NOVALUE;
        if (IS_ATOM_INT(_26522)) {
            if (_26522 == 0) {
                goto LF; // [491] 587
            }
        }
        else {
            if (DBL_PTR(_26522)->dbl == 0.0) {
                goto LF; // [491] 587
            }
        }
        if (IS_SEQUENCE(_36Code_21531)){
                _26524 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26524 = 1;
        }
        _26525 = _26524 - 1LL;
        _26524 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21531);
        _26526 = (object)*(((s1_ptr)_2)->base + _26525);
        Ref(_26526);
        _26527 = _47IsInteger(_26526);
        _26526 = NOVALUE;
        if (_26527 == 0) {
            DeRef(_26527);
            _26527 = NOVALUE;
            goto LF; // [513] 587
        }
        else {
            if (!IS_ATOM_INT(_26527) && DBL_PTR(_26527)->dbl == 0.0){
                DeRef(_26527);
                _26527 = NOVALUE;
                goto LF; // [513] 587
            }
            DeRef(_26527);
            _26527 = NOVALUE;
        }
        DeRef(_26527);
        _26527 = NOVALUE;

        /** emit.e:779							if previous_op = PLUS then*/
        if (_36previous_op_21541 != 11LL)
        goto L13; // [522] 538

        /** emit.e:780								op = PLUS_I*/
        _op_51870 = 115LL;
        goto L14; // [535] 548
L13: 

        /** emit.e:782								op = MINUS_I*/
        _op_51870 = 116LL;
L14: 

        /** emit.e:784							backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_36Code_21531)){
                _26529 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26529 = 1;
        }
        _26530 = _26529 - 2LL;
        _26529 = NOVALUE;
        _47backpatch(_26530, _op_51870);
        _26530 = NOVALUE;
        goto LF; // [564] 587
L12: 

        /** emit.e:790						if IsInteger(source) then*/
        _26531 = _47IsInteger(_source_51876);
        if (_26531 == 0) {
            DeRef(_26531);
            _26531 = NOVALUE;
            goto L15; // [573] 586
        }
        else {
            if (!IS_ATOM_INT(_26531) && DBL_PTR(_26531)->dbl == 0.0){
                DeRef(_26531);
                _26531 = NOVALUE;
                goto L15; // [573] 586
            }
            DeRef(_26531);
            _26531 = NOVALUE;
        }
        DeRef(_26531);
        _26531 = NOVALUE;

        /** emit.e:791							op = ASSIGN_I -- fake to avoid subsequent check*/
        _op_51870 = 113LL;
L15: 
LF: 
LD: 

        /** emit.e:795				last_op = last_op_backup*/
        _47last_op_51829 = _last_op_backup_51888;

        /** emit.e:796				last_pc = last_pc_backup*/
        _47last_pc_51830 = _last_pc_backup_51887;
        goto L16; // [598] 743
L5: 

        /** emit.e:798				if IsInteger(source) and IsInteger(target) then*/
        _26532 = _47IsInteger(_source_51876);
        if (IS_ATOM_INT(_26532)) {
            if (_26532 == 0) {
                goto L17; // [607] 629
            }
        }
        else {
            if (DBL_PTR(_26532)->dbl == 0.0) {
                goto L17; // [607] 629
            }
        }
        _26534 = _47IsInteger(_target_51877);
        if (_26534 == 0) {
            DeRef(_26534);
            _26534 = NOVALUE;
            goto L17; // [616] 629
        }
        else {
            if (!IS_ATOM_INT(_26534) && DBL_PTR(_26534)->dbl == 0.0){
                DeRef(_26534);
                _26534 = NOVALUE;
                goto L17; // [616] 629
            }
            DeRef(_26534);
            _26534 = NOVALUE;
        }
        DeRef(_26534);
        _26534 = NOVALUE;

        /** emit.e:799					op = ASSIGN_I*/
        _op_51870 = 113LL;
L17: 

        /** emit.e:801				if source > 0 and target > 0 and*/
        _26535 = (_source_51876 > 0LL);
        if (_26535 == 0) {
            _26536 = 0;
            goto L18; // [635] 647
        }
        _26537 = (_target_51877 > 0LL);
        _26536 = (_26537 != 0);
L18: 
        if (_26536 == 0) {
            _26538 = 0;
            goto L19; // [647] 673
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26539 = (object)*(((s1_ptr)_2)->base + _source_51876);
        _2 = (object)SEQ_PTR(_26539);
        _26540 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26539 = NOVALUE;
        if (IS_ATOM_INT(_26540)) {
            _26541 = (_26540 == 2LL);
        }
        else {
            _26541 = binary_op(EQUALS, _26540, 2LL);
        }
        _26540 = NOVALUE;
        if (IS_ATOM_INT(_26541))
        _26538 = (_26541 != 0);
        else
        _26538 = DBL_PTR(_26541)->dbl != 0.0;
L19: 
        if (_26538 == 0) {
            goto L1A; // [673] 727
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26543 = (object)*(((s1_ptr)_2)->base + _target_51877);
        _2 = (object)SEQ_PTR(_26543);
        _26544 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26543 = NOVALUE;
        if (IS_ATOM_INT(_26544)) {
            _26545 = (_26544 == 2LL);
        }
        else {
            _26545 = binary_op(EQUALS, _26544, 2LL);
        }
        _26544 = NOVALUE;
        if (_26545 == 0) {
            DeRef(_26545);
            _26545 = NOVALUE;
            goto L1A; // [696] 727
        }
        else {
            if (!IS_ATOM_INT(_26545) && DBL_PTR(_26545)->dbl == 0.0){
                DeRef(_26545);
                _26545 = NOVALUE;
                goto L1A; // [696] 727
            }
            DeRef(_26545);
            _26545 = NOVALUE;
        }
        DeRef(_26545);
        _26545 = NOVALUE;

        /** emit.e:806					SymTab[target][S_OBJ] = SymTab[source][S_OBJ]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_target_51877 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26548 = (object)*(((s1_ptr)_2)->base + _source_51876);
        _2 = (object)SEQ_PTR(_26548);
        _26549 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26548 = NOVALUE;
        Ref(_26549);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26549;
        if( _1 != _26549 ){
            DeRef(_1);
        }
        _26549 = NOVALUE;
        _26546 = NOVALUE;
L1A: 

        /** emit.e:809				emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:810				emit_addr(source)*/
        _47emit_addr(_source_51876);

        /** emit.e:811				last_op = op*/
        _47last_op_51829 = _op_51870;
L16: 

        /** emit.e:814			assignable = FALSE*/
        _47assignable_50950 = _13FALSE_450;

        /** emit.e:815			emit_addr(target)*/
        _47emit_addr(_target_51877);

        /** emit.e:817			if length(temp) then*/
        if (IS_SEQUENCE(_temp_51897)){
                _26550 = SEQ_PTR(_temp_51897)->length;
        }
        else {
            _26550 = 1;
        }
        if (_26550 == 0)
        {
            _26550 = NOVALUE;
            goto L1B; // [760] 792
        }
        else{
            _26550 = NOVALUE;
        }

        /** emit.e:819				for i = 1 to length( temp ) do*/
        if (IS_SEQUENCE(_temp_51897)){
                _26551 = SEQ_PTR(_temp_51897)->length;
        }
        else {
            _26551 = 1;
        }
        {
            object _i_52043;
            _i_52043 = 1LL;
L1C: 
            if (_i_52043 > _26551){
                goto L1D; // [768] 791
            }

            /** emit.e:820					flush_temp( temp[i] )*/
            _2 = (object)SEQ_PTR(_temp_51897);
            _26552 = (object)*(((s1_ptr)_2)->base + _i_52043);
            Ref(_26552);
            _47flush_temp(_26552);
            _26552 = NOVALUE;

            /** emit.e:821				end for*/
            _i_52043 = _i_52043 + 1LL;
            goto L1C; // [786] 775
L1D: 
            ;
        }
L1B: 
        DeRef(_temp_51897);
        _temp_51897 = NOVALUE;
        goto LC; // [794] 7739

        /** emit.e:824		case RHS_SUBS then*/
        case 25:

        /** emit.e:825			b = Pop() -- subscript*/
        _b_51873 = _47Pop();
        if (!IS_ATOM_INT(_b_51873)) {
            _1 = (object)(DBL_PTR(_b_51873)->dbl);
            DeRefDS(_b_51873);
            _b_51873 = _1;
        }

        /** emit.e:826			c = Pop() -- sequence*/
        _c_51874 = _47Pop();
        if (!IS_ATOM_INT(_c_51874)) {
            _1 = (object)(DBL_PTR(_c_51874)->dbl);
            DeRefDS(_c_51874);
            _c_51874 = _1;
        }

        /** emit.e:827			target = NewTempSym() -- target*/
        _target_51877 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_target_51877)) {
            _1 = (object)(DBL_PTR(_target_51877)->dbl);
            DeRefDS(_target_51877);
            _target_51877 = _1;
        }

        /** emit.e:828			if c < 0 or length(SymTab[c]) < S_VTYPE or SymTab[c][S_VTYPE] < 0 then -- forward reference*/
        _26556 = (_c_51874 < 0LL);
        if (_26556 != 0) {
            _26557 = 1;
            goto L1E; // [828] 851
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26558 = (object)*(((s1_ptr)_2)->base + _c_51874);
        if (IS_SEQUENCE(_26558)){
                _26559 = SEQ_PTR(_26558)->length;
        }
        else {
            _26559 = 1;
        }
        _26558 = NOVALUE;
        _26560 = (_26559 < 15LL);
        _26559 = NOVALUE;
        _26557 = (_26560 != 0);
L1E: 
        if (_26557 != 0) {
            goto L1F; // [851] 876
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26562 = (object)*(((s1_ptr)_2)->base + _c_51874);
        _2 = (object)SEQ_PTR(_26562);
        _26563 = (object)*(((s1_ptr)_2)->base + 15LL);
        _26562 = NOVALUE;
        if (IS_ATOM_INT(_26563)) {
            _26564 = (_26563 < 0LL);
        }
        else {
            _26564 = binary_op(LESS, _26563, 0LL);
        }
        _26563 = NOVALUE;
        if (_26564 == 0) {
            DeRef(_26564);
            _26564 = NOVALUE;
            goto L20; // [872] 888
        }
        else {
            if (!IS_ATOM_INT(_26564) && DBL_PTR(_26564)->dbl == 0.0){
                DeRef(_26564);
                _26564 = NOVALUE;
                goto L20; // [872] 888
            }
            DeRef(_26564);
            _26564 = NOVALUE;
        }
        DeRef(_26564);
        _26564 = NOVALUE;
L1F: 

        /** emit.e:830				op = RHS_SUBS_CHECK*/
        _op_51870 = 92LL;
        goto L21; // [885] 1049
L20: 

        /** emit.e:831			elsif SymTab[c][S_MODE] = M_NORMAL then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26565 = (object)*(((s1_ptr)_2)->base + _c_51874);
        _2 = (object)SEQ_PTR(_26565);
        _26566 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26565 = NOVALUE;
        if (binary_op_a(NOTEQ, _26566, 1LL)){
            _26566 = NOVALUE;
            goto L22; // [904] 991
        }
        _26566 = NOVALUE;

        /** emit.e:832				if SymTab[c][S_VTYPE] != sequence_type and*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26568 = (object)*(((s1_ptr)_2)->base + _c_51874);
        _2 = (object)SEQ_PTR(_26568);
        _26569 = (object)*(((s1_ptr)_2)->base + 15LL);
        _26568 = NOVALUE;
        if (IS_ATOM_INT(_26569)) {
            _26570 = (_26569 != _54sequence_type_46780);
        }
        else {
            _26570 = binary_op(NOTEQ, _26569, _54sequence_type_46780);
        }
        _26569 = NOVALUE;
        if (IS_ATOM_INT(_26570)) {
            if (_26570 == 0) {
                goto L21; // [928] 1049
            }
        }
        else {
            if (DBL_PTR(_26570)->dbl == 0.0) {
                goto L21; // [928] 1049
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26572 = (object)*(((s1_ptr)_2)->base + _c_51874);
        _2 = (object)SEQ_PTR(_26572);
        _26573 = (object)*(((s1_ptr)_2)->base + 15LL);
        _26572 = NOVALUE;
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!IS_ATOM_INT(_26573)){
            _26574 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_26573)->dbl));
        }
        else{
            _26574 = (object)*(((s1_ptr)_2)->base + _26573);
        }
        _2 = (object)SEQ_PTR(_26574);
        _26575 = (object)*(((s1_ptr)_2)->base + 2LL);
        _26574 = NOVALUE;
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!IS_ATOM_INT(_26575)){
            _26576 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_26575)->dbl));
        }
        else{
            _26576 = (object)*(((s1_ptr)_2)->base + _26575);
        }
        _2 = (object)SEQ_PTR(_26576);
        _26577 = (object)*(((s1_ptr)_2)->base + 15LL);
        _26576 = NOVALUE;
        if (IS_ATOM_INT(_26577)) {
            _26578 = (_26577 != _54sequence_type_46780);
        }
        else {
            _26578 = binary_op(NOTEQ, _26577, _54sequence_type_46780);
        }
        _26577 = NOVALUE;
        if (_26578 == 0) {
            DeRef(_26578);
            _26578 = NOVALUE;
            goto L21; // [975] 1049
        }
        else {
            if (!IS_ATOM_INT(_26578) && DBL_PTR(_26578)->dbl == 0.0){
                DeRef(_26578);
                _26578 = NOVALUE;
                goto L21; // [975] 1049
            }
            DeRef(_26578);
            _26578 = NOVALUE;
        }
        DeRef(_26578);
        _26578 = NOVALUE;

        /** emit.e:835					op = RHS_SUBS_CHECK*/
        _op_51870 = 92LL;
        goto L21; // [988] 1049
L22: 

        /** emit.e:837			elsif SymTab[c][S_MODE] != M_CONSTANT or*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26579 = (object)*(((s1_ptr)_2)->base + _c_51874);
        _2 = (object)SEQ_PTR(_26579);
        _26580 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26579 = NOVALUE;
        if (IS_ATOM_INT(_26580)) {
            _26581 = (_26580 != 2LL);
        }
        else {
            _26581 = binary_op(NOTEQ, _26580, 2LL);
        }
        _26580 = NOVALUE;
        if (IS_ATOM_INT(_26581)) {
            if (_26581 != 0) {
                goto L23; // [1011] 1038
            }
        }
        else {
            if (DBL_PTR(_26581)->dbl != 0.0) {
                goto L23; // [1011] 1038
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26583 = (object)*(((s1_ptr)_2)->base + _c_51874);
        _2 = (object)SEQ_PTR(_26583);
        _26584 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26583 = NOVALUE;
        _26585 = IS_SEQUENCE(_26584);
        _26584 = NOVALUE;
        _26586 = (_26585 == 0);
        _26585 = NOVALUE;
        if (_26586 == 0)
        {
            DeRef(_26586);
            _26586 = NOVALUE;
            goto L24; // [1034] 1048
        }
        else{
            DeRef(_26586);
            _26586 = NOVALUE;
        }
L23: 

        /** emit.e:839				op = RHS_SUBS_CHECK*/
        _op_51870 = 92LL;
L24: 
L21: 

        /** emit.e:841			emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:842			emit_addr(c)*/
        _47emit_addr(_c_51874);

        /** emit.e:843			emit_addr(b)*/
        _47emit_addr(_b_51873);

        /** emit.e:844			assignable = TRUE*/
        _47assignable_50950 = _13TRUE_452;

        /** emit.e:845			Push(target)*/
        _47Push(_target_51877);

        /** emit.e:846			emit_addr(target)*/
        _47emit_addr(_target_51877);

        /** emit.e:847			emit_temp(target, NEW_REFERENCE)*/
        _47emit_temp(_target_51877, 1LL);

        /** emit.e:848			current_sequence = append(current_sequence, target)*/
        Append(&_47current_sequence_50940, _47current_sequence_50940, _target_51877);

        /** emit.e:849			flush_temp( Code[$-2] )*/
        if (IS_SEQUENCE(_36Code_21531)){
                _26588 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26588 = 1;
        }
        _26589 = _26588 - 2LL;
        _26588 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21531);
        _26590 = (object)*(((s1_ptr)_2)->base + _26589);
        Ref(_26590);
        _47flush_temp(_26590);
        _26590 = NOVALUE;
        goto LC; // [1113] 7739

        /** emit.e:851		case PROC then -- procedure, function and type calls*/
        case 27:

        /** emit.e:853			assignable = FALSE -- assume for now*/
        _47assignable_50950 = _13FALSE_450;

        /** emit.e:854			subsym = op_info1*/
        _subsym_51878 = _47op_info1_50932;

        /** emit.e:855			n = SymTab[subsym][S_NUM_ARGS]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26591 = (object)*(((s1_ptr)_2)->base + _subsym_51878);
        _2 = (object)SEQ_PTR(_26591);
        if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
            _n_51883 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
        }
        else{
            _n_51883 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
        }
        if (!IS_ATOM_INT(_n_51883)){
            _n_51883 = (object)DBL_PTR(_n_51883)->dbl;
        }
        _26591 = NOVALUE;

        /** emit.e:857			if subsym = CurrentSub then*/
        if (_subsym_51878 != _36CurrentSub_21447)
        goto L25; // [1155] 1340

        /** emit.e:860				for i = cgi-n+1 to cgi do*/
        _26594 = _47cgi_50948 - _n_51883;
        if ((object)((uintptr_t)_26594 +(uintptr_t) HIGH_BITS) >= 0){
            _26594 = NewDouble((eudouble)_26594);
        }
        if (IS_ATOM_INT(_26594)) {
            _26595 = _26594 + 1;
            if (_26595 > MAXINT){
                _26595 = NewDouble((eudouble)_26595);
            }
        }
        else
        _26595 = binary_op(PLUS, 1, _26594);
        DeRef(_26594);
        _26594 = NOVALUE;
        _26596 = _47cgi_50948;
        {
            object _i_52129;
            Ref(_26595);
            _i_52129 = _26595;
L26: 
            if (binary_op_a(GREATER, _i_52129, _26596)){
                goto L27; // [1176] 1339
            }

            /** emit.e:861					if cg_stack[i] > 0 then -- if it's a forward reference, it's not a private*/
            _2 = (object)SEQ_PTR(_47cg_stack_50947);
            if (!IS_ATOM_INT(_i_52129)){
                _26597 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52129)->dbl));
            }
            else{
                _26597 = (object)*(((s1_ptr)_2)->base + _i_52129);
            }
            if (binary_op_a(LESSEQ, _26597, 0LL)){
                _26597 = NOVALUE;
                goto L28; // [1191] 1332
            }
            _26597 = NOVALUE;

            /** emit.e:862						if SymTab[cg_stack[i]][S_SCOPE] = SC_PRIVATE and*/
            _2 = (object)SEQ_PTR(_47cg_stack_50947);
            if (!IS_ATOM_INT(_i_52129)){
                _26599 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52129)->dbl));
            }
            else{
                _26599 = (object)*(((s1_ptr)_2)->base + _i_52129);
            }
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            if (!IS_ATOM_INT(_26599)){
                _26600 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_26599)->dbl));
            }
            else{
                _26600 = (object)*(((s1_ptr)_2)->base + _26599);
            }
            _2 = (object)SEQ_PTR(_26600);
            _26601 = (object)*(((s1_ptr)_2)->base + 4LL);
            _26600 = NOVALUE;
            if (IS_ATOM_INT(_26601)) {
                _26602 = (_26601 == 3LL);
            }
            else {
                _26602 = binary_op(EQUALS, _26601, 3LL);
            }
            _26601 = NOVALUE;
            if (IS_ATOM_INT(_26602)) {
                if (_26602 == 0) {
                    goto L29; // [1221] 1299
                }
            }
            else {
                if (DBL_PTR(_26602)->dbl == 0.0) {
                    goto L29; // [1221] 1299
                }
            }
            _2 = (object)SEQ_PTR(_47cg_stack_50947);
            if (!IS_ATOM_INT(_i_52129)){
                _26604 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52129)->dbl));
            }
            else{
                _26604 = (object)*(((s1_ptr)_2)->base + _i_52129);
            }
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            if (!IS_ATOM_INT(_26604)){
                _26605 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_26604)->dbl));
            }
            else{
                _26605 = (object)*(((s1_ptr)_2)->base + _26604);
            }
            _2 = (object)SEQ_PTR(_26605);
            _26606 = (object)*(((s1_ptr)_2)->base + 16LL);
            _26605 = NOVALUE;
            if (IS_ATOM_INT(_26606) && IS_ATOM_INT(_i_52129)) {
                _26607 = (_26606 < _i_52129);
            }
            else {
                _26607 = binary_op(LESS, _26606, _i_52129);
            }
            _26606 = NOVALUE;
            if (_26607 == 0) {
                DeRef(_26607);
                _26607 = NOVALUE;
                goto L29; // [1248] 1299
            }
            else {
                if (!IS_ATOM_INT(_26607) && DBL_PTR(_26607)->dbl == 0.0){
                    DeRef(_26607);
                    _26607 = NOVALUE;
                    goto L29; // [1248] 1299
                }
                DeRef(_26607);
                _26607 = NOVALUE;
            }
            DeRef(_26607);
            _26607 = NOVALUE;

            /** emit.e:865							emit_opcode(ASSIGN)*/
            _47emit_opcode(18LL);

            /** emit.e:866							emit_addr(cg_stack[i])*/
            _2 = (object)SEQ_PTR(_47cg_stack_50947);
            if (!IS_ATOM_INT(_i_52129)){
                _26608 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52129)->dbl));
            }
            else{
                _26608 = (object)*(((s1_ptr)_2)->base + _i_52129);
            }
            Ref(_26608);
            _47emit_addr(_26608);
            _26608 = NOVALUE;

            /** emit.e:867							cg_stack[i] = NewTempSym()*/
            _26609 = _54NewTempSym(0LL);
            _2 = (object)SEQ_PTR(_47cg_stack_50947);
            if (!IS_ATOM_INT(_i_52129))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52129)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _i_52129);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _26609;
            if( _1 != _26609 ){
                DeRef(_1);
            }
            _26609 = NOVALUE;

            /** emit.e:868							emit_addr(cg_stack[i])*/
            _2 = (object)SEQ_PTR(_47cg_stack_50947);
            if (!IS_ATOM_INT(_i_52129)){
                _26610 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52129)->dbl));
            }
            else{
                _26610 = (object)*(((s1_ptr)_2)->base + _i_52129);
            }
            Ref(_26610);
            _47emit_addr(_26610);
            _26610 = NOVALUE;

            /** emit.e:869							check_for_temps()*/
            _47check_for_temps();
            goto L2A; // [1296] 1331
L29: 

            /** emit.e:870						elsif sym_mode( cg_stack[i] ) = M_TEMP then*/
            _2 = (object)SEQ_PTR(_47cg_stack_50947);
            if (!IS_ATOM_INT(_i_52129)){
                _26611 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52129)->dbl));
            }
            else{
                _26611 = (object)*(((s1_ptr)_2)->base + _i_52129);
            }
            Ref(_26611);
            _26612 = _54sym_mode(_26611);
            _26611 = NOVALUE;
            if (binary_op_a(NOTEQ, _26612, 3LL)){
                DeRef(_26612);
                _26612 = NOVALUE;
                goto L2B; // [1313] 1330
            }
            DeRef(_26612);
            _26612 = NOVALUE;

            /** emit.e:871							emit_temp( cg_stack[i], NEW_REFERENCE )*/
            _2 = (object)SEQ_PTR(_47cg_stack_50947);
            if (!IS_ATOM_INT(_i_52129)){
                _26614 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52129)->dbl));
            }
            else{
                _26614 = (object)*(((s1_ptr)_2)->base + _i_52129);
            }
            Ref(_26614);
            _47emit_temp(_26614, 1LL);
            _26614 = NOVALUE;
L2B: 
L2A: 
L28: 

            /** emit.e:874				end for*/
            _0 = _i_52129;
            if (IS_ATOM_INT(_i_52129)) {
                _i_52129 = _i_52129 + 1LL;
                if ((object)((uintptr_t)_i_52129 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_52129 = NewDouble((eudouble)_i_52129);
                }
            }
            else {
                _i_52129 = binary_op_a(PLUS, _i_52129, 1LL);
            }
            DeRef(_0);
            goto L26; // [1334] 1183
L27: 
            ;
            DeRef(_i_52129);
        }
L25: 

        /** emit.e:877			if SymTab[subsym][S_DEPRECATED] then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26615 = (object)*(((s1_ptr)_2)->base + _subsym_51878);
        _2 = (object)SEQ_PTR(_26615);
        _26616 = (object)*(((s1_ptr)_2)->base + 30LL);
        _26615 = NOVALUE;
        if (_26616 == 0) {
            _26616 = NOVALUE;
            goto L2C; // [1354] 1383
        }
        else {
            if (!IS_ATOM_INT(_26616) && DBL_PTR(_26616)->dbl == 0.0){
                _26616 = NOVALUE;
                goto L2C; // [1354] 1383
            }
            _26616 = NOVALUE;
        }
        _26616 = NOVALUE;

        /** emit.e:878				Warning(327, deprecated_warning_flag, { SymTab[subsym][S_NAME] })*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26617 = (object)*(((s1_ptr)_2)->base + _subsym_51878);
        _2 = (object)SEQ_PTR(_26617);
        if (!IS_ATOM_INT(_36S_NAME_21076)){
            _26618 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
        }
        else{
            _26618 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
        }
        _26617 = NOVALUE;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_26618);
        ((intptr_t*)_2)[1] = _26618;
        _26619 = MAKE_SEQ(_1);
        _26618 = NOVALUE;
        _50Warning(327LL, 16384LL, _26619);
        _26619 = NOVALUE;
L2C: 

        /** emit.e:881			emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:882			emit_addr(subsym)*/
        _47emit_addr(_subsym_51878);

        /** emit.e:883			for i = cgi-n+1 to cgi do*/
        _26620 = _47cgi_50948 - _n_51883;
        if ((object)((uintptr_t)_26620 +(uintptr_t) HIGH_BITS) >= 0){
            _26620 = NewDouble((eudouble)_26620);
        }
        if (IS_ATOM_INT(_26620)) {
            _26621 = _26620 + 1;
            if (_26621 > MAXINT){
                _26621 = NewDouble((eudouble)_26621);
            }
        }
        else
        _26621 = binary_op(PLUS, 1, _26620);
        DeRef(_26620);
        _26620 = NOVALUE;
        _26622 = _47cgi_50948;
        {
            object _i_52176;
            Ref(_26621);
            _i_52176 = _26621;
L2D: 
            if (binary_op_a(GREATER, _i_52176, _26622)){
                goto L2E; // [1410] 1447
            }

            /** emit.e:884				emit_addr(cg_stack[i])*/
            _2 = (object)SEQ_PTR(_47cg_stack_50947);
            if (!IS_ATOM_INT(_i_52176)){
                _26623 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52176)->dbl));
            }
            else{
                _26623 = (object)*(((s1_ptr)_2)->base + _i_52176);
            }
            Ref(_26623);
            _47emit_addr(_26623);
            _26623 = NOVALUE;

            /** emit.e:885				emit_temp( cg_stack[i], NEW_REFERENCE )*/
            _2 = (object)SEQ_PTR(_47cg_stack_50947);
            if (!IS_ATOM_INT(_i_52176)){
                _26624 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52176)->dbl));
            }
            else{
                _26624 = (object)*(((s1_ptr)_2)->base + _i_52176);
            }
            Ref(_26624);
            _47emit_temp(_26624, 1LL);
            _26624 = NOVALUE;

            /** emit.e:886			end for*/
            _0 = _i_52176;
            if (IS_ATOM_INT(_i_52176)) {
                _i_52176 = _i_52176 + 1LL;
                if ((object)((uintptr_t)_i_52176 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_52176 = NewDouble((eudouble)_i_52176);
                }
            }
            else {
                _i_52176 = binary_op_a(PLUS, _i_52176, 1LL);
            }
            DeRef(_0);
            goto L2D; // [1442] 1417
L2E: 
            ;
            DeRef(_i_52176);
        }

        /** emit.e:888			cgi -= n*/
        _47cgi_50948 = _47cgi_50948 - _n_51883;

        /** emit.e:890			if SymTab[subsym][S_TOKEN] != PROC then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26626 = (object)*(((s1_ptr)_2)->base + _subsym_51878);
        _2 = (object)SEQ_PTR(_26626);
        if (!IS_ATOM_INT(_36S_TOKEN_21081)){
            _26627 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
        }
        else{
            _26627 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
        }
        _26626 = NOVALUE;
        if (binary_op_a(EQUALS, _26627, 27LL)){
            _26627 = NOVALUE;
            goto LC; // [1471] 7739
        }
        _26627 = NOVALUE;

        /** emit.e:891				assignable = TRUE*/
        _47assignable_50950 = _13TRUE_452;

        /** emit.e:892				c = NewTempSym() -- put final result in temp*/
        _c_51874 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_51874)) {
            _1 = (object)(DBL_PTR(_c_51874)->dbl);
            DeRefDS(_c_51874);
            _c_51874 = _1;
        }

        /** emit.e:893				emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_51874, 1LL);

        /** emit.e:894				Push(c)*/
        _47Push(_c_51874);

        /** emit.e:896				emit_addr(c)*/
        _47emit_addr(_c_51874);
        goto LC; // [1507] 7739

        /** emit.e:900		case PROC_FORWARD, FUNC_FORWARD then*/
        case 195:
        case 196:

        /** emit.e:901			assignable = FALSE -- assume for now*/
        _47assignable_50950 = _13FALSE_450;

        /** emit.e:902			integer real_op*/

        /** emit.e:903			if op = PROC_FORWARD then*/
        if (_op_51870 != 195LL)
        goto L2F; // [1528] 1544

        /** emit.e:904				real_op = PROC*/
        _real_op_52197 = 27LL;
        goto L30; // [1541] 1554
L2F: 

        /** emit.e:906				real_op = FUNC*/
        _real_op_52197 = 501LL;
L30: 

        /** emit.e:908			integer ref*/

        /** emit.e:909			ref = new_forward_reference( real_op, op_info1, real_op )*/
        _ref_52204 = _44new_forward_reference(_real_op_52197, _47op_info1_50932, _real_op_52197);
        if (!IS_ATOM_INT(_ref_52204)) {
            _1 = (object)(DBL_PTR(_ref_52204)->dbl);
            DeRefDS(_ref_52204);
            _ref_52204 = _1;
        }

        /** emit.e:910			n = Pop() -- number of known args*/
        _n_51883 = _47Pop();
        if (!IS_ATOM_INT(_n_51883)) {
            _1 = (object)(DBL_PTR(_n_51883)->dbl);
            DeRefDS(_n_51883);
            _n_51883 = _1;
        }

        /** emit.e:912			emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:913			emit_addr(ref)*/
        _47emit_addr(_ref_52204);

        /** emit.e:914			emit_addr( n ) -- this changes to be the "next" instruction*/
        _47emit_addr(_n_51883);

        /** emit.e:915			for i = cgi-n+1 to cgi do*/
        _26633 = _47cgi_50948 - _n_51883;
        if ((object)((uintptr_t)_26633 +(uintptr_t) HIGH_BITS) >= 0){
            _26633 = NewDouble((eudouble)_26633);
        }
        if (IS_ATOM_INT(_26633)) {
            _26634 = _26633 + 1;
            if (_26634 > MAXINT){
                _26634 = NewDouble((eudouble)_26634);
            }
        }
        else
        _26634 = binary_op(PLUS, 1, _26633);
        DeRef(_26633);
        _26633 = NOVALUE;
        _26635 = _47cgi_50948;
        {
            object _i_52209;
            Ref(_26634);
            _i_52209 = _26634;
L31: 
            if (binary_op_a(GREATER, _i_52209, _26635)){
                goto L32; // [1609] 1646
            }

            /** emit.e:916				emit_addr(cg_stack[i])*/
            _2 = (object)SEQ_PTR(_47cg_stack_50947);
            if (!IS_ATOM_INT(_i_52209)){
                _26636 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52209)->dbl));
            }
            else{
                _26636 = (object)*(((s1_ptr)_2)->base + _i_52209);
            }
            Ref(_26636);
            _47emit_addr(_26636);
            _26636 = NOVALUE;

            /** emit.e:917				emit_temp( cg_stack[i], NEW_REFERENCE )*/
            _2 = (object)SEQ_PTR(_47cg_stack_50947);
            if (!IS_ATOM_INT(_i_52209)){
                _26637 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52209)->dbl));
            }
            else{
                _26637 = (object)*(((s1_ptr)_2)->base + _i_52209);
            }
            Ref(_26637);
            _47emit_temp(_26637, 1LL);
            _26637 = NOVALUE;

            /** emit.e:918			end for*/
            _0 = _i_52209;
            if (IS_ATOM_INT(_i_52209)) {
                _i_52209 = _i_52209 + 1LL;
                if ((object)((uintptr_t)_i_52209 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_52209 = NewDouble((eudouble)_i_52209);
                }
            }
            else {
                _i_52209 = binary_op_a(PLUS, _i_52209, 1LL);
            }
            DeRef(_0);
            goto L31; // [1641] 1616
L32: 
            ;
            DeRef(_i_52209);
        }

        /** emit.e:919			cgi -= n*/
        _47cgi_50948 = _47cgi_50948 - _n_51883;

        /** emit.e:921			if op != PROC_FORWARD then*/
        if (_op_51870 == 195LL)
        goto L33; // [1658] 1694

        /** emit.e:922				assignable = TRUE*/
        _47assignable_50950 = _13TRUE_452;

        /** emit.e:923				c = NewTempSym() -- put final result in temp*/
        _c_51874 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_51874)) {
            _1 = (object)(DBL_PTR(_c_51874)->dbl);
            DeRefDS(_c_51874);
            _c_51874 = _1;
        }

        /** emit.e:924				Push(c)*/
        _47Push(_c_51874);

        /** emit.e:926				emit_addr(c)*/
        _47emit_addr(_c_51874);

        /** emit.e:927				emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_51874, 1LL);
L33: 
        goto LC; // [1696] 7739

        /** emit.e:930		case WARNING then*/
        case 506:

        /** emit.e:931			assignable = FALSE*/
        _47assignable_50950 = _13FALSE_450;

        /** emit.e:932		    a = Pop()*/
        _a_51872 = _47Pop();
        if (!IS_ATOM_INT(_a_51872)) {
            _1 = (object)(DBL_PTR(_a_51872)->dbl);
            DeRefDS(_a_51872);
            _a_51872 = _1;
        }

        /** emit.e:933			Warning(SymTab[a][S_OBJ], custom_warning_flag,"")*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26642 = (object)*(((s1_ptr)_2)->base + _a_51872);
        _2 = (object)SEQ_PTR(_26642);
        _26643 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26642 = NOVALUE;
        Ref(_26643);
        RefDS(_21993);
        _50Warning(_26643, 64LL, _21993);
        _26643 = NOVALUE;
        goto LC; // [1737] 7739

        /** emit.e:935		case INCLUDE_PATHS then*/
        case 507:

        /** emit.e:936			sequence paths*/

        /** emit.e:938			assignable = TRUE*/
        _47assignable_50950 = _13TRUE_452;

        /** emit.e:939		    a = Pop()*/
        _a_51872 = _47Pop();
        if (!IS_ATOM_INT(_a_51872)) {
            _1 = (object)(DBL_PTR(_a_51872)->dbl);
            DeRefDS(_a_51872);
            _a_51872 = _1;
        }

        /** emit.e:940		    emit_opcode(RIGHT_BRACE_N)*/
        _47emit_opcode(31LL);

        /** emit.e:941		    paths = Include_paths(SymTab[a][S_OBJ])*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26645 = (object)*(((s1_ptr)_2)->base + _a_51872);
        _2 = (object)SEQ_PTR(_26645);
        _26646 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26645 = NOVALUE;
        Ref(_26646);
        _0 = _paths_52234;
        _paths_52234 = _48Include_paths(_26646);
        DeRef(_0);
        _26646 = NOVALUE;

        /** emit.e:942		    emit(length(paths))*/
        if (IS_SEQUENCE(_paths_52234)){
                _26648 = SEQ_PTR(_paths_52234)->length;
        }
        else {
            _26648 = 1;
        }
        _47emit(_26648);
        _26648 = NOVALUE;

        /** emit.e:943		    for i=length(paths) to 1 by -1 do*/
        if (IS_SEQUENCE(_paths_52234)){
                _26649 = SEQ_PTR(_paths_52234)->length;
        }
        else {
            _26649 = 1;
        }
        {
            object _i_52246;
            _i_52246 = _26649;
L34: 
            if (_i_52246 < 1LL){
                goto L35; // [1799] 1830
            }

            /** emit.e:944		        c = NewStringSym(paths[i])*/
            _2 = (object)SEQ_PTR(_paths_52234);
            _26650 = (object)*(((s1_ptr)_2)->base + _i_52246);
            Ref(_26650);
            _c_51874 = _54NewStringSym(_26650);
            _26650 = NOVALUE;
            if (!IS_ATOM_INT(_c_51874)) {
                _1 = (object)(DBL_PTR(_c_51874)->dbl);
                DeRefDS(_c_51874);
                _c_51874 = _1;
            }

            /** emit.e:945		        emit_addr(c)*/
            _47emit_addr(_c_51874);

            /** emit.e:946		    end for*/
            _i_52246 = _i_52246 + -1LL;
            goto L34; // [1825] 1806
L35: 
            ;
        }

        /** emit.e:947		    b = NewTempSym()*/
        _b_51873 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_b_51873)) {
            _1 = (object)(DBL_PTR(_b_51873)->dbl);
            DeRefDS(_b_51873);
            _b_51873 = _1;
        }

        /** emit.e:948			emit_temp(b, NEW_REFERENCE)*/
        _47emit_temp(_b_51873, 1LL);

        /** emit.e:949		    Push(b)*/
        _47Push(_b_51873);

        /** emit.e:950		    emit_addr(b)*/
        _47emit_addr(_b_51873);

        /** emit.e:951			last_op = RIGHT_BRACE_N*/
        _47last_op_51829 = 31LL;

        /** emit.e:952			op = last_op*/
        _op_51870 = 31LL;
        DeRef(_paths_52234);
        _paths_52234 = NOVALUE;
        goto LC; // [1872] 7739

        /** emit.e:955		case NOP1, NOP2, NOPWHILE, PRIVATE_INIT_CHECK, GLOBAL_INIT_CHECK,*/
        case 159:
        case 110:
        case 158:
        case 30:
        case 109:
        case 58:
        case 59:
        case 61:
        case 184:
        case 22:
        case 23:
        case 188:
        case 189:
        case 88:
        case 43:
        case 90:
        case 89:
        case 87:
        case 135:
        case 156:
        case 169:
        case 175:
        case 174:
        case 187:
        case 210:
        case 211:

        /** emit.e:961			emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:962			assignable = FALSE*/
        _47assignable_50950 = _13FALSE_450;

        /** emit.e:963			if op = UPDATE_GLOBALS then*/
        if (_op_51870 != 89LL)
        goto LC; // [1944] 7739

        /** emit.e:964				last_op = last_op_backup*/
        _47last_op_51829 = _last_op_backup_51888;

        /** emit.e:965				last_pc = last_pc_backup*/
        _47last_pc_51830 = _last_pc_backup_51887;
        goto LC; // [1959] 7739

        /** emit.e:969		case IF, WHILE then*/
        case 20:
        case 47:

        /** emit.e:970			a = Pop()*/
        _a_51872 = _47Pop();
        if (!IS_ATOM_INT(_a_51872)) {
            _1 = (object)(DBL_PTR(_a_51872)->dbl);
            DeRefDS(_a_51872);
            _a_51872 = _1;
        }

        /** emit.e:971			assignable = FALSE*/
        _47assignable_50950 = _13FALSE_450;

        /** emit.e:973			if previous_op >= LESS and previous_op <= NOT then*/
        _26655 = (_36previous_op_21541 >= 1LL);
        if (_26655 == 0) {
            goto L36; // [1991] 2283
        }
        _26657 = (_36previous_op_21541 <= 7LL);
        if (_26657 == 0)
        {
            DeRef(_26657);
            _26657 = NOVALUE;
            goto L36; // [2004] 2283
        }
        else{
            DeRef(_26657);
            _26657 = NOVALUE;
        }

        /** emit.e:974				clear_temp( Code[$] )*/
        if (IS_SEQUENCE(_36Code_21531)){
                _26658 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26658 = 1;
        }
        _2 = (object)SEQ_PTR(_36Code_21531);
        _26659 = (object)*(((s1_ptr)_2)->base + _26658);
        Ref(_26659);
        _47clear_temp(_26659);
        _26659 = NOVALUE;

        /** emit.e:975				Code = Code[1..$-1]*/
        if (IS_SEQUENCE(_36Code_21531)){
                _26660 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26660 = 1;
        }
        _26661 = _26660 - 1LL;
        _26660 = NOVALUE;
        rhs_slice_target = (object_ptr)&_36Code_21531;
        RHS_Slice(_36Code_21531, 1LL, _26661);

        /** emit.e:976				if previous_op = NOT then*/
        if (_36previous_op_21541 != 7LL)
        goto L37; // [2045] 2125

        /** emit.e:977					op = NOT_IFW*/
        _op_51870 = 108LL;

        /** emit.e:978					backpatch(length(Code) - 1, op)*/
        if (IS_SEQUENCE(_36Code_21531)){
                _26664 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26664 = 1;
        }
        _26665 = _26664 - 1LL;
        _26664 = NOVALUE;
        _47backpatch(_26665, 108LL);
        _26665 = NOVALUE;

        /** emit.e:979					sequence if_code = Code[$-1..$]*/
        if (IS_SEQUENCE(_36Code_21531)){
                _26666 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26666 = 1;
        }
        _26667 = _26666 - 1LL;
        _26666 = NOVALUE;
        if (IS_SEQUENCE(_36Code_21531)){
                _26668 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26668 = 1;
        }
        rhs_slice_target = (object_ptr)&_if_code_52314;
        RHS_Slice(_36Code_21531, _26667, _26668);

        /** emit.e:980					Code = Code[1..$-2]*/
        if (IS_SEQUENCE(_36Code_21531)){
                _26670 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26670 = 1;
        }
        _26671 = _26670 - 2LL;
        _26670 = NOVALUE;
        rhs_slice_target = (object_ptr)&_36Code_21531;
        RHS_Slice(_36Code_21531, 1LL, _26671);

        /** emit.e:981					Code &= if_code*/
        Concat((object_ptr)&_36Code_21531, _36Code_21531, _if_code_52314);
        DeRefDS(_if_code_52314);
        _if_code_52314 = NOVALUE;
        goto L38; // [2122] 2270
L37: 

        /** emit.e:983					if IsInteger(Code[$-1]) and IsInteger(Code[$]) then*/
        if (IS_SEQUENCE(_36Code_21531)){
                _26674 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26674 = 1;
        }
        _26675 = _26674 - 1LL;
        _26674 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21531);
        _26676 = (object)*(((s1_ptr)_2)->base + _26675);
        Ref(_26676);
        _26677 = _47IsInteger(_26676);
        _26676 = NOVALUE;
        if (IS_ATOM_INT(_26677)) {
            if (_26677 == 0) {
                goto L39; // [2144] 2186
            }
        }
        else {
            if (DBL_PTR(_26677)->dbl == 0.0) {
                goto L39; // [2144] 2186
            }
        }
        if (IS_SEQUENCE(_36Code_21531)){
                _26679 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26679 = 1;
        }
        _2 = (object)SEQ_PTR(_36Code_21531);
        _26680 = (object)*(((s1_ptr)_2)->base + _26679);
        Ref(_26680);
        _26681 = _47IsInteger(_26680);
        _26680 = NOVALUE;
        if (_26681 == 0) {
            DeRef(_26681);
            _26681 = NOVALUE;
            goto L39; // [2162] 2186
        }
        else {
            if (!IS_ATOM_INT(_26681) && DBL_PTR(_26681)->dbl == 0.0){
                DeRef(_26681);
                _26681 = NOVALUE;
                goto L39; // [2162] 2186
            }
            DeRef(_26681);
            _26681 = NOVALUE;
        }
        DeRef(_26681);
        _26681 = NOVALUE;

        /** emit.e:984						op = previous_op + LESS_IFW_I - LESS*/
        _26682 = _36previous_op_21541 + 119LL;
        if ((object)((uintptr_t)_26682 + (uintptr_t)HIGH_BITS) >= 0){
            _26682 = NewDouble((eudouble)_26682);
        }
        if (IS_ATOM_INT(_26682)) {
            _op_51870 = _26682 - 1LL;
        }
        else {
            _op_51870 = NewDouble(DBL_PTR(_26682)->dbl - (eudouble)1LL);
        }
        DeRef(_26682);
        _26682 = NOVALUE;
        if (!IS_ATOM_INT(_op_51870)) {
            _1 = (object)(DBL_PTR(_op_51870)->dbl);
            DeRefDS(_op_51870);
            _op_51870 = _1;
        }
        goto L3A; // [2183] 2205
L39: 

        /** emit.e:986						op = previous_op + LESS_IFW - LESS*/
        _26684 = _36previous_op_21541 + 102LL;
        if ((object)((uintptr_t)_26684 + (uintptr_t)HIGH_BITS) >= 0){
            _26684 = NewDouble((eudouble)_26684);
        }
        if (IS_ATOM_INT(_26684)) {
            _op_51870 = _26684 - 1LL;
        }
        else {
            _op_51870 = NewDouble(DBL_PTR(_26684)->dbl - (eudouble)1LL);
        }
        DeRef(_26684);
        _26684 = NOVALUE;
        if (!IS_ATOM_INT(_op_51870)) {
            _1 = (object)(DBL_PTR(_op_51870)->dbl);
            DeRefDS(_op_51870);
            _op_51870 = _1;
        }
L3A: 

        /** emit.e:989					backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_36Code_21531)){
                _26686 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26686 = 1;
        }
        _26687 = _26686 - 2LL;
        _26686 = NOVALUE;
        _47backpatch(_26687, _op_51870);
        _26687 = NOVALUE;

        /** emit.e:991					sequence if_code = Code[$-2..$]*/
        if (IS_SEQUENCE(_36Code_21531)){
                _26688 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26688 = 1;
        }
        _26689 = _26688 - 2LL;
        _26688 = NOVALUE;
        if (IS_SEQUENCE(_36Code_21531)){
                _26690 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26690 = 1;
        }
        rhs_slice_target = (object_ptr)&_if_code_52353;
        RHS_Slice(_36Code_21531, _26689, _26690);

        /** emit.e:992					Code = Code[1..$-3]*/
        if (IS_SEQUENCE(_36Code_21531)){
                _26692 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26692 = 1;
        }
        _26693 = _26692 - 3LL;
        _26692 = NOVALUE;
        rhs_slice_target = (object_ptr)&_36Code_21531;
        RHS_Slice(_36Code_21531, 1LL, _26693);

        /** emit.e:993					Code &= if_code*/
        Concat((object_ptr)&_36Code_21531, _36Code_21531, _if_code_52353);
        DeRefDS(_if_code_52353);
        _if_code_52353 = NOVALUE;
L38: 

        /** emit.e:997				last_pc = last_pc_backup*/
        _47last_pc_51830 = _last_pc_backup_51887;

        /** emit.e:998				last_op = op*/
        _47last_op_51829 = _op_51870;
        goto LC; // [2280] 7739
L36: 

        /** emit.e:1000			elsif op = WHILE and*/
        _26696 = (_op_51870 == 47LL);
        if (_26696 == 0) {
            _26697 = 0;
            goto L3B; // [2291] 2303
        }
        _26698 = (_a_51872 > 0LL);
        _26697 = (_26698 != 0);
L3B: 
        if (_26697 == 0) {
            _26699 = 0;
            goto L3C; // [2303] 2329
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26700 = (object)*(((s1_ptr)_2)->base + _a_51872);
        _2 = (object)SEQ_PTR(_26700);
        _26701 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26700 = NOVALUE;
        if (IS_ATOM_INT(_26701)) {
            _26702 = (_26701 == 2LL);
        }
        else {
            _26702 = binary_op(EQUALS, _26701, 2LL);
        }
        _26701 = NOVALUE;
        if (IS_ATOM_INT(_26702))
        _26699 = (_26702 != 0);
        else
        _26699 = DBL_PTR(_26702)->dbl != 0.0;
L3C: 
        if (_26699 == 0) {
            _26703 = 0;
            goto L3D; // [2329] 2352
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26704 = (object)*(((s1_ptr)_2)->base + _a_51872);
        _2 = (object)SEQ_PTR(_26704);
        _26705 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26704 = NOVALUE;
        if (IS_ATOM_INT(_26705))
        _26706 = 1;
        else if (IS_ATOM_DBL(_26705))
        _26706 = IS_ATOM_INT(DoubleToInt(_26705));
        else
        _26706 = 0;
        _26705 = NOVALUE;
        _26703 = (_26706 != 0);
L3D: 
        if (_26703 == 0) {
            goto L3E; // [2352] 2401
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26708 = (object)*(((s1_ptr)_2)->base + _a_51872);
        _2 = (object)SEQ_PTR(_26708);
        _26709 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26708 = NOVALUE;
        if (_26709 == 0LL)
        _26710 = 1;
        else if (IS_ATOM_INT(_26709) && IS_ATOM_INT(0LL))
        _26710 = 0;
        else
        _26710 = (compare(_26709, 0LL) == 0);
        _26709 = NOVALUE;
        _26711 = (_26710 == 0);
        _26710 = NOVALUE;
        if (_26711 == 0)
        {
            DeRef(_26711);
            _26711 = NOVALUE;
            goto L3E; // [2376] 2401
        }
        else{
            DeRef(_26711);
            _26711 = NOVALUE;
        }

        /** emit.e:1005				optimized_while = TRUE   -- while TRUE ... emit nothing*/
        _47optimized_while_50934 = _13TRUE_452;

        /** emit.e:1006				last_pc = last_pc_backup*/
        _47last_pc_51830 = _last_pc_backup_51887;

        /** emit.e:1007				last_op = last_op_backup*/
        _47last_op_51829 = _last_op_backup_51888;
        goto LC; // [2398] 7739
L3E: 

        /** emit.e:1009				flush_temps( {a} )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _a_51872;
        _26712 = MAKE_SEQ(_1);
        _47flush_temps(_26712);
        _26712 = NOVALUE;

        /** emit.e:1010				emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1011				emit_addr(a)*/
        _47emit_addr(_a_51872);
        goto LC; // [2421] 7739

        /** emit.e:1016		case INTEGER_CHECK then*/
        case 96:

        /** emit.e:1017			assignable = FALSE*/
        _47assignable_50950 = _13FALSE_450;

        /** emit.e:1018			if previous_op = ASSIGN then*/
        if (_36previous_op_21541 != 18LL)
        goto L3F; // [2440] 2499

        /** emit.e:1019				c = Code[$-1]*/
        if (IS_SEQUENCE(_36Code_21531)){
                _26714 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26714 = 1;
        }
        _26715 = _26714 - 1LL;
        _26714 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21531);
        _c_51874 = (object)*(((s1_ptr)_2)->base + _26715);
        if (!IS_ATOM_INT(_c_51874)){
            _c_51874 = (object)DBL_PTR(_c_51874)->dbl;
        }

        /** emit.e:1020				if not IsInteger(c) then*/
        _26717 = _47IsInteger(_c_51874);
        if (IS_ATOM_INT(_26717)) {
            if (_26717 != 0){
                DeRef(_26717);
                _26717 = NOVALUE;
                goto L40; // [2467] 2485
            }
        }
        else {
            if (DBL_PTR(_26717)->dbl != 0.0){
                DeRef(_26717);
                _26717 = NOVALUE;
                goto L40; // [2467] 2485
            }
        }
        DeRef(_26717);
        _26717 = NOVALUE;

        /** emit.e:1021					emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1022					emit_addr(op_info1)*/
        _47emit_addr(_47op_info1_50932);
        goto L41; // [2482] 2556
L40: 

        /** emit.e:1024					last_op = last_op_backup*/
        _47last_op_51829 = _last_op_backup_51888;

        /** emit.e:1025					last_pc = last_pc_backup*/
        _47last_pc_51830 = _last_pc_backup_51887;
        goto L41; // [2496] 2556
L3F: 

        /** emit.e:1027			elsif previous_op = -1 or*/
        _26719 = (_36previous_op_21541 == -1LL);
        if (_26719 != 0) {
            goto L42; // [2507] 2530
        }
        _2 = (object)SEQ_PTR(_47op_result_51548);
        _26721 = (object)*(((s1_ptr)_2)->base + _36previous_op_21541);
        _26722 = (_26721 != 1LL);
        _26721 = NOVALUE;
        if (_26722 == 0)
        {
            DeRef(_26722);
            _26722 = NOVALUE;
            goto L43; // [2526] 2545
        }
        else{
            DeRef(_26722);
            _26722 = NOVALUE;
        }
L42: 

        /** emit.e:1029				emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1030				emit_addr(op_info1)*/
        _47emit_addr(_47op_info1_50932);
        goto L41; // [2542] 2556
L43: 

        /** emit.e:1032				last_op = last_op_backup*/
        _47last_op_51829 = _last_op_backup_51888;

        /** emit.e:1033				last_pc = last_pc_backup*/
        _47last_pc_51830 = _last_pc_backup_51887;
L41: 

        /** emit.e:1035			clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_36Code_21531)){
                _26723 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26723 = 1;
        }
        _26724 = _26723 - 1LL;
        _26723 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21531);
        _26725 = (object)*(((s1_ptr)_2)->base + _26724);
        Ref(_26725);
        _47clear_temp(_26725);
        _26725 = NOVALUE;
        goto LC; // [2574] 7739

        /** emit.e:1037		case SEQUENCE_CHECK then*/
        case 97:

        /** emit.e:1038			assignable = FALSE*/
        _47assignable_50950 = _13FALSE_450;

        /** emit.e:1039			if previous_op = ASSIGN then*/
        if (_36previous_op_21541 != 18LL)
        goto L44; // [2593] 2720

        /** emit.e:1040				c = Code[$-1]*/
        if (IS_SEQUENCE(_36Code_21531)){
                _26727 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26727 = 1;
        }
        _26728 = _26727 - 1LL;
        _26727 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21531);
        _c_51874 = (object)*(((s1_ptr)_2)->base + _26728);
        if (!IS_ATOM_INT(_c_51874)){
            _c_51874 = (object)DBL_PTR(_c_51874)->dbl;
        }

        /** emit.e:1041				if c < 1 or*/
        _26730 = (_c_51874 < 1LL);
        if (_26730 != 0) {
            _26731 = 1;
            goto L45; // [2620] 2646
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26732 = (object)*(((s1_ptr)_2)->base + _c_51874);
        _2 = (object)SEQ_PTR(_26732);
        _26733 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26732 = NOVALUE;
        if (IS_ATOM_INT(_26733)) {
            _26734 = (_26733 != 2LL);
        }
        else {
            _26734 = binary_op(NOTEQ, _26733, 2LL);
        }
        _26733 = NOVALUE;
        if (IS_ATOM_INT(_26734))
        _26731 = (_26734 != 0);
        else
        _26731 = DBL_PTR(_26734)->dbl != 0.0;
L45: 
        if (_26731 != 0) {
            goto L46; // [2646] 2673
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26736 = (object)*(((s1_ptr)_2)->base + _c_51874);
        _2 = (object)SEQ_PTR(_26736);
        _26737 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26736 = NOVALUE;
        _26738 = IS_SEQUENCE(_26737);
        _26737 = NOVALUE;
        _26739 = (_26738 == 0);
        _26738 = NOVALUE;
        if (_26739 == 0)
        {
            DeRef(_26739);
            _26739 = NOVALUE;
            goto L47; // [2669] 2706
        }
        else{
            DeRef(_26739);
            _26739 = NOVALUE;
        }
L46: 

        /** emit.e:1044					emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1045					emit_addr(op_info1)*/
        _47emit_addr(_47op_info1_50932);

        /** emit.e:1046					clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_36Code_21531)){
                _26740 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26740 = 1;
        }
        _26741 = _26740 - 1LL;
        _26740 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21531);
        _26742 = (object)*(((s1_ptr)_2)->base + _26741);
        Ref(_26742);
        _47clear_temp(_26742);
        _26742 = NOVALUE;
        goto LC; // [2703] 7739
L47: 

        /** emit.e:1048					last_op = last_op_backup*/
        _47last_op_51829 = _last_op_backup_51888;

        /** emit.e:1049					last_pc = last_pc_backup*/
        _47last_pc_51830 = _last_pc_backup_51887;
        goto LC; // [2717] 7739
L44: 

        /** emit.e:1051			elsif previous_op = -1 or op_result[previous_op] != T_SEQUENCE then*/
        _26743 = (_36previous_op_21541 == -1LL);
        if (_26743 != 0) {
            goto L48; // [2728] 2751
        }
        _2 = (object)SEQ_PTR(_47op_result_51548);
        _26745 = (object)*(((s1_ptr)_2)->base + _36previous_op_21541);
        _26746 = (_26745 != 2LL);
        _26745 = NOVALUE;
        if (_26746 == 0)
        {
            DeRef(_26746);
            _26746 = NOVALUE;
            goto L49; // [2747] 2784
        }
        else{
            DeRef(_26746);
            _26746 = NOVALUE;
        }
L48: 

        /** emit.e:1052				emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1053				emit_addr(op_info1)*/
        _47emit_addr(_47op_info1_50932);

        /** emit.e:1054				clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_36Code_21531)){
                _26747 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26747 = 1;
        }
        _26748 = _26747 - 1LL;
        _26747 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21531);
        _26749 = (object)*(((s1_ptr)_2)->base + _26748);
        Ref(_26749);
        _47clear_temp(_26749);
        _26749 = NOVALUE;
        goto LC; // [2781] 7739
L49: 

        /** emit.e:1056				last_op = last_op_backup*/
        _47last_op_51829 = _last_op_backup_51888;

        /** emit.e:1057				last_pc = last_pc_backup*/
        _47last_pc_51830 = _last_pc_backup_51887;
        goto LC; // [2795] 7739

        /** emit.e:1061		case ATOM_CHECK then*/
        case 101:

        /** emit.e:1062			assignable = FALSE*/
        _47assignable_50950 = _13FALSE_450;

        /** emit.e:1063			if previous_op = ASSIGN then*/
        if (_36previous_op_21541 != 18LL)
        goto L4A; // [2814] 3015

        /** emit.e:1064				c = Code[$-1]*/
        if (IS_SEQUENCE(_36Code_21531)){
                _26751 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26751 = 1;
        }
        _26752 = _26751 - 1LL;
        _26751 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21531);
        _c_51874 = (object)*(((s1_ptr)_2)->base + _26752);
        if (!IS_ATOM_INT(_c_51874)){
            _c_51874 = (object)DBL_PTR(_c_51874)->dbl;
        }

        /** emit.e:1065				if c > 1*/
        _26754 = (_c_51874 > 1LL);
        if (_26754 == 0) {
            goto L4B; // [2841] 2964
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26756 = (object)*(((s1_ptr)_2)->base + _c_51874);
        _2 = (object)SEQ_PTR(_26756);
        _26757 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26756 = NOVALUE;
        if (IS_ATOM_INT(_26757)) {
            _26758 = (_26757 == 2LL);
        }
        else {
            _26758 = binary_op(EQUALS, _26757, 2LL);
        }
        _26757 = NOVALUE;
        if (_26758 == 0) {
            DeRef(_26758);
            _26758 = NOVALUE;
            goto L4B; // [2864] 2964
        }
        else {
            if (!IS_ATOM_INT(_26758) && DBL_PTR(_26758)->dbl == 0.0){
                DeRef(_26758);
                _26758 = NOVALUE;
                goto L4B; // [2864] 2964
            }
            DeRef(_26758);
            _26758 = NOVALUE;
        }
        DeRef(_26758);
        _26758 = NOVALUE;

        /** emit.e:1068					if sequence( SymTab[c][S_OBJ] ) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26759 = (object)*(((s1_ptr)_2)->base + _c_51874);
        _2 = (object)SEQ_PTR(_26759);
        _26760 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26759 = NOVALUE;
        _26761 = IS_SEQUENCE(_26760);
        _26760 = NOVALUE;
        if (_26761 == 0)
        {
            _26761 = NOVALUE;
            goto L4C; // [2884] 2915
        }
        else{
            _26761 = NOVALUE;
        }

        /** emit.e:1070						ThisLine = ExprLine*/
        RefDS(_45ExprLine_57042);
        DeRef(_50ThisLine_49234);
        _50ThisLine_49234 = _45ExprLine_57042;

        /** emit.e:1071						bp = expr_bp*/
        _50bp_49238 = _45expr_bp_57043;

        /** emit.e:1072						CompileErr( TYPE_CHECK_ERROR__ASSIGNING_A_SEQUENCE_TO_AN_ATOM)*/
        RefDS(_21993);
        _50CompileErr(346LL, _21993, 0LL);
        goto L4D; // [2912] 3094
L4C: 

        /** emit.e:1074					elsif SymTab[c][S_OBJ] = NOVALUE then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26762 = (object)*(((s1_ptr)_2)->base + _c_51874);
        _2 = (object)SEQ_PTR(_26762);
        _26763 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26762 = NOVALUE;
        if (binary_op_a(NOTEQ, _26763, _36NOVALUE_21293)){
            _26763 = NOVALUE;
            goto L4E; // [2931] 2950
        }
        _26763 = NOVALUE;

        /** emit.e:1075						emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1076						emit_addr(op_info1)*/
        _47emit_addr(_47op_info1_50932);
        goto L4D; // [2947] 3094
L4E: 

        /** emit.e:1078						last_op = last_op_backup*/
        _47last_op_51829 = _last_op_backup_51888;

        /** emit.e:1079						last_pc = last_pc_backup*/
        _47last_pc_51830 = _last_pc_backup_51887;
        goto L4D; // [2961] 3094
L4B: 

        /** emit.e:1082				elsif c < 1 */
        _26765 = (_c_51874 < 1LL);
        if (_26765 != 0) {
            goto L4F; // [2970] 2986
        }
        _26767 = _47IsInteger(_c_51874);
        if (IS_ATOM_INT(_26767)) {
            _26768 = (_26767 == 0);
        }
        else {
            _26768 = unary_op(NOT, _26767);
        }
        DeRef(_26767);
        _26767 = NOVALUE;
        if (_26768 == 0) {
            DeRef(_26768);
            _26768 = NOVALUE;
            goto L50; // [2982] 3001
        }
        else {
            if (!IS_ATOM_INT(_26768) && DBL_PTR(_26768)->dbl == 0.0){
                DeRef(_26768);
                _26768 = NOVALUE;
                goto L50; // [2982] 3001
            }
            DeRef(_26768);
            _26768 = NOVALUE;
        }
        DeRef(_26768);
        _26768 = NOVALUE;
L4F: 

        /** emit.e:1085					emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1086					emit_addr(op_info1)*/
        _47emit_addr(_47op_info1_50932);
        goto L4D; // [2998] 3094
L50: 

        /** emit.e:1089					last_op = last_op_backup*/
        _47last_op_51829 = _last_op_backup_51888;

        /** emit.e:1090					last_pc = last_pc_backup*/
        _47last_pc_51830 = _last_pc_backup_51887;
        goto L4D; // [3012] 3094
L4A: 

        /** emit.e:1092			elsif previous_op = -1 or*/
        _26769 = (_36previous_op_21541 == -1LL);
        if (_26769 != 0) {
            goto L51; // [3023] 3068
        }
        _2 = (object)SEQ_PTR(_47op_result_51548);
        _26771 = (object)*(((s1_ptr)_2)->base + _36previous_op_21541);
        _26772 = (_26771 != 1LL);
        _26771 = NOVALUE;
        if (_26772 == 0) {
            DeRef(_26773);
            _26773 = 0;
            goto L52; // [3041] 3063
        }
        _2 = (object)SEQ_PTR(_47op_result_51548);
        _26774 = (object)*(((s1_ptr)_2)->base + _36previous_op_21541);
        _26775 = (_26774 != 3LL);
        _26774 = NOVALUE;
        _26773 = (_26775 != 0);
L52: 
        if (_26773 == 0)
        {
            _26773 = NOVALUE;
            goto L53; // [3064] 3083
        }
        else{
            _26773 = NOVALUE;
        }
L51: 

        /** emit.e:1095				emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1096				emit_addr(op_info1)*/
        _47emit_addr(_47op_info1_50932);
        goto L4D; // [3080] 3094
L53: 

        /** emit.e:1098				last_op = last_op_backup*/
        _47last_op_51829 = _last_op_backup_51888;

        /** emit.e:1099				last_pc = last_pc_backup*/
        _47last_pc_51830 = _last_pc_backup_51887;
L4D: 

        /** emit.e:1101			clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_36Code_21531)){
                _26776 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26776 = 1;
        }
        _26777 = _26776 - 1LL;
        _26776 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21531);
        _26778 = (object)*(((s1_ptr)_2)->base + _26777);
        Ref(_26778);
        _47clear_temp(_26778);
        _26778 = NOVALUE;
        goto LC; // [3112] 7739

        /** emit.e:1103		case RIGHT_BRACE_N then*/
        case 31:

        /** emit.e:1105			n = op_info1*/
        _n_51883 = _47op_info1_50932;

        /** emit.e:1107			elements = {}*/
        RefDS(_21993);
        DeRef(_elements_51885);
        _elements_51885 = _21993;

        /** emit.e:1108			for i = 1 to n do*/
        _26779 = _n_51883;
        {
            object _i_52534;
            _i_52534 = 1LL;
L54: 
            if (_i_52534 > _26779){
                goto L55; // [3137] 3160
            }

            /** emit.e:1109				elements = append(elements, Pop())*/
            _26780 = _47Pop();
            Ref(_26780);
            Append(&_elements_51885, _elements_51885, _26780);
            DeRef(_26780);
            _26780 = NOVALUE;

            /** emit.e:1110			end for*/
            _i_52534 = _i_52534 + 1LL;
            goto L54; // [3155] 3144
L55: 
            ;
        }

        /** emit.e:1111			element_vals = good_string(elements)*/
        RefDS(_elements_51885);
        _0 = _element_vals_51886;
        _element_vals_51886 = _47good_string(_elements_51885);
        DeRef(_0);

        /** emit.e:1113			if sequence(element_vals) then*/
        _26783 = IS_SEQUENCE(_element_vals_51886);
        if (_26783 == 0)
        {
            _26783 = NOVALUE;
            goto L56; // [3171] 3202
        }
        else{
            _26783 = NOVALUE;
        }

        /** emit.e:1114				c = NewStringSym(element_vals)  -- make a string literal*/
        Ref(_element_vals_51886);
        _c_51874 = _54NewStringSym(_element_vals_51886);
        if (!IS_ATOM_INT(_c_51874)) {
            _1 = (object)(DBL_PTR(_c_51874)->dbl);
            DeRefDS(_c_51874);
            _c_51874 = _1;
        }

        /** emit.e:1115				assignable = FALSE*/
        _47assignable_50950 = _13FALSE_450;

        /** emit.e:1116				last_op = last_op_backup*/
        _47last_op_51829 = _last_op_backup_51888;

        /** emit.e:1117				last_pc = last_pc_backup*/
        _47last_pc_51830 = _last_pc_backup_51887;
        goto L57; // [3199] 3293
L56: 

        /** emit.e:1119				if n = 2 then*/
        if (_n_51883 != 2LL)
        goto L58; // [3204] 3227

        /** emit.e:1120					emit_opcode(RIGHT_BRACE_2) -- faster op for two items*/
        _47emit_opcode(85LL);

        /** emit.e:1121					last_op = RIGHT_BRACE_2*/
        _47last_op_51829 = 85LL;
        goto L59; // [3224] 3238
L58: 

        /** emit.e:1123					emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1124					emit(n)*/
        _47emit(_n_51883);
L59: 

        /** emit.e:1127				for i = 1 to n do*/
        _26786 = _n_51883;
        {
            object _i_52551;
            _i_52551 = 1LL;
L5A: 
            if (_i_52551 > _26786){
                goto L5B; // [3243] 3266
            }

            /** emit.e:1128					emit_addr(elements[i])*/
            _2 = (object)SEQ_PTR(_elements_51885);
            _26787 = (object)*(((s1_ptr)_2)->base + _i_52551);
            Ref(_26787);
            _47emit_addr(_26787);
            _26787 = NOVALUE;

            /** emit.e:1129				end for*/
            _i_52551 = _i_52551 + 1LL;
            goto L5A; // [3261] 3250
L5B: 
            ;
        }

        /** emit.e:1130				c = NewTempSym()*/
        _c_51874 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_51874)) {
            _1 = (object)(DBL_PTR(_c_51874)->dbl);
            DeRefDS(_c_51874);
            _c_51874 = _1;
        }

        /** emit.e:1131				emit_addr(c)*/
        _47emit_addr(_c_51874);

        /** emit.e:1132				emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_51874, 1LL);

        /** emit.e:1133				assignable = TRUE*/
        _47assignable_50950 = _13TRUE_452;
L57: 

        /** emit.e:1135			Push(c)*/
        _47Push(_c_51874);
        goto LC; // [3298] 7739

        /** emit.e:1138		case ASSIGN_SUBS2,      -- can't change the op*/
        case 148:
        case 16:
        case 162:

        /** emit.e:1141			b = Pop() -- rhs value*/
        _b_51873 = _47Pop();
        if (!IS_ATOM_INT(_b_51873)) {
            _1 = (object)(DBL_PTR(_b_51873)->dbl);
            DeRefDS(_b_51873);
            _b_51873 = _1;
        }

        /** emit.e:1142			a = Pop() -- subscript*/
        _a_51872 = _47Pop();
        if (!IS_ATOM_INT(_a_51872)) {
            _1 = (object)(DBL_PTR(_a_51872)->dbl);
            DeRefDS(_a_51872);
            _a_51872 = _1;
        }

        /** emit.e:1143			c = Pop() -- sequence*/
        _c_51874 = _47Pop();
        if (!IS_ATOM_INT(_c_51874)) {
            _1 = (object)(DBL_PTR(_c_51874)->dbl);
            DeRefDS(_c_51874);
            _c_51874 = _1;
        }

        /** emit.e:1144			if op = ASSIGN_SUBS then*/
        if (_op_51870 != 16LL)
        goto L5C; // [3333] 3525

        /** emit.e:1146				if (previous_op != LHS_SUBS) and*/
        _26793 = (_36previous_op_21541 != 95LL);
        if (_26793 == 0) {
            _26794 = 0;
            goto L5D; // [3347] 3359
        }
        _26795 = (_c_51874 > 0LL);
        _26794 = (_26795 != 0);
L5D: 
        if (_26794 == 0) {
            goto L5E; // [3359] 3497
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26797 = (object)*(((s1_ptr)_2)->base + _c_51874);
        _2 = (object)SEQ_PTR(_26797);
        _26798 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26797 = NOVALUE;
        if (IS_ATOM_INT(_26798)) {
            _26799 = (_26798 != 1LL);
        }
        else {
            _26799 = binary_op(NOTEQ, _26798, 1LL);
        }
        _26798 = NOVALUE;
        if (IS_ATOM_INT(_26799)) {
            if (_26799 != 0) {
                DeRef(_26800);
                _26800 = 1;
                goto L5F; // [3381] 3481
            }
        }
        else {
            if (DBL_PTR(_26799)->dbl != 0.0) {
                DeRef(_26800);
                _26800 = 1;
                goto L5F; // [3381] 3481
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26801 = (object)*(((s1_ptr)_2)->base + _c_51874);
        _2 = (object)SEQ_PTR(_26801);
        _26802 = (object)*(((s1_ptr)_2)->base + 15LL);
        _26801 = NOVALUE;
        if (IS_ATOM_INT(_26802)) {
            _26803 = (_26802 != _54sequence_type_46780);
        }
        else {
            _26803 = binary_op(NOTEQ, _26802, _54sequence_type_46780);
        }
        _26802 = NOVALUE;
        if (IS_ATOM_INT(_26803)) {
            if (_26803 == 0) {
                DeRef(_26804);
                _26804 = 0;
                goto L60; // [3403] 3477
            }
        }
        else {
            if (DBL_PTR(_26803)->dbl == 0.0) {
                DeRef(_26804);
                _26804 = 0;
                goto L60; // [3403] 3477
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26805 = (object)*(((s1_ptr)_2)->base + _c_51874);
        _2 = (object)SEQ_PTR(_26805);
        _26806 = (object)*(((s1_ptr)_2)->base + 15LL);
        _26805 = NOVALUE;
        if (IS_ATOM_INT(_26806)) {
            _26807 = (_26806 > 0LL);
        }
        else {
            _26807 = binary_op(GREATER, _26806, 0LL);
        }
        _26806 = NOVALUE;
        if (IS_ATOM_INT(_26807)) {
            if (_26807 == 0) {
                DeRef(_26808);
                _26808 = 0;
                goto L61; // [3423] 3473
            }
        }
        else {
            if (DBL_PTR(_26807)->dbl == 0.0) {
                DeRef(_26808);
                _26808 = 0;
                goto L61; // [3423] 3473
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26809 = (object)*(((s1_ptr)_2)->base + _c_51874);
        _2 = (object)SEQ_PTR(_26809);
        _26810 = (object)*(((s1_ptr)_2)->base + 15LL);
        _26809 = NOVALUE;
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!IS_ATOM_INT(_26810)){
            _26811 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_26810)->dbl));
        }
        else{
            _26811 = (object)*(((s1_ptr)_2)->base + _26810);
        }
        _2 = (object)SEQ_PTR(_26811);
        _26812 = (object)*(((s1_ptr)_2)->base + 2LL);
        _26811 = NOVALUE;
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!IS_ATOM_INT(_26812)){
            _26813 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_26812)->dbl));
        }
        else{
            _26813 = (object)*(((s1_ptr)_2)->base + _26812);
        }
        _2 = (object)SEQ_PTR(_26813);
        _26814 = (object)*(((s1_ptr)_2)->base + 15LL);
        _26813 = NOVALUE;
        if (IS_ATOM_INT(_26814)) {
            _26815 = (_26814 != _54sequence_type_46780);
        }
        else {
            _26815 = binary_op(NOTEQ, _26814, _54sequence_type_46780);
        }
        _26814 = NOVALUE;
        DeRef(_26808);
        if (IS_ATOM_INT(_26815))
        _26808 = (_26815 != 0);
        else
        _26808 = DBL_PTR(_26815)->dbl != 0.0;
L61: 
        DeRef(_26804);
        _26804 = (_26808 != 0);
L60: 
        DeRef(_26800);
        _26800 = (_26804 != 0);
L5F: 
        if (_26800 == 0)
        {
            _26800 = NOVALUE;
            goto L5E; // [3482] 3497
        }
        else{
            _26800 = NOVALUE;
        }

        /** emit.e:1153					op = ASSIGN_SUBS_CHECK*/
        _op_51870 = 84LL;
        goto L62; // [3494] 3517
L5E: 

        /** emit.e:1155					if IsInteger(b) then*/
        _26816 = _47IsInteger(_b_51873);
        if (_26816 == 0) {
            DeRef(_26816);
            _26816 = NOVALUE;
            goto L63; // [3503] 3516
        }
        else {
            if (!IS_ATOM_INT(_26816) && DBL_PTR(_26816)->dbl == 0.0){
                DeRef(_26816);
                _26816 = NOVALUE;
                goto L63; // [3503] 3516
            }
            DeRef(_26816);
            _26816 = NOVALUE;
        }
        DeRef(_26816);
        _26816 = NOVALUE;

        /** emit.e:1156						op = ASSIGN_SUBS_I*/
        _op_51870 = 118LL;
L63: 
L62: 

        /** emit.e:1159				emit_opcode(op)*/
        _47emit_opcode(_op_51870);
        goto L64; // [3522] 3551
L5C: 

        /** emit.e:1161			elsif op = PASSIGN_SUBS then*/
        if (_op_51870 != 162LL)
        goto L65; // [3529] 3543

        /** emit.e:1162				emit_opcode(PASSIGN_SUBS) -- always*/
        _47emit_opcode(162LL);
        goto L64; // [3540] 3551
L65: 

        /** emit.e:1165				emit_opcode(ASSIGN_SUBS) -- always*/
        _47emit_opcode(16LL);
L64: 

        /** emit.e:1169			emit_addr(c) -- sequence*/
        _47emit_addr(_c_51874);

        /** emit.e:1170			emit_addr(a) -- subscript*/
        _47emit_addr(_a_51872);

        /** emit.e:1171			emit_addr(b) -- rhs value*/
        _47emit_addr(_b_51873);

        /** emit.e:1172			assignable = FALSE*/
        _47assignable_50950 = _13FALSE_450;
        goto LC; // [3573] 7739

        /** emit.e:1174		case LHS_SUBS, LHS_SUBS1, LHS_SUBS1_COPY then*/
        case 95:
        case 161:
        case 166:

        /** emit.e:1176			a = Pop() -- subs*/
        _a_51872 = _47Pop();
        if (!IS_ATOM_INT(_a_51872)) {
            _1 = (object)(DBL_PTR(_a_51872)->dbl);
            DeRefDS(_a_51872);
            _a_51872 = _1;
        }

        /** emit.e:1177			lhs_var = Pop() -- sequence*/
        _lhs_var_51880 = _47Pop();
        if (!IS_ATOM_INT(_lhs_var_51880)) {
            _1 = (object)(DBL_PTR(_lhs_var_51880)->dbl);
            DeRefDS(_lhs_var_51880);
            _lhs_var_51880 = _1;
        }

        /** emit.e:1178			emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1179			emit_addr(lhs_var)*/
        _47emit_addr(_lhs_var_51880);

        /** emit.e:1180			emit_addr(a)*/
        _47emit_addr(_a_51872);

        /** emit.e:1181			if op = LHS_SUBS then*/
        if (_op_51870 != 95LL)
        goto L66; // [3616] 3647

        /** emit.e:1182				TempKeep(lhs_var) -- should be lhs_target_temp*/
        _47TempKeep(_lhs_var_51880);

        /** emit.e:1183				emit_addr(lhs_target_temp)*/
        _47emit_addr(_47lhs_target_temp_50946);

        /** emit.e:1184				Push(lhs_target_temp)*/
        _47Push(_47lhs_target_temp_50946);

        /** emit.e:1185				emit_addr(0) -- place holder*/
        _47emit_addr(0LL);
        goto L67; // [3644] 3701
L66: 

        /** emit.e:1189				lhs_target_temp = NewTempSym() -- use same temp for all subscripts*/
        _0 = _54NewTempSym(0LL);
        _47lhs_target_temp_50946 = _0;
        if (!IS_ATOM_INT(_47lhs_target_temp_50946)) {
            _1 = (object)(DBL_PTR(_47lhs_target_temp_50946)->dbl);
            DeRefDS(_47lhs_target_temp_50946);
            _47lhs_target_temp_50946 = _1;
        }

        /** emit.e:1190				emit_addr(lhs_target_temp) -- target temp holds pointer to sequence*/
        _47emit_addr(_47lhs_target_temp_50946);

        /** emit.e:1191				emit_temp(lhs_target_temp, NEW_REFERENCE )*/
        _47emit_temp(_47lhs_target_temp_50946, 1LL);

        /** emit.e:1192				Push(lhs_target_temp)*/
        _47Push(_47lhs_target_temp_50946);

        /** emit.e:1193				lhs_subs1_copy_temp = NewTempSym() -- place to copy (may be ignored)*/
        _0 = _54NewTempSym(0LL);
        _47lhs_subs1_copy_temp_50945 = _0;
        if (!IS_ATOM_INT(_47lhs_subs1_copy_temp_50945)) {
            _1 = (object)(DBL_PTR(_47lhs_subs1_copy_temp_50945)->dbl);
            DeRefDS(_47lhs_subs1_copy_temp_50945);
            _47lhs_subs1_copy_temp_50945 = _1;
        }

        /** emit.e:1194				emit_addr(lhs_subs1_copy_temp)*/
        _47emit_addr(_47lhs_subs1_copy_temp_50945);

        /** emit.e:1195				emit_temp( lhs_subs1_copy_temp, NEW_REFERENCE )*/
        _47emit_temp(_47lhs_subs1_copy_temp_50945, 1LL);
L67: 

        /** emit.e:1198			current_sequence = append(current_sequence, lhs_target_temp)*/
        Append(&_47current_sequence_50940, _47current_sequence_50940, _47lhs_target_temp_50946);

        /** emit.e:1199			assignable = FALSE  -- need to update current_sequence like in RHS_SUBS*/
        _47assignable_50950 = _13FALSE_450;
        goto LC; // [3718] 7739

        /** emit.e:1201		case PEEK_LONGS then*/
        case 436:

        /** emit.e:1202			if IWINDOWS or TWINDOWS or not (IX86_64 or TX86_64) then*/
        if (_46IWINDOWS_21585 != 0) {
            _26824 = 1;
            goto L68; // [3728] 3738
        }
        _26824 = (_46TWINDOWS_21586 != 0);
L68: 
        if (_26824 != 0) {
            goto L69; // [3738] 3762
        }
        if (_46IX86_64_21601 != 0) {
            DeRef(_26826);
            _26826 = 1;
            goto L6A; // [3744] 3754
        }
        _26826 = (_46TX86_64_21602 != 0);
L6A: 
        _26827 = (_26826 == 0);
        _26826 = NOVALUE;
        if (_26827 == 0)
        {
            DeRef(_26827);
            _26827 = NOVALUE;
            goto L6B; // [3758] 3774
        }
        else{
            DeRef(_26827);
            _26827 = NOVALUE;
        }
L69: 

        /** emit.e:1203				op = PEEK4S*/
        _op_51870 = 139LL;
        goto L6C; // [3771] 3784
L6B: 

        /** emit.e:1205				op = PEEK8S*/
        _op_51870 = 213LL;
L6C: 

        /** emit.e:1207			last_op = op*/
        _47last_op_51829 = _op_51870;

        /** emit.e:1208			cont11ii(op, TRUE )*/
        _47cont11ii(_op_51870, _13TRUE_452);
        goto LC; // [3797] 7739

        /** emit.e:1210		case PEEK_LONGU then*/
        case 435:

        /** emit.e:1211			if IWINDOWS or TWINDOWS or not (IX86_64 or TX86_64) then*/
        if (_46IWINDOWS_21585 != 0) {
            _26828 = 1;
            goto L6D; // [3807] 3817
        }
        _26828 = (_46TWINDOWS_21586 != 0);
L6D: 
        if (_26828 != 0) {
            goto L6E; // [3817] 3841
        }
        if (_46IX86_64_21601 != 0) {
            DeRef(_26830);
            _26830 = 1;
            goto L6F; // [3823] 3833
        }
        _26830 = (_46TX86_64_21602 != 0);
L6F: 
        _26831 = (_26830 == 0);
        _26830 = NOVALUE;
        if (_26831 == 0)
        {
            DeRef(_26831);
            _26831 = NOVALUE;
            goto L70; // [3837] 3853
        }
        else{
            DeRef(_26831);
            _26831 = NOVALUE;
        }
L6E: 

        /** emit.e:1212				op = PEEK4U*/
        _op_51870 = 140LL;
        goto L71; // [3850] 3863
L70: 

        /** emit.e:1214				op = PEEK8U*/
        _op_51870 = 214LL;
L71: 

        /** emit.e:1216			last_op = op*/
        _47last_op_51829 = _op_51870;

        /** emit.e:1217			cont11ii(op, TRUE )*/
        _47cont11ii(_op_51870, _13TRUE_452);
        goto LC; // [3876] 7739

        /** emit.e:1220		case RAND, PEEK, PEEK4S, PEEK4U, NOT_BITS, NOT, PEEK8U, PEEK8S, SIZEOF,*/
        case 62:
        case 127:
        case 139:
        case 140:
        case 51:
        case 7:
        case 214:
        case 213:
        case 217:
        case 173:
        case 180:
        case 179:
        case 181:
        case 182:
        case 216:

        /** emit.e:1222			cont11ii(op, TRUE)*/
        _47cont11ii(_op_51870, _13TRUE_452);
        goto LC; // [3918] 7739

        /** emit.e:1224		case UMINUS then*/
        case 12:

        /** emit.e:1226			a = Pop()*/
        _a_51872 = _47Pop();
        if (!IS_ATOM_INT(_a_51872)) {
            _1 = (object)(DBL_PTR(_a_51872)->dbl);
            DeRefDS(_a_51872);
            _a_51872 = _1;
        }

        /** emit.e:1228			if a > 0 then*/
        if (_a_51872 <= 0LL)
        goto L72; // [3933] 4180

        /** emit.e:1229				obj = SymTab[a][S_OBJ]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26834 = (object)*(((s1_ptr)_2)->base + _a_51872);
        DeRef(_obj_51884);
        _2 = (object)SEQ_PTR(_26834);
        _obj_51884 = (object)*(((s1_ptr)_2)->base + 1LL);
        Ref(_obj_51884);
        _26834 = NOVALUE;

        /** emit.e:1230				if SymTab[a][S_MODE] = M_CONSTANT then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26836 = (object)*(((s1_ptr)_2)->base + _a_51872);
        _2 = (object)SEQ_PTR(_26836);
        _26837 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26836 = NOVALUE;
        if (binary_op_a(NOTEQ, _26837, 2LL)){
            _26837 = NOVALUE;
            goto L73; // [3967] 4092
        }
        _26837 = NOVALUE;

        /** emit.e:1231					if is_integer(obj) then*/
        Ref(_obj_51884);
        _26839 = _36is_integer(_obj_51884);
        if (_26839 == 0) {
            DeRef(_26839);
            _26839 = NOVALUE;
            goto L74; // [3977] 4031
        }
        else {
            if (!IS_ATOM_INT(_26839) && DBL_PTR(_26839)->dbl == 0.0){
                DeRef(_26839);
                _26839 = NOVALUE;
                goto L74; // [3977] 4031
            }
            DeRef(_26839);
            _26839 = NOVALUE;
        }
        DeRef(_26839);
        _26839 = NOVALUE;

        /** emit.e:1232						if obj = MININT then*/
        if (binary_op_a(NOTEQ, _obj_51884, _36MININT_21263)){
            goto L75; // [3984] 4005
        }

        /** emit.e:1233							Push(NewDoubleSym(-MININT))*/
        if (IS_ATOM_INT(_36MININT_21263)) {
            if ((uintptr_t)_36MININT_21263 == (uintptr_t)HIGH_BITS){
                _26841 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _26841 = - _36MININT_21263;
            }
        }
        else {
            _26841 = unary_op(UMINUS, _36MININT_21263);
        }
        _26842 = _54NewDoubleSym(_26841);
        _26841 = NOVALUE;
        _47Push(_26842);
        _26842 = NOVALUE;
        goto L76; // [4002] 4018
L75: 

        /** emit.e:1235							Push(NewIntSym(-obj))*/
        if (IS_ATOM_INT(_obj_51884)) {
            if ((uintptr_t)_obj_51884 == (uintptr_t)HIGH_BITS){
                _26843 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _26843 = - _obj_51884;
            }
        }
        else {
            _26843 = unary_op(UMINUS, _obj_51884);
        }
        _26844 = _54NewIntSym(_26843);
        _26843 = NOVALUE;
        _47Push(_26844);
        _26844 = NOVALUE;
L76: 

        /** emit.e:1237						last_pc = last_pc_backup*/
        _47last_pc_51830 = _last_pc_backup_51887;

        /** emit.e:1238						last_op = last_op_backup*/
        _47last_op_51829 = _last_op_backup_51888;
        goto LC; // [4028] 7739
L74: 

        /** emit.e:1240					elsif atom(obj) and obj != NOVALUE then*/
        _26845 = IS_ATOM(_obj_51884);
        if (_26845 == 0) {
            goto L77; // [4036] 4075
        }
        if (IS_ATOM_INT(_obj_51884) && IS_ATOM_INT(_36NOVALUE_21293)) {
            _26847 = (_obj_51884 != _36NOVALUE_21293);
        }
        else {
            _26847 = binary_op(NOTEQ, _obj_51884, _36NOVALUE_21293);
        }
        if (_26847 == 0) {
            DeRef(_26847);
            _26847 = NOVALUE;
            goto L77; // [4047] 4075
        }
        else {
            if (!IS_ATOM_INT(_26847) && DBL_PTR(_26847)->dbl == 0.0){
                DeRef(_26847);
                _26847 = NOVALUE;
                goto L77; // [4047] 4075
            }
            DeRef(_26847);
            _26847 = NOVALUE;
        }
        DeRef(_26847);
        _26847 = NOVALUE;

        /** emit.e:1245						Push(NewDoubleSym(-obj))*/
        if (IS_ATOM_INT(_obj_51884)) {
            if ((uintptr_t)_obj_51884 == (uintptr_t)HIGH_BITS){
                _26848 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _26848 = - _obj_51884;
            }
        }
        else {
            _26848 = unary_op(UMINUS, _obj_51884);
        }
        _26849 = _54NewDoubleSym(_26848);
        _26848 = NOVALUE;
        _47Push(_26849);
        _26849 = NOVALUE;

        /** emit.e:1246						last_pc = last_pc_backup*/
        _47last_pc_51830 = _last_pc_backup_51887;

        /** emit.e:1247						last_op = last_op_backup*/
        _47last_op_51829 = _last_op_backup_51888;
        goto LC; // [4072] 7739
L77: 

        /** emit.e:1250						Push(a)*/
        _47Push(_a_51872);

        /** emit.e:1251						cont11ii(op, FALSE)*/
        _47cont11ii(_op_51870, _13FALSE_450);
        goto LC; // [4089] 7739
L73: 

        /** emit.e:1254				elsif TRANSLATE and SymTab[a][S_MODE] = M_TEMP and*/
        if (_36TRANSLATE_21041 == 0) {
            _26850 = 0;
            goto L78; // [4096] 4122
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26851 = (object)*(((s1_ptr)_2)->base + _a_51872);
        _2 = (object)SEQ_PTR(_26851);
        _26852 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26851 = NOVALUE;
        if (IS_ATOM_INT(_26852)) {
            _26853 = (_26852 == 3LL);
        }
        else {
            _26853 = binary_op(EQUALS, _26852, 3LL);
        }
        _26852 = NOVALUE;
        if (IS_ATOM_INT(_26853))
        _26850 = (_26853 != 0);
        else
        _26850 = DBL_PTR(_26853)->dbl != 0.0;
L78: 
        if (_26850 == 0) {
            goto L79; // [4122] 4163
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26855 = (object)*(((s1_ptr)_2)->base + _a_51872);
        _2 = (object)SEQ_PTR(_26855);
        _26856 = (object)*(((s1_ptr)_2)->base + 36LL);
        _26855 = NOVALUE;
        if (IS_ATOM_INT(_26856)) {
            _26857 = (_26856 == 2LL);
        }
        else {
            _26857 = binary_op(EQUALS, _26856, 2LL);
        }
        _26856 = NOVALUE;
        if (_26857 == 0) {
            DeRef(_26857);
            _26857 = NOVALUE;
            goto L79; // [4145] 4163
        }
        else {
            if (!IS_ATOM_INT(_26857) && DBL_PTR(_26857)->dbl == 0.0){
                DeRef(_26857);
                _26857 = NOVALUE;
                goto L79; // [4145] 4163
            }
            DeRef(_26857);
            _26857 = NOVALUE;
        }
        DeRef(_26857);
        _26857 = NOVALUE;

        /** emit.e:1256					Push(NewDoubleSym(-obj))*/
        if (IS_ATOM_INT(_obj_51884)) {
            if ((uintptr_t)_obj_51884 == (uintptr_t)HIGH_BITS){
                _26858 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _26858 = - _obj_51884;
            }
        }
        else {
            _26858 = unary_op(UMINUS, _obj_51884);
        }
        _26859 = _54NewDoubleSym(_26858);
        _26858 = NOVALUE;
        _47Push(_26859);
        _26859 = NOVALUE;
        goto LC; // [4160] 7739
L79: 

        /** emit.e:1259					Push(a)*/
        _47Push(_a_51872);

        /** emit.e:1260					cont11ii(op, FALSE)*/
        _47cont11ii(_op_51870, _13FALSE_450);
        goto LC; // [4177] 7739
L72: 

        /** emit.e:1263				Push(a)*/
        _47Push(_a_51872);

        /** emit.e:1264				cont11ii(op, FALSE)*/
        _47cont11ii(_op_51870, _13FALSE_450);
        goto LC; // [4194] 7739

        /** emit.e:1267		case LENGTH, GETC, SQRT, SIN, COS, TAN, ARCTAN, LOG, GETS, GETENV then*/
        case 42:
        case 33:
        case 41:
        case 80:
        case 81:
        case 82:
        case 73:
        case 74:
        case 17:
        case 91:

        /** emit.e:1268			cont11ii(op, FALSE)*/
        _47cont11ii(_op_51870, _13FALSE_450);
        goto LC; // [4226] 7739

        /** emit.e:1270		case IS_AN_INTEGER, IS_AN_ATOM, IS_A_SEQUENCE, IS_AN_OBJECT then*/
        case 94:
        case 67:
        case 68:
        case 40:

        /** emit.e:1271			cont11ii(op, FALSE)*/
        _47cont11ii(_op_51870, _13FALSE_450);
        goto LC; // [4246] 7739

        /** emit.e:1275		case ROUTINE_ID then*/
        case 134:

        /** emit.e:1276			emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1277			source = Pop()*/
        _source_51876 = _47Pop();
        if (!IS_ATOM_INT(_source_51876)) {
            _1 = (object)(DBL_PTR(_source_51876)->dbl);
            DeRefDS(_source_51876);
            _source_51876 = _1;
        }

        /** emit.e:1278			if TRANSLATE then*/
        if (_36TRANSLATE_21041 == 0)
        {
            goto L7A; // [4268] 4312
        }
        else{
        }

        /** emit.e:1279				emit_addr(num_routines-1)*/
        _26861 = _36num_routines_21448 - 1LL;
        if ((object)((uintptr_t)_26861 +(uintptr_t) HIGH_BITS) >= 0){
            _26861 = NewDouble((eudouble)_26861);
        }
        _47emit_addr(_26861);
        _26861 = NOVALUE;

        /** emit.e:1280				last_routine_id = num_routines*/
        _47last_routine_id_50937 = _36num_routines_21448;

        /** emit.e:1281				last_max_params = max_params*/
        _47last_max_params_50939 = _47max_params_50938;

        /** emit.e:1282				MarkTargets(source, S_RI_TARGET)*/
        _31698 = _54MarkTargets(_source_51876, 53LL);
        DeRef(_31698);
        _31698 = NOVALUE;
        goto L7B; // [4309] 4349
L7A: 

        /** emit.e:1285				emit_addr(CurrentSub)*/
        _47emit_addr(_36CurrentSub_21447);

        /** emit.e:1286				emit_addr(length(SymTab))*/
        if (IS_SEQUENCE(_37SymTab_15406)){
                _26862 = SEQ_PTR(_37SymTab_15406)->length;
        }
        else {
            _26862 = 1;
        }
        _47emit_addr(_26862);
        _26862 = NOVALUE;

        /** emit.e:1288				if BIND then*/
        if (_36BIND_21044 == 0)
        {
            goto L7C; // [4333] 4348
        }
        else{
        }

        /** emit.e:1290					MarkTargets(source, S_NREFS)*/
        _31697 = _54MarkTargets(_source_51876, 12LL);
        DeRef(_31697);
        _31697 = NOVALUE;
L7C: 
L7B: 

        /** emit.e:1294			emit_addr(source)*/
        _47emit_addr(_source_51876);

        /** emit.e:1295			emit_addr(current_file_no)  -- necessary at top level*/
        _47emit_addr(_36current_file_no_21439);

        /** emit.e:1296			assignable = TRUE*/
        _47assignable_50950 = _13TRUE_452;

        /** emit.e:1297			c = NewTempSym()*/
        _c_51874 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_51874)) {
            _1 = (object)(DBL_PTR(_c_51874)->dbl);
            DeRefDS(_c_51874);
            _c_51874 = _1;
        }

        /** emit.e:1298			TempInteger(c) -- result will always be an integer*/
        _47TempInteger(_c_51874);

        /** emit.e:1299			Push(c)*/
        _47Push(_c_51874);

        /** emit.e:1300			emit_addr(c)*/
        _47emit_addr(_c_51874);
        goto LC; // [4391] 7739

        /** emit.e:1305		case SC1_OR, SC1_AND then*/
        case 143:
        case 141:

        /** emit.e:1306			emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1307			emit_addr(Pop())*/
        _26864 = _47Pop();
        _47emit_addr(_26864);
        _26864 = NOVALUE;

        /** emit.e:1308			c = NewTempSym()*/
        _c_51874 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_51874)) {
            _1 = (object)(DBL_PTR(_c_51874)->dbl);
            DeRefDS(_c_51874);
            _c_51874 = _1;
        }

        /** emit.e:1309			Push(c)*/
        _47Push(_c_51874);

        /** emit.e:1310			emit_addr(c)*/
        _47emit_addr(_c_51874);

        /** emit.e:1311			assignable = FALSE*/
        _47assignable_50950 = _13FALSE_450;
        goto LC; // [4437] 7739

        /** emit.e:1315		case POKE_LONG then*/
        case 434:

        /** emit.e:1316			if IWINDOWS or TWINDOWS or not (IX86_64 or TX86_64) then*/
        if (_46IWINDOWS_21585 != 0) {
            _26866 = 1;
            goto L7D; // [4447] 4457
        }
        _26866 = (_46TWINDOWS_21586 != 0);
L7D: 
        if (_26866 != 0) {
            goto L7E; // [4457] 4481
        }
        if (_46IX86_64_21601 != 0) {
            DeRef(_26868);
            _26868 = 1;
            goto L7F; // [4463] 4473
        }
        _26868 = (_46TX86_64_21602 != 0);
L7F: 
        _26869 = (_26868 == 0);
        _26868 = NOVALUE;
        if (_26869 == 0)
        {
            DeRef(_26869);
            _26869 = NOVALUE;
            goto L80; // [4477] 4493
        }
        else{
            DeRef(_26869);
            _26869 = NOVALUE;
        }
L7E: 

        /** emit.e:1317				op = POKE4*/
        _op_51870 = 138LL;
        goto L81; // [4490] 4503
L80: 

        /** emit.e:1319				op = POKE8*/
        _op_51870 = 212LL;
L81: 

        /** emit.e:1321			last_op = op*/
        _47last_op_51829 = _op_51870;

        /** emit.e:1324		case SYSTEM, PUTS, PRINT, QPRINT, POSITION, MACHINE_PROC,*/
        case 99:
        case 44:
        case 19:
        case 36:
        case 60:
        case 112:
        case 132:
        case 128:
        case 138:
        case 168:
        case 178:
        case 212:
        case 215:

        /** emit.e:1326			emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1328			b = Pop()*/
        _b_51873 = _47Pop();
        if (!IS_ATOM_INT(_b_51873)) {
            _1 = (object)(DBL_PTR(_b_51873)->dbl);
            DeRefDS(_b_51873);
            _b_51873 = _1;
        }

        /** emit.e:1329			emit_addr(Pop())*/
        _26871 = _47Pop();
        _47emit_addr(_26871);
        _26871 = NOVALUE;

        /** emit.e:1330			emit_addr(b)*/
        _47emit_addr(_b_51873);

        /** emit.e:1331			if op = C_PROC then*/
        if (_op_51870 != 132LL)
        goto L82; // [4565] 4577

        /** emit.e:1332				emit_addr(CurrentSub)*/
        _47emit_addr(_36CurrentSub_21447);
L82: 

        /** emit.e:1334			assignable = FALSE*/
        _47assignable_50950 = _13FALSE_450;
        goto LC; // [4584] 7739

        /** emit.e:1337		case EQUALS, LESS, GREATER, NOTEQ, LESSEQ, GREATEREQ,*/
        case 3:
        case 1:
        case 6:
        case 4:
        case 5:
        case 2:
        case 8:
        case 9:
        case 152:
        case 71:
        case 56:
        case 24:
        case 26:

        /** emit.e:1339			cont21ii(op, TRUE)  -- both integer args => integer result*/
        _47cont21ii(_op_51870, _13TRUE_452);
        goto LC; // [4622] 7739

        /** emit.e:1341		case PLUS then -- elsif op = PLUS then*/
        case 11:

        /** emit.e:1343			b = Pop()*/
        _b_51873 = _47Pop();
        if (!IS_ATOM_INT(_b_51873)) {
            _1 = (object)(DBL_PTR(_b_51873)->dbl);
            DeRefDS(_b_51873);
            _b_51873 = _1;
        }

        /** emit.e:1344			a = Pop()*/
        _a_51872 = _47Pop();
        if (!IS_ATOM_INT(_a_51872)) {
            _1 = (object)(DBL_PTR(_a_51872)->dbl);
            DeRefDS(_a_51872);
            _a_51872 = _1;
        }

        /** emit.e:1346			if b < 1 or a < 1 then*/
        _26875 = (_b_51873 < 1LL);
        if (_26875 != 0) {
            goto L83; // [4648] 4661
        }
        _26877 = (_a_51872 < 1LL);
        if (_26877 == 0)
        {
            DeRef(_26877);
            _26877 = NOVALUE;
            goto L84; // [4657] 4682
        }
        else{
            DeRef(_26877);
            _26877 = NOVALUE;
        }
L83: 

        /** emit.e:1347				Push(a)*/
        _47Push(_a_51872);

        /** emit.e:1348				Push(b)*/
        _47Push(_b_51873);

        /** emit.e:1349				cont21ii(op, FALSE)*/
        _47cont21ii(_op_51870, _13FALSE_450);
        goto LC; // [4679] 7739
L84: 

        /** emit.e:1350			elsif SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 1) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26878 = (object)*(((s1_ptr)_2)->base + _b_51873);
        _2 = (object)SEQ_PTR(_26878);
        _26879 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26878 = NOVALUE;
        if (IS_ATOM_INT(_26879)) {
            _26880 = (_26879 == 2LL);
        }
        else {
            _26880 = binary_op(EQUALS, _26879, 2LL);
        }
        _26879 = NOVALUE;
        if (IS_ATOM_INT(_26880)) {
            if (_26880 == 0) {
                goto L85; // [4702] 4763
            }
        }
        else {
            if (DBL_PTR(_26880)->dbl == 0.0) {
                goto L85; // [4702] 4763
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26882 = (object)*(((s1_ptr)_2)->base + _b_51873);
        _2 = (object)SEQ_PTR(_26882);
        _26883 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26882 = NOVALUE;
        if (_26883 == 1LL)
        _26884 = 1;
        else if (IS_ATOM_INT(_26883) && IS_ATOM_INT(1LL))
        _26884 = 0;
        else
        _26884 = (compare(_26883, 1LL) == 0);
        _26883 = NOVALUE;
        if (_26884 == 0)
        {
            _26884 = NOVALUE;
            goto L85; // [4723] 4763
        }
        else{
            _26884 = NOVALUE;
        }

        /** emit.e:1351				op = PLUS1*/
        _op_51870 = 93LL;

        /** emit.e:1352				emit_opcode(op)*/
        _47emit_opcode(93LL);

        /** emit.e:1353				emit_addr(a)*/
        _47emit_addr(_a_51872);

        /** emit.e:1354				emit_addr(0)*/
        _47emit_addr(0LL);

        /** emit.e:1355				cont21d(op, a, b, FALSE)*/
        _47cont21d(93LL, _a_51872, _b_51873, _13FALSE_450);
        goto LC; // [4760] 7739
L85: 

        /** emit.e:1356			elsif SymTab[a][S_MODE] = M_CONSTANT and equal(SymTab[a][S_OBJ], 1) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26885 = (object)*(((s1_ptr)_2)->base + _a_51872);
        _2 = (object)SEQ_PTR(_26885);
        _26886 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26885 = NOVALUE;
        if (IS_ATOM_INT(_26886)) {
            _26887 = (_26886 == 2LL);
        }
        else {
            _26887 = binary_op(EQUALS, _26886, 2LL);
        }
        _26886 = NOVALUE;
        if (IS_ATOM_INT(_26887)) {
            if (_26887 == 0) {
                goto L86; // [4783] 4844
            }
        }
        else {
            if (DBL_PTR(_26887)->dbl == 0.0) {
                goto L86; // [4783] 4844
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26889 = (object)*(((s1_ptr)_2)->base + _a_51872);
        _2 = (object)SEQ_PTR(_26889);
        _26890 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26889 = NOVALUE;
        if (_26890 == 1LL)
        _26891 = 1;
        else if (IS_ATOM_INT(_26890) && IS_ATOM_INT(1LL))
        _26891 = 0;
        else
        _26891 = (compare(_26890, 1LL) == 0);
        _26890 = NOVALUE;
        if (_26891 == 0)
        {
            _26891 = NOVALUE;
            goto L86; // [4804] 4844
        }
        else{
            _26891 = NOVALUE;
        }

        /** emit.e:1357				op = PLUS1*/
        _op_51870 = 93LL;

        /** emit.e:1358				emit_opcode(op)*/
        _47emit_opcode(93LL);

        /** emit.e:1359				emit_addr(b)*/
        _47emit_addr(_b_51873);

        /** emit.e:1360				emit_addr(0)*/
        _47emit_addr(0LL);

        /** emit.e:1361				cont21d(op, a, b, FALSE)*/
        _47cont21d(93LL, _a_51872, _b_51873, _13FALSE_450);
        goto LC; // [4841] 7739
L86: 

        /** emit.e:1363				Push(a)*/
        _47Push(_a_51872);

        /** emit.e:1364				Push(b)*/
        _47Push(_b_51873);

        /** emit.e:1365				cont21ii(op, FALSE)*/
        _47cont21ii(_op_51870, _13FALSE_450);
        goto LC; // [4863] 7739

        /** emit.e:1368		case rw:MULTIPLY then*/
        case 13:

        /** emit.e:1370			b = Pop()*/
        _b_51873 = _47Pop();
        if (!IS_ATOM_INT(_b_51873)) {
            _1 = (object)(DBL_PTR(_b_51873)->dbl);
            DeRefDS(_b_51873);
            _b_51873 = _1;
        }

        /** emit.e:1371			a = Pop()*/
        _a_51872 = _47Pop();
        if (!IS_ATOM_INT(_a_51872)) {
            _1 = (object)(DBL_PTR(_a_51872)->dbl);
            DeRefDS(_a_51872);
            _a_51872 = _1;
        }

        /** emit.e:1372			if a < 1 or b < 1 then*/
        _26894 = (_a_51872 < 1LL);
        if (_26894 != 0) {
            goto L87; // [4889] 4902
        }
        _26896 = (_b_51873 < 1LL);
        if (_26896 == 0)
        {
            DeRef(_26896);
            _26896 = NOVALUE;
            goto L88; // [4898] 4923
        }
        else{
            DeRef(_26896);
            _26896 = NOVALUE;
        }
L87: 

        /** emit.e:1373				Push(a)*/
        _47Push(_a_51872);

        /** emit.e:1374				Push(b)*/
        _47Push(_b_51873);

        /** emit.e:1375				cont21ii(op, FALSE)*/
        _47cont21ii(_op_51870, _13FALSE_450);
        goto LC; // [4920] 7739
L88: 

        /** emit.e:1377			elsif SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 2) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26897 = (object)*(((s1_ptr)_2)->base + _b_51873);
        _2 = (object)SEQ_PTR(_26897);
        _26898 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26897 = NOVALUE;
        if (IS_ATOM_INT(_26898)) {
            _26899 = (_26898 == 2LL);
        }
        else {
            _26899 = binary_op(EQUALS, _26898, 2LL);
        }
        _26898 = NOVALUE;
        if (IS_ATOM_INT(_26899)) {
            if (_26899 == 0) {
                goto L89; // [4943] 5004
            }
        }
        else {
            if (DBL_PTR(_26899)->dbl == 0.0) {
                goto L89; // [4943] 5004
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26901 = (object)*(((s1_ptr)_2)->base + _b_51873);
        _2 = (object)SEQ_PTR(_26901);
        _26902 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26901 = NOVALUE;
        if (_26902 == 2LL)
        _26903 = 1;
        else if (IS_ATOM_INT(_26902) && IS_ATOM_INT(2LL))
        _26903 = 0;
        else
        _26903 = (compare(_26902, 2LL) == 0);
        _26902 = NOVALUE;
        if (_26903 == 0)
        {
            _26903 = NOVALUE;
            goto L89; // [4964] 5004
        }
        else{
            _26903 = NOVALUE;
        }

        /** emit.e:1379				op = PLUS*/
        _op_51870 = 11LL;

        /** emit.e:1380				emit_opcode(op)*/
        _47emit_opcode(11LL);

        /** emit.e:1381				emit_addr(a)*/
        _47emit_addr(_a_51872);

        /** emit.e:1382				emit_addr(a)*/
        _47emit_addr(_a_51872);

        /** emit.e:1383				cont21d(op, a, b, FALSE)*/
        _47cont21d(11LL, _a_51872, _b_51873, _13FALSE_450);
        goto LC; // [5001] 7739
L89: 

        /** emit.e:1385			elsif SymTab[a][S_MODE] = M_CONSTANT and equal(SymTab[a][S_OBJ], 2) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26904 = (object)*(((s1_ptr)_2)->base + _a_51872);
        _2 = (object)SEQ_PTR(_26904);
        _26905 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26904 = NOVALUE;
        if (IS_ATOM_INT(_26905)) {
            _26906 = (_26905 == 2LL);
        }
        else {
            _26906 = binary_op(EQUALS, _26905, 2LL);
        }
        _26905 = NOVALUE;
        if (IS_ATOM_INT(_26906)) {
            if (_26906 == 0) {
                goto L8A; // [5024] 5085
            }
        }
        else {
            if (DBL_PTR(_26906)->dbl == 0.0) {
                goto L8A; // [5024] 5085
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26908 = (object)*(((s1_ptr)_2)->base + _a_51872);
        _2 = (object)SEQ_PTR(_26908);
        _26909 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26908 = NOVALUE;
        if (_26909 == 2LL)
        _26910 = 1;
        else if (IS_ATOM_INT(_26909) && IS_ATOM_INT(2LL))
        _26910 = 0;
        else
        _26910 = (compare(_26909, 2LL) == 0);
        _26909 = NOVALUE;
        if (_26910 == 0)
        {
            _26910 = NOVALUE;
            goto L8A; // [5045] 5085
        }
        else{
            _26910 = NOVALUE;
        }

        /** emit.e:1386				op = PLUS*/
        _op_51870 = 11LL;

        /** emit.e:1387				emit_opcode(op)*/
        _47emit_opcode(11LL);

        /** emit.e:1388				emit_addr(b)*/
        _47emit_addr(_b_51873);

        /** emit.e:1389				emit_addr(b)*/
        _47emit_addr(_b_51873);

        /** emit.e:1390				cont21d(op, a, b, FALSE)*/
        _47cont21d(11LL, _a_51872, _b_51873, _13FALSE_450);
        goto LC; // [5082] 7739
L8A: 

        /** emit.e:1393				Push(a)*/
        _47Push(_a_51872);

        /** emit.e:1394				Push(b)*/
        _47Push(_b_51873);

        /** emit.e:1395				cont21ii(op, FALSE)*/
        _47cont21ii(_op_51870, _13FALSE_450);
        goto LC; // [5104] 7739

        /** emit.e:1399		case rw:DIVIDE then*/
        case 14:

        /** emit.e:1400			b = Pop()*/
        _b_51873 = _47Pop();
        if (!IS_ATOM_INT(_b_51873)) {
            _1 = (object)(DBL_PTR(_b_51873)->dbl);
            DeRefDS(_b_51873);
            _b_51873 = _1;
        }

        /** emit.e:1401			if b > 0 and SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 2) then*/
        _26912 = (_b_51873 > 0LL);
        if (_26912 == 0) {
            _26913 = 0;
            goto L8B; // [5123] 5149
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26914 = (object)*(((s1_ptr)_2)->base + _b_51873);
        _2 = (object)SEQ_PTR(_26914);
        _26915 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26914 = NOVALUE;
        if (IS_ATOM_INT(_26915)) {
            _26916 = (_26915 == 2LL);
        }
        else {
            _26916 = binary_op(EQUALS, _26915, 2LL);
        }
        _26915 = NOVALUE;
        if (IS_ATOM_INT(_26916))
        _26913 = (_26916 != 0);
        else
        _26913 = DBL_PTR(_26916)->dbl != 0.0;
L8B: 
        if (_26913 == 0) {
            goto L8C; // [5149] 5220
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26918 = (object)*(((s1_ptr)_2)->base + _b_51873);
        _2 = (object)SEQ_PTR(_26918);
        _26919 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26918 = NOVALUE;
        if (_26919 == 2LL)
        _26920 = 1;
        else if (IS_ATOM_INT(_26919) && IS_ATOM_INT(2LL))
        _26920 = 0;
        else
        _26920 = (compare(_26919, 2LL) == 0);
        _26919 = NOVALUE;
        if (_26920 == 0)
        {
            _26920 = NOVALUE;
            goto L8C; // [5170] 5220
        }
        else{
            _26920 = NOVALUE;
        }

        /** emit.e:1402				op = DIV2*/
        _op_51870 = 98LL;

        /** emit.e:1403				emit_opcode(op)*/
        _47emit_opcode(98LL);

        /** emit.e:1404				emit_addr(Pop()) -- n.b. "a" hasn't been set*/
        _26921 = _47Pop();
        _47emit_addr(_26921);
        _26921 = NOVALUE;

        /** emit.e:1405				a = 0*/
        _a_51872 = 0LL;

        /** emit.e:1406				emit_addr(0)*/
        _47emit_addr(0LL);

        /** emit.e:1407				cont21d(op, a, b, FALSE)  -- could have fractional result*/
        _47cont21d(98LL, 0LL, _b_51873, _13FALSE_450);
        goto LC; // [5217] 7739
L8C: 

        /** emit.e:1409				Push(b)*/
        _47Push(_b_51873);

        /** emit.e:1410				cont21ii(op, FALSE)*/
        _47cont21ii(_op_51870, _13FALSE_450);
        goto LC; // [5234] 7739

        /** emit.e:1413		case FLOOR then*/
        case 83:

        /** emit.e:1414			if previous_op = rw:DIVIDE then*/
        if (_36previous_op_21541 != 14LL)
        goto L8D; // [5244] 5292

        /** emit.e:1415				op = FLOOR_DIV*/
        _op_51870 = 63LL;

        /** emit.e:1416				backpatch(length(Code) - 3, op)*/
        if (IS_SEQUENCE(_36Code_21531)){
                _26923 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26923 = 1;
        }
        _26924 = _26923 - 3LL;
        _26923 = NOVALUE;
        _47backpatch(_26924, 63LL);
        _26924 = NOVALUE;

        /** emit.e:1417				assignable = TRUE*/
        _47assignable_50950 = _13TRUE_452;

        /** emit.e:1418				last_op = op*/
        _47last_op_51829 = 63LL;

        /** emit.e:1419				last_pc = last_pc_backup*/
        _47last_pc_51830 = _last_pc_backup_51887;
        goto LC; // [5289] 7739
L8D: 

        /** emit.e:1421			elsif previous_op = DIV2 then*/
        if (_36previous_op_21541 != 98LL)
        goto L8E; // [5298] 5385

        /** emit.e:1422				op = FLOOR_DIV2*/
        _op_51870 = 66LL;

        /** emit.e:1423				backpatch(length(Code) - 3, op)*/
        if (IS_SEQUENCE(_36Code_21531)){
                _26926 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26926 = 1;
        }
        _26927 = _26926 - 3LL;
        _26926 = NOVALUE;
        _47backpatch(_26927, 66LL);
        _26927 = NOVALUE;

        /** emit.e:1424				assignable = TRUE*/
        _47assignable_50950 = _13TRUE_452;

        /** emit.e:1425				if IsInteger(Code[$-2]) then*/
        if (IS_SEQUENCE(_36Code_21531)){
                _26928 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _26928 = 1;
        }
        _26929 = _26928 - 2LL;
        _26928 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21531);
        _26930 = (object)*(((s1_ptr)_2)->base + _26929);
        Ref(_26930);
        _26931 = _47IsInteger(_26930);
        _26930 = NOVALUE;
        if (_26931 == 0) {
            DeRef(_26931);
            _26931 = NOVALUE;
            goto L8F; // [5352] 5372
        }
        else {
            if (!IS_ATOM_INT(_26931) && DBL_PTR(_26931)->dbl == 0.0){
                DeRef(_26931);
                _26931 = NOVALUE;
                goto L8F; // [5352] 5372
            }
            DeRef(_26931);
            _26931 = NOVALUE;
        }
        DeRef(_26931);
        _26931 = NOVALUE;

        /** emit.e:1426					TempInteger(Top()) --mark temp as integer type*/

        /** emit.e:145		return cg_stack[cgi]*/
        DeRef(_Top_inlined_Top_at_5482_52972);
        _2 = (object)SEQ_PTR(_47cg_stack_50947);
        _Top_inlined_Top_at_5482_52972 = (object)*(((s1_ptr)_2)->base + _47cgi_50948);
        Ref(_Top_inlined_Top_at_5482_52972);
        Ref(_Top_inlined_Top_at_5482_52972);
        _47TempInteger(_Top_inlined_Top_at_5482_52972);
L8F: 

        /** emit.e:1428				last_op = op*/
        _47last_op_51829 = _op_51870;

        /** emit.e:1429				last_pc = last_pc_backup*/
        _47last_pc_51830 = _last_pc_backup_51887;
        goto LC; // [5382] 7739
L8E: 

        /** emit.e:1431				cont11ii(op, TRUE)*/
        _47cont11ii(_op_51870, _13TRUE_452);
        goto LC; // [5394] 7739

        /** emit.e:1437		case MINUS, rw:APPEND, PREPEND, COMPARE, EQUAL,*/
        case 10:
        case 35:
        case 57:
        case 76:
        case 153:
        case 154:
        case 15:
        case 32:
        case 111:
        case 133:
        case 53:
        case 167:
        case 194:
        case 198:
        case 199:
        case 204:

        /** emit.e:1440			cont21ii(op, FALSE)*/
        _47cont21ii(_op_51870, _13FALSE_450);
        goto LC; // [5438] 7739

        /** emit.e:1442		case SC2_NULL then  -- correct the stack - we aren't emitting anything*/
        case 145:

        /** emit.e:1443			c = Pop()*/
        _c_51874 = _47Pop();
        if (!IS_ATOM_INT(_c_51874)) {
            _1 = (object)(DBL_PTR(_c_51874)->dbl);
            DeRefDS(_c_51874);
            _c_51874 = _1;
        }

        /** emit.e:1444			TempKeep(c)*/
        _47TempKeep(_c_51874);

        /** emit.e:1445			b = Pop()  -- remove SC1's temp*/
        _b_51873 = _47Pop();
        if (!IS_ATOM_INT(_b_51873)) {
            _1 = (object)(DBL_PTR(_b_51873)->dbl);
            DeRefDS(_b_51873);
            _b_51873 = _1;
        }

        /** emit.e:1446			Push(c)*/
        _47Push(_c_51874);

        /** emit.e:1447			assignable = FALSE*/
        _47assignable_50950 = _13FALSE_450;

        /** emit.e:1448			last_op = last_op_backup*/
        _47last_op_51829 = _last_op_backup_51888;

        /** emit.e:1449			last_pc = last_pc_backup*/
        _47last_pc_51830 = _last_pc_backup_51887;
        goto LC; // [5485] 7739

        /** emit.e:1452		case SC2_AND, SC2_OR then*/
        case 142:
        case 144:

        /** emit.e:1453			emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1454			emit_addr(Pop())*/
        _26934 = _47Pop();
        _47emit_addr(_26934);
        _26934 = NOVALUE;

        /** emit.e:1455			c = Pop()*/
        _c_51874 = _47Pop();
        if (!IS_ATOM_INT(_c_51874)) {
            _1 = (object)(DBL_PTR(_c_51874)->dbl);
            DeRefDS(_c_51874);
            _c_51874 = _1;
        }

        /** emit.e:1456			TempKeep(c)*/
        _47TempKeep(_c_51874);

        /** emit.e:1457			emit_addr(c) -- target*/
        _47emit_addr(_c_51874);

        /** emit.e:1458			TempInteger(c)*/
        _47TempInteger(_c_51874);

        /** emit.e:1459			Push(c)*/
        _47Push(_c_51874);

        /** emit.e:1460			assignable = FALSE*/
        _47assignable_50950 = _13FALSE_450;
        goto LC; // [5540] 7739

        /** emit.e:1463		case MEM_COPY, MEM_SET, PRINTF then*/
        case 130:
        case 131:
        case 38:

        /** emit.e:1464			emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1465			c = Pop()*/
        _c_51874 = _47Pop();
        if (!IS_ATOM_INT(_c_51874)) {
            _1 = (object)(DBL_PTR(_c_51874)->dbl);
            DeRefDS(_c_51874);
            _c_51874 = _1;
        }

        /** emit.e:1466			b = Pop()*/
        _b_51873 = _47Pop();
        if (!IS_ATOM_INT(_b_51873)) {
            _1 = (object)(DBL_PTR(_b_51873)->dbl);
            DeRefDS(_b_51873);
            _b_51873 = _1;
        }

        /** emit.e:1467			emit_addr(Pop())*/
        _26938 = _47Pop();
        _47emit_addr(_26938);
        _26938 = NOVALUE;

        /** emit.e:1468			emit_addr(b)*/
        _47emit_addr(_b_51873);

        /** emit.e:1469			emit_addr(c)*/
        _47emit_addr(_c_51874);

        /** emit.e:1470			assignable = FALSE*/
        _47assignable_50950 = _13FALSE_450;
        goto LC; // [5594] 7739

        /** emit.e:1473		case RHS_SLICE, FIND, MATCH, FIND_FROM, MATCH_FROM, SPLICE, INSERT, REMOVE, OPEN then*/
        case 46:
        case 77:
        case 78:
        case 176:
        case 177:
        case 190:
        case 191:
        case 200:
        case 37:

        /** emit.e:1474			emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1475			c = Pop()*/
        _c_51874 = _47Pop();
        if (!IS_ATOM_INT(_c_51874)) {
            _1 = (object)(DBL_PTR(_c_51874)->dbl);
            DeRefDS(_c_51874);
            _c_51874 = _1;
        }

        /** emit.e:1476			b = Pop()*/
        _b_51873 = _47Pop();
        if (!IS_ATOM_INT(_b_51873)) {
            _1 = (object)(DBL_PTR(_b_51873)->dbl);
            DeRefDS(_b_51873);
            _b_51873 = _1;
        }

        /** emit.e:1477			emit_addr(Pop())*/
        _26941 = _47Pop();
        _47emit_addr(_26941);
        _26941 = NOVALUE;

        /** emit.e:1478			emit_addr(b)*/
        _47emit_addr(_b_51873);

        /** emit.e:1479			emit_addr(c)*/
        _47emit_addr(_c_51874);

        /** emit.e:1480			c = NewTempSym()*/
        _c_51874 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_51874)) {
            _1 = (object)(DBL_PTR(_c_51874)->dbl);
            DeRefDS(_c_51874);
            _c_51874 = _1;
        }

        /** emit.e:1481			if op = FIND or op = FIND_FROM or op = OPEN then*/
        _26943 = (_op_51870 == 77LL);
        if (_26943 != 0) {
            _26944 = 1;
            goto L90; // [5669] 5683
        }
        _26945 = (_op_51870 == 176LL);
        _26944 = (_26945 != 0);
L90: 
        if (_26944 != 0) {
            goto L91; // [5683] 5698
        }
        _26947 = (_op_51870 == 37LL);
        if (_26947 == 0)
        {
            DeRef(_26947);
            _26947 = NOVALUE;
            goto L92; // [5694] 5706
        }
        else{
            DeRef(_26947);
            _26947 = NOVALUE;
        }
L91: 

        /** emit.e:1482				TempInteger( c )*/
        _47TempInteger(_c_51874);
        goto L93; // [5703] 5713
L92: 

        /** emit.e:1484				emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_51874, 1LL);
L93: 

        /** emit.e:1486			assignable = TRUE*/
        _47assignable_50950 = _13TRUE_452;

        /** emit.e:1487			Push(c)*/
        _47Push(_c_51874);

        /** emit.e:1488			emit_addr(c)*/
        _47emit_addr(_c_51874);
        goto LC; // [5730] 7739

        /** emit.e:1491		case CONCAT_N then     -- concatenate 3 or more items*/
        case 157:

        /** emit.e:1492			n = op_info1  -- number of items to concatenate*/
        _n_51883 = _47op_info1_50932;

        /** emit.e:1493			emit_opcode(CONCAT_N)*/
        _47emit_opcode(157LL);

        /** emit.e:1494			emit(n)*/
        _47emit(_n_51883);

        /** emit.e:1495			for i = 1 to n do*/
        _26948 = _n_51883;
        {
            object _i_53040;
            _i_53040 = 1LL;
L94: 
            if (_i_53040 > _26948){
                goto L95; // [5760] 5788
            }

            /** emit.e:1496				symtab_index element = Pop()*/
            _element_53043 = _47Pop();
            if (!IS_ATOM_INT(_element_53043)) {
                _1 = (object)(DBL_PTR(_element_53043)->dbl);
                DeRefDS(_element_53043);
                _element_53043 = _1;
            }

            /** emit.e:1497				emit_addr( element )  -- reverse order*/
            _47emit_addr(_element_53043);

            /** emit.e:1498			end for*/
            _i_53040 = _i_53040 + 1LL;
            goto L94; // [5783] 5767
L95: 
            ;
        }

        /** emit.e:1499			c = NewTempSym()*/
        _c_51874 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_51874)) {
            _1 = (object)(DBL_PTR(_c_51874)->dbl);
            DeRefDS(_c_51874);
            _c_51874 = _1;
        }

        /** emit.e:1500			emit_addr(c)*/
        _47emit_addr(_c_51874);

        /** emit.e:1501			emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_51874, 1LL);

        /** emit.e:1502			assignable = TRUE*/
        _47assignable_50950 = _13TRUE_452;

        /** emit.e:1503			Push(c)*/
        _47Push(_c_51874);
        goto LC; // [5819] 7739

        /** emit.e:1505		case FOR then*/
        case 21:

        /** emit.e:1506			c = Pop() -- increment*/
        _c_51874 = _47Pop();
        if (!IS_ATOM_INT(_c_51874)) {
            _1 = (object)(DBL_PTR(_c_51874)->dbl);
            DeRefDS(_c_51874);
            _c_51874 = _1;
        }

        /** emit.e:1507			TempKeep(c)*/
        _47TempKeep(_c_51874);

        /** emit.e:1508			ic = IsInteger(c)*/
        _ic_51882 = _47IsInteger(_c_51874);
        if (!IS_ATOM_INT(_ic_51882)) {
            _1 = (object)(DBL_PTR(_ic_51882)->dbl);
            DeRefDS(_ic_51882);
            _ic_51882 = _1;
        }

        /** emit.e:1509			if c < 1 or*/
        _26953 = (_c_51874 < 1LL);
        if (_26953 != 0) {
            goto L96; // [5851] 5930
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26955 = (object)*(((s1_ptr)_2)->base + _c_51874);
        _2 = (object)SEQ_PTR(_26955);
        _26956 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26955 = NOVALUE;
        if (IS_ATOM_INT(_26956)) {
            _26957 = (_26956 == 1LL);
        }
        else {
            _26957 = binary_op(EQUALS, _26956, 1LL);
        }
        _26956 = NOVALUE;
        if (IS_ATOM_INT(_26957)) {
            if (_26957 == 0) {
                DeRef(_26958);
                _26958 = 0;
                goto L97; // [5873] 5899
            }
        }
        else {
            if (DBL_PTR(_26957)->dbl == 0.0) {
                DeRef(_26958);
                _26958 = 0;
                goto L97; // [5873] 5899
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26959 = (object)*(((s1_ptr)_2)->base + _c_51874);
        _2 = (object)SEQ_PTR(_26959);
        _26960 = (object)*(((s1_ptr)_2)->base + 4LL);
        _26959 = NOVALUE;
        if (IS_ATOM_INT(_26960)) {
            _26961 = (_26960 != 2LL);
        }
        else {
            _26961 = binary_op(NOTEQ, _26960, 2LL);
        }
        _26960 = NOVALUE;
        DeRef(_26958);
        if (IS_ATOM_INT(_26961))
        _26958 = (_26961 != 0);
        else
        _26958 = DBL_PTR(_26961)->dbl != 0.0;
L97: 
        if (_26958 == 0) {
            DeRef(_26962);
            _26962 = 0;
            goto L98; // [5899] 5925
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26963 = (object)*(((s1_ptr)_2)->base + _c_51874);
        _2 = (object)SEQ_PTR(_26963);
        _26964 = (object)*(((s1_ptr)_2)->base + 4LL);
        _26963 = NOVALUE;
        if (IS_ATOM_INT(_26964)) {
            _26965 = (_26964 != 4LL);
        }
        else {
            _26965 = binary_op(NOTEQ, _26964, 4LL);
        }
        _26964 = NOVALUE;
        if (IS_ATOM_INT(_26965))
        _26962 = (_26965 != 0);
        else
        _26962 = DBL_PTR(_26965)->dbl != 0.0;
L98: 
        if (_26962 == 0)
        {
            _26962 = NOVALUE;
            goto L99; // [5926] 5967
        }
        else{
            _26962 = NOVALUE;
        }
L96: 

        /** emit.e:1514				emit_opcode(ASSIGN)*/
        _47emit_opcode(18LL);

        /** emit.e:1515				emit_addr(c)*/
        _47emit_addr(_c_51874);

        /** emit.e:1516				c = NewTempSym()*/
        _c_51874 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_51874)) {
            _1 = (object)(DBL_PTR(_c_51874)->dbl);
            DeRefDS(_c_51874);
            _c_51874 = _1;
        }

        /** emit.e:1517				if ic then*/
        if (_ic_51882 == 0)
        {
            goto L9A; // [5952] 5961
        }
        else{
        }

        /** emit.e:1518					TempInteger( c )*/
        _47TempInteger(_c_51874);
L9A: 

        /** emit.e:1520				emit_addr(c)*/
        _47emit_addr(_c_51874);
L99: 

        /** emit.e:1522			b = Pop() -- limit*/
        _b_51873 = _47Pop();
        if (!IS_ATOM_INT(_b_51873)) {
            _1 = (object)(DBL_PTR(_b_51873)->dbl);
            DeRefDS(_b_51873);
            _b_51873 = _1;
        }

        /** emit.e:1523			TempKeep(b)*/
        _47TempKeep(_b_51873);

        /** emit.e:1524			ib = IsInteger(b)*/
        _ib_51881 = _47IsInteger(_b_51873);
        if (!IS_ATOM_INT(_ib_51881)) {
            _1 = (object)(DBL_PTR(_ib_51881)->dbl);
            DeRefDS(_ib_51881);
            _ib_51881 = _1;
        }

        /** emit.e:1525			if b < 1 or*/
        _26969 = (_b_51873 < 1LL);
        if (_26969 != 0) {
            goto L9B; // [5993] 6072
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26971 = (object)*(((s1_ptr)_2)->base + _b_51873);
        _2 = (object)SEQ_PTR(_26971);
        _26972 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26971 = NOVALUE;
        if (IS_ATOM_INT(_26972)) {
            _26973 = (_26972 == 1LL);
        }
        else {
            _26973 = binary_op(EQUALS, _26972, 1LL);
        }
        _26972 = NOVALUE;
        if (IS_ATOM_INT(_26973)) {
            if (_26973 == 0) {
                DeRef(_26974);
                _26974 = 0;
                goto L9C; // [6015] 6041
            }
        }
        else {
            if (DBL_PTR(_26973)->dbl == 0.0) {
                DeRef(_26974);
                _26974 = 0;
                goto L9C; // [6015] 6041
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26975 = (object)*(((s1_ptr)_2)->base + _b_51873);
        _2 = (object)SEQ_PTR(_26975);
        _26976 = (object)*(((s1_ptr)_2)->base + 4LL);
        _26975 = NOVALUE;
        if (IS_ATOM_INT(_26976)) {
            _26977 = (_26976 != 2LL);
        }
        else {
            _26977 = binary_op(NOTEQ, _26976, 2LL);
        }
        _26976 = NOVALUE;
        DeRef(_26974);
        if (IS_ATOM_INT(_26977))
        _26974 = (_26977 != 0);
        else
        _26974 = DBL_PTR(_26977)->dbl != 0.0;
L9C: 
        if (_26974 == 0) {
            DeRef(_26978);
            _26978 = 0;
            goto L9D; // [6041] 6067
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _26979 = (object)*(((s1_ptr)_2)->base + _b_51873);
        _2 = (object)SEQ_PTR(_26979);
        _26980 = (object)*(((s1_ptr)_2)->base + 4LL);
        _26979 = NOVALUE;
        if (IS_ATOM_INT(_26980)) {
            _26981 = (_26980 != 4LL);
        }
        else {
            _26981 = binary_op(NOTEQ, _26980, 4LL);
        }
        _26980 = NOVALUE;
        if (IS_ATOM_INT(_26981))
        _26978 = (_26981 != 0);
        else
        _26978 = DBL_PTR(_26981)->dbl != 0.0;
L9D: 
        if (_26978 == 0)
        {
            _26978 = NOVALUE;
            goto L9E; // [6068] 6109
        }
        else{
            _26978 = NOVALUE;
        }
L9B: 

        /** emit.e:1530				emit_opcode(ASSIGN)*/
        _47emit_opcode(18LL);

        /** emit.e:1531				emit_addr(b)*/
        _47emit_addr(_b_51873);

        /** emit.e:1532				b = NewTempSym()*/
        _b_51873 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_b_51873)) {
            _1 = (object)(DBL_PTR(_b_51873)->dbl);
            DeRefDS(_b_51873);
            _b_51873 = _1;
        }

        /** emit.e:1533				if ib then*/
        if (_ib_51881 == 0)
        {
            goto L9F; // [6094] 6103
        }
        else{
        }

        /** emit.e:1534					TempInteger( b )*/
        _47TempInteger(_b_51873);
L9F: 

        /** emit.e:1536				emit_addr(b)*/
        _47emit_addr(_b_51873);
L9E: 

        /** emit.e:1538			a = Pop() -- initial value*/
        _a_51872 = _47Pop();
        if (!IS_ATOM_INT(_a_51872)) {
            _1 = (object)(DBL_PTR(_a_51872)->dbl);
            DeRefDS(_a_51872);
            _a_51872 = _1;
        }

        /** emit.e:1539			if IsInteger(a) and ib and ic then*/
        _26984 = _47IsInteger(_a_51872);
        if (IS_ATOM_INT(_26984)) {
            if (_26984 == 0) {
                DeRef(_26985);
                _26985 = 0;
                goto LA0; // [6122] 6130
            }
        }
        else {
            if (DBL_PTR(_26984)->dbl == 0.0) {
                DeRef(_26985);
                _26985 = 0;
                goto LA0; // [6122] 6130
            }
        }
        DeRef(_26985);
        _26985 = (_ib_51881 != 0);
LA0: 
        if (_26985 == 0) {
            goto LA1; // [6130] 6169
        }
        if (_ic_51882 == 0)
        {
            goto LA1; // [6135] 6169
        }
        else{
        }

        /** emit.e:1540				SymTab[op_info1][S_VTYPE] = integer_type*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_47op_info1_50932 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 15LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _54integer_type_46782;
        DeRef(_1);
        _26987 = NOVALUE;

        /** emit.e:1541				op = FOR_I*/
        _op_51870 = 125LL;
        goto LA2; // [6166] 6179
LA1: 

        /** emit.e:1543				op = FOR*/
        _op_51870 = 21LL;
LA2: 

        /** emit.e:1545			emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1546			emit_addr(c)*/
        _47emit_addr(_c_51874);

        /** emit.e:1547			emit_addr(b)*/
        _47emit_addr(_b_51873);

        /** emit.e:1548			emit_addr(a)*/
        _47emit_addr(_a_51872);

        /** emit.e:1549			emit_addr(CurrentSub) -- in case recursion check is needed*/
        _47emit_addr(_36CurrentSub_21447);

        /** emit.e:1550			Push(b)*/
        _47Push(_b_51873);

        /** emit.e:1551			Push(c)*/
        _47Push(_c_51874);

        /** emit.e:1552			assignable = FALSE*/
        _47assignable_50950 = _13FALSE_450;
        goto LC; // [6223] 7739

        /** emit.e:1555		case ENDFOR_GENERAL, ENDFOR_INT_UP1 then  -- all ENDFORs*/
        case 39:
        case 54:

        /** emit.e:1556			emit_opcode(op) -- will be patched at runtime*/
        _47emit_opcode(_op_51870);

        /** emit.e:1557			a = Pop()*/
        _a_51872 = _47Pop();
        if (!IS_ATOM_INT(_a_51872)) {
            _1 = (object)(DBL_PTR(_a_51872)->dbl);
            DeRefDS(_a_51872);
            _a_51872 = _1;
        }

        /** emit.e:1558			emit_addr(op_info2) -- address of top of loop*/
        _47emit_addr(_47op_info2_50933);

        /** emit.e:1559			emit_addr(Pop())    -- limit*/
        _26990 = _47Pop();
        _47emit_addr(_26990);
        _26990 = NOVALUE;

        /** emit.e:1560			emit_addr(op_info1) -- loop var*/
        _47emit_addr(_47op_info1_50932);

        /** emit.e:1561			emit_addr(a)        -- increment - not always used -*/
        _47emit_addr(_a_51872);

        /** emit.e:1563			assignable = FALSE*/
        _47assignable_50950 = _13FALSE_450;
        goto LC; // [6277] 7739

        /** emit.e:1566		case ASSIGN_OP_SUBS, PASSIGN_OP_SUBS then*/
        case 149:
        case 164:

        /** emit.e:1568			b = Pop()      -- rhs value, keep on stack*/
        _b_51873 = _47Pop();
        if (!IS_ATOM_INT(_b_51873)) {
            _1 = (object)(DBL_PTR(_b_51873)->dbl);
            DeRefDS(_b_51873);
            _b_51873 = _1;
        }

        /** emit.e:1569			TempKeep(b)*/
        _47TempKeep(_b_51873);

        /** emit.e:1571			a = Pop()      -- subscript, keep on stack*/
        _a_51872 = _47Pop();
        if (!IS_ATOM_INT(_a_51872)) {
            _1 = (object)(DBL_PTR(_a_51872)->dbl);
            DeRefDS(_a_51872);
            _a_51872 = _1;
        }

        /** emit.e:1572			TempKeep(a)*/
        _47TempKeep(_a_51872);

        /** emit.e:1574			c = Pop()      -- lhs sequence, keep on stack*/
        _c_51874 = _47Pop();
        if (!IS_ATOM_INT(_c_51874)) {
            _1 = (object)(DBL_PTR(_c_51874)->dbl);
            DeRefDS(_c_51874);
            _c_51874 = _1;
        }

        /** emit.e:1575			TempKeep(c)*/
        _47TempKeep(_c_51874);

        /** emit.e:1577			emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1578			emit_addr(c)*/
        _47emit_addr(_c_51874);

        /** emit.e:1579			emit_addr(a)*/
        _47emit_addr(_a_51872);

        /** emit.e:1581			d = NewTempSym()*/
        _d_51875 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_d_51875)) {
            _1 = (object)(DBL_PTR(_d_51875)->dbl);
            DeRefDS(_d_51875);
            _d_51875 = _1;
        }

        /** emit.e:1582			emit_addr(d)   -- place to store result*/
        _47emit_addr(_d_51875);

        /** emit.e:1583			emit_temp( d, NEW_REFERENCE )*/
        _47emit_temp(_d_51875, 1LL);

        /** emit.e:1585			Push(c)*/
        _47Push(_c_51874);

        /** emit.e:1586			Push(a)*/
        _47Push(_a_51872);

        /** emit.e:1587			Push(d)*/
        _47Push(_d_51875);

        /** emit.e:1588			Push(b)*/
        _47Push(_b_51873);

        /** emit.e:1589			assignable = FALSE*/
        _47assignable_50950 = _13FALSE_450;
        goto LC; // [6382] 7739

        /** emit.e:1592		case ASSIGN_SLICE, PASSIGN_SLICE then*/
        case 45:
        case 163:

        /** emit.e:1593			emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1594			b = Pop() -- rhs value*/
        _b_51873 = _47Pop();
        if (!IS_ATOM_INT(_b_51873)) {
            _1 = (object)(DBL_PTR(_b_51873)->dbl);
            DeRefDS(_b_51873);
            _b_51873 = _1;
        }

        /** emit.e:1595			a = Pop() -- 2nd subs*/
        _a_51872 = _47Pop();
        if (!IS_ATOM_INT(_a_51872)) {
            _1 = (object)(DBL_PTR(_a_51872)->dbl);
            DeRefDS(_a_51872);
            _a_51872 = _1;
        }

        /** emit.e:1596			c = Pop() -- 1st subs*/
        _c_51874 = _47Pop();
        if (!IS_ATOM_INT(_c_51874)) {
            _1 = (object)(DBL_PTR(_c_51874)->dbl);
            DeRefDS(_c_51874);
            _c_51874 = _1;
        }

        /** emit.e:1597			emit_addr(Pop()) -- sequence*/
        _26998 = _47Pop();
        _47emit_addr(_26998);
        _26998 = NOVALUE;

        /** emit.e:1598			emit_addr(c)*/
        _47emit_addr(_c_51874);

        /** emit.e:1599			emit_addr(a)*/
        _47emit_addr(_a_51872);

        /** emit.e:1600			emit_addr(b)*/
        _47emit_addr(_b_51873);

        /** emit.e:1601			assignable = FALSE*/
        _47assignable_50950 = _13FALSE_450;
        goto LC; // [6446] 7739

        /** emit.e:1604		case REPLACE then*/
        case 201:

        /** emit.e:1605			emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1607			b = Pop()  -- source*/
        _b_51873 = _47Pop();
        if (!IS_ATOM_INT(_b_51873)) {
            _1 = (object)(DBL_PTR(_b_51873)->dbl);
            DeRefDS(_b_51873);
            _b_51873 = _1;
        }

        /** emit.e:1608			a = Pop()  -- replacement*/
        _a_51872 = _47Pop();
        if (!IS_ATOM_INT(_a_51872)) {
            _1 = (object)(DBL_PTR(_a_51872)->dbl);
            DeRefDS(_a_51872);
            _a_51872 = _1;
        }

        /** emit.e:1609			c = Pop()  -- start of replaced slice*/
        _c_51874 = _47Pop();
        if (!IS_ATOM_INT(_c_51874)) {
            _1 = (object)(DBL_PTR(_c_51874)->dbl);
            DeRefDS(_c_51874);
            _c_51874 = _1;
        }

        /** emit.e:1610			d = Pop()  -- end of replaced slice*/
        _d_51875 = _47Pop();
        if (!IS_ATOM_INT(_d_51875)) {
            _1 = (object)(DBL_PTR(_d_51875)->dbl);
            DeRefDS(_d_51875);
            _d_51875 = _1;
        }

        /** emit.e:1611			emit_addr(d)*/
        _47emit_addr(_d_51875);

        /** emit.e:1612			emit_addr(c)*/
        _47emit_addr(_c_51874);

        /** emit.e:1613			emit_addr(a)*/
        _47emit_addr(_a_51872);

        /** emit.e:1614			emit_addr(b)*/
        _47emit_addr(_b_51873);

        /** emit.e:1616			c = NewTempSym()*/
        _c_51874 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_51874)) {
            _1 = (object)(DBL_PTR(_c_51874)->dbl);
            DeRefDS(_c_51874);
            _c_51874 = _1;
        }

        /** emit.e:1617			Push(c)*/
        _47Push(_c_51874);

        /** emit.e:1618			emit_addr(c)     -- place to store result*/
        _47emit_addr(_c_51874);

        /** emit.e:1619			emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_51874, 1LL);

        /** emit.e:1620			assignable = TRUE*/
        _47assignable_50950 = _13TRUE_452;
        goto LC; // [6536] 7739

        /** emit.e:1623		case ASSIGN_OP_SLICE, PASSIGN_OP_SLICE then*/
        case 150:
        case 165:

        /** emit.e:1625			emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1627			b = Pop()        -- rhs value not used*/
        _b_51873 = _47Pop();
        if (!IS_ATOM_INT(_b_51873)) {
            _1 = (object)(DBL_PTR(_b_51873)->dbl);
            DeRefDS(_b_51873);
            _b_51873 = _1;
        }

        /** emit.e:1628			TempKeep(b)*/
        _47TempKeep(_b_51873);

        /** emit.e:1630			a = Pop()        -- 2nd subs*/
        _a_51872 = _47Pop();
        if (!IS_ATOM_INT(_a_51872)) {
            _1 = (object)(DBL_PTR(_a_51872)->dbl);
            DeRefDS(_a_51872);
            _a_51872 = _1;
        }

        /** emit.e:1631			TempKeep(a)*/
        _47TempKeep(_a_51872);

        /** emit.e:1633			c = Pop()        -- 1st subs*/
        _c_51874 = _47Pop();
        if (!IS_ATOM_INT(_c_51874)) {
            _1 = (object)(DBL_PTR(_c_51874)->dbl);
            DeRefDS(_c_51874);
            _c_51874 = _1;
        }

        /** emit.e:1634			TempKeep(c)*/
        _47TempKeep(_c_51874);

        /** emit.e:1636			d = Pop()*/
        _d_51875 = _47Pop();
        if (!IS_ATOM_INT(_d_51875)) {
            _1 = (object)(DBL_PTR(_d_51875)->dbl);
            DeRefDS(_d_51875);
            _d_51875 = _1;
        }

        /** emit.e:1637			TempKeep(d)      -- sequence*/
        _47TempKeep(_d_51875);

        /** emit.e:1639			emit_addr(d)*/
        _47emit_addr(_d_51875);

        /** emit.e:1640			Push(d)*/
        _47Push(_d_51875);

        /** emit.e:1642			emit_addr(c)*/
        _47emit_addr(_c_51874);

        /** emit.e:1643			Push(c)*/
        _47Push(_c_51874);

        /** emit.e:1645			emit_addr(a)*/
        _47emit_addr(_a_51872);

        /** emit.e:1646			Push(a)*/
        _47Push(_a_51872);

        /** emit.e:1648			c = NewTempSym()*/
        _c_51874 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_51874)) {
            _1 = (object)(DBL_PTR(_c_51874)->dbl);
            DeRefDS(_c_51874);
            _c_51874 = _1;
        }

        /** emit.e:1649			Push(c)*/
        _47Push(_c_51874);

        /** emit.e:1650			emit_addr(c)     -- place to store result*/
        _47emit_addr(_c_51874);

        /** emit.e:1651			emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_51874, 1LL);

        /** emit.e:1653			Push(b)*/
        _47Push(_b_51873);

        /** emit.e:1654			assignable = FALSE*/
        _47assignable_50950 = _13FALSE_450;
        goto LC; // [6663] 7739

        /** emit.e:1657		case CALL_PROC then*/
        case 136:

        /** emit.e:1658			emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1659			b = Pop()*/
        _b_51873 = _47Pop();
        if (!IS_ATOM_INT(_b_51873)) {
            _1 = (object)(DBL_PTR(_b_51873)->dbl);
            DeRefDS(_b_51873);
            _b_51873 = _1;
        }

        /** emit.e:1660			emit_addr(Pop())*/
        _27010 = _47Pop();
        _47emit_addr(_27010);
        _27010 = NOVALUE;

        /** emit.e:1661			emit_addr(b)*/
        _47emit_addr(_b_51873);

        /** emit.e:1662			assignable = FALSE*/
        _47assignable_50950 = _13FALSE_450;
        goto LC; // [6701] 7739

        /** emit.e:1664		case CALL_FUNC then*/
        case 137:

        /** emit.e:1665			emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1666			b = Pop()*/
        _b_51873 = _47Pop();
        if (!IS_ATOM_INT(_b_51873)) {
            _1 = (object)(DBL_PTR(_b_51873)->dbl);
            DeRefDS(_b_51873);
            _b_51873 = _1;
        }

        /** emit.e:1667			emit_addr(Pop())*/
        _27012 = _47Pop();
        _47emit_addr(_27012);
        _27012 = NOVALUE;

        /** emit.e:1668			emit_addr(b)*/
        _47emit_addr(_b_51873);

        /** emit.e:1669			assignable = TRUE*/
        _47assignable_50950 = _13TRUE_452;

        /** emit.e:1670			c = NewTempSym()*/
        _c_51874 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_51874)) {
            _1 = (object)(DBL_PTR(_c_51874)->dbl);
            DeRefDS(_c_51874);
            _c_51874 = _1;
        }

        /** emit.e:1671			Push(c)*/
        _47Push(_c_51874);

        /** emit.e:1672			emit_addr(c)*/
        _47emit_addr(_c_51874);

        /** emit.e:1673			emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_51874, 1LL);
        goto LC; // [6763] 7739

        /** emit.e:1675		case EXIT_BLOCK then*/
        case 206:

        /** emit.e:1676			emit_opcode( op )*/
        _47emit_opcode(_op_51870);

        /** emit.e:1677			emit_addr( Pop() )*/
        _27014 = _47Pop();
        _47emit_addr(_27014);
        _27014 = NOVALUE;

        /** emit.e:1678			assignable = FALSE*/
        _47assignable_50950 = _13FALSE_450;
        goto LC; // [6789] 7739

        /** emit.e:1680		case RETURNP then*/
        case 29:

        /** emit.e:1681			emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1682			emit_addr(CurrentSub)*/
        _47emit_addr(_36CurrentSub_21447);

        /** emit.e:1683			emit_addr(top_block())*/
        _27015 = _65top_block(0LL);
        _47emit_addr(_27015);
        _27015 = NOVALUE;

        /** emit.e:1684			assignable = FALSE*/
        _47assignable_50950 = _13FALSE_450;
        goto LC; // [6823] 7739

        /** emit.e:1686		case RETURNF then*/
        case 28:

        /** emit.e:1687			clear_temp( Top() )*/

        /** emit.e:145		return cg_stack[cgi]*/
        DeRef(_Top_inlined_Top_at_7037_53190);
        _2 = (object)SEQ_PTR(_47cg_stack_50947);
        _Top_inlined_Top_at_7037_53190 = (object)*(((s1_ptr)_2)->base + _47cgi_50948);
        Ref(_Top_inlined_Top_at_7037_53190);
        Ref(_Top_inlined_Top_at_7037_53190);
        _47clear_temp(_Top_inlined_Top_at_7037_53190);

        /** emit.e:1688			flush_temps()*/
        RefDS(_21993);
        _47flush_temps(_21993);

        /** emit.e:1689			emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1690			emit_addr(CurrentSub)*/
        _47emit_addr(_36CurrentSub_21447);

        /** emit.e:1691			emit_addr(Least_block())*/
        _27016 = _65Least_block();
        _47emit_addr(_27016);
        _27016 = NOVALUE;

        /** emit.e:1692			emit_addr(Pop())*/
        _27017 = _47Pop();
        _47emit_addr(_27017);
        _27017 = NOVALUE;

        /** emit.e:1693			assignable = FALSE*/
        _47assignable_50950 = _13FALSE_450;
        goto LC; // [6885] 7739

        /** emit.e:1695		case RETURNT then*/
        case 34:

        /** emit.e:1696			emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1697			assignable = FALSE*/
        _47assignable_50950 = _13FALSE_450;
        goto LC; // [6903] 7739

        /** emit.e:1699		case DATE, TIME, SPACE_USED, GET_KEY, TASK_LIST,*/
        case 69:
        case 70:
        case 75:
        case 79:
        case 172:
        case 100:
        case 183:

        /** emit.e:1701			emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1702			c = NewTempSym()*/
        _c_51874 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_51874)) {
            _1 = (object)(DBL_PTR(_c_51874)->dbl);
            DeRefDS(_c_51874);
            _c_51874 = _1;
        }

        /** emit.e:1703			assignable = TRUE*/
        _47assignable_50950 = _13TRUE_452;

        /** emit.e:1704			if op = GET_KEY then  -- it's in op_result as integer*/
        if (_op_51870 != 79LL)
        goto LA3; // [6945] 6957

        /** emit.e:1705				TempInteger(c)*/
        _47TempInteger(_c_51874);
        goto LA4; // [6954] 6964
LA3: 

        /** emit.e:1707				emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_51874, 1LL);
LA4: 

        /** emit.e:1709			Push(c)*/
        _47Push(_c_51874);

        /** emit.e:1710			emit_addr(c)*/
        _47emit_addr(_c_51874);
        goto LC; // [6974] 7739

        /** emit.e:1712		case CLOSE, ABORT, CALL, DELETE_OBJECT then*/
        case 86:
        case 126:
        case 129:
        case 205:

        /** emit.e:1713			emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1714			emit_addr(Pop())*/
        _27020 = _47Pop();
        _47emit_addr(_27020);
        _27020 = NOVALUE;

        /** emit.e:1715			assignable = FALSE*/
        _47assignable_50950 = _13FALSE_450;
        goto LC; // [7006] 7739

        /** emit.e:1717		case POWER then*/
        case 72:

        /** emit.e:1719			b = Pop()*/
        _b_51873 = _47Pop();
        if (!IS_ATOM_INT(_b_51873)) {
            _1 = (object)(DBL_PTR(_b_51873)->dbl);
            DeRefDS(_b_51873);
            _b_51873 = _1;
        }

        /** emit.e:1720			a = Pop()*/
        _a_51872 = _47Pop();
        if (!IS_ATOM_INT(_a_51872)) {
            _1 = (object)(DBL_PTR(_a_51872)->dbl);
            DeRefDS(_a_51872);
            _a_51872 = _1;
        }

        /** emit.e:1721			if b > 0 and SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 2) then*/
        _27023 = (_b_51873 > 0LL);
        if (_27023 == 0) {
            _27024 = 0;
            goto LA5; // [7032] 7058
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27025 = (object)*(((s1_ptr)_2)->base + _b_51873);
        _2 = (object)SEQ_PTR(_27025);
        _27026 = (object)*(((s1_ptr)_2)->base + 3LL);
        _27025 = NOVALUE;
        if (IS_ATOM_INT(_27026)) {
            _27027 = (_27026 == 2LL);
        }
        else {
            _27027 = binary_op(EQUALS, _27026, 2LL);
        }
        _27026 = NOVALUE;
        if (IS_ATOM_INT(_27027))
        _27024 = (_27027 != 0);
        else
        _27024 = DBL_PTR(_27027)->dbl != 0.0;
LA5: 
        if (_27024 == 0) {
            goto LA6; // [7058] 7115
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27029 = (object)*(((s1_ptr)_2)->base + _b_51873);
        _2 = (object)SEQ_PTR(_27029);
        _27030 = (object)*(((s1_ptr)_2)->base + 1LL);
        _27029 = NOVALUE;
        if (_27030 == 2LL)
        _27031 = 1;
        else if (IS_ATOM_INT(_27030) && IS_ATOM_INT(2LL))
        _27031 = 0;
        else
        _27031 = (compare(_27030, 2LL) == 0);
        _27030 = NOVALUE;
        if (_27031 == 0)
        {
            _27031 = NOVALUE;
            goto LA6; // [7079] 7115
        }
        else{
            _27031 = NOVALUE;
        }

        /** emit.e:1723				op = rw:MULTIPLY*/
        _op_51870 = 13LL;

        /** emit.e:1724				emit_opcode(op)*/
        _47emit_opcode(13LL);

        /** emit.e:1725				emit_addr(a)*/
        _47emit_addr(_a_51872);

        /** emit.e:1726				emit_addr(a)*/
        _47emit_addr(_a_51872);

        /** emit.e:1727				cont21d(op, a, b, FALSE)*/
        _47cont21d(13LL, _a_51872, _b_51873, _13FALSE_450);
        goto LC; // [7112] 7739
LA6: 

        /** emit.e:1729				Push(a)*/
        _47Push(_a_51872);

        /** emit.e:1730				Push(b)*/
        _47Push(_b_51873);

        /** emit.e:1731				cont21ii(op, FALSE)*/
        _47cont21ii(_op_51870, _13FALSE_450);
        goto LC; // [7134] 7739

        /** emit.e:1735		case TYPE_CHECK then*/
        case 65:

        /** emit.e:1736			emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1737			c = Pop()*/
        _c_51874 = _47Pop();
        if (!IS_ATOM_INT(_c_51874)) {
            _1 = (object)(DBL_PTR(_c_51874)->dbl);
            DeRefDS(_c_51874);
            _c_51874 = _1;
        }

        /** emit.e:1738			assignable = FALSE*/
        _47assignable_50950 = _13FALSE_450;
        goto LC; // [7159] 7739

        /** emit.e:1741		case DOLLAR then*/
        case -22:

        /** emit.e:1742			if current_sequence[$] < 0 or SymTab[current_sequence[$]][S_SCOPE] = SC_UNDEFINED then*/
        if (IS_SEQUENCE(_47current_sequence_50940)){
                _27033 = SEQ_PTR(_47current_sequence_50940)->length;
        }
        else {
            _27033 = 1;
        }
        _2 = (object)SEQ_PTR(_47current_sequence_50940);
        _27034 = (object)*(((s1_ptr)_2)->base + _27033);
        if (IS_ATOM_INT(_27034)) {
            _27035 = (_27034 < 0LL);
        }
        else {
            _27035 = binary_op(LESS, _27034, 0LL);
        }
        _27034 = NOVALUE;
        if (IS_ATOM_INT(_27035)) {
            if (_27035 != 0) {
                goto LA7; // [7180] 7216
            }
        }
        else {
            if (DBL_PTR(_27035)->dbl != 0.0) {
                goto LA7; // [7180] 7216
            }
        }
        if (IS_SEQUENCE(_47current_sequence_50940)){
                _27037 = SEQ_PTR(_47current_sequence_50940)->length;
        }
        else {
            _27037 = 1;
        }
        _2 = (object)SEQ_PTR(_47current_sequence_50940);
        _27038 = (object)*(((s1_ptr)_2)->base + _27037);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!IS_ATOM_INT(_27038)){
            _27039 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27038)->dbl));
        }
        else{
            _27039 = (object)*(((s1_ptr)_2)->base + _27038);
        }
        _2 = (object)SEQ_PTR(_27039);
        _27040 = (object)*(((s1_ptr)_2)->base + 4LL);
        _27039 = NOVALUE;
        if (IS_ATOM_INT(_27040)) {
            _27041 = (_27040 == 9LL);
        }
        else {
            _27041 = binary_op(EQUALS, _27040, 9LL);
        }
        _27040 = NOVALUE;
        if (_27041 == 0) {
            DeRef(_27041);
            _27041 = NOVALUE;
            goto LA8; // [7212] 7286
        }
        else {
            if (!IS_ATOM_INT(_27041) && DBL_PTR(_27041)->dbl == 0.0){
                DeRef(_27041);
                _27041 = NOVALUE;
                goto LA8; // [7212] 7286
            }
            DeRef(_27041);
            _27041 = NOVALUE;
        }
        DeRef(_27041);
        _27041 = NOVALUE;
LA7: 

        /** emit.e:1743				if lhs_ptr and length(current_sequence) = 1 then*/
        if (_47lhs_ptr_50942 == 0) {
            goto LA9; // [7220] 7249
        }
        if (IS_SEQUENCE(_47current_sequence_50940)){
                _27043 = SEQ_PTR(_47current_sequence_50940)->length;
        }
        else {
            _27043 = 1;
        }
        _27044 = (_27043 == 1LL);
        _27043 = NOVALUE;
        if (_27044 == 0)
        {
            DeRef(_27044);
            _27044 = NOVALUE;
            goto LA9; // [7234] 7249
        }
        else{
            DeRef(_27044);
            _27044 = NOVALUE;
        }

        /** emit.e:1744					c = PLENGTH*/
        _c_51874 = 160LL;
        goto LAA; // [7246] 7259
LA9: 

        /** emit.e:1746					c = LENGTH*/
        _c_51874 = 42LL;
LAA: 

        /** emit.e:1748				c = - new_forward_reference( VARIABLE, current_sequence[$], c )*/
        if (IS_SEQUENCE(_47current_sequence_50940)){
                _27045 = SEQ_PTR(_47current_sequence_50940)->length;
        }
        else {
            _27045 = 1;
        }
        _2 = (object)SEQ_PTR(_47current_sequence_50940);
        _27046 = (object)*(((s1_ptr)_2)->base + _27045);
        Ref(_27046);
        _27047 = _44new_forward_reference(-100LL, _27046, _c_51874);
        _27046 = NOVALUE;
        if (IS_ATOM_INT(_27047)) {
            if ((uintptr_t)_27047 == (uintptr_t)HIGH_BITS){
                _c_51874 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _c_51874 = - _27047;
            }
        }
        else {
            _c_51874 = unary_op(UMINUS, _27047);
        }
        DeRef(_27047);
        _27047 = NOVALUE;
        if (!IS_ATOM_INT(_c_51874)) {
            _1 = (object)(DBL_PTR(_c_51874)->dbl);
            DeRefDS(_c_51874);
            _c_51874 = _1;
        }
        goto LAB; // [7283] 7300
LA8: 

        /** emit.e:1750				c = current_sequence[$]*/
        if (IS_SEQUENCE(_47current_sequence_50940)){
                _27049 = SEQ_PTR(_47current_sequence_50940)->length;
        }
        else {
            _27049 = 1;
        }
        _2 = (object)SEQ_PTR(_47current_sequence_50940);
        _c_51874 = (object)*(((s1_ptr)_2)->base + _27049);
        if (!IS_ATOM_INT(_c_51874)){
            _c_51874 = (object)DBL_PTR(_c_51874)->dbl;
        }
LAB: 

        /** emit.e:1754			if lhs_ptr and length(current_sequence) = 1 then*/
        if (_47lhs_ptr_50942 == 0) {
            goto LAC; // [7304] 7331
        }
        if (IS_SEQUENCE(_47current_sequence_50940)){
                _27052 = SEQ_PTR(_47current_sequence_50940)->length;
        }
        else {
            _27052 = 1;
        }
        _27053 = (_27052 == 1LL);
        _27052 = NOVALUE;
        if (_27053 == 0)
        {
            DeRef(_27053);
            _27053 = NOVALUE;
            goto LAC; // [7318] 7331
        }
        else{
            DeRef(_27053);
            _27053 = NOVALUE;
        }

        /** emit.e:1755				emit_opcode(PLENGTH)*/
        _47emit_opcode(160LL);
        goto LAD; // [7328] 7339
LAC: 

        /** emit.e:1757				emit_opcode(LENGTH)*/
        _47emit_opcode(42LL);
LAD: 

        /** emit.e:1760			emit_addr( c )*/
        _47emit_addr(_c_51874);

        /** emit.e:1762			c = NewTempSym()*/
        _c_51874 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_51874)) {
            _1 = (object)(DBL_PTR(_c_51874)->dbl);
            DeRefDS(_c_51874);
            _c_51874 = _1;
        }

        /** emit.e:1763			TempInteger(c)*/
        _47TempInteger(_c_51874);

        /** emit.e:1764			Push(c)*/
        _47Push(_c_51874);

        /** emit.e:1765			emit_addr(c)*/
        _47emit_addr(_c_51874);

        /** emit.e:1766			assignable = FALSE -- it wouldn't be assigned anyway*/
        _47assignable_50950 = _13FALSE_450;
        goto LC; // [7374] 7739

        /** emit.e:1769		case TASK_SELF then*/
        case 170:

        /** emit.e:1770			c = NewTempSym()*/
        _c_51874 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_51874)) {
            _1 = (object)(DBL_PTR(_c_51874)->dbl);
            DeRefDS(_c_51874);
            _c_51874 = _1;
        }

        /** emit.e:1771			Push(c)*/
        _47Push(_c_51874);

        /** emit.e:1772			emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1773			emit_addr(c)*/
        _47emit_addr(_c_51874);

        /** emit.e:1774			assignable = TRUE*/
        _47assignable_50950 = _13TRUE_452;
        goto LC; // [7410] 7739

        /** emit.e:1776		case SWITCH then*/
        case 185:

        /** emit.e:1777			emit_opcode( op )*/
        _47emit_opcode(_op_51870);

        /** emit.e:1778			c = Pop()*/
        _c_51874 = _47Pop();
        if (!IS_ATOM_INT(_c_51874)) {
            _1 = (object)(DBL_PTR(_c_51874)->dbl);
            DeRefDS(_c_51874);
            _c_51874 = _1;
        }

        /** emit.e:1779			b = Pop()*/
        _b_51873 = _47Pop();
        if (!IS_ATOM_INT(_b_51873)) {
            _1 = (object)(DBL_PTR(_b_51873)->dbl);
            DeRefDS(_b_51873);
            _b_51873 = _1;
        }

        /** emit.e:1780			a = Pop()*/
        _a_51872 = _47Pop();
        if (!IS_ATOM_INT(_a_51872)) {
            _1 = (object)(DBL_PTR(_a_51872)->dbl);
            DeRefDS(_a_51872);
            _a_51872 = _1;
        }

        /** emit.e:1781			emit_addr( a ) -- Switch Expr*/
        _47emit_addr(_a_51872);

        /** emit.e:1782			emit_addr( b ) -- Case values*/
        _47emit_addr(_b_51873);

        /** emit.e:1783			emit_addr( c ) -- Jump table*/
        _47emit_addr(_c_51874);

        /** emit.e:1785			assignable = FALSE*/
        _47assignable_50950 = _13FALSE_450;
        goto LC; // [7464] 7739

        /** emit.e:1787		case CASE then*/
        case 186:

        /** emit.e:1789			emit_opcode( op )*/
        _47emit_opcode(_op_51870);

        /** emit.e:1790			emit( cg_stack[cgi] )  -- the case index*/
        _2 = (object)SEQ_PTR(_47cg_stack_50947);
        _27059 = (object)*(((s1_ptr)_2)->base + _47cgi_50948);
        Ref(_27059);
        _47emit(_27059);
        _27059 = NOVALUE;

        /** emit.e:1791			cgi -= 1*/
        _47cgi_50948 = _47cgi_50948 - 1LL;
        goto LC; // [7496] 7739

        /** emit.e:1794		case PLATFORM then*/
        case 155:

        /** emit.e:1795			if BIND and shroud_only then*/
        if (_36BIND_21044 == 0) {
            goto LAE; // [7506] 7554
        }
        if (_36shroud_only_21437 == 0)
        {
            goto LAE; // [7513] 7554
        }
        else{
        }

        /** emit.e:1797				c = NewTempSym()*/
        _c_51874 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_51874)) {
            _1 = (object)(DBL_PTR(_c_51874)->dbl);
            DeRefDS(_c_51874);
            _c_51874 = _1;
        }

        /** emit.e:1798				TempInteger(c)*/
        _47TempInteger(_c_51874);

        /** emit.e:1799				Push(c)*/
        _47Push(_c_51874);

        /** emit.e:1800				emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1801				emit_addr(c)*/
        _47emit_addr(_c_51874);

        /** emit.e:1802				assignable = TRUE*/
        _47assignable_50950 = _13TRUE_452;
        goto LC; // [7551] 7739
LAE: 

        /** emit.e:1806				n = host_platform()*/
        _n_51883 = _46host_platform();
        if (!IS_ATOM_INT(_n_51883)) {
            _1 = (object)(DBL_PTR(_n_51883)->dbl);
            DeRefDS(_n_51883);
            _n_51883 = _1;
        }

        /** emit.e:1807				Push(NewIntSym(n))*/
        _27064 = _54NewIntSym(_n_51883);
        _47Push(_27064);
        _27064 = NOVALUE;

        /** emit.e:1808				assignable = FALSE*/
        _47assignable_50950 = _13FALSE_450;
        goto LC; // [7578] 7739

        /** emit.e:1812		case PROFILE, TASK_SUSPEND then*/
        case 151:
        case 171:

        /** emit.e:1813			a = Pop()*/
        _a_51872 = _47Pop();
        if (!IS_ATOM_INT(_a_51872)) {
            _1 = (object)(DBL_PTR(_a_51872)->dbl);
            DeRefDS(_a_51872);
            _a_51872 = _1;
        }

        /** emit.e:1814			emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1815			emit_addr(a)*/
        _47emit_addr(_a_51872);

        /** emit.e:1816			assignable = FALSE*/
        _47assignable_50950 = _13FALSE_450;
        goto LC; // [7610] 7739

        /** emit.e:1818		case TRACE then*/
        case 64:

        /** emit.e:1819			a = Pop()*/
        _a_51872 = _47Pop();
        if (!IS_ATOM_INT(_a_51872)) {
            _1 = (object)(DBL_PTR(_a_51872)->dbl);
            DeRefDS(_a_51872);
            _a_51872 = _1;
        }

        /** emit.e:1820			if OpTrace then*/
        if (_36OpTrace_21512 == 0)
        {
            goto LAF; // [7627] 7673
        }
        else{
        }

        /** emit.e:1822				emit_opcode(op)*/
        _47emit_opcode(_op_51870);

        /** emit.e:1823				emit_addr(a)*/
        _47emit_addr(_a_51872);

        /** emit.e:1824				if TRANSLATE then*/
        if (_36TRANSLATE_21041 == 0)
        {
            goto LB0; // [7644] 7672
        }
        else{
        }

        /** emit.e:1825					if not trace_called then*/
        if (_47trace_called_50935 != 0)
        goto LB1; // [7651] 7662

        /** emit.e:1826						Warning(217,0)*/
        RefDS(_21993);
        _50Warning(217LL, 0LL, _21993);
LB1: 

        /** emit.e:1828					trace_called = TRUE*/
        _47trace_called_50935 = _13TRUE_452;
LB0: 
LAF: 

        /** emit.e:1831			assignable = FALSE*/
        _47assignable_50950 = _13FALSE_450;
        goto LC; // [7680] 7739

        /** emit.e:1833		case REF_TEMP then*/
        case 207:

        /** emit.e:1835			emit_opcode( REF_TEMP )*/
        _47emit_opcode(207LL);

        /** emit.e:1836			emit_addr( Pop() )*/
        _27068 = _47Pop();
        _47emit_addr(_27068);
        _27068 = NOVALUE;
        goto LC; // [7701] 7739

        /** emit.e:1838		case DEREF_TEMP then*/
        case 208:

        /** emit.e:1839			emit_opcode( DEREF_TEMP )*/
        _47emit_opcode(208LL);

        /** emit.e:1840			emit_addr( Pop() )*/
        _27069 = _47Pop();
        _47emit_addr(_27069);
        _27069 = NOVALUE;
        goto LC; // [7722] 7739

        /** emit.e:1842		case else*/
        default:

        /** emit.e:1843			InternalErr(259, {op})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _op_51870;
        _27070 = MAKE_SEQ(_1);
        _50InternalErr(259LL, _27070);
        _27070 = NOVALUE;
    ;}LC: 

    /** emit.e:1847		previous_op = op*/
    _36previous_op_21541 = _op_51870;

    /** emit.e:1848		inlined = 0*/
    _47inlined_51848 = 0LL;

    /** emit.e:1850	end procedure*/
    DeRef(_obj_51884);
    DeRef(_elements_51885);
    DeRef(_element_vals_51886);
    DeRef(_26775);
    _26775 = NOVALUE;
    _26558 = NOVALUE;
    DeRef(_26916);
    _26916 = NOVALUE;
    DeRef(_27035);
    _27035 = NOVALUE;
    DeRef(_26912);
    _26912 = NOVALUE;
    DeRef(_26675);
    _26675 = NOVALUE;
    DeRef(_26777);
    _26777 = NOVALUE;
    DeRef(_26667);
    _26667 = NOVALUE;
    DeRef(_26581);
    _26581 = NOVALUE;
    DeRef(_26906);
    _26906 = NOVALUE;
    DeRef(_26560);
    _26560 = NOVALUE;
    DeRef(_26541);
    _26541 = NOVALUE;
    DeRef(_26743);
    _26743 = NOVALUE;
    DeRef(_26981);
    _26981 = NOVALUE;
    DeRef(_26556);
    _26556 = NOVALUE;
    DeRef(_26943);
    _26943 = NOVALUE;
    DeRef(_26728);
    _26728 = NOVALUE;
    DeRef(_26702);
    _26702 = NOVALUE;
    DeRef(_26537);
    _26537 = NOVALUE;
    DeRef(_26621);
    _26621 = NOVALUE;
    DeRef(_26698);
    _26698 = NOVALUE;
    DeRef(_26719);
    _26719 = NOVALUE;
    DeRef(_26752);
    _26752 = NOVALUE;
    _26573 = NOVALUE;
    DeRef(_26693);
    _26693 = NOVALUE;
    DeRef(_26880);
    _26880 = NOVALUE;
    DeRef(_26595);
    _26595 = NOVALUE;
    _26810 = NOVALUE;
    DeRef(_26525);
    _26525 = NOVALUE;
    DeRef(_26754);
    _26754 = NOVALUE;
    DeRef(_26489);
    _26489 = NOVALUE;
    DeRef(_26803);
    _26803 = NOVALUE;
    DeRef(_26807);
    _26807 = NOVALUE;
    DeRef(_26887);
    _26887 = NOVALUE;
    DeRef(_26715);
    _26715 = NOVALUE;
    _26604 = NOVALUE;
    DeRef(_26535);
    _26535 = NOVALUE;
    DeRef(_26795);
    _26795 = NOVALUE;
    DeRef(_26973);
    _26973 = NOVALUE;
    _26505 = NOVALUE;
    DeRef(_26815);
    _26815 = NOVALUE;
    DeRef(_26853);
    _26853 = NOVALUE;
    DeRef(_26724);
    _26724 = NOVALUE;
    DeRef(_26965);
    _26965 = NOVALUE;
    DeRef(_26589);
    _26589 = NOVALUE;
    DeRef(_26485);
    _26485 = NOVALUE;
    DeRef(_26875);
    _26875 = NOVALUE;
    DeRef(_27027);
    _27027 = NOVALUE;
    DeRef(_26894);
    _26894 = NOVALUE;
    DeRef(_26957);
    _26957 = NOVALUE;
    DeRef(_26487);
    _26487 = NOVALUE;
    _26575 = NOVALUE;
    _27038 = NOVALUE;
    DeRef(_26961);
    _26961 = NOVALUE;
    DeRef(_26522);
    _26522 = NOVALUE;
    DeRef(_26661);
    _26661 = NOVALUE;
    DeRef(_26602);
    _26602 = NOVALUE;
    DeRef(_26929);
    _26929 = NOVALUE;
    DeRef(_26769);
    _26769 = NOVALUE;
    DeRef(_26634);
    _26634 = NOVALUE;
    DeRef(_26793);
    _26793 = NOVALUE;
    DeRef(_26899);
    _26899 = NOVALUE;
    DeRef(_26655);
    _26655 = NOVALUE;
    _26599 = NOVALUE;
    DeRef(_26953);
    _26953 = NOVALUE;
    DeRef(_27023);
    _27023 = NOVALUE;
    DeRef(_26483);
    _26483 = NOVALUE;
    DeRef(_26671);
    _26671 = NOVALUE;
    DeRef(_26772);
    _26772 = NOVALUE;
    DeRef(_26481);
    _26481 = NOVALUE;
    DeRef(_26977);
    _26977 = NOVALUE;
    DeRef(_26748);
    _26748 = NOVALUE;
    DeRef(_26696);
    _26696 = NOVALUE;
    DeRef(_26689);
    _26689 = NOVALUE;
    DeRef(_26734);
    _26734 = NOVALUE;
    DeRef(_26799);
    _26799 = NOVALUE;
    _26812 = NOVALUE;
    DeRef(_26570);
    _26570 = NOVALUE;
    DeRef(_26517);
    _26517 = NOVALUE;
    DeRef(_26945);
    _26945 = NOVALUE;
    DeRef(_26969);
    _26969 = NOVALUE;
    DeRef(_26532);
    _26532 = NOVALUE;
    DeRef(_26677);
    _26677 = NOVALUE;
    DeRef(_26765);
    _26765 = NOVALUE;
    DeRef(_26741);
    _26741 = NOVALUE;
    DeRef(_26730);
    _26730 = NOVALUE;
    DeRef(_26984);
    _26984 = NOVALUE;
    return;
    ;
}


void _47emit_assign_op(object _op_53349)
{
    object _0, _1, _2;
    

    /** emit.e:1854		if op = PLUS_EQUALS then*/
    if (_op_53349 != 515LL)
    goto L1; // [7] 21

    /** emit.e:1855			emit_op(PLUS)*/
    _47emit_op(11LL);
    goto L2; // [18] 86
L1: 

    /** emit.e:1856		elsif op = MINUS_EQUALS then*/
    if (_op_53349 != 516LL)
    goto L3; // [25] 39

    /** emit.e:1857			emit_op(MINUS)*/
    _47emit_op(10LL);
    goto L2; // [36] 86
L3: 

    /** emit.e:1858		elsif op = MULTIPLY_EQUALS then*/
    if (_op_53349 != 517LL)
    goto L4; // [43] 55

    /** emit.e:1859			emit_op(rw:MULTIPLY)*/
    _47emit_op(13LL);
    goto L2; // [52] 86
L4: 

    /** emit.e:1860		elsif op = DIVIDE_EQUALS then*/
    if (_op_53349 != 518LL)
    goto L5; // [59] 71

    /** emit.e:1861			emit_op(rw:DIVIDE)*/
    _47emit_op(14LL);
    goto L2; // [68] 86
L5: 

    /** emit.e:1862		elsif op = CONCAT_EQUALS then*/
    if (_op_53349 != 519LL)
    goto L6; // [75] 85

    /** emit.e:1863			emit_op(rw:CONCAT)*/
    _47emit_op(15LL);
L6: 
L2: 

    /** emit.e:1865	end procedure*/
    return;
    ;
}


void _47StartSourceLine(object _sl_53369, object _dup_ok_53370, object _emit_coverage_53371)
{
    object _line_span_53374 = NOVALUE;
    object _27092 = NOVALUE;
    object _27090 = NOVALUE;
    object _27089 = NOVALUE;
    object _27088 = NOVALUE;
    object _27087 = NOVALUE;
    object _27086 = NOVALUE;
    object _27084 = NOVALUE;
    object _27081 = NOVALUE;
    object _27079 = NOVALUE;
    object _27078 = NOVALUE;
    object _27077 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:1873		if gline_number = LastLineNumber then*/
    if (_36gline_number_21444 != _62LastLineNumber_25551)
    goto L1; // [13] 66

    /** emit.e:1874			if length(LineTable) then*/
    if (IS_SEQUENCE(_36LineTable_21532)){
            _27077 = SEQ_PTR(_36LineTable_21532)->length;
    }
    else {
        _27077 = 1;
    }
    if (_27077 == 0)
    {
        _27077 = NOVALUE;
        goto L2; // [24] 55
    }
    else{
        _27077 = NOVALUE;
    }

    /** emit.e:1875				if dup_ok then*/
    if (_dup_ok_53370 == 0)
    {
        goto L3; // [29] 47
    }
    else{
    }

    /** emit.e:1876					emit_op( STARTLINE )*/
    _47emit_op(58LL);

    /** emit.e:1877					emit_addr( gline_number )*/
    _47emit_addr(_36gline_number_21444);
L3: 

    /** emit.e:1879				return -- ignore duplicates*/
    return;
    goto L4; // [52] 65
L2: 

    /** emit.e:1882				sl = FALSE -- top-level new statement to execute on same line*/
    _sl_53369 = _13FALSE_450;
L4: 
L1: 

    /** emit.e:1885		LastLineNumber = gline_number*/
    _62LastLineNumber_25551 = _36gline_number_21444;

    /** emit.e:1888		line_span = gline_number - SymTab[CurrentSub][S_FIRSTLINE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27078 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21447);
    _2 = (object)SEQ_PTR(_27078);
    if (!IS_ATOM_INT(_36S_FIRSTLINE_21116)){
        _27079 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FIRSTLINE_21116)->dbl));
    }
    else{
        _27079 = (object)*(((s1_ptr)_2)->base + _36S_FIRSTLINE_21116);
    }
    _27078 = NOVALUE;
    if (IS_ATOM_INT(_27079)) {
        _line_span_53374 = _36gline_number_21444 - _27079;
    }
    else {
        _line_span_53374 = binary_op(MINUS, _36gline_number_21444, _27079);
    }
    _27079 = NOVALUE;
    if (!IS_ATOM_INT(_line_span_53374)) {
        _1 = (object)(DBL_PTR(_line_span_53374)->dbl);
        DeRefDS(_line_span_53374);
        _line_span_53374 = _1;
    }

    /** emit.e:1889		while length(LineTable) < line_span do*/
L5: 
    if (IS_SEQUENCE(_36LineTable_21532)){
            _27081 = SEQ_PTR(_36LineTable_21532)->length;
    }
    else {
        _27081 = 1;
    }
    if (_27081 >= _line_span_53374)
    goto L6; // [109] 128

    /** emit.e:1890			LineTable = append(LineTable, -1) -- filler*/
    Append(&_36LineTable_21532, _36LineTable_21532, -1LL);

    /** emit.e:1891		end while*/
    goto L5; // [125] 104
L6: 

    /** emit.e:1892		LineTable = append(LineTable, length(Code))*/
    if (IS_SEQUENCE(_36Code_21531)){
            _27084 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _27084 = 1;
    }
    Append(&_36LineTable_21532, _36LineTable_21532, _27084);
    _27084 = NOVALUE;

    /** emit.e:1894		if sl and (TRANSLATE or (OpTrace or OpProfileStatement)) then*/
    if (_sl_53369 == 0) {
        goto L7; // [145] 190
    }
    if (_36TRANSLATE_21041 != 0) {
        DeRef(_27087);
        _27087 = 1;
        goto L8; // [151] 171
    }
    if (_36OpTrace_21512 != 0) {
        _27088 = 1;
        goto L9; // [157] 167
    }
    _27088 = (_36OpProfileStatement_21514 != 0);
L9: 
    DeRef(_27087);
    _27087 = (_27088 != 0);
L8: 
    if (_27087 == 0)
    {
        _27087 = NOVALUE;
        goto L7; // [172] 190
    }
    else{
        _27087 = NOVALUE;
    }

    /** emit.e:1896			emit_op(STARTLINE)*/
    _47emit_op(58LL);

    /** emit.e:1897			emit_addr(gline_number)*/
    _47emit_addr(_36gline_number_21444);
L7: 

    /** emit.e:1901		if (sl and emit_coverage = COVERAGE_INCLUDE) or emit_coverage = COVERAGE_OVERRIDE then*/
    if (_sl_53369 == 0) {
        _27089 = 0;
        goto LA; // [192] 206
    }
    _27090 = (_emit_coverage_53371 == 2LL);
    _27089 = (_27090 != 0);
LA: 
    if (_27089 != 0) {
        goto LB; // [206] 221
    }
    _27092 = (_emit_coverage_53371 == 3LL);
    if (_27092 == 0)
    {
        DeRef(_27092);
        _27092 = NOVALUE;
        goto LC; // [217] 229
    }
    else{
        DeRef(_27092);
        _27092 = NOVALUE;
    }
LB: 

    /** emit.e:1902			include_line( gline_number )*/
    _51include_line(_36gline_number_21444);
LC: 

    /** emit.e:1905	end procedure*/
    DeRef(_27090);
    _27090 = NOVALUE;
    return;
    ;
}


object _47has_forward_params(object _sym_53428)
{
    object _27098 = NOVALUE;
    object _27097 = NOVALUE;
    object _27096 = NOVALUE;
    object _27095 = NOVALUE;
    object _27094 = NOVALUE;
    object _27093 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:1908		for i = cgi - (SymTab[sym][S_NUM_ARGS]-1) to cgi do*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27093 = (object)*(((s1_ptr)_2)->base + _sym_53428);
    _2 = (object)SEQ_PTR(_27093);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
        _27094 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
    }
    else{
        _27094 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
    }
    _27093 = NOVALUE;
    if (IS_ATOM_INT(_27094)) {
        _27095 = _27094 - 1LL;
        if ((object)((uintptr_t)_27095 +(uintptr_t) HIGH_BITS) >= 0){
            _27095 = NewDouble((eudouble)_27095);
        }
    }
    else {
        _27095 = binary_op(MINUS, _27094, 1LL);
    }
    _27094 = NOVALUE;
    if (IS_ATOM_INT(_27095)) {
        _27096 = _47cgi_50948 - _27095;
        if ((object)((uintptr_t)_27096 +(uintptr_t) HIGH_BITS) >= 0){
            _27096 = NewDouble((eudouble)_27096);
        }
    }
    else {
        _27096 = binary_op(MINUS, _47cgi_50948, _27095);
    }
    DeRef(_27095);
    _27095 = NOVALUE;
    _27097 = _47cgi_50948;
    {
        object _i_53430;
        Ref(_27096);
        _i_53430 = _27096;
L1: 
        if (binary_op_a(GREATER, _i_53430, _27097)){
            goto L2; // [32] 65
        }

        /** emit.e:1909			if cg_stack[i] < 0 then*/
        _2 = (object)SEQ_PTR(_47cg_stack_50947);
        if (!IS_ATOM_INT(_i_53430)){
            _27098 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_53430)->dbl));
        }
        else{
            _27098 = (object)*(((s1_ptr)_2)->base + _i_53430);
        }
        if (binary_op_a(GREATEREQ, _27098, 0LL)){
            _27098 = NOVALUE;
            goto L3; // [47] 58
        }
        _27098 = NOVALUE;

        /** emit.e:1910				return 1*/
        DeRef(_i_53430);
        DeRef(_27096);
        _27096 = NOVALUE;
        return 1LL;
L3: 

        /** emit.e:1912		end for*/
        _0 = _i_53430;
        if (IS_ATOM_INT(_i_53430)) {
            _i_53430 = _i_53430 + 1LL;
            if ((object)((uintptr_t)_i_53430 +(uintptr_t) HIGH_BITS) >= 0){
                _i_53430 = NewDouble((eudouble)_i_53430);
            }
        }
        else {
            _i_53430 = binary_op_a(PLUS, _i_53430, 1LL);
        }
        DeRef(_0);
        goto L1; // [60] 39
L2: 
        ;
        DeRef(_i_53430);
    }

    /** emit.e:1913		return 0*/
    DeRef(_27096);
    _27096 = NOVALUE;
    return 0LL;
    ;
}



// 0xF48C9DA8
