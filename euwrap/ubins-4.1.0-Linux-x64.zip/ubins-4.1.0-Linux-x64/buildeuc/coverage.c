// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _51check_coverage()
{
    object _25103 = NOVALUE;
    object _25102 = NOVALUE;
    object _25101 = NOVALUE;
    object _25100 = NOVALUE;
    object _25099 = NOVALUE;
    object _25098 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:45		for i = length( file_coverage ) + 1 to length( known_files ) do*/
    if (IS_SEQUENCE(_51file_coverage_48821)){
            _25098 = SEQ_PTR(_51file_coverage_48821)->length;
    }
    else {
        _25098 = 1;
    }
    _25099 = _25098 + 1;
    _25098 = NOVALUE;
    if (IS_SEQUENCE(_37known_files_15407)){
            _25100 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _25100 = 1;
    }
    {
        object _i_48832;
        _i_48832 = _25099;
L1: 
        if (_i_48832 > _25100){
            goto L2; // [17] 58
        }

        /** coverage.e:46			file_coverage &= find( canonical_path( known_files[i],,1 ), covered_files )*/
        _2 = (object)SEQ_PTR(_37known_files_15407);
        _25101 = (object)*(((s1_ptr)_2)->base + _i_48832);
        Ref(_25101);
        _25102 = _17canonical_path(_25101, 0LL, 1LL);
        _25101 = NOVALUE;
        _25103 = find_from(_25102, _51covered_files_48820, 1LL);
        DeRef(_25102);
        _25102 = NOVALUE;
        Append(&_51file_coverage_48821, _51file_coverage_48821, _25103);
        _25103 = NOVALUE;

        /** coverage.e:47		end for*/
        _i_48832 = _i_48832 + 1LL;
        goto L1; // [53] 24
L2: 
        ;
    }

    /** coverage.e:48	end procedure*/
    DeRef(_25099);
    _25099 = NOVALUE;
    return;
    ;
}


void _51init_coverage()
{
    object _cmd_48856 = NOVALUE;
    object _25121 = NOVALUE;
    object _25120 = NOVALUE;
    object _25118 = NOVALUE;
    object _25117 = NOVALUE;
    object _25116 = NOVALUE;
    object _25114 = NOVALUE;
    object _25112 = NOVALUE;
    object _25111 = NOVALUE;
    object _25109 = NOVALUE;
    object _25108 = NOVALUE;
    object _25107 = NOVALUE;
    object _25106 = NOVALUE;
    object _25105 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:54		if initialized_coverage then*/
    if (_51initialized_coverage_48828 == 0)
    {
        goto L1; // [5] 14
    }
    else{
    }

    /** coverage.e:55			return*/
    return;
L1: 

    /** coverage.e:57		initialized_coverage = 1*/
    _51initialized_coverage_48828 = 1LL;

    /** coverage.e:58		for i = 1 to length( file_coverage ) do*/
    if (IS_SEQUENCE(_51file_coverage_48821)){
            _25105 = SEQ_PTR(_51file_coverage_48821)->length;
    }
    else {
        _25105 = 1;
    }
    {
        object _i_48847;
        _i_48847 = 1LL;
L2: 
        if (_i_48847 > _25105){
            goto L3; // [26] 67
        }

        /** coverage.e:59			file_coverage[i] = find( canonical_path( known_files[i],,1 ), covered_files )*/
        _2 = (object)SEQ_PTR(_37known_files_15407);
        _25106 = (object)*(((s1_ptr)_2)->base + _i_48847);
        Ref(_25106);
        _25107 = _17canonical_path(_25106, 0LL, 1LL);
        _25106 = NOVALUE;
        _25108 = find_from(_25107, _51covered_files_48820, 1LL);
        DeRef(_25107);
        _25107 = NOVALUE;
        _2 = (object)SEQ_PTR(_51file_coverage_48821);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _51file_coverage_48821 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_48847);
        *(intptr_t *)_2 = _25108;
        if( _1 != _25108 ){
        }
        _25108 = NOVALUE;

        /** coverage.e:60		end for*/
        _i_48847 = _i_48847 + 1LL;
        goto L2; // [62] 33
L3: 
        ;
    }

    /** coverage.e:62		if equal( coverage_db_name, "" ) then*/
    if (_51coverage_db_name_48822 == _21993)
    _25109 = 1;
    else if (IS_ATOM_INT(_51coverage_db_name_48822) && IS_ATOM_INT(_21993))
    _25109 = 0;
    else
    _25109 = (compare(_51coverage_db_name_48822, _21993) == 0);
    if (_25109 == 0)
    {
        _25109 = NOVALUE;
        goto L4; // [75] 105
    }
    else{
        _25109 = NOVALUE;
    }

    /** coverage.e:63			sequence cmd = command_line()*/
    DeRef(_cmd_48856);
    _cmd_48856 = Command_Line();

    /** coverage.e:64			coverage_db_name = canonical_path( filebase( cmd[2] ) & "-cvg.edb" )*/
    _2 = (object)SEQ_PTR(_cmd_48856);
    _25111 = (object)*(((s1_ptr)_2)->base + 2LL);
    RefDS(_25111);
    _25112 = _17filebase(_25111);
    _25111 = NOVALUE;
    if (IS_SEQUENCE(_25112) && IS_ATOM(_25113)) {
    }
    else if (IS_ATOM(_25112) && IS_SEQUENCE(_25113)) {
        Ref(_25112);
        Prepend(&_25114, _25113, _25112);
    }
    else {
        Concat((object_ptr)&_25114, _25112, _25113);
        DeRef(_25112);
        _25112 = NOVALUE;
    }
    DeRef(_25112);
    _25112 = NOVALUE;
    _0 = _17canonical_path(_25114, 0LL, 0LL);
    DeRefDS(_51coverage_db_name_48822);
    _51coverage_db_name_48822 = _0;
    _25114 = NOVALUE;
L4: 
    DeRef(_cmd_48856);
    _cmd_48856 = NOVALUE;

    /** coverage.e:67		if coverage_erase and file_exists( coverage_db_name ) then*/
    if (0LL == 0) {
        goto L5; // [111] 153
    }
    RefDS(_51coverage_db_name_48822);
    _25117 = _17file_exists(_51coverage_db_name_48822);
    if (_25117 == 0) {
        DeRef(_25117);
        _25117 = NOVALUE;
        goto L5; // [122] 153
    }
    else {
        if (!IS_ATOM_INT(_25117) && DBL_PTR(_25117)->dbl == 0.0){
            DeRef(_25117);
            _25117 = NOVALUE;
            goto L5; // [122] 153
        }
        DeRef(_25117);
        _25117 = NOVALUE;
    }
    DeRef(_25117);
    _25117 = NOVALUE;

    /** coverage.e:68			if not delete_file( coverage_db_name ) then*/
    RefDS(_51coverage_db_name_48822);
    _25118 = _17delete_file(_51coverage_db_name_48822);
    if (IS_ATOM_INT(_25118)) {
        if (_25118 != 0){
            DeRef(_25118);
            _25118 = NOVALUE;
            goto L6; // [133] 152
        }
    }
    else {
        if (DBL_PTR(_25118)->dbl != 0.0){
            DeRef(_25118);
            _25118 = NOVALUE;
            goto L6; // [133] 152
        }
    }
    DeRef(_25118);
    _25118 = NOVALUE;

    /** coverage.e:69				CompileErr( COULD_NOT_ERASE_COVERAGE_DATABASE_1, { coverage_db_name } )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_51coverage_db_name_48822);
    ((intptr_t*)_2)[1] = _51coverage_db_name_48822;
    _25120 = MAKE_SEQ(_1);
    _50CompileErr(335LL, _25120, 0LL);
    _25120 = NOVALUE;
L6: 
L5: 

    /** coverage.e:73		if db_open( coverage_db_name ) = DB_OK then*/
    RefDS(_51coverage_db_name_48822);
    _25121 = _43db_open(_51coverage_db_name_48822, 0LL);
    if (binary_op_a(NOTEQ, _25121, 0LL)){
        DeRef(_25121);
        _25121 = NOVALUE;
        goto L7; // [164] 177
    }
    DeRef(_25121);
    _25121 = NOVALUE;

    /** coverage.e:74			read_coverage_db()*/
    _51read_coverage_db();

    /** coverage.e:75			db_close()*/
    _43db_close();
L7: 

    /** coverage.e:77	end procedure*/
    return;
    ;
}


void _51read_coverage_db()
{
    object _tables_48962 = NOVALUE;
    object _name_48968 = NOVALUE;
    object _fx_48972 = NOVALUE;
    object _the_map_48979 = NOVALUE;
    object _31699 = NOVALUE;
    object _25169 = NOVALUE;
    object _25168 = NOVALUE;
    object _25167 = NOVALUE;
    object _25163 = NOVALUE;
    object _25162 = NOVALUE;
    object _25161 = NOVALUE;
    object _25157 = NOVALUE;
    object _25156 = NOVALUE;
    object _25155 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:135		sequence tables = db_table_list()*/
    _0 = _tables_48962;
    _tables_48962 = _43db_table_list();
    DeRef(_0);

    /** coverage.e:137		for i = 1 to length( tables ) do*/
    if (IS_SEQUENCE(_tables_48962)){
            _25155 = SEQ_PTR(_tables_48962)->length;
    }
    else {
        _25155 = 1;
    }
    {
        object _i_48966;
        _i_48966 = 1LL;
L1: 
        if (_i_48966 > _25155){
            goto L2; // [13] 157
        }

        /** coverage.e:138			sequence name = tables[i][2..$]*/
        _2 = (object)SEQ_PTR(_tables_48962);
        _25156 = (object)*(((s1_ptr)_2)->base + _i_48966);
        if (IS_SEQUENCE(_25156)){
                _25157 = SEQ_PTR(_25156)->length;
        }
        else {
            _25157 = 1;
        }
        rhs_slice_target = (object_ptr)&_name_48968;
        RHS_Slice(_25156, 2LL, _25157);
        _25156 = NOVALUE;

        /** coverage.e:139			integer fx = find( name, covered_files )*/
        _fx_48972 = find_from(_name_48968, _51covered_files_48820, 1LL);

        /** coverage.e:140			if not fx then*/
        if (_fx_48972 != 0)
        goto L3; // [45] 55

        /** coverage.e:141				continue*/
        DeRefDS(_name_48968);
        _name_48968 = NOVALUE;
        DeRef(_the_map_48979);
        _the_map_48979 = NOVALUE;
        goto L4; // [52] 152
L3: 

        /** coverage.e:144			db_select_table( tables[i] )*/
        _2 = (object)SEQ_PTR(_tables_48962);
        _25161 = (object)*(((s1_ptr)_2)->base + _i_48966);
        Ref(_25161);
        _31699 = _43db_select_table(_25161);
        _25161 = NOVALUE;
        DeRef(_31699);
        _31699 = NOVALUE;

        /** coverage.e:146			if tables[i][1] = 'r' then*/
        _2 = (object)SEQ_PTR(_tables_48962);
        _25162 = (object)*(((s1_ptr)_2)->base + _i_48966);
        _2 = (object)SEQ_PTR(_25162);
        _25163 = (object)*(((s1_ptr)_2)->base + 1LL);
        _25162 = NOVALUE;
        if (binary_op_a(NOTEQ, _25163, 114LL)){
            _25163 = NOVALUE;
            goto L5; // [77] 92
        }
        _25163 = NOVALUE;

        /** coverage.e:148				the_map = routine_map[fx]*/
        DeRef(_the_map_48979);
        _2 = (object)SEQ_PTR(_51routine_map_48826);
        _the_map_48979 = (object)*(((s1_ptr)_2)->base + _fx_48972);
        Ref(_the_map_48979);
        goto L6; // [89] 101
L5: 

        /** coverage.e:152				the_map = line_map[fx]*/
        DeRef(_the_map_48979);
        _2 = (object)SEQ_PTR(_51line_map_48825);
        _the_map_48979 = (object)*(((s1_ptr)_2)->base + _fx_48972);
        Ref(_the_map_48979);
L6: 

        /** coverage.e:156			for j = 1 to db_table_size() do*/
        RefDS(_43current_table_name_16829);
        _25167 = _43db_table_size(_43current_table_name_16829);
        {
            object _j_48988;
            _j_48988 = 1LL;
L7: 
            if (binary_op_a(GREATER, _j_48988, _25167)){
                goto L8; // [109] 148
            }

            /** coverage.e:157				map:put( the_map, db_record_key( j ), db_record_data( j ), map:ADD )*/
            Ref(_j_48988);
            RefDS(_43current_table_name_16829);
            _25168 = _43db_record_key(_j_48988, _43current_table_name_16829);
            Ref(_j_48988);
            RefDS(_43current_table_name_16829);
            _25169 = _43db_record_data(_j_48988, _43current_table_name_16829);
            Ref(_the_map_48979);
            _29put(_the_map_48979, _25168, _25169, 2LL, 0LL);
            _25168 = NOVALUE;
            _25169 = NOVALUE;

            /** coverage.e:158			end for*/
            _0 = _j_48988;
            if (IS_ATOM_INT(_j_48988)) {
                _j_48988 = _j_48988 + 1LL;
                if ((object)((uintptr_t)_j_48988 +(uintptr_t) HIGH_BITS) >= 0){
                    _j_48988 = NewDouble((eudouble)_j_48988);
                }
            }
            else {
                _j_48988 = binary_op_a(PLUS, _j_48988, 1LL);
            }
            DeRef(_0);
            goto L7; // [143] 116
L8: 
            ;
            DeRef(_j_48988);
        }
        DeRef(_name_48968);
        _name_48968 = NOVALUE;
        DeRef(_the_map_48979);
        _the_map_48979 = NOVALUE;

        /** coverage.e:160		end for*/
L4: 
        _i_48966 = _i_48966 + 1LL;
        goto L1; // [152] 20
L2: 
        ;
    }

    /** coverage.e:161	end procedure*/
    DeRef(_tables_48962);
    DeRef(_25167);
    _25167 = NOVALUE;
    return;
    ;
}


object _51coverage_on()
{
    object _25170 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:170		return file_coverage[current_file_no]*/
    _2 = (object)SEQ_PTR(_51file_coverage_48821);
    _25170 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
    return _25170;
    ;
}


void _51include_line(object _line_number_49128)
{
    object _25231 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:247		if coverage_on() then*/
    _25231 = _51coverage_on();
    if (_25231 == 0) {
        DeRef(_25231);
        _25231 = NOVALUE;
        goto L1; // [8] 34
    }
    else {
        if (!IS_ATOM_INT(_25231) && DBL_PTR(_25231)->dbl == 0.0){
            DeRef(_25231);
            _25231 = NOVALUE;
            goto L1; // [8] 34
        }
        DeRef(_25231);
        _25231 = NOVALUE;
    }
    DeRef(_25231);
    _25231 = NOVALUE;

    /** coverage.e:248			emit_op( COVERAGE_LINE )*/
    _47emit_op(210LL);

    /** coverage.e:249			emit_addr( gline_number )*/
    _47emit_addr(_36gline_number_21444);

    /** coverage.e:251			included_lines &= line_number*/
    Append(&_51included_lines_48827, _51included_lines_48827, _line_number_49128);
L1: 

    /** coverage.e:253	end procedure*/
    return;
    ;
}


void _51include_routine()
{
    object _file_no_49144 = NOVALUE;
    object _25238 = NOVALUE;
    object _25237 = NOVALUE;
    object _25236 = NOVALUE;
    object _25234 = NOVALUE;
    object _25233 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:256		if coverage_on() then*/
    _25233 = _51coverage_on();
    if (_25233 == 0) {
        DeRef(_25233);
        _25233 = NOVALUE;
        goto L1; // [6] 69
    }
    else {
        if (!IS_ATOM_INT(_25233) && DBL_PTR(_25233)->dbl == 0.0){
            DeRef(_25233);
            _25233 = NOVALUE;
            goto L1; // [6] 69
        }
        DeRef(_25233);
        _25233 = NOVALUE;
    }
    DeRef(_25233);
    _25233 = NOVALUE;

    /** coverage.e:257			emit_op( COVERAGE_ROUTINE )*/
    _47emit_op(211LL);

    /** coverage.e:258			emit_addr( CurrentSub )*/
    _47emit_addr(_36CurrentSub_21447);

    /** coverage.e:261			integer file_no = SymTab[CurrentSub][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25234 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21447);
    _2 = (object)SEQ_PTR(_25234);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _file_no_49144 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _file_no_49144 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    if (!IS_ATOM_INT(_file_no_49144)){
        _file_no_49144 = (object)DBL_PTR(_file_no_49144)->dbl;
    }
    _25234 = NOVALUE;

    /** coverage.e:262			map:put( routine_map[file_coverage[file_no]], sym_name( CurrentSub ), 0, map:ADD )*/
    _2 = (object)SEQ_PTR(_51file_coverage_48821);
    _25236 = (object)*(((s1_ptr)_2)->base + _file_no_49144);
    _2 = (object)SEQ_PTR(_51routine_map_48826);
    _25237 = (object)*(((s1_ptr)_2)->base + _25236);
    _25238 = _54sym_name(_36CurrentSub_21447);
    Ref(_25237);
    _29put(_25237, _25238, 0LL, 2LL, 0LL);
    _25237 = NOVALUE;
    _25238 = NOVALUE;
L1: 

    /** coverage.e:264	end procedure*/
    _25236 = NOVALUE;
    return;
    ;
}



// 0xF9BEA5E5
