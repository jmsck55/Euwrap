// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _67advance(object _pc_53474, object _code_53475)
{
    object _27102 = NOVALUE;
    object _27100 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:63		prev_pc = pc*/
    _67prev_pc_53457 = _pc_53474;

    /** inline.e:64		if pc > length( code ) then*/
    if (IS_SEQUENCE(_code_53475)){
            _27100 = SEQ_PTR(_code_53475)->length;
    }
    else {
        _27100 = 1;
    }
    if (_pc_53474 <= _27100)
    goto L1; // [15] 26

    /** inline.e:65			return pc*/
    DeRefDS(_code_53475);
    return _pc_53474;
L1: 

    /** inline.e:67		return shift:advance( pc, code )*/
    RefDS(_code_53475);
    _27102 = _66advance(_pc_53474, _code_53475);
    DeRefDS(_code_53475);
    return _27102;
    ;
}


void _67shift(object _start_53482, object _amount_53483, object _bound_53484)
{
    object _temp_LineTable_53485 = NOVALUE;
    object _temp_Code_53487 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_amount_53483)) {
        _1 = (object)(DBL_PTR(_amount_53483)->dbl);
        DeRefDS(_amount_53483);
        _amount_53483 = _1;
    }

    /** inline.e:72			temp_LineTable = LineTable,*/
    RefDS(_36LineTable_21532);
    DeRef(_temp_LineTable_53485);
    _temp_LineTable_53485 = _36LineTable_21532;

    /** inline.e:73			temp_Code = Code*/
    RefDS(_36Code_21531);
    DeRef(_temp_Code_53487);
    _temp_Code_53487 = _36Code_21531;

    /** inline.e:74		LineTable = {}*/
    RefDS(_21993);
    DeRefDS(_36LineTable_21532);
    _36LineTable_21532 = _21993;

    /** inline.e:75		Code = inline_code*/
    RefDS(_67inline_code_53449);
    DeRefDS(_36Code_21531);
    _36Code_21531 = _67inline_code_53449;

    /** inline.e:76		inline_code = {}*/
    RefDS(_21993);
    DeRefDS(_67inline_code_53449);
    _67inline_code_53449 = _21993;

    /** inline.e:78		shift:shift( start, amount, bound )*/
    _66shift(_start_53482, _amount_53483, _bound_53484);

    /** inline.e:80		LineTable = temp_LineTable*/
    RefDS(_temp_LineTable_53485);
    DeRefDS(_36LineTable_21532);
    _36LineTable_21532 = _temp_LineTable_53485;

    /** inline.e:81		inline_code = Code*/
    RefDS(_36Code_21531);
    DeRefDS(_67inline_code_53449);
    _67inline_code_53449 = _36Code_21531;

    /** inline.e:82		Code = temp_Code*/
    RefDS(_temp_Code_53487);
    DeRefDS(_36Code_21531);
    _36Code_21531 = _temp_Code_53487;

    /** inline.e:83	end procedure*/
    DeRefDS(_temp_LineTable_53485);
    DeRefDS(_temp_Code_53487);
    return;
    ;
}


void _67replace_code(object _code_53502, object _start_53503, object _finish_53504)
{
    object _27109 = NOVALUE;
    object _27108 = NOVALUE;
    object _27107 = NOVALUE;
    object _27106 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_finish_53504)) {
        _1 = (object)(DBL_PTR(_finish_53504)->dbl);
        DeRefDS(_finish_53504);
        _finish_53504 = _1;
    }

    /** inline.e:92		inline_code = replace( inline_code, code, start, finish )*/
    {
        intptr_t p1 = _67inline_code_53449;
        intptr_t p2 = _code_53502;
        intptr_t p3 = _start_53503;
        intptr_t p4 = _finish_53504;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_67inline_code_53449;
        Replace( &replace_params );
    }

    /** inline.e:93		shift( start , length( code ) - (finish - start + 1), finish )*/
    if (IS_SEQUENCE(_code_53502)){
            _27106 = SEQ_PTR(_code_53502)->length;
    }
    else {
        _27106 = 1;
    }
    _27107 = _finish_53504 - _start_53503;
    if ((object)((uintptr_t)_27107 +(uintptr_t) HIGH_BITS) >= 0){
        _27107 = NewDouble((eudouble)_27107);
    }
    if (IS_ATOM_INT(_27107)) {
        _27108 = _27107 + 1;
        if (_27108 > MAXINT){
            _27108 = NewDouble((eudouble)_27108);
        }
    }
    else
    _27108 = binary_op(PLUS, 1, _27107);
    DeRef(_27107);
    _27107 = NOVALUE;
    if (IS_ATOM_INT(_27108)) {
        _27109 = _27106 - _27108;
        if ((object)((uintptr_t)_27109 +(uintptr_t) HIGH_BITS) >= 0){
            _27109 = NewDouble((eudouble)_27109);
        }
    }
    else {
        _27109 = NewDouble((eudouble)_27106 - DBL_PTR(_27108)->dbl);
    }
    _27106 = NOVALUE;
    DeRef(_27108);
    _27108 = NOVALUE;
    _67shift(_start_53503, _27109, _finish_53504);
    _27109 = NOVALUE;

    /** inline.e:94	end procedure*/
    DeRefDS(_code_53502);
    return;
    ;
}


void _67defer()
{
    object _dx_53512 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:101		integer dx = find( inline_sub, deferred_inline_decisions )*/
    _dx_53512 = find_from(_67inline_sub_53463, _67deferred_inline_decisions_53465, 1LL);

    /** inline.e:102		if not dx then*/
    if (_dx_53512 != 0)
    goto L1; // [14] 36

    /** inline.e:103			deferred_inline_decisions &= inline_sub*/
    Append(&_67deferred_inline_decisions_53465, _67deferred_inline_decisions_53465, _67inline_sub_53463);

    /** inline.e:104			deferred_inline_calls = append( deferred_inline_calls, {} )*/
    RefDS(_21993);
    Append(&_67deferred_inline_calls_53466, _67deferred_inline_calls_53466, _21993);
L1: 

    /** inline.e:106	end procedure*/
    return;
    ;
}


object _67new_inline_temp(object _sym_53521)
{
    object _27115 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:110		inline_temps &= sym*/
    Append(&_67inline_temps_53451, _67inline_temps_53451, _sym_53521);

    /** inline.e:111		return length( inline_temps )*/
    if (IS_SEQUENCE(_67inline_temps_53451)){
            _27115 = SEQ_PTR(_67inline_temps_53451)->length;
    }
    else {
        _27115 = 1;
    }
    return _27115;
    ;
}


object _67get_inline_temp(object _sym_53527)
{
    object _temp_num_53528 = NOVALUE;
    object _27119 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:117		integer temp_num = find( sym, inline_params )*/
    _temp_num_53528 = find_from(_sym_53527, _67inline_params_53454, 1LL);

    /** inline.e:118		if temp_num then*/
    if (_temp_num_53528 == 0)
    {
        goto L1; // [14] 24
    }
    else{
    }

    /** inline.e:119			return temp_num*/
    return _temp_num_53528;
L1: 

    /** inline.e:122		temp_num = find( sym, proc_vars )*/
    _temp_num_53528 = find_from(_sym_53527, _67proc_vars_53450, 1LL);

    /** inline.e:123		if temp_num then*/
    if (_temp_num_53528 == 0)
    {
        goto L2; // [35] 45
    }
    else{
    }

    /** inline.e:124			return temp_num*/
    return _temp_num_53528;
L2: 

    /** inline.e:127		temp_num = find( sym, inline_temps )*/
    _temp_num_53528 = find_from(_sym_53527, _67inline_temps_53451, 1LL);

    /** inline.e:128		if temp_num then*/
    if (_temp_num_53528 == 0)
    {
        goto L3; // [56] 66
    }
    else{
    }

    /** inline.e:129			return temp_num*/
    return _temp_num_53528;
L3: 

    /** inline.e:132		return new_inline_temp( sym )*/
    _27119 = _67new_inline_temp(_sym_53527);
    return _27119;
    ;
}


object _67generic_symbol(object _sym_53539)
{
    object _inline_type_53540 = NOVALUE;
    object _px_53541 = NOVALUE;
    object _eentry_53548 = NOVALUE;
    object _27128 = NOVALUE;
    object _27127 = NOVALUE;
    object _27126 = NOVALUE;
    object _27125 = NOVALUE;
    object _27123 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:137		integer px = find( sym, inline_params )*/
    _px_53541 = find_from(_sym_53539, _67inline_params_53454, 1LL);

    /** inline.e:138		if px then*/
    if (_px_53541 == 0)
    {
        goto L1; // [14] 25
    }
    else{
    }

    /** inline.e:139			inline_type = INLINE_PARAM*/
    _inline_type_53540 = 1LL;
    goto L2; // [22] 100
L1: 

    /** inline.e:141			px = find( sym, proc_vars )*/
    _px_53541 = find_from(_sym_53539, _67proc_vars_53450, 1LL);

    /** inline.e:142			if px then*/
    if (_px_53541 == 0)
    {
        goto L3; // [36] 47
    }
    else{
    }

    /** inline.e:143				inline_type = INLINE_VAR*/
    _inline_type_53540 = 6LL;
    goto L4; // [44] 99
L3: 

    /** inline.e:145				sequence eentry = SymTab[sym]*/
    DeRef(_eentry_53548);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _eentry_53548 = (object)*(((s1_ptr)_2)->base + _sym_53539);
    Ref(_eentry_53548);

    /** inline.e:146				if is_literal( sym ) or eentry[S_SCOPE] > SC_PRIVATE then*/
    _27123 = _67is_literal(_sym_53539);
    if (IS_ATOM_INT(_27123)) {
        if (_27123 != 0) {
            goto L5; // [63] 84
        }
    }
    else {
        if (DBL_PTR(_27123)->dbl != 0.0) {
            goto L5; // [63] 84
        }
    }
    _2 = (object)SEQ_PTR(_eentry_53548);
    _27125 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_27125)) {
        _27126 = (_27125 > 3LL);
    }
    else {
        _27126 = binary_op(GREATER, _27125, 3LL);
    }
    _27125 = NOVALUE;
    if (_27126 == 0) {
        DeRef(_27126);
        _27126 = NOVALUE;
        goto L6; // [80] 91
    }
    else {
        if (!IS_ATOM_INT(_27126) && DBL_PTR(_27126)->dbl == 0.0){
            DeRef(_27126);
            _27126 = NOVALUE;
            goto L6; // [80] 91
        }
        DeRef(_27126);
        _27126 = NOVALUE;
    }
    DeRef(_27126);
    _27126 = NOVALUE;
L5: 

    /** inline.e:147					return sym*/
    DeRef(_eentry_53548);
    DeRef(_27123);
    _27123 = NOVALUE;
    return _sym_53539;
L6: 

    /** inline.e:149				inline_type = INLINE_TEMP*/
    _inline_type_53540 = 2LL;
    DeRef(_eentry_53548);
    _eentry_53548 = NOVALUE;
L4: 
L2: 

    /** inline.e:153		return { inline_type, get_inline_temp( sym ) }*/
    _27127 = _67get_inline_temp(_sym_53539);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _inline_type_53540;
    ((intptr_t *)_2)[2] = _27127;
    _27128 = MAKE_SEQ(_1);
    _27127 = NOVALUE;
    DeRef(_27123);
    _27123 = NOVALUE;
    return _27128;
    ;
}


object _67adjust_symbol(object _pc_53563)
{
    object _sym_53565 = NOVALUE;
    object _eentry_53571 = NOVALUE;
    object _27136 = NOVALUE;
    object _27134 = NOVALUE;
    object _27133 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_53563)) {
        _1 = (object)(DBL_PTR(_pc_53563)->dbl);
        DeRefDS(_pc_53563);
        _pc_53563 = _1;
    }

    /** inline.e:160		symtab_index sym = inline_code[pc]*/
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    _sym_53565 = (object)*(((s1_ptr)_2)->base + _pc_53563);
    if (!IS_ATOM_INT(_sym_53565)){
        _sym_53565 = (object)DBL_PTR(_sym_53565)->dbl;
    }

    /** inline.e:161		if sym < 0 then*/
    if (_sym_53565 >= 0LL)
    goto L1; // [15] 28

    /** inline.e:162			return 0*/
    DeRef(_eentry_53571);
    return 0LL;
    goto L2; // [25] 41
L1: 

    /** inline.e:163		elsif not sym then*/
    if (_sym_53565 != 0)
    goto L3; // [30] 40

    /** inline.e:165			return 1*/
    DeRef(_eentry_53571);
    return 1LL;
L3: 
L2: 

    /** inline.e:168		sequence eentry = SymTab[sym]*/
    DeRef(_eentry_53571);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _eentry_53571 = (object)*(((s1_ptr)_2)->base + _sym_53565);
    Ref(_eentry_53571);

    /** inline.e:169		if is_literal( sym ) then*/
    _27133 = _67is_literal(_sym_53565);
    if (_27133 == 0) {
        DeRef(_27133);
        _27133 = NOVALUE;
        goto L4; // [57] 69
    }
    else {
        if (!IS_ATOM_INT(_27133) && DBL_PTR(_27133)->dbl == 0.0){
            DeRef(_27133);
            _27133 = NOVALUE;
            goto L4; // [57] 69
        }
        DeRef(_27133);
        _27133 = NOVALUE;
    }
    DeRef(_27133);
    _27133 = NOVALUE;

    /** inline.e:170			return 1*/
    DeRefDS(_eentry_53571);
    return 1LL;
    goto L5; // [66] 95
L4: 

    /** inline.e:172		elsif eentry[S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_eentry_53571);
    _27134 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (binary_op_a(NOTEQ, _27134, 9LL)){
        _27134 = NOVALUE;
        goto L6; // [79] 94
    }
    _27134 = NOVALUE;

    /** inline.e:173			defer()*/
    _67defer();

    /** inline.e:174			return 0*/
    DeRefDS(_eentry_53571);
    return 0LL;
L6: 
L5: 

    /** inline.e:177		inline_code[pc] = generic_symbol( sym )*/
    _27136 = _67generic_symbol(_sym_53565);
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53449 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _pc_53563);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27136;
    if( _1 != _27136 ){
        DeRef(_1);
    }
    _27136 = NOVALUE;

    /** inline.e:178		return 1*/
    DeRef(_eentry_53571);
    return 1LL;
    ;
}


object _67check_for_param(object _pc_53585)
{
    object _px_53586 = NOVALUE;
    object _27139 = NOVALUE;
    object _27137 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_53585)) {
        _1 = (object)(DBL_PTR(_pc_53585)->dbl);
        DeRefDS(_pc_53585);
        _pc_53585 = _1;
    }

    /** inline.e:182		integer px = find( inline_code[pc], inline_params )*/
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    _27137 = (object)*(((s1_ptr)_2)->base + _pc_53585);
    _px_53586 = find_from(_27137, _67inline_params_53454, 1LL);
    _27137 = NOVALUE;

    /** inline.e:183		if px then*/
    if (_px_53586 == 0)
    {
        goto L1; // [20] 51
    }
    else{
    }

    /** inline.e:184			if not find( px, assigned_params ) then*/
    _27139 = find_from(_px_53586, _67assigned_params_53455, 1LL);
    if (_27139 != 0)
    goto L2; // [32] 44
    _27139 = NOVALUE;

    /** inline.e:185				assigned_params &= px*/
    Append(&_67assigned_params_53455, _67assigned_params_53455, _px_53586);
L2: 

    /** inline.e:187			return 1*/
    return 1LL;
L1: 

    /** inline.e:189		return 0*/
    return 0LL;
    ;
}


void _67check_target(object _pc_53596, object _op_53597)
{
    object _targets_53598 = NOVALUE;
    object _27148 = NOVALUE;
    object _27147 = NOVALUE;
    object _27146 = NOVALUE;
    object _27145 = NOVALUE;
    object _27144 = NOVALUE;
    object _27142 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:194		sequence targets = op_info[op][OP_TARGET]*/
    _2 = (object)SEQ_PTR(_66op_info_24235);
    _27142 = (object)*(((s1_ptr)_2)->base + _op_53597);
    DeRef(_targets_53598);
    _2 = (object)SEQ_PTR(_27142);
    _targets_53598 = (object)*(((s1_ptr)_2)->base + 4LL);
    Ref(_targets_53598);
    _27142 = NOVALUE;

    /** inline.e:196		if length( targets ) then*/
    if (IS_SEQUENCE(_targets_53598)){
            _27144 = SEQ_PTR(_targets_53598)->length;
    }
    else {
        _27144 = 1;
    }
    if (_27144 == 0)
    {
        _27144 = NOVALUE;
        goto L1; // [26] 72
    }
    else{
        _27144 = NOVALUE;
    }

    /** inline.e:197		for i = 1 to length( targets ) do*/
    if (IS_SEQUENCE(_targets_53598)){
            _27145 = SEQ_PTR(_targets_53598)->length;
    }
    else {
        _27145 = 1;
    }
    {
        object _i_53606;
        _i_53606 = 1LL;
L2: 
        if (_i_53606 > _27145){
            goto L3; // [34] 71
        }

        /** inline.e:198				if check_for_param( pc + targets[i] ) then*/
        _2 = (object)SEQ_PTR(_targets_53598);
        _27146 = (object)*(((s1_ptr)_2)->base + _i_53606);
        if (IS_ATOM_INT(_27146)) {
            _27147 = _pc_53596 + _27146;
            if ((object)((uintptr_t)_27147 + (uintptr_t)HIGH_BITS) >= 0){
                _27147 = NewDouble((eudouble)_27147);
            }
        }
        else {
            _27147 = binary_op(PLUS, _pc_53596, _27146);
        }
        _27146 = NOVALUE;
        _27148 = _67check_for_param(_27147);
        _27147 = NOVALUE;
        if (_27148 == 0) {
            DeRef(_27148);
            _27148 = NOVALUE;
            goto L4; // [55] 64
        }
        else {
            if (!IS_ATOM_INT(_27148) && DBL_PTR(_27148)->dbl == 0.0){
                DeRef(_27148);
                _27148 = NOVALUE;
                goto L4; // [55] 64
            }
            DeRef(_27148);
            _27148 = NOVALUE;
        }
        DeRef(_27148);
        _27148 = NOVALUE;

        /** inline.e:199					return*/
        DeRefDS(_targets_53598);
        return;
L4: 

        /** inline.e:201			end for*/
        _i_53606 = _i_53606 + 1LL;
        goto L2; // [66] 41
L3: 
        ;
    }
L1: 

    /** inline.e:203	end procedure*/
    DeRef(_targets_53598);
    return;
    ;
}


object _67adjust_il(object _pc_53614, object _op_53615)
{
    object _addr_53623 = NOVALUE;
    object _sub_53629 = NOVALUE;
    object _27173 = NOVALUE;
    object _27172 = NOVALUE;
    object _27171 = NOVALUE;
    object _27170 = NOVALUE;
    object _27169 = NOVALUE;
    object _27168 = NOVALUE;
    object _27167 = NOVALUE;
    object _27165 = NOVALUE;
    object _27164 = NOVALUE;
    object _27163 = NOVALUE;
    object _27162 = NOVALUE;
    object _27161 = NOVALUE;
    object _27160 = NOVALUE;
    object _27159 = NOVALUE;
    object _27158 = NOVALUE;
    object _27156 = NOVALUE;
    object _27155 = NOVALUE;
    object _27153 = NOVALUE;
    object _27152 = NOVALUE;
    object _27151 = NOVALUE;
    object _27150 = NOVALUE;
    object _27149 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:208		for i = 1 to op_info[op][OP_SIZE] - 1 do*/
    _2 = (object)SEQ_PTR(_66op_info_24235);
    _27149 = (object)*(((s1_ptr)_2)->base + _op_53615);
    _2 = (object)SEQ_PTR(_27149);
    _27150 = (object)*(((s1_ptr)_2)->base + 2LL);
    _27149 = NOVALUE;
    if (IS_ATOM_INT(_27150)) {
        _27151 = _27150 - 1LL;
        if ((object)((uintptr_t)_27151 +(uintptr_t) HIGH_BITS) >= 0){
            _27151 = NewDouble((eudouble)_27151);
        }
    }
    else {
        _27151 = binary_op(MINUS, _27150, 1LL);
    }
    _27150 = NOVALUE;
    {
        object _i_53617;
        _i_53617 = 1LL;
L1: 
        if (binary_op_a(GREATER, _i_53617, _27151)){
            goto L2; // [23] 214
        }

        /** inline.e:210			integer addr = find( i, op_info[op][OP_ADDR] )*/
        _2 = (object)SEQ_PTR(_66op_info_24235);
        _27152 = (object)*(((s1_ptr)_2)->base + _op_53615);
        _2 = (object)SEQ_PTR(_27152);
        _27153 = (object)*(((s1_ptr)_2)->base + 3LL);
        _27152 = NOVALUE;
        _addr_53623 = find_from(_i_53617, _27153, 1LL);
        _27153 = NOVALUE;

        /** inline.e:211			integer sub  = find( i, op_info[op][OP_SUB] )*/
        _2 = (object)SEQ_PTR(_66op_info_24235);
        _27155 = (object)*(((s1_ptr)_2)->base + _op_53615);
        _2 = (object)SEQ_PTR(_27155);
        _27156 = (object)*(((s1_ptr)_2)->base + 5LL);
        _27155 = NOVALUE;
        _sub_53629 = find_from(_i_53617, _27156, 1LL);
        _27156 = NOVALUE;

        /** inline.e:212			if addr then*/
        if (_addr_53623 == 0)
        {
            goto L3; // [70] 121
        }
        else{
        }

        /** inline.e:213				if integer( inline_code[pc+i] ) then*/
        if (IS_ATOM_INT(_i_53617)) {
            _27158 = _pc_53614 + _i_53617;
        }
        else {
            _27158 = NewDouble((eudouble)_pc_53614 + DBL_PTR(_i_53617)->dbl);
        }
        _2 = (object)SEQ_PTR(_67inline_code_53449);
        if (!IS_ATOM_INT(_27158)){
            _27159 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27158)->dbl));
        }
        else{
            _27159 = (object)*(((s1_ptr)_2)->base + _27158);
        }
        if (IS_ATOM_INT(_27159))
        _27160 = 1;
        else if (IS_ATOM_DBL(_27159))
        _27160 = IS_ATOM_INT(DoubleToInt(_27159));
        else
        _27160 = 0;
        _27159 = NOVALUE;
        if (_27160 == 0)
        {
            _27160 = NOVALUE;
            goto L4; // [88] 205
        }
        else{
            _27160 = NOVALUE;
        }

        /** inline.e:214					inline_code[pc + i] = { INLINE_ADDR, inline_code[pc + i] }*/
        if (IS_ATOM_INT(_i_53617)) {
            _27161 = _pc_53614 + _i_53617;
            if ((object)((uintptr_t)_27161 + (uintptr_t)HIGH_BITS) >= 0){
                _27161 = NewDouble((eudouble)_27161);
            }
        }
        else {
            _27161 = NewDouble((eudouble)_pc_53614 + DBL_PTR(_i_53617)->dbl);
        }
        if (IS_ATOM_INT(_i_53617)) {
            _27162 = _pc_53614 + _i_53617;
        }
        else {
            _27162 = NewDouble((eudouble)_pc_53614 + DBL_PTR(_i_53617)->dbl);
        }
        _2 = (object)SEQ_PTR(_67inline_code_53449);
        if (!IS_ATOM_INT(_27162)){
            _27163 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27162)->dbl));
        }
        else{
            _27163 = (object)*(((s1_ptr)_2)->base + _27162);
        }
        Ref(_27163);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 4LL;
        ((intptr_t *)_2)[2] = _27163;
        _27164 = MAKE_SEQ(_1);
        _27163 = NOVALUE;
        _2 = (object)SEQ_PTR(_67inline_code_53449);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67inline_code_53449 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_27161))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27161)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _27161);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _27164;
        if( _1 != _27164 ){
            DeRef(_1);
        }
        _27164 = NOVALUE;
        goto L4; // [118] 205
L3: 

        /** inline.e:217			elsif sub then*/
        if (_sub_53629 == 0)
        {
            goto L5; // [123] 141
        }
        else{
        }

        /** inline.e:218				inline_code[pc+i] = {INLINE_SUB}*/
        if (IS_ATOM_INT(_i_53617)) {
            _27165 = _pc_53614 + _i_53617;
        }
        else {
            _27165 = NewDouble((eudouble)_pc_53614 + DBL_PTR(_i_53617)->dbl);
        }
        RefDS(_27166);
        _2 = (object)SEQ_PTR(_67inline_code_53449);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67inline_code_53449 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_27165))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27165)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _27165);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _27166;
        DeRef(_1);
        goto L4; // [138] 205
L5: 

        /** inline.e:220				if op != STARTLINE and op != COVERAGE_LINE and op != COVERAGE_ROUTINE then*/
        _27167 = (_op_53615 != 58LL);
        if (_27167 == 0) {
            _27168 = 0;
            goto L6; // [149] 163
        }
        _27169 = (_op_53615 != 210LL);
        _27168 = (_27169 != 0);
L6: 
        if (_27168 == 0) {
            goto L7; // [163] 204
        }
        _27171 = (_op_53615 != 211LL);
        if (_27171 == 0)
        {
            DeRef(_27171);
            _27171 = NOVALUE;
            goto L7; // [174] 204
        }
        else{
            DeRef(_27171);
            _27171 = NOVALUE;
        }

        /** inline.e:221					check_target( pc, op )*/
        _67check_target(_pc_53614, _op_53615);

        /** inline.e:222					if not adjust_symbol( pc + i ) then*/
        if (IS_ATOM_INT(_i_53617)) {
            _27172 = _pc_53614 + _i_53617;
            if ((object)((uintptr_t)_27172 + (uintptr_t)HIGH_BITS) >= 0){
                _27172 = NewDouble((eudouble)_27172);
            }
        }
        else {
            _27172 = NewDouble((eudouble)_pc_53614 + DBL_PTR(_i_53617)->dbl);
        }
        _27173 = _67adjust_symbol(_27172);
        _27172 = NOVALUE;
        if (IS_ATOM_INT(_27173)) {
            if (_27173 != 0){
                DeRef(_27173);
                _27173 = NOVALUE;
                goto L8; // [193] 203
            }
        }
        else {
            if (DBL_PTR(_27173)->dbl != 0.0){
                DeRef(_27173);
                _27173 = NOVALUE;
                goto L8; // [193] 203
            }
        }
        DeRef(_27173);
        _27173 = NOVALUE;

        /** inline.e:223						return 0*/
        DeRef(_i_53617);
        DeRef(_27151);
        _27151 = NOVALUE;
        DeRef(_27169);
        _27169 = NOVALUE;
        DeRef(_27167);
        _27167 = NOVALUE;
        DeRef(_27161);
        _27161 = NOVALUE;
        DeRef(_27162);
        _27162 = NOVALUE;
        DeRef(_27158);
        _27158 = NOVALUE;
        DeRef(_27165);
        _27165 = NOVALUE;
        return 0LL;
L8: 
L7: 
L4: 

        /** inline.e:227		end for*/
        _0 = _i_53617;
        if (IS_ATOM_INT(_i_53617)) {
            _i_53617 = _i_53617 + 1LL;
            if ((object)((uintptr_t)_i_53617 +(uintptr_t) HIGH_BITS) >= 0){
                _i_53617 = NewDouble((eudouble)_i_53617);
            }
        }
        else {
            _i_53617 = binary_op_a(PLUS, _i_53617, 1LL);
        }
        DeRef(_0);
        goto L1; // [209] 30
L2: 
        ;
        DeRef(_i_53617);
    }

    /** inline.e:228		return 1*/
    DeRef(_27151);
    _27151 = NOVALUE;
    DeRef(_27169);
    _27169 = NOVALUE;
    DeRef(_27167);
    _27167 = NOVALUE;
    DeRef(_27161);
    _27161 = NOVALUE;
    DeRef(_27162);
    _27162 = NOVALUE;
    DeRef(_27158);
    _27158 = NOVALUE;
    DeRef(_27165);
    _27165 = NOVALUE;
    return 1LL;
    ;
}


object _67is_temp(object _sym_53664)
{
    object _27184 = NOVALUE;
    object _27183 = NOVALUE;
    object _27182 = NOVALUE;
    object _27181 = NOVALUE;
    object _27180 = NOVALUE;
    object _27179 = NOVALUE;
    object _27178 = NOVALUE;
    object _27177 = NOVALUE;
    object _27176 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:232		if sym <= 0 then*/
    if (_sym_53664 > 0LL)
    goto L1; // [5] 16

    /** inline.e:233			return 0*/
    return 0LL;
L1: 

    /** inline.e:236		return (SymTab[sym][S_MODE] = M_TEMP) and (not TRANSLATE or equal( NOVALUE, SymTab[sym][S_OBJ]) )*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27176 = (object)*(((s1_ptr)_2)->base + _sym_53664);
    _2 = (object)SEQ_PTR(_27176);
    _27177 = (object)*(((s1_ptr)_2)->base + 3LL);
    _27176 = NOVALUE;
    if (IS_ATOM_INT(_27177)) {
        _27178 = (_27177 == 3LL);
    }
    else {
        _27178 = binary_op(EQUALS, _27177, 3LL);
    }
    _27177 = NOVALUE;
    _27179 = (_36TRANSLATE_21041 == 0);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27180 = (object)*(((s1_ptr)_2)->base + _sym_53664);
    _2 = (object)SEQ_PTR(_27180);
    _27181 = (object)*(((s1_ptr)_2)->base + 1LL);
    _27180 = NOVALUE;
    if (_36NOVALUE_21293 == _27181)
    _27182 = 1;
    else if (IS_ATOM_INT(_36NOVALUE_21293) && IS_ATOM_INT(_27181))
    _27182 = 0;
    else
    _27182 = (compare(_36NOVALUE_21293, _27181) == 0);
    _27181 = NOVALUE;
    _27183 = (_27179 != 0 || _27182 != 0);
    _27179 = NOVALUE;
    _27182 = NOVALUE;
    if (IS_ATOM_INT(_27178)) {
        _27184 = (_27178 != 0 && _27183 != 0);
    }
    else {
        _27184 = binary_op(AND, _27178, _27183);
    }
    DeRef(_27178);
    _27178 = NOVALUE;
    _27183 = NOVALUE;
    return _27184;
    ;
}


object _67is_literal(object _sym_53686)
{
    object _mode_53689 = NOVALUE;
    object _27199 = NOVALUE;
    object _27198 = NOVALUE;
    object _27197 = NOVALUE;
    object _27196 = NOVALUE;
    object _27195 = NOVALUE;
    object _27194 = NOVALUE;
    object _27192 = NOVALUE;
    object _27191 = NOVALUE;
    object _27190 = NOVALUE;
    object _27189 = NOVALUE;
    object _27188 = NOVALUE;
    object _27186 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:240		if sym <= 0 then*/
    if (_sym_53686 > 0LL)
    goto L1; // [5] 16

    /** inline.e:241			return 0*/
    return 0LL;
L1: 

    /** inline.e:244		integer mode = SymTab[sym][S_MODE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27186 = (object)*(((s1_ptr)_2)->base + _sym_53686);
    _2 = (object)SEQ_PTR(_27186);
    _mode_53689 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_mode_53689)){
        _mode_53689 = (object)DBL_PTR(_mode_53689)->dbl;
    }
    _27186 = NOVALUE;

    /** inline.e:245		if (mode = M_CONSTANT and eu:compare( NOVALUE, SymTab[sym][S_OBJ]) ) */
    _27188 = (_mode_53689 == 2LL);
    if (_27188 == 0) {
        _27189 = 0;
        goto L2; // [40] 66
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27190 = (object)*(((s1_ptr)_2)->base + _sym_53686);
    _2 = (object)SEQ_PTR(_27190);
    _27191 = (object)*(((s1_ptr)_2)->base + 1LL);
    _27190 = NOVALUE;
    if (IS_ATOM_INT(_36NOVALUE_21293) && IS_ATOM_INT(_27191)){
        _27192 = (_36NOVALUE_21293 < _27191) ? -1 : (_36NOVALUE_21293 > _27191);
    }
    else{
        _27192 = compare(_36NOVALUE_21293, _27191);
    }
    _27191 = NOVALUE;
    _27189 = (_27192 != 0);
L2: 
    if (_27189 != 0) {
        goto L3; // [66] 117
    }
    if (_36TRANSLATE_21041 == 0) {
        _27194 = 0;
        goto L4; // [72] 86
    }
    _27195 = (_mode_53689 == 3LL);
    _27194 = (_27195 != 0);
L4: 
    if (_27194 == 0) {
        DeRef(_27196);
        _27196 = 0;
        goto L5; // [86] 112
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27197 = (object)*(((s1_ptr)_2)->base + _sym_53686);
    _2 = (object)SEQ_PTR(_27197);
    _27198 = (object)*(((s1_ptr)_2)->base + 1LL);
    _27197 = NOVALUE;
    if (IS_ATOM_INT(_27198) && IS_ATOM_INT(_36NOVALUE_21293)){
        _27199 = (_27198 < _36NOVALUE_21293) ? -1 : (_27198 > _36NOVALUE_21293);
    }
    else{
        _27199 = compare(_27198, _36NOVALUE_21293);
    }
    _27198 = NOVALUE;
    _27196 = (_27199 != 0);
L5: 
    if (_27196 == 0)
    {
        _27196 = NOVALUE;
        goto L6; // [113] 126
    }
    else{
        _27196 = NOVALUE;
    }
L3: 

    /** inline.e:247			return 1*/
    DeRef(_27195);
    _27195 = NOVALUE;
    DeRef(_27188);
    _27188 = NOVALUE;
    return 1LL;
    goto L7; // [123] 133
L6: 

    /** inline.e:249			return 0*/
    DeRef(_27195);
    _27195 = NOVALUE;
    DeRef(_27188);
    _27188 = NOVALUE;
    return 0LL;
L7: 
    ;
}


object _67returnf(object _pc_53736)
{
    object _retsym_53738 = NOVALUE;
    object _code_53771 = NOVALUE;
    object _ret_pc_53772 = NOVALUE;
    object _code_53817 = NOVALUE;
    object _ret_pc_53831 = NOVALUE;
    object _27272 = NOVALUE;
    object _27271 = NOVALUE;
    object _27269 = NOVALUE;
    object _27267 = NOVALUE;
    object _27266 = NOVALUE;
    object _27264 = NOVALUE;
    object _27263 = NOVALUE;
    object _27261 = NOVALUE;
    object _27260 = NOVALUE;
    object _27259 = NOVALUE;
    object _27257 = NOVALUE;
    object _27256 = NOVALUE;
    object _27254 = NOVALUE;
    object _27252 = NOVALUE;
    object _27251 = NOVALUE;
    object _27249 = NOVALUE;
    object _27248 = NOVALUE;
    object _27246 = NOVALUE;
    object _27245 = NOVALUE;
    object _27244 = NOVALUE;
    object _27242 = NOVALUE;
    object _27241 = NOVALUE;
    object _27240 = NOVALUE;
    object _27239 = NOVALUE;
    object _27238 = NOVALUE;
    object _27236 = NOVALUE;
    object _27235 = NOVALUE;
    object _27234 = NOVALUE;
    object _27233 = NOVALUE;
    object _27231 = NOVALUE;
    object _27229 = NOVALUE;
    object _27228 = NOVALUE;
    object _27227 = NOVALUE;
    object _27226 = NOVALUE;
    object _27225 = NOVALUE;
    object _27224 = NOVALUE;
    object _27223 = NOVALUE;
    object _27222 = NOVALUE;
    object _27221 = NOVALUE;
    object _27219 = NOVALUE;
    object _27218 = NOVALUE;
    object _27217 = NOVALUE;
    object _27215 = NOVALUE;
    object _27214 = NOVALUE;
    object _27213 = NOVALUE;
    object _27212 = NOVALUE;
    object _27211 = NOVALUE;
    object _27210 = NOVALUE;
    object _27208 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** inline.e:259		symtab_index retsym = inline_code[pc+3]*/
    _27208 = _pc_53736 + 3LL;
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    _retsym_53738 = (object)*(((s1_ptr)_2)->base + _27208);
    if (!IS_ATOM_INT(_retsym_53738)){
        _retsym_53738 = (object)DBL_PTR(_retsym_53738)->dbl;
    }

    /** inline.e:260		if equal( inline_code[$], BADRETURNF ) then*/
    if (IS_SEQUENCE(_67inline_code_53449)){
            _27210 = SEQ_PTR(_67inline_code_53449)->length;
    }
    else {
        _27210 = 1;
    }
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    _27211 = (object)*(((s1_ptr)_2)->base + _27210);
    if (_27211 == 43LL)
    _27212 = 1;
    else if (IS_ATOM_INT(_27211) && IS_ATOM_INT(43LL))
    _27212 = 0;
    else
    _27212 = (compare(_27211, 43LL) == 0);
    _27211 = NOVALUE;
    if (_27212 == 0)
    {
        _27212 = NOVALUE;
        goto L1; // [34] 102
    }
    else{
        _27212 = NOVALUE;
    }

    /** inline.e:261			if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L2; // [41] 60
    }
    else{
    }

    /** inline.e:262				inline_code[$] = NOP1*/
    if (IS_SEQUENCE(_67inline_code_53449)){
            _27213 = SEQ_PTR(_67inline_code_53449)->length;
    }
    else {
        _27213 = 1;
    }
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53449 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27213);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 159LL;
    DeRef(_1);
    goto L3; // [57] 101
L2: 

    /** inline.e:263			elsif SymTab[inline_sub][S_TOKEN] = PROC then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27214 = (object)*(((s1_ptr)_2)->base + _67inline_sub_53463);
    _2 = (object)SEQ_PTR(_27214);
    if (!IS_ATOM_INT(_36S_TOKEN_21081)){
        _27215 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    }
    else{
        _27215 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    }
    _27214 = NOVALUE;
    if (binary_op_a(NOTEQ, _27215, 27LL)){
        _27215 = NOVALUE;
        goto L4; // [78] 100
    }
    _27215 = NOVALUE;

    /** inline.e:264				replace_code( {}, length(inline_code), length(inline_code) )*/
    if (IS_SEQUENCE(_67inline_code_53449)){
            _27217 = SEQ_PTR(_67inline_code_53449)->length;
    }
    else {
        _27217 = 1;
    }
    if (IS_SEQUENCE(_67inline_code_53449)){
            _27218 = SEQ_PTR(_67inline_code_53449)->length;
    }
    else {
        _27218 = 1;
    }
    RefDS(_21993);
    _67replace_code(_21993, _27217, _27218);
    _27217 = NOVALUE;
    _27218 = NOVALUE;
L4: 
L3: 
L1: 

    /** inline.e:270		if is_temp( retsym ) */
    _27219 = _67is_temp(_retsym_53738);
    if (IS_ATOM_INT(_27219)) {
        if (_27219 != 0) {
            goto L5; // [108] 150
        }
    }
    else {
        if (DBL_PTR(_27219)->dbl != 0.0) {
            goto L5; // [108] 150
        }
    }
    _27221 = _67is_literal(_retsym_53738);
    if (IS_ATOM_INT(_27221)) {
        _27222 = (_27221 == 0);
    }
    else {
        _27222 = unary_op(NOT, _27221);
    }
    DeRef(_27221);
    _27221 = NOVALUE;
    if (IS_ATOM_INT(_27222)) {
        if (_27222 == 0) {
            DeRef(_27223);
            _27223 = 0;
            goto L6; // [119] 145
        }
    }
    else {
        if (DBL_PTR(_27222)->dbl == 0.0) {
            DeRef(_27223);
            _27223 = 0;
            goto L6; // [119] 145
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27224 = (object)*(((s1_ptr)_2)->base + _retsym_53738);
    _2 = (object)SEQ_PTR(_27224);
    _27225 = (object)*(((s1_ptr)_2)->base + 4LL);
    _27224 = NOVALUE;
    if (IS_ATOM_INT(_27225)) {
        _27226 = (_27225 <= 3LL);
    }
    else {
        _27226 = binary_op(LESSEQ, _27225, 3LL);
    }
    _27225 = NOVALUE;
    DeRef(_27223);
    if (IS_ATOM_INT(_27226))
    _27223 = (_27226 != 0);
    else
    _27223 = DBL_PTR(_27226)->dbl != 0.0;
L6: 
    if (_27223 == 0)
    {
        _27223 = NOVALUE;
        goto L7; // [146] 393
    }
    else{
        _27223 = NOVALUE;
    }
L5: 

    /** inline.e:272			sequence code = {}*/
    RefDS(_21993);
    DeRef(_code_53771);
    _code_53771 = _21993;

    /** inline.e:274			integer ret_pc = 0*/
    _ret_pc_53772 = 0LL;

    /** inline.e:276			if not (find( retsym, inline_params ) or find( retsym, proc_vars )) then*/
    _27227 = find_from(_retsym_53738, _67inline_params_53454, 1LL);
    if (_27227 != 0) {
        DeRef(_27228);
        _27228 = 1;
        goto L8; // [171] 186
    }
    _27229 = find_from(_retsym_53738, _67proc_vars_53450, 1LL);
    _27228 = (_27229 != 0);
L8: 
    if (_27228 != 0)
    goto L9; // [186] 206
    _27228 = NOVALUE;

    /** inline.e:277				ret_pc = rfind( generic_symbol( retsym ), inline_code, pc )*/
    _27231 = _67generic_symbol(_retsym_53738);
    RefDS(_67inline_code_53449);
    _ret_pc_53772 = _16rfind(_27231, _67inline_code_53449, _pc_53736);
    _27231 = NOVALUE;
    if (!IS_ATOM_INT(_ret_pc_53772)) {
        _1 = (object)(DBL_PTR(_ret_pc_53772)->dbl);
        DeRefDS(_ret_pc_53772);
        _ret_pc_53772 = _1;
    }
L9: 

    /** inline.e:281			if ret_pc and eu:compare( inline_code[ret_pc-1], PRIVATE_INIT_CHECK ) then*/
    if (_ret_pc_53772 == 0) {
        goto LA; // [208] 277
    }
    _27234 = _ret_pc_53772 - 1LL;
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    _27235 = (object)*(((s1_ptr)_2)->base + _27234);
    if (IS_ATOM_INT(_27235) && IS_ATOM_INT(30LL)){
        _27236 = (_27235 < 30LL) ? -1 : (_27235 > 30LL);
    }
    else{
        _27236 = compare(_27235, 30LL);
    }
    _27235 = NOVALUE;
    if (_27236 == 0)
    {
        _27236 = NOVALUE;
        goto LA; // [229] 277
    }
    else{
        _27236 = NOVALUE;
    }

    /** inline.e:282				inline_code[ret_pc] = {INLINE_TARGET}*/
    RefDS(_27237);
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53449 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _ret_pc_53772);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27237;
    DeRef(_1);

    /** inline.e:284				if equal( inline_code[ret_pc-1], REF_TEMP ) then*/
    _27238 = _ret_pc_53772 - 1LL;
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    _27239 = (object)*(((s1_ptr)_2)->base + _27238);
    if (_27239 == 207LL)
    _27240 = 1;
    else if (IS_ATOM_INT(_27239) && IS_ATOM_INT(207LL))
    _27240 = 0;
    else
    _27240 = (compare(_27239, 207LL) == 0);
    _27239 = NOVALUE;
    if (_27240 == 0)
    {
        _27240 = NOVALUE;
        goto LB; // [258] 292
    }
    else{
        _27240 = NOVALUE;
    }

    /** inline.e:287					inline_code[ret_pc-2] = {INLINE_TARGET}*/
    _27241 = _ret_pc_53772 - 2LL;
    RefDS(_27237);
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53449 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27241);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27237;
    DeRef(_1);
    goto LB; // [274] 292
LA: 

    /** inline.e:290				code = {ASSIGN, generic_symbol( retsym ), {INLINE_TARGET}}*/
    _27242 = _67generic_symbol(_retsym_53738);
    _0 = _code_53771;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 18LL;
    ((intptr_t*)_2)[2] = _27242;
    RefDS(_27237);
    ((intptr_t*)_2)[3] = _27237;
    _code_53771 = MAKE_SEQ(_1);
    DeRef(_0);
    _27242 = NOVALUE;
LB: 

    /** inline.e:293			if pc != length( inline_code ) - ( 3 + TRANSLATE ) then*/
    if (IS_SEQUENCE(_67inline_code_53449)){
            _27244 = SEQ_PTR(_67inline_code_53449)->length;
    }
    else {
        _27244 = 1;
    }
    _27245 = 3LL + _36TRANSLATE_21041;
    _27246 = _27244 - _27245;
    _27244 = NOVALUE;
    _27245 = NOVALUE;
    if (_pc_53736 == _27246)
    goto LC; // [309] 330

    /** inline.e:294				code &= { ELSE, {INLINE_ADDR, -1 }}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4LL;
    ((intptr_t *)_2)[2] = -1LL;
    _27248 = MAKE_SEQ(_1);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 23LL;
    ((intptr_t *)_2)[2] = _27248;
    _27249 = MAKE_SEQ(_1);
    _27248 = NOVALUE;
    Concat((object_ptr)&_code_53771, _code_53771, _27249);
    DeRefDS(_27249);
    _27249 = NOVALUE;
LC: 

    /** inline.e:298			replace_code( code, pc, pc + 3 )*/
    _27251 = _pc_53736 + 3LL;
    if ((object)((uintptr_t)_27251 + (uintptr_t)HIGH_BITS) >= 0){
        _27251 = NewDouble((eudouble)_27251);
    }
    RefDS(_code_53771);
    _67replace_code(_code_53771, _pc_53736, _27251);
    _27251 = NOVALUE;

    /** inline.e:299			ret_pc = find( { INLINE_ADDR, -1 }, inline_code, pc )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4LL;
    ((intptr_t *)_2)[2] = -1LL;
    _27252 = MAKE_SEQ(_1);
    _ret_pc_53772 = find_from(_27252, _67inline_code_53449, _pc_53736);
    DeRefDS(_27252);
    _27252 = NOVALUE;

    /** inline.e:300			if ret_pc then*/
    if (_ret_pc_53772 == 0)
    {
        goto LD; // [356] 382
    }
    else{
    }

    /** inline.e:301				inline_code[ret_pc][2] = length(inline_code) + 1*/
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53449 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ret_pc_53772 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_67inline_code_53449)){
            _27256 = SEQ_PTR(_67inline_code_53449)->length;
    }
    else {
        _27256 = 1;
    }
    _27257 = _27256 + 1;
    _27256 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27257;
    if( _1 != _27257 ){
        DeRef(_1);
    }
    _27257 = NOVALUE;
    _27254 = NOVALUE;
LD: 

    /** inline.e:303			return 1*/
    DeRef(_code_53771);
    DeRef(_27226);
    _27226 = NOVALUE;
    DeRef(_27238);
    _27238 = NOVALUE;
    DeRef(_27208);
    _27208 = NOVALUE;
    DeRef(_27246);
    _27246 = NOVALUE;
    DeRef(_27241);
    _27241 = NOVALUE;
    DeRef(_27234);
    _27234 = NOVALUE;
    DeRef(_27219);
    _27219 = NOVALUE;
    DeRef(_27222);
    _27222 = NOVALUE;
    return 1LL;
    goto LE; // [390] 502
L7: 

    /** inline.e:306			sequence code = {ASSIGN, retsym, {INLINE_TARGET}}*/
    _0 = _code_53817;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 18LL;
    ((intptr_t*)_2)[2] = _retsym_53738;
    RefDS(_27237);
    ((intptr_t*)_2)[3] = _27237;
    _code_53817 = MAKE_SEQ(_1);
    DeRef(_0);

    /** inline.e:307			if pc != length( inline_code ) - ( 3 + TRANSLATE ) then*/
    if (IS_SEQUENCE(_67inline_code_53449)){
            _27259 = SEQ_PTR(_67inline_code_53449)->length;
    }
    else {
        _27259 = 1;
    }
    _27260 = 3LL + _36TRANSLATE_21041;
    _27261 = _27259 - _27260;
    _27259 = NOVALUE;
    _27260 = NOVALUE;
    if (_pc_53736 == _27261)
    goto LF; // [420] 441

    /** inline.e:308				code &= { ELSE, {INLINE_ADDR, -1 }}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4LL;
    ((intptr_t *)_2)[2] = -1LL;
    _27263 = MAKE_SEQ(_1);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 23LL;
    ((intptr_t *)_2)[2] = _27263;
    _27264 = MAKE_SEQ(_1);
    _27263 = NOVALUE;
    Concat((object_ptr)&_code_53817, _code_53817, _27264);
    DeRefDS(_27264);
    _27264 = NOVALUE;
LF: 

    /** inline.e:312			replace_code( code, pc, pc + 3 )*/
    _27266 = _pc_53736 + 3LL;
    if ((object)((uintptr_t)_27266 + (uintptr_t)HIGH_BITS) >= 0){
        _27266 = NewDouble((eudouble)_27266);
    }
    RefDS(_code_53817);
    _67replace_code(_code_53817, _pc_53736, _27266);
    _27266 = NOVALUE;

    /** inline.e:313			integer ret_pc = find( { INLINE_ADDR, -1 }, inline_code, pc )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4LL;
    ((intptr_t *)_2)[2] = -1LL;
    _27267 = MAKE_SEQ(_1);
    _ret_pc_53831 = find_from(_27267, _67inline_code_53449, _pc_53736);
    DeRefDS(_27267);
    _27267 = NOVALUE;

    /** inline.e:314			if ret_pc then*/
    if (_ret_pc_53831 == 0)
    {
        goto L10; // [467] 493
    }
    else{
    }

    /** inline.e:315				inline_code[ret_pc][2] = length(inline_code) + 1*/
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53449 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ret_pc_53831 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_67inline_code_53449)){
            _27271 = SEQ_PTR(_67inline_code_53449)->length;
    }
    else {
        _27271 = 1;
    }
    _27272 = _27271 + 1;
    _27271 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27272;
    if( _1 != _27272 ){
        DeRef(_1);
    }
    _27272 = NOVALUE;
    _27269 = NOVALUE;
L10: 

    /** inline.e:317			return 1*/
    DeRef(_code_53817);
    DeRef(_27226);
    _27226 = NOVALUE;
    DeRef(_27238);
    _27238 = NOVALUE;
    DeRef(_27208);
    _27208 = NOVALUE;
    DeRef(_27246);
    _27246 = NOVALUE;
    DeRef(_27261);
    _27261 = NOVALUE;
    DeRef(_27241);
    _27241 = NOVALUE;
    DeRef(_27234);
    _27234 = NOVALUE;
    DeRef(_27219);
    _27219 = NOVALUE;
    DeRef(_27222);
    _27222 = NOVALUE;
    return 1LL;
LE: 

    /** inline.e:319		return 0*/
    DeRef(_27226);
    _27226 = NOVALUE;
    DeRef(_27238);
    _27238 = NOVALUE;
    DeRef(_27208);
    _27208 = NOVALUE;
    DeRef(_27246);
    _27246 = NOVALUE;
    DeRef(_27261);
    _27261 = NOVALUE;
    DeRef(_27241);
    _27241 = NOVALUE;
    DeRef(_27234);
    _27234 = NOVALUE;
    DeRef(_27219);
    _27219 = NOVALUE;
    DeRef(_27222);
    _27222 = NOVALUE;
    return 0LL;
    ;
}


object _67inline_op(object _pc_53841)
{
    object _op_53842 = NOVALUE;
    object _code_53847 = NOVALUE;
    object _stlen_53880 = NOVALUE;
    object _file_53885 = NOVALUE;
    object _ok_53890 = NOVALUE;
    object _original_table_53913 = NOVALUE;
    object _jump_table_53917 = NOVALUE;
    object _27333 = NOVALUE;
    object _27332 = NOVALUE;
    object _27331 = NOVALUE;
    object _27330 = NOVALUE;
    object _27329 = NOVALUE;
    object _27328 = NOVALUE;
    object _27327 = NOVALUE;
    object _27326 = NOVALUE;
    object _27325 = NOVALUE;
    object _27324 = NOVALUE;
    object _27323 = NOVALUE;
    object _27322 = NOVALUE;
    object _27319 = NOVALUE;
    object _27318 = NOVALUE;
    object _27317 = NOVALUE;
    object _27316 = NOVALUE;
    object _27314 = NOVALUE;
    object _27312 = NOVALUE;
    object _27311 = NOVALUE;
    object _27309 = NOVALUE;
    object _27305 = NOVALUE;
    object _27304 = NOVALUE;
    object _27303 = NOVALUE;
    object _27302 = NOVALUE;
    object _27301 = NOVALUE;
    object _27300 = NOVALUE;
    object _27297 = NOVALUE;
    object _27296 = NOVALUE;
    object _27294 = NOVALUE;
    object _27293 = NOVALUE;
    object _27291 = NOVALUE;
    object _27289 = NOVALUE;
    object _27288 = NOVALUE;
    object _27287 = NOVALUE;
    object _27286 = NOVALUE;
    object _27285 = NOVALUE;
    object _27284 = NOVALUE;
    object _27283 = NOVALUE;
    object _27281 = NOVALUE;
    object _27280 = NOVALUE;
    object _27279 = NOVALUE;
    object _27277 = NOVALUE;
    object _27276 = NOVALUE;
    object _27275 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** inline.e:324		integer op = inline_code[pc]*/
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    _op_53842 = (object)*(((s1_ptr)_2)->base + _pc_53841);
    if (!IS_ATOM_INT(_op_53842))
    _op_53842 = (object)DBL_PTR(_op_53842)->dbl;

    /** inline.e:326		if op = RETURNP then*/
    if (_op_53842 != 29LL)
    goto L1; // [15] 150

    /** inline.e:333			sequence code = ""*/
    RefDS(_21993);
    DeRef(_code_53847);
    _code_53847 = _21993;

    /** inline.e:335			if pc != length( inline_code ) - 1 - TRANSLATE then*/
    if (IS_SEQUENCE(_67inline_code_53449)){
            _27275 = SEQ_PTR(_67inline_code_53449)->length;
    }
    else {
        _27275 = 1;
    }
    _27276 = _27275 - 1LL;
    _27275 = NOVALUE;
    _27277 = _27276 - _36TRANSLATE_21041;
    _27276 = NOVALUE;
    if (_pc_53841 == _27277)
    goto L2; // [43] 92

    /** inline.e:336				code = { ELSE, {INLINE_ADDR, length( inline_code ) + 1 }}*/
    if (IS_SEQUENCE(_67inline_code_53449)){
            _27279 = SEQ_PTR(_67inline_code_53449)->length;
    }
    else {
        _27279 = 1;
    }
    _27280 = _27279 + 1;
    _27279 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4LL;
    ((intptr_t *)_2)[2] = _27280;
    _27281 = MAKE_SEQ(_1);
    _27280 = NOVALUE;
    DeRefDS(_code_53847);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 23LL;
    ((intptr_t *)_2)[2] = _27281;
    _code_53847 = MAKE_SEQ(_1);
    _27281 = NOVALUE;

    /** inline.e:337				if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L3; // [72] 134
    }
    else{
    }

    /** inline.e:338					inline_code[$] = NOP1*/
    if (IS_SEQUENCE(_67inline_code_53449)){
            _27283 = SEQ_PTR(_67inline_code_53449)->length;
    }
    else {
        _27283 = 1;
    }
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53449 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27283);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 159LL;
    DeRef(_1);
    goto L3; // [89] 134
L2: 

    /** inline.e:341			elsif TRANSLATE and inline_code[$] = BADRETURNF then*/
    if (_36TRANSLATE_21041 == 0) {
        goto L4; // [96] 133
    }
    if (IS_SEQUENCE(_67inline_code_53449)){
            _27285 = SEQ_PTR(_67inline_code_53449)->length;
    }
    else {
        _27285 = 1;
    }
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    _27286 = (object)*(((s1_ptr)_2)->base + _27285);
    if (IS_ATOM_INT(_27286)) {
        _27287 = (_27286 == 43LL);
    }
    else {
        _27287 = binary_op(EQUALS, _27286, 43LL);
    }
    _27286 = NOVALUE;
    if (_27287 == 0) {
        DeRef(_27287);
        _27287 = NOVALUE;
        goto L4; // [116] 133
    }
    else {
        if (!IS_ATOM_INT(_27287) && DBL_PTR(_27287)->dbl == 0.0){
            DeRef(_27287);
            _27287 = NOVALUE;
            goto L4; // [116] 133
        }
        DeRef(_27287);
        _27287 = NOVALUE;
    }
    DeRef(_27287);
    _27287 = NOVALUE;

    /** inline.e:342				inline_code[$] = NOP1*/
    if (IS_SEQUENCE(_67inline_code_53449)){
            _27288 = SEQ_PTR(_67inline_code_53449)->length;
    }
    else {
        _27288 = 1;
    }
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53449 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27288);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 159LL;
    DeRef(_1);
L4: 
L3: 

    /** inline.e:344			replace_code( code, pc, pc + 2 )*/
    _27289 = _pc_53841 + 2LL;
    if ((object)((uintptr_t)_27289 + (uintptr_t)HIGH_BITS) >= 0){
        _27289 = NewDouble((eudouble)_27289);
    }
    RefDS(_code_53847);
    _67replace_code(_code_53847, _pc_53841, _27289);
    _27289 = NOVALUE;
    DeRefDS(_code_53847);
    _code_53847 = NOVALUE;
    goto L5; // [147] 526
L1: 

    /** inline.e:346		elsif op = RETURNF then*/
    if (_op_53842 != 28LL)
    goto L6; // [154] 171

    /** inline.e:347			return returnf( pc )*/
    _27291 = _67returnf(_pc_53841);
    DeRef(_27277);
    _27277 = NOVALUE;
    return _27291;
    goto L5; // [168] 526
L6: 

    /** inline.e:349		elsif op = ROUTINE_ID then*/
    if (_op_53842 != 134LL)
    goto L7; // [175] 273

    /** inline.e:351			integer*/

    /** inline.e:352				stlen = inline_code[pc+2+TRANSLATE],*/
    _27293 = _pc_53841 + 2LL;
    if ((object)((uintptr_t)_27293 + (uintptr_t)HIGH_BITS) >= 0){
        _27293 = NewDouble((eudouble)_27293);
    }
    if (IS_ATOM_INT(_27293)) {
        _27294 = _27293 + _36TRANSLATE_21041;
    }
    else {
        _27294 = NewDouble(DBL_PTR(_27293)->dbl + (eudouble)_36TRANSLATE_21041);
    }
    DeRef(_27293);
    _27293 = NOVALUE;
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    if (!IS_ATOM_INT(_27294)){
        _stlen_53880 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27294)->dbl));
    }
    else{
        _stlen_53880 = (object)*(((s1_ptr)_2)->base + _27294);
    }
    if (!IS_ATOM_INT(_stlen_53880))
    _stlen_53880 = (object)DBL_PTR(_stlen_53880)->dbl;

    /** inline.e:353				file  = inline_code[pc+4+TRANSLATE],*/
    _27296 = _pc_53841 + 4LL;
    if ((object)((uintptr_t)_27296 + (uintptr_t)HIGH_BITS) >= 0){
        _27296 = NewDouble((eudouble)_27296);
    }
    if (IS_ATOM_INT(_27296)) {
        _27297 = _27296 + _36TRANSLATE_21041;
    }
    else {
        _27297 = NewDouble(DBL_PTR(_27296)->dbl + (eudouble)_36TRANSLATE_21041);
    }
    DeRef(_27296);
    _27296 = NOVALUE;
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    if (!IS_ATOM_INT(_27297)){
        _file_53885 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27297)->dbl));
    }
    else{
        _file_53885 = (object)*(((s1_ptr)_2)->base + _27297);
    }
    if (!IS_ATOM_INT(_file_53885))
    _file_53885 = (object)DBL_PTR(_file_53885)->dbl;

    /** inline.e:354				ok    = adjust_il( pc, op )*/
    _ok_53890 = _67adjust_il(_pc_53841, _op_53842);
    if (!IS_ATOM_INT(_ok_53890)) {
        _1 = (object)(DBL_PTR(_ok_53890)->dbl);
        DeRefDS(_ok_53890);
        _ok_53890 = _1;
    }

    /** inline.e:355			inline_code[pc+2+TRANSLATE] = stlen*/
    _27300 = _pc_53841 + 2LL;
    if ((object)((uintptr_t)_27300 + (uintptr_t)HIGH_BITS) >= 0){
        _27300 = NewDouble((eudouble)_27300);
    }
    if (IS_ATOM_INT(_27300)) {
        _27301 = _27300 + _36TRANSLATE_21041;
    }
    else {
        _27301 = NewDouble(DBL_PTR(_27300)->dbl + (eudouble)_36TRANSLATE_21041);
    }
    DeRef(_27300);
    _27300 = NOVALUE;
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53449 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27301))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27301)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27301);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _stlen_53880;
    DeRef(_1);

    /** inline.e:356			inline_code[pc+4+TRANSLATE] = file*/
    _27302 = _pc_53841 + 4LL;
    if ((object)((uintptr_t)_27302 + (uintptr_t)HIGH_BITS) >= 0){
        _27302 = NewDouble((eudouble)_27302);
    }
    if (IS_ATOM_INT(_27302)) {
        _27303 = _27302 + _36TRANSLATE_21041;
    }
    else {
        _27303 = NewDouble(DBL_PTR(_27302)->dbl + (eudouble)_36TRANSLATE_21041);
    }
    DeRef(_27302);
    _27302 = NOVALUE;
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53449 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27303))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27303)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27303);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _file_53885;
    DeRef(_1);

    /** inline.e:358			return ok*/
    DeRef(_27297);
    _27297 = NOVALUE;
    DeRef(_27277);
    _27277 = NOVALUE;
    DeRef(_27294);
    _27294 = NOVALUE;
    DeRef(_27303);
    _27303 = NOVALUE;
    DeRef(_27301);
    _27301 = NOVALUE;
    DeRef(_27291);
    _27291 = NOVALUE;
    return _ok_53890;
    goto L5; // [270] 526
L7: 

    /** inline.e:360		elsif op_info[op][OP_SIZE_TYPE] = FIXED_SIZE then*/
    _2 = (object)SEQ_PTR(_66op_info_24235);
    _27304 = (object)*(((s1_ptr)_2)->base + _op_53842);
    _2 = (object)SEQ_PTR(_27304);
    _27305 = (object)*(((s1_ptr)_2)->base + 1LL);
    _27304 = NOVALUE;
    if (binary_op_a(NOTEQ, _27305, 1LL)){
        _27305 = NOVALUE;
        goto L8; // [289] 397
    }
    _27305 = NOVALUE;

    /** inline.e:361			switch op do*/
    _0 = _op_53842;
    switch ( _0 ){ 

        /** inline.e:362				case SWITCH, SWITCH_RT, SWITCH_I, SWITCH_SPI then*/
        case 185:
        case 202:
        case 193:
        case 192:

        /** inline.e:364					symtab_index original_table = inline_code[pc + 3]*/
        _27309 = _pc_53841 + 3LL;
        _2 = (object)SEQ_PTR(_67inline_code_53449);
        _original_table_53913 = (object)*(((s1_ptr)_2)->base + _27309);
        if (!IS_ATOM_INT(_original_table_53913)){
            _original_table_53913 = (object)DBL_PTR(_original_table_53913)->dbl;
        }

        /** inline.e:365					symtab_index jump_table = NewStringSym( {-2, length(SymTab) } )*/
        if (IS_SEQUENCE(_37SymTab_15406)){
                _27311 = SEQ_PTR(_37SymTab_15406)->length;
        }
        else {
            _27311 = 1;
        }
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -2LL;
        ((intptr_t *)_2)[2] = _27311;
        _27312 = MAKE_SEQ(_1);
        _27311 = NOVALUE;
        _jump_table_53917 = _54NewStringSym(_27312);
        _27312 = NOVALUE;
        if (!IS_ATOM_INT(_jump_table_53917)) {
            _1 = (object)(DBL_PTR(_jump_table_53917)->dbl);
            DeRefDS(_jump_table_53917);
            _jump_table_53917 = _1;
        }

        /** inline.e:366					SymTab[jump_table][S_OBJ] = SymTab[original_table][S_OBJ]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_jump_table_53917 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27316 = (object)*(((s1_ptr)_2)->base + _original_table_53913);
        _2 = (object)SEQ_PTR(_27316);
        _27317 = (object)*(((s1_ptr)_2)->base + 1LL);
        _27316 = NOVALUE;
        Ref(_27317);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _27317;
        if( _1 != _27317 ){
            DeRef(_1);
        }
        _27317 = NOVALUE;
        _27314 = NOVALUE;

        /** inline.e:367					inline_code[pc+3] = jump_table*/
        _27318 = _pc_53841 + 3LL;
        _2 = (object)SEQ_PTR(_67inline_code_53449);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67inline_code_53449 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _27318);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _jump_table_53917;
        DeRef(_1);
    ;}
    /** inline.e:369			return adjust_il( pc, op )*/
    _27319 = _67adjust_il(_pc_53841, _op_53842);
    DeRef(_27297);
    _27297 = NOVALUE;
    DeRef(_27277);
    _27277 = NOVALUE;
    DeRef(_27318);
    _27318 = NOVALUE;
    DeRef(_27294);
    _27294 = NOVALUE;
    DeRef(_27303);
    _27303 = NOVALUE;
    DeRef(_27309);
    _27309 = NOVALUE;
    DeRef(_27301);
    _27301 = NOVALUE;
    DeRef(_27291);
    _27291 = NOVALUE;
    return _27319;
    goto L5; // [394] 526
L8: 

    /** inline.e:372			switch op with fallthru do*/
    _0 = _op_53842;
    switch ( _0 ){ 

        /** inline.e:373				case REF_TEMP then*/
        case 207:

        /** inline.e:374					inline_code[pc+1] = {INLINE_TARGET}*/
        _27322 = _pc_53841 + 1;
        RefDS(_27237);
        _2 = (object)SEQ_PTR(_67inline_code_53449);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67inline_code_53449 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _27322);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _27237;
        DeRef(_1);

        /** inline.e:376				case CONCAT_N then*/
        case 157:
        case 31:

        /** inline.e:379					if check_for_param( pc + 2 + inline_code[pc+1] ) then*/
        _27323 = _pc_53841 + 2LL;
        if ((object)((uintptr_t)_27323 + (uintptr_t)HIGH_BITS) >= 0){
            _27323 = NewDouble((eudouble)_27323);
        }
        _27324 = _pc_53841 + 1;
        _2 = (object)SEQ_PTR(_67inline_code_53449);
        _27325 = (object)*(((s1_ptr)_2)->base + _27324);
        if (IS_ATOM_INT(_27323) && IS_ATOM_INT(_27325)) {
            _27326 = _27323 + _27325;
            if ((object)((uintptr_t)_27326 + (uintptr_t)HIGH_BITS) >= 0){
                _27326 = NewDouble((eudouble)_27326);
            }
        }
        else {
            _27326 = binary_op(PLUS, _27323, _27325);
        }
        DeRef(_27323);
        _27323 = NOVALUE;
        _27325 = NOVALUE;
        _27327 = _67check_for_param(_27326);
        _27326 = NOVALUE;
        if (_27327 == 0) {
            DeRef(_27327);
            _27327 = NOVALUE;
            goto L9; // [450] 454
        }
        else {
            if (!IS_ATOM_INT(_27327) && DBL_PTR(_27327)->dbl == 0.0){
                DeRef(_27327);
                _27327 = NOVALUE;
                goto L9; // [450] 454
            }
            DeRef(_27327);
            _27327 = NOVALUE;
        }
        DeRef(_27327);
        _27327 = NOVALUE;
L9: 

        /** inline.e:383					for i = pc + 2 to pc + 2 + inline_code[pc+1] do*/
        _27328 = _pc_53841 + 2LL;
        if ((object)((uintptr_t)_27328 + (uintptr_t)HIGH_BITS) >= 0){
            _27328 = NewDouble((eudouble)_27328);
        }
        _27329 = _pc_53841 + 2LL;
        if ((object)((uintptr_t)_27329 + (uintptr_t)HIGH_BITS) >= 0){
            _27329 = NewDouble((eudouble)_27329);
        }
        _27330 = _pc_53841 + 1;
        _2 = (object)SEQ_PTR(_67inline_code_53449);
        _27331 = (object)*(((s1_ptr)_2)->base + _27330);
        if (IS_ATOM_INT(_27329) && IS_ATOM_INT(_27331)) {
            _27332 = _27329 + _27331;
            if ((object)((uintptr_t)_27332 + (uintptr_t)HIGH_BITS) >= 0){
                _27332 = NewDouble((eudouble)_27332);
            }
        }
        else {
            _27332 = binary_op(PLUS, _27329, _27331);
        }
        DeRef(_27329);
        _27329 = NOVALUE;
        _27331 = NOVALUE;
        {
            object _i_53949;
            Ref(_27328);
            _i_53949 = _27328;
LA: 
            if (binary_op_a(GREATER, _i_53949, _27332)){
                goto LB; // [478] 508
            }

            /** inline.e:384						if not adjust_symbol( i ) then*/
            Ref(_i_53949);
            _27333 = _67adjust_symbol(_i_53949);
            if (IS_ATOM_INT(_27333)) {
                if (_27333 != 0){
                    DeRef(_27333);
                    _27333 = NOVALUE;
                    goto LC; // [491] 501
                }
            }
            else {
                if (DBL_PTR(_27333)->dbl != 0.0){
                    DeRef(_27333);
                    _27333 = NOVALUE;
                    goto LC; // [491] 501
                }
            }
            DeRef(_27333);
            _27333 = NOVALUE;

            /** inline.e:385							return 0*/
            DeRef(_i_53949);
            DeRef(_27297);
            _27297 = NOVALUE;
            DeRef(_27328);
            _27328 = NOVALUE;
            DeRef(_27319);
            _27319 = NOVALUE;
            DeRef(_27330);
            _27330 = NOVALUE;
            DeRef(_27277);
            _27277 = NOVALUE;
            DeRef(_27318);
            _27318 = NOVALUE;
            DeRef(_27332);
            _27332 = NOVALUE;
            DeRef(_27294);
            _27294 = NOVALUE;
            DeRef(_27303);
            _27303 = NOVALUE;
            DeRef(_27324);
            _27324 = NOVALUE;
            DeRef(_27309);
            _27309 = NOVALUE;
            DeRef(_27322);
            _27322 = NOVALUE;
            DeRef(_27301);
            _27301 = NOVALUE;
            DeRef(_27291);
            _27291 = NOVALUE;
            return 0LL;
LC: 

            /** inline.e:388					end for*/
            _0 = _i_53949;
            if (IS_ATOM_INT(_i_53949)) {
                _i_53949 = _i_53949 + 1LL;
                if ((object)((uintptr_t)_i_53949 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_53949 = NewDouble((eudouble)_i_53949);
                }
            }
            else {
                _i_53949 = binary_op_a(PLUS, _i_53949, 1LL);
            }
            DeRef(_0);
            goto LA; // [503] 485
LB: 
            ;
            DeRef(_i_53949);
        }

        /** inline.e:389					return 1*/
        DeRef(_27297);
        _27297 = NOVALUE;
        DeRef(_27328);
        _27328 = NOVALUE;
        DeRef(_27319);
        _27319 = NOVALUE;
        DeRef(_27330);
        _27330 = NOVALUE;
        DeRef(_27277);
        _27277 = NOVALUE;
        DeRef(_27318);
        _27318 = NOVALUE;
        DeRef(_27332);
        _27332 = NOVALUE;
        DeRef(_27294);
        _27294 = NOVALUE;
        DeRef(_27303);
        _27303 = NOVALUE;
        DeRef(_27324);
        _27324 = NOVALUE;
        DeRef(_27309);
        _27309 = NOVALUE;
        DeRef(_27322);
        _27322 = NOVALUE;
        DeRef(_27301);
        _27301 = NOVALUE;
        DeRef(_27291);
        _27291 = NOVALUE;
        return 1LL;

        /** inline.e:390				case else*/
        default:

        /** inline.e:391					return 0*/
        DeRef(_27297);
        _27297 = NOVALUE;
        DeRef(_27328);
        _27328 = NOVALUE;
        DeRef(_27319);
        _27319 = NOVALUE;
        DeRef(_27330);
        _27330 = NOVALUE;
        DeRef(_27277);
        _27277 = NOVALUE;
        DeRef(_27318);
        _27318 = NOVALUE;
        DeRef(_27332);
        _27332 = NOVALUE;
        DeRef(_27294);
        _27294 = NOVALUE;
        DeRef(_27303);
        _27303 = NOVALUE;
        DeRef(_27324);
        _27324 = NOVALUE;
        DeRef(_27309);
        _27309 = NOVALUE;
        DeRef(_27322);
        _27322 = NOVALUE;
        DeRef(_27301);
        _27301 = NOVALUE;
        DeRef(_27291);
        _27291 = NOVALUE;
        return 0LL;
    ;}L5: 

    /** inline.e:394		return 1*/
    DeRef(_27297);
    _27297 = NOVALUE;
    DeRef(_27328);
    _27328 = NOVALUE;
    DeRef(_27319);
    _27319 = NOVALUE;
    DeRef(_27330);
    _27330 = NOVALUE;
    DeRef(_27277);
    _27277 = NOVALUE;
    DeRef(_27318);
    _27318 = NOVALUE;
    DeRef(_27332);
    _27332 = NOVALUE;
    DeRef(_27294);
    _27294 = NOVALUE;
    DeRef(_27303);
    _27303 = NOVALUE;
    DeRef(_27324);
    _27324 = NOVALUE;
    DeRef(_27309);
    _27309 = NOVALUE;
    DeRef(_27322);
    _27322 = NOVALUE;
    DeRef(_27301);
    _27301 = NOVALUE;
    DeRef(_27291);
    _27291 = NOVALUE;
    return 1LL;
    ;
}


void _67restore_code()
{
    object _27335 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:399		if length( temp_code ) then*/
    if (IS_SEQUENCE(_67temp_code_53959)){
            _27335 = SEQ_PTR(_67temp_code_53959)->length;
    }
    else {
        _27335 = 1;
    }
    if (_27335 == 0)
    {
        _27335 = NOVALUE;
        goto L1; // [8] 21
    }
    else{
        _27335 = NOVALUE;
    }

    /** inline.e:400			Code = temp_code*/
    RefDS(_67temp_code_53959);
    DeRef(_36Code_21531);
    _36Code_21531 = _67temp_code_53959;
L1: 

    /** inline.e:402	end procedure*/
    return;
    ;
}


void _67check_inline(object _sub_53968)
{
    object _pc_53997 = NOVALUE;
    object _s_53999 = NOVALUE;
    object _backpatch_op_54037 = NOVALUE;
    object _op_54041 = NOVALUE;
    object _rtn_idx_54052 = NOVALUE;
    object _args_54057 = NOVALUE;
    object _args_54089 = NOVALUE;
    object _values_54118 = NOVALUE;
    object _27422 = NOVALUE;
    object _27421 = NOVALUE;
    object _27419 = NOVALUE;
    object _27416 = NOVALUE;
    object _27414 = NOVALUE;
    object _27413 = NOVALUE;
    object _27412 = NOVALUE;
    object _27410 = NOVALUE;
    object _27409 = NOVALUE;
    object _27408 = NOVALUE;
    object _27407 = NOVALUE;
    object _27406 = NOVALUE;
    object _27405 = NOVALUE;
    object _27404 = NOVALUE;
    object _27403 = NOVALUE;
    object _27402 = NOVALUE;
    object _27400 = NOVALUE;
    object _27399 = NOVALUE;
    object _27398 = NOVALUE;
    object _27397 = NOVALUE;
    object _27396 = NOVALUE;
    object _27394 = NOVALUE;
    object _27393 = NOVALUE;
    object _27392 = NOVALUE;
    object _27391 = NOVALUE;
    object _27390 = NOVALUE;
    object _27388 = NOVALUE;
    object _27387 = NOVALUE;
    object _27386 = NOVALUE;
    object _27385 = NOVALUE;
    object _27384 = NOVALUE;
    object _27383 = NOVALUE;
    object _27382 = NOVALUE;
    object _27381 = NOVALUE;
    object _27380 = NOVALUE;
    object _27379 = NOVALUE;
    object _27378 = NOVALUE;
    object _27377 = NOVALUE;
    object _27376 = NOVALUE;
    object _27375 = NOVALUE;
    object _27373 = NOVALUE;
    object _27370 = NOVALUE;
    object _27365 = NOVALUE;
    object _27363 = NOVALUE;
    object _27360 = NOVALUE;
    object _27359 = NOVALUE;
    object _27358 = NOVALUE;
    object _27357 = NOVALUE;
    object _27356 = NOVALUE;
    object _27355 = NOVALUE;
    object _27354 = NOVALUE;
    object _27353 = NOVALUE;
    object _27351 = NOVALUE;
    object _27349 = NOVALUE;
    object _27348 = NOVALUE;
    object _27346 = NOVALUE;
    object _27344 = NOVALUE;
    object _27342 = NOVALUE;
    object _27340 = NOVALUE;
    object _27339 = NOVALUE;
    object _27338 = NOVALUE;
    object _27337 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** inline.e:411		if OpTrace or SymTab[sub][S_TOKEN] = TYPE then*/
    if (_36OpTrace_21512 != 0) {
        goto L1; // [7] 34
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27337 = (object)*(((s1_ptr)_2)->base + _sub_53968);
    _2 = (object)SEQ_PTR(_27337);
    if (!IS_ATOM_INT(_36S_TOKEN_21081)){
        _27338 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    }
    else{
        _27338 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    }
    _27337 = NOVALUE;
    if (IS_ATOM_INT(_27338)) {
        _27339 = (_27338 == 504LL);
    }
    else {
        _27339 = binary_op(EQUALS, _27338, 504LL);
    }
    _27338 = NOVALUE;
    if (_27339 == 0) {
        DeRef(_27339);
        _27339 = NOVALUE;
        goto L2; // [30] 40
    }
    else {
        if (!IS_ATOM_INT(_27339) && DBL_PTR(_27339)->dbl == 0.0){
            DeRef(_27339);
            _27339 = NOVALUE;
            goto L2; // [30] 40
        }
        DeRef(_27339);
        _27339 = NOVALUE;
    }
    DeRef(_27339);
    _27339 = NOVALUE;
L1: 

    /** inline.e:412			return*/
    DeRefi(_backpatch_op_54037);
    return;
L2: 

    /** inline.e:414		inline_sub      = sub*/
    _67inline_sub_53463 = _sub_53968;

    /** inline.e:415		if get_fwdref_count() then*/
    _27340 = _44get_fwdref_count();
    if (_27340 == 0) {
        DeRef(_27340);
        _27340 = NOVALUE;
        goto L3; // [52] 65
    }
    else {
        if (!IS_ATOM_INT(_27340) && DBL_PTR(_27340)->dbl == 0.0){
            DeRef(_27340);
            _27340 = NOVALUE;
            goto L3; // [52] 65
        }
        DeRef(_27340);
        _27340 = NOVALUE;
    }
    DeRef(_27340);
    _27340 = NOVALUE;

    /** inline.e:416			defer()*/
    _67defer();

    /** inline.e:417			return*/
    DeRefi(_backpatch_op_54037);
    return;
L3: 

    /** inline.e:419		temp_code = ""*/
    RefDS(_21993);
    DeRef(_67temp_code_53959);
    _67temp_code_53959 = _21993;

    /** inline.e:420		if sub != CurrentSub then*/
    if (_sub_53968 == _36CurrentSub_21447)
    goto L4; // [76] 99

    /** inline.e:421			Code = SymTab[sub][S_CODE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27342 = (object)*(((s1_ptr)_2)->base + _sub_53968);
    DeRef(_36Code_21531);
    _2 = (object)SEQ_PTR(_27342);
    if (!IS_ATOM_INT(_36S_CODE_21088)){
        _36Code_21531 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
    }
    else{
        _36Code_21531 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21088);
    }
    Ref(_36Code_21531);
    _27342 = NOVALUE;
    goto L5; // [96] 109
L4: 

    /** inline.e:423			temp_code = Code*/
    RefDS(_36Code_21531);
    DeRef(_67temp_code_53959);
    _67temp_code_53959 = _36Code_21531;
L5: 

    /** inline.e:426		if length(Code) > OpInline then*/
    if (IS_SEQUENCE(_36Code_21531)){
            _27344 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _27344 = 1;
    }
    if (_27344 <= _36OpInline_21517)
    goto L6; // [118] 128

    /** inline.e:427			return*/
    DeRefi(_backpatch_op_54037);
    return;
L6: 

    /** inline.e:430		inline_code     = Code*/
    RefDS(_36Code_21531);
    DeRef(_67inline_code_53449);
    _67inline_code_53449 = _36Code_21531;

    /** inline.e:431		return_gotos    = 0*/
    _67return_gotos_53458 = 0LL;

    /** inline.e:432		prev_pc         = 1*/
    _67prev_pc_53457 = 1LL;

    /** inline.e:433		proc_vars       = {}*/
    RefDS(_21993);
    DeRefi(_67proc_vars_53450);
    _67proc_vars_53450 = _21993;

    /** inline.e:434		inline_temps    = {}*/
    RefDS(_21993);
    DeRef(_67inline_temps_53451);
    _67inline_temps_53451 = _21993;

    /** inline.e:435		inline_params   = {}*/
    RefDS(_21993);
    DeRefi(_67inline_params_53454);
    _67inline_params_53454 = _21993;

    /** inline.e:436		assigned_params = {}*/
    RefDS(_21993);
    DeRef(_67assigned_params_53455);
    _67assigned_params_53455 = _21993;

    /** inline.e:438		integer pc = 1*/
    _pc_53997 = 1LL;

    /** inline.e:439		symtab_index s = SymTab[sub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27346 = (object)*(((s1_ptr)_2)->base + _sub_53968);
    _2 = (object)SEQ_PTR(_27346);
    _s_53999 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_53999)){
        _s_53999 = (object)DBL_PTR(_s_53999)->dbl;
    }
    _27346 = NOVALUE;

    /** inline.e:440		for p = 1 to SymTab[sub][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27348 = (object)*(((s1_ptr)_2)->base + _sub_53968);
    _2 = (object)SEQ_PTR(_27348);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
        _27349 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
    }
    else{
        _27349 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
    }
    _27348 = NOVALUE;
    {
        object _p_54005;
        _p_54005 = 1LL;
L7: 
        if (binary_op_a(GREATER, _p_54005, _27349)){
            goto L8; // [210] 248
        }

        /** inline.e:441			inline_params &= s*/
        Append(&_67inline_params_53454, _67inline_params_53454, _s_53999);

        /** inline.e:442			s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27351 = (object)*(((s1_ptr)_2)->base + _s_53999);
        _2 = (object)SEQ_PTR(_27351);
        _s_53999 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_s_53999)){
            _s_53999 = (object)DBL_PTR(_s_53999)->dbl;
        }
        _27351 = NOVALUE;

        /** inline.e:443		end for*/
        _0 = _p_54005;
        if (IS_ATOM_INT(_p_54005)) {
            _p_54005 = _p_54005 + 1LL;
            if ((object)((uintptr_t)_p_54005 +(uintptr_t) HIGH_BITS) >= 0){
                _p_54005 = NewDouble((eudouble)_p_54005);
            }
        }
        else {
            _p_54005 = binary_op_a(PLUS, _p_54005, 1LL);
        }
        DeRef(_0);
        goto L7; // [243] 217
L8: 
        ;
        DeRef(_p_54005);
    }

    /** inline.e:445		while s != 0 and */
L9: 
    _27353 = (_s_53999 != 0LL);
    if (_27353 == 0) {
        goto LA; // [257] 335
    }
    _27355 = _54sym_scope(_s_53999);
    if (IS_ATOM_INT(_27355)) {
        _27356 = (_27355 <= 3LL);
    }
    else {
        _27356 = binary_op(LESSEQ, _27355, 3LL);
    }
    DeRef(_27355);
    _27355 = NOVALUE;
    if (IS_ATOM_INT(_27356)) {
        if (_27356 != 0) {
            DeRef(_27357);
            _27357 = 1;
            goto LB; // [271] 289
        }
    }
    else {
        if (DBL_PTR(_27356)->dbl != 0.0) {
            DeRef(_27357);
            _27357 = 1;
            goto LB; // [271] 289
        }
    }
    _27358 = _54sym_scope(_s_53999);
    if (IS_ATOM_INT(_27358)) {
        _27359 = (_27358 == 9LL);
    }
    else {
        _27359 = binary_op(EQUALS, _27358, 9LL);
    }
    DeRef(_27358);
    _27358 = NOVALUE;
    DeRef(_27357);
    if (IS_ATOM_INT(_27359))
    _27357 = (_27359 != 0);
    else
    _27357 = DBL_PTR(_27359)->dbl != 0.0;
LB: 
    if (_27357 == 0)
    {
        _27357 = NOVALUE;
        goto LA; // [290] 335
    }
    else{
        _27357 = NOVALUE;
    }

    /** inline.e:447			if sym_scope( s ) != SC_UNDEFINED then*/
    _27360 = _54sym_scope(_s_53999);
    if (binary_op_a(EQUALS, _27360, 9LL)){
        DeRef(_27360);
        _27360 = NOVALUE;
        goto LC; // [301] 314
    }
    DeRef(_27360);
    _27360 = NOVALUE;

    /** inline.e:448				proc_vars &= s*/
    Append(&_67proc_vars_53450, _67proc_vars_53450, _s_53999);
LC: 

    /** inline.e:451			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27363 = (object)*(((s1_ptr)_2)->base + _s_53999);
    _2 = (object)SEQ_PTR(_27363);
    _s_53999 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_53999)){
        _s_53999 = (object)DBL_PTR(_s_53999)->dbl;
    }
    _27363 = NOVALUE;

    /** inline.e:452		end while*/
    goto L9; // [332] 253
LA: 

    /** inline.e:453		sequence backpatch_op = {}*/
    RefDS(_21993);
    DeRefi(_backpatch_op_54037);
    _backpatch_op_54037 = _21993;

    /** inline.e:454		while pc < length( inline_code ) do*/
LD: 
    if (IS_SEQUENCE(_67inline_code_53449)){
            _27365 = SEQ_PTR(_67inline_code_53449)->length;
    }
    else {
        _27365 = 1;
    }
    if (_pc_53997 >= _27365)
    goto LE; // [352] 869

    /** inline.e:456			integer op = inline_code[pc]*/
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    _op_54041 = (object)*(((s1_ptr)_2)->base + _pc_53997);
    if (!IS_ATOM_INT(_op_54041))
    _op_54041 = (object)DBL_PTR(_op_54041)->dbl;

    /** inline.e:457			switch op do*/
    _0 = _op_54041;
    switch ( _0 ){ 

        /** inline.e:458				case PROC_FORWARD, FUNC_FORWARD then*/
        case 195:
        case 196:

        /** inline.e:459					defer()*/
        _67defer();

        /** inline.e:460					restore_code()*/
        _67restore_code();

        /** inline.e:461					return*/
        DeRefi(_backpatch_op_54037);
        DeRef(_27356);
        _27356 = NOVALUE;
        _27349 = NOVALUE;
        DeRef(_27353);
        _27353 = NOVALUE;
        DeRef(_27359);
        _27359 = NOVALUE;
        return;
        goto LF; // [390] 851

        /** inline.e:463				case PROC, FUNC then*/
        case 27:
        case 501:

        /** inline.e:464					symtab_index rtn_idx = inline_code[pc+1]*/
        _27370 = _pc_53997 + 1;
        _2 = (object)SEQ_PTR(_67inline_code_53449);
        _rtn_idx_54052 = (object)*(((s1_ptr)_2)->base + _27370);
        if (!IS_ATOM_INT(_rtn_idx_54052)){
            _rtn_idx_54052 = (object)DBL_PTR(_rtn_idx_54052)->dbl;
        }

        /** inline.e:465					if rtn_idx = sub then*/
        if (_rtn_idx_54052 != _sub_53968)
        goto L10; // [414] 428

        /** inline.e:467						restore_code()*/
        _67restore_code();

        /** inline.e:468						return*/
        DeRefi(_backpatch_op_54037);
        _27370 = NOVALUE;
        DeRef(_27356);
        _27356 = NOVALUE;
        _27349 = NOVALUE;
        DeRef(_27353);
        _27353 = NOVALUE;
        DeRef(_27359);
        _27359 = NOVALUE;
        return;
L10: 

        /** inline.e:471					integer args = SymTab[rtn_idx][S_NUM_ARGS]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27373 = (object)*(((s1_ptr)_2)->base + _rtn_idx_54052);
        _2 = (object)SEQ_PTR(_27373);
        if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
            _args_54057 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
        }
        else{
            _args_54057 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
        }
        if (!IS_ATOM_INT(_args_54057)){
            _args_54057 = (object)DBL_PTR(_args_54057)->dbl;
        }
        _27373 = NOVALUE;

        /** inline.e:472					if SymTab[rtn_idx][S_TOKEN] != PROC and check_for_param( pc + args + 2 ) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27375 = (object)*(((s1_ptr)_2)->base + _rtn_idx_54052);
        _2 = (object)SEQ_PTR(_27375);
        if (!IS_ATOM_INT(_36S_TOKEN_21081)){
            _27376 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
        }
        else{
            _27376 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
        }
        _27375 = NOVALUE;
        if (IS_ATOM_INT(_27376)) {
            _27377 = (_27376 != 27LL);
        }
        else {
            _27377 = binary_op(NOTEQ, _27376, 27LL);
        }
        _27376 = NOVALUE;
        if (IS_ATOM_INT(_27377)) {
            if (_27377 == 0) {
                goto L11; // [464] 485
            }
        }
        else {
            if (DBL_PTR(_27377)->dbl == 0.0) {
                goto L11; // [464] 485
            }
        }
        _27379 = _pc_53997 + _args_54057;
        if ((object)((uintptr_t)_27379 + (uintptr_t)HIGH_BITS) >= 0){
            _27379 = NewDouble((eudouble)_27379);
        }
        if (IS_ATOM_INT(_27379)) {
            _27380 = _27379 + 2LL;
            if ((object)((uintptr_t)_27380 + (uintptr_t)HIGH_BITS) >= 0){
                _27380 = NewDouble((eudouble)_27380);
            }
        }
        else {
            _27380 = NewDouble(DBL_PTR(_27379)->dbl + (eudouble)2LL);
        }
        DeRef(_27379);
        _27379 = NOVALUE;
        _27381 = _67check_for_param(_27380);
        _27380 = NOVALUE;
        if (_27381 == 0) {
            DeRef(_27381);
            _27381 = NOVALUE;
            goto L11; // [481] 485
        }
        else {
            if (!IS_ATOM_INT(_27381) && DBL_PTR(_27381)->dbl == 0.0){
                DeRef(_27381);
                _27381 = NOVALUE;
                goto L11; // [481] 485
            }
            DeRef(_27381);
            _27381 = NOVALUE;
        }
        DeRef(_27381);
        _27381 = NOVALUE;
L11: 

        /** inline.e:475					for i = 2 to args + 1 + (SymTab[rtn_idx][S_TOKEN] != PROC) do*/
        _27382 = _args_54057 + 1;
        if (_27382 > MAXINT){
            _27382 = NewDouble((eudouble)_27382);
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27383 = (object)*(((s1_ptr)_2)->base + _rtn_idx_54052);
        _2 = (object)SEQ_PTR(_27383);
        if (!IS_ATOM_INT(_36S_TOKEN_21081)){
            _27384 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
        }
        else{
            _27384 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
        }
        _27383 = NOVALUE;
        if (IS_ATOM_INT(_27384)) {
            _27385 = (_27384 != 27LL);
        }
        else {
            _27385 = binary_op(NOTEQ, _27384, 27LL);
        }
        _27384 = NOVALUE;
        if (IS_ATOM_INT(_27382) && IS_ATOM_INT(_27385)) {
            _27386 = _27382 + _27385;
            if ((object)((uintptr_t)_27386 + (uintptr_t)HIGH_BITS) >= 0){
                _27386 = NewDouble((eudouble)_27386);
            }
        }
        else {
            _27386 = binary_op(PLUS, _27382, _27385);
        }
        DeRef(_27382);
        _27382 = NOVALUE;
        DeRef(_27385);
        _27385 = NOVALUE;
        {
            object _i_54074;
            _i_54074 = 2LL;
L12: 
            if (binary_op_a(GREATER, _i_54074, _27386)){
                goto L13; // [513] 550
            }

            /** inline.e:476						if not adjust_symbol( pc + i ) then */
            if (IS_ATOM_INT(_i_54074)) {
                _27387 = _pc_53997 + _i_54074;
                if ((object)((uintptr_t)_27387 + (uintptr_t)HIGH_BITS) >= 0){
                    _27387 = NewDouble((eudouble)_27387);
                }
            }
            else {
                _27387 = NewDouble((eudouble)_pc_53997 + DBL_PTR(_i_54074)->dbl);
            }
            _27388 = _67adjust_symbol(_27387);
            _27387 = NOVALUE;
            if (IS_ATOM_INT(_27388)) {
                if (_27388 != 0){
                    DeRef(_27388);
                    _27388 = NOVALUE;
                    goto L14; // [530] 543
                }
            }
            else {
                if (DBL_PTR(_27388)->dbl != 0.0){
                    DeRef(_27388);
                    _27388 = NOVALUE;
                    goto L14; // [530] 543
                }
            }
            DeRef(_27388);
            _27388 = NOVALUE;

            /** inline.e:477							defer()*/
            _67defer();

            /** inline.e:478							return*/
            DeRef(_i_54074);
            DeRefi(_backpatch_op_54037);
            DeRef(_27386);
            _27386 = NOVALUE;
            DeRef(_27370);
            _27370 = NOVALUE;
            DeRef(_27356);
            _27356 = NOVALUE;
            _27349 = NOVALUE;
            DeRef(_27353);
            _27353 = NOVALUE;
            DeRef(_27359);
            _27359 = NOVALUE;
            DeRef(_27377);
            _27377 = NOVALUE;
            return;
L14: 

            /** inline.e:480					end for*/
            _0 = _i_54074;
            if (IS_ATOM_INT(_i_54074)) {
                _i_54074 = _i_54074 + 1LL;
                if ((object)((uintptr_t)_i_54074 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_54074 = NewDouble((eudouble)_i_54074);
                }
            }
            else {
                _i_54074 = binary_op_a(PLUS, _i_54074, 1LL);
            }
            DeRef(_0);
            goto L12; // [545] 520
L13: 
            ;
            DeRef(_i_54074);
        }
        goto LF; // [552] 851

        /** inline.e:482				case RIGHT_BRACE_N then*/
        case 31:

        /** inline.e:484					sequence args = inline_code[pc+2..inline_code[pc+1] + pc + 1]*/
        _27390 = _pc_53997 + 2LL;
        if ((object)((uintptr_t)_27390 + (uintptr_t)HIGH_BITS) >= 0){
            _27390 = NewDouble((eudouble)_27390);
        }
        _27391 = _pc_53997 + 1;
        _2 = (object)SEQ_PTR(_67inline_code_53449);
        _27392 = (object)*(((s1_ptr)_2)->base + _27391);
        if (IS_ATOM_INT(_27392)) {
            _27393 = _27392 + _pc_53997;
            if ((object)((uintptr_t)_27393 + (uintptr_t)HIGH_BITS) >= 0){
                _27393 = NewDouble((eudouble)_27393);
            }
        }
        else {
            _27393 = binary_op(PLUS, _27392, _pc_53997);
        }
        _27392 = NOVALUE;
        if (IS_ATOM_INT(_27393)) {
            _27394 = _27393 + 1;
        }
        else
        _27394 = binary_op(PLUS, 1, _27393);
        DeRef(_27393);
        _27393 = NOVALUE;
        rhs_slice_target = (object_ptr)&_args_54089;
        RHS_Slice(_67inline_code_53449, _27390, _27394);

        /** inline.e:486					for i = 1 to length(args) - 1 do*/
        if (IS_SEQUENCE(_args_54089)){
                _27396 = SEQ_PTR(_args_54089)->length;
        }
        else {
            _27396 = 1;
        }
        _27397 = _27396 - 1LL;
        _27396 = NOVALUE;
        {
            object _i_54097;
            _i_54097 = 1LL;
L15: 
            if (_i_54097 > _27397){
                goto L16; // [598] 644
            }

            /** inline.e:487						if find( args[i], args, i + 1 ) then*/
            _2 = (object)SEQ_PTR(_args_54089);
            _27398 = (object)*(((s1_ptr)_2)->base + _i_54097);
            _27399 = _i_54097 + 1;
            _27400 = find_from(_27398, _args_54089, _27399);
            _27398 = NOVALUE;
            _27399 = NOVALUE;
            if (_27400 == 0)
            {
                _27400 = NOVALUE;
                goto L17; // [620] 637
            }
            else{
                _27400 = NOVALUE;
            }

            /** inline.e:488							defer()*/
            _67defer();

            /** inline.e:489							restore_code()*/
            _67restore_code();

            /** inline.e:490							return*/
            DeRefDS(_args_54089);
            DeRefi(_backpatch_op_54037);
            DeRef(_27394);
            _27394 = NOVALUE;
            DeRef(_27386);
            _27386 = NOVALUE;
            DeRef(_27370);
            _27370 = NOVALUE;
            DeRef(_27356);
            _27356 = NOVALUE;
            _27349 = NOVALUE;
            DeRef(_27353);
            _27353 = NOVALUE;
            DeRef(_27391);
            _27391 = NOVALUE;
            DeRef(_27359);
            _27359 = NOVALUE;
            DeRef(_27390);
            _27390 = NOVALUE;
            DeRef(_27397);
            _27397 = NOVALUE;
            DeRef(_27377);
            _27377 = NOVALUE;
            return;
L17: 

            /** inline.e:492					end for*/
            _i_54097 = _i_54097 + 1LL;
            goto L15; // [639] 605
L16: 
            ;
        }

        /** inline.e:493					goto "inline op"*/
        DeRef(_args_54089);
        _args_54089 = NOVALUE;
        goto G18;
        goto LF; // [654] 851

        /** inline.e:495				case RIGHT_BRACE_2 then*/
        case 85:

        /** inline.e:496					if equal( inline_code[pc+1], inline_code[pc+2] ) then*/
        _27402 = _pc_53997 + 1;
        _2 = (object)SEQ_PTR(_67inline_code_53449);
        _27403 = (object)*(((s1_ptr)_2)->base + _27402);
        _27404 = _pc_53997 + 2LL;
        _2 = (object)SEQ_PTR(_67inline_code_53449);
        _27405 = (object)*(((s1_ptr)_2)->base + _27404);
        if (_27403 == _27405)
        _27406 = 1;
        else if (IS_ATOM_INT(_27403) && IS_ATOM_INT(_27405))
        _27406 = 0;
        else
        _27406 = (compare(_27403, _27405) == 0);
        _27403 = NOVALUE;
        _27405 = NOVALUE;
        if (_27406 == 0)
        {
            _27406 = NOVALUE;
            goto L19; // [686] 703
        }
        else{
            _27406 = NOVALUE;
        }

        /** inline.e:497						defer()*/
        _67defer();

        /** inline.e:498						restore_code()*/
        _67restore_code();

        /** inline.e:499						return*/
        DeRefi(_backpatch_op_54037);
        DeRef(_27394);
        _27394 = NOVALUE;
        DeRef(_27386);
        _27386 = NOVALUE;
        DeRef(_27370);
        _27370 = NOVALUE;
        DeRef(_27356);
        _27356 = NOVALUE;
        _27349 = NOVALUE;
        DeRef(_27353);
        _27353 = NOVALUE;
        DeRef(_27391);
        _27391 = NOVALUE;
        DeRef(_27359);
        _27359 = NOVALUE;
        DeRef(_27390);
        _27390 = NOVALUE;
        DeRef(_27397);
        _27397 = NOVALUE;
        _27402 = NOVALUE;
        DeRef(_27377);
        _27377 = NOVALUE;
        _27404 = NOVALUE;
        return;
L19: 

        /** inline.e:501					goto "inline op"*/
        goto G18;
        goto LF; // [711] 851

        /** inline.e:503				case EXIT_BLOCK then*/
        case 206:

        /** inline.e:504					replace_code( "", pc, pc + 1 )*/
        _27407 = _pc_53997 + 1;
        if (_27407 > MAXINT){
            _27407 = NewDouble((eudouble)_27407);
        }
        RefDS(_21993);
        _67replace_code(_21993, _pc_53997, _27407);
        _27407 = NOVALUE;

        /** inline.e:505					continue*/
        goto LD; // [732] 347
        goto LF; // [734] 851

        /** inline.e:507				case SWITCH_RT then*/
        case 202:

        /** inline.e:508					sequence values = SymTab[inline_code[pc+2]][S_OBJ]*/
        _27408 = _pc_53997 + 2LL;
        _2 = (object)SEQ_PTR(_67inline_code_53449);
        _27409 = (object)*(((s1_ptr)_2)->base + _27408);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!IS_ATOM_INT(_27409)){
            _27410 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27409)->dbl));
        }
        else{
            _27410 = (object)*(((s1_ptr)_2)->base + _27409);
        }
        DeRef(_values_54118);
        _2 = (object)SEQ_PTR(_27410);
        _values_54118 = (object)*(((s1_ptr)_2)->base + 1LL);
        Ref(_values_54118);
        _27410 = NOVALUE;

        /** inline.e:509					for i = 1 to length( values ) do*/
        if (IS_SEQUENCE(_values_54118)){
                _27412 = SEQ_PTR(_values_54118)->length;
        }
        else {
            _27412 = 1;
        }
        {
            object _i_54126;
            _i_54126 = 1LL;
L1A: 
            if (_i_54126 > _27412){
                goto L1B; // [771] 811
            }

            /** inline.e:510						if sequence( values[i] ) then*/
            _2 = (object)SEQ_PTR(_values_54118);
            _27413 = (object)*(((s1_ptr)_2)->base + _i_54126);
            _27414 = IS_SEQUENCE(_27413);
            _27413 = NOVALUE;
            if (_27414 == 0)
            {
                _27414 = NOVALUE;
                goto L1C; // [787] 804
            }
            else{
                _27414 = NOVALUE;
            }

            /** inline.e:512							defer()*/
            _67defer();

            /** inline.e:513							restore_code()*/
            _67restore_code();

            /** inline.e:514							return*/
            DeRefDS(_values_54118);
            DeRefi(_backpatch_op_54037);
            DeRef(_27394);
            _27394 = NOVALUE;
            DeRef(_27386);
            _27386 = NOVALUE;
            DeRef(_27370);
            _27370 = NOVALUE;
            DeRef(_27356);
            _27356 = NOVALUE;
            _27409 = NOVALUE;
            _27349 = NOVALUE;
            DeRef(_27408);
            _27408 = NOVALUE;
            DeRef(_27353);
            _27353 = NOVALUE;
            DeRef(_27391);
            _27391 = NOVALUE;
            DeRef(_27359);
            _27359 = NOVALUE;
            DeRef(_27390);
            _27390 = NOVALUE;
            DeRef(_27397);
            _27397 = NOVALUE;
            DeRef(_27402);
            _27402 = NOVALUE;
            DeRef(_27377);
            _27377 = NOVALUE;
            DeRef(_27404);
            _27404 = NOVALUE;
            return;
L1C: 

            /** inline.e:516					end for*/
            _i_54126 = _i_54126 + 1LL;
            goto L1A; // [806] 778
L1B: 
            ;
        }

        /** inline.e:517					backpatch_op = append( backpatch_op, pc )*/
        Append(&_backpatch_op_54037, _backpatch_op_54037, _pc_53997);
        DeRef(_values_54118);
        _values_54118 = NOVALUE;

        /** inline.e:520				case else*/
        default:

        /** inline.e:521				label "inline op"*/
G18:

        /** inline.e:522					if not inline_op( pc ) then*/
        _27416 = _67inline_op(_pc_53997);
        if (IS_ATOM_INT(_27416)) {
            if (_27416 != 0){
                DeRef(_27416);
                _27416 = NOVALUE;
                goto L1D; // [833] 850
            }
        }
        else {
            if (DBL_PTR(_27416)->dbl != 0.0){
                DeRef(_27416);
                _27416 = NOVALUE;
                goto L1D; // [833] 850
            }
        }
        DeRef(_27416);
        _27416 = NOVALUE;

        /** inline.e:524						defer()*/
        _67defer();

        /** inline.e:525						restore_code()*/
        _67restore_code();

        /** inline.e:526						return*/
        DeRefi(_backpatch_op_54037);
        DeRef(_27394);
        _27394 = NOVALUE;
        DeRef(_27386);
        _27386 = NOVALUE;
        DeRef(_27370);
        _27370 = NOVALUE;
        DeRef(_27356);
        _27356 = NOVALUE;
        _27409 = NOVALUE;
        _27349 = NOVALUE;
        DeRef(_27408);
        _27408 = NOVALUE;
        DeRef(_27353);
        _27353 = NOVALUE;
        DeRef(_27391);
        _27391 = NOVALUE;
        DeRef(_27359);
        _27359 = NOVALUE;
        DeRef(_27390);
        _27390 = NOVALUE;
        DeRef(_27397);
        _27397 = NOVALUE;
        DeRef(_27402);
        _27402 = NOVALUE;
        DeRef(_27377);
        _27377 = NOVALUE;
        DeRef(_27404);
        _27404 = NOVALUE;
        return;
L1D: 
    ;}LF: 

    /** inline.e:530			pc = advance( pc, inline_code )*/
    RefDS(_67inline_code_53449);
    _pc_53997 = _67advance(_pc_53997, _67inline_code_53449);
    if (!IS_ATOM_INT(_pc_53997)) {
        _1 = (object)(DBL_PTR(_pc_53997)->dbl);
        DeRefDS(_pc_53997);
        _pc_53997 = _1;
    }

    /** inline.e:532		end while*/
    goto LD; // [866] 347
LE: 

    /** inline.e:534		SymTab[sub][S_INLINE] = { sort( assigned_params ), inline_code, backpatch_op }*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sub_53968 + ((s1_ptr)_2)->base);
    RefDS(_67assigned_params_53455);
    _27421 = _24sort(_67assigned_params_53455, 1LL);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _27421;
    RefDS(_67inline_code_53449);
    ((intptr_t*)_2)[2] = _67inline_code_53449;
    RefDS(_backpatch_op_54037);
    ((intptr_t*)_2)[3] = _backpatch_op_54037;
    _27422 = MAKE_SEQ(_1);
    _27421 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 29LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27422;
    if( _1 != _27422 ){
        DeRef(_1);
    }
    _27422 = NOVALUE;
    _27419 = NOVALUE;

    /** inline.e:535		restore_code()*/
    _67restore_code();

    /** inline.e:536	end procedure*/
    DeRefDSi(_backpatch_op_54037);
    DeRef(_27394);
    _27394 = NOVALUE;
    DeRef(_27386);
    _27386 = NOVALUE;
    DeRef(_27370);
    _27370 = NOVALUE;
    DeRef(_27356);
    _27356 = NOVALUE;
    _27409 = NOVALUE;
    _27349 = NOVALUE;
    DeRef(_27408);
    _27408 = NOVALUE;
    DeRef(_27353);
    _27353 = NOVALUE;
    DeRef(_27391);
    _27391 = NOVALUE;
    DeRef(_27359);
    _27359 = NOVALUE;
    DeRef(_27390);
    _27390 = NOVALUE;
    DeRef(_27397);
    _27397 = NOVALUE;
    DeRef(_27402);
    _27402 = NOVALUE;
    DeRef(_27377);
    _27377 = NOVALUE;
    DeRef(_27404);
    _27404 = NOVALUE;
    return;
    ;
}


void _67replace_temp(object _pc_54146)
{
    object _temp_num_54147 = NOVALUE;
    object _needed_54150 = NOVALUE;
    object _27435 = NOVALUE;
    object _27434 = NOVALUE;
    object _27433 = NOVALUE;
    object _27432 = NOVALUE;
    object _27430 = NOVALUE;
    object _27428 = NOVALUE;
    object _27425 = NOVALUE;
    object _27423 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:539		integer temp_num = inline_code[pc][2]*/
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    _27423 = (object)*(((s1_ptr)_2)->base + _pc_54146);
    _2 = (object)SEQ_PTR(_27423);
    _temp_num_54147 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_temp_num_54147)){
        _temp_num_54147 = (object)DBL_PTR(_temp_num_54147)->dbl;
    }
    _27423 = NOVALUE;

    /** inline.e:540		integer needed = temp_num - length( inline_temps )*/
    if (IS_SEQUENCE(_67inline_temps_53451)){
            _27425 = SEQ_PTR(_67inline_temps_53451)->length;
    }
    else {
        _27425 = 1;
    }
    _needed_54150 = _temp_num_54147 - _27425;
    _27425 = NOVALUE;

    /** inline.e:541		if needed > 0 then*/
    if (_needed_54150 <= 0LL)
    goto L1; // [30] 47

    /** inline.e:542			inline_temps &= repeat( 0, needed )*/
    _27428 = Repeat(0LL, _needed_54150);
    Concat((object_ptr)&_67inline_temps_53451, _67inline_temps_53451, _27428);
    DeRefDS(_27428);
    _27428 = NOVALUE;
L1: 

    /** inline.e:545		if not inline_temps[temp_num] then*/
    _2 = (object)SEQ_PTR(_67inline_temps_53451);
    _27430 = (object)*(((s1_ptr)_2)->base + _temp_num_54147);
    if (IS_ATOM_INT(_27430)) {
        if (_27430 != 0){
            _27430 = NOVALUE;
            goto L2; // [55] 100
        }
    }
    else {
        if (DBL_PTR(_27430)->dbl != 0.0){
            _27430 = NOVALUE;
            goto L2; // [55] 100
        }
    }
    _27430 = NOVALUE;

    /** inline.e:546			if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L3; // [62] 84
    }
    else{
    }

    /** inline.e:547				inline_temps[temp_num] = new_inline_var( -temp_num, 0 )*/
    if ((uintptr_t)_temp_num_54147 == (uintptr_t)HIGH_BITS){
        _27432 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _27432 = - _temp_num_54147;
    }
    _27433 = _67new_inline_var(_27432, 0LL);
    _27432 = NOVALUE;
    _2 = (object)SEQ_PTR(_67inline_temps_53451);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_temps_53451 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _temp_num_54147);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27433;
    if( _1 != _27433 ){
        DeRef(_1);
    }
    _27433 = NOVALUE;
    goto L4; // [81] 99
L3: 

    /** inline.e:549				inline_temps[temp_num] = NewTempSym( TRUE )*/
    _27434 = _54NewTempSym(_13TRUE_452);
    _2 = (object)SEQ_PTR(_67inline_temps_53451);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_temps_53451 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _temp_num_54147);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27434;
    if( _1 != _27434 ){
        DeRef(_1);
    }
    _27434 = NOVALUE;
L4: 
L2: 

    /** inline.e:554		inline_code[pc] = inline_temps[temp_num]*/
    _2 = (object)SEQ_PTR(_67inline_temps_53451);
    _27435 = (object)*(((s1_ptr)_2)->base + _temp_num_54147);
    Ref(_27435);
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53449 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _pc_54146);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27435;
    if( _1 != _27435 ){
        DeRef(_1);
    }
    _27435 = NOVALUE;

    /** inline.e:555	end procedure*/
    return;
    ;
}


object _67get_param_sym(object _pc_54172)
{
    object _il_54173 = NOVALUE;
    object _px_54181 = NOVALUE;
    object _27442 = NOVALUE;
    object _27439 = NOVALUE;
    object _27438 = NOVALUE;
    object _27437 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:558		object il = inline_code[pc]*/
    DeRef(_il_54173);
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    _il_54173 = (object)*(((s1_ptr)_2)->base + _pc_54172);
    Ref(_il_54173);

    /** inline.e:559		if integer( il ) then*/
    if (IS_ATOM_INT(_il_54173))
    _27437 = 1;
    else if (IS_ATOM_DBL(_il_54173))
    _27437 = IS_ATOM_INT(DoubleToInt(_il_54173));
    else
    _27437 = 0;
    if (_27437 == 0)
    {
        _27437 = NOVALUE;
        goto L1; // [16] 34
    }
    else{
        _27437 = NOVALUE;
    }

    /** inline.e:560			return inline_code[pc]*/
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    _27438 = (object)*(((s1_ptr)_2)->base + _pc_54172);
    Ref(_27438);
    DeRef(_il_54173);
    return _27438;
    goto L2; // [31] 53
L1: 

    /** inline.e:562		elsif length( il ) = 1 then*/
    if (IS_SEQUENCE(_il_54173)){
            _27439 = SEQ_PTR(_il_54173)->length;
    }
    else {
        _27439 = 1;
    }
    if (_27439 != 1LL)
    goto L3; // [39] 52

    /** inline.e:563			return inline_target*/
    DeRef(_il_54173);
    _27438 = NOVALUE;
    return _67inline_target_53456;
L3: 
L2: 

    /** inline.e:567		integer px = il[2]*/
    _2 = (object)SEQ_PTR(_il_54173);
    _px_54181 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_px_54181)){
        _px_54181 = (object)DBL_PTR(_px_54181)->dbl;
    }

    /** inline.e:568		return passed_params[px]*/
    _2 = (object)SEQ_PTR(_67passed_params_53452);
    _27442 = (object)*(((s1_ptr)_2)->base + _px_54181);
    Ref(_27442);
    DeRef(_il_54173);
    _27438 = NOVALUE;
    return _27442;
    ;
}


object _67get_original_sym(object _pc_54186)
{
    object _il_54187 = NOVALUE;
    object _px_54195 = NOVALUE;
    object _27449 = NOVALUE;
    object _27446 = NOVALUE;
    object _27445 = NOVALUE;
    object _27444 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_54186)) {
        _1 = (object)(DBL_PTR(_pc_54186)->dbl);
        DeRefDS(_pc_54186);
        _pc_54186 = _1;
    }

    /** inline.e:572		object il = inline_code[pc]*/
    DeRef(_il_54187);
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    _il_54187 = (object)*(((s1_ptr)_2)->base + _pc_54186);
    Ref(_il_54187);

    /** inline.e:573		if integer( il ) then*/
    if (IS_ATOM_INT(_il_54187))
    _27444 = 1;
    else if (IS_ATOM_DBL(_il_54187))
    _27444 = IS_ATOM_INT(DoubleToInt(_il_54187));
    else
    _27444 = 0;
    if (_27444 == 0)
    {
        _27444 = NOVALUE;
        goto L1; // [16] 34
    }
    else{
        _27444 = NOVALUE;
    }

    /** inline.e:574			return inline_code[pc]*/
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    _27445 = (object)*(((s1_ptr)_2)->base + _pc_54186);
    Ref(_27445);
    DeRef(_il_54187);
    return _27445;
    goto L2; // [31] 53
L1: 

    /** inline.e:576		elsif length( il ) = 1 then*/
    if (IS_SEQUENCE(_il_54187)){
            _27446 = SEQ_PTR(_il_54187)->length;
    }
    else {
        _27446 = 1;
    }
    if (_27446 != 1LL)
    goto L3; // [39] 52

    /** inline.e:577			return inline_target*/
    DeRef(_il_54187);
    _27445 = NOVALUE;
    return _67inline_target_53456;
L3: 
L2: 

    /** inline.e:581		integer px = il[2]*/
    _2 = (object)SEQ_PTR(_il_54187);
    _px_54195 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_px_54195)){
        _px_54195 = (object)DBL_PTR(_px_54195)->dbl;
    }

    /** inline.e:582		return original_params[px]*/
    _2 = (object)SEQ_PTR(_67original_params_53453);
    _27449 = (object)*(((s1_ptr)_2)->base + _px_54195);
    Ref(_27449);
    DeRef(_il_54187);
    _27445 = NOVALUE;
    return _27449;
    ;
}


void _67replace_var(object _pc_54204)
{
    object _27453 = NOVALUE;
    object _27452 = NOVALUE;
    object _27451 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:590		inline_code[pc] = proc_vars[inline_code[pc][2]]*/
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    _27451 = (object)*(((s1_ptr)_2)->base + _pc_54204);
    _2 = (object)SEQ_PTR(_27451);
    _27452 = (object)*(((s1_ptr)_2)->base + 2LL);
    _27451 = NOVALUE;
    _2 = (object)SEQ_PTR(_67proc_vars_53450);
    if (!IS_ATOM_INT(_27452)){
        _27453 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27452)->dbl));
    }
    else{
        _27453 = (object)*(((s1_ptr)_2)->base + _27452);
    }
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53449 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _pc_54204);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27453;
    if( _1 != _27453 ){
        DeRef(_1);
    }
    _27453 = NOVALUE;

    /** inline.e:591	end procedure*/
    _27452 = NOVALUE;
    return;
    ;
}


void _67fix_switch_rt(object _pc_54210)
{
    object _value_table_54212 = NOVALUE;
    object _jump_table_54219 = NOVALUE;
    object _27473 = NOVALUE;
    object _27472 = NOVALUE;
    object _27471 = NOVALUE;
    object _27470 = NOVALUE;
    object _27469 = NOVALUE;
    object _27468 = NOVALUE;
    object _27466 = NOVALUE;
    object _27465 = NOVALUE;
    object _27464 = NOVALUE;
    object _27463 = NOVALUE;
    object _27462 = NOVALUE;
    object _27460 = NOVALUE;
    object _27458 = NOVALUE;
    object _27457 = NOVALUE;
    object _27455 = NOVALUE;
    object _27454 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** inline.e:594		symtab_index value_table = NewStringSym( {-1, length(SymTab)} )*/
    if (IS_SEQUENCE(_37SymTab_15406)){
            _27454 = SEQ_PTR(_37SymTab_15406)->length;
    }
    else {
        _27454 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1LL;
    ((intptr_t *)_2)[2] = _27454;
    _27455 = MAKE_SEQ(_1);
    _27454 = NOVALUE;
    _value_table_54212 = _54NewStringSym(_27455);
    _27455 = NOVALUE;
    if (!IS_ATOM_INT(_value_table_54212)) {
        _1 = (object)(DBL_PTR(_value_table_54212)->dbl);
        DeRefDS(_value_table_54212);
        _value_table_54212 = _1;
    }

    /** inline.e:595		symtab_index jump_table  = NewStringSym( {-1, length(SymTab)} )*/
    if (IS_SEQUENCE(_37SymTab_15406)){
            _27457 = SEQ_PTR(_37SymTab_15406)->length;
    }
    else {
        _27457 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1LL;
    ((intptr_t *)_2)[2] = _27457;
    _27458 = MAKE_SEQ(_1);
    _27457 = NOVALUE;
    _jump_table_54219 = _54NewStringSym(_27458);
    _27458 = NOVALUE;
    if (!IS_ATOM_INT(_jump_table_54219)) {
        _1 = (object)(DBL_PTR(_jump_table_54219)->dbl);
        DeRefDS(_jump_table_54219);
        _jump_table_54219 = _1;
    }

    /** inline.e:597		SymTab[value_table][S_OBJ] = SymTab[inline_code[pc+2]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_value_table_54212 + ((s1_ptr)_2)->base);
    _27462 = _pc_54210 + 2LL;
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    _27463 = (object)*(((s1_ptr)_2)->base + _27462);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_27463)){
        _27464 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27463)->dbl));
    }
    else{
        _27464 = (object)*(((s1_ptr)_2)->base + _27463);
    }
    _2 = (object)SEQ_PTR(_27464);
    _27465 = (object)*(((s1_ptr)_2)->base + 1LL);
    _27464 = NOVALUE;
    Ref(_27465);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27465;
    if( _1 != _27465 ){
        DeRef(_1);
    }
    _27465 = NOVALUE;
    _27460 = NOVALUE;

    /** inline.e:598		SymTab[jump_table][S_OBJ]  = SymTab[inline_code[pc+3]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_jump_table_54219 + ((s1_ptr)_2)->base);
    _27468 = _pc_54210 + 3LL;
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    _27469 = (object)*(((s1_ptr)_2)->base + _27468);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_27469)){
        _27470 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27469)->dbl));
    }
    else{
        _27470 = (object)*(((s1_ptr)_2)->base + _27469);
    }
    _2 = (object)SEQ_PTR(_27470);
    _27471 = (object)*(((s1_ptr)_2)->base + 1LL);
    _27470 = NOVALUE;
    Ref(_27471);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27471;
    if( _1 != _27471 ){
        DeRef(_1);
    }
    _27471 = NOVALUE;
    _27466 = NOVALUE;

    /** inline.e:600		inline_code[pc+2] = value_table*/
    _27472 = _pc_54210 + 2LL;
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53449 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27472);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _value_table_54212;
    DeRef(_1);

    /** inline.e:601		inline_code[pc+3] = jump_table*/
    _27473 = _pc_54210 + 3LL;
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53449 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27473);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _jump_table_54219;
    DeRef(_1);

    /** inline.e:603	end procedure*/
    _27472 = NOVALUE;
    _27468 = NOVALUE;
    _27462 = NOVALUE;
    _27463 = NOVALUE;
    _27473 = NOVALUE;
    _27469 = NOVALUE;
    return;
    ;
}


void _67fixup_special_op(object _pc_54249)
{
    object _op_54250 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_54249)) {
        _1 = (object)(DBL_PTR(_pc_54249)->dbl);
        DeRefDS(_pc_54249);
        _pc_54249 = _1;
    }

    /** inline.e:606		integer op = inline_code[pc]*/
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    _op_54250 = (object)*(((s1_ptr)_2)->base + _pc_54249);
    if (!IS_ATOM_INT(_op_54250))
    _op_54250 = (object)DBL_PTR(_op_54250)->dbl;

    /** inline.e:607		switch op with fallthru do*/
    _0 = _op_54250;
    switch ( _0 ){ 

        /** inline.e:608			case SWITCH_RT then*/
        case 202:

        /** inline.e:609				fix_switch_rt( pc )*/
        _67fix_switch_rt(_pc_54249);

        /** inline.e:610				break*/
        goto L1; // [29] 32
    ;}L1: 

    /** inline.e:612	end procedure*/
    return;
    ;
}


object _67new_inline_var(object _ps_54261, object _reuse_54262)
{
    object _var_54264 = NOVALUE;
    object _vtype_54265 = NOVALUE;
    object _name_54266 = NOVALUE;
    object _s_54268 = NOVALUE;
    object _27536 = NOVALUE;
    object _27535 = NOVALUE;
    object _27533 = NOVALUE;
    object _27530 = NOVALUE;
    object _27529 = NOVALUE;
    object _27527 = NOVALUE;
    object _27524 = NOVALUE;
    object _27523 = NOVALUE;
    object _27522 = NOVALUE;
    object _27520 = NOVALUE;
    object _27515 = NOVALUE;
    object _27510 = NOVALUE;
    object _27509 = NOVALUE;
    object _27508 = NOVALUE;
    object _27507 = NOVALUE;
    object _27504 = NOVALUE;
    object _27502 = NOVALUE;
    object _27499 = NOVALUE;
    object _27494 = NOVALUE;
    object _27493 = NOVALUE;
    object _27492 = NOVALUE;
    object _27491 = NOVALUE;
    object _27490 = NOVALUE;
    object _27487 = NOVALUE;
    object _27486 = NOVALUE;
    object _27485 = NOVALUE;
    object _27484 = NOVALUE;
    object _27483 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ps_54261)) {
        _1 = (object)(DBL_PTR(_ps_54261)->dbl);
        DeRefDS(_ps_54261);
        _ps_54261 = _1;
    }

    /** inline.e:622			var = 0, */
    _var_54264 = 0LL;

    /** inline.e:624		sequence name*/

    /** inline.e:627		if reuse then*/

    /** inline.e:631		if not var then*/

    /** inline.e:632			if ps > 0 then*/
    if (_ps_54261 <= 0LL)
    goto L1; // [45] 222

    /** inline.e:633				s = ps*/
    _s_54268 = _ps_54261;

    /** inline.e:634				if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L2; // [60] 102
    }
    else{
    }

    /** inline.e:635					name = sprintf( "%s_inlined_%s", {SymTab[s][S_NAME], SymTab[inline_sub][S_NAME] })*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27483 = (object)*(((s1_ptr)_2)->base + _s_54268);
    _2 = (object)SEQ_PTR(_27483);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _27484 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _27484 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _27483 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27485 = (object)*(((s1_ptr)_2)->base + _67inline_sub_53463);
    _2 = (object)SEQ_PTR(_27485);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _27486 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _27486 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _27485 = NOVALUE;
    Ref(_27486);
    Ref(_27484);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _27484;
    ((intptr_t *)_2)[2] = _27486;
    _27487 = MAKE_SEQ(_1);
    _27486 = NOVALUE;
    _27484 = NOVALUE;
    DeRefi(_name_54266);
    _name_54266 = EPrintf(-9999999, _27482, _27487);
    DeRefDS(_27487);
    _27487 = NOVALUE;
    goto L3; // [99] 139
L2: 

    /** inline.e:637					name = sprintf( "%s (from inlined routine '%s'", {SymTab[s][S_NAME], SymTab[inline_sub][S_NAME] })*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27490 = (object)*(((s1_ptr)_2)->base + _s_54268);
    _2 = (object)SEQ_PTR(_27490);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _27491 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _27491 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _27490 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27492 = (object)*(((s1_ptr)_2)->base + _67inline_sub_53463);
    _2 = (object)SEQ_PTR(_27492);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _27493 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _27493 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _27492 = NOVALUE;
    Ref(_27493);
    Ref(_27491);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _27491;
    ((intptr_t *)_2)[2] = _27493;
    _27494 = MAKE_SEQ(_1);
    _27493 = NOVALUE;
    _27491 = NOVALUE;
    DeRefi(_name_54266);
    _name_54266 = EPrintf(-9999999, _27489, _27494);
    DeRefDS(_27494);
    _27494 = NOVALUE;
L3: 

    /** inline.e:640				if reuse then*/
    if (_reuse_54262 == 0)
    {
        goto L4; // [141] 163
    }
    else{
    }

    /** inline.e:641					if not TRANSLATE then*/
    if (_36TRANSLATE_21041 != 0)
    goto L5; // [148] 203

    /** inline.e:642						name &= ")"*/
    Concat((object_ptr)&_name_54266, _name_54266, _26259);
    goto L5; // [160] 203
L4: 

    /** inline.e:645					if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L6; // [167] 187
    }
    else{
    }

    /** inline.e:646						name &= sprintf( "_at_%d", inline_start)*/
    _27499 = EPrintf(-9999999, _27498, _67inline_start_53461);
    Concat((object_ptr)&_name_54266, _name_54266, _27499);
    DeRefDS(_27499);
    _27499 = NOVALUE;
    goto L7; // [184] 202
L6: 

    /** inline.e:648						name &= sprintf( " at %d)", inline_start)*/
    _27502 = EPrintf(-9999999, _27501, _67inline_start_53461);
    Concat((object_ptr)&_name_54266, _name_54266, _27502);
    DeRefDS(_27502);
    _27502 = NOVALUE;
L7: 
L5: 

    /** inline.e:652				vtype = SymTab[s][S_VTYPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27504 = (object)*(((s1_ptr)_2)->base + _s_54268);
    _2 = (object)SEQ_PTR(_27504);
    _vtype_54265 = (object)*(((s1_ptr)_2)->base + 15LL);
    if (!IS_ATOM_INT(_vtype_54265)){
        _vtype_54265 = (object)DBL_PTR(_vtype_54265)->dbl;
    }
    _27504 = NOVALUE;
    goto L8; // [219] 286
L1: 

    /** inline.e:654				name = sprintf( "%s_%d", {SymTab[inline_sub][S_NAME], -ps})*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27507 = (object)*(((s1_ptr)_2)->base + _67inline_sub_53463);
    _2 = (object)SEQ_PTR(_27507);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _27508 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _27508 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _27507 = NOVALUE;
    if ((uintptr_t)_ps_54261 == (uintptr_t)HIGH_BITS){
        _27509 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _27509 = - _ps_54261;
    }
    Ref(_27508);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _27508;
    ((intptr_t *)_2)[2] = _27509;
    _27510 = MAKE_SEQ(_1);
    _27509 = NOVALUE;
    _27508 = NOVALUE;
    DeRefi(_name_54266);
    _name_54266 = EPrintf(-9999999, _27506, _27510);
    DeRefDS(_27510);
    _27510 = NOVALUE;

    /** inline.e:655				if reuse then*/
    if (_reuse_54262 == 0)
    {
        goto L9; // [251] 263
    }
    else{
    }

    /** inline.e:656					name &= "__tmp"*/
    Concat((object_ptr)&_name_54266, _name_54266, _27512);
    goto LA; // [260] 276
L9: 

    /** inline.e:658					name &= sprintf( "__tmp_at%d", inline_start)*/
    _27515 = EPrintf(-9999999, _27514, _67inline_start_53461);
    Concat((object_ptr)&_name_54266, _name_54266, _27515);
    DeRefDS(_27515);
    _27515 = NOVALUE;
LA: 

    /** inline.e:660				vtype = object_type*/
    _vtype_54265 = _54object_type_46776;
L8: 

    /** inline.e:662			if CurrentSub = TopLevelSub then*/
    if (_36CurrentSub_21447 != _36TopLevelSub_21446)
    goto LB; // [292] 325

    /** inline.e:663				var = NewEntry( name, varnum, SC_LOCAL, VARIABLE, INLINE_HASHVAL, 0, vtype )*/
    RefDS(_name_54266);
    _var_54264 = _54NewEntry(_name_54266, _67varnum_53460, 5LL, -100LL, 2004LL, 0LL, _vtype_54265);
    if (!IS_ATOM_INT(_var_54264)) {
        _1 = (object)(DBL_PTR(_var_54264)->dbl);
        DeRefDS(_var_54264);
        _var_54264 = _1;
    }
    goto LC; // [322] 416
LB: 

    /** inline.e:666				var = NewBasicEntry( name, varnum, SC_PRIVATE, VARIABLE, INLINE_HASHVAL, 0, vtype )*/
    RefDS(_name_54266);
    _var_54264 = _54NewBasicEntry(_name_54266, _67varnum_53460, 3LL, -100LL, 2004LL, 0LL, _vtype_54265);
    if (!IS_ATOM_INT(_var_54264)) {
        _1 = (object)(DBL_PTR(_var_54264)->dbl);
        DeRefDS(_var_54264);
        _var_54264 = _1;
    }

    /** inline.e:667				SymTab[var][S_NEXT] = SymTab[last_param][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_var_54264 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27522 = (object)*(((s1_ptr)_2)->base + _67last_param_53464);
    _2 = (object)SEQ_PTR(_27522);
    _27523 = (object)*(((s1_ptr)_2)->base + 2LL);
    _27522 = NOVALUE;
    Ref(_27523);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27523;
    if( _1 != _27523 ){
        DeRef(_1);
    }
    _27523 = NOVALUE;
    _27520 = NOVALUE;

    /** inline.e:668				SymTab[last_param][S_NEXT] = var*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67last_param_53464 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _var_54264;
    DeRef(_1);
    _27524 = NOVALUE;

    /** inline.e:669				if last_param = last_sym then*/
    if (_67last_param_53464 != _54last_sym_46785)
    goto LD; // [403] 415

    /** inline.e:670					last_sym = var*/
    _54last_sym_46785 = _var_54264;
LD: 
LC: 

    /** inline.e:673			if deferred_inlining then*/
    if (_67deferred_inlining_53459 == 0)
    {
        goto LE; // [420] 451
    }
    else{
    }

    /** inline.e:674				SymTab[CurrentSub][S_STACK_SPACE] += 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21447 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21136)){
        _27529 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21136)->dbl));
    }
    else{
        _27529 = (object)*(((s1_ptr)_2)->base + _36S_STACK_SPACE_21136);
    }
    _27527 = NOVALUE;
    if (IS_ATOM_INT(_27529)) {
        _27530 = _27529 + 1;
        if (_27530 > MAXINT){
            _27530 = NewDouble((eudouble)_27530);
        }
    }
    else
    _27530 = binary_op(PLUS, 1, _27529);
    _27529 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21136))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21136)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_STACK_SPACE_21136);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27530;
    if( _1 != _27530 ){
        DeRef(_1);
    }
    _27530 = NOVALUE;
    _27527 = NOVALUE;
    goto LF; // [448] 471
LE: 

    /** inline.e:676				if param_num != -1 then*/
    if (_45param_num_54933 == -1LL)
    goto L10; // [455] 470

    /** inline.e:677					param_num += 1*/
    _45param_num_54933 = _45param_num_54933 + 1LL;
L10: 
LF: 

    /** inline.e:680			SymTab[var][S_USAGE] = U_USED*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_var_54264 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3LL;
    DeRef(_1);
    _27533 = NOVALUE;

    /** inline.e:681			if reuse then*/
    if (_reuse_54262 == 0)
    {
        goto L11; // [490] 511
    }
    else{
    }

    /** inline.e:682				map:nested_put( inline_var_map, {CurrentSub, ps }, var )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _36CurrentSub_21447;
    ((intptr_t *)_2)[2] = _ps_54261;
    _27535 = MAKE_SEQ(_1);
    Ref(_67inline_var_map_53468);
    _29nested_put(_67inline_var_map_53468, _27535, _var_54264, 1LL, 0LL);
    _27535 = NOVALUE;
L11: 

    /** inline.e:686		Block_var( var )*/
    _65Block_var(_var_54264);

    /** inline.e:687		if BIND then*/
    if (_36BIND_21044 == 0)
    {
        goto L12; // [521] 536
    }
    else{
    }

    /** inline.e:688			add_ref( {VARIABLE, var} )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100LL;
    ((intptr_t *)_2)[2] = _var_54264;
    _27536 = MAKE_SEQ(_1);
    _54add_ref(_27536);
    _27536 = NOVALUE;
L12: 

    /** inline.e:690		return var*/
    DeRefi(_name_54266);
    return _var_54264;
    ;
}


object _67get_inlined_code(object _sub_54398, object _start_54399, object _deferred_54400)
{
    object _is_proc_54401 = NOVALUE;
    object _backpatches_54419 = NOVALUE;
    object _prolog_54425 = NOVALUE;
    object _epilog_54426 = NOVALUE;
    object _s_54442 = NOVALUE;
    object _last_sym_54465 = NOVALUE;
    object _int_sym_54492 = NOVALUE;
    object _param_54500 = NOVALUE;
    object _ax_54503 = NOVALUE;
    object _var_54510 = NOVALUE;
    object _final_target_54525 = NOVALUE;
    object _var_54544 = NOVALUE;
    object _create_target_var_54557 = NOVALUE;
    object _check_pc_54580 = NOVALUE;
    object _op_54584 = NOVALUE;
    object _sym_54593 = NOVALUE;
    object _check_result_54598 = NOVALUE;
    object _inline_type_54676 = NOVALUE;
    object _replace_param_1__tmp_at1343_54687 = NOVALUE;
    object _27690 = NOVALUE;
    object _27689 = NOVALUE;
    object _27688 = NOVALUE;
    object _27687 = NOVALUE;
    object _27686 = NOVALUE;
    object _27685 = NOVALUE;
    object _27684 = NOVALUE;
    object _27683 = NOVALUE;
    object _27681 = NOVALUE;
    object _27678 = NOVALUE;
    object _27675 = NOVALUE;
    object _27674 = NOVALUE;
    object _27673 = NOVALUE;
    object _27672 = NOVALUE;
    object _27671 = NOVALUE;
    object _27670 = NOVALUE;
    object _27669 = NOVALUE;
    object _27668 = NOVALUE;
    object _27664 = NOVALUE;
    object _27663 = NOVALUE;
    object _27662 = NOVALUE;
    object _27661 = NOVALUE;
    object _27657 = NOVALUE;
    object _27656 = NOVALUE;
    object _27655 = NOVALUE;
    object _27654 = NOVALUE;
    object _27653 = NOVALUE;
    object _27652 = NOVALUE;
    object _27651 = NOVALUE;
    object _27649 = NOVALUE;
    object _27648 = NOVALUE;
    object _27647 = NOVALUE;
    object _27646 = NOVALUE;
    object _27645 = NOVALUE;
    object _27644 = NOVALUE;
    object _27643 = NOVALUE;
    object _27642 = NOVALUE;
    object _27641 = NOVALUE;
    object _27640 = NOVALUE;
    object _27639 = NOVALUE;
    object _27637 = NOVALUE;
    object _27636 = NOVALUE;
    object _27634 = NOVALUE;
    object _27633 = NOVALUE;
    object _27631 = NOVALUE;
    object _27630 = NOVALUE;
    object _27627 = NOVALUE;
    object _27626 = NOVALUE;
    object _27624 = NOVALUE;
    object _27622 = NOVALUE;
    object _27617 = NOVALUE;
    object _27613 = NOVALUE;
    object _27610 = NOVALUE;
    object _27606 = NOVALUE;
    object _27599 = NOVALUE;
    object _27598 = NOVALUE;
    object _27597 = NOVALUE;
    object _27596 = NOVALUE;
    object _27595 = NOVALUE;
    object _27594 = NOVALUE;
    object _27593 = NOVALUE;
    object _27591 = NOVALUE;
    object _27586 = NOVALUE;
    object _27583 = NOVALUE;
    object _27578 = NOVALUE;
    object _27577 = NOVALUE;
    object _27575 = NOVALUE;
    object _27574 = NOVALUE;
    object _27573 = NOVALUE;
    object _27570 = NOVALUE;
    object _27569 = NOVALUE;
    object _27568 = NOVALUE;
    object _27567 = NOVALUE;
    object _27566 = NOVALUE;
    object _27565 = NOVALUE;
    object _27564 = NOVALUE;
    object _27562 = NOVALUE;
    object _27561 = NOVALUE;
    object _27560 = NOVALUE;
    object _27558 = NOVALUE;
    object _27556 = NOVALUE;
    object _27555 = NOVALUE;
    object _27554 = NOVALUE;
    object _27553 = NOVALUE;
    object _27552 = NOVALUE;
    object _27551 = NOVALUE;
    object _27550 = NOVALUE;
    object _27547 = NOVALUE;
    object _27546 = NOVALUE;
    object _27544 = NOVALUE;
    object _27543 = NOVALUE;
    object _27541 = NOVALUE;
    object _27540 = NOVALUE;
    object _27538 = NOVALUE;
    object _27537 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_start_54399)) {
        _1 = (object)(DBL_PTR(_start_54399)->dbl);
        DeRefDS(_start_54399);
        _start_54399 = _1;
    }

    /** inline.e:694		integer is_proc = SymTab[sub][S_TOKEN] = PROC*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27537 = (object)*(((s1_ptr)_2)->base + _sub_54398);
    _2 = (object)SEQ_PTR(_27537);
    if (!IS_ATOM_INT(_36S_TOKEN_21081)){
        _27538 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    }
    else{
        _27538 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    }
    _27537 = NOVALUE;
    if (IS_ATOM_INT(_27538)) {
        _is_proc_54401 = (_27538 == 27LL);
    }
    else {
        _is_proc_54401 = binary_op(EQUALS, _27538, 27LL);
    }
    _27538 = NOVALUE;
    if (!IS_ATOM_INT(_is_proc_54401)) {
        _1 = (object)(DBL_PTR(_is_proc_54401)->dbl);
        DeRefDS(_is_proc_54401);
        _is_proc_54401 = _1;
    }

    /** inline.e:695		clear_inline_targets()*/
    _47clear_inline_targets();

    /** inline.e:697		inline_temps = {}*/
    RefDS(_21993);
    DeRef(_67inline_temps_53451);
    _67inline_temps_53451 = _21993;

    /** inline.e:698		inline_params = {}*/
    RefDS(_21993);
    DeRefi(_67inline_params_53454);
    _67inline_params_53454 = _21993;

    /** inline.e:699		assigned_params      = SymTab[sub][S_INLINE][1]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27540 = (object)*(((s1_ptr)_2)->base + _sub_54398);
    _2 = (object)SEQ_PTR(_27540);
    _27541 = (object)*(((s1_ptr)_2)->base + 29LL);
    _27540 = NOVALUE;
    DeRef(_67assigned_params_53455);
    _2 = (object)SEQ_PTR(_27541);
    _67assigned_params_53455 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_67assigned_params_53455);
    _27541 = NOVALUE;

    /** inline.e:700		inline_code          = SymTab[sub][S_INLINE][2]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27543 = (object)*(((s1_ptr)_2)->base + _sub_54398);
    _2 = (object)SEQ_PTR(_27543);
    _27544 = (object)*(((s1_ptr)_2)->base + 29LL);
    _27543 = NOVALUE;
    DeRef(_67inline_code_53449);
    _2 = (object)SEQ_PTR(_27544);
    _67inline_code_53449 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_67inline_code_53449);
    _27544 = NOVALUE;

    /** inline.e:701		sequence backpatches = SymTab[sub][S_INLINE][3]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27546 = (object)*(((s1_ptr)_2)->base + _sub_54398);
    _2 = (object)SEQ_PTR(_27546);
    _27547 = (object)*(((s1_ptr)_2)->base + 29LL);
    _27546 = NOVALUE;
    DeRef(_backpatches_54419);
    _2 = (object)SEQ_PTR(_27547);
    _backpatches_54419 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_backpatches_54419);
    _27547 = NOVALUE;

    /** inline.e:703		passed_params = {}*/
    RefDS(_21993);
    DeRef(_67passed_params_53452);
    _67passed_params_53452 = _21993;

    /** inline.e:704		original_params = {}*/
    RefDS(_21993);
    DeRef(_67original_params_53453);
    _67original_params_53453 = _21993;

    /** inline.e:705		proc_vars = {}*/
    RefDS(_21993);
    DeRefi(_67proc_vars_53450);
    _67proc_vars_53450 = _21993;

    /** inline.e:706		sequence prolog = {}*/
    RefDS(_21993);
    DeRefi(_prolog_54425);
    _prolog_54425 = _21993;

    /** inline.e:707		sequence epilog = {}*/
    RefDS(_21993);
    DeRef(_epilog_54426);
    _epilog_54426 = _21993;

    /** inline.e:709		Start_block( EXIT_BLOCK, sprintf("Inline-%s from %s @ %d", */
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27550 = (object)*(((s1_ptr)_2)->base + _sub_54398);
    _2 = (object)SEQ_PTR(_27550);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _27551 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _27551 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _27550 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27552 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21447);
    _2 = (object)SEQ_PTR(_27552);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _27553 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _27553 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _27552 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_27551);
    ((intptr_t*)_2)[1] = _27551;
    Ref(_27553);
    ((intptr_t*)_2)[2] = _27553;
    ((intptr_t*)_2)[3] = _start_54399;
    _27554 = MAKE_SEQ(_1);
    _27553 = NOVALUE;
    _27551 = NOVALUE;
    _27555 = EPrintf(-9999999, _27549, _27554);
    DeRefDS(_27554);
    _27554 = NOVALUE;
    _65Start_block(206LL, _27555);
    _27555 = NOVALUE;

    /** inline.e:712		symtab_index s = SymTab[sub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27556 = (object)*(((s1_ptr)_2)->base + _sub_54398);
    _2 = (object)SEQ_PTR(_27556);
    _s_54442 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_54442)){
        _s_54442 = (object)DBL_PTR(_s_54442)->dbl;
    }
    _27556 = NOVALUE;

    /** inline.e:714		varnum = SymTab[CurrentSub][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27558 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21447);
    _2 = (object)SEQ_PTR(_27558);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
        _67varnum_53460 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
    }
    else{
        _67varnum_53460 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
    }
    if (!IS_ATOM_INT(_67varnum_53460)){
        _67varnum_53460 = (object)DBL_PTR(_67varnum_53460)->dbl;
    }
    _27558 = NOVALUE;

    /** inline.e:715		inline_start = start*/
    _67inline_start_53461 = _start_54399;

    /** inline.e:717		last_param = CurrentSub*/
    _67last_param_53464 = _36CurrentSub_21447;

    /** inline.e:718		for p = 1 to SymTab[CurrentSub][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27560 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21447);
    _2 = (object)SEQ_PTR(_27560);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
        _27561 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
    }
    else{
        _27561 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
    }
    _27560 = NOVALUE;
    {
        object _p_54454;
        _p_54454 = 1LL;
L1: 
        if (binary_op_a(GREATER, _p_54454, _27561)){
            goto L2; // [250] 282
        }

        /** inline.e:719			last_param = SymTab[last_param][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27562 = (object)*(((s1_ptr)_2)->base + _67last_param_53464);
        _2 = (object)SEQ_PTR(_27562);
        _67last_param_53464 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_67last_param_53464)){
            _67last_param_53464 = (object)DBL_PTR(_67last_param_53464)->dbl;
        }
        _27562 = NOVALUE;

        /** inline.e:720		end for*/
        _0 = _p_54454;
        if (IS_ATOM_INT(_p_54454)) {
            _p_54454 = _p_54454 + 1LL;
            if ((object)((uintptr_t)_p_54454 +(uintptr_t) HIGH_BITS) >= 0){
                _p_54454 = NewDouble((eudouble)_p_54454);
            }
        }
        else {
            _p_54454 = binary_op_a(PLUS, _p_54454, 1LL);
        }
        DeRef(_0);
        goto L1; // [277] 257
L2: 
        ;
        DeRef(_p_54454);
    }

    /** inline.e:722		symtab_index last_sym = last_param*/
    _last_sym_54465 = _67last_param_53464;

    /** inline.e:723		while last_sym and */
L3: 
    if (_last_sym_54465 == 0) {
        goto L4; // [296] 368
    }
    _27565 = _54sym_scope(_last_sym_54465);
    if (IS_ATOM_INT(_27565)) {
        _27566 = (_27565 <= 3LL);
    }
    else {
        _27566 = binary_op(LESSEQ, _27565, 3LL);
    }
    DeRef(_27565);
    _27565 = NOVALUE;
    if (IS_ATOM_INT(_27566)) {
        if (_27566 != 0) {
            DeRef(_27567);
            _27567 = 1;
            goto L5; // [310] 328
        }
    }
    else {
        if (DBL_PTR(_27566)->dbl != 0.0) {
            DeRef(_27567);
            _27567 = 1;
            goto L5; // [310] 328
        }
    }
    _27568 = _54sym_scope(_last_sym_54465);
    if (IS_ATOM_INT(_27568)) {
        _27569 = (_27568 == 9LL);
    }
    else {
        _27569 = binary_op(EQUALS, _27568, 9LL);
    }
    DeRef(_27568);
    _27568 = NOVALUE;
    DeRef(_27567);
    if (IS_ATOM_INT(_27569))
    _27567 = (_27569 != 0);
    else
    _27567 = DBL_PTR(_27569)->dbl != 0.0;
L5: 
    if (_27567 == 0)
    {
        _27567 = NOVALUE;
        goto L4; // [329] 368
    }
    else{
        _27567 = NOVALUE;
    }

    /** inline.e:725			last_param = last_sym*/
    _67last_param_53464 = _last_sym_54465;

    /** inline.e:726			last_sym = SymTab[last_sym][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27570 = (object)*(((s1_ptr)_2)->base + _last_sym_54465);
    _2 = (object)SEQ_PTR(_27570);
    _last_sym_54465 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_last_sym_54465)){
        _last_sym_54465 = (object)DBL_PTR(_last_sym_54465)->dbl;
    }
    _27570 = NOVALUE;

    /** inline.e:727			varnum += 1*/
    _67varnum_53460 = _67varnum_53460 + 1;

    /** inline.e:728		end while*/
    goto L3; // [365] 296
L4: 

    /** inline.e:729		for p = SymTab[sub][S_NUM_ARGS] to 1 by -1 do*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27573 = (object)*(((s1_ptr)_2)->base + _sub_54398);
    _2 = (object)SEQ_PTR(_27573);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
        _27574 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
    }
    else{
        _27574 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
    }
    _27573 = NOVALUE;
    {
        object _p_54483;
        Ref(_27574);
        _p_54483 = _27574;
L6: 
        if (binary_op_a(LESS, _p_54483, 1LL)){
            goto L7; // [382] 407
        }

        /** inline.e:730			passed_params = prepend( passed_params, Pop() )*/
        _27575 = _47Pop();
        Ref(_27575);
        Prepend(&_67passed_params_53452, _67passed_params_53452, _27575);
        DeRef(_27575);
        _27575 = NOVALUE;

        /** inline.e:731		end for*/
        _0 = _p_54483;
        if (IS_ATOM_INT(_p_54483)) {
            _p_54483 = _p_54483 + -1LL;
            if ((object)((uintptr_t)_p_54483 +(uintptr_t) HIGH_BITS) >= 0){
                _p_54483 = NewDouble((eudouble)_p_54483);
            }
        }
        else {
            _p_54483 = binary_op_a(PLUS, _p_54483, -1LL);
        }
        DeRef(_0);
        goto L6; // [402] 389
L7: 
        ;
        DeRef(_p_54483);
    }

    /** inline.e:733		original_params = passed_params*/
    RefDS(_67passed_params_53452);
    DeRef(_67original_params_53453);
    _67original_params_53453 = _67passed_params_53452;

    /** inline.e:735		symtab_index int_sym = 0*/
    _int_sym_54492 = 0LL;

    /** inline.e:736		for p = 1 to SymTab[sub][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27577 = (object)*(((s1_ptr)_2)->base + _sub_54398);
    _2 = (object)SEQ_PTR(_27577);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
        _27578 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
    }
    else{
        _27578 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
    }
    _27577 = NOVALUE;
    {
        object _p_54494;
        _p_54494 = 1LL;
L8: 
        if (binary_op_a(GREATER, _p_54494, _27578)){
            goto L9; // [437] 575
        }

        /** inline.e:737			symtab_index param = passed_params[p]*/
        _2 = (object)SEQ_PTR(_67passed_params_53452);
        if (!IS_ATOM_INT(_p_54494)){
            _param_54500 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_p_54494)->dbl));
        }
        else{
            _param_54500 = (object)*(((s1_ptr)_2)->base + _p_54494);
        }
        if (!IS_ATOM_INT(_param_54500)){
            _param_54500 = (object)DBL_PTR(_param_54500)->dbl;
        }

        /** inline.e:738			inline_params &= s*/
        Append(&_67inline_params_53454, _67inline_params_53454, _s_54442);

        /** inline.e:739			integer ax = find( p, assigned_params )*/
        _ax_54503 = find_from(_p_54494, _67assigned_params_53455, 1LL);

        /** inline.e:740			if ax or is_temp( param ) then*/
        if (_ax_54503 != 0) {
            goto LA; // [473] 486
        }
        _27583 = _67is_temp(_param_54500);
        if (_27583 == 0) {
            DeRef(_27583);
            _27583 = NOVALUE;
            goto LB; // [482] 548
        }
        else {
            if (!IS_ATOM_INT(_27583) && DBL_PTR(_27583)->dbl == 0.0){
                DeRef(_27583);
                _27583 = NOVALUE;
                goto LB; // [482] 548
            }
            DeRef(_27583);
            _27583 = NOVALUE;
        }
        DeRef(_27583);
        _27583 = NOVALUE;
LA: 

        /** inline.e:743				varnum += 1*/
        _67varnum_53460 = _67varnum_53460 + 1;

        /** inline.e:744				symtab_index var = new_inline_var( s, 0 )*/
        _var_54510 = _67new_inline_var(_s_54442, 0LL);
        if (!IS_ATOM_INT(_var_54510)) {
            _1 = (object)(DBL_PTR(_var_54510)->dbl);
            DeRefDS(_var_54510);
            _var_54510 = _1;
        }

        /** inline.e:745				prolog &= {ASSIGN, param, var}*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = 18LL;
        ((intptr_t*)_2)[2] = _param_54500;
        ((intptr_t*)_2)[3] = _var_54510;
        _27586 = MAKE_SEQ(_1);
        Concat((object_ptr)&_prolog_54425, _prolog_54425, _27586);
        DeRefDS(_27586);
        _27586 = NOVALUE;

        /** inline.e:746				if not int_sym then*/
        if (_int_sym_54492 != 0)
        goto LC; // [519] 531

        /** inline.e:747					int_sym = NewIntSym( 0 )*/
        _int_sym_54492 = _54NewIntSym(0LL);
        if (!IS_ATOM_INT(_int_sym_54492)) {
            _1 = (object)(DBL_PTR(_int_sym_54492)->dbl);
            DeRefDS(_int_sym_54492);
            _int_sym_54492 = _1;
        }
LC: 

        /** inline.e:750				inline_start += 3*/
        _67inline_start_53461 = _67inline_start_53461 + 3LL;

        /** inline.e:751				passed_params[p] = var*/
        _2 = (object)SEQ_PTR(_67passed_params_53452);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67passed_params_53452 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_p_54494))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_p_54494)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _p_54494);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _var_54510;
        DeRef(_1);
LB: 

        /** inline.e:753			s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27591 = (object)*(((s1_ptr)_2)->base + _s_54442);
        _2 = (object)SEQ_PTR(_27591);
        _s_54442 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_s_54442)){
            _s_54442 = (object)DBL_PTR(_s_54442)->dbl;
        }
        _27591 = NOVALUE;

        /** inline.e:755		end for*/
        _0 = _p_54494;
        if (IS_ATOM_INT(_p_54494)) {
            _p_54494 = _p_54494 + 1LL;
            if ((object)((uintptr_t)_p_54494 +(uintptr_t) HIGH_BITS) >= 0){
                _p_54494 = NewDouble((eudouble)_p_54494);
            }
        }
        else {
            _p_54494 = binary_op_a(PLUS, _p_54494, 1LL);
        }
        DeRef(_0);
        goto L8; // [570] 444
L9: 
        ;
        DeRef(_p_54494);
    }

    /** inline.e:757		symtab_index final_target = 0*/
    _final_target_54525 = 0LL;

    /** inline.e:758		while s and */
LD: 
    if (_s_54442 == 0) {
        goto LE; // [587] 699
    }
    _27594 = _54sym_scope(_s_54442);
    if (IS_ATOM_INT(_27594)) {
        _27595 = (_27594 <= 3LL);
    }
    else {
        _27595 = binary_op(LESSEQ, _27594, 3LL);
    }
    DeRef(_27594);
    _27594 = NOVALUE;
    if (IS_ATOM_INT(_27595)) {
        if (_27595 != 0) {
            DeRef(_27596);
            _27596 = 1;
            goto LF; // [601] 619
        }
    }
    else {
        if (DBL_PTR(_27595)->dbl != 0.0) {
            DeRef(_27596);
            _27596 = 1;
            goto LF; // [601] 619
        }
    }
    _27597 = _54sym_scope(_s_54442);
    if (IS_ATOM_INT(_27597)) {
        _27598 = (_27597 == 9LL);
    }
    else {
        _27598 = binary_op(EQUALS, _27597, 9LL);
    }
    DeRef(_27597);
    _27597 = NOVALUE;
    DeRef(_27596);
    if (IS_ATOM_INT(_27598))
    _27596 = (_27598 != 0);
    else
    _27596 = DBL_PTR(_27598)->dbl != 0.0;
LF: 
    if (_27596 == 0)
    {
        _27596 = NOVALUE;
        goto LE; // [620] 699
    }
    else{
        _27596 = NOVALUE;
    }

    /** inline.e:760			if sym_scope( s ) != SC_UNDEFINED then*/
    _27599 = _54sym_scope(_s_54442);
    if (binary_op_a(EQUALS, _27599, 9LL)){
        DeRef(_27599);
        _27599 = NOVALUE;
        goto L10; // [631] 676
    }
    DeRef(_27599);
    _27599 = NOVALUE;

    /** inline.e:763				varnum += 1*/
    _67varnum_53460 = _67varnum_53460 + 1;

    /** inline.e:764				symtab_index var = new_inline_var( s, 0 )*/
    _var_54544 = _67new_inline_var(_s_54442, 0LL);
    if (!IS_ATOM_INT(_var_54544)) {
        _1 = (object)(DBL_PTR(_var_54544)->dbl);
        DeRefDS(_var_54544);
        _var_54544 = _1;
    }

    /** inline.e:765				proc_vars &= var*/
    Append(&_67proc_vars_53450, _67proc_vars_53450, _var_54544);

    /** inline.e:766				if int_sym = 0 then*/
    if (_int_sym_54492 != 0LL)
    goto L11; // [662] 675

    /** inline.e:767					int_sym = NewIntSym( 0 )*/
    _int_sym_54492 = _54NewIntSym(0LL);
    if (!IS_ATOM_INT(_int_sym_54492)) {
        _1 = (object)(DBL_PTR(_int_sym_54492)->dbl);
        DeRefDS(_int_sym_54492);
        _int_sym_54492 = _1;
    }
L11: 
L10: 

    /** inline.e:770			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27606 = (object)*(((s1_ptr)_2)->base + _s_54442);
    _2 = (object)SEQ_PTR(_27606);
    _s_54442 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_54442)){
        _s_54442 = (object)DBL_PTR(_s_54442)->dbl;
    }
    _27606 = NOVALUE;

    /** inline.e:771		end while*/
    goto LD; // [696] 587
LE: 

    /** inline.e:773		if not is_proc then*/
    if (_is_proc_54401 != 0)
    goto L12; // [701] 831

    /** inline.e:774			integer create_target_var = 1*/
    _create_target_var_54557 = 1LL;

    /** inline.e:775			if deferred then*/
    if (_deferred_54400 == 0)
    {
        goto L13; // [711] 751
    }
    else{
    }

    /** inline.e:776				inline_target = Pop()*/
    _0 = _47Pop();
    _67inline_target_53456 = _0;
    if (!IS_ATOM_INT(_67inline_target_53456)) {
        _1 = (object)(DBL_PTR(_67inline_target_53456)->dbl);
        DeRefDS(_67inline_target_53456);
        _67inline_target_53456 = _1;
    }

    /** inline.e:777				if is_temp( inline_target ) then*/
    _27610 = _67is_temp(_67inline_target_53456);
    if (_27610 == 0) {
        DeRef(_27610);
        _27610 = NOVALUE;
        goto L14; // [729] 744
    }
    else {
        if (!IS_ATOM_INT(_27610) && DBL_PTR(_27610)->dbl == 0.0){
            DeRef(_27610);
            _27610 = NOVALUE;
            goto L14; // [729] 744
        }
        DeRef(_27610);
        _27610 = NOVALUE;
    }
    DeRef(_27610);
    _27610 = NOVALUE;

    /** inline.e:778					final_target = inline_target*/
    _final_target_54525 = _67inline_target_53456;
    goto L15; // [741] 750
L14: 

    /** inline.e:780					create_target_var = 0*/
    _create_target_var_54557 = 0LL;
L15: 
L13: 

    /** inline.e:784			if create_target_var then*/
    if (_create_target_var_54557 == 0)
    {
        goto L16; // [753] 816
    }
    else{
    }

    /** inline.e:785				varnum += 1*/
    _67varnum_53460 = _67varnum_53460 + 1;

    /** inline.e:786				if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L17; // [768] 806
    }
    else{
    }

    /** inline.e:787					inline_target = new_inline_var( sub, 0 )*/
    _0 = _67new_inline_var(_sub_54398, 0LL);
    _67inline_target_53456 = _0;
    if (!IS_ATOM_INT(_67inline_target_53456)) {
        _1 = (object)(DBL_PTR(_67inline_target_53456)->dbl);
        DeRefDS(_67inline_target_53456);
        _67inline_target_53456 = _1;
    }

    /** inline.e:788					SymTab[inline_target][S_VTYPE] = object_type*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67inline_target_53456 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _54object_type_46776;
    DeRef(_1);
    _27613 = NOVALUE;

    /** inline.e:789					Pop_block_var()*/
    _65Pop_block_var();
    goto L18; // [803] 815
L17: 

    /** inline.e:791					inline_target = NewTempSym()*/
    _0 = _54NewTempSym(0LL);
    _67inline_target_53456 = _0;
    if (!IS_ATOM_INT(_67inline_target_53456)) {
        _1 = (object)(DBL_PTR(_67inline_target_53456)->dbl);
        DeRefDS(_67inline_target_53456);
        _67inline_target_53456 = _1;
    }
L18: 
L16: 

    /** inline.e:794			proc_vars &= inline_target*/
    Append(&_67proc_vars_53450, _67proc_vars_53450, _67inline_target_53456);
    goto L19; // [828] 837
L12: 

    /** inline.e:796			inline_target = 0*/
    _67inline_target_53456 = 0LL;
L19: 

    /** inline.e:800		integer check_pc = 1*/
    _check_pc_54580 = 1LL;

    /** inline.e:802		while length(inline_code) > check_pc do*/
L1A: 
    if (IS_SEQUENCE(_67inline_code_53449)){
            _27617 = SEQ_PTR(_67inline_code_53449)->length;
    }
    else {
        _27617 = 1;
    }
    if (_27617 <= _check_pc_54580)
    goto L1B; // [852] 1218

    /** inline.e:803			integer op = inline_code[check_pc]*/
    _2 = (object)SEQ_PTR(_67inline_code_53449);
    _op_54584 = (object)*(((s1_ptr)_2)->base + _check_pc_54580);
    if (!IS_ATOM_INT(_op_54584))
    _op_54584 = (object)DBL_PTR(_op_54584)->dbl;

    /** inline.e:805			switch op with fallthru do*/
    _0 = _op_54584;
    switch ( _0 ){ 

        /** inline.e:806				case ATOM_CHECK then*/
        case 101:
        case 97:
        case 96:

        /** inline.e:809					symtab_index sym = get_original_sym( check_pc + 1 )*/
        _27622 = _check_pc_54580 + 1;
        if (_27622 > MAXINT){
            _27622 = NewDouble((eudouble)_27622);
        }
        _sym_54593 = _67get_original_sym(_27622);
        _27622 = NOVALUE;
        if (!IS_ATOM_INT(_sym_54593)) {
            _1 = (object)(DBL_PTR(_sym_54593)->dbl);
            DeRefDS(_sym_54593);
            _sym_54593 = _1;
        }

        /** inline.e:810					if is_literal( sym ) then*/
        _27624 = _67is_literal(_sym_54593);
        if (_27624 == 0) {
            DeRef(_27624);
            _27624 = NOVALUE;
            goto L1C; // [897] 1012
        }
        else {
            if (!IS_ATOM_INT(_27624) && DBL_PTR(_27624)->dbl == 0.0){
                DeRef(_27624);
                _27624 = NOVALUE;
                goto L1C; // [897] 1012
            }
            DeRef(_27624);
            _27624 = NOVALUE;
        }
        DeRef(_27624);
        _27624 = NOVALUE;

        /** inline.e:811						integer check_result*/

        /** inline.e:813						if op = INTEGER_CHECK then*/
        if (_op_54584 != 96LL)
        goto L1D; // [906] 930

        /** inline.e:814							check_result = integer( SymTab[sym][S_OBJ] )*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27626 = (object)*(((s1_ptr)_2)->base + _sym_54593);
        _2 = (object)SEQ_PTR(_27626);
        _27627 = (object)*(((s1_ptr)_2)->base + 1LL);
        _27626 = NOVALUE;
        if (IS_ATOM_INT(_27627))
        _check_result_54598 = 1;
        else if (IS_ATOM_DBL(_27627))
        _check_result_54598 = IS_ATOM_INT(DoubleToInt(_27627));
        else
        _check_result_54598 = 0;
        _27627 = NOVALUE;
        goto L1E; // [927] 976
L1D: 

        /** inline.e:815						elsif op = SEQUENCE_CHECK then*/
        if (_op_54584 != 97LL)
        goto L1F; // [934] 958

        /** inline.e:816							check_result = sequence( SymTab[sym][S_OBJ] )*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27630 = (object)*(((s1_ptr)_2)->base + _sym_54593);
        _2 = (object)SEQ_PTR(_27630);
        _27631 = (object)*(((s1_ptr)_2)->base + 1LL);
        _27630 = NOVALUE;
        _check_result_54598 = IS_SEQUENCE(_27631);
        _27631 = NOVALUE;
        goto L1E; // [955] 976
L1F: 

        /** inline.e:818							check_result = atom( SymTab[sym][S_OBJ] )*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27633 = (object)*(((s1_ptr)_2)->base + _sym_54593);
        _2 = (object)SEQ_PTR(_27633);
        _27634 = (object)*(((s1_ptr)_2)->base + 1LL);
        _27633 = NOVALUE;
        _check_result_54598 = IS_ATOM(_27634);
        _27634 = NOVALUE;
L1E: 

        /** inline.e:821						if check_result then*/
        if (_check_result_54598 == 0)
        {
            goto L20; // [980] 997
        }
        else{
        }

        /** inline.e:822							replace_code( {}, check_pc, check_pc+1 )*/
        _27636 = _check_pc_54580 + 1;
        if (_27636 > MAXINT){
            _27636 = NewDouble((eudouble)_27636);
        }
        RefDS(_21993);
        _67replace_code(_21993, _check_pc_54580, _27636);
        _27636 = NOVALUE;
        goto L21; // [994] 1007
L20: 

        /** inline.e:826							CompileErr(TYPE_CHECK_ERROR_WHEN_INLINING_LITERAL)*/
        RefDS(_21993);
        _50CompileErr(146LL, _21993, 0LL);
L21: 
        goto L22; // [1009] 1174
L1C: 

        /** inline.e:829					elsif not is_temp( sym ) then*/
        _27637 = _67is_temp(_sym_54593);
        if (IS_ATOM_INT(_27637)) {
            if (_27637 != 0){
                DeRef(_27637);
                _27637 = NOVALUE;
                goto L23; // [1018] 1167
            }
        }
        else {
            if (DBL_PTR(_27637)->dbl != 0.0){
                DeRef(_27637);
                _27637 = NOVALUE;
                goto L23; // [1018] 1167
            }
        }
        DeRef(_27637);
        _27637 = NOVALUE;

        /** inline.e:831						if (op = INTEGER_CHECK and SymTab[sym][S_VTYPE] = integer_type )*/
        _27639 = (_op_54584 == 96LL);
        if (_27639 == 0) {
            _27640 = 0;
            goto L24; // [1029] 1055
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27641 = (object)*(((s1_ptr)_2)->base + _sym_54593);
        _2 = (object)SEQ_PTR(_27641);
        _27642 = (object)*(((s1_ptr)_2)->base + 15LL);
        _27641 = NOVALUE;
        if (IS_ATOM_INT(_27642)) {
            _27643 = (_27642 == _54integer_type_46782);
        }
        else {
            _27643 = binary_op(EQUALS, _27642, _54integer_type_46782);
        }
        _27642 = NOVALUE;
        if (IS_ATOM_INT(_27643))
        _27640 = (_27643 != 0);
        else
        _27640 = DBL_PTR(_27643)->dbl != 0.0;
L24: 
        if (_27640 != 0) {
            _27644 = 1;
            goto L25; // [1055] 1095
        }
        _27645 = (_op_54584 == 97LL);
        if (_27645 == 0) {
            _27646 = 0;
            goto L26; // [1065] 1091
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27647 = (object)*(((s1_ptr)_2)->base + _sym_54593);
        _2 = (object)SEQ_PTR(_27647);
        _27648 = (object)*(((s1_ptr)_2)->base + 15LL);
        _27647 = NOVALUE;
        if (IS_ATOM_INT(_27648)) {
            _27649 = (_27648 == _54sequence_type_46780);
        }
        else {
            _27649 = binary_op(EQUALS, _27648, _54sequence_type_46780);
        }
        _27648 = NOVALUE;
        if (IS_ATOM_INT(_27649))
        _27646 = (_27649 != 0);
        else
        _27646 = DBL_PTR(_27649)->dbl != 0.0;
L26: 
        _27644 = (_27646 != 0);
L25: 
        if (_27644 != 0) {
            goto L27; // [1095] 1143
        }
        _27651 = (_op_54584 == 101LL);
        if (_27651 == 0) {
            DeRef(_27652);
            _27652 = 0;
            goto L28; // [1105] 1138
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27653 = (object)*(((s1_ptr)_2)->base + _sym_54593);
        _2 = (object)SEQ_PTR(_27653);
        _27654 = (object)*(((s1_ptr)_2)->base + 15LL);
        _27653 = NOVALUE;
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _54integer_type_46782;
        ((intptr_t *)_2)[2] = _54atom_type_46778;
        _27655 = MAKE_SEQ(_1);
        _27656 = find_from(_27654, _27655, 1LL);
        _27654 = NOVALUE;
        DeRefDS(_27655);
        _27655 = NOVALUE;
        _27652 = (_27656 != 0);
L28: 
        if (_27652 == 0)
        {
            _27652 = NOVALUE;
            goto L29; // [1139] 1157
        }
        else{
            _27652 = NOVALUE;
        }
L27: 

        /** inline.e:834							replace_code( {}, check_pc, check_pc+1 )*/
        _27657 = _check_pc_54580 + 1;
        if (_27657 > MAXINT){
            _27657 = NewDouble((eudouble)_27657);
        }
        RefDS(_21993);
        _67replace_code(_21993, _check_pc_54580, _27657);
        _27657 = NOVALUE;
        goto L22; // [1154] 1174
L29: 

        /** inline.e:837							check_pc += 2*/
        _check_pc_54580 = _check_pc_54580 + 2LL;
        goto L22; // [1164] 1174
L23: 

        /** inline.e:841						check_pc += 2*/
        _check_pc_54580 = _check_pc_54580 + 2LL;
L22: 

        /** inline.e:843					continue*/
        goto L1A; // [1180] 847

        /** inline.e:844				case STARTLINE then*/
        case 58:

        /** inline.e:845					check_pc += 2*/
        _check_pc_54580 = _check_pc_54580 + 2LL;

        /** inline.e:846					continue*/
        goto L1A; // [1198] 847

        /** inline.e:848				case else*/
        default:

        /** inline.e:849					exit*/
        goto L1B; // [1208] 1218
    ;}
    /** inline.e:851		end while*/
    goto L1A; // [1215] 847
L1B: 

    /** inline.e:853		for pc = 1 to length( inline_code ) do*/
    if (IS_SEQUENCE(_67inline_code_53449)){
            _27661 = SEQ_PTR(_67inline_code_53449)->length;
    }
    else {
        _27661 = 1;
    }
    {
        object _pc_54671;
        _pc_54671 = 1LL;
L2A: 
        if (_pc_54671 > _27661){
            goto L2B; // [1225] 1422
        }

        /** inline.e:854			if sequence( inline_code[pc] ) then*/
        _2 = (object)SEQ_PTR(_67inline_code_53449);
        _27662 = (object)*(((s1_ptr)_2)->base + _pc_54671);
        _27663 = IS_SEQUENCE(_27662);
        _27662 = NOVALUE;
        if (_27663 == 0)
        {
            _27663 = NOVALUE;
            goto L2C; // [1243] 1413
        }
        else{
            _27663 = NOVALUE;
        }

        /** inline.e:855				integer inline_type = inline_code[pc][1]*/
        _2 = (object)SEQ_PTR(_67inline_code_53449);
        _27664 = (object)*(((s1_ptr)_2)->base + _pc_54671);
        _2 = (object)SEQ_PTR(_27664);
        _inline_type_54676 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (!IS_ATOM_INT(_inline_type_54676)){
            _inline_type_54676 = (object)DBL_PTR(_inline_type_54676)->dbl;
        }
        _27664 = NOVALUE;

        /** inline.e:856				switch inline_type do*/
        _0 = _inline_type_54676;
        switch ( _0 ){ 

            /** inline.e:857					case INLINE_SUB then*/
            case 5:

            /** inline.e:858						inline_code[pc] = CurrentSub*/
            _2 = (object)SEQ_PTR(_67inline_code_53449);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _67inline_code_53449 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _pc_54671);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _36CurrentSub_21447;
            DeRef(_1);
            goto L2D; // [1281] 1412

            /** inline.e:860					case INLINE_VAR then*/
            case 6:

            /** inline.e:861						replace_var( pc )*/
            _67replace_var(_pc_54671);

            /** inline.e:862						break*/
            goto L2D; // [1294] 1412
            goto L2D; // [1296] 1412

            /** inline.e:863					case INLINE_TEMP then*/
            case 2:

            /** inline.e:864						replace_temp( pc )*/
            _67replace_temp(_pc_54671);
            goto L2D; // [1307] 1412

            /** inline.e:866					case INLINE_PARAM then*/
            case 1:

            /** inline.e:867						replace_param( pc )*/

            /** inline.e:586		inline_code[pc] = get_param_sym( pc )*/
            _0 = _replace_param_1__tmp_at1343_54687;
            _replace_param_1__tmp_at1343_54687 = _67get_param_sym(_pc_54671);
            DeRef(_0);
            Ref(_replace_param_1__tmp_at1343_54687);
            _2 = (object)SEQ_PTR(_67inline_code_53449);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _67inline_code_53449 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _pc_54671);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _replace_param_1__tmp_at1343_54687;
            DeRef(_1);

            /** inline.e:587	end procedure*/
            goto L2E; // [1329] 1332
L2E: 
            DeRef(_replace_param_1__tmp_at1343_54687);
            _replace_param_1__tmp_at1343_54687 = NOVALUE;
            goto L2D; // [1334] 1412

            /** inline.e:869					case INLINE_ADDR then*/
            case 4:

            /** inline.e:870						inline_code[pc] = inline_start + inline_code[pc][2]*/
            _2 = (object)SEQ_PTR(_67inline_code_53449);
            _27668 = (object)*(((s1_ptr)_2)->base + _pc_54671);
            _2 = (object)SEQ_PTR(_27668);
            _27669 = (object)*(((s1_ptr)_2)->base + 2LL);
            _27668 = NOVALUE;
            if (IS_ATOM_INT(_27669)) {
                _27670 = _67inline_start_53461 + _27669;
                if ((object)((uintptr_t)_27670 + (uintptr_t)HIGH_BITS) >= 0){
                    _27670 = NewDouble((eudouble)_27670);
                }
            }
            else {
                _27670 = binary_op(PLUS, _67inline_start_53461, _27669);
            }
            _27669 = NOVALUE;
            _2 = (object)SEQ_PTR(_67inline_code_53449);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _67inline_code_53449 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _pc_54671);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _27670;
            if( _1 != _27670 ){
                DeRef(_1);
            }
            _27670 = NOVALUE;
            goto L2D; // [1364] 1412

            /** inline.e:872					case INLINE_TARGET then*/
            case 3:

            /** inline.e:873						inline_code[pc] = inline_target*/
            _2 = (object)SEQ_PTR(_67inline_code_53449);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _67inline_code_53449 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _pc_54671);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _67inline_target_53456;
            DeRef(_1);

            /** inline.e:874						add_inline_target( pc + inline_start )*/
            _27671 = _pc_54671 + _67inline_start_53461;
            if ((object)((uintptr_t)_27671 + (uintptr_t)HIGH_BITS) >= 0){
                _27671 = NewDouble((eudouble)_27671);
            }
            _47add_inline_target(_27671);
            _27671 = NOVALUE;

            /** inline.e:875						break*/
            goto L2D; // [1393] 1412
            goto L2D; // [1395] 1412

            /** inline.e:877					case else*/
            default:

            /** inline.e:878						InternalErr( 265, {inline_type} )*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t*)_2)[1] = _inline_type_54676;
            _27672 = MAKE_SEQ(_1);
            _50InternalErr(265LL, _27672);
            _27672 = NOVALUE;
        ;}L2D: 
L2C: 

        /** inline.e:881		end for*/
        _pc_54671 = _pc_54671 + 1LL;
        goto L2A; // [1417] 1232
L2B: 
        ;
    }

    /** inline.e:883		for i = 1 to length(backpatches) do*/
    if (IS_SEQUENCE(_backpatches_54419)){
            _27673 = SEQ_PTR(_backpatches_54419)->length;
    }
    else {
        _27673 = 1;
    }
    {
        object _i_54699;
        _i_54699 = 1LL;
L2F: 
        if (_i_54699 > _27673){
            goto L30; // [1427] 1450
        }

        /** inline.e:884			fixup_special_op( backpatches[i] )*/
        _2 = (object)SEQ_PTR(_backpatches_54419);
        _27674 = (object)*(((s1_ptr)_2)->base + _i_54699);
        Ref(_27674);
        _67fixup_special_op(_27674);
        _27674 = NOVALUE;

        /** inline.e:885		end for*/
        _i_54699 = _i_54699 + 1LL;
        goto L2F; // [1445] 1434
L30: 
        ;
    }

    /** inline.e:887		epilog &= End_inline_block( EXIT_BLOCK )*/
    _27675 = _65End_inline_block(206LL);
    if (IS_SEQUENCE(_epilog_54426) && IS_ATOM(_27675)) {
        Ref(_27675);
        Append(&_epilog_54426, _epilog_54426, _27675);
    }
    else if (IS_ATOM(_epilog_54426) && IS_SEQUENCE(_27675)) {
    }
    else {
        Concat((object_ptr)&_epilog_54426, _epilog_54426, _27675);
    }
    DeRef(_27675);
    _27675 = NOVALUE;

    /** inline.e:889		if is_proc then*/
    if (_is_proc_54401 == 0)
    {
        goto L31; // [1464] 1474
    }
    else{
    }

    /** inline.e:890			clear_op()*/
    _47clear_op();
    goto L32; // [1471] 1597
L31: 

    /** inline.e:892			if not deferred then*/
    if (_deferred_54400 != 0)
    goto L33; // [1476] 1491

    /** inline.e:893				Push( inline_target )*/
    _47Push(_67inline_target_53456);

    /** inline.e:894				inlined_function()*/
    _47inlined_function();
L33: 

    /** inline.e:897			if final_target then*/
    if (_final_target_54525 == 0)
    {
        goto L34; // [1493] 1523
    }
    else{
    }

    /** inline.e:898				epilog &= { ASSIGN, inline_target, final_target }*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 18LL;
    ((intptr_t*)_2)[2] = _67inline_target_53456;
    ((intptr_t*)_2)[3] = _final_target_54525;
    _27678 = MAKE_SEQ(_1);
    Concat((object_ptr)&_epilog_54426, _epilog_54426, _27678);
    DeRefDS(_27678);
    _27678 = NOVALUE;

    /** inline.e:899				emit_temp( final_target, NEW_REFERENCE )*/
    _47emit_temp(_final_target_54525, 1LL);
    goto L35; // [1520] 1596
L34: 

    /** inline.e:905				emit_temp( inline_target, NEW_REFERENCE )*/
    _47emit_temp(_67inline_target_53456, 1LL);

    /** inline.e:906				if not TRANSLATE then*/
    if (_36TRANSLATE_21041 != 0)
    goto L36; // [1537] 1595

    /** inline.e:907					epilog &= { ELSE, 0, PRIVATE_INIT_CHECK, inline_target }*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 23LL;
    ((intptr_t*)_2)[2] = 0LL;
    ((intptr_t*)_2)[3] = 30LL;
    ((intptr_t*)_2)[4] = _67inline_target_53456;
    _27681 = MAKE_SEQ(_1);
    Concat((object_ptr)&_epilog_54426, _epilog_54426, _27681);
    DeRefDS(_27681);
    _27681 = NOVALUE;

    /** inline.e:908					epilog[$-2] = length(inline_code) + length(epilog) + inline_start + 1*/
    if (IS_SEQUENCE(_epilog_54426)){
            _27683 = SEQ_PTR(_epilog_54426)->length;
    }
    else {
        _27683 = 1;
    }
    _27684 = _27683 - 2LL;
    _27683 = NOVALUE;
    if (IS_SEQUENCE(_67inline_code_53449)){
            _27685 = SEQ_PTR(_67inline_code_53449)->length;
    }
    else {
        _27685 = 1;
    }
    if (IS_SEQUENCE(_epilog_54426)){
            _27686 = SEQ_PTR(_epilog_54426)->length;
    }
    else {
        _27686 = 1;
    }
    _27687 = _27685 + _27686;
    if ((object)((uintptr_t)_27687 + (uintptr_t)HIGH_BITS) >= 0){
        _27687 = NewDouble((eudouble)_27687);
    }
    _27685 = NOVALUE;
    _27686 = NOVALUE;
    if (IS_ATOM_INT(_27687)) {
        _27688 = _27687 + _67inline_start_53461;
        if ((object)((uintptr_t)_27688 + (uintptr_t)HIGH_BITS) >= 0){
            _27688 = NewDouble((eudouble)_27688);
        }
    }
    else {
        _27688 = NewDouble(DBL_PTR(_27687)->dbl + (eudouble)_67inline_start_53461);
    }
    DeRef(_27687);
    _27687 = NOVALUE;
    if (IS_ATOM_INT(_27688)) {
        _27689 = _27688 + 1;
        if (_27689 > MAXINT){
            _27689 = NewDouble((eudouble)_27689);
        }
    }
    else
    _27689 = binary_op(PLUS, 1, _27688);
    DeRef(_27688);
    _27688 = NOVALUE;
    _2 = (object)SEQ_PTR(_epilog_54426);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _epilog_54426 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27684);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27689;
    if( _1 != _27689 ){
        DeRef(_1);
    }
    _27689 = NOVALUE;
L36: 
L35: 
L32: 

    /** inline.e:914		return prolog & inline_code & epilog*/
    {
        object concat_list[3];

        concat_list[0] = _epilog_54426;
        concat_list[1] = _67inline_code_53449;
        concat_list[2] = _prolog_54425;
        Concat_N((object_ptr)&_27690, concat_list, 3);
    }
    DeRef(_backpatches_54419);
    DeRefDSi(_prolog_54425);
    DeRefDS(_epilog_54426);
    DeRef(_27569);
    _27569 = NOVALUE;
    _27578 = NOVALUE;
    DeRef(_27598);
    _27598 = NOVALUE;
    DeRef(_27566);
    _27566 = NOVALUE;
    DeRef(_27651);
    _27651 = NOVALUE;
    DeRef(_27645);
    _27645 = NOVALUE;
    DeRef(_27643);
    _27643 = NOVALUE;
    DeRef(_27639);
    _27639 = NOVALUE;
    DeRef(_27595);
    _27595 = NOVALUE;
    _27574 = NOVALUE;
    _27561 = NOVALUE;
    DeRef(_27649);
    _27649 = NOVALUE;
    DeRef(_27684);
    _27684 = NOVALUE;
    return _27690;
    ;
}


void _67defer_call()
{
    object _defer_54739 = NOVALUE;
    object _27693 = NOVALUE;
    object _27692 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:918		integer defer = find( inline_sub, deferred_inline_decisions )*/
    _defer_54739 = find_from(_67inline_sub_53463, _67deferred_inline_decisions_53465, 1LL);

    /** inline.e:919		if defer then*/
    if (_defer_54739 == 0)
    {
        goto L1; // [14] 36
    }
    else{
    }

    /** inline.e:921			deferred_inline_calls[defer] &= CurrentSub*/
    _2 = (object)SEQ_PTR(_67deferred_inline_calls_53466);
    _27692 = (object)*(((s1_ptr)_2)->base + _defer_54739);
    if (IS_SEQUENCE(_27692) && IS_ATOM(_36CurrentSub_21447)) {
        Append(&_27693, _27692, _36CurrentSub_21447);
    }
    else if (IS_ATOM(_27692) && IS_SEQUENCE(_36CurrentSub_21447)) {
    }
    else {
        Concat((object_ptr)&_27693, _27692, _36CurrentSub_21447);
        _27692 = NOVALUE;
    }
    _27692 = NOVALUE;
    _2 = (object)SEQ_PTR(_67deferred_inline_calls_53466);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67deferred_inline_calls_53466 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _defer_54739);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27693;
    if( _1 != _27693 ){
        DeRef(_1);
    }
    _27693 = NOVALUE;
L1: 

    /** inline.e:923	end procedure*/
    return;
    ;
}


void _67emit_or_inline()
{
    object _sub_54748 = NOVALUE;
    object _code_54779 = NOVALUE;
    object _27705 = NOVALUE;
    object _27704 = NOVALUE;
    object _27702 = NOVALUE;
    object _27701 = NOVALUE;
    object _27700 = NOVALUE;
    object _27698 = NOVALUE;
    object _27697 = NOVALUE;
    object _27696 = NOVALUE;
    object _27695 = NOVALUE;
    object _27694 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:928		symtab_index sub = op_info1*/
    _sub_54748 = _47op_info1_50932;

    /** inline.e:929		inline_sub = sub*/
    _67inline_sub_53463 = _sub_54748;

    /** inline.e:931		if SymTab[sub][S_DEPRECATED] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27694 = (object)*(((s1_ptr)_2)->base + _sub_54748);
    _2 = (object)SEQ_PTR(_27694);
    _27695 = (object)*(((s1_ptr)_2)->base + 30LL);
    _27694 = NOVALUE;
    if (_27695 == 0) {
        _27695 = NOVALUE;
        goto L1; // [31] 60
    }
    else {
        if (!IS_ATOM_INT(_27695) && DBL_PTR(_27695)->dbl == 0.0){
            _27695 = NOVALUE;
            goto L1; // [31] 60
        }
        _27695 = NOVALUE;
    }
    _27695 = NOVALUE;

    /** inline.e:932			Warning(327, deprecated_warning_flag, { SymTab[sub][S_NAME] })*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27696 = (object)*(((s1_ptr)_2)->base + _sub_54748);
    _2 = (object)SEQ_PTR(_27696);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _27697 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _27697 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _27696 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_27697);
    ((intptr_t*)_2)[1] = _27697;
    _27698 = MAKE_SEQ(_1);
    _27697 = NOVALUE;
    _50Warning(327LL, 16384LL, _27698);
    _27698 = NOVALUE;
L1: 

    /** inline.e:935		if Parser_mode != PAM_NORMAL then*/
    if (_36Parser_mode_21548 == 0LL)
    goto L2; // [66] 85

    /** inline.e:938			emit_op( PROC )*/
    _47emit_op(27LL);

    /** inline.e:939			return*/
    DeRef(_code_54779);
    return;
    goto L3; // [82] 133
L2: 

    /** inline.e:941		elsif atom( SymTab[sub][S_INLINE] ) or has_forward_params(sub) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27700 = (object)*(((s1_ptr)_2)->base + _sub_54748);
    _2 = (object)SEQ_PTR(_27700);
    _27701 = (object)*(((s1_ptr)_2)->base + 29LL);
    _27700 = NOVALUE;
    _27702 = IS_ATOM(_27701);
    _27701 = NOVALUE;
    if (_27702 != 0) {
        goto L4; // [102] 115
    }
    _27704 = _47has_forward_params(_sub_54748);
    if (_27704 == 0) {
        DeRef(_27704);
        _27704 = NOVALUE;
        goto L5; // [111] 132
    }
    else {
        if (!IS_ATOM_INT(_27704) && DBL_PTR(_27704)->dbl == 0.0){
            DeRef(_27704);
            _27704 = NOVALUE;
            goto L5; // [111] 132
        }
        DeRef(_27704);
        _27704 = NOVALUE;
    }
    DeRef(_27704);
    _27704 = NOVALUE;
L4: 

    /** inline.e:942			defer_call()*/
    _67defer_call();

    /** inline.e:943			emit_op( PROC )*/
    _47emit_op(27LL);

    /** inline.e:944			return*/
    DeRef(_code_54779);
    return;
L5: 
L3: 

    /** inline.e:947		sequence code = get_inlined_code( sub, length(Code) )*/
    if (IS_SEQUENCE(_36Code_21531)){
            _27705 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _27705 = 1;
    }
    _0 = _code_54779;
    _code_54779 = _67get_inlined_code(_sub_54748, _27705, 0LL);
    DeRef(_0);
    _27705 = NOVALUE;

    /** inline.e:948		emit_inline( code )*/
    RefDS(_code_54779);
    _47emit_inline(_code_54779);

    /** inline.e:949		clear_last()*/
    _47clear_last();

    /** inline.e:951	end procedure*/
    DeRefDS(_code_54779);
    return;
    ;
}


void _67inline_deferred_calls()
{
    object _sub_54793 = NOVALUE;
    object _ix_54805 = NOVALUE;
    object _calling_sub_54807 = NOVALUE;
    object _code_54829 = NOVALUE;
    object _calls_54830 = NOVALUE;
    object _is_func_54834 = NOVALUE;
    object _offset_54841 = NOVALUE;
    object _op_54852 = NOVALUE;
    object _size_54855 = NOVALUE;
    object _27767 = NOVALUE;
    object _27765 = NOVALUE;
    object _27763 = NOVALUE;
    object _27762 = NOVALUE;
    object _27761 = NOVALUE;
    object _27759 = NOVALUE;
    object _27758 = NOVALUE;
    object _27757 = NOVALUE;
    object _27756 = NOVALUE;
    object _27755 = NOVALUE;
    object _27754 = NOVALUE;
    object _27753 = NOVALUE;
    object _27752 = NOVALUE;
    object _27751 = NOVALUE;
    object _27750 = NOVALUE;
    object _27748 = NOVALUE;
    object _27747 = NOVALUE;
    object _27746 = NOVALUE;
    object _27745 = NOVALUE;
    object _27743 = NOVALUE;
    object _27742 = NOVALUE;
    object _27741 = NOVALUE;
    object _27739 = NOVALUE;
    object _27737 = NOVALUE;
    object _27735 = NOVALUE;
    object _27733 = NOVALUE;
    object _27732 = NOVALUE;
    object _27731 = NOVALUE;
    object _27730 = NOVALUE;
    object _27728 = NOVALUE;
    object _27727 = NOVALUE;
    object _27724 = NOVALUE;
    object _27722 = NOVALUE;
    object _27720 = NOVALUE;
    object _27718 = NOVALUE;
    object _27716 = NOVALUE;
    object _27715 = NOVALUE;
    object _27714 = NOVALUE;
    object _27713 = NOVALUE;
    object _27712 = NOVALUE;
    object _27711 = NOVALUE;
    object _27709 = NOVALUE;
    object _27708 = NOVALUE;
    object _27707 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** inline.e:957		deferred_inlining = 1*/
    _67deferred_inlining_53459 = 1LL;

    /** inline.e:958		for i = 1 to length( deferred_inline_decisions ) do*/
    if (IS_SEQUENCE(_67deferred_inline_decisions_53465)){
            _27707 = SEQ_PTR(_67deferred_inline_decisions_53465)->length;
    }
    else {
        _27707 = 1;
    }
    {
        object _i_54788;
        _i_54788 = 1LL;
L1: 
        if (_i_54788 > _27707){
            goto L2; // [13] 506
        }

        /** inline.e:960			if length( deferred_inline_calls[i] ) then*/
        _2 = (object)SEQ_PTR(_67deferred_inline_calls_53466);
        _27708 = (object)*(((s1_ptr)_2)->base + _i_54788);
        if (IS_SEQUENCE(_27708)){
                _27709 = SEQ_PTR(_27708)->length;
        }
        else {
            _27709 = 1;
        }
        _27708 = NOVALUE;
        if (_27709 == 0)
        {
            _27709 = NOVALUE;
            goto L3; // [31] 497
        }
        else{
            _27709 = NOVALUE;
        }

        /** inline.e:962				integer sub = deferred_inline_decisions[i]*/
        _2 = (object)SEQ_PTR(_67deferred_inline_decisions_53465);
        _sub_54793 = (object)*(((s1_ptr)_2)->base + _i_54788);

        /** inline.e:963				check_inline( sub )*/
        _67check_inline(_sub_54793);

        /** inline.e:964				if atom( SymTab[sub][S_INLINE] ) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _27711 = (object)*(((s1_ptr)_2)->base + _sub_54793);
        _2 = (object)SEQ_PTR(_27711);
        _27712 = (object)*(((s1_ptr)_2)->base + 29LL);
        _27711 = NOVALUE;
        _27713 = IS_ATOM(_27712);
        _27712 = NOVALUE;
        if (_27713 == 0)
        {
            _27713 = NOVALUE;
            goto L4; // [64] 74
        }
        else{
            _27713 = NOVALUE;
        }

        /** inline.e:965					continue*/
        goto L5; // [71] 501
L4: 

        /** inline.e:967				for cx = 1 to length( deferred_inline_calls[i] ) do*/
        _2 = (object)SEQ_PTR(_67deferred_inline_calls_53466);
        _27714 = (object)*(((s1_ptr)_2)->base + _i_54788);
        if (IS_SEQUENCE(_27714)){
                _27715 = SEQ_PTR(_27714)->length;
        }
        else {
            _27715 = 1;
        }
        _27714 = NOVALUE;
        {
            object _cx_54802;
            _cx_54802 = 1LL;
L6: 
            if (_cx_54802 > _27715){
                goto L7; // [85] 496
            }

            /** inline.e:968					integer ix = 1*/
            _ix_54805 = 1LL;

            /** inline.e:969					symtab_index calling_sub = deferred_inline_calls[i][cx]*/
            _2 = (object)SEQ_PTR(_67deferred_inline_calls_53466);
            _27716 = (object)*(((s1_ptr)_2)->base + _i_54788);
            _2 = (object)SEQ_PTR(_27716);
            _calling_sub_54807 = (object)*(((s1_ptr)_2)->base + _cx_54802);
            if (!IS_ATOM_INT(_calling_sub_54807)){
                _calling_sub_54807 = (object)DBL_PTR(_calling_sub_54807)->dbl;
            }
            _27716 = NOVALUE;

            /** inline.e:970					CurrentSub = calling_sub*/
            _36CurrentSub_21447 = _calling_sub_54807;

            /** inline.e:971					Code = SymTab[calling_sub][S_CODE]*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _27718 = (object)*(((s1_ptr)_2)->base + _calling_sub_54807);
            DeRef(_36Code_21531);
            _2 = (object)SEQ_PTR(_27718);
            if (!IS_ATOM_INT(_36S_CODE_21088)){
                _36Code_21531 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
            }
            else{
                _36Code_21531 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21088);
            }
            Ref(_36Code_21531);
            _27718 = NOVALUE;

            /** inline.e:972					LineTable = SymTab[calling_sub][S_LINETAB]*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _27720 = (object)*(((s1_ptr)_2)->base + _calling_sub_54807);
            DeRef(_36LineTable_21532);
            _2 = (object)SEQ_PTR(_27720);
            if (!IS_ATOM_INT(_36S_LINETAB_21111)){
                _36LineTable_21532 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21111)->dbl));
            }
            else{
                _36LineTable_21532 = (object)*(((s1_ptr)_2)->base + _36S_LINETAB_21111);
            }
            Ref(_36LineTable_21532);
            _27720 = NOVALUE;

            /** inline.e:973					SymTab[calling_sub][S_CODE] = 0*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _37SymTab_15406 = MAKE_SEQ(_2);
            }
            _3 = (object)(_calling_sub_54807 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_36S_CODE_21088))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21088);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 0LL;
            DeRef(_1);
            _27722 = NOVALUE;

            /** inline.e:974					SymTab[calling_sub][S_LINETAB] = 0*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _37SymTab_15406 = MAKE_SEQ(_2);
            }
            _3 = (object)(_calling_sub_54807 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_36S_LINETAB_21111))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21111)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21111);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 0LL;
            DeRef(_1);
            _27724 = NOVALUE;

            /** inline.e:975					sequence code = {}*/
            RefDS(_21993);
            DeRef(_code_54829);
            _code_54829 = _21993;

            /** inline.e:977					sequence calls = find_ops( 1, PROC )*/
            RefDS(_36Code_21531);
            _0 = _calls_54830;
            _calls_54830 = _66find_ops(1LL, 27LL, _36Code_21531);
            DeRef(_0);

            /** inline.e:978					integer is_func = SymTab[sub][S_TOKEN] != PROC */
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _27727 = (object)*(((s1_ptr)_2)->base + _sub_54793);
            _2 = (object)SEQ_PTR(_27727);
            if (!IS_ATOM_INT(_36S_TOKEN_21081)){
                _27728 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
            }
            else{
                _27728 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
            }
            _27727 = NOVALUE;
            if (IS_ATOM_INT(_27728)) {
                _is_func_54834 = (_27728 != 27LL);
            }
            else {
                _is_func_54834 = binary_op(NOTEQ, _27728, 27LL);
            }
            _27728 = NOVALUE;
            if (!IS_ATOM_INT(_is_func_54834)) {
                _1 = (object)(DBL_PTR(_is_func_54834)->dbl);
                DeRefDS(_is_func_54834);
                _is_func_54834 = _1;
            }

            /** inline.e:979					integer offset = 0*/
            _offset_54841 = 0LL;

            /** inline.e:980					for o = 1 to length( calls ) do*/
            if (IS_SEQUENCE(_calls_54830)){
                    _27730 = SEQ_PTR(_calls_54830)->length;
            }
            else {
                _27730 = 1;
            }
            {
                object _o_54843;
                _o_54843 = 1LL;
L8: 
                if (_o_54843 > _27730){
                    goto L9; // [233] 453
                }

                /** inline.e:981						if calls[o][2][2] = sub then*/
                _2 = (object)SEQ_PTR(_calls_54830);
                _27731 = (object)*(((s1_ptr)_2)->base + _o_54843);
                _2 = (object)SEQ_PTR(_27731);
                _27732 = (object)*(((s1_ptr)_2)->base + 2LL);
                _27731 = NOVALUE;
                _2 = (object)SEQ_PTR(_27732);
                _27733 = (object)*(((s1_ptr)_2)->base + 2LL);
                _27732 = NOVALUE;
                if (binary_op_a(NOTEQ, _27733, _sub_54793)){
                    _27733 = NOVALUE;
                    goto LA; // [254] 444
                }
                _27733 = NOVALUE;

                /** inline.e:982							ix = calls[o][1]*/
                _2 = (object)SEQ_PTR(_calls_54830);
                _27735 = (object)*(((s1_ptr)_2)->base + _o_54843);
                _2 = (object)SEQ_PTR(_27735);
                _ix_54805 = (object)*(((s1_ptr)_2)->base + 1LL);
                if (!IS_ATOM_INT(_ix_54805)){
                    _ix_54805 = (object)DBL_PTR(_ix_54805)->dbl;
                }
                _27735 = NOVALUE;

                /** inline.e:983							sequence op = calls[o][2]*/
                _2 = (object)SEQ_PTR(_calls_54830);
                _27737 = (object)*(((s1_ptr)_2)->base + _o_54843);
                DeRef(_op_54852);
                _2 = (object)SEQ_PTR(_27737);
                _op_54852 = (object)*(((s1_ptr)_2)->base + 2LL);
                Ref(_op_54852);
                _27737 = NOVALUE;

                /** inline.e:984							integer size = length( op ) - 1*/
                if (IS_SEQUENCE(_op_54852)){
                        _27739 = SEQ_PTR(_op_54852)->length;
                }
                else {
                    _27739 = 1;
                }
                _size_54855 = _27739 - 1LL;
                _27739 = NOVALUE;

                /** inline.e:985							if is_func then*/
                if (_is_func_54834 == 0)
                {
                    goto LB; // [293] 319
                }
                else{
                }

                /** inline.e:987								Push( op[$] )*/
                if (IS_SEQUENCE(_op_54852)){
                        _27741 = SEQ_PTR(_op_54852)->length;
                }
                else {
                    _27741 = 1;
                }
                _2 = (object)SEQ_PTR(_op_54852);
                _27742 = (object)*(((s1_ptr)_2)->base + _27741);
                Ref(_27742);
                _47Push(_27742);
                _27742 = NOVALUE;

                /** inline.e:988								op = remove( op, length(op) )*/
                if (IS_SEQUENCE(_op_54852)){
                        _27743 = SEQ_PTR(_op_54852)->length;
                }
                else {
                    _27743 = 1;
                }
                {
                    s1_ptr assign_space = SEQ_PTR(_op_54852);
                    int len = assign_space->length;
                    int start = (IS_ATOM_INT(_27743)) ? _27743 : (object)(DBL_PTR(_27743)->dbl);
                    int stop = (IS_ATOM_INT(_27743)) ? _27743 : (object)(DBL_PTR(_27743)->dbl);
                    if (stop > len){
                        stop = len;
                    }
                    if (start > len || start > stop || stop<1) {
                    }
                    else if (start < 2) {
                        if (stop >= len) {
                            Head( SEQ_PTR(_op_54852), start, &_op_54852 );
                        }
                        else Tail(SEQ_PTR(_op_54852), stop+1, &_op_54852);
                    }
                    else if (stop >= len){
                        Head(SEQ_PTR(_op_54852), start, &_op_54852);
                    }
                    else {
                        assign_slice_seq = &assign_space;
                        _op_54852 = Remove_elements(start, stop, (SEQ_PTR(_op_54852)->ref == 1));
                    }
                }
                _27743 = NOVALUE;
                _27743 = NOVALUE;
LB: 

                /** inline.e:992							for p = 3 to length( op ) do*/
                if (IS_SEQUENCE(_op_54852)){
                        _27745 = SEQ_PTR(_op_54852)->length;
                }
                else {
                    _27745 = 1;
                }
                {
                    object _p_54865;
                    _p_54865 = 3LL;
LC: 
                    if (_p_54865 > _27745){
                        goto LD; // [324] 347
                    }

                    /** inline.e:993								Push( op[p] )*/
                    _2 = (object)SEQ_PTR(_op_54852);
                    _27746 = (object)*(((s1_ptr)_2)->base + _p_54865);
                    Ref(_27746);
                    _47Push(_27746);
                    _27746 = NOVALUE;

                    /** inline.e:994							end for*/
                    _p_54865 = _p_54865 + 1LL;
                    goto LC; // [342] 331
LD: 
                    ;
                }

                /** inline.e:995							code = get_inlined_code( sub, ix + offset - 1, 1 )*/
                _27747 = _ix_54805 + _offset_54841;
                if ((object)((uintptr_t)_27747 + (uintptr_t)HIGH_BITS) >= 0){
                    _27747 = NewDouble((eudouble)_27747);
                }
                if (IS_ATOM_INT(_27747)) {
                    _27748 = _27747 - 1LL;
                    if ((object)((uintptr_t)_27748 +(uintptr_t) HIGH_BITS) >= 0){
                        _27748 = NewDouble((eudouble)_27748);
                    }
                }
                else {
                    _27748 = NewDouble(DBL_PTR(_27747)->dbl - (eudouble)1LL);
                }
                DeRef(_27747);
                _27747 = NOVALUE;
                _0 = _code_54829;
                _code_54829 = _67get_inlined_code(_sub_54793, _27748, 1LL);
                DeRef(_0);
                _27748 = NOVALUE;

                /** inline.e:996							shift:replace_code( repeat( NOP1, length(code) ), ix + offset, ix + offset + size )*/
                if (IS_SEQUENCE(_code_54829)){
                        _27750 = SEQ_PTR(_code_54829)->length;
                }
                else {
                    _27750 = 1;
                }
                _27751 = Repeat(159LL, _27750);
                _27750 = NOVALUE;
                _27752 = _ix_54805 + _offset_54841;
                if ((object)((uintptr_t)_27752 + (uintptr_t)HIGH_BITS) >= 0){
                    _27752 = NewDouble((eudouble)_27752);
                }
                _27753 = _ix_54805 + _offset_54841;
                if ((object)((uintptr_t)_27753 + (uintptr_t)HIGH_BITS) >= 0){
                    _27753 = NewDouble((eudouble)_27753);
                }
                if (IS_ATOM_INT(_27753)) {
                    _27754 = _27753 + _size_54855;
                    if ((object)((uintptr_t)_27754 + (uintptr_t)HIGH_BITS) >= 0){
                        _27754 = NewDouble((eudouble)_27754);
                    }
                }
                else {
                    _27754 = NewDouble(DBL_PTR(_27753)->dbl + (eudouble)_size_54855);
                }
                DeRef(_27753);
                _27753 = NOVALUE;
                _66replace_code(_27751, _27752, _27754);
                _27751 = NOVALUE;
                _27752 = NOVALUE;
                _27754 = NOVALUE;

                /** inline.e:999							Code = eu:replace( Code, code, ix + offset, ix + offset + length( code ) -1 )*/
                _27755 = _ix_54805 + _offset_54841;
                if ((object)((uintptr_t)_27755 + (uintptr_t)HIGH_BITS) >= 0){
                    _27755 = NewDouble((eudouble)_27755);
                }
                _27756 = _ix_54805 + _offset_54841;
                if ((object)((uintptr_t)_27756 + (uintptr_t)HIGH_BITS) >= 0){
                    _27756 = NewDouble((eudouble)_27756);
                }
                if (IS_SEQUENCE(_code_54829)){
                        _27757 = SEQ_PTR(_code_54829)->length;
                }
                else {
                    _27757 = 1;
                }
                if (IS_ATOM_INT(_27756)) {
                    _27758 = _27756 + _27757;
                    if ((object)((uintptr_t)_27758 + (uintptr_t)HIGH_BITS) >= 0){
                        _27758 = NewDouble((eudouble)_27758);
                    }
                }
                else {
                    _27758 = NewDouble(DBL_PTR(_27756)->dbl + (eudouble)_27757);
                }
                DeRef(_27756);
                _27756 = NOVALUE;
                _27757 = NOVALUE;
                if (IS_ATOM_INT(_27758)) {
                    _27759 = _27758 - 1LL;
                    if ((object)((uintptr_t)_27759 +(uintptr_t) HIGH_BITS) >= 0){
                        _27759 = NewDouble((eudouble)_27759);
                    }
                }
                else {
                    _27759 = NewDouble(DBL_PTR(_27758)->dbl - (eudouble)1LL);
                }
                DeRef(_27758);
                _27758 = NOVALUE;
                {
                    intptr_t p1 = _36Code_21531;
                    intptr_t p2 = _code_54829;
                    intptr_t p3 = _27755;
                    intptr_t p4 = _27759;
                    struct replace_block replace_params;
                    replace_params.copy_to   = &p1;
                    replace_params.copy_from = &p2;
                    replace_params.start     = &p3;
                    replace_params.stop      = &p4;
                    replace_params.target    = &_36Code_21531;
                    Replace( &replace_params );
                }
                DeRef(_27755);
                _27755 = NOVALUE;
                DeRef(_27759);
                _27759 = NOVALUE;

                /** inline.e:1000							offset += length(code) - size - 1*/
                if (IS_SEQUENCE(_code_54829)){
                        _27761 = SEQ_PTR(_code_54829)->length;
                }
                else {
                    _27761 = 1;
                }
                _27762 = _27761 - _size_54855;
                if ((object)((uintptr_t)_27762 +(uintptr_t) HIGH_BITS) >= 0){
                    _27762 = NewDouble((eudouble)_27762);
                }
                _27761 = NOVALUE;
                if (IS_ATOM_INT(_27762)) {
                    _27763 = _27762 - 1LL;
                    if ((object)((uintptr_t)_27763 +(uintptr_t) HIGH_BITS) >= 0){
                        _27763 = NewDouble((eudouble)_27763);
                    }
                }
                else {
                    _27763 = NewDouble(DBL_PTR(_27762)->dbl - (eudouble)1LL);
                }
                DeRef(_27762);
                _27762 = NOVALUE;
                if (IS_ATOM_INT(_27763)) {
                    _offset_54841 = _offset_54841 + _27763;
                }
                else {
                    _offset_54841 = NewDouble((eudouble)_offset_54841 + DBL_PTR(_27763)->dbl);
                }
                DeRef(_27763);
                _27763 = NOVALUE;
                if (!IS_ATOM_INT(_offset_54841)) {
                    _1 = (object)(DBL_PTR(_offset_54841)->dbl);
                    DeRefDS(_offset_54841);
                    _offset_54841 = _1;
                }
LA: 
                DeRef(_op_54852);
                _op_54852 = NOVALUE;

                /** inline.e:1003					end for*/
                _o_54843 = _o_54843 + 1LL;
                goto L8; // [448] 240
L9: 
                ;
            }

            /** inline.e:1004					SymTab[calling_sub][S_CODE] = Code*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _37SymTab_15406 = MAKE_SEQ(_2);
            }
            _3 = (object)(_calling_sub_54807 + ((s1_ptr)_2)->base);
            RefDS(_36Code_21531);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_36S_CODE_21088))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21088);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _36Code_21531;
            DeRef(_1);
            _27765 = NOVALUE;

            /** inline.e:1005					SymTab[calling_sub][S_LINETAB] = LineTable*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _37SymTab_15406 = MAKE_SEQ(_2);
            }
            _3 = (object)(_calling_sub_54807 + ((s1_ptr)_2)->base);
            RefDS(_36LineTable_21532);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_36S_LINETAB_21111))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21111)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21111);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _36LineTable_21532;
            DeRef(_1);
            _27767 = NOVALUE;
            DeRef(_code_54829);
            _code_54829 = NOVALUE;
            DeRef(_calls_54830);
            _calls_54830 = NOVALUE;

            /** inline.e:1006				end for*/
            _cx_54802 = _cx_54802 + 1LL;
            goto L6; // [491] 92
L7: 
            ;
        }
L3: 

        /** inline.e:1008		end for*/
L5: 
        _i_54788 = _i_54788 + 1LL;
        goto L1; // [501] 20
L2: 
        ;
    }

    /** inline.e:1009	end procedure*/
    _27714 = NOVALUE;
    _27708 = NOVALUE;
    return;
    ;
}



// 0x7B2341F6
