// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _71default_state()
{
    object _32123 = NOVALUE;
    object _0, _1, _2;
    

    /** tokenize.e:177		return {*/
    _1 = NewS1(8);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    ((intptr_t*)_2)[3] = 0LL;
    ((intptr_t*)_2)[4] = 1LL;
    ((intptr_t*)_2)[5] = 0LL;
    ((intptr_t*)_2)[6] = 1LL;
    ((intptr_t*)_2)[7] = 0LL;
    ((intptr_t*)_2)[8] = 0LL;
    _32123 = MAKE_SEQ(_1);
    return _32123;
    ;
}


object _71new()
{
    object _state_65508 = NOVALUE;
    object _0, _1, _2;
    

    /** tokenize.e:200		atom state = eumem:malloc()*/
    _0 = _state_65508;
    _state_65508 = _30malloc(1LL, 1LL);
    DeRef(_0);

    /** tokenize.e:202		reset(state)*/
    Ref(_state_65508);
    _71reset(_state_65508);

    /** tokenize.e:204		return state*/
    return _state_65508;
    ;
}


void _71reset(object _state_65513)
{
    object _32127 = NOVALUE;
    object _0, _1, _2;
    

    /** tokenize.e:215		eumem:ram_space[state] = default_state()*/
    _32127 = _71default_state();
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _30ram_space_11238 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_65513))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_state_65513)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _state_65513);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32127;
    if( _1 != _32127 ){
        DeRef(_1);
    }
    _32127 = NOVALUE;

    /** tokenize.e:216	end procedure*/
    DeRef(_state_65513);
    return;
    ;
}



// 0x8872F57D
