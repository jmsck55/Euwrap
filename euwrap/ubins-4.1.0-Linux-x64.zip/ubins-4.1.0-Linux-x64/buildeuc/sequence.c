// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _23reverse(object _target_4468, object _pFrom_4469, object _pTo_4470)
{
    object _uppr_4471 = NOVALUE;
    object _n_4472 = NOVALUE;
    object _lLimit_4473 = NOVALUE;
    object _t_4474 = NOVALUE;
    object _2230 = NOVALUE;
    object _2229 = NOVALUE;
    object _2228 = NOVALUE;
    object _2226 = NOVALUE;
    object _2225 = NOVALUE;
    object _2223 = NOVALUE;
    object _2221 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:549		n = length(target)*/
    if (IS_SEQUENCE(_target_4468)){
            _n_4472 = SEQ_PTR(_target_4468)->length;
    }
    else {
        _n_4472 = 1;
    }

    /** sequence.e:550		if n < 2 then*/
    if (_n_4472 >= 2LL)
    goto L1; // [12] 23

    /** sequence.e:551			return target*/
    DeRef(_t_4474);
    return _target_4468;
L1: 

    /** sequence.e:553		if pFrom < 1 then*/
    if (_pFrom_4469 >= 1LL)
    goto L2; // [25] 35

    /** sequence.e:554			pFrom = 1*/
    _pFrom_4469 = 1LL;
L2: 

    /** sequence.e:556		if pTo < 1 then*/
    if (_pTo_4470 >= 1LL)
    goto L3; // [37] 48

    /** sequence.e:557			pTo = n + pTo*/
    _pTo_4470 = _n_4472 + _pTo_4470;
L3: 

    /** sequence.e:559		if pTo < pFrom or pFrom >= n then*/
    _2221 = (_pTo_4470 < _pFrom_4469);
    if (_2221 != 0) {
        goto L4; // [54] 67
    }
    _2223 = (_pFrom_4469 >= _n_4472);
    if (_2223 == 0)
    {
        DeRef(_2223);
        _2223 = NOVALUE;
        goto L5; // [63] 74
    }
    else{
        DeRef(_2223);
        _2223 = NOVALUE;
    }
L4: 

    /** sequence.e:560			return target*/
    DeRef(_t_4474);
    DeRef(_2221);
    _2221 = NOVALUE;
    return _target_4468;
L5: 

    /** sequence.e:562		if pTo > n then*/
    if (_pTo_4470 <= _n_4472)
    goto L6; // [76] 86

    /** sequence.e:563			pTo = n*/
    _pTo_4470 = _n_4472;
L6: 

    /** sequence.e:566		lLimit = floor((pFrom+pTo-1)/2)*/
    _2225 = _pFrom_4469 + _pTo_4470;
    if ((object)((uintptr_t)_2225 + (uintptr_t)HIGH_BITS) >= 0){
        _2225 = NewDouble((eudouble)_2225);
    }
    if (IS_ATOM_INT(_2225)) {
        _2226 = _2225 - 1LL;
        if ((object)((uintptr_t)_2226 +(uintptr_t) HIGH_BITS) >= 0){
            _2226 = NewDouble((eudouble)_2226);
        }
    }
    else {
        _2226 = NewDouble(DBL_PTR(_2225)->dbl - (eudouble)1LL);
    }
    DeRef(_2225);
    _2225 = NOVALUE;
    if (IS_ATOM_INT(_2226)) {
        _lLimit_4473 = _2226 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _2226, 2);
        _lLimit_4473 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    DeRef(_2226);
    _2226 = NOVALUE;
    if (!IS_ATOM_INT(_lLimit_4473)) {
        _1 = (object)(DBL_PTR(_lLimit_4473)->dbl);
        DeRefDS(_lLimit_4473);
        _lLimit_4473 = _1;
    }

    /** sequence.e:567		t = target*/
    Ref(_target_4468);
    DeRef(_t_4474);
    _t_4474 = _target_4468;

    /** sequence.e:568		uppr = pTo*/
    _uppr_4471 = _pTo_4470;

    /** sequence.e:569		for lowr = pFrom to lLimit do*/
    _2228 = _lLimit_4473;
    {
        object _lowr_4493;
        _lowr_4493 = _pFrom_4469;
L7: 
        if (_lowr_4493 > _2228){
            goto L8; // [119] 159
        }

        /** sequence.e:570			t[uppr] = target[lowr]*/
        _2 = (object)SEQ_PTR(_target_4468);
        _2229 = (object)*(((s1_ptr)_2)->base + _lowr_4493);
        Ref(_2229);
        _2 = (object)SEQ_PTR(_t_4474);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _t_4474 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _uppr_4471);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _2229;
        if( _1 != _2229 ){
            DeRef(_1);
        }
        _2229 = NOVALUE;

        /** sequence.e:571			t[lowr] = target[uppr]*/
        _2 = (object)SEQ_PTR(_target_4468);
        _2230 = (object)*(((s1_ptr)_2)->base + _uppr_4471);
        Ref(_2230);
        _2 = (object)SEQ_PTR(_t_4474);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _t_4474 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _lowr_4493);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _2230;
        if( _1 != _2230 ){
            DeRef(_1);
        }
        _2230 = NOVALUE;

        /** sequence.e:572			uppr -= 1*/
        _uppr_4471 = _uppr_4471 - 1LL;

        /** sequence.e:573		end for*/
        _lowr_4493 = _lowr_4493 + 1LL;
        goto L7; // [154] 126
L8: 
        ;
    }

    /** sequence.e:574		return t*/
    DeRef(_target_4468);
    DeRef(_2221);
    _2221 = NOVALUE;
    return _t_4474;
    ;
}


object _23pad_tail(object _target_4569, object _size_4570, object _ch_4571)
{
    object _2267 = NOVALUE;
    object _2266 = NOVALUE;
    object _2265 = NOVALUE;
    object _2264 = NOVALUE;
    object _2262 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:1022		if size <= length(target) then*/
    if (IS_SEQUENCE(_target_4569)){
            _2262 = SEQ_PTR(_target_4569)->length;
    }
    else {
        _2262 = 1;
    }
    if (_size_4570 > _2262)
    goto L1; // [8] 19

    /** sequence.e:1023			return target*/
    return _target_4569;
L1: 

    /** sequence.e:1026		return target & repeat(ch, size - length(target))*/
    if (IS_SEQUENCE(_target_4569)){
            _2264 = SEQ_PTR(_target_4569)->length;
    }
    else {
        _2264 = 1;
    }
    _2265 = _size_4570 - _2264;
    _2264 = NOVALUE;
    _2266 = Repeat(_ch_4571, _2265);
    _2265 = NOVALUE;
    if (IS_SEQUENCE(_target_4569) && IS_ATOM(_2266)) {
    }
    else if (IS_ATOM(_target_4569) && IS_SEQUENCE(_2266)) {
        Ref(_target_4569);
        Prepend(&_2267, _2266, _target_4569);
    }
    else {
        Concat((object_ptr)&_2267, _target_4569, _2266);
    }
    DeRefDS(_2266);
    _2266 = NOVALUE;
    DeRef(_target_4569);
    return _2267;
    ;
}


object _23filter(object _source_4823, object _rid_4824, object _userdata_4825, object _rangetype_4826)
{
    object _dest_4827 = NOVALUE;
    object _idx_4828 = NOVALUE;
    object _2581 = NOVALUE;
    object _2580 = NOVALUE;
    object _2578 = NOVALUE;
    object _2577 = NOVALUE;
    object _2576 = NOVALUE;
    object _2575 = NOVALUE;
    object _2574 = NOVALUE;
    object _2571 = NOVALUE;
    object _2570 = NOVALUE;
    object _2569 = NOVALUE;
    object _2568 = NOVALUE;
    object _2565 = NOVALUE;
    object _2564 = NOVALUE;
    object _2563 = NOVALUE;
    object _2562 = NOVALUE;
    object _2561 = NOVALUE;
    object _2558 = NOVALUE;
    object _2557 = NOVALUE;
    object _2556 = NOVALUE;
    object _2555 = NOVALUE;
    object _2552 = NOVALUE;
    object _2551 = NOVALUE;
    object _2550 = NOVALUE;
    object _2549 = NOVALUE;
    object _2548 = NOVALUE;
    object _2545 = NOVALUE;
    object _2544 = NOVALUE;
    object _2543 = NOVALUE;
    object _2542 = NOVALUE;
    object _2539 = NOVALUE;
    object _2538 = NOVALUE;
    object _2537 = NOVALUE;
    object _2536 = NOVALUE;
    object _2535 = NOVALUE;
    object _2532 = NOVALUE;
    object _2531 = NOVALUE;
    object _2530 = NOVALUE;
    object _2529 = NOVALUE;
    object _2526 = NOVALUE;
    object _2525 = NOVALUE;
    object _2524 = NOVALUE;
    object _2523 = NOVALUE;
    object _2522 = NOVALUE;
    object _2519 = NOVALUE;
    object _2518 = NOVALUE;
    object _2517 = NOVALUE;
    object _2513 = NOVALUE;
    object _2510 = NOVALUE;
    object _2509 = NOVALUE;
    object _2508 = NOVALUE;
    object _2506 = NOVALUE;
    object _2505 = NOVALUE;
    object _2504 = NOVALUE;
    object _2503 = NOVALUE;
    object _2502 = NOVALUE;
    object _2499 = NOVALUE;
    object _2498 = NOVALUE;
    object _2497 = NOVALUE;
    object _2495 = NOVALUE;
    object _2494 = NOVALUE;
    object _2493 = NOVALUE;
    object _2492 = NOVALUE;
    object _2491 = NOVALUE;
    object _2488 = NOVALUE;
    object _2487 = NOVALUE;
    object _2486 = NOVALUE;
    object _2484 = NOVALUE;
    object _2483 = NOVALUE;
    object _2482 = NOVALUE;
    object _2481 = NOVALUE;
    object _2480 = NOVALUE;
    object _2477 = NOVALUE;
    object _2476 = NOVALUE;
    object _2475 = NOVALUE;
    object _2473 = NOVALUE;
    object _2472 = NOVALUE;
    object _2471 = NOVALUE;
    object _2470 = NOVALUE;
    object _2469 = NOVALUE;
    object _2467 = NOVALUE;
    object _2466 = NOVALUE;
    object _2465 = NOVALUE;
    object _2461 = NOVALUE;
    object _2458 = NOVALUE;
    object _2457 = NOVALUE;
    object _2456 = NOVALUE;
    object _2453 = NOVALUE;
    object _2450 = NOVALUE;
    object _2449 = NOVALUE;
    object _2448 = NOVALUE;
    object _2445 = NOVALUE;
    object _2442 = NOVALUE;
    object _2441 = NOVALUE;
    object _2440 = NOVALUE;
    object _2437 = NOVALUE;
    object _2434 = NOVALUE;
    object _2433 = NOVALUE;
    object _2432 = NOVALUE;
    object _2428 = NOVALUE;
    object _2425 = NOVALUE;
    object _2424 = NOVALUE;
    object _2423 = NOVALUE;
    object _2420 = NOVALUE;
    object _2417 = NOVALUE;
    object _2416 = NOVALUE;
    object _2415 = NOVALUE;
    object _2409 = NOVALUE;
    object _2407 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:1731		if length(source) = 0 then*/
    if (IS_SEQUENCE(_source_4823)){
            _2407 = SEQ_PTR(_source_4823)->length;
    }
    else {
        _2407 = 1;
    }
    if (_2407 != 0LL)
    goto L1; // [8] 19

    /** sequence.e:1732			return source*/
    DeRefDS(_userdata_4825);
    DeRefDS(_rangetype_4826);
    DeRef(_dest_4827);
    return _source_4823;
L1: 

    /** sequence.e:1734		dest = repeat(0, length(source))*/
    if (IS_SEQUENCE(_source_4823)){
            _2409 = SEQ_PTR(_source_4823)->length;
    }
    else {
        _2409 = 1;
    }
    DeRef(_dest_4827);
    _dest_4827 = Repeat(0LL, _2409);
    _2409 = NOVALUE;

    /** sequence.e:1735		idx = 0*/
    _idx_4828 = 0LL;

    /** sequence.e:1736		switch rid do*/
    _1 = find(_rid_4824, _2411);
    switch ( _1 ){ 

        /** sequence.e:1737			case "<", "lt" then*/
        case 1:
        case 2:

        /** sequence.e:1738				for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4823)){
                _2415 = SEQ_PTR(_source_4823)->length;
        }
        else {
            _2415 = 1;
        }
        {
            object _a_4840;
            _a_4840 = 1LL;
L2: 
            if (_a_4840 > _2415){
                goto L3; // [51] 96
            }

            /** sequence.e:1739					if compare(source[a], userdata) < 0 then*/
            _2 = (object)SEQ_PTR(_source_4823);
            _2416 = (object)*(((s1_ptr)_2)->base + _a_4840);
            if (IS_ATOM_INT(_2416) && IS_ATOM_INT(_userdata_4825)){
                _2417 = (_2416 < _userdata_4825) ? -1 : (_2416 > _userdata_4825);
            }
            else{
                _2417 = compare(_2416, _userdata_4825);
            }
            _2416 = NOVALUE;
            if (_2417 >= 0LL)
            goto L4; // [68] 89

            /** sequence.e:1740						idx += 1*/
            _idx_4828 = _idx_4828 + 1;

            /** sequence.e:1741						dest[idx] = source[a]*/
            _2 = (object)SEQ_PTR(_source_4823);
            _2420 = (object)*(((s1_ptr)_2)->base + _a_4840);
            Ref(_2420);
            _2 = (object)SEQ_PTR(_dest_4827);
            _2 = (object)(((s1_ptr)_2)->base + _idx_4828);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _2420;
            if( _1 != _2420 ){
                DeRef(_1);
            }
            _2420 = NOVALUE;
L4: 

            /** sequence.e:1743				end for*/
            _a_4840 = _a_4840 + 1LL;
            goto L2; // [91] 58
L3: 
            ;
        }
        goto L5; // [96] 1304

        /** sequence.e:1745			case "<=", "le" then*/
        case 3:
        case 4:

        /** sequence.e:1746				for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4823)){
                _2423 = SEQ_PTR(_source_4823)->length;
        }
        else {
            _2423 = 1;
        }
        {
            object _a_4852;
            _a_4852 = 1LL;
L6: 
            if (_a_4852 > _2423){
                goto L7; // [109] 154
            }

            /** sequence.e:1747					if compare(source[a], userdata) <= 0 then*/
            _2 = (object)SEQ_PTR(_source_4823);
            _2424 = (object)*(((s1_ptr)_2)->base + _a_4852);
            if (IS_ATOM_INT(_2424) && IS_ATOM_INT(_userdata_4825)){
                _2425 = (_2424 < _userdata_4825) ? -1 : (_2424 > _userdata_4825);
            }
            else{
                _2425 = compare(_2424, _userdata_4825);
            }
            _2424 = NOVALUE;
            if (_2425 > 0LL)
            goto L8; // [126] 147

            /** sequence.e:1748						idx += 1*/
            _idx_4828 = _idx_4828 + 1;

            /** sequence.e:1749						dest[idx] = source[a]*/
            _2 = (object)SEQ_PTR(_source_4823);
            _2428 = (object)*(((s1_ptr)_2)->base + _a_4852);
            Ref(_2428);
            _2 = (object)SEQ_PTR(_dest_4827);
            _2 = (object)(((s1_ptr)_2)->base + _idx_4828);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _2428;
            if( _1 != _2428 ){
                DeRef(_1);
            }
            _2428 = NOVALUE;
L8: 

            /** sequence.e:1751				end for*/
            _a_4852 = _a_4852 + 1LL;
            goto L6; // [149] 116
L7: 
            ;
        }
        goto L5; // [154] 1304

        /** sequence.e:1753			case "=", "==", "eq" then*/
        case 5:
        case 6:
        case 7:

        /** sequence.e:1754				for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4823)){
                _2432 = SEQ_PTR(_source_4823)->length;
        }
        else {
            _2432 = 1;
        }
        {
            object _a_4865;
            _a_4865 = 1LL;
L9: 
            if (_a_4865 > _2432){
                goto LA; // [169] 214
            }

            /** sequence.e:1755					if compare(source[a], userdata) = 0 then*/
            _2 = (object)SEQ_PTR(_source_4823);
            _2433 = (object)*(((s1_ptr)_2)->base + _a_4865);
            if (IS_ATOM_INT(_2433) && IS_ATOM_INT(_userdata_4825)){
                _2434 = (_2433 < _userdata_4825) ? -1 : (_2433 > _userdata_4825);
            }
            else{
                _2434 = compare(_2433, _userdata_4825);
            }
            _2433 = NOVALUE;
            if (_2434 != 0LL)
            goto LB; // [186] 207

            /** sequence.e:1756						idx += 1*/
            _idx_4828 = _idx_4828 + 1;

            /** sequence.e:1757						dest[idx] = source[a]*/
            _2 = (object)SEQ_PTR(_source_4823);
            _2437 = (object)*(((s1_ptr)_2)->base + _a_4865);
            Ref(_2437);
            _2 = (object)SEQ_PTR(_dest_4827);
            _2 = (object)(((s1_ptr)_2)->base + _idx_4828);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _2437;
            if( _1 != _2437 ){
                DeRef(_1);
            }
            _2437 = NOVALUE;
LB: 

            /** sequence.e:1759				end for*/
            _a_4865 = _a_4865 + 1LL;
            goto L9; // [209] 176
LA: 
            ;
        }
        goto L5; // [214] 1304

        /** sequence.e:1761			case "!=", "ne" then*/
        case 8:
        case 9:

        /** sequence.e:1762				for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4823)){
                _2440 = SEQ_PTR(_source_4823)->length;
        }
        else {
            _2440 = 1;
        }
        {
            object _a_4877;
            _a_4877 = 1LL;
LC: 
            if (_a_4877 > _2440){
                goto LD; // [227] 272
            }

            /** sequence.e:1763					if compare(source[a], userdata) != 0 then*/
            _2 = (object)SEQ_PTR(_source_4823);
            _2441 = (object)*(((s1_ptr)_2)->base + _a_4877);
            if (IS_ATOM_INT(_2441) && IS_ATOM_INT(_userdata_4825)){
                _2442 = (_2441 < _userdata_4825) ? -1 : (_2441 > _userdata_4825);
            }
            else{
                _2442 = compare(_2441, _userdata_4825);
            }
            _2441 = NOVALUE;
            if (_2442 == 0LL)
            goto LE; // [244] 265

            /** sequence.e:1764						idx += 1*/
            _idx_4828 = _idx_4828 + 1;

            /** sequence.e:1765						dest[idx] = source[a]*/
            _2 = (object)SEQ_PTR(_source_4823);
            _2445 = (object)*(((s1_ptr)_2)->base + _a_4877);
            Ref(_2445);
            _2 = (object)SEQ_PTR(_dest_4827);
            _2 = (object)(((s1_ptr)_2)->base + _idx_4828);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _2445;
            if( _1 != _2445 ){
                DeRef(_1);
            }
            _2445 = NOVALUE;
LE: 

            /** sequence.e:1767				end for*/
            _a_4877 = _a_4877 + 1LL;
            goto LC; // [267] 234
LD: 
            ;
        }
        goto L5; // [272] 1304

        /** sequence.e:1769			case ">", "gt" then*/
        case 10:
        case 11:

        /** sequence.e:1770				for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4823)){
                _2448 = SEQ_PTR(_source_4823)->length;
        }
        else {
            _2448 = 1;
        }
        {
            object _a_4889;
            _a_4889 = 1LL;
LF: 
            if (_a_4889 > _2448){
                goto L10; // [285] 330
            }

            /** sequence.e:1771					if compare(source[a], userdata) > 0 then*/
            _2 = (object)SEQ_PTR(_source_4823);
            _2449 = (object)*(((s1_ptr)_2)->base + _a_4889);
            if (IS_ATOM_INT(_2449) && IS_ATOM_INT(_userdata_4825)){
                _2450 = (_2449 < _userdata_4825) ? -1 : (_2449 > _userdata_4825);
            }
            else{
                _2450 = compare(_2449, _userdata_4825);
            }
            _2449 = NOVALUE;
            if (_2450 <= 0LL)
            goto L11; // [302] 323

            /** sequence.e:1772						idx += 1*/
            _idx_4828 = _idx_4828 + 1;

            /** sequence.e:1773						dest[idx] = source[a]*/
            _2 = (object)SEQ_PTR(_source_4823);
            _2453 = (object)*(((s1_ptr)_2)->base + _a_4889);
            Ref(_2453);
            _2 = (object)SEQ_PTR(_dest_4827);
            _2 = (object)(((s1_ptr)_2)->base + _idx_4828);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _2453;
            if( _1 != _2453 ){
                DeRef(_1);
            }
            _2453 = NOVALUE;
L11: 

            /** sequence.e:1775				end for*/
            _a_4889 = _a_4889 + 1LL;
            goto LF; // [325] 292
L10: 
            ;
        }
        goto L5; // [330] 1304

        /** sequence.e:1777			case ">=", "ge" then*/
        case 12:
        case 13:

        /** sequence.e:1778				for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4823)){
                _2456 = SEQ_PTR(_source_4823)->length;
        }
        else {
            _2456 = 1;
        }
        {
            object _a_4901;
            _a_4901 = 1LL;
L12: 
            if (_a_4901 > _2456){
                goto L13; // [343] 388
            }

            /** sequence.e:1779					if compare(source[a], userdata) >= 0 then*/
            _2 = (object)SEQ_PTR(_source_4823);
            _2457 = (object)*(((s1_ptr)_2)->base + _a_4901);
            if (IS_ATOM_INT(_2457) && IS_ATOM_INT(_userdata_4825)){
                _2458 = (_2457 < _userdata_4825) ? -1 : (_2457 > _userdata_4825);
            }
            else{
                _2458 = compare(_2457, _userdata_4825);
            }
            _2457 = NOVALUE;
            if (_2458 < 0LL)
            goto L14; // [360] 381

            /** sequence.e:1780						idx += 1*/
            _idx_4828 = _idx_4828 + 1;

            /** sequence.e:1781						dest[idx] = source[a]*/
            _2 = (object)SEQ_PTR(_source_4823);
            _2461 = (object)*(((s1_ptr)_2)->base + _a_4901);
            Ref(_2461);
            _2 = (object)SEQ_PTR(_dest_4827);
            _2 = (object)(((s1_ptr)_2)->base + _idx_4828);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _2461;
            if( _1 != _2461 ){
                DeRef(_1);
            }
            _2461 = NOVALUE;
L14: 

            /** sequence.e:1783				end for*/
            _a_4901 = _a_4901 + 1LL;
            goto L12; // [383] 350
L13: 
            ;
        }
        goto L5; // [388] 1304

        /** sequence.e:1785			case "in" then*/
        case 14:

        /** sequence.e:1786				switch rangetype do*/
        _1 = find(_rangetype_4826, _2463);
        switch ( _1 ){ 

            /** sequence.e:1787					case "" then*/
            case 1:

            /** sequence.e:1788						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4823)){
                    _2465 = SEQ_PTR(_source_4823)->length;
            }
            else {
                _2465 = 1;
            }
            {
                object _a_4915;
                _a_4915 = 1LL;
L15: 
                if (_a_4915 > _2465){
                    goto L16; // [410] 455
                }

                /** sequence.e:1789							if find(source[a], userdata)  then*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2466 = (object)*(((s1_ptr)_2)->base + _a_4915);
                _2467 = find_from(_2466, _userdata_4825, 1LL);
                _2466 = NOVALUE;
                if (_2467 == 0)
                {
                    _2467 = NOVALUE;
                    goto L17; // [428] 448
                }
                else{
                    _2467 = NOVALUE;
                }

                /** sequence.e:1790								idx += 1*/
                _idx_4828 = _idx_4828 + 1;

                /** sequence.e:1791								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2469 = (object)*(((s1_ptr)_2)->base + _a_4915);
                Ref(_2469);
                _2 = (object)SEQ_PTR(_dest_4827);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4828);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2469;
                if( _1 != _2469 ){
                    DeRef(_1);
                }
                _2469 = NOVALUE;
L17: 

                /** sequence.e:1793						end for*/
                _a_4915 = _a_4915 + 1LL;
                goto L15; // [450] 417
L16: 
                ;
            }
            goto L5; // [455] 1304

            /** sequence.e:1795					case "[]" then*/
            case 2:

            /** sequence.e:1796						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4823)){
                    _2470 = SEQ_PTR(_source_4823)->length;
            }
            else {
                _2470 = 1;
            }
            {
                object _a_4924;
                _a_4924 = 1LL;
L18: 
                if (_a_4924 > _2470){
                    goto L19; // [466] 534
                }

                /** sequence.e:1797							if compare(source[a], userdata[1]) >= 0 then*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2471 = (object)*(((s1_ptr)_2)->base + _a_4924);
                _2 = (object)SEQ_PTR(_userdata_4825);
                _2472 = (object)*(((s1_ptr)_2)->base + 1LL);
                if (IS_ATOM_INT(_2471) && IS_ATOM_INT(_2472)){
                    _2473 = (_2471 < _2472) ? -1 : (_2471 > _2472);
                }
                else{
                    _2473 = compare(_2471, _2472);
                }
                _2471 = NOVALUE;
                _2472 = NOVALUE;
                if (_2473 < 0LL)
                goto L1A; // [487] 527

                /** sequence.e:1798								if compare(source[a], userdata[2]) <= 0 then*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2475 = (object)*(((s1_ptr)_2)->base + _a_4924);
                _2 = (object)SEQ_PTR(_userdata_4825);
                _2476 = (object)*(((s1_ptr)_2)->base + 2LL);
                if (IS_ATOM_INT(_2475) && IS_ATOM_INT(_2476)){
                    _2477 = (_2475 < _2476) ? -1 : (_2475 > _2476);
                }
                else{
                    _2477 = compare(_2475, _2476);
                }
                _2475 = NOVALUE;
                _2476 = NOVALUE;
                if (_2477 > 0LL)
                goto L1B; // [505] 526

                /** sequence.e:1799									idx += 1*/
                _idx_4828 = _idx_4828 + 1;

                /** sequence.e:1800									dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2480 = (object)*(((s1_ptr)_2)->base + _a_4924);
                Ref(_2480);
                _2 = (object)SEQ_PTR(_dest_4827);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4828);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2480;
                if( _1 != _2480 ){
                    DeRef(_1);
                }
                _2480 = NOVALUE;
L1B: 
L1A: 

                /** sequence.e:1803						end for*/
                _a_4924 = _a_4924 + 1LL;
                goto L18; // [529] 473
L19: 
                ;
            }
            goto L5; // [534] 1304

            /** sequence.e:1805					case "[)" then*/
            case 3:

            /** sequence.e:1806						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4823)){
                    _2481 = SEQ_PTR(_source_4823)->length;
            }
            else {
                _2481 = 1;
            }
            {
                object _a_4940;
                _a_4940 = 1LL;
L1C: 
                if (_a_4940 > _2481){
                    goto L1D; // [545] 613
                }

                /** sequence.e:1807							if compare(source[a], userdata[1]) >= 0 then*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2482 = (object)*(((s1_ptr)_2)->base + _a_4940);
                _2 = (object)SEQ_PTR(_userdata_4825);
                _2483 = (object)*(((s1_ptr)_2)->base + 1LL);
                if (IS_ATOM_INT(_2482) && IS_ATOM_INT(_2483)){
                    _2484 = (_2482 < _2483) ? -1 : (_2482 > _2483);
                }
                else{
                    _2484 = compare(_2482, _2483);
                }
                _2482 = NOVALUE;
                _2483 = NOVALUE;
                if (_2484 < 0LL)
                goto L1E; // [566] 606

                /** sequence.e:1808								if compare(source[a], userdata[2]) < 0 then*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2486 = (object)*(((s1_ptr)_2)->base + _a_4940);
                _2 = (object)SEQ_PTR(_userdata_4825);
                _2487 = (object)*(((s1_ptr)_2)->base + 2LL);
                if (IS_ATOM_INT(_2486) && IS_ATOM_INT(_2487)){
                    _2488 = (_2486 < _2487) ? -1 : (_2486 > _2487);
                }
                else{
                    _2488 = compare(_2486, _2487);
                }
                _2486 = NOVALUE;
                _2487 = NOVALUE;
                if (_2488 >= 0LL)
                goto L1F; // [584] 605

                /** sequence.e:1809									idx += 1*/
                _idx_4828 = _idx_4828 + 1;

                /** sequence.e:1810									dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2491 = (object)*(((s1_ptr)_2)->base + _a_4940);
                Ref(_2491);
                _2 = (object)SEQ_PTR(_dest_4827);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4828);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2491;
                if( _1 != _2491 ){
                    DeRef(_1);
                }
                _2491 = NOVALUE;
L1F: 
L1E: 

                /** sequence.e:1813						end for*/
                _a_4940 = _a_4940 + 1LL;
                goto L1C; // [608] 552
L1D: 
                ;
            }
            goto L5; // [613] 1304

            /** sequence.e:1814					case "(]" then*/
            case 4:

            /** sequence.e:1815						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4823)){
                    _2492 = SEQ_PTR(_source_4823)->length;
            }
            else {
                _2492 = 1;
            }
            {
                object _a_4956;
                _a_4956 = 1LL;
L20: 
                if (_a_4956 > _2492){
                    goto L21; // [624] 692
                }

                /** sequence.e:1816							if compare(source[a], userdata[1]) > 0 then*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2493 = (object)*(((s1_ptr)_2)->base + _a_4956);
                _2 = (object)SEQ_PTR(_userdata_4825);
                _2494 = (object)*(((s1_ptr)_2)->base + 1LL);
                if (IS_ATOM_INT(_2493) && IS_ATOM_INT(_2494)){
                    _2495 = (_2493 < _2494) ? -1 : (_2493 > _2494);
                }
                else{
                    _2495 = compare(_2493, _2494);
                }
                _2493 = NOVALUE;
                _2494 = NOVALUE;
                if (_2495 <= 0LL)
                goto L22; // [645] 685

                /** sequence.e:1817								if compare(source[a], userdata[2]) <= 0 then*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2497 = (object)*(((s1_ptr)_2)->base + _a_4956);
                _2 = (object)SEQ_PTR(_userdata_4825);
                _2498 = (object)*(((s1_ptr)_2)->base + 2LL);
                if (IS_ATOM_INT(_2497) && IS_ATOM_INT(_2498)){
                    _2499 = (_2497 < _2498) ? -1 : (_2497 > _2498);
                }
                else{
                    _2499 = compare(_2497, _2498);
                }
                _2497 = NOVALUE;
                _2498 = NOVALUE;
                if (_2499 > 0LL)
                goto L23; // [663] 684

                /** sequence.e:1818									idx += 1*/
                _idx_4828 = _idx_4828 + 1;

                /** sequence.e:1819									dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2502 = (object)*(((s1_ptr)_2)->base + _a_4956);
                Ref(_2502);
                _2 = (object)SEQ_PTR(_dest_4827);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4828);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2502;
                if( _1 != _2502 ){
                    DeRef(_1);
                }
                _2502 = NOVALUE;
L23: 
L22: 

                /** sequence.e:1822						end for*/
                _a_4956 = _a_4956 + 1LL;
                goto L20; // [687] 631
L21: 
                ;
            }
            goto L5; // [692] 1304

            /** sequence.e:1823					case "()" then*/
            case 5:

            /** sequence.e:1824						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4823)){
                    _2503 = SEQ_PTR(_source_4823)->length;
            }
            else {
                _2503 = 1;
            }
            {
                object _a_4972;
                _a_4972 = 1LL;
L24: 
                if (_a_4972 > _2503){
                    goto L25; // [703] 771
                }

                /** sequence.e:1825							if compare(source[a], userdata[1]) > 0 then*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2504 = (object)*(((s1_ptr)_2)->base + _a_4972);
                _2 = (object)SEQ_PTR(_userdata_4825);
                _2505 = (object)*(((s1_ptr)_2)->base + 1LL);
                if (IS_ATOM_INT(_2504) && IS_ATOM_INT(_2505)){
                    _2506 = (_2504 < _2505) ? -1 : (_2504 > _2505);
                }
                else{
                    _2506 = compare(_2504, _2505);
                }
                _2504 = NOVALUE;
                _2505 = NOVALUE;
                if (_2506 <= 0LL)
                goto L26; // [724] 764

                /** sequence.e:1826								if compare(source[a], userdata[2]) < 0 then*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2508 = (object)*(((s1_ptr)_2)->base + _a_4972);
                _2 = (object)SEQ_PTR(_userdata_4825);
                _2509 = (object)*(((s1_ptr)_2)->base + 2LL);
                if (IS_ATOM_INT(_2508) && IS_ATOM_INT(_2509)){
                    _2510 = (_2508 < _2509) ? -1 : (_2508 > _2509);
                }
                else{
                    _2510 = compare(_2508, _2509);
                }
                _2508 = NOVALUE;
                _2509 = NOVALUE;
                if (_2510 >= 0LL)
                goto L27; // [742] 763

                /** sequence.e:1827									idx += 1*/
                _idx_4828 = _idx_4828 + 1;

                /** sequence.e:1828									dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2513 = (object)*(((s1_ptr)_2)->base + _a_4972);
                Ref(_2513);
                _2 = (object)SEQ_PTR(_dest_4827);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4828);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2513;
                if( _1 != _2513 ){
                    DeRef(_1);
                }
                _2513 = NOVALUE;
L27: 
L26: 

                /** sequence.e:1831						end for*/
                _a_4972 = _a_4972 + 1LL;
                goto L24; // [766] 710
L25: 
                ;
            }
            goto L5; // [771] 1304

            /** sequence.e:1833					case else*/
            case 0:
        ;}        goto L5; // [778] 1304

        /** sequence.e:1838			case "out" then*/
        case 15:

        /** sequence.e:1839				switch rangetype do*/
        _1 = find(_rangetype_4826, _2515);
        switch ( _1 ){ 

            /** sequence.e:1840					case "" then*/
            case 1:

            /** sequence.e:1841						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4823)){
                    _2517 = SEQ_PTR(_source_4823)->length;
            }
            else {
                _2517 = 1;
            }
            {
                object _a_4993;
                _a_4993 = 1LL;
L28: 
                if (_a_4993 > _2517){
                    goto L29; // [800] 845
                }

                /** sequence.e:1842							if not find(source[a], userdata)  then*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2518 = (object)*(((s1_ptr)_2)->base + _a_4993);
                _2519 = find_from(_2518, _userdata_4825, 1LL);
                _2518 = NOVALUE;
                if (_2519 != 0)
                goto L2A; // [818] 838
                _2519 = NOVALUE;

                /** sequence.e:1843								idx += 1*/
                _idx_4828 = _idx_4828 + 1;

                /** sequence.e:1844								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2522 = (object)*(((s1_ptr)_2)->base + _a_4993);
                Ref(_2522);
                _2 = (object)SEQ_PTR(_dest_4827);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4828);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2522;
                if( _1 != _2522 ){
                    DeRef(_1);
                }
                _2522 = NOVALUE;
L2A: 

                /** sequence.e:1846						end for*/
                _a_4993 = _a_4993 + 1LL;
                goto L28; // [840] 807
L29: 
                ;
            }
            goto L5; // [845] 1304

            /** sequence.e:1848					case "[]" then*/
            case 2:

            /** sequence.e:1849						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4823)){
                    _2523 = SEQ_PTR(_source_4823)->length;
            }
            else {
                _2523 = 1;
            }
            {
                object _a_5003;
                _a_5003 = 1LL;
L2B: 
                if (_a_5003 > _2523){
                    goto L2C; // [856] 943
                }

                /** sequence.e:1850							if compare(source[a], userdata[1]) < 0 then*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2524 = (object)*(((s1_ptr)_2)->base + _a_5003);
                _2 = (object)SEQ_PTR(_userdata_4825);
                _2525 = (object)*(((s1_ptr)_2)->base + 1LL);
                if (IS_ATOM_INT(_2524) && IS_ATOM_INT(_2525)){
                    _2526 = (_2524 < _2525) ? -1 : (_2524 > _2525);
                }
                else{
                    _2526 = compare(_2524, _2525);
                }
                _2524 = NOVALUE;
                _2525 = NOVALUE;
                if (_2526 >= 0LL)
                goto L2D; // [877] 900

                /** sequence.e:1851								idx += 1*/
                _idx_4828 = _idx_4828 + 1;

                /** sequence.e:1852								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2529 = (object)*(((s1_ptr)_2)->base + _a_5003);
                Ref(_2529);
                _2 = (object)SEQ_PTR(_dest_4827);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4828);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2529;
                if( _1 != _2529 ){
                    DeRef(_1);
                }
                _2529 = NOVALUE;
                goto L2E; // [897] 936
L2D: 

                /** sequence.e:1853							elsif compare(source[a], userdata[2]) > 0 then*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2530 = (object)*(((s1_ptr)_2)->base + _a_5003);
                _2 = (object)SEQ_PTR(_userdata_4825);
                _2531 = (object)*(((s1_ptr)_2)->base + 2LL);
                if (IS_ATOM_INT(_2530) && IS_ATOM_INT(_2531)){
                    _2532 = (_2530 < _2531) ? -1 : (_2530 > _2531);
                }
                else{
                    _2532 = compare(_2530, _2531);
                }
                _2530 = NOVALUE;
                _2531 = NOVALUE;
                if (_2532 <= 0LL)
                goto L2F; // [914] 935

                /** sequence.e:1854								idx += 1*/
                _idx_4828 = _idx_4828 + 1;

                /** sequence.e:1855								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2535 = (object)*(((s1_ptr)_2)->base + _a_5003);
                Ref(_2535);
                _2 = (object)SEQ_PTR(_dest_4827);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4828);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2535;
                if( _1 != _2535 ){
                    DeRef(_1);
                }
                _2535 = NOVALUE;
L2F: 
L2E: 

                /** sequence.e:1857						end for*/
                _a_5003 = _a_5003 + 1LL;
                goto L2B; // [938] 863
L2C: 
                ;
            }
            goto L5; // [943] 1304

            /** sequence.e:1859					case "[)" then*/
            case 3:

            /** sequence.e:1860						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4823)){
                    _2536 = SEQ_PTR(_source_4823)->length;
            }
            else {
                _2536 = 1;
            }
            {
                object _a_5021;
                _a_5021 = 1LL;
L30: 
                if (_a_5021 > _2536){
                    goto L31; // [954] 1041
                }

                /** sequence.e:1861							if compare(source[a], userdata[1]) < 0 then*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2537 = (object)*(((s1_ptr)_2)->base + _a_5021);
                _2 = (object)SEQ_PTR(_userdata_4825);
                _2538 = (object)*(((s1_ptr)_2)->base + 1LL);
                if (IS_ATOM_INT(_2537) && IS_ATOM_INT(_2538)){
                    _2539 = (_2537 < _2538) ? -1 : (_2537 > _2538);
                }
                else{
                    _2539 = compare(_2537, _2538);
                }
                _2537 = NOVALUE;
                _2538 = NOVALUE;
                if (_2539 >= 0LL)
                goto L32; // [975] 998

                /** sequence.e:1862								idx += 1*/
                _idx_4828 = _idx_4828 + 1;

                /** sequence.e:1863								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2542 = (object)*(((s1_ptr)_2)->base + _a_5021);
                Ref(_2542);
                _2 = (object)SEQ_PTR(_dest_4827);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4828);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2542;
                if( _1 != _2542 ){
                    DeRef(_1);
                }
                _2542 = NOVALUE;
                goto L33; // [995] 1034
L32: 

                /** sequence.e:1864							elsif compare(source[a], userdata[2]) >= 0 then*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2543 = (object)*(((s1_ptr)_2)->base + _a_5021);
                _2 = (object)SEQ_PTR(_userdata_4825);
                _2544 = (object)*(((s1_ptr)_2)->base + 2LL);
                if (IS_ATOM_INT(_2543) && IS_ATOM_INT(_2544)){
                    _2545 = (_2543 < _2544) ? -1 : (_2543 > _2544);
                }
                else{
                    _2545 = compare(_2543, _2544);
                }
                _2543 = NOVALUE;
                _2544 = NOVALUE;
                if (_2545 < 0LL)
                goto L34; // [1012] 1033

                /** sequence.e:1865								idx += 1*/
                _idx_4828 = _idx_4828 + 1;

                /** sequence.e:1866								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2548 = (object)*(((s1_ptr)_2)->base + _a_5021);
                Ref(_2548);
                _2 = (object)SEQ_PTR(_dest_4827);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4828);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2548;
                if( _1 != _2548 ){
                    DeRef(_1);
                }
                _2548 = NOVALUE;
L34: 
L33: 

                /** sequence.e:1868						end for*/
                _a_5021 = _a_5021 + 1LL;
                goto L30; // [1036] 961
L31: 
                ;
            }
            goto L5; // [1041] 1304

            /** sequence.e:1869					case "(]" then*/
            case 4:

            /** sequence.e:1870						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4823)){
                    _2549 = SEQ_PTR(_source_4823)->length;
            }
            else {
                _2549 = 1;
            }
            {
                object _a_5039;
                _a_5039 = 1LL;
L35: 
                if (_a_5039 > _2549){
                    goto L36; // [1052] 1139
                }

                /** sequence.e:1871							if compare(source[a], userdata[1]) <= 0 then*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2550 = (object)*(((s1_ptr)_2)->base + _a_5039);
                _2 = (object)SEQ_PTR(_userdata_4825);
                _2551 = (object)*(((s1_ptr)_2)->base + 1LL);
                if (IS_ATOM_INT(_2550) && IS_ATOM_INT(_2551)){
                    _2552 = (_2550 < _2551) ? -1 : (_2550 > _2551);
                }
                else{
                    _2552 = compare(_2550, _2551);
                }
                _2550 = NOVALUE;
                _2551 = NOVALUE;
                if (_2552 > 0LL)
                goto L37; // [1073] 1096

                /** sequence.e:1872								idx += 1*/
                _idx_4828 = _idx_4828 + 1;

                /** sequence.e:1873								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2555 = (object)*(((s1_ptr)_2)->base + _a_5039);
                Ref(_2555);
                _2 = (object)SEQ_PTR(_dest_4827);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4828);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2555;
                if( _1 != _2555 ){
                    DeRef(_1);
                }
                _2555 = NOVALUE;
                goto L38; // [1093] 1132
L37: 

                /** sequence.e:1874							elsif compare(source[a], userdata[2]) > 0 then*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2556 = (object)*(((s1_ptr)_2)->base + _a_5039);
                _2 = (object)SEQ_PTR(_userdata_4825);
                _2557 = (object)*(((s1_ptr)_2)->base + 2LL);
                if (IS_ATOM_INT(_2556) && IS_ATOM_INT(_2557)){
                    _2558 = (_2556 < _2557) ? -1 : (_2556 > _2557);
                }
                else{
                    _2558 = compare(_2556, _2557);
                }
                _2556 = NOVALUE;
                _2557 = NOVALUE;
                if (_2558 <= 0LL)
                goto L39; // [1110] 1131

                /** sequence.e:1875								idx += 1*/
                _idx_4828 = _idx_4828 + 1;

                /** sequence.e:1876								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2561 = (object)*(((s1_ptr)_2)->base + _a_5039);
                Ref(_2561);
                _2 = (object)SEQ_PTR(_dest_4827);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4828);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2561;
                if( _1 != _2561 ){
                    DeRef(_1);
                }
                _2561 = NOVALUE;
L39: 
L38: 

                /** sequence.e:1878						end for*/
                _a_5039 = _a_5039 + 1LL;
                goto L35; // [1134] 1059
L36: 
                ;
            }
            goto L5; // [1139] 1304

            /** sequence.e:1879					case "()" then*/
            case 5:

            /** sequence.e:1880						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4823)){
                    _2562 = SEQ_PTR(_source_4823)->length;
            }
            else {
                _2562 = 1;
            }
            {
                object _a_5057;
                _a_5057 = 1LL;
L3A: 
                if (_a_5057 > _2562){
                    goto L3B; // [1150] 1237
                }

                /** sequence.e:1881							if compare(source[a], userdata[1]) <= 0 then*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2563 = (object)*(((s1_ptr)_2)->base + _a_5057);
                _2 = (object)SEQ_PTR(_userdata_4825);
                _2564 = (object)*(((s1_ptr)_2)->base + 1LL);
                if (IS_ATOM_INT(_2563) && IS_ATOM_INT(_2564)){
                    _2565 = (_2563 < _2564) ? -1 : (_2563 > _2564);
                }
                else{
                    _2565 = compare(_2563, _2564);
                }
                _2563 = NOVALUE;
                _2564 = NOVALUE;
                if (_2565 > 0LL)
                goto L3C; // [1171] 1194

                /** sequence.e:1882								idx += 1*/
                _idx_4828 = _idx_4828 + 1;

                /** sequence.e:1883								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2568 = (object)*(((s1_ptr)_2)->base + _a_5057);
                Ref(_2568);
                _2 = (object)SEQ_PTR(_dest_4827);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4828);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2568;
                if( _1 != _2568 ){
                    DeRef(_1);
                }
                _2568 = NOVALUE;
                goto L3D; // [1191] 1230
L3C: 

                /** sequence.e:1884							elsif compare(source[a], userdata[2]) >= 0 then*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2569 = (object)*(((s1_ptr)_2)->base + _a_5057);
                _2 = (object)SEQ_PTR(_userdata_4825);
                _2570 = (object)*(((s1_ptr)_2)->base + 2LL);
                if (IS_ATOM_INT(_2569) && IS_ATOM_INT(_2570)){
                    _2571 = (_2569 < _2570) ? -1 : (_2569 > _2570);
                }
                else{
                    _2571 = compare(_2569, _2570);
                }
                _2569 = NOVALUE;
                _2570 = NOVALUE;
                if (_2571 < 0LL)
                goto L3E; // [1208] 1229

                /** sequence.e:1885								idx += 1*/
                _idx_4828 = _idx_4828 + 1;

                /** sequence.e:1886								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4823);
                _2574 = (object)*(((s1_ptr)_2)->base + _a_5057);
                Ref(_2574);
                _2 = (object)SEQ_PTR(_dest_4827);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4828);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2574;
                if( _1 != _2574 ){
                    DeRef(_1);
                }
                _2574 = NOVALUE;
L3E: 
L3D: 

                /** sequence.e:1888						end for*/
                _a_5057 = _a_5057 + 1LL;
                goto L3A; // [1232] 1157
L3B: 
                ;
            }
            goto L5; // [1237] 1304

            /** sequence.e:1889					case else*/
            case 0:
        ;}        goto L5; // [1244] 1304

        /** sequence.e:1894			case else*/
        case 0:

        /** sequence.e:1895				for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4823)){
                _2575 = SEQ_PTR(_source_4823)->length;
        }
        else {
            _2575 = 1;
        }
        {
            object _a_5076;
            _a_5076 = 1LL;
L3F: 
            if (_a_5076 > _2575){
                goto L40; // [1255] 1303
            }

            /** sequence.e:1896					if call_func(rid, {source[a], userdata}) then*/
            _2 = (object)SEQ_PTR(_source_4823);
            _2576 = (object)*(((s1_ptr)_2)->base + _a_5076);
            Ref(_userdata_4825);
            Ref(_2576);
            _1 = NewS1(2);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t *)_2)[1] = _2576;
            ((intptr_t *)_2)[2] = _userdata_4825;
            _2577 = MAKE_SEQ(_1);
            _2576 = NOVALUE;
            _1 = (object)SEQ_PTR(_2577);
            _2 = (object)((s1_ptr)_1)->base;
            _0 = (object)_00[_rid_4824].addr;
            Ref( *(( (intptr_t*)_2) + 1) );
            Ref( *(( (intptr_t*)_2) + 2) );
            _1 = (*(intptr_t (*)())_0)(
                                *( ((intptr_t *)_2) + 1), 
                                *( ((intptr_t *)_2) + 2)
                                 );
            DeRef(_2578);
            _2578 = _1;
            DeRefDS(_2577);
            _2577 = NOVALUE;
            if (_2578 == 0) {
                DeRef(_2578);
                _2578 = NOVALUE;
                goto L41; // [1276] 1296
            }
            else {
                if (!IS_ATOM_INT(_2578) && DBL_PTR(_2578)->dbl == 0.0){
                    DeRef(_2578);
                    _2578 = NOVALUE;
                    goto L41; // [1276] 1296
                }
                DeRef(_2578);
                _2578 = NOVALUE;
            }
            DeRef(_2578);
            _2578 = NOVALUE;

            /** sequence.e:1897						idx += 1*/
            _idx_4828 = _idx_4828 + 1;

            /** sequence.e:1898						dest[idx] = source[a]*/
            _2 = (object)SEQ_PTR(_source_4823);
            _2580 = (object)*(((s1_ptr)_2)->base + _a_5076);
            Ref(_2580);
            _2 = (object)SEQ_PTR(_dest_4827);
            _2 = (object)(((s1_ptr)_2)->base + _idx_4828);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _2580;
            if( _1 != _2580 ){
                DeRef(_1);
            }
            _2580 = NOVALUE;
L41: 

            /** sequence.e:1900				end for*/
            _a_5076 = _a_5076 + 1LL;
            goto L3F; // [1298] 1262
L40: 
            ;
        }
    ;}L5: 

    /** sequence.e:1902		return dest[1..idx]*/
    rhs_slice_target = (object_ptr)&_2581;
    RHS_Slice(_dest_4827, 1LL, _idx_4828);
    DeRefDS(_source_4823);
    DeRef(_userdata_4825);
    DeRef(_rangetype_4826);
    DeRefDS(_dest_4827);
    return _2581;
    ;
}


object _23filter_alpha(object _elem_5088, object _ud_5089)
{
    object _2582 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:1907		return t_alpha(elem)*/
    Ref(_elem_5088);
    _2582 = _13t_alpha(_elem_5088);
    DeRef(_elem_5088);
    return _2582;
    ;
}


object _23split(object _st_5133, object _delim_5134, object _no_empty_5135, object _limit_5136)
{
    object _ret_5137 = NOVALUE;
    object _start_5138 = NOVALUE;
    object _pos_5139 = NOVALUE;
    object _k_5191 = NOVALUE;
    object _2650 = NOVALUE;
    object _2648 = NOVALUE;
    object _2647 = NOVALUE;
    object _2643 = NOVALUE;
    object _2642 = NOVALUE;
    object _2641 = NOVALUE;
    object _2638 = NOVALUE;
    object _2637 = NOVALUE;
    object _2632 = NOVALUE;
    object _2631 = NOVALUE;
    object _2627 = NOVALUE;
    object _2623 = NOVALUE;
    object _2621 = NOVALUE;
    object _2620 = NOVALUE;
    object _2616 = NOVALUE;
    object _2614 = NOVALUE;
    object _2613 = NOVALUE;
    object _2612 = NOVALUE;
    object _2611 = NOVALUE;
    object _2608 = NOVALUE;
    object _2607 = NOVALUE;
    object _2606 = NOVALUE;
    object _2605 = NOVALUE;
    object _2604 = NOVALUE;
    object _2602 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:2088		sequence ret = {}*/
    RefDS(_5);
    DeRef(_ret_5137);
    _ret_5137 = _5;

    /** sequence.e:2092		if length(st) = 0 then*/
    if (IS_SEQUENCE(_st_5133)){
            _2602 = SEQ_PTR(_st_5133)->length;
    }
    else {
        _2602 = 1;
    }
    if (_2602 != 0LL)
    goto L1; // [19] 30

    /** sequence.e:2093			return ret*/
    DeRefDS(_st_5133);
    DeRefi(_delim_5134);
    return _ret_5137;
L1: 

    /** sequence.e:2097		if sequence(delim) then*/
    _2604 = IS_SEQUENCE(_delim_5134);
    if (_2604 == 0)
    {
        _2604 = NOVALUE;
        goto L2; // [35] 211
    }
    else{
        _2604 = NOVALUE;
    }

    /** sequence.e:2099			if equal(delim, "") then*/
    if (_delim_5134 == _5)
    _2605 = 1;
    else if (IS_ATOM_INT(_delim_5134) && IS_ATOM_INT(_5))
    _2605 = 0;
    else
    _2605 = (compare(_delim_5134, _5) == 0);
    if (_2605 == 0)
    {
        _2605 = NOVALUE;
        goto L3; // [44] 127
    }
    else{
        _2605 = NOVALUE;
    }

    /** sequence.e:2100				for i = 1 to length(st) do*/
    if (IS_SEQUENCE(_st_5133)){
            _2606 = SEQ_PTR(_st_5133)->length;
    }
    else {
        _2606 = 1;
    }
    {
        object _i_5148;
        _i_5148 = 1LL;
L4: 
        if (_i_5148 > _2606){
            goto L5; // [52] 120
        }

        /** sequence.e:2101					st[i] = {st[i]}*/
        _2 = (object)SEQ_PTR(_st_5133);
        _2607 = (object)*(((s1_ptr)_2)->base + _i_5148);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_2607);
        ((intptr_t*)_2)[1] = _2607;
        _2608 = MAKE_SEQ(_1);
        _2607 = NOVALUE;
        _2 = (object)SEQ_PTR(_st_5133);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _st_5133 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_5148);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _2608;
        if( _1 != _2608 ){
            DeRef(_1);
        }
        _2608 = NOVALUE;

        /** sequence.e:2102					limit -= 1*/
        _limit_5136 = _limit_5136 - 1LL;

        /** sequence.e:2103					if limit = 0 then*/
        if (_limit_5136 != 0LL)
        goto L6; // [81] 113

        /** sequence.e:2104						st = append(st[1 .. i],st[i+1 .. $])*/
        rhs_slice_target = (object_ptr)&_2611;
        RHS_Slice(_st_5133, 1LL, _i_5148);
        _2612 = _i_5148 + 1;
        if (IS_SEQUENCE(_st_5133)){
                _2613 = SEQ_PTR(_st_5133)->length;
        }
        else {
            _2613 = 1;
        }
        rhs_slice_target = (object_ptr)&_2614;
        RHS_Slice(_st_5133, _2612, _2613);
        RefDS(_2614);
        Append(&_st_5133, _2611, _2614);
        DeRefDS(_2611);
        _2611 = NOVALUE;
        DeRefDS(_2614);
        _2614 = NOVALUE;

        /** sequence.e:2105						exit*/
        goto L5; // [110] 120
L6: 

        /** sequence.e:2107				end for*/
        _i_5148 = _i_5148 + 1LL;
        goto L4; // [115] 59
L5: 
        ;
    }

    /** sequence.e:2109				return st*/
    DeRefi(_delim_5134);
    DeRef(_ret_5137);
    DeRef(_2612);
    _2612 = NOVALUE;
    return _st_5133;
L3: 

    /** sequence.e:2112			start = 1*/
    _start_5138 = 1LL;

    /** sequence.e:2113			while start <= length(st) do*/
L7: 
    if (IS_SEQUENCE(_st_5133)){
            _2616 = SEQ_PTR(_st_5133)->length;
    }
    else {
        _2616 = 1;
    }
    if (_start_5138 > _2616)
    goto L8; // [140] 290

    /** sequence.e:2114				pos = match(delim, st, start)*/
    _pos_5139 = e_match_from(_delim_5134, _st_5133, _start_5138);

    /** sequence.e:2116				if pos = 0 then*/
    if (_pos_5139 != 0LL)
    goto L9; // [153] 162

    /** sequence.e:2117					exit*/
    goto L8; // [159] 290
L9: 

    /** sequence.e:2120				ret = append(ret, st[start..pos-1])*/
    _2620 = _pos_5139 - 1LL;
    rhs_slice_target = (object_ptr)&_2621;
    RHS_Slice(_st_5133, _start_5138, _2620);
    RefDS(_2621);
    Append(&_ret_5137, _ret_5137, _2621);
    DeRefDS(_2621);
    _2621 = NOVALUE;

    /** sequence.e:2121				start = pos+length(delim)*/
    if (IS_SEQUENCE(_delim_5134)){
            _2623 = SEQ_PTR(_delim_5134)->length;
    }
    else {
        _2623 = 1;
    }
    _start_5138 = _pos_5139 + _2623;
    _2623 = NOVALUE;

    /** sequence.e:2122				limit -= 1*/
    _limit_5136 = _limit_5136 - 1LL;

    /** sequence.e:2123				if limit = 0 then*/
    if (_limit_5136 != 0LL)
    goto L7; // [194] 137

    /** sequence.e:2124					exit*/
    goto L8; // [200] 290

    /** sequence.e:2126			end while*/
    goto L7; // [205] 137
    goto L8; // [208] 290
L2: 

    /** sequence.e:2128			start = 1*/
    _start_5138 = 1LL;

    /** sequence.e:2129			while start <= length(st) do*/
LA: 
    if (IS_SEQUENCE(_st_5133)){
            _2627 = SEQ_PTR(_st_5133)->length;
    }
    else {
        _2627 = 1;
    }
    if (_start_5138 > _2627)
    goto LB; // [224] 289

    /** sequence.e:2130				pos = find(delim, st, start)*/
    _pos_5139 = find_from(_delim_5134, _st_5133, _start_5138);

    /** sequence.e:2132				if pos = 0 then*/
    if (_pos_5139 != 0LL)
    goto LC; // [237] 246

    /** sequence.e:2133					exit*/
    goto LB; // [243] 289
LC: 

    /** sequence.e:2136				ret = append(ret, st[start..pos-1])*/
    _2631 = _pos_5139 - 1LL;
    rhs_slice_target = (object_ptr)&_2632;
    RHS_Slice(_st_5133, _start_5138, _2631);
    RefDS(_2632);
    Append(&_ret_5137, _ret_5137, _2632);
    DeRefDS(_2632);
    _2632 = NOVALUE;

    /** sequence.e:2137				start = pos + 1*/
    _start_5138 = _pos_5139 + 1;

    /** sequence.e:2138				limit -= 1*/
    _limit_5136 = _limit_5136 - 1LL;

    /** sequence.e:2139				if limit = 0 then*/
    if (_limit_5136 != 0LL)
    goto LA; // [275] 221

    /** sequence.e:2140					exit*/
    goto LB; // [281] 289

    /** sequence.e:2142			end while*/
    goto LA; // [286] 221
LB: 
L8: 

    /** sequence.e:2145		ret = append(ret, st[start..$])*/
    if (IS_SEQUENCE(_st_5133)){
            _2637 = SEQ_PTR(_st_5133)->length;
    }
    else {
        _2637 = 1;
    }
    rhs_slice_target = (object_ptr)&_2638;
    RHS_Slice(_st_5133, _start_5138, _2637);
    RefDS(_2638);
    Append(&_ret_5137, _ret_5137, _2638);
    DeRefDS(_2638);
    _2638 = NOVALUE;

    /** sequence.e:2147		integer k = length(ret)*/
    if (IS_SEQUENCE(_ret_5137)){
            _k_5191 = SEQ_PTR(_ret_5137)->length;
    }
    else {
        _k_5191 = 1;
    }

    /** sequence.e:2148		if no_empty then*/
    if (_no_empty_5135 == 0)
    {
        goto LD; // [313] 378
    }
    else{
    }

    /** sequence.e:2149			k = 0*/
    _k_5191 = 0LL;

    /** sequence.e:2150			for i = 1 to length(ret) do*/
    if (IS_SEQUENCE(_ret_5137)){
            _2641 = SEQ_PTR(_ret_5137)->length;
    }
    else {
        _2641 = 1;
    }
    {
        object _i_5195;
        _i_5195 = 1LL;
LE: 
        if (_i_5195 > _2641){
            goto LF; // [326] 377
        }

        /** sequence.e:2151				if length(ret[i]) != 0 then*/
        _2 = (object)SEQ_PTR(_ret_5137);
        _2642 = (object)*(((s1_ptr)_2)->base + _i_5195);
        if (IS_SEQUENCE(_2642)){
                _2643 = SEQ_PTR(_2642)->length;
        }
        else {
            _2643 = 1;
        }
        _2642 = NOVALUE;
        if (_2643 == 0LL)
        goto L10; // [342] 370

        /** sequence.e:2152					k += 1*/
        _k_5191 = _k_5191 + 1;

        /** sequence.e:2153					if k != i then*/
        if (_k_5191 == _i_5195)
        goto L11; // [354] 369

        /** sequence.e:2154						ret[k] = ret[i]*/
        _2 = (object)SEQ_PTR(_ret_5137);
        _2647 = (object)*(((s1_ptr)_2)->base + _i_5195);
        Ref(_2647);
        _2 = (object)SEQ_PTR(_ret_5137);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _ret_5137 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _k_5191);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _2647;
        if( _1 != _2647 ){
            DeRef(_1);
        }
        _2647 = NOVALUE;
L11: 
L10: 

        /** sequence.e:2157			end for*/
        _i_5195 = _i_5195 + 1LL;
        goto LE; // [372] 333
LF: 
        ;
    }
LD: 

    /** sequence.e:2160		if k < length(ret) then*/
    if (IS_SEQUENCE(_ret_5137)){
            _2648 = SEQ_PTR(_ret_5137)->length;
    }
    else {
        _2648 = 1;
    }
    if (_k_5191 >= _2648)
    goto L12; // [383] 401

    /** sequence.e:2161			return ret[1 .. k]*/
    rhs_slice_target = (object_ptr)&_2650;
    RHS_Slice(_ret_5137, 1LL, _k_5191);
    DeRefDS(_st_5133);
    DeRefi(_delim_5134);
    DeRefDS(_ret_5137);
    DeRef(_2620);
    _2620 = NOVALUE;
    _2642 = NOVALUE;
    DeRef(_2631);
    _2631 = NOVALUE;
    DeRef(_2612);
    _2612 = NOVALUE;
    return _2650;
    goto L13; // [398] 408
L12: 

    /** sequence.e:2163			return ret*/
    DeRefDS(_st_5133);
    DeRefi(_delim_5134);
    DeRef(_2620);
    _2620 = NOVALUE;
    _2642 = NOVALUE;
    DeRef(_2631);
    _2631 = NOVALUE;
    DeRef(_2650);
    _2650 = NOVALUE;
    DeRef(_2612);
    _2612 = NOVALUE;
    return _ret_5137;
L13: 
    ;
}


object _23join(object _items_5260, object _delim_5261)
{
    object _ret_5263 = NOVALUE;
    object _2685 = NOVALUE;
    object _2684 = NOVALUE;
    object _2682 = NOVALUE;
    object _2681 = NOVALUE;
    object _2680 = NOVALUE;
    object _2679 = NOVALUE;
    object _2677 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:2279		if not length(items) then return {} end if*/
    if (IS_SEQUENCE(_items_5260)){
            _2677 = SEQ_PTR(_items_5260)->length;
    }
    else {
        _2677 = 1;
    }
    if (_2677 != 0)
    goto L1; // [8] 16
    _2677 = NOVALUE;
    RefDS(_5);
    DeRefDS(_items_5260);
    DeRef(_ret_5263);
    return _5;
L1: 

    /** sequence.e:2281		ret = {}*/
    RefDS(_5);
    DeRef(_ret_5263);
    _ret_5263 = _5;

    /** sequence.e:2282		for i=1 to length(items)-1 do*/
    if (IS_SEQUENCE(_items_5260)){
            _2679 = SEQ_PTR(_items_5260)->length;
    }
    else {
        _2679 = 1;
    }
    _2680 = _2679 - 1LL;
    _2679 = NOVALUE;
    {
        object _i_5268;
        _i_5268 = 1LL;
L2: 
        if (_i_5268 > _2680){
            goto L3; // [30] 58
        }

        /** sequence.e:2283			ret &= items[i] & delim*/
        _2 = (object)SEQ_PTR(_items_5260);
        _2681 = (object)*(((s1_ptr)_2)->base + _i_5268);
        if (IS_SEQUENCE(_2681) && IS_ATOM(_delim_5261)) {
            Append(&_2682, _2681, _delim_5261);
        }
        else if (IS_ATOM(_2681) && IS_SEQUENCE(_delim_5261)) {
        }
        else {
            Concat((object_ptr)&_2682, _2681, _delim_5261);
            _2681 = NOVALUE;
        }
        _2681 = NOVALUE;
        if (IS_SEQUENCE(_ret_5263) && IS_ATOM(_2682)) {
        }
        else if (IS_ATOM(_ret_5263) && IS_SEQUENCE(_2682)) {
            Ref(_ret_5263);
            Prepend(&_ret_5263, _2682, _ret_5263);
        }
        else {
            Concat((object_ptr)&_ret_5263, _ret_5263, _2682);
        }
        DeRefDS(_2682);
        _2682 = NOVALUE;

        /** sequence.e:2284		end for*/
        _i_5268 = _i_5268 + 1LL;
        goto L2; // [53] 37
L3: 
        ;
    }

    /** sequence.e:2286		ret &= items[$]*/
    if (IS_SEQUENCE(_items_5260)){
            _2684 = SEQ_PTR(_items_5260)->length;
    }
    else {
        _2684 = 1;
    }
    _2 = (object)SEQ_PTR(_items_5260);
    _2685 = (object)*(((s1_ptr)_2)->base + _2684);
    if (IS_SEQUENCE(_ret_5263) && IS_ATOM(_2685)) {
        Ref(_2685);
        Append(&_ret_5263, _ret_5263, _2685);
    }
    else if (IS_ATOM(_ret_5263) && IS_SEQUENCE(_2685)) {
        Ref(_ret_5263);
        Prepend(&_ret_5263, _2685, _ret_5263);
    }
    else {
        Concat((object_ptr)&_ret_5263, _ret_5263, _2685);
    }
    _2685 = NOVALUE;

    /** sequence.e:2288		return ret*/
    DeRefDS(_items_5260);
    DeRef(_2680);
    _2680 = NOVALUE;
    return _ret_5263;
    ;
}


object _23flatten(object _s_5370, object _delim_5371)
{
    object _ret_5372 = NOVALUE;
    object _x_5373 = NOVALUE;
    object _len_5374 = NOVALUE;
    object _pos_5375 = NOVALUE;
    object _temp_5393 = NOVALUE;
    object _2771 = NOVALUE;
    object _2770 = NOVALUE;
    object _2769 = NOVALUE;
    object _2767 = NOVALUE;
    object _2766 = NOVALUE;
    object _2765 = NOVALUE;
    object _2763 = NOVALUE;
    object _2761 = NOVALUE;
    object _2760 = NOVALUE;
    object _2759 = NOVALUE;
    object _2757 = NOVALUE;
    object _2756 = NOVALUE;
    object _2755 = NOVALUE;
    object _2754 = NOVALUE;
    object _2753 = NOVALUE;
    object _2752 = NOVALUE;
    object _2750 = NOVALUE;
    object _2749 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:2491		ret = s*/
    RefDS(_s_5370);
    DeRef(_ret_5372);
    _ret_5372 = _s_5370;

    /** sequence.e:2492		pos = 1*/
    _pos_5375 = 1LL;

    /** sequence.e:2493		len = length(ret)*/
    if (IS_SEQUENCE(_ret_5372)){
            _len_5374 = SEQ_PTR(_ret_5372)->length;
    }
    else {
        _len_5374 = 1;
    }

    /** sequence.e:2494		while pos <= len do*/
L1: 
    if (_pos_5375 > _len_5374)
    goto L2; // [25] 183

    /** sequence.e:2495			x = ret[pos]*/
    DeRef(_x_5373);
    _2 = (object)SEQ_PTR(_ret_5372);
    _x_5373 = (object)*(((s1_ptr)_2)->base + _pos_5375);
    Ref(_x_5373);

    /** sequence.e:2496			if sequence(x) then*/
    _2749 = IS_SEQUENCE(_x_5373);
    if (_2749 == 0)
    {
        _2749 = NOVALUE;
        goto L3; // [40] 171
    }
    else{
        _2749 = NOVALUE;
    }

    /** sequence.e:2497				if length(delim) = 0 then*/
    if (IS_SEQUENCE(_delim_5371)){
            _2750 = SEQ_PTR(_delim_5371)->length;
    }
    else {
        _2750 = 1;
    }
    if (_2750 != 0LL)
    goto L4; // [48] 89

    /** sequence.e:2498					ret = ret[1..pos-1] & flatten(x) & ret[pos+1 .. $]*/
    _2752 = _pos_5375 - 1LL;
    rhs_slice_target = (object_ptr)&_2753;
    RHS_Slice(_ret_5372, 1LL, _2752);
    Ref(_x_5373);
    RefDS(_5);
    _2754 = _23flatten(_x_5373, _5);
    _2755 = _pos_5375 + 1;
    if (_2755 > MAXINT){
        _2755 = NewDouble((eudouble)_2755);
    }
    if (IS_SEQUENCE(_ret_5372)){
            _2756 = SEQ_PTR(_ret_5372)->length;
    }
    else {
        _2756 = 1;
    }
    rhs_slice_target = (object_ptr)&_2757;
    RHS_Slice(_ret_5372, _2755, _2756);
    {
        object concat_list[3];

        concat_list[0] = _2757;
        concat_list[1] = _2754;
        concat_list[2] = _2753;
        Concat_N((object_ptr)&_ret_5372, concat_list, 3);
    }
    DeRefDS(_2757);
    _2757 = NOVALUE;
    DeRef(_2754);
    _2754 = NOVALUE;
    DeRefDS(_2753);
    _2753 = NOVALUE;
    goto L5; // [86] 163
L4: 

    /** sequence.e:2500					sequence temp = ret[1..pos-1] & flatten(x)*/
    _2759 = _pos_5375 - 1LL;
    rhs_slice_target = (object_ptr)&_2760;
    RHS_Slice(_ret_5372, 1LL, _2759);
    Ref(_x_5373);
    RefDS(_5);
    _2761 = _23flatten(_x_5373, _5);
    if (IS_SEQUENCE(_2760) && IS_ATOM(_2761)) {
        Ref(_2761);
        Append(&_temp_5393, _2760, _2761);
    }
    else if (IS_ATOM(_2760) && IS_SEQUENCE(_2761)) {
    }
    else {
        Concat((object_ptr)&_temp_5393, _2760, _2761);
        DeRefDS(_2760);
        _2760 = NOVALUE;
    }
    DeRef(_2760);
    _2760 = NOVALUE;
    DeRef(_2761);
    _2761 = NOVALUE;

    /** sequence.e:2501					if pos != length(ret) then*/
    if (IS_SEQUENCE(_ret_5372)){
            _2763 = SEQ_PTR(_ret_5372)->length;
    }
    else {
        _2763 = 1;
    }
    if (_pos_5375 == _2763)
    goto L6; // [114] 141

    /** sequence.e:2502						ret = temp &  delim & ret[pos+1 .. $]*/
    _2765 = _pos_5375 + 1;
    if (_2765 > MAXINT){
        _2765 = NewDouble((eudouble)_2765);
    }
    if (IS_SEQUENCE(_ret_5372)){
            _2766 = SEQ_PTR(_ret_5372)->length;
    }
    else {
        _2766 = 1;
    }
    rhs_slice_target = (object_ptr)&_2767;
    RHS_Slice(_ret_5372, _2765, _2766);
    {
        object concat_list[3];

        concat_list[0] = _2767;
        concat_list[1] = _delim_5371;
        concat_list[2] = _temp_5393;
        Concat_N((object_ptr)&_ret_5372, concat_list, 3);
    }
    DeRefDS(_2767);
    _2767 = NOVALUE;
    goto L7; // [138] 160
L6: 

    /** sequence.e:2504						ret = temp & ret[pos+1 .. $]*/
    _2769 = _pos_5375 + 1;
    if (_2769 > MAXINT){
        _2769 = NewDouble((eudouble)_2769);
    }
    if (IS_SEQUENCE(_ret_5372)){
            _2770 = SEQ_PTR(_ret_5372)->length;
    }
    else {
        _2770 = 1;
    }
    rhs_slice_target = (object_ptr)&_2771;
    RHS_Slice(_ret_5372, _2769, _2770);
    Concat((object_ptr)&_ret_5372, _temp_5393, _2771);
    DeRefDS(_2771);
    _2771 = NOVALUE;
L7: 
    DeRef(_temp_5393);
    _temp_5393 = NOVALUE;
L5: 

    /** sequence.e:2507				len = length(ret)*/
    if (IS_SEQUENCE(_ret_5372)){
            _len_5374 = SEQ_PTR(_ret_5372)->length;
    }
    else {
        _len_5374 = 1;
    }
    goto L1; // [168] 25
L3: 

    /** sequence.e:2509				pos += 1*/
    _pos_5375 = _pos_5375 + 1;

    /** sequence.e:2511		end while*/
    goto L1; // [180] 25
L2: 

    /** sequence.e:2513		return ret*/
    DeRefDS(_s_5370);
    DeRefi(_delim_5371);
    DeRef(_x_5373);
    DeRef(_2765);
    _2765 = NOVALUE;
    DeRef(_2752);
    _2752 = NOVALUE;
    DeRef(_2759);
    _2759 = NOVALUE;
    DeRef(_2769);
    _2769 = NOVALUE;
    DeRef(_2755);
    _2755 = NOVALUE;
    return _ret_5372;
    ;
}


object _23remove_dups(object _source_data_5740, object _proc_option_5741)
{
    object _lTo_5742 = NOVALUE;
    object _lFrom_5743 = NOVALUE;
    object _lResult_5766 = NOVALUE;
    object _3000 = NOVALUE;
    object _2998 = NOVALUE;
    object _2997 = NOVALUE;
    object _2996 = NOVALUE;
    object _2995 = NOVALUE;
    object _2993 = NOVALUE;
    object _2989 = NOVALUE;
    object _2988 = NOVALUE;
    object _2987 = NOVALUE;
    object _2985 = NOVALUE;
    object _2980 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:3111		if length(source_data) < 2 then*/
    if (IS_SEQUENCE(_source_data_5740)){
            _2980 = SEQ_PTR(_source_data_5740)->length;
    }
    else {
        _2980 = 1;
    }
    if (_2980 >= 2LL)
    goto L1; // [10] 21

    /** sequence.e:3112			return source_data*/
    DeRef(_lResult_5766);
    return _source_data_5740;
L1: 

    /** sequence.e:3115		if proc_option = RD_SORT then*/
    if (_proc_option_5741 != 3LL)
    goto L2; // [23] 42

    /** sequence.e:3116			source_data = stdsort:sort(source_data)*/
    RefDS(_source_data_5740);
    _0 = _source_data_5740;
    _source_data_5740 = _24sort(_source_data_5740, 1LL);
    DeRefDS(_0);

    /** sequence.e:3117			proc_option = RD_PRESORTED*/
    _proc_option_5741 = 2LL;
L2: 

    /** sequence.e:3119		if proc_option = RD_PRESORTED then*/
    if (_proc_option_5741 != 2LL)
    goto L3; // [44] 134

    /** sequence.e:3120			lTo = 1*/
    _lTo_5742 = 1LL;

    /** sequence.e:3121			lFrom = 2*/
    _lFrom_5743 = 2LL;

    /** sequence.e:3123			while lFrom <= length(source_data) do*/
L4: 
    if (IS_SEQUENCE(_source_data_5740)){
            _2985 = SEQ_PTR(_source_data_5740)->length;
    }
    else {
        _2985 = 1;
    }
    if (_lFrom_5743 > _2985)
    goto L5; // [66] 122

    /** sequence.e:3124				if not equal(source_data[lFrom], source_data[lTo]) then*/
    _2 = (object)SEQ_PTR(_source_data_5740);
    _2987 = (object)*(((s1_ptr)_2)->base + _lFrom_5743);
    _2 = (object)SEQ_PTR(_source_data_5740);
    _2988 = (object)*(((s1_ptr)_2)->base + _lTo_5742);
    if (_2987 == _2988)
    _2989 = 1;
    else if (IS_ATOM_INT(_2987) && IS_ATOM_INT(_2988))
    _2989 = 0;
    else
    _2989 = (compare(_2987, _2988) == 0);
    _2987 = NOVALUE;
    _2988 = NOVALUE;
    if (_2989 != 0)
    goto L6; // [84] 111
    _2989 = NOVALUE;

    /** sequence.e:3125					lTo += 1*/
    _lTo_5742 = _lTo_5742 + 1;

    /** sequence.e:3126					if lTo != lFrom then*/
    if (_lTo_5742 == _lFrom_5743)
    goto L7; // [95] 110

    /** sequence.e:3127						source_data[lTo] = source_data[lFrom]*/
    _2 = (object)SEQ_PTR(_source_data_5740);
    _2993 = (object)*(((s1_ptr)_2)->base + _lFrom_5743);
    Ref(_2993);
    _2 = (object)SEQ_PTR(_source_data_5740);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _source_data_5740 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _lTo_5742);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _2993;
    if( _1 != _2993 ){
        DeRef(_1);
    }
    _2993 = NOVALUE;
L7: 
L6: 

    /** sequence.e:3130				lFrom += 1*/
    _lFrom_5743 = _lFrom_5743 + 1;

    /** sequence.e:3131			end while*/
    goto L4; // [119] 63
L5: 

    /** sequence.e:3132			return source_data[1 .. lTo]*/
    rhs_slice_target = (object_ptr)&_2995;
    RHS_Slice(_source_data_5740, 1LL, _lTo_5742);
    DeRefDS(_source_data_5740);
    DeRef(_lResult_5766);
    return _2995;
L3: 

    /** sequence.e:3135		sequence lResult*/

    /** sequence.e:3136		lResult = {}*/
    RefDS(_5);
    DeRef(_lResult_5766);
    _lResult_5766 = _5;

    /** sequence.e:3137		for i = 1 to length(source_data) do*/
    if (IS_SEQUENCE(_source_data_5740)){
            _2996 = SEQ_PTR(_source_data_5740)->length;
    }
    else {
        _2996 = 1;
    }
    {
        object _i_5768;
        _i_5768 = 1LL;
L8: 
        if (_i_5768 > _2996){
            goto L9; // [148] 187
        }

        /** sequence.e:3138			if not find(source_data[i], lResult) then*/
        _2 = (object)SEQ_PTR(_source_data_5740);
        _2997 = (object)*(((s1_ptr)_2)->base + _i_5768);
        _2998 = find_from(_2997, _lResult_5766, 1LL);
        _2997 = NOVALUE;
        if (_2998 != 0)
        goto LA; // [166] 180
        _2998 = NOVALUE;

        /** sequence.e:3139				lResult = append(lResult, source_data[i])*/
        _2 = (object)SEQ_PTR(_source_data_5740);
        _3000 = (object)*(((s1_ptr)_2)->base + _i_5768);
        Ref(_3000);
        Append(&_lResult_5766, _lResult_5766, _3000);
        _3000 = NOVALUE;
LA: 

        /** sequence.e:3141		end for*/
        _i_5768 = _i_5768 + 1LL;
        goto L8; // [182] 155
L9: 
        ;
    }

    /** sequence.e:3142		return lResult*/
    DeRefDS(_source_data_5740);
    DeRef(_2995);
    _2995 = NOVALUE;
    return _lResult_5766;
    ;
}



// 0xF857AEAE
