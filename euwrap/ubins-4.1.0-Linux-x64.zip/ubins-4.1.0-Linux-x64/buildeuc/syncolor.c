// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _70set_colors(object _pColorList_66530)
{
    object _lColorName_66531 = NOVALUE;
    object _32777 = NOVALUE;
    object _32774 = NOVALUE;
    object _32771 = NOVALUE;
    object _32768 = NOVALUE;
    object _32765 = NOVALUE;
    object _32762 = NOVALUE;
    object _32759 = NOVALUE;
    object _32754 = NOVALUE;
    object _32753 = NOVALUE;
    object _32752 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:48		for i = 1 to length(pColorList) do*/
    _32752 = 6;
    {
        object _i_66533;
        _i_66533 = 1LL;
L1: 
        if (_i_66533 > 6LL){
            goto L2; // [8] 168
        }

        /** syncolor.e:49			lColorName = text:upper(pColorList[i][1])*/
        _2 = (object)SEQ_PTR(_pColorList_66530);
        _32753 = (object)*(((s1_ptr)_2)->base + _i_66533);
        _2 = (object)SEQ_PTR(_32753);
        _32754 = (object)*(((s1_ptr)_2)->base + 1LL);
        _32753 = NOVALUE;
        Ref(_32754);
        _0 = _lColorName_66531;
        _lColorName_66531 = _14upper(_32754);
        DeRef(_0);
        _32754 = NOVALUE;

        /** syncolor.e:50			switch lColorName do*/
        _1 = find(_lColorName_66531, _32756);
        switch ( _1 ){ 

            /** syncolor.e:51				case "NORMAL" then*/
            case 1:

            /** syncolor.e:52					NORMAL_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_66530);
            _32759 = (object)*(((s1_ptr)_2)->base + _i_66533);
            _2 = (object)SEQ_PTR(_32759);
            _70NORMAL_COLOR_66519 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_70NORMAL_COLOR_66519)){
                _70NORMAL_COLOR_66519 = (object)DBL_PTR(_70NORMAL_COLOR_66519)->dbl;
            }
            _32759 = NOVALUE;
            goto L3; // [54] 161

            /** syncolor.e:53				case "COMMENT" then*/
            case 2:

            /** syncolor.e:54					COMMENT_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_66530);
            _32762 = (object)*(((s1_ptr)_2)->base + _i_66533);
            _2 = (object)SEQ_PTR(_32762);
            _70COMMENT_COLOR_66520 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_70COMMENT_COLOR_66520)){
                _70COMMENT_COLOR_66520 = (object)DBL_PTR(_70COMMENT_COLOR_66520)->dbl;
            }
            _32762 = NOVALUE;
            goto L3; // [72] 161

            /** syncolor.e:55				case "KEYWORD" then*/
            case 3:

            /** syncolor.e:56					KEYWORD_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_66530);
            _32765 = (object)*(((s1_ptr)_2)->base + _i_66533);
            _2 = (object)SEQ_PTR(_32765);
            _70KEYWORD_COLOR_66521 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_70KEYWORD_COLOR_66521)){
                _70KEYWORD_COLOR_66521 = (object)DBL_PTR(_70KEYWORD_COLOR_66521)->dbl;
            }
            _32765 = NOVALUE;
            goto L3; // [90] 161

            /** syncolor.e:57				case "BUILTIN" then*/
            case 4:

            /** syncolor.e:58					BUILTIN_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_66530);
            _32768 = (object)*(((s1_ptr)_2)->base + _i_66533);
            _2 = (object)SEQ_PTR(_32768);
            _70BUILTIN_COLOR_66522 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_70BUILTIN_COLOR_66522)){
                _70BUILTIN_COLOR_66522 = (object)DBL_PTR(_70BUILTIN_COLOR_66522)->dbl;
            }
            _32768 = NOVALUE;
            goto L3; // [108] 161

            /** syncolor.e:59				case "STRING" then*/
            case 5:

            /** syncolor.e:60					STRING_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_66530);
            _32771 = (object)*(((s1_ptr)_2)->base + _i_66533);
            _2 = (object)SEQ_PTR(_32771);
            _70STRING_COLOR_66523 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_70STRING_COLOR_66523)){
                _70STRING_COLOR_66523 = (object)DBL_PTR(_70STRING_COLOR_66523)->dbl;
            }
            _32771 = NOVALUE;
            goto L3; // [126] 161

            /** syncolor.e:61				case "BRACKET" then*/
            case 6:

            /** syncolor.e:62					BRACKET_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_66530);
            _32774 = (object)*(((s1_ptr)_2)->base + _i_66533);
            DeRef(_70BRACKET_COLOR_66524);
            _2 = (object)SEQ_PTR(_32774);
            _70BRACKET_COLOR_66524 = (object)*(((s1_ptr)_2)->base + 2LL);
            Ref(_70BRACKET_COLOR_66524);
            _32774 = NOVALUE;
            goto L3; // [144] 161

            /** syncolor.e:63				case else*/
            case 0:

            /** syncolor.e:64					printf(2, "syncolor.e: Unknown color name '%s', ignored.\n", {lColorName})*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            RefDS(_lColorName_66531);
            ((intptr_t*)_2)[1] = _lColorName_66531;
            _32777 = MAKE_SEQ(_1);
            EPrintf(2LL, _32776, _32777);
            DeRefDS(_32777);
            _32777 = NOVALUE;
        ;}L3: 

        /** syncolor.e:66		end for*/
        _i_66533 = _i_66533 + 1LL;
        goto L1; // [163] 15
L2: 
        ;
    }

    /** syncolor.e:67	end procedure*/
    DeRefDS(_pColorList_66530);
    DeRef(_lColorName_66531);
    return;
    ;
}


void _70init_class()
{
    object _0, _1, _2;
    

    /** syncolor.e:71		NORMAL_COLOR  = #330033*/
    _70NORMAL_COLOR_66519 = 3342387LL;

    /** syncolor.e:72		COMMENT_COLOR = #FF0055*/
    _70COMMENT_COLOR_66520 = 16711765LL;

    /** syncolor.e:73		KEYWORD_COLOR = #0000FF*/
    _70KEYWORD_COLOR_66521 = 255LL;

    /** syncolor.e:74		BUILTIN_COLOR = #FF00FF*/
    _70BUILTIN_COLOR_66522 = 16711935LL;

    /** syncolor.e:75		STRING_COLOR  = #00A033*/
    _70STRING_COLOR_66523 = 41011LL;

    /** syncolor.e:76		BRACKET_COLOR = {NORMAL_COLOR, #993333, #0000FF, #5500FF, #00FF00}*/
    _0 = _70BRACKET_COLOR_66524;
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 3342387LL;
    ((intptr_t*)_2)[2] = 10040115LL;
    ((intptr_t*)_2)[3] = 255LL;
    ((intptr_t*)_2)[4] = 5570815LL;
    ((intptr_t*)_2)[5] = 65280LL;
    _70BRACKET_COLOR_66524 = MAKE_SEQ(_1);
    DeRef(_0);

    /** syncolor.e:78	end procedure*/
    return;
    ;
}


object _70default_state(object _token_66600)
{
    object _32799 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:103		if not token then*/
    if (IS_ATOM_INT(_token_66600)) {
        if (_token_66600 != 0){
            goto L1; // [3] 12
        }
    }
    else {
        if (DBL_PTR(_token_66600)->dbl != 0.0){
            goto L1; // [3] 12
        }
    }

    /** syncolor.e:104			token = tokenize:new()*/
    _0 = _token_66600;
    _token_66600 = _71new();
    DeRef(_0);
L1: 

    /** syncolor.e:106		return {*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_token_66600);
    ((intptr_t*)_2)[1] = _token_66600;
    ((intptr_t*)_2)[2] = 0LL;
    ((intptr_t*)_2)[3] = 0LL;
    _32799 = MAKE_SEQ(_1);
    DeRef(_token_66600);
    return _32799;
    ;
}


object _70new()
{
    object _state_66611 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:124		atom state = eumem:malloc()*/
    _0 = _state_66611;
    _state_66611 = _30malloc(1LL, 1LL);
    DeRef(_0);

    /** syncolor.e:126		reset(state)*/
    Ref(_state_66611);
    _70reset(_state_66611);

    /** syncolor.e:128		return state*/
    return _state_66611;
    ;
}


void _70tokenize_reset(object _token_66616)
{
    object _reset_1__tmp_at7_66619 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:138		if token then*/
    if (_token_66616 == 0) {
        goto L1; // [3] 27
    }
    else {
        if (!IS_ATOM_INT(_token_66616) && DBL_PTR(_token_66616)->dbl == 0.0){
            goto L1; // [3] 27
        }
    }

    /** syncolor.e:139			tokenize:reset(token)*/

    /** tokenize.e:215		eumem:ram_space[state] = default_state()*/
    _0 = _reset_1__tmp_at7_66619;
    _reset_1__tmp_at7_66619 = _71default_state();
    DeRef(_0);
    Ref(_reset_1__tmp_at7_66619);
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _30ram_space_11238 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_token_66616))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_token_66616)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _token_66616);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _reset_1__tmp_at7_66619;
    DeRef(_1);

    /** tokenize.e:216	end procedure*/
    goto L2; // [21] 24
L2: 
    DeRef(_reset_1__tmp_at7_66619);
    _reset_1__tmp_at7_66619 = NOVALUE;
L1: 

    /** syncolor.e:141	end procedure*/
    DeRef(_token_66616);
    return;
    ;
}


void _70reset(object _state_66622)
{
    object _token_66623 = NOVALUE;
    object _32806 = NOVALUE;
    object _32805 = NOVALUE;
    object _32803 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:144		atom token = eumem:ram_space[state][S_TOKENIZER]*/
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!IS_ATOM_INT(_state_66622)){
        _32803 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_state_66622)->dbl));
    }
    else{
        _32803 = (object)*(((s1_ptr)_2)->base + _state_66622);
    }
    DeRef(_token_66623);
    _2 = (object)SEQ_PTR(_32803);
    _token_66623 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_token_66623);
    _32803 = NOVALUE;

    /** syncolor.e:145		tokenize_reset(token)*/
    Ref(_token_66623);
    _70tokenize_reset(_token_66623);

    /** syncolor.e:146		eumem:ram_space[state] = default_state(token)*/
    Ref(_token_66623);
    _32805 = _70default_state(_token_66623);
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _30ram_space_11238 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_66622))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_state_66622)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _state_66622);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32805;
    if( _1 != _32805 ){
        DeRef(_1);
    }
    _32805 = NOVALUE;

    /** syncolor.e:147		eumem:ram_space[state] = default_state()*/
    _32806 = _70default_state(0LL);
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _30ram_space_11238 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_66622))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_state_66622)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _state_66622);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32806;
    if( _1 != _32806 ){
        DeRef(_1);
    }
    _32806 = NOVALUE;

    /** syncolor.e:148	end procedure*/
    DeRef(_state_66622);
    DeRef(_token_66623);
    return;
    ;
}



// 0x1C9C1383
