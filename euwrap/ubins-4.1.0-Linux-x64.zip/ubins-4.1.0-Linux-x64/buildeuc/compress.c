// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _60compress(object _x_22557)
{
    object _x4_22558 = NOVALUE;
    object _s_22559 = NOVALUE;
    object _12748 = NOVALUE;
    object _12747 = NOVALUE;
    object _12746 = NOVALUE;
    object _12744 = NOVALUE;
    object _12743 = NOVALUE;
    object _12741 = NOVALUE;
    object _12739 = NOVALUE;
    object _12738 = NOVALUE;
    object _12737 = NOVALUE;
    object _12736 = NOVALUE;
    object _12734 = NOVALUE;
    object _12732 = NOVALUE;
    object _12730 = NOVALUE;
    object _12728 = NOVALUE;
    object _12727 = NOVALUE;
    object _12726 = NOVALUE;
    object _12724 = NOVALUE;
    object _12723 = NOVALUE;
    object _12722 = NOVALUE;
    object _12721 = NOVALUE;
    object _12720 = NOVALUE;
    object _12719 = NOVALUE;
    object _12718 = NOVALUE;
    object _12717 = NOVALUE;
    object _12716 = NOVALUE;
    object _12715 = NOVALUE;
    object _12713 = NOVALUE;
    object _12712 = NOVALUE;
    object _12711 = NOVALUE;
    object _12710 = NOVALUE;
    object _12709 = NOVALUE;
    object _12708 = NOVALUE;
    object _12706 = NOVALUE;
    object _12705 = NOVALUE;
    object _12704 = NOVALUE;
    object _12703 = NOVALUE;
    object _12702 = NOVALUE;
    object _12701 = NOVALUE;
    object _12700 = NOVALUE;
    object _12699 = NOVALUE;
    object _12698 = NOVALUE;
    object _0, _1, _2;
    

    /** compress.e:59		if integer(x) then*/
    if (IS_ATOM_INT(_x_22557))
    _12698 = 1;
    else if (IS_ATOM_DBL(_x_22557))
    _12698 = IS_ATOM_INT(DoubleToInt(_x_22557));
    else
    _12698 = 0;
    if (_12698 == 0)
    {
        _12698 = NOVALUE;
        goto L1; // [6] 220
    }
    else{
        _12698 = NOVALUE;
    }

    /** compress.e:60			if x >= MIN1B and x <= MAX1B then*/
    if (IS_ATOM_INT(_x_22557)) {
        _12699 = (_x_22557 >= -2LL);
    }
    else {
        _12699 = binary_op(GREATEREQ, _x_22557, -2LL);
    }
    if (IS_ATOM_INT(_12699)) {
        if (_12699 == 0) {
            goto L2; // [15] 44
        }
    }
    else {
        if (DBL_PTR(_12699)->dbl == 0.0) {
            goto L2; // [15] 44
        }
    }
    if (IS_ATOM_INT(_x_22557)) {
        _12701 = (_x_22557 <= 244LL);
    }
    else {
        _12701 = binary_op(LESSEQ, _x_22557, 244LL);
    }
    if (_12701 == 0) {
        DeRef(_12701);
        _12701 = NOVALUE;
        goto L2; // [24] 44
    }
    else {
        if (!IS_ATOM_INT(_12701) && DBL_PTR(_12701)->dbl == 0.0){
            DeRef(_12701);
            _12701 = NOVALUE;
            goto L2; // [24] 44
        }
        DeRef(_12701);
        _12701 = NOVALUE;
    }
    DeRef(_12701);
    _12701 = NOVALUE;

    /** compress.e:61				return {x - MIN1B}*/
    if (IS_ATOM_INT(_x_22557)) {
        _12702 = _x_22557 - -2LL;
        if ((object)((uintptr_t)_12702 +(uintptr_t) HIGH_BITS) >= 0){
            _12702 = NewDouble((eudouble)_12702);
        }
    }
    else {
        _12702 = binary_op(MINUS, _x_22557, -2LL);
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _12702;
    _12703 = MAKE_SEQ(_1);
    _12702 = NOVALUE;
    DeRef(_x_22557);
    DeRef(_x4_22558);
    DeRef(_s_22559);
    DeRef(_12699);
    _12699 = NOVALUE;
    return _12703;
    goto L3; // [41] 389
L2: 

    /** compress.e:63			elsif x >= MIN2B and x <= MAX2B then*/
    if (IS_ATOM_INT(_x_22557)) {
        _12704 = (_x_22557 >= _60MIN2B_22531);
    }
    else {
        _12704 = binary_op(GREATEREQ, _x_22557, _60MIN2B_22531);
    }
    if (IS_ATOM_INT(_12704)) {
        if (_12704 == 0) {
            goto L4; // [52] 97
        }
    }
    else {
        if (DBL_PTR(_12704)->dbl == 0.0) {
            goto L4; // [52] 97
        }
    }
    if (IS_ATOM_INT(_x_22557)) {
        _12706 = (_x_22557 <= 32767LL);
    }
    else {
        _12706 = binary_op(LESSEQ, _x_22557, 32767LL);
    }
    if (_12706 == 0) {
        DeRef(_12706);
        _12706 = NOVALUE;
        goto L4; // [63] 97
    }
    else {
        if (!IS_ATOM_INT(_12706) && DBL_PTR(_12706)->dbl == 0.0){
            DeRef(_12706);
            _12706 = NOVALUE;
            goto L4; // [63] 97
        }
        DeRef(_12706);
        _12706 = NOVALUE;
    }
    DeRef(_12706);
    _12706 = NOVALUE;

    /** compress.e:64				x -= MIN2B*/
    _0 = _x_22557;
    if (IS_ATOM_INT(_x_22557)) {
        _x_22557 = _x_22557 - _60MIN2B_22531;
        if ((object)((uintptr_t)_x_22557 +(uintptr_t) HIGH_BITS) >= 0){
            _x_22557 = NewDouble((eudouble)_x_22557);
        }
    }
    else {
        _x_22557 = binary_op(MINUS, _x_22557, _60MIN2B_22531);
    }
    DeRef(_0);

    /** compress.e:65				return {I2B, and_bits(x, #FF), floor(x / #100)}*/
    if (IS_ATOM_INT(_x_22557)) {
        {uintptr_t tu;
             tu = (uintptr_t)_x_22557 & (uintptr_t)255LL;
             _12708 = MAKE_UINT(tu);
        }
    }
    else {
        _12708 = binary_op(AND_BITS, _x_22557, 255LL);
    }
    if (IS_ATOM_INT(_x_22557)) {
        if (256LL > 0 && _x_22557 >= 0) {
            _12709 = _x_22557 / 256LL;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_x_22557 / (eudouble)256LL);
            if (_x_22557 != MININT)
            _12709 = (object)temp_dbl;
            else
            _12709 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_22557, 256LL);
        _12709 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 247LL;
    ((intptr_t*)_2)[2] = _12708;
    ((intptr_t*)_2)[3] = _12709;
    _12710 = MAKE_SEQ(_1);
    _12709 = NOVALUE;
    _12708 = NOVALUE;
    DeRef(_x_22557);
    DeRef(_x4_22558);
    DeRef(_s_22559);
    DeRef(_12699);
    _12699 = NOVALUE;
    DeRef(_12703);
    _12703 = NOVALUE;
    DeRef(_12704);
    _12704 = NOVALUE;
    return _12710;
    goto L3; // [94] 389
L4: 

    /** compress.e:67			elsif x >= MIN3B and x <= MAX3B then*/
    if (IS_ATOM_INT(_x_22557)) {
        _12711 = (_x_22557 >= _60MIN3B_22537);
    }
    else {
        _12711 = binary_op(GREATEREQ, _x_22557, _60MIN3B_22537);
    }
    if (IS_ATOM_INT(_12711)) {
        if (_12711 == 0) {
            goto L5; // [105] 159
        }
    }
    else {
        if (DBL_PTR(_12711)->dbl == 0.0) {
            goto L5; // [105] 159
        }
    }
    if (IS_ATOM_INT(_x_22557)) {
        _12713 = (_x_22557 <= 8388607LL);
    }
    else {
        _12713 = binary_op(LESSEQ, _x_22557, 8388607LL);
    }
    if (_12713 == 0) {
        DeRef(_12713);
        _12713 = NOVALUE;
        goto L5; // [116] 159
    }
    else {
        if (!IS_ATOM_INT(_12713) && DBL_PTR(_12713)->dbl == 0.0){
            DeRef(_12713);
            _12713 = NOVALUE;
            goto L5; // [116] 159
        }
        DeRef(_12713);
        _12713 = NOVALUE;
    }
    DeRef(_12713);
    _12713 = NOVALUE;

    /** compress.e:68				x -= MIN3B*/
    _0 = _x_22557;
    if (IS_ATOM_INT(_x_22557)) {
        _x_22557 = _x_22557 - _60MIN3B_22537;
        if ((object)((uintptr_t)_x_22557 +(uintptr_t) HIGH_BITS) >= 0){
            _x_22557 = NewDouble((eudouble)_x_22557);
        }
    }
    else {
        _x_22557 = binary_op(MINUS, _x_22557, _60MIN3B_22537);
    }
    DeRef(_0);

    /** compress.e:69				return {I3B, and_bits(x, #FF), and_bits(floor(x / #100), #FF), floor(x / #10000)}*/
    if (IS_ATOM_INT(_x_22557)) {
        {uintptr_t tu;
             tu = (uintptr_t)_x_22557 & (uintptr_t)255LL;
             _12715 = MAKE_UINT(tu);
        }
    }
    else {
        _12715 = binary_op(AND_BITS, _x_22557, 255LL);
    }
    if (IS_ATOM_INT(_x_22557)) {
        if (256LL > 0 && _x_22557 >= 0) {
            _12716 = _x_22557 / 256LL;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_x_22557 / (eudouble)256LL);
            if (_x_22557 != MININT)
            _12716 = (object)temp_dbl;
            else
            _12716 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_22557, 256LL);
        _12716 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (IS_ATOM_INT(_12716)) {
        {uintptr_t tu;
             tu = (uintptr_t)_12716 & (uintptr_t)255LL;
             _12717 = MAKE_UINT(tu);
        }
    }
    else {
        _12717 = binary_op(AND_BITS, _12716, 255LL);
    }
    DeRef(_12716);
    _12716 = NOVALUE;
    if (IS_ATOM_INT(_x_22557)) {
        if (65536LL > 0 && _x_22557 >= 0) {
            _12718 = _x_22557 / 65536LL;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_x_22557 / (eudouble)65536LL);
            if (_x_22557 != MININT)
            _12718 = (object)temp_dbl;
            else
            _12718 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_22557, 65536LL);
        _12718 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 248LL;
    ((intptr_t*)_2)[2] = _12715;
    ((intptr_t*)_2)[3] = _12717;
    ((intptr_t*)_2)[4] = _12718;
    _12719 = MAKE_SEQ(_1);
    _12718 = NOVALUE;
    _12717 = NOVALUE;
    _12715 = NOVALUE;
    DeRef(_x_22557);
    DeRef(_x4_22558);
    DeRef(_s_22559);
    DeRef(_12699);
    _12699 = NOVALUE;
    DeRef(_12703);
    _12703 = NOVALUE;
    DeRef(_12711);
    _12711 = NOVALUE;
    DeRef(_12710);
    _12710 = NOVALUE;
    DeRef(_12704);
    _12704 = NOVALUE;
    return _12719;
    goto L3; // [156] 389
L5: 

    /** compress.e:71			elsif x >= MIN4B and x <= MAX4B then*/
    if (IS_ATOM_INT(_x_22557)) {
        _12720 = (_x_22557 >= _60MIN4B_22543);
    }
    else {
        _12720 = binary_op(GREATEREQ, _x_22557, _60MIN4B_22543);
    }
    if (IS_ATOM_INT(_12720)) {
        if (_12720 == 0) {
            goto L6; // [167] 199
        }
    }
    else {
        if (DBL_PTR(_12720)->dbl == 0.0) {
            goto L6; // [167] 199
        }
    }
    if (IS_ATOM_INT(_x_22557)) {
        _12722 = (_x_22557 <= 2147483647LL);
    }
    else {
        _12722 = binary_op(LESSEQ, _x_22557, 2147483647LL);
    }
    if (_12722 == 0) {
        DeRef(_12722);
        _12722 = NOVALUE;
        goto L6; // [178] 199
    }
    else {
        if (!IS_ATOM_INT(_12722) && DBL_PTR(_12722)->dbl == 0.0){
            DeRef(_12722);
            _12722 = NOVALUE;
            goto L6; // [178] 199
        }
        DeRef(_12722);
        _12722 = NOVALUE;
    }
    DeRef(_12722);
    _12722 = NOVALUE;

    /** compress.e:72				return I4B & int_to_bytes(x)*/
    Ref(_x_22557);
    _12723 = _15int_to_bytes(_x_22557, 4LL);
    if (IS_SEQUENCE(249LL) && IS_ATOM(_12723)) {
    }
    else if (IS_ATOM(249LL) && IS_SEQUENCE(_12723)) {
        Prepend(&_12724, _12723, 249LL);
    }
    else {
        Concat((object_ptr)&_12724, 249LL, _12723);
    }
    DeRef(_12723);
    _12723 = NOVALUE;
    DeRef(_x_22557);
    DeRef(_x4_22558);
    DeRef(_s_22559);
    DeRef(_12719);
    _12719 = NOVALUE;
    DeRef(_12699);
    _12699 = NOVALUE;
    DeRef(_12703);
    _12703 = NOVALUE;
    DeRef(_12711);
    _12711 = NOVALUE;
    DeRef(_12710);
    _12710 = NOVALUE;
    DeRef(_12704);
    _12704 = NOVALUE;
    DeRef(_12720);
    _12720 = NOVALUE;
    return _12724;
    goto L3; // [196] 389
L6: 

    /** compress.e:75				ifdef EU4_0 then*/

    /** compress.e:79					return I8B & int_to_bytes(x, 8)*/
    Ref(_x_22557);
    _12726 = _15int_to_bytes(_x_22557, 8LL);
    if (IS_SEQUENCE(250LL) && IS_ATOM(_12726)) {
    }
    else if (IS_ATOM(250LL) && IS_SEQUENCE(_12726)) {
        Prepend(&_12727, _12726, 250LL);
    }
    else {
        Concat((object_ptr)&_12727, 250LL, _12726);
    }
    DeRef(_12726);
    _12726 = NOVALUE;
    DeRef(_x_22557);
    DeRef(_x4_22558);
    DeRef(_s_22559);
    DeRef(_12719);
    _12719 = NOVALUE;
    DeRef(_12699);
    _12699 = NOVALUE;
    DeRef(_12703);
    _12703 = NOVALUE;
    DeRef(_12711);
    _12711 = NOVALUE;
    DeRef(_12710);
    _12710 = NOVALUE;
    DeRef(_12704);
    _12704 = NOVALUE;
    DeRef(_12720);
    _12720 = NOVALUE;
    DeRef(_12724);
    _12724 = NOVALUE;
    return _12727;
    goto L3; // [217] 389
L1: 

    /** compress.e:83		elsif atom(x) then*/
    _12728 = IS_ATOM(_x_22557);
    if (_12728 == 0)
    {
        _12728 = NOVALUE;
        goto L7; // [225] 309
    }
    else{
        _12728 = NOVALUE;
    }

    /** compress.e:85			x4 = atom_to_float32(x)*/
    Ref(_x_22557);
    _0 = _x4_22558;
    _x4_22558 = _15atom_to_float32(_x_22557);
    DeRef(_0);

    /** compress.e:86			if x = float32_to_atom(x4) then*/
    RefDS(_x4_22558);
    _12730 = _15float32_to_atom(_x4_22558);
    if (binary_op_a(NOTEQ, _x_22557, _12730)){
        DeRef(_12730);
        _12730 = NOVALUE;
        goto L8; // [242] 259
    }
    DeRef(_12730);
    _12730 = NOVALUE;

    /** compress.e:88				return F4B & x4*/
    Prepend(&_12732, _x4_22558, 251LL);
    DeRef(_x_22557);
    DeRefDS(_x4_22558);
    DeRef(_s_22559);
    DeRef(_12719);
    _12719 = NOVALUE;
    DeRef(_12699);
    _12699 = NOVALUE;
    DeRef(_12703);
    _12703 = NOVALUE;
    DeRef(_12711);
    _12711 = NOVALUE;
    DeRef(_12710);
    _12710 = NOVALUE;
    DeRef(_12704);
    _12704 = NOVALUE;
    DeRef(_12720);
    _12720 = NOVALUE;
    DeRef(_12727);
    _12727 = NOVALUE;
    DeRef(_12724);
    _12724 = NOVALUE;
    return _12732;
    goto L3; // [256] 389
L8: 

    /** compress.e:90				x4 = atom_to_float64( x )*/
    Ref(_x_22557);
    _0 = _x4_22558;
    _x4_22558 = _15atom_to_float64(_x_22557);
    DeRef(_0);

    /** compress.e:91				if x = float64_to_atom( x4 ) then*/
    RefDS(_x4_22558);
    _12734 = _15float64_to_atom(_x4_22558);
    if (binary_op_a(NOTEQ, _x_22557, _12734)){
        DeRef(_12734);
        _12734 = NOVALUE;
        goto L9; // [273] 290
    }
    DeRef(_12734);
    _12734 = NOVALUE;

    /** compress.e:92					return F8B & x4*/
    Prepend(&_12736, _x4_22558, 252LL);
    DeRef(_x_22557);
    DeRefDS(_x4_22558);
    DeRef(_s_22559);
    DeRef(_12719);
    _12719 = NOVALUE;
    DeRef(_12699);
    _12699 = NOVALUE;
    DeRef(_12703);
    _12703 = NOVALUE;
    DeRef(_12711);
    _12711 = NOVALUE;
    DeRef(_12732);
    _12732 = NOVALUE;
    DeRef(_12710);
    _12710 = NOVALUE;
    DeRef(_12704);
    _12704 = NOVALUE;
    DeRef(_12720);
    _12720 = NOVALUE;
    DeRef(_12727);
    _12727 = NOVALUE;
    DeRef(_12724);
    _12724 = NOVALUE;
    return _12736;
    goto L3; // [287] 389
L9: 

    /** compress.e:94					return F10B & atom_to_float80( x )*/
    Ref(_x_22557);
    _12737 = _15atom_to_float80(_x_22557);
    if (IS_SEQUENCE(253LL) && IS_ATOM(_12737)) {
    }
    else if (IS_ATOM(253LL) && IS_SEQUENCE(_12737)) {
        Prepend(&_12738, _12737, 253LL);
    }
    else {
        Concat((object_ptr)&_12738, 253LL, _12737);
    }
    DeRef(_12737);
    _12737 = NOVALUE;
    DeRef(_x_22557);
    DeRef(_x4_22558);
    DeRef(_s_22559);
    DeRef(_12719);
    _12719 = NOVALUE;
    DeRef(_12699);
    _12699 = NOVALUE;
    DeRef(_12703);
    _12703 = NOVALUE;
    DeRef(_12711);
    _12711 = NOVALUE;
    DeRef(_12732);
    _12732 = NOVALUE;
    DeRef(_12710);
    _12710 = NOVALUE;
    DeRef(_12704);
    _12704 = NOVALUE;
    DeRef(_12736);
    _12736 = NOVALUE;
    DeRef(_12720);
    _12720 = NOVALUE;
    DeRef(_12727);
    _12727 = NOVALUE;
    DeRef(_12724);
    _12724 = NOVALUE;
    return _12738;
    goto L3; // [306] 389
L7: 

    /** compress.e:100			if length(x) <= 255 then*/
    if (IS_SEQUENCE(_x_22557)){
            _12739 = SEQ_PTR(_x_22557)->length;
    }
    else {
        _12739 = 1;
    }
    if (_12739 > 255LL)
    goto LA; // [314] 330

    /** compress.e:101				s = {S1B, length(x)}*/
    if (IS_SEQUENCE(_x_22557)){
            _12741 = SEQ_PTR(_x_22557)->length;
    }
    else {
        _12741 = 1;
    }
    DeRef(_s_22559);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 254LL;
    ((intptr_t *)_2)[2] = _12741;
    _s_22559 = MAKE_SEQ(_1);
    _12741 = NOVALUE;
    goto LB; // [327] 345
LA: 

    /** compress.e:103				s = S4B & int_to_bytes(length(x))*/
    if (IS_SEQUENCE(_x_22557)){
            _12743 = SEQ_PTR(_x_22557)->length;
    }
    else {
        _12743 = 1;
    }
    _12744 = _15int_to_bytes(_12743, 4LL);
    _12743 = NOVALUE;
    if (IS_SEQUENCE(255LL) && IS_ATOM(_12744)) {
    }
    else if (IS_ATOM(255LL) && IS_SEQUENCE(_12744)) {
        Prepend(&_s_22559, _12744, 255LL);
    }
    else {
        Concat((object_ptr)&_s_22559, 255LL, _12744);
    }
    DeRef(_12744);
    _12744 = NOVALUE;
LB: 

    /** compress.e:105			for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_22557)){
            _12746 = SEQ_PTR(_x_22557)->length;
    }
    else {
        _12746 = 1;
    }
    {
        object _i_22631;
        _i_22631 = 1LL;
LC: 
        if (_i_22631 > _12746){
            goto LD; // [350] 380
        }

        /** compress.e:106				s &= compress(x[i])*/
        _2 = (object)SEQ_PTR(_x_22557);
        _12747 = (object)*(((s1_ptr)_2)->base + _i_22631);
        Ref(_12747);
        _12748 = _60compress(_12747);
        _12747 = NOVALUE;
        if (IS_SEQUENCE(_s_22559) && IS_ATOM(_12748)) {
            Ref(_12748);
            Append(&_s_22559, _s_22559, _12748);
        }
        else if (IS_ATOM(_s_22559) && IS_SEQUENCE(_12748)) {
        }
        else {
            Concat((object_ptr)&_s_22559, _s_22559, _12748);
        }
        DeRef(_12748);
        _12748 = NOVALUE;

        /** compress.e:107			end for*/
        _i_22631 = _i_22631 + 1LL;
        goto LC; // [375] 357
LD: 
        ;
    }

    /** compress.e:108			return s*/
    DeRef(_x_22557);
    DeRef(_x4_22558);
    DeRef(_12719);
    _12719 = NOVALUE;
    DeRef(_12699);
    _12699 = NOVALUE;
    DeRef(_12703);
    _12703 = NOVALUE;
    DeRef(_12711);
    _12711 = NOVALUE;
    DeRef(_12732);
    _12732 = NOVALUE;
    DeRef(_12710);
    _12710 = NOVALUE;
    DeRef(_12704);
    _12704 = NOVALUE;
    DeRef(_12736);
    _12736 = NOVALUE;
    DeRef(_12720);
    _12720 = NOVALUE;
    DeRef(_12727);
    _12727 = NOVALUE;
    DeRef(_12738);
    _12738 = NOVALUE;
    DeRef(_12724);
    _12724 = NOVALUE;
    return _s_22559;
L3: 
    ;
}



// 0x05070711
