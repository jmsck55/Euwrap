// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _24sort(object _x_3947, object _order_3948)
{
    object _gap_3949 = NOVALUE;
    object _j_3950 = NOVALUE;
    object _first_3951 = NOVALUE;
    object _last_3952 = NOVALUE;
    object _tempi_3953 = NOVALUE;
    object _tempj_3954 = NOVALUE;
    object _1936 = NOVALUE;
    object _1932 = NOVALUE;
    object _1929 = NOVALUE;
    object _1925 = NOVALUE;
    object _1922 = NOVALUE;
    object _0, _1, _2;
    

    /** sort.e:72		if order >= 0 then*/

    /** sort.e:73			order = -1*/
    _order_3948 = -1LL;
    goto L1; // [16] 25

    /** sort.e:75			order = 1*/
    _order_3948 = 1LL;
L1: 

    /** sort.e:79		last = length(x)*/
    if (IS_SEQUENCE(_x_3947)){
            _last_3952 = SEQ_PTR(_x_3947)->length;
    }
    else {
        _last_3952 = 1;
    }

    /** sort.e:80		gap = floor(last / 10) + 1*/
    if (10LL > 0 && _last_3952 >= 0) {
        _1922 = _last_3952 / 10LL;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_last_3952 / (eudouble)10LL);
        _1922 = (object)temp_dbl;
    }
    _gap_3949 = _1922 + 1;
    _1922 = NOVALUE;

    /** sort.e:81		while 1 do*/
L2: 

    /** sort.e:82			first = gap + 1*/
    _first_3951 = _gap_3949 + 1;

    /** sort.e:83			for i = first to last do*/
    _1925 = _last_3952;
    {
        object _i_3964;
        _i_3964 = _first_3951;
L3: 
        if (_i_3964 > _1925){
            goto L4; // [56] 152
        }

        /** sort.e:84				tempi = x[i]*/
        DeRef(_tempi_3953);
        _2 = (object)SEQ_PTR(_x_3947);
        _tempi_3953 = (object)*(((s1_ptr)_2)->base + _i_3964);
        Ref(_tempi_3953);

        /** sort.e:85				j = i - gap*/
        _j_3950 = _i_3964 - _gap_3949;

        /** sort.e:86				while 1 do*/
L5: 

        /** sort.e:87					tempj = x[j]*/
        DeRef(_tempj_3954);
        _2 = (object)SEQ_PTR(_x_3947);
        _tempj_3954 = (object)*(((s1_ptr)_2)->base + _j_3950);
        Ref(_tempj_3954);

        /** sort.e:88					if eu:compare(tempi, tempj) != order then*/
        if (IS_ATOM_INT(_tempi_3953) && IS_ATOM_INT(_tempj_3954)){
            _1929 = (_tempi_3953 < _tempj_3954) ? -1 : (_tempi_3953 > _tempj_3954);
        }
        else{
            _1929 = compare(_tempi_3953, _tempj_3954);
        }
        if (_1929 == _order_3948)
        goto L6; // [92] 107

        /** sort.e:89						j += gap*/
        _j_3950 = _j_3950 + _gap_3949;

        /** sort.e:90						exit*/
        goto L7; // [104] 139
L6: 

        /** sort.e:92					x[j+gap] = tempj*/
        _1932 = _j_3950 + _gap_3949;
        Ref(_tempj_3954);
        _2 = (object)SEQ_PTR(_x_3947);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _x_3947 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _1932);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _tempj_3954;
        DeRef(_1);

        /** sort.e:93					if j <= gap then*/
        if (_j_3950 > _gap_3949)
        goto L8; // [119] 128

        /** sort.e:94						exit*/
        goto L7; // [125] 139
L8: 

        /** sort.e:96					j -= gap*/
        _j_3950 = _j_3950 - _gap_3949;

        /** sort.e:97				end while*/
        goto L5; // [136] 80
L7: 

        /** sort.e:98				x[j] = tempi*/
        Ref(_tempi_3953);
        _2 = (object)SEQ_PTR(_x_3947);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _x_3947 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _j_3950);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _tempi_3953;
        DeRef(_1);

        /** sort.e:99			end for*/
        _i_3964 = _i_3964 + 1LL;
        goto L3; // [147] 63
L4: 
        ;
    }

    /** sort.e:100			if gap = 1 then*/
    if (_gap_3949 != 1LL)
    goto L9; // [154] 167

    /** sort.e:101				return x*/
    DeRef(_tempi_3953);
    DeRef(_tempj_3954);
    DeRef(_1932);
    _1932 = NOVALUE;
    return _x_3947;
    goto L2; // [164] 45
L9: 

    /** sort.e:103				gap = floor(gap / 7) + 1*/
    if (7LL > 0 && _gap_3949 >= 0) {
        _1936 = _gap_3949 / 7LL;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_gap_3949 / (eudouble)7LL);
        _1936 = (object)temp_dbl;
    }
    _gap_3949 = _1936 + 1;
    _1936 = NOVALUE;

    /** sort.e:105		end while*/
    goto L2; // [180] 45
    ;
}


object _24custom_sort(object _custom_compare_3985, object _x_3986, object _data_3987, object _order_3988)
{
    object _gap_3989 = NOVALUE;
    object _j_3990 = NOVALUE;
    object _first_3991 = NOVALUE;
    object _last_3992 = NOVALUE;
    object _tempi_3993 = NOVALUE;
    object _tempj_3994 = NOVALUE;
    object _result_3995 = NOVALUE;
    object _args_3996 = NOVALUE;
    object _1964 = NOVALUE;
    object _1960 = NOVALUE;
    object _1957 = NOVALUE;
    object _1955 = NOVALUE;
    object _1954 = NOVALUE;
    object _1949 = NOVALUE;
    object _1946 = NOVALUE;
    object _1942 = NOVALUE;
    object _1940 = NOVALUE;
    object _0, _1, _2;
    

    /** sort.e:253		sequence args = {0, 0}*/
    DeRef(_args_3996);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = 0LL;
    _args_3996 = MAKE_SEQ(_1);

    /** sort.e:255		if order >= 0 then*/

    /** sort.e:256			order = -1*/
    _order_3988 = -1LL;
    goto L1; // [24] 33

    /** sort.e:258			order = 1*/
    _order_3988 = 1LL;
L1: 

    /** sort.e:261		if atom(data) then*/
    _1940 = IS_ATOM(_data_3987);
    if (_1940 == 0)
    {
        _1940 = NOVALUE;
        goto L2; // [38] 50
    }
    else{
        _1940 = NOVALUE;
    }

    /** sort.e:262			args &= data*/
    if (IS_SEQUENCE(_args_3996) && IS_ATOM(_data_3987)) {
        Ref(_data_3987);
        Append(&_args_3996, _args_3996, _data_3987);
    }
    else if (IS_ATOM(_args_3996) && IS_SEQUENCE(_data_3987)) {
    }
    else {
        Concat((object_ptr)&_args_3996, _args_3996, _data_3987);
    }
    goto L3; // [47] 70
L2: 

    /** sort.e:263		elsif length(data) then*/
    _1942 = 0;
L3: 

    /** sort.e:267		last = length(x)*/
    if (IS_SEQUENCE(_x_3986)){
            _last_3992 = SEQ_PTR(_x_3986)->length;
    }
    else {
        _last_3992 = 1;
    }

    /** sort.e:268		gap = floor(last / 10) + 1*/
    if (10LL > 0 && _last_3992 >= 0) {
        _1946 = _last_3992 / 10LL;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_last_3992 / (eudouble)10LL);
        _1946 = (object)temp_dbl;
    }
    _gap_3989 = _1946 + 1;
    _1946 = NOVALUE;

    /** sort.e:269		while 1 do*/
L4: 

    /** sort.e:270			first = gap + 1*/
    _first_3991 = _gap_3989 + 1;

    /** sort.e:271			for i = first to last do*/
    _1949 = _last_3992;
    {
        object _i_4014;
        _i_4014 = _first_3991;
L5: 
        if (_i_4014 > _1949){
            goto L6; // [101] 240
        }

        /** sort.e:272				tempi = x[i]*/
        DeRef(_tempi_3993);
        _2 = (object)SEQ_PTR(_x_3986);
        _tempi_3993 = (object)*(((s1_ptr)_2)->base + _i_4014);
        Ref(_tempi_3993);

        /** sort.e:273				args[1] = tempi*/
        Ref(_tempi_3993);
        _2 = (object)SEQ_PTR(_args_3996);
        _2 = (object)(((s1_ptr)_2)->base + 1LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _tempi_3993;
        DeRef(_1);

        /** sort.e:274				j = i - gap*/
        _j_3990 = _i_4014 - _gap_3989;

        /** sort.e:275				while 1 do*/
L7: 

        /** sort.e:276					tempj = x[j]*/
        DeRef(_tempj_3994);
        _2 = (object)SEQ_PTR(_x_3986);
        _tempj_3994 = (object)*(((s1_ptr)_2)->base + _j_3990);
        Ref(_tempj_3994);

        /** sort.e:277					args[2] = tempj*/
        Ref(_tempj_3994);
        _2 = (object)SEQ_PTR(_args_3996);
        _2 = (object)(((s1_ptr)_2)->base + 2LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _tempj_3994;
        DeRef(_1);

        /** sort.e:278					result = call_func(custom_compare, args)*/
        _1 = (object)SEQ_PTR(_args_3996);
        _2 = (object)((s1_ptr)_1)->base;
        _0 = (object)_00[_custom_compare_3985].addr;
        switch(((s1_ptr)_1)->length) {
            case 0:
                _1 = (*(intptr_t (*)())_0)(
                                     );
                break;
            case 1:
                Ref( *(( (intptr_t*)_2) + 1) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1)
                                     );
                break;
            case 2:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2)
                                     );
                break;
            case 3:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3)
                                     );
                break;
            case 4:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4)
                                     );
                break;
            case 5:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5)
                                     );
                break;
            case 6:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                Ref( *(( (intptr_t*)_2) + 6) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5), 
                                    *( ((intptr_t *)_2) + 6)
                                     );
                break;
            case 7:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                Ref( *(( (intptr_t*)_2) + 6) );
                Ref( *(( (intptr_t*)_2) + 7) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5), 
                                    *( ((intptr_t *)_2) + 6), 
                                    *( ((intptr_t *)_2) + 7)
                                     );
                break;
            case 8:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                Ref( *(( (intptr_t*)_2) + 6) );
                Ref( *(( (intptr_t*)_2) + 7) );
                Ref( *(( (intptr_t*)_2) + 8) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5), 
                                    *( ((intptr_t *)_2) + 6), 
                                    *( ((intptr_t *)_2) + 7), 
                                    *( ((intptr_t *)_2) + 8)
                                     );
                break;
            case 9:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                Ref( *(( (intptr_t*)_2) + 6) );
                Ref( *(( (intptr_t*)_2) + 7) );
                Ref( *(( (intptr_t*)_2) + 8) );
                Ref( *(( (intptr_t*)_2) + 9) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5), 
                                    *( ((intptr_t *)_2) + 6), 
                                    *( ((intptr_t *)_2) + 7), 
                                    *( ((intptr_t *)_2) + 8), 
                                    *( ((intptr_t *)_2) + 9)
                                     );
                break;
            case 10:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                Ref( *(( (intptr_t*)_2) + 6) );
                Ref( *(( (intptr_t*)_2) + 7) );
                Ref( *(( (intptr_t*)_2) + 8) );
                Ref( *(( (intptr_t*)_2) + 9) );
                Ref( *(( (intptr_t*)_2) + 10) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5), 
                                    *( ((intptr_t *)_2) + 6), 
                                    *( ((intptr_t *)_2) + 7), 
                                    *( ((intptr_t *)_2) + 8), 
                                    *( ((intptr_t *)_2) + 9), 
                                    *( ((intptr_t *)_2) + 10)
                                     );
                break;
            case 11:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                Ref( *(( (intptr_t*)_2) + 6) );
                Ref( *(( (intptr_t*)_2) + 7) );
                Ref( *(( (intptr_t*)_2) + 8) );
                Ref( *(( (intptr_t*)_2) + 9) );
                Ref( *(( (intptr_t*)_2) + 10) );
                Ref( *(( (intptr_t*)_2) + 11) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5), 
                                    *( ((intptr_t *)_2) + 6), 
                                    *( ((intptr_t *)_2) + 7), 
                                    *( ((intptr_t *)_2) + 8), 
                                    *( ((intptr_t *)_2) + 9), 
                                    *( ((intptr_t *)_2) + 10), 
                                    *( ((intptr_t *)_2) + 11)
                                     );
                break;
            case 12:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                Ref( *(( (intptr_t*)_2) + 6) );
                Ref( *(( (intptr_t*)_2) + 7) );
                Ref( *(( (intptr_t*)_2) + 8) );
                Ref( *(( (intptr_t*)_2) + 9) );
                Ref( *(( (intptr_t*)_2) + 10) );
                Ref( *(( (intptr_t*)_2) + 11) );
                Ref( *(( (intptr_t*)_2) + 12) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5), 
                                    *( ((intptr_t *)_2) + 6), 
                                    *( ((intptr_t *)_2) + 7), 
                                    *( ((intptr_t *)_2) + 8), 
                                    *( ((intptr_t *)_2) + 9), 
                                    *( ((intptr_t *)_2) + 10), 
                                    *( ((intptr_t *)_2) + 11), 
                                    *( ((intptr_t *)_2) + 12)
                                     );
                break;
        }
        DeRef(_result_3995);
        _result_3995 = _1;

        /** sort.e:279					if sequence(result) then*/
        _1954 = IS_SEQUENCE(_result_3995);
        if (_1954 == 0)
        {
            _1954 = NOVALUE;
            goto L8; // [154] 174
        }
        else{
            _1954 = NOVALUE;
        }

        /** sort.e:280						args[3] = result[2]*/
        _2 = (object)SEQ_PTR(_result_3995);
        _1955 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_1955);
        _2 = (object)SEQ_PTR(_args_3996);
        _2 = (object)(((s1_ptr)_2)->base + 3LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _1955;
        if( _1 != _1955 ){
            DeRef(_1);
        }
        _1955 = NOVALUE;

        /** sort.e:281						result = result[1]*/
        _0 = _result_3995;
        _2 = (object)SEQ_PTR(_result_3995);
        _result_3995 = (object)*(((s1_ptr)_2)->base + 1LL);
        Ref(_result_3995);
        DeRef(_0);
L8: 

        /** sort.e:283					if eu:compare(result, 0) != order then*/
        if (IS_ATOM_INT(_result_3995) && IS_ATOM_INT(0LL)){
            _1957 = (_result_3995 < 0LL) ? -1 : (_result_3995 > 0LL);
        }
        else{
            _1957 = compare(_result_3995, 0LL);
        }
        if (_1957 == _order_3988)
        goto L9; // [180] 195

        /** sort.e:284						j += gap*/
        _j_3990 = _j_3990 + _gap_3989;

        /** sort.e:285						exit*/
        goto LA; // [192] 227
L9: 

        /** sort.e:287					x[j+gap] = tempj*/
        _1960 = _j_3990 + _gap_3989;
        Ref(_tempj_3994);
        _2 = (object)SEQ_PTR(_x_3986);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _x_3986 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _1960);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _tempj_3994;
        DeRef(_1);

        /** sort.e:288					if j <= gap then*/
        if (_j_3990 > _gap_3989)
        goto LB; // [207] 216

        /** sort.e:289						exit*/
        goto LA; // [213] 227
LB: 

        /** sort.e:291					j -= gap*/
        _j_3990 = _j_3990 - _gap_3989;

        /** sort.e:292				end while*/
        goto L7; // [224] 131
LA: 

        /** sort.e:293				x[j] = tempi*/
        Ref(_tempi_3993);
        _2 = (object)SEQ_PTR(_x_3986);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _x_3986 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _j_3990);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _tempi_3993;
        DeRef(_1);

        /** sort.e:294			end for*/
        _i_4014 = _i_4014 + 1LL;
        goto L5; // [235] 108
L6: 
        ;
    }

    /** sort.e:295			if gap = 1 then*/
    if (_gap_3989 != 1LL)
    goto LC; // [242] 255

    /** sort.e:296				return x*/
    DeRef(_data_3987);
    DeRef(_tempi_3993);
    DeRef(_tempj_3994);
    DeRef(_result_3995);
    DeRef(_args_3996);
    DeRef(_1960);
    _1960 = NOVALUE;
    return _x_3986;
    goto L4; // [252] 90
LC: 

    /** sort.e:298				gap = floor(gap / 7) + 1*/
    if (7LL > 0 && _gap_3989 >= 0) {
        _1964 = _gap_3989 / 7LL;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_gap_3989 / (eudouble)7LL);
        _1964 = (object)temp_dbl;
    }
    _gap_3989 = _1964 + 1;
    _1964 = NOVALUE;

    /** sort.e:300		end while*/
    goto L4; // [268] 90
    ;
}


object _24column_compare(object _a_4040, object _b_4041, object _cols_4042)
{
    object _sign_4043 = NOVALUE;
    object _column_4044 = NOVALUE;
    object _1987 = NOVALUE;
    object _1985 = NOVALUE;
    object _1984 = NOVALUE;
    object _1983 = NOVALUE;
    object _1982 = NOVALUE;
    object _1981 = NOVALUE;
    object _1980 = NOVALUE;
    object _1978 = NOVALUE;
    object _1977 = NOVALUE;
    object _1976 = NOVALUE;
    object _1974 = NOVALUE;
    object _1972 = NOVALUE;
    object _1969 = NOVALUE;
    object _1967 = NOVALUE;
    object _1966 = NOVALUE;
    object _0, _1, _2;
    

    /** sort.e:309		for i = 1 to length(cols) do*/
    if (IS_SEQUENCE(_cols_4042)){
            _1966 = SEQ_PTR(_cols_4042)->length;
    }
    else {
        _1966 = 1;
    }
    {
        object _i_4046;
        _i_4046 = 1LL;
L1: 
        if (_i_4046 > _1966){
            goto L2; // [6] 176
        }

        /** sort.e:310			if cols[i] < 0 then*/
        _2 = (object)SEQ_PTR(_cols_4042);
        _1967 = (object)*(((s1_ptr)_2)->base + _i_4046);
        if (binary_op_a(GREATEREQ, _1967, 0LL)){
            _1967 = NOVALUE;
            goto L3; // [19] 42
        }
        _1967 = NOVALUE;

        /** sort.e:311				sign = -1*/
        _sign_4043 = -1LL;

        /** sort.e:312				column = -cols[i]*/
        _2 = (object)SEQ_PTR(_cols_4042);
        _1969 = (object)*(((s1_ptr)_2)->base + _i_4046);
        if (IS_ATOM_INT(_1969)) {
            if ((uintptr_t)_1969 == (uintptr_t)HIGH_BITS){
                _column_4044 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _column_4044 = - _1969;
            }
        }
        else {
            _column_4044 = unary_op(UMINUS, _1969);
        }
        _1969 = NOVALUE;
        if (!IS_ATOM_INT(_column_4044)) {
            _1 = (object)(DBL_PTR(_column_4044)->dbl);
            DeRefDS(_column_4044);
            _column_4044 = _1;
        }
        goto L4; // [39] 56
L3: 

        /** sort.e:314				sign = 1*/
        _sign_4043 = 1LL;

        /** sort.e:315				column = cols[i]*/
        _2 = (object)SEQ_PTR(_cols_4042);
        _column_4044 = (object)*(((s1_ptr)_2)->base + _i_4046);
        if (!IS_ATOM_INT(_column_4044)){
            _column_4044 = (object)DBL_PTR(_column_4044)->dbl;
        }
L4: 

        /** sort.e:317			if column <= length(a) then*/
        if (IS_SEQUENCE(_a_4040)){
                _1972 = SEQ_PTR(_a_4040)->length;
        }
        else {
            _1972 = 1;
        }
        if (_column_4044 > _1972)
        goto L5; // [63] 137

        /** sort.e:318				if column <= length(b) then*/
        if (IS_SEQUENCE(_b_4041)){
                _1974 = SEQ_PTR(_b_4041)->length;
        }
        else {
            _1974 = 1;
        }
        if (_column_4044 > _1974)
        goto L6; // [72] 121

        /** sort.e:319					if not equal(a[column], b[column]) then*/
        _2 = (object)SEQ_PTR(_a_4040);
        _1976 = (object)*(((s1_ptr)_2)->base + _column_4044);
        _2 = (object)SEQ_PTR(_b_4041);
        _1977 = (object)*(((s1_ptr)_2)->base + _column_4044);
        if (_1976 == _1977)
        _1978 = 1;
        else if (IS_ATOM_INT(_1976) && IS_ATOM_INT(_1977))
        _1978 = 0;
        else
        _1978 = (compare(_1976, _1977) == 0);
        _1976 = NOVALUE;
        _1977 = NOVALUE;
        if (_1978 != 0)
        goto L7; // [90] 169
        _1978 = NOVALUE;

        /** sort.e:320						return sign * eu:compare(a[column], b[column])*/
        _2 = (object)SEQ_PTR(_a_4040);
        _1980 = (object)*(((s1_ptr)_2)->base + _column_4044);
        _2 = (object)SEQ_PTR(_b_4041);
        _1981 = (object)*(((s1_ptr)_2)->base + _column_4044);
        if (IS_ATOM_INT(_1980) && IS_ATOM_INT(_1981)){
            _1982 = (_1980 < _1981) ? -1 : (_1980 > _1981);
        }
        else{
            _1982 = compare(_1980, _1981);
        }
        _1980 = NOVALUE;
        _1981 = NOVALUE;
        {
            int128_t p128 = (int128_t)_sign_4043 * (int128_t)_1982;
            if( p128 != (int128_t)(_1983 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _1983 = NewDouble( (eudouble)p128 );
            }
        }
        _1982 = NOVALUE;
        DeRef(_a_4040);
        DeRef(_b_4041);
        DeRef(_cols_4042);
        return _1983;
        goto L7; // [118] 169
L6: 

        /** sort.e:323					return sign * -1*/
        {
            int128_t p128 = (int128_t)_sign_4043 * (int128_t)-1LL;
            if( p128 != (int128_t)(_1984 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _1984 = NewDouble( (eudouble)p128 );
            }
        }
        DeRef(_a_4040);
        DeRef(_b_4041);
        DeRef(_cols_4042);
        DeRef(_1983);
        _1983 = NOVALUE;
        return _1984;
        goto L7; // [134] 169
L5: 

        /** sort.e:326				if column <= length(b) then*/
        if (IS_SEQUENCE(_b_4041)){
                _1985 = SEQ_PTR(_b_4041)->length;
        }
        else {
            _1985 = 1;
        }
        if (_column_4044 > _1985)
        goto L8; // [142] 161

        /** sort.e:327					return sign * 1*/
        _1987 = _sign_4043 * 1LL;
        DeRef(_a_4040);
        DeRef(_b_4041);
        DeRef(_cols_4042);
        DeRef(_1983);
        _1983 = NOVALUE;
        DeRef(_1984);
        _1984 = NOVALUE;
        return _1987;
        goto L9; // [158] 168
L8: 

        /** sort.e:329					return 0*/
        DeRef(_a_4040);
        DeRef(_b_4041);
        DeRef(_cols_4042);
        DeRef(_1983);
        _1983 = NOVALUE;
        DeRef(_1987);
        _1987 = NOVALUE;
        DeRef(_1984);
        _1984 = NOVALUE;
        return 0LL;
L9: 
L7: 

        /** sort.e:332		end for*/
        _i_4046 = _i_4046 + 1LL;
        goto L1; // [171] 13
L2: 
        ;
    }

    /** sort.e:333		return 0*/
    DeRef(_a_4040);
    DeRef(_b_4041);
    DeRef(_cols_4042);
    DeRef(_1983);
    _1983 = NOVALUE;
    DeRef(_1987);
    _1987 = NOVALUE;
    DeRef(_1984);
    _1984 = NOVALUE;
    return 0LL;
    ;
}



// 0x59D10CFA
