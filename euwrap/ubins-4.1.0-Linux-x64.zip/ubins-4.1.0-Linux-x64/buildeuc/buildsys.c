// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _56find_file(object _fname_45311)
{
    object _23578 = NOVALUE;
    object _23577 = NOVALUE;
    object _23576 = NOVALUE;
    object _23575 = NOVALUE;
    object _23573 = NOVALUE;
    object _23572 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:30		for i = 1 to length(inc_dirs) do*/
    _23572 = 3;
    {
        object _i_45313;
        _i_45313 = 1LL;
L1: 
        if (_i_45313 > 3LL){
            goto L2; // [10] 64
        }

        /** buildsys.e:31			if file_exists(inc_dirs[i] & "/" & fname) then*/
        _2 = (object)SEQ_PTR(_56inc_dirs_45303);
        _23573 = (object)*(((s1_ptr)_2)->base + _i_45313);
        {
            object concat_list[3];

            concat_list[0] = _fname_45311;
            concat_list[1] = _23574;
            concat_list[2] = _23573;
            Concat_N((object_ptr)&_23575, concat_list, 3);
        }
        _23573 = NOVALUE;
        _23576 = _17file_exists(_23575);
        _23575 = NOVALUE;
        if (_23576 == 0) {
            DeRef(_23576);
            _23576 = NOVALUE;
            goto L3; // [35] 57
        }
        else {
            if (!IS_ATOM_INT(_23576) && DBL_PTR(_23576)->dbl == 0.0){
                DeRef(_23576);
                _23576 = NOVALUE;
                goto L3; // [35] 57
            }
            DeRef(_23576);
            _23576 = NOVALUE;
        }
        DeRef(_23576);
        _23576 = NOVALUE;

        /** buildsys.e:32				return inc_dirs[i] & "/" & fname*/
        _2 = (object)SEQ_PTR(_56inc_dirs_45303);
        _23577 = (object)*(((s1_ptr)_2)->base + _i_45313);
        {
            object concat_list[3];

            concat_list[0] = _fname_45311;
            concat_list[1] = _23574;
            concat_list[2] = _23577;
            Concat_N((object_ptr)&_23578, concat_list, 3);
        }
        _23577 = NOVALUE;
        DeRefDS(_fname_45311);
        return _23578;
L3: 

        /** buildsys.e:34		end for*/
        _i_45313 = _i_45313 + 1LL;
        goto L1; // [59] 17
L2: 
        ;
    }

    /** buildsys.e:36		return 0*/
    DeRefDS(_fname_45311);
    DeRef(_23578);
    _23578 = NOVALUE;
    return 0LL;
    ;
}


object _56find_all_includes(object _fname_45325, object _includes_45326)
{
    object _lines_45327 = NOVALUE;
    object _m_45333 = NOVALUE;
    object _full_fname_45338 = NOVALUE;
    object _23591 = NOVALUE;
    object _23589 = NOVALUE;
    object _23587 = NOVALUE;
    object _23586 = NOVALUE;
    object _23584 = NOVALUE;
    object _23583 = NOVALUE;
    object _23581 = NOVALUE;
    object _23580 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:40		sequence lines = read_lines(fname)*/
    RefDS(_fname_45325);
    _0 = _lines_45327;
    _lines_45327 = _8read_lines(_fname_45325);
    DeRef(_0);

    /** buildsys.e:42		for i = 1 to length(lines) do*/
    if (IS_SEQUENCE(_lines_45327)){
            _23580 = SEQ_PTR(_lines_45327)->length;
    }
    else {
        _23580 = 1;
    }
    {
        object _i_45331;
        _i_45331 = 1LL;
L1: 
        if (_i_45331 > _23580){
            goto L2; // [18] 113
        }

        /** buildsys.e:43			object m = regex:matches(re_include, lines[i])*/
        _2 = (object)SEQ_PTR(_lines_45327);
        _23581 = (object)*(((s1_ptr)_2)->base + _i_45331);
        Ref(_56re_include_45300);
        Ref(_23581);
        _0 = _m_45333;
        _m_45333 = _52matches(_56re_include_45300, _23581, 1LL, 0LL);
        DeRef(_0);
        _23581 = NOVALUE;

        /** buildsys.e:44			if sequence(m) then*/
        _23583 = IS_SEQUENCE(_m_45333);
        if (_23583 == 0)
        {
            _23583 = NOVALUE;
            goto L3; // [45] 102
        }
        else{
            _23583 = NOVALUE;
        }

        /** buildsys.e:45				object full_fname = find_file(m[3])*/
        _2 = (object)SEQ_PTR(_m_45333);
        _23584 = (object)*(((s1_ptr)_2)->base + 3LL);
        Ref(_23584);
        _0 = _full_fname_45338;
        _full_fname_45338 = _56find_file(_23584);
        DeRef(_0);
        _23584 = NOVALUE;

        /** buildsys.e:46				if sequence(full_fname) then*/
        _23586 = IS_SEQUENCE(_full_fname_45338);
        if (_23586 == 0)
        {
            _23586 = NOVALUE;
            goto L4; // [63] 101
        }
        else{
            _23586 = NOVALUE;
        }

        /** buildsys.e:47					if eu:find(full_fname, includes) = 0 then*/
        _23587 = find_from(_full_fname_45338, _includes_45326, 1LL);
        if (_23587 != 0LL)
        goto L5; // [73] 100

        /** buildsys.e:48						includes &= { full_fname }*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_full_fname_45338);
        ((intptr_t*)_2)[1] = _full_fname_45338;
        _23589 = MAKE_SEQ(_1);
        Concat((object_ptr)&_includes_45326, _includes_45326, _23589);
        DeRefDS(_23589);
        _23589 = NOVALUE;

        /** buildsys.e:49						includes = find_all_includes(full_fname, includes)*/
        RefDS(_includes_45326);
        DeRef(_23591);
        _23591 = _includes_45326;
        Ref(_full_fname_45338);
        _0 = _includes_45326;
        _includes_45326 = _56find_all_includes(_full_fname_45338, _23591);
        DeRefDS(_0);
        _23591 = NOVALUE;
L5: 
L4: 
L3: 
        DeRef(_full_fname_45338);
        _full_fname_45338 = NOVALUE;
        DeRef(_m_45333);
        _m_45333 = NOVALUE;

        /** buildsys.e:53		end for*/
        _i_45331 = _i_45331 + 1LL;
        goto L1; // [108] 25
L2: 
        ;
    }

    /** buildsys.e:55		return includes*/
    DeRefDS(_fname_45325);
    DeRef(_lines_45327);
    return _includes_45326;
    ;
}


object _56quick_has_changed(object _fname_45352)
{
    object _d1_45353 = NOVALUE;
    object _all_files_45363 = NOVALUE;
    object _d2_45369 = NOVALUE;
    object _diff_2__tmp_at88_45379 = NOVALUE;
    object _diff_1__tmp_at88_45378 = NOVALUE;
    object _diff_inlined_diff_at_88_45377 = NOVALUE;
    object _23603 = NOVALUE;
    object _23601 = NOVALUE;
    object _23600 = NOVALUE;
    object _23598 = NOVALUE;
    object _23597 = NOVALUE;
    object _23595 = NOVALUE;
    object _23593 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:59		object d1 = file_timestamp(output_dir & filebase(fname) & ".bld")*/
    RefDS(_fname_45352);
    _23593 = _17filebase(_fname_45352);
    {
        object concat_list[3];

        concat_list[0] = _23594;
        concat_list[1] = _23593;
        concat_list[2] = _58output_dir_42577;
        Concat_N((object_ptr)&_23595, concat_list, 3);
    }
    DeRef(_23593);
    _23593 = NOVALUE;
    _0 = _d1_45353;
    _d1_45353 = _17file_timestamp(_23595);
    DeRef(_0);
    _23595 = NOVALUE;

    /** buildsys.e:61		if atom(d1) then*/
    _23597 = IS_ATOM(_d1_45353);
    if (_23597 == 0)
    {
        _23597 = NOVALUE;
        goto L1; // [26] 36
    }
    else{
        _23597 = NOVALUE;
    }

    /** buildsys.e:62			return 1*/
    DeRefDS(_fname_45352);
    DeRef(_d1_45353);
    DeRef(_all_files_45363);
    return 1LL;
L1: 

    /** buildsys.e:65		sequence all_files = append(find_all_includes(fname), fname)*/
    RefDS(_fname_45352);
    RefDS(_21993);
    _23598 = _56find_all_includes(_fname_45352, _21993);
    RefDS(_fname_45352);
    Append(&_all_files_45363, _23598, _fname_45352);
    DeRef(_23598);
    _23598 = NOVALUE;

    /** buildsys.e:66		for i = 1 to length(all_files) do*/
    if (IS_SEQUENCE(_all_files_45363)){
            _23600 = SEQ_PTR(_all_files_45363)->length;
    }
    else {
        _23600 = 1;
    }
    {
        object _i_45367;
        _i_45367 = 1LL;
L2: 
        if (_i_45367 > _23600){
            goto L3; // [52] 123
        }

        /** buildsys.e:67			object d2 = file_timestamp(all_files[i])*/
        _2 = (object)SEQ_PTR(_all_files_45363);
        _23601 = (object)*(((s1_ptr)_2)->base + _i_45367);
        Ref(_23601);
        _0 = _d2_45369;
        _d2_45369 = _17file_timestamp(_23601);
        DeRef(_0);
        _23601 = NOVALUE;

        /** buildsys.e:68			if atom(d2) then*/
        _23603 = IS_ATOM(_d2_45369);
        if (_23603 == 0)
        {
            _23603 = NOVALUE;
            goto L4; // [74] 84
        }
        else{
            _23603 = NOVALUE;
        }

        /** buildsys.e:69				return 1*/
        DeRef(_d2_45369);
        DeRefDS(_fname_45352);
        DeRef(_d1_45353);
        DeRefDS(_all_files_45363);
        return 1LL;
L4: 

        /** buildsys.e:71			if datetime:diff(d1, d2) > 0 then*/

        /** datetime.e:1253		return datetimeToSeconds(dt2) - datetimeToSeconds(dt1)*/
        Ref(_d2_45369);
        _0 = _diff_1__tmp_at88_45378;
        _diff_1__tmp_at88_45378 = _18datetimeToSeconds(_d2_45369);
        DeRef(_0);
        Ref(_d1_45353);
        _0 = _diff_2__tmp_at88_45379;
        _diff_2__tmp_at88_45379 = _18datetimeToSeconds(_d1_45353);
        DeRef(_0);
        DeRef(_diff_inlined_diff_at_88_45377);
        if (IS_ATOM_INT(_diff_1__tmp_at88_45378) && IS_ATOM_INT(_diff_2__tmp_at88_45379)) {
            _diff_inlined_diff_at_88_45377 = _diff_1__tmp_at88_45378 - _diff_2__tmp_at88_45379;
            if ((object)((uintptr_t)_diff_inlined_diff_at_88_45377 +(uintptr_t) HIGH_BITS) >= 0){
                _diff_inlined_diff_at_88_45377 = NewDouble((eudouble)_diff_inlined_diff_at_88_45377);
            }
        }
        else {
            _diff_inlined_diff_at_88_45377 = binary_op(MINUS, _diff_1__tmp_at88_45378, _diff_2__tmp_at88_45379);
        }
        DeRef(_diff_1__tmp_at88_45378);
        _diff_1__tmp_at88_45378 = NOVALUE;
        DeRef(_diff_2__tmp_at88_45379);
        _diff_2__tmp_at88_45379 = NOVALUE;
        if (binary_op_a(LESSEQ, _diff_inlined_diff_at_88_45377, 0LL)){
            goto L5; // [103] 114
        }

        /** buildsys.e:72				return 1*/
        DeRef(_d2_45369);
        DeRefDS(_fname_45352);
        DeRef(_d1_45353);
        DeRef(_all_files_45363);
        return 1LL;
L5: 
        DeRef(_d2_45369);
        _d2_45369 = NOVALUE;

        /** buildsys.e:74		end for*/
        _i_45367 = _i_45367 + 1LL;
        goto L2; // [118] 59
L3: 
        ;
    }

    /** buildsys.e:76		return 0*/
    DeRefDS(_fname_45352);
    DeRef(_d1_45353);
    DeRef(_all_files_45363);
    return 0LL;
    ;
}


void _56update_checksum(object _raw_data_45425)
{
    object _23611 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:213		cfile_check = xor_bits(cfile_check, hash( raw_data, stdhash:HSIEH32))*/
    _23611 = calc_hash(_raw_data_45425, -5LL);
    _0 = _56cfile_check_45406;
    if (IS_ATOM_INT(_56cfile_check_45406) && IS_ATOM_INT(_23611)) {
        {uintptr_t tu;
             tu = (uintptr_t)_56cfile_check_45406 ^ (uintptr_t)_23611;
             _56cfile_check_45406 = MAKE_UINT(tu);
        }
    }
    else {
        if (IS_ATOM_INT(_56cfile_check_45406)) {
            temp_d.dbl = (eudouble)_56cfile_check_45406;
            _56cfile_check_45406 = Dxor_bits(&temp_d, DBL_PTR(_23611));
        }
        else {
            if (IS_ATOM_INT(_23611)) {
                temp_d.dbl = (eudouble)_23611;
                _56cfile_check_45406 = Dxor_bits(DBL_PTR(_56cfile_check_45406), &temp_d);
            }
            else
            _56cfile_check_45406 = Dxor_bits(DBL_PTR(_56cfile_check_45406), DBL_PTR(_23611));
        }
    }
    DeRef(_0);
    DeRef(_23611);
    _23611 = NOVALUE;

    /** buildsys.e:214	end procedure*/
    DeRef(_raw_data_45425);
    return;
    ;
}


void _56write_checksum(object _file_45430)
{
    object _0, _1, _2;
    

    /** buildsys.e:219		printf( file, "\n// 0x%08x\n", cfile_check )*/
    EPrintf(_file_45430, _23613, _56cfile_check_45406);

    /** buildsys.e:220		cfile_check = 0*/
    DeRef(_56cfile_check_45406);
    _56cfile_check_45406 = 0LL;

    /** buildsys.e:221	end procedure*/
    return;
    ;
}


object _56adjust_for_command_line_passing(object _long_path_45478)
{
    object _slash_45479 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:310		if compiler_type = COMPILER_GCC then*/
    if (_56compiler_type_45389 != 1LL)
    goto L1; // [7] 19

    /** buildsys.e:311			slash = '/'*/
    _slash_45479 = 47LL;
    goto L2; // [16] 45
L1: 

    /** buildsys.e:312		elsif compiler_type = COMPILER_WATCOM then*/
    if (_56compiler_type_45389 != 2LL)
    goto L3; // [23] 35

    /** buildsys.e:313			slash = '\\'*/
    _slash_45479 = 92LL;
    goto L2; // [32] 45
L3: 

    /** buildsys.e:315			slash = SLASH*/
    _slash_45479 = 47LL;
L2: 

    /** buildsys.e:317		ifdef UNIX then*/

    /** buildsys.e:318			return long_path*/
    return _long_path_45478;
    ;
}


object _56adjust_for_build_file(object _long_path_45488)
{
    object _short_path_45489 = NOVALUE;
    object _23643 = NOVALUE;
    object _23642 = NOVALUE;
    object _23641 = NOVALUE;
    object _23640 = NOVALUE;
    object _23639 = NOVALUE;
    object _23638 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:355	    object short_path = adjust_for_command_line_passing(long_path)*/
    RefDS(_long_path_45488);
    _0 = _short_path_45489;
    _short_path_45489 = _56adjust_for_command_line_passing(_long_path_45488);
    DeRef(_0);

    /** buildsys.e:356	    if atom(short_path) then*/
    _23638 = IS_ATOM(_short_path_45489);
    if (_23638 == 0)
    {
        _23638 = NOVALUE;
        goto L1; // [14] 24
    }
    else{
        _23638 = NOVALUE;
    }

    /** buildsys.e:357	    	return short_path*/
    DeRefDS(_long_path_45488);
    return _short_path_45489;
L1: 

    /** buildsys.e:359		if compiler_type = COMPILER_GCC and build_system_type != BUILD_DIRECT and TWINDOWS then*/
    _23639 = (_56compiler_type_45389 == 1LL);
    if (_23639 == 0) {
        _23640 = 0;
        goto L2; // [32] 46
    }
    _23641 = (_56build_system_type_45385 != 3LL);
    _23640 = (_23641 != 0);
L2: 
    if (_23640 == 0) {
        goto L3; // [46] 69
    }
    if (_46TWINDOWS_21586 == 0)
    {
        goto L3; // [53] 69
    }
    else{
    }

    /** buildsys.e:360			return windows_to_mingw_path(short_path)*/
    Ref(_short_path_45489);
    _23643 = _56windows_to_mingw_path(_short_path_45489);
    DeRefDS(_long_path_45488);
    DeRef(_short_path_45489);
    DeRef(_23641);
    _23641 = NOVALUE;
    DeRef(_23639);
    _23639 = NOVALUE;
    return _23643;
    goto L4; // [66] 76
L3: 

    /** buildsys.e:362			return short_path*/
    DeRefDS(_long_path_45488);
    DeRef(_23641);
    _23641 = NOVALUE;
    DeRef(_23639);
    _23639 = NOVALUE;
    DeRef(_23643);
    _23643 = NOVALUE;
    return _short_path_45489;
L4: 
    ;
}


object _56setup_build()
{
    object _c_exe_45504 = NOVALUE;
    object _c_flags_45505 = NOVALUE;
    object _l_exe_45506 = NOVALUE;
    object _l_flags_45507 = NOVALUE;
    object _obj_ext_45508 = NOVALUE;
    object _exe_ext_45509 = NOVALUE;
    object _l_flags_begin_45510 = NOVALUE;
    object _rc_comp_45511 = NOVALUE;
    object _l_names_45512 = NOVALUE;
    object _l_ext_45513 = NOVALUE;
    object _t_slash_45514 = NOVALUE;
    object _eudir_45556 = NOVALUE;
    object _locations_45581 = NOVALUE;
    object _compile_dir_45633 = NOVALUE;
    object _bits_45644 = NOVALUE;
    object _m_flag_45654 = NOVALUE;
    object _23812 = NOVALUE;
    object _23810 = NOVALUE;
    object _23809 = NOVALUE;
    object _23808 = NOVALUE;
    object _23806 = NOVALUE;
    object _23805 = NOVALUE;
    object _23804 = NOVALUE;
    object _23801 = NOVALUE;
    object _23800 = NOVALUE;
    object _23797 = NOVALUE;
    object _23796 = NOVALUE;
    object _23789 = NOVALUE;
    object _23788 = NOVALUE;
    object _23783 = NOVALUE;
    object _23782 = NOVALUE;
    object _23777 = NOVALUE;
    object _23776 = NOVALUE;
    object _23773 = NOVALUE;
    object _23772 = NOVALUE;
    object _23760 = NOVALUE;
    object _23759 = NOVALUE;
    object _23744 = NOVALUE;
    object _23743 = NOVALUE;
    object _23740 = NOVALUE;
    object _23735 = NOVALUE;
    object _23733 = NOVALUE;
    object _23732 = NOVALUE;
    object _23731 = NOVALUE;
    object _23730 = NOVALUE;
    object _23726 = NOVALUE;
    object _23725 = NOVALUE;
    object _23711 = NOVALUE;
    object _23710 = NOVALUE;
    object _23707 = NOVALUE;
    object _23695 = NOVALUE;
    object _23693 = NOVALUE;
    object _23692 = NOVALUE;
    object _23691 = NOVALUE;
    object _23690 = NOVALUE;
    object _23689 = NOVALUE;
    object _23688 = NOVALUE;
    object _23687 = NOVALUE;
    object _23686 = NOVALUE;
    object _23685 = NOVALUE;
    object _23684 = NOVALUE;
    object _23679 = NOVALUE;
    object _23676 = NOVALUE;
    object _23675 = NOVALUE;
    object _23674 = NOVALUE;
    object _23671 = NOVALUE;
    object _23670 = NOVALUE;
    object _23669 = NOVALUE;
    object _23666 = NOVALUE;
    object _23662 = NOVALUE;
    object _23661 = NOVALUE;
    object _23659 = NOVALUE;
    object _23658 = NOVALUE;
    object _23657 = NOVALUE;
    object _23656 = NOVALUE;
    object _23649 = NOVALUE;
    object _23648 = NOVALUE;
    object _23647 = NOVALUE;
    object _23646 = NOVALUE;
    object _23645 = NOVALUE;
    object _23644 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:373			c_exe   = "",*/
    RefDS(_21993);
    DeRef(_c_exe_45504);
    _c_exe_45504 = _21993;

    /** buildsys.e:374			c_flags = "",*/
    RefDS(_21993);
    DeRef(_c_flags_45505);
    _c_flags_45505 = _21993;

    /** buildsys.e:375			l_exe   = "",*/
    RefDS(_21993);
    DeRef(_l_exe_45506);
    _l_exe_45506 = _21993;

    /** buildsys.e:376			l_flags = "",*/
    RefDS(_21993);
    DeRef(_l_flags_45507);
    _l_flags_45507 = _21993;

    /** buildsys.e:377			obj_ext = "",*/
    RefDS(_21993);
    DeRefi(_obj_ext_45508);
    _obj_ext_45508 = _21993;

    /** buildsys.e:378			exe_ext = "",*/
    RefDS(_21993);
    DeRefi(_exe_ext_45509);
    _exe_ext_45509 = _21993;

    /** buildsys.e:379			l_flags_begin = "",*/
    RefDS(_21993);
    DeRefi(_l_flags_begin_45510);
    _l_flags_begin_45510 = _21993;

    /** buildsys.e:380			rc_comp = "",*/
    RefDS(_21993);
    DeRef(_rc_comp_45511);
    _rc_comp_45511 = _21993;

    /** buildsys.e:385		if dll_option*/
    if (_58dll_option_42563 == 0) {
        _23644 = 0;
        goto L1; // [61] 78
    }
    if (IS_SEQUENCE(_58user_pic_library_42576)){
            _23645 = SEQ_PTR(_58user_pic_library_42576)->length;
    }
    else {
        _23645 = 1;
    }
    _23646 = (_23645 > 0LL);
    _23645 = NOVALUE;
    _23644 = (_23646 != 0);
L1: 
    if (_23644 == 0) {
        goto L2; // [78] 101
    }
    _23648 = (_46TWINDOWS_21586 == 0);
    if (_23648 == 0)
    {
        DeRef(_23648);
        _23648 = NOVALUE;
        goto L2; // [88] 101
    }
    else{
        DeRef(_23648);
        _23648 = NOVALUE;
    }

    /** buildsys.e:388			user_library = user_pic_library*/
    RefDS(_58user_pic_library_42576);
    DeRef(_58user_library_42575);
    _58user_library_42575 = _58user_pic_library_42576;
L2: 

    /** buildsys.e:391		if length(user_library) = 0 then*/
    if (IS_SEQUENCE(_58user_library_42575)){
            _23649 = SEQ_PTR(_58user_library_42575)->length;
    }
    else {
        _23649 = 1;
    }
    if (_23649 != 0LL)
    goto L3; // [108] 456

    /** buildsys.e:392			if debug_option then*/
    if (_58debug_option_42573 == 0)
    {
        goto L4; // [116] 128
    }
    else{
    }

    /** buildsys.e:393				l_names = { "eudbg", "eu" }*/
    RefDS(_23652);
    RefDS(_23651);
    DeRef(_l_names_45512);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _23651;
    ((intptr_t *)_2)[2] = _23652;
    _l_names_45512 = MAKE_SEQ(_1);
    goto L5; // [125] 135
L4: 

    /** buildsys.e:395				l_names = { "eu", "eudbg" }*/
    RefDS(_23651);
    RefDS(_23652);
    DeRef(_l_names_45512);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _23652;
    ((intptr_t *)_2)[2] = _23651;
    _l_names_45512 = MAKE_SEQ(_1);
L5: 

    /** buildsys.e:400			if TUNIX or compiler_type = COMPILER_GCC then*/
    if (_46TUNIX_21590 != 0) {
        goto L6; // [139] 154
    }
    _23656 = (_56compiler_type_45389 == 1LL);
    if (_23656 == 0)
    {
        DeRef(_23656);
        _23656 = NOVALUE;
        goto L7; // [150] 224
    }
    else{
        DeRef(_23656);
        _23656 = NOVALUE;
    }
L6: 

    /** buildsys.e:401				l_ext = "a"*/
    RefDS(_22274);
    DeRefi(_l_ext_45513);
    _l_ext_45513 = _22274;

    /** buildsys.e:402				t_slash = "/"*/
    RefDS(_23574);
    DeRefi(_t_slash_45514);
    _t_slash_45514 = _23574;

    /** buildsys.e:403				if dll_option and not TWINDOWS then*/
    if (_58dll_option_42563 == 0) {
        goto L8; // [172] 247
    }
    _23658 = (_46TWINDOWS_21586 == 0);
    if (_23658 == 0)
    {
        DeRef(_23658);
        _23658 = NOVALUE;
        goto L8; // [182] 247
    }
    else{
        DeRef(_23658);
        _23658 = NOVALUE;
    }

    /** buildsys.e:404					for i = 1 to length( l_names ) do*/
    if (IS_SEQUENCE(_l_names_45512)){
            _23659 = SEQ_PTR(_l_names_45512)->length;
    }
    else {
        _23659 = 1;
    }
    {
        object _i_45547;
        _i_45547 = 1LL;
L9: 
        if (_i_45547 > _23659){
            goto LA; // [192] 220
        }

        /** buildsys.e:406						l_names[i] &= "so"*/
        _2 = (object)SEQ_PTR(_l_names_45512);
        _23661 = (object)*(((s1_ptr)_2)->base + _i_45547);
        if (IS_SEQUENCE(_23661) && IS_ATOM(_23660)) {
        }
        else if (IS_ATOM(_23661) && IS_SEQUENCE(_23660)) {
            Ref(_23661);
            Prepend(&_23662, _23660, _23661);
        }
        else {
            Concat((object_ptr)&_23662, _23661, _23660);
            _23661 = NOVALUE;
        }
        _23661 = NOVALUE;
        _2 = (object)SEQ_PTR(_l_names_45512);
        _2 = (object)(((s1_ptr)_2)->base + _i_45547);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _23662;
        if( _1 != _23662 ){
            DeRef(_1);
        }
        _23662 = NOVALUE;

        /** buildsys.e:407					end for*/
        _i_45547 = _i_45547 + 1LL;
        goto L9; // [215] 199
LA: 
        ;
    }
    goto L8; // [221] 247
L7: 

    /** buildsys.e:409			elsif TWINDOWS then*/
    if (_46TWINDOWS_21586 == 0)
    {
        goto LB; // [228] 246
    }
    else{
    }

    /** buildsys.e:410				l_ext = "lib"*/
    RefDS(_23663);
    DeRefi(_l_ext_45513);
    _l_ext_45513 = _23663;

    /** buildsys.e:411				t_slash = "\\"*/
    RefDS(_23664);
    DeRefi(_t_slash_45514);
    _t_slash_45514 = _23664;
LB: 
L8: 

    /** buildsys.e:414			object eudir = get_eucompiledir()*/
    _0 = _eudir_45556;
    _eudir_45556 = _58get_eucompiledir();
    DeRef(_0);

    /** buildsys.e:415			if not file_exists(eudir) then*/
    Ref(_eudir_45556);
    _23666 = _17file_exists(_eudir_45556);
    if (IS_ATOM_INT(_23666)) {
        if (_23666 != 0){
            DeRef(_23666);
            _23666 = NOVALUE;
            goto LC; // [258] 279
        }
    }
    else {
        if (DBL_PTR(_23666)->dbl != 0.0){
            DeRef(_23666);
            _23666 = NOVALUE;
            goto LC; // [258] 279
        }
    }
    DeRef(_23666);
    _23666 = NOVALUE;

    /** buildsys.e:416				printf(2,"Supplied directory \'%s\' is not a valid EUDIR\n",{get_eucompiledir()})*/
    _23669 = _58get_eucompiledir();
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _23669;
    _23670 = MAKE_SEQ(_1);
    _23669 = NOVALUE;
    EPrintf(2LL, _23668, _23670);
    DeRefDS(_23670);
    _23670 = NOVALUE;

    /** buildsys.e:417				abort(1)*/
    UserCleanup(1LL);
LC: 

    /** buildsys.e:419			for tk = 1 to length(l_names) label "translation kind" do*/
    if (IS_SEQUENCE(_l_names_45512)){
            _23671 = SEQ_PTR(_l_names_45512)->length;
    }
    else {
        _23671 = 1;
    }
    {
        object _tk_45568;
        _tk_45568 = 1LL;
LD: 
        if (_tk_45568 > _23671){
            goto LE; // [286] 455
        }

        /** buildsys.e:420				user_library = eudir & sprintf("%sbin%s%s.%s",{t_slash, t_slash, l_names[tk],l_ext})*/
        _2 = (object)SEQ_PTR(_l_names_45512);
        _23674 = (object)*(((s1_ptr)_2)->base + _tk_45568);
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        RefDSn(_t_slash_45514, 2);
        ((intptr_t*)_2)[1] = _t_slash_45514;
        ((intptr_t*)_2)[2] = _t_slash_45514;
        Ref(_23674);
        ((intptr_t*)_2)[3] = _23674;
        RefDS(_l_ext_45513);
        ((intptr_t*)_2)[4] = _l_ext_45513;
        _23675 = MAKE_SEQ(_1);
        _23674 = NOVALUE;
        _23676 = EPrintf(-9999999, _23673, _23675);
        DeRefDS(_23675);
        _23675 = NOVALUE;
        if (IS_SEQUENCE(_eudir_45556) && IS_ATOM(_23676)) {
        }
        else if (IS_ATOM(_eudir_45556) && IS_SEQUENCE(_23676)) {
            Ref(_eudir_45556);
            Prepend(&_58user_library_42575, _23676, _eudir_45556);
        }
        else {
            Concat((object_ptr)&_58user_library_42575, _eudir_45556, _23676);
        }
        DeRefDS(_23676);
        _23676 = NOVALUE;

        /** buildsys.e:421				if TUNIX or compiler_type = COMPILER_GCC then*/
        if (_46TUNIX_21590 != 0) {
            goto LF; // [324] 339
        }
        _23679 = (_56compiler_type_45389 == 1LL);
        if (_23679 == 0)
        {
            DeRef(_23679);
            _23679 = NOVALUE;
            goto L10; // [335] 430
        }
        else{
            DeRef(_23679);
            _23679 = NOVALUE;
        }
LF: 

        /** buildsys.e:422					ifdef UNIX then*/

        /** buildsys.e:423						sequence locations = { "/usr/local/lib/%s.a", "/usr/lib/%s.a"}*/
        RefDS(_23681);
        RefDS(_23680);
        DeRef(_locations_45581);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _23680;
        ((intptr_t *)_2)[2] = _23681;
        _locations_45581 = MAKE_SEQ(_1);

        /** buildsys.e:424						if match( "/share/euphoria", eudir ) then*/
        _23684 = e_match_from(_23683, _eudir_45556, 1LL);
        if (_23684 == 0)
        {
            _23684 = NOVALUE;
            goto L11; // [354] 429
        }
        else{
            _23684 = NOVALUE;
        }

        /** buildsys.e:426							for i = 1 to length(locations) do*/
        _23685 = 2;
        {
            object _i_45589;
            _i_45589 = 1LL;
L12: 
            if (_i_45589 > 2LL){
                goto L13; // [362] 428
            }

            /** buildsys.e:427								if file_exists( sprintf(locations[i],{l_names[tk]}) ) then*/
            _2 = (object)SEQ_PTR(_locations_45581);
            _23686 = (object)*(((s1_ptr)_2)->base + _i_45589);
            _2 = (object)SEQ_PTR(_l_names_45512);
            _23687 = (object)*(((s1_ptr)_2)->base + _tk_45568);
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_23687);
            ((intptr_t*)_2)[1] = _23687;
            _23688 = MAKE_SEQ(_1);
            _23687 = NOVALUE;
            _23689 = EPrintf(-9999999, _23686, _23688);
            _23686 = NOVALUE;
            DeRefDS(_23688);
            _23688 = NOVALUE;
            _23690 = _17file_exists(_23689);
            _23689 = NOVALUE;
            if (_23690 == 0) {
                DeRef(_23690);
                _23690 = NOVALUE;
                goto L14; // [391] 421
            }
            else {
                if (!IS_ATOM_INT(_23690) && DBL_PTR(_23690)->dbl == 0.0){
                    DeRef(_23690);
                    _23690 = NOVALUE;
                    goto L14; // [391] 421
                }
                DeRef(_23690);
                _23690 = NOVALUE;
            }
            DeRef(_23690);
            _23690 = NOVALUE;

            /** buildsys.e:428									user_library = sprintf(locations[i],{l_names[tk]})*/
            _2 = (object)SEQ_PTR(_locations_45581);
            _23691 = (object)*(((s1_ptr)_2)->base + _i_45589);
            _2 = (object)SEQ_PTR(_l_names_45512);
            _23692 = (object)*(((s1_ptr)_2)->base + _tk_45568);
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_23692);
            ((intptr_t*)_2)[1] = _23692;
            _23693 = MAKE_SEQ(_1);
            _23692 = NOVALUE;
            DeRef(_58user_library_42575);
            _58user_library_42575 = EPrintf(-9999999, _23691, _23693);
            _23691 = NOVALUE;
            DeRefDS(_23693);
            _23693 = NOVALUE;

            /** buildsys.e:429									exit "translation kind"*/
            DeRefDS(_locations_45581);
            _locations_45581 = NOVALUE;
            goto LE; // [418] 455
L14: 

            /** buildsys.e:431							end for*/
            _i_45589 = _i_45589 + 1LL;
            goto L12; // [423] 369
L13: 
            ;
        }
L11: 
L10: 
        DeRef(_locations_45581);
        _locations_45581 = NOVALUE;

        /** buildsys.e:436				if file_exists(user_library) then*/
        RefDS(_58user_library_42575);
        _23695 = _17file_exists(_58user_library_42575);
        if (_23695 == 0) {
            DeRef(_23695);
            _23695 = NOVALUE;
            goto L15; // [440] 448
        }
        else {
            if (!IS_ATOM_INT(_23695) && DBL_PTR(_23695)->dbl == 0.0){
                DeRef(_23695);
                _23695 = NOVALUE;
                goto L15; // [440] 448
            }
            DeRef(_23695);
            _23695 = NOVALUE;
        }
        DeRef(_23695);
        _23695 = NOVALUE;

        /** buildsys.e:437					exit "translation kind"*/
        goto LE; // [445] 455
L15: 

        /** buildsys.e:439			end for -- tk*/
        _tk_45568 = _tk_45568 + 1LL;
        goto LD; // [450] 293
LE: 
        ;
    }
L3: 
    DeRef(_eudir_45556);
    _eudir_45556 = NOVALUE;

    /** buildsys.e:441		user_library = adjust_for_build_file(user_library)*/
    RefDS(_58user_library_42575);
    _0 = _56adjust_for_build_file(_58user_library_42575);
    DeRefDS(_58user_library_42575);
    _58user_library_42575 = _0;

    /** buildsys.e:443		if TWINDOWS then*/
    if (_46TWINDOWS_21586 == 0)
    {
        goto L16; // [472] 527
    }
    else{
    }

    /** buildsys.e:444			if compiler_type = COMPILER_WATCOM then*/
    if (_56compiler_type_45389 != 2LL)
    goto L17; // [479] 492

    /** buildsys.e:445				c_flags &= " /dEWINDOWS"*/
    Concat((object_ptr)&_c_flags_45505, _c_flags_45505, _23698);
    goto L18; // [489] 499
L17: 

    /** buildsys.e:447				c_flags &= " -DEWINDOWS"*/
    Concat((object_ptr)&_c_flags_45505, _c_flags_45505, _23700);
L18: 

    /** buildsys.e:450			if dll_option then*/
    if (_58dll_option_42563 == 0)
    {
        goto L19; // [503] 516
    }
    else{
    }

    /** buildsys.e:451				exe_ext = ".dll"*/
    RefDS(_23702);
    DeRefi(_exe_ext_45509);
    _exe_ext_45509 = _23702;
    goto L1A; // [513] 568
L19: 

    /** buildsys.e:453				exe_ext = ".exe"*/
    RefDS(_23703);
    DeRefi(_exe_ext_45509);
    _exe_ext_45509 = _23703;
    goto L1A; // [524] 568
L16: 

    /** buildsys.e:455		elsif TOSX then*/
    if (_46TOSX_21594 == 0)
    {
        goto L1B; // [531] 552
    }
    else{
    }

    /** buildsys.e:456			if dll_option then*/
    if (_58dll_option_42563 == 0)
    {
        goto L1A; // [538] 568
    }
    else{
    }

    /** buildsys.e:457				exe_ext = ".dylib"*/
    RefDS(_23704);
    DeRefi(_exe_ext_45509);
    _exe_ext_45509 = _23704;
    goto L1A; // [549] 568
L1B: 

    /** buildsys.e:460			if dll_option then*/
    if (_58dll_option_42563 == 0)
    {
        goto L1C; // [556] 567
    }
    else{
    }

    /** buildsys.e:461				exe_ext = ".so"*/
    RefDS(_23705);
    DeRefi(_exe_ext_45509);
    _exe_ext_45509 = _23705;
L1C: 
L1A: 

    /** buildsys.e:465		object compile_dir = get_eucompiledir()*/
    _0 = _compile_dir_45633;
    _compile_dir_45633 = _58get_eucompiledir();
    DeRef(_0);

    /** buildsys.e:466		if not file_exists(compile_dir) then*/
    Ref(_compile_dir_45633);
    _23707 = _17file_exists(_compile_dir_45633);
    if (IS_ATOM_INT(_23707)) {
        if (_23707 != 0){
            DeRef(_23707);
            _23707 = NOVALUE;
            goto L1D; // [579] 600
        }
    }
    else {
        if (DBL_PTR(_23707)->dbl != 0.0){
            DeRef(_23707);
            _23707 = NOVALUE;
            goto L1D; // [579] 600
        }
    }
    DeRef(_23707);
    _23707 = NOVALUE;

    /** buildsys.e:467			printf(2,"Couldn't get include directory '%s'",{get_eucompiledir()})*/
    _23710 = _58get_eucompiledir();
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _23710;
    _23711 = MAKE_SEQ(_1);
    _23710 = NOVALUE;
    EPrintf(2LL, _23709, _23711);
    DeRefDS(_23711);
    _23711 = NOVALUE;

    /** buildsys.e:468			abort(1)*/
    UserCleanup(1LL);
L1D: 

    /** buildsys.e:471		integer bits = 32*/
    _bits_45644 = 32LL;

    /** buildsys.e:472		if TX86_64 then*/
    if (_46TX86_64_21602 == 0)
    {
        goto L1E; // [609] 618
    }
    else{
    }

    /** buildsys.e:473			bits = 64*/
    _bits_45644 = 64LL;
L1E: 

    /** buildsys.e:476		switch compiler_type do*/
    _0 = _56compiler_type_45389;
    switch ( _0 ){ 

        /** buildsys.e:477			case COMPILER_GCC then*/
        case 1:

        /** buildsys.e:478				c_exe = compiler_prefix & "gcc"*/
        Concat((object_ptr)&_c_exe_45504, _56compiler_prefix_45390, _23714);

        /** buildsys.e:479				l_exe = compiler_prefix & "gcc"*/
        Concat((object_ptr)&_l_exe_45506, _56compiler_prefix_45390, _23714);

        /** buildsys.e:480				obj_ext = "o"*/
        RefDS(_23717);
        DeRefi(_obj_ext_45508);
        _obj_ext_45508 = _23717;

        /** buildsys.e:482				sequence m_flag = ""*/
        RefDS(_21993);
        DeRefi(_m_flag_45654);
        _m_flag_45654 = _21993;

        /** buildsys.e:483				if not TARM then*/
        if (_46TARM_21604 != 0)
        goto L1F; // [665] 675

        /** buildsys.e:485					m_flag = sprintf( "-m%d", bits )*/
        DeRefDSi(_m_flag_45654);
        _m_flag_45654 = EPrintf(-9999999, _23719, _bits_45644);
L1F: 

        /** buildsys.e:488				if debug_option then*/
        if (_58debug_option_42573 == 0)
        {
            goto L20; // [679] 691
        }
        else{
        }

        /** buildsys.e:489					c_flags &= " -g3"*/
        Concat((object_ptr)&_c_flags_45505, _c_flags_45505, _23721);
        goto L21; // [688] 698
L20: 

        /** buildsys.e:491					c_flags &= " -fomit-frame-pointer"*/
        Concat((object_ptr)&_c_flags_45505, _c_flags_45505, _23723);
L21: 

        /** buildsys.e:494				if dll_option and not TWINDOWS then*/
        if (_58dll_option_42563 == 0) {
            goto L22; // [702] 722
        }
        _23726 = (_46TWINDOWS_21586 == 0);
        if (_23726 == 0)
        {
            DeRef(_23726);
            _23726 = NOVALUE;
            goto L22; // [712] 722
        }
        else{
            DeRef(_23726);
            _23726 = NOVALUE;
        }

        /** buildsys.e:495					c_flags &= " -fPIC"*/
        Concat((object_ptr)&_c_flags_45505, _c_flags_45505, _23727);
L22: 

        /** buildsys.e:498				c_flags &= sprintf(" -c -w -fsigned-char -O2 %s -I%s -ffast-math",*/
        _23730 = _58get_eucompiledir();
        _23731 = _56adjust_for_build_file(_23730);
        _23730 = NOVALUE;
        RefDS(_m_flag_45654);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _m_flag_45654;
        ((intptr_t *)_2)[2] = _23731;
        _23732 = MAKE_SEQ(_1);
        _23731 = NOVALUE;
        _23733 = EPrintf(-9999999, _23729, _23732);
        DeRefDS(_23732);
        _23732 = NOVALUE;
        Concat((object_ptr)&_c_flags_45505, _c_flags_45505, _23733);
        DeRefDS(_23733);
        _23733 = NOVALUE;

        /** buildsys.e:501				if TWINDOWS and mno_cygwin then*/
        if (_46TWINDOWS_21586 == 0) {
            goto L23; // [747] 764
        }
        if (_56mno_cygwin_45413 == 0)
        {
            goto L23; // [754] 764
        }
        else{
        }

        /** buildsys.e:504					c_flags &= " -mno-cygwin"*/
        Concat((object_ptr)&_c_flags_45505, _c_flags_45505, _23736);
L23: 

        /** buildsys.e:507				if build_system_type != BUILD_DIRECT then*/
        if (_56build_system_type_45385 == 3LL)
        goto L24; // [768] 785

        /** buildsys.e:508					l_flags = sprintf( " $(RUNTIME_LIBRARY) %s", { m_flag })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_m_flag_45654);
        ((intptr_t*)_2)[1] = _m_flag_45654;
        _23740 = MAKE_SEQ(_1);
        DeRef(_l_flags_45507);
        _l_flags_45507 = EPrintf(-9999999, _23739, _23740);
        DeRefDS(_23740);
        _23740 = NOVALUE;
        goto L25; // [782] 802
L24: 

        /** buildsys.e:510					l_flags = sprintf( " %s %s",*/
        RefDS(_58user_library_42575);
        _23743 = _56adjust_for_command_line_passing(_58user_library_42575);
        RefDS(_m_flag_45654);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _23743;
        ((intptr_t *)_2)[2] = _m_flag_45654;
        _23744 = MAKE_SEQ(_1);
        _23743 = NOVALUE;
        DeRef(_l_flags_45507);
        _l_flags_45507 = EPrintf(-9999999, _23742, _23744);
        DeRefDS(_23744);
        _23744 = NOVALUE;
L25: 

        /** buildsys.e:514				if dll_option then*/
        if (_58dll_option_42563 == 0)
        {
            goto L26; // [806] 816
        }
        else{
        }

        /** buildsys.e:515					l_flags &= " -shared "*/
        Concat((object_ptr)&_l_flags_45507, _l_flags_45507, _23746);
L26: 

        /** buildsys.e:518				if TLINUX then*/
        if (_46TLINUX_21588 == 0)
        {
            goto L27; // [820] 832
        }
        else{
        }

        /** buildsys.e:519					l_flags &= " -ldl -lm -lpthread"*/
        Concat((object_ptr)&_l_flags_45507, _l_flags_45507, _23748);
        goto L28; // [829] 901
L27: 

        /** buildsys.e:520				elsif TBSD then*/
        if (_46TBSD_21592 == 0)
        {
            goto L29; // [836] 848
        }
        else{
        }

        /** buildsys.e:521					l_flags &= " -lm -lpthread"*/
        Concat((object_ptr)&_l_flags_45507, _l_flags_45507, _23750);
        goto L28; // [845] 901
L29: 

        /** buildsys.e:522				elsif TOSX then*/
        if (_46TOSX_21594 == 0)
        {
            goto L2A; // [852] 864
        }
        else{
        }

        /** buildsys.e:523					l_flags &= " -lresolv"*/
        Concat((object_ptr)&_l_flags_45507, _l_flags_45507, _23752);
        goto L28; // [861] 901
L2A: 

        /** buildsys.e:524				elsif TWINDOWS then*/
        if (_46TWINDOWS_21586 == 0)
        {
            goto L2B; // [868] 900
        }
        else{
        }

        /** buildsys.e:525					if mno_cygwin then*/
        if (_56mno_cygwin_45413 == 0)
        {
            goto L2C; // [875] 885
        }
        else{
        }

        /** buildsys.e:527						l_flags &= " -mno-cygwin"*/
        Concat((object_ptr)&_l_flags_45507, _l_flags_45507, _23736);
L2C: 

        /** buildsys.e:529					if not con_option then*/
        if (_58con_option_42565 != 0)
        goto L2D; // [889] 899

        /** buildsys.e:532						l_flags &= " -mwindows"*/
        Concat((object_ptr)&_l_flags_45507, _l_flags_45507, _23756);
L2D: 
L2B: 
L28: 

        /** buildsys.e:537				rc_comp = compiler_prefix & "windres -DSRCDIR=\"" & adjust_for_build_file(current_dir()) & "\" [1] -O coff -o [2]"*/
        _23759 = _17current_dir();
        _23760 = _56adjust_for_build_file(_23759);
        _23759 = NOVALUE;
        {
            object concat_list[4];

            concat_list[0] = _23761;
            concat_list[1] = _23760;
            concat_list[2] = _23758;
            concat_list[3] = _56compiler_prefix_45390;
            Concat_N((object_ptr)&_rc_comp_45511, concat_list, 4);
        }
        DeRef(_23760);
        _23760 = NOVALUE;
        DeRefi(_m_flag_45654);
        _m_flag_45654 = NOVALUE;
        goto L2E; // [921] 1127

        /** buildsys.e:539			case COMPILER_WATCOM then*/
        case 2:

        /** buildsys.e:540				c_exe = compiler_prefix & "wcc386"*/
        Concat((object_ptr)&_c_exe_45504, _56compiler_prefix_45390, _23763);

        /** buildsys.e:541				l_exe = compiler_prefix & "wlink"*/
        Concat((object_ptr)&_l_exe_45506, _56compiler_prefix_45390, _23765);

        /** buildsys.e:542				obj_ext = "obj"*/
        RefDS(_23767);
        DeRefi(_obj_ext_45508);
        _obj_ext_45508 = _23767;

        /** buildsys.e:544				if debug_option then*/
        if (_58debug_option_42573 == 0)
        {
            goto L2F; // [954] 971
        }
        else{
        }

        /** buildsys.e:545					c_flags = " /d3"*/
        RefDS(_23768);
        DeRef(_c_flags_45505);
        _c_flags_45505 = _23768;

        /** buildsys.e:546					l_flags_begin &= " DEBUG ALL "*/
        Concat((object_ptr)&_l_flags_begin_45510, _l_flags_begin_45510, _23769);
L2F: 

        /** buildsys.e:549				l_flags &= sprintf(" OPTION STACK=%d ", { total_stack_size })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _58total_stack_size_42578;
        _23772 = MAKE_SEQ(_1);
        _23773 = EPrintf(-9999999, _23771, _23772);
        DeRefDS(_23772);
        _23772 = NOVALUE;
        Concat((object_ptr)&_l_flags_45507, _l_flags_45507, _23773);
        DeRefDS(_23773);
        _23773 = NOVALUE;

        /** buildsys.e:550				l_flags &= sprintf(" COMMIT STACK=%d ", { total_stack_size })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _58total_stack_size_42578;
        _23776 = MAKE_SEQ(_1);
        _23777 = EPrintf(-9999999, _23775, _23776);
        DeRefDS(_23776);
        _23776 = NOVALUE;
        Concat((object_ptr)&_l_flags_45507, _l_flags_45507, _23777);
        DeRefDS(_23777);
        _23777 = NOVALUE;

        /** buildsys.e:551				l_flags &= " OPTION QUIET OPTION ELIMINATE OPTION CASEEXACT"*/
        Concat((object_ptr)&_l_flags_45507, _l_flags_45507, _23779);

        /** buildsys.e:553				if dll_option then*/
        if (_58dll_option_42563 == 0)
        {
            goto L30; // [1013] 1039
        }
        else{
        }

        /** buildsys.e:554					c_flags &= " /bd /bt=nt /mf /w0 /zq /j /zp4 /fp5 /fpi87 /5r /otimra /s /I" & adjust_for_build_file(compile_dir) */
        Ref(_compile_dir_45633);
        _23782 = _56adjust_for_build_file(_compile_dir_45633);
        if (IS_SEQUENCE(_23781) && IS_ATOM(_23782)) {
            Ref(_23782);
            Append(&_23783, _23781, _23782);
        }
        else if (IS_ATOM(_23781) && IS_SEQUENCE(_23782)) {
        }
        else {
            Concat((object_ptr)&_23783, _23781, _23782);
        }
        DeRef(_23782);
        _23782 = NOVALUE;
        Concat((object_ptr)&_c_flags_45505, _c_flags_45505, _23783);
        DeRefDS(_23783);
        _23783 = NOVALUE;

        /** buildsys.e:555					l_flags &= " SYSTEM NT_DLL initinstance terminstance"*/
        Concat((object_ptr)&_l_flags_45507, _l_flags_45507, _23785);
        goto L31; // [1036] 1077
L30: 

        /** buildsys.e:557					c_flags &= " /bt=nt /mf /w0 /zq /j /zp4 /fp5 /fpi87 /5r /otimra /s /I" & adjust_for_build_file(compile_dir)*/
        Ref(_compile_dir_45633);
        _23788 = _56adjust_for_build_file(_compile_dir_45633);
        if (IS_SEQUENCE(_23787) && IS_ATOM(_23788)) {
            Ref(_23788);
            Append(&_23789, _23787, _23788);
        }
        else if (IS_ATOM(_23787) && IS_SEQUENCE(_23788)) {
        }
        else {
            Concat((object_ptr)&_23789, _23787, _23788);
        }
        DeRef(_23788);
        _23788 = NOVALUE;
        Concat((object_ptr)&_c_flags_45505, _c_flags_45505, _23789);
        DeRefDS(_23789);
        _23789 = NOVALUE;

        /** buildsys.e:558					if con_option then*/
        if (_58con_option_42565 == 0)
        {
            goto L32; // [1057] 1069
        }
        else{
        }

        /** buildsys.e:560						l_flags = " SYSTEM NT" & l_flags*/
        Concat((object_ptr)&_l_flags_45507, _23791, _l_flags_45507);
        goto L33; // [1066] 1076
L32: 

        /** buildsys.e:562						l_flags = " SYSTEM NT_WIN RUNTIME WINDOWS=4.0" & l_flags*/
        Concat((object_ptr)&_l_flags_45507, _23793, _l_flags_45507);
L33: 
L31: 

        /** buildsys.e:566				l_flags &= sprintf(" FILE %s", { (user_library) })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_58user_library_42575);
        ((intptr_t*)_2)[1] = _58user_library_42575;
        _23796 = MAKE_SEQ(_1);
        _23797 = EPrintf(-9999999, _23795, _23796);
        DeRefDS(_23796);
        _23796 = NOVALUE;
        Concat((object_ptr)&_l_flags_45507, _l_flags_45507, _23797);
        DeRefDS(_23797);
        _23797 = NOVALUE;

        /** buildsys.e:570				rc_comp = compiler_prefix &"wrc -DSRCDIR=\"" & adjust_for_build_file(current_dir()) & "\" -q -fo=[2] -ad [1] [3]"*/
        _23800 = _17current_dir();
        _23801 = _56adjust_for_build_file(_23800);
        _23800 = NOVALUE;
        {
            object concat_list[4];

            concat_list[0] = _23802;
            concat_list[1] = _23801;
            concat_list[2] = _23799;
            concat_list[3] = _56compiler_prefix_45390;
            Concat_N((object_ptr)&_rc_comp_45511, concat_list, 4);
        }
        DeRef(_23801);
        _23801 = NOVALUE;
        goto L2E; // [1111] 1127

        /** buildsys.e:571			case else*/
        default:

        /** buildsys.e:572				CompileErr(COMPILER_IS_UNKNOWN)*/
        RefDS(_21993);
        _50CompileErr(43LL, _21993, 0LL);
    ;}L2E: 

    /** buildsys.e:575		if length(cflags) then*/
    if (IS_SEQUENCE(_56cflags_45407)){
            _23804 = SEQ_PTR(_56cflags_45407)->length;
    }
    else {
        _23804 = 1;
    }
    if (_23804 == 0)
    {
        _23804 = NOVALUE;
        goto L34; // [1134] 1147
    }
    else{
        _23804 = NOVALUE;
    }

    /** buildsys.e:577			c_flags = cflags*/
    RefDS(_56cflags_45407);
    DeRef(_c_flags_45505);
    _c_flags_45505 = _56cflags_45407;
L34: 

    /** buildsys.e:580		if length(extra_cflags) then*/
    if (IS_SEQUENCE(_56extra_cflags_45408)){
            _23805 = SEQ_PTR(_56extra_cflags_45408)->length;
    }
    else {
        _23805 = 1;
    }
    if (_23805 == 0)
    {
        _23805 = NOVALUE;
        goto L35; // [1154] 1170
    }
    else{
        _23805 = NOVALUE;
    }

    /** buildsys.e:581			c_flags &= " " & extra_cflags*/
    Concat((object_ptr)&_23806, _23384, _56extra_cflags_45408);
    Concat((object_ptr)&_c_flags_45505, _c_flags_45505, _23806);
    DeRefDS(_23806);
    _23806 = NOVALUE;
L35: 

    /** buildsys.e:584		if length(lflags) then*/
    if (IS_SEQUENCE(_56lflags_45409)){
            _23808 = SEQ_PTR(_56lflags_45409)->length;
    }
    else {
        _23808 = 1;
    }
    if (_23808 == 0)
    {
        _23808 = NOVALUE;
        goto L36; // [1177] 1197
    }
    else{
        _23808 = NOVALUE;
    }

    /** buildsys.e:585			l_flags = lflags*/
    RefDS(_56lflags_45409);
    DeRef(_l_flags_45507);
    _l_flags_45507 = _56lflags_45409;

    /** buildsys.e:586			l_flags_begin = ""*/
    RefDS(_21993);
    DeRefi(_l_flags_begin_45510);
    _l_flags_begin_45510 = _21993;
L36: 

    /** buildsys.e:589		if length(extra_lflags) then*/
    if (IS_SEQUENCE(_56extra_lflags_45410)){
            _23809 = SEQ_PTR(_56extra_lflags_45410)->length;
    }
    else {
        _23809 = 1;
    }
    if (_23809 == 0)
    {
        _23809 = NOVALUE;
        goto L37; // [1204] 1220
    }
    else{
        _23809 = NOVALUE;
    }

    /** buildsys.e:590			l_flags &= " " & extra_lflags*/
    Concat((object_ptr)&_23810, _23384, _56extra_lflags_45410);
    Concat((object_ptr)&_l_flags_45507, _l_flags_45507, _23810);
    DeRefDS(_23810);
    _23810 = NOVALUE;
L37: 

    /** buildsys.e:593		return { */
    _1 = NewS1(9);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_c_exe_45504);
    ((intptr_t*)_2)[1] = _c_exe_45504;
    RefDS(_c_flags_45505);
    ((intptr_t*)_2)[2] = _c_flags_45505;
    RefDS(_l_exe_45506);
    ((intptr_t*)_2)[3] = _l_exe_45506;
    RefDS(_l_flags_45507);
    ((intptr_t*)_2)[4] = _l_flags_45507;
    RefDS(_obj_ext_45508);
    ((intptr_t*)_2)[5] = _obj_ext_45508;
    RefDS(_exe_ext_45509);
    ((intptr_t*)_2)[6] = _exe_ext_45509;
    RefDS(_l_flags_begin_45510);
    ((intptr_t*)_2)[7] = _l_flags_begin_45510;
    RefDS(_rc_comp_45511);
    ((intptr_t*)_2)[8] = _rc_comp_45511;
    RefDS(_58user_library_42575);
    ((intptr_t*)_2)[9] = _58user_library_42575;
    _23812 = MAKE_SEQ(_1);
    DeRefDS(_c_exe_45504);
    DeRefDS(_c_flags_45505);
    DeRefDS(_l_exe_45506);
    DeRefDS(_l_flags_45507);
    DeRefDSi(_obj_ext_45508);
    DeRefDSi(_exe_ext_45509);
    DeRefDSi(_l_flags_begin_45510);
    DeRefDS(_rc_comp_45511);
    DeRef(_l_names_45512);
    DeRefi(_l_ext_45513);
    DeRefi(_t_slash_45514);
    DeRef(_compile_dir_45633);
    DeRef(_23646);
    _23646 = NOVALUE;
    return _23812;
    ;
}


void _56ensure_exename(object _ext_45801)
{
    object _23819 = NOVALUE;
    object _23818 = NOVALUE;
    object _23817 = NOVALUE;
    object _23816 = NOVALUE;
    object _23814 = NOVALUE;
    object _23813 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:602		if length(exe_name[D_ALTNAME]) = 0 then*/
    _2 = (object)SEQ_PTR(_56exe_name_45392);
    _23813 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (IS_SEQUENCE(_23813)){
            _23814 = SEQ_PTR(_23813)->length;
    }
    else {
        _23814 = 1;
    }
    _23813 = NOVALUE;
    if (_23814 != 0LL)
    goto L1; // [16] 67

    /** buildsys.e:603			exe_name[D_NAME] = current_dir() & SLASH & file0 & ext*/
    _23816 = _17current_dir();
    {
        object concat_list[4];

        concat_list[0] = _ext_45801;
        concat_list[1] = _58file0_44531;
        concat_list[2] = 47LL;
        concat_list[3] = _23816;
        Concat_N((object_ptr)&_23817, concat_list, 4);
    }
    DeRef(_23816);
    _23816 = NOVALUE;
    _2 = (object)SEQ_PTR(_56exe_name_45392);
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23817;
    if( _1 != _23817 ){
        DeRef(_1);
    }
    _23817 = NOVALUE;

    /** buildsys.e:604			exe_name[D_ALTNAME] = adjust_for_command_line_passing(exe_name[D_NAME])*/
    _2 = (object)SEQ_PTR(_56exe_name_45392);
    _23818 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_23818);
    _23819 = _56adjust_for_command_line_passing(_23818);
    _23818 = NOVALUE;
    _2 = (object)SEQ_PTR(_56exe_name_45392);
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23819;
    if( _1 != _23819 ){
        DeRef(_1);
    }
    _23819 = NOVALUE;
L1: 

    /** buildsys.e:606	end procedure*/
    DeRefDS(_ext_45801);
    _23813 = NOVALUE;
    return;
    ;
}


void _56write_objlink_file()
{
    object _settings_45819 = NOVALUE;
    object _fh_45821 = NOVALUE;
    object _s_45869 = NOVALUE;
    object _23868 = NOVALUE;
    object _23866 = NOVALUE;
    object _23865 = NOVALUE;
    object _23864 = NOVALUE;
    object _23863 = NOVALUE;
    object _23862 = NOVALUE;
    object _23861 = NOVALUE;
    object _23860 = NOVALUE;
    object _23859 = NOVALUE;
    object _23858 = NOVALUE;
    object _23857 = NOVALUE;
    object _23856 = NOVALUE;
    object _23855 = NOVALUE;
    object _23853 = NOVALUE;
    object _23852 = NOVALUE;
    object _23851 = NOVALUE;
    object _23850 = NOVALUE;
    object _23848 = NOVALUE;
    object _23847 = NOVALUE;
    object _23846 = NOVALUE;
    object _23845 = NOVALUE;
    object _23844 = NOVALUE;
    object _23843 = NOVALUE;
    object _23842 = NOVALUE;
    object _23841 = NOVALUE;
    object _23840 = NOVALUE;
    object _23837 = NOVALUE;
    object _23836 = NOVALUE;
    object _23833 = NOVALUE;
    object _23832 = NOVALUE;
    object _23831 = NOVALUE;
    object _23830 = NOVALUE;
    object _23829 = NOVALUE;
    object _23827 = NOVALUE;
    object _23826 = NOVALUE;
    object _23825 = NOVALUE;
    object _23822 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:612		sequence settings = setup_build()*/
    _0 = _settings_45819;
    _settings_45819 = _56setup_build();
    DeRef(_0);

    /** buildsys.e:613		integer fh = open(output_dir & file0 & ".lnk", "wb")*/
    {
        object concat_list[3];

        concat_list[0] = _23821;
        concat_list[1] = _58file0_44531;
        concat_list[2] = _58output_dir_42577;
        Concat_N((object_ptr)&_23822, concat_list, 3);
    }
    _fh_45821 = EOpen(_23822, _23823, 0LL);
    DeRefDS(_23822);
    _23822 = NOVALUE;

    /** buildsys.e:615		ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (object)SEQ_PTR(_settings_45819);
    _23825 = (object)*(((s1_ptr)_2)->base + 6LL);
    Ref(_23825);
    _56ensure_exename(_23825);
    _23825 = NOVALUE;

    /** buildsys.e:617		if length(settings[SETUP_LFLAGS_BEGIN]) > 0 then*/
    _2 = (object)SEQ_PTR(_settings_45819);
    _23826 = (object)*(((s1_ptr)_2)->base + 7LL);
    if (IS_SEQUENCE(_23826)){
            _23827 = SEQ_PTR(_23826)->length;
    }
    else {
        _23827 = 1;
    }
    _23826 = NOVALUE;
    if (_23827 <= 0LL)
    goto L1; // [43] 63

    /** buildsys.e:618			puts(fh, settings[SETUP_LFLAGS_BEGIN] & HOSTNL)*/
    _2 = (object)SEQ_PTR(_settings_45819);
    _23829 = (object)*(((s1_ptr)_2)->base + 7LL);
    if (IS_SEQUENCE(_23829) && IS_ATOM(_46HOSTNL_21608)) {
    }
    else if (IS_ATOM(_23829) && IS_SEQUENCE(_46HOSTNL_21608)) {
        Ref(_23829);
        Prepend(&_23830, _46HOSTNL_21608, _23829);
    }
    else {
        Concat((object_ptr)&_23830, _23829, _46HOSTNL_21608);
        _23829 = NOVALUE;
    }
    _23829 = NOVALUE;
    EPuts(_fh_45821, _23830); // DJP 
    DeRefDS(_23830);
    _23830 = NOVALUE;
L1: 

    /** buildsys.e:621		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42567)){
            _23831 = SEQ_PTR(_58generated_files_42567)->length;
    }
    else {
        _23831 = 1;
    }
    {
        object _i_45837;
        _i_45837 = 1LL;
L2: 
        if (_i_45837 > _23831){
            goto L3; // [70] 132
        }

        /** buildsys.e:622			if match(".o", generated_files[i]) then*/
        _2 = (object)SEQ_PTR(_58generated_files_42567);
        _23832 = (object)*(((s1_ptr)_2)->base + _i_45837);
        _23833 = e_match_from(_23144, _23832, 1LL);
        _23832 = NOVALUE;
        if (_23833 == 0)
        {
            _23833 = NOVALUE;
            goto L4; // [90] 125
        }
        else{
            _23833 = NOVALUE;
        }

        /** buildsys.e:623				if compiler_type = COMPILER_WATCOM then*/
        if (_56compiler_type_45389 != 2LL)
        goto L5; // [97] 107

        /** buildsys.e:624					puts(fh, "FILE ")*/
        EPuts(_fh_45821, _23835); // DJP 
L5: 

        /** buildsys.e:627				puts(fh, generated_files[i] & HOSTNL)*/
        _2 = (object)SEQ_PTR(_58generated_files_42567);
        _23836 = (object)*(((s1_ptr)_2)->base + _i_45837);
        Concat((object_ptr)&_23837, _23836, _46HOSTNL_21608);
        _23836 = NOVALUE;
        _23836 = NOVALUE;
        EPuts(_fh_45821, _23837); // DJP 
        DeRefDS(_23837);
        _23837 = NOVALUE;
L4: 

        /** buildsys.e:629		end for*/
        _i_45837 = _i_45837 + 1LL;
        goto L2; // [127] 77
L3: 
        ;
    }

    /** buildsys.e:631		if compiler_type = COMPILER_WATCOM then*/
    if (_56compiler_type_45389 != 2LL)
    goto L6; // [136] 165

    /** buildsys.e:632			printf(fh, "NAME '%s'" & HOSTNL, { exe_name[D_ALTNAME] })*/
    Concat((object_ptr)&_23840, _23839, _46HOSTNL_21608);
    _2 = (object)SEQ_PTR(_56exe_name_45392);
    _23841 = (object)*(((s1_ptr)_2)->base + 11LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23841);
    ((intptr_t*)_2)[1] = _23841;
    _23842 = MAKE_SEQ(_1);
    _23841 = NOVALUE;
    EPrintf(_fh_45821, _23840, _23842);
    DeRefDS(_23840);
    _23840 = NOVALUE;
    DeRefDS(_23842);
    _23842 = NOVALUE;
L6: 

    /** buildsys.e:635		puts(fh, trim(settings[SETUP_LFLAGS] & HOSTNL))*/
    _2 = (object)SEQ_PTR(_settings_45819);
    _23843 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_SEQUENCE(_23843) && IS_ATOM(_46HOSTNL_21608)) {
    }
    else if (IS_ATOM(_23843) && IS_SEQUENCE(_46HOSTNL_21608)) {
        Ref(_23843);
        Prepend(&_23844, _46HOSTNL_21608, _23843);
    }
    else {
        Concat((object_ptr)&_23844, _23843, _46HOSTNL_21608);
        _23843 = NOVALUE;
    }
    _23843 = NOVALUE;
    RefDS(_3871);
    _23845 = _14trim(_23844, _3871, 0LL);
    _23844 = NOVALUE;
    EPuts(_fh_45821, _23845); // DJP 
    DeRef(_23845);
    _23845 = NOVALUE;

    /** buildsys.e:637		if compiler_type = COMPILER_WATCOM and dll_option then*/
    _23846 = (_56compiler_type_45389 == 2LL);
    if (_23846 == 0) {
        goto L7; // [194] 361
    }
    if (_58dll_option_42563 == 0)
    {
        goto L7; // [201] 361
    }
    else{
    }

    /** buildsys.e:638			puts(fh, HOSTNL)*/
    EPuts(_fh_45821, _46HOSTNL_21608); // DJP 

    /** buildsys.e:640			object s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _23848 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21446);
    DeRef(_s_45869);
    _2 = (object)SEQ_PTR(_23848);
    _s_45869 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_s_45869);
    _23848 = NOVALUE;

    /** buildsys.e:641			while s do*/
L8: 
    if (_s_45869 <= 0) {
        if (_s_45869 == 0) {
            goto L9; // [232] 360
        }
        else {
            if (!IS_ATOM_INT(_s_45869) && DBL_PTR(_s_45869)->dbl == 0.0){
                goto L9; // [232] 360
            }
        }
    }

    /** buildsys.e:642				if eu:find(SymTab[s][S_TOKEN], RTN_TOKS) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_s_45869)){
        _23850 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_45869)->dbl));
    }
    else{
        _23850 = (object)*(((s1_ptr)_2)->base + _s_45869);
    }
    _2 = (object)SEQ_PTR(_23850);
    if (!IS_ATOM_INT(_36S_TOKEN_21081)){
        _23851 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    }
    else{
        _23851 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    }
    _23850 = NOVALUE;
    _23852 = find_from(_23851, _38RTN_TOKS_16045, 1LL);
    _23851 = NOVALUE;
    if (_23852 == 0)
    {
        _23852 = NOVALUE;
        goto LA; // [256] 341
    }
    else{
        _23852 = NOVALUE;
    }

    /** buildsys.e:643					if is_exported( s ) then*/
    Ref(_s_45869);
    _23853 = _58is_exported(_s_45869);
    if (_23853 == 0) {
        DeRef(_23853);
        _23853 = NOVALUE;
        goto LB; // [265] 340
    }
    else {
        if (!IS_ATOM_INT(_23853) && DBL_PTR(_23853)->dbl == 0.0){
            DeRef(_23853);
            _23853 = NOVALUE;
            goto LB; // [265] 340
        }
        DeRef(_23853);
        _23853 = NOVALUE;
    }
    DeRef(_23853);
    _23853 = NOVALUE;

    /** buildsys.e:644						printf(fh, "EXPORT %s='__%d%s@%d'" & HOSTNL,*/
    Concat((object_ptr)&_23855, _23854, _46HOSTNL_21608);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_s_45869)){
        _23856 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_45869)->dbl));
    }
    else{
        _23856 = (object)*(((s1_ptr)_2)->base + _s_45869);
    }
    _2 = (object)SEQ_PTR(_23856);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _23857 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _23857 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _23856 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_s_45869)){
        _23858 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_45869)->dbl));
    }
    else{
        _23858 = (object)*(((s1_ptr)_2)->base + _s_45869);
    }
    _2 = (object)SEQ_PTR(_23858);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _23859 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _23859 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    _23858 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_s_45869)){
        _23860 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_45869)->dbl));
    }
    else{
        _23860 = (object)*(((s1_ptr)_2)->base + _s_45869);
    }
    _2 = (object)SEQ_PTR(_23860);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _23861 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _23861 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _23860 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_s_45869)){
        _23862 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_45869)->dbl));
    }
    else{
        _23862 = (object)*(((s1_ptr)_2)->base + _s_45869);
    }
    _2 = (object)SEQ_PTR(_23862);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
        _23863 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
    }
    else{
        _23863 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
    }
    _23862 = NOVALUE;
    if (IS_ATOM_INT(_23863)) {
        {
            int128_t p128 = (int128_t)_23863 * (int128_t)4LL;
            if( p128 != (int128_t)(_23864 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _23864 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _23864 = binary_op(MULTIPLY, _23863, 4LL);
    }
    _23863 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23857);
    ((intptr_t*)_2)[1] = _23857;
    Ref(_23859);
    ((intptr_t*)_2)[2] = _23859;
    Ref(_23861);
    ((intptr_t*)_2)[3] = _23861;
    ((intptr_t*)_2)[4] = _23864;
    _23865 = MAKE_SEQ(_1);
    _23864 = NOVALUE;
    _23861 = NOVALUE;
    _23859 = NOVALUE;
    _23857 = NOVALUE;
    EPrintf(_fh_45821, _23855, _23865);
    DeRefDS(_23855);
    _23855 = NOVALUE;
    DeRefDS(_23865);
    _23865 = NOVALUE;
LB: 
LA: 

    /** buildsys.e:649				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_s_45869)){
        _23866 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_45869)->dbl));
    }
    else{
        _23866 = (object)*(((s1_ptr)_2)->base + _s_45869);
    }
    DeRef(_s_45869);
    _2 = (object)SEQ_PTR(_23866);
    _s_45869 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_s_45869);
    _23866 = NOVALUE;

    /** buildsys.e:650			end while*/
    goto L8; // [357] 232
L9: 
L7: 
    DeRef(_s_45869);
    _s_45869 = NOVALUE;

    /** buildsys.e:653		close(fh)*/
    EClose(_fh_45821);

    /** buildsys.e:655		generated_files = append(generated_files, file0 & ".lnk")*/
    Concat((object_ptr)&_23868, _58file0_44531, _23821);
    RefDS(_23868);
    Append(&_58generated_files_42567, _58generated_files_42567, _23868);
    DeRefDS(_23868);
    _23868 = NOVALUE;

    /** buildsys.e:656	end procedure*/
    DeRef(_settings_45819);
    _23826 = NOVALUE;
    DeRef(_23846);
    _23846 = NOVALUE;
    return;
    ;
}


void _56write_makefile_srcobj_list(object _fh_45918)
{
    object _file_count_45948 = NOVALUE;
    object _23900 = NOVALUE;
    object _23899 = NOVALUE;
    object _23898 = NOVALUE;
    object _23896 = NOVALUE;
    object _23895 = NOVALUE;
    object _23894 = NOVALUE;
    object _23892 = NOVALUE;
    object _23891 = NOVALUE;
    object _23889 = NOVALUE;
    object _23888 = NOVALUE;
    object _23887 = NOVALUE;
    object _23886 = NOVALUE;
    object _23885 = NOVALUE;
    object _23884 = NOVALUE;
    object _23882 = NOVALUE;
    object _23881 = NOVALUE;
    object _23880 = NOVALUE;
    object _23876 = NOVALUE;
    object _23875 = NOVALUE;
    object _23874 = NOVALUE;
    object _23873 = NOVALUE;
    object _23872 = NOVALUE;
    object _23871 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:660		printf(fh, "%s_SOURCES =", { upper(file0) })*/
    RefDS(_58file0_44531);
    _23871 = _14upper(_58file0_44531);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _23871;
    _23872 = MAKE_SEQ(_1);
    _23871 = NOVALUE;
    EPrintf(_fh_45918, _23870, _23872);
    DeRefDS(_23872);
    _23872 = NOVALUE;

    /** buildsys.e:661		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42567)){
            _23873 = SEQ_PTR(_58generated_files_42567)->length;
    }
    else {
        _23873 = 1;
    }
    {
        object _i_45925;
        _i_45925 = 1LL;
L1: 
        if (_i_45925 > _23873){
            goto L2; // [26] 94
        }

        /** buildsys.e:662			if generated_files[i][$] = 'c' then*/
        _2 = (object)SEQ_PTR(_58generated_files_42567);
        _23874 = (object)*(((s1_ptr)_2)->base + _i_45925);
        if (IS_SEQUENCE(_23874)){
                _23875 = SEQ_PTR(_23874)->length;
        }
        else {
            _23875 = 1;
        }
        _2 = (object)SEQ_PTR(_23874);
        _23876 = (object)*(((s1_ptr)_2)->base + _23875);
        _23874 = NOVALUE;
        if (binary_op_a(NOTEQ, _23876, 99LL)){
            _23876 = NOVALUE;
            goto L3; // [48] 87
        }
        _23876 = NOVALUE;

        /** buildsys.e:663				if i > 1 then*/
        if (_i_45925 <= 1LL)
        goto L4; // [54] 71

        /** buildsys.e:664					printf(fh, " \\%s\t", { HOSTNL }  )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_46HOSTNL_21608);
        ((intptr_t*)_2)[1] = _46HOSTNL_21608;
        _23880 = MAKE_SEQ(_1);
        EPrintf(_fh_45918, _23879, _23880);
        DeRefDS(_23880);
        _23880 = NOVALUE;
L4: 

        /** buildsys.e:666				puts(fh, " " & generated_files[i])*/
        _2 = (object)SEQ_PTR(_58generated_files_42567);
        _23881 = (object)*(((s1_ptr)_2)->base + _i_45925);
        Concat((object_ptr)&_23882, _23384, _23881);
        _23881 = NOVALUE;
        EPuts(_fh_45918, _23882); // DJP 
        DeRefDS(_23882);
        _23882 = NOVALUE;
L3: 

        /** buildsys.e:668		end for*/
        _i_45925 = _i_45925 + 1LL;
        goto L1; // [89] 33
L2: 
        ;
    }

    /** buildsys.e:669		puts(fh, HOSTNL)*/
    EPuts(_fh_45918, _46HOSTNL_21608); // DJP 

    /** buildsys.e:671		printf(fh, "%s_OBJECTS =", { upper(file0) })*/
    RefDS(_58file0_44531);
    _23884 = _14upper(_58file0_44531);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _23884;
    _23885 = MAKE_SEQ(_1);
    _23884 = NOVALUE;
    EPrintf(_fh_45918, _23883, _23885);
    DeRefDS(_23885);
    _23885 = NOVALUE;

    /** buildsys.e:672		integer file_count = 0*/
    _file_count_45948 = 0LL;

    /** buildsys.e:673		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42567)){
            _23886 = SEQ_PTR(_58generated_files_42567)->length;
    }
    else {
        _23886 = 1;
    }
    {
        object _i_45950;
        _i_45950 = 1LL;
L5: 
        if (_i_45950 > _23886){
            goto L6; // [129] 199
        }

        /** buildsys.e:674			if match(".o", generated_files[i]) then*/
        _2 = (object)SEQ_PTR(_58generated_files_42567);
        _23887 = (object)*(((s1_ptr)_2)->base + _i_45950);
        _23888 = e_match_from(_23144, _23887, 1LL);
        _23887 = NOVALUE;
        if (_23888 == 0)
        {
            _23888 = NOVALUE;
            goto L7; // [149] 192
        }
        else{
            _23888 = NOVALUE;
        }

        /** buildsys.e:675				if file_count then*/
        if (_file_count_45948 == 0)
        {
            goto L8; // [154] 170
        }
        else{
        }

        /** buildsys.e:676					printf(fh, " \\%s\t", { HOSTNL }  )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_46HOSTNL_21608);
        ((intptr_t*)_2)[1] = _46HOSTNL_21608;
        _23889 = MAKE_SEQ(_1);
        EPrintf(_fh_45918, _23879, _23889);
        DeRefDS(_23889);
        _23889 = NOVALUE;
L8: 

        /** buildsys.e:678				file_count += 1*/
        _file_count_45948 = _file_count_45948 + 1;

        /** buildsys.e:679				puts(fh, " " & generated_files[i])*/
        _2 = (object)SEQ_PTR(_58generated_files_42567);
        _23891 = (object)*(((s1_ptr)_2)->base + _i_45950);
        Concat((object_ptr)&_23892, _23384, _23891);
        _23891 = NOVALUE;
        EPuts(_fh_45918, _23892); // DJP 
        DeRefDS(_23892);
        _23892 = NOVALUE;
L7: 

        /** buildsys.e:681		end for*/
        _i_45950 = _i_45950 + 1LL;
        goto L5; // [194] 136
L6: 
        ;
    }

    /** buildsys.e:682		puts(fh, HOSTNL)*/
    EPuts(_fh_45918, _46HOSTNL_21608); // DJP 

    /** buildsys.e:684		printf(fh, "%s_GENERATED_FILES = ", { upper(file0) })*/
    RefDS(_58file0_44531);
    _23894 = _14upper(_58file0_44531);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _23894;
    _23895 = MAKE_SEQ(_1);
    _23894 = NOVALUE;
    EPrintf(_fh_45918, _23893, _23895);
    DeRefDS(_23895);
    _23895 = NOVALUE;

    /** buildsys.e:685		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42567)){
            _23896 = SEQ_PTR(_58generated_files_42567)->length;
    }
    else {
        _23896 = 1;
    }
    {
        object _i_45971;
        _i_45971 = 1LL;
L9: 
        if (_i_45971 > _23896){
            goto LA; // [229] 277
        }

        /** buildsys.e:686			if i > 1 then*/
        if (_i_45971 <= 1LL)
        goto LB; // [238] 255

        /** buildsys.e:687				printf(fh, " \\%s\t", { HOSTNL }  )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_46HOSTNL_21608);
        ((intptr_t*)_2)[1] = _46HOSTNL_21608;
        _23898 = MAKE_SEQ(_1);
        EPrintf(_fh_45918, _23879, _23898);
        DeRefDS(_23898);
        _23898 = NOVALUE;
LB: 

        /** buildsys.e:689			puts(fh, " " & generated_files[i])*/
        _2 = (object)SEQ_PTR(_58generated_files_42567);
        _23899 = (object)*(((s1_ptr)_2)->base + _i_45971);
        Concat((object_ptr)&_23900, _23384, _23899);
        _23899 = NOVALUE;
        EPuts(_fh_45918, _23900); // DJP 
        DeRefDS(_23900);
        _23900 = NOVALUE;

        /** buildsys.e:690		end for*/
        _i_45971 = _i_45971 + 1LL;
        goto L9; // [272] 236
LA: 
        ;
    }

    /** buildsys.e:691		puts(fh, HOSTNL)*/
    EPuts(_fh_45918, _46HOSTNL_21608); // DJP 

    /** buildsys.e:692	end procedure*/
    return;
    ;
}


object _56windows_to_mingw_path(object _s_45984)
{
    object _23902 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:701		ifdef TEST_FOR_WIN9X_ON_MING then*/

    /** buildsys.e:711		return search:find_replace('\\',s,'/')*/
    RefDS(_s_45984);
    _23902 = _16find_replace(92LL, _s_45984, 47LL, 0LL);
    DeRefDS(_s_45984);
    return _23902;
    ;
}


void _56write_makefile_full()
{
    object _settings_45989 = NOVALUE;
    object _fh_45992 = NOVALUE;
    object _24029 = NOVALUE;
    object _24027 = NOVALUE;
    object _24025 = NOVALUE;
    object _24024 = NOVALUE;
    object _24023 = NOVALUE;
    object _24022 = NOVALUE;
    object _24021 = NOVALUE;
    object _24019 = NOVALUE;
    object _24018 = NOVALUE;
    object _24016 = NOVALUE;
    object _24015 = NOVALUE;
    object _24014 = NOVALUE;
    object _24013 = NOVALUE;
    object _24011 = NOVALUE;
    object _24010 = NOVALUE;
    object _24008 = NOVALUE;
    object _24007 = NOVALUE;
    object _24005 = NOVALUE;
    object _24004 = NOVALUE;
    object _24003 = NOVALUE;
    object _24002 = NOVALUE;
    object _24001 = NOVALUE;
    object _24000 = NOVALUE;
    object _23999 = NOVALUE;
    object _23998 = NOVALUE;
    object _23996 = NOVALUE;
    object _23995 = NOVALUE;
    object _23994 = NOVALUE;
    object _23993 = NOVALUE;
    object _23992 = NOVALUE;
    object _23991 = NOVALUE;
    object _23990 = NOVALUE;
    object _23989 = NOVALUE;
    object _23988 = NOVALUE;
    object _23987 = NOVALUE;
    object _23986 = NOVALUE;
    object _23985 = NOVALUE;
    object _23984 = NOVALUE;
    object _23982 = NOVALUE;
    object _23981 = NOVALUE;
    object _23979 = NOVALUE;
    object _23977 = NOVALUE;
    object _23975 = NOVALUE;
    object _23974 = NOVALUE;
    object _23973 = NOVALUE;
    object _23972 = NOVALUE;
    object _23971 = NOVALUE;
    object _23970 = NOVALUE;
    object _23969 = NOVALUE;
    object _23968 = NOVALUE;
    object _23967 = NOVALUE;
    object _23966 = NOVALUE;
    object _23965 = NOVALUE;
    object _23964 = NOVALUE;
    object _23963 = NOVALUE;
    object _23962 = NOVALUE;
    object _23960 = NOVALUE;
    object _23959 = NOVALUE;
    object _23958 = NOVALUE;
    object _23957 = NOVALUE;
    object _23956 = NOVALUE;
    object _23955 = NOVALUE;
    object _23954 = NOVALUE;
    object _23953 = NOVALUE;
    object _23952 = NOVALUE;
    object _23950 = NOVALUE;
    object _23949 = NOVALUE;
    object _23948 = NOVALUE;
    object _23947 = NOVALUE;
    object _23945 = NOVALUE;
    object _23944 = NOVALUE;
    object _23943 = NOVALUE;
    object _23942 = NOVALUE;
    object _23941 = NOVALUE;
    object _23940 = NOVALUE;
    object _23938 = NOVALUE;
    object _23937 = NOVALUE;
    object _23936 = NOVALUE;
    object _23935 = NOVALUE;
    object _23934 = NOVALUE;
    object _23933 = NOVALUE;
    object _23932 = NOVALUE;
    object _23930 = NOVALUE;
    object _23929 = NOVALUE;
    object _23928 = NOVALUE;
    object _23927 = NOVALUE;
    object _23924 = NOVALUE;
    object _23923 = NOVALUE;
    object _23922 = NOVALUE;
    object _23919 = NOVALUE;
    object _23918 = NOVALUE;
    object _23917 = NOVALUE;
    object _23915 = NOVALUE;
    object _23914 = NOVALUE;
    object _23913 = NOVALUE;
    object _23911 = NOVALUE;
    object _23910 = NOVALUE;
    object _23909 = NOVALUE;
    object _23906 = NOVALUE;
    object _23904 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:718		sequence settings = setup_build()*/
    _0 = _settings_45989;
    _settings_45989 = _56setup_build();
    DeRef(_0);

    /** buildsys.e:720		ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (object)SEQ_PTR(_settings_45989);
    _23904 = (object)*(((s1_ptr)_2)->base + 6LL);
    Ref(_23904);
    _56ensure_exename(_23904);
    _23904 = NOVALUE;

    /** buildsys.e:722		integer fh = open(output_dir & file0 & ".mak", "wb")*/
    {
        object concat_list[3];

        concat_list[0] = _23905;
        concat_list[1] = _58file0_44531;
        concat_list[2] = _58output_dir_42577;
        Concat_N((object_ptr)&_23906, concat_list, 3);
    }
    _fh_45992 = EOpen(_23906, _23823, 0LL);
    DeRefDS(_23906);
    _23906 = NOVALUE;

    /** buildsys.e:724		printf(fh, "CC     = %s" & HOSTNL, { settings[SETUP_CEXE] })*/
    Concat((object_ptr)&_23909, _23908, _46HOSTNL_21608);
    _2 = (object)SEQ_PTR(_settings_45989);
    _23910 = (object)*(((s1_ptr)_2)->base + 1LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23910);
    ((intptr_t*)_2)[1] = _23910;
    _23911 = MAKE_SEQ(_1);
    _23910 = NOVALUE;
    EPrintf(_fh_45992, _23909, _23911);
    DeRefDS(_23909);
    _23909 = NOVALUE;
    DeRefDS(_23911);
    _23911 = NOVALUE;

    /** buildsys.e:725		printf(fh, "CFLAGS = %s" & HOSTNL, { settings[SETUP_CFLAGS] })*/
    Concat((object_ptr)&_23913, _23912, _46HOSTNL_21608);
    _2 = (object)SEQ_PTR(_settings_45989);
    _23914 = (object)*(((s1_ptr)_2)->base + 2LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23914);
    ((intptr_t*)_2)[1] = _23914;
    _23915 = MAKE_SEQ(_1);
    _23914 = NOVALUE;
    EPrintf(_fh_45992, _23913, _23915);
    DeRefDS(_23913);
    _23913 = NOVALUE;
    DeRefDS(_23915);
    _23915 = NOVALUE;

    /** buildsys.e:726		printf(fh, "LINKER = %s" & HOSTNL, { settings[SETUP_LEXE] })*/
    Concat((object_ptr)&_23917, _23916, _46HOSTNL_21608);
    _2 = (object)SEQ_PTR(_settings_45989);
    _23918 = (object)*(((s1_ptr)_2)->base + 3LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23918);
    ((intptr_t*)_2)[1] = _23918;
    _23919 = MAKE_SEQ(_1);
    _23918 = NOVALUE;
    EPrintf(_fh_45992, _23917, _23919);
    DeRefDS(_23917);
    _23917 = NOVALUE;
    DeRefDS(_23919);
    _23919 = NOVALUE;

    /** buildsys.e:728		if compiler_type = COMPILER_GCC then*/
    if (_56compiler_type_45389 != 1LL)
    goto L1; // [98] 125

    /** buildsys.e:729			printf(fh, "LFLAGS = %s" & HOSTNL, { settings[SETUP_LFLAGS] })*/
    Concat((object_ptr)&_23922, _23921, _46HOSTNL_21608);
    _2 = (object)SEQ_PTR(_settings_45989);
    _23923 = (object)*(((s1_ptr)_2)->base + 4LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23923);
    ((intptr_t*)_2)[1] = _23923;
    _23924 = MAKE_SEQ(_1);
    _23923 = NOVALUE;
    EPrintf(_fh_45992, _23922, _23924);
    DeRefDS(_23922);
    _23922 = NOVALUE;
    DeRefDS(_23924);
    _23924 = NOVALUE;
    goto L2; // [122] 130
L1: 

    /** buildsys.e:731			write_objlink_file()*/
    _56write_objlink_file();
L2: 

    /** buildsys.e:734		write_makefile_srcobj_list(fh)*/
    _56write_makefile_srcobj_list(_fh_45992);

    /** buildsys.e:735		puts(fh, HOSTNL)*/
    EPuts(_fh_45992, _46HOSTNL_21608); // DJP 

    /** buildsys.e:737		if compiler_type = COMPILER_WATCOM then*/
    if (_56compiler_type_45389 != 2LL)
    goto L3; // [146] 575

    /** buildsys.e:738			printf(fh, "\"%s\" : $(%s_OBJECTS) %s" & HOSTNL, { */
    Concat((object_ptr)&_23927, _23926, _46HOSTNL_21608);
    _2 = (object)SEQ_PTR(_56exe_name_45392);
    _23928 = (object)*(((s1_ptr)_2)->base + 11LL);
    RefDS(_58file0_44531);
    _23929 = _14upper(_58file0_44531);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23928);
    ((intptr_t*)_2)[1] = _23928;
    ((intptr_t*)_2)[2] = _23929;
    RefDS(_58user_library_42575);
    ((intptr_t*)_2)[3] = _58user_library_42575;
    _23930 = MAKE_SEQ(_1);
    _23929 = NOVALUE;
    _23928 = NOVALUE;
    EPrintf(_fh_45992, _23927, _23930);
    DeRefDS(_23927);
    _23927 = NOVALUE;
    DeRefDS(_23930);
    _23930 = NOVALUE;

    /** buildsys.e:741			printf(fh, "\t$(LINKER) @%s.lnk" & HOSTNL, { file0 })*/
    Concat((object_ptr)&_23932, _23931, _46HOSTNL_21608);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_58file0_44531);
    ((intptr_t*)_2)[1] = _58file0_44531;
    _23933 = MAKE_SEQ(_1);
    EPrintf(_fh_45992, _23932, _23933);
    DeRefDS(_23932);
    _23932 = NOVALUE;
    DeRefDS(_23933);
    _23933 = NOVALUE;

    /** buildsys.e:742			if length(rc_file[D_ALTNAME]) and length(settings[SETUP_RC_COMPILER]) then*/
    _2 = (object)SEQ_PTR(_56rc_file_45398);
    _23934 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (IS_SEQUENCE(_23934)){
            _23935 = SEQ_PTR(_23934)->length;
    }
    else {
        _23935 = 1;
    }
    _23934 = NOVALUE;
    if (_23935 == 0) {
        goto L4; // [215] 277
    }
    _2 = (object)SEQ_PTR(_settings_45989);
    _23937 = (object)*(((s1_ptr)_2)->base + 8LL);
    if (IS_SEQUENCE(_23937)){
            _23938 = SEQ_PTR(_23937)->length;
    }
    else {
        _23938 = 1;
    }
    _23937 = NOVALUE;
    if (_23938 == 0)
    {
        _23938 = NOVALUE;
        goto L4; // [227] 277
    }
    else{
        _23938 = NOVALUE;
    }

    /** buildsys.e:743				writef(fh, "\t" & settings[SETUP_RC_COMPILER], { rc_file[D_ALTNAME], res_file[D_ALTNAME], exe_name[D_ALTNAME] })*/
    _2 = (object)SEQ_PTR(_settings_45989);
    _23940 = (object)*(((s1_ptr)_2)->base + 8LL);
    if (IS_SEQUENCE(_23939) && IS_ATOM(_23940)) {
        Ref(_23940);
        Append(&_23941, _23939, _23940);
    }
    else if (IS_ATOM(_23939) && IS_SEQUENCE(_23940)) {
    }
    else {
        Concat((object_ptr)&_23941, _23939, _23940);
    }
    _23940 = NOVALUE;
    _2 = (object)SEQ_PTR(_56rc_file_45398);
    _23942 = (object)*(((s1_ptr)_2)->base + 11LL);
    _2 = (object)SEQ_PTR(_56res_file_45404);
    _23943 = (object)*(((s1_ptr)_2)->base + 11LL);
    _2 = (object)SEQ_PTR(_56exe_name_45392);
    _23944 = (object)*(((s1_ptr)_2)->base + 11LL);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23942);
    ((intptr_t*)_2)[1] = _23942;
    Ref(_23943);
    ((intptr_t*)_2)[2] = _23943;
    Ref(_23944);
    ((intptr_t*)_2)[3] = _23944;
    _23945 = MAKE_SEQ(_1);
    _23944 = NOVALUE;
    _23943 = NOVALUE;
    _23942 = NOVALUE;
    _8writef(_fh_45992, _23941, _23945, 0LL);
    _23941 = NOVALUE;
    _23945 = NOVALUE;
L4: 

    /** buildsys.e:745			puts(fh, HOSTNL)*/
    EPuts(_fh_45992, _46HOSTNL_21608); // DJP 

    /** buildsys.e:746			printf(fh, "%s-clean : .SYMBOLIC" & HOSTNL, { file0 })*/
    Concat((object_ptr)&_23947, _23946, _46HOSTNL_21608);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_58file0_44531);
    ((intptr_t*)_2)[1] = _58file0_44531;
    _23948 = MAKE_SEQ(_1);
    EPrintf(_fh_45992, _23947, _23948);
    DeRefDS(_23947);
    _23947 = NOVALUE;
    DeRefDS(_23948);
    _23948 = NOVALUE;

    /** buildsys.e:747			if length(res_file[D_ALTNAME]) then*/
    _2 = (object)SEQ_PTR(_56res_file_45404);
    _23949 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (IS_SEQUENCE(_23949)){
            _23950 = SEQ_PTR(_23949)->length;
    }
    else {
        _23950 = 1;
    }
    _23949 = NOVALUE;
    if (_23950 == 0)
    {
        _23950 = NOVALUE;
        goto L5; // [315] 343
    }
    else{
        _23950 = NOVALUE;
    }

    /** buildsys.e:748				printf(fh, "\tdel \"%s\"" & HOSTNL, { res_file[D_ALTNAME] })*/
    Concat((object_ptr)&_23952, _23951, _46HOSTNL_21608);
    _2 = (object)SEQ_PTR(_56res_file_45404);
    _23953 = (object)*(((s1_ptr)_2)->base + 11LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23953);
    ((intptr_t*)_2)[1] = _23953;
    _23954 = MAKE_SEQ(_1);
    _23953 = NOVALUE;
    EPrintf(_fh_45992, _23952, _23954);
    DeRefDS(_23952);
    _23952 = NOVALUE;
    DeRefDS(_23954);
    _23954 = NOVALUE;
L5: 

    /** buildsys.e:750			for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42567)){
            _23955 = SEQ_PTR(_58generated_files_42567)->length;
    }
    else {
        _23955 = 1;
    }
    {
        object _i_46074;
        _i_46074 = 1LL;
L6: 
        if (_i_46074 > _23955){
            goto L7; // [350] 403
        }

        /** buildsys.e:751				if match(".o", generated_files[i]) then*/
        _2 = (object)SEQ_PTR(_58generated_files_42567);
        _23956 = (object)*(((s1_ptr)_2)->base + _i_46074);
        _23957 = e_match_from(_23144, _23956, 1LL);
        _23956 = NOVALUE;
        if (_23957 == 0)
        {
            _23957 = NOVALUE;
            goto L8; // [370] 396
        }
        else{
            _23957 = NOVALUE;
        }

        /** buildsys.e:752					printf(fh, "\tdel \"%s\"" & HOSTNL, { generated_files[i] })*/
        Concat((object_ptr)&_23958, _23951, _46HOSTNL_21608);
        _2 = (object)SEQ_PTR(_58generated_files_42567);
        _23959 = (object)*(((s1_ptr)_2)->base + _i_46074);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_23959);
        ((intptr_t*)_2)[1] = _23959;
        _23960 = MAKE_SEQ(_1);
        _23959 = NOVALUE;
        EPrintf(_fh_45992, _23958, _23960);
        DeRefDS(_23958);
        _23958 = NOVALUE;
        DeRefDS(_23960);
        _23960 = NOVALUE;
L8: 

        /** buildsys.e:754			end for*/
        _i_46074 = _i_46074 + 1LL;
        goto L6; // [398] 357
L7: 
        ;
    }

    /** buildsys.e:755			puts(fh, HOSTNL)*/
    EPuts(_fh_45992, _46HOSTNL_21608); // DJP 

    /** buildsys.e:756			printf(fh, "%s-clean-all : .SYMBOLIC" & HOSTNL, { file0 })*/
    Concat((object_ptr)&_23962, _23961, _46HOSTNL_21608);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_58file0_44531);
    ((intptr_t*)_2)[1] = _58file0_44531;
    _23963 = MAKE_SEQ(_1);
    EPrintf(_fh_45992, _23962, _23963);
    DeRefDS(_23962);
    _23962 = NOVALUE;
    DeRefDS(_23963);
    _23963 = NOVALUE;

    /** buildsys.e:757			printf(fh, "\tdel \"%s\"" & HOSTNL, { exe_name[D_ALTNAME] })*/
    Concat((object_ptr)&_23964, _23951, _46HOSTNL_21608);
    _2 = (object)SEQ_PTR(_56exe_name_45392);
    _23965 = (object)*(((s1_ptr)_2)->base + 11LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23965);
    ((intptr_t*)_2)[1] = _23965;
    _23966 = MAKE_SEQ(_1);
    _23965 = NOVALUE;
    EPrintf(_fh_45992, _23964, _23966);
    DeRefDS(_23964);
    _23964 = NOVALUE;
    DeRefDS(_23966);
    _23966 = NOVALUE;

    /** buildsys.e:758			if length(res_file[D_ALTNAME]) then*/
    _2 = (object)SEQ_PTR(_56res_file_45404);
    _23967 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (IS_SEQUENCE(_23967)){
            _23968 = SEQ_PTR(_23967)->length;
    }
    else {
        _23968 = 1;
    }
    _23967 = NOVALUE;
    if (_23968 == 0)
    {
        _23968 = NOVALUE;
        goto L9; // [465] 493
    }
    else{
        _23968 = NOVALUE;
    }

    /** buildsys.e:759				printf(fh, "\tdel \"%s\"" & HOSTNL, { res_file[D_ALTNAME] })*/
    Concat((object_ptr)&_23969, _23951, _46HOSTNL_21608);
    _2 = (object)SEQ_PTR(_56res_file_45404);
    _23970 = (object)*(((s1_ptr)_2)->base + 11LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23970);
    ((intptr_t*)_2)[1] = _23970;
    _23971 = MAKE_SEQ(_1);
    _23970 = NOVALUE;
    EPrintf(_fh_45992, _23969, _23971);
    DeRefDS(_23969);
    _23969 = NOVALUE;
    DeRefDS(_23971);
    _23971 = NOVALUE;
L9: 

    /** buildsys.e:761			for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42567)){
            _23972 = SEQ_PTR(_58generated_files_42567)->length;
    }
    else {
        _23972 = 1;
    }
    {
        object _i_46107;
        _i_46107 = 1LL;
LA: 
        if (_i_46107 > _23972){
            goto LB; // [500] 536
        }

        /** buildsys.e:762				printf(fh, "\tdel \"%s\"" & HOSTNL, { generated_files[i] })*/
        Concat((object_ptr)&_23973, _23951, _46HOSTNL_21608);
        _2 = (object)SEQ_PTR(_58generated_files_42567);
        _23974 = (object)*(((s1_ptr)_2)->base + _i_46107);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_23974);
        ((intptr_t*)_2)[1] = _23974;
        _23975 = MAKE_SEQ(_1);
        _23974 = NOVALUE;
        EPrintf(_fh_45992, _23973, _23975);
        DeRefDS(_23973);
        _23973 = NOVALUE;
        DeRefDS(_23975);
        _23975 = NOVALUE;

        /** buildsys.e:763			end for*/
        _i_46107 = _i_46107 + 1LL;
        goto LA; // [531] 507
LB: 
        ;
    }

    /** buildsys.e:764			puts(fh, HOSTNL)*/
    EPuts(_fh_45992, _46HOSTNL_21608); // DJP 

    /** buildsys.e:765			puts(fh, ".c.obj : .autodepend" & HOSTNL)*/
    Concat((object_ptr)&_23977, _23976, _46HOSTNL_21608);
    EPuts(_fh_45992, _23977); // DJP 
    DeRefDS(_23977);
    _23977 = NOVALUE;

    /** buildsys.e:766			puts(fh, "\t$(CC) $(CFLAGS) $<" & HOSTNL)*/
    Concat((object_ptr)&_23979, _23978, _46HOSTNL_21608);
    EPuts(_fh_45992, _23979); // DJP 
    DeRefDS(_23979);
    _23979 = NOVALUE;

    /** buildsys.e:767			puts(fh, HOSTNL)*/
    EPuts(_fh_45992, _46HOSTNL_21608); // DJP 
    goto LC; // [572] 933
L3: 

    /** buildsys.e:770			printf(fh, "RUNTIME_LIBRARY=%s\n", { settings[SETUP_RUNTIME_LIBRARY] } )*/
    _2 = (object)SEQ_PTR(_settings_45989);
    _23981 = (object)*(((s1_ptr)_2)->base + 9LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23981);
    ((intptr_t*)_2)[1] = _23981;
    _23982 = MAKE_SEQ(_1);
    _23981 = NOVALUE;
    EPrintf(_fh_45992, _23980, _23982);
    DeRefDS(_23982);
    _23982 = NOVALUE;

    /** buildsys.e:771			printf(fh, "%s: $(%s_OBJECTS) $(RUNTIME_LIBRARY) %s " & HOSTNL, { adjust_for_build_file(exe_name[D_ALTNAME]), upper(file0), rc_file[D_ALTNAME] })*/
    Concat((object_ptr)&_23984, _23983, _46HOSTNL_21608);
    _2 = (object)SEQ_PTR(_56exe_name_45392);
    _23985 = (object)*(((s1_ptr)_2)->base + 11LL);
    Ref(_23985);
    _23986 = _56adjust_for_build_file(_23985);
    _23985 = NOVALUE;
    RefDS(_58file0_44531);
    _23987 = _14upper(_58file0_44531);
    _2 = (object)SEQ_PTR(_56rc_file_45398);
    _23988 = (object)*(((s1_ptr)_2)->base + 11LL);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _23986;
    ((intptr_t*)_2)[2] = _23987;
    Ref(_23988);
    ((intptr_t*)_2)[3] = _23988;
    _23989 = MAKE_SEQ(_1);
    _23988 = NOVALUE;
    _23987 = NOVALUE;
    _23986 = NOVALUE;
    EPrintf(_fh_45992, _23984, _23989);
    DeRefDS(_23984);
    _23984 = NOVALUE;
    DeRefDS(_23989);
    _23989 = NOVALUE;

    /** buildsys.e:772			if length(rc_file[D_ALTNAME]) then*/
    _2 = (object)SEQ_PTR(_56rc_file_45398);
    _23990 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (IS_SEQUENCE(_23990)){
            _23991 = SEQ_PTR(_23990)->length;
    }
    else {
        _23991 = 1;
    }
    _23990 = NOVALUE;
    if (_23991 == 0)
    {
        _23991 = NOVALUE;
        goto LD; // [646] 690
    }
    else{
        _23991 = NOVALUE;
    }

    /** buildsys.e:773				writef(fh, "\t" & settings[SETUP_RC_COMPILER] & HOSTNL, { rc_file[D_ALTNAME], res_file[D_ALTNAME] })*/
    _2 = (object)SEQ_PTR(_settings_45989);
    _23992 = (object)*(((s1_ptr)_2)->base + 8LL);
    {
        object concat_list[3];

        concat_list[0] = _46HOSTNL_21608;
        concat_list[1] = _23992;
        concat_list[2] = _23939;
        Concat_N((object_ptr)&_23993, concat_list, 3);
    }
    _23992 = NOVALUE;
    _2 = (object)SEQ_PTR(_56rc_file_45398);
    _23994 = (object)*(((s1_ptr)_2)->base + 11LL);
    _2 = (object)SEQ_PTR(_56res_file_45404);
    _23995 = (object)*(((s1_ptr)_2)->base + 11LL);
    Ref(_23995);
    Ref(_23994);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _23994;
    ((intptr_t *)_2)[2] = _23995;
    _23996 = MAKE_SEQ(_1);
    _23995 = NOVALUE;
    _23994 = NOVALUE;
    _8writef(_fh_45992, _23993, _23996, 0LL);
    _23993 = NOVALUE;
    _23996 = NOVALUE;
LD: 

    /** buildsys.e:775			printf(fh, "\t$(LINKER) -o %s $(%s_OBJECTS) %s $(LFLAGS)" & HOSTNL, {*/
    Concat((object_ptr)&_23998, _23997, _46HOSTNL_21608);
    _2 = (object)SEQ_PTR(_56exe_name_45392);
    _23999 = (object)*(((s1_ptr)_2)->base + 11LL);
    RefDS(_58file0_44531);
    _24000 = _14upper(_58file0_44531);
    _2 = (object)SEQ_PTR(_56res_file_45404);
    _24001 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (IS_SEQUENCE(_24001)){
            _24002 = SEQ_PTR(_24001)->length;
    }
    else {
        _24002 = 1;
    }
    _24001 = NOVALUE;
    _2 = (object)SEQ_PTR(_56res_file_45404);
    _24003 = (object)*(((s1_ptr)_2)->base + 11LL);
    Ref(_24003);
    RefDS(_21993);
    _24004 = _57iif(_24002, _24003, _21993);
    _24002 = NOVALUE;
    _24003 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_23999);
    ((intptr_t*)_2)[1] = _23999;
    ((intptr_t*)_2)[2] = _24000;
    ((intptr_t*)_2)[3] = _24004;
    _24005 = MAKE_SEQ(_1);
    _24004 = NOVALUE;
    _24000 = NOVALUE;
    _23999 = NOVALUE;
    EPrintf(_fh_45992, _23998, _24005);
    DeRefDS(_23998);
    _23998 = NOVALUE;
    DeRefDS(_24005);
    _24005 = NOVALUE;

    /** buildsys.e:777			puts(fh, HOSTNL)*/
    EPuts(_fh_45992, _46HOSTNL_21608); // DJP 

    /** buildsys.e:778			printf(fh, ".PHONY: %s-clean %s-clean-all" & HOSTNL, { file0, file0 })*/
    Concat((object_ptr)&_24007, _24006, _46HOSTNL_21608);
    RefDS(_58file0_44531);
    RefDS(_58file0_44531);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _58file0_44531;
    ((intptr_t *)_2)[2] = _58file0_44531;
    _24008 = MAKE_SEQ(_1);
    EPrintf(_fh_45992, _24007, _24008);
    DeRefDS(_24007);
    _24007 = NOVALUE;
    DeRefDS(_24008);
    _24008 = NOVALUE;

    /** buildsys.e:779			puts(fh, HOSTNL)*/
    EPuts(_fh_45992, _46HOSTNL_21608); // DJP 

    /** buildsys.e:780			printf(fh, "%s-clean:" & HOSTNL, { file0 })*/
    Concat((object_ptr)&_24010, _24009, _46HOSTNL_21608);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_58file0_44531);
    ((intptr_t*)_2)[1] = _58file0_44531;
    _24011 = MAKE_SEQ(_1);
    EPrintf(_fh_45992, _24010, _24011);
    DeRefDS(_24010);
    _24010 = NOVALUE;
    DeRefDS(_24011);
    _24011 = NOVALUE;

    /** buildsys.e:781			printf(fh, "\trm -rf $(%s_OBJECTS) %s" & HOSTNL, { upper(file0), res_file[D_ALTNAME] })*/
    Concat((object_ptr)&_24013, _24012, _46HOSTNL_21608);
    RefDS(_58file0_44531);
    _24014 = _14upper(_58file0_44531);
    _2 = (object)SEQ_PTR(_56res_file_45404);
    _24015 = (object)*(((s1_ptr)_2)->base + 11LL);
    Ref(_24015);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24014;
    ((intptr_t *)_2)[2] = _24015;
    _24016 = MAKE_SEQ(_1);
    _24015 = NOVALUE;
    _24014 = NOVALUE;
    EPrintf(_fh_45992, _24013, _24016);
    DeRefDS(_24013);
    _24013 = NOVALUE;
    DeRefDS(_24016);
    _24016 = NOVALUE;

    /** buildsys.e:782			puts(fh, HOSTNL)*/
    EPuts(_fh_45992, _46HOSTNL_21608); // DJP 

    /** buildsys.e:783			printf(fh, "%s-clean-all: %s-clean" & HOSTNL, { file0, file0 })*/
    Concat((object_ptr)&_24018, _24017, _46HOSTNL_21608);
    RefDS(_58file0_44531);
    RefDS(_58file0_44531);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _58file0_44531;
    ((intptr_t *)_2)[2] = _58file0_44531;
    _24019 = MAKE_SEQ(_1);
    EPrintf(_fh_45992, _24018, _24019);
    DeRefDS(_24018);
    _24018 = NOVALUE;
    DeRefDS(_24019);
    _24019 = NOVALUE;

    /** buildsys.e:784			printf(fh, "\trm -rf $(%s_SOURCES) %s %s" & HOSTNL, { upper(file0), res_file[D_ALTNAME], exe_name[D_ALTNAME] })*/
    Concat((object_ptr)&_24021, _24020, _46HOSTNL_21608);
    RefDS(_58file0_44531);
    _24022 = _14upper(_58file0_44531);
    _2 = (object)SEQ_PTR(_56res_file_45404);
    _24023 = (object)*(((s1_ptr)_2)->base + 11LL);
    _2 = (object)SEQ_PTR(_56exe_name_45392);
    _24024 = (object)*(((s1_ptr)_2)->base + 11LL);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24022;
    Ref(_24023);
    ((intptr_t*)_2)[2] = _24023;
    Ref(_24024);
    ((intptr_t*)_2)[3] = _24024;
    _24025 = MAKE_SEQ(_1);
    _24024 = NOVALUE;
    _24023 = NOVALUE;
    _24022 = NOVALUE;
    EPrintf(_fh_45992, _24021, _24025);
    DeRefDS(_24021);
    _24021 = NOVALUE;
    DeRefDS(_24025);
    _24025 = NOVALUE;

    /** buildsys.e:785			puts(fh, HOSTNL)*/
    EPuts(_fh_45992, _46HOSTNL_21608); // DJP 

    /** buildsys.e:786			puts(fh, "%.o: %.c" & HOSTNL)*/
    Concat((object_ptr)&_24027, _24026, _46HOSTNL_21608);
    EPuts(_fh_45992, _24027); // DJP 
    DeRefDS(_24027);
    _24027 = NOVALUE;

    /** buildsys.e:787			puts(fh, "\t$(CC) $(CFLAGS) $*.c -o $*.o" & HOSTNL)*/
    Concat((object_ptr)&_24029, _24028, _46HOSTNL_21608);
    EPuts(_fh_45992, _24029); // DJP 
    DeRefDS(_24029);
    _24029 = NOVALUE;

    /** buildsys.e:788			puts(fh, HOSTNL)*/
    EPuts(_fh_45992, _46HOSTNL_21608); // DJP 
LC: 

    /** buildsys.e:791		close(fh)*/
    EClose(_fh_45992);

    /** buildsys.e:792	end procedure*/
    DeRef(_settings_45989);
    _23990 = NOVALUE;
    _23967 = NOVALUE;
    _23934 = NOVALUE;
    _23949 = NOVALUE;
    _23937 = NOVALUE;
    _24001 = NOVALUE;
    return;
    ;
}


void _56write_makefile_partial()
{
    object _settings_46218 = NOVALUE;
    object _fh_46220 = NOVALUE;
    object _24031 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:798		sequence settings = setup_build()*/
    _0 = _settings_46218;
    _settings_46218 = _56setup_build();
    DeRef(_0);

    /** buildsys.e:799		integer fh = open(output_dir & file0 & ".mak", "wb")*/
    {
        object concat_list[3];

        concat_list[0] = _23905;
        concat_list[1] = _58file0_44531;
        concat_list[2] = _58output_dir_42577;
        Concat_N((object_ptr)&_24031, concat_list, 3);
    }
    _fh_46220 = EOpen(_24031, _23823, 0LL);
    DeRefDS(_24031);
    _24031 = NOVALUE;

    /** buildsys.e:801		write_makefile_srcobj_list(fh)*/
    _56write_makefile_srcobj_list(_fh_46220);

    /** buildsys.e:803		close(fh)*/
    EClose(_fh_46220);

    /** buildsys.e:804	end procedure*/
    DeRefDS(_settings_46218);
    return;
    ;
}


void _56build_direct(object _link_only_46227, object _the_file0_46228)
{
    object _cmd_46234 = NOVALUE;
    object _objs_46235 = NOVALUE;
    object _settings_46236 = NOVALUE;
    object _cwd_46238 = NOVALUE;
    object _status_46241 = NOVALUE;
    object _link_files_46272 = NOVALUE;
    object _pdone_46298 = NOVALUE;
    object _files_46349 = NOVALUE;
    object _31707 = NOVALUE;
    object _31706 = NOVALUE;
    object _31705 = NOVALUE;
    object _31704 = NOVALUE;
    object _31703 = NOVALUE;
    object _31702 = NOVALUE;
    object _31701 = NOVALUE;
    object _24179 = NOVALUE;
    object _24178 = NOVALUE;
    object _24176 = NOVALUE;
    object _24175 = NOVALUE;
    object _24174 = NOVALUE;
    object _24173 = NOVALUE;
    object _24172 = NOVALUE;
    object _24171 = NOVALUE;
    object _24170 = NOVALUE;
    object _24169 = NOVALUE;
    object _24167 = NOVALUE;
    object _24166 = NOVALUE;
    object _24165 = NOVALUE;
    object _24164 = NOVALUE;
    object _24160 = NOVALUE;
    object _24159 = NOVALUE;
    object _24158 = NOVALUE;
    object _24157 = NOVALUE;
    object _24156 = NOVALUE;
    object _24155 = NOVALUE;
    object _24154 = NOVALUE;
    object _24153 = NOVALUE;
    object _24152 = NOVALUE;
    object _24151 = NOVALUE;
    object _24150 = NOVALUE;
    object _24149 = NOVALUE;
    object _24148 = NOVALUE;
    object _24147 = NOVALUE;
    object _24146 = NOVALUE;
    object _24143 = NOVALUE;
    object _24142 = NOVALUE;
    object _24141 = NOVALUE;
    object _24140 = NOVALUE;
    object _24137 = NOVALUE;
    object _24135 = NOVALUE;
    object _24134 = NOVALUE;
    object _24133 = NOVALUE;
    object _24132 = NOVALUE;
    object _24131 = NOVALUE;
    object _24130 = NOVALUE;
    object _24127 = NOVALUE;
    object _24126 = NOVALUE;
    object _24122 = NOVALUE;
    object _24121 = NOVALUE;
    object _24120 = NOVALUE;
    object _24116 = NOVALUE;
    object _24115 = NOVALUE;
    object _24114 = NOVALUE;
    object _24113 = NOVALUE;
    object _24112 = NOVALUE;
    object _24111 = NOVALUE;
    object _24110 = NOVALUE;
    object _24109 = NOVALUE;
    object _24108 = NOVALUE;
    object _24107 = NOVALUE;
    object _24106 = NOVALUE;
    object _24105 = NOVALUE;
    object _24103 = NOVALUE;
    object _24102 = NOVALUE;
    object _24101 = NOVALUE;
    object _24100 = NOVALUE;
    object _24099 = NOVALUE;
    object _24097 = NOVALUE;
    object _24096 = NOVALUE;
    object _24095 = NOVALUE;
    object _24094 = NOVALUE;
    object _24093 = NOVALUE;
    object _24091 = NOVALUE;
    object _24089 = NOVALUE;
    object _24088 = NOVALUE;
    object _24087 = NOVALUE;
    object _24086 = NOVALUE;
    object _24084 = NOVALUE;
    object _24083 = NOVALUE;
    object _24082 = NOVALUE;
    object _24079 = NOVALUE;
    object _24078 = NOVALUE;
    object _24077 = NOVALUE;
    object _24076 = NOVALUE;
    object _24075 = NOVALUE;
    object _24074 = NOVALUE;
    object _24073 = NOVALUE;
    object _24072 = NOVALUE;
    object _24071 = NOVALUE;
    object _24070 = NOVALUE;
    object _24067 = NOVALUE;
    object _24066 = NOVALUE;
    object _24063 = NOVALUE;
    object _24061 = NOVALUE;
    object _24060 = NOVALUE;
    object _24059 = NOVALUE;
    object _24058 = NOVALUE;
    object _24055 = NOVALUE;
    object _24054 = NOVALUE;
    object _24053 = NOVALUE;
    object _24052 = NOVALUE;
    object _24050 = NOVALUE;
    object _24049 = NOVALUE;
    object _24048 = NOVALUE;
    object _24047 = NOVALUE;
    object _24046 = NOVALUE;
    object _24043 = NOVALUE;
    object _24037 = NOVALUE;
    object _24033 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:810		if length(the_file0) then*/
    if (IS_SEQUENCE(_the_file0_46228)){
            _24033 = SEQ_PTR(_the_file0_46228)->length;
    }
    else {
        _24033 = 1;
    }
    if (_24033 == 0)
    {
        _24033 = NOVALUE;
        goto L1; // [10] 22
    }
    else{
        _24033 = NOVALUE;
    }

    /** buildsys.e:811			file0 = filebase(the_file0)*/
    RefDS(_the_file0_46228);
    _0 = _17filebase(_the_file0_46228);
    DeRef(_58file0_44531);
    _58file0_44531 = _0;
L1: 

    /** buildsys.e:813		sequence cmd, objs = "", settings = setup_build(), cwd = current_dir()*/
    RefDS(_21993);
    DeRef(_objs_46235);
    _objs_46235 = _21993;
    _0 = _settings_46236;
    _settings_46236 = _56setup_build();
    DeRef(_0);
    _0 = _cwd_46238;
    _cwd_46238 = _17current_dir();
    DeRef(_0);

    /** buildsys.e:814		integer status*/

    /** buildsys.e:816		ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (object)SEQ_PTR(_settings_46236);
    _24037 = (object)*(((s1_ptr)_2)->base + 6LL);
    Ref(_24037);
    _56ensure_exename(_24037);
    _24037 = NOVALUE;

    /** buildsys.e:818		if not link_only then*/
    if (_link_only_46227 != 0)
    goto L2; // [52] 124

    /** buildsys.e:819			switch compiler_type do*/
    _0 = _56compiler_type_45389;
    switch ( _0 ){ 

        /** buildsys.e:820				case COMPILER_GCC then*/
        case 1:

        /** buildsys.e:821					if not silent then*/
        if (_36silent_21558 != 0)
        goto L3; // [72] 123

        /** buildsys.e:822						ShowMsg(1, COMPILING_WITH_1, {"GCC"})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24042);
        ((intptr_t*)_2)[1] = _24042;
        _24043 = MAKE_SEQ(_1);
        _39ShowMsg(1LL, 176LL, _24043, 1LL);
        _24043 = NOVALUE;
        goto L3; // [90] 123

        /** buildsys.e:825				case COMPILER_WATCOM then*/
        case 2:

        /** buildsys.e:826					write_objlink_file()*/
        _56write_objlink_file();

        /** buildsys.e:828					if not silent then*/
        if (_36silent_21558 != 0)
        goto L4; // [104] 122

        /** buildsys.e:829						ShowMsg(1, COMPILING_WITH_1, {"Watcom"})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24045);
        ((intptr_t*)_2)[1] = _24045;
        _24046 = MAKE_SEQ(_1);
        _39ShowMsg(1LL, 176LL, _24046, 1LL);
        _24046 = NOVALUE;
L4: 
    ;}L3: 
L2: 

    /** buildsys.e:834		if sequence(output_dir) and length(output_dir) > 0 then*/
    _24047 = 1;
    if (_24047 == 0) {
        goto L5; // [131] 159
    }
    if (IS_SEQUENCE(_58output_dir_42577)){
            _24049 = SEQ_PTR(_58output_dir_42577)->length;
    }
    else {
        _24049 = 1;
    }
    _24050 = (_24049 > 0LL);
    _24049 = NOVALUE;
    if (_24050 == 0)
    {
        DeRef(_24050);
        _24050 = NOVALUE;
        goto L5; // [145] 159
    }
    else{
        DeRef(_24050);
        _24050 = NOVALUE;
    }

    /** buildsys.e:835			chdir(output_dir)*/
    RefDS(_58output_dir_42577);
    _31707 = _17chdir(_58output_dir_42577);
    DeRef(_31707);
    _31707 = NOVALUE;
L5: 

    /** buildsys.e:838		sequence link_files = {}*/
    RefDS(_21993);
    DeRef(_link_files_46272);
    _link_files_46272 = _21993;

    /** buildsys.e:840		if not link_only then*/
    if (_link_only_46227 != 0)
    goto L6; // [168] 482

    /** buildsys.e:841			for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42567)){
            _24052 = SEQ_PTR(_58generated_files_42567)->length;
    }
    else {
        _24052 = 1;
    }
    {
        object _i_46276;
        _i_46276 = 1LL;
L7: 
        if (_i_46276 > _24052){
            goto L8; // [178] 479
        }

        /** buildsys.e:842				if generated_files[i][$] = 'c' then*/
        _2 = (object)SEQ_PTR(_58generated_files_42567);
        _24053 = (object)*(((s1_ptr)_2)->base + _i_46276);
        if (IS_SEQUENCE(_24053)){
                _24054 = SEQ_PTR(_24053)->length;
        }
        else {
            _24054 = 1;
        }
        _2 = (object)SEQ_PTR(_24053);
        _24055 = (object)*(((s1_ptr)_2)->base + _24054);
        _24053 = NOVALUE;
        if (binary_op_a(NOTEQ, _24055, 99LL)){
            _24055 = NOVALUE;
            goto L9; // [200] 438
        }
        _24055 = NOVALUE;

        /** buildsys.e:843					cmd = sprintf("%s %s %s", { settings[SETUP_CEXE], settings[SETUP_CFLAGS],*/
        _2 = (object)SEQ_PTR(_settings_46236);
        _24058 = (object)*(((s1_ptr)_2)->base + 1LL);
        _2 = (object)SEQ_PTR(_settings_46236);
        _24059 = (object)*(((s1_ptr)_2)->base + 2LL);
        _2 = (object)SEQ_PTR(_58generated_files_42567);
        _24060 = (object)*(((s1_ptr)_2)->base + _i_46276);
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_24058);
        ((intptr_t*)_2)[1] = _24058;
        Ref(_24059);
        ((intptr_t*)_2)[2] = _24059;
        RefDS(_24060);
        ((intptr_t*)_2)[3] = _24060;
        _24061 = MAKE_SEQ(_1);
        _24060 = NOVALUE;
        _24059 = NOVALUE;
        _24058 = NOVALUE;
        DeRef(_cmd_46234);
        _cmd_46234 = EPrintf(-9999999, _24057, _24061);
        DeRefDS(_24061);
        _24061 = NOVALUE;

        /** buildsys.e:846					link_files = append(link_files, generated_files[i])*/
        _2 = (object)SEQ_PTR(_58generated_files_42567);
        _24063 = (object)*(((s1_ptr)_2)->base + _i_46276);
        RefDS(_24063);
        Append(&_link_files_46272, _link_files_46272, _24063);
        _24063 = NOVALUE;

        /** buildsys.e:848					if not silent then*/
        if (_36silent_21558 != 0)
        goto LA; // [246] 374

        /** buildsys.e:849						atom pdone = 100 * (i / length(generated_files))*/
        if (IS_SEQUENCE(_58generated_files_42567)){
                _24066 = SEQ_PTR(_58generated_files_42567)->length;
        }
        else {
            _24066 = 1;
        }
        _24067 = (_i_46276 % _24066) ? NewDouble((eudouble)_i_46276 / _24066) : (_i_46276 / _24066);
        _24066 = NOVALUE;
        DeRef(_pdone_46298);
        if (IS_ATOM_INT(_24067)) {
            {
                int128_t p128 = (int128_t)100LL * (int128_t)_24067;
                if( p128 != (int128_t)(_pdone_46298 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                    _pdone_46298 = NewDouble( (eudouble)p128 );
                }
            }
        }
        else {
            _pdone_46298 = NewDouble((eudouble)100LL * DBL_PTR(_24067)->dbl);
        }
        DeRef(_24067);
        _24067 = NOVALUE;

        /** buildsys.e:850						if not verbose then*/
        if (_36verbose_21561 != 0)
        goto LB; // [268] 358

        /** buildsys.e:853							if 0 and outdated_files[i] = 0 and force_build = 0 then*/
        if (0LL == 0) {
            _24070 = 0;
            goto LC; // [273] 291
        }
        _2 = (object)SEQ_PTR(_58outdated_files_42568);
        _24071 = (object)*(((s1_ptr)_2)->base + _i_46276);
        if (IS_ATOM_INT(_24071)) {
            _24072 = (_24071 == 0LL);
        }
        else {
            _24072 = binary_op(EQUALS, _24071, 0LL);
        }
        _24071 = NOVALUE;
        if (IS_ATOM_INT(_24072))
        _24070 = (_24072 != 0);
        else
        _24070 = DBL_PTR(_24072)->dbl != 0.0;
LC: 
        if (_24070 == 0) {
            goto LD; // [291] 334
        }
        _24074 = (_56force_build_45411 == 0LL);
        if (_24074 == 0)
        {
            DeRef(_24074);
            _24074 = NOVALUE;
            goto LD; // [302] 334
        }
        else{
            DeRef(_24074);
            _24074 = NOVALUE;
        }

        /** buildsys.e:854								ShowMsg(1, SKIPPING__130_2_UPTODATE, { pdone, generated_files[i] })*/
        _2 = (object)SEQ_PTR(_58generated_files_42567);
        _24075 = (object)*(((s1_ptr)_2)->base + _i_46276);
        RefDS(_24075);
        Ref(_pdone_46298);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _pdone_46298;
        ((intptr_t *)_2)[2] = _24075;
        _24076 = MAKE_SEQ(_1);
        _24075 = NOVALUE;
        _39ShowMsg(1LL, 325LL, _24076, 1LL);
        _24076 = NOVALUE;

        /** buildsys.e:855								continue*/
        DeRef(_pdone_46298);
        _pdone_46298 = NOVALUE;
        goto LE; // [329] 474
        goto LF; // [331] 373
LD: 

        /** buildsys.e:857								ShowMsg(1, COMPILING_130_2, { pdone, generated_files[i] })*/
        _2 = (object)SEQ_PTR(_58generated_files_42567);
        _24077 = (object)*(((s1_ptr)_2)->base + _i_46276);
        RefDS(_24077);
        Ref(_pdone_46298);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _pdone_46298;
        ((intptr_t *)_2)[2] = _24077;
        _24078 = MAKE_SEQ(_1);
        _24077 = NOVALUE;
        _39ShowMsg(1LL, 163LL, _24078, 1LL);
        _24078 = NOVALUE;
        goto LF; // [355] 373
LB: 

        /** buildsys.e:860							ShowMsg(1, COMPILING_130_2, { pdone, cmd })*/
        RefDS(_cmd_46234);
        Ref(_pdone_46298);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _pdone_46298;
        ((intptr_t *)_2)[2] = _cmd_46234;
        _24079 = MAKE_SEQ(_1);
        _39ShowMsg(1LL, 163LL, _24079, 1LL);
        _24079 = NOVALUE;
LF: 
LA: 
        DeRef(_pdone_46298);
        _pdone_46298 = NOVALUE;

        /** buildsys.e:865					status = system_exec(cmd, 0)*/
        _status_46241 = system_exec_call(_cmd_46234, 0LL);

        /** buildsys.e:866					if status != 0 then*/
        if (_status_46241 == 0LL)
        goto L10; // [384] 472

        /** buildsys.e:867						ShowMsg(2, COULDNT_COMPILE_FILE_1, { generated_files[i] })*/
        _2 = (object)SEQ_PTR(_58generated_files_42567);
        _24082 = (object)*(((s1_ptr)_2)->base + _i_46276);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24082);
        ((intptr_t*)_2)[1] = _24082;
        _24083 = MAKE_SEQ(_1);
        _24082 = NOVALUE;
        _39ShowMsg(2LL, 164LL, _24083, 1LL);
        _24083 = NOVALUE;

        /** buildsys.e:868						ShowMsg(2, STATUS_1_COMMAND_2, { status, cmd })*/
        RefDS(_cmd_46234);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _status_46241;
        ((intptr_t *)_2)[2] = _cmd_46234;
        _24084 = MAKE_SEQ(_1);
        _39ShowMsg(2LL, 165LL, _24084, 1LL);
        _24084 = NOVALUE;

        /** buildsys.e:869						goto "build_direct_cleanup"*/
        goto G11;
        goto L10; // [435] 472
L9: 

        /** buildsys.e:871				elsif match(".o", generated_files[i]) then*/
        _2 = (object)SEQ_PTR(_58generated_files_42567);
        _24086 = (object)*(((s1_ptr)_2)->base + _i_46276);
        _24087 = e_match_from(_23144, _24086, 1LL);
        _24086 = NOVALUE;
        if (_24087 == 0)
        {
            _24087 = NOVALUE;
            goto L12; // [451] 471
        }
        else{
            _24087 = NOVALUE;
        }

        /** buildsys.e:872					objs &= " " & generated_files[i]*/
        _2 = (object)SEQ_PTR(_58generated_files_42567);
        _24088 = (object)*(((s1_ptr)_2)->base + _i_46276);
        Concat((object_ptr)&_24089, _23384, _24088);
        _24088 = NOVALUE;
        Concat((object_ptr)&_objs_46235, _objs_46235, _24089);
        DeRefDS(_24089);
        _24089 = NOVALUE;
L12: 
L10: 

        /** buildsys.e:874			end for*/
LE: 
        _i_46276 = _i_46276 + 1LL;
        goto L7; // [474] 185
L8: 
        ;
    }
    goto L13; // [479] 541
L6: 

    /** buildsys.e:876			object files = read_lines(file0 & ".bld")*/
    Concat((object_ptr)&_24091, _58file0_44531, _23594);
    _0 = _files_46349;
    _files_46349 = _8read_lines(_24091);
    DeRef(_0);
    _24091 = NOVALUE;

    /** buildsys.e:877			for i = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_46349)){
            _24093 = SEQ_PTR(_files_46349)->length;
    }
    else {
        _24093 = 1;
    }
    {
        object _i_46355;
        _i_46355 = 1LL;
L14: 
        if (_i_46355 > _24093){
            goto L15; // [499] 538
        }

        /** buildsys.e:878				objs &= " " & filebase(files[i]) & "." & settings[SETUP_OBJ_EXT]*/
        _2 = (object)SEQ_PTR(_files_46349);
        _24094 = (object)*(((s1_ptr)_2)->base + _i_46355);
        Ref(_24094);
        _24095 = _17filebase(_24094);
        _24094 = NOVALUE;
        _2 = (object)SEQ_PTR(_settings_46236);
        _24096 = (object)*(((s1_ptr)_2)->base + 5LL);
        {
            object concat_list[4];

            concat_list[0] = _24096;
            concat_list[1] = _23183;
            concat_list[2] = _24095;
            concat_list[3] = _23384;
            Concat_N((object_ptr)&_24097, concat_list, 4);
        }
        _24096 = NOVALUE;
        DeRef(_24095);
        _24095 = NOVALUE;
        Concat((object_ptr)&_objs_46235, _objs_46235, _24097);
        DeRefDS(_24097);
        _24097 = NOVALUE;

        /** buildsys.e:879			end for*/
        _i_46355 = _i_46355 + 1LL;
        goto L14; // [533] 506
L15: 
        ;
    }
    DeRef(_files_46349);
    _files_46349 = NOVALUE;
L13: 

    /** buildsys.e:882		if keep and not link_only and length(link_files) then*/
    if (_58keep_42570 == 0) {
        _24099 = 0;
        goto L16; // [545] 556
    }
    _24100 = (_link_only_46227 == 0);
    _24099 = (_24100 != 0);
L16: 
    if (_24099 == 0) {
        goto L17; // [556] 585
    }
    if (IS_SEQUENCE(_link_files_46272)){
            _24102 = SEQ_PTR(_link_files_46272)->length;
    }
    else {
        _24102 = 1;
    }
    if (_24102 == 0)
    {
        _24102 = NOVALUE;
        goto L17; // [564] 585
    }
    else{
        _24102 = NOVALUE;
    }

    /** buildsys.e:883			write_lines(file0 & ".bld", link_files)*/
    Concat((object_ptr)&_24103, _58file0_44531, _23594);
    RefDS(_link_files_46272);
    _31706 = _8write_lines(_24103, _link_files_46272);
    _24103 = NOVALUE;
    DeRef(_31706);
    _31706 = NOVALUE;
    goto L18; // [582] 609
L17: 

    /** buildsys.e:884		elsif keep = 0 then*/
    if (_58keep_42570 != 0LL)
    goto L19; // [589] 608

    /** buildsys.e:886			delete_file(file0 & ".bld")*/
    Concat((object_ptr)&_24105, _58file0_44531, _23594);
    _31705 = _17delete_file(_24105);
    _24105 = NOVALUE;
    DeRef(_31705);
    _31705 = NOVALUE;
L19: 
L18: 

    /** buildsys.e:890		if length(rc_file[D_ALTNAME]) and length(settings[SETUP_RC_COMPILER]) and compiler_type = COMPILER_GCC then*/
    _2 = (object)SEQ_PTR(_56rc_file_45398);
    _24106 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (IS_SEQUENCE(_24106)){
            _24107 = SEQ_PTR(_24106)->length;
    }
    else {
        _24107 = 1;
    }
    _24106 = NOVALUE;
    if (_24107 == 0) {
        _24108 = 0;
        goto L1A; // [622] 637
    }
    _2 = (object)SEQ_PTR(_settings_46236);
    _24109 = (object)*(((s1_ptr)_2)->base + 8LL);
    if (IS_SEQUENCE(_24109)){
            _24110 = SEQ_PTR(_24109)->length;
    }
    else {
        _24110 = 1;
    }
    _24109 = NOVALUE;
    _24108 = (_24110 != 0);
L1A: 
    if (_24108 == 0) {
        goto L1B; // [637] 742
    }
    _24112 = (_56compiler_type_45389 == 1LL);
    if (_24112 == 0)
    {
        DeRef(_24112);
        _24112 = NOVALUE;
        goto L1B; // [648] 742
    }
    else{
        DeRef(_24112);
        _24112 = NOVALUE;
    }

    /** buildsys.e:891			cmd = text:format(settings[SETUP_RC_COMPILER], { rc_file[D_ALTNAME], res_file[D_ALTNAME] })*/
    _2 = (object)SEQ_PTR(_settings_46236);
    _24113 = (object)*(((s1_ptr)_2)->base + 8LL);
    _2 = (object)SEQ_PTR(_56rc_file_45398);
    _24114 = (object)*(((s1_ptr)_2)->base + 11LL);
    _2 = (object)SEQ_PTR(_56res_file_45404);
    _24115 = (object)*(((s1_ptr)_2)->base + 11LL);
    Ref(_24115);
    Ref(_24114);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24114;
    ((intptr_t *)_2)[2] = _24115;
    _24116 = MAKE_SEQ(_1);
    _24115 = NOVALUE;
    _24114 = NOVALUE;
    Ref(_24113);
    _0 = _cmd_46234;
    _cmd_46234 = _14format(_24113, _24116);
    DeRef(_0);
    _24113 = NOVALUE;
    _24116 = NOVALUE;

    /** buildsys.e:892			status = system_exec(cmd, 0)*/
    _status_46241 = system_exec_call(_cmd_46234, 0LL);

    /** buildsys.e:893			if status != 0 then*/
    if (_status_46241 == 0LL)
    goto L1C; // [692] 741

    /** buildsys.e:894				ShowMsg(2, UNABLE_TO_COMPILE_RESOURCE_FILE_1, { rc_file[D_NAME] })*/
    _2 = (object)SEQ_PTR(_56rc_file_45398);
    _24120 = (object)*(((s1_ptr)_2)->base + 1LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24120);
    ((intptr_t*)_2)[1] = _24120;
    _24121 = MAKE_SEQ(_1);
    _24120 = NOVALUE;
    _39ShowMsg(2LL, 350LL, _24121, 1LL);
    _24121 = NOVALUE;

    /** buildsys.e:895				ShowMsg(2, STATUS_1_COMMAND_2_A, { status, cmd })*/
    RefDS(_cmd_46234);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _status_46241;
    ((intptr_t *)_2)[2] = _cmd_46234;
    _24122 = MAKE_SEQ(_1);
    _39ShowMsg(2LL, 169LL, _24122, 1LL);
    _24122 = NOVALUE;

    /** buildsys.e:897				goto "build_direct_cleanup"*/
    goto G11;
L1C: 
L1B: 

    /** buildsys.e:901		switch compiler_type do*/
    _0 = _56compiler_type_45389;
    switch ( _0 ){ 

        /** buildsys.e:902			case COMPILER_WATCOM then*/
        case 2:

        /** buildsys.e:903				cmd = sprintf("%s @%s.lnk", { settings[SETUP_LEXE], file0 })*/
        _2 = (object)SEQ_PTR(_settings_46236);
        _24126 = (object)*(((s1_ptr)_2)->base + 3LL);
        RefDS(_58file0_44531);
        Ref(_24126);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _24126;
        ((intptr_t *)_2)[2] = _58file0_44531;
        _24127 = MAKE_SEQ(_1);
        _24126 = NOVALUE;
        DeRef(_cmd_46234);
        _cmd_46234 = EPrintf(-9999999, _24125, _24127);
        DeRefDS(_24127);
        _24127 = NOVALUE;
        goto L1D; // [771] 848

        /** buildsys.e:905			case COMPILER_GCC then*/
        case 1:

        /** buildsys.e:906				cmd = sprintf("%s -o %s %s %s %s", { */
        _2 = (object)SEQ_PTR(_settings_46236);
        _24130 = (object)*(((s1_ptr)_2)->base + 3LL);
        _2 = (object)SEQ_PTR(_56exe_name_45392);
        _24131 = (object)*(((s1_ptr)_2)->base + 11LL);
        Ref(_24131);
        _24132 = _56adjust_for_build_file(_24131);
        _24131 = NOVALUE;
        _2 = (object)SEQ_PTR(_56res_file_45404);
        _24133 = (object)*(((s1_ptr)_2)->base + 11LL);
        _2 = (object)SEQ_PTR(_settings_46236);
        _24134 = (object)*(((s1_ptr)_2)->base + 4LL);
        _1 = NewS1(5);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_24130);
        ((intptr_t*)_2)[1] = _24130;
        ((intptr_t*)_2)[2] = _24132;
        RefDS(_objs_46235);
        ((intptr_t*)_2)[3] = _objs_46235;
        Ref(_24133);
        ((intptr_t*)_2)[4] = _24133;
        Ref(_24134);
        ((intptr_t*)_2)[5] = _24134;
        _24135 = MAKE_SEQ(_1);
        _24134 = NOVALUE;
        _24133 = NOVALUE;
        _24132 = NOVALUE;
        _24130 = NOVALUE;
        DeRef(_cmd_46234);
        _cmd_46234 = EPrintf(-9999999, _24129, _24135);
        DeRefDS(_24135);
        _24135 = NOVALUE;
        goto L1D; // [819] 848

        /** buildsys.e:915			case else*/
        default:

        /** buildsys.e:916				ShowMsg(2, UNKNOWN_COMPILER_TYPE_1, { compiler_type })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _56compiler_type_45389;
        _24137 = MAKE_SEQ(_1);
        _39ShowMsg(2LL, 167LL, _24137, 1LL);
        _24137 = NOVALUE;

        /** buildsys.e:918				goto "build_direct_cleanup"*/
        goto G11;
    ;}L1D: 

    /** buildsys.e:921		if not silent then*/
    if (_36silent_21558 != 0)
    goto L1E; // [852] 910

    /** buildsys.e:922			if not verbose then*/
    if (_36verbose_21561 != 0)
    goto L1F; // [859] 892

    /** buildsys.e:923				ShowMsg(1, LINKING_100_1, { abbreviate_path(exe_name[D_NAME]) })*/
    _2 = (object)SEQ_PTR(_56exe_name_45392);
    _24140 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_24140);
    RefDS(_21993);
    _24141 = _17abbreviate_path(_24140, _21993);
    _24140 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24141;
    _24142 = MAKE_SEQ(_1);
    _24141 = NOVALUE;
    _39ShowMsg(1LL, 166LL, _24142, 1LL);
    _24142 = NOVALUE;
    goto L20; // [889] 909
L1F: 

    /** buildsys.e:925				ShowMsg(1, LINKING_100_1, { cmd })*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_cmd_46234);
    ((intptr_t*)_2)[1] = _cmd_46234;
    _24143 = MAKE_SEQ(_1);
    _39ShowMsg(1LL, 166LL, _24143, 1LL);
    _24143 = NOVALUE;
L20: 
L1E: 

    /** buildsys.e:929		status = system_exec(cmd, 0)*/
    _status_46241 = system_exec_call(_cmd_46234, 0LL);

    /** buildsys.e:930		if status != 0 then*/
    if (_status_46241 == 0LL)
    goto L21; // [920] 967

    /** buildsys.e:931			ShowMsg(2, UNABLE_TO_LINK_1, { exe_name[D_NAME] })*/
    _2 = (object)SEQ_PTR(_56exe_name_45392);
    _24146 = (object)*(((s1_ptr)_2)->base + 1LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24146);
    ((intptr_t*)_2)[1] = _24146;
    _24147 = MAKE_SEQ(_1);
    _24146 = NOVALUE;
    _39ShowMsg(2LL, 168LL, _24147, 1LL);
    _24147 = NOVALUE;

    /** buildsys.e:932			ShowMsg(2, STATUS_1_COMMAND_2_A, { status, cmd })*/
    RefDS(_cmd_46234);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _status_46241;
    ((intptr_t *)_2)[2] = _cmd_46234;
    _24148 = MAKE_SEQ(_1);
    _39ShowMsg(2LL, 169LL, _24148, 1LL);
    _24148 = NOVALUE;

    /** buildsys.e:934			goto "build_direct_cleanup"*/
    goto G11;
L21: 

    /** buildsys.e:938		if length(rc_file[D_ALTNAME]) and length(settings[SETUP_RC_COMPILER]) and compiler_type = COMPILER_WATCOM then*/
    _2 = (object)SEQ_PTR(_56rc_file_45398);
    _24149 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (IS_SEQUENCE(_24149)){
            _24150 = SEQ_PTR(_24149)->length;
    }
    else {
        _24150 = 1;
    }
    _24149 = NOVALUE;
    if (_24150 == 0) {
        _24151 = 0;
        goto L22; // [980] 995
    }
    _2 = (object)SEQ_PTR(_settings_46236);
    _24152 = (object)*(((s1_ptr)_2)->base + 8LL);
    if (IS_SEQUENCE(_24152)){
            _24153 = SEQ_PTR(_24152)->length;
    }
    else {
        _24153 = 1;
    }
    _24152 = NOVALUE;
    _24151 = (_24153 != 0);
L22: 
    if (_24151 == 0) {
        goto L23; // [995] 1118
    }
    _24155 = (_56compiler_type_45389 == 2LL);
    if (_24155 == 0)
    {
        DeRef(_24155);
        _24155 = NOVALUE;
        goto L23; // [1006] 1118
    }
    else{
        DeRef(_24155);
        _24155 = NOVALUE;
    }

    /** buildsys.e:939			cmd = text:format(settings[SETUP_RC_COMPILER], { rc_file[D_ALTNAME], res_file[D_ALTNAME], exe_name[D_ALTNAME] })*/
    _2 = (object)SEQ_PTR(_settings_46236);
    _24156 = (object)*(((s1_ptr)_2)->base + 8LL);
    _2 = (object)SEQ_PTR(_56rc_file_45398);
    _24157 = (object)*(((s1_ptr)_2)->base + 11LL);
    _2 = (object)SEQ_PTR(_56res_file_45404);
    _24158 = (object)*(((s1_ptr)_2)->base + 11LL);
    _2 = (object)SEQ_PTR(_56exe_name_45392);
    _24159 = (object)*(((s1_ptr)_2)->base + 11LL);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24157);
    ((intptr_t*)_2)[1] = _24157;
    Ref(_24158);
    ((intptr_t*)_2)[2] = _24158;
    Ref(_24159);
    ((intptr_t*)_2)[3] = _24159;
    _24160 = MAKE_SEQ(_1);
    _24159 = NOVALUE;
    _24158 = NOVALUE;
    _24157 = NOVALUE;
    Ref(_24156);
    _0 = _cmd_46234;
    _cmd_46234 = _14format(_24156, _24160);
    DeRef(_0);
    _24156 = NOVALUE;
    _24160 = NOVALUE;

    /** buildsys.e:940			status = system_exec(cmd, 0)*/
    _status_46241 = system_exec_call(_cmd_46234, 0LL);

    /** buildsys.e:941			if status != 0 then*/
    if (_status_46241 == 0LL)
    goto L24; // [1060] 1117

    /** buildsys.e:942				ShowMsg(2, UNABLE_TO_LINK_RESOURCE_FILE_1_INTO_EXECUTABLE_2, { rc_file[D_NAME], exe_name[D_NAME] })*/
    _2 = (object)SEQ_PTR(_56rc_file_45398);
    _24164 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_56exe_name_45392);
    _24165 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_24165);
    Ref(_24164);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24164;
    ((intptr_t *)_2)[2] = _24165;
    _24166 = MAKE_SEQ(_1);
    _24165 = NOVALUE;
    _24164 = NOVALUE;
    _39ShowMsg(2LL, 187LL, _24166, 1LL);
    _24166 = NOVALUE;

    /** buildsys.e:943				ShowMsg(2, STATUS_1_COMMAND_2_A, { status, cmd })*/
    RefDS(_cmd_46234);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _status_46241;
    ((intptr_t *)_2)[2] = _cmd_46234;
    _24167 = MAKE_SEQ(_1);
    _39ShowMsg(2LL, 169LL, _24167, 1LL);
    _24167 = NOVALUE;

    /** buildsys.e:945				goto "build_direct_cleanup"*/
    goto G11;
L24: 
L23: 

    /** buildsys.e:949	label "build_direct_cleanup"*/
G11:

    /** buildsys.e:950		if keep = 0 then*/
    if (_58keep_42570 != 0LL)
    goto L25; // [1126] 1277

    /** buildsys.e:951			for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42567)){
            _24169 = SEQ_PTR(_58generated_files_42567)->length;
    }
    else {
        _24169 = 1;
    }
    {
        object _i_46491;
        _i_46491 = 1LL;
L26: 
        if (_i_46491 > _24169){
            goto L27; // [1137] 1193
        }

        /** buildsys.e:952				if verbose then*/
        if (_36verbose_21561 == 0)
        {
            goto L28; // [1148] 1172
        }
        else{
        }

        /** buildsys.e:953					ShowMsg(1, DELETING_1, { generated_files[i] })*/
        _2 = (object)SEQ_PTR(_58generated_files_42567);
        _24170 = (object)*(((s1_ptr)_2)->base + _i_46491);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24170);
        ((intptr_t*)_2)[1] = _24170;
        _24171 = MAKE_SEQ(_1);
        _24170 = NOVALUE;
        _39ShowMsg(1LL, 347LL, _24171, 1LL);
        _24171 = NOVALUE;
L28: 

        /** buildsys.e:955				delete_file(generated_files[i])*/
        _2 = (object)SEQ_PTR(_58generated_files_42567);
        _24172 = (object)*(((s1_ptr)_2)->base + _i_46491);
        RefDS(_24172);
        _31704 = _17delete_file(_24172);
        _24172 = NOVALUE;
        DeRef(_31704);
        _31704 = NOVALUE;

        /** buildsys.e:956			end for*/
        _i_46491 = _i_46491 + 1LL;
        goto L26; // [1188] 1144
L27: 
        ;
    }

    /** buildsys.e:958			if length(res_file[D_ALTNAME]) then*/
    _2 = (object)SEQ_PTR(_56res_file_45404);
    _24173 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (IS_SEQUENCE(_24173)){
            _24174 = SEQ_PTR(_24173)->length;
    }
    else {
        _24174 = 1;
    }
    _24173 = NOVALUE;
    if (_24174 == 0)
    {
        _24174 = NOVALUE;
        goto L29; // [1206] 1226
    }
    else{
        _24174 = NOVALUE;
    }

    /** buildsys.e:959				delete_file(res_file[D_ALTNAME])*/
    _2 = (object)SEQ_PTR(_56res_file_45404);
    _24175 = (object)*(((s1_ptr)_2)->base + 11LL);
    Ref(_24175);
    _31703 = _17delete_file(_24175);
    _24175 = NOVALUE;
    DeRef(_31703);
    _31703 = NOVALUE;
L29: 

    /** buildsys.e:962			if remove_output_dir then*/
    if (_56remove_output_dir_45412 == 0)
    {
        goto L2A; // [1230] 1276
    }
    else{
    }

    /** buildsys.e:963				chdir(cwd)*/
    RefDS(_cwd_46238);
    _31702 = _17chdir(_cwd_46238);
    DeRef(_31702);
    _31702 = NOVALUE;

    /** buildsys.e:966				if not remove_directory(output_dir) then*/
    RefDS(_58output_dir_42577);
    _24176 = _17remove_directory(_58output_dir_42577, 0LL);
    if (IS_ATOM_INT(_24176)) {
        if (_24176 != 0){
            DeRef(_24176);
            _24176 = NOVALUE;
            goto L2B; // [1250] 1275
        }
    }
    else {
        if (DBL_PTR(_24176)->dbl != 0.0){
            DeRef(_24176);
            _24176 = NOVALUE;
            goto L2B; // [1250] 1275
        }
    }
    DeRef(_24176);
    _24176 = NOVALUE;

    /** buildsys.e:967					ShowMsg(2, COULD_NOT_REMOVE_DIRECTORY_1, { abbreviate_path(output_dir) })*/
    RefDS(_58output_dir_42577);
    RefDS(_21993);
    _24178 = _17abbreviate_path(_58output_dir_42577, _21993);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24178;
    _24179 = MAKE_SEQ(_1);
    _24178 = NOVALUE;
    _39ShowMsg(2LL, 194LL, _24179, 1LL);
    _24179 = NOVALUE;
L2B: 
L2A: 
L25: 

    /** buildsys.e:972		chdir(cwd)*/
    RefDS(_cwd_46238);
    _31701 = _17chdir(_cwd_46238);
    DeRef(_31701);
    _31701 = NOVALUE;

    /** buildsys.e:973	end procedure*/
    DeRefDS(_the_file0_46228);
    DeRef(_cmd_46234);
    DeRef(_objs_46235);
    DeRef(_settings_46236);
    DeRefDS(_cwd_46238);
    DeRef(_link_files_46272);
    _24152 = NOVALUE;
    DeRef(_24100);
    _24100 = NOVALUE;
    _24109 = NOVALUE;
    _24149 = NOVALUE;
    _24106 = NOVALUE;
    DeRef(_24072);
    _24072 = NOVALUE;
    _24173 = NOVALUE;
    return;
    ;
}


void _56write_buildfile()
{
    object _make_command_46533 = NOVALUE;
    object _settings_46578 = NOVALUE;
    object _24202 = NOVALUE;
    object _24201 = NOVALUE;
    object _24197 = NOVALUE;
    object _24196 = NOVALUE;
    object _24195 = NOVALUE;
    object _24193 = NOVALUE;
    object _24192 = NOVALUE;
    object _24191 = NOVALUE;
    object _24190 = NOVALUE;
    object _24189 = NOVALUE;
    object _24188 = NOVALUE;
    object _24187 = NOVALUE;
    object _24186 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:982		switch build_system_type do*/
    _0 = _56build_system_type_45385;
    switch ( _0 ){ 

        /** buildsys.e:983			case BUILD_MAKEFILE_FULL then*/
        case 2:

        /** buildsys.e:984				write_makefile_full()*/
        _56write_makefile_full();

        /** buildsys.e:986				if not silent then*/
        if (_36silent_21558 != 0)
        goto L1; // [22] 142

        /** buildsys.e:987					sequence make_command*/

        /** buildsys.e:988					if compiler_type = COMPILER_WATCOM then*/
        if (_56compiler_type_45389 != 2LL)
        goto L2; // [31] 45

        /** buildsys.e:989						make_command = "wmake /f "*/
        RefDS(_24184);
        DeRefi(_make_command_46533);
        _make_command_46533 = _24184;
        goto L3; // [42] 53
L2: 

        /** buildsys.e:991						make_command = "make -f "*/
        RefDS(_24185);
        DeRefi(_make_command_46533);
        _make_command_46533 = _24185;
L3: 

        /** buildsys.e:994					ShowMsg(1, MSG_1C_FILES_WERE_CREATED, { cfile_count + 2 })*/
        _24186 = _36cfile_count_21521 + 2LL;
        if ((object)((uintptr_t)_24186 + (uintptr_t)HIGH_BITS) >= 0){
            _24186 = NewDouble((eudouble)_24186);
        }
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _24186;
        _24187 = MAKE_SEQ(_1);
        _24186 = NOVALUE;
        _39ShowMsg(1LL, 170LL, _24187, 1LL);
        _24187 = NOVALUE;

        /** buildsys.e:996					if sequence(output_dir) and length(output_dir) > 0 then*/
        _24188 = 1;
        if (_24188 == 0) {
            goto L4; // [80] 122
        }
        if (IS_SEQUENCE(_58output_dir_42577)){
                _24190 = SEQ_PTR(_58output_dir_42577)->length;
        }
        else {
            _24190 = 1;
        }
        _24191 = (_24190 > 0LL);
        _24190 = NOVALUE;
        if (_24191 == 0)
        {
            DeRef(_24191);
            _24191 = NOVALUE;
            goto L4; // [94] 122
        }
        else{
            DeRef(_24191);
            _24191 = NOVALUE;
        }

        /** buildsys.e:997						ShowMsg(1, TO_BUILD_YOUR_PROJECT_CHANGE_DIRECTORY_TO_1_AND_TYPE_23MAK, { output_dir, make_command, file0 })*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_58output_dir_42577);
        ((intptr_t*)_2)[1] = _58output_dir_42577;
        RefDS(_make_command_46533);
        ((intptr_t*)_2)[2] = _make_command_46533;
        RefDS(_58file0_44531);
        ((intptr_t*)_2)[3] = _58file0_44531;
        _24192 = MAKE_SEQ(_1);
        _39ShowMsg(1LL, 174LL, _24192, 1LL);
        _24192 = NOVALUE;
        goto L5; // [119] 141
L4: 

        /** buildsys.e:999						ShowMsg(1, TO_BUILD_YOUR_PROJECT_TYPE_12MAK, { make_command, file0 })*/
        RefDS(_58file0_44531);
        RefDS(_make_command_46533);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _make_command_46533;
        ((intptr_t *)_2)[2] = _58file0_44531;
        _24193 = MAKE_SEQ(_1);
        _39ShowMsg(1LL, 172LL, _24193, 1LL);
        _24193 = NOVALUE;
L5: 
L1: 
        DeRefi(_make_command_46533);
        _make_command_46533 = NOVALUE;
        goto L6; // [144] 277

        /** buildsys.e:1003			case BUILD_MAKEFILE_PARTIAL then*/
        case 1:

        /** buildsys.e:1004				write_makefile_partial()*/
        _56write_makefile_partial();

        /** buildsys.e:1006				if not silent then*/
        if (_36silent_21558 != 0)
        goto L6; // [158] 277

        /** buildsys.e:1007					ShowMsg(1, MSG_1C_FILES_WERE_CREATED, { cfile_count + 2 })*/
        _24195 = _36cfile_count_21521 + 2LL;
        if ((object)((uintptr_t)_24195 + (uintptr_t)HIGH_BITS) >= 0){
            _24195 = NewDouble((eudouble)_24195);
        }
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _24195;
        _24196 = MAKE_SEQ(_1);
        _24195 = NOVALUE;
        _39ShowMsg(1LL, 170LL, _24196, 1LL);
        _24196 = NOVALUE;

        /** buildsys.e:1008					ShowMsg(1, TO_BUILD_YOUR_PROJECT_INCLUDE_1MAK_INTO_A_LARGER_MAKEFILE_PROJECT, { file0 })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_58file0_44531);
        ((intptr_t*)_2)[1] = _58file0_44531;
        _24197 = MAKE_SEQ(_1);
        _39ShowMsg(1LL, 173LL, _24197, 1LL);
        _24197 = NOVALUE;
        goto L6; // [198] 277

        /** buildsys.e:1011			case BUILD_DIRECT then*/
        case 3:

        /** buildsys.e:1012				build_direct()*/
        RefDS(_21993);
        _56build_direct(0LL, _21993);

        /** buildsys.e:1014				if not silent then*/
        if (_36silent_21558 != 0)
        goto L7; // [214] 225

        /** buildsys.e:1015					sequence settings = setup_build()*/
        _0 = _settings_46578;
        _settings_46578 = _56setup_build();
        DeRef(_0);
L7: 
        DeRef(_settings_46578);
        _settings_46578 = NOVALUE;
        goto L6; // [227] 277

        /** buildsys.e:1019			case BUILD_NONE then*/
        case 0:

        /** buildsys.e:1020				if not silent then*/
        if (_36silent_21558 != 0)
        goto L6; // [237] 277

        /** buildsys.e:1021					ShowMsg(1, MSG_1C_FILES_WERE_CREATED, { cfile_count + 2 })*/
        _24201 = _36cfile_count_21521 + 2LL;
        if ((object)((uintptr_t)_24201 + (uintptr_t)HIGH_BITS) >= 0){
            _24201 = NewDouble((eudouble)_24201);
        }
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _24201;
        _24202 = MAKE_SEQ(_1);
        _24201 = NOVALUE;
        _39ShowMsg(1LL, 170LL, _24202, 1LL);
        _24202 = NOVALUE;
        goto L6; // [261] 277

        /** buildsys.e:1026			case else*/
        default:

        /** buildsys.e:1027				CompileErr(UNKNOWN_BUILD_FILE_TYPE)*/
        RefDS(_21993);
        _50CompileErr(151LL, _21993, 0LL);
    ;}L6: 

    /** buildsys.e:1029	end procedure*/
    return;
    ;
}



// 0x2C913675
