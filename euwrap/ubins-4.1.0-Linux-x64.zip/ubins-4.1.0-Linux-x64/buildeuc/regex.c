// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _52new(object _pattern_22162, object _options_22163)
{
    object _12515 = NOVALUE;
    object _12514 = NOVALUE;
    object _12512 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:723		if sequence(options) then */
    _12512 = 0;
    if (_12512 == 0)
    {
        _12512 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _12512 = NOVALUE;
    }

    /** regex.e:724			options = math:or_all(options) */
    _options_22163 = _20or_all(_options_22163);
L1: 

    /** regex.e:730		return machine_func(M_PCRE_COMPILE, { pattern, options })*/
    Ref(_options_22163);
    Ref(_pattern_22162);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _pattern_22162;
    ((intptr_t *)_2)[2] = _options_22163;
    _12514 = MAKE_SEQ(_1);
    _12515 = machine(68LL, _12514);
    DeRefDS(_12514);
    _12514 = NOVALUE;
    DeRefi(_pattern_22162);
    DeRef(_options_22163);
    return _12515;
    ;
}


object _52get_ovector_size(object _ex_22182, object _maxsize_22183)
{
    object _m_22184 = NOVALUE;
    object _12523 = NOVALUE;
    object _12520 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:804		integer m = machine_func(M_PCRE_GET_OVECTOR_SIZE, {ex})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_ex_22182);
    ((intptr_t*)_2)[1] = _ex_22182;
    _12520 = MAKE_SEQ(_1);
    _m_22184 = machine(97LL, _12520);
    DeRefDS(_12520);
    _12520 = NOVALUE;
    if (!IS_ATOM_INT(_m_22184)) {
        _1 = (object)(DBL_PTR(_m_22184)->dbl);
        DeRefDS(_m_22184);
        _m_22184 = _1;
    }

    /** regex.e:805		if (m > maxsize) then*/
    if (_m_22184 <= 30LL)
    goto L1; // [17] 28

    /** regex.e:806			return maxsize*/
    DeRef(_ex_22182);
    return 30LL;
L1: 

    /** regex.e:809		return m+1*/
    _12523 = _m_22184 + 1;
    if (_12523 > MAXINT){
        _12523 = NewDouble((eudouble)_12523);
    }
    DeRef(_ex_22182);
    return _12523;
    ;
}


object _52find(object _re_22192, object _haystack_22194, object _from_22195, object _options_22196, object _size_22197)
{
    object _12530 = NOVALUE;
    object _12529 = NOVALUE;
    object _12528 = NOVALUE;
    object _12525 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_size_22197)) {
        _1 = (object)(DBL_PTR(_size_22197)->dbl);
        DeRefDS(_size_22197);
        _size_22197 = _1;
    }

    /** regex.e:872		if sequence(options) then */
    _12525 = IS_SEQUENCE(_options_22196);
    if (_12525 == 0)
    {
        _12525 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _12525 = NOVALUE;
    }

    /** regex.e:873			options = math:or_all(options) */
    Ref(_options_22196);
    _0 = _options_22196;
    _options_22196 = _20or_all(_options_22196);
    DeRef(_0);
L1: 

    /** regex.e:876		if size < 0 then*/
    if (_size_22197 >= 0LL)
    goto L2; // [22] 32

    /** regex.e:877			size = 0*/
    _size_22197 = 0LL;
L2: 

    /** regex.e:880		return machine_func(M_PCRE_EXEC, { re, haystack, length(haystack), options, from, size })*/
    if (IS_SEQUENCE(_haystack_22194)){
            _12528 = SEQ_PTR(_haystack_22194)->length;
    }
    else {
        _12528 = 1;
    }
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_re_22192);
    ((intptr_t*)_2)[1] = _re_22192;
    Ref(_haystack_22194);
    ((intptr_t*)_2)[2] = _haystack_22194;
    ((intptr_t*)_2)[3] = _12528;
    Ref(_options_22196);
    ((intptr_t*)_2)[4] = _options_22196;
    ((intptr_t*)_2)[5] = _from_22195;
    ((intptr_t*)_2)[6] = _size_22197;
    _12529 = MAKE_SEQ(_1);
    _12528 = NOVALUE;
    _12530 = machine(70LL, _12529);
    DeRefDS(_12529);
    _12529 = NOVALUE;
    DeRef(_re_22192);
    DeRef(_haystack_22194);
    DeRef(_options_22196);
    return _12530;
    ;
}


object _52matches(object _re_22272, object _haystack_22274, object _from_22275, object _options_22276)
{
    object _str_offsets_22280 = NOVALUE;
    object _match_data_22282 = NOVALUE;
    object _tmp_22292 = NOVALUE;
    object _12584 = NOVALUE;
    object _12583 = NOVALUE;
    object _12582 = NOVALUE;
    object _12581 = NOVALUE;
    object _12580 = NOVALUE;
    object _12578 = NOVALUE;
    object _12577 = NOVALUE;
    object _12576 = NOVALUE;
    object _12575 = NOVALUE;
    object _12573 = NOVALUE;
    object _12572 = NOVALUE;
    object _12571 = NOVALUE;
    object _12570 = NOVALUE;
    object _12568 = NOVALUE;
    object _12567 = NOVALUE;
    object _12566 = NOVALUE;
    object _12563 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:1038		if sequence(options) then */
    _12563 = 0;
    if (_12563 == 0)
    {
        _12563 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _12563 = NOVALUE;
    }

    /** regex.e:1039			options = math:or_all(options) */
    _options_22276 = _20or_all(0LL);
L1: 

    /** regex.e:1041		integer str_offsets = and_bits(STRING_OFFSETS, options)*/
    if (IS_ATOM_INT(_options_22276)) {
        {uintptr_t tu;
             tu = (uintptr_t)201326592LL & (uintptr_t)_options_22276;
             _str_offsets_22280 = MAKE_UINT(tu);
        }
    }
    else {
        _str_offsets_22280 = binary_op(AND_BITS, 201326592LL, _options_22276);
    }
    if (!IS_ATOM_INT(_str_offsets_22280)) {
        _1 = (object)(DBL_PTR(_str_offsets_22280)->dbl);
        DeRefDS(_str_offsets_22280);
        _str_offsets_22280 = _1;
    }

    /** regex.e:1042		object match_data = find(re, haystack, from, and_bits(options, not_bits(STRING_OFFSETS)))*/
    _12566 = not_bits(201326592LL);
    if (IS_ATOM_INT(_options_22276) && IS_ATOM_INT(_12566)) {
        {uintptr_t tu;
             tu = (uintptr_t)_options_22276 & (uintptr_t)_12566;
             _12567 = MAKE_UINT(tu);
        }
    }
    else {
        _12567 = binary_op(AND_BITS, _options_22276, _12566);
    }
    DeRef(_12566);
    _12566 = NOVALUE;
    Ref(_re_22272);
    _12568 = _52get_ovector_size(_re_22272, 30LL);
    Ref(_re_22272);
    Ref(_haystack_22274);
    _0 = _match_data_22282;
    _match_data_22282 = _52find(_re_22272, _haystack_22274, _from_22275, _12567, _12568);
    DeRef(_0);
    _12567 = NOVALUE;
    _12568 = NOVALUE;

    /** regex.e:1044		if atom(match_data) then */
    _12570 = IS_ATOM(_match_data_22282);
    if (_12570 == 0)
    {
        _12570 = NOVALUE;
        goto L2; // [53] 63
    }
    else{
        _12570 = NOVALUE;
    }

    /** regex.e:1045			return ERROR_NOMATCH */
    DeRef(_re_22272);
    DeRef(_haystack_22274);
    DeRef(_options_22276);
    DeRef(_match_data_22282);
    return -1LL;
L2: 

    /** regex.e:1048		for i = 1 to length(match_data) do*/
    if (IS_SEQUENCE(_match_data_22282)){
            _12571 = SEQ_PTR(_match_data_22282)->length;
    }
    else {
        _12571 = 1;
    }
    {
        object _i_22290;
        _i_22290 = 1LL;
L3: 
        if (_i_22290 > _12571){
            goto L4; // [68] 181
        }

        /** regex.e:1049			sequence tmp*/

        /** regex.e:1050			if match_data[i][1] = 0 then*/
        _2 = (object)SEQ_PTR(_match_data_22282);
        _12572 = (object)*(((s1_ptr)_2)->base + _i_22290);
        _2 = (object)SEQ_PTR(_12572);
        _12573 = (object)*(((s1_ptr)_2)->base + 1LL);
        _12572 = NOVALUE;
        if (binary_op_a(NOTEQ, _12573, 0LL)){
            _12573 = NOVALUE;
            goto L5; // [87] 101
        }
        _12573 = NOVALUE;

        /** regex.e:1051				tmp = ""*/
        RefDS(_5);
        DeRef(_tmp_22292);
        _tmp_22292 = _5;
        goto L6; // [98] 125
L5: 

        /** regex.e:1053				tmp = haystack[match_data[i][1]..match_data[i][2]]*/
        _2 = (object)SEQ_PTR(_match_data_22282);
        _12575 = (object)*(((s1_ptr)_2)->base + _i_22290);
        _2 = (object)SEQ_PTR(_12575);
        _12576 = (object)*(((s1_ptr)_2)->base + 1LL);
        _12575 = NOVALUE;
        _2 = (object)SEQ_PTR(_match_data_22282);
        _12577 = (object)*(((s1_ptr)_2)->base + _i_22290);
        _2 = (object)SEQ_PTR(_12577);
        _12578 = (object)*(((s1_ptr)_2)->base + 2LL);
        _12577 = NOVALUE;
        rhs_slice_target = (object_ptr)&_tmp_22292;
        RHS_Slice(_haystack_22274, _12576, _12578);
L6: 

        /** regex.e:1055			if str_offsets then*/
        if (_str_offsets_22280 == 0)
        {
            goto L7; // [127] 163
        }
        else{
        }

        /** regex.e:1056				match_data[i] = { tmp, match_data[i][1], match_data[i][2] }*/
        _2 = (object)SEQ_PTR(_match_data_22282);
        _12580 = (object)*(((s1_ptr)_2)->base + _i_22290);
        _2 = (object)SEQ_PTR(_12580);
        _12581 = (object)*(((s1_ptr)_2)->base + 1LL);
        _12580 = NOVALUE;
        _2 = (object)SEQ_PTR(_match_data_22282);
        _12582 = (object)*(((s1_ptr)_2)->base + _i_22290);
        _2 = (object)SEQ_PTR(_12582);
        _12583 = (object)*(((s1_ptr)_2)->base + 2LL);
        _12582 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_tmp_22292);
        ((intptr_t*)_2)[1] = _tmp_22292;
        Ref(_12581);
        ((intptr_t*)_2)[2] = _12581;
        Ref(_12583);
        ((intptr_t*)_2)[3] = _12583;
        _12584 = MAKE_SEQ(_1);
        _12583 = NOVALUE;
        _12581 = NOVALUE;
        _2 = (object)SEQ_PTR(_match_data_22282);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _match_data_22282 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_22290);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _12584;
        if( _1 != _12584 ){
            DeRef(_1);
        }
        _12584 = NOVALUE;
        goto L8; // [160] 172
L7: 

        /** regex.e:1058				match_data[i] = tmp*/
        RefDS(_tmp_22292);
        _2 = (object)SEQ_PTR(_match_data_22282);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _match_data_22282 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_22290);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _tmp_22292;
        DeRef(_1);
L8: 
        DeRef(_tmp_22292);
        _tmp_22292 = NOVALUE;

        /** regex.e:1060		end for*/
        _i_22290 = _i_22290 + 1LL;
        goto L3; // [176] 75
L4: 
        ;
    }

    /** regex.e:1062		return match_data*/
    DeRef(_re_22272);
    DeRef(_haystack_22274);
    DeRef(_options_22276);
    _12578 = NOVALUE;
    _12576 = NOVALUE;
    return _match_data_22282;
    ;
}



// 0xFBA16577
