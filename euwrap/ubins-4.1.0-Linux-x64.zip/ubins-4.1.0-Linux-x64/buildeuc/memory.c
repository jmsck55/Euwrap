// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _11deallocate(object _addr_389)
{
    object _0, _1, _2;
    

    /** memory.e:71		ifdef DATA_EXECUTE then*/

    /** memory.e:82	   	machine_proc( memconst:M_FREE, addr)*/
    machine(17LL, _addr_389);

    /** memory.e:83	end procedure*/
    DeRef(_addr_389);
    return;
    ;
}


object _11prepare_block(object _addr_415, object _a_416, object _protection_417)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_protection_417)) {
        _1 = (object)(DBL_PTR(_protection_417)->dbl);
        DeRefDS(_protection_417);
        _protection_417 = _1;
    }

    /** memory.e:134		return addr*/
    return _addr_415;
    ;
}



// 0xFCD8943C
