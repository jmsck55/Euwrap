// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _68GetSourceName()
{
    object _real_name_66840 = NOVALUE;
    object _fh_66841 = NOVALUE;
    object _has_extension_66843 = NOVALUE;
    object _32961 = NOVALUE;
    object _32959 = NOVALUE;
    object _32958 = NOVALUE;
    object _32955 = NOVALUE;
    object _32954 = NOVALUE;
    object _32953 = NOVALUE;
    object _32952 = NOVALUE;
    object _32951 = NOVALUE;
    object _32950 = NOVALUE;
    object _32947 = NOVALUE;
    object _32946 = NOVALUE;
    object _32944 = NOVALUE;
    object _32943 = NOVALUE;
    object _32942 = NOVALUE;
    object _32941 = NOVALUE;
    object _32940 = NOVALUE;
    object _32939 = NOVALUE;
    object _32936 = NOVALUE;
    object _32935 = NOVALUE;
    object _32932 = NOVALUE;
    object _32931 = NOVALUE;
    object _32929 = NOVALUE;
    object _32928 = NOVALUE;
    object _32925 = NOVALUE;
    object _32924 = NOVALUE;
    object _32923 = NOVALUE;
    object _32921 = NOVALUE;
    object _32920 = NOVALUE;
    object _32919 = NOVALUE;
    object _32917 = NOVALUE;
    object _32916 = NOVALUE;
    object _32915 = NOVALUE;
    object _32914 = NOVALUE;
    object _0, _1, _2;
    

    /** main.e:48		boolean has_extension = FALSE*/
    _has_extension_66843 = _13FALSE_450;

    /** main.e:50		if length(src_name) = 0 and not repl then*/
    if (IS_SEQUENCE(_49src_name_49591)){
            _32914 = SEQ_PTR(_49src_name_49591)->length;
    }
    else {
        _32914 = 1;
    }
    _32915 = (_32914 == 0LL);
    _32914 = NOVALUE;
    if (_32915 == 0) {
        goto L1; // [19] 45
    }
    _32917 = (0LL == 0);
    if (_32917 == 0)
    {
        DeRef(_32917);
        _32917 = NOVALUE;
        goto L1; // [29] 45
    }
    else{
        DeRef(_32917);
        _32917 = NOVALUE;
    }

    /** main.e:51			show_banner()*/
    _49show_banner();

    /** main.e:52			return -2 -- No source file*/
    DeRef(_real_name_66840);
    DeRef(_32915);
    _32915 = NOVALUE;
    return -2LL;
    goto L2; // [42] 143
L1: 

    /** main.e:53		elsif length(src_name) = 0 and repl then*/
    if (IS_SEQUENCE(_49src_name_49591)){
            _32919 = SEQ_PTR(_49src_name_49591)->length;
    }
    else {
        _32919 = 1;
    }
    _32920 = (_32919 == 0LL);
    _32919 = NOVALUE;
    if (_32920 == 0) {
        goto L3; // [56] 142
    }
    goto L3; // [63] 142

    /** main.e:54			known_files = append(known_files, "")*/
    RefDS(_21993);
    Append(&_37known_files_15407, _37known_files_15407, _21993);

    /** main.e:55			known_files_hash &= hash(known_files[$], stdhash:HSIEH32)*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _32923 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _32923 = 1;
    }
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _32924 = (object)*(((s1_ptr)_2)->base + _32923);
    _32925 = calc_hash(_32924, -5LL);
    _32924 = NOVALUE;
    Ref(_32925);
    Append(&_37known_files_hash_15408, _37known_files_hash_15408, _32925);
    DeRef(_32925);
    _32925 = NOVALUE;

    /** main.e:56			real_name = ""*/
    RefDS(_21993);
    DeRef(_real_name_66840);
    _real_name_66840 = _21993;

    /** main.e:57			finished_files &= 0*/
    Append(&_37finished_files_15409, _37finished_files_15409, 0LL);

    /** main.e:58			file_include_depend = append( file_include_depend, { length( known_files ) } )*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _32928 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _32928 = 1;
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _32928;
    _32929 = MAKE_SEQ(_1);
    _32928 = NOVALUE;
    RefDS(_32929);
    Append(&_37file_include_depend_15410, _37file_include_depend_15410, _32929);
    DeRefDS(_32929);
    _32929 = NOVALUE;

    /** main.e:59			return repl_file*/
    DeRefDS(_real_name_66840);
    DeRef(_32915);
    _32915 = NOVALUE;
    DeRef(_32920);
    _32920 = NOVALUE;
    return 5555LL;
L3: 
L2: 

    /** main.e:62		ifdef WINDOWS then*/

    /** main.e:66		for p = length(src_name) to 1 by -1 do*/
    if (IS_SEQUENCE(_49src_name_49591)){
            _32931 = SEQ_PTR(_49src_name_49591)->length;
    }
    else {
        _32931 = 1;
    }
    {
        object _p_66879;
        _p_66879 = _32931;
L4: 
        if (_p_66879 < 1LL){
            goto L5; // [152] 216
        }

        /** main.e:67			if src_name[p] = '.' then*/
        _2 = (object)SEQ_PTR(_49src_name_49591);
        _32932 = (object)*(((s1_ptr)_2)->base + _p_66879);
        if (binary_op_a(NOTEQ, _32932, 46LL)){
            _32932 = NOVALUE;
            goto L6; // [167] 185
        }
        _32932 = NOVALUE;

        /** main.e:68			   has_extension = TRUE*/
        _has_extension_66843 = _13TRUE_452;

        /** main.e:69			   exit*/
        goto L5; // [180] 216
        goto L7; // [182] 209
L6: 

        /** main.e:70			elsif find(src_name[p], SLASH_CHARS) then*/
        _2 = (object)SEQ_PTR(_49src_name_49591);
        _32935 = (object)*(((s1_ptr)_2)->base + _p_66879);
        _32936 = find_from(_32935, _46SLASH_CHARS_21606, 1LL);
        _32935 = NOVALUE;
        if (_32936 == 0)
        {
            _32936 = NOVALUE;
            goto L8; // [200] 208
        }
        else{
            _32936 = NOVALUE;
        }

        /** main.e:71			   exit*/
        goto L5; // [205] 216
L8: 
L7: 

        /** main.e:73		end for*/
        _p_66879 = _p_66879 + -1LL;
        goto L4; // [211] 159
L5: 
        ;
    }

    /** main.e:75		if not has_extension then*/
    if (_has_extension_66843 != 0)
    goto L9; // [218] 323

    /** main.e:79			known_files = append(known_files, "")*/
    RefDS(_21993);
    Append(&_37known_files_15407, _37known_files_15407, _21993);

    /** main.e:82			for i = 1 to length( DEFAULT_EXTS ) do*/
    _32939 = 4;
    {
        object _i_66899;
        _i_66899 = 1LL;
LA: 
        if (_i_66899 > 4LL){
            goto LB; // [238] 303
        }

        /** main.e:83				known_files[$] = src_name & DEFAULT_EXTS[i]*/
        if (IS_SEQUENCE(_37known_files_15407)){
                _32940 = SEQ_PTR(_37known_files_15407)->length;
        }
        else {
            _32940 = 1;
        }
        _2 = (object)SEQ_PTR(_46DEFAULT_EXTS_21581);
        _32941 = (object)*(((s1_ptr)_2)->base + _i_66899);
        Concat((object_ptr)&_32942, _49src_name_49591, _32941);
        _32941 = NOVALUE;
        _2 = (object)SEQ_PTR(_37known_files_15407);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37known_files_15407 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _32940);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _32942;
        if( _1 != _32942 ){
            DeRef(_1);
        }
        _32942 = NOVALUE;

        /** main.e:84				real_name = e_path_find(known_files[$])*/
        if (IS_SEQUENCE(_37known_files_15407)){
                _32943 = SEQ_PTR(_37known_files_15407)->length;
        }
        else {
            _32943 = 1;
        }
        _2 = (object)SEQ_PTR(_37known_files_15407);
        _32944 = (object)*(((s1_ptr)_2)->base + _32943);
        Ref(_32944);
        _0 = _real_name_66840;
        _real_name_66840 = _48e_path_find(_32944);
        DeRef(_0);
        _32944 = NOVALUE;

        /** main.e:85				if sequence(real_name) then*/
        _32946 = IS_SEQUENCE(_real_name_66840);
        if (_32946 == 0)
        {
            _32946 = NOVALUE;
            goto LC; // [288] 296
        }
        else{
            _32946 = NOVALUE;
        }

        /** main.e:86					exit*/
        goto LB; // [293] 303
LC: 

        /** main.e:88			end for*/
        _i_66899 = _i_66899 + 1LL;
        goto LA; // [298] 245
LB: 
        ;
    }

    /** main.e:90			if atom(real_name) then*/
    _32947 = IS_ATOM(_real_name_66840);
    if (_32947 == 0)
    {
        _32947 = NOVALUE;
        goto LD; // [310] 359
    }
    else{
        _32947 = NOVALUE;
    }

    /** main.e:91				return -1*/
    DeRef(_real_name_66840);
    DeRef(_32915);
    _32915 = NOVALUE;
    DeRef(_32920);
    _32920 = NOVALUE;
    return -1LL;
    goto LD; // [320] 359
L9: 

    /** main.e:94			known_files = append(known_files, src_name)*/
    RefDS(_49src_name_49591);
    Append(&_37known_files_15407, _37known_files_15407, _49src_name_49591);

    /** main.e:95			real_name = e_path_find(src_name)*/
    RefDS(_49src_name_49591);
    _0 = _real_name_66840;
    _real_name_66840 = _48e_path_find(_49src_name_49591);
    DeRef(_0);

    /** main.e:96			if atom(real_name) then*/
    _32950 = IS_ATOM(_real_name_66840);
    if (_32950 == 0)
    {
        _32950 = NOVALUE;
        goto LE; // [348] 358
    }
    else{
        _32950 = NOVALUE;
    }

    /** main.e:97				return -1*/
    DeRef(_real_name_66840);
    DeRef(_32915);
    _32915 = NOVALUE;
    DeRef(_32920);
    _32920 = NOVALUE;
    return -1LL;
LE: 
LD: 

    /** main.e:100		known_files[$] = canonical_path(real_name,,CORRECT)*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _32951 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _32951 = 1;
    }
    Ref(_real_name_66840);
    _32952 = _17canonical_path(_real_name_66840, 0LL, 2LL);
    _2 = (object)SEQ_PTR(_37known_files_15407);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37known_files_15407 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _32951);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32952;
    if( _1 != _32952 ){
        DeRef(_1);
    }
    _32952 = NOVALUE;

    /** main.e:101		known_files_hash &= hash(known_files[$], stdhash:HSIEH32)*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _32953 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _32953 = 1;
    }
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _32954 = (object)*(((s1_ptr)_2)->base + _32953);
    _32955 = calc_hash(_32954, -5LL);
    _32954 = NOVALUE;
    Ref(_32955);
    Append(&_37known_files_hash_15408, _37known_files_hash_15408, _32955);
    DeRef(_32955);
    _32955 = NOVALUE;

    /** main.e:102		finished_files &= 0*/
    Append(&_37finished_files_15409, _37finished_files_15409, 0LL);

    /** main.e:103		file_include_depend = append( file_include_depend, { length( known_files ) } )*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _32958 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _32958 = 1;
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _32958;
    _32959 = MAKE_SEQ(_1);
    _32958 = NOVALUE;
    RefDS(_32959);
    Append(&_37file_include_depend_15410, _37file_include_depend_15410, _32959);
    DeRefDS(_32959);
    _32959 = NOVALUE;

    /** main.e:105		if file_exists(real_name) then*/
    Ref(_real_name_66840);
    _32961 = _17file_exists(_real_name_66840);
    if (_32961 == 0) {
        DeRef(_32961);
        _32961 = NOVALUE;
        goto LF; // [438] 462
    }
    else {
        if (!IS_ATOM_INT(_32961) && DBL_PTR(_32961)->dbl == 0.0){
            DeRef(_32961);
            _32961 = NOVALUE;
            goto LF; // [438] 462
        }
        DeRef(_32961);
        _32961 = NOVALUE;
    }
    DeRef(_32961);
    _32961 = NOVALUE;

    /** main.e:106			real_name = maybe_preprocess(real_name)*/
    Ref(_real_name_66840);
    _0 = _real_name_66840;
    _real_name_66840 = _64maybe_preprocess(_real_name_66840);
    DeRef(_0);

    /** main.e:107			fh = open_locked(real_name)*/
    Ref(_real_name_66840);
    _fh_66841 = _37open_locked(_real_name_66840);
    if (!IS_ATOM_INT(_fh_66841)) {
        _1 = (object)(DBL_PTR(_fh_66841)->dbl);
        DeRefDS(_fh_66841);
        _fh_66841 = _1;
    }

    /** main.e:108			return fh*/
    DeRef(_real_name_66840);
    DeRef(_32915);
    _32915 = NOVALUE;
    DeRef(_32920);
    _32920 = NOVALUE;
    return _fh_66841;
LF: 

    /** main.e:111		return -1*/
    DeRef(_real_name_66840);
    DeRef(_32915);
    _32915 = NOVALUE;
    DeRef(_32920);
    _32920 = NOVALUE;
    return -1LL;
    ;
}


void _68main()
{
    object _argc_66968 = NOVALUE;
    object _argv_66969 = NOVALUE;
    object _33001 = NOVALUE;
    object _33000 = NOVALUE;
    object _32999 = NOVALUE;
    object _32998 = NOVALUE;
    object _32997 = NOVALUE;
    object _32996 = NOVALUE;
    object _32995 = NOVALUE;
    object _32994 = NOVALUE;
    object _32993 = NOVALUE;
    object _32992 = NOVALUE;
    object _32991 = NOVALUE;
    object _32988 = NOVALUE;
    object _32986 = NOVALUE;
    object _32984 = NOVALUE;
    object _32983 = NOVALUE;
    object _32982 = NOVALUE;
    object _32981 = NOVALUE;
    object _32980 = NOVALUE;
    object _32979 = NOVALUE;
    object _32978 = NOVALUE;
    object _32977 = NOVALUE;
    object _32973 = NOVALUE;
    object _0, _1, _2;
    

    /** main.e:131		argv = command_line()*/
    DeRef(_argv_66969);
    _argv_66969 = Command_Line();

    /** main.e:133		if BIND then*/
    if (_36BIND_21044 == 0)
    {
        goto L1; // [9] 21
    }
    else{
    }

    /** main.e:134			argv = extract_options(argv)*/
    RefDS(_argv_66969);
    _0 = _argv_66969;
    _argv_66969 = _2extract_options(_argv_66969);
    DeRefDS(_0);
L1: 

    /** main.e:137		argc = length(argv)*/
    if (IS_SEQUENCE(_argv_66969)){
            _argc_66968 = SEQ_PTR(_argv_66969)->length;
    }
    else {
        _argc_66968 = 1;
    }

    /** main.e:139		Argv = argv*/
    RefDS(_argv_66969);
    DeRef(_36Argv_21450);
    _36Argv_21450 = _argv_66969;

    /** main.e:140		Argc = argc*/
    _36Argc_21449 = _argc_66968;

    /** main.e:142		TempErrName = "ex.err"*/
    RefDS(_32972);
    DeRefi(_50TempErrName_49232);
    _50TempErrName_49232 = _32972;

    /** main.e:143		TempWarningName = STDERR*/
    DeRef(_36TempWarningName_21453);
    _36TempWarningName_21453 = 2LL;

    /** main.e:144		display_warnings = 1*/
    _50display_warnings_49233 = 1LL;

    /** main.e:146		InitGlobals()*/
    _45InitGlobals();

    /** main.e:148		if TRANSLATE or BIND or INTERPRET then*/
    if (_36TRANSLATE_21041 != 0) {
        _32973 = 1;
        goto L2; // [69] 79
    }
    _32973 = (_36BIND_21044 != 0);
L2: 
    if (_32973 != 0) {
        goto L3; // [79] 90
    }
    if (_36INTERPRET_21038 == 0)
    {
        goto L4; // [86] 96
    }
    else{
    }
L3: 

    /** main.e:149			InitBackEnd(0)*/
    _2InitBackEnd(0LL);
L4: 

    /** main.e:152		src_file = GetSourceName()*/
    _0 = _68GetSourceName();
    _36src_file_21564 = _0;
    if (!IS_ATOM_INT(_36src_file_21564)) {
        _1 = (object)(DBL_PTR(_36src_file_21564)->dbl);
        DeRefDS(_36src_file_21564);
        _36src_file_21564 = _1;
    }

    /** main.e:154		if src_file = -1 then*/
    if (_36src_file_21564 != -1LL)
    goto L5; // [107] 185

    /** main.e:156			screen_output(STDERR, GetMsgText(CANT_OPEN_1, 0, {known_files[$]}))*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _32977 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _32977 = 1;
    }
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _32978 = (object)*(((s1_ptr)_2)->base + _32977);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_32978);
    ((intptr_t*)_2)[1] = _32978;
    _32979 = MAKE_SEQ(_1);
    _32978 = NOVALUE;
    _32980 = _39GetMsgText(51LL, 0LL, _32979);
    _32979 = NOVALUE;
    _50screen_output(2LL, _32980);
    _32980 = NOVALUE;

    /** main.e:157			if not batch_job and not test_only then*/
    _32981 = (_36batch_job_21452 == 0);
    if (_32981 == 0) {
        goto L6; // [147] 177
    }
    _32983 = (_36test_only_21451 == 0);
    if (_32983 == 0)
    {
        DeRef(_32983);
        _32983 = NOVALUE;
        goto L6; // [157] 177
    }
    else{
        DeRef(_32983);
        _32983 = NOVALUE;
    }

    /** main.e:158				maybe_any_key(GetMsgText(PAUSED_PRESS_ANY_KEY,0), STDERR)*/
    RefDS(_21993);
    _32984 = _39GetMsgText(277LL, 0LL, _21993);
    _5maybe_any_key(_32984, 2LL);
    _32984 = NOVALUE;
L6: 

    /** main.e:160			Cleanup(1)*/
    _50Cleanup(1LL);
    goto L7; // [182] 230
L5: 

    /** main.e:162		elsif src_file >= 0 then*/
    if (_36src_file_21564 < 0LL)
    goto L8; // [189] 229

    /** main.e:163			main_path = known_files[$]*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _32986 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _32986 = 1;
    }
    DeRef(_36main_path_21563);
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _36main_path_21563 = (object)*(((s1_ptr)_2)->base + _32986);
    Ref(_36main_path_21563);

    /** main.e:164			if length(main_path) = 0 then*/
    if (IS_SEQUENCE(_36main_path_21563)){
            _32988 = SEQ_PTR(_36main_path_21563)->length;
    }
    else {
        _32988 = 1;
    }
    if (_32988 != 0LL)
    goto L9; // [213] 228

    /** main.e:165				main_path = '.' & SLASH*/
    Concat((object_ptr)&_36main_path_21563, 46LL, 47LL);
L9: 
L8: 
L7: 

    /** main.e:171		if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto LA; // [234] 243
    }
    else{
    }

    /** main.e:172			InitBackEnd(1)*/
    _2InitBackEnd(1LL);
LA: 

    /** main.e:175		CheckPlatform()*/
    _2CheckPlatform();

    /** main.e:177		InitSymTab()*/
    _54InitSymTab();

    /** main.e:178		InitEmit()*/
    _47InitEmit();

    /** main.e:179		InitLex()*/
    _62InitLex();

    /** main.e:180		InitParser()*/
    _45InitParser();

    /** main.e:184		eu_namespace()*/
    _62eu_namespace();

    /** main.e:186		ifdef TRANSLATOR then*/

    /** main.e:187			if keep and build_system_type = BUILD_DIRECT then*/
    if (_58keep_42570 == 0) {
        goto LB; // [273] 342
    }
    _32992 = (_56build_system_type_45385 == 3LL);
    if (_32992 == 0)
    {
        DeRef(_32992);
        _32992 = NOVALUE;
        goto LB; // [286] 342
    }
    else{
        DeRef(_32992);
        _32992 = NOVALUE;
    }

    /** main.e:188				if 0 and not quick_has_changed(known_files[$]) then*/
    if (0LL == 0) {
        goto LC; // [291] 341
    }
    if (IS_SEQUENCE(_37known_files_15407)){
            _32994 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _32994 = 1;
    }
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _32995 = (object)*(((s1_ptr)_2)->base + _32994);
    Ref(_32995);
    _32996 = _56quick_has_changed(_32995);
    _32995 = NOVALUE;
    if (IS_ATOM_INT(_32996)) {
        _32997 = (_32996 == 0);
    }
    else {
        _32997 = unary_op(NOT, _32996);
    }
    DeRef(_32996);
    _32996 = NOVALUE;
    if (_32997 == 0) {
        DeRef(_32997);
        _32997 = NOVALUE;
        goto LC; // [312] 341
    }
    else {
        if (!IS_ATOM_INT(_32997) && DBL_PTR(_32997)->dbl == 0.0){
            DeRef(_32997);
            _32997 = NOVALUE;
            goto LC; // [312] 341
        }
        DeRef(_32997);
        _32997 = NOVALUE;
    }
    DeRef(_32997);
    _32997 = NOVALUE;

    /** main.e:189					build_direct(1, known_files[$])*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _32998 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _32998 = 1;
    }
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _32999 = (object)*(((s1_ptr)_2)->base + _32998);
    Ref(_32999);
    _56build_direct(1LL, _32999);
    _32999 = NOVALUE;

    /** main.e:190					Cleanup(0)*/
    _50Cleanup(0LL);

    /** main.e:191					return*/
    DeRef(_argv_66969);
    DeRef(_32981);
    _32981 = NOVALUE;
    return;
LC: 
LB: 

    /** main.e:197		main_file()*/
    _62main_file();

    /** main.e:199		check_coverage()*/
    _51check_coverage();

    /** main.e:201		parser()*/
    _45parser();

    /** main.e:203		init_coverage()*/
    _51init_coverage();

    /** main.e:206		if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto LD; // [362] 373
    }
    else{
    }

    /** main.e:207			BackEnd(0) -- translate IL to C*/
    _2BackEnd(0LL);
    goto LE; // [370] 460
LD: 

    /** main.e:209		elsif BIND then*/
    if (_36BIND_21044 == 0)
    {
        goto LF; // [377] 387
    }
    else{
    }

    /** main.e:210			OutputIL()*/
    _2OutputIL();
    goto LE; // [384] 460
LF: 

    /** main.e:212		elsif INTERPRET and not test_only then*/
    if (_36INTERPRET_21038 == 0) {
        goto L10; // [391] 459
    }
    _33001 = (_36test_only_21451 == 0);
    if (_33001 == 0)
    {
        DeRef(_33001);
        _33001 = NOVALUE;
        goto L10; // [401] 459
    }
    else{
        DeRef(_33001);
        _33001 = NOVALUE;
    }

    /** main.e:213			ifdef not STDDEBUG then*/

    /** main.e:214				BackEnd(0) -- execute IL using Euphoria-coded back-end*/
    _2BackEnd(0LL);

    /** main.e:216			while repl do*/
L10: 
LE: 

    /** main.e:225		Cleanup(0) -- does warnings*/
    _50Cleanup(0LL);

    /** main.e:226	end procedure*/
    DeRef(_argv_66969);
    DeRef(_32981);
    _32981 = NOVALUE;
    return;
    ;
}



// 0x907FA4F5
