// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _20abs(object _a_3322)
{
    object _t_3323 = NOVALUE;
    object _1614 = NOVALUE;
    object _1613 = NOVALUE;
    object _1612 = NOVALUE;
    object _1610 = NOVALUE;
    object _1608 = NOVALUE;
    object _1607 = NOVALUE;
    object _1605 = NOVALUE;
    object _0, _1, _2;
    

    /** math.e:58		if atom(a) then*/
    _1605 = IS_ATOM(_a_3322);
    if (_1605 == 0)
    {
        _1605 = NOVALUE;
        goto L1; // [6] 35
    }
    else{
        _1605 = NOVALUE;
    }

    /** math.e:59			if a >= 0 then*/
    if (binary_op_a(LESS, _a_3322, 0LL)){
        goto L2; // [11] 24
    }

    /** math.e:60				return a*/
    DeRef(_t_3323);
    return _a_3322;
    goto L3; // [21] 34
L2: 

    /** math.e:62				return - a*/
    if (IS_ATOM_INT(_a_3322)) {
        if ((uintptr_t)_a_3322 == (uintptr_t)HIGH_BITS){
            _1607 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _1607 = - _a_3322;
        }
    }
    else {
        _1607 = unary_op(UMINUS, _a_3322);
    }
    DeRef(_a_3322);
    DeRef(_t_3323);
    return _1607;
L3: 
L1: 

    /** math.e:65		for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_3322)){
            _1608 = SEQ_PTR(_a_3322)->length;
    }
    else {
        _1608 = 1;
    }
    {
        object _i_3331;
        _i_3331 = 1LL;
L4: 
        if (_i_3331 > _1608){
            goto L5; // [40] 101
        }

        /** math.e:66			t = a[i]*/
        DeRef(_t_3323);
        _2 = (object)SEQ_PTR(_a_3322);
        _t_3323 = (object)*(((s1_ptr)_2)->base + _i_3331);
        Ref(_t_3323);

        /** math.e:67			if atom(t) then*/
        _1610 = IS_ATOM(_t_3323);
        if (_1610 == 0)
        {
            _1610 = NOVALUE;
            goto L6; // [58] 80
        }
        else{
            _1610 = NOVALUE;
        }

        /** math.e:68				if t < 0 then*/
        if (binary_op_a(GREATEREQ, _t_3323, 0LL)){
            goto L7; // [63] 94
        }

        /** math.e:69					a[i] = - t*/
        if (IS_ATOM_INT(_t_3323)) {
            if ((uintptr_t)_t_3323 == (uintptr_t)HIGH_BITS){
                _1612 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _1612 = - _t_3323;
            }
        }
        else {
            _1612 = unary_op(UMINUS, _t_3323);
        }
        _2 = (object)SEQ_PTR(_a_3322);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _a_3322 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_3331);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _1612;
        if( _1 != _1612 ){
            DeRef(_1);
        }
        _1612 = NOVALUE;
        goto L7; // [77] 94
L6: 

        /** math.e:72				a[i] = abs(t)*/
        Ref(_t_3323);
        DeRef(_1613);
        _1613 = _t_3323;
        _1614 = _20abs(_1613);
        _1613 = NOVALUE;
        _2 = (object)SEQ_PTR(_a_3322);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _a_3322 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_3331);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _1614;
        if( _1 != _1614 ){
            DeRef(_1);
        }
        _1614 = NOVALUE;
L7: 

        /** math.e:74		end for*/
        _i_3331 = _i_3331 + 1LL;
        goto L4; // [96] 47
L5: 
        ;
    }

    /** math.e:75		return a*/
    DeRef(_t_3323);
    DeRef(_1607);
    _1607 = NOVALUE;
    return _a_3322;
    ;
}


object _20max(object _a_3366)
{
    object _b_3367 = NOVALUE;
    object _c_3368 = NOVALUE;
    object _1624 = NOVALUE;
    object _1623 = NOVALUE;
    object _1622 = NOVALUE;
    object _0, _1, _2;
    

    /** math.e:199		if atom(a) then*/
    _1622 = IS_ATOM(_a_3366);
    if (_1622 == 0)
    {
        _1622 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _1622 = NOVALUE;
    }

    /** math.e:200			return a*/
    DeRef(_b_3367);
    DeRef(_c_3368);
    return _a_3366;
L1: 

    /** math.e:202		b = mathcons:MINF*/
    Ref(_22MINF_3300);
    DeRef(_b_3367);
    _b_3367 = _22MINF_3300;

    /** math.e:203		for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_3366)){
            _1623 = SEQ_PTR(_a_3366)->length;
    }
    else {
        _1623 = 1;
    }
    {
        object _i_3372;
        _i_3372 = 1LL;
L2: 
        if (_i_3372 > _1623){
            goto L3; // [28] 64
        }

        /** math.e:204			c = max(a[i])*/
        _2 = (object)SEQ_PTR(_a_3366);
        _1624 = (object)*(((s1_ptr)_2)->base + _i_3372);
        Ref(_1624);
        _0 = _c_3368;
        _c_3368 = _20max(_1624);
        DeRef(_0);
        _1624 = NOVALUE;

        /** math.e:205			if c > b then*/
        if (binary_op_a(LESSEQ, _c_3368, _b_3367)){
            goto L4; // [47] 57
        }

        /** math.e:206				b = c*/
        Ref(_c_3368);
        DeRef(_b_3367);
        _b_3367 = _c_3368;
L4: 

        /** math.e:208		end for*/
        _i_3372 = _i_3372 + 1LL;
        goto L2; // [59] 35
L3: 
        ;
    }

    /** math.e:209		return b*/
    DeRef(_a_3366);
    DeRef(_c_3368);
    return _b_3367;
    ;
}


object _20min(object _a_3380)
{
    object _b_3381 = NOVALUE;
    object _c_3382 = NOVALUE;
    object _1629 = NOVALUE;
    object _1628 = NOVALUE;
    object _1627 = NOVALUE;
    object _0, _1, _2;
    

    /** math.e:232		if atom(a) then*/
    _1627 = IS_ATOM(_a_3380);
    if (_1627 == 0)
    {
        _1627 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _1627 = NOVALUE;
    }

    /** math.e:233				return a*/
    DeRef(_b_3381);
    DeRef(_c_3382);
    return _a_3380;
L1: 

    /** math.e:235		b = mathcons:PINF*/
    Ref(_22PINF_3298);
    DeRef(_b_3381);
    _b_3381 = _22PINF_3298;

    /** math.e:236		for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_3380)){
            _1628 = SEQ_PTR(_a_3380)->length;
    }
    else {
        _1628 = 1;
    }
    {
        object _i_3386;
        _i_3386 = 1LL;
L2: 
        if (_i_3386 > _1628){
            goto L3; // [28] 64
        }

        /** math.e:237			c = min(a[i])*/
        _2 = (object)SEQ_PTR(_a_3380);
        _1629 = (object)*(((s1_ptr)_2)->base + _i_3386);
        Ref(_1629);
        _0 = _c_3382;
        _c_3382 = _20min(_1629);
        DeRef(_0);
        _1629 = NOVALUE;

        /** math.e:238				if c < b then*/
        if (binary_op_a(GREATEREQ, _c_3382, _b_3381)){
            goto L4; // [47] 57
        }

        /** math.e:239					b = c*/
        Ref(_c_3382);
        DeRef(_b_3381);
        _b_3381 = _c_3382;
L4: 

        /** math.e:241		end for*/
        _i_3386 = _i_3386 + 1LL;
        goto L2; // [59] 35
L3: 
        ;
    }

    /** math.e:242		return b*/
    DeRef(_a_3380);
    DeRef(_c_3382);
    return _b_3381;
    ;
}


object _20or_all(object _a_3759)
{
    object _b_3760 = NOVALUE;
    object _1828 = NOVALUE;
    object _1827 = NOVALUE;
    object _1825 = NOVALUE;
    object _1824 = NOVALUE;
    object _1823 = NOVALUE;
    object _1822 = NOVALUE;
    object _1821 = NOVALUE;
    object _0, _1, _2;
    

    /** math.e:1469		if atom(a) then*/
    _1821 = IS_ATOM(_a_3759);
    if (_1821 == 0)
    {
        _1821 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _1821 = NOVALUE;
    }

    /** math.e:1470			return a*/
    DeRef(_b_3760);
    return _a_3759;
L1: 

    /** math.e:1472		b = 0*/
    DeRef(_b_3760);
    _b_3760 = 0LL;

    /** math.e:1473		for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_3759)){
            _1822 = SEQ_PTR(_a_3759)->length;
    }
    else {
        _1822 = 1;
    }
    {
        object _i_3764;
        _i_3764 = 1LL;
L2: 
        if (_i_3764 > _1822){
            goto L3; // [26] 80
        }

        /** math.e:1474			if atom(a[i]) then*/
        _2 = (object)SEQ_PTR(_a_3759);
        _1823 = (object)*(((s1_ptr)_2)->base + _i_3764);
        _1824 = IS_ATOM(_1823);
        _1823 = NOVALUE;
        if (_1824 == 0)
        {
            _1824 = NOVALUE;
            goto L4; // [42] 58
        }
        else{
            _1824 = NOVALUE;
        }

        /** math.e:1475				b = or_bits(b, a[i])*/
        _2 = (object)SEQ_PTR(_a_3759);
        _1825 = (object)*(((s1_ptr)_2)->base + _i_3764);
        _0 = _b_3760;
        if (IS_ATOM_INT(_b_3760) && IS_ATOM_INT(_1825)) {
            {uintptr_t tu;
                 tu = (uintptr_t)_b_3760 | (uintptr_t)_1825;
                 _b_3760 = MAKE_UINT(tu);
            }
        }
        else {
            _b_3760 = binary_op(OR_BITS, _b_3760, _1825);
        }
        DeRef(_0);
        _1825 = NOVALUE;
        goto L5; // [55] 73
L4: 

        /** math.e:1477				b = or_bits(b, or_all(a[i]))*/
        _2 = (object)SEQ_PTR(_a_3759);
        _1827 = (object)*(((s1_ptr)_2)->base + _i_3764);
        Ref(_1827);
        _1828 = _20or_all(_1827);
        _1827 = NOVALUE;
        _0 = _b_3760;
        if (IS_ATOM_INT(_b_3760) && IS_ATOM_INT(_1828)) {
            {uintptr_t tu;
                 tu = (uintptr_t)_b_3760 | (uintptr_t)_1828;
                 _b_3760 = MAKE_UINT(tu);
            }
        }
        else {
            _b_3760 = binary_op(OR_BITS, _b_3760, _1828);
        }
        DeRef(_0);
        DeRef(_1828);
        _1828 = NOVALUE;
L5: 

        /** math.e:1479		end for*/
        _i_3764 = _i_3764 + 1LL;
        goto L2; // [75] 33
L3: 
        ;
    }

    /** math.e:1480		return b*/
    DeRef(_a_3759);
    return _b_3760;
    ;
}



// 0x8CF04383
