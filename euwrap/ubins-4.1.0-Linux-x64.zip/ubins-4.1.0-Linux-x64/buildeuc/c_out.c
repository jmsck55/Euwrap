// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _55c_putc(object _c_46633)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_c_46633)) {
        _1 = (object)(DBL_PTR(_c_46633)->dbl);
        DeRefDS(_c_46633);
        _c_46633 = _1;
    }

    /** c_out.e:62		if emit_c_output then*/
    if (_55emit_c_output_46620 == 0)
    {
        goto L1; // [7] 23
    }
    else{
    }

    /** c_out.e:63			puts(c_code, c)*/
    EPuts(_55c_code_46623, _c_46633); // DJP 

    /** c_out.e:64			update_checksum( c )*/
    _56update_checksum(_c_46633);
L1: 

    /** c_out.e:66	end procedure*/
    return;
    ;
}


void _55c_hputs(object _c_source_46638)
{
    object _0, _1, _2;
    

    /** c_out.e:71		if emit_c_output then*/
    if (_55emit_c_output_46620 == 0)
    {
        goto L1; // [7] 18
    }
    else{
    }

    /** c_out.e:72			puts(c_h, c_source)    */
    EPuts(_55c_h_46624, _c_source_46638); // DJP 
L1: 

    /** c_out.e:74	end procedure*/
    DeRefDS(_c_source_46638);
    return;
    ;
}


void _55c_puts(object _c_source_46642)
{
    object _0, _1, _2;
    

    /** c_out.e:79		if emit_c_output then*/
    if (_55emit_c_output_46620 == 0)
    {
        goto L1; // [7] 23
    }
    else{
    }

    /** c_out.e:80			puts(c_code, c_source)*/
    EPuts(_55c_code_46623, _c_source_46642); // DJP 

    /** c_out.e:81			update_checksum( c_source )*/
    RefDS(_c_source_46642);
    _56update_checksum(_c_source_46642);
L1: 

    /** c_out.e:83	end procedure*/
    DeRefDS(_c_source_46642);
    return;
    ;
}


void _55c_hprintf(object _format_46647, object _value_46648)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_value_46648)) {
        _1 = (object)(DBL_PTR(_value_46648)->dbl);
        DeRefDS(_value_46648);
        _value_46648 = _1;
    }

    /** c_out.e:88		if emit_c_output then*/
    if (_55emit_c_output_46620 == 0)
    {
        goto L1; // [9] 21
    }
    else{
    }

    /** c_out.e:89			printf(c_h, format, value)*/
    EPrintf(_55c_h_46624, _format_46647, _value_46648);
L1: 

    /** c_out.e:91	end procedure*/
    DeRefDSi(_format_46647);
    return;
    ;
}


void _55c_printf(object _format_46652, object _value_46653)
{
    object _text_46655 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:96		if emit_c_output then*/
    if (_55emit_c_output_46620 == 0)
    {
        goto L1; // [7] 29
    }
    else{
    }

    /** c_out.e:97			sequence text = sprintf( format, value )*/
    DeRefi(_text_46655);
    _text_46655 = EPrintf(-9999999, _format_46652, _value_46653);

    /** c_out.e:98			puts(c_code, text)*/
    EPuts(_55c_code_46623, _text_46655); // DJP 

    /** c_out.e:99			update_checksum( text )*/
    RefDS(_text_46655);
    _56update_checksum(_text_46655);
L1: 
    DeRefi(_text_46655);
    _text_46655 = NOVALUE;

    /** c_out.e:101	end procedure*/
    DeRefDSi(_format_46652);
    DeRef(_value_46653);
    return;
    ;
}


void _55c_printf8(object _value_46666)
{
    object _buff_46667 = NOVALUE;
    object _neg_46668 = NOVALUE;
    object _p_46669 = NOVALUE;
    object _24234 = NOVALUE;
    object _24233 = NOVALUE;
    object _24231 = NOVALUE;
    object _24230 = NOVALUE;
    object _24228 = NOVALUE;
    object _24227 = NOVALUE;
    object _24225 = NOVALUE;
    object _24224 = NOVALUE;
    object _24222 = NOVALUE;
    object _24220 = NOVALUE;
    object _24218 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:115		if emit_c_output then*/
    if (_55emit_c_output_46620 == 0)
    {
        goto L1; // [5] 182
    }
    else{
    }

    /** c_out.e:116			neg = 0*/
    _neg_46668 = 0LL;

    /** c_out.e:117			buff = sprintf("%.20eL", value)*/
    DeRef(_buff_46667);
    _buff_46667 = EPrintf(-9999999, _24216, _value_46666);

    /** c_out.e:118			if length(buff) < 10 then*/
    if (IS_SEQUENCE(_buff_46667)){
            _24218 = SEQ_PTR(_buff_46667)->length;
    }
    else {
        _24218 = 1;
    }
    if (_24218 >= 10LL)
    goto L2; // [24] 174

    /** c_out.e:120				p = 1*/
    _p_46669 = 1LL;

    /** c_out.e:121				while p <= length(buff) do*/
L3: 
    if (IS_SEQUENCE(_buff_46667)){
            _24220 = SEQ_PTR(_buff_46667)->length;
    }
    else {
        _24220 = 1;
    }
    if (_p_46669 > _24220)
    goto L4; // [41] 173

    /** c_out.e:122					if buff[p] = '-' then*/
    _2 = (object)SEQ_PTR(_buff_46667);
    _24222 = (object)*(((s1_ptr)_2)->base + _p_46669);
    if (binary_op_a(NOTEQ, _24222, 45LL)){
        _24222 = NOVALUE;
        goto L5; // [51] 63
    }
    _24222 = NOVALUE;

    /** c_out.e:123						neg = 1*/
    _neg_46668 = 1LL;
    goto L6; // [60] 162
L5: 

    /** c_out.e:125					elsif buff[p] = 'i' or buff[p] = 'I' then*/
    _2 = (object)SEQ_PTR(_buff_46667);
    _24224 = (object)*(((s1_ptr)_2)->base + _p_46669);
    if (IS_ATOM_INT(_24224)) {
        _24225 = (_24224 == 105LL);
    }
    else {
        _24225 = binary_op(EQUALS, _24224, 105LL);
    }
    _24224 = NOVALUE;
    if (IS_ATOM_INT(_24225)) {
        if (_24225 != 0) {
            goto L7; // [73] 90
        }
    }
    else {
        if (DBL_PTR(_24225)->dbl != 0.0) {
            goto L7; // [73] 90
        }
    }
    _2 = (object)SEQ_PTR(_buff_46667);
    _24227 = (object)*(((s1_ptr)_2)->base + _p_46669);
    if (IS_ATOM_INT(_24227)) {
        _24228 = (_24227 == 73LL);
    }
    else {
        _24228 = binary_op(EQUALS, _24227, 73LL);
    }
    _24227 = NOVALUE;
    if (_24228 == 0) {
        DeRef(_24228);
        _24228 = NOVALUE;
        goto L8; // [86] 114
    }
    else {
        if (!IS_ATOM_INT(_24228) && DBL_PTR(_24228)->dbl == 0.0){
            DeRef(_24228);
            _24228 = NOVALUE;
            goto L8; // [86] 114
        }
        DeRef(_24228);
        _24228 = NOVALUE;
    }
    DeRef(_24228);
    _24228 = NOVALUE;
L7: 

    /** c_out.e:127						buff = CREATE_INF*/
    RefDS(_55CREATE_INF_46658);
    DeRef(_buff_46667);
    _buff_46667 = _55CREATE_INF_46658;

    /** c_out.e:128						if neg then*/
    if (_neg_46668 == 0)
    {
        goto L4; // [97] 173
    }
    else{
    }

    /** c_out.e:129							buff = prepend(buff, '-')*/
    Prepend(&_buff_46667, _buff_46667, 45LL);

    /** c_out.e:131						exit*/
    goto L4; // [109] 173
    goto L6; // [111] 162
L8: 

    /** c_out.e:133					elsif buff[p] = 'n' or buff[p] = 'N' then*/
    _2 = (object)SEQ_PTR(_buff_46667);
    _24230 = (object)*(((s1_ptr)_2)->base + _p_46669);
    if (IS_ATOM_INT(_24230)) {
        _24231 = (_24230 == 110LL);
    }
    else {
        _24231 = binary_op(EQUALS, _24230, 110LL);
    }
    _24230 = NOVALUE;
    if (IS_ATOM_INT(_24231)) {
        if (_24231 != 0) {
            goto L9; // [124] 141
        }
    }
    else {
        if (DBL_PTR(_24231)->dbl != 0.0) {
            goto L9; // [124] 141
        }
    }
    _2 = (object)SEQ_PTR(_buff_46667);
    _24233 = (object)*(((s1_ptr)_2)->base + _p_46669);
    if (IS_ATOM_INT(_24233)) {
        _24234 = (_24233 == 78LL);
    }
    else {
        _24234 = binary_op(EQUALS, _24233, 78LL);
    }
    _24233 = NOVALUE;
    if (_24234 == 0) {
        DeRef(_24234);
        _24234 = NOVALUE;
        goto LA; // [137] 161
    }
    else {
        if (!IS_ATOM_INT(_24234) && DBL_PTR(_24234)->dbl == 0.0){
            DeRef(_24234);
            _24234 = NOVALUE;
            goto LA; // [137] 161
        }
        DeRef(_24234);
        _24234 = NOVALUE;
    }
    DeRef(_24234);
    _24234 = NOVALUE;
L9: 

    /** c_out.e:135						ifdef UNIX then*/

    /** c_out.e:136							buff = CREATE_NAN1*/
    RefDS(_55CREATE_NAN1_46660);
    DeRef(_buff_46667);
    _buff_46667 = _55CREATE_NAN1_46660;

    /** c_out.e:137							if neg then*/
    if (_neg_46668 == 0)
    {
        goto LB; // [150] 160
    }
    else{
    }

    /** c_out.e:138								buff = prepend(buff, '-')*/
    Prepend(&_buff_46667, _buff_46667, 45LL);
LB: 
LA: 
L6: 

    /** c_out.e:156					p += 1*/
    _p_46669 = _p_46669 + 1;

    /** c_out.e:157				end while*/
    goto L3; // [170] 38
L4: 
L2: 

    /** c_out.e:159			puts(c_code, buff)*/
    EPuts(_55c_code_46623, _buff_46667); // DJP 
L1: 

    /** c_out.e:161	end procedure*/
    DeRef(_value_46666);
    DeRef(_buff_46667);
    DeRef(_24231);
    _24231 = NOVALUE;
    DeRef(_24225);
    _24225 = NOVALUE;
    return;
    ;
}


void _55adjust_indent_before(object _stmt_46705)
{
    object _i_46706 = NOVALUE;
    object _lb_46708 = NOVALUE;
    object _rb_46709 = NOVALUE;
    object _24249 = NOVALUE;
    object _24247 = NOVALUE;
    object _24245 = NOVALUE;
    object _24239 = NOVALUE;
    object _24238 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:177		lb = FALSE*/
    _lb_46708 = _13FALSE_450;

    /** c_out.e:178		rb = FALSE*/
    _rb_46709 = _13FALSE_450;

    /** c_out.e:180		for p = 1 to length(stmt) do*/
    if (IS_SEQUENCE(_stmt_46705)){
            _24238 = SEQ_PTR(_stmt_46705)->length;
    }
    else {
        _24238 = 1;
    }
    {
        object _p_46713;
        _p_46713 = 1LL;
L1: 
        if (_p_46713 > _24238){
            goto L2; // [22] 102
        }

        /** c_out.e:181			switch stmt[p] do*/
        _2 = (object)SEQ_PTR(_stmt_46705);
        _24239 = (object)*(((s1_ptr)_2)->base + _p_46713);
        if (IS_SEQUENCE(_24239) ){
            goto L3; // [35] 95
        }
        if(!IS_ATOM_INT(_24239)){
            if( (DBL_PTR(_24239)->dbl != (eudouble) ((object) DBL_PTR(_24239)->dbl) ) ){
                goto L3; // [35] 95
            }
            _0 = (object) DBL_PTR(_24239)->dbl;
        }
        else {
            _0 = _24239;
        };
        _24239 = NOVALUE;
        switch ( _0 ){ 

            /** c_out.e:182				case '\n' then*/
            case 10:

            /** c_out.e:183					exit*/
            goto L2; // [46] 102
            goto L3; // [48] 95

            /** c_out.e:185				case  '}' then*/
            case 125:

            /** c_out.e:186					rb = TRUE*/
            _rb_46709 = _13TRUE_452;

            /** c_out.e:187					if lb then*/
            if (_lb_46708 == 0)
            {
                goto L3; // [63] 95
            }
            else{
            }

            /** c_out.e:188						exit*/
            goto L2; // [68] 102
            goto L3; // [71] 95

            /** c_out.e:191				case '{' then*/
            case 123:

            /** c_out.e:192					lb = TRUE*/
            _lb_46708 = _13TRUE_452;

            /** c_out.e:193					if rb then */
            if (_rb_46709 == 0)
            {
                goto L4; // [86] 94
            }
            else{
            }

            /** c_out.e:194						exit*/
            goto L2; // [91] 102
L4: 
        ;}L3: 

        /** c_out.e:198		end for*/
        _p_46713 = _p_46713 + 1LL;
        goto L1; // [97] 29
L2: 
        ;
    }

    /** c_out.e:200		if rb then*/
    if (_rb_46709 == 0)
    {
        goto L5; // [104] 122
    }
    else{
    }

    /** c_out.e:201			if not lb then*/
    if (_lb_46708 != 0)
    goto L6; // [109] 121

    /** c_out.e:202				indent -= 4*/
    _55indent_46699 = _55indent_46699 - 4LL;
L6: 
L5: 

    /** c_out.e:206		i = indent + temp_indent*/
    _i_46706 = _55indent_46699 + _55temp_indent_46700;

    /** c_out.e:207		while i >= length(big_blanks) do*/
L7: 
    if (IS_SEQUENCE(_55big_blanks_46701)){
            _24245 = SEQ_PTR(_55big_blanks_46701)->length;
    }
    else {
        _24245 = 1;
    }
    if (_i_46706 < _24245)
    goto L8; // [140] 163

    /** c_out.e:208			c_puts(big_blanks)*/
    RefDS(_55big_blanks_46701);
    _55c_puts(_55big_blanks_46701);

    /** c_out.e:209			i -= length(big_blanks)*/
    if (IS_SEQUENCE(_55big_blanks_46701)){
            _24247 = SEQ_PTR(_55big_blanks_46701)->length;
    }
    else {
        _24247 = 1;
    }
    _i_46706 = _i_46706 - _24247;
    _24247 = NOVALUE;

    /** c_out.e:210		end while*/
    goto L7; // [160] 137
L8: 

    /** c_out.e:212		c_puts(big_blanks[1..i])*/
    rhs_slice_target = (object_ptr)&_24249;
    RHS_Slice(_55big_blanks_46701, 1LL, _i_46706);
    _55c_puts(_24249);
    _24249 = NOVALUE;

    /** c_out.e:214		temp_indent = 0    */
    _55temp_indent_46700 = 0LL;

    /** c_out.e:215	end procedure*/
    DeRefDS(_stmt_46705);
    return;
    ;
}


void _55adjust_indent_after(object _stmt_46738)
{
    object _24270 = NOVALUE;
    object _24269 = NOVALUE;
    object _24267 = NOVALUE;
    object _24265 = NOVALUE;
    object _24264 = NOVALUE;
    object _24261 = NOVALUE;
    object _24259 = NOVALUE;
    object _24258 = NOVALUE;
    object _24255 = NOVALUE;
    object _24251 = NOVALUE;
    object _24250 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:221		for p = 1 to length(stmt) do*/
    if (IS_SEQUENCE(_stmt_46738)){
            _24250 = SEQ_PTR(_stmt_46738)->length;
    }
    else {
        _24250 = 1;
    }
    {
        object _p_46740;
        _p_46740 = 1LL;
L1: 
        if (_p_46740 > _24250){
            goto L2; // [8] 61
        }

        /** c_out.e:222			switch stmt[p] do*/
        _2 = (object)SEQ_PTR(_stmt_46738);
        _24251 = (object)*(((s1_ptr)_2)->base + _p_46740);
        if (IS_SEQUENCE(_24251) ){
            goto L3; // [21] 54
        }
        if(!IS_ATOM_INT(_24251)){
            if( (DBL_PTR(_24251)->dbl != (eudouble) ((object) DBL_PTR(_24251)->dbl) ) ){
                goto L3; // [21] 54
            }
            _0 = (object) DBL_PTR(_24251)->dbl;
        }
        else {
            _0 = _24251;
        };
        _24251 = NOVALUE;
        switch ( _0 ){ 

            /** c_out.e:223				case '\n' then*/
            case 10:

            /** c_out.e:224					exit*/
            goto L2; // [32] 61
            goto L3; // [34] 54

            /** c_out.e:226				case '{' then*/
            case 123:

            /** c_out.e:227					indent += 4*/
            _55indent_46699 = _55indent_46699 + 4LL;

            /** c_out.e:228					return*/
            DeRefDS(_stmt_46738);
            return;
        ;}L3: 

        /** c_out.e:230		end for*/
        _p_46740 = _p_46740 + 1LL;
        goto L1; // [56] 15
L2: 
        ;
    }

    /** c_out.e:232		if length(stmt) < 3 then*/
    if (IS_SEQUENCE(_stmt_46738)){
            _24255 = SEQ_PTR(_stmt_46738)->length;
    }
    else {
        _24255 = 1;
    }
    if (_24255 >= 3LL)
    goto L4; // [66] 76

    /** c_out.e:233			return*/
    DeRefDS(_stmt_46738);
    return;
L4: 

    /** c_out.e:236		if not equal("if ", stmt[1..3]) then*/
    rhs_slice_target = (object_ptr)&_24258;
    RHS_Slice(_stmt_46738, 1LL, 3LL);
    if (_24257 == _24258)
    _24259 = 1;
    else if (IS_ATOM_INT(_24257) && IS_ATOM_INT(_24258))
    _24259 = 0;
    else
    _24259 = (compare(_24257, _24258) == 0);
    DeRefDS(_24258);
    _24258 = NOVALUE;
    if (_24259 != 0)
    goto L5; // [87] 96
    _24259 = NOVALUE;

    /** c_out.e:237			return*/
    DeRefDS(_stmt_46738);
    return;
L5: 

    /** c_out.e:240		if length(stmt) < 5 then*/
    if (IS_SEQUENCE(_stmt_46738)){
            _24261 = SEQ_PTR(_stmt_46738)->length;
    }
    else {
        _24261 = 1;
    }
    if (_24261 >= 5LL)
    goto L6; // [101] 111

    /** c_out.e:241			return*/
    DeRefDS(_stmt_46738);
    return;
L6: 

    /** c_out.e:244		if not equal("else", stmt[1..4]) then*/
    rhs_slice_target = (object_ptr)&_24264;
    RHS_Slice(_stmt_46738, 1LL, 4LL);
    if (_24263 == _24264)
    _24265 = 1;
    else if (IS_ATOM_INT(_24263) && IS_ATOM_INT(_24264))
    _24265 = 0;
    else
    _24265 = (compare(_24263, _24264) == 0);
    DeRefDS(_24264);
    _24264 = NOVALUE;
    if (_24265 != 0)
    goto L7; // [122] 131
    _24265 = NOVALUE;

    /** c_out.e:245			return*/
    DeRefDS(_stmt_46738);
    return;
L7: 

    /** c_out.e:248		if not find(stmt[5], {" \n"}) then*/
    _2 = (object)SEQ_PTR(_stmt_46738);
    _24267 = (object)*(((s1_ptr)_2)->base + 5LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_24268);
    ((intptr_t*)_2)[1] = _24268;
    _24269 = MAKE_SEQ(_1);
    _24270 = find_from(_24267, _24269, 1LL);
    _24267 = NOVALUE;
    DeRefDS(_24269);
    _24269 = NOVALUE;
    if (_24270 != 0)
    goto L8; // [146] 155
    _24270 = NOVALUE;

    /** c_out.e:249			return*/
    DeRefDS(_stmt_46738);
    return;
L8: 

    /** c_out.e:252		temp_indent = 4*/
    _55temp_indent_46700 = 4LL;

    /** c_out.e:254	end procedure*/
    DeRefDS(_stmt_46738);
    return;
    ;
}



// 0x0FF48C64
