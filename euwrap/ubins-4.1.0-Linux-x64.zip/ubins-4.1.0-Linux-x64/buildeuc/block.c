// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _65block_type_name(object _opcode_25118)
{
    object _14037 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_opcode_25118)) {
        _1 = (object)(DBL_PTR(_opcode_25118)->dbl);
        DeRefDS(_opcode_25118);
        _opcode_25118 = _1;
    }

    /** block.e:51		switch opcode do*/
    _0 = _opcode_25118;
    switch ( _0 ){ 

        /** block.e:52			case LOOP then*/
        case 422:

        /** block.e:53				return "LOOP"*/
        RefDS(_14035);
        return _14035;
        goto L1; // [20] 63

        /** block.e:54			case PROC then*/
        case 27:

        /** block.e:55				return "PROC"*/
        RefDS(_12942);
        return _12942;
        goto L1; // [32] 63

        /** block.e:56			case FUNC then*/
        case 501:

        /** block.e:57				return "FUNC"*/
        RefDS(_14036);
        return _14036;
        goto L1; // [44] 63

        /** block.e:58			case else*/
        default:

        /** block.e:59				return opnames[opcode]*/
        _2 = (object)SEQ_PTR(_61opnames_22885);
        _14037 = (object)*(((s1_ptr)_2)->base + _opcode_25118);
        RefDS(_14037);
        return _14037;
    ;}L1: 
    ;
}


void _65check_block(object _got_25134)
{
    object _expected_25135 = NOVALUE;
    object _14045 = NOVALUE;
    object _14044 = NOVALUE;
    object _14043 = NOVALUE;
    object _14039 = NOVALUE;
    object _14038 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:64		integer expected = block_stack[$][BLOCK_OPCODE]*/
    if (IS_SEQUENCE(_65block_stack_25107)){
            _14038 = SEQ_PTR(_65block_stack_25107)->length;
    }
    else {
        _14038 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25107);
    _14039 = (object)*(((s1_ptr)_2)->base + _14038);
    _2 = (object)SEQ_PTR(_14039);
    _expected_25135 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_expected_25135)){
        _expected_25135 = (object)DBL_PTR(_expected_25135)->dbl;
    }
    _14039 = NOVALUE;

    /** block.e:65		if got = FUNC then*/
    if (_got_25134 != 501LL)
    goto L1; // [24] 38

    /** block.e:66			got = PROC*/
    _got_25134 = 27LL;
L1: 

    /** block.e:68		if got != expected then*/
    if (_got_25134 == _expected_25135)
    goto L2; // [40] 66

    /** block.e:69			CompileErr( EXPECTED_END_OF_1_BLOCK_NOT_2, {block_type_name( expected ), block_type_name( got)} )*/
    _14043 = _65block_type_name(_expected_25135);
    _14044 = _65block_type_name(_got_25134);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _14043;
    ((intptr_t *)_2)[2] = _14044;
    _14045 = MAKE_SEQ(_1);
    _14044 = NOVALUE;
    _14043 = NOVALUE;
    _50CompileErr(79LL, _14045, 0LL);
    _14045 = NOVALUE;
L2: 

    /** block.e:71	end procedure*/
    return;
    ;
}


void _65Block_var(object _sym_25153)
{
    object _block_25154 = NOVALUE;
    object _14066 = NOVALUE;
    object _14065 = NOVALUE;
    object _14064 = NOVALUE;
    object _14062 = NOVALUE;
    object _14061 = NOVALUE;
    object _14059 = NOVALUE;
    object _14058 = NOVALUE;
    object _14057 = NOVALUE;
    object _14056 = NOVALUE;
    object _14055 = NOVALUE;
    object _14054 = NOVALUE;
    object _14053 = NOVALUE;
    object _14051 = NOVALUE;
    object _14049 = NOVALUE;
    object _14048 = NOVALUE;
    object _14046 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_25153)) {
        _1 = (object)(DBL_PTR(_sym_25153)->dbl);
        DeRefDS(_sym_25153);
        _sym_25153 = _1;
    }

    /** block.e:75		sequence block = block_stack[$]*/
    if (IS_SEQUENCE(_65block_stack_25107)){
            _14046 = SEQ_PTR(_65block_stack_25107)->length;
    }
    else {
        _14046 = 1;
    }
    DeRef(_block_25154);
    _2 = (object)SEQ_PTR(_65block_stack_25107);
    _block_25154 = (object)*(((s1_ptr)_2)->base + _14046);
    Ref(_block_25154);

    /** block.e:76		block_stack[$] = 0*/
    if (IS_SEQUENCE(_65block_stack_25107)){
            _14048 = SEQ_PTR(_65block_stack_25107)->length;
    }
    else {
        _14048 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25107);
    _2 = (object)(((s1_ptr)_2)->base + _14048);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** block.e:77		if length(block_stack) > 1 then*/
    if (IS_SEQUENCE(_65block_stack_25107)){
            _14049 = SEQ_PTR(_65block_stack_25107)->length;
    }
    else {
        _14049 = 1;
    }
    if (_14049 <= 1LL)
    goto L1; // [34] 58

    /** block.e:79			SymTab[sym][S_BLOCK] = block[BLOCK_SYM]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_25153 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_block_25154);
    _14053 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_14053);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_BLOCK_21096))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_BLOCK_21096)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_BLOCK_21096);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14053;
    if( _1 != _14053 ){
        DeRef(_1);
    }
    _14053 = NOVALUE;
    _14051 = NOVALUE;
L1: 

    /** block.e:82		if length(block[BLOCK_VARS]) then*/
    _2 = (object)SEQ_PTR(_block_25154);
    _14054 = (object)*(((s1_ptr)_2)->base + 6LL);
    if (IS_SEQUENCE(_14054)){
            _14055 = SEQ_PTR(_14054)->length;
    }
    else {
        _14055 = 1;
    }
    _14054 = NOVALUE;
    if (_14055 == 0)
    {
        _14055 = NOVALUE;
        goto L2; // [67] 99
    }
    else{
        _14055 = NOVALUE;
    }

    /** block.e:83			SymTab[block[BLOCK_VARS][$]][S_NEXT_IN_BLOCK] = sym*/
    _2 = (object)SEQ_PTR(_block_25154);
    _14056 = (object)*(((s1_ptr)_2)->base + 6LL);
    if (IS_SEQUENCE(_14056)){
            _14057 = SEQ_PTR(_14056)->length;
    }
    else {
        _14057 = 1;
    }
    _2 = (object)SEQ_PTR(_14056);
    _14058 = (object)*(((s1_ptr)_2)->base + _14057);
    _14056 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_14058))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14058)->dbl));
    else
    _3 = (object)(_14058 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NEXT_IN_BLOCK_21068))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NEXT_IN_BLOCK_21068)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NEXT_IN_BLOCK_21068);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_25153;
    DeRef(_1);
    _14059 = NOVALUE;
    goto L3; // [96] 119
L2: 

    /** block.e:85			SymTab[block[BLOCK_SYM]][S_NEXT_IN_BLOCK] = sym*/
    _2 = (object)SEQ_PTR(_block_25154);
    _14061 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_14061))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14061)->dbl));
    else
    _3 = (object)(_14061 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NEXT_IN_BLOCK_21068))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NEXT_IN_BLOCK_21068)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NEXT_IN_BLOCK_21068);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_25153;
    DeRef(_1);
    _14062 = NOVALUE;
L3: 

    /** block.e:88		block[BLOCK_VARS] &= sym*/
    _2 = (object)SEQ_PTR(_block_25154);
    _14064 = (object)*(((s1_ptr)_2)->base + 6LL);
    if (IS_SEQUENCE(_14064) && IS_ATOM(_sym_25153)) {
        Append(&_14065, _14064, _sym_25153);
    }
    else if (IS_ATOM(_14064) && IS_SEQUENCE(_sym_25153)) {
    }
    else {
        Concat((object_ptr)&_14065, _14064, _sym_25153);
        _14064 = NOVALUE;
    }
    _14064 = NOVALUE;
    _2 = (object)SEQ_PTR(_block_25154);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25154 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14065;
    if( _1 != _14065 ){
        DeRef(_1);
    }
    _14065 = NOVALUE;

    /** block.e:90		block_stack[$] = block*/
    if (IS_SEQUENCE(_65block_stack_25107)){
            _14066 = SEQ_PTR(_65block_stack_25107)->length;
    }
    else {
        _14066 = 1;
    }
    RefDS(_block_25154);
    _2 = (object)SEQ_PTR(_65block_stack_25107);
    _2 = (object)(((s1_ptr)_2)->base + _14066);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _block_25154;
    DeRef(_1);

    /** block.e:91		ifdef BDEBUG then*/

    /** block.e:96	end procedure*/
    DeRefDS(_block_25154);
    _14058 = NOVALUE;
    _14061 = NOVALUE;
    _14054 = NOVALUE;
    return;
    ;
}


void _65NewBlock(object _opcode_25188, object _block_label_25189)
{
    object _block_25207 = NOVALUE;
    object _14080 = NOVALUE;
    object _14079 = NOVALUE;
    object _14078 = NOVALUE;
    object _14076 = NOVALUE;
    object _14074 = NOVALUE;
    object _14073 = NOVALUE;
    object _14071 = NOVALUE;
    object _14070 = NOVALUE;
    object _14068 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** block.e:101		SymTab = append( SymTab, repeat( 0, SIZEOF_BLOCK_ENTRY ) )*/
    _14068 = Repeat(0LL, _36SIZEOF_BLOCK_ENTRY_21208);
    RefDS(_14068);
    Append(&_37SymTab_15406, _37SymTab_15406, _14068);
    DeRefDS(_14068);
    _14068 = NOVALUE;

    /** block.e:102		SymTab[$][S_MODE] = M_BLOCK*/
    if (IS_SEQUENCE(_37SymTab_15406)){
            _14070 = SEQ_PTR(_37SymTab_15406)->length;
    }
    else {
        _14070 = 1;
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14070 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 4LL;
    DeRef(_1);
    _14071 = NOVALUE;

    /** block.e:103		SymTab[$][S_FIRST_LINE] = gline_number*/
    if (IS_SEQUENCE(_37SymTab_15406)){
            _14073 = SEQ_PTR(_37SymTab_15406)->length;
    }
    else {
        _14073 = 1;
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14073 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_FIRST_LINE_21101))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FIRST_LINE_21101)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_FIRST_LINE_21101);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36gline_number_21444;
    DeRef(_1);
    _14074 = NOVALUE;

    /** block.e:105		sequence block = repeat( 0, BLOCK_SIZE-1 )*/
    _14076 = 6LL;
    DeRef(_block_25207);
    _block_25207 = Repeat(0LL, 6LL);
    _14076 = NOVALUE;

    /** block.e:106		block[BLOCK_SYM]    = length(SymTab)*/
    if (IS_SEQUENCE(_37SymTab_15406)){
            _14078 = SEQ_PTR(_37SymTab_15406)->length;
    }
    else {
        _14078 = 1;
    }
    _2 = (object)SEQ_PTR(_block_25207);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25207 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    *(intptr_t *)_2 = _14078;
    if( _1 != _14078 ){
    }
    _14078 = NOVALUE;

    /** block.e:107		block[BLOCK_OPCODE] = opcode*/
    _2 = (object)SEQ_PTR(_block_25207);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25207 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    *(intptr_t *)_2 = _opcode_25188;

    /** block.e:108		block[BLOCK_LABEL]  = block_label*/
    Ref(_block_label_25189);
    _2 = (object)SEQ_PTR(_block_25207);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25207 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    *(intptr_t *)_2 = _block_label_25189;

    /** block.e:109		block[BLOCK_START]  = length(Code) + 1*/
    if (IS_SEQUENCE(_36Code_21531)){
            _14079 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _14079 = 1;
    }
    _14080 = _14079 + 1;
    _14079 = NOVALUE;
    _2 = (object)SEQ_PTR(_block_25207);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25207 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14080;
    if( _1 != _14080 ){
        DeRef(_1);
    }
    _14080 = NOVALUE;

    /** block.e:110		block[BLOCK_VARS]   = {}*/
    RefDS(_5);
    _2 = (object)SEQ_PTR(_block_25207);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25207 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _5;
    DeRef(_1);

    /** block.e:112		block_stack = append( block_stack, block )*/
    RefDS(_block_25207);
    Append(&_65block_stack_25107, _65block_stack_25107, _block_25207);

    /** block.e:113		current_block = length(SymTab)*/
    if (IS_SEQUENCE(_37SymTab_15406)){
            _65current_block_25114 = SEQ_PTR(_37SymTab_15406)->length;
    }
    else {
        _65current_block_25114 = 1;
    }

    /** block.e:114	end procedure*/
    DeRefi(_block_label_25189);
    DeRefDS(_block_25207);
    return;
    ;
}


void _65Start_block(object _opcode_25220, object _block_label_25221)
{
    object _last_block_25223 = NOVALUE;
    object _label_name_25251 = NOVALUE;
    object _14102 = NOVALUE;
    object _14101 = NOVALUE;
    object _14100 = NOVALUE;
    object _14097 = NOVALUE;
    object _14096 = NOVALUE;
    object _14094 = NOVALUE;
    object _14093 = NOVALUE;
    object _14092 = NOVALUE;
    object _14091 = NOVALUE;
    object _14090 = NOVALUE;
    object _14087 = NOVALUE;
    object _14085 = NOVALUE;
    object _14084 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** block.e:120		symtab_index last_block = current_block*/
    _last_block_25223 = _65current_block_25114;

    /** block.e:121		if opcode = FUNC then*/
    if (_opcode_25220 != 501LL)
    goto L1; // [16] 30

    /** block.e:122			opcode = PROC*/
    _opcode_25220 = 27LL;
L1: 

    /** block.e:124		NewBlock( opcode, block_label )*/
    Ref(_block_label_25221);
    _65NewBlock(_opcode_25220, _block_label_25221);

    /** block.e:126		if find(opcode, RTN_TOKS) then*/
    _14084 = find_from(_opcode_25220, _38RTN_TOKS_16045, 1LL);
    if (_14084 == 0)
    {
        _14084 = NOVALUE;
        goto L2; // [45] 105
    }
    else{
        _14084 = NOVALUE;
    }

    /** block.e:127			SymTab[block_label][S_BLOCK] = current_block*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_block_label_25221))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_block_label_25221)->dbl));
    else
    _3 = (object)(_block_label_25221 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_BLOCK_21096))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_BLOCK_21096)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_BLOCK_21096);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _65current_block_25114;
    DeRef(_1);
    _14085 = NOVALUE;

    /** block.e:128			SymTab[current_block][S_NAME] = sprintf("BLOCK: %s", {SymTab[block_label][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_65current_block_25114 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_block_label_25221)){
        _14090 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_block_label_25221)->dbl));
    }
    else{
        _14090 = (object)*(((s1_ptr)_2)->base + _block_label_25221);
    }
    _2 = (object)SEQ_PTR(_14090);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _14091 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _14091 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _14090 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_14091);
    ((intptr_t*)_2)[1] = _14091;
    _14092 = MAKE_SEQ(_1);
    _14091 = NOVALUE;
    _14093 = EPrintf(-9999999, _14089, _14092);
    DeRefDS(_14092);
    _14092 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NAME_21076))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NAME_21076);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14093;
    if( _1 != _14093 ){
        DeRef(_1);
    }
    _14093 = NOVALUE;
    _14087 = NOVALUE;
    goto L3; // [102] 185
L2: 

    /** block.e:129		elsif current_block then*/
    if (_65current_block_25114 == 0)
    {
        goto L4; // [109] 182
    }
    else{
    }

    /** block.e:135			SymTab[current_block][S_BLOCK] = last_block*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_65current_block_25114 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_BLOCK_21096))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_BLOCK_21096)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_BLOCK_21096);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _last_block_25223;
    DeRef(_1);
    _14094 = NOVALUE;

    /** block.e:136			sequence label_name = ""*/
    RefDS(_5);
    DeRefi(_label_name_25251);
    _label_name_25251 = _5;

    /** block.e:137			if sequence(block_label) then*/
    _14096 = IS_SEQUENCE(_block_label_25221);
    if (_14096 == 0)
    {
        _14096 = NOVALUE;
        goto L5; // [141] 152
    }
    else{
        _14096 = NOVALUE;
    }

    /** block.e:138				label_name = block_label*/
    Ref(_block_label_25221);
    DeRefDSi(_label_name_25251);
    _label_name_25251 = _block_label_25221;
L5: 

    /** block.e:141			SymTab[current_block][S_NAME] = sprintf( "BLOCK: %s-%s", {block_type_name(opcode), label_name})*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_65current_block_25114 + ((s1_ptr)_2)->base);
    _14100 = _65block_type_name(_opcode_25220);
    RefDS(_label_name_25251);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _14100;
    ((intptr_t *)_2)[2] = _label_name_25251;
    _14101 = MAKE_SEQ(_1);
    _14100 = NOVALUE;
    _14102 = EPrintf(-9999999, _14099, _14101);
    DeRefDS(_14101);
    _14101 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NAME_21076))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NAME_21076);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14102;
    if( _1 != _14102 ){
        DeRef(_1);
    }
    _14102 = NOVALUE;
    _14097 = NOVALUE;
L4: 
    DeRefi(_label_name_25251);
    _label_name_25251 = NOVALUE;
L3: 

    /** block.e:144		ifdef BDEBUG then*/

    /** block.e:153	end procedure*/
    DeRefi(_block_label_25221);
    return;
    ;
}


void _65block_label(object _label_name_25267)
{
    object _14116 = NOVALUE;
    object _14115 = NOVALUE;
    object _14114 = NOVALUE;
    object _14113 = NOVALUE;
    object _14112 = NOVALUE;
    object _14111 = NOVALUE;
    object _14109 = NOVALUE;
    object _14107 = NOVALUE;
    object _14106 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** block.e:157		block_stack[$][BLOCK_LABEL] = label_name*/
    if (IS_SEQUENCE(_65block_stack_25107)){
            _14106 = SEQ_PTR(_65block_stack_25107)->length;
    }
    else {
        _14106 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25107);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65block_stack_25107 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14106 + ((s1_ptr)_2)->base);
    RefDS(_label_name_25267);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _label_name_25267;
    DeRef(_1);
    _14107 = NOVALUE;

    /** block.e:158		SymTab[current_block][S_NAME] = sprintf( "BLOCK: %s-%s", */
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_65current_block_25114 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_65block_stack_25107)){
            _14111 = SEQ_PTR(_65block_stack_25107)->length;
    }
    else {
        _14111 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25107);
    _14112 = (object)*(((s1_ptr)_2)->base + _14111);
    _2 = (object)SEQ_PTR(_14112);
    _14113 = (object)*(((s1_ptr)_2)->base + 2LL);
    _14112 = NOVALUE;
    Ref(_14113);
    _14114 = _65block_type_name(_14113);
    _14113 = NOVALUE;
    RefDS(_label_name_25267);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _14114;
    ((intptr_t *)_2)[2] = _label_name_25267;
    _14115 = MAKE_SEQ(_1);
    _14114 = NOVALUE;
    _14116 = EPrintf(-9999999, _14099, _14115);
    DeRefDS(_14115);
    _14115 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NAME_21076))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NAME_21076);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14116;
    if( _1 != _14116 ){
        DeRef(_1);
    }
    _14116 = NOVALUE;
    _14109 = NOVALUE;

    /** block.e:160	end procedure*/
    DeRefDS(_label_name_25267);
    return;
    ;
}


object _65pop_block()
{
    object _block_25286 = NOVALUE;
    object _block_vars_25299 = NOVALUE;
    object _14145 = NOVALUE;
    object _14143 = NOVALUE;
    object _14142 = NOVALUE;
    object _14141 = NOVALUE;
    object _14140 = NOVALUE;
    object _14138 = NOVALUE;
    object _14137 = NOVALUE;
    object _14136 = NOVALUE;
    object _14135 = NOVALUE;
    object _14134 = NOVALUE;
    object _14133 = NOVALUE;
    object _14132 = NOVALUE;
    object _14131 = NOVALUE;
    object _14130 = NOVALUE;
    object _14129 = NOVALUE;
    object _14125 = NOVALUE;
    object _14124 = NOVALUE;
    object _14122 = NOVALUE;
    object _14121 = NOVALUE;
    object _14119 = NOVALUE;
    object _14117 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** block.e:164		if not length(block_stack) then*/
    if (IS_SEQUENCE(_65block_stack_25107)){
            _14117 = SEQ_PTR(_65block_stack_25107)->length;
    }
    else {
        _14117 = 1;
    }
    if (_14117 != 0)
    goto L1; // [8] 18
    _14117 = NOVALUE;

    /** block.e:165			return 0*/
    DeRef(_block_25286);
    DeRef(_block_vars_25299);
    return 0LL;
L1: 

    /** block.e:168		sequence  block = block_stack[$]*/
    if (IS_SEQUENCE(_65block_stack_25107)){
            _14119 = SEQ_PTR(_65block_stack_25107)->length;
    }
    else {
        _14119 = 1;
    }
    DeRef(_block_25286);
    _2 = (object)SEQ_PTR(_65block_stack_25107);
    _block_25286 = (object)*(((s1_ptr)_2)->base + _14119);
    Ref(_block_25286);

    /** block.e:169		block_stack = block_stack[1..$-1]*/
    if (IS_SEQUENCE(_65block_stack_25107)){
            _14121 = SEQ_PTR(_65block_stack_25107)->length;
    }
    else {
        _14121 = 1;
    }
    _14122 = _14121 - 1LL;
    _14121 = NOVALUE;
    rhs_slice_target = (object_ptr)&_65block_stack_25107;
    RHS_Slice(_65block_stack_25107, 1LL, _14122);

    /** block.e:170		SymTab[block[BLOCK_SYM]][S_LAST_LINE] = gline_number*/
    _2 = (object)SEQ_PTR(_block_25286);
    _14124 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_14124))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14124)->dbl));
    else
    _3 = (object)(_14124 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_LAST_LINE_21106))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LAST_LINE_21106)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_LAST_LINE_21106);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36gline_number_21444;
    DeRef(_1);
    _14125 = NOVALUE;

    /** block.e:172		ifdef BDEBUG then*/

    /** block.e:177		sequence block_vars = block[BLOCK_VARS]*/
    DeRef(_block_vars_25299);
    _2 = (object)SEQ_PTR(_block_25286);
    _block_vars_25299 = (object)*(((s1_ptr)_2)->base + 6LL);
    Ref(_block_vars_25299);

    /** block.e:178		for sx = 1 to length( block_vars ) do*/
    if (IS_SEQUENCE(_block_vars_25299)){
            _14129 = SEQ_PTR(_block_vars_25299)->length;
    }
    else {
        _14129 = 1;
    }
    {
        object _sx_25302;
        _sx_25302 = 1LL;
L2: 
        if (_sx_25302 > _14129){
            goto L3; // [83] 172
        }

        /** block.e:180			if SymTab[block_vars[sx]][S_MODE] = M_NORMAL */
        _2 = (object)SEQ_PTR(_block_vars_25299);
        _14130 = (object)*(((s1_ptr)_2)->base + _sx_25302);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!IS_ATOM_INT(_14130)){
            _14131 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14130)->dbl));
        }
        else{
            _14131 = (object)*(((s1_ptr)_2)->base + _14130);
        }
        _2 = (object)SEQ_PTR(_14131);
        _14132 = (object)*(((s1_ptr)_2)->base + 3LL);
        _14131 = NOVALUE;
        if (IS_ATOM_INT(_14132)) {
            _14133 = (_14132 == 1LL);
        }
        else {
            _14133 = binary_op(EQUALS, _14132, 1LL);
        }
        _14132 = NOVALUE;
        if (IS_ATOM_INT(_14133)) {
            if (_14133 == 0) {
                goto L4; // [114] 165
            }
        }
        else {
            if (DBL_PTR(_14133)->dbl == 0.0) {
                goto L4; // [114] 165
            }
        }
        _2 = (object)SEQ_PTR(_block_vars_25299);
        _14135 = (object)*(((s1_ptr)_2)->base + _sx_25302);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!IS_ATOM_INT(_14135)){
            _14136 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14135)->dbl));
        }
        else{
            _14136 = (object)*(((s1_ptr)_2)->base + _14135);
        }
        _2 = (object)SEQ_PTR(_14136);
        _14137 = (object)*(((s1_ptr)_2)->base + 4LL);
        _14136 = NOVALUE;
        if (IS_ATOM_INT(_14137)) {
            _14138 = (_14137 <= 5LL);
        }
        else {
            _14138 = binary_op(LESSEQ, _14137, 5LL);
        }
        _14137 = NOVALUE;
        if (_14138 == 0) {
            DeRef(_14138);
            _14138 = NOVALUE;
            goto L4; // [141] 165
        }
        else {
            if (!IS_ATOM_INT(_14138) && DBL_PTR(_14138)->dbl == 0.0){
                DeRef(_14138);
                _14138 = NOVALUE;
                goto L4; // [141] 165
            }
            DeRef(_14138);
            _14138 = NOVALUE;
        }
        DeRef(_14138);
        _14138 = NOVALUE;

        /** block.e:182				ifdef BDEBUG then*/

        /** block.e:187				Hide( block_vars[sx] )*/
        _2 = (object)SEQ_PTR(_block_vars_25299);
        _14140 = (object)*(((s1_ptr)_2)->base + _sx_25302);
        Ref(_14140);
        _54Hide(_14140);
        _14140 = NOVALUE;

        /** block.e:188				LintCheck( block_vars[sx] )*/
        _2 = (object)SEQ_PTR(_block_vars_25299);
        _14141 = (object)*(((s1_ptr)_2)->base + _sx_25302);
        Ref(_14141);
        _54LintCheck(_14141);
        _14141 = NOVALUE;
L4: 

        /** block.e:191		end for*/
        _sx_25302 = _sx_25302 + 1LL;
        goto L2; // [167] 90
L3: 
        ;
    }

    /** block.e:213		current_block = block_stack[$][BLOCK_SYM]*/
    if (IS_SEQUENCE(_65block_stack_25107)){
            _14142 = SEQ_PTR(_65block_stack_25107)->length;
    }
    else {
        _14142 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25107);
    _14143 = (object)*(((s1_ptr)_2)->base + _14142);
    _2 = (object)SEQ_PTR(_14143);
    _65current_block_25114 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_65current_block_25114)){
        _65current_block_25114 = (object)DBL_PTR(_65current_block_25114)->dbl;
    }
    _14143 = NOVALUE;

    /** block.e:214		return block[BLOCK_SYM]*/
    _2 = (object)SEQ_PTR(_block_25286);
    _14145 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_14145);
    DeRefDS(_block_25286);
    DeRef(_block_vars_25299);
    _14135 = NOVALUE;
    _14124 = NOVALUE;
    _14130 = NOVALUE;
    DeRef(_14122);
    _14122 = NOVALUE;
    DeRef(_14133);
    _14133 = NOVALUE;
    return _14145;
    ;
}


object _65top_block(object _offset_25331)
{
    object _14153 = NOVALUE;
    object _14152 = NOVALUE;
    object _14151 = NOVALUE;
    object _14150 = NOVALUE;
    object _14149 = NOVALUE;
    object _14148 = NOVALUE;
    object _14146 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:219		if offset >= length(block_stack) then*/
    if (IS_SEQUENCE(_65block_stack_25107)){
            _14146 = SEQ_PTR(_65block_stack_25107)->length;
    }
    else {
        _14146 = 1;
    }
    if (_offset_25331 < _14146)
    goto L1; // [10] 35

    /** block.e:220			CompileErr(LEAVING_TOO_MANY_BLOCKS_1__2, {offset,length(block_stack)})*/
    if (IS_SEQUENCE(_65block_stack_25107)){
            _14148 = SEQ_PTR(_65block_stack_25107)->length;
    }
    else {
        _14148 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _offset_25331;
    ((intptr_t *)_2)[2] = _14148;
    _14149 = MAKE_SEQ(_1);
    _14148 = NOVALUE;
    _50CompileErr(107LL, _14149, 0LL);
    _14149 = NOVALUE;
    goto L2; // [32] 59
L1: 

    /** block.e:222			return block_stack[$-offset][BLOCK_SYM]*/
    if (IS_SEQUENCE(_65block_stack_25107)){
            _14150 = SEQ_PTR(_65block_stack_25107)->length;
    }
    else {
        _14150 = 1;
    }
    _14151 = _14150 - _offset_25331;
    _14150 = NOVALUE;
    _2 = (object)SEQ_PTR(_65block_stack_25107);
    _14152 = (object)*(((s1_ptr)_2)->base + _14151);
    _2 = (object)SEQ_PTR(_14152);
    _14153 = (object)*(((s1_ptr)_2)->base + 1LL);
    _14152 = NOVALUE;
    Ref(_14153);
    _14151 = NOVALUE;
    return _14153;
L2: 
    ;
}


void _65End_block(object _opcode_25346)
{
    object _ix_25357 = NOVALUE;
    object _14161 = NOVALUE;
    object _14158 = NOVALUE;
    object _14157 = NOVALUE;
    object _14156 = NOVALUE;
    object _14155 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:229		if opcode = FUNC then*/

    /** block.e:232		check_block( opcode )*/
    _65check_block(_opcode_25346);

    /** block.e:233		if not length(block_stack[$][BLOCK_VARS]) then*/
    if (IS_SEQUENCE(_65block_stack_25107)){
            _14155 = SEQ_PTR(_65block_stack_25107)->length;
    }
    else {
        _14155 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25107);
    _14156 = (object)*(((s1_ptr)_2)->base + _14155);
    _2 = (object)SEQ_PTR(_14156);
    _14157 = (object)*(((s1_ptr)_2)->base + 6LL);
    _14156 = NOVALUE;
    if (IS_SEQUENCE(_14157)){
            _14158 = SEQ_PTR(_14157)->length;
    }
    else {
        _14158 = 1;
    }
    _14157 = NOVALUE;
    if (_14158 != 0)
    goto L1; // [44] 64
    _14158 = NOVALUE;

    /** block.e:234			integer ix = 1*/
    _ix_25357 = 1LL;

    /** block.e:235			ix = pop_block()*/
    _ix_25357 = _65pop_block();
    if (!IS_ATOM_INT(_ix_25357)) {
        _1 = (object)(DBL_PTR(_ix_25357)->dbl);
        DeRefDS(_ix_25357);
        _ix_25357 = _1;
    }
    goto L2; // [61] 80
L1: 

    /** block.e:237			Push( pop_block() )*/
    _14161 = _65pop_block();
    _47Push(_14161);
    _14161 = NOVALUE;

    /** block.e:238			emit_op( EXIT_BLOCK )*/
    _47emit_op(206LL);
L2: 

    /** block.e:241	end procedure*/
    _14157 = NOVALUE;
    return;
    ;
}


object _65End_inline_block(object _opcode_25366)
{
    object _14168 = NOVALUE;
    object _14167 = NOVALUE;
    object _14166 = NOVALUE;
    object _14165 = NOVALUE;
    object _14164 = NOVALUE;
    object _14163 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:246		if opcode = FUNC then*/

    /** block.e:249		if length(block_stack[$][BLOCK_VARS]) then*/
    if (IS_SEQUENCE(_65block_stack_25107)){
            _14163 = SEQ_PTR(_65block_stack_25107)->length;
    }
    else {
        _14163 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25107);
    _14164 = (object)*(((s1_ptr)_2)->base + _14163);
    _2 = (object)SEQ_PTR(_14164);
    _14165 = (object)*(((s1_ptr)_2)->base + 6LL);
    _14164 = NOVALUE;
    if (IS_SEQUENCE(_14165)){
            _14166 = SEQ_PTR(_14165)->length;
    }
    else {
        _14166 = 1;
    }
    _14165 = NOVALUE;
    if (_14166 == 0)
    {
        _14166 = NOVALUE;
        goto L1; // [39] 60
    }
    else{
        _14166 = NOVALUE;
    }

    /** block.e:250			return { EXIT_BLOCK, pop_block() }*/
    _14167 = _65pop_block();
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 206LL;
    ((intptr_t *)_2)[2] = _14167;
    _14168 = MAKE_SEQ(_1);
    _14167 = NOVALUE;
    _14165 = NOVALUE;
    return _14168;
    goto L2; // [57] 72
L1: 

    /** block.e:252			Drop_block( opcode )*/
    _65Drop_block(_opcode_25366);

    /** block.e:253			return {}*/
    RefDS(_5);
    _14165 = NOVALUE;
    DeRef(_14168);
    _14168 = NOVALUE;
    return _5;
L2: 
    ;
}


void _65Sibling_block(object _opcode_25383)
{
    object _0, _1, _2;
    

    /** block.e:261		End_block( opcode )*/
    _65End_block(_opcode_25383);

    /** block.e:262		Start_block( opcode )*/
    _65Start_block(_opcode_25383, 0LL);

    /** block.e:263	end procedure*/
    return;
    ;
}


void _65Leave_block(object _offset_25386)
{
    object _14174 = NOVALUE;
    object _14173 = NOVALUE;
    object _14172 = NOVALUE;
    object _14171 = NOVALUE;
    object _14170 = NOVALUE;
    object _14169 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_offset_25386)) {
        _1 = (object)(DBL_PTR(_offset_25386)->dbl);
        DeRefDS(_offset_25386);
        _offset_25386 = _1;
    }

    /** block.e:268		if length( block_stack[$-offset][BLOCK_VARS]) then*/
    if (IS_SEQUENCE(_65block_stack_25107)){
            _14169 = SEQ_PTR(_65block_stack_25107)->length;
    }
    else {
        _14169 = 1;
    }
    _14170 = _14169 - _offset_25386;
    _14169 = NOVALUE;
    _2 = (object)SEQ_PTR(_65block_stack_25107);
    _14171 = (object)*(((s1_ptr)_2)->base + _14170);
    _2 = (object)SEQ_PTR(_14171);
    _14172 = (object)*(((s1_ptr)_2)->base + 6LL);
    _14171 = NOVALUE;
    if (IS_SEQUENCE(_14172)){
            _14173 = SEQ_PTR(_14172)->length;
    }
    else {
        _14173 = 1;
    }
    _14172 = NOVALUE;
    if (_14173 == 0)
    {
        _14173 = NOVALUE;
        goto L1; // [25] 45
    }
    else{
        _14173 = NOVALUE;
    }

    /** block.e:269			Push( top_block( offset ) )*/
    _14174 = _65top_block(_offset_25386);
    _47Push(_14174);
    _14174 = NOVALUE;

    /** block.e:270			emit_op( EXIT_BLOCK )*/
    _47emit_op(206LL);
L1: 

    /** block.e:272	end procedure*/
    DeRef(_14170);
    _14170 = NOVALUE;
    _14172 = NOVALUE;
    return;
    ;
}


void _65Leave_blocks(object _blocks_25406, object _block_type_25407)
{
    object _bx_25408 = NOVALUE;
    object _Block_opcode_3__tmp_at29_25415 = NOVALUE;
    object _Block_opcode_2__tmp_at29_25414 = NOVALUE;
    object _Block_opcode_1__tmp_at29_25413 = NOVALUE;
    object _Block_opcode_inlined_Block_opcode_at_29_25412 = NOVALUE;
    object _14187 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_blocks_25406)) {
        _1 = (object)(DBL_PTR(_blocks_25406)->dbl);
        DeRefDS(_blocks_25406);
        _blocks_25406 = _1;
    }

    /** block.e:284		integer bx = 0*/
    _bx_25408 = 0LL;

    /** block.e:285		while blocks do*/
L1: 
    if (_blocks_25406 == 0)
    {
        goto L2; // [15] 119
    }
    else{
    }

    /** block.e:286			Leave_block( bx )*/
    _65Leave_block(_bx_25408);

    /** block.e:288			if block_type then*/
    if (_block_type_25407 == 0)
    {
        goto L3; // [25] 101
    }
    else{
    }

    /** block.e:289				switch Block_opcode( bx ) do*/

    /** block.e:276		return block_stack[$-bx][BLOCK_OPCODE]*/
    if (IS_SEQUENCE(_65block_stack_25107)){
            _Block_opcode_1__tmp_at29_25413 = SEQ_PTR(_65block_stack_25107)->length;
    }
    else {
        _Block_opcode_1__tmp_at29_25413 = 1;
    }
    _Block_opcode_2__tmp_at29_25414 = _Block_opcode_1__tmp_at29_25413 - _bx_25408;
    DeRef(_Block_opcode_3__tmp_at29_25415);
    _2 = (object)SEQ_PTR(_65block_stack_25107);
    _Block_opcode_3__tmp_at29_25415 = (object)*(((s1_ptr)_2)->base + _Block_opcode_2__tmp_at29_25414);
    Ref(_Block_opcode_3__tmp_at29_25415);
    DeRef(_Block_opcode_inlined_Block_opcode_at_29_25412);
    _2 = (object)SEQ_PTR(_Block_opcode_3__tmp_at29_25415);
    _Block_opcode_inlined_Block_opcode_at_29_25412 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_Block_opcode_inlined_Block_opcode_at_29_25412);
    DeRef(_Block_opcode_3__tmp_at29_25415);
    _Block_opcode_3__tmp_at29_25415 = NOVALUE;
    if (IS_SEQUENCE(_Block_opcode_inlined_Block_opcode_at_29_25412) ){
        goto L4; // [52] 82
    }
    if(!IS_ATOM_INT(_Block_opcode_inlined_Block_opcode_at_29_25412)){
        if( (DBL_PTR(_Block_opcode_inlined_Block_opcode_at_29_25412)->dbl != (eudouble) ((object) DBL_PTR(_Block_opcode_inlined_Block_opcode_at_29_25412)->dbl) ) ){
            goto L4; // [52] 82
        }
        _0 = (object) DBL_PTR(_Block_opcode_inlined_Block_opcode_at_29_25412)->dbl;
    }
    else {
        _0 = _Block_opcode_inlined_Block_opcode_at_29_25412;
    };
    switch ( _0 ){ 

        /** block.e:290					case FOR, WHILE, LOOP then*/
        case 21:
        case 47:
        case 422:

        /** block.e:291						if block_type = LOOP_BLOCK then*/
        if (_block_type_25407 != 1LL)
        goto L5; // [67] 108

        /** block.e:292							blocks -= 1*/
        _blocks_25406 = _blocks_25406 - 1LL;
        goto L5; // [78] 108

        /** block.e:294					case else*/
        default:
L4: 

        /** block.e:295						if block_type = CONDITIONAL_BLOCK then*/
        if (_block_type_25407 != 2LL)
        goto L6; // [86] 97

        /** block.e:296							blocks -= 1*/
        _blocks_25406 = _blocks_25406 - 1LL;
L6: 
    ;}    goto L5; // [98] 108
L3: 

    /** block.e:300				blocks -= 1*/
    _blocks_25406 = _blocks_25406 - 1LL;
L5: 

    /** block.e:302			bx += 1*/
    _bx_25408 = _bx_25408 + 1;

    /** block.e:303		end while*/
    goto L1; // [116] 15
L2: 

    /** block.e:304		for i = 0 to blocks - 1 do*/
    _14187 = _blocks_25406 - 1LL;
    if ((object)((uintptr_t)_14187 +(uintptr_t) HIGH_BITS) >= 0){
        _14187 = NewDouble((eudouble)_14187);
    }
    {
        object _i_25433;
        _i_25433 = 0LL;
L7: 
        if (binary_op_a(GREATER, _i_25433, _14187)){
            goto L8; // [125] 144
        }

        /** block.e:305			Leave_block( i )*/
        Ref(_i_25433);
        _65Leave_block(_i_25433);

        /** block.e:306		end for*/
        _0 = _i_25433;
        if (IS_ATOM_INT(_i_25433)) {
            _i_25433 = _i_25433 + 1LL;
            if ((object)((uintptr_t)_i_25433 +(uintptr_t) HIGH_BITS) >= 0){
                _i_25433 = NewDouble((eudouble)_i_25433);
            }
        }
        else {
            _i_25433 = binary_op_a(PLUS, _i_25433, 1LL);
        }
        DeRef(_0);
        goto L7; // [139] 132
L8: 
        ;
        DeRef(_i_25433);
    }

    /** block.e:307	end procedure*/
    DeRef(_14187);
    _14187 = NOVALUE;
    return;
    ;
}


void _65Drop_block(object _opcode_25437)
{
    object _x_25439 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:311		check_block( opcode )*/
    _65check_block(_opcode_25437);

    /** block.e:312		symtab_index x = pop_block()*/
    _x_25439 = _65pop_block();
    if (!IS_ATOM_INT(_x_25439)) {
        _1 = (object)(DBL_PTR(_x_25439)->dbl);
        DeRefDS(_x_25439);
        _x_25439 = _1;
    }

    /** block.e:313	end procedure*/
    return;
    ;
}


void _65Pop_block_var()
{
    object _sym_25444 = NOVALUE;
    object _block_sym_25451 = NOVALUE;
    object _14215 = NOVALUE;
    object _14214 = NOVALUE;
    object _14213 = NOVALUE;
    object _14212 = NOVALUE;
    object _14211 = NOVALUE;
    object _14210 = NOVALUE;
    object _14209 = NOVALUE;
    object _14208 = NOVALUE;
    object _14206 = NOVALUE;
    object _14205 = NOVALUE;
    object _14203 = NOVALUE;
    object _14202 = NOVALUE;
    object _14200 = NOVALUE;
    object _14197 = NOVALUE;
    object _14195 = NOVALUE;
    object _14194 = NOVALUE;
    object _14192 = NOVALUE;
    object _14191 = NOVALUE;
    object _14190 = NOVALUE;
    object _14189 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** block.e:316		symtab_index sym = block_stack[$][BLOCK_VARS][$]*/
    if (IS_SEQUENCE(_65block_stack_25107)){
            _14189 = SEQ_PTR(_65block_stack_25107)->length;
    }
    else {
        _14189 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25107);
    _14190 = (object)*(((s1_ptr)_2)->base + _14189);
    _2 = (object)SEQ_PTR(_14190);
    _14191 = (object)*(((s1_ptr)_2)->base + 6LL);
    _14190 = NOVALUE;
    if (IS_SEQUENCE(_14191)){
            _14192 = SEQ_PTR(_14191)->length;
    }
    else {
        _14192 = 1;
    }
    _2 = (object)SEQ_PTR(_14191);
    _sym_25444 = (object)*(((s1_ptr)_2)->base + _14192);
    if (!IS_ATOM_INT(_sym_25444)){
        _sym_25444 = (object)DBL_PTR(_sym_25444)->dbl;
    }
    _14191 = NOVALUE;

    /** block.e:317		symtab_index block_sym = block_stack[$][BLOCK_SYM]*/
    if (IS_SEQUENCE(_65block_stack_25107)){
            _14194 = SEQ_PTR(_65block_stack_25107)->length;
    }
    else {
        _14194 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25107);
    _14195 = (object)*(((s1_ptr)_2)->base + _14194);
    _2 = (object)SEQ_PTR(_14195);
    _block_sym_25451 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_block_sym_25451)){
        _block_sym_25451 = (object)DBL_PTR(_block_sym_25451)->dbl;
    }
    _14195 = NOVALUE;

    /** block.e:318		while sym_next_in_block( block_sym ) != sym do*/
L1: 
    _14197 = _54sym_next_in_block(_block_sym_25451);
    if (binary_op_a(EQUALS, _14197, _sym_25444)){
        DeRef(_14197);
        _14197 = NOVALUE;
        goto L2; // [51] 68
    }
    DeRef(_14197);
    _14197 = NOVALUE;

    /** block.e:319			block_sym = sym_next_in_block( block_sym )*/
    _block_sym_25451 = _54sym_next_in_block(_block_sym_25451);
    if (!IS_ATOM_INT(_block_sym_25451)) {
        _1 = (object)(DBL_PTR(_block_sym_25451)->dbl);
        DeRefDS(_block_sym_25451);
        _block_sym_25451 = _1;
    }

    /** block.e:320		end while*/
    goto L1; // [65] 47
L2: 

    /** block.e:322		SymTab[block_sym][S_NEXT_IN_BLOCK] = sym_next_in_block( sym )*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_block_sym_25451 + ((s1_ptr)_2)->base);
    _14202 = _54sym_next_in_block(_sym_25444);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NEXT_IN_BLOCK_21068))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NEXT_IN_BLOCK_21068)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NEXT_IN_BLOCK_21068);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14202;
    if( _1 != _14202 ){
        DeRef(_1);
    }
    _14202 = NOVALUE;
    _14200 = NOVALUE;

    /** block.e:323		SymTab[sym][S_NEXT_IN_BLOCK] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_25444 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NEXT_IN_BLOCK_21068))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NEXT_IN_BLOCK_21068)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NEXT_IN_BLOCK_21068);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _14203 = NOVALUE;

    /** block.e:325		block_stack[$][BLOCK_VARS] = eu:remove( block_stack[$][BLOCK_VARS], */
    if (IS_SEQUENCE(_65block_stack_25107)){
            _14205 = SEQ_PTR(_65block_stack_25107)->length;
    }
    else {
        _14205 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25107);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65block_stack_25107 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14205 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_65block_stack_25107)){
            _14208 = SEQ_PTR(_65block_stack_25107)->length;
    }
    else {
        _14208 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25107);
    _14209 = (object)*(((s1_ptr)_2)->base + _14208);
    _2 = (object)SEQ_PTR(_14209);
    _14210 = (object)*(((s1_ptr)_2)->base + 6LL);
    _14209 = NOVALUE;
    if (IS_SEQUENCE(_65block_stack_25107)){
            _14211 = SEQ_PTR(_65block_stack_25107)->length;
    }
    else {
        _14211 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25107);
    _14212 = (object)*(((s1_ptr)_2)->base + _14211);
    _2 = (object)SEQ_PTR(_14212);
    _14213 = (object)*(((s1_ptr)_2)->base + 6LL);
    _14212 = NOVALUE;
    if (IS_SEQUENCE(_14213)){
            _14214 = SEQ_PTR(_14213)->length;
    }
    else {
        _14214 = 1;
    }
    _14213 = NOVALUE;
    {
        s1_ptr assign_space = SEQ_PTR(_14210);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_14214)) ? _14214 : (object)(DBL_PTR(_14214)->dbl);
        int stop = (IS_ATOM_INT(_14214)) ? _14214 : (object)(DBL_PTR(_14214)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
            RefDS(_14210);
            DeRef(_14215);
            _14215 = _14210;
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_14210), start, &_14215 );
            }
            else Tail(SEQ_PTR(_14210), stop+1, &_14215);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_14210), start, &_14215);
        }
        else {
            assign_slice_seq = &assign_space;
            _1 = Remove_elements(start, stop, 0);
            DeRef(_14215);
            _14215 = _1;
        }
    }
    _14210 = NOVALUE;
    _14214 = NOVALUE;
    _14214 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14215;
    if( _1 != _14215 ){
        DeRef(_1);
    }
    _14215 = NOVALUE;
    _14206 = NOVALUE;

    /** block.e:327	end procedure*/
    _14213 = NOVALUE;
    return;
    ;
}


void _65Goto_block(object _from_block_25485, object _to_block_25487, object _pc_25488)
{
    object _code_25489 = NOVALUE;
    object _next_block_25491 = NOVALUE;
    object _14226 = NOVALUE;
    object _14223 = NOVALUE;
    object _14222 = NOVALUE;
    object _14221 = NOVALUE;
    object _14220 = NOVALUE;
    object _14219 = NOVALUE;
    object _14218 = NOVALUE;
    object _14217 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_from_block_25485)) {
        _1 = (object)(DBL_PTR(_from_block_25485)->dbl);
        DeRefDS(_from_block_25485);
        _from_block_25485 = _1;
    }
    if (!IS_ATOM_INT(_to_block_25487)) {
        _1 = (object)(DBL_PTR(_to_block_25487)->dbl);
        DeRefDS(_to_block_25487);
        _to_block_25487 = _1;
    }
    if (!IS_ATOM_INT(_pc_25488)) {
        _1 = (object)(DBL_PTR(_pc_25488)->dbl);
        DeRefDS(_pc_25488);
        _pc_25488 = _1;
    }

    /** block.e:330		sequence code = {}*/
    RefDS(_5);
    DeRefi(_code_25489);
    _code_25489 = _5;

    /** block.e:331		symtab_index next_block = sym_block( from_block )*/
    _next_block_25491 = _54sym_block(_from_block_25485);
    if (!IS_ATOM_INT(_next_block_25491)) {
        _1 = (object)(DBL_PTR(_next_block_25491)->dbl);
        DeRefDS(_next_block_25491);
        _next_block_25491 = _1;
    }

    /** block.e:332		while next_block */
L1: 
    if (_next_block_25491 == 0) {
        _14217 = 0;
        goto L2; // [27] 39
    }
    _14218 = (_from_block_25485 != _to_block_25487);
    _14217 = (_14218 != 0);
L2: 
    if (_14217 == 0) {
        goto L3; // [39] 93
    }
    _14220 = _54sym_token(_next_block_25491);
    _14221 = find_from(_14220, _38RTN_TOKS_16045, 1LL);
    DeRef(_14220);
    _14220 = NOVALUE;
    _14222 = (_14221 == 0);
    _14221 = NOVALUE;
    if (_14222 == 0)
    {
        DeRef(_14222);
        _14222 = NOVALUE;
        goto L3; // [58] 93
    }
    else{
        DeRef(_14222);
        _14222 = NOVALUE;
    }

    /** block.e:335			code &= { EXIT_BLOCK, from_block }*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 206LL;
    ((intptr_t *)_2)[2] = _from_block_25485;
    _14223 = MAKE_SEQ(_1);
    Concat((object_ptr)&_code_25489, _code_25489, _14223);
    DeRefDS(_14223);
    _14223 = NOVALUE;

    /** block.e:336			from_block = next_block*/
    _from_block_25485 = _next_block_25491;

    /** block.e:337			next_block = sym_block( next_block )*/
    _next_block_25491 = _54sym_block(_next_block_25491);
    if (!IS_ATOM_INT(_next_block_25491)) {
        _1 = (object)(DBL_PTR(_next_block_25491)->dbl);
        DeRefDS(_next_block_25491);
        _next_block_25491 = _1;
    }

    /** block.e:338		end while*/
    goto L1; // [90] 27
L3: 

    /** block.e:340		if length(code) then*/
    if (IS_SEQUENCE(_code_25489)){
            _14226 = SEQ_PTR(_code_25489)->length;
    }
    else {
        _14226 = 1;
    }
    if (_14226 == 0)
    {
        _14226 = NOVALUE;
        goto L4; // [98] 127
    }
    else{
        _14226 = NOVALUE;
    }

    /** block.e:341			if pc then*/
    if (_pc_25488 == 0)
    {
        goto L5; // [103] 115
    }
    else{
    }

    /** block.e:342				insert_code( code, pc )*/
    RefDS(_code_25489);
    _66insert_code(_code_25489, _pc_25488);
    goto L6; // [112] 126
L5: 

    /** block.e:344				Code &= code*/
    Concat((object_ptr)&_36Code_21531, _36Code_21531, _code_25489);
L6: 
L4: 

    /** block.e:348	end procedure*/
    DeRefi(_code_25489);
    DeRef(_14218);
    _14218 = NOVALUE;
    return;
    ;
}


object _65Least_block()
{
    object _ix_25519 = NOVALUE;
    object _sub_block_25522 = NOVALUE;
    object _14240 = NOVALUE;
    object _14239 = NOVALUE;
    object _14237 = NOVALUE;
    object _14236 = NOVALUE;
    object _14235 = NOVALUE;
    object _14234 = NOVALUE;
    object _14233 = NOVALUE;
    object _14232 = NOVALUE;
    object _14231 = NOVALUE;
    object _14230 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:358		integer ix = length( block_stack )*/
    if (IS_SEQUENCE(_65block_stack_25107)){
            _ix_25519 = SEQ_PTR(_65block_stack_25107)->length;
    }
    else {
        _ix_25519 = 1;
    }

    /** block.e:359		symtab_index sub_block = sym_block( CurrentSub )*/
    _sub_block_25522 = _54sym_block(_36CurrentSub_21447);
    if (!IS_ATOM_INT(_sub_block_25522)) {
        _1 = (object)(DBL_PTR(_sub_block_25522)->dbl);
        DeRefDS(_sub_block_25522);
        _sub_block_25522 = _1;
    }

    /** block.e:360		while not length( block_stack[ix][BLOCK_VARS] ) */
L1: 
    _2 = (object)SEQ_PTR(_65block_stack_25107);
    _14230 = (object)*(((s1_ptr)_2)->base + _ix_25519);
    _2 = (object)SEQ_PTR(_14230);
    _14231 = (object)*(((s1_ptr)_2)->base + 6LL);
    _14230 = NOVALUE;
    if (IS_SEQUENCE(_14231)){
            _14232 = SEQ_PTR(_14231)->length;
    }
    else {
        _14232 = 1;
    }
    _14231 = NOVALUE;
    _14233 = (_14232 == 0);
    _14232 = NOVALUE;
    if (_14233 == 0) {
        goto L2; // [39] 72
    }
    _2 = (object)SEQ_PTR(_65block_stack_25107);
    _14235 = (object)*(((s1_ptr)_2)->base + _ix_25519);
    _2 = (object)SEQ_PTR(_14235);
    _14236 = (object)*(((s1_ptr)_2)->base + 1LL);
    _14235 = NOVALUE;
    if (IS_ATOM_INT(_14236)) {
        _14237 = (_14236 != _sub_block_25522);
    }
    else {
        _14237 = binary_op(NOTEQ, _14236, _sub_block_25522);
    }
    _14236 = NOVALUE;
    if (_14237 <= 0) {
        if (_14237 == 0) {
            DeRef(_14237);
            _14237 = NOVALUE;
            goto L2; // [58] 72
        }
        else {
            if (!IS_ATOM_INT(_14237) && DBL_PTR(_14237)->dbl == 0.0){
                DeRef(_14237);
                _14237 = NOVALUE;
                goto L2; // [58] 72
            }
            DeRef(_14237);
            _14237 = NOVALUE;
        }
    }
    DeRef(_14237);
    _14237 = NOVALUE;

    /** block.e:362			ix -= 1	*/
    _ix_25519 = _ix_25519 - 1LL;

    /** block.e:363		end while*/
    goto L1; // [69] 23
L2: 

    /** block.e:364		return block_stack[ix][BLOCK_SYM]*/
    _2 = (object)SEQ_PTR(_65block_stack_25107);
    _14239 = (object)*(((s1_ptr)_2)->base + _ix_25519);
    _2 = (object)SEQ_PTR(_14239);
    _14240 = (object)*(((s1_ptr)_2)->base + 1LL);
    _14239 = NOVALUE;
    Ref(_14240);
    _14231 = NOVALUE;
    DeRef(_14233);
    _14233 = NOVALUE;
    return _14240;
    ;
}



// 0x201DC0FE
