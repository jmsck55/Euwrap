// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _17find_first_wildcard(object _name_6001, object _from_6002)
{
    object _asterisk_at_6003 = NOVALUE;
    object _question_at_6005 = NOVALUE;
    object _first_wildcard_at_6007 = NOVALUE;
    object _3137 = NOVALUE;
    object _3136 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:247		integer asterisk_at = eu:find('*', name, from)*/
    _asterisk_at_6003 = find_from(42LL, _name_6001, _from_6002);

    /** filesys.e:248		integer question_at = eu:find('?', name, from)*/
    _question_at_6005 = find_from(63LL, _name_6001, _from_6002);

    /** filesys.e:249		integer first_wildcard_at = asterisk_at*/
    _first_wildcard_at_6007 = _asterisk_at_6003;

    /** filesys.e:250		if asterisk_at or question_at then*/
    if (_asterisk_at_6003 != 0) {
        goto L1; // [26] 35
    }
    if (_question_at_6005 == 0)
    {
        goto L2; // [31] 56
    }
    else{
    }
L1: 

    /** filesys.e:253			if question_at and question_at < asterisk_at then*/
    if (_question_at_6005 == 0) {
        goto L3; // [37] 55
    }
    _3137 = (_question_at_6005 < _asterisk_at_6003);
    if (_3137 == 0)
    {
        DeRef(_3137);
        _3137 = NOVALUE;
        goto L3; // [46] 55
    }
    else{
        DeRef(_3137);
        _3137 = NOVALUE;
    }

    /** filesys.e:254				first_wildcard_at = question_at*/
    _first_wildcard_at_6007 = _question_at_6005;
L3: 
L2: 

    /** filesys.e:257		return first_wildcard_at*/
    DeRefDS(_name_6001);
    return _first_wildcard_at_6007;
    ;
}


object _17dir(object _name_6015)
{
    object _dir_data_6016 = NOVALUE;
    object _data_6017 = NOVALUE;
    object _the_name_6018 = NOVALUE;
    object _the_dir_6019 = NOVALUE;
    object _the_suffix_6020 = NOVALUE;
    object _idx_6021 = NOVALUE;
    object _first_wildcard_at_6022 = NOVALUE;
    object _next_slash_6037 = NOVALUE;
    object _wild_data_6069 = NOVALUE;
    object _interim_dir_6073 = NOVALUE;
    object _dir_results_6077 = NOVALUE;
    object _3180 = NOVALUE;
    object _3179 = NOVALUE;
    object _3178 = NOVALUE;
    object _3176 = NOVALUE;
    object _3175 = NOVALUE;
    object _3174 = NOVALUE;
    object _3172 = NOVALUE;
    object _3170 = NOVALUE;
    object _3169 = NOVALUE;
    object _3168 = NOVALUE;
    object _3167 = NOVALUE;
    object _3165 = NOVALUE;
    object _3163 = NOVALUE;
    object _3162 = NOVALUE;
    object _3161 = NOVALUE;
    object _3160 = NOVALUE;
    object _3159 = NOVALUE;
    object _3158 = NOVALUE;
    object _3155 = NOVALUE;
    object _3154 = NOVALUE;
    object _3152 = NOVALUE;
    object _3150 = NOVALUE;
    object _3149 = NOVALUE;
    object _3142 = NOVALUE;
    object _3140 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** filesys.e:358		ifdef WINDOWS then*/

    /** filesys.e:361			object dir_data, data, the_name, the_dir, the_suffix = 0*/
    DeRef(_the_suffix_6020);
    _the_suffix_6020 = 0LL;

    /** filesys.e:362			integer idx*/

    /** filesys.e:365			integer first_wildcard_at = find_first_wildcard( name )*/
    RefDS(_name_6015);
    _first_wildcard_at_6022 = _17find_first_wildcard(_name_6015, 1LL);
    if (!IS_ATOM_INT(_first_wildcard_at_6022)) {
        _1 = (object)(DBL_PTR(_first_wildcard_at_6022)->dbl);
        DeRefDS(_first_wildcard_at_6022);
        _first_wildcard_at_6022 = _1;
    }

    /** filesys.e:366			if first_wildcard_at = 0 then*/
    if (_first_wildcard_at_6022 != 0LL)
    goto L1; // [23] 38

    /** filesys.e:367				return machine_func(M_DIR, name)*/
    _3140 = machine(22LL, _name_6015);
    DeRefDS(_name_6015);
    DeRef(_dir_data_6016);
    DeRef(_data_6017);
    DeRef(_the_name_6018);
    DeRef(_the_dir_6019);
    return _3140;
L1: 

    /** filesys.e:371			if first_wildcard_at then*/
    if (_first_wildcard_at_6022 == 0)
    {
        goto L2; // [40] 56
    }
    else{
    }

    /** filesys.e:372				idx = search:rfind(SLASH, name, first_wildcard_at )*/
    RefDS(_name_6015);
    _idx_6021 = _16rfind(47LL, _name_6015, _first_wildcard_at_6022);
    if (!IS_ATOM_INT(_idx_6021)) {
        _1 = (object)(DBL_PTR(_idx_6021)->dbl);
        DeRefDS(_idx_6021);
        _idx_6021 = _1;
    }
    goto L3; // [53] 70
L2: 

    /** filesys.e:374				idx = search:rfind(SLASH, name )*/
    if (IS_SEQUENCE(_name_6015)){
            _3142 = SEQ_PTR(_name_6015)->length;
    }
    else {
        _3142 = 1;
    }
    RefDS(_name_6015);
    _idx_6021 = _16rfind(47LL, _name_6015, _3142);
    _3142 = NOVALUE;
    if (!IS_ATOM_INT(_idx_6021)) {
        _1 = (object)(DBL_PTR(_idx_6021)->dbl);
        DeRefDS(_idx_6021);
        _idx_6021 = _1;
    }
L3: 

    /** filesys.e:377			if idx = 0 then*/
    if (_idx_6021 != 0LL)
    goto L4; // [74] 91

    /** filesys.e:378				the_dir = "."*/
    RefDS(_3145);
    DeRef(_the_dir_6019);
    _the_dir_6019 = _3145;

    /** filesys.e:379				the_name = name*/
    RefDS(_name_6015);
    DeRef(_the_name_6018);
    _the_name_6018 = _name_6015;
    goto L5; // [88] 187
L4: 

    /** filesys.e:383				the_dir = name[1 .. idx]*/
    rhs_slice_target = (object_ptr)&_the_dir_6019;
    RHS_Slice(_name_6015, 1LL, _idx_6021);

    /** filesys.e:384				integer next_slash = 0*/
    _next_slash_6037 = 0LL;

    /** filesys.e:385				if first_wildcard_at then*/
    if (_first_wildcard_at_6022 == 0)
    {
        goto L6; // [105] 116
    }
    else{
    }

    /** filesys.e:386					next_slash = eu:find( SLASH, name, first_wildcard_at )*/
    _next_slash_6037 = find_from(47LL, _name_6015, _first_wildcard_at_6022);
L6: 

    /** filesys.e:389				if next_slash then*/
    if (_next_slash_6037 == 0)
    {
        goto L7; // [118] 164
    }
    else{
    }

    /** filesys.e:390					first_wildcard_at = find_first_wildcard( name, next_slash )*/
    RefDS(_name_6015);
    _first_wildcard_at_6022 = _17find_first_wildcard(_name_6015, _next_slash_6037);
    if (!IS_ATOM_INT(_first_wildcard_at_6022)) {
        _1 = (object)(DBL_PTR(_first_wildcard_at_6022)->dbl);
        DeRefDS(_first_wildcard_at_6022);
        _first_wildcard_at_6022 = _1;
    }

    /** filesys.e:391					if first_wildcard_at then*/
    if (_first_wildcard_at_6022 == 0)
    {
        goto L8; // [132] 184
    }
    else{
    }

    /** filesys.e:392						the_name = name[idx+1..next_slash-1]*/
    _3149 = _idx_6021 + 1;
    if (_3149 > MAXINT){
        _3149 = NewDouble((eudouble)_3149);
    }
    _3150 = _next_slash_6037 - 1LL;
    rhs_slice_target = (object_ptr)&_the_name_6018;
    RHS_Slice(_name_6015, _3149, _3150);

    /** filesys.e:393						the_suffix = name[next_slash..$]*/
    if (IS_SEQUENCE(_name_6015)){
            _3152 = SEQ_PTR(_name_6015)->length;
    }
    else {
        _3152 = 1;
    }
    rhs_slice_target = (object_ptr)&_the_suffix_6020;
    RHS_Slice(_name_6015, _next_slash_6037, _3152);
    goto L8; // [161] 184
L7: 

    /** filesys.e:396					the_name = name[idx+1 .. $]*/
    _3154 = _idx_6021 + 1;
    if (_3154 > MAXINT){
        _3154 = NewDouble((eudouble)_3154);
    }
    if (IS_SEQUENCE(_name_6015)){
            _3155 = SEQ_PTR(_name_6015)->length;
    }
    else {
        _3155 = 1;
    }
    rhs_slice_target = (object_ptr)&_the_name_6018;
    RHS_Slice(_name_6015, _3154, _3155);

    /** filesys.e:397					the_suffix = 0*/
    DeRef(_the_suffix_6020);
    _the_suffix_6020 = 0LL;
L8: 
L5: 

    /** filesys.e:403			dir_data = dir( the_dir )*/
    Ref(_the_dir_6019);
    _0 = _dir_data_6016;
    _dir_data_6016 = _17dir(_the_dir_6019);
    DeRef(_0);

    /** filesys.e:406			if atom(dir_data) then*/
    _3158 = IS_ATOM(_dir_data_6016);
    if (_3158 == 0)
    {
        _3158 = NOVALUE;
        goto L9; // [200] 210
    }
    else{
        _3158 = NOVALUE;
    }

    /** filesys.e:407				return dir_data*/
    DeRefDS(_name_6015);
    DeRef(_data_6017);
    DeRef(_the_name_6018);
    DeRef(_the_dir_6019);
    DeRef(_the_suffix_6020);
    DeRef(_3154);
    _3154 = NOVALUE;
    DeRef(_3149);
    _3149 = NOVALUE;
    DeRef(_3150);
    _3150 = NOVALUE;
    DeRef(_3140);
    _3140 = NOVALUE;
    return _dir_data_6016;
L9: 

    /** filesys.e:412			data = {}*/
    RefDS(_5);
    DeRef(_data_6017);
    _data_6017 = _5;

    /** filesys.e:413			for i = 1 to length(dir_data) do*/
    if (IS_SEQUENCE(_dir_data_6016)){
            _3159 = SEQ_PTR(_dir_data_6016)->length;
    }
    else {
        _3159 = 1;
    }
    {
        object _i_6056;
        _i_6056 = 1LL;
LA: 
        if (_i_6056 > _3159){
            goto LB; // [220] 265
        }

        /** filesys.e:414				if wildcard:is_match(the_name, dir_data[i][1]) then*/
        _2 = (object)SEQ_PTR(_dir_data_6016);
        _3160 = (object)*(((s1_ptr)_2)->base + _i_6056);
        _2 = (object)SEQ_PTR(_3160);
        _3161 = (object)*(((s1_ptr)_2)->base + 1LL);
        _3160 = NOVALUE;
        Ref(_the_name_6018);
        Ref(_3161);
        _3162 = _25is_match(_the_name_6018, _3161);
        _3161 = NOVALUE;
        if (_3162 == 0) {
            DeRef(_3162);
            _3162 = NOVALUE;
            goto LC; // [244] 258
        }
        else {
            if (!IS_ATOM_INT(_3162) && DBL_PTR(_3162)->dbl == 0.0){
                DeRef(_3162);
                _3162 = NOVALUE;
                goto LC; // [244] 258
            }
            DeRef(_3162);
            _3162 = NOVALUE;
        }
        DeRef(_3162);
        _3162 = NOVALUE;

        /** filesys.e:415						data = append(data, dir_data[i])*/
        _2 = (object)SEQ_PTR(_dir_data_6016);
        _3163 = (object)*(((s1_ptr)_2)->base + _i_6056);
        Ref(_3163);
        Append(&_data_6017, _data_6017, _3163);
        _3163 = NOVALUE;
LC: 

        /** filesys.e:417			end for*/
        _i_6056 = _i_6056 + 1LL;
        goto LA; // [260] 227
LB: 
        ;
    }

    /** filesys.e:419			if not length(data) then*/
    if (IS_SEQUENCE(_data_6017)){
            _3165 = SEQ_PTR(_data_6017)->length;
    }
    else {
        _3165 = 1;
    }
    if (_3165 != 0)
    goto LD; // [270] 280
    _3165 = NOVALUE;

    /** filesys.e:421				return -1*/
    DeRefDS(_name_6015);
    DeRef(_dir_data_6016);
    DeRef(_data_6017);
    DeRef(_the_name_6018);
    DeRef(_the_dir_6019);
    DeRef(_the_suffix_6020);
    DeRef(_3154);
    _3154 = NOVALUE;
    DeRef(_3149);
    _3149 = NOVALUE;
    DeRef(_3150);
    _3150 = NOVALUE;
    DeRef(_3140);
    _3140 = NOVALUE;
    return -1LL;
LD: 

    /** filesys.e:424			if sequence( the_suffix ) then*/
    _3167 = IS_SEQUENCE(_the_suffix_6020);
    if (_3167 == 0)
    {
        _3167 = NOVALUE;
        goto LE; // [285] 406
    }
    else{
        _3167 = NOVALUE;
    }

    /** filesys.e:425				sequence wild_data = {}*/
    RefDS(_5);
    DeRef(_wild_data_6069);
    _wild_data_6069 = _5;

    /** filesys.e:426				for i = 1 to length( dir_data ) do*/
    if (IS_SEQUENCE(_dir_data_6016)){
            _3168 = SEQ_PTR(_dir_data_6016)->length;
    }
    else {
        _3168 = 1;
    }
    {
        object _i_6071;
        _i_6071 = 1LL;
LF: 
        if (_i_6071 > _3168){
            goto L10; // [300] 399
        }

        /** filesys.e:427					sequence interim_dir = the_dir & dir_data[i][D_NAME] & SLASH*/
        _2 = (object)SEQ_PTR(_dir_data_6016);
        _3169 = (object)*(((s1_ptr)_2)->base + _i_6071);
        _2 = (object)SEQ_PTR(_3169);
        _3170 = (object)*(((s1_ptr)_2)->base + 1LL);
        _3169 = NOVALUE;
        {
            object concat_list[3];

            concat_list[0] = 47LL;
            concat_list[1] = _3170;
            concat_list[2] = _the_dir_6019;
            Concat_N((object_ptr)&_interim_dir_6073, concat_list, 3);
        }
        _3170 = NOVALUE;

        /** filesys.e:428					object dir_results = dir( interim_dir & the_suffix )*/
        if (IS_SEQUENCE(_interim_dir_6073) && IS_ATOM(_the_suffix_6020)) {
            Ref(_the_suffix_6020);
            Append(&_3172, _interim_dir_6073, _the_suffix_6020);
        }
        else if (IS_ATOM(_interim_dir_6073) && IS_SEQUENCE(_the_suffix_6020)) {
        }
        else {
            Concat((object_ptr)&_3172, _interim_dir_6073, _the_suffix_6020);
        }
        _0 = _dir_results_6077;
        _dir_results_6077 = _17dir(_3172);
        DeRef(_0);
        _3172 = NOVALUE;

        /** filesys.e:429					if sequence( dir_results ) then*/
        _3174 = IS_SEQUENCE(_dir_results_6077);
        if (_3174 == 0)
        {
            _3174 = NOVALUE;
            goto L11; // [338] 390
        }
        else{
            _3174 = NOVALUE;
        }

        /** filesys.e:430						for j = 1 to length( dir_results ) do*/
        if (IS_SEQUENCE(_dir_results_6077)){
                _3175 = SEQ_PTR(_dir_results_6077)->length;
        }
        else {
            _3175 = 1;
        }
        {
            object _j_6083;
            _j_6083 = 1LL;
L12: 
            if (_j_6083 > _3175){
                goto L13; // [346] 383
            }

            /** filesys.e:431							dir_results[j][D_NAME] = interim_dir & dir_results[j][D_NAME]*/
            _2 = (object)SEQ_PTR(_dir_results_6077);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _dir_results_6077 = MAKE_SEQ(_2);
            }
            _3 = (object)(_j_6083 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(_dir_results_6077);
            _3178 = (object)*(((s1_ptr)_2)->base + _j_6083);
            _2 = (object)SEQ_PTR(_3178);
            _3179 = (object)*(((s1_ptr)_2)->base + 1LL);
            _3178 = NOVALUE;
            if (IS_SEQUENCE(_interim_dir_6073) && IS_ATOM(_3179)) {
                Ref(_3179);
                Append(&_3180, _interim_dir_6073, _3179);
            }
            else if (IS_ATOM(_interim_dir_6073) && IS_SEQUENCE(_3179)) {
            }
            else {
                Concat((object_ptr)&_3180, _interim_dir_6073, _3179);
            }
            _3179 = NOVALUE;
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 1LL);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _3180;
            if( _1 != _3180 ){
                DeRef(_1);
            }
            _3180 = NOVALUE;
            _3176 = NOVALUE;

            /** filesys.e:432						end for*/
            _j_6083 = _j_6083 + 1LL;
            goto L12; // [378] 353
L13: 
            ;
        }

        /** filesys.e:433						wild_data &= dir_results*/
        if (IS_SEQUENCE(_wild_data_6069) && IS_ATOM(_dir_results_6077)) {
            Ref(_dir_results_6077);
            Append(&_wild_data_6069, _wild_data_6069, _dir_results_6077);
        }
        else if (IS_ATOM(_wild_data_6069) && IS_SEQUENCE(_dir_results_6077)) {
        }
        else {
            Concat((object_ptr)&_wild_data_6069, _wild_data_6069, _dir_results_6077);
        }
L11: 
        DeRef(_interim_dir_6073);
        _interim_dir_6073 = NOVALUE;
        DeRef(_dir_results_6077);
        _dir_results_6077 = NOVALUE;

        /** filesys.e:435				end for*/
        _i_6071 = _i_6071 + 1LL;
        goto LF; // [394] 307
L10: 
        ;
    }

    /** filesys.e:436				return wild_data*/
    DeRefDS(_name_6015);
    DeRef(_dir_data_6016);
    DeRef(_data_6017);
    DeRef(_the_name_6018);
    DeRef(_the_dir_6019);
    DeRef(_the_suffix_6020);
    DeRef(_3154);
    _3154 = NOVALUE;
    DeRef(_3149);
    _3149 = NOVALUE;
    DeRef(_3150);
    _3150 = NOVALUE;
    DeRef(_3140);
    _3140 = NOVALUE;
    return _wild_data_6069;
LE: 
    DeRef(_wild_data_6069);
    _wild_data_6069 = NOVALUE;

    /** filesys.e:439			return data*/
    DeRefDS(_name_6015);
    DeRef(_dir_data_6016);
    DeRef(_the_name_6018);
    DeRef(_the_dir_6019);
    DeRef(_the_suffix_6020);
    DeRef(_3154);
    _3154 = NOVALUE;
    DeRef(_3149);
    _3149 = NOVALUE;
    DeRef(_3150);
    _3150 = NOVALUE;
    DeRef(_3140);
    _3140 = NOVALUE;
    return _data_6017;
    ;
}


object _17current_dir()
{
    object _3182 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:465		return machine_func(M_CURRENT_DIR, 0)*/
    _3182 = machine(23LL, 0LL);
    return _3182;
    ;
}


object _17chdir(object _newdir_6096)
{
    object _3183 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:501		return machine_func(M_CHDIR, newdir)*/
    _3183 = machine(63LL, _newdir_6096);
    DeRefDS(_newdir_6096);
    return _3183;
    ;
}


object _17create_directory(object _name_6187, object _mode_6188, object _mkparent_6190)
{
    object _pname_6191 = NOVALUE;
    object _ret_6192 = NOVALUE;
    object _pos_6193 = NOVALUE;
    object _3255 = NOVALUE;
    object _3254 = NOVALUE;
    object _3251 = NOVALUE;
    object _3250 = NOVALUE;
    object _3249 = NOVALUE;
    object _3248 = NOVALUE;
    object _3245 = NOVALUE;
    object _3242 = NOVALUE;
    object _3241 = NOVALUE;
    object _3239 = NOVALUE;
    object _3238 = NOVALUE;
    object _3236 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:731		if length(name) = 0 then*/
    if (IS_SEQUENCE(_name_6187)){
            _3236 = SEQ_PTR(_name_6187)->length;
    }
    else {
        _3236 = 1;
    }
    if (_3236 != 0LL)
    goto L1; // [12] 23

    /** filesys.e:732			return 0 -- failed*/
    DeRefDS(_name_6187);
    DeRef(_pname_6191);
    DeRef(_ret_6192);
    return 0LL;
L1: 

    /** filesys.e:736		if name[$] = SLASH then*/
    if (IS_SEQUENCE(_name_6187)){
            _3238 = SEQ_PTR(_name_6187)->length;
    }
    else {
        _3238 = 1;
    }
    _2 = (object)SEQ_PTR(_name_6187);
    _3239 = (object)*(((s1_ptr)_2)->base + _3238);
    if (binary_op_a(NOTEQ, _3239, 47LL)){
        _3239 = NOVALUE;
        goto L2; // [32] 51
    }
    _3239 = NOVALUE;

    /** filesys.e:737			name = name[1 .. $-1]*/
    if (IS_SEQUENCE(_name_6187)){
            _3241 = SEQ_PTR(_name_6187)->length;
    }
    else {
        _3241 = 1;
    }
    _3242 = _3241 - 1LL;
    _3241 = NOVALUE;
    rhs_slice_target = (object_ptr)&_name_6187;
    RHS_Slice(_name_6187, 1LL, _3242);
L2: 

    /** filesys.e:740		if mkparent != 0 then*/
    if (_mkparent_6190 == 0LL)
    goto L3; // [53] 101

    /** filesys.e:741			pos = search:rfind(SLASH, name)*/
    if (IS_SEQUENCE(_name_6187)){
            _3245 = SEQ_PTR(_name_6187)->length;
    }
    else {
        _3245 = 1;
    }
    RefDS(_name_6187);
    _pos_6193 = _16rfind(47LL, _name_6187, _3245);
    _3245 = NOVALUE;
    if (!IS_ATOM_INT(_pos_6193)) {
        _1 = (object)(DBL_PTR(_pos_6193)->dbl);
        DeRefDS(_pos_6193);
        _pos_6193 = _1;
    }

    /** filesys.e:742			if pos != 0 then*/
    if (_pos_6193 == 0LL)
    goto L4; // [72] 100

    /** filesys.e:743				ret = create_directory(name[1.. pos-1], mode, mkparent)*/
    _3248 = _pos_6193 - 1LL;
    rhs_slice_target = (object_ptr)&_3249;
    RHS_Slice(_name_6187, 1LL, _3248);
    DeRef(_3250);
    _3250 = _mode_6188;
    DeRef(_3251);
    _3251 = _mkparent_6190;
    _0 = _ret_6192;
    _ret_6192 = _17create_directory(_3249, _3250, _3251);
    DeRef(_0);
    _3249 = NOVALUE;
    _3250 = NOVALUE;
    _3251 = NOVALUE;
L4: 
L3: 

    /** filesys.e:747		pname = machine:allocate_string(name)*/
    RefDS(_name_6187);
    _0 = _pname_6191;
    _pname_6191 = _9allocate_string(_name_6187, 0LL);
    DeRef(_0);

    /** filesys.e:749		ifdef UNIX then*/

    /** filesys.e:750			ret = not c_func(xCreateDirectory, {pname, mode})*/
    Ref(_pname_6191);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _pname_6191;
    ((intptr_t *)_2)[2] = _mode_6188;
    _3254 = MAKE_SEQ(_1);
    _3255 = call_c(1, _17xCreateDirectory_5948, _3254);
    DeRefDS(_3254);
    _3254 = NOVALUE;
    DeRef(_ret_6192);
    if (IS_ATOM_INT(_3255)) {
        _ret_6192 = (_3255 == 0);
    }
    else {
        _ret_6192 = unary_op(NOT, _3255);
    }
    DeRef(_3255);
    _3255 = NOVALUE;

    /** filesys.e:756		return ret*/
    DeRefDS(_name_6187);
    DeRef(_pname_6191);
    DeRef(_3242);
    _3242 = NOVALUE;
    DeRef(_3248);
    _3248 = NOVALUE;
    return _ret_6192;
    ;
}


object _17delete_file(object _name_6230)
{
    object _pfilename_6231 = NOVALUE;
    object _success_6233 = NOVALUE;
    object _3261 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:802		atom pfilename = machine:allocate_string(name)*/
    RefDS(_name_6230);
    _0 = _pfilename_6231;
    _pfilename_6231 = _9allocate_string(_name_6230, 0LL);
    DeRef(_0);

    /** filesys.e:803		integer success = c_func(xDeleteFile, {pfilename})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_pfilename_6231);
    ((intptr_t*)_2)[1] = _pfilename_6231;
    _3261 = MAKE_SEQ(_1);
    _success_6233 = call_c(1, _17xDeleteFile_5944, _3261);
    DeRefDS(_3261);
    _3261 = NOVALUE;
    if (!IS_ATOM_INT(_success_6233)) {
        _1 = (object)(DBL_PTR(_success_6233)->dbl);
        DeRefDS(_success_6233);
        _success_6233 = _1;
    }

    /** filesys.e:805		ifdef UNIX then*/

    /** filesys.e:806			success = not success*/
    _success_6233 = (_success_6233 == 0);

    /** filesys.e:809		machine:free(pfilename)*/
    Ref(_pfilename_6231);
    _9free(_pfilename_6231);

    /** filesys.e:811		return success*/
    DeRefDS(_name_6230);
    DeRef(_pfilename_6231);
    return _success_6233;
    ;
}


object _17curdir(object _drive_id_6239)
{
    object _lCurDir_6240 = NOVALUE;
    object _current_dir_inlined_current_dir_at_6_6242 = NOVALUE;
    object _3265 = NOVALUE;
    object _3264 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:847		ifdef not LINUX then*/

    /** filesys.e:862	    lCurDir = current_dir()*/

    /** filesys.e:465		return machine_func(M_CURRENT_DIR, 0)*/
    DeRefi(_lCurDir_6240);
    _lCurDir_6240 = machine(23LL, 0LL);

    /** filesys.e:863		ifdef not LINUX then*/

    /** filesys.e:870		if (lCurDir[$] != SLASH) then*/
    if (IS_SEQUENCE(_lCurDir_6240)){
            _3264 = SEQ_PTR(_lCurDir_6240)->length;
    }
    else {
        _3264 = 1;
    }
    _2 = (object)SEQ_PTR(_lCurDir_6240);
    _3265 = (object)*(((s1_ptr)_2)->base + _3264);
    if (_3265 == 47LL)
    goto L1; // [27] 38

    /** filesys.e:871			lCurDir &= SLASH*/
    Append(&_lCurDir_6240, _lCurDir_6240, 47LL);
L1: 

    /** filesys.e:874		return lCurDir*/
    _3265 = NOVALUE;
    return _lCurDir_6240;
    ;
}


object _17remove_directory(object _dir_name_6311, object _force_6312)
{
    object _pname_6313 = NOVALUE;
    object _ret_6314 = NOVALUE;
    object _files_6315 = NOVALUE;
    object _D_NAME_6316 = NOVALUE;
    object _D_ATTRIBUTES_6317 = NOVALUE;
    object _3339 = NOVALUE;
    object _3335 = NOVALUE;
    object _3334 = NOVALUE;
    object _3333 = NOVALUE;
    object _3331 = NOVALUE;
    object _3330 = NOVALUE;
    object _3329 = NOVALUE;
    object _3328 = NOVALUE;
    object _3327 = NOVALUE;
    object _3326 = NOVALUE;
    object _3325 = NOVALUE;
    object _3324 = NOVALUE;
    object _3323 = NOVALUE;
    object _3322 = NOVALUE;
    object _3321 = NOVALUE;
    object _3320 = NOVALUE;
    object _3317 = NOVALUE;
    object _3316 = NOVALUE;
    object _3313 = NOVALUE;
    object _3311 = NOVALUE;
    object _3310 = NOVALUE;
    object _3308 = NOVALUE;
    object _3307 = NOVALUE;
    object _3305 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1056		integer D_NAME = 1, D_ATTRIBUTES = 2*/
    _D_NAME_6316 = 1LL;
    _D_ATTRIBUTES_6317 = 2LL;

    /** filesys.e:1059	 	if length(dir_name) > 0 then*/
    if (IS_SEQUENCE(_dir_name_6311)){
            _3305 = SEQ_PTR(_dir_name_6311)->length;
    }
    else {
        _3305 = 1;
    }
    if (_3305 <= 0LL)
    goto L1; // [18] 51

    /** filesys.e:1060			if dir_name[$] = SLASH then*/
    if (IS_SEQUENCE(_dir_name_6311)){
            _3307 = SEQ_PTR(_dir_name_6311)->length;
    }
    else {
        _3307 = 1;
    }
    _2 = (object)SEQ_PTR(_dir_name_6311);
    _3308 = (object)*(((s1_ptr)_2)->base + _3307);
    if (binary_op_a(NOTEQ, _3308, 47LL)){
        _3308 = NOVALUE;
        goto L2; // [31] 50
    }
    _3308 = NOVALUE;

    /** filesys.e:1061				dir_name = dir_name[1 .. $-1]*/
    if (IS_SEQUENCE(_dir_name_6311)){
            _3310 = SEQ_PTR(_dir_name_6311)->length;
    }
    else {
        _3310 = 1;
    }
    _3311 = _3310 - 1LL;
    _3310 = NOVALUE;
    rhs_slice_target = (object_ptr)&_dir_name_6311;
    RHS_Slice(_dir_name_6311, 1LL, _3311);
L2: 
L1: 

    /** filesys.e:1065		if length(dir_name) = 0 then*/
    if (IS_SEQUENCE(_dir_name_6311)){
            _3313 = SEQ_PTR(_dir_name_6311)->length;
    }
    else {
        _3313 = 1;
    }
    if (_3313 != 0LL)
    goto L3; // [56] 67

    /** filesys.e:1066			return 0	-- nothing specified to delete.*/
    DeRefDS(_dir_name_6311);
    DeRef(_pname_6313);
    DeRef(_ret_6314);
    DeRef(_files_6315);
    DeRef(_3311);
    _3311 = NOVALUE;
    return 0LL;
L3: 

    /** filesys.e:1070		ifdef WINDOWS then*/

    /** filesys.e:1078		files = dir(dir_name)*/
    RefDS(_dir_name_6311);
    _0 = _files_6315;
    _files_6315 = _17dir(_dir_name_6311);
    DeRef(_0);

    /** filesys.e:1079		if atom(files) then*/
    _3316 = IS_ATOM(_files_6315);
    if (_3316 == 0)
    {
        _3316 = NOVALUE;
        goto L4; // [80] 90
    }
    else{
        _3316 = NOVALUE;
    }

    /** filesys.e:1080			return 0*/
    DeRefDS(_dir_name_6311);
    DeRef(_pname_6313);
    DeRef(_ret_6314);
    DeRef(_files_6315);
    DeRef(_3311);
    _3311 = NOVALUE;
    return 0LL;
L4: 

    /** filesys.e:1082		if length( files ) < 2 then*/
    if (IS_SEQUENCE(_files_6315)){
            _3317 = SEQ_PTR(_files_6315)->length;
    }
    else {
        _3317 = 1;
    }
    if (_3317 >= 2LL)
    goto L5; // [95] 106

    /** filesys.e:1083			return 0	-- Supplied dir_name was not a directory*/
    DeRefDS(_dir_name_6311);
    DeRef(_pname_6313);
    DeRef(_ret_6314);
    DeRef(_files_6315);
    DeRef(_3311);
    _3311 = NOVALUE;
    return 0LL;
L5: 

    /** filesys.e:1085		ifdef WINDOWS then*/

    /** filesys.e:1100		dir_name &= SLASH*/
    Append(&_dir_name_6311, _dir_name_6311, 47LL);

    /** filesys.e:1101		ifdef WINDOWS then*/

    /** filesys.e:1115			for i = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_6315)){
            _3320 = SEQ_PTR(_files_6315)->length;
    }
    else {
        _3320 = 1;
    }
    {
        object _i_6339;
        _i_6339 = 1LL;
L6: 
        if (_i_6339 > _3320){
            goto L7; // [121] 240
        }

        /** filesys.e:1116				if find( files[i][D_NAME], {".",".."}) then*/
        _2 = (object)SEQ_PTR(_files_6315);
        _3321 = (object)*(((s1_ptr)_2)->base + _i_6339);
        _2 = (object)SEQ_PTR(_3321);
        _3322 = (object)*(((s1_ptr)_2)->base + _D_NAME_6316);
        _3321 = NOVALUE;
        RefDS(_3212);
        RefDS(_3145);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _3145;
        ((intptr_t *)_2)[2] = _3212;
        _3323 = MAKE_SEQ(_1);
        _3324 = find_from(_3322, _3323, 1LL);
        _3322 = NOVALUE;
        DeRefDS(_3323);
        _3323 = NOVALUE;
        if (_3324 == 0)
        {
            _3324 = NOVALUE;
            goto L8; // [147] 155
        }
        else{
            _3324 = NOVALUE;
        }

        /** filesys.e:1117					continue*/
        goto L9; // [152] 235
L8: 

        /** filesys.e:1119				if eu:find('d', files[i][D_ATTRIBUTES]) then*/
        _2 = (object)SEQ_PTR(_files_6315);
        _3325 = (object)*(((s1_ptr)_2)->base + _i_6339);
        _2 = (object)SEQ_PTR(_3325);
        _3326 = (object)*(((s1_ptr)_2)->base + _D_ATTRIBUTES_6317);
        _3325 = NOVALUE;
        _3327 = find_from(100LL, _3326, 1LL);
        _3326 = NOVALUE;
        if (_3327 == 0)
        {
            _3327 = NOVALUE;
            goto LA; // [170] 200
        }
        else{
            _3327 = NOVALUE;
        }

        /** filesys.e:1120					ret = remove_directory(dir_name & files[i][D_NAME] & SLASH, force)*/
        _2 = (object)SEQ_PTR(_files_6315);
        _3328 = (object)*(((s1_ptr)_2)->base + _i_6339);
        _2 = (object)SEQ_PTR(_3328);
        _3329 = (object)*(((s1_ptr)_2)->base + _D_NAME_6316);
        _3328 = NOVALUE;
        {
            object concat_list[3];

            concat_list[0] = 47LL;
            concat_list[1] = _3329;
            concat_list[2] = _dir_name_6311;
            Concat_N((object_ptr)&_3330, concat_list, 3);
        }
        _3329 = NOVALUE;
        DeRef(_3331);
        _3331 = _force_6312;
        _0 = _ret_6314;
        _ret_6314 = _17remove_directory(_3330, _3331);
        DeRef(_0);
        _3330 = NOVALUE;
        _3331 = NOVALUE;
        goto LB; // [197] 219
LA: 

        /** filesys.e:1122					ret = delete_file(dir_name & files[i][D_NAME])*/
        _2 = (object)SEQ_PTR(_files_6315);
        _3333 = (object)*(((s1_ptr)_2)->base + _i_6339);
        _2 = (object)SEQ_PTR(_3333);
        _3334 = (object)*(((s1_ptr)_2)->base + _D_NAME_6316);
        _3333 = NOVALUE;
        if (IS_SEQUENCE(_dir_name_6311) && IS_ATOM(_3334)) {
            Ref(_3334);
            Append(&_3335, _dir_name_6311, _3334);
        }
        else if (IS_ATOM(_dir_name_6311) && IS_SEQUENCE(_3334)) {
        }
        else {
            Concat((object_ptr)&_3335, _dir_name_6311, _3334);
        }
        _3334 = NOVALUE;
        _0 = _ret_6314;
        _ret_6314 = _17delete_file(_3335);
        DeRef(_0);
        _3335 = NOVALUE;
LB: 

        /** filesys.e:1124				if not ret then*/
        if (IS_ATOM_INT(_ret_6314)) {
            if (_ret_6314 != 0){
                goto LC; // [223] 233
            }
        }
        else {
            if (DBL_PTR(_ret_6314)->dbl != 0.0){
                goto LC; // [223] 233
            }
        }

        /** filesys.e:1125					return 0*/
        DeRefDS(_dir_name_6311);
        DeRef(_pname_6313);
        DeRef(_ret_6314);
        DeRef(_files_6315);
        DeRef(_3311);
        _3311 = NOVALUE;
        return 0LL;
LC: 

        /** filesys.e:1127			end for*/
L9: 
        _i_6339 = _i_6339 + 1LL;
        goto L6; // [235] 128
L7: 
        ;
    }

    /** filesys.e:1129		pname = machine:allocate_string(dir_name)*/
    RefDS(_dir_name_6311);
    _0 = _pname_6313;
    _pname_6313 = _9allocate_string(_dir_name_6311, 0LL);
    DeRef(_0);

    /** filesys.e:1130		ret = c_func(xRemoveDirectory, {pname})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_pname_6313);
    ((intptr_t*)_2)[1] = _pname_6313;
    _3339 = MAKE_SEQ(_1);
    DeRef(_ret_6314);
    _ret_6314 = call_c(1, _17xRemoveDirectory_5952, _3339);
    DeRefDS(_3339);
    _3339 = NOVALUE;

    /** filesys.e:1131		ifdef UNIX then*/

    /** filesys.e:1132				ret = not ret */
    _0 = _ret_6314;
    if (IS_ATOM_INT(_ret_6314)) {
        _ret_6314 = (_ret_6314 == 0);
    }
    else {
        _ret_6314 = unary_op(NOT, _ret_6314);
    }
    DeRef(_0);

    /** filesys.e:1134		machine:free(pname)*/
    Ref(_pname_6313);
    _9free(_pname_6313);

    /** filesys.e:1135		return ret*/
    DeRefDS(_dir_name_6311);
    DeRef(_pname_6313);
    DeRef(_files_6315);
    DeRef(_3311);
    _3311 = NOVALUE;
    return _ret_6314;
    ;
}


object _17pathinfo(object _path_6373, object _std_slash_6374)
{
    object _slash_6375 = NOVALUE;
    object _period_6376 = NOVALUE;
    object _ch_6377 = NOVALUE;
    object _dir_name_6378 = NOVALUE;
    object _file_name_6379 = NOVALUE;
    object _file_ext_6380 = NOVALUE;
    object _file_full_6381 = NOVALUE;
    object _drive_id_6382 = NOVALUE;
    object _from_slash_6414 = NOVALUE;
    object _3367 = NOVALUE;
    object _3360 = NOVALUE;
    object _3359 = NOVALUE;
    object _3356 = NOVALUE;
    object _3355 = NOVALUE;
    object _3353 = NOVALUE;
    object _3352 = NOVALUE;
    object _3349 = NOVALUE;
    object _3347 = NOVALUE;
    object _3346 = NOVALUE;
    object _3345 = NOVALUE;
    object _3344 = NOVALUE;
    object _3342 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1196		dir_name  = ""*/
    RefDS(_5);
    DeRef(_dir_name_6378);
    _dir_name_6378 = _5;

    /** filesys.e:1197		file_name = ""*/
    RefDS(_5);
    DeRef(_file_name_6379);
    _file_name_6379 = _5;

    /** filesys.e:1198		file_ext  = ""*/
    RefDS(_5);
    DeRef(_file_ext_6380);
    _file_ext_6380 = _5;

    /** filesys.e:1199		file_full = ""*/
    RefDS(_5);
    DeRef(_file_full_6381);
    _file_full_6381 = _5;

    /** filesys.e:1200		drive_id  = ""*/
    RefDS(_5);
    DeRef(_drive_id_6382);
    _drive_id_6382 = _5;

    /** filesys.e:1202		slash = 0*/
    _slash_6375 = 0LL;

    /** filesys.e:1203		period = 0*/
    _period_6376 = 0LL;

    /** filesys.e:1205		for i = length(path) to 1 by -1 do*/
    if (IS_SEQUENCE(_path_6373)){
            _3342 = SEQ_PTR(_path_6373)->length;
    }
    else {
        _3342 = 1;
    }
    {
        object _i_6384;
        _i_6384 = _3342;
L1: 
        if (_i_6384 < 1LL){
            goto L2; // [55] 122
        }

        /** filesys.e:1206			ch = path[i]*/
        _2 = (object)SEQ_PTR(_path_6373);
        _ch_6377 = (object)*(((s1_ptr)_2)->base + _i_6384);
        if (!IS_ATOM_INT(_ch_6377))
        _ch_6377 = (object)DBL_PTR(_ch_6377)->dbl;

        /** filesys.e:1207			if period = 0 and ch = '.' then*/
        _3344 = (_period_6376 == 0LL);
        if (_3344 == 0) {
            goto L3; // [74] 94
        }
        _3346 = (_ch_6377 == 46LL);
        if (_3346 == 0)
        {
            DeRef(_3346);
            _3346 = NOVALUE;
            goto L3; // [83] 94
        }
        else{
            DeRef(_3346);
            _3346 = NOVALUE;
        }

        /** filesys.e:1208				period = i*/
        _period_6376 = _i_6384;
        goto L4; // [91] 115
L3: 

        /** filesys.e:1209			elsif eu:find(ch, SLASHES) then*/
        _3347 = find_from(_ch_6377, _17SLASHES_5968, 1LL);
        if (_3347 == 0)
        {
            _3347 = NOVALUE;
            goto L5; // [101] 114
        }
        else{
            _3347 = NOVALUE;
        }

        /** filesys.e:1210				slash = i*/
        _slash_6375 = _i_6384;

        /** filesys.e:1211				exit*/
        goto L2; // [111] 122
L5: 
L4: 

        /** filesys.e:1213		end for*/
        _i_6384 = _i_6384 + -1LL;
        goto L1; // [117] 62
L2: 
        ;
    }

    /** filesys.e:1215		if slash > 0 then*/
    if (_slash_6375 <= 0LL)
    goto L6; // [124] 142

    /** filesys.e:1216			dir_name = path[1..slash-1]*/
    _3349 = _slash_6375 - 1LL;
    rhs_slice_target = (object_ptr)&_dir_name_6378;
    RHS_Slice(_path_6373, 1LL, _3349);

    /** filesys.e:1218			ifdef not UNIX then*/
L6: 

    /** filesys.e:1226		if period > 0 then*/
    if (_period_6376 <= 0LL)
    goto L7; // [144] 188

    /** filesys.e:1227			file_name = path[slash+1..period-1]*/
    _3352 = _slash_6375 + 1;
    if (_3352 > MAXINT){
        _3352 = NewDouble((eudouble)_3352);
    }
    _3353 = _period_6376 - 1LL;
    rhs_slice_target = (object_ptr)&_file_name_6379;
    RHS_Slice(_path_6373, _3352, _3353);

    /** filesys.e:1228			file_ext = path[period+1..$]*/
    _3355 = _period_6376 + 1;
    if (_3355 > MAXINT){
        _3355 = NewDouble((eudouble)_3355);
    }
    if (IS_SEQUENCE(_path_6373)){
            _3356 = SEQ_PTR(_path_6373)->length;
    }
    else {
        _3356 = 1;
    }
    rhs_slice_target = (object_ptr)&_file_ext_6380;
    RHS_Slice(_path_6373, _3355, _3356);

    /** filesys.e:1229			file_full = file_name & '.' & file_ext*/
    {
        object concat_list[3];

        concat_list[0] = _file_ext_6380;
        concat_list[1] = 46LL;
        concat_list[2] = _file_name_6379;
        Concat_N((object_ptr)&_file_full_6381, concat_list, 3);
    }
    goto L8; // [185] 210
L7: 

    /** filesys.e:1231			file_name = path[slash+1..$]*/
    _3359 = _slash_6375 + 1;
    if (_3359 > MAXINT){
        _3359 = NewDouble((eudouble)_3359);
    }
    if (IS_SEQUENCE(_path_6373)){
            _3360 = SEQ_PTR(_path_6373)->length;
    }
    else {
        _3360 = 1;
    }
    rhs_slice_target = (object_ptr)&_file_name_6379;
    RHS_Slice(_path_6373, _3359, _3360);

    /** filesys.e:1232			file_full = file_name*/
    RefDS(_file_name_6379);
    DeRef(_file_full_6381);
    _file_full_6381 = _file_name_6379;
L8: 

    /** filesys.e:1235		if std_slash != 0 then*/
    if (_std_slash_6374 == 0LL)
    goto L9; // [212] 278

    /** filesys.e:1236			if std_slash < 0 then*/
    if (_std_slash_6374 >= 0LL)
    goto LA; // [218] 254

    /** filesys.e:1237				std_slash = SLASH*/
    _std_slash_6374 = 47LL;

    /** filesys.e:1238				ifdef UNIX then*/

    /** filesys.e:1239				sequence from_slash = "\\"*/
    RefDS(_947);
    DeRefi(_from_slash_6414);
    _from_slash_6414 = _947;

    /** filesys.e:1243				dir_name = search:match_replace(from_slash, dir_name, std_slash)*/
    RefDS(_from_slash_6414);
    RefDS(_dir_name_6378);
    _0 = _dir_name_6378;
    _dir_name_6378 = _16match_replace(_from_slash_6414, _dir_name_6378, 47LL, 0LL);
    DeRefDS(_0);
    DeRefDSi(_from_slash_6414);
    _from_slash_6414 = NOVALUE;
    goto LB; // [251] 277
LA: 

    /** filesys.e:1245				dir_name = search:match_replace("\\", dir_name, std_slash)*/
    RefDS(_947);
    RefDS(_dir_name_6378);
    _0 = _dir_name_6378;
    _dir_name_6378 = _16match_replace(_947, _dir_name_6378, _std_slash_6374, 0LL);
    DeRefDS(_0);

    /** filesys.e:1246				dir_name = search:match_replace("/", dir_name, std_slash)*/
    RefDS(_3121);
    RefDS(_dir_name_6378);
    _0 = _dir_name_6378;
    _dir_name_6378 = _16match_replace(_3121, _dir_name_6378, _std_slash_6374, 0LL);
    DeRefDS(_0);
LB: 
L9: 

    /** filesys.e:1250		return {dir_name, file_full, file_name, file_ext, drive_id }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_dir_name_6378);
    ((intptr_t*)_2)[1] = _dir_name_6378;
    RefDS(_file_full_6381);
    ((intptr_t*)_2)[2] = _file_full_6381;
    RefDS(_file_name_6379);
    ((intptr_t*)_2)[3] = _file_name_6379;
    RefDS(_file_ext_6380);
    ((intptr_t*)_2)[4] = _file_ext_6380;
    RefDS(_drive_id_6382);
    ((intptr_t*)_2)[5] = _drive_id_6382;
    _3367 = MAKE_SEQ(_1);
    DeRefDS(_path_6373);
    DeRefDS(_dir_name_6378);
    DeRefDS(_file_name_6379);
    DeRefDS(_file_ext_6380);
    DeRefDS(_file_full_6381);
    DeRefDS(_drive_id_6382);
    DeRef(_3359);
    _3359 = NOVALUE;
    DeRef(_3344);
    _3344 = NOVALUE;
    DeRef(_3352);
    _3352 = NOVALUE;
    DeRef(_3349);
    _3349 = NOVALUE;
    DeRef(_3355);
    _3355 = NOVALUE;
    DeRef(_3353);
    _3353 = NOVALUE;
    return _3367;
    ;
}


object _17dirname(object _path_6422, object _pcd_6423)
{
    object _data_6424 = NOVALUE;
    object _3372 = NOVALUE;
    object _3370 = NOVALUE;
    object _3369 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1279		data = pathinfo(path)*/
    RefDS(_path_6422);
    _0 = _data_6424;
    _data_6424 = _17pathinfo(_path_6422, 0LL);
    DeRef(_0);

    /** filesys.e:1280		if pcd then*/
    if (_pcd_6423 == 0)
    {
        goto L1; // [16] 40
    }
    else{
    }

    /** filesys.e:1281			if length(data[1]) = 0 then*/
    _2 = (object)SEQ_PTR(_data_6424);
    _3369 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_3369)){
            _3370 = SEQ_PTR(_3369)->length;
    }
    else {
        _3370 = 1;
    }
    _3369 = NOVALUE;
    if (_3370 != 0LL)
    goto L2; // [28] 39

    /** filesys.e:1282				return "."*/
    RefDS(_3145);
    DeRefDS(_path_6422);
    DeRefDS(_data_6424);
    _3369 = NOVALUE;
    return _3145;
L2: 
L1: 

    /** filesys.e:1285		return data[1]*/
    _2 = (object)SEQ_PTR(_data_6424);
    _3372 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_3372);
    DeRefDS(_path_6422);
    DeRefDS(_data_6424);
    _3369 = NOVALUE;
    return _3372;
    ;
}


object _17filebase(object _path_6451)
{
    object _data_6452 = NOVALUE;
    object _3381 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1375		data = pathinfo(path)*/
    RefDS(_path_6451);
    _0 = _data_6452;
    _data_6452 = _17pathinfo(_path_6451, 0LL);
    DeRef(_0);

    /** filesys.e:1377		return data[3]*/
    _2 = (object)SEQ_PTR(_data_6452);
    _3381 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_3381);
    DeRefDS(_path_6451);
    DeRefDS(_data_6452);
    return _3381;
    ;
}


object _17fileext(object _path_6457)
{
    object _data_6458 = NOVALUE;
    object _3383 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1403		data = pathinfo(path)*/
    RefDS(_path_6457);
    _0 = _data_6458;
    _data_6458 = _17pathinfo(_path_6457, 0LL);
    DeRef(_0);

    /** filesys.e:1404		return data[4]*/
    _2 = (object)SEQ_PTR(_data_6458);
    _3383 = (object)*(((s1_ptr)_2)->base + 4LL);
    Ref(_3383);
    DeRefDS(_path_6457);
    DeRefDS(_data_6458);
    return _3383;
    ;
}


object _17defaultext(object _path_6469, object _defext_6470)
{
    object _3398 = NOVALUE;
    object _3395 = NOVALUE;
    object _3393 = NOVALUE;
    object _3392 = NOVALUE;
    object _3391 = NOVALUE;
    object _3389 = NOVALUE;
    object _3388 = NOVALUE;
    object _3386 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1455		if length(defext) = 0 then*/
    _3386 = 3;

    /** filesys.e:1459		for i = length(path) to 1 by -1 do*/
    if (IS_SEQUENCE(_path_6469)){
            _3388 = SEQ_PTR(_path_6469)->length;
    }
    else {
        _3388 = 1;
    }
    {
        object _i_6475;
        _i_6475 = _3388;
L1: 
        if (_i_6475 < 1LL){
            goto L2; // [26] 95
        }

        /** filesys.e:1460			if path[i] = '.' then*/
        _2 = (object)SEQ_PTR(_path_6469);
        _3389 = (object)*(((s1_ptr)_2)->base + _i_6475);
        if (binary_op_a(NOTEQ, _3389, 46LL)){
            _3389 = NOVALUE;
            goto L3; // [39] 50
        }
        _3389 = NOVALUE;

        /** filesys.e:1462				return path*/
        DeRefDSi(_defext_6470);
        return _path_6469;
L3: 

        /** filesys.e:1464			if find(path[i], SLASHES) then*/
        _2 = (object)SEQ_PTR(_path_6469);
        _3391 = (object)*(((s1_ptr)_2)->base + _i_6475);
        _3392 = find_from(_3391, _17SLASHES_5968, 1LL);
        _3391 = NOVALUE;
        if (_3392 == 0)
        {
            _3392 = NOVALUE;
            goto L4; // [61] 88
        }
        else{
            _3392 = NOVALUE;
        }

        /** filesys.e:1465				if i = length(path) then*/
        if (IS_SEQUENCE(_path_6469)){
                _3393 = SEQ_PTR(_path_6469)->length;
        }
        else {
            _3393 = 1;
        }
        if (_i_6475 != _3393)
        goto L2; // [69] 95

        /** filesys.e:1467					return path*/
        DeRefDSi(_defext_6470);
        return _path_6469;
        goto L5; // [79] 87

        /** filesys.e:1470					exit*/
        goto L2; // [84] 95
L5: 
L4: 

        /** filesys.e:1473		end for*/
        _i_6475 = _i_6475 + -1LL;
        goto L1; // [90] 33
L2: 
        ;
    }

    /** filesys.e:1475		if defext[1] != '.' then*/
    _2 = (object)SEQ_PTR(_defext_6470);
    _3395 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (_3395 == 46LL)
    goto L6; // [101] 112

    /** filesys.e:1476			path &= '.'*/
    Append(&_path_6469, _path_6469, 46LL);
L6: 

    /** filesys.e:1479		return path & defext*/
    Concat((object_ptr)&_3398, _path_6469, _defext_6470);
    DeRefDS(_path_6469);
    DeRefDSi(_defext_6470);
    _3395 = NOVALUE;
    return _3398;
    ;
}


object _17absolute_path(object _filename_6494)
{
    object _3402 = NOVALUE;
    object _3401 = NOVALUE;
    object _3399 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1514		if length(filename) = 0 then*/
    if (IS_SEQUENCE(_filename_6494)){
            _3399 = SEQ_PTR(_filename_6494)->length;
    }
    else {
        _3399 = 1;
    }
    if (_3399 != 0LL)
    goto L1; // [8] 19

    /** filesys.e:1515			return 0*/
    DeRefDS(_filename_6494);
    return 0LL;
L1: 

    /** filesys.e:1518		if eu:find(filename[1], SLASHES) then*/
    _2 = (object)SEQ_PTR(_filename_6494);
    _3401 = (object)*(((s1_ptr)_2)->base + 1LL);
    _3402 = find_from(_3401, _17SLASHES_5968, 1LL);
    _3401 = NOVALUE;
    if (_3402 == 0)
    {
        _3402 = NOVALUE;
        goto L2; // [30] 40
    }
    else{
        _3402 = NOVALUE;
    }

    /** filesys.e:1519			return 1*/
    DeRefDS(_filename_6494);
    return 1LL;
L2: 

    /** filesys.e:1522		ifdef WINDOWS then*/

    /** filesys.e:1539		return 0*/
    DeRefDS(_filename_6494);
    return 0LL;
    ;
}


object _17canonical_path(object _path_in_6514, object _directory_given_6515, object _case_flags_6516)
{
    object _lPath_6517 = NOVALUE;
    object _lPosA_6518 = NOVALUE;
    object _lPosB_6519 = NOVALUE;
    object _lLevel_6520 = NOVALUE;
    object _lHome_6521 = NOVALUE;
    object _wildcard_suffix_6563 = NOVALUE;
    object _first_wildcard_at_6564 = NOVALUE;
    object _last_slash_6567 = NOVALUE;
    object _sl_6620 = NOVALUE;
    object _short_name_6623 = NOVALUE;
    object _correct_name_6626 = NOVALUE;
    object _lower_name_6629 = NOVALUE;
    object _part_6645 = NOVALUE;
    object _list_6649 = NOVALUE;
    object _supplied_name_6652 = NOVALUE;
    object _read_name_6671 = NOVALUE;
    object _read_name_6696 = NOVALUE;
    object _3582 = NOVALUE;
    object _3580 = NOVALUE;
    object _3579 = NOVALUE;
    object _3578 = NOVALUE;
    object _3577 = NOVALUE;
    object _3576 = NOVALUE;
    object _3574 = NOVALUE;
    object _3573 = NOVALUE;
    object _3572 = NOVALUE;
    object _3571 = NOVALUE;
    object _3570 = NOVALUE;
    object _3569 = NOVALUE;
    object _3568 = NOVALUE;
    object _3567 = NOVALUE;
    object _3565 = NOVALUE;
    object _3564 = NOVALUE;
    object _3563 = NOVALUE;
    object _3562 = NOVALUE;
    object _3561 = NOVALUE;
    object _3560 = NOVALUE;
    object _3559 = NOVALUE;
    object _3558 = NOVALUE;
    object _3557 = NOVALUE;
    object _3555 = NOVALUE;
    object _3554 = NOVALUE;
    object _3553 = NOVALUE;
    object _3552 = NOVALUE;
    object _3551 = NOVALUE;
    object _3550 = NOVALUE;
    object _3549 = NOVALUE;
    object _3548 = NOVALUE;
    object _3547 = NOVALUE;
    object _3546 = NOVALUE;
    object _3545 = NOVALUE;
    object _3544 = NOVALUE;
    object _3543 = NOVALUE;
    object _3542 = NOVALUE;
    object _3541 = NOVALUE;
    object _3539 = NOVALUE;
    object _3538 = NOVALUE;
    object _3537 = NOVALUE;
    object _3536 = NOVALUE;
    object _3535 = NOVALUE;
    object _3533 = NOVALUE;
    object _3532 = NOVALUE;
    object _3531 = NOVALUE;
    object _3530 = NOVALUE;
    object _3529 = NOVALUE;
    object _3528 = NOVALUE;
    object _3527 = NOVALUE;
    object _3526 = NOVALUE;
    object _3525 = NOVALUE;
    object _3524 = NOVALUE;
    object _3523 = NOVALUE;
    object _3522 = NOVALUE;
    object _3521 = NOVALUE;
    object _3519 = NOVALUE;
    object _3518 = NOVALUE;
    object _3516 = NOVALUE;
    object _3515 = NOVALUE;
    object _3514 = NOVALUE;
    object _3513 = NOVALUE;
    object _3512 = NOVALUE;
    object _3510 = NOVALUE;
    object _3509 = NOVALUE;
    object _3508 = NOVALUE;
    object _3507 = NOVALUE;
    object _3506 = NOVALUE;
    object _3504 = NOVALUE;
    object _3502 = NOVALUE;
    object _3501 = NOVALUE;
    object _3499 = NOVALUE;
    object _3498 = NOVALUE;
    object _3496 = NOVALUE;
    object _3495 = NOVALUE;
    object _3494 = NOVALUE;
    object _3492 = NOVALUE;
    object _3491 = NOVALUE;
    object _3489 = NOVALUE;
    object _3487 = NOVALUE;
    object _3485 = NOVALUE;
    object _3478 = NOVALUE;
    object _3475 = NOVALUE;
    object _3474 = NOVALUE;
    object _3473 = NOVALUE;
    object _3472 = NOVALUE;
    object _3466 = NOVALUE;
    object _3462 = NOVALUE;
    object _3461 = NOVALUE;
    object _3460 = NOVALUE;
    object _3459 = NOVALUE;
    object _3458 = NOVALUE;
    object _3456 = NOVALUE;
    object _3455 = NOVALUE;
    object _3454 = NOVALUE;
    object _3452 = NOVALUE;
    object _3451 = NOVALUE;
    object _3450 = NOVALUE;
    object _3449 = NOVALUE;
    object _3447 = NOVALUE;
    object _3445 = NOVALUE;
    object _3441 = NOVALUE;
    object _3440 = NOVALUE;
    object _3438 = NOVALUE;
    object _3437 = NOVALUE;
    object _3436 = NOVALUE;
    object _3435 = NOVALUE;
    object _3434 = NOVALUE;
    object _3433 = NOVALUE;
    object _3432 = NOVALUE;
    object _3429 = NOVALUE;
    object _3428 = NOVALUE;
    object _3423 = NOVALUE;
    object _3422 = NOVALUE;
    object _3421 = NOVALUE;
    object _3420 = NOVALUE;
    object _3419 = NOVALUE;
    object _3417 = NOVALUE;
    object _3416 = NOVALUE;
    object _3415 = NOVALUE;
    object _3414 = NOVALUE;
    object _3413 = NOVALUE;
    object _3412 = NOVALUE;
    object _3411 = NOVALUE;
    object _3410 = NOVALUE;
    object _3409 = NOVALUE;
    object _3408 = NOVALUE;
    object _3407 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1607	    sequence lPath = ""*/
    RefDS(_5);
    DeRef(_lPath_6517);
    _lPath_6517 = _5;

    /** filesys.e:1608	    integer lPosA = -1*/
    _lPosA_6518 = -1LL;

    /** filesys.e:1609	    integer lPosB = -1*/
    _lPosB_6519 = -1LL;

    /** filesys.e:1610	    sequence lLevel = ""*/
    RefDS(_5);
    DeRefi(_lLevel_6520);
    _lLevel_6520 = _5;

    /** filesys.e:1612	    path_in = path_in*/
    RefDS(_path_in_6514);
    DeRefDS(_path_in_6514);
    _path_in_6514 = _path_in_6514;

    /** filesys.e:1614		ifdef UNIX then*/

    /** filesys.e:1615			lPath = path_in*/
    RefDS(_path_in_6514);
    DeRefDS(_lPath_6517);
    _lPath_6517 = _path_in_6514;

    /** filesys.e:1623	    if (length(lPath) > 2 and lPath[1] = '"' and lPath[$] = '"') then*/
    if (IS_SEQUENCE(_lPath_6517)){
            _3407 = SEQ_PTR(_lPath_6517)->length;
    }
    else {
        _3407 = 1;
    }
    _3408 = (_3407 > 2LL);
    _3407 = NOVALUE;
    if (_3408 == 0) {
        _3409 = 0;
        goto L1; // [56] 72
    }
    _2 = (object)SEQ_PTR(_lPath_6517);
    _3410 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_3410)) {
        _3411 = (_3410 == 34LL);
    }
    else {
        _3411 = binary_op(EQUALS, _3410, 34LL);
    }
    _3410 = NOVALUE;
    if (IS_ATOM_INT(_3411))
    _3409 = (_3411 != 0);
    else
    _3409 = DBL_PTR(_3411)->dbl != 0.0;
L1: 
    if (_3409 == 0) {
        DeRef(_3412);
        _3412 = 0;
        goto L2; // [72] 91
    }
    if (IS_SEQUENCE(_lPath_6517)){
            _3413 = SEQ_PTR(_lPath_6517)->length;
    }
    else {
        _3413 = 1;
    }
    _2 = (object)SEQ_PTR(_lPath_6517);
    _3414 = (object)*(((s1_ptr)_2)->base + _3413);
    if (IS_ATOM_INT(_3414)) {
        _3415 = (_3414 == 34LL);
    }
    else {
        _3415 = binary_op(EQUALS, _3414, 34LL);
    }
    _3414 = NOVALUE;
    if (IS_ATOM_INT(_3415))
    _3412 = (_3415 != 0);
    else
    _3412 = DBL_PTR(_3415)->dbl != 0.0;
L2: 
    if (_3412 == 0)
    {
        _3412 = NOVALUE;
        goto L3; // [91] 109
    }
    else{
        _3412 = NOVALUE;
    }

    /** filesys.e:1624	        lPath = lPath[2..$-1]*/
    if (IS_SEQUENCE(_lPath_6517)){
            _3416 = SEQ_PTR(_lPath_6517)->length;
    }
    else {
        _3416 = 1;
    }
    _3417 = _3416 - 1LL;
    _3416 = NOVALUE;
    rhs_slice_target = (object_ptr)&_lPath_6517;
    RHS_Slice(_lPath_6517, 2LL, _3417);
L3: 

    /** filesys.e:1628	    if (length(lPath) > 0 and lPath[1] = '~') then*/
    if (IS_SEQUENCE(_lPath_6517)){
            _3419 = SEQ_PTR(_lPath_6517)->length;
    }
    else {
        _3419 = 1;
    }
    _3420 = (_3419 > 0LL);
    _3419 = NOVALUE;
    if (_3420 == 0) {
        DeRef(_3421);
        _3421 = 0;
        goto L4; // [118] 134
    }
    _2 = (object)SEQ_PTR(_lPath_6517);
    _3422 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_3422)) {
        _3423 = (_3422 == 126LL);
    }
    else {
        _3423 = binary_op(EQUALS, _3422, 126LL);
    }
    _3422 = NOVALUE;
    if (IS_ATOM_INT(_3423))
    _3421 = (_3423 != 0);
    else
    _3421 = DBL_PTR(_3423)->dbl != 0.0;
L4: 
    if (_3421 == 0)
    {
        _3421 = NOVALUE;
        goto L5; // [134] 222
    }
    else{
        _3421 = NOVALUE;
    }

    /** filesys.e:1630			lHome = getenv("HOME")*/
    DeRefi(_lHome_6521);
    _lHome_6521 = EGetEnv(_3424);

    /** filesys.e:1631			ifdef WINDOWS then*/

    /** filesys.e:1637			if lHome[$] != SLASH then*/
    if (IS_SEQUENCE(_lHome_6521)){
            _3428 = SEQ_PTR(_lHome_6521)->length;
    }
    else {
        _3428 = 1;
    }
    _2 = (object)SEQ_PTR(_lHome_6521);
    _3429 = (object)*(((s1_ptr)_2)->base + _3428);
    if (_3429 == 47LL)
    goto L6; // [153] 164

    /** filesys.e:1638				lHome &= SLASH*/
    if (IS_SEQUENCE(_lHome_6521) && IS_ATOM(47LL)) {
        Append(&_lHome_6521, _lHome_6521, 47LL);
    }
    else if (IS_ATOM(_lHome_6521) && IS_SEQUENCE(47LL)) {
    }
    else {
        Concat((object_ptr)&_lHome_6521, _lHome_6521, 47LL);
    }
L6: 

    /** filesys.e:1641			if length(lPath) > 1 and lPath[2] = SLASH then*/
    if (IS_SEQUENCE(_lPath_6517)){
            _3432 = SEQ_PTR(_lPath_6517)->length;
    }
    else {
        _3432 = 1;
    }
    _3433 = (_3432 > 1LL);
    _3432 = NOVALUE;
    if (_3433 == 0) {
        goto L7; // [173] 206
    }
    _2 = (object)SEQ_PTR(_lPath_6517);
    _3435 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_3435)) {
        _3436 = (_3435 == 47LL);
    }
    else {
        _3436 = binary_op(EQUALS, _3435, 47LL);
    }
    _3435 = NOVALUE;
    if (_3436 == 0) {
        DeRef(_3436);
        _3436 = NOVALUE;
        goto L7; // [186] 206
    }
    else {
        if (!IS_ATOM_INT(_3436) && DBL_PTR(_3436)->dbl == 0.0){
            DeRef(_3436);
            _3436 = NOVALUE;
            goto L7; // [186] 206
        }
        DeRef(_3436);
        _3436 = NOVALUE;
    }
    DeRef(_3436);
    _3436 = NOVALUE;

    /** filesys.e:1642				lPath = lHome & lPath[3 .. $]*/
    if (IS_SEQUENCE(_lPath_6517)){
            _3437 = SEQ_PTR(_lPath_6517)->length;
    }
    else {
        _3437 = 1;
    }
    rhs_slice_target = (object_ptr)&_3438;
    RHS_Slice(_lPath_6517, 3LL, _3437);
    if (IS_SEQUENCE(_lHome_6521) && IS_ATOM(_3438)) {
    }
    else if (IS_ATOM(_lHome_6521) && IS_SEQUENCE(_3438)) {
        Ref(_lHome_6521);
        Prepend(&_lPath_6517, _3438, _lHome_6521);
    }
    else {
        Concat((object_ptr)&_lPath_6517, _lHome_6521, _3438);
    }
    DeRefDS(_3438);
    _3438 = NOVALUE;
    goto L8; // [203] 221
L7: 

    /** filesys.e:1644				lPath = lHome & lPath[2 .. $]*/
    if (IS_SEQUENCE(_lPath_6517)){
            _3440 = SEQ_PTR(_lPath_6517)->length;
    }
    else {
        _3440 = 1;
    }
    rhs_slice_target = (object_ptr)&_3441;
    RHS_Slice(_lPath_6517, 2LL, _3440);
    if (IS_SEQUENCE(_lHome_6521) && IS_ATOM(_3441)) {
    }
    else if (IS_ATOM(_lHome_6521) && IS_SEQUENCE(_3441)) {
        Ref(_lHome_6521);
        Prepend(&_lPath_6517, _3441, _lHome_6521);
    }
    else {
        Concat((object_ptr)&_lPath_6517, _lHome_6521, _3441);
    }
    DeRefDS(_3441);
    _3441 = NOVALUE;
L8: 
L5: 

    /** filesys.e:1648		ifdef WINDOWS then*/

    /** filesys.e:1658		sequence wildcard_suffix*/

    /** filesys.e:1659		integer first_wildcard_at = find_first_wildcard( lPath )*/
    RefDS(_lPath_6517);
    _first_wildcard_at_6564 = _17find_first_wildcard(_lPath_6517, 1LL);
    if (!IS_ATOM_INT(_first_wildcard_at_6564)) {
        _1 = (object)(DBL_PTR(_first_wildcard_at_6564)->dbl);
        DeRefDS(_first_wildcard_at_6564);
        _first_wildcard_at_6564 = _1;
    }

    /** filesys.e:1660		if first_wildcard_at then*/
    if (_first_wildcard_at_6564 == 0)
    {
        goto L9; // [237] 298
    }
    else{
    }

    /** filesys.e:1661			integer last_slash = search:rfind( SLASH, lPath, first_wildcard_at )*/
    RefDS(_lPath_6517);
    _last_slash_6567 = _16rfind(47LL, _lPath_6517, _first_wildcard_at_6564);
    if (!IS_ATOM_INT(_last_slash_6567)) {
        _1 = (object)(DBL_PTR(_last_slash_6567)->dbl);
        DeRefDS(_last_slash_6567);
        _last_slash_6567 = _1;
    }

    /** filesys.e:1662			if last_slash then*/
    if (_last_slash_6567 == 0)
    {
        goto LA; // [252] 278
    }
    else{
    }

    /** filesys.e:1663				wildcard_suffix = lPath[last_slash..$]*/
    if (IS_SEQUENCE(_lPath_6517)){
            _3445 = SEQ_PTR(_lPath_6517)->length;
    }
    else {
        _3445 = 1;
    }
    rhs_slice_target = (object_ptr)&_wildcard_suffix_6563;
    RHS_Slice(_lPath_6517, _last_slash_6567, _3445);

    /** filesys.e:1664				lPath = remove( lPath, last_slash, length( lPath ) )*/
    if (IS_SEQUENCE(_lPath_6517)){
            _3447 = SEQ_PTR(_lPath_6517)->length;
    }
    else {
        _3447 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_lPath_6517);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_last_slash_6567)) ? _last_slash_6567 : (object)(DBL_PTR(_last_slash_6567)->dbl);
        int stop = (IS_ATOM_INT(_3447)) ? _3447 : (object)(DBL_PTR(_3447)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_lPath_6517), start, &_lPath_6517 );
            }
            else Tail(SEQ_PTR(_lPath_6517), stop+1, &_lPath_6517);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_lPath_6517), start, &_lPath_6517);
        }
        else {
            assign_slice_seq = &assign_space;
            _lPath_6517 = Remove_elements(start, stop, (SEQ_PTR(_lPath_6517)->ref == 1));
        }
    }
    _3447 = NOVALUE;
    goto LB; // [275] 293
LA: 

    /** filesys.e:1666				wildcard_suffix = lPath*/
    RefDS(_lPath_6517);
    DeRef(_wildcard_suffix_6563);
    _wildcard_suffix_6563 = _lPath_6517;

    /** filesys.e:1667				lPath = ""*/
    RefDS(_5);
    DeRefDS(_lPath_6517);
    _lPath_6517 = _5;
LB: 
    goto LC; // [295] 306
L9: 

    /** filesys.e:1670			wildcard_suffix = ""*/
    RefDS(_5);
    DeRef(_wildcard_suffix_6563);
    _wildcard_suffix_6563 = _5;
LC: 

    /** filesys.e:1674		if ((length(lPath) = 0) or not find(lPath[1], "/\\")) then*/
    if (IS_SEQUENCE(_lPath_6517)){
            _3449 = SEQ_PTR(_lPath_6517)->length;
    }
    else {
        _3449 = 1;
    }
    _3450 = (_3449 == 0LL);
    _3449 = NOVALUE;
    if (_3450 != 0) {
        DeRef(_3451);
        _3451 = 1;
        goto LD; // [315] 335
    }
    _2 = (object)SEQ_PTR(_lPath_6517);
    _3452 = (object)*(((s1_ptr)_2)->base + 1LL);
    _3454 = find_from(_3452, _3453, 1LL);
    _3452 = NOVALUE;
    _3455 = (_3454 == 0);
    _3454 = NOVALUE;
    _3451 = (_3455 != 0);
LD: 
    if (_3451 == 0)
    {
        _3451 = NOVALUE;
        goto LE; // [335] 351
    }
    else{
        _3451 = NOVALUE;
    }

    /** filesys.e:1675			ifdef UNIX then*/

    /** filesys.e:1676				lPath = curdir() & lPath*/
    _3456 = _17curdir(0LL);
    if (IS_SEQUENCE(_3456) && IS_ATOM(_lPath_6517)) {
    }
    else if (IS_ATOM(_3456) && IS_SEQUENCE(_lPath_6517)) {
        Ref(_3456);
        Prepend(&_lPath_6517, _lPath_6517, _3456);
    }
    else {
        Concat((object_ptr)&_lPath_6517, _3456, _lPath_6517);
        DeRef(_3456);
        _3456 = NOVALUE;
    }
    DeRef(_3456);
    _3456 = NOVALUE;
LE: 

    /** filesys.e:1694		if ((directory_given != 0) and (lPath[$] != SLASH) ) then*/
    _3458 = (_directory_given_6515 != 0LL);
    if (_3458 == 0) {
        DeRef(_3459);
        _3459 = 0;
        goto LF; // [357] 376
    }
    if (IS_SEQUENCE(_lPath_6517)){
            _3460 = SEQ_PTR(_lPath_6517)->length;
    }
    else {
        _3460 = 1;
    }
    _2 = (object)SEQ_PTR(_lPath_6517);
    _3461 = (object)*(((s1_ptr)_2)->base + _3460);
    if (IS_ATOM_INT(_3461)) {
        _3462 = (_3461 != 47LL);
    }
    else {
        _3462 = binary_op(NOTEQ, _3461, 47LL);
    }
    _3461 = NOVALUE;
    if (IS_ATOM_INT(_3462))
    _3459 = (_3462 != 0);
    else
    _3459 = DBL_PTR(_3462)->dbl != 0.0;
LF: 
    if (_3459 == 0)
    {
        _3459 = NOVALUE;
        goto L10; // [376] 386
    }
    else{
        _3459 = NOVALUE;
    }

    /** filesys.e:1695			lPath &= SLASH*/
    Append(&_lPath_6517, _lPath_6517, 47LL);
L10: 

    /** filesys.e:1699		lLevel = SLASH & '.' & SLASH*/
    {
        object concat_list[3];

        concat_list[0] = 47LL;
        concat_list[1] = 46LL;
        concat_list[2] = 47LL;
        Concat_N((object_ptr)&_lLevel_6520, concat_list, 3);
    }

    /** filesys.e:1700		lPosA = 1*/
    _lPosA_6518 = 1LL;

    /** filesys.e:1701		while( lPosA != 0 ) with entry do*/
    goto L11; // [401] 422
L12: 
    if (_lPosA_6518 == 0LL)
    goto L13; // [404] 434

    /** filesys.e:1702			lPath = eu:remove(lPath, lPosA, lPosA + 1)*/
    _3466 = _lPosA_6518 + 1;
    if (_3466 > MAXINT){
        _3466 = NewDouble((eudouble)_3466);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_lPath_6517);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_lPosA_6518)) ? _lPosA_6518 : (object)(DBL_PTR(_lPosA_6518)->dbl);
        int stop = (IS_ATOM_INT(_3466)) ? _3466 : (object)(DBL_PTR(_3466)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_lPath_6517), start, &_lPath_6517 );
            }
            else Tail(SEQ_PTR(_lPath_6517), stop+1, &_lPath_6517);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_lPath_6517), start, &_lPath_6517);
        }
        else {
            assign_slice_seq = &assign_space;
            _lPath_6517 = Remove_elements(start, stop, (SEQ_PTR(_lPath_6517)->ref == 1));
        }
    }
    DeRef(_3466);
    _3466 = NOVALUE;

    /** filesys.e:1704		  entry*/
L11: 

    /** filesys.e:1705			lPosA = match(lLevel, lPath, lPosA )*/
    _lPosA_6518 = e_match_from(_lLevel_6520, _lPath_6517, _lPosA_6518);

    /** filesys.e:1706		end while*/
    goto L12; // [431] 404
L13: 

    /** filesys.e:1709		lLevel = SLASH & ".." & SLASH*/
    {
        object concat_list[3];

        concat_list[0] = 47LL;
        concat_list[1] = _3212;
        concat_list[2] = 47LL;
        Concat_N((object_ptr)&_lLevel_6520, concat_list, 3);
    }

    /** filesys.e:1711		lPosB = 1*/
    _lPosB_6519 = 1LL;

    /** filesys.e:1712		while( lPosA != 0 ) with entry do*/
    goto L14; // [449] 527
L15: 
    if (_lPosA_6518 == 0LL)
    goto L16; // [452] 539

    /** filesys.e:1714			lPosB = lPosA-1*/
    _lPosB_6519 = _lPosA_6518 - 1LL;

    /** filesys.e:1715			while((lPosB > 0) and (lPath[lPosB] != SLASH)) do*/
L17: 
    _3472 = (_lPosB_6519 > 0LL);
    if (_3472 == 0) {
        DeRef(_3473);
        _3473 = 0;
        goto L18; // [471] 487
    }
    _2 = (object)SEQ_PTR(_lPath_6517);
    _3474 = (object)*(((s1_ptr)_2)->base + _lPosB_6519);
    if (IS_ATOM_INT(_3474)) {
        _3475 = (_3474 != 47LL);
    }
    else {
        _3475 = binary_op(NOTEQ, _3474, 47LL);
    }
    _3474 = NOVALUE;
    if (IS_ATOM_INT(_3475))
    _3473 = (_3475 != 0);
    else
    _3473 = DBL_PTR(_3475)->dbl != 0.0;
L18: 
    if (_3473 == 0)
    {
        _3473 = NOVALUE;
        goto L19; // [487] 501
    }
    else{
        _3473 = NOVALUE;
    }

    /** filesys.e:1716				lPosB -= 1*/
    _lPosB_6519 = _lPosB_6519 - 1LL;

    /** filesys.e:1717			end while*/
    goto L17; // [498] 467
L19: 

    /** filesys.e:1718			if (lPosB <= 0) then*/
    if (_lPosB_6519 > 0LL)
    goto L1A; // [503] 513

    /** filesys.e:1719				lPosB = 1*/
    _lPosB_6519 = 1LL;
L1A: 

    /** filesys.e:1721			lPath = eu:remove(lPath, lPosB, lPosA + 2)*/
    _3478 = _lPosA_6518 + 2LL;
    if ((object)((uintptr_t)_3478 + (uintptr_t)HIGH_BITS) >= 0){
        _3478 = NewDouble((eudouble)_3478);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_lPath_6517);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_lPosB_6519)) ? _lPosB_6519 : (object)(DBL_PTR(_lPosB_6519)->dbl);
        int stop = (IS_ATOM_INT(_3478)) ? _3478 : (object)(DBL_PTR(_3478)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_lPath_6517), start, &_lPath_6517 );
            }
            else Tail(SEQ_PTR(_lPath_6517), stop+1, &_lPath_6517);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_lPath_6517), start, &_lPath_6517);
        }
        else {
            assign_slice_seq = &assign_space;
            _lPath_6517 = Remove_elements(start, stop, (SEQ_PTR(_lPath_6517)->ref == 1));
        }
    }
    DeRef(_3478);
    _3478 = NOVALUE;

    /** filesys.e:1723		  entry*/
L14: 

    /** filesys.e:1724			lPosA = match(lLevel, lPath, lPosB )*/
    _lPosA_6518 = e_match_from(_lLevel_6520, _lPath_6517, _lPosB_6519);

    /** filesys.e:1725		end while*/
    goto L15; // [536] 452
L16: 

    /** filesys.e:1727		if case_flags = TO_LOWER then*/
    if (_case_flags_6516 != 1LL)
    goto L1B; // [541] 556

    /** filesys.e:1728			lPath = lower( lPath )*/
    RefDS(_lPath_6517);
    _0 = _lPath_6517;
    _lPath_6517 = _14lower(_lPath_6517);
    DeRefDS(_0);
    goto L1C; // [553] 1153
L1B: 

    /** filesys.e:1730		elsif case_flags != AS_IS then*/
    if (_case_flags_6516 == 0LL)
    goto L1D; // [558] 1150

    /** filesys.e:1731			sequence sl = find_all(SLASH,lPath) -- split apart lPath*/
    RefDS(_lPath_6517);
    _0 = _sl_6620;
    _sl_6620 = _16find_all(47LL, _lPath_6517, 1LL);
    DeRef(_0);

    /** filesys.e:1732			integer short_name = and_bits(TO_SHORT,case_flags)=TO_SHORT*/
    {uintptr_t tu;
         tu = (uintptr_t)4LL & (uintptr_t)_case_flags_6516;
         _3485 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_3485)) {
        _short_name_6623 = (_3485 == 4LL);
    }
    else {
        _short_name_6623 = (DBL_PTR(_3485)->dbl == (eudouble)4LL);
    }
    DeRef(_3485);
    _3485 = NOVALUE;

    /** filesys.e:1733			integer correct_name = and_bits(case_flags,CORRECT)=CORRECT*/
    {uintptr_t tu;
         tu = (uintptr_t)_case_flags_6516 & (uintptr_t)2LL;
         _3487 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_3487)) {
        _correct_name_6626 = (_3487 == 2LL);
    }
    else {
        _correct_name_6626 = (DBL_PTR(_3487)->dbl == (eudouble)2LL);
    }
    DeRef(_3487);
    _3487 = NOVALUE;

    /** filesys.e:1734			integer lower_name = and_bits(TO_LOWER,case_flags)=TO_LOWER*/
    {uintptr_t tu;
         tu = (uintptr_t)1LL & (uintptr_t)_case_flags_6516;
         _3489 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_3489)) {
        _lower_name_6629 = (_3489 == 1LL);
    }
    else {
        _lower_name_6629 = (DBL_PTR(_3489)->dbl == (eudouble)1LL);
    }
    DeRef(_3489);
    _3489 = NOVALUE;

    /** filesys.e:1735			if lPath[$] != SLASH then*/
    if (IS_SEQUENCE(_lPath_6517)){
            _3491 = SEQ_PTR(_lPath_6517)->length;
    }
    else {
        _3491 = 1;
    }
    _2 = (object)SEQ_PTR(_lPath_6517);
    _3492 = (object)*(((s1_ptr)_2)->base + _3491);
    if (binary_op_a(EQUALS, _3492, 47LL)){
        _3492 = NOVALUE;
        goto L1E; // [611] 633
    }
    _3492 = NOVALUE;

    /** filesys.e:1736				sl = sl & {length(lPath)+1}*/
    if (IS_SEQUENCE(_lPath_6517)){
            _3494 = SEQ_PTR(_lPath_6517)->length;
    }
    else {
        _3494 = 1;
    }
    _3495 = _3494 + 1;
    _3494 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _3495;
    _3496 = MAKE_SEQ(_1);
    _3495 = NOVALUE;
    Concat((object_ptr)&_sl_6620, _sl_6620, _3496);
    DeRefDS(_3496);
    _3496 = NOVALUE;
L1E: 

    /** filesys.e:1739			for i = length(sl)-1 to 1 by -1 label "partloop" do*/
    if (IS_SEQUENCE(_sl_6620)){
            _3498 = SEQ_PTR(_sl_6620)->length;
    }
    else {
        _3498 = 1;
    }
    _3499 = _3498 - 1LL;
    _3498 = NOVALUE;
    {
        object _i_6641;
        _i_6641 = _3499;
L1F: 
        if (_i_6641 < 1LL){
            goto L20; // [642] 1115
        }

        /** filesys.e:1740				ifdef WINDOWS then*/

        /** filesys.e:1743					sequence part = lPath[1..sl[i]-1]*/
        _2 = (object)SEQ_PTR(_sl_6620);
        _3501 = (object)*(((s1_ptr)_2)->base + _i_6641);
        if (IS_ATOM_INT(_3501)) {
            _3502 = _3501 - 1LL;
        }
        else {
            _3502 = binary_op(MINUS, _3501, 1LL);
        }
        _3501 = NOVALUE;
        rhs_slice_target = (object_ptr)&_part_6645;
        RHS_Slice(_lPath_6517, 1LL, _3502);

        /** filesys.e:1746				object list = dir( part & SLASH )*/
        Append(&_3504, _part_6645, 47LL);
        _0 = _list_6649;
        _list_6649 = _17dir(_3504);
        DeRef(_0);
        _3504 = NOVALUE;

        /** filesys.e:1747				sequence supplied_name = lPath[sl[i]+1..sl[i+1]-1]*/
        _2 = (object)SEQ_PTR(_sl_6620);
        _3506 = (object)*(((s1_ptr)_2)->base + _i_6641);
        if (IS_ATOM_INT(_3506)) {
            _3507 = _3506 + 1;
            if (_3507 > MAXINT){
                _3507 = NewDouble((eudouble)_3507);
            }
        }
        else
        _3507 = binary_op(PLUS, 1, _3506);
        _3506 = NOVALUE;
        _3508 = _i_6641 + 1;
        _2 = (object)SEQ_PTR(_sl_6620);
        _3509 = (object)*(((s1_ptr)_2)->base + _3508);
        if (IS_ATOM_INT(_3509)) {
            _3510 = _3509 - 1LL;
        }
        else {
            _3510 = binary_op(MINUS, _3509, 1LL);
        }
        _3509 = NOVALUE;
        rhs_slice_target = (object_ptr)&_supplied_name_6652;
        RHS_Slice(_lPath_6517, _3507, _3510);

        /** filesys.e:1749				if atom(list) then*/
        _3512 = IS_ATOM(_list_6649);
        if (_3512 == 0)
        {
            _3512 = NOVALUE;
            goto L21; // [710] 748
        }
        else{
            _3512 = NOVALUE;
        }

        /** filesys.e:1750					if lower_name then*/
        if (_lower_name_6629 == 0)
        {
            goto L22; // [715] 741
        }
        else{
        }

        /** filesys.e:1751						lPath = part & lower(lPath[sl[i]..$])*/
        _2 = (object)SEQ_PTR(_sl_6620);
        _3513 = (object)*(((s1_ptr)_2)->base + _i_6641);
        if (IS_SEQUENCE(_lPath_6517)){
                _3514 = SEQ_PTR(_lPath_6517)->length;
        }
        else {
            _3514 = 1;
        }
        rhs_slice_target = (object_ptr)&_3515;
        RHS_Slice(_lPath_6517, _3513, _3514);
        _3516 = _14lower(_3515);
        _3515 = NOVALUE;
        if (IS_SEQUENCE(_part_6645) && IS_ATOM(_3516)) {
            Ref(_3516);
            Append(&_lPath_6517, _part_6645, _3516);
        }
        else if (IS_ATOM(_part_6645) && IS_SEQUENCE(_3516)) {
        }
        else {
            Concat((object_ptr)&_lPath_6517, _part_6645, _3516);
        }
        DeRef(_3516);
        _3516 = NOVALUE;
L22: 

        /** filesys.e:1753					continue*/
        DeRef(_part_6645);
        _part_6645 = NOVALUE;
        DeRef(_list_6649);
        _list_6649 = NOVALUE;
        DeRef(_supplied_name_6652);
        _supplied_name_6652 = NOVALUE;
        goto L23; // [745] 1110
L21: 

        /** filesys.e:1757				for j = 1 to length(list) do*/
        if (IS_SEQUENCE(_list_6649)){
                _3518 = SEQ_PTR(_list_6649)->length;
        }
        else {
            _3518 = 1;
        }
        {
            object _j_6669;
            _j_6669 = 1LL;
L24: 
            if (_j_6669 > _3518){
                goto L25; // [753] 878
            }

            /** filesys.e:1758					sequence read_name = list[j][D_NAME]*/
            _2 = (object)SEQ_PTR(_list_6649);
            _3519 = (object)*(((s1_ptr)_2)->base + _j_6669);
            DeRef(_read_name_6671);
            _2 = (object)SEQ_PTR(_3519);
            _read_name_6671 = (object)*(((s1_ptr)_2)->base + 1LL);
            Ref(_read_name_6671);
            _3519 = NOVALUE;

            /** filesys.e:1759					if equal(read_name, supplied_name) then*/
            if (_read_name_6671 == _supplied_name_6652)
            _3521 = 1;
            else if (IS_ATOM_INT(_read_name_6671) && IS_ATOM_INT(_supplied_name_6652))
            _3521 = 0;
            else
            _3521 = (compare(_read_name_6671, _supplied_name_6652) == 0);
            if (_3521 == 0)
            {
                _3521 = NOVALUE;
                goto L26; // [778] 869
            }
            else{
                _3521 = NOVALUE;
            }

            /** filesys.e:1760						if short_name and sequence(list[j][D_ALTNAME]) then*/
            if (_short_name_6623 == 0) {
                goto L27; // [783] 860
            }
            _2 = (object)SEQ_PTR(_list_6649);
            _3523 = (object)*(((s1_ptr)_2)->base + _j_6669);
            _2 = (object)SEQ_PTR(_3523);
            _3524 = (object)*(((s1_ptr)_2)->base + 11LL);
            _3523 = NOVALUE;
            _3525 = IS_SEQUENCE(_3524);
            _3524 = NOVALUE;
            if (_3525 == 0)
            {
                _3525 = NOVALUE;
                goto L27; // [799] 860
            }
            else{
                _3525 = NOVALUE;
            }

            /** filesys.e:1761							lPath = lPath[1..sl[i]] & list[j][D_ALTNAME] & lPath[sl[i+1]..$]*/
            _2 = (object)SEQ_PTR(_sl_6620);
            _3526 = (object)*(((s1_ptr)_2)->base + _i_6641);
            rhs_slice_target = (object_ptr)&_3527;
            RHS_Slice(_lPath_6517, 1LL, _3526);
            _2 = (object)SEQ_PTR(_list_6649);
            _3528 = (object)*(((s1_ptr)_2)->base + _j_6669);
            _2 = (object)SEQ_PTR(_3528);
            _3529 = (object)*(((s1_ptr)_2)->base + 11LL);
            _3528 = NOVALUE;
            _3530 = _i_6641 + 1;
            _2 = (object)SEQ_PTR(_sl_6620);
            _3531 = (object)*(((s1_ptr)_2)->base + _3530);
            if (IS_SEQUENCE(_lPath_6517)){
                    _3532 = SEQ_PTR(_lPath_6517)->length;
            }
            else {
                _3532 = 1;
            }
            rhs_slice_target = (object_ptr)&_3533;
            RHS_Slice(_lPath_6517, _3531, _3532);
            {
                object concat_list[3];

                concat_list[0] = _3533;
                concat_list[1] = _3529;
                concat_list[2] = _3527;
                Concat_N((object_ptr)&_lPath_6517, concat_list, 3);
            }
            DeRefDS(_3533);
            _3533 = NOVALUE;
            _3529 = NOVALUE;
            DeRefDS(_3527);
            _3527 = NOVALUE;

            /** filesys.e:1762							sl[$] = length(lPath)+1*/
            if (IS_SEQUENCE(_sl_6620)){
                    _3535 = SEQ_PTR(_sl_6620)->length;
            }
            else {
                _3535 = 1;
            }
            if (IS_SEQUENCE(_lPath_6517)){
                    _3536 = SEQ_PTR(_lPath_6517)->length;
            }
            else {
                _3536 = 1;
            }
            _3537 = _3536 + 1;
            _3536 = NOVALUE;
            _2 = (object)SEQ_PTR(_sl_6620);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _sl_6620 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _3535);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _3537;
            if( _1 != _3537 ){
                DeRef(_1);
            }
            _3537 = NOVALUE;
L27: 

            /** filesys.e:1764						continue "partloop"*/
            DeRef(_read_name_6671);
            _read_name_6671 = NOVALUE;
            DeRef(_part_6645);
            _part_6645 = NOVALUE;
            DeRef(_list_6649);
            _list_6649 = NOVALUE;
            DeRef(_supplied_name_6652);
            _supplied_name_6652 = NOVALUE;
            goto L23; // [866] 1110
L26: 
            DeRef(_read_name_6671);
            _read_name_6671 = NOVALUE;

            /** filesys.e:1766				end for*/
            _j_6669 = _j_6669 + 1LL;
            goto L24; // [873] 760
L25: 
            ;
        }

        /** filesys.e:1770				for j = 1 to length(list) do*/
        if (IS_SEQUENCE(_list_6649)){
                _3538 = SEQ_PTR(_list_6649)->length;
        }
        else {
            _3538 = 1;
        }
        {
            object _j_6694;
            _j_6694 = 1LL;
L28: 
            if (_j_6694 > _3538){
                goto L29; // [883] 1055
            }

            /** filesys.e:1771					sequence read_name = list[j][D_NAME]*/
            _2 = (object)SEQ_PTR(_list_6649);
            _3539 = (object)*(((s1_ptr)_2)->base + _j_6694);
            DeRef(_read_name_6696);
            _2 = (object)SEQ_PTR(_3539);
            _read_name_6696 = (object)*(((s1_ptr)_2)->base + 1LL);
            Ref(_read_name_6696);
            _3539 = NOVALUE;

            /** filesys.e:1772					if equal(lower(read_name), lower(supplied_name)) then*/
            RefDS(_read_name_6696);
            _3541 = _14lower(_read_name_6696);
            RefDS(_supplied_name_6652);
            _3542 = _14lower(_supplied_name_6652);
            if (_3541 == _3542)
            _3543 = 1;
            else if (IS_ATOM_INT(_3541) && IS_ATOM_INT(_3542))
            _3543 = 0;
            else
            _3543 = (compare(_3541, _3542) == 0);
            DeRef(_3541);
            _3541 = NOVALUE;
            DeRef(_3542);
            _3542 = NOVALUE;
            if (_3543 == 0)
            {
                _3543 = NOVALUE;
                goto L2A; // [916] 1046
            }
            else{
                _3543 = NOVALUE;
            }

            /** filesys.e:1773						if short_name and sequence(list[j][D_ALTNAME]) then*/
            if (_short_name_6623 == 0) {
                goto L2B; // [921] 998
            }
            _2 = (object)SEQ_PTR(_list_6649);
            _3545 = (object)*(((s1_ptr)_2)->base + _j_6694);
            _2 = (object)SEQ_PTR(_3545);
            _3546 = (object)*(((s1_ptr)_2)->base + 11LL);
            _3545 = NOVALUE;
            _3547 = IS_SEQUENCE(_3546);
            _3546 = NOVALUE;
            if (_3547 == 0)
            {
                _3547 = NOVALUE;
                goto L2B; // [937] 998
            }
            else{
                _3547 = NOVALUE;
            }

            /** filesys.e:1774							lPath = lPath[1..sl[i]] & list[j][D_ALTNAME] & lPath[sl[i+1]..$]*/
            _2 = (object)SEQ_PTR(_sl_6620);
            _3548 = (object)*(((s1_ptr)_2)->base + _i_6641);
            rhs_slice_target = (object_ptr)&_3549;
            RHS_Slice(_lPath_6517, 1LL, _3548);
            _2 = (object)SEQ_PTR(_list_6649);
            _3550 = (object)*(((s1_ptr)_2)->base + _j_6694);
            _2 = (object)SEQ_PTR(_3550);
            _3551 = (object)*(((s1_ptr)_2)->base + 11LL);
            _3550 = NOVALUE;
            _3552 = _i_6641 + 1;
            _2 = (object)SEQ_PTR(_sl_6620);
            _3553 = (object)*(((s1_ptr)_2)->base + _3552);
            if (IS_SEQUENCE(_lPath_6517)){
                    _3554 = SEQ_PTR(_lPath_6517)->length;
            }
            else {
                _3554 = 1;
            }
            rhs_slice_target = (object_ptr)&_3555;
            RHS_Slice(_lPath_6517, _3553, _3554);
            {
                object concat_list[3];

                concat_list[0] = _3555;
                concat_list[1] = _3551;
                concat_list[2] = _3549;
                Concat_N((object_ptr)&_lPath_6517, concat_list, 3);
            }
            DeRefDS(_3555);
            _3555 = NOVALUE;
            _3551 = NOVALUE;
            DeRefDS(_3549);
            _3549 = NOVALUE;

            /** filesys.e:1775							sl[$] = length(lPath)+1*/
            if (IS_SEQUENCE(_sl_6620)){
                    _3557 = SEQ_PTR(_sl_6620)->length;
            }
            else {
                _3557 = 1;
            }
            if (IS_SEQUENCE(_lPath_6517)){
                    _3558 = SEQ_PTR(_lPath_6517)->length;
            }
            else {
                _3558 = 1;
            }
            _3559 = _3558 + 1;
            _3558 = NOVALUE;
            _2 = (object)SEQ_PTR(_sl_6620);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _sl_6620 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _3557);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _3559;
            if( _1 != _3559 ){
                DeRef(_1);
            }
            _3559 = NOVALUE;
L2B: 

            /** filesys.e:1777						if correct_name then*/
            if (_correct_name_6626 == 0)
            {
                goto L2C; // [1000] 1037
            }
            else{
            }

            /** filesys.e:1778							lPath = lPath[1..sl[i]] & read_name & lPath[sl[i+1]..$]*/
            _2 = (object)SEQ_PTR(_sl_6620);
            _3560 = (object)*(((s1_ptr)_2)->base + _i_6641);
            rhs_slice_target = (object_ptr)&_3561;
            RHS_Slice(_lPath_6517, 1LL, _3560);
            _3562 = _i_6641 + 1;
            _2 = (object)SEQ_PTR(_sl_6620);
            _3563 = (object)*(((s1_ptr)_2)->base + _3562);
            if (IS_SEQUENCE(_lPath_6517)){
                    _3564 = SEQ_PTR(_lPath_6517)->length;
            }
            else {
                _3564 = 1;
            }
            rhs_slice_target = (object_ptr)&_3565;
            RHS_Slice(_lPath_6517, _3563, _3564);
            {
                object concat_list[3];

                concat_list[0] = _3565;
                concat_list[1] = _read_name_6696;
                concat_list[2] = _3561;
                Concat_N((object_ptr)&_lPath_6517, concat_list, 3);
            }
            DeRefDS(_3565);
            _3565 = NOVALUE;
            DeRefDS(_3561);
            _3561 = NOVALUE;
L2C: 

            /** filesys.e:1780						continue "partloop"*/
            DeRef(_read_name_6696);
            _read_name_6696 = NOVALUE;
            DeRef(_part_6645);
            _part_6645 = NOVALUE;
            DeRef(_list_6649);
            _list_6649 = NOVALUE;
            DeRef(_supplied_name_6652);
            _supplied_name_6652 = NOVALUE;
            goto L23; // [1043] 1110
L2A: 
            DeRef(_read_name_6696);
            _read_name_6696 = NOVALUE;

            /** filesys.e:1782				end for*/
            _j_6694 = _j_6694 + 1LL;
            goto L28; // [1050] 890
L29: 
            ;
        }

        /** filesys.e:1786				if and_bits(TO_LOWER,case_flags) then*/
        {uintptr_t tu;
             tu = (uintptr_t)1LL & (uintptr_t)_case_flags_6516;
             _3567 = MAKE_UINT(tu);
        }
        if (_3567 == 0) {
            DeRef(_3567);
            _3567 = NOVALUE;
            goto L2D; // [1061] 1100
        }
        else {
            if (!IS_ATOM_INT(_3567) && DBL_PTR(_3567)->dbl == 0.0){
                DeRef(_3567);
                _3567 = NOVALUE;
                goto L2D; // [1061] 1100
            }
            DeRef(_3567);
            _3567 = NOVALUE;
        }
        DeRef(_3567);
        _3567 = NOVALUE;

        /** filesys.e:1787					lPath = lPath[1..sl[i]-1] & lower(lPath[sl[i]..$])*/
        _2 = (object)SEQ_PTR(_sl_6620);
        _3568 = (object)*(((s1_ptr)_2)->base + _i_6641);
        if (IS_ATOM_INT(_3568)) {
            _3569 = _3568 - 1LL;
        }
        else {
            _3569 = binary_op(MINUS, _3568, 1LL);
        }
        _3568 = NOVALUE;
        rhs_slice_target = (object_ptr)&_3570;
        RHS_Slice(_lPath_6517, 1LL, _3569);
        _2 = (object)SEQ_PTR(_sl_6620);
        _3571 = (object)*(((s1_ptr)_2)->base + _i_6641);
        if (IS_SEQUENCE(_lPath_6517)){
                _3572 = SEQ_PTR(_lPath_6517)->length;
        }
        else {
            _3572 = 1;
        }
        rhs_slice_target = (object_ptr)&_3573;
        RHS_Slice(_lPath_6517, _3571, _3572);
        _3574 = _14lower(_3573);
        _3573 = NOVALUE;
        if (IS_SEQUENCE(_3570) && IS_ATOM(_3574)) {
            Ref(_3574);
            Append(&_lPath_6517, _3570, _3574);
        }
        else if (IS_ATOM(_3570) && IS_SEQUENCE(_3574)) {
        }
        else {
            Concat((object_ptr)&_lPath_6517, _3570, _3574);
            DeRefDS(_3570);
            _3570 = NOVALUE;
        }
        DeRef(_3570);
        _3570 = NOVALUE;
        DeRef(_3574);
        _3574 = NOVALUE;
L2D: 

        /** filesys.e:1789				exit*/
        DeRef(_part_6645);
        _part_6645 = NOVALUE;
        DeRef(_list_6649);
        _list_6649 = NOVALUE;
        DeRef(_supplied_name_6652);
        _supplied_name_6652 = NOVALUE;
        goto L20; // [1104] 1115

        /** filesys.e:1790			end for*/
L23: 
        _i_6641 = _i_6641 + -1LL;
        goto L1F; // [1110] 649
L20: 
        ;
    }

    /** filesys.e:1791			if and_bits(case_flags,or_bits(CORRECT,TO_LOWER))=TO_LOWER and length(lPath) then*/
    {uintptr_t tu;
         tu = (uintptr_t)2LL | (uintptr_t)1LL;
         _3576 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_3576)) {
        {uintptr_t tu;
             tu = (uintptr_t)_case_flags_6516 & (uintptr_t)_3576;
             _3577 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (eudouble)_case_flags_6516;
        _3577 = Dand_bits(&temp_d, DBL_PTR(_3576));
    }
    DeRef(_3576);
    _3576 = NOVALUE;
    if (IS_ATOM_INT(_3577)) {
        _3578 = (_3577 == 1LL);
    }
    else {
        _3578 = (DBL_PTR(_3577)->dbl == (eudouble)1LL);
    }
    DeRef(_3577);
    _3577 = NOVALUE;
    if (_3578 == 0) {
        goto L2E; // [1129] 1149
    }
    if (IS_SEQUENCE(_lPath_6517)){
            _3580 = SEQ_PTR(_lPath_6517)->length;
    }
    else {
        _3580 = 1;
    }
    if (_3580 == 0)
    {
        _3580 = NOVALUE;
        goto L2E; // [1137] 1149
    }
    else{
        _3580 = NOVALUE;
    }

    /** filesys.e:1792				lPath = lower(lPath)*/
    RefDS(_lPath_6517);
    _0 = _lPath_6517;
    _lPath_6517 = _14lower(_lPath_6517);
    DeRefDS(_0);
L2E: 
L1D: 
    DeRef(_sl_6620);
    _sl_6620 = NOVALUE;
L1C: 

    /** filesys.e:1796		ifdef WINDOWS then*/

    /** filesys.e:1810		return lPath & wildcard_suffix*/
    Concat((object_ptr)&_3582, _lPath_6517, _wildcard_suffix_6563);
    DeRefDS(_path_in_6514);
    DeRefDS(_lPath_6517);
    DeRefi(_lLevel_6520);
    DeRefi(_lHome_6521);
    DeRefDS(_wildcard_suffix_6563);
    DeRef(_3530);
    _3530 = NOVALUE;
    _3553 = NOVALUE;
    DeRef(_3462);
    _3462 = NOVALUE;
    DeRef(_3569);
    _3569 = NOVALUE;
    _3429 = NOVALUE;
    DeRef(_3510);
    _3510 = NOVALUE;
    DeRef(_3475);
    _3475 = NOVALUE;
    DeRef(_3417);
    _3417 = NOVALUE;
    DeRef(_3472);
    _3472 = NOVALUE;
    DeRef(_3423);
    _3423 = NOVALUE;
    DeRef(_3450);
    _3450 = NOVALUE;
    _3531 = NOVALUE;
    DeRef(_3552);
    _3552 = NOVALUE;
    DeRef(_3578);
    _3578 = NOVALUE;
    DeRef(_3408);
    _3408 = NOVALUE;
    DeRef(_3508);
    _3508 = NOVALUE;
    DeRef(_3507);
    _3507 = NOVALUE;
    DeRef(_3433);
    _3433 = NOVALUE;
    _3548 = NOVALUE;
    _3560 = NOVALUE;
    _3513 = NOVALUE;
    _3526 = NOVALUE;
    _3571 = NOVALUE;
    DeRef(_3455);
    _3455 = NOVALUE;
    DeRef(_3499);
    _3499 = NOVALUE;
    DeRef(_3458);
    _3458 = NOVALUE;
    DeRef(_3562);
    _3562 = NOVALUE;
    DeRef(_3502);
    _3502 = NOVALUE;
    _3563 = NOVALUE;
    DeRef(_3411);
    _3411 = NOVALUE;
    DeRef(_3420);
    _3420 = NOVALUE;
    DeRef(_3415);
    _3415 = NOVALUE;
    return _3582;
    ;
}


object _17abbreviate_path(object _orig_path_6755, object _base_paths_6756)
{
    object _expanded_path_6757 = NOVALUE;
    object _fs_case_inlined_fs_case_at_61_6767 = NOVALUE;
    object _lowered_expanded_path_6768 = NOVALUE;
    object _fs_case_inlined_fs_case_at_73_6770 = NOVALUE;
    object _fs_case_inlined_fs_case_at_216_6797 = NOVALUE;
    object _s_inlined_fs_case_at_213_6796 = NOVALUE;
    object _3618 = NOVALUE;
    object _3617 = NOVALUE;
    object _3614 = NOVALUE;
    object _3613 = NOVALUE;
    object _3612 = NOVALUE;
    object _3611 = NOVALUE;
    object _3610 = NOVALUE;
    object _3608 = NOVALUE;
    object _3607 = NOVALUE;
    object _3606 = NOVALUE;
    object _3605 = NOVALUE;
    object _3604 = NOVALUE;
    object _3603 = NOVALUE;
    object _3602 = NOVALUE;
    object _3601 = NOVALUE;
    object _3598 = NOVALUE;
    object _3597 = NOVALUE;
    object _3596 = NOVALUE;
    object _3595 = NOVALUE;
    object _3594 = NOVALUE;
    object _3593 = NOVALUE;
    object _3592 = NOVALUE;
    object _3591 = NOVALUE;
    object _3590 = NOVALUE;
    object _3589 = NOVALUE;
    object _3588 = NOVALUE;
    object _3587 = NOVALUE;
    object _3586 = NOVALUE;
    object _3584 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1881		expanded_path = canonical_path(orig_path)*/
    RefDS(_orig_path_6755);
    _0 = _expanded_path_6757;
    _expanded_path_6757 = _17canonical_path(_orig_path_6755, 0LL, 0LL);
    DeRef(_0);

    /** filesys.e:1884		base_paths = append(base_paths, curdir())*/
    _3584 = _17curdir(0LL);
    Ref(_3584);
    Append(&_base_paths_6756, _base_paths_6756, _3584);
    DeRef(_3584);
    _3584 = NOVALUE;

    /** filesys.e:1886		for i = 1 to length(base_paths) do*/
    _3586 = 1;
    {
        object _i_6762;
        _i_6762 = 1LL;
L1: 
        if (_i_6762 > 1LL){
            goto L2; // [30] 60
        }

        /** filesys.e:1887			base_paths[i] = canonical_path(base_paths[i], 1) -- assume each base path is meant to be a directory.*/
        _2 = (object)SEQ_PTR(_base_paths_6756);
        _3587 = (object)*(((s1_ptr)_2)->base + 1LL);
        Ref(_3587);
        _3588 = _17canonical_path(_3587, 1LL, 0LL);
        _3587 = NOVALUE;
        _2 = (object)SEQ_PTR(_base_paths_6756);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _base_paths_6756 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _3588;
        if( _1 != _3588 ){
            DeRef(_1);
        }
        _3588 = NOVALUE;

        /** filesys.e:1888		end for*/
        _i_6762 = 1LL + 1LL;
        goto L1; // [55] 37
L2: 
        ;
    }

    /** filesys.e:1892		base_paths = fs_case(base_paths)*/

    /** filesys.e:1825		ifdef WINDOWS then*/

    /** filesys.e:1828			return s*/
    RefDS(_base_paths_6756);
    DeRefDS(_base_paths_6756);
    _base_paths_6756 = _base_paths_6756;

    /** filesys.e:1893		sequence lowered_expanded_path = fs_case(expanded_path)*/

    /** filesys.e:1825		ifdef WINDOWS then*/

    /** filesys.e:1828			return s*/
    RefDS(_expanded_path_6757);
    DeRef(_lowered_expanded_path_6768);
    _lowered_expanded_path_6768 = _expanded_path_6757;

    /** filesys.e:1896		for i = 1 to length(base_paths) do*/
    if (IS_SEQUENCE(_base_paths_6756)){
            _3589 = SEQ_PTR(_base_paths_6756)->length;
    }
    else {
        _3589 = 1;
    }
    {
        object _i_6772;
        _i_6772 = 1LL;
L3: 
        if (_i_6772 > _3589){
            goto L4; // [89] 143
        }

        /** filesys.e:1897			if search:begins(base_paths[i], lowered_expanded_path) then*/
        _2 = (object)SEQ_PTR(_base_paths_6756);
        _3590 = (object)*(((s1_ptr)_2)->base + _i_6772);
        Ref(_3590);
        RefDS(_lowered_expanded_path_6768);
        _3591 = _16begins(_3590, _lowered_expanded_path_6768);
        _3590 = NOVALUE;
        if (_3591 == 0) {
            DeRef(_3591);
            _3591 = NOVALUE;
            goto L5; // [107] 136
        }
        else {
            if (!IS_ATOM_INT(_3591) && DBL_PTR(_3591)->dbl == 0.0){
                DeRef(_3591);
                _3591 = NOVALUE;
                goto L5; // [107] 136
            }
            DeRef(_3591);
            _3591 = NOVALUE;
        }
        DeRef(_3591);
        _3591 = NOVALUE;

        /** filesys.e:1899				return expanded_path[length(base_paths[i]) + 1 .. $]*/
        _2 = (object)SEQ_PTR(_base_paths_6756);
        _3592 = (object)*(((s1_ptr)_2)->base + _i_6772);
        if (IS_SEQUENCE(_3592)){
                _3593 = SEQ_PTR(_3592)->length;
        }
        else {
            _3593 = 1;
        }
        _3592 = NOVALUE;
        _3594 = _3593 + 1;
        _3593 = NOVALUE;
        if (IS_SEQUENCE(_expanded_path_6757)){
                _3595 = SEQ_PTR(_expanded_path_6757)->length;
        }
        else {
            _3595 = 1;
        }
        rhs_slice_target = (object_ptr)&_3596;
        RHS_Slice(_expanded_path_6757, _3594, _3595);
        DeRefDS(_orig_path_6755);
        DeRefDS(_base_paths_6756);
        DeRefDS(_expanded_path_6757);
        DeRefDS(_lowered_expanded_path_6768);
        _3592 = NOVALUE;
        _3594 = NOVALUE;
        return _3596;
L5: 

        /** filesys.e:1901		end for*/
        _i_6772 = _i_6772 + 1LL;
        goto L3; // [138] 96
L4: 
        ;
    }

    /** filesys.e:1904		ifdef WINDOWS then*/

    /** filesys.e:1912		base_paths = stdseq:split(base_paths[$], SLASH)*/
    if (IS_SEQUENCE(_base_paths_6756)){
            _3597 = SEQ_PTR(_base_paths_6756)->length;
    }
    else {
        _3597 = 1;
    }
    _2 = (object)SEQ_PTR(_base_paths_6756);
    _3598 = (object)*(((s1_ptr)_2)->base + _3597);
    Ref(_3598);
    _0 = _base_paths_6756;
    _base_paths_6756 = _23split(_3598, 47LL, 0LL, 0LL);
    DeRefDS(_0);
    _3598 = NOVALUE;

    /** filesys.e:1914		expanded_path = stdseq:split(expanded_path, SLASH)*/
    RefDS(_expanded_path_6757);
    _0 = _expanded_path_6757;
    _expanded_path_6757 = _23split(_expanded_path_6757, 47LL, 0LL, 0LL);
    DeRefDS(_0);

    /** filesys.e:1915		lowered_expanded_path = ""*/
    RefDS(_5);
    DeRef(_lowered_expanded_path_6768);
    _lowered_expanded_path_6768 = _5;

    /** filesys.e:1918		for i = 1 to math:min({length(expanded_path), length(base_paths) - 1}) do*/
    if (IS_SEQUENCE(_expanded_path_6757)){
            _3601 = SEQ_PTR(_expanded_path_6757)->length;
    }
    else {
        _3601 = 1;
    }
    if (IS_SEQUENCE(_base_paths_6756)){
            _3602 = SEQ_PTR(_base_paths_6756)->length;
    }
    else {
        _3602 = 1;
    }
    _3603 = _3602 - 1LL;
    _3602 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _3601;
    ((intptr_t *)_2)[2] = _3603;
    _3604 = MAKE_SEQ(_1);
    _3603 = NOVALUE;
    _3601 = NOVALUE;
    _3605 = _20min(_3604);
    _3604 = NOVALUE;
    {
        object _i_6787;
        _i_6787 = 1LL;
L6: 
        if (binary_op_a(GREATER, _i_6787, _3605)){
            goto L7; // [201] 305
        }

        /** filesys.e:1919			if not equal(fs_case(expanded_path[i]), base_paths[i]) then*/
        _2 = (object)SEQ_PTR(_expanded_path_6757);
        if (!IS_ATOM_INT(_i_6787)){
            _3606 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_6787)->dbl));
        }
        else{
            _3606 = (object)*(((s1_ptr)_2)->base + _i_6787);
        }
        Ref(_3606);
        DeRef(_s_inlined_fs_case_at_213_6796);
        _s_inlined_fs_case_at_213_6796 = _3606;
        _3606 = NOVALUE;

        /** filesys.e:1825		ifdef WINDOWS then*/

        /** filesys.e:1828			return s*/
        Ref(_s_inlined_fs_case_at_213_6796);
        DeRef(_fs_case_inlined_fs_case_at_216_6797);
        _fs_case_inlined_fs_case_at_216_6797 = _s_inlined_fs_case_at_213_6796;
        DeRef(_s_inlined_fs_case_at_213_6796);
        _s_inlined_fs_case_at_213_6796 = NOVALUE;
        _2 = (object)SEQ_PTR(_base_paths_6756);
        if (!IS_ATOM_INT(_i_6787)){
            _3607 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_6787)->dbl));
        }
        else{
            _3607 = (object)*(((s1_ptr)_2)->base + _i_6787);
        }
        if (_fs_case_inlined_fs_case_at_216_6797 == _3607)
        _3608 = 1;
        else if (IS_ATOM_INT(_fs_case_inlined_fs_case_at_216_6797) && IS_ATOM_INT(_3607))
        _3608 = 0;
        else
        _3608 = (compare(_fs_case_inlined_fs_case_at_216_6797, _3607) == 0);
        _3607 = NOVALUE;
        if (_3608 != 0)
        goto L8; // [237] 298
        _3608 = NOVALUE;

        /** filesys.e:1923				expanded_path = repeat("..", length(base_paths) - i) & expanded_path[i .. $]*/
        if (IS_SEQUENCE(_base_paths_6756)){
                _3610 = SEQ_PTR(_base_paths_6756)->length;
        }
        else {
            _3610 = 1;
        }
        if (IS_ATOM_INT(_i_6787)) {
            _3611 = _3610 - _i_6787;
        }
        else {
            _3611 = NewDouble((eudouble)_3610 - DBL_PTR(_i_6787)->dbl);
        }
        _3610 = NOVALUE;
        _3612 = Repeat(_3212, _3611);
        DeRef(_3611);
        _3611 = NOVALUE;
        if (IS_SEQUENCE(_expanded_path_6757)){
                _3613 = SEQ_PTR(_expanded_path_6757)->length;
        }
        else {
            _3613 = 1;
        }
        rhs_slice_target = (object_ptr)&_3614;
        RHS_Slice(_expanded_path_6757, _i_6787, _3613);
        Concat((object_ptr)&_expanded_path_6757, _3612, _3614);
        DeRefDS(_3612);
        _3612 = NOVALUE;
        DeRef(_3612);
        _3612 = NOVALUE;
        DeRefDS(_3614);
        _3614 = NOVALUE;

        /** filesys.e:1924				expanded_path = stdseq:join(expanded_path, SLASH)*/
        RefDS(_expanded_path_6757);
        _0 = _expanded_path_6757;
        _expanded_path_6757 = _23join(_expanded_path_6757, 47LL);
        DeRefDS(_0);

        /** filesys.e:1925				if length(expanded_path) < length(orig_path) then*/
        if (IS_SEQUENCE(_expanded_path_6757)){
                _3617 = SEQ_PTR(_expanded_path_6757)->length;
        }
        else {
            _3617 = 1;
        }
        if (IS_SEQUENCE(_orig_path_6755)){
                _3618 = SEQ_PTR(_orig_path_6755)->length;
        }
        else {
            _3618 = 1;
        }
        if (_3617 >= _3618)
        goto L7; // [282] 305

        /** filesys.e:1927			  		return expanded_path*/
        DeRef(_i_6787);
        DeRefDS(_orig_path_6755);
        DeRefDS(_base_paths_6756);
        DeRef(_lowered_expanded_path_6768);
        _3592 = NOVALUE;
        DeRef(_3605);
        _3605 = NOVALUE;
        DeRef(_3596);
        _3596 = NOVALUE;
        DeRef(_3594);
        _3594 = NOVALUE;
        return _expanded_path_6757;

        /** filesys.e:1929				exit*/
        goto L7; // [295] 305
L8: 

        /** filesys.e:1931		end for*/
        _0 = _i_6787;
        if (IS_ATOM_INT(_i_6787)) {
            _i_6787 = _i_6787 + 1LL;
            if ((object)((uintptr_t)_i_6787 +(uintptr_t) HIGH_BITS) >= 0){
                _i_6787 = NewDouble((eudouble)_i_6787);
            }
        }
        else {
            _i_6787 = binary_op_a(PLUS, _i_6787, 1LL);
        }
        DeRef(_0);
        goto L6; // [300] 208
L7: 
        ;
        DeRef(_i_6787);
    }

    /** filesys.e:1934		return orig_path*/
    DeRefDS(_base_paths_6756);
    DeRef(_expanded_path_6757);
    DeRef(_lowered_expanded_path_6768);
    _3592 = NOVALUE;
    DeRef(_3605);
    _3605 = NOVALUE;
    DeRef(_3596);
    _3596 = NOVALUE;
    DeRef(_3594);
    _3594 = NOVALUE;
    return _orig_path_6755;
    ;
}


object _17file_type(object _filename_6845)
{
    object _dirfil_6846 = NOVALUE;
    object _3651 = NOVALUE;
    object _3650 = NOVALUE;
    object _3649 = NOVALUE;
    object _3648 = NOVALUE;
    object _3647 = NOVALUE;
    object _3645 = NOVALUE;
    object _3644 = NOVALUE;
    object _3643 = NOVALUE;
    object _3642 = NOVALUE;
    object _3641 = NOVALUE;
    object _3640 = NOVALUE;
    object _3639 = NOVALUE;
    object _3637 = NOVALUE;
    object _3635 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:2040		if eu:find('*', filename) or eu:find('?', filename) then return FILETYPE_UNDEFINED end if*/
    _3635 = find_from(42LL, _filename_6845, 1LL);
    if (_3635 != 0) {
        goto L1; // [10] 24
    }
    _3637 = find_from(63LL, _filename_6845, 1LL);
    if (_3637 == 0)
    {
        _3637 = NOVALUE;
        goto L2; // [20] 29
    }
    else{
        _3637 = NOVALUE;
    }
L1: 
    DeRefDS(_filename_6845);
    DeRef(_dirfil_6846);
    return -1LL;
L2: 

    /** filesys.e:2042		ifdef WINDOWS then*/

    /** filesys.e:2048		dirfil = dir(filename)*/
    RefDS(_filename_6845);
    _0 = _dirfil_6846;
    _dirfil_6846 = _17dir(_filename_6845);
    DeRef(_0);

    /** filesys.e:2049		if sequence(dirfil) then*/
    _3639 = IS_SEQUENCE(_dirfil_6846);
    if (_3639 == 0)
    {
        _3639 = NOVALUE;
        goto L3; // [42] 126
    }
    else{
        _3639 = NOVALUE;
    }

    /** filesys.e:2050			if length( dirfil ) > 1 or eu:find('d', dirfil[1][2]) or (length(filename)=3 and filename[2]=':') then*/
    if (IS_SEQUENCE(_dirfil_6846)){
            _3640 = SEQ_PTR(_dirfil_6846)->length;
    }
    else {
        _3640 = 1;
    }
    _3641 = (_3640 > 1LL);
    _3640 = NOVALUE;
    if (_3641 != 0) {
        _3642 = 1;
        goto L4; // [54] 75
    }
    _2 = (object)SEQ_PTR(_dirfil_6846);
    _3643 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_3643);
    _3644 = (object)*(((s1_ptr)_2)->base + 2LL);
    _3643 = NOVALUE;
    _3645 = find_from(100LL, _3644, 1LL);
    _3644 = NOVALUE;
    _3642 = (_3645 != 0);
L4: 
    if (_3642 != 0) {
        goto L5; // [75] 107
    }
    if (IS_SEQUENCE(_filename_6845)){
            _3647 = SEQ_PTR(_filename_6845)->length;
    }
    else {
        _3647 = 1;
    }
    _3648 = (_3647 == 3LL);
    _3647 = NOVALUE;
    if (_3648 == 0) {
        DeRef(_3649);
        _3649 = 0;
        goto L6; // [86] 102
    }
    _2 = (object)SEQ_PTR(_filename_6845);
    _3650 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_3650)) {
        _3651 = (_3650 == 58LL);
    }
    else {
        _3651 = binary_op(EQUALS, _3650, 58LL);
    }
    _3650 = NOVALUE;
    if (IS_ATOM_INT(_3651))
    _3649 = (_3651 != 0);
    else
    _3649 = DBL_PTR(_3651)->dbl != 0.0;
L6: 
    if (_3649 == 0)
    {
        _3649 = NOVALUE;
        goto L7; // [103] 116
    }
    else{
        _3649 = NOVALUE;
    }
L5: 

    /** filesys.e:2051				return FILETYPE_DIRECTORY*/
    DeRefDS(_filename_6845);
    DeRef(_dirfil_6846);
    DeRef(_3648);
    _3648 = NOVALUE;
    DeRef(_3651);
    _3651 = NOVALUE;
    DeRef(_3641);
    _3641 = NOVALUE;
    return 2LL;
    goto L8; // [113] 133
L7: 

    /** filesys.e:2053				return FILETYPE_FILE*/
    DeRefDS(_filename_6845);
    DeRef(_dirfil_6846);
    DeRef(_3648);
    _3648 = NOVALUE;
    DeRef(_3651);
    _3651 = NOVALUE;
    DeRef(_3641);
    _3641 = NOVALUE;
    return 1LL;
    goto L8; // [123] 133
L3: 

    /** filesys.e:2056			return FILETYPE_NOT_FOUND*/
    DeRefDS(_filename_6845);
    DeRef(_dirfil_6846);
    DeRef(_3648);
    _3648 = NOVALUE;
    DeRef(_3651);
    _3651 = NOVALUE;
    DeRef(_3641);
    _3641 = NOVALUE;
    return 0LL;
L8: 
    ;
}


object _17file_exists(object _name_6885)
{
    object _pName_6888 = NOVALUE;
    object _r_6890 = NOVALUE;
    object _3656 = NOVALUE;
    object _3654 = NOVALUE;
    object _3652 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:2103		if atom(name) then*/
    _3652 = IS_ATOM(_name_6885);
    if (_3652 == 0)
    {
        _3652 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _3652 = NOVALUE;
    }

    /** filesys.e:2104			return 0*/
    DeRef(_name_6885);
    DeRef(_pName_6888);
    DeRef(_r_6890);
    return 0LL;
L1: 

    /** filesys.e:2107		ifdef WINDOWS then*/

    /** filesys.e:2115			atom pName = machine:allocate_string(name)*/
    Ref(_name_6885);
    _0 = _pName_6888;
    _pName_6888 = _9allocate_string(_name_6885, 0LL);
    DeRef(_0);

    /** filesys.e:2116			atom r = c_func(xGetFileAttributes, {pName, 0})*/
    Ref(_pName_6888);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _pName_6888;
    ((intptr_t *)_2)[2] = 0LL;
    _3654 = MAKE_SEQ(_1);
    DeRef(_r_6890);
    _r_6890 = call_c(1, _17xGetFileAttributes_5956, _3654);
    DeRefDS(_3654);
    _3654 = NOVALUE;

    /** filesys.e:2117			machine:free(pName)*/
    Ref(_pName_6888);
    _9free(_pName_6888);

    /** filesys.e:2119			return r = 0*/
    if (IS_ATOM_INT(_r_6890)) {
        _3656 = (_r_6890 == 0LL);
    }
    else {
        _3656 = (DBL_PTR(_r_6890)->dbl == (eudouble)0LL);
    }
    DeRef(_name_6885);
    DeRef(_pName_6888);
    DeRef(_r_6890);
    return _3656;
    ;
}


object _17file_timestamp(object _fname_6896)
{
    object _d_6897 = NOVALUE;
    object _3671 = NOVALUE;
    object _3670 = NOVALUE;
    object _3669 = NOVALUE;
    object _3668 = NOVALUE;
    object _3667 = NOVALUE;
    object _3666 = NOVALUE;
    object _3665 = NOVALUE;
    object _3664 = NOVALUE;
    object _3663 = NOVALUE;
    object _3662 = NOVALUE;
    object _3661 = NOVALUE;
    object _3660 = NOVALUE;
    object _3659 = NOVALUE;
    object _3658 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:2139		object d = dir(fname)*/
    RefDS(_fname_6896);
    _0 = _d_6897;
    _d_6897 = _17dir(_fname_6896);
    DeRef(_0);

    /** filesys.e:2140		if atom(d) then return -1 end if*/
    _3658 = IS_ATOM(_d_6897);
    if (_3658 == 0)
    {
        _3658 = NOVALUE;
        goto L1; // [14] 22
    }
    else{
        _3658 = NOVALUE;
    }
    DeRefDS(_fname_6896);
    DeRef(_d_6897);
    return -1LL;
L1: 

    /** filesys.e:2142		return datetime:new(d[1][D_YEAR], d[1][D_MONTH], d[1][D_DAY],*/
    _2 = (object)SEQ_PTR(_d_6897);
    _3659 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_3659);
    _3660 = (object)*(((s1_ptr)_2)->base + 4LL);
    _3659 = NOVALUE;
    _2 = (object)SEQ_PTR(_d_6897);
    _3661 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_3661);
    _3662 = (object)*(((s1_ptr)_2)->base + 5LL);
    _3661 = NOVALUE;
    _2 = (object)SEQ_PTR(_d_6897);
    _3663 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_3663);
    _3664 = (object)*(((s1_ptr)_2)->base + 6LL);
    _3663 = NOVALUE;
    _2 = (object)SEQ_PTR(_d_6897);
    _3665 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_3665);
    _3666 = (object)*(((s1_ptr)_2)->base + 7LL);
    _3665 = NOVALUE;
    _2 = (object)SEQ_PTR(_d_6897);
    _3667 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_3667);
    _3668 = (object)*(((s1_ptr)_2)->base + 8LL);
    _3667 = NOVALUE;
    _2 = (object)SEQ_PTR(_d_6897);
    _3669 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_3669);
    _3670 = (object)*(((s1_ptr)_2)->base + 9LL);
    _3669 = NOVALUE;
    Ref(_3660);
    Ref(_3662);
    Ref(_3664);
    Ref(_3666);
    Ref(_3668);
    Ref(_3670);
    _3671 = _18new(_3660, _3662, _3664, _3666, _3668, _3670);
    _3660 = NOVALUE;
    _3662 = NOVALUE;
    _3664 = NOVALUE;
    _3666 = NOVALUE;
    _3668 = NOVALUE;
    _3670 = NOVALUE;
    DeRefDS(_fname_6896);
    DeRef(_d_6897);
    return _3671;
    ;
}


object _17locate_file(object _filename_7088, object _search_list_7089, object _subdir_7090)
{
    object _extra_paths_7091 = NOVALUE;
    object _this_path_7092 = NOVALUE;
    object _3843 = NOVALUE;
    object _3842 = NOVALUE;
    object _3840 = NOVALUE;
    object _3838 = NOVALUE;
    object _3836 = NOVALUE;
    object _3835 = NOVALUE;
    object _3834 = NOVALUE;
    object _3832 = NOVALUE;
    object _3831 = NOVALUE;
    object _3830 = NOVALUE;
    object _3828 = NOVALUE;
    object _3827 = NOVALUE;
    object _3826 = NOVALUE;
    object _3823 = NOVALUE;
    object _3822 = NOVALUE;
    object _3820 = NOVALUE;
    object _3818 = NOVALUE;
    object _3817 = NOVALUE;
    object _3814 = NOVALUE;
    object _3809 = NOVALUE;
    object _3805 = NOVALUE;
    object _3797 = NOVALUE;
    object _3794 = NOVALUE;
    object _3791 = NOVALUE;
    object _3790 = NOVALUE;
    object _3786 = NOVALUE;
    object _3783 = NOVALUE;
    object _3781 = NOVALUE;
    object _3777 = NOVALUE;
    object _3775 = NOVALUE;
    object _3774 = NOVALUE;
    object _3770 = NOVALUE;
    object _3769 = NOVALUE;
    object _3766 = NOVALUE;
    object _3764 = NOVALUE;
    object _3763 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:2525		if absolute_path(filename) then*/
    RefDS(_filename_7088);
    _3763 = _17absolute_path(_filename_7088);
    if (_3763 == 0) {
        DeRef(_3763);
        _3763 = NOVALUE;
        goto L1; // [13] 23
    }
    else {
        if (!IS_ATOM_INT(_3763) && DBL_PTR(_3763)->dbl == 0.0){
            DeRef(_3763);
            _3763 = NOVALUE;
            goto L1; // [13] 23
        }
        DeRef(_3763);
        _3763 = NOVALUE;
    }
    DeRef(_3763);
    _3763 = NOVALUE;

    /** filesys.e:2526			return filename*/
    DeRefDS(_search_list_7089);
    DeRefDS(_subdir_7090);
    DeRef(_extra_paths_7091);
    DeRef(_this_path_7092);
    return _filename_7088;
L1: 

    /** filesys.e:2529		if length(search_list) = 0 then*/
    if (IS_SEQUENCE(_search_list_7089)){
            _3764 = SEQ_PTR(_search_list_7089)->length;
    }
    else {
        _3764 = 1;
    }
    if (_3764 != 0LL)
    goto L2; // [28] 281

    /** filesys.e:2530			search_list = append(search_list, "." & SLASH)*/
    Append(&_3766, _3145, 47LL);
    RefDS(_3766);
    Append(&_search_list_7089, _search_list_7089, _3766);
    DeRefDS(_3766);
    _3766 = NOVALUE;

    /** filesys.e:2532			extra_paths = command_line()*/
    DeRef(_extra_paths_7091);
    _extra_paths_7091 = Command_Line();

    /** filesys.e:2533			extra_paths = canonical_path(dirname(extra_paths[2]), 1)*/
    _2 = (object)SEQ_PTR(_extra_paths_7091);
    _3769 = (object)*(((s1_ptr)_2)->base + 2LL);
    RefDS(_3769);
    _3770 = _17dirname(_3769, 0LL);
    _3769 = NOVALUE;
    _0 = _extra_paths_7091;
    _extra_paths_7091 = _17canonical_path(_3770, 1LL, 0LL);
    DeRefDS(_0);
    _3770 = NOVALUE;

    /** filesys.e:2534			search_list = append(search_list, extra_paths)*/
    Ref(_extra_paths_7091);
    Append(&_search_list_7089, _search_list_7089, _extra_paths_7091);

    /** filesys.e:2536			ifdef UNIX then*/

    /** filesys.e:2537				extra_paths = getenv("HOME")*/
    DeRef(_extra_paths_7091);
    _extra_paths_7091 = EGetEnv(_3424);

    /** filesys.e:2543			if sequence(extra_paths) then*/
    _3774 = IS_SEQUENCE(_extra_paths_7091);
    if (_3774 == 0)
    {
        _3774 = NOVALUE;
        goto L3; // [81] 95
    }
    else{
        _3774 = NOVALUE;
    }

    /** filesys.e:2544				search_list = append(search_list, extra_paths & SLASH)*/
    if (IS_SEQUENCE(_extra_paths_7091) && IS_ATOM(47LL)) {
        Append(&_3775, _extra_paths_7091, 47LL);
    }
    else if (IS_ATOM(_extra_paths_7091) && IS_SEQUENCE(47LL)) {
    }
    else {
        Concat((object_ptr)&_3775, _extra_paths_7091, 47LL);
    }
    RefDS(_3775);
    Append(&_search_list_7089, _search_list_7089, _3775);
    DeRefDS(_3775);
    _3775 = NOVALUE;
L3: 

    /** filesys.e:2547			search_list = append(search_list, ".." & SLASH)*/
    Append(&_3777, _3212, 47LL);
    RefDS(_3777);
    Append(&_search_list_7089, _search_list_7089, _3777);
    DeRefDS(_3777);
    _3777 = NOVALUE;

    /** filesys.e:2549			extra_paths = getenv("EUDIR")*/
    DeRef(_extra_paths_7091);
    _extra_paths_7091 = EGetEnv(_3779);

    /** filesys.e:2550			if sequence(extra_paths) then*/
    _3781 = IS_SEQUENCE(_extra_paths_7091);
    if (_3781 == 0)
    {
        _3781 = NOVALUE;
        goto L4; // [115] 145
    }
    else{
        _3781 = NOVALUE;
    }

    /** filesys.e:2551				search_list = append(search_list, extra_paths & SLASH & "bin" & SLASH)*/
    {
        object concat_list[4];

        concat_list[0] = 47LL;
        concat_list[1] = _3782;
        concat_list[2] = 47LL;
        concat_list[3] = _extra_paths_7091;
        Concat_N((object_ptr)&_3783, concat_list, 4);
    }
    RefDS(_3783);
    Append(&_search_list_7089, _search_list_7089, _3783);
    DeRefDS(_3783);
    _3783 = NOVALUE;

    /** filesys.e:2552				search_list = append(search_list, extra_paths & SLASH & "docs" & SLASH)*/
    {
        object concat_list[4];

        concat_list[0] = 47LL;
        concat_list[1] = _3785;
        concat_list[2] = 47LL;
        concat_list[3] = _extra_paths_7091;
        Concat_N((object_ptr)&_3786, concat_list, 4);
    }
    RefDS(_3786);
    Append(&_search_list_7089, _search_list_7089, _3786);
    DeRefDS(_3786);
    _3786 = NOVALUE;
L4: 

    /** filesys.e:2555			extra_paths = getenv("EUDIST")*/
    DeRef(_extra_paths_7091);
    _extra_paths_7091 = EGetEnv(_3788);

    /** filesys.e:2556			if sequence(extra_paths) then*/
    _3790 = IS_SEQUENCE(_extra_paths_7091);
    if (_3790 == 0)
    {
        _3790 = NOVALUE;
        goto L5; // [155] 195
    }
    else{
        _3790 = NOVALUE;
    }

    /** filesys.e:2557				search_list = append(search_list, extra_paths & SLASH)*/
    if (IS_SEQUENCE(_extra_paths_7091) && IS_ATOM(47LL)) {
        Append(&_3791, _extra_paths_7091, 47LL);
    }
    else if (IS_ATOM(_extra_paths_7091) && IS_SEQUENCE(47LL)) {
    }
    else {
        Concat((object_ptr)&_3791, _extra_paths_7091, 47LL);
    }
    RefDS(_3791);
    Append(&_search_list_7089, _search_list_7089, _3791);
    DeRefDS(_3791);
    _3791 = NOVALUE;

    /** filesys.e:2558				search_list = append(search_list, extra_paths & SLASH & "etc" & SLASH)*/
    {
        object concat_list[4];

        concat_list[0] = 47LL;
        concat_list[1] = _3793;
        concat_list[2] = 47LL;
        concat_list[3] = _extra_paths_7091;
        Concat_N((object_ptr)&_3794, concat_list, 4);
    }
    RefDS(_3794);
    Append(&_search_list_7089, _search_list_7089, _3794);
    DeRefDS(_3794);
    _3794 = NOVALUE;

    /** filesys.e:2559				search_list = append(search_list, extra_paths & SLASH & "data" & SLASH)*/
    {
        object concat_list[4];

        concat_list[0] = 47LL;
        concat_list[1] = _3796;
        concat_list[2] = 47LL;
        concat_list[3] = _extra_paths_7091;
        Concat_N((object_ptr)&_3797, concat_list, 4);
    }
    RefDS(_3797);
    Append(&_search_list_7089, _search_list_7089, _3797);
    DeRefDS(_3797);
    _3797 = NOVALUE;
L5: 

    /** filesys.e:2562			ifdef UNIX then*/

    /** filesys.e:2564				search_list = append( search_list, "/usr/local/share/euphoria/bin/" )*/
    RefDS(_3799);
    Append(&_search_list_7089, _search_list_7089, _3799);

    /** filesys.e:2565				search_list = append( search_list, "/usr/share/euphoria/bin/" )*/
    RefDS(_3801);
    Append(&_search_list_7089, _search_list_7089, _3801);

    /** filesys.e:2568			search_list &= include_paths(1)*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_3804);
    ((intptr_t*)_2)[1] = _3804;
    RefDS(_3803);
    ((intptr_t*)_2)[2] = _3803;
    _3805 = MAKE_SEQ(_1);
    Concat((object_ptr)&_search_list_7089, _search_list_7089, _3805);
    DeRefDS(_3805);
    _3805 = NOVALUE;

    /** filesys.e:2571			extra_paths = getenv("USERPATH")*/
    DeRef(_extra_paths_7091);
    _extra_paths_7091 = EGetEnv(_3807);

    /** filesys.e:2572			if sequence(extra_paths) then*/
    _3809 = IS_SEQUENCE(_extra_paths_7091);
    if (_3809 == 0)
    {
        _3809 = NOVALUE;
        goto L6; // [230] 249
    }
    else{
        _3809 = NOVALUE;
    }

    /** filesys.e:2573				extra_paths = stdseq:split(extra_paths, PATHSEP)*/
    Ref(_extra_paths_7091);
    _0 = _extra_paths_7091;
    _extra_paths_7091 = _23split(_extra_paths_7091, 58LL, 0LL, 0LL);
    DeRefi(_0);

    /** filesys.e:2574				search_list &= extra_paths*/
    if (IS_SEQUENCE(_search_list_7089) && IS_ATOM(_extra_paths_7091)) {
        Ref(_extra_paths_7091);
        Append(&_search_list_7089, _search_list_7089, _extra_paths_7091);
    }
    else if (IS_ATOM(_search_list_7089) && IS_SEQUENCE(_extra_paths_7091)) {
    }
    else {
        Concat((object_ptr)&_search_list_7089, _search_list_7089, _extra_paths_7091);
    }
L6: 

    /** filesys.e:2577			extra_paths = getenv("PATH")*/
    DeRef(_extra_paths_7091);
    _extra_paths_7091 = EGetEnv(_3812);

    /** filesys.e:2578			if sequence(extra_paths) then*/
    _3814 = IS_SEQUENCE(_extra_paths_7091);
    if (_3814 == 0)
    {
        _3814 = NOVALUE;
        goto L7; // [259] 306
    }
    else{
        _3814 = NOVALUE;
    }

    /** filesys.e:2579				extra_paths = stdseq:split(extra_paths, PATHSEP)*/
    Ref(_extra_paths_7091);
    _0 = _extra_paths_7091;
    _extra_paths_7091 = _23split(_extra_paths_7091, 58LL, 0LL, 0LL);
    DeRefi(_0);

    /** filesys.e:2580				search_list &= extra_paths*/
    if (IS_SEQUENCE(_search_list_7089) && IS_ATOM(_extra_paths_7091)) {
        Ref(_extra_paths_7091);
        Append(&_search_list_7089, _search_list_7089, _extra_paths_7091);
    }
    else if (IS_ATOM(_search_list_7089) && IS_SEQUENCE(_extra_paths_7091)) {
    }
    else {
        Concat((object_ptr)&_search_list_7089, _search_list_7089, _extra_paths_7091);
    }
    goto L7; // [278] 306
L2: 

    /** filesys.e:2583			if integer(search_list[1]) then*/
    _2 = (object)SEQ_PTR(_search_list_7089);
    _3817 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_3817))
    _3818 = 1;
    else if (IS_ATOM_DBL(_3817))
    _3818 = IS_ATOM_INT(DoubleToInt(_3817));
    else
    _3818 = 0;
    _3817 = NOVALUE;
    if (_3818 == 0)
    {
        _3818 = NOVALUE;
        goto L8; // [290] 305
    }
    else{
        _3818 = NOVALUE;
    }

    /** filesys.e:2584				search_list = stdseq:split(search_list, PATHSEP)*/
    RefDS(_search_list_7089);
    _0 = _search_list_7089;
    _search_list_7089 = _23split(_search_list_7089, 58LL, 0LL, 0LL);
    DeRefDS(_0);
L8: 
L7: 

    /** filesys.e:2588		if length(subdir) > 0 then*/
    if (IS_SEQUENCE(_subdir_7090)){
            _3820 = SEQ_PTR(_subdir_7090)->length;
    }
    else {
        _3820 = 1;
    }
    if (_3820 <= 0LL)
    goto L9; // [311] 336

    /** filesys.e:2589			if subdir[$] != SLASH then*/
    if (IS_SEQUENCE(_subdir_7090)){
            _3822 = SEQ_PTR(_subdir_7090)->length;
    }
    else {
        _3822 = 1;
    }
    _2 = (object)SEQ_PTR(_subdir_7090);
    _3823 = (object)*(((s1_ptr)_2)->base + _3822);
    if (binary_op_a(EQUALS, _3823, 47LL)){
        _3823 = NOVALUE;
        goto LA; // [324] 335
    }
    _3823 = NOVALUE;

    /** filesys.e:2590				subdir &= SLASH*/
    Append(&_subdir_7090, _subdir_7090, 47LL);
LA: 
L9: 

    /** filesys.e:2594		for i = 1 to length(search_list) do*/
    if (IS_SEQUENCE(_search_list_7089)){
            _3826 = SEQ_PTR(_search_list_7089)->length;
    }
    else {
        _3826 = 1;
    }
    {
        object _i_7168;
        _i_7168 = 1LL;
LB: 
        if (_i_7168 > _3826){
            goto LC; // [341] 464
        }

        /** filesys.e:2595			if length(search_list[i]) = 0 then*/
        _2 = (object)SEQ_PTR(_search_list_7089);
        _3827 = (object)*(((s1_ptr)_2)->base + _i_7168);
        if (IS_SEQUENCE(_3827)){
                _3828 = SEQ_PTR(_3827)->length;
        }
        else {
            _3828 = 1;
        }
        _3827 = NOVALUE;
        if (_3828 != 0LL)
        goto LD; // [357] 366

        /** filesys.e:2596				continue*/
        goto LE; // [363] 459
LD: 

        /** filesys.e:2599			if search_list[i][$] != SLASH then*/
        _2 = (object)SEQ_PTR(_search_list_7089);
        _3830 = (object)*(((s1_ptr)_2)->base + _i_7168);
        if (IS_SEQUENCE(_3830)){
                _3831 = SEQ_PTR(_3830)->length;
        }
        else {
            _3831 = 1;
        }
        _2 = (object)SEQ_PTR(_3830);
        _3832 = (object)*(((s1_ptr)_2)->base + _3831);
        _3830 = NOVALUE;
        if (binary_op_a(EQUALS, _3832, 47LL)){
            _3832 = NOVALUE;
            goto LF; // [379] 398
        }
        _3832 = NOVALUE;

        /** filesys.e:2600				search_list[i] &= SLASH*/
        _2 = (object)SEQ_PTR(_search_list_7089);
        _3834 = (object)*(((s1_ptr)_2)->base + _i_7168);
        if (IS_SEQUENCE(_3834) && IS_ATOM(47LL)) {
            Append(&_3835, _3834, 47LL);
        }
        else if (IS_ATOM(_3834) && IS_SEQUENCE(47LL)) {
        }
        else {
            Concat((object_ptr)&_3835, _3834, 47LL);
            _3834 = NOVALUE;
        }
        _3834 = NOVALUE;
        _2 = (object)SEQ_PTR(_search_list_7089);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _search_list_7089 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_7168);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _3835;
        if( _1 != _3835 ){
            DeRef(_1);
        }
        _3835 = NOVALUE;
LF: 

        /** filesys.e:2604			if length(subdir) > 0 then*/
        if (IS_SEQUENCE(_subdir_7090)){
                _3836 = SEQ_PTR(_subdir_7090)->length;
        }
        else {
            _3836 = 1;
        }
        if (_3836 <= 0LL)
        goto L10; // [403] 422

        /** filesys.e:2605				this_path = search_list[i] & subdir & filename*/
        _2 = (object)SEQ_PTR(_search_list_7089);
        _3838 = (object)*(((s1_ptr)_2)->base + _i_7168);
        {
            object concat_list[3];

            concat_list[0] = _filename_7088;
            concat_list[1] = _subdir_7090;
            concat_list[2] = _3838;
            Concat_N((object_ptr)&_this_path_7092, concat_list, 3);
        }
        _3838 = NOVALUE;
        goto L11; // [419] 433
L10: 

        /** filesys.e:2607				this_path = search_list[i] & filename*/
        _2 = (object)SEQ_PTR(_search_list_7089);
        _3840 = (object)*(((s1_ptr)_2)->base + _i_7168);
        if (IS_SEQUENCE(_3840) && IS_ATOM(_filename_7088)) {
        }
        else if (IS_ATOM(_3840) && IS_SEQUENCE(_filename_7088)) {
            Ref(_3840);
            Prepend(&_this_path_7092, _filename_7088, _3840);
        }
        else {
            Concat((object_ptr)&_this_path_7092, _3840, _filename_7088);
            _3840 = NOVALUE;
        }
        _3840 = NOVALUE;
L11: 

        /** filesys.e:2610			if file_exists(this_path) then*/
        RefDS(_this_path_7092);
        _3842 = _17file_exists(_this_path_7092);
        if (_3842 == 0) {
            DeRef(_3842);
            _3842 = NOVALUE;
            goto L12; // [441] 457
        }
        else {
            if (!IS_ATOM_INT(_3842) && DBL_PTR(_3842)->dbl == 0.0){
                DeRef(_3842);
                _3842 = NOVALUE;
                goto L12; // [441] 457
            }
            DeRef(_3842);
            _3842 = NOVALUE;
        }
        DeRef(_3842);
        _3842 = NOVALUE;

        /** filesys.e:2611				return canonical_path(this_path)*/
        RefDS(_this_path_7092);
        _3843 = _17canonical_path(_this_path_7092, 0LL, 0LL);
        DeRefDS(_filename_7088);
        DeRefDS(_search_list_7089);
        DeRefDS(_subdir_7090);
        DeRef(_extra_paths_7091);
        DeRefDS(_this_path_7092);
        _3827 = NOVALUE;
        return _3843;
L12: 

        /** filesys.e:2614		end for*/
LE: 
        _i_7168 = _i_7168 + 1LL;
        goto LB; // [459] 348
LC: 
        ;
    }

    /** filesys.e:2615		return filename*/
    DeRefDS(_search_list_7089);
    DeRefDS(_subdir_7090);
    DeRef(_extra_paths_7091);
    DeRef(_this_path_7092);
    DeRef(_3843);
    _3843 = NOVALUE;
    _3827 = NOVALUE;
    return _filename_7088;
    ;
}


object _17count_files(object _orig_path_7267, object _dir_info_7268, object _inst_7269)
{
    object _pos_7270 = NOVALUE;
    object _ext_7271 = NOVALUE;
    object _fileext_inlined_fileext_at_218_7312 = NOVALUE;
    object _data_inlined_fileext_at_218_7311 = NOVALUE;
    object _path_inlined_fileext_at_215_7310 = NOVALUE;
    object _3949 = NOVALUE;
    object _3948 = NOVALUE;
    object _3947 = NOVALUE;
    object _3945 = NOVALUE;
    object _3944 = NOVALUE;
    object _3943 = NOVALUE;
    object _3942 = NOVALUE;
    object _3940 = NOVALUE;
    object _3939 = NOVALUE;
    object _3937 = NOVALUE;
    object _3936 = NOVALUE;
    object _3935 = NOVALUE;
    object _3934 = NOVALUE;
    object _3933 = NOVALUE;
    object _3932 = NOVALUE;
    object _3931 = NOVALUE;
    object _3929 = NOVALUE;
    object _3928 = NOVALUE;
    object _3926 = NOVALUE;
    object _3925 = NOVALUE;
    object _3924 = NOVALUE;
    object _3923 = NOVALUE;
    object _3922 = NOVALUE;
    object _3921 = NOVALUE;
    object _3920 = NOVALUE;
    object _3919 = NOVALUE;
    object _3918 = NOVALUE;
    object _3917 = NOVALUE;
    object _3916 = NOVALUE;
    object _3915 = NOVALUE;
    object _3914 = NOVALUE;
    object _3912 = NOVALUE;
    object _3911 = NOVALUE;
    object _3910 = NOVALUE;
    object _3909 = NOVALUE;
    object _3907 = NOVALUE;
    object _3906 = NOVALUE;
    object _3905 = NOVALUE;
    object _3904 = NOVALUE;
    object _3903 = NOVALUE;
    object _3902 = NOVALUE;
    object _3901 = NOVALUE;
    object _3899 = NOVALUE;
    object _3898 = NOVALUE;
    object _3897 = NOVALUE;
    object _3896 = NOVALUE;
    object _3895 = NOVALUE;
    object _3894 = NOVALUE;
    object _3891 = NOVALUE;
    object _3890 = NOVALUE;
    object _3889 = NOVALUE;
    object _3888 = NOVALUE;
    object _3887 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** filesys.e:2777		integer pos = 0*/
    _pos_7270 = 0LL;

    /** filesys.e:2780		orig_path = orig_path*/
    RefDS(_orig_path_7267);
    DeRefDS(_orig_path_7267);
    _orig_path_7267 = _orig_path_7267;

    /** filesys.e:2781		if equal(dir_info[D_NAME], ".") then*/
    _2 = (object)SEQ_PTR(_dir_info_7268);
    _3887 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (_3887 == _3145)
    _3888 = 1;
    else if (IS_ATOM_INT(_3887) && IS_ATOM_INT(_3145))
    _3888 = 0;
    else
    _3888 = (compare(_3887, _3145) == 0);
    _3887 = NOVALUE;
    if (_3888 == 0)
    {
        _3888 = NOVALUE;
        goto L1; // [29] 39
    }
    else{
        _3888 = NOVALUE;
    }

    /** filesys.e:2782			return 0*/
    DeRefDS(_orig_path_7267);
    DeRefDS(_dir_info_7268);
    DeRefDS(_inst_7269);
    DeRef(_ext_7271);
    return 0LL;
L1: 

    /** filesys.e:2784		if equal(dir_info[D_NAME], "..") then*/
    _2 = (object)SEQ_PTR(_dir_info_7268);
    _3889 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (_3889 == _3212)
    _3890 = 1;
    else if (IS_ATOM_INT(_3889) && IS_ATOM_INT(_3212))
    _3890 = 0;
    else
    _3890 = (compare(_3889, _3212) == 0);
    _3889 = NOVALUE;
    if (_3890 == 0)
    {
        _3890 = NOVALUE;
        goto L2; // [49] 59
    }
    else{
        _3890 = NOVALUE;
    }

    /** filesys.e:2785			return 0*/
    DeRefDS(_orig_path_7267);
    DeRefDS(_dir_info_7268);
    DeRefDS(_inst_7269);
    DeRef(_ext_7271);
    return 0LL;
L2: 

    /** filesys.e:2789		if inst[1] = 0 then -- count all is false*/
    _2 = (object)SEQ_PTR(_inst_7269);
    _3891 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _3891, 0LL)){
        _3891 = NOVALUE;
        goto L3; // [65] 112
    }
    _3891 = NOVALUE;

    /** filesys.e:2790			if find('h', dir_info[D_ATTRIBUTES]) then*/
    _2 = (object)SEQ_PTR(_dir_info_7268);
    _3894 = (object)*(((s1_ptr)_2)->base + 2LL);
    _3895 = find_from(104LL, _3894, 1LL);
    _3894 = NOVALUE;
    if (_3895 == 0)
    {
        _3895 = NOVALUE;
        goto L4; // [80] 90
    }
    else{
        _3895 = NOVALUE;
    }

    /** filesys.e:2791				return 0*/
    DeRefDS(_orig_path_7267);
    DeRefDS(_dir_info_7268);
    DeRefDS(_inst_7269);
    DeRef(_ext_7271);
    return 0LL;
L4: 

    /** filesys.e:2794			if find('s', dir_info[D_ATTRIBUTES]) then*/
    _2 = (object)SEQ_PTR(_dir_info_7268);
    _3896 = (object)*(((s1_ptr)_2)->base + 2LL);
    _3897 = find_from(115LL, _3896, 1LL);
    _3896 = NOVALUE;
    if (_3897 == 0)
    {
        _3897 = NOVALUE;
        goto L5; // [101] 111
    }
    else{
        _3897 = NOVALUE;
    }

    /** filesys.e:2795				return 0*/
    DeRefDS(_orig_path_7267);
    DeRefDS(_dir_info_7268);
    DeRefDS(_inst_7269);
    DeRef(_ext_7271);
    return 0LL;
L5: 
L3: 

    /** filesys.e:2799		file_counters[inst[2]][COUNT_SIZE] += dir_info[D_SIZE]*/
    _2 = (object)SEQ_PTR(_inst_7269);
    _3898 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_17file_counters_7264);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _17file_counters_7264 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_3898))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_3898)->dbl));
    else
    _3 = (object)(_3898 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_dir_info_7268);
    _3901 = (object)*(((s1_ptr)_2)->base + 3LL);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _3902 = (object)*(((s1_ptr)_2)->base + 3LL);
    _3899 = NOVALUE;
    if (IS_ATOM_INT(_3902) && IS_ATOM_INT(_3901)) {
        _3903 = _3902 + _3901;
        if ((object)((uintptr_t)_3903 + (uintptr_t)HIGH_BITS) >= 0){
            _3903 = NewDouble((eudouble)_3903);
        }
    }
    else {
        _3903 = binary_op(PLUS, _3902, _3901);
    }
    _3902 = NOVALUE;
    _3901 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _3903;
    if( _1 != _3903 ){
        DeRef(_1);
    }
    _3903 = NOVALUE;
    _3899 = NOVALUE;

    /** filesys.e:2800		if find('d', dir_info[D_ATTRIBUTES]) then*/
    _2 = (object)SEQ_PTR(_dir_info_7268);
    _3904 = (object)*(((s1_ptr)_2)->base + 2LL);
    _3905 = find_from(100LL, _3904, 1LL);
    _3904 = NOVALUE;
    if (_3905 == 0)
    {
        _3905 = NOVALUE;
        goto L6; // [152] 183
    }
    else{
        _3905 = NOVALUE;
    }

    /** filesys.e:2801			file_counters[inst[2]][COUNT_DIRS] += 1*/
    _2 = (object)SEQ_PTR(_inst_7269);
    _3906 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_17file_counters_7264);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _17file_counters_7264 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_3906))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_3906)->dbl));
    else
    _3 = (object)(_3906 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _3909 = (object)*(((s1_ptr)_2)->base + 1LL);
    _3907 = NOVALUE;
    if (IS_ATOM_INT(_3909)) {
        _3910 = _3909 + 1;
        if (_3910 > MAXINT){
            _3910 = NewDouble((eudouble)_3910);
        }
    }
    else
    _3910 = binary_op(PLUS, 1, _3909);
    _3909 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _3910;
    if( _1 != _3910 ){
        DeRef(_1);
    }
    _3910 = NOVALUE;
    _3907 = NOVALUE;
    goto L7; // [180] 460
L6: 

    /** filesys.e:2803			file_counters[inst[2]][COUNT_FILES] += 1*/
    _2 = (object)SEQ_PTR(_inst_7269);
    _3911 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_17file_counters_7264);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _17file_counters_7264 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_3911))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_3911)->dbl));
    else
    _3 = (object)(_3911 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _3914 = (object)*(((s1_ptr)_2)->base + 2LL);
    _3912 = NOVALUE;
    if (IS_ATOM_INT(_3914)) {
        _3915 = _3914 + 1;
        if (_3915 > MAXINT){
            _3915 = NewDouble((eudouble)_3915);
        }
    }
    else
    _3915 = binary_op(PLUS, 1, _3914);
    _3914 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _3915;
    if( _1 != _3915 ){
        DeRef(_1);
    }
    _3915 = NOVALUE;
    _3912 = NOVALUE;

    /** filesys.e:2804			ifdef not UNIX then*/

    /** filesys.e:2807				ext = fileext(dir_info[D_NAME])*/
    _2 = (object)SEQ_PTR(_dir_info_7268);
    _3916 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_3916);
    DeRef(_path_inlined_fileext_at_215_7310);
    _path_inlined_fileext_at_215_7310 = _3916;
    _3916 = NOVALUE;

    /** filesys.e:1403		data = pathinfo(path)*/
    Ref(_path_inlined_fileext_at_215_7310);
    _0 = _data_inlined_fileext_at_218_7311;
    _data_inlined_fileext_at_218_7311 = _17pathinfo(_path_inlined_fileext_at_215_7310, 0LL);
    DeRef(_0);

    /** filesys.e:1404		return data[4]*/
    DeRef(_ext_7271);
    _2 = (object)SEQ_PTR(_data_inlined_fileext_at_218_7311);
    _ext_7271 = (object)*(((s1_ptr)_2)->base + 4LL);
    Ref(_ext_7271);
    DeRef(_path_inlined_fileext_at_215_7310);
    _path_inlined_fileext_at_215_7310 = NOVALUE;
    DeRef(_data_inlined_fileext_at_218_7311);
    _data_inlined_fileext_at_218_7311 = NOVALUE;

    /** filesys.e:2810			pos = 0*/
    _pos_7270 = 0LL;

    /** filesys.e:2811			for i = 1 to length(file_counters[inst[2]][COUNT_TYPES]) do*/
    _2 = (object)SEQ_PTR(_inst_7269);
    _3917 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_17file_counters_7264);
    if (!IS_ATOM_INT(_3917)){
        _3918 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_3917)->dbl));
    }
    else{
        _3918 = (object)*(((s1_ptr)_2)->base + _3917);
    }
    _2 = (object)SEQ_PTR(_3918);
    _3919 = (object)*(((s1_ptr)_2)->base + 4LL);
    _3918 = NOVALUE;
    if (IS_SEQUENCE(_3919)){
            _3920 = SEQ_PTR(_3919)->length;
    }
    else {
        _3920 = 1;
    }
    _3919 = NOVALUE;
    {
        object _i_7314;
        _i_7314 = 1LL;
L8: 
        if (_i_7314 > _3920){
            goto L9; // [265] 322
        }

        /** filesys.e:2812				if equal(file_counters[inst[2]][COUNT_TYPES][i][EXT_NAME], ext) then*/
        _2 = (object)SEQ_PTR(_inst_7269);
        _3921 = (object)*(((s1_ptr)_2)->base + 2LL);
        _2 = (object)SEQ_PTR(_17file_counters_7264);
        if (!IS_ATOM_INT(_3921)){
            _3922 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_3921)->dbl));
        }
        else{
            _3922 = (object)*(((s1_ptr)_2)->base + _3921);
        }
        _2 = (object)SEQ_PTR(_3922);
        _3923 = (object)*(((s1_ptr)_2)->base + 4LL);
        _3922 = NOVALUE;
        _2 = (object)SEQ_PTR(_3923);
        _3924 = (object)*(((s1_ptr)_2)->base + _i_7314);
        _3923 = NOVALUE;
        _2 = (object)SEQ_PTR(_3924);
        _3925 = (object)*(((s1_ptr)_2)->base + 1LL);
        _3924 = NOVALUE;
        if (_3925 == _ext_7271)
        _3926 = 1;
        else if (IS_ATOM_INT(_3925) && IS_ATOM_INT(_ext_7271))
        _3926 = 0;
        else
        _3926 = (compare(_3925, _ext_7271) == 0);
        _3925 = NOVALUE;
        if (_3926 == 0)
        {
            _3926 = NOVALUE;
            goto LA; // [302] 315
        }
        else{
            _3926 = NOVALUE;
        }

        /** filesys.e:2813					pos = i*/
        _pos_7270 = _i_7314;

        /** filesys.e:2814					exit*/
        goto L9; // [312] 322
LA: 

        /** filesys.e:2816			end for*/
        _i_7314 = _i_7314 + 1LL;
        goto L8; // [317] 272
L9: 
        ;
    }

    /** filesys.e:2818			if pos = 0 then*/
    if (_pos_7270 != 0LL)
    goto LB; // [324] 385

    /** filesys.e:2819				file_counters[inst[2]][COUNT_TYPES] &= {{ext, 0, 0}}*/
    _2 = (object)SEQ_PTR(_inst_7269);
    _3928 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_17file_counters_7264);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _17file_counters_7264 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_3928))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_3928)->dbl));
    else
    _3 = (object)(_3928 + ((s1_ptr)_2)->base);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_ext_7271);
    ((intptr_t*)_2)[1] = _ext_7271;
    ((intptr_t*)_2)[2] = 0LL;
    ((intptr_t*)_2)[3] = 0LL;
    _3931 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _3931;
    _3932 = MAKE_SEQ(_1);
    _3931 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _3933 = (object)*(((s1_ptr)_2)->base + 4LL);
    _3929 = NOVALUE;
    if (IS_SEQUENCE(_3933) && IS_ATOM(_3932)) {
    }
    else if (IS_ATOM(_3933) && IS_SEQUENCE(_3932)) {
        Ref(_3933);
        Prepend(&_3934, _3932, _3933);
    }
    else {
        Concat((object_ptr)&_3934, _3933, _3932);
        _3933 = NOVALUE;
    }
    _3933 = NOVALUE;
    DeRefDS(_3932);
    _3932 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _3934;
    if( _1 != _3934 ){
        DeRef(_1);
    }
    _3934 = NOVALUE;
    _3929 = NOVALUE;

    /** filesys.e:2820				pos = length(file_counters[inst[2]][COUNT_TYPES])*/
    _2 = (object)SEQ_PTR(_inst_7269);
    _3935 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_17file_counters_7264);
    if (!IS_ATOM_INT(_3935)){
        _3936 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_3935)->dbl));
    }
    else{
        _3936 = (object)*(((s1_ptr)_2)->base + _3935);
    }
    _2 = (object)SEQ_PTR(_3936);
    _3937 = (object)*(((s1_ptr)_2)->base + 4LL);
    _3936 = NOVALUE;
    if (IS_SEQUENCE(_3937)){
            _pos_7270 = SEQ_PTR(_3937)->length;
    }
    else {
        _pos_7270 = 1;
    }
    _3937 = NOVALUE;
LB: 

    /** filesys.e:2823			file_counters[inst[2]][COUNT_TYPES][pos][EXT_COUNT] += 1*/
    _2 = (object)SEQ_PTR(_inst_7269);
    _3939 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_17file_counters_7264);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _17file_counters_7264 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_3939))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_3939)->dbl));
    else
    _3 = (object)(_3939 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (object)(4LL + ((s1_ptr)_2)->base);
    _3940 = NOVALUE;
    _2 = (object)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (object)(_pos_7270 + ((s1_ptr)_2)->base);
    _3940 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _3942 = (object)*(((s1_ptr)_2)->base + 2LL);
    _3940 = NOVALUE;
    if (IS_ATOM_INT(_3942)) {
        _3943 = _3942 + 1;
        if (_3943 > MAXINT){
            _3943 = NewDouble((eudouble)_3943);
        }
    }
    else
    _3943 = binary_op(PLUS, 1, _3942);
    _3942 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _3943;
    if( _1 != _3943 ){
        DeRef(_1);
    }
    _3943 = NOVALUE;
    _3940 = NOVALUE;

    /** filesys.e:2824			file_counters[inst[2]][COUNT_TYPES][pos][EXT_SIZE] += dir_info[D_SIZE]*/
    _2 = (object)SEQ_PTR(_inst_7269);
    _3944 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_17file_counters_7264);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _17file_counters_7264 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_3944))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_3944)->dbl));
    else
    _3 = (object)(_3944 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (object)(4LL + ((s1_ptr)_2)->base);
    _3945 = NOVALUE;
    _2 = (object)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (object)(_pos_7270 + ((s1_ptr)_2)->base);
    _3945 = NOVALUE;
    _2 = (object)SEQ_PTR(_dir_info_7268);
    _3947 = (object)*(((s1_ptr)_2)->base + 3LL);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _3948 = (object)*(((s1_ptr)_2)->base + 3LL);
    _3945 = NOVALUE;
    if (IS_ATOM_INT(_3948) && IS_ATOM_INT(_3947)) {
        _3949 = _3948 + _3947;
        if ((object)((uintptr_t)_3949 + (uintptr_t)HIGH_BITS) >= 0){
            _3949 = NewDouble((eudouble)_3949);
        }
    }
    else {
        _3949 = binary_op(PLUS, _3948, _3947);
    }
    _3948 = NOVALUE;
    _3947 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _3949;
    if( _1 != _3949 ){
        DeRef(_1);
    }
    _3949 = NOVALUE;
    _3945 = NOVALUE;
L7: 

    /** filesys.e:2827		return 0*/
    DeRefDS(_orig_path_7267);
    DeRefDS(_dir_info_7268);
    DeRefDS(_inst_7269);
    DeRef(_ext_7271);
    _3898 = NOVALUE;
    _3937 = NOVALUE;
    _3911 = NOVALUE;
    _3939 = NOVALUE;
    _3917 = NOVALUE;
    _3921 = NOVALUE;
    _3944 = NOVALUE;
    _3928 = NOVALUE;
    _3935 = NOVALUE;
    _3906 = NOVALUE;
    _3919 = NOVALUE;
    return 0LL;
    ;
}


object _17temp_file(object _temp_location_7372, object _temp_prefix_7373, object _temp_extn_7374, object _reserve_temp_7376)
{
    object _randname_7377 = NOVALUE;
    object _envtmp_7381 = NOVALUE;
    object _tdir_7400 = NOVALUE;
    object _6326 = NOVALUE;
    object _4001 = NOVALUE;
    object _3999 = NOVALUE;
    object _3997 = NOVALUE;
    object _3995 = NOVALUE;
    object _3994 = NOVALUE;
    object _3993 = NOVALUE;
    object _3989 = NOVALUE;
    object _3988 = NOVALUE;
    object _3987 = NOVALUE;
    object _3986 = NOVALUE;
    object _3983 = NOVALUE;
    object _3982 = NOVALUE;
    object _3981 = NOVALUE;
    object _3976 = NOVALUE;
    object _3974 = NOVALUE;
    object _3970 = NOVALUE;
    object _3966 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:2919		if length(temp_location) = 0 then*/
    if (IS_SEQUENCE(_temp_location_7372)){
            _3966 = SEQ_PTR(_temp_location_7372)->length;
    }
    else {
        _3966 = 1;
    }
    if (_3966 != 0LL)
    goto L1; // [14] 67

    /** filesys.e:2920			object envtmp*/

    /** filesys.e:2921			envtmp = getenv("TEMP")*/
    DeRefi(_envtmp_7381);
    _envtmp_7381 = EGetEnv(_3968);

    /** filesys.e:2922			if atom(envtmp) then*/
    _3970 = IS_ATOM(_envtmp_7381);
    if (_3970 == 0)
    {
        _3970 = NOVALUE;
        goto L2; // [30] 39
    }
    else{
        _3970 = NOVALUE;
    }

    /** filesys.e:2923				envtmp = getenv("TMP")*/
    DeRefi(_envtmp_7381);
    _envtmp_7381 = EGetEnv(_3971);
L2: 

    /** filesys.e:2925			ifdef WINDOWS then			*/

    /** filesys.e:2930				if atom(envtmp) then*/
    _3974 = IS_ATOM(_envtmp_7381);
    if (_3974 == 0)
    {
        _3974 = NOVALUE;
        goto L3; // [46] 55
    }
    else{
        _3974 = NOVALUE;
    }

    /** filesys.e:2931					envtmp = "/tmp/"*/
    RefDS(_3975);
    DeRefi(_envtmp_7381);
    _envtmp_7381 = _3975;
L3: 

    /** filesys.e:2934			temp_location = envtmp*/
    Ref(_envtmp_7381);
    DeRefDS(_temp_location_7372);
    _temp_location_7372 = _envtmp_7381;
    DeRefi(_envtmp_7381);
    _envtmp_7381 = NOVALUE;
    goto L4; // [64] 161
L1: 

    /** filesys.e:2936			switch file_type(temp_location) do*/
    RefDS(_temp_location_7372);
    _3976 = _17file_type(_temp_location_7372);
    if (IS_SEQUENCE(_3976) ){
        goto L5; // [73] 150
    }
    if(!IS_ATOM_INT(_3976)){
        if( (DBL_PTR(_3976)->dbl != (eudouble) ((object) DBL_PTR(_3976)->dbl) ) ){
            goto L5; // [73] 150
        }
        _0 = (object) DBL_PTR(_3976)->dbl;
    }
    else {
        _0 = _3976;
    };
    DeRef(_3976);
    _3976 = NOVALUE;
    switch ( _0 ){ 

        /** filesys.e:2937				case FILETYPE_FILE then*/
        case 1:

        /** filesys.e:2938					temp_location = dirname(temp_location, 1)*/
        RefDS(_temp_location_7372);
        _0 = _temp_location_7372;
        _temp_location_7372 = _17dirname(_temp_location_7372, 1LL);
        DeRefDS(_0);
        goto L6; // [91] 160

        /** filesys.e:2940				case FILETYPE_DIRECTORY then*/
        case 2:

        /** filesys.e:2942					temp_location = temp_location*/
        RefDS(_temp_location_7372);
        DeRefDS(_temp_location_7372);
        _temp_location_7372 = _temp_location_7372;
        goto L6; // [104] 160

        /** filesys.e:2944				case FILETYPE_NOT_FOUND then*/
        case 0:

        /** filesys.e:2945					object tdir = dirname(temp_location, 1)*/
        RefDS(_temp_location_7372);
        _0 = _tdir_7400;
        _tdir_7400 = _17dirname(_temp_location_7372, 1LL);
        DeRef(_0);

        /** filesys.e:2946					if file_exists(tdir) then*/
        Ref(_tdir_7400);
        _3981 = _17file_exists(_tdir_7400);
        if (_3981 == 0) {
            DeRef(_3981);
            _3981 = NOVALUE;
            goto L7; // [123] 136
        }
        else {
            if (!IS_ATOM_INT(_3981) && DBL_PTR(_3981)->dbl == 0.0){
                DeRef(_3981);
                _3981 = NOVALUE;
                goto L7; // [123] 136
            }
            DeRef(_3981);
            _3981 = NOVALUE;
        }
        DeRef(_3981);
        _3981 = NOVALUE;

        /** filesys.e:2947						temp_location = tdir*/
        Ref(_tdir_7400);
        DeRefDS(_temp_location_7372);
        _temp_location_7372 = _tdir_7400;
        goto L8; // [133] 144
L7: 

        /** filesys.e:2949						temp_location = "."*/
        RefDS(_3145);
        DeRefDS(_temp_location_7372);
        _temp_location_7372 = _3145;
L8: 
        DeRef(_tdir_7400);
        _tdir_7400 = NOVALUE;
        goto L6; // [146] 160

        /** filesys.e:2952				case else*/
        default:
L5: 

        /** filesys.e:2953					temp_location = "."*/
        RefDS(_3145);
        DeRefDS(_temp_location_7372);
        _temp_location_7372 = _3145;
    ;}L6: 
L4: 

    /** filesys.e:2958		if temp_location[$] != SLASH then*/
    if (IS_SEQUENCE(_temp_location_7372)){
            _3982 = SEQ_PTR(_temp_location_7372)->length;
    }
    else {
        _3982 = 1;
    }
    _2 = (object)SEQ_PTR(_temp_location_7372);
    _3983 = (object)*(((s1_ptr)_2)->base + _3982);
    if (binary_op_a(EQUALS, _3983, 47LL)){
        _3983 = NOVALUE;
        goto L9; // [170] 181
    }
    _3983 = NOVALUE;

    /** filesys.e:2959			temp_location &= SLASH*/
    Append(&_temp_location_7372, _temp_location_7372, 47LL);
L9: 

    /** filesys.e:2962		if length(temp_extn) and temp_extn[1] != '.' then*/
    if (IS_SEQUENCE(_temp_extn_7374)){
            _3986 = SEQ_PTR(_temp_extn_7374)->length;
    }
    else {
        _3986 = 1;
    }
    if (_3986 == 0) {
        goto LA; // [186] 209
    }
    _2 = (object)SEQ_PTR(_temp_extn_7374);
    _3988 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_3988)) {
        _3989 = (_3988 != 46LL);
    }
    else {
        _3989 = binary_op(NOTEQ, _3988, 46LL);
    }
    _3988 = NOVALUE;
    if (_3989 == 0) {
        DeRef(_3989);
        _3989 = NOVALUE;
        goto LA; // [199] 209
    }
    else {
        if (!IS_ATOM_INT(_3989) && DBL_PTR(_3989)->dbl == 0.0){
            DeRef(_3989);
            _3989 = NOVALUE;
            goto LA; // [199] 209
        }
        DeRef(_3989);
        _3989 = NOVALUE;
    }
    DeRef(_3989);
    _3989 = NOVALUE;

    /** filesys.e:2963			temp_extn = '.' & temp_extn*/
    Prepend(&_temp_extn_7374, _temp_extn_7374, 46LL);
LA: 

    /** filesys.e:2966		while 1 do*/
LB: 

    /** filesys.e:2967			randname = sprintf("%s%s%06d%s", {temp_location, temp_prefix, rand(1_000_000) - 1, temp_extn})*/
    _3993 = good_rand() % ((uint32_t)1000000LL) + 1;
    _3994 = _3993 - 1LL;
    _3993 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_temp_location_7372);
    ((intptr_t*)_2)[1] = _temp_location_7372;
    RefDS(_temp_prefix_7373);
    ((intptr_t*)_2)[2] = _temp_prefix_7373;
    ((intptr_t*)_2)[3] = _3994;
    RefDS(_temp_extn_7374);
    ((intptr_t*)_2)[4] = _temp_extn_7374;
    _3995 = MAKE_SEQ(_1);
    _3994 = NOVALUE;
    DeRefi(_randname_7377);
    _randname_7377 = EPrintf(-9999999, _3991, _3995);
    DeRefDS(_3995);
    _3995 = NOVALUE;

    /** filesys.e:2968			if not file_exists( randname ) then*/
    RefDS(_randname_7377);
    _3997 = _17file_exists(_randname_7377);
    if (IS_ATOM_INT(_3997)) {
        if (_3997 != 0){
            DeRef(_3997);
            _3997 = NOVALUE;
            goto LB; // [240] 214
        }
    }
    else {
        if (DBL_PTR(_3997)->dbl != 0.0){
            DeRef(_3997);
            _3997 = NOVALUE;
            goto LB; // [240] 214
        }
    }
    DeRef(_3997);
    _3997 = NOVALUE;

    /** filesys.e:2969				exit*/
    goto LC; // [245] 253

    /** filesys.e:2971		end while*/
    goto LB; // [250] 214
LC: 

    /** filesys.e:2973		if reserve_temp then*/
    if (_reserve_temp_7376 == 0)
    {
        goto LD; // [255] 300
    }
    else{
    }

    /** filesys.e:2975			if not file_exists(temp_location) then*/
    RefDS(_temp_location_7372);
    _3999 = _17file_exists(_temp_location_7372);
    if (IS_ATOM_INT(_3999)) {
        if (_3999 != 0){
            DeRef(_3999);
            _3999 = NOVALUE;
            goto LE; // [264] 287
        }
    }
    else {
        if (DBL_PTR(_3999)->dbl != 0.0){
            DeRef(_3999);
            _3999 = NOVALUE;
            goto LE; // [264] 287
        }
    }
    DeRef(_3999);
    _3999 = NOVALUE;

    /** filesys.e:2976				if create_directory(temp_location) = 0 then*/
    RefDS(_temp_location_7372);
    _4001 = _17create_directory(_temp_location_7372, 448LL, 1LL);
    if (binary_op_a(NOTEQ, _4001, 0LL)){
        DeRef(_4001);
        _4001 = NOVALUE;
        goto LF; // [275] 286
    }
    DeRef(_4001);
    _4001 = NOVALUE;

    /** filesys.e:2977					return ""*/
    RefDS(_5);
    DeRefDS(_temp_location_7372);
    DeRefDSi(_temp_prefix_7373);
    DeRefDS(_temp_extn_7374);
    DeRefi(_randname_7377);
    return _5;
LF: 
LE: 

    /** filesys.e:2980			io:write_file(randname, "")*/
    RefDS(_randname_7377);
    RefDS(_5);
    _6326 = _8write_file(_randname_7377, _5, 1LL);
    DeRef(_6326);
    _6326 = NOVALUE;
LD: 

    /** filesys.e:2983		return randname*/
    DeRefDS(_temp_location_7372);
    DeRefDSi(_temp_prefix_7373);
    DeRefDS(_temp_extn_7374);
    return _randname_7377;
    ;
}



// 0x384DA9DB
