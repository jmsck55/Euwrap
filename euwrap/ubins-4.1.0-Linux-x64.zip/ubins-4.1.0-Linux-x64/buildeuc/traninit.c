// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _3extract_options(object _s_64561)
{
    object _0, _1, _2;
    

    /** traninit.e:69		return s*/
    return _s_64561;
    ;
}


void _3transoptions()
{
    object _tranopts_64748 = NOVALUE;
    object _opts_64760 = NOVALUE;
    object _opt_keys_64766 = NOVALUE;
    object _option_w_64768 = NOVALUE;
    object _key_64772 = NOVALUE;
    object _val_64774 = NOVALUE;
    object _tmp_64879 = NOVALUE;
    object _tmp_64899 = NOVALUE;
    object _filetype_64925 = NOVALUE;
    object _31939 = NOVALUE;
    object _31938 = NOVALUE;
    object _31937 = NOVALUE;
    object _31936 = NOVALUE;
    object _31934 = NOVALUE;
    object _31933 = NOVALUE;
    object _31932 = NOVALUE;
    object _31931 = NOVALUE;
    object _31930 = NOVALUE;
    object _31929 = NOVALUE;
    object _31924 = NOVALUE;
    object _31923 = NOVALUE;
    object _31922 = NOVALUE;
    object _31919 = NOVALUE;
    object _31918 = NOVALUE;
    object _31917 = NOVALUE;
    object _31916 = NOVALUE;
    object _31915 = NOVALUE;
    object _31912 = NOVALUE;
    object _31909 = NOVALUE;
    object _31908 = NOVALUE;
    object _31907 = NOVALUE;
    object _31906 = NOVALUE;
    object _31904 = NOVALUE;
    object _31901 = NOVALUE;
    object _31900 = NOVALUE;
    object _31899 = NOVALUE;
    object _31898 = NOVALUE;
    object _31897 = NOVALUE;
    object _31896 = NOVALUE;
    object _31895 = NOVALUE;
    object _31894 = NOVALUE;
    object _31893 = NOVALUE;
    object _31892 = NOVALUE;
    object _31891 = NOVALUE;
    object _31890 = NOVALUE;
    object _31889 = NOVALUE;
    object _31885 = NOVALUE;
    object _31882 = NOVALUE;
    object _31881 = NOVALUE;
    object _31880 = NOVALUE;
    object _31874 = NOVALUE;
    object _31871 = NOVALUE;
    object _31870 = NOVALUE;
    object _31868 = NOVALUE;
    object _31866 = NOVALUE;
    object _31862 = NOVALUE;
    object _31852 = NOVALUE;
    object _31850 = NOVALUE;
    object _31847 = NOVALUE;
    object _31845 = NOVALUE;
    object _31843 = NOVALUE;
    object _31842 = NOVALUE;
    object _31841 = NOVALUE;
    object _31840 = NOVALUE;
    object _31839 = NOVALUE;
    object _31834 = NOVALUE;
    object _31828 = NOVALUE;
    object _0, _1, _2;
    

    /** traninit.e:112		sequence tranopts = sort( get_options() )*/
    _31828 = _49get_options();
    _0 = _tranopts_64748;
    _tranopts_64748 = _24sort(_31828, 1LL);
    DeRef(_0);
    _31828 = NOVALUE;

    /** traninit.e:114		Argv = expand_config_options( Argv )*/
    RefDS(_36Argv_21450);
    _0 = _49expand_config_options(_36Argv_21450);
    DeRefDS(_36Argv_21450);
    _36Argv_21450 = _0;

    /** traninit.e:115		Argc = length(Argv)*/
    if (IS_SEQUENCE(_36Argv_21450)){
            _36Argc_21449 = SEQ_PTR(_36Argv_21450)->length;
    }
    else {
        _36Argc_21449 = 1;
    }

    /** traninit.e:117		map:map opts = cmd_parse( tranopts, NO_HELP_ON_ERROR, Argv)*/
    RefDS(_tranopts_64748);
    RefDS(_36Argv_21450);
    _0 = _opts_64760;
    _opts_64760 = _4cmd_parse(_tranopts_64748, 10LL, _36Argv_21450);
    DeRef(_0);

    /** traninit.e:119		handle_common_options(opts)*/
    Ref(_opts_64760);
    _49handle_common_options(_opts_64760);

    /** traninit.e:121		sequence opt_keys = map:keys(opts)*/
    Ref(_opts_64760);
    _0 = _opt_keys_64766;
    _opt_keys_64766 = _29keys(_opts_64760, 0LL);
    DeRef(_0);

    /** traninit.e:122		integer option_w = 0*/
    _option_w_64768 = 0LL;

    /** traninit.e:124		for idx = 1 to length(opt_keys) do*/
    if (IS_SEQUENCE(_opt_keys_64766)){
            _31834 = SEQ_PTR(_opt_keys_64766)->length;
    }
    else {
        _31834 = 1;
    }
    {
        object _idx_64770;
        _idx_64770 = 1LL;
L1: 
        if (_idx_64770 > _31834){
            goto L2; // [68] 884
        }

        /** traninit.e:126			sequence key = opt_keys[idx]*/
        DeRef(_key_64772);
        _2 = (object)SEQ_PTR(_opt_keys_64766);
        _key_64772 = (object)*(((s1_ptr)_2)->base + _idx_64770);
        Ref(_key_64772);

        /** traninit.e:127			object val = map:get(opts, key)*/
        Ref(_opts_64760);
        RefDS(_key_64772);
        _0 = _val_64774;
        _val_64774 = _29get(_opts_64760, _key_64772, 0LL);
        DeRef(_0);

        /** traninit.e:129			switch key do*/
        _1 = find(_key_64772, _31837);
        switch ( _1 ){ 

            /** traninit.e:130				case "silent" then*/
            case 1:

            /** traninit.e:131					silent = TRUE*/
            _36silent_21558 = _13TRUE_452;
            goto L3; // [109] 875

            /** traninit.e:133				case "verbose" then*/
            case 2:

            /** traninit.e:134					verbose = TRUE*/
            _36verbose_21561 = _13TRUE_452;
            goto L3; // [122] 875

            /** traninit.e:136				case "rc-file" then*/
            case 3:

            /** traninit.e:137					rc_file[D_NAME] = canonical_path(val)*/
            Ref(_val_64774);
            _31839 = _17canonical_path(_val_64774, 0LL, 0LL);
            _2 = (object)SEQ_PTR(_56rc_file_45398);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _56rc_file_45398 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 1LL);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _31839;
            if( _1 != _31839 ){
                DeRef(_1);
            }
            _31839 = NOVALUE;

            /** traninit.e:138					rc_file[D_ALTNAME] = adjust_for_command_line_passing((rc_file[D_NAME]))*/
            _2 = (object)SEQ_PTR(_56rc_file_45398);
            _31840 = (object)*(((s1_ptr)_2)->base + 1LL);
            Ref(_31840);
            _31841 = _56adjust_for_command_line_passing(_31840);
            _31840 = NOVALUE;
            _2 = (object)SEQ_PTR(_56rc_file_45398);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _56rc_file_45398 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 11LL);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _31841;
            if( _1 != _31841 ){
                DeRef(_1);
            }
            _31841 = NOVALUE;

            /** traninit.e:139					if not file_exists(rc_file[D_NAME]) then*/
            _2 = (object)SEQ_PTR(_56rc_file_45398);
            _31842 = (object)*(((s1_ptr)_2)->base + 1LL);
            Ref(_31842);
            _31843 = _17file_exists(_31842);
            _31842 = NOVALUE;
            if (IS_ATOM_INT(_31843)) {
                if (_31843 != 0){
                    DeRef(_31843);
                    _31843 = NOVALUE;
                    goto L3; // [180] 875
                }
            }
            else {
                if (DBL_PTR(_31843)->dbl != 0.0){
                    DeRef(_31843);
                    _31843 = NOVALUE;
                    goto L3; // [180] 875
                }
            }
            DeRef(_31843);
            _31843 = NOVALUE;

            /** traninit.e:140						ShowMsg(2, RESOURCE_FILE_DOES_NOT_EXIST__1, { val })*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_val_64774);
            ((intptr_t*)_2)[1] = _val_64774;
            _31845 = MAKE_SEQ(_1);
            _39ShowMsg(2LL, 349LL, _31845, 1LL);
            _31845 = NOVALUE;

            /** traninit.e:141						abort(1)*/
            UserCleanup(1LL);
            goto L3; // [202] 875

            /** traninit.e:144				case "cflags" then*/
            case 4:

            /** traninit.e:145					cflags = val*/
            Ref(_val_64774);
            DeRef(_56cflags_45407);
            _56cflags_45407 = _val_64774;
            goto L3; // [215] 875

            /** traninit.e:147				case "extra-cflags" then*/
            case 5:

            /** traninit.e:148					extra_cflags = val*/
            Ref(_val_64774);
            DeRef(_56extra_cflags_45408);
            _56extra_cflags_45408 = _val_64774;
            goto L3; // [228] 875

            /** traninit.e:150				case "lflags" then*/
            case 6:

            /** traninit.e:151					lflags = val*/
            Ref(_val_64774);
            DeRef(_56lflags_45409);
            _56lflags_45409 = _val_64774;
            goto L3; // [241] 875

            /** traninit.e:153				case "extra-lflags" then*/
            case 7:

            /** traninit.e:154					extra_lflags = val*/
            Ref(_val_64774);
            DeRef(_56extra_lflags_45410);
            _56extra_lflags_45410 = _val_64774;
            goto L3; // [254] 875

            /** traninit.e:156				case "wat" then*/
            case 8:

            /** traninit.e:157					compiler_type = COMPILER_WATCOM*/
            _56compiler_type_45389 = 2LL;
            goto L3; // [269] 875

            /** traninit.e:159				case "gcc" then*/
            case 9:

            /** traninit.e:160					compiler_type = COMPILER_GCC*/
            _56compiler_type_45389 = 1LL;
            goto L3; // [284] 875

            /** traninit.e:162				case "com" then*/
            case 10:

            /** traninit.e:163					compiler_dir = val*/
            Ref(_val_64774);
            DeRef(_56compiler_dir_45391);
            _56compiler_dir_45391 = _val_64774;
            goto L3; // [297] 875

            /** traninit.e:165				case "con" then*/
            case 11:

            /** traninit.e:166					con_option = TRUE*/
            _58con_option_42565 = _13TRUE_452;

            /** traninit.e:167					OpDefines &= { "CONSOLE" }*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            RefDS(_31846);
            ((intptr_t*)_2)[1] = _31846;
            _31847 = MAKE_SEQ(_1);
            Concat((object_ptr)&_36OpDefines_21516, _36OpDefines_21516, _31847);
            DeRefDS(_31847);
            _31847 = NOVALUE;
            goto L3; // [324] 875

            /** traninit.e:169				case "dll", "so" then*/
            case 12:
            case 13:

            /** traninit.e:170					dll_option = TRUE*/
            _58dll_option_42563 = _13TRUE_452;

            /** traninit.e:171					OpDefines &= { "EUC_DLL" }*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            RefDS(_31849);
            ((intptr_t*)_2)[1] = _31849;
            _31850 = MAKE_SEQ(_1);
            Concat((object_ptr)&_36OpDefines_21516, _36OpDefines_21516, _31850);
            DeRefDS(_31850);
            _31850 = NOVALUE;
            goto L3; // [353] 875

            /** traninit.e:173				case "plat" then*/
            case 14:

            /** traninit.e:174					switch upper(val) do*/
            Ref(_val_64774);
            _31852 = _14upper(_val_64774);
            _1 = find(_31852, _31853);
            DeRef(_31852);
            _31852 = NOVALUE;
            switch ( _1 ){ 

                /** traninit.e:178						case "WINDOWS" then*/
                case 1:

                /** traninit.e:179							set_host_platform( WIN32 )*/
                _46set_host_platform(2LL);
                goto L3; // [381] 875

                /** traninit.e:181						case "LINUX" then*/
                case 2:

                /** traninit.e:182							set_host_platform( ULINUX )*/
                _46set_host_platform(3LL);
                goto L3; // [394] 875

                /** traninit.e:184						case "FREEBSD" then*/
                case 3:

                /** traninit.e:185							set_host_platform( UFREEBSD )*/
                _46set_host_platform(8LL);
                goto L3; // [407] 875

                /** traninit.e:187						case "OSX" then*/
                case 4:

                /** traninit.e:188							set_host_platform( UOSX )*/
                _46set_host_platform(4LL);
                goto L3; // [420] 875

                /** traninit.e:190						case "OPENBSD" then*/
                case 5:

                /** traninit.e:191							set_host_platform( UOPENBSD )*/
                _46set_host_platform(6LL);
                goto L3; // [433] 875

                /** traninit.e:193						case "NETBSD" then*/
                case 6:

                /** traninit.e:194							set_host_platform( UNETBSD )*/
                _46set_host_platform(7LL);
                goto L3; // [446] 875

                /** traninit.e:196						case else*/
                case 0:

                /** traninit.e:197							ShowMsg(2, UNKNOWN_PLATFORM_1__SUPPORTED_PLATFORMS_ARE_2, { val, "WINDOWS, LINUX, FREEBSD, OSX, OPENBSD, NETBSD" })*/
                RefDS(_31861);
                Ref(_val_64774);
                _1 = NewS1(2);
                _2 = (object)((s1_ptr)_1)->base;
                ((intptr_t *)_2)[1] = _val_64774;
                ((intptr_t *)_2)[2] = _31861;
                _31862 = MAKE_SEQ(_1);
                _39ShowMsg(2LL, 201LL, _31862, 1LL);
                _31862 = NOVALUE;

                /** traninit.e:198							abort(1)*/
                UserCleanup(1LL);
            ;}            goto L3; // [471] 875

            /** traninit.e:201				case "lib" then*/
            case 15:

            /** traninit.e:202					user_library = canonical_path(val)*/
            Ref(_val_64774);
            _0 = _17canonical_path(_val_64774, 0LL, 0LL);
            DeRef(_58user_library_42575);
            _58user_library_42575 = _0;
            goto L3; // [487] 875

            /** traninit.e:204				case "lib-pic" then*/
            case 16:

            /** traninit.e:205					user_pic_library = canonical_path( val )*/
            Ref(_val_64774);
            _0 = _17canonical_path(_val_64774, 0LL, 0LL);
            DeRef(_58user_pic_library_42576);
            _58user_pic_library_42576 = _0;
            goto L3; // [503] 875

            /** traninit.e:207				case "stack" then*/
            case 17:

            /** traninit.e:208					sequence tmp = value(val)*/
            Ref(_val_64774);
            _0 = _tmp_64879;
            _tmp_64879 = _6value(_val_64774, 1LL, _6GET_SHORT_ANSWER_11168);
            DeRef(_0);

            /** traninit.e:209					if tmp[1] = GET_SUCCESS then*/
            _2 = (object)SEQ_PTR(_tmp_64879);
            _31866 = (object)*(((s1_ptr)_2)->base + 1LL);
            if (binary_op_a(NOTEQ, _31866, 0LL)){
                _31866 = NOVALUE;
                goto L4; // [529] 561
            }
            _31866 = NOVALUE;

            /** traninit.e:210						if tmp[2] >= 16384 then*/
            _2 = (object)SEQ_PTR(_tmp_64879);
            _31868 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (binary_op_a(LESS, _31868, 16384LL)){
                _31868 = NOVALUE;
                goto L5; // [539] 560
            }
            _31868 = NOVALUE;

            /** traninit.e:211							total_stack_size = floor(tmp[2] / 4) * 4*/
            _2 = (object)SEQ_PTR(_tmp_64879);
            _31870 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (IS_ATOM_INT(_31870)) {
                if (4LL > 0 && _31870 >= 0) {
                    _31871 = _31870 / 4LL;
                }
                else {
                    temp_dbl = EUFLOOR((eudouble)_31870 / (eudouble)4LL);
                    if (_31870 != MININT)
                    _31871 = (object)temp_dbl;
                    else
                    _31871 = NewDouble(temp_dbl);
                }
            }
            else {
                _2 = binary_op(DIVIDE, _31870, 4LL);
                _31871 = unary_op(FLOOR, _2);
                DeRef(_2);
            }
            _31870 = NOVALUE;
            if (IS_ATOM_INT(_31871)) {
                _58total_stack_size_42578 = _31871 * 4LL;
            }
            else {
                _58total_stack_size_42578 = binary_op(MULTIPLY, _31871, 4LL);
            }
            DeRef(_31871);
            _31871 = NOVALUE;
            if (!IS_ATOM_INT(_58total_stack_size_42578)) {
                _1 = (object)(DBL_PTR(_58total_stack_size_42578)->dbl);
                DeRefDS(_58total_stack_size_42578);
                _58total_stack_size_42578 = _1;
            }
L5: 
L4: 
            DeRef(_tmp_64879);
            _tmp_64879 = NOVALUE;
            goto L3; // [563] 875

            /** traninit.e:215				case "debug" then*/
            case 18:

            /** traninit.e:216					debug_option = TRUE*/
            _58debug_option_42573 = _13TRUE_452;

            /** traninit.e:217					keep = TRUE -- you'll need the sources to debug*/
            _58keep_42570 = _13TRUE_452;
            goto L3; // [583] 875

            /** traninit.e:219				case "maxsize" then*/
            case 19:

            /** traninit.e:220					sequence tmp = value(val)*/
            Ref(_val_64774);
            _0 = _tmp_64899;
            _tmp_64899 = _6value(_val_64774, 1LL, _6GET_SHORT_ANSWER_11168);
            DeRef(_0);

            /** traninit.e:221					if tmp[1] = GET_SUCCESS then*/
            _2 = (object)SEQ_PTR(_tmp_64899);
            _31874 = (object)*(((s1_ptr)_2)->base + 1LL);
            if (binary_op_a(NOTEQ, _31874, 0LL)){
                _31874 = NOVALUE;
                goto L6; // [609] 624
            }
            _31874 = NOVALUE;

            /** traninit.e:222						max_cfile_size = tmp[2]*/
            _2 = (object)SEQ_PTR(_tmp_64899);
            _56max_cfile_size_45405 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_56max_cfile_size_45405)){
                _56max_cfile_size_45405 = (object)DBL_PTR(_56max_cfile_size_45405)->dbl;
            }
            goto L7; // [621] 639
L6: 

            /** traninit.e:224						ShowMsg(2, INVALID_MAXIMUM_FILE_SIZE)*/
            RefDS(_21993);
            _39ShowMsg(2LL, 202LL, _21993, 1LL);

            /** traninit.e:225						abort(1)*/
            UserCleanup(1LL);
L7: 
            DeRef(_tmp_64899);
            _tmp_64899 = NOVALUE;
            goto L3; // [641] 875

            /** traninit.e:228				case "keep" then*/
            case 20:

            /** traninit.e:229					keep = TRUE*/
            _58keep_42570 = _13TRUE_452;
            goto L3; // [654] 875

            /** traninit.e:231				case "makefile-partial" then*/
            case 21:

            /** traninit.e:232					build_system_type = BUILD_MAKEFILE_PARTIAL*/
            _56build_system_type_45385 = 1LL;
            goto L3; // [669] 875

            /** traninit.e:234				case "makefile" then*/
            case 22:

            /** traninit.e:235					build_system_type = BUILD_MAKEFILE_FULL*/
            _56build_system_type_45385 = 2LL;
            goto L3; // [684] 875

            /** traninit.e:237				case "nobuild" then*/
            case 23:

            /** traninit.e:238					build_system_type = BUILD_NONE*/
            _56build_system_type_45385 = 0LL;
            goto L3; // [699] 875

            /** traninit.e:240				case "build-dir" then*/
            case 24:

            /** traninit.e:241					output_dir = val*/
            Ref(_val_64774);
            DeRef(_58output_dir_42577);
            _58output_dir_42577 = _val_64774;

            /** traninit.e:242					integer filetype = file_type( output_dir )*/
            RefDS(_58output_dir_42577);
            _filetype_64925 = _17file_type(_58output_dir_42577);
            if (!IS_ATOM_INT(_filetype_64925)) {
                _1 = (object)(DBL_PTR(_filetype_64925)->dbl);
                DeRefDS(_filetype_64925);
                _filetype_64925 = _1;
            }

            /** traninit.e:244					if filetype = FILETYPE_FILE then*/
            if (_filetype_64925 != 1LL)
            goto L8; // [726] 747

            /** traninit.e:245						ShowMsg( 2, BUILDDIR_IS_FILE )*/
            RefDS(_21993);
            _39ShowMsg(2LL, 605LL, _21993, 1LL);

            /** traninit.e:246						abort(1)*/
            UserCleanup(1LL);
            goto L9; // [744] 771
L8: 

            /** traninit.e:247					elsif filetype = FILETYPE_UNDEFINED then*/
            if (_filetype_64925 != -1LL)
            goto LA; // [751] 770

            /** traninit.e:248						ShowMsg( 2, BUILDDIR_IS_UNDEFINED )*/
            RefDS(_21993);
            _39ShowMsg(2LL, 606LL, _21993, 1LL);

            /** traninit.e:249						abort(1)*/
            UserCleanup(1LL);
LA: 
L9: 

            /** traninit.e:251					if find(output_dir[$], "/\\") = 0 then*/
            if (IS_SEQUENCE(_58output_dir_42577)){
                    _31880 = SEQ_PTR(_58output_dir_42577)->length;
            }
            else {
                _31880 = 1;
            }
            _2 = (object)SEQ_PTR(_58output_dir_42577);
            _31881 = (object)*(((s1_ptr)_2)->base + _31880);
            _31882 = find_from(_31881, _23901, 1LL);
            _31881 = NOVALUE;
            if (_31882 != 0LL)
            goto LB; // [787] 802

            /** traninit.e:252						output_dir &= '/'*/
            Append(&_58output_dir_42577, _58output_dir_42577, 47LL);
LB: 
            goto L3; // [804] 875

            /** traninit.e:255				case "force-build" then*/
            case 25:

            /** traninit.e:256					force_build = 1*/
            _56force_build_45411 = 1LL;
            goto L3; // [817] 875

            /** traninit.e:258				case "o" then*/
            case 26:

            /** traninit.e:259					exe_name[D_NAME] = val*/
            Ref(_val_64774);
            _2 = (object)SEQ_PTR(_56exe_name_45392);
            _2 = (object)(((s1_ptr)_2)->base + 1LL);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _val_64774;
            DeRef(_1);
            goto L3; // [833] 875

            /** traninit.e:261				case "no-cygwin" then*/
            case 27:

            /** traninit.e:262					mno_cygwin = 1*/
            _56mno_cygwin_45413 = 1LL;
            goto L3; // [846] 875

            /** traninit.e:264				case "arch" then*/
            case 28:

            /** traninit.e:265					set_target_arch( upper( val ) )*/
            Ref(_val_64774);
            _31885 = _14upper(_val_64774);
            _46set_target_arch(_31885);
            _31885 = NOVALUE;
            goto L3; // [861] 875

            /** traninit.e:267				case "cc-prefix" then*/
            case 29:

            /** traninit.e:268					compiler_prefix = val*/
            Ref(_val_64774);
            DeRef(_56compiler_prefix_45390);
            _56compiler_prefix_45390 = _val_64774;
        ;}L3: 
        DeRef(_key_64772);
        _key_64772 = NOVALUE;
        DeRef(_val_64774);
        _val_64774 = NOVALUE;

        /** traninit.e:271		end for*/
        _idx_64770 = _idx_64770 + 1LL;
        goto L1; // [879] 75
L2: 
        ;
    }

    /** traninit.e:274		if dll_option then*/
    if (_58dll_option_42563 == 0)
    {
        goto LC; // [888] 925
    }
    else{
    }

    /** traninit.e:275			if TX86_64  then*/
    if (_46TX86_64_21602 == 0)
    {
        goto LD; // [895] 911
    }
    else{
    }

    /** traninit.e:277				user_pic_library = check_library( user_pic_library )*/
    RefDS(_58user_pic_library_42576);
    _0 = _3check_library(_58user_pic_library_42576);
    DeRefDS(_58user_pic_library_42576);
    _58user_pic_library_42576 = _0;
    goto LE; // [908] 936
LD: 

    /** traninit.e:279				user_library = check_library( user_library )*/
    RefDS(_58user_library_42575);
    _0 = _3check_library(_58user_library_42575);
    DeRefDS(_58user_library_42575);
    _58user_library_42575 = _0;
    goto LE; // [922] 936
LC: 

    /** traninit.e:282			user_library = check_library( user_library )*/
    RefDS(_58user_library_42575);
    _0 = _3check_library(_58user_library_42575);
    DeRefDS(_58user_library_42575);
    _58user_library_42575 = _0;
LE: 

    /** traninit.e:285		if length(exe_name[D_NAME]) and not absolute_path(exe_name[D_NAME]) then*/
    _2 = (object)SEQ_PTR(_56exe_name_45392);
    _31889 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_31889)){
            _31890 = SEQ_PTR(_31889)->length;
    }
    else {
        _31890 = 1;
    }
    _31889 = NOVALUE;
    if (_31890 == 0) {
        goto LF; // [949] 1002
    }
    _2 = (object)SEQ_PTR(_56exe_name_45392);
    _31892 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_31892);
    _31893 = _17absolute_path(_31892);
    _31892 = NOVALUE;
    if (IS_ATOM_INT(_31893)) {
        _31894 = (_31893 == 0);
    }
    else {
        _31894 = unary_op(NOT, _31893);
    }
    DeRef(_31893);
    _31893 = NOVALUE;
    if (_31894 == 0) {
        DeRef(_31894);
        _31894 = NOVALUE;
        goto LF; // [969] 1002
    }
    else {
        if (!IS_ATOM_INT(_31894) && DBL_PTR(_31894)->dbl == 0.0){
            DeRef(_31894);
            _31894 = NOVALUE;
            goto LF; // [969] 1002
        }
        DeRef(_31894);
        _31894 = NOVALUE;
    }
    DeRef(_31894);
    _31894 = NOVALUE;

    /** traninit.e:286			exe_name[D_NAME] = current_dir() & SLASH & exe_name[D_NAME]*/
    _31895 = _17current_dir();
    _2 = (object)SEQ_PTR(_56exe_name_45392);
    _31896 = (object)*(((s1_ptr)_2)->base + 1LL);
    {
        object concat_list[3];

        concat_list[0] = _31896;
        concat_list[1] = 47LL;
        concat_list[2] = _31895;
        Concat_N((object_ptr)&_31897, concat_list, 3);
    }
    _31896 = NOVALUE;
    DeRef(_31895);
    _31895 = NOVALUE;
    _2 = (object)SEQ_PTR(_56exe_name_45392);
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31897;
    if( _1 != _31897 ){
        DeRef(_1);
    }
    _31897 = NOVALUE;
LF: 

    /** traninit.e:288		exe_name[D_ALTNAME] = adjust_for_command_line_passing(exe_name[D_NAME])*/
    _2 = (object)SEQ_PTR(_56exe_name_45392);
    _31898 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_31898);
    _31899 = _56adjust_for_command_line_passing(_31898);
    _31898 = NOVALUE;
    _2 = (object)SEQ_PTR(_56exe_name_45392);
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31899;
    if( _1 != _31899 ){
        DeRef(_1);
    }
    _31899 = NOVALUE;

    /** traninit.e:290		if length(map:get(opts, OPT_EXTRAS)) = 0 then*/
    Ref(_opts_64760);
    RefDS(_4OPT_EXTRAS_14180);
    _31900 = _29get(_opts_64760, _4OPT_EXTRAS_14180, 0LL);
    if (IS_SEQUENCE(_31900)){
            _31901 = SEQ_PTR(_31900)->length;
    }
    else {
        _31901 = 1;
    }
    DeRef(_31900);
    _31900 = NOVALUE;
    if (_31901 != 0LL)
    goto L10; // [1037] 1060

    /** traninit.e:292			show_banner()*/
    _49show_banner();

    /** traninit.e:293			ShowMsg(2, ERROR_MUST_SPECIFY_THE_FILE_TO_BE_TRANSLATED_ON_THE_COMMAND_LINE)*/
    RefDS(_21993);
    _39ShowMsg(2LL, 203LL, _21993, 1LL);

    /** traninit.e:296			abort(1)*/
    UserCleanup(1LL);
L10: 

    /** traninit.e:299		OpDefines &= { "EUC" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_31903);
    ((intptr_t*)_2)[1] = _31903;
    _31904 = MAKE_SEQ(_1);
    Concat((object_ptr)&_36OpDefines_21516, _36OpDefines_21516, _31904);
    DeRefDS(_31904);
    _31904 = NOVALUE;

    /** traninit.e:301		if host_platform() = WIN32 and not con_option then*/
    _31906 = _46host_platform();
    if (IS_ATOM_INT(_31906)) {
        _31907 = (_31906 == 2LL);
    }
    else {
        _31907 = binary_op(EQUALS, _31906, 2LL);
    }
    DeRef(_31906);
    _31906 = NOVALUE;
    if (IS_ATOM_INT(_31907)) {
        if (_31907 == 0) {
            goto L11; // [1085] 1111
        }
    }
    else {
        if (DBL_PTR(_31907)->dbl == 0.0) {
            goto L11; // [1085] 1111
        }
    }
    _31909 = (_58con_option_42565 == 0);
    if (_31909 == 0)
    {
        DeRef(_31909);
        _31909 = NOVALUE;
        goto L11; // [1095] 1111
    }
    else{
        DeRef(_31909);
        _31909 = NOVALUE;
    }

    /** traninit.e:302			OpDefines = append( OpDefines, "GUI" )*/
    RefDS(_31910);
    Append(&_36OpDefines_21516, _36OpDefines_21516, _31910);
    goto L12; // [1108] 1135
L11: 

    /** traninit.e:303		elsif not find( "CONSOLE", OpDefines ) then*/
    _31912 = find_from(_31846, _36OpDefines_21516, 1LL);
    if (_31912 != 0)
    goto L13; // [1120] 1134
    _31912 = NOVALUE;

    /** traninit.e:304			OpDefines = append( OpDefines, "CONSOLE" )*/
    RefDS(_31846);
    Append(&_36OpDefines_21516, _36OpDefines_21516, _31846);
L13: 
L12: 

    /** traninit.e:307		ifdef not EUDIS then*/

    /** traninit.e:308			if build_system_type = BUILD_DIRECT and length(output_dir) = 0 then*/
    _31915 = (_56build_system_type_45385 == 3LL);
    if (_31915 == 0) {
        goto L14; // [1147] 1245
    }
    if (IS_SEQUENCE(_58output_dir_42577)){
            _31917 = SEQ_PTR(_58output_dir_42577)->length;
    }
    else {
        _31917 = 1;
    }
    _31918 = (_31917 == 0LL);
    _31917 = NOVALUE;
    if (_31918 == 0)
    {
        DeRef(_31918);
        _31918 = NOVALUE;
        goto L14; // [1161] 1245
    }
    else{
        DeRef(_31918);
        _31918 = NOVALUE;
    }

    /** traninit.e:309				output_dir = temp_file("." & SLASH, "build-", "")*/
    Append(&_31919, _23183, 47LL);
    RefDS(_31920);
    RefDS(_21993);
    _0 = _17temp_file(_31919, _31920, _21993, 0LL);
    DeRef(_58output_dir_42577);
    _58output_dir_42577 = _0;
    _31919 = NOVALUE;

    /** traninit.e:310				if find(output_dir[$], "/\\") = 0 then*/
    if (IS_SEQUENCE(_58output_dir_42577)){
            _31922 = SEQ_PTR(_58output_dir_42577)->length;
    }
    else {
        _31922 = 1;
    }
    _2 = (object)SEQ_PTR(_58output_dir_42577);
    _31923 = (object)*(((s1_ptr)_2)->base + _31922);
    _31924 = find_from(_31923, _23901, 1LL);
    _31923 = NOVALUE;
    if (_31924 != 0LL)
    goto L15; // [1197] 1212

    /** traninit.e:311					output_dir &= '/'*/
    Append(&_58output_dir_42577, _58output_dir_42577, 47LL);
L15: 

    /** traninit.e:314				if not silent then*/
    if (_36silent_21558 != 0)
    goto L16; // [1216] 1237

    /** traninit.e:315					printf(1, "Build directory: %s\n", { abbreviate_path(output_dir) })*/
    RefDS(_58output_dir_42577);
    RefDS(_21993);
    _31929 = _17abbreviate_path(_58output_dir_42577, _21993);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _31929;
    _31930 = MAKE_SEQ(_1);
    _31929 = NOVALUE;
    EPrintf(1LL, _31928, _31930);
    DeRefDS(_31930);
    _31930 = NOVALUE;
L16: 

    /** traninit.e:318				remove_output_dir = 1*/
    _56remove_output_dir_45412 = 1LL;
L14: 

    /** traninit.e:322		if length(rc_file[D_NAME]) then*/
    _2 = (object)SEQ_PTR(_56rc_file_45398);
    _31931 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_31931)){
            _31932 = SEQ_PTR(_31931)->length;
    }
    else {
        _31932 = 1;
    }
    _31931 = NOVALUE;
    if (_31932 == 0)
    {
        _31932 = NOVALUE;
        goto L17; // [1258] 1320
    }
    else{
        _31932 = NOVALUE;
    }

    /** traninit.e:323			res_file[D_NAME] = canonical_path(output_dir & filebase(rc_file[D_NAME]) & ".res")*/
    _2 = (object)SEQ_PTR(_56rc_file_45398);
    _31933 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_31933);
    _31934 = _17filebase(_31933);
    _31933 = NOVALUE;
    {
        object concat_list[3];

        concat_list[0] = _31935;
        concat_list[1] = _31934;
        concat_list[2] = _58output_dir_42577;
        Concat_N((object_ptr)&_31936, concat_list, 3);
    }
    DeRef(_31934);
    _31934 = NOVALUE;
    _31937 = _17canonical_path(_31936, 0LL, 0LL);
    _31936 = NOVALUE;
    _2 = (object)SEQ_PTR(_56res_file_45404);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _56res_file_45404 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31937;
    if( _1 != _31937 ){
        DeRef(_1);
    }
    _31937 = NOVALUE;

    /** traninit.e:324			res_file[D_ALTNAME] = adjust_for_command_line_passing(res_file[D_NAME])*/
    _2 = (object)SEQ_PTR(_56res_file_45404);
    _31938 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_31938);
    _31939 = _56adjust_for_command_line_passing(_31938);
    _31938 = NOVALUE;
    _2 = (object)SEQ_PTR(_56res_file_45404);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _56res_file_45404 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31939;
    if( _1 != _31939 ){
        DeRef(_1);
    }
    _31939 = NOVALUE;
L17: 

    /** traninit.e:327		finalize_command_line(opts)*/
    Ref(_opts_64760);
    _49finalize_command_line(_opts_64760);

    /** traninit.e:328	end procedure*/
    DeRef(_tranopts_64748);
    DeRef(_opts_64760);
    DeRef(_opt_keys_64766);
    _31900 = NOVALUE;
    _31931 = NOVALUE;
    DeRef(_31907);
    _31907 = NOVALUE;
    _31889 = NOVALUE;
    DeRef(_31915);
    _31915 = NOVALUE;
    return;
    ;
}


void _3OpenCFiles()
{
    object _32001 = NOVALUE;
    object _31951 = NOVALUE;
    object _31945 = NOVALUE;
    object _31943 = NOVALUE;
    object _31942 = NOVALUE;
    object _31941 = NOVALUE;
    object _31940 = NOVALUE;
    object _0, _1, _2;
    

    /** traninit.e:333		if sequence(output_dir) and length(output_dir) > 0 then*/
    _31940 = 1;
    if (_31940 == 0) {
        goto L1; // [8] 38
    }
    if (IS_SEQUENCE(_58output_dir_42577)){
            _31942 = SEQ_PTR(_58output_dir_42577)->length;
    }
    else {
        _31942 = 1;
    }
    _31943 = (_31942 > 0LL);
    _31942 = NOVALUE;
    if (_31943 == 0)
    {
        DeRef(_31943);
        _31943 = NOVALUE;
        goto L1; // [22] 38
    }
    else{
        DeRef(_31943);
        _31943 = NOVALUE;
    }

    /** traninit.e:334			create_directory(output_dir)*/
    RefDS(_58output_dir_42577);
    _32001 = _17create_directory(_58output_dir_42577, 448LL, 1LL);
    DeRef(_32001);
    _32001 = NOVALUE;
L1: 

    /** traninit.e:337		c_code = open(output_dir & "init-.c", "w")*/
    Concat((object_ptr)&_31945, _58output_dir_42577, _31944);
    _55c_code_46623 = EOpen(_31945, _22129, 0LL);
    DeRefDS(_31945);
    _31945 = NOVALUE;

    /** traninit.e:338		if c_code = -1 then*/
    if (_55c_code_46623 != -1LL)
    goto L2; // [57] 71

    /** traninit.e:339			CompileErr(CANT_OPEN_INITC_FOR_OUTPUT)*/
    RefDS(_21993);
    _50CompileErr(55LL, _21993, 0LL);
L2: 

    /** traninit.e:342		add_file("init-.c")*/
    RefDS(_31944);
    RefDS(_21993);
    _58add_file(_31944, _21993);

    /** traninit.e:344		emit_c_output = TRUE*/
    _55emit_c_output_46620 = _13TRUE_452;

    /** traninit.e:346		c_puts("#include \"")*/
    RefDS(_31948);
    _55c_puts(_31948);

    /** traninit.e:347		c_puts("include/euphoria.h\"\n")*/
    RefDS(_31949);
    _55c_puts(_31949);

    /** traninit.e:349		c_puts("#include \"main-.h\"\n\n")*/
    RefDS(_22135);
    _55c_puts(_22135);

    /** traninit.e:350		c_h = open(output_dir & "main-.h", "w")*/
    Concat((object_ptr)&_31951, _58output_dir_42577, _31950);
    _55c_h_46624 = EOpen(_31951, _22129, 0LL);
    DeRefDS(_31951);
    _31951 = NOVALUE;

    /** traninit.e:351		if c_h = -1 then*/
    if (_55c_h_46624 != -1LL)
    goto L3; // [118] 132

    /** traninit.e:352			CompileErr(CANT_OPEN_MAINH_FILE_FOR_OUTPUT)*/
    RefDS(_21993);
    _50CompileErr(47LL, _21993, 0LL);
L3: 

    /** traninit.e:354		c_hputs("#include \"include/euphoria.h\"\n")*/
    RefDS(_22134);
    _55c_hputs(_22134);

    /** traninit.e:356		add_file("main-.h")*/
    RefDS(_31950);
    RefDS(_21993);
    _58add_file(_31950, _21993);

    /** traninit.e:357	end procedure*/
    return;
    ;
}


void _3InitBackEnd(object _c_65136)
{
    object _31984 = NOVALUE;
    object _31983 = NOVALUE;
    object _31981 = NOVALUE;
    object _31980 = NOVALUE;
    object _31979 = NOVALUE;
    object _31978 = NOVALUE;
    object _31977 = NOVALUE;
    object _31974 = NOVALUE;
    object _31973 = NOVALUE;
    object _31970 = NOVALUE;
    object _31969 = NOVALUE;
    object _31966 = NOVALUE;
    object _31965 = NOVALUE;
    object _31963 = NOVALUE;
    object _31960 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_c_65136)) {
        _1 = (object)(DBL_PTR(_c_65136)->dbl);
        DeRefDS(_c_65136);
        _c_65136 = _1;
    }

    /** traninit.e:363		if c = 1 then*/
    if (_c_65136 != 1LL)
    goto L1; // [5] 19

    /** traninit.e:364			OpenCFiles()*/
    _3OpenCFiles();

    /** traninit.e:366			return*/
    return;
L1: 

    /** traninit.e:369		init_opcodes()*/
    _59init_opcodes();

    /** traninit.e:370		transoptions()*/
    _3transoptions();

    /** traninit.e:372		if compiler_type = COMPILER_UNKNOWN then*/
    if (_56compiler_type_45389 != 0LL)
    goto L2; // [33] 75

    /** traninit.e:373			if TWINDOWS then*/
    if (_46TWINDOWS_21586 == 0)
    {
        goto L3; // [41] 56
    }
    else{
    }

    /** traninit.e:374				compiler_type = COMPILER_WATCOM*/
    _56compiler_type_45389 = 2LL;
    goto L4; // [53] 74
L3: 

    /** traninit.e:375			elsif TUNIX then*/
    if (_46TUNIX_21590 == 0)
    {
        goto L5; // [60] 73
    }
    else{
    }

    /** traninit.e:376				compiler_type = COMPILER_GCC*/
    _56compiler_type_45389 = 1LL;
L5: 
L4: 
L2: 

    /** traninit.e:380		switch compiler_type do*/
    _0 = _56compiler_type_45389;
    switch ( _0 ){ 

        /** traninit.e:381		  	case COMPILER_GCC then*/
        case 1:

        /** traninit.e:383				break -- to avoid empty block warning*/
        goto L6; // [90] 334
        goto L6; // [92] 334

        /** traninit.e:385			case COMPILER_WATCOM then*/
        case 2:

        /** traninit.e:386				wat_path = getenv("WATCOM")*/
        DeRefi(_36wat_path_21520);
        _36wat_path_21520 = EGetEnv(_31958);

        /** traninit.e:388				if atom(wat_path) then*/
        _31960 = IS_ATOM(_36wat_path_21520);
        if (_31960 == 0)
        {
            _31960 = NOVALUE;
            goto L7; // [110] 148
        }
        else{
            _31960 = NOVALUE;
        }

        /** traninit.e:389					if build_system_type = BUILD_DIRECT then*/
        if (_56build_system_type_45385 != 3LL)
        goto L8; // [119] 135

        /** traninit.e:392						CompileErr(WATCOM_ENVIRONMENT_VARIABLE_IS_NOT_SET)*/
        RefDS(_21993);
        _50CompileErr(159LL, _21993, 0LL);
        goto L6; // [132] 334
L8: 

        /** traninit.e:397						Warning(159, translator_warning_flag)*/
        RefDS(_21993);
        _50Warning(159LL, 128LL, _21993);
        goto L6; // [145] 334
L7: 

        /** traninit.e:399				elsif find(' ', wat_path) then*/
        _31963 = find_from(32LL, _36wat_path_21520, 1LL);
        if (_31963 == 0)
        {
            _31963 = NOVALUE;
            goto L9; // [157] 172
        }
        else{
            _31963 = NOVALUE;
        }

        /** traninit.e:400					Warning( 214, translator_warning_flag)*/
        RefDS(_21993);
        _50Warning(214LL, 128LL, _21993);
        goto L6; // [169] 334
L9: 

        /** traninit.e:401				elsif atom(getenv("INCLUDE")) then*/
        _31965 = EGetEnv(_31964);
        _31966 = IS_ATOM(_31965);
        DeRef(_31965);
        _31965 = NOVALUE;
        if (_31966 == 0)
        {
            _31966 = NOVALUE;
            goto LA; // [180] 195
        }
        else{
            _31966 = NOVALUE;
        }

        /** traninit.e:402					Warning( 215, translator_warning_flag )*/
        RefDS(_21993);
        _50Warning(215LL, 128LL, _21993);
        goto L6; // [192] 334
LA: 

        /** traninit.e:403				elsif not file_exists(wat_path & SLASH & "binnt" & SLASH & "wcc386.exe") then*/
        {
            object concat_list[5];

            concat_list[0] = _31968;
            concat_list[1] = 47LL;
            concat_list[2] = _31967;
            concat_list[3] = 47LL;
            concat_list[4] = _36wat_path_21520;
            Concat_N((object_ptr)&_31969, concat_list, 5);
        }
        _31970 = _17file_exists(_31969);
        _31969 = NOVALUE;
        if (IS_ATOM_INT(_31970)) {
            if (_31970 != 0){
                DeRef(_31970);
                _31970 = NOVALUE;
                goto LB; // [215] 265
            }
        }
        else {
            if (DBL_PTR(_31970)->dbl != 0.0){
                DeRef(_31970);
                _31970 = NOVALUE;
                goto LB; // [215] 265
            }
        }
        DeRef(_31970);
        _31970 = NOVALUE;

        /** traninit.e:404					if build_system_type = BUILD_DIRECT then*/
        if (_56build_system_type_45385 != 3LL)
        goto LC; // [224] 246

        /** traninit.e:405						CompileErr( THERE_IS_NO_WATCOM_INSTALATION_UNDER_SPECIFIED_WATOM_PATH_1, {wat_path})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_36wat_path_21520);
        ((intptr_t*)_2)[1] = _36wat_path_21520;
        _31973 = MAKE_SEQ(_1);
        _50CompileErr(352LL, _31973, 0LL);
        _31973 = NOVALUE;
        goto L6; // [243] 334
LC: 

        /** traninit.e:407						Warning( 352, translator_warning_flag, {wat_path})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_36wat_path_21520);
        ((intptr_t*)_2)[1] = _36wat_path_21520;
        _31974 = MAKE_SEQ(_1);
        _50Warning(352LL, 128LL, _31974);
        _31974 = NOVALUE;
        goto L6; // [262] 334
LB: 

        /** traninit.e:409				elsif match(upper(wat_path & "\\H;" & wat_path & "\\H\\NT"),*/
        {
            object concat_list[4];

            concat_list[0] = _31976;
            concat_list[1] = _36wat_path_21520;
            concat_list[2] = _31975;
            concat_list[3] = _36wat_path_21520;
            Concat_N((object_ptr)&_31977, concat_list, 4);
        }
        _31978 = _14upper(_31977);
        _31977 = NOVALUE;
        _31979 = EGetEnv(_31964);
        _31980 = _14upper(_31979);
        _31979 = NOVALUE;
        _31981 = e_match_from(_31978, _31980, 1LL);
        DeRef(_31978);
        _31978 = NOVALUE;
        DeRef(_31980);
        _31980 = NOVALUE;
        if (_31981 == 1LL)
        goto L6; // [294] 334

        /** traninit.e:412					Warning( 216, translator_warning_flag, {wat_path,getenv("INCLUDE")} )*/
        _31983 = EGetEnv(_31964);
        Ref(_36wat_path_21520);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _36wat_path_21520;
        ((intptr_t *)_2)[2] = _31983;
        _31984 = MAKE_SEQ(_1);
        _31983 = NOVALUE;
        _50Warning(216LL, 128LL, _31984);
        _31984 = NOVALUE;
        goto L6; // [318] 334

        /** traninit.e:415			case else*/
        default:

        /** traninit.e:416				CompileErr(UNKNOWN_COMPILER)*/
        RefDS(_21993);
        _50CompileErr(150LL, _21993, 0LL);
    ;}L6: 

    /** traninit.e:419	end procedure*/
    return;
    ;
}


void _3CheckPlatform()
{
    object _31990 = NOVALUE;
    object _31988 = NOVALUE;
    object _31987 = NOVALUE;
    object _0, _1, _2;
    

    /** traninit.e:425		OpDefines = eu:remove(OpDefines,*/
    _31987 = find_from(_25339, _36OpDefines_21516, 1LL);
    _31988 = find_from(_25340, _36OpDefines_21516, 1LL);
    {
        s1_ptr assign_space = SEQ_PTR(_36OpDefines_21516);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_31987)) ? _31987 : (object)(DBL_PTR(_31987)->dbl);
        int stop = (IS_ATOM_INT(_31988)) ? _31988 : (object)(DBL_PTR(_31988)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_36OpDefines_21516), start, &_36OpDefines_21516 );
            }
            else Tail(SEQ_PTR(_36OpDefines_21516), stop+1, &_36OpDefines_21516);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_36OpDefines_21516), start, &_36OpDefines_21516);
        }
        else {
            assign_slice_seq = &assign_space;
            _36OpDefines_21516 = Remove_elements(start, stop, (SEQ_PTR(_36OpDefines_21516)->ref == 1));
        }
    }
    _31987 = NOVALUE;
    _31988 = NOVALUE;

    /** traninit.e:428		OpDefines &= GetPlatformDefines(1)*/
    _31990 = _46GetPlatformDefines(1LL);
    if (IS_SEQUENCE(_36OpDefines_21516) && IS_ATOM(_31990)) {
        Ref(_31990);
        Append(&_36OpDefines_21516, _36OpDefines_21516, _31990);
    }
    else if (IS_ATOM(_36OpDefines_21516) && IS_SEQUENCE(_31990)) {
    }
    else {
        Concat((object_ptr)&_36OpDefines_21516, _36OpDefines_21516, _31990);
    }
    DeRef(_31990);
    _31990 = NOVALUE;

    /** traninit.e:429	end procedure*/
    return;
    ;
}


object _3check_library(object _lib_65253)
{
    object _32000 = NOVALUE;
    object _31999 = NOVALUE;
    object _31997 = NOVALUE;
    object _31995 = NOVALUE;
    object _31994 = NOVALUE;
    object _0, _1, _2;
    

    /** traninit.e:433		if equal( lib, "" ) then*/
    if (_lib_65253 == _21993)
    _31994 = 1;
    else if (IS_ATOM_INT(_lib_65253) && IS_ATOM_INT(_21993))
    _31994 = 0;
    else
    _31994 = (compare(_lib_65253, _21993) == 0);
    if (_31994 == 0)
    {
        _31994 = NOVALUE;
        goto L1; // [9] 19
    }
    else{
        _31994 = NOVALUE;
    }

    /** traninit.e:434			return ""*/
    RefDS(_21993);
    DeRefDS(_lib_65253);
    return _21993;
L1: 

    /** traninit.e:437		if not file_exists( lib ) then*/
    RefDS(_lib_65253);
    _31995 = _17file_exists(_lib_65253);
    if (IS_ATOM_INT(_31995)) {
        if (_31995 != 0){
            DeRef(_31995);
            _31995 = NOVALUE;
            goto L2; // [25] 69
        }
    }
    else {
        if (DBL_PTR(_31995)->dbl != 0.0){
            DeRef(_31995);
            _31995 = NOVALUE;
            goto L2; // [25] 69
        }
    }
    DeRef(_31995);
    _31995 = NOVALUE;

    /** traninit.e:438			ShowMsg(2, USER_SUPPLIED_LIBRARY_DOES_NOT_EXIST__1, { lib })*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_lib_65253);
    ((intptr_t*)_2)[1] = _lib_65253;
    _31997 = MAKE_SEQ(_1);
    _39ShowMsg(2LL, 348LL, _31997, 1LL);
    _31997 = NOVALUE;

    /** traninit.e:439			if force_build or build_system_type = BUILD_DIRECT then*/
    if (_56force_build_45411 != 0) {
        goto L3; // [46] 63
    }
    _31999 = (_56build_system_type_45385 == 3LL);
    if (_31999 == 0)
    {
        DeRef(_31999);
        _31999 = NOVALUE;
        goto L4; // [59] 68
    }
    else{
        DeRef(_31999);
        _31999 = NOVALUE;
    }
L3: 

    /** traninit.e:440				abort(1)*/
    UserCleanup(1LL);
L4: 
L2: 

    /** traninit.e:443		return canonical_path( lib )*/
    RefDS(_lib_65253);
    _32000 = _17canonical_path(_lib_65253, 0LL, 0LL);
    DeRefDS(_lib_65253);
    return _32000;
    ;
}



// 0x496EBD37
