// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _49add_options(object _new_options_49723)
{
    object _0, _1, _2;
    

    /** cominit.e:65		options = splice(options, new_options, COMMON_OPTIONS_SPLICE_IDX)*/
    {
        s1_ptr assign_space;
        insert_pos = 16LL;
        if (insert_pos <= 0) {
            Concat(&_49options_49719,_new_options_49723,_49options_49719);
        }
        else if (insert_pos > SEQ_PTR(_49options_49719)->length){
            Concat(&_49options_49719,_49options_49719,_new_options_49723);
        }
        else if (IS_SEQUENCE(_new_options_49723)) {
            if( _49options_49719 != _49options_49719 || SEQ_PTR( _49options_49719 )->ref != 1 ){
                DeRef( _49options_49719 );
                RefDS( _49options_49719 );
            }
            assign_space = Add_internal_space( _49options_49719, insert_pos,((s1_ptr)SEQ_PTR(_new_options_49723))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_new_options_49723), _49options_49719 == _49options_49719 );
            _49options_49719 = MAKE_SEQ( assign_space );
        }
        else {
            if( _49options_49719 == _49options_49719 && SEQ_PTR( _49options_49719 )->ref == 1 ){
                _49options_49719 = Insert( _49options_49719, _new_options_49723, insert_pos);
            }
            else {
                DeRef( _49options_49719 );
                RefDS( _49options_49719 );
                _49options_49719 = Insert( _49options_49719, _new_options_49723, insert_pos);
            }
        }
    }

    /** cominit.e:67	end procedure*/
    DeRefDS(_new_options_49723);
    return;
    ;
}


object _49get_options()
{
    object _0, _1, _2;
    

    /** cominit.e:73		return options*/
    RefDS(_49options_49719);
    return _49options_49719;
    ;
}


object _49get_switches()
{
    object _0, _1, _2;
    

    /** cominit.e:87		return switches*/
    RefDS(_49switches_49592);
    return _49switches_49592;
    ;
}


void _49show_copyrights()
{
    object _notices_49733 = NOVALUE;
    object _25499 = NOVALUE;
    object _25498 = NOVALUE;
    object _25496 = NOVALUE;
    object _25495 = NOVALUE;
    object _25494 = NOVALUE;
    object _25493 = NOVALUE;
    object _25491 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:94		sequence notices = all_copyrights()*/
    _0 = _notices_49733;
    _notices_49733 = _33all_copyrights();
    DeRef(_0);

    /** cominit.e:95		for i = 1 to length(notices) do*/
    if (IS_SEQUENCE(_notices_49733)){
            _25491 = SEQ_PTR(_notices_49733)->length;
    }
    else {
        _25491 = 1;
    }
    {
        object _i_49737;
        _i_49737 = 1LL;
L1: 
        if (_i_49737 > _25491){
            goto L2; // [13] 60
        }

        /** cominit.e:96			printf(2, "%s\n  %s\n\n", { notices[i][1], match_replace("\n", notices[i][2], "\n  ") })*/
        _2 = (object)SEQ_PTR(_notices_49733);
        _25493 = (object)*(((s1_ptr)_2)->base + _i_49737);
        _2 = (object)SEQ_PTR(_25493);
        _25494 = (object)*(((s1_ptr)_2)->base + 1LL);
        _25493 = NOVALUE;
        _2 = (object)SEQ_PTR(_notices_49733);
        _25495 = (object)*(((s1_ptr)_2)->base + _i_49737);
        _2 = (object)SEQ_PTR(_25495);
        _25496 = (object)*(((s1_ptr)_2)->base + 2LL);
        _25495 = NOVALUE;
        RefDS(_22188);
        Ref(_25496);
        RefDS(_25497);
        _25498 = _16match_replace(_22188, _25496, _25497, 0LL);
        _25496 = NOVALUE;
        Ref(_25494);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _25494;
        ((intptr_t *)_2)[2] = _25498;
        _25499 = MAKE_SEQ(_1);
        _25498 = NOVALUE;
        _25494 = NOVALUE;
        EPrintf(2LL, _25492, _25499);
        DeRefDS(_25499);
        _25499 = NOVALUE;

        /** cominit.e:97		end for*/
        _i_49737 = _i_49737 + 1LL;
        goto L1; // [55] 20
L2: 
        ;
    }

    /** cominit.e:98	end procedure*/
    DeRef(_notices_49733);
    return;
    ;
}


void _49show_banner()
{
    object _version_type_inlined_version_type_at_220_49806 = NOVALUE;
    object _version_string_short_1__tmp_at204_49804 = NOVALUE;
    object _version_string_short_inlined_version_string_short_at_204_49803 = NOVALUE;
    object _version_revision_inlined_version_revision_at_133_49784 = NOVALUE;
    object _platform_name_inlined_platform_name_at_94_49776 = NOVALUE;
    object _prod_name_49750 = NOVALUE;
    object _memory_type_49751 = NOVALUE;
    object _misc_info_49773 = NOVALUE;
    object _EuConsole_49788 = NOVALUE;
    object _25524 = NOVALUE;
    object _25523 = NOVALUE;
    object _25522 = NOVALUE;
    object _25519 = NOVALUE;
    object _25518 = NOVALUE;
    object _25514 = NOVALUE;
    object _25513 = NOVALUE;
    object _25512 = NOVALUE;
    object _25510 = NOVALUE;
    object _25508 = NOVALUE;
    object _25507 = NOVALUE;
    object _25506 = NOVALUE;
    object _25501 = NOVALUE;
    object _25500 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:109		if INTERPRET and not BIND then*/
    if (_36INTERPRET_21038 == 0) {
        goto L1; // [5] 33
    }
    _25501 = (_36BIND_21044 == 0);
    if (_25501 == 0)
    {
        DeRef(_25501);
        _25501 = NOVALUE;
        goto L1; // [15] 33
    }
    else{
        DeRef(_25501);
        _25501 = NOVALUE;
    }

    /** cominit.e:110			prod_name = GetMsgText(EUPHORIA_INTERPRETER,0)*/
    RefDS(_21993);
    _0 = _prod_name_49750;
    _prod_name_49750 = _39GetMsgText(270LL, 0LL, _21993);
    DeRef(_0);
    goto L2; // [30] 76
L1: 

    /** cominit.e:112		elsif TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L3; // [37] 55
    }
    else{
    }

    /** cominit.e:113			prod_name = GetMsgText(EUPHORIA_TO_C_TRANSLATOR,0)*/
    RefDS(_21993);
    _0 = _prod_name_49750;
    _prod_name_49750 = _39GetMsgText(271LL, 0LL, _21993);
    DeRef(_0);
    goto L2; // [52] 76
L3: 

    /** cominit.e:115		elsif BIND then*/
    if (_36BIND_21044 == 0)
    {
        goto L4; // [59] 75
    }
    else{
    }

    /** cominit.e:116			prod_name = GetMsgText(EUPHORIA_BINDER,0)*/
    RefDS(_21993);
    _0 = _prod_name_49750;
    _prod_name_49750 = _39GetMsgText(272LL, 0LL, _21993);
    DeRef(_0);
L4: 
L2: 

    /** cominit.e:119		ifdef EU_MANAGED_MEM then*/

    /** cominit.e:122			memory_type = GetMsgText(USING_SYSTEM_MEMORY,0)*/
    RefDS(_21993);
    _0 = _memory_type_49751;
    _memory_type_49751 = _39GetMsgText(274LL, 0LL, _21993);
    DeRef(_0);

    /** cominit.e:125		sequence misc_info = {*/
    _25506 = _33arch_bits();

    /** info.e:48		ifdef WINDOWS then*/

    /** info.e:51			return "Linux"*/
    RefDS(_6723);
    DeRefi(_platform_name_inlined_platform_name_at_94_49776);
    _platform_name_inlined_platform_name_at_94_49776 = _6723;
    _25507 = _33version_date(0LL);
    _25508 = _33version_node(0LL);
    _0 = _misc_info_49773;
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _25506;
    RefDS(_platform_name_inlined_platform_name_at_94_49776);
    ((intptr_t*)_2)[2] = _platform_name_inlined_platform_name_at_94_49776;
    RefDS(_memory_type_49751);
    ((intptr_t*)_2)[3] = _memory_type_49751;
    RefDS(_21993);
    ((intptr_t*)_2)[4] = _21993;
    ((intptr_t*)_2)[5] = _25507;
    ((intptr_t*)_2)[6] = _25508;
    _misc_info_49773 = MAKE_SEQ(_1);
    DeRef(_0);
    _25508 = NOVALUE;
    _25507 = NOVALUE;
    _25506 = NOVALUE;

    /** cominit.e:134		if info:is_developmental then*/
    if (_33is_developmental_11979 == 0)
    {
        goto L5; // [126] 160
    }
    else{
    }

    /** cominit.e:135			misc_info[$] = sprintf("%d:%s", { info:version_revision(), info:version_node() })*/
    _25510 = 6;

    /** info.e:157		return version_info[REVISION]*/
    DeRef(_version_revision_inlined_version_revision_at_133_49784);
    _2 = (object)SEQ_PTR(_33version_info_11977);
    _version_revision_inlined_version_revision_at_133_49784 = (object)*(((s1_ptr)_2)->base + 6LL);
    Ref(_version_revision_inlined_version_revision_at_133_49784);
    _25512 = _33version_node(0LL);
    Ref(_version_revision_inlined_version_revision_at_133_49784);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _version_revision_inlined_version_revision_at_133_49784;
    ((intptr_t *)_2)[2] = _25512;
    _25513 = MAKE_SEQ(_1);
    _25512 = NOVALUE;
    _25514 = EPrintf(-9999999, _25511, _25513);
    DeRefDS(_25513);
    _25513 = NOVALUE;
    _2 = (object)SEQ_PTR(_misc_info_49773);
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25514;
    if( _1 != _25514 ){
        DeRef(_1);
    }
    _25514 = NOVALUE;
L5: 

    /** cominit.e:138		object EuConsole = getenv("EUCONS")*/
    DeRefi(_EuConsole_49788);
    _EuConsole_49788 = EGetEnv(_25515);

    /** cominit.e:139		if equal(EuConsole, "1") then*/
    if (_EuConsole_49788 == _25517)
    _25518 = 1;
    else if (IS_ATOM_INT(_EuConsole_49788) && IS_ATOM_INT(_25517))
    _25518 = 0;
    else
    _25518 = (compare(_EuConsole_49788, _25517) == 0);
    if (_25518 == 0)
    {
        _25518 = NOVALUE;
        goto L6; // [171] 191
    }
    else{
        _25518 = NOVALUE;
    }

    /** cominit.e:140			misc_info[4] = GetMsgText(EUCONSOLE,0)*/
    RefDS(_21993);
    _25519 = _39GetMsgText(275LL, 0LL, _21993);
    _2 = (object)SEQ_PTR(_misc_info_49773);
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25519;
    if( _1 != _25519 ){
        DeRef(_1);
    }
    _25519 = NOVALUE;
    goto L7; // [188] 199
L6: 

    /** cominit.e:142			misc_info = remove(misc_info, 4)*/
    {
        s1_ptr assign_space = SEQ_PTR(_misc_info_49773);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(4LL)) ? 4LL : (object)(DBL_PTR(4LL)->dbl);
        int stop = (IS_ATOM_INT(4LL)) ? 4LL : (object)(DBL_PTR(4LL)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_misc_info_49773), start, &_misc_info_49773 );
            }
            else Tail(SEQ_PTR(_misc_info_49773), stop+1, &_misc_info_49773);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_misc_info_49773), start, &_misc_info_49773);
        }
        else {
            assign_slice_seq = &assign_space;
            _misc_info_49773 = Remove_elements(start, stop, (SEQ_PTR(_misc_info_49773)->ref == 1));
        }
    }
L7: 

    /** cominit.e:145		screen_output(STDERR, sprintf("%s v%s %s\n   %s %s, %s\n   Revision Date: %s, Id: %s\n", {*/

    /** info.e:261		return sprintf("%d.%d.%d", version_info[MAJ_VER..PAT_VER])*/
    rhs_slice_target = (object_ptr)&_version_string_short_1__tmp_at204_49804;
    RHS_Slice(_33version_info_11977, 1LL, 3LL);
    DeRefi(_version_string_short_inlined_version_string_short_at_204_49803);
    _version_string_short_inlined_version_string_short_at_204_49803 = EPrintf(-9999999, _6780, _version_string_short_1__tmp_at204_49804);
    DeRef(_version_string_short_1__tmp_at204_49804);
    _version_string_short_1__tmp_at204_49804 = NOVALUE;

    /** info.e:202		return version_info[VER_TYPE]*/
    DeRef(_version_type_inlined_version_type_at_220_49806);
    _2 = (object)SEQ_PTR(_33version_info_11977);
    _version_type_inlined_version_type_at_220_49806 = (object)*(((s1_ptr)_2)->base + 4LL);
    Ref(_version_type_inlined_version_type_at_220_49806);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_prod_name_49750);
    ((intptr_t*)_2)[1] = _prod_name_49750;
    RefDS(_version_string_short_inlined_version_string_short_at_204_49803);
    ((intptr_t*)_2)[2] = _version_string_short_inlined_version_string_short_at_204_49803;
    Ref(_version_type_inlined_version_type_at_220_49806);
    ((intptr_t*)_2)[3] = _version_type_inlined_version_type_at_220_49806;
    _25522 = MAKE_SEQ(_1);
    Concat((object_ptr)&_25523, _25522, _misc_info_49773);
    DeRefDS(_25522);
    _25522 = NOVALUE;
    DeRef(_25522);
    _25522 = NOVALUE;
    _25524 = EPrintf(-9999999, _25521, _25523);
    DeRefDS(_25523);
    _25523 = NOVALUE;
    _50screen_output(2LL, _25524);
    _25524 = NOVALUE;

    /** cominit.e:147	end procedure*/
    DeRefDS(_prod_name_49750);
    DeRef(_memory_type_49751);
    DeRefDS(_misc_info_49773);
    DeRefi(_EuConsole_49788);
    return;
    ;
}


object _49find_opt(object _name_type_49818, object _opt_49819, object _opts_49820)
{
    object _o_49824 = NOVALUE;
    object _has_case_49826 = NOVALUE;
    object _25537 = NOVALUE;
    object _25536 = NOVALUE;
    object _25535 = NOVALUE;
    object _25534 = NOVALUE;
    object _25533 = NOVALUE;
    object _25532 = NOVALUE;
    object _25531 = NOVALUE;
    object _25530 = NOVALUE;
    object _25529 = NOVALUE;
    object _25527 = NOVALUE;
    object _25525 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:172		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_49820)){
            _25525 = SEQ_PTR(_opts_49820)->length;
    }
    else {
        _25525 = 1;
    }
    {
        object _i_49822;
        _i_49822 = 1LL;
L1: 
        if (_i_49822 > _25525){
            goto L2; // [12] 113
        }

        /** cominit.e:173			sequence o = opts[i]		*/
        DeRef(_o_49824);
        _2 = (object)SEQ_PTR(_opts_49820);
        _o_49824 = (object)*(((s1_ptr)_2)->base + _i_49822);
        Ref(_o_49824);

        /** cominit.e:174			integer has_case = find(HAS_CASE, o[OPTIONS])*/
        _2 = (object)SEQ_PTR(_o_49824);
        _25527 = (object)*(((s1_ptr)_2)->base + 4LL);
        _has_case_49826 = find_from(99LL, _25527, 1LL);
        _25527 = NOVALUE;

        /** cominit.e:176			if has_case and equal(o[name_type], opt) then*/
        if (_has_case_49826 == 0) {
            goto L3; // [42] 67
        }
        _2 = (object)SEQ_PTR(_o_49824);
        _25530 = (object)*(((s1_ptr)_2)->base + _name_type_49818);
        if (_25530 == _opt_49819)
        _25531 = 1;
        else if (IS_ATOM_INT(_25530) && IS_ATOM_INT(_opt_49819))
        _25531 = 0;
        else
        _25531 = (compare(_25530, _opt_49819) == 0);
        _25530 = NOVALUE;
        if (_25531 == 0)
        {
            _25531 = NOVALUE;
            goto L3; // [55] 67
        }
        else{
            _25531 = NOVALUE;
        }

        /** cominit.e:177				return o*/
        DeRefDS(_opt_49819);
        DeRefDS(_opts_49820);
        return _o_49824;
        goto L4; // [64] 104
L3: 

        /** cominit.e:178			elsif not has_case and equal(text:lower(o[name_type]), text:lower(opt)) then*/
        _25532 = (_has_case_49826 == 0);
        if (_25532 == 0) {
            goto L5; // [72] 103
        }
        _2 = (object)SEQ_PTR(_o_49824);
        _25534 = (object)*(((s1_ptr)_2)->base + _name_type_49818);
        Ref(_25534);
        _25535 = _14lower(_25534);
        _25534 = NOVALUE;
        RefDS(_opt_49819);
        _25536 = _14lower(_opt_49819);
        if (_25535 == _25536)
        _25537 = 1;
        else if (IS_ATOM_INT(_25535) && IS_ATOM_INT(_25536))
        _25537 = 0;
        else
        _25537 = (compare(_25535, _25536) == 0);
        DeRef(_25535);
        _25535 = NOVALUE;
        DeRef(_25536);
        _25536 = NOVALUE;
        if (_25537 == 0)
        {
            _25537 = NOVALUE;
            goto L5; // [93] 103
        }
        else{
            _25537 = NOVALUE;
        }

        /** cominit.e:179				return o*/
        DeRefDS(_opt_49819);
        DeRefDS(_opts_49820);
        DeRef(_25532);
        _25532 = NOVALUE;
        return _o_49824;
L5: 
L4: 
        DeRef(_o_49824);
        _o_49824 = NOVALUE;

        /** cominit.e:181		end for*/
        _i_49822 = _i_49822 + 1LL;
        goto L1; // [108] 19
L2: 
        ;
    }

    /** cominit.e:183		return {}*/
    RefDS(_21993);
    DeRefDS(_opt_49819);
    DeRefDS(_opts_49820);
    DeRef(_25532);
    _25532 = NOVALUE;
    return _21993;
    ;
}


object _49merge_parameters(object _a_49843, object _b_49844, object _opts_49845, object _dedupe_49846)
{
    object _i_49847 = NOVALUE;
    object _opt_49851 = NOVALUE;
    object _this_opt_49857 = NOVALUE;
    object _bi_49858 = NOVALUE;
    object _beginLen_49918 = NOVALUE;
    object _first_extra_49940 = NOVALUE;
    object _opt_49944 = NOVALUE;
    object _this_opt_49949 = NOVALUE;
    object _25631 = NOVALUE;
    object _25630 = NOVALUE;
    object _25627 = NOVALUE;
    object _25626 = NOVALUE;
    object _25625 = NOVALUE;
    object _25623 = NOVALUE;
    object _25622 = NOVALUE;
    object _25621 = NOVALUE;
    object _25620 = NOVALUE;
    object _25618 = NOVALUE;
    object _25617 = NOVALUE;
    object _25615 = NOVALUE;
    object _25614 = NOVALUE;
    object _25613 = NOVALUE;
    object _25612 = NOVALUE;
    object _25611 = NOVALUE;
    object _25610 = NOVALUE;
    object _25609 = NOVALUE;
    object _25607 = NOVALUE;
    object _25604 = NOVALUE;
    object _25603 = NOVALUE;
    object _25598 = NOVALUE;
    object _25596 = NOVALUE;
    object _25595 = NOVALUE;
    object _25594 = NOVALUE;
    object _25593 = NOVALUE;
    object _25592 = NOVALUE;
    object _25591 = NOVALUE;
    object _25590 = NOVALUE;
    object _25589 = NOVALUE;
    object _25585 = NOVALUE;
    object _25584 = NOVALUE;
    object _25583 = NOVALUE;
    object _25582 = NOVALUE;
    object _25581 = NOVALUE;
    object _25580 = NOVALUE;
    object _25579 = NOVALUE;
    object _25578 = NOVALUE;
    object _25577 = NOVALUE;
    object _25576 = NOVALUE;
    object _25575 = NOVALUE;
    object _25574 = NOVALUE;
    object _25573 = NOVALUE;
    object _25572 = NOVALUE;
    object _25571 = NOVALUE;
    object _25569 = NOVALUE;
    object _25568 = NOVALUE;
    object _25567 = NOVALUE;
    object _25566 = NOVALUE;
    object _25565 = NOVALUE;
    object _25564 = NOVALUE;
    object _25563 = NOVALUE;
    object _25562 = NOVALUE;
    object _25560 = NOVALUE;
    object _25559 = NOVALUE;
    object _25558 = NOVALUE;
    object _25557 = NOVALUE;
    object _25555 = NOVALUE;
    object _25554 = NOVALUE;
    object _25553 = NOVALUE;
    object _25552 = NOVALUE;
    object _25551 = NOVALUE;
    object _25550 = NOVALUE;
    object _25549 = NOVALUE;
    object _25547 = NOVALUE;
    object _25546 = NOVALUE;
    object _25544 = NOVALUE;
    object _25541 = NOVALUE;
    object _25538 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:199		integer i = 1*/
    _i_49847 = 1LL;

    /** cominit.e:201		while i <= length(a) do*/
L1: 
    if (IS_SEQUENCE(_a_49843)){
            _25538 = SEQ_PTR(_a_49843)->length;
    }
    else {
        _25538 = 1;
    }
    if (_i_49847 > _25538)
    goto L2; // [22] 465

    /** cominit.e:202			sequence opt = a[i]*/
    DeRef(_opt_49851);
    _2 = (object)SEQ_PTR(_a_49843);
    _opt_49851 = (object)*(((s1_ptr)_2)->base + _i_49847);
    Ref(_opt_49851);

    /** cominit.e:203			if length(opt) < 2 then*/
    if (IS_SEQUENCE(_opt_49851)){
            _25541 = SEQ_PTR(_opt_49851)->length;
    }
    else {
        _25541 = 1;
    }
    if (_25541 >= 2LL)
    goto L3; // [39] 56

    /** cominit.e:204				i += 1*/
    _i_49847 = _i_49847 + 1;

    /** cominit.e:205				continue*/
    DeRefDS(_opt_49851);
    _opt_49851 = NOVALUE;
    DeRef(_this_opt_49857);
    _this_opt_49857 = NOVALUE;
    goto L1; // [53] 19
L3: 

    /** cominit.e:208			sequence this_opt = {}*/
    RefDS(_21993);
    DeRef(_this_opt_49857);
    _this_opt_49857 = _21993;

    /** cominit.e:209			integer bi = 0*/
    _bi_49858 = 0LL;

    /** cominit.e:211			if opt[2] = '-' then*/
    _2 = (object)SEQ_PTR(_opt_49851);
    _25544 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (binary_op_a(NOTEQ, _25544, 45LL)){
        _25544 = NOVALUE;
        goto L4; // [74] 149
    }
    _25544 = NOVALUE;

    /** cominit.e:214				this_opt = find_opt(LONGNAME, opt[3..$], opts)*/
    if (IS_SEQUENCE(_opt_49851)){
            _25546 = SEQ_PTR(_opt_49851)->length;
    }
    else {
        _25546 = 1;
    }
    rhs_slice_target = (object_ptr)&_25547;
    RHS_Slice(_opt_49851, 3LL, _25546);
    RefDS(_opts_49845);
    _0 = _this_opt_49857;
    _this_opt_49857 = _49find_opt(2LL, _25547, _opts_49845);
    DeRefDS(_0);
    _25547 = NOVALUE;

    /** cominit.e:216				for j = 1 to length(b) do*/
    if (IS_SEQUENCE(_b_49844)){
            _25549 = SEQ_PTR(_b_49844)->length;
    }
    else {
        _25549 = 1;
    }
    {
        object _j_49866;
        _j_49866 = 1LL;
L5: 
        if (_j_49866 > _25549){
            goto L6; // [101] 146
        }

        /** cominit.e:217					if equal(text:lower(b[j]), text:lower(opt)) then*/
        _2 = (object)SEQ_PTR(_b_49844);
        _25550 = (object)*(((s1_ptr)_2)->base + _j_49866);
        Ref(_25550);
        _25551 = _14lower(_25550);
        _25550 = NOVALUE;
        RefDS(_opt_49851);
        _25552 = _14lower(_opt_49851);
        if (_25551 == _25552)
        _25553 = 1;
        else if (IS_ATOM_INT(_25551) && IS_ATOM_INT(_25552))
        _25553 = 0;
        else
        _25553 = (compare(_25551, _25552) == 0);
        DeRef(_25551);
        _25551 = NOVALUE;
        DeRef(_25552);
        _25552 = NOVALUE;
        if (_25553 == 0)
        {
            _25553 = NOVALUE;
            goto L7; // [126] 139
        }
        else{
            _25553 = NOVALUE;
        }

        /** cominit.e:218						bi = j*/
        _bi_49858 = _j_49866;

        /** cominit.e:219						exit*/
        goto L6; // [136] 146
L7: 

        /** cominit.e:221				end for*/
        _j_49866 = _j_49866 + 1LL;
        goto L5; // [141] 108
L6: 
        ;
    }
    goto L8; // [146] 292
L4: 

    /** cominit.e:223			elsif opt[1] = '-' or opt[1] = '/' then*/
    _2 = (object)SEQ_PTR(_opt_49851);
    _25554 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_25554)) {
        _25555 = (_25554 == 45LL);
    }
    else {
        _25555 = binary_op(EQUALS, _25554, 45LL);
    }
    _25554 = NOVALUE;
    if (IS_ATOM_INT(_25555)) {
        if (_25555 != 0) {
            goto L9; // [159] 176
        }
    }
    else {
        if (DBL_PTR(_25555)->dbl != 0.0) {
            goto L9; // [159] 176
        }
    }
    _2 = (object)SEQ_PTR(_opt_49851);
    _25557 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_25557)) {
        _25558 = (_25557 == 47LL);
    }
    else {
        _25558 = binary_op(EQUALS, _25557, 47LL);
    }
    _25557 = NOVALUE;
    if (_25558 == 0) {
        DeRef(_25558);
        _25558 = NOVALUE;
        goto LA; // [172] 291
    }
    else {
        if (!IS_ATOM_INT(_25558) && DBL_PTR(_25558)->dbl == 0.0){
            DeRef(_25558);
            _25558 = NOVALUE;
            goto LA; // [172] 291
        }
        DeRef(_25558);
        _25558 = NOVALUE;
    }
    DeRef(_25558);
    _25558 = NOVALUE;
L9: 

    /** cominit.e:226				this_opt = find_opt(SHORTNAME, opt[2..$], opts)*/
    if (IS_SEQUENCE(_opt_49851)){
            _25559 = SEQ_PTR(_opt_49851)->length;
    }
    else {
        _25559 = 1;
    }
    rhs_slice_target = (object_ptr)&_25560;
    RHS_Slice(_opt_49851, 2LL, _25559);
    RefDS(_opts_49845);
    _0 = _this_opt_49857;
    _this_opt_49857 = _49find_opt(1LL, _25560, _opts_49845);
    DeRef(_0);
    _25560 = NOVALUE;

    /** cominit.e:228				for j = 1 to length(b) do*/
    if (IS_SEQUENCE(_b_49844)){
            _25562 = SEQ_PTR(_b_49844)->length;
    }
    else {
        _25562 = 1;
    }
    {
        object _j_49883;
        _j_49883 = 1LL;
LB: 
        if (_j_49883 > _25562){
            goto LC; // [199] 290
        }

        /** cominit.e:229					if equal(text:lower(b[j]), '-' & text:lower(opt[2..$])) or */
        _2 = (object)SEQ_PTR(_b_49844);
        _25563 = (object)*(((s1_ptr)_2)->base + _j_49883);
        Ref(_25563);
        _25564 = _14lower(_25563);
        _25563 = NOVALUE;
        if (IS_SEQUENCE(_opt_49851)){
                _25565 = SEQ_PTR(_opt_49851)->length;
        }
        else {
            _25565 = 1;
        }
        rhs_slice_target = (object_ptr)&_25566;
        RHS_Slice(_opt_49851, 2LL, _25565);
        _25567 = _14lower(_25566);
        _25566 = NOVALUE;
        if (IS_SEQUENCE(45LL) && IS_ATOM(_25567)) {
        }
        else if (IS_ATOM(45LL) && IS_SEQUENCE(_25567)) {
            Prepend(&_25568, _25567, 45LL);
        }
        else {
            Concat((object_ptr)&_25568, 45LL, _25567);
        }
        DeRef(_25567);
        _25567 = NOVALUE;
        if (_25564 == _25568)
        _25569 = 1;
        else if (IS_ATOM_INT(_25564) && IS_ATOM_INT(_25568))
        _25569 = 0;
        else
        _25569 = (compare(_25564, _25568) == 0);
        DeRef(_25564);
        _25564 = NOVALUE;
        DeRefDS(_25568);
        _25568 = NOVALUE;
        if (_25569 != 0) {
            goto LD; // [236] 273
        }
        _2 = (object)SEQ_PTR(_b_49844);
        _25571 = (object)*(((s1_ptr)_2)->base + _j_49883);
        Ref(_25571);
        _25572 = _14lower(_25571);
        _25571 = NOVALUE;
        if (IS_SEQUENCE(_opt_49851)){
                _25573 = SEQ_PTR(_opt_49851)->length;
        }
        else {
            _25573 = 1;
        }
        rhs_slice_target = (object_ptr)&_25574;
        RHS_Slice(_opt_49851, 2LL, _25573);
        _25575 = _14lower(_25574);
        _25574 = NOVALUE;
        if (IS_SEQUENCE(47LL) && IS_ATOM(_25575)) {
        }
        else if (IS_ATOM(47LL) && IS_SEQUENCE(_25575)) {
            Prepend(&_25576, _25575, 47LL);
        }
        else {
            Concat((object_ptr)&_25576, 47LL, _25575);
        }
        DeRef(_25575);
        _25575 = NOVALUE;
        if (_25572 == _25576)
        _25577 = 1;
        else if (IS_ATOM_INT(_25572) && IS_ATOM_INT(_25576))
        _25577 = 0;
        else
        _25577 = (compare(_25572, _25576) == 0);
        DeRef(_25572);
        _25572 = NOVALUE;
        DeRefDS(_25576);
        _25576 = NOVALUE;
        if (_25577 == 0)
        {
            _25577 = NOVALUE;
            goto LE; // [269] 283
        }
        else{
            _25577 = NOVALUE;
        }
LD: 

        /** cominit.e:232						bi = j*/
        _bi_49858 = _j_49883;

        /** cominit.e:233						exit*/
        goto LC; // [280] 290
LE: 

        /** cominit.e:235				end for*/
        _j_49883 = _j_49883 + 1LL;
        goto LB; // [285] 206
LC: 
        ;
    }
LA: 
L8: 

    /** cominit.e:243			if length(this_opt) and not find(MULTIPLE, this_opt[OPTIONS]) then*/
    if (IS_SEQUENCE(_this_opt_49857)){
            _25578 = SEQ_PTR(_this_opt_49857)->length;
    }
    else {
        _25578 = 1;
    }
    if (_25578 == 0) {
        goto LF; // [297] 451
    }
    _2 = (object)SEQ_PTR(_this_opt_49857);
    _25580 = (object)*(((s1_ptr)_2)->base + 4LL);
    _25581 = find_from(42LL, _25580, 1LL);
    _25580 = NOVALUE;
    _25582 = (_25581 == 0);
    _25581 = NOVALUE;
    if (_25582 == 0)
    {
        DeRef(_25582);
        _25582 = NOVALUE;
        goto LF; // [316] 451
    }
    else{
        DeRef(_25582);
        _25582 = NOVALUE;
    }

    /** cominit.e:244				if bi then*/
    if (_bi_49858 == 0)
    {
        goto L10; // [321] 365
    }
    else{
    }

    /** cominit.e:245					if find(HAS_PARAMETER, this_opt[OPTIONS]) then*/
    _2 = (object)SEQ_PTR(_this_opt_49857);
    _25583 = (object)*(((s1_ptr)_2)->base + 4LL);
    _25584 = find_from(112LL, _25583, 1LL);
    _25583 = NOVALUE;
    if (_25584 == 0)
    {
        _25584 = NOVALUE;
        goto L11; // [337] 354
    }
    else{
        _25584 = NOVALUE;
    }

    /** cominit.e:247						a = remove(a, i, i + 1)*/
    _25585 = _i_49847 + 1;
    if (_25585 > MAXINT){
        _25585 = NewDouble((eudouble)_25585);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_a_49843);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_i_49847)) ? _i_49847 : (object)(DBL_PTR(_i_49847)->dbl);
        int stop = (IS_ATOM_INT(_25585)) ? _25585 : (object)(DBL_PTR(_25585)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_a_49843), start, &_a_49843 );
            }
            else Tail(SEQ_PTR(_a_49843), stop+1, &_a_49843);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_a_49843), start, &_a_49843);
        }
        else {
            assign_slice_seq = &assign_space;
            _a_49843 = Remove_elements(start, stop, (SEQ_PTR(_a_49843)->ref == 1));
        }
    }
    DeRef(_25585);
    _25585 = NOVALUE;
    goto L12; // [351] 458
L11: 

    /** cominit.e:250						a = remove(a, i)*/
    {
        s1_ptr assign_space = SEQ_PTR(_a_49843);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_i_49847)) ? _i_49847 : (object)(DBL_PTR(_i_49847)->dbl);
        int stop = (IS_ATOM_INT(_i_49847)) ? _i_49847 : (object)(DBL_PTR(_i_49847)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_a_49843), start, &_a_49843 );
            }
            else Tail(SEQ_PTR(_a_49843), stop+1, &_a_49843);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_a_49843), start, &_a_49843);
        }
        else {
            assign_slice_seq = &assign_space;
            _a_49843 = Remove_elements(start, stop, (SEQ_PTR(_a_49843)->ref == 1));
        }
    }
    goto L12; // [362] 458
L10: 

    /** cominit.e:265					integer beginLen = length(a)*/
    if (IS_SEQUENCE(_a_49843)){
            _beginLen_49918 = SEQ_PTR(_a_49843)->length;
    }
    else {
        _beginLen_49918 = 1;
    }

    /** cominit.e:267					if dedupe = 0 and i < beginLen then*/
    _25589 = (_dedupe_49846 == 0LL);
    if (_25589 == 0) {
        goto L13; // [376] 438
    }
    _25591 = (_i_49847 < _beginLen_49918);
    if (_25591 == 0)
    {
        DeRef(_25591);
        _25591 = NOVALUE;
        goto L13; // [385] 438
    }
    else{
        DeRef(_25591);
        _25591 = NOVALUE;
    }

    /** cominit.e:268						a = merge_parameters( a[i + 1..$], a[1..i], opts, 1)*/
    _25592 = _i_49847 + 1;
    if (_25592 > MAXINT){
        _25592 = NewDouble((eudouble)_25592);
    }
    if (IS_SEQUENCE(_a_49843)){
            _25593 = SEQ_PTR(_a_49843)->length;
    }
    else {
        _25593 = 1;
    }
    rhs_slice_target = (object_ptr)&_25594;
    RHS_Slice(_a_49843, _25592, _25593);
    rhs_slice_target = (object_ptr)&_25595;
    RHS_Slice(_a_49843, 1LL, _i_49847);
    RefDS(_opts_49845);
    DeRef(_25596);
    _25596 = _opts_49845;
    _0 = _a_49843;
    _a_49843 = _49merge_parameters(_25594, _25595, _25596, 1LL);
    DeRefDS(_0);
    _25594 = NOVALUE;
    _25595 = NOVALUE;
    _25596 = NOVALUE;

    /** cominit.e:270						if beginLen = length(a) then*/
    if (IS_SEQUENCE(_a_49843)){
            _25598 = SEQ_PTR(_a_49843)->length;
    }
    else {
        _25598 = 1;
    }
    if (_beginLen_49918 != _25598)
    goto L14; // [424] 445

    /** cominit.e:272							i += 1*/
    _i_49847 = _i_49847 + 1;
    goto L14; // [435] 445
L13: 

    /** cominit.e:276						i += 1*/
    _i_49847 = _i_49847 + 1;
L14: 
    goto L12; // [448] 458
LF: 

    /** cominit.e:282				i += 1*/
    _i_49847 = _i_49847 + 1;
L12: 
    DeRef(_opt_49851);
    _opt_49851 = NOVALUE;
    DeRef(_this_opt_49857);
    _this_opt_49857 = NOVALUE;

    /** cominit.e:284		end while*/
    goto L1; // [462] 19
L2: 

    /** cominit.e:286		if dedupe then*/
    if (_dedupe_49846 == 0)
    {
        goto L15; // [467] 481
    }
    else{
    }

    /** cominit.e:287			return b & a*/
    Concat((object_ptr)&_25603, _b_49844, _a_49843);
    DeRefDS(_a_49843);
    DeRefDS(_b_49844);
    DeRefDS(_opts_49845);
    DeRef(_25555);
    _25555 = NOVALUE;
    DeRef(_25589);
    _25589 = NOVALUE;
    DeRef(_25592);
    _25592 = NOVALUE;
    return _25603;
L15: 

    /** cominit.e:290		integer first_extra = 0*/
    _first_extra_49940 = 0LL;

    /** cominit.e:292		i = 1*/
    _i_49847 = 1LL;

    /** cominit.e:295		while i <= length(b) do*/
L16: 
    if (IS_SEQUENCE(_b_49844)){
            _25604 = SEQ_PTR(_b_49844)->length;
    }
    else {
        _25604 = 1;
    }
    if (_i_49847 > _25604)
    goto L17; // [499] 692

    /** cominit.e:296			sequence opt = b[i]*/
    DeRef(_opt_49944);
    _2 = (object)SEQ_PTR(_b_49844);
    _opt_49944 = (object)*(((s1_ptr)_2)->base + _i_49847);
    Ref(_opt_49944);

    /** cominit.e:299			if length(opt) <= 1 then*/
    if (IS_SEQUENCE(_opt_49944)){
            _25607 = SEQ_PTR(_opt_49944)->length;
    }
    else {
        _25607 = 1;
    }
    if (_25607 > 1LL)
    goto L18; // [516] 532

    /** cominit.e:300				first_extra = i*/
    _first_extra_49940 = _i_49847;

    /** cominit.e:301				exit*/
    DeRefDS(_opt_49944);
    _opt_49944 = NOVALUE;
    DeRef(_this_opt_49949);
    _this_opt_49949 = NOVALUE;
    goto L17; // [529] 692
L18: 

    /** cominit.e:304			sequence this_opt = {}*/
    RefDS(_21993);
    DeRef(_this_opt_49949);
    _this_opt_49949 = _21993;

    /** cominit.e:305			if opt[2] = '-' and opt[1] = '-' then*/
    _2 = (object)SEQ_PTR(_opt_49944);
    _25609 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_25609)) {
        _25610 = (_25609 == 45LL);
    }
    else {
        _25610 = binary_op(EQUALS, _25609, 45LL);
    }
    _25609 = NOVALUE;
    if (IS_ATOM_INT(_25610)) {
        if (_25610 == 0) {
            goto L19; // [549] 586
        }
    }
    else {
        if (DBL_PTR(_25610)->dbl == 0.0) {
            goto L19; // [549] 586
        }
    }
    _2 = (object)SEQ_PTR(_opt_49944);
    _25612 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_25612)) {
        _25613 = (_25612 == 45LL);
    }
    else {
        _25613 = binary_op(EQUALS, _25612, 45LL);
    }
    _25612 = NOVALUE;
    if (_25613 == 0) {
        DeRef(_25613);
        _25613 = NOVALUE;
        goto L19; // [562] 586
    }
    else {
        if (!IS_ATOM_INT(_25613) && DBL_PTR(_25613)->dbl == 0.0){
            DeRef(_25613);
            _25613 = NOVALUE;
            goto L19; // [562] 586
        }
        DeRef(_25613);
        _25613 = NOVALUE;
    }
    DeRef(_25613);
    _25613 = NOVALUE;

    /** cominit.e:306				this_opt = find_opt(LONGNAME, opt[3..$], opts)*/
    if (IS_SEQUENCE(_opt_49944)){
            _25614 = SEQ_PTR(_opt_49944)->length;
    }
    else {
        _25614 = 1;
    }
    rhs_slice_target = (object_ptr)&_25615;
    RHS_Slice(_opt_49944, 3LL, _25614);
    RefDS(_opts_49845);
    _0 = _this_opt_49949;
    _this_opt_49949 = _49find_opt(2LL, _25615, _opts_49845);
    DeRef(_0);
    _25615 = NOVALUE;
    goto L1A; // [583] 633
L19: 

    /** cominit.e:307			elsif opt[1] = '-' or opt[1] = '/' then*/
    _2 = (object)SEQ_PTR(_opt_49944);
    _25617 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_25617)) {
        _25618 = (_25617 == 45LL);
    }
    else {
        _25618 = binary_op(EQUALS, _25617, 45LL);
    }
    _25617 = NOVALUE;
    if (IS_ATOM_INT(_25618)) {
        if (_25618 != 0) {
            goto L1B; // [596] 613
        }
    }
    else {
        if (DBL_PTR(_25618)->dbl != 0.0) {
            goto L1B; // [596] 613
        }
    }
    _2 = (object)SEQ_PTR(_opt_49944);
    _25620 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_25620)) {
        _25621 = (_25620 == 47LL);
    }
    else {
        _25621 = binary_op(EQUALS, _25620, 47LL);
    }
    _25620 = NOVALUE;
    if (_25621 == 0) {
        DeRef(_25621);
        _25621 = NOVALUE;
        goto L1C; // [609] 632
    }
    else {
        if (!IS_ATOM_INT(_25621) && DBL_PTR(_25621)->dbl == 0.0){
            DeRef(_25621);
            _25621 = NOVALUE;
            goto L1C; // [609] 632
        }
        DeRef(_25621);
        _25621 = NOVALUE;
    }
    DeRef(_25621);
    _25621 = NOVALUE;
L1B: 

    /** cominit.e:308				this_opt = find_opt(SHORTNAME, opt[2..$], opts)*/
    if (IS_SEQUENCE(_opt_49944)){
            _25622 = SEQ_PTR(_opt_49944)->length;
    }
    else {
        _25622 = 1;
    }
    rhs_slice_target = (object_ptr)&_25623;
    RHS_Slice(_opt_49944, 2LL, _25622);
    RefDS(_opts_49845);
    _0 = _this_opt_49949;
    _this_opt_49949 = _49find_opt(1LL, _25623, _opts_49845);
    DeRef(_0);
    _25623 = NOVALUE;
L1C: 
L1A: 

    /** cominit.e:311			if length(this_opt) then*/
    if (IS_SEQUENCE(_this_opt_49949)){
            _25625 = SEQ_PTR(_this_opt_49949)->length;
    }
    else {
        _25625 = 1;
    }
    if (_25625 == 0)
    {
        _25625 = NOVALUE;
        goto L1D; // [638] 667
    }
    else{
        _25625 = NOVALUE;
    }

    /** cominit.e:312				if find(HAS_PARAMETER, this_opt[OPTIONS]) then*/
    _2 = (object)SEQ_PTR(_this_opt_49949);
    _25626 = (object)*(((s1_ptr)_2)->base + 4LL);
    _25627 = find_from(112LL, _25626, 1LL);
    _25626 = NOVALUE;
    if (_25627 == 0)
    {
        _25627 = NOVALUE;
        goto L1E; // [654] 679
    }
    else{
        _25627 = NOVALUE;
    }

    /** cominit.e:313					i += 1*/
    _i_49847 = _i_49847 + 1;
    goto L1E; // [664] 679
L1D: 

    /** cominit.e:316				first_extra = i*/
    _first_extra_49940 = _i_49847;

    /** cominit.e:317				exit*/
    DeRef(_opt_49944);
    _opt_49944 = NOVALUE;
    DeRef(_this_opt_49949);
    _this_opt_49949 = NOVALUE;
    goto L17; // [676] 692
L1E: 

    /** cominit.e:320			i += 1*/
    _i_49847 = _i_49847 + 1;
    DeRef(_opt_49944);
    _opt_49944 = NOVALUE;
    DeRef(_this_opt_49949);
    _this_opt_49949 = NOVALUE;

    /** cominit.e:321		end while*/
    goto L16; // [689] 496
L17: 

    /** cominit.e:323		if first_extra then*/
    if (_first_extra_49940 == 0)
    {
        goto L1F; // [694] 709
    }
    else{
    }

    /** cominit.e:324			return splice(b, a, first_extra)*/
    {
        s1_ptr assign_space;
        insert_pos = _first_extra_49940;
        if (insert_pos <= 0) {
            Concat(&_25630,_a_49843,_b_49844);
        }
        else if (insert_pos > SEQ_PTR(_b_49844)->length){
            Concat(&_25630,_b_49844,_a_49843);
        }
        else if (IS_SEQUENCE(_a_49843)) {
            if( _25630 != _b_49844 || SEQ_PTR( _b_49844 )->ref != 1 ){
                DeRef( _25630 );
                RefDS( _b_49844 );
            }
            assign_space = Add_internal_space( _b_49844, insert_pos,((s1_ptr)SEQ_PTR(_a_49843))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_a_49843), _b_49844 == _25630 );
            _25630 = MAKE_SEQ( assign_space );
        }
        else {
            if( _25630 == _b_49844 && SEQ_PTR( _b_49844 )->ref == 1 ){
                _25630 = Insert( _b_49844, _a_49843, insert_pos);
            }
            else {
                DeRef( _25630 );
                RefDS( _b_49844 );
                _25630 = Insert( _b_49844, _a_49843, insert_pos);
            }
        }
    }
    DeRefDS(_a_49843);
    DeRefDS(_b_49844);
    DeRefDS(_opts_49845);
    DeRef(_25555);
    _25555 = NOVALUE;
    DeRef(_25618);
    _25618 = NOVALUE;
    DeRef(_25589);
    _25589 = NOVALUE;
    DeRef(_25610);
    _25610 = NOVALUE;
    DeRef(_25603);
    _25603 = NOVALUE;
    DeRef(_25592);
    _25592 = NOVALUE;
    return _25630;
L1F: 

    /** cominit.e:328		return b & a*/
    Concat((object_ptr)&_25631, _b_49844, _a_49843);
    DeRefDS(_a_49843);
    DeRefDS(_b_49844);
    DeRefDS(_opts_49845);
    DeRef(_25555);
    _25555 = NOVALUE;
    DeRef(_25618);
    _25618 = NOVALUE;
    DeRef(_25630);
    _25630 = NOVALUE;
    DeRef(_25589);
    _25589 = NOVALUE;
    DeRef(_25610);
    _25610 = NOVALUE;
    DeRef(_25603);
    _25603 = NOVALUE;
    DeRef(_25592);
    _25592 = NOVALUE;
    return _25631;
    ;
}


object _49validate_opt(object _opt_type_49982, object _arg_49983, object _args_49984, object _ix_49985)
{
    object _opt_49986 = NOVALUE;
    object _this_opt_49994 = NOVALUE;
    object _25650 = NOVALUE;
    object _25649 = NOVALUE;
    object _25648 = NOVALUE;
    object _25647 = NOVALUE;
    object _25646 = NOVALUE;
    object _25644 = NOVALUE;
    object _25643 = NOVALUE;
    object _25642 = NOVALUE;
    object _25641 = NOVALUE;
    object _25640 = NOVALUE;
    object _25638 = NOVALUE;
    object _25635 = NOVALUE;
    object _25633 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:336		if opt_type = SHORTNAME then*/
    if (_opt_type_49982 != 1LL)
    goto L1; // [11] 28

    /** cominit.e:337			opt = arg[2..$]*/
    if (IS_SEQUENCE(_arg_49983)){
            _25633 = SEQ_PTR(_arg_49983)->length;
    }
    else {
        _25633 = 1;
    }
    rhs_slice_target = (object_ptr)&_opt_49986;
    RHS_Slice(_arg_49983, 2LL, _25633);
    goto L2; // [25] 39
L1: 

    /** cominit.e:339			opt = arg[3..$]*/
    if (IS_SEQUENCE(_arg_49983)){
            _25635 = SEQ_PTR(_arg_49983)->length;
    }
    else {
        _25635 = 1;
    }
    rhs_slice_target = (object_ptr)&_opt_49986;
    RHS_Slice(_arg_49983, 3LL, _25635);
L2: 

    /** cominit.e:342		sequence this_opt = find_opt( opt_type, opt, options )*/
    RefDS(_opt_49986);
    RefDS(_49options_49719);
    _0 = _this_opt_49994;
    _this_opt_49994 = _49find_opt(_opt_type_49982, _opt_49986, _49options_49719);
    DeRef(_0);

    /** cominit.e:343		if not length( this_opt ) then*/
    if (IS_SEQUENCE(_this_opt_49994)){
            _25638 = SEQ_PTR(_this_opt_49994)->length;
    }
    else {
        _25638 = 1;
    }
    if (_25638 != 0)
    goto L3; // [58] 72
    _25638 = NOVALUE;

    /** cominit.e:345			return { 0, 0 }*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = 0LL;
    _25640 = MAKE_SEQ(_1);
    DeRefDS(_arg_49983);
    DeRefDS(_args_49984);
    DeRefDS(_opt_49986);
    DeRefDS(_this_opt_49994);
    return _25640;
L3: 

    /** cominit.e:348		if find( HAS_PARAMETER, this_opt[OPTIONS] ) then*/
    _2 = (object)SEQ_PTR(_this_opt_49994);
    _25641 = (object)*(((s1_ptr)_2)->base + 4LL);
    _25642 = find_from(112LL, _25641, 1LL);
    _25641 = NOVALUE;
    if (_25642 == 0)
    {
        _25642 = NOVALUE;
        goto L4; // [85] 135
    }
    else{
        _25642 = NOVALUE;
    }

    /** cominit.e:349			if ix = length( args ) - 1 then*/
    if (IS_SEQUENCE(_args_49984)){
            _25643 = SEQ_PTR(_args_49984)->length;
    }
    else {
        _25643 = 1;
    }
    _25644 = _25643 - 1LL;
    _25643 = NOVALUE;
    if (_ix_49985 != _25644)
    goto L5; // [97] 117

    /** cominit.e:351				CompileErr( MISSING_CMD_PARAMETER, { arg } )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_arg_49983);
    ((intptr_t*)_2)[1] = _arg_49983;
    _25646 = MAKE_SEQ(_1);
    _50CompileErr(353LL, _25646, 0LL);
    _25646 = NOVALUE;
    goto L6; // [114] 150
L5: 

    /** cominit.e:353				return { ix, ix + 2 }*/
    _25647 = _ix_49985 + 2LL;
    if ((object)((uintptr_t)_25647 + (uintptr_t)HIGH_BITS) >= 0){
        _25647 = NewDouble((eudouble)_25647);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _ix_49985;
    ((intptr_t *)_2)[2] = _25647;
    _25648 = MAKE_SEQ(_1);
    _25647 = NOVALUE;
    DeRefDS(_arg_49983);
    DeRefDS(_args_49984);
    DeRef(_opt_49986);
    DeRef(_this_opt_49994);
    DeRef(_25640);
    _25640 = NOVALUE;
    DeRef(_25644);
    _25644 = NOVALUE;
    return _25648;
    goto L6; // [132] 150
L4: 

    /** cominit.e:356			return { ix, ix + 1 }*/
    _25649 = _ix_49985 + 1;
    if (_25649 > MAXINT){
        _25649 = NewDouble((eudouble)_25649);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _ix_49985;
    ((intptr_t *)_2)[2] = _25649;
    _25650 = MAKE_SEQ(_1);
    _25649 = NOVALUE;
    DeRefDS(_arg_49983);
    DeRefDS(_args_49984);
    DeRef(_opt_49986);
    DeRef(_this_opt_49994);
    DeRef(_25640);
    _25640 = NOVALUE;
    DeRef(_25648);
    _25648 = NOVALUE;
    DeRef(_25644);
    _25644 = NOVALUE;
    return _25650;
L6: 
    ;
}


object _49find_next_opt(object _ix_50019, object _args_50020)
{
    object _arg_50024 = NOVALUE;
    object _25672 = NOVALUE;
    object _25671 = NOVALUE;
    object _25669 = NOVALUE;
    object _25668 = NOVALUE;
    object _25667 = NOVALUE;
    object _25666 = NOVALUE;
    object _25665 = NOVALUE;
    object _25664 = NOVALUE;
    object _25663 = NOVALUE;
    object _25662 = NOVALUE;
    object _25660 = NOVALUE;
    object _25658 = NOVALUE;
    object _25656 = NOVALUE;
    object _25654 = NOVALUE;
    object _25651 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:374		while ix < length( args ) do*/
L1: 
    if (IS_SEQUENCE(_args_50020)){
            _25651 = SEQ_PTR(_args_50020)->length;
    }
    else {
        _25651 = 1;
    }
    if (_ix_50019 >= _25651)
    goto L2; // [13] 157

    /** cominit.e:375			sequence arg = args[ix]*/
    DeRef(_arg_50024);
    _2 = (object)SEQ_PTR(_args_50020);
    _arg_50024 = (object)*(((s1_ptr)_2)->base + _ix_50019);
    Ref(_arg_50024);

    /** cominit.e:376			if length( arg ) > 1 then*/
    if (IS_SEQUENCE(_arg_50024)){
            _25654 = SEQ_PTR(_arg_50024)->length;
    }
    else {
        _25654 = 1;
    }
    if (_25654 <= 1LL)
    goto L3; // [30] 129

    /** cominit.e:377				if arg[1] = '-' then*/
    _2 = (object)SEQ_PTR(_arg_50024);
    _25656 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _25656, 45LL)){
        _25656 = NOVALUE;
        goto L4; // [40] 111
    }
    _25656 = NOVALUE;

    /** cominit.e:378					if arg[2] = '-' then*/
    _2 = (object)SEQ_PTR(_arg_50024);
    _25658 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (binary_op_a(NOTEQ, _25658, 45LL)){
        _25658 = NOVALUE;
        goto L5; // [50] 94
    }
    _25658 = NOVALUE;

    /** cominit.e:380						if length( arg ) = 2 then*/
    if (IS_SEQUENCE(_arg_50024)){
            _25660 = SEQ_PTR(_arg_50024)->length;
    }
    else {
        _25660 = 1;
    }
    if (_25660 != 2LL)
    goto L6; // [59] 78

    /** cominit.e:382							return { 0, ix - 1 }*/
    _25662 = _ix_50019 - 1LL;
    if ((object)((uintptr_t)_25662 +(uintptr_t) HIGH_BITS) >= 0){
        _25662 = NewDouble((eudouble)_25662);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = _25662;
    _25663 = MAKE_SEQ(_1);
    _25662 = NOVALUE;
    DeRefDS(_arg_50024);
    DeRefDS(_args_50020);
    return _25663;
L6: 

    /** cominit.e:385						return validate_opt( LONGNAME, arg, args, ix )*/
    RefDS(_arg_50024);
    RefDS(_args_50020);
    _25664 = _49validate_opt(2LL, _arg_50024, _args_50020, _ix_50019);
    DeRefDS(_arg_50024);
    DeRefDS(_args_50020);
    DeRef(_25663);
    _25663 = NOVALUE;
    return _25664;
    goto L7; // [91] 144
L5: 

    /** cominit.e:389						return validate_opt( SHORTNAME, arg, args, ix )*/
    RefDS(_arg_50024);
    RefDS(_args_50020);
    _25665 = _49validate_opt(1LL, _arg_50024, _args_50020, _ix_50019);
    DeRefDS(_arg_50024);
    DeRefDS(_args_50020);
    DeRef(_25663);
    _25663 = NOVALUE;
    DeRef(_25664);
    _25664 = NOVALUE;
    return _25665;
    goto L7; // [108] 144
L4: 

    /** cominit.e:393					return {0, ix-1}*/
    _25666 = _ix_50019 - 1LL;
    if ((object)((uintptr_t)_25666 +(uintptr_t) HIGH_BITS) >= 0){
        _25666 = NewDouble((eudouble)_25666);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = _25666;
    _25667 = MAKE_SEQ(_1);
    _25666 = NOVALUE;
    DeRef(_arg_50024);
    DeRefDS(_args_50020);
    DeRef(_25665);
    _25665 = NOVALUE;
    DeRef(_25663);
    _25663 = NOVALUE;
    DeRef(_25664);
    _25664 = NOVALUE;
    return _25667;
    goto L7; // [126] 144
L3: 

    /** cominit.e:397				return { 0, ix-1 }*/
    _25668 = _ix_50019 - 1LL;
    if ((object)((uintptr_t)_25668 +(uintptr_t) HIGH_BITS) >= 0){
        _25668 = NewDouble((eudouble)_25668);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = _25668;
    _25669 = MAKE_SEQ(_1);
    _25668 = NOVALUE;
    DeRef(_arg_50024);
    DeRefDS(_args_50020);
    DeRef(_25665);
    _25665 = NOVALUE;
    DeRef(_25667);
    _25667 = NOVALUE;
    DeRef(_25663);
    _25663 = NOVALUE;
    DeRef(_25664);
    _25664 = NOVALUE;
    return _25669;
L7: 

    /** cominit.e:400			ix += 1*/
    _ix_50019 = _ix_50019 + 1;
    DeRef(_arg_50024);
    _arg_50024 = NOVALUE;

    /** cominit.e:401		end while*/
    goto L1; // [154] 10
L2: 

    /** cominit.e:402		return {0, ix-1}*/
    _25671 = _ix_50019 - 1LL;
    if ((object)((uintptr_t)_25671 +(uintptr_t) HIGH_BITS) >= 0){
        _25671 = NewDouble((eudouble)_25671);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = _25671;
    _25672 = MAKE_SEQ(_1);
    _25671 = NOVALUE;
    DeRefDS(_args_50020);
    DeRef(_25665);
    _25665 = NOVALUE;
    DeRef(_25667);
    _25667 = NOVALUE;
    DeRef(_25669);
    _25669 = NOVALUE;
    DeRef(_25663);
    _25663 = NOVALUE;
    DeRef(_25664);
    _25664 = NOVALUE;
    return _25672;
    ;
}


object _49expand_config_options(object _args_50054)
{
    object _idx_50055 = NOVALUE;
    object _next_idx_50056 = NOVALUE;
    object _files_50057 = NOVALUE;
    object _cmd_1_2_50058 = NOVALUE;
    object _25695 = NOVALUE;
    object _25694 = NOVALUE;
    object _25693 = NOVALUE;
    object _25692 = NOVALUE;
    object _25691 = NOVALUE;
    object _25690 = NOVALUE;
    object _25689 = NOVALUE;
    object _25688 = NOVALUE;
    object _25687 = NOVALUE;
    object _25682 = NOVALUE;
    object _25680 = NOVALUE;
    object _25679 = NOVALUE;
    object _25678 = NOVALUE;
    object _25676 = NOVALUE;
    object _25675 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:410		integer idx = 1*/
    _idx_50055 = 1LL;

    /** cominit.e:412		sequence files = {}*/
    RefDS(_21993);
    DeRef(_files_50057);
    _files_50057 = _21993;

    /** cominit.e:413		sequence cmd_1_2 = args[1..2]*/
    rhs_slice_target = (object_ptr)&_cmd_1_2_50058;
    RHS_Slice(_args_50054, 1LL, 2LL);

    /** cominit.e:414		args = remove( args, 1, 2 )*/
    {
        s1_ptr assign_space = SEQ_PTR(_args_50054);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(1LL)) ? 1LL : (object)(DBL_PTR(1LL)->dbl);
        int stop = (IS_ATOM_INT(2LL)) ? 2LL : (object)(DBL_PTR(2LL)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_args_50054), start, &_args_50054 );
            }
            else Tail(SEQ_PTR(_args_50054), stop+1, &_args_50054);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_args_50054), start, &_args_50054);
        }
        else {
            assign_slice_seq = &assign_space;
            _args_50054 = Remove_elements(start, stop, (SEQ_PTR(_args_50054)->ref == 1));
        }
    }

    /** cominit.e:416		while idx with entry do*/
    goto L1; // [31] 94
L2: 
    if (_idx_50055 == 0)
    {
        goto L3; // [34] 114
    }
    else{
    }

    /** cominit.e:417			if equal(upper(args[idx]), "-C") then*/
    _2 = (object)SEQ_PTR(_args_50054);
    _25675 = (object)*(((s1_ptr)_2)->base + _idx_50055);
    Ref(_25675);
    _25676 = _14upper(_25675);
    _25675 = NOVALUE;
    if (_25676 == _25677)
    _25678 = 1;
    else if (IS_ATOM_INT(_25676) && IS_ATOM_INT(_25677))
    _25678 = 0;
    else
    _25678 = (compare(_25676, _25677) == 0);
    DeRef(_25676);
    _25676 = NOVALUE;
    if (_25678 == 0)
    {
        _25678 = NOVALUE;
        goto L4; // [51] 82
    }
    else{
        _25678 = NOVALUE;
    }

    /** cominit.e:418				files = append( files, args[idx+1] )*/
    _25679 = _idx_50055 + 1;
    _2 = (object)SEQ_PTR(_args_50054);
    _25680 = (object)*(((s1_ptr)_2)->base + _25679);
    Ref(_25680);
    Append(&_files_50057, _files_50057, _25680);
    _25680 = NOVALUE;

    /** cominit.e:419				args = remove( args, idx, idx + 1 )*/
    _25682 = _idx_50055 + 1;
    if (_25682 > MAXINT){
        _25682 = NewDouble((eudouble)_25682);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_args_50054);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_idx_50055)) ? _idx_50055 : (object)(DBL_PTR(_idx_50055)->dbl);
        int stop = (IS_ATOM_INT(_25682)) ? _25682 : (object)(DBL_PTR(_25682)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_args_50054), start, &_args_50054 );
            }
            else Tail(SEQ_PTR(_args_50054), stop+1, &_args_50054);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_args_50054), start, &_args_50054);
        }
        else {
            assign_slice_seq = &assign_space;
            _args_50054 = Remove_elements(start, stop, (SEQ_PTR(_args_50054)->ref == 1));
        }
    }
    DeRef(_25682);
    _25682 = NOVALUE;
    goto L5; // [79] 91
L4: 

    /** cominit.e:422				idx = next_idx[2]*/
    _2 = (object)SEQ_PTR(_next_idx_50056);
    _idx_50055 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_idx_50055))
    _idx_50055 = (object)DBL_PTR(_idx_50055)->dbl;
L5: 

    /** cominit.e:424		entry*/
L1: 

    /** cominit.e:425			next_idx = find_next_opt( idx, args )*/
    RefDS(_args_50054);
    _0 = _next_idx_50056;
    _next_idx_50056 = _49find_next_opt(_idx_50055, _args_50054);
    DeRef(_0);

    /** cominit.e:426			idx = next_idx[1]*/
    _2 = (object)SEQ_PTR(_next_idx_50056);
    _idx_50055 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_idx_50055))
    _idx_50055 = (object)DBL_PTR(_idx_50055)->dbl;

    /** cominit.e:427		end while*/
    goto L2; // [111] 34
L3: 

    /** cominit.e:428		return cmd_1_2 & merge_parameters( GetDefaultArgs( files ), args[1..next_idx[2]], options, 1 ) & args[next_idx[2]+1..$]*/
    RefDS(_files_50057);
    _25687 = _48GetDefaultArgs(_files_50057);
    _2 = (object)SEQ_PTR(_next_idx_50056);
    _25688 = (object)*(((s1_ptr)_2)->base + 2LL);
    rhs_slice_target = (object_ptr)&_25689;
    RHS_Slice(_args_50054, 1LL, _25688);
    RefDS(_49options_49719);
    _25690 = _49merge_parameters(_25687, _25689, _49options_49719, 1LL);
    _25687 = NOVALUE;
    _25689 = NOVALUE;
    _2 = (object)SEQ_PTR(_next_idx_50056);
    _25691 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_25691)) {
        _25692 = _25691 + 1;
        if (_25692 > MAXINT){
            _25692 = NewDouble((eudouble)_25692);
        }
    }
    else
    _25692 = binary_op(PLUS, 1, _25691);
    _25691 = NOVALUE;
    if (IS_SEQUENCE(_args_50054)){
            _25693 = SEQ_PTR(_args_50054)->length;
    }
    else {
        _25693 = 1;
    }
    rhs_slice_target = (object_ptr)&_25694;
    RHS_Slice(_args_50054, _25692, _25693);
    {
        object concat_list[3];

        concat_list[0] = _25694;
        concat_list[1] = _25690;
        concat_list[2] = _cmd_1_2_50058;
        Concat_N((object_ptr)&_25695, concat_list, 3);
    }
    DeRefDS(_25694);
    _25694 = NOVALUE;
    DeRef(_25690);
    _25690 = NOVALUE;
    DeRefDS(_args_50054);
    DeRefDS(_next_idx_50056);
    DeRefDS(_files_50057);
    DeRefDS(_cmd_1_2_50058);
    _25688 = NOVALUE;
    DeRef(_25679);
    _25679 = NOVALUE;
    DeRef(_25692);
    _25692 = NOVALUE;
    return _25695;
    ;
}


void _49handle_common_options(object _opts_50089)
{
    object _opt_keys_50090 = NOVALUE;
    object _option_w_50092 = NOVALUE;
    object _key_50096 = NOVALUE;
    object _val_50098 = NOVALUE;
    object _this_warn_50144 = NOVALUE;
    object _auto_add_warn_50146 = NOVALUE;
    object _n_50152 = NOVALUE;
    object _this_warn_50175 = NOVALUE;
    object _auto_add_warn_50177 = NOVALUE;
    object _n_50183 = NOVALUE;
    object _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50220 = NOVALUE;
    object _prompt_inlined_maybe_any_key_at_617_50219 = NOVALUE;
    object _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50233 = NOVALUE;
    object _prompt_inlined_maybe_any_key_at_693_50232 = NOVALUE;
    object _25754 = NOVALUE;
    object _25753 = NOVALUE;
    object _25751 = NOVALUE;
    object _25749 = NOVALUE;
    object _25747 = NOVALUE;
    object _25746 = NOVALUE;
    object _25745 = NOVALUE;
    object _25744 = NOVALUE;
    object _25743 = NOVALUE;
    object _25742 = NOVALUE;
    object _25741 = NOVALUE;
    object _25740 = NOVALUE;
    object _25738 = NOVALUE;
    object _25736 = NOVALUE;
    object _25735 = NOVALUE;
    object _25734 = NOVALUE;
    object _25729 = NOVALUE;
    object _25727 = NOVALUE;
    object _25725 = NOVALUE;
    object _25722 = NOVALUE;
    object _25721 = NOVALUE;
    object _25716 = NOVALUE;
    object _25714 = NOVALUE;
    object _25712 = NOVALUE;
    object _25710 = NOVALUE;
    object _25709 = NOVALUE;
    object _25708 = NOVALUE;
    object _25707 = NOVALUE;
    object _25706 = NOVALUE;
    object _25705 = NOVALUE;
    object _25703 = NOVALUE;
    object _25702 = NOVALUE;
    object _25697 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:435		sequence opt_keys = m:keys(opts)*/
    Ref(_opts_50089);
    _0 = _opt_keys_50090;
    _opt_keys_50090 = _29keys(_opts_50089, 0LL);
    DeRef(_0);

    /** cominit.e:436		integer option_w = 0*/
    _option_w_50092 = 0LL;

    /** cominit.e:438		for idx = 1 to length(opt_keys) do*/
    if (IS_SEQUENCE(_opt_keys_50090)){
            _25697 = SEQ_PTR(_opt_keys_50090)->length;
    }
    else {
        _25697 = 1;
    }
    {
        object _idx_50094;
        _idx_50094 = 1LL;
L1: 
        if (_idx_50094 > _25697){
            goto L2; // [20] 795
        }

        /** cominit.e:439			sequence key = opt_keys[idx]*/
        DeRef(_key_50096);
        _2 = (object)SEQ_PTR(_opt_keys_50090);
        _key_50096 = (object)*(((s1_ptr)_2)->base + _idx_50094);
        Ref(_key_50096);

        /** cominit.e:440			object val = m:get(opts, key)*/
        Ref(_opts_50089);
        RefDS(_key_50096);
        _0 = _val_50098;
        _val_50098 = _29get(_opts_50089, _key_50096, 0LL);
        DeRef(_0);

        /** cominit.e:442			switch key do*/
        _1 = find(_key_50096, _25700);
        switch ( _1 ){ 

            /** cominit.e:443				case "i" then*/
            case 1:

            /** cominit.e:444					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50098)){
                    _25702 = SEQ_PTR(_val_50098)->length;
            }
            else {
                _25702 = 1;
            }
            {
                object _i_50104;
                _i_50104 = 1LL;
L3: 
                if (_i_50104 > _25702){
                    goto L4; // [59] 82
                }

                /** cominit.e:445						add_include_directory(val[i])*/
                _2 = (object)SEQ_PTR(_val_50098);
                _25703 = (object)*(((s1_ptr)_2)->base + _i_50104);
                Ref(_25703);
                _48add_include_directory(_25703);
                _25703 = NOVALUE;

                /** cominit.e:446					end for*/
                _i_50104 = _i_50104 + 1LL;
                goto L3; // [77] 66
L4: 
                ;
            }
            goto L5; // [82] 786

            /** cominit.e:448				case "d" then*/
            case 2:

            /** cominit.e:449					OpDefines &= val*/
            if (IS_SEQUENCE(_36OpDefines_21516) && IS_ATOM(_val_50098)) {
                Ref(_val_50098);
                Append(&_36OpDefines_21516, _36OpDefines_21516, _val_50098);
            }
            else if (IS_ATOM(_36OpDefines_21516) && IS_SEQUENCE(_val_50098)) {
            }
            else {
                Concat((object_ptr)&_36OpDefines_21516, _36OpDefines_21516, _val_50098);
            }
            goto L5; // [98] 786

            /** cominit.e:451				case "batch" then*/
            case 3:

            /** cominit.e:452					batch_job = 1*/
            _36batch_job_21452 = 1LL;
            goto L5; // [111] 786

            /** cominit.e:454				case "test" then*/
            case 4:

            /** cominit.e:455					test_only = 1*/
            _36test_only_21451 = 1LL;
            goto L5; // [124] 786

            /** cominit.e:457				case "strict" then*/
            case 5:

            /** cominit.e:458					Strict_is_on = 1*/
            _36Strict_is_on_21508 = 1LL;
            goto L5; // [137] 786

            /** cominit.e:460				case "p" then*/
            case 6:

            /** cominit.e:461					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50098)){
                    _25705 = SEQ_PTR(_val_50098)->length;
            }
            else {
                _25705 = 1;
            }
            {
                object _i_50119;
                _i_50119 = 1LL;
L6: 
                if (_i_50119 > _25705){
                    goto L7; // [148] 173
                }

                /** cominit.e:462						add_preprocessor(val[i])*/
                _2 = (object)SEQ_PTR(_val_50098);
                _25706 = (object)*(((s1_ptr)_2)->base + _i_50119);
                Ref(_25706);
                _64add_preprocessor(_25706, 0LL, 0LL);
                _25706 = NOVALUE;

                /** cominit.e:463					end for*/
                _i_50119 = _i_50119 + 1LL;
                goto L6; // [168] 155
L7: 
                ;
            }
            goto L5; // [173] 786

            /** cominit.e:465				case "pf" then*/
            case 7:

            /** cominit.e:466					force_preprocessor = 1*/
            _37force_preprocessor_15424 = 1LL;
            goto L5; // [186] 786

            /** cominit.e:468				case "l" then*/
            case 8:

            /** cominit.e:469					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50098)){
                    _25707 = SEQ_PTR(_val_50098)->length;
            }
            else {
                _25707 = 1;
            }
            {
                object _i_50127;
                _i_50127 = 1LL;
L8: 
                if (_i_50127 > _25707){
                    goto L9; // [197] 238
                }

                /** cominit.e:470						LocalizeQual = append(LocalizeQual, (filter(lower(val[i]), STDFLTR_ALPHA)))*/
                _2 = (object)SEQ_PTR(_val_50098);
                _25708 = (object)*(((s1_ptr)_2)->base + _i_50127);
                Ref(_25708);
                _25709 = _14lower(_25708);
                _25708 = NOVALUE;
                RefDS(_21993);
                RefDS(_5);
                _25710 = _23filter(_25709, _23STDFLTR_ALPHA_5092, _21993, _5);
                _25709 = NOVALUE;
                Ref(_25710);
                Append(&_37LocalizeQual_15425, _37LocalizeQual_15425, _25710);
                DeRef(_25710);
                _25710 = NOVALUE;

                /** cominit.e:471					end for*/
                _i_50127 = _i_50127 + 1LL;
                goto L8; // [233] 204
L9: 
                ;
            }
            goto L5; // [238] 786

            /** cominit.e:473				case "ldb" then*/
            case 9:

            /** cominit.e:474					LocalDB = val*/
            Ref(_val_50098);
            DeRef(_37LocalDB_15426);
            _37LocalDB_15426 = _val_50098;
            goto L5; // [251] 786

            /** cominit.e:476				case "w" then*/
            case 10:

            /** cominit.e:477					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50098)){
                    _25712 = SEQ_PTR(_val_50098)->length;
            }
            else {
                _25712 = 1;
            }
            {
                object _i_50142;
                _i_50142 = 1LL;
LA: 
                if (_i_50142 > _25712){
                    goto LB; // [262] 392
                }

                /** cominit.e:478						sequence this_warn = val[i]*/
                DeRef(_this_warn_50144);
                _2 = (object)SEQ_PTR(_val_50098);
                _this_warn_50144 = (object)*(((s1_ptr)_2)->base + _i_50142);
                Ref(_this_warn_50144);

                /** cominit.e:479						integer auto_add_warn = 0*/
                _auto_add_warn_50146 = 0LL;

                /** cominit.e:480						if this_warn[1] = '+' then*/
                _2 = (object)SEQ_PTR(_this_warn_50144);
                _25714 = (object)*(((s1_ptr)_2)->base + 1LL);
                if (binary_op_a(NOTEQ, _25714, 43LL)){
                    _25714 = NOVALUE;
                    goto LC; // [288] 308
                }
                _25714 = NOVALUE;

                /** cominit.e:481							auto_add_warn = 1*/
                _auto_add_warn_50146 = 1LL;

                /** cominit.e:482							this_warn = this_warn[2 .. $]*/
                if (IS_SEQUENCE(_this_warn_50144)){
                        _25716 = SEQ_PTR(_this_warn_50144)->length;
                }
                else {
                    _25716 = 1;
                }
                rhs_slice_target = (object_ptr)&_this_warn_50144;
                RHS_Slice(_this_warn_50144, 2LL, _25716);
LC: 

                /** cominit.e:484						integer n = find(this_warn, warning_names)*/
                _n_50152 = find_from(_this_warn_50144, _36warning_names_21487, 1LL);

                /** cominit.e:485						if n != 0 then*/
                if (_n_50152 == 0LL)
                goto LD; // [319] 383

                /** cominit.e:486							if auto_add_warn or option_w = 1 then*/
                if (_auto_add_warn_50146 != 0) {
                    goto LE; // [325] 338
                }
                _25721 = (_option_w_50092 == 1LL);
                if (_25721 == 0)
                {
                    DeRef(_25721);
                    _25721 = NOVALUE;
                    goto LF; // [334] 357
                }
                else{
                    DeRef(_25721);
                    _25721 = NOVALUE;
                }
LE: 

                /** cominit.e:487								OpWarning = or_bits(OpWarning, warning_flags[n])*/
                _2 = (object)SEQ_PTR(_36warning_flags_21485);
                _25722 = (object)*(((s1_ptr)_2)->base + _n_50152);
                {uintptr_t tu;
                     tu = (uintptr_t)_36OpWarning_21510 | (uintptr_t)_25722;
                     _36OpWarning_21510 = MAKE_UINT(tu);
                }
                _25722 = NOVALUE;
                if (!IS_ATOM_INT(_36OpWarning_21510)) {
                    _1 = (object)(DBL_PTR(_36OpWarning_21510)->dbl);
                    DeRefDS(_36OpWarning_21510);
                    _36OpWarning_21510 = _1;
                }
                goto L10; // [354] 373
LF: 

                /** cominit.e:489								option_w = 1*/
                _option_w_50092 = 1LL;

                /** cominit.e:490								OpWarning = warning_flags[n]*/
                _2 = (object)SEQ_PTR(_36warning_flags_21485);
                _36OpWarning_21510 = (object)*(((s1_ptr)_2)->base + _n_50152);
L10: 

                /** cominit.e:493							prev_OpWarning = OpWarning*/
                _36prev_OpWarning_21511 = _36OpWarning_21510;
LD: 
                DeRef(_this_warn_50144);
                _this_warn_50144 = NOVALUE;

                /** cominit.e:495					end for*/
                _i_50142 = _i_50142 + 1LL;
                goto LA; // [387] 269
LB: 
                ;
            }
            goto L5; // [392] 786

            /** cominit.e:497				case "x" then*/
            case 11:

            /** cominit.e:498					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50098)){
                    _25725 = SEQ_PTR(_val_50098)->length;
            }
            else {
                _25725 = 1;
            }
            {
                object _i_50173;
                _i_50173 = 1LL;
L11: 
                if (_i_50173 > _25725){
                    goto L12; // [403] 542
                }

                /** cominit.e:499						sequence this_warn = val[i]*/
                DeRef(_this_warn_50175);
                _2 = (object)SEQ_PTR(_val_50098);
                _this_warn_50175 = (object)*(((s1_ptr)_2)->base + _i_50173);
                Ref(_this_warn_50175);

                /** cominit.e:500						integer auto_add_warn = 0*/
                _auto_add_warn_50177 = 0LL;

                /** cominit.e:501						if this_warn[1] = '+' then*/
                _2 = (object)SEQ_PTR(_this_warn_50175);
                _25727 = (object)*(((s1_ptr)_2)->base + 1LL);
                if (binary_op_a(NOTEQ, _25727, 43LL)){
                    _25727 = NOVALUE;
                    goto L13; // [429] 449
                }
                _25727 = NOVALUE;

                /** cominit.e:502							auto_add_warn = 1*/
                _auto_add_warn_50177 = 1LL;

                /** cominit.e:503							this_warn = this_warn[2 .. $]*/
                if (IS_SEQUENCE(_this_warn_50175)){
                        _25729 = SEQ_PTR(_this_warn_50175)->length;
                }
                else {
                    _25729 = 1;
                }
                rhs_slice_target = (object_ptr)&_this_warn_50175;
                RHS_Slice(_this_warn_50175, 2LL, _25729);
L13: 

                /** cominit.e:505						integer n = find(this_warn, warning_names)*/
                _n_50183 = find_from(_this_warn_50175, _36warning_names_21487, 1LL);

                /** cominit.e:506						if n != 0 then*/
                if (_n_50183 == 0LL)
                goto L14; // [460] 533

                /** cominit.e:507							if auto_add_warn or option_w = -1 then*/
                if (_auto_add_warn_50177 != 0) {
                    goto L15; // [466] 479
                }
                _25734 = (_option_w_50092 == -1LL);
                if (_25734 == 0)
                {
                    DeRef(_25734);
                    _25734 = NOVALUE;
                    goto L16; // [475] 501
                }
                else{
                    DeRef(_25734);
                    _25734 = NOVALUE;
                }
L15: 

                /** cominit.e:508								OpWarning = and_bits(OpWarning, not_bits(warning_flags[n]))*/
                _2 = (object)SEQ_PTR(_36warning_flags_21485);
                _25735 = (object)*(((s1_ptr)_2)->base + _n_50183);
                _25736 = not_bits(_25735);
                _25735 = NOVALUE;
                if (IS_ATOM_INT(_25736)) {
                    {uintptr_t tu;
                         tu = (uintptr_t)_36OpWarning_21510 & (uintptr_t)_25736;
                         _36OpWarning_21510 = MAKE_UINT(tu);
                    }
                }
                else {
                    temp_d.dbl = (eudouble)_36OpWarning_21510;
                    _36OpWarning_21510 = Dand_bits(&temp_d, DBL_PTR(_25736));
                }
                DeRef(_25736);
                _25736 = NOVALUE;
                if (!IS_ATOM_INT(_36OpWarning_21510)) {
                    _1 = (object)(DBL_PTR(_36OpWarning_21510)->dbl);
                    DeRefDS(_36OpWarning_21510);
                    _36OpWarning_21510 = _1;
                }
                goto L17; // [498] 523
L16: 

                /** cominit.e:510								option_w = -1*/
                _option_w_50092 = -1LL;

                /** cominit.e:511								OpWarning = all_warning_flag - warning_flags[n]*/
                _2 = (object)SEQ_PTR(_36warning_flags_21485);
                _25738 = (object)*(((s1_ptr)_2)->base + _n_50183);
                _36OpWarning_21510 = 32767LL - _25738;
                _25738 = NOVALUE;
L17: 

                /** cominit.e:514							prev_OpWarning = OpWarning*/
                _36prev_OpWarning_21511 = _36OpWarning_21510;
L14: 
                DeRef(_this_warn_50175);
                _this_warn_50175 = NOVALUE;

                /** cominit.e:516					end for*/
                _i_50173 = _i_50173 + 1LL;
                goto L11; // [537] 410
L12: 
                ;
            }
            goto L5; // [542] 786

            /** cominit.e:518				case "wf" then*/
            case 12:

            /** cominit.e:519					TempWarningName = val*/
            Ref(_val_50098);
            DeRef(_36TempWarningName_21453);
            _36TempWarningName_21453 = _val_50098;

            /** cominit.e:520				  	error:warning_file(TempWarningName)*/
            Ref(_36TempWarningName_21453);
            _7warning_file(_36TempWarningName_21453);
            goto L5; // [560] 786

            /** cominit.e:522				case "v", "version" then*/
            case 13:
            case 14:

            /** cominit.e:523					show_banner()*/
            _49show_banner();

            /** cominit.e:524					if not batch_job and not test_only then*/
            _25740 = (_36batch_job_21452 == 0);
            if (_25740 == 0) {
                goto L18; // [579] 634
            }
            _25742 = (_36test_only_21451 == 0);
            if (_25742 == 0)
            {
                DeRef(_25742);
                _25742 = NOVALUE;
                goto L18; // [589] 634
            }
            else{
                DeRef(_25742);
                _25742 = NOVALUE;
            }

            /** cominit.e:525						console:maybe_any_key(GetMsgText(MSG_PRESS_ANY_KEY_AND_WINDOW_WILL_CLOSE,0), 2)*/
            RefDS(_21993);
            _25743 = _39GetMsgText(278LL, 0LL, _21993);
            DeRef(_prompt_inlined_maybe_any_key_at_617_50219);
            _prompt_inlined_maybe_any_key_at_617_50219 = _25743;
            _25743 = NOVALUE;

            /** console.e:923		if not has_console() then*/

            /** console.e:59		return machine_func(M_HAS_CONSOLE, 0)*/
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50220);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50220 = machine(99LL, 0LL);
            if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50220)) {
                if (_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50220 != 0){
                    goto L19; // [616] 631
                }
            }
            else {
                if (DBL_PTR(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50220)->dbl != 0.0){
                    goto L19; // [616] 631
                }
            }

            /** console.e:924			any_key(prompt, con)*/
            Ref(_prompt_inlined_maybe_any_key_at_617_50219);
            _5any_key(_prompt_inlined_maybe_any_key_at_617_50219, 2LL);

            /** console.e:926	end procedure*/
            goto L19; // [628] 631
L19: 
            DeRef(_prompt_inlined_maybe_any_key_at_617_50219);
            _prompt_inlined_maybe_any_key_at_617_50219 = NOVALUE;
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50220);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50220 = NOVALUE;
L18: 

            /** cominit.e:528					abort(0)*/
            UserCleanup(0LL);
            goto L5; // [638] 786

            /** cominit.e:530				case "copyright" then*/
            case 15:

            /** cominit.e:531					show_copyrights()*/
            _49show_copyrights();

            /** cominit.e:532					if not batch_job and not test_only then*/
            _25744 = (_36batch_job_21452 == 0);
            if (_25744 == 0) {
                goto L1A; // [655] 710
            }
            _25746 = (_36test_only_21451 == 0);
            if (_25746 == 0)
            {
                DeRef(_25746);
                _25746 = NOVALUE;
                goto L1A; // [665] 710
            }
            else{
                DeRef(_25746);
                _25746 = NOVALUE;
            }

            /** cominit.e:533						console:maybe_any_key(GetMsgText(MSG_PRESS_ANY_KEY_AND_WINDOW_WILL_CLOSE,0), 2)*/
            RefDS(_21993);
            _25747 = _39GetMsgText(278LL, 0LL, _21993);
            DeRef(_prompt_inlined_maybe_any_key_at_693_50232);
            _prompt_inlined_maybe_any_key_at_693_50232 = _25747;
            _25747 = NOVALUE;

            /** console.e:923		if not has_console() then*/

            /** console.e:59		return machine_func(M_HAS_CONSOLE, 0)*/
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50233);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50233 = machine(99LL, 0LL);
            if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50233)) {
                if (_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50233 != 0){
                    goto L1B; // [692] 707
                }
            }
            else {
                if (DBL_PTR(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50233)->dbl != 0.0){
                    goto L1B; // [692] 707
                }
            }

            /** console.e:924			any_key(prompt, con)*/
            Ref(_prompt_inlined_maybe_any_key_at_693_50232);
            _5any_key(_prompt_inlined_maybe_any_key_at_693_50232, 2LL);

            /** console.e:926	end procedure*/
            goto L1B; // [704] 707
L1B: 
            DeRef(_prompt_inlined_maybe_any_key_at_693_50232);
            _prompt_inlined_maybe_any_key_at_693_50232 = NOVALUE;
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50233);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50233 = NOVALUE;
L1A: 

            /** cominit.e:535					abort(0)*/
            UserCleanup(0LL);
            goto L5; // [714] 786

            /** cominit.e:537				case "eudir" then*/
            case 16:

            /** cominit.e:538					set_eudir( val )*/
            Ref(_val_50098);
            _37set_eudir(_val_50098);
            goto L5; // [725] 786

            /** cominit.e:540				case "trace-lines" then*/
            case 17:

            /** cominit.e:541					val = value( val )*/
            Ref(_val_50098);
            _0 = _val_50098;
            _val_50098 = _6value(_val_50098, 1LL, _6GET_SHORT_ANSWER_11168);
            DeRef(_0);

            /** cominit.e:542					if val[1] = GET_SUCCESS then*/
            _2 = (object)SEQ_PTR(_val_50098);
            _25749 = (object)*(((s1_ptr)_2)->base + 1LL);
            if (binary_op_a(NOTEQ, _25749, 0LL)){
                _25749 = NOVALUE;
                goto L1C; // [749] 767
            }
            _25749 = NOVALUE;

            /** cominit.e:543						trace_lines = floor( val[2] )*/
            _2 = (object)SEQ_PTR(_val_50098);
            _25751 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (IS_ATOM_INT(_25751))
            _36trace_lines_64507 = e_floor(_25751);
            else
            _36trace_lines_64507 = unary_op(FLOOR, _25751);
            _25751 = NOVALUE;
            if (!IS_ATOM_INT(_36trace_lines_64507)) {
                _1 = (object)(DBL_PTR(_36trace_lines_64507)->dbl);
                DeRefDS(_36trace_lines_64507);
                _36trace_lines_64507 = _1;
            }
            goto L1D; // [764] 785
L1C: 

            /** cominit.e:545						puts(2, GetMsgText( BAD_TRACE_LINES ) )*/
            RefDS(_21993);
            _25753 = _39GetMsgText(604LL, 1LL, _21993);
            EPuts(2LL, _25753); // DJP 
            DeRef(_25753);
            _25753 = NOVALUE;

            /** cominit.e:546						abort( 1 )*/
            UserCleanup(1LL);
L1D: 
        ;}L5: 
        DeRef(_key_50096);
        _key_50096 = NOVALUE;
        DeRef(_val_50098);
        _val_50098 = NOVALUE;

        /** cominit.e:549		end for*/
        _idx_50094 = _idx_50094 + 1LL;
        goto L1; // [790] 27
L2: 
        ;
    }

    /** cominit.e:551		if length(LocalizeQual) = 0 then*/
    if (IS_SEQUENCE(_37LocalizeQual_15425)){
            _25754 = SEQ_PTR(_37LocalizeQual_15425)->length;
    }
    else {
        _25754 = 1;
    }
    if (_25754 != 0LL)
    goto L1E; // [802] 815

    /** cominit.e:552			LocalizeQual = {"en"}*/
    _0 = _37LocalizeQual_15425;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_25756);
    ((intptr_t*)_2)[1] = _25756;
    _37LocalizeQual_15425 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1E: 

    /** cominit.e:554	end procedure*/
    DeRef(_opts_50089);
    DeRef(_opt_keys_50090);
    DeRef(_25740);
    _25740 = NOVALUE;
    DeRef(_25744);
    _25744 = NOVALUE;
    return;
    ;
}


void _49finalize_command_line(object _opts_50259)
{
    object _extras_50266 = NOVALUE;
    object _pairs_50271 = NOVALUE;
    object _pair_50276 = NOVALUE;
    object _25786 = NOVALUE;
    object _25784 = NOVALUE;
    object _25781 = NOVALUE;
    object _25780 = NOVALUE;
    object _25779 = NOVALUE;
    object _25778 = NOVALUE;
    object _25777 = NOVALUE;
    object _25776 = NOVALUE;
    object _25775 = NOVALUE;
    object _25774 = NOVALUE;
    object _25773 = NOVALUE;
    object _25772 = NOVALUE;
    object _25771 = NOVALUE;
    object _25770 = NOVALUE;
    object _25769 = NOVALUE;
    object _25768 = NOVALUE;
    object _25767 = NOVALUE;
    object _25766 = NOVALUE;
    object _25765 = NOVALUE;
    object _25764 = NOVALUE;
    object _25762 = NOVALUE;
    object _25759 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:562		if Strict_is_on then -- overrides any -W/-X switches*/
    if (_36Strict_is_on_21508 == 0)
    {
        goto L1; // [5] 27
    }
    else{
    }

    /** cominit.e:563			OpWarning = all_warning_flag*/
    _36OpWarning_21510 = 32767LL;

    /** cominit.e:564			prev_OpWarning = OpWarning*/
    _36prev_OpWarning_21511 = 32767LL;
L1: 

    /** cominit.e:569		sequence extras = m:get(opts, cmdline:EXTRAS)*/
    Ref(_opts_50259);
    RefDS(_4EXTRAS_14176);
    _0 = _extras_50266;
    _extras_50266 = _29get(_opts_50259, _4EXTRAS_14176, 0LL);
    DeRef(_0);

    /** cominit.e:570		if length(extras) > 0 then*/
    if (IS_SEQUENCE(_extras_50266)){
            _25759 = SEQ_PTR(_extras_50266)->length;
    }
    else {
        _25759 = 1;
    }
    if (_25759 <= 0LL)
    goto L2; // [44] 270

    /** cominit.e:571			sequence pairs = m:pairs( opts )*/
    Ref(_opts_50259);
    _0 = _pairs_50271;
    _pairs_50271 = _29pairs(_opts_50259, 0LL);
    DeRef(_0);

    /** cominit.e:573			for i = 1 to length( pairs ) do*/
    if (IS_SEQUENCE(_pairs_50271)){
            _25762 = SEQ_PTR(_pairs_50271)->length;
    }
    else {
        _25762 = 1;
    }
    {
        object _i_50274;
        _i_50274 = 1LL;
L3: 
        if (_i_50274 > _25762){
            goto L4; // [62] 237
        }

        /** cominit.e:574				sequence pair = pairs[i]*/
        DeRef(_pair_50276);
        _2 = (object)SEQ_PTR(_pairs_50271);
        _pair_50276 = (object)*(((s1_ptr)_2)->base + _i_50274);
        Ref(_pair_50276);

        /** cominit.e:575				if equal( pair[1], cmdline:EXTRAS ) then*/
        _2 = (object)SEQ_PTR(_pair_50276);
        _25764 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (_25764 == _4EXTRAS_14176)
        _25765 = 1;
        else if (IS_ATOM_INT(_25764) && IS_ATOM_INT(_4EXTRAS_14176))
        _25765 = 0;
        else
        _25765 = (compare(_25764, _4EXTRAS_14176) == 0);
        _25764 = NOVALUE;
        if (_25765 == 0)
        {
            _25765 = NOVALUE;
            goto L5; // [89] 99
        }
        else{
            _25765 = NOVALUE;
        }

        /** cominit.e:576					continue*/
        DeRefDS(_pair_50276);
        _pair_50276 = NOVALUE;
        goto L6; // [96] 232
L5: 

        /** cominit.e:578				pair[1] = prepend( pair[1], '-' )*/
        _2 = (object)SEQ_PTR(_pair_50276);
        _25766 = (object)*(((s1_ptr)_2)->base + 1LL);
        Prepend(&_25767, _25766, 45LL);
        _25766 = NOVALUE;
        _2 = (object)SEQ_PTR(_pair_50276);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _pair_50276 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _25767;
        if( _1 != _25767 ){
            DeRef(_1);
        }
        _25767 = NOVALUE;

        /** cominit.e:579				if sequence( pair[2] ) then*/
        _2 = (object)SEQ_PTR(_pair_50276);
        _25768 = (object)*(((s1_ptr)_2)->base + 2LL);
        _25769 = IS_SEQUENCE(_25768);
        _25768 = NOVALUE;
        if (_25769 == 0)
        {
            _25769 = NOVALUE;
            goto L7; // [122] 215
        }
        else{
            _25769 = NOVALUE;
        }

        /** cominit.e:580					if length( pair[2] ) and sequence( pair[2][1] ) then*/
        _2 = (object)SEQ_PTR(_pair_50276);
        _25770 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (IS_SEQUENCE(_25770)){
                _25771 = SEQ_PTR(_25770)->length;
        }
        else {
            _25771 = 1;
        }
        _25770 = NOVALUE;
        if (_25771 == 0) {
            goto L8; // [134] 203
        }
        _2 = (object)SEQ_PTR(_pair_50276);
        _25773 = (object)*(((s1_ptr)_2)->base + 2LL);
        _2 = (object)SEQ_PTR(_25773);
        _25774 = (object)*(((s1_ptr)_2)->base + 1LL);
        _25773 = NOVALUE;
        _25775 = IS_SEQUENCE(_25774);
        _25774 = NOVALUE;
        if (_25775 == 0)
        {
            _25775 = NOVALUE;
            goto L8; // [150] 203
        }
        else{
            _25775 = NOVALUE;
        }

        /** cominit.e:581						for j = 1 to length( pair[2] ) do*/
        _2 = (object)SEQ_PTR(_pair_50276);
        _25776 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (IS_SEQUENCE(_25776)){
                _25777 = SEQ_PTR(_25776)->length;
        }
        else {
            _25777 = 1;
        }
        _25776 = NOVALUE;
        {
            object _j_50294;
            _j_50294 = 1LL;
L9: 
            if (_j_50294 > _25777){
                goto LA; // [162] 200
            }

            /** cominit.e:582							switches &= { pair[1], pair[2][j] }*/
            _2 = (object)SEQ_PTR(_pair_50276);
            _25778 = (object)*(((s1_ptr)_2)->base + 1LL);
            _2 = (object)SEQ_PTR(_pair_50276);
            _25779 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_25779);
            _25780 = (object)*(((s1_ptr)_2)->base + _j_50294);
            _25779 = NOVALUE;
            Ref(_25780);
            Ref(_25778);
            _1 = NewS1(2);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t *)_2)[1] = _25778;
            ((intptr_t *)_2)[2] = _25780;
            _25781 = MAKE_SEQ(_1);
            _25780 = NOVALUE;
            _25778 = NOVALUE;
            Concat((object_ptr)&_49switches_49592, _49switches_49592, _25781);
            DeRefDS(_25781);
            _25781 = NOVALUE;

            /** cominit.e:583						end for*/
            _j_50294 = _j_50294 + 1LL;
            goto L9; // [195] 169
LA: 
            ;
        }
        goto LB; // [200] 228
L8: 

        /** cominit.e:585						switches &= pair*/
        Concat((object_ptr)&_49switches_49592, _49switches_49592, _pair_50276);
        goto LB; // [212] 228
L7: 

        /** cominit.e:588					switches = append( switches, pair[1] )*/
        _2 = (object)SEQ_PTR(_pair_50276);
        _25784 = (object)*(((s1_ptr)_2)->base + 1LL);
        Ref(_25784);
        Append(&_49switches_49592, _49switches_49592, _25784);
        _25784 = NOVALUE;
LB: 
        DeRef(_pair_50276);
        _pair_50276 = NOVALUE;

        /** cominit.e:590			end for*/
L6: 
        _i_50274 = _i_50274 + 1LL;
        goto L3; // [232] 69
L4: 
        ;
    }

    /** cominit.e:592			Argv = Argv[2..3] & extras*/
    rhs_slice_target = (object_ptr)&_25786;
    RHS_Slice(_36Argv_21450, 2LL, 3LL);
    Concat((object_ptr)&_36Argv_21450, _25786, _extras_50266);
    DeRefDS(_25786);
    _25786 = NOVALUE;
    DeRef(_25786);
    _25786 = NOVALUE;

    /** cominit.e:593			Argc = length(Argv)*/
    if (IS_SEQUENCE(_36Argv_21450)){
            _36Argc_21449 = SEQ_PTR(_36Argv_21450)->length;
    }
    else {
        _36Argc_21449 = 1;
    }

    /** cominit.e:595			src_name = extras[1]*/
    DeRef(_49src_name_49591);
    _2 = (object)SEQ_PTR(_extras_50266);
    _49src_name_49591 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_49src_name_49591);
L2: 
    DeRef(_pairs_50271);
    _pairs_50271 = NOVALUE;

    /** cominit.e:597	end procedure*/
    DeRef(_opts_50259);
    DeRef(_extras_50266);
    _25770 = NOVALUE;
    _25776 = NOVALUE;
    return;
    ;
}



// 0xD006934D
