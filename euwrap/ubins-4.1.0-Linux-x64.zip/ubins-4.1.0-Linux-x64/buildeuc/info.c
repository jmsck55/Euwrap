// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _33arch_bits()
{
    object _6732 = NOVALUE;
    object _6731 = NOVALUE;
    object _6730 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:72		return sprintf( "%d-bit", 8 * sizeof( C_POINTER ) )*/
    _6730 = eu_sizeof( 50331649LL );
    {
        int128_t p128 = (int128_t)8LL * (int128_t)_6730;
        if( p128 != (int128_t)(_6731 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
            _6731 = NewDouble( (eudouble)p128 );
        }
    }
    _6730 = NOVALUE;
    _6732 = EPrintf(-9999999, _6729, _6731);
    DeRef(_6731);
    _6731 = NOVALUE;
    return _6732;
    ;
}


object _33version_major()
{
    object _6741 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:100		return version_info[MAJ_VER]*/
    _2 = (object)SEQ_PTR(_33version_info_11977);
    _6741 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_6741);
    return _6741;
    ;
}


object _33version_minor()
{
    object _6742 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:112		return version_info[MIN_VER]*/
    _2 = (object)SEQ_PTR(_33version_info_11977);
    _6742 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_6742);
    return _6742;
    ;
}


object _33version_patch()
{
    object _6743 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:124		return version_info[PAT_VER]*/
    _2 = (object)SEQ_PTR(_33version_info_11977);
    _6743 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_6743);
    return _6743;
    ;
}


object _33version_node(object _full_12022)
{
    object _6750 = NOVALUE;
    object _6749 = NOVALUE;
    object _6748 = NOVALUE;
    object _6747 = NOVALUE;
    object _6746 = NOVALUE;
    object _6745 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:141		if full or length(version_info[NODE]) < 12 then*/
    if (0LL != 0) {
        goto L1; // [5] 27
    }
    _2 = (object)SEQ_PTR(_33version_info_11977);
    _6745 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (IS_SEQUENCE(_6745)){
            _6746 = SEQ_PTR(_6745)->length;
    }
    else {
        _6746 = 1;
    }
    _6745 = NOVALUE;
    _6747 = (_6746 < 12LL);
    _6746 = NOVALUE;
    if (_6747 == 0)
    {
        DeRef(_6747);
        _6747 = NOVALUE;
        goto L2; // [23] 40
    }
    else{
        DeRef(_6747);
        _6747 = NOVALUE;
    }
L1: 

    /** info.e:142			return version_info[NODE]*/
    _2 = (object)SEQ_PTR(_33version_info_11977);
    _6748 = (object)*(((s1_ptr)_2)->base + 5LL);
    Ref(_6748);
    _6745 = NOVALUE;
    return _6748;
L2: 

    /** info.e:145		return version_info[NODE][1..12]*/
    _2 = (object)SEQ_PTR(_33version_info_11977);
    _6749 = (object)*(((s1_ptr)_2)->base + 5LL);
    rhs_slice_target = (object_ptr)&_6750;
    RHS_Slice(_6749, 1LL, 12LL);
    _6749 = NOVALUE;
    _6748 = NOVALUE;
    _6745 = NOVALUE;
    return _6750;
    ;
}


object _33version_date(object _full_12036)
{
    object _6759 = NOVALUE;
    object _6758 = NOVALUE;
    object _6757 = NOVALUE;
    object _6756 = NOVALUE;
    object _6755 = NOVALUE;
    object _6754 = NOVALUE;
    object _6752 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:181		if full or is_developmental or length(version_info[REVISION_DATE]) < 10 then*/
    if (_full_12036 != 0) {
        _6752 = 1;
        goto L1; // [5] 15
    }
    _6752 = (_33is_developmental_11979 != 0);
L1: 
    if (_6752 != 0) {
        goto L2; // [15] 37
    }
    _2 = (object)SEQ_PTR(_33version_info_11977);
    _6754 = (object)*(((s1_ptr)_2)->base + 7LL);
    if (IS_SEQUENCE(_6754)){
            _6755 = SEQ_PTR(_6754)->length;
    }
    else {
        _6755 = 1;
    }
    _6754 = NOVALUE;
    _6756 = (_6755 < 10LL);
    _6755 = NOVALUE;
    if (_6756 == 0)
    {
        DeRef(_6756);
        _6756 = NOVALUE;
        goto L3; // [33] 50
    }
    else{
        DeRef(_6756);
        _6756 = NOVALUE;
    }
L2: 

    /** info.e:182			return version_info[REVISION_DATE]*/
    _2 = (object)SEQ_PTR(_33version_info_11977);
    _6757 = (object)*(((s1_ptr)_2)->base + 7LL);
    Ref(_6757);
    _6754 = NOVALUE;
    return _6757;
L3: 

    /** info.e:185		return version_info[REVISION_DATE][1..10]*/
    _2 = (object)SEQ_PTR(_33version_info_11977);
    _6758 = (object)*(((s1_ptr)_2)->base + 7LL);
    rhs_slice_target = (object_ptr)&_6759;
    RHS_Slice(_6758, 1LL, 10LL);
    _6758 = NOVALUE;
    _6757 = NOVALUE;
    _6754 = NOVALUE;
    return _6759;
    ;
}


object _33version_string(object _full_12051)
{
    object _version_revision_inlined_version_revision_at_41_12060 = NOVALUE;
    object _6779 = NOVALUE;
    object _6778 = NOVALUE;
    object _6777 = NOVALUE;
    object _6776 = NOVALUE;
    object _6775 = NOVALUE;
    object _6774 = NOVALUE;
    object _6773 = NOVALUE;
    object _6772 = NOVALUE;
    object _6770 = NOVALUE;
    object _6769 = NOVALUE;
    object _6768 = NOVALUE;
    object _6767 = NOVALUE;
    object _6766 = NOVALUE;
    object _6765 = NOVALUE;
    object _6764 = NOVALUE;
    object _6763 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:225		if full or is_developmental then*/
    if (0LL != 0) {
        goto L1; // [5] 16
    }
    if (_33is_developmental_11979 == 0)
    {
        goto L2; // [12] 80
    }
    else{
    }
L1: 

    /** info.e:226			return sprintf("%d.%d.%d %s (%d:%s, %s)", {*/
    _2 = (object)SEQ_PTR(_33version_info_11977);
    _6763 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_33version_info_11977);
    _6764 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_33version_info_11977);
    _6765 = (object)*(((s1_ptr)_2)->base + 3LL);
    _2 = (object)SEQ_PTR(_33version_info_11977);
    _6766 = (object)*(((s1_ptr)_2)->base + 4LL);

    /** info.e:157		return version_info[REVISION]*/
    DeRef(_version_revision_inlined_version_revision_at_41_12060);
    _2 = (object)SEQ_PTR(_33version_info_11977);
    _version_revision_inlined_version_revision_at_41_12060 = (object)*(((s1_ptr)_2)->base + 6LL);
    Ref(_version_revision_inlined_version_revision_at_41_12060);
    _6767 = _33version_node(0LL);
    _6768 = _33version_date(_full_12051);
    _1 = NewS1(7);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_6763);
    ((intptr_t*)_2)[1] = _6763;
    Ref(_6764);
    ((intptr_t*)_2)[2] = _6764;
    Ref(_6765);
    ((intptr_t*)_2)[3] = _6765;
    Ref(_6766);
    ((intptr_t*)_2)[4] = _6766;
    Ref(_version_revision_inlined_version_revision_at_41_12060);
    ((intptr_t*)_2)[5] = _version_revision_inlined_version_revision_at_41_12060;
    ((intptr_t*)_2)[6] = _6767;
    ((intptr_t*)_2)[7] = _6768;
    _6769 = MAKE_SEQ(_1);
    _6768 = NOVALUE;
    _6767 = NOVALUE;
    _6766 = NOVALUE;
    _6765 = NOVALUE;
    _6764 = NOVALUE;
    _6763 = NOVALUE;
    _6770 = EPrintf(-9999999, _6762, _6769);
    DeRefDS(_6769);
    _6769 = NOVALUE;
    return _6770;
    goto L3; // [77] 132
L2: 

    /** info.e:236			return sprintf("%d.%d.%d %s (%s, %s)", {*/
    _2 = (object)SEQ_PTR(_33version_info_11977);
    _6772 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_33version_info_11977);
    _6773 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_33version_info_11977);
    _6774 = (object)*(((s1_ptr)_2)->base + 3LL);
    _2 = (object)SEQ_PTR(_33version_info_11977);
    _6775 = (object)*(((s1_ptr)_2)->base + 4LL);
    _6776 = _33version_node(0LL);
    _6777 = _33version_date(_full_12051);
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_6772);
    ((intptr_t*)_2)[1] = _6772;
    Ref(_6773);
    ((intptr_t*)_2)[2] = _6773;
    Ref(_6774);
    ((intptr_t*)_2)[3] = _6774;
    Ref(_6775);
    ((intptr_t*)_2)[4] = _6775;
    ((intptr_t*)_2)[5] = _6776;
    ((intptr_t*)_2)[6] = _6777;
    _6778 = MAKE_SEQ(_1);
    _6777 = NOVALUE;
    _6776 = NOVALUE;
    _6775 = NOVALUE;
    _6774 = NOVALUE;
    _6773 = NOVALUE;
    _6772 = NOVALUE;
    _6779 = EPrintf(-9999999, _6771, _6778);
    DeRefDS(_6778);
    _6778 = NOVALUE;
    DeRef(_6770);
    _6770 = NOVALUE;
    return _6779;
L3: 
    ;
}


object _33version_string_long(object _full_12082)
{
    object _platform_name_inlined_platform_name_at_8_12086 = NOVALUE;
    object _6786 = NOVALUE;
    object _6785 = NOVALUE;
    object _6783 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:284		return version_string(full) & " for " & platform_name() & " " & arch_bits()*/
    _6783 = _33version_string(0LL);

    /** info.e:48		ifdef WINDOWS then*/

    /** info.e:51			return "Linux"*/
    RefDS(_6723);
    DeRefi(_platform_name_inlined_platform_name_at_8_12086);
    _platform_name_inlined_platform_name_at_8_12086 = _6723;
    _6785 = _33arch_bits();
    {
        object concat_list[5];

        concat_list[0] = _6785;
        concat_list[1] = _2676;
        concat_list[2] = _platform_name_inlined_platform_name_at_8_12086;
        concat_list[3] = _6784;
        concat_list[4] = _6783;
        Concat_N((object_ptr)&_6786, concat_list, 5);
    }
    DeRef(_6785);
    _6785 = NOVALUE;
    DeRef(_6783);
    _6783 = NOVALUE;
    return _6786;
    ;
}


object _33all_copyrights()
{
    object _pcre_copyright_inlined_pcre_copyright_at_19_12108 = NOVALUE;
    object _euphoria_copyright_2__tmp_at2_12106 = NOVALUE;
    object _euphoria_copyright_1__tmp_at2_12105 = NOVALUE;
    object _euphoria_copyright_inlined_euphoria_copyright_at_2_12104 = NOVALUE;
    object _6795 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:355		return {*/

    /** info.e:309		return {*/
    _0 = _euphoria_copyright_1__tmp_at2_12105;
    _euphoria_copyright_1__tmp_at2_12105 = _33version_string_long(0LL);
    DeRef(_0);
    if (IS_SEQUENCE(_6787) && IS_ATOM(_euphoria_copyright_1__tmp_at2_12105)) {
        Ref(_euphoria_copyright_1__tmp_at2_12105);
        Append(&_euphoria_copyright_2__tmp_at2_12106, _6787, _euphoria_copyright_1__tmp_at2_12105);
    }
    else if (IS_ATOM(_6787) && IS_SEQUENCE(_euphoria_copyright_1__tmp_at2_12105)) {
    }
    else {
        Concat((object_ptr)&_euphoria_copyright_2__tmp_at2_12106, _6787, _euphoria_copyright_1__tmp_at2_12105);
    }
    RefDS(_6790);
    RefDS(_euphoria_copyright_2__tmp_at2_12106);
    DeRef(_euphoria_copyright_inlined_euphoria_copyright_at_2_12104);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _euphoria_copyright_2__tmp_at2_12106;
    ((intptr_t *)_2)[2] = _6790;
    _euphoria_copyright_inlined_euphoria_copyright_at_2_12104 = MAKE_SEQ(_1);
    DeRef(_euphoria_copyright_1__tmp_at2_12105);
    _euphoria_copyright_1__tmp_at2_12105 = NOVALUE;
    DeRef(_euphoria_copyright_2__tmp_at2_12106);
    _euphoria_copyright_2__tmp_at2_12106 = NOVALUE;

    /** info.e:331		return {*/
    RefDS(_6793);
    RefDS(_6792);
    DeRef(_pcre_copyright_inlined_pcre_copyright_at_19_12108);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _6792;
    ((intptr_t *)_2)[2] = _6793;
    _pcre_copyright_inlined_pcre_copyright_at_19_12108 = MAKE_SEQ(_1);
    RefDS(_pcre_copyright_inlined_pcre_copyright_at_19_12108);
    RefDS(_euphoria_copyright_inlined_euphoria_copyright_at_2_12104);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _euphoria_copyright_inlined_euphoria_copyright_at_2_12104;
    ((intptr_t *)_2)[2] = _pcre_copyright_inlined_pcre_copyright_at_19_12108;
    _6795 = MAKE_SEQ(_1);
    return _6795;
    ;
}



// 0xB3969C8C
