// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _44clear_fwd_refs()
{
    object _0, _1, _2;
    

    /** fwdref.e:70		fwdref_count = 0*/
    _44fwdref_count_62785 = 0LL;

    /** fwdref.e:71	end procedure*/
    return;
    ;
}


object _44get_fwdref_count()
{
    object _0, _1, _2;
    

    /** fwdref.e:74		return fwdref_count*/
    return _44fwdref_count_62785;
    ;
}


void _44set_glabel_block(object _ref_62792, object _block_62794)
{
    object _30828 = NOVALUE;
    object _30827 = NOVALUE;
    object _30825 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_62792)) {
        _1 = (object)(DBL_PTR(_ref_62792)->dbl);
        DeRefDS(_ref_62792);
        _ref_62792 = _1;
    }
    if (!IS_ATOM_INT(_block_62794)) {
        _1 = (object)(DBL_PTR(_block_62794)->dbl);
        DeRefDS(_block_62794);
        _block_62794 = _1;
    }

    /** fwdref.e:78		forward_references[ref][FR_DATA] &= block*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62765 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_62792 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _30827 = (object)*(((s1_ptr)_2)->base + 12LL);
    _30825 = NOVALUE;
    if (IS_SEQUENCE(_30827) && IS_ATOM(_block_62794)) {
        Append(&_30828, _30827, _block_62794);
    }
    else if (IS_ATOM(_30827) && IS_SEQUENCE(_block_62794)) {
    }
    else {
        Concat((object_ptr)&_30828, _30827, _block_62794);
        _30827 = NOVALUE;
    }
    _30827 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30828;
    if( _1 != _30828 ){
        DeRef(_1);
    }
    _30828 = NOVALUE;
    _30825 = NOVALUE;

    /** fwdref.e:79	end procedure*/
    return;
    ;
}


void _44replace_code(object _code_62806, object _start_62807, object _finish_62808, object _subprog_62809)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_finish_62808)) {
        _1 = (object)(DBL_PTR(_finish_62808)->dbl);
        DeRefDS(_finish_62808);
        _finish_62808 = _1;
    }
    if (!IS_ATOM_INT(_subprog_62809)) {
        _1 = (object)(DBL_PTR(_subprog_62809)->dbl);
        DeRefDS(_subprog_62809);
        _subprog_62809 = _1;
    }

    /** fwdref.e:88		shifting_sub = subprog*/
    _44shifting_sub_62784 = _subprog_62809;

    /** fwdref.e:89		shift:replace_code( code, start, finish )*/
    RefDS(_code_62806);
    _66replace_code(_code_62806, _start_62807, _finish_62808);

    /** fwdref.e:90		shifting_sub = 0*/
    _44shifting_sub_62784 = 0LL;

    /** fwdref.e:91	end procedure*/
    DeRefDS(_code_62806);
    return;
    ;
}


void _44resolved_reference(object _ref_62812)
{
    object _file_62813 = NOVALUE;
    object _subprog_62816 = NOVALUE;
    object _tx_62819 = NOVALUE;
    object _ax_62820 = NOVALUE;
    object _sp_62821 = NOVALUE;
    object _r_62836 = NOVALUE;
    object _r_62854 = NOVALUE;
    object _30852 = NOVALUE;
    object _30851 = NOVALUE;
    object _30850 = NOVALUE;
    object _30848 = NOVALUE;
    object _30845 = NOVALUE;
    object _30843 = NOVALUE;
    object _30841 = NOVALUE;
    object _30840 = NOVALUE;
    object _30838 = NOVALUE;
    object _30836 = NOVALUE;
    object _30834 = NOVALUE;
    object _30833 = NOVALUE;
    object _30831 = NOVALUE;
    object _30829 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:95			file    = forward_references[ref][FR_FILE],*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    _30829 = (object)*(((s1_ptr)_2)->base + _ref_62812);
    _2 = (object)SEQ_PTR(_30829);
    _file_62813 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_file_62813)){
        _file_62813 = (object)DBL_PTR(_file_62813)->dbl;
    }
    _30829 = NOVALUE;

    /** fwdref.e:96			subprog = forward_references[ref][FR_SUBPROG]*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    _30831 = (object)*(((s1_ptr)_2)->base + _ref_62812);
    _2 = (object)SEQ_PTR(_30831);
    _subprog_62816 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_subprog_62816)){
        _subprog_62816 = (object)DBL_PTR(_subprog_62816)->dbl;
    }
    _30831 = NOVALUE;

    /** fwdref.e:99			tx = 0,*/
    _tx_62819 = 0LL;

    /** fwdref.e:100			ax = 0,*/
    _ax_62820 = 0LL;

    /** fwdref.e:101			sp = 0*/
    _sp_62821 = 0LL;

    /** fwdref.e:103		if forward_references[ref][FR_SUBPROG] = TopLevelSub then*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    _30833 = (object)*(((s1_ptr)_2)->base + _ref_62812);
    _2 = (object)SEQ_PTR(_30833);
    _30834 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30833 = NOVALUE;
    if (binary_op_a(NOTEQ, _30834, _36TopLevelSub_21446)){
        _30834 = NOVALUE;
        goto L1; // [60] 80
    }
    _30834 = NOVALUE;

    /** fwdref.e:104			tx = find( ref, toplevel_references[file] )*/
    _2 = (object)SEQ_PTR(_44toplevel_references_62768);
    _30836 = (object)*(((s1_ptr)_2)->base + _file_62813);
    _tx_62819 = find_from(_ref_62812, _30836, 1LL);
    _30836 = NOVALUE;
    goto L2; // [77] 111
L1: 

    /** fwdref.e:106			sp = find( subprog, active_subprogs[file] )*/
    _2 = (object)SEQ_PTR(_44active_subprogs_62766);
    _30838 = (object)*(((s1_ptr)_2)->base + _file_62813);
    _sp_62821 = find_from(_subprog_62816, _30838, 1LL);
    _30838 = NOVALUE;

    /** fwdref.e:107			ax = find( ref, active_references[file][sp] )*/
    _2 = (object)SEQ_PTR(_44active_references_62767);
    _30840 = (object)*(((s1_ptr)_2)->base + _file_62813);
    _2 = (object)SEQ_PTR(_30840);
    _30841 = (object)*(((s1_ptr)_2)->base + _sp_62821);
    _30840 = NOVALUE;
    _ax_62820 = find_from(_ref_62812, _30841, 1LL);
    _30841 = NOVALUE;
L2: 

    /** fwdref.e:110		if ax then*/
    if (_ax_62820 == 0)
    {
        goto L3; // [113] 253
    }
    else{
    }

    /** fwdref.e:111			sequence r = active_references[file][sp] */
    _2 = (object)SEQ_PTR(_44active_references_62767);
    _30843 = (object)*(((s1_ptr)_2)->base + _file_62813);
    DeRef(_r_62836);
    _2 = (object)SEQ_PTR(_30843);
    _r_62836 = (object)*(((s1_ptr)_2)->base + _sp_62821);
    Ref(_r_62836);
    _30843 = NOVALUE;

    /** fwdref.e:112			active_references[file][sp] = 0*/
    _2 = (object)SEQ_PTR(_44active_references_62767);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_references_62767 = MAKE_SEQ(_2);
    }
    _3 = (object)(_file_62813 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _sp_62821);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30845 = NOVALUE;

    /** fwdref.e:113			r = remove( r, ax )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_62836);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ax_62820)) ? _ax_62820 : (object)(DBL_PTR(_ax_62820)->dbl);
        int stop = (IS_ATOM_INT(_ax_62820)) ? _ax_62820 : (object)(DBL_PTR(_ax_62820)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_62836), start, &_r_62836 );
            }
            else Tail(SEQ_PTR(_r_62836), stop+1, &_r_62836);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_62836), start, &_r_62836);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_62836 = Remove_elements(start, stop, (SEQ_PTR(_r_62836)->ref == 1));
        }
    }

    /** fwdref.e:114			active_references[file][sp] = r*/
    _2 = (object)SEQ_PTR(_44active_references_62767);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_references_62767 = MAKE_SEQ(_2);
    }
    _3 = (object)(_file_62813 + ((s1_ptr)_2)->base);
    RefDS(_r_62836);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _sp_62821);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_62836;
    DeRef(_1);
    _30848 = NOVALUE;

    /** fwdref.e:116			if not length( active_references[file][sp] ) then*/
    _2 = (object)SEQ_PTR(_44active_references_62767);
    _30850 = (object)*(((s1_ptr)_2)->base + _file_62813);
    _2 = (object)SEQ_PTR(_30850);
    _30851 = (object)*(((s1_ptr)_2)->base + _sp_62821);
    _30850 = NOVALUE;
    if (IS_SEQUENCE(_30851)){
            _30852 = SEQ_PTR(_30851)->length;
    }
    else {
        _30852 = 1;
    }
    _30851 = NOVALUE;
    if (_30852 != 0)
    goto L4; // [178] 248
    _30852 = NOVALUE;

    /** fwdref.e:117				r = active_references[file]*/
    DeRefDS(_r_62836);
    _2 = (object)SEQ_PTR(_44active_references_62767);
    _r_62836 = (object)*(((s1_ptr)_2)->base + _file_62813);
    Ref(_r_62836);

    /** fwdref.e:118				active_references[file] = 0*/
    _2 = (object)SEQ_PTR(_44active_references_62767);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_references_62767 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_62813);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** fwdref.e:119				r = remove( r, sp )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_62836);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_sp_62821)) ? _sp_62821 : (object)(DBL_PTR(_sp_62821)->dbl);
        int stop = (IS_ATOM_INT(_sp_62821)) ? _sp_62821 : (object)(DBL_PTR(_sp_62821)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_62836), start, &_r_62836 );
            }
            else Tail(SEQ_PTR(_r_62836), stop+1, &_r_62836);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_62836), start, &_r_62836);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_62836 = Remove_elements(start, stop, (SEQ_PTR(_r_62836)->ref == 1));
        }
    }

    /** fwdref.e:120				active_references[file] = r*/
    RefDS(_r_62836);
    _2 = (object)SEQ_PTR(_44active_references_62767);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_references_62767 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_62813);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_62836;
    DeRef(_1);

    /** fwdref.e:122				r = active_subprogs[file]*/
    DeRefDS(_r_62836);
    _2 = (object)SEQ_PTR(_44active_subprogs_62766);
    _r_62836 = (object)*(((s1_ptr)_2)->base + _file_62813);
    Ref(_r_62836);

    /** fwdref.e:123				active_subprogs[file] = 0*/
    _2 = (object)SEQ_PTR(_44active_subprogs_62766);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_subprogs_62766 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_62813);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** fwdref.e:124				r = remove( r,   sp )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_62836);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_sp_62821)) ? _sp_62821 : (object)(DBL_PTR(_sp_62821)->dbl);
        int stop = (IS_ATOM_INT(_sp_62821)) ? _sp_62821 : (object)(DBL_PTR(_sp_62821)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_62836), start, &_r_62836 );
            }
            else Tail(SEQ_PTR(_r_62836), stop+1, &_r_62836);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_62836), start, &_r_62836);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_62836 = Remove_elements(start, stop, (SEQ_PTR(_r_62836)->ref == 1));
        }
    }

    /** fwdref.e:125				active_subprogs[file] = r*/
    RefDS(_r_62836);
    _2 = (object)SEQ_PTR(_44active_subprogs_62766);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_subprogs_62766 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_62813);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_62836;
    DeRef(_1);
L4: 
    DeRef(_r_62836);
    _r_62836 = NOVALUE;
    goto L5; // [250] 303
L3: 

    /** fwdref.e:127		elsif tx then*/
    if (_tx_62819 == 0)
    {
        goto L6; // [255] 296
    }
    else{
    }

    /** fwdref.e:128			sequence r = toplevel_references[file]*/
    DeRef(_r_62854);
    _2 = (object)SEQ_PTR(_44toplevel_references_62768);
    _r_62854 = (object)*(((s1_ptr)_2)->base + _file_62813);
    Ref(_r_62854);

    /** fwdref.e:129			toplevel_references[file] = 0*/
    _2 = (object)SEQ_PTR(_44toplevel_references_62768);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44toplevel_references_62768 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_62813);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** fwdref.e:130			r = remove( r, tx )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_62854);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_tx_62819)) ? _tx_62819 : (object)(DBL_PTR(_tx_62819)->dbl);
        int stop = (IS_ATOM_INT(_tx_62819)) ? _tx_62819 : (object)(DBL_PTR(_tx_62819)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_62854), start, &_r_62854 );
            }
            else Tail(SEQ_PTR(_r_62854), stop+1, &_r_62854);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_62854), start, &_r_62854);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_62854 = Remove_elements(start, stop, (SEQ_PTR(_r_62854)->ref == 1));
        }
    }

    /** fwdref.e:131			toplevel_references[file] = r*/
    RefDS(_r_62854);
    _2 = (object)SEQ_PTR(_44toplevel_references_62768);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44toplevel_references_62768 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_62813);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_62854;
    DeRef(_1);
    DeRefDS(_r_62854);
    _r_62854 = NOVALUE;
    goto L5; // [293] 303
L6: 

    /** fwdref.e:134			InternalErr( 260 )*/
    RefDS(_21993);
    _50InternalErr(260LL, _21993);
L5: 

    /** fwdref.e:136		inactive_references &= ref*/
    Append(&_44inactive_references_62769, _44inactive_references_62769, _ref_62812);

    /** fwdref.e:137		forward_references[ref] = 0*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62765 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _ref_62812);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** fwdref.e:138	end procedure*/
    _30851 = NOVALUE;
    return;
    ;
}


void _44set_code(object _ref_62868)
{
    object _30877 = NOVALUE;
    object _30875 = NOVALUE;
    object _30874 = NOVALUE;
    object _30873 = NOVALUE;
    object _30872 = NOVALUE;
    object _30870 = NOVALUE;
    object _30868 = NOVALUE;
    object _30866 = NOVALUE;
    object _30864 = NOVALUE;
    object _30861 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:146		patch_code_sub = forward_references[ref][FR_SUBPROG]*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    _30861 = (object)*(((s1_ptr)_2)->base + _ref_62868);
    _2 = (object)SEQ_PTR(_30861);
    _44patch_code_sub_62863 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_44patch_code_sub_62863)){
        _44patch_code_sub_62863 = (object)DBL_PTR(_44patch_code_sub_62863)->dbl;
    }
    _30861 = NOVALUE;

    /** fwdref.e:147		if patch_code_sub != CurrentSub then*/
    if (_44patch_code_sub_62863 == _36CurrentSub_21447)
    goto L1; // [23] 136

    /** fwdref.e:149			patch_code_temp = Code*/
    RefDS(_36Code_21531);
    DeRef(_44patch_code_temp_62860);
    _44patch_code_temp_62860 = _36Code_21531;

    /** fwdref.e:150			patch_linetab_temp = LineTable*/
    RefDS(_36LineTable_21532);
    DeRef(_44patch_linetab_temp_62861);
    _44patch_linetab_temp_62861 = _36LineTable_21532;

    /** fwdref.e:152			Code = SymTab[patch_code_sub][S_CODE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30864 = (object)*(((s1_ptr)_2)->base + _44patch_code_sub_62863);
    DeRefDS(_36Code_21531);
    _2 = (object)SEQ_PTR(_30864);
    if (!IS_ATOM_INT(_36S_CODE_21088)){
        _36Code_21531 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
    }
    else{
        _36Code_21531 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21088);
    }
    Ref(_36Code_21531);
    _30864 = NOVALUE;

    /** fwdref.e:153			SymTab[patch_code_sub][S_CODE] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_44patch_code_sub_62863 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21088))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21088);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30866 = NOVALUE;

    /** fwdref.e:154			LineTable = SymTab[patch_code_sub][S_LINETAB]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30868 = (object)*(((s1_ptr)_2)->base + _44patch_code_sub_62863);
    DeRefDS(_36LineTable_21532);
    _2 = (object)SEQ_PTR(_30868);
    if (!IS_ATOM_INT(_36S_LINETAB_21111)){
        _36LineTable_21532 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21111)->dbl));
    }
    else{
        _36LineTable_21532 = (object)*(((s1_ptr)_2)->base + _36S_LINETAB_21111);
    }
    Ref(_36LineTable_21532);
    _30868 = NOVALUE;

    /** fwdref.e:155			SymTab[patch_code_sub][S_LINETAB] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_44patch_code_sub_62863 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_LINETAB_21111))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21111)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21111);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30870 = NOVALUE;

    /** fwdref.e:157			patch_current_sub = CurrentSub*/
    _44patch_current_sub_62865 = _36CurrentSub_21447;

    /** fwdref.e:158			CurrentSub = patch_code_sub*/
    _36CurrentSub_21447 = _44patch_code_sub_62863;
    goto L2; // [133] 203
L1: 

    /** fwdref.e:160			patch_current_sub = patch_code_sub*/
    _44patch_current_sub_62865 = _44patch_code_sub_62863;

    /** fwdref.e:161			if sequence( SymTab[patch_current_sub][S_CODE] ) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30872 = (object)*(((s1_ptr)_2)->base + _44patch_current_sub_62865);
    _2 = (object)SEQ_PTR(_30872);
    if (!IS_ATOM_INT(_36S_CODE_21088)){
        _30873 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
    }
    else{
        _30873 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21088);
    }
    _30872 = NOVALUE;
    _30874 = IS_SEQUENCE(_30873);
    _30873 = NOVALUE;
    if (_30874 == 0)
    {
        _30874 = NOVALUE;
        goto L3; // [164] 202
    }
    else{
        _30874 = NOVALUE;
    }

    /** fwdref.e:162				SymTab[patch_code_sub][S_CODE] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_44patch_code_sub_62863 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21088))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21088);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30875 = NOVALUE;

    /** fwdref.e:163				SymTab[patch_code_sub][S_LINETAB] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_44patch_code_sub_62863 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_LINETAB_21111))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21111)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21111);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30877 = NOVALUE;
L3: 
L2: 

    /** fwdref.e:166	end procedure*/
    return;
    ;
}


void _44reset_code()
{
    object _30882 = NOVALUE;
    object _30880 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:169		if patch_code_sub != patch_current_sub then*/
    if (_44patch_code_sub_62863 == _44patch_current_sub_62865)
    goto L1; // [7] 77

    /** fwdref.e:171			SymTab[patch_code_sub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_44patch_code_sub_62863 + ((s1_ptr)_2)->base);
    RefDS(_36Code_21531);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21088))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21088);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36Code_21531;
    DeRef(_1);
    _30880 = NOVALUE;

    /** fwdref.e:172			SymTab[patch_code_sub][S_LINETAB] = LineTable*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_44patch_code_sub_62863 + ((s1_ptr)_2)->base);
    RefDS(_36LineTable_21532);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_LINETAB_21111))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21111)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21111);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36LineTable_21532;
    DeRef(_1);
    _30882 = NOVALUE;

    /** fwdref.e:175			CurrentSub = patch_current_sub*/
    _36CurrentSub_21447 = _44patch_current_sub_62865;

    /** fwdref.e:176			Code = patch_code_temp*/
    RefDS(_44patch_code_temp_62860);
    DeRefDS(_36Code_21531);
    _36Code_21531 = _44patch_code_temp_62860;

    /** fwdref.e:177			LineTable = patch_linetab_temp*/
    RefDS(_44patch_linetab_temp_62861);
    DeRefDS(_36LineTable_21532);
    _36LineTable_21532 = _44patch_linetab_temp_62861;
L1: 

    /** fwdref.e:181		patch_code_temp = {}*/
    RefDS(_21993);
    DeRef(_44patch_code_temp_62860);
    _44patch_code_temp_62860 = _21993;

    /** fwdref.e:182		patch_linetab_temp = {}*/
    RefDS(_21993);
    DeRef(_44patch_linetab_temp_62861);
    _44patch_linetab_temp_62861 = _21993;

    /** fwdref.e:183	end procedure*/
    return;
    ;
}


void _44set_data(object _ref_62930, object _data_62931)
{
    object _30884 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:186		forward_references[ref][FR_DATA] = data*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62765 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_62930 + ((s1_ptr)_2)->base);
    Ref(_data_62931);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _data_62931;
    DeRef(_1);
    _30884 = NOVALUE;

    /** fwdref.e:187	end procedure*/
    DeRef(_data_62931);
    return;
    ;
}


void _44add_data(object _ref_62936, object _data_62937)
{
    object _30890 = NOVALUE;
    object _30889 = NOVALUE;
    object _30888 = NOVALUE;
    object _30886 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_62936)) {
        _1 = (object)(DBL_PTR(_ref_62936)->dbl);
        DeRefDS(_ref_62936);
        _ref_62936 = _1;
    }

    /** fwdref.e:190		forward_references[ref][FR_DATA] = append( forward_references[ref][FR_DATA], data )*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62765 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_62936 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    _30888 = (object)*(((s1_ptr)_2)->base + _ref_62936);
    _2 = (object)SEQ_PTR(_30888);
    _30889 = (object)*(((s1_ptr)_2)->base + 12LL);
    _30888 = NOVALUE;
    Ref(_data_62937);
    Append(&_30890, _30889, _data_62937);
    _30889 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30890;
    if( _1 != _30890 ){
        DeRef(_1);
    }
    _30890 = NOVALUE;
    _30886 = NOVALUE;

    /** fwdref.e:191	end procedure*/
    DeRef(_data_62937);
    return;
    ;
}


void _44set_line(object _ref_62945, object _line_no_62946, object _this_line_62947, object _bp_62948)
{
    object _30895 = NOVALUE;
    object _30893 = NOVALUE;
    object _30891 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_62945)) {
        _1 = (object)(DBL_PTR(_ref_62945)->dbl);
        DeRefDS(_ref_62945);
        _ref_62945 = _1;
    }

    /** fwdref.e:194		forward_references[ref][FR_LINE] = line_no*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62765 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_62945 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _line_no_62946;
    DeRef(_1);
    _30891 = NOVALUE;

    /** fwdref.e:195		forward_references[ref][FR_THISLINE] = this_line*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62765 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_62945 + ((s1_ptr)_2)->base);
    RefDS(_this_line_62947);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 7LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _this_line_62947;
    DeRef(_1);
    _30893 = NOVALUE;

    /** fwdref.e:196		forward_references[ref][FR_BP] = bp*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62765 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_62945 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 8LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _bp_62948;
    DeRef(_1);
    _30895 = NOVALUE;

    /** fwdref.e:198	end procedure*/
    DeRefDS(_this_line_62947);
    return;
    ;
}


void _44add_private_symbol(object _sym_62960, object _name_62961)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_62960)) {
        _1 = (object)(DBL_PTR(_sym_62960)->dbl);
        DeRefDS(_sym_62960);
        _sym_62960 = _1;
    }

    /** fwdref.e:206		fwd_private_sym &= sym*/
    Append(&_44fwd_private_sym_62955, _44fwd_private_sym_62955, _sym_62960);

    /** fwdref.e:207		fwd_private_name = append( fwd_private_name, name )*/
    RefDS(_name_62961);
    Append(&_44fwd_private_name_62956, _44fwd_private_name_62956, _name_62961);

    /** fwdref.e:209	end procedure*/
    DeRefDS(_name_62961);
    return;
    ;
}


void _44patch_forward_goto(object _tok_62969, object _ref_62970)
{
    object _fr_62971 = NOVALUE;
    object _30911 = NOVALUE;
    object _30910 = NOVALUE;
    object _30909 = NOVALUE;
    object _30908 = NOVALUE;
    object _30907 = NOVALUE;
    object _30906 = NOVALUE;
    object _30905 = NOVALUE;
    object _30904 = NOVALUE;
    object _30902 = NOVALUE;
    object _30901 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:217		sequence fr = forward_references[ref]*/
    DeRef(_fr_62971);
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    _fr_62971 = (object)*(((s1_ptr)_2)->base + _ref_62970);
    Ref(_fr_62971);

    /** fwdref.e:218		set_code( ref )*/
    _44set_code(_ref_62970);

    /** fwdref.e:220		shifting_sub = fr[FR_SUBPROG]*/
    _2 = (object)SEQ_PTR(_fr_62971);
    _44shifting_sub_62784 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_44shifting_sub_62784))
    _44shifting_sub_62784 = (object)DBL_PTR(_44shifting_sub_62784)->dbl;

    /** fwdref.e:222		if length( fr[FR_DATA] ) = 2 then*/
    _2 = (object)SEQ_PTR(_fr_62971);
    _30901 = (object)*(((s1_ptr)_2)->base + 12LL);
    if (IS_SEQUENCE(_30901)){
            _30902 = SEQ_PTR(_30901)->length;
    }
    else {
        _30902 = 1;
    }
    _30901 = NOVALUE;
    if (_30902 != 2LL)
    goto L1; // [33] 64

    /** fwdref.e:223			prep_forward_error( ref )*/
    _44prep_forward_error(_ref_62970);

    /** fwdref.e:224			CompileErr( UNKNOWN_LABEL_1, { fr[FR_DATA][2] })*/
    _2 = (object)SEQ_PTR(_fr_62971);
    _30904 = (object)*(((s1_ptr)_2)->base + 12LL);
    _2 = (object)SEQ_PTR(_30904);
    _30905 = (object)*(((s1_ptr)_2)->base + 2LL);
    _30904 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_30905);
    ((intptr_t*)_2)[1] = _30905;
    _30906 = MAKE_SEQ(_1);
    _30905 = NOVALUE;
    _50CompileErr(156LL, _30906, 0LL);
    _30906 = NOVALUE;
L1: 

    /** fwdref.e:227		Goto_block(  fr[FR_DATA][1], fr[FR_DATA][3], fr[FR_PC] )*/
    _2 = (object)SEQ_PTR(_fr_62971);
    _30907 = (object)*(((s1_ptr)_2)->base + 12LL);
    _2 = (object)SEQ_PTR(_30907);
    _30908 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30907 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_62971);
    _30909 = (object)*(((s1_ptr)_2)->base + 12LL);
    _2 = (object)SEQ_PTR(_30909);
    _30910 = (object)*(((s1_ptr)_2)->base + 3LL);
    _30909 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_62971);
    _30911 = (object)*(((s1_ptr)_2)->base + 5LL);
    Ref(_30908);
    Ref(_30910);
    Ref(_30911);
    _65Goto_block(_30908, _30910, _30911);
    _30908 = NOVALUE;
    _30910 = NOVALUE;
    _30911 = NOVALUE;

    /** fwdref.e:229		shifting_sub = 0*/
    _44shifting_sub_62784 = 0LL;

    /** fwdref.e:231		reset_code()*/
    _44reset_code();

    /** fwdref.e:232		resolved_reference( ref )*/
    _44resolved_reference(_ref_62970);

    /** fwdref.e:233	end procedure*/
    DeRefDS(_fr_62971);
    _30901 = NOVALUE;
    return;
    ;
}


void _44patch_forward_call(object _tok_62993, object _ref_62994)
{
    object _fr_62995 = NOVALUE;
    object _sub_62998 = NOVALUE;
    object _defarg_63004 = NOVALUE;
    object _paramsym_63008 = NOVALUE;
    object _old_63011 = NOVALUE;
    object _tx_63015 = NOVALUE;
    object _code_sub_63025 = NOVALUE;
    object _args_63027 = NOVALUE;
    object _is_func_63032 = NOVALUE;
    object _real_file_63046 = NOVALUE;
    object _code_63050 = NOVALUE;
    object _temp_sub_63052 = NOVALUE;
    object _pc_63054 = NOVALUE;
    object _next_pc_63056 = NOVALUE;
    object _supplied_args_63057 = NOVALUE;
    object _name_63060 = NOVALUE;
    object _old_temps_allocated_63096 = NOVALUE;
    object _temp_target_63105 = NOVALUE;
    object _converted_code_63108 = NOVALUE;
    object _target_63124 = NOVALUE;
    object _has_defaults_63130 = NOVALUE;
    object _goto_target_63131 = NOVALUE;
    object _defarg_63134 = NOVALUE;
    object _code_len_63135 = NOVALUE;
    object _extra_default_args_63137 = NOVALUE;
    object _param_sym_63140 = NOVALUE;
    object _params_63141 = NOVALUE;
    object _orig_code_63143 = NOVALUE;
    object _orig_linetable_63144 = NOVALUE;
    object _ar_sp_63148 = NOVALUE;
    object _pre_refs_63152 = NOVALUE;
    object _old_fwd_params_63167 = NOVALUE;
    object _temp_shifting_sub_63208 = NOVALUE;
    object _new_code_63212 = NOVALUE;
    object _routine_type_63221 = NOVALUE;
    object _31670 = NOVALUE;
    object _31052 = NOVALUE;
    object _31051 = NOVALUE;
    object _31050 = NOVALUE;
    object _31048 = NOVALUE;
    object _31047 = NOVALUE;
    object _31046 = NOVALUE;
    object _31045 = NOVALUE;
    object _31044 = NOVALUE;
    object _31043 = NOVALUE;
    object _31042 = NOVALUE;
    object _31041 = NOVALUE;
    object _31040 = NOVALUE;
    object _31039 = NOVALUE;
    object _31038 = NOVALUE;
    object _31037 = NOVALUE;
    object _31036 = NOVALUE;
    object _31034 = NOVALUE;
    object _31033 = NOVALUE;
    object _31032 = NOVALUE;
    object _31031 = NOVALUE;
    object _31030 = NOVALUE;
    object _31029 = NOVALUE;
    object _31028 = NOVALUE;
    object _31027 = NOVALUE;
    object _31025 = NOVALUE;
    object _31022 = NOVALUE;
    object _31021 = NOVALUE;
    object _31020 = NOVALUE;
    object _31019 = NOVALUE;
    object _31015 = NOVALUE;
    object _31014 = NOVALUE;
    object _31013 = NOVALUE;
    object _31012 = NOVALUE;
    object _31011 = NOVALUE;
    object _31009 = NOVALUE;
    object _31008 = NOVALUE;
    object _31007 = NOVALUE;
    object _31006 = NOVALUE;
    object _31005 = NOVALUE;
    object _31004 = NOVALUE;
    object _31002 = NOVALUE;
    object _31001 = NOVALUE;
    object _30999 = NOVALUE;
    object _30998 = NOVALUE;
    object _30997 = NOVALUE;
    object _30996 = NOVALUE;
    object _30994 = NOVALUE;
    object _30992 = NOVALUE;
    object _30991 = NOVALUE;
    object _30990 = NOVALUE;
    object _30988 = NOVALUE;
    object _30987 = NOVALUE;
    object _30985 = NOVALUE;
    object _30983 = NOVALUE;
    object _30980 = NOVALUE;
    object _30976 = NOVALUE;
    object _30974 = NOVALUE;
    object _30973 = NOVALUE;
    object _30971 = NOVALUE;
    object _30970 = NOVALUE;
    object _30969 = NOVALUE;
    object _30968 = NOVALUE;
    object _30966 = NOVALUE;
    object _30965 = NOVALUE;
    object _30964 = NOVALUE;
    object _30963 = NOVALUE;
    object _30962 = NOVALUE;
    object _30960 = NOVALUE;
    object _30959 = NOVALUE;
    object _30958 = NOVALUE;
    object _30957 = NOVALUE;
    object _30956 = NOVALUE;
    object _30955 = NOVALUE;
    object _30954 = NOVALUE;
    object _30953 = NOVALUE;
    object _30952 = NOVALUE;
    object _30951 = NOVALUE;
    object _30950 = NOVALUE;
    object _30949 = NOVALUE;
    object _30948 = NOVALUE;
    object _30947 = NOVALUE;
    object _30945 = NOVALUE;
    object _30944 = NOVALUE;
    object _30943 = NOVALUE;
    object _30942 = NOVALUE;
    object _30941 = NOVALUE;
    object _30938 = NOVALUE;
    object _30934 = NOVALUE;
    object _30933 = NOVALUE;
    object _30932 = NOVALUE;
    object _30931 = NOVALUE;
    object _30930 = NOVALUE;
    object _30929 = NOVALUE;
    object _30927 = NOVALUE;
    object _30924 = NOVALUE;
    object _30922 = NOVALUE;
    object _30921 = NOVALUE;
    object _30919 = NOVALUE;
    object _30916 = NOVALUE;
    object _30915 = NOVALUE;
    object _30914 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:242		sequence fr = forward_references[ref]*/
    DeRef(_fr_62995);
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    _fr_62995 = (object)*(((s1_ptr)_2)->base + _ref_62994);
    Ref(_fr_62995);

    /** fwdref.e:243		symtab_index sub = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_62993);
    _sub_62998 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_sub_62998)){
        _sub_62998 = (object)DBL_PTR(_sub_62998)->dbl;
    }

    /** fwdref.e:245		if sequence( fr[FR_DATA] ) then*/
    _2 = (object)SEQ_PTR(_fr_62995);
    _30914 = (object)*(((s1_ptr)_2)->base + 12LL);
    _30915 = IS_SEQUENCE(_30914);
    _30914 = NOVALUE;
    if (_30915 == 0)
    {
        _30915 = NOVALUE;
        goto L1; // [32] 117
    }
    else{
        _30915 = NOVALUE;
    }

    /** fwdref.e:246			sequence defarg = fr[FR_DATA][1]*/
    _2 = (object)SEQ_PTR(_fr_62995);
    _30916 = (object)*(((s1_ptr)_2)->base + 12LL);
    DeRef(_defarg_63004);
    _2 = (object)SEQ_PTR(_30916);
    _defarg_63004 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_defarg_63004);
    _30916 = NOVALUE;

    /** fwdref.e:247			symtab_index paramsym = defarg[2]*/
    _2 = (object)SEQ_PTR(_defarg_63004);
    _paramsym_63008 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_paramsym_63008)){
        _paramsym_63008 = (object)DBL_PTR(_paramsym_63008)->dbl;
    }

    /** fwdref.e:248			token old = { RECORDED, defarg[3] }*/
    _2 = (object)SEQ_PTR(_defarg_63004);
    _30919 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_30919);
    DeRef(_old_63011);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 508LL;
    ((intptr_t *)_2)[2] = _30919;
    _old_63011 = MAKE_SEQ(_1);
    _30919 = NOVALUE;

    /** fwdref.e:249			integer tx = find( old, SymTab[paramsym][S_CODE] )*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30921 = (object)*(((s1_ptr)_2)->base + _paramsym_63008);
    _2 = (object)SEQ_PTR(_30921);
    if (!IS_ATOM_INT(_36S_CODE_21088)){
        _30922 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
    }
    else{
        _30922 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21088);
    }
    _30921 = NOVALUE;
    _tx_63015 = find_from(_old_63011, _30922, 1LL);
    _30922 = NOVALUE;

    /** fwdref.e:250			SymTab[paramsym][S_CODE][tx] = tok*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_paramsym_63008 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21088))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
    else
    _3 = (object)(_36S_CODE_21088 + ((s1_ptr)_2)->base);
    _30924 = NOVALUE;
    Ref(_tok_62993);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _tx_63015);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _tok_62993;
    DeRef(_1);
    _30924 = NOVALUE;

    /** fwdref.e:251			resolved_reference( ref )*/
    _44resolved_reference(_ref_62994);

    /** fwdref.e:252			return*/
    DeRefDS(_defarg_63004);
    DeRefDS(_old_63011);
    DeRef(_tok_62993);
    DeRefDS(_fr_62995);
    DeRef(_code_63050);
    DeRef(_name_63060);
    DeRef(_params_63141);
    DeRef(_orig_code_63143);
    DeRef(_orig_linetable_63144);
    DeRef(_old_fwd_params_63167);
    DeRef(_new_code_63212);
    return;
L1: 
    DeRef(_defarg_63004);
    _defarg_63004 = NOVALUE;
    DeRef(_old_63011);
    _old_63011 = NOVALUE;

    /** fwdref.e:255		integer code_sub = fr[FR_SUBPROG]*/
    _2 = (object)SEQ_PTR(_fr_62995);
    _code_sub_63025 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_code_sub_63025))
    _code_sub_63025 = (object)DBL_PTR(_code_sub_63025)->dbl;

    /** fwdref.e:257		integer args = SymTab[sub][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30927 = (object)*(((s1_ptr)_2)->base + _sub_62998);
    _2 = (object)SEQ_PTR(_30927);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
        _args_63027 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
    }
    else{
        _args_63027 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
    }
    if (!IS_ATOM_INT(_args_63027)){
        _args_63027 = (object)DBL_PTR(_args_63027)->dbl;
    }
    _30927 = NOVALUE;

    /** fwdref.e:258		integer is_func = (SymTab[sub][S_TOKEN] = FUNC) or (SymTab[sub][S_TOKEN] = TYPE)*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30929 = (object)*(((s1_ptr)_2)->base + _sub_62998);
    _2 = (object)SEQ_PTR(_30929);
    if (!IS_ATOM_INT(_36S_TOKEN_21081)){
        _30930 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    }
    else{
        _30930 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    }
    _30929 = NOVALUE;
    if (IS_ATOM_INT(_30930)) {
        _30931 = (_30930 == 501LL);
    }
    else {
        _30931 = binary_op(EQUALS, _30930, 501LL);
    }
    _30930 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30932 = (object)*(((s1_ptr)_2)->base + _sub_62998);
    _2 = (object)SEQ_PTR(_30932);
    if (!IS_ATOM_INT(_36S_TOKEN_21081)){
        _30933 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    }
    else{
        _30933 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    }
    _30932 = NOVALUE;
    if (IS_ATOM_INT(_30933)) {
        _30934 = (_30933 == 504LL);
    }
    else {
        _30934 = binary_op(EQUALS, _30933, 504LL);
    }
    _30933 = NOVALUE;
    if (IS_ATOM_INT(_30931) && IS_ATOM_INT(_30934)) {
        _is_func_63032 = (_30931 != 0 || _30934 != 0);
    }
    else {
        _is_func_63032 = binary_op(OR, _30931, _30934);
    }
    DeRef(_30931);
    _30931 = NOVALUE;
    DeRef(_30934);
    _30934 = NOVALUE;
    if (!IS_ATOM_INT(_is_func_63032)) {
        _1 = (object)(DBL_PTR(_is_func_63032)->dbl);
        DeRefDS(_is_func_63032);
        _is_func_63032 = _1;
    }

    /** fwdref.e:260		integer real_file = current_file_no*/
    _real_file_63046 = _36current_file_no_21439;

    /** fwdref.e:261		current_file_no = fr[FR_FILE]*/
    _2 = (object)SEQ_PTR(_fr_62995);
    _36current_file_no_21439 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_36current_file_no_21439)){
        _36current_file_no_21439 = (object)DBL_PTR(_36current_file_no_21439)->dbl;
    }

    /** fwdref.e:263		set_code( ref )*/
    _44set_code(_ref_62994);

    /** fwdref.e:264		sequence code = Code*/
    RefDS(_36Code_21531);
    DeRef(_code_63050);
    _code_63050 = _36Code_21531;

    /** fwdref.e:265		integer temp_sub = CurrentSub*/
    _temp_sub_63052 = _36CurrentSub_21447;

    /** fwdref.e:267		integer pc = fr[FR_PC]*/
    _2 = (object)SEQ_PTR(_fr_62995);
    _pc_63054 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (!IS_ATOM_INT(_pc_63054))
    _pc_63054 = (object)DBL_PTR(_pc_63054)->dbl;

    /** fwdref.e:268		integer next_pc = pc*/
    _next_pc_63056 = _pc_63054;

    /** fwdref.e:269		integer supplied_args = code[pc+2]*/
    _30938 = _pc_63054 + 2LL;
    _2 = (object)SEQ_PTR(_code_63050);
    _supplied_args_63057 = (object)*(((s1_ptr)_2)->base + _30938);
    if (!IS_ATOM_INT(_supplied_args_63057))
    _supplied_args_63057 = (object)DBL_PTR(_supplied_args_63057)->dbl;

    /** fwdref.e:270		sequence name = fr[FR_NAME]*/
    DeRef(_name_63060);
    _2 = (object)SEQ_PTR(_fr_62995);
    _name_63060 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_name_63060);

    /** fwdref.e:272		if Code[pc] != FUNC_FORWARD and Code[pc] != PROC_FORWARD then*/
    _2 = (object)SEQ_PTR(_36Code_21531);
    _30941 = (object)*(((s1_ptr)_2)->base + _pc_63054);
    if (IS_ATOM_INT(_30941)) {
        _30942 = (_30941 != 196LL);
    }
    else {
        _30942 = binary_op(NOTEQ, _30941, 196LL);
    }
    _30941 = NOVALUE;
    if (IS_ATOM_INT(_30942)) {
        if (_30942 == 0) {
            goto L2; // [268] 332
        }
    }
    else {
        if (DBL_PTR(_30942)->dbl == 0.0) {
            goto L2; // [268] 332
        }
    }
    _2 = (object)SEQ_PTR(_36Code_21531);
    _30944 = (object)*(((s1_ptr)_2)->base + _pc_63054);
    if (IS_ATOM_INT(_30944)) {
        _30945 = (_30944 != 195LL);
    }
    else {
        _30945 = binary_op(NOTEQ, _30944, 195LL);
    }
    _30944 = NOVALUE;
    if (_30945 == 0) {
        DeRef(_30945);
        _30945 = NOVALUE;
        goto L2; // [285] 332
    }
    else {
        if (!IS_ATOM_INT(_30945) && DBL_PTR(_30945)->dbl == 0.0){
            DeRef(_30945);
            _30945 = NOVALUE;
            goto L2; // [285] 332
        }
        DeRef(_30945);
        _30945 = NOVALUE;
    }
    DeRef(_30945);
    _30945 = NOVALUE;

    /** fwdref.e:273			prep_forward_error( ref )*/
    _44prep_forward_error(_ref_62994);

    /** fwdref.e:274			CompileErr( "The forward call to [4] wasn't where we thought it would be: [1]:[2]:[3]",*/
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _30947 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
    _2 = (object)SEQ_PTR(_fr_62995);
    _30948 = (object)*(((s1_ptr)_2)->base + 4LL);
    Ref(_30948);
    _30949 = _54sym_name(_30948);
    _30948 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_62995);
    _30950 = (object)*(((s1_ptr)_2)->base + 6LL);
    _2 = (object)SEQ_PTR(_fr_62995);
    _30951 = (object)*(((s1_ptr)_2)->base + 2LL);
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_30947);
    ((intptr_t*)_2)[1] = _30947;
    ((intptr_t*)_2)[2] = _30949;
    Ref(_30950);
    ((intptr_t*)_2)[3] = _30950;
    Ref(_30951);
    ((intptr_t*)_2)[4] = _30951;
    _30952 = MAKE_SEQ(_1);
    _30951 = NOVALUE;
    _30950 = NOVALUE;
    _30949 = NOVALUE;
    _30947 = NOVALUE;
    RefDS(_30946);
    _50CompileErr(_30946, _30952, 0LL);
    _30952 = NOVALUE;
L2: 

    /** fwdref.e:278		if SymTab[sub][S_DEPRECATED] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30953 = (object)*(((s1_ptr)_2)->base + _sub_62998);
    _2 = (object)SEQ_PTR(_30953);
    _30954 = (object)*(((s1_ptr)_2)->base + 30LL);
    _30953 = NOVALUE;
    if (_30954 == 0) {
        _30954 = NOVALUE;
        goto L3; // [346] 375
    }
    else {
        if (!IS_ATOM_INT(_30954) && DBL_PTR(_30954)->dbl == 0.0){
            _30954 = NOVALUE;
            goto L3; // [346] 375
        }
        _30954 = NOVALUE;
    }
    _30954 = NOVALUE;

    /** fwdref.e:279			Warning(327, deprecated_warning_flag, { SymTab[sub][S_NAME] })*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30955 = (object)*(((s1_ptr)_2)->base + _sub_62998);
    _2 = (object)SEQ_PTR(_30955);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _30956 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _30956 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _30955 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_30956);
    ((intptr_t*)_2)[1] = _30956;
    _30957 = MAKE_SEQ(_1);
    _30956 = NOVALUE;
    _50Warning(327LL, 16384LL, _30957);
    _30957 = NOVALUE;
L3: 

    /** fwdref.e:282		integer old_temps_allocated = temps_allocated*/
    _old_temps_allocated_63096 = _54temps_allocated_47307;

    /** fwdref.e:283		temps_allocated = 0*/
    _54temps_allocated_47307 = 0LL;

    /** fwdref.e:285		if is_func and fr[FR_OP] = PROC then*/
    if (_is_func_63032 == 0) {
        goto L4; // [393] 481
    }
    _2 = (object)SEQ_PTR(_fr_62995);
    _30959 = (object)*(((s1_ptr)_2)->base + 10LL);
    if (IS_ATOM_INT(_30959)) {
        _30960 = (_30959 == 27LL);
    }
    else {
        _30960 = binary_op(EQUALS, _30959, 27LL);
    }
    _30959 = NOVALUE;
    if (_30960 == 0) {
        DeRef(_30960);
        _30960 = NOVALUE;
        goto L4; // [408] 481
    }
    else {
        if (!IS_ATOM_INT(_30960) && DBL_PTR(_30960)->dbl == 0.0){
            DeRef(_30960);
            _30960 = NOVALUE;
            goto L4; // [408] 481
        }
        DeRef(_30960);
        _30960 = NOVALUE;
    }
    DeRef(_30960);
    _30960 = NOVALUE;

    /** fwdref.e:288			symtab_index temp_target = NewTempSym()*/
    _temp_target_63105 = _54NewTempSym(0LL);
    if (!IS_ATOM_INT(_temp_target_63105)) {
        _1 = (object)(DBL_PTR(_temp_target_63105)->dbl);
        DeRefDS(_temp_target_63105);
        _temp_target_63105 = _1;
    }

    /** fwdref.e:289			sequence converted_code = */
    _30962 = _pc_63054 + 1;
    if (_30962 > MAXINT){
        _30962 = NewDouble((eudouble)_30962);
    }
    _30963 = _pc_63054 + 2LL;
    if ((object)((uintptr_t)_30963 + (uintptr_t)HIGH_BITS) >= 0){
        _30963 = NewDouble((eudouble)_30963);
    }
    if (IS_ATOM_INT(_30963)) {
        _30964 = _30963 + _supplied_args_63057;
    }
    else {
        _30964 = NewDouble(DBL_PTR(_30963)->dbl + (eudouble)_supplied_args_63057);
    }
    DeRef(_30963);
    _30963 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30965;
    RHS_Slice(_36Code_21531, _30962, _30964);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 208LL;
    ((intptr_t *)_2)[2] = _temp_target_63105;
    _30966 = MAKE_SEQ(_1);
    {
        object concat_list[4];

        concat_list[0] = _30966;
        concat_list[1] = _temp_target_63105;
        concat_list[2] = _30965;
        concat_list[3] = 196LL;
        Concat_N((object_ptr)&_converted_code_63108, concat_list, 4);
    }
    DeRefDS(_30966);
    _30966 = NOVALUE;
    DeRefDS(_30965);
    _30965 = NOVALUE;

    /** fwdref.e:295			replace_code( converted_code, pc, pc + 2 + supplied_args, code_sub )*/
    _30968 = _pc_63054 + 2LL;
    if ((object)((uintptr_t)_30968 + (uintptr_t)HIGH_BITS) >= 0){
        _30968 = NewDouble((eudouble)_30968);
    }
    if (IS_ATOM_INT(_30968)) {
        _30969 = _30968 + _supplied_args_63057;
        if ((object)((uintptr_t)_30969 + (uintptr_t)HIGH_BITS) >= 0){
            _30969 = NewDouble((eudouble)_30969);
        }
    }
    else {
        _30969 = NewDouble(DBL_PTR(_30968)->dbl + (eudouble)_supplied_args_63057);
    }
    DeRef(_30968);
    _30968 = NOVALUE;
    RefDS(_converted_code_63108);
    _44replace_code(_converted_code_63108, _pc_63054, _30969, _code_sub_63025);
    _30969 = NOVALUE;

    /** fwdref.e:297			code = Code*/
    RefDS(_36Code_21531);
    DeRef(_code_63050);
    _code_63050 = _36Code_21531;
L4: 
    DeRef(_converted_code_63108);
    _converted_code_63108 = NOVALUE;

    /** fwdref.e:299		next_pc +=*/
    _30970 = 3LL + _supplied_args_63057;
    if ((object)((uintptr_t)_30970 + (uintptr_t)HIGH_BITS) >= 0){
        _30970 = NewDouble((eudouble)_30970);
    }
    if (IS_ATOM_INT(_30970)) {
        _30971 = _30970 + _is_func_63032;
        if ((object)((uintptr_t)_30971 + (uintptr_t)HIGH_BITS) >= 0){
            _30971 = NewDouble((eudouble)_30971);
        }
    }
    else {
        _30971 = NewDouble(DBL_PTR(_30970)->dbl + (eudouble)_is_func_63032);
    }
    DeRef(_30970);
    _30970 = NOVALUE;
    if (IS_ATOM_INT(_30971)) {
        _next_pc_63056 = _next_pc_63056 + _30971;
    }
    else {
        _next_pc_63056 = NewDouble((eudouble)_next_pc_63056 + DBL_PTR(_30971)->dbl);
    }
    DeRef(_30971);
    _30971 = NOVALUE;
    if (!IS_ATOM_INT(_next_pc_63056)) {
        _1 = (object)(DBL_PTR(_next_pc_63056)->dbl);
        DeRefDS(_next_pc_63056);
        _next_pc_63056 = _1;
    }

    /** fwdref.e:303		integer target*/

    /** fwdref.e:304		if is_func then*/
    if (_is_func_63032 == 0)
    {
        goto L5; // [503] 525
    }
    else{
    }

    /** fwdref.e:305			target = Code[pc + 3 + supplied_args]*/
    _30973 = _pc_63054 + 3LL;
    if ((object)((uintptr_t)_30973 + (uintptr_t)HIGH_BITS) >= 0){
        _30973 = NewDouble((eudouble)_30973);
    }
    if (IS_ATOM_INT(_30973)) {
        _30974 = _30973 + _supplied_args_63057;
    }
    else {
        _30974 = NewDouble(DBL_PTR(_30973)->dbl + (eudouble)_supplied_args_63057);
    }
    DeRef(_30973);
    _30973 = NOVALUE;
    _2 = (object)SEQ_PTR(_36Code_21531);
    if (!IS_ATOM_INT(_30974)){
        _target_63124 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30974)->dbl));
    }
    else{
        _target_63124 = (object)*(((s1_ptr)_2)->base + _30974);
    }
    if (!IS_ATOM_INT(_target_63124)){
        _target_63124 = (object)DBL_PTR(_target_63124)->dbl;
    }
L5: 

    /** fwdref.e:307		integer has_defaults = 0*/
    _has_defaults_63130 = 0LL;

    /** fwdref.e:308		integer goto_target = length( code ) + 1*/
    if (IS_SEQUENCE(_code_63050)){
            _30976 = SEQ_PTR(_code_63050)->length;
    }
    else {
        _30976 = 1;
    }
    _goto_target_63131 = _30976 + 1;
    _30976 = NOVALUE;

    /** fwdref.e:309		integer defarg = 0*/
    _defarg_63134 = 0LL;

    /** fwdref.e:310		integer code_len = length(code)*/
    if (IS_SEQUENCE(_code_63050)){
            _code_len_63135 = SEQ_PTR(_code_63050)->length;
    }
    else {
        _code_len_63135 = 1;
    }

    /** fwdref.e:312		integer extra_default_args = 0*/
    _extra_default_args_63137 = 0LL;

    /** fwdref.e:313		set_dont_read( 1 )*/
    _62set_dont_read(1LL);

    /** fwdref.e:314		reset_private_lists()*/

    /** fwdref.e:212		fwd_private_sym  = {}*/
    RefDS(_21993);
    DeRefi(_44fwd_private_sym_62955);
    _44fwd_private_sym_62955 = _21993;

    /** fwdref.e:213		fwd_private_name = {}*/
    RefDS(_21993);
    DeRef(_44fwd_private_name_62956);
    _44fwd_private_name_62956 = _21993;

    /** fwdref.e:214	end procedure*/
    goto L6; // [577] 580
L6: 

    /** fwdref.e:315		integer param_sym = sub*/
    _param_sym_63140 = _sub_62998;

    /** fwdref.e:316		sequence params = repeat( 0, args )*/
    DeRef(_params_63141);
    _params_63141 = Repeat(0LL, _args_63027);

    /** fwdref.e:317		sequence orig_code = code*/
    RefDS(_code_63050);
    DeRef(_orig_code_63143);
    _orig_code_63143 = _code_63050;

    /** fwdref.e:318		sequence orig_linetable = LineTable*/
    RefDS(_36LineTable_21532);
    DeRef(_orig_linetable_63144);
    _orig_linetable_63144 = _36LineTable_21532;

    /** fwdref.e:319		LineTable = {}*/
    RefDS(_21993);
    DeRefDS(_36LineTable_21532);
    _36LineTable_21532 = _21993;

    /** fwdref.e:320		Code = {}*/
    RefDS(_21993);
    DeRef(_36Code_21531);
    _36Code_21531 = _21993;

    /** fwdref.e:323		integer ar_sp = find( code_sub, active_subprogs[current_file_no] )*/
    _2 = (object)SEQ_PTR(_44active_subprogs_62766);
    _30980 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
    _ar_sp_63148 = find_from(_code_sub_63025, _30980, 1LL);
    _30980 = NOVALUE;

    /** fwdref.e:324		integer pre_refs*/

    /** fwdref.e:326		if code_sub = TopLevelSub then*/
    if (_code_sub_63025 != _36TopLevelSub_21446)
    goto L7; // [644] 664

    /** fwdref.e:327			pre_refs = length( toplevel_references[current_file_no] )*/
    _2 = (object)SEQ_PTR(_44toplevel_references_62768);
    _30983 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
    if (IS_SEQUENCE(_30983)){
            _pre_refs_63152 = SEQ_PTR(_30983)->length;
    }
    else {
        _pre_refs_63152 = 1;
    }
    _30983 = NOVALUE;
    goto L8; // [661] 697
L7: 

    /** fwdref.e:329			ar_sp = find( code_sub, active_subprogs[current_file_no] )*/
    _2 = (object)SEQ_PTR(_44active_subprogs_62766);
    _30985 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
    _ar_sp_63148 = find_from(_code_sub_63025, _30985, 1LL);
    _30985 = NOVALUE;

    /** fwdref.e:330			pre_refs = length( active_references[current_file_no][ar_sp] )*/
    _2 = (object)SEQ_PTR(_44active_references_62767);
    _30987 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
    _2 = (object)SEQ_PTR(_30987);
    _30988 = (object)*(((s1_ptr)_2)->base + _ar_sp_63148);
    _30987 = NOVALUE;
    if (IS_SEQUENCE(_30988)){
            _pre_refs_63152 = SEQ_PTR(_30988)->length;
    }
    else {
        _pre_refs_63152 = 1;
    }
    _30988 = NOVALUE;
L8: 

    /** fwdref.e:333		sequence old_fwd_params = {}*/
    RefDS(_21993);
    DeRef(_old_fwd_params_63167);
    _old_fwd_params_63167 = _21993;

    /** fwdref.e:334		for i = pc + 3 to pc + args + 2 do*/
    _30990 = _pc_63054 + 3LL;
    if ((object)((uintptr_t)_30990 + (uintptr_t)HIGH_BITS) >= 0){
        _30990 = NewDouble((eudouble)_30990);
    }
    _30991 = _pc_63054 + _args_63027;
    if ((object)((uintptr_t)_30991 + (uintptr_t)HIGH_BITS) >= 0){
        _30991 = NewDouble((eudouble)_30991);
    }
    if (IS_ATOM_INT(_30991)) {
        _30992 = _30991 + 2LL;
        if ((object)((uintptr_t)_30992 + (uintptr_t)HIGH_BITS) >= 0){
            _30992 = NewDouble((eudouble)_30992);
        }
    }
    else {
        _30992 = NewDouble(DBL_PTR(_30991)->dbl + (eudouble)2LL);
    }
    DeRef(_30991);
    _30991 = NOVALUE;
    {
        object _i_63169;
        Ref(_30990);
        _i_63169 = _30990;
L9: 
        if (binary_op_a(GREATER, _i_63169, _30992)){
            goto LA; // [718] 879
        }

        /** fwdref.e:335			defarg += 1*/
        _defarg_63134 = _defarg_63134 + 1;

        /** fwdref.e:336			param_sym = SymTab[param_sym][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _30994 = (object)*(((s1_ptr)_2)->base + _param_sym_63140);
        _2 = (object)SEQ_PTR(_30994);
        _param_sym_63140 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_param_sym_63140)){
            _param_sym_63140 = (object)DBL_PTR(_param_sym_63140)->dbl;
        }
        _30994 = NOVALUE;

        /** fwdref.e:337			if defarg > supplied_args or i > length( code ) or not code[i] then*/
        _30996 = (_defarg_63134 > _supplied_args_63057);
        if (_30996 != 0) {
            _30997 = 1;
            goto LB; // [753] 768
        }
        if (IS_SEQUENCE(_code_63050)){
                _30998 = SEQ_PTR(_code_63050)->length;
        }
        else {
            _30998 = 1;
        }
        if (IS_ATOM_INT(_i_63169)) {
            _30999 = (_i_63169 > _30998);
        }
        else {
            _30999 = (DBL_PTR(_i_63169)->dbl > (eudouble)_30998);
        }
        _30998 = NOVALUE;
        _30997 = (_30999 != 0);
LB: 
        if (_30997 != 0) {
            goto LC; // [768] 784
        }
        _2 = (object)SEQ_PTR(_code_63050);
        if (!IS_ATOM_INT(_i_63169)){
            _31001 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63169)->dbl));
        }
        else{
            _31001 = (object)*(((s1_ptr)_2)->base + _i_63169);
        }
        if (IS_ATOM_INT(_31001)) {
            _31002 = (_31001 == 0);
        }
        else {
            _31002 = unary_op(NOT, _31001);
        }
        _31001 = NOVALUE;
        if (_31002 == 0) {
            DeRef(_31002);
            _31002 = NOVALUE;
            goto LD; // [780] 834
        }
        else {
            if (!IS_ATOM_INT(_31002) && DBL_PTR(_31002)->dbl == 0.0){
                DeRef(_31002);
                _31002 = NOVALUE;
                goto LD; // [780] 834
            }
            DeRef(_31002);
            _31002 = NOVALUE;
        }
        DeRef(_31002);
        _31002 = NOVALUE;
LC: 

        /** fwdref.e:339				has_defaults = 1*/
        _has_defaults_63130 = 1LL;

        /** fwdref.e:340				extra_default_args += 1*/
        _extra_default_args_63137 = _extra_default_args_63137 + 1;

        /** fwdref.e:345				show_params( sub )*/
        _54show_params(_sub_62998);

        /** fwdref.e:346				set_error_info( ref )*/
        _44set_error_info(_ref_62994);

        /** fwdref.e:347				Parse_default_arg(sub, defarg, fwd_private_name, fwd_private_sym) --call_proc( parse_arg_rid, { sub, defarg, fwd_private_name, fwd_private_sym } )*/
        RefDS(_44fwd_private_name_62956);
        RefDS(_44fwd_private_sym_62955);
        _45Parse_default_arg(_sub_62998, _defarg_63134, _44fwd_private_name_62956, _44fwd_private_sym_62955);

        /** fwdref.e:348				hide_params( sub )*/
        _54hide_params(_sub_62998);

        /** fwdref.e:349				params[defarg] = Pop()*/
        _31004 = _47Pop();
        _2 = (object)SEQ_PTR(_params_63141);
        _2 = (object)(((s1_ptr)_2)->base + _defarg_63134);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31004;
        if( _1 != _31004 ){
            DeRef(_1);
        }
        _31004 = NOVALUE;
        goto LE; // [831] 872
LD: 

        /** fwdref.e:351				extra_default_args = 0*/
        _extra_default_args_63137 = 0LL;

        /** fwdref.e:352				add_private_symbol( code[i], SymTab[param_sym][S_NAME] )*/
        _2 = (object)SEQ_PTR(_code_63050);
        if (!IS_ATOM_INT(_i_63169)){
            _31005 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63169)->dbl));
        }
        else{
            _31005 = (object)*(((s1_ptr)_2)->base + _i_63169);
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _31006 = (object)*(((s1_ptr)_2)->base + _param_sym_63140);
        _2 = (object)SEQ_PTR(_31006);
        if (!IS_ATOM_INT(_36S_NAME_21076)){
            _31007 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
        }
        else{
            _31007 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
        }
        _31006 = NOVALUE;
        Ref(_31005);
        Ref(_31007);
        _44add_private_symbol(_31005, _31007);
        _31005 = NOVALUE;
        _31007 = NOVALUE;

        /** fwdref.e:353				params[defarg] = code[i]*/
        _2 = (object)SEQ_PTR(_code_63050);
        if (!IS_ATOM_INT(_i_63169)){
            _31008 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63169)->dbl));
        }
        else{
            _31008 = (object)*(((s1_ptr)_2)->base + _i_63169);
        }
        Ref(_31008);
        _2 = (object)SEQ_PTR(_params_63141);
        _2 = (object)(((s1_ptr)_2)->base + _defarg_63134);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31008;
        if( _1 != _31008 ){
            DeRef(_1);
        }
        _31008 = NOVALUE;
LE: 

        /** fwdref.e:355		end for*/
        _0 = _i_63169;
        if (IS_ATOM_INT(_i_63169)) {
            _i_63169 = _i_63169 + 1LL;
            if ((object)((uintptr_t)_i_63169 +(uintptr_t) HIGH_BITS) >= 0){
                _i_63169 = NewDouble((eudouble)_i_63169);
            }
        }
        else {
            _i_63169 = binary_op_a(PLUS, _i_63169, 1LL);
        }
        DeRef(_0);
        goto L9; // [874] 725
LA: 
        ;
        DeRef(_i_63169);
    }

    /** fwdref.e:357		SymTab[code_sub][S_STACK_SPACE] += temps_allocated*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_code_sub_63025 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21136)){
        _31011 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21136)->dbl));
    }
    else{
        _31011 = (object)*(((s1_ptr)_2)->base + _36S_STACK_SPACE_21136);
    }
    _31009 = NOVALUE;
    if (IS_ATOM_INT(_31011)) {
        _31012 = _31011 + _54temps_allocated_47307;
        if ((object)((uintptr_t)_31012 + (uintptr_t)HIGH_BITS) >= 0){
            _31012 = NewDouble((eudouble)_31012);
        }
    }
    else {
        _31012 = binary_op(PLUS, _31011, _54temps_allocated_47307);
    }
    _31011 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21136))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21136)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_STACK_SPACE_21136);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31012;
    if( _1 != _31012 ){
        DeRef(_1);
    }
    _31012 = NOVALUE;
    _31009 = NOVALUE;

    /** fwdref.e:358		temps_allocated = old_temps_allocated*/
    _54temps_allocated_47307 = _old_temps_allocated_63096;

    /** fwdref.e:363		integer temp_shifting_sub = shifting_sub*/
    _temp_shifting_sub_63208 = _44shifting_sub_62784;

    /** fwdref.e:364		shift( -pc, pc-1 )*/
    if ((uintptr_t)_pc_63054 == (uintptr_t)HIGH_BITS){
        _31013 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31013 = - _pc_63054;
    }
    _31014 = _pc_63054 - 1LL;
    if ((object)((uintptr_t)_31014 +(uintptr_t) HIGH_BITS) >= 0){
        _31014 = NewDouble((eudouble)_31014);
    }
    Ref(_31013);
    DeRef(_31670);
    _31670 = _31013;
    _66shift(_31013, _31014, _31670);
    _31013 = NOVALUE;
    _31014 = NOVALUE;
    _31670 = NOVALUE;

    /** fwdref.e:366		sequence new_code = Code*/
    RefDS(_36Code_21531);
    DeRef(_new_code_63212);
    _new_code_63212 = _36Code_21531;

    /** fwdref.e:367		Code = orig_code*/
    RefDS(_orig_code_63143);
    DeRefDS(_36Code_21531);
    _36Code_21531 = _orig_code_63143;

    /** fwdref.e:368		orig_code = {}*/
    RefDS(_21993);
    DeRefDS(_orig_code_63143);
    _orig_code_63143 = _21993;

    /** fwdref.e:369		LineTable = orig_linetable*/
    RefDS(_orig_linetable_63144);
    DeRef(_36LineTable_21532);
    _36LineTable_21532 = _orig_linetable_63144;

    /** fwdref.e:370		orig_linetable = {}*/
    RefDS(_21993);
    DeRefDS(_orig_linetable_63144);
    _orig_linetable_63144 = _21993;

    /** fwdref.e:371		set_dont_read( 0 )*/
    _62set_dont_read(0LL);

    /** fwdref.e:372		current_file_no = real_file*/
    _36current_file_no_21439 = _real_file_63046;

    /** fwdref.e:374		if args != ( supplied_args + extra_default_args ) then*/
    _31015 = _supplied_args_63057 + _extra_default_args_63137;
    if ((object)((uintptr_t)_31015 + (uintptr_t)HIGH_BITS) >= 0){
        _31015 = NewDouble((eudouble)_31015);
    }
    if (binary_op_a(EQUALS, _args_63027, _31015)){
        DeRef(_31015);
        _31015 = NOVALUE;
        goto LF; // [990] 1070
    }
    DeRef(_31015);
    _31015 = NOVALUE;

    /** fwdref.e:375			sequence routine_type*/

    /** fwdref.e:377			if is_func then */
    if (_is_func_63032 == 0)
    {
        goto L10; // [998] 1011
    }
    else{
    }

    /** fwdref.e:378				routine_type = "function"*/
    RefDS(_26192);
    DeRefi(_routine_type_63221);
    _routine_type_63221 = _26192;
    goto L11; // [1008] 1019
L10: 

    /** fwdref.e:380				routine_type = "procedure"*/
    RefDS(_26246);
    DeRefi(_routine_type_63221);
    _routine_type_63221 = _26246;
L11: 

    /** fwdref.e:382			current_file_no = fr[FR_FILE]*/
    _2 = (object)SEQ_PTR(_fr_62995);
    _36current_file_no_21439 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_36current_file_no_21439)){
        _36current_file_no_21439 = (object)DBL_PTR(_36current_file_no_21439)->dbl;
    }

    /** fwdref.e:383			line_number = fr[FR_LINE]*/
    _2 = (object)SEQ_PTR(_fr_62995);
    _36line_number_21440 = (object)*(((s1_ptr)_2)->base + 6LL);
    if (!IS_ATOM_INT(_36line_number_21440)){
        _36line_number_21440 = (object)DBL_PTR(_36line_number_21440)->dbl;
    }

    /** fwdref.e:384			CompileErr( WRONG_NUMBER_OF_ARGUMENTS_SUPPLIED_FOR_FORWARD_REFERENCET1_2_3_4__EXPECTED_5_BUT_FOUND_6,*/
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _31019 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
    _31020 = _supplied_args_63057 + _extra_default_args_63137;
    if ((object)((uintptr_t)_31020 + (uintptr_t)HIGH_BITS) >= 0){
        _31020 = NewDouble((eudouble)_31020);
    }
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_31019);
    ((intptr_t*)_2)[1] = _31019;
    ((intptr_t*)_2)[2] = _36line_number_21440;
    RefDS(_routine_type_63221);
    ((intptr_t*)_2)[3] = _routine_type_63221;
    RefDS(_name_63060);
    ((intptr_t*)_2)[4] = _name_63060;
    ((intptr_t*)_2)[5] = _args_63027;
    ((intptr_t*)_2)[6] = _31020;
    _31021 = MAKE_SEQ(_1);
    _31020 = NOVALUE;
    _31019 = NOVALUE;
    _50CompileErr(158LL, _31021, 0LL);
    _31021 = NOVALUE;
LF: 
    DeRefi(_routine_type_63221);
    _routine_type_63221 = NOVALUE;

    /** fwdref.e:388		new_code &= PROC & sub & params*/
    {
        object concat_list[3];

        concat_list[0] = _params_63141;
        concat_list[1] = _sub_62998;
        concat_list[2] = 27LL;
        Concat_N((object_ptr)&_31022, concat_list, 3);
    }
    Concat((object_ptr)&_new_code_63212, _new_code_63212, _31022);
    DeRefDS(_31022);
    _31022 = NOVALUE;

    /** fwdref.e:389		if is_func then*/
    if (_is_func_63032 == 0)
    {
        goto L12; // [1088] 1100
    }
    else{
    }

    /** fwdref.e:390			new_code &= target*/
    Append(&_new_code_63212, _new_code_63212, _target_63124);
L12: 

    /** fwdref.e:393		replace_code( new_code, pc, next_pc - 1, code_sub )*/
    _31025 = _next_pc_63056 - 1LL;
    if ((object)((uintptr_t)_31025 +(uintptr_t) HIGH_BITS) >= 0){
        _31025 = NewDouble((eudouble)_31025);
    }
    RefDS(_new_code_63212);
    _44replace_code(_new_code_63212, _pc_63054, _31025, _code_sub_63025);
    _31025 = NOVALUE;

    /** fwdref.e:395		if code_sub = TopLevelSub then*/
    if (_code_sub_63025 != _36TopLevelSub_21446)
    goto L13; // [1116] 1197

    /** fwdref.e:396			for i = pre_refs + 1 to length( toplevel_references[fr[FR_FILE]] ) do*/
    _31027 = _pre_refs_63152 + 1;
    if (_31027 > MAXINT){
        _31027 = NewDouble((eudouble)_31027);
    }
    _2 = (object)SEQ_PTR(_fr_62995);
    _31028 = (object)*(((s1_ptr)_2)->base + 3LL);
    _2 = (object)SEQ_PTR(_44toplevel_references_62768);
    if (!IS_ATOM_INT(_31028)){
        _31029 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31028)->dbl));
    }
    else{
        _31029 = (object)*(((s1_ptr)_2)->base + _31028);
    }
    if (IS_SEQUENCE(_31029)){
            _31030 = SEQ_PTR(_31029)->length;
    }
    else {
        _31030 = 1;
    }
    _31029 = NOVALUE;
    {
        object _i_63246;
        Ref(_31027);
        _i_63246 = _31027;
L14: 
        if (binary_op_a(GREATER, _i_63246, _31030)){
            goto L15; // [1141] 1194
        }

        /** fwdref.e:397				forward_references[toplevel_references[fr[FR_FILE]][i]][FR_PC] += pc - 1*/
        _2 = (object)SEQ_PTR(_fr_62995);
        _31031 = (object)*(((s1_ptr)_2)->base + 3LL);
        _2 = (object)SEQ_PTR(_44toplevel_references_62768);
        if (!IS_ATOM_INT(_31031)){
            _31032 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31031)->dbl));
        }
        else{
            _31032 = (object)*(((s1_ptr)_2)->base + _31031);
        }
        _2 = (object)SEQ_PTR(_31032);
        if (!IS_ATOM_INT(_i_63246)){
            _31033 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63246)->dbl));
        }
        else{
            _31033 = (object)*(((s1_ptr)_2)->base + _i_63246);
        }
        _31032 = NOVALUE;
        _2 = (object)SEQ_PTR(_44forward_references_62765);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _44forward_references_62765 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31033))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31033)->dbl));
        else
        _3 = (object)(_31033 + ((s1_ptr)_2)->base);
        _31036 = _pc_63054 - 1LL;
        if ((object)((uintptr_t)_31036 +(uintptr_t) HIGH_BITS) >= 0){
            _31036 = NewDouble((eudouble)_31036);
        }
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _31037 = (object)*(((s1_ptr)_2)->base + 5LL);
        _31034 = NOVALUE;
        if (IS_ATOM_INT(_31037) && IS_ATOM_INT(_31036)) {
            _31038 = _31037 + _31036;
            if ((object)((uintptr_t)_31038 + (uintptr_t)HIGH_BITS) >= 0){
                _31038 = NewDouble((eudouble)_31038);
            }
        }
        else {
            _31038 = binary_op(PLUS, _31037, _31036);
        }
        _31037 = NOVALUE;
        DeRef(_31036);
        _31036 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31038;
        if( _1 != _31038 ){
            DeRef(_1);
        }
        _31038 = NOVALUE;
        _31034 = NOVALUE;

        /** fwdref.e:398			end for*/
        _0 = _i_63246;
        if (IS_ATOM_INT(_i_63246)) {
            _i_63246 = _i_63246 + 1LL;
            if ((object)((uintptr_t)_i_63246 +(uintptr_t) HIGH_BITS) >= 0){
                _i_63246 = NewDouble((eudouble)_i_63246);
            }
        }
        else {
            _i_63246 = binary_op_a(PLUS, _i_63246, 1LL);
        }
        DeRef(_0);
        goto L14; // [1189] 1148
L15: 
        ;
        DeRef(_i_63246);
    }
    goto L16; // [1194] 1280
L13: 

    /** fwdref.e:400			for i = pre_refs + 1 to length( active_references[fr[FR_FILE]][ar_sp] ) do*/
    _31039 = _pre_refs_63152 + 1;
    if (_31039 > MAXINT){
        _31039 = NewDouble((eudouble)_31039);
    }
    _2 = (object)SEQ_PTR(_fr_62995);
    _31040 = (object)*(((s1_ptr)_2)->base + 3LL);
    _2 = (object)SEQ_PTR(_44active_references_62767);
    if (!IS_ATOM_INT(_31040)){
        _31041 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31040)->dbl));
    }
    else{
        _31041 = (object)*(((s1_ptr)_2)->base + _31040);
    }
    _2 = (object)SEQ_PTR(_31041);
    _31042 = (object)*(((s1_ptr)_2)->base + _ar_sp_63148);
    _31041 = NOVALUE;
    if (IS_SEQUENCE(_31042)){
            _31043 = SEQ_PTR(_31042)->length;
    }
    else {
        _31043 = 1;
    }
    _31042 = NOVALUE;
    {
        object _i_63261;
        Ref(_31039);
        _i_63261 = _31039;
L17: 
        if (binary_op_a(GREATER, _i_63261, _31043)){
            goto L18; // [1222] 1279
        }

        /** fwdref.e:401				forward_references[active_references[fr[FR_FILE]][ar_sp][i]][FR_PC] += pc - 1*/
        _2 = (object)SEQ_PTR(_fr_62995);
        _31044 = (object)*(((s1_ptr)_2)->base + 3LL);
        _2 = (object)SEQ_PTR(_44active_references_62767);
        if (!IS_ATOM_INT(_31044)){
            _31045 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31044)->dbl));
        }
        else{
            _31045 = (object)*(((s1_ptr)_2)->base + _31044);
        }
        _2 = (object)SEQ_PTR(_31045);
        _31046 = (object)*(((s1_ptr)_2)->base + _ar_sp_63148);
        _31045 = NOVALUE;
        _2 = (object)SEQ_PTR(_31046);
        if (!IS_ATOM_INT(_i_63261)){
            _31047 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63261)->dbl));
        }
        else{
            _31047 = (object)*(((s1_ptr)_2)->base + _i_63261);
        }
        _31046 = NOVALUE;
        _2 = (object)SEQ_PTR(_44forward_references_62765);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _44forward_references_62765 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31047))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31047)->dbl));
        else
        _3 = (object)(_31047 + ((s1_ptr)_2)->base);
        _31050 = _pc_63054 - 1LL;
        if ((object)((uintptr_t)_31050 +(uintptr_t) HIGH_BITS) >= 0){
            _31050 = NewDouble((eudouble)_31050);
        }
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _31051 = (object)*(((s1_ptr)_2)->base + 5LL);
        _31048 = NOVALUE;
        if (IS_ATOM_INT(_31051) && IS_ATOM_INT(_31050)) {
            _31052 = _31051 + _31050;
            if ((object)((uintptr_t)_31052 + (uintptr_t)HIGH_BITS) >= 0){
                _31052 = NewDouble((eudouble)_31052);
            }
        }
        else {
            _31052 = binary_op(PLUS, _31051, _31050);
        }
        _31051 = NOVALUE;
        DeRef(_31050);
        _31050 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31052;
        if( _1 != _31052 ){
            DeRef(_1);
        }
        _31052 = NOVALUE;
        _31048 = NOVALUE;

        /** fwdref.e:402			end for*/
        _0 = _i_63261;
        if (IS_ATOM_INT(_i_63261)) {
            _i_63261 = _i_63261 + 1LL;
            if ((object)((uintptr_t)_i_63261 +(uintptr_t) HIGH_BITS) >= 0){
                _i_63261 = NewDouble((eudouble)_i_63261);
            }
        }
        else {
            _i_63261 = binary_op_a(PLUS, _i_63261, 1LL);
        }
        DeRef(_0);
        goto L17; // [1274] 1229
L18: 
        ;
        DeRef(_i_63261);
    }
L16: 

    /** fwdref.e:405		reset_code()*/
    _44reset_code();

    /** fwdref.e:408		resolved_reference( ref )*/
    _44resolved_reference(_ref_62994);

    /** fwdref.e:409	end procedure*/
    DeRef(_tok_62993);
    DeRef(_fr_62995);
    DeRef(_code_63050);
    DeRef(_name_63060);
    DeRef(_params_63141);
    DeRef(_orig_code_63143);
    DeRef(_orig_linetable_63144);
    DeRef(_old_fwd_params_63167);
    DeRef(_new_code_63212);
    DeRef(_30938);
    _30938 = NOVALUE;
    DeRef(_30974);
    _30974 = NOVALUE;
    _31028 = NOVALUE;
    DeRef(_30992);
    _30992 = NOVALUE;
    _31029 = NOVALUE;
    DeRef(_30999);
    _30999 = NOVALUE;
    DeRef(_31027);
    _31027 = NOVALUE;
    DeRef(_30996);
    _30996 = NOVALUE;
    _31047 = NOVALUE;
    DeRef(_30990);
    _30990 = NOVALUE;
    _30988 = NOVALUE;
    DeRef(_30942);
    _30942 = NOVALUE;
    _31033 = NOVALUE;
    DeRef(_31039);
    _31039 = NOVALUE;
    _31031 = NOVALUE;
    _30983 = NOVALUE;
    _31040 = NOVALUE;
    DeRef(_30962);
    _30962 = NOVALUE;
    DeRef(_30964);
    _30964 = NOVALUE;
    _31044 = NOVALUE;
    _31042 = NOVALUE;
    return;
    ;
}


void _44set_error_info(object _ref_63278)
{
    object _fr_63279 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:412		sequence fr = forward_references[ref]*/
    DeRef(_fr_63279);
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    _fr_63279 = (object)*(((s1_ptr)_2)->base + _ref_63278);
    Ref(_fr_63279);

    /** fwdref.e:413		ThisLine        = fr[FR_THISLINE]*/
    DeRef(_50ThisLine_49234);
    _2 = (object)SEQ_PTR(_fr_63279);
    _50ThisLine_49234 = (object)*(((s1_ptr)_2)->base + 7LL);
    Ref(_50ThisLine_49234);

    /** fwdref.e:414		bp              = fr[FR_BP]*/
    _2 = (object)SEQ_PTR(_fr_63279);
    _50bp_49238 = (object)*(((s1_ptr)_2)->base + 8LL);
    if (!IS_ATOM_INT(_50bp_49238)){
        _50bp_49238 = (object)DBL_PTR(_50bp_49238)->dbl;
    }

    /** fwdref.e:415		line_number     = fr[FR_LINE]*/
    _2 = (object)SEQ_PTR(_fr_63279);
    _36line_number_21440 = (object)*(((s1_ptr)_2)->base + 6LL);
    if (!IS_ATOM_INT(_36line_number_21440)){
        _36line_number_21440 = (object)DBL_PTR(_36line_number_21440)->dbl;
    }

    /** fwdref.e:416		current_file_no = fr[FR_FILE]*/
    _2 = (object)SEQ_PTR(_fr_63279);
    _36current_file_no_21439 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_36current_file_no_21439)){
        _36current_file_no_21439 = (object)DBL_PTR(_36current_file_no_21439)->dbl;
    }

    /** fwdref.e:417	end procedure*/
    DeRefDS(_fr_63279);
    return;
    ;
}


void _44patch_forward_variable(object _tok_63292, object _ref_63293)
{
    object _fr_63294 = NOVALUE;
    object _sym_63297 = NOVALUE;
    object _pc_63350 = NOVALUE;
    object _vx_63354 = NOVALUE;
    object _d_63371 = NOVALUE;
    object _param_63381 = NOVALUE;
    object _old_63384 = NOVALUE;
    object _new_63389 = NOVALUE;
    object _31109 = NOVALUE;
    object _31108 = NOVALUE;
    object _31107 = NOVALUE;
    object _31105 = NOVALUE;
    object _31102 = NOVALUE;
    object _31100 = NOVALUE;
    object _31099 = NOVALUE;
    object _31098 = NOVALUE;
    object _31097 = NOVALUE;
    object _31095 = NOVALUE;
    object _31094 = NOVALUE;
    object _31093 = NOVALUE;
    object _31092 = NOVALUE;
    object _31091 = NOVALUE;
    object _31089 = NOVALUE;
    object _31087 = NOVALUE;
    object _31084 = NOVALUE;
    object _31083 = NOVALUE;
    object _31082 = NOVALUE;
    object _31080 = NOVALUE;
    object _31079 = NOVALUE;
    object _31078 = NOVALUE;
    object _31077 = NOVALUE;
    object _31075 = NOVALUE;
    object _31073 = NOVALUE;
    object _31072 = NOVALUE;
    object _31071 = NOVALUE;
    object _31070 = NOVALUE;
    object _31069 = NOVALUE;
    object _31068 = NOVALUE;
    object _31067 = NOVALUE;
    object _31066 = NOVALUE;
    object _31065 = NOVALUE;
    object _31064 = NOVALUE;
    object _31063 = NOVALUE;
    object _31062 = NOVALUE;
    object _31061 = NOVALUE;
    object _31060 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:421		sequence fr = forward_references[ref]*/
    DeRef(_fr_63294);
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    _fr_63294 = (object)*(((s1_ptr)_2)->base + _ref_63293);
    Ref(_fr_63294);

    /** fwdref.e:422		symtab_index sym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63292);
    _sym_63297 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_sym_63297)){
        _sym_63297 = (object)DBL_PTR(_sym_63297)->dbl;
    }

    /** fwdref.e:424		if SymTab[sym][S_FILE_NO] = fr[FR_FILE] */
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31060 = (object)*(((s1_ptr)_2)->base + _sym_63297);
    _2 = (object)SEQ_PTR(_31060);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _31061 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _31061 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    _31060 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_63294);
    _31062 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (IS_ATOM_INT(_31061) && IS_ATOM_INT(_31062)) {
        _31063 = (_31061 == _31062);
    }
    else {
        _31063 = binary_op(EQUALS, _31061, _31062);
    }
    _31061 = NOVALUE;
    _31062 = NOVALUE;
    if (IS_ATOM_INT(_31063)) {
        if (_31063 == 0) {
            goto L1; // [45] 69
        }
    }
    else {
        if (DBL_PTR(_31063)->dbl == 0.0) {
            goto L1; // [45] 69
        }
    }
    _2 = (object)SEQ_PTR(_fr_63294);
    _31065 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_31065)) {
        _31066 = (_31065 == _36TopLevelSub_21446);
    }
    else {
        _31066 = binary_op(EQUALS, _31065, _36TopLevelSub_21446);
    }
    _31065 = NOVALUE;
    if (_31066 == 0) {
        DeRef(_31066);
        _31066 = NOVALUE;
        goto L1; // [60] 69
    }
    else {
        if (!IS_ATOM_INT(_31066) && DBL_PTR(_31066)->dbl == 0.0){
            DeRef(_31066);
            _31066 = NOVALUE;
            goto L1; // [60] 69
        }
        DeRef(_31066);
        _31066 = NOVALUE;
    }
    DeRef(_31066);
    _31066 = NOVALUE;

    /** fwdref.e:426			return*/
    DeRef(_tok_63292);
    DeRef(_fr_63294);
    DeRef(_31063);
    _31063 = NOVALUE;
    return;
L1: 

    /** fwdref.e:429		if fr[FR_OP] = ASSIGN and SymTab[sym][S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_fr_63294);
    _31067 = (object)*(((s1_ptr)_2)->base + 10LL);
    if (IS_ATOM_INT(_31067)) {
        _31068 = (_31067 == 18LL);
    }
    else {
        _31068 = binary_op(EQUALS, _31067, 18LL);
    }
    _31067 = NOVALUE;
    if (IS_ATOM_INT(_31068)) {
        if (_31068 == 0) {
            goto L2; // [81] 122
        }
    }
    else {
        if (DBL_PTR(_31068)->dbl == 0.0) {
            goto L2; // [81] 122
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31070 = (object)*(((s1_ptr)_2)->base + _sym_63297);
    _2 = (object)SEQ_PTR(_31070);
    _31071 = (object)*(((s1_ptr)_2)->base + 3LL);
    _31070 = NOVALUE;
    if (IS_ATOM_INT(_31071)) {
        _31072 = (_31071 == 2LL);
    }
    else {
        _31072 = binary_op(EQUALS, _31071, 2LL);
    }
    _31071 = NOVALUE;
    if (_31072 == 0) {
        DeRef(_31072);
        _31072 = NOVALUE;
        goto L2; // [104] 122
    }
    else {
        if (!IS_ATOM_INT(_31072) && DBL_PTR(_31072)->dbl == 0.0){
            DeRef(_31072);
            _31072 = NOVALUE;
            goto L2; // [104] 122
        }
        DeRef(_31072);
        _31072 = NOVALUE;
    }
    DeRef(_31072);
    _31072 = NOVALUE;

    /** fwdref.e:430			prep_forward_error( ref )*/
    _44prep_forward_error(_ref_63293);

    /** fwdref.e:431			CompileErr( MAY_NOT_CHANGE_THE_VALUE_OF_A_CONSTANT)*/
    RefDS(_21993);
    _50CompileErr(110LL, _21993, 0LL);
L2: 

    /** fwdref.e:434		if fr[FR_OP] = ASSIGN then*/
    _2 = (object)SEQ_PTR(_fr_63294);
    _31073 = (object)*(((s1_ptr)_2)->base + 10LL);
    if (binary_op_a(NOTEQ, _31073, 18LL)){
        _31073 = NOVALUE;
        goto L3; // [130] 170
    }
    _31073 = NOVALUE;

    /** fwdref.e:435			SymTab[sym][S_USAGE] = or_bits( U_WRITTEN, SymTab[sym][S_USAGE] )*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_63297 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31077 = (object)*(((s1_ptr)_2)->base + _sym_63297);
    _2 = (object)SEQ_PTR(_31077);
    _31078 = (object)*(((s1_ptr)_2)->base + 5LL);
    _31077 = NOVALUE;
    if (IS_ATOM_INT(_31078)) {
        {uintptr_t tu;
             tu = (uintptr_t)2LL | (uintptr_t)_31078;
             _31079 = MAKE_UINT(tu);
        }
    }
    else {
        _31079 = binary_op(OR_BITS, 2LL, _31078);
    }
    _31078 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31079;
    if( _1 != _31079 ){
        DeRef(_1);
    }
    _31079 = NOVALUE;
    _31075 = NOVALUE;
    goto L4; // [167] 204
L3: 

    /** fwdref.e:437			SymTab[sym][S_USAGE] = or_bits( U_READ, SymTab[sym][S_USAGE] )*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_63297 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31082 = (object)*(((s1_ptr)_2)->base + _sym_63297);
    _2 = (object)SEQ_PTR(_31082);
    _31083 = (object)*(((s1_ptr)_2)->base + 5LL);
    _31082 = NOVALUE;
    if (IS_ATOM_INT(_31083)) {
        {uintptr_t tu;
             tu = (uintptr_t)1LL | (uintptr_t)_31083;
             _31084 = MAKE_UINT(tu);
        }
    }
    else {
        _31084 = binary_op(OR_BITS, 1LL, _31083);
    }
    _31083 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31084;
    if( _1 != _31084 ){
        DeRef(_1);
    }
    _31084 = NOVALUE;
    _31080 = NOVALUE;
L4: 

    /** fwdref.e:440		set_code( ref )*/
    _44set_code(_ref_63293);

    /** fwdref.e:441		integer pc = fr[FR_PC]*/
    _2 = (object)SEQ_PTR(_fr_63294);
    _pc_63350 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (!IS_ATOM_INT(_pc_63350))
    _pc_63350 = (object)DBL_PTR(_pc_63350)->dbl;

    /** fwdref.e:442		if pc < 1 then*/
    if (_pc_63350 >= 1LL)
    goto L5; // [217] 227

    /** fwdref.e:443			pc = 1*/
    _pc_63350 = 1LL;
L5: 

    /** fwdref.e:445		integer vx = find( -ref, Code, pc )*/
    if ((uintptr_t)_ref_63293 == (uintptr_t)HIGH_BITS){
        _31087 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31087 = - _ref_63293;
    }
    _vx_63354 = find_from(_31087, _36Code_21531, _pc_63350);
    DeRef(_31087);
    _31087 = NOVALUE;

    /** fwdref.e:446		if vx then*/
    if (_vx_63354 == 0)
    {
        goto L6; // [241] 283
    }
    else{
    }

    /** fwdref.e:447			while vx do*/
L7: 
    if (_vx_63354 == 0)
    {
        goto L8; // [249] 277
    }
    else{
    }

    /** fwdref.e:450				Code[vx] = sym*/
    _2 = (object)SEQ_PTR(_36Code_21531);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21531 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _vx_63354);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_63297;
    DeRef(_1);

    /** fwdref.e:451				vx = find( -ref, Code, vx )*/
    if ((uintptr_t)_ref_63293 == (uintptr_t)HIGH_BITS){
        _31089 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31089 = - _ref_63293;
    }
    _vx_63354 = find_from(_31089, _36Code_21531, _vx_63354);
    DeRef(_31089);
    _31089 = NOVALUE;

    /** fwdref.e:452			end while*/
    goto L7; // [274] 249
L8: 

    /** fwdref.e:453			resolved_reference( ref )*/
    _44resolved_reference(_ref_63293);
L6: 

    /** fwdref.e:456		if sequence( fr[FR_DATA] ) then*/
    _2 = (object)SEQ_PTR(_fr_63294);
    _31091 = (object)*(((s1_ptr)_2)->base + 12LL);
    _31092 = IS_SEQUENCE(_31091);
    _31091 = NOVALUE;
    if (_31092 == 0)
    {
        _31092 = NOVALUE;
        goto L9; // [292] 424
    }
    else{
        _31092 = NOVALUE;
    }

    /** fwdref.e:457			for i = 1 to length( fr[FR_DATA] ) do*/
    _2 = (object)SEQ_PTR(_fr_63294);
    _31093 = (object)*(((s1_ptr)_2)->base + 12LL);
    if (IS_SEQUENCE(_31093)){
            _31094 = SEQ_PTR(_31093)->length;
    }
    else {
        _31094 = 1;
    }
    _31093 = NOVALUE;
    {
        object _i_63368;
        _i_63368 = 1LL;
LA: 
        if (_i_63368 > _31094){
            goto LB; // [304] 418
        }

        /** fwdref.e:458				object d = fr[FR_DATA][i]*/
        _2 = (object)SEQ_PTR(_fr_63294);
        _31095 = (object)*(((s1_ptr)_2)->base + 12LL);
        DeRef(_d_63371);
        _2 = (object)SEQ_PTR(_31095);
        _d_63371 = (object)*(((s1_ptr)_2)->base + _i_63368);
        Ref(_d_63371);
        _31095 = NOVALUE;

        /** fwdref.e:459				if sequence( d ) and d[1] = PAM_RECORD then*/
        _31097 = IS_SEQUENCE(_d_63371);
        if (_31097 == 0) {
            goto LC; // [326] 407
        }
        _2 = (object)SEQ_PTR(_d_63371);
        _31099 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_31099)) {
            _31100 = (_31099 == 1LL);
        }
        else {
            _31100 = binary_op(EQUALS, _31099, 1LL);
        }
        _31099 = NOVALUE;
        if (_31100 == 0) {
            DeRef(_31100);
            _31100 = NOVALUE;
            goto LC; // [341] 407
        }
        else {
            if (!IS_ATOM_INT(_31100) && DBL_PTR(_31100)->dbl == 0.0){
                DeRef(_31100);
                _31100 = NOVALUE;
                goto LC; // [341] 407
            }
            DeRef(_31100);
            _31100 = NOVALUE;
        }
        DeRef(_31100);
        _31100 = NOVALUE;

        /** fwdref.e:461					symtab_index param = d[2]*/
        _2 = (object)SEQ_PTR(_d_63371);
        _param_63381 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_param_63381)){
            _param_63381 = (object)DBL_PTR(_param_63381)->dbl;
        }

        /** fwdref.e:462					token old = {RECORDED, d[3]}*/
        _2 = (object)SEQ_PTR(_d_63371);
        _31102 = (object)*(((s1_ptr)_2)->base + 3LL);
        Ref(_31102);
        DeRef(_old_63384);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 508LL;
        ((intptr_t *)_2)[2] = _31102;
        _old_63384 = MAKE_SEQ(_1);
        _31102 = NOVALUE;

        /** fwdref.e:463					token new = {VARIABLE, sym}*/
        DeRefi(_new_63389);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -100LL;
        ((intptr_t *)_2)[2] = _sym_63297;
        _new_63389 = MAKE_SEQ(_1);

        /** fwdref.e:464					SymTab[param][S_CODE] = find_replace( old, SymTab[param][S_CODE], new )*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_param_63381 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _31107 = (object)*(((s1_ptr)_2)->base + _param_63381);
        _2 = (object)SEQ_PTR(_31107);
        if (!IS_ATOM_INT(_36S_CODE_21088)){
            _31108 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
        }
        else{
            _31108 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21088);
        }
        _31107 = NOVALUE;
        RefDS(_old_63384);
        Ref(_31108);
        RefDS(_new_63389);
        _31109 = _16find_replace(_old_63384, _31108, _new_63389, 0LL);
        _31108 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_36S_CODE_21088))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21088);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31109;
        if( _1 != _31109 ){
            DeRef(_1);
        }
        _31109 = NOVALUE;
        _31105 = NOVALUE;
LC: 
        DeRef(_old_63384);
        _old_63384 = NOVALUE;
        DeRefi(_new_63389);
        _new_63389 = NOVALUE;
        DeRef(_d_63371);
        _d_63371 = NOVALUE;

        /** fwdref.e:466			end for*/
        _i_63368 = _i_63368 + 1LL;
        goto LA; // [413] 311
LB: 
        ;
    }

    /** fwdref.e:467			resolved_reference( ref )*/
    _44resolved_reference(_ref_63293);
L9: 

    /** fwdref.e:469		reset_code()*/
    _44reset_code();

    /** fwdref.e:470	end procedure*/
    DeRef(_tok_63292);
    DeRef(_fr_63294);
    DeRef(_31068);
    _31068 = NOVALUE;
    _31093 = NOVALUE;
    DeRef(_31063);
    _31063 = NOVALUE;
    return;
    ;
}


void _44patch_forward_init_check(object _tok_63405, object _ref_63406)
{
    object _fr_63407 = NOVALUE;
    object _31117 = NOVALUE;
    object _31116 = NOVALUE;
    object _31115 = NOVALUE;
    object _31113 = NOVALUE;
    object _31112 = NOVALUE;
    object _31111 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:474		sequence fr = forward_references[ref]*/
    DeRef(_fr_63407);
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    _fr_63407 = (object)*(((s1_ptr)_2)->base + _ref_63406);
    Ref(_fr_63407);

    /** fwdref.e:475		set_code( ref )*/
    _44set_code(_ref_63406);

    /** fwdref.e:476		if sequence( fr[FR_DATA] ) then*/
    _2 = (object)SEQ_PTR(_fr_63407);
    _31111 = (object)*(((s1_ptr)_2)->base + 12LL);
    _31112 = IS_SEQUENCE(_31111);
    _31111 = NOVALUE;
    if (_31112 == 0)
    {
        _31112 = NOVALUE;
        goto L1; // [27] 38
    }
    else{
        _31112 = NOVALUE;
    }

    /** fwdref.e:478			resolved_reference( ref )*/
    _44resolved_reference(_ref_63406);
    goto L2; // [35] 85
L1: 

    /** fwdref.e:479		elsif fr[FR_PC] > 0 then*/
    _2 = (object)SEQ_PTR(_fr_63407);
    _31113 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (binary_op_a(LESSEQ, _31113, 0LL)){
        _31113 = NOVALUE;
        goto L3; // [44] 78
    }
    _31113 = NOVALUE;

    /** fwdref.e:480			Code[fr[FR_PC]+1] = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_fr_63407);
    _31115 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (IS_ATOM_INT(_31115)) {
        _31116 = _31115 + 1;
        if (_31116 > MAXINT){
            _31116 = NewDouble((eudouble)_31116);
        }
    }
    else
    _31116 = binary_op(PLUS, 1, _31115);
    _31115 = NOVALUE;
    _2 = (object)SEQ_PTR(_tok_63405);
    _31117 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_31117);
    _2 = (object)SEQ_PTR(_36Code_21531);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21531 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_31116))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31116)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _31116);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31117;
    if( _1 != _31117 ){
        DeRef(_1);
    }
    _31117 = NOVALUE;

    /** fwdref.e:481			resolved_reference( ref )*/
    _44resolved_reference(_ref_63406);
    goto L2; // [75] 85
L3: 

    /** fwdref.e:483			forward_error( tok, ref )*/
    Ref(_tok_63405);
    _44forward_error(_tok_63405, _ref_63406);
L2: 

    /** fwdref.e:485		reset_code()*/
    _44reset_code();

    /** fwdref.e:486	end procedure*/
    DeRef(_tok_63405);
    DeRef(_fr_63407);
    DeRef(_31116);
    _31116 = NOVALUE;
    return;
    ;
}


object _44expected_name(object _id_63424)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_63424)) {
        _1 = (object)(DBL_PTR(_id_63424)->dbl);
        DeRefDS(_id_63424);
        _id_63424 = _1;
    }

    /** fwdref.e:491		switch id with fallthru do*/
    _0 = _id_63424;
    switch ( _0 ){ 

        /** fwdref.e:492			case PROC then*/
        case 27:
        case 195:

        /** fwdref.e:494				return "a procedure"*/
        RefDS(_26244);
        return _26244;

        /** fwdref.e:496			case FUNC then*/
        case 501:
        case 196:

        /** fwdref.e:498				return "a function"*/
        RefDS(_26190);
        return _26190;

        /** fwdref.e:500			case VARIABLE then*/
        case -100:

        /** fwdref.e:501				return "a variable, constant or enum"*/
        RefDS(_31120);
        return _31120;

        /** fwdref.e:502			case else*/
        default:

        /** fwdref.e:503				return "something"*/
        RefDS(_31121);
        return _31121;
    ;}    ;
}


void _44patch_forward_type(object _tok_63441, object _ref_63442)
{
    object _fr_63443 = NOVALUE;
    object _syms_63445 = NOVALUE;
    object _31133 = NOVALUE;
    object _31132 = NOVALUE;
    object _31130 = NOVALUE;
    object _31129 = NOVALUE;
    object _31128 = NOVALUE;
    object _31126 = NOVALUE;
    object _31125 = NOVALUE;
    object _31124 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:510		sequence fr = forward_references[ref]*/
    DeRef(_fr_63443);
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    _fr_63443 = (object)*(((s1_ptr)_2)->base + _ref_63442);
    Ref(_fr_63443);

    /** fwdref.e:511		sequence syms = fr[FR_DATA]*/
    DeRef(_syms_63445);
    _2 = (object)SEQ_PTR(_fr_63443);
    _syms_63445 = (object)*(((s1_ptr)_2)->base + 12LL);
    Ref(_syms_63445);

    /** fwdref.e:512		for i = 2 to length( syms ) do*/
    if (IS_SEQUENCE(_syms_63445)){
            _31124 = SEQ_PTR(_syms_63445)->length;
    }
    else {
        _31124 = 1;
    }
    {
        object _i_63448;
        _i_63448 = 2LL;
L1: 
        if (_i_63448 > _31124){
            goto L2; // [26] 102
        }

        /** fwdref.e:513			SymTab[syms[i]][S_VTYPE] = tok[T_SYM]*/
        _2 = (object)SEQ_PTR(_syms_63445);
        _31125 = (object)*(((s1_ptr)_2)->base + _i_63448);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31125))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31125)->dbl));
        else
        _3 = (object)(_31125 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_tok_63441);
        _31128 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_31128);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 15LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31128;
        if( _1 != _31128 ){
            DeRef(_1);
        }
        _31128 = NOVALUE;
        _31126 = NOVALUE;

        /** fwdref.e:514			if TRANSLATE then*/
        if (_36TRANSLATE_21041 == 0)
        {
            goto L3; // [62] 95
        }
        else{
        }

        /** fwdref.e:515				SymTab[syms[i]][S_GTYPE] = CompileType(tok[T_SYM])*/
        _2 = (object)SEQ_PTR(_syms_63445);
        _31129 = (object)*(((s1_ptr)_2)->base + _i_63448);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31129))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31129)->dbl));
        else
        _3 = (object)(_31129 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_tok_63441);
        _31132 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_31132);
        _31133 = _45CompileType(_31132);
        _31132 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 36LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31133;
        if( _1 != _31133 ){
            DeRef(_1);
        }
        _31133 = NOVALUE;
        _31130 = NOVALUE;
L3: 

        /** fwdref.e:517		end for*/
        _i_63448 = _i_63448 + 1LL;
        goto L1; // [97] 33
L2: 
        ;
    }

    /** fwdref.e:518		resolved_reference( ref )*/
    _44resolved_reference(_ref_63442);

    /** fwdref.e:519	end procedure*/
    DeRef(_tok_63441);
    DeRef(_fr_63443);
    DeRef(_syms_63445);
    _31125 = NOVALUE;
    _31129 = NOVALUE;
    return;
    ;
}


void _44patch_forward_case(object _tok_63471, object _ref_63472)
{
    object _fr_63473 = NOVALUE;
    object _switch_pc_63475 = NOVALUE;
    object _case_sym_63478 = NOVALUE;
    object _case_values_63507 = NOVALUE;
    object _cx_63512 = NOVALUE;
    object _negative_63520 = NOVALUE;
    object _31171 = NOVALUE;
    object _31170 = NOVALUE;
    object _31169 = NOVALUE;
    object _31168 = NOVALUE;
    object _31167 = NOVALUE;
    object _31166 = NOVALUE;
    object _31164 = NOVALUE;
    object _31162 = NOVALUE;
    object _31161 = NOVALUE;
    object _31159 = NOVALUE;
    object _31158 = NOVALUE;
    object _31155 = NOVALUE;
    object _31153 = NOVALUE;
    object _31152 = NOVALUE;
    object _31151 = NOVALUE;
    object _31150 = NOVALUE;
    object _31149 = NOVALUE;
    object _31148 = NOVALUE;
    object _31147 = NOVALUE;
    object _31146 = NOVALUE;
    object _31145 = NOVALUE;
    object _31143 = NOVALUE;
    object _31142 = NOVALUE;
    object _31141 = NOVALUE;
    object _31140 = NOVALUE;
    object _31138 = NOVALUE;
    object _31136 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:522		sequence fr = forward_references[ref]*/
    DeRef(_fr_63473);
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    _fr_63473 = (object)*(((s1_ptr)_2)->base + _ref_63472);
    Ref(_fr_63473);

    /** fwdref.e:524		integer switch_pc = fr[FR_DATA]*/
    _2 = (object)SEQ_PTR(_fr_63473);
    _switch_pc_63475 = (object)*(((s1_ptr)_2)->base + 12LL);
    if (!IS_ATOM_INT(_switch_pc_63475))
    _switch_pc_63475 = (object)DBL_PTR(_switch_pc_63475)->dbl;

    /** fwdref.e:527		if fr[FR_SUBPROG] = TopLevelSub then*/
    _2 = (object)SEQ_PTR(_fr_63473);
    _31136 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (binary_op_a(NOTEQ, _31136, _36TopLevelSub_21446)){
        _31136 = NOVALUE;
        goto L1; // [27] 48
    }
    _31136 = NOVALUE;

    /** fwdref.e:528			case_sym = Code[switch_pc + 2]*/
    _31138 = _switch_pc_63475 + 2LL;
    _2 = (object)SEQ_PTR(_36Code_21531);
    _case_sym_63478 = (object)*(((s1_ptr)_2)->base + _31138);
    if (!IS_ATOM_INT(_case_sym_63478)){
        _case_sym_63478 = (object)DBL_PTR(_case_sym_63478)->dbl;
    }
    goto L2; // [45] 77
L1: 

    /** fwdref.e:530			case_sym = SymTab[fr[FR_SUBPROG]][S_CODE][switch_pc + 2]*/
    _2 = (object)SEQ_PTR(_fr_63473);
    _31140 = (object)*(((s1_ptr)_2)->base + 4LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_31140)){
        _31141 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31140)->dbl));
    }
    else{
        _31141 = (object)*(((s1_ptr)_2)->base + _31140);
    }
    _2 = (object)SEQ_PTR(_31141);
    if (!IS_ATOM_INT(_36S_CODE_21088)){
        _31142 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
    }
    else{
        _31142 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21088);
    }
    _31141 = NOVALUE;
    _31143 = _switch_pc_63475 + 2LL;
    _2 = (object)SEQ_PTR(_31142);
    _case_sym_63478 = (object)*(((s1_ptr)_2)->base + _31143);
    if (!IS_ATOM_INT(_case_sym_63478)){
        _case_sym_63478 = (object)DBL_PTR(_case_sym_63478)->dbl;
    }
    _31142 = NOVALUE;
L2: 

    /** fwdref.e:533		if SymTab[tok[T_SYM]][S_FILE_NO] = fr[FR_FILE] and fr[FR_SUBPROG] = TopLevelSub then*/
    _2 = (object)SEQ_PTR(_tok_63471);
    _31145 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_31145)){
        _31146 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31145)->dbl));
    }
    else{
        _31146 = (object)*(((s1_ptr)_2)->base + _31145);
    }
    _2 = (object)SEQ_PTR(_31146);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _31147 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _31147 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    _31146 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_63473);
    _31148 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (IS_ATOM_INT(_31147) && IS_ATOM_INT(_31148)) {
        _31149 = (_31147 == _31148);
    }
    else {
        _31149 = binary_op(EQUALS, _31147, _31148);
    }
    _31147 = NOVALUE;
    _31148 = NOVALUE;
    if (IS_ATOM_INT(_31149)) {
        if (_31149 == 0) {
            goto L3; // [105] 129
        }
    }
    else {
        if (DBL_PTR(_31149)->dbl == 0.0) {
            goto L3; // [105] 129
        }
    }
    _2 = (object)SEQ_PTR(_fr_63473);
    _31151 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_31151)) {
        _31152 = (_31151 == _36TopLevelSub_21446);
    }
    else {
        _31152 = binary_op(EQUALS, _31151, _36TopLevelSub_21446);
    }
    _31151 = NOVALUE;
    if (_31152 == 0) {
        DeRef(_31152);
        _31152 = NOVALUE;
        goto L3; // [120] 129
    }
    else {
        if (!IS_ATOM_INT(_31152) && DBL_PTR(_31152)->dbl == 0.0){
            DeRef(_31152);
            _31152 = NOVALUE;
            goto L3; // [120] 129
        }
        DeRef(_31152);
        _31152 = NOVALUE;
    }
    DeRef(_31152);
    _31152 = NOVALUE;

    /** fwdref.e:534			return*/
    DeRef(_tok_63471);
    DeRef(_fr_63473);
    DeRef(_case_values_63507);
    DeRef(_31149);
    _31149 = NOVALUE;
    DeRef(_31143);
    _31143 = NOVALUE;
    _31140 = NOVALUE;
    DeRef(_31138);
    _31138 = NOVALUE;
    _31145 = NOVALUE;
    return;
L3: 

    /** fwdref.e:537		sequence case_values = SymTab[case_sym][S_OBJ]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31153 = (object)*(((s1_ptr)_2)->base + _case_sym_63478);
    DeRef(_case_values_63507);
    _2 = (object)SEQ_PTR(_31153);
    _case_values_63507 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_case_values_63507);
    _31153 = NOVALUE;

    /** fwdref.e:539		integer cx = find( { ref }, case_values )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _ref_63472;
    _31155 = MAKE_SEQ(_1);
    _cx_63512 = find_from(_31155, _case_values_63507, 1LL);
    DeRefDS(_31155);
    _31155 = NOVALUE;

    /** fwdref.e:540		if not cx then*/
    if (_cx_63512 != 0)
    goto L4; // [160] 178

    /** fwdref.e:541			cx = find( { -ref }, case_values )*/
    if ((uintptr_t)_ref_63472 == (uintptr_t)HIGH_BITS){
        _31158 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31158 = - _ref_63472;
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _31158;
    _31159 = MAKE_SEQ(_1);
    _31158 = NOVALUE;
    _cx_63512 = find_from(_31159, _case_values_63507, 1LL);
    DeRefDS(_31159);
    _31159 = NOVALUE;
L4: 

    /** fwdref.e:544	 	ifdef DEBUG then	*/

    /** fwdref.e:551		integer negative = 0*/
    _negative_63520 = 0LL;

    /** fwdref.e:552		if case_values[cx][1] < 0 then*/
    _2 = (object)SEQ_PTR(_case_values_63507);
    _31161 = (object)*(((s1_ptr)_2)->base + _cx_63512);
    _2 = (object)SEQ_PTR(_31161);
    _31162 = (object)*(((s1_ptr)_2)->base + 1LL);
    _31161 = NOVALUE;
    if (binary_op_a(GREATEREQ, _31162, 0LL)){
        _31162 = NOVALUE;
        goto L5; // [195] 224
    }
    _31162 = NOVALUE;

    /** fwdref.e:553			negative = 1*/
    _negative_63520 = 1LL;

    /** fwdref.e:554			case_values[cx][1] *= -1*/
    _2 = (object)SEQ_PTR(_case_values_63507);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _case_values_63507 = MAKE_SEQ(_2);
    }
    _3 = (object)(_cx_63512 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _31166 = (object)*(((s1_ptr)_2)->base + 1LL);
    _31164 = NOVALUE;
    if (IS_ATOM_INT(_31166)) {
        {
            int128_t p128 = (int128_t)_31166 * (int128_t)-1LL;
            if( p128 != (int128_t)(_31167 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _31167 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _31167 = binary_op(MULTIPLY, _31166, -1LL);
    }
    _31166 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31167;
    if( _1 != _31167 ){
        DeRef(_1);
    }
    _31167 = NOVALUE;
    _31164 = NOVALUE;
L5: 

    /** fwdref.e:557		if negative then*/
    if (_negative_63520 == 0)
    {
        goto L6; // [226] 247
    }
    else{
    }

    /** fwdref.e:558			case_values[cx] = - tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63471);
    _31168 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_31168)) {
        if ((uintptr_t)_31168 == (uintptr_t)HIGH_BITS){
            _31169 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _31169 = - _31168;
        }
    }
    else {
        _31169 = unary_op(UMINUS, _31168);
    }
    _31168 = NOVALUE;
    _2 = (object)SEQ_PTR(_case_values_63507);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _case_values_63507 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _cx_63512);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31169;
    if( _1 != _31169 ){
        DeRef(_1);
    }
    _31169 = NOVALUE;
    goto L7; // [244] 260
L6: 

    /** fwdref.e:560			case_values[cx] = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63471);
    _31170 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_31170);
    _2 = (object)SEQ_PTR(_case_values_63507);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _case_values_63507 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _cx_63512);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31170;
    if( _1 != _31170 ){
        DeRef(_1);
    }
    _31170 = NOVALUE;
L7: 

    /** fwdref.e:562		SymTab[case_sym][S_OBJ] = case_values*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_case_sym_63478 + ((s1_ptr)_2)->base);
    RefDS(_case_values_63507);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _case_values_63507;
    DeRef(_1);
    _31171 = NOVALUE;

    /** fwdref.e:563		resolved_reference( ref )*/
    _44resolved_reference(_ref_63472);

    /** fwdref.e:564	end procedure*/
    DeRef(_tok_63471);
    DeRef(_fr_63473);
    DeRefDS(_case_values_63507);
    DeRef(_31149);
    _31149 = NOVALUE;
    DeRef(_31143);
    _31143 = NOVALUE;
    _31140 = NOVALUE;
    DeRef(_31138);
    _31138 = NOVALUE;
    _31145 = NOVALUE;
    return;
    ;
}


void _44patch_forward_type_check(object _tok_63543, object _ref_63544)
{
    object _fr_63545 = NOVALUE;
    object _which_type_63548 = NOVALUE;
    object _var_63550 = NOVALUE;
    object _pc_63583 = NOVALUE;
    object _with_type_check_63585 = NOVALUE;
    object _c_63615 = NOVALUE;
    object _subprog_inlined_insert_code_at_332_63624 = NOVALUE;
    object _code_inlined_insert_code_at_329_63623 = NOVALUE;
    object _subprog_inlined_insert_code_at_415_63640 = NOVALUE;
    object _code_inlined_insert_code_at_412_63639 = NOVALUE;
    object _subprog_inlined_insert_code_at_477_63650 = NOVALUE;
    object _code_inlined_insert_code_at_474_63649 = NOVALUE;
    object _subprog_inlined_insert_code_at_539_63660 = NOVALUE;
    object _code_inlined_insert_code_at_536_63659 = NOVALUE;
    object _start_pc_63667 = NOVALUE;
    object _subprog_inlined_insert_code_at_647_63684 = NOVALUE;
    object _code_inlined_insert_code_at_644_63683 = NOVALUE;
    object _c_63687 = NOVALUE;
    object _subprog_inlined_insert_code_at_741_63703 = NOVALUE;
    object _code_inlined_insert_code_at_738_63702 = NOVALUE;
    object _start_pc_63714 = NOVALUE;
    object _subprog_inlined_insert_code_at_886_63734 = NOVALUE;
    object _code_inlined_insert_code_at_883_63733 = NOVALUE;
    object _subprog_inlined_insert_code_at_987_63755 = NOVALUE;
    object _code_inlined_insert_code_at_984_63754 = NOVALUE;
    object _31261 = NOVALUE;
    object _31260 = NOVALUE;
    object _31259 = NOVALUE;
    object _31258 = NOVALUE;
    object _31257 = NOVALUE;
    object _31256 = NOVALUE;
    object _31255 = NOVALUE;
    object _31253 = NOVALUE;
    object _31251 = NOVALUE;
    object _31250 = NOVALUE;
    object _31249 = NOVALUE;
    object _31248 = NOVALUE;
    object _31247 = NOVALUE;
    object _31246 = NOVALUE;
    object _31245 = NOVALUE;
    object _31243 = NOVALUE;
    object _31242 = NOVALUE;
    object _31241 = NOVALUE;
    object _31240 = NOVALUE;
    object _31239 = NOVALUE;
    object _31238 = NOVALUE;
    object _31236 = NOVALUE;
    object _31235 = NOVALUE;
    object _31234 = NOVALUE;
    object _31233 = NOVALUE;
    object _31231 = NOVALUE;
    object _31230 = NOVALUE;
    object _31227 = NOVALUE;
    object _31226 = NOVALUE;
    object _31224 = NOVALUE;
    object _31223 = NOVALUE;
    object _31222 = NOVALUE;
    object _31221 = NOVALUE;
    object _31220 = NOVALUE;
    object _31219 = NOVALUE;
    object _31217 = NOVALUE;
    object _31216 = NOVALUE;
    object _31213 = NOVALUE;
    object _31212 = NOVALUE;
    object _31209 = NOVALUE;
    object _31208 = NOVALUE;
    object _31204 = NOVALUE;
    object _31203 = NOVALUE;
    object _31201 = NOVALUE;
    object _31200 = NOVALUE;
    object _31198 = NOVALUE;
    object _31197 = NOVALUE;
    object _31194 = NOVALUE;
    object _31191 = NOVALUE;
    object _31189 = NOVALUE;
    object _31186 = NOVALUE;
    object _31185 = NOVALUE;
    object _31182 = NOVALUE;
    object _31177 = NOVALUE;
    object _31176 = NOVALUE;
    object _31174 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:568		sequence fr = forward_references[ref]*/
    DeRef(_fr_63545);
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    _fr_63545 = (object)*(((s1_ptr)_2)->base + _ref_63544);
    Ref(_fr_63545);

    /** fwdref.e:572		if fr[FR_OP] = TYPE_CHECK_FORWARD then*/
    _2 = (object)SEQ_PTR(_fr_63545);
    _31174 = (object)*(((s1_ptr)_2)->base + 10LL);
    if (binary_op_a(NOTEQ, _31174, 197LL)){
        _31174 = NOVALUE;
        goto L1; // [21] 86
    }
    _31174 = NOVALUE;

    /** fwdref.e:573			which_type = SymTab[tok[T_SYM]][S_VTYPE]*/
    _2 = (object)SEQ_PTR(_tok_63543);
    _31176 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_31176)){
        _31177 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31176)->dbl));
    }
    else{
        _31177 = (object)*(((s1_ptr)_2)->base + _31176);
    }
    _2 = (object)SEQ_PTR(_31177);
    _which_type_63548 = (object)*(((s1_ptr)_2)->base + 15LL);
    if (!IS_ATOM_INT(_which_type_63548)){
        _which_type_63548 = (object)DBL_PTR(_which_type_63548)->dbl;
    }
    _31177 = NOVALUE;

    /** fwdref.e:574			if not which_type then*/
    if (_which_type_63548 != 0)
    goto L2; // [49] 72

    /** fwdref.e:575				which_type = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63543);
    _which_type_63548 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_which_type_63548)){
        _which_type_63548 = (object)DBL_PTR(_which_type_63548)->dbl;
    }

    /** fwdref.e:576				var = 0*/
    _var_63550 = 0LL;
    goto L3; // [69] 144
L2: 

    /** fwdref.e:578				var = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63543);
    _var_63550 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_var_63550)){
        _var_63550 = (object)DBL_PTR(_var_63550)->dbl;
    }
    goto L3; // [83] 144
L1: 

    /** fwdref.e:582		elsif fr[FR_OP] = TYPE then*/
    _2 = (object)SEQ_PTR(_fr_63545);
    _31182 = (object)*(((s1_ptr)_2)->base + 10LL);
    if (binary_op_a(NOTEQ, _31182, 504LL)){
        _31182 = NOVALUE;
        goto L4; // [94] 118
    }
    _31182 = NOVALUE;

    /** fwdref.e:583			which_type = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63543);
    _which_type_63548 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_which_type_63548)){
        _which_type_63548 = (object)DBL_PTR(_which_type_63548)->dbl;
    }

    /** fwdref.e:584			var = 0*/
    _var_63550 = 0LL;
    goto L3; // [115] 144
L4: 

    /** fwdref.e:587			prep_forward_error( ref )*/
    _44prep_forward_error(_ref_63544);

    /** fwdref.e:588			InternalErr( 262, { TYPE_CHECK, TYPE_CHECK_FORWARD, fr[FR_OP] })*/
    _2 = (object)SEQ_PTR(_fr_63545);
    _31185 = (object)*(((s1_ptr)_2)->base + 10LL);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 65LL;
    ((intptr_t*)_2)[2] = 197LL;
    Ref(_31185);
    ((intptr_t*)_2)[3] = _31185;
    _31186 = MAKE_SEQ(_1);
    _31185 = NOVALUE;
    _50InternalErr(262LL, _31186);
    _31186 = NOVALUE;
L3: 

    /** fwdref.e:591		if which_type < 0 then*/
    if (_which_type_63548 >= 0LL)
    goto L5; // [148] 158

    /** fwdref.e:593			return*/
    DeRef(_tok_63543);
    DeRef(_fr_63545);
    _31176 = NOVALUE;
    return;
L5: 

    /** fwdref.e:596		set_code( ref )*/
    _44set_code(_ref_63544);

    /** fwdref.e:598		integer pc = fr[FR_PC]*/
    _2 = (object)SEQ_PTR(_fr_63545);
    _pc_63583 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (!IS_ATOM_INT(_pc_63583))
    _pc_63583 = (object)DBL_PTR(_pc_63583)->dbl;

    /** fwdref.e:599		integer with_type_check = Code[pc + 2]*/
    _31189 = _pc_63583 + 2LL;
    _2 = (object)SEQ_PTR(_36Code_21531);
    _with_type_check_63585 = (object)*(((s1_ptr)_2)->base + _31189);
    if (!IS_ATOM_INT(_with_type_check_63585)){
        _with_type_check_63585 = (object)DBL_PTR(_with_type_check_63585)->dbl;
    }

    /** fwdref.e:601		if Code[pc] != TYPE_CHECK_FORWARD then*/
    _2 = (object)SEQ_PTR(_36Code_21531);
    _31191 = (object)*(((s1_ptr)_2)->base + _pc_63583);
    if (binary_op_a(EQUALS, _31191, 197LL)){
        _31191 = NOVALUE;
        goto L6; // [193] 204
    }
    _31191 = NOVALUE;

    /** fwdref.e:602			forward_error( tok, ref )*/
    Ref(_tok_63543);
    _44forward_error(_tok_63543, _ref_63544);
L6: 

    /** fwdref.e:604		if not var then*/
    if (_var_63550 != 0)
    goto L7; // [208] 226

    /** fwdref.e:606			var = Code[pc+1]*/
    _31194 = _pc_63583 + 1;
    _2 = (object)SEQ_PTR(_36Code_21531);
    _var_63550 = (object)*(((s1_ptr)_2)->base + _31194);
    if (!IS_ATOM_INT(_var_63550)){
        _var_63550 = (object)DBL_PTR(_var_63550)->dbl;
    }
L7: 

    /** fwdref.e:609		if var < 0 then*/
    if (_var_63550 >= 0LL)
    goto L8; // [228] 238

    /** fwdref.e:611			return*/
    DeRef(_tok_63543);
    DeRef(_fr_63545);
    DeRef(_31189);
    _31189 = NOVALUE;
    DeRef(_31194);
    _31194 = NOVALUE;
    _31176 = NOVALUE;
    return;
L8: 

    /** fwdref.e:615		replace_code( {}, pc, pc + 2, fr[FR_SUBPROG])*/
    _31197 = _pc_63583 + 2LL;
    if ((object)((uintptr_t)_31197 + (uintptr_t)HIGH_BITS) >= 0){
        _31197 = NewDouble((eudouble)_31197);
    }
    _2 = (object)SEQ_PTR(_fr_63545);
    _31198 = (object)*(((s1_ptr)_2)->base + 4LL);
    RefDS(_21993);
    Ref(_31198);
    _44replace_code(_21993, _pc_63583, _31197, _31198);
    _31197 = NOVALUE;
    _31198 = NOVALUE;

    /** fwdref.e:617		if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L9; // [258] 364
    }
    else{
    }

    /** fwdref.e:618			if with_type_check then*/
    if (_with_type_check_63585 == 0)
    {
        goto LA; // [263] 771
    }
    else{
    }

    /** fwdref.e:619				if which_type != object_type then*/
    if (_which_type_63548 == _54object_type_46776)
    goto LA; // [270] 771

    /** fwdref.e:620					if SymTab[which_type][S_EFFECT] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31200 = (object)*(((s1_ptr)_2)->base + _which_type_63548);
    _2 = (object)SEQ_PTR(_31200);
    _31201 = (object)*(((s1_ptr)_2)->base + 23LL);
    _31200 = NOVALUE;
    if (_31201 == 0) {
        _31201 = NOVALUE;
        goto LB; // [288] 357
    }
    else {
        if (!IS_ATOM_INT(_31201) && DBL_PTR(_31201)->dbl == 0.0){
            _31201 = NOVALUE;
            goto LB; // [288] 357
        }
        _31201 = NOVALUE;
    }
    _31201 = NOVALUE;

    /** fwdref.e:622						integer c = NewTempSym()*/
    _c_63615 = _54NewTempSym(0LL);
    if (!IS_ATOM_INT(_c_63615)) {
        _1 = (object)(DBL_PTR(_c_63615)->dbl);
        DeRefDS(_c_63615);
        _c_63615 = _1;
    }

    /** fwdref.e:623						insert_code( { PROC, which_type, var, c, TYPE_CHECK }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 27LL;
    ((intptr_t*)_2)[2] = _which_type_63548;
    ((intptr_t*)_2)[3] = _var_63550;
    ((intptr_t*)_2)[4] = _c_63615;
    ((intptr_t*)_2)[5] = 65LL;
    _31203 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63545);
    _31204 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_329_63623);
    _code_inlined_insert_code_at_329_63623 = _31203;
    _31203 = NOVALUE;
    Ref(_31204);
    DeRef(_subprog_inlined_insert_code_at_332_63624);
    _subprog_inlined_insert_code_at_332_63624 = _31204;
    _31204 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_332_63624)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_332_63624)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_332_63624);
        _subprog_inlined_insert_code_at_332_63624 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_62784 = _subprog_inlined_insert_code_at_332_63624;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_329_63623);
    _66insert_code(_code_inlined_insert_code_at_329_63623, _pc_63583);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_62784 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto LC; // [345] 348
LC: 
    DeRefi(_code_inlined_insert_code_at_329_63623);
    _code_inlined_insert_code_at_329_63623 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_332_63624);
    _subprog_inlined_insert_code_at_332_63624 = NOVALUE;

    /** fwdref.e:624						pc += 5*/
    _pc_63583 = _pc_63583 + 5LL;
LB: 
    goto LA; // [361] 771
L9: 

    /** fwdref.e:630			if with_type_check then*/
    if (_with_type_check_63585 == 0)
    {
        goto LD; // [366] 770
    }
    else{
    }

    /** fwdref.e:632				if which_type = object_type then*/
    if (_which_type_63548 != _54object_type_46776)
    goto LE; // [373] 380
    goto LF; // [377] 769
LE: 

    /** fwdref.e:636					if which_type = integer_type then*/
    if (_which_type_63548 != _54integer_type_46782)
    goto L10; // [384] 442

    /** fwdref.e:637						insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 96LL;
    ((intptr_t *)_2)[2] = _var_63550;
    _31208 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63545);
    _31209 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_412_63639);
    _code_inlined_insert_code_at_412_63639 = _31208;
    _31208 = NOVALUE;
    Ref(_31209);
    DeRef(_subprog_inlined_insert_code_at_415_63640);
    _subprog_inlined_insert_code_at_415_63640 = _31209;
    _31209 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_415_63640)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_415_63640)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_415_63640);
        _subprog_inlined_insert_code_at_415_63640 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_62784 = _subprog_inlined_insert_code_at_415_63640;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_412_63639);
    _66insert_code(_code_inlined_insert_code_at_412_63639, _pc_63583);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_62784 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto L11; // [428] 431
L11: 
    DeRefi(_code_inlined_insert_code_at_412_63639);
    _code_inlined_insert_code_at_412_63639 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_415_63640);
    _subprog_inlined_insert_code_at_415_63640 = NOVALUE;

    /** fwdref.e:638						pc += 2*/
    _pc_63583 = _pc_63583 + 2LL;
    goto L12; // [439] 768
L10: 

    /** fwdref.e:640					elsif which_type = sequence_type then*/
    if (_which_type_63548 != _54sequence_type_46780)
    goto L13; // [446] 504

    /** fwdref.e:641						insert_code( { SEQUENCE_CHECK, var }, pc, fr[FR_SUBPROG])*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 97LL;
    ((intptr_t *)_2)[2] = _var_63550;
    _31212 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63545);
    _31213 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_474_63649);
    _code_inlined_insert_code_at_474_63649 = _31212;
    _31212 = NOVALUE;
    Ref(_31213);
    DeRef(_subprog_inlined_insert_code_at_477_63650);
    _subprog_inlined_insert_code_at_477_63650 = _31213;
    _31213 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_477_63650)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_477_63650)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_477_63650);
        _subprog_inlined_insert_code_at_477_63650 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_62784 = _subprog_inlined_insert_code_at_477_63650;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_474_63649);
    _66insert_code(_code_inlined_insert_code_at_474_63649, _pc_63583);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_62784 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto L14; // [490] 493
L14: 
    DeRefi(_code_inlined_insert_code_at_474_63649);
    _code_inlined_insert_code_at_474_63649 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_477_63650);
    _subprog_inlined_insert_code_at_477_63650 = NOVALUE;

    /** fwdref.e:642						pc += 2*/
    _pc_63583 = _pc_63583 + 2LL;
    goto L12; // [501] 768
L13: 

    /** fwdref.e:644					elsif which_type = atom_type then*/
    if (_which_type_63548 != _54atom_type_46778)
    goto L15; // [508] 566

    /** fwdref.e:645						insert_code( { ATOM_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 101LL;
    ((intptr_t *)_2)[2] = _var_63550;
    _31216 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63545);
    _31217 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_536_63659);
    _code_inlined_insert_code_at_536_63659 = _31216;
    _31216 = NOVALUE;
    Ref(_31217);
    DeRef(_subprog_inlined_insert_code_at_539_63660);
    _subprog_inlined_insert_code_at_539_63660 = _31217;
    _31217 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_539_63660)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_539_63660)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_539_63660);
        _subprog_inlined_insert_code_at_539_63660 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_62784 = _subprog_inlined_insert_code_at_539_63660;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_536_63659);
    _66insert_code(_code_inlined_insert_code_at_536_63659, _pc_63583);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_62784 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto L16; // [552] 555
L16: 
    DeRefi(_code_inlined_insert_code_at_536_63659);
    _code_inlined_insert_code_at_536_63659 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_539_63660);
    _subprog_inlined_insert_code_at_539_63660 = NOVALUE;

    /** fwdref.e:646						pc += 2*/
    _pc_63583 = _pc_63583 + 2LL;
    goto L12; // [563] 768
L15: 

    /** fwdref.e:648					elsif SymTab[which_type][S_NEXT] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31219 = (object)*(((s1_ptr)_2)->base + _which_type_63548);
    _2 = (object)SEQ_PTR(_31219);
    _31220 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31219 = NOVALUE;
    if (_31220 == 0) {
        _31220 = NOVALUE;
        goto L17; // [580] 765
    }
    else {
        if (!IS_ATOM_INT(_31220) && DBL_PTR(_31220)->dbl == 0.0){
            _31220 = NOVALUE;
            goto L17; // [580] 765
        }
        _31220 = NOVALUE;
    }
    _31220 = NOVALUE;

    /** fwdref.e:649						integer start_pc = pc*/
    _start_pc_63667 = _pc_63583;

    /** fwdref.e:652						if SymTab[SymTab[which_type][S_NEXT]][S_VTYPE] = integer_type then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31221 = (object)*(((s1_ptr)_2)->base + _which_type_63548);
    _2 = (object)SEQ_PTR(_31221);
    _31222 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31221 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_31222)){
        _31223 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31222)->dbl));
    }
    else{
        _31223 = (object)*(((s1_ptr)_2)->base + _31222);
    }
    _2 = (object)SEQ_PTR(_31223);
    _31224 = (object)*(((s1_ptr)_2)->base + 15LL);
    _31223 = NOVALUE;
    if (binary_op_a(NOTEQ, _31224, _54integer_type_46782)){
        _31224 = NOVALUE;
        goto L18; // [616] 672
    }
    _31224 = NOVALUE;

    /** fwdref.e:654							insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 96LL;
    ((intptr_t *)_2)[2] = _var_63550;
    _31226 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63545);
    _31227 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_644_63683);
    _code_inlined_insert_code_at_644_63683 = _31226;
    _31226 = NOVALUE;
    Ref(_31227);
    DeRef(_subprog_inlined_insert_code_at_647_63684);
    _subprog_inlined_insert_code_at_647_63684 = _31227;
    _31227 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_647_63684)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_647_63684)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_647_63684);
        _subprog_inlined_insert_code_at_647_63684 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_62784 = _subprog_inlined_insert_code_at_647_63684;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_644_63683);
    _66insert_code(_code_inlined_insert_code_at_644_63683, _pc_63583);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_62784 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto L19; // [660] 663
L19: 
    DeRefi(_code_inlined_insert_code_at_644_63683);
    _code_inlined_insert_code_at_644_63683 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_647_63684);
    _subprog_inlined_insert_code_at_647_63684 = NOVALUE;

    /** fwdref.e:656							pc += 2*/
    _pc_63583 = _pc_63583 + 2LL;
L18: 

    /** fwdref.e:658						symtab_index c = NewTempSym()*/
    _c_63687 = _54NewTempSym(0LL);
    if (!IS_ATOM_INT(_c_63687)) {
        _1 = (object)(DBL_PTR(_c_63687)->dbl);
        DeRefDS(_c_63687);
        _c_63687 = _1;
    }

    /** fwdref.e:659						SymTab[fr[FR_SUBPROG]][S_STACK_SPACE] += 1*/
    _2 = (object)SEQ_PTR(_fr_63545);
    _31230 = (object)*(((s1_ptr)_2)->base + 4LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_31230))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31230)->dbl));
    else
    _3 = (object)(_31230 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21136)){
        _31233 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21136)->dbl));
    }
    else{
        _31233 = (object)*(((s1_ptr)_2)->base + _36S_STACK_SPACE_21136);
    }
    _31231 = NOVALUE;
    if (IS_ATOM_INT(_31233)) {
        _31234 = _31233 + 1;
        if (_31234 > MAXINT){
            _31234 = NewDouble((eudouble)_31234);
        }
    }
    else
    _31234 = binary_op(PLUS, 1, _31233);
    _31233 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21136))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21136)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_STACK_SPACE_21136);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31234;
    if( _1 != _31234 ){
        DeRef(_1);
    }
    _31234 = NOVALUE;
    _31231 = NOVALUE;

    /** fwdref.e:660						insert_code( { PROC, which_type, var, c, TYPE_CHECK }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 27LL;
    ((intptr_t*)_2)[2] = _which_type_63548;
    ((intptr_t*)_2)[3] = _var_63550;
    ((intptr_t*)_2)[4] = _c_63687;
    ((intptr_t*)_2)[5] = 65LL;
    _31235 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63545);
    _31236 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_738_63702);
    _code_inlined_insert_code_at_738_63702 = _31235;
    _31235 = NOVALUE;
    Ref(_31236);
    DeRef(_subprog_inlined_insert_code_at_741_63703);
    _subprog_inlined_insert_code_at_741_63703 = _31236;
    _31236 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_741_63703)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_741_63703)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_741_63703);
        _subprog_inlined_insert_code_at_741_63703 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_62784 = _subprog_inlined_insert_code_at_741_63703;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_738_63702);
    _66insert_code(_code_inlined_insert_code_at_738_63702, _pc_63583);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_62784 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto L1A; // [753] 756
L1A: 
    DeRefi(_code_inlined_insert_code_at_738_63702);
    _code_inlined_insert_code_at_738_63702 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_741_63703);
    _subprog_inlined_insert_code_at_741_63703 = NOVALUE;

    /** fwdref.e:661						pc += 4*/
    _pc_63583 = _pc_63583 + 4LL;
L17: 
L12: 
LF: 
LD: 
LA: 

    /** fwdref.e:668		if (TRANSLATE or not with_type_check) and SymTab[which_type][S_NEXT] then*/
    if (_36TRANSLATE_21041 != 0) {
        _31238 = 1;
        goto L1B; // [775] 786
    }
    _31239 = (_with_type_check_63585 == 0);
    _31238 = (_31239 != 0);
L1B: 
    if (_31238 == 0) {
        goto L1C; // [786] 1013
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31241 = (object)*(((s1_ptr)_2)->base + _which_type_63548);
    _2 = (object)SEQ_PTR(_31241);
    _31242 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31241 = NOVALUE;
    if (_31242 == 0) {
        _31242 = NOVALUE;
        goto L1C; // [803] 1013
    }
    else {
        if (!IS_ATOM_INT(_31242) && DBL_PTR(_31242)->dbl == 0.0){
            _31242 = NOVALUE;
            goto L1C; // [803] 1013
        }
        _31242 = NOVALUE;
    }
    _31242 = NOVALUE;

    /** fwdref.e:669			integer start_pc = pc*/
    _start_pc_63714 = _pc_63583;

    /** fwdref.e:671			if which_type = sequence_type or*/
    _31243 = (_which_type_63548 == _54sequence_type_46780);
    if (_31243 != 0) {
        goto L1D; // [819] 858
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31245 = (object)*(((s1_ptr)_2)->base + _which_type_63548);
    _2 = (object)SEQ_PTR(_31245);
    _31246 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31245 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_31246)){
        _31247 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31246)->dbl));
    }
    else{
        _31247 = (object)*(((s1_ptr)_2)->base + _31246);
    }
    _2 = (object)SEQ_PTR(_31247);
    _31248 = (object)*(((s1_ptr)_2)->base + 15LL);
    _31247 = NOVALUE;
    if (IS_ATOM_INT(_31248)) {
        _31249 = (_31248 == _54sequence_type_46780);
    }
    else {
        _31249 = binary_op(EQUALS, _31248, _54sequence_type_46780);
    }
    _31248 = NOVALUE;
    if (_31249 == 0) {
        DeRef(_31249);
        _31249 = NOVALUE;
        goto L1E; // [854] 912
    }
    else {
        if (!IS_ATOM_INT(_31249) && DBL_PTR(_31249)->dbl == 0.0){
            DeRef(_31249);
            _31249 = NOVALUE;
            goto L1E; // [854] 912
        }
        DeRef(_31249);
        _31249 = NOVALUE;
    }
    DeRef(_31249);
    _31249 = NOVALUE;
L1D: 

    /** fwdref.e:674				insert_code( { SEQUENCE_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 97LL;
    ((intptr_t *)_2)[2] = _var_63550;
    _31250 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63545);
    _31251 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_883_63733);
    _code_inlined_insert_code_at_883_63733 = _31250;
    _31250 = NOVALUE;
    Ref(_31251);
    DeRef(_subprog_inlined_insert_code_at_886_63734);
    _subprog_inlined_insert_code_at_886_63734 = _31251;
    _31251 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_886_63734)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_886_63734)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_886_63734);
        _subprog_inlined_insert_code_at_886_63734 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_62784 = _subprog_inlined_insert_code_at_886_63734;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_883_63733);
    _66insert_code(_code_inlined_insert_code_at_883_63733, _pc_63583);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_62784 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto L1F; // [898] 901
L1F: 
    DeRefi(_code_inlined_insert_code_at_883_63733);
    _code_inlined_insert_code_at_883_63733 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_886_63734);
    _subprog_inlined_insert_code_at_886_63734 = NOVALUE;

    /** fwdref.e:675				pc += 2*/
    _pc_63583 = _pc_63583 + 2LL;
    goto L20; // [909] 1012
L1E: 

    /** fwdref.e:677			elsif which_type = integer_type or*/
    _31253 = (_which_type_63548 == _54integer_type_46782);
    if (_31253 != 0) {
        goto L21; // [920] 959
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31255 = (object)*(((s1_ptr)_2)->base + _which_type_63548);
    _2 = (object)SEQ_PTR(_31255);
    _31256 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31255 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_31256)){
        _31257 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31256)->dbl));
    }
    else{
        _31257 = (object)*(((s1_ptr)_2)->base + _31256);
    }
    _2 = (object)SEQ_PTR(_31257);
    _31258 = (object)*(((s1_ptr)_2)->base + 15LL);
    _31257 = NOVALUE;
    if (IS_ATOM_INT(_31258)) {
        _31259 = (_31258 == _54integer_type_46782);
    }
    else {
        _31259 = binary_op(EQUALS, _31258, _54integer_type_46782);
    }
    _31258 = NOVALUE;
    if (_31259 == 0) {
        DeRef(_31259);
        _31259 = NOVALUE;
        goto L22; // [955] 1011
    }
    else {
        if (!IS_ATOM_INT(_31259) && DBL_PTR(_31259)->dbl == 0.0){
            DeRef(_31259);
            _31259 = NOVALUE;
            goto L22; // [955] 1011
        }
        DeRef(_31259);
        _31259 = NOVALUE;
    }
    DeRef(_31259);
    _31259 = NOVALUE;
L21: 

    /** fwdref.e:680				insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 96LL;
    ((intptr_t *)_2)[2] = _var_63550;
    _31260 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63545);
    _31261 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_984_63754);
    _code_inlined_insert_code_at_984_63754 = _31260;
    _31260 = NOVALUE;
    Ref(_31261);
    DeRef(_subprog_inlined_insert_code_at_987_63755);
    _subprog_inlined_insert_code_at_987_63755 = _31261;
    _31261 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_987_63755)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_987_63755)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_987_63755);
        _subprog_inlined_insert_code_at_987_63755 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_62784 = _subprog_inlined_insert_code_at_987_63755;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_984_63754);
    _66insert_code(_code_inlined_insert_code_at_984_63754, _pc_63583);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_62784 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto L23; // [999] 1002
L23: 
    DeRefi(_code_inlined_insert_code_at_984_63754);
    _code_inlined_insert_code_at_984_63754 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_987_63755);
    _subprog_inlined_insert_code_at_987_63755 = NOVALUE;

    /** fwdref.e:681				pc += 4*/
    _pc_63583 = _pc_63583 + 4LL;
L22: 
L20: 
L1C: 

    /** fwdref.e:686		resolved_reference( ref )*/
    _44resolved_reference(_ref_63544);

    /** fwdref.e:687		reset_code()*/
    _44reset_code();

    /** fwdref.e:688	end procedure*/
    DeRef(_tok_63543);
    DeRef(_fr_63545);
    DeRef(_31189);
    _31189 = NOVALUE;
    _31230 = NOVALUE;
    _31222 = NOVALUE;
    DeRef(_31239);
    _31239 = NOVALUE;
    DeRef(_31194);
    _31194 = NOVALUE;
    _31256 = NOVALUE;
    _31246 = NOVALUE;
    _31176 = NOVALUE;
    DeRef(_31253);
    _31253 = NOVALUE;
    DeRef(_31243);
    _31243 = NOVALUE;
    return;
    ;
}


void _44prep_forward_error(object _ref_63759)
{
    object _31269 = NOVALUE;
    object _31267 = NOVALUE;
    object _31265 = NOVALUE;
    object _31263 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_ref_63759)) {
        _1 = (object)(DBL_PTR(_ref_63759)->dbl);
        DeRefDS(_ref_63759);
        _ref_63759 = _1;
    }

    /** fwdref.e:691		ThisLine = forward_references[ref][FR_THISLINE]*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    _31263 = (object)*(((s1_ptr)_2)->base + _ref_63759);
    DeRef(_50ThisLine_49234);
    _2 = (object)SEQ_PTR(_31263);
    _50ThisLine_49234 = (object)*(((s1_ptr)_2)->base + 7LL);
    Ref(_50ThisLine_49234);
    _31263 = NOVALUE;

    /** fwdref.e:692		bp = forward_references[ref][FR_BP]*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    _31265 = (object)*(((s1_ptr)_2)->base + _ref_63759);
    _2 = (object)SEQ_PTR(_31265);
    _50bp_49238 = (object)*(((s1_ptr)_2)->base + 8LL);
    if (!IS_ATOM_INT(_50bp_49238)){
        _50bp_49238 = (object)DBL_PTR(_50bp_49238)->dbl;
    }
    _31265 = NOVALUE;

    /** fwdref.e:693		line_number = forward_references[ref][FR_LINE]*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    _31267 = (object)*(((s1_ptr)_2)->base + _ref_63759);
    _2 = (object)SEQ_PTR(_31267);
    _36line_number_21440 = (object)*(((s1_ptr)_2)->base + 6LL);
    if (!IS_ATOM_INT(_36line_number_21440)){
        _36line_number_21440 = (object)DBL_PTR(_36line_number_21440)->dbl;
    }
    _31267 = NOVALUE;

    /** fwdref.e:694		current_file_no = forward_references[ref][FR_FILE]*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    _31269 = (object)*(((s1_ptr)_2)->base + _ref_63759);
    _2 = (object)SEQ_PTR(_31269);
    _36current_file_no_21439 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_36current_file_no_21439)){
        _36current_file_no_21439 = (object)DBL_PTR(_36current_file_no_21439)->dbl;
    }
    _31269 = NOVALUE;

    /** fwdref.e:695	end procedure*/
    return;
    ;
}


void _44forward_error(object _tok_63775, object _ref_63776)
{
    object _31276 = NOVALUE;
    object _31275 = NOVALUE;
    object _31274 = NOVALUE;
    object _31273 = NOVALUE;
    object _31272 = NOVALUE;
    object _31271 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:698		prep_forward_error( ref )*/
    _44prep_forward_error(_ref_63776);

    /** fwdref.e:699		CompileErr(EXPECTED_1_NOT_2, { expected_name( forward_references[ref][FR_TYPE] ),*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    _31271 = (object)*(((s1_ptr)_2)->base + _ref_63776);
    _2 = (object)SEQ_PTR(_31271);
    _31272 = (object)*(((s1_ptr)_2)->base + 1LL);
    _31271 = NOVALUE;
    Ref(_31272);
    _31273 = _44expected_name(_31272);
    _31272 = NOVALUE;
    _2 = (object)SEQ_PTR(_tok_63775);
    _31274 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_31274);
    _31275 = _44expected_name(_31274);
    _31274 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _31273;
    ((intptr_t *)_2)[2] = _31275;
    _31276 = MAKE_SEQ(_1);
    _31275 = NOVALUE;
    _31273 = NOVALUE;
    _50CompileErr(68LL, _31276, 0LL);
    _31276 = NOVALUE;

    /** fwdref.e:701	end procedure*/
    DeRef(_tok_63775);
    return;
    ;
}


object _44find_reference(object _fr_63788)
{
    object _name_63789 = NOVALUE;
    object _file_63791 = NOVALUE;
    object _ns_file_63793 = NOVALUE;
    object _ix_63794 = NOVALUE;
    object _ns_63797 = NOVALUE;
    object _ns_tok_63801 = NOVALUE;
    object _tok_63813 = NOVALUE;
    object _31287 = NOVALUE;
    object _31284 = NOVALUE;
    object _31282 = NOVALUE;
    object _31280 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:706		sequence name = fr[FR_NAME]*/
    DeRef(_name_63789);
    _2 = (object)SEQ_PTR(_fr_63788);
    _name_63789 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_name_63789);

    /** fwdref.e:707		integer file  = fr[FR_FILE]*/
    _2 = (object)SEQ_PTR(_fr_63788);
    _file_63791 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_file_63791))
    _file_63791 = (object)DBL_PTR(_file_63791)->dbl;

    /** fwdref.e:709		integer ns_file = -1*/
    _ns_file_63793 = -1LL;

    /** fwdref.e:710		integer ix = find( ':', name )*/
    _ix_63794 = find_from(58LL, _name_63789, 1LL);

    /** fwdref.e:711		if ix then*/
    if (_ix_63794 == 0)
    {
        goto L1; // [31] 85
    }
    else{
    }

    /** fwdref.e:712			sequence ns = name[1..ix-1]*/
    _31280 = _ix_63794 - 1LL;
    rhs_slice_target = (object_ptr)&_ns_63797;
    RHS_Slice(_name_63789, 1LL, _31280);

    /** fwdref.e:713			token ns_tok = keyfind( ns, ns_file, file, 1, fr[FR_HASHVAL] )*/
    _2 = (object)SEQ_PTR(_fr_63788);
    _31282 = (object)*(((s1_ptr)_2)->base + 11LL);
    RefDS(_ns_63797);
    Ref(_31282);
    _0 = _ns_tok_63801;
    _ns_tok_63801 = _54keyfind(_ns_63797, -1LL, _file_63791, 1LL, _31282);
    DeRef(_0);
    _31282 = NOVALUE;

    /** fwdref.e:714			if ns_tok[T_ID] != NAMESPACE then*/
    _2 = (object)SEQ_PTR(_ns_tok_63801);
    _31284 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _31284, 523LL)){
        _31284 = NOVALUE;
        goto L2; // [69] 80
    }
    _31284 = NOVALUE;

    /** fwdref.e:715				return ns_tok*/
    DeRefDS(_ns_63797);
    DeRefDS(_fr_63788);
    DeRefDS(_name_63789);
    DeRef(_tok_63813);
    _31280 = NOVALUE;
    return _ns_tok_63801;
L2: 
    DeRef(_ns_63797);
    _ns_63797 = NOVALUE;
    DeRef(_ns_tok_63801);
    _ns_tok_63801 = NOVALUE;
    goto L3; // [82] 92
L1: 

    /** fwdref.e:718			ns_file = fr[FR_QUALIFIED]*/
    _2 = (object)SEQ_PTR(_fr_63788);
    _ns_file_63793 = (object)*(((s1_ptr)_2)->base + 9LL);
    if (!IS_ATOM_INT(_ns_file_63793))
    _ns_file_63793 = (object)DBL_PTR(_ns_file_63793)->dbl;
L3: 

    /** fwdref.e:721		No_new_entry = 1*/
    _54No_new_entry_47974 = 1LL;

    /** fwdref.e:722		object tok = keyfind( name, ns_file, file, , fr[FR_HASHVAL] )*/
    _2 = (object)SEQ_PTR(_fr_63788);
    _31287 = (object)*(((s1_ptr)_2)->base + 11LL);
    RefDS(_name_63789);
    Ref(_31287);
    _0 = _tok_63813;
    _tok_63813 = _54keyfind(_name_63789, _ns_file_63793, _file_63791, 0LL, _31287);
    DeRef(_0);
    _31287 = NOVALUE;

    /** fwdref.e:723		No_new_entry = 0*/
    _54No_new_entry_47974 = 0LL;

    /** fwdref.e:724		return tok*/
    DeRefDS(_fr_63788);
    DeRefDS(_name_63789);
    DeRef(_31280);
    _31280 = NOVALUE;
    return _tok_63813;
    ;
}


void _44register_forward_type(object _sym_63821, object _ref_63822)
{
    object _31294 = NOVALUE;
    object _31293 = NOVALUE;
    object _31291 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:729		if ref < 0 then*/
    if (_ref_63822 >= 0LL)
    goto L1; // [7] 19

    /** fwdref.e:730			ref = -ref*/
    _ref_63822 = - _ref_63822;
L1: 

    /** fwdref.e:732		forward_references[ref][FR_DATA] &= sym*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62765 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63822 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _31293 = (object)*(((s1_ptr)_2)->base + 12LL);
    _31291 = NOVALUE;
    if (IS_SEQUENCE(_31293) && IS_ATOM(_sym_63821)) {
        Append(&_31294, _31293, _sym_63821);
    }
    else if (IS_ATOM(_31293) && IS_SEQUENCE(_sym_63821)) {
    }
    else {
        Concat((object_ptr)&_31294, _31293, _sym_63821);
        _31293 = NOVALUE;
    }
    _31293 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31294;
    if( _1 != _31294 ){
        DeRef(_1);
    }
    _31294 = NOVALUE;
    _31291 = NOVALUE;

    /** fwdref.e:733	end procedure*/
    return;
    ;
}


object _44new_forward_reference(object _fwd_op_63852, object _sym_63854, object _op_63855)
{
    object _ref_63856 = NOVALUE;
    object _len_63857 = NOVALUE;
    object _hashval_63887 = NOVALUE;
    object _default_sym_63962 = NOVALUE;
    object _param_63965 = NOVALUE;
    object _set_data_2__tmp_at578_63982 = NOVALUE;
    object _set_data_1__tmp_at578_63981 = NOVALUE;
    object _data_inlined_set_data_at_575_63980 = NOVALUE;
    object _31380 = NOVALUE;
    object _31379 = NOVALUE;
    object _31378 = NOVALUE;
    object _31375 = NOVALUE;
    object _31373 = NOVALUE;
    object _31372 = NOVALUE;
    object _31370 = NOVALUE;
    object _31369 = NOVALUE;
    object _31368 = NOVALUE;
    object _31366 = NOVALUE;
    object _31364 = NOVALUE;
    object _31362 = NOVALUE;
    object _31359 = NOVALUE;
    object _31358 = NOVALUE;
    object _31356 = NOVALUE;
    object _31354 = NOVALUE;
    object _31352 = NOVALUE;
    object _31350 = NOVALUE;
    object _31349 = NOVALUE;
    object _31348 = NOVALUE;
    object _31346 = NOVALUE;
    object _31343 = NOVALUE;
    object _31341 = NOVALUE;
    object _31339 = NOVALUE;
    object _31338 = NOVALUE;
    object _31337 = NOVALUE;
    object _31336 = NOVALUE;
    object _31334 = NOVALUE;
    object _31331 = NOVALUE;
    object _31330 = NOVALUE;
    object _31329 = NOVALUE;
    object _31327 = NOVALUE;
    object _31326 = NOVALUE;
    object _31325 = NOVALUE;
    object _31324 = NOVALUE;
    object _31322 = NOVALUE;
    object _31321 = NOVALUE;
    object _31320 = NOVALUE;
    object _31319 = NOVALUE;
    object _31317 = NOVALUE;
    object _31314 = NOVALUE;
    object _31313 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_63854)) {
        _1 = (object)(DBL_PTR(_sym_63854)->dbl);
        DeRefDS(_sym_63854);
        _sym_63854 = _1;
    }

    /** fwdref.e:754			len = length( inactive_references )*/
    if (IS_SEQUENCE(_44inactive_references_62769)){
            _len_63857 = SEQ_PTR(_44inactive_references_62769)->length;
    }
    else {
        _len_63857 = 1;
    }

    /** fwdref.e:757		if len then*/
    if (_len_63857 == 0)
    {
        goto L1; // [16] 39
    }
    else{
    }

    /** fwdref.e:758			ref = inactive_references[len]*/
    _2 = (object)SEQ_PTR(_44inactive_references_62769);
    _ref_63856 = (object)*(((s1_ptr)_2)->base + _len_63857);
    if (!IS_ATOM_INT(_ref_63856))
    _ref_63856 = (object)DBL_PTR(_ref_63856)->dbl;

    /** fwdref.e:759			inactive_references = remove( inactive_references, len, len )*/
    {
        s1_ptr assign_space = SEQ_PTR(_44inactive_references_62769);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_len_63857)) ? _len_63857 : (object)(DBL_PTR(_len_63857)->dbl);
        int stop = (IS_ATOM_INT(_len_63857)) ? _len_63857 : (object)(DBL_PTR(_len_63857)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_44inactive_references_62769), start, &_44inactive_references_62769 );
            }
            else Tail(SEQ_PTR(_44inactive_references_62769), stop+1, &_44inactive_references_62769);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_44inactive_references_62769), start, &_44inactive_references_62769);
        }
        else {
            assign_slice_seq = &assign_space;
            _44inactive_references_62769 = Remove_elements(start, stop, (SEQ_PTR(_44inactive_references_62769)->ref == 1));
        }
    }
    goto L2; // [36] 55
L1: 

    /** fwdref.e:761			forward_references &= 0*/
    Append(&_44forward_references_62765, _44forward_references_62765, 0LL);

    /** fwdref.e:762			ref = length( forward_references )*/
    if (IS_SEQUENCE(_44forward_references_62765)){
            _ref_63856 = SEQ_PTR(_44forward_references_62765)->length;
    }
    else {
        _ref_63856 = 1;
    }
L2: 

    /** fwdref.e:764		forward_references[ref] = repeat( 0, FR_SIZE )*/
    _31313 = Repeat(0LL, 12LL);
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62765 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _ref_63856);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31313;
    if( _1 != _31313 ){
        DeRef(_1);
    }
    _31313 = NOVALUE;

    /** fwdref.e:766		forward_references[ref][FR_TYPE]      = fwd_op*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62765 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63856 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _fwd_op_63852;
    DeRef(_1);
    _31314 = NOVALUE;

    /** fwdref.e:767		if sym < 0 then*/
    if (_sym_63854 >= 0LL)
    goto L3; // [84] 143

    /** fwdref.e:768			forward_references[ref][FR_NAME] = forward_references[-sym][FR_NAME]*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62765 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63856 + ((s1_ptr)_2)->base);
    if ((uintptr_t)_sym_63854 == (uintptr_t)HIGH_BITS){
        _31319 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31319 = - _sym_63854;
    }
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    if (!IS_ATOM_INT(_31319)){
        _31320 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31319)->dbl));
    }
    else{
        _31320 = (object)*(((s1_ptr)_2)->base + _31319);
    }
    _2 = (object)SEQ_PTR(_31320);
    _31321 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31320 = NOVALUE;
    Ref(_31321);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31321;
    if( _1 != _31321 ){
        DeRef(_1);
    }
    _31321 = NOVALUE;
    _31317 = NOVALUE;

    /** fwdref.e:769			forward_references[ref][FR_HASHVAL] = forward_references[-sym][FR_HASHVAL]*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62765 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63856 + ((s1_ptr)_2)->base);
    if ((uintptr_t)_sym_63854 == (uintptr_t)HIGH_BITS){
        _31324 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31324 = - _sym_63854;
    }
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    if (!IS_ATOM_INT(_31324)){
        _31325 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31324)->dbl));
    }
    else{
        _31325 = (object)*(((s1_ptr)_2)->base + _31324);
    }
    _2 = (object)SEQ_PTR(_31325);
    _31326 = (object)*(((s1_ptr)_2)->base + 11LL);
    _31325 = NOVALUE;
    Ref(_31326);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31326;
    if( _1 != _31326 ){
        DeRef(_1);
    }
    _31326 = NOVALUE;
    _31322 = NOVALUE;
    goto L4; // [140] 242
L3: 

    /** fwdref.e:771			forward_references[ref][FR_NAME] = SymTab[sym][S_NAME]*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62765 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63856 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31329 = (object)*(((s1_ptr)_2)->base + _sym_63854);
    _2 = (object)SEQ_PTR(_31329);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _31330 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _31330 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _31329 = NOVALUE;
    Ref(_31330);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31330;
    if( _1 != _31330 ){
        DeRef(_1);
    }
    _31330 = NOVALUE;
    _31327 = NOVALUE;

    /** fwdref.e:772			integer hashval = SymTab[sym][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31331 = (object)*(((s1_ptr)_2)->base + _sym_63854);
    _2 = (object)SEQ_PTR(_31331);
    _hashval_63887 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (!IS_ATOM_INT(_hashval_63887)){
        _hashval_63887 = (object)DBL_PTR(_hashval_63887)->dbl;
    }
    _31331 = NOVALUE;

    /** fwdref.e:773			if 0 = hashval then*/
    if (0LL != _hashval_63887)
    goto L5; // [186] 220

    /** fwdref.e:774				forward_references[ref][FR_HASHVAL] = hashfn( forward_references[ref][FR_NAME] )*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62765 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63856 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    _31336 = (object)*(((s1_ptr)_2)->base + _ref_63856);
    _2 = (object)SEQ_PTR(_31336);
    _31337 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31336 = NOVALUE;
    Ref(_31337);
    _31338 = _54hashfn(_31337);
    _31337 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31338;
    if( _1 != _31338 ){
        DeRef(_1);
    }
    _31338 = NOVALUE;
    _31334 = NOVALUE;
    goto L6; // [217] 239
L5: 

    /** fwdref.e:776				forward_references[ref][FR_HASHVAL] = hashval*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62765 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63856 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _hashval_63887;
    DeRef(_1);
    _31339 = NOVALUE;

    /** fwdref.e:777				remove_symbol( sym )*/
    _54remove_symbol(_sym_63854);
L6: 
L4: 

    /** fwdref.e:782		forward_references[ref][FR_FILE]      = current_file_no*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62765 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63856 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36current_file_no_21439;
    DeRef(_1);
    _31341 = NOVALUE;

    /** fwdref.e:783		forward_references[ref][FR_SUBPROG]   = CurrentSub*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62765 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63856 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36CurrentSub_21447;
    DeRef(_1);
    _31343 = NOVALUE;

    /** fwdref.e:785		if fwd_op != TYPE then*/
    if (_fwd_op_63852 == 504LL)
    goto L7; // [276] 303

    /** fwdref.e:786			forward_references[ref][FR_PC]        = length( Code ) + 1*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62765 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63856 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_36Code_21531)){
            _31348 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _31348 = 1;
    }
    _31349 = _31348 + 1;
    _31348 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31349;
    if( _1 != _31349 ){
        DeRef(_1);
    }
    _31349 = NOVALUE;
    _31346 = NOVALUE;
L7: 

    /** fwdref.e:789		forward_references[ref][FR_LINE]      = fwd_line_number*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62765 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63856 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36fwd_line_number_21441;
    DeRef(_1);
    _31350 = NOVALUE;

    /** fwdref.e:790		forward_references[ref][FR_THISLINE]  = ForwardLine*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62765 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63856 + ((s1_ptr)_2)->base);
    Ref(_50ForwardLine_49235);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 7LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _50ForwardLine_49235;
    DeRef(_1);
    _31352 = NOVALUE;

    /** fwdref.e:791		forward_references[ref][FR_BP]        = forward_bp*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62765 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63856 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 8LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _50forward_bp_49239;
    DeRef(_1);
    _31354 = NOVALUE;

    /** fwdref.e:792		forward_references[ref][FR_QUALIFIED] = get_qualified_fwd()*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62765 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63856 + ((s1_ptr)_2)->base);
    _31358 = _62get_qualified_fwd();
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31358;
    if( _1 != _31358 ){
        DeRef(_1);
    }
    _31358 = NOVALUE;
    _31356 = NOVALUE;

    /** fwdref.e:793		forward_references[ref][FR_OP]        = op*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62765 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63856 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _op_63855;
    DeRef(_1);
    _31359 = NOVALUE;

    /** fwdref.e:795		if op = GOTO then*/
    if (_op_63855 != 188LL)
    goto L8; // [381] 403

    /** fwdref.e:796			forward_references[ref][FR_DATA] = { sym }*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62765 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63856 + ((s1_ptr)_2)->base);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _sym_63854;
    _31364 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31364;
    if( _1 != _31364 ){
        DeRef(_1);
    }
    _31364 = NOVALUE;
    _31362 = NOVALUE;
L8: 

    /** fwdref.e:803		if CurrentSub = TopLevelSub then*/
    if (_36CurrentSub_21447 != _36TopLevelSub_21446)
    goto L9; // [409] 471

    /** fwdref.e:804			if length( toplevel_references ) < current_file_no then*/
    if (IS_SEQUENCE(_44toplevel_references_62768)){
            _31366 = SEQ_PTR(_44toplevel_references_62768)->length;
    }
    else {
        _31366 = 1;
    }
    if (_31366 >= _36current_file_no_21439)
    goto LA; // [422] 450

    /** fwdref.e:805				toplevel_references &= repeat( {}, current_file_no - length( toplevel_references ) )*/
    if (IS_SEQUENCE(_44toplevel_references_62768)){
            _31368 = SEQ_PTR(_44toplevel_references_62768)->length;
    }
    else {
        _31368 = 1;
    }
    _31369 = _36current_file_no_21439 - _31368;
    _31368 = NOVALUE;
    _31370 = Repeat(_21993, _31369);
    _31369 = NOVALUE;
    Concat((object_ptr)&_44toplevel_references_62768, _44toplevel_references_62768, _31370);
    DeRefDS(_31370);
    _31370 = NOVALUE;
LA: 

    /** fwdref.e:807			toplevel_references[current_file_no] &= ref*/
    _2 = (object)SEQ_PTR(_44toplevel_references_62768);
    _31372 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
    if (IS_SEQUENCE(_31372) && IS_ATOM(_ref_63856)) {
        Append(&_31373, _31372, _ref_63856);
    }
    else if (IS_ATOM(_31372) && IS_SEQUENCE(_ref_63856)) {
    }
    else {
        Concat((object_ptr)&_31373, _31372, _ref_63856);
        _31372 = NOVALUE;
    }
    _31372 = NOVALUE;
    _2 = (object)SEQ_PTR(_44toplevel_references_62768);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44toplevel_references_62768 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21439);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31373;
    if( _1 != _31373 ){
        DeRef(_1);
    }
    _31373 = NOVALUE;
    goto LB; // [468] 595
L9: 

    /** fwdref.e:809			add_active_reference( ref )*/
    _44add_active_reference(_ref_63856, _36current_file_no_21439);

    /** fwdref.e:811			if Parser_mode = PAM_RECORD then*/
    if (_36Parser_mode_21548 != 1LL)
    goto LC; // [485] 592

    /** fwdref.e:812				symtab_pointer default_sym = CurrentSub*/
    _default_sym_63962 = _36CurrentSub_21447;

    /** fwdref.e:813				symtab_pointer param = 0*/
    _param_63965 = 0LL;

    /** fwdref.e:814				while default_sym with entry do*/
    goto LD; // [507] 536
LE: 
    if (_default_sym_63962 == 0)
    {
        goto LF; // [510] 549
    }
    else{
    }

    /** fwdref.e:815					if sym_scope( default_sym ) = SC_PRIVATE then*/
    _31375 = _54sym_scope(_default_sym_63962);
    if (binary_op_a(NOTEQ, _31375, 3LL)){
        DeRef(_31375);
        _31375 = NOVALUE;
        goto L10; // [521] 533
    }
    DeRef(_31375);
    _31375 = NOVALUE;

    /** fwdref.e:816						param = default_sym*/
    _param_63965 = _default_sym_63962;
L10: 

    /** fwdref.e:818				entry*/
LD: 

    /** fwdref.e:819					default_sym = sym_next( default_sym )*/
    _default_sym_63962 = _54sym_next(_default_sym_63962);
    if (!IS_ATOM_INT(_default_sym_63962)) {
        _1 = (object)(DBL_PTR(_default_sym_63962)->dbl);
        DeRefDS(_default_sym_63962);
        _default_sym_63962 = _1;
    }

    /** fwdref.e:820				end while*/
    goto LE; // [546] 510
LF: 

    /** fwdref.e:821				set_data( ref, {{ PAM_RECORD, param, length( Recorded_sym ) }} )*/
    if (IS_SEQUENCE(_36Recorded_sym_21551)){
            _31378 = SEQ_PTR(_36Recorded_sym_21551)->length;
    }
    else {
        _31378 = 1;
    }
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = _param_63965;
    ((intptr_t*)_2)[3] = _31378;
    _31379 = MAKE_SEQ(_1);
    _31378 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _31379;
    _31380 = MAKE_SEQ(_1);
    _31379 = NOVALUE;
    DeRef(_data_inlined_set_data_at_575_63980);
    _data_inlined_set_data_at_575_63980 = _31380;
    _31380 = NOVALUE;

    /** fwdref.e:186		forward_references[ref][FR_DATA] = data*/
    _2 = (object)SEQ_PTR(_44forward_references_62765);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_62765 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63856 + ((s1_ptr)_2)->base);
    RefDS(_data_inlined_set_data_at_575_63980);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _data_inlined_set_data_at_575_63980;
    DeRef(_1);

    /** fwdref.e:187	end procedure*/
    goto L11; // [586] 589
L11: 
    DeRef(_data_inlined_set_data_at_575_63980);
    _data_inlined_set_data_at_575_63980 = NOVALUE;
LC: 
LB: 

    /** fwdref.e:824		fwdref_count += 1*/
    _44fwdref_count_62785 = _44fwdref_count_62785 + 1;

    /** fwdref.e:826		ifdef EUDIS then*/

    /** fwdref.e:839		return ref*/
    DeRef(_31324);
    _31324 = NOVALUE;
    DeRef(_31319);
    _31319 = NOVALUE;
    return _ref_63856;
    ;
}


void _44add_active_reference(object _ref_63986, object _file_no_63987)
{
    object _sp_64001 = NOVALUE;
    object _31404 = NOVALUE;
    object _31403 = NOVALUE;
    object _31401 = NOVALUE;
    object _31400 = NOVALUE;
    object _31399 = NOVALUE;
    object _31397 = NOVALUE;
    object _31396 = NOVALUE;
    object _31395 = NOVALUE;
    object _31392 = NOVALUE;
    object _31390 = NOVALUE;
    object _31389 = NOVALUE;
    object _31388 = NOVALUE;
    object _31386 = NOVALUE;
    object _31385 = NOVALUE;
    object _31384 = NOVALUE;
    object _31382 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:843		if length( active_references ) < file_no then*/
    if (IS_SEQUENCE(_44active_references_62767)){
            _31382 = SEQ_PTR(_44active_references_62767)->length;
    }
    else {
        _31382 = 1;
    }
    if (_31382 >= _file_no_63987)
    goto L1; // [12] 59

    /** fwdref.e:844			active_references &= repeat( {}, file_no - length( active_references ) )*/
    if (IS_SEQUENCE(_44active_references_62767)){
            _31384 = SEQ_PTR(_44active_references_62767)->length;
    }
    else {
        _31384 = 1;
    }
    _31385 = _file_no_63987 - _31384;
    _31384 = NOVALUE;
    _31386 = Repeat(_21993, _31385);
    _31385 = NOVALUE;
    Concat((object_ptr)&_44active_references_62767, _44active_references_62767, _31386);
    DeRefDS(_31386);
    _31386 = NOVALUE;

    /** fwdref.e:845			active_subprogs   &= repeat( {}, file_no - length( active_subprogs ) )*/
    if (IS_SEQUENCE(_44active_subprogs_62766)){
            _31388 = SEQ_PTR(_44active_subprogs_62766)->length;
    }
    else {
        _31388 = 1;
    }
    _31389 = _file_no_63987 - _31388;
    _31388 = NOVALUE;
    _31390 = Repeat(_21993, _31389);
    _31389 = NOVALUE;
    Concat((object_ptr)&_44active_subprogs_62766, _44active_subprogs_62766, _31390);
    DeRefDS(_31390);
    _31390 = NOVALUE;
L1: 

    /** fwdref.e:847		integer sp = find( CurrentSub, active_subprogs[file_no] )*/
    _2 = (object)SEQ_PTR(_44active_subprogs_62766);
    _31392 = (object)*(((s1_ptr)_2)->base + _file_no_63987);
    _sp_64001 = find_from(_36CurrentSub_21447, _31392, 1LL);
    _31392 = NOVALUE;

    /** fwdref.e:848		if not sp then*/
    if (_sp_64001 != 0)
    goto L2; // [76] 127

    /** fwdref.e:849			active_subprogs[file_no] &= CurrentSub*/
    _2 = (object)SEQ_PTR(_44active_subprogs_62766);
    _31395 = (object)*(((s1_ptr)_2)->base + _file_no_63987);
    if (IS_SEQUENCE(_31395) && IS_ATOM(_36CurrentSub_21447)) {
        Append(&_31396, _31395, _36CurrentSub_21447);
    }
    else if (IS_ATOM(_31395) && IS_SEQUENCE(_36CurrentSub_21447)) {
    }
    else {
        Concat((object_ptr)&_31396, _31395, _36CurrentSub_21447);
        _31395 = NOVALUE;
    }
    _31395 = NOVALUE;
    _2 = (object)SEQ_PTR(_44active_subprogs_62766);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_subprogs_62766 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_no_63987);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31396;
    if( _1 != _31396 ){
        DeRef(_1);
    }
    _31396 = NOVALUE;

    /** fwdref.e:850			sp = length( active_subprogs[file_no] )*/
    _2 = (object)SEQ_PTR(_44active_subprogs_62766);
    _31397 = (object)*(((s1_ptr)_2)->base + _file_no_63987);
    if (IS_SEQUENCE(_31397)){
            _sp_64001 = SEQ_PTR(_31397)->length;
    }
    else {
        _sp_64001 = 1;
    }
    _31397 = NOVALUE;

    /** fwdref.e:852			active_references[file_no] = append( active_references[file_no], {} )*/
    _2 = (object)SEQ_PTR(_44active_references_62767);
    _31399 = (object)*(((s1_ptr)_2)->base + _file_no_63987);
    RefDS(_21993);
    Append(&_31400, _31399, _21993);
    _31399 = NOVALUE;
    _2 = (object)SEQ_PTR(_44active_references_62767);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_references_62767 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_no_63987);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31400;
    if( _1 != _31400 ){
        DeRef(_1);
    }
    _31400 = NOVALUE;
L2: 

    /** fwdref.e:854		active_references[file_no][sp] &= ref*/
    _2 = (object)SEQ_PTR(_44active_references_62767);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_references_62767 = MAKE_SEQ(_2);
    }
    _3 = (object)(_file_no_63987 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _31403 = (object)*(((s1_ptr)_2)->base + _sp_64001);
    _31401 = NOVALUE;
    if (IS_SEQUENCE(_31403) && IS_ATOM(_ref_63986)) {
        Append(&_31404, _31403, _ref_63986);
    }
    else if (IS_ATOM(_31403) && IS_SEQUENCE(_ref_63986)) {
    }
    else {
        Concat((object_ptr)&_31404, _31403, _ref_63986);
        _31403 = NOVALUE;
    }
    _31403 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _sp_64001);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31404;
    if( _1 != _31404 ){
        DeRef(_1);
    }
    _31404 = NOVALUE;
    _31401 = NOVALUE;

    /** fwdref.e:855	end procedure*/
    _31397 = NOVALUE;
    return;
    ;
}


object _44resolve_file(object _refs_64038, object _report_errors_64039, object _unincluded_ok_64040)
{
    object _errors_64041 = NOVALUE;
    object _ref_64045 = NOVALUE;
    object _fr_64047 = NOVALUE;
    object _tok_64060 = NOVALUE;
    object _code_sub_64068 = NOVALUE;
    object _fr_type_64070 = NOVALUE;
    object _sym_tok_64072 = NOVALUE;
    object _31458 = NOVALUE;
    object _31457 = NOVALUE;
    object _31456 = NOVALUE;
    object _31455 = NOVALUE;
    object _31454 = NOVALUE;
    object _31453 = NOVALUE;
    object _31448 = NOVALUE;
    object _31447 = NOVALUE;
    object _31446 = NOVALUE;
    object _31444 = NOVALUE;
    object _31443 = NOVALUE;
    object _31440 = NOVALUE;
    object _31439 = NOVALUE;
    object _31438 = NOVALUE;
    object _31434 = NOVALUE;
    object _31433 = NOVALUE;
    object _31425 = NOVALUE;
    object _31423 = NOVALUE;
    object _31422 = NOVALUE;
    object _31421 = NOVALUE;
    object _31420 = NOVALUE;
    object _31419 = NOVALUE;
    object _31418 = NOVALUE;
    object _31415 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:864		sequence errors = {}*/
    RefDS(_21993);
    DeRefi(_errors_64041);
    _errors_64041 = _21993;

    /** fwdref.e:865		for ar = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_64038)){
            _31415 = SEQ_PTR(_refs_64038)->length;
    }
    else {
        _31415 = 1;
    }
    {
        object _ar_64043;
        _ar_64043 = _31415;
L1: 
        if (_ar_64043 < 1LL){
            goto L2; // [19] 481
        }

        /** fwdref.e:866			integer ref = refs[ar]*/
        _2 = (object)SEQ_PTR(_refs_64038);
        _ref_64045 = (object)*(((s1_ptr)_2)->base + _ar_64043);
        if (!IS_ATOM_INT(_ref_64045))
        _ref_64045 = (object)DBL_PTR(_ref_64045)->dbl;

        /** fwdref.e:868			sequence fr = forward_references[ref]*/
        DeRef(_fr_64047);
        _2 = (object)SEQ_PTR(_44forward_references_62765);
        _fr_64047 = (object)*(((s1_ptr)_2)->base + _ref_64045);
        Ref(_fr_64047);

        /** fwdref.e:869			if include_matrix[fr[FR_FILE]][current_file_no] = NOT_INCLUDED and not unincluded_ok then*/
        _2 = (object)SEQ_PTR(_fr_64047);
        _31418 = (object)*(((s1_ptr)_2)->base + 3LL);
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        if (!IS_ATOM_INT(_31418)){
            _31419 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31418)->dbl));
        }
        else{
            _31419 = (object)*(((s1_ptr)_2)->base + _31418);
        }
        _2 = (object)SEQ_PTR(_31419);
        _31420 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
        _31419 = NOVALUE;
        if (IS_ATOM_INT(_31420)) {
            _31421 = (_31420 == 0LL);
        }
        else {
            _31421 = binary_op(EQUALS, _31420, 0LL);
        }
        _31420 = NOVALUE;
        if (IS_ATOM_INT(_31421)) {
            if (_31421 == 0) {
                goto L3; // [66] 84
            }
        }
        else {
            if (DBL_PTR(_31421)->dbl == 0.0) {
                goto L3; // [66] 84
            }
        }
        _31423 = (_unincluded_ok_64040 == 0);
        if (_31423 == 0)
        {
            DeRef(_31423);
            _31423 = NOVALUE;
            goto L3; // [74] 84
        }
        else{
            DeRef(_31423);
            _31423 = NOVALUE;
        }

        /** fwdref.e:870				continue*/
        DeRef(_fr_64047);
        _fr_64047 = NOVALUE;
        DeRef(_tok_64060);
        _tok_64060 = NOVALUE;
        goto L4; // [81] 476
L3: 

        /** fwdref.e:873			token tok = find_reference( fr )*/
        RefDS(_fr_64047);
        _0 = _tok_64060;
        _tok_64060 = _44find_reference(_fr_64047);
        DeRef(_0);

        /** fwdref.e:874			if tok[T_ID] = IGNORED then*/
        _2 = (object)SEQ_PTR(_tok_64060);
        _31425 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _31425, 509LL)){
            _31425 = NOVALUE;
            goto L5; // [100] 117
        }
        _31425 = NOVALUE;

        /** fwdref.e:875				errors &= ref*/
        Append(&_errors_64041, _errors_64041, _ref_64045);

        /** fwdref.e:876				continue*/
        DeRefDS(_fr_64047);
        _fr_64047 = NOVALUE;
        DeRef(_tok_64060);
        _tok_64060 = NOVALUE;
        goto L4; // [114] 476
L5: 

        /** fwdref.e:880			integer code_sub = fr[FR_SUBPROG]*/
        _2 = (object)SEQ_PTR(_fr_64047);
        _code_sub_64068 = (object)*(((s1_ptr)_2)->base + 4LL);
        if (!IS_ATOM_INT(_code_sub_64068))
        _code_sub_64068 = (object)DBL_PTR(_code_sub_64068)->dbl;

        /** fwdref.e:881			integer fr_type  = fr[FR_TYPE]*/
        _2 = (object)SEQ_PTR(_fr_64047);
        _fr_type_64070 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (!IS_ATOM_INT(_fr_type_64070))
        _fr_type_64070 = (object)DBL_PTR(_fr_type_64070)->dbl;

        /** fwdref.e:882			integer sym_tok*/

        /** fwdref.e:884			switch fr_type label "fr_type" do*/
        _0 = _fr_type_64070;
        switch ( _0 ){ 

            /** fwdref.e:885				case PROC, FUNC then*/
            case 27:
            case 501:

            /** fwdref.e:887					sym_tok = SymTab[tok[T_SYM]][S_TOKEN]*/
            _2 = (object)SEQ_PTR(_tok_64060);
            _31433 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            if (!IS_ATOM_INT(_31433)){
                _31434 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31433)->dbl));
            }
            else{
                _31434 = (object)*(((s1_ptr)_2)->base + _31433);
            }
            _2 = (object)SEQ_PTR(_31434);
            if (!IS_ATOM_INT(_36S_TOKEN_21081)){
                _sym_tok_64072 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
            }
            else{
                _sym_tok_64072 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
            }
            if (!IS_ATOM_INT(_sym_tok_64072)){
                _sym_tok_64072 = (object)DBL_PTR(_sym_tok_64072)->dbl;
            }
            _31434 = NOVALUE;

            /** fwdref.e:888					if sym_tok = TYPE then*/
            if (_sym_tok_64072 != 504LL)
            goto L6; // [170] 184

            /** fwdref.e:889						sym_tok = FUNC*/
            _sym_tok_64072 = 501LL;
L6: 

            /** fwdref.e:891					if sym_tok != fr_type then*/
            if (_sym_tok_64072 == _fr_type_64070)
            goto L7; // [186] 220

            /** fwdref.e:892						if sym_tok != FUNC and fr_type != PROC then*/
            _31438 = (_sym_tok_64072 != 501LL);
            if (_31438 == 0) {
                goto L8; // [198] 219
            }
            _31440 = (_fr_type_64070 != 27LL);
            if (_31440 == 0)
            {
                DeRef(_31440);
                _31440 = NOVALUE;
                goto L8; // [209] 219
            }
            else{
                DeRef(_31440);
                _31440 = NOVALUE;
            }

            /** fwdref.e:893							forward_error( tok, ref )*/
            Ref(_tok_64060);
            _44forward_error(_tok_64060, _ref_64045);
L8: 
L7: 

            /** fwdref.e:896					switch sym_tok do*/
            _0 = _sym_tok_64072;
            switch ( _0 ){ 

                /** fwdref.e:897						case PROC, FUNC then*/
                case 27:
                case 501:

                /** fwdref.e:898							patch_forward_call( tok, ref )*/
                Ref(_tok_64060);
                _44patch_forward_call(_tok_64060, _ref_64045);

                /** fwdref.e:899							break "fr_type"*/
                goto L9; // [241] 446
                goto L9; // [243] 446

                /** fwdref.e:901						case else*/
                default:

                /** fwdref.e:902							forward_error( tok, ref )*/
                Ref(_tok_64060);
                _44forward_error(_tok_64060, _ref_64045);
            ;}            goto L9; // [256] 446

            /** fwdref.e:906				case VARIABLE then*/
            case -100:

            /** fwdref.e:907					sym_tok = SymTab[tok[T_SYM]][S_TOKEN]*/
            _2 = (object)SEQ_PTR(_tok_64060);
            _31443 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            if (!IS_ATOM_INT(_31443)){
                _31444 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31443)->dbl));
            }
            else{
                _31444 = (object)*(((s1_ptr)_2)->base + _31443);
            }
            _2 = (object)SEQ_PTR(_31444);
            if (!IS_ATOM_INT(_36S_TOKEN_21081)){
                _sym_tok_64072 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
            }
            else{
                _sym_tok_64072 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
            }
            if (!IS_ATOM_INT(_sym_tok_64072)){
                _sym_tok_64072 = (object)DBL_PTR(_sym_tok_64072)->dbl;
            }
            _31444 = NOVALUE;

            /** fwdref.e:908					if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
            _2 = (object)SEQ_PTR(_tok_64060);
            _31446 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            if (!IS_ATOM_INT(_31446)){
                _31447 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31446)->dbl));
            }
            else{
                _31447 = (object)*(((s1_ptr)_2)->base + _31446);
            }
            _2 = (object)SEQ_PTR(_31447);
            _31448 = (object)*(((s1_ptr)_2)->base + 4LL);
            _31447 = NOVALUE;
            if (binary_op_a(NOTEQ, _31448, 9LL)){
                _31448 = NOVALUE;
                goto LA; // [306] 323
            }
            _31448 = NOVALUE;

            /** fwdref.e:909						errors &= ref*/
            Append(&_errors_64041, _errors_64041, _ref_64045);

            /** fwdref.e:910						continue*/
            DeRef(_fr_64047);
            _fr_64047 = NOVALUE;
            DeRef(_tok_64060);
            _tok_64060 = NOVALUE;
            goto L4; // [320] 476
LA: 

            /** fwdref.e:913					switch sym_tok do*/
            _0 = _sym_tok_64072;
            switch ( _0 ){ 

                /** fwdref.e:914						case CONSTANT, ENUM, VARIABLE then*/
                case 417:
                case 427:
                case -100:

                /** fwdref.e:915							patch_forward_variable( tok, ref )*/
                Ref(_tok_64060);
                _44patch_forward_variable(_tok_64060, _ref_64045);

                /** fwdref.e:916							break "fr_type"*/
                goto L9; // [346] 446
                goto L9; // [348] 446

                /** fwdref.e:917						case else*/
                default:

                /** fwdref.e:918							forward_error( tok, ref )*/
                Ref(_tok_64060);
                _44forward_error(_tok_64060, _ref_64045);
            ;}            goto L9; // [361] 446

            /** fwdref.e:921				case TYPE_CHECK then*/
            case 65:

            /** fwdref.e:922					patch_forward_type_check( tok, ref )*/
            Ref(_tok_64060);
            _44patch_forward_type_check(_tok_64060, _ref_64045);
            goto L9; // [373] 446

            /** fwdref.e:924				case GLOBAL_INIT_CHECK then*/
            case 109:

            /** fwdref.e:925					patch_forward_init_check( tok, ref )*/
            Ref(_tok_64060);
            _44patch_forward_init_check(_tok_64060, _ref_64045);
            goto L9; // [385] 446

            /** fwdref.e:927				case CASE then*/
            case 186:

            /** fwdref.e:928					patch_forward_case( tok, ref )*/
            Ref(_tok_64060);
            _44patch_forward_case(_tok_64060, _ref_64045);
            goto L9; // [397] 446

            /** fwdref.e:930				case TYPE then*/
            case 504:

            /** fwdref.e:931					patch_forward_type( tok, ref )*/
            Ref(_tok_64060);
            _44patch_forward_type(_tok_64060, _ref_64045);
            goto L9; // [409] 446

            /** fwdref.e:933				case GOTO then*/
            case 188:

            /** fwdref.e:934					patch_forward_goto( tok, ref )*/
            Ref(_tok_64060);
            _44patch_forward_goto(_tok_64060, _ref_64045);
            goto L9; // [421] 446

            /** fwdref.e:936				case else*/
            default:

            /** fwdref.e:938					InternalErr( 263, {fr[FR_TYPE], fr[FR_NAME]})*/
            _2 = (object)SEQ_PTR(_fr_64047);
            _31453 = (object)*(((s1_ptr)_2)->base + 1LL);
            _2 = (object)SEQ_PTR(_fr_64047);
            _31454 = (object)*(((s1_ptr)_2)->base + 2LL);
            Ref(_31454);
            Ref(_31453);
            _1 = NewS1(2);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t *)_2)[1] = _31453;
            ((intptr_t *)_2)[2] = _31454;
            _31455 = MAKE_SEQ(_1);
            _31454 = NOVALUE;
            _31453 = NOVALUE;
            _50InternalErr(263LL, _31455);
            _31455 = NOVALUE;
        ;}L9: 

        /** fwdref.e:940			if report_errors and sequence( forward_references[ref] ) then*/
        if (_report_errors_64039 == 0) {
            goto LB; // [448] 472
        }
        _2 = (object)SEQ_PTR(_44forward_references_62765);
        _31457 = (object)*(((s1_ptr)_2)->base + _ref_64045);
        _31458 = IS_SEQUENCE(_31457);
        _31457 = NOVALUE;
        if (_31458 == 0)
        {
            _31458 = NOVALUE;
            goto LB; // [462] 472
        }
        else{
            _31458 = NOVALUE;
        }

        /** fwdref.e:941				errors &= ref*/
        Append(&_errors_64041, _errors_64041, _ref_64045);
LB: 
        DeRef(_fr_64047);
        _fr_64047 = NOVALUE;
        DeRef(_tok_64060);
        _tok_64060 = NOVALUE;

        /** fwdref.e:944		end for*/
L4: 
        _ar_64043 = _ar_64043 + -1LL;
        goto L1; // [476] 26
L2: 
        ;
    }

    /** fwdref.e:945		return errors*/
    DeRefDS(_refs_64038);
    DeRef(_31438);
    _31438 = NOVALUE;
    _31446 = NOVALUE;
    _31443 = NOVALUE;
    _31418 = NOVALUE;
    DeRef(_31421);
    _31421 = NOVALUE;
    _31433 = NOVALUE;
    return _errors_64041;
    ;
}


object _44file_name_based_symindex_compare(object _si1_64150, object _si2_64151)
{
    object _fn1_64172 = NOVALUE;
    object _fn2_64177 = NOVALUE;
    object _31487 = NOVALUE;
    object _31486 = NOVALUE;
    object _31485 = NOVALUE;
    object _31484 = NOVALUE;
    object _31483 = NOVALUE;
    object _31482 = NOVALUE;
    object _31481 = NOVALUE;
    object _31480 = NOVALUE;
    object _31479 = NOVALUE;
    object _31478 = NOVALUE;
    object _31477 = NOVALUE;
    object _31476 = NOVALUE;
    object _31474 = NOVALUE;
    object _31472 = NOVALUE;
    object _31471 = NOVALUE;
    object _31470 = NOVALUE;
    object _31469 = NOVALUE;
    object _31468 = NOVALUE;
    object _31467 = NOVALUE;
    object _31466 = NOVALUE;
    object _31465 = NOVALUE;
    object _31464 = NOVALUE;
    object _31463 = NOVALUE;
    object _31461 = NOVALUE;
    object _31460 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_si1_64150)) {
        _1 = (object)(DBL_PTR(_si1_64150)->dbl);
        DeRefDS(_si1_64150);
        _si1_64150 = _1;
    }
    if (!IS_ATOM_INT(_si2_64151)) {
        _1 = (object)(DBL_PTR(_si2_64151)->dbl);
        DeRefDS(_si2_64151);
        _si2_64151 = _1;
    }

    /** fwdref.e:949		if not symtab_index(si1) or not symtab_index(si2) then*/
    _31460 = _36symtab_index(_si1_64150);
    if (IS_ATOM_INT(_31460)) {
        _31461 = (_31460 == 0);
    }
    else {
        _31461 = unary_op(NOT, _31460);
    }
    DeRef(_31460);
    _31460 = NOVALUE;
    if (IS_ATOM_INT(_31461)) {
        if (_31461 != 0) {
            goto L1; // [14] 30
        }
    }
    else {
        if (DBL_PTR(_31461)->dbl != 0.0) {
            goto L1; // [14] 30
        }
    }
    _31463 = _36symtab_index(_si2_64151);
    if (IS_ATOM_INT(_31463)) {
        _31464 = (_31463 == 0);
    }
    else {
        _31464 = unary_op(NOT, _31463);
    }
    DeRef(_31463);
    _31463 = NOVALUE;
    if (_31464 == 0) {
        DeRef(_31464);
        _31464 = NOVALUE;
        goto L2; // [26] 37
    }
    else {
        if (!IS_ATOM_INT(_31464) && DBL_PTR(_31464)->dbl == 0.0){
            DeRef(_31464);
            _31464 = NOVALUE;
            goto L2; // [26] 37
        }
        DeRef(_31464);
        _31464 = NOVALUE;
    }
    DeRef(_31464);
    _31464 = NOVALUE;
L1: 

    /** fwdref.e:950			return 1 -- put non symbols last*/
    DeRef(_31461);
    _31461 = NOVALUE;
    return 1LL;
L2: 

    /** fwdref.e:952		if S_FILE_NO <= length(SymTab[si1]) and S_FILE_NO <= length(SymTab[si2]) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31465 = (object)*(((s1_ptr)_2)->base + _si1_64150);
    if (IS_SEQUENCE(_31465)){
            _31466 = SEQ_PTR(_31465)->length;
    }
    else {
        _31466 = 1;
    }
    _31465 = NOVALUE;
    if (IS_ATOM_INT(_36S_FILE_NO_21072)) {
        _31467 = (_36S_FILE_NO_21072 <= _31466);
    }
    else {
        _31467 = binary_op(LESSEQ, _36S_FILE_NO_21072, _31466);
    }
    _31466 = NOVALUE;
    if (IS_ATOM_INT(_31467)) {
        if (_31467 == 0) {
            goto L3; // [54] 186
        }
    }
    else {
        if (DBL_PTR(_31467)->dbl == 0.0) {
            goto L3; // [54] 186
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31469 = (object)*(((s1_ptr)_2)->base + _si2_64151);
    if (IS_SEQUENCE(_31469)){
            _31470 = SEQ_PTR(_31469)->length;
    }
    else {
        _31470 = 1;
    }
    _31469 = NOVALUE;
    if (IS_ATOM_INT(_36S_FILE_NO_21072)) {
        _31471 = (_36S_FILE_NO_21072 <= _31470);
    }
    else {
        _31471 = binary_op(LESSEQ, _36S_FILE_NO_21072, _31470);
    }
    _31470 = NOVALUE;
    if (_31471 == 0) {
        DeRef(_31471);
        _31471 = NOVALUE;
        goto L3; // [74] 186
    }
    else {
        if (!IS_ATOM_INT(_31471) && DBL_PTR(_31471)->dbl == 0.0){
            DeRef(_31471);
            _31471 = NOVALUE;
            goto L3; // [74] 186
        }
        DeRef(_31471);
        _31471 = NOVALUE;
    }
    DeRef(_31471);
    _31471 = NOVALUE;

    /** fwdref.e:953			integer fn1 = SymTab[si1][S_FILE_NO], fn2 = SymTab[si2][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31472 = (object)*(((s1_ptr)_2)->base + _si1_64150);
    _2 = (object)SEQ_PTR(_31472);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _fn1_64172 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _fn1_64172 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    if (!IS_ATOM_INT(_fn1_64172)){
        _fn1_64172 = (object)DBL_PTR(_fn1_64172)->dbl;
    }
    _31472 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31474 = (object)*(((s1_ptr)_2)->base + _si2_64151);
    _2 = (object)SEQ_PTR(_31474);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _fn2_64177 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _fn2_64177 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    if (!IS_ATOM_INT(_fn2_64177)){
        _fn2_64177 = (object)DBL_PTR(_fn2_64177)->dbl;
    }
    _31474 = NOVALUE;

    /** fwdref.e:954			if find(1,{fn1,fn2} > length(known_files) or {fn1,fn2} <= 0) then*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _fn1_64172;
    ((intptr_t *)_2)[2] = _fn2_64177;
    _31476 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_37known_files_15407)){
            _31477 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _31477 = 1;
    }
    _31478 = binary_op(GREATER, _31476, _31477);
    DeRefDS(_31476);
    _31476 = NOVALUE;
    _31477 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _fn1_64172;
    ((intptr_t *)_2)[2] = _fn2_64177;
    _31479 = MAKE_SEQ(_1);
    _31480 = binary_op(LESSEQ, _31479, 0LL);
    DeRefDS(_31479);
    _31479 = NOVALUE;
    _31481 = binary_op(OR, _31478, _31480);
    DeRefDS(_31478);
    _31478 = NOVALUE;
    DeRefDS(_31480);
    _31480 = NOVALUE;
    _31482 = find_from(1LL, _31481, 1LL);
    DeRefDS(_31481);
    _31481 = NOVALUE;
    if (_31482 == 0)
    {
        _31482 = NOVALUE;
        goto L4; // [139] 149
    }
    else{
        _31482 = NOVALUE;
    }

    /** fwdref.e:956				return 1*/
    _31465 = NOVALUE;
    DeRef(_31467);
    _31467 = NOVALUE;
    _31469 = NOVALUE;
    DeRef(_31461);
    _31461 = NOVALUE;
    return 1LL;
L4: 

    /** fwdref.e:958			return compare(abbreviate_path(known_files[fn1]),*/
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _31483 = (object)*(((s1_ptr)_2)->base + _fn1_64172);
    Ref(_31483);
    RefDS(_21993);
    _31484 = _17abbreviate_path(_31483, _21993);
    _31483 = NOVALUE;
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _31485 = (object)*(((s1_ptr)_2)->base + _fn2_64177);
    Ref(_31485);
    RefDS(_21993);
    _31486 = _17abbreviate_path(_31485, _21993);
    _31485 = NOVALUE;
    if (IS_ATOM_INT(_31484) && IS_ATOM_INT(_31486)){
        _31487 = (_31484 < _31486) ? -1 : (_31484 > _31486);
    }
    else{
        _31487 = compare(_31484, _31486);
    }
    DeRef(_31484);
    _31484 = NOVALUE;
    DeRef(_31486);
    _31486 = NOVALUE;
    _31465 = NOVALUE;
    DeRef(_31467);
    _31467 = NOVALUE;
    _31469 = NOVALUE;
    DeRef(_31461);
    _31461 = NOVALUE;
    return _31487;
    goto L5; // [183] 193
L3: 

    /** fwdref.e:961			return 1 -- put non-names last*/
    _31465 = NOVALUE;
    DeRef(_31467);
    _31467 = NOVALUE;
    _31469 = NOVALUE;
    DeRef(_31461);
    _31461 = NOVALUE;
    return 1LL;
L5: 
    ;
}


void _44Resolve_forward_references(object _report_errors_64203)
{
    object _errors_64204 = NOVALUE;
    object _unincluded_ok_64205 = NOVALUE;
    object _msg_64266 = NOVALUE;
    object _errloc_64267 = NOVALUE;
    object _ref_64272 = NOVALUE;
    object _tok_64288 = NOVALUE;
    object _THIS_SCOPE_64290 = NOVALUE;
    object _THESE_GLOBALS_64291 = NOVALUE;
    object _syms_64349 = NOVALUE;
    object _s_64370 = NOVALUE;
    object _31620 = NOVALUE;
    object _31619 = NOVALUE;
    object _31618 = NOVALUE;
    object _31616 = NOVALUE;
    object _31611 = NOVALUE;
    object _31608 = NOVALUE;
    object _31606 = NOVALUE;
    object _31605 = NOVALUE;
    object _31604 = NOVALUE;
    object _31603 = NOVALUE;
    object _31602 = NOVALUE;
    object _31601 = NOVALUE;
    object _31600 = NOVALUE;
    object _31598 = NOVALUE;
    object _31597 = NOVALUE;
    object _31596 = NOVALUE;
    object _31594 = NOVALUE;
    object _31592 = NOVALUE;
    object _31591 = NOVALUE;
    object _31590 = NOVALUE;
    object _31589 = NOVALUE;
    object _31588 = NOVALUE;
    object _31587 = NOVALUE;
    object _31584 = NOVALUE;
    object _31580 = NOVALUE;
    object _31579 = NOVALUE;
    object _31578 = NOVALUE;
    object _31577 = NOVALUE;
    object _31576 = NOVALUE;
    object _31575 = NOVALUE;
    object _31572 = NOVALUE;
    object _31571 = NOVALUE;
    object _31570 = NOVALUE;
    object _31569 = NOVALUE;
    object _31568 = NOVALUE;
    object _31567 = NOVALUE;
    object _31564 = NOVALUE;
    object _31563 = NOVALUE;
    object _31562 = NOVALUE;
    object _31561 = NOVALUE;
    object _31560 = NOVALUE;
    object _31559 = NOVALUE;
    object _31558 = NOVALUE;
    object _31557 = NOVALUE;
    object _31556 = NOVALUE;
    object _31555 = NOVALUE;
    object _31552 = NOVALUE;
    object _31550 = NOVALUE;
    object _31547 = NOVALUE;
    object _31545 = NOVALUE;
    object _31543 = NOVALUE;
    object _31542 = NOVALUE;
    object _31540 = NOVALUE;
    object _31539 = NOVALUE;
    object _31538 = NOVALUE;
    object _31537 = NOVALUE;
    object _31536 = NOVALUE;
    object _31534 = NOVALUE;
    object _31533 = NOVALUE;
    object _31531 = NOVALUE;
    object _31530 = NOVALUE;
    object _31528 = NOVALUE;
    object _31527 = NOVALUE;
    object _31525 = NOVALUE;
    object _31524 = NOVALUE;
    object _31523 = NOVALUE;
    object _31522 = NOVALUE;
    object _31521 = NOVALUE;
    object _31520 = NOVALUE;
    object _31519 = NOVALUE;
    object _31518 = NOVALUE;
    object _31517 = NOVALUE;
    object _31516 = NOVALUE;
    object _31515 = NOVALUE;
    object _31514 = NOVALUE;
    object _31513 = NOVALUE;
    object _31512 = NOVALUE;
    object _31511 = NOVALUE;
    object _31510 = NOVALUE;
    object _31508 = NOVALUE;
    object _31507 = NOVALUE;
    object _31506 = NOVALUE;
    object _31505 = NOVALUE;
    object _31503 = NOVALUE;
    object _31502 = NOVALUE;
    object _31500 = NOVALUE;
    object _31499 = NOVALUE;
    object _31498 = NOVALUE;
    object _31497 = NOVALUE;
    object _31495 = NOVALUE;
    object _31494 = NOVALUE;
    object _31493 = NOVALUE;
    object _31492 = NOVALUE;
    object _31490 = NOVALUE;
    object _31489 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:966		sequence errors = {}*/
    RefDS(_21993);
    DeRef(_errors_64204);
    _errors_64204 = _21993;

    /** fwdref.e:967		integer unincluded_ok = get_resolve_unincluded_globals()*/
    _unincluded_ok_64205 = _54get_resolve_unincluded_globals();
    if (!IS_ATOM_INT(_unincluded_ok_64205)) {
        _1 = (object)(DBL_PTR(_unincluded_ok_64205)->dbl);
        DeRefDS(_unincluded_ok_64205);
        _unincluded_ok_64205 = _1;
    }

    /** fwdref.e:969		if length( active_references ) < length( known_files ) then*/
    if (IS_SEQUENCE(_44active_references_62767)){
            _31489 = SEQ_PTR(_44active_references_62767)->length;
    }
    else {
        _31489 = 1;
    }
    if (IS_SEQUENCE(_37known_files_15407)){
            _31490 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _31490 = 1;
    }
    if (_31489 >= _31490)
    goto L1; // [29] 86

    /** fwdref.e:970			active_references &= repeat( {}, length( known_files ) - length( active_references ) )*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _31492 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _31492 = 1;
    }
    if (IS_SEQUENCE(_44active_references_62767)){
            _31493 = SEQ_PTR(_44active_references_62767)->length;
    }
    else {
        _31493 = 1;
    }
    _31494 = _31492 - _31493;
    _31492 = NOVALUE;
    _31493 = NOVALUE;
    _31495 = Repeat(_21993, _31494);
    _31494 = NOVALUE;
    Concat((object_ptr)&_44active_references_62767, _44active_references_62767, _31495);
    DeRefDS(_31495);
    _31495 = NOVALUE;

    /** fwdref.e:971			active_subprogs   &= repeat( {}, length( known_files ) - length( active_subprogs ) )*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _31497 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _31497 = 1;
    }
    if (IS_SEQUENCE(_44active_subprogs_62766)){
            _31498 = SEQ_PTR(_44active_subprogs_62766)->length;
    }
    else {
        _31498 = 1;
    }
    _31499 = _31497 - _31498;
    _31497 = NOVALUE;
    _31498 = NOVALUE;
    _31500 = Repeat(_21993, _31499);
    _31499 = NOVALUE;
    Concat((object_ptr)&_44active_subprogs_62766, _44active_subprogs_62766, _31500);
    DeRefDS(_31500);
    _31500 = NOVALUE;
L1: 

    /** fwdref.e:974		if length( toplevel_references ) < length( known_files ) then*/
    if (IS_SEQUENCE(_44toplevel_references_62768)){
            _31502 = SEQ_PTR(_44toplevel_references_62768)->length;
    }
    else {
        _31502 = 1;
    }
    if (IS_SEQUENCE(_37known_files_15407)){
            _31503 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _31503 = 1;
    }
    if (_31502 >= _31503)
    goto L2; // [98] 129

    /** fwdref.e:975			toplevel_references &= repeat( {}, length( known_files ) - length( toplevel_references ) )*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _31505 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _31505 = 1;
    }
    if (IS_SEQUENCE(_44toplevel_references_62768)){
            _31506 = SEQ_PTR(_44toplevel_references_62768)->length;
    }
    else {
        _31506 = 1;
    }
    _31507 = _31505 - _31506;
    _31505 = NOVALUE;
    _31506 = NOVALUE;
    _31508 = Repeat(_21993, _31507);
    _31507 = NOVALUE;
    Concat((object_ptr)&_44toplevel_references_62768, _44toplevel_references_62768, _31508);
    DeRefDS(_31508);
    _31508 = NOVALUE;
L2: 

    /** fwdref.e:978		for i = 1 to length( active_subprogs ) do*/
    if (IS_SEQUENCE(_44active_subprogs_62766)){
            _31510 = SEQ_PTR(_44active_subprogs_62766)->length;
    }
    else {
        _31510 = 1;
    }
    {
        object _i_64237;
        _i_64237 = 1LL;
L3: 
        if (_i_64237 > _31510){
            goto L4; // [136] 280
        }

        /** fwdref.e:979			if (length( active_subprogs[i] ) or length(toplevel_references[i])) */
        _2 = (object)SEQ_PTR(_44active_subprogs_62766);
        _31511 = (object)*(((s1_ptr)_2)->base + _i_64237);
        if (IS_SEQUENCE(_31511)){
                _31512 = SEQ_PTR(_31511)->length;
        }
        else {
            _31512 = 1;
        }
        _31511 = NOVALUE;
        if (_31512 != 0) {
            _31513 = 1;
            goto L5; // [154] 171
        }
        _2 = (object)SEQ_PTR(_44toplevel_references_62768);
        _31514 = (object)*(((s1_ptr)_2)->base + _i_64237);
        if (IS_SEQUENCE(_31514)){
                _31515 = SEQ_PTR(_31514)->length;
        }
        else {
            _31515 = 1;
        }
        _31514 = NOVALUE;
        _31513 = (_31515 != 0);
L5: 
        if (_31513 == 0) {
            goto L6; // [171] 273
        }
        _31517 = (_i_64237 == _36current_file_no_21439);
        if (_31517 != 0) {
            _31518 = 1;
            goto L7; // [181] 195
        }
        _2 = (object)SEQ_PTR(_37finished_files_15409);
        _31519 = (object)*(((s1_ptr)_2)->base + _i_64237);
        _31518 = (_31519 != 0);
L7: 
        if (_31518 != 0) {
            DeRef(_31520);
            _31520 = 1;
            goto L8; // [195] 203
        }
        _31520 = (_unincluded_ok_64205 != 0);
L8: 
        if (_31520 == 0)
        {
            _31520 = NOVALUE;
            goto L6; // [204] 273
        }
        else{
            _31520 = NOVALUE;
        }

        /** fwdref.e:982				for j = length( active_references[i] ) to 1 by -1 do*/
        _2 = (object)SEQ_PTR(_44active_references_62767);
        _31521 = (object)*(((s1_ptr)_2)->base + _i_64237);
        if (IS_SEQUENCE(_31521)){
                _31522 = SEQ_PTR(_31521)->length;
        }
        else {
            _31522 = 1;
        }
        _31521 = NOVALUE;
        {
            object _j_64253;
            _j_64253 = _31522;
L9: 
            if (_j_64253 < 1LL){
                goto LA; // [218] 254
            }

            /** fwdref.e:983					errors &= resolve_file( active_references[i][j], report_errors, unincluded_ok )*/
            _2 = (object)SEQ_PTR(_44active_references_62767);
            _31523 = (object)*(((s1_ptr)_2)->base + _i_64237);
            _2 = (object)SEQ_PTR(_31523);
            _31524 = (object)*(((s1_ptr)_2)->base + _j_64253);
            _31523 = NOVALUE;
            Ref(_31524);
            _31525 = _44resolve_file(_31524, _report_errors_64203, _unincluded_ok_64205);
            _31524 = NOVALUE;
            if (IS_SEQUENCE(_errors_64204) && IS_ATOM(_31525)) {
                Ref(_31525);
                Append(&_errors_64204, _errors_64204, _31525);
            }
            else if (IS_ATOM(_errors_64204) && IS_SEQUENCE(_31525)) {
            }
            else {
                Concat((object_ptr)&_errors_64204, _errors_64204, _31525);
            }
            DeRef(_31525);
            _31525 = NOVALUE;

            /** fwdref.e:984				end for*/
            _j_64253 = _j_64253 + -1LL;
            goto L9; // [249] 225
LA: 
            ;
        }

        /** fwdref.e:985				errors &= resolve_file( toplevel_references[i], report_errors, unincluded_ok )*/
        _2 = (object)SEQ_PTR(_44toplevel_references_62768);
        _31527 = (object)*(((s1_ptr)_2)->base + _i_64237);
        Ref(_31527);
        _31528 = _44resolve_file(_31527, _report_errors_64203, _unincluded_ok_64205);
        _31527 = NOVALUE;
        if (IS_SEQUENCE(_errors_64204) && IS_ATOM(_31528)) {
            Ref(_31528);
            Append(&_errors_64204, _errors_64204, _31528);
        }
        else if (IS_ATOM(_errors_64204) && IS_SEQUENCE(_31528)) {
        }
        else {
            Concat((object_ptr)&_errors_64204, _errors_64204, _31528);
        }
        DeRef(_31528);
        _31528 = NOVALUE;
L6: 

        /** fwdref.e:987		end for*/
        _i_64237 = _i_64237 + 1LL;
        goto L3; // [275] 143
L4: 
        ;
    }

    /** fwdref.e:989		if report_errors and length( errors ) then*/
    if (_report_errors_64203 == 0) {
        goto LB; // [282] 856
    }
    if (IS_SEQUENCE(_errors_64204)){
            _31531 = SEQ_PTR(_errors_64204)->length;
    }
    else {
        _31531 = 1;
    }
    if (_31531 == 0)
    {
        _31531 = NOVALUE;
        goto LB; // [290] 856
    }
    else{
        _31531 = NOVALUE;
    }

    /** fwdref.e:990			sequence msg = ""*/
    RefDS(_21993);
    DeRefi(_msg_64266);
    _msg_64266 = _21993;

    /** fwdref.e:991			sequence errloc = "Internal Error - Unknown Error Message"*/
    RefDS(_31532);
    DeRefi(_errloc_64267);
    _errloc_64267 = _31532;

    /** fwdref.e:993			for e = length(errors) to 1 by -1 do*/
    if (IS_SEQUENCE(_errors_64204)){
            _31533 = SEQ_PTR(_errors_64204)->length;
    }
    else {
        _31533 = 1;
    }
    {
        object _e_64270;
        _e_64270 = _31533;
LC: 
        if (_e_64270 < 1LL){
            goto LD; // [312] 828
        }

        /** fwdref.e:994				sequence ref = forward_references[errors[e]]*/
        _2 = (object)SEQ_PTR(_errors_64204);
        _31534 = (object)*(((s1_ptr)_2)->base + _e_64270);
        DeRef(_ref_64272);
        _2 = (object)SEQ_PTR(_44forward_references_62765);
        if (!IS_ATOM_INT(_31534)){
            _ref_64272 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31534)->dbl));
        }
        else{
            _ref_64272 = (object)*(((s1_ptr)_2)->base + _31534);
        }
        Ref(_ref_64272);

        /** fwdref.e:995				if (ref[FR_TYPE] = TYPE_CHECK and ref[FR_OP] = TYPE_CHECK) or ref[FR_TYPE] = GLOBAL_INIT_CHECK then*/
        _2 = (object)SEQ_PTR(_ref_64272);
        _31536 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_31536)) {
            _31537 = (_31536 == 65LL);
        }
        else {
            _31537 = binary_op(EQUALS, _31536, 65LL);
        }
        _31536 = NOVALUE;
        if (IS_ATOM_INT(_31537)) {
            if (_31537 == 0) {
                DeRef(_31538);
                _31538 = 0;
                goto LE; // [345] 363
            }
        }
        else {
            if (DBL_PTR(_31537)->dbl == 0.0) {
                DeRef(_31538);
                _31538 = 0;
                goto LE; // [345] 363
            }
        }
        _2 = (object)SEQ_PTR(_ref_64272);
        _31539 = (object)*(((s1_ptr)_2)->base + 10LL);
        if (IS_ATOM_INT(_31539)) {
            _31540 = (_31539 == 65LL);
        }
        else {
            _31540 = binary_op(EQUALS, _31539, 65LL);
        }
        _31539 = NOVALUE;
        DeRef(_31538);
        if (IS_ATOM_INT(_31540))
        _31538 = (_31540 != 0);
        else
        _31538 = DBL_PTR(_31540)->dbl != 0.0;
LE: 
        if (_31538 != 0) {
            goto LF; // [363] 382
        }
        _2 = (object)SEQ_PTR(_ref_64272);
        _31542 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_31542)) {
            _31543 = (_31542 == 109LL);
        }
        else {
            _31543 = binary_op(EQUALS, _31542, 109LL);
        }
        _31542 = NOVALUE;
        if (_31543 == 0) {
            DeRef(_31543);
            _31543 = NOVALUE;
            goto L10; // [378] 391
        }
        else {
            if (!IS_ATOM_INT(_31543) && DBL_PTR(_31543)->dbl == 0.0){
                DeRef(_31543);
                _31543 = NOVALUE;
                goto L10; // [378] 391
            }
            DeRef(_31543);
            _31543 = NOVALUE;
        }
        DeRef(_31543);
        _31543 = NOVALUE;
LF: 

        /** fwdref.e:997					continue*/
        DeRef(_ref_64272);
        _ref_64272 = NOVALUE;
        goto L11; // [386] 823
        goto L12; // [388] 789
L10: 

        /** fwdref.e:1001					object tok = find_reference(ref)*/
        RefDS(_ref_64272);
        _0 = _tok_64288;
        _tok_64288 = _44find_reference(_ref_64272);
        DeRef(_0);

        /** fwdref.e:1002					integer THIS_SCOPE = 3*/
        _THIS_SCOPE_64290 = 3LL;

        /** fwdref.e:1003					integer THESE_GLOBALS = 4*/
        _THESE_GLOBALS_64291 = 4LL;

        /** fwdref.e:1004					if tok[T_ID] = IGNORED then*/
        _2 = (object)SEQ_PTR(_tok_64288);
        _31545 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _31545, 509LL)){
            _31545 = NOVALUE;
            goto L13; // [417] 760
        }
        _31545 = NOVALUE;

        /** fwdref.e:1006						switch tok[THIS_SCOPE] do*/
        _2 = (object)SEQ_PTR(_tok_64288);
        _31547 = (object)*(((s1_ptr)_2)->base + 3LL);
        if (IS_SEQUENCE(_31547) ){
            goto L14; // [427] 756
        }
        if(!IS_ATOM_INT(_31547)){
            if( (DBL_PTR(_31547)->dbl != (eudouble) ((object) DBL_PTR(_31547)->dbl) ) ){
                goto L14; // [427] 756
            }
            _0 = (object) DBL_PTR(_31547)->dbl;
        }
        else {
            _0 = _31547;
        };
        _31547 = NOVALUE;
        switch ( _0 ){ 

            /** fwdref.e:1007							case SC_UNDEFINED then*/
            case 9:

            /** fwdref.e:1008								if ref[FR_QUALIFIED] != -1 then*/
            _2 = (object)SEQ_PTR(_ref_64272);
            _31550 = (object)*(((s1_ptr)_2)->base + 9LL);
            if (binary_op_a(EQUALS, _31550, -1LL)){
                _31550 = NOVALUE;
                goto L15; // [442] 556
            }
            _31550 = NOVALUE;

            /** fwdref.e:1009									if ref[FR_QUALIFIED] > 0 then*/
            _2 = (object)SEQ_PTR(_ref_64272);
            _31552 = (object)*(((s1_ptr)_2)->base + 9LL);
            if (binary_op_a(LESSEQ, _31552, 0LL)){
                _31552 = NOVALUE;
                goto L16; // [452] 517
            }
            _31552 = NOVALUE;

            /** fwdref.e:1011										errloc = sprintf("\t\'%s\' (%s:%d) was not declared in \'%s\'.\n", */
            _2 = (object)SEQ_PTR(_ref_64272);
            _31555 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_ref_64272);
            _31556 = (object)*(((s1_ptr)_2)->base + 3LL);
            _2 = (object)SEQ_PTR(_37known_files_15407);
            if (!IS_ATOM_INT(_31556)){
                _31557 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31556)->dbl));
            }
            else{
                _31557 = (object)*(((s1_ptr)_2)->base + _31556);
            }
            Ref(_31557);
            RefDS(_21993);
            _31558 = _17abbreviate_path(_31557, _21993);
            _31557 = NOVALUE;
            _2 = (object)SEQ_PTR(_ref_64272);
            _31559 = (object)*(((s1_ptr)_2)->base + 6LL);
            _2 = (object)SEQ_PTR(_ref_64272);
            _31560 = (object)*(((s1_ptr)_2)->base + 9LL);
            _2 = (object)SEQ_PTR(_37known_files_15407);
            if (!IS_ATOM_INT(_31560)){
                _31561 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31560)->dbl));
            }
            else{
                _31561 = (object)*(((s1_ptr)_2)->base + _31560);
            }
            Ref(_31561);
            RefDS(_21993);
            _31562 = _17abbreviate_path(_31561, _21993);
            _31561 = NOVALUE;
            _31563 = _16find_replace(92LL, _31562, 47LL, 0LL);
            _31562 = NOVALUE;
            _1 = NewS1(4);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_31555);
            ((intptr_t*)_2)[1] = _31555;
            ((intptr_t*)_2)[2] = _31558;
            Ref(_31559);
            ((intptr_t*)_2)[3] = _31559;
            ((intptr_t*)_2)[4] = _31563;
            _31564 = MAKE_SEQ(_1);
            _31563 = NOVALUE;
            _31559 = NOVALUE;
            _31558 = NOVALUE;
            _31555 = NOVALUE;
            DeRefi(_errloc_64267);
            _errloc_64267 = EPrintf(-9999999, _31554, _31564);
            DeRefDS(_31564);
            _31564 = NOVALUE;
            goto L17; // [514] 759
L16: 

            /** fwdref.e:1016										errloc = sprintf("\t\'%s\' (%s:%d) is not a builtin.\n", */
            _2 = (object)SEQ_PTR(_ref_64272);
            _31567 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_ref_64272);
            _31568 = (object)*(((s1_ptr)_2)->base + 3LL);
            _2 = (object)SEQ_PTR(_37known_files_15407);
            if (!IS_ATOM_INT(_31568)){
                _31569 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31568)->dbl));
            }
            else{
                _31569 = (object)*(((s1_ptr)_2)->base + _31568);
            }
            Ref(_31569);
            RefDS(_21993);
            _31570 = _17abbreviate_path(_31569, _21993);
            _31569 = NOVALUE;
            _2 = (object)SEQ_PTR(_ref_64272);
            _31571 = (object)*(((s1_ptr)_2)->base + 6LL);
            _1 = NewS1(3);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_31567);
            ((intptr_t*)_2)[1] = _31567;
            ((intptr_t*)_2)[2] = _31570;
            Ref(_31571);
            ((intptr_t*)_2)[3] = _31571;
            _31572 = MAKE_SEQ(_1);
            _31571 = NOVALUE;
            _31570 = NOVALUE;
            _31567 = NOVALUE;
            DeRefi(_errloc_64267);
            _errloc_64267 = EPrintf(-9999999, _31566, _31572);
            DeRefDS(_31572);
            _31572 = NOVALUE;
            goto L17; // [553] 759
L15: 

            /** fwdref.e:1021									errloc = sprintf("\t\'%s\' (%s:%d) has not been declared.\n", */
            _2 = (object)SEQ_PTR(_ref_64272);
            _31575 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_ref_64272);
            _31576 = (object)*(((s1_ptr)_2)->base + 3LL);
            _2 = (object)SEQ_PTR(_37known_files_15407);
            if (!IS_ATOM_INT(_31576)){
                _31577 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31576)->dbl));
            }
            else{
                _31577 = (object)*(((s1_ptr)_2)->base + _31576);
            }
            Ref(_31577);
            RefDS(_21993);
            _31578 = _17abbreviate_path(_31577, _21993);
            _31577 = NOVALUE;
            _2 = (object)SEQ_PTR(_ref_64272);
            _31579 = (object)*(((s1_ptr)_2)->base + 6LL);
            _1 = NewS1(3);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_31575);
            ((intptr_t*)_2)[1] = _31575;
            ((intptr_t*)_2)[2] = _31578;
            Ref(_31579);
            ((intptr_t*)_2)[3] = _31579;
            _31580 = MAKE_SEQ(_1);
            _31579 = NOVALUE;
            _31578 = NOVALUE;
            _31575 = NOVALUE;
            DeRefi(_errloc_64267);
            _errloc_64267 = EPrintf(-9999999, _31574, _31580);
            DeRefDS(_31580);
            _31580 = NOVALUE;
            goto L17; // [592] 759

            /** fwdref.e:1024							case SC_MULTIPLY_DEFINED then*/
            case 10:

            /** fwdref.e:1025								sequence syms = tok[THESE_GLOBALS] -- there should be no forward references in here.*/
            DeRef(_syms_64349);
            _2 = (object)SEQ_PTR(_tok_64288);
            _syms_64349 = (object)*(((s1_ptr)_2)->base + _THESE_GLOBALS_64291);
            Ref(_syms_64349);

            /** fwdref.e:1026								syms = custom_sort(routine_id("file_name_based_symindex_compare"), syms,, ASCENDING)*/
            _31584 = CRoutineId(1382, 44, _31583);
            RefDS(_syms_64349);
            RefDS(_21993);
            _0 = _syms_64349;
            _syms_64349 = _24custom_sort(_31584, _syms_64349, _21993, 1LL);
            DeRefDS(_0);
            _31584 = NOVALUE;

            /** fwdref.e:1027								errloc = sprintf("\t\'%s\' (%s:%d) has been declared more than once.\n", */
            _2 = (object)SEQ_PTR(_ref_64272);
            _31587 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_ref_64272);
            _31588 = (object)*(((s1_ptr)_2)->base + 3LL);
            _2 = (object)SEQ_PTR(_37known_files_15407);
            if (!IS_ATOM_INT(_31588)){
                _31589 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31588)->dbl));
            }
            else{
                _31589 = (object)*(((s1_ptr)_2)->base + _31588);
            }
            Ref(_31589);
            RefDS(_21993);
            _31590 = _17abbreviate_path(_31589, _21993);
            _31589 = NOVALUE;
            _2 = (object)SEQ_PTR(_ref_64272);
            _31591 = (object)*(((s1_ptr)_2)->base + 6LL);
            _1 = NewS1(3);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_31587);
            ((intptr_t*)_2)[1] = _31587;
            ((intptr_t*)_2)[2] = _31590;
            Ref(_31591);
            ((intptr_t*)_2)[3] = _31591;
            _31592 = MAKE_SEQ(_1);
            _31591 = NOVALUE;
            _31590 = NOVALUE;
            _31587 = NOVALUE;
            DeRefi(_errloc_64267);
            _errloc_64267 = EPrintf(-9999999, _31586, _31592);
            DeRefDS(_31592);
            _31592 = NOVALUE;

            /** fwdref.e:1029								for si = 1 to length(syms) do*/
            if (IS_SEQUENCE(_syms_64349)){
                    _31594 = SEQ_PTR(_syms_64349)->length;
            }
            else {
                _31594 = 1;
            }
            {
                object _si_64367;
                _si_64367 = 1LL;
L18: 
                if (_si_64367 > _31594){
                    goto L19; // [664] 750
                }

                /** fwdref.e:1030									symtab_index s = syms[si] */
                _2 = (object)SEQ_PTR(_syms_64349);
                _s_64370 = (object)*(((s1_ptr)_2)->base + _si_64367);
                if (!IS_ATOM_INT(_s_64370)){
                    _s_64370 = (object)DBL_PTR(_s_64370)->dbl;
                }

                /** fwdref.e:1031									if equal(ref[FR_NAME], sym_name(s)) then*/
                _2 = (object)SEQ_PTR(_ref_64272);
                _31596 = (object)*(((s1_ptr)_2)->base + 2LL);
                _31597 = _54sym_name(_s_64370);
                if (_31596 == _31597)
                _31598 = 1;
                else if (IS_ATOM_INT(_31596) && IS_ATOM_INT(_31597))
                _31598 = 0;
                else
                _31598 = (compare(_31596, _31597) == 0);
                _31596 = NOVALUE;
                DeRef(_31597);
                _31597 = NOVALUE;
                if (_31598 == 0)
                {
                    _31598 = NOVALUE;
                    goto L1A; // [693] 741
                }
                else{
                    _31598 = NOVALUE;
                }

                /** fwdref.e:1032										errloc &= sprintf("\t\tin %s\n", */
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _31600 = (object)*(((s1_ptr)_2)->base + _s_64370);
                _2 = (object)SEQ_PTR(_31600);
                if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
                    _31601 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
                }
                else{
                    _31601 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
                }
                _31600 = NOVALUE;
                _2 = (object)SEQ_PTR(_37known_files_15407);
                if (!IS_ATOM_INT(_31601)){
                    _31602 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31601)->dbl));
                }
                else{
                    _31602 = (object)*(((s1_ptr)_2)->base + _31601);
                }
                Ref(_31602);
                RefDS(_21993);
                _31603 = _17abbreviate_path(_31602, _21993);
                _31602 = NOVALUE;
                _31604 = _16find_replace(92LL, _31603, 47LL, 0LL);
                _31603 = NOVALUE;
                _1 = NewS1(1);
                _2 = (object)((s1_ptr)_1)->base;
                ((intptr_t*)_2)[1] = _31604;
                _31605 = MAKE_SEQ(_1);
                _31604 = NOVALUE;
                _31606 = EPrintf(-9999999, _31599, _31605);
                DeRefDS(_31605);
                _31605 = NOVALUE;
                Concat((object_ptr)&_errloc_64267, _errloc_64267, _31606);
                DeRefDS(_31606);
                _31606 = NOVALUE;
L1A: 

                /** fwdref.e:1035								end for*/
                _si_64367 = _si_64367 + 1LL;
                goto L18; // [745] 671
L19: 
                ;
            }
            DeRef(_syms_64349);
            _syms_64349 = NOVALUE;
            goto L17; // [752] 759

            /** fwdref.e:1036							case else */
            default:
L14: 
        ;}L17: 
L13: 

        /** fwdref.e:1040					if not match(errloc, msg) then*/
        _31608 = e_match_from(_errloc_64267, _msg_64266, 1LL);
        if (_31608 != 0)
        goto L1B; // [767] 786
        _31608 = NOVALUE;

        /** fwdref.e:1041						msg &= errloc*/
        Concat((object_ptr)&_msg_64266, _msg_64266, _errloc_64267);

        /** fwdref.e:1042						prep_forward_error( errors[e] )*/
        _2 = (object)SEQ_PTR(_errors_64204);
        _31611 = (object)*(((s1_ptr)_2)->base + _e_64270);
        Ref(_31611);
        _44prep_forward_error(_31611);
        _31611 = NOVALUE;
L1B: 
        DeRef(_tok_64288);
        _tok_64288 = NOVALUE;
L12: 

        /** fwdref.e:1045				ThisLine    = ref[FR_THISLINE]*/
        DeRef(_50ThisLine_49234);
        _2 = (object)SEQ_PTR(_ref_64272);
        _50ThisLine_49234 = (object)*(((s1_ptr)_2)->base + 7LL);
        Ref(_50ThisLine_49234);

        /** fwdref.e:1046				bp          = ref[FR_BP]*/
        _2 = (object)SEQ_PTR(_ref_64272);
        _50bp_49238 = (object)*(((s1_ptr)_2)->base + 8LL);
        if (!IS_ATOM_INT(_50bp_49238)){
            _50bp_49238 = (object)DBL_PTR(_50bp_49238)->dbl;
        }

        /** fwdref.e:1047				CurrentSub  = ref[FR_SUBPROG]*/
        _2 = (object)SEQ_PTR(_ref_64272);
        _36CurrentSub_21447 = (object)*(((s1_ptr)_2)->base + 4LL);
        if (!IS_ATOM_INT(_36CurrentSub_21447)){
            _36CurrentSub_21447 = (object)DBL_PTR(_36CurrentSub_21447)->dbl;
        }

        /** fwdref.e:1048				line_number = ref[FR_LINE]*/
        _2 = (object)SEQ_PTR(_ref_64272);
        _36line_number_21440 = (object)*(((s1_ptr)_2)->base + 6LL);
        if (!IS_ATOM_INT(_36line_number_21440)){
            _36line_number_21440 = (object)DBL_PTR(_36line_number_21440)->dbl;
        }
        DeRefDS(_ref_64272);
        _ref_64272 = NOVALUE;

        /** fwdref.e:1049			end for*/
L11: 
        _e_64270 = _e_64270 + -1LL;
        goto LC; // [823] 319
LD: 
        ;
    }

    /** fwdref.e:1050			if length(msg) > 0 then*/
    if (IS_SEQUENCE(_msg_64266)){
            _31616 = SEQ_PTR(_msg_64266)->length;
    }
    else {
        _31616 = 1;
    }
    if (_31616 <= 0LL)
    goto L1C; // [833] 851

    /** fwdref.e:1051				CompileErr( ERRORS_RESOLVING_THE_FOLLOWING_REFERENCES1, {msg} )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_msg_64266);
    ((intptr_t*)_2)[1] = _msg_64266;
    _31618 = MAKE_SEQ(_1);
    _50CompileErr(74LL, _31618, 0LL);
    _31618 = NOVALUE;
L1C: 
    DeRefi(_msg_64266);
    _msg_64266 = NOVALUE;
    DeRefi(_errloc_64267);
    _errloc_64267 = NOVALUE;
    goto L1D; // [853] 901
LB: 

    /** fwdref.e:1053		elsif report_errors and not repl then*/
    if (_report_errors_64203 == 0) {
        goto L1E; // [858] 900
    }
    _31620 = (0LL == 0);
    if (_31620 == 0)
    {
        DeRef(_31620);
        _31620 = NOVALUE;
        goto L1E; // [868] 900
    }
    else{
        DeRef(_31620);
        _31620 = NOVALUE;
    }

    /** fwdref.e:1055			forward_references  = {}*/
    RefDS(_21993);
    DeRef(_44forward_references_62765);
    _44forward_references_62765 = _21993;

    /** fwdref.e:1056			active_references   = {}*/
    RefDS(_21993);
    DeRef(_44active_references_62767);
    _44active_references_62767 = _21993;

    /** fwdref.e:1057			toplevel_references = {}*/
    RefDS(_21993);
    DeRef(_44toplevel_references_62768);
    _44toplevel_references_62768 = _21993;

    /** fwdref.e:1058			inactive_references = {}*/
    RefDS(_21993);
    DeRef(_44inactive_references_62769);
    _44inactive_references_62769 = _21993;
L1E: 
L1D: 

    /** fwdref.e:1060		clear_last()*/
    _47clear_last();

    /** fwdref.e:1061	end procedure*/
    DeRef(_errors_64204);
    _31534 = NOVALUE;
    DeRef(_31540);
    _31540 = NOVALUE;
    _31514 = NOVALUE;
    _31601 = NOVALUE;
    _31576 = NOVALUE;
    DeRef(_31517);
    _31517 = NOVALUE;
    DeRef(_31537);
    _31537 = NOVALUE;
    _31511 = NOVALUE;
    _31588 = NOVALUE;
    _31556 = NOVALUE;
    _31568 = NOVALUE;
    _31519 = NOVALUE;
    _31521 = NOVALUE;
    _31560 = NOVALUE;
    return;
    ;
}


void _44shift_these(object _refs_64418, object _pc_64419, object _amount_64420)
{
    object _fr_64424 = NOVALUE;
    object _31638 = NOVALUE;
    object _31637 = NOVALUE;
    object _31636 = NOVALUE;
    object _31635 = NOVALUE;
    object _31634 = NOVALUE;
    object _31633 = NOVALUE;
    object _31632 = NOVALUE;
    object _31631 = NOVALUE;
    object _31630 = NOVALUE;
    object _31629 = NOVALUE;
    object _31627 = NOVALUE;
    object _31625 = NOVALUE;
    object _31624 = NOVALUE;
    object _31622 = NOVALUE;
    object _31621 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:1064		for i = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_64418)){
            _31621 = SEQ_PTR(_refs_64418)->length;
    }
    else {
        _31621 = 1;
    }
    {
        object _i_64422;
        _i_64422 = _31621;
L1: 
        if (_i_64422 < 1LL){
            goto L2; // [12] 147
        }

        /** fwdref.e:1065			sequence fr = forward_references[refs[i]]*/
        _2 = (object)SEQ_PTR(_refs_64418);
        _31622 = (object)*(((s1_ptr)_2)->base + _i_64422);
        DeRef(_fr_64424);
        _2 = (object)SEQ_PTR(_44forward_references_62765);
        if (!IS_ATOM_INT(_31622)){
            _fr_64424 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31622)->dbl));
        }
        else{
            _fr_64424 = (object)*(((s1_ptr)_2)->base + _31622);
        }
        Ref(_fr_64424);

        /** fwdref.e:1066			forward_references[refs[i]] = 0*/
        _2 = (object)SEQ_PTR(_refs_64418);
        _31624 = (object)*(((s1_ptr)_2)->base + _i_64422);
        _2 = (object)SEQ_PTR(_44forward_references_62765);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _44forward_references_62765 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31624))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31624)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _31624);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0LL;
        DeRef(_1);

        /** fwdref.e:1067			if fr[FR_SUBPROG] = shifting_sub then*/
        _2 = (object)SEQ_PTR(_fr_64424);
        _31625 = (object)*(((s1_ptr)_2)->base + 4LL);
        if (binary_op_a(NOTEQ, _31625, _44shifting_sub_62784)){
            _31625 = NOVALUE;
            goto L3; // [53] 126
        }
        _31625 = NOVALUE;

        /** fwdref.e:1068				if fr[FR_PC] >= pc then*/
        _2 = (object)SEQ_PTR(_fr_64424);
        _31627 = (object)*(((s1_ptr)_2)->base + 5LL);
        if (binary_op_a(LESS, _31627, _pc_64419)){
            _31627 = NOVALUE;
            goto L4; // [63] 125
        }
        _31627 = NOVALUE;

        /** fwdref.e:1069					fr[FR_PC] += amount*/
        _2 = (object)SEQ_PTR(_fr_64424);
        _31629 = (object)*(((s1_ptr)_2)->base + 5LL);
        if (IS_ATOM_INT(_31629)) {
            _31630 = _31629 + _amount_64420;
            if ((object)((uintptr_t)_31630 + (uintptr_t)HIGH_BITS) >= 0){
                _31630 = NewDouble((eudouble)_31630);
            }
        }
        else {
            _31630 = binary_op(PLUS, _31629, _amount_64420);
        }
        _31629 = NOVALUE;
        _2 = (object)SEQ_PTR(_fr_64424);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _fr_64424 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31630;
        if( _1 != _31630 ){
            DeRef(_1);
        }
        _31630 = NOVALUE;

        /** fwdref.e:1070					if fr[FR_TYPE] = CASE*/
        _2 = (object)SEQ_PTR(_fr_64424);
        _31631 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_31631)) {
            _31632 = (_31631 == 186LL);
        }
        else {
            _31632 = binary_op(EQUALS, _31631, 186LL);
        }
        _31631 = NOVALUE;
        if (IS_ATOM_INT(_31632)) {
            if (_31632 == 0) {
                goto L5; // [93] 124
            }
        }
        else {
            if (DBL_PTR(_31632)->dbl == 0.0) {
                goto L5; // [93] 124
            }
        }
        _2 = (object)SEQ_PTR(_fr_64424);
        _31634 = (object)*(((s1_ptr)_2)->base + 12LL);
        if (IS_ATOM_INT(_31634)) {
            _31635 = (_31634 >= _pc_64419);
        }
        else {
            _31635 = binary_op(GREATEREQ, _31634, _pc_64419);
        }
        _31634 = NOVALUE;
        if (_31635 == 0) {
            DeRef(_31635);
            _31635 = NOVALUE;
            goto L5; // [106] 124
        }
        else {
            if (!IS_ATOM_INT(_31635) && DBL_PTR(_31635)->dbl == 0.0){
                DeRef(_31635);
                _31635 = NOVALUE;
                goto L5; // [106] 124
            }
            DeRef(_31635);
            _31635 = NOVALUE;
        }
        DeRef(_31635);
        _31635 = NOVALUE;

        /** fwdref.e:1073						fr[FR_DATA] += amount*/
        _2 = (object)SEQ_PTR(_fr_64424);
        _31636 = (object)*(((s1_ptr)_2)->base + 12LL);
        if (IS_ATOM_INT(_31636)) {
            _31637 = _31636 + _amount_64420;
            if ((object)((uintptr_t)_31637 + (uintptr_t)HIGH_BITS) >= 0){
                _31637 = NewDouble((eudouble)_31637);
            }
        }
        else {
            _31637 = binary_op(PLUS, _31636, _amount_64420);
        }
        _31636 = NOVALUE;
        _2 = (object)SEQ_PTR(_fr_64424);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _fr_64424 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 12LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31637;
        if( _1 != _31637 ){
            DeRef(_1);
        }
        _31637 = NOVALUE;
L5: 
L4: 
L3: 

        /** fwdref.e:1077			forward_references[refs[i]] = fr*/
        _2 = (object)SEQ_PTR(_refs_64418);
        _31638 = (object)*(((s1_ptr)_2)->base + _i_64422);
        RefDS(_fr_64424);
        _2 = (object)SEQ_PTR(_44forward_references_62765);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _44forward_references_62765 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31638))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31638)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _31638);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _fr_64424;
        DeRef(_1);
        DeRefDS(_fr_64424);
        _fr_64424 = NOVALUE;

        /** fwdref.e:1078		end for*/
        _i_64422 = _i_64422 + -1LL;
        goto L1; // [142] 19
L2: 
        ;
    }

    /** fwdref.e:1079	end procedure*/
    DeRefDS(_refs_64418);
    _31622 = NOVALUE;
    DeRef(_31632);
    _31632 = NOVALUE;
    _31624 = NOVALUE;
    _31638 = NOVALUE;
    return;
    ;
}


void _44shift_top(object _refs_64448, object _pc_64449, object _amount_64450)
{
    object _fr_64454 = NOVALUE;
    object _31654 = NOVALUE;
    object _31653 = NOVALUE;
    object _31652 = NOVALUE;
    object _31651 = NOVALUE;
    object _31650 = NOVALUE;
    object _31649 = NOVALUE;
    object _31648 = NOVALUE;
    object _31647 = NOVALUE;
    object _31646 = NOVALUE;
    object _31645 = NOVALUE;
    object _31643 = NOVALUE;
    object _31642 = NOVALUE;
    object _31640 = NOVALUE;
    object _31639 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:1083		for i = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_64448)){
            _31639 = SEQ_PTR(_refs_64448)->length;
    }
    else {
        _31639 = 1;
    }
    {
        object _i_64452;
        _i_64452 = _31639;
L1: 
        if (_i_64452 < 1LL){
            goto L2; // [12] 134
        }

        /** fwdref.e:1084			sequence fr = forward_references[refs[i]]*/
        _2 = (object)SEQ_PTR(_refs_64448);
        _31640 = (object)*(((s1_ptr)_2)->base + _i_64452);
        DeRef(_fr_64454);
        _2 = (object)SEQ_PTR(_44forward_references_62765);
        if (!IS_ATOM_INT(_31640)){
            _fr_64454 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31640)->dbl));
        }
        else{
            _fr_64454 = (object)*(((s1_ptr)_2)->base + _31640);
        }
        Ref(_fr_64454);

        /** fwdref.e:1085			forward_references[refs[i]] = 0*/
        _2 = (object)SEQ_PTR(_refs_64448);
        _31642 = (object)*(((s1_ptr)_2)->base + _i_64452);
        _2 = (object)SEQ_PTR(_44forward_references_62765);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _44forward_references_62765 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31642))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31642)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _31642);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0LL;
        DeRef(_1);

        /** fwdref.e:1086			if fr[FR_PC] >= pc then*/
        _2 = (object)SEQ_PTR(_fr_64454);
        _31643 = (object)*(((s1_ptr)_2)->base + 5LL);
        if (binary_op_a(LESS, _31643, _pc_64449)){
            _31643 = NOVALUE;
            goto L3; // [51] 113
        }
        _31643 = NOVALUE;

        /** fwdref.e:1087				fr[FR_PC] += amount*/
        _2 = (object)SEQ_PTR(_fr_64454);
        _31645 = (object)*(((s1_ptr)_2)->base + 5LL);
        if (IS_ATOM_INT(_31645)) {
            _31646 = _31645 + _amount_64450;
            if ((object)((uintptr_t)_31646 + (uintptr_t)HIGH_BITS) >= 0){
                _31646 = NewDouble((eudouble)_31646);
            }
        }
        else {
            _31646 = binary_op(PLUS, _31645, _amount_64450);
        }
        _31645 = NOVALUE;
        _2 = (object)SEQ_PTR(_fr_64454);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _fr_64454 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31646;
        if( _1 != _31646 ){
            DeRef(_1);
        }
        _31646 = NOVALUE;

        /** fwdref.e:1088				if fr[FR_TYPE] = CASE*/
        _2 = (object)SEQ_PTR(_fr_64454);
        _31647 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_31647)) {
            _31648 = (_31647 == 186LL);
        }
        else {
            _31648 = binary_op(EQUALS, _31647, 186LL);
        }
        _31647 = NOVALUE;
        if (IS_ATOM_INT(_31648)) {
            if (_31648 == 0) {
                goto L4; // [81] 112
            }
        }
        else {
            if (DBL_PTR(_31648)->dbl == 0.0) {
                goto L4; // [81] 112
            }
        }
        _2 = (object)SEQ_PTR(_fr_64454);
        _31650 = (object)*(((s1_ptr)_2)->base + 12LL);
        if (IS_ATOM_INT(_31650)) {
            _31651 = (_31650 >= _pc_64449);
        }
        else {
            _31651 = binary_op(GREATEREQ, _31650, _pc_64449);
        }
        _31650 = NOVALUE;
        if (_31651 == 0) {
            DeRef(_31651);
            _31651 = NOVALUE;
            goto L4; // [94] 112
        }
        else {
            if (!IS_ATOM_INT(_31651) && DBL_PTR(_31651)->dbl == 0.0){
                DeRef(_31651);
                _31651 = NOVALUE;
                goto L4; // [94] 112
            }
            DeRef(_31651);
            _31651 = NOVALUE;
        }
        DeRef(_31651);
        _31651 = NOVALUE;

        /** fwdref.e:1091					fr[FR_DATA] += amount*/
        _2 = (object)SEQ_PTR(_fr_64454);
        _31652 = (object)*(((s1_ptr)_2)->base + 12LL);
        if (IS_ATOM_INT(_31652)) {
            _31653 = _31652 + _amount_64450;
            if ((object)((uintptr_t)_31653 + (uintptr_t)HIGH_BITS) >= 0){
                _31653 = NewDouble((eudouble)_31653);
            }
        }
        else {
            _31653 = binary_op(PLUS, _31652, _amount_64450);
        }
        _31652 = NOVALUE;
        _2 = (object)SEQ_PTR(_fr_64454);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _fr_64454 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 12LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31653;
        if( _1 != _31653 ){
            DeRef(_1);
        }
        _31653 = NOVALUE;
L4: 
L3: 

        /** fwdref.e:1094			forward_references[refs[i]] = fr*/
        _2 = (object)SEQ_PTR(_refs_64448);
        _31654 = (object)*(((s1_ptr)_2)->base + _i_64452);
        RefDS(_fr_64454);
        _2 = (object)SEQ_PTR(_44forward_references_62765);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _44forward_references_62765 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31654))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31654)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _31654);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _fr_64454;
        DeRef(_1);
        DeRefDS(_fr_64454);
        _fr_64454 = NOVALUE;

        /** fwdref.e:1095		end for*/
        _i_64452 = _i_64452 + -1LL;
        goto L1; // [129] 19
L2: 
        ;
    }

    /** fwdref.e:1096	end procedure*/
    DeRefDS(_refs_64448);
    _31642 = NOVALUE;
    _31654 = NOVALUE;
    DeRef(_31648);
    _31648 = NOVALUE;
    _31640 = NOVALUE;
    return;
    ;
}


void _44shift_fwd_refs(object _pc_64475, object _amount_64476)
{
    object _file_64487 = NOVALUE;
    object _sp_64492 = NOVALUE;
    object _31664 = NOVALUE;
    object _31663 = NOVALUE;
    object _31661 = NOVALUE;
    object _31659 = NOVALUE;
    object _31658 = NOVALUE;
    object _31657 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:1099		if not shifting_sub then*/
    if (_44shifting_sub_62784 != 0)
    goto L1; // [9] 18

    /** fwdref.e:1100			return*/
    return;
L1: 

    /** fwdref.e:1103		if shifting_sub = TopLevelSub then*/
    if (_44shifting_sub_62784 != _36TopLevelSub_21446)
    goto L2; // [24] 65

    /** fwdref.e:1104			for file = 1 to length( toplevel_references ) do*/
    if (IS_SEQUENCE(_44toplevel_references_62768)){
            _31657 = SEQ_PTR(_44toplevel_references_62768)->length;
    }
    else {
        _31657 = 1;
    }
    {
        object _file_64483;
        _file_64483 = 1LL;
L3: 
        if (_file_64483 > _31657){
            goto L4; // [35] 62
        }

        /** fwdref.e:1105				shift_top( toplevel_references[file], pc, amount )*/
        _2 = (object)SEQ_PTR(_44toplevel_references_62768);
        _31658 = (object)*(((s1_ptr)_2)->base + _file_64483);
        Ref(_31658);
        _44shift_top(_31658, _pc_64475, _amount_64476);
        _31658 = NOVALUE;

        /** fwdref.e:1106			end for*/
        _file_64483 = _file_64483 + 1LL;
        goto L3; // [57] 42
L4: 
        ;
    }
    goto L5; // [62] 118
L2: 

    /** fwdref.e:1108			integer file = SymTab[shifting_sub][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _31659 = (object)*(((s1_ptr)_2)->base + _44shifting_sub_62784);
    _2 = (object)SEQ_PTR(_31659);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _file_64487 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _file_64487 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    if (!IS_ATOM_INT(_file_64487)){
        _file_64487 = (object)DBL_PTR(_file_64487)->dbl;
    }
    _31659 = NOVALUE;

    /** fwdref.e:1109			integer sp   = find( shifting_sub, active_subprogs[file] )*/
    _2 = (object)SEQ_PTR(_44active_subprogs_62766);
    _31661 = (object)*(((s1_ptr)_2)->base + _file_64487);
    _sp_64492 = find_from(_44shifting_sub_62784, _31661, 1LL);
    _31661 = NOVALUE;

    /** fwdref.e:1110			shift_these( active_references[file][sp], pc, amount )*/
    _2 = (object)SEQ_PTR(_44active_references_62767);
    _31663 = (object)*(((s1_ptr)_2)->base + _file_64487);
    _2 = (object)SEQ_PTR(_31663);
    _31664 = (object)*(((s1_ptr)_2)->base + _sp_64492);
    _31663 = NOVALUE;
    Ref(_31664);
    _44shift_these(_31664, _pc_64475, _amount_64476);
    _31664 = NOVALUE;
L5: 

    /** fwdref.e:1112	end procedure*/
    return;
    ;
}



// 0xB0BADDD2
