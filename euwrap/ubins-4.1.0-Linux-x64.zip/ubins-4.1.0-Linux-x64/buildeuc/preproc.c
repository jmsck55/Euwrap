// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _64is_file_newer(object _f1_24036, object _f2_24037)
{
    object _d1_24038 = NOVALUE;
    object _d2_24041 = NOVALUE;
    object _diff_2__tmp_at33_24050 = NOVALUE;
    object _diff_1__tmp_at33_24049 = NOVALUE;
    object _diff_inlined_diff_at_33_24048 = NOVALUE;
    object _13517 = NOVALUE;
    object _0, _1, _2;
    

    /** preproc.e:22		object d1 = file_timestamp(f1)*/
    RefDS(_f1_24036);
    _0 = _d1_24038;
    _d1_24038 = _17file_timestamp(_f1_24036);
    DeRef(_0);

    /** preproc.e:23		object d2 = file_timestamp(f2)*/
    RefDS(_f2_24037);
    _0 = _d2_24041;
    _d2_24041 = _17file_timestamp(_f2_24037);
    DeRef(_0);

    /** preproc.e:25		if atom(d2) then return 1 end if*/
    _13517 = IS_ATOM(_d2_24041);
    if (_13517 == 0)
    {
        _13517 = NOVALUE;
        goto L1; // [22] 30
    }
    else{
        _13517 = NOVALUE;
    }
    DeRefDS(_f1_24036);
    DeRefDS(_f2_24037);
    DeRef(_d1_24038);
    DeRef(_d2_24041);
    return 1LL;
L1: 

    /** preproc.e:27		if dt:diff(d1, d2) < 0 then*/

    /** datetime.e:1253		return datetimeToSeconds(dt2) - datetimeToSeconds(dt1)*/
    Ref(_d2_24041);
    _0 = _diff_1__tmp_at33_24049;
    _diff_1__tmp_at33_24049 = _18datetimeToSeconds(_d2_24041);
    DeRef(_0);
    Ref(_d1_24038);
    _0 = _diff_2__tmp_at33_24050;
    _diff_2__tmp_at33_24050 = _18datetimeToSeconds(_d1_24038);
    DeRef(_0);
    DeRef(_diff_inlined_diff_at_33_24048);
    if (IS_ATOM_INT(_diff_1__tmp_at33_24049) && IS_ATOM_INT(_diff_2__tmp_at33_24050)) {
        _diff_inlined_diff_at_33_24048 = _diff_1__tmp_at33_24049 - _diff_2__tmp_at33_24050;
        if ((object)((uintptr_t)_diff_inlined_diff_at_33_24048 +(uintptr_t) HIGH_BITS) >= 0){
            _diff_inlined_diff_at_33_24048 = NewDouble((eudouble)_diff_inlined_diff_at_33_24048);
        }
    }
    else {
        _diff_inlined_diff_at_33_24048 = binary_op(MINUS, _diff_1__tmp_at33_24049, _diff_2__tmp_at33_24050);
    }
    DeRef(_diff_1__tmp_at33_24049);
    _diff_1__tmp_at33_24049 = NOVALUE;
    DeRef(_diff_2__tmp_at33_24050);
    _diff_2__tmp_at33_24050 = NOVALUE;
    if (binary_op_a(GREATEREQ, _diff_inlined_diff_at_33_24048, 0LL)){
        goto L2; // [49] 60
    }

    /** preproc.e:28			return 1*/
    DeRefDS(_f1_24036);
    DeRefDS(_f2_24037);
    DeRef(_d1_24038);
    DeRef(_d2_24041);
    return 1LL;
L2: 

    /** preproc.e:31		return 0*/
    DeRefDS(_f1_24036);
    DeRefDS(_f2_24037);
    DeRef(_d1_24038);
    DeRef(_d2_24041);
    return 0LL;
    ;
}


void _64add_preprocessor(object _file_ext_24054, object _command_24055, object _params_24056)
{
    object _tmp_24059 = NOVALUE;
    object _file_exts_24069 = NOVALUE;
    object _exts_24075 = NOVALUE;
    object _13534 = NOVALUE;
    object _13533 = NOVALUE;
    object _13532 = NOVALUE;
    object _13531 = NOVALUE;
    object _13529 = NOVALUE;
    object _13524 = NOVALUE;
    object _13519 = NOVALUE;
    object _0, _1, _2;
    

    /** preproc.e:46		if atom(command) then*/
    _13519 = 1;
    if (_13519 == 0)
    {
        _13519 = NOVALUE;
        goto L1; // [8] 53
    }
    else{
        _13519 = NOVALUE;
    }

    /** preproc.e:47			sequence tmp = split( file_ext, ":")*/
    RefDS(_file_ext_24054);
    RefDS(_13520);
    _0 = _tmp_24059;
    _tmp_24059 = _23split(_file_ext_24054, _13520, 0LL, 0LL);
    DeRef(_0);

    /** preproc.e:48			file_ext = tmp[1]*/
    DeRefDS(_file_ext_24054);
    _2 = (object)SEQ_PTR(_tmp_24059);
    _file_ext_24054 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_file_ext_24054);

    /** preproc.e:49			command = tmp[2]*/
    _2 = (object)SEQ_PTR(_tmp_24059);
    _command_24055 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_command_24055);

    /** preproc.e:50			if length(tmp) >= 3 then*/
    if (IS_SEQUENCE(_tmp_24059)){
            _13524 = SEQ_PTR(_tmp_24059)->length;
    }
    else {
        _13524 = 1;
    }
    if (_13524 < 3LL)
    goto L2; // [41] 52

    /** preproc.e:51				params = tmp[3]*/
    _2 = (object)SEQ_PTR(_tmp_24059);
    _params_24056 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_params_24056);
L2: 
L1: 
    DeRef(_tmp_24059);
    _tmp_24059 = NOVALUE;

    /** preproc.e:55		sequence file_exts = split( file_ext, "," )*/
    RefDS(_file_ext_24054);
    RefDS(_13527);
    _0 = _file_exts_24069;
    _file_exts_24069 = _23split(_file_ext_24054, _13527, 0LL, 0LL);
    DeRef(_0);

    /** preproc.e:57		if atom(params) then*/
    _13529 = IS_ATOM(_params_24056);
    if (_13529 == 0)
    {
        _13529 = NOVALUE;
        goto L3; // [71] 80
    }
    else{
        _13529 = NOVALUE;
    }

    /** preproc.e:58			params = ""*/
    RefDS(_5);
    DeRef(_params_24056);
    _params_24056 = _5;
L3: 

    /** preproc.e:61		sequence exts = split(file_ext, ",")*/
    RefDS(_file_ext_24054);
    RefDS(_13527);
    _0 = _exts_24075;
    _exts_24075 = _23split(_file_ext_24054, _13527, 0LL, 0LL);
    DeRef(_0);

    /** preproc.e:62		for i = 1 to length(exts) do*/
    if (IS_SEQUENCE(_exts_24075)){
            _13531 = SEQ_PTR(_exts_24075)->length;
    }
    else {
        _13531 = 1;
    }
    {
        object _i_24079;
        _i_24079 = 1LL;
L4: 
        if (_i_24079 > _13531){
            goto L5; // [96] 135
        }

        /** preproc.e:63			preprocessors &= { { exts[i], command, params, -1 } }*/
        _2 = (object)SEQ_PTR(_exts_24075);
        _13532 = (object)*(((s1_ptr)_2)->base + _i_24079);
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_13532);
        ((intptr_t*)_2)[1] = _13532;
        Ref(_command_24055);
        ((intptr_t*)_2)[2] = _command_24055;
        Ref(_params_24056);
        ((intptr_t*)_2)[3] = _params_24056;
        ((intptr_t*)_2)[4] = -1LL;
        _13533 = MAKE_SEQ(_1);
        _13532 = NOVALUE;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _13533;
        _13534 = MAKE_SEQ(_1);
        _13533 = NOVALUE;
        Concat((object_ptr)&_37preprocessors_15423, _37preprocessors_15423, _13534);
        DeRefDS(_13534);
        _13534 = NOVALUE;

        /** preproc.e:64		end for*/
        _i_24079 = _i_24079 + 1LL;
        goto L4; // [130] 103
L5: 
        ;
    }

    /** preproc.e:65	end procedure */
    DeRefDS(_file_ext_24054);
    DeRef(_command_24055);
    DeRef(_params_24056);
    DeRef(_file_exts_24069);
    DeRef(_exts_24075);
    return;
    ;
}


object _64maybe_preprocess(object _fname_24088)
{
    object _pp_24089 = NOVALUE;
    object _pp_id_24090 = NOVALUE;
    object _fext_24094 = NOVALUE;
    object _post_fname_24111 = NOVALUE;
    object _rid_24139 = NOVALUE;
    object _dll_id_24143 = NOVALUE;
    object _public_cmd_args_24179 = NOVALUE;
    object _cmd_args_24182 = NOVALUE;
    object _cmd_24211 = NOVALUE;
    object _pcmd_24216 = NOVALUE;
    object _result_24221 = NOVALUE;
    object _13613 = NOVALUE;
    object _13612 = NOVALUE;
    object _13607 = NOVALUE;
    object _13606 = NOVALUE;
    object _13604 = NOVALUE;
    object _13603 = NOVALUE;
    object _13601 = NOVALUE;
    object _13599 = NOVALUE;
    object _13598 = NOVALUE;
    object _13596 = NOVALUE;
    object _13593 = NOVALUE;
    object _13591 = NOVALUE;
    object _13589 = NOVALUE;
    object _13587 = NOVALUE;
    object _13586 = NOVALUE;
    object _13584 = NOVALUE;
    object _13583 = NOVALUE;
    object _13581 = NOVALUE;
    object _13578 = NOVALUE;
    object _13577 = NOVALUE;
    object _13576 = NOVALUE;
    object _13574 = NOVALUE;
    object _13570 = NOVALUE;
    object _13568 = NOVALUE;
    object _13567 = NOVALUE;
    object _13566 = NOVALUE;
    object _13562 = NOVALUE;
    object _13559 = NOVALUE;
    object _13558 = NOVALUE;
    object _13557 = NOVALUE;
    object _13555 = NOVALUE;
    object _13552 = NOVALUE;
    object _13550 = NOVALUE;
    object _13549 = NOVALUE;
    object _13547 = NOVALUE;
    object _13545 = NOVALUE;
    object _13543 = NOVALUE;
    object _13541 = NOVALUE;
    object _13540 = NOVALUE;
    object _13539 = NOVALUE;
    object _13538 = NOVALUE;
    object _13536 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** preproc.e:81		sequence pp = {}*/
    RefDS(_5);
    DeRef(_pp_24089);
    _pp_24089 = _5;

    /** preproc.e:84		if length(preprocessors) then*/
    if (IS_SEQUENCE(_37preprocessors_15423)){
            _13536 = SEQ_PTR(_37preprocessors_15423)->length;
    }
    else {
        _13536 = 1;
    }
    if (_13536 == 0)
    {
        _13536 = NOVALUE;
        goto L1; // [17] 89
    }
    else{
        _13536 = NOVALUE;
    }

    /** preproc.e:85			sequence fext = fileext(fname)*/
    RefDS(_fname_24088);
    _0 = _fext_24094;
    _fext_24094 = _17fileext(_fname_24088);
    DeRef(_0);

    /** preproc.e:87			for i = 1 to length(preprocessors) do*/
    if (IS_SEQUENCE(_37preprocessors_15423)){
            _13538 = SEQ_PTR(_37preprocessors_15423)->length;
    }
    else {
        _13538 = 1;
    }
    {
        object _i_24098;
        _i_24098 = 1LL;
L2: 
        if (_i_24098 > _13538){
            goto L3; // [35] 88
        }

        /** preproc.e:88				if equal(fext, preprocessors[i][1]) then*/
        _2 = (object)SEQ_PTR(_37preprocessors_15423);
        _13539 = (object)*(((s1_ptr)_2)->base + _i_24098);
        _2 = (object)SEQ_PTR(_13539);
        _13540 = (object)*(((s1_ptr)_2)->base + 1LL);
        _13539 = NOVALUE;
        if (_fext_24094 == _13540)
        _13541 = 1;
        else if (IS_ATOM_INT(_fext_24094) && IS_ATOM_INT(_13540))
        _13541 = 0;
        else
        _13541 = (compare(_fext_24094, _13540) == 0);
        _13540 = NOVALUE;
        if (_13541 == 0)
        {
            _13541 = NOVALUE;
            goto L4; // [58] 81
        }
        else{
            _13541 = NOVALUE;
        }

        /** preproc.e:89					pp_id = i*/
        _pp_id_24090 = _i_24098;

        /** preproc.e:90					pp = preprocessors[pp_id]*/
        DeRef(_pp_24089);
        _2 = (object)SEQ_PTR(_37preprocessors_15423);
        _pp_24089 = (object)*(((s1_ptr)_2)->base + _pp_id_24090);
        RefDS(_pp_24089);

        /** preproc.e:91					exit*/
        goto L3; // [78] 88
L4: 

        /** preproc.e:93			end for*/
        _i_24098 = _i_24098 + 1LL;
        goto L2; // [83] 42
L3: 
        ;
    }
L1: 
    DeRef(_fext_24094);
    _fext_24094 = NOVALUE;

    /** preproc.e:96		if length(pp) = 0 then */
    if (IS_SEQUENCE(_pp_24089)){
            _13543 = SEQ_PTR(_pp_24089)->length;
    }
    else {
        _13543 = 1;
    }
    if (_13543 != 0LL)
    goto L5; // [96] 107

    /** preproc.e:97			return fname*/
    DeRefDS(_pp_24089);
    DeRef(_post_fname_24111);
    return _fname_24088;
L5: 

    /** preproc.e:100		sequence post_fname = filebase(fname) & ".pp." & fileext(fname)*/
    RefDS(_fname_24088);
    _13545 = _17filebase(_fname_24088);
    RefDS(_fname_24088);
    _13547 = _17fileext(_fname_24088);
    {
        object concat_list[3];

        concat_list[0] = _13547;
        concat_list[1] = _13546;
        concat_list[2] = _13545;
        Concat_N((object_ptr)&_post_fname_24111, concat_list, 3);
    }
    DeRef(_13547);
    _13547 = NOVALUE;
    DeRef(_13545);
    _13545 = NOVALUE;

    /** preproc.e:101		if length(dirname(fname)) > 0 then*/
    RefDS(_fname_24088);
    _13549 = _17dirname(_fname_24088, 0LL);
    if (IS_SEQUENCE(_13549)){
            _13550 = SEQ_PTR(_13549)->length;
    }
    else {
        _13550 = 1;
    }
    DeRef(_13549);
    _13549 = NOVALUE;
    if (_13550 <= 0LL)
    goto L6; // [133] 153

    /** preproc.e:102			post_fname = dirname(fname) & SLASH & post_fname*/
    RefDS(_fname_24088);
    _13552 = _17dirname(_fname_24088, 0LL);
    {
        object concat_list[3];

        concat_list[0] = _post_fname_24111;
        concat_list[1] = 47LL;
        concat_list[2] = _13552;
        Concat_N((object_ptr)&_post_fname_24111, concat_list, 3);
    }
    DeRef(_13552);
    _13552 = NOVALUE;
L6: 

    /** preproc.e:105		if not force_preprocessor then*/
    if (_37force_preprocessor_15424 != 0)
    goto L7; // [157] 178

    /** preproc.e:106			if not is_file_newer(fname, post_fname) then*/
    RefDS(_fname_24088);
    RefDS(_post_fname_24111);
    _13555 = _64is_file_newer(_fname_24088, _post_fname_24111);
    if (IS_ATOM_INT(_13555)) {
        if (_13555 != 0){
            DeRef(_13555);
            _13555 = NOVALUE;
            goto L8; // [167] 177
        }
    }
    else {
        if (DBL_PTR(_13555)->dbl != 0.0){
            DeRef(_13555);
            _13555 = NOVALUE;
            goto L8; // [167] 177
        }
    }
    DeRef(_13555);
    _13555 = NOVALUE;

    /** preproc.e:107				return post_fname*/
    DeRefDS(_fname_24088);
    DeRef(_pp_24089);
    _13549 = NOVALUE;
    return _post_fname_24111;
L8: 
L7: 

    /** preproc.e:112		if equal(fileext(pp[PP_COMMAND]), SHARED_LIB_EXT) then*/
    _2 = (object)SEQ_PTR(_pp_24089);
    _13557 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_13557);
    _13558 = _17fileext(_13557);
    _13557 = NOVALUE;
    if (_13558 == _17SHARED_LIB_EXT_5976)
    _13559 = 1;
    else if (IS_ATOM_INT(_13558) && IS_ATOM_INT(_17SHARED_LIB_EXT_5976))
    _13559 = 0;
    else
    _13559 = (compare(_13558, _17SHARED_LIB_EXT_5976) == 0);
    DeRef(_13558);
    _13558 = NOVALUE;
    if (_13559 == 0)
    {
        _13559 = NOVALUE;
        goto L9; // [194] 348
    }
    else{
        _13559 = NOVALUE;
    }

    /** preproc.e:113			integer rid = pp[PP_RID]*/
    _2 = (object)SEQ_PTR(_pp_24089);
    _rid_24139 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_rid_24139))
    _rid_24139 = (object)DBL_PTR(_rid_24139)->dbl;

    /** preproc.e:114			if rid = -1 then*/
    if (_rid_24139 != -1LL)
    goto LA; // [205] 307

    /** preproc.e:115				integer dll_id = open_dll(pp[PP_COMMAND])*/
    _2 = (object)SEQ_PTR(_pp_24089);
    _13562 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_13562);
    _dll_id_24143 = _12open_dll(_13562);
    _13562 = NOVALUE;
    if (!IS_ATOM_INT(_dll_id_24143)) {
        _1 = (object)(DBL_PTR(_dll_id_24143)->dbl);
        DeRefDS(_dll_id_24143);
        _dll_id_24143 = _1;
    }

    /** preproc.e:116				if dll_id = -1 then*/
    if (_dll_id_24143 != -1LL)
    goto LB; // [223] 247

    /** preproc.e:117					CompileErr(sprintf("Preprocessor shared library '%s' could not be loaded\n",*/
    _2 = (object)SEQ_PTR(_pp_24089);
    _13566 = (object)*(((s1_ptr)_2)->base + 2LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_13566);
    ((intptr_t*)_2)[1] = _13566;
    _13567 = MAKE_SEQ(_1);
    _13566 = NOVALUE;
    _13568 = EPrintf(-9999999, _13565, _13567);
    DeRefDS(_13567);
    _13567 = NOVALUE;
    RefDS(_21993);
    _50CompileErr(_13568, _21993, 1LL);
    _13568 = NOVALUE;
LB: 

    /** preproc.e:121				rid = define_c_func(dll_id, "preprocess", { E_SEQUENCE, E_SEQUENCE, E_SEQUENCE }, */
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 134217732LL;
    ((intptr_t*)_2)[2] = 134217732LL;
    ((intptr_t*)_2)[3] = 134217732LL;
    _13570 = MAKE_SEQ(_1);
    RefDS(_13569);
    _rid_24139 = _12define_c_func(_dll_id_24143, _13569, _13570, 100663300LL);
    _13570 = NOVALUE;
    if (!IS_ATOM_INT(_rid_24139)) {
        _1 = (object)(DBL_PTR(_rid_24139)->dbl);
        DeRefDS(_rid_24139);
        _rid_24139 = _1;
    }

    /** preproc.e:123				if rid = -1 then*/
    if (_rid_24139 != -1LL)
    goto LC; // [274] 291

    /** preproc.e:124					CompileErr("Preprocessor entry point cound not be found\n",,1)*/
    RefDS(_13573);
    RefDS(_21993);
    _50CompileErr(_13573, _21993, 1LL);

    /** preproc.e:126					Cleanup(1)*/
    _50Cleanup(1LL);
LC: 

    /** preproc.e:129				preprocessors[pp_id][PP_RID] = rid*/
    _2 = (object)SEQ_PTR(_37preprocessors_15423);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37preprocessors_15423 = MAKE_SEQ(_2);
    }
    _3 = (object)(_pp_id_24090 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _rid_24139;
    DeRef(_1);
    _13574 = NOVALUE;
LA: 

    /** preproc.e:132			if c_func(rid, { fname, post_fname, pp[PP_PARAMS] }) != 0 then*/
    _2 = (object)SEQ_PTR(_pp_24089);
    _13576 = (object)*(((s1_ptr)_2)->base + 3LL);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_fname_24088);
    ((intptr_t*)_2)[1] = _fname_24088;
    RefDS(_post_fname_24111);
    ((intptr_t*)_2)[2] = _post_fname_24111;
    Ref(_13576);
    ((intptr_t*)_2)[3] = _13576;
    _13577 = MAKE_SEQ(_1);
    _13576 = NOVALUE;
    _13578 = call_c(1, _rid_24139, _13577);
    DeRefDS(_13577);
    _13577 = NOVALUE;
    if (binary_op_a(EQUALS, _13578, 0LL)){
        DeRef(_13578);
        _13578 = NOVALUE;
        goto LD; // [326] 343
    }
    DeRef(_13578);
    _13578 = NOVALUE;

    /** preproc.e:133				CompileErr("Preprocessor call failed\n",,1)*/
    RefDS(_13580);
    RefDS(_21993);
    _50CompileErr(_13580, _21993, 1LL);

    /** preproc.e:135				Cleanup(1)*/
    _50Cleanup(1LL);
LD: 
    goto LE; // [345] 520
L9: 

    /** preproc.e:138			sequence public_cmd_args = {pp[PP_COMMAND]}*/
    _2 = (object)SEQ_PTR(_pp_24089);
    _13581 = (object)*(((s1_ptr)_2)->base + 2LL);
    _0 = _public_cmd_args_24179;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_13581);
    ((intptr_t*)_2)[1] = _13581;
    _public_cmd_args_24179 = MAKE_SEQ(_1);
    DeRef(_0);
    _13581 = NOVALUE;

    /** preproc.e:139			sequence cmd_args = {canonical_path(pp[PP_COMMAND],,TO_SHORT)}*/
    _2 = (object)SEQ_PTR(_pp_24089);
    _13583 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_13583);
    _13584 = _17canonical_path(_13583, 0LL, 4LL);
    _13583 = NOVALUE;
    _0 = _cmd_args_24182;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _13584;
    _cmd_args_24182 = MAKE_SEQ(_1);
    DeRef(_0);
    _13584 = NOVALUE;

    /** preproc.e:141			if equal(fileext(pp[PP_COMMAND]), "ex") then*/
    _2 = (object)SEQ_PTR(_pp_24089);
    _13586 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_13586);
    _13587 = _17fileext(_13586);
    _13586 = NOVALUE;
    if (_13587 == _13588)
    _13589 = 1;
    else if (IS_ATOM_INT(_13587) && IS_ATOM_INT(_13588))
    _13589 = 0;
    else
    _13589 = (compare(_13587, _13588) == 0);
    DeRef(_13587);
    _13587 = NOVALUE;
    if (_13589 == 0)
    {
        _13589 = NOVALUE;
        goto LF; // [390] 414
    }
    else{
        _13589 = NOVALUE;
    }

    /** preproc.e:142				public_cmd_args = { "eui" } & public_cmd_args*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_13590);
    ((intptr_t*)_2)[1] = _13590;
    _13591 = MAKE_SEQ(_1);
    Concat((object_ptr)&_public_cmd_args_24179, _13591, _public_cmd_args_24179);
    DeRefDS(_13591);
    _13591 = NOVALUE;
    DeRef(_13591);
    _13591 = NOVALUE;

    /** preproc.e:143				cmd_args = { "eui" } & cmd_args*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_13590);
    ((intptr_t*)_2)[1] = _13590;
    _13593 = MAKE_SEQ(_1);
    Concat((object_ptr)&_cmd_args_24182, _13593, _cmd_args_24182);
    DeRefDS(_13593);
    _13593 = NOVALUE;
    DeRef(_13593);
    _13593 = NOVALUE;
LF: 

    /** preproc.e:146			cmd_args &= { "-i", canonical_path(fname,,TO_SHORT), "-o", canonical_path(post_fname,,TO_SHORT) }*/
    RefDS(_fname_24088);
    _13596 = _17canonical_path(_fname_24088, 0LL, 4LL);
    RefDS(_post_fname_24111);
    _13598 = _17canonical_path(_post_fname_24111, 0LL, 4LL);
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_13595);
    ((intptr_t*)_2)[1] = _13595;
    ((intptr_t*)_2)[2] = _13596;
    RefDS(_13597);
    ((intptr_t*)_2)[3] = _13597;
    ((intptr_t*)_2)[4] = _13598;
    _13599 = MAKE_SEQ(_1);
    _13598 = NOVALUE;
    _13596 = NOVALUE;
    Concat((object_ptr)&_cmd_args_24182, _cmd_args_24182, _13599);
    DeRefDS(_13599);
    _13599 = NOVALUE;

    /** preproc.e:147			public_cmd_args &= { "-i", fname, "-o", post_fname }*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_13595);
    ((intptr_t*)_2)[1] = _13595;
    RefDS(_fname_24088);
    ((intptr_t*)_2)[2] = _fname_24088;
    RefDS(_13597);
    ((intptr_t*)_2)[3] = _13597;
    RefDS(_post_fname_24111);
    ((intptr_t*)_2)[4] = _post_fname_24111;
    _13601 = MAKE_SEQ(_1);
    Concat((object_ptr)&_public_cmd_args_24179, _public_cmd_args_24179, _13601);
    DeRefDS(_13601);
    _13601 = NOVALUE;

    /** preproc.e:148			sequence cmd = build_commandline( cmd_args ) & pp[PP_PARAMS]*/
    RefDS(_cmd_args_24182);
    _13603 = _4build_commandline(_cmd_args_24182);
    _2 = (object)SEQ_PTR(_pp_24089);
    _13604 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (IS_SEQUENCE(_13603) && IS_ATOM(_13604)) {
        Ref(_13604);
        Append(&_cmd_24211, _13603, _13604);
    }
    else if (IS_ATOM(_13603) && IS_SEQUENCE(_13604)) {
        Ref(_13603);
        Prepend(&_cmd_24211, _13604, _13603);
    }
    else {
        Concat((object_ptr)&_cmd_24211, _13603, _13604);
        DeRef(_13603);
        _13603 = NOVALUE;
    }
    DeRef(_13603);
    _13603 = NOVALUE;
    _13604 = NOVALUE;

    /** preproc.e:149			sequence pcmd = build_commandline(public_cmd_args) & pp[PP_PARAMS]*/
    RefDS(_public_cmd_args_24179);
    _13606 = _4build_commandline(_public_cmd_args_24179);
    _2 = (object)SEQ_PTR(_pp_24089);
    _13607 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (IS_SEQUENCE(_13606) && IS_ATOM(_13607)) {
        Ref(_13607);
        Append(&_pcmd_24216, _13606, _13607);
    }
    else if (IS_ATOM(_13606) && IS_SEQUENCE(_13607)) {
        Ref(_13606);
        Prepend(&_pcmd_24216, _13607, _13606);
    }
    else {
        Concat((object_ptr)&_pcmd_24216, _13606, _13607);
        DeRef(_13606);
        _13606 = NOVALUE;
    }
    DeRef(_13606);
    _13606 = NOVALUE;
    _13607 = NOVALUE;

    /** preproc.e:150			integer result = system_exec(cmd, 2)*/
    _result_24221 = system_exec_call(_cmd_24211, 2LL);

    /** preproc.e:151			if result != 0 then*/
    if (_result_24221 == 0LL)
    goto L10; // [492] 517

    /** preproc.e:152				CompileErr(sprintf("Preprocessor command failed (%d): %s\n", { result, pcmd } ),,1)*/
    RefDS(_pcmd_24216);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _result_24221;
    ((intptr_t *)_2)[2] = _pcmd_24216;
    _13612 = MAKE_SEQ(_1);
    _13613 = EPrintf(-9999999, _13611, _13612);
    DeRefDS(_13612);
    _13612 = NOVALUE;
    RefDS(_21993);
    _50CompileErr(_13613, _21993, 1LL);
    _13613 = NOVALUE;

    /** preproc.e:154				Cleanup(1)*/
    _50Cleanup(1LL);
L10: 
    DeRef(_public_cmd_args_24179);
    _public_cmd_args_24179 = NOVALUE;
    DeRef(_cmd_args_24182);
    _cmd_args_24182 = NOVALUE;
    DeRef(_cmd_24211);
    _cmd_24211 = NOVALUE;
    DeRef(_pcmd_24216);
    _pcmd_24216 = NOVALUE;
LE: 

    /** preproc.e:158		return post_fname*/
    DeRefDS(_fname_24088);
    DeRef(_pp_24089);
    _13549 = NOVALUE;
    return _post_fname_24111;
    ;
}



// 0x56AE6F87
