// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _62set_qualified_fwd(object _fwd_25582)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_fwd_25582)) {
        _1 = (object)(DBL_PTR(_fwd_25582)->dbl);
        DeRefDS(_fwd_25582);
        _fwd_25582 = _1;
    }

    /** scanner.e:104		qualified_fwd = fwd*/
    _62qualified_fwd_25579 = _fwd_25582;

    /** scanner.e:105	end procedure*/
    return;
    ;
}


object _62get_qualified_fwd()
{
    object _fwd_25585 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:108		integer fwd = qualified_fwd*/
    _fwd_25585 = _62qualified_fwd_25579;

    /** scanner.e:109		set_qualified_fwd( -1 )*/

    /** scanner.e:104		qualified_fwd = fwd*/
    _62qualified_fwd_25579 = -1LL;

    /** scanner.e:105	end procedure*/
    goto L1; // [17] 20
L1: 

    /** scanner.e:110		return fwd*/
    return _fwd_25585;
    ;
}


void _62InitLex()
{
    object _14249 = NOVALUE;
    object _14248 = NOVALUE;
    object _14247 = NOVALUE;
    object _14245 = NOVALUE;
    object _14244 = NOVALUE;
    object _14243 = NOVALUE;
    object _14242 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:117		gline_number = 0*/
    _36gline_number_21444 = 0LL;

    /** scanner.e:118		line_number = 0*/
    _36line_number_21440 = 0LL;

    /** scanner.e:119		IncludeStk = {}*/
    RefDS(_5);
    DeRef(_62IncludeStk_25556);
    _62IncludeStk_25556 = _5;

    /** scanner.e:120		char_class = repeat(ILLEGAL_CHAR, 255)  -- we screen out the 0 character*/
    DeRefi(_62char_class_25554);
    _62char_class_25554 = Repeat(-20LL, 255LL);

    /** scanner.e:122		char_class['0'..'9'] = DIGIT*/
    assign_slice_seq = (s1_ptr *)&_62char_class_25554;
    AssignSlice(48LL, 57LL, -7LL);

    /** scanner.e:123		char_class['_']      = DIGIT*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _2 = (object)(((s1_ptr)_2)->base + 95LL);
    *(intptr_t *)_2 = -7LL;

    /** scanner.e:124		char_class['a'..'z'] = LETTER*/
    assign_slice_seq = (s1_ptr *)&_62char_class_25554;
    AssignSlice(97LL, 122LL, -2LL);

    /** scanner.e:125		char_class['A'..'Z'] = LETTER*/
    assign_slice_seq = (s1_ptr *)&_62char_class_25554;
    AssignSlice(65LL, 90LL, -2LL);

    /** scanner.e:126		char_class[KEYWORD_BASE+1..KEYWORD_BASE+NUM_KEYWORDS] = KEYWORD*/
    _14242 = 129;
    _14243 = 152LL;
    assign_slice_seq = (s1_ptr *)&_62char_class_25554;
    AssignSlice(129LL, 152LL, -10LL);
    _14242 = NOVALUE;
    _14243 = NOVALUE;

    /** scanner.e:127		char_class[BUILTIN_BASE+1..BUILTIN_BASE+NUM_BUILTINS] = BUILTIN*/
    _14244 = 171;
    _14245 = 234LL;
    assign_slice_seq = (s1_ptr *)&_62char_class_25554;
    AssignSlice(171LL, 234LL, -9LL);
    _14244 = NOVALUE;
    _14245 = NOVALUE;

    /** scanner.e:129		char_class[' '] = BLANK*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    *(intptr_t *)_2 = -8LL;

    /** scanner.e:130		char_class['\t'] = BLANK*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    *(intptr_t *)_2 = -8LL;

    /** scanner.e:131		char_class['+'] = PLUS*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _2 = (object)(((s1_ptr)_2)->base + 43LL);
    *(intptr_t *)_2 = 11LL;

    /** scanner.e:132		char_class['-'] = MINUS*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _2 = (object)(((s1_ptr)_2)->base + 45LL);
    *(intptr_t *)_2 = 10LL;

    /** scanner.e:133		char_class['*'] = res:MULTIPLY*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _2 = (object)(((s1_ptr)_2)->base + 42LL);
    *(intptr_t *)_2 = 13LL;

    /** scanner.e:134		char_class['/'] = res:DIVIDE*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _2 = (object)(((s1_ptr)_2)->base + 47LL);
    *(intptr_t *)_2 = 14LL;

    /** scanner.e:135		char_class['='] = EQUALS*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _2 = (object)(((s1_ptr)_2)->base + 61LL);
    *(intptr_t *)_2 = 3LL;

    /** scanner.e:136		char_class['<'] = LESS*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _2 = (object)(((s1_ptr)_2)->base + 60LL);
    *(intptr_t *)_2 = 1LL;

    /** scanner.e:137		char_class['>'] = GREATER*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _2 = (object)(((s1_ptr)_2)->base + 62LL);
    *(intptr_t *)_2 = 6LL;

    /** scanner.e:138		char_class['\''] = SINGLE_QUOTE*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _2 = (object)(((s1_ptr)_2)->base + 39LL);
    *(intptr_t *)_2 = -5LL;

    /** scanner.e:139		char_class['"'] = DOUBLE_QUOTE*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _2 = (object)(((s1_ptr)_2)->base + 34LL);
    *(intptr_t *)_2 = -4LL;

    /** scanner.e:140		char_class['`'] = BACK_QUOTE*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _2 = (object)(((s1_ptr)_2)->base + 96LL);
    *(intptr_t *)_2 = -12LL;

    /** scanner.e:141		char_class['.'] = DOT*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _2 = (object)(((s1_ptr)_2)->base + 46LL);
    *(intptr_t *)_2 = -3LL;

    /** scanner.e:142		char_class[':'] = COLON*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _2 = (object)(((s1_ptr)_2)->base + 58LL);
    *(intptr_t *)_2 = -23LL;

    /** scanner.e:143		char_class['\r'] = NEWLINE*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _2 = (object)(((s1_ptr)_2)->base + 13LL);
    *(intptr_t *)_2 = -6LL;

    /** scanner.e:144		char_class['\n'] = NEWLINE*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _2 = (object)(((s1_ptr)_2)->base + 10LL);
    *(intptr_t *)_2 = -6LL;

    /** scanner.e:145		char_class['!'] = BANG*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    *(intptr_t *)_2 = -1LL;

    /** scanner.e:146		char_class['{'] = LEFT_BRACE*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _2 = (object)(((s1_ptr)_2)->base + 123LL);
    *(intptr_t *)_2 = -24LL;

    /** scanner.e:147		char_class['}'] = RIGHT_BRACE*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _2 = (object)(((s1_ptr)_2)->base + 125LL);
    *(intptr_t *)_2 = -25LL;

    /** scanner.e:148		char_class['('] = LEFT_ROUND*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _2 = (object)(((s1_ptr)_2)->base + 40LL);
    *(intptr_t *)_2 = -26LL;

    /** scanner.e:149		char_class[')'] = RIGHT_ROUND*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _2 = (object)(((s1_ptr)_2)->base + 41LL);
    *(intptr_t *)_2 = -27LL;

    /** scanner.e:150		char_class['['] = LEFT_SQUARE*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _2 = (object)(((s1_ptr)_2)->base + 91LL);
    *(intptr_t *)_2 = -28LL;

    /** scanner.e:151		char_class[']'] = RIGHT_SQUARE*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _2 = (object)(((s1_ptr)_2)->base + 93LL);
    *(intptr_t *)_2 = -29LL;

    /** scanner.e:152		char_class['$'] = DOLLAR*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    *(intptr_t *)_2 = -22LL;

    /** scanner.e:153		char_class[','] = COMMA*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _2 = (object)(((s1_ptr)_2)->base + 44LL);
    *(intptr_t *)_2 = -30LL;

    /** scanner.e:154		char_class['&'] = res:CONCAT*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _2 = (object)(((s1_ptr)_2)->base + 38LL);
    *(intptr_t *)_2 = 15LL;

    /** scanner.e:155		char_class['?'] = QUESTION_MARK*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _2 = (object)(((s1_ptr)_2)->base + 63LL);
    *(intptr_t *)_2 = -31LL;

    /** scanner.e:156		char_class['#'] = NUMBER_SIGN*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _2 = (object)(((s1_ptr)_2)->base + 35LL);
    *(intptr_t *)_2 = -11LL;

    /** scanner.e:159		char_class[END_OF_FILE_CHAR] = END_OF_FILE*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _2 = (object)(((s1_ptr)_2)->base + 26LL);
    *(intptr_t *)_2 = -21LL;

    /** scanner.e:162		id_char = repeat(FALSE, 255)*/
    DeRefi(_62id_char_25555);
    _62id_char_25555 = Repeat(_13FALSE_450, 255LL);

    /** scanner.e:163		for i = 1 to 255 do*/
    {
        object _i_25633;
        _i_25633 = 1LL;
L1: 
        if (_i_25633 > 255LL){
            goto L2; // [407] 456
        }

        /** scanner.e:164			if find(char_class[i], {LETTER, DIGIT}) then*/
        _2 = (object)SEQ_PTR(_62char_class_25554);
        _14247 = (object)*(((s1_ptr)_2)->base + _i_25633);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -2LL;
        ((intptr_t *)_2)[2] = -7LL;
        _14248 = MAKE_SEQ(_1);
        _14249 = find_from(_14247, _14248, 1LL);
        _14247 = NOVALUE;
        DeRefDS(_14248);
        _14248 = NOVALUE;
        if (_14249 == 0)
        {
            _14249 = NOVALUE;
            goto L3; // [435] 449
        }
        else{
            _14249 = NOVALUE;
        }

        /** scanner.e:165				id_char[i] = TRUE*/
        _2 = (object)SEQ_PTR(_62id_char_25555);
        _2 = (object)(((s1_ptr)_2)->base + _i_25633);
        *(intptr_t *)_2 = _13TRUE_452;
L3: 

        /** scanner.e:167		end for*/
        _i_25633 = _i_25633 + 1LL;
        goto L1; // [451] 414
L2: 
        ;
    }

    /** scanner.e:169		default_namespaces = {0}*/
    _0 = _62default_namespaces_25553;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0LL;
    _62default_namespaces_25553 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scanner.e:170	end procedure*/
    return;
    ;
}


void _62ResetTP()
{
    object _0, _1, _2;
    

    /** scanner.e:174		OpTrace = FALSE*/
    _36OpTrace_21512 = _13FALSE_450;

    /** scanner.e:175		OpProfileStatement = FALSE*/
    _36OpProfileStatement_21514 = _13FALSE_450;

    /** scanner.e:176		OpProfileTime = FALSE*/
    _36OpProfileTime_21515 = _13FALSE_450;

    /** scanner.e:177		AnyStatementProfile = FALSE*/
    _37AnyStatementProfile_15429 = _13FALSE_450;

    /** scanner.e:178		AnyTimeProfile = FALSE*/
    _37AnyTimeProfile_15428 = _13FALSE_450;

    /** scanner.e:179	end procedure*/
    return;
    ;
}


object _62pack_source(object _src_25663)
{
    object _start_25664 = NOVALUE;
    object _14273 = NOVALUE;
    object _14272 = NOVALUE;
    object _14271 = NOVALUE;
    object _14270 = NOVALUE;
    object _14268 = NOVALUE;
    object _14266 = NOVALUE;
    object _14265 = NOVALUE;
    object _14264 = NOVALUE;
    object _14260 = NOVALUE;
    object _14258 = NOVALUE;
    object _14257 = NOVALUE;
    object _14254 = NOVALUE;
    object _14253 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:197		if equal(src, 0) then*/
    if (_src_25663 == 0LL)
    _14253 = 1;
    else if (IS_ATOM_INT(_src_25663) && IS_ATOM_INT(0LL))
    _14253 = 0;
    else
    _14253 = (compare(_src_25663, 0LL) == 0);
    if (_14253 == 0)
    {
        _14253 = NOVALUE;
        goto L1; // [7] 17
    }
    else{
        _14253 = NOVALUE;
    }

    /** scanner.e:198			return 0*/
    DeRef(_src_25663);
    return 0LL;
L1: 

    /** scanner.e:201		if length(src) >= SOURCE_CHUNK then*/
    if (IS_SEQUENCE(_src_25663)){
            _14254 = SEQ_PTR(_src_25663)->length;
    }
    else {
        _14254 = 1;
    }
    if (_14254 < 10000LL)
    goto L2; // [22] 34

    /** scanner.e:202			src = src[1..100] -- enough for trace or profile display*/
    rhs_slice_target = (object_ptr)&_src_25663;
    RHS_Slice(_src_25663, 1LL, 100LL);
L2: 

    /** scanner.e:205		if current_source_next + length(src) >= SOURCE_CHUNK then*/
    if (IS_SEQUENCE(_src_25663)){
            _14257 = SEQ_PTR(_src_25663)->length;
    }
    else {
        _14257 = 1;
    }
    _14258 = _62current_source_next_25659 + _14257;
    if ((object)((uintptr_t)_14258 + (uintptr_t)HIGH_BITS) >= 0){
        _14258 = NewDouble((eudouble)_14258);
    }
    _14257 = NOVALUE;
    if (binary_op_a(LESS, _14258, 10000LL)){
        DeRef(_14258);
        _14258 = NOVALUE;
        goto L3; // [45] 96
    }
    DeRef(_14258);
    _14258 = NOVALUE;

    /** scanner.e:207			current_source = allocate(SOURCE_CHUNK + LINE_BUFLEN)*/
    _14260 = 10400LL;
    _0 = _9allocate(10400LL, 0LL);
    DeRef(_62current_source_25658);
    _62current_source_25658 = _0;
    _14260 = NOVALUE;

    /** scanner.e:208			if current_source = 0 then*/
    if (binary_op_a(NOTEQ, _62current_source_25658, 0LL)){
        goto L4; // [64] 78
    }

    /** scanner.e:209				CompileErr(OUT_OF_MEMORY__TURN_OFF_TRACE_AND_PROFILE)*/
    RefDS(_21993);
    _50CompileErr(123LL, _21993, 0LL);
L4: 

    /** scanner.e:211			all_source = append(all_source, current_source)*/
    Ref(_62current_source_25658);
    Append(&_37all_source_15430, _37all_source_15430, _62current_source_25658);

    /** scanner.e:213			current_source_next = 1*/
    _62current_source_next_25659 = 1LL;
L3: 

    /** scanner.e:216		start = current_source_next*/
    _start_25664 = _62current_source_next_25659;

    /** scanner.e:217		poke(current_source+current_source_next, src)*/
    if (IS_ATOM_INT(_62current_source_25658)) {
        _14264 = _62current_source_25658 + _62current_source_next_25659;
        if ((object)((uintptr_t)_14264 + (uintptr_t)HIGH_BITS) >= 0){
            _14264 = NewDouble((eudouble)_14264);
        }
    }
    else {
        _14264 = NewDouble(DBL_PTR(_62current_source_25658)->dbl + (eudouble)_62current_source_next_25659);
    }
    if (IS_ATOM_INT(_14264)){
        poke_addr = (uint8_t *)_14264;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_14264)->dbl);
    }
    if (IS_ATOM_INT(_src_25663)) {
        *poke_addr = (uint8_t)_src_25663;
    }
    else if (IS_ATOM(_src_25663)) {
        *poke_addr = (uint8_t)DBL_PTR(_src_25663)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_src_25663);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke_addr++ = (uint8_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_14264);
    _14264 = NOVALUE;

    /** scanner.e:218		current_source_next += length(src)-1*/
    if (IS_SEQUENCE(_src_25663)){
            _14265 = SEQ_PTR(_src_25663)->length;
    }
    else {
        _14265 = 1;
    }
    _14266 = _14265 - 1LL;
    _14265 = NOVALUE;
    _62current_source_next_25659 = _62current_source_next_25659 + _14266;
    _14266 = NOVALUE;

    /** scanner.e:219		poke(current_source+current_source_next, 0) -- overwrite \n*/
    if (IS_ATOM_INT(_62current_source_25658)) {
        _14268 = _62current_source_25658 + _62current_source_next_25659;
        if ((object)((uintptr_t)_14268 + (uintptr_t)HIGH_BITS) >= 0){
            _14268 = NewDouble((eudouble)_14268);
        }
    }
    else {
        _14268 = NewDouble(DBL_PTR(_62current_source_25658)->dbl + (eudouble)_62current_source_next_25659);
    }
    if (IS_ATOM_INT(_14268)){
        poke_addr = (uint8_t *)_14268;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_14268)->dbl);
    }
    *poke_addr = (uint8_t)0LL;
    DeRef(_14268);
    _14268 = NOVALUE;

    /** scanner.e:220		current_source_next += 1*/
    _62current_source_next_25659 = _62current_source_next_25659 + 1;

    /** scanner.e:221		return start + SOURCE_CHUNK * (length(all_source)-1)*/
    if (IS_SEQUENCE(_37all_source_15430)){
            _14270 = SEQ_PTR(_37all_source_15430)->length;
    }
    else {
        _14270 = 1;
    }
    _14271 = _14270 - 1LL;
    _14270 = NOVALUE;
    {
        int128_t p128 = (int128_t)10000LL * (int128_t)_14271;
        if( p128 != (int128_t)(_14272 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
            _14272 = NewDouble( (eudouble)p128 );
        }
    }
    _14271 = NOVALUE;
    if (IS_ATOM_INT(_14272)) {
        _14273 = _start_25664 + _14272;
        if ((object)((uintptr_t)_14273 + (uintptr_t)HIGH_BITS) >= 0){
            _14273 = NewDouble((eudouble)_14273);
        }
    }
    else {
        _14273 = NewDouble((eudouble)_start_25664 + DBL_PTR(_14272)->dbl);
    }
    DeRef(_14272);
    _14272 = NOVALUE;
    DeRef(_src_25663);
    return _14273;
    ;
}


object _62fetch_line(object _start_25698)
{
    object _line_25699 = NOVALUE;
    object _memdata_25700 = NOVALUE;
    object _c_25701 = NOVALUE;
    object _chunk_25702 = NOVALUE;
    object _p_25703 = NOVALUE;
    object _n_25704 = NOVALUE;
    object _m_25705 = NOVALUE;
    object _14298 = NOVALUE;
    object _14297 = NOVALUE;
    object _14295 = NOVALUE;
    object _14293 = NOVALUE;
    object _14287 = NOVALUE;
    object _14285 = NOVALUE;
    object _14281 = NOVALUE;
    object _14279 = NOVALUE;
    object _14276 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:234		if start = 0 then*/
    if (_start_25698 != 0LL)
    goto L1; // [5] 16

    /** scanner.e:235			return ""*/
    RefDS(_5);
    DeRef(_line_25699);
    DeRefi(_memdata_25700);
    DeRef(_p_25703);
    return _5;
L1: 

    /** scanner.e:237		line = repeat(0, LINE_BUFLEN)*/
    DeRef(_line_25699);
    _line_25699 = Repeat(0LL, 400LL);

    /** scanner.e:238		n = 0*/
    _n_25704 = 0LL;

    /** scanner.e:239		chunk = 1+floor(start / SOURCE_CHUNK)*/
    if (10000LL > 0 && _start_25698 >= 0) {
        _14276 = _start_25698 / 10000LL;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_start_25698 / (eudouble)10000LL);
        _14276 = (object)temp_dbl;
    }
    _chunk_25702 = _14276 + 1;
    _14276 = NOVALUE;

    /** scanner.e:240		start = remainder(start, SOURCE_CHUNK)*/
    _start_25698 = (_start_25698 % 10000LL);

    /** scanner.e:241		p = all_source[chunk] + start*/
    _2 = (object)SEQ_PTR(_37all_source_15430);
    _14279 = (object)*(((s1_ptr)_2)->base + _chunk_25702);
    DeRef(_p_25703);
    if (IS_ATOM_INT(_14279)) {
        _p_25703 = _14279 + _start_25698;
        if ((object)((uintptr_t)_p_25703 + (uintptr_t)HIGH_BITS) >= 0){
            _p_25703 = NewDouble((eudouble)_p_25703);
        }
    }
    else {
        _p_25703 = NewDouble(DBL_PTR(_14279)->dbl + (eudouble)_start_25698);
    }
    _14279 = NOVALUE;

    /** scanner.e:242		memdata = peek({p, LINE_BUFLEN})*/
    Ref(_p_25703);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _p_25703;
    ((intptr_t *)_2)[2] = 400LL;
    _14281 = MAKE_SEQ(_1);
    DeRefi(_memdata_25700);
    _1 = (object)SEQ_PTR(_14281);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _memdata_25700 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    DeRefDS(_14281);
    _14281 = NOVALUE;

    /** scanner.e:243		p += LINE_BUFLEN*/
    _0 = _p_25703;
    if (IS_ATOM_INT(_p_25703)) {
        _p_25703 = _p_25703 + 400LL;
        if ((object)((uintptr_t)_p_25703 + (uintptr_t)HIGH_BITS) >= 0){
            _p_25703 = NewDouble((eudouble)_p_25703);
        }
    }
    else {
        _p_25703 = NewDouble(DBL_PTR(_p_25703)->dbl + (eudouble)400LL);
    }
    DeRef(_0);

    /** scanner.e:244		m = 0*/
    _m_25705 = 0LL;

    /** scanner.e:245		while TRUE do*/
L2: 
    if (_13TRUE_452 == 0)
    {
        goto L3; // [84] 179
    }
    else{
    }

    /** scanner.e:246			m += 1*/
    _m_25705 = _m_25705 + 1;

    /** scanner.e:247			if m > length(memdata) then*/
    if (IS_SEQUENCE(_memdata_25700)){
            _14285 = SEQ_PTR(_memdata_25700)->length;
    }
    else {
        _14285 = 1;
    }
    if (_m_25705 <= _14285)
    goto L4; // [98] 125

    /** scanner.e:248				memdata = peek({p, LINE_BUFLEN})*/
    Ref(_p_25703);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _p_25703;
    ((intptr_t *)_2)[2] = 400LL;
    _14287 = MAKE_SEQ(_1);
    DeRefDSi(_memdata_25700);
    _1 = (object)SEQ_PTR(_14287);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _memdata_25700 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    DeRefDS(_14287);
    _14287 = NOVALUE;

    /** scanner.e:249				p += LINE_BUFLEN*/
    _0 = _p_25703;
    if (IS_ATOM_INT(_p_25703)) {
        _p_25703 = _p_25703 + 400LL;
        if ((object)((uintptr_t)_p_25703 + (uintptr_t)HIGH_BITS) >= 0){
            _p_25703 = NewDouble((eudouble)_p_25703);
        }
    }
    else {
        _p_25703 = NewDouble(DBL_PTR(_p_25703)->dbl + (eudouble)400LL);
    }
    DeRef(_0);

    /** scanner.e:250				m = 1*/
    _m_25705 = 1LL;
L4: 

    /** scanner.e:252			c = memdata[m]*/
    _2 = (object)SEQ_PTR(_memdata_25700);
    _c_25701 = (object)*(((s1_ptr)_2)->base + _m_25705);

    /** scanner.e:253			if c = 0 then*/
    if (_c_25701 != 0LL)
    goto L5; // [133] 142

    /** scanner.e:254				exit*/
    goto L3; // [139] 179
L5: 

    /** scanner.e:256			n += 1*/
    _n_25704 = _n_25704 + 1;

    /** scanner.e:257			if n > length(line) then*/
    if (IS_SEQUENCE(_line_25699)){
            _14293 = SEQ_PTR(_line_25699)->length;
    }
    else {
        _14293 = 1;
    }
    if (_n_25704 <= _14293)
    goto L6; // [153] 168

    /** scanner.e:258				line &= repeat(0, LINE_BUFLEN)*/
    _14295 = Repeat(0LL, 400LL);
    Concat((object_ptr)&_line_25699, _line_25699, _14295);
    DeRefDS(_14295);
    _14295 = NOVALUE;
L6: 

    /** scanner.e:260			line[n] = c*/
    _2 = (object)SEQ_PTR(_line_25699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _line_25699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _n_25704);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _c_25701;
    DeRef(_1);

    /** scanner.e:261		end while*/
    goto L2; // [176] 82
L3: 

    /** scanner.e:262		line = remove( line, n+1, length( line ) )*/
    _14297 = _n_25704 + 1;
    if (_14297 > MAXINT){
        _14297 = NewDouble((eudouble)_14297);
    }
    if (IS_SEQUENCE(_line_25699)){
            _14298 = SEQ_PTR(_line_25699)->length;
    }
    else {
        _14298 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_line_25699);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_14297)) ? _14297 : (object)(DBL_PTR(_14297)->dbl);
        int stop = (IS_ATOM_INT(_14298)) ? _14298 : (object)(DBL_PTR(_14298)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_line_25699), start, &_line_25699 );
            }
            else Tail(SEQ_PTR(_line_25699), stop+1, &_line_25699);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_line_25699), start, &_line_25699);
        }
        else {
            assign_slice_seq = &assign_space;
            _line_25699 = Remove_elements(start, stop, (SEQ_PTR(_line_25699)->ref == 1));
        }
    }
    DeRef(_14297);
    _14297 = NOVALUE;
    _14298 = NOVALUE;

    /** scanner.e:263		return line*/
    DeRefi(_memdata_25700);
    DeRef(_p_25703);
    return _line_25699;
    ;
}


void _62AppendSourceLine()
{
    object _new_25741 = NOVALUE;
    object _old_25742 = NOVALUE;
    object _options_25743 = NOVALUE;
    object _src_25744 = NOVALUE;
    object _14339 = NOVALUE;
    object _14335 = NOVALUE;
    object _14333 = NOVALUE;
    object _14332 = NOVALUE;
    object _14329 = NOVALUE;
    object _14328 = NOVALUE;
    object _14327 = NOVALUE;
    object _14326 = NOVALUE;
    object _14325 = NOVALUE;
    object _14324 = NOVALUE;
    object _14323 = NOVALUE;
    object _14322 = NOVALUE;
    object _14321 = NOVALUE;
    object _14320 = NOVALUE;
    object _14319 = NOVALUE;
    object _14318 = NOVALUE;
    object _14317 = NOVALUE;
    object _14316 = NOVALUE;
    object _14315 = NOVALUE;
    object _14314 = NOVALUE;
    object _14313 = NOVALUE;
    object _14312 = NOVALUE;
    object _14310 = NOVALUE;
    object _14309 = NOVALUE;
    object _14308 = NOVALUE;
    object _14306 = NOVALUE;
    object _14301 = NOVALUE;
    object _14300 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:272		src = 0*/
    DeRef(_src_25744);
    _src_25744 = 0LL;

    /** scanner.e:273		options = 0*/
    _options_25743 = 0LL;

    /** scanner.e:275		if TRANSLATE or OpTrace or OpProfileStatement or OpProfileTime then*/
    if (_36TRANSLATE_21041 != 0) {
        _14300 = 1;
        goto L1; // [15] 25
    }
    _14300 = (_36OpTrace_21512 != 0);
L1: 
    if (_14300 != 0) {
        _14301 = 1;
        goto L2; // [25] 35
    }
    _14301 = (_36OpProfileStatement_21514 != 0);
L2: 
    if (_14301 != 0) {
        goto L3; // [35] 46
    }
    if (_36OpProfileTime_21515 == 0)
    {
        goto L4; // [42] 136
    }
    else{
    }
L3: 

    /** scanner.e:277			src = ThisLine*/
    Ref(_50ThisLine_49234);
    DeRef(_src_25744);
    _src_25744 = _50ThisLine_49234;

    /** scanner.e:279			if OpTrace then*/
    if (_36OpTrace_21512 == 0)
    {
        goto L5; // [57] 70
    }
    else{
    }

    /** scanner.e:280				options = SOP_TRACE*/
    _options_25743 = 1LL;
L5: 

    /** scanner.e:282			if OpProfileTime then*/
    if (_36OpProfileTime_21515 == 0)
    {
        goto L6; // [74] 88
    }
    else{
    }

    /** scanner.e:283				options = or_bits(options, SOP_PROFILE_TIME)*/
    {uintptr_t tu;
         tu = (uintptr_t)_options_25743 | (uintptr_t)2LL;
         _options_25743 = MAKE_UINT(tu);
    }
    if (!IS_ATOM_INT(_options_25743)) {
        _1 = (object)(DBL_PTR(_options_25743)->dbl);
        DeRefDS(_options_25743);
        _options_25743 = _1;
    }
L6: 

    /** scanner.e:285			if OpProfileStatement then*/
    if (_36OpProfileStatement_21514 == 0)
    {
        goto L7; // [92] 106
    }
    else{
    }

    /** scanner.e:286				options = or_bits(options, SOP_PROFILE_STATEMENT)*/
    {uintptr_t tu;
         tu = (uintptr_t)_options_25743 | (uintptr_t)4LL;
         _options_25743 = MAKE_UINT(tu);
    }
    if (!IS_ATOM_INT(_options_25743)) {
        _1 = (object)(DBL_PTR(_options_25743)->dbl);
        DeRefDS(_options_25743);
        _options_25743 = _1;
    }
L7: 

    /** scanner.e:288			if OpProfileStatement or OpProfileTime then*/
    if (_36OpProfileStatement_21514 != 0) {
        goto L8; // [110] 121
    }
    if (_36OpProfileTime_21515 == 0)
    {
        goto L9; // [117] 135
    }
    else{
    }
L8: 

    /** scanner.e:289				src = {0,0,0,0} & src*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0LL;
    ((intptr_t*)_2)[2] = 0LL;
    ((intptr_t*)_2)[3] = 0LL;
    ((intptr_t*)_2)[4] = 0LL;
    _14306 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_14306) && IS_ATOM(_src_25744)) {
        Ref(_src_25744);
        Append(&_src_25744, _14306, _src_25744);
    }
    else if (IS_ATOM(_14306) && IS_SEQUENCE(_src_25744)) {
    }
    else {
        Concat((object_ptr)&_src_25744, _14306, _src_25744);
        DeRefDS(_14306);
        _14306 = NOVALUE;
    }
    DeRef(_14306);
    _14306 = NOVALUE;
L9: 
L4: 

    /** scanner.e:293		if length(slist) then*/
    if (IS_SEQUENCE(_36slist_21533)){
            _14308 = SEQ_PTR(_36slist_21533)->length;
    }
    else {
        _14308 = 1;
    }
    if (_14308 == 0)
    {
        _14308 = NOVALUE;
        goto LA; // [143] 345
    }
    else{
        _14308 = NOVALUE;
    }

    /** scanner.e:294			old = slist[$-1]*/
    if (IS_SEQUENCE(_36slist_21533)){
            _14309 = SEQ_PTR(_36slist_21533)->length;
    }
    else {
        _14309 = 1;
    }
    _14310 = _14309 - 1LL;
    _14309 = NOVALUE;
    DeRef(_old_25742);
    _2 = (object)SEQ_PTR(_36slist_21533);
    _old_25742 = (object)*(((s1_ptr)_2)->base + _14310);
    Ref(_old_25742);

    /** scanner.e:296			if equal(src, old[SRC]) and*/
    _2 = (object)SEQ_PTR(_old_25742);
    _14312 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (_src_25744 == _14312)
    _14313 = 1;
    else if (IS_ATOM_INT(_src_25744) && IS_ATOM_INT(_14312))
    _14313 = 0;
    else
    _14313 = (compare(_src_25744, _14312) == 0);
    _14312 = NOVALUE;
    if (_14313 == 0) {
        _14314 = 0;
        goto LB; // [175] 195
    }
    _2 = (object)SEQ_PTR(_old_25742);
    _14315 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (IS_ATOM_INT(_14315)) {
        _14316 = (_36current_file_no_21439 == _14315);
    }
    else {
        _14316 = binary_op(EQUALS, _36current_file_no_21439, _14315);
    }
    _14315 = NOVALUE;
    if (IS_ATOM_INT(_14316))
    _14314 = (_14316 != 0);
    else
    _14314 = DBL_PTR(_14316)->dbl != 0.0;
LB: 
    if (_14314 == 0) {
        _14317 = 0;
        goto LC; // [195] 232
    }
    _2 = (object)SEQ_PTR(_old_25742);
    _14318 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_14318)) {
        _14319 = _14318 + 1;
        if (_14319 > MAXINT){
            _14319 = NewDouble((eudouble)_14319);
        }
    }
    else
    _14319 = binary_op(PLUS, 1, _14318);
    _14318 = NOVALUE;
    if (IS_SEQUENCE(_36slist_21533)){
            _14320 = SEQ_PTR(_36slist_21533)->length;
    }
    else {
        _14320 = 1;
    }
    _2 = (object)SEQ_PTR(_36slist_21533);
    _14321 = (object)*(((s1_ptr)_2)->base + _14320);
    if (IS_ATOM_INT(_14319) && IS_ATOM_INT(_14321)) {
        _14322 = _14319 + _14321;
        if ((object)((uintptr_t)_14322 + (uintptr_t)HIGH_BITS) >= 0){
            _14322 = NewDouble((eudouble)_14322);
        }
    }
    else {
        _14322 = binary_op(PLUS, _14319, _14321);
    }
    DeRef(_14319);
    _14319 = NOVALUE;
    _14321 = NOVALUE;
    if (IS_ATOM_INT(_14322)) {
        _14323 = (_36line_number_21440 == _14322);
    }
    else {
        _14323 = binary_op(EQUALS, _36line_number_21440, _14322);
    }
    DeRef(_14322);
    _14322 = NOVALUE;
    if (IS_ATOM_INT(_14323))
    _14317 = (_14323 != 0);
    else
    _14317 = DBL_PTR(_14323)->dbl != 0.0;
LC: 
    if (_14317 == 0) {
        goto LD; // [232] 272
    }
    _2 = (object)SEQ_PTR(_old_25742);
    _14325 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_14325)) {
        _14326 = (_options_25743 == _14325);
    }
    else {
        _14326 = binary_op(EQUALS, _options_25743, _14325);
    }
    _14325 = NOVALUE;
    if (_14326 == 0) {
        DeRef(_14326);
        _14326 = NOVALUE;
        goto LD; // [247] 272
    }
    else {
        if (!IS_ATOM_INT(_14326) && DBL_PTR(_14326)->dbl == 0.0){
            DeRef(_14326);
            _14326 = NOVALUE;
            goto LD; // [247] 272
        }
        DeRef(_14326);
        _14326 = NOVALUE;
    }
    DeRef(_14326);
    _14326 = NOVALUE;

    /** scanner.e:302				slist[$] += 1*/
    if (IS_SEQUENCE(_36slist_21533)){
            _14327 = SEQ_PTR(_36slist_21533)->length;
    }
    else {
        _14327 = 1;
    }
    _2 = (object)SEQ_PTR(_36slist_21533);
    _14328 = (object)*(((s1_ptr)_2)->base + _14327);
    if (IS_ATOM_INT(_14328)) {
        _14329 = _14328 + 1;
        if (_14329 > MAXINT){
            _14329 = NewDouble((eudouble)_14329);
        }
    }
    else
    _14329 = binary_op(PLUS, 1, _14328);
    _14328 = NOVALUE;
    _2 = (object)SEQ_PTR(_36slist_21533);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36slist_21533 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14327);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14329;
    if( _1 != _14329 ){
        DeRef(_1);
    }
    _14329 = NOVALUE;
    goto LE; // [269] 371
LD: 

    /** scanner.e:304				src = pack_source(src)*/
    Ref(_src_25744);
    _0 = _src_25744;
    _src_25744 = _62pack_source(_src_25744);
    DeRef(_0);

    /** scanner.e:305				new = {src, line_number, current_file_no, options}*/
    _0 = _new_25741;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_src_25744);
    ((intptr_t*)_2)[1] = _src_25744;
    ((intptr_t*)_2)[2] = _36line_number_21440;
    ((intptr_t*)_2)[3] = _36current_file_no_21439;
    ((intptr_t*)_2)[4] = _options_25743;
    _new_25741 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scanner.e:306				if slist[$] = 0 then*/
    if (IS_SEQUENCE(_36slist_21533)){
            _14332 = SEQ_PTR(_36slist_21533)->length;
    }
    else {
        _14332 = 1;
    }
    _2 = (object)SEQ_PTR(_36slist_21533);
    _14333 = (object)*(((s1_ptr)_2)->base + _14332);
    if (binary_op_a(NOTEQ, _14333, 0LL)){
        _14333 = NOVALUE;
        goto LF; // [302] 320
    }
    _14333 = NOVALUE;

    /** scanner.e:307					slist[$] = new*/
    if (IS_SEQUENCE(_36slist_21533)){
            _14335 = SEQ_PTR(_36slist_21533)->length;
    }
    else {
        _14335 = 1;
    }
    RefDS(_new_25741);
    _2 = (object)SEQ_PTR(_36slist_21533);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36slist_21533 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14335);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _new_25741;
    DeRef(_1);
    goto L10; // [317] 331
LF: 

    /** scanner.e:309					slist = append(slist, new)*/
    RefDS(_new_25741);
    Append(&_36slist_21533, _36slist_21533, _new_25741);
L10: 

    /** scanner.e:311				slist = append(slist, 0)*/
    Append(&_36slist_21533, _36slist_21533, 0LL);
    goto LE; // [342] 371
LA: 

    /** scanner.e:314			src = pack_source(src)*/
    Ref(_src_25744);
    _0 = _src_25744;
    _src_25744 = _62pack_source(_src_25744);
    DeRef(_0);

    /** scanner.e:315			slist = {{src, line_number, current_file_no, options}, 0}*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_src_25744);
    ((intptr_t*)_2)[1] = _src_25744;
    ((intptr_t*)_2)[2] = _36line_number_21440;
    ((intptr_t*)_2)[3] = _36current_file_no_21439;
    ((intptr_t*)_2)[4] = _options_25743;
    _14339 = MAKE_SEQ(_1);
    DeRef(_36slist_21533);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _14339;
    ((intptr_t *)_2)[2] = 0LL;
    _36slist_21533 = MAKE_SEQ(_1);
    _14339 = NOVALUE;
LE: 

    /** scanner.e:317	end procedure*/
    DeRef(_new_25741);
    DeRef(_old_25742);
    DeRef(_src_25744);
    DeRef(_14323);
    _14323 = NOVALUE;
    DeRef(_14310);
    _14310 = NOVALUE;
    DeRef(_14316);
    _14316 = NOVALUE;
    return;
    ;
}


object _62s_expand(object _slist_25833)
{
    object _new_slist_25834 = NOVALUE;
    object _14353 = NOVALUE;
    object _14352 = NOVALUE;
    object _14351 = NOVALUE;
    object _14350 = NOVALUE;
    object _14348 = NOVALUE;
    object _14347 = NOVALUE;
    object _14346 = NOVALUE;
    object _14344 = NOVALUE;
    object _14343 = NOVALUE;
    object _14342 = NOVALUE;
    object _14341 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:323		new_slist = {}*/
    RefDS(_5);
    DeRef(_new_slist_25834);
    _new_slist_25834 = _5;

    /** scanner.e:325		for i = 1 to length(slist) do*/
    if (IS_SEQUENCE(_slist_25833)){
            _14341 = SEQ_PTR(_slist_25833)->length;
    }
    else {
        _14341 = 1;
    }
    {
        object _i_25836;
        _i_25836 = 1LL;
L1: 
        if (_i_25836 > _14341){
            goto L2; // [15] 114
        }

        /** scanner.e:326			if sequence(slist[i]) then*/
        _2 = (object)SEQ_PTR(_slist_25833);
        _14342 = (object)*(((s1_ptr)_2)->base + _i_25836);
        _14343 = IS_SEQUENCE(_14342);
        _14342 = NOVALUE;
        if (_14343 == 0)
        {
            _14343 = NOVALUE;
            goto L3; // [31] 47
        }
        else{
            _14343 = NOVALUE;
        }

        /** scanner.e:327				new_slist = append(new_slist, slist[i])*/
        _2 = (object)SEQ_PTR(_slist_25833);
        _14344 = (object)*(((s1_ptr)_2)->base + _i_25836);
        Ref(_14344);
        Append(&_new_slist_25834, _new_slist_25834, _14344);
        _14344 = NOVALUE;
        goto L4; // [44] 107
L3: 

        /** scanner.e:329				for j = 1 to slist[i] do*/
        _2 = (object)SEQ_PTR(_slist_25833);
        _14346 = (object)*(((s1_ptr)_2)->base + _i_25836);
        {
            object _j_25845;
            _j_25845 = 1LL;
L5: 
            if (binary_op_a(GREATER, _j_25845, _14346)){
                goto L6; // [53] 106
            }

            /** scanner.e:330					slist[i-1][LINE] += 1*/
            _14347 = _i_25836 - 1LL;
            _2 = (object)SEQ_PTR(_slist_25833);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _slist_25833 = MAKE_SEQ(_2);
            }
            _3 = (object)(_14347 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            _14350 = (object)*(((s1_ptr)_2)->base + 2LL);
            _14348 = NOVALUE;
            if (IS_ATOM_INT(_14350)) {
                _14351 = _14350 + 1;
                if (_14351 > MAXINT){
                    _14351 = NewDouble((eudouble)_14351);
                }
            }
            else
            _14351 = binary_op(PLUS, 1, _14350);
            _14350 = NOVALUE;
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 2LL);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _14351;
            if( _1 != _14351 ){
                DeRef(_1);
            }
            _14351 = NOVALUE;
            _14348 = NOVALUE;

            /** scanner.e:331					new_slist = append(new_slist, slist[i-1])*/
            _14352 = _i_25836 - 1LL;
            _2 = (object)SEQ_PTR(_slist_25833);
            _14353 = (object)*(((s1_ptr)_2)->base + _14352);
            Ref(_14353);
            Append(&_new_slist_25834, _new_slist_25834, _14353);
            _14353 = NOVALUE;

            /** scanner.e:332				end for*/
            _0 = _j_25845;
            if (IS_ATOM_INT(_j_25845)) {
                _j_25845 = _j_25845 + 1LL;
                if ((object)((uintptr_t)_j_25845 +(uintptr_t) HIGH_BITS) >= 0){
                    _j_25845 = NewDouble((eudouble)_j_25845);
                }
            }
            else {
                _j_25845 = binary_op_a(PLUS, _j_25845, 1LL);
            }
            DeRef(_0);
            goto L5; // [101] 60
L6: 
            ;
            DeRef(_j_25845);
        }
L4: 

        /** scanner.e:334		end for*/
        _i_25836 = _i_25836 + 1LL;
        goto L1; // [109] 22
L2: 
        ;
    }

    /** scanner.e:335		return new_slist*/
    DeRefDS(_slist_25833);
    DeRef(_14347);
    _14347 = NOVALUE;
    DeRef(_14352);
    _14352 = NOVALUE;
    _14346 = NOVALUE;
    return _new_slist_25834;
    ;
}


void _62set_dont_read(object _read_25860)
{
    object _0, _1, _2;
    

    /** scanner.e:357		dont_read = read*/
    _62dont_read_25857 = _read_25860;

    /** scanner.e:358	end procedure*/
    return;
    ;
}


void _62read_line()
{
    object _n_25866 = NOVALUE;
    object _14383 = NOVALUE;
    object _14382 = NOVALUE;
    object _14381 = NOVALUE;
    object _14380 = NOVALUE;
    object _14379 = NOVALUE;
    object _14377 = NOVALUE;
    object _14376 = NOVALUE;
    object _14374 = NOVALUE;
    object _14373 = NOVALUE;
    object _14372 = NOVALUE;
    object _14371 = NOVALUE;
    object _14363 = NOVALUE;
    object _14361 = NOVALUE;
    object _14360 = NOVALUE;
    object _14359 = NOVALUE;
    object _14358 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:367		line_number += 1*/
    _36line_number_21440 = _36line_number_21440 + 1LL;

    /** scanner.e:368		gline_number += 1*/
    _36gline_number_21444 = _36gline_number_21444 + 1LL;

    /** scanner.e:370		if dont_read then*/
    if (_62dont_read_25857 == 0)
    {
        goto L1; // [25] 36
    }
    else{
    }

    /** scanner.e:371			ThisLine = -1*/
    DeRef(_50ThisLine_49234);
    _50ThisLine_49234 = -1LL;
    goto L2; // [33] 216
L1: 

    /** scanner.e:372		elsif repl and src_file = repl_file then*/
    if (0LL == 0) {
        goto L3; // [40] 144
    }
    _14359 = (_36src_file_21564 == 5555LL);
    if (_14359 == 0)
    {
        DeRef(_14359);
        _14359 = NOVALUE;
        goto L3; // [53] 144
    }
    else{
        DeRef(_14359);
        _14359 = NOVALUE;
    }

    /** scanner.e:373			if repl_line_was_read and current_block = top_level_block then*/
    if (_62repl_line_was_read_25861 == 0) {
        goto L4; // [60] 118
    }
    _14361 = (_65current_block_25114 == _65top_level_block_25115);
    if (_14361 == 0)
    {
        DeRef(_14361);
        _14361 = NOVALUE;
        goto L4; // [73] 118
    }
    else{
        DeRef(_14361);
        _14361 = NOVALUE;
    }

    /** scanner.e:374				if repl_line_was_read > 1 then*/
    if (_62repl_line_was_read_25861 <= 1LL)
    goto L5; // [80] 110

    /** scanner.e:375					if not match("end", ThisLine) then*/
    _14363 = e_match_from(_13137, _50ThisLine_49234, 1LL);
    if (_14363 != 0)
    goto L6; // [93] 109
    _14363 = NOVALUE;

    /** scanner.e:376						goto "lol"*/
    goto G7;
L6: 
L5: 

    /** scanner.e:379				ThisLine = -1*/
    DeRef(_50ThisLine_49234);
    _50ThisLine_49234 = -1LL;
    goto L2; // [115] 216
L4: 

    /** scanner.e:381				label "lol"*/
G7:

    /** scanner.e:382				puts(1, "Enter line:\n")*/
    EPuts(1LL, _14366); // DJP 

    /** scanner.e:383				repl_line_was_read += 1*/
    _62repl_line_was_read_25861 = _62repl_line_was_read_25861 + 1;

    /** scanner.e:384				ThisLine = gets(0)*/
    DeRef(_50ThisLine_49234);
    _50ThisLine_49234 = EGets(0LL);
    goto L2; // [141] 216
L3: 

    /** scanner.e:386		elsif src_file < 0 then*/
    if (_36src_file_21564 >= 0LL)
    goto L8; // [148] 160

    /** scanner.e:387			ThisLine = -1*/
    DeRef(_50ThisLine_49234);
    _50ThisLine_49234 = -1LL;
    goto L2; // [157] 216
L8: 

    /** scanner.e:389			ThisLine = gets(src_file)*/
    DeRef(_50ThisLine_49234);
    _50ThisLine_49234 = EGets(_36src_file_21564);

    /** scanner.e:390			if sequence(ThisLine) and ends( {13,10}, ThisLine ) then*/
    _14371 = IS_SEQUENCE(_50ThisLine_49234);
    if (_14371 == 0) {
        goto L9; // [174] 215
    }
    RefDS(_12165);
    Ref(_50ThisLine_49234);
    _14373 = _16ends(_12165, _50ThisLine_49234);
    if (_14373 == 0) {
        DeRef(_14373);
        _14373 = NOVALUE;
        goto L9; // [186] 215
    }
    else {
        if (!IS_ATOM_INT(_14373) && DBL_PTR(_14373)->dbl == 0.0){
            DeRef(_14373);
            _14373 = NOVALUE;
            goto L9; // [186] 215
        }
        DeRef(_14373);
        _14373 = NOVALUE;
    }
    DeRef(_14373);
    _14373 = NOVALUE;

    /** scanner.e:391				ThisLine = remove(ThisLine, length(ThisLine))*/
    if (IS_SEQUENCE(_50ThisLine_49234)){
            _14374 = SEQ_PTR(_50ThisLine_49234)->length;
    }
    else {
        _14374 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_50ThisLine_49234);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_14374)) ? _14374 : (object)(DBL_PTR(_14374)->dbl);
        int stop = (IS_ATOM_INT(_14374)) ? _14374 : (object)(DBL_PTR(_14374)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_50ThisLine_49234), start, &_50ThisLine_49234 );
            }
            else Tail(SEQ_PTR(_50ThisLine_49234), stop+1, &_50ThisLine_49234);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_50ThisLine_49234), start, &_50ThisLine_49234);
        }
        else {
            assign_slice_seq = &assign_space;
            _50ThisLine_49234 = Remove_elements(start, stop, (SEQ_PTR(_50ThisLine_49234)->ref == 1));
        }
    }
    _14374 = NOVALUE;
    _14374 = NOVALUE;

    /** scanner.e:392				ThisLine[$] = 10*/
    if (IS_SEQUENCE(_50ThisLine_49234)){
            _14376 = SEQ_PTR(_50ThisLine_49234)->length;
    }
    else {
        _14376 = 1;
    }
    _2 = (object)SEQ_PTR(_50ThisLine_49234);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _50ThisLine_49234 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14376);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 10LL;
    DeRef(_1);
L9: 
L2: 

    /** scanner.e:395		if atom(ThisLine) then*/
    _14377 = IS_ATOM(_50ThisLine_49234);
    if (_14377 == 0)
    {
        _14377 = NOVALUE;
        goto LA; // [223] 286
    }
    else{
        _14377 = NOVALUE;
    }

    /** scanner.e:396			ThisLine = {END_OF_FILE_CHAR}*/
    _0 = _50ThisLine_49234;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 26LL;
    _50ThisLine_49234 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scanner.e:397			if src_file >= 0 and (src_file != repl_file or not repl) then*/
    _14379 = (_36src_file_21564 >= 0LL);
    if (_14379 == 0) {
        goto LB; // [242] 278
    }
    _14381 = (_36src_file_21564 != 5555LL);
    if (_14381 != 0) {
        DeRef(_14382);
        _14382 = 1;
        goto LC; // [254] 267
    }
    _14383 = (0LL == 0);
    _14382 = (_14383 != 0);
LC: 
    if (_14382 == 0)
    {
        _14382 = NOVALUE;
        goto LB; // [268] 278
    }
    else{
        _14382 = NOVALUE;
    }

    /** scanner.e:398				close(src_file)*/
    EClose(_36src_file_21564);
LB: 

    /** scanner.e:400			src_file = -1*/
    _36src_file_21564 = -1LL;
LA: 

    /** scanner.e:403		bp = 1*/
    _50bp_49238 = 1LL;

    /** scanner.e:411		AppendSourceLine()*/
    _62AppendSourceLine();

    /** scanner.e:412	end procedure*/
    DeRef(_14383);
    _14383 = NOVALUE;
    DeRef(_14381);
    _14381 = NOVALUE;
    DeRef(_14379);
    _14379 = NOVALUE;
    return;
    ;
}


object _62getch()
{
    object _c_25940 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:417		c = ThisLine[bp]*/
    _2 = (object)SEQ_PTR(_50ThisLine_49234);
    _c_25940 = (object)*(((s1_ptr)_2)->base + _50bp_49238);
    if (!IS_ATOM_INT(_c_25940)){
        _c_25940 = (object)DBL_PTR(_c_25940)->dbl;
    }

    /** scanner.e:418		bp += 1*/
    _50bp_49238 = _50bp_49238 + 1LL;

    /** scanner.e:419		return c*/
    return _c_25940;
    ;
}


void _62ungetch()
{
    object _0, _1, _2;
    

    /** scanner.e:424		bp -= 1*/
    _50bp_49238 = _50bp_49238 - 1LL;

    /** scanner.e:425	end procedure*/
    return;
    ;
}


object _62get_file_path(object _s_25952)
{
    object _14392 = NOVALUE;
    object _14390 = NOVALUE;
    object _14389 = NOVALUE;
    object _14388 = NOVALUE;
    object _14387 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:429			for t=length(s) to 1 by -1 do*/
    if (IS_SEQUENCE(_s_25952)){
            _14387 = SEQ_PTR(_s_25952)->length;
    }
    else {
        _14387 = 1;
    }
    {
        object _t_25954;
        _t_25954 = _14387;
L1: 
        if (_t_25954 < 1LL){
            goto L2; // [8] 50
        }

        /** scanner.e:430					if find(s[t],SLASH_CHARS) then*/
        _2 = (object)SEQ_PTR(_s_25952);
        _14388 = (object)*(((s1_ptr)_2)->base + _t_25954);
        _14389 = find_from(_14388, _46SLASH_CHARS_21606, 1LL);
        _14388 = NOVALUE;
        if (_14389 == 0)
        {
            _14389 = NOVALUE;
            goto L3; // [28] 43
        }
        else{
            _14389 = NOVALUE;
        }

        /** scanner.e:431							return s[1..t]*/
        rhs_slice_target = (object_ptr)&_14390;
        RHS_Slice(_s_25952, 1LL, _t_25954);
        DeRefDS(_s_25952);
        return _14390;
L3: 

        /** scanner.e:433			end for*/
        _t_25954 = _t_25954 + -1LL;
        goto L1; // [45] 15
L2: 
        ;
    }

    /** scanner.e:435			return "." & SLASH*/
    Append(&_14392, _14391, 47LL);
    DeRefDS(_s_25952);
    DeRef(_14390);
    _14390 = NOVALUE;
    return _14392;
    ;
}


object _62find_file(object _fname_25966)
{
    object _try_25967 = NOVALUE;
    object _full_path_25968 = NOVALUE;
    object _errbuff_25969 = NOVALUE;
    object _currdir_25970 = NOVALUE;
    object _conf_path_25971 = NOVALUE;
    object _scan_result_25972 = NOVALUE;
    object _inc_path_25973 = NOVALUE;
    object _mainpath_25993 = NOVALUE;
    object _31719 = NOVALUE;
    object _31718 = NOVALUE;
    object _14489 = NOVALUE;
    object _14487 = NOVALUE;
    object _14486 = NOVALUE;
    object _14485 = NOVALUE;
    object _14483 = NOVALUE;
    object _14481 = NOVALUE;
    object _14479 = NOVALUE;
    object _14478 = NOVALUE;
    object _14476 = NOVALUE;
    object _14475 = NOVALUE;
    object _14472 = NOVALUE;
    object _14469 = NOVALUE;
    object _14468 = NOVALUE;
    object _14467 = NOVALUE;
    object _14466 = NOVALUE;
    object _14465 = NOVALUE;
    object _14464 = NOVALUE;
    object _14463 = NOVALUE;
    object _14462 = NOVALUE;
    object _14459 = NOVALUE;
    object _14458 = NOVALUE;
    object _14454 = NOVALUE;
    object _14451 = NOVALUE;
    object _14450 = NOVALUE;
    object _14449 = NOVALUE;
    object _14448 = NOVALUE;
    object _14447 = NOVALUE;
    object _14446 = NOVALUE;
    object _14445 = NOVALUE;
    object _14444 = NOVALUE;
    object _14441 = NOVALUE;
    object _14437 = NOVALUE;
    object _14435 = NOVALUE;
    object _14434 = NOVALUE;
    object _14433 = NOVALUE;
    object _14432 = NOVALUE;
    object _14431 = NOVALUE;
    object _14428 = NOVALUE;
    object _14427 = NOVALUE;
    object _14426 = NOVALUE;
    object _14425 = NOVALUE;
    object _14424 = NOVALUE;
    object _14423 = NOVALUE;
    object _14421 = NOVALUE;
    object _14420 = NOVALUE;
    object _14419 = NOVALUE;
    object _14418 = NOVALUE;
    object _14417 = NOVALUE;
    object _14415 = NOVALUE;
    object _14414 = NOVALUE;
    object _14411 = NOVALUE;
    object _14408 = NOVALUE;
    object _14406 = NOVALUE;
    object _14403 = NOVALUE;
    object _14401 = NOVALUE;
    object _14400 = NOVALUE;
    object _14397 = NOVALUE;
    object _14396 = NOVALUE;
    object _14394 = NOVALUE;
    object _14393 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:449		if absolute_path(fname) then*/
    RefDS(_fname_25966);
    _14393 = _17absolute_path(_fname_25966);
    if (_14393 == 0) {
        DeRef(_14393);
        _14393 = NOVALUE;
        goto L1; // [9] 44
    }
    else {
        if (!IS_ATOM_INT(_14393) && DBL_PTR(_14393)->dbl == 0.0){
            DeRef(_14393);
            _14393 = NOVALUE;
            goto L1; // [9] 44
        }
        DeRef(_14393);
        _14393 = NOVALUE;
    }
    DeRef(_14393);
    _14393 = NOVALUE;

    /** scanner.e:451			if not file_exists(fname) then*/
    RefDS(_fname_25966);
    _14394 = _17file_exists(_fname_25966);
    if (IS_ATOM_INT(_14394)) {
        if (_14394 != 0){
            DeRef(_14394);
            _14394 = NOVALUE;
            goto L2; // [18] 37
        }
    }
    else {
        if (DBL_PTR(_14394)->dbl != 0.0){
            DeRef(_14394);
            _14394 = NOVALUE;
            goto L2; // [18] 37
        }
    }
    DeRef(_14394);
    _14394 = NOVALUE;

    /** scanner.e:452				CompileErr(CANT_OPEN_1, {new_include_name})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_36new_include_name_21565);
    ((intptr_t*)_2)[1] = _36new_include_name_21565;
    _14396 = MAKE_SEQ(_1);
    _50CompileErr(51LL, _14396, 0LL);
    _14396 = NOVALUE;
L2: 

    /** scanner.e:455			return fname*/
    DeRef(_full_path_25968);
    DeRef(_errbuff_25969);
    DeRef(_currdir_25970);
    DeRef(_conf_path_25971);
    DeRef(_scan_result_25972);
    DeRef(_inc_path_25973);
    DeRef(_mainpath_25993);
    return _fname_25966;
L1: 

    /** scanner.e:460		currdir = get_file_path( known_files[current_file_no] )*/
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _14397 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
    Ref(_14397);
    _0 = _currdir_25970;
    _currdir_25970 = _62get_file_path(_14397);
    DeRef(_0);
    _14397 = NOVALUE;

    /** scanner.e:461		full_path = currdir & fname*/
    Concat((object_ptr)&_full_path_25968, _currdir_25970, _fname_25966);

    /** scanner.e:462		if file_exists(full_path) then*/
    RefDS(_full_path_25968);
    _14400 = _17file_exists(_full_path_25968);
    if (_14400 == 0) {
        DeRef(_14400);
        _14400 = NOVALUE;
        goto L3; // [72] 82
    }
    else {
        if (!IS_ATOM_INT(_14400) && DBL_PTR(_14400)->dbl == 0.0){
            DeRef(_14400);
            _14400 = NOVALUE;
            goto L3; // [72] 82
        }
        DeRef(_14400);
        _14400 = NOVALUE;
    }
    DeRef(_14400);
    _14400 = NOVALUE;

    /** scanner.e:463			return full_path*/
    DeRefDS(_fname_25966);
    DeRef(_errbuff_25969);
    DeRefDS(_currdir_25970);
    DeRef(_conf_path_25971);
    DeRef(_scan_result_25972);
    DeRef(_inc_path_25973);
    DeRef(_mainpath_25993);
    return _full_path_25968;
L3: 

    /** scanner.e:467		sequence mainpath = main_path[1..rfind(SLASH, main_path)]*/
    RefDS(_36main_path_21563);
    DeRef(_31718);
    _31718 = _36main_path_21563;
    if (IS_SEQUENCE(_31718)){
            _31719 = SEQ_PTR(_31718)->length;
    }
    else {
        _31719 = 1;
    }
    _31718 = NOVALUE;
    RefDS(_36main_path_21563);
    _14401 = _16rfind(47LL, _36main_path_21563, _31719);
    _31719 = NOVALUE;
    rhs_slice_target = (object_ptr)&_mainpath_25993;
    RHS_Slice(_36main_path_21563, 1LL, _14401);

    /** scanner.e:468		if not equal(mainpath, currdir) then*/
    if (_mainpath_25993 == _currdir_25970)
    _14403 = 1;
    else if (IS_ATOM_INT(_mainpath_25993) && IS_ATOM_INT(_currdir_25970))
    _14403 = 0;
    else
    _14403 = (compare(_mainpath_25993, _currdir_25970) == 0);
    if (_14403 != 0)
    goto L4; // [113] 141
    _14403 = NOVALUE;

    /** scanner.e:469			full_path = mainpath & new_include_name*/
    Concat((object_ptr)&_full_path_25968, _mainpath_25993, _36new_include_name_21565);

    /** scanner.e:470			if file_exists(full_path) then*/
    RefDS(_full_path_25968);
    _14406 = _17file_exists(_full_path_25968);
    if (_14406 == 0) {
        DeRef(_14406);
        _14406 = NOVALUE;
        goto L5; // [130] 140
    }
    else {
        if (!IS_ATOM_INT(_14406) && DBL_PTR(_14406)->dbl == 0.0){
            DeRef(_14406);
            _14406 = NOVALUE;
            goto L5; // [130] 140
        }
        DeRef(_14406);
        _14406 = NOVALUE;
    }
    DeRef(_14406);
    _14406 = NOVALUE;

    /** scanner.e:471				return full_path*/
    DeRefDS(_fname_25966);
    DeRef(_errbuff_25969);
    DeRefDS(_currdir_25970);
    DeRef(_conf_path_25971);
    DeRef(_scan_result_25972);
    DeRef(_inc_path_25973);
    DeRefDS(_mainpath_25993);
    _31718 = NOVALUE;
    DeRef(_14401);
    _14401 = NOVALUE;
    return _full_path_25968;
L5: 
L4: 

    /** scanner.e:475		scan_result = ConfPath(new_include_name)*/
    RefDS(_36new_include_name_21565);
    _0 = _scan_result_25972;
    _scan_result_25972 = _48ConfPath(_36new_include_name_21565);
    DeRef(_0);

    /** scanner.e:477		if atom(scan_result) then*/
    _14408 = IS_ATOM(_scan_result_25972);
    if (_14408 == 0)
    {
        _14408 = NOVALUE;
        goto L6; // [154] 166
    }
    else{
        _14408 = NOVALUE;
    }

    /** scanner.e:478			scan_result = ScanPath(fname,"EUINC",0)*/
    RefDS(_fname_25966);
    RefDS(_14409);
    _0 = _scan_result_25972;
    _scan_result_25972 = _48ScanPath(_fname_25966, _14409, 0LL);
    DeRef(_0);
L6: 

    /** scanner.e:481		if atom(scan_result) then*/
    _14411 = IS_ATOM(_scan_result_25972);
    if (_14411 == 0)
    {
        _14411 = NOVALUE;
        goto L7; // [171] 183
    }
    else{
        _14411 = NOVALUE;
    }

    /** scanner.e:482			scan_result = ScanPath(fname, "EUDIR",1)*/
    RefDS(_fname_25966);
    RefDS(_14412);
    _0 = _scan_result_25972;
    _scan_result_25972 = _48ScanPath(_fname_25966, _14412, 1LL);
    DeRef(_0);
L7: 

    /** scanner.e:485		if atom(scan_result) then*/
    _14414 = IS_ATOM(_scan_result_25972);
    if (_14414 == 0)
    {
        _14414 = NOVALUE;
        goto L8; // [188] 225
    }
    else{
        _14414 = NOVALUE;
    }

    /** scanner.e:487			full_path = get_eudir() & SLASH & "include" & SLASH & fname*/
    _14415 = _37get_eudir();
    {
        object concat_list[5];

        concat_list[0] = _fname_25966;
        concat_list[1] = 47LL;
        concat_list[2] = _13175;
        concat_list[3] = 47LL;
        concat_list[4] = _14415;
        Concat_N((object_ptr)&_full_path_25968, concat_list, 5);
    }
    DeRef(_14415);
    _14415 = NOVALUE;

    /** scanner.e:488			if file_exists(full_path) then*/
    RefDS(_full_path_25968);
    _14417 = _17file_exists(_full_path_25968);
    if (_14417 == 0) {
        DeRef(_14417);
        _14417 = NOVALUE;
        goto L9; // [214] 224
    }
    else {
        if (!IS_ATOM_INT(_14417) && DBL_PTR(_14417)->dbl == 0.0){
            DeRef(_14417);
            _14417 = NOVALUE;
            goto L9; // [214] 224
        }
        DeRef(_14417);
        _14417 = NOVALUE;
    }
    DeRef(_14417);
    _14417 = NOVALUE;

    /** scanner.e:489				return full_path*/
    DeRefDS(_fname_25966);
    DeRef(_errbuff_25969);
    DeRef(_currdir_25970);
    DeRef(_conf_path_25971);
    DeRef(_scan_result_25972);
    DeRef(_inc_path_25973);
    DeRef(_mainpath_25993);
    _31718 = NOVALUE;
    DeRef(_14401);
    _14401 = NOVALUE;
    return _full_path_25968;
L9: 
L8: 

    /** scanner.e:493		if sequence(scan_result) then*/
    _14418 = IS_SEQUENCE(_scan_result_25972);
    if (_14418 == 0)
    {
        _14418 = NOVALUE;
        goto LA; // [230] 252
    }
    else{
        _14418 = NOVALUE;
    }

    /** scanner.e:495			close(scan_result[2])*/
    _2 = (object)SEQ_PTR(_scan_result_25972);
    _14419 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_14419))
    EClose(_14419);
    else
    EClose((object)DBL_PTR(_14419)->dbl);
    _14419 = NOVALUE;

    /** scanner.e:496			return scan_result[1]*/
    _2 = (object)SEQ_PTR(_scan_result_25972);
    _14420 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_14420);
    DeRefDS(_fname_25966);
    DeRef(_full_path_25968);
    DeRef(_errbuff_25969);
    DeRef(_currdir_25970);
    DeRef(_conf_path_25971);
    DeRef(_scan_result_25972);
    DeRef(_inc_path_25973);
    DeRef(_mainpath_25993);
    _31718 = NOVALUE;
    DeRef(_14401);
    _14401 = NOVALUE;
    return _14420;
LA: 

    /** scanner.e:500		errbuff = ""*/
    RefDS(_5);
    DeRef(_errbuff_25969);
    _errbuff_25969 = _5;

    /** scanner.e:501		full_path = {}*/
    RefDS(_5);
    DeRef(_full_path_25968);
    _full_path_25968 = _5;

    /** scanner.e:502		if length(currdir) > 0 then*/
    if (IS_SEQUENCE(_currdir_25970)){
            _14421 = SEQ_PTR(_currdir_25970)->length;
    }
    else {
        _14421 = 1;
    }
    if (_14421 <= 0LL)
    goto LB; // [271] 323

    /** scanner.e:503			if find(currdir[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_currdir_25970)){
            _14423 = SEQ_PTR(_currdir_25970)->length;
    }
    else {
        _14423 = 1;
    }
    _2 = (object)SEQ_PTR(_currdir_25970);
    _14424 = (object)*(((s1_ptr)_2)->base + _14423);
    _14425 = find_from(_14424, _46SLASH_CHARS_21606, 1LL);
    _14424 = NOVALUE;
    if (_14425 == 0)
    {
        _14425 = NOVALUE;
        goto LC; // [291] 315
    }
    else{
        _14425 = NOVALUE;
    }

    /** scanner.e:504				full_path = append(full_path, currdir[1..$-1])*/
    if (IS_SEQUENCE(_currdir_25970)){
            _14426 = SEQ_PTR(_currdir_25970)->length;
    }
    else {
        _14426 = 1;
    }
    _14427 = _14426 - 1LL;
    _14426 = NOVALUE;
    rhs_slice_target = (object_ptr)&_14428;
    RHS_Slice(_currdir_25970, 1LL, _14427);
    RefDS(_14428);
    Append(&_full_path_25968, _full_path_25968, _14428);
    DeRefDS(_14428);
    _14428 = NOVALUE;
    goto LD; // [312] 322
LC: 

    /** scanner.e:506				full_path = append(full_path, currdir)*/
    RefDS(_currdir_25970);
    Append(&_full_path_25968, _full_path_25968, _currdir_25970);
LD: 
LB: 

    /** scanner.e:511		if find(main_path[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_36main_path_21563)){
            _14431 = SEQ_PTR(_36main_path_21563)->length;
    }
    else {
        _14431 = 1;
    }
    _2 = (object)SEQ_PTR(_36main_path_21563);
    _14432 = (object)*(((s1_ptr)_2)->base + _14431);
    _14433 = find_from(_14432, _46SLASH_CHARS_21606, 1LL);
    _14432 = NOVALUE;
    if (_14433 == 0)
    {
        _14433 = NOVALUE;
        goto LE; // [341] 363
    }
    else{
        _14433 = NOVALUE;
    }

    /** scanner.e:512			errbuff = main_path[1..$-1]  -- looks better*/
    if (IS_SEQUENCE(_36main_path_21563)){
            _14434 = SEQ_PTR(_36main_path_21563)->length;
    }
    else {
        _14434 = 1;
    }
    _14435 = _14434 - 1LL;
    _14434 = NOVALUE;
    rhs_slice_target = (object_ptr)&_errbuff_25969;
    RHS_Slice(_36main_path_21563, 1LL, _14435);
    goto LF; // [360] 373
LE: 

    /** scanner.e:514			errbuff = main_path*/
    RefDS(_36main_path_21563);
    DeRef(_errbuff_25969);
    _errbuff_25969 = _36main_path_21563;
LF: 

    /** scanner.e:516		if not find(errbuff, full_path) then*/
    _14437 = find_from(_errbuff_25969, _full_path_25968, 1LL);
    if (_14437 != 0)
    goto L10; // [380] 390
    _14437 = NOVALUE;

    /** scanner.e:517			full_path = append(full_path, errbuff)*/
    RefDS(_errbuff_25969);
    Append(&_full_path_25968, _full_path_25968, _errbuff_25969);
L10: 

    /** scanner.e:520		conf_path = get_conf_dirs()*/
    _0 = _conf_path_25971;
    _conf_path_25971 = _48get_conf_dirs();
    DeRef(_0);

    /** scanner.e:521		if length(conf_path) > 0 then*/
    if (IS_SEQUENCE(_conf_path_25971)){
            _14441 = SEQ_PTR(_conf_path_25971)->length;
    }
    else {
        _14441 = 1;
    }
    if (_14441 <= 0LL)
    goto L11; // [402] 509

    /** scanner.e:522			conf_path = split(conf_path, PATHSEP)*/
    RefDS(_conf_path_25971);
    _0 = _conf_path_25971;
    _conf_path_25971 = _23split(_conf_path_25971, 58LL, 0LL, 0LL);
    DeRefDS(_0);

    /** scanner.e:523			for i = 1 to length(conf_path) do*/
    if (IS_SEQUENCE(_conf_path_25971)){
            _14444 = SEQ_PTR(_conf_path_25971)->length;
    }
    else {
        _14444 = 1;
    }
    {
        object _i_26074;
        _i_26074 = 1LL;
L12: 
        if (_i_26074 > _14444){
            goto L13; // [424] 508
        }

        /** scanner.e:524				if find(conf_path[i][$], SLASH_CHARS) then*/
        _2 = (object)SEQ_PTR(_conf_path_25971);
        _14445 = (object)*(((s1_ptr)_2)->base + _i_26074);
        if (IS_SEQUENCE(_14445)){
                _14446 = SEQ_PTR(_14445)->length;
        }
        else {
            _14446 = 1;
        }
        _2 = (object)SEQ_PTR(_14445);
        _14447 = (object)*(((s1_ptr)_2)->base + _14446);
        _14445 = NOVALUE;
        _14448 = find_from(_14447, _46SLASH_CHARS_21606, 1LL);
        _14447 = NOVALUE;
        if (_14448 == 0)
        {
            _14448 = NOVALUE;
            goto L14; // [451] 475
        }
        else{
            _14448 = NOVALUE;
        }

        /** scanner.e:525					errbuff = conf_path[i][1..$-1]  -- looks better*/
        _2 = (object)SEQ_PTR(_conf_path_25971);
        _14449 = (object)*(((s1_ptr)_2)->base + _i_26074);
        if (IS_SEQUENCE(_14449)){
                _14450 = SEQ_PTR(_14449)->length;
        }
        else {
            _14450 = 1;
        }
        _14451 = _14450 - 1LL;
        _14450 = NOVALUE;
        rhs_slice_target = (object_ptr)&_errbuff_25969;
        RHS_Slice(_14449, 1LL, _14451);
        _14449 = NOVALUE;
        goto L15; // [472] 484
L14: 

        /** scanner.e:527					errbuff = conf_path[i]*/
        DeRef(_errbuff_25969);
        _2 = (object)SEQ_PTR(_conf_path_25971);
        _errbuff_25969 = (object)*(((s1_ptr)_2)->base + _i_26074);
        Ref(_errbuff_25969);
L15: 

        /** scanner.e:529				if not find(errbuff, full_path) then*/
        _14454 = find_from(_errbuff_25969, _full_path_25968, 1LL);
        if (_14454 != 0)
        goto L16; // [491] 501
        _14454 = NOVALUE;

        /** scanner.e:530					full_path = append(full_path, errbuff)*/
        RefDS(_errbuff_25969);
        Append(&_full_path_25968, _full_path_25968, _errbuff_25969);
L16: 

        /** scanner.e:532			end for*/
        _i_26074 = _i_26074 + 1LL;
        goto L12; // [503] 431
L13: 
        ;
    }
L11: 

    /** scanner.e:535		inc_path = getenv("EUINC")*/
    DeRef(_inc_path_25973);
    _inc_path_25973 = EGetEnv(_14409);

    /** scanner.e:536		if sequence(inc_path) then*/
    _14458 = IS_SEQUENCE(_inc_path_25973);
    if (_14458 == 0)
    {
        _14458 = NOVALUE;
        goto L17; // [519] 633
    }
    else{
        _14458 = NOVALUE;
    }

    /** scanner.e:537			if length(inc_path) > 0 then*/
    if (IS_SEQUENCE(_inc_path_25973)){
            _14459 = SEQ_PTR(_inc_path_25973)->length;
    }
    else {
        _14459 = 1;
    }
    if (_14459 <= 0LL)
    goto L18; // [527] 632

    /** scanner.e:538				inc_path = split(inc_path, PATHSEP)*/
    Ref(_inc_path_25973);
    _0 = _inc_path_25973;
    _inc_path_25973 = _23split(_inc_path_25973, 58LL, 0LL, 0LL);
    DeRefi(_0);

    /** scanner.e:539				for i = 1 to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_25973)){
            _14462 = SEQ_PTR(_inc_path_25973)->length;
    }
    else {
        _14462 = 1;
    }
    {
        object _i_26102;
        _i_26102 = 1LL;
L19: 
        if (_i_26102 > _14462){
            goto L1A; // [547] 631
        }

        /** scanner.e:540					if find(inc_path[i][$], SLASH_CHARS) then*/
        _2 = (object)SEQ_PTR(_inc_path_25973);
        _14463 = (object)*(((s1_ptr)_2)->base + _i_26102);
        if (IS_SEQUENCE(_14463)){
                _14464 = SEQ_PTR(_14463)->length;
        }
        else {
            _14464 = 1;
        }
        _2 = (object)SEQ_PTR(_14463);
        _14465 = (object)*(((s1_ptr)_2)->base + _14464);
        _14463 = NOVALUE;
        _14466 = find_from(_14465, _46SLASH_CHARS_21606, 1LL);
        _14465 = NOVALUE;
        if (_14466 == 0)
        {
            _14466 = NOVALUE;
            goto L1B; // [574] 598
        }
        else{
            _14466 = NOVALUE;
        }

        /** scanner.e:541						errbuff = inc_path[i][1..$-1]  -- looks better*/
        _2 = (object)SEQ_PTR(_inc_path_25973);
        _14467 = (object)*(((s1_ptr)_2)->base + _i_26102);
        if (IS_SEQUENCE(_14467)){
                _14468 = SEQ_PTR(_14467)->length;
        }
        else {
            _14468 = 1;
        }
        _14469 = _14468 - 1LL;
        _14468 = NOVALUE;
        rhs_slice_target = (object_ptr)&_errbuff_25969;
        RHS_Slice(_14467, 1LL, _14469);
        _14467 = NOVALUE;
        goto L1C; // [595] 607
L1B: 

        /** scanner.e:543						errbuff = inc_path[i]*/
        DeRef(_errbuff_25969);
        _2 = (object)SEQ_PTR(_inc_path_25973);
        _errbuff_25969 = (object)*(((s1_ptr)_2)->base + _i_26102);
        Ref(_errbuff_25969);
L1C: 

        /** scanner.e:545					if not find(errbuff, full_path) then*/
        _14472 = find_from(_errbuff_25969, _full_path_25968, 1LL);
        if (_14472 != 0)
        goto L1D; // [614] 624
        _14472 = NOVALUE;

        /** scanner.e:546						full_path = append(full_path, errbuff)*/
        RefDS(_errbuff_25969);
        Append(&_full_path_25968, _full_path_25968, _errbuff_25969);
L1D: 

        /** scanner.e:548				end for*/
        _i_26102 = _i_26102 + 1LL;
        goto L19; // [626] 554
L1A: 
        ;
    }
L18: 
L17: 

    /** scanner.e:552		if length(get_eudir()) > 0 then*/
    _14475 = _37get_eudir();
    if (IS_SEQUENCE(_14475)){
            _14476 = SEQ_PTR(_14475)->length;
    }
    else {
        _14476 = 1;
    }
    DeRef(_14475);
    _14475 = NOVALUE;
    if (_14476 <= 0LL)
    goto L1E; // [641] 669

    /** scanner.e:553			if not find(get_eudir(), full_path) then*/
    _14478 = _37get_eudir();
    _14479 = find_from(_14478, _full_path_25968, 1LL);
    DeRef(_14478);
    _14478 = NOVALUE;
    if (_14479 != 0)
    goto L1F; // [655] 668
    _14479 = NOVALUE;

    /** scanner.e:554				full_path = append(full_path, get_eudir())*/
    _14481 = _37get_eudir();
    Ref(_14481);
    Append(&_full_path_25968, _full_path_25968, _14481);
    DeRef(_14481);
    _14481 = NOVALUE;
L1F: 
L1E: 

    /** scanner.e:558		errbuff = ""*/
    RefDS(_5);
    DeRef(_errbuff_25969);
    _errbuff_25969 = _5;

    /** scanner.e:559		for i = 1 to length(full_path) do*/
    if (IS_SEQUENCE(_full_path_25968)){
            _14483 = SEQ_PTR(_full_path_25968)->length;
    }
    else {
        _14483 = 1;
    }
    {
        object _i_26134;
        _i_26134 = 1LL;
L20: 
        if (_i_26134 > _14483){
            goto L21; // [681] 713
        }

        /** scanner.e:560			errbuff &= sprintf("\t%s\n", {full_path[i]})*/
        _2 = (object)SEQ_PTR(_full_path_25968);
        _14485 = (object)*(((s1_ptr)_2)->base + _i_26134);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_14485);
        ((intptr_t*)_2)[1] = _14485;
        _14486 = MAKE_SEQ(_1);
        _14485 = NOVALUE;
        _14487 = EPrintf(-9999999, _14484, _14486);
        DeRefDS(_14486);
        _14486 = NOVALUE;
        Concat((object_ptr)&_errbuff_25969, _errbuff_25969, _14487);
        DeRefDS(_14487);
        _14487 = NOVALUE;

        /** scanner.e:561		end for*/
        _i_26134 = _i_26134 + 1LL;
        goto L20; // [708] 688
L21: 
        ;
    }

    /** scanner.e:563		CompileErr(CANT_FIND_1_IN_ANY_OF_2, {new_include_name, errbuff})*/
    RefDS(_errbuff_25969);
    RefDS(_36new_include_name_21565);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _36new_include_name_21565;
    ((intptr_t *)_2)[2] = _errbuff_25969;
    _14489 = MAKE_SEQ(_1);
    _50CompileErr(52LL, _14489, 0LL);
    _14489 = NOVALUE;
    ;
}


object _62path_open()
{
    object _fh_26147 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:569		new_include_name = find_file(new_include_name)*/
    RefDS(_36new_include_name_21565);
    _0 = _62find_file(_36new_include_name_21565);
    DeRefDS(_36new_include_name_21565);
    _36new_include_name_21565 = _0;

    /** scanner.e:570		new_include_name = maybe_preprocess(new_include_name)*/
    RefDS(_36new_include_name_21565);
    _0 = _64maybe_preprocess(_36new_include_name_21565);
    DeRefDS(_36new_include_name_21565);
    _36new_include_name_21565 = _0;

    /** scanner.e:572		fh = open_locked(new_include_name)*/
    RefDS(_36new_include_name_21565);
    _fh_26147 = _37open_locked(_36new_include_name_21565);
    if (!IS_ATOM_INT(_fh_26147)) {
        _1 = (object)(DBL_PTR(_fh_26147)->dbl);
        DeRefDS(_fh_26147);
        _fh_26147 = _1;
    }

    /** scanner.e:573		return fh*/
    return _fh_26147;
    ;
}


object _62NameSpace_declaration(object _sym_26171)
{
    object _h_26172 = NOVALUE;
    object _14511 = NOVALUE;
    object _14509 = NOVALUE;
    object _14507 = NOVALUE;
    object _14505 = NOVALUE;
    object _14504 = NOVALUE;
    object _14503 = NOVALUE;
    object _14501 = NOVALUE;
    object _14500 = NOVALUE;
    object _14499 = NOVALUE;
    object _14498 = NOVALUE;
    object _14497 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_26171)) {
        _1 = (object)(DBL_PTR(_sym_26171)->dbl);
        DeRefDS(_sym_26171);
        _sym_26171 = _1;
    }

    /** scanner.e:594		DefinedYet(sym)*/
    _54DefinedYet(_sym_26171);

    /** scanner.e:595		if find(SymTab[sym][S_SCOPE], {SC_GLOBAL, SC_PUBLIC, SC_EXPORT, SC_PREDEF}) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _14497 = (object)*(((s1_ptr)_2)->base + _sym_26171);
    _2 = (object)SEQ_PTR(_14497);
    _14498 = (object)*(((s1_ptr)_2)->base + 4LL);
    _14497 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 6LL;
    ((intptr_t*)_2)[2] = 13LL;
    ((intptr_t*)_2)[3] = 11LL;
    ((intptr_t*)_2)[4] = 7LL;
    _14499 = MAKE_SEQ(_1);
    _14500 = find_from(_14498, _14499, 1LL);
    _14498 = NOVALUE;
    DeRefDS(_14499);
    _14499 = NOVALUE;
    if (_14500 == 0)
    {
        _14500 = NOVALUE;
        goto L1; // [42] 104
    }
    else{
        _14500 = NOVALUE;
    }

    /** scanner.e:597			h = SymTab[sym][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _14501 = (object)*(((s1_ptr)_2)->base + _sym_26171);
    _2 = (object)SEQ_PTR(_14501);
    _h_26172 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (!IS_ATOM_INT(_h_26172)){
        _h_26172 = (object)DBL_PTR(_h_26172)->dbl;
    }
    _14501 = NOVALUE;

    /** scanner.e:599			sym = NewEntry(SymTab[sym][S_NAME], 0, 0, VARIABLE, h, buckets[h], 0)*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _14503 = (object)*(((s1_ptr)_2)->base + _sym_26171);
    _2 = (object)SEQ_PTR(_14503);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _14504 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _14504 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _14503 = NOVALUE;
    _2 = (object)SEQ_PTR(_54buckets_46772);
    _14505 = (object)*(((s1_ptr)_2)->base + _h_26172);
    Ref(_14504);
    Ref(_14505);
    _sym_26171 = _54NewEntry(_14504, 0LL, 0LL, -100LL, _h_26172, _14505, 0LL);
    _14504 = NOVALUE;
    _14505 = NOVALUE;
    if (!IS_ATOM_INT(_sym_26171)) {
        _1 = (object)(DBL_PTR(_sym_26171)->dbl);
        DeRefDS(_sym_26171);
        _sym_26171 = _1;
    }

    /** scanner.e:600			buckets[h] = sym*/
    _2 = (object)SEQ_PTR(_54buckets_46772);
    _2 = (object)(((s1_ptr)_2)->base + _h_26172);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_26171;
    DeRef(_1);
L1: 

    /** scanner.e:602		SymTab[sym][S_SCOPE] = SC_LOCAL*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26171 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 5LL;
    DeRef(_1);
    _14507 = NOVALUE;

    /** scanner.e:603		SymTab[sym][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26171 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _14509 = NOVALUE;

    /** scanner.e:604		SymTab[sym][S_TOKEN] = NAMESPACE -- [S_OBJ] will get the file number referred-to*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26171 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_TOKEN_21081))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 523LL;
    DeRef(_1);
    _14511 = NOVALUE;

    /** scanner.e:605		if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L2; // [159] 173
    }
    else{
    }

    /** scanner.e:606			num_routines += 1 -- order of ns declaration relative to routines*/
    _36num_routines_21448 = _36num_routines_21448 + 1LL;
L2: 

    /** scanner.e:609		return sym*/
    return _sym_26171;
    ;
}


void _62default_namespace()
{
    object _tok_26222 = NOVALUE;
    object _sym_26224 = NOVALUE;
    object _14535 = NOVALUE;
    object _14534 = NOVALUE;
    object _14532 = NOVALUE;
    object _14530 = NOVALUE;
    object _14527 = NOVALUE;
    object _14524 = NOVALUE;
    object _14522 = NOVALUE;
    object _14520 = NOVALUE;
    object _14519 = NOVALUE;
    object _14518 = NOVALUE;
    object _14517 = NOVALUE;
    object _14516 = NOVALUE;
    object _14515 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:618		tok = call_func( scanner_rid, {} )*/
    _0 = (object)_00[_62scanner_rid_26218].addr;
    _1 = (*(intptr_t (*)())_0)(
                         );
    DeRef(_tok_26222);
    _tok_26222 = _1;

    /** scanner.e:619		if tok[T_ID] = VARIABLE and equal( SymTab[tok[T_SYM]][S_NAME], "namespace" ) then*/
    _2 = (object)SEQ_PTR(_tok_26222);
    _14515 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_14515)) {
        _14516 = (_14515 == -100LL);
    }
    else {
        _14516 = binary_op(EQUALS, _14515, -100LL);
    }
    _14515 = NOVALUE;
    if (IS_ATOM_INT(_14516)) {
        if (_14516 == 0) {
            goto L1; // [23] 179
        }
    }
    else {
        if (DBL_PTR(_14516)->dbl == 0.0) {
            goto L1; // [23] 179
        }
    }
    _2 = (object)SEQ_PTR(_tok_26222);
    _14518 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_14518)){
        _14519 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14518)->dbl));
    }
    else{
        _14519 = (object)*(((s1_ptr)_2)->base + _14518);
    }
    _2 = (object)SEQ_PTR(_14519);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _14520 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _14520 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _14519 = NOVALUE;
    if (_14520 == _14521)
    _14522 = 1;
    else if (IS_ATOM_INT(_14520) && IS_ATOM_INT(_14521))
    _14522 = 0;
    else
    _14522 = (compare(_14520, _14521) == 0);
    _14520 = NOVALUE;
    if (_14522 == 0)
    {
        _14522 = NOVALUE;
        goto L1; // [50] 179
    }
    else{
        _14522 = NOVALUE;
    }

    /** scanner.e:621			tok = call_func( scanner_rid, {} )*/
    _0 = (object)_00[_62scanner_rid_26218].addr;
    _1 = (*(intptr_t (*)())_0)(
                         );
    DeRef(_tok_26222);
    _tok_26222 = _1;

    /** scanner.e:622			if tok[T_ID] != VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_26222);
    _14524 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _14524, -100LL)){
        _14524 = NOVALUE;
        goto L2; // [71] 85
    }
    _14524 = NOVALUE;

    /** scanner.e:623				CompileErr(MISSING_DEFAULT_NAMESPACE_QUALIFIER)*/
    RefDS(_21993);
    _50CompileErr(114LL, _21993, 0LL);
L2: 

    /** scanner.e:626			sym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_26222);
    _sym_26224 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_sym_26224)){
        _sym_26224 = (object)DBL_PTR(_sym_26224)->dbl;
    }

    /** scanner.e:628			SymTab[sym][S_FILE_NO] = current_file_no*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26224 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_FILE_NO_21072))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36current_file_no_21439;
    DeRef(_1);
    _14527 = NOVALUE;

    /** scanner.e:629			sym  = NameSpace_declaration( sym )*/
    _sym_26224 = _62NameSpace_declaration(_sym_26224);
    if (!IS_ATOM_INT(_sym_26224)) {
        _1 = (object)(DBL_PTR(_sym_26224)->dbl);
        DeRefDS(_sym_26224);
        _sym_26224 = _1;
    }

    /** scanner.e:630			SymTab[sym][S_OBJ] = current_file_no*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26224 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36current_file_no_21439;
    DeRef(_1);
    _14530 = NOVALUE;

    /** scanner.e:631			SymTab[sym][S_SCOPE] = SC_PUBLIC*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26224 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 13LL;
    DeRef(_1);
    _14532 = NOVALUE;

    /** scanner.e:633			default_namespaces[current_file_no] = SymTab[sym][S_NAME]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _14534 = (object)*(((s1_ptr)_2)->base + _sym_26224);
    _2 = (object)SEQ_PTR(_14534);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _14535 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _14535 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _14534 = NOVALUE;
    Ref(_14535);
    _2 = (object)SEQ_PTR(_62default_namespaces_25553);
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21439);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14535;
    if( _1 != _14535 ){
        DeRef(_1);
    }
    _14535 = NOVALUE;
    goto L3; // [176] 187
L1: 

    /** scanner.e:637			bp = 1*/
    _50bp_49238 = 1LL;
L3: 

    /** scanner.e:640	end procedure*/
    DeRef(_tok_26222);
    _14518 = NOVALUE;
    DeRef(_14516);
    _14516 = NOVALUE;
    return;
    ;
}


void _62add_exports(object _from_file_26275, object _to_file_26276)
{
    object _exports_26277 = NOVALUE;
    object _direct_26278 = NOVALUE;
    object _14555 = NOVALUE;
    object _14554 = NOVALUE;
    object _14553 = NOVALUE;
    object _14552 = NOVALUE;
    object _14551 = NOVALUE;
    object _14549 = NOVALUE;
    object _14547 = NOVALUE;
    object _14546 = NOVALUE;
    object _14544 = NOVALUE;
    object _14543 = NOVALUE;
    object _14542 = NOVALUE;
    object _14540 = NOVALUE;
    object _14539 = NOVALUE;
    object _14538 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:645		direct = file_include[to_file]*/
    DeRef(_direct_26278);
    _2 = (object)SEQ_PTR(_37file_include_15411);
    _direct_26278 = (object)*(((s1_ptr)_2)->base + _to_file_26276);
    Ref(_direct_26278);

    /** scanner.e:646		exports = file_public[from_file]*/
    DeRef(_exports_26277);
    _2 = (object)SEQ_PTR(_37file_public_15417);
    _exports_26277 = (object)*(((s1_ptr)_2)->base + _from_file_26275);
    Ref(_exports_26277);

    /** scanner.e:647		for i = 1 to length(exports) do*/
    if (IS_SEQUENCE(_exports_26277)){
            _14538 = SEQ_PTR(_exports_26277)->length;
    }
    else {
        _14538 = 1;
    }
    {
        object _i_26284;
        _i_26284 = 1LL;
L1: 
        if (_i_26284 > _14538){
            goto L2; // [30] 127
        }

        /** scanner.e:648			if not find( exports[i], direct ) then*/
        _2 = (object)SEQ_PTR(_exports_26277);
        _14539 = (object)*(((s1_ptr)_2)->base + _i_26284);
        _14540 = find_from(_14539, _direct_26278, 1LL);
        _14539 = NOVALUE;
        if (_14540 != 0)
        goto L3; // [48] 120
        _14540 = NOVALUE;

        /** scanner.e:649				if not find( -exports[i], direct ) then*/
        _2 = (object)SEQ_PTR(_exports_26277);
        _14542 = (object)*(((s1_ptr)_2)->base + _i_26284);
        if (IS_ATOM_INT(_14542)) {
            if ((uintptr_t)_14542 == (uintptr_t)HIGH_BITS){
                _14543 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _14543 = - _14542;
            }
        }
        else {
            _14543 = unary_op(UMINUS, _14542);
        }
        _14542 = NOVALUE;
        _14544 = find_from(_14543, _direct_26278, 1LL);
        DeRef(_14543);
        _14543 = NOVALUE;
        if (_14544 != 0)
        goto L4; // [65] 82
        _14544 = NOVALUE;

        /** scanner.e:650					direct &= -exports[i]*/
        _2 = (object)SEQ_PTR(_exports_26277);
        _14546 = (object)*(((s1_ptr)_2)->base + _i_26284);
        if (IS_ATOM_INT(_14546)) {
            if ((uintptr_t)_14546 == (uintptr_t)HIGH_BITS){
                _14547 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _14547 = - _14546;
            }
        }
        else {
            _14547 = unary_op(UMINUS, _14546);
        }
        _14546 = NOVALUE;
        if (IS_SEQUENCE(_direct_26278) && IS_ATOM(_14547)) {
            Ref(_14547);
            Append(&_direct_26278, _direct_26278, _14547);
        }
        else if (IS_ATOM(_direct_26278) && IS_SEQUENCE(_14547)) {
        }
        else {
            Concat((object_ptr)&_direct_26278, _direct_26278, _14547);
        }
        DeRef(_14547);
        _14547 = NOVALUE;
L4: 

        /** scanner.e:654				include_matrix[to_file][exports[i]] = or_bits( PUBLIC_INCLUDE, include_matrix[to_file][exports[i]] )*/
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37include_matrix_15413 = MAKE_SEQ(_2);
        }
        _3 = (object)(_to_file_26276 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_exports_26277);
        _14551 = (object)*(((s1_ptr)_2)->base + _i_26284);
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        _14552 = (object)*(((s1_ptr)_2)->base + _to_file_26276);
        _2 = (object)SEQ_PTR(_exports_26277);
        _14553 = (object)*(((s1_ptr)_2)->base + _i_26284);
        _2 = (object)SEQ_PTR(_14552);
        if (!IS_ATOM_INT(_14553)){
            _14554 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14553)->dbl));
        }
        else{
            _14554 = (object)*(((s1_ptr)_2)->base + _14553);
        }
        _14552 = NOVALUE;
        if (IS_ATOM_INT(_14554)) {
            {uintptr_t tu;
                 tu = (uintptr_t)4LL | (uintptr_t)_14554;
                 _14555 = MAKE_UINT(tu);
            }
        }
        else {
            _14555 = binary_op(OR_BITS, 4LL, _14554);
        }
        _14554 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_14551))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14551)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _14551);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14555;
        if( _1 != _14555 ){
            DeRef(_1);
        }
        _14555 = NOVALUE;
        _14549 = NOVALUE;
L3: 

        /** scanner.e:656		end for*/
        _i_26284 = _i_26284 + 1LL;
        goto L1; // [122] 37
L2: 
        ;
    }

    /** scanner.e:657		file_include[to_file] = direct*/
    RefDS(_direct_26278);
    _2 = (object)SEQ_PTR(_37file_include_15411);
    _2 = (object)(((s1_ptr)_2)->base + _to_file_26276);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _direct_26278;
    DeRef(_1);

    /** scanner.e:658	end procedure*/
    DeRef(_exports_26277);
    DeRefDS(_direct_26278);
    _14553 = NOVALUE;
    _14551 = NOVALUE;
    return;
    ;
}


void _62patch_exports(object _for_file_26311)
{
    object _export_len_26312 = NOVALUE;
    object _14566 = NOVALUE;
    object _14565 = NOVALUE;
    object _14563 = NOVALUE;
    object _14562 = NOVALUE;
    object _14561 = NOVALUE;
    object _14560 = NOVALUE;
    object _14558 = NOVALUE;
    object _14557 = NOVALUE;
    object _14556 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:663		for i = 1 to length(file_include) do*/
    if (IS_SEQUENCE(_37file_include_15411)){
            _14556 = SEQ_PTR(_37file_include_15411)->length;
    }
    else {
        _14556 = 1;
    }
    {
        object _i_26314;
        _i_26314 = 1LL;
L1: 
        if (_i_26314 > _14556){
            goto L2; // [10] 99
        }

        /** scanner.e:664			if find( for_file, file_include[i] ) or find( -for_file, file_include[i] ) then*/
        _2 = (object)SEQ_PTR(_37file_include_15411);
        _14557 = (object)*(((s1_ptr)_2)->base + _i_26314);
        _14558 = find_from(_for_file_26311, _14557, 1LL);
        _14557 = NOVALUE;
        if (_14558 != 0) {
            goto L3; // [30] 53
        }
        if ((uintptr_t)_for_file_26311 == (uintptr_t)HIGH_BITS){
            _14560 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _14560 = - _for_file_26311;
        }
        _2 = (object)SEQ_PTR(_37file_include_15411);
        _14561 = (object)*(((s1_ptr)_2)->base + _i_26314);
        _14562 = find_from(_14560, _14561, 1LL);
        DeRef(_14560);
        _14560 = NOVALUE;
        _14561 = NOVALUE;
        if (_14562 == 0)
        {
            _14562 = NOVALUE;
            goto L4; // [49] 92
        }
        else{
            _14562 = NOVALUE;
        }
L3: 

        /** scanner.e:665				export_len = length( file_include[i] )*/
        _2 = (object)SEQ_PTR(_37file_include_15411);
        _14563 = (object)*(((s1_ptr)_2)->base + _i_26314);
        if (IS_SEQUENCE(_14563)){
                _export_len_26312 = SEQ_PTR(_14563)->length;
        }
        else {
            _export_len_26312 = 1;
        }
        _14563 = NOVALUE;

        /** scanner.e:666				add_exports( for_file, i )*/
        _62add_exports(_for_file_26311, _i_26314);

        /** scanner.e:667				if length( file_include[i] ) != export_len then*/
        _2 = (object)SEQ_PTR(_37file_include_15411);
        _14565 = (object)*(((s1_ptr)_2)->base + _i_26314);
        if (IS_SEQUENCE(_14565)){
                _14566 = SEQ_PTR(_14565)->length;
        }
        else {
            _14566 = 1;
        }
        _14565 = NOVALUE;
        if (_14566 == _export_len_26312)
        goto L5; // [81] 91

        /** scanner.e:669					patch_exports( i )*/
        _62patch_exports(_i_26314);
L5: 
L4: 

        /** scanner.e:672		end for*/
        _i_26314 = _i_26314 + 1LL;
        goto L1; // [94] 17
L2: 
        ;
    }

    /** scanner.e:673	end procedure*/
    _14563 = NOVALUE;
    _14565 = NOVALUE;
    return;
    ;
}


void _62update_include_matrix(object _included_file_26336, object _from_file_26337)
{
    object _add_public_26347 = NOVALUE;
    object _px_26365 = NOVALUE;
    object _indirect_26424 = NOVALUE;
    object _mask_26427 = NOVALUE;
    object _ix_26438 = NOVALUE;
    object _indirect_file_26442 = NOVALUE;
    object _14642 = NOVALUE;
    object _14641 = NOVALUE;
    object _14639 = NOVALUE;
    object _14638 = NOVALUE;
    object _14637 = NOVALUE;
    object _14636 = NOVALUE;
    object _14635 = NOVALUE;
    object _14634 = NOVALUE;
    object _14633 = NOVALUE;
    object _14632 = NOVALUE;
    object _14631 = NOVALUE;
    object _14628 = NOVALUE;
    object _14626 = NOVALUE;
    object _14625 = NOVALUE;
    object _14624 = NOVALUE;
    object _14622 = NOVALUE;
    object _14620 = NOVALUE;
    object _14619 = NOVALUE;
    object _14617 = NOVALUE;
    object _14616 = NOVALUE;
    object _14615 = NOVALUE;
    object _14614 = NOVALUE;
    object _14613 = NOVALUE;
    object _14611 = NOVALUE;
    object _14610 = NOVALUE;
    object _14609 = NOVALUE;
    object _14608 = NOVALUE;
    object _14607 = NOVALUE;
    object _14606 = NOVALUE;
    object _14604 = NOVALUE;
    object _14603 = NOVALUE;
    object _14602 = NOVALUE;
    object _14600 = NOVALUE;
    object _14599 = NOVALUE;
    object _14598 = NOVALUE;
    object _14597 = NOVALUE;
    object _14596 = NOVALUE;
    object _14595 = NOVALUE;
    object _14594 = NOVALUE;
    object _14593 = NOVALUE;
    object _14592 = NOVALUE;
    object _14591 = NOVALUE;
    object _14590 = NOVALUE;
    object _14588 = NOVALUE;
    object _14587 = NOVALUE;
    object _14585 = NOVALUE;
    object _14583 = NOVALUE;
    object _14581 = NOVALUE;
    object _14580 = NOVALUE;
    object _14579 = NOVALUE;
    object _14578 = NOVALUE;
    object _14576 = NOVALUE;
    object _14575 = NOVALUE;
    object _14574 = NOVALUE;
    object _14572 = NOVALUE;
    object _14571 = NOVALUE;
    object _14570 = NOVALUE;
    object _14568 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:684		include_matrix[from_file][included_file] = or_bits( DIRECT_INCLUDE, include_matrix[from_file][included_file] )*/
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37include_matrix_15413 = MAKE_SEQ(_2);
    }
    _3 = (object)(_from_file_26337 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    _14570 = (object)*(((s1_ptr)_2)->base + _from_file_26337);
    _2 = (object)SEQ_PTR(_14570);
    _14571 = (object)*(((s1_ptr)_2)->base + _included_file_26336);
    _14570 = NOVALUE;
    if (IS_ATOM_INT(_14571)) {
        {uintptr_t tu;
             tu = (uintptr_t)2LL | (uintptr_t)_14571;
             _14572 = MAKE_UINT(tu);
        }
    }
    else {
        _14572 = binary_op(OR_BITS, 2LL, _14571);
    }
    _14571 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26336);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14572;
    if( _1 != _14572 ){
        DeRef(_1);
    }
    _14572 = NOVALUE;
    _14568 = NOVALUE;

    /** scanner.e:686		if public_include then*/
    if (_62public_include_25550 == 0)
    {
        goto L1; // [38] 339
    }
    else{
    }

    /** scanner.e:689			sequence add_public = file_include_by[from_file]*/
    DeRef(_add_public_26347);
    _2 = (object)SEQ_PTR(_37file_include_by_15419);
    _add_public_26347 = (object)*(((s1_ptr)_2)->base + _from_file_26337);
    Ref(_add_public_26347);

    /** scanner.e:690			for i = 1 to length( add_public ) do*/
    if (IS_SEQUENCE(_add_public_26347)){
            _14574 = SEQ_PTR(_add_public_26347)->length;
    }
    else {
        _14574 = 1;
    }
    {
        object _i_26351;
        _i_26351 = 1LL;
L2: 
        if (_i_26351 > _14574){
            goto L3; // [56] 107
        }

        /** scanner.e:692				include_matrix[add_public[i]][included_file] =*/
        _2 = (object)SEQ_PTR(_add_public_26347);
        _14575 = (object)*(((s1_ptr)_2)->base + _i_26351);
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37include_matrix_15413 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_14575))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14575)->dbl));
        else
        _3 = (object)(_14575 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_add_public_26347);
        _14578 = (object)*(((s1_ptr)_2)->base + _i_26351);
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        if (!IS_ATOM_INT(_14578)){
            _14579 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14578)->dbl));
        }
        else{
            _14579 = (object)*(((s1_ptr)_2)->base + _14578);
        }
        _2 = (object)SEQ_PTR(_14579);
        _14580 = (object)*(((s1_ptr)_2)->base + _included_file_26336);
        _14579 = NOVALUE;
        if (IS_ATOM_INT(_14580)) {
            {uintptr_t tu;
                 tu = (uintptr_t)4LL | (uintptr_t)_14580;
                 _14581 = MAKE_UINT(tu);
            }
        }
        else {
            _14581 = binary_op(OR_BITS, 4LL, _14580);
        }
        _14580 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _included_file_26336);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14581;
        if( _1 != _14581 ){
            DeRef(_1);
        }
        _14581 = NOVALUE;
        _14576 = NOVALUE;

        /** scanner.e:695			end for*/
        _i_26351 = _i_26351 + 1LL;
        goto L2; // [102] 63
L3: 
        ;
    }

    /** scanner.e:698			add_public = file_public_by[from_file]*/
    DeRef(_add_public_26347);
    _2 = (object)SEQ_PTR(_37file_public_by_15421);
    _add_public_26347 = (object)*(((s1_ptr)_2)->base + _from_file_26337);
    Ref(_add_public_26347);

    /** scanner.e:699			integer px = length( add_public ) + 1*/
    if (IS_SEQUENCE(_add_public_26347)){
            _14583 = SEQ_PTR(_add_public_26347)->length;
    }
    else {
        _14583 = 1;
    }
    _px_26365 = _14583 + 1;
    _14583 = NOVALUE;

    /** scanner.e:700			while px <= length( add_public ) do*/
L4: 
    if (IS_SEQUENCE(_add_public_26347)){
            _14585 = SEQ_PTR(_add_public_26347)->length;
    }
    else {
        _14585 = 1;
    }
    if (_px_26365 > _14585)
    goto L5; // [134] 338

    /** scanner.e:701				include_matrix[add_public[px]][included_file] =*/
    _2 = (object)SEQ_PTR(_add_public_26347);
    _14587 = (object)*(((s1_ptr)_2)->base + _px_26365);
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37include_matrix_15413 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_14587))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14587)->dbl));
    else
    _3 = (object)(_14587 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_add_public_26347);
    _14590 = (object)*(((s1_ptr)_2)->base + _px_26365);
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    if (!IS_ATOM_INT(_14590)){
        _14591 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14590)->dbl));
    }
    else{
        _14591 = (object)*(((s1_ptr)_2)->base + _14590);
    }
    _2 = (object)SEQ_PTR(_14591);
    _14592 = (object)*(((s1_ptr)_2)->base + _included_file_26336);
    _14591 = NOVALUE;
    if (IS_ATOM_INT(_14592)) {
        {uintptr_t tu;
             tu = (uintptr_t)4LL | (uintptr_t)_14592;
             _14593 = MAKE_UINT(tu);
        }
    }
    else {
        _14593 = binary_op(OR_BITS, 4LL, _14592);
    }
    _14592 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26336);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14593;
    if( _1 != _14593 ){
        DeRef(_1);
    }
    _14593 = NOVALUE;
    _14588 = NOVALUE;

    /** scanner.e:704				for i = 1 to length( file_public_by[add_public[px]] ) do*/
    _2 = (object)SEQ_PTR(_add_public_26347);
    _14594 = (object)*(((s1_ptr)_2)->base + _px_26365);
    _2 = (object)SEQ_PTR(_37file_public_by_15421);
    if (!IS_ATOM_INT(_14594)){
        _14595 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14594)->dbl));
    }
    else{
        _14595 = (object)*(((s1_ptr)_2)->base + _14594);
    }
    if (IS_SEQUENCE(_14595)){
            _14596 = SEQ_PTR(_14595)->length;
    }
    else {
        _14596 = 1;
    }
    _14595 = NOVALUE;
    {
        object _i_26382;
        _i_26382 = 1LL;
L6: 
        if (_i_26382 > _14596){
            goto L7; // [190] 249
        }

        /** scanner.e:705					if not find( file_public[add_public[px]][i], add_public ) then*/
        _2 = (object)SEQ_PTR(_add_public_26347);
        _14597 = (object)*(((s1_ptr)_2)->base + _px_26365);
        _2 = (object)SEQ_PTR(_37file_public_15417);
        if (!IS_ATOM_INT(_14597)){
            _14598 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14597)->dbl));
        }
        else{
            _14598 = (object)*(((s1_ptr)_2)->base + _14597);
        }
        _2 = (object)SEQ_PTR(_14598);
        _14599 = (object)*(((s1_ptr)_2)->base + _i_26382);
        _14598 = NOVALUE;
        _14600 = find_from(_14599, _add_public_26347, 1LL);
        _14599 = NOVALUE;
        if (_14600 != 0)
        goto L8; // [218] 242
        _14600 = NOVALUE;

        /** scanner.e:706						add_public &= file_public[add_public[px]][i]*/
        _2 = (object)SEQ_PTR(_add_public_26347);
        _14602 = (object)*(((s1_ptr)_2)->base + _px_26365);
        _2 = (object)SEQ_PTR(_37file_public_15417);
        if (!IS_ATOM_INT(_14602)){
            _14603 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14602)->dbl));
        }
        else{
            _14603 = (object)*(((s1_ptr)_2)->base + _14602);
        }
        _2 = (object)SEQ_PTR(_14603);
        _14604 = (object)*(((s1_ptr)_2)->base + _i_26382);
        _14603 = NOVALUE;
        if (IS_SEQUENCE(_add_public_26347) && IS_ATOM(_14604)) {
            Ref(_14604);
            Append(&_add_public_26347, _add_public_26347, _14604);
        }
        else if (IS_ATOM(_add_public_26347) && IS_SEQUENCE(_14604)) {
        }
        else {
            Concat((object_ptr)&_add_public_26347, _add_public_26347, _14604);
        }
        _14604 = NOVALUE;
L8: 

        /** scanner.e:708				end for*/
        _i_26382 = _i_26382 + 1LL;
        goto L6; // [244] 197
L7: 
        ;
    }

    /** scanner.e:710				for i = 1 to length( file_include_by[add_public[px]] ) do*/
    _2 = (object)SEQ_PTR(_add_public_26347);
    _14606 = (object)*(((s1_ptr)_2)->base + _px_26365);
    _2 = (object)SEQ_PTR(_37file_include_by_15419);
    if (!IS_ATOM_INT(_14606)){
        _14607 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14606)->dbl));
    }
    else{
        _14607 = (object)*(((s1_ptr)_2)->base + _14606);
    }
    if (IS_SEQUENCE(_14607)){
            _14608 = SEQ_PTR(_14607)->length;
    }
    else {
        _14608 = 1;
    }
    _14607 = NOVALUE;
    {
        object _i_26400;
        _i_26400 = 1LL;
L9: 
        if (_i_26400 > _14608){
            goto LA; // [264] 327
        }

        /** scanner.e:711					include_matrix[file_include_by[add_public[px]]][included_file] =*/
        _2 = (object)SEQ_PTR(_add_public_26347);
        _14609 = (object)*(((s1_ptr)_2)->base + _px_26365);
        _2 = (object)SEQ_PTR(_37file_include_by_15419);
        if (!IS_ATOM_INT(_14609)){
            _14610 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14609)->dbl));
        }
        else{
            _14610 = (object)*(((s1_ptr)_2)->base + _14609);
        }
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37include_matrix_15413 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_14610))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14610)->dbl));
        else
        _3 = (object)(_14610 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_add_public_26347);
        _14613 = (object)*(((s1_ptr)_2)->base + _px_26365);
        _2 = (object)SEQ_PTR(_37file_include_by_15419);
        if (!IS_ATOM_INT(_14613)){
            _14614 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14613)->dbl));
        }
        else{
            _14614 = (object)*(((s1_ptr)_2)->base + _14613);
        }
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        if (!IS_ATOM_INT(_14614)){
            _14615 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14614)->dbl));
        }
        else{
            _14615 = (object)*(((s1_ptr)_2)->base + _14614);
        }
        _2 = (object)SEQ_PTR(_14615);
        _14616 = (object)*(((s1_ptr)_2)->base + _included_file_26336);
        _14615 = NOVALUE;
        if (IS_ATOM_INT(_14616)) {
            {uintptr_t tu;
                 tu = (uintptr_t)4LL | (uintptr_t)_14616;
                 _14617 = MAKE_UINT(tu);
            }
        }
        else {
            _14617 = binary_op(OR_BITS, 4LL, _14616);
        }
        _14616 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _included_file_26336);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14617;
        if( _1 != _14617 ){
            DeRef(_1);
        }
        _14617 = NOVALUE;
        _14611 = NOVALUE;

        /** scanner.e:713				end for*/
        _i_26400 = _i_26400 + 1LL;
        goto L9; // [322] 271
LA: 
        ;
    }

    /** scanner.e:715				px += 1*/
    _px_26365 = _px_26365 + 1;

    /** scanner.e:716			end while*/
    goto L4; // [335] 131
L5: 
L1: 
    DeRef(_add_public_26347);
    _add_public_26347 = NOVALUE;

    /** scanner.e:721		if indirect_include[from_file][included_file] then*/
    _2 = (object)SEQ_PTR(_37indirect_include_15415);
    _14619 = (object)*(((s1_ptr)_2)->base + _from_file_26337);
    _2 = (object)SEQ_PTR(_14619);
    _14620 = (object)*(((s1_ptr)_2)->base + _included_file_26336);
    _14619 = NOVALUE;
    if (_14620 == 0) {
        _14620 = NOVALUE;
        goto LB; // [353] 545
    }
    else {
        if (!IS_ATOM_INT(_14620) && DBL_PTR(_14620)->dbl == 0.0){
            _14620 = NOVALUE;
            goto LB; // [353] 545
        }
        _14620 = NOVALUE;
    }
    _14620 = NOVALUE;

    /** scanner.e:723			sequence indirect = file_include_by[from_file]*/
    DeRef(_indirect_26424);
    _2 = (object)SEQ_PTR(_37file_include_by_15419);
    _indirect_26424 = (object)*(((s1_ptr)_2)->base + _from_file_26337);
    Ref(_indirect_26424);

    /** scanner.e:725			sequence mask = include_matrix[included_file] != 0*/
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    _14622 = (object)*(((s1_ptr)_2)->base + _included_file_26336);
    DeRef(_mask_26427);
    if (IS_ATOM_INT(_14622)) {
        _mask_26427 = (_14622 != 0LL);
    }
    else {
        _mask_26427 = binary_op(NOTEQ, _14622, 0LL);
    }
    _14622 = NOVALUE;

    /** scanner.e:726			include_matrix[from_file] = or_bits( include_matrix[from_file], mask )*/
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    _14624 = (object)*(((s1_ptr)_2)->base + _from_file_26337);
    _14625 = binary_op(OR_BITS, _14624, _mask_26427);
    _14624 = NOVALUE;
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    _2 = (object)(((s1_ptr)_2)->base + _from_file_26337);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14625;
    if( _1 != _14625 ){
        DeRef(_1);
    }
    _14625 = NOVALUE;

    /** scanner.e:727			mask = include_matrix[from_file] != 0*/
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    _14626 = (object)*(((s1_ptr)_2)->base + _from_file_26337);
    DeRefDS(_mask_26427);
    if (IS_ATOM_INT(_14626)) {
        _mask_26427 = (_14626 != 0LL);
    }
    else {
        _mask_26427 = binary_op(NOTEQ, _14626, 0LL);
    }
    _14626 = NOVALUE;

    /** scanner.e:728			integer ix = 1*/
    _ix_26438 = 1LL;

    /** scanner.e:729			while ix <= length(indirect) do*/
LC: 
    if (IS_SEQUENCE(_indirect_26424)){
            _14628 = SEQ_PTR(_indirect_26424)->length;
    }
    else {
        _14628 = 1;
    }
    if (_ix_26438 > _14628)
    goto LD; // [425] 544

    /** scanner.e:730				integer indirect_file = indirect[ix]*/
    _2 = (object)SEQ_PTR(_indirect_26424);
    _indirect_file_26442 = (object)*(((s1_ptr)_2)->base + _ix_26438);
    if (!IS_ATOM_INT(_indirect_file_26442))
    _indirect_file_26442 = (object)DBL_PTR(_indirect_file_26442)->dbl;

    /** scanner.e:731				if indirect_include[indirect_file][included_file] then*/
    _2 = (object)SEQ_PTR(_37indirect_include_15415);
    _14631 = (object)*(((s1_ptr)_2)->base + _indirect_file_26442);
    _2 = (object)SEQ_PTR(_14631);
    _14632 = (object)*(((s1_ptr)_2)->base + _included_file_26336);
    _14631 = NOVALUE;
    if (_14632 == 0) {
        _14632 = NOVALUE;
        goto LE; // [447] 531
    }
    else {
        if (!IS_ATOM_INT(_14632) && DBL_PTR(_14632)->dbl == 0.0){
            _14632 = NOVALUE;
            goto LE; // [447] 531
        }
        _14632 = NOVALUE;
    }
    _14632 = NOVALUE;

    /** scanner.e:732					include_matrix[indirect_file] =*/
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    _14633 = (object)*(((s1_ptr)_2)->base + _indirect_file_26442);
    _14634 = binary_op(OR_BITS, _mask_26427, _14633);
    _14633 = NOVALUE;
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    _2 = (object)(((s1_ptr)_2)->base + _indirect_file_26442);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14634;
    if( _1 != _14634 ){
        DeRef(_1);
    }
    _14634 = NOVALUE;

    /** scanner.e:734					for i = 1 to length( file_include_by[indirect_file] ) do*/
    _2 = (object)SEQ_PTR(_37file_include_by_15419);
    _14635 = (object)*(((s1_ptr)_2)->base + _indirect_file_26442);
    if (IS_SEQUENCE(_14635)){
            _14636 = SEQ_PTR(_14635)->length;
    }
    else {
        _14636 = 1;
    }
    _14635 = NOVALUE;
    {
        object _i_26453;
        _i_26453 = 1LL;
LF: 
        if (_i_26453 > _14636){
            goto L10; // [479] 530
        }

        /** scanner.e:736						if not find( file_include_by[indirect_file][i], indirect ) then*/
        _2 = (object)SEQ_PTR(_37file_include_by_15419);
        _14637 = (object)*(((s1_ptr)_2)->base + _indirect_file_26442);
        _2 = (object)SEQ_PTR(_14637);
        _14638 = (object)*(((s1_ptr)_2)->base + _i_26453);
        _14637 = NOVALUE;
        _14639 = find_from(_14638, _indirect_26424, 1LL);
        _14638 = NOVALUE;
        if (_14639 != 0)
        goto L11; // [503] 523
        _14639 = NOVALUE;

        /** scanner.e:737							indirect &= file_include_by[indirect_file][i]*/
        _2 = (object)SEQ_PTR(_37file_include_by_15419);
        _14641 = (object)*(((s1_ptr)_2)->base + _indirect_file_26442);
        _2 = (object)SEQ_PTR(_14641);
        _14642 = (object)*(((s1_ptr)_2)->base + _i_26453);
        _14641 = NOVALUE;
        if (IS_SEQUENCE(_indirect_26424) && IS_ATOM(_14642)) {
            Ref(_14642);
            Append(&_indirect_26424, _indirect_26424, _14642);
        }
        else if (IS_ATOM(_indirect_26424) && IS_SEQUENCE(_14642)) {
        }
        else {
            Concat((object_ptr)&_indirect_26424, _indirect_26424, _14642);
        }
        _14642 = NOVALUE;
L11: 

        /** scanner.e:740					end for*/
        _i_26453 = _i_26453 + 1LL;
        goto LF; // [525] 486
L10: 
        ;
    }
LE: 

    /** scanner.e:742				ix += 1*/
    _ix_26438 = _ix_26438 + 1;

    /** scanner.e:743			end while*/
    goto LC; // [541] 422
LD: 
LB: 
    DeRef(_indirect_26424);
    _indirect_26424 = NOVALUE;
    DeRef(_mask_26427);
    _mask_26427 = NOVALUE;

    /** scanner.e:746		public_include = FALSE*/
    _62public_include_25550 = _13FALSE_450;

    /** scanner.e:747	end procedure*/
    _14597 = NOVALUE;
    _14587 = NOVALUE;
    _14595 = NOVALUE;
    _14635 = NOVALUE;
    _14602 = NOVALUE;
    _14609 = NOVALUE;
    _14578 = NOVALUE;
    _14607 = NOVALUE;
    _14614 = NOVALUE;
    _14575 = NOVALUE;
    _14610 = NOVALUE;
    _14613 = NOVALUE;
    _14594 = NOVALUE;
    _14590 = NOVALUE;
    _14606 = NOVALUE;
    return;
    ;
}


void _62add_include_by(object _by_file_26471, object _included_file_26472, object _is_public_26473)
{
    object _14689 = NOVALUE;
    object _14688 = NOVALUE;
    object _14687 = NOVALUE;
    object _14685 = NOVALUE;
    object _14684 = NOVALUE;
    object _14683 = NOVALUE;
    object _14682 = NOVALUE;
    object _14680 = NOVALUE;
    object _14679 = NOVALUE;
    object _14678 = NOVALUE;
    object _14677 = NOVALUE;
    object _14676 = NOVALUE;
    object _14675 = NOVALUE;
    object _14674 = NOVALUE;
    object _14673 = NOVALUE;
    object _14671 = NOVALUE;
    object _14670 = NOVALUE;
    object _14669 = NOVALUE;
    object _14668 = NOVALUE;
    object _14666 = NOVALUE;
    object _14665 = NOVALUE;
    object _14664 = NOVALUE;
    object _14663 = NOVALUE;
    object _14661 = NOVALUE;
    object _14660 = NOVALUE;
    object _14659 = NOVALUE;
    object _14658 = NOVALUE;
    object _14656 = NOVALUE;
    object _14655 = NOVALUE;
    object _14654 = NOVALUE;
    object _14653 = NOVALUE;
    object _14652 = NOVALUE;
    object _14650 = NOVALUE;
    object _14649 = NOVALUE;
    object _14648 = NOVALUE;
    object _14647 = NOVALUE;
    object _14645 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:750		include_matrix[by_file][included_file] = or_bits( DIRECT_INCLUDE, include_matrix[by_file][included_file] )*/
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37include_matrix_15413 = MAKE_SEQ(_2);
    }
    _3 = (object)(_by_file_26471 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    _14647 = (object)*(((s1_ptr)_2)->base + _by_file_26471);
    _2 = (object)SEQ_PTR(_14647);
    _14648 = (object)*(((s1_ptr)_2)->base + _included_file_26472);
    _14647 = NOVALUE;
    if (IS_ATOM_INT(_14648)) {
        {uintptr_t tu;
             tu = (uintptr_t)2LL | (uintptr_t)_14648;
             _14649 = MAKE_UINT(tu);
        }
    }
    else {
        _14649 = binary_op(OR_BITS, 2LL, _14648);
    }
    _14648 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26472);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14649;
    if( _1 != _14649 ){
        DeRef(_1);
    }
    _14649 = NOVALUE;
    _14645 = NOVALUE;

    /** scanner.e:751		if is_public then*/
    if (_is_public_26473 == 0)
    {
        goto L1; // [38] 71
    }
    else{
    }

    /** scanner.e:752			include_matrix[by_file][included_file] = or_bits( PUBLIC_INCLUDE, include_matrix[by_file][included_file] )*/
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37include_matrix_15413 = MAKE_SEQ(_2);
    }
    _3 = (object)(_by_file_26471 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    _14652 = (object)*(((s1_ptr)_2)->base + _by_file_26471);
    _2 = (object)SEQ_PTR(_14652);
    _14653 = (object)*(((s1_ptr)_2)->base + _included_file_26472);
    _14652 = NOVALUE;
    if (IS_ATOM_INT(_14653)) {
        {uintptr_t tu;
             tu = (uintptr_t)4LL | (uintptr_t)_14653;
             _14654 = MAKE_UINT(tu);
        }
    }
    else {
        _14654 = binary_op(OR_BITS, 4LL, _14653);
    }
    _14653 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26472);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14654;
    if( _1 != _14654 ){
        DeRef(_1);
    }
    _14654 = NOVALUE;
    _14650 = NOVALUE;
L1: 

    /** scanner.e:754		if not find( by_file, file_include_by[included_file] ) then*/
    _2 = (object)SEQ_PTR(_37file_include_by_15419);
    _14655 = (object)*(((s1_ptr)_2)->base + _included_file_26472);
    _14656 = find_from(_by_file_26471, _14655, 1LL);
    _14655 = NOVALUE;
    if (_14656 != 0)
    goto L2; // [84] 104
    _14656 = NOVALUE;

    /** scanner.e:755			file_include_by[included_file] &= by_file*/
    _2 = (object)SEQ_PTR(_37file_include_by_15419);
    _14658 = (object)*(((s1_ptr)_2)->base + _included_file_26472);
    if (IS_SEQUENCE(_14658) && IS_ATOM(_by_file_26471)) {
        Append(&_14659, _14658, _by_file_26471);
    }
    else if (IS_ATOM(_14658) && IS_SEQUENCE(_by_file_26471)) {
    }
    else {
        Concat((object_ptr)&_14659, _14658, _by_file_26471);
        _14658 = NOVALUE;
    }
    _14658 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_include_by_15419);
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26472);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14659;
    if( _1 != _14659 ){
        DeRef(_1);
    }
    _14659 = NOVALUE;
L2: 

    /** scanner.e:758		if not find( included_file, file_include[by_file] ) then*/
    _2 = (object)SEQ_PTR(_37file_include_15411);
    _14660 = (object)*(((s1_ptr)_2)->base + _by_file_26471);
    _14661 = find_from(_included_file_26472, _14660, 1LL);
    _14660 = NOVALUE;
    if (_14661 != 0)
    goto L3; // [117] 137
    _14661 = NOVALUE;

    /** scanner.e:759			file_include[by_file] &= included_file*/
    _2 = (object)SEQ_PTR(_37file_include_15411);
    _14663 = (object)*(((s1_ptr)_2)->base + _by_file_26471);
    if (IS_SEQUENCE(_14663) && IS_ATOM(_included_file_26472)) {
        Append(&_14664, _14663, _included_file_26472);
    }
    else if (IS_ATOM(_14663) && IS_SEQUENCE(_included_file_26472)) {
    }
    else {
        Concat((object_ptr)&_14664, _14663, _included_file_26472);
        _14663 = NOVALUE;
    }
    _14663 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_include_15411);
    _2 = (object)(((s1_ptr)_2)->base + _by_file_26471);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14664;
    if( _1 != _14664 ){
        DeRef(_1);
    }
    _14664 = NOVALUE;
L3: 

    /** scanner.e:762		if is_public then*/
    if (_is_public_26473 == 0)
    {
        goto L4; // [139] 209
    }
    else{
    }

    /** scanner.e:763			if not find( by_file, file_public_by[included_file] ) then*/
    _2 = (object)SEQ_PTR(_37file_public_by_15421);
    _14665 = (object)*(((s1_ptr)_2)->base + _included_file_26472);
    _14666 = find_from(_by_file_26471, _14665, 1LL);
    _14665 = NOVALUE;
    if (_14666 != 0)
    goto L5; // [155] 175
    _14666 = NOVALUE;

    /** scanner.e:764				file_public_by[included_file] &= by_file*/
    _2 = (object)SEQ_PTR(_37file_public_by_15421);
    _14668 = (object)*(((s1_ptr)_2)->base + _included_file_26472);
    if (IS_SEQUENCE(_14668) && IS_ATOM(_by_file_26471)) {
        Append(&_14669, _14668, _by_file_26471);
    }
    else if (IS_ATOM(_14668) && IS_SEQUENCE(_by_file_26471)) {
    }
    else {
        Concat((object_ptr)&_14669, _14668, _by_file_26471);
        _14668 = NOVALUE;
    }
    _14668 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_public_by_15421);
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26472);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14669;
    if( _1 != _14669 ){
        DeRef(_1);
    }
    _14669 = NOVALUE;
L5: 

    /** scanner.e:767			if not find( included_file, file_public[by_file] ) then*/
    _2 = (object)SEQ_PTR(_37file_public_15417);
    _14670 = (object)*(((s1_ptr)_2)->base + _by_file_26471);
    _14671 = find_from(_included_file_26472, _14670, 1LL);
    _14670 = NOVALUE;
    if (_14671 != 0)
    goto L6; // [188] 208
    _14671 = NOVALUE;

    /** scanner.e:768				file_public[by_file] &= included_file*/
    _2 = (object)SEQ_PTR(_37file_public_15417);
    _14673 = (object)*(((s1_ptr)_2)->base + _by_file_26471);
    if (IS_SEQUENCE(_14673) && IS_ATOM(_included_file_26472)) {
        Append(&_14674, _14673, _included_file_26472);
    }
    else if (IS_ATOM(_14673) && IS_SEQUENCE(_included_file_26472)) {
    }
    else {
        Concat((object_ptr)&_14674, _14673, _included_file_26472);
        _14673 = NOVALUE;
    }
    _14673 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_public_15417);
    _2 = (object)(((s1_ptr)_2)->base + _by_file_26471);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14674;
    if( _1 != _14674 ){
        DeRef(_1);
    }
    _14674 = NOVALUE;
L6: 
L4: 

    /** scanner.e:772		for propagate = 1 to length( include_matrix[included_file] ) do*/
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    _14675 = (object)*(((s1_ptr)_2)->base + _included_file_26472);
    if (IS_SEQUENCE(_14675)){
            _14676 = SEQ_PTR(_14675)->length;
    }
    else {
        _14676 = 1;
    }
    _14675 = NOVALUE;
    {
        object _propagate_26525;
        _propagate_26525 = 1LL;
L7: 
        if (_propagate_26525 > _14676){
            goto L8; // [220] 320
        }

        /** scanner.e:773			if and_bits( PUBLIC_INCLUDE, include_matrix[included_file][propagate] ) then*/
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        _14677 = (object)*(((s1_ptr)_2)->base + _included_file_26472);
        _2 = (object)SEQ_PTR(_14677);
        _14678 = (object)*(((s1_ptr)_2)->base + _propagate_26525);
        _14677 = NOVALUE;
        if (IS_ATOM_INT(_14678)) {
            {uintptr_t tu;
                 tu = (uintptr_t)4LL & (uintptr_t)_14678;
                 _14679 = MAKE_UINT(tu);
            }
        }
        else {
            _14679 = binary_op(AND_BITS, 4LL, _14678);
        }
        _14678 = NOVALUE;
        if (_14679 == 0) {
            DeRef(_14679);
            _14679 = NOVALUE;
            goto L9; // [245] 313
        }
        else {
            if (!IS_ATOM_INT(_14679) && DBL_PTR(_14679)->dbl == 0.0){
                DeRef(_14679);
                _14679 = NOVALUE;
                goto L9; // [245] 313
            }
            DeRef(_14679);
            _14679 = NOVALUE;
        }
        DeRef(_14679);
        _14679 = NOVALUE;

        /** scanner.e:774				include_matrix[by_file][propagate] = or_bits( DIRECT_INCLUDE, include_matrix[by_file][propagate] )*/
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37include_matrix_15413 = MAKE_SEQ(_2);
        }
        _3 = (object)(_by_file_26471 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        _14682 = (object)*(((s1_ptr)_2)->base + _by_file_26471);
        _2 = (object)SEQ_PTR(_14682);
        _14683 = (object)*(((s1_ptr)_2)->base + _propagate_26525);
        _14682 = NOVALUE;
        if (IS_ATOM_INT(_14683)) {
            {uintptr_t tu;
                 tu = (uintptr_t)2LL | (uintptr_t)_14683;
                 _14684 = MAKE_UINT(tu);
            }
        }
        else {
            _14684 = binary_op(OR_BITS, 2LL, _14683);
        }
        _14683 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _propagate_26525);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14684;
        if( _1 != _14684 ){
            DeRef(_1);
        }
        _14684 = NOVALUE;
        _14680 = NOVALUE;

        /** scanner.e:775				if is_public then*/
        if (_is_public_26473 == 0)
        {
            goto LA; // [279] 312
        }
        else{
        }

        /** scanner.e:776					include_matrix[by_file][propagate] = or_bits( PUBLIC_INCLUDE, include_matrix[by_file][propagate] )*/
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37include_matrix_15413 = MAKE_SEQ(_2);
        }
        _3 = (object)(_by_file_26471 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        _14687 = (object)*(((s1_ptr)_2)->base + _by_file_26471);
        _2 = (object)SEQ_PTR(_14687);
        _14688 = (object)*(((s1_ptr)_2)->base + _propagate_26525);
        _14687 = NOVALUE;
        if (IS_ATOM_INT(_14688)) {
            {uintptr_t tu;
                 tu = (uintptr_t)4LL | (uintptr_t)_14688;
                 _14689 = MAKE_UINT(tu);
            }
        }
        else {
            _14689 = binary_op(OR_BITS, 4LL, _14688);
        }
        _14688 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _propagate_26525);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14689;
        if( _1 != _14689 ){
            DeRef(_1);
        }
        _14689 = NOVALUE;
        _14685 = NOVALUE;
LA: 
L9: 

        /** scanner.e:779		end for*/
        _propagate_26525 = _propagate_26525 + 1LL;
        goto L7; // [315] 227
L8: 
        ;
    }

    /** scanner.e:780	end procedure*/
    _14675 = NOVALUE;
    return;
    ;
}


void _62IncludePush()
{
    object _new_file_handle_26554 = NOVALUE;
    object _old_file_no_26555 = NOVALUE;
    object _new_hash_26556 = NOVALUE;
    object _idx_26557 = NOVALUE;
    object _14776 = NOVALUE;
    object _14773 = NOVALUE;
    object _14771 = NOVALUE;
    object _14770 = NOVALUE;
    object _14769 = NOVALUE;
    object _14767 = NOVALUE;
    object _14766 = NOVALUE;
    object _14760 = NOVALUE;
    object _14759 = NOVALUE;
    object _14758 = NOVALUE;
    object _14757 = NOVALUE;
    object _14756 = NOVALUE;
    object _14755 = NOVALUE;
    object _14754 = NOVALUE;
    object _14751 = NOVALUE;
    object _14749 = NOVALUE;
    object _14747 = NOVALUE;
    object _14746 = NOVALUE;
    object _14745 = NOVALUE;
    object _14743 = NOVALUE;
    object _14742 = NOVALUE;
    object _14740 = NOVALUE;
    object _14739 = NOVALUE;
    object _14737 = NOVALUE;
    object _14736 = NOVALUE;
    object _14735 = NOVALUE;
    object _14734 = NOVALUE;
    object _14733 = NOVALUE;
    object _14732 = NOVALUE;
    object _14731 = NOVALUE;
    object _14727 = NOVALUE;
    object _14725 = NOVALUE;
    object _14724 = NOVALUE;
    object _14723 = NOVALUE;
    object _14722 = NOVALUE;
    object _14721 = NOVALUE;
    object _14720 = NOVALUE;
    object _14719 = NOVALUE;
    object _14718 = NOVALUE;
    object _14717 = NOVALUE;
    object _14715 = NOVALUE;
    object _14714 = NOVALUE;
    object _14713 = NOVALUE;
    object _14711 = NOVALUE;
    object _14710 = NOVALUE;
    object _14709 = NOVALUE;
    object _14708 = NOVALUE;
    object _14706 = NOVALUE;
    object _14705 = NOVALUE;
    object _14704 = NOVALUE;
    object _14703 = NOVALUE;
    object _14702 = NOVALUE;
    object _14700 = NOVALUE;
    object _14699 = NOVALUE;
    object _14698 = NOVALUE;
    object _14697 = NOVALUE;
    object _14695 = NOVALUE;
    object _14691 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:788		start_include = FALSE*/
    _62start_include_25547 = _13FALSE_450;

    /** scanner.e:790		new_file_handle = path_open() -- sets new_include_name to full path*/
    _new_file_handle_26554 = _62path_open();
    if (!IS_ATOM_INT(_new_file_handle_26554)) {
        _1 = (object)(DBL_PTR(_new_file_handle_26554)->dbl);
        DeRefDS(_new_file_handle_26554);
        _new_file_handle_26554 = _1;
    }

    /** scanner.e:792		new_hash = hash(canonical_path(new_include_name,,CORRECT), stdhash:HSIEH32)*/
    RefDS(_36new_include_name_21565);
    _14691 = _17canonical_path(_36new_include_name_21565, 0LL, 2LL);
    DeRef(_new_hash_26556);
    _new_hash_26556 = calc_hash(_14691, -5LL);
    DeRef(_14691);
    _14691 = NOVALUE;

    /** scanner.e:794		idx = find(new_hash, known_files_hash)*/
    _idx_26557 = find_from(_new_hash_26556, _37known_files_hash_15408, 1LL);

    /** scanner.e:795		if idx then*/
    if (_idx_26557 == 0)
    {
        goto L1; // [42] 335
    }
    else{
    }

    /** scanner.e:797			if new_include_space != 0 then*/
    if (_62new_include_space_25545 == 0LL)
    goto L2; // [49] 71

    /** scanner.e:798				SymTab[new_include_space][S_OBJ] = idx -- but note any namespace*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_62new_include_space_25545 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _idx_26557;
    DeRef(_1);
    _14695 = NOVALUE;
L2: 

    /** scanner.e:801			close(new_file_handle)*/
    EClose(_new_file_handle_26554);

    /** scanner.e:803			if find( -idx, file_include[current_file_no] ) then*/
    if ((uintptr_t)_idx_26557 == (uintptr_t)HIGH_BITS){
        _14697 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _14697 = - _idx_26557;
    }
    _2 = (object)SEQ_PTR(_37file_include_15411);
    _14698 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
    _14699 = find_from(_14697, _14698, 1LL);
    DeRef(_14697);
    _14697 = NOVALUE;
    _14698 = NOVALUE;
    if (_14699 == 0)
    {
        _14699 = NOVALUE;
        goto L3; // [93] 130
    }
    else{
        _14699 = NOVALUE;
    }

    /** scanner.e:805				file_include[current_file_no][ find( -idx, file_include[current_file_no] ) ] = idx*/
    _2 = (object)SEQ_PTR(_37file_include_15411);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37file_include_15411 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36current_file_no_21439 + ((s1_ptr)_2)->base);
    if ((uintptr_t)_idx_26557 == (uintptr_t)HIGH_BITS){
        _14702 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _14702 = - _idx_26557;
    }
    _2 = (object)SEQ_PTR(_37file_include_15411);
    _14703 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
    _14704 = find_from(_14702, _14703, 1LL);
    DeRef(_14702);
    _14702 = NOVALUE;
    _14703 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14704);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _idx_26557;
    DeRef(_1);
    _14700 = NOVALUE;
    goto L4; // [127] 228
L3: 

    /** scanner.e:809			elsif not find( idx, file_include[current_file_no] ) then*/
    _2 = (object)SEQ_PTR(_37file_include_15411);
    _14705 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
    _14706 = find_from(_idx_26557, _14705, 1LL);
    _14705 = NOVALUE;
    if (_14706 != 0)
    goto L5; // [145] 227
    _14706 = NOVALUE;

    /** scanner.e:811				file_include[current_file_no] &= idx*/
    _2 = (object)SEQ_PTR(_37file_include_15411);
    _14708 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
    if (IS_SEQUENCE(_14708) && IS_ATOM(_idx_26557)) {
        Append(&_14709, _14708, _idx_26557);
    }
    else if (IS_ATOM(_14708) && IS_SEQUENCE(_idx_26557)) {
    }
    else {
        Concat((object_ptr)&_14709, _14708, _idx_26557);
        _14708 = NOVALUE;
    }
    _14708 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_include_15411);
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21439);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14709;
    if( _1 != _14709 ){
        DeRef(_1);
    }
    _14709 = NOVALUE;

    /** scanner.e:814				add_exports( idx, current_file_no )*/
    _62add_exports(_idx_26557, _36current_file_no_21439);

    /** scanner.e:816				if public_include then*/
    if (_62public_include_25550 == 0)
    {
        goto L6; // [178] 226
    }
    else{
    }

    /** scanner.e:818					if not find( idx, file_public[current_file_no] ) then*/
    _2 = (object)SEQ_PTR(_37file_public_15417);
    _14710 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
    _14711 = find_from(_idx_26557, _14710, 1LL);
    _14710 = NOVALUE;
    if (_14711 != 0)
    goto L7; // [196] 225
    _14711 = NOVALUE;

    /** scanner.e:819						file_public[current_file_no] &= idx*/
    _2 = (object)SEQ_PTR(_37file_public_15417);
    _14713 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
    if (IS_SEQUENCE(_14713) && IS_ATOM(_idx_26557)) {
        Append(&_14714, _14713, _idx_26557);
    }
    else if (IS_ATOM(_14713) && IS_SEQUENCE(_idx_26557)) {
    }
    else {
        Concat((object_ptr)&_14714, _14713, _idx_26557);
        _14713 = NOVALUE;
    }
    _14713 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_public_15417);
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21439);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14714;
    if( _1 != _14714 ){
        DeRef(_1);
    }
    _14714 = NOVALUE;

    /** scanner.e:820						patch_exports( current_file_no )*/
    _62patch_exports(_36current_file_no_21439);
L7: 
L6: 
L5: 
L4: 

    /** scanner.e:825			indirect_include[current_file_no][idx] = OpIndirectInclude*/
    _2 = (object)SEQ_PTR(_37indirect_include_15415);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37indirect_include_15415 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36current_file_no_21439 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _idx_26557);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36OpIndirectInclude_21518;
    DeRef(_1);
    _14715 = NOVALUE;

    /** scanner.e:826			add_include_by( current_file_no, idx, public_include )*/
    _62add_include_by(_36current_file_no_21439, _idx_26557, _62public_include_25550);

    /** scanner.e:827			update_include_matrix( idx, current_file_no )*/
    _62update_include_matrix(_idx_26557, _36current_file_no_21439);

    /** scanner.e:828			public_include = FALSE*/
    _62public_include_25550 = _13FALSE_450;

    /** scanner.e:829			read_line() -- we can't return without reading a line first*/
    _62read_line();

    /** scanner.e:830			if not find( idx, file_include_depend[current_file_no] ) and not finished_files[idx] then*/
    _2 = (object)SEQ_PTR(_37file_include_depend_15410);
    _14717 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
    _14718 = find_from(_idx_26557, _14717, 1LL);
    _14717 = NOVALUE;
    _14719 = (_14718 == 0);
    _14718 = NOVALUE;
    if (_14719 == 0) {
        goto L8; // [293] 329
    }
    _2 = (object)SEQ_PTR(_37finished_files_15409);
    _14721 = (object)*(((s1_ptr)_2)->base + _idx_26557);
    _14722 = (_14721 == 0);
    _14721 = NOVALUE;
    if (_14722 == 0)
    {
        DeRef(_14722);
        _14722 = NOVALUE;
        goto L8; // [307] 329
    }
    else{
        DeRef(_14722);
        _14722 = NOVALUE;
    }

    /** scanner.e:831				file_include_depend[current_file_no] &= idx*/
    _2 = (object)SEQ_PTR(_37file_include_depend_15410);
    _14723 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
    if (IS_SEQUENCE(_14723) && IS_ATOM(_idx_26557)) {
        Append(&_14724, _14723, _idx_26557);
    }
    else if (IS_ATOM(_14723) && IS_SEQUENCE(_idx_26557)) {
    }
    else {
        Concat((object_ptr)&_14724, _14723, _idx_26557);
        _14723 = NOVALUE;
    }
    _14723 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_include_depend_15410);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37file_include_depend_15410 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21439);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14724;
    if( _1 != _14724 ){
        DeRef(_1);
    }
    _14724 = NOVALUE;
L8: 

    /** scanner.e:833			return -- ignore it*/
    DeRef(_new_hash_26556);
    DeRef(_14719);
    _14719 = NOVALUE;
    return;
L1: 

    /** scanner.e:836		if length(IncludeStk) >= INCLUDE_LIMIT then*/
    if (IS_SEQUENCE(_62IncludeStk_25556)){
            _14725 = SEQ_PTR(_62IncludeStk_25556)->length;
    }
    else {
        _14725 = 1;
    }
    if (_14725 < 30LL)
    goto L9; // [342] 356

    /** scanner.e:837			CompileErr(INCLUDES_ARE_NESTED_TOO_DEEPLY)*/
    RefDS(_21993);
    _50CompileErr(104LL, _21993, 0LL);
L9: 

    /** scanner.e:840		IncludeStk = append(IncludeStk,*/
    _1 = NewS1(22);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _36current_file_no_21439;
    ((intptr_t*)_2)[2] = _36line_number_21440;
    ((intptr_t*)_2)[3] = _36src_file_21564;
    ((intptr_t*)_2)[4] = _36file_start_sym_21445;
    ((intptr_t*)_2)[5] = _36OpWarning_21510;
    ((intptr_t*)_2)[6] = _36OpTrace_21512;
    ((intptr_t*)_2)[7] = _36OpTypeCheck_21513;
    ((intptr_t*)_2)[8] = _36OpProfileTime_21515;
    ((intptr_t*)_2)[9] = _36OpProfileStatement_21514;
    RefDS(_36OpDefines_21516);
    ((intptr_t*)_2)[10] = _36OpDefines_21516;
    ((intptr_t*)_2)[11] = _36prev_OpWarning_21511;
    ((intptr_t*)_2)[12] = _36OpInline_21517;
    ((intptr_t*)_2)[13] = _36OpIndirectInclude_21518;
    ((intptr_t*)_2)[14] = _36putback_fwd_line_number_21442;
    Ref(_50putback_ForwardLine_49236);
    ((intptr_t*)_2)[15] = _50putback_ForwardLine_49236;
    ((intptr_t*)_2)[16] = _50putback_forward_bp_49240;
    ((intptr_t*)_2)[17] = _36last_fwd_line_number_21443;
    Ref(_50last_ForwardLine_49237);
    ((intptr_t*)_2)[18] = _50last_ForwardLine_49237;
    ((intptr_t*)_2)[19] = _50last_forward_bp_49241;
    Ref(_50ThisLine_49234);
    ((intptr_t*)_2)[20] = _50ThisLine_49234;
    ((intptr_t*)_2)[21] = _36fwd_line_number_21441;
    ((intptr_t*)_2)[22] = _50forward_bp_49239;
    _14727 = MAKE_SEQ(_1);
    RefDS(_14727);
    Append(&_62IncludeStk_25556, _62IncludeStk_25556, _14727);
    DeRefDS(_14727);
    _14727 = NOVALUE;

    /** scanner.e:864		file_include = append( file_include, {} )*/
    RefDS(_5);
    Append(&_37file_include_15411, _37file_include_15411, _5);

    /** scanner.e:865		file_include_by = append( file_include_by, {} )*/
    RefDS(_5);
    Append(&_37file_include_by_15419, _37file_include_by_15419, _5);

    /** scanner.e:866		for i = 1 to length( include_matrix) do*/
    if (IS_SEQUENCE(_37include_matrix_15413)){
            _14731 = SEQ_PTR(_37include_matrix_15413)->length;
    }
    else {
        _14731 = 1;
    }
    {
        object _i_26670;
        _i_26670 = 1LL;
LA: 
        if (_i_26670 > _14731){
            goto LB; // [460] 506
        }

        /** scanner.e:867			include_matrix[i]   &= 0*/
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        _14732 = (object)*(((s1_ptr)_2)->base + _i_26670);
        if (IS_SEQUENCE(_14732) && IS_ATOM(0LL)) {
            Append(&_14733, _14732, 0LL);
        }
        else if (IS_ATOM(_14732) && IS_SEQUENCE(0LL)) {
        }
        else {
            Concat((object_ptr)&_14733, _14732, 0LL);
            _14732 = NOVALUE;
        }
        _14732 = NOVALUE;
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        _2 = (object)(((s1_ptr)_2)->base + _i_26670);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14733;
        if( _1 != _14733 ){
            DeRef(_1);
        }
        _14733 = NOVALUE;

        /** scanner.e:868			indirect_include[i] &= 0*/
        _2 = (object)SEQ_PTR(_37indirect_include_15415);
        _14734 = (object)*(((s1_ptr)_2)->base + _i_26670);
        if (IS_SEQUENCE(_14734) && IS_ATOM(0LL)) {
            Append(&_14735, _14734, 0LL);
        }
        else if (IS_ATOM(_14734) && IS_SEQUENCE(0LL)) {
        }
        else {
            Concat((object_ptr)&_14735, _14734, 0LL);
            _14734 = NOVALUE;
        }
        _14734 = NOVALUE;
        _2 = (object)SEQ_PTR(_37indirect_include_15415);
        _2 = (object)(((s1_ptr)_2)->base + _i_26670);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14735;
        if( _1 != _14735 ){
            DeRef(_1);
        }
        _14735 = NOVALUE;

        /** scanner.e:869		end for*/
        _i_26670 = _i_26670 + 1LL;
        goto LA; // [501] 467
LB: 
        ;
    }

    /** scanner.e:870		include_matrix = append( include_matrix, repeat( 0, length( file_include ) ) )*/
    if (IS_SEQUENCE(_37file_include_15411)){
            _14736 = SEQ_PTR(_37file_include_15411)->length;
    }
    else {
        _14736 = 1;
    }
    _14737 = Repeat(0LL, _14736);
    _14736 = NOVALUE;
    RefDS(_14737);
    Append(&_37include_matrix_15413, _37include_matrix_15413, _14737);
    DeRefDS(_14737);
    _14737 = NOVALUE;

    /** scanner.e:871		include_matrix[$][$] = DIRECT_INCLUDE*/
    if (IS_SEQUENCE(_37include_matrix_15413)){
            _14739 = SEQ_PTR(_37include_matrix_15413)->length;
    }
    else {
        _14739 = 1;
    }
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37include_matrix_15413 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14739 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(*(object_ptr)_3)){
            _14742 = SEQ_PTR(*(object_ptr)_3)->length;
    }
    else {
        _14742 = 1;
    }
    _14740 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14742);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _14740 = NOVALUE;

    /** scanner.e:872		include_matrix[current_file_no][$] = DIRECT_INCLUDE*/
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37include_matrix_15413 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36current_file_no_21439 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(*(object_ptr)_3)){
            _14745 = SEQ_PTR(*(object_ptr)_3)->length;
    }
    else {
        _14745 = 1;
    }
    _14743 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14745);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _14743 = NOVALUE;

    /** scanner.e:874		indirect_include = append( indirect_include, repeat( 0, length( file_include ) ) )*/
    if (IS_SEQUENCE(_37file_include_15411)){
            _14746 = SEQ_PTR(_37file_include_15411)->length;
    }
    else {
        _14746 = 1;
    }
    _14747 = Repeat(0LL, _14746);
    _14746 = NOVALUE;
    RefDS(_14747);
    Append(&_37indirect_include_15415, _37indirect_include_15415, _14747);
    DeRefDS(_14747);
    _14747 = NOVALUE;

    /** scanner.e:875		indirect_include[current_file_no][$] = OpIndirectInclude*/
    _2 = (object)SEQ_PTR(_37indirect_include_15415);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37indirect_include_15415 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36current_file_no_21439 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(*(object_ptr)_3)){
            _14751 = SEQ_PTR(*(object_ptr)_3)->length;
    }
    else {
        _14751 = 1;
    }
    _14749 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14751);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36OpIndirectInclude_21518;
    DeRef(_1);
    _14749 = NOVALUE;

    /** scanner.e:876		OpIndirectInclude = 1*/
    _36OpIndirectInclude_21518 = 1LL;

    /** scanner.e:878		file_public  = append( file_public, {} )*/
    RefDS(_5);
    Append(&_37file_public_15417, _37file_public_15417, _5);

    /** scanner.e:879		file_public_by = append( file_public_by, {} )*/
    RefDS(_5);
    Append(&_37file_public_by_15421, _37file_public_by_15421, _5);

    /** scanner.e:880		file_include[current_file_no] &= length( file_include )*/
    if (IS_SEQUENCE(_37file_include_15411)){
            _14754 = SEQ_PTR(_37file_include_15411)->length;
    }
    else {
        _14754 = 1;
    }
    _2 = (object)SEQ_PTR(_37file_include_15411);
    _14755 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
    if (IS_SEQUENCE(_14755) && IS_ATOM(_14754)) {
        Append(&_14756, _14755, _14754);
    }
    else if (IS_ATOM(_14755) && IS_SEQUENCE(_14754)) {
    }
    else {
        Concat((object_ptr)&_14756, _14755, _14754);
        _14755 = NOVALUE;
    }
    _14755 = NOVALUE;
    _14754 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_include_15411);
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21439);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14756;
    if( _1 != _14756 ){
        DeRef(_1);
    }
    _14756 = NOVALUE;

    /** scanner.e:881		add_include_by( current_file_no, length(file_include), public_include )*/
    if (IS_SEQUENCE(_37file_include_15411)){
            _14757 = SEQ_PTR(_37file_include_15411)->length;
    }
    else {
        _14757 = 1;
    }
    _62add_include_by(_36current_file_no_21439, _14757, _62public_include_25550);
    _14757 = NOVALUE;

    /** scanner.e:882		if public_include then*/
    if (_62public_include_25550 == 0)
    {
        goto LC; // [675] 709
    }
    else{
    }

    /** scanner.e:883			file_public[current_file_no] &= length( file_public )*/
    if (IS_SEQUENCE(_37file_public_15417)){
            _14758 = SEQ_PTR(_37file_public_15417)->length;
    }
    else {
        _14758 = 1;
    }
    _2 = (object)SEQ_PTR(_37file_public_15417);
    _14759 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
    if (IS_SEQUENCE(_14759) && IS_ATOM(_14758)) {
        Append(&_14760, _14759, _14758);
    }
    else if (IS_ATOM(_14759) && IS_SEQUENCE(_14758)) {
    }
    else {
        Concat((object_ptr)&_14760, _14759, _14758);
        _14759 = NOVALUE;
    }
    _14759 = NOVALUE;
    _14758 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_public_15417);
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21439);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14760;
    if( _1 != _14760 ){
        DeRef(_1);
    }
    _14760 = NOVALUE;

    /** scanner.e:884			patch_exports( current_file_no )*/
    _62patch_exports(_36current_file_no_21439);
LC: 

    /** scanner.e:887	ifdef STDDEBUG then*/

    /** scanner.e:893		src_file = new_file_handle*/
    _36src_file_21564 = _new_file_handle_26554;

    /** scanner.e:894		file_start_sym = last_sym*/
    _36file_start_sym_21445 = _54last_sym_46785;

    /** scanner.e:895		if current_file_no >= MAX_FILE then*/
    if (_36current_file_no_21439 < 256LL)
    goto LD; // [731] 745

    /** scanner.e:896			CompileErr(PROGRAM_INCLUDES_TOO_MANY_FILES)*/
    RefDS(_21993);
    _50CompileErr(126LL, _21993, 0LL);
LD: 

    /** scanner.e:898		known_files = append(known_files, new_include_name)*/
    RefDS(_36new_include_name_21565);
    Append(&_37known_files_15407, _37known_files_15407, _36new_include_name_21565);

    /** scanner.e:899		known_files_hash &= new_hash*/
    Ref(_new_hash_26556);
    Append(&_37known_files_hash_15408, _37known_files_hash_15408, _new_hash_26556);

    /** scanner.e:900		finished_files &= 0*/
    Append(&_37finished_files_15409, _37finished_files_15409, 0LL);

    /** scanner.e:901		file_include_depend = append( file_include_depend, { length( known_files ) } )*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _14766 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _14766 = 1;
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _14766;
    _14767 = MAKE_SEQ(_1);
    _14766 = NOVALUE;
    RefDS(_14767);
    Append(&_37file_include_depend_15410, _37file_include_depend_15410, _14767);
    DeRefDS(_14767);
    _14767 = NOVALUE;

    /** scanner.e:902		file_include_depend[current_file_no] &= length( known_files )*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _14769 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _14769 = 1;
    }
    _2 = (object)SEQ_PTR(_37file_include_depend_15410);
    _14770 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
    if (IS_SEQUENCE(_14770) && IS_ATOM(_14769)) {
        Append(&_14771, _14770, _14769);
    }
    else if (IS_ATOM(_14770) && IS_SEQUENCE(_14769)) {
    }
    else {
        Concat((object_ptr)&_14771, _14770, _14769);
        _14770 = NOVALUE;
    }
    _14770 = NOVALUE;
    _14769 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_include_depend_15410);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37file_include_depend_15410 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21439);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14771;
    if( _1 != _14771 ){
        DeRef(_1);
    }
    _14771 = NOVALUE;

    /** scanner.e:903		check_coverage()*/
    _51check_coverage();

    /** scanner.e:904		default_namespaces &= 0*/
    Append(&_62default_namespaces_25553, _62default_namespaces_25553, 0LL);

    /** scanner.e:906		update_include_matrix( length( file_include ), current_file_no )*/
    if (IS_SEQUENCE(_37file_include_15411)){
            _14773 = SEQ_PTR(_37file_include_15411)->length;
    }
    else {
        _14773 = 1;
    }
    _62update_include_matrix(_14773, _36current_file_no_21439);
    _14773 = NOVALUE;

    /** scanner.e:907		old_file_no = current_file_no*/
    _old_file_no_26555 = _36current_file_no_21439;

    /** scanner.e:908		current_file_no = length(known_files)*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _36current_file_no_21439 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _36current_file_no_21439 = 1;
    }

    /** scanner.e:909		line_number = 0*/
    _36line_number_21440 = 0LL;

    /** scanner.e:910		read_line()*/
    _62read_line();

    /** scanner.e:912		if new_include_space != 0 then*/
    if (_62new_include_space_25545 == 0LL)
    goto LE; // [877] 901

    /** scanner.e:913			SymTab[new_include_space][S_OBJ] = current_file_no*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_62new_include_space_25545 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36current_file_no_21439;
    DeRef(_1);
    _14776 = NOVALUE;
LE: 

    /** scanner.e:915		default_namespace( )*/
    _62default_namespace();

    /** scanner.e:916	end procedure*/
    DeRef(_new_hash_26556);
    DeRef(_14719);
    _14719 = NOVALUE;
    return;
    ;
}


void _62update_include_completion(object _file_no_26781)
{
    object _fx_26790 = NOVALUE;
    object _14786 = NOVALUE;
    object _14785 = NOVALUE;
    object _14784 = NOVALUE;
    object _14783 = NOVALUE;
    object _14781 = NOVALUE;
    object _14780 = NOVALUE;
    object _14779 = NOVALUE;
    object _14778 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:919		for i = 1 to length( file_include_depend ) do*/
    if (IS_SEQUENCE(_37file_include_depend_15410)){
            _14778 = SEQ_PTR(_37file_include_depend_15410)->length;
    }
    else {
        _14778 = 1;
    }
    {
        object _i_26783;
        _i_26783 = 1LL;
L1: 
        if (_i_26783 > _14778){
            goto L2; // [10] 114
        }

        /** scanner.e:920			if length( file_include_depend[i] ) then*/
        _2 = (object)SEQ_PTR(_37file_include_depend_15410);
        _14779 = (object)*(((s1_ptr)_2)->base + _i_26783);
        if (IS_SEQUENCE(_14779)){
                _14780 = SEQ_PTR(_14779)->length;
        }
        else {
            _14780 = 1;
        }
        _14779 = NOVALUE;
        if (_14780 == 0)
        {
            _14780 = NOVALUE;
            goto L3; // [28] 105
        }
        else{
            _14780 = NOVALUE;
        }

        /** scanner.e:921				integer fx = find( file_no, file_include_depend[i] )*/
        _2 = (object)SEQ_PTR(_37file_include_depend_15410);
        _14781 = (object)*(((s1_ptr)_2)->base + _i_26783);
        _fx_26790 = find_from(_file_no_26781, _14781, 1LL);
        _14781 = NOVALUE;

        /** scanner.e:922				if fx then*/
        if (_fx_26790 == 0)
        {
            goto L4; // [46] 104
        }
        else{
        }

        /** scanner.e:923					file_include_depend[i] = remove( file_include_depend[i], fx )*/
        _2 = (object)SEQ_PTR(_37file_include_depend_15410);
        _14783 = (object)*(((s1_ptr)_2)->base + _i_26783);
        {
            s1_ptr assign_space = SEQ_PTR(_14783);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_26790)) ? _fx_26790 : (object)(DBL_PTR(_fx_26790)->dbl);
            int stop = (IS_ATOM_INT(_fx_26790)) ? _fx_26790 : (object)(DBL_PTR(_fx_26790)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
                RefDS(_14783);
                DeRef(_14784);
                _14784 = _14783;
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_14783), start, &_14784 );
                }
                else Tail(SEQ_PTR(_14783), stop+1, &_14784);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_14783), start, &_14784);
            }
            else {
                assign_slice_seq = &assign_space;
                _1 = Remove_elements(start, stop, 0);
                DeRef(_14784);
                _14784 = _1;
            }
        }
        _14783 = NOVALUE;
        _2 = (object)SEQ_PTR(_37file_include_depend_15410);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37file_include_depend_15410 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_26783);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14784;
        if( _1 != _14784 ){
            DeRef(_1);
        }
        _14784 = NOVALUE;

        /** scanner.e:924					if not length( file_include_depend[i] ) then*/
        _2 = (object)SEQ_PTR(_37file_include_depend_15410);
        _14785 = (object)*(((s1_ptr)_2)->base + _i_26783);
        if (IS_SEQUENCE(_14785)){
                _14786 = SEQ_PTR(_14785)->length;
        }
        else {
            _14786 = 1;
        }
        _14785 = NOVALUE;
        if (_14786 != 0)
        goto L5; // [79] 103
        _14786 = NOVALUE;

        /** scanner.e:925						finished_files[i] = 1*/
        _2 = (object)SEQ_PTR(_37finished_files_15409);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37finished_files_15409 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_26783);
        *(intptr_t *)_2 = 1LL;

        /** scanner.e:926						if i != file_no then*/
        if (_i_26783 == _file_no_26781)
        goto L6; // [92] 102

        /** scanner.e:927							update_include_completion( i )*/
        _62update_include_completion(_i_26783);
L6: 
L5: 
L4: 
L3: 

        /** scanner.e:932		end for*/
        _i_26783 = _i_26783 + 1LL;
        goto L1; // [109] 17
L2: 
        ;
    }

    /** scanner.e:933	end procedure*/
    _14779 = NOVALUE;
    _14785 = NOVALUE;
    return;
    ;
}


object _62IncludePop()
{
    object _top_26821 = NOVALUE;
    object _14817 = NOVALUE;
    object _14815 = NOVALUE;
    object _14814 = NOVALUE;
    object _14792 = NOVALUE;
    object _14790 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:940		update_include_completion( current_file_no )*/
    _62update_include_completion(_36current_file_no_21439);

    /** scanner.e:941		Resolve_forward_references()*/
    _44Resolve_forward_references(0LL);

    /** scanner.e:942		HideLocals()*/
    _54HideLocals();

    /** scanner.e:944		if src_file >= 0 then*/
    if (_36src_file_21564 < 0LL)
    goto L1; // [21] 39

    /** scanner.e:945			close(src_file)*/
    EClose(_36src_file_21564);

    /** scanner.e:946			src_file = -1*/
    _36src_file_21564 = -1LL;
L1: 

    /** scanner.e:949		if length(IncludeStk) = 0 then*/
    if (IS_SEQUENCE(_62IncludeStk_25556)){
            _14790 = SEQ_PTR(_62IncludeStk_25556)->length;
    }
    else {
        _14790 = 1;
    }
    if (_14790 != 0LL)
    goto L2; // [46] 59

    /** scanner.e:950			return FALSE  -- the end*/
    DeRef(_top_26821);
    return _13FALSE_450;
L2: 

    /** scanner.e:953		sequence top = IncludeStk[$]*/
    if (IS_SEQUENCE(_62IncludeStk_25556)){
            _14792 = SEQ_PTR(_62IncludeStk_25556)->length;
    }
    else {
        _14792 = 1;
    }
    DeRef(_top_26821);
    _2 = (object)SEQ_PTR(_62IncludeStk_25556);
    _top_26821 = (object)*(((s1_ptr)_2)->base + _14792);
    RefDS(_top_26821);

    /** scanner.e:955		current_file_no    = top[FILE_NO]*/
    _2 = (object)SEQ_PTR(_top_26821);
    _36current_file_no_21439 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_36current_file_no_21439)){
        _36current_file_no_21439 = (object)DBL_PTR(_36current_file_no_21439)->dbl;
    }

    /** scanner.e:956		line_number        = top[LINE_NO]*/
    _2 = (object)SEQ_PTR(_top_26821);
    _36line_number_21440 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_36line_number_21440)){
        _36line_number_21440 = (object)DBL_PTR(_36line_number_21440)->dbl;
    }

    /** scanner.e:957		src_file           = top[FILE_PTR]*/
    _2 = (object)SEQ_PTR(_top_26821);
    _36src_file_21564 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_36src_file_21564)){
        _36src_file_21564 = (object)DBL_PTR(_36src_file_21564)->dbl;
    }

    /** scanner.e:958		file_start_sym     = top[FILE_START_SYM]*/
    _2 = (object)SEQ_PTR(_top_26821);
    _36file_start_sym_21445 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_36file_start_sym_21445)){
        _36file_start_sym_21445 = (object)DBL_PTR(_36file_start_sym_21445)->dbl;
    }

    /** scanner.e:959		OpWarning          = top[OP_WARNING]*/
    _2 = (object)SEQ_PTR(_top_26821);
    _36OpWarning_21510 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (!IS_ATOM_INT(_36OpWarning_21510)){
        _36OpWarning_21510 = (object)DBL_PTR(_36OpWarning_21510)->dbl;
    }

    /** scanner.e:960		OpTrace            = top[OP_TRACE]*/
    _2 = (object)SEQ_PTR(_top_26821);
    _36OpTrace_21512 = (object)*(((s1_ptr)_2)->base + 6LL);
    if (!IS_ATOM_INT(_36OpTrace_21512)){
        _36OpTrace_21512 = (object)DBL_PTR(_36OpTrace_21512)->dbl;
    }

    /** scanner.e:961		OpTypeCheck        = top[OP_TYPE_CHECK]*/
    _2 = (object)SEQ_PTR(_top_26821);
    _36OpTypeCheck_21513 = (object)*(((s1_ptr)_2)->base + 7LL);
    if (!IS_ATOM_INT(_36OpTypeCheck_21513)){
        _36OpTypeCheck_21513 = (object)DBL_PTR(_36OpTypeCheck_21513)->dbl;
    }

    /** scanner.e:962		OpProfileTime      = top[OP_PROFILE_TIME]*/
    _2 = (object)SEQ_PTR(_top_26821);
    _36OpProfileTime_21515 = (object)*(((s1_ptr)_2)->base + 8LL);
    if (!IS_ATOM_INT(_36OpProfileTime_21515)){
        _36OpProfileTime_21515 = (object)DBL_PTR(_36OpProfileTime_21515)->dbl;
    }

    /** scanner.e:963		OpProfileStatement = top[OP_PROFILE_STATEMENT]*/
    _2 = (object)SEQ_PTR(_top_26821);
    _36OpProfileStatement_21514 = (object)*(((s1_ptr)_2)->base + 9LL);
    if (!IS_ATOM_INT(_36OpProfileStatement_21514)){
        _36OpProfileStatement_21514 = (object)DBL_PTR(_36OpProfileStatement_21514)->dbl;
    }

    /** scanner.e:964		OpDefines          = top[OP_DEFINES]*/
    DeRef(_36OpDefines_21516);
    _2 = (object)SEQ_PTR(_top_26821);
    _36OpDefines_21516 = (object)*(((s1_ptr)_2)->base + 10LL);
    Ref(_36OpDefines_21516);

    /** scanner.e:965		prev_OpWarning     = top[PREV_OP_WARNING]*/
    _2 = (object)SEQ_PTR(_top_26821);
    _36prev_OpWarning_21511 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (!IS_ATOM_INT(_36prev_OpWarning_21511)){
        _36prev_OpWarning_21511 = (object)DBL_PTR(_36prev_OpWarning_21511)->dbl;
    }

    /** scanner.e:966		OpInline           = top[OP_INLINE]*/
    _2 = (object)SEQ_PTR(_top_26821);
    _36OpInline_21517 = (object)*(((s1_ptr)_2)->base + 12LL);
    if (!IS_ATOM_INT(_36OpInline_21517)){
        _36OpInline_21517 = (object)DBL_PTR(_36OpInline_21517)->dbl;
    }

    /** scanner.e:967		OpIndirectInclude  = top[OP_INDIRECT_INCLUDE]*/
    _2 = (object)SEQ_PTR(_top_26821);
    _36OpIndirectInclude_21518 = (object)*(((s1_ptr)_2)->base + 13LL);
    if (!IS_ATOM_INT(_36OpIndirectInclude_21518)){
        _36OpIndirectInclude_21518 = (object)DBL_PTR(_36OpIndirectInclude_21518)->dbl;
    }

    /** scanner.e:968		putback_fwd_line_number = line_number -- top[PUTBACK_FWD_LINE_NUMBER]*/
    _36putback_fwd_line_number_21442 = _36line_number_21440;

    /** scanner.e:969		putback_ForwardLine = top[PUTBACK_FORWARDLINE]*/
    DeRef(_50putback_ForwardLine_49236);
    _2 = (object)SEQ_PTR(_top_26821);
    _50putback_ForwardLine_49236 = (object)*(((s1_ptr)_2)->base + 15LL);
    Ref(_50putback_ForwardLine_49236);

    /** scanner.e:970		putback_forward_bp = top[PUTBACK_FORWARD_BP]*/
    _2 = (object)SEQ_PTR(_top_26821);
    _50putback_forward_bp_49240 = (object)*(((s1_ptr)_2)->base + 16LL);
    if (!IS_ATOM_INT(_50putback_forward_bp_49240)){
        _50putback_forward_bp_49240 = (object)DBL_PTR(_50putback_forward_bp_49240)->dbl;
    }

    /** scanner.e:971		last_fwd_line_number = top[LAST_FWD_LINE_NUMBER]*/
    _2 = (object)SEQ_PTR(_top_26821);
    _36last_fwd_line_number_21443 = (object)*(((s1_ptr)_2)->base + 17LL);
    if (!IS_ATOM_INT(_36last_fwd_line_number_21443)){
        _36last_fwd_line_number_21443 = (object)DBL_PTR(_36last_fwd_line_number_21443)->dbl;
    }

    /** scanner.e:972		last_ForwardLine = top[LAST_FORWARDLINE]*/
    DeRef(_50last_ForwardLine_49237);
    _2 = (object)SEQ_PTR(_top_26821);
    _50last_ForwardLine_49237 = (object)*(((s1_ptr)_2)->base + 18LL);
    Ref(_50last_ForwardLine_49237);

    /** scanner.e:973		last_forward_bp = top[LAST_FORWARD_BP]*/
    _2 = (object)SEQ_PTR(_top_26821);
    _50last_forward_bp_49241 = (object)*(((s1_ptr)_2)->base + 19LL);
    if (!IS_ATOM_INT(_50last_forward_bp_49241)){
        _50last_forward_bp_49241 = (object)DBL_PTR(_50last_forward_bp_49241)->dbl;
    }

    /** scanner.e:974		ThisLine = top[THISLINE]*/
    DeRef(_50ThisLine_49234);
    _2 = (object)SEQ_PTR(_top_26821);
    _50ThisLine_49234 = (object)*(((s1_ptr)_2)->base + 20LL);
    Ref(_50ThisLine_49234);

    /** scanner.e:976		fwd_line_number = line_number --top[FWD_LINE_NUMBER]*/
    _36fwd_line_number_21441 = _36line_number_21440;

    /** scanner.e:977		forward_bp = top[FORWARD_BP]*/
    _2 = (object)SEQ_PTR(_top_26821);
    _50forward_bp_49239 = (object)*(((s1_ptr)_2)->base + 22LL);
    if (!IS_ATOM_INT(_50forward_bp_49239)){
        _50forward_bp_49239 = (object)DBL_PTR(_50forward_bp_49239)->dbl;
    }

    /** scanner.e:978		ForwardLine = ThisLine*/
    Ref(_50ThisLine_49234);
    DeRef(_50ForwardLine_49235);
    _50ForwardLine_49235 = _50ThisLine_49234;

    /** scanner.e:980		putback_ForwardLine = ThisLine*/
    Ref(_50ThisLine_49234);
    DeRef(_50putback_ForwardLine_49236);
    _50putback_ForwardLine_49236 = _50ThisLine_49234;

    /** scanner.e:981		last_ForwardLine = ThisLine*/
    Ref(_50ThisLine_49234);
    DeRef(_50last_ForwardLine_49237);
    _50last_ForwardLine_49237 = _50ThisLine_49234;

    /** scanner.e:983		IncludeStk = IncludeStk[1..$-1]*/
    if (IS_SEQUENCE(_62IncludeStk_25556)){
            _14814 = SEQ_PTR(_62IncludeStk_25556)->length;
    }
    else {
        _14814 = 1;
    }
    _14815 = _14814 - 1LL;
    _14814 = NOVALUE;
    rhs_slice_target = (object_ptr)&_62IncludeStk_25556;
    RHS_Slice(_62IncludeStk_25556, 1LL, _14815);

    /** scanner.e:984		SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21446 + ((s1_ptr)_2)->base);
    RefDS(_36Code_21531);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21088))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21088);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36Code_21531;
    DeRef(_1);
    _14817 = NOVALUE;

    /** scanner.e:987		return TRUE*/
    DeRefDS(_top_26821);
    _14815 = NOVALUE;
    return _13TRUE_452;
    ;
}


object _62MakeInt(object _text_26922, object _nBase_26923)
{
    object _num_26924 = NOVALUE;
    object _maxchk_26925 = NOVALUE;
    object _fnum_26926 = NOVALUE;
    object _digit_26927 = NOVALUE;
    object _14867 = NOVALUE;
    object _14865 = NOVALUE;
    object _14863 = NOVALUE;
    object _14860 = NOVALUE;
    object _14859 = NOVALUE;
    object _14858 = NOVALUE;
    object _14856 = NOVALUE;
    object _14854 = NOVALUE;
    object _14853 = NOVALUE;
    object _14852 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_nBase_26923)) {
        _1 = (object)(DBL_PTR(_nBase_26923)->dbl);
        DeRefDS(_nBase_26923);
        _nBase_26923 = _1;
    }

    /** scanner.e:1012		ifdef BITS32 then*/

    /** scanner.e:1015			integer num, maxchk*/

    /** scanner.e:1017		atom fnum*/

    /** scanner.e:1018		integer digit*/

    /** scanner.e:1021		switch nBase do*/
    _0 = _nBase_26923;
    switch ( _0 ){ 

        /** scanner.e:1022			case 2 then*/
        case 2:

        /** scanner.e:1023				maxchk = MAXCHK2*/
        _maxchk_26925 = 2305843009213693949LL;
        goto L1; // [29] 90

        /** scanner.e:1025			case 8 then*/
        case 8:

        /** scanner.e:1026				maxchk = MAXCHK8*/
        _maxchk_26925 = 576460752303423479LL;
        goto L1; // [40] 90

        /** scanner.e:1028			case 10 then*/
        case 10:

        /** scanner.e:1030				num = find(text, common_int_text)*/
        _num_26924 = find_from(_text_26922, _62common_int_text_26897, 1LL);

        /** scanner.e:1031				if num then*/
        if (_num_26924 == 0)
        {
            goto L2; // [57] 73
        }
        else{
        }

        /** scanner.e:1032					return common_ints[num]*/
        _2 = (object)SEQ_PTR(_62common_ints_26917);
        _14852 = (object)*(((s1_ptr)_2)->base + _num_26924);
        DeRefDS(_text_26922);
        DeRef(_fnum_26926);
        return _14852;
L2: 

        /** scanner.e:1035				maxchk = MAXCHK10*/
        _maxchk_26925 = 461168601842738782LL;
        goto L1; // [78] 90

        /** scanner.e:1037			case 16 then*/
        case 16:

        /** scanner.e:1038				maxchk = MAXCHK16*/
        _maxchk_26925 = 288230376151711728LL;
    ;}L1: 

    /** scanner.e:1042		num = 0*/
    _num_26924 = 0LL;

    /** scanner.e:1043		fnum = 0*/
    DeRef(_fnum_26926);
    _fnum_26926 = 0LL;

    /** scanner.e:1044		for i = 1 to length(text) do*/
    if (IS_SEQUENCE(_text_26922)){
            _14853 = SEQ_PTR(_text_26922)->length;
    }
    else {
        _14853 = 1;
    }
    {
        object _i_26938;
        _i_26938 = 1LL;
L3: 
        if (_i_26938 > _14853){
            goto L4; // [105] 222
        }

        /** scanner.e:1045			digit = (text[i] - '0')*/
        _2 = (object)SEQ_PTR(_text_26922);
        _14854 = (object)*(((s1_ptr)_2)->base + _i_26938);
        if (IS_ATOM_INT(_14854)) {
            _digit_26927 = _14854 - 48LL;
        }
        else {
            _digit_26927 = binary_op(MINUS, _14854, 48LL);
        }
        _14854 = NOVALUE;
        if (!IS_ATOM_INT(_digit_26927)) {
            _1 = (object)(DBL_PTR(_digit_26927)->dbl);
            DeRefDS(_digit_26927);
            _digit_26927 = _1;
        }

        /** scanner.e:1046			if digit >= nBase or digit < 0 then*/
        _14856 = (_digit_26927 >= _nBase_26923);
        if (_14856 != 0) {
            goto L5; // [130] 143
        }
        _14858 = (_digit_26927 < 0LL);
        if (_14858 == 0)
        {
            DeRef(_14858);
            _14858 = NOVALUE;
            goto L6; // [139] 161
        }
        else{
            DeRef(_14858);
            _14858 = NOVALUE;
        }
L5: 

        /** scanner.e:1047				CompileErr(DIGIT_1_AT_POSITION_2_IS_OUTSIDE_OF_NUMBER_BASE, {text[i],i})*/
        _2 = (object)SEQ_PTR(_text_26922);
        _14859 = (object)*(((s1_ptr)_2)->base + _i_26938);
        Ref(_14859);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _14859;
        ((intptr_t *)_2)[2] = _i_26938;
        _14860 = MAKE_SEQ(_1);
        _14859 = NOVALUE;
        _50CompileErr(62LL, _14860, 0LL);
        _14860 = NOVALUE;
L6: 

        /** scanner.e:1049			if fnum = 0 then*/
        if (binary_op_a(NOTEQ, _fnum_26926, 0LL)){
            goto L7; // [163] 204
        }

        /** scanner.e:1050				if num <= maxchk then*/
        if (_num_26924 > _maxchk_26925)
        goto L8; // [171] 190

        /** scanner.e:1051					num = num * nBase + digit*/
        {
            int128_t p128 = (int128_t)_num_26924 * (int128_t)_nBase_26923;
            if( p128 != (int128_t)(_14863 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _14863 = NewDouble( (eudouble)p128 );
            }
        }
        if (IS_ATOM_INT(_14863)) {
            _num_26924 = _14863 + _digit_26927;
        }
        else {
            _num_26924 = NewDouble(DBL_PTR(_14863)->dbl + (eudouble)_digit_26927);
        }
        DeRef(_14863);
        _14863 = NOVALUE;
        if (!IS_ATOM_INT(_num_26924)) {
            _1 = (object)(DBL_PTR(_num_26924)->dbl);
            DeRefDS(_num_26924);
            _num_26924 = _1;
        }
        goto L9; // [187] 215
L8: 

        /** scanner.e:1053					fnum = num * nBase + digit*/
        {
            int128_t p128 = (int128_t)_num_26924 * (int128_t)_nBase_26923;
            if( p128 != (int128_t)(_14865 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _14865 = NewDouble( (eudouble)p128 );
            }
        }
        DeRef(_fnum_26926);
        if (IS_ATOM_INT(_14865)) {
            _fnum_26926 = _14865 + _digit_26927;
            if ((object)((uintptr_t)_fnum_26926 + (uintptr_t)HIGH_BITS) >= 0){
                _fnum_26926 = NewDouble((eudouble)_fnum_26926);
            }
        }
        else {
            _fnum_26926 = NewDouble(DBL_PTR(_14865)->dbl + (eudouble)_digit_26927);
        }
        DeRef(_14865);
        _14865 = NOVALUE;
        goto L9; // [201] 215
L7: 

        /** scanner.e:1056				fnum = fnum * nBase + digit*/
        if (IS_ATOM_INT(_fnum_26926)) {
            {
                int128_t p128 = (int128_t)_fnum_26926 * (int128_t)_nBase_26923;
                if( p128 != (int128_t)(_14867 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                    _14867 = NewDouble( (eudouble)p128 );
                }
            }
        }
        else {
            _14867 = NewDouble(DBL_PTR(_fnum_26926)->dbl * (eudouble)_nBase_26923);
        }
        DeRef(_fnum_26926);
        if (IS_ATOM_INT(_14867)) {
            _fnum_26926 = _14867 + _digit_26927;
            if ((object)((uintptr_t)_fnum_26926 + (uintptr_t)HIGH_BITS) >= 0){
                _fnum_26926 = NewDouble((eudouble)_fnum_26926);
            }
        }
        else {
            _fnum_26926 = NewDouble(DBL_PTR(_14867)->dbl + (eudouble)_digit_26927);
        }
        DeRef(_14867);
        _14867 = NOVALUE;
L9: 

        /** scanner.e:1058		end for*/
        _i_26938 = _i_26938 + 1LL;
        goto L3; // [217] 112
L4: 
        ;
    }

    /** scanner.e:1060		if fnum = 0 then*/
    if (binary_op_a(NOTEQ, _fnum_26926, 0LL)){
        goto LA; // [224] 237
    }

    /** scanner.e:1061			return num*/
    DeRefDS(_text_26922);
    DeRef(_fnum_26926);
    DeRef(_14856);
    _14856 = NOVALUE;
    _14852 = NOVALUE;
    return _num_26924;
    goto LB; // [234] 244
LA: 

    /** scanner.e:1063			return fnum*/
    DeRefDS(_text_26922);
    DeRef(_14856);
    _14856 = NOVALUE;
    _14852 = NOVALUE;
    return _fnum_26926;
LB: 
    ;
}


object _62GetHexChar(object _cnt_26967, object _errno_26968)
{
    object _val_26969 = NOVALUE;
    object _d_26970 = NOVALUE;
    object _14877 = NOVALUE;
    object _14876 = NOVALUE;
    object _14871 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1070		val = 0*/
    DeRef(_val_26969);
    _val_26969 = 0LL;

    /** scanner.e:1072		while cnt > 0 do*/
L1: 
    if (_cnt_26967 <= 0LL)
    goto L2; // [15] 88

    /** scanner.e:1073			d = find(getch(), "0123456789ABCDEFabcdef_")*/
    _14871 = _62getch();
    _d_26970 = find_from(_14871, _14872, 1LL);
    DeRef(_14871);
    _14871 = NOVALUE;

    /** scanner.e:1074			if d = 0 then*/
    if (_d_26970 != 0LL)
    goto L3; // [31] 43

    /** scanner.e:1075				CompileErr( errno )*/
    RefDS(_21993);
    _50CompileErr(_errno_26968, _21993, 0LL);
L3: 

    /** scanner.e:1077			if d != 23 then*/
    if (_d_26970 == 23LL)
    goto L1; // [45] 15

    /** scanner.e:1078				val = val * 16 + d - 1*/
    if (IS_ATOM_INT(_val_26969)) {
        {
            int128_t p128 = (int128_t)_val_26969 * (int128_t)16LL;
            if( p128 != (int128_t)(_14876 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _14876 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _14876 = NewDouble(DBL_PTR(_val_26969)->dbl * (eudouble)16LL);
    }
    if (IS_ATOM_INT(_14876)) {
        _14877 = _14876 + _d_26970;
        if ((object)((uintptr_t)_14877 + (uintptr_t)HIGH_BITS) >= 0){
            _14877 = NewDouble((eudouble)_14877);
        }
    }
    else {
        _14877 = NewDouble(DBL_PTR(_14876)->dbl + (eudouble)_d_26970);
    }
    DeRef(_14876);
    _14876 = NOVALUE;
    DeRef(_val_26969);
    if (IS_ATOM_INT(_14877)) {
        _val_26969 = _14877 - 1LL;
        if ((object)((uintptr_t)_val_26969 +(uintptr_t) HIGH_BITS) >= 0){
            _val_26969 = NewDouble((eudouble)_val_26969);
        }
    }
    else {
        _val_26969 = NewDouble(DBL_PTR(_14877)->dbl - (eudouble)1LL);
    }
    DeRef(_14877);
    _14877 = NOVALUE;

    /** scanner.e:1079				if d > 16 then*/
    if (_d_26970 <= 16LL)
    goto L4; // [65] 76

    /** scanner.e:1080					val -= 6*/
    _0 = _val_26969;
    if (IS_ATOM_INT(_val_26969)) {
        _val_26969 = _val_26969 - 6LL;
        if ((object)((uintptr_t)_val_26969 +(uintptr_t) HIGH_BITS) >= 0){
            _val_26969 = NewDouble((eudouble)_val_26969);
        }
    }
    else {
        _val_26969 = NewDouble(DBL_PTR(_val_26969)->dbl - (eudouble)6LL);
    }
    DeRef(_0);
L4: 

    /** scanner.e:1082				cnt -= 1*/
    _cnt_26967 = _cnt_26967 - 1LL;

    /** scanner.e:1084		end while*/
    goto L1; // [85] 15
L2: 

    /** scanner.e:1086		return val*/
    return _val_26969;
    ;
}


object _62GetBinaryChar(object _delim_26990)
{
    object _val_26991 = NOVALUE;
    object _d_26992 = NOVALUE;
    object _vchars_26993 = NOVALUE;
    object _cnt_26996 = NOVALUE;
    object _14891 = NOVALUE;
    object _14890 = NOVALUE;
    object _14884 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1092		sequence vchars = "01_ " & delim*/
    Append(&_vchars_26993, _14882, _delim_26990);

    /** scanner.e:1093		integer cnt = 0*/
    _cnt_26996 = 0LL;

    /** scanner.e:1094		val = 0*/
    DeRef(_val_26991);
    _val_26991 = 0LL;

    /** scanner.e:1095		while 1 do*/
L1: 

    /** scanner.e:1096			d = find(getch(), vchars)*/
    _14884 = _62getch();
    _d_26992 = find_from(_14884, _vchars_26993, 1LL);
    DeRef(_14884);
    _14884 = NOVALUE;

    /** scanner.e:1097			if d = 0 then*/
    if (_d_26992 != 0LL)
    goto L2; // [36] 50

    /** scanner.e:1098				CompileErr( EXPECTING_ONLY_0_1_OR_SPACE_TO_FOLLOW_THE_B)*/
    RefDS(_21993);
    _50CompileErr(343LL, _21993, 0LL);
L2: 

    /** scanner.e:1100			if d = 5 then*/
    if (_d_26992 != 5LL)
    goto L3; // [52] 65

    /** scanner.e:1101				ungetch()*/
    _62ungetch();

    /** scanner.e:1102				exit*/
    goto L4; // [62] 108
L3: 

    /** scanner.e:1104			if d = 4 then*/
    if (_d_26992 != 4LL)
    goto L5; // [67] 76

    /** scanner.e:1105				exit*/
    goto L4; // [73] 108
L5: 

    /** scanner.e:1107			if d != 3 then*/
    if (_d_26992 == 3LL)
    goto L1; // [78] 24

    /** scanner.e:1108				val = val * 2 + d - 1*/
    if (IS_ATOM_INT(_val_26991) && IS_ATOM_INT(_val_26991)) {
        _14890 = _val_26991 + _val_26991;
        if ((object)((uintptr_t)_14890 + (uintptr_t)HIGH_BITS) >= 0){
            _14890 = NewDouble((eudouble)_14890);
        }
    }
    else {
        if (IS_ATOM_INT(_val_26991)) {
            _14890 = NewDouble((eudouble)_val_26991 + DBL_PTR(_val_26991)->dbl);
        }
        else {
            if (IS_ATOM_INT(_val_26991)) {
                _14890 = NewDouble(DBL_PTR(_val_26991)->dbl + (eudouble)_val_26991);
            }
            else
            _14890 = NewDouble(DBL_PTR(_val_26991)->dbl + DBL_PTR(_val_26991)->dbl);
        }
    }
    if (IS_ATOM_INT(_14890)) {
        _14891 = _14890 + _d_26992;
        if ((object)((uintptr_t)_14891 + (uintptr_t)HIGH_BITS) >= 0){
            _14891 = NewDouble((eudouble)_14891);
        }
    }
    else {
        _14891 = NewDouble(DBL_PTR(_14890)->dbl + (eudouble)_d_26992);
    }
    DeRef(_14890);
    _14890 = NOVALUE;
    DeRef(_val_26991);
    if (IS_ATOM_INT(_14891)) {
        _val_26991 = _14891 - 1LL;
        if ((object)((uintptr_t)_val_26991 +(uintptr_t) HIGH_BITS) >= 0){
            _val_26991 = NewDouble((eudouble)_val_26991);
        }
    }
    else {
        _val_26991 = NewDouble(DBL_PTR(_14891)->dbl - (eudouble)1LL);
    }
    DeRef(_14891);
    _14891 = NOVALUE;

    /** scanner.e:1109				cnt += 1*/
    _cnt_26996 = _cnt_26996 + 1;

    /** scanner.e:1111		end while*/
    goto L1; // [105] 24
L4: 

    /** scanner.e:1113		if cnt = 0 then*/
    if (_cnt_26996 != 0LL)
    goto L6; // [110] 124

    /** scanner.e:1114			CompileErr(EXPECTING_ONLY_0_1_OR_SPACE_TO_FOLLOW_THE_B)*/
    RefDS(_21993);
    _50CompileErr(343LL, _21993, 0LL);
L6: 

    /** scanner.e:1116		return val*/
    DeRefi(_vchars_26993);
    return _val_26991;
    ;
}


object _62EscapeChar(object _delim_27020)
{
    object _c_27021 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1124		c = getch()*/
    _0 = _c_27021;
    _c_27021 = _62getch();
    DeRef(_0);

    /** scanner.e:1125		switch c do*/
    if (IS_SEQUENCE(_c_27021) ){
        goto L1; // [10] 135
    }
    if(!IS_ATOM_INT(_c_27021)){
        if( (DBL_PTR(_c_27021)->dbl != (eudouble) ((object) DBL_PTR(_c_27021)->dbl) ) ){
            goto L1; // [10] 135
        }
        _0 = (object) DBL_PTR(_c_27021)->dbl;
    }
    else {
        _0 = _c_27021;
    };
    switch ( _0 ){ 

        /** scanner.e:1126			case 'n' then*/
        case 110:

        /** scanner.e:1127				c = 10 -- Newline*/
        DeRef(_c_27021);
        _c_27021 = 10LL;
        goto L2; // [24] 147

        /** scanner.e:1129			case 't' then*/
        case 116:

        /** scanner.e:1130				c = 9 -- Tabulator*/
        DeRef(_c_27021);
        _c_27021 = 9LL;
        goto L2; // [35] 147

        /** scanner.e:1132			case '"', '\\', '\'' then*/
        case 34:
        case 92:
        case 39:

        /** scanner.e:1137			case 'r' then*/
        goto L2; // [47] 147
        case 114:

        /** scanner.e:1138				c = 13 -- Carriage Return*/
        DeRef(_c_27021);
        _c_27021 = 13LL;
        goto L2; // [56] 147

        /** scanner.e:1140			case '0' then*/
        case 48:

        /** scanner.e:1141				c = 0 -- Null*/
        DeRef(_c_27021);
        _c_27021 = 0LL;
        goto L2; // [67] 147

        /** scanner.e:1143			case 'e', 'E' then*/
        case 101:
        case 69:

        /** scanner.e:1144				c = 27 -- escape char.*/
        DeRef(_c_27021);
        _c_27021 = 27LL;
        goto L2; // [80] 147

        /** scanner.e:1146			case 'x' then*/
        case 120:

        /** scanner.e:1148				c = GetHexChar(2, 340)*/
        _0 = _c_27021;
        _c_27021 = _62GetHexChar(2LL, 340LL);
        DeRef(_0);
        goto L2; // [93] 147

        /** scanner.e:1150			case 'u' then*/
        case 117:

        /** scanner.e:1152				c = GetHexChar(4, 341)*/
        _0 = _c_27021;
        _c_27021 = _62GetHexChar(4LL, 341LL);
        DeRef(_0);
        goto L2; // [106] 147

        /** scanner.e:1154			case 'U' then*/
        case 85:

        /** scanner.e:1156				c = GetHexChar(8, 342)*/
        _0 = _c_27021;
        _c_27021 = _62GetHexChar(8LL, 342LL);
        DeRef(_0);
        goto L2; // [119] 147

        /** scanner.e:1158			case 'b' then*/
        case 98:

        /** scanner.e:1160				c = GetBinaryChar(delim)*/
        _0 = _c_27021;
        _c_27021 = _62GetBinaryChar(_delim_27020);
        DeRef(_0);
        goto L2; // [131] 147

        /** scanner.e:1162			case else*/
        default:
L1: 

        /** scanner.e:1163				CompileErr(UNKNOWN_ESCAPE_CHARACTER)*/
        RefDS(_21993);
        _50CompileErr(155LL, _21993, 0LL);
    ;}L2: 

    /** scanner.e:1166		return c*/
    return _c_27021;
    ;
}


object _62my_sscanf(object _yytext_27045)
{
    object _e_sign_27046 = NOVALUE;
    object _ndigits_27047 = NOVALUE;
    object _e_mag_27048 = NOVALUE;
    object _mantissa_27049 = NOVALUE;
    object _c_27050 = NOVALUE;
    object _i_27051 = NOVALUE;
    object _dec_27052 = NOVALUE;
    object _frac_27085 = NOVALUE;
    object _14937 = NOVALUE;
    object _14932 = NOVALUE;
    object _14931 = NOVALUE;
    object _14929 = NOVALUE;
    object _14928 = NOVALUE;
    object _14927 = NOVALUE;
    object _14919 = NOVALUE;
    object _14918 = NOVALUE;
    object _14915 = NOVALUE;
    object _14914 = NOVALUE;
    object _14913 = NOVALUE;
    object _14908 = NOVALUE;
    object _14907 = NOVALUE;
    object _14905 = NOVALUE;
    object _14903 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1179		if length(yytext) < 2 then*/
    if (IS_SEQUENCE(_yytext_27045)){
            _14903 = SEQ_PTR(_yytext_27045)->length;
    }
    else {
        _14903 = 1;
    }
    if (_14903 >= 2LL)
    goto L1; // [8] 22

    /** scanner.e:1180			CompileErr(NUMBER_NOT_FORMED_CORRECTLY)*/
    RefDS(_21993);
    _50CompileErr(121LL, _21993, 0LL);
L1: 

    /** scanner.e:1184		if find( 'e', yytext ) or find( 'E', yytext ) then*/
    _14905 = find_from(101LL, _yytext_27045, 1LL);
    if (_14905 != 0) {
        goto L2; // [29] 43
    }
    _14907 = find_from(69LL, _yytext_27045, 1LL);
    if (_14907 == 0)
    {
        _14907 = NOVALUE;
        goto L3; // [39] 59
    }
    else{
        _14907 = NOVALUE;
    }
L2: 

    /** scanner.e:1185			ifdef BITS32 then*/

    /** scanner.e:1188				return scientific_to_atom( yytext, EXTENDED )*/
    RefDS(_yytext_27045);
    _14908 = _28scientific_to_atom(_yytext_27045, 3LL);
    DeRefDS(_yytext_27045);
    DeRef(_mantissa_27049);
    DeRef(_dec_27052);
    return _14908;
L3: 

    /** scanner.e:1193		mantissa = 0.0*/
    RefDS(_14910);
    DeRef(_mantissa_27049);
    _mantissa_27049 = _14910;

    /** scanner.e:1194		ndigits = 0*/
    _ndigits_27047 = 0LL;

    /** scanner.e:1198		yytext &= 0 -- end marker*/
    Append(&_yytext_27045, _yytext_27045, 0LL);

    /** scanner.e:1199		c = yytext[1]*/
    _2 = (object)SEQ_PTR(_yytext_27045);
    _c_27050 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_c_27050))
    _c_27050 = (object)DBL_PTR(_c_27050)->dbl;

    /** scanner.e:1200		i = 2*/
    _i_27051 = 2LL;

    /** scanner.e:1201		while c >= '0' and c <= '9' do*/
L4: 
    _14913 = (_c_27050 >= 48LL);
    if (_14913 == 0) {
        goto L5; // [95] 144
    }
    _14915 = (_c_27050 <= 57LL);
    if (_14915 == 0)
    {
        DeRef(_14915);
        _14915 = NOVALUE;
        goto L5; // [104] 144
    }
    else{
        DeRef(_14915);
        _14915 = NOVALUE;
    }

    /** scanner.e:1202			ndigits += 1*/
    _ndigits_27047 = _ndigits_27047 + 1;

    /** scanner.e:1203			mantissa = mantissa * 10.0 + (c - '0')*/
    if (IS_ATOM_INT(_mantissa_27049)) {
        _14918 = NewDouble((eudouble)_mantissa_27049 * DBL_PTR(_14917)->dbl);
    }
    else {
        _14918 = NewDouble(DBL_PTR(_mantissa_27049)->dbl * DBL_PTR(_14917)->dbl);
    }
    _14919 = _c_27050 - 48LL;
    if ((object)((uintptr_t)_14919 +(uintptr_t) HIGH_BITS) >= 0){
        _14919 = NewDouble((eudouble)_14919);
    }
    DeRef(_mantissa_27049);
    if (IS_ATOM_INT(_14919)) {
        _mantissa_27049 = NewDouble(DBL_PTR(_14918)->dbl + (eudouble)_14919);
    }
    else
    _mantissa_27049 = NewDouble(DBL_PTR(_14918)->dbl + DBL_PTR(_14919)->dbl);
    DeRefDS(_14918);
    _14918 = NOVALUE;
    DeRef(_14919);
    _14919 = NOVALUE;

    /** scanner.e:1204			c = yytext[i]*/
    _2 = (object)SEQ_PTR(_yytext_27045);
    _c_27050 = (object)*(((s1_ptr)_2)->base + _i_27051);
    if (!IS_ATOM_INT(_c_27050))
    _c_27050 = (object)DBL_PTR(_c_27050)->dbl;

    /** scanner.e:1205			i += 1*/
    _i_27051 = _i_27051 + 1;

    /** scanner.e:1206		end while*/
    goto L4; // [141] 91
L5: 

    /** scanner.e:1208		if c = '.' then*/
    if (_c_27050 != 46LL)
    goto L6; // [146] 247

    /** scanner.e:1210			c = yytext[i]*/
    _2 = (object)SEQ_PTR(_yytext_27045);
    _c_27050 = (object)*(((s1_ptr)_2)->base + _i_27051);
    if (!IS_ATOM_INT(_c_27050))
    _c_27050 = (object)DBL_PTR(_c_27050)->dbl;

    /** scanner.e:1211			i += 1*/
    _i_27051 = _i_27051 + 1;

    /** scanner.e:1212			dec = 1.0*/
    RefDS(_14926);
    DeRef(_dec_27052);
    _dec_27052 = _14926;

    /** scanner.e:1213			atom frac = 0*/
    DeRef(_frac_27085);
    _frac_27085 = 0LL;

    /** scanner.e:1214			while c >= '0' and c <= '9' do*/
L7: 
    _14927 = (_c_27050 >= 48LL);
    if (_14927 == 0) {
        goto L8; // [181] 236
    }
    _14929 = (_c_27050 <= 57LL);
    if (_14929 == 0)
    {
        DeRef(_14929);
        _14929 = NOVALUE;
        goto L8; // [190] 236
    }
    else{
        DeRef(_14929);
        _14929 = NOVALUE;
    }

    /** scanner.e:1215				ndigits += 1*/
    _ndigits_27047 = _ndigits_27047 + 1;

    /** scanner.e:1216				frac = frac * 10 + (c - '0')*/
    if (IS_ATOM_INT(_frac_27085)) {
        {
            int128_t p128 = (int128_t)_frac_27085 * (int128_t)10LL;
            if( p128 != (int128_t)(_14931 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _14931 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _14931 = NewDouble(DBL_PTR(_frac_27085)->dbl * (eudouble)10LL);
    }
    _14932 = _c_27050 - 48LL;
    if ((object)((uintptr_t)_14932 +(uintptr_t) HIGH_BITS) >= 0){
        _14932 = NewDouble((eudouble)_14932);
    }
    DeRef(_frac_27085);
    if (IS_ATOM_INT(_14931) && IS_ATOM_INT(_14932)) {
        _frac_27085 = _14931 + _14932;
        if ((object)((uintptr_t)_frac_27085 + (uintptr_t)HIGH_BITS) >= 0){
            _frac_27085 = NewDouble((eudouble)_frac_27085);
        }
    }
    else {
        if (IS_ATOM_INT(_14931)) {
            _frac_27085 = NewDouble((eudouble)_14931 + DBL_PTR(_14932)->dbl);
        }
        else {
            if (IS_ATOM_INT(_14932)) {
                _frac_27085 = NewDouble(DBL_PTR(_14931)->dbl + (eudouble)_14932);
            }
            else
            _frac_27085 = NewDouble(DBL_PTR(_14931)->dbl + DBL_PTR(_14932)->dbl);
        }
    }
    DeRef(_14931);
    _14931 = NOVALUE;
    DeRef(_14932);
    _14932 = NOVALUE;

    /** scanner.e:1217				dec *= 10.0*/
    _0 = _dec_27052;
    if (IS_ATOM_INT(_dec_27052)) {
        _dec_27052 = NewDouble((eudouble)_dec_27052 * DBL_PTR(_14917)->dbl);
    }
    else {
        _dec_27052 = NewDouble(DBL_PTR(_dec_27052)->dbl * DBL_PTR(_14917)->dbl);
    }
    DeRef(_0);

    /** scanner.e:1218				c = yytext[i]*/
    _2 = (object)SEQ_PTR(_yytext_27045);
    _c_27050 = (object)*(((s1_ptr)_2)->base + _i_27051);
    if (!IS_ATOM_INT(_c_27050))
    _c_27050 = (object)DBL_PTR(_c_27050)->dbl;

    /** scanner.e:1219				i += 1*/
    _i_27051 = _i_27051 + 1;

    /** scanner.e:1220			end while*/
    goto L7; // [233] 177
L8: 

    /** scanner.e:1221			mantissa += frac / dec*/
    if (IS_ATOM_INT(_frac_27085) && IS_ATOM_INT(_dec_27052)) {
        _14937 = (_frac_27085 % _dec_27052) ? NewDouble((eudouble)_frac_27085 / _dec_27052) : (_frac_27085 / _dec_27052);
    }
    else {
        if (IS_ATOM_INT(_frac_27085)) {
            _14937 = NewDouble((eudouble)_frac_27085 / DBL_PTR(_dec_27052)->dbl);
        }
        else {
            if (IS_ATOM_INT(_dec_27052)) {
                _14937 = NewDouble(DBL_PTR(_frac_27085)->dbl / (eudouble)_dec_27052);
            }
            else
            _14937 = NewDouble(DBL_PTR(_frac_27085)->dbl / DBL_PTR(_dec_27052)->dbl);
        }
    }
    _0 = _mantissa_27049;
    if (IS_ATOM_INT(_mantissa_27049) && IS_ATOM_INT(_14937)) {
        _mantissa_27049 = _mantissa_27049 + _14937;
        if ((object)((uintptr_t)_mantissa_27049 + (uintptr_t)HIGH_BITS) >= 0){
            _mantissa_27049 = NewDouble((eudouble)_mantissa_27049);
        }
    }
    else {
        if (IS_ATOM_INT(_mantissa_27049)) {
            _mantissa_27049 = NewDouble((eudouble)_mantissa_27049 + DBL_PTR(_14937)->dbl);
        }
        else {
            if (IS_ATOM_INT(_14937)) {
                _mantissa_27049 = NewDouble(DBL_PTR(_mantissa_27049)->dbl + (eudouble)_14937);
            }
            else
            _mantissa_27049 = NewDouble(DBL_PTR(_mantissa_27049)->dbl + DBL_PTR(_14937)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_14937);
    _14937 = NOVALUE;
L6: 
    DeRef(_frac_27085);
    _frac_27085 = NOVALUE;

    /** scanner.e:1224		if ndigits = 0 then*/
    if (_ndigits_27047 != 0LL)
    goto L9; // [251] 265

    /** scanner.e:1225			CompileErr(NUMBER_NOT_FORMED_CORRECTLY)  -- no digits*/
    RefDS(_21993);
    _50CompileErr(121LL, _21993, 0LL);
L9: 

    /** scanner.e:1271		return mantissa*/
    DeRefDS(_yytext_27045);
    DeRef(_dec_27052);
    DeRef(_14908);
    _14908 = NOVALUE;
    DeRef(_14913);
    _14913 = NOVALUE;
    DeRef(_14927);
    _14927 = NOVALUE;
    return _mantissa_27049;
    ;
}


void _62maybe_namespace()
{
    object _0, _1, _2;
    

    /** scanner.e:1276		might_be_namespace = 1*/
    _62might_be_namespace_27103 = 1LL;

    /** scanner.e:1277	end procedure*/
    return;
    ;
}


object _62ExtendedString(object _ech_27113)
{
    object _ch_27114 = NOVALUE;
    object _fch_27115 = NOVALUE;
    object _cline_27116 = NOVALUE;
    object _string_text_27117 = NOVALUE;
    object _trimming_27118 = NOVALUE;
    object _14990 = NOVALUE;
    object _14989 = NOVALUE;
    object _14987 = NOVALUE;
    object _14986 = NOVALUE;
    object _14985 = NOVALUE;
    object _14984 = NOVALUE;
    object _14983 = NOVALUE;
    object _14982 = NOVALUE;
    object _14981 = NOVALUE;
    object _14980 = NOVALUE;
    object _14978 = NOVALUE;
    object _14977 = NOVALUE;
    object _14976 = NOVALUE;
    object _14975 = NOVALUE;
    object _14974 = NOVALUE;
    object _14973 = NOVALUE;
    object _14970 = NOVALUE;
    object _14969 = NOVALUE;
    object _14968 = NOVALUE;
    object _14966 = NOVALUE;
    object _14965 = NOVALUE;
    object _14964 = NOVALUE;
    object _14963 = NOVALUE;
    object _14960 = NOVALUE;
    object _14945 = NOVALUE;
    object _14943 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1290		cline = line_number*/
    _cline_27116 = _36line_number_21440;

    /** scanner.e:1291		string_text = ""*/
    RefDS(_5);
    DeRefi(_string_text_27117);
    _string_text_27117 = _5;

    /** scanner.e:1292		trimming = 0*/
    _trimming_27118 = 0LL;

    /** scanner.e:1293		ch = getch()*/
    _ch_27114 = _62getch();
    if (!IS_ATOM_INT(_ch_27114)) {
        _1 = (object)(DBL_PTR(_ch_27114)->dbl);
        DeRefDS(_ch_27114);
        _ch_27114 = _1;
    }

    /** scanner.e:1294		if bp > length(ThisLine) then*/
    if (IS_SEQUENCE(_50ThisLine_49234)){
            _14943 = SEQ_PTR(_50ThisLine_49234)->length;
    }
    else {
        _14943 = 1;
    }
    if (_50bp_49238 <= _14943)
    goto L1; // [40] 101

    /** scanner.e:1296			read_line()*/
    _62read_line();

    /** scanner.e:1297			while ThisLine[bp] = '_' do*/
L2: 
    _2 = (object)SEQ_PTR(_50ThisLine_49234);
    _14945 = (object)*(((s1_ptr)_2)->base + _50bp_49238);
    if (binary_op_a(NOTEQ, _14945, 95LL)){
        _14945 = NOVALUE;
        goto L3; // [61] 86
    }
    _14945 = NOVALUE;

    /** scanner.e:1298				trimming += 1*/
    _trimming_27118 = _trimming_27118 + 1;

    /** scanner.e:1299				bp += 1*/
    _50bp_49238 = _50bp_49238 + 1LL;

    /** scanner.e:1300			end while*/
    goto L2; // [83] 53
L3: 

    /** scanner.e:1301			if trimming > 0 then*/
    if (_trimming_27118 <= 0LL)
    goto L4; // [88] 100

    /** scanner.e:1302				ch = getch()*/
    _ch_27114 = _62getch();
    if (!IS_ATOM_INT(_ch_27114)) {
        _1 = (object)(DBL_PTR(_ch_27114)->dbl);
        DeRefDS(_ch_27114);
        _ch_27114 = _1;
    }
L4: 
L1: 

    /** scanner.e:1306		while 1 do*/
L5: 

    /** scanner.e:1307			if ch = END_OF_FILE_CHAR then*/
    if (_ch_27114 != 26LL)
    goto L6; // [110] 124

    /** scanner.e:1308				CompileErr(RAW_STRING_LITERAL_FROM_LINE_1_NOT_TERMINATED, cline)*/
    _50CompileErr(129LL, _cline_27116, 0LL);
L6: 

    /** scanner.e:1311			if ch = ech then*/
    if (_ch_27114 != _ech_27113)
    goto L7; // [126] 182

    /** scanner.e:1312				if ech != '"' then*/
    if (_ech_27113 == 34LL)
    goto L8; // [132] 141

    /** scanner.e:1313					exit*/
    goto L9; // [138] 312
L8: 

    /** scanner.e:1315				fch = getch()*/
    _fch_27115 = _62getch();
    if (!IS_ATOM_INT(_fch_27115)) {
        _1 = (object)(DBL_PTR(_fch_27115)->dbl);
        DeRefDS(_fch_27115);
        _fch_27115 = _1;
    }

    /** scanner.e:1316				if fch = '"' then*/
    if (_fch_27115 != 34LL)
    goto LA; // [150] 177

    /** scanner.e:1317					fch = getch()*/
    _fch_27115 = _62getch();
    if (!IS_ATOM_INT(_fch_27115)) {
        _1 = (object)(DBL_PTR(_fch_27115)->dbl);
        DeRefDS(_fch_27115);
        _fch_27115 = _1;
    }

    /** scanner.e:1318					if fch = '"' then*/
    if (_fch_27115 != 34LL)
    goto LB; // [163] 172

    /** scanner.e:1319						exit*/
    goto L9; // [169] 312
LB: 

    /** scanner.e:1321					ungetch()*/
    _62ungetch();
LA: 

    /** scanner.e:1323				ungetch()*/
    _62ungetch();
L7: 

    /** scanner.e:1326			if ch != '\r' then*/
    if (_ch_27114 == 13LL)
    goto LC; // [184] 195

    /** scanner.e:1329				string_text &= ch*/
    Append(&_string_text_27117, _string_text_27117, _ch_27114);
LC: 

    /** scanner.e:1332			if bp > length(ThisLine) then*/
    if (IS_SEQUENCE(_50ThisLine_49234)){
            _14960 = SEQ_PTR(_50ThisLine_49234)->length;
    }
    else {
        _14960 = 1;
    }
    if (_50bp_49238 <= _14960)
    goto LD; // [204] 300

    /** scanner.e:1333				read_line() -- sets bp to 1, btw.*/
    _62read_line();

    /** scanner.e:1334				if trimming > 0 then*/
    if (_trimming_27118 <= 0LL)
    goto LE; // [214] 299

    /** scanner.e:1335					while bp <= trimming and bp <= length(ThisLine) do*/
LF: 
    _14963 = (_50bp_49238 <= _trimming_27118);
    if (_14963 == 0) {
        goto L10; // [229] 298
    }
    if (IS_SEQUENCE(_50ThisLine_49234)){
            _14965 = SEQ_PTR(_50ThisLine_49234)->length;
    }
    else {
        _14965 = 1;
    }
    _14966 = (_50bp_49238 <= _14965);
    _14965 = NOVALUE;
    if (_14966 == 0)
    {
        DeRef(_14966);
        _14966 = NOVALUE;
        goto L10; // [245] 298
    }
    else{
        DeRef(_14966);
        _14966 = NOVALUE;
    }

    /** scanner.e:1336						ch = ThisLine[bp]*/
    _2 = (object)SEQ_PTR(_50ThisLine_49234);
    _ch_27114 = (object)*(((s1_ptr)_2)->base + _50bp_49238);
    if (!IS_ATOM_INT(_ch_27114)){
        _ch_27114 = (object)DBL_PTR(_ch_27114)->dbl;
    }

    /** scanner.e:1337						if ch != ' ' and ch != '\t' then*/
    _14968 = (_ch_27114 != 32LL);
    if (_14968 == 0) {
        goto L11; // [266] 283
    }
    _14970 = (_ch_27114 != 9LL);
    if (_14970 == 0)
    {
        DeRef(_14970);
        _14970 = NOVALUE;
        goto L11; // [275] 283
    }
    else{
        DeRef(_14970);
        _14970 = NOVALUE;
    }

    /** scanner.e:1338							exit*/
    goto L10; // [280] 298
L11: 

    /** scanner.e:1340						bp += 1*/
    _50bp_49238 = _50bp_49238 + 1LL;

    /** scanner.e:1341					end while*/
    goto LF; // [295] 223
L10: 
LE: 
LD: 

    /** scanner.e:1344			ch = getch()*/
    _ch_27114 = _62getch();
    if (!IS_ATOM_INT(_ch_27114)) {
        _1 = (object)(DBL_PTR(_ch_27114)->dbl);
        DeRefDS(_ch_27114);
        _ch_27114 = _1;
    }

    /** scanner.e:1345		end while*/
    goto L5; // [309] 106
L9: 

    /** scanner.e:1346		if length(string_text) > 0 and string_text[1] = '\n' then*/
    if (IS_SEQUENCE(_string_text_27117)){
            _14973 = SEQ_PTR(_string_text_27117)->length;
    }
    else {
        _14973 = 1;
    }
    _14974 = (_14973 > 0LL);
    _14973 = NOVALUE;
    if (_14974 == 0) {
        goto L12; // [321] 391
    }
    _2 = (object)SEQ_PTR(_string_text_27117);
    _14976 = (object)*(((s1_ptr)_2)->base + 1LL);
    _14977 = (_14976 == 10LL);
    _14976 = NOVALUE;
    if (_14977 == 0)
    {
        DeRef(_14977);
        _14977 = NOVALUE;
        goto L12; // [334] 391
    }
    else{
        DeRef(_14977);
        _14977 = NOVALUE;
    }

    /** scanner.e:1347			string_text = string_text[2 .. $]*/
    if (IS_SEQUENCE(_string_text_27117)){
            _14978 = SEQ_PTR(_string_text_27117)->length;
    }
    else {
        _14978 = 1;
    }
    rhs_slice_target = (object_ptr)&_string_text_27117;
    RHS_Slice(_string_text_27117, 2LL, _14978);

    /** scanner.e:1348			if length(string_text) > 0 and string_text[$] = '\n' then*/
    if (IS_SEQUENCE(_string_text_27117)){
            _14980 = SEQ_PTR(_string_text_27117)->length;
    }
    else {
        _14980 = 1;
    }
    _14981 = (_14980 > 0LL);
    _14980 = NOVALUE;
    if (_14981 == 0) {
        goto L13; // [356] 390
    }
    if (IS_SEQUENCE(_string_text_27117)){
            _14983 = SEQ_PTR(_string_text_27117)->length;
    }
    else {
        _14983 = 1;
    }
    _2 = (object)SEQ_PTR(_string_text_27117);
    _14984 = (object)*(((s1_ptr)_2)->base + _14983);
    _14985 = (_14984 == 10LL);
    _14984 = NOVALUE;
    if (_14985 == 0)
    {
        DeRef(_14985);
        _14985 = NOVALUE;
        goto L13; // [372] 390
    }
    else{
        DeRef(_14985);
        _14985 = NOVALUE;
    }

    /** scanner.e:1349				string_text = string_text[1 .. $-1]*/
    if (IS_SEQUENCE(_string_text_27117)){
            _14986 = SEQ_PTR(_string_text_27117)->length;
    }
    else {
        _14986 = 1;
    }
    _14987 = _14986 - 1LL;
    _14986 = NOVALUE;
    rhs_slice_target = (object_ptr)&_string_text_27117;
    RHS_Slice(_string_text_27117, 1LL, _14987);
L13: 
L12: 

    /** scanner.e:1352		return {STRING, NewStringSym(string_text)}*/
    RefDS(_string_text_27117);
    _14989 = _54NewStringSym(_string_text_27117);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 503LL;
    ((intptr_t *)_2)[2] = _14989;
    _14990 = MAKE_SEQ(_1);
    _14989 = NOVALUE;
    DeRefDSi(_string_text_27117);
    DeRef(_14987);
    _14987 = NOVALUE;
    DeRef(_14974);
    _14974 = NOVALUE;
    DeRef(_14981);
    _14981 = NOVALUE;
    DeRef(_14963);
    _14963 = NOVALUE;
    DeRef(_14968);
    _14968 = NOVALUE;
    return _14990;
    ;
}


object _62GetHexString(object _maxnibbles_27205)
{
    object _ch_27206 = NOVALUE;
    object _digit_27207 = NOVALUE;
    object _val_27208 = NOVALUE;
    object _cline_27209 = NOVALUE;
    object _nibble_27210 = NOVALUE;
    object _string_text_27211 = NOVALUE;
    object _15004 = NOVALUE;
    object _15003 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1363		cline = line_number*/
    _cline_27209 = _36line_number_21440;

    /** scanner.e:1364		string_text = ""*/
    RefDS(_5);
    DeRef(_string_text_27211);
    _string_text_27211 = _5;

    /** scanner.e:1365		nibble = 1*/
    _nibble_27210 = 1LL;

    /** scanner.e:1366		val = -1*/
    DeRef(_val_27208);
    _val_27208 = -1LL;

    /** scanner.e:1367		ch = getch()*/
    _ch_27206 = _62getch();
    if (!IS_ATOM_INT(_ch_27206)) {
        _1 = (object)(DBL_PTR(_ch_27206)->dbl);
        DeRefDS(_ch_27206);
        _ch_27206 = _1;
    }

    /** scanner.e:1368		while 1 do*/
L1: 

    /** scanner.e:1369			if ch = END_OF_FILE_CHAR then*/
    if (_ch_27206 != 26LL)
    goto L2; // [45] 59

    /** scanner.e:1370				CompileErr(RAW_STRING_LITERAL_FROM_LINE_1_NOT_TERMINATED, cline)*/
    _50CompileErr(129LL, _cline_27209, 0LL);
L2: 

    /** scanner.e:1373			if ch = '"' then*/
    if (_ch_27206 != 34LL)
    goto L3; // [61] 70

    /** scanner.e:1374				exit*/
    goto L4; // [67] 228
L3: 

    /** scanner.e:1377			digit = find(ch, "0123456789ABCDEFabcdef_ \t\n\r")*/
    _digit_27207 = find_from(_ch_27206, _14994, 1LL);

    /** scanner.e:1378			if digit = 0 then*/
    if (_digit_27207 != 0LL)
    goto L5; // [79] 93

    /** scanner.e:1379				CompileErr(INVALID_CHARACTER_IN_HEX_STRING)*/
    RefDS(_21993);
    _50CompileErr(329LL, _21993, 0LL);
L5: 

    /** scanner.e:1381			if digit <= 23 then*/
    if (_digit_27207 > 23LL)
    goto L6; // [95] 181

    /** scanner.e:1382				if digit != 23 then*/
    if (_digit_27207 == 23LL)
    goto L7; // [101] 216

    /** scanner.e:1383					if digit > 16 then*/
    if (_digit_27207 <= 16LL)
    goto L8; // [107] 118

    /** scanner.e:1384						digit -= 6*/
    _digit_27207 = _digit_27207 - 6LL;
L8: 

    /** scanner.e:1386					if nibble = 1 then*/
    if (_nibble_27210 != 1LL)
    goto L9; // [120] 133

    /** scanner.e:1387						val = digit - 1*/
    DeRef(_val_27208);
    _val_27208 = _digit_27207 - 1LL;
    if ((object)((uintptr_t)_val_27208 +(uintptr_t) HIGH_BITS) >= 0){
        _val_27208 = NewDouble((eudouble)_val_27208);
    }
    goto LA; // [130] 171
L9: 

    /** scanner.e:1389						val = val * 16 + digit - 1*/
    if (IS_ATOM_INT(_val_27208)) {
        {
            int128_t p128 = (int128_t)_val_27208 * (int128_t)16LL;
            if( p128 != (int128_t)(_15003 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _15003 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _15003 = NewDouble(DBL_PTR(_val_27208)->dbl * (eudouble)16LL);
    }
    if (IS_ATOM_INT(_15003)) {
        _15004 = _15003 + _digit_27207;
        if ((object)((uintptr_t)_15004 + (uintptr_t)HIGH_BITS) >= 0){
            _15004 = NewDouble((eudouble)_15004);
        }
    }
    else {
        _15004 = NewDouble(DBL_PTR(_15003)->dbl + (eudouble)_digit_27207);
    }
    DeRef(_15003);
    _15003 = NOVALUE;
    DeRef(_val_27208);
    if (IS_ATOM_INT(_15004)) {
        _val_27208 = _15004 - 1LL;
        if ((object)((uintptr_t)_val_27208 +(uintptr_t) HIGH_BITS) >= 0){
            _val_27208 = NewDouble((eudouble)_val_27208);
        }
    }
    else {
        _val_27208 = NewDouble(DBL_PTR(_15004)->dbl - (eudouble)1LL);
    }
    DeRef(_15004);
    _15004 = NOVALUE;

    /** scanner.e:1390						if nibble = maxnibbles then*/
    if (_nibble_27210 != _maxnibbles_27205)
    goto LB; // [149] 170

    /** scanner.e:1391							string_text &= val*/
    Ref(_val_27208);
    Append(&_string_text_27211, _string_text_27211, _val_27208);

    /** scanner.e:1392							val = -1*/
    DeRef(_val_27208);
    _val_27208 = -1LL;

    /** scanner.e:1393							nibble = 0*/
    _nibble_27210 = 0LL;
LB: 
LA: 

    /** scanner.e:1396					nibble += 1*/
    _nibble_27210 = _nibble_27210 + 1;
    goto L7; // [178] 216
L6: 

    /** scanner.e:1399				if val >= 0 then*/
    if (binary_op_a(LESS, _val_27208, 0LL)){
        goto LC; // [183] 199
    }

    /** scanner.e:1401					string_text &= val*/
    Ref(_val_27208);
    Append(&_string_text_27211, _string_text_27211, _val_27208);

    /** scanner.e:1402					val = -1*/
    DeRef(_val_27208);
    _val_27208 = -1LL;
LC: 

    /** scanner.e:1404				nibble = 1*/
    _nibble_27210 = 1LL;

    /** scanner.e:1405				if ch = '\n' then*/
    if (_ch_27206 != 10LL)
    goto LD; // [206] 215

    /** scanner.e:1406					read_line()*/
    _62read_line();
LD: 
L7: 

    /** scanner.e:1409			ch = getch()*/
    _ch_27206 = _62getch();
    if (!IS_ATOM_INT(_ch_27206)) {
        _1 = (object)(DBL_PTR(_ch_27206)->dbl);
        DeRefDS(_ch_27206);
        _ch_27206 = _1;
    }

    /** scanner.e:1410		end while*/
    goto L1; // [225] 41
L4: 

    /** scanner.e:1412		if val >= 0 then	*/
    if (binary_op_a(LESS, _val_27208, 0LL)){
        goto LE; // [230] 241
    }

    /** scanner.e:1414			string_text &= val*/
    Ref(_val_27208);
    Append(&_string_text_27211, _string_text_27211, _val_27208);
LE: 

    /** scanner.e:1417		return string_text*/
    DeRef(_val_27208);
    return _string_text_27211;
    ;
}


object _62GetBitString()
{
    object _ch_27258 = NOVALUE;
    object _digit_27259 = NOVALUE;
    object _val_27260 = NOVALUE;
    object _cline_27261 = NOVALUE;
    object _bitcnt_27262 = NOVALUE;
    object _string_text_27263 = NOVALUE;
    object _15026 = NOVALUE;
    object _15025 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1428		cline = line_number*/
    _cline_27261 = _36line_number_21440;

    /** scanner.e:1429		string_text = ""*/
    RefDS(_5);
    DeRef(_string_text_27263);
    _string_text_27263 = _5;

    /** scanner.e:1430		bitcnt = 1*/
    _bitcnt_27262 = 1LL;

    /** scanner.e:1431		val = -1*/
    DeRef(_val_27260);
    _val_27260 = -1LL;

    /** scanner.e:1432		ch = getch()*/
    _ch_27258 = _62getch();
    if (!IS_ATOM_INT(_ch_27258)) {
        _1 = (object)(DBL_PTR(_ch_27258)->dbl);
        DeRefDS(_ch_27258);
        _ch_27258 = _1;
    }

    /** scanner.e:1433		while 1 do*/
L1: 

    /** scanner.e:1434			if ch = END_OF_FILE_CHAR then*/
    if (_ch_27258 != 26LL)
    goto L2; // [43] 57

    /** scanner.e:1435				CompileErr(RAW_STRING_LITERAL_FROM_LINE_1_NOT_TERMINATED, cline)*/
    _50CompileErr(129LL, _cline_27261, 0LL);
L2: 

    /** scanner.e:1438			if ch = '"' then*/
    if (_ch_27258 != 34LL)
    goto L3; // [59] 68

    /** scanner.e:1439				exit*/
    goto L4; // [65] 190
L3: 

    /** scanner.e:1442			digit = find(ch, "01_ \t\n\r")*/
    _digit_27259 = find_from(_ch_27258, _15018, 1LL);

    /** scanner.e:1443			if digit = 0 then*/
    if (_digit_27259 != 0LL)
    goto L5; // [77] 91

    /** scanner.e:1444				CompileErr(INVALID_CHARACTER_IN_HEX_STRING)*/
    RefDS(_21993);
    _50CompileErr(329LL, _21993, 0LL);
L5: 

    /** scanner.e:1446			if digit <= 3 then*/
    if (_digit_27259 > 3LL)
    goto L6; // [93] 143

    /** scanner.e:1447				if digit != 3 then*/
    if (_digit_27259 == 3LL)
    goto L7; // [99] 178

    /** scanner.e:1448					if bitcnt = 1 then*/
    if (_bitcnt_27262 != 1LL)
    goto L8; // [105] 118

    /** scanner.e:1449						val = digit - 1*/
    DeRef(_val_27260);
    _val_27260 = _digit_27259 - 1LL;
    if ((object)((uintptr_t)_val_27260 +(uintptr_t) HIGH_BITS) >= 0){
        _val_27260 = NewDouble((eudouble)_val_27260);
    }
    goto L9; // [115] 133
L8: 

    /** scanner.e:1451						val = val * 2 + digit - 1*/
    if (IS_ATOM_INT(_val_27260) && IS_ATOM_INT(_val_27260)) {
        _15025 = _val_27260 + _val_27260;
        if ((object)((uintptr_t)_15025 + (uintptr_t)HIGH_BITS) >= 0){
            _15025 = NewDouble((eudouble)_15025);
        }
    }
    else {
        if (IS_ATOM_INT(_val_27260)) {
            _15025 = NewDouble((eudouble)_val_27260 + DBL_PTR(_val_27260)->dbl);
        }
        else {
            if (IS_ATOM_INT(_val_27260)) {
                _15025 = NewDouble(DBL_PTR(_val_27260)->dbl + (eudouble)_val_27260);
            }
            else
            _15025 = NewDouble(DBL_PTR(_val_27260)->dbl + DBL_PTR(_val_27260)->dbl);
        }
    }
    if (IS_ATOM_INT(_15025)) {
        _15026 = _15025 + _digit_27259;
        if ((object)((uintptr_t)_15026 + (uintptr_t)HIGH_BITS) >= 0){
            _15026 = NewDouble((eudouble)_15026);
        }
    }
    else {
        _15026 = NewDouble(DBL_PTR(_15025)->dbl + (eudouble)_digit_27259);
    }
    DeRef(_15025);
    _15025 = NOVALUE;
    DeRef(_val_27260);
    if (IS_ATOM_INT(_15026)) {
        _val_27260 = _15026 - 1LL;
        if ((object)((uintptr_t)_val_27260 +(uintptr_t) HIGH_BITS) >= 0){
            _val_27260 = NewDouble((eudouble)_val_27260);
        }
    }
    else {
        _val_27260 = NewDouble(DBL_PTR(_15026)->dbl - (eudouble)1LL);
    }
    DeRef(_15026);
    _15026 = NOVALUE;
L9: 

    /** scanner.e:1453					bitcnt += 1*/
    _bitcnt_27262 = _bitcnt_27262 + 1;
    goto L7; // [140] 178
L6: 

    /** scanner.e:1456				if val >= 0 then*/
    if (binary_op_a(LESS, _val_27260, 0LL)){
        goto LA; // [145] 161
    }

    /** scanner.e:1458					string_text &= val*/
    Ref(_val_27260);
    Append(&_string_text_27263, _string_text_27263, _val_27260);

    /** scanner.e:1459					val = -1*/
    DeRef(_val_27260);
    _val_27260 = -1LL;
LA: 

    /** scanner.e:1461				bitcnt = 1*/
    _bitcnt_27262 = 1LL;

    /** scanner.e:1462				if ch = '\n' then*/
    if (_ch_27258 != 10LL)
    goto LB; // [168] 177

    /** scanner.e:1463					read_line()*/
    _62read_line();
LB: 
L7: 

    /** scanner.e:1466			ch = getch()*/
    _ch_27258 = _62getch();
    if (!IS_ATOM_INT(_ch_27258)) {
        _1 = (object)(DBL_PTR(_ch_27258)->dbl);
        DeRefDS(_ch_27258);
        _ch_27258 = _1;
    }

    /** scanner.e:1467		end while*/
    goto L1; // [187] 39
L4: 

    /** scanner.e:1469		if val >= 0 then	*/
    if (binary_op_a(LESS, _val_27260, 0LL)){
        goto LC; // [192] 203
    }

    /** scanner.e:1471			string_text &= val*/
    Ref(_val_27260);
    Append(&_string_text_27263, _string_text_27263, _val_27260);
LC: 

    /** scanner.e:1474		return string_text*/
    DeRef(_val_27260);
    return _string_text_27263;
    ;
}


object _62Scanner()
{
    object _fwd_inlined_set_qualified_fwd_at_441_27403 = NOVALUE;
    object _ch_27304 = NOVALUE;
    object _sp_27305 = NOVALUE;
    object _prev_Nne_27306 = NOVALUE;
    object _i_27307 = NOVALUE;
    object _pch_27308 = NOVALUE;
    object _cline_27309 = NOVALUE;
    object _yytext_27310 = NOVALUE;
    object _namespaces_27311 = NOVALUE;
    object _d_27312 = NOVALUE;
    object _tok_27314 = NOVALUE;
    object _is_int_27315 = NOVALUE;
    object _class_27316 = NOVALUE;
    object _name_27317 = NOVALUE;
    object _is_namespace_27376 = NOVALUE;
    object _basetype_27612 = NOVALUE;
    object _hdigit_27653 = NOVALUE;
    object _fch_27793 = NOVALUE;
    object _cnest_27977 = NOVALUE;
    object _ach_28007 = NOVALUE;
    object _31717 = NOVALUE;
    object _31716 = NOVALUE;
    object _31715 = NOVALUE;
    object _31714 = NOVALUE;
    object _31713 = NOVALUE;
    object _31712 = NOVALUE;
    object _31711 = NOVALUE;
    object _15419 = NOVALUE;
    object _15418 = NOVALUE;
    object _15416 = NOVALUE;
    object _15414 = NOVALUE;
    object _15413 = NOVALUE;
    object _15412 = NOVALUE;
    object _15410 = NOVALUE;
    object _15409 = NOVALUE;
    object _15408 = NOVALUE;
    object _15407 = NOVALUE;
    object _15405 = NOVALUE;
    object _15404 = NOVALUE;
    object _15402 = NOVALUE;
    object _15400 = NOVALUE;
    object _15399 = NOVALUE;
    object _15397 = NOVALUE;
    object _15395 = NOVALUE;
    object _15394 = NOVALUE;
    object _15392 = NOVALUE;
    object _15390 = NOVALUE;
    object _15389 = NOVALUE;
    object _15388 = NOVALUE;
    object _15387 = NOVALUE;
    object _15386 = NOVALUE;
    object _15384 = NOVALUE;
    object _15383 = NOVALUE;
    object _15373 = NOVALUE;
    object _15360 = NOVALUE;
    object _15356 = NOVALUE;
    object _15355 = NOVALUE;
    object _15351 = NOVALUE;
    object _15350 = NOVALUE;
    object _15349 = NOVALUE;
    object _15348 = NOVALUE;
    object _15346 = NOVALUE;
    object _15345 = NOVALUE;
    object _15344 = NOVALUE;
    object _15343 = NOVALUE;
    object _15340 = NOVALUE;
    object _15339 = NOVALUE;
    object _15338 = NOVALUE;
    object _15337 = NOVALUE;
    object _15336 = NOVALUE;
    object _15335 = NOVALUE;
    object _15333 = NOVALUE;
    object _15332 = NOVALUE;
    object _15331 = NOVALUE;
    object _15330 = NOVALUE;
    object _15329 = NOVALUE;
    object _15328 = NOVALUE;
    object _15326 = NOVALUE;
    object _15325 = NOVALUE;
    object _15322 = NOVALUE;
    object _15319 = NOVALUE;
    object _15314 = NOVALUE;
    object _15313 = NOVALUE;
    object _15312 = NOVALUE;
    object _15311 = NOVALUE;
    object _15310 = NOVALUE;
    object _15309 = NOVALUE;
    object _15307 = NOVALUE;
    object _15306 = NOVALUE;
    object _15305 = NOVALUE;
    object _15304 = NOVALUE;
    object _15303 = NOVALUE;
    object _15302 = NOVALUE;
    object _15300 = NOVALUE;
    object _15299 = NOVALUE;
    object _15296 = NOVALUE;
    object _15293 = NOVALUE;
    object _15291 = NOVALUE;
    object _15290 = NOVALUE;
    object _15286 = NOVALUE;
    object _15285 = NOVALUE;
    object _15281 = NOVALUE;
    object _15280 = NOVALUE;
    object _15279 = NOVALUE;
    object _15277 = NOVALUE;
    object _15272 = NOVALUE;
    object _15269 = NOVALUE;
    object _15268 = NOVALUE;
    object _15267 = NOVALUE;
    object _15266 = NOVALUE;
    object _15260 = NOVALUE;
    object _15258 = NOVALUE;
    object _15253 = NOVALUE;
    object _15252 = NOVALUE;
    object _15251 = NOVALUE;
    object _15250 = NOVALUE;
    object _15249 = NOVALUE;
    object _15248 = NOVALUE;
    object _15247 = NOVALUE;
    object _15245 = NOVALUE;
    object _15243 = NOVALUE;
    object _15242 = NOVALUE;
    object _15241 = NOVALUE;
    object _15240 = NOVALUE;
    object _15239 = NOVALUE;
    object _15237 = NOVALUE;
    object _15232 = NOVALUE;
    object _15231 = NOVALUE;
    object _15229 = NOVALUE;
    object _15225 = NOVALUE;
    object _15222 = NOVALUE;
    object _15221 = NOVALUE;
    object _15219 = NOVALUE;
    object _15218 = NOVALUE;
    object _15217 = NOVALUE;
    object _15214 = NOVALUE;
    object _15212 = NOVALUE;
    object _15211 = NOVALUE;
    object _15207 = NOVALUE;
    object _15203 = NOVALUE;
    object _15200 = NOVALUE;
    object _15194 = NOVALUE;
    object _15186 = NOVALUE;
    object _15185 = NOVALUE;
    object _15184 = NOVALUE;
    object _15182 = NOVALUE;
    object _15179 = NOVALUE;
    object _15177 = NOVALUE;
    object _15175 = NOVALUE;
    object _15172 = NOVALUE;
    object _15169 = NOVALUE;
    object _15167 = NOVALUE;
    object _15165 = NOVALUE;
    object _15163 = NOVALUE;
    object _15162 = NOVALUE;
    object _15158 = NOVALUE;
    object _15155 = NOVALUE;
    object _15153 = NOVALUE;
    object _15150 = NOVALUE;
    object _15143 = NOVALUE;
    object _15141 = NOVALUE;
    object _15138 = NOVALUE;
    object _15132 = NOVALUE;
    object _15131 = NOVALUE;
    object _15130 = NOVALUE;
    object _15129 = NOVALUE;
    object _15128 = NOVALUE;
    object _15127 = NOVALUE;
    object _15126 = NOVALUE;
    object _15124 = NOVALUE;
    object _15122 = NOVALUE;
    object _15120 = NOVALUE;
    object _15118 = NOVALUE;
    object _15116 = NOVALUE;
    object _15115 = NOVALUE;
    object _15114 = NOVALUE;
    object _15113 = NOVALUE;
    object _15112 = NOVALUE;
    object _15110 = NOVALUE;
    object _15107 = NOVALUE;
    object _15105 = NOVALUE;
    object _15104 = NOVALUE;
    object _15103 = NOVALUE;
    object _15101 = NOVALUE;
    object _15096 = NOVALUE;
    object _15092 = NOVALUE;
    object _15089 = NOVALUE;
    object _15087 = NOVALUE;
    object _15086 = NOVALUE;
    object _15084 = NOVALUE;
    object _15082 = NOVALUE;
    object _15080 = NOVALUE;
    object _15079 = NOVALUE;
    object _15078 = NOVALUE;
    object _15076 = NOVALUE;
    object _15071 = NOVALUE;
    object _15068 = NOVALUE;
    object _15066 = NOVALUE;
    object _15063 = NOVALUE;
    object _15062 = NOVALUE;
    object _15060 = NOVALUE;
    object _15059 = NOVALUE;
    object _15058 = NOVALUE;
    object _15057 = NOVALUE;
    object _15056 = NOVALUE;
    object _15055 = NOVALUE;
    object _15054 = NOVALUE;
    object _15053 = NOVALUE;
    object _15052 = NOVALUE;
    object _15051 = NOVALUE;
    object _15050 = NOVALUE;
    object _15049 = NOVALUE;
    object _15048 = NOVALUE;
    object _15043 = NOVALUE;
    object _15041 = NOVALUE;
    object _15038 = NOVALUE;
    object _15036 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1486		integer is_int, class*/

    /** scanner.e:1487		sequence name*/

    /** scanner.e:1489		while TRUE do*/
L1: 
    if (_13TRUE_452 == 0)
    {
        goto L2; // [12] 3821
    }
    else{
    }

    /** scanner.e:1490			ch = getch()*/
    _ch_27304 = _62getch();
    if (!IS_ATOM_INT(_ch_27304)) {
        _1 = (object)(DBL_PTR(_ch_27304)->dbl);
        DeRefDS(_ch_27304);
        _ch_27304 = _1;
    }

    /** scanner.e:1491			while ch = ' ' or ch = '\t' do*/
L3: 
    _15036 = (_ch_27304 == 32LL);
    if (_15036 != 0) {
        goto L4; // [31] 44
    }
    _15038 = (_ch_27304 == 9LL);
    if (_15038 == 0)
    {
        DeRef(_15038);
        _15038 = NOVALUE;
        goto L5; // [40] 56
    }
    else{
        DeRef(_15038);
        _15038 = NOVALUE;
    }
L4: 

    /** scanner.e:1492				ch = getch()*/
    _ch_27304 = _62getch();
    if (!IS_ATOM_INT(_ch_27304)) {
        _1 = (object)(DBL_PTR(_ch_27304)->dbl);
        DeRefDS(_ch_27304);
        _ch_27304 = _1;
    }

    /** scanner.e:1493			end while*/
    goto L3; // [53] 27
L5: 

    /** scanner.e:1495			class = char_class[ch]*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _class_27316 = (object)*(((s1_ptr)_2)->base + _ch_27304);

    /** scanner.e:1498			if class = LETTER or ch = '_' then*/
    _15041 = (_class_27316 == -2LL);
    if (_15041 != 0) {
        goto L6; // [72] 85
    }
    _15043 = (_ch_27304 == 95LL);
    if (_15043 == 0)
    {
        DeRef(_15043);
        _15043 = NOVALUE;
        goto L7; // [81] 1284
    }
    else{
        DeRef(_15043);
        _15043 = NOVALUE;
    }
L6: 

    /** scanner.e:1499				sp = bp*/
    _sp_27305 = _50bp_49238;

    /** scanner.e:1500				pch = ch*/
    _pch_27308 = _ch_27304;

    /** scanner.e:1501				ch = getch()*/
    _ch_27304 = _62getch();
    if (!IS_ATOM_INT(_ch_27304)) {
        _1 = (object)(DBL_PTR(_ch_27304)->dbl);
        DeRefDS(_ch_27304);
        _ch_27304 = _1;
    }

    /** scanner.e:1502				if ch = '"' then*/
    if (_ch_27304 != 34LL)
    goto L8; // [108] 222

    /** scanner.e:1503					switch pch do*/
    _0 = _pch_27308;
    switch ( _0 ){ 

        /** scanner.e:1504						case 'x' then*/
        case 120:

        /** scanner.e:1505							return {STRING, NewStringSym(GetHexString(2))}*/
        _15048 = _62GetHexString(2LL);
        _15049 = _54NewStringSym(_15048);
        _15048 = NOVALUE;
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 503LL;
        ((intptr_t *)_2)[2] = _15049;
        _15050 = MAKE_SEQ(_1);
        _15049 = NOVALUE;
        DeRef(_i_27307);
        DeRef(_yytext_27310);
        DeRef(_namespaces_27311);
        DeRef(_d_27312);
        DeRef(_tok_27314);
        DeRef(_name_27317);
        DeRef(_15036);
        _15036 = NOVALUE;
        DeRef(_15041);
        _15041 = NOVALUE;
        return _15050;
        goto L9; // [143] 221

        /** scanner.e:1507						case 'u' then*/
        case 117:

        /** scanner.e:1508							return {STRING, NewStringSym(GetHexString(4))}*/
        _15051 = _62GetHexString(4LL);
        _15052 = _54NewStringSym(_15051);
        _15051 = NOVALUE;
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 503LL;
        ((intptr_t *)_2)[2] = _15052;
        _15053 = MAKE_SEQ(_1);
        _15052 = NOVALUE;
        DeRef(_i_27307);
        DeRef(_yytext_27310);
        DeRef(_namespaces_27311);
        DeRef(_d_27312);
        DeRef(_tok_27314);
        DeRef(_name_27317);
        DeRef(_15050);
        _15050 = NOVALUE;
        DeRef(_15036);
        _15036 = NOVALUE;
        DeRef(_15041);
        _15041 = NOVALUE;
        return _15053;
        goto L9; // [169] 221

        /** scanner.e:1510						case 'U' then*/
        case 85:

        /** scanner.e:1511							return {STRING, NewStringSym(GetHexString(8))}*/
        _15054 = _62GetHexString(8LL);
        _15055 = _54NewStringSym(_15054);
        _15054 = NOVALUE;
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 503LL;
        ((intptr_t *)_2)[2] = _15055;
        _15056 = MAKE_SEQ(_1);
        _15055 = NOVALUE;
        DeRef(_i_27307);
        DeRef(_yytext_27310);
        DeRef(_namespaces_27311);
        DeRef(_d_27312);
        DeRef(_tok_27314);
        DeRef(_name_27317);
        DeRef(_15050);
        _15050 = NOVALUE;
        DeRef(_15036);
        _15036 = NOVALUE;
        DeRef(_15053);
        _15053 = NOVALUE;
        DeRef(_15041);
        _15041 = NOVALUE;
        return _15056;
        goto L9; // [195] 221

        /** scanner.e:1513						case 'b' then*/
        case 98:

        /** scanner.e:1514							return {STRING, NewStringSym(GetBitString())}*/
        _15057 = _62GetBitString();
        _15058 = _54NewStringSym(_15057);
        _15057 = NOVALUE;
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 503LL;
        ((intptr_t *)_2)[2] = _15058;
        _15059 = MAKE_SEQ(_1);
        _15058 = NOVALUE;
        DeRef(_i_27307);
        DeRef(_yytext_27310);
        DeRef(_namespaces_27311);
        DeRef(_d_27312);
        DeRef(_tok_27314);
        DeRef(_name_27317);
        DeRef(_15056);
        _15056 = NOVALUE;
        DeRef(_15050);
        _15050 = NOVALUE;
        DeRef(_15036);
        _15036 = NOVALUE;
        DeRef(_15053);
        _15053 = NOVALUE;
        DeRef(_15041);
        _15041 = NOVALUE;
        return _15059;
    ;}L9: 
L8: 

    /** scanner.e:1519				while id_char[ch] do*/
LA: 
    _2 = (object)SEQ_PTR(_62id_char_25555);
    _15060 = (object)*(((s1_ptr)_2)->base + _ch_27304);
    if (_15060 == 0)
    {
        _15060 = NOVALUE;
        goto LB; // [233] 248
    }
    else{
        _15060 = NOVALUE;
    }

    /** scanner.e:1520					ch = getch()*/
    _ch_27304 = _62getch();
    if (!IS_ATOM_INT(_ch_27304)) {
        _1 = (object)(DBL_PTR(_ch_27304)->dbl);
        DeRefDS(_ch_27304);
        _ch_27304 = _1;
    }

    /** scanner.e:1521				end while*/
    goto LA; // [245] 227
LB: 

    /** scanner.e:1522				yytext = ThisLine[sp-1..bp-2]*/
    _15062 = _sp_27305 - 1LL;
    if ((object)((uintptr_t)_15062 +(uintptr_t) HIGH_BITS) >= 0){
        _15062 = NewDouble((eudouble)_15062);
    }
    _15063 = _50bp_49238 - 2LL;
    rhs_slice_target = (object_ptr)&_yytext_27310;
    RHS_Slice(_50ThisLine_49234, _15062, _15063);

    /** scanner.e:1523				ungetch()*/
    _62ungetch();

    /** scanner.e:1525				ch = getch()*/
    _ch_27304 = _62getch();
    if (!IS_ATOM_INT(_ch_27304)) {
        _1 = (object)(DBL_PTR(_ch_27304)->dbl);
        DeRefDS(_ch_27304);
        _ch_27304 = _1;
    }

    /** scanner.e:1526				while ch = ' ' or ch = '\t' do*/
LC: 
    _15066 = (_ch_27304 == 32LL);
    if (_15066 != 0) {
        goto LD; // [287] 300
    }
    _15068 = (_ch_27304 == 9LL);
    if (_15068 == 0)
    {
        DeRef(_15068);
        _15068 = NOVALUE;
        goto LE; // [296] 312
    }
    else{
        DeRef(_15068);
        _15068 = NOVALUE;
    }
LD: 

    /** scanner.e:1527					ch = getch()*/
    _ch_27304 = _62getch();
    if (!IS_ATOM_INT(_ch_27304)) {
        _1 = (object)(DBL_PTR(_ch_27304)->dbl);
        DeRefDS(_ch_27304);
        _ch_27304 = _1;
    }

    /** scanner.e:1528				end while*/
    goto LC; // [309] 283
LE: 

    /** scanner.e:1529				integer is_namespace*/

    /** scanner.e:1531				if might_be_namespace then*/
    if (_62might_be_namespace_27103 == 0)
    {
        goto LF; // [318] 361
    }
    else{
    }

    /** scanner.e:1532					tok = keyfind(yytext, -1, , -1 )*/
    RefDS(_yytext_27310);
    _31717 = _54hashfn(_yytext_27310);
    RefDS(_yytext_27310);
    _0 = _tok_27314;
    _tok_27314 = _54keyfind(_yytext_27310, -1LL, _36current_file_no_21439, -1LL, _31717);
    DeRef(_0);
    _31717 = NOVALUE;

    /** scanner.e:1533					is_namespace = tok[T_ID] = NAMESPACE*/
    _2 = (object)SEQ_PTR(_tok_27314);
    _15071 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_15071)) {
        _is_namespace_27376 = (_15071 == 523LL);
    }
    else {
        _is_namespace_27376 = binary_op(EQUALS, _15071, 523LL);
    }
    _15071 = NOVALUE;
    if (!IS_ATOM_INT(_is_namespace_27376)) {
        _1 = (object)(DBL_PTR(_is_namespace_27376)->dbl);
        DeRefDS(_is_namespace_27376);
        _is_namespace_27376 = _1;
    }

    /** scanner.e:1534					might_be_namespace = 0*/
    _62might_be_namespace_27103 = 0LL;
    goto L10; // [358] 384
LF: 

    /** scanner.e:1536					is_namespace = ch = ':'*/
    _is_namespace_27376 = (_ch_27304 == 58LL);

    /** scanner.e:1537					tok = keyfind(yytext, -1, , is_namespace )*/
    RefDS(_yytext_27310);
    _31716 = _54hashfn(_yytext_27310);
    RefDS(_yytext_27310);
    _0 = _tok_27314;
    _tok_27314 = _54keyfind(_yytext_27310, -1LL, _36current_file_no_21439, _is_namespace_27376, _31716);
    DeRef(_0);
    _31716 = NOVALUE;
L10: 

    /** scanner.e:1541				if not is_namespace then*/
    if (_is_namespace_27376 != 0)
    goto L11; // [388] 396

    /** scanner.e:1542					ungetch()*/
    _62ungetch();
L11: 

    /** scanner.e:1545				if is_namespace then*/
    if (_is_namespace_27376 == 0)
    {
        goto L12; // [398] 1121
    }
    else{
    }

    /** scanner.e:1547					namespaces = yytext*/
    RefDS(_yytext_27310);
    DeRef(_namespaces_27311);
    _namespaces_27311 = _yytext_27310;

    /** scanner.e:1550					if tok[T_ID] = NAMESPACE then -- known namespace*/
    _2 = (object)SEQ_PTR(_tok_27314);
    _15076 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _15076, 523LL)){
        _15076 = NOVALUE;
        goto L13; // [420] 976
    }
    _15076 = NOVALUE;

    /** scanner.e:1551						set_qualified_fwd( SymTab[tok[T_SYM]][S_OBJ] )*/
    _2 = (object)SEQ_PTR(_tok_27314);
    _15078 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_15078)){
        _15079 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_15078)->dbl));
    }
    else{
        _15079 = (object)*(((s1_ptr)_2)->base + _15078);
    }
    _2 = (object)SEQ_PTR(_15079);
    _15080 = (object)*(((s1_ptr)_2)->base + 1LL);
    _15079 = NOVALUE;
    Ref(_15080);
    DeRef(_fwd_inlined_set_qualified_fwd_at_441_27403);
    _fwd_inlined_set_qualified_fwd_at_441_27403 = _15080;
    _15080 = NOVALUE;
    if (!IS_ATOM_INT(_fwd_inlined_set_qualified_fwd_at_441_27403)) {
        _1 = (object)(DBL_PTR(_fwd_inlined_set_qualified_fwd_at_441_27403)->dbl);
        DeRefDS(_fwd_inlined_set_qualified_fwd_at_441_27403);
        _fwd_inlined_set_qualified_fwd_at_441_27403 = _1;
    }

    /** scanner.e:104		qualified_fwd = fwd*/
    _62qualified_fwd_25579 = _fwd_inlined_set_qualified_fwd_at_441_27403;

    /** scanner.e:105	end procedure*/
    goto L14; // [456] 459
L14: 
    DeRef(_fwd_inlined_set_qualified_fwd_at_441_27403);
    _fwd_inlined_set_qualified_fwd_at_441_27403 = NOVALUE;

    /** scanner.e:1554						ch = getch()*/
    _ch_27304 = _62getch();
    if (!IS_ATOM_INT(_ch_27304)) {
        _1 = (object)(DBL_PTR(_ch_27304)->dbl);
        DeRefDS(_ch_27304);
        _ch_27304 = _1;
    }

    /** scanner.e:1555						while ch = ' ' or ch = '\t' do*/
L15: 
    _15082 = (_ch_27304 == 32LL);
    if (_15082 != 0) {
        goto L16; // [477] 490
    }
    _15084 = (_ch_27304 == 9LL);
    if (_15084 == 0)
    {
        DeRef(_15084);
        _15084 = NOVALUE;
        goto L17; // [486] 502
    }
    else{
        DeRef(_15084);
        _15084 = NOVALUE;
    }
L16: 

    /** scanner.e:1556							ch = getch()*/
    _ch_27304 = _62getch();
    if (!IS_ATOM_INT(_ch_27304)) {
        _1 = (object)(DBL_PTR(_ch_27304)->dbl);
        DeRefDS(_ch_27304);
        _ch_27304 = _1;
    }

    /** scanner.e:1557						end while*/
    goto L15; // [499] 473
L17: 

    /** scanner.e:1558						yytext = ""*/
    RefDS(_5);
    DeRef(_yytext_27310);
    _yytext_27310 = _5;

    /** scanner.e:1559						if char_class[ch] = LETTER or ch = '_' then*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _15086 = (object)*(((s1_ptr)_2)->base + _ch_27304);
    _15087 = (_15086 == -2LL);
    _15086 = NOVALUE;
    if (_15087 != 0) {
        goto L18; // [523] 536
    }
    _15089 = (_ch_27304 == 95LL);
    if (_15089 == 0)
    {
        DeRef(_15089);
        _15089 = NOVALUE;
        goto L19; // [532] 589
    }
    else{
        DeRef(_15089);
        _15089 = NOVALUE;
    }
L18: 

    /** scanner.e:1560							yytext &= ch*/
    Append(&_yytext_27310, _yytext_27310, _ch_27304);

    /** scanner.e:1561							ch = getch()*/
    _ch_27304 = _62getch();
    if (!IS_ATOM_INT(_ch_27304)) {
        _1 = (object)(DBL_PTR(_ch_27304)->dbl);
        DeRefDS(_ch_27304);
        _ch_27304 = _1;
    }

    /** scanner.e:1562							while id_char[ch] = TRUE do*/
L1A: 
    _2 = (object)SEQ_PTR(_62id_char_25555);
    _15092 = (object)*(((s1_ptr)_2)->base + _ch_27304);
    if (_15092 != _13TRUE_452)
    goto L1B; // [562] 584

    /** scanner.e:1563								yytext &= ch*/
    Append(&_yytext_27310, _yytext_27310, _ch_27304);

    /** scanner.e:1564								ch = getch()*/
    _ch_27304 = _62getch();
    if (!IS_ATOM_INT(_ch_27304)) {
        _1 = (object)(DBL_PTR(_ch_27304)->dbl);
        DeRefDS(_ch_27304);
        _ch_27304 = _1;
    }

    /** scanner.e:1565							end while*/
    goto L1A; // [581] 554
L1B: 

    /** scanner.e:1566							ungetch()*/
    _62ungetch();
L19: 

    /** scanner.e:1569						if length(yytext) = 0 then*/
    if (IS_SEQUENCE(_yytext_27310)){
            _15096 = SEQ_PTR(_yytext_27310)->length;
    }
    else {
        _15096 = 1;
    }
    if (_15096 != 0LL)
    goto L1C; // [594] 608

    /** scanner.e:1570							CompileErr(AN_IDENTIFIER_IS_EXPECTED_HERE)*/
    RefDS(_21993);
    _50CompileErr(32LL, _21993, 0LL);
L1C: 

    /** scanner.e:1576					    if Parser_mode = PAM_RECORD then*/
    if (_36Parser_mode_21548 != 1LL)
    goto L1D; // [614] 775

    /** scanner.e:1577			                Recorded = append(Recorded,yytext)*/
    RefDS(_yytext_27310);
    Append(&_36Recorded_21549, _36Recorded_21549, _yytext_27310);

    /** scanner.e:1578			                Ns_recorded = append(Ns_recorded,namespaces)*/
    RefDS(_namespaces_27311);
    Append(&_36Ns_recorded_21550, _36Ns_recorded_21550, _namespaces_27311);

    /** scanner.e:1579			                Ns_recorded_sym &= tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_27314);
    _15101 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_SEQUENCE(_36Ns_recorded_sym_21552) && IS_ATOM(_15101)) {
        Ref(_15101);
        Append(&_36Ns_recorded_sym_21552, _36Ns_recorded_sym_21552, _15101);
    }
    else if (IS_ATOM(_36Ns_recorded_sym_21552) && IS_SEQUENCE(_15101)) {
    }
    else {
        Concat((object_ptr)&_36Ns_recorded_sym_21552, _36Ns_recorded_sym_21552, _15101);
    }
    _15101 = NOVALUE;

    /** scanner.e:1580			                prev_Nne = No_new_entry*/
    _prev_Nne_27306 = _54No_new_entry_47974;

    /** scanner.e:1581							No_new_entry = 1*/
    _54No_new_entry_47974 = 1LL;

    /** scanner.e:1582							tok = keyfind(yytext, SymTab[tok[T_SYM]][S_OBJ])*/
    _2 = (object)SEQ_PTR(_tok_27314);
    _15103 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_15103)){
        _15104 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_15103)->dbl));
    }
    else{
        _15104 = (object)*(((s1_ptr)_2)->base + _15103);
    }
    _2 = (object)SEQ_PTR(_15104);
    _15105 = (object)*(((s1_ptr)_2)->base + 1LL);
    _15104 = NOVALUE;
    RefDS(_yytext_27310);
    _31715 = _54hashfn(_yytext_27310);
    RefDS(_yytext_27310);
    Ref(_15105);
    _0 = _tok_27314;
    _tok_27314 = _54keyfind(_yytext_27310, _15105, _36current_file_no_21439, 0LL, _31715);
    DeRef(_0);
    _15105 = NOVALUE;
    _31715 = NOVALUE;

    /** scanner.e:1583							if tok[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_tok_27314);
    _15107 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _15107, 509LL)){
        _15107 = NOVALUE;
        goto L1E; // [714] 731
    }
    _15107 = NOVALUE;

    /** scanner.e:1584								Recorded_sym &= 0 -- must resolve on call site*/
    Append(&_36Recorded_sym_21551, _36Recorded_sym_21551, 0LL);
    goto L1F; // [728] 748
L1E: 

    /** scanner.e:1586								Recorded_sym &= tok[T_SYM] -- fallback when symbol is undefined on call site*/
    _2 = (object)SEQ_PTR(_tok_27314);
    _15110 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_SEQUENCE(_36Recorded_sym_21551) && IS_ATOM(_15110)) {
        Ref(_15110);
        Append(&_36Recorded_sym_21551, _36Recorded_sym_21551, _15110);
    }
    else if (IS_ATOM(_36Recorded_sym_21551) && IS_SEQUENCE(_15110)) {
    }
    else {
        Concat((object_ptr)&_36Recorded_sym_21551, _36Recorded_sym_21551, _15110);
    }
    _15110 = NOVALUE;
L1F: 

    /** scanner.e:1588			                No_new_entry = prev_Nne*/
    _54No_new_entry_47974 = _prev_Nne_27306;

    /** scanner.e:1589			                return {RECORDED,length(Recorded)}*/
    if (IS_SEQUENCE(_36Recorded_21549)){
            _15112 = SEQ_PTR(_36Recorded_21549)->length;
    }
    else {
        _15112 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 508LL;
    ((intptr_t *)_2)[2] = _15112;
    _15113 = MAKE_SEQ(_1);
    _15112 = NOVALUE;
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    _15092 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15113;
    goto L20; // [772] 917
L1D: 

    /** scanner.e:1591							tok = keyfind(yytext, SymTab[tok[T_SYM]][S_OBJ])*/
    _2 = (object)SEQ_PTR(_tok_27314);
    _15114 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_15114)){
        _15115 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_15114)->dbl));
    }
    else{
        _15115 = (object)*(((s1_ptr)_2)->base + _15114);
    }
    _2 = (object)SEQ_PTR(_15115);
    _15116 = (object)*(((s1_ptr)_2)->base + 1LL);
    _15115 = NOVALUE;
    RefDS(_yytext_27310);
    _31714 = _54hashfn(_yytext_27310);
    RefDS(_yytext_27310);
    Ref(_15116);
    _0 = _tok_27314;
    _tok_27314 = _54keyfind(_yytext_27310, _15116, _36current_file_no_21439, 0LL, _31714);
    DeRef(_0);
    _15116 = NOVALUE;
    _31714 = NOVALUE;

    /** scanner.e:1593							if tok[T_ID] = VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_27314);
    _15118 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _15118, -100LL)){
        _15118 = NOVALUE;
        goto L21; // [819] 836
    }
    _15118 = NOVALUE;

    /** scanner.e:1594								tok[T_ID] = QUALIFIED_VARIABLE*/
    _2 = (object)SEQ_PTR(_tok_27314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_27314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 512LL;
    DeRef(_1);
    goto L22; // [833] 916
L21: 

    /** scanner.e:1595							elsif tok[T_ID] = FUNC then*/
    _2 = (object)SEQ_PTR(_tok_27314);
    _15120 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _15120, 501LL)){
        _15120 = NOVALUE;
        goto L23; // [846] 863
    }
    _15120 = NOVALUE;

    /** scanner.e:1596								tok[T_ID] = QUALIFIED_FUNC*/
    _2 = (object)SEQ_PTR(_tok_27314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_27314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 520LL;
    DeRef(_1);
    goto L22; // [860] 916
L23: 

    /** scanner.e:1597							elsif tok[T_ID] = PROC then*/
    _2 = (object)SEQ_PTR(_tok_27314);
    _15122 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _15122, 27LL)){
        _15122 = NOVALUE;
        goto L24; // [873] 890
    }
    _15122 = NOVALUE;

    /** scanner.e:1598								tok[T_ID] = QUALIFIED_PROC*/
    _2 = (object)SEQ_PTR(_tok_27314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_27314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 521LL;
    DeRef(_1);
    goto L22; // [887] 916
L24: 

    /** scanner.e:1599							elsif tok[T_ID] = TYPE then*/
    _2 = (object)SEQ_PTR(_tok_27314);
    _15124 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _15124, 504LL)){
        _15124 = NOVALUE;
        goto L25; // [900] 915
    }
    _15124 = NOVALUE;

    /** scanner.e:1600								tok[T_ID] = QUALIFIED_TYPE*/
    _2 = (object)SEQ_PTR(_tok_27314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_27314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 522LL;
    DeRef(_1);
L25: 
L22: 
L20: 

    /** scanner.e:1605						if atom( tok[T_SYM] ) and  SymTab[tok[T_SYM]][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_tok_27314);
    _15126 = (object)*(((s1_ptr)_2)->base + 2LL);
    _15127 = IS_ATOM(_15126);
    _15126 = NOVALUE;
    if (_15127 == 0) {
        goto L26; // [928] 1271
    }
    _2 = (object)SEQ_PTR(_tok_27314);
    _15129 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_15129)){
        _15130 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_15129)->dbl));
    }
    else{
        _15130 = (object)*(((s1_ptr)_2)->base + _15129);
    }
    _2 = (object)SEQ_PTR(_15130);
    _15131 = (object)*(((s1_ptr)_2)->base + 4LL);
    _15130 = NOVALUE;
    if (IS_ATOM_INT(_15131)) {
        _15132 = (_15131 != 9LL);
    }
    else {
        _15132 = binary_op(NOTEQ, _15131, 9LL);
    }
    _15131 = NOVALUE;
    if (_15132 == 0) {
        DeRef(_15132);
        _15132 = NOVALUE;
        goto L26; // [957] 1271
    }
    else {
        if (!IS_ATOM_INT(_15132) && DBL_PTR(_15132)->dbl == 0.0){
            DeRef(_15132);
            _15132 = NOVALUE;
            goto L26; // [957] 1271
        }
        DeRef(_15132);
        _15132 = NOVALUE;
    }
    DeRef(_15132);
    _15132 = NOVALUE;

    /** scanner.e:1606							set_qualified_fwd( -1 )*/

    /** scanner.e:104		qualified_fwd = fwd*/
    _62qualified_fwd_25579 = -1LL;

    /** scanner.e:105	end procedure*/
    goto L26; // [969] 1271
    goto L26; // [973] 1271
L13: 

    /** scanner.e:1610						ungetch()*/
    _62ungetch();

    /** scanner.e:1611					    if Parser_mode = PAM_RECORD then*/
    if (_36Parser_mode_21548 != 1LL)
    goto L26; // [986] 1271

    /** scanner.e:1612			                Ns_recorded &= 0*/
    Append(&_36Ns_recorded_21550, _36Ns_recorded_21550, 0LL);

    /** scanner.e:1613			                Ns_recorded_sym &= 0*/
    Append(&_36Ns_recorded_sym_21552, _36Ns_recorded_sym_21552, 0LL);

    /** scanner.e:1614			                Recorded = append(Recorded,yytext)*/
    RefDS(_yytext_27310);
    Append(&_36Recorded_21549, _36Recorded_21549, _yytext_27310);

    /** scanner.e:1615			                prev_Nne = No_new_entry*/
    _prev_Nne_27306 = _54No_new_entry_47974;

    /** scanner.e:1616							No_new_entry = 1*/
    _54No_new_entry_47974 = 1LL;

    /** scanner.e:1617							tok = keyfind(yytext, -1)*/
    RefDS(_yytext_27310);
    _31713 = _54hashfn(_yytext_27310);
    RefDS(_yytext_27310);
    _0 = _tok_27314;
    _tok_27314 = _54keyfind(_yytext_27310, -1LL, _36current_file_no_21439, 0LL, _31713);
    DeRef(_0);
    _31713 = NOVALUE;

    /** scanner.e:1618							if tok[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_tok_27314);
    _15138 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _15138, 509LL)){
        _15138 = NOVALUE;
        goto L27; // [1062] 1079
    }
    _15138 = NOVALUE;

    /** scanner.e:1619								Recorded_sym &= 0 -- must resolve on call site*/
    Append(&_36Recorded_sym_21551, _36Recorded_sym_21551, 0LL);
    goto L28; // [1076] 1096
L27: 

    /** scanner.e:1621								Recorded_sym &= tok[T_SYM] -- fallback when symbol is undefined on call site*/
    _2 = (object)SEQ_PTR(_tok_27314);
    _15141 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_SEQUENCE(_36Recorded_sym_21551) && IS_ATOM(_15141)) {
        Ref(_15141);
        Append(&_36Recorded_sym_21551, _36Recorded_sym_21551, _15141);
    }
    else if (IS_ATOM(_36Recorded_sym_21551) && IS_SEQUENCE(_15141)) {
    }
    else {
        Concat((object_ptr)&_36Recorded_sym_21551, _36Recorded_sym_21551, _15141);
    }
    _15141 = NOVALUE;
L28: 

    /** scanner.e:1623			                No_new_entry = prev_Nne*/
    _54No_new_entry_47974 = _prev_Nne_27306;

    /** scanner.e:1624			                tok = {RECORDED,length(Recorded)}*/
    if (IS_SEQUENCE(_36Recorded_21549)){
            _15143 = SEQ_PTR(_36Recorded_21549)->length;
    }
    else {
        _15143 = 1;
    }
    DeRef(_tok_27314);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 508LL;
    ((intptr_t *)_2)[2] = _15143;
    _tok_27314 = MAKE_SEQ(_1);
    _15143 = NOVALUE;
    goto L26; // [1118] 1271
L12: 

    /** scanner.e:1628					set_qualified_fwd( -1 )*/

    /** scanner.e:104		qualified_fwd = fwd*/
    _62qualified_fwd_25579 = -1LL;

    /** scanner.e:105	end procedure*/
    goto L29; // [1130] 1133
L29: 

    /** scanner.e:1629				    if Parser_mode = PAM_RECORD then*/
    if (_36Parser_mode_21548 != 1LL)
    goto L2A; // [1139] 1270

    /** scanner.e:1630		                Ns_recorded_sym &= 0*/
    Append(&_36Ns_recorded_sym_21552, _36Ns_recorded_sym_21552, 0LL);

    /** scanner.e:1631							Recorded = append(Recorded, yytext)*/
    RefDS(_yytext_27310);
    Append(&_36Recorded_21549, _36Recorded_21549, _yytext_27310);

    /** scanner.e:1632			                Ns_recorded &= 0*/
    Append(&_36Ns_recorded_21550, _36Ns_recorded_21550, 0LL);

    /** scanner.e:1633			                prev_Nne = No_new_entry*/
    _prev_Nne_27306 = _54No_new_entry_47974;

    /** scanner.e:1634							No_new_entry = 1*/
    _54No_new_entry_47974 = 1LL;

    /** scanner.e:1635							tok = keyfind(yytext, -1)*/
    RefDS(_yytext_27310);
    _31712 = _54hashfn(_yytext_27310);
    RefDS(_yytext_27310);
    _0 = _tok_27314;
    _tok_27314 = _54keyfind(_yytext_27310, -1LL, _36current_file_no_21439, 0LL, _31712);
    DeRef(_0);
    _31712 = NOVALUE;

    /** scanner.e:1636							if tok[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_tok_27314);
    _15150 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _15150, 509LL)){
        _15150 = NOVALUE;
        goto L2B; // [1215] 1232
    }
    _15150 = NOVALUE;

    /** scanner.e:1637								Recorded_sym &= 0 -- must resolve on call site*/
    Append(&_36Recorded_sym_21551, _36Recorded_sym_21551, 0LL);
    goto L2C; // [1229] 1249
L2B: 

    /** scanner.e:1639								Recorded_sym &= tok[T_SYM] -- fallback when symbol is undefined on call site*/
    _2 = (object)SEQ_PTR(_tok_27314);
    _15153 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_SEQUENCE(_36Recorded_sym_21551) && IS_ATOM(_15153)) {
        Ref(_15153);
        Append(&_36Recorded_sym_21551, _36Recorded_sym_21551, _15153);
    }
    else if (IS_ATOM(_36Recorded_sym_21551) && IS_SEQUENCE(_15153)) {
    }
    else {
        Concat((object_ptr)&_36Recorded_sym_21551, _36Recorded_sym_21551, _15153);
    }
    _15153 = NOVALUE;
L2C: 

    /** scanner.e:1641			                No_new_entry = prev_Nne*/
    _54No_new_entry_47974 = _prev_Nne_27306;

    /** scanner.e:1642		                tok = {RECORDED, length(Recorded)}*/
    if (IS_SEQUENCE(_36Recorded_21549)){
            _15155 = SEQ_PTR(_36Recorded_21549)->length;
    }
    else {
        _15155 = 1;
    }
    DeRef(_tok_27314);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 508LL;
    ((intptr_t *)_2)[2] = _15155;
    _tok_27314 = MAKE_SEQ(_1);
    _15155 = NOVALUE;
L2A: 
L26: 

    /** scanner.e:1646				return tok*/
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_name_27317);
    _15092 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _tok_27314;
    goto L1; // [1281] 10
L7: 

    /** scanner.e:1648			elsif class < ILLEGAL_CHAR then*/
    if (_class_27316 >= -20LL)
    goto L2D; // [1288] 1305

    /** scanner.e:1649				return {class, 0}  -- brackets, punctuation, eof, illegal char etc.*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _class_27316;
    ((intptr_t *)_2)[2] = 0LL;
    _15158 = MAKE_SEQ(_1);
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    _15092 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15158;
    goto L1; // [1302] 10
L2D: 

    /** scanner.e:1651			elsif class = ILLEGAL_CHAR then*/
    if (_class_27316 != -20LL)
    goto L2E; // [1309] 1325

    /** scanner.e:1652				CompileErr(ILLEGAL_CHARACTER_IN_SOURCE)*/
    RefDS(_21993);
    _50CompileErr(101LL, _21993, 0LL);
    goto L1; // [1322] 10
L2E: 

    /** scanner.e:1654			elsif class = NEWLINE then*/
    if (_class_27316 != -6LL)
    goto L2F; // [1329] 1355

    /** scanner.e:1655				if start_include then*/
    if (_62start_include_25547 == 0)
    {
        goto L30; // [1337] 1347
    }
    else{
    }

    /** scanner.e:1656					IncludePush()*/
    _62IncludePush();
    goto L1; // [1344] 10
L30: 

    /** scanner.e:1658					read_line()*/
    _62read_line();
    goto L1; // [1352] 10
L2F: 

    /** scanner.e:1662			elsif class = EQUALS then*/
    if (_class_27316 != 3LL)
    goto L31; // [1359] 1376

    /** scanner.e:1663				return {class, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _class_27316;
    ((intptr_t *)_2)[2] = 0LL;
    _15162 = MAKE_SEQ(_1);
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    _15092 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15162;
    goto L1; // [1373] 10
L31: 

    /** scanner.e:1665			elsif class = DOT or class = DIGIT then*/
    _15163 = (_class_27316 == -3LL);
    if (_15163 != 0) {
        goto L32; // [1384] 1399
    }
    _15165 = (_class_27316 == -7LL);
    if (_15165 == 0)
    {
        DeRef(_15165);
        _15165 = NOVALUE;
        goto L33; // [1395] 2195
    }
    else{
        DeRef(_15165);
        _15165 = NOVALUE;
    }
L32: 

    /** scanner.e:1666				integer basetype*/

    /** scanner.e:1667				if class = DOT then*/
    if (_class_27316 != -3LL)
    goto L34; // [1405] 1439

    /** scanner.e:1668					if getch() = '.' then*/
    _15167 = _62getch();
    if (binary_op_a(NOTEQ, _15167, 46LL)){
        DeRef(_15167);
        _15167 = NOVALUE;
        goto L35; // [1414] 1433
    }
    DeRef(_15167);
    _15167 = NOVALUE;

    /** scanner.e:1669						return {SLICE, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 513LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15169 = MAKE_SEQ(_1);
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    _15092 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15169;
    goto L36; // [1430] 1438
L35: 

    /** scanner.e:1671						ungetch()*/
    _62ungetch();
L36: 
L34: 

    /** scanner.e:1675				yytext = {ch}*/
    _0 = _yytext_27310;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _ch_27304;
    _yytext_27310 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scanner.e:1676				is_int = (ch != '.')*/
    _is_int_27315 = (_ch_27304 != 46LL);

    /** scanner.e:1677				basetype = -1 -- default is decimal*/
    _basetype_27612 = -1LL;

    /** scanner.e:1678				while 1 with entry do*/
    goto L37; // [1458] 1651
L38: 

    /** scanner.e:1679					if char_class[ch] = DIGIT then*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _15172 = (object)*(((s1_ptr)_2)->base + _ch_27304);
    if (_15172 != -7LL)
    goto L39; // [1471] 1484

    /** scanner.e:1680						yytext &= ch*/
    Append(&_yytext_27310, _yytext_27310, _ch_27304);
    goto L3A; // [1481] 1648
L39: 

    /** scanner.e:1682					elsif equal(yytext, "0") then*/
    if (_yytext_27310 == _14828)
    _15175 = 1;
    else if (IS_ATOM_INT(_yytext_27310) && IS_ATOM_INT(_14828))
    _15175 = 0;
    else
    _15175 = (compare(_yytext_27310, _14828) == 0);
    if (_15175 == 0)
    {
        _15175 = NOVALUE;
        goto L3B; // [1490] 1587
    }
    else{
        _15175 = NOVALUE;
    }

    /** scanner.e:1683						basetype = find(ch, nbasecode)*/
    _basetype_27612 = find_from(_ch_27304, _62nbasecode_27107, 1LL);

    /** scanner.e:1684						if basetype > length(nbase) then*/
    if (IS_SEQUENCE(_62nbase_27106)){
            _15177 = SEQ_PTR(_62nbase_27106)->length;
    }
    else {
        _15177 = 1;
    }
    if (_basetype_27612 <= _15177)
    goto L3C; // [1505] 1519

    /** scanner.e:1685							basetype -= length(nbase)*/
    if (IS_SEQUENCE(_62nbase_27106)){
            _15179 = SEQ_PTR(_62nbase_27106)->length;
    }
    else {
        _15179 = 1;
    }
    _basetype_27612 = _basetype_27612 - _15179;
    _15179 = NOVALUE;
L3C: 

    /** scanner.e:1688						if basetype = 0 then*/
    if (_basetype_27612 != 0LL)
    goto L3D; // [1521] 1578

    /** scanner.e:1689							if char_class[ch] = LETTER then*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _15182 = (object)*(((s1_ptr)_2)->base + _ch_27304);
    if (_15182 != -2LL)
    goto L3E; // [1535] 1568

    /** scanner.e:1690								if ch != 'e' and ch != 'E' then*/
    _15184 = (_ch_27304 != 101LL);
    if (_15184 == 0) {
        goto L3F; // [1545] 1567
    }
    _15186 = (_ch_27304 != 69LL);
    if (_15186 == 0)
    {
        DeRef(_15186);
        _15186 = NOVALUE;
        goto L3F; // [1554] 1567
    }
    else{
        DeRef(_15186);
        _15186 = NOVALUE;
    }

    /** scanner.e:1691									CompileErr(INVALID_NUMBER_BASE_SPECIFIER_1, ch)*/
    _50CompileErr(105LL, _ch_27304, 0LL);
L3F: 
L3E: 

    /** scanner.e:1695							basetype = -1 -- decimal*/
    _basetype_27612 = -1LL;

    /** scanner.e:1696							exit*/
    goto L40; // [1575] 1663
L3D: 

    /** scanner.e:1698						yytext &= '0'*/
    Append(&_yytext_27310, _yytext_27310, 48LL);
    goto L3A; // [1584] 1648
L3B: 

    /** scanner.e:1700					elsif basetype = 4 then -- hexadecimal*/
    if (_basetype_27612 != 4LL)
    goto L40; // [1589] 1663

    /** scanner.e:1701						integer hdigit*/

    /** scanner.e:1702						hdigit = find(ch, "ABCDEFabcdef")*/
    _hdigit_27653 = find_from(_ch_27304, _15189, 1LL);

    /** scanner.e:1703						if hdigit = 0 then*/
    if (_hdigit_27653 != 0LL)
    goto L41; // [1604] 1615

    /** scanner.e:1704							exit*/
    goto L40; // [1612] 1663
L41: 

    /** scanner.e:1706						if hdigit > 6 then*/
    if (_hdigit_27653 <= 6LL)
    goto L42; // [1617] 1628

    /** scanner.e:1707							hdigit -= 6*/
    _hdigit_27653 = _hdigit_27653 - 6LL;
L42: 

    /** scanner.e:1709						yytext &= hexasc[hdigit]*/
    _2 = (object)SEQ_PTR(_62hexasc_27109);
    _15194 = (object)*(((s1_ptr)_2)->base + _hdigit_27653);
    if (IS_SEQUENCE(_yytext_27310) && IS_ATOM(_15194)) {
        Ref(_15194);
        Append(&_yytext_27310, _yytext_27310, _15194);
    }
    else if (IS_ATOM(_yytext_27310) && IS_SEQUENCE(_15194)) {
    }
    else {
        Concat((object_ptr)&_yytext_27310, _yytext_27310, _15194);
    }
    _15194 = NOVALUE;
    goto L3A; // [1640] 1648

    /** scanner.e:1712						exit*/
    goto L40; // [1645] 1663
L3A: 

    /** scanner.e:1714				entry*/
L37: 

    /** scanner.e:1715					ch = getch()*/
    _ch_27304 = _62getch();
    if (!IS_ATOM_INT(_ch_27304)) {
        _1 = (object)(DBL_PTR(_ch_27304)->dbl);
        DeRefDS(_ch_27304);
        _ch_27304 = _1;
    }

    /** scanner.e:1716				end while*/
    goto L38; // [1660] 1461
L40: 

    /** scanner.e:1718				if ch = '.' then*/
    if (_ch_27304 != 46LL)
    goto L43; // [1665] 1804

    /** scanner.e:1719					ch = getch()*/
    _ch_27304 = _62getch();
    if (!IS_ATOM_INT(_ch_27304)) {
        _1 = (object)(DBL_PTR(_ch_27304)->dbl);
        DeRefDS(_ch_27304);
        _ch_27304 = _1;
    }

    /** scanner.e:1720					if ch = '.' then*/
    if (_ch_27304 != 46LL)
    goto L44; // [1678] 1689

    /** scanner.e:1722						ungetch()*/
    _62ungetch();
    goto L45; // [1686] 1803
L44: 

    /** scanner.e:1724						is_int = FALSE*/
    _is_int_27315 = _13FALSE_450;

    /** scanner.e:1725						if yytext[1] = '.' then*/
    _2 = (object)SEQ_PTR(_yytext_27310);
    _15200 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _15200, 46LL)){
        _15200 = NOVALUE;
        goto L46; // [1704] 1720
    }
    _15200 = NOVALUE;

    /** scanner.e:1726							CompileErr(ONLY_ONE_DECIMAL_POINT_ALLOWED)*/
    RefDS(_21993);
    _50CompileErr(124LL, _21993, 0LL);
    goto L47; // [1717] 1727
L46: 

    /** scanner.e:1728							yytext &= '.'*/
    Append(&_yytext_27310, _yytext_27310, 46LL);
L47: 

    /** scanner.e:1730						if char_class[ch] = DIGIT then*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _15203 = (object)*(((s1_ptr)_2)->base + _ch_27304);
    if (_15203 != -7LL)
    goto L48; // [1737] 1792

    /** scanner.e:1731							yytext &= ch*/
    Append(&_yytext_27310, _yytext_27310, _ch_27304);

    /** scanner.e:1732							ch = getch()*/
    _ch_27304 = _62getch();
    if (!IS_ATOM_INT(_ch_27304)) {
        _1 = (object)(DBL_PTR(_ch_27304)->dbl);
        DeRefDS(_ch_27304);
        _ch_27304 = _1;
    }

    /** scanner.e:1733							while char_class[ch] = DIGIT do*/
L49: 
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _15207 = (object)*(((s1_ptr)_2)->base + _ch_27304);
    if (_15207 != -7LL)
    goto L4A; // [1767] 1802

    /** scanner.e:1734								yytext &= ch*/
    Append(&_yytext_27310, _yytext_27310, _ch_27304);

    /** scanner.e:1735								ch = getch()*/
    _ch_27304 = _62getch();
    if (!IS_ATOM_INT(_ch_27304)) {
        _1 = (object)(DBL_PTR(_ch_27304)->dbl);
        DeRefDS(_ch_27304);
        _ch_27304 = _1;
    }

    /** scanner.e:1736							end while*/
    goto L49; // [1786] 1759
    goto L4A; // [1789] 1802
L48: 

    /** scanner.e:1738							CompileErr(FRACTIONAL_PART_OF_NUMBER_IS_MISSING)*/
    RefDS(_21993);
    _50CompileErr(94LL, _21993, 0LL);
L4A: 
L45: 
L43: 

    /** scanner.e:1743				if basetype = -1 and find(ch, "eE") then*/
    _15211 = (_basetype_27612 == -1LL);
    if (_15211 == 0) {
        goto L4B; // [1810] 1948
    }
    _15214 = find_from(_ch_27304, _15213, 1LL);
    if (_15214 == 0)
    {
        _15214 = NOVALUE;
        goto L4B; // [1820] 1948
    }
    else{
        _15214 = NOVALUE;
    }

    /** scanner.e:1744					is_int = FALSE*/
    _is_int_27315 = _13FALSE_450;

    /** scanner.e:1745					yytext &= ch*/
    Append(&_yytext_27310, _yytext_27310, _ch_27304);

    /** scanner.e:1746					ch = getch()*/
    _ch_27304 = _62getch();
    if (!IS_ATOM_INT(_ch_27304)) {
        _1 = (object)(DBL_PTR(_ch_27304)->dbl);
        DeRefDS(_ch_27304);
        _ch_27304 = _1;
    }

    /** scanner.e:1747					if ch = '-' or ch = '+' or char_class[ch] = DIGIT then*/
    _15217 = (_ch_27304 == 45LL);
    if (_15217 != 0) {
        _15218 = 1;
        goto L4C; // [1851] 1863
    }
    _15219 = (_ch_27304 == 43LL);
    _15218 = (_15219 != 0);
L4C: 
    if (_15218 != 0) {
        goto L4D; // [1863] 1884
    }
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _15221 = (object)*(((s1_ptr)_2)->base + _ch_27304);
    _15222 = (_15221 == -7LL);
    _15221 = NOVALUE;
    if (_15222 == 0)
    {
        DeRef(_15222);
        _15222 = NOVALUE;
        goto L4E; // [1880] 1893
    }
    else{
        DeRef(_15222);
        _15222 = NOVALUE;
    }
L4D: 

    /** scanner.e:1748						yytext &= ch*/
    Append(&_yytext_27310, _yytext_27310, _ch_27304);
    goto L4F; // [1890] 1903
L4E: 

    /** scanner.e:1750						CompileErr(EXPONENT_NOT_FORMED_CORRECTLY)*/
    RefDS(_21993);
    _50CompileErr(86LL, _21993, 0LL);
L4F: 

    /** scanner.e:1752					ch = getch()*/
    _ch_27304 = _62getch();
    if (!IS_ATOM_INT(_ch_27304)) {
        _1 = (object)(DBL_PTR(_ch_27304)->dbl);
        DeRefDS(_ch_27304);
        _ch_27304 = _1;
    }

    /** scanner.e:1753					while char_class[ch] = DIGIT do*/
L50: 
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _15225 = (object)*(((s1_ptr)_2)->base + _ch_27304);
    if (_15225 != -7LL)
    goto L51; // [1923] 1981

    /** scanner.e:1754						yytext &= ch*/
    Append(&_yytext_27310, _yytext_27310, _ch_27304);

    /** scanner.e:1755						ch = getch()*/
    _ch_27304 = _62getch();
    if (!IS_ATOM_INT(_ch_27304)) {
        _1 = (object)(DBL_PTR(_ch_27304)->dbl);
        DeRefDS(_ch_27304);
        _ch_27304 = _1;
    }

    /** scanner.e:1756					end while*/
    goto L50; // [1942] 1915
    goto L51; // [1945] 1981
L4B: 

    /** scanner.e:1757				elsif char_class[ch] = LETTER then*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _15229 = (object)*(((s1_ptr)_2)->base + _ch_27304);
    if (_15229 != -2LL)
    goto L52; // [1958] 1980

    /** scanner.e:1758					CompileErr(PUNCTUATION_MISSING_IN_BETWEEN_NUMBER_AND_1, {{ch}})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _ch_27304;
    _15231 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _15231;
    _15232 = MAKE_SEQ(_1);
    _15231 = NOVALUE;
    _50CompileErr(127LL, _15232, 0LL);
    _15232 = NOVALUE;
L52: 
L51: 

    /** scanner.e:1761				ungetch()*/
    _62ungetch();

    /** scanner.e:1763				while i != 0 with entry do*/
    goto L53; // [1987] 2006
L54: 
    if (binary_op_a(EQUALS, _i_27307, 0LL)){
        goto L55; // [1992] 2018
    }

    /** scanner.e:1764					yytext = remove( yytext, i )*/
    {
        s1_ptr assign_space = SEQ_PTR(_yytext_27310);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_i_27307)) ? _i_27307 : (object)(DBL_PTR(_i_27307)->dbl);
        int stop = (IS_ATOM_INT(_i_27307)) ? _i_27307 : (object)(DBL_PTR(_i_27307)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_yytext_27310), start, &_yytext_27310 );
            }
            else Tail(SEQ_PTR(_yytext_27310), stop+1, &_yytext_27310);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_yytext_27310), start, &_yytext_27310);
        }
        else {
            assign_slice_seq = &assign_space;
            _yytext_27310 = Remove_elements(start, stop, (SEQ_PTR(_yytext_27310)->ref == 1));
        }
    }

    /** scanner.e:1765				  entry*/
L53: 

    /** scanner.e:1766				    i = find('_', yytext)*/
    DeRef(_i_27307);
    _i_27307 = find_from(95LL, _yytext_27310, 1LL);

    /** scanner.e:1767				end while*/
    goto L54; // [2015] 1990
L55: 

    /** scanner.e:1769				if is_int then*/
    if (_is_int_27315 == 0)
    {
        goto L56; // [2020] 2092
    }
    else{
    }

    /** scanner.e:1770					if basetype = -1 then*/
    if (_basetype_27612 != -1LL)
    goto L57; // [2025] 2035

    /** scanner.e:1771						basetype = 3 -- decimal*/
    _basetype_27612 = 3LL;
L57: 

    /** scanner.e:1773					d = MakeInt(yytext, nbase[basetype])*/
    _2 = (object)SEQ_PTR(_62nbase_27106);
    _15237 = (object)*(((s1_ptr)_2)->base + _basetype_27612);
    RefDS(_yytext_27310);
    Ref(_15237);
    _0 = _d_27312;
    _d_27312 = _62MakeInt(_yytext_27310, _15237);
    DeRef(_0);
    _15237 = NOVALUE;

    /** scanner.e:1774					if is_integer(d) then*/
    Ref(_d_27312);
    _15239 = _36is_integer(_d_27312);
    if (_15239 == 0) {
        DeRef(_15239);
        _15239 = NOVALUE;
        goto L58; // [2052] 2074
    }
    else {
        if (!IS_ATOM_INT(_15239) && DBL_PTR(_15239)->dbl == 0.0){
            DeRef(_15239);
            _15239 = NOVALUE;
            goto L58; // [2052] 2074
        }
        DeRef(_15239);
        _15239 = NOVALUE;
    }
    DeRef(_15239);
    _15239 = NOVALUE;

    /** scanner.e:1775						return {ATOM, NewIntSym(d)}*/
    Ref(_d_27312);
    _15240 = _54NewIntSym(_d_27312);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502LL;
    ((intptr_t *)_2)[2] = _15240;
    _15241 = MAKE_SEQ(_1);
    _15240 = NOVALUE;
    DeRef(_i_27307);
    DeRefDS(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    _15203 = NOVALUE;
    _15092 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    _15207 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    _15182 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15229 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    DeRef(_15219);
    _15219 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15169);
    _15169 = NOVALUE;
    _15172 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    DeRef(_15211);
    _15211 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    DeRef(_15217);
    _15217 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15225 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15241;
    goto L59; // [2071] 2091
L58: 

    /** scanner.e:1777						return {ATOM, NewDoubleSym(d)}*/
    Ref(_d_27312);
    _15242 = _54NewDoubleSym(_d_27312);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502LL;
    ((intptr_t *)_2)[2] = _15242;
    _15243 = MAKE_SEQ(_1);
    _15242 = NOVALUE;
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    _15203 = NOVALUE;
    _15092 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    _15207 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    _15182 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15229 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    DeRef(_15219);
    _15219 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15169);
    _15169 = NOVALUE;
    _15172 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    DeRef(_15211);
    _15211 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    DeRef(_15217);
    _15217 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15225 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15243;
L59: 
L56: 

    /** scanner.e:1782				if basetype != -1 then*/
    if (_basetype_27612 == -1LL)
    goto L5A; // [2094] 2112

    /** scanner.e:1783					CompileErr(ONLY_INTEGER_LITERALS_CAN_USE_THE_01_FORMAT, nbasecode[basetype])*/
    _2 = (object)SEQ_PTR(_62nbasecode_27107);
    _15245 = (object)*(((s1_ptr)_2)->base + _basetype_27612);
    Ref(_15245);
    _50CompileErr(125LL, _15245, 0LL);
    _15245 = NOVALUE;
L5A: 

    /** scanner.e:1787				d = my_sscanf(yytext)*/
    RefDS(_yytext_27310);
    _0 = _d_27312;
    _d_27312 = _62my_sscanf(_yytext_27310);
    DeRef(_0);

    /** scanner.e:1788				if sequence(d) then*/
    _15247 = IS_SEQUENCE(_d_27312);
    if (_15247 == 0)
    {
        _15247 = NOVALUE;
        goto L5B; // [2123] 2138
    }
    else{
        _15247 = NOVALUE;
    }

    /** scanner.e:1789					CompileErr(NUMBER_NOT_FORMED_CORRECTLY)*/
    RefDS(_21993);
    _50CompileErr(121LL, _21993, 0LL);
    goto L5C; // [2135] 2190
L5B: 

    /** scanner.e:1790				elsif is_int and d <= TMAXINT_DBL then*/
    if (_is_int_27315 == 0) {
        goto L5D; // [2140] 2173
    }
    if (IS_ATOM_INT(_d_27312) && IS_ATOM_INT(_36TMAXINT_DBL_21271)) {
        _15249 = (_d_27312 <= _36TMAXINT_DBL_21271);
    }
    else {
        _15249 = binary_op(LESSEQ, _d_27312, _36TMAXINT_DBL_21271);
    }
    if (_15249 == 0) {
        DeRef(_15249);
        _15249 = NOVALUE;
        goto L5D; // [2151] 2173
    }
    else {
        if (!IS_ATOM_INT(_15249) && DBL_PTR(_15249)->dbl == 0.0){
            DeRef(_15249);
            _15249 = NOVALUE;
            goto L5D; // [2151] 2173
        }
        DeRef(_15249);
        _15249 = NOVALUE;
    }
    DeRef(_15249);
    _15249 = NOVALUE;

    /** scanner.e:1791					return {ATOM, NewIntSym(d)}  -- 1 to 1.07 billion*/
    Ref(_d_27312);
    _15250 = _54NewIntSym(_d_27312);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502LL;
    ((intptr_t *)_2)[2] = _15250;
    _15251 = MAKE_SEQ(_1);
    _15250 = NOVALUE;
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    _15203 = NOVALUE;
    _15092 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    _15207 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    _15182 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15229 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    DeRef(_15219);
    _15219 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15169);
    _15169 = NOVALUE;
    _15172 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    DeRef(_15211);
    _15211 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    DeRef(_15217);
    _15217 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15225 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15251;
    goto L5C; // [2170] 2190
L5D: 

    /** scanner.e:1793					return {ATOM, NewDoubleSym(d)}*/
    Ref(_d_27312);
    _15252 = _54NewDoubleSym(_d_27312);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502LL;
    ((intptr_t *)_2)[2] = _15252;
    _15253 = MAKE_SEQ(_1);
    _15252 = NOVALUE;
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    _15203 = NOVALUE;
    _15092 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    _15207 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    _15182 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15229 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    DeRef(_15219);
    _15219 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15169);
    _15169 = NOVALUE;
    _15172 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    DeRef(_15211);
    _15211 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    DeRef(_15217);
    _15217 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15225 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15253;
L5C: 
    goto L1; // [2192] 10
L33: 

    /** scanner.e:1797			elsif class = MINUS then*/
    if (_class_27316 != 10LL)
    goto L5E; // [2199] 2285

    /** scanner.e:1798				ch = getch()*/
    _ch_27304 = _62getch();
    if (!IS_ATOM_INT(_ch_27304)) {
        _1 = (object)(DBL_PTR(_ch_27304)->dbl);
        DeRefDS(_ch_27304);
        _ch_27304 = _1;
    }

    /** scanner.e:1799				if ch = '-' then*/
    if (_ch_27304 != 45LL)
    goto L5F; // [2212] 2238

    /** scanner.e:1801					if start_include then*/
    if (_62start_include_25547 == 0)
    {
        goto L60; // [2220] 2230
    }
    else{
    }

    /** scanner.e:1802						IncludePush()*/
    _62IncludePush();
    goto L1; // [2227] 10
L60: 

    /** scanner.e:1804						read_line()*/
    _62read_line();
    goto L1; // [2235] 10
L5F: 

    /** scanner.e:1806				elsif ch = '=' then*/
    if (_ch_27304 != 61LL)
    goto L61; // [2240] 2259

    /** scanner.e:1807					return {MINUS_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 516LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15258 = MAKE_SEQ(_1);
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    _15203 = NOVALUE;
    _15092 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    _15207 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    _15182 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15229 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    DeRef(_15219);
    _15219 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15169);
    _15169 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    _15172 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    DeRef(_15211);
    _15211 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    DeRef(_15217);
    _15217 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15225 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15258;
    goto L1; // [2256] 10
L61: 

    /** scanner.e:1809					bp -= 1*/
    _50bp_49238 = _50bp_49238 - 1LL;

    /** scanner.e:1810					return {MINUS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 10LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15260 = MAKE_SEQ(_1);
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    _15203 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15092 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    _15207 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    _15182 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15229 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    DeRef(_15219);
    _15219 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15169);
    _15169 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    _15172 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    DeRef(_15211);
    _15211 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    DeRef(_15217);
    _15217 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15225 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15260;
    goto L1; // [2282] 10
L5E: 

    /** scanner.e:1812			elsif class = DOUBLE_QUOTE then*/
    if (_class_27316 != -4LL)
    goto L62; // [2289] 2487

    /** scanner.e:1813				integer fch*/

    /** scanner.e:1814				ch = getch()*/
    _ch_27304 = _62getch();
    if (!IS_ATOM_INT(_ch_27304)) {
        _1 = (object)(DBL_PTR(_ch_27304)->dbl);
        DeRefDS(_ch_27304);
        _ch_27304 = _1;
    }

    /** scanner.e:1815				if ch = '"' then*/
    if (_ch_27304 != 34LL)
    goto L63; // [2304] 2340

    /** scanner.e:1816					fch = getch()*/
    _fch_27793 = _62getch();
    if (!IS_ATOM_INT(_fch_27793)) {
        _1 = (object)(DBL_PTR(_fch_27793)->dbl);
        DeRefDS(_fch_27793);
        _fch_27793 = _1;
    }

    /** scanner.e:1817					if fch = '"' then*/
    if (_fch_27793 != 34LL)
    goto L64; // [2317] 2334

    /** scanner.e:1819						return ExtendedString( fch )*/
    _15266 = _62ExtendedString(_fch_27793);
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    _15203 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15092 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    _15207 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    _15182 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15229 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    DeRef(_15219);
    _15219 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15169);
    _15169 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    _15172 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    DeRef(_15211);
    _15211 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    DeRef(_15217);
    _15217 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15225 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15266;
    goto L65; // [2331] 2339
L64: 

    /** scanner.e:1821						ungetch()*/
    _62ungetch();
L65: 
L63: 

    /** scanner.e:1824				yytext = ""*/
    RefDS(_5);
    DeRef(_yytext_27310);
    _yytext_27310 = _5;

    /** scanner.e:1825				while ch != '\n' and ch != '\r' do -- can't be EOF*/
L66: 
    _15267 = (_ch_27304 != 10LL);
    if (_15267 == 0) {
        goto L67; // [2356] 2437
    }
    _15269 = (_ch_27304 != 13LL);
    if (_15269 == 0)
    {
        DeRef(_15269);
        _15269 = NOVALUE;
        goto L67; // [2365] 2437
    }
    else{
        DeRef(_15269);
        _15269 = NOVALUE;
    }

    /** scanner.e:1826					if ch = '"' then*/
    if (_ch_27304 != 34LL)
    goto L68; // [2370] 2381

    /** scanner.e:1827						exit*/
    goto L67; // [2376] 2437
    goto L69; // [2378] 2425
L68: 

    /** scanner.e:1828					elsif ch = '\\' then*/
    if (_ch_27304 != 92LL)
    goto L6A; // [2383] 2400

    /** scanner.e:1829						yytext &= EscapeChar('"')*/
    _15272 = _62EscapeChar(34LL);
    if (IS_SEQUENCE(_yytext_27310) && IS_ATOM(_15272)) {
        Ref(_15272);
        Append(&_yytext_27310, _yytext_27310, _15272);
    }
    else if (IS_ATOM(_yytext_27310) && IS_SEQUENCE(_15272)) {
    }
    else {
        Concat((object_ptr)&_yytext_27310, _yytext_27310, _15272);
    }
    DeRef(_15272);
    _15272 = NOVALUE;
    goto L69; // [2397] 2425
L6A: 

    /** scanner.e:1830					elsif ch = '\t' then*/
    if (_ch_27304 != 9LL)
    goto L6B; // [2402] 2418

    /** scanner.e:1831						CompileErr(MSG_TAB_CHARACTER_FOUND_IN_STRING__USE_T_INSTEAD)*/
    RefDS(_21993);
    _50CompileErr(145LL, _21993, 0LL);
    goto L69; // [2415] 2425
L6B: 

    /** scanner.e:1833						yytext &= ch*/
    Append(&_yytext_27310, _yytext_27310, _ch_27304);
L69: 

    /** scanner.e:1835					ch = getch()*/
    _ch_27304 = _62getch();
    if (!IS_ATOM_INT(_ch_27304)) {
        _1 = (object)(DBL_PTR(_ch_27304)->dbl);
        DeRefDS(_ch_27304);
        _ch_27304 = _1;
    }

    /** scanner.e:1836				end while*/
    goto L66; // [2434] 2352
L67: 

    /** scanner.e:1837				if ch = '\n' or ch = '\r' then*/
    _15277 = (_ch_27304 == 10LL);
    if (_15277 != 0) {
        goto L6C; // [2443] 2456
    }
    _15279 = (_ch_27304 == 13LL);
    if (_15279 == 0)
    {
        DeRef(_15279);
        _15279 = NOVALUE;
        goto L6D; // [2452] 2466
    }
    else{
        DeRef(_15279);
        _15279 = NOVALUE;
    }
L6C: 

    /** scanner.e:1838					CompileErr(END_OF_LINE_REACHED_WITH_NO_CLOSING)*/
    RefDS(_21993);
    _50CompileErr(67LL, _21993, 0LL);
L6D: 

    /** scanner.e:1840				return {STRING, NewStringSym(yytext)}*/
    RefDS(_yytext_27310);
    _15280 = _54NewStringSym(_yytext_27310);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 503LL;
    ((intptr_t *)_2)[2] = _15280;
    _15281 = MAKE_SEQ(_1);
    _15280 = NOVALUE;
    DeRef(_i_27307);
    DeRefDS(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    _15203 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15092 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    _15207 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    _15182 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15229 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    DeRef(_15219);
    _15219 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15169);
    _15169 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    _15172 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    DeRef(_15211);
    _15211 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    DeRef(_15217);
    _15217 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15225 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15266);
    _15266 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15281;
    goto L1; // [2484] 10
L62: 

    /** scanner.e:1842			elsif class = PLUS then*/
    if (_class_27316 != 11LL)
    goto L6E; // [2491] 2543

    /** scanner.e:1843				ch = getch()*/
    _ch_27304 = _62getch();
    if (!IS_ATOM_INT(_ch_27304)) {
        _1 = (object)(DBL_PTR(_ch_27304)->dbl);
        DeRefDS(_ch_27304);
        _ch_27304 = _1;
    }

    /** scanner.e:1844				if ch = '=' then*/
    if (_ch_27304 != 61LL)
    goto L6F; // [2504] 2523

    /** scanner.e:1845					return {PLUS_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 515LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15285 = MAKE_SEQ(_1);
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    _15203 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15092 = NOVALUE;
    DeRef(_15281);
    _15281 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    _15207 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    _15182 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15229 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    DeRef(_15219);
    _15219 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15169);
    _15169 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    _15172 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    DeRef(_15211);
    _15211 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    DeRef(_15217);
    _15217 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15225 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15266);
    _15266 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15285;
    goto L1; // [2520] 10
L6F: 

    /** scanner.e:1847					ungetch()*/
    _62ungetch();

    /** scanner.e:1848					return {PLUS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 11LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15286 = MAKE_SEQ(_1);
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    _15203 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15092 = NOVALUE;
    DeRef(_15281);
    _15281 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    DeRef(_15285);
    _15285 = NOVALUE;
    _15207 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    _15182 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15229 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    DeRef(_15219);
    _15219 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15169);
    _15169 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    _15172 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    DeRef(_15211);
    _15211 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    DeRef(_15217);
    _15217 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15225 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15266);
    _15266 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15286;
    goto L1; // [2540] 10
L6E: 

    /** scanner.e:1851			elsif class = res:CONCAT then*/
    if (_class_27316 != 15LL)
    goto L70; // [2545] 2595

    /** scanner.e:1852				ch = getch()*/
    _ch_27304 = _62getch();
    if (!IS_ATOM_INT(_ch_27304)) {
        _1 = (object)(DBL_PTR(_ch_27304)->dbl);
        DeRefDS(_ch_27304);
        _ch_27304 = _1;
    }

    /** scanner.e:1853				if ch = '=' then*/
    if (_ch_27304 != 61LL)
    goto L71; // [2558] 2577

    /** scanner.e:1854					return {CONCAT_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 519LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15290 = MAKE_SEQ(_1);
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    _15203 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15092 = NOVALUE;
    DeRef(_15281);
    _15281 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    DeRef(_15285);
    _15285 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    _15207 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    _15182 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15229 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    DeRef(_15219);
    _15219 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15169);
    _15169 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    _15172 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    DeRef(_15211);
    _15211 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    DeRef(_15217);
    _15217 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15225 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15266);
    _15266 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15290;
    goto L1; // [2574] 10
L71: 

    /** scanner.e:1856					ungetch()*/
    _62ungetch();

    /** scanner.e:1857					return {res:CONCAT, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 15LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15291 = MAKE_SEQ(_1);
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    _15203 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15092 = NOVALUE;
    DeRef(_15281);
    _15281 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    DeRef(_15285);
    _15285 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    _15207 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    _15182 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15229 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    DeRef(_15219);
    _15219 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15169);
    _15169 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    _15172 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    DeRef(_15211);
    _15211 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    DeRef(_15217);
    _15217 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15225 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15266);
    _15266 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15291;
    goto L1; // [2592] 10
L70: 

    /** scanner.e:1860			elsif class = NUMBER_SIGN then*/
    if (_class_27316 != -11LL)
    goto L72; // [2599] 3122

    /** scanner.e:1861				i = 0*/
    DeRef(_i_27307);
    _i_27307 = 0LL;

    /** scanner.e:1862				is_int = -1*/
    _is_int_27315 = -1LL;

    /** scanner.e:1863				while i < TMAXINT/32 do*/
L73: 
    if (IS_ATOM_INT(_36TMAXINT_21268)) {
        _15293 = (_36TMAXINT_21268 % 32LL) ? NewDouble((eudouble)_36TMAXINT_21268 / 32LL) : (_36TMAXINT_21268 / 32LL);
    }
    else {
        _15293 = NewDouble(DBL_PTR(_36TMAXINT_21268)->dbl / (eudouble)32LL);
    }
    if (binary_op_a(GREATEREQ, _i_27307, _15293)){
        DeRef(_15293);
        _15293 = NOVALUE;
        goto L74; // [2624] 2788
    }
    DeRef(_15293);
    _15293 = NOVALUE;

    /** scanner.e:1864					ch = getch()*/
    _ch_27304 = _62getch();
    if (!IS_ATOM_INT(_ch_27304)) {
        _1 = (object)(DBL_PTR(_ch_27304)->dbl);
        DeRefDS(_ch_27304);
        _ch_27304 = _1;
    }

    /** scanner.e:1865					if char_class[ch] = DIGIT then*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _15296 = (object)*(((s1_ptr)_2)->base + _ch_27304);
    if (_15296 != -7LL)
    goto L75; // [2645] 2682

    /** scanner.e:1866						if ch != '_' then*/
    if (_ch_27304 == 95LL)
    goto L73; // [2651] 2618

    /** scanner.e:1867							i = i * 16 + ch - '0'*/
    if (IS_ATOM_INT(_i_27307)) {
        {
            int128_t p128 = (int128_t)_i_27307 * (int128_t)16LL;
            if( p128 != (int128_t)(_15299 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _15299 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _15299 = NewDouble(DBL_PTR(_i_27307)->dbl * (eudouble)16LL);
    }
    if (IS_ATOM_INT(_15299)) {
        _15300 = _15299 + _ch_27304;
        if ((object)((uintptr_t)_15300 + (uintptr_t)HIGH_BITS) >= 0){
            _15300 = NewDouble((eudouble)_15300);
        }
    }
    else {
        _15300 = NewDouble(DBL_PTR(_15299)->dbl + (eudouble)_ch_27304);
    }
    DeRef(_15299);
    _15299 = NOVALUE;
    DeRef(_i_27307);
    if (IS_ATOM_INT(_15300)) {
        _i_27307 = _15300 - 48LL;
        if ((object)((uintptr_t)_i_27307 +(uintptr_t) HIGH_BITS) >= 0){
            _i_27307 = NewDouble((eudouble)_i_27307);
        }
    }
    else {
        _i_27307 = NewDouble(DBL_PTR(_15300)->dbl - (eudouble)48LL);
    }
    DeRef(_15300);
    _15300 = NOVALUE;

    /** scanner.e:1868							is_int = TRUE*/
    _is_int_27315 = _13TRUE_452;
    goto L73; // [2679] 2618
L75: 

    /** scanner.e:1870					elsif ch >= 'A' and ch <= 'F' then*/
    _15302 = (_ch_27304 >= 65LL);
    if (_15302 == 0) {
        goto L76; // [2688] 2730
    }
    _15304 = (_ch_27304 <= 70LL);
    if (_15304 == 0)
    {
        DeRef(_15304);
        _15304 = NOVALUE;
        goto L76; // [2697] 2730
    }
    else{
        DeRef(_15304);
        _15304 = NOVALUE;
    }

    /** scanner.e:1871						i = (i * 16) + ch - ('A'-10)*/
    if (IS_ATOM_INT(_i_27307)) {
        {
            int128_t p128 = (int128_t)_i_27307 * (int128_t)16LL;
            if( p128 != (int128_t)(_15305 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _15305 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _15305 = NewDouble(DBL_PTR(_i_27307)->dbl * (eudouble)16LL);
    }
    if (IS_ATOM_INT(_15305)) {
        _15306 = _15305 + _ch_27304;
        if ((object)((uintptr_t)_15306 + (uintptr_t)HIGH_BITS) >= 0){
            _15306 = NewDouble((eudouble)_15306);
        }
    }
    else {
        _15306 = NewDouble(DBL_PTR(_15305)->dbl + (eudouble)_ch_27304);
    }
    DeRef(_15305);
    _15305 = NOVALUE;
    _15307 = 55LL;
    DeRef(_i_27307);
    if (IS_ATOM_INT(_15306)) {
        _i_27307 = _15306 - 55LL;
        if ((object)((uintptr_t)_i_27307 +(uintptr_t) HIGH_BITS) >= 0){
            _i_27307 = NewDouble((eudouble)_i_27307);
        }
    }
    else {
        _i_27307 = NewDouble(DBL_PTR(_15306)->dbl - (eudouble)55LL);
    }
    DeRef(_15306);
    _15306 = NOVALUE;
    _15307 = NOVALUE;

    /** scanner.e:1872						is_int = TRUE*/
    _is_int_27315 = _13TRUE_452;
    goto L73; // [2727] 2618
L76: 

    /** scanner.e:1873					elsif ch >= 'a' and ch <= 'f' then*/
    _15309 = (_ch_27304 >= 97LL);
    if (_15309 == 0) {
        goto L74; // [2736] 2788
    }
    _15311 = (_ch_27304 <= 102LL);
    if (_15311 == 0)
    {
        DeRef(_15311);
        _15311 = NOVALUE;
        goto L74; // [2745] 2788
    }
    else{
        DeRef(_15311);
        _15311 = NOVALUE;
    }

    /** scanner.e:1874						i = (i * 16) + ch - ('a'-10)*/
    if (IS_ATOM_INT(_i_27307)) {
        {
            int128_t p128 = (int128_t)_i_27307 * (int128_t)16LL;
            if( p128 != (int128_t)(_15312 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _15312 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _15312 = NewDouble(DBL_PTR(_i_27307)->dbl * (eudouble)16LL);
    }
    if (IS_ATOM_INT(_15312)) {
        _15313 = _15312 + _ch_27304;
        if ((object)((uintptr_t)_15313 + (uintptr_t)HIGH_BITS) >= 0){
            _15313 = NewDouble((eudouble)_15313);
        }
    }
    else {
        _15313 = NewDouble(DBL_PTR(_15312)->dbl + (eudouble)_ch_27304);
    }
    DeRef(_15312);
    _15312 = NOVALUE;
    _15314 = 87LL;
    DeRef(_i_27307);
    if (IS_ATOM_INT(_15313)) {
        _i_27307 = _15313 - 87LL;
        if ((object)((uintptr_t)_i_27307 +(uintptr_t) HIGH_BITS) >= 0){
            _i_27307 = NewDouble((eudouble)_i_27307);
        }
    }
    else {
        _i_27307 = NewDouble(DBL_PTR(_15313)->dbl - (eudouble)87LL);
    }
    DeRef(_15313);
    _15313 = NOVALUE;
    _15314 = NOVALUE;

    /** scanner.e:1875						is_int = TRUE*/
    _is_int_27315 = _13TRUE_452;
    goto L73; // [2775] 2618

    /** scanner.e:1877						exit*/
    goto L74; // [2780] 2788

    /** scanner.e:1879				end while*/
    goto L73; // [2785] 2618
L74: 

    /** scanner.e:1881				if is_int = -1 then*/
    if (_is_int_27315 != -1LL)
    goto L77; // [2790] 2857

    /** scanner.e:1882					if ch = '!' then*/
    if (_ch_27304 != 33LL)
    goto L78; // [2796] 2844

    /** scanner.e:1883						if line_number > 1 then*/
    if (_36line_number_21440 <= 1LL)
    goto L79; // [2804] 2818

    /** scanner.e:1884							CompileErr(MSG__MAY_ONLY_BE_ON_THE_FIRST_LINE_OF_A_PROGRAM)*/
    RefDS(_21993);
    _50CompileErr(161LL, _21993, 0LL);
L79: 

    /** scanner.e:1887						shebang = ThisLine*/
    Ref(_50ThisLine_49234);
    DeRef(_62shebang_25552);
    _62shebang_25552 = _50ThisLine_49234;

    /** scanner.e:1888						if start_include then*/
    if (_62start_include_25547 == 0)
    {
        goto L7A; // [2829] 2837
    }
    else{
    }

    /** scanner.e:1889							IncludePush()*/
    _62IncludePush();
L7A: 

    /** scanner.e:1891						read_line()*/
    _62read_line();
    goto L1; // [2841] 10
L78: 

    /** scanner.e:1893						CompileErr(HEX_NUMBER_NOT_FORMED_CORRECTLY)*/
    RefDS(_21993);
    _50CompileErr(97LL, _21993, 0LL);
    goto L1; // [2854] 10
L77: 

    /** scanner.e:1896					d = i*/
    Ref(_i_27307);
    DeRef(_d_27312);
    _d_27312 = _i_27307;

    /** scanner.e:1897					if i >= TMAXINT/32 then*/
    if (IS_ATOM_INT(_36TMAXINT_21268)) {
        _15319 = (_36TMAXINT_21268 % 32LL) ? NewDouble((eudouble)_36TMAXINT_21268 / 32LL) : (_36TMAXINT_21268 / 32LL);
    }
    else {
        _15319 = NewDouble(DBL_PTR(_36TMAXINT_21268)->dbl / (eudouble)32LL);
    }
    if (binary_op_a(LESS, _i_27307, _15319)){
        DeRef(_15319);
        _15319 = NOVALUE;
        goto L7B; // [2870] 3036
    }
    DeRef(_15319);
    _15319 = NOVALUE;

    /** scanner.e:1898						is_int = FALSE*/
    _is_int_27315 = _13FALSE_450;

    /** scanner.e:1899						while TRUE do*/
L7C: 
    if (_13TRUE_452 == 0)
    {
        goto L7D; // [2890] 3035
    }
    else{
    }

    /** scanner.e:1900							ch = getch()  -- eventually END_OF_FILE_CHAR or new-line*/
    _ch_27304 = _62getch();
    if (!IS_ATOM_INT(_ch_27304)) {
        _1 = (object)(DBL_PTR(_ch_27304)->dbl);
        DeRefDS(_ch_27304);
        _ch_27304 = _1;
    }

    /** scanner.e:1901							if char_class[ch] = DIGIT then*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _15322 = (object)*(((s1_ptr)_2)->base + _ch_27304);
    if (_15322 != -7LL)
    goto L7E; // [2910] 2938

    /** scanner.e:1902								if ch != '_' then*/
    if (_ch_27304 == 95LL)
    goto L7C; // [2916] 2888

    /** scanner.e:1903									d = (d * 16) + ch - '0'*/
    if (IS_ATOM_INT(_d_27312)) {
        {
            int128_t p128 = (int128_t)_d_27312 * (int128_t)16LL;
            if( p128 != (int128_t)(_15325 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _15325 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _15325 = binary_op(MULTIPLY, _d_27312, 16LL);
    }
    if (IS_ATOM_INT(_15325)) {
        _15326 = _15325 + _ch_27304;
        if ((object)((uintptr_t)_15326 + (uintptr_t)HIGH_BITS) >= 0){
            _15326 = NewDouble((eudouble)_15326);
        }
    }
    else {
        _15326 = binary_op(PLUS, _15325, _ch_27304);
    }
    DeRef(_15325);
    _15325 = NOVALUE;
    DeRef(_d_27312);
    if (IS_ATOM_INT(_15326)) {
        _d_27312 = _15326 - 48LL;
        if ((object)((uintptr_t)_d_27312 +(uintptr_t) HIGH_BITS) >= 0){
            _d_27312 = NewDouble((eudouble)_d_27312);
        }
    }
    else {
        _d_27312 = binary_op(MINUS, _15326, 48LL);
    }
    DeRef(_15326);
    _15326 = NOVALUE;
    goto L7C; // [2935] 2888
L7E: 

    /** scanner.e:1905							elsif ch >= 'A' and ch <= 'F' then*/
    _15328 = (_ch_27304 >= 65LL);
    if (_15328 == 0) {
        goto L7F; // [2944] 2977
    }
    _15330 = (_ch_27304 <= 70LL);
    if (_15330 == 0)
    {
        DeRef(_15330);
        _15330 = NOVALUE;
        goto L7F; // [2953] 2977
    }
    else{
        DeRef(_15330);
        _15330 = NOVALUE;
    }

    /** scanner.e:1906								d = (d * 16) + ch - ('A'- 10)*/
    if (IS_ATOM_INT(_d_27312)) {
        {
            int128_t p128 = (int128_t)_d_27312 * (int128_t)16LL;
            if( p128 != (int128_t)(_15331 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _15331 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _15331 = binary_op(MULTIPLY, _d_27312, 16LL);
    }
    if (IS_ATOM_INT(_15331)) {
        _15332 = _15331 + _ch_27304;
        if ((object)((uintptr_t)_15332 + (uintptr_t)HIGH_BITS) >= 0){
            _15332 = NewDouble((eudouble)_15332);
        }
    }
    else {
        _15332 = binary_op(PLUS, _15331, _ch_27304);
    }
    DeRef(_15331);
    _15331 = NOVALUE;
    _15333 = 55LL;
    DeRef(_d_27312);
    if (IS_ATOM_INT(_15332)) {
        _d_27312 = _15332 - 55LL;
        if ((object)((uintptr_t)_d_27312 +(uintptr_t) HIGH_BITS) >= 0){
            _d_27312 = NewDouble((eudouble)_d_27312);
        }
    }
    else {
        _d_27312 = binary_op(MINUS, _15332, 55LL);
    }
    DeRef(_15332);
    _15332 = NOVALUE;
    _15333 = NOVALUE;
    goto L7C; // [2974] 2888
L7F: 

    /** scanner.e:1907							elsif ch >= 'a' and ch <= 'f' then*/
    _15335 = (_ch_27304 >= 97LL);
    if (_15335 == 0) {
        goto L80; // [2983] 3016
    }
    _15337 = (_ch_27304 <= 102LL);
    if (_15337 == 0)
    {
        DeRef(_15337);
        _15337 = NOVALUE;
        goto L80; // [2992] 3016
    }
    else{
        DeRef(_15337);
        _15337 = NOVALUE;
    }

    /** scanner.e:1908								d = (d * 16) + ch - ('a'-10)*/
    if (IS_ATOM_INT(_d_27312)) {
        {
            int128_t p128 = (int128_t)_d_27312 * (int128_t)16LL;
            if( p128 != (int128_t)(_15338 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _15338 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _15338 = binary_op(MULTIPLY, _d_27312, 16LL);
    }
    if (IS_ATOM_INT(_15338)) {
        _15339 = _15338 + _ch_27304;
        if ((object)((uintptr_t)_15339 + (uintptr_t)HIGH_BITS) >= 0){
            _15339 = NewDouble((eudouble)_15339);
        }
    }
    else {
        _15339 = binary_op(PLUS, _15338, _ch_27304);
    }
    DeRef(_15338);
    _15338 = NOVALUE;
    _15340 = 87LL;
    DeRef(_d_27312);
    if (IS_ATOM_INT(_15339)) {
        _d_27312 = _15339 - 87LL;
        if ((object)((uintptr_t)_d_27312 +(uintptr_t) HIGH_BITS) >= 0){
            _d_27312 = NewDouble((eudouble)_d_27312);
        }
    }
    else {
        _d_27312 = binary_op(MINUS, _15339, 87LL);
    }
    DeRef(_15339);
    _15339 = NOVALUE;
    _15340 = NOVALUE;
    goto L7C; // [3013] 2888
L80: 

    /** scanner.e:1909							elsif ch = '_' then*/
    if (_ch_27304 != 95LL)
    goto L7D; // [3018] 3035
    goto L7C; // [3022] 2888

    /** scanner.e:1912								exit*/
    goto L7D; // [3027] 3035

    /** scanner.e:1914						end while*/
    goto L7C; // [3032] 2888
L7D: 
L7B: 

    /** scanner.e:1917					ungetch()*/
    _62ungetch();

    /** scanner.e:1918					if is_int and is_integer(i) then*/
    if (_is_int_27315 == 0) {
        goto L81; // [3042] 3073
    }
    Ref(_i_27307);
    _15344 = _36is_integer(_i_27307);
    if (_15344 == 0) {
        DeRef(_15344);
        _15344 = NOVALUE;
        goto L81; // [3051] 3073
    }
    else {
        if (!IS_ATOM_INT(_15344) && DBL_PTR(_15344)->dbl == 0.0){
            DeRef(_15344);
            _15344 = NOVALUE;
            goto L81; // [3051] 3073
        }
        DeRef(_15344);
        _15344 = NOVALUE;
    }
    DeRef(_15344);
    _15344 = NOVALUE;

    /** scanner.e:1919						return {ATOM, NewIntSym(i)}*/
    Ref(_i_27307);
    _15345 = _54NewIntSym(_i_27307);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502LL;
    ((intptr_t *)_2)[2] = _15345;
    _15346 = MAKE_SEQ(_1);
    _15345 = NOVALUE;
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    DeRef(_15328);
    _15328 = NOVALUE;
    _15203 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15092 = NOVALUE;
    DeRef(_15281);
    _15281 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    DeRef(_15285);
    _15285 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    _15207 = NOVALUE;
    _15296 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    _15322 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    _15182 = NOVALUE;
    DeRef(_15335);
    _15335 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15229 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    DeRef(_15302);
    _15302 = NOVALUE;
    DeRef(_15219);
    _15219 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15169);
    _15169 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    _15172 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    DeRef(_15211);
    _15211 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    DeRef(_15217);
    _15217 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15225 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15266);
    _15266 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15346;
    goto L1; // [3070] 10
L81: 

    /** scanner.e:1921						if d <= TMAXINT_DBL then            -- d is always >= 0*/
    if (binary_op_a(GREATER, _d_27312, _36TMAXINT_DBL_21271)){
        goto L82; // [3077] 3100
    }

    /** scanner.e:1922							return {ATOM, NewIntSym(d)}*/
    Ref(_d_27312);
    _15348 = _54NewIntSym(_d_27312);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502LL;
    ((intptr_t *)_2)[2] = _15348;
    _15349 = MAKE_SEQ(_1);
    _15348 = NOVALUE;
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    DeRef(_15328);
    _15328 = NOVALUE;
    _15203 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15092 = NOVALUE;
    DeRef(_15281);
    _15281 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    DeRef(_15285);
    _15285 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    _15207 = NOVALUE;
    _15296 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    _15322 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    _15182 = NOVALUE;
    DeRef(_15335);
    _15335 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15229 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    DeRef(_15302);
    _15302 = NOVALUE;
    DeRef(_15219);
    _15219 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15169);
    _15169 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    _15172 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    DeRef(_15211);
    _15211 = NOVALUE;
    DeRef(_15346);
    _15346 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    DeRef(_15217);
    _15217 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15225 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15266);
    _15266 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15349;
    goto L1; // [3097] 10
L82: 

    /** scanner.e:1924							return {ATOM, NewDoubleSym(d)}*/
    Ref(_d_27312);
    _15350 = _54NewDoubleSym(_d_27312);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502LL;
    ((intptr_t *)_2)[2] = _15350;
    _15351 = MAKE_SEQ(_1);
    _15350 = NOVALUE;
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    DeRef(_15328);
    _15328 = NOVALUE;
    _15203 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15092 = NOVALUE;
    DeRef(_15281);
    _15281 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    DeRef(_15285);
    _15285 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    _15207 = NOVALUE;
    _15296 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    _15322 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    _15182 = NOVALUE;
    DeRef(_15335);
    _15335 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15229 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    DeRef(_15302);
    _15302 = NOVALUE;
    DeRef(_15219);
    _15219 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15169);
    _15169 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    _15172 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    DeRef(_15211);
    _15211 = NOVALUE;
    DeRef(_15346);
    _15346 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    DeRef(_15217);
    _15217 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15225 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15349);
    _15349 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15266);
    _15266 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15351;
    goto L1; // [3119] 10
L72: 

    /** scanner.e:1929			elsif class = res:MULTIPLY then*/
    if (_class_27316 != 13LL)
    goto L83; // [3124] 3174

    /** scanner.e:1930				ch = getch()*/
    _ch_27304 = _62getch();
    if (!IS_ATOM_INT(_ch_27304)) {
        _1 = (object)(DBL_PTR(_ch_27304)->dbl);
        DeRefDS(_ch_27304);
        _ch_27304 = _1;
    }

    /** scanner.e:1931				if ch = '=' then*/
    if (_ch_27304 != 61LL)
    goto L84; // [3137] 3156

    /** scanner.e:1932					return {MULTIPLY_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 517LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15355 = MAKE_SEQ(_1);
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    DeRef(_15328);
    _15328 = NOVALUE;
    _15203 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15092 = NOVALUE;
    DeRef(_15281);
    _15281 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    DeRef(_15285);
    _15285 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    _15207 = NOVALUE;
    _15296 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    _15322 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    _15182 = NOVALUE;
    DeRef(_15335);
    _15335 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15229 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    DeRef(_15302);
    _15302 = NOVALUE;
    DeRef(_15219);
    _15219 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15169);
    _15169 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    _15172 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    DeRef(_15211);
    _15211 = NOVALUE;
    DeRef(_15346);
    _15346 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    DeRef(_15217);
    _15217 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15225 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15349);
    _15349 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15266);
    _15266 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15355;
    goto L1; // [3153] 10
L84: 

    /** scanner.e:1934					ungetch()*/
    _62ungetch();

    /** scanner.e:1935					return {res:MULTIPLY, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 13LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15356 = MAKE_SEQ(_1);
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    DeRef(_15328);
    _15328 = NOVALUE;
    _15203 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15092 = NOVALUE;
    DeRef(_15281);
    _15281 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    DeRef(_15285);
    _15285 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    _15207 = NOVALUE;
    _15296 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    _15322 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    _15182 = NOVALUE;
    DeRef(_15335);
    _15335 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15229 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    DeRef(_15302);
    _15302 = NOVALUE;
    DeRef(_15219);
    _15219 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15169);
    _15169 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    _15172 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    DeRef(_15211);
    _15211 = NOVALUE;
    DeRef(_15346);
    _15346 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    DeRef(_15217);
    _15217 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15225 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15349);
    _15349 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15266);
    _15266 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15356;
    goto L1; // [3171] 10
L83: 

    /** scanner.e:1938			elsif class = res:DIVIDE then*/
    if (_class_27316 != 14LL)
    goto L85; // [3176] 3380

    /** scanner.e:1939				ch = getch()*/
    _ch_27304 = _62getch();
    if (!IS_ATOM_INT(_ch_27304)) {
        _1 = (object)(DBL_PTR(_ch_27304)->dbl);
        DeRefDS(_ch_27304);
        _ch_27304 = _1;
    }

    /** scanner.e:1940				if ch = '=' then*/
    if (_ch_27304 != 61LL)
    goto L86; // [3189] 3208

    /** scanner.e:1941					return {DIVIDE_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 518LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15360 = MAKE_SEQ(_1);
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    DeRef(_15328);
    _15328 = NOVALUE;
    _15203 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15092 = NOVALUE;
    DeRef(_15281);
    _15281 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    DeRef(_15285);
    _15285 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    _15207 = NOVALUE;
    _15296 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    _15322 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    _15182 = NOVALUE;
    DeRef(_15335);
    _15335 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15229 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    DeRef(_15302);
    _15302 = NOVALUE;
    DeRef(_15219);
    _15219 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15169);
    _15169 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    _15172 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    DeRef(_15211);
    _15211 = NOVALUE;
    DeRef(_15346);
    _15346 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    DeRef(_15217);
    _15217 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15225 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15349);
    _15349 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15356);
    _15356 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15266);
    _15266 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15360;
    goto L1; // [3205] 10
L86: 

    /** scanner.e:1942				elsif ch = '*' then*/
    if (_ch_27304 != 42LL)
    goto L87; // [3210] 3362

    /** scanner.e:1944					cline = line_number*/
    _cline_27309 = _36line_number_21440;

    /** scanner.e:1945					integer cnest = 1*/
    _cnest_27977 = 1LL;

    /** scanner.e:1946					while cnest > 0 do*/
L88: 
    if (_cnest_27977 <= 0LL)
    goto L89; // [3233] 3341

    /** scanner.e:1947						ch = getch()*/
    _ch_27304 = _62getch();
    if (!IS_ATOM_INT(_ch_27304)) {
        _1 = (object)(DBL_PTR(_ch_27304)->dbl);
        DeRefDS(_ch_27304);
        _ch_27304 = _1;
    }

    /** scanner.e:1948						switch ch do*/
    _0 = _ch_27304;
    switch ( _0 ){ 

        /** scanner.e:1949							case  END_OF_FILE_CHAR then*/
        case 26:

        /** scanner.e:1950								exit*/
        goto L89; // [3257] 3341
        goto L88; // [3259] 3233

        /** scanner.e:1952							case '\n' then*/
        case 10:

        /** scanner.e:1953								read_line()*/
        _62read_line();
        goto L88; // [3269] 3233

        /** scanner.e:1955							case '*' then*/
        case 42:

        /** scanner.e:1956								ch = getch()*/
        _ch_27304 = _62getch();
        if (!IS_ATOM_INT(_ch_27304)) {
            _1 = (object)(DBL_PTR(_ch_27304)->dbl);
            DeRefDS(_ch_27304);
            _ch_27304 = _1;
        }

        /** scanner.e:1957								if ch = '/' then*/
        if (_ch_27304 != 47LL)
        goto L8A; // [3284] 3297

        /** scanner.e:1958									cnest -= 1*/
        _cnest_27977 = _cnest_27977 - 1LL;
        goto L88; // [3294] 3233
L8A: 

        /** scanner.e:1960									ungetch()*/
        _62ungetch();
        goto L88; // [3302] 3233

        /** scanner.e:1963							case '/' then*/
        case 47:

        /** scanner.e:1964								ch = getch()*/
        _ch_27304 = _62getch();
        if (!IS_ATOM_INT(_ch_27304)) {
            _1 = (object)(DBL_PTR(_ch_27304)->dbl);
            DeRefDS(_ch_27304);
            _ch_27304 = _1;
        }

        /** scanner.e:1965								if ch = '*' then*/
        if (_ch_27304 != 42LL)
        goto L8B; // [3317] 3330

        /** scanner.e:1966									cnest += 1*/
        _cnest_27977 = _cnest_27977 + 1;
        goto L8C; // [3327] 3335
L8B: 

        /** scanner.e:1968									ungetch()*/
        _62ungetch();
L8C: 
    ;}
    /** scanner.e:1972					end while*/
    goto L88; // [3338] 3233
L89: 

    /** scanner.e:1974					if cnest > 0 then*/
    if (_cnest_27977 <= 0LL)
    goto L8D; // [3343] 3357

    /** scanner.e:1975						CompileErr(BLOCK_COMMENT_FROM_LINE_1_NOT_TERMINATED, cline)*/
    _50CompileErr(42LL, _cline_27309, 0LL);
L8D: 
    goto L1; // [3359] 10
L87: 

    /** scanner.e:1978					ungetch()*/
    _62ungetch();

    /** scanner.e:1979					return {res:DIVIDE, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 14LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15373 = MAKE_SEQ(_1);
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    DeRef(_15328);
    _15328 = NOVALUE;
    _15203 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15092 = NOVALUE;
    DeRef(_15281);
    _15281 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    DeRef(_15285);
    _15285 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    _15207 = NOVALUE;
    _15296 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    _15322 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    _15182 = NOVALUE;
    DeRef(_15335);
    _15335 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15229 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    DeRef(_15302);
    _15302 = NOVALUE;
    DeRef(_15219);
    _15219 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15169);
    _15169 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    _15172 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    DeRef(_15211);
    _15211 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15346);
    _15346 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    DeRef(_15217);
    _15217 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15225 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15349);
    _15349 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15356);
    _15356 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15266);
    _15266 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15373;
    goto L1; // [3377] 10
L85: 

    /** scanner.e:1981			elsif class = SINGLE_QUOTE then*/
    if (_class_27316 != -5LL)
    goto L8E; // [3384] 3534

    /** scanner.e:1982				atom ach = getch()*/
    _0 = _ach_28007;
    _ach_28007 = _62getch();
    DeRef(_0);

    /** scanner.e:1983				if ach = '\\' then*/
    if (binary_op_a(NOTEQ, _ach_28007, 92LL)){
        goto L8F; // [3395] 3408
    }

    /** scanner.e:1984					ach = EscapeChar('\'')*/
    _0 = _ach_28007;
    _ach_28007 = _62EscapeChar(39LL);
    DeRef(_0);
    goto L90; // [3405] 3465
L8F: 

    /** scanner.e:1985				elsif ach = '\t' then*/
    if (binary_op_a(NOTEQ, _ach_28007, 9LL)){
        goto L91; // [3410] 3426
    }

    /** scanner.e:1986					CompileErr(MSG_TAB_CHARACTER_FOUND_IN_STRING__USE_T_INSTEAD)*/
    RefDS(_21993);
    _50CompileErr(145LL, _21993, 0LL);
    goto L90; // [3423] 3465
L91: 

    /** scanner.e:1987				elsif ach = '\'' then*/
    if (binary_op_a(NOTEQ, _ach_28007, 39LL)){
        goto L92; // [3428] 3444
    }

    /** scanner.e:1988					CompileErr(SINGLEQUOTE_CHARACTER_IS_EMPTY)*/
    RefDS(_21993);
    _50CompileErr(137LL, _21993, 0LL);
    goto L90; // [3441] 3465
L92: 

    /** scanner.e:1989				elsif ach = '\n' then*/
    if (binary_op_a(NOTEQ, _ach_28007, 10LL)){
        goto L93; // [3446] 3464
    }

    /** scanner.e:1990					CompileErr(EXPECTED_1_NOT_2, {"character", "end of line"})*/
    RefDS(_15382);
    RefDS(_15381);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _15381;
    ((intptr_t *)_2)[2] = _15382;
    _15383 = MAKE_SEQ(_1);
    _50CompileErr(68LL, _15383, 0LL);
    _15383 = NOVALUE;
L93: 
L90: 

    /** scanner.e:1992				if getch() != '\'' then*/
    _15384 = _62getch();
    if (binary_op_a(EQUALS, _15384, 39LL)){
        DeRef(_15384);
        _15384 = NOVALUE;
        goto L94; // [3470] 3484
    }
    DeRef(_15384);
    _15384 = NOVALUE;

    /** scanner.e:1993					CompileErr(CHARACTER_CONSTANT_IS_MISSING_A_CLOSING)*/
    RefDS(_21993);
    _50CompileErr(56LL, _21993, 0LL);
L94: 

    /** scanner.e:1995				if is_integer(ach) then*/
    Ref(_ach_28007);
    _15386 = _36is_integer(_ach_28007);
    if (_15386 == 0) {
        DeRef(_15386);
        _15386 = NOVALUE;
        goto L95; // [3490] 3512
    }
    else {
        if (!IS_ATOM_INT(_15386) && DBL_PTR(_15386)->dbl == 0.0){
            DeRef(_15386);
            _15386 = NOVALUE;
            goto L95; // [3490] 3512
        }
        DeRef(_15386);
        _15386 = NOVALUE;
    }
    DeRef(_15386);
    _15386 = NOVALUE;

    /** scanner.e:1996					return {ATOM, NewIntSym(ach)}*/
    Ref(_ach_28007);
    _15387 = _54NewIntSym(_ach_28007);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502LL;
    ((intptr_t *)_2)[2] = _15387;
    _15388 = MAKE_SEQ(_1);
    _15387 = NOVALUE;
    DeRef(_ach_28007);
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    DeRef(_15328);
    _15328 = NOVALUE;
    _15203 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15092 = NOVALUE;
    DeRef(_15281);
    _15281 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    DeRef(_15285);
    _15285 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15373);
    _15373 = NOVALUE;
    _15207 = NOVALUE;
    _15296 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    _15322 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    _15182 = NOVALUE;
    DeRef(_15335);
    _15335 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15229 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    DeRef(_15302);
    _15302 = NOVALUE;
    DeRef(_15219);
    _15219 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15169);
    _15169 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    _15172 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    DeRef(_15211);
    _15211 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15346);
    _15346 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    DeRef(_15217);
    _15217 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15225 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15349);
    _15349 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15356);
    _15356 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15266);
    _15266 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15388;
    goto L96; // [3509] 3529
L95: 

    /** scanner.e:1998					return {ATOM, NewDoubleSym(ach)}*/
    Ref(_ach_28007);
    _15389 = _54NewDoubleSym(_ach_28007);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502LL;
    ((intptr_t *)_2)[2] = _15389;
    _15390 = MAKE_SEQ(_1);
    _15389 = NOVALUE;
    DeRef(_ach_28007);
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    DeRef(_15328);
    _15328 = NOVALUE;
    _15203 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15092 = NOVALUE;
    DeRef(_15281);
    _15281 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    DeRef(_15285);
    _15285 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15373);
    _15373 = NOVALUE;
    _15207 = NOVALUE;
    _15296 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    _15322 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    _15182 = NOVALUE;
    DeRef(_15388);
    _15388 = NOVALUE;
    DeRef(_15335);
    _15335 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15229 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    DeRef(_15302);
    _15302 = NOVALUE;
    DeRef(_15219);
    _15219 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15169);
    _15169 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    _15172 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    DeRef(_15211);
    _15211 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15346);
    _15346 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    DeRef(_15217);
    _15217 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15225 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15349);
    _15349 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15356);
    _15356 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15266);
    _15266 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15390;
L96: 
    DeRef(_ach_28007);
    _ach_28007 = NOVALUE;
    goto L1; // [3531] 10
L8E: 

    /** scanner.e:2001			elsif class = LESS then*/
    if (_class_27316 != 1LL)
    goto L97; // [3538] 3586

    /** scanner.e:2002				if getch() = '=' then*/
    _15392 = _62getch();
    if (binary_op_a(NOTEQ, _15392, 61LL)){
        DeRef(_15392);
        _15392 = NOVALUE;
        goto L98; // [3547] 3566
    }
    DeRef(_15392);
    _15392 = NOVALUE;

    /** scanner.e:2003					return {LESSEQ, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 5LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15394 = MAKE_SEQ(_1);
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    DeRef(_15328);
    _15328 = NOVALUE;
    _15203 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15092 = NOVALUE;
    DeRef(_15281);
    _15281 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    DeRef(_15285);
    _15285 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15373);
    _15373 = NOVALUE;
    _15207 = NOVALUE;
    _15296 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    _15322 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    _15182 = NOVALUE;
    DeRef(_15388);
    _15388 = NOVALUE;
    DeRef(_15335);
    _15335 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15229 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    DeRef(_15302);
    _15302 = NOVALUE;
    DeRef(_15219);
    _15219 = NOVALUE;
    DeRef(_15390);
    _15390 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15169);
    _15169 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    _15172 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    DeRef(_15211);
    _15211 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15346);
    _15346 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    DeRef(_15217);
    _15217 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15225 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15349);
    _15349 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15356);
    _15356 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15266);
    _15266 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15394;
    goto L1; // [3563] 10
L98: 

    /** scanner.e:2005					ungetch()*/
    _62ungetch();

    /** scanner.e:2006					return {LESS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15395 = MAKE_SEQ(_1);
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    DeRef(_15328);
    _15328 = NOVALUE;
    _15203 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15092 = NOVALUE;
    DeRef(_15281);
    _15281 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    DeRef(_15285);
    _15285 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15394);
    _15394 = NOVALUE;
    DeRef(_15373);
    _15373 = NOVALUE;
    _15207 = NOVALUE;
    _15296 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    _15322 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    _15182 = NOVALUE;
    DeRef(_15388);
    _15388 = NOVALUE;
    DeRef(_15335);
    _15335 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15229 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    DeRef(_15302);
    _15302 = NOVALUE;
    DeRef(_15219);
    _15219 = NOVALUE;
    DeRef(_15390);
    _15390 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15169);
    _15169 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    _15172 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    DeRef(_15211);
    _15211 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15346);
    _15346 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    DeRef(_15217);
    _15217 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15225 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15349);
    _15349 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15356);
    _15356 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15266);
    _15266 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15395;
    goto L1; // [3583] 10
L97: 

    /** scanner.e:2009			elsif class = GREATER then*/
    if (_class_27316 != 6LL)
    goto L99; // [3590] 3638

    /** scanner.e:2010				if getch() = '=' then*/
    _15397 = _62getch();
    if (binary_op_a(NOTEQ, _15397, 61LL)){
        DeRef(_15397);
        _15397 = NOVALUE;
        goto L9A; // [3599] 3618
    }
    DeRef(_15397);
    _15397 = NOVALUE;

    /** scanner.e:2011					return {GREATEREQ, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 2LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15399 = MAKE_SEQ(_1);
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    DeRef(_15328);
    _15328 = NOVALUE;
    _15203 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15092 = NOVALUE;
    DeRef(_15281);
    _15281 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    DeRef(_15285);
    _15285 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15394);
    _15394 = NOVALUE;
    DeRef(_15373);
    _15373 = NOVALUE;
    _15207 = NOVALUE;
    _15296 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    _15322 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    _15182 = NOVALUE;
    DeRef(_15388);
    _15388 = NOVALUE;
    DeRef(_15335);
    _15335 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15229 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    DeRef(_15302);
    _15302 = NOVALUE;
    DeRef(_15219);
    _15219 = NOVALUE;
    DeRef(_15390);
    _15390 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15169);
    _15169 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    _15172 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    DeRef(_15211);
    _15211 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15346);
    _15346 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    DeRef(_15217);
    _15217 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15225 = NOVALUE;
    DeRef(_15395);
    _15395 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15349);
    _15349 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15356);
    _15356 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15266);
    _15266 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15399;
    goto L1; // [3615] 10
L9A: 

    /** scanner.e:2013					ungetch()*/
    _62ungetch();

    /** scanner.e:2014					return {GREATER, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 6LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15400 = MAKE_SEQ(_1);
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    DeRef(_15328);
    _15328 = NOVALUE;
    _15203 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15092 = NOVALUE;
    DeRef(_15281);
    _15281 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    DeRef(_15285);
    _15285 = NOVALUE;
    DeRef(_15399);
    _15399 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15394);
    _15394 = NOVALUE;
    DeRef(_15373);
    _15373 = NOVALUE;
    _15207 = NOVALUE;
    _15296 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    _15322 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    _15182 = NOVALUE;
    DeRef(_15388);
    _15388 = NOVALUE;
    DeRef(_15335);
    _15335 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15229 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    DeRef(_15302);
    _15302 = NOVALUE;
    DeRef(_15219);
    _15219 = NOVALUE;
    DeRef(_15390);
    _15390 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15169);
    _15169 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    _15172 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    DeRef(_15211);
    _15211 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15346);
    _15346 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    DeRef(_15217);
    _15217 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15225 = NOVALUE;
    DeRef(_15395);
    _15395 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15349);
    _15349 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15356);
    _15356 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15266);
    _15266 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15400;
    goto L1; // [3635] 10
L99: 

    /** scanner.e:2017			elsif class = BANG then*/
    if (_class_27316 != -1LL)
    goto L9B; // [3642] 3690

    /** scanner.e:2018				if getch() = '=' then*/
    _15402 = _62getch();
    if (binary_op_a(NOTEQ, _15402, 61LL)){
        DeRef(_15402);
        _15402 = NOVALUE;
        goto L9C; // [3651] 3670
    }
    DeRef(_15402);
    _15402 = NOVALUE;

    /** scanner.e:2019					return {NOTEQ, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15404 = MAKE_SEQ(_1);
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    DeRef(_15328);
    _15328 = NOVALUE;
    _15203 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15092 = NOVALUE;
    DeRef(_15281);
    _15281 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    DeRef(_15285);
    _15285 = NOVALUE;
    DeRef(_15399);
    _15399 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15394);
    _15394 = NOVALUE;
    DeRef(_15373);
    _15373 = NOVALUE;
    _15207 = NOVALUE;
    _15296 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    _15322 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    _15182 = NOVALUE;
    DeRef(_15388);
    _15388 = NOVALUE;
    DeRef(_15335);
    _15335 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15229 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    DeRef(_15302);
    _15302 = NOVALUE;
    DeRef(_15219);
    _15219 = NOVALUE;
    DeRef(_15390);
    _15390 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15169);
    _15169 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    _15172 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    DeRef(_15211);
    _15211 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15346);
    _15346 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15400);
    _15400 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    DeRef(_15217);
    _15217 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15225 = NOVALUE;
    DeRef(_15395);
    _15395 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15349);
    _15349 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15356);
    _15356 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15266);
    _15266 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15404;
    goto L1; // [3667] 10
L9C: 

    /** scanner.e:2021					ungetch()*/
    _62ungetch();

    /** scanner.e:2022					return {BANG, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15405 = MAKE_SEQ(_1);
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    DeRef(_15328);
    _15328 = NOVALUE;
    _15203 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15092 = NOVALUE;
    DeRef(_15281);
    _15281 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    DeRef(_15285);
    _15285 = NOVALUE;
    DeRef(_15399);
    _15399 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15394);
    _15394 = NOVALUE;
    DeRef(_15373);
    _15373 = NOVALUE;
    _15207 = NOVALUE;
    _15296 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    _15322 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    _15182 = NOVALUE;
    DeRef(_15388);
    _15388 = NOVALUE;
    DeRef(_15335);
    _15335 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15229 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    DeRef(_15302);
    _15302 = NOVALUE;
    DeRef(_15219);
    _15219 = NOVALUE;
    DeRef(_15390);
    _15390 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15169);
    _15169 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    _15172 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    DeRef(_15211);
    _15211 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15346);
    _15346 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15400);
    _15400 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    DeRef(_15217);
    _15217 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15225 = NOVALUE;
    DeRef(_15395);
    _15395 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15404);
    _15404 = NOVALUE;
    DeRef(_15349);
    _15349 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15356);
    _15356 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15266);
    _15266 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15405;
    goto L1; // [3687] 10
L9B: 

    /** scanner.e:2025			elsif class = KEYWORD then*/
    if (_class_27316 != -10LL)
    goto L9D; // [3694] 3727

    /** scanner.e:2026				return {keylist[ch - KEYWORD_BASE][K_TOKEN], 0}*/
    _15407 = _ch_27304 - 128LL;
    _2 = (object)SEQ_PTR(_63keylist_23115);
    _15408 = (object)*(((s1_ptr)_2)->base + _15407);
    _2 = (object)SEQ_PTR(_15408);
    _15409 = (object)*(((s1_ptr)_2)->base + 3LL);
    _15408 = NOVALUE;
    Ref(_15409);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _15409;
    ((intptr_t *)_2)[2] = 0LL;
    _15410 = MAKE_SEQ(_1);
    _15409 = NOVALUE;
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    DeRef(_15328);
    _15328 = NOVALUE;
    _15203 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15092 = NOVALUE;
    DeRef(_15281);
    _15281 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    DeRef(_15285);
    _15285 = NOVALUE;
    DeRef(_15399);
    _15399 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15394);
    _15394 = NOVALUE;
    _15407 = NOVALUE;
    DeRef(_15373);
    _15373 = NOVALUE;
    _15207 = NOVALUE;
    _15296 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    _15322 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    _15182 = NOVALUE;
    DeRef(_15388);
    _15388 = NOVALUE;
    DeRef(_15335);
    _15335 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15229 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    DeRef(_15302);
    _15302 = NOVALUE;
    DeRef(_15219);
    _15219 = NOVALUE;
    DeRef(_15390);
    _15390 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15169);
    _15169 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    _15172 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    DeRef(_15405);
    _15405 = NOVALUE;
    DeRef(_15211);
    _15211 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15346);
    _15346 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15400);
    _15400 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    DeRef(_15217);
    _15217 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15225 = NOVALUE;
    DeRef(_15395);
    _15395 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15404);
    _15404 = NOVALUE;
    DeRef(_15349);
    _15349 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15356);
    _15356 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15266);
    _15266 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15410;
    goto L1; // [3724] 10
L9D: 

    /** scanner.e:2028			elsif class = BUILTIN then*/
    if (_class_27316 != -9LL)
    goto L9E; // [3731] 3784

    /** scanner.e:2029				name = keylist[ch - BUILTIN_BASE + NUM_KEYWORDS][K_NAME]*/
    _15412 = _ch_27304 - 170LL;
    if ((object)((uintptr_t)_15412 +(uintptr_t) HIGH_BITS) >= 0){
        _15412 = NewDouble((eudouble)_15412);
    }
    if (IS_ATOM_INT(_15412)) {
        _15413 = _15412 + 24LL;
    }
    else {
        _15413 = NewDouble(DBL_PTR(_15412)->dbl + (eudouble)24LL);
    }
    DeRef(_15412);
    _15412 = NOVALUE;
    _2 = (object)SEQ_PTR(_63keylist_23115);
    if (!IS_ATOM_INT(_15413)){
        _15414 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_15413)->dbl));
    }
    else{
        _15414 = (object)*(((s1_ptr)_2)->base + _15413);
    }
    DeRef(_name_27317);
    _2 = (object)SEQ_PTR(_15414);
    _name_27317 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_name_27317);
    _15414 = NOVALUE;

    /** scanner.e:2030				return keyfind(name, -1)*/
    RefDS(_name_27317);
    _31711 = _54hashfn(_name_27317);
    RefDS(_name_27317);
    _15416 = _54keyfind(_name_27317, -1LL, _36current_file_no_21439, 0LL, _31711);
    _31711 = NOVALUE;
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRefDS(_name_27317);
    DeRef(_15328);
    _15328 = NOVALUE;
    _15203 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15092 = NOVALUE;
    DeRef(_15281);
    _15281 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    DeRef(_15285);
    _15285 = NOVALUE;
    DeRef(_15399);
    _15399 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15394);
    _15394 = NOVALUE;
    DeRef(_15410);
    _15410 = NOVALUE;
    DeRef(_15407);
    _15407 = NOVALUE;
    DeRef(_15373);
    _15373 = NOVALUE;
    _15207 = NOVALUE;
    _15296 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    _15322 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    _15182 = NOVALUE;
    DeRef(_15388);
    _15388 = NOVALUE;
    DeRef(_15335);
    _15335 = NOVALUE;
    DeRef(_15413);
    _15413 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15229 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    DeRef(_15302);
    _15302 = NOVALUE;
    DeRef(_15219);
    _15219 = NOVALUE;
    DeRef(_15390);
    _15390 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15169);
    _15169 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    _15172 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    DeRef(_15405);
    _15405 = NOVALUE;
    DeRef(_15211);
    _15211 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15346);
    _15346 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15400);
    _15400 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    DeRef(_15217);
    _15217 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15225 = NOVALUE;
    DeRef(_15395);
    _15395 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15404);
    _15404 = NOVALUE;
    DeRef(_15349);
    _15349 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15356);
    _15356 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15266);
    _15266 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15416;
    goto L1; // [3781] 10
L9E: 

    /** scanner.e:2032			elsif class = BACK_QUOTE then*/
    if (_class_27316 != -12LL)
    goto L9F; // [3788] 3805

    /** scanner.e:2033				return ExtendedString( '`' )*/
    _15418 = _62ExtendedString(96LL);
    DeRef(_i_27307);
    DeRef(_yytext_27310);
    DeRef(_namespaces_27311);
    DeRef(_d_27312);
    DeRef(_tok_27314);
    DeRef(_name_27317);
    DeRef(_15328);
    _15328 = NOVALUE;
    _15203 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15092 = NOVALUE;
    DeRef(_15281);
    _15281 = NOVALUE;
    DeRef(_15056);
    _15056 = NOVALUE;
    DeRef(_15285);
    _15285 = NOVALUE;
    DeRef(_15399);
    _15399 = NOVALUE;
    DeRef(_15286);
    _15286 = NOVALUE;
    DeRef(_15394);
    _15394 = NOVALUE;
    DeRef(_15410);
    _15410 = NOVALUE;
    DeRef(_15407);
    _15407 = NOVALUE;
    DeRef(_15373);
    _15373 = NOVALUE;
    _15207 = NOVALUE;
    _15296 = NOVALUE;
    DeRef(_15290);
    _15290 = NOVALUE;
    DeRef(_15243);
    _15243 = NOVALUE;
    _15322 = NOVALUE;
    DeRef(_15082);
    _15082 = NOVALUE;
    _15182 = NOVALUE;
    DeRef(_15388);
    _15388 = NOVALUE;
    DeRef(_15335);
    _15335 = NOVALUE;
    DeRef(_15413);
    _15413 = NOVALUE;
    DeRef(_15291);
    _15291 = NOVALUE;
    DeRef(_15059);
    _15059 = NOVALUE;
    _15229 = NOVALUE;
    DeRef(_15158);
    _15158 = NOVALUE;
    DeRef(_15302);
    _15302 = NOVALUE;
    DeRef(_15219);
    _15219 = NOVALUE;
    DeRef(_15390);
    _15390 = NOVALUE;
    DeRef(_15416);
    _15416 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15241);
    _15241 = NOVALUE;
    DeRef(_15351);
    _15351 = NOVALUE;
    DeRef(_15277);
    _15277 = NOVALUE;
    _15103 = NOVALUE;
    DeRef(_15309);
    _15309 = NOVALUE;
    DeRef(_15062);
    _15062 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15260);
    _15260 = NOVALUE;
    DeRef(_15050);
    _15050 = NOVALUE;
    _15114 = NOVALUE;
    DeRef(_15169);
    _15169 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    _15172 = NOVALUE;
    DeRef(_15113);
    _15113 = NOVALUE;
    DeRef(_15405);
    _15405 = NOVALUE;
    DeRef(_15211);
    _15211 = NOVALUE;
    DeRef(_15360);
    _15360 = NOVALUE;
    DeRef(_15346);
    _15346 = NOVALUE;
    _15078 = NOVALUE;
    DeRef(_15400);
    _15400 = NOVALUE;
    DeRef(_15036);
    _15036 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    DeRef(_15217);
    _15217 = NOVALUE;
    DeRef(_15053);
    _15053 = NOVALUE;
    _15225 = NOVALUE;
    DeRef(_15395);
    _15395 = NOVALUE;
    _15129 = NOVALUE;
    DeRef(_15184);
    _15184 = NOVALUE;
    DeRef(_15063);
    _15063 = NOVALUE;
    DeRef(_15404);
    _15404 = NOVALUE;
    DeRef(_15349);
    _15349 = NOVALUE;
    DeRef(_15163);
    _15163 = NOVALUE;
    DeRef(_15356);
    _15356 = NOVALUE;
    DeRef(_15066);
    _15066 = NOVALUE;
    DeRef(_15266);
    _15266 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15041);
    _15041 = NOVALUE;
    return _15418;
    goto L1; // [3802] 10
L9F: 

    /** scanner.e:2036				InternalErr(268, {class})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _class_27316;
    _15419 = MAKE_SEQ(_1);
    _50InternalErr(268LL, _15419);
    _15419 = NOVALUE;

    /** scanner.e:2039	   end while*/
    goto L1; // [3818] 10
L2: 
    ;
}


void _62eu_namespace()
{
    object _eu_tok_28109 = NOVALUE;
    object _eu_ns_28111 = NOVALUE;
    object _31710 = NOVALUE;
    object _31709 = NOVALUE;
    object _15428 = NOVALUE;
    object _15426 = NOVALUE;
    object _15424 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:2047		eu_tok = keyfind("eu", -1, , 1)*/
    RefDS(_15422);
    _31709 = _15422;
    _31710 = _54hashfn(_31709);
    _31709 = NOVALUE;
    RefDS(_15422);
    _0 = _eu_tok_28109;
    _eu_tok_28109 = _54keyfind(_15422, -1LL, _36current_file_no_21439, 1LL, _31710);
    DeRef(_0);
    _31710 = NOVALUE;

    /** scanner.e:2050		eu_ns  = NameSpace_declaration(eu_tok[T_SYM])*/
    _2 = (object)SEQ_PTR(_eu_tok_28109);
    _15424 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_15424);
    _eu_ns_28111 = _62NameSpace_declaration(_15424);
    _15424 = NOVALUE;
    if (!IS_ATOM_INT(_eu_ns_28111)) {
        _1 = (object)(DBL_PTR(_eu_ns_28111)->dbl);
        DeRefDS(_eu_ns_28111);
        _eu_ns_28111 = _1;
    }

    /** scanner.e:2051		SymTab[eu_ns][S_OBJ] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_eu_ns_28111 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _15426 = NOVALUE;

    /** scanner.e:2052		SymTab[eu_ns][S_SCOPE] = SC_GLOBAL*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_eu_ns_28111 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 6LL;
    DeRef(_1);
    _15428 = NOVALUE;

    /** scanner.e:2053	end procedure*/
    DeRef(_eu_tok_28109);
    return;
    ;
}


object _62StringToken(object _pDelims_28129)
{
    object _ch_28130 = NOVALUE;
    object _m_28131 = NOVALUE;
    object _gtext_28132 = NOVALUE;
    object _level_28163 = NOVALUE;
    object _15467 = NOVALUE;
    object _15465 = NOVALUE;
    object _15463 = NOVALUE;
    object _15444 = NOVALUE;
    object _15443 = NOVALUE;
    object _15437 = NOVALUE;
    object _15435 = NOVALUE;
    object _15433 = NOVALUE;
    object _15431 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:2064		ch = getch()*/
    _ch_28130 = _62getch();
    if (!IS_ATOM_INT(_ch_28130)) {
        _1 = (object)(DBL_PTR(_ch_28130)->dbl);
        DeRefDS(_ch_28130);
        _ch_28130 = _1;
    }

    /** scanner.e:2065		while ch = ' ' or ch = '\t' do*/
L1: 
    _15431 = (_ch_28130 == 32LL);
    if (_15431 != 0) {
        goto L2; // [19] 32
    }
    _15433 = (_ch_28130 == 9LL);
    if (_15433 == 0)
    {
        DeRef(_15433);
        _15433 = NOVALUE;
        goto L3; // [28] 44
    }
    else{
        DeRef(_15433);
        _15433 = NOVALUE;
    }
L2: 

    /** scanner.e:2066			ch = getch()*/
    _ch_28130 = _62getch();
    if (!IS_ATOM_INT(_ch_28130)) {
        _1 = (object)(DBL_PTR(_ch_28130)->dbl);
        DeRefDS(_ch_28130);
        _ch_28130 = _1;
    }

    /** scanner.e:2067		end while*/
    goto L1; // [41] 15
L3: 

    /** scanner.e:2069		pDelims &= {' ', '\t', '\n', '\r', END_OF_FILE_CHAR}*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 32LL;
    ((intptr_t*)_2)[2] = 9LL;
    ((intptr_t*)_2)[3] = 10LL;
    ((intptr_t*)_2)[4] = 13LL;
    ((intptr_t*)_2)[5] = 26LL;
    _15435 = MAKE_SEQ(_1);
    Concat((object_ptr)&_pDelims_28129, _pDelims_28129, _15435);
    DeRefDS(_15435);
    _15435 = NOVALUE;

    /** scanner.e:2070		gtext = ""*/
    RefDS(_5);
    DeRefi(_gtext_28132);
    _gtext_28132 = _5;

    /** scanner.e:2071		while not find(ch,  pDelims) label "top" do*/
L4: 
    _15437 = find_from(_ch_28130, _pDelims_28129, 1LL);
    if (_15437 != 0)
    goto L5; // [77] 391
    _15437 = NOVALUE;

    /** scanner.e:2072			if ch = '-' then*/
    if (_ch_28130 != 45LL)
    goto L6; // [82] 145

    /** scanner.e:2073				ch = getch()*/
    _ch_28130 = _62getch();
    if (!IS_ATOM_INT(_ch_28130)) {
        _1 = (object)(DBL_PTR(_ch_28130)->dbl);
        DeRefDS(_ch_28130);
        _ch_28130 = _1;
    }

    /** scanner.e:2074				if ch = '-' then*/
    if (_ch_28130 != 45LL)
    goto L7; // [95] 137

    /** scanner.e:2075					while not find(ch, {'\n', END_OF_FILE_CHAR}) do*/
L8: 
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 10LL;
    ((intptr_t *)_2)[2] = 26LL;
    _15443 = MAKE_SEQ(_1);
    _15444 = find_from(_ch_28130, _15443, 1LL);
    DeRefDS(_15443);
    _15443 = NOVALUE;
    if (_15444 != 0)
    goto L5; // [115] 391
    _15444 = NOVALUE;

    /** scanner.e:2076						ch = getch()*/
    _ch_28130 = _62getch();
    if (!IS_ATOM_INT(_ch_28130)) {
        _1 = (object)(DBL_PTR(_ch_28130)->dbl);
        DeRefDS(_ch_28130);
        _ch_28130 = _1;
    }

    /** scanner.e:2077					end while*/
    goto L8; // [127] 104

    /** scanner.e:2078					exit*/
    goto L5; // [132] 391
    goto L9; // [134] 373
L7: 

    /** scanner.e:2080					ungetch()*/
    _62ungetch();
    goto L9; // [142] 373
L6: 

    /** scanner.e:2082			elsif ch = '/' then*/
    if (_ch_28130 != 47LL)
    goto LA; // [147] 372

    /** scanner.e:2083				ch = getch()*/
    _ch_28130 = _62getch();
    if (!IS_ATOM_INT(_ch_28130)) {
        _1 = (object)(DBL_PTR(_ch_28130)->dbl);
        DeRefDS(_ch_28130);
        _ch_28130 = _1;
    }

    /** scanner.e:2084				if ch = '*' then*/
    if (_ch_28130 != 42LL)
    goto LB; // [160] 361

    /** scanner.e:2085					integer level = 1*/
    _level_28163 = 1LL;

    /** scanner.e:2086					while level > 0 do*/
LC: 
    if (_level_28163 <= 0LL)
    goto LD; // [174] 293

    /** scanner.e:2087						ch = getch()*/
    _ch_28130 = _62getch();
    if (!IS_ATOM_INT(_ch_28130)) {
        _1 = (object)(DBL_PTR(_ch_28130)->dbl);
        DeRefDS(_ch_28130);
        _ch_28130 = _1;
    }

    /** scanner.e:2088						if ch = '/' then*/
    if (_ch_28130 != 47LL)
    goto LE; // [187] 221

    /** scanner.e:2089							ch = getch()*/
    _ch_28130 = _62getch();
    if (!IS_ATOM_INT(_ch_28130)) {
        _1 = (object)(DBL_PTR(_ch_28130)->dbl);
        DeRefDS(_ch_28130);
        _ch_28130 = _1;
    }

    /** scanner.e:2090							if ch = '*' then*/
    if (_ch_28130 != 42LL)
    goto LF; // [200] 213

    /** scanner.e:2091								level += 1*/
    _level_28163 = _level_28163 + 1;
    goto LC; // [210] 174
LF: 

    /** scanner.e:2093								ungetch()*/
    _62ungetch();
    goto LC; // [218] 174
LE: 

    /** scanner.e:2095						elsif ch = '*' then*/
    if (_ch_28130 != 42LL)
    goto L10; // [223] 257

    /** scanner.e:2096							ch = getch()*/
    _ch_28130 = _62getch();
    if (!IS_ATOM_INT(_ch_28130)) {
        _1 = (object)(DBL_PTR(_ch_28130)->dbl);
        DeRefDS(_ch_28130);
        _ch_28130 = _1;
    }

    /** scanner.e:2097							if ch = '/' then*/
    if (_ch_28130 != 47LL)
    goto L11; // [236] 249

    /** scanner.e:2098								level -= 1*/
    _level_28163 = _level_28163 - 1LL;
    goto LC; // [246] 174
L11: 

    /** scanner.e:2100								ungetch()*/
    _62ungetch();
    goto LC; // [254] 174
L10: 

    /** scanner.e:2102						elsif ch = '\n' then*/
    if (_ch_28130 != 10LL)
    goto L12; // [259] 270

    /** scanner.e:2103							read_line()*/
    _62read_line();
    goto LC; // [267] 174
L12: 

    /** scanner.e:2104						elsif ch = END_OF_FILE_CHAR then*/
    if (_ch_28130 != 26LL)
    goto LC; // [274] 174

    /** scanner.e:2105							ungetch()*/
    _62ungetch();

    /** scanner.e:2106							exit*/
    goto LD; // [284] 293

    /** scanner.e:2108					end while*/
    goto LC; // [290] 174
LD: 

    /** scanner.e:2109					ch = getch()*/
    _ch_28130 = _62getch();
    if (!IS_ATOM_INT(_ch_28130)) {
        _1 = (object)(DBL_PTR(_ch_28130)->dbl);
        DeRefDS(_ch_28130);
        _ch_28130 = _1;
    }

    /** scanner.e:2110					if length(gtext) = 0 then*/
    if (IS_SEQUENCE(_gtext_28132)){
            _15463 = SEQ_PTR(_gtext_28132)->length;
    }
    else {
        _15463 = 1;
    }
    if (_15463 != 0LL)
    goto L13; // [305] 350

    /** scanner.e:2111						while ch = ' ' or ch = '\t' do*/
L14: 
    _15465 = (_ch_28130 == 32LL);
    if (_15465 != 0) {
        goto L15; // [318] 331
    }
    _15467 = (_ch_28130 == 9LL);
    if (_15467 == 0)
    {
        DeRef(_15467);
        _15467 = NOVALUE;
        goto L16; // [327] 343
    }
    else{
        DeRef(_15467);
        _15467 = NOVALUE;
    }
L15: 

    /** scanner.e:2112							ch = getch()*/
    _ch_28130 = _62getch();
    if (!IS_ATOM_INT(_ch_28130)) {
        _1 = (object)(DBL_PTR(_ch_28130)->dbl);
        DeRefDS(_ch_28130);
        _ch_28130 = _1;
    }

    /** scanner.e:2113						end while*/
    goto L14; // [340] 314
L16: 

    /** scanner.e:2114						continue "top"*/
    goto L4; // [347] 72
L13: 

    /** scanner.e:2116					exit*/
    goto L5; // [354] 391
    goto L17; // [358] 371
LB: 

    /** scanner.e:2119					ungetch()*/
    _62ungetch();

    /** scanner.e:2120					ch = '/'*/
    _ch_28130 = 47LL;
L17: 
LA: 
L9: 

    /** scanner.e:2123			gtext &= ch*/
    Append(&_gtext_28132, _gtext_28132, _ch_28130);

    /** scanner.e:2124			ch = getch()*/
    _ch_28130 = _62getch();
    if (!IS_ATOM_INT(_ch_28130)) {
        _1 = (object)(DBL_PTR(_ch_28130)->dbl);
        DeRefDS(_ch_28130);
        _ch_28130 = _1;
    }

    /** scanner.e:2125		end while*/
    goto L4; // [388] 72
L5: 

    /** scanner.e:2127		ungetch() -- put back end-word token.*/
    _62ungetch();

    /** scanner.e:2129		return gtext*/
    DeRefDSi(_pDelims_28129);
    DeRef(_15465);
    _15465 = NOVALUE;
    DeRef(_15431);
    _15431 = NOVALUE;
    return _gtext_28132;
    ;
}


void _62IncludeScan(object _is_public_28200)
{
    object _ch_28201 = NOVALUE;
    object _gtext_28202 = NOVALUE;
    object _s_28204 = NOVALUE;
    object _31708 = NOVALUE;
    object _15530 = NOVALUE;
    object _15529 = NOVALUE;
    object _15527 = NOVALUE;
    object _15525 = NOVALUE;
    object _15524 = NOVALUE;
    object _15519 = NOVALUE;
    object _15516 = NOVALUE;
    object _15514 = NOVALUE;
    object _15513 = NOVALUE;
    object _15511 = NOVALUE;
    object _15509 = NOVALUE;
    object _15507 = NOVALUE;
    object _15505 = NOVALUE;
    object _15499 = NOVALUE;
    object _15497 = NOVALUE;
    object _15492 = NOVALUE;
    object _15488 = NOVALUE;
    object _15487 = NOVALUE;
    object _15482 = NOVALUE;
    object _15479 = NOVALUE;
    object _15478 = NOVALUE;
    object _15474 = NOVALUE;
    object _15472 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:2149		ch = getch()*/
    _ch_28201 = _62getch();
    if (!IS_ATOM_INT(_ch_28201)) {
        _1 = (object)(DBL_PTR(_ch_28201)->dbl);
        DeRefDS(_ch_28201);
        _ch_28201 = _1;
    }

    /** scanner.e:2150		while ch = ' ' or ch = '\t' do*/
L1: 
    _15472 = (_ch_28201 == 32LL);
    if (_15472 != 0) {
        goto L2; // [19] 32
    }
    _15474 = (_ch_28201 == 9LL);
    if (_15474 == 0)
    {
        DeRef(_15474);
        _15474 = NOVALUE;
        goto L3; // [28] 44
    }
    else{
        DeRef(_15474);
        _15474 = NOVALUE;
    }
L2: 

    /** scanner.e:2151			ch = getch()*/
    _ch_28201 = _62getch();
    if (!IS_ATOM_INT(_ch_28201)) {
        _1 = (object)(DBL_PTR(_ch_28201)->dbl);
        DeRefDS(_ch_28201);
        _ch_28201 = _1;
    }

    /** scanner.e:2152		end while*/
    goto L1; // [41] 15
L3: 

    /** scanner.e:2155		gtext = ""*/
    RefDS(_5);
    DeRef(_gtext_28202);
    _gtext_28202 = _5;

    /** scanner.e:2157		if ch = '"' then*/
    if (_ch_28201 != 34LL)
    goto L4; // [53] 143

    /** scanner.e:2159			ch = getch()*/
    _ch_28201 = _62getch();
    if (!IS_ATOM_INT(_ch_28201)) {
        _1 = (object)(DBL_PTR(_ch_28201)->dbl);
        DeRefDS(_ch_28201);
        _ch_28201 = _1;
    }

    /** scanner.e:2160			while not find(ch, {'\n', '\r', '"', END_OF_FILE_CHAR}) do*/
L5: 
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 10LL;
    ((intptr_t*)_2)[2] = 13LL;
    ((intptr_t*)_2)[3] = 34LL;
    ((intptr_t*)_2)[4] = 26LL;
    _15478 = MAKE_SEQ(_1);
    _15479 = find_from(_ch_28201, _15478, 1LL);
    DeRefDS(_15478);
    _15478 = NOVALUE;
    if (_15479 != 0)
    goto L6; // [83] 124
    _15479 = NOVALUE;

    /** scanner.e:2161				if ch = '\\' then*/
    if (_ch_28201 != 92LL)
    goto L7; // [88] 105

    /** scanner.e:2162					gtext &= EscapeChar('"')*/
    _15482 = _62EscapeChar(34LL);
    if (IS_SEQUENCE(_gtext_28202) && IS_ATOM(_15482)) {
        Ref(_15482);
        Append(&_gtext_28202, _gtext_28202, _15482);
    }
    else if (IS_ATOM(_gtext_28202) && IS_SEQUENCE(_15482)) {
    }
    else {
        Concat((object_ptr)&_gtext_28202, _gtext_28202, _15482);
    }
    DeRef(_15482);
    _15482 = NOVALUE;
    goto L8; // [102] 112
L7: 

    /** scanner.e:2164					gtext &= ch*/
    Append(&_gtext_28202, _gtext_28202, _ch_28201);
L8: 

    /** scanner.e:2166				ch = getch()*/
    _ch_28201 = _62getch();
    if (!IS_ATOM_INT(_ch_28201)) {
        _1 = (object)(DBL_PTR(_ch_28201)->dbl);
        DeRefDS(_ch_28201);
        _ch_28201 = _1;
    }

    /** scanner.e:2167			end while*/
    goto L5; // [121] 69
L6: 

    /** scanner.e:2168			if ch != '"' then*/
    if (_ch_28201 == 34LL)
    goto L9; // [126] 189

    /** scanner.e:2169				CompileErr(MISSING_CLOSING_QUOTE_ON_FILE_NAME)*/
    RefDS(_21993);
    _50CompileErr(115LL, _21993, 0LL);
    goto L9; // [140] 189
L4: 

    /** scanner.e:2173			while not find(ch, {' ', '\t', '\n', '\r', END_OF_FILE_CHAR}) do*/
LA: 
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 32LL;
    ((intptr_t*)_2)[2] = 9LL;
    ((intptr_t*)_2)[3] = 10LL;
    ((intptr_t*)_2)[4] = 13LL;
    ((intptr_t*)_2)[5] = 26LL;
    _15487 = MAKE_SEQ(_1);
    _15488 = find_from(_ch_28201, _15487, 1LL);
    DeRefDS(_15487);
    _15487 = NOVALUE;
    if (_15488 != 0)
    goto LB; // [163] 184
    _15488 = NOVALUE;

    /** scanner.e:2174				gtext &= ch*/
    Append(&_gtext_28202, _gtext_28202, _ch_28201);

    /** scanner.e:2175				ch = getch()*/
    _ch_28201 = _62getch();
    if (!IS_ATOM_INT(_ch_28201)) {
        _1 = (object)(DBL_PTR(_ch_28201)->dbl);
        DeRefDS(_ch_28201);
        _ch_28201 = _1;
    }

    /** scanner.e:2176			end while*/
    goto LA; // [181] 148
LB: 

    /** scanner.e:2177			ungetch()*/
    _62ungetch();
L9: 

    /** scanner.e:2180		if length(gtext) = 0 then*/
    if (IS_SEQUENCE(_gtext_28202)){
            _15492 = SEQ_PTR(_gtext_28202)->length;
    }
    else {
        _15492 = 1;
    }
    if (_15492 != 0LL)
    goto LC; // [194] 208

    /** scanner.e:2181			CompileErr(FILE_NAME_IS_MISSING)*/
    RefDS(_21993);
    _50CompileErr(95LL, _21993, 0LL);
LC: 

    /** scanner.e:2185		ifdef WINDOWS then*/

    /** scanner.e:2188			new_include_name = gtext*/
    RefDS(_gtext_28202);
    DeRef(_36new_include_name_21565);
    _36new_include_name_21565 = _gtext_28202;

    /** scanner.e:2192		ch = getch()*/
    _ch_28201 = _62getch();
    if (!IS_ATOM_INT(_ch_28201)) {
        _1 = (object)(DBL_PTR(_ch_28201)->dbl);
        DeRefDS(_ch_28201);
        _ch_28201 = _1;
    }

    /** scanner.e:2193		while ch = ' ' or ch = '\t' do*/
LD: 
    _15497 = (_ch_28201 == 32LL);
    if (_15497 != 0) {
        goto LE; // [233] 246
    }
    _15499 = (_ch_28201 == 9LL);
    if (_15499 == 0)
    {
        DeRef(_15499);
        _15499 = NOVALUE;
        goto LF; // [242] 258
    }
    else{
        DeRef(_15499);
        _15499 = NOVALUE;
    }
LE: 

    /** scanner.e:2194			ch = getch()*/
    _ch_28201 = _62getch();
    if (!IS_ATOM_INT(_ch_28201)) {
        _1 = (object)(DBL_PTR(_ch_28201)->dbl);
        DeRefDS(_ch_28201);
        _ch_28201 = _1;
    }

    /** scanner.e:2195		end while*/
    goto LD; // [255] 229
LF: 

    /** scanner.e:2197		new_include_space = 0*/
    _62new_include_space_25545 = 0LL;

    /** scanner.e:2199		if ch = 'a' then*/
    if (_ch_28201 != 97LL)
    goto L10; // [267] 532

    /** scanner.e:2201			ch = getch()*/
    _ch_28201 = _62getch();
    if (!IS_ATOM_INT(_ch_28201)) {
        _1 = (object)(DBL_PTR(_ch_28201)->dbl);
        DeRefDS(_ch_28201);
        _ch_28201 = _1;
    }

    /** scanner.e:2202			if ch = 's' then*/
    if (_ch_28201 != 115LL)
    goto L11; // [280] 519

    /** scanner.e:2203				ch = getch()*/
    _ch_28201 = _62getch();
    if (!IS_ATOM_INT(_ch_28201)) {
        _1 = (object)(DBL_PTR(_ch_28201)->dbl);
        DeRefDS(_ch_28201);
        _ch_28201 = _1;
    }

    /** scanner.e:2204				if ch = ' ' or ch = '\t' then*/
    _15505 = (_ch_28201 == 32LL);
    if (_15505 != 0) {
        goto L12; // [297] 310
    }
    _15507 = (_ch_28201 == 9LL);
    if (_15507 == 0)
    {
        DeRef(_15507);
        _15507 = NOVALUE;
        goto L13; // [306] 506
    }
    else{
        DeRef(_15507);
        _15507 = NOVALUE;
    }
L12: 

    /** scanner.e:2207					ch = getch()*/
    _ch_28201 = _62getch();
    if (!IS_ATOM_INT(_ch_28201)) {
        _1 = (object)(DBL_PTR(_ch_28201)->dbl);
        DeRefDS(_ch_28201);
        _ch_28201 = _1;
    }

    /** scanner.e:2208					while ch = ' ' or ch = '\t' do*/
L14: 
    _15509 = (_ch_28201 == 32LL);
    if (_15509 != 0) {
        goto L15; // [326] 339
    }
    _15511 = (_ch_28201 == 9LL);
    if (_15511 == 0)
    {
        DeRef(_15511);
        _15511 = NOVALUE;
        goto L16; // [335] 351
    }
    else{
        DeRef(_15511);
        _15511 = NOVALUE;
    }
L15: 

    /** scanner.e:2209						ch = getch()*/
    _ch_28201 = _62getch();
    if (!IS_ATOM_INT(_ch_28201)) {
        _1 = (object)(DBL_PTR(_ch_28201)->dbl);
        DeRefDS(_ch_28201);
        _ch_28201 = _1;
    }

    /** scanner.e:2210					end while*/
    goto L14; // [348] 322
L16: 

    /** scanner.e:2213					if char_class[ch] = LETTER or ch = '_' then*/
    _2 = (object)SEQ_PTR(_62char_class_25554);
    _15513 = (object)*(((s1_ptr)_2)->base + _ch_28201);
    _15514 = (_15513 == -2LL);
    _15513 = NOVALUE;
    if (_15514 != 0) {
        goto L17; // [365] 378
    }
    _15516 = (_ch_28201 == 95LL);
    if (_15516 == 0)
    {
        DeRef(_15516);
        _15516 = NOVALUE;
        goto L18; // [374] 493
    }
    else{
        DeRef(_15516);
        _15516 = NOVALUE;
    }
L17: 

    /** scanner.e:2214						gtext = {ch}*/
    _0 = _gtext_28202;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _ch_28201;
    _gtext_28202 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scanner.e:2215						ch = getch()*/
    _ch_28201 = _62getch();
    if (!IS_ATOM_INT(_ch_28201)) {
        _1 = (object)(DBL_PTR(_ch_28201)->dbl);
        DeRefDS(_ch_28201);
        _ch_28201 = _1;
    }

    /** scanner.e:2216						while id_char[ch] = TRUE do*/
L19: 
    _2 = (object)SEQ_PTR(_62id_char_25555);
    _15519 = (object)*(((s1_ptr)_2)->base + _ch_28201);
    if (_15519 != _13TRUE_452)
    goto L1A; // [404] 426

    /** scanner.e:2217							gtext &= ch*/
    Append(&_gtext_28202, _gtext_28202, _ch_28201);

    /** scanner.e:2218							ch = getch()*/
    _ch_28201 = _62getch();
    if (!IS_ATOM_INT(_ch_28201)) {
        _1 = (object)(DBL_PTR(_ch_28201)->dbl);
        DeRefDS(_ch_28201);
        _ch_28201 = _1;
    }

    /** scanner.e:2219						end while*/
    goto L19; // [423] 396
L1A: 

    /** scanner.e:2221						ungetch()*/
    _62ungetch();

    /** scanner.e:2222						s = keyfind(gtext, -1, , 1)*/
    RefDS(_gtext_28202);
    _31708 = _54hashfn(_gtext_28202);
    RefDS(_gtext_28202);
    _0 = _s_28204;
    _s_28204 = _54keyfind(_gtext_28202, -1LL, _36current_file_no_21439, 1LL, _31708);
    DeRef(_0);
    _31708 = NOVALUE;

    /** scanner.e:2223						if not find(s[T_ID], ID_TOKS) then*/
    _2 = (object)SEQ_PTR(_s_28204);
    _15524 = (object)*(((s1_ptr)_2)->base + 1LL);
    _15525 = find_from(_15524, _38ID_TOKS_16051, 1LL);
    _15524 = NOVALUE;
    if (_15525 != 0)
    goto L1B; // [463] 476
    _15525 = NOVALUE;

    /** scanner.e:2224							CompileErr(A_NEW_NAMESPACE_IDENTIFIER_IS_EXPECTED_HERE)*/
    RefDS(_21993);
    _50CompileErr(36LL, _21993, 0LL);
L1B: 

    /** scanner.e:2226						new_include_space = NameSpace_declaration(s[T_SYM])*/
    _2 = (object)SEQ_PTR(_s_28204);
    _15527 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_15527);
    _0 = _62NameSpace_declaration(_15527);
    _62new_include_space_25545 = _0;
    _15527 = NOVALUE;
    if (!IS_ATOM_INT(_62new_include_space_25545)) {
        _1 = (object)(DBL_PTR(_62new_include_space_25545)->dbl);
        DeRefDS(_62new_include_space_25545);
        _62new_include_space_25545 = _1;
    }
    goto L1C; // [490] 647
L18: 

    /** scanner.e:2228						CompileErr(MISSING_NAMESPACE_QUALIFIER)*/
    RefDS(_21993);
    _50CompileErr(113LL, _21993, 0LL);
    goto L1C; // [503] 647
L13: 

    /** scanner.e:2231					CompileErr(EXPECTING_AS_OR_ENDOF_LINE_UNEXPECTED_TEXT_ON_INCLUDE_DIRECTIVE)*/
    RefDS(_21993);
    _50CompileErr(100LL, _21993, 0LL);
    goto L1C; // [516] 647
L11: 

    /** scanner.e:2234				CompileErr(EXPECTING_AS_OR_ENDOF_LINE_UNEXPECTED_TEXT_ON_INCLUDE_DIRECTIVE)*/
    RefDS(_21993);
    _50CompileErr(100LL, _21993, 0LL);
    goto L1C; // [529] 647
L10: 

    /** scanner.e:2237		elsif find(ch, {'\n', '\r', END_OF_FILE_CHAR}) then*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 10LL;
    ((intptr_t*)_2)[2] = 13LL;
    ((intptr_t*)_2)[3] = 26LL;
    _15529 = MAKE_SEQ(_1);
    _15530 = find_from(_ch_28201, _15529, 1LL);
    DeRefDS(_15529);
    _15529 = NOVALUE;
    if (_15530 == 0)
    {
        _15530 = NOVALUE;
        goto L1D; // [547] 557
    }
    else{
        _15530 = NOVALUE;
    }

    /** scanner.e:2238			ungetch()*/
    _62ungetch();
    goto L1C; // [554] 647
L1D: 

    /** scanner.e:2240		elsif ch = '-' then*/
    if (_ch_28201 != 45LL)
    goto L1E; // [559] 597

    /** scanner.e:2241			ch = getch()*/
    _ch_28201 = _62getch();
    if (!IS_ATOM_INT(_ch_28201)) {
        _1 = (object)(DBL_PTR(_ch_28201)->dbl);
        DeRefDS(_ch_28201);
        _ch_28201 = _1;
    }

    /** scanner.e:2242			if ch != '-' then*/
    if (_ch_28201 == 45LL)
    goto L1F; // [572] 586

    /** scanner.e:2243				CompileErr(EXPECTING_AS_OR_ENDOF_LINE_UNEXPECTED_TEXT_ON_INCLUDE_DIRECTIVE)*/
    RefDS(_21993);
    _50CompileErr(100LL, _21993, 0LL);
L1F: 

    /** scanner.e:2245			ungetch()*/
    _62ungetch();

    /** scanner.e:2246			ungetch()*/
    _62ungetch();
    goto L1C; // [594] 647
L1E: 

    /** scanner.e:2248		elsif ch = '/' then*/
    if (_ch_28201 != 47LL)
    goto L20; // [599] 637

    /** scanner.e:2249			ch = getch()*/
    _ch_28201 = _62getch();
    if (!IS_ATOM_INT(_ch_28201)) {
        _1 = (object)(DBL_PTR(_ch_28201)->dbl);
        DeRefDS(_ch_28201);
        _ch_28201 = _1;
    }

    /** scanner.e:2250			if ch != '*' then*/
    if (_ch_28201 == 42LL)
    goto L21; // [612] 626

    /** scanner.e:2251				CompileErr(EXPECTING_AS_OR_ENDOF_LINE_UNEXPECTED_TEXT_ON_INCLUDE_DIRECTIVE)*/
    RefDS(_21993);
    _50CompileErr(100LL, _21993, 0LL);
L21: 

    /** scanner.e:2253			ungetch()*/
    _62ungetch();

    /** scanner.e:2254			ungetch()*/
    _62ungetch();
    goto L1C; // [634] 647
L20: 

    /** scanner.e:2257			CompileErr(EXPECTING_AS_OR_ENDOF_LINE_UNEXPECTED_TEXT_ON_INCLUDE_DIRECTIVE)*/
    RefDS(_21993);
    _50CompileErr(100LL, _21993, 0LL);
L1C: 

    /** scanner.e:2260		start_include = TRUE -- let scanner know*/
    _62start_include_25547 = _13TRUE_452;

    /** scanner.e:2261		public_include = is_public*/
    _62public_include_25550 = _is_public_28200;

    /** scanner.e:2262	end procedure*/
    DeRef(_gtext_28202);
    DeRef(_s_28204);
    DeRef(_15472);
    _15472 = NOVALUE;
    _15519 = NOVALUE;
    DeRef(_15509);
    _15509 = NOVALUE;
    DeRef(_15514);
    _15514 = NOVALUE;
    DeRef(_15505);
    _15505 = NOVALUE;
    DeRef(_15497);
    _15497 = NOVALUE;
    return;
    ;
}


void _62main_file()
{
    object _15539 = NOVALUE;
    object _15538 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:2275		if repl and top_level_block = -1 then*/
    if (0LL == 0) {
        goto L1; // [5] 29
    }
    _15539 = (_65top_level_block_25115 == -1LL);
    if (_15539 == 0)
    {
        DeRef(_15539);
        _15539 = NOVALUE;
        goto L1; // [16] 29
    }
    else{
        DeRef(_15539);
        _15539 = NOVALUE;
    }

    /** scanner.e:2276			top_level_block = current_block*/
    _65top_level_block_25115 = _65current_block_25114;
L1: 

    /** scanner.e:2278		ifdef STDDEBUG then*/

    /** scanner.e:2283			read_line()*/
    _62read_line();

    /** scanner.e:2284			default_namespace( )*/
    _62default_namespace();

    /** scanner.e:2286	end procedure*/
    return;
    ;
}


void _62cleanup_open_includes()
{
    object _15542 = NOVALUE;
    object _15541 = NOVALUE;
    object _15540 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:2289		for i = 1 to length( IncludeStk ) do*/
    if (IS_SEQUENCE(_62IncludeStk_25556)){
            _15540 = SEQ_PTR(_62IncludeStk_25556)->length;
    }
    else {
        _15540 = 1;
    }
    {
        object _i_28339;
        _i_28339 = 1LL;
L1: 
        if (_i_28339 > _15540){
            goto L2; // [8] 36
        }

        /** scanner.e:2290			close( IncludeStk[i][FILE_PTR] )*/
        _2 = (object)SEQ_PTR(_62IncludeStk_25556);
        _15541 = (object)*(((s1_ptr)_2)->base + _i_28339);
        _2 = (object)SEQ_PTR(_15541);
        _15542 = (object)*(((s1_ptr)_2)->base + 3LL);
        _15541 = NOVALUE;
        if (IS_ATOM_INT(_15542))
        EClose(_15542);
        else
        EClose((object)DBL_PTR(_15542)->dbl);
        _15542 = NOVALUE;

        /** scanner.e:2291		end for*/
        _i_28339 = _i_28339 + 1LL;
        goto L1; // [31] 15
L2: 
        ;
    }

    /** scanner.e:2292	end procedure*/
    return;
    ;
}



// 0x643A30D1
