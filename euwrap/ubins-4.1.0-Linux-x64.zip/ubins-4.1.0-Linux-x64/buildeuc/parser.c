// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _45EndLineTable()
{
    object _0, _1, _2;
    

    /** parser.e:120		LineTable = append(LineTable, -2)*/
    Append(&_36LineTable_21532, _36LineTable_21532, -2LL);

    /** parser.e:121	end procedure*/
    return;
    ;
}


void _45CreateTopLevel()
{
    object _27791 = NOVALUE;
    object _27789 = NOVALUE;
    object _27787 = NOVALUE;
    object _27785 = NOVALUE;
    object _27783 = NOVALUE;
    object _27781 = NOVALUE;
    object _27779 = NOVALUE;
    object _27777 = NOVALUE;
    object _27775 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:125		SymTab[TopLevelSub][S_NUM_ARGS] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21446 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21127))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _27775 = NOVALUE;

    /** parser.e:126		SymTab[TopLevelSub][S_TEMPS] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21446 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_TEMPS_21121))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TEMPS_21121)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_TEMPS_21121);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _27777 = NOVALUE;

    /** parser.e:127		SymTab[TopLevelSub][S_CODE] = {}*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21446 + ((s1_ptr)_2)->base);
    RefDS(_21993);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21088))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21088);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _21993;
    DeRef(_1);
    _27779 = NOVALUE;

    /** parser.e:128		SymTab[TopLevelSub][S_LINETAB] = {}*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21446 + ((s1_ptr)_2)->base);
    RefDS(_21993);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_LINETAB_21111))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21111)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21111);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _21993;
    DeRef(_1);
    _27781 = NOVALUE;

    /** parser.e:129		SymTab[TopLevelSub][S_FIRSTLINE] = 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21446 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_FIRSTLINE_21116))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FIRSTLINE_21116)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_FIRSTLINE_21116);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _27783 = NOVALUE;

    /** parser.e:130		SymTab[TopLevelSub][S_REFLIST] = {}*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21446 + ((s1_ptr)_2)->base);
    RefDS(_21993);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 24LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _21993;
    DeRef(_1);
    _27785 = NOVALUE;

    /** parser.e:131		SymTab[TopLevelSub][S_NREFS] = 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21446 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _27787 = NOVALUE;

    /** parser.e:132		SymTab[TopLevelSub][S_RESIDENT_TASK] = 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21446 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _27789 = NOVALUE;

    /** parser.e:133		SymTab[TopLevelSub][S_SAVED_PRIVATES] = {}*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21446 + ((s1_ptr)_2)->base);
    RefDS(_21993);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 26LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _21993;
    DeRef(_1);
    _27791 = NOVALUE;

    /** parser.e:135		Start_block( PROC, TopLevelSub )*/
    _65Start_block(27LL, _36TopLevelSub_21446);

    /** parser.e:136	end procedure*/
    return;
    ;
}


void _45CheckForUndefinedGotoLabels()
{
    object _27805 = NOVALUE;
    object _27804 = NOVALUE;
    object _27801 = NOVALUE;
    object _27799 = NOVALUE;
    object _27797 = NOVALUE;
    object _27795 = NOVALUE;
    object _27794 = NOVALUE;
    object _27793 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:139		for i = 1 to length(goto_delay) do*/
    if (IS_SEQUENCE(_36goto_delay_21553)){
            _27793 = SEQ_PTR(_36goto_delay_21553)->length;
    }
    else {
        _27793 = 1;
    }
    {
        object _i_55028;
        _i_55028 = 1LL;
L1: 
        if (_i_55028 > _27793){
            goto L2; // [8] 106
        }

        /** parser.e:140			if not equal(goto_delay[i],"") then*/
        _2 = (object)SEQ_PTR(_36goto_delay_21553);
        _27794 = (object)*(((s1_ptr)_2)->base + _i_55028);
        if (_27794 == _21993)
        _27795 = 1;
        else if (IS_ATOM_INT(_27794) && IS_ATOM_INT(_21993))
        _27795 = 0;
        else
        _27795 = (compare(_27794, _21993) == 0);
        _27794 = NOVALUE;
        if (_27795 != 0)
        goto L3; // [27] 99
        _27795 = NOVALUE;

        /** parser.e:141				line_number = goto_line[i][1] -- tell compiler the correct line number*/
        _2 = (object)SEQ_PTR(_45goto_line_54934);
        _27797 = (object)*(((s1_ptr)_2)->base + _i_55028);
        _2 = (object)SEQ_PTR(_27797);
        _36line_number_21440 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (!IS_ATOM_INT(_36line_number_21440)){
            _36line_number_21440 = (object)DBL_PTR(_36line_number_21440)->dbl;
        }
        _27797 = NOVALUE;

        /** parser.e:142				gline_number = goto_line[i][1] -- tell compiler the correct line number*/
        _2 = (object)SEQ_PTR(_45goto_line_54934);
        _27799 = (object)*(((s1_ptr)_2)->base + _i_55028);
        _2 = (object)SEQ_PTR(_27799);
        _36gline_number_21444 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (!IS_ATOM_INT(_36gline_number_21444)){
            _36gline_number_21444 = (object)DBL_PTR(_36gline_number_21444)->dbl;
        }
        _27799 = NOVALUE;

        /** parser.e:143				ThisLine = goto_line[i][2] -- tell compiler the correct line number*/
        _2 = (object)SEQ_PTR(_45goto_line_54934);
        _27801 = (object)*(((s1_ptr)_2)->base + _i_55028);
        DeRef(_50ThisLine_49234);
        _2 = (object)SEQ_PTR(_27801);
        _50ThisLine_49234 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_50ThisLine_49234);
        _27801 = NOVALUE;

        /** parser.e:144				bp = length(ThisLine)*/
        if (IS_SEQUENCE(_50ThisLine_49234)){
                _50bp_49238 = SEQ_PTR(_50ThisLine_49234)->length;
        }
        else {
            _50bp_49238 = 1;
        }

        /** parser.e:145					CompileErr(UNKNOWN_LABEL_1, {goto_delay[i]})*/
        _2 = (object)SEQ_PTR(_36goto_delay_21553);
        _27804 = (object)*(((s1_ptr)_2)->base + _i_55028);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_27804);
        ((intptr_t*)_2)[1] = _27804;
        _27805 = MAKE_SEQ(_1);
        _27804 = NOVALUE;
        _50CompileErr(156LL, _27805, 0LL);
        _27805 = NOVALUE;
L3: 

        /** parser.e:147		end for*/
        _i_55028 = _i_55028 + 1LL;
        goto L1; // [101] 15
L2: 
        ;
    }

    /** parser.e:148	end procedure*/
    return;
    ;
}


void _45PushGoto()
{
    object _new_1__tmp_at88_55063 = NOVALUE;
    object _new_inlined_new_at_88_55062 = NOVALUE;
    object _27806 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:151		goto_stack = append(goto_stack, {goto_addr, goto_list, goto_labels, goto_delay, goto_line, goto_ref, label_block, goto_init })*/
    _1 = NewS1(8);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_45goto_addr_54936);
    ((intptr_t*)_2)[1] = _45goto_addr_54936;
    RefDS(_36goto_list_21554);
    ((intptr_t*)_2)[2] = _36goto_list_21554;
    RefDS(_45goto_labels_54935);
    ((intptr_t*)_2)[3] = _45goto_labels_54935;
    RefDS(_36goto_delay_21553);
    ((intptr_t*)_2)[4] = _36goto_delay_21553;
    RefDS(_45goto_line_54934);
    ((intptr_t*)_2)[5] = _45goto_line_54934;
    RefDS(_45goto_ref_54938);
    ((intptr_t*)_2)[6] = _45goto_ref_54938;
    RefDS(_45label_block_54939);
    ((intptr_t*)_2)[7] = _45label_block_54939;
    Ref(_45goto_init_54941);
    ((intptr_t*)_2)[8] = _45goto_init_54941;
    _27806 = MAKE_SEQ(_1);
    RefDS(_27806);
    Append(&_45goto_stack_54937, _45goto_stack_54937, _27806);
    DeRefDS(_27806);
    _27806 = NOVALUE;

    /** parser.e:152		goto_addr = {}*/
    RefDS(_21993);
    DeRefDS(_45goto_addr_54936);
    _45goto_addr_54936 = _21993;

    /** parser.e:153		goto_list = {}*/
    RefDS(_21993);
    DeRefDS(_36goto_list_21554);
    _36goto_list_21554 = _21993;

    /** parser.e:154		goto_labels = {}*/
    RefDS(_21993);
    DeRefDS(_45goto_labels_54935);
    _45goto_labels_54935 = _21993;

    /** parser.e:155		goto_delay = {}*/
    RefDS(_21993);
    DeRefDS(_36goto_delay_21553);
    _36goto_delay_21553 = _21993;

    /** parser.e:156		goto_line = {}*/
    RefDS(_21993);
    DeRefDS(_45goto_line_54934);
    _45goto_line_54934 = _21993;

    /** parser.e:157		goto_ref = {}*/
    RefDS(_21993);
    DeRefDS(_45goto_ref_54938);
    _45goto_ref_54938 = _21993;

    /** parser.e:158		label_block = {}*/
    RefDS(_21993);
    DeRefDS(_45label_block_54939);
    _45label_block_54939 = _21993;

    /** parser.e:159		goto_init = map:new()*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at88_55063;
    _new_1__tmp_at88_55063 = _29new_map_seq(8LL);
    DeRef(_0);
    Ref(_new_1__tmp_at88_55063);
    _0 = _30malloc(_new_1__tmp_at88_55063, 1LL);
    DeRef(_45goto_init_54941);
    _45goto_init_54941 = _0;
    DeRef(_new_1__tmp_at88_55063);
    _new_1__tmp_at88_55063 = NOVALUE;

    /** parser.e:160	end procedure*/
    return;
    ;
}


void _45PopGoto()
{
    object _27832 = NOVALUE;
    object _27830 = NOVALUE;
    object _27829 = NOVALUE;
    object _27827 = NOVALUE;
    object _27826 = NOVALUE;
    object _27824 = NOVALUE;
    object _27823 = NOVALUE;
    object _27821 = NOVALUE;
    object _27820 = NOVALUE;
    object _27818 = NOVALUE;
    object _27817 = NOVALUE;
    object _27815 = NOVALUE;
    object _27814 = NOVALUE;
    object _27812 = NOVALUE;
    object _27811 = NOVALUE;
    object _27809 = NOVALUE;
    object _27808 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:163		CheckForUndefinedGotoLabels()*/
    _45CheckForUndefinedGotoLabels();

    /** parser.e:164		goto_addr   = goto_stack[$][1]*/
    if (IS_SEQUENCE(_45goto_stack_54937)){
            _27808 = SEQ_PTR(_45goto_stack_54937)->length;
    }
    else {
        _27808 = 1;
    }
    _2 = (object)SEQ_PTR(_45goto_stack_54937);
    _27809 = (object)*(((s1_ptr)_2)->base + _27808);
    DeRef(_45goto_addr_54936);
    _2 = (object)SEQ_PTR(_27809);
    _45goto_addr_54936 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_45goto_addr_54936);
    _27809 = NOVALUE;

    /** parser.e:165		goto_list   = goto_stack[$][2]*/
    if (IS_SEQUENCE(_45goto_stack_54937)){
            _27811 = SEQ_PTR(_45goto_stack_54937)->length;
    }
    else {
        _27811 = 1;
    }
    _2 = (object)SEQ_PTR(_45goto_stack_54937);
    _27812 = (object)*(((s1_ptr)_2)->base + _27811);
    DeRef(_36goto_list_21554);
    _2 = (object)SEQ_PTR(_27812);
    _36goto_list_21554 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_36goto_list_21554);
    _27812 = NOVALUE;

    /** parser.e:166		goto_labels = goto_stack[$][3]*/
    if (IS_SEQUENCE(_45goto_stack_54937)){
            _27814 = SEQ_PTR(_45goto_stack_54937)->length;
    }
    else {
        _27814 = 1;
    }
    _2 = (object)SEQ_PTR(_45goto_stack_54937);
    _27815 = (object)*(((s1_ptr)_2)->base + _27814);
    DeRef(_45goto_labels_54935);
    _2 = (object)SEQ_PTR(_27815);
    _45goto_labels_54935 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_45goto_labels_54935);
    _27815 = NOVALUE;

    /** parser.e:167		goto_delay  = goto_stack[$][4]*/
    if (IS_SEQUENCE(_45goto_stack_54937)){
            _27817 = SEQ_PTR(_45goto_stack_54937)->length;
    }
    else {
        _27817 = 1;
    }
    _2 = (object)SEQ_PTR(_45goto_stack_54937);
    _27818 = (object)*(((s1_ptr)_2)->base + _27817);
    DeRef(_36goto_delay_21553);
    _2 = (object)SEQ_PTR(_27818);
    _36goto_delay_21553 = (object)*(((s1_ptr)_2)->base + 4LL);
    Ref(_36goto_delay_21553);
    _27818 = NOVALUE;

    /** parser.e:168		goto_line   = goto_stack[$][5]*/
    if (IS_SEQUENCE(_45goto_stack_54937)){
            _27820 = SEQ_PTR(_45goto_stack_54937)->length;
    }
    else {
        _27820 = 1;
    }
    _2 = (object)SEQ_PTR(_45goto_stack_54937);
    _27821 = (object)*(((s1_ptr)_2)->base + _27820);
    DeRef(_45goto_line_54934);
    _2 = (object)SEQ_PTR(_27821);
    _45goto_line_54934 = (object)*(((s1_ptr)_2)->base + 5LL);
    Ref(_45goto_line_54934);
    _27821 = NOVALUE;

    /** parser.e:169		goto_ref    = goto_stack[$][6]*/
    if (IS_SEQUENCE(_45goto_stack_54937)){
            _27823 = SEQ_PTR(_45goto_stack_54937)->length;
    }
    else {
        _27823 = 1;
    }
    _2 = (object)SEQ_PTR(_45goto_stack_54937);
    _27824 = (object)*(((s1_ptr)_2)->base + _27823);
    DeRef(_45goto_ref_54938);
    _2 = (object)SEQ_PTR(_27824);
    _45goto_ref_54938 = (object)*(((s1_ptr)_2)->base + 6LL);
    Ref(_45goto_ref_54938);
    _27824 = NOVALUE;

    /** parser.e:170		label_block = goto_stack[$][7]*/
    if (IS_SEQUENCE(_45goto_stack_54937)){
            _27826 = SEQ_PTR(_45goto_stack_54937)->length;
    }
    else {
        _27826 = 1;
    }
    _2 = (object)SEQ_PTR(_45goto_stack_54937);
    _27827 = (object)*(((s1_ptr)_2)->base + _27826);
    DeRef(_45label_block_54939);
    _2 = (object)SEQ_PTR(_27827);
    _45label_block_54939 = (object)*(((s1_ptr)_2)->base + 7LL);
    Ref(_45label_block_54939);
    _27827 = NOVALUE;

    /** parser.e:171		goto_init   = goto_stack[$][8]*/
    if (IS_SEQUENCE(_45goto_stack_54937)){
            _27829 = SEQ_PTR(_45goto_stack_54937)->length;
    }
    else {
        _27829 = 1;
    }
    _2 = (object)SEQ_PTR(_45goto_stack_54937);
    _27830 = (object)*(((s1_ptr)_2)->base + _27829);
    DeRef(_45goto_init_54941);
    _2 = (object)SEQ_PTR(_27830);
    _45goto_init_54941 = (object)*(((s1_ptr)_2)->base + 8LL);
    Ref(_45goto_init_54941);
    _27830 = NOVALUE;

    /** parser.e:173		goto_stack = remove( goto_stack, length( goto_stack ) )*/
    if (IS_SEQUENCE(_45goto_stack_54937)){
            _27832 = SEQ_PTR(_45goto_stack_54937)->length;
    }
    else {
        _27832 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_45goto_stack_54937);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_27832)) ? _27832 : (object)(DBL_PTR(_27832)->dbl);
        int stop = (IS_ATOM_INT(_27832)) ? _27832 : (object)(DBL_PTR(_27832)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_45goto_stack_54937), start, &_45goto_stack_54937 );
            }
            else Tail(SEQ_PTR(_45goto_stack_54937), stop+1, &_45goto_stack_54937);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_45goto_stack_54937), start, &_45goto_stack_54937);
        }
        else {
            assign_slice_seq = &assign_space;
            _45goto_stack_54937 = Remove_elements(start, stop, (SEQ_PTR(_45goto_stack_54937)->ref == 1));
        }
    }
    _27832 = NOVALUE;
    _27832 = NOVALUE;

    /** parser.e:175	end procedure*/
    return;
    ;
}


void _45EnterTopLevel(object _end_line_table_55096)
{
    object _27851 = NOVALUE;
    object _27850 = NOVALUE;
    object _27848 = NOVALUE;
    object _27847 = NOVALUE;
    object _27845 = NOVALUE;
    object _27843 = NOVALUE;
    object _27841 = NOVALUE;
    object _27839 = NOVALUE;
    object _27838 = NOVALUE;
    object _27836 = NOVALUE;
    object _27834 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:179		if CurrentSub then*/
    if (_36CurrentSub_21447 == 0)
    {
        goto L1; // [7] 59
    }
    else{
    }

    /** parser.e:180			if end_line_table then*/
    if (_end_line_table_55096 == 0)
    {
        goto L2; // [12] 58
    }
    else{
    }

    /** parser.e:181				EndLineTable()*/
    _45EndLineTable();

    /** parser.e:182				SymTab[CurrentSub][S_LINETAB] = LineTable*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21447 + ((s1_ptr)_2)->base);
    RefDS(_36LineTable_21532);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_LINETAB_21111))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21111)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21111);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36LineTable_21532;
    DeRef(_1);
    _27834 = NOVALUE;

    /** parser.e:183				SymTab[CurrentSub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21447 + ((s1_ptr)_2)->base);
    RefDS(_36Code_21531);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21088))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21088);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36Code_21531;
    DeRef(_1);
    _27836 = NOVALUE;
L2: 
L1: 

    /** parser.e:186		if length(goto_stack) then*/
    if (IS_SEQUENCE(_45goto_stack_54937)){
            _27838 = SEQ_PTR(_45goto_stack_54937)->length;
    }
    else {
        _27838 = 1;
    }
    if (_27838 == 0)
    {
        _27838 = NOVALUE;
        goto L3; // [66] 74
    }
    else{
        _27838 = NOVALUE;
    }

    /** parser.e:187			PopGoto()*/
    _45PopGoto();
L3: 

    /** parser.e:189		LineTable = SymTab[TopLevelSub][S_LINETAB]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27839 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21446);
    DeRef(_36LineTable_21532);
    _2 = (object)SEQ_PTR(_27839);
    if (!IS_ATOM_INT(_36S_LINETAB_21111)){
        _36LineTable_21532 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21111)->dbl));
    }
    else{
        _36LineTable_21532 = (object)*(((s1_ptr)_2)->base + _36S_LINETAB_21111);
    }
    Ref(_36LineTable_21532);
    _27839 = NOVALUE;

    /** parser.e:190		Code = SymTab[TopLevelSub][S_CODE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27841 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21446);
    DeRef(_36Code_21531);
    _2 = (object)SEQ_PTR(_27841);
    if (!IS_ATOM_INT(_36S_CODE_21088)){
        _36Code_21531 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
    }
    else{
        _36Code_21531 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21088);
    }
    Ref(_36Code_21531);
    _27841 = NOVALUE;

    /** parser.e:191		SymTab[TopLevelSub][S_LINETAB] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21446 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_LINETAB_21111))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21111)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21111);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _27843 = NOVALUE;

    /** parser.e:192		SymTab[TopLevelSub][S_CODE] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21446 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21088))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21088);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _27845 = NOVALUE;

    /** parser.e:193		previous_op = -1*/
    _36previous_op_21541 = -1LL;

    /** parser.e:194		CurrentSub = TopLevelSub*/
    _36CurrentSub_21447 = _36TopLevelSub_21446;

    /** parser.e:195		clear_last()*/
    _47clear_last();

    /** parser.e:196		if length( branch_stack ) then*/
    if (IS_SEQUENCE(_45branch_stack_54923)){
            _27847 = SEQ_PTR(_45branch_stack_54923)->length;
    }
    else {
        _27847 = 1;
    }
    if (_27847 == 0)
    {
        _27847 = NOVALUE;
        goto L4; // [171] 205
    }
    else{
        _27847 = NOVALUE;
    }

    /** parser.e:197			branch_list = branch_stack[$]*/
    if (IS_SEQUENCE(_45branch_stack_54923)){
            _27848 = SEQ_PTR(_45branch_stack_54923)->length;
    }
    else {
        _27848 = 1;
    }
    DeRef(_45branch_list_54922);
    _2 = (object)SEQ_PTR(_45branch_stack_54923);
    _45branch_list_54922 = (object)*(((s1_ptr)_2)->base + _27848);
    Ref(_45branch_list_54922);

    /** parser.e:198			branch_stack = tail( branch_stack )*/
    if (IS_SEQUENCE(_45branch_stack_54923)){
            _27850 = SEQ_PTR(_45branch_stack_54923)->length;
    }
    else {
        _27850 = 1;
    }
    _27851 = _27850 - 1LL;
    _27850 = NOVALUE;
    {
        int len = SEQ_PTR(_45branch_stack_54923)->length;
        int size = (IS_ATOM_INT(_27851)) ? _27851 : (object)(DBL_PTR(_27851)->dbl);
        if (size <= 0) {
            DeRef(_45branch_stack_54923);
            _45branch_stack_54923 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_45branch_stack_54923);
            DeRef(_45branch_stack_54923);
            _45branch_stack_54923 = _45branch_stack_54923;
        }
        else Tail(SEQ_PTR(_45branch_stack_54923), len-size+1, &_45branch_stack_54923);
    }
    _27851 = NOVALUE;
L4: 

    /** parser.e:200	end procedure*/
    return;
    ;
}


void _45LeaveTopLevel()
{
    object _27856 = NOVALUE;
    object _27854 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:204		branch_stack = append( branch_stack, branch_list )*/
    RefDS(_45branch_list_54922);
    Append(&_45branch_stack_54923, _45branch_stack_54923, _45branch_list_54922);

    /** parser.e:205		branch_list = {}*/
    RefDS(_21993);
    DeRefDS(_45branch_list_54922);
    _45branch_list_54922 = _21993;

    /** parser.e:206		PushGoto()*/
    _45PushGoto();

    /** parser.e:207		LastLineNumber = -1*/
    _62LastLineNumber_25551 = -1LL;

    /** parser.e:208		SymTab[TopLevelSub][S_LINETAB] = LineTable*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21446 + ((s1_ptr)_2)->base);
    RefDS(_36LineTable_21532);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_LINETAB_21111))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21111)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21111);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36LineTable_21532;
    DeRef(_1);
    _27854 = NOVALUE;

    /** parser.e:209		SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21446 + ((s1_ptr)_2)->base);
    RefDS(_36Code_21531);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21088))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21088);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36Code_21531;
    DeRef(_1);
    _27856 = NOVALUE;

    /** parser.e:210		LineTable = {}*/
    RefDS(_21993);
    DeRefDS(_36LineTable_21532);
    _36LineTable_21532 = _21993;

    /** parser.e:211		Code = {}*/
    RefDS(_21993);
    DeRefDS(_36Code_21531);
    _36Code_21531 = _21993;

    /** parser.e:212		previous_op = -1*/
    _36previous_op_21541 = -1LL;

    /** parser.e:213		clear_last()*/
    _47clear_last();

    /** parser.e:214	end procedure*/
    return;
    ;
}


void _45InitParser()
{
    object _new_1__tmp_at195_55172 = NOVALUE;
    object _new_inlined_new_at_195_55171 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:217		goto_stack = {}*/
    RefDS(_21993);
    DeRef(_45goto_stack_54937);
    _45goto_stack_54937 = _21993;

    /** parser.e:220		goto_labels = {}*/
    RefDS(_21993);
    DeRef(_45goto_labels_54935);
    _45goto_labels_54935 = _21993;

    /** parser.e:221		label_block = {}*/
    RefDS(_21993);
    DeRef(_45label_block_54939);
    _45label_block_54939 = _21993;

    /** parser.e:222		goto_ref = {}*/
    RefDS(_21993);
    DeRef(_45goto_ref_54938);
    _45goto_ref_54938 = _21993;

    /** parser.e:223		goto_addr = {}*/
    RefDS(_21993);
    DeRef(_45goto_addr_54936);
    _45goto_addr_54936 = _21993;

    /** parser.e:224		goto_line = {}*/
    RefDS(_21993);
    DeRef(_45goto_line_54934);
    _45goto_line_54934 = _21993;

    /** parser.e:225		break_list = {}*/
    RefDS(_21993);
    DeRefi(_45break_list_54942);
    _45break_list_54942 = _21993;

    /** parser.e:226		break_delay = {}*/
    RefDS(_21993);
    DeRef(_45break_delay_54943);
    _45break_delay_54943 = _21993;

    /** parser.e:227		exit_list = {}*/
    RefDS(_21993);
    DeRefi(_45exit_list_54944);
    _45exit_list_54944 = _21993;

    /** parser.e:228		exit_delay = {}*/
    RefDS(_21993);
    DeRef(_45exit_delay_54945);
    _45exit_delay_54945 = _21993;

    /** parser.e:229		continue_list = {}*/
    RefDS(_21993);
    DeRefi(_45continue_list_54946);
    _45continue_list_54946 = _21993;

    /** parser.e:230		continue_delay = {}*/
    RefDS(_21993);
    DeRef(_45continue_delay_54947);
    _45continue_delay_54947 = _21993;

    /** parser.e:231		init_stack = {}*/
    RefDS(_21993);
    DeRefi(_45init_stack_54957);
    _45init_stack_54957 = _21993;

    /** parser.e:232		CurrentSub = 0*/
    _36CurrentSub_21447 = 0LL;

    /** parser.e:233		CreateTopLevel()*/
    _45CreateTopLevel();

    /** parser.e:234		EnterTopLevel()*/
    _45EnterTopLevel(1LL);

    /** parser.e:235		backed_up_tok = {}*/
    RefDS(_21993);
    DeRef(_45backed_up_tok_54931);
    _45backed_up_tok_54931 = _21993;

    /** parser.e:236		loop_stack = {}*/
    RefDS(_21993);
    DeRefi(_45loop_stack_54958);
    _45loop_stack_54958 = _21993;

    /** parser.e:237		stmt_nest = 0*/
    _45stmt_nest_54956 = 0LL;

    /** parser.e:238		loop_labels = {}*/
    RefDS(_21993);
    DeRef(_45loop_labels_54952);
    _45loop_labels_54952 = _21993;

    /** parser.e:239		if_labels = {}*/
    RefDS(_21993);
    DeRef(_45if_labels_54953);
    _45if_labels_54953 = _21993;

    /** parser.e:240		if_stack = {}*/
    RefDS(_21993);
    DeRefi(_45if_stack_54959);
    _45if_stack_54959 = _21993;

    /** parser.e:241		continue_addr = {}*/
    RefDS(_21993);
    DeRefi(_45continue_addr_54949);
    _45continue_addr_54949 = _21993;

    /** parser.e:242		retry_addr = {}*/
    RefDS(_21993);
    DeRefi(_45retry_addr_54950);
    _45retry_addr_54950 = _21993;

    /** parser.e:243		entry_addr = {}*/
    RefDS(_21993);
    DeRefi(_45entry_addr_54948);
    _45entry_addr_54948 = _21993;

    /** parser.e:244		block_list = {}*/
    RefDS(_21993);
    DeRefi(_45block_list_54954);
    _45block_list_54954 = _21993;

    /** parser.e:245		block_index = 0*/
    _45block_index_54955 = 0LL;

    /** parser.e:246		param_num = -1*/
    _45param_num_54933 = -1LL;

    /** parser.e:247		entry_stack = {}*/
    RefDS(_21993);
    DeRef(_45entry_stack_54951);
    _45entry_stack_54951 = _21993;

    /** parser.e:248		goto_init = map:new()*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at195_55172;
    _new_1__tmp_at195_55172 = _29new_map_seq(8LL);
    DeRef(_0);
    Ref(_new_1__tmp_at195_55172);
    _0 = _30malloc(_new_1__tmp_at195_55172, 1LL);
    DeRef(_45goto_init_54941);
    _45goto_init_54941 = _0;
    DeRef(_new_1__tmp_at195_55172);
    _new_1__tmp_at195_55172 = NOVALUE;

    /** parser.e:249	end procedure*/
    return;
    ;
}


void _45NotReached(object _tok_55189, object _keyword_55190)
{
    object _27871 = NOVALUE;
    object _27870 = NOVALUE;
    object _27869 = NOVALUE;
    object _27868 = NOVALUE;
    object _27867 = NOVALUE;
    object _27866 = NOVALUE;
    object _27864 = NOVALUE;
    object _27863 = NOVALUE;
    object _27862 = NOVALUE;
    object _27861 = NOVALUE;
    object _27859 = NOVALUE;
    object _27858 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_tok_55189)) {
        _1 = (object)(DBL_PTR(_tok_55189)->dbl);
        DeRefDS(_tok_55189);
        _tok_55189 = _1;
    }

    /** parser.e:271		if not find(tok, {END, ELSE, ELSIF, END_OF_FILE, CASE, IFDEF, ELSIFDEF, ELSEDEF}) then*/
    _1 = NewS1(8);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 402LL;
    ((intptr_t*)_2)[2] = 23LL;
    ((intptr_t*)_2)[3] = 414LL;
    ((intptr_t*)_2)[4] = -21LL;
    ((intptr_t*)_2)[5] = 186LL;
    ((intptr_t*)_2)[6] = 407LL;
    ((intptr_t*)_2)[7] = 408LL;
    ((intptr_t*)_2)[8] = 409LL;
    _27858 = MAKE_SEQ(_1);
    _27859 = find_from(_tok_55189, _27858, 1LL);
    DeRefDS(_27858);
    _27858 = NOVALUE;
    if (_27859 != 0)
    goto L1; // [39] 135
    _27859 = NOVALUE;

    /** parser.e:272			if equal(keyword, "goto") and find(tok, {LOOP, LABEL, WHILE}) then*/
    if (_keyword_55190 == _26198)
    _27861 = 1;
    else if (IS_ATOM_INT(_keyword_55190) && IS_ATOM_INT(_26198))
    _27861 = 0;
    else
    _27861 = (compare(_keyword_55190, _26198) == 0);
    if (_27861 == 0) {
        goto L2; // [48] 79
    }
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 422LL;
    ((intptr_t*)_2)[2] = 419LL;
    ((intptr_t*)_2)[3] = 47LL;
    _27863 = MAKE_SEQ(_1);
    _27864 = find_from(_tok_55189, _27863, 1LL);
    DeRefDS(_27863);
    _27863 = NOVALUE;
    if (_27864 == 0)
    {
        _27864 = NOVALUE;
        goto L2; // [70] 79
    }
    else{
        _27864 = NOVALUE;
    }

    /** parser.e:273				return*/
    DeRefDSi(_keyword_55190);
    return;
L2: 

    /** parser.e:275			if equal(keyword, "abort()") and tok = LABEL then*/
    if (_keyword_55190 == _27865)
    _27866 = 1;
    else if (IS_ATOM_INT(_keyword_55190) && IS_ATOM_INT(_27865))
    _27866 = 0;
    else
    _27866 = (compare(_keyword_55190, _27865) == 0);
    if (_27866 == 0) {
        goto L3; // [85] 105
    }
    _27868 = (_tok_55189 == 419LL);
    if (_27868 == 0)
    {
        DeRef(_27868);
        _27868 = NOVALUE;
        goto L3; // [96] 105
    }
    else{
        DeRef(_27868);
        _27868 = NOVALUE;
    }

    /** parser.e:278				return*/
    DeRefDSi(_keyword_55190);
    return;
L3: 

    /** parser.e:280			Warning(218, not_reached_warning_flag,*/
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _27869 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
    Ref(_27869);
    _27870 = _54name_ext(_27869);
    _27869 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _27870;
    ((intptr_t*)_2)[2] = _36line_number_21440;
    RefDS(_keyword_55190);
    ((intptr_t*)_2)[3] = _keyword_55190;
    _27871 = MAKE_SEQ(_1);
    _27870 = NOVALUE;
    _50Warning(218LL, 512LL, _27871);
    _27871 = NOVALUE;
L1: 

    /** parser.e:285	end procedure*/
    DeRefDSi(_keyword_55190);
    return;
    ;
}


void _45Forward_InitCheck(object _tok_55229, object _ref_55230)
{
    object _sym_55232 = NOVALUE;
    object _27877 = NOVALUE;
    object _27876 = NOVALUE;
    object _27875 = NOVALUE;
    object _27873 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:289		if ref then*/
    if (_ref_55230 == 0)
    {
        goto L1; // [5] 83
    }
    else{
    }

    /** parser.e:290			integer sym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_55229);
    _sym_55232 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_sym_55232)){
        _sym_55232 = (object)DBL_PTR(_sym_55232)->dbl;
    }

    /** parser.e:291			if tok[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_55229);
    _27873 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _27873, 512LL)){
        _27873 = NOVALUE;
        goto L2; // [28] 50
    }
    _27873 = NOVALUE;

    /** parser.e:292				set_qualified_fwd( SymTab[sym][S_FILE_NO] )*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27875 = (object)*(((s1_ptr)_2)->base + _sym_55232);
    _2 = (object)SEQ_PTR(_27875);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _27876 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _27876 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    _27875 = NOVALUE;
    Ref(_27876);
    _62set_qualified_fwd(_27876);
    _27876 = NOVALUE;
L2: 

    /** parser.e:294			ref = new_forward_reference( GLOBAL_INIT_CHECK, tok[T_SYM], GLOBAL_INIT_CHECK )*/
    _2 = (object)SEQ_PTR(_tok_55229);
    _27877 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_27877);
    _ref_55230 = _44new_forward_reference(109LL, _27877, 109LL);
    _27877 = NOVALUE;
    if (!IS_ATOM_INT(_ref_55230)) {
        _1 = (object)(DBL_PTR(_ref_55230)->dbl);
        DeRefDS(_ref_55230);
        _ref_55230 = _1;
    }

    /** parser.e:296			emit_op( GLOBAL_INIT_CHECK )*/
    _47emit_op(109LL);

    /** parser.e:297			emit_addr( sym )*/
    _47emit_addr(_sym_55232);
L1: 

    /** parser.e:299	end procedure*/
    DeRef(_tok_55229);
    return;
    ;
}


void _45InitCheck(object _sym_55257, object _ref_55258)
{
    object _27954 = NOVALUE;
    object _27953 = NOVALUE;
    object _27952 = NOVALUE;
    object _27951 = NOVALUE;
    object _27950 = NOVALUE;
    object _27949 = NOVALUE;
    object _27948 = NOVALUE;
    object _27947 = NOVALUE;
    object _27945 = NOVALUE;
    object _27943 = NOVALUE;
    object _27942 = NOVALUE;
    object _27940 = NOVALUE;
    object _27939 = NOVALUE;
    object _27938 = NOVALUE;
    object _27937 = NOVALUE;
    object _27936 = NOVALUE;
    object _27935 = NOVALUE;
    object _27934 = NOVALUE;
    object _27933 = NOVALUE;
    object _27932 = NOVALUE;
    object _27931 = NOVALUE;
    object _27930 = NOVALUE;
    object _27929 = NOVALUE;
    object _27928 = NOVALUE;
    object _27927 = NOVALUE;
    object _27925 = NOVALUE;
    object _27924 = NOVALUE;
    object _27923 = NOVALUE;
    object _27922 = NOVALUE;
    object _27921 = NOVALUE;
    object _27920 = NOVALUE;
    object _27919 = NOVALUE;
    object _27918 = NOVALUE;
    object _27917 = NOVALUE;
    object _27915 = NOVALUE;
    object _27914 = NOVALUE;
    object _27913 = NOVALUE;
    object _27912 = NOVALUE;
    object _27911 = NOVALUE;
    object _27910 = NOVALUE;
    object _27909 = NOVALUE;
    object _27908 = NOVALUE;
    object _27907 = NOVALUE;
    object _27906 = NOVALUE;
    object _27905 = NOVALUE;
    object _27904 = NOVALUE;
    object _27903 = NOVALUE;
    object _27902 = NOVALUE;
    object _27901 = NOVALUE;
    object _27900 = NOVALUE;
    object _27899 = NOVALUE;
    object _27898 = NOVALUE;
    object _27897 = NOVALUE;
    object _27896 = NOVALUE;
    object _27895 = NOVALUE;
    object _27894 = NOVALUE;
    object _27892 = NOVALUE;
    object _27891 = NOVALUE;
    object _27890 = NOVALUE;
    object _27889 = NOVALUE;
    object _27888 = NOVALUE;
    object _27887 = NOVALUE;
    object _27886 = NOVALUE;
    object _27885 = NOVALUE;
    object _27884 = NOVALUE;
    object _27883 = NOVALUE;
    object _27882 = NOVALUE;
    object _27881 = NOVALUE;
    object _27879 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:306		if sym < 0 or (SymTab[sym][S_MODE] = M_NORMAL and*/
    _27879 = (_sym_55257 < 0LL);
    if (_27879 != 0) {
        goto L1; // [11] 90
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27881 = (object)*(((s1_ptr)_2)->base + _sym_55257);
    _2 = (object)SEQ_PTR(_27881);
    _27882 = (object)*(((s1_ptr)_2)->base + 3LL);
    _27881 = NOVALUE;
    if (IS_ATOM_INT(_27882)) {
        _27883 = (_27882 == 1LL);
    }
    else {
        _27883 = binary_op(EQUALS, _27882, 1LL);
    }
    _27882 = NOVALUE;
    if (IS_ATOM_INT(_27883)) {
        if (_27883 == 0) {
            _27884 = 0;
            goto L2; // [33] 59
        }
    }
    else {
        if (DBL_PTR(_27883)->dbl == 0.0) {
            _27884 = 0;
            goto L2; // [33] 59
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27885 = (object)*(((s1_ptr)_2)->base + _sym_55257);
    _2 = (object)SEQ_PTR(_27885);
    _27886 = (object)*(((s1_ptr)_2)->base + 4LL);
    _27885 = NOVALUE;
    if (IS_ATOM_INT(_27886)) {
        _27887 = (_27886 != 2LL);
    }
    else {
        _27887 = binary_op(NOTEQ, _27886, 2LL);
    }
    _27886 = NOVALUE;
    DeRef(_27884);
    if (IS_ATOM_INT(_27887))
    _27884 = (_27887 != 0);
    else
    _27884 = DBL_PTR(_27887)->dbl != 0.0;
L2: 
    if (_27884 == 0) {
        DeRef(_27888);
        _27888 = 0;
        goto L3; // [59] 85
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27889 = (object)*(((s1_ptr)_2)->base + _sym_55257);
    _2 = (object)SEQ_PTR(_27889);
    _27890 = (object)*(((s1_ptr)_2)->base + 4LL);
    _27889 = NOVALUE;
    if (IS_ATOM_INT(_27890)) {
        _27891 = (_27890 != 4LL);
    }
    else {
        _27891 = binary_op(NOTEQ, _27890, 4LL);
    }
    _27890 = NOVALUE;
    if (IS_ATOM_INT(_27891))
    _27888 = (_27891 != 0);
    else
    _27888 = DBL_PTR(_27891)->dbl != 0.0;
L3: 
    if (_27888 == 0)
    {
        _27888 = NOVALUE;
        goto L4; // [86] 502
    }
    else{
        _27888 = NOVALUE;
    }
L1: 

    /** parser.e:309			if sym < 0 or ((SymTab[sym][S_SCOPE] != SC_PRIVATE and*/
    _27892 = (_sym_55257 < 0LL);
    if (_27892 != 0) {
        goto L5; // [96] 213
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27894 = (object)*(((s1_ptr)_2)->base + _sym_55257);
    _2 = (object)SEQ_PTR(_27894);
    _27895 = (object)*(((s1_ptr)_2)->base + 4LL);
    _27894 = NOVALUE;
    if (IS_ATOM_INT(_27895)) {
        _27896 = (_27895 != 3LL);
    }
    else {
        _27896 = binary_op(NOTEQ, _27895, 3LL);
    }
    _27895 = NOVALUE;
    if (IS_ATOM_INT(_27896)) {
        if (_27896 == 0) {
            DeRef(_27897);
            _27897 = 0;
            goto L6; // [118] 144
        }
    }
    else {
        if (DBL_PTR(_27896)->dbl == 0.0) {
            DeRef(_27897);
            _27897 = 0;
            goto L6; // [118] 144
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27898 = (object)*(((s1_ptr)_2)->base + _sym_55257);
    _2 = (object)SEQ_PTR(_27898);
    _27899 = (object)*(((s1_ptr)_2)->base + 1LL);
    _27898 = NOVALUE;
    if (_27899 == _36NOVALUE_21293)
    _27900 = 1;
    else if (IS_ATOM_INT(_27899) && IS_ATOM_INT(_36NOVALUE_21293))
    _27900 = 0;
    else
    _27900 = (compare(_27899, _36NOVALUE_21293) == 0);
    _27899 = NOVALUE;
    DeRef(_27897);
    _27897 = (_27900 != 0);
L6: 
    if (_27897 != 0) {
        DeRef(_27901);
        _27901 = 1;
        goto L7; // [144] 208
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27902 = (object)*(((s1_ptr)_2)->base + _sym_55257);
    _2 = (object)SEQ_PTR(_27902);
    _27903 = (object)*(((s1_ptr)_2)->base + 4LL);
    _27902 = NOVALUE;
    if (IS_ATOM_INT(_27903)) {
        _27904 = (_27903 == 3LL);
    }
    else {
        _27904 = binary_op(EQUALS, _27903, 3LL);
    }
    _27903 = NOVALUE;
    if (IS_ATOM_INT(_27904)) {
        if (_27904 == 0) {
            DeRef(_27905);
            _27905 = 0;
            goto L8; // [166] 204
        }
    }
    else {
        if (DBL_PTR(_27904)->dbl == 0.0) {
            DeRef(_27905);
            _27905 = 0;
            goto L8; // [166] 204
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27906 = (object)*(((s1_ptr)_2)->base + _sym_55257);
    _2 = (object)SEQ_PTR(_27906);
    _27907 = (object)*(((s1_ptr)_2)->base + 16LL);
    _27906 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27908 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21447);
    _2 = (object)SEQ_PTR(_27908);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
        _27909 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
    }
    else{
        _27909 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
    }
    _27908 = NOVALUE;
    if (IS_ATOM_INT(_27907) && IS_ATOM_INT(_27909)) {
        _27910 = (_27907 >= _27909);
    }
    else {
        _27910 = binary_op(GREATEREQ, _27907, _27909);
    }
    _27907 = NOVALUE;
    _27909 = NOVALUE;
    DeRef(_27905);
    if (IS_ATOM_INT(_27910))
    _27905 = (_27910 != 0);
    else
    _27905 = DBL_PTR(_27910)->dbl != 0.0;
L8: 
    DeRef(_27901);
    _27901 = (_27905 != 0);
L7: 
    if (_27901 == 0)
    {
        _27901 = NOVALUE;
        goto L9; // [209] 566
    }
    else{
        _27901 = NOVALUE;
    }
L5: 

    /** parser.e:313				if sym < 0 or (SymTab[sym][S_INITLEVEL] = -1)*/
    _27911 = (_sym_55257 < 0LL);
    if (_27911 != 0) {
        _27912 = 1;
        goto LA; // [219] 243
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27913 = (object)*(((s1_ptr)_2)->base + _sym_55257);
    _2 = (object)SEQ_PTR(_27913);
    _27914 = (object)*(((s1_ptr)_2)->base + 14LL);
    _27913 = NOVALUE;
    if (IS_ATOM_INT(_27914)) {
        _27915 = (_27914 == -1LL);
    }
    else {
        _27915 = binary_op(EQUALS, _27914, -1LL);
    }
    _27914 = NOVALUE;
    if (IS_ATOM_INT(_27915))
    _27912 = (_27915 != 0);
    else
    _27912 = DBL_PTR(_27915)->dbl != 0.0;
LA: 
    if (_27912 != 0) {
        goto LB; // [243] 270
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27917 = (object)*(((s1_ptr)_2)->base + _sym_55257);
    _2 = (object)SEQ_PTR(_27917);
    _27918 = (object)*(((s1_ptr)_2)->base + 4LL);
    _27917 = NOVALUE;
    if (IS_ATOM_INT(_27918)) {
        _27919 = (_27918 != 3LL);
    }
    else {
        _27919 = binary_op(NOTEQ, _27918, 3LL);
    }
    _27918 = NOVALUE;
    if (_27919 == 0) {
        DeRef(_27919);
        _27919 = NOVALUE;
        goto L9; // [266] 566
    }
    else {
        if (!IS_ATOM_INT(_27919) && DBL_PTR(_27919)->dbl == 0.0){
            DeRef(_27919);
            _27919 = NOVALUE;
            goto L9; // [266] 566
        }
        DeRef(_27919);
        _27919 = NOVALUE;
    }
    DeRef(_27919);
    _27919 = NOVALUE;
LB: 

    /** parser.e:316					if ref then*/
    if (_ref_55258 == 0)
    {
        goto LC; // [272] 375
    }
    else{
    }

    /** parser.e:317						if sym > 0 and (SymTab[sym][S_SCOPE] = SC_UNDEFINED) then*/
    _27920 = (_sym_55257 > 0LL);
    if (_27920 == 0) {
        goto LD; // [281] 317
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27922 = (object)*(((s1_ptr)_2)->base + _sym_55257);
    _2 = (object)SEQ_PTR(_27922);
    _27923 = (object)*(((s1_ptr)_2)->base + 4LL);
    _27922 = NOVALUE;
    if (IS_ATOM_INT(_27923)) {
        _27924 = (_27923 == 9LL);
    }
    else {
        _27924 = binary_op(EQUALS, _27923, 9LL);
    }
    _27923 = NOVALUE;
    if (_27924 == 0) {
        DeRef(_27924);
        _27924 = NOVALUE;
        goto LD; // [304] 317
    }
    else {
        if (!IS_ATOM_INT(_27924) && DBL_PTR(_27924)->dbl == 0.0){
            DeRef(_27924);
            _27924 = NOVALUE;
            goto LD; // [304] 317
        }
        DeRef(_27924);
        _27924 = NOVALUE;
    }
    DeRef(_27924);
    _27924 = NOVALUE;

    /** parser.e:318							emit_op(PRIVATE_INIT_CHECK)*/
    _47emit_op(30LL);
    goto LE; // [314] 369
LD: 

    /** parser.e:319						elsif sym < 0 or find(SymTab[sym][S_SCOPE], SCOPE_TYPES) then*/
    _27925 = (_sym_55257 < 0LL);
    if (_27925 != 0) {
        goto LF; // [323] 351
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27927 = (object)*(((s1_ptr)_2)->base + _sym_55257);
    _2 = (object)SEQ_PTR(_27927);
    _27928 = (object)*(((s1_ptr)_2)->base + 4LL);
    _27927 = NOVALUE;
    _27929 = find_from(_27928, _45SCOPE_TYPES_54915, 1LL);
    _27928 = NOVALUE;
    if (_27929 == 0)
    {
        _27929 = NOVALUE;
        goto L10; // [347] 361
    }
    else{
        _27929 = NOVALUE;
    }
LF: 

    /** parser.e:320							emit_op(GLOBAL_INIT_CHECK) -- will become NOP2*/
    _47emit_op(109LL);
    goto LE; // [358] 369
L10: 

    /** parser.e:322							emit_op(PRIVATE_INIT_CHECK)*/
    _47emit_op(30LL);
LE: 

    /** parser.e:324						emit_addr(sym)*/
    _47emit_addr(_sym_55257);
LC: 

    /** parser.e:326					if sym > 0 */
    _27930 = (_sym_55257 > 0LL);
    if (_27930 == 0) {
        _27931 = 0;
        goto L11; // [381] 411
    }
    _27932 = (_45short_circuit_54924 <= 0LL);
    if (_27932 != 0) {
        _27933 = 1;
        goto L12; // [391] 407
    }
    _27934 = (_45short_circuit_B_54926 == _13FALSE_450);
    _27933 = (_27934 != 0);
L12: 
    _27931 = (_27933 != 0);
L11: 
    if (_27931 == 0) {
        goto L9; // [411] 566
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27936 = (object)*(((s1_ptr)_2)->base + _sym_55257);
    _2 = (object)SEQ_PTR(_27936);
    _27937 = (object)*(((s1_ptr)_2)->base + 4LL);
    _27936 = NOVALUE;
    if (IS_ATOM_INT(_27937)) {
        _27938 = (_27937 != 3LL);
    }
    else {
        _27938 = binary_op(NOTEQ, _27937, 3LL);
    }
    _27937 = NOVALUE;
    if (IS_ATOM_INT(_27938)) {
        _27939 = (_27938 == 0);
    }
    else {
        _27939 = unary_op(NOT, _27938);
    }
    DeRef(_27938);
    _27938 = NOVALUE;
    if (_27939 == 0) {
        DeRef(_27939);
        _27939 = NOVALUE;
        goto L9; // [437] 566
    }
    else {
        if (!IS_ATOM_INT(_27939) && DBL_PTR(_27939)->dbl == 0.0){
            DeRef(_27939);
            _27939 = NOVALUE;
            goto L9; // [437] 566
        }
        DeRef(_27939);
        _27939 = NOVALUE;
    }
    DeRef(_27939);
    _27939 = NOVALUE;

    /** parser.e:330						if CurrentSub != TopLevelSub */
    _27940 = (_36CurrentSub_21447 != _36TopLevelSub_21446);
    if (_27940 != 0) {
        goto L13; // [450] 470
    }
    if (IS_SEQUENCE(_37known_files_15407)){
            _27942 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _27942 = 1;
    }
    _27943 = (_36current_file_no_21439 == _27942);
    _27942 = NOVALUE;
    if (_27943 == 0)
    {
        DeRef(_27943);
        _27943 = NOVALUE;
        goto L9; // [466] 566
    }
    else{
        DeRef(_27943);
        _27943 = NOVALUE;
    }
L13: 

    /** parser.e:335							init_stack = append(init_stack, sym)*/
    Append(&_45init_stack_54957, _45init_stack_54957, _sym_55257);

    /** parser.e:336							SymTab[sym][S_INITLEVEL] = stmt_nest*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_55257 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _45stmt_nest_54956;
    DeRef(_1);
    _27945 = NOVALUE;
    goto L9; // [499] 566
L4: 

    /** parser.e:343		elsif ref and sym > 0 and sym_mode( sym ) = M_CONSTANT and equal( NOVALUE, sym_obj( sym ) ) then*/
    if (_ref_55258 == 0) {
        _27947 = 0;
        goto L14; // [504] 516
    }
    _27948 = (_sym_55257 > 0LL);
    _27947 = (_27948 != 0);
L14: 
    if (_27947 == 0) {
        _27949 = 0;
        goto L15; // [516] 534
    }
    _27950 = _54sym_mode(_sym_55257);
    if (IS_ATOM_INT(_27950)) {
        _27951 = (_27950 == 2LL);
    }
    else {
        _27951 = binary_op(EQUALS, _27950, 2LL);
    }
    DeRef(_27950);
    _27950 = NOVALUE;
    if (IS_ATOM_INT(_27951))
    _27949 = (_27951 != 0);
    else
    _27949 = DBL_PTR(_27951)->dbl != 0.0;
L15: 
    if (_27949 == 0) {
        goto L16; // [534] 565
    }
    _27953 = _54sym_obj(_sym_55257);
    if (_36NOVALUE_21293 == _27953)
    _27954 = 1;
    else if (IS_ATOM_INT(_36NOVALUE_21293) && IS_ATOM_INT(_27953))
    _27954 = 0;
    else
    _27954 = (compare(_36NOVALUE_21293, _27953) == 0);
    DeRef(_27953);
    _27953 = NOVALUE;
    if (_27954 == 0)
    {
        _27954 = NOVALUE;
        goto L16; // [549] 565
    }
    else{
        _27954 = NOVALUE;
    }

    /** parser.e:344			emit_op( GLOBAL_INIT_CHECK )*/
    _47emit_op(109LL);

    /** parser.e:345			emit_addr(sym)*/
    _47emit_addr(_sym_55257);
L16: 
L9: 

    /** parser.e:349	end procedure*/
    DeRef(_27932);
    _27932 = NOVALUE;
    DeRef(_27925);
    _27925 = NOVALUE;
    DeRef(_27904);
    _27904 = NOVALUE;
    DeRef(_27896);
    _27896 = NOVALUE;
    DeRef(_27948);
    _27948 = NOVALUE;
    DeRef(_27915);
    _27915 = NOVALUE;
    DeRef(_27910);
    _27910 = NOVALUE;
    DeRef(_27930);
    _27930 = NOVALUE;
    DeRef(_27934);
    _27934 = NOVALUE;
    DeRef(_27879);
    _27879 = NOVALUE;
    DeRef(_27883);
    _27883 = NOVALUE;
    DeRef(_27892);
    _27892 = NOVALUE;
    DeRef(_27911);
    _27911 = NOVALUE;
    DeRef(_27951);
    _27951 = NOVALUE;
    DeRef(_27891);
    _27891 = NOVALUE;
    DeRef(_27940);
    _27940 = NOVALUE;
    DeRef(_27887);
    _27887 = NOVALUE;
    DeRef(_27920);
    _27920 = NOVALUE;
    return;
    ;
}


void _45InitDelete()
{
    object _27967 = NOVALUE;
    object _27966 = NOVALUE;
    object _27964 = NOVALUE;
    object _27963 = NOVALUE;
    object _27962 = NOVALUE;
    object _27961 = NOVALUE;
    object _27960 = NOVALUE;
    object _27959 = NOVALUE;
    object _27958 = NOVALUE;
    object _27957 = NOVALUE;
    object _27956 = NOVALUE;
    object _27955 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:354		while length(init_stack) and*/
L1: 
    if (IS_SEQUENCE(_45init_stack_54957)){
            _27955 = SEQ_PTR(_45init_stack_54957)->length;
    }
    else {
        _27955 = 1;
    }
    if (_27955 == 0) {
        goto L2; // [11] 91
    }
    if (IS_SEQUENCE(_45init_stack_54957)){
            _27957 = SEQ_PTR(_45init_stack_54957)->length;
    }
    else {
        _27957 = 1;
    }
    _2 = (object)SEQ_PTR(_45init_stack_54957);
    _27958 = (object)*(((s1_ptr)_2)->base + _27957);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _27959 = (object)*(((s1_ptr)_2)->base + _27958);
    _2 = (object)SEQ_PTR(_27959);
    _27960 = (object)*(((s1_ptr)_2)->base + 14LL);
    _27959 = NOVALUE;
    if (IS_ATOM_INT(_27960)) {
        _27961 = (_27960 > _45stmt_nest_54956);
    }
    else {
        _27961 = binary_op(GREATER, _27960, _45stmt_nest_54956);
    }
    _27960 = NOVALUE;
    if (_27961 <= 0) {
        if (_27961 == 0) {
            DeRef(_27961);
            _27961 = NOVALUE;
            goto L2; // [43] 91
        }
        else {
            if (!IS_ATOM_INT(_27961) && DBL_PTR(_27961)->dbl == 0.0){
                DeRef(_27961);
                _27961 = NOVALUE;
                goto L2; // [43] 91
            }
            DeRef(_27961);
            _27961 = NOVALUE;
        }
    }
    DeRef(_27961);
    _27961 = NOVALUE;

    /** parser.e:356			SymTab[init_stack[$]][S_INITLEVEL] = -1*/
    if (IS_SEQUENCE(_45init_stack_54957)){
            _27962 = SEQ_PTR(_45init_stack_54957)->length;
    }
    else {
        _27962 = 1;
    }
    _2 = (object)SEQ_PTR(_45init_stack_54957);
    _27963 = (object)*(((s1_ptr)_2)->base + _27962);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27963 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1LL;
    DeRef(_1);
    _27964 = NOVALUE;

    /** parser.e:357			init_stack = init_stack[1..$-1]*/
    if (IS_SEQUENCE(_45init_stack_54957)){
            _27966 = SEQ_PTR(_45init_stack_54957)->length;
    }
    else {
        _27966 = 1;
    }
    _27967 = _27966 - 1LL;
    _27966 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45init_stack_54957;
    RHS_Slice(_45init_stack_54957, 1LL, _27967);

    /** parser.e:358		end while*/
    goto L1; // [88] 6
L2: 

    /** parser.e:359	end procedure*/
    DeRef(_27967);
    _27967 = NOVALUE;
    _27963 = NOVALUE;
    _27958 = NOVALUE;
    return;
    ;
}


void _45emit_forward_addr()
{
    object _27969 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:364		emit_addr(0)*/
    _47emit_addr(0LL);

    /** parser.e:365		branch_list = append(branch_list, length(Code))*/
    if (IS_SEQUENCE(_36Code_21531)){
            _27969 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _27969 = 1;
    }
    Append(&_45branch_list_54922, _45branch_list_54922, _27969);
    _27969 = NOVALUE;

    /** parser.e:366	end procedure*/
    return;
    ;
}


void _45StraightenBranches()
{
    object _br_55431 = NOVALUE;
    object _target_55432 = NOVALUE;
    object _27990 = NOVALUE;
    object _27989 = NOVALUE;
    object _27988 = NOVALUE;
    object _27987 = NOVALUE;
    object _27985 = NOVALUE;
    object _27984 = NOVALUE;
    object _27983 = NOVALUE;
    object _27981 = NOVALUE;
    object _27980 = NOVALUE;
    object _27979 = NOVALUE;
    object _27978 = NOVALUE;
    object _27976 = NOVALUE;
    object _27973 = NOVALUE;
    object _27972 = NOVALUE;
    object _27971 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:373		if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L1; // [5] 14
    }
    else{
    }

    /** parser.e:374			return -- do it in back-end*/
    return;
L1: 

    /** parser.e:376		for i = length(branch_list) to 1 by -1 do*/
    if (IS_SEQUENCE(_45branch_list_54922)){
            _27971 = SEQ_PTR(_45branch_list_54922)->length;
    }
    else {
        _27971 = 1;
    }
    {
        object _i_55436;
        _i_55436 = _27971;
L2: 
        if (_i_55436 < 1LL){
            goto L3; // [21] 170
        }

        /** parser.e:377			if branch_list[i] > length(Code) then*/
        _2 = (object)SEQ_PTR(_45branch_list_54922);
        _27972 = (object)*(((s1_ptr)_2)->base + _i_55436);
        if (IS_SEQUENCE(_36Code_21531)){
                _27973 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _27973 = 1;
        }
        if (binary_op_a(LESSEQ, _27972, _27973)){
            _27972 = NOVALUE;
            _27973 = NOVALUE;
            goto L4; // [41] 53
        }
        _27972 = NOVALUE;
        _27973 = NOVALUE;

        /** parser.e:378				CompileErr("wtf")*/
        RefDS(_27975);
        RefDS(_21993);
        _50CompileErr(_27975, _21993, 0LL);
L4: 

        /** parser.e:380			target = Code[branch_list[i]]*/
        _2 = (object)SEQ_PTR(_45branch_list_54922);
        _27976 = (object)*(((s1_ptr)_2)->base + _i_55436);
        _2 = (object)SEQ_PTR(_36Code_21531);
        if (!IS_ATOM_INT(_27976)){
            _target_55432 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27976)->dbl));
        }
        else{
            _target_55432 = (object)*(((s1_ptr)_2)->base + _27976);
        }
        if (!IS_ATOM_INT(_target_55432)){
            _target_55432 = (object)DBL_PTR(_target_55432)->dbl;
        }

        /** parser.e:381			if target <= length(Code) and target > 0 then*/
        if (IS_SEQUENCE(_36Code_21531)){
                _27978 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _27978 = 1;
        }
        _27979 = (_target_55432 <= _27978);
        _27978 = NOVALUE;
        if (_27979 == 0) {
            goto L5; // [80] 163
        }
        _27981 = (_target_55432 > 0LL);
        if (_27981 == 0)
        {
            DeRef(_27981);
            _27981 = NOVALUE;
            goto L5; // [89] 163
        }
        else{
            DeRef(_27981);
            _27981 = NOVALUE;
        }

        /** parser.e:382				br = Code[target]*/
        _2 = (object)SEQ_PTR(_36Code_21531);
        _br_55431 = (object)*(((s1_ptr)_2)->base + _target_55432);
        if (!IS_ATOM_INT(_br_55431)){
            _br_55431 = (object)DBL_PTR(_br_55431)->dbl;
        }

        /** parser.e:383				if br = ELSE or br = ENDWHILE or br = EXIT then*/
        _27983 = (_br_55431 == 23LL);
        if (_27983 != 0) {
            _27984 = 1;
            goto L6; // [110] 124
        }
        _27985 = (_br_55431 == 22LL);
        _27984 = (_27985 != 0);
L6: 
        if (_27984 != 0) {
            goto L7; // [124] 139
        }
        _27987 = (_br_55431 == 61LL);
        if (_27987 == 0)
        {
            DeRef(_27987);
            _27987 = NOVALUE;
            goto L8; // [135] 162
        }
        else{
            DeRef(_27987);
            _27987 = NOVALUE;
        }
L7: 

        /** parser.e:384					backpatch(branch_list[i], Code[target+1])*/
        _2 = (object)SEQ_PTR(_45branch_list_54922);
        _27988 = (object)*(((s1_ptr)_2)->base + _i_55436);
        _27989 = _target_55432 + 1;
        _2 = (object)SEQ_PTR(_36Code_21531);
        _27990 = (object)*(((s1_ptr)_2)->base + _27989);
        Ref(_27988);
        Ref(_27990);
        _47backpatch(_27988, _27990);
        _27988 = NOVALUE;
        _27990 = NOVALUE;
L8: 
L5: 

        /** parser.e:387		end for*/
        _i_55436 = _i_55436 + -1LL;
        goto L2; // [165] 28
L3: 
        ;
    }

    /** parser.e:388		branch_list = {}*/
    RefDS(_21993);
    DeRef(_45branch_list_54922);
    _45branch_list_54922 = _21993;

    /** parser.e:389	end procedure*/
    DeRef(_27985);
    _27985 = NOVALUE;
    _27976 = NOVALUE;
    DeRef(_27983);
    _27983 = NOVALUE;
    DeRef(_27989);
    _27989 = NOVALUE;
    DeRef(_27979);
    _27979 = NOVALUE;
    return;
    ;
}


void _45PatchEList(object _base_55484)
{
    object _break_top_55485 = NOVALUE;
    object _n_55486 = NOVALUE;
    object _28007 = NOVALUE;
    object _28006 = NOVALUE;
    object _28005 = NOVALUE;
    object _28001 = NOVALUE;
    object _28000 = NOVALUE;
    object _27999 = NOVALUE;
    object _27997 = NOVALUE;
    object _27996 = NOVALUE;
    object _27994 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:410		if not length(break_list) then*/
    if (IS_SEQUENCE(_45break_list_54942)){
            _27994 = SEQ_PTR(_45break_list_54942)->length;
    }
    else {
        _27994 = 1;
    }
    if (_27994 != 0)
    goto L1; // [10] 19
    _27994 = NOVALUE;

    /** parser.e:411			return*/
    return;
L1: 

    /** parser.e:414		break_top = 0*/
    _break_top_55485 = 0LL;

    /** parser.e:415		for i=length(break_list) to base+1 by -1 do*/
    if (IS_SEQUENCE(_45break_list_54942)){
            _27996 = SEQ_PTR(_45break_list_54942)->length;
    }
    else {
        _27996 = 1;
    }
    _27997 = _base_55484 + 1;
    if (_27997 > MAXINT){
        _27997 = NewDouble((eudouble)_27997);
    }
    {
        object _i_55491;
        _i_55491 = _27996;
L2: 
        if (binary_op_a(LESS, _i_55491, _27997)){
            goto L3; // [35] 129
        }

        /** parser.e:416			n=break_delay[i]*/
        _2 = (object)SEQ_PTR(_45break_delay_54943);
        if (!IS_ATOM_INT(_i_55491)){
            _n_55486 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55491)->dbl));
        }
        else{
            _n_55486 = (object)*(((s1_ptr)_2)->base + _i_55491);
        }
        if (!IS_ATOM_INT(_n_55486))
        _n_55486 = (object)DBL_PTR(_n_55486)->dbl;

        /** parser.e:417			break_delay[i] -= (n>0)*/
        _27999 = (_n_55486 > 0LL);
        _2 = (object)SEQ_PTR(_45break_delay_54943);
        if (!IS_ATOM_INT(_i_55491)){
            _28000 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55491)->dbl));
        }
        else{
            _28000 = (object)*(((s1_ptr)_2)->base + _i_55491);
        }
        if (IS_ATOM_INT(_28000)) {
            _28001 = _28000 - _27999;
            if ((object)((uintptr_t)_28001 +(uintptr_t) HIGH_BITS) >= 0){
                _28001 = NewDouble((eudouble)_28001);
            }
        }
        else {
            _28001 = binary_op(MINUS, _28000, _27999);
        }
        _28000 = NOVALUE;
        _27999 = NOVALUE;
        _2 = (object)SEQ_PTR(_45break_delay_54943);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _45break_delay_54943 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_55491))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55491)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _i_55491);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _28001;
        if( _1 != _28001 ){
            DeRef(_1);
        }
        _28001 = NOVALUE;

        /** parser.e:418			if n>1 then*/
        if (_n_55486 <= 1LL)
        goto L4; // [72] 93

        /** parser.e:419				if break_top = 0 then*/
        if (_break_top_55485 != 0LL)
        goto L5; // [78] 122

        /** parser.e:420					break_top = i*/
        Ref(_i_55491);
        _break_top_55485 = _i_55491;
        if (!IS_ATOM_INT(_break_top_55485)) {
            _1 = (object)(DBL_PTR(_break_top_55485)->dbl);
            DeRefDS(_break_top_55485);
            _break_top_55485 = _1;
        }
        goto L5; // [90] 122
L4: 

        /** parser.e:422			elsif n=1 then*/
        if (_n_55486 != 1LL)
        goto L6; // [95] 121

        /** parser.e:423				backpatch(break_list[i],length(Code)+1)*/
        _2 = (object)SEQ_PTR(_45break_list_54942);
        if (!IS_ATOM_INT(_i_55491)){
            _28005 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55491)->dbl));
        }
        else{
            _28005 = (object)*(((s1_ptr)_2)->base + _i_55491);
        }
        if (IS_SEQUENCE(_36Code_21531)){
                _28006 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _28006 = 1;
        }
        _28007 = _28006 + 1;
        _28006 = NOVALUE;
        _47backpatch(_28005, _28007);
        _28005 = NOVALUE;
        _28007 = NOVALUE;
L6: 
L5: 

        /** parser.e:425		end for*/
        _0 = _i_55491;
        if (IS_ATOM_INT(_i_55491)) {
            _i_55491 = _i_55491 + -1LL;
            if ((object)((uintptr_t)_i_55491 +(uintptr_t) HIGH_BITS) >= 0){
                _i_55491 = NewDouble((eudouble)_i_55491);
            }
        }
        else {
            _i_55491 = binary_op_a(PLUS, _i_55491, -1LL);
        }
        DeRef(_0);
        goto L2; // [124] 42
L3: 
        ;
        DeRef(_i_55491);
    }

    /** parser.e:427		if break_top=0 then*/
    if (_break_top_55485 != 0LL)
    goto L7; // [131] 141

    /** parser.e:428		    break_top=base*/
    _break_top_55485 = _base_55484;
L7: 

    /** parser.e:431		break_delay = break_delay[1..break_top]*/
    rhs_slice_target = (object_ptr)&_45break_delay_54943;
    RHS_Slice(_45break_delay_54943, 1LL, _break_top_55485);

    /** parser.e:432		break_list = break_list[1..break_top]*/
    rhs_slice_target = (object_ptr)&_45break_list_54942;
    RHS_Slice(_45break_list_54942, 1LL, _break_top_55485);

    /** parser.e:433	end procedure*/
    DeRef(_27997);
    _27997 = NOVALUE;
    return;
    ;
}


void _45PatchNList(object _base_55515)
{
    object _next_top_55516 = NOVALUE;
    object _n_55517 = NOVALUE;
    object _28024 = NOVALUE;
    object _28023 = NOVALUE;
    object _28022 = NOVALUE;
    object _28018 = NOVALUE;
    object _28017 = NOVALUE;
    object _28016 = NOVALUE;
    object _28014 = NOVALUE;
    object _28013 = NOVALUE;
    object _28011 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:439		if not length(continue_list) then*/
    if (IS_SEQUENCE(_45continue_list_54946)){
            _28011 = SEQ_PTR(_45continue_list_54946)->length;
    }
    else {
        _28011 = 1;
    }
    if (_28011 != 0)
    goto L1; // [10] 19
    _28011 = NOVALUE;

    /** parser.e:440			return*/
    return;
L1: 

    /** parser.e:443		next_top = 0*/
    _next_top_55516 = 0LL;

    /** parser.e:445		for i=length(continue_list) to base+1 by -1 do*/
    if (IS_SEQUENCE(_45continue_list_54946)){
            _28013 = SEQ_PTR(_45continue_list_54946)->length;
    }
    else {
        _28013 = 1;
    }
    _28014 = _base_55515 + 1;
    if (_28014 > MAXINT){
        _28014 = NewDouble((eudouble)_28014);
    }
    {
        object _i_55522;
        _i_55522 = _28013;
L2: 
        if (binary_op_a(LESS, _i_55522, _28014)){
            goto L3; // [35] 129
        }

        /** parser.e:446			n=continue_delay[i]*/
        _2 = (object)SEQ_PTR(_45continue_delay_54947);
        if (!IS_ATOM_INT(_i_55522)){
            _n_55517 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55522)->dbl));
        }
        else{
            _n_55517 = (object)*(((s1_ptr)_2)->base + _i_55522);
        }
        if (!IS_ATOM_INT(_n_55517))
        _n_55517 = (object)DBL_PTR(_n_55517)->dbl;

        /** parser.e:447			continue_delay[i] -= (n>0)*/
        _28016 = (_n_55517 > 0LL);
        _2 = (object)SEQ_PTR(_45continue_delay_54947);
        if (!IS_ATOM_INT(_i_55522)){
            _28017 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55522)->dbl));
        }
        else{
            _28017 = (object)*(((s1_ptr)_2)->base + _i_55522);
        }
        if (IS_ATOM_INT(_28017)) {
            _28018 = _28017 - _28016;
            if ((object)((uintptr_t)_28018 +(uintptr_t) HIGH_BITS) >= 0){
                _28018 = NewDouble((eudouble)_28018);
            }
        }
        else {
            _28018 = binary_op(MINUS, _28017, _28016);
        }
        _28017 = NOVALUE;
        _28016 = NOVALUE;
        _2 = (object)SEQ_PTR(_45continue_delay_54947);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _45continue_delay_54947 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_55522))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55522)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _i_55522);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _28018;
        if( _1 != _28018 ){
            DeRef(_1);
        }
        _28018 = NOVALUE;

        /** parser.e:448			if n>1 then*/
        if (_n_55517 <= 1LL)
        goto L4; // [72] 93

        /** parser.e:449				if next_top = 0 then*/
        if (_next_top_55516 != 0LL)
        goto L5; // [78] 122

        /** parser.e:450					next_top = i*/
        Ref(_i_55522);
        _next_top_55516 = _i_55522;
        if (!IS_ATOM_INT(_next_top_55516)) {
            _1 = (object)(DBL_PTR(_next_top_55516)->dbl);
            DeRefDS(_next_top_55516);
            _next_top_55516 = _1;
        }
        goto L5; // [90] 122
L4: 

        /** parser.e:452			elsif n=1 then*/
        if (_n_55517 != 1LL)
        goto L6; // [95] 121

        /** parser.e:453				backpatch(continue_list[i],length(Code)+1)*/
        _2 = (object)SEQ_PTR(_45continue_list_54946);
        if (!IS_ATOM_INT(_i_55522)){
            _28022 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55522)->dbl));
        }
        else{
            _28022 = (object)*(((s1_ptr)_2)->base + _i_55522);
        }
        if (IS_SEQUENCE(_36Code_21531)){
                _28023 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _28023 = 1;
        }
        _28024 = _28023 + 1;
        _28023 = NOVALUE;
        _47backpatch(_28022, _28024);
        _28022 = NOVALUE;
        _28024 = NOVALUE;
L6: 
L5: 

        /** parser.e:455		end for*/
        _0 = _i_55522;
        if (IS_ATOM_INT(_i_55522)) {
            _i_55522 = _i_55522 + -1LL;
            if ((object)((uintptr_t)_i_55522 +(uintptr_t) HIGH_BITS) >= 0){
                _i_55522 = NewDouble((eudouble)_i_55522);
            }
        }
        else {
            _i_55522 = binary_op_a(PLUS, _i_55522, -1LL);
        }
        DeRef(_0);
        goto L2; // [124] 42
L3: 
        ;
        DeRef(_i_55522);
    }

    /** parser.e:457		if next_top=0 then*/
    if (_next_top_55516 != 0LL)
    goto L7; // [131] 141

    /** parser.e:458		    next_top=base*/
    _next_top_55516 = _base_55515;
L7: 

    /** parser.e:461		continue_delay =continue_delay[1..next_top]*/
    rhs_slice_target = (object_ptr)&_45continue_delay_54947;
    RHS_Slice(_45continue_delay_54947, 1LL, _next_top_55516);

    /** parser.e:462		continue_list = continue_list[1..next_top]*/
    rhs_slice_target = (object_ptr)&_45continue_list_54946;
    RHS_Slice(_45continue_list_54946, 1LL, _next_top_55516);

    /** parser.e:463	end procedure*/
    DeRef(_28014);
    _28014 = NOVALUE;
    return;
    ;
}


void _45PatchXList(object _base_55546)
{
    object _exit_top_55547 = NOVALUE;
    object _n_55548 = NOVALUE;
    object _28041 = NOVALUE;
    object _28040 = NOVALUE;
    object _28039 = NOVALUE;
    object _28035 = NOVALUE;
    object _28034 = NOVALUE;
    object _28033 = NOVALUE;
    object _28031 = NOVALUE;
    object _28030 = NOVALUE;
    object _28028 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:469		if not length(exit_list) then*/
    if (IS_SEQUENCE(_45exit_list_54944)){
            _28028 = SEQ_PTR(_45exit_list_54944)->length;
    }
    else {
        _28028 = 1;
    }
    if (_28028 != 0)
    goto L1; // [10] 19
    _28028 = NOVALUE;

    /** parser.e:470			return*/
    return;
L1: 

    /** parser.e:473		exit_top = 0*/
    _exit_top_55547 = 0LL;

    /** parser.e:475		for i=length(exit_list) to base+1 by -1 do*/
    if (IS_SEQUENCE(_45exit_list_54944)){
            _28030 = SEQ_PTR(_45exit_list_54944)->length;
    }
    else {
        _28030 = 1;
    }
    _28031 = _base_55546 + 1;
    if (_28031 > MAXINT){
        _28031 = NewDouble((eudouble)_28031);
    }
    {
        object _i_55553;
        _i_55553 = _28030;
L2: 
        if (binary_op_a(LESS, _i_55553, _28031)){
            goto L3; // [35] 129
        }

        /** parser.e:476			n=exit_delay[i]*/
        _2 = (object)SEQ_PTR(_45exit_delay_54945);
        if (!IS_ATOM_INT(_i_55553)){
            _n_55548 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55553)->dbl));
        }
        else{
            _n_55548 = (object)*(((s1_ptr)_2)->base + _i_55553);
        }
        if (!IS_ATOM_INT(_n_55548))
        _n_55548 = (object)DBL_PTR(_n_55548)->dbl;

        /** parser.e:477			exit_delay[i] -= (n>0)*/
        _28033 = (_n_55548 > 0LL);
        _2 = (object)SEQ_PTR(_45exit_delay_54945);
        if (!IS_ATOM_INT(_i_55553)){
            _28034 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55553)->dbl));
        }
        else{
            _28034 = (object)*(((s1_ptr)_2)->base + _i_55553);
        }
        if (IS_ATOM_INT(_28034)) {
            _28035 = _28034 - _28033;
            if ((object)((uintptr_t)_28035 +(uintptr_t) HIGH_BITS) >= 0){
                _28035 = NewDouble((eudouble)_28035);
            }
        }
        else {
            _28035 = binary_op(MINUS, _28034, _28033);
        }
        _28034 = NOVALUE;
        _28033 = NOVALUE;
        _2 = (object)SEQ_PTR(_45exit_delay_54945);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _45exit_delay_54945 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_55553))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55553)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _i_55553);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _28035;
        if( _1 != _28035 ){
            DeRef(_1);
        }
        _28035 = NOVALUE;

        /** parser.e:478			if n>1 then*/
        if (_n_55548 <= 1LL)
        goto L4; // [72] 93

        /** parser.e:479				if exit_top = 0 then*/
        if (_exit_top_55547 != 0LL)
        goto L5; // [78] 122

        /** parser.e:480					exit_top = i*/
        Ref(_i_55553);
        _exit_top_55547 = _i_55553;
        if (!IS_ATOM_INT(_exit_top_55547)) {
            _1 = (object)(DBL_PTR(_exit_top_55547)->dbl);
            DeRefDS(_exit_top_55547);
            _exit_top_55547 = _1;
        }
        goto L5; // [90] 122
L4: 

        /** parser.e:482			elsif n=1 then*/
        if (_n_55548 != 1LL)
        goto L6; // [95] 121

        /** parser.e:483				backpatch(exit_list[i],length(Code)+1)*/
        _2 = (object)SEQ_PTR(_45exit_list_54944);
        if (!IS_ATOM_INT(_i_55553)){
            _28039 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55553)->dbl));
        }
        else{
            _28039 = (object)*(((s1_ptr)_2)->base + _i_55553);
        }
        if (IS_SEQUENCE(_36Code_21531)){
                _28040 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _28040 = 1;
        }
        _28041 = _28040 + 1;
        _28040 = NOVALUE;
        _47backpatch(_28039, _28041);
        _28039 = NOVALUE;
        _28041 = NOVALUE;
L6: 
L5: 

        /** parser.e:485		end for*/
        _0 = _i_55553;
        if (IS_ATOM_INT(_i_55553)) {
            _i_55553 = _i_55553 + -1LL;
            if ((object)((uintptr_t)_i_55553 +(uintptr_t) HIGH_BITS) >= 0){
                _i_55553 = NewDouble((eudouble)_i_55553);
            }
        }
        else {
            _i_55553 = binary_op_a(PLUS, _i_55553, -1LL);
        }
        DeRef(_0);
        goto L2; // [124] 42
L3: 
        ;
        DeRef(_i_55553);
    }

    /** parser.e:487		if exit_top=0 then*/
    if (_exit_top_55547 != 0LL)
    goto L7; // [131] 141

    /** parser.e:488		    exit_top=base*/
    _exit_top_55547 = _base_55546;
L7: 

    /** parser.e:491		exit_delay = exit_delay [1..exit_top]*/
    rhs_slice_target = (object_ptr)&_45exit_delay_54945;
    RHS_Slice(_45exit_delay_54945, 1LL, _exit_top_55547);

    /** parser.e:492		exit_list = exit_list [1..exit_top]*/
    rhs_slice_target = (object_ptr)&_45exit_list_54944;
    RHS_Slice(_45exit_list_54944, 1LL, _exit_top_55547);

    /** parser.e:493	end procedure*/
    DeRef(_28031);
    _28031 = NOVALUE;
    return;
    ;
}


void _45putback(object _t_55578)
{
    object _28046 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:497		backed_up_tok = append(backed_up_tok, t)*/
    Ref(_t_55578);
    Append(&_45backed_up_tok_54931, _45backed_up_tok_54931, _t_55578);

    /** parser.e:499		if t[T_SYM] then*/
    _2 = (object)SEQ_PTR(_t_55578);
    _28046 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (_28046 == 0) {
        _28046 = NOVALUE;
        goto L1; // [17] 79
    }
    else {
        if (!IS_ATOM_INT(_28046) && DBL_PTR(_28046)->dbl == 0.0){
            _28046 = NOVALUE;
            goto L1; // [17] 79
        }
        _28046 = NOVALUE;
    }
    _28046 = NOVALUE;

    /** parser.e:500			putback_ForwardLine     = ForwardLine*/
    Ref(_50ForwardLine_49235);
    DeRef(_50putback_ForwardLine_49236);
    _50putback_ForwardLine_49236 = _50ForwardLine_49235;

    /** parser.e:501			putback_forward_bp      = forward_bp*/
    _50putback_forward_bp_49240 = _50forward_bp_49239;

    /** parser.e:502			putback_fwd_line_number = fwd_line_number*/
    _36putback_fwd_line_number_21442 = _36fwd_line_number_21441;

    /** parser.e:504			if last_fwd_line_number then*/
    if (_36last_fwd_line_number_21443 == 0)
    {
        goto L2; // [49] 78
    }
    else{
    }

    /** parser.e:505				ForwardLine     = last_ForwardLine*/
    Ref(_50last_ForwardLine_49237);
    DeRef(_50ForwardLine_49235);
    _50ForwardLine_49235 = _50last_ForwardLine_49237;

    /** parser.e:506				forward_bp      = last_forward_bp*/
    _50forward_bp_49239 = _50last_forward_bp_49241;

    /** parser.e:507				fwd_line_number = last_fwd_line_number*/
    _36fwd_line_number_21441 = _36last_fwd_line_number_21443;
L2: 
L1: 

    /** parser.e:510	end procedure*/
    DeRef(_t_55578);
    return;
    ;
}


void _45start_recording()
{
    object _0, _1, _2;
    

    /** parser.e:519		psm_stack &= Parser_mode*/
    Append(&_45psm_stack_55597, _45psm_stack_55597, _36Parser_mode_21548);

    /** parser.e:520		can_stack = append(can_stack,canned_tokens)*/
    Ref(_45canned_tokens_54968);
    Append(&_45can_stack_55598, _45can_stack_55598, _45canned_tokens_54968);

    /** parser.e:521		idx_stack &= canned_index*/
    Append(&_45idx_stack_55599, _45idx_stack_55599, _45canned_index_54969);

    /** parser.e:522		tok_stack = append(tok_stack,backed_up_tok)*/
    RefDS(_45backed_up_tok_54931);
    Append(&_45tok_stack_55600, _45tok_stack_55600, _45backed_up_tok_54931);

    /** parser.e:523		canned_tokens = {}*/
    RefDS(_21993);
    DeRef(_45canned_tokens_54968);
    _45canned_tokens_54968 = _21993;

    /** parser.e:524		Parser_mode = PAM_RECORD*/
    _36Parser_mode_21548 = 1LL;

    /** parser.e:525		clear_last()*/
    _47clear_last();

    /** parser.e:526	end procedure*/
    return;
    ;
}


object _45restore_parser()
{
    object _n_55613 = NOVALUE;
    object _tok_55614 = NOVALUE;
    object _x_55615 = NOVALUE;
    object _28077 = NOVALUE;
    object _28076 = NOVALUE;
    object _28075 = NOVALUE;
    object _28073 = NOVALUE;
    object _28069 = NOVALUE;
    object _28068 = NOVALUE;
    object _28066 = NOVALUE;
    object _28064 = NOVALUE;
    object _28063 = NOVALUE;
    object _28061 = NOVALUE;
    object _28059 = NOVALUE;
    object _28058 = NOVALUE;
    object _28056 = NOVALUE;
    object _28054 = NOVALUE;
    object _28053 = NOVALUE;
    object _28051 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:533		n=Parser_mode*/
    _n_55613 = _36Parser_mode_21548;

    /** parser.e:534		x = canned_tokens*/
    Ref(_45canned_tokens_54968);
    DeRef(_x_55615);
    _x_55615 = _45canned_tokens_54968;

    /** parser.e:535		canned_tokens = can_stack[$]*/
    if (IS_SEQUENCE(_45can_stack_55598)){
            _28051 = SEQ_PTR(_45can_stack_55598)->length;
    }
    else {
        _28051 = 1;
    }
    DeRef(_45canned_tokens_54968);
    _2 = (object)SEQ_PTR(_45can_stack_55598);
    _45canned_tokens_54968 = (object)*(((s1_ptr)_2)->base + _28051);
    Ref(_45canned_tokens_54968);

    /** parser.e:536		can_stack     = can_stack[1..$-1]*/
    if (IS_SEQUENCE(_45can_stack_55598)){
            _28053 = SEQ_PTR(_45can_stack_55598)->length;
    }
    else {
        _28053 = 1;
    }
    _28054 = _28053 - 1LL;
    _28053 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45can_stack_55598;
    RHS_Slice(_45can_stack_55598, 1LL, _28054);

    /** parser.e:537		canned_index  = idx_stack[$]*/
    if (IS_SEQUENCE(_45idx_stack_55599)){
            _28056 = SEQ_PTR(_45idx_stack_55599)->length;
    }
    else {
        _28056 = 1;
    }
    _2 = (object)SEQ_PTR(_45idx_stack_55599);
    _45canned_index_54969 = (object)*(((s1_ptr)_2)->base + _28056);

    /** parser.e:538		idx_stack     = idx_stack[1..$-1]*/
    if (IS_SEQUENCE(_45idx_stack_55599)){
            _28058 = SEQ_PTR(_45idx_stack_55599)->length;
    }
    else {
        _28058 = 1;
    }
    _28059 = _28058 - 1LL;
    _28058 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45idx_stack_55599;
    RHS_Slice(_45idx_stack_55599, 1LL, _28059);

    /** parser.e:539		Parser_mode   = psm_stack[$]*/
    if (IS_SEQUENCE(_45psm_stack_55597)){
            _28061 = SEQ_PTR(_45psm_stack_55597)->length;
    }
    else {
        _28061 = 1;
    }
    _2 = (object)SEQ_PTR(_45psm_stack_55597);
    _36Parser_mode_21548 = (object)*(((s1_ptr)_2)->base + _28061);

    /** parser.e:540		psm_stack     = psm_stack[1..$-1]*/
    if (IS_SEQUENCE(_45psm_stack_55597)){
            _28063 = SEQ_PTR(_45psm_stack_55597)->length;
    }
    else {
        _28063 = 1;
    }
    _28064 = _28063 - 1LL;
    _28063 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45psm_stack_55597;
    RHS_Slice(_45psm_stack_55597, 1LL, _28064);

    /** parser.e:541		tok 		  = tok_stack[$]*/
    if (IS_SEQUENCE(_45tok_stack_55600)){
            _28066 = SEQ_PTR(_45tok_stack_55600)->length;
    }
    else {
        _28066 = 1;
    }
    DeRef(_tok_55614);
    _2 = (object)SEQ_PTR(_45tok_stack_55600);
    _tok_55614 = (object)*(((s1_ptr)_2)->base + _28066);
    RefDS(_tok_55614);

    /** parser.e:542		tok_stack 	  = tok_stack[1..$-1]*/
    if (IS_SEQUENCE(_45tok_stack_55600)){
            _28068 = SEQ_PTR(_45tok_stack_55600)->length;
    }
    else {
        _28068 = 1;
    }
    _28069 = _28068 - 1LL;
    _28068 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45tok_stack_55600;
    RHS_Slice(_45tok_stack_55600, 1LL, _28069);

    /** parser.e:543		clear_last()*/
    _47clear_last();

    /** parser.e:544		if n=PAM_PLAYBACK then*/
    if (_n_55613 != -1LL)
    goto L1; // [137] 150

    /** parser.e:545			return {}*/
    RefDS(_21993);
    DeRefDS(_tok_55614);
    DeRefDS(_x_55615);
    _28054 = NOVALUE;
    _28064 = NOVALUE;
    _28059 = NOVALUE;
    _28069 = NOVALUE;
    return _21993;
    goto L2; // [147] 167
L1: 

    /** parser.e:547		elsif n = PAM_NORMAL then*/
    if (_n_55613 != 0LL)
    goto L3; // [154] 166

    /** parser.e:548			use_private_list = 0*/
    _36use_private_list_21556 = 0LL;
L3: 
L2: 

    /** parser.e:550		if length(backed_up_tok) > 0 then*/
    if (IS_SEQUENCE(_45backed_up_tok_54931)){
            _28073 = SEQ_PTR(_45backed_up_tok_54931)->length;
    }
    else {
        _28073 = 1;
    }
    if (_28073 <= 0LL)
    goto L4; // [174] 199

    /** parser.e:551			return x[1..$-1]*/
    if (IS_SEQUENCE(_x_55615)){
            _28075 = SEQ_PTR(_x_55615)->length;
    }
    else {
        _28075 = 1;
    }
    _28076 = _28075 - 1LL;
    _28075 = NOVALUE;
    rhs_slice_target = (object_ptr)&_28077;
    RHS_Slice(_x_55615, 1LL, _28076);
    DeRef(_tok_55614);
    DeRefDS(_x_55615);
    DeRef(_28054);
    _28054 = NOVALUE;
    _28076 = NOVALUE;
    DeRef(_28064);
    _28064 = NOVALUE;
    DeRef(_28059);
    _28059 = NOVALUE;
    DeRef(_28069);
    _28069 = NOVALUE;
    return _28077;
    goto L5; // [196] 206
L4: 

    /** parser.e:553			return x*/
    DeRef(_tok_55614);
    DeRef(_28077);
    _28077 = NOVALUE;
    DeRef(_28054);
    _28054 = NOVALUE;
    DeRef(_28076);
    _28076 = NOVALUE;
    DeRef(_28064);
    _28064 = NOVALUE;
    DeRef(_28059);
    _28059 = NOVALUE;
    DeRef(_28069);
    _28069 = NOVALUE;
    return _x_55615;
L5: 
    ;
}


void _45start_playback(object _s_55655)
{
    object _0, _1, _2;
    

    /** parser.e:558		psm_stack &= Parser_mode*/
    Append(&_45psm_stack_55597, _45psm_stack_55597, _36Parser_mode_21548);

    /** parser.e:559		can_stack = append(can_stack,canned_tokens)*/
    Ref(_45canned_tokens_54968);
    Append(&_45can_stack_55598, _45can_stack_55598, _45canned_tokens_54968);

    /** parser.e:560		idx_stack &= canned_index*/
    Append(&_45idx_stack_55599, _45idx_stack_55599, _45canned_index_54969);

    /** parser.e:561		tok_stack = append(tok_stack,backed_up_tok)*/
    RefDS(_45backed_up_tok_54931);
    Append(&_45tok_stack_55600, _45tok_stack_55600, _45backed_up_tok_54931);

    /** parser.e:562		canned_index = 1*/
    _45canned_index_54969 = 1LL;

    /** parser.e:563		canned_tokens = s*/
    RefDS(_s_55655);
    DeRef(_45canned_tokens_54968);
    _45canned_tokens_54968 = _s_55655;

    /** parser.e:564		backed_up_tok = {}*/
    RefDS(_21993);
    DeRefDS(_45backed_up_tok_54931);
    _45backed_up_tok_54931 = _21993;

    /** parser.e:565		Parser_mode = PAM_PLAYBACK*/
    _36Parser_mode_21548 = -1LL;

    /** parser.e:566	end procedure*/
    DeRefDS(_s_55655);
    return;
    ;
}


void _45restore_parseargs_states()
{
    object _s_55674 = NOVALUE;
    object _n_55675 = NOVALUE;
    object _28094 = NOVALUE;
    object _28093 = NOVALUE;
    object _28085 = NOVALUE;
    object _28084 = NOVALUE;
    object _28082 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:584		s = parseargs_states[$]*/
    if (IS_SEQUENCE(_45parseargs_states_55663)){
            _28082 = SEQ_PTR(_45parseargs_states_55663)->length;
    }
    else {
        _28082 = 1;
    }
    DeRef(_s_55674);
    _2 = (object)SEQ_PTR(_45parseargs_states_55663);
    _s_55674 = (object)*(((s1_ptr)_2)->base + _28082);
    RefDS(_s_55674);

    /** parser.e:585		parseargs_states = parseargs_states[1..$-1]*/
    if (IS_SEQUENCE(_45parseargs_states_55663)){
            _28084 = SEQ_PTR(_45parseargs_states_55663)->length;
    }
    else {
        _28084 = 1;
    }
    _28085 = _28084 - 1LL;
    _28084 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45parseargs_states_55663;
    RHS_Slice(_45parseargs_states_55663, 1LL, _28085);

    /** parser.e:586		n=s[PS_POSITION]*/
    _2 = (object)SEQ_PTR(_s_55674);
    _n_55675 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_n_55675))
    _n_55675 = (object)DBL_PTR(_n_55675)->dbl;

    /** parser.e:587		private_list = private_list[1..n]*/
    rhs_slice_target = (object_ptr)&_45private_list_55668;
    RHS_Slice(_45private_list_55668, 1LL, _n_55675);

    /** parser.e:588		private_sym = private_sym[1..n]*/
    rhs_slice_target = (object_ptr)&_36private_sym_21555;
    RHS_Slice(_36private_sym_21555, 1LL, _n_55675);

    /** parser.e:589		lock_scanner = s[PS_SCAN_LOCK]*/
    _2 = (object)SEQ_PTR(_s_55674);
    _45lock_scanner_55669 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_45lock_scanner_55669))
    _45lock_scanner_55669 = (object)DBL_PTR(_45lock_scanner_55669)->dbl;

    /** parser.e:590		use_private_list = s[PS_USE_LIST]*/
    _2 = (object)SEQ_PTR(_s_55674);
    _36use_private_list_21556 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_36use_private_list_21556)){
        _36use_private_list_21556 = (object)DBL_PTR(_36use_private_list_21556)->dbl;
    }

    /** parser.e:591		on_arg = s[PS_ON_ARG]*/
    _2 = (object)SEQ_PTR(_s_55674);
    _45on_arg_55670 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_45on_arg_55670))
    _45on_arg_55670 = (object)DBL_PTR(_45on_arg_55670)->dbl;

    /** parser.e:592		nested_calls = nested_calls[1..$-1]*/
    if (IS_SEQUENCE(_45nested_calls_55671)){
            _28093 = SEQ_PTR(_45nested_calls_55671)->length;
    }
    else {
        _28093 = 1;
    }
    _28094 = _28093 - 1LL;
    _28093 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45nested_calls_55671;
    RHS_Slice(_45nested_calls_55671, 1LL, _28094);

    /** parser.e:593	end procedure*/
    DeRefDS(_s_55674);
    _28094 = NOVALUE;
    _28085 = NOVALUE;
    return;
    ;
}


object _45read_recorded_token(object _n_55695)
{
    object _t_55697 = NOVALUE;
    object _p_55698 = NOVALUE;
    object _prev_Nne_55699 = NOVALUE;
    object _ts_55728 = NOVALUE;
    object _31696 = NOVALUE;
    object _31695 = NOVALUE;
    object _31694 = NOVALUE;
    object _31693 = NOVALUE;
    object _31692 = NOVALUE;
    object _31691 = NOVALUE;
    object _31690 = NOVALUE;
    object _31689 = NOVALUE;
    object _28166 = NOVALUE;
    object _28165 = NOVALUE;
    object _28164 = NOVALUE;
    object _28163 = NOVALUE;
    object _28159 = NOVALUE;
    object _28157 = NOVALUE;
    object _28156 = NOVALUE;
    object _28155 = NOVALUE;
    object _28154 = NOVALUE;
    object _28152 = NOVALUE;
    object _28151 = NOVALUE;
    object _28150 = NOVALUE;
    object _28149 = NOVALUE;
    object _28147 = NOVALUE;
    object _28144 = NOVALUE;
    object _28142 = NOVALUE;
    object _28140 = NOVALUE;
    object _28139 = NOVALUE;
    object _28138 = NOVALUE;
    object _28137 = NOVALUE;
    object _28135 = NOVALUE;
    object _28133 = NOVALUE;
    object _28129 = NOVALUE;
    object _28127 = NOVALUE;
    object _28125 = NOVALUE;
    object _28124 = NOVALUE;
    object _28123 = NOVALUE;
    object _28122 = NOVALUE;
    object _28121 = NOVALUE;
    object _28120 = NOVALUE;
    object _28119 = NOVALUE;
    object _28118 = NOVALUE;
    object _28117 = NOVALUE;
    object _28116 = NOVALUE;
    object _28115 = NOVALUE;
    object _28114 = NOVALUE;
    object _28112 = NOVALUE;
    object _28111 = NOVALUE;
    object _28109 = NOVALUE;
    object _28108 = NOVALUE;
    object _28107 = NOVALUE;
    object _28106 = NOVALUE;
    object _28105 = NOVALUE;
    object _28104 = NOVALUE;
    object _28103 = NOVALUE;
    object _28102 = NOVALUE;
    object _28099 = NOVALUE;
    object _28097 = NOVALUE;
    object _28096 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_n_55695)) {
        _1 = (object)(DBL_PTR(_n_55695)->dbl);
        DeRefDS(_n_55695);
        _n_55695 = _1;
    }

    /** parser.e:597		integer p, prev_Nne*/

    /** parser.e:598		if atom(Ns_recorded[n]) label "top if" then*/
    _2 = (object)SEQ_PTR(_36Ns_recorded_21550);
    _28096 = (object)*(((s1_ptr)_2)->base + _n_55695);
    _28097 = IS_ATOM(_28096);
    _28096 = NOVALUE;
    if (_28097 == 0)
    {
        _28097 = NOVALUE;
        goto L1; // [16] 405
    }
    else{
        _28097 = NOVALUE;
    }

    /** parser.e:599			if use_private_list then*/
    if (_36use_private_list_21556 == 0)
    {
        goto L2; // [23] 171
    }
    else{
    }

    /** parser.e:600				p = find( Recorded[n], private_list)*/
    _2 = (object)SEQ_PTR(_36Recorded_21549);
    _28099 = (object)*(((s1_ptr)_2)->base + _n_55695);
    _p_55698 = find_from(_28099, _45private_list_55668, 1LL);
    _28099 = NOVALUE;

    /** parser.e:601				if p > 0 then -- the value of this parameter is known, use it*/
    if (_p_55698 <= 0LL)
    goto L3; // [43] 170

    /** parser.e:603					if TRANSLATE*/
    if (_36TRANSLATE_21041 == 0) {
        goto L4; // [51] 150
    }
    _2 = (object)SEQ_PTR(_36private_sym_21555);
    _28103 = (object)*(((s1_ptr)_2)->base + _p_55698);
    if (IS_ATOM_INT(_28103)) {
        _28104 = (_28103 < 0LL);
    }
    else {
        _28104 = binary_op(LESS, _28103, 0LL);
    }
    _28103 = NOVALUE;
    if (IS_ATOM_INT(_28104)) {
        if (_28104 != 0) {
            _28105 = 1;
            goto L5; // [65] 97
        }
    }
    else {
        if (DBL_PTR(_28104)->dbl != 0.0) {
            _28105 = 1;
            goto L5; // [65] 97
        }
    }
    _2 = (object)SEQ_PTR(_36private_sym_21555);
    _28106 = (object)*(((s1_ptr)_2)->base + _p_55698);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_28106)){
        _28107 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28106)->dbl));
    }
    else{
        _28107 = (object)*(((s1_ptr)_2)->base + _28106);
    }
    _2 = (object)SEQ_PTR(_28107);
    _28108 = (object)*(((s1_ptr)_2)->base + 3LL);
    _28107 = NOVALUE;
    if (IS_ATOM_INT(_28108)) {
        _28109 = (_28108 == 3LL);
    }
    else {
        _28109 = binary_op(EQUALS, _28108, 3LL);
    }
    _28108 = NOVALUE;
    DeRef(_28105);
    if (IS_ATOM_INT(_28109))
    _28105 = (_28109 != 0);
    else
    _28105 = DBL_PTR(_28109)->dbl != 0.0;
L5: 
    if (_28105 == 0)
    {
        _28105 = NOVALUE;
        goto L4; // [98] 150
    }
    else{
        _28105 = NOVALUE;
    }

    /** parser.e:610						symtab_index ts = NewTempSym()*/
    _ts_55728 = _54NewTempSym(0LL);
    if (!IS_ATOM_INT(_ts_55728)) {
        _1 = (object)(DBL_PTR(_ts_55728)->dbl);
        DeRefDS(_ts_55728);
        _ts_55728 = _1;
    }

    /** parser.e:611						Code &= { ASSIGN, private_sym[p], ts }*/
    _2 = (object)SEQ_PTR(_36private_sym_21555);
    _28111 = (object)*(((s1_ptr)_2)->base + _p_55698);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 18LL;
    Ref(_28111);
    ((intptr_t*)_2)[2] = _28111;
    ((intptr_t*)_2)[3] = _ts_55728;
    _28112 = MAKE_SEQ(_1);
    _28111 = NOVALUE;
    Concat((object_ptr)&_36Code_21531, _36Code_21531, _28112);
    DeRefDS(_28112);
    _28112 = NOVALUE;

    /** parser.e:612						return {VARIABLE, ts}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100LL;
    ((intptr_t *)_2)[2] = _ts_55728;
    _28114 = MAKE_SEQ(_1);
    DeRef(_t_55697);
    _28106 = NOVALUE;
    DeRef(_28109);
    _28109 = NOVALUE;
    DeRef(_28104);
    _28104 = NOVALUE;
    return _28114;
    goto L6; // [147] 169
L4: 

    /** parser.e:614						return {VARIABLE, private_sym[p]}*/
    _2 = (object)SEQ_PTR(_36private_sym_21555);
    _28115 = (object)*(((s1_ptr)_2)->base + _p_55698);
    Ref(_28115);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100LL;
    ((intptr_t *)_2)[2] = _28115;
    _28116 = MAKE_SEQ(_1);
    _28115 = NOVALUE;
    DeRef(_t_55697);
    DeRef(_28114);
    _28114 = NOVALUE;
    _28106 = NOVALUE;
    DeRef(_28109);
    _28109 = NOVALUE;
    DeRef(_28104);
    _28104 = NOVALUE;
    return _28116;
L6: 
L3: 
L2: 

    /** parser.e:620			prev_Nne = No_new_entry*/
    _prev_Nne_55699 = _54No_new_entry_47974;

    /** parser.e:621			No_new_entry = 1*/
    _54No_new_entry_47974 = 1LL;

    /** parser.e:623			if Recorded_sym[n] > 0 and  sym_scope( Recorded_sym[n] ) != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_36Recorded_sym_21551);
    _28117 = (object)*(((s1_ptr)_2)->base + _n_55695);
    if (IS_ATOM_INT(_28117)) {
        _28118 = (_28117 > 0LL);
    }
    else {
        _28118 = binary_op(GREATER, _28117, 0LL);
    }
    _28117 = NOVALUE;
    if (IS_ATOM_INT(_28118)) {
        if (_28118 == 0) {
            goto L7; // [199] 250
        }
    }
    else {
        if (DBL_PTR(_28118)->dbl == 0.0) {
            goto L7; // [199] 250
        }
    }
    _2 = (object)SEQ_PTR(_36Recorded_sym_21551);
    _28120 = (object)*(((s1_ptr)_2)->base + _n_55695);
    Ref(_28120);
    _28121 = _54sym_scope(_28120);
    _28120 = NOVALUE;
    if (IS_ATOM_INT(_28121)) {
        _28122 = (_28121 != 9LL);
    }
    else {
        _28122 = binary_op(NOTEQ, _28121, 9LL);
    }
    DeRef(_28121);
    _28121 = NOVALUE;
    if (_28122 == 0) {
        DeRef(_28122);
        _28122 = NOVALUE;
        goto L7; // [220] 250
    }
    else {
        if (!IS_ATOM_INT(_28122) && DBL_PTR(_28122)->dbl == 0.0){
            DeRef(_28122);
            _28122 = NOVALUE;
            goto L7; // [220] 250
        }
        DeRef(_28122);
        _28122 = NOVALUE;
    }
    DeRef(_28122);
    _28122 = NOVALUE;

    /** parser.e:624				t = { sym_token( Recorded_sym[n] ), Recorded_sym[n] }*/
    _2 = (object)SEQ_PTR(_36Recorded_sym_21551);
    _28123 = (object)*(((s1_ptr)_2)->base + _n_55695);
    Ref(_28123);
    _28124 = _54sym_token(_28123);
    _28123 = NOVALUE;
    _2 = (object)SEQ_PTR(_36Recorded_sym_21551);
    _28125 = (object)*(((s1_ptr)_2)->base + _n_55695);
    Ref(_28125);
    DeRef(_t_55697);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28124;
    ((intptr_t *)_2)[2] = _28125;
    _t_55697 = MAKE_SEQ(_1);
    _28125 = NOVALUE;
    _28124 = NOVALUE;

    /** parser.e:625				break "top if"*/
    goto L8; // [247] 734
L7: 

    /** parser.e:628			t = keyfind(Recorded[n],-1)*/
    _2 = (object)SEQ_PTR(_36Recorded_21549);
    _28127 = (object)*(((s1_ptr)_2)->base + _n_55695);
    RefDS(_28127);
    DeRef(_31695);
    _31695 = _28127;
    _31696 = _54hashfn(_31695);
    _31695 = NOVALUE;
    RefDS(_28127);
    _0 = _t_55697;
    _t_55697 = _54keyfind(_28127, -1LL, _36current_file_no_21439, 0LL, _31696);
    DeRef(_0);
    _28127 = NOVALUE;
    _31696 = NOVALUE;

    /** parser.e:629			if t[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_t_55697);
    _28129 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28129, 509LL)){
        _28129 = NOVALUE;
        goto L8; // [286] 734
    }
    _28129 = NOVALUE;

    /** parser.e:630		        p = Recorded_sym[n]*/
    _2 = (object)SEQ_PTR(_36Recorded_sym_21551);
    _p_55698 = (object)*(((s1_ptr)_2)->base + _n_55695);
    if (!IS_ATOM_INT(_p_55698)){
        _p_55698 = (object)DBL_PTR(_p_55698)->dbl;
    }

    /** parser.e:631		        if p = 0 then*/
    if (_p_55698 != 0LL)
    goto L9; // [302] 382

    /** parser.e:633					No_new_entry = 0*/
    _54No_new_entry_47974 = 0LL;

    /** parser.e:634					t = keyfind( Recorded[n], -1 )*/
    _2 = (object)SEQ_PTR(_36Recorded_21549);
    _28133 = (object)*(((s1_ptr)_2)->base + _n_55695);
    RefDS(_28133);
    DeRef(_31693);
    _31693 = _28133;
    _31694 = _54hashfn(_31693);
    _31693 = NOVALUE;
    RefDS(_28133);
    _0 = _t_55697;
    _t_55697 = _54keyfind(_28133, -1LL, _36current_file_no_21439, 0LL, _31694);
    DeRef(_0);
    _28133 = NOVALUE;
    _31694 = NOVALUE;

    /** parser.e:635					No_new_entry = 1*/
    _54No_new_entry_47974 = 1LL;

    /** parser.e:636					if t[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_t_55697);
    _28135 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28135, 509LL)){
        _28135 = NOVALUE;
        goto L8; // [355] 734
    }
    _28135 = NOVALUE;

    /** parser.e:637						CompileErr(VARIABLE_1_HAS_NOT_BEEN_DECLARED,{Recorded[n]})*/
    _2 = (object)SEQ_PTR(_36Recorded_21549);
    _28137 = (object)*(((s1_ptr)_2)->base + _n_55695);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_28137);
    ((intptr_t*)_2)[1] = _28137;
    _28138 = MAKE_SEQ(_1);
    _28137 = NOVALUE;
    _50CompileErr(157LL, _28138, 0LL);
    _28138 = NOVALUE;
    goto L8; // [379] 734
L9: 

    /** parser.e:640					t = {SymTab[p][S_TOKEN], p}*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28139 = (object)*(((s1_ptr)_2)->base + _p_55698);
    _2 = (object)SEQ_PTR(_28139);
    if (!IS_ATOM_INT(_36S_TOKEN_21081)){
        _28140 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    }
    else{
        _28140 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    }
    _28139 = NOVALUE;
    Ref(_28140);
    DeRef(_t_55697);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28140;
    ((intptr_t *)_2)[2] = _p_55698;
    _t_55697 = MAKE_SEQ(_1);
    _28140 = NOVALUE;
    goto L8; // [402] 734
L1: 

    /** parser.e:644			prev_Nne = No_new_entry*/
    _prev_Nne_55699 = _54No_new_entry_47974;

    /** parser.e:645			No_new_entry = 1*/
    _54No_new_entry_47974 = 1LL;

    /** parser.e:646			t = keyfind(Ns_recorded[n],-1, , 1)*/
    _2 = (object)SEQ_PTR(_36Ns_recorded_21550);
    _28142 = (object)*(((s1_ptr)_2)->base + _n_55695);
    Ref(_28142);
    DeRef(_31691);
    _31691 = _28142;
    _31692 = _54hashfn(_31691);
    _31691 = NOVALUE;
    Ref(_28142);
    _0 = _t_55697;
    _t_55697 = _54keyfind(_28142, -1LL, _36current_file_no_21439, 1LL, _31692);
    DeRef(_0);
    _28142 = NOVALUE;
    _31692 = NOVALUE;

    /** parser.e:647			if t[T_ID] != NAMESPACE then*/
    _2 = (object)SEQ_PTR(_t_55697);
    _28144 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _28144, 523LL)){
        _28144 = NOVALUE;
        goto LA; // [456] 524
    }
    _28144 = NOVALUE;

    /** parser.e:648				p = Ns_recorded_sym[n]*/
    _2 = (object)SEQ_PTR(_36Ns_recorded_sym_21552);
    _p_55698 = (object)*(((s1_ptr)_2)->base + _n_55695);
    if (!IS_ATOM_INT(_p_55698)){
        _p_55698 = (object)DBL_PTR(_p_55698)->dbl;
    }

    /** parser.e:649				if p = 0 or sym_token( p ) != NAMESPACE then*/
    _28147 = (_p_55698 == 0LL);
    if (_28147 != 0) {
        goto LB; // [476] 495
    }
    _28149 = _54sym_token(_p_55698);
    if (IS_ATOM_INT(_28149)) {
        _28150 = (_28149 != 523LL);
    }
    else {
        _28150 = binary_op(NOTEQ, _28149, 523LL);
    }
    DeRef(_28149);
    _28149 = NOVALUE;
    if (_28150 == 0) {
        DeRef(_28150);
        _28150 = NOVALUE;
        goto LC; // [491] 515
    }
    else {
        if (!IS_ATOM_INT(_28150) && DBL_PTR(_28150)->dbl == 0.0){
            DeRef(_28150);
            _28150 = NOVALUE;
            goto LC; // [491] 515
        }
        DeRef(_28150);
        _28150 = NOVALUE;
    }
    DeRef(_28150);
    _28150 = NOVALUE;
LB: 

    /** parser.e:650					CompileErr(UNKNOWN_NAMESPACE_1_IN_DEFAULT_ARGUMENT, {Ns_recorded[n]})*/
    _2 = (object)SEQ_PTR(_36Ns_recorded_21550);
    _28151 = (object)*(((s1_ptr)_2)->base + _n_55695);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_28151);
    ((intptr_t*)_2)[1] = _28151;
    _28152 = MAKE_SEQ(_1);
    _28151 = NOVALUE;
    _50CompileErr(153LL, _28152, 0LL);
    _28152 = NOVALUE;
LC: 

    /** parser.e:652				t = {NAMESPACE, p}*/
    DeRef(_t_55697);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 523LL;
    ((intptr_t *)_2)[2] = _p_55698;
    _t_55697 = MAKE_SEQ(_1);
LA: 

    /** parser.e:655			t = keyfind(Recorded[n],SymTab[t[T_SYM]][S_OBJ])*/
    _2 = (object)SEQ_PTR(_36Recorded_21549);
    _28154 = (object)*(((s1_ptr)_2)->base + _n_55695);
    _2 = (object)SEQ_PTR(_t_55697);
    _28155 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_28155)){
        _28156 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28155)->dbl));
    }
    else{
        _28156 = (object)*(((s1_ptr)_2)->base + _28155);
    }
    _2 = (object)SEQ_PTR(_28156);
    _28157 = (object)*(((s1_ptr)_2)->base + 1LL);
    _28156 = NOVALUE;
    RefDS(_28154);
    DeRef(_31689);
    _31689 = _28154;
    _31690 = _54hashfn(_31689);
    _31689 = NOVALUE;
    RefDS(_28154);
    Ref(_28157);
    _0 = _t_55697;
    _t_55697 = _54keyfind(_28154, _28157, _36current_file_no_21439, 0LL, _31690);
    DeRef(_0);
    _28154 = NOVALUE;
    _28157 = NOVALUE;
    _31690 = NOVALUE;

    /** parser.e:656			if t[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_t_55697);
    _28159 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28159, 509LL)){
        _28159 = NOVALUE;
        goto LD; // [577] 636
    }
    _28159 = NOVALUE;

    /** parser.e:657		        p = Recorded_sym[n]*/
    _2 = (object)SEQ_PTR(_36Recorded_sym_21551);
    _p_55698 = (object)*(((s1_ptr)_2)->base + _n_55695);
    if (!IS_ATOM_INT(_p_55698)){
        _p_55698 = (object)DBL_PTR(_p_55698)->dbl;
    }

    /** parser.e:658		        if p = 0 then*/
    if (_p_55698 != 0LL)
    goto LE; // [593] 617

    /** parser.e:659		        	CompileErr(VARIABLE_1_HAS_NOT_BEEN_DECLARED,{Recorded[n]})*/
    _2 = (object)SEQ_PTR(_36Recorded_21549);
    _28163 = (object)*(((s1_ptr)_2)->base + _n_55695);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_28163);
    ((intptr_t*)_2)[1] = _28163;
    _28164 = MAKE_SEQ(_1);
    _28163 = NOVALUE;
    _50CompileErr(157LL, _28164, 0LL);
    _28164 = NOVALUE;
LE: 

    /** parser.e:661			    t = {SymTab[p][S_TOKEN], p}*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28165 = (object)*(((s1_ptr)_2)->base + _p_55698);
    _2 = (object)SEQ_PTR(_28165);
    if (!IS_ATOM_INT(_36S_TOKEN_21081)){
        _28166 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    }
    else{
        _28166 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    }
    _28165 = NOVALUE;
    Ref(_28166);
    DeRef(_t_55697);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28166;
    ((intptr_t *)_2)[2] = _p_55698;
    _t_55697 = MAKE_SEQ(_1);
    _28166 = NOVALUE;
LD: 

    /** parser.e:663			n = t[T_ID]*/
    _2 = (object)SEQ_PTR(_t_55697);
    _n_55695 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_n_55695)){
        _n_55695 = (object)DBL_PTR(_n_55695)->dbl;
    }

    /** parser.e:664			if n = VARIABLE then*/
    if (_n_55695 != -100LL)
    goto LF; // [650] 666

    /** parser.e:665				n = QUALIFIED_VARIABLE*/
    _n_55695 = 512LL;
    goto L10; // [663] 725
LF: 

    /** parser.e:666			elsif n = FUNC then*/
    if (_n_55695 != 501LL)
    goto L11; // [670] 686

    /** parser.e:667				n = QUALIFIED_FUNC*/
    _n_55695 = 520LL;
    goto L10; // [683] 725
L11: 

    /** parser.e:668			elsif n = PROC then*/
    if (_n_55695 != 27LL)
    goto L12; // [690] 706

    /** parser.e:669				n = QUALIFIED_PROC*/
    _n_55695 = 521LL;
    goto L10; // [703] 725
L12: 

    /** parser.e:670			elsif n = TYPE then*/
    if (_n_55695 != 504LL)
    goto L13; // [710] 724

    /** parser.e:671				n = QUALIFIED_TYPE*/
    _n_55695 = 522LL;
L13: 
L10: 

    /** parser.e:673			t[T_ID] = n*/
    _2 = (object)SEQ_PTR(_t_55697);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _t_55697 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _n_55695;
    DeRef(_1);
L8: 

    /** parser.e:675		No_new_entry = prev_Nne*/
    _54No_new_entry_47974 = _prev_Nne_55699;

    /** parser.e:676	  	return t*/
    DeRef(_28114);
    _28114 = NOVALUE;
    DeRef(_28116);
    _28116 = NOVALUE;
    _28106 = NOVALUE;
    DeRef(_28109);
    _28109 = NOVALUE;
    DeRef(_28147);
    _28147 = NOVALUE;
    DeRef(_28104);
    _28104 = NOVALUE;
    _28155 = NOVALUE;
    DeRef(_28118);
    _28118 = NOVALUE;
    return _t_55697;
    ;
}


object _45next_token()
{
    object _t_55879 = NOVALUE;
    object _s_55880 = NOVALUE;
    object _28205 = NOVALUE;
    object _28204 = NOVALUE;
    object _28203 = NOVALUE;
    object _28202 = NOVALUE;
    object _28201 = NOVALUE;
    object _28200 = NOVALUE;
    object _28199 = NOVALUE;
    object _28198 = NOVALUE;
    object _28196 = NOVALUE;
    object _28195 = NOVALUE;
    object _28194 = NOVALUE;
    object _28193 = NOVALUE;
    object _28191 = NOVALUE;
    object _28189 = NOVALUE;
    object _28187 = NOVALUE;
    object _28183 = NOVALUE;
    object _28180 = NOVALUE;
    object _28177 = NOVALUE;
    object _28175 = NOVALUE;
    object _28173 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:682		sequence s*/

    /** parser.e:684		if length(backed_up_tok) > 0 then*/
    if (IS_SEQUENCE(_45backed_up_tok_54931)){
            _28173 = SEQ_PTR(_45backed_up_tok_54931)->length;
    }
    else {
        _28173 = 1;
    }
    if (_28173 <= 0LL)
    goto L1; // [10] 82

    /** parser.e:685			t = backed_up_tok[$]*/
    if (IS_SEQUENCE(_45backed_up_tok_54931)){
            _28175 = SEQ_PTR(_45backed_up_tok_54931)->length;
    }
    else {
        _28175 = 1;
    }
    DeRef(_t_55879);
    _2 = (object)SEQ_PTR(_45backed_up_tok_54931);
    _t_55879 = (object)*(((s1_ptr)_2)->base + _28175);
    Ref(_t_55879);

    /** parser.e:686			backed_up_tok = remove( backed_up_tok, length( backed_up_tok ) )*/
    if (IS_SEQUENCE(_45backed_up_tok_54931)){
            _28177 = SEQ_PTR(_45backed_up_tok_54931)->length;
    }
    else {
        _28177 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_45backed_up_tok_54931);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_28177)) ? _28177 : (object)(DBL_PTR(_28177)->dbl);
        int stop = (IS_ATOM_INT(_28177)) ? _28177 : (object)(DBL_PTR(_28177)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_45backed_up_tok_54931), start, &_45backed_up_tok_54931 );
            }
            else Tail(SEQ_PTR(_45backed_up_tok_54931), stop+1, &_45backed_up_tok_54931);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_45backed_up_tok_54931), start, &_45backed_up_tok_54931);
        }
        else {
            assign_slice_seq = &assign_space;
            _45backed_up_tok_54931 = Remove_elements(start, stop, (SEQ_PTR(_45backed_up_tok_54931)->ref == 1));
        }
    }
    _28177 = NOVALUE;
    _28177 = NOVALUE;

    /** parser.e:687			if putback_fwd_line_number then*/
    if (_36putback_fwd_line_number_21442 == 0)
    {
        goto L2; // [43] 349
    }
    else{
    }

    /** parser.e:689				ForwardLine     = putback_ForwardLine*/
    Ref(_50putback_ForwardLine_49236);
    DeRef(_50ForwardLine_49235);
    _50ForwardLine_49235 = _50putback_ForwardLine_49236;

    /** parser.e:690				forward_bp      = putback_forward_bp*/
    _50forward_bp_49239 = _50putback_forward_bp_49240;

    /** parser.e:691				fwd_line_number = putback_fwd_line_number*/
    _36fwd_line_number_21441 = _36putback_fwd_line_number_21442;

    /** parser.e:693				putback_fwd_line_number = 0*/
    _36putback_fwd_line_number_21442 = 0LL;
    goto L2; // [79] 349
L1: 

    /** parser.e:696		elsif Parser_mode = PAM_PLAYBACK then*/
    if (_36Parser_mode_21548 != -1LL)
    goto L3; // [88] 302

    /** parser.e:697			if canned_index <= length(canned_tokens) then*/
    if (IS_SEQUENCE(_45canned_tokens_54968)){
            _28180 = SEQ_PTR(_45canned_tokens_54968)->length;
    }
    else {
        _28180 = 1;
    }
    if (_45canned_index_54969 > _28180)
    goto L4; // [101] 150

    /** parser.e:698				t = canned_tokens[canned_index]*/
    DeRef(_t_55879);
    _2 = (object)SEQ_PTR(_45canned_tokens_54968);
    _t_55879 = (object)*(((s1_ptr)_2)->base + _45canned_index_54969);
    Ref(_t_55879);

    /** parser.e:699				if canned_index < length(canned_tokens) then*/
    if (IS_SEQUENCE(_45canned_tokens_54968)){
            _28183 = SEQ_PTR(_45canned_tokens_54968)->length;
    }
    else {
        _28183 = 1;
    }
    if (_45canned_index_54969 >= _28183)
    goto L5; // [124] 139

    /** parser.e:700					canned_index += 1*/
    _45canned_index_54969 = _45canned_index_54969 + 1;
    goto L6; // [136] 157
L5: 

    /** parser.e:702		            s = restore_parser()*/
    _0 = _s_55880;
    _s_55880 = _45restore_parser();
    DeRef(_0);
    goto L6; // [147] 157
L4: 

    /** parser.e:705		    	InternalErr(266)*/
    RefDS(_21993);
    _50InternalErr(266LL, _21993);
L6: 

    /** parser.e:707			if t[T_ID] = RECORDED then*/
    _2 = (object)SEQ_PTR(_t_55879);
    _28187 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28187, 508LL)){
        _28187 = NOVALUE;
        goto L7; // [169] 188
    }
    _28187 = NOVALUE;

    /** parser.e:708				t=read_recorded_token(t[T_SYM])*/
    _2 = (object)SEQ_PTR(_t_55879);
    _28189 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_28189);
    _0 = _t_55879;
    _t_55879 = _45read_recorded_token(_28189);
    DeRef(_0);
    _28189 = NOVALUE;
    goto L2; // [185] 349
L7: 

    /** parser.e:709			elsif t[T_ID] = DEF_PARAM then*/
    _2 = (object)SEQ_PTR(_t_55879);
    _28191 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28191, 510LL)){
        _28191 = NOVALUE;
        goto L2; // [198] 349
    }
    _28191 = NOVALUE;

    /** parser.e:710	        	for i=length(nested_calls) to 1 by -1 do*/
    if (IS_SEQUENCE(_45nested_calls_55671)){
            _28193 = SEQ_PTR(_45nested_calls_55671)->length;
    }
    else {
        _28193 = 1;
    }
    {
        object _i_55927;
        _i_55927 = _28193;
L8: 
        if (_i_55927 < 1LL){
            goto L9; // [209] 288
        }

        /** parser.e:711	        	    if nested_calls[i] = t[T_SYM][2] then*/
        _2 = (object)SEQ_PTR(_45nested_calls_55671);
        _28194 = (object)*(((s1_ptr)_2)->base + _i_55927);
        _2 = (object)SEQ_PTR(_t_55879);
        _28195 = (object)*(((s1_ptr)_2)->base + 2LL);
        _2 = (object)SEQ_PTR(_28195);
        _28196 = (object)*(((s1_ptr)_2)->base + 2LL);
        _28195 = NOVALUE;
        if (binary_op_a(NOTEQ, _28194, _28196)){
            _28194 = NOVALUE;
            _28196 = NOVALUE;
            goto LA; // [234] 281
        }
        _28194 = NOVALUE;
        _28196 = NOVALUE;

        /** parser.e:712						return {VARIABLE, private_sym[parseargs_states[i][PS_POSITION]+t[T_SYM][1]]}*/
        _2 = (object)SEQ_PTR(_45parseargs_states_55663);
        _28198 = (object)*(((s1_ptr)_2)->base + _i_55927);
        _2 = (object)SEQ_PTR(_28198);
        _28199 = (object)*(((s1_ptr)_2)->base + 1LL);
        _28198 = NOVALUE;
        _2 = (object)SEQ_PTR(_t_55879);
        _28200 = (object)*(((s1_ptr)_2)->base + 2LL);
        _2 = (object)SEQ_PTR(_28200);
        _28201 = (object)*(((s1_ptr)_2)->base + 1LL);
        _28200 = NOVALUE;
        if (IS_ATOM_INT(_28199) && IS_ATOM_INT(_28201)) {
            _28202 = _28199 + _28201;
        }
        else {
            _28202 = binary_op(PLUS, _28199, _28201);
        }
        _28199 = NOVALUE;
        _28201 = NOVALUE;
        _2 = (object)SEQ_PTR(_36private_sym_21555);
        if (!IS_ATOM_INT(_28202)){
            _28203 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28202)->dbl));
        }
        else{
            _28203 = (object)*(((s1_ptr)_2)->base + _28202);
        }
        Ref(_28203);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -100LL;
        ((intptr_t *)_2)[2] = _28203;
        _28204 = MAKE_SEQ(_1);
        _28203 = NOVALUE;
        DeRef(_t_55879);
        DeRef(_s_55880);
        DeRef(_28202);
        _28202 = NOVALUE;
        return _28204;
LA: 

        /** parser.e:714				end for*/
        _i_55927 = _i_55927 + -1LL;
        goto L8; // [283] 216
L9: 
        ;
    }

    /** parser.e:715				CompileErr(INTERNAL_NESTED_CALL_PARSING_ERROR)*/
    RefDS(_21993);
    _50CompileErr(98LL, _21993, 0LL);
    goto L2; // [299] 349
L3: 

    /** parser.e:717		elsif lock_scanner then*/
    if (_45lock_scanner_55669 == 0)
    {
        goto LB; // [306] 324
    }
    else{
    }

    /** parser.e:718			return {PLAYBACK_ENDS,0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 505LL;
    ((intptr_t *)_2)[2] = 0LL;
    _28205 = MAKE_SEQ(_1);
    DeRef(_t_55879);
    DeRef(_s_55880);
    DeRef(_28204);
    _28204 = NOVALUE;
    DeRef(_28202);
    _28202 = NOVALUE;
    return _28205;
    goto L2; // [321] 349
LB: 

    /** parser.e:720		    t = Scanner()*/
    _0 = _t_55879;
    _t_55879 = _62Scanner();
    DeRef(_0);

    /** parser.e:721		    if Parser_mode = PAM_RECORD then*/
    if (_36Parser_mode_21548 != 1LL)
    goto LC; // [335] 348

    /** parser.e:722		        canned_tokens = append(canned_tokens,t)*/
    Ref(_t_55879);
    Append(&_45canned_tokens_54968, _45canned_tokens_54968, _t_55879);
LC: 
L2: 

    /** parser.e:725		putback_fwd_line_number = 0*/
    _36putback_fwd_line_number_21442 = 0LL;

    /** parser.e:726		return t*/
    DeRef(_s_55880);
    DeRef(_28205);
    _28205 = NOVALUE;
    DeRef(_28204);
    _28204 = NOVALUE;
    DeRef(_28202);
    _28202 = NOVALUE;
    return _t_55879;
    ;
}


object _45Expr_list()
{
    object _tok_55963 = NOVALUE;
    object _n_55964 = NOVALUE;
    object _28221 = NOVALUE;
    object _28218 = NOVALUE;
    object _28217 = NOVALUE;
    object _28215 = NOVALUE;
    object _28214 = NOVALUE;
    object _28210 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:734		integer n*/

    /** parser.e:736		tok = next_token()*/
    _0 = _tok_55963;
    _tok_55963 = _45next_token();
    DeRef(_0);

    /** parser.e:737		putback(tok)*/
    Ref(_tok_55963);
    _45putback(_tok_55963);

    /** parser.e:738		if tok[T_ID] = RIGHT_BRACE then*/
    _2 = (object)SEQ_PTR(_tok_55963);
    _28210 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28210, -25LL)){
        _28210 = NOVALUE;
        goto L1; // [23] 36
    }
    _28210 = NOVALUE;

    /** parser.e:739			return 0*/
    DeRef(_tok_55963);
    return 0LL;
    goto L2; // [33] 142
L1: 

    /** parser.e:741			n = 0*/
    _n_55964 = 0LL;

    /** parser.e:742			short_circuit -= 1*/
    _45short_circuit_54924 = _45short_circuit_54924 - 1LL;

    /** parser.e:743			while TRUE do*/
L3: 
    if (_13TRUE_452 == 0)
    {
        goto L4; // [56] 133
    }
    else{
    }

    /** parser.e:744				gListItem &= 1*/
    Append(&_45gListItem_54960, _45gListItem_54960, 1LL);

    /** parser.e:745				Expr()*/
    _45Expr();

    /** parser.e:746				n += gListItem[$]*/
    if (IS_SEQUENCE(_45gListItem_54960)){
            _28214 = SEQ_PTR(_45gListItem_54960)->length;
    }
    else {
        _28214 = 1;
    }
    _2 = (object)SEQ_PTR(_45gListItem_54960);
    _28215 = (object)*(((s1_ptr)_2)->base + _28214);
    _n_55964 = _n_55964 + _28215;
    _28215 = NOVALUE;

    /** parser.e:747				gListItem = gListItem[1 .. $-1]*/
    if (IS_SEQUENCE(_45gListItem_54960)){
            _28217 = SEQ_PTR(_45gListItem_54960)->length;
    }
    else {
        _28217 = 1;
    }
    _28218 = _28217 - 1LL;
    _28217 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45gListItem_54960;
    RHS_Slice(_45gListItem_54960, 1LL, _28218);

    /** parser.e:748				tok = next_token()*/
    _0 = _tok_55963;
    _tok_55963 = _45next_token();
    DeRef(_0);

    /** parser.e:749				if tok[T_ID] != COMMA then*/
    _2 = (object)SEQ_PTR(_tok_55963);
    _28221 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _28221, -30LL)){
        _28221 = NOVALUE;
        goto L3; // [119] 54
    }
    _28221 = NOVALUE;

    /** parser.e:750					exit*/
    goto L4; // [125] 133

    /** parser.e:752			end while*/
    goto L3; // [130] 54
L4: 

    /** parser.e:753			short_circuit += 1*/
    _45short_circuit_54924 = _45short_circuit_54924 + 1;
L2: 

    /** parser.e:755		putback(tok)*/
    Ref(_tok_55963);
    _45putback(_tok_55963);

    /** parser.e:756		return n*/
    DeRef(_tok_55963);
    DeRef(_28218);
    _28218 = NOVALUE;
    return _n_55964;
    ;
}


void _45tok_match(object _tok_55992, object _prevtok_55993)
{
    object _t_55995 = NOVALUE;
    object _expected_55996 = NOVALUE;
    object _actual_55997 = NOVALUE;
    object _prevname_55998 = NOVALUE;
    object _28233 = NOVALUE;
    object _28231 = NOVALUE;
    object _28228 = NOVALUE;
    object _28225 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:762		sequence expected, actual, prevname*/

    /** parser.e:764		t = next_token()*/
    _0 = _t_55995;
    _t_55995 = _45next_token();
    DeRef(_0);

    /** parser.e:765		if t[T_ID] != tok then*/
    _2 = (object)SEQ_PTR(_t_55995);
    _28225 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _28225, _tok_55992)){
        _28225 = NOVALUE;
        goto L1; // [20] 96
    }
    _28225 = NOVALUE;

    /** parser.e:766			expected = LexName(tok)*/
    RefDS(_26329);
    _0 = _expected_55996;
    _expected_55996 = _47LexName(_tok_55992, _26329);
    DeRef(_0);

    /** parser.e:767			actual = LexName(t[T_ID])*/
    _2 = (object)SEQ_PTR(_t_55995);
    _28228 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_28228);
    RefDS(_26329);
    _0 = _actual_55997;
    _actual_55997 = _47LexName(_28228, _26329);
    DeRef(_0);
    _28228 = NOVALUE;

    /** parser.e:768			if prevtok = 0 then*/
    if (_prevtok_55993 != 0LL)
    goto L2; // [50] 70

    /** parser.e:769				CompileErr(SYNTAX_ERROR__EXPECTED_TO_SEE_POSSIBLY_1_NOT_2, {expected, actual})*/
    RefDS(_actual_55997);
    RefDS(_expected_55996);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _expected_55996;
    ((intptr_t *)_2)[2] = _actual_55997;
    _28231 = MAKE_SEQ(_1);
    _50CompileErr(132LL, _28231, 0LL);
    _28231 = NOVALUE;
    goto L3; // [67] 95
L2: 

    /** parser.e:771				prevname = LexName(prevtok)*/
    RefDS(_26329);
    _0 = _prevname_55998;
    _prevname_55998 = _47LexName(_prevtok_55993, _26329);
    DeRef(_0);

    /** parser.e:772				CompileErr(SYNTAX_ERROR__EXPECTED_TO_SEE_1_AFTER_2_NOT_3, {expected, prevname, actual})*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_expected_55996);
    ((intptr_t*)_2)[1] = _expected_55996;
    RefDS(_prevname_55998);
    ((intptr_t*)_2)[2] = _prevname_55998;
    RefDS(_actual_55997);
    ((intptr_t*)_2)[3] = _actual_55997;
    _28233 = MAKE_SEQ(_1);
    _50CompileErr(138LL, _28233, 0LL);
    _28233 = NOVALUE;
L3: 
L1: 

    /** parser.e:775	end procedure*/
    DeRef(_t_55995);
    DeRef(_expected_55996);
    DeRef(_actual_55997);
    DeRef(_prevname_55998);
    return;
    ;
}


void _45UndefinedVar(object _s_56034)
{
    object _dup_56036 = NOVALUE;
    object _errmsg_56037 = NOVALUE;
    object _rname_56038 = NOVALUE;
    object _fname_56039 = NOVALUE;
    object _28256 = NOVALUE;
    object _28255 = NOVALUE;
    object _28253 = NOVALUE;
    object _28251 = NOVALUE;
    object _28250 = NOVALUE;
    object _28248 = NOVALUE;
    object _28246 = NOVALUE;
    object _28244 = NOVALUE;
    object _28243 = NOVALUE;
    object _28242 = NOVALUE;
    object _28241 = NOVALUE;
    object _28240 = NOVALUE;
    object _28238 = NOVALUE;
    object _28237 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_56034)) {
        _1 = (object)(DBL_PTR(_s_56034)->dbl);
        DeRefDS(_s_56034);
        _s_56034 = _1;
    }

    /** parser.e:790		sequence errmsg*/

    /** parser.e:791		sequence rname*/

    /** parser.e:792		sequence fname*/

    /** parser.e:794		if SymTab[s][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28237 = (object)*(((s1_ptr)_2)->base + _s_56034);
    _2 = (object)SEQ_PTR(_28237);
    _28238 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28237 = NOVALUE;
    if (binary_op_a(NOTEQ, _28238, 9LL)){
        _28238 = NOVALUE;
        goto L1; // [25] 57
    }
    _28238 = NOVALUE;

    /** parser.e:795			CompileErr(MSG_1_HAS_NOT_BEEN_DECLARED, {SymTab[s][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28240 = (object)*(((s1_ptr)_2)->base + _s_56034);
    _2 = (object)SEQ_PTR(_28240);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _28241 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _28241 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _28240 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_28241);
    ((intptr_t*)_2)[1] = _28241;
    _28242 = MAKE_SEQ(_1);
    _28241 = NOVALUE;
    _50CompileErr(19LL, _28242, 0LL);
    _28242 = NOVALUE;
    goto L2; // [54] 206
L1: 

    /** parser.e:797		elsif SymTab[s][S_SCOPE] = SC_MULTIPLY_DEFINED then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28243 = (object)*(((s1_ptr)_2)->base + _s_56034);
    _2 = (object)SEQ_PTR(_28243);
    _28244 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28243 = NOVALUE;
    if (binary_op_a(NOTEQ, _28244, 10LL)){
        _28244 = NOVALUE;
        goto L3; // [73] 183
    }
    _28244 = NOVALUE;

    /** parser.e:798			rname = SymTab[s][S_NAME]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28246 = (object)*(((s1_ptr)_2)->base + _s_56034);
    DeRef(_rname_56038);
    _2 = (object)SEQ_PTR(_28246);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _rname_56038 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _rname_56038 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    Ref(_rname_56038);
    _28246 = NOVALUE;

    /** parser.e:799			errmsg = ""*/
    RefDS(_21993);
    DeRef(_errmsg_56037);
    _errmsg_56037 = _21993;

    /** parser.e:801			for i = 1 to length(dup_globals) do*/
    if (IS_SEQUENCE(_54dup_globals_47963)){
            _28248 = SEQ_PTR(_54dup_globals_47963)->length;
    }
    else {
        _28248 = 1;
    }
    {
        object _i_56066;
        _i_56066 = 1LL;
L4: 
        if (_i_56066 > _28248){
            goto L5; // [107] 165
        }

        /** parser.e:802				dup = dup_globals[i]*/
        _2 = (object)SEQ_PTR(_54dup_globals_47963);
        _dup_56036 = (object)*(((s1_ptr)_2)->base + _i_56066);
        if (!IS_ATOM_INT(_dup_56036)){
            _dup_56036 = (object)DBL_PTR(_dup_56036)->dbl;
        }

        /** parser.e:803				fname = known_files[SymTab[dup][S_FILE_NO]]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _28250 = (object)*(((s1_ptr)_2)->base + _dup_56036);
        _2 = (object)SEQ_PTR(_28250);
        if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
            _28251 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
        }
        else{
            _28251 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
        }
        _28250 = NOVALUE;
        DeRef(_fname_56039);
        _2 = (object)SEQ_PTR(_37known_files_15407);
        if (!IS_ATOM_INT(_28251)){
            _fname_56039 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28251)->dbl));
        }
        else{
            _fname_56039 = (object)*(((s1_ptr)_2)->base + _28251);
        }
        Ref(_fname_56039);

        /** parser.e:804				errmsg &= "    " & fname & "\n"*/
        {
            object concat_list[3];

            concat_list[0] = _22188;
            concat_list[1] = _fname_56039;
            concat_list[2] = _24880;
            Concat_N((object_ptr)&_28253, concat_list, 3);
        }
        Concat((object_ptr)&_errmsg_56037, _errmsg_56037, _28253);
        DeRefDS(_28253);
        _28253 = NOVALUE;

        /** parser.e:806			end for*/
        _i_56066 = _i_56066 + 1LL;
        goto L4; // [160] 114
L5: 
        ;
    }

    /** parser.e:808			CompileErr(A_NAMESPACE_QUALIFIER_IS_NEEDED_TO_RESOLVE_1BECAUSE_2_IS_DECLARED_AS_A_GLOBALPUBLIC_SYMBOL_IN3, {rname, rname, errmsg})*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDSn(_rname_56038, 2);
    ((intptr_t*)_2)[1] = _rname_56038;
    ((intptr_t*)_2)[2] = _rname_56038;
    RefDS(_errmsg_56037);
    ((intptr_t*)_2)[3] = _errmsg_56037;
    _28255 = MAKE_SEQ(_1);
    _50CompileErr(23LL, _28255, 0LL);
    _28255 = NOVALUE;
    goto L2; // [180] 206
L3: 

    /** parser.e:810		elsif length(symbol_resolution_warning) then*/
    if (IS_SEQUENCE(_36symbol_resolution_warning_21544)){
            _28256 = SEQ_PTR(_36symbol_resolution_warning_21544)->length;
    }
    else {
        _28256 = 1;
    }
    if (_28256 == 0)
    {
        _28256 = NOVALUE;
        goto L6; // [190] 205
    }
    else{
        _28256 = NOVALUE;
    }

    /** parser.e:811			Warning( symbol_resolution_warning, resolution_warning_flag)*/
    RefDS(_36symbol_resolution_warning_21544);
    RefDS(_21993);
    _50Warning(_36symbol_resolution_warning_21544, 1LL, _21993);
L6: 
L2: 

    /** parser.e:813	end procedure*/
    DeRef(_errmsg_56037);
    DeRef(_rname_56038);
    DeRef(_fname_56039);
    _28251 = NOVALUE;
    return;
    ;
}


void _45WrongNumberArgs(object _subsym_56091, object _only_56092)
{
    object _msgno_56093 = NOVALUE;
    object _28268 = NOVALUE;
    object _28267 = NOVALUE;
    object _28266 = NOVALUE;
    object _28265 = NOVALUE;
    object _28264 = NOVALUE;
    object _28262 = NOVALUE;
    object _28260 = NOVALUE;
    object _28258 = NOVALUE;
    object _28257 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_subsym_56091)) {
        _1 = (object)(DBL_PTR(_subsym_56091)->dbl);
        DeRefDS(_subsym_56091);
        _subsym_56091 = _1;
    }

    /** parser.e:819		if SymTab[subsym][S_NUM_ARGS] = 1 then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28257 = (object)*(((s1_ptr)_2)->base + _subsym_56091);
    _2 = (object)SEQ_PTR(_28257);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
        _28258 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
    }
    else{
        _28258 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
    }
    _28257 = NOVALUE;
    if (binary_op_a(NOTEQ, _28258, 1LL)){
        _28258 = NOVALUE;
        goto L1; // [19] 49
    }
    _28258 = NOVALUE;

    /** parser.e:820			if length(only) = 0 then*/
    if (IS_SEQUENCE(_only_56092)){
            _28260 = SEQ_PTR(_only_56092)->length;
    }
    else {
        _28260 = 1;
    }
    if (_28260 != 0LL)
    goto L2; // [28] 40

    /** parser.e:821				msgno = 20*/
    _msgno_56093 = 20LL;
    goto L3; // [37] 73
L2: 

    /** parser.e:823				msgno = 237*/
    _msgno_56093 = 237LL;
    goto L3; // [46] 73
L1: 

    /** parser.e:826			if length(only) = 0 then*/
    if (IS_SEQUENCE(_only_56092)){
            _28262 = SEQ_PTR(_only_56092)->length;
    }
    else {
        _28262 = 1;
    }
    if (_28262 != 0LL)
    goto L4; // [54] 66

    /** parser.e:827				msgno = 236*/
    _msgno_56093 = 236LL;
    goto L5; // [63] 72
L4: 

    /** parser.e:829				msgno = 238*/
    _msgno_56093 = 238LL;
L5: 
L3: 

    /** parser.e:833		CompileErr(msgno, {SymTab[subsym][S_NAME], SymTab[subsym][S_NUM_ARGS]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28264 = (object)*(((s1_ptr)_2)->base + _subsym_56091);
    _2 = (object)SEQ_PTR(_28264);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _28265 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _28265 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _28264 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28266 = (object)*(((s1_ptr)_2)->base + _subsym_56091);
    _2 = (object)SEQ_PTR(_28266);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
        _28267 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
    }
    else{
        _28267 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
    }
    _28266 = NOVALUE;
    Ref(_28267);
    Ref(_28265);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28265;
    ((intptr_t *)_2)[2] = _28267;
    _28268 = MAKE_SEQ(_1);
    _28267 = NOVALUE;
    _28265 = NOVALUE;
    _50CompileErr(_msgno_56093, _28268, 0LL);
    _28268 = NOVALUE;

    /** parser.e:834	end procedure*/
    DeRefDSi(_only_56092);
    return;
    ;
}


void _45MissingArgs(object _subsym_56122)
{
    object _eentry_56123 = NOVALUE;
    object _28273 = NOVALUE;
    object _28272 = NOVALUE;
    object _28271 = NOVALUE;
    object _28270 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:837		sequence eentry = SymTab[subsym]*/
    DeRef(_eentry_56123);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _eentry_56123 = (object)*(((s1_ptr)_2)->base + _subsym_56122);
    Ref(_eentry_56123);

    /** parser.e:839		CompileErr(MSG_1_NEEDS_AT_LEAST_2_PARAMETERS_BUT_SOME_NONDEFAULTABLE_ARGUMENTS_ARE_MISSING, {eentry[S_NAME], eentry[S_DEF_ARGS][2]})*/
    _2 = (object)SEQ_PTR(_eentry_56123);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _28270 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _28270 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _2 = (object)SEQ_PTR(_eentry_56123);
    _28271 = (object)*(((s1_ptr)_2)->base + 28LL);
    _2 = (object)SEQ_PTR(_28271);
    _28272 = (object)*(((s1_ptr)_2)->base + 2LL);
    _28271 = NOVALUE;
    Ref(_28272);
    Ref(_28270);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28270;
    ((intptr_t *)_2)[2] = _28272;
    _28273 = MAKE_SEQ(_1);
    _28272 = NOVALUE;
    _28270 = NOVALUE;
    _50CompileErr(235LL, _28273, 0LL);
    _28273 = NOVALUE;

    /** parser.e:840	end procedure*/
    DeRefDS(_eentry_56123);
    return;
    ;
}


void _45Parse_default_arg(object _subsym_56137, object _arg_56138, object _fwd_private_list_56139, object _fwd_private_sym_56140)
{
    object _param_56142 = NOVALUE;
    object _28293 = NOVALUE;
    object _28292 = NOVALUE;
    object _28291 = NOVALUE;
    object _28290 = NOVALUE;
    object _28289 = NOVALUE;
    object _28288 = NOVALUE;
    object _28287 = NOVALUE;
    object _28286 = NOVALUE;
    object _28285 = NOVALUE;
    object _28284 = NOVALUE;
    object _28283 = NOVALUE;
    object _28282 = NOVALUE;
    object _28281 = NOVALUE;
    object _28279 = NOVALUE;
    object _28278 = NOVALUE;
    object _28275 = NOVALUE;
    object _28274 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:843		symtab_index param = subsym*/
    _param_56142 = _subsym_56137;

    /** parser.e:844		on_arg = arg*/
    _45on_arg_55670 = _arg_56138;

    /** parser.e:845		parseargs_states = append(parseargs_states,*/
    if (IS_SEQUENCE(_45private_list_55668)){
            _28274 = SEQ_PTR(_45private_list_55668)->length;
    }
    else {
        _28274 = 1;
    }
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _28274;
    ((intptr_t*)_2)[2] = _45lock_scanner_55669;
    ((intptr_t*)_2)[3] = _36use_private_list_21556;
    ((intptr_t*)_2)[4] = _45on_arg_55670;
    _28275 = MAKE_SEQ(_1);
    _28274 = NOVALUE;
    RefDS(_28275);
    Append(&_45parseargs_states_55663, _45parseargs_states_55663, _28275);
    DeRefDS(_28275);
    _28275 = NOVALUE;

    /** parser.e:847		nested_calls &= subsym*/
    Append(&_45nested_calls_55671, _45nested_calls_55671, _subsym_56137);

    /** parser.e:849		for i = 1 to arg do*/
    _28278 = _arg_56138;
    {
        object _i_56149;
        _i_56149 = 1LL;
L1: 
        if (_i_56149 > _28278){
            goto L2; // [60] 90
        }

        /** parser.e:850			param = SymTab[param][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _28279 = (object)*(((s1_ptr)_2)->base + _param_56142);
        _2 = (object)SEQ_PTR(_28279);
        _param_56142 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_param_56142)){
            _param_56142 = (object)DBL_PTR(_param_56142)->dbl;
        }
        _28279 = NOVALUE;

        /** parser.e:851		end for*/
        _i_56149 = _i_56149 + 1LL;
        goto L1; // [85] 67
L2: 
        ;
    }

    /** parser.e:853		private_list = fwd_private_list*/
    RefDS(_fwd_private_list_56139);
    DeRef(_45private_list_55668);
    _45private_list_55668 = _fwd_private_list_56139;

    /** parser.e:854		private_sym  = fwd_private_sym*/
    RefDS(_fwd_private_sym_56140);
    DeRef(_36private_sym_21555);
    _36private_sym_21555 = _fwd_private_sym_56140;

    /** parser.e:856		if atom(SymTab[param][S_CODE]) then  -- but no default set*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28281 = (object)*(((s1_ptr)_2)->base + _param_56142);
    _2 = (object)SEQ_PTR(_28281);
    if (!IS_ATOM_INT(_36S_CODE_21088)){
        _28282 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
    }
    else{
        _28282 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21088);
    }
    _28281 = NOVALUE;
    _28283 = IS_ATOM(_28282);
    _28282 = NOVALUE;
    if (_28283 == 0)
    {
        _28283 = NOVALUE;
        goto L3; // [121] 164
    }
    else{
        _28283 = NOVALUE;
    }

    /** parser.e:857			CompileErr(ARGUMENT_1_OF_2_3_WAS_OMITTED_BUT_THERE_IS_NO_DEFAULT_VALUE_DEFINED, {arg, SymTab[subsym][S_NAME], SymTab[param][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28284 = (object)*(((s1_ptr)_2)->base + _subsym_56137);
    _2 = (object)SEQ_PTR(_28284);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _28285 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _28285 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _28284 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28286 = (object)*(((s1_ptr)_2)->base + _param_56142);
    _2 = (object)SEQ_PTR(_28286);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _28287 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _28287 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _28286 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _arg_56138;
    Ref(_28285);
    ((intptr_t*)_2)[2] = _28285;
    Ref(_28287);
    ((intptr_t*)_2)[3] = _28287;
    _28288 = MAKE_SEQ(_1);
    _28287 = NOVALUE;
    _28285 = NOVALUE;
    _50CompileErr(26LL, _28288, 0LL);
    _28288 = NOVALUE;
L3: 

    /** parser.e:860		use_private_list = 1*/
    _36use_private_list_21556 = 1LL;

    /** parser.e:861		lock_scanner = 1*/
    _45lock_scanner_55669 = 1LL;

    /** parser.e:862		start_playback(SymTab[param][S_CODE] )*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28289 = (object)*(((s1_ptr)_2)->base + _param_56142);
    _2 = (object)SEQ_PTR(_28289);
    if (!IS_ATOM_INT(_36S_CODE_21088)){
        _28290 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
    }
    else{
        _28290 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21088);
    }
    _28289 = NOVALUE;
    Ref(_28290);
    _45start_playback(_28290);
    _28290 = NOVALUE;

    /** parser.e:863		call_proc(forward_expr, {})*/
    _0 = (object)_00[_45forward_expr_55959].addr;
    (*(intptr_t (*)())_0)(
                         );

    /** parser.e:865		add_private_symbol( Top(), SymTab[param][S_NAME] )*/
    _28291 = _47Top();
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28292 = (object)*(((s1_ptr)_2)->base + _param_56142);
    _2 = (object)SEQ_PTR(_28292);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _28293 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _28293 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _28292 = NOVALUE;
    Ref(_28293);
    _44add_private_symbol(_28291, _28293);
    _28291 = NOVALUE;
    _28293 = NOVALUE;

    /** parser.e:866		lock_scanner = 0*/
    _45lock_scanner_55669 = 0LL;

    /** parser.e:867		restore_parseargs_states()*/
    _45restore_parseargs_states();

    /** parser.e:868	end procedure*/
    DeRefDS(_fwd_private_list_56139);
    DeRefDSi(_fwd_private_sym_56140);
    return;
    ;
}


void _45ParseArgs(object _subsym_56188)
{
    object _n_56189 = NOVALUE;
    object _fda_56190 = NOVALUE;
    object _lnda_56191 = NOVALUE;
    object _tok_56193 = NOVALUE;
    object _s_56195 = NOVALUE;
    object _var_code_56196 = NOVALUE;
    object _name_56197 = NOVALUE;
    object _28403 = NOVALUE;
    object _28401 = NOVALUE;
    object _28397 = NOVALUE;
    object _28396 = NOVALUE;
    object _28395 = NOVALUE;
    object _28392 = NOVALUE;
    object _28389 = NOVALUE;
    object _28387 = NOVALUE;
    object _28385 = NOVALUE;
    object _28383 = NOVALUE;
    object _28381 = NOVALUE;
    object _28380 = NOVALUE;
    object _28379 = NOVALUE;
    object _28378 = NOVALUE;
    object _28377 = NOVALUE;
    object _28376 = NOVALUE;
    object _28375 = NOVALUE;
    object _28369 = NOVALUE;
    object _28368 = NOVALUE;
    object _28367 = NOVALUE;
    object _28366 = NOVALUE;
    object _28365 = NOVALUE;
    object _28364 = NOVALUE;
    object _28361 = NOVALUE;
    object _28358 = NOVALUE;
    object _28353 = NOVALUE;
    object _28351 = NOVALUE;
    object _28350 = NOVALUE;
    object _28349 = NOVALUE;
    object _28347 = NOVALUE;
    object _28344 = NOVALUE;
    object _28341 = NOVALUE;
    object _28339 = NOVALUE;
    object _28337 = NOVALUE;
    object _28335 = NOVALUE;
    object _28333 = NOVALUE;
    object _28332 = NOVALUE;
    object _28331 = NOVALUE;
    object _28330 = NOVALUE;
    object _28329 = NOVALUE;
    object _28328 = NOVALUE;
    object _28327 = NOVALUE;
    object _28325 = NOVALUE;
    object _28324 = NOVALUE;
    object _28323 = NOVALUE;
    object _28322 = NOVALUE;
    object _28321 = NOVALUE;
    object _28320 = NOVALUE;
    object _28317 = NOVALUE;
    object _28316 = NOVALUE;
    object _28315 = NOVALUE;
    object _28313 = NOVALUE;
    object _28312 = NOVALUE;
    object _28310 = NOVALUE;
    object _28306 = NOVALUE;
    object _28305 = NOVALUE;
    object _28303 = NOVALUE;
    object _28302 = NOVALUE;
    object _28300 = NOVALUE;
    object _28299 = NOVALUE;
    object _28298 = NOVALUE;
    object _28297 = NOVALUE;
    object _28296 = NOVALUE;
    object _28294 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_subsym_56188)) {
        _1 = (object)(DBL_PTR(_subsym_56188)->dbl);
        DeRefDS(_subsym_56188);
        _subsym_56188 = _1;
    }

    /** parser.e:875		object var_code*/

    /** parser.e:876		sequence name*/

    /** parser.e:878		n = SymTab[subsym][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28294 = (object)*(((s1_ptr)_2)->base + _subsym_56188);
    _2 = (object)SEQ_PTR(_28294);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
        _n_56189 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
    }
    else{
        _n_56189 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
    }
    if (!IS_ATOM_INT(_n_56189)){
        _n_56189 = (object)DBL_PTR(_n_56189)->dbl;
    }
    _28294 = NOVALUE;

    /** parser.e:879		if sequence(SymTab[subsym][S_DEF_ARGS]) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28296 = (object)*(((s1_ptr)_2)->base + _subsym_56188);
    _2 = (object)SEQ_PTR(_28296);
    _28297 = (object)*(((s1_ptr)_2)->base + 28LL);
    _28296 = NOVALUE;
    _28298 = IS_SEQUENCE(_28297);
    _28297 = NOVALUE;
    if (_28298 == 0)
    {
        _28298 = NOVALUE;
        goto L1; // [40] 86
    }
    else{
        _28298 = NOVALUE;
    }

    /** parser.e:880			fda = SymTab[subsym][S_DEF_ARGS][1]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28299 = (object)*(((s1_ptr)_2)->base + _subsym_56188);
    _2 = (object)SEQ_PTR(_28299);
    _28300 = (object)*(((s1_ptr)_2)->base + 28LL);
    _28299 = NOVALUE;
    _2 = (object)SEQ_PTR(_28300);
    _fda_56190 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_fda_56190)){
        _fda_56190 = (object)DBL_PTR(_fda_56190)->dbl;
    }
    _28300 = NOVALUE;

    /** parser.e:881			lnda = SymTab[subsym][S_DEF_ARGS][2]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28302 = (object)*(((s1_ptr)_2)->base + _subsym_56188);
    _2 = (object)SEQ_PTR(_28302);
    _28303 = (object)*(((s1_ptr)_2)->base + 28LL);
    _28302 = NOVALUE;
    _2 = (object)SEQ_PTR(_28303);
    _lnda_56191 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_lnda_56191)){
        _lnda_56191 = (object)DBL_PTR(_lnda_56191)->dbl;
    }
    _28303 = NOVALUE;
    goto L2; // [83] 97
L1: 

    /** parser.e:883			fda = 0*/
    _fda_56190 = 0LL;

    /** parser.e:884			lnda = 0*/
    _lnda_56191 = 0LL;
L2: 

    /** parser.e:886		s = subsym*/
    _s_56195 = _subsym_56188;

    /** parser.e:888		parseargs_states = append(parseargs_states,*/
    if (IS_SEQUENCE(_45private_list_55668)){
            _28305 = SEQ_PTR(_45private_list_55668)->length;
    }
    else {
        _28305 = 1;
    }
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _28305;
    ((intptr_t*)_2)[2] = _45lock_scanner_55669;
    ((intptr_t*)_2)[3] = _36use_private_list_21556;
    ((intptr_t*)_2)[4] = _45on_arg_55670;
    _28306 = MAKE_SEQ(_1);
    _28305 = NOVALUE;
    RefDS(_28306);
    Append(&_45parseargs_states_55663, _45parseargs_states_55663, _28306);
    DeRefDS(_28306);
    _28306 = NOVALUE;

    /** parser.e:890		nested_calls &= subsym*/
    Append(&_45nested_calls_55671, _45nested_calls_55671, _subsym_56188);

    /** parser.e:891		lock_scanner = 0*/
    _45lock_scanner_55669 = 0LL;

    /** parser.e:892		on_arg = 0*/
    _45on_arg_55670 = 0LL;

    /** parser.e:894		short_circuit -= 1*/
    _45short_circuit_54924 = _45short_circuit_54924 - 1LL;

    /** parser.e:895		for i = 1 to n do*/
    _28310 = _n_56189;
    {
        object _i_56226;
        _i_56226 = 1LL;
L3: 
        if (_i_56226 > _28310){
            goto L4; // [161] 1050
        }

        /** parser.e:897		  	tok = next_token()*/
        _0 = _tok_56193;
        _tok_56193 = _45next_token();
        DeRef(_0);

        /** parser.e:899			if tok[T_ID] = QUESTION_MARK or tok[T_ID] = COMMA then*/
        _2 = (object)SEQ_PTR(_tok_56193);
        _28312 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_28312)) {
            _28313 = (_28312 == -31LL);
        }
        else {
            _28313 = binary_op(EQUALS, _28312, -31LL);
        }
        _28312 = NOVALUE;
        if (IS_ATOM_INT(_28313)) {
            if (_28313 != 0) {
                goto L5; // [187] 208
            }
        }
        else {
            if (DBL_PTR(_28313)->dbl != 0.0) {
                goto L5; // [187] 208
            }
        }
        _2 = (object)SEQ_PTR(_tok_56193);
        _28315 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_28315)) {
            _28316 = (_28315 == -30LL);
        }
        else {
            _28316 = binary_op(EQUALS, _28315, -30LL);
        }
        _28315 = NOVALUE;
        if (_28316 == 0) {
            DeRef(_28316);
            _28316 = NOVALUE;
            goto L6; // [204] 505
        }
        else {
            if (!IS_ATOM_INT(_28316) && DBL_PTR(_28316)->dbl == 0.0){
                DeRef(_28316);
                _28316 = NOVALUE;
                goto L6; // [204] 505
            }
            DeRef(_28316);
            _28316 = NOVALUE;
        }
        DeRef(_28316);
        _28316 = NOVALUE;
L5: 

        /** parser.e:902				if tok[T_ID] = QUESTION_MARK then*/
        _2 = (object)SEQ_PTR(_tok_56193);
        _28317 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _28317, -31LL)){
            _28317 = NOVALUE;
            goto L7; // [218] 297
        }
        _28317 = NOVALUE;

        /** parser.e:903					tok = next_token()*/
        _0 = _tok_56193;
        _tok_56193 = _45next_token();
        DeRef(_0);

        /** parser.e:904					if tok[T_ID] != RIGHT_ROUND and tok[T_ID] != COMMA then*/
        _2 = (object)SEQ_PTR(_tok_56193);
        _28320 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_28320)) {
            _28321 = (_28320 != -27LL);
        }
        else {
            _28321 = binary_op(NOTEQ, _28320, -27LL);
        }
        _28320 = NOVALUE;
        if (IS_ATOM_INT(_28321)) {
            if (_28321 == 0) {
                goto L8; // [241] 273
            }
        }
        else {
            if (DBL_PTR(_28321)->dbl == 0.0) {
                goto L8; // [241] 273
            }
        }
        _2 = (object)SEQ_PTR(_tok_56193);
        _28323 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_28323)) {
            _28324 = (_28323 != -30LL);
        }
        else {
            _28324 = binary_op(NOTEQ, _28323, -30LL);
        }
        _28323 = NOVALUE;
        if (_28324 == 0) {
            DeRef(_28324);
            _28324 = NOVALUE;
            goto L8; // [258] 273
        }
        else {
            if (!IS_ATOM_INT(_28324) && DBL_PTR(_28324)->dbl == 0.0){
                DeRef(_28324);
                _28324 = NOVALUE;
                goto L8; // [258] 273
            }
            DeRef(_28324);
            _28324 = NOVALUE;
        }
        DeRef(_28324);
        _28324 = NOVALUE;

        /** parser.e:905						CompileErr( BADLYFORMED_LIST_OF_PARAMETERS__EXPECTED__OR)*/
        RefDS(_21993);
        _50CompileErr(41LL, _21993, 0LL);
        goto L9; // [270] 298
L8: 

        /** parser.e:906					elsif tok[T_ID] = RIGHT_ROUND then*/
        _2 = (object)SEQ_PTR(_tok_56193);
        _28325 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _28325, -27LL)){
            _28325 = NOVALUE;
            goto L9; // [283] 298
        }
        _28325 = NOVALUE;

        /** parser.e:907						putback( tok )*/
        Ref(_tok_56193);
        _45putback(_tok_56193);
        goto L9; // [294] 298
L7: 
L9: 

        /** parser.e:912				if SymTab[subsym][S_OPCODE] then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _28327 = (object)*(((s1_ptr)_2)->base + _subsym_56188);
        _2 = (object)SEQ_PTR(_28327);
        _28328 = (object)*(((s1_ptr)_2)->base + 21LL);
        _28327 = NOVALUE;
        if (_28328 == 0) {
            _28328 = NOVALUE;
            goto LA; // [312] 372
        }
        else {
            if (!IS_ATOM_INT(_28328) && DBL_PTR(_28328)->dbl == 0.0){
                _28328 = NOVALUE;
                goto LA; // [312] 372
            }
            _28328 = NOVALUE;
        }
        _28328 = NOVALUE;

        /** parser.e:913					if atom(SymTab[subsym][S_CODE]) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _28329 = (object)*(((s1_ptr)_2)->base + _subsym_56188);
        _2 = (object)SEQ_PTR(_28329);
        if (!IS_ATOM_INT(_36S_CODE_21088)){
            _28330 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
        }
        else{
            _28330 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21088);
        }
        _28329 = NOVALUE;
        _28331 = IS_ATOM(_28330);
        _28330 = NOVALUE;
        if (_28331 == 0)
        {
            _28331 = NOVALUE;
            goto LB; // [332] 343
        }
        else{
            _28331 = NOVALUE;
        }

        /** parser.e:914						var_code = 0*/
        DeRef(_var_code_56196);
        _var_code_56196 = 0LL;
        goto LC; // [340] 362
LB: 

        /** parser.e:916						var_code = SymTab[subsym][S_CODE][i]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _28332 = (object)*(((s1_ptr)_2)->base + _subsym_56188);
        _2 = (object)SEQ_PTR(_28332);
        if (!IS_ATOM_INT(_36S_CODE_21088)){
            _28333 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
        }
        else{
            _28333 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21088);
        }
        _28332 = NOVALUE;
        DeRef(_var_code_56196);
        _2 = (object)SEQ_PTR(_28333);
        _var_code_56196 = (object)*(((s1_ptr)_2)->base + _i_56226);
        Ref(_var_code_56196);
        _28333 = NOVALUE;
LC: 

        /** parser.e:918					name = ""*/
        RefDS(_21993);
        DeRef(_name_56197);
        _name_56197 = _21993;
        goto LD; // [369] 419
LA: 

        /** parser.e:920					s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _28335 = (object)*(((s1_ptr)_2)->base + _s_56195);
        _2 = (object)SEQ_PTR(_28335);
        _s_56195 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_s_56195)){
            _s_56195 = (object)DBL_PTR(_s_56195)->dbl;
        }
        _28335 = NOVALUE;

        /** parser.e:921					var_code = SymTab[s][S_CODE]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _28337 = (object)*(((s1_ptr)_2)->base + _s_56195);
        DeRef(_var_code_56196);
        _2 = (object)SEQ_PTR(_28337);
        if (!IS_ATOM_INT(_36S_CODE_21088)){
            _var_code_56196 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
        }
        else{
            _var_code_56196 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21088);
        }
        Ref(_var_code_56196);
        _28337 = NOVALUE;

        /** parser.e:922					name = SymTab[s][S_NAME]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _28339 = (object)*(((s1_ptr)_2)->base + _s_56195);
        DeRef(_name_56197);
        _2 = (object)SEQ_PTR(_28339);
        if (!IS_ATOM_INT(_36S_NAME_21076)){
            _name_56197 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
        }
        else{
            _name_56197 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
        }
        Ref(_name_56197);
        _28339 = NOVALUE;
LD: 

        /** parser.e:925				if atom(var_code) then  -- but no default set*/
        _28341 = IS_ATOM(_var_code_56196);
        if (_28341 == 0)
        {
            _28341 = NOVALUE;
            goto LE; // [426] 439
        }
        else{
            _28341 = NOVALUE;
        }

        /** parser.e:926					CompileErr(ARGUMENT_1_WAS_OMITTED_BUT_THERE_IS_NO_DEFAULT_VALUE_DEFINED,i)*/
        _50CompileErr(29LL, _i_56226, 0LL);
LE: 

        /** parser.e:929				use_private_list = 1*/
        _36use_private_list_21556 = 1LL;

        /** parser.e:930				start_playback(var_code)*/
        Ref(_var_code_56196);
        _45start_playback(_var_code_56196);

        /** parser.e:931				lock_scanner=1*/
        _45lock_scanner_55669 = 1LL;

        /** parser.e:934				Expr()*/
        _45Expr();

        /** parser.e:935				lock_scanner=0*/
        _45lock_scanner_55669 = 0LL;

        /** parser.e:936				on_arg += 1*/
        _45on_arg_55670 = _45on_arg_55670 + 1;

        /** parser.e:937				private_list = append(private_list,name)*/
        RefDS(_name_56197);
        Append(&_45private_list_55668, _45private_list_55668, _name_56197);

        /** parser.e:938				private_sym &= Top()*/
        _28344 = _47Top();
        if (IS_SEQUENCE(_36private_sym_21555) && IS_ATOM(_28344)) {
            Ref(_28344);
            Append(&_36private_sym_21555, _36private_sym_21555, _28344);
        }
        else if (IS_ATOM(_36private_sym_21555) && IS_SEQUENCE(_28344)) {
        }
        else {
            Concat((object_ptr)&_36private_sym_21555, _36private_sym_21555, _28344);
        }
        DeRef(_28344);
        _28344 = NOVALUE;

        /** parser.e:939				backed_up_tok = {tok} -- ????*/
        _0 = _45backed_up_tok_54931;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_tok_56193);
        ((intptr_t*)_2)[1] = _tok_56193;
        _45backed_up_tok_54931 = MAKE_SEQ(_1);
        DeRef(_0);
        goto LF; // [502] 633
L6: 

        /** parser.e:942			elsif tok[T_ID] != RIGHT_ROUND then*/
        _2 = (object)SEQ_PTR(_tok_56193);
        _28347 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(EQUALS, _28347, -27LL)){
            _28347 = NOVALUE;
            goto L10; // [515] 632
        }
        _28347 = NOVALUE;

        /** parser.e:944				if SymTab[subsym][S_OPCODE] then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _28349 = (object)*(((s1_ptr)_2)->base + _subsym_56188);
        _2 = (object)SEQ_PTR(_28349);
        _28350 = (object)*(((s1_ptr)_2)->base + 21LL);
        _28349 = NOVALUE;
        if (_28350 == 0) {
            _28350 = NOVALUE;
            goto L11; // [533] 546
        }
        else {
            if (!IS_ATOM_INT(_28350) && DBL_PTR(_28350)->dbl == 0.0){
                _28350 = NOVALUE;
                goto L11; // [533] 546
            }
            _28350 = NOVALUE;
        }
        _28350 = NOVALUE;

        /** parser.e:945					name = ""*/
        RefDS(_21993);
        DeRef(_name_56197);
        _name_56197 = _21993;
        goto L12; // [543] 579
L11: 

        /** parser.e:947					s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _28351 = (object)*(((s1_ptr)_2)->base + _s_56195);
        _2 = (object)SEQ_PTR(_28351);
        _s_56195 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_s_56195)){
            _s_56195 = (object)DBL_PTR(_s_56195)->dbl;
        }
        _28351 = NOVALUE;

        /** parser.e:948					name = SymTab[s][S_NAME]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _28353 = (object)*(((s1_ptr)_2)->base + _s_56195);
        DeRef(_name_56197);
        _2 = (object)SEQ_PTR(_28353);
        if (!IS_ATOM_INT(_36S_NAME_21076)){
            _name_56197 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
        }
        else{
            _name_56197 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
        }
        Ref(_name_56197);
        _28353 = NOVALUE;
L12: 

        /** parser.e:951				use_private_list = Parser_mode != PAM_NORMAL*/
        _36use_private_list_21556 = (_36Parser_mode_21548 != 0LL);

        /** parser.e:952				putback(tok)*/
        Ref(_tok_56193);
        _45putback(_tok_56193);

        /** parser.e:953				Expr()*/
        _45Expr();

        /** parser.e:954				on_arg += 1*/
        _45on_arg_55670 = _45on_arg_55670 + 1;

        /** parser.e:955				private_list = append(private_list,name)*/
        RefDS(_name_56197);
        Append(&_45private_list_55668, _45private_list_55668, _name_56197);

        /** parser.e:956				private_sym &= Top()*/
        _28358 = _47Top();
        if (IS_SEQUENCE(_36private_sym_21555) && IS_ATOM(_28358)) {
            Ref(_28358);
            Append(&_36private_sym_21555, _36private_sym_21555, _28358);
        }
        else if (IS_ATOM(_36private_sym_21555) && IS_SEQUENCE(_28358)) {
        }
        else {
            Concat((object_ptr)&_36private_sym_21555, _36private_sym_21555, _28358);
        }
        DeRef(_28358);
        _28358 = NOVALUE;
L10: 
LF: 

        /** parser.e:959			if on_arg != n then*/
        if (_45on_arg_55670 == _n_56189)
        goto L13; // [637] 1043

        /** parser.e:960				if tok[T_ID] = RIGHT_ROUND then*/
        _2 = (object)SEQ_PTR(_tok_56193);
        _28361 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _28361, -27LL)){
            _28361 = NOVALUE;
            goto L14; // [651] 661
        }
        _28361 = NOVALUE;

        /** parser.e:961					putback( tok )*/
        Ref(_tok_56193);
        _45putback(_tok_56193);
L14: 

        /** parser.e:963				tok = next_token()*/
        _0 = _tok_56193;
        _tok_56193 = _45next_token();
        DeRef(_0);

        /** parser.e:964				if tok[T_ID] != COMMA and tok[T_ID] != QUESTION_MARK then*/
        _2 = (object)SEQ_PTR(_tok_56193);
        _28364 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_28364)) {
            _28365 = (_28364 != -30LL);
        }
        else {
            _28365 = binary_op(NOTEQ, _28364, -30LL);
        }
        _28364 = NOVALUE;
        if (IS_ATOM_INT(_28365)) {
            if (_28365 == 0) {
                goto L15; // [680] 1042
            }
        }
        else {
            if (DBL_PTR(_28365)->dbl == 0.0) {
                goto L15; // [680] 1042
            }
        }
        _2 = (object)SEQ_PTR(_tok_56193);
        _28367 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_28367)) {
            _28368 = (_28367 != -31LL);
        }
        else {
            _28368 = binary_op(NOTEQ, _28367, -31LL);
        }
        _28367 = NOVALUE;
        if (_28368 == 0) {
            DeRef(_28368);
            _28368 = NOVALUE;
            goto L15; // [697] 1042
        }
        else {
            if (!IS_ATOM_INT(_28368) && DBL_PTR(_28368)->dbl == 0.0){
                DeRef(_28368);
                _28368 = NOVALUE;
                goto L15; // [697] 1042
            }
            DeRef(_28368);
            _28368 = NOVALUE;
        }
        DeRef(_28368);
        _28368 = NOVALUE;

        /** parser.e:966			  		if tok[T_ID] = RIGHT_ROUND then*/
        _2 = (object)SEQ_PTR(_tok_56193);
        _28369 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _28369, -27LL)){
            _28369 = NOVALUE;
            goto L16; // [710] 1027
        }
        _28369 = NOVALUE;

        /** parser.e:968						if fda=0 then*/
        if (_fda_56190 != 0LL)
        goto L17; // [718] 731

        /** parser.e:969							WrongNumberArgs(subsym, "")*/
        RefDS(_21993);
        _45WrongNumberArgs(_subsym_56188, _21993);
        goto L18; // [728] 746
L17: 

        /** parser.e:970						elsif i<lnda then*/
        if (_i_56226 >= _lnda_56191)
        goto L19; // [735] 745

        /** parser.e:971							MissingArgs(subsym)*/
        _45MissingArgs(_subsym_56188);
L19: 
L18: 

        /** parser.e:973						lock_scanner = 1*/
        _45lock_scanner_55669 = 1LL;

        /** parser.e:974						use_private_list = 1*/
        _36use_private_list_21556 = 1LL;

        /** parser.e:977						while on_arg < n do*/
L1A: 
        if (_45on_arg_55670 >= _n_56189)
        goto L1B; // [765] 976

        /** parser.e:978							on_arg += 1*/
        _45on_arg_55670 = _45on_arg_55670 + 1;

        /** parser.e:979							if SymTab[subsym][S_OPCODE] then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _28375 = (object)*(((s1_ptr)_2)->base + _subsym_56188);
        _2 = (object)SEQ_PTR(_28375);
        _28376 = (object)*(((s1_ptr)_2)->base + 21LL);
        _28375 = NOVALUE;
        if (_28376 == 0) {
            _28376 = NOVALUE;
            goto L1C; // [791] 853
        }
        else {
            if (!IS_ATOM_INT(_28376) && DBL_PTR(_28376)->dbl == 0.0){
                _28376 = NOVALUE;
                goto L1C; // [791] 853
            }
            _28376 = NOVALUE;
        }
        _28376 = NOVALUE;

        /** parser.e:980								if atom(SymTab[subsym][S_CODE]) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _28377 = (object)*(((s1_ptr)_2)->base + _subsym_56188);
        _2 = (object)SEQ_PTR(_28377);
        if (!IS_ATOM_INT(_36S_CODE_21088)){
            _28378 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
        }
        else{
            _28378 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21088);
        }
        _28377 = NOVALUE;
        _28379 = IS_ATOM(_28378);
        _28378 = NOVALUE;
        if (_28379 == 0)
        {
            _28379 = NOVALUE;
            goto L1D; // [811] 822
        }
        else{
            _28379 = NOVALUE;
        }

        /** parser.e:981									var_code = 0*/
        DeRef(_var_code_56196);
        _var_code_56196 = 0LL;
        goto L1E; // [819] 843
L1D: 

        /** parser.e:983									var_code = SymTab[subsym][S_CODE][on_arg]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _28380 = (object)*(((s1_ptr)_2)->base + _subsym_56188);
        _2 = (object)SEQ_PTR(_28380);
        if (!IS_ATOM_INT(_36S_CODE_21088)){
            _28381 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
        }
        else{
            _28381 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21088);
        }
        _28380 = NOVALUE;
        DeRef(_var_code_56196);
        _2 = (object)SEQ_PTR(_28381);
        _var_code_56196 = (object)*(((s1_ptr)_2)->base + _45on_arg_55670);
        Ref(_var_code_56196);
        _28381 = NOVALUE;
L1E: 

        /** parser.e:986								name = ""*/
        RefDS(_21993);
        DeRef(_name_56197);
        _name_56197 = _21993;
        goto L1F; // [850] 900
L1C: 

        /** parser.e:989								s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _28383 = (object)*(((s1_ptr)_2)->base + _s_56195);
        _2 = (object)SEQ_PTR(_28383);
        _s_56195 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_s_56195)){
            _s_56195 = (object)DBL_PTR(_s_56195)->dbl;
        }
        _28383 = NOVALUE;

        /** parser.e:990								var_code = SymTab[s][S_CODE]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _28385 = (object)*(((s1_ptr)_2)->base + _s_56195);
        DeRef(_var_code_56196);
        _2 = (object)SEQ_PTR(_28385);
        if (!IS_ATOM_INT(_36S_CODE_21088)){
            _var_code_56196 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
        }
        else{
            _var_code_56196 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21088);
        }
        Ref(_var_code_56196);
        _28385 = NOVALUE;

        /** parser.e:991								name = SymTab[s][S_NAME]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _28387 = (object)*(((s1_ptr)_2)->base + _s_56195);
        DeRef(_name_56197);
        _2 = (object)SEQ_PTR(_28387);
        if (!IS_ATOM_INT(_36S_NAME_21076)){
            _name_56197 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
        }
        else{
            _name_56197 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
        }
        Ref(_name_56197);
        _28387 = NOVALUE;
L1F: 

        /** parser.e:993							if sequence(var_code) then*/
        _28389 = IS_SEQUENCE(_var_code_56196);
        if (_28389 == 0)
        {
            _28389 = NOVALUE;
            goto L20; // [907] 959
        }
        else{
            _28389 = NOVALUE;
        }

        /** parser.e:995								putback( tok )*/
        Ref(_tok_56193);
        _45putback(_tok_56193);

        /** parser.e:996								start_playback(var_code)*/
        Ref(_var_code_56196);
        _45start_playback(_var_code_56196);

        /** parser.e:999								Expr()*/
        _45Expr();

        /** parser.e:1000								if on_arg < n then*/
        if (_45on_arg_55670 >= _n_56189)
        goto L1A; // [928] 763

        /** parser.e:1001									private_list = append(private_list,name)*/
        RefDS(_name_56197);
        Append(&_45private_list_55668, _45private_list_55668, _name_56197);

        /** parser.e:1002									private_sym &= Top()*/
        _28392 = _47Top();
        if (IS_SEQUENCE(_36private_sym_21555) && IS_ATOM(_28392)) {
            Ref(_28392);
            Append(&_36private_sym_21555, _36private_sym_21555, _28392);
        }
        else if (IS_ATOM(_36private_sym_21555) && IS_SEQUENCE(_28392)) {
        }
        else {
            Concat((object_ptr)&_36private_sym_21555, _36private_sym_21555, _28392);
        }
        DeRef(_28392);
        _28392 = NOVALUE;
        goto L1A; // [956] 763
L20: 

        /** parser.e:1005								CompileErr(ARGUMENT_1_WAS_OMITTED_BUT_THERE_IS_NO_DEFAULT_VALUE_DEFINED, on_arg)*/
        _50CompileErr(29LL, _45on_arg_55670, 0LL);

        /** parser.e:1007			  		    end while*/
        goto L1A; // [973] 763
L1B: 

        /** parser.e:1009						short_circuit += 1*/
        _45short_circuit_54924 = _45short_circuit_54924 + 1;

        /** parser.e:1010						if backed_up_tok[$][T_ID] = PLAYBACK_ENDS then*/
        if (IS_SEQUENCE(_45backed_up_tok_54931)){
                _28395 = SEQ_PTR(_45backed_up_tok_54931)->length;
        }
        else {
            _28395 = 1;
        }
        _2 = (object)SEQ_PTR(_45backed_up_tok_54931);
        _28396 = (object)*(((s1_ptr)_2)->base + _28395);
        _2 = (object)SEQ_PTR(_28396);
        _28397 = (object)*(((s1_ptr)_2)->base + 1LL);
        _28396 = NOVALUE;
        if (binary_op_a(NOTEQ, _28397, 505LL)){
            _28397 = NOVALUE;
            goto L21; // [1003] 1015
        }
        _28397 = NOVALUE;

        /** parser.e:1011							backed_up_tok = {}*/
        RefDS(_21993);
        DeRefDS(_45backed_up_tok_54931);
        _45backed_up_tok_54931 = _21993;
L21: 

        /** parser.e:1014						restore_parseargs_states()*/
        _45restore_parseargs_states();

        /** parser.e:1016						return*/
        DeRef(_tok_56193);
        DeRef(_var_code_56196);
        DeRef(_name_56197);
        DeRef(_28321);
        _28321 = NOVALUE;
        DeRef(_28313);
        _28313 = NOVALUE;
        DeRef(_28365);
        _28365 = NOVALUE;
        return;
        goto L22; // [1024] 1041
L16: 

        /** parser.e:1018						putback(tok)*/
        Ref(_tok_56193);
        _45putback(_tok_56193);

        /** parser.e:1019						tok_match(COMMA)*/
        _45tok_match(-30LL, 0LL);
L22: 
L15: 
L13: 

        /** parser.e:1024		end for*/
        _i_56226 = _i_56226 + 1LL;
        goto L3; // [1045] 168
L4: 
        ;
    }

    /** parser.e:1025		tok = next_token()*/
    _0 = _tok_56193;
    _tok_56193 = _45next_token();
    DeRef(_0);

    /** parser.e:1026		short_circuit += 1*/
    _45short_circuit_54924 = _45short_circuit_54924 + 1;

    /** parser.e:1027		if tok[T_ID] != RIGHT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok_56193);
    _28401 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _28401, -27LL)){
        _28401 = NOVALUE;
        goto L23; // [1073] 1115
    }
    _28401 = NOVALUE;

    /** parser.e:1028			if tok[T_ID] = COMMA then*/
    _2 = (object)SEQ_PTR(_tok_56193);
    _28403 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28403, -30LL)){
        _28403 = NOVALUE;
        goto L24; // [1087] 1100
    }
    _28403 = NOVALUE;

    /** parser.e:1029				WrongNumberArgs(subsym, "only ")*/
    RefDS(_28405);
    _45WrongNumberArgs(_subsym_56188, _28405);
    goto L25; // [1097] 1114
L24: 

    /** parser.e:1031				putback(tok)*/
    Ref(_tok_56193);
    _45putback(_tok_56193);

    /** parser.e:1032				tok_match(RIGHT_ROUND)*/
    _45tok_match(-27LL, 0LL);
L25: 
L23: 

    /** parser.e:1036		restore_parseargs_states()*/
    _45restore_parseargs_states();

    /** parser.e:1037	end procedure*/
    DeRef(_tok_56193);
    DeRef(_var_code_56196);
    DeRef(_name_56197);
    DeRef(_28321);
    _28321 = NOVALUE;
    DeRef(_28313);
    _28313 = NOVALUE;
    DeRef(_28365);
    _28365 = NOVALUE;
    return;
    ;
}


void _45Forward_var(object _tok_56438, object _init_check_56439, object _op_56440)
{
    object _ref_56444 = NOVALUE;
    object _28409 = NOVALUE;
    object _28407 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_op_56440)) {
        _1 = (object)(DBL_PTR(_op_56440)->dbl);
        DeRefDS(_op_56440);
        _op_56440 = _1;
    }

    /** parser.e:1041		ref = new_forward_reference( VARIABLE, tok[T_SYM], op )*/
    _2 = (object)SEQ_PTR(_tok_56438);
    _28407 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_28407);
    _ref_56444 = _44new_forward_reference(-100LL, _28407, _op_56440);
    _28407 = NOVALUE;
    if (!IS_ATOM_INT(_ref_56444)) {
        _1 = (object)(DBL_PTR(_ref_56444)->dbl);
        DeRefDS(_ref_56444);
        _ref_56444 = _1;
    }

    /** parser.e:1042		emit_opnd( - ref )*/
    if ((uintptr_t)_ref_56444 == (uintptr_t)HIGH_BITS){
        _28409 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _28409 = - _ref_56444;
    }
    _47emit_opnd(_28409);
    _28409 = NOVALUE;

    /** parser.e:1043		if init_check != -1 then*/
    if (_init_check_56439 == -1LL)
    goto L1; // [33] 44

    /** parser.e:1044			Forward_InitCheck( tok, init_check )*/
    Ref(_tok_56438);
    _45Forward_InitCheck(_tok_56438, _init_check_56439);
L1: 

    /** parser.e:1047	end procedure*/
    DeRef(_tok_56438);
    return;
    ;
}


void _45Forward_call(object _tok_56457, object _opcode_56458)
{
    object _args_56461 = NOVALUE;
    object _proc_56463 = NOVALUE;
    object _tok_id_56466 = NOVALUE;
    object _id_56473 = NOVALUE;
    object _fc_pc_56497 = NOVALUE;
    object _28428 = NOVALUE;
    object _28427 = NOVALUE;
    object _28424 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1050		integer args = 0*/
    _args_56461 = 0LL;

    /** parser.e:1051		symtab_index proc = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_56457);
    _proc_56463 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_proc_56463)){
        _proc_56463 = (object)DBL_PTR(_proc_56463)->dbl;
    }

    /** parser.e:1052		integer tok_id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_56457);
    _tok_id_56466 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_tok_id_56466)){
        _tok_id_56466 = (object)DBL_PTR(_tok_id_56466)->dbl;
    }

    /** parser.e:1053		remove_symbol( proc )*/
    _54remove_symbol(_proc_56463);

    /** parser.e:1054		short_circuit -= 1*/
    _45short_circuit_54924 = _45short_circuit_54924 - 1LL;

    /** parser.e:1055		while 1 do*/
L1: 

    /** parser.e:1056			tok = next_token()*/
    _0 = _tok_56457;
    _tok_56457 = _45next_token();
    DeRef(_0);

    /** parser.e:1057			integer id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_56457);
    _id_56473 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_56473)){
        _id_56473 = (object)DBL_PTR(_id_56473)->dbl;
    }

    /** parser.e:1059			switch id do*/
    _0 = _id_56473;
    switch ( _0 ){ 

        /** parser.e:1060				case COMMA then*/
        case -30:

        /** parser.e:1061					emit_opnd( 0 ) -- clean this up later*/
        _47emit_opnd(0LL);

        /** parser.e:1062					args += 1*/
        _args_56461 = _args_56461 + 1;
        goto L2; // [83] 168

        /** parser.e:1064				case RIGHT_ROUND then*/
        case -27:

        /** parser.e:1065					exit*/
        goto L3; // [93] 175
        goto L2; // [95] 168

        /** parser.e:1067				case else*/
        default:

        /** parser.e:1068					putback( tok )*/
        Ref(_tok_56457);
        _45putback(_tok_56457);

        /** parser.e:1069					call_proc( forward_expr, {} )*/
        _0 = (object)_00[_45forward_expr_55959].addr;
        (*(intptr_t (*)())_0)(
                             );

        /** parser.e:1070					args += 1*/
        _args_56461 = _args_56461 + 1;

        /** parser.e:1072					tok = next_token()*/
        _0 = _tok_56457;
        _tok_56457 = _45next_token();
        DeRef(_0);

        /** parser.e:1073					id = tok[T_ID]*/
        _2 = (object)SEQ_PTR(_tok_56457);
        _id_56473 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (!IS_ATOM_INT(_id_56473)){
            _id_56473 = (object)DBL_PTR(_id_56473)->dbl;
        }

        /** parser.e:1074					if id = RIGHT_ROUND then*/
        if (_id_56473 != -27LL)
        goto L4; // [138] 149

        /** parser.e:1075						exit*/
        goto L3; // [146] 175
L4: 

        /** parser.e:1078					if id != COMMA then*/
        if (_id_56473 == -30LL)
        goto L5; // [153] 167

        /** parser.e:1079							CompileErr(EXPECTED__OR)*/
        RefDS(_21993);
        _50CompileErr(69LL, _21993, 0LL);
L5: 
    ;}L2: 

    /** parser.e:1082		end while*/
    goto L1; // [172] 46
L3: 

    /** parser.e:1084		integer fc_pc = length( Code ) + 1*/
    if (IS_SEQUENCE(_36Code_21531)){
            _28424 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _28424 = 1;
    }
    _fc_pc_56497 = _28424 + 1;
    _28424 = NOVALUE;

    /** parser.e:1085		emit_opnd( args )*/
    _47emit_opnd(_args_56461);

    /** parser.e:1087		op_info1 = proc*/
    _47op_info1_50932 = _proc_56463;

    /** parser.e:1088		if tok_id = QUALIFIED_VARIABLE then*/
    if (_tok_id_56466 != 512LL)
    goto L6; // [202] 226

    /** parser.e:1089			set_qualified_fwd( SymTab[proc][S_FILE_NO] )*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28427 = (object)*(((s1_ptr)_2)->base + _proc_56463);
    _2 = (object)SEQ_PTR(_28427);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _28428 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _28428 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    _28427 = NOVALUE;
    Ref(_28428);
    _62set_qualified_fwd(_28428);
    _28428 = NOVALUE;
    goto L7; // [223] 232
L6: 

    /** parser.e:1091			set_qualified_fwd( -1 )*/
    _62set_qualified_fwd(-1LL);
L7: 

    /** parser.e:1093		emit_op( opcode )*/
    _47emit_op(_opcode_56458);

    /** parser.e:1094		if not TRANSLATE then*/
    if (_36TRANSLATE_21041 != 0)
    goto L8; // [241] 260

    /** parser.e:1095			if OpTrace then*/
    if (_36OpTrace_21512 == 0)
    {
        goto L9; // [248] 259
    }
    else{
    }

    /** parser.e:1096				emit_op(UPDATE_GLOBALS)*/
    _47emit_op(89LL);
L9: 
L8: 

    /** parser.e:1099		short_circuit += 1*/
    _45short_circuit_54924 = _45short_circuit_54924 + 1;

    /** parser.e:1100	end procedure*/
    DeRef(_tok_56457);
    return;
    ;
}


void _45Object_call(object _tok_56525)
{
    object _tok2_56527 = NOVALUE;
    object _tok3_56528 = NOVALUE;
    object _save_factors_56529 = NOVALUE;
    object _save_lhs_subs_level_56530 = NOVALUE;
    object _sym_56532 = NOVALUE;
    object _28486 = NOVALUE;
    object _28484 = NOVALUE;
    object _28481 = NOVALUE;
    object _28477 = NOVALUE;
    object _28471 = NOVALUE;
    object _28468 = NOVALUE;
    object _28467 = NOVALUE;
    object _28466 = NOVALUE;
    object _28464 = NOVALUE;
    object _28463 = NOVALUE;
    object _28461 = NOVALUE;
    object _28460 = NOVALUE;
    object _28457 = NOVALUE;
    object _28456 = NOVALUE;
    object _28455 = NOVALUE;
    object _28453 = NOVALUE;
    object _28452 = NOVALUE;
    object _28450 = NOVALUE;
    object _28449 = NOVALUE;
    object _28448 = NOVALUE;
    object _28447 = NOVALUE;
    object _28445 = NOVALUE;
    object _28444 = NOVALUE;
    object _28442 = NOVALUE;
    object _28441 = NOVALUE;
    object _28438 = NOVALUE;
    object _28436 = NOVALUE;
    object _28435 = NOVALUE;
    object _28433 = NOVALUE;
    object _28432 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:1104		integer save_factors, save_lhs_subs_level*/

    /** parser.e:1107		tok2 = next_token()*/
    _0 = _tok2_56527;
    _tok2_56527 = _45next_token();
    DeRef(_0);

    /** parser.e:1108		if tok2[T_ID] = VARIABLE or tok2[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok2_56527);
    _28432 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28432)) {
        _28433 = (_28432 == -100LL);
    }
    else {
        _28433 = binary_op(EQUALS, _28432, -100LL);
    }
    _28432 = NOVALUE;
    if (IS_ATOM_INT(_28433)) {
        if (_28433 != 0) {
            goto L1; // [22] 43
        }
    }
    else {
        if (DBL_PTR(_28433)->dbl != 0.0) {
            goto L1; // [22] 43
        }
    }
    _2 = (object)SEQ_PTR(_tok2_56527);
    _28435 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28435)) {
        _28436 = (_28435 == 512LL);
    }
    else {
        _28436 = binary_op(EQUALS, _28435, 512LL);
    }
    _28435 = NOVALUE;
    if (_28436 == 0) {
        DeRef(_28436);
        _28436 = NOVALUE;
        goto L2; // [39] 582
    }
    else {
        if (!IS_ATOM_INT(_28436) && DBL_PTR(_28436)->dbl == 0.0){
            DeRef(_28436);
            _28436 = NOVALUE;
            goto L2; // [39] 582
        }
        DeRef(_28436);
        _28436 = NOVALUE;
    }
    DeRef(_28436);
    _28436 = NOVALUE;
L1: 

    /** parser.e:1109			tok3 = next_token()*/
    _0 = _tok3_56528;
    _tok3_56528 = _45next_token();
    DeRef(_0);

    /** parser.e:1110			if tok3[T_ID] = RIGHT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok3_56528);
    _28438 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28438, -27LL)){
        _28438 = NOVALUE;
        goto L3; // [58] 155
    }
    _28438 = NOVALUE;

    /** parser.e:1112				sym = tok2[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok2_56527);
    _sym_56532 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_sym_56532)){
        _sym_56532 = (object)DBL_PTR(_sym_56532)->dbl;
    }

    /** parser.e:1113				if SymTab[sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28441 = (object)*(((s1_ptr)_2)->base + _sym_56532);
    _2 = (object)SEQ_PTR(_28441);
    _28442 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28441 = NOVALUE;
    if (binary_op_a(NOTEQ, _28442, 9LL)){
        _28442 = NOVALUE;
        goto L4; // [88] 108
    }
    _28442 = NOVALUE;

    /** parser.e:1114					Forward_var( tok2 )*/
    _2 = (object)SEQ_PTR(_tok2_56527);
    _28444 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_tok2_56527);
    Ref(_28444);
    _45Forward_var(_tok2_56527, -1LL, _28444);
    _28444 = NOVALUE;
    goto L5; // [105] 147
L4: 

    /** parser.e:1116					SymTab[sym][S_USAGE] = or_bits(SymTab[sym][S_USAGE], U_READ)*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_56532 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28447 = (object)*(((s1_ptr)_2)->base + _sym_56532);
    _2 = (object)SEQ_PTR(_28447);
    _28448 = (object)*(((s1_ptr)_2)->base + 5LL);
    _28447 = NOVALUE;
    if (IS_ATOM_INT(_28448)) {
        {uintptr_t tu;
             tu = (uintptr_t)_28448 | (uintptr_t)1LL;
             _28449 = MAKE_UINT(tu);
        }
    }
    else {
        _28449 = binary_op(OR_BITS, _28448, 1LL);
    }
    _28448 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _28449;
    if( _1 != _28449 ){
        DeRef(_1);
    }
    _28449 = NOVALUE;
    _28445 = NOVALUE;

    /** parser.e:1118					emit_opnd(sym)*/
    _47emit_opnd(_sym_56532);
L5: 

    /** parser.e:1120				putback( tok3 )*/
    Ref(_tok3_56528);
    _45putback(_tok3_56528);
    goto L6; // [152] 571
L3: 

    /** parser.e:1122			elsif tok3[T_ID] = COMMA then*/
    _2 = (object)SEQ_PTR(_tok3_56528);
    _28450 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28450, -30LL)){
        _28450 = NOVALUE;
        goto L7; // [165] 184
    }
    _28450 = NOVALUE;

    /** parser.e:1124				WrongNumberArgs(tok[T_SYM], "")*/
    _2 = (object)SEQ_PTR(_tok_56525);
    _28452 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_28452);
    RefDS(_21993);
    _45WrongNumberArgs(_28452, _21993);
    _28452 = NOVALUE;
    goto L6; // [181] 571
L7: 

    /** parser.e:1126			elsif tok3[T_ID] = LEFT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok3_56528);
    _28453 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28453, -26LL)){
        _28453 = NOVALUE;
        goto L8; // [194] 244
    }
    _28453 = NOVALUE;

    /** parser.e:1127				if SymTab[tok2[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_tok2_56527);
    _28455 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_28455)){
        _28456 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28455)->dbl));
    }
    else{
        _28456 = (object)*(((s1_ptr)_2)->base + _28455);
    }
    _2 = (object)SEQ_PTR(_28456);
    _28457 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28456 = NOVALUE;
    if (binary_op_a(NOTEQ, _28457, 9LL)){
        _28457 = NOVALUE;
        goto L9; // [220] 235
    }
    _28457 = NOVALUE;

    /** parser.e:1128					Forward_call( tok2, FUNC_FORWARD )*/
    Ref(_tok2_56527);
    _45Forward_call(_tok2_56527, 196LL);
    goto L6; // [232] 571
L9: 

    /** parser.e:1130					Function_call( tok2 )*/
    Ref(_tok2_56527);
    _45Function_call(_tok2_56527);
    goto L6; // [241] 571
L8: 

    /** parser.e:1139				sym = tok2[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok2_56527);
    _sym_56532 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_sym_56532)){
        _sym_56532 = (object)DBL_PTR(_sym_56532)->dbl;
    }

    /** parser.e:1140				if SymTab[sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28460 = (object)*(((s1_ptr)_2)->base + _sym_56532);
    _2 = (object)SEQ_PTR(_28460);
    _28461 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28460 = NOVALUE;
    if (binary_op_a(NOTEQ, _28461, 9LL)){
        _28461 = NOVALUE;
        goto LA; // [270] 292
    }
    _28461 = NOVALUE;

    /** parser.e:1141					Forward_var( tok2, TRUE )*/
    _2 = (object)SEQ_PTR(_tok2_56527);
    _28463 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_tok2_56527);
    Ref(_28463);
    _45Forward_var(_tok2_56527, _13TRUE_452, _28463);
    _28463 = NOVALUE;
    goto LB; // [289] 339
LA: 

    /** parser.e:1143					SymTab[sym][S_USAGE] = or_bits(SymTab[sym][S_USAGE], U_READ)*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_56532 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28466 = (object)*(((s1_ptr)_2)->base + _sym_56532);
    _2 = (object)SEQ_PTR(_28466);
    _28467 = (object)*(((s1_ptr)_2)->base + 5LL);
    _28466 = NOVALUE;
    if (IS_ATOM_INT(_28467)) {
        {uintptr_t tu;
             tu = (uintptr_t)_28467 | (uintptr_t)1LL;
             _28468 = MAKE_UINT(tu);
        }
    }
    else {
        _28468 = binary_op(OR_BITS, _28467, 1LL);
    }
    _28467 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _28468;
    if( _1 != _28468 ){
        DeRef(_1);
    }
    _28468 = NOVALUE;
    _28464 = NOVALUE;

    /** parser.e:1144					InitCheck(sym, TRUE)*/
    _45InitCheck(_sym_56532, _13TRUE_452);

    /** parser.e:1145					emit_opnd(sym)*/
    _47emit_opnd(_sym_56532);
LB: 

    /** parser.e:1149				if sym = left_sym then*/
    if (_sym_56532 != _45left_sym_54965)
    goto LC; // [343] 353

    /** parser.e:1150					lhs_subs_level = 0*/
    _45lhs_subs_level_54963 = 0LL;
LC: 

    /** parser.e:1155				tok2 = tok3*/
    Ref(_tok3_56528);
    DeRef(_tok2_56527);
    _tok2_56527 = _tok3_56528;

    /** parser.e:1156				current_sequence = append(current_sequence, sym)*/
    Append(&_47current_sequence_50940, _47current_sequence_50940, _sym_56532);

    /** parser.e:1157				while tok2[T_ID] = LEFT_SQUARE do*/
LD: 
    _2 = (object)SEQ_PTR(_tok2_56527);
    _28471 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28471, -28LL)){
        _28471 = NOVALUE;
        goto LE; // [381] 549
    }
    _28471 = NOVALUE;

    /** parser.e:1158					subs_depth += 1*/
    _45subs_depth_54966 = _45subs_depth_54966 + 1;

    /** parser.e:1159					if lhs_subs_level >= 0 then*/
    if (_45lhs_subs_level_54963 < 0LL)
    goto LF; // [397] 410

    /** parser.e:1160						lhs_subs_level += 1*/
    _45lhs_subs_level_54963 = _45lhs_subs_level_54963 + 1;
LF: 

    /** parser.e:1162					save_factors = factors*/
    _save_factors_56529 = _45factors_54962;

    /** parser.e:1163					save_lhs_subs_level = lhs_subs_level*/
    _save_lhs_subs_level_56530 = _45lhs_subs_level_54963;

    /** parser.e:1164					call_proc(forward_expr, {})*/
    _0 = (object)_00[_45forward_expr_55959].addr;
    (*(intptr_t (*)())_0)(
                         );

    /** parser.e:1165					tok2 = next_token()*/
    _0 = _tok2_56527;
    _tok2_56527 = _45next_token();
    DeRef(_0);

    /** parser.e:1166					if tok2[T_ID] = SLICE then*/
    _2 = (object)SEQ_PTR(_tok2_56527);
    _28477 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28477, 513LL)){
        _28477 = NOVALUE;
        goto L10; // [446] 484
    }
    _28477 = NOVALUE;

    /** parser.e:1167						call_proc(forward_expr, {})*/
    _0 = (object)_00[_45forward_expr_55959].addr;
    (*(intptr_t (*)())_0)(
                         );

    /** parser.e:1168						emit_op(RHS_SLICE)*/
    _47emit_op(46LL);

    /** parser.e:1169						tok_match(RIGHT_SQUARE)*/
    _45tok_match(-29LL, 0LL);

    /** parser.e:1170						tok2 = next_token()*/
    _0 = _tok2_56527;
    _tok2_56527 = _45next_token();
    DeRef(_0);

    /** parser.e:1171						exit*/
    goto LE; // [479] 549
    goto L11; // [481] 529
L10: 

    /** parser.e:1173						putback(tok2)*/
    Ref(_tok2_56527);
    _45putback(_tok2_56527);

    /** parser.e:1174						tok_match(RIGHT_SQUARE)*/
    _45tok_match(-29LL, 0LL);

    /** parser.e:1175						subs_depth -= 1*/
    _45subs_depth_54966 = _45subs_depth_54966 - 1LL;

    /** parser.e:1176						current_sequence = remove( current_sequence, length( current_sequence ) )*/
    if (IS_SEQUENCE(_47current_sequence_50940)){
            _28481 = SEQ_PTR(_47current_sequence_50940)->length;
    }
    else {
        _28481 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_47current_sequence_50940);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_28481)) ? _28481 : (object)(DBL_PTR(_28481)->dbl);
        int stop = (IS_ATOM_INT(_28481)) ? _28481 : (object)(DBL_PTR(_28481)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_47current_sequence_50940), start, &_47current_sequence_50940 );
            }
            else Tail(SEQ_PTR(_47current_sequence_50940), stop+1, &_47current_sequence_50940);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_47current_sequence_50940), start, &_47current_sequence_50940);
        }
        else {
            assign_slice_seq = &assign_space;
            _47current_sequence_50940 = Remove_elements(start, stop, (SEQ_PTR(_47current_sequence_50940)->ref == 1));
        }
    }
    _28481 = NOVALUE;
    _28481 = NOVALUE;

    /** parser.e:1177						emit_op(RHS_SUBS)*/
    _47emit_op(25LL);
L11: 

    /** parser.e:1180					factors = save_factors*/
    _45factors_54962 = _save_factors_56529;

    /** parser.e:1181					lhs_subs_level = save_lhs_subs_level*/
    _45lhs_subs_level_54963 = _save_lhs_subs_level_56530;

    /** parser.e:1182					tok2 = next_token()*/
    _0 = _tok2_56527;
    _tok2_56527 = _45next_token();
    DeRef(_0);

    /** parser.e:1183				end while*/
    goto LD; // [546] 373
LE: 

    /** parser.e:1184				current_sequence = remove( current_sequence, length( current_sequence ) )*/
    if (IS_SEQUENCE(_47current_sequence_50940)){
            _28484 = SEQ_PTR(_47current_sequence_50940)->length;
    }
    else {
        _28484 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_47current_sequence_50940);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_28484)) ? _28484 : (object)(DBL_PTR(_28484)->dbl);
        int stop = (IS_ATOM_INT(_28484)) ? _28484 : (object)(DBL_PTR(_28484)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_47current_sequence_50940), start, &_47current_sequence_50940 );
            }
            else Tail(SEQ_PTR(_47current_sequence_50940), stop+1, &_47current_sequence_50940);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_47current_sequence_50940), start, &_47current_sequence_50940);
        }
        else {
            assign_slice_seq = &assign_space;
            _47current_sequence_50940 = Remove_elements(start, stop, (SEQ_PTR(_47current_sequence_50940)->ref == 1));
        }
    }
    _28484 = NOVALUE;
    _28484 = NOVALUE;

    /** parser.e:1185				putback(tok2)*/
    Ref(_tok2_56527);
    _45putback(_tok2_56527);
L6: 

    /** parser.e:1189			tok_match( RIGHT_ROUND )*/
    _45tok_match(-27LL, 0LL);
    goto L12; // [579] 599
L2: 

    /** parser.e:1191			putback(tok2)*/
    Ref(_tok2_56527);
    _45putback(_tok2_56527);

    /** parser.e:1192			ParseArgs(tok[T_SYM])*/
    _2 = (object)SEQ_PTR(_tok_56525);
    _28486 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_28486);
    _45ParseArgs(_28486);
    _28486 = NOVALUE;
L12: 

    /** parser.e:1194	end procedure*/
    DeRef(_tok_56525);
    DeRef(_tok2_56527);
    DeRef(_tok3_56528);
    _28455 = NOVALUE;
    DeRef(_28433);
    _28433 = NOVALUE;
    return;
    ;
}


void _45Function_call(object _tok_56670)
{
    object _id_56671 = NOVALUE;
    object _scope_56672 = NOVALUE;
    object _opcode_56673 = NOVALUE;
    object _e_56674 = NOVALUE;
    object _28527 = NOVALUE;
    object _28526 = NOVALUE;
    object _28525 = NOVALUE;
    object _28524 = NOVALUE;
    object _28523 = NOVALUE;
    object _28522 = NOVALUE;
    object _28521 = NOVALUE;
    object _28519 = NOVALUE;
    object _28518 = NOVALUE;
    object _28516 = NOVALUE;
    object _28515 = NOVALUE;
    object _28514 = NOVALUE;
    object _28513 = NOVALUE;
    object _28512 = NOVALUE;
    object _28511 = NOVALUE;
    object _28510 = NOVALUE;
    object _28509 = NOVALUE;
    object _28508 = NOVALUE;
    object _28507 = NOVALUE;
    object _28506 = NOVALUE;
    object _28505 = NOVALUE;
    object _28504 = NOVALUE;
    object _28503 = NOVALUE;
    object _28502 = NOVALUE;
    object _28500 = NOVALUE;
    object _28498 = NOVALUE;
    object _28497 = NOVALUE;
    object _28495 = NOVALUE;
    object _28493 = NOVALUE;
    object _28492 = NOVALUE;
    object _28491 = NOVALUE;
    object _28490 = NOVALUE;
    object _28488 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:1200		id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_56670);
    _id_56671 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_56671)){
        _id_56671 = (object)DBL_PTR(_id_56671)->dbl;
    }

    /** parser.e:1201		if id = FUNC or id = TYPE then*/
    _28488 = (_id_56671 == 501LL);
    if (_28488 != 0) {
        goto L1; // [19] 34
    }
    _28490 = (_id_56671 == 504LL);
    if (_28490 == 0)
    {
        DeRef(_28490);
        _28490 = NOVALUE;
        goto L2; // [30] 46
    }
    else{
        DeRef(_28490);
        _28490 = NOVALUE;
    }
L1: 

    /** parser.e:1203			UndefinedVar( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_56670);
    _28491 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_28491);
    _45UndefinedVar(_28491);
    _28491 = NOVALUE;
L2: 

    /** parser.e:1206		e = SymTab[tok[T_SYM]][S_EFFECT]*/
    _2 = (object)SEQ_PTR(_tok_56670);
    _28492 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_28492)){
        _28493 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28492)->dbl));
    }
    else{
        _28493 = (object)*(((s1_ptr)_2)->base + _28492);
    }
    _2 = (object)SEQ_PTR(_28493);
    _e_56674 = (object)*(((s1_ptr)_2)->base + 23LL);
    if (!IS_ATOM_INT(_e_56674)){
        _e_56674 = (object)DBL_PTR(_e_56674)->dbl;
    }
    _28493 = NOVALUE;

    /** parser.e:1207		if e then*/
    if (_e_56674 == 0)
    {
        goto L3; // [70] 229
    }
    else{
    }

    /** parser.e:1209			if e = E_ALL_EFFECT or tok[T_SYM] > left_sym then*/
    _28495 = (_e_56674 == 1073741823LL);
    if (_28495 != 0) {
        goto L4; // [81] 102
    }
    _2 = (object)SEQ_PTR(_tok_56670);
    _28497 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_28497)) {
        _28498 = (_28497 > _45left_sym_54965);
    }
    else {
        _28498 = binary_op(GREATER, _28497, _45left_sym_54965);
    }
    _28497 = NOVALUE;
    if (_28498 == 0) {
        DeRef(_28498);
        _28498 = NOVALUE;
        goto L5; // [98] 111
    }
    else {
        if (!IS_ATOM_INT(_28498) && DBL_PTR(_28498)->dbl == 0.0){
            DeRef(_28498);
            _28498 = NOVALUE;
            goto L5; // [98] 111
        }
        DeRef(_28498);
        _28498 = NOVALUE;
    }
    DeRef(_28498);
    _28498 = NOVALUE;
L4: 

    /** parser.e:1211				side_effect_calls = or_bits(side_effect_calls, e)*/
    {uintptr_t tu;
         tu = (uintptr_t)_45side_effect_calls_54961 | (uintptr_t)_e_56674;
         _45side_effect_calls_54961 = MAKE_UINT(tu);
    }
L5: 

    /** parser.e:1214			SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT], e)*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21447 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28502 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21447);
    _2 = (object)SEQ_PTR(_28502);
    _28503 = (object)*(((s1_ptr)_2)->base + 23LL);
    _28502 = NOVALUE;
    if (IS_ATOM_INT(_28503)) {
        {uintptr_t tu;
             tu = (uintptr_t)_28503 | (uintptr_t)_e_56674;
             _28504 = MAKE_UINT(tu);
        }
    }
    else {
        _28504 = binary_op(OR_BITS, _28503, _e_56674);
    }
    _28503 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _28504;
    if( _1 != _28504 ){
        DeRef(_1);
    }
    _28504 = NOVALUE;
    _28500 = NOVALUE;

    /** parser.e:1216			if short_circuit > 0 and short_circuit_B and*/
    _28505 = (_45short_circuit_54924 > 0LL);
    if (_28505 == 0) {
        _28506 = 0;
        goto L6; // [154] 164
    }
    _28506 = (_45short_circuit_B_54926 != 0);
L6: 
    if (_28506 == 0) {
        goto L7; // [164] 228
    }
    _28508 = find_from(_id_56671, _38FUNC_TOKS_16057, 1LL);
    if (_28508 == 0)
    {
        _28508 = NOVALUE;
        goto L7; // [176] 228
    }
    else{
        _28508 = NOVALUE;
    }

    /** parser.e:1218				Warning(219, short_circuit_warning_flag,*/
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _28509 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
    Ref(_28509);
    RefDS(_21993);
    _28510 = _17abbreviate_path(_28509, _21993);
    _28509 = NOVALUE;
    _2 = (object)SEQ_PTR(_tok_56670);
    _28511 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_28511)){
        _28512 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28511)->dbl));
    }
    else{
        _28512 = (object)*(((s1_ptr)_2)->base + _28511);
    }
    _2 = (object)SEQ_PTR(_28512);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _28513 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _28513 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _28512 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _28510;
    ((intptr_t*)_2)[2] = _36line_number_21440;
    Ref(_28513);
    ((intptr_t*)_2)[3] = _28513;
    _28514 = MAKE_SEQ(_1);
    _28513 = NOVALUE;
    _28510 = NOVALUE;
    _50Warning(219LL, 2LL, _28514);
    _28514 = NOVALUE;
L7: 
L3: 

    /** parser.e:1222		tok_match(LEFT_ROUND)*/
    _45tok_match(-26LL, 0LL);

    /** parser.e:1223		scope = SymTab[tok[T_SYM]][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_tok_56670);
    _28515 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_28515)){
        _28516 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28515)->dbl));
    }
    else{
        _28516 = (object)*(((s1_ptr)_2)->base + _28515);
    }
    _2 = (object)SEQ_PTR(_28516);
    _scope_56672 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_scope_56672)){
        _scope_56672 = (object)DBL_PTR(_scope_56672)->dbl;
    }
    _28516 = NOVALUE;

    /** parser.e:1224		opcode = SymTab[tok[T_SYM]][S_OPCODE]*/
    _2 = (object)SEQ_PTR(_tok_56670);
    _28518 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_28518)){
        _28519 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28518)->dbl));
    }
    else{
        _28519 = (object)*(((s1_ptr)_2)->base + _28518);
    }
    _2 = (object)SEQ_PTR(_28519);
    _opcode_56673 = (object)*(((s1_ptr)_2)->base + 21LL);
    if (!IS_ATOM_INT(_opcode_56673)){
        _opcode_56673 = (object)DBL_PTR(_opcode_56673)->dbl;
    }
    _28519 = NOVALUE;

    /** parser.e:1225		if equal(SymTab[tok[T_SYM]][S_NAME],"object") and scope = SC_PREDEF then*/
    _2 = (object)SEQ_PTR(_tok_56670);
    _28521 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_28521)){
        _28522 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28521)->dbl));
    }
    else{
        _28522 = (object)*(((s1_ptr)_2)->base + _28521);
    }
    _2 = (object)SEQ_PTR(_28522);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _28523 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _28523 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _28522 = NOVALUE;
    if (_28523 == _22955)
    _28524 = 1;
    else if (IS_ATOM_INT(_28523) && IS_ATOM_INT(_22955))
    _28524 = 0;
    else
    _28524 = (compare(_28523, _22955) == 0);
    _28523 = NOVALUE;
    if (_28524 == 0) {
        goto L8; // [305] 327
    }
    _28526 = (_scope_56672 == 7LL);
    if (_28526 == 0)
    {
        DeRef(_28526);
        _28526 = NOVALUE;
        goto L8; // [316] 327
    }
    else{
        DeRef(_28526);
        _28526 = NOVALUE;
    }

    /** parser.e:1227			Object_call( tok )*/
    Ref(_tok_56670);
    _45Object_call(_tok_56670);
    goto L9; // [324] 339
L8: 

    /** parser.e:1230			ParseArgs(tok[T_SYM])*/
    _2 = (object)SEQ_PTR(_tok_56670);
    _28527 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_28527);
    _45ParseArgs(_28527);
    _28527 = NOVALUE;
L9: 

    /** parser.e:1233		if scope = SC_PREDEF then*/
    if (_scope_56672 != 7LL)
    goto LA; // [343] 355

    /** parser.e:1234			emit_op(opcode)*/
    _47emit_op(_opcode_56673);
    goto LB; // [352] 393
LA: 

    /** parser.e:1236			op_info1 = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_56670);
    _47op_info1_50932 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_47op_info1_50932)){
        _47op_info1_50932 = (object)DBL_PTR(_47op_info1_50932)->dbl;
    }

    /** parser.e:1238			emit_or_inline()*/
    _67emit_or_inline();

    /** parser.e:1239			if not TRANSLATE then*/
    if (_36TRANSLATE_21041 != 0)
    goto LC; // [373] 392

    /** parser.e:1240				if OpTrace then*/
    if (_36OpTrace_21512 == 0)
    {
        goto LD; // [380] 391
    }
    else{
    }

    /** parser.e:1241					emit_op(UPDATE_GLOBALS)*/
    _47emit_op(89LL);
LD: 
LC: 
LB: 

    /** parser.e:1245	end procedure*/
    DeRef(_tok_56670);
    _28518 = NOVALUE;
    DeRef(_28495);
    _28495 = NOVALUE;
    _28511 = NOVALUE;
    _28492 = NOVALUE;
    _28521 = NOVALUE;
    _28515 = NOVALUE;
    DeRef(_28488);
    _28488 = NOVALUE;
    DeRef(_28505);
    _28505 = NOVALUE;
    return;
    ;
}


void _45Factor()
{
    object _tok_56778 = NOVALUE;
    object _id_56779 = NOVALUE;
    object _n_56780 = NOVALUE;
    object _save_factors_56781 = NOVALUE;
    object _save_lhs_subs_level_56782 = NOVALUE;
    object _sym_56784 = NOVALUE;
    object _forward_56815 = NOVALUE;
    object _28587 = NOVALUE;
    object _28586 = NOVALUE;
    object _28585 = NOVALUE;
    object _28583 = NOVALUE;
    object _28582 = NOVALUE;
    object _28581 = NOVALUE;
    object _28580 = NOVALUE;
    object _28579 = NOVALUE;
    object _28577 = NOVALUE;
    object _28573 = NOVALUE;
    object _28570 = NOVALUE;
    object _28566 = NOVALUE;
    object _28560 = NOVALUE;
    object _28555 = NOVALUE;
    object _28554 = NOVALUE;
    object _28553 = NOVALUE;
    object _28551 = NOVALUE;
    object _28550 = NOVALUE;
    object _28548 = NOVALUE;
    object _28546 = NOVALUE;
    object _28545 = NOVALUE;
    object _28544 = NOVALUE;
    object _28542 = NOVALUE;
    object _28535 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:1250		integer id, n*/

    /** parser.e:1251		integer save_factors, save_lhs_subs_level*/

    /** parser.e:1254		factors += 1*/
    _45factors_54962 = _45factors_54962 + 1;

    /** parser.e:1255		tok = next_token()*/
    _0 = _tok_56778;
    _tok_56778 = _45next_token();
    DeRef(_0);

    /** parser.e:1256		id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_56778);
    _id_56779 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_56779)){
        _id_56779 = (object)DBL_PTR(_id_56779)->dbl;
    }

    /** parser.e:1257		if id = RECORDED then*/
    if (_id_56779 != 508LL)
    goto L1; // [32] 59

    /** parser.e:1258			tok = read_recorded_token(tok[T_SYM])*/
    _2 = (object)SEQ_PTR(_tok_56778);
    _28535 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_28535);
    _0 = _tok_56778;
    _tok_56778 = _45read_recorded_token(_28535);
    DeRef(_0);
    _28535 = NOVALUE;

    /** parser.e:1259			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_56778);
    _id_56779 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_56779)){
        _id_56779 = (object)DBL_PTR(_id_56779)->dbl;
    }
L1: 

    /** parser.e:1261		switch id label "factor" do*/
    _0 = _id_56779;
    switch ( _0 ){ 

        /** parser.e:1262			case VARIABLE, QUALIFIED_VARIABLE then*/
        case -100:
        case 512:

        /** parser.e:1263				sym = tok[T_SYM]*/
        _2 = (object)SEQ_PTR(_tok_56778);
        _sym_56784 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_sym_56784)){
            _sym_56784 = (object)DBL_PTR(_sym_56784)->dbl;
        }

        /** parser.e:1264				if sym < 0 or SymTab[sym][S_SCOPE] = SC_UNDEFINED then*/
        _28542 = (_sym_56784 < 0LL);
        if (_28542 != 0) {
            goto L2; // [88] 115
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _28544 = (object)*(((s1_ptr)_2)->base + _sym_56784);
        _2 = (object)SEQ_PTR(_28544);
        _28545 = (object)*(((s1_ptr)_2)->base + 4LL);
        _28544 = NOVALUE;
        if (IS_ATOM_INT(_28545)) {
            _28546 = (_28545 == 9LL);
        }
        else {
            _28546 = binary_op(EQUALS, _28545, 9LL);
        }
        _28545 = NOVALUE;
        if (_28546 == 0) {
            DeRef(_28546);
            _28546 = NOVALUE;
            goto L3; // [111] 177
        }
        else {
            if (!IS_ATOM_INT(_28546) && DBL_PTR(_28546)->dbl == 0.0){
                DeRef(_28546);
                _28546 = NOVALUE;
                goto L3; // [111] 177
            }
            DeRef(_28546);
            _28546 = NOVALUE;
        }
        DeRef(_28546);
        _28546 = NOVALUE;
L2: 

        /** parser.e:1265					token forward = next_token()*/
        _0 = _forward_56815;
        _forward_56815 = _45next_token();
        DeRef(_0);

        /** parser.e:1266					if forward[T_ID] = LEFT_ROUND then*/
        _2 = (object)SEQ_PTR(_forward_56815);
        _28548 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _28548, -26LL)){
            _28548 = NOVALUE;
            goto L4; // [130] 151
        }
        _28548 = NOVALUE;

        /** parser.e:1267						Forward_call( tok, FUNC_FORWARD )*/
        Ref(_tok_56778);
        _45Forward_call(_tok_56778, 196LL);

        /** parser.e:1268						break "factor"*/
        DeRef(_forward_56815);
        _forward_56815 = NOVALUE;
        goto L5; // [146] 694
        goto L6; // [148] 172
L4: 

        /** parser.e:1270						putback( forward )*/
        Ref(_forward_56815);
        _45putback(_forward_56815);

        /** parser.e:1271						Forward_var( tok, TRUE )*/
        _2 = (object)SEQ_PTR(_tok_56778);
        _28550 = (object)*(((s1_ptr)_2)->base + 1LL);
        Ref(_tok_56778);
        Ref(_28550);
        _45Forward_var(_tok_56778, _13TRUE_452, _28550);
        _28550 = NOVALUE;
L6: 
        DeRef(_forward_56815);
        _forward_56815 = NOVALUE;
        goto L7; // [174] 229
L3: 

        /** parser.e:1275					UndefinedVar(sym)*/
        _45UndefinedVar(_sym_56784);

        /** parser.e:1276					SymTab[sym][S_USAGE] = or_bits(SymTab[sym][S_USAGE], U_READ)*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_sym_56784 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _28553 = (object)*(((s1_ptr)_2)->base + _sym_56784);
        _2 = (object)SEQ_PTR(_28553);
        _28554 = (object)*(((s1_ptr)_2)->base + 5LL);
        _28553 = NOVALUE;
        if (IS_ATOM_INT(_28554)) {
            {uintptr_t tu;
                 tu = (uintptr_t)_28554 | (uintptr_t)1LL;
                 _28555 = MAKE_UINT(tu);
            }
        }
        else {
            _28555 = binary_op(OR_BITS, _28554, 1LL);
        }
        _28554 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _28555;
        if( _1 != _28555 ){
            DeRef(_1);
        }
        _28555 = NOVALUE;
        _28551 = NOVALUE;

        /** parser.e:1277					InitCheck(sym, TRUE)*/
        _45InitCheck(_sym_56784, _13TRUE_452);

        /** parser.e:1278					emit_opnd(sym)*/
        _47emit_opnd(_sym_56784);
L7: 

        /** parser.e:1281				if sym = left_sym then*/
        if (_sym_56784 != _45left_sym_54965)
        goto L8; // [233] 243

        /** parser.e:1282					lhs_subs_level = 0 -- start counting subscripts*/
        _45lhs_subs_level_54963 = 0LL;
L8: 

        /** parser.e:1285				short_circuit -= 1*/
        _45short_circuit_54924 = _45short_circuit_54924 - 1LL;

        /** parser.e:1286				tok = next_token()*/
        _0 = _tok_56778;
        _tok_56778 = _45next_token();
        DeRef(_0);

        /** parser.e:1287				current_sequence = append(current_sequence, sym)*/
        Append(&_47current_sequence_50940, _47current_sequence_50940, _sym_56784);

        /** parser.e:1288				while tok[T_ID] = LEFT_SQUARE do*/
L9: 
        _2 = (object)SEQ_PTR(_tok_56778);
        _28560 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _28560, -28LL)){
            _28560 = NOVALUE;
            goto LA; // [279] 447
        }
        _28560 = NOVALUE;

        /** parser.e:1289					subs_depth += 1*/
        _45subs_depth_54966 = _45subs_depth_54966 + 1;

        /** parser.e:1290					if lhs_subs_level >= 0 then*/
        if (_45lhs_subs_level_54963 < 0LL)
        goto LB; // [295] 308

        /** parser.e:1291						lhs_subs_level += 1*/
        _45lhs_subs_level_54963 = _45lhs_subs_level_54963 + 1;
LB: 

        /** parser.e:1293					save_factors = factors*/
        _save_factors_56781 = _45factors_54962;

        /** parser.e:1294					save_lhs_subs_level = lhs_subs_level*/
        _save_lhs_subs_level_56782 = _45lhs_subs_level_54963;

        /** parser.e:1295					call_proc(forward_expr, {})*/
        _0 = (object)_00[_45forward_expr_55959].addr;
        (*(intptr_t (*)())_0)(
                             );

        /** parser.e:1296					tok = next_token()*/
        _0 = _tok_56778;
        _tok_56778 = _45next_token();
        DeRef(_0);

        /** parser.e:1297					if tok[T_ID] = SLICE then*/
        _2 = (object)SEQ_PTR(_tok_56778);
        _28566 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _28566, 513LL)){
            _28566 = NOVALUE;
            goto LC; // [344] 382
        }
        _28566 = NOVALUE;

        /** parser.e:1298						call_proc(forward_expr, {})*/
        _0 = (object)_00[_45forward_expr_55959].addr;
        (*(intptr_t (*)())_0)(
                             );

        /** parser.e:1299						emit_op(RHS_SLICE)*/
        _47emit_op(46LL);

        /** parser.e:1300						tok_match(RIGHT_SQUARE)*/
        _45tok_match(-29LL, 0LL);

        /** parser.e:1301						tok = next_token()*/
        _0 = _tok_56778;
        _tok_56778 = _45next_token();
        DeRef(_0);

        /** parser.e:1302						exit*/
        goto LA; // [377] 447
        goto LD; // [379] 427
LC: 

        /** parser.e:1304						putback(tok)*/
        Ref(_tok_56778);
        _45putback(_tok_56778);

        /** parser.e:1305						tok_match(RIGHT_SQUARE)*/
        _45tok_match(-29LL, 0LL);

        /** parser.e:1306						subs_depth -= 1*/
        _45subs_depth_54966 = _45subs_depth_54966 - 1LL;

        /** parser.e:1307						current_sequence = remove( current_sequence, length( current_sequence ) )*/
        if (IS_SEQUENCE(_47current_sequence_50940)){
                _28570 = SEQ_PTR(_47current_sequence_50940)->length;
        }
        else {
            _28570 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_47current_sequence_50940);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_28570)) ? _28570 : (object)(DBL_PTR(_28570)->dbl);
            int stop = (IS_ATOM_INT(_28570)) ? _28570 : (object)(DBL_PTR(_28570)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_47current_sequence_50940), start, &_47current_sequence_50940 );
                }
                else Tail(SEQ_PTR(_47current_sequence_50940), stop+1, &_47current_sequence_50940);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_47current_sequence_50940), start, &_47current_sequence_50940);
            }
            else {
                assign_slice_seq = &assign_space;
                _47current_sequence_50940 = Remove_elements(start, stop, (SEQ_PTR(_47current_sequence_50940)->ref == 1));
            }
        }
        _28570 = NOVALUE;
        _28570 = NOVALUE;

        /** parser.e:1308						emit_op(RHS_SUBS) -- current_sequence will be updated*/
        _47emit_op(25LL);
LD: 

        /** parser.e:1310					factors = save_factors*/
        _45factors_54962 = _save_factors_56781;

        /** parser.e:1311					lhs_subs_level = save_lhs_subs_level*/
        _45lhs_subs_level_54963 = _save_lhs_subs_level_56782;

        /** parser.e:1312					tok = next_token()*/
        _0 = _tok_56778;
        _tok_56778 = _45next_token();
        DeRef(_0);

        /** parser.e:1313				end while*/
        goto L9; // [444] 271
LA: 

        /** parser.e:1314				current_sequence = remove( current_sequence, length( current_sequence ) )*/
        if (IS_SEQUENCE(_47current_sequence_50940)){
                _28573 = SEQ_PTR(_47current_sequence_50940)->length;
        }
        else {
            _28573 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_47current_sequence_50940);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_28573)) ? _28573 : (object)(DBL_PTR(_28573)->dbl);
            int stop = (IS_ATOM_INT(_28573)) ? _28573 : (object)(DBL_PTR(_28573)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_47current_sequence_50940), start, &_47current_sequence_50940 );
                }
                else Tail(SEQ_PTR(_47current_sequence_50940), stop+1, &_47current_sequence_50940);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_47current_sequence_50940), start, &_47current_sequence_50940);
            }
            else {
                assign_slice_seq = &assign_space;
                _47current_sequence_50940 = Remove_elements(start, stop, (SEQ_PTR(_47current_sequence_50940)->ref == 1));
            }
        }
        _28573 = NOVALUE;
        _28573 = NOVALUE;

        /** parser.e:1315				putback(tok)*/
        Ref(_tok_56778);
        _45putback(_tok_56778);

        /** parser.e:1316				short_circuit += 1*/
        _45short_circuit_54924 = _45short_circuit_54924 + 1;
        goto L5; // [476] 694

        /** parser.e:1318			case DOLLAR then*/
        case -22:

        /** parser.e:1319				tok = next_token()*/
        _0 = _tok_56778;
        _tok_56778 = _45next_token();
        DeRef(_0);

        /** parser.e:1320				putback(tok)*/
        Ref(_tok_56778);
        _45putback(_tok_56778);

        /** parser.e:1321				if tok[T_ID] = RIGHT_BRACE then*/
        _2 = (object)SEQ_PTR(_tok_56778);
        _28577 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _28577, -25LL)){
            _28577 = NOVALUE;
            goto LE; // [502] 520
        }
        _28577 = NOVALUE;

        /** parser.e:1322					gListItem[$] = 0*/
        if (IS_SEQUENCE(_45gListItem_54960)){
                _28579 = SEQ_PTR(_45gListItem_54960)->length;
        }
        else {
            _28579 = 1;
        }
        _2 = (object)SEQ_PTR(_45gListItem_54960);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _45gListItem_54960 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _28579);
        *(intptr_t *)_2 = 0LL;
        goto L5; // [517] 694
LE: 

        /** parser.e:1324					if subs_depth > 0 and length(current_sequence) then*/
        _28580 = (_45subs_depth_54966 > 0LL);
        if (_28580 == 0) {
            goto LF; // [528] 551
        }
        if (IS_SEQUENCE(_47current_sequence_50940)){
                _28582 = SEQ_PTR(_47current_sequence_50940)->length;
        }
        else {
            _28582 = 1;
        }
        if (_28582 == 0)
        {
            _28582 = NOVALUE;
            goto LF; // [538] 551
        }
        else{
            _28582 = NOVALUE;
        }

        /** parser.e:1325						emit_op(DOLLAR)*/
        _47emit_op(-22LL);
        goto L5; // [548] 694
LF: 

        /** parser.e:1327						CompileErr(MSG__MUST_ONLY_APPEAR_BETWEEN__AND__OR_AS_THE_LAST_ITEM_IN_A_SEQUENCE_LITERAL)*/
        RefDS(_21993);
        _50CompileErr(21LL, _21993, 0LL);
        goto L5; // [562] 694

        /** parser.e:1331			case ATOM then*/
        case 502:

        /** parser.e:1332				emit_opnd(tok[T_SYM])*/
        _2 = (object)SEQ_PTR(_tok_56778);
        _28583 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_28583);
        _47emit_opnd(_28583);
        _28583 = NOVALUE;
        goto L5; // [579] 694

        /** parser.e:1334			case LEFT_BRACE then*/
        case -24:

        /** parser.e:1335				n = Expr_list()*/
        _n_56780 = _45Expr_list();
        if (!IS_ATOM_INT(_n_56780)) {
            _1 = (object)(DBL_PTR(_n_56780)->dbl);
            DeRefDS(_n_56780);
            _n_56780 = _1;
        }

        /** parser.e:1336				tok_match(RIGHT_BRACE)*/
        _45tok_match(-25LL, 0LL);

        /** parser.e:1337				op_info1 = n*/
        _47op_info1_50932 = _n_56780;

        /** parser.e:1338				emit_op(RIGHT_BRACE_N)*/
        _47emit_op(31LL);
        goto L5; // [614] 694

        /** parser.e:1340			case STRING then*/
        case 503:

        /** parser.e:1341				emit_opnd(tok[T_SYM])*/
        _2 = (object)SEQ_PTR(_tok_56778);
        _28585 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_28585);
        _47emit_opnd(_28585);
        _28585 = NOVALUE;
        goto L5; // [631] 694

        /** parser.e:1343			case LEFT_ROUND then*/
        case -26:

        /** parser.e:1344				call_proc(forward_expr, {})*/
        _0 = (object)_00[_45forward_expr_55959].addr;
        (*(intptr_t (*)())_0)(
                             );

        /** parser.e:1345				tok_match(RIGHT_ROUND)*/
        _45tok_match(-27LL, 0LL);
        goto L5; // [652] 694

        /** parser.e:1347			case FUNC, TYPE, QUALIFIED_FUNC, QUALIFIED_TYPE then*/
        case 501:
        case 504:
        case 520:
        case 522:

        /** parser.e:1348				Function_call( tok )*/
        Ref(_tok_56778);
        _45Function_call(_tok_56778);
        goto L5; // [669] 694

        /** parser.e:1350			case else*/
        default:

        /** parser.e:1351				CompileErr(SYNTAX_ERROR__EXPECTED_TO_SEE_AN_EXPRESSION_NOT_1, {LexName(id)})*/
        RefDS(_26329);
        _28586 = _47LexName(_id_56779, _26329);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _28586;
        _28587 = MAKE_SEQ(_1);
        _28586 = NOVALUE;
        _50CompileErr(135LL, _28587, 0LL);
        _28587 = NOVALUE;
    ;}L5: 

    /** parser.e:1353	end procedure*/
    DeRef(_tok_56778);
    DeRef(_28580);
    _28580 = NOVALUE;
    DeRef(_28542);
    _28542 = NOVALUE;
    return;
    ;
}


void _45UFactor()
{
    object _tok_56937 = NOVALUE;
    object _28593 = NOVALUE;
    object _28591 = NOVALUE;
    object _28589 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1359		tok = next_token()*/
    _0 = _tok_56937;
    _tok_56937 = _45next_token();
    DeRef(_0);

    /** parser.e:1361		if tok[T_ID] = MINUS then*/
    _2 = (object)SEQ_PTR(_tok_56937);
    _28589 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28589, 10LL)){
        _28589 = NOVALUE;
        goto L1; // [16] 34
    }
    _28589 = NOVALUE;

    /** parser.e:1362			Factor()*/
    _45Factor();

    /** parser.e:1363			emit_op(UMINUS)*/
    _47emit_op(12LL);
    goto L2; // [31] 93
L1: 

    /** parser.e:1365		elsif tok[T_ID] = NOT then*/
    _2 = (object)SEQ_PTR(_tok_56937);
    _28591 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28591, 7LL)){
        _28591 = NOVALUE;
        goto L3; // [44] 62
    }
    _28591 = NOVALUE;

    /** parser.e:1366			Factor()*/
    _45Factor();

    /** parser.e:1367			emit_op(NOT)*/
    _47emit_op(7LL);
    goto L2; // [59] 93
L3: 

    /** parser.e:1369		elsif tok[T_ID] = PLUS then*/
    _2 = (object)SEQ_PTR(_tok_56937);
    _28593 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28593, 11LL)){
        _28593 = NOVALUE;
        goto L4; // [72] 83
    }
    _28593 = NOVALUE;

    /** parser.e:1370			Factor()*/
    _45Factor();
    goto L2; // [80] 93
L4: 

    /** parser.e:1373			putback(tok)*/
    Ref(_tok_56937);
    _45putback(_tok_56937);

    /** parser.e:1374			Factor()*/
    _45Factor();
L2: 

    /** parser.e:1377	end procedure*/
    DeRef(_tok_56937);
    return;
    ;
}


object _45Term()
{
    object _tok_56962 = NOVALUE;
    object _28601 = NOVALUE;
    object _28600 = NOVALUE;
    object _28599 = NOVALUE;
    object _28597 = NOVALUE;
    object _28596 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1383		UFactor()*/
    _45UFactor();

    /** parser.e:1384		tok = next_token()*/
    _0 = _tok_56962;
    _tok_56962 = _45next_token();
    DeRef(_0);

    /** parser.e:1385		while tok[T_ID] = reserved:MULTIPLY or tok[T_ID] = reserved:DIVIDE do*/
L1: 
    _2 = (object)SEQ_PTR(_tok_56962);
    _28596 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28596)) {
        _28597 = (_28596 == 13LL);
    }
    else {
        _28597 = binary_op(EQUALS, _28596, 13LL);
    }
    _28596 = NOVALUE;
    if (IS_ATOM_INT(_28597)) {
        if (_28597 != 0) {
            goto L2; // [25] 44
        }
    }
    else {
        if (DBL_PTR(_28597)->dbl != 0.0) {
            goto L2; // [25] 44
        }
    }
    _2 = (object)SEQ_PTR(_tok_56962);
    _28599 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28599)) {
        _28600 = (_28599 == 14LL);
    }
    else {
        _28600 = binary_op(EQUALS, _28599, 14LL);
    }
    _28599 = NOVALUE;
    if (_28600 <= 0) {
        if (_28600 == 0) {
            DeRef(_28600);
            _28600 = NOVALUE;
            goto L3; // [40] 69
        }
        else {
            if (!IS_ATOM_INT(_28600) && DBL_PTR(_28600)->dbl == 0.0){
                DeRef(_28600);
                _28600 = NOVALUE;
                goto L3; // [40] 69
            }
            DeRef(_28600);
            _28600 = NOVALUE;
        }
    }
    DeRef(_28600);
    _28600 = NOVALUE;
L2: 

    /** parser.e:1386			UFactor()*/
    _45UFactor();

    /** parser.e:1387			emit_op(tok[T_ID])*/
    _2 = (object)SEQ_PTR(_tok_56962);
    _28601 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_28601);
    _47emit_op(_28601);
    _28601 = NOVALUE;

    /** parser.e:1388			tok = next_token()*/
    _0 = _tok_56962;
    _tok_56962 = _45next_token();
    DeRef(_0);

    /** parser.e:1389		end while*/
    goto L1; // [66] 15
L3: 

    /** parser.e:1390		return tok*/
    DeRef(_28597);
    _28597 = NOVALUE;
    return _tok_56962;
    ;
}


object _45aexpr()
{
    object _tok_56979 = NOVALUE;
    object _id_56980 = NOVALUE;
    object _28608 = NOVALUE;
    object _28607 = NOVALUE;
    object _28605 = NOVALUE;
    object _28604 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1396		integer id*/

    /** parser.e:1398		tok = Term()*/
    _0 = _tok_56979;
    _tok_56979 = _45Term();
    DeRef(_0);

    /** parser.e:1399		while tok[T_ID] = PLUS or tok[T_ID] = MINUS do*/
L1: 
    _2 = (object)SEQ_PTR(_tok_56979);
    _28604 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28604)) {
        _28605 = (_28604 == 11LL);
    }
    else {
        _28605 = binary_op(EQUALS, _28604, 11LL);
    }
    _28604 = NOVALUE;
    if (IS_ATOM_INT(_28605)) {
        if (_28605 != 0) {
            goto L2; // [25] 46
        }
    }
    else {
        if (DBL_PTR(_28605)->dbl != 0.0) {
            goto L2; // [25] 46
        }
    }
    _2 = (object)SEQ_PTR(_tok_56979);
    _28607 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28607)) {
        _28608 = (_28607 == 10LL);
    }
    else {
        _28608 = binary_op(EQUALS, _28607, 10LL);
    }
    _28607 = NOVALUE;
    if (_28608 <= 0) {
        if (_28608 == 0) {
            DeRef(_28608);
            _28608 = NOVALUE;
            goto L3; // [42] 71
        }
        else {
            if (!IS_ATOM_INT(_28608) && DBL_PTR(_28608)->dbl == 0.0){
                DeRef(_28608);
                _28608 = NOVALUE;
                goto L3; // [42] 71
            }
            DeRef(_28608);
            _28608 = NOVALUE;
        }
    }
    DeRef(_28608);
    _28608 = NOVALUE;
L2: 

    /** parser.e:1400			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_56979);
    _id_56980 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_56980)){
        _id_56980 = (object)DBL_PTR(_id_56980)->dbl;
    }

    /** parser.e:1401			tok = Term()*/
    _0 = _tok_56979;
    _tok_56979 = _45Term();
    DeRef(_0);

    /** parser.e:1402			emit_op(id)*/
    _47emit_op(_id_56980);

    /** parser.e:1403		end while*/
    goto L1; // [68] 13
L3: 

    /** parser.e:1404		return tok*/
    DeRef(_28605);
    _28605 = NOVALUE;
    return _tok_56979;
    ;
}


object _45cexpr()
{
    object _tok_56999 = NOVALUE;
    object _concat_count_57000 = NOVALUE;
    object _28612 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1410		integer concat_count*/

    /** parser.e:1412		tok = aexpr()*/
    _0 = _tok_56999;
    _tok_56999 = _45aexpr();
    DeRef(_0);

    /** parser.e:1413		concat_count = 0*/
    _concat_count_57000 = 0LL;

    /** parser.e:1414		while tok[T_ID] = reserved:CONCAT do*/
L1: 
    _2 = (object)SEQ_PTR(_tok_56999);
    _28612 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28612, 15LL)){
        _28612 = NOVALUE;
        goto L2; // [24] 44
    }
    _28612 = NOVALUE;

    /** parser.e:1415			tok = aexpr()*/
    _0 = _tok_56999;
    _tok_56999 = _45aexpr();
    DeRef(_0);

    /** parser.e:1416			concat_count += 1*/
    _concat_count_57000 = _concat_count_57000 + 1;

    /** parser.e:1417		end while*/
    goto L1; // [41] 18
L2: 

    /** parser.e:1419		if concat_count = 1 then*/
    if (_concat_count_57000 != 1LL)
    goto L3; // [46] 58

    /** parser.e:1420			emit_op( reserved:CONCAT )*/
    _47emit_op(15LL);
    goto L4; // [55] 81
L3: 

    /** parser.e:1422		elsif concat_count > 1 then*/
    if (_concat_count_57000 <= 1LL)
    goto L5; // [60] 80

    /** parser.e:1423			op_info1 = concat_count+1*/
    _47op_info1_50932 = _concat_count_57000 + 1;

    /** parser.e:1424			emit_op(CONCAT_N)*/
    _47emit_op(157LL);
L5: 
L4: 

    /** parser.e:1427		return tok*/
    return _tok_56999;
    ;
}


object _45rexpr()
{
    object _tok_57020 = NOVALUE;
    object _id_57021 = NOVALUE;
    object _28624 = NOVALUE;
    object _28623 = NOVALUE;
    object _28622 = NOVALUE;
    object _28621 = NOVALUE;
    object _28620 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1433		integer id*/

    /** parser.e:1435		tok = cexpr()*/
    _0 = _tok_57020;
    _tok_57020 = _45cexpr();
    DeRef(_0);

    /** parser.e:1436		while tok[T_ID] <= GREATER and tok[T_ID] >= LESS do*/
L1: 
    _2 = (object)SEQ_PTR(_tok_57020);
    _28620 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28620)) {
        _28621 = (_28620 <= 6LL);
    }
    else {
        _28621 = binary_op(LESSEQ, _28620, 6LL);
    }
    _28620 = NOVALUE;
    if (IS_ATOM_INT(_28621)) {
        if (_28621 == 0) {
            goto L2; // [25] 70
        }
    }
    else {
        if (DBL_PTR(_28621)->dbl == 0.0) {
            goto L2; // [25] 70
        }
    }
    _2 = (object)SEQ_PTR(_tok_57020);
    _28623 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28623)) {
        _28624 = (_28623 >= 1LL);
    }
    else {
        _28624 = binary_op(GREATEREQ, _28623, 1LL);
    }
    _28623 = NOVALUE;
    if (_28624 <= 0) {
        if (_28624 == 0) {
            DeRef(_28624);
            _28624 = NOVALUE;
            goto L2; // [42] 70
        }
        else {
            if (!IS_ATOM_INT(_28624) && DBL_PTR(_28624)->dbl == 0.0){
                DeRef(_28624);
                _28624 = NOVALUE;
                goto L2; // [42] 70
            }
            DeRef(_28624);
            _28624 = NOVALUE;
        }
    }
    DeRef(_28624);
    _28624 = NOVALUE;

    /** parser.e:1437			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57020);
    _id_57021 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_57021)){
        _id_57021 = (object)DBL_PTR(_id_57021)->dbl;
    }

    /** parser.e:1438			tok = cexpr()*/
    _0 = _tok_57020;
    _tok_57020 = _45cexpr();
    DeRef(_0);

    /** parser.e:1439			emit_op(id)*/
    _47emit_op(_id_57021);

    /** parser.e:1440		end while*/
    goto L1; // [67] 13
L2: 

    /** parser.e:1441		return tok*/
    DeRef(_28621);
    _28621 = NOVALUE;
    return _tok_57020;
    ;
}


void _45Expr()
{
    object _tok_57047 = NOVALUE;
    object _id_57048 = NOVALUE;
    object _patch_57049 = NOVALUE;
    object _28647 = NOVALUE;
    object _28645 = NOVALUE;
    object _28644 = NOVALUE;
    object _28642 = NOVALUE;
    object _28641 = NOVALUE;
    object _28640 = NOVALUE;
    object _28639 = NOVALUE;
    object _28638 = NOVALUE;
    object _28632 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1451		integer id*/

    /** parser.e:1452		integer patch*/

    /** parser.e:1454		ExprLine = ThisLine*/
    Ref(_50ThisLine_49234);
    DeRef(_45ExprLine_57042);
    _45ExprLine_57042 = _50ThisLine_49234;

    /** parser.e:1455		expr_bp = bp*/
    _45expr_bp_57043 = _50bp_49238;

    /** parser.e:1456		id = -1*/
    _id_57048 = -1LL;

    /** parser.e:1457		patch = 0*/
    _patch_57049 = 0LL;

    /** parser.e:1458		while TRUE do*/
L1: 
    if (_13TRUE_452 == 0)
    {
        goto L2; // [40] 300
    }
    else{
    }

    /** parser.e:1459			if id != -1 then*/
    if (_id_57048 == -1LL)
    goto L3; // [45] 116

    /** parser.e:1460				if id != XOR then*/
    if (_id_57048 == 152LL)
    goto L4; // [53] 115

    /** parser.e:1461					if short_circuit > 0 then*/
    if (_45short_circuit_54924 <= 0LL)
    goto L5; // [61] 114

    /** parser.e:1462						if id = OR then*/
    if (_id_57048 != 9LL)
    goto L6; // [69] 83

    /** parser.e:1463							emit_op(SC1_OR)*/
    _47emit_op(143LL);
    goto L7; // [80] 91
L6: 

    /** parser.e:1465							emit_op(SC1_AND)*/
    _47emit_op(141LL);
L7: 

    /** parser.e:1467						patch = length(Code)+1*/
    if (IS_SEQUENCE(_36Code_21531)){
            _28632 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _28632 = 1;
    }
    _patch_57049 = _28632 + 1;
    _28632 = NOVALUE;

    /** parser.e:1468						emit_forward_addr()*/
    _45emit_forward_addr();

    /** parser.e:1469						short_circuit_B = TRUE*/
    _45short_circuit_B_54926 = _13TRUE_452;
L5: 
L4: 
L3: 

    /** parser.e:1474			tok = rexpr()*/
    _0 = _tok_57047;
    _tok_57047 = _45rexpr();
    DeRef(_0);

    /** parser.e:1476			if id != -1 then*/
    if (_id_57048 == -1LL)
    goto L8; // [123] 268

    /** parser.e:1477				if id != XOR then*/
    if (_id_57048 == 152LL)
    goto L9; // [131] 261

    /** parser.e:1478					if short_circuit > 0 then*/
    if (_45short_circuit_54924 <= 0LL)
    goto LA; // [139] 252

    /** parser.e:1479						if tok[T_ID] != THEN and tok[T_ID] != DO then*/
    _2 = (object)SEQ_PTR(_tok_57047);
    _28638 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28638)) {
        _28639 = (_28638 != 410LL);
    }
    else {
        _28639 = binary_op(NOTEQ, _28638, 410LL);
    }
    _28638 = NOVALUE;
    if (IS_ATOM_INT(_28639)) {
        if (_28639 == 0) {
            goto LB; // [157] 206
        }
    }
    else {
        if (DBL_PTR(_28639)->dbl == 0.0) {
            goto LB; // [157] 206
        }
    }
    _2 = (object)SEQ_PTR(_tok_57047);
    _28641 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28641)) {
        _28642 = (_28641 != 411LL);
    }
    else {
        _28642 = binary_op(NOTEQ, _28641, 411LL);
    }
    _28641 = NOVALUE;
    if (_28642 == 0) {
        DeRef(_28642);
        _28642 = NOVALUE;
        goto LB; // [174] 206
    }
    else {
        if (!IS_ATOM_INT(_28642) && DBL_PTR(_28642)->dbl == 0.0){
            DeRef(_28642);
            _28642 = NOVALUE;
            goto LB; // [174] 206
        }
        DeRef(_28642);
        _28642 = NOVALUE;
    }
    DeRef(_28642);
    _28642 = NOVALUE;

    /** parser.e:1480							if id = OR then*/
    if (_id_57048 != 9LL)
    goto LC; // [181] 195

    /** parser.e:1481								emit_op(SC2_OR)*/
    _47emit_op(144LL);
    goto LD; // [192] 219
LC: 

    /** parser.e:1483								emit_op(SC2_AND)*/
    _47emit_op(142LL);
    goto LD; // [203] 219
LB: 

    /** parser.e:1486							SC1_type = id -- if/while/elsif must patch*/
    _45SC1_type_54929 = _id_57048;

    /** parser.e:1487							emit_op(SC2_NULL)*/
    _47emit_op(145LL);
LD: 

    /** parser.e:1489						if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto LE; // [223] 234
    }
    else{
    }

    /** parser.e:1490							emit_op(NOP1)   -- to get label here*/
    _47emit_op(159LL);
LE: 

    /** parser.e:1492						backpatch(patch, length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21531)){
            _28644 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _28644 = 1;
    }
    _28645 = _28644 + 1;
    _28644 = NOVALUE;
    _47backpatch(_patch_57049, _28645);
    _28645 = NOVALUE;
    goto LF; // [249] 267
LA: 

    /** parser.e:1494						emit_op(id)*/
    _47emit_op(_id_57048);
    goto LF; // [258] 267
L9: 

    /** parser.e:1497					emit_op(id)*/
    _47emit_op(_id_57048);
LF: 
L8: 

    /** parser.e:1500			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57047);
    _id_57048 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_57048)){
        _id_57048 = (object)DBL_PTR(_id_57048)->dbl;
    }

    /** parser.e:1501			if not find(id, boolOps) then*/
    _28647 = find_from(_id_57048, _45boolOps_57037, 1LL);
    if (_28647 != 0)
    goto L1; // [287] 38
    _28647 = NOVALUE;

    /** parser.e:1502				exit*/
    goto L2; // [292] 300

    /** parser.e:1504		end while*/
    goto L1; // [297] 38
L2: 

    /** parser.e:1505		putback(tok)*/
    Ref(_tok_57047);
    _45putback(_tok_57047);

    /** parser.e:1506		SC1_patch = patch -- extra line*/
    _45SC1_patch_54928 = _patch_57049;

    /** parser.e:1507	end procedure*/
    DeRef(_tok_57047);
    DeRef(_28639);
    _28639 = NOVALUE;
    return;
    ;
}


void _45TypeCheck(object _var_57124)
{
    object _which_type_57125 = NOVALUE;
    object _ref_57135 = NOVALUE;
    object _ref_57168 = NOVALUE;
    object _28703 = NOVALUE;
    object _28702 = NOVALUE;
    object _28701 = NOVALUE;
    object _28700 = NOVALUE;
    object _28699 = NOVALUE;
    object _28697 = NOVALUE;
    object _28696 = NOVALUE;
    object _28695 = NOVALUE;
    object _28694 = NOVALUE;
    object _28693 = NOVALUE;
    object _28692 = NOVALUE;
    object _28690 = NOVALUE;
    object _28689 = NOVALUE;
    object _28686 = NOVALUE;
    object _28685 = NOVALUE;
    object _28684 = NOVALUE;
    object _28683 = NOVALUE;
    object _28678 = NOVALUE;
    object _28677 = NOVALUE;
    object _28673 = NOVALUE;
    object _28671 = NOVALUE;
    object _28670 = NOVALUE;
    object _28669 = NOVALUE;
    object _28667 = NOVALUE;
    object _28666 = NOVALUE;
    object _28665 = NOVALUE;
    object _28664 = NOVALUE;
    object _28663 = NOVALUE;
    object _28662 = NOVALUE;
    object _28659 = NOVALUE;
    object _28657 = NOVALUE;
    object _28655 = NOVALUE;
    object _28654 = NOVALUE;
    object _28653 = NOVALUE;
    object _28651 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_var_57124)) {
        _1 = (object)(DBL_PTR(_var_57124)->dbl);
        DeRefDS(_var_57124);
        _var_57124 = _1;
    }

    /** parser.e:1515		if var < 0 or SymTab[var][S_SCOPE] = SC_UNDEFINED then*/
    _28651 = (_var_57124 < 0LL);
    if (_28651 != 0) {
        goto L1; // [9] 36
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28653 = (object)*(((s1_ptr)_2)->base + _var_57124);
    _2 = (object)SEQ_PTR(_28653);
    _28654 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28653 = NOVALUE;
    if (IS_ATOM_INT(_28654)) {
        _28655 = (_28654 == 9LL);
    }
    else {
        _28655 = binary_op(EQUALS, _28654, 9LL);
    }
    _28654 = NOVALUE;
    if (_28655 == 0) {
        DeRef(_28655);
        _28655 = NOVALUE;
        goto L2; // [32] 76
    }
    else {
        if (!IS_ATOM_INT(_28655) && DBL_PTR(_28655)->dbl == 0.0){
            DeRef(_28655);
            _28655 = NOVALUE;
            goto L2; // [32] 76
        }
        DeRef(_28655);
        _28655 = NOVALUE;
    }
    DeRef(_28655);
    _28655 = NOVALUE;
L1: 

    /** parser.e:1517			integer ref = new_forward_reference( TYPE_CHECK, var, TYPE_CHECK_FORWARD )*/
    _ref_57135 = _44new_forward_reference(65LL, _var_57124, 197LL);
    if (!IS_ATOM_INT(_ref_57135)) {
        _1 = (object)(DBL_PTR(_ref_57135)->dbl);
        DeRefDS(_ref_57135);
        _ref_57135 = _1;
    }

    /** parser.e:1518			Code &= { TYPE_CHECK_FORWARD, var, OpTypeCheck }*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 197LL;
    ((intptr_t*)_2)[2] = _var_57124;
    ((intptr_t*)_2)[3] = _36OpTypeCheck_21513;
    _28657 = MAKE_SEQ(_1);
    Concat((object_ptr)&_36Code_21531, _36Code_21531, _28657);
    DeRefDS(_28657);
    _28657 = NOVALUE;

    /** parser.e:1519			return*/
    DeRef(_28651);
    _28651 = NOVALUE;
    return;
L2: 

    /** parser.e:1522		which_type = SymTab[var][S_VTYPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28659 = (object)*(((s1_ptr)_2)->base + _var_57124);
    _2 = (object)SEQ_PTR(_28659);
    _which_type_57125 = (object)*(((s1_ptr)_2)->base + 15LL);
    if (!IS_ATOM_INT(_which_type_57125)){
        _which_type_57125 = (object)DBL_PTR(_which_type_57125)->dbl;
    }
    _28659 = NOVALUE;

    /** parser.e:1523		if which_type = 0 then*/
    if (_which_type_57125 != 0LL)
    goto L3; // [96] 106

    /** parser.e:1524			return	-- Not a typed identifier.*/
    DeRef(_28651);
    _28651 = NOVALUE;
    return;
L3: 

    /** parser.e:1526		if which_type > 0 and length(SymTab[which_type]) < S_TOKEN then*/
    _28662 = (_which_type_57125 > 0LL);
    if (_28662 == 0) {
        goto L4; // [112] 141
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28664 = (object)*(((s1_ptr)_2)->base + _which_type_57125);
    if (IS_SEQUENCE(_28664)){
            _28665 = SEQ_PTR(_28664)->length;
    }
    else {
        _28665 = 1;
    }
    _28664 = NOVALUE;
    if (IS_ATOM_INT(_36S_TOKEN_21081)) {
        _28666 = (_28665 < _36S_TOKEN_21081);
    }
    else {
        _28666 = binary_op(LESS, _28665, _36S_TOKEN_21081);
    }
    _28665 = NOVALUE;
    if (_28666 == 0) {
        DeRef(_28666);
        _28666 = NOVALUE;
        goto L4; // [132] 141
    }
    else {
        if (!IS_ATOM_INT(_28666) && DBL_PTR(_28666)->dbl == 0.0){
            DeRef(_28666);
            _28666 = NOVALUE;
            goto L4; // [132] 141
        }
        DeRef(_28666);
        _28666 = NOVALUE;
    }
    DeRef(_28666);
    _28666 = NOVALUE;

    /** parser.e:1527			return	-- Not a typed identifier.*/
    _28664 = NOVALUE;
    DeRef(_28662);
    _28662 = NOVALUE;
    DeRef(_28651);
    _28651 = NOVALUE;
    return;
L4: 

    /** parser.e:1530		if which_type < 0 or SymTab[which_type][S_TOKEN] = VARIABLE  then*/
    _28667 = (_which_type_57125 < 0LL);
    if (_28667 != 0) {
        goto L5; // [147] 174
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28669 = (object)*(((s1_ptr)_2)->base + _which_type_57125);
    _2 = (object)SEQ_PTR(_28669);
    if (!IS_ATOM_INT(_36S_TOKEN_21081)){
        _28670 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    }
    else{
        _28670 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    }
    _28669 = NOVALUE;
    if (IS_ATOM_INT(_28670)) {
        _28671 = (_28670 == -100LL);
    }
    else {
        _28671 = binary_op(EQUALS, _28670, -100LL);
    }
    _28670 = NOVALUE;
    if (_28671 == 0) {
        DeRef(_28671);
        _28671 = NOVALUE;
        goto L6; // [170] 214
    }
    else {
        if (!IS_ATOM_INT(_28671) && DBL_PTR(_28671)->dbl == 0.0){
            DeRef(_28671);
            _28671 = NOVALUE;
            goto L6; // [170] 214
        }
        DeRef(_28671);
        _28671 = NOVALUE;
    }
    DeRef(_28671);
    _28671 = NOVALUE;
L5: 

    /** parser.e:1531			integer ref = new_forward_reference( TYPE_CHECK, which_type, TYPE )*/
    _ref_57168 = _44new_forward_reference(65LL, _which_type_57125, 504LL);
    if (!IS_ATOM_INT(_ref_57168)) {
        _1 = (object)(DBL_PTR(_ref_57168)->dbl);
        DeRefDS(_ref_57168);
        _ref_57168 = _1;
    }

    /** parser.e:1532			Code &= { TYPE_CHECK_FORWARD, var, OpTypeCheck }*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 197LL;
    ((intptr_t*)_2)[2] = _var_57124;
    ((intptr_t*)_2)[3] = _36OpTypeCheck_21513;
    _28673 = MAKE_SEQ(_1);
    Concat((object_ptr)&_36Code_21531, _36Code_21531, _28673);
    DeRefDS(_28673);
    _28673 = NOVALUE;

    /** parser.e:1534			return*/
    _28664 = NOVALUE;
    DeRef(_28662);
    _28662 = NOVALUE;
    DeRef(_28667);
    _28667 = NOVALUE;
    DeRef(_28651);
    _28651 = NOVALUE;
    return;
L6: 

    /** parser.e:1537		if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L7; // [220] 317
    }
    else{
    }

    /** parser.e:1538			if OpTypeCheck then*/
    if (_36OpTypeCheck_21513 == 0)
    {
        goto L8; // [227] 481
    }
    else{
    }

    /** parser.e:1539				switch which_type do*/
    if( _45_57182_cases == 0 ){
        _45_57182_cases = 1;
        SEQ_PTR( _28675 )->base[1] = _54object_type_46776;
        SEQ_PTR( _28675 )->base[2] = _54sequence_type_46780;
        SEQ_PTR( _28675 )->base[3] = _54atom_type_46778;
        SEQ_PTR( _28675 )->base[4] = _54integer_type_46782;
    }
    _1 = find(_which_type_57125, _28675);
    switch ( _1 ){ 

        /** parser.e:1540					case object_type, sequence_type, atom_type then*/
        case 1:
        case 2:
        case 3:

        /** parser.e:1542					case integer_type then*/
        goto L8; // [247] 481
        case 4:

        /** parser.e:1544						op_info1 = var*/
        _47op_info1_50932 = _var_57124;

        /** parser.e:1545						emit_op(INTEGER_CHECK)*/
        _47emit_op(96LL);
        goto L8; // [265] 481

        /** parser.e:1546					case else*/
        case 0:

        /** parser.e:1547						if SymTab[which_type][S_EFFECT] then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _28677 = (object)*(((s1_ptr)_2)->base + _which_type_57125);
        _2 = (object)SEQ_PTR(_28677);
        _28678 = (object)*(((s1_ptr)_2)->base + 23LL);
        _28677 = NOVALUE;
        if (_28678 == 0) {
            _28678 = NOVALUE;
            goto L9; // [285] 312
        }
        else {
            if (!IS_ATOM_INT(_28678) && DBL_PTR(_28678)->dbl == 0.0){
                _28678 = NOVALUE;
                goto L9; // [285] 312
            }
            _28678 = NOVALUE;
        }
        _28678 = NOVALUE;

        /** parser.e:1549							emit_opnd(var)*/
        _47emit_opnd(_var_57124);

        /** parser.e:1550							op_info1 = which_type*/
        _47op_info1_50932 = _which_type_57125;

        /** parser.e:1552							emit_or_inline()*/
        _67emit_or_inline();

        /** parser.e:1553							emit_op(TYPE_CHECK)*/
        _47emit_op(65LL);
L9: 
    ;}    goto L8; // [314] 481
L7: 

    /** parser.e:1559			if OpTypeCheck then*/
    if (_36OpTypeCheck_21513 == 0)
    {
        goto LA; // [321] 480
    }
    else{
    }

    /** parser.e:1560				if which_type != object_type then*/
    if (_which_type_57125 == _54object_type_46776)
    goto LB; // [328] 479

    /** parser.e:1561					if which_type = integer_type then*/
    if (_which_type_57125 != _54integer_type_46782)
    goto LC; // [336] 357

    /** parser.e:1562							op_info1 = var*/
    _47op_info1_50932 = _var_57124;

    /** parser.e:1563							emit_op(INTEGER_CHECK)*/
    _47emit_op(96LL);
    goto LD; // [354] 478
LC: 

    /** parser.e:1565					elsif which_type = sequence_type then*/
    if (_which_type_57125 != _54sequence_type_46780)
    goto LE; // [361] 382

    /** parser.e:1566							op_info1 = var*/
    _47op_info1_50932 = _var_57124;

    /** parser.e:1567							emit_op(SEQUENCE_CHECK)*/
    _47emit_op(97LL);
    goto LD; // [379] 478
LE: 

    /** parser.e:1569					elsif which_type = atom_type then*/
    if (_which_type_57125 != _54atom_type_46778)
    goto LF; // [386] 407

    /** parser.e:1570							op_info1 = var*/
    _47op_info1_50932 = _var_57124;

    /** parser.e:1571							emit_op(ATOM_CHECK)*/
    _47emit_op(101LL);
    goto LD; // [404] 478
LF: 

    /** parser.e:1575							if SymTab[SymTab[which_type][S_NEXT]][S_VTYPE] =*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28683 = (object)*(((s1_ptr)_2)->base + _which_type_57125);
    _2 = (object)SEQ_PTR(_28683);
    _28684 = (object)*(((s1_ptr)_2)->base + 2LL);
    _28683 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_28684)){
        _28685 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28684)->dbl));
    }
    else{
        _28685 = (object)*(((s1_ptr)_2)->base + _28684);
    }
    _2 = (object)SEQ_PTR(_28685);
    _28686 = (object)*(((s1_ptr)_2)->base + 15LL);
    _28685 = NOVALUE;
    if (binary_op_a(NOTEQ, _28686, _54integer_type_46782)){
        _28686 = NOVALUE;
        goto L10; // [435] 454
    }
    _28686 = NOVALUE;

    /** parser.e:1577								op_info1 = var*/
    _47op_info1_50932 = _var_57124;

    /** parser.e:1578								emit_op(INTEGER_CHECK) -- need integer conversion*/
    _47emit_op(96LL);
L10: 

    /** parser.e:1580							emit_opnd(var)*/
    _47emit_opnd(_var_57124);

    /** parser.e:1581							op_info1 = which_type*/
    _47op_info1_50932 = _which_type_57125;

    /** parser.e:1582							emit_or_inline()*/
    _67emit_or_inline();

    /** parser.e:1584							emit_op(TYPE_CHECK)*/
    _47emit_op(65LL);
LD: 
LB: 
LA: 
L8: 

    /** parser.e:1590		if TRANSLATE or not OpTypeCheck then*/
    if (_36TRANSLATE_21041 != 0) {
        goto L11; // [485] 499
    }
    _28689 = (_36OpTypeCheck_21513 == 0);
    if (_28689 == 0)
    {
        DeRef(_28689);
        _28689 = NOVALUE;
        goto L12; // [495] 620
    }
    else{
        DeRef(_28689);
        _28689 = NOVALUE;
    }
L11: 

    /** parser.e:1591			op_info1 = var*/
    _47op_info1_50932 = _var_57124;

    /** parser.e:1592			if which_type = sequence_type or*/
    _28690 = (_which_type_57125 == _54sequence_type_46780);
    if (_28690 != 0) {
        goto L13; // [514] 553
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28692 = (object)*(((s1_ptr)_2)->base + _which_type_57125);
    _2 = (object)SEQ_PTR(_28692);
    _28693 = (object)*(((s1_ptr)_2)->base + 2LL);
    _28692 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_28693)){
        _28694 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28693)->dbl));
    }
    else{
        _28694 = (object)*(((s1_ptr)_2)->base + _28693);
    }
    _2 = (object)SEQ_PTR(_28694);
    _28695 = (object)*(((s1_ptr)_2)->base + 15LL);
    _28694 = NOVALUE;
    if (IS_ATOM_INT(_28695)) {
        _28696 = (_28695 == _54sequence_type_46780);
    }
    else {
        _28696 = binary_op(EQUALS, _28695, _54sequence_type_46780);
    }
    _28695 = NOVALUE;
    if (_28696 == 0) {
        DeRef(_28696);
        _28696 = NOVALUE;
        goto L14; // [549] 563
    }
    else {
        if (!IS_ATOM_INT(_28696) && DBL_PTR(_28696)->dbl == 0.0){
            DeRef(_28696);
            _28696 = NOVALUE;
            goto L14; // [549] 563
        }
        DeRef(_28696);
        _28696 = NOVALUE;
    }
    DeRef(_28696);
    _28696 = NOVALUE;
L13: 

    /** parser.e:1595				emit_op(SEQUENCE_CHECK)*/
    _47emit_op(97LL);
    goto L15; // [560] 619
L14: 

    /** parser.e:1597			elsif which_type = integer_type or*/
    _28697 = (_which_type_57125 == _54integer_type_46782);
    if (_28697 != 0) {
        goto L16; // [571] 610
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28699 = (object)*(((s1_ptr)_2)->base + _which_type_57125);
    _2 = (object)SEQ_PTR(_28699);
    _28700 = (object)*(((s1_ptr)_2)->base + 2LL);
    _28699 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_28700)){
        _28701 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28700)->dbl));
    }
    else{
        _28701 = (object)*(((s1_ptr)_2)->base + _28700);
    }
    _2 = (object)SEQ_PTR(_28701);
    _28702 = (object)*(((s1_ptr)_2)->base + 15LL);
    _28701 = NOVALUE;
    if (IS_ATOM_INT(_28702)) {
        _28703 = (_28702 == _54integer_type_46782);
    }
    else {
        _28703 = binary_op(EQUALS, _28702, _54integer_type_46782);
    }
    _28702 = NOVALUE;
    if (_28703 == 0) {
        DeRef(_28703);
        _28703 = NOVALUE;
        goto L17; // [606] 618
    }
    else {
        if (!IS_ATOM_INT(_28703) && DBL_PTR(_28703)->dbl == 0.0){
            DeRef(_28703);
            _28703 = NOVALUE;
            goto L17; // [606] 618
        }
        DeRef(_28703);
        _28703 = NOVALUE;
    }
    DeRef(_28703);
    _28703 = NOVALUE;
L16: 

    /** parser.e:1600				emit_op(INTEGER_CHECK)*/
    _47emit_op(96LL);
L17: 
L15: 
L12: 

    /** parser.e:1603	end procedure*/
    _28693 = NOVALUE;
    DeRef(_28697);
    _28697 = NOVALUE;
    _28664 = NOVALUE;
    _28684 = NOVALUE;
    DeRef(_28662);
    _28662 = NOVALUE;
    DeRef(_28667);
    _28667 = NOVALUE;
    _28700 = NOVALUE;
    DeRef(_28690);
    _28690 = NOVALUE;
    DeRef(_28651);
    _28651 = NOVALUE;
    return;
    ;
}


void _45Assignment(object _left_var_57289)
{
    object _tok_57291 = NOVALUE;
    object _subs_57292 = NOVALUE;
    object _slice_57293 = NOVALUE;
    object _assign_op_57294 = NOVALUE;
    object _subs1_patch_57295 = NOVALUE;
    object _dangerous_57297 = NOVALUE;
    object _lname_57422 = NOVALUE;
    object _temp_len_57441 = NOVALUE;
    object _28800 = NOVALUE;
    object _28799 = NOVALUE;
    object _28798 = NOVALUE;
    object _28797 = NOVALUE;
    object _28796 = NOVALUE;
    object _28795 = NOVALUE;
    object _28794 = NOVALUE;
    object _28785 = NOVALUE;
    object _28784 = NOVALUE;
    object _28783 = NOVALUE;
    object _28782 = NOVALUE;
    object _28781 = NOVALUE;
    object _28780 = NOVALUE;
    object _28779 = NOVALUE;
    object _28778 = NOVALUE;
    object _28777 = NOVALUE;
    object _28776 = NOVALUE;
    object _28775 = NOVALUE;
    object _28774 = NOVALUE;
    object _28773 = NOVALUE;
    object _28772 = NOVALUE;
    object _28771 = NOVALUE;
    object _28769 = NOVALUE;
    object _28768 = NOVALUE;
    object _28767 = NOVALUE;
    object _28765 = NOVALUE;
    object _28760 = NOVALUE;
    object _28759 = NOVALUE;
    object _28756 = NOVALUE;
    object _28755 = NOVALUE;
    object _28753 = NOVALUE;
    object _28747 = NOVALUE;
    object _28742 = NOVALUE;
    object _28739 = NOVALUE;
    object _28736 = NOVALUE;
    object _28733 = NOVALUE;
    object _28732 = NOVALUE;
    object _28731 = NOVALUE;
    object _28729 = NOVALUE;
    object _28728 = NOVALUE;
    object _28727 = NOVALUE;
    object _28726 = NOVALUE;
    object _28725 = NOVALUE;
    object _28724 = NOVALUE;
    object _28722 = NOVALUE;
    object _28721 = NOVALUE;
    object _28720 = NOVALUE;
    object _28719 = NOVALUE;
    object _28717 = NOVALUE;
    object _28716 = NOVALUE;
    object _28715 = NOVALUE;
    object _28714 = NOVALUE;
    object _28713 = NOVALUE;
    object _28711 = NOVALUE;
    object _28710 = NOVALUE;
    object _28709 = NOVALUE;
    object _28706 = NOVALUE;
    object _28705 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:1608		integer subs, slice, assign_op, subs1_patch*/

    /** parser.e:1611		left_sym = left_var[T_SYM]*/
    _2 = (object)SEQ_PTR(_left_var_57289);
    _45left_sym_54965 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_45left_sym_54965)){
        _45left_sym_54965 = (object)DBL_PTR(_45left_sym_54965)->dbl;
    }

    /** parser.e:1612		if SymTab[left_sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28705 = (object)*(((s1_ptr)_2)->base + _45left_sym_54965);
    _2 = (object)SEQ_PTR(_28705);
    _28706 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28705 = NOVALUE;
    if (binary_op_a(NOTEQ, _28706, 9LL)){
        _28706 = NOVALUE;
        goto L1; // [31] 54
    }
    _28706 = NOVALUE;

    /** parser.e:1613			Forward_var( left_var, ,ASSIGN )*/
    Ref(_left_var_57289);
    _45Forward_var(_left_var_57289, -1LL, 18LL);

    /** parser.e:1614			left_sym = Pop() -- pops off what forward var emitted, because it gets emitted later*/
    _0 = _47Pop();
    _45left_sym_54965 = _0;
    if (!IS_ATOM_INT(_45left_sym_54965)) {
        _1 = (object)(DBL_PTR(_45left_sym_54965)->dbl);
        DeRefDS(_45left_sym_54965);
        _45left_sym_54965 = _1;
    }
    goto L2; // [51] 271
L1: 

    /** parser.e:1616			UndefinedVar(left_sym)*/
    _45UndefinedVar(_45left_sym_54965);

    /** parser.e:1617			if SymTab[left_sym][S_SCOPE] = SC_LOOP_VAR or*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28709 = (object)*(((s1_ptr)_2)->base + _45left_sym_54965);
    _2 = (object)SEQ_PTR(_28709);
    _28710 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28709 = NOVALUE;
    if (IS_ATOM_INT(_28710)) {
        _28711 = (_28710 == 2LL);
    }
    else {
        _28711 = binary_op(EQUALS, _28710, 2LL);
    }
    _28710 = NOVALUE;
    if (IS_ATOM_INT(_28711)) {
        if (_28711 != 0) {
            goto L3; // [83] 112
        }
    }
    else {
        if (DBL_PTR(_28711)->dbl != 0.0) {
            goto L3; // [83] 112
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28713 = (object)*(((s1_ptr)_2)->base + _45left_sym_54965);
    _2 = (object)SEQ_PTR(_28713);
    _28714 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28713 = NOVALUE;
    if (IS_ATOM_INT(_28714)) {
        _28715 = (_28714 == 4LL);
    }
    else {
        _28715 = binary_op(EQUALS, _28714, 4LL);
    }
    _28714 = NOVALUE;
    if (_28715 == 0) {
        DeRef(_28715);
        _28715 = NOVALUE;
        goto L4; // [108] 124
    }
    else {
        if (!IS_ATOM_INT(_28715) && DBL_PTR(_28715)->dbl == 0.0){
            DeRef(_28715);
            _28715 = NOVALUE;
            goto L4; // [108] 124
        }
        DeRef(_28715);
        _28715 = NOVALUE;
    }
    DeRef(_28715);
    _28715 = NOVALUE;
L3: 

    /** parser.e:1619				CompileErr(MAY_NOT_ASSIGN_TO_A_FORLOOP_VARIABLE)*/
    RefDS(_21993);
    _50CompileErr(109LL, _21993, 0LL);
    goto L5; // [121] 233
L4: 

    /** parser.e:1621			elsif SymTab[left_sym][S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28716 = (object)*(((s1_ptr)_2)->base + _45left_sym_54965);
    _2 = (object)SEQ_PTR(_28716);
    _28717 = (object)*(((s1_ptr)_2)->base + 3LL);
    _28716 = NOVALUE;
    if (binary_op_a(NOTEQ, _28717, 2LL)){
        _28717 = NOVALUE;
        goto L6; // [142] 158
    }
    _28717 = NOVALUE;

    /** parser.e:1622				CompileErr(MAY_NOT_CHANGE_THE_VALUE_OF_A_CONSTANT)*/
    RefDS(_21993);
    _50CompileErr(110LL, _21993, 0LL);
    goto L5; // [155] 233
L6: 

    /** parser.e:1624			elsif find(SymTab[left_sym][S_SCOPE], SCOPE_TYPES) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28719 = (object)*(((s1_ptr)_2)->base + _45left_sym_54965);
    _2 = (object)SEQ_PTR(_28719);
    _28720 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28719 = NOVALUE;
    _28721 = find_from(_28720, _45SCOPE_TYPES_54915, 1LL);
    _28720 = NOVALUE;
    if (_28721 == 0)
    {
        _28721 = NOVALUE;
        goto L7; // [181] 232
    }
    else{
        _28721 = NOVALUE;
    }

    /** parser.e:1626				SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT],*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21447 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28724 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21447);
    _2 = (object)SEQ_PTR(_28724);
    _28725 = (object)*(((s1_ptr)_2)->base + 23LL);
    _28724 = NOVALUE;
    _28726 = (_45left_sym_54965 % 29LL);
    _28727 = power(2LL, _28726);
    _28726 = NOVALUE;
    if (IS_ATOM_INT(_28725) && IS_ATOM_INT(_28727)) {
        {uintptr_t tu;
             tu = (uintptr_t)_28725 | (uintptr_t)_28727;
             _28728 = MAKE_UINT(tu);
        }
    }
    else {
        _28728 = binary_op(OR_BITS, _28725, _28727);
    }
    _28725 = NOVALUE;
    DeRef(_28727);
    _28727 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _28728;
    if( _1 != _28728 ){
        DeRef(_1);
    }
    _28728 = NOVALUE;
    _28722 = NOVALUE;
L7: 
L5: 

    /** parser.e:1630			SymTab[left_sym][S_USAGE] = or_bits(SymTab[left_sym][S_USAGE], U_WRITTEN)*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_45left_sym_54965 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28731 = (object)*(((s1_ptr)_2)->base + _45left_sym_54965);
    _2 = (object)SEQ_PTR(_28731);
    _28732 = (object)*(((s1_ptr)_2)->base + 5LL);
    _28731 = NOVALUE;
    if (IS_ATOM_INT(_28732)) {
        {uintptr_t tu;
             tu = (uintptr_t)_28732 | (uintptr_t)2LL;
             _28733 = MAKE_UINT(tu);
        }
    }
    else {
        _28733 = binary_op(OR_BITS, _28732, 2LL);
    }
    _28732 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _28733;
    if( _1 != _28733 ){
        DeRef(_1);
    }
    _28733 = NOVALUE;
    _28729 = NOVALUE;
L2: 

    /** parser.e:1635		tok = next_token()*/
    _0 = _tok_57291;
    _tok_57291 = _45next_token();
    DeRef(_0);

    /** parser.e:1636		subs = 0*/
    _subs_57292 = 0LL;

    /** parser.e:1637		slice = FALSE*/
    _slice_57293 = _13FALSE_450;

    /** parser.e:1639		dangerous = FALSE*/
    _dangerous_57297 = _13FALSE_450;

    /** parser.e:1640		side_effect_calls = 0*/
    _45side_effect_calls_54961 = 0LL;

    /** parser.e:1643		emit_opnd(left_sym)*/
    _47emit_opnd(_45left_sym_54965);

    /** parser.e:1644		current_sequence = append(current_sequence, left_sym)*/
    Append(&_47current_sequence_50940, _47current_sequence_50940, _45left_sym_54965);

    /** parser.e:1646		while tok[T_ID] = LEFT_SQUARE do*/
L8: 
    _2 = (object)SEQ_PTR(_tok_57291);
    _28736 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28736, -28LL)){
        _28736 = NOVALUE;
        goto L9; // [334] 523
    }
    _28736 = NOVALUE;

    /** parser.e:1647			subs_depth += 1*/
    _45subs_depth_54966 = _45subs_depth_54966 + 1;

    /** parser.e:1648			if lhs_ptr then*/
    if (_47lhs_ptr_50942 == 0)
    {
        goto LA; // [350] 405
    }
    else{
    }

    /** parser.e:1650				current_sequence = remove( current_sequence, length( current_sequence ) )*/
    if (IS_SEQUENCE(_47current_sequence_50940)){
            _28739 = SEQ_PTR(_47current_sequence_50940)->length;
    }
    else {
        _28739 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_47current_sequence_50940);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_28739)) ? _28739 : (object)(DBL_PTR(_28739)->dbl);
        int stop = (IS_ATOM_INT(_28739)) ? _28739 : (object)(DBL_PTR(_28739)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_47current_sequence_50940), start, &_47current_sequence_50940 );
            }
            else Tail(SEQ_PTR(_47current_sequence_50940), stop+1, &_47current_sequence_50940);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_47current_sequence_50940), start, &_47current_sequence_50940);
        }
        else {
            assign_slice_seq = &assign_space;
            _47current_sequence_50940 = Remove_elements(start, stop, (SEQ_PTR(_47current_sequence_50940)->ref == 1));
        }
    }
    _28739 = NOVALUE;
    _28739 = NOVALUE;

    /** parser.e:1651				if subs = 1 then*/
    if (_subs_57292 != 1LL)
    goto LB; // [371] 396

    /** parser.e:1653					subs1_patch = length(Code)+1*/
    if (IS_SEQUENCE(_36Code_21531)){
            _28742 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _28742 = 1;
    }
    _subs1_patch_57295 = _28742 + 1;
    _28742 = NOVALUE;

    /** parser.e:1654					emit_op(LHS_SUBS1) -- creates new current_sequence*/
    _47emit_op(161LL);
    goto LC; // [393] 404
LB: 

    /** parser.e:1657					emit_op(LHS_SUBS) -- adds to current_sequence*/
    _47emit_op(95LL);
LC: 
LA: 

    /** parser.e:1660			subs += 1*/
    _subs_57292 = _subs_57292 + 1;

    /** parser.e:1661			if subs = 1 then*/
    if (_subs_57292 != 1LL)
    goto LD; // [413] 428

    /** parser.e:1662				InitCheck(left_sym, TRUE)*/
    _45InitCheck(_45left_sym_54965, _13TRUE_452);
LD: 

    /** parser.e:1664			Expr()*/
    _45Expr();

    /** parser.e:1665			tok = next_token()*/
    _0 = _tok_57291;
    _tok_57291 = _45next_token();
    DeRef(_0);

    /** parser.e:1666			if tok[T_ID] = SLICE then*/
    _2 = (object)SEQ_PTR(_tok_57291);
    _28747 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28747, 513LL)){
        _28747 = NOVALUE;
        goto LE; // [447] 484
    }
    _28747 = NOVALUE;

    /** parser.e:1667				Expr()*/
    _45Expr();

    /** parser.e:1668				slice = TRUE*/
    _slice_57293 = _13TRUE_452;

    /** parser.e:1669				tok_match(RIGHT_SQUARE)*/
    _45tok_match(-29LL, 0LL);

    /** parser.e:1670				tok = next_token()*/
    _0 = _tok_57291;
    _tok_57291 = _45next_token();
    DeRef(_0);

    /** parser.e:1671				exit  -- no further subs or slices allowed*/
    goto L9; // [479] 523
    goto LF; // [481] 506
LE: 

    /** parser.e:1673				putback(tok)*/
    Ref(_tok_57291);
    _45putback(_tok_57291);

    /** parser.e:1674				tok_match(RIGHT_SQUARE)*/
    _45tok_match(-29LL, 0LL);

    /** parser.e:1675				subs_depth -= 1*/
    _45subs_depth_54966 = _45subs_depth_54966 - 1LL;
LF: 

    /** parser.e:1677			tok = next_token()*/
    _0 = _tok_57291;
    _tok_57291 = _45next_token();
    DeRef(_0);

    /** parser.e:1678			lhs_ptr = TRUE*/
    _47lhs_ptr_50942 = _13TRUE_452;

    /** parser.e:1679		end while*/
    goto L8; // [520] 326
L9: 

    /** parser.e:1681		lhs_ptr = FALSE*/
    _47lhs_ptr_50942 = _13FALSE_450;

    /** parser.e:1683		assign_op = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57291);
    _assign_op_57294 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_assign_op_57294)){
        _assign_op_57294 = (object)DBL_PTR(_assign_op_57294)->dbl;
    }

    /** parser.e:1684		if not find(assign_op, ASSIGN_OPS) then*/
    _28753 = find_from(_assign_op_57294, _45ASSIGN_OPS_54907, 1LL);
    if (_28753 != 0)
    goto L10; // [549] 613
    _28753 = NOVALUE;

    /** parser.e:1685			sequence lname = SymTab[left_var[T_SYM]][S_NAME]*/
    _2 = (object)SEQ_PTR(_left_var_57289);
    _28755 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_28755)){
        _28756 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28755)->dbl));
    }
    else{
        _28756 = (object)*(((s1_ptr)_2)->base + _28755);
    }
    DeRef(_lname_57422);
    _2 = (object)SEQ_PTR(_28756);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _lname_57422 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _lname_57422 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    Ref(_lname_57422);
    _28756 = NOVALUE;

    /** parser.e:1686			if assign_op = COLON then*/
    if (_assign_op_57294 != -23LL)
    goto L11; // [578] 598

    /** parser.e:1687				CompileErr(SYNTAX_ERROR__UNKNOWN_NAMESPACE_1_USED, {lname})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_lname_57422);
    ((intptr_t*)_2)[1] = _lname_57422;
    _28759 = MAKE_SEQ(_1);
    _50CompileErr(133LL, _28759, 0LL);
    _28759 = NOVALUE;
    goto L12; // [595] 612
L11: 

    /** parser.e:1689				CompileErr(EXPECTED_TO_SEE_AN_ASSIGNMENT_AFTER_1_SUCH_AS__OR, {lname})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_lname_57422);
    ((intptr_t*)_2)[1] = _lname_57422;
    _28760 = MAKE_SEQ(_1);
    _50CompileErr(76LL, _28760, 0LL);
    _28760 = NOVALUE;
L12: 
L10: 
    DeRef(_lname_57422);
    _lname_57422 = NOVALUE;

    /** parser.e:1693		if subs = 0 then*/
    if (_subs_57292 != 0LL)
    goto L13; // [617] 745

    /** parser.e:1695			integer temp_len = length(Code)*/
    if (IS_SEQUENCE(_36Code_21531)){
            _temp_len_57441 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _temp_len_57441 = 1;
    }

    /** parser.e:1696			if assign_op = EQUALS then*/
    if (_assign_op_57294 != 3LL)
    goto L14; // [632] 653

    /** parser.e:1697				Expr() -- RHS expression*/
    _45Expr();

    /** parser.e:1698				InitCheck(left_sym, FALSE)*/
    _45InitCheck(_45left_sym_54965, _13FALSE_450);
    goto L15; // [650] 726
L14: 

    /** parser.e:1700				InitCheck(left_sym, TRUE)*/
    _45InitCheck(_45left_sym_54965, _13TRUE_452);

    /** parser.e:1701				if left_sym > 0 then*/
    if (_45left_sym_54965 <= 0LL)
    goto L16; // [667] 709

    /** parser.e:1702					SymTab[left_sym][S_USAGE] = or_bits(SymTab[left_sym][S_USAGE], U_READ)*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_45left_sym_54965 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28767 = (object)*(((s1_ptr)_2)->base + _45left_sym_54965);
    _2 = (object)SEQ_PTR(_28767);
    _28768 = (object)*(((s1_ptr)_2)->base + 5LL);
    _28767 = NOVALUE;
    if (IS_ATOM_INT(_28768)) {
        {uintptr_t tu;
             tu = (uintptr_t)_28768 | (uintptr_t)1LL;
             _28769 = MAKE_UINT(tu);
        }
    }
    else {
        _28769 = binary_op(OR_BITS, _28768, 1LL);
    }
    _28768 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _28769;
    if( _1 != _28769 ){
        DeRef(_1);
    }
    _28769 = NOVALUE;
    _28765 = NOVALUE;
L16: 

    /** parser.e:1704				emit_opnd(left_sym)*/
    _47emit_opnd(_45left_sym_54965);

    /** parser.e:1705				Expr() -- RHS expression*/
    _45Expr();

    /** parser.e:1706				emit_assign_op(assign_op)*/
    _47emit_assign_op(_assign_op_57294);
L15: 

    /** parser.e:1708			emit_op(ASSIGN)*/
    _47emit_op(18LL);

    /** parser.e:1709			TypeCheck(left_sym)*/
    _45TypeCheck(_45left_sym_54965);
    goto L17; // [742] 1169
L13: 

    /** parser.e:1712			factors = 0*/
    _45factors_54962 = 0LL;

    /** parser.e:1713			lhs_subs_level = -1*/
    _45lhs_subs_level_54963 = -1LL;

    /** parser.e:1714			Expr() -- RHS expression*/
    _45Expr();

    /** parser.e:1716			if subs > 1 then*/
    if (_subs_57292 <= 1LL)
    goto L18; // [761] 900

    /** parser.e:1717				if left_sym < 0 or SymTab[left_sym][S_SCOPE] != SC_PRIVATE and*/
    _28771 = (_45left_sym_54965 < 0LL);
    if (_28771 != 0) {
        _28772 = 1;
        goto L19; // [773] 801
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28773 = (object)*(((s1_ptr)_2)->base + _45left_sym_54965);
    _2 = (object)SEQ_PTR(_28773);
    _28774 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28773 = NOVALUE;
    if (IS_ATOM_INT(_28774)) {
        _28775 = (_28774 != 3LL);
    }
    else {
        _28775 = binary_op(NOTEQ, _28774, 3LL);
    }
    _28774 = NOVALUE;
    if (IS_ATOM_INT(_28775))
    _28772 = (_28775 != 0);
    else
    _28772 = DBL_PTR(_28775)->dbl != 0.0;
L19: 
    if (_28772 == 0) {
        goto L1A; // [801] 835
    }
    _28777 = (_45left_sym_54965 % 29LL);
    _28778 = power(2LL, _28777);
    _28777 = NOVALUE;
    if (IS_ATOM_INT(_28778)) {
        {uintptr_t tu;
             tu = (uintptr_t)_45side_effect_calls_54961 & (uintptr_t)_28778;
             _28779 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (eudouble)_45side_effect_calls_54961;
        _28779 = Dand_bits(&temp_d, DBL_PTR(_28778));
    }
    DeRef(_28778);
    _28778 = NOVALUE;
    if (_28779 == 0) {
        DeRef(_28779);
        _28779 = NOVALUE;
        goto L1A; // [824] 835
    }
    else {
        if (!IS_ATOM_INT(_28779) && DBL_PTR(_28779)->dbl == 0.0){
            DeRef(_28779);
            _28779 = NOVALUE;
            goto L1A; // [824] 835
        }
        DeRef(_28779);
        _28779 = NOVALUE;
    }
    DeRef(_28779);
    _28779 = NOVALUE;

    /** parser.e:1722					dangerous = TRUE*/
    _dangerous_57297 = _13TRUE_452;
L1A: 

    /** parser.e:1725				if factors = 1 and*/
    _28780 = (_45factors_54962 == 1LL);
    if (_28780 == 0) {
        _28781 = 0;
        goto L1B; // [843] 857
    }
    _28782 = (_45lhs_subs_level_54963 >= 0LL);
    _28781 = (_28782 != 0);
L1B: 
    if (_28781 == 0) {
        goto L1C; // [857] 883
    }
    _28784 = _subs_57292 + _slice_57293;
    if ((object)((uintptr_t)_28784 + (uintptr_t)HIGH_BITS) >= 0){
        _28784 = NewDouble((eudouble)_28784);
    }
    if (IS_ATOM_INT(_28784)) {
        _28785 = (_45lhs_subs_level_54963 < _28784);
    }
    else {
        _28785 = ((eudouble)_45lhs_subs_level_54963 < DBL_PTR(_28784)->dbl);
    }
    DeRef(_28784);
    _28784 = NOVALUE;
    if (_28785 == 0)
    {
        DeRef(_28785);
        _28785 = NOVALUE;
        goto L1C; // [872] 883
    }
    else{
        DeRef(_28785);
        _28785 = NOVALUE;
    }

    /** parser.e:1729					dangerous = TRUE*/
    _dangerous_57297 = _13TRUE_452;
L1C: 

    /** parser.e:1732				if dangerous then*/
    if (_dangerous_57297 == 0)
    {
        goto L1D; // [885] 899
    }
    else{
    }

    /** parser.e:1738					backpatch(subs1_patch, LHS_SUBS1_COPY)*/
    _47backpatch(_subs1_patch_57295, 166LL);
L1D: 
L18: 

    /** parser.e:1742			if slice then*/
    if (_slice_57293 == 0)
    {
        goto L1E; // [902] 970
    }
    else{
    }

    /** parser.e:1743				if assign_op != EQUALS then*/
    if (_assign_op_57294 == 3LL)
    goto L1F; // [909] 943

    /** parser.e:1744					if subs = 1 then*/
    if (_subs_57292 != 1LL)
    goto L20; // [915] 929

    /** parser.e:1745						emit_op(ASSIGN_OP_SLICE)*/
    _47emit_op(150LL);
    goto L21; // [926] 937
L20: 

    /** parser.e:1747						emit_op(PASSIGN_OP_SLICE)*/
    _47emit_op(165LL);
L21: 

    /** parser.e:1749					emit_assign_op(assign_op)*/
    _47emit_assign_op(_assign_op_57294);
L1F: 

    /** parser.e:1751				if subs = 1 then*/
    if (_subs_57292 != 1LL)
    goto L22; // [945] 959

    /** parser.e:1752					emit_op(ASSIGN_SLICE)*/
    _47emit_op(45LL);
    goto L23; // [956] 1060
L22: 

    /** parser.e:1754					emit_op(PASSIGN_SLICE)*/
    _47emit_op(163LL);
    goto L23; // [967] 1060
L1E: 

    /** parser.e:1757				if assign_op = EQUALS then*/
    if (_assign_op_57294 != 3LL)
    goto L24; // [974] 1005

    /** parser.e:1758					if subs = 1 then*/
    if (_subs_57292 != 1LL)
    goto L25; // [980] 994

    /** parser.e:1759						emit_op(ASSIGN_SUBS)*/
    _47emit_op(16LL);
    goto L26; // [991] 1059
L25: 

    /** parser.e:1761						emit_op(PASSIGN_SUBS)*/
    _47emit_op(162LL);
    goto L26; // [1002] 1059
L24: 

    /** parser.e:1764					if subs = 1 then*/
    if (_subs_57292 != 1LL)
    goto L27; // [1007] 1021

    /** parser.e:1765						emit_op(ASSIGN_OP_SUBS)*/
    _47emit_op(149LL);
    goto L28; // [1018] 1029
L27: 

    /** parser.e:1767						emit_op(PASSIGN_OP_SUBS)*/
    _47emit_op(164LL);
L28: 

    /** parser.e:1769					emit_assign_op(assign_op)*/
    _47emit_assign_op(_assign_op_57294);

    /** parser.e:1770					if subs = 1 then*/
    if (_subs_57292 != 1LL)
    goto L29; // [1036] 1050

    /** parser.e:1771						emit_op(ASSIGN_SUBS2)*/
    _47emit_op(148LL);
    goto L2A; // [1047] 1058
L29: 

    /** parser.e:1773						emit_op(PASSIGN_SUBS)*/
    _47emit_op(162LL);
L2A: 
L26: 
L23: 

    /** parser.e:1778			if subs > 1 then*/
    if (_subs_57292 <= 1LL)
    goto L2B; // [1062] 1114

    /** parser.e:1779				if dangerous then*/
    if (_dangerous_57297 == 0)
    {
        goto L2C; // [1068] 1105
    }
    else{
    }

    /** parser.e:1781					emit_opnd(left_sym)*/
    _47emit_opnd(_45left_sym_54965);

    /** parser.e:1782					emit_opnd(lhs_subs1_copy_temp) -- will be freed*/
    _47emit_opnd(_47lhs_subs1_copy_temp_50945);

    /** parser.e:1783					emit_temp( lhs_subs1_copy_temp, NEW_REFERENCE )*/
    _47emit_temp(_47lhs_subs1_copy_temp_50945, 1LL);

    /** parser.e:1784					emit_op(ASSIGN)*/
    _47emit_op(18LL);
    goto L2D; // [1102] 1113
L2C: 

    /** parser.e:1787					TempFree(lhs_subs1_copy_temp)*/
    _47TempFree(_47lhs_subs1_copy_temp_50945);
L2D: 
L2B: 

    /** parser.e:1791			if OpTypeCheck and (left_sym < 0 or SymTab[left_sym][S_VTYPE] != sequence_type) then*/
    if (_36OpTypeCheck_21513 == 0) {
        goto L2E; // [1118] 1168
    }
    _28795 = (_45left_sym_54965 < 0LL);
    if (_28795 != 0) {
        DeRef(_28796);
        _28796 = 1;
        goto L2F; // [1128] 1156
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28797 = (object)*(((s1_ptr)_2)->base + _45left_sym_54965);
    _2 = (object)SEQ_PTR(_28797);
    _28798 = (object)*(((s1_ptr)_2)->base + 15LL);
    _28797 = NOVALUE;
    if (IS_ATOM_INT(_28798)) {
        _28799 = (_28798 != _54sequence_type_46780);
    }
    else {
        _28799 = binary_op(NOTEQ, _28798, _54sequence_type_46780);
    }
    _28798 = NOVALUE;
    if (IS_ATOM_INT(_28799))
    _28796 = (_28799 != 0);
    else
    _28796 = DBL_PTR(_28799)->dbl != 0.0;
L2F: 
    if (_28796 == 0)
    {
        _28796 = NOVALUE;
        goto L2E; // [1157] 1168
    }
    else{
        _28796 = NOVALUE;
    }

    /** parser.e:1792				TypeCheck(left_sym)*/
    _45TypeCheck(_45left_sym_54965);
L2E: 
L17: 

    /** parser.e:1796		current_sequence = remove( current_sequence, length( current_sequence ) )*/
    if (IS_SEQUENCE(_47current_sequence_50940)){
            _28800 = SEQ_PTR(_47current_sequence_50940)->length;
    }
    else {
        _28800 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_47current_sequence_50940);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_28800)) ? _28800 : (object)(DBL_PTR(_28800)->dbl);
        int stop = (IS_ATOM_INT(_28800)) ? _28800 : (object)(DBL_PTR(_28800)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_47current_sequence_50940), start, &_47current_sequence_50940 );
            }
            else Tail(SEQ_PTR(_47current_sequence_50940), stop+1, &_47current_sequence_50940);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_47current_sequence_50940), start, &_47current_sequence_50940);
        }
        else {
            assign_slice_seq = &assign_space;
            _47current_sequence_50940 = Remove_elements(start, stop, (SEQ_PTR(_47current_sequence_50940)->ref == 1));
        }
    }
    _28800 = NOVALUE;
    _28800 = NOVALUE;

    /** parser.e:1798		if not TRANSLATE then*/
    if (_36TRANSLATE_21041 != 0)
    goto L30; // [1189] 1215

    /** parser.e:1799			if OpTrace then*/
    if (_36OpTrace_21512 == 0)
    {
        goto L31; // [1196] 1214
    }
    else{
    }

    /** parser.e:1800				emit_op(DISPLAY_VAR)*/
    _47emit_op(87LL);

    /** parser.e:1801				emit_addr(left_sym)*/
    _47emit_addr(_45left_sym_54965);
L31: 
L30: 

    /** parser.e:1804	end procedure*/
    DeRef(_left_var_57289);
    DeRef(_tok_57291);
    DeRef(_28711);
    _28711 = NOVALUE;
    DeRef(_28782);
    _28782 = NOVALUE;
    DeRef(_28795);
    _28795 = NOVALUE;
    DeRef(_28771);
    _28771 = NOVALUE;
    DeRef(_28799);
    _28799 = NOVALUE;
    _28755 = NOVALUE;
    DeRef(_28775);
    _28775 = NOVALUE;
    DeRef(_28780);
    _28780 = NOVALUE;
    return;
    ;
}


void _45Multi_assign()
{
    object _lhs_syms_57581 = NOVALUE;
    object _lhs_list_57582 = NOVALUE;
    object _tok_57584 = NOVALUE;
    object _need_comma_57585 = NOVALUE;
    object _temp_sym_57647 = NOVALUE;
    object _temps_57650 = NOVALUE;
    object _len_57698 = NOVALUE;
    object _28859 = NOVALUE;
    object _28857 = NOVALUE;
    object _28855 = NOVALUE;
    object _28853 = NOVALUE;
    object _28852 = NOVALUE;
    object _28851 = NOVALUE;
    object _28850 = NOVALUE;
    object _28849 = NOVALUE;
    object _28848 = NOVALUE;
    object _28846 = NOVALUE;
    object _28845 = NOVALUE;
    object _28844 = NOVALUE;
    object _28843 = NOVALUE;
    object _28842 = NOVALUE;
    object _28840 = NOVALUE;
    object _28839 = NOVALUE;
    object _28838 = NOVALUE;
    object _28837 = NOVALUE;
    object _28836 = NOVALUE;
    object _28832 = NOVALUE;
    object _28831 = NOVALUE;
    object _28830 = NOVALUE;
    object _28829 = NOVALUE;
    object _28826 = NOVALUE;
    object _28825 = NOVALUE;
    object _28823 = NOVALUE;
    object _28822 = NOVALUE;
    object _28821 = NOVALUE;
    object _28819 = NOVALUE;
    object _28818 = NOVALUE;
    object _28817 = NOVALUE;
    object _28816 = NOVALUE;
    object _28814 = NOVALUE;
    object _28813 = NOVALUE;
    object _28812 = NOVALUE;
    object _28810 = NOVALUE;
    object _28809 = NOVALUE;
    object _28806 = NOVALUE;
    object _28803 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:1811		sequence lhs_syms = {}*/
    RefDS(_21993);
    DeRef(_lhs_syms_57581);
    _lhs_syms_57581 = _21993;

    /** parser.e:1812		sequence lhs_list = {} -- make sure we don't repeat anything*/
    RefDS(_21993);
    DeRef(_lhs_list_57582);
    _lhs_list_57582 = _21993;

    /** parser.e:1814		integer need_comma = 0*/
    _need_comma_57585 = 0LL;

    /** parser.e:1815		while tok[T_ID] != RIGHT_BRACE with entry do*/
    goto L1; // [22] 215
L2: 
    _2 = (object)SEQ_PTR(_tok_57584);
    _28803 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _28803, -25LL)){
        _28803 = NOVALUE;
        goto L3; // [35] 225
    }
    _28803 = NOVALUE;

    /** parser.e:1817			if need_comma then*/
    if (_need_comma_57585 == 0)
    {
        goto L4; // [41] 63
    }
    else{
    }

    /** parser.e:1818				putback( tok )*/
    Ref(_tok_57584);
    _45putback(_tok_57584);

    /** parser.e:1819				tok_match( COMMA )*/
    _45tok_match(-30LL, 0LL);

    /** parser.e:1820				tok = next_token()*/
    _0 = _tok_57584;
    _tok_57584 = _45next_token();
    DeRef(_0);
L4: 

    /** parser.e:1823			if tok[T_ID] = QUESTION_MARK then*/
    _2 = (object)SEQ_PTR(_tok_57584);
    _28806 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28806, -31LL)){
        _28806 = NOVALUE;
        goto L5; // [73] 86
    }
    _28806 = NOVALUE;

    /** parser.e:1825				lhs_syms &= 0*/
    Append(&_lhs_syms_57581, _lhs_syms_57581, 0LL);
    goto L6; // [83] 207
L5: 

    /** parser.e:1826			elsif tok[T_ID] = VARIABLE or tok[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_57584);
    _28809 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28809)) {
        _28810 = (_28809 == -100LL);
    }
    else {
        _28810 = binary_op(EQUALS, _28809, -100LL);
    }
    _28809 = NOVALUE;
    if (IS_ATOM_INT(_28810)) {
        if (_28810 != 0) {
            goto L7; // [100] 121
        }
    }
    else {
        if (DBL_PTR(_28810)->dbl != 0.0) {
            goto L7; // [100] 121
        }
    }
    _2 = (object)SEQ_PTR(_tok_57584);
    _28812 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_28812)) {
        _28813 = (_28812 == 512LL);
    }
    else {
        _28813 = binary_op(EQUALS, _28812, 512LL);
    }
    _28812 = NOVALUE;
    if (_28813 == 0) {
        DeRef(_28813);
        _28813 = NOVALUE;
        goto L8; // [117] 197
    }
    else {
        if (!IS_ATOM_INT(_28813) && DBL_PTR(_28813)->dbl == 0.0){
            DeRef(_28813);
            _28813 = NOVALUE;
            goto L8; // [117] 197
        }
        DeRef(_28813);
        _28813 = NOVALUE;
    }
    DeRef(_28813);
    _28813 = NOVALUE;
L7: 

    /** parser.e:1827				lhs_syms &= tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_57584);
    _28814 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_SEQUENCE(_lhs_syms_57581) && IS_ATOM(_28814)) {
        Ref(_28814);
        Append(&_lhs_syms_57581, _lhs_syms_57581, _28814);
    }
    else if (IS_ATOM(_lhs_syms_57581) && IS_SEQUENCE(_28814)) {
    }
    else {
        Concat((object_ptr)&_lhs_syms_57581, _lhs_syms_57581, _28814);
    }
    _28814 = NOVALUE;

    /** parser.e:1828				if SymTab[lhs_syms[$]][S_SCOPE] = SC_UNDEFINED then*/
    if (IS_SEQUENCE(_lhs_syms_57581)){
            _28816 = SEQ_PTR(_lhs_syms_57581)->length;
    }
    else {
        _28816 = 1;
    }
    _2 = (object)SEQ_PTR(_lhs_syms_57581);
    _28817 = (object)*(((s1_ptr)_2)->base + _28816);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_28817)){
        _28818 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28817)->dbl));
    }
    else{
        _28818 = (object)*(((s1_ptr)_2)->base + _28817);
    }
    _2 = (object)SEQ_PTR(_28818);
    _28819 = (object)*(((s1_ptr)_2)->base + 4LL);
    _28818 = NOVALUE;
    if (binary_op_a(NOTEQ, _28819, 9LL)){
        _28819 = NOVALUE;
        goto L9; // [156] 180
    }
    _28819 = NOVALUE;

    /** parser.e:1829					lhs_list = append( lhs_list, sym_name( lhs_syms[$] ) )*/
    if (IS_SEQUENCE(_lhs_syms_57581)){
            _28821 = SEQ_PTR(_lhs_syms_57581)->length;
    }
    else {
        _28821 = 1;
    }
    _2 = (object)SEQ_PTR(_lhs_syms_57581);
    _28822 = (object)*(((s1_ptr)_2)->base + _28821);
    Ref(_28822);
    _28823 = _54sym_name(_28822);
    _28822 = NOVALUE;
    Ref(_28823);
    Append(&_lhs_list_57582, _lhs_list_57582, _28823);
    DeRef(_28823);
    _28823 = NOVALUE;
    goto L6; // [177] 207
L9: 

    /** parser.e:1831					lhs_list &= lhs_syms[$]*/
    if (IS_SEQUENCE(_lhs_syms_57581)){
            _28825 = SEQ_PTR(_lhs_syms_57581)->length;
    }
    else {
        _28825 = 1;
    }
    _2 = (object)SEQ_PTR(_lhs_syms_57581);
    _28826 = (object)*(((s1_ptr)_2)->base + _28825);
    if (IS_SEQUENCE(_lhs_list_57582) && IS_ATOM(_28826)) {
        Ref(_28826);
        Append(&_lhs_list_57582, _lhs_list_57582, _28826);
    }
    else if (IS_ATOM(_lhs_list_57582) && IS_SEQUENCE(_28826)) {
    }
    else {
        Concat((object_ptr)&_lhs_list_57582, _lhs_list_57582, _28826);
    }
    _28826 = NOVALUE;
    goto L6; // [194] 207
L8: 

    /** parser.e:1834				CompileErr( A_VARIABLE_NAME_IS_EXPECTED_HERE)*/
    RefDS(_21993);
    _50CompileErr(24LL, _21993, 0LL);
L6: 

    /** parser.e:1837			need_comma = 1*/
    _need_comma_57585 = 1LL;

    /** parser.e:1838		entry*/
L1: 

    /** parser.e:1839			tok = next_token()*/
    _0 = _tok_57584;
    _tok_57584 = _45next_token();
    DeRef(_0);

    /** parser.e:1840		end while*/
    goto L2; // [222] 25
L3: 

    /** parser.e:1843		if length( lhs_list ) != length( remove_dups( sort( lhs_list ) ) ) then*/
    if (IS_SEQUENCE(_lhs_list_57582)){
            _28829 = SEQ_PTR(_lhs_list_57582)->length;
    }
    else {
        _28829 = 1;
    }
    RefDS(_lhs_list_57582);
    _28830 = _24sort(_lhs_list_57582, 1LL);
    _28831 = _23remove_dups(_28830, 2LL);
    _28830 = NOVALUE;
    if (IS_SEQUENCE(_28831)){
            _28832 = SEQ_PTR(_28831)->length;
    }
    else {
        _28832 = 1;
    }
    DeRef(_28831);
    _28831 = NOVALUE;
    if (_28829 == _28832)
    goto LA; // [243] 257

    /** parser.e:1844			CompileErr( DUPLICATE_MULTI_ASSIGN )*/
    RefDS(_21993);
    _50CompileErr(602LL, _21993, 0LL);
LA: 

    /** parser.e:1846		tok_match( EQUALS )*/
    _45tok_match(3LL, 0LL);

    /** parser.e:1849		Expr()*/
    _45Expr();

    /** parser.e:1851		symtab_index temp_sym = Pop()*/
    _temp_sym_57647 = _47Pop();
    if (!IS_ATOM_INT(_temp_sym_57647)) {
        _1 = (object)(DBL_PTR(_temp_sym_57647)->dbl);
        DeRefDS(_temp_sym_57647);
        _temp_sym_57647 = _1;
    }

    /** parser.e:1852		sequence temps = pop_temps()*/
    _0 = _temps_57650;
    _temps_57650 = _47pop_temps();
    DeRef(_0);

    /** parser.e:1853		if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto LB; // [287] 303
    }
    else{
    }

    /** parser.e:1854			emit_opnd( temp_sym )*/
    _47emit_opnd(_temp_sym_57647);

    /** parser.e:1855			emit_op( REF_TEMP )*/
    _47emit_op(207LL);
LB: 

    /** parser.e:1858		for i = 1 to length( lhs_syms ) do*/
    if (IS_SEQUENCE(_lhs_syms_57581)){
            _28836 = SEQ_PTR(_lhs_syms_57581)->length;
    }
    else {
        _28836 = 1;
    }
    {
        object _i_57659;
        _i_57659 = 1LL;
LC: 
        if (_i_57659 > _28836){
            goto LD; // [308] 512
        }

        /** parser.e:1859			if lhs_syms[i] then*/
        _2 = (object)SEQ_PTR(_lhs_syms_57581);
        _28837 = (object)*(((s1_ptr)_2)->base + _i_57659);
        if (_28837 == 0) {
            _28837 = NOVALUE;
            goto LE; // [321] 503
        }
        else {
            if (!IS_ATOM_INT(_28837) && DBL_PTR(_28837)->dbl == 0.0){
                _28837 = NOVALUE;
                goto LE; // [321] 503
            }
            _28837 = NOVALUE;
        }
        _28837 = NOVALUE;

        /** parser.e:1860				if SymTab[lhs_syms[i]][S_SCOPE] = SC_UNDEFINED then*/
        _2 = (object)SEQ_PTR(_lhs_syms_57581);
        _28838 = (object)*(((s1_ptr)_2)->base + _i_57659);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!IS_ATOM_INT(_28838)){
            _28839 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28838)->dbl));
        }
        else{
            _28839 = (object)*(((s1_ptr)_2)->base + _28838);
        }
        _2 = (object)SEQ_PTR(_28839);
        _28840 = (object)*(((s1_ptr)_2)->base + 4LL);
        _28839 = NOVALUE;
        if (binary_op_a(NOTEQ, _28840, 9LL)){
            _28840 = NOVALUE;
            goto LF; // [344] 379
        }
        _28840 = NOVALUE;

        /** parser.e:1861					Forward_var( { VARIABLE, lhs_syms[i]}, ,ASSIGN )*/
        _2 = (object)SEQ_PTR(_lhs_syms_57581);
        _28842 = (object)*(((s1_ptr)_2)->base + _i_57659);
        Ref(_28842);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -100LL;
        ((intptr_t *)_2)[2] = _28842;
        _28843 = MAKE_SEQ(_1);
        _28842 = NOVALUE;
        _45Forward_var(_28843, -1LL, 18LL);
        _28843 = NOVALUE;

        /** parser.e:1862					lhs_syms[i] = Pop()*/
        _28844 = _47Pop();
        _2 = (object)SEQ_PTR(_lhs_syms_57581);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _lhs_syms_57581 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_57659);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _28844;
        if( _1 != _28844 ){
            DeRef(_1);
        }
        _28844 = NOVALUE;
        goto L10; // [376] 421
LF: 

        /** parser.e:1864					SymTab[lhs_syms[i]][S_USAGE] = or_bits(SymTab[lhs_syms[i]][S_USAGE], U_WRITTEN)*/
        _2 = (object)SEQ_PTR(_lhs_syms_57581);
        _28845 = (object)*(((s1_ptr)_2)->base + _i_57659);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_28845))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_28845)->dbl));
        else
        _3 = (object)(_28845 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_lhs_syms_57581);
        _28848 = (object)*(((s1_ptr)_2)->base + _i_57659);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!IS_ATOM_INT(_28848)){
            _28849 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28848)->dbl));
        }
        else{
            _28849 = (object)*(((s1_ptr)_2)->base + _28848);
        }
        _2 = (object)SEQ_PTR(_28849);
        _28850 = (object)*(((s1_ptr)_2)->base + 5LL);
        _28849 = NOVALUE;
        if (IS_ATOM_INT(_28850)) {
            {uintptr_t tu;
                 tu = (uintptr_t)_28850 | (uintptr_t)2LL;
                 _28851 = MAKE_UINT(tu);
            }
        }
        else {
            _28851 = binary_op(OR_BITS, _28850, 2LL);
        }
        _28850 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _28851;
        if( _1 != _28851 ){
            DeRef(_1);
        }
        _28851 = NOVALUE;
        _28846 = NOVALUE;
L10: 

        /** parser.e:1867				emit_opnd( lhs_syms[i] )*/
        _2 = (object)SEQ_PTR(_lhs_syms_57581);
        _28852 = (object)*(((s1_ptr)_2)->base + _i_57659);
        Ref(_28852);
        _47emit_opnd(_28852);
        _28852 = NOVALUE;

        /** parser.e:1869				emit_opnd( temp_sym )*/
        _47emit_opnd(_temp_sym_57647);

        /** parser.e:1870				emit_opnd( NewIntSym( i ) )*/
        _28853 = _54NewIntSym(_i_57659);
        _47emit_opnd(_28853);
        _28853 = NOVALUE;

        /** parser.e:1871				emit_op( RHS_SUBS )*/
        _47emit_op(25LL);

        /** parser.e:1872				integer len = length( Code )*/
        if (IS_SEQUENCE(_36Code_21531)){
                _len_57698 = SEQ_PTR(_36Code_21531)->length;
        }
        else {
            _len_57698 = 1;
        }

        /** parser.e:1873				if Code[len] = temp_sym then*/
        _2 = (object)SEQ_PTR(_36Code_21531);
        _28855 = (object)*(((s1_ptr)_2)->base + _len_57698);
        if (binary_op_a(NOTEQ, _28855, _temp_sym_57647)){
            _28855 = NOVALUE;
            goto L11; // [466] 486
        }
        _28855 = NOVALUE;

        /** parser.e:1875					Code = remove( Code, len - 1, len )*/
        _28857 = _len_57698 - 1LL;
        {
            s1_ptr assign_space = SEQ_PTR(_36Code_21531);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_28857)) ? _28857 : (object)(DBL_PTR(_28857)->dbl);
            int stop = (IS_ATOM_INT(_len_57698)) ? _len_57698 : (object)(DBL_PTR(_len_57698)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_36Code_21531), start, &_36Code_21531 );
                }
                else Tail(SEQ_PTR(_36Code_21531), stop+1, &_36Code_21531);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_36Code_21531), start, &_36Code_21531);
            }
            else {
                assign_slice_seq = &assign_space;
                _36Code_21531 = Remove_elements(start, stop, (SEQ_PTR(_36Code_21531)->ref == 1));
            }
        }
        _28857 = NOVALUE;
L11: 

        /** parser.e:1877				emit_op( ASSIGN )*/
        _47emit_op(18LL);

        /** parser.e:1879				TypeCheck( lhs_syms[i] )*/
        _2 = (object)SEQ_PTR(_lhs_syms_57581);
        _28859 = (object)*(((s1_ptr)_2)->base + _i_57659);
        Ref(_28859);
        _45TypeCheck(_28859);
        _28859 = NOVALUE;
LE: 

        /** parser.e:1882		end for*/
        _i_57659 = _i_57659 + 1LL;
        goto LC; // [507] 315
LD: 
        ;
    }

    /** parser.e:1884		push_temps( temps )*/
    RefDS(_temps_57650);
    _47push_temps(_temps_57650);

    /** parser.e:1885		flush_temps()*/
    RefDS(_21993);
    _47flush_temps(_21993);

    /** parser.e:1887		if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L12; // [526] 542
    }
    else{
    }

    /** parser.e:1888			emit_opnd( temp_sym )*/
    _47emit_opnd(_temp_sym_57647);

    /** parser.e:1889			emit_op( DEREF_TEMP )*/
    _47emit_op(208LL);
L12: 

    /** parser.e:1891	end procedure*/
    DeRef(_lhs_syms_57581);
    DeRef(_lhs_list_57582);
    DeRef(_tok_57584);
    DeRef(_temps_57650);
    _28817 = NOVALUE;
    _28831 = NOVALUE;
    _28838 = NOVALUE;
    DeRef(_28810);
    _28810 = NOVALUE;
    _28848 = NOVALUE;
    _28845 = NOVALUE;
    return;
    ;
}


void _45Return_statement()
{
    object _tok_57722 = NOVALUE;
    object _pop_57723 = NOVALUE;
    object _last_op_57730 = NOVALUE;
    object _last_pc_57733 = NOVALUE;
    object _is_tail_57736 = NOVALUE;
    object _28891 = NOVALUE;
    object _28889 = NOVALUE;
    object _28888 = NOVALUE;
    object _28887 = NOVALUE;
    object _28886 = NOVALUE;
    object _28884 = NOVALUE;
    object _28883 = NOVALUE;
    object _28882 = NOVALUE;
    object _28881 = NOVALUE;
    object _28880 = NOVALUE;
    object _28879 = NOVALUE;
    object _28878 = NOVALUE;
    object _28877 = NOVALUE;
    object _28873 = NOVALUE;
    object _28872 = NOVALUE;
    object _28870 = NOVALUE;
    object _28869 = NOVALUE;
    object _28868 = NOVALUE;
    object _28867 = NOVALUE;
    object _28866 = NOVALUE;
    object _28865 = NOVALUE;
    object _28864 = NOVALUE;
    object _28863 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1897		integer pop*/

    /** parser.e:1898		if CurrentSub = TopLevelSub then*/
    if (_36CurrentSub_21447 != _36TopLevelSub_21446)
    goto L1; // [9] 23

    /** parser.e:1899			CompileErr(RETURN_MUST_BE_INSIDE_A_PROCEDURE_OR_FUNCTION)*/
    RefDS(_21993);
    _50CompileErr(130LL, _21993, 0LL);
L1: 

    /** parser.e:1902		integer*/

    /** parser.e:1903			last_op = Last_op(),*/
    _last_op_57730 = _47Last_op();
    if (!IS_ATOM_INT(_last_op_57730)) {
        _1 = (object)(DBL_PTR(_last_op_57730)->dbl);
        DeRefDS(_last_op_57730);
        _last_op_57730 = _1;
    }

    /** parser.e:1904			last_pc = Last_pc(),*/
    _last_pc_57733 = _47Last_pc();
    if (!IS_ATOM_INT(_last_pc_57733)) {
        _1 = (object)(DBL_PTR(_last_pc_57733)->dbl);
        DeRefDS(_last_pc_57733);
        _last_pc_57733 = _1;
    }

    /** parser.e:1905			is_tail = 0*/
    _is_tail_57736 = 0LL;

    /** parser.e:1907		if last_op = PROC and length(Code) > last_pc and Code[last_pc+1] = CurrentSub then*/
    _28863 = (_last_op_57730 == 27LL);
    if (_28863 == 0) {
        _28864 = 0;
        goto L2; // [52] 69
    }
    if (IS_SEQUENCE(_36Code_21531)){
            _28865 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _28865 = 1;
    }
    _28866 = (_28865 > _last_pc_57733);
    _28865 = NOVALUE;
    _28864 = (_28866 != 0);
L2: 
    if (_28864 == 0) {
        goto L3; // [69] 99
    }
    _28868 = _last_pc_57733 + 1;
    _2 = (object)SEQ_PTR(_36Code_21531);
    _28869 = (object)*(((s1_ptr)_2)->base + _28868);
    if (IS_ATOM_INT(_28869)) {
        _28870 = (_28869 == _36CurrentSub_21447);
    }
    else {
        _28870 = binary_op(EQUALS, _28869, _36CurrentSub_21447);
    }
    _28869 = NOVALUE;
    if (_28870 == 0) {
        DeRef(_28870);
        _28870 = NOVALUE;
        goto L3; // [90] 99
    }
    else {
        if (!IS_ATOM_INT(_28870) && DBL_PTR(_28870)->dbl == 0.0){
            DeRef(_28870);
            _28870 = NOVALUE;
            goto L3; // [90] 99
        }
        DeRef(_28870);
        _28870 = NOVALUE;
    }
    DeRef(_28870);
    _28870 = NOVALUE;

    /** parser.e:1908			is_tail = 1*/
    _is_tail_57736 = 1LL;
L3: 

    /** parser.e:1911		if not TRANSLATE then*/
    if (_36TRANSLATE_21041 != 0)
    goto L4; // [103] 129

    /** parser.e:1912			if OpTrace then*/
    if (_36OpTrace_21512 == 0)
    {
        goto L5; // [110] 128
    }
    else{
    }

    /** parser.e:1913				emit_op(ERASE_PRIVATE_NAMES)*/
    _47emit_op(88LL);

    /** parser.e:1914				emit_addr(CurrentSub)*/
    _47emit_addr(_36CurrentSub_21447);
L5: 
L4: 

    /** parser.e:1917		if SymTab[CurrentSub][S_TOKEN] != PROC then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _28872 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21447);
    _2 = (object)SEQ_PTR(_28872);
    if (!IS_ATOM_INT(_36S_TOKEN_21081)){
        _28873 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    }
    else{
        _28873 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    }
    _28872 = NOVALUE;
    if (binary_op_a(EQUALS, _28873, 27LL)){
        _28873 = NOVALUE;
        goto L6; // [147] 273
    }
    _28873 = NOVALUE;

    /** parser.e:1918			Expr()*/
    _45Expr();

    /** parser.e:1919			last_op = Last_op()*/
    _last_op_57730 = _47Last_op();
    if (!IS_ATOM_INT(_last_op_57730)) {
        _1 = (object)(DBL_PTR(_last_op_57730)->dbl);
        DeRefDS(_last_op_57730);
        _last_op_57730 = _1;
    }

    /** parser.e:1920			last_pc = Last_pc()*/
    _last_pc_57733 = _47Last_pc();
    if (!IS_ATOM_INT(_last_pc_57733)) {
        _1 = (object)(DBL_PTR(_last_pc_57733)->dbl);
        DeRefDS(_last_pc_57733);
        _last_pc_57733 = _1;
    }

    /** parser.e:1921			if last_op = PROC and length(Code) > last_pc and Code[last_pc+1] = CurrentSub then*/
    _28877 = (_last_op_57730 == 27LL);
    if (_28877 == 0) {
        _28878 = 0;
        goto L7; // [177] 194
    }
    if (IS_SEQUENCE(_36Code_21531)){
            _28879 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _28879 = 1;
    }
    _28880 = (_28879 > _last_pc_57733);
    _28879 = NOVALUE;
    _28878 = (_28880 != 0);
L7: 
    if (_28878 == 0) {
        goto L8; // [194] 253
    }
    _28882 = _last_pc_57733 + 1;
    _2 = (object)SEQ_PTR(_36Code_21531);
    _28883 = (object)*(((s1_ptr)_2)->base + _28882);
    if (IS_ATOM_INT(_28883)) {
        _28884 = (_28883 == _36CurrentSub_21447);
    }
    else {
        _28884 = binary_op(EQUALS, _28883, _36CurrentSub_21447);
    }
    _28883 = NOVALUE;
    if (_28884 == 0) {
        DeRef(_28884);
        _28884 = NOVALUE;
        goto L8; // [215] 253
    }
    else {
        if (!IS_ATOM_INT(_28884) && DBL_PTR(_28884)->dbl == 0.0){
            DeRef(_28884);
            _28884 = NOVALUE;
            goto L8; // [215] 253
        }
        DeRef(_28884);
        _28884 = NOVALUE;
    }
    DeRef(_28884);
    _28884 = NOVALUE;

    /** parser.e:1922				pop = Pop() -- prevent cg_stack (code generation stack) leakage*/
    _pop_57723 = _47Pop();
    if (!IS_ATOM_INT(_pop_57723)) {
        _1 = (object)(DBL_PTR(_pop_57723)->dbl);
        DeRefDS(_pop_57723);
        _pop_57723 = _1;
    }

    /** parser.e:1923				Code[Last_pc()] = PROC_TAIL*/
    _28886 = _47Last_pc();
    _2 = (object)SEQ_PTR(_36Code_21531);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21531 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_28886))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_28886)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _28886);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 203LL;
    DeRef(_1);

    /** parser.e:1924				if object(pop_temps()) then end if*/
    _28887 = _47pop_temps();
    if( NOVALUE == _28887 ){
        _28888 = 0;
    }
    else{
        if (IS_ATOM_INT(_28887))
        _28888 = 1;
        else if (IS_ATOM_DBL(_28887)) {
             if (IS_ATOM_INT(DoubleToInt(_28887))) {
                 _28888 = 1;
                 } else {
                     _28888 = 2;
                } } else if (IS_SEQUENCE(_28887))
                _28888 = 3;
                else
                _28888 = 0;
            }
            DeRef(_28887);
            _28887 = NOVALUE;
            if (_28888 == 0)
            {
                _28888 = NOVALUE;
                goto L9; // [246] 300
            }
            else{
                _28888 = NOVALUE;
            }
            goto L9; // [250] 300
L8: 

            /** parser.e:1926				FuncReturn = TRUE*/
            _45FuncReturn_54932 = _13TRUE_452;

            /** parser.e:1927				emit_op(RETURNF)*/
            _47emit_op(28LL);
            goto L9; // [270] 300
L6: 

            /** parser.e:1930			if is_tail then*/
            if (_is_tail_57736 == 0)
            {
                goto LA; // [275] 292
            }
            else{
            }

            /** parser.e:1931				Code[Last_pc()] = PROC_TAIL*/
            _28889 = _47Last_pc();
            _2 = (object)SEQ_PTR(_36Code_21531);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _36Code_21531 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_28889))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_28889)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _28889);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 203LL;
            DeRef(_1);
LA: 

            /** parser.e:1933			emit_op(RETURNP)*/
            _47emit_op(29LL);
L9: 

            /** parser.e:1936		tok = next_token()*/
            _0 = _tok_57722;
            _tok_57722 = _45next_token();
            DeRef(_0);

            /** parser.e:1937		putback(tok)*/
            Ref(_tok_57722);
            _45putback(_tok_57722);

            /** parser.e:1938		NotReached(tok[T_ID], "return")*/
            _2 = (object)SEQ_PTR(_tok_57722);
            _28891 = (object)*(((s1_ptr)_2)->base + 1LL);
            Ref(_28891);
            RefDS(_26256);
            _45NotReached(_28891, _26256);
            _28891 = NOVALUE;

            /** parser.e:1939	end procedure*/
            DeRef(_tok_57722);
            DeRef(_28880);
            _28880 = NOVALUE;
            DeRef(_28889);
            _28889 = NOVALUE;
            DeRef(_28886);
            _28886 = NOVALUE;
            DeRef(_28882);
            _28882 = NOVALUE;
            DeRef(_28863);
            _28863 = NOVALUE;
            DeRef(_28877);
            _28877 = NOVALUE;
            DeRef(_28868);
            _28868 = NOVALUE;
            DeRef(_28866);
            _28866 = NOVALUE;
            return;
    ;
}


object _45exit_level(object _tok_57812, object _flag_57813)
{
    object _arg_57814 = NOVALUE;
    object _n_57815 = NOVALUE;
    object _num_labels_57816 = NOVALUE;
    object _negative_57817 = NOVALUE;
    object _labels_57818 = NOVALUE;
    object _28920 = NOVALUE;
    object _28919 = NOVALUE;
    object _28918 = NOVALUE;
    object _28917 = NOVALUE;
    object _28916 = NOVALUE;
    object _28913 = NOVALUE;
    object _28912 = NOVALUE;
    object _28911 = NOVALUE;
    object _28909 = NOVALUE;
    object _28908 = NOVALUE;
    object _28907 = NOVALUE;
    object _28906 = NOVALUE;
    object _28904 = NOVALUE;
    object _28899 = NOVALUE;
    object _28898 = NOVALUE;
    object _28896 = NOVALUE;
    object _28893 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1946		integer negative = 0*/
    _negative_57817 = 0LL;

    /** parser.e:1949		if flag then*/
    if (_flag_57813 == 0)
    {
        goto L1; // [10] 25
    }
    else{
    }

    /** parser.e:1950			labels = if_labels*/
    RefDS(_45if_labels_54953);
    DeRef(_labels_57818);
    _labels_57818 = _45if_labels_54953;
    goto L2; // [22] 35
L1: 

    /** parser.e:1952			labels = loop_labels*/
    RefDS(_45loop_labels_54952);
    DeRef(_labels_57818);
    _labels_57818 = _45loop_labels_54952;
L2: 

    /** parser.e:1954		num_labels = length(labels)*/
    if (IS_SEQUENCE(_labels_57818)){
            _num_labels_57816 = SEQ_PTR(_labels_57818)->length;
    }
    else {
        _num_labels_57816 = 1;
    }

    /** parser.e:1956		if tok[T_ID] = MINUS then*/
    _2 = (object)SEQ_PTR(_tok_57812);
    _28893 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28893, 10LL)){
        _28893 = NOVALUE;
        goto L3; // [52] 67
    }
    _28893 = NOVALUE;

    /** parser.e:1957			tok = next_token()*/
    _0 = _tok_57812;
    _tok_57812 = _45next_token();
    DeRef(_0);

    /** parser.e:1958			negative = 1*/
    _negative_57817 = 1LL;
L3: 

    /** parser.e:1961		if tok[T_ID]=ATOM then*/
    _2 = (object)SEQ_PTR(_tok_57812);
    _28896 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28896, 502LL)){
        _28896 = NOVALUE;
        goto L4; // [77] 180
    }
    _28896 = NOVALUE;

    /** parser.e:1962			arg = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_tok_57812);
    _28898 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_28898)){
        _28899 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28898)->dbl));
    }
    else{
        _28899 = (object)*(((s1_ptr)_2)->base + _28898);
    }
    DeRef(_arg_57814);
    _2 = (object)SEQ_PTR(_28899);
    _arg_57814 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_arg_57814);
    _28899 = NOVALUE;

    /** parser.e:1963			n = floor(arg)*/
    if (IS_ATOM_INT(_arg_57814))
    _n_57815 = e_floor(_arg_57814);
    else
    _n_57815 = unary_op(FLOOR, _arg_57814);
    if (!IS_ATOM_INT(_n_57815)) {
        _1 = (object)(DBL_PTR(_n_57815)->dbl);
        DeRefDS(_n_57815);
        _n_57815 = _1;
    }

    /** parser.e:1964			if negative then*/
    if (_negative_57817 == 0)
    {
        goto L5; // [110] 122
    }
    else{
    }

    /** parser.e:1965				n = num_labels - n*/
    _n_57815 = _num_labels_57816 - _n_57815;
    goto L6; // [119] 135
L5: 

    /** parser.e:1966			elsif n = 0 then*/
    if (_n_57815 != 0LL)
    goto L7; // [124] 134

    /** parser.e:1967				n = num_labels*/
    _n_57815 = _num_labels_57816;
L7: 
L6: 

    /** parser.e:1969			if n<=0 or n>num_labels then*/
    _28904 = (_n_57815 <= 0LL);
    if (_28904 != 0) {
        goto L8; // [141] 154
    }
    _28906 = (_n_57815 > _num_labels_57816);
    if (_28906 == 0)
    {
        DeRef(_28906);
        _28906 = NOVALUE;
        goto L9; // [150] 164
    }
    else{
        DeRef(_28906);
        _28906 = NOVALUE;
    }
L8: 

    /** parser.e:1970				CompileErr(EXITBREAK_ARGUMENT_OUT_OF_RANGE)*/
    RefDS(_21993);
    _50CompileErr(87LL, _21993, 0LL);
L9: 

    /** parser.e:1972			return {n, next_token()}*/
    _28907 = _45next_token();
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _n_57815;
    ((intptr_t *)_2)[2] = _28907;
    _28908 = MAKE_SEQ(_1);
    _28907 = NOVALUE;
    DeRef(_tok_57812);
    DeRef(_arg_57814);
    DeRef(_labels_57818);
    _28898 = NOVALUE;
    DeRef(_28904);
    _28904 = NOVALUE;
    return _28908;
    goto LA; // [177] 270
L4: 

    /** parser.e:1973		elsif tok[T_ID]=STRING then*/
    _2 = (object)SEQ_PTR(_tok_57812);
    _28909 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28909, 503LL)){
        _28909 = NOVALUE;
        goto LB; // [190] 259
    }
    _28909 = NOVALUE;

    /** parser.e:1974			n = find(SymTab[tok[T_SYM]][S_OBJ],labels)*/
    _2 = (object)SEQ_PTR(_tok_57812);
    _28911 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_28911)){
        _28912 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28911)->dbl));
    }
    else{
        _28912 = (object)*(((s1_ptr)_2)->base + _28911);
    }
    _2 = (object)SEQ_PTR(_28912);
    _28913 = (object)*(((s1_ptr)_2)->base + 1LL);
    _28912 = NOVALUE;
    _n_57815 = find_from(_28913, _labels_57818, 1LL);
    _28913 = NOVALUE;

    /** parser.e:1975			if n = 0 then*/
    if (_n_57815 != 0LL)
    goto LC; // [221] 235

    /** parser.e:1976				CompileErr(UNKNOWN_BLOCK_LABEL)*/
    RefDS(_21993);
    _50CompileErr(152LL, _21993, 0LL);
LC: 

    /** parser.e:1978			return {num_labels + 1 - n, next_token()}*/
    _28916 = _num_labels_57816 + 1;
    if (_28916 > MAXINT){
        _28916 = NewDouble((eudouble)_28916);
    }
    if (IS_ATOM_INT(_28916)) {
        _28917 = _28916 - _n_57815;
        if ((object)((uintptr_t)_28917 +(uintptr_t) HIGH_BITS) >= 0){
            _28917 = NewDouble((eudouble)_28917);
        }
    }
    else {
        _28917 = NewDouble(DBL_PTR(_28916)->dbl - (eudouble)_n_57815);
    }
    DeRef(_28916);
    _28916 = NOVALUE;
    _28918 = _45next_token();
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28917;
    ((intptr_t *)_2)[2] = _28918;
    _28919 = MAKE_SEQ(_1);
    _28918 = NOVALUE;
    _28917 = NOVALUE;
    DeRef(_tok_57812);
    DeRef(_arg_57814);
    DeRef(_labels_57818);
    _28898 = NOVALUE;
    _28911 = NOVALUE;
    DeRef(_28908);
    _28908 = NOVALUE;
    DeRef(_28904);
    _28904 = NOVALUE;
    return _28919;
    goto LA; // [256] 270
LB: 

    /** parser.e:1980			return {1, tok} -- no parameters*/
    Ref(_tok_57812);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1LL;
    ((intptr_t *)_2)[2] = _tok_57812;
    _28920 = MAKE_SEQ(_1);
    DeRef(_tok_57812);
    DeRef(_arg_57814);
    DeRef(_labels_57818);
    _28898 = NOVALUE;
    _28911 = NOVALUE;
    DeRef(_28919);
    _28919 = NOVALUE;
    DeRef(_28908);
    _28908 = NOVALUE;
    DeRef(_28904);
    _28904 = NOVALUE;
    return _28920;
LA: 
    ;
}


void _45GLabel_statement()
{
    object _tok_57877 = NOVALUE;
    object _labbel_57878 = NOVALUE;
    object _laddr_57879 = NOVALUE;
    object _n_57880 = NOVALUE;
    object _28939 = NOVALUE;
    object _28937 = NOVALUE;
    object _28936 = NOVALUE;
    object _28935 = NOVALUE;
    object _28934 = NOVALUE;
    object _28932 = NOVALUE;
    object _28929 = NOVALUE;
    object _28927 = NOVALUE;
    object _28925 = NOVALUE;
    object _28924 = NOVALUE;
    object _28922 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1986		object labbel*/

    /** parser.e:1987		object laddr*/

    /** parser.e:1988		integer n*/

    /** parser.e:1990		tok = next_token()*/
    _0 = _tok_57877;
    _tok_57877 = _45next_token();
    DeRef(_0);

    /** parser.e:1992		if tok[T_ID] != STRING then*/
    _2 = (object)SEQ_PTR(_tok_57877);
    _28922 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _28922, 503LL)){
        _28922 = NOVALUE;
        goto L1; // [22] 36
    }
    _28922 = NOVALUE;

    /** parser.e:1993			CompileErr(A_LABEL_CLAUSE_MUST_BE_FOLLOWED_BY_A_CONSTANT_STRING)*/
    RefDS(_21993);
    _50CompileErr(35LL, _21993, 0LL);
L1: 

    /** parser.e:1996		labbel = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_tok_57877);
    _28924 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_28924)){
        _28925 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28924)->dbl));
    }
    else{
        _28925 = (object)*(((s1_ptr)_2)->base + _28924);
    }
    DeRef(_labbel_57878);
    _2 = (object)SEQ_PTR(_28925);
    _labbel_57878 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_labbel_57878);
    _28925 = NOVALUE;

    /** parser.e:1997		laddr = length(Code) + 1*/
    if (IS_SEQUENCE(_36Code_21531)){
            _28927 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _28927 = 1;
    }
    _laddr_57879 = _28927 + 1;
    _28927 = NOVALUE;

    /** parser.e:1999		if find(labbel, goto_labels) then*/
    _28929 = find_from(_labbel_57878, _45goto_labels_54935, 1LL);
    if (_28929 == 0)
    {
        _28929 = NOVALUE;
        goto L2; // [76] 89
    }
    else{
        _28929 = NOVALUE;
    }

    /** parser.e:2000			CompileErr(DUPLICATE_LABEL_NAME)*/
    RefDS(_21993);
    _50CompileErr(59LL, _21993, 0LL);
L2: 

    /** parser.e:2003		goto_labels = append(goto_labels, labbel)*/
    Ref(_labbel_57878);
    Append(&_45goto_labels_54935, _45goto_labels_54935, _labbel_57878);

    /** parser.e:2004		goto_addr = append(goto_addr, laddr)*/
    Append(&_45goto_addr_54936, _45goto_addr_54936, _laddr_57879);

    /** parser.e:2005		label_block = append( label_block, top_block() )*/
    _28932 = _65top_block(0LL);
    Ref(_28932);
    Append(&_45label_block_54939, _45label_block_54939, _28932);
    DeRef(_28932);
    _28932 = NOVALUE;

    /** parser.e:2007		while n with entry do*/
    goto L3; // [119] 178
L4: 
    if (_n_57880 == 0)
    {
        goto L5; // [124] 192
    }
    else{
    }

    /** parser.e:2008			backpatch(goto_list[n], laddr)*/
    _2 = (object)SEQ_PTR(_36goto_list_21554);
    _28934 = (object)*(((s1_ptr)_2)->base + _n_57880);
    Ref(_28934);
    _47backpatch(_28934, _laddr_57879);
    _28934 = NOVALUE;

    /** parser.e:2009			set_glabel_block( goto_ref[n], top_block() )*/
    _2 = (object)SEQ_PTR(_45goto_ref_54938);
    _28935 = (object)*(((s1_ptr)_2)->base + _n_57880);
    _28936 = _65top_block(0LL);
    Ref(_28935);
    _44set_glabel_block(_28935, _28936);
    _28935 = NOVALUE;
    _28936 = NOVALUE;

    /** parser.e:2010			goto_delay[n] = "" --clear it*/
    RefDS(_21993);
    _2 = (object)SEQ_PTR(_36goto_delay_21553);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36goto_delay_21553 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _n_57880);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _21993;
    DeRef(_1);

    /** parser.e:2011			goto_line[n] = {-1,""} --clear it*/
    RefDS(_21993);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1LL;
    ((intptr_t *)_2)[2] = _21993;
    _28937 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_45goto_line_54934);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _45goto_line_54934 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _n_57880);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _28937;
    if( _1 != _28937 ){
        DeRef(_1);
    }
    _28937 = NOVALUE;

    /** parser.e:2013		entry*/
L3: 

    /** parser.e:2014			n = find(labbel, goto_delay)*/
    _n_57880 = find_from(_labbel_57878, _36goto_delay_21553, 1LL);

    /** parser.e:2015		end while*/
    goto L4; // [189] 122
L5: 

    /** parser.e:2017		force_uninitialize( map:get( goto_init, labbel, {} ) )*/
    Ref(_45goto_init_54941);
    Ref(_labbel_57878);
    RefDS(_21993);
    _28939 = _29get(_45goto_init_54941, _labbel_57878, _21993);
    _45force_uninitialize(_28939);
    _28939 = NOVALUE;

    /** parser.e:2019		if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L6; // [209] 225
    }
    else{
    }

    /** parser.e:2020			emit_op(GLABEL)*/
    _47emit_op(189LL);

    /** parser.e:2021			emit_addr(laddr)*/
    _47emit_addr(_laddr_57879);
L6: 

    /** parser.e:2023	end procedure*/
    DeRef(_tok_57877);
    DeRef(_labbel_57878);
    _28924 = NOVALUE;
    return;
    ;
}


void _45Goto_statement()
{
    object _tok_57929 = NOVALUE;
    object _n_57930 = NOVALUE;
    object _num_labels_57931 = NOVALUE;
    object _31688 = NOVALUE;
    object _28978 = NOVALUE;
    object _28977 = NOVALUE;
    object _28974 = NOVALUE;
    object _28973 = NOVALUE;
    object _28972 = NOVALUE;
    object _28971 = NOVALUE;
    object _28970 = NOVALUE;
    object _28969 = NOVALUE;
    object _28968 = NOVALUE;
    object _28967 = NOVALUE;
    object _28966 = NOVALUE;
    object _28965 = NOVALUE;
    object _28964 = NOVALUE;
    object _28963 = NOVALUE;
    object _28961 = NOVALUE;
    object _28960 = NOVALUE;
    object _28958 = NOVALUE;
    object _28957 = NOVALUE;
    object _28955 = NOVALUE;
    object _28954 = NOVALUE;
    object _28952 = NOVALUE;
    object _28951 = NOVALUE;
    object _28950 = NOVALUE;
    object _28949 = NOVALUE;
    object _28946 = NOVALUE;
    object _28945 = NOVALUE;
    object _28944 = NOVALUE;
    object _28942 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2028		integer n*/

    /** parser.e:2029		integer num_labels*/

    /** parser.e:2031		tok = next_token()*/
    _0 = _tok_57929;
    _tok_57929 = _45next_token();
    DeRef(_0);

    /** parser.e:2032		num_labels = length(goto_labels)*/
    if (IS_SEQUENCE(_45goto_labels_54935)){
            _num_labels_57931 = SEQ_PTR(_45goto_labels_54935)->length;
    }
    else {
        _num_labels_57931 = 1;
    }

    /** parser.e:2034		if tok[T_ID]=STRING then*/
    _2 = (object)SEQ_PTR(_tok_57929);
    _28942 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _28942, 503LL)){
        _28942 = NOVALUE;
        goto L1; // [27] 267
    }
    _28942 = NOVALUE;

    /** parser.e:2035			n = find(SymTab[tok[T_SYM]][S_OBJ],goto_labels)*/
    _2 = (object)SEQ_PTR(_tok_57929);
    _28944 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_28944)){
        _28945 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28944)->dbl));
    }
    else{
        _28945 = (object)*(((s1_ptr)_2)->base + _28944);
    }
    _2 = (object)SEQ_PTR(_28945);
    _28946 = (object)*(((s1_ptr)_2)->base + 1LL);
    _28945 = NOVALUE;
    _n_57930 = find_from(_28946, _45goto_labels_54935, 1LL);
    _28946 = NOVALUE;

    /** parser.e:2036			if n = 0 then*/
    if (_n_57930 != 0LL)
    goto L2; // [60] 241

    /** parser.e:2037				goto_delay &= {SymTab[tok[T_SYM]][S_OBJ]}*/
    _2 = (object)SEQ_PTR(_tok_57929);
    _28949 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_28949)){
        _28950 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28949)->dbl));
    }
    else{
        _28950 = (object)*(((s1_ptr)_2)->base + _28949);
    }
    _2 = (object)SEQ_PTR(_28950);
    _28951 = (object)*(((s1_ptr)_2)->base + 1LL);
    _28950 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_28951);
    ((intptr_t*)_2)[1] = _28951;
    _28952 = MAKE_SEQ(_1);
    _28951 = NOVALUE;
    Concat((object_ptr)&_36goto_delay_21553, _36goto_delay_21553, _28952);
    DeRefDS(_28952);
    _28952 = NOVALUE;

    /** parser.e:2038				goto_list &= length(Code)+2 --not 1???*/
    if (IS_SEQUENCE(_36Code_21531)){
            _28954 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _28954 = 1;
    }
    _28955 = _28954 + 2LL;
    _28954 = NOVALUE;
    Append(&_36goto_list_21554, _36goto_list_21554, _28955);
    _28955 = NOVALUE;

    /** parser.e:2039				goto_line &= {{line_number,ThisLine}}*/
    Ref(_50ThisLine_49234);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _36line_number_21440;
    ((intptr_t *)_2)[2] = _50ThisLine_49234;
    _28957 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _28957;
    _28958 = MAKE_SEQ(_1);
    _28957 = NOVALUE;
    Concat((object_ptr)&_45goto_line_54934, _45goto_line_54934, _28958);
    DeRefDS(_28958);
    _28958 = NOVALUE;

    /** parser.e:2040				goto_ref &= new_forward_reference( GOTO, top_block() )*/
    _28960 = _65top_block(0LL);
    _31688 = 188LL;
    _28961 = _44new_forward_reference(188LL, _28960, 188LL);
    _28960 = NOVALUE;
    _31688 = NOVALUE;
    if (IS_SEQUENCE(_45goto_ref_54938) && IS_ATOM(_28961)) {
        Ref(_28961);
        Append(&_45goto_ref_54938, _45goto_ref_54938, _28961);
    }
    else if (IS_ATOM(_45goto_ref_54938) && IS_SEQUENCE(_28961)) {
    }
    else {
        Concat((object_ptr)&_45goto_ref_54938, _45goto_ref_54938, _28961);
    }
    DeRef(_28961);
    _28961 = NOVALUE;

    /** parser.e:2041				map:put( goto_init, SymTab[tok[T_SYM]][S_OBJ], get_private_uninitialized() )*/
    _2 = (object)SEQ_PTR(_tok_57929);
    _28963 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_28963)){
        _28964 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28963)->dbl));
    }
    else{
        _28964 = (object)*(((s1_ptr)_2)->base + _28963);
    }
    _2 = (object)SEQ_PTR(_28964);
    _28965 = (object)*(((s1_ptr)_2)->base + 1LL);
    _28964 = NOVALUE;
    _28966 = _45get_private_uninitialized();
    Ref(_45goto_init_54941);
    Ref(_28965);
    _29put(_45goto_init_54941, _28965, _28966, 1LL, 0LL);
    _28965 = NOVALUE;
    _28966 = NOVALUE;

    /** parser.e:2042				add_data( goto_ref[$], sym_obj( tok[T_SYM] ) )*/
    if (IS_SEQUENCE(_45goto_ref_54938)){
            _28967 = SEQ_PTR(_45goto_ref_54938)->length;
    }
    else {
        _28967 = 1;
    }
    _2 = (object)SEQ_PTR(_45goto_ref_54938);
    _28968 = (object)*(((s1_ptr)_2)->base + _28967);
    _2 = (object)SEQ_PTR(_tok_57929);
    _28969 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_28969);
    _28970 = _54sym_obj(_28969);
    _28969 = NOVALUE;
    Ref(_28968);
    _44add_data(_28968, _28970);
    _28968 = NOVALUE;
    _28970 = NOVALUE;

    /** parser.e:2043				set_line( goto_ref[$], line_number, ThisLine, bp )*/
    if (IS_SEQUENCE(_45goto_ref_54938)){
            _28971 = SEQ_PTR(_45goto_ref_54938)->length;
    }
    else {
        _28971 = 1;
    }
    _2 = (object)SEQ_PTR(_45goto_ref_54938);
    _28972 = (object)*(((s1_ptr)_2)->base + _28971);
    Ref(_28972);
    Ref(_50ThisLine_49234);
    _44set_line(_28972, _36line_number_21440, _50ThisLine_49234, _50bp_49238);
    _28972 = NOVALUE;
    goto L3; // [238] 259
L2: 

    /** parser.e:2045				Goto_block( top_block(), label_block[n] )*/
    _28973 = _65top_block(0LL);
    _2 = (object)SEQ_PTR(_45label_block_54939);
    _28974 = (object)*(((s1_ptr)_2)->base + _n_57930);
    Ref(_28974);
    _65Goto_block(_28973, _28974, 0LL);
    _28973 = NOVALUE;
    _28974 = NOVALUE;
L3: 

    /** parser.e:2047			tok = next_token()*/
    _0 = _tok_57929;
    _tok_57929 = _45next_token();
    DeRef(_0);
    goto L4; // [264] 277
L1: 

    /** parser.e:2049			CompileErr(GOTO_STATEMENT_WITHOUT_A_STRING_LABEL)*/
    RefDS(_21993);
    _50CompileErr(96LL, _21993, 0LL);
L4: 

    /** parser.e:2052		emit_op(GOTO)*/
    _47emit_op(188LL);

    /** parser.e:2053		if n = 0 then*/
    if (_n_57930 != 0LL)
    goto L5; // [288] 300

    /** parser.e:2054			emit_addr(0) -- to be back-patched*/
    _47emit_addr(0LL);
    goto L6; // [297] 312
L5: 

    /** parser.e:2056			emit_addr(goto_addr[n])*/
    _2 = (object)SEQ_PTR(_45goto_addr_54936);
    _28977 = (object)*(((s1_ptr)_2)->base + _n_57930);
    Ref(_28977);
    _47emit_addr(_28977);
    _28977 = NOVALUE;
L6: 

    /** parser.e:2059		putback(tok)*/
    Ref(_tok_57929);
    _45putback(_tok_57929);

    /** parser.e:2060		NotReached(tok[T_ID], "goto")*/
    _2 = (object)SEQ_PTR(_tok_57929);
    _28978 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_28978);
    RefDS(_26198);
    _45NotReached(_28978, _26198);
    _28978 = NOVALUE;

    /** parser.e:2061	end procedure*/
    DeRef(_tok_57929);
    _28944 = NOVALUE;
    _28963 = NOVALUE;
    _28949 = NOVALUE;
    return;
    ;
}


void _45Exit_statement()
{
    object _addr_inlined_AppendXList_at_65_58034 = NOVALUE;
    object _tok_58016 = NOVALUE;
    object _by_ref_58017 = NOVALUE;
    object _28986 = NOVALUE;
    object _28985 = NOVALUE;
    object _28984 = NOVALUE;
    object _28983 = NOVALUE;
    object _28981 = NOVALUE;
    object _28979 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2066		sequence by_ref*/

    /** parser.e:2068		if not length(loop_stack) then*/
    if (IS_SEQUENCE(_45loop_stack_54958)){
            _28979 = SEQ_PTR(_45loop_stack_54958)->length;
    }
    else {
        _28979 = 1;
    }
    if (_28979 != 0)
    goto L1; // [10] 23
    _28979 = NOVALUE;

    /** parser.e:2069			CompileErr(EXIT_STATEMENT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_21993);
    _50CompileErr(88LL, _21993, 0LL);
L1: 

    /** parser.e:2072		by_ref = exit_level(next_token(),0) -- can't pass tok by reference*/
    _28981 = _45next_token();
    _0 = _by_ref_58017;
    _by_ref_58017 = _45exit_level(_28981, 0LL);
    DeRef(_0);
    _28981 = NOVALUE;

    /** parser.e:2073		Leave_blocks( by_ref[1], LOOP_BLOCK )*/
    _2 = (object)SEQ_PTR(_by_ref_58017);
    _28983 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_28983);
    _65Leave_blocks(_28983, 1LL);
    _28983 = NOVALUE;

    /** parser.e:2074		emit_op(EXIT)*/
    _47emit_op(61LL);

    /** parser.e:2075		AppendXList(length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21531)){
            _28984 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _28984 = 1;
    }
    _28985 = _28984 + 1;
    _28984 = NOVALUE;
    _addr_inlined_AppendXList_at_65_58034 = _28985;
    _28985 = NOVALUE;

    /** parser.e:398		exit_list = append(exit_list, addr)*/
    Append(&_45exit_list_54944, _45exit_list_54944, _addr_inlined_AppendXList_at_65_58034);

    /** parser.e:399	end procedure*/
    goto L2; // [80] 83
L2: 

    /** parser.e:2076		exit_delay &= by_ref[1]*/
    _2 = (object)SEQ_PTR(_by_ref_58017);
    _28986 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_45exit_delay_54945) && IS_ATOM(_28986)) {
        Ref(_28986);
        Append(&_45exit_delay_54945, _45exit_delay_54945, _28986);
    }
    else if (IS_ATOM(_45exit_delay_54945) && IS_SEQUENCE(_28986)) {
    }
    else {
        Concat((object_ptr)&_45exit_delay_54945, _45exit_delay_54945, _28986);
    }
    _28986 = NOVALUE;

    /** parser.e:2077		emit_forward_addr()    -- to be back-patched*/
    _45emit_forward_addr();

    /** parser.e:2078		tok = by_ref[2]*/
    DeRef(_tok_58016);
    _2 = (object)SEQ_PTR(_by_ref_58017);
    _tok_58016 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_tok_58016);

    /** parser.e:2079		putback(tok)*/
    Ref(_tok_58016);
    _45putback(_tok_58016);

    /** parser.e:2080	end procedure*/
    DeRef(_tok_58016);
    DeRefDS(_by_ref_58017);
    return;
    ;
}


void _45Continue_statement()
{
    object _addr_inlined_AppendNList_at_153_58080 = NOVALUE;
    object _tok_58041 = NOVALUE;
    object _by_ref_58042 = NOVALUE;
    object _loop_level_58043 = NOVALUE;
    object _29012 = NOVALUE;
    object _29009 = NOVALUE;
    object _29008 = NOVALUE;
    object _29007 = NOVALUE;
    object _29006 = NOVALUE;
    object _29005 = NOVALUE;
    object _29004 = NOVALUE;
    object _29002 = NOVALUE;
    object _29001 = NOVALUE;
    object _29000 = NOVALUE;
    object _28999 = NOVALUE;
    object _28998 = NOVALUE;
    object _28997 = NOVALUE;
    object _28996 = NOVALUE;
    object _28995 = NOVALUE;
    object _28993 = NOVALUE;
    object _28991 = NOVALUE;
    object _28989 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2085		sequence by_ref*/

    /** parser.e:2086		integer loop_level*/

    /** parser.e:2088		if not length(loop_stack) then*/
    if (IS_SEQUENCE(_45loop_stack_54958)){
            _28989 = SEQ_PTR(_45loop_stack_54958)->length;
    }
    else {
        _28989 = 1;
    }
    if (_28989 != 0)
    goto L1; // [12] 25
    _28989 = NOVALUE;

    /** parser.e:2089			CompileErr(CONTINUE_STATEMENT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_21993);
    _50CompileErr(49LL, _21993, 0LL);
L1: 

    /** parser.e:2092		by_ref = exit_level(next_token(),0) -- can't pass tok by reference*/
    _28991 = _45next_token();
    _0 = _by_ref_58042;
    _by_ref_58042 = _45exit_level(_28991, 0LL);
    DeRef(_0);
    _28991 = NOVALUE;

    /** parser.e:2093		Leave_blocks( by_ref[1], LOOP_BLOCK )*/
    _2 = (object)SEQ_PTR(_by_ref_58042);
    _28993 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_28993);
    _65Leave_blocks(_28993, 1LL);
    _28993 = NOVALUE;

    /** parser.e:2094		emit_op(ELSE)*/
    _47emit_op(23LL);

    /** parser.e:2095		loop_level = by_ref[1]*/
    _2 = (object)SEQ_PTR(_by_ref_58042);
    _loop_level_58043 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_loop_level_58043))
    _loop_level_58043 = (object)DBL_PTR(_loop_level_58043)->dbl;

    /** parser.e:2098		if continue_addr[$+1-loop_level] then -- address is known for while loops*/
    if (IS_SEQUENCE(_45continue_addr_54949)){
            _28995 = SEQ_PTR(_45continue_addr_54949)->length;
    }
    else {
        _28995 = 1;
    }
    _28996 = _28995 + 1;
    _28995 = NOVALUE;
    _28997 = _28996 - _loop_level_58043;
    _28996 = NOVALUE;
    _2 = (object)SEQ_PTR(_45continue_addr_54949);
    _28998 = (object)*(((s1_ptr)_2)->base + _28997);
    if (_28998 == 0)
    {
        _28998 = NOVALUE;
        goto L2; // [81] 142
    }
    else{
        _28998 = NOVALUE;
    }

    /** parser.e:2099			if continue_addr[$+1-loop_level] < 0 then*/
    if (IS_SEQUENCE(_45continue_addr_54949)){
            _28999 = SEQ_PTR(_45continue_addr_54949)->length;
    }
    else {
        _28999 = 1;
    }
    _29000 = _28999 + 1;
    _28999 = NOVALUE;
    _29001 = _29000 - _loop_level_58043;
    _29000 = NOVALUE;
    _2 = (object)SEQ_PTR(_45continue_addr_54949);
    _29002 = (object)*(((s1_ptr)_2)->base + _29001);
    if (_29002 >= 0LL)
    goto L3; // [103] 117

    /** parser.e:2101				CompileErr(CONTINUE_STATEMENT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_21993);
    _50CompileErr(49LL, _21993, 0LL);
L3: 

    /** parser.e:2103			emit_addr(continue_addr[$+1-loop_level])*/
    if (IS_SEQUENCE(_45continue_addr_54949)){
            _29004 = SEQ_PTR(_45continue_addr_54949)->length;
    }
    else {
        _29004 = 1;
    }
    _29005 = _29004 + 1;
    _29004 = NOVALUE;
    _29006 = _29005 - _loop_level_58043;
    _29005 = NOVALUE;
    _2 = (object)SEQ_PTR(_45continue_addr_54949);
    _29007 = (object)*(((s1_ptr)_2)->base + _29006);
    _47emit_addr(_29007);
    _29007 = NOVALUE;
    goto L4; // [139] 186
L2: 

    /** parser.e:2105			AppendNList(length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21531)){
            _29008 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29008 = 1;
    }
    _29009 = _29008 + 1;
    _29008 = NOVALUE;
    _addr_inlined_AppendNList_at_153_58080 = _29009;
    _29009 = NOVALUE;

    /** parser.e:403		continue_list = append(continue_list, addr)*/
    Append(&_45continue_list_54946, _45continue_list_54946, _addr_inlined_AppendNList_at_153_58080);

    /** parser.e:404	end procedure*/
    goto L5; // [168] 171
L5: 

    /** parser.e:2106			continue_delay &= loop_level*/
    Append(&_45continue_delay_54947, _45continue_delay_54947, _loop_level_58043);

    /** parser.e:2107			emit_forward_addr()    -- to be back-patched*/
    _45emit_forward_addr();
L4: 

    /** parser.e:2110		tok = by_ref[2]*/
    DeRef(_tok_58041);
    _2 = (object)SEQ_PTR(_by_ref_58042);
    _tok_58041 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_tok_58041);

    /** parser.e:2111		putback(tok)*/
    Ref(_tok_58041);
    _45putback(_tok_58041);

    /** parser.e:2113		NotReached(tok[T_ID], "continue")*/
    _2 = (object)SEQ_PTR(_tok_58041);
    _29012 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_29012);
    RefDS(_26160);
    _45NotReached(_29012, _26160);
    _29012 = NOVALUE;

    /** parser.e:2114	end procedure*/
    DeRef(_tok_58041);
    DeRefDS(_by_ref_58042);
    DeRef(_28997);
    _28997 = NOVALUE;
    DeRef(_29006);
    _29006 = NOVALUE;
    DeRef(_29001);
    _29001 = NOVALUE;
    _29002 = NOVALUE;
    return;
    ;
}


void _45Retry_statement()
{
    object _by_ref_58087 = NOVALUE;
    object _tok_58089 = NOVALUE;
    object _29036 = NOVALUE;
    object _29034 = NOVALUE;
    object _29033 = NOVALUE;
    object _29032 = NOVALUE;
    object _29031 = NOVALUE;
    object _29030 = NOVALUE;
    object _29028 = NOVALUE;
    object _29027 = NOVALUE;
    object _29026 = NOVALUE;
    object _29025 = NOVALUE;
    object _29024 = NOVALUE;
    object _29022 = NOVALUE;
    object _29021 = NOVALUE;
    object _29020 = NOVALUE;
    object _29019 = NOVALUE;
    object _29018 = NOVALUE;
    object _29017 = NOVALUE;
    object _29015 = NOVALUE;
    object _29013 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2122		if not length(loop_stack) then*/
    if (IS_SEQUENCE(_45loop_stack_54958)){
            _29013 = SEQ_PTR(_45loop_stack_54958)->length;
    }
    else {
        _29013 = 1;
    }
    if (_29013 != 0)
    goto L1; // [8] 21
    _29013 = NOVALUE;

    /** parser.e:2123			CompileErr(RETRY_STATEMENT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_21993);
    _50CompileErr(131LL, _21993, 0LL);
L1: 

    /** parser.e:2126		by_ref = exit_level(next_token(),0) -- can't pass tok by reference*/
    _29015 = _45next_token();
    _0 = _by_ref_58087;
    _by_ref_58087 = _45exit_level(_29015, 0LL);
    DeRef(_0);
    _29015 = NOVALUE;

    /** parser.e:2127		Leave_blocks( by_ref[1], LOOP_BLOCK )*/
    _2 = (object)SEQ_PTR(_by_ref_58087);
    _29017 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_29017);
    _65Leave_blocks(_29017, 1LL);
    _29017 = NOVALUE;

    /** parser.e:2128		if loop_stack[$+1-by_ref[1]]=FOR then*/
    if (IS_SEQUENCE(_45loop_stack_54958)){
            _29018 = SEQ_PTR(_45loop_stack_54958)->length;
    }
    else {
        _29018 = 1;
    }
    _29019 = _29018 + 1;
    _29018 = NOVALUE;
    _2 = (object)SEQ_PTR(_by_ref_58087);
    _29020 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_29020)) {
        _29021 = _29019 - _29020;
    }
    else {
        _29021 = binary_op(MINUS, _29019, _29020);
    }
    _29019 = NOVALUE;
    _29020 = NOVALUE;
    _2 = (object)SEQ_PTR(_45loop_stack_54958);
    if (!IS_ATOM_INT(_29021)){
        _29022 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29021)->dbl));
    }
    else{
        _29022 = (object)*(((s1_ptr)_2)->base + _29021);
    }
    if (_29022 != 21LL)
    goto L2; // [70] 84

    /** parser.e:2129			emit_op(RETRY) -- for Translator to emit a label at the right place*/
    _47emit_op(184LL);
    goto L3; // [81] 129
L2: 

    /** parser.e:2131			if retry_addr[$+1-by_ref[1]] < 0 then*/
    if (IS_SEQUENCE(_45retry_addr_54950)){
            _29024 = SEQ_PTR(_45retry_addr_54950)->length;
    }
    else {
        _29024 = 1;
    }
    _29025 = _29024 + 1;
    _29024 = NOVALUE;
    _2 = (object)SEQ_PTR(_by_ref_58087);
    _29026 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_29026)) {
        _29027 = _29025 - _29026;
    }
    else {
        _29027 = binary_op(MINUS, _29025, _29026);
    }
    _29025 = NOVALUE;
    _29026 = NOVALUE;
    _2 = (object)SEQ_PTR(_45retry_addr_54950);
    if (!IS_ATOM_INT(_29027)){
        _29028 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29027)->dbl));
    }
    else{
        _29028 = (object)*(((s1_ptr)_2)->base + _29027);
    }
    if (_29028 >= 0LL)
    goto L4; // [107] 121

    /** parser.e:2133				CompileErr(RETRY_STATEMENT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_21993);
    _50CompileErr(131LL, _21993, 0LL);
L4: 

    /** parser.e:2135			emit_op(ELSE)*/
    _47emit_op(23LL);
L3: 

    /** parser.e:2138		emit_addr(retry_addr[$+1-by_ref[1]])*/
    if (IS_SEQUENCE(_45retry_addr_54950)){
            _29030 = SEQ_PTR(_45retry_addr_54950)->length;
    }
    else {
        _29030 = 1;
    }
    _29031 = _29030 + 1;
    _29030 = NOVALUE;
    _2 = (object)SEQ_PTR(_by_ref_58087);
    _29032 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_29032)) {
        _29033 = _29031 - _29032;
    }
    else {
        _29033 = binary_op(MINUS, _29031, _29032);
    }
    _29031 = NOVALUE;
    _29032 = NOVALUE;
    _2 = (object)SEQ_PTR(_45retry_addr_54950);
    if (!IS_ATOM_INT(_29033)){
        _29034 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29033)->dbl));
    }
    else{
        _29034 = (object)*(((s1_ptr)_2)->base + _29033);
    }
    _47emit_addr(_29034);
    _29034 = NOVALUE;

    /** parser.e:2139		tok = by_ref[2]*/
    DeRef(_tok_58089);
    _2 = (object)SEQ_PTR(_by_ref_58087);
    _tok_58089 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_tok_58089);

    /** parser.e:2140		putback(tok)*/
    Ref(_tok_58089);
    _45putback(_tok_58089);

    /** parser.e:2141		NotReached(tok[T_ID], "retry")*/
    _2 = (object)SEQ_PTR(_tok_58089);
    _29036 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_29036);
    RefDS(_26254);
    _45NotReached(_29036, _26254);
    _29036 = NOVALUE;

    /** parser.e:2142	end procedure*/
    DeRefDS(_by_ref_58087);
    DeRef(_tok_58089);
    _29022 = NOVALUE;
    DeRef(_29021);
    _29021 = NOVALUE;
    _29028 = NOVALUE;
    DeRef(_29033);
    _29033 = NOVALUE;
    DeRef(_29027);
    _29027 = NOVALUE;
    return;
    ;
}


object _45in_switch()
{
    object _29041 = NOVALUE;
    object _29040 = NOVALUE;
    object _29039 = NOVALUE;
    object _29038 = NOVALUE;
    object _29037 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2145		if length( if_stack ) and if_stack[$] = SWITCH then*/
    if (IS_SEQUENCE(_45if_stack_54959)){
            _29037 = SEQ_PTR(_45if_stack_54959)->length;
    }
    else {
        _29037 = 1;
    }
    if (_29037 == 0) {
        goto L1; // [8] 40
    }
    if (IS_SEQUENCE(_45if_stack_54959)){
            _29039 = SEQ_PTR(_45if_stack_54959)->length;
    }
    else {
        _29039 = 1;
    }
    _2 = (object)SEQ_PTR(_45if_stack_54959);
    _29040 = (object)*(((s1_ptr)_2)->base + _29039);
    _29041 = (_29040 == 185LL);
    _29040 = NOVALUE;
    if (_29041 == 0)
    {
        DeRef(_29041);
        _29041 = NOVALUE;
        goto L1; // [28] 40
    }
    else{
        DeRef(_29041);
        _29041 = NOVALUE;
    }

    /** parser.e:2146			return 1*/
    return 1LL;
    goto L2; // [37] 47
L1: 

    /** parser.e:2148			return 0*/
    return 0LL;
L2: 
    ;
}


void _45Break_statement()
{
    object _addr_inlined_AppendEList_at_65_58162 = NOVALUE;
    object _tok_58144 = NOVALUE;
    object _by_ref_58145 = NOVALUE;
    object _29052 = NOVALUE;
    object _29049 = NOVALUE;
    object _29048 = NOVALUE;
    object _29047 = NOVALUE;
    object _29046 = NOVALUE;
    object _29044 = NOVALUE;
    object _29042 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2154		sequence by_ref*/

    /** parser.e:2156		if not length(if_labels) then*/
    if (IS_SEQUENCE(_45if_labels_54953)){
            _29042 = SEQ_PTR(_45if_labels_54953)->length;
    }
    else {
        _29042 = 1;
    }
    if (_29042 != 0)
    goto L1; // [10] 23
    _29042 = NOVALUE;

    /** parser.e:2157			CompileErr(BREAK_STATEMENT_MUST_BE_INSIDE_A_IF_OR_A_SWITCH_BLOCK)*/
    RefDS(_21993);
    _50CompileErr(40LL, _21993, 0LL);
L1: 

    /** parser.e:2160		by_ref = exit_level(next_token(),1)*/
    _29044 = _45next_token();
    _0 = _by_ref_58145;
    _by_ref_58145 = _45exit_level(_29044, 1LL);
    DeRef(_0);
    _29044 = NOVALUE;

    /** parser.e:2161		Leave_blocks( by_ref[1], CONDITIONAL_BLOCK )*/
    _2 = (object)SEQ_PTR(_by_ref_58145);
    _29046 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_29046);
    _65Leave_blocks(_29046, 2LL);
    _29046 = NOVALUE;

    /** parser.e:2162		emit_op(ELSE)*/
    _47emit_op(23LL);

    /** parser.e:2163		AppendEList(length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21531)){
            _29047 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29047 = 1;
    }
    _29048 = _29047 + 1;
    _29047 = NOVALUE;
    _addr_inlined_AppendEList_at_65_58162 = _29048;
    _29048 = NOVALUE;

    /** parser.e:393		break_list = append(break_list, addr)*/
    Append(&_45break_list_54942, _45break_list_54942, _addr_inlined_AppendEList_at_65_58162);

    /** parser.e:394	end procedure*/
    goto L2; // [80] 83
L2: 

    /** parser.e:2165		break_delay &= by_ref[1]*/
    _2 = (object)SEQ_PTR(_by_ref_58145);
    _29049 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_45break_delay_54943) && IS_ATOM(_29049)) {
        Ref(_29049);
        Append(&_45break_delay_54943, _45break_delay_54943, _29049);
    }
    else if (IS_ATOM(_45break_delay_54943) && IS_SEQUENCE(_29049)) {
    }
    else {
        Concat((object_ptr)&_45break_delay_54943, _45break_delay_54943, _29049);
    }
    _29049 = NOVALUE;

    /** parser.e:2166		emit_forward_addr()    -- to be back-patched*/
    _45emit_forward_addr();

    /** parser.e:2167		tok = by_ref[2]*/
    DeRef(_tok_58144);
    _2 = (object)SEQ_PTR(_by_ref_58145);
    _tok_58144 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_tok_58144);

    /** parser.e:2168		putback(tok)*/
    Ref(_tok_58144);
    _45putback(_tok_58144);

    /** parser.e:2169		NotReached(tok[T_ID], "break")*/
    _2 = (object)SEQ_PTR(_tok_58144);
    _29052 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_29052);
    RefDS(_26144);
    _45NotReached(_29052, _26144);
    _29052 = NOVALUE;

    /** parser.e:2170	end procedure*/
    DeRef(_tok_58144);
    DeRefDS(_by_ref_58145);
    return;
    ;
}


object _45finish_block_header(object _opcode_58171)
{
    object _tok_58173 = NOVALUE;
    object _labbel_58174 = NOVALUE;
    object _has_entry_58175 = NOVALUE;
    object _29106 = NOVALUE;
    object _29105 = NOVALUE;
    object _29104 = NOVALUE;
    object _29103 = NOVALUE;
    object _29100 = NOVALUE;
    object _29095 = NOVALUE;
    object _29092 = NOVALUE;
    object _29090 = NOVALUE;
    object _29087 = NOVALUE;
    object _29086 = NOVALUE;
    object _29084 = NOVALUE;
    object _29081 = NOVALUE;
    object _29078 = NOVALUE;
    object _29077 = NOVALUE;
    object _29075 = NOVALUE;
    object _29073 = NOVALUE;
    object _29070 = NOVALUE;
    object _29067 = NOVALUE;
    object _29066 = NOVALUE;
    object _29064 = NOVALUE;
    object _29062 = NOVALUE;
    object _29061 = NOVALUE;
    object _29060 = NOVALUE;
    object _29057 = NOVALUE;
    object _29054 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2176		object labbel*/

    /** parser.e:2177		integer has_entry*/

    /** parser.e:2179		tok = next_token()*/
    _0 = _tok_58173;
    _tok_58173 = _45next_token();
    DeRef(_0);

    /** parser.e:2180		has_entry=0*/
    _has_entry_58175 = 0LL;

    /** parser.e:2182		if tok[T_ID] = WITH then*/
    _2 = (object)SEQ_PTR(_tok_58173);
    _29054 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29054, 420LL)){
        _29054 = NOVALUE;
        goto L1; // [27] 160
    }
    _29054 = NOVALUE;

    /** parser.e:2183			tok = next_token()*/
    _0 = _tok_58173;
    _tok_58173 = _45next_token();
    DeRef(_0);

    /** parser.e:2184			switch tok[T_ID] do*/
    _2 = (object)SEQ_PTR(_tok_58173);
    _29057 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_29057) ){
        goto L2; // [44] 140
    }
    if(!IS_ATOM_INT(_29057)){
        if( (DBL_PTR(_29057)->dbl != (eudouble) ((object) DBL_PTR(_29057)->dbl) ) ){
            goto L2; // [44] 140
        }
        _0 = (object) DBL_PTR(_29057)->dbl;
    }
    else {
        _0 = _29057;
    };
    _29057 = NOVALUE;
    switch ( _0 ){ 

        /** parser.e:2185			    case ENTRY then*/
        case 424:

        /** parser.e:2186					if not (opcode = WHILE or opcode = LOOP) then*/
        _29060 = (_opcode_58171 == 47LL);
        if (_29060 != 0) {
            DeRef(_29061);
            _29061 = 1;
            goto L3; // [61] 75
        }
        _29062 = (_opcode_58171 == 422LL);
        _29061 = (_29062 != 0);
L3: 
        if (_29061 != 0)
        goto L4; // [75] 88
        _29061 = NOVALUE;

        /** parser.e:2187						CompileErr(MSG_WITH_ENTRY_IS_ONLY_VALID_ON_A_WHILE_OR_LOOP_STATEMENT)*/
        RefDS(_21993);
        _50CompileErr(14LL, _21993, 0LL);
L4: 

        /** parser.e:2190				    has_entry = 1*/
        _has_entry_58175 = 1LL;
        goto L5; // [93] 152

        /** parser.e:2192				case FALLTHRU then*/
        case 431:

        /** parser.e:2193					if not opcode = SWITCH then*/
        _29064 = (_opcode_58171 == 0);
        if (_29064 != 185LL)
        goto L6; // [106] 120

        /** parser.e:2194						CompileErr(MSG_WITH_FALLTHRU_IS_ONLY_VALID_IN_A_SWITCH_STATEMENT)*/
        RefDS(_21993);
        _50CompileErr(13LL, _21993, 0LL);
L6: 

        /** parser.e:2197					switch_stack[$][SWITCH_FALLTHRU] = 1*/
        if (IS_SEQUENCE(_45switch_stack_55173)){
                _29066 = SEQ_PTR(_45switch_stack_55173)->length;
        }
        else {
            _29066 = 1;
        }
        _2 = (object)SEQ_PTR(_45switch_stack_55173);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _45switch_stack_55173 = MAKE_SEQ(_2);
        }
        _3 = (object)(_29066 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 1LL;
        DeRef(_1);
        _29067 = NOVALUE;
        goto L5; // [136] 152

        /** parser.e:2199				case else*/
        default:
L2: 

        /** parser.e:2200				    CompileErr(AN_UNKNOWN_WITHWITHOUT_OPTION_HAS_BEEN_SPECIFIED)*/
        RefDS(_21993);
        _50CompileErr(27LL, _21993, 0LL);
    ;}L5: 

    /** parser.e:2203	        tok = next_token()*/
    _0 = _tok_58173;
    _tok_58173 = _45next_token();
    DeRef(_0);
    goto L7; // [157] 250
L1: 

    /** parser.e:2204		elsif tok[T_ID] = WITHOUT then*/
    _2 = (object)SEQ_PTR(_tok_58173);
    _29070 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29070, 421LL)){
        _29070 = NOVALUE;
        goto L8; // [170] 249
    }
    _29070 = NOVALUE;

    /** parser.e:2205			tok = next_token()*/
    _0 = _tok_58173;
    _tok_58173 = _45next_token();
    DeRef(_0);

    /** parser.e:2206			if tok[T_ID] = FALLTHRU then*/
    _2 = (object)SEQ_PTR(_tok_58173);
    _29073 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29073, 431LL)){
        _29073 = NOVALUE;
        goto L9; // [189] 233
    }
    _29073 = NOVALUE;

    /** parser.e:2207				if not opcode = SWITCH then*/
    _29075 = (_opcode_58171 == 0);
    if (_29075 != 185LL)
    goto LA; // [200] 214

    /** parser.e:2208					CompileErr(MSG_WITHOUT_FALLTHRU_IS_ONLY_VALID_IN_A_SWITCH_STATEMENT)*/
    RefDS(_21993);
    _50CompileErr(15LL, _21993, 0LL);
LA: 

    /** parser.e:2211				switch_stack[$][SWITCH_FALLTHRU] = 0*/
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _29077 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _29077 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55173);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _45switch_stack_55173 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29077 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _29078 = NOVALUE;
    goto LB; // [230] 243
L9: 

    /** parser.e:2214				CompileErr(AN_UNKNOWN_WITHWITHOUT_OPTION_HAS_BEEN_SPECIFIED)*/
    RefDS(_21993);
    _50CompileErr(27LL, _21993, 0LL);
LB: 

    /** parser.e:2216	        tok = next_token()*/
    _0 = _tok_58173;
    _tok_58173 = _45next_token();
    DeRef(_0);
L8: 
L7: 

    /** parser.e:2219		labbel=0*/
    DeRef(_labbel_58174);
    _labbel_58174 = 0LL;

    /** parser.e:2220		if tok[T_ID]=LABEL then*/
    _2 = (object)SEQ_PTR(_tok_58173);
    _29081 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29081, 419LL)){
        _29081 = NOVALUE;
        goto LC; // [265] 329
    }
    _29081 = NOVALUE;

    /** parser.e:2221			tok = next_token()*/
    _0 = _tok_58173;
    _tok_58173 = _45next_token();
    DeRef(_0);

    /** parser.e:2222			if tok[T_ID] != STRING then*/
    _2 = (object)SEQ_PTR(_tok_58173);
    _29084 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _29084, 503LL)){
        _29084 = NOVALUE;
        goto LD; // [284] 298
    }
    _29084 = NOVALUE;

    /** parser.e:2223				CompileErr(A_LABEL_CLAUSE_MUST_BE_FOLLOWED_BY_A_LITERAL_STRING)*/
    RefDS(_21993);
    _50CompileErr(38LL, _21993, 0LL);
LD: 

    /** parser.e:2225			labbel = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_tok_58173);
    _29086 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_29086)){
        _29087 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29086)->dbl));
    }
    else{
        _29087 = (object)*(((s1_ptr)_2)->base + _29086);
    }
    DeRef(_labbel_58174);
    _2 = (object)SEQ_PTR(_29087);
    _labbel_58174 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_labbel_58174);
    _29087 = NOVALUE;

    /** parser.e:2226			block_label( labbel )*/
    Ref(_labbel_58174);
    _65block_label(_labbel_58174);

    /** parser.e:2227			tok = next_token()*/
    _0 = _tok_58173;
    _tok_58173 = _45next_token();
    DeRef(_0);
LC: 

    /** parser.e:2229		if opcode = IF or opcode = SWITCH then*/
    _29090 = (_opcode_58171 == 20LL);
    if (_29090 != 0) {
        goto LE; // [337] 352
    }
    _29092 = (_opcode_58171 == 185LL);
    if (_29092 == 0)
    {
        DeRef(_29092);
        _29092 = NOVALUE;
        goto LF; // [348] 363
    }
    else{
        DeRef(_29092);
        _29092 = NOVALUE;
    }
LE: 

    /** parser.e:2230			if_labels = append(if_labels,labbel)*/
    Ref(_labbel_58174);
    Append(&_45if_labels_54953, _45if_labels_54953, _labbel_58174);
    goto L10; // [360] 372
LF: 

    /** parser.e:2232			loop_labels = append(loop_labels,labbel)*/
    Ref(_labbel_58174);
    Append(&_45loop_labels_54952, _45loop_labels_54952, _labbel_58174);
L10: 

    /** parser.e:2234		if block_index=length(block_list) then*/
    if (IS_SEQUENCE(_45block_list_54954)){
            _29095 = SEQ_PTR(_45block_list_54954)->length;
    }
    else {
        _29095 = 1;
    }
    if (_45block_index_54955 != _29095)
    goto L11; // [381] 404

    /** parser.e:2235		    block_list &= opcode*/
    Append(&_45block_list_54954, _45block_list_54954, _opcode_58171);

    /** parser.e:2236		    block_index += 1*/
    _45block_index_54955 = _45block_index_54955 + 1;
    goto L12; // [401] 423
L11: 

    /** parser.e:2238		    block_index += 1*/
    _45block_index_54955 = _45block_index_54955 + 1;

    /** parser.e:2239		    block_list[block_index] = opcode*/
    _2 = (object)SEQ_PTR(_45block_list_54954);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _45block_list_54954 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _45block_index_54955);
    *(intptr_t *)_2 = _opcode_58171;
L12: 

    /** parser.e:2241		if tok[T_ID]=ENTRY then*/
    _2 = (object)SEQ_PTR(_tok_58173);
    _29100 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29100, 424LL)){
        _29100 = NOVALUE;
        goto L13; // [433] 463
    }
    _29100 = NOVALUE;

    /** parser.e:2242		    if has_entry then*/
    if (_has_entry_58175 == 0)
    {
        goto L14; // [439] 452
    }
    else{
    }

    /** parser.e:2243		        CompileErr(DUPLICATE_ENTRY_CLAUSE_IN_A_LOOP_HEADER)*/
    RefDS(_21993);
    _50CompileErr(64LL, _21993, 0LL);
L14: 

    /** parser.e:2245		    has_entry=1*/
    _has_entry_58175 = 1LL;

    /** parser.e:2246		    tok=next_token()*/
    _0 = _tok_58173;
    _tok_58173 = _45next_token();
    DeRef(_0);
L13: 

    /** parser.e:2248		if has_entry and (opcode = IF or opcode = SWITCH) then*/
    if (_has_entry_58175 == 0) {
        goto L15; // [465] 503
    }
    _29104 = (_opcode_58171 == 20LL);
    if (_29104 != 0) {
        DeRef(_29105);
        _29105 = 1;
        goto L16; // [475] 489
    }
    _29106 = (_opcode_58171 == 185LL);
    _29105 = (_29106 != 0);
L16: 
    if (_29105 == 0)
    {
        _29105 = NOVALUE;
        goto L15; // [490] 503
    }
    else{
        _29105 = NOVALUE;
    }

    /** parser.e:2249			CompileErr(ENTRY_KEYWORD_IS_NOT_SUPPORTED_INSIDE_AN_IF_OR_SWITCH_BLOCK_HEADER)*/
    RefDS(_21993);
    _50CompileErr(80LL, _21993, 0LL);
L15: 

    /** parser.e:2251		if opcode = IF then*/
    if (_opcode_58171 != 20LL)
    goto L17; // [507] 523

    /** parser.e:2252			opcode = THEN*/
    _opcode_58171 = 410LL;
    goto L18; // [520] 533
L17: 

    /** parser.e:2254			opcode = DO*/
    _opcode_58171 = 411LL;
L18: 

    /** parser.e:2256		putback(tok)*/
    Ref(_tok_58173);
    _45putback(_tok_58173);

    /** parser.e:2257		tok_match(opcode)*/
    _45tok_match(_opcode_58171, 0LL);

    /** parser.e:2258		return has_entry*/
    DeRef(_tok_58173);
    DeRef(_labbel_58174);
    DeRef(_29075);
    _29075 = NOVALUE;
    DeRef(_29064);
    _29064 = NOVALUE;
    DeRef(_29060);
    _29060 = NOVALUE;
    DeRef(_29106);
    _29106 = NOVALUE;
    DeRef(_29104);
    _29104 = NOVALUE;
    DeRef(_29090);
    _29090 = NOVALUE;
    DeRef(_29062);
    _29062 = NOVALUE;
    _29086 = NOVALUE;
    return _has_entry_58175;
    ;
}


void _45If_statement()
{
    object _addr_inlined_AppendEList_at_624_58429 = NOVALUE;
    object _addr_inlined_AppendEList_at_260_58358 = NOVALUE;
    object _tok_58301 = NOVALUE;
    object _prev_false_58302 = NOVALUE;
    object _prev_false2_58303 = NOVALUE;
    object _elist_base_58304 = NOVALUE;
    object _temps_58312 = NOVALUE;
    object _31687 = NOVALUE;
    object _29172 = NOVALUE;
    object _29171 = NOVALUE;
    object _29168 = NOVALUE;
    object _29167 = NOVALUE;
    object _29165 = NOVALUE;
    object _29164 = NOVALUE;
    object _29163 = NOVALUE;
    object _29161 = NOVALUE;
    object _29160 = NOVALUE;
    object _29158 = NOVALUE;
    object _29157 = NOVALUE;
    object _29156 = NOVALUE;
    object _29154 = NOVALUE;
    object _29153 = NOVALUE;
    object _29151 = NOVALUE;
    object _29150 = NOVALUE;
    object _29149 = NOVALUE;
    object _29148 = NOVALUE;
    object _29146 = NOVALUE;
    object _29145 = NOVALUE;
    object _29142 = NOVALUE;
    object _29140 = NOVALUE;
    object _29139 = NOVALUE;
    object _29138 = NOVALUE;
    object _29135 = NOVALUE;
    object _29132 = NOVALUE;
    object _29131 = NOVALUE;
    object _29129 = NOVALUE;
    object _29128 = NOVALUE;
    object _29126 = NOVALUE;
    object _29125 = NOVALUE;
    object _29123 = NOVALUE;
    object _29120 = NOVALUE;
    object _29118 = NOVALUE;
    object _29117 = NOVALUE;
    object _29116 = NOVALUE;
    object _29112 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2265		integer prev_false*/

    /** parser.e:2266		integer prev_false2*/

    /** parser.e:2267		integer elist_base*/

    /** parser.e:2269		if_stack &= IF*/
    Append(&_45if_stack_54959, _45if_stack_54959, 20LL);

    /** parser.e:2271		Start_block( IF )*/
    _65Start_block(20LL, 0LL);

    /** parser.e:2273		elist_base = length(break_list)*/
    if (IS_SEQUENCE(_45break_list_54942)){
            _elist_base_58304 = SEQ_PTR(_45break_list_54942)->length;
    }
    else {
        _elist_base_58304 = 1;
    }

    /** parser.e:2274		short_circuit += 1*/
    _45short_circuit_54924 = _45short_circuit_54924 + 1;

    /** parser.e:2275		short_circuit_B = FALSE*/
    _45short_circuit_B_54926 = _13FALSE_450;

    /** parser.e:2276		SC1_type = 0*/
    _45SC1_type_54929 = 0LL;

    /** parser.e:2277		Expr()*/
    _45Expr();

    /** parser.e:2279		sequence temps = get_temps()*/
    _31687 = Repeat(_21993, 2LL);
    _0 = _temps_58312;
    _temps_58312 = _47get_temps(_31687);
    DeRef(_0);
    _31687 = NOVALUE;

    /** parser.e:2281		emit_op(IF)*/
    _47emit_op(20LL);

    /** parser.e:2282		prev_false = length(Code)+1*/
    if (IS_SEQUENCE(_36Code_21531)){
            _29112 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29112 = 1;
    }
    _prev_false_58302 = _29112 + 1;
    _29112 = NOVALUE;

    /** parser.e:2283		emit_forward_addr() -- to be patched*/
    _45emit_forward_addr();

    /** parser.e:2284		prev_false2=finish_block_header(IF)  -- 0*/
    _prev_false2_58303 = _45finish_block_header(20LL);
    if (!IS_ATOM_INT(_prev_false2_58303)) {
        _1 = (object)(DBL_PTR(_prev_false2_58303)->dbl);
        DeRefDS(_prev_false2_58303);
        _prev_false2_58303 = _1;
    }

    /** parser.e:2285		if SC1_type = OR then*/
    if (_45SC1_type_54929 != 9LL)
    goto L1; // [106] 159

    /** parser.e:2286			backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29116 = _45SC1_patch_54928 - 3LL;
    if ((object)((uintptr_t)_29116 +(uintptr_t) HIGH_BITS) >= 0){
        _29116 = NewDouble((eudouble)_29116);
    }
    _47backpatch(_29116, 147LL);
    _29116 = NOVALUE;

    /** parser.e:2287			if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L2; // [128] 139
    }
    else{
    }

    /** parser.e:2288				emit_op(NOP1)  -- to get label here*/
    _47emit_op(159LL);
L2: 

    /** parser.e:2290			backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21531)){
            _29117 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29117 = 1;
    }
    _29118 = _29117 + 1;
    _29117 = NOVALUE;
    _47backpatch(_45SC1_patch_54928, _29118);
    _29118 = NOVALUE;
    goto L3; // [156] 192
L1: 

    /** parser.e:2291		elsif SC1_type = AND then*/
    if (_45SC1_type_54929 != 8LL)
    goto L4; // [165] 191

    /** parser.e:2292			backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29120 = _45SC1_patch_54928 - 3LL;
    if ((object)((uintptr_t)_29120 +(uintptr_t) HIGH_BITS) >= 0){
        _29120 = NewDouble((eudouble)_29120);
    }
    _47backpatch(_29120, 146LL);
    _29120 = NOVALUE;

    /** parser.e:2293			prev_false2 = SC1_patch*/
    _prev_false2_58303 = _45SC1_patch_54928;
L4: 
L3: 

    /** parser.e:2295		short_circuit -= 1*/
    _45short_circuit_54924 = _45short_circuit_54924 - 1LL;

    /** parser.e:2298		Statement_list()*/
    _45Statement_list();

    /** parser.e:2299		tok = next_token()*/
    _0 = _tok_58301;
    _tok_58301 = _45next_token();
    DeRef(_0);

    /** parser.e:2301		while tok[T_ID] = ELSIF do*/
L5: 
    _2 = (object)SEQ_PTR(_tok_58301);
    _29123 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29123, 414LL)){
        _29123 = NOVALUE;
        goto L6; // [222] 530
    }
    _29123 = NOVALUE;

    /** parser.e:2302			Sibling_block( IF )*/
    _65Sibling_block(20LL);

    /** parser.e:2305			emit_op(ELSE)*/
    _47emit_op(23LL);

    /** parser.e:2306			AppendEList(length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21531)){
            _29125 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29125 = 1;
    }
    _29126 = _29125 + 1;
    _29125 = NOVALUE;
    _addr_inlined_AppendEList_at_260_58358 = _29126;
    _29126 = NOVALUE;

    /** parser.e:393		break_list = append(break_list, addr)*/
    Append(&_45break_list_54942, _45break_list_54942, _addr_inlined_AppendEList_at_260_58358);

    /** parser.e:394	end procedure*/
    goto L7; // [266] 269
L7: 

    /** parser.e:2307			break_delay &= 1*/
    Append(&_45break_delay_54943, _45break_delay_54943, 1LL);

    /** parser.e:2308			emit_forward_addr()  -- to be patched*/
    _45emit_forward_addr();

    /** parser.e:2309			if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L8; // [287] 298
    }
    else{
    }

    /** parser.e:2310				emit_op(NOP1)*/
    _47emit_op(159LL);
L8: 

    /** parser.e:2312			backpatch(prev_false, length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21531)){
            _29128 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29128 = 1;
    }
    _29129 = _29128 + 1;
    _29128 = NOVALUE;
    _47backpatch(_prev_false_58302, _29129);
    _29129 = NOVALUE;

    /** parser.e:2313			if prev_false2 != 0 then*/
    if (_prev_false2_58303 == 0LL)
    goto L9; // [315] 335

    /** parser.e:2314				backpatch(prev_false2, length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21531)){
            _29131 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29131 = 1;
    }
    _29132 = _29131 + 1;
    _29131 = NOVALUE;
    _47backpatch(_prev_false2_58303, _29132);
    _29132 = NOVALUE;
L9: 

    /** parser.e:2317			StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:2318			short_circuit += 1*/
    _45short_circuit_54924 = _45short_circuit_54924 + 1;

    /** parser.e:2319			short_circuit_B = FALSE*/
    _45short_circuit_B_54926 = _13FALSE_450;

    /** parser.e:2320			SC1_type = 0*/
    _45SC1_type_54929 = 0LL;

    /** parser.e:2322			push_temps( temps )*/
    RefDS(_temps_58312);
    _47push_temps(_temps_58312);

    /** parser.e:2323			Expr()*/
    _45Expr();

    /** parser.e:2325			temps = get_temps( temps )*/
    RefDS(_temps_58312);
    _0 = _temps_58312;
    _temps_58312 = _47get_temps(_temps_58312);
    DeRefDS(_0);

    /** parser.e:2327			emit_op(IF)*/
    _47emit_op(20LL);

    /** parser.e:2328			prev_false = length(Code)+1*/
    if (IS_SEQUENCE(_36Code_21531)){
            _29135 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29135 = 1;
    }
    _prev_false_58302 = _29135 + 1;
    _29135 = NOVALUE;

    /** parser.e:2329			prev_false2 = 0*/
    _prev_false2_58303 = 0LL;

    /** parser.e:2330			emit_forward_addr() -- to be patched*/
    _45emit_forward_addr();

    /** parser.e:2331			if SC1_type = OR then*/
    if (_45SC1_type_54929 != 9LL)
    goto LA; // [414] 467

    /** parser.e:2332				backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29138 = _45SC1_patch_54928 - 3LL;
    if ((object)((uintptr_t)_29138 +(uintptr_t) HIGH_BITS) >= 0){
        _29138 = NewDouble((eudouble)_29138);
    }
    _47backpatch(_29138, 147LL);
    _29138 = NOVALUE;

    /** parser.e:2333				if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto LB; // [436] 447
    }
    else{
    }

    /** parser.e:2334					emit_op(NOP1)*/
    _47emit_op(159LL);
LB: 

    /** parser.e:2336				backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21531)){
            _29139 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29139 = 1;
    }
    _29140 = _29139 + 1;
    _29139 = NOVALUE;
    _47backpatch(_45SC1_patch_54928, _29140);
    _29140 = NOVALUE;
    goto LC; // [464] 500
LA: 

    /** parser.e:2337			elsif SC1_type = AND then*/
    if (_45SC1_type_54929 != 8LL)
    goto LD; // [473] 499

    /** parser.e:2338				backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29142 = _45SC1_patch_54928 - 3LL;
    if ((object)((uintptr_t)_29142 +(uintptr_t) HIGH_BITS) >= 0){
        _29142 = NewDouble((eudouble)_29142);
    }
    _47backpatch(_29142, 146LL);
    _29142 = NOVALUE;

    /** parser.e:2339				prev_false2 = SC1_patch*/
    _prev_false2_58303 = _45SC1_patch_54928;
LD: 
LC: 

    /** parser.e:2341			short_circuit -= 1*/
    _45short_circuit_54924 = _45short_circuit_54924 - 1LL;

    /** parser.e:2342			tok_match(THEN)*/
    _45tok_match(410LL, 0LL);

    /** parser.e:2345			Statement_list()*/
    _45Statement_list();

    /** parser.e:2346			tok = next_token()*/
    _0 = _tok_58301;
    _tok_58301 = _45next_token();
    DeRef(_0);

    /** parser.e:2347		end while*/
    goto L5; // [527] 214
L6: 

    /** parser.e:2349		if tok[T_ID] = ELSE or length(temps[1]) then*/
    _2 = (object)SEQ_PTR(_tok_58301);
    _29145 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_29145)) {
        _29146 = (_29145 == 23LL);
    }
    else {
        _29146 = binary_op(EQUALS, _29145, 23LL);
    }
    _29145 = NOVALUE;
    if (IS_ATOM_INT(_29146)) {
        if (_29146 != 0) {
            goto LE; // [544] 560
        }
    }
    else {
        if (DBL_PTR(_29146)->dbl != 0.0) {
            goto LE; // [544] 560
        }
    }
    _2 = (object)SEQ_PTR(_temps_58312);
    _29148 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_29148)){
            _29149 = SEQ_PTR(_29148)->length;
    }
    else {
        _29149 = 1;
    }
    _29148 = NOVALUE;
    if (_29149 == 0)
    {
        _29149 = NOVALUE;
        goto LF; // [556] 715
    }
    else{
        _29149 = NOVALUE;
    }
LE: 

    /** parser.e:2354			Sibling_block( IF )*/
    _65Sibling_block(20LL);

    /** parser.e:2356			StartSourceLine(FALSE, , COVERAGE_SUPPRESS )*/
    _47StartSourceLine(_13FALSE_450, 0LL, 1LL);

    /** parser.e:2357			emit_op(ELSE)*/
    _47emit_op(23LL);

    /** parser.e:2358			AppendEList(length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21531)){
            _29150 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29150 = 1;
    }
    _29151 = _29150 + 1;
    _29150 = NOVALUE;
    _addr_inlined_AppendEList_at_624_58429 = _29151;
    _29151 = NOVALUE;

    /** parser.e:393		break_list = append(break_list, addr)*/
    Append(&_45break_list_54942, _45break_list_54942, _addr_inlined_AppendEList_at_624_58429);

    /** parser.e:394	end procedure*/
    goto L10; // [611] 614
L10: 

    /** parser.e:2359			break_delay &= 1*/
    Append(&_45break_delay_54943, _45break_delay_54943, 1LL);

    /** parser.e:2360			emit_forward_addr() -- to be patched*/
    _45emit_forward_addr();

    /** parser.e:2361			if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L11; // [632] 643
    }
    else{
    }

    /** parser.e:2362				emit_op(NOP1)*/
    _47emit_op(159LL);
L11: 

    /** parser.e:2364			backpatch(prev_false, length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21531)){
            _29153 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29153 = 1;
    }
    _29154 = _29153 + 1;
    _29153 = NOVALUE;
    _47backpatch(_prev_false_58302, _29154);
    _29154 = NOVALUE;

    /** parser.e:2365			if prev_false2 != 0 then*/
    if (_prev_false2_58303 == 0LL)
    goto L12; // [660] 680

    /** parser.e:2366				backpatch(prev_false2, length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21531)){
            _29156 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29156 = 1;
    }
    _29157 = _29156 + 1;
    _29156 = NOVALUE;
    _47backpatch(_prev_false2_58303, _29157);
    _29157 = NOVALUE;
L12: 

    /** parser.e:2369			push_temps( temps )*/
    RefDS(_temps_58312);
    _47push_temps(_temps_58312);

    /** parser.e:2371			if tok[T_ID] = ELSE then*/
    _2 = (object)SEQ_PTR(_tok_58301);
    _29158 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29158, 23LL)){
        _29158 = NOVALUE;
        goto L13; // [695] 706
    }
    _29158 = NOVALUE;

    /** parser.e:2372				Statement_list()*/
    _45Statement_list();
    goto L14; // [703] 773
L13: 

    /** parser.e:2374				putback(tok)*/
    Ref(_tok_58301);
    _45putback(_tok_58301);
    goto L14; // [712] 773
LF: 

    /** parser.e:2377			putback(tok)*/
    Ref(_tok_58301);
    _45putback(_tok_58301);

    /** parser.e:2378			if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L15; // [724] 735
    }
    else{
    }

    /** parser.e:2379				emit_op(NOP1)*/
    _47emit_op(159LL);
L15: 

    /** parser.e:2381			backpatch(prev_false, length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21531)){
            _29160 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29160 = 1;
    }
    _29161 = _29160 + 1;
    _29160 = NOVALUE;
    _47backpatch(_prev_false_58302, _29161);
    _29161 = NOVALUE;

    /** parser.e:2382			if prev_false2 != 0 then*/
    if (_prev_false2_58303 == 0LL)
    goto L16; // [752] 772

    /** parser.e:2383				backpatch(prev_false2, length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21531)){
            _29163 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29163 = 1;
    }
    _29164 = _29163 + 1;
    _29163 = NOVALUE;
    _47backpatch(_prev_false2_58303, _29164);
    _29164 = NOVALUE;
L16: 
L14: 

    /** parser.e:2387		tok_match(END)*/
    _45tok_match(402LL, 0LL);

    /** parser.e:2388		tok_match(IF, END)*/
    _45tok_match(20LL, 402LL);

    /** parser.e:2390		End_block( IF )*/
    _65End_block(20LL);

    /** parser.e:2392		if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L17; // [802] 825
    }
    else{
    }

    /** parser.e:2393			if length(break_list) > elist_base then*/
    if (IS_SEQUENCE(_45break_list_54942)){
            _29165 = SEQ_PTR(_45break_list_54942)->length;
    }
    else {
        _29165 = 1;
    }
    if (_29165 <= _elist_base_58304)
    goto L18; // [812] 824

    /** parser.e:2394				emit_op(NOP1)  -- to emit label here*/
    _47emit_op(159LL);
L18: 
L17: 

    /** parser.e:2397		PatchEList(elist_base)*/
    _45PatchEList(_elist_base_58304);

    /** parser.e:2398		if_labels = if_labels[1..$-1]*/
    if (IS_SEQUENCE(_45if_labels_54953)){
            _29167 = SEQ_PTR(_45if_labels_54953)->length;
    }
    else {
        _29167 = 1;
    }
    _29168 = _29167 - 1LL;
    _29167 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45if_labels_54953;
    RHS_Slice(_45if_labels_54953, 1LL, _29168);

    /** parser.e:2399		block_index -= 1*/
    _45block_index_54955 = _45block_index_54955 - 1LL;

    /** parser.e:2400		if_stack = if_stack[1..$-1]*/
    if (IS_SEQUENCE(_45if_stack_54959)){
            _29171 = SEQ_PTR(_45if_stack_54959)->length;
    }
    else {
        _29171 = 1;
    }
    _29172 = _29171 - 1LL;
    _29171 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45if_stack_54959;
    RHS_Slice(_45if_stack_54959, 1LL, _29172);

    /** parser.e:2402	end procedure*/
    DeRef(_tok_58301);
    DeRef(_temps_58312);
    DeRef(_29146);
    _29146 = NOVALUE;
    _29148 = NOVALUE;
    _29168 = NOVALUE;
    _29172 = NOVALUE;
    return;
    ;
}


void _45exit_loop(object _exit_base_58489)
{
    object _29187 = NOVALUE;
    object _29186 = NOVALUE;
    object _29184 = NOVALUE;
    object _29183 = NOVALUE;
    object _29181 = NOVALUE;
    object _29180 = NOVALUE;
    object _29178 = NOVALUE;
    object _29177 = NOVALUE;
    object _29175 = NOVALUE;
    object _29174 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2405		PatchXList(exit_base)*/
    _45PatchXList(_exit_base_58489);

    /** parser.e:2406		loop_labels = loop_labels[1..$-1]*/
    if (IS_SEQUENCE(_45loop_labels_54952)){
            _29174 = SEQ_PTR(_45loop_labels_54952)->length;
    }
    else {
        _29174 = 1;
    }
    _29175 = _29174 - 1LL;
    _29174 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45loop_labels_54952;
    RHS_Slice(_45loop_labels_54952, 1LL, _29175);

    /** parser.e:2407		loop_stack = loop_stack[1..$-1]*/
    if (IS_SEQUENCE(_45loop_stack_54958)){
            _29177 = SEQ_PTR(_45loop_stack_54958)->length;
    }
    else {
        _29177 = 1;
    }
    _29178 = _29177 - 1LL;
    _29177 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45loop_stack_54958;
    RHS_Slice(_45loop_stack_54958, 1LL, _29178);

    /** parser.e:2408		continue_addr = continue_addr[1..$-1]*/
    if (IS_SEQUENCE(_45continue_addr_54949)){
            _29180 = SEQ_PTR(_45continue_addr_54949)->length;
    }
    else {
        _29180 = 1;
    }
    _29181 = _29180 - 1LL;
    _29180 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45continue_addr_54949;
    RHS_Slice(_45continue_addr_54949, 1LL, _29181);

    /** parser.e:2409		retry_addr = retry_addr[1..$-1]*/
    if (IS_SEQUENCE(_45retry_addr_54950)){
            _29183 = SEQ_PTR(_45retry_addr_54950)->length;
    }
    else {
        _29183 = 1;
    }
    _29184 = _29183 - 1LL;
    _29183 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45retry_addr_54950;
    RHS_Slice(_45retry_addr_54950, 1LL, _29184);

    /** parser.e:2410		entry_addr = entry_addr[1..$-1]*/
    if (IS_SEQUENCE(_45entry_addr_54948)){
            _29186 = SEQ_PTR(_45entry_addr_54948)->length;
    }
    else {
        _29186 = 1;
    }
    _29187 = _29186 - 1LL;
    _29186 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45entry_addr_54948;
    RHS_Slice(_45entry_addr_54948, 1LL, _29187);

    /** parser.e:2411		block_index -= 1*/
    _45block_index_54955 = _45block_index_54955 - 1LL;

    /** parser.e:2412	end procedure*/
    _29175 = NOVALUE;
    _29181 = NOVALUE;
    _29187 = NOVALUE;
    _29184 = NOVALUE;
    _29178 = NOVALUE;
    return;
    ;
}


void _45push_switch()
{
    object _new_1__tmp_at14_58512 = NOVALUE;
    object _new_inlined_new_at_14_58511 = NOVALUE;
    object _29191 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2415		if_stack &= SWITCH*/
    Append(&_45if_stack_54959, _45if_stack_54959, 185LL);

    /** parser.e:2416		switch_stack = append( switch_stack,*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at14_58512;
    _new_1__tmp_at14_58512 = _29new_map_seq(8LL);
    DeRef(_0);
    Ref(_new_1__tmp_at14_58512);
    _0 = _new_inlined_new_at_14_58511;
    _new_inlined_new_at_14_58511 = _30malloc(_new_1__tmp_at14_58512, 1LL);
    DeRef(_0);
    DeRef(_new_1__tmp_at14_58512);
    _new_1__tmp_at14_58512 = NOVALUE;
    _1 = NewS1(13);
    _2 = (object)((s1_ptr)_1)->base;
    RefDSn(_21993, 2);
    ((intptr_t*)_2)[1] = _21993;
    ((intptr_t*)_2)[2] = _21993;
    ((intptr_t*)_2)[3] = 0LL;
    ((intptr_t*)_2)[4] = 0LL;
    ((intptr_t*)_2)[5] = 0LL;
    ((intptr_t*)_2)[6] = 0LL;
    Ref(_new_inlined_new_at_14_58511);
    ((intptr_t*)_2)[7] = _new_inlined_new_at_14_58511;
    RefDS(_21993);
    ((intptr_t*)_2)[8] = _21993;
    ((intptr_t*)_2)[9] = 0LL;
    RefDSn(_21993, 4);
    ((intptr_t*)_2)[10] = _21993;
    ((intptr_t*)_2)[11] = _21993;
    ((intptr_t*)_2)[12] = _21993;
    ((intptr_t*)_2)[13] = _21993;
    _29191 = MAKE_SEQ(_1);
    RefDS(_29191);
    Append(&_45switch_stack_55173, _45switch_stack_55173, _29191);
    DeRefDS(_29191);
    _29191 = NOVALUE;

    /** parser.e:2433	end procedure*/
    return;
    ;
}


void _45pop_switch(object _break_base_58517)
{
    object _29206 = NOVALUE;
    object _29205 = NOVALUE;
    object _29203 = NOVALUE;
    object _29202 = NOVALUE;
    object _29200 = NOVALUE;
    object _29199 = NOVALUE;
    object _29197 = NOVALUE;
    object _29196 = NOVALUE;
    object _29195 = NOVALUE;
    object _29194 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2438		PatchEList( break_base )*/
    _45PatchEList(_break_base_58517);

    /** parser.e:2439		block_index -= 1*/
    _45block_index_54955 = _45block_index_54955 - 1LL;

    /** parser.e:2440		if length(switch_stack[$][SWITCH_CASES]) > 0 then*/
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _29194 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _29194 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55173);
    _29195 = (object)*(((s1_ptr)_2)->base + _29194);
    _2 = (object)SEQ_PTR(_29195);
    _29196 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29195 = NOVALUE;
    if (IS_SEQUENCE(_29196)){
            _29197 = SEQ_PTR(_29196)->length;
    }
    else {
        _29197 = 1;
    }
    _29196 = NOVALUE;
    if (_29197 <= 0LL)
    goto L1; // [34] 46

    /** parser.e:2441			End_block( CASE )*/
    _65End_block(186LL);
L1: 

    /** parser.e:2443		if_labels = if_labels[1..$-1]*/
    if (IS_SEQUENCE(_45if_labels_54953)){
            _29199 = SEQ_PTR(_45if_labels_54953)->length;
    }
    else {
        _29199 = 1;
    }
    _29200 = _29199 - 1LL;
    _29199 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45if_labels_54953;
    RHS_Slice(_45if_labels_54953, 1LL, _29200);

    /** parser.e:2444		if_stack  = if_stack[1..$-1]*/
    if (IS_SEQUENCE(_45if_stack_54959)){
            _29202 = SEQ_PTR(_45if_stack_54959)->length;
    }
    else {
        _29202 = 1;
    }
    _29203 = _29202 - 1LL;
    _29202 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45if_stack_54959;
    RHS_Slice(_45if_stack_54959, 1LL, _29203);

    /** parser.e:2445		switch_stack  = switch_stack[1..$-1]*/
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _29205 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _29205 = 1;
    }
    _29206 = _29205 - 1LL;
    _29205 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45switch_stack_55173;
    RHS_Slice(_45switch_stack_55173, 1LL, _29206);

    /** parser.e:2446	end procedure*/
    _29200 = NOVALUE;
    _29203 = NOVALUE;
    _29206 = NOVALUE;
    _29196 = NOVALUE;
    return;
    ;
}


void _45add_case(object _sym_58538, object _sign_58539)
{
    object _29253 = NOVALUE;
    object _29252 = NOVALUE;
    object _29251 = NOVALUE;
    object _29250 = NOVALUE;
    object _29249 = NOVALUE;
    object _29248 = NOVALUE;
    object _29246 = NOVALUE;
    object _29245 = NOVALUE;
    object _29244 = NOVALUE;
    object _29243 = NOVALUE;
    object _29241 = NOVALUE;
    object _29240 = NOVALUE;
    object _29239 = NOVALUE;
    object _29238 = NOVALUE;
    object _29236 = NOVALUE;
    object _29235 = NOVALUE;
    object _29234 = NOVALUE;
    object _29233 = NOVALUE;
    object _29232 = NOVALUE;
    object _29230 = NOVALUE;
    object _29229 = NOVALUE;
    object _29228 = NOVALUE;
    object _29227 = NOVALUE;
    object _29226 = NOVALUE;
    object _29225 = NOVALUE;
    object _29223 = NOVALUE;
    object _29222 = NOVALUE;
    object _29221 = NOVALUE;
    object _29220 = NOVALUE;
    object _29219 = NOVALUE;
    object _29218 = NOVALUE;
    object _29216 = NOVALUE;
    object _29215 = NOVALUE;
    object _29213 = NOVALUE;
    object _29212 = NOVALUE;
    object _29211 = NOVALUE;
    object _29210 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2450		if sign < 0 then*/
    if (_sign_58539 >= 0LL)
    goto L1; // [5] 15

    /** parser.e:2451			sym = -sym*/
    _0 = _sym_58538;
    if (IS_ATOM_INT(_sym_58538)) {
        if ((uintptr_t)_sym_58538 == (uintptr_t)HIGH_BITS){
            _sym_58538 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _sym_58538 = - _sym_58538;
        }
    }
    else {
        _sym_58538 = unary_op(UMINUS, _sym_58538);
    }
    DeRefi(_0);
L1: 

    /** parser.e:2454		if find(sym, switch_stack[$][SWITCH_CASES] ) = 0 then*/
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _29210 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _29210 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55173);
    _29211 = (object)*(((s1_ptr)_2)->base + _29210);
    _2 = (object)SEQ_PTR(_29211);
    _29212 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29211 = NOVALUE;
    _29213 = find_from(_sym_58538, _29212, 1LL);
    _29212 = NOVALUE;
    if (_29213 != 0LL)
    goto L2; // [35] 252

    /** parser.e:2455			switch_stack[$][SWITCH_CASES]            = append( switch_stack[$][SWITCH_CASES], sym )*/
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _29215 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _29215 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55173);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _45switch_stack_55173 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29215 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _29218 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _29218 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55173);
    _29219 = (object)*(((s1_ptr)_2)->base + _29218);
    _2 = (object)SEQ_PTR(_29219);
    _29220 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29219 = NOVALUE;
    Ref(_sym_58538);
    Append(&_29221, _29220, _sym_58538);
    _29220 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29221;
    if( _1 != _29221 ){
        DeRef(_1);
    }
    _29221 = NOVALUE;
    _29216 = NOVALUE;

    /** parser.e:2456			switch_stack[$][SWITCH_JUMP_TABLE]      &= length(Code) + 1*/
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _29222 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _29222 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55173);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _45switch_stack_55173 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29222 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_36Code_21531)){
            _29225 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29225 = 1;
    }
    _29226 = _29225 + 1;
    _29225 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29227 = (object)*(((s1_ptr)_2)->base + 2LL);
    _29223 = NOVALUE;
    if (IS_SEQUENCE(_29227) && IS_ATOM(_29226)) {
        Append(&_29228, _29227, _29226);
    }
    else if (IS_ATOM(_29227) && IS_SEQUENCE(_29226)) {
    }
    else {
        Concat((object_ptr)&_29228, _29227, _29226);
        _29227 = NOVALUE;
    }
    _29227 = NOVALUE;
    _29226 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29228;
    if( _1 != _29228 ){
        DeRef(_1);
    }
    _29228 = NOVALUE;
    _29223 = NOVALUE;

    /** parser.e:2457			switch_stack[$][SWITCH_THISLINE]        &= {ThisLine}*/
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _29229 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _29229 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55173);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _45switch_stack_55173 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29229 + ((s1_ptr)_2)->base);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_50ThisLine_49234);
    ((intptr_t*)_2)[1] = _50ThisLine_49234;
    _29232 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29233 = (object)*(((s1_ptr)_2)->base + 10LL);
    _29230 = NOVALUE;
    if (IS_SEQUENCE(_29233) && IS_ATOM(_29232)) {
    }
    else if (IS_ATOM(_29233) && IS_SEQUENCE(_29232)) {
        Ref(_29233);
        Prepend(&_29234, _29232, _29233);
    }
    else {
        Concat((object_ptr)&_29234, _29233, _29232);
        _29233 = NOVALUE;
    }
    _29233 = NOVALUE;
    DeRefDS(_29232);
    _29232 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29234;
    if( _1 != _29234 ){
        DeRef(_1);
    }
    _29234 = NOVALUE;
    _29230 = NOVALUE;

    /** parser.e:2458			switch_stack[$][SWITCH_BP]              &= bp*/
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _29235 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _29235 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55173);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _45switch_stack_55173 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29235 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29238 = (object)*(((s1_ptr)_2)->base + 11LL);
    _29236 = NOVALUE;
    if (IS_SEQUENCE(_29238) && IS_ATOM(_50bp_49238)) {
        Append(&_29239, _29238, _50bp_49238);
    }
    else if (IS_ATOM(_29238) && IS_SEQUENCE(_50bp_49238)) {
    }
    else {
        Concat((object_ptr)&_29239, _29238, _50bp_49238);
        _29238 = NOVALUE;
    }
    _29238 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29239;
    if( _1 != _29239 ){
        DeRef(_1);
    }
    _29239 = NOVALUE;
    _29236 = NOVALUE;

    /** parser.e:2459			switch_stack[$][SWITCH_LINE_NUMBER]     &= line_number*/
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _29240 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _29240 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55173);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _45switch_stack_55173 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29240 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29243 = (object)*(((s1_ptr)_2)->base + 12LL);
    _29241 = NOVALUE;
    if (IS_SEQUENCE(_29243) && IS_ATOM(_36line_number_21440)) {
        Append(&_29244, _29243, _36line_number_21440);
    }
    else if (IS_ATOM(_29243) && IS_SEQUENCE(_36line_number_21440)) {
    }
    else {
        Concat((object_ptr)&_29244, _29243, _36line_number_21440);
        _29243 = NOVALUE;
    }
    _29243 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29244;
    if( _1 != _29244 ){
        DeRef(_1);
    }
    _29244 = NOVALUE;
    _29241 = NOVALUE;

    /** parser.e:2460			switch_stack[$][SWITCH_CURRENT_FILE_NO] &= current_file_no*/
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _29245 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _29245 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55173);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _45switch_stack_55173 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29245 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29248 = (object)*(((s1_ptr)_2)->base + 13LL);
    _29246 = NOVALUE;
    if (IS_SEQUENCE(_29248) && IS_ATOM(_36current_file_no_21439)) {
        Append(&_29249, _29248, _36current_file_no_21439);
    }
    else if (IS_ATOM(_29248) && IS_SEQUENCE(_36current_file_no_21439)) {
    }
    else {
        Concat((object_ptr)&_29249, _29248, _36current_file_no_21439);
        _29248 = NOVALUE;
    }
    _29248 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 13LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29249;
    if( _1 != _29249 ){
        DeRef(_1);
    }
    _29249 = NOVALUE;
    _29246 = NOVALUE;

    /** parser.e:2462			if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L3; // [217] 262
    }
    else{
    }

    /** parser.e:2463				emit_addr( CASE )*/
    _47emit_addr(186LL);

    /** parser.e:2464				emit_addr( length( switch_stack[$][SWITCH_CASES] ) )*/
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _29250 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _29250 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55173);
    _29251 = (object)*(((s1_ptr)_2)->base + _29250);
    _2 = (object)SEQ_PTR(_29251);
    _29252 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29251 = NOVALUE;
    if (IS_SEQUENCE(_29252)){
            _29253 = SEQ_PTR(_29252)->length;
    }
    else {
        _29253 = 1;
    }
    _29252 = NOVALUE;
    _47emit_addr(_29253);
    _29253 = NOVALUE;
    goto L3; // [249] 262
L2: 

    /** parser.e:2467			CompileErr( DUPLICATE_CASE_VALUE_USED)*/
    RefDS(_21993);
    _50CompileErr(63LL, _21993, 0LL);
L3: 

    /** parser.e:2469	end procedure*/
    DeRef(_sym_58538);
    _29252 = NOVALUE;
    return;
    ;
}


void _45case_else()
{
    object _29261 = NOVALUE;
    object _29260 = NOVALUE;
    object _29258 = NOVALUE;
    object _29257 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2476		switch_stack[$][SWITCH_ELSE] = length(Code) + 1*/
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _29257 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _29257 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55173);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _45switch_stack_55173 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29257 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_36Code_21531)){
            _29260 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29260 = 1;
    }
    _29261 = _29260 + 1;
    _29260 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29261;
    if( _1 != _29261 ){
        DeRef(_1);
    }
    _29261 = NOVALUE;
    _29258 = NOVALUE;

    /** parser.e:2477		if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L1; // [30] 46
    }
    else{
    }

    /** parser.e:2478			emit_addr( CASE )*/
    _47emit_addr(186LL);

    /** parser.e:2479			emit_addr( 0 )*/
    _47emit_addr(0LL);
L1: 

    /** parser.e:2482	end procedure*/
    return;
    ;
}


void _45Case_statement()
{
    object _else_case_2__tmp_at147_58662 = NOVALUE;
    object _else_case_1__tmp_at147_58661 = NOVALUE;
    object _else_case_inlined_else_case_at_147_58660 = NOVALUE;
    object _tok_58623 = NOVALUE;
    object _condition_58625 = NOVALUE;
    object _start_line_58655 = NOVALUE;
    object _sign_58667 = NOVALUE;
    object _fwd_58680 = NOVALUE;
    object _symi_58690 = NOVALUE;
    object _fwdref_58762 = NOVALUE;
    object _31686 = NOVALUE;
    object _29343 = NOVALUE;
    object _29342 = NOVALUE;
    object _29341 = NOVALUE;
    object _29340 = NOVALUE;
    object _29339 = NOVALUE;
    object _29338 = NOVALUE;
    object _29336 = NOVALUE;
    object _29335 = NOVALUE;
    object _29334 = NOVALUE;
    object _29333 = NOVALUE;
    object _29332 = NOVALUE;
    object _29331 = NOVALUE;
    object _29329 = NOVALUE;
    object _29326 = NOVALUE;
    object _29323 = NOVALUE;
    object _29322 = NOVALUE;
    object _29321 = NOVALUE;
    object _29320 = NOVALUE;
    object _29317 = NOVALUE;
    object _29316 = NOVALUE;
    object _29315 = NOVALUE;
    object _29314 = NOVALUE;
    object _29311 = NOVALUE;
    object _29310 = NOVALUE;
    object _29309 = NOVALUE;
    object _29308 = NOVALUE;
    object _29306 = NOVALUE;
    object _29305 = NOVALUE;
    object _29304 = NOVALUE;
    object _29302 = NOVALUE;
    object _29301 = NOVALUE;
    object _29300 = NOVALUE;
    object _29299 = NOVALUE;
    object _29298 = NOVALUE;
    object _29296 = NOVALUE;
    object _29295 = NOVALUE;
    object _29293 = NOVALUE;
    object _29292 = NOVALUE;
    object _29291 = NOVALUE;
    object _29290 = NOVALUE;
    object _29286 = NOVALUE;
    object _29285 = NOVALUE;
    object _29284 = NOVALUE;
    object _29281 = NOVALUE;
    object _29278 = NOVALUE;
    object _29275 = NOVALUE;
    object _29274 = NOVALUE;
    object _29273 = NOVALUE;
    object _29272 = NOVALUE;
    object _29271 = NOVALUE;
    object _29270 = NOVALUE;
    object _29269 = NOVALUE;
    object _29267 = NOVALUE;
    object _29266 = NOVALUE;
    object _29265 = NOVALUE;
    object _29264 = NOVALUE;
    object _29262 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2489		if not in_switch() then*/
    _29262 = _45in_switch();
    if (IS_ATOM_INT(_29262)) {
        if (_29262 != 0){
            DeRef(_29262);
            _29262 = NOVALUE;
            goto L1; // [6] 19
        }
    }
    else {
        if (DBL_PTR(_29262)->dbl != 0.0){
            DeRef(_29262);
            _29262 = NOVALUE;
            goto L1; // [6] 19
        }
    }
    DeRef(_29262);
    _29262 = NOVALUE;

    /** parser.e:2490			CompileErr( A_CASE_MUST_BE_INSIDE_A_SWITCH)*/
    RefDS(_21993);
    _50CompileErr(34LL, _21993, 0LL);
L1: 

    /** parser.e:2493		if length(switch_stack[$][SWITCH_CASES]) > 0 then*/
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _29264 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _29264 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55173);
    _29265 = (object)*(((s1_ptr)_2)->base + _29264);
    _2 = (object)SEQ_PTR(_29265);
    _29266 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29265 = NOVALUE;
    if (IS_SEQUENCE(_29266)){
            _29267 = SEQ_PTR(_29266)->length;
    }
    else {
        _29267 = 1;
    }
    _29266 = NOVALUE;
    if (_29267 <= 0LL)
    goto L2; // [37] 103

    /** parser.e:2495			Sibling_block( CASE )*/
    _65Sibling_block(186LL);

    /** parser.e:2497			if not switch_stack[$][SWITCH_FALLTHRU] and*/
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _29269 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _29269 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55173);
    _29270 = (object)*(((s1_ptr)_2)->base + _29269);
    _2 = (object)SEQ_PTR(_29270);
    _29271 = (object)*(((s1_ptr)_2)->base + 5LL);
    _29270 = NOVALUE;
    if (IS_ATOM_INT(_29271)) {
        _29272 = (_29271 == 0);
    }
    else {
        _29272 = unary_op(NOT, _29271);
    }
    _29271 = NOVALUE;
    if (IS_ATOM_INT(_29272)) {
        if (_29272 == 0) {
            goto L3; // [66] 112
        }
    }
    else {
        if (DBL_PTR(_29272)->dbl == 0.0) {
            goto L3; // [66] 112
        }
    }
    _29274 = (_45fallthru_case_58619 == 0);
    if (_29274 == 0)
    {
        DeRef(_29274);
        _29274 = NOVALUE;
        goto L3; // [76] 112
    }
    else{
        DeRef(_29274);
        _29274 = NOVALUE;
    }

    /** parser.e:2501				putback( {CASE, 0} )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 186LL;
    ((intptr_t *)_2)[2] = 0LL;
    _29275 = MAKE_SEQ(_1);
    _45putback(_29275);
    _29275 = NOVALUE;

    /** parser.e:2502				Break_statement()*/
    _45Break_statement();

    /** parser.e:2503				tok = next_token()*/
    _0 = _tok_58623;
    _tok_58623 = _45next_token();
    DeRef(_0);
    goto L3; // [100] 112
L2: 

    /** parser.e:2506			Start_block( CASE )*/
    _65Start_block(186LL, 0LL);
L3: 

    /** parser.e:2509		StartSourceLine(TRUE, , COVERAGE_SUPPRESS)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 1LL);

    /** parser.e:2511		fallthru_case = 0*/
    _45fallthru_case_58619 = 0LL;

    /** parser.e:2512		integer start_line = line_number*/
    _start_line_58655 = _36line_number_21440;

    /** parser.e:2513		while 1 do*/
L4: 

    /** parser.e:2515			if else_case() then*/

    /** parser.e:2472		return switch_stack[$][SWITCH_ELSE]*/
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _else_case_1__tmp_at147_58661 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _else_case_1__tmp_at147_58661 = 1;
    }
    DeRef(_else_case_2__tmp_at147_58662);
    _2 = (object)SEQ_PTR(_45switch_stack_55173);
    _else_case_2__tmp_at147_58662 = (object)*(((s1_ptr)_2)->base + _else_case_1__tmp_at147_58661);
    RefDS(_else_case_2__tmp_at147_58662);
    DeRef(_else_case_inlined_else_case_at_147_58660);
    _2 = (object)SEQ_PTR(_else_case_2__tmp_at147_58662);
    _else_case_inlined_else_case_at_147_58660 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_else_case_inlined_else_case_at_147_58660);
    DeRef(_else_case_2__tmp_at147_58662);
    _else_case_2__tmp_at147_58662 = NOVALUE;
    if (_else_case_inlined_else_case_at_147_58660 == 0) {
        goto L5; // [162] 175
    }
    else {
        if (!IS_ATOM_INT(_else_case_inlined_else_case_at_147_58660) && DBL_PTR(_else_case_inlined_else_case_at_147_58660)->dbl == 0.0){
            goto L5; // [162] 175
        }
    }

    /** parser.e:2516				CompileErr( A_CASE_BLOCK_CANNOT_FOLLOW_A_CASE_ELSE_BLOCK)*/
    RefDS(_21993);
    _50CompileErr(33LL, _21993, 0LL);
L5: 

    /** parser.e:2518			maybe_namespace()*/
    _62maybe_namespace();

    /** parser.e:2519			tok = next_token()*/
    _0 = _tok_58623;
    _tok_58623 = _45next_token();
    DeRef(_0);

    /** parser.e:2520			integer sign = 1*/
    _sign_58667 = 1LL;

    /** parser.e:2521			if tok[T_ID] = MINUS then*/
    _2 = (object)SEQ_PTR(_tok_58623);
    _29278 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29278, 10LL)){
        _29278 = NOVALUE;
        goto L6; // [199] 216
    }
    _29278 = NOVALUE;

    /** parser.e:2522				sign = -1*/
    _sign_58667 = -1LL;

    /** parser.e:2523				tok = next_token()*/
    _0 = _tok_58623;
    _tok_58623 = _45next_token();
    DeRef(_0);
    goto L7; // [213] 237
L6: 

    /** parser.e:2524			elsif tok[T_ID] = PLUS then*/
    _2 = (object)SEQ_PTR(_tok_58623);
    _29281 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29281, 11LL)){
        _29281 = NOVALUE;
        goto L8; // [226] 236
    }
    _29281 = NOVALUE;

    /** parser.e:2525				tok = next_token()*/
    _0 = _tok_58623;
    _tok_58623 = _45next_token();
    DeRef(_0);
L8: 
L7: 

    /** parser.e:2528			integer fwd*/

    /** parser.e:2529			if not find( tok[T_ID], {ATOM, STRING, ELSE} ) then*/
    _2 = (object)SEQ_PTR(_tok_58623);
    _29284 = (object)*(((s1_ptr)_2)->base + 1LL);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 502LL;
    ((intptr_t*)_2)[2] = 503LL;
    ((intptr_t*)_2)[3] = 23LL;
    _29285 = MAKE_SEQ(_1);
    _29286 = find_from(_29284, _29285, 1LL);
    _29284 = NOVALUE;
    DeRefDS(_29285);
    _29285 = NOVALUE;
    if (_29286 != 0)
    goto L9; // [264] 439
    _29286 = NOVALUE;

    /** parser.e:2531				integer symi = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_58623);
    _symi_58690 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_symi_58690)){
        _symi_58690 = (object)DBL_PTR(_symi_58690)->dbl;
    }

    /** parser.e:2532				fwd = -1*/
    _fwd_58680 = -1LL;

    /** parser.e:2533				if symi > 0 then*/
    if (_symi_58690 <= 0LL)
    goto LA; // [284] 434

    /** parser.e:2534					if find(tok[T_ID] , VAR_TOKS) then*/
    _2 = (object)SEQ_PTR(_tok_58623);
    _29290 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29291 = find_from(_29290, _38VAR_TOKS_16055, 1LL);
    _29290 = NOVALUE;
    if (_29291 == 0)
    {
        _29291 = NOVALUE;
        goto LB; // [303] 433
    }
    else{
        _29291 = NOVALUE;
    }

    /** parser.e:2535						if SymTab[symi][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29292 = (object)*(((s1_ptr)_2)->base + _symi_58690);
    _2 = (object)SEQ_PTR(_29292);
    _29293 = (object)*(((s1_ptr)_2)->base + 4LL);
    _29292 = NOVALUE;
    if (binary_op_a(NOTEQ, _29293, 9LL)){
        _29293 = NOVALUE;
        goto LC; // [322] 334
    }
    _29293 = NOVALUE;

    /** parser.e:2537							fwd = symi*/
    _fwd_58680 = _symi_58690;
    goto LD; // [331] 432
LC: 

    /** parser.e:2538						elsif SymTab[symi][S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29295 = (object)*(((s1_ptr)_2)->base + _symi_58690);
    _2 = (object)SEQ_PTR(_29295);
    _29296 = (object)*(((s1_ptr)_2)->base + 3LL);
    _29295 = NOVALUE;
    if (binary_op_a(NOTEQ, _29296, 2LL)){
        _29296 = NOVALUE;
        goto LE; // [350] 431
    }
    _29296 = NOVALUE;

    /** parser.e:2539							fwd = 0*/
    _fwd_58680 = 0LL;

    /** parser.e:2540							if SymTab[symi][S_CODE] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29298 = (object)*(((s1_ptr)_2)->base + _symi_58690);
    _2 = (object)SEQ_PTR(_29298);
    if (!IS_ATOM_INT(_36S_CODE_21088)){
        _29299 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
    }
    else{
        _29299 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21088);
    }
    _29298 = NOVALUE;
    if (_29299 == 0) {
        _29299 = NOVALUE;
        goto LF; // [373] 397
    }
    else {
        if (!IS_ATOM_INT(_29299) && DBL_PTR(_29299)->dbl == 0.0){
            _29299 = NOVALUE;
            goto LF; // [373] 397
        }
        _29299 = NOVALUE;
    }
    _29299 = NOVALUE;

    /** parser.e:2541								tok[T_SYM] = SymTab[symi][S_CODE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29300 = (object)*(((s1_ptr)_2)->base + _symi_58690);
    _2 = (object)SEQ_PTR(_29300);
    if (!IS_ATOM_INT(_36S_CODE_21088)){
        _29301 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
    }
    else{
        _29301 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21088);
    }
    _29300 = NOVALUE;
    Ref(_29301);
    _2 = (object)SEQ_PTR(_tok_58623);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_58623 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29301;
    if( _1 != _29301 ){
        DeRef(_1);
    }
    _29301 = NOVALUE;
LF: 

    /** parser.e:2543							SymTab[symi][S_USAGE] = or_bits( SymTab[symi][S_USAGE], U_READ )*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_symi_58690 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29304 = (object)*(((s1_ptr)_2)->base + _symi_58690);
    _2 = (object)SEQ_PTR(_29304);
    _29305 = (object)*(((s1_ptr)_2)->base + 5LL);
    _29304 = NOVALUE;
    if (IS_ATOM_INT(_29305)) {
        {uintptr_t tu;
             tu = (uintptr_t)_29305 | (uintptr_t)1LL;
             _29306 = MAKE_UINT(tu);
        }
    }
    else {
        _29306 = binary_op(OR_BITS, _29305, 1LL);
    }
    _29305 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29306;
    if( _1 != _29306 ){
        DeRef(_1);
    }
    _29306 = NOVALUE;
    _29302 = NOVALUE;
LE: 
LD: 
LB: 
LA: 
    goto L10; // [436] 445
L9: 

    /** parser.e:2548				fwd = 0*/
    _fwd_58680 = 0LL;
L10: 

    /** parser.e:2551			if fwd < 0 then*/
    if (_fwd_58680 >= 0LL)
    goto L11; // [449] 477

    /** parser.e:2552				CompileErr( FOUND_1_BUT_EXPECTED_ELSE_AN_ATOM_STRING_CONSTANT_OR_ENUM, {find_category(tok[T_ID])})*/
    _2 = (object)SEQ_PTR(_tok_58623);
    _29308 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_29308);
    _29309 = _63find_category(_29308);
    _29308 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _29309;
    _29310 = MAKE_SEQ(_1);
    _29309 = NOVALUE;
    _50CompileErr(91LL, _29310, 0LL);
    _29310 = NOVALUE;
L11: 

    /** parser.e:2555			if tok[T_ID] = ELSE then*/
    _2 = (object)SEQ_PTR(_tok_58623);
    _29311 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29311, 23LL)){
        _29311 = NOVALUE;
        goto L12; // [487] 552
    }
    _29311 = NOVALUE;

    /** parser.e:2556				if sign = -1 then*/
    if (_sign_58667 != -1LL)
    goto L13; // [493] 507

    /** parser.e:2557					CompileErr( EXPECTED_AN_ATOM_STRING_OR_A_CONSTANT_ASSIGNED_AN_ATOM_OR_A_STRING)*/
    RefDS(_21993);
    _50CompileErr(71LL, _21993, 0LL);
L13: 

    /** parser.e:2559				if length(switch_stack[$][SWITCH_CASES]) = 0 then*/
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _29314 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _29314 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55173);
    _29315 = (object)*(((s1_ptr)_2)->base + _29314);
    _2 = (object)SEQ_PTR(_29315);
    _29316 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29315 = NOVALUE;
    if (IS_SEQUENCE(_29316)){
            _29317 = SEQ_PTR(_29316)->length;
    }
    else {
        _29317 = 1;
    }
    _29316 = NOVALUE;
    if (_29317 != 0LL)
    goto L14; // [525] 539

    /** parser.e:2560					CompileErr( CASE_ELSE_CANNOT_BE_FIRST_CASE_IN_SWITCH)*/
    RefDS(_21993);
    _50CompileErr(44LL, _21993, 0LL);
L14: 

    /** parser.e:2562				case_else()*/
    _45case_else();

    /** parser.e:2563				exit*/
    goto L15; // [547] 789
    goto L16; // [549] 623
L12: 

    /** parser.e:2565			elsif fwd then*/
    if (_fwd_58680 == 0)
    {
        goto L17; // [554] 606
    }
    else{
    }

    /** parser.e:2566				integer fwdref = new_forward_reference( CASE, fwd )*/
    DeRef(_31686);
    _31686 = 186LL;
    _fwdref_58762 = _44new_forward_reference(186LL, _fwd_58680, 186LL);
    _31686 = NOVALUE;
    if (!IS_ATOM_INT(_fwdref_58762)) {
        _1 = (object)(DBL_PTR(_fwdref_58762)->dbl);
        DeRefDS(_fwdref_58762);
        _fwdref_58762 = _1;
    }

    /** parser.e:2567				add_case( {fwdref}, sign )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _fwdref_58762;
    _29320 = MAKE_SEQ(_1);
    _45add_case(_29320, _sign_58667);
    _29320 = NOVALUE;

    /** parser.e:2568				fwd:set_data( fwdref, switch_stack[$][SWITCH_PC] )*/
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _29321 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _29321 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55173);
    _29322 = (object)*(((s1_ptr)_2)->base + _29321);
    _2 = (object)SEQ_PTR(_29322);
    _29323 = (object)*(((s1_ptr)_2)->base + 4LL);
    _29322 = NOVALUE;
    Ref(_29323);
    _44set_data(_fwdref_58762, _29323);
    _29323 = NOVALUE;
    goto L16; // [603] 623
L17: 

    /** parser.e:2571				condition = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_58623);
    _condition_58625 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_condition_58625)){
        _condition_58625 = (object)DBL_PTR(_condition_58625)->dbl;
    }

    /** parser.e:2572				add_case( condition, sign )*/
    _45add_case(_condition_58625, _sign_58667);
L16: 

    /** parser.e:2575			tok = next_token()*/
    _0 = _tok_58623;
    _tok_58623 = _45next_token();
    DeRef(_0);

    /** parser.e:2576			if tok[T_ID] = THEN then*/
    _2 = (object)SEQ_PTR(_tok_58623);
    _29326 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29326, 410LL)){
        _29326 = NOVALUE;
        goto L18; // [638] 742
    }
    _29326 = NOVALUE;

    /** parser.e:2577				tok = next_token()*/
    _0 = _tok_58623;
    _tok_58623 = _45next_token();
    DeRef(_0);

    /** parser.e:2579				if tok[T_ID] = CASE then*/
    _2 = (object)SEQ_PTR(_tok_58623);
    _29329 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29329, 186LL)){
        _29329 = NOVALUE;
        goto L19; // [657] 727
    }
    _29329 = NOVALUE;

    /** parser.e:2580					if switch_stack[$][SWITCH_FALLTHRU] then*/
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _29331 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _29331 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55173);
    _29332 = (object)*(((s1_ptr)_2)->base + _29331);
    _2 = (object)SEQ_PTR(_29332);
    _29333 = (object)*(((s1_ptr)_2)->base + 5LL);
    _29332 = NOVALUE;
    if (_29333 == 0) {
        _29333 = NOVALUE;
        goto L1A; // [676] 691
    }
    else {
        if (!IS_ATOM_INT(_29333) && DBL_PTR(_29333)->dbl == 0.0){
            _29333 = NOVALUE;
            goto L1A; // [676] 691
        }
        _29333 = NOVALUE;
    }
    _29333 = NOVALUE;

    /** parser.e:2581						start_line = line_number*/
    _start_line_58655 = _36line_number_21440;
    goto L1B; // [688] 782
L1A: 

    /** parser.e:2583						putback( tok )*/
    Ref(_tok_58623);
    _45putback(_tok_58623);

    /** parser.e:2584						Warning(220, empty_case_warning_flag,*/
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _29334 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
    Ref(_29334);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _29334;
    ((intptr_t *)_2)[2] = _start_line_58655;
    _29335 = MAKE_SEQ(_1);
    _29334 = NOVALUE;
    _50Warning(220LL, 2048LL, _29335);
    _29335 = NOVALUE;

    /** parser.e:2586						exit*/
    goto L15; // [721] 789
    goto L1B; // [724] 782
L19: 

    /** parser.e:2589					putback( tok )*/
    Ref(_tok_58623);
    _45putback(_tok_58623);

    /** parser.e:2590					exit*/
    goto L15; // [736] 789
    goto L1B; // [739] 782
L18: 

    /** parser.e:2593			elsif tok[T_ID] != COMMA then*/
    _2 = (object)SEQ_PTR(_tok_58623);
    _29336 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _29336, -30LL)){
        _29336 = NOVALUE;
        goto L1C; // [752] 781
    }
    _29336 = NOVALUE;

    /** parser.e:2594				CompileErr(EXPECTED_THEN_OR__NOT_1,{LexName(tok[T_ID])})*/
    _2 = (object)SEQ_PTR(_tok_58623);
    _29338 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_29338);
    RefDS(_26329);
    _29339 = _47LexName(_29338, _26329);
    _29338 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _29339;
    _29340 = MAKE_SEQ(_1);
    _29339 = NOVALUE;
    _50CompileErr(66LL, _29340, 0LL);
    _29340 = NOVALUE;
L1C: 
L1B: 

    /** parser.e:2597		end while*/
    goto L4; // [786] 142
L15: 

    /** parser.e:2598		StartSourceLine( TRUE )*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:2599		emit_temp( switch_stack[$][SWITCH_VALUE], NEW_REFERENCE )*/
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _29341 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _29341 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55173);
    _29342 = (object)*(((s1_ptr)_2)->base + _29341);
    _2 = (object)SEQ_PTR(_29342);
    _29343 = (object)*(((s1_ptr)_2)->base + 6LL);
    _29342 = NOVALUE;
    Ref(_29343);
    _47emit_temp(_29343, 1LL);
    _29343 = NOVALUE;

    /** parser.e:2600		flush_temps()*/
    RefDS(_21993);
    _47flush_temps(_21993);

    /** parser.e:2601	end procedure*/
    DeRef(_tok_58623);
    _29266 = NOVALUE;
    _29316 = NOVALUE;
    DeRef(_29272);
    _29272 = NOVALUE;
    return;
    ;
}


void _45Fallthru_statement()
{
    object _29344 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2604		if not in_switch() then*/
    _29344 = _45in_switch();
    if (IS_ATOM_INT(_29344)) {
        if (_29344 != 0){
            DeRef(_29344);
            _29344 = NOVALUE;
            goto L1; // [6] 19
        }
    }
    else {
        if (DBL_PTR(_29344)->dbl != 0.0){
            DeRef(_29344);
            _29344 = NOVALUE;
            goto L1; // [6] 19
        }
    }
    DeRef(_29344);
    _29344 = NOVALUE;

    /** parser.e:2605			CompileErr( A_FALLTHRU_MUST_BE_INSIDE_A_SWITCH)*/
    RefDS(_21993);
    _50CompileErr(22LL, _21993, 0LL);
L1: 

    /** parser.e:2607		tok_match( CASE )*/
    _45tok_match(186LL, 0LL);

    /** parser.e:2608		fallthru_case = 1*/
    _45fallthru_case_58619 = 1LL;

    /** parser.e:2609		Case_statement()*/
    _45Case_statement();

    /** parser.e:2610	end procedure*/
    return;
    ;
}


void _45update_translator_info(object _sym_58830, object _all_ints_58831, object _has_integer_58832, object _has_atom_58833, object _has_sequence_58834)
{
    object _29369 = NOVALUE;
    object _29367 = NOVALUE;
    object _29365 = NOVALUE;
    object _29363 = NOVALUE;
    object _29361 = NOVALUE;
    object _29360 = NOVALUE;
    object _29358 = NOVALUE;
    object _29356 = NOVALUE;
    object _29355 = NOVALUE;
    object _29354 = NOVALUE;
    object _29353 = NOVALUE;
    object _29352 = NOVALUE;
    object _29350 = NOVALUE;
    object _29348 = NOVALUE;
    object _29346 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2615		SymTab[sym][S_MODE] = M_TEMP    -- override CONSTANT for compile*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_58830 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3LL;
    DeRef(_1);
    _29346 = NOVALUE;

    /** parser.e:2616		SymTab[sym][S_GTYPE] = TYPE_SEQUENCE*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_58830 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 8LL;
    DeRef(_1);
    _29348 = NOVALUE;

    /** parser.e:2617		SymTab[sym][S_SEQ_LEN] = length( SymTab[sym][S_OBJ] )*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_58830 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29352 = (object)*(((s1_ptr)_2)->base + _sym_58830);
    _2 = (object)SEQ_PTR(_29352);
    _29353 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29352 = NOVALUE;
    if (IS_SEQUENCE(_29353)){
            _29354 = SEQ_PTR(_29353)->length;
    }
    else {
        _29354 = 1;
    }
    _29353 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29354;
    if( _1 != _29354 ){
        DeRef(_1);
    }
    _29354 = NOVALUE;
    _29350 = NOVALUE;

    /** parser.e:2619		if SymTab[sym][S_SEQ_LEN] > 0 then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29355 = (object)*(((s1_ptr)_2)->base + _sym_58830);
    _2 = (object)SEQ_PTR(_29355);
    _29356 = (object)*(((s1_ptr)_2)->base + 32LL);
    _29355 = NOVALUE;
    if (binary_op_a(LESSEQ, _29356, 0LL)){
        _29356 = NOVALUE;
        goto L1; // [89] 198
    }
    _29356 = NOVALUE;

    /** parser.e:2620			if all_ints then*/
    if (_all_ints_58831 == 0)
    {
        goto L2; // [95] 118
    }
    else{
    }

    /** parser.e:2621				SymTab[sym][S_SEQ_ELEM] = TYPE_INTEGER*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_58830 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _29358 = NOVALUE;
    goto L3; // [115] 216
L2: 

    /** parser.e:2623			elsif has_atom + has_sequence + has_integer > 1 then*/
    _29360 = _has_atom_58833 + _has_sequence_58834;
    if ((object)((uintptr_t)_29360 + (uintptr_t)HIGH_BITS) >= 0){
        _29360 = NewDouble((eudouble)_29360);
    }
    if (IS_ATOM_INT(_29360)) {
        _29361 = _29360 + _has_integer_58832;
        if ((object)((uintptr_t)_29361 + (uintptr_t)HIGH_BITS) >= 0){
            _29361 = NewDouble((eudouble)_29361);
        }
    }
    else {
        _29361 = NewDouble(DBL_PTR(_29360)->dbl + (eudouble)_has_integer_58832);
    }
    DeRef(_29360);
    _29360 = NOVALUE;
    if (binary_op_a(LESSEQ, _29361, 1LL)){
        DeRef(_29361);
        _29361 = NOVALUE;
        goto L4; // [128] 152
    }
    DeRef(_29361);
    _29361 = NOVALUE;

    /** parser.e:2624				SymTab[sym][S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_58830 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);
    _29363 = NOVALUE;
    goto L3; // [149] 216
L4: 

    /** parser.e:2626			elsif has_atom then*/
    if (_has_atom_58833 == 0)
    {
        goto L5; // [154] 177
    }
    else{
    }

    /** parser.e:2627				SymTab[sym][S_SEQ_ELEM] = TYPE_ATOM*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_58830 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 4LL;
    DeRef(_1);
    _29365 = NOVALUE;
    goto L3; // [174] 216
L5: 

    /** parser.e:2630				SymTab[sym][S_SEQ_ELEM] = TYPE_SEQUENCE*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_58830 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 8LL;
    DeRef(_1);
    _29367 = NOVALUE;
    goto L3; // [195] 216
L1: 

    /** parser.e:2634			SymTab[sym][S_SEQ_ELEM] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_58830 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _29369 = NOVALUE;
L3: 

    /** parser.e:2636	end procedure*/
    _29353 = NOVALUE;
    return;
    ;
}


void _45optimize_switch(object _switch_pc_58895, object _else_bp_58896, object _cases_58897, object _jump_table_58898)
{
    object _values_58899 = NOVALUE;
    object _min_58903 = NOVALUE;
    object _max_58905 = NOVALUE;
    object _all_ints_58907 = NOVALUE;
    object _has_integer_58908 = NOVALUE;
    object _has_atom_58909 = NOVALUE;
    object _has_sequence_58910 = NOVALUE;
    object _has_unassigned_58911 = NOVALUE;
    object _has_fwdref_58912 = NOVALUE;
    object _unique_values_58913 = NOVALUE;
    object _unique_jumps_58915 = NOVALUE;
    object _new_1__tmp_at74_58918 = NOVALUE;
    object _new_inlined_new_at_74_58917 = NOVALUE;
    object _jump_58919 = NOVALUE;
    object _jump_offset_58923 = NOVALUE;
    object _sym_58930 = NOVALUE;
    object _sign_58932 = NOVALUE;
    object _value_i_58945 = NOVALUE;
    object _v_58969 = NOVALUE;
    object _else_target_59055 = NOVALUE;
    object _opcode_59058 = NOVALUE;
    object _delta_59064 = NOVALUE;
    object _switch_table_59074 = NOVALUE;
    object _offset_59077 = NOVALUE;
    object _29483 = NOVALUE;
    object _29482 = NOVALUE;
    object _29481 = NOVALUE;
    object _29480 = NOVALUE;
    object _29478 = NOVALUE;
    object _29476 = NOVALUE;
    object _29473 = NOVALUE;
    object _29472 = NOVALUE;
    object _29471 = NOVALUE;
    object _29470 = NOVALUE;
    object _29469 = NOVALUE;
    object _29468 = NOVALUE;
    object _29467 = NOVALUE;
    object _29464 = NOVALUE;
    object _29463 = NOVALUE;
    object _29462 = NOVALUE;
    object _29461 = NOVALUE;
    object _29460 = NOVALUE;
    object _29459 = NOVALUE;
    object _29455 = NOVALUE;
    object _29454 = NOVALUE;
    object _29452 = NOVALUE;
    object _29451 = NOVALUE;
    object _29450 = NOVALUE;
    object _29449 = NOVALUE;
    object _29448 = NOVALUE;
    object _29447 = NOVALUE;
    object _29446 = NOVALUE;
    object _29445 = NOVALUE;
    object _29444 = NOVALUE;
    object _29443 = NOVALUE;
    object _29441 = NOVALUE;
    object _29440 = NOVALUE;
    object _29436 = NOVALUE;
    object _29434 = NOVALUE;
    object _29433 = NOVALUE;
    object _29432 = NOVALUE;
    object _29430 = NOVALUE;
    object _29427 = NOVALUE;
    object _29426 = NOVALUE;
    object _29425 = NOVALUE;
    object _29423 = NOVALUE;
    object _29422 = NOVALUE;
    object _29421 = NOVALUE;
    object _29419 = NOVALUE;
    object _29418 = NOVALUE;
    object _29417 = NOVALUE;
    object _29415 = NOVALUE;
    object _29414 = NOVALUE;
    object _29413 = NOVALUE;
    object _29411 = NOVALUE;
    object _29408 = NOVALUE;
    object _29407 = NOVALUE;
    object _29406 = NOVALUE;
    object _29405 = NOVALUE;
    object _29404 = NOVALUE;
    object _29403 = NOVALUE;
    object _29402 = NOVALUE;
    object _29401 = NOVALUE;
    object _29400 = NOVALUE;
    object _29399 = NOVALUE;
    object _29398 = NOVALUE;
    object _29397 = NOVALUE;
    object _29394 = NOVALUE;
    object _29393 = NOVALUE;
    object _29392 = NOVALUE;
    object _29390 = NOVALUE;
    object _29389 = NOVALUE;
    object _29387 = NOVALUE;
    object _29386 = NOVALUE;
    object _29385 = NOVALUE;
    object _29381 = NOVALUE;
    object _29380 = NOVALUE;
    object _29379 = NOVALUE;
    object _29377 = NOVALUE;
    object _29376 = NOVALUE;
    object _29372 = NOVALUE;
    object _29371 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2641		sequence values = switch_stack[$][SWITCH_CASES]*/
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _29371 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _29371 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55173);
    _29372 = (object)*(((s1_ptr)_2)->base + _29371);
    DeRef(_values_58899);
    _2 = (object)SEQ_PTR(_29372);
    _values_58899 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_values_58899);
    _29372 = NOVALUE;

    /** parser.e:2642		atom min =  1e+300*/
    RefDS(_29374);
    DeRef(_min_58903);
    _min_58903 = _29374;

    /** parser.e:2643		atom max = -1e+300*/
    RefDS(_29375);
    DeRef(_max_58905);
    _max_58905 = _29375;

    /** parser.e:2644		integer all_ints = 1*/
    _all_ints_58907 = 1LL;

    /** parser.e:2645		integer has_integer    = 0*/
    _has_integer_58908 = 0LL;

    /** parser.e:2646		integer has_atom       = 0*/
    _has_atom_58909 = 0LL;

    /** parser.e:2647		integer has_sequence   = 0*/
    _has_sequence_58910 = 0LL;

    /** parser.e:2648		integer has_unassigned = 0*/
    _has_unassigned_58911 = 0LL;

    /** parser.e:2649		integer has_fwdref     = 0*/
    _has_fwdref_58912 = 0LL;

    /** parser.e:2650		sequence unique_values = {}*/
    RefDS(_21993);
    DeRef(_unique_values_58913);
    _unique_values_58913 = _21993;

    /** parser.e:2651		map unique_jumps = map:new()*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at74_58918;
    _new_1__tmp_at74_58918 = _29new_map_seq(8LL);
    DeRef(_0);
    Ref(_new_1__tmp_at74_58918);
    _0 = _unique_jumps_58915;
    _unique_jumps_58915 = _30malloc(_new_1__tmp_at74_58918, 1LL);
    DeRef(_0);
    DeRef(_new_1__tmp_at74_58918);
    _new_1__tmp_at74_58918 = NOVALUE;

    /** parser.e:2653		sequence jump = switch_stack[$][SWITCH_JUMP_TABLE]*/
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _29376 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _29376 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55173);
    _29377 = (object)*(((s1_ptr)_2)->base + _29376);
    DeRef(_jump_58919);
    _2 = (object)SEQ_PTR(_29377);
    _jump_58919 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_jump_58919);
    _29377 = NOVALUE;

    /** parser.e:2654		integer jump_offset = 0*/
    _jump_offset_58923 = 0LL;

    /** parser.e:2655		for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_58899)){
            _29379 = SEQ_PTR(_values_58899)->length;
    }
    else {
        _29379 = 1;
    }
    {
        object _i_58925;
        _i_58925 = 1LL;
L1: 
        if (_i_58925 > _29379){
            goto L2; // [116] 586
        }

        /** parser.e:2656			if sequence( values[i] ) then*/
        _2 = (object)SEQ_PTR(_values_58899);
        _29380 = (object)*(((s1_ptr)_2)->base + _i_58925);
        _29381 = IS_SEQUENCE(_29380);
        _29380 = NOVALUE;
        if (_29381 == 0)
        {
            _29381 = NOVALUE;
            goto L3; // [132] 145
        }
        else{
            _29381 = NOVALUE;
        }

        /** parser.e:2657				has_fwdref = 1*/
        _has_fwdref_58912 = 1LL;

        /** parser.e:2658				exit*/
        goto L2; // [142] 586
L3: 

        /** parser.e:2660			integer sym = values[i]*/
        _2 = (object)SEQ_PTR(_values_58899);
        _sym_58930 = (object)*(((s1_ptr)_2)->base + _i_58925);
        if (!IS_ATOM_INT(_sym_58930))
        _sym_58930 = (object)DBL_PTR(_sym_58930)->dbl;

        /** parser.e:2661			integer sign*/

        /** parser.e:2663			if sym < 0 then*/
        if (_sym_58930 >= 0LL)
        goto L4; // [155] 174

        /** parser.e:2664				sign = -1*/
        _sign_58932 = -1LL;

        /** parser.e:2665				sym = -sym*/
        _sym_58930 = - _sym_58930;
        goto L5; // [171] 180
L4: 

        /** parser.e:2667				sign = 1*/
        _sign_58932 = 1LL;
L5: 

        /** parser.e:2669			if not equal(SymTab[sym][S_OBJ], NOVALUE) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _29385 = (object)*(((s1_ptr)_2)->base + _sym_58930);
        _2 = (object)SEQ_PTR(_29385);
        _29386 = (object)*(((s1_ptr)_2)->base + 1LL);
        _29385 = NOVALUE;
        if (_29386 == _36NOVALUE_21293)
        _29387 = 1;
        else if (IS_ATOM_INT(_29386) && IS_ATOM_INT(_36NOVALUE_21293))
        _29387 = 0;
        else
        _29387 = (compare(_29386, _36NOVALUE_21293) == 0);
        _29386 = NOVALUE;
        if (_29387 != 0)
        goto L6; // [200] 565
        _29387 = NOVALUE;

        /** parser.e:2670				object value_i = sign * SymTab[sym][S_OBJ]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _29389 = (object)*(((s1_ptr)_2)->base + _sym_58930);
        _2 = (object)SEQ_PTR(_29389);
        _29390 = (object)*(((s1_ptr)_2)->base + 1LL);
        _29389 = NOVALUE;
        DeRef(_value_i_58945);
        if (IS_ATOM_INT(_29390)) {
            {
                int128_t p128 = (int128_t)_sign_58932 * (int128_t)_29390;
                if( p128 != (int128_t)(_value_i_58945 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                    _value_i_58945 = NewDouble( (eudouble)p128 );
                }
            }
        }
        else {
            _value_i_58945 = binary_op(MULTIPLY, _sign_58932, _29390);
        }
        _29390 = NOVALUE;

        /** parser.e:2671				values[i] = value_i*/
        Ref(_value_i_58945);
        _2 = (object)SEQ_PTR(_values_58899);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _values_58899 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_58925);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _value_i_58945;
        DeRef(_1);

        /** parser.e:2672				if TRANSLATE then*/
        if (_36TRANSLATE_21041 == 0)
        {
            goto L7; // [233] 274
        }
        else{
        }

        /** parser.e:2673					if Code[jump[i]-2] = CASE then*/
        _2 = (object)SEQ_PTR(_jump_58919);
        _29392 = (object)*(((s1_ptr)_2)->base + _i_58925);
        if (IS_ATOM_INT(_29392)) {
            _29393 = _29392 - 2LL;
        }
        else {
            _29393 = binary_op(MINUS, _29392, 2LL);
        }
        _29392 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21531);
        if (!IS_ATOM_INT(_29393)){
            _29394 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29393)->dbl));
        }
        else{
            _29394 = (object)*(((s1_ptr)_2)->base + _29393);
        }
        if (binary_op_a(NOTEQ, _29394, 186LL)){
            _29394 = NOVALUE;
            goto L8; // [254] 267
        }
        _29394 = NOVALUE;

        /** parser.e:2674						jump_offset -=2*/
        _jump_offset_58923 = _jump_offset_58923 - 2LL;
        goto L9; // [264] 273
L8: 

        /** parser.e:2676						jump_offset = 0*/
        _jump_offset_58923 = 0LL;
L9: 
L7: 

        /** parser.e:2680				if find( value_i, map:get( unique_jumps, jump[i] + jump_offset, {}) ) then*/
        _2 = (object)SEQ_PTR(_jump_58919);
        _29397 = (object)*(((s1_ptr)_2)->base + _i_58925);
        if (IS_ATOM_INT(_29397)) {
            _29398 = _29397 + _jump_offset_58923;
            if ((object)((uintptr_t)_29398 + (uintptr_t)HIGH_BITS) >= 0){
                _29398 = NewDouble((eudouble)_29398);
            }
        }
        else {
            _29398 = binary_op(PLUS, _29397, _jump_offset_58923);
        }
        _29397 = NOVALUE;
        Ref(_unique_jumps_58915);
        RefDS(_21993);
        _29399 = _29get(_unique_jumps_58915, _29398, _21993);
        _29398 = NOVALUE;
        _29400 = find_from(_value_i_58945, _29399, 1LL);
        DeRef(_29399);
        _29399 = NOVALUE;
        if (_29400 == 0)
        {
            _29400 = NOVALUE;
            goto LA; // [295] 301
        }
        else{
            _29400 = NOVALUE;
        }
        goto LB; // [298] 560
LA: 

        /** parser.e:2683				elsif find( value_i, unique_values ) then*/
        _29401 = find_from(_value_i_58945, _unique_values_58913, 1LL);
        if (_29401 == 0)
        {
            _29401 = NOVALUE;
            goto LC; // [308] 467
        }
        else{
            _29401 = NOVALUE;
        }

        /** parser.e:2686					object v = ""*/
        RefDS(_21993);
        DeRef(_v_58969);
        _v_58969 = _21993;

        /** parser.e:2687					if length( SymTab[sym] ) > S_NAME and sequence( sym_name( sym ) ) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _29402 = (object)*(((s1_ptr)_2)->base + _sym_58930);
        if (IS_SEQUENCE(_29402)){
                _29403 = SEQ_PTR(_29402)->length;
        }
        else {
            _29403 = 1;
        }
        _29402 = NOVALUE;
        if (IS_ATOM_INT(_36S_NAME_21076)) {
            _29404 = (_29403 > _36S_NAME_21076);
        }
        else {
            _29404 = binary_op(GREATER, _29403, _36S_NAME_21076);
        }
        _29403 = NOVALUE;
        if (IS_ATOM_INT(_29404)) {
            if (_29404 == 0) {
                goto LD; // [333] 359
            }
        }
        else {
            if (DBL_PTR(_29404)->dbl == 0.0) {
                goto LD; // [333] 359
            }
        }
        _29406 = _54sym_name(_sym_58930);
        _29407 = IS_SEQUENCE(_29406);
        DeRef(_29406);
        _29406 = NOVALUE;
        if (_29407 == 0)
        {
            _29407 = NOVALUE;
            goto LD; // [345] 359
        }
        else{
            _29407 = NOVALUE;
        }

        /** parser.e:2688						v = sym_name( sym ) & " = " */
        _29408 = _54sym_name(_sym_58930);
        if (IS_SEQUENCE(_29408) && IS_ATOM(_29409)) {
        }
        else if (IS_ATOM(_29408) && IS_SEQUENCE(_29409)) {
            Ref(_29408);
            Prepend(&_v_58969, _29409, _29408);
        }
        else {
            Concat((object_ptr)&_v_58969, _29408, _29409);
            DeRef(_29408);
            _29408 = NOVALUE;
        }
        DeRef(_29408);
        _29408 = NOVALUE;
LD: 

        /** parser.e:2691					v &= sprint( value_i )*/
        Ref(_value_i_58945);
        _29411 = _14sprint(_value_i_58945);
        if (IS_SEQUENCE(_v_58969) && IS_ATOM(_29411)) {
            Ref(_29411);
            Append(&_v_58969, _v_58969, _29411);
        }
        else if (IS_ATOM(_v_58969) && IS_SEQUENCE(_29411)) {
            Ref(_v_58969);
            Prepend(&_v_58969, _29411, _v_58969);
        }
        else {
            Concat((object_ptr)&_v_58969, _v_58969, _29411);
        }
        DeRef(_29411);
        _29411 = NOVALUE;

        /** parser.e:2692					ThisLine        = switch_stack[$][SWITCH_THISLINE][i]*/
        if (IS_SEQUENCE(_45switch_stack_55173)){
                _29413 = SEQ_PTR(_45switch_stack_55173)->length;
        }
        else {
            _29413 = 1;
        }
        _2 = (object)SEQ_PTR(_45switch_stack_55173);
        _29414 = (object)*(((s1_ptr)_2)->base + _29413);
        _2 = (object)SEQ_PTR(_29414);
        _29415 = (object)*(((s1_ptr)_2)->base + 10LL);
        _29414 = NOVALUE;
        DeRef(_50ThisLine_49234);
        _2 = (object)SEQ_PTR(_29415);
        _50ThisLine_49234 = (object)*(((s1_ptr)_2)->base + _i_58925);
        Ref(_50ThisLine_49234);
        _29415 = NOVALUE;

        /** parser.e:2693					bp              = switch_stack[$][SWITCH_BP][i]*/
        if (IS_SEQUENCE(_45switch_stack_55173)){
                _29417 = SEQ_PTR(_45switch_stack_55173)->length;
        }
        else {
            _29417 = 1;
        }
        _2 = (object)SEQ_PTR(_45switch_stack_55173);
        _29418 = (object)*(((s1_ptr)_2)->base + _29417);
        _2 = (object)SEQ_PTR(_29418);
        _29419 = (object)*(((s1_ptr)_2)->base + 11LL);
        _29418 = NOVALUE;
        _2 = (object)SEQ_PTR(_29419);
        _50bp_49238 = (object)*(((s1_ptr)_2)->base + _i_58925);
        if (!IS_ATOM_INT(_50bp_49238)){
            _50bp_49238 = (object)DBL_PTR(_50bp_49238)->dbl;
        }
        _29419 = NOVALUE;

        /** parser.e:2694					line_number     = switch_stack[$][SWITCH_LINE_NUMBER][i]*/
        if (IS_SEQUENCE(_45switch_stack_55173)){
                _29421 = SEQ_PTR(_45switch_stack_55173)->length;
        }
        else {
            _29421 = 1;
        }
        _2 = (object)SEQ_PTR(_45switch_stack_55173);
        _29422 = (object)*(((s1_ptr)_2)->base + _29421);
        _2 = (object)SEQ_PTR(_29422);
        _29423 = (object)*(((s1_ptr)_2)->base + 12LL);
        _29422 = NOVALUE;
        _2 = (object)SEQ_PTR(_29423);
        _36line_number_21440 = (object)*(((s1_ptr)_2)->base + _i_58925);
        if (!IS_ATOM_INT(_36line_number_21440)){
            _36line_number_21440 = (object)DBL_PTR(_36line_number_21440)->dbl;
        }
        _29423 = NOVALUE;

        /** parser.e:2695					current_file_no = switch_stack[$][SWITCH_CURRENT_FILE_NO][i]*/
        if (IS_SEQUENCE(_45switch_stack_55173)){
                _29425 = SEQ_PTR(_45switch_stack_55173)->length;
        }
        else {
            _29425 = 1;
        }
        _2 = (object)SEQ_PTR(_45switch_stack_55173);
        _29426 = (object)*(((s1_ptr)_2)->base + _29425);
        _2 = (object)SEQ_PTR(_29426);
        _29427 = (object)*(((s1_ptr)_2)->base + 13LL);
        _29426 = NOVALUE;
        _2 = (object)SEQ_PTR(_29427);
        _36current_file_no_21439 = (object)*(((s1_ptr)_2)->base + _i_58925);
        if (!IS_ATOM_INT(_36current_file_no_21439)){
            _36current_file_no_21439 = (object)DBL_PTR(_36current_file_no_21439)->dbl;
        }
        _29427 = NOVALUE;

        /** parser.e:2697					CompileErr("duplicate case value used in switch: [1]", {v})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_v_58969);
        ((intptr_t*)_2)[1] = _v_58969;
        _29430 = MAKE_SEQ(_1);
        RefDS(_29429);
        _50CompileErr(_29429, _29430, 0LL);
        _29430 = NOVALUE;
        DeRefDS(_v_58969);
        _v_58969 = NOVALUE;
        goto LB; // [464] 560
LC: 

        /** parser.e:2700					unique_values   &= value_i*/
        if (IS_SEQUENCE(_unique_values_58913) && IS_ATOM(_value_i_58945)) {
            Ref(_value_i_58945);
            Append(&_unique_values_58913, _unique_values_58913, _value_i_58945);
        }
        else if (IS_ATOM(_unique_values_58913) && IS_SEQUENCE(_value_i_58945)) {
        }
        else {
            Concat((object_ptr)&_unique_values_58913, _unique_values_58913, _value_i_58945);
        }

        /** parser.e:2701					map:put( unique_jumps, jump[i] + jump_offset, value_i, map:APPEND )*/
        _2 = (object)SEQ_PTR(_jump_58919);
        _29432 = (object)*(((s1_ptr)_2)->base + _i_58925);
        if (IS_ATOM_INT(_29432)) {
            _29433 = _29432 + _jump_offset_58923;
            if ((object)((uintptr_t)_29433 + (uintptr_t)HIGH_BITS) >= 0){
                _29433 = NewDouble((eudouble)_29433);
            }
        }
        else {
            _29433 = binary_op(PLUS, _29432, _jump_offset_58923);
        }
        _29432 = NOVALUE;
        Ref(_unique_jumps_58915);
        Ref(_value_i_58945);
        _29put(_unique_jumps_58915, _29433, _value_i_58945, 6LL, 0LL);
        _29433 = NOVALUE;

        /** parser.e:2703					if not is_integer( value_i ) then*/
        Ref(_value_i_58945);
        _29434 = _36is_integer(_value_i_58945);
        if (IS_ATOM_INT(_29434)) {
            if (_29434 != 0){
                DeRef(_29434);
                _29434 = NOVALUE;
                goto LE; // [496] 529
            }
        }
        else {
            if (DBL_PTR(_29434)->dbl != 0.0){
                DeRef(_29434);
                _29434 = NOVALUE;
                goto LE; // [496] 529
            }
        }
        DeRef(_29434);
        _29434 = NOVALUE;

        /** parser.e:2704						all_ints = 0*/
        _all_ints_58907 = 0LL;

        /** parser.e:2705						if atom( value_i ) then*/
        _29436 = IS_ATOM(_value_i_58945);
        if (_29436 == 0)
        {
            _29436 = NOVALUE;
            goto LF; // [509] 520
        }
        else{
            _29436 = NOVALUE;
        }

        /** parser.e:2706							has_atom = 1*/
        _has_atom_58909 = 1LL;
        goto L10; // [517] 559
LF: 

        /** parser.e:2708							has_sequence = 1*/
        _has_sequence_58910 = 1LL;
        goto L10; // [526] 559
LE: 

        /** parser.e:2711						has_integer = 1*/
        _has_integer_58908 = 1LL;

        /** parser.e:2713						if value_i < min then*/
        if (binary_op_a(GREATEREQ, _value_i_58945, _min_58903)){
            goto L11; // [536] 546
        }

        /** parser.e:2714							min = value_i*/
        Ref(_value_i_58945);
        DeRef(_min_58903);
        _min_58903 = _value_i_58945;
L11: 

        /** parser.e:2717						if value_i > max then*/
        if (binary_op_a(LESSEQ, _value_i_58945, _max_58905)){
            goto L12; // [548] 558
        }

        /** parser.e:2718							max = value_i*/
        Ref(_value_i_58945);
        DeRef(_max_58905);
        _max_58905 = _value_i_58945;
L12: 
L10: 
LB: 
        DeRef(_value_i_58945);
        _value_i_58945 = NOVALUE;
        goto L13; // [562] 577
L6: 

        /** parser.e:2723				has_unassigned = 1*/
        _has_unassigned_58911 = 1LL;

        /** parser.e:2724				exit*/
        goto L2; // [574] 586
L13: 

        /** parser.e:2726		end for*/
        _i_58925 = _i_58925 + 1LL;
        goto L1; // [581] 123
L2: 
        ;
    }

    /** parser.e:2728		if has_unassigned or has_fwdref then*/
    if (_has_unassigned_58911 != 0) {
        goto L14; // [588] 597
    }
    if (_has_fwdref_58912 == 0)
    {
        goto L15; // [593] 615
    }
    else{
    }
L14: 

    /** parser.e:2729			values = switch_stack[$][SWITCH_CASES]*/
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _29440 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _29440 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55173);
    _29441 = (object)*(((s1_ptr)_2)->base + _29440);
    DeRef(_values_58899);
    _2 = (object)SEQ_PTR(_29441);
    _values_58899 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_values_58899);
    _29441 = NOVALUE;
L15: 

    /** parser.e:2732		if switch_stack[$][SWITCH_ELSE] then*/
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _29443 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _29443 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55173);
    _29444 = (object)*(((s1_ptr)_2)->base + _29443);
    _2 = (object)SEQ_PTR(_29444);
    _29445 = (object)*(((s1_ptr)_2)->base + 3LL);
    _29444 = NOVALUE;
    if (_29445 == 0) {
        _29445 = NOVALUE;
        goto L16; // [630] 657
    }
    else {
        if (!IS_ATOM_INT(_29445) && DBL_PTR(_29445)->dbl == 0.0){
            _29445 = NOVALUE;
            goto L16; // [630] 657
        }
        _29445 = NOVALUE;
    }
    _29445 = NOVALUE;

    /** parser.e:2733				Code[else_bp] = switch_stack[$][SWITCH_ELSE]*/
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _29446 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _29446 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55173);
    _29447 = (object)*(((s1_ptr)_2)->base + _29446);
    _2 = (object)SEQ_PTR(_29447);
    _29448 = (object)*(((s1_ptr)_2)->base + 3LL);
    _29447 = NOVALUE;
    Ref(_29448);
    _2 = (object)SEQ_PTR(_36Code_21531);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21531 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _else_bp_58896);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29448;
    if( _1 != _29448 ){
        DeRef(_1);
    }
    _29448 = NOVALUE;
    goto L17; // [654] 681
L16: 

    /** parser.e:2736			Code[else_bp] = length(Code) + 1 + TRANSLATE*/
    if (IS_SEQUENCE(_36Code_21531)){
            _29449 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29449 = 1;
    }
    _29450 = _29449 + 1;
    _29449 = NOVALUE;
    _29451 = _29450 + _36TRANSLATE_21041;
    _29450 = NOVALUE;
    _2 = (object)SEQ_PTR(_36Code_21531);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21531 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _else_bp_58896);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29451;
    if( _1 != _29451 ){
        DeRef(_1);
    }
    _29451 = NOVALUE;
L17: 

    /** parser.e:2739		if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L18; // [685] 712
    }
    else{
    }

    /** parser.e:2744			SymTab[cases][S_OBJ] &= 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_cases_58897 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29454 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29452 = NOVALUE;
    if (IS_SEQUENCE(_29454) && IS_ATOM(0LL)) {
        Append(&_29455, _29454, 0LL);
    }
    else if (IS_ATOM(_29454) && IS_SEQUENCE(0LL)) {
    }
    else {
        Concat((object_ptr)&_29455, _29454, 0LL);
        _29454 = NOVALUE;
    }
    _29454 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29455;
    if( _1 != _29455 ){
        DeRef(_1);
    }
    _29455 = NOVALUE;
    _29452 = NOVALUE;
L18: 

    /** parser.e:2748		integer else_target = Code[else_bp]*/
    _2 = (object)SEQ_PTR(_36Code_21531);
    _else_target_59055 = (object)*(((s1_ptr)_2)->base + _else_bp_58896);
    if (!IS_ATOM_INT(_else_target_59055)){
        _else_target_59055 = (object)DBL_PTR(_else_target_59055)->dbl;
    }

    /** parser.e:2749		integer opcode = SWITCH*/
    _opcode_59058 = 185LL;

    /** parser.e:2750		if has_unassigned or has_fwdref then*/
    if (_has_unassigned_58911 != 0) {
        goto L19; // [733] 742
    }
    if (_has_fwdref_58912 == 0)
    {
        goto L1A; // [738] 754
    }
    else{
    }
L19: 

    /** parser.e:2751			opcode = SWITCH_RT*/
    _opcode_59058 = 202LL;
    goto L1B; // [751] 907
L1A: 

    /** parser.e:2753		elsif all_ints then*/
    if (_all_ints_58907 == 0)
    {
        goto L1C; // [756] 904
    }
    else{
    }

    /** parser.e:2754			atom delta = max - min*/
    DeRef(_delta_59064);
    if (IS_ATOM_INT(_max_58905) && IS_ATOM_INT(_min_58903)) {
        _delta_59064 = _max_58905 - _min_58903;
        if ((object)((uintptr_t)_delta_59064 +(uintptr_t) HIGH_BITS) >= 0){
            _delta_59064 = NewDouble((eudouble)_delta_59064);
        }
    }
    else {
        if (IS_ATOM_INT(_max_58905)) {
            _delta_59064 = NewDouble((eudouble)_max_58905 - DBL_PTR(_min_58903)->dbl);
        }
        else {
            if (IS_ATOM_INT(_min_58903)) {
                _delta_59064 = NewDouble(DBL_PTR(_max_58905)->dbl - (eudouble)_min_58903);
            }
            else
            _delta_59064 = NewDouble(DBL_PTR(_max_58905)->dbl - DBL_PTR(_min_58903)->dbl);
        }
    }

    /** parser.e:2755			if not TRANSLATE and  delta < 1024 and delta >= 0 then*/
    _29459 = (_36TRANSLATE_21041 == 0);
    if (_29459 == 0) {
        _29460 = 0;
        goto L1D; // [772] 784
    }
    if (IS_ATOM_INT(_delta_59064)) {
        _29461 = (_delta_59064 < 1024LL);
    }
    else {
        _29461 = (DBL_PTR(_delta_59064)->dbl < (eudouble)1024LL);
    }
    _29460 = (_29461 != 0);
L1D: 
    if (_29460 == 0) {
        goto L1E; // [784] 893
    }
    if (IS_ATOM_INT(_delta_59064)) {
        _29463 = (_delta_59064 >= 0LL);
    }
    else {
        _29463 = (DBL_PTR(_delta_59064)->dbl >= (eudouble)0LL);
    }
    if (_29463 == 0)
    {
        DeRef(_29463);
        _29463 = NOVALUE;
        goto L1E; // [793] 893
    }
    else{
        DeRef(_29463);
        _29463 = NOVALUE;
    }

    /** parser.e:2756				opcode = SWITCH_SPI*/
    _opcode_59058 = 192LL;

    /** parser.e:2758				sequence switch_table = repeat( else_target, delta + 1 )*/
    if (IS_ATOM_INT(_delta_59064)) {
        _29464 = _delta_59064 + 1;
    }
    else
    _29464 = binary_op(PLUS, 1, _delta_59064);
    DeRef(_switch_table_59074);
    _switch_table_59074 = Repeat(_else_target_59055, _29464);
    DeRef(_29464);
    _29464 = NOVALUE;

    /** parser.e:2759				integer offset = min - 1*/
    if (IS_ATOM_INT(_min_58903)) {
        _offset_59077 = _min_58903 - 1LL;
    }
    else {
        _offset_59077 = NewDouble(DBL_PTR(_min_58903)->dbl - (eudouble)1LL);
    }
    if (!IS_ATOM_INT(_offset_59077)) {
        _1 = (object)(DBL_PTR(_offset_59077)->dbl);
        DeRefDS(_offset_59077);
        _offset_59077 = _1;
    }

    /** parser.e:2760				for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_58899)){
            _29467 = SEQ_PTR(_values_58899)->length;
    }
    else {
        _29467 = 1;
    }
    {
        object _i_59080;
        _i_59080 = 1LL;
L1F: 
        if (_i_59080 > _29467){
            goto L20; // [828] 860
        }

        /** parser.e:2761					switch_table[values[i] - offset] = jump[i]*/
        _2 = (object)SEQ_PTR(_values_58899);
        _29468 = (object)*(((s1_ptr)_2)->base + _i_59080);
        if (IS_ATOM_INT(_29468)) {
            _29469 = _29468 - _offset_59077;
            if ((object)((uintptr_t)_29469 +(uintptr_t) HIGH_BITS) >= 0){
                _29469 = NewDouble((eudouble)_29469);
            }
        }
        else {
            _29469 = binary_op(MINUS, _29468, _offset_59077);
        }
        _29468 = NOVALUE;
        _2 = (object)SEQ_PTR(_jump_58919);
        _29470 = (object)*(((s1_ptr)_2)->base + _i_59080);
        Ref(_29470);
        _2 = (object)SEQ_PTR(_switch_table_59074);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _switch_table_59074 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_29469))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_29469)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _29469);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _29470;
        if( _1 != _29470 ){
            DeRef(_1);
        }
        _29470 = NOVALUE;

        /** parser.e:2762				end for*/
        _i_59080 = _i_59080 + 1LL;
        goto L1F; // [855] 835
L20: 
        ;
    }

    /** parser.e:2763				Code[switch_pc + 2] = offset*/
    _29471 = _switch_pc_58895 + 2LL;
    _2 = (object)SEQ_PTR(_36Code_21531);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21531 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _29471);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _offset_59077;
    DeRef(_1);

    /** parser.e:2764				switch_stack[$][SWITCH_JUMP_TABLE] = switch_table*/
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _29472 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _29472 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55173);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _45switch_stack_55173 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29472 + ((s1_ptr)_2)->base);
    RefDS(_switch_table_59074);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _switch_table_59074;
    DeRef(_1);
    _29473 = NOVALUE;
    DeRefDS(_switch_table_59074);
    _switch_table_59074 = NOVALUE;
    goto L21; // [890] 903
L1E: 

    /** parser.e:2766				opcode = SWITCH_I*/
    _opcode_59058 = 193LL;
L21: 
L1C: 
    DeRef(_delta_59064);
    _delta_59064 = NOVALUE;
L1B: 

    /** parser.e:2770		Code[switch_pc] = opcode*/
    _2 = (object)SEQ_PTR(_36Code_21531);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21531 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _switch_pc_58895);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _opcode_59058;
    DeRef(_1);

    /** parser.e:2771		if opcode != SWITCH_SPI then*/
    if (_opcode_59058 == 192LL)
    goto L22; // [919] 956

    /** parser.e:2772			SymTab[cases][S_OBJ] = values*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_cases_58897 + ((s1_ptr)_2)->base);
    RefDS(_values_58899);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _values_58899;
    DeRef(_1);
    _29476 = NOVALUE;

    /** parser.e:2773			if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L23; // [942] 955
    }
    else{
    }

    /** parser.e:2774				update_translator_info( cases, all_ints, has_integer, has_atom, has_sequence )*/
    _45update_translator_info(_cases_58897, _all_ints_58907, _has_integer_58908, _has_atom_58909, _has_sequence_58910);
L23: 
L22: 

    /** parser.e:2779		SymTab[jump_table][S_OBJ] = switch_stack[$][SWITCH_JUMP_TABLE] - switch_pc*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_jump_table_58898 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _29480 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _29480 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55173);
    _29481 = (object)*(((s1_ptr)_2)->base + _29480);
    _2 = (object)SEQ_PTR(_29481);
    _29482 = (object)*(((s1_ptr)_2)->base + 2LL);
    _29481 = NOVALUE;
    if (IS_ATOM_INT(_29482)) {
        _29483 = _29482 - _switch_pc_58895;
        if ((object)((uintptr_t)_29483 +(uintptr_t) HIGH_BITS) >= 0){
            _29483 = NewDouble((eudouble)_29483);
        }
    }
    else {
        _29483 = binary_op(MINUS, _29482, _switch_pc_58895);
    }
    _29482 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29483;
    if( _1 != _29483 ){
        DeRef(_1);
    }
    _29483 = NOVALUE;
    _29478 = NOVALUE;

    /** parser.e:2781	end procedure*/
    DeRef(_values_58899);
    DeRef(_min_58903);
    DeRef(_max_58905);
    DeRef(_unique_values_58913);
    DeRef(_unique_jumps_58915);
    DeRef(_jump_58919);
    DeRef(_29469);
    _29469 = NOVALUE;
    DeRef(_29459);
    _29459 = NOVALUE;
    DeRef(_29461);
    _29461 = NOVALUE;
    DeRef(_29404);
    _29404 = NOVALUE;
    DeRef(_29393);
    _29393 = NOVALUE;
    DeRef(_29471);
    _29471 = NOVALUE;
    _29402 = NOVALUE;
    return;
    ;
}


void _45Switch_statement()
{
    object _else_case_2__tmp_at250_59174 = NOVALUE;
    object _else_case_1__tmp_at250_59173 = NOVALUE;
    object _else_case_inlined_else_case_at_250_59172 = NOVALUE;
    object _break_base_59112 = NOVALUE;
    object _cases_59114 = NOVALUE;
    object _jump_table_59115 = NOVALUE;
    object _else_bp_59116 = NOVALUE;
    object _switch_pc_59117 = NOVALUE;
    object _t_59154 = NOVALUE;
    object _29514 = NOVALUE;
    object _29513 = NOVALUE;
    object _29512 = NOVALUE;
    object _29511 = NOVALUE;
    object _29510 = NOVALUE;
    object _29506 = NOVALUE;
    object _29502 = NOVALUE;
    object _29501 = NOVALUE;
    object _29499 = NOVALUE;
    object _29498 = NOVALUE;
    object _29496 = NOVALUE;
    object _29495 = NOVALUE;
    object _29493 = NOVALUE;
    object _29492 = NOVALUE;
    object _29491 = NOVALUE;
    object _29490 = NOVALUE;
    object _29489 = NOVALUE;
    object _29488 = NOVALUE;
    object _29486 = NOVALUE;
    object _29485 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2786		integer else_bp*/

    /** parser.e:2787		integer switch_pc*/

    /** parser.e:2789		push_switch()*/
    _45push_switch();

    /** parser.e:2790		break_base = length(break_list)*/
    if (IS_SEQUENCE(_45break_list_54942)){
            _break_base_59112 = SEQ_PTR(_45break_list_54942)->length;
    }
    else {
        _break_base_59112 = 1;
    }

    /** parser.e:2792		Expr()*/
    _45Expr();

    /** parser.e:2793		switch_stack[$][SWITCH_VALUE] = Top()*/
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _29485 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _29485 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55173);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _45switch_stack_55173 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29485 + ((s1_ptr)_2)->base);
    _29488 = _47Top();
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29488;
    if( _1 != _29488 ){
        DeRef(_1);
    }
    _29488 = NOVALUE;
    _29486 = NOVALUE;

    /** parser.e:2794		clear_temp( switch_stack[$][SWITCH_VALUE] )*/
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _29489 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _29489 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55173);
    _29490 = (object)*(((s1_ptr)_2)->base + _29489);
    _2 = (object)SEQ_PTR(_29490);
    _29491 = (object)*(((s1_ptr)_2)->base + 6LL);
    _29490 = NOVALUE;
    Ref(_29491);
    _47clear_temp(_29491);
    _29491 = NOVALUE;

    /** parser.e:2796		cases = NewStringSym( {-1, length(SymTab) } )*/
    if (IS_SEQUENCE(_37SymTab_15406)){
            _29492 = SEQ_PTR(_37SymTab_15406)->length;
    }
    else {
        _29492 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1LL;
    ((intptr_t *)_2)[2] = _29492;
    _29493 = MAKE_SEQ(_1);
    _29492 = NOVALUE;
    _cases_59114 = _54NewStringSym(_29493);
    _29493 = NOVALUE;
    if (!IS_ATOM_INT(_cases_59114)) {
        _1 = (object)(DBL_PTR(_cases_59114)->dbl);
        DeRefDS(_cases_59114);
        _cases_59114 = _1;
    }

    /** parser.e:2798		emit_opnd( cases )*/
    _47emit_opnd(_cases_59114);

    /** parser.e:2800		jump_table = NewStringSym( {-2, length(SymTab) } )*/
    if (IS_SEQUENCE(_37SymTab_15406)){
            _29495 = SEQ_PTR(_37SymTab_15406)->length;
    }
    else {
        _29495 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -2LL;
    ((intptr_t *)_2)[2] = _29495;
    _29496 = MAKE_SEQ(_1);
    _29495 = NOVALUE;
    _jump_table_59115 = _54NewStringSym(_29496);
    _29496 = NOVALUE;
    if (!IS_ATOM_INT(_jump_table_59115)) {
        _1 = (object)(DBL_PTR(_jump_table_59115)->dbl);
        DeRefDS(_jump_table_59115);
        _jump_table_59115 = _1;
    }

    /** parser.e:2801		emit_opnd( jump_table )*/
    _47emit_opnd(_jump_table_59115);

    /** parser.e:2803		if finish_block_header(SWITCH) then end if*/
    _29498 = _45finish_block_header(185LL);
    if (_29498 == 0) {
        DeRef(_29498);
        _29498 = NOVALUE;
        goto L1; // [109] 113
    }
    else {
        if (!IS_ATOM_INT(_29498) && DBL_PTR(_29498)->dbl == 0.0){
            DeRef(_29498);
            _29498 = NOVALUE;
            goto L1; // [109] 113
        }
        DeRef(_29498);
        _29498 = NOVALUE;
    }
    DeRef(_29498);
    _29498 = NOVALUE;
L1: 

    /** parser.e:2805		switch_pc = length(Code) + 1*/
    if (IS_SEQUENCE(_36Code_21531)){
            _29499 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29499 = 1;
    }
    _switch_pc_59117 = _29499 + 1;
    _29499 = NOVALUE;

    /** parser.e:2806		switch_stack[$][SWITCH_PC] = switch_pc*/
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _29501 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _29501 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55173);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _45switch_stack_55173 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29501 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _switch_pc_59117;
    DeRef(_1);
    _29502 = NOVALUE;

    /** parser.e:2808		emit_op(SWITCH)*/
    _47emit_op(185LL);

    /** parser.e:2809		emit_forward_addr()  -- the else*/
    _45emit_forward_addr();

    /** parser.e:2810		else_bp = length( Code )*/
    if (IS_SEQUENCE(_36Code_21531)){
            _else_bp_59116 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _else_bp_59116 = 1;
    }

    /** parser.e:2813		t = next_token()*/
    _0 = _t_59154;
    _t_59154 = _45next_token();
    DeRef(_0);

    /** parser.e:2814		if t[T_ID] = CASE then*/
    _2 = (object)SEQ_PTR(_t_59154);
    _29506 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29506, 186LL)){
        _29506 = NOVALUE;
        goto L2; // [173] 188
    }
    _29506 = NOVALUE;

    /** parser.e:2816			Case_statement()*/
    _45Case_statement();

    /** parser.e:2818			Statement_list()*/
    _45Statement_list();
    goto L3; // [185] 194
L2: 

    /** parser.e:2821			putback(t)*/
    Ref(_t_59154);
    _45putback(_t_59154);
L3: 

    /** parser.e:2824		optimize_switch( switch_pc, else_bp, cases, jump_table )*/
    _45optimize_switch(_switch_pc_59117, _else_bp_59116, _cases_59114, _jump_table_59115);

    /** parser.e:2825		tok_match(END)*/
    _45tok_match(402LL, 0LL);

    /** parser.e:2826		tok_match(SWITCH, END)*/
    _45tok_match(185LL, 402LL);

    /** parser.e:2827		if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L4; // [224] 235
    }
    else{
    }

    /** parser.e:2828			emit_op(NOPSWITCH)*/
    _47emit_op(187LL);
L4: 

    /** parser.e:2831		if not else_case() then*/

    /** parser.e:2472		return switch_stack[$][SWITCH_ELSE]*/
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _else_case_1__tmp_at250_59173 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _else_case_1__tmp_at250_59173 = 1;
    }
    DeRef(_else_case_2__tmp_at250_59174);
    _2 = (object)SEQ_PTR(_45switch_stack_55173);
    _else_case_2__tmp_at250_59174 = (object)*(((s1_ptr)_2)->base + _else_case_1__tmp_at250_59173);
    RefDS(_else_case_2__tmp_at250_59174);
    DeRef(_else_case_inlined_else_case_at_250_59172);
    _2 = (object)SEQ_PTR(_else_case_2__tmp_at250_59174);
    _else_case_inlined_else_case_at_250_59172 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_else_case_inlined_else_case_at_250_59172);
    DeRef(_else_case_2__tmp_at250_59174);
    _else_case_2__tmp_at250_59174 = NOVALUE;
    if (IS_ATOM_INT(_else_case_inlined_else_case_at_250_59172)) {
        if (_else_case_inlined_else_case_at_250_59172 != 0){
            goto L5; // [255] 327
        }
    }
    else {
        if (DBL_PTR(_else_case_inlined_else_case_at_250_59172)->dbl != 0.0){
            goto L5; // [255] 327
        }
    }

    /** parser.e:2832			if not TRANSLATE then*/
    if (_36TRANSLATE_21041 != 0)
    goto L6; // [262] 303

    /** parser.e:2833				StartSourceLine( TRUE, , COVERAGE_SUPPRESS )*/
    _47StartSourceLine(_13TRUE_452, 0LL, 1LL);

    /** parser.e:2834				emit_temp( switch_stack[$][SWITCH_VALUE], NEW_REFERENCE )*/
    if (IS_SEQUENCE(_45switch_stack_55173)){
            _29510 = SEQ_PTR(_45switch_stack_55173)->length;
    }
    else {
        _29510 = 1;
    }
    _2 = (object)SEQ_PTR(_45switch_stack_55173);
    _29511 = (object)*(((s1_ptr)_2)->base + _29510);
    _2 = (object)SEQ_PTR(_29511);
    _29512 = (object)*(((s1_ptr)_2)->base + 6LL);
    _29511 = NOVALUE;
    Ref(_29512);
    _47emit_temp(_29512, 1LL);
    _29512 = NOVALUE;

    /** parser.e:2835				flush_temps()*/
    RefDS(_21993);
    _47flush_temps(_21993);
L6: 

    /** parser.e:2838			Warning(221, no_case_else_warning_flag,*/
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _29513 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
    Ref(_29513);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _29513;
    ((intptr_t *)_2)[2] = _36line_number_21440;
    _29514 = MAKE_SEQ(_1);
    _29513 = NOVALUE;
    _50Warning(221LL, 4096LL, _29514);
    _29514 = NOVALUE;
L5: 

    /** parser.e:2841		pop_switch( break_base )*/
    _45pop_switch(_break_base_59112);

    /** parser.e:2842	end procedure*/
    DeRef(_t_59154);
    return;
    ;
}


object _45get_private_uninitialized()
{
    object _uninitialized_59197 = NOVALUE;
    object _s_59203 = NOVALUE;
    object _pu_59209 = NOVALUE;
    object _29531 = NOVALUE;
    object _29529 = NOVALUE;
    object _29528 = NOVALUE;
    object _29527 = NOVALUE;
    object _29526 = NOVALUE;
    object _29525 = NOVALUE;
    object _29524 = NOVALUE;
    object _29523 = NOVALUE;
    object _29522 = NOVALUE;
    object _29521 = NOVALUE;
    object _29520 = NOVALUE;
    object _29519 = NOVALUE;
    object _29516 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2845		sequence uninitialized = {}*/
    RefDS(_21993);
    DeRefi(_uninitialized_59197);
    _uninitialized_59197 = _21993;

    /** parser.e:2846		if CurrentSub != TopLevelSub then*/
    if (_36CurrentSub_21447 == _36TopLevelSub_21446)
    goto L1; // [14] 149

    /** parser.e:2847			symtab_pointer s = SymTab[CurrentSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29516 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21447);
    _2 = (object)SEQ_PTR(_29516);
    _s_59203 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_59203)){
        _s_59203 = (object)DBL_PTR(_s_59203)->dbl;
    }
    _29516 = NOVALUE;

    /** parser.e:2848			sequence pu = { SC_PRIVATE, SC_UNDEFINED }*/
    DeRefi(_pu_59209);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 3LL;
    ((intptr_t *)_2)[2] = 9LL;
    _pu_59209 = MAKE_SEQ(_1);

    /** parser.e:2849			while s and find( SymTab[s][S_SCOPE], pu ) do*/
L2: 
    if (_s_59203 == 0) {
        goto L3; // [51] 148
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29520 = (object)*(((s1_ptr)_2)->base + _s_59203);
    _2 = (object)SEQ_PTR(_29520);
    _29521 = (object)*(((s1_ptr)_2)->base + 4LL);
    _29520 = NOVALUE;
    _29522 = find_from(_29521, _pu_59209, 1LL);
    _29521 = NOVALUE;
    if (_29522 == 0)
    {
        _29522 = NOVALUE;
        goto L3; // [73] 148
    }
    else{
        _29522 = NOVALUE;
    }

    /** parser.e:2850				if SymTab[s][S_SCOPE] = SC_PRIVATE and SymTab[s][S_INITLEVEL] = -1 then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29523 = (object)*(((s1_ptr)_2)->base + _s_59203);
    _2 = (object)SEQ_PTR(_29523);
    _29524 = (object)*(((s1_ptr)_2)->base + 4LL);
    _29523 = NOVALUE;
    if (IS_ATOM_INT(_29524)) {
        _29525 = (_29524 == 3LL);
    }
    else {
        _29525 = binary_op(EQUALS, _29524, 3LL);
    }
    _29524 = NOVALUE;
    if (IS_ATOM_INT(_29525)) {
        if (_29525 == 0) {
            goto L4; // [96] 127
        }
    }
    else {
        if (DBL_PTR(_29525)->dbl == 0.0) {
            goto L4; // [96] 127
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29527 = (object)*(((s1_ptr)_2)->base + _s_59203);
    _2 = (object)SEQ_PTR(_29527);
    _29528 = (object)*(((s1_ptr)_2)->base + 14LL);
    _29527 = NOVALUE;
    if (IS_ATOM_INT(_29528)) {
        _29529 = (_29528 == -1LL);
    }
    else {
        _29529 = binary_op(EQUALS, _29528, -1LL);
    }
    _29528 = NOVALUE;
    if (_29529 == 0) {
        DeRef(_29529);
        _29529 = NOVALUE;
        goto L4; // [117] 127
    }
    else {
        if (!IS_ATOM_INT(_29529) && DBL_PTR(_29529)->dbl == 0.0){
            DeRef(_29529);
            _29529 = NOVALUE;
            goto L4; // [117] 127
        }
        DeRef(_29529);
        _29529 = NOVALUE;
    }
    DeRef(_29529);
    _29529 = NOVALUE;

    /** parser.e:2851					uninitialized &= s*/
    Append(&_uninitialized_59197, _uninitialized_59197, _s_59203);
L4: 

    /** parser.e:2853				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29531 = (object)*(((s1_ptr)_2)->base + _s_59203);
    _2 = (object)SEQ_PTR(_29531);
    _s_59203 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_59203)){
        _s_59203 = (object)DBL_PTR(_s_59203)->dbl;
    }
    _29531 = NOVALUE;

    /** parser.e:2854			end while*/
    goto L2; // [145] 51
L3: 
L1: 
    DeRefi(_pu_59209);
    _pu_59209 = NOVALUE;

    /** parser.e:2856		return uninitialized*/
    DeRef(_29525);
    _29525 = NOVALUE;
    return _uninitialized_59197;
    ;
}


void _45While_statement()
{
    object _bp1_59240 = NOVALUE;
    object _bp2_59241 = NOVALUE;
    object _exit_base_59242 = NOVALUE;
    object _next_base_59243 = NOVALUE;
    object _uninitialized_59244 = NOVALUE;
    object _temps_59314 = NOVALUE;
    object _29567 = NOVALUE;
    object _29566 = NOVALUE;
    object _29565 = NOVALUE;
    object _29561 = NOVALUE;
    object _29560 = NOVALUE;
    object _29558 = NOVALUE;
    object _29556 = NOVALUE;
    object _29555 = NOVALUE;
    object _29554 = NOVALUE;
    object _29550 = NOVALUE;
    object _29548 = NOVALUE;
    object _29546 = NOVALUE;
    object _29540 = NOVALUE;
    object _29538 = NOVALUE;
    object _29537 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2865		sequence uninitialized = get_private_uninitialized()*/
    _0 = _uninitialized_59244;
    _uninitialized_59244 = _45get_private_uninitialized();
    DeRef(_0);

    /** parser.e:2867		entry_stack = append( entry_stack, uninitialized )*/
    RefDS(_uninitialized_59244);
    Append(&_45entry_stack_54951, _45entry_stack_54951, _uninitialized_59244);

    /** parser.e:2869		Start_block( WHILE )*/
    _65Start_block(47LL, 0LL);

    /** parser.e:2871		exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_45exit_list_54944)){
            _exit_base_59242 = SEQ_PTR(_45exit_list_54944)->length;
    }
    else {
        _exit_base_59242 = 1;
    }

    /** parser.e:2872		next_base = length(continue_list)*/
    if (IS_SEQUENCE(_45continue_list_54946)){
            _next_base_59243 = SEQ_PTR(_45continue_list_54946)->length;
    }
    else {
        _next_base_59243 = 1;
    }

    /** parser.e:2873		entry_addr &= length(Code)+1*/
    if (IS_SEQUENCE(_36Code_21531)){
            _29537 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29537 = 1;
    }
    _29538 = _29537 + 1;
    _29537 = NOVALUE;
    Append(&_45entry_addr_54948, _45entry_addr_54948, _29538);
    _29538 = NOVALUE;

    /** parser.e:2874		emit_op(NOP2) -- Entry_statement may patch this later*/
    _47emit_op(110LL);

    /** parser.e:2875		emit_addr(0)*/
    _47emit_addr(0LL);

    /** parser.e:2876		if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L1; // [71] 82
    }
    else{
    }

    /** parser.e:2877			emit_op(NOPWHILE)*/
    _47emit_op(158LL);
L1: 

    /** parser.e:2879		bp1 = length(Code)+1*/
    if (IS_SEQUENCE(_36Code_21531)){
            _29540 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29540 = 1;
    }
    _bp1_59240 = _29540 + 1;
    _29540 = NOVALUE;

    /** parser.e:2880		continue_addr &= bp1*/
    Append(&_45continue_addr_54949, _45continue_addr_54949, _bp1_59240);

    /** parser.e:2881		short_circuit += 1*/
    _45short_circuit_54924 = _45short_circuit_54924 + 1;

    /** parser.e:2882		short_circuit_B = FALSE*/
    _45short_circuit_B_54926 = _13FALSE_450;

    /** parser.e:2883		SC1_type = 0*/
    _45SC1_type_54929 = 0LL;

    /** parser.e:2884		Expr()*/
    _45Expr();

    /** parser.e:2885		optimized_while = FALSE*/
    _47optimized_while_50934 = _13FALSE_450;

    /** parser.e:2886		emit_op(WHILE)*/
    _47emit_op(47LL);

    /** parser.e:2887		short_circuit -= 1*/
    _45short_circuit_54924 = _45short_circuit_54924 - 1LL;

    /** parser.e:2888		if not optimized_while then*/
    if (_47optimized_while_50934 != 0)
    goto L2; // [153] 174

    /** parser.e:2890			bp2 = length(Code)+1*/
    if (IS_SEQUENCE(_36Code_21531)){
            _29546 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29546 = 1;
    }
    _bp2_59241 = _29546 + 1;
    _29546 = NOVALUE;

    /** parser.e:2891			emit_forward_addr() -- will be patched*/
    _45emit_forward_addr();
    goto L3; // [171] 180
L2: 

    /** parser.e:2893			bp2 = 0*/
    _bp2_59241 = 0LL;
L3: 

    /** parser.e:2895		if finish_block_header(WHILE)=0 then*/
    _29548 = _45finish_block_header(47LL);
    if (binary_op_a(NOTEQ, _29548, 0LL)){
        DeRef(_29548);
        _29548 = NOVALUE;
        goto L4; // [188] 204
    }
    DeRef(_29548);
    _29548 = NOVALUE;

    /** parser.e:2896			entry_addr[$]=-1*/
    if (IS_SEQUENCE(_45entry_addr_54948)){
            _29550 = SEQ_PTR(_45entry_addr_54948)->length;
    }
    else {
        _29550 = 1;
    }
    _2 = (object)SEQ_PTR(_45entry_addr_54948);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _45entry_addr_54948 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _29550);
    *(intptr_t *)_2 = -1LL;
L4: 

    /** parser.e:2899		loop_stack &= WHILE*/
    Append(&_45loop_stack_54958, _45loop_stack_54958, 47LL);

    /** parser.e:2901		exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_45exit_list_54944)){
            _exit_base_59242 = SEQ_PTR(_45exit_list_54944)->length;
    }
    else {
        _exit_base_59242 = 1;
    }

    /** parser.e:2902		if SC1_type = OR then*/
    if (_45SC1_type_54929 != 9LL)
    goto L5; // [227] 280

    /** parser.e:2903			backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29554 = _45SC1_patch_54928 - 3LL;
    if ((object)((uintptr_t)_29554 +(uintptr_t) HIGH_BITS) >= 0){
        _29554 = NewDouble((eudouble)_29554);
    }
    _47backpatch(_29554, 147LL);
    _29554 = NOVALUE;

    /** parser.e:2904			if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L6; // [249] 260
    }
    else{
    }

    /** parser.e:2905				emit_op(NOP1)*/
    _47emit_op(159LL);
L6: 

    /** parser.e:2907			backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21531)){
            _29555 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29555 = 1;
    }
    _29556 = _29555 + 1;
    _29555 = NOVALUE;
    _47backpatch(_45SC1_patch_54928, _29556);
    _29556 = NOVALUE;
    goto L7; // [277] 331
L5: 

    /** parser.e:2908		elsif SC1_type = AND then*/
    if (_45SC1_type_54929 != 8LL)
    goto L8; // [286] 330

    /** parser.e:2909			backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29558 = _45SC1_patch_54928 - 3LL;
    if ((object)((uintptr_t)_29558 +(uintptr_t) HIGH_BITS) >= 0){
        _29558 = NewDouble((eudouble)_29558);
    }
    _47backpatch(_29558, 146LL);
    _29558 = NOVALUE;

    /** parser.e:2910			AppendXList(SC1_patch)*/

    /** parser.e:398		exit_list = append(exit_list, addr)*/
    Append(&_45exit_list_54944, _45exit_list_54944, _45SC1_patch_54928);

    /** parser.e:399	end procedure*/
    goto L9; // [318] 321
L9: 

    /** parser.e:2911			exit_delay &= 1*/
    Append(&_45exit_delay_54945, _45exit_delay_54945, 1LL);
L8: 
L7: 

    /** parser.e:2913		retry_addr &= length(Code)+1*/
    if (IS_SEQUENCE(_36Code_21531)){
            _29560 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29560 = 1;
    }
    _29561 = _29560 + 1;
    _29560 = NOVALUE;
    Append(&_45retry_addr_54950, _45retry_addr_54950, _29561);
    _29561 = NOVALUE;

    /** parser.e:2915		sequence temps = pop_temps()*/
    _0 = _temps_59314;
    _temps_59314 = _47pop_temps();
    DeRef(_0);

    /** parser.e:2917		push_temps( temps )*/
    RefDS(_temps_59314);
    _47push_temps(_temps_59314);

    /** parser.e:2919		Statement_list()*/
    _45Statement_list();

    /** parser.e:2920		PatchNList(next_base)*/
    _45PatchNList(_next_base_59243);

    /** parser.e:2921		tok_match(END)*/
    _45tok_match(402LL, 0LL);

    /** parser.e:2922		tok_match(WHILE, END)*/
    _45tok_match(47LL, 402LL);

    /** parser.e:2924		End_block( WHILE )*/
    _65End_block(47LL);

    /** parser.e:2926		StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:2927		emit_op(ENDWHILE)*/
    _47emit_op(22LL);

    /** parser.e:2928		emit_addr(bp1)*/
    _47emit_addr(_bp1_59240);

    /** parser.e:2929		if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto LA; // [419] 430
    }
    else{
    }

    /** parser.e:2930			emit_op(NOP1)*/
    _47emit_op(159LL);
LA: 

    /** parser.e:2932		if bp2 != 0 then*/
    if (_bp2_59241 == 0LL)
    goto LB; // [434] 454

    /** parser.e:2933			backpatch(bp2, length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21531)){
            _29565 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29565 = 1;
    }
    _29566 = _29565 + 1;
    _29565 = NOVALUE;
    _47backpatch(_bp2_59241, _29566);
    _29566 = NOVALUE;
LB: 

    /** parser.e:2935		exit_loop(exit_base)*/
    _45exit_loop(_exit_base_59242);

    /** parser.e:2936		entry_stack = remove( entry_stack, length( entry_stack ) )*/
    if (IS_SEQUENCE(_45entry_stack_54951)){
            _29567 = SEQ_PTR(_45entry_stack_54951)->length;
    }
    else {
        _29567 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_45entry_stack_54951);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_29567)) ? _29567 : (object)(DBL_PTR(_29567)->dbl);
        int stop = (IS_ATOM_INT(_29567)) ? _29567 : (object)(DBL_PTR(_29567)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_45entry_stack_54951), start, &_45entry_stack_54951 );
            }
            else Tail(SEQ_PTR(_45entry_stack_54951), stop+1, &_45entry_stack_54951);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_45entry_stack_54951), start, &_45entry_stack_54951);
        }
        else {
            assign_slice_seq = &assign_space;
            _45entry_stack_54951 = Remove_elements(start, stop, (SEQ_PTR(_45entry_stack_54951)->ref == 1));
        }
    }
    _29567 = NOVALUE;
    _29567 = NOVALUE;

    /** parser.e:2937		push_temps( temps )*/
    RefDS(_temps_59314);
    _47push_temps(_temps_59314);

    /** parser.e:2938	end procedure*/
    DeRef(_uninitialized_59244);
    DeRefDS(_temps_59314);
    return;
    ;
}


void _45Loop_statement()
{
    object _bp1_59344 = NOVALUE;
    object _exit_base_59345 = NOVALUE;
    object _next_base_59346 = NOVALUE;
    object _t_59348 = NOVALUE;
    object _uninitialized_59351 = NOVALUE;
    object _29591 = NOVALUE;
    object _29589 = NOVALUE;
    object _29588 = NOVALUE;
    object _29587 = NOVALUE;
    object _29581 = NOVALUE;
    object _29580 = NOVALUE;
    object _29578 = NOVALUE;
    object _29575 = NOVALUE;
    object _29574 = NOVALUE;
    object _29573 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2946		Start_block( LOOP )*/
    _65Start_block(422LL, 0LL);

    /** parser.e:2948		sequence uninitialized = get_private_uninitialized()*/
    _0 = _uninitialized_59351;
    _uninitialized_59351 = _45get_private_uninitialized();
    DeRef(_0);

    /** parser.e:2949		entry_stack = append( entry_stack, uninitialized )*/
    RefDS(_uninitialized_59351);
    Append(&_45entry_stack_54951, _45entry_stack_54951, _uninitialized_59351);

    /** parser.e:2951		exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_45exit_list_54944)){
            _exit_base_59345 = SEQ_PTR(_45exit_list_54944)->length;
    }
    else {
        _exit_base_59345 = 1;
    }

    /** parser.e:2952		next_base = length(continue_list)*/
    if (IS_SEQUENCE(_45continue_list_54946)){
            _next_base_59346 = SEQ_PTR(_45continue_list_54946)->length;
    }
    else {
        _next_base_59346 = 1;
    }

    /** parser.e:2953		emit_op(NOP2) -- Entry_statement() may patch this*/
    _47emit_op(110LL);

    /** parser.e:2954		emit_addr(0)*/
    _47emit_addr(0LL);

    /** parser.e:2955		if finish_block_header(LOOP) then*/
    _29573 = _45finish_block_header(422LL);
    if (_29573 == 0) {
        DeRef(_29573);
        _29573 = NOVALUE;
        goto L1; // [58] 81
    }
    else {
        if (!IS_ATOM_INT(_29573) && DBL_PTR(_29573)->dbl == 0.0){
            DeRef(_29573);
            _29573 = NOVALUE;
            goto L1; // [58] 81
        }
        DeRef(_29573);
        _29573 = NOVALUE;
    }
    DeRef(_29573);
    _29573 = NOVALUE;

    /** parser.e:2956		    entry_addr &= length(Code)-1*/
    if (IS_SEQUENCE(_36Code_21531)){
            _29574 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29574 = 1;
    }
    _29575 = _29574 - 1LL;
    _29574 = NOVALUE;
    Append(&_45entry_addr_54948, _45entry_addr_54948, _29575);
    _29575 = NOVALUE;
    goto L2; // [78] 90
L1: 

    /** parser.e:2958			entry_addr &= -1*/
    Append(&_45entry_addr_54948, _45entry_addr_54948, -1LL);
L2: 

    /** parser.e:2962		if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L3; // [94] 105
    }
    else{
    }

    /** parser.e:2963			emit_op(NOP1)*/
    _47emit_op(159LL);
L3: 

    /** parser.e:2965		bp1 = length(Code)+1*/
    if (IS_SEQUENCE(_36Code_21531)){
            _29578 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29578 = 1;
    }
    _bp1_59344 = _29578 + 1;
    _29578 = NOVALUE;

    /** parser.e:2966		retry_addr &= length(Code)+1*/
    if (IS_SEQUENCE(_36Code_21531)){
            _29580 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29580 = 1;
    }
    _29581 = _29580 + 1;
    _29580 = NOVALUE;
    Append(&_45retry_addr_54950, _45retry_addr_54950, _29581);
    _29581 = NOVALUE;

    /** parser.e:2967		continue_addr &= 0*/
    Append(&_45continue_addr_54949, _45continue_addr_54949, 0LL);

    /** parser.e:2968		loop_stack &= LOOP*/
    Append(&_45loop_stack_54958, _45loop_stack_54958, 422LL);

    /** parser.e:2970		Statement_list()*/
    _45Statement_list();

    /** parser.e:2972		End_block( LOOP )*/
    _65End_block(422LL);

    /** parser.e:2974		tok_match(UNTIL)*/
    _45tok_match(423LL, 0LL);

    /** parser.e:2975		if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L4; // [174] 185
    }
    else{
    }

    /** parser.e:2976			emit_op(NOP1)*/
    _47emit_op(159LL);
L4: 

    /** parser.e:2978		PatchNList(next_base)*/
    _45PatchNList(_next_base_59346);

    /** parser.e:2979		StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:2980		short_circuit += 1*/
    _45short_circuit_54924 = _45short_circuit_54924 + 1;

    /** parser.e:2981		short_circuit_B = FALSE*/
    _45short_circuit_B_54926 = _13FALSE_450;

    /** parser.e:2982		SC1_type = 0*/
    _45SC1_type_54929 = 0LL;

    /** parser.e:2983		Expr()*/
    _45Expr();

    /** parser.e:2984		if SC1_type = OR then*/
    if (_45SC1_type_54929 != 9LL)
    goto L5; // [229] 282

    /** parser.e:2985			backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29587 = _45SC1_patch_54928 - 3LL;
    if ((object)((uintptr_t)_29587 +(uintptr_t) HIGH_BITS) >= 0){
        _29587 = NewDouble((eudouble)_29587);
    }
    _47backpatch(_29587, 147LL);
    _29587 = NOVALUE;

    /** parser.e:2986			if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L6; // [251] 262
    }
    else{
    }

    /** parser.e:2987			    emit_op(NOP1)  -- to get label here*/
    _47emit_op(159LL);
L6: 

    /** parser.e:2989			backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21531)){
            _29588 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29588 = 1;
    }
    _29589 = _29588 + 1;
    _29588 = NOVALUE;
    _47backpatch(_45SC1_patch_54928, _29589);
    _29589 = NOVALUE;
    goto L7; // [279] 308
L5: 

    /** parser.e:2990		elsif SC1_type = AND then*/
    if (_45SC1_type_54929 != 8LL)
    goto L8; // [288] 307

    /** parser.e:2991			backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29591 = _45SC1_patch_54928 - 3LL;
    if ((object)((uintptr_t)_29591 +(uintptr_t) HIGH_BITS) >= 0){
        _29591 = NewDouble((eudouble)_29591);
    }
    _47backpatch(_29591, 146LL);
    _29591 = NOVALUE;
L8: 
L7: 

    /** parser.e:2993		short_circuit -= 1*/
    _45short_circuit_54924 = _45short_circuit_54924 - 1LL;

    /** parser.e:2994		emit_op(IF)*/
    _47emit_op(20LL);

    /** parser.e:2995		emit_addr(bp1)*/
    _47emit_addr(_bp1_59344);

    /** parser.e:2996		if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L9; // [332] 343
    }
    else{
    }

    /** parser.e:2997			emit_op(NOP1)*/
    _47emit_op(159LL);
L9: 

    /** parser.e:2999		exit_loop(exit_base)*/
    _45exit_loop(_exit_base_59345);

    /** parser.e:3001		tok_match(END)*/
    _45tok_match(402LL, 0LL);

    /** parser.e:3002		tok_match(LOOP, END)*/
    _45tok_match(422LL, 402LL);

    /** parser.e:3004	end procedure*/
    DeRef(_uninitialized_59351);
    return;
    ;
}


void _45Ifdef_statement()
{
    object _option_59430 = NOVALUE;
    object _matched_59431 = NOVALUE;
    object _has_matched_59432 = NOVALUE;
    object _in_matched_59433 = NOVALUE;
    object _dead_ifdef_59434 = NOVALUE;
    object _in_elsedef_59435 = NOVALUE;
    object _tok_59437 = NOVALUE;
    object _keyw_59438 = NOVALUE;
    object _parser_id_59442 = NOVALUE;
    object _negate_59458 = NOVALUE;
    object _conjunction_59459 = NOVALUE;
    object _at_start_59460 = NOVALUE;
    object _prev_conj_59461 = NOVALUE;
    object _this_matched_59546 = NOVALUE;
    object _gotword_59562 = NOVALUE;
    object _gotthen_59563 = NOVALUE;
    object _if_lvl_59564 = NOVALUE;
    object _29708 = NOVALUE;
    object _29707 = NOVALUE;
    object _29703 = NOVALUE;
    object _29701 = NOVALUE;
    object _29698 = NOVALUE;
    object _29696 = NOVALUE;
    object _29695 = NOVALUE;
    object _29691 = NOVALUE;
    object _29688 = NOVALUE;
    object _29685 = NOVALUE;
    object _29681 = NOVALUE;
    object _29679 = NOVALUE;
    object _29678 = NOVALUE;
    object _29677 = NOVALUE;
    object _29676 = NOVALUE;
    object _29675 = NOVALUE;
    object _29674 = NOVALUE;
    object _29673 = NOVALUE;
    object _29669 = NOVALUE;
    object _29666 = NOVALUE;
    object _29665 = NOVALUE;
    object _29664 = NOVALUE;
    object _29660 = NOVALUE;
    object _29659 = NOVALUE;
    object _29658 = NOVALUE;
    object _29655 = NOVALUE;
    object _29652 = NOVALUE;
    object _29651 = NOVALUE;
    object _29650 = NOVALUE;
    object _29648 = NOVALUE;
    object _29637 = NOVALUE;
    object _29635 = NOVALUE;
    object _29634 = NOVALUE;
    object _29633 = NOVALUE;
    object _29632 = NOVALUE;
    object _29631 = NOVALUE;
    object _29630 = NOVALUE;
    object _29629 = NOVALUE;
    object _29626 = NOVALUE;
    object _29625 = NOVALUE;
    object _29623 = NOVALUE;
    object _29621 = NOVALUE;
    object _29620 = NOVALUE;
    object _29618 = NOVALUE;
    object _29616 = NOVALUE;
    object _29615 = NOVALUE;
    object _29613 = NOVALUE;
    object _29612 = NOVALUE;
    object _29611 = NOVALUE;
    object _29608 = NOVALUE;
    object _29606 = NOVALUE;
    object _29603 = NOVALUE;
    object _29602 = NOVALUE;
    object _29601 = NOVALUE;
    object _29599 = NOVALUE;
    object _29597 = NOVALUE;
    object _29596 = NOVALUE;
    object _29595 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:3012		integer matched = 0, has_matched = 0,  in_matched = 0, dead_ifdef = 0, in_elsedef = 0*/
    _matched_59431 = 0LL;
    _has_matched_59432 = 0LL;
    _in_matched_59433 = 0LL;
    _dead_ifdef_59434 = 0LL;
    _in_elsedef_59435 = 0LL;

    /** parser.e:3014		sequence keyw ="ifdef"*/
    RefDS(_26206);
    DeRefi(_keyw_59438);
    _keyw_59438 = _26206;

    /** parser.e:3016		live_ifdef += 1*/
    _45live_ifdef_59426 = _45live_ifdef_59426 + 1;

    /** parser.e:3017		ifdef_lineno &= line_number*/
    Append(&_45ifdef_lineno_59427, _45ifdef_lineno_59427, _36line_number_21440);

    /** parser.e:3019		integer parser_id*/

    /** parser.e:3020		if CurrentSub != TopLevelSub or length(if_labels) or length(loop_labels) then*/
    _29595 = (_36CurrentSub_21447 != _36TopLevelSub_21446);
    if (_29595 != 0) {
        _29596 = 1;
        goto L1; // [55] 68
    }
    if (IS_SEQUENCE(_45if_labels_54953)){
            _29597 = SEQ_PTR(_45if_labels_54953)->length;
    }
    else {
        _29597 = 1;
    }
    _29596 = (_29597 != 0);
L1: 
    if (_29596 != 0) {
        goto L2; // [68] 82
    }
    if (IS_SEQUENCE(_45loop_labels_54952)){
            _29599 = SEQ_PTR(_45loop_labels_54952)->length;
    }
    else {
        _29599 = 1;
    }
    if (_29599 == 0)
    {
        _29599 = NOVALUE;
        goto L3; // [78] 92
    }
    else{
        _29599 = NOVALUE;
    }
L2: 

    /** parser.e:3021			parser_id = forward_Statement_list*/
    _parser_id_59442 = _45forward_Statement_list_58168;
    goto L4; // [89] 100
L3: 

    /** parser.e:3023			parser_id = top_level_parser*/
    _parser_id_59442 = _45top_level_parser_59425;
L4: 

    /** parser.e:3026		while 1 label "top" do*/
L5: 

    /** parser.e:3027			if matched = 0 and in_elsedef = 0 then*/
    _29601 = (_matched_59431 == 0LL);
    if (_29601 == 0) {
        goto L6; // [111] 656
    }
    _29603 = (_in_elsedef_59435 == 0LL);
    if (_29603 == 0)
    {
        DeRef(_29603);
        _29603 = NOVALUE;
        goto L6; // [120] 656
    }
    else{
        DeRef(_29603);
        _29603 = NOVALUE;
    }

    /** parser.e:3028				integer negate = 0, conjunction = 0*/
    _negate_59458 = 0LL;
    _conjunction_59459 = 0LL;

    /** parser.e:3029				integer at_start = 1*/
    _at_start_59460 = 1LL;

    /** parser.e:3030				sequence prev_conj = ""*/
    RefDS(_21993);
    DeRef(_prev_conj_59461);
    _prev_conj_59461 = _21993;

    /** parser.e:3032				while 1 label "deflist" do*/
L7: 

    /** parser.e:3033					option = StringToken()*/
    RefDS(_5);
    _0 = _option_59430;
    _option_59430 = _62StringToken(_5);
    DeRef(_0);

    /** parser.e:3034					if equal(option, "then") then*/
    if (_option_59430 == _26273)
    _29606 = 1;
    else if (IS_ATOM_INT(_option_59430) && IS_ATOM_INT(_26273))
    _29606 = 0;
    else
    _29606 = (compare(_option_59430, _26273) == 0);
    if (_29606 == 0)
    {
        _29606 = NOVALUE;
        goto L8; // [162] 240
    }
    else{
        _29606 = NOVALUE;
    }

    /** parser.e:3035						if at_start = 1 then*/
    if (_at_start_59460 != 1LL)
    goto L9; // [167] 187

    /** parser.e:3036							CompileErr(MSG_1_IS_MISSING_DEFINED_WORD_BEFORE_THEN, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59438);
    ((intptr_t*)_2)[1] = _keyw_59438;
    _29608 = MAKE_SEQ(_1);
    _50CompileErr(6LL, _29608, 0LL);
    _29608 = NOVALUE;
    goto LA; // [184] 542
L9: 

    /** parser.e:3037						elsif conjunction = 0 then*/
    if (_conjunction_59459 != 0LL)
    goto LB; // [189] 223

    /** parser.e:3038							if negate = 0 then*/
    if (_negate_59458 != 0LL)
    goto LC; // [195] 206

    /** parser.e:3039								exit "deflist"*/
    goto LD; // [201] 630
    goto LA; // [203] 542
LC: 

    /** parser.e:3041								CompileErr(MSG_1_THEN_FOLLOWS_NOT, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59438);
    ((intptr_t*)_2)[1] = _keyw_59438;
    _29611 = MAKE_SEQ(_1);
    _50CompileErr(11LL, _29611, 0LL);
    _29611 = NOVALUE;
    goto LA; // [220] 542
LB: 

    /** parser.e:3044							CompileErr(MSG_1_THEN_FOLLOWS_2, {keyw, prev_conj})*/
    RefDS(_prev_conj_59461);
    RefDS(_keyw_59438);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _keyw_59438;
    ((intptr_t *)_2)[2] = _prev_conj_59461;
    _29612 = MAKE_SEQ(_1);
    _50CompileErr(8LL, _29612, 0LL);
    _29612 = NOVALUE;
    goto LA; // [237] 542
L8: 

    /** parser.e:3046					elsif equal(option, "not") then*/
    if (_option_59430 == _26234)
    _29613 = 1;
    else if (IS_ATOM_INT(_option_59430) && IS_ATOM_INT(_26234))
    _29613 = 0;
    else
    _29613 = (compare(_option_59430, _26234) == 0);
    if (_29613 == 0)
    {
        _29613 = NOVALUE;
        goto LE; // [246] 284
    }
    else{
        _29613 = NOVALUE;
    }

    /** parser.e:3047						if negate = 0 then*/
    if (_negate_59458 != 0LL)
    goto LF; // [251] 267

    /** parser.e:3048							negate = 1*/
    _negate_59458 = 1LL;

    /** parser.e:3049							continue "deflist"*/
    goto L7; // [262] 148
    goto LA; // [264] 542
LF: 

    /** parser.e:3051							CompileErr(MSG_1_DUPLICATE_NOT, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59438);
    ((intptr_t*)_2)[1] = _keyw_59438;
    _29615 = MAKE_SEQ(_1);
    _50CompileErr(7LL, _29615, 0LL);
    _29615 = NOVALUE;
    goto LA; // [281] 542
LE: 

    /** parser.e:3053					elsif equal(option, "and") then*/
    if (_option_59430 == _26138)
    _29616 = 1;
    else if (IS_ATOM_INT(_option_59430) && IS_ATOM_INT(_26138))
    _29616 = 0;
    else
    _29616 = (compare(_option_59430, _26138) == 0);
    if (_29616 == 0)
    {
        _29616 = NOVALUE;
        goto L10; // [290] 357
    }
    else{
        _29616 = NOVALUE;
    }

    /** parser.e:3054						if at_start = 1 then*/
    if (_at_start_59460 != 1LL)
    goto L11; // [295] 315

    /** parser.e:3055							CompileErr(MSG_1_IS_MISSING_DEFINED_WORD_BEFORE_AND, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59438);
    ((intptr_t*)_2)[1] = _keyw_59438;
    _29618 = MAKE_SEQ(_1);
    _50CompileErr(2LL, _29618, 0LL);
    _29618 = NOVALUE;
    goto LA; // [312] 542
L11: 

    /** parser.e:3056						elsif conjunction = 0 then*/
    if (_conjunction_59459 != 0LL)
    goto L12; // [317] 340

    /** parser.e:3057							conjunction = 1*/
    _conjunction_59459 = 1LL;

    /** parser.e:3058							prev_conj = option*/
    RefDS(_option_59430);
    DeRef(_prev_conj_59461);
    _prev_conj_59461 = _option_59430;

    /** parser.e:3059							continue "deflist"*/
    goto L7; // [335] 148
    goto LA; // [337] 542
L12: 

    /** parser.e:3061							CompileErr(MSG_1_AND_FOLLOWS_2,{keyw,prev_conj})*/
    RefDS(_prev_conj_59461);
    RefDS(_keyw_59438);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _keyw_59438;
    ((intptr_t *)_2)[2] = _prev_conj_59461;
    _29620 = MAKE_SEQ(_1);
    _50CompileErr(10LL, _29620, 0LL);
    _29620 = NOVALUE;
    goto LA; // [354] 542
L10: 

    /** parser.e:3063					elsif equal(option, "or") then*/
    if (_option_59430 == _26238)
    _29621 = 1;
    else if (IS_ATOM_INT(_option_59430) && IS_ATOM_INT(_26238))
    _29621 = 0;
    else
    _29621 = (compare(_option_59430, _26238) == 0);
    if (_29621 == 0)
    {
        _29621 = NOVALUE;
        goto L13; // [363] 430
    }
    else{
        _29621 = NOVALUE;
    }

    /** parser.e:3064						if at_start = 1 then*/
    if (_at_start_59460 != 1LL)
    goto L14; // [368] 388

    /** parser.e:3065							CompileErr(MSG_1_IS_MISSING_DEFINED_WORD_BEFORE_THEN, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59438);
    ((intptr_t*)_2)[1] = _keyw_59438;
    _29623 = MAKE_SEQ(_1);
    _50CompileErr(6LL, _29623, 0LL);
    _29623 = NOVALUE;
    goto LA; // [385] 542
L14: 

    /** parser.e:3066						elsif conjunction = 0 then*/
    if (_conjunction_59459 != 0LL)
    goto L15; // [390] 413

    /** parser.e:3067							conjunction = 2*/
    _conjunction_59459 = 2LL;

    /** parser.e:3068							prev_conj = option*/
    RefDS(_option_59430);
    DeRef(_prev_conj_59461);
    _prev_conj_59461 = _option_59430;

    /** parser.e:3069							continue "deflist"*/
    goto L7; // [408] 148
    goto LA; // [410] 542
L15: 

    /** parser.e:3071							CompileErr(MSG_1_OR_FOLLOWS_2, {keyw, prev_conj})*/
    RefDS(_prev_conj_59461);
    RefDS(_keyw_59438);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _keyw_59438;
    ((intptr_t *)_2)[2] = _prev_conj_59461;
    _29625 = MAKE_SEQ(_1);
    _50CompileErr(9LL, _29625, 0LL);
    _29625 = NOVALUE;
    goto LA; // [427] 542
L13: 

    /** parser.e:3073					elsif length(option) = 0 then*/
    if (IS_SEQUENCE(_option_59430)){
            _29626 = SEQ_PTR(_option_59430)->length;
    }
    else {
        _29626 = 1;
    }
    if (_29626 != 0LL)
    goto L16; // [435] 474

    /** parser.e:3074						if at_start = 1 then*/
    if (_at_start_59460 != 1LL)
    goto L17; // [441] 461

    /** parser.e:3075							CompileErr(NO_WORD_WAS_FOUND_FOLLOWING_1, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59438);
    ((intptr_t*)_2)[1] = _keyw_59438;
    _29629 = MAKE_SEQ(_1);
    _50CompileErr(122LL, _29629, 0LL);
    _29629 = NOVALUE;
    goto LA; // [458] 542
L17: 

    /** parser.e:3077							CompileErr(EXPECTING_POSSIBLY_THEN_NOT_END_OF_LINE)*/
    RefDS(_21993);
    _50CompileErr(82LL, _21993, 0LL);
    goto LA; // [471] 542
L16: 

    /** parser.e:3079					elsif not at_start and length(prev_conj) = 0 then*/
    _29630 = (_at_start_59460 == 0);
    if (_29630 == 0) {
        goto L18; // [479] 510
    }
    if (IS_SEQUENCE(_prev_conj_59461)){
            _29632 = SEQ_PTR(_prev_conj_59461)->length;
    }
    else {
        _29632 = 1;
    }
    _29633 = (_29632 == 0LL);
    _29632 = NOVALUE;
    if (_29633 == 0)
    {
        DeRef(_29633);
        _29633 = NOVALUE;
        goto L18; // [491] 510
    }
    else{
        DeRef(_29633);
        _29633 = NOVALUE;
    }

    /** parser.e:3080						CompileErr(MSG_1_NOT_UNDERSTOOD, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59438);
    ((intptr_t*)_2)[1] = _keyw_59438;
    _29634 = MAKE_SEQ(_1);
    _50CompileErr(4LL, _29634, 0LL);
    _29634 = NOVALUE;
    goto LA; // [507] 542
L18: 

    /** parser.e:3081					elsif t_identifier(option) = 0 then*/
    RefDS(_option_59430);
    _29635 = _13t_identifier(_option_59430);
    if (binary_op_a(NOTEQ, _29635, 0LL)){
        DeRef(_29635);
        _29635 = NOVALUE;
        goto L19; // [516] 536
    }
    DeRef(_29635);
    _29635 = NOVALUE;

    /** parser.e:3082						CompileErr(MSG_1_WORD_MUST_BE_AN_IDENTIFIER, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59438);
    ((intptr_t*)_2)[1] = _keyw_59438;
    _29637 = MAKE_SEQ(_1);
    _50CompileErr(3LL, _29637, 0LL);
    _29637 = NOVALUE;
    goto LA; // [533] 542
L19: 

    /** parser.e:3084						at_start = 0*/
    _at_start_59460 = 0LL;
LA: 

    /** parser.e:3087					integer this_matched = find(option, OpDefines)*/
    _this_matched_59546 = find_from(_option_59430, _36OpDefines_21516, 1LL);

    /** parser.e:3088					if negate then*/
    if (_negate_59458 == 0)
    {
        goto L1A; // [553] 567
    }
    else{
    }

    /** parser.e:3089						this_matched = not this_matched*/
    _this_matched_59546 = (_this_matched_59546 == 0);

    /** parser.e:3090						negate = 0*/
    _negate_59458 = 0LL;
L1A: 

    /** parser.e:3093					if conjunction = 0 then*/
    if (_conjunction_59459 != 0LL)
    goto L1B; // [569] 581

    /** parser.e:3094						matched = this_matched*/
    _matched_59431 = _this_matched_59546;
    goto L1C; // [578] 623
L1B: 

    /** parser.e:3096						if conjunction = 1 then*/
    if (_conjunction_59459 != 1LL)
    goto L1D; // [583] 596

    /** parser.e:3097							matched = matched and this_matched*/
    _matched_59431 = (_matched_59431 != 0 && _this_matched_59546 != 0);
    goto L1E; // [593] 610
L1D: 

    /** parser.e:3098						elsif conjunction = 2 then*/
    if (_conjunction_59459 != 2LL)
    goto L1F; // [598] 609

    /** parser.e:3099							matched = matched or this_matched*/
    _matched_59431 = (_matched_59431 != 0 || _this_matched_59546 != 0);
L1F: 
L1E: 

    /** parser.e:3101						conjunction = 0*/
    _conjunction_59459 = 0LL;

    /** parser.e:3102						prev_conj = ""*/
    RefDS(_21993);
    DeRef(_prev_conj_59461);
    _prev_conj_59461 = _21993;
L1C: 

    /** parser.e:3104				end while*/
    goto L7; // [627] 148
LD: 

    /** parser.e:3106				in_matched = matched*/
    _in_matched_59433 = _matched_59431;

    /** parser.e:3107				if matched then*/
    if (_matched_59431 == 0)
    {
        goto L20; // [637] 655
    }
    else{
    }

    /** parser.e:3108					No_new_entry = 0*/
    _54No_new_entry_47974 = 0LL;

    /** parser.e:3109					call_proc(parser_id, {})*/
    _0 = (object)_00[_parser_id_59442].addr;
    (*(intptr_t (*)())_0)(
                         );
L20: 
L6: 
    DeRef(_prev_conj_59461);
    _prev_conj_59461 = NOVALUE;

    /** parser.e:3115			integer gotword = 0*/
    _gotword_59562 = 0LL;

    /** parser.e:3116			integer gotthen = 0*/
    _gotthen_59563 = 0LL;

    /** parser.e:3117			integer if_lvl  = 0*/
    _if_lvl_59564 = 0LL;

    /** parser.e:3118			No_new_entry = not matched*/
    _54No_new_entry_47974 = (_matched_59431 == 0);

    /** parser.e:3119			has_matched = has_matched or matched*/
    _has_matched_59432 = (_has_matched_59432 != 0 || _matched_59431 != 0);

    /** parser.e:3120			keyw = "elsifdef"*/
    RefDS(_26174);
    DeRefi(_keyw_59438);
    _keyw_59438 = _26174;

    /** parser.e:3121			while 1 do*/
L21: 

    /** parser.e:3122				tok = next_token()*/
    _0 = _tok_59437;
    _tok_59437 = _45next_token();
    DeRef(_0);

    /** parser.e:3123				if tok[T_ID] = END_OF_FILE then*/
    _2 = (object)SEQ_PTR(_tok_59437);
    _29648 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29648, -21LL)){
        _29648 = NOVALUE;
        goto L22; // [713] 738
    }
    _29648 = NOVALUE;

    /** parser.e:3124					CompileErr(END_OF_FILE_REACHED_WHILE_SEARCHING_FOR_END_IFDEF_TO_MATCH_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_45ifdef_lineno_59427)){
            _29650 = SEQ_PTR(_45ifdef_lineno_59427)->length;
    }
    else {
        _29650 = 1;
    }
    _2 = (object)SEQ_PTR(_45ifdef_lineno_59427);
    _29651 = (object)*(((s1_ptr)_2)->base + _29650);
    _50CompileErr(65LL, _29651, 0LL);
    _29651 = NOVALUE;
    goto L21; // [735] 698
L22: 

    /** parser.e:3125				elsif tok[T_ID] = END then*/
    _2 = (object)SEQ_PTR(_tok_59437);
    _29652 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29652, 402LL)){
        _29652 = NOVALUE;
        goto L23; // [748] 874
    }
    _29652 = NOVALUE;

    /** parser.e:3126					tok = next_token()*/
    _0 = _tok_59437;
    _tok_59437 = _45next_token();
    DeRef(_0);

    /** parser.e:3127					if tok[T_ID] = IFDEF then*/
    _2 = (object)SEQ_PTR(_tok_59437);
    _29655 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29655, 407LL)){
        _29655 = NOVALUE;
        goto L24; // [767] 795
    }
    _29655 = NOVALUE;

    /** parser.e:3128						if dead_ifdef then*/
    if (_dead_ifdef_59434 == 0)
    {
        goto L25; // [773] 785
    }
    else{
    }

    /** parser.e:3129							dead_ifdef -= 1*/
    _dead_ifdef_59434 = _dead_ifdef_59434 - 1LL;
    goto L21; // [782] 698
L25: 

    /** parser.e:3131							exit "top"*/
    goto L26; // [789] 1350
    goto L21; // [792] 698
L24: 

    /** parser.e:3133					elsif in_matched then*/
    if (_in_matched_59433 == 0)
    {
        goto L27; // [797] 821
    }
    else{
    }

    /** parser.e:3135						CompileErr(EXPECTING_END_IFDEF_TO_MATCH_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_45ifdef_lineno_59427)){
            _29658 = SEQ_PTR(_45ifdef_lineno_59427)->length;
    }
    else {
        _29658 = 1;
    }
    _2 = (object)SEQ_PTR(_45ifdef_lineno_59427);
    _29659 = (object)*(((s1_ptr)_2)->base + _29658);
    _50CompileErr(75LL, _29659, 0LL);
    _29659 = NOVALUE;
    goto L21; // [818] 698
L27: 

    /** parser.e:3137						if tok[T_ID] = IF then*/
    _2 = (object)SEQ_PTR(_tok_59437);
    _29660 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29660, 20LL)){
        _29660 = NOVALUE;
        goto L21; // [831] 698
    }
    _29660 = NOVALUE;

    /** parser.e:3138							if if_lvl > 0 then*/
    if (_if_lvl_59564 <= 0LL)
    goto L28; // [837] 850

    /** parser.e:3139								if_lvl -= 1*/
    _if_lvl_59564 = _if_lvl_59564 - 1LL;
    goto L21; // [847] 698
L28: 

    /** parser.e:3141								CompileErr(MISMATCHED_END_IF_SHOULD_THIS_BE_AN_END_IFDEF_TO_MATCH_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_45ifdef_lineno_59427)){
            _29664 = SEQ_PTR(_45ifdef_lineno_59427)->length;
    }
    else {
        _29664 = 1;
    }
    _2 = (object)SEQ_PTR(_45ifdef_lineno_59427);
    _29665 = (object)*(((s1_ptr)_2)->base + _29664);
    _50CompileErr(111LL, _29665, 0LL);
    _29665 = NOVALUE;
    goto L21; // [871] 698
L23: 

    /** parser.e:3145				elsif tok[T_ID] = IF then*/
    _2 = (object)SEQ_PTR(_tok_59437);
    _29666 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29666, 20LL)){
        _29666 = NOVALUE;
        goto L29; // [884] 897
    }
    _29666 = NOVALUE;

    /** parser.e:3146					if_lvl += 1*/
    _if_lvl_59564 = _if_lvl_59564 + 1;
    goto L21; // [894] 698
L29: 

    /** parser.e:3147				elsif tok[T_ID] = ELSE then*/
    _2 = (object)SEQ_PTR(_tok_59437);
    _29669 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29669, 23LL)){
        _29669 = NOVALUE;
        goto L2A; // [907] 945
    }
    _29669 = NOVALUE;

    /** parser.e:3148					if not in_matched then*/
    if (_in_matched_59433 != 0)
    goto L21; // [913] 698

    /** parser.e:3149						if if_lvl = 0 then*/
    if (_if_lvl_59564 != 0LL)
    goto L21; // [918] 698

    /** parser.e:3150							CompileErr(MISMATCHED_ELSE_SHOULD_THIS_BE_AN_ELSEDEF_TO_MATCH_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_45ifdef_lineno_59427)){
            _29673 = SEQ_PTR(_45ifdef_lineno_59427)->length;
    }
    else {
        _29673 = 1;
    }
    _2 = (object)SEQ_PTR(_45ifdef_lineno_59427);
    _29674 = (object)*(((s1_ptr)_2)->base + _29673);
    _50CompileErr(108LL, _29674, 0LL);
    _29674 = NOVALUE;
    goto L21; // [942] 698
L2A: 

    /** parser.e:3153				elsif tok[T_ID] = ELSIFDEF and not dead_ifdef then*/
    _2 = (object)SEQ_PTR(_tok_59437);
    _29675 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_29675)) {
        _29676 = (_29675 == 408LL);
    }
    else {
        _29676 = binary_op(EQUALS, _29675, 408LL);
    }
    _29675 = NOVALUE;
    if (IS_ATOM_INT(_29676)) {
        if (_29676 == 0) {
            goto L2B; // [959] 1101
        }
    }
    else {
        if (DBL_PTR(_29676)->dbl == 0.0) {
            goto L2B; // [959] 1101
        }
    }
    _29678 = (_dead_ifdef_59434 == 0);
    if (_29678 == 0)
    {
        DeRef(_29678);
        _29678 = NOVALUE;
        goto L2B; // [967] 1101
    }
    else{
        DeRef(_29678);
        _29678 = NOVALUE;
    }

    /** parser.e:3154					if has_matched then*/
    if (_has_matched_59432 == 0)
    {
        goto L2C; // [972] 1343
    }
    else{
    }

    /** parser.e:3155						in_matched = 0*/
    _in_matched_59433 = 0LL;

    /** parser.e:3156						No_new_entry = 1*/
    _54No_new_entry_47974 = 1LL;

    /** parser.e:3157						gotword = 0*/
    _gotword_59562 = 0LL;

    /** parser.e:3158						gotthen = 0*/
    _gotthen_59563 = 0LL;

    /** parser.e:3159						while length(option) > 0 with entry do*/
    goto L2D; // [999] 1041
L2E: 
    if (IS_SEQUENCE(_option_59430)){
            _29679 = SEQ_PTR(_option_59430)->length;
    }
    else {
        _29679 = 1;
    }
    if (_29679 <= 0LL)
    goto L2F; // [1007] 1054

    /** parser.e:3160							if equal(option, "then") then*/
    if (_option_59430 == _26273)
    _29681 = 1;
    else if (IS_ATOM_INT(_option_59430) && IS_ATOM_INT(_26273))
    _29681 = 0;
    else
    _29681 = (compare(_option_59430, _26273) == 0);
    if (_29681 == 0)
    {
        _29681 = NOVALUE;
        goto L30; // [1017] 1032
    }
    else{
        _29681 = NOVALUE;
    }

    /** parser.e:3161								gotthen = 1*/
    _gotthen_59563 = 1LL;

    /** parser.e:3162								exit*/
    goto L2F; // [1027] 1054
    goto L31; // [1029] 1038
L30: 

    /** parser.e:3164								gotword = 1*/
    _gotword_59562 = 1LL;
L31: 

    /** parser.e:3166						entry*/
L2D: 

    /** parser.e:3167							option = StringToken()*/
    RefDS(_5);
    _0 = _option_59430;
    _option_59430 = _62StringToken(_5);
    DeRef(_0);

    /** parser.e:3168						end while*/
    goto L2E; // [1051] 1002
L2F: 

    /** parser.e:3169						if gotword = 0 then*/
    if (_gotword_59562 != 0LL)
    goto L32; // [1056] 1070

    /** parser.e:3170							CompileErr(EXPECTING_A_WORD_TO_FOLLOW_ELSIFDEF)*/
    RefDS(_21993);
    _50CompileErr(78LL, _21993, 0LL);
L32: 

    /** parser.e:3172						if gotthen = 0 then*/
    if (_gotthen_59563 != 0LL)
    goto L33; // [1072] 1086

    /** parser.e:3173							CompileErr(EXPECTING_THEN_ON_ELSIFDEF_LINE)*/
    RefDS(_21993);
    _50CompileErr(77LL, _21993, 0LL);
L33: 

    /** parser.e:3175						read_line()*/
    _62read_line();
    goto L21; // [1090] 698

    /** parser.e:3177						exit*/
    goto L2C; // [1095] 1343
    goto L21; // [1098] 698
L2B: 

    /** parser.e:3179				elsif tok[T_ID] = ELSEDEF then*/
    _2 = (object)SEQ_PTR(_tok_59437);
    _29685 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29685, 409LL)){
        _29685 = NOVALUE;
        goto L34; // [1111] 1273
    }
    _29685 = NOVALUE;

    /** parser.e:3180					gotword = line_number*/
    _gotword_59562 = _36line_number_21440;

    /** parser.e:3181					option = StringToken()*/
    RefDS(_5);
    _0 = _option_59430;
    _option_59430 = _62StringToken(_5);
    DeRef(_0);

    /** parser.e:3182					if length(option) > 0 then*/
    if (IS_SEQUENCE(_option_59430)){
            _29688 = SEQ_PTR(_option_59430)->length;
    }
    else {
        _29688 = 1;
    }
    if (_29688 <= 0LL)
    goto L35; // [1137] 1173

    /** parser.e:3183						if line_number = gotword then*/
    if (_36line_number_21440 != _gotword_59562)
    goto L36; // [1145] 1159

    /** parser.e:3184							CompileErr(NOT_EXPECTING_ANYTHING_ON_SAME_LINE_AS_ELSDEF)*/
    RefDS(_21993);
    _50CompileErr(116LL, _21993, 0LL);
L36: 

    /** parser.e:3186						bp -= length(option)*/
    if (IS_SEQUENCE(_option_59430)){
            _29691 = SEQ_PTR(_option_59430)->length;
    }
    else {
        _29691 = 1;
    }
    _50bp_49238 = _50bp_49238 - _29691;
    _29691 = NOVALUE;
L35: 

    /** parser.e:3188					if not dead_ifdef then*/
    if (_dead_ifdef_59434 != 0)
    goto L21; // [1175] 698

    /** parser.e:3189						if has_matched then*/
    if (_has_matched_59432 == 0)
    {
        goto L37; // [1180] 1202
    }
    else{
    }

    /** parser.e:3190							in_matched = 0*/
    _in_matched_59433 = 0LL;

    /** parser.e:3191							No_new_entry = 1*/
    _54No_new_entry_47974 = 1LL;

    /** parser.e:3192							read_line()*/
    _62read_line();
    goto L21; // [1199] 698
L37: 

    /** parser.e:3194							No_new_entry = 0*/
    _54No_new_entry_47974 = 0LL;

    /** parser.e:3195							in_elsedef = 1*/
    _in_elsedef_59435 = 1LL;

    /** parser.e:3196							call_proc(parser_id, {})*/
    _0 = (object)_00[_parser_id_59442].addr;
    (*(intptr_t (*)())_0)(
                         );

    /** parser.e:3197							tok_match(END)*/
    _45tok_match(402LL, 0LL);

    /** parser.e:3198							tok_match(IFDEF, END)*/
    _45tok_match(407LL, 402LL);

    /** parser.e:3199							live_ifdef -= 1*/
    _45live_ifdef_59426 = _45live_ifdef_59426 - 1LL;

    /** parser.e:3200							ifdef_lineno = ifdef_lineno[1..$-1]*/
    if (IS_SEQUENCE(_45ifdef_lineno_59427)){
            _29695 = SEQ_PTR(_45ifdef_lineno_59427)->length;
    }
    else {
        _29695 = 1;
    }
    _29696 = _29695 - 1LL;
    _29695 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45ifdef_lineno_59427;
    RHS_Slice(_45ifdef_lineno_59427, 1LL, _29696);

    /** parser.e:3201							return*/
    DeRef(_option_59430);
    DeRef(_tok_59437);
    DeRefi(_keyw_59438);
    DeRef(_29630);
    _29630 = NOVALUE;
    DeRef(_29595);
    _29595 = NOVALUE;
    _29696 = NOVALUE;
    DeRef(_29676);
    _29676 = NOVALUE;
    DeRef(_29601);
    _29601 = NOVALUE;
    return;
    goto L21; // [1270] 698
L34: 

    /** parser.e:3204				elsif tok[T_ID] = IFDEF then*/
    _2 = (object)SEQ_PTR(_tok_59437);
    _29698 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29698, 407LL)){
        _29698 = NOVALUE;
        goto L38; // [1283] 1296
    }
    _29698 = NOVALUE;

    /** parser.e:3205					dead_ifdef += 1*/
    _dead_ifdef_59434 = _dead_ifdef_59434 + 1;
    goto L21; // [1293] 698
L38: 

    /** parser.e:3207				elsif tok[T_ID] = INCLUDE then*/
    _2 = (object)SEQ_PTR(_tok_59437);
    _29701 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29701, 418LL)){
        _29701 = NOVALUE;
        goto L39; // [1306] 1317
    }
    _29701 = NOVALUE;

    /** parser.e:3209					read_line()*/
    _62read_line();
    goto L21; // [1314] 698
L39: 

    /** parser.e:3211				elsif tok[T_ID] = CASE then*/
    _2 = (object)SEQ_PTR(_tok_59437);
    _29703 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29703, 186LL)){
        _29703 = NOVALUE;
        goto L21; // [1327] 698
    }
    _29703 = NOVALUE;

    /** parser.e:3213					tok = next_token()*/
    _0 = _tok_59437;
    _tok_59437 = _45next_token();
    DeRef(_0);

    /** parser.e:3216			end while*/
    goto L21; // [1340] 698
L2C: 

    /** parser.e:3217		end while*/
    goto L5; // [1347] 105
L26: 

    /** parser.e:3219		live_ifdef -= 1*/
    _45live_ifdef_59426 = _45live_ifdef_59426 - 1LL;

    /** parser.e:3220		ifdef_lineno = ifdef_lineno[1..$-1]*/
    if (IS_SEQUENCE(_45ifdef_lineno_59427)){
            _29707 = SEQ_PTR(_45ifdef_lineno_59427)->length;
    }
    else {
        _29707 = 1;
    }
    _29708 = _29707 - 1LL;
    _29707 = NOVALUE;
    rhs_slice_target = (object_ptr)&_45ifdef_lineno_59427;
    RHS_Slice(_45ifdef_lineno_59427, 1LL, _29708);

    /** parser.e:3221		No_new_entry = 0*/
    _54No_new_entry_47974 = 0LL;

    /** parser.e:3222	end procedure*/
    DeRef(_option_59430);
    DeRef(_tok_59437);
    DeRefi(_keyw_59438);
    DeRef(_29630);
    _29630 = NOVALUE;
    DeRef(_29595);
    _29595 = NOVALUE;
    DeRef(_29696);
    _29696 = NOVALUE;
    DeRef(_29676);
    _29676 = NOVALUE;
    DeRef(_29601);
    _29601 = NOVALUE;
    _29708 = NOVALUE;
    return;
    ;
}


object _45SetPrivateScope(object _s_59717, object _type_sym_59719, object _n_59720)
{
    object _hashval_59721 = NOVALUE;
    object _scope_59722 = NOVALUE;
    object _t_59724 = NOVALUE;
    object _29729 = NOVALUE;
    object _29728 = NOVALUE;
    object _29727 = NOVALUE;
    object _29726 = NOVALUE;
    object _29725 = NOVALUE;
    object _29724 = NOVALUE;
    object _29721 = NOVALUE;
    object _29718 = NOVALUE;
    object _29716 = NOVALUE;
    object _29714 = NOVALUE;
    object _29710 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_59717)) {
        _1 = (object)(DBL_PTR(_s_59717)->dbl);
        DeRefDS(_s_59717);
        _s_59717 = _1;
    }

    /** parser.e:3230		scope = SymTab[s][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29710 = (object)*(((s1_ptr)_2)->base + _s_59717);
    _2 = (object)SEQ_PTR(_29710);
    _scope_59722 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_scope_59722)){
        _scope_59722 = (object)DBL_PTR(_scope_59722)->dbl;
    }
    _29710 = NOVALUE;

    /** parser.e:3231		switch scope do*/
    _0 = _scope_59722;
    switch ( _0 ){ 

        /** parser.e:3232			case SC_PRIVATE then*/
        case 3:

        /** parser.e:3233				DefinedYet(s)*/
        _54DefinedYet(_s_59717);

        /** parser.e:3234				Block_var( s )*/
        _65Block_var(_s_59717);

        /** parser.e:3235				return s*/
        return _s_59717;
        goto L1; // [50] 260

        /** parser.e:3237			case SC_LOOP_VAR then*/
        case 2:

        /** parser.e:3238				DefinedYet(s)*/
        _54DefinedYet(_s_59717);

        /** parser.e:3239				return s*/
        return _s_59717;
        goto L1; // [67] 260

        /** parser.e:3241			case SC_UNDEFINED, SC_MULTIPLY_DEFINED then*/
        case 9:
        case 10:

        /** parser.e:3242				SymTab[s][S_SCOPE] = SC_PRIVATE*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_s_59717 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 4LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 3LL;
        DeRef(_1);
        _29714 = NOVALUE;

        /** parser.e:3243				SymTab[s][S_VARNUM] = n*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_s_59717 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 16LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _n_59720;
        DeRef(_1);
        _29716 = NOVALUE;

        /** parser.e:3244				SymTab[s][S_VTYPE] = type_sym*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_s_59717 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 15LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _type_sym_59719;
        DeRef(_1);
        _29718 = NOVALUE;

        /** parser.e:3245				if type_sym < 0 then*/
        if (_type_sym_59719 >= 0LL)
        goto L2; // [124] 135

        /** parser.e:3246					register_forward_type( s, type_sym )*/
        _44register_forward_type(_s_59717, _type_sym_59719);
L2: 

        /** parser.e:3248				Block_var( s )*/
        _65Block_var(_s_59717);

        /** parser.e:3249				return s*/
        return _s_59717;
        goto L1; // [146] 260

        /** parser.e:3251			case SC_LOCAL, SC_GLOBAL, SC_PREDEF, SC_PUBLIC, SC_EXPORT then*/
        case 5:
        case 6:
        case 7:
        case 13:
        case 11:

        /** parser.e:3252				hashval = SymTab[s][S_HASHVAL]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _29721 = (object)*(((s1_ptr)_2)->base + _s_59717);
        _2 = (object)SEQ_PTR(_29721);
        _hashval_59721 = (object)*(((s1_ptr)_2)->base + 11LL);
        if (!IS_ATOM_INT(_hashval_59721)){
            _hashval_59721 = (object)DBL_PTR(_hashval_59721)->dbl;
        }
        _29721 = NOVALUE;

        /** parser.e:3253				t = buckets[hashval]*/
        _2 = (object)SEQ_PTR(_54buckets_46772);
        _t_59724 = (object)*(((s1_ptr)_2)->base + _hashval_59721);
        if (!IS_ATOM_INT(_t_59724)){
            _t_59724 = (object)DBL_PTR(_t_59724)->dbl;
        }

        /** parser.e:3254				buckets[hashval] = NewEntry(SymTab[s][S_NAME], n, SC_PRIVATE,*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _29724 = (object)*(((s1_ptr)_2)->base + _s_59717);
        _2 = (object)SEQ_PTR(_29724);
        if (!IS_ATOM_INT(_36S_NAME_21076)){
            _29725 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
        }
        else{
            _29725 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
        }
        _29724 = NOVALUE;
        Ref(_29725);
        _29726 = _54NewEntry(_29725, _n_59720, 3LL, -100LL, _hashval_59721, _t_59724, _type_sym_59719);
        _29725 = NOVALUE;
        _2 = (object)SEQ_PTR(_54buckets_46772);
        _2 = (object)(((s1_ptr)_2)->base + _hashval_59721);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _29726;
        if( _1 != _29726 ){
            DeRef(_1);
        }
        _29726 = NOVALUE;

        /** parser.e:3256				Block_var( buckets[hashval] )*/
        _2 = (object)SEQ_PTR(_54buckets_46772);
        _29727 = (object)*(((s1_ptr)_2)->base + _hashval_59721);
        Ref(_29727);
        _65Block_var(_29727);
        _29727 = NOVALUE;

        /** parser.e:3257				return buckets[hashval]*/
        _2 = (object)SEQ_PTR(_54buckets_46772);
        _29728 = (object)*(((s1_ptr)_2)->base + _hashval_59721);
        Ref(_29728);
        return _29728;
        goto L1; // [243] 260

        /** parser.e:3259			case else*/
        default:

        /** parser.e:3260				InternalErr(267, {scope})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _scope_59722;
        _29729 = MAKE_SEQ(_1);
        _50InternalErr(267LL, _29729);
        _29729 = NOVALUE;
    ;}L1: 

    /** parser.e:3264		return 0*/
    _29728 = NOVALUE;
    return 0LL;
    ;
}


void _45For_statement()
{
    object _bp1_59789 = NOVALUE;
    object _bp2_59790 = NOVALUE;
    object _exit_base_59791 = NOVALUE;
    object _next_base_59792 = NOVALUE;
    object _end_op_59793 = NOVALUE;
    object _tok_59795 = NOVALUE;
    object _loop_var_59796 = NOVALUE;
    object _loop_var_sym_59798 = NOVALUE;
    object _save_syms_59799 = NOVALUE;
    object _29776 = NOVALUE;
    object _29774 = NOVALUE;
    object _29773 = NOVALUE;
    object _29767 = NOVALUE;
    object _29765 = NOVALUE;
    object _29763 = NOVALUE;
    object _29762 = NOVALUE;
    object _29761 = NOVALUE;
    object _29760 = NOVALUE;
    object _29758 = NOVALUE;
    object _29756 = NOVALUE;
    object _29755 = NOVALUE;
    object _29754 = NOVALUE;
    object _29753 = NOVALUE;
    object _29751 = NOVALUE;
    object _29749 = NOVALUE;
    object _29745 = NOVALUE;
    object _29743 = NOVALUE;
    object _29740 = NOVALUE;
    object _29738 = NOVALUE;
    object _29732 = NOVALUE;
    object _29731 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:3273		sequence save_syms*/

    /** parser.e:3275		Start_block( FOR )*/
    _65Start_block(21LL, 0LL);

    /** parser.e:3276		loop_var = next_token()*/
    _0 = _loop_var_59796;
    _loop_var_59796 = _45next_token();
    DeRef(_0);

    /** parser.e:3277		if not find(loop_var[T_ID], ADDR_TOKS) then*/
    _2 = (object)SEQ_PTR(_loop_var_59796);
    _29731 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29732 = find_from(_29731, _38ADDR_TOKS_16049, 1LL);
    _29731 = NOVALUE;
    if (_29732 != 0)
    goto L1; // [31] 44
    _29732 = NOVALUE;

    /** parser.e:3278			CompileErr(A_LOOP_VARIABLE_NAME_IS_EXPECTED_HERE)*/
    RefDS(_21993);
    _50CompileErr(28LL, _21993, 0LL);
L1: 

    /** parser.e:3281		if BIND then*/
    if (_36BIND_21044 == 0)
    {
        goto L2; // [48] 57
    }
    else{
    }

    /** parser.e:3282			add_ref(loop_var)*/
    Ref(_loop_var_59796);
    _54add_ref(_loop_var_59796);
L2: 

    /** parser.e:3285		tok_match(EQUALS)*/
    _45tok_match(3LL, 0LL);

    /** parser.e:3286		exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_45exit_list_54944)){
            _exit_base_59791 = SEQ_PTR(_45exit_list_54944)->length;
    }
    else {
        _exit_base_59791 = 1;
    }

    /** parser.e:3287		next_base = length(continue_list)*/
    if (IS_SEQUENCE(_45continue_list_54946)){
            _next_base_59792 = SEQ_PTR(_45continue_list_54946)->length;
    }
    else {
        _next_base_59792 = 1;
    }

    /** parser.e:3288		Expr()*/
    _45Expr();

    /** parser.e:3289		tok_match(TO)*/
    _45tok_match(403LL, 0LL);

    /** parser.e:3290		exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_45exit_list_54944)){
            _exit_base_59791 = SEQ_PTR(_45exit_list_54944)->length;
    }
    else {
        _exit_base_59791 = 1;
    }

    /** parser.e:3291		Expr()*/
    _45Expr();

    /** parser.e:3292		tok = next_token()*/
    _0 = _tok_59795;
    _tok_59795 = _45next_token();
    DeRef(_0);

    /** parser.e:3293		if tok[T_ID] = BY then*/
    _2 = (object)SEQ_PTR(_tok_59795);
    _29738 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29738, 404LL)){
        _29738 = NOVALUE;
        goto L3; // [117] 137
    }
    _29738 = NOVALUE;

    /** parser.e:3294			Expr()*/
    _45Expr();

    /** parser.e:3295			end_op = ENDFOR_GENERAL -- will be set at runtime by FOR op*/
    _end_op_59793 = 39LL;
    goto L4; // [134] 161
L3: 

    /** parser.e:3298			emit_opnd(NewIntSym(1))*/
    _29740 = _54NewIntSym(1LL);
    _47emit_opnd(_29740);
    _29740 = NOVALUE;

    /** parser.e:3299			putback(tok)*/
    Ref(_tok_59795);
    _45putback(_tok_59795);

    /** parser.e:3300			end_op = ENDFOR_INT_UP1*/
    _end_op_59793 = 54LL;
L4: 

    /** parser.e:3303		loop_var_sym = loop_var[T_SYM]*/
    _2 = (object)SEQ_PTR(_loop_var_59796);
    _loop_var_sym_59798 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_loop_var_sym_59798)){
        _loop_var_sym_59798 = (object)DBL_PTR(_loop_var_sym_59798)->dbl;
    }

    /** parser.e:3304		if CurrentSub = TopLevelSub then*/
    if (_36CurrentSub_21447 != _36TopLevelSub_21446)
    goto L5; // [177] 223

    /** parser.e:3305			DefinedYet(loop_var_sym)*/
    _54DefinedYet(_loop_var_sym_59798);

    /** parser.e:3306			SymTab[loop_var_sym][S_SCOPE] = SC_GLOOP_VAR*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_loop_var_sym_59798 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 4LL;
    DeRef(_1);
    _29743 = NOVALUE;

    /** parser.e:3307			SymTab[loop_var_sym][S_VTYPE] = object_type*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_loop_var_sym_59798 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _54object_type_46776;
    DeRef(_1);
    _29745 = NOVALUE;
    goto L6; // [220] 267
L5: 

    /** parser.e:3309			loop_var_sym = SetPrivateScope(loop_var_sym, object_type, param_num)*/
    _loop_var_sym_59798 = _45SetPrivateScope(_loop_var_sym_59798, _54object_type_46776, _45param_num_54933);
    if (!IS_ATOM_INT(_loop_var_sym_59798)) {
        _1 = (object)(DBL_PTR(_loop_var_sym_59798)->dbl);
        DeRefDS(_loop_var_sym_59798);
        _loop_var_sym_59798 = _1;
    }

    /** parser.e:3310			param_num += 1*/
    _45param_num_54933 = _45param_num_54933 + 1;

    /** parser.e:3311			SymTab[loop_var_sym][S_SCOPE] = SC_LOOP_VAR*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_loop_var_sym_59798 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _29749 = NOVALUE;

    /** parser.e:3312			Pop_block_var()*/
    _65Pop_block_var();
L6: 

    /** parser.e:3314		SymTab[loop_var_sym][S_USAGE] = or_bits(SymTab[loop_var_sym][S_USAGE], U_USED)*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_loop_var_sym_59798 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29753 = (object)*(((s1_ptr)_2)->base + _loop_var_sym_59798);
    _2 = (object)SEQ_PTR(_29753);
    _29754 = (object)*(((s1_ptr)_2)->base + 5LL);
    _29753 = NOVALUE;
    if (IS_ATOM_INT(_29754)) {
        {uintptr_t tu;
             tu = (uintptr_t)_29754 | (uintptr_t)3LL;
             _29755 = MAKE_UINT(tu);
        }
    }
    else {
        _29755 = binary_op(OR_BITS, _29754, 3LL);
    }
    _29754 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29755;
    if( _1 != _29755 ){
        DeRef(_1);
    }
    _29755 = NOVALUE;
    _29751 = NOVALUE;

    /** parser.e:3316		op_info1 = loop_var_sym*/
    _47op_info1_50932 = _loop_var_sym_59798;

    /** parser.e:3317		emit_op(FOR)*/
    _47emit_op(21LL);

    /** parser.e:3318		emit_addr(loop_var_sym)*/
    _47emit_addr(_loop_var_sym_59798);

    /** parser.e:3319		if finish_block_header(FOR) then*/
    _29756 = _45finish_block_header(21LL);
    if (_29756 == 0) {
        DeRef(_29756);
        _29756 = NOVALUE;
        goto L7; // [327] 340
    }
    else {
        if (!IS_ATOM_INT(_29756) && DBL_PTR(_29756)->dbl == 0.0){
            DeRef(_29756);
            _29756 = NOVALUE;
            goto L7; // [327] 340
        }
        DeRef(_29756);
        _29756 = NOVALUE;
    }
    DeRef(_29756);
    _29756 = NOVALUE;

    /** parser.e:3320			CompileErr(ENTRY_IS_NOT_SUPPORTED_IN_FOR_LOOPS)*/
    RefDS(_21993);
    _50CompileErr(83LL, _21993, 0LL);
L7: 

    /** parser.e:3322		entry_addr &= 0*/
    Append(&_45entry_addr_54948, _45entry_addr_54948, 0LL);

    /** parser.e:3323		bp1 = length(Code)+1*/
    if (IS_SEQUENCE(_36Code_21531)){
            _29758 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29758 = 1;
    }
    _bp1_59789 = _29758 + 1;
    _29758 = NOVALUE;

    /** parser.e:3324		emit_addr(0) -- will be patched - don't straighten*/
    _47emit_addr(0LL);

    /** parser.e:3326		save_syms = Code[$-5..$-3] -- could be temps, but can't get rid of them yet*/
    if (IS_SEQUENCE(_36Code_21531)){
            _29760 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29760 = 1;
    }
    _29761 = _29760 - 5LL;
    _29760 = NOVALUE;
    if (IS_SEQUENCE(_36Code_21531)){
            _29762 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29762 = 1;
    }
    _29763 = _29762 - 3LL;
    _29762 = NOVALUE;
    rhs_slice_target = (object_ptr)&_save_syms_59799;
    RHS_Slice(_36Code_21531, _29761, _29763);

    /** parser.e:3327		for i = 1 to 3 do*/
    {
        object _i_59889;
        _i_59889 = 1LL;
L8: 
        if (_i_59889 > 3LL){
            goto L9; // [389] 412
        }

        /** parser.e:3328			clear_temp( save_syms[i] )*/
        _2 = (object)SEQ_PTR(_save_syms_59799);
        _29765 = (object)*(((s1_ptr)_2)->base + _i_59889);
        Ref(_29765);
        _47clear_temp(_29765);
        _29765 = NOVALUE;

        /** parser.e:3329		end for*/
        _i_59889 = _i_59889 + 1LL;
        goto L8; // [407] 396
L9: 
        ;
    }

    /** parser.e:3330		flush_temps()*/
    RefDS(_21993);
    _47flush_temps(_21993);

    /** parser.e:3332		bp2 = length(Code)*/
    if (IS_SEQUENCE(_36Code_21531)){
            _bp2_59790 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _bp2_59790 = 1;
    }

    /** parser.e:3333		retry_addr &= bp2 + 1*/
    _29767 = _bp2_59790 + 1;
    Append(&_45retry_addr_54950, _45retry_addr_54950, _29767);
    _29767 = NOVALUE;

    /** parser.e:3334		continue_addr &= 0*/
    Append(&_45continue_addr_54949, _45continue_addr_54949, 0LL);

    /** parser.e:3336		loop_stack &= FOR*/
    Append(&_45loop_stack_54958, _45loop_stack_54958, 21LL);

    /** parser.e:3338		if not TRANSLATE then*/
    if (_36TRANSLATE_21041 != 0)
    goto LA; // [458] 482

    /** parser.e:3339			if OpTrace then*/
    if (_36OpTrace_21512 == 0)
    {
        goto LB; // [465] 481
    }
    else{
    }

    /** parser.e:3340				emit_op(DISPLAY_VAR)*/
    _47emit_op(87LL);

    /** parser.e:3341				emit_addr(loop_var_sym)*/
    _47emit_addr(_loop_var_sym_59798);
LB: 
LA: 

    /** parser.e:3345		Statement_list()*/
    _45Statement_list();

    /** parser.e:3346		tok_match(END)*/
    _45tok_match(402LL, 0LL);

    /** parser.e:3347		tok_match(FOR, END)*/
    _45tok_match(21LL, 402LL);

    /** parser.e:3349		End_block( FOR )*/
    _65End_block(21LL);

    /** parser.e:3351		StartSourceLine(TRUE, TRANSLATE)*/
    _47StartSourceLine(_13TRUE_452, _36TRANSLATE_21041, 2LL);

    /** parser.e:3352		op_info1 = loop_var_sym*/
    _47op_info1_50932 = _loop_var_sym_59798;

    /** parser.e:3353		op_info2 = bp2 + 1*/
    _47op_info2_50933 = _bp2_59790 + 1;

    /** parser.e:3354		PatchNList(next_base)*/
    _45PatchNList(_next_base_59792);

    /** parser.e:3355		emit_op(end_op)*/
    _47emit_op(_end_op_59793);

    /** parser.e:3356		backpatch(bp1, length(Code)+1)*/
    if (IS_SEQUENCE(_36Code_21531)){
            _29773 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29773 = 1;
    }
    _29774 = _29773 + 1;
    _29773 = NOVALUE;
    _47backpatch(_bp1_59789, _29774);
    _29774 = NOVALUE;

    /** parser.e:3357		if not TRANSLATE then*/
    if (_36TRANSLATE_21041 != 0)
    goto LC; // [568] 592

    /** parser.e:3358			if OpTrace then*/
    if (_36OpTrace_21512 == 0)
    {
        goto LD; // [575] 591
    }
    else{
    }

    /** parser.e:3359				emit_op(ERASE_SYMBOL)*/
    _47emit_op(90LL);

    /** parser.e:3360				emit_addr(loop_var_sym)*/
    _47emit_addr(_loop_var_sym_59798);
LD: 
LC: 

    /** parser.e:3364		Hide(loop_var_sym)*/
    _54Hide(_loop_var_sym_59798);

    /** parser.e:3365		exit_loop(exit_base)*/
    _45exit_loop(_exit_base_59791);

    /** parser.e:3366		for i = 1 to 3 do*/
    {
        object _i_59935;
        _i_59935 = 1LL;
LE: 
        if (_i_59935 > 3LL){
            goto LF; // [604] 630
        }

        /** parser.e:3367			emit_temp( save_syms[i], NEW_REFERENCE )*/
        _2 = (object)SEQ_PTR(_save_syms_59799);
        _29776 = (object)*(((s1_ptr)_2)->base + _i_59935);
        Ref(_29776);
        _47emit_temp(_29776, 1LL);
        _29776 = NOVALUE;

        /** parser.e:3368		end for*/
        _i_59935 = _i_59935 + 1LL;
        goto LE; // [625] 611
LF: 
        ;
    }

    /** parser.e:3369		flush_temps()*/
    RefDS(_21993);
    _47flush_temps(_21993);

    /** parser.e:3370	end procedure*/
    DeRef(_tok_59795);
    DeRef(_loop_var_59796);
    DeRef(_save_syms_59799);
    DeRef(_29761);
    _29761 = NOVALUE;
    DeRef(_29763);
    _29763 = NOVALUE;
    return;
    ;
}


object _45CompileType(object _type_ptr_59943)
{
    object _t_59944 = NOVALUE;
    object _29787 = NOVALUE;
    object _29786 = NOVALUE;
    object _29785 = NOVALUE;
    object _29779 = NOVALUE;
    object _29778 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_type_ptr_59943)) {
        _1 = (object)(DBL_PTR(_type_ptr_59943)->dbl);
        DeRefDS(_type_ptr_59943);
        _type_ptr_59943 = _1;
    }

    /** parser.e:3376		if type_ptr < 0 then*/
    if (_type_ptr_59943 >= 0LL)
    goto L1; // [5] 16

    /** parser.e:3378			return type_ptr*/
    return _type_ptr_59943;
L1: 

    /** parser.e:3381		if SymTab[type_ptr][S_TOKEN] = OBJECT then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29778 = (object)*(((s1_ptr)_2)->base + _type_ptr_59943);
    _2 = (object)SEQ_PTR(_29778);
    if (!IS_ATOM_INT(_36S_TOKEN_21081)){
        _29779 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    }
    else{
        _29779 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    }
    _29778 = NOVALUE;
    if (binary_op_a(NOTEQ, _29779, 415LL)){
        _29779 = NOVALUE;
        goto L2; // [32] 47
    }
    _29779 = NOVALUE;

    /** parser.e:3382			return TYPE_OBJECT*/
    return 16LL;
    goto L3; // [44] 218
L2: 

    /** parser.e:3384		elsif type_ptr = integer_type then*/
    if (_type_ptr_59943 != _54integer_type_46782)
    goto L4; // [51] 66

    /** parser.e:3385			return TYPE_INTEGER*/
    return 1LL;
    goto L3; // [63] 218
L4: 

    /** parser.e:3387		elsif type_ptr = atom_type then*/
    if (_type_ptr_59943 != _54atom_type_46778)
    goto L5; // [70] 85

    /** parser.e:3388			return TYPE_ATOM*/
    return 4LL;
    goto L3; // [82] 218
L5: 

    /** parser.e:3390		elsif type_ptr = sequence_type then*/
    if (_type_ptr_59943 != _54sequence_type_46780)
    goto L6; // [89] 104

    /** parser.e:3391			return TYPE_SEQUENCE*/
    return 8LL;
    goto L3; // [101] 218
L6: 

    /** parser.e:3393		elsif type_ptr = object_type then*/
    if (_type_ptr_59943 != _54object_type_46776)
    goto L7; // [108] 123

    /** parser.e:3394			return TYPE_OBJECT*/
    return 16LL;
    goto L3; // [120] 218
L7: 

    /** parser.e:3398			t = SymTab[SymTab[type_ptr][S_NEXT]][S_VTYPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29785 = (object)*(((s1_ptr)_2)->base + _type_ptr_59943);
    _2 = (object)SEQ_PTR(_29785);
    _29786 = (object)*(((s1_ptr)_2)->base + 2LL);
    _29785 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_29786)){
        _29787 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29786)->dbl));
    }
    else{
        _29787 = (object)*(((s1_ptr)_2)->base + _29786);
    }
    _2 = (object)SEQ_PTR(_29787);
    _t_59944 = (object)*(((s1_ptr)_2)->base + 15LL);
    if (!IS_ATOM_INT(_t_59944)){
        _t_59944 = (object)DBL_PTR(_t_59944)->dbl;
    }
    _29787 = NOVALUE;

    /** parser.e:3399			if t = integer_type then*/
    if (_t_59944 != _54integer_type_46782)
    goto L8; // [155] 170

    /** parser.e:3400				return TYPE_INTEGER*/
    _29786 = NOVALUE;
    return 1LL;
    goto L9; // [167] 217
L8: 

    /** parser.e:3401			elsif t = atom_type then*/
    if (_t_59944 != _54atom_type_46778)
    goto LA; // [174] 189

    /** parser.e:3402				return TYPE_ATOM*/
    _29786 = NOVALUE;
    return 4LL;
    goto L9; // [186] 217
LA: 

    /** parser.e:3403			elsif t = sequence_type then*/
    if (_t_59944 != _54sequence_type_46780)
    goto LB; // [193] 208

    /** parser.e:3404				return TYPE_SEQUENCE*/
    _29786 = NOVALUE;
    return 8LL;
    goto L9; // [205] 217
LB: 

    /** parser.e:3406				return TYPE_OBJECT*/
    _29786 = NOVALUE;
    return 16LL;
L9: 
L3: 
    ;
}


object _45get_assigned_sym()
{
    object _29800 = NOVALUE;
    object _29799 = NOVALUE;
    object _29798 = NOVALUE;
    object _29796 = NOVALUE;
    object _29795 = NOVALUE;
    object _29794 = NOVALUE;
    object _29793 = NOVALUE;
    object _29792 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:3416		if not find( Code[$-2], {ASSIGN, ASSIGN_I}) then*/
    if (IS_SEQUENCE(_36Code_21531)){
            _29792 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29792 = 1;
    }
    _29793 = _29792 - 2LL;
    _29792 = NOVALUE;
    _2 = (object)SEQ_PTR(_36Code_21531);
    _29794 = (object)*(((s1_ptr)_2)->base + _29793);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 18LL;
    ((intptr_t *)_2)[2] = 113LL;
    _29795 = MAKE_SEQ(_1);
    _29796 = find_from(_29794, _29795, 1LL);
    _29794 = NOVALUE;
    DeRefDS(_29795);
    _29795 = NOVALUE;
    if (_29796 != 0)
    goto L1; // [29] 39
    _29796 = NOVALUE;

    /** parser.e:3417			return 0*/
    _29793 = NOVALUE;
    return 0LL;
L1: 

    /** parser.e:3419		return Code[$-1]*/
    if (IS_SEQUENCE(_36Code_21531)){
            _29798 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _29798 = 1;
    }
    _29799 = _29798 - 1LL;
    _29798 = NOVALUE;
    _2 = (object)SEQ_PTR(_36Code_21531);
    _29800 = (object)*(((s1_ptr)_2)->base + _29799);
    Ref(_29800);
    DeRef(_29793);
    _29793 = NOVALUE;
    _29799 = NOVALUE;
    return _29800;
    ;
}


void _45Assign_Constant(object _sym_60013)
{
    object _valsym_60015 = NOVALUE;
    object _val_60018 = NOVALUE;
    object _29827 = NOVALUE;
    object _29826 = NOVALUE;
    object _29824 = NOVALUE;
    object _29823 = NOVALUE;
    object _29822 = NOVALUE;
    object _29820 = NOVALUE;
    object _29819 = NOVALUE;
    object _29818 = NOVALUE;
    object _29816 = NOVALUE;
    object _29815 = NOVALUE;
    object _29814 = NOVALUE;
    object _29812 = NOVALUE;
    object _29811 = NOVALUE;
    object _29810 = NOVALUE;
    object _29808 = NOVALUE;
    object _29806 = NOVALUE;
    object _29804 = NOVALUE;
    object _29802 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:3423		symtab_index valsym = Pop() -- pop the sym for the constant, too*/
    _valsym_60015 = _47Pop();
    if (!IS_ATOM_INT(_valsym_60015)) {
        _1 = (object)(DBL_PTR(_valsym_60015)->dbl);
        DeRefDS(_valsym_60015);
        _valsym_60015 = _1;
    }

    /** parser.e:3424		object val = SymTab[valsym][S_OBJ]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29802 = (object)*(((s1_ptr)_2)->base + _valsym_60015);
    DeRef(_val_60018);
    _2 = (object)SEQ_PTR(_29802);
    _val_60018 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_val_60018);
    _29802 = NOVALUE;

    /** parser.e:3426		SymTab[sym][S_OBJ] = val*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60013 + ((s1_ptr)_2)->base);
    Ref(_val_60018);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _val_60018;
    DeRef(_1);
    _29804 = NOVALUE;

    /** parser.e:3427		SymTab[sym][S_INITLEVEL] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60013 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _29806 = NOVALUE;

    /** parser.e:3429		if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L1; // [58] 197
    }
    else{
    }

    /** parser.e:3431			SymTab[sym][S_GTYPE] = SymTab[valsym][S_GTYPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60013 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29810 = (object)*(((s1_ptr)_2)->base + _valsym_60015);
    _2 = (object)SEQ_PTR(_29810);
    _29811 = (object)*(((s1_ptr)_2)->base + 36LL);
    _29810 = NOVALUE;
    Ref(_29811);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29811;
    if( _1 != _29811 ){
        DeRef(_1);
    }
    _29811 = NOVALUE;
    _29808 = NOVALUE;

    /** parser.e:3432			SymTab[sym][S_SEQ_ELEM] = SymTab[valsym][S_SEQ_ELEM]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60013 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29814 = (object)*(((s1_ptr)_2)->base + _valsym_60015);
    _2 = (object)SEQ_PTR(_29814);
    _29815 = (object)*(((s1_ptr)_2)->base + 33LL);
    _29814 = NOVALUE;
    Ref(_29815);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29815;
    if( _1 != _29815 ){
        DeRef(_1);
    }
    _29815 = NOVALUE;
    _29812 = NOVALUE;

    /** parser.e:3433			SymTab[sym][S_OBJ_MIN] = SymTab[valsym][S_OBJ_MIN]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60013 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29818 = (object)*(((s1_ptr)_2)->base + _valsym_60015);
    _2 = (object)SEQ_PTR(_29818);
    _29819 = (object)*(((s1_ptr)_2)->base + 30LL);
    _29818 = NOVALUE;
    Ref(_29819);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29819;
    if( _1 != _29819 ){
        DeRef(_1);
    }
    _29819 = NOVALUE;
    _29816 = NOVALUE;

    /** parser.e:3434			SymTab[sym][S_OBJ_MAX] = SymTab[valsym][S_OBJ_MAX]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60013 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29822 = (object)*(((s1_ptr)_2)->base + _valsym_60015);
    _2 = (object)SEQ_PTR(_29822);
    _29823 = (object)*(((s1_ptr)_2)->base + 31LL);
    _29822 = NOVALUE;
    Ref(_29823);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29823;
    if( _1 != _29823 ){
        DeRef(_1);
    }
    _29823 = NOVALUE;
    _29820 = NOVALUE;

    /** parser.e:3435			SymTab[sym][S_SEQ_LEN] = SymTab[valsym][S_SEQ_LEN]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60013 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29826 = (object)*(((s1_ptr)_2)->base + _valsym_60015);
    _2 = (object)SEQ_PTR(_29826);
    _29827 = (object)*(((s1_ptr)_2)->base + 32LL);
    _29826 = NOVALUE;
    Ref(_29827);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29827;
    if( _1 != _29827 ){
        DeRef(_1);
    }
    _29827 = NOVALUE;
    _29824 = NOVALUE;
L1: 

    /** parser.e:3437	end procedure*/
    DeRef(_val_60018);
    return;
    ;
}


object _45Global_declaration(object _type_ptr_60075, object _scope_60076)
{
    object _new_symbols_60077 = NOVALUE;
    object _tok_60079 = NOVALUE;
    object _tsym_60080 = NOVALUE;
    object _prevtok_60081 = NOVALUE;
    object _sym_60083 = NOVALUE;
    object _valsym_60084 = NOVALUE;
    object _h_60085 = NOVALUE;
    object _count_60086 = NOVALUE;
    object _val_60087 = NOVALUE;
    object _usedval_60088 = NOVALUE;
    object _deltafunc_60089 = NOVALUE;
    object _delta_60090 = NOVALUE;
    object _is_fwd_ref_60091 = NOVALUE;
    object _ptok_60108 = NOVALUE;
    object _negate_60124 = NOVALUE;
    object _negate_60373 = NOVALUE;
    object _31685 = NOVALUE;
    object _31684 = NOVALUE;
    object _31683 = NOVALUE;
    object _30067 = NOVALUE;
    object _30065 = NOVALUE;
    object _30063 = NOVALUE;
    object _30061 = NOVALUE;
    object _30059 = NOVALUE;
    object _30056 = NOVALUE;
    object _30054 = NOVALUE;
    object _30053 = NOVALUE;
    object _30052 = NOVALUE;
    object _30051 = NOVALUE;
    object _30050 = NOVALUE;
    object _30049 = NOVALUE;
    object _30047 = NOVALUE;
    object _30043 = NOVALUE;
    object _30041 = NOVALUE;
    object _30039 = NOVALUE;
    object _30037 = NOVALUE;
    object _30035 = NOVALUE;
    object _30033 = NOVALUE;
    object _30032 = NOVALUE;
    object _30030 = NOVALUE;
    object _30029 = NOVALUE;
    object _30028 = NOVALUE;
    object _30026 = NOVALUE;
    object _30024 = NOVALUE;
    object _30022 = NOVALUE;
    object _30021 = NOVALUE;
    object _30020 = NOVALUE;
    object _30018 = NOVALUE;
    object _30017 = NOVALUE;
    object _30016 = NOVALUE;
    object _30014 = NOVALUE;
    object _30012 = NOVALUE;
    object _30010 = NOVALUE;
    object _30009 = NOVALUE;
    object _30008 = NOVALUE;
    object _30007 = NOVALUE;
    object _30006 = NOVALUE;
    object _30003 = NOVALUE;
    object _30001 = NOVALUE;
    object _29999 = NOVALUE;
    object _29998 = NOVALUE;
    object _29997 = NOVALUE;
    object _29993 = NOVALUE;
    object _29992 = NOVALUE;
    object _29991 = NOVALUE;
    object _29987 = NOVALUE;
    object _29986 = NOVALUE;
    object _29985 = NOVALUE;
    object _29983 = NOVALUE;
    object _29982 = NOVALUE;
    object _29981 = NOVALUE;
    object _29980 = NOVALUE;
    object _29979 = NOVALUE;
    object _29978 = NOVALUE;
    object _29977 = NOVALUE;
    object _29976 = NOVALUE;
    object _29975 = NOVALUE;
    object _29972 = NOVALUE;
    object _29970 = NOVALUE;
    object _29969 = NOVALUE;
    object _29967 = NOVALUE;
    object _29966 = NOVALUE;
    object _29964 = NOVALUE;
    object _29963 = NOVALUE;
    object _29962 = NOVALUE;
    object _29961 = NOVALUE;
    object _29959 = NOVALUE;
    object _29957 = NOVALUE;
    object _29955 = NOVALUE;
    object _29952 = NOVALUE;
    object _29949 = NOVALUE;
    object _29946 = NOVALUE;
    object _29944 = NOVALUE;
    object _29943 = NOVALUE;
    object _29942 = NOVALUE;
    object _29941 = NOVALUE;
    object _29939 = NOVALUE;
    object _29938 = NOVALUE;
    object _29937 = NOVALUE;
    object _29936 = NOVALUE;
    object _29932 = NOVALUE;
    object _29931 = NOVALUE;
    object _29930 = NOVALUE;
    object _29929 = NOVALUE;
    object _29928 = NOVALUE;
    object _29927 = NOVALUE;
    object _29924 = NOVALUE;
    object _29922 = NOVALUE;
    object _29921 = NOVALUE;
    object _29920 = NOVALUE;
    object _29919 = NOVALUE;
    object _29918 = NOVALUE;
    object _29915 = NOVALUE;
    object _29913 = NOVALUE;
    object _29911 = NOVALUE;
    object _29910 = NOVALUE;
    object _29909 = NOVALUE;
    object _29908 = NOVALUE;
    object _29907 = NOVALUE;
    object _29906 = NOVALUE;
    object _29905 = NOVALUE;
    object _29903 = NOVALUE;
    object _29900 = NOVALUE;
    object _29898 = NOVALUE;
    object _29897 = NOVALUE;
    object _29896 = NOVALUE;
    object _29895 = NOVALUE;
    object _29894 = NOVALUE;
    object _29893 = NOVALUE;
    object _29892 = NOVALUE;
    object _29891 = NOVALUE;
    object _29888 = NOVALUE;
    object _29887 = NOVALUE;
    object _29886 = NOVALUE;
    object _29884 = NOVALUE;
    object _29883 = NOVALUE;
    object _29882 = NOVALUE;
    object _29881 = NOVALUE;
    object _29880 = NOVALUE;
    object _29878 = NOVALUE;
    object _29877 = NOVALUE;
    object _29876 = NOVALUE;
    object _29874 = NOVALUE;
    object _29873 = NOVALUE;
    object _29871 = NOVALUE;
    object _29868 = NOVALUE;
    object _29866 = NOVALUE;
    object _29864 = NOVALUE;
    object _29856 = NOVALUE;
    object _29855 = NOVALUE;
    object _29853 = NOVALUE;
    object _29850 = NOVALUE;
    object _29843 = NOVALUE;
    object _29840 = NOVALUE;
    object _29839 = NOVALUE;
    object _29837 = NOVALUE;
    object _29833 = NOVALUE;
    object _29832 = NOVALUE;
    object _29831 = NOVALUE;
    object _29830 = NOVALUE;
    object _29829 = NOVALUE;
    object _29828 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_type_ptr_60075)) {
        _1 = (object)(DBL_PTR(_type_ptr_60075)->dbl);
        DeRefDS(_type_ptr_60075);
        _type_ptr_60075 = _1;
    }

    /** parser.e:3447		object tsym*/

    /** parser.e:3448		object prevtok = 0*/
    DeRef(_prevtok_60081);
    _prevtok_60081 = 0LL;

    /** parser.e:3450		integer h, count = 0*/
    _count_60086 = 0LL;

    /** parser.e:3451		atom val = 1, usedval*/
    DeRef(_val_60087);
    _val_60087 = 1LL;

    /** parser.e:3452		integer deltafunc = '+'*/
    _deltafunc_60089 = 43LL;

    /** parser.e:3453		atom delta = 1*/
    DeRef(_delta_60090);
    _delta_60090 = 1LL;

    /** parser.e:3455		new_symbols = {}*/
    RefDS(_21993);
    DeRefi(_new_symbols_60077);
    _new_symbols_60077 = _21993;

    /** parser.e:3456		integer is_fwd_ref = 0*/
    _is_fwd_ref_60091 = 0LL;

    /** parser.e:3457		if type_ptr > 0 and SymTab[type_ptr][S_SCOPE] = SC_UNDEFINED then*/
    _29828 = (_type_ptr_60075 > 0LL);
    if (_29828 == 0) {
        goto L1; // [50] 105
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29830 = (object)*(((s1_ptr)_2)->base + _type_ptr_60075);
    _2 = (object)SEQ_PTR(_29830);
    _29831 = (object)*(((s1_ptr)_2)->base + 4LL);
    _29830 = NOVALUE;
    if (IS_ATOM_INT(_29831)) {
        _29832 = (_29831 == 9LL);
    }
    else {
        _29832 = binary_op(EQUALS, _29831, 9LL);
    }
    _29831 = NOVALUE;
    if (_29832 == 0) {
        DeRef(_29832);
        _29832 = NOVALUE;
        goto L1; // [73] 105
    }
    else {
        if (!IS_ATOM_INT(_29832) && DBL_PTR(_29832)->dbl == 0.0){
            DeRef(_29832);
            _29832 = NOVALUE;
            goto L1; // [73] 105
        }
        DeRef(_29832);
        _29832 = NOVALUE;
    }
    DeRef(_29832);
    _29832 = NOVALUE;

    /** parser.e:3458			is_fwd_ref = 1*/
    _is_fwd_ref_60091 = 1LL;

    /** parser.e:3459			Hide(type_ptr)*/
    _54Hide(_type_ptr_60075);

    /** parser.e:3460			type_ptr = -new_forward_reference( TYPE, type_ptr )*/
    DeRef(_31685);
    _31685 = 504LL;
    _29833 = _44new_forward_reference(504LL, _type_ptr_60075, 504LL);
    _31685 = NOVALUE;
    if (IS_ATOM_INT(_29833)) {
        if ((uintptr_t)_29833 == (uintptr_t)HIGH_BITS){
            _type_ptr_60075 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _type_ptr_60075 = - _29833;
        }
    }
    else {
        _type_ptr_60075 = unary_op(UMINUS, _29833);
    }
    DeRef(_29833);
    _29833 = NOVALUE;
    if (!IS_ATOM_INT(_type_ptr_60075)) {
        _1 = (object)(DBL_PTR(_type_ptr_60075)->dbl);
        DeRefDS(_type_ptr_60075);
        _type_ptr_60075 = _1;
    }
L1: 

    /** parser.e:3463		if type_ptr = -1 then*/
    if (_type_ptr_60075 != -1LL)
    goto L2; // [107] 426

    /** parser.e:3465			sequence ptok = next_token()*/
    _0 = _ptok_60108;
    _ptok_60108 = _45next_token();
    DeRef(_0);

    /** parser.e:3466			if ptok[T_ID] = TYPE_DECL then*/
    _2 = (object)SEQ_PTR(_ptok_60108);
    _29837 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29837, 416LL)){
        _29837 = NOVALUE;
        goto L3; // [128] 172
    }
    _29837 = NOVALUE;

    /** parser.e:3469				putback(keyfind("enum",-1))*/
    RefDS(_26182);
    DeRef(_31683);
    _31683 = _26182;
    _31684 = _54hashfn(_31683);
    _31683 = NOVALUE;
    RefDS(_26182);
    _29839 = _54keyfind(_26182, -1LL, _36current_file_no_21439, 0LL, _31684);
    _31684 = NOVALUE;
    _45putback(_29839);
    _29839 = NOVALUE;

    /** parser.e:3470				SubProg(TYPE_DECL, scope, 0)*/
    _45SubProg(416LL, _scope_60076, 0LL);

    /** parser.e:3471				return {}*/
    RefDS(_21993);
    DeRefDS(_ptok_60108);
    DeRefi(_new_symbols_60077);
    DeRef(_tok_60079);
    DeRef(_tsym_60080);
    DeRef(_prevtok_60081);
    DeRef(_val_60087);
    DeRef(_usedval_60088);
    DeRef(_delta_60090);
    DeRef(_29828);
    _29828 = NOVALUE;
    return _21993;
    goto L4; // [169] 425
L3: 

    /** parser.e:3472			elsif ptok[T_ID] = BY then*/
    _2 = (object)SEQ_PTR(_ptok_60108);
    _29840 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29840, 404LL)){
        _29840 = NOVALUE;
        goto L5; // [182] 419
    }
    _29840 = NOVALUE;

    /** parser.e:3474				integer negate = 0*/
    _negate_60124 = 0LL;

    /** parser.e:3475				ptok = next_token()*/
    _0 = _ptok_60108;
    _ptok_60108 = _45next_token();
    DeRefDS(_0);

    /** parser.e:3476				switch ptok[T_ID] do*/
    _2 = (object)SEQ_PTR(_ptok_60108);
    _29843 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_29843) ){
        goto L6; // [206] 285
    }
    if(!IS_ATOM_INT(_29843)){
        if( (DBL_PTR(_29843)->dbl != (eudouble) ((object) DBL_PTR(_29843)->dbl) ) ){
            goto L6; // [206] 285
        }
        _0 = (object) DBL_PTR(_29843)->dbl;
    }
    else {
        _0 = _29843;
    };
    _29843 = NOVALUE;
    switch ( _0 ){ 

        /** parser.e:3477					case reserved:MULTIPLY then*/
        case 13:

        /** parser.e:3478						deltafunc = '*'*/
        _deltafunc_60089 = 42LL;

        /** parser.e:3479						ptok = next_token()*/
        _0 = _ptok_60108;
        _ptok_60108 = _45next_token();
        DeRef(_0);
        goto L7; // [227] 293

        /** parser.e:3481					case reserved:DIVIDE then*/
        case 14:

        /** parser.e:3482						deltafunc = '/'*/
        _deltafunc_60089 = 47LL;

        /** parser.e:3483						ptok = next_token()*/
        _0 = _ptok_60108;
        _ptok_60108 = _45next_token();
        DeRef(_0);
        goto L7; // [245] 293

        /** parser.e:3485					case MINUS then*/
        case 10:

        /** parser.e:3486						deltafunc = '-'*/
        _deltafunc_60089 = 45LL;

        /** parser.e:3487						ptok = next_token()*/
        _0 = _ptok_60108;
        _ptok_60108 = _45next_token();
        DeRef(_0);
        goto L7; // [263] 293

        /** parser.e:3489					case PLUS then*/
        case 11:

        /** parser.e:3490						deltafunc = '+'*/
        _deltafunc_60089 = 43LL;

        /** parser.e:3491						ptok = next_token()*/
        _0 = _ptok_60108;
        _ptok_60108 = _45next_token();
        DeRef(_0);
        goto L7; // [281] 293

        /** parser.e:3493					case else*/
        default:
L6: 

        /** parser.e:3494						deltafunc = '+'*/
        _deltafunc_60089 = 43LL;
    ;}L7: 

    /** parser.e:3498				if ptok[T_ID] = MINUS then*/
    _2 = (object)SEQ_PTR(_ptok_60108);
    _29850 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29850, 10LL)){
        _29850 = NOVALUE;
        goto L8; // [303] 320
    }
    _29850 = NOVALUE;

    /** parser.e:3499					negate = 1*/
    _negate_60124 = 1LL;

    /** parser.e:3500					ptok = next_token()*/
    _0 = _ptok_60108;
    _ptok_60108 = _45next_token();
    DeRefDS(_0);
L8: 

    /** parser.e:3502				if ptok[T_ID] != ATOM then*/
    _2 = (object)SEQ_PTR(_ptok_60108);
    _29853 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _29853, 502LL)){
        _29853 = NOVALUE;
        goto L9; // [330] 344
    }
    _29853 = NOVALUE;

    /** parser.e:3503					CompileErr( A_NUMERIC_LITERAL_WAS_EXPECTED)*/
    RefDS(_21993);
    _50CompileErr(344LL, _21993, 0LL);
L9: 

    /** parser.e:3506				delta = SymTab[ptok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_ptok_60108);
    _29855 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_29855)){
        _29856 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29855)->dbl));
    }
    else{
        _29856 = (object)*(((s1_ptr)_2)->base + _29855);
    }
    DeRef(_delta_60090);
    _2 = (object)SEQ_PTR(_29856);
    _delta_60090 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_delta_60090);
    _29856 = NOVALUE;

    /** parser.e:3507				if negate then*/
    if (_negate_60124 == 0)
    {
        goto LA; // [366] 375
    }
    else{
    }

    /** parser.e:3508					delta = -delta*/
    _0 = _delta_60090;
    if (IS_ATOM_INT(_delta_60090)) {
        if ((uintptr_t)_delta_60090 == (uintptr_t)HIGH_BITS){
            _delta_60090 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _delta_60090 = - _delta_60090;
        }
    }
    else {
        _delta_60090 = unary_op(UMINUS, _delta_60090);
    }
    DeRef(_0);
LA: 

    /** parser.e:3511				switch deltafunc do*/
    _0 = _deltafunc_60089;
    switch ( _0 ){ 

        /** parser.e:3512					case '/' then*/
        case 47:

        /** parser.e:3513						delta = 1 / delta*/
        _0 = _delta_60090;
        if (IS_ATOM_INT(_delta_60090)) {
            _delta_60090 = (1LL % _delta_60090) ? NewDouble((eudouble)1LL / _delta_60090) : (1LL / _delta_60090);
        }
        else {
            _delta_60090 = NewDouble((eudouble)1LL / DBL_PTR(_delta_60090)->dbl);
        }
        DeRef(_0);

        /** parser.e:3514						deltafunc = '*'*/
        _deltafunc_60089 = 42LL;
        goto LB; // [397] 414

        /** parser.e:3516					case '-' then*/
        case 45:

        /** parser.e:3517						delta = -delta*/
        _0 = _delta_60090;
        if (IS_ATOM_INT(_delta_60090)) {
            if ((uintptr_t)_delta_60090 == (uintptr_t)HIGH_BITS){
                _delta_60090 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _delta_60090 = - _delta_60090;
            }
        }
        else {
            _delta_60090 = unary_op(UMINUS, _delta_60090);
        }
        DeRef(_0);

        /** parser.e:3518						deltafunc = '+'*/
        _deltafunc_60089 = 43LL;
    ;}LB: 
    goto L4; // [416] 425
L5: 

    /** parser.e:3523				putback(ptok)*/
    RefDS(_ptok_60108);
    _45putback(_ptok_60108);
L4: 
L2: 
    DeRef(_ptok_60108);
    _ptok_60108 = NOVALUE;

    /** parser.e:3527		valsym = 0*/
    _valsym_60084 = 0LL;

    /** parser.e:3528		while TRUE do*/
LC: 
    if (_13TRUE_452 == 0)
    {
        goto LD; // [442] 2303
    }
    else{
    }

    /** parser.e:3529			tok = next_token()*/
    _0 = _tok_60079;
    _tok_60079 = _45next_token();
    DeRef(_0);

    /** parser.e:3530			if tok[T_ID] = DOLLAR then*/
    _2 = (object)SEQ_PTR(_tok_60079);
    _29864 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29864, -22LL)){
        _29864 = NOVALUE;
        goto LE; // [460] 499
    }
    _29864 = NOVALUE;

    /** parser.e:3531				if not equal(prevtok, 0) then*/
    if (_prevtok_60081 == 0LL)
    _29866 = 1;
    else if (IS_ATOM_INT(_prevtok_60081) && IS_ATOM_INT(0LL))
    _29866 = 0;
    else
    _29866 = (compare(_prevtok_60081, 0LL) == 0);
    if (_29866 != 0)
    goto LF; // [470] 498
    _29866 = NOVALUE;

    /** parser.e:3532					if prevtok[T_ID] = COMMA then*/
    _2 = (object)SEQ_PTR(_prevtok_60081);
    _29868 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29868, -30LL)){
        _29868 = NOVALUE;
        goto L10; // [483] 497
    }
    _29868 = NOVALUE;

    /** parser.e:3534						tok = next_token()*/
    _0 = _tok_60079;
    _tok_60079 = _45next_token();
    DeRef(_0);

    /** parser.e:3535						exit*/
    goto LD; // [494] 2303
L10: 
LF: 
LE: 

    /** parser.e:3539			if tok[T_ID] = END_OF_FILE then*/
    _2 = (object)SEQ_PTR(_tok_60079);
    _29871 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29871, -21LL)){
        _29871 = NOVALUE;
        goto L11; // [509] 523
    }
    _29871 = NOVALUE;

    /** parser.e:3540				CompileErr( AN_IDENTIFIER_IS_EXPECTED_HERE)*/
    RefDS(_21993);
    _50CompileErr(32LL, _21993, 0LL);
L11: 

    /** parser.e:3543			if not find(tok[T_ID], ADDR_TOKS) then*/
    _2 = (object)SEQ_PTR(_tok_60079);
    _29873 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29874 = find_from(_29873, _38ADDR_TOKS_16049, 1LL);
    _29873 = NOVALUE;
    if (_29874 != 0)
    goto L12; // [538] 565
    _29874 = NOVALUE;

    /** parser.e:3544				CompileErr(FOUND__1__BUT_WAS_EXPECTING_AN_IDENTIFIER_NAME, {find_category(tok[T_ID])} )*/
    _2 = (object)SEQ_PTR(_tok_60079);
    _29876 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_29876);
    _29877 = _63find_category(_29876);
    _29876 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _29877;
    _29878 = MAKE_SEQ(_1);
    _29877 = NOVALUE;
    _50CompileErr(25LL, _29878, 0LL);
    _29878 = NOVALUE;
L12: 

    /** parser.e:3546			sym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_60079);
    _sym_60083 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_sym_60083)){
        _sym_60083 = (object)DBL_PTR(_sym_60083)->dbl;
    }

    /** parser.e:3547			DefinedYet(sym)*/
    _54DefinedYet(_sym_60083);

    /** parser.e:3548			if find(SymTab[sym][S_SCOPE], {SC_GLOBAL, SC_PREDEF, SC_PUBLIC, SC_EXPORT}) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29880 = (object)*(((s1_ptr)_2)->base + _sym_60083);
    _2 = (object)SEQ_PTR(_29880);
    _29881 = (object)*(((s1_ptr)_2)->base + 4LL);
    _29880 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 6LL;
    ((intptr_t*)_2)[2] = 7LL;
    ((intptr_t*)_2)[3] = 13LL;
    ((intptr_t*)_2)[4] = 11LL;
    _29882 = MAKE_SEQ(_1);
    _29883 = find_from(_29881, _29882, 1LL);
    _29881 = NOVALUE;
    DeRefDS(_29882);
    _29882 = NOVALUE;
    if (_29883 == 0)
    {
        _29883 = NOVALUE;
        goto L13; // [614] 676
    }
    else{
        _29883 = NOVALUE;
    }

    /** parser.e:3549				h = SymTab[sym][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29884 = (object)*(((s1_ptr)_2)->base + _sym_60083);
    _2 = (object)SEQ_PTR(_29884);
    _h_60085 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (!IS_ATOM_INT(_h_60085)){
        _h_60085 = (object)DBL_PTR(_h_60085)->dbl;
    }
    _29884 = NOVALUE;

    /** parser.e:3551				sym = NewEntry(SymTab[sym][S_NAME], 0, 0, VARIABLE, h, buckets[h], 0)*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29886 = (object)*(((s1_ptr)_2)->base + _sym_60083);
    _2 = (object)SEQ_PTR(_29886);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _29887 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _29887 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _29886 = NOVALUE;
    _2 = (object)SEQ_PTR(_54buckets_46772);
    _29888 = (object)*(((s1_ptr)_2)->base + _h_60085);
    Ref(_29887);
    Ref(_29888);
    _sym_60083 = _54NewEntry(_29887, 0LL, 0LL, -100LL, _h_60085, _29888, 0LL);
    _29887 = NOVALUE;
    _29888 = NOVALUE;
    if (!IS_ATOM_INT(_sym_60083)) {
        _1 = (object)(DBL_PTR(_sym_60083)->dbl);
        DeRefDS(_sym_60083);
        _sym_60083 = _1;
    }

    /** parser.e:3552				buckets[h] = sym*/
    _2 = (object)SEQ_PTR(_54buckets_46772);
    _2 = (object)(((s1_ptr)_2)->base + _h_60085);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_60083;
    DeRef(_1);
L13: 

    /** parser.e:3555			new_symbols = append(new_symbols, sym)*/
    Append(&_new_symbols_60077, _new_symbols_60077, _sym_60083);

    /** parser.e:3556			Block_var( sym )*/
    _65Block_var(_sym_60083);

    /** parser.e:3557			if SymTab[sym][S_SCOPE] = SC_UNDEFINED and SymTab[sym][S_FILE_NO] != current_file_no then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29891 = (object)*(((s1_ptr)_2)->base + _sym_60083);
    _2 = (object)SEQ_PTR(_29891);
    _29892 = (object)*(((s1_ptr)_2)->base + 4LL);
    _29891 = NOVALUE;
    if (IS_ATOM_INT(_29892)) {
        _29893 = (_29892 == 9LL);
    }
    else {
        _29893 = binary_op(EQUALS, _29892, 9LL);
    }
    _29892 = NOVALUE;
    if (IS_ATOM_INT(_29893)) {
        if (_29893 == 0) {
            goto L14; // [707] 751
        }
    }
    else {
        if (DBL_PTR(_29893)->dbl == 0.0) {
            goto L14; // [707] 751
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29895 = (object)*(((s1_ptr)_2)->base + _sym_60083);
    _2 = (object)SEQ_PTR(_29895);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _29896 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _29896 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    _29895 = NOVALUE;
    if (IS_ATOM_INT(_29896)) {
        _29897 = (_29896 != _36current_file_no_21439);
    }
    else {
        _29897 = binary_op(NOTEQ, _29896, _36current_file_no_21439);
    }
    _29896 = NOVALUE;
    if (_29897 == 0) {
        DeRef(_29897);
        _29897 = NOVALUE;
        goto L14; // [730] 751
    }
    else {
        if (!IS_ATOM_INT(_29897) && DBL_PTR(_29897)->dbl == 0.0){
            DeRef(_29897);
            _29897 = NOVALUE;
            goto L14; // [730] 751
        }
        DeRef(_29897);
        _29897 = NOVALUE;
    }
    DeRef(_29897);
    _29897 = NOVALUE;

    /** parser.e:3558				SymTab[sym][S_FILE_NO] = current_file_no*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60083 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_FILE_NO_21072))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36current_file_no_21439;
    DeRef(_1);
    _29898 = NOVALUE;
L14: 

    /** parser.e:3560			SymTab[sym][S_SCOPE] = scope*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60083 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _scope_60076;
    DeRef(_1);
    _29900 = NOVALUE;

    /** parser.e:3562			if type_ptr = 0 then*/
    if (_type_ptr_60075 != 0LL)
    goto L15; // [768] 1103

    /** parser.e:3564				SymTab[sym][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60083 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _29903 = NOVALUE;

    /** parser.e:3566				buckets[SymTab[sym][S_HASHVAL]] = SymTab[sym][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29905 = (object)*(((s1_ptr)_2)->base + _sym_60083);
    _2 = (object)SEQ_PTR(_29905);
    _29906 = (object)*(((s1_ptr)_2)->base + 11LL);
    _29905 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29907 = (object)*(((s1_ptr)_2)->base + _sym_60083);
    _2 = (object)SEQ_PTR(_29907);
    _29908 = (object)*(((s1_ptr)_2)->base + 9LL);
    _29907 = NOVALUE;
    Ref(_29908);
    _2 = (object)SEQ_PTR(_54buckets_46772);
    if (!IS_ATOM_INT(_29906))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_29906)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _29906);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29908;
    if( _1 != _29908 ){
        DeRef(_1);
    }
    _29908 = NOVALUE;

    /** parser.e:3567				tok_match(EQUALS)*/
    _45tok_match(3LL, 0LL);

    /** parser.e:3568				StartSourceLine(FALSE, , COVERAGE_OVERRIDE)*/
    _47StartSourceLine(_13FALSE_450, 0LL, 3LL);

    /** parser.e:3569				emit_opnd(sym)*/
    _47emit_opnd(_sym_60083);

    /** parser.e:3570				Expr()  -- no new symbols can be defined in here*/
    _45Expr();

    /** parser.e:3571				buckets[SymTab[sym][S_HASHVAL]] = sym*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29909 = (object)*(((s1_ptr)_2)->base + _sym_60083);
    _2 = (object)SEQ_PTR(_29909);
    _29910 = (object)*(((s1_ptr)_2)->base + 11LL);
    _29909 = NOVALUE;
    _2 = (object)SEQ_PTR(_54buckets_46772);
    if (!IS_ATOM_INT(_29910))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_29910)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _29910);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_60083;
    DeRef(_1);

    /** parser.e:3572				SymTab[sym][S_USAGE] = U_WRITTEN*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60083 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _29911 = NOVALUE;

    /** parser.e:3573				if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L16; // [890] 928
    }
    else{
    }

    /** parser.e:3574					SymTab[sym][S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60083 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);
    _29913 = NOVALUE;

    /** parser.e:3575					SymTab[sym][S_OBJ] = NOVALUE     -- distinguish from literals*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60083 + ((s1_ptr)_2)->base);
    Ref(_36NOVALUE_21293);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21293;
    DeRef(_1);
    _29915 = NOVALUE;
L16: 

    /** parser.e:3577				valsym = Top()*/
    _valsym_60084 = _47Top();
    if (!IS_ATOM_INT(_valsym_60084)) {
        _1 = (object)(DBL_PTR(_valsym_60084)->dbl);
        DeRefDS(_valsym_60084);
        _valsym_60084 = _1;
    }

    /** parser.e:3579				if valsym > 0 and compare( SymTab[valsym][S_OBJ], NOVALUE ) then*/
    _29918 = (_valsym_60084 > 0LL);
    if (_29918 == 0) {
        goto L17; // [941] 982
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29920 = (object)*(((s1_ptr)_2)->base + _valsym_60084);
    _2 = (object)SEQ_PTR(_29920);
    _29921 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29920 = NOVALUE;
    if (IS_ATOM_INT(_29921) && IS_ATOM_INT(_36NOVALUE_21293)){
        _29922 = (_29921 < _36NOVALUE_21293) ? -1 : (_29921 > _36NOVALUE_21293);
    }
    else{
        _29922 = compare(_29921, _36NOVALUE_21293);
    }
    _29921 = NOVALUE;
    if (_29922 == 0)
    {
        _29922 = NOVALUE;
        goto L17; // [964] 982
    }
    else{
        _29922 = NOVALUE;
    }

    /** parser.e:3580					Assign_Constant( sym )*/
    _45Assign_Constant(_sym_60083);

    /** parser.e:3581					sym = Pop()*/
    _sym_60083 = _47Pop();
    if (!IS_ATOM_INT(_sym_60083)) {
        _1 = (object)(DBL_PTR(_sym_60083)->dbl);
        DeRefDS(_sym_60083);
        _sym_60083 = _1;
    }
    goto L18; // [979] 2269
L17: 

    /** parser.e:3584					emit_op(ASSIGN)*/
    _47emit_op(18LL);

    /** parser.e:3585					if Last_op() = ASSIGN then*/
    _29924 = _47Last_op();
    if (binary_op_a(NOTEQ, _29924, 18LL)){
        DeRef(_29924);
        _29924 = NOVALUE;
        goto L19; // [996] 1010
    }
    DeRef(_29924);
    _29924 = NOVALUE;

    /** parser.e:3586						valsym = get_assigned_sym()*/
    _valsym_60084 = _45get_assigned_sym();
    if (!IS_ATOM_INT(_valsym_60084)) {
        _1 = (object)(DBL_PTR(_valsym_60084)->dbl);
        DeRefDS(_valsym_60084);
        _valsym_60084 = _1;
    }
    goto L1A; // [1007] 1018
L19: 

    /** parser.e:3589						valsym = -1*/
    _valsym_60084 = -1LL;
L1A: 

    /** parser.e:3591					if valsym > 0 and compare( SymTab[valsym][S_OBJ], NOVALUE ) then*/
    _29927 = (_valsym_60084 > 0LL);
    if (_29927 == 0) {
        goto L1B; // [1024] 1066
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29929 = (object)*(((s1_ptr)_2)->base + _valsym_60084);
    _2 = (object)SEQ_PTR(_29929);
    _29930 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29929 = NOVALUE;
    if (IS_ATOM_INT(_29930) && IS_ATOM_INT(_36NOVALUE_21293)){
        _29931 = (_29930 < _36NOVALUE_21293) ? -1 : (_29930 > _36NOVALUE_21293);
    }
    else{
        _29931 = compare(_29930, _36NOVALUE_21293);
    }
    _29930 = NOVALUE;
    if (_29931 == 0)
    {
        _29931 = NOVALUE;
        goto L1B; // [1047] 1066
    }
    else{
        _29931 = NOVALUE;
    }

    /** parser.e:3593						SymTab[sym][S_CODE] = valsym*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60083 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21088))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21088);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _valsym_60084;
    DeRef(_1);
    _29932 = NOVALUE;
L1B: 

    /** parser.e:3596					if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L18; // [1070] 2269
    }
    else{
    }

    /** parser.e:3597						count += 1*/
    _count_60086 = _count_60086 + 1;

    /** parser.e:3598						if count = 10 then*/
    if (_count_60086 != 10LL)
    goto L18; // [1081] 2269

    /** parser.e:3599							count = 0*/
    _count_60086 = 0LL;

    /** parser.e:3601							emit_op( RETURNT )*/
    _47emit_op(34LL);
    goto L18; // [1100] 2269
L15: 

    /** parser.e:3606			elsif type_ptr = -1 and not is_fwd_ref then*/
    _29936 = (_type_ptr_60075 == -1LL);
    if (_29936 == 0) {
        goto L1C; // [1109] 2096
    }
    _29938 = (_is_fwd_ref_60091 == 0);
    if (_29938 == 0)
    {
        DeRef(_29938);
        _29938 = NOVALUE;
        goto L1C; // [1117] 2096
    }
    else{
        DeRef(_29938);
        _29938 = NOVALUE;
    }

    /** parser.e:3608				StartSourceLine(FALSE, , COVERAGE_OVERRIDE )*/
    _47StartSourceLine(_13FALSE_450, 0LL, 3LL);

    /** parser.e:3609				SymTab[sym][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60083 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _29939 = NOVALUE;

    /** parser.e:3611				buckets[SymTab[sym][S_HASHVAL]] = SymTab[sym][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29941 = (object)*(((s1_ptr)_2)->base + _sym_60083);
    _2 = (object)SEQ_PTR(_29941);
    _29942 = (object)*(((s1_ptr)_2)->base + 11LL);
    _29941 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29943 = (object)*(((s1_ptr)_2)->base + _sym_60083);
    _2 = (object)SEQ_PTR(_29943);
    _29944 = (object)*(((s1_ptr)_2)->base + 9LL);
    _29943 = NOVALUE;
    Ref(_29944);
    _2 = (object)SEQ_PTR(_54buckets_46772);
    if (!IS_ATOM_INT(_29942))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_29942)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _29942);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29944;
    if( _1 != _29944 ){
        DeRef(_1);
    }
    _29944 = NOVALUE;

    /** parser.e:3612				tok = next_token()*/
    _0 = _tok_60079;
    _tok_60079 = _45next_token();
    DeRef(_0);

    /** parser.e:3615				emit_opnd(sym)*/
    _47emit_opnd(_sym_60083);

    /** parser.e:3617				if tok[T_ID] = EQUALS then*/
    _2 = (object)SEQ_PTR(_tok_60079);
    _29946 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29946, 3LL)){
        _29946 = NOVALUE;
        goto L1D; // [1200] 1607
    }
    _29946 = NOVALUE;

    /** parser.e:3618					integer negate = 1*/
    _negate_60373 = 1LL;

    /** parser.e:3620					tok = next_token()*/
    _0 = _tok_60079;
    _tok_60079 = _45next_token();
    DeRef(_0);

    /** parser.e:3621					if tok[T_ID] = MINUS then*/
    _2 = (object)SEQ_PTR(_tok_60079);
    _29949 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29949, 10LL)){
        _29949 = NOVALUE;
        goto L1E; // [1224] 1239
    }
    _29949 = NOVALUE;

    /** parser.e:3622						negate = -1*/
    _negate_60373 = -1LL;

    /** parser.e:3623						tok = next_token()*/
    _0 = _tok_60079;
    _tok_60079 = _45next_token();
    DeRef(_0);
L1E: 

    /** parser.e:3626					if tok[T_ID] = ATOM then*/
    _2 = (object)SEQ_PTR(_tok_60079);
    _29952 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29952, 502LL)){
        _29952 = NOVALUE;
        goto L1F; // [1249] 1266
    }
    _29952 = NOVALUE;

    /** parser.e:3627						valsym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_60079);
    _valsym_60084 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_valsym_60084)){
        _valsym_60084 = (object)DBL_PTR(_valsym_60084)->dbl;
    }
    goto L20; // [1263] 1464
L1F: 

    /** parser.e:3628					elsif tok[T_SYM] > 0 then*/
    _2 = (object)SEQ_PTR(_tok_60079);
    _29955 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (binary_op_a(LESSEQ, _29955, 0LL)){
        _29955 = NOVALUE;
        goto L21; // [1274] 1454
    }
    _29955 = NOVALUE;

    /** parser.e:3629						tsym = SymTab[tok[T_SYM]]*/
    _2 = (object)SEQ_PTR(_tok_60079);
    _29957 = (object)*(((s1_ptr)_2)->base + 2LL);
    DeRef(_tsym_60080);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_29957)){
        _tsym_60080 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29957)->dbl));
    }
    else{
        _tsym_60080 = (object)*(((s1_ptr)_2)->base + _29957);
    }
    Ref(_tsym_60080);

    /** parser.e:3630						if tsym[S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_tsym_60080);
    _29959 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (binary_op_a(NOTEQ, _29959, 2LL)){
        _29959 = NOVALUE;
        goto L22; // [1302] 1415
    }
    _29959 = NOVALUE;

    /** parser.e:3631							if length(tsym) >= S_CODE and tsym[S_CODE] then*/
    if (IS_SEQUENCE(_tsym_60080)){
            _29961 = SEQ_PTR(_tsym_60080)->length;
    }
    else {
        _29961 = 1;
    }
    if (IS_ATOM_INT(_36S_CODE_21088)) {
        _29962 = (_29961 >= _36S_CODE_21088);
    }
    else {
        _29962 = binary_op(GREATEREQ, _29961, _36S_CODE_21088);
    }
    _29961 = NOVALUE;
    if (IS_ATOM_INT(_29962)) {
        if (_29962 == 0) {
            goto L23; // [1317] 1344
        }
    }
    else {
        if (DBL_PTR(_29962)->dbl == 0.0) {
            goto L23; // [1317] 1344
        }
    }
    _2 = (object)SEQ_PTR(_tsym_60080);
    if (!IS_ATOM_INT(_36S_CODE_21088)){
        _29964 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
    }
    else{
        _29964 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21088);
    }
    if (_29964 == 0) {
        _29964 = NOVALUE;
        goto L23; // [1328] 1344
    }
    else {
        if (!IS_ATOM_INT(_29964) && DBL_PTR(_29964)->dbl == 0.0){
            _29964 = NOVALUE;
            goto L23; // [1328] 1344
        }
        _29964 = NOVALUE;
    }
    _29964 = NOVALUE;

    /** parser.e:3632								valsym = tsym[S_CODE]*/
    _2 = (object)SEQ_PTR(_tsym_60080);
    if (!IS_ATOM_INT(_36S_CODE_21088)){
        _valsym_60084 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
    }
    else{
        _valsym_60084 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21088);
    }
    if (!IS_ATOM_INT(_valsym_60084)){
        _valsym_60084 = (object)DBL_PTR(_valsym_60084)->dbl;
    }
    goto L20; // [1341] 1464
L23: 

    /** parser.e:3634							elsif not equal( tsym[S_OBJ], NOVALUE ) then*/
    _2 = (object)SEQ_PTR(_tsym_60080);
    _29966 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (_29966 == _36NOVALUE_21293)
    _29967 = 1;
    else if (IS_ATOM_INT(_29966) && IS_ATOM_INT(_36NOVALUE_21293))
    _29967 = 0;
    else
    _29967 = (compare(_29966, _36NOVALUE_21293) == 0);
    _29966 = NOVALUE;
    if (_29967 != 0)
    goto L24; // [1358] 1402
    _29967 = NOVALUE;

    /** parser.e:3635								if is_integer(tsym[S_OBJ]) then*/
    _2 = (object)SEQ_PTR(_tsym_60080);
    _29969 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_29969);
    _29970 = _36is_integer(_29969);
    _29969 = NOVALUE;
    if (_29970 == 0) {
        DeRef(_29970);
        _29970 = NOVALUE;
        goto L25; // [1373] 1389
    }
    else {
        if (!IS_ATOM_INT(_29970) && DBL_PTR(_29970)->dbl == 0.0){
            DeRef(_29970);
            _29970 = NOVALUE;
            goto L25; // [1373] 1389
        }
        DeRef(_29970);
        _29970 = NOVALUE;
    }
    DeRef(_29970);
    _29970 = NOVALUE;

    /** parser.e:3636									valsym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_60079);
    _valsym_60084 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_valsym_60084)){
        _valsym_60084 = (object)DBL_PTR(_valsym_60084)->dbl;
    }
    goto L20; // [1386] 1464
L25: 

    /** parser.e:3638									CompileErr(AN_ENUM_CONSTANT_MUST_BE_AN_INTEGER)*/
    RefDS(_21993);
    _50CompileErr(30LL, _21993, 0LL);
    goto L20; // [1399] 1464
L24: 

    /** parser.e:3641								CompileErr(ENUM_CONSTANTS_MUST_BE_ASSIGNED_AN_INTEGER)*/
    RefDS(_21993);
    _50CompileErr(70LL, _21993, 0LL);
    goto L20; // [1412] 1464
L22: 

    /** parser.e:3643						elsif tsym[S_OBJ] = NOVALUE then*/
    _2 = (object)SEQ_PTR(_tsym_60080);
    _29972 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _29972, _36NOVALUE_21293)){
        _29972 = NOVALUE;
        goto L26; // [1425] 1441
    }
    _29972 = NOVALUE;

    /** parser.e:3645							CompileErr(ENUM_FWD_REFERENCES_NOT_SUPPORTED)*/
    RefDS(_21993);
    _50CompileErr(331LL, _21993, 0LL);
    goto L20; // [1438] 1464
L26: 

    /** parser.e:3647							CompileErr(INTEGER_OR_CONSTANT_EXPECTED)*/
    RefDS(_21993);
    _50CompileErr(99LL, _21993, 0LL);
    goto L20; // [1451] 1464
L21: 

    /** parser.e:3651							CompileErr(INTEGER_OR_CONSTANT_EXPECTED)*/
    RefDS(_21993);
    _50CompileErr(99LL, _21993, 0LL);
L20: 

    /** parser.e:3653					valsym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_60079);
    _valsym_60084 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_valsym_60084)){
        _valsym_60084 = (object)DBL_PTR(_valsym_60084)->dbl;
    }

    /** parser.e:3654					if not atom( SymTab[valsym][S_OBJ] ) and tsym[S_SCOPE] != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29975 = (object)*(((s1_ptr)_2)->base + _valsym_60084);
    _2 = (object)SEQ_PTR(_29975);
    _29976 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29975 = NOVALUE;
    _29977 = IS_ATOM(_29976);
    _29976 = NOVALUE;
    _29978 = (_29977 == 0);
    _29977 = NOVALUE;
    if (_29978 == 0) {
        goto L27; // [1494] 1526
    }
    _2 = (object)SEQ_PTR(_tsym_60080);
    _29980 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_29980)) {
        _29981 = (_29980 != 9LL);
    }
    else {
        _29981 = binary_op(NOTEQ, _29980, 9LL);
    }
    _29980 = NOVALUE;
    if (_29981 == 0) {
        DeRef(_29981);
        _29981 = NOVALUE;
        goto L27; // [1513] 1526
    }
    else {
        if (!IS_ATOM_INT(_29981) && DBL_PTR(_29981)->dbl == 0.0){
            DeRef(_29981);
            _29981 = NOVALUE;
            goto L27; // [1513] 1526
        }
        DeRef(_29981);
        _29981 = NOVALUE;
    }
    DeRef(_29981);
    _29981 = NOVALUE;

    /** parser.e:3655						CompileErr(ENUM_CONSTANTS_MUST_BE_INTEGERS)*/
    RefDS(_21993);
    _50CompileErr(84LL, _21993, 0LL);
L27: 

    /** parser.e:3657					val = SymTab[valsym][S_OBJ] * negate*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29982 = (object)*(((s1_ptr)_2)->base + _valsym_60084);
    _2 = (object)SEQ_PTR(_29982);
    _29983 = (object)*(((s1_ptr)_2)->base + 1LL);
    _29982 = NOVALUE;
    DeRef(_val_60087);
    if (IS_ATOM_INT(_29983)) {
        {
            int128_t p128 = (int128_t)_29983 * (int128_t)_negate_60373;
            if( p128 != (int128_t)(_val_60087 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _val_60087 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _val_60087 = binary_op(MULTIPLY, _29983, _negate_60373);
    }
    _29983 = NOVALUE;

    /** parser.e:3658					if is_integer(val) then*/
    Ref(_val_60087);
    _29985 = _36is_integer(_val_60087);
    if (_29985 == 0) {
        DeRef(_29985);
        _29985 = NOVALUE;
        goto L28; // [1550] 1565
    }
    else {
        if (!IS_ATOM_INT(_29985) && DBL_PTR(_29985)->dbl == 0.0){
            DeRef(_29985);
            _29985 = NOVALUE;
            goto L28; // [1550] 1565
        }
        DeRef(_29985);
        _29985 = NOVALUE;
    }
    DeRef(_29985);
    _29985 = NOVALUE;

    /** parser.e:3659						Push(NewIntSym(val))*/
    Ref(_val_60087);
    _29986 = _54NewIntSym(_val_60087);
    _47Push(_29986);
    _29986 = NOVALUE;
    goto L29; // [1562] 1575
L28: 

    /** parser.e:3661						Push(NewDoubleSym(val))*/
    Ref(_val_60087);
    _29987 = _54NewDoubleSym(_val_60087);
    _47Push(_29987);
    _29987 = NOVALUE;
L29: 

    /** parser.e:3663					usedval = val*/
    Ref(_val_60087);
    DeRef(_usedval_60088);
    _usedval_60088 = _val_60087;

    /** parser.e:3664					if deltafunc = '+' then*/
    if (_deltafunc_60089 != 43LL)
    goto L2A; // [1582] 1595

    /** parser.e:3665						val += delta*/
    _0 = _val_60087;
    if (IS_ATOM_INT(_val_60087) && IS_ATOM_INT(_delta_60090)) {
        _val_60087 = _val_60087 + _delta_60090;
        if ((object)((uintptr_t)_val_60087 + (uintptr_t)HIGH_BITS) >= 0){
            _val_60087 = NewDouble((eudouble)_val_60087);
        }
    }
    else {
        if (IS_ATOM_INT(_val_60087)) {
            _val_60087 = NewDouble((eudouble)_val_60087 + DBL_PTR(_delta_60090)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_60090)) {
                _val_60087 = NewDouble(DBL_PTR(_val_60087)->dbl + (eudouble)_delta_60090);
            }
            else
            _val_60087 = NewDouble(DBL_PTR(_val_60087)->dbl + DBL_PTR(_delta_60090)->dbl);
        }
    }
    DeRef(_0);
    goto L2B; // [1592] 1602
L2A: 

    /** parser.e:3667						val *= delta*/
    _0 = _val_60087;
    if (IS_ATOM_INT(_val_60087) && IS_ATOM_INT(_delta_60090)) {
        {
            int128_t p128 = (int128_t)_val_60087 * (int128_t)_delta_60090;
            if( p128 != (int128_t)(_val_60087 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _val_60087 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        if (IS_ATOM_INT(_val_60087)) {
            _val_60087 = NewDouble((eudouble)_val_60087 * DBL_PTR(_delta_60090)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_60090)) {
                _val_60087 = NewDouble(DBL_PTR(_val_60087)->dbl * (eudouble)_delta_60090);
            }
            else
            _val_60087 = NewDouble(DBL_PTR(_val_60087)->dbl * DBL_PTR(_delta_60090)->dbl);
        }
    }
    DeRef(_0);
L2B: 
    goto L2C; // [1604] 1678
L1D: 

    /** parser.e:3670					putback(tok)*/
    Ref(_tok_60079);
    _45putback(_tok_60079);

    /** parser.e:3671					if is_integer(val) then*/
    Ref(_val_60087);
    _29991 = _36is_integer(_val_60087);
    if (_29991 == 0) {
        DeRef(_29991);
        _29991 = NOVALUE;
        goto L2D; // [1618] 1633
    }
    else {
        if (!IS_ATOM_INT(_29991) && DBL_PTR(_29991)->dbl == 0.0){
            DeRef(_29991);
            _29991 = NOVALUE;
            goto L2D; // [1618] 1633
        }
        DeRef(_29991);
        _29991 = NOVALUE;
    }
    DeRef(_29991);
    _29991 = NOVALUE;

    /** parser.e:3672						Push(NewIntSym(val))*/
    Ref(_val_60087);
    _29992 = _54NewIntSym(_val_60087);
    _47Push(_29992);
    _29992 = NOVALUE;
    goto L2E; // [1630] 1643
L2D: 

    /** parser.e:3674						Push(NewDoubleSym(val))*/
    Ref(_val_60087);
    _29993 = _54NewDoubleSym(_val_60087);
    _47Push(_29993);
    _29993 = NOVALUE;
L2E: 

    /** parser.e:3676					usedval = val*/
    Ref(_val_60087);
    DeRef(_usedval_60088);
    _usedval_60088 = _val_60087;

    /** parser.e:3677					if deltafunc = '+' then*/
    if (_deltafunc_60089 != 43LL)
    goto L2F; // [1650] 1663

    /** parser.e:3678						val += delta*/
    _0 = _val_60087;
    if (IS_ATOM_INT(_val_60087) && IS_ATOM_INT(_delta_60090)) {
        _val_60087 = _val_60087 + _delta_60090;
        if ((object)((uintptr_t)_val_60087 + (uintptr_t)HIGH_BITS) >= 0){
            _val_60087 = NewDouble((eudouble)_val_60087);
        }
    }
    else {
        if (IS_ATOM_INT(_val_60087)) {
            _val_60087 = NewDouble((eudouble)_val_60087 + DBL_PTR(_delta_60090)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_60090)) {
                _val_60087 = NewDouble(DBL_PTR(_val_60087)->dbl + (eudouble)_delta_60090);
            }
            else
            _val_60087 = NewDouble(DBL_PTR(_val_60087)->dbl + DBL_PTR(_delta_60090)->dbl);
        }
    }
    DeRef(_0);
    goto L30; // [1660] 1670
L2F: 

    /** parser.e:3680						val *= delta*/
    _0 = _val_60087;
    if (IS_ATOM_INT(_val_60087) && IS_ATOM_INT(_delta_60090)) {
        {
            int128_t p128 = (int128_t)_val_60087 * (int128_t)_delta_60090;
            if( p128 != (int128_t)(_val_60087 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _val_60087 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        if (IS_ATOM_INT(_val_60087)) {
            _val_60087 = NewDouble((eudouble)_val_60087 * DBL_PTR(_delta_60090)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_60090)) {
                _val_60087 = NewDouble(DBL_PTR(_val_60087)->dbl * (eudouble)_delta_60090);
            }
            else
            _val_60087 = NewDouble(DBL_PTR(_val_60087)->dbl * DBL_PTR(_delta_60090)->dbl);
        }
    }
    DeRef(_0);
L30: 

    /** parser.e:3682					valsym = 0*/
    _valsym_60084 = 0LL;
L2C: 

    /** parser.e:3684				buckets[SymTab[sym][S_HASHVAL]] = sym*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _29997 = (object)*(((s1_ptr)_2)->base + _sym_60083);
    _2 = (object)SEQ_PTR(_29997);
    _29998 = (object)*(((s1_ptr)_2)->base + 11LL);
    _29997 = NOVALUE;
    _2 = (object)SEQ_PTR(_54buckets_46772);
    if (!IS_ATOM_INT(_29998))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_29998)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _29998);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_60083;
    DeRef(_1);

    /** parser.e:3685				SymTab[sym][S_USAGE] = U_WRITTEN*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60083 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _29999 = NOVALUE;

    /** parser.e:3687				if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L31; // [1719] 1757
    }
    else{
    }

    /** parser.e:3688					SymTab[sym][S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60083 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);
    _30001 = NOVALUE;

    /** parser.e:3689					SymTab[sym][S_OBJ] = NOVALUE     -- distinguish from literals*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60083 + ((s1_ptr)_2)->base);
    Ref(_36NOVALUE_21293);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21293;
    DeRef(_1);
    _30003 = NOVALUE;
L31: 

    /** parser.e:3692				if valsym < 0 then*/
    if (_valsym_60084 >= 0LL)
    goto L32; // [1759] 1764
L32: 

    /** parser.e:3697				if valsym and compare( SymTab[valsym][S_OBJ], NOVALUE ) then*/
    if (_valsym_60084 == 0) {
        goto L33; // [1766] 1946
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30007 = (object)*(((s1_ptr)_2)->base + _valsym_60084);
    _2 = (object)SEQ_PTR(_30007);
    _30008 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30007 = NOVALUE;
    if (IS_ATOM_INT(_30008) && IS_ATOM_INT(_36NOVALUE_21293)){
        _30009 = (_30008 < _36NOVALUE_21293) ? -1 : (_30008 > _36NOVALUE_21293);
    }
    else{
        _30009 = compare(_30008, _36NOVALUE_21293);
    }
    _30008 = NOVALUE;
    if (_30009 == 0)
    {
        _30009 = NOVALUE;
        goto L33; // [1789] 1946
    }
    else{
        _30009 = NOVALUE;
    }

    /** parser.e:3699					SymTab[sym][S_CODE] = valsym*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60083 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21088))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21088);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _valsym_60084;
    DeRef(_1);
    _30010 = NOVALUE;

    /** parser.e:3700					SymTab[sym][S_OBJ]  = usedval*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60083 + ((s1_ptr)_2)->base);
    Ref(_usedval_60088);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60088;
    DeRef(_1);
    _30012 = NOVALUE;

    /** parser.e:3702					if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L34; // [1828] 2079
    }
    else{
    }

    /** parser.e:3704						SymTab[sym][S_GTYPE] = SymTab[valsym][S_GTYPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60083 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30016 = (object)*(((s1_ptr)_2)->base + _valsym_60084);
    _2 = (object)SEQ_PTR(_30016);
    _30017 = (object)*(((s1_ptr)_2)->base + 36LL);
    _30016 = NOVALUE;
    Ref(_30017);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30017;
    if( _1 != _30017 ){
        DeRef(_1);
    }
    _30017 = NOVALUE;
    _30014 = NOVALUE;

    /** parser.e:3705						SymTab[sym][S_SEQ_ELEM] = SymTab[valsym][S_SEQ_ELEM]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60083 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30020 = (object)*(((s1_ptr)_2)->base + _valsym_60084);
    _2 = (object)SEQ_PTR(_30020);
    _30021 = (object)*(((s1_ptr)_2)->base + 33LL);
    _30020 = NOVALUE;
    Ref(_30021);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30021;
    if( _1 != _30021 ){
        DeRef(_1);
    }
    _30021 = NOVALUE;
    _30018 = NOVALUE;

    /** parser.e:3706						SymTab[sym][S_OBJ_MIN] = usedval*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60083 + ((s1_ptr)_2)->base);
    Ref(_usedval_60088);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60088;
    DeRef(_1);
    _30022 = NOVALUE;

    /** parser.e:3707						SymTab[sym][S_OBJ_MAX] = usedval*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60083 + ((s1_ptr)_2)->base);
    Ref(_usedval_60088);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60088;
    DeRef(_1);
    _30024 = NOVALUE;

    /** parser.e:3708						SymTab[sym][S_SEQ_LEN] = SymTab[valsym][S_SEQ_LEN]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60083 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30028 = (object)*(((s1_ptr)_2)->base + _valsym_60084);
    _2 = (object)SEQ_PTR(_30028);
    _30029 = (object)*(((s1_ptr)_2)->base + 32LL);
    _30028 = NOVALUE;
    Ref(_30029);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30029;
    if( _1 != _30029 ){
        DeRef(_1);
    }
    _30029 = NOVALUE;
    _30026 = NOVALUE;
    goto L34; // [1943] 2079
L33: 

    /** parser.e:3711					SymTab[sym][S_OBJ] = usedval*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60083 + ((s1_ptr)_2)->base);
    Ref(_usedval_60088);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60088;
    DeRef(_1);
    _30030 = NOVALUE;

    /** parser.e:3712					if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L35; // [1967] 2078
    }
    else{
    }

    /** parser.e:3714						if is_integer( usedval ) then*/
    Ref(_usedval_60088);
    _30032 = _36is_integer(_usedval_60088);
    if (_30032 == 0) {
        DeRef(_30032);
        _30032 = NOVALUE;
        goto L36; // [1976] 1999
    }
    else {
        if (!IS_ATOM_INT(_30032) && DBL_PTR(_30032)->dbl == 0.0){
            DeRef(_30032);
            _30032 = NOVALUE;
            goto L36; // [1976] 1999
        }
        DeRef(_30032);
        _30032 = NOVALUE;
    }
    DeRef(_30032);
    _30032 = NOVALUE;

    /** parser.e:3715							SymTab[sym][S_GTYPE] = TYPE_INTEGER*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60083 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _30033 = NOVALUE;
    goto L37; // [1996] 2017
L36: 

    /** parser.e:3717							SymTab[sym][S_GTYPE] = TYPE_DOUBLE*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60083 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _30035 = NOVALUE;
L37: 

    /** parser.e:3719						SymTab[sym][S_SEQ_ELEM] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60083 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30037 = NOVALUE;

    /** parser.e:3720						SymTab[sym][S_OBJ_MIN] = usedval*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60083 + ((s1_ptr)_2)->base);
    Ref(_usedval_60088);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60088;
    DeRef(_1);
    _30039 = NOVALUE;

    /** parser.e:3721						SymTab[sym][S_OBJ_MAX] = usedval*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60083 + ((s1_ptr)_2)->base);
    Ref(_usedval_60088);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60088;
    DeRef(_1);
    _30041 = NOVALUE;

    /** parser.e:3722						SymTab[sym][S_SEQ_LEN] = 0 --SymTab[valsym][S_SEQ_LEN]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60083 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30043 = NOVALUE;
L35: 
L34: 

    /** parser.e:3725				valsym = Pop()*/
    _valsym_60084 = _47Pop();
    if (!IS_ATOM_INT(_valsym_60084)) {
        _1 = (object)(DBL_PTR(_valsym_60084)->dbl);
        DeRefDS(_valsym_60084);
        _valsym_60084 = _1;
    }

    /** parser.e:3726				valsym = Pop()*/
    _valsym_60084 = _47Pop();
    if (!IS_ATOM_INT(_valsym_60084)) {
        _1 = (object)(DBL_PTR(_valsym_60084)->dbl);
        DeRefDS(_valsym_60084);
        _valsym_60084 = _1;
    }
    goto L18; // [2093] 2269
L1C: 

    /** parser.e:3729				SymTab[sym][S_MODE] = M_NORMAL*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60083 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _30047 = NOVALUE;

    /** parser.e:3730				if type_ptr > 0 and SymTab[type_ptr][S_TOKEN] = OBJECT then*/
    _30049 = (_type_ptr_60075 > 0LL);
    if (_30049 == 0) {
        goto L38; // [2119] 2165
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30051 = (object)*(((s1_ptr)_2)->base + _type_ptr_60075);
    _2 = (object)SEQ_PTR(_30051);
    if (!IS_ATOM_INT(_36S_TOKEN_21081)){
        _30052 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    }
    else{
        _30052 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    }
    _30051 = NOVALUE;
    if (IS_ATOM_INT(_30052)) {
        _30053 = (_30052 == 415LL);
    }
    else {
        _30053 = binary_op(EQUALS, _30052, 415LL);
    }
    _30052 = NOVALUE;
    if (_30053 == 0) {
        DeRef(_30053);
        _30053 = NOVALUE;
        goto L38; // [2142] 2165
    }
    else {
        if (!IS_ATOM_INT(_30053) && DBL_PTR(_30053)->dbl == 0.0){
            DeRef(_30053);
            _30053 = NOVALUE;
            goto L38; // [2142] 2165
        }
        DeRef(_30053);
        _30053 = NOVALUE;
    }
    DeRef(_30053);
    _30053 = NOVALUE;

    /** parser.e:3731					SymTab[sym][S_VTYPE] = object_type*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60083 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _54object_type_46776;
    DeRef(_1);
    _30054 = NOVALUE;
    goto L39; // [2162] 2194
L38: 

    /** parser.e:3733					SymTab[sym][S_VTYPE] = type_ptr*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60083 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _type_ptr_60075;
    DeRef(_1);
    _30056 = NOVALUE;

    /** parser.e:3734					if type_ptr < 0 then*/
    if (_type_ptr_60075 >= 0LL)
    goto L3A; // [2182] 2193

    /** parser.e:3735						register_forward_type( sym, type_ptr )*/
    _44register_forward_type(_sym_60083, _type_ptr_60075);
L3A: 
L39: 

    /** parser.e:3739				if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L3B; // [2198] 2221
    }
    else{
    }

    /** parser.e:3740					SymTab[sym][S_GTYPE] = CompileType(type_ptr)*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60083 + ((s1_ptr)_2)->base);
    _30061 = _45CompileType(_type_ptr_60075);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30061;
    if( _1 != _30061 ){
        DeRef(_1);
    }
    _30061 = NOVALUE;
    _30059 = NOVALUE;
L3B: 

    /** parser.e:3743		   		tok = next_token()*/
    _0 = _tok_60079;
    _tok_60079 = _45next_token();
    DeRef(_0);

    /** parser.e:3744	   			putback(tok)*/
    Ref(_tok_60079);
    _45putback(_tok_60079);

    /** parser.e:3745		   		if tok[T_ID] = EQUALS then -- assign on declare*/
    _2 = (object)SEQ_PTR(_tok_60079);
    _30063 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30063, 3LL)){
        _30063 = NOVALUE;
        goto L3C; // [2241] 2268
    }
    _30063 = NOVALUE;

    /** parser.e:3746		   			StartSourceLine( FALSE, , COVERAGE_OVERRIDE )*/
    _47StartSourceLine(_13FALSE_450, 0LL, 3LL);

    /** parser.e:3747		   			Assignment({VARIABLE,sym})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100LL;
    ((intptr_t *)_2)[2] = _sym_60083;
    _30065 = MAKE_SEQ(_1);
    _45Assignment(_30065);
    _30065 = NOVALUE;
L3C: 
L18: 

    /** parser.e:3750			tok = next_token()*/
    _0 = _tok_60079;
    _tok_60079 = _45next_token();
    DeRef(_0);

    /** parser.e:3751			if tok[T_ID] != COMMA then*/
    _2 = (object)SEQ_PTR(_tok_60079);
    _30067 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _30067, -30LL)){
        _30067 = NOVALUE;
        goto L3D; // [2284] 2293
    }
    _30067 = NOVALUE;

    /** parser.e:3752				exit*/
    goto LD; // [2290] 2303
L3D: 

    /** parser.e:3754			prevtok = tok*/
    Ref(_tok_60079);
    DeRef(_prevtok_60081);
    _prevtok_60081 = _tok_60079;

    /** parser.e:3755		end while*/
    goto LC; // [2300] 440
LD: 

    /** parser.e:3756		putback(tok)*/
    Ref(_tok_60079);
    _45putback(_tok_60079);

    /** parser.e:3757		return new_symbols*/
    DeRef(_tok_60079);
    DeRef(_tsym_60080);
    DeRef(_prevtok_60081);
    DeRef(_val_60087);
    DeRef(_usedval_60088);
    DeRef(_delta_60090);
    _29855 = NOVALUE;
    DeRef(_29978);
    _29978 = NOVALUE;
    DeRef(_30049);
    _30049 = NOVALUE;
    _29957 = NOVALUE;
    _29942 = NOVALUE;
    _29998 = NOVALUE;
    _29910 = NOVALUE;
    DeRef(_29962);
    _29962 = NOVALUE;
    _29906 = NOVALUE;
    DeRef(_29936);
    _29936 = NOVALUE;
    DeRef(_29893);
    _29893 = NOVALUE;
    DeRef(_29828);
    _29828 = NOVALUE;
    DeRef(_29927);
    _29927 = NOVALUE;
    DeRef(_29918);
    _29918 = NOVALUE;
    return _new_symbols_60077;
    ;
}


void _45Private_declaration(object _type_sym_60664)
{
    object _tok_60666 = NOVALUE;
    object _sym_60668 = NOVALUE;
    object _31682 = NOVALUE;
    object _31681 = NOVALUE;
    object _31680 = NOVALUE;
    object _30093 = NOVALUE;
    object _30091 = NOVALUE;
    object _30089 = NOVALUE;
    object _30087 = NOVALUE;
    object _30085 = NOVALUE;
    object _30083 = NOVALUE;
    object _30081 = NOVALUE;
    object _30078 = NOVALUE;
    object _30076 = NOVALUE;
    object _30075 = NOVALUE;
    object _30072 = NOVALUE;
    object _30070 = NOVALUE;
    object _30069 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_type_sym_60664)) {
        _1 = (object)(DBL_PTR(_type_sym_60664)->dbl);
        DeRefDS(_type_sym_60664);
        _type_sym_60664 = _1;
    }

    /** parser.e:3765		if SymTab[type_sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30069 = (object)*(((s1_ptr)_2)->base + _type_sym_60664);
    _2 = (object)SEQ_PTR(_30069);
    _30070 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30069 = NOVALUE;
    if (binary_op_a(NOTEQ, _30070, 9LL)){
        _30070 = NOVALUE;
        goto L1; // [19] 47
    }
    _30070 = NOVALUE;

    /** parser.e:3766			Hide( type_sym )*/
    _54Hide(_type_sym_60664);

    /** parser.e:3767			type_sym = -new_forward_reference( TYPE, type_sym )*/
    _31682 = 504LL;
    _30072 = _44new_forward_reference(504LL, _type_sym_60664, 504LL);
    _31682 = NOVALUE;
    if (IS_ATOM_INT(_30072)) {
        if ((uintptr_t)_30072 == (uintptr_t)HIGH_BITS){
            _type_sym_60664 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _type_sym_60664 = - _30072;
        }
    }
    else {
        _type_sym_60664 = unary_op(UMINUS, _30072);
    }
    DeRef(_30072);
    _30072 = NOVALUE;
    if (!IS_ATOM_INT(_type_sym_60664)) {
        _1 = (object)(DBL_PTR(_type_sym_60664)->dbl);
        DeRefDS(_type_sym_60664);
        _type_sym_60664 = _1;
    }
L1: 

    /** parser.e:3770		while TRUE do*/
L2: 
    if (_13TRUE_452 == 0)
    {
        goto L3; // [54] 257
    }
    else{
    }

    /** parser.e:3771			tok = next_token()*/
    _0 = _tok_60666;
    _tok_60666 = _45next_token();
    DeRef(_0);

    /** parser.e:3772			if not find(tok[T_ID], ID_TOKS) then*/
    _2 = (object)SEQ_PTR(_tok_60666);
    _30075 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30076 = find_from(_30075, _38ID_TOKS_16051, 1LL);
    _30075 = NOVALUE;
    if (_30076 != 0)
    goto L4; // [77] 90
    _30076 = NOVALUE;

    /** parser.e:3773				CompileErr(A_VARIABLE_NAME_IS_EXPECTED_HERE)*/
    RefDS(_21993);
    _50CompileErr(24LL, _21993, 0LL);
L4: 

    /** parser.e:3775			sym = SetPrivateScope(tok[T_SYM], type_sym, param_num)*/
    _2 = (object)SEQ_PTR(_tok_60666);
    _30078 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30078);
    _sym_60668 = _45SetPrivateScope(_30078, _type_sym_60664, _45param_num_54933);
    _30078 = NOVALUE;
    if (!IS_ATOM_INT(_sym_60668)) {
        _1 = (object)(DBL_PTR(_sym_60668)->dbl);
        DeRefDS(_sym_60668);
        _sym_60668 = _1;
    }

    /** parser.e:3776			param_num += 1*/
    _45param_num_54933 = _45param_num_54933 + 1;

    /** parser.e:3778			if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L5; // [120] 143
    }
    else{
    }

    /** parser.e:3779				SymTab[sym][S_GTYPE] = CompileType(type_sym)*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60668 + ((s1_ptr)_2)->base);
    _30083 = _45CompileType(_type_sym_60664);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30083;
    if( _1 != _30083 ){
        DeRef(_1);
    }
    _30083 = NOVALUE;
    _30081 = NOVALUE;
L5: 

    /** parser.e:3782	   		tok = next_token()*/
    _0 = _tok_60666;
    _tok_60666 = _45next_token();
    DeRef(_0);

    /** parser.e:3783	   		if tok[T_ID] = EQUALS then -- assign on declare*/
    _2 = (object)SEQ_PTR(_tok_60666);
    _30085 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30085, 3LL)){
        _30085 = NOVALUE;
        goto L6; // [158] 233
    }
    _30085 = NOVALUE;

    /** parser.e:3784			    putback(tok)*/
    Ref(_tok_60666);
    _45putback(_tok_60666);

    /** parser.e:3785			    StartSourceLine( TRUE )*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:3797			    Assignment({VARIABLE,sym})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100LL;
    ((intptr_t *)_2)[2] = _sym_60668;
    _30087 = MAKE_SEQ(_1);
    _45Assignment(_30087);
    _30087 = NOVALUE;

    /** parser.e:3800				tok = next_token()*/
    _0 = _tok_60666;
    _tok_60666 = _45next_token();
    DeRef(_0);

    /** parser.e:3801				if tok[T_ID]=IGNORED then*/
    _2 = (object)SEQ_PTR(_tok_60666);
    _30089 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30089, 509LL)){
        _30089 = NOVALUE;
        goto L7; // [202] 232
    }
    _30089 = NOVALUE;

    /** parser.e:3802					tok = keyfind(tok[T_SYM],-1)*/
    _2 = (object)SEQ_PTR(_tok_60666);
    _30091 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30091);
    DeRef(_31680);
    _31680 = _30091;
    _31681 = _54hashfn(_31680);
    _31680 = NOVALUE;
    Ref(_30091);
    _0 = _tok_60666;
    _tok_60666 = _54keyfind(_30091, -1LL, _36current_file_no_21439, 0LL, _31681);
    DeRef(_0);
    _30091 = NOVALUE;
    _31681 = NOVALUE;
L7: 
L6: 

    /** parser.e:3806			if tok[T_ID] != COMMA then*/
    _2 = (object)SEQ_PTR(_tok_60666);
    _30093 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _30093, -30LL)){
        _30093 = NOVALUE;
        goto L2; // [243] 52
    }
    _30093 = NOVALUE;

    /** parser.e:3807				exit*/
    goto L3; // [249] 257

    /** parser.e:3809		end while*/
    goto L2; // [254] 52
L3: 

    /** parser.e:3810		putback(tok)*/
    Ref(_tok_60666);
    _45putback(_tok_60666);

    /** parser.e:3811	end procedure*/
    DeRef(_tok_60666);
    return;
    ;
}


void _45Procedure_call(object _tok_60731)
{
    object _n_60732 = NOVALUE;
    object _scope_60733 = NOVALUE;
    object _opcode_60734 = NOVALUE;
    object _temp_tok_60736 = NOVALUE;
    object _s_60738 = NOVALUE;
    object _sub_60739 = NOVALUE;
    object _30129 = NOVALUE;
    object _30124 = NOVALUE;
    object _30123 = NOVALUE;
    object _30122 = NOVALUE;
    object _30121 = NOVALUE;
    object _30120 = NOVALUE;
    object _30119 = NOVALUE;
    object _30118 = NOVALUE;
    object _30117 = NOVALUE;
    object _30116 = NOVALUE;
    object _30115 = NOVALUE;
    object _30114 = NOVALUE;
    object _30112 = NOVALUE;
    object _30111 = NOVALUE;
    object _30110 = NOVALUE;
    object _30109 = NOVALUE;
    object _30108 = NOVALUE;
    object _30107 = NOVALUE;
    object _30106 = NOVALUE;
    object _30104 = NOVALUE;
    object _30103 = NOVALUE;
    object _30102 = NOVALUE;
    object _30100 = NOVALUE;
    object _30098 = NOVALUE;
    object _30096 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:3820		tok_match(LEFT_ROUND)*/
    _45tok_match(-26LL, 0LL);

    /** parser.e:3821		s = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_60731);
    _s_60738 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_60738)){
        _s_60738 = (object)DBL_PTR(_s_60738)->dbl;
    }

    /** parser.e:3822		sub=s*/
    _sub_60739 = _s_60738;

    /** parser.e:3823		n = SymTab[s][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30096 = (object)*(((s1_ptr)_2)->base + _s_60738);
    _2 = (object)SEQ_PTR(_30096);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
        _n_60732 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
    }
    else{
        _n_60732 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
    }
    if (!IS_ATOM_INT(_n_60732)){
        _n_60732 = (object)DBL_PTR(_n_60732)->dbl;
    }
    _30096 = NOVALUE;

    /** parser.e:3824		scope = SymTab[s][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30098 = (object)*(((s1_ptr)_2)->base + _s_60738);
    _2 = (object)SEQ_PTR(_30098);
    _scope_60733 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_scope_60733)){
        _scope_60733 = (object)DBL_PTR(_scope_60733)->dbl;
    }
    _30098 = NOVALUE;

    /** parser.e:3825		opcode = SymTab[s][S_OPCODE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30100 = (object)*(((s1_ptr)_2)->base + _s_60738);
    _2 = (object)SEQ_PTR(_30100);
    _opcode_60734 = (object)*(((s1_ptr)_2)->base + 21LL);
    if (!IS_ATOM_INT(_opcode_60734)){
        _opcode_60734 = (object)DBL_PTR(_opcode_60734)->dbl;
    }
    _30100 = NOVALUE;

    /** parser.e:3826		if SymTab[s][S_EFFECT] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30102 = (object)*(((s1_ptr)_2)->base + _s_60738);
    _2 = (object)SEQ_PTR(_30102);
    _30103 = (object)*(((s1_ptr)_2)->base + 23LL);
    _30102 = NOVALUE;
    if (_30103 == 0) {
        _30103 = NOVALUE;
        goto L1; // [88] 139
    }
    else {
        if (!IS_ATOM_INT(_30103) && DBL_PTR(_30103)->dbl == 0.0){
            _30103 = NOVALUE;
            goto L1; // [88] 139
        }
        _30103 = NOVALUE;
    }
    _30103 = NOVALUE;

    /** parser.e:3827			SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT],*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21447 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30106 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21447);
    _2 = (object)SEQ_PTR(_30106);
    _30107 = (object)*(((s1_ptr)_2)->base + 23LL);
    _30106 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30108 = (object)*(((s1_ptr)_2)->base + _s_60738);
    _2 = (object)SEQ_PTR(_30108);
    _30109 = (object)*(((s1_ptr)_2)->base + 23LL);
    _30108 = NOVALUE;
    if (IS_ATOM_INT(_30107) && IS_ATOM_INT(_30109)) {
        {uintptr_t tu;
             tu = (uintptr_t)_30107 | (uintptr_t)_30109;
             _30110 = MAKE_UINT(tu);
        }
    }
    else {
        _30110 = binary_op(OR_BITS, _30107, _30109);
    }
    _30107 = NOVALUE;
    _30109 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30110;
    if( _1 != _30110 ){
        DeRef(_1);
    }
    _30110 = NOVALUE;
    _30104 = NOVALUE;
L1: 

    /** parser.e:3830		ParseArgs(s)*/
    _45ParseArgs(_s_60738);

    /** parser.e:3833		for i=1 to n+1 do*/
    _30111 = _n_60732 + 1;
    if (_30111 > MAXINT){
        _30111 = NewDouble((eudouble)_30111);
    }
    {
        object _i_60776;
        _i_60776 = 1LL;
L2: 
        if (binary_op_a(GREATER, _i_60776, _30111)){
            goto L3; // [150] 180
        }

        /** parser.e:3834			s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _30112 = (object)*(((s1_ptr)_2)->base + _s_60738);
        _2 = (object)SEQ_PTR(_30112);
        _s_60738 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_s_60738)){
            _s_60738 = (object)DBL_PTR(_s_60738)->dbl;
        }
        _30112 = NOVALUE;

        /** parser.e:3835		end for*/
        _0 = _i_60776;
        if (IS_ATOM_INT(_i_60776)) {
            _i_60776 = _i_60776 + 1LL;
            if ((object)((uintptr_t)_i_60776 +(uintptr_t) HIGH_BITS) >= 0){
                _i_60776 = NewDouble((eudouble)_i_60776);
            }
        }
        else {
            _i_60776 = binary_op_a(PLUS, _i_60776, 1LL);
        }
        DeRef(_0);
        goto L2; // [175] 157
L3: 
        ;
        DeRef(_i_60776);
    }

    /** parser.e:3836		while s and SymTab[s][S_SCOPE]=SC_PRIVATE do*/
L4: 
    if (_s_60738 == 0) {
        goto L5; // [185] 281
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30115 = (object)*(((s1_ptr)_2)->base + _s_60738);
    _2 = (object)SEQ_PTR(_30115);
    _30116 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30115 = NOVALUE;
    if (IS_ATOM_INT(_30116)) {
        _30117 = (_30116 == 3LL);
    }
    else {
        _30117 = binary_op(EQUALS, _30116, 3LL);
    }
    _30116 = NOVALUE;
    if (_30117 <= 0) {
        if (_30117 == 0) {
            DeRef(_30117);
            _30117 = NOVALUE;
            goto L5; // [208] 281
        }
        else {
            if (!IS_ATOM_INT(_30117) && DBL_PTR(_30117)->dbl == 0.0){
                DeRef(_30117);
                _30117 = NOVALUE;
                goto L5; // [208] 281
            }
            DeRef(_30117);
            _30117 = NOVALUE;
        }
    }
    DeRef(_30117);
    _30117 = NOVALUE;

    /** parser.e:3837			if sequence(SymTab[s][S_CODE]) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30118 = (object)*(((s1_ptr)_2)->base + _s_60738);
    _2 = (object)SEQ_PTR(_30118);
    if (!IS_ATOM_INT(_36S_CODE_21088)){
        _30119 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
    }
    else{
        _30119 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21088);
    }
    _30118 = NOVALUE;
    _30120 = IS_SEQUENCE(_30119);
    _30119 = NOVALUE;
    if (_30120 == 0)
    {
        _30120 = NOVALUE;
        goto L6; // [228] 260
    }
    else{
        _30120 = NOVALUE;
    }

    /** parser.e:3838				start_playback(SymTab[s][S_CODE])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30121 = (object)*(((s1_ptr)_2)->base + _s_60738);
    _2 = (object)SEQ_PTR(_30121);
    if (!IS_ATOM_INT(_36S_CODE_21088)){
        _30122 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
    }
    else{
        _30122 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21088);
    }
    _30121 = NOVALUE;
    Ref(_30122);
    _45start_playback(_30122);
    _30122 = NOVALUE;

    /** parser.e:3839				Assignment({VARIABLE,s})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100LL;
    ((intptr_t *)_2)[2] = _s_60738;
    _30123 = MAKE_SEQ(_1);
    _45Assignment(_30123);
    _30123 = NOVALUE;
L6: 

    /** parser.e:3841			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30124 = (object)*(((s1_ptr)_2)->base + _s_60738);
    _2 = (object)SEQ_PTR(_30124);
    _s_60738 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_60738)){
        _s_60738 = (object)DBL_PTR(_s_60738)->dbl;
    }
    _30124 = NOVALUE;

    /** parser.e:3842		end while*/
    goto L4; // [278] 185
L5: 

    /** parser.e:3844		s = sub*/
    _s_60738 = _sub_60739;

    /** parser.e:3845		if scope = SC_PREDEF then*/
    if (_scope_60733 != 7LL)
    goto L7; // [292] 335

    /** parser.e:3846			emit_op(opcode)*/
    _47emit_op(_opcode_60734);

    /** parser.e:3847			if opcode = ABORT then*/
    if (_opcode_60734 != 126LL)
    goto L8; // [305] 370

    /** parser.e:3848				temp_tok = next_token()*/
    _0 = _temp_tok_60736;
    _temp_tok_60736 = _45next_token();
    DeRef(_0);

    /** parser.e:3849				putback(temp_tok)*/
    Ref(_temp_tok_60736);
    _45putback(_temp_tok_60736);

    /** parser.e:3850				NotReached(temp_tok[T_ID], "abort()")*/
    _2 = (object)SEQ_PTR(_temp_tok_60736);
    _30129 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_30129);
    RefDS(_27865);
    _45NotReached(_30129, _27865);
    _30129 = NOVALUE;
    goto L8; // [332] 370
L7: 

    /** parser.e:3853			op_info1 = s*/
    _47op_info1_50932 = _s_60738;

    /** parser.e:3855			emit_or_inline()*/
    _67emit_or_inline();

    /** parser.e:3856			if not TRANSLATE then*/
    if (_36TRANSLATE_21041 != 0)
    goto L9; // [350] 369

    /** parser.e:3857				if OpTrace then*/
    if (_36OpTrace_21512 == 0)
    {
        goto LA; // [357] 368
    }
    else{
    }

    /** parser.e:3858					emit_op(UPDATE_GLOBALS)*/
    _47emit_op(89LL);
LA: 
L9: 
L8: 

    /** parser.e:3862	end procedure*/
    DeRef(_tok_60731);
    DeRef(_temp_tok_60736);
    DeRef(_30111);
    _30111 = NOVALUE;
    return;
    ;
}


void _45Print_statement()
{
    object _30136 = NOVALUE;
    object _30135 = NOVALUE;
    object _30134 = NOVALUE;
    object _30132 = NOVALUE;
    object _30131 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:3866		emit_opnd(NewIntSym(1)) -- stdout*/
    _30131 = _54NewIntSym(1LL);
    _47emit_opnd(_30131);
    _30131 = NOVALUE;

    /** parser.e:3867		Expr()*/
    _45Expr();

    /** parser.e:3868		emit_op(QPRINT)*/
    _47emit_op(36LL);

    /** parser.e:3869		SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT],*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21447 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30134 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21447);
    _2 = (object)SEQ_PTR(_30134);
    _30135 = (object)*(((s1_ptr)_2)->base + 23LL);
    _30134 = NOVALUE;
    if (IS_ATOM_INT(_30135)) {
        {uintptr_t tu;
             tu = (uintptr_t)_30135 | (uintptr_t)536870912LL;
             _30136 = MAKE_UINT(tu);
        }
    }
    else {
        _30136 = binary_op(OR_BITS, _30135, 536870912LL);
    }
    _30135 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30136;
    if( _1 != _30136 ){
        DeRef(_1);
    }
    _30136 = NOVALUE;
    _30132 = NOVALUE;

    /** parser.e:3871	end procedure*/
    return;
    ;
}


void _45Entry_statement()
{
    object _addr_60847 = NOVALUE;
    object _30160 = NOVALUE;
    object _30159 = NOVALUE;
    object _30158 = NOVALUE;
    object _30157 = NOVALUE;
    object _30156 = NOVALUE;
    object _30155 = NOVALUE;
    object _30154 = NOVALUE;
    object _30153 = NOVALUE;
    object _30149 = NOVALUE;
    object _30147 = NOVALUE;
    object _30146 = NOVALUE;
    object _30145 = NOVALUE;
    object _30144 = NOVALUE;
    object _30142 = NOVALUE;
    object _30141 = NOVALUE;
    object _30140 = NOVALUE;
    object _30138 = NOVALUE;
    object _30137 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:3878		if not length(loop_stack) or block_index=0 then*/
    if (IS_SEQUENCE(_45loop_stack_54958)){
            _30137 = SEQ_PTR(_45loop_stack_54958)->length;
    }
    else {
        _30137 = 1;
    }
    _30138 = (_30137 == 0);
    _30137 = NOVALUE;
    if (_30138 != 0) {
        goto L1; // [11] 26
    }
    _30140 = (_45block_index_54955 == 0LL);
    if (_30140 == 0)
    {
        DeRef(_30140);
        _30140 = NOVALUE;
        goto L2; // [22] 36
    }
    else{
        DeRef(_30140);
        _30140 = NOVALUE;
    }
L1: 

    /** parser.e:3879			CompileErr(THE_ENTRY_STATEMENT_MUST_APPEAR_INSIDE_A_LOOP)*/
    RefDS(_21993);
    _50CompileErr(144LL, _21993, 0LL);
L2: 

    /** parser.e:3881		if block_list[block_index]=IF or block_list[block_index]=SWITCH then*/
    _2 = (object)SEQ_PTR(_45block_list_54954);
    _30141 = (object)*(((s1_ptr)_2)->base + _45block_index_54955);
    _30142 = (_30141 == 20LL);
    _30141 = NOVALUE;
    if (_30142 != 0) {
        goto L3; // [52] 75
    }
    _2 = (object)SEQ_PTR(_45block_list_54954);
    _30144 = (object)*(((s1_ptr)_2)->base + _45block_index_54955);
    _30145 = (_30144 == 185LL);
    _30144 = NOVALUE;
    if (_30145 == 0)
    {
        DeRef(_30145);
        _30145 = NOVALUE;
        goto L4; // [71] 87
    }
    else{
        DeRef(_30145);
        _30145 = NOVALUE;
    }
L3: 

    /** parser.e:3882			CompileErr(THE_INNERMOST_BLOCK_CONTAINING_AN_ENTRY_STATEMENT_MUST_BE_THE_LOOP_IT_DEFINES_AN_ENTRY_IN)*/
    RefDS(_21993);
    _50CompileErr(143LL, _21993, 0LL);
    goto L5; // [84] 115
L4: 

    /** parser.e:3883		elsif loop_stack[$] = FOR then  -- not allowed in an innermost for loop*/
    if (IS_SEQUENCE(_45loop_stack_54958)){
            _30146 = SEQ_PTR(_45loop_stack_54958)->length;
    }
    else {
        _30146 = 1;
    }
    _2 = (object)SEQ_PTR(_45loop_stack_54958);
    _30147 = (object)*(((s1_ptr)_2)->base + _30146);
    if (_30147 != 21LL)
    goto L6; // [100] 114

    /** parser.e:3884			CompileErr(THE_ENTRY_STATEMENT_CAN_NOT_BE_USED_IN_A_FOR_BLOCK)*/
    RefDS(_21993);
    _50CompileErr(142LL, _21993, 0LL);
L6: 
L5: 

    /** parser.e:3886		addr = entry_addr[$]*/
    if (IS_SEQUENCE(_45entry_addr_54948)){
            _30149 = SEQ_PTR(_45entry_addr_54948)->length;
    }
    else {
        _30149 = 1;
    }
    _2 = (object)SEQ_PTR(_45entry_addr_54948);
    _addr_60847 = (object)*(((s1_ptr)_2)->base + _30149);

    /** parser.e:3887		if addr=0  then*/
    if (_addr_60847 != 0LL)
    goto L7; // [128] 144

    /** parser.e:3888			CompileErr(THE_ENTRY_STATEMENT_MUST_APPEAR_AT_MOST_ONCE_INSIDE_A_LOOP)*/
    RefDS(_21993);
    _50CompileErr(141LL, _21993, 0LL);
    goto L8; // [141] 161
L7: 

    /** parser.e:3889		elsif addr<0 then*/
    if (_addr_60847 >= 0LL)
    goto L9; // [146] 160

    /** parser.e:3890			CompileErr(ENTRY_STATEMENT_IS_BEING_USED_WITHOUT_A_CORRESPONDING_ENTRY_CLAUSE_IN_THE_LOOP_HEADER)*/
    RefDS(_21993);
    _50CompileErr(73LL, _21993, 0LL);
L9: 
L8: 

    /** parser.e:3892		backpatch(addr,ELSE)*/
    _47backpatch(_addr_60847, 23LL);

    /** parser.e:3893		backpatch(addr+1,length(Code)+1+(TRANSLATE>0))*/
    _30153 = _addr_60847 + 1;
    if (_30153 > MAXINT){
        _30153 = NewDouble((eudouble)_30153);
    }
    if (IS_SEQUENCE(_36Code_21531)){
            _30154 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _30154 = 1;
    }
    _30155 = _30154 + 1;
    _30154 = NOVALUE;
    _30156 = (_36TRANSLATE_21041 > 0LL);
    _30157 = _30155 + _30156;
    _30155 = NOVALUE;
    _30156 = NOVALUE;
    _47backpatch(_30153, _30157);
    _30153 = NOVALUE;
    _30157 = NOVALUE;

    /** parser.e:3894		entry_addr[$] = 0*/
    if (IS_SEQUENCE(_45entry_addr_54948)){
            _30158 = SEQ_PTR(_45entry_addr_54948)->length;
    }
    else {
        _30158 = 1;
    }
    _2 = (object)SEQ_PTR(_45entry_addr_54948);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _45entry_addr_54948 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _30158);
    *(intptr_t *)_2 = 0LL;

    /** parser.e:3895		if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto LA; // [213] 224
    }
    else{
    }

    /** parser.e:3896		    emit_op(NOP1)*/
    _47emit_op(159LL);
LA: 

    /** parser.e:3899		force_uninitialize( entry_stack[$] )*/
    if (IS_SEQUENCE(_45entry_stack_54951)){
            _30159 = SEQ_PTR(_45entry_stack_54951)->length;
    }
    else {
        _30159 = 1;
    }
    _2 = (object)SEQ_PTR(_45entry_stack_54951);
    _30160 = (object)*(((s1_ptr)_2)->base + _30159);
    Ref(_30160);
    _45force_uninitialize(_30160);
    _30160 = NOVALUE;

    /** parser.e:3901	end procedure*/
    DeRef(_30142);
    _30142 = NOVALUE;
    _30147 = NOVALUE;
    DeRef(_30138);
    _30138 = NOVALUE;
    return;
    ;
}


void _45force_uninitialize(object _uninitialized_60902)
{
    object _30163 = NOVALUE;
    object _30162 = NOVALUE;
    object _30161 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:3907		for i = 1 to length( uninitialized ) do*/
    if (IS_SEQUENCE(_uninitialized_60902)){
            _30161 = SEQ_PTR(_uninitialized_60902)->length;
    }
    else {
        _30161 = 1;
    }
    {
        object _i_60904;
        _i_60904 = 1LL;
L1: 
        if (_i_60904 > _30161){
            goto L2; // [8] 41
        }

        /** parser.e:3908			SymTab[uninitialized[i]][S_INITLEVEL] = -1*/
        _2 = (object)SEQ_PTR(_uninitialized_60902);
        _30162 = (object)*(((s1_ptr)_2)->base + _i_60904);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_30162))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_30162)->dbl));
        else
        _3 = (object)(_30162 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 14LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = -1LL;
        DeRef(_1);
        _30163 = NOVALUE;

        /** parser.e:3909		end for*/
        _i_60904 = _i_60904 + 1LL;
        goto L1; // [36] 15
L2: 
        ;
    }

    /** parser.e:3910	end procedure*/
    DeRefDS(_uninitialized_60902);
    _30162 = NOVALUE;
    return;
    ;
}


void _45Statement_list()
{
    object _tok_60914 = NOVALUE;
    object _id_60915 = NOVALUE;
    object _forward_60938 = NOVALUE;
    object _test_61087 = NOVALUE;
    object _30236 = NOVALUE;
    object _30235 = NOVALUE;
    object _30232 = NOVALUE;
    object _30230 = NOVALUE;
    object _30229 = NOVALUE;
    object _30226 = NOVALUE;
    object _30223 = NOVALUE;
    object _30222 = NOVALUE;
    object _30221 = NOVALUE;
    object _30218 = NOVALUE;
    object _30216 = NOVALUE;
    object _30214 = NOVALUE;
    object _30212 = NOVALUE;
    object _30194 = NOVALUE;
    object _30193 = NOVALUE;
    object _30191 = NOVALUE;
    object _30189 = NOVALUE;
    object _30188 = NOVALUE;
    object _30186 = NOVALUE;
    object _30184 = NOVALUE;
    object _30183 = NOVALUE;
    object _30182 = NOVALUE;
    object _30181 = NOVALUE;
    object _30176 = NOVALUE;
    object _30173 = NOVALUE;
    object _30172 = NOVALUE;
    object _30171 = NOVALUE;
    object _30170 = NOVALUE;
    object _30168 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:3915		integer id*/

    /** parser.e:3917		stmt_nest += 1*/
    _45stmt_nest_54956 = _45stmt_nest_54956 + 1;

    /** parser.e:3918		while TRUE do*/
L1: 
    if (_13TRUE_452 == 0)
    {
        goto L2; // [18] 1125
    }
    else{
    }

    /** parser.e:3919			tok = next_token()*/
    _0 = _tok_60914;
    _tok_60914 = _45next_token();
    DeRef(_0);

    /** parser.e:3920			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_60914);
    _id_60915 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_60915)){
        _id_60915 = (object)DBL_PTR(_id_60915)->dbl;
    }

    /** parser.e:3921			if id = VARIABLE or id = QUALIFIED_VARIABLE then*/
    _30168 = (_id_60915 == -100LL);
    if (_30168 != 0) {
        goto L3; // [44] 59
    }
    _30170 = (_id_60915 == 512LL);
    if (_30170 == 0)
    {
        DeRef(_30170);
        _30170 = NOVALUE;
        goto L4; // [55] 229
    }
    else{
        DeRef(_30170);
        _30170 = NOVALUE;
    }
L3: 

    /** parser.e:3922				if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_tok_60914);
    _30171 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_30171)){
        _30172 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30171)->dbl));
    }
    else{
        _30172 = (object)*(((s1_ptr)_2)->base + _30171);
    }
    _2 = (object)SEQ_PTR(_30172);
    _30173 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30172 = NOVALUE;
    if (binary_op_a(NOTEQ, _30173, 9LL)){
        _30173 = NOVALUE;
        goto L5; // [81] 210
    }
    _30173 = NOVALUE;

    /** parser.e:3923					token forward = next_token()*/
    _0 = _forward_60938;
    _forward_60938 = _45next_token();
    DeRef(_0);

    /** parser.e:3924					switch forward[T_ID] do*/
    _2 = (object)SEQ_PTR(_forward_60938);
    _30176 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_30176) ){
        goto L6; // [98] 204
    }
    if(!IS_ATOM_INT(_30176)){
        if( (DBL_PTR(_30176)->dbl != (eudouble) ((object) DBL_PTR(_30176)->dbl) ) ){
            goto L6; // [98] 204
        }
        _0 = (object) DBL_PTR(_30176)->dbl;
    }
    else {
        _0 = _30176;
    };
    _30176 = NOVALUE;
    switch ( _0 ){ 

        /** parser.e:3925						case LEFT_ROUND then*/
        case -26:

        /** parser.e:3926							StartSourceLine( TRUE )*/
        _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

        /** parser.e:3928							Forward_call( tok )*/
        Ref(_tok_60914);
        _45Forward_call(_tok_60914, 195LL);

        /** parser.e:3929							flush_temps()*/
        RefDS(_21993);
        _47flush_temps(_21993);

        /** parser.e:3930							continue*/
        DeRef(_forward_60938);
        _forward_60938 = NOVALUE;
        goto L1; // [133] 16
        goto L6; // [135] 204

        /** parser.e:3932						case VARIABLE then*/
        case -100:

        /** parser.e:3933							putback( forward )*/
        Ref(_forward_60938);
        _45putback(_forward_60938);

        /** parser.e:3934							if param_num != -1 then*/
        if (_45param_num_54933 == -1LL)
        goto L7; // [150] 176

        /** parser.e:3936								param_num += 1*/
        _45param_num_54933 = _45param_num_54933 + 1;

        /** parser.e:3937								Private_declaration( tok[T_SYM] )*/
        _2 = (object)SEQ_PTR(_tok_60914);
        _30181 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_30181);
        _45Private_declaration(_30181);
        _30181 = NOVALUE;
        goto L8; // [173] 192
L7: 

        /** parser.e:3939								Global_declaration( tok[T_SYM], SC_LOCAL )*/
        _2 = (object)SEQ_PTR(_tok_60914);
        _30182 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_30182);
        _30183 = _45Global_declaration(_30182, 5LL);
        _30182 = NOVALUE;
L8: 

        /** parser.e:3941							flush_temps()*/
        RefDS(_21993);
        _47flush_temps(_21993);

        /** parser.e:3942							continue*/
        DeRef(_forward_60938);
        _forward_60938 = NOVALUE;
        goto L1; // [201] 16
    ;}L6: 

    /** parser.e:3945					putback( forward )*/
    Ref(_forward_60938);
    _45putback(_forward_60938);
L5: 
    DeRef(_forward_60938);
    _forward_60938 = NOVALUE;

    /** parser.e:3947				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:3948				Assignment(tok)*/
    Ref(_tok_60914);
    _45Assignment(_tok_60914);
    goto L9; // [226] 1115
L4: 

    /** parser.e:3950			elsif id = PROC or id = QUALIFIED_PROC then*/
    _30184 = (_id_60915 == 27LL);
    if (_30184 != 0) {
        goto LA; // [237] 252
    }
    _30186 = (_id_60915 == 521LL);
    if (_30186 == 0)
    {
        DeRef(_30186);
        _30186 = NOVALUE;
        goto LB; // [248] 289
    }
    else{
        DeRef(_30186);
        _30186 = NOVALUE;
    }
LA: 

    /** parser.e:3951				if id = PROC then*/
    if (_id_60915 != 27LL)
    goto LC; // [256] 272

    /** parser.e:3953					UndefinedVar( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_60914);
    _30188 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30188);
    _45UndefinedVar(_30188);
    _30188 = NOVALUE;
LC: 

    /** parser.e:3955				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:3956				Procedure_call(tok)*/
    Ref(_tok_60914);
    _45Procedure_call(_tok_60914);
    goto L9; // [286] 1115
LB: 

    /** parser.e:3958			elsif id = FUNC or id = QUALIFIED_FUNC then*/
    _30189 = (_id_60915 == 501LL);
    if (_30189 != 0) {
        goto LD; // [297] 312
    }
    _30191 = (_id_60915 == 520LL);
    if (_30191 == 0)
    {
        DeRef(_30191);
        _30191 = NOVALUE;
        goto LE; // [308] 362
    }
    else{
        DeRef(_30191);
        _30191 = NOVALUE;
    }
LD: 

    /** parser.e:3959				if id = FUNC then*/
    if (_id_60915 != 501LL)
    goto LF; // [316] 332

    /** parser.e:3961					UndefinedVar( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_60914);
    _30193 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30193);
    _45UndefinedVar(_30193);
    _30193 = NOVALUE;
LF: 

    /** parser.e:3963				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:3964				Procedure_call(tok)*/
    Ref(_tok_60914);
    _45Procedure_call(_tok_60914);

    /** parser.e:3965				clear_op()*/
    _47clear_op();

    /** parser.e:3966				if Pop() then end if*/
    _30194 = _47Pop();
    if (_30194 == 0) {
        DeRef(_30194);
        _30194 = NOVALUE;
        goto L9; // [355] 1115
    }
    else {
        if (!IS_ATOM_INT(_30194) && DBL_PTR(_30194)->dbl == 0.0){
            DeRef(_30194);
            _30194 = NOVALUE;
            goto L9; // [355] 1115
        }
        DeRef(_30194);
        _30194 = NOVALUE;
    }
    DeRef(_30194);
    _30194 = NOVALUE;
    goto L9; // [359] 1115
LE: 

    /** parser.e:3968			elsif id = IF then*/
    if (_id_60915 != 20LL)
    goto L10; // [366] 386

    /** parser.e:3969				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:3970				If_statement()*/
    _45If_statement();
    goto L9; // [383] 1115
L10: 

    /** parser.e:3972			elsif id = FOR then*/
    if (_id_60915 != 21LL)
    goto L11; // [390] 410

    /** parser.e:3973				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:3974				For_statement()*/
    _45For_statement();
    goto L9; // [407] 1115
L11: 

    /** parser.e:3976			elsif id = RETURN then*/
    if (_id_60915 != 413LL)
    goto L12; // [414] 434

    /** parser.e:3977				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:3978				Return_statement()*/
    _45Return_statement();
    goto L9; // [431] 1115
L12: 

    /** parser.e:3980			elsif id = LABEL then*/
    if (_id_60915 != 419LL)
    goto L13; // [438] 460

    /** parser.e:3981				StartSourceLine(TRUE, , COVERAGE_SUPPRESS )*/
    _47StartSourceLine(_13TRUE_452, 0LL, 1LL);

    /** parser.e:3982				GLabel_statement()*/
    _45GLabel_statement();
    goto L9; // [457] 1115
L13: 

    /** parser.e:3984			elsif id = GOTO then*/
    if (_id_60915 != 188LL)
    goto L14; // [464] 484

    /** parser.e:3985				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:3986				Goto_statement()*/
    _45Goto_statement();
    goto L9; // [481] 1115
L14: 

    /** parser.e:3988			elsif id = EXIT then*/
    if (_id_60915 != 61LL)
    goto L15; // [488] 508

    /** parser.e:3989				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:3990				Exit_statement()*/
    _45Exit_statement();
    goto L9; // [505] 1115
L15: 

    /** parser.e:3992			elsif id = BREAK then*/
    if (_id_60915 != 425LL)
    goto L16; // [512] 532

    /** parser.e:3993				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:3994				Break_statement()*/
    _45Break_statement();
    goto L9; // [529] 1115
L16: 

    /** parser.e:3996			elsif id = WHILE then*/
    if (_id_60915 != 47LL)
    goto L17; // [536] 556

    /** parser.e:3997				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:3998				While_statement()*/
    _45While_statement();
    goto L9; // [553] 1115
L17: 

    /** parser.e:4000			elsif id = LOOP then*/
    if (_id_60915 != 422LL)
    goto L18; // [560] 580

    /** parser.e:4001			    StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:4002		        Loop_statement()*/
    _45Loop_statement();
    goto L9; // [577] 1115
L18: 

    /** parser.e:4004			elsif id = ENTRY then*/
    if (_id_60915 != 424LL)
    goto L19; // [584] 606

    /** parser.e:4005			    StartSourceLine(TRUE, , COVERAGE_SUPPRESS )*/
    _47StartSourceLine(_13TRUE_452, 0LL, 1LL);

    /** parser.e:4006			    Entry_statement()*/
    _45Entry_statement();
    goto L9; // [603] 1115
L19: 

    /** parser.e:4008			elsif id = QUESTION_MARK then*/
    if (_id_60915 != -31LL)
    goto L1A; // [610] 630

    /** parser.e:4009				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:4010				Print_statement()*/
    _45Print_statement();
    goto L9; // [627] 1115
L1A: 

    /** parser.e:4012			elsif id = CONTINUE then*/
    if (_id_60915 != 426LL)
    goto L1B; // [634] 654

    /** parser.e:4013				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:4014				Continue_statement()*/
    _45Continue_statement();
    goto L9; // [651] 1115
L1B: 

    /** parser.e:4016			elsif id = RETRY then*/
    if (_id_60915 != 184LL)
    goto L1C; // [658] 678

    /** parser.e:4017				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:4018				Retry_statement()*/
    _45Retry_statement();
    goto L9; // [675] 1115
L1C: 

    /** parser.e:4020			elsif id = IFDEF then*/
    if (_id_60915 != 407LL)
    goto L1D; // [682] 702

    /** parser.e:4021				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:4022				Ifdef_statement()*/
    _45Ifdef_statement();
    goto L9; // [699] 1115
L1D: 

    /** parser.e:4024			elsif id = CASE then*/
    if (_id_60915 != 186LL)
    goto L1E; // [706] 717

    /** parser.e:4025				Case_statement()*/
    _45Case_statement();
    goto L9; // [714] 1115
L1E: 

    /** parser.e:4027			elsif id = SWITCH then*/
    if (_id_60915 != 185LL)
    goto L1F; // [721] 741

    /** parser.e:4028				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:4029				Switch_statement()*/
    _45Switch_statement();
    goto L9; // [738] 1115
L1F: 

    /** parser.e:4031			elsif id = FALLTHRU then*/
    if (_id_60915 != 431LL)
    goto L20; // [745] 756

    /** parser.e:4032				Fallthru_statement()*/
    _45Fallthru_statement();
    goto L9; // [753] 1115
L20: 

    /** parser.e:4034			elsif id = TYPE or id = QUALIFIED_TYPE then*/
    _30212 = (_id_60915 == 504LL);
    if (_30212 != 0) {
        goto L21; // [764] 779
    }
    _30214 = (_id_60915 == 522LL);
    if (_30214 == 0)
    {
        DeRef(_30214);
        _30214 = NOVALUE;
        goto L22; // [775] 904
    }
    else{
        DeRef(_30214);
        _30214 = NOVALUE;
    }
L21: 

    /** parser.e:4035				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:4036				token test = next_token()*/
    _0 = _test_61087;
    _test_61087 = _45next_token();
    DeRef(_0);

    /** parser.e:4037				putback( test )*/
    Ref(_test_61087);
    _45putback(_test_61087);

    /** parser.e:4038				if test[T_ID] = LEFT_ROUND then*/
    _2 = (object)SEQ_PTR(_test_61087);
    _30216 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30216, -26LL)){
        _30216 = NOVALUE;
        goto L23; // [808] 852
    }
    _30216 = NOVALUE;

    /** parser.e:4039					StartSourceLine( TRUE )*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:4040					Procedure_call(tok)*/
    Ref(_tok_60914);
    _45Procedure_call(_tok_60914);

    /** parser.e:4041					clear_op()*/
    _47clear_op();

    /** parser.e:4042					if Pop() then end if*/
    _30218 = _47Pop();
    if (_30218 == 0) {
        DeRef(_30218);
        _30218 = NOVALUE;
        goto L24; // [835] 839
    }
    else {
        if (!IS_ATOM_INT(_30218) && DBL_PTR(_30218)->dbl == 0.0){
            DeRef(_30218);
            _30218 = NOVALUE;
            goto L24; // [835] 839
        }
        DeRef(_30218);
        _30218 = NOVALUE;
    }
    DeRef(_30218);
    _30218 = NOVALUE;
L24: 

    /** parser.e:4043					ExecCommand()*/
    _45ExecCommand();

    /** parser.e:4044					continue*/
    DeRef(_test_61087);
    _test_61087 = NOVALUE;
    goto L1; // [847] 16
    goto L25; // [849] 899
L23: 

    /** parser.e:4047					if param_num != -1 then*/
    if (_45param_num_54933 == -1LL)
    goto L26; // [856] 882

    /** parser.e:4049						param_num += 1*/
    _45param_num_54933 = _45param_num_54933 + 1;

    /** parser.e:4050						Private_declaration( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_60914);
    _30221 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30221);
    _45Private_declaration(_30221);
    _30221 = NOVALUE;
    goto L27; // [879] 898
L26: 

    /** parser.e:4052						Global_declaration( tok[T_SYM], SC_LOCAL )*/
    _2 = (object)SEQ_PTR(_tok_60914);
    _30222 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30222);
    _30223 = _45Global_declaration(_30222, 5LL);
    _30222 = NOVALUE;
L27: 
L25: 
    DeRef(_test_61087);
    _test_61087 = NOVALUE;
    goto L9; // [901] 1115
L22: 

    /** parser.e:4055			elsif id = LEFT_BRACE then*/
    if (_id_60915 != -24LL)
    goto L28; // [908] 928

    /** parser.e:4056				StartSourceLine( TRUE )*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:4057				Multi_assign()*/
    _45Multi_assign();
    goto L9; // [925] 1115
L28: 

    /** parser.e:4060				if id = ELSE then*/
    if (_id_60915 != 23LL)
    goto L29; // [932] 990

    /** parser.e:4061					if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_45if_stack_54959)){
            _30226 = SEQ_PTR(_45if_stack_54959)->length;
    }
    else {
        _30226 = 1;
    }
    if (_30226 != 0LL)
    goto L2A; // [943] 1051

    /** parser.e:4062						if live_ifdef > 0 then*/
    if (_45live_ifdef_59426 <= 0LL)
    goto L2B; // [951] 976

    /** parser.e:4063							CompileErr(SHOULD_THIS_BE_ELSEDEF_FOR_THE_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_45ifdef_lineno_59427)){
            _30229 = SEQ_PTR(_45ifdef_lineno_59427)->length;
    }
    else {
        _30229 = 1;
    }
    _2 = (object)SEQ_PTR(_45ifdef_lineno_59427);
    _30230 = (object)*(((s1_ptr)_2)->base + _30229);
    _50CompileErr(134LL, _30230, 0LL);
    _30230 = NOVALUE;
    goto L2A; // [973] 1051
L2B: 

    /** parser.e:4065							CompileErr(NOT_EXPECTING_ELSE)*/
    RefDS(_21993);
    _50CompileErr(118LL, _21993, 0LL);
    goto L2A; // [987] 1051
L29: 

    /** parser.e:4068				elsif id = ELSIF then*/
    if (_id_60915 != 414LL)
    goto L2C; // [994] 1050

    /** parser.e:4069					if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_45if_stack_54959)){
            _30232 = SEQ_PTR(_45if_stack_54959)->length;
    }
    else {
        _30232 = 1;
    }
    if (_30232 != 0LL)
    goto L2D; // [1005] 1049

    /** parser.e:4070						if live_ifdef > 0 then*/
    if (_45live_ifdef_59426 <= 0LL)
    goto L2E; // [1013] 1038

    /** parser.e:4071							CompileErr(SHOULD_THIS_BE_ELSIFDEF_FOR_THE_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_45ifdef_lineno_59427)){
            _30235 = SEQ_PTR(_45ifdef_lineno_59427)->length;
    }
    else {
        _30235 = 1;
    }
    _2 = (object)SEQ_PTR(_45ifdef_lineno_59427);
    _30236 = (object)*(((s1_ptr)_2)->base + _30235);
    _50CompileErr(139LL, _30236, 0LL);
    _30236 = NOVALUE;
    goto L2F; // [1035] 1048
L2E: 

    /** parser.e:4073							CompileErr(NOT_EXPECTING_ELSIF)*/
    RefDS(_21993);
    _50CompileErr(119LL, _21993, 0LL);
L2F: 
L2D: 
L2C: 
L2A: 

    /** parser.e:4078				putback( tok )*/
    Ref(_tok_60914);
    _45putback(_tok_60914);

    /** parser.e:4080				switch id do*/
    _0 = _id_60915;
    switch ( _0 ){ 

        /** parser.e:4081					case END, ELSEDEF, ELSIFDEF, ELSIF, ELSE, UNTIL then*/
        case 402:
        case 409:
        case 408:
        case 414:
        case 23:
        case 423:

        /** parser.e:4083						stmt_nest -= 1*/
        _45stmt_nest_54956 = _45stmt_nest_54956 - 1LL;

        /** parser.e:4084						InitDelete()*/
        _45InitDelete();

        /** parser.e:4085						flush_temps()*/
        RefDS(_21993);
        _47flush_temps(_21993);

        /** parser.e:4086						return*/
        DeRef(_tok_60914);
        DeRef(_30184);
        _30184 = NOVALUE;
        DeRef(_30168);
        _30168 = NOVALUE;
        DeRef(_30189);
        _30189 = NOVALUE;
        DeRef(_30183);
        _30183 = NOVALUE;
        DeRef(_30212);
        _30212 = NOVALUE;
        _30171 = NOVALUE;
        DeRef(_30223);
        _30223 = NOVALUE;
        return;
        goto L30; // [1099] 1114

        /** parser.e:4088					case else*/
        default:

        /** parser.e:4089						tok_match( END )*/
        _45tok_match(402LL, 0LL);
    ;}L30: 
L9: 

    /** parser.e:4094			flush_temps()*/
    RefDS(_21993);
    _47flush_temps(_21993);

    /** parser.e:4095		end while*/
    goto L1; // [1122] 16
L2: 

    /** parser.e:4096	end procedure*/
    DeRef(_tok_60914);
    DeRef(_30184);
    _30184 = NOVALUE;
    DeRef(_30168);
    _30168 = NOVALUE;
    DeRef(_30189);
    _30189 = NOVALUE;
    DeRef(_30183);
    _30183 = NOVALUE;
    DeRef(_30212);
    _30212 = NOVALUE;
    _30171 = NOVALUE;
    DeRef(_30223);
    _30223 = NOVALUE;
    return;
    ;
}


void _45SubProg(object _prog_type_61166, object _scope_61167, object _deprecated_61168)
{
    object _h_61169 = NOVALUE;
    object _pt_61170 = NOVALUE;
    object _p_61172 = NOVALUE;
    object _type_sym_61173 = NOVALUE;
    object _sym_61174 = NOVALUE;
    object _tok_61176 = NOVALUE;
    object _prog_name_61177 = NOVALUE;
    object _first_def_arg_61178 = NOVALUE;
    object _again_61179 = NOVALUE;
    object _type_enum_61180 = NOVALUE;
    object _seq_sym_61181 = NOVALUE;
    object _i1_sym_61182 = NOVALUE;
    object _enum_syms_61183 = NOVALUE;
    object _type_enum_gline_61184 = NOVALUE;
    object _real_gline_61185 = NOVALUE;
    object _tsym_61197 = NOVALUE;
    object _seq_symbol_61208 = NOVALUE;
    object _middle_def_args_61413 = NOVALUE;
    object _last_nda_61414 = NOVALUE;
    object _start_def_61415 = NOVALUE;
    object _last_link_61417 = NOVALUE;
    object _temptok_61444 = NOVALUE;
    object _undef_type_61446 = NOVALUE;
    object _tokcat_61498 = NOVALUE;
    object _31679 = NOVALUE;
    object _31678 = NOVALUE;
    object _31677 = NOVALUE;
    object _31676 = NOVALUE;
    object _31675 = NOVALUE;
    object _31674 = NOVALUE;
    object _31673 = NOVALUE;
    object _31672 = NOVALUE;
    object _31671 = NOVALUE;
    object _30502 = NOVALUE;
    object _30500 = NOVALUE;
    object _30499 = NOVALUE;
    object _30497 = NOVALUE;
    object _30496 = NOVALUE;
    object _30495 = NOVALUE;
    object _30494 = NOVALUE;
    object _30493 = NOVALUE;
    object _30491 = NOVALUE;
    object _30490 = NOVALUE;
    object _30487 = NOVALUE;
    object _30486 = NOVALUE;
    object _30485 = NOVALUE;
    object _30484 = NOVALUE;
    object _30482 = NOVALUE;
    object _30473 = NOVALUE;
    object _30471 = NOVALUE;
    object _30470 = NOVALUE;
    object _30469 = NOVALUE;
    object _30468 = NOVALUE;
    object _30465 = NOVALUE;
    object _30464 = NOVALUE;
    object _30463 = NOVALUE;
    object _30461 = NOVALUE;
    object _30458 = NOVALUE;
    object _30457 = NOVALUE;
    object _30456 = NOVALUE;
    object _30454 = NOVALUE;
    object _30453 = NOVALUE;
    object _30450 = NOVALUE;
    object _30448 = NOVALUE;
    object _30446 = NOVALUE;
    object _30445 = NOVALUE;
    object _30444 = NOVALUE;
    object _30443 = NOVALUE;
    object _30441 = NOVALUE;
    object _30440 = NOVALUE;
    object _30439 = NOVALUE;
    object _30438 = NOVALUE;
    object _30437 = NOVALUE;
    object _30436 = NOVALUE;
    object _30433 = NOVALUE;
    object _30431 = NOVALUE;
    object _30429 = NOVALUE;
    object _30427 = NOVALUE;
    object _30425 = NOVALUE;
    object _30422 = NOVALUE;
    object _30420 = NOVALUE;
    object _30419 = NOVALUE;
    object _30416 = NOVALUE;
    object _30412 = NOVALUE;
    object _30411 = NOVALUE;
    object _30409 = NOVALUE;
    object _30407 = NOVALUE;
    object _30405 = NOVALUE;
    object _30403 = NOVALUE;
    object _30401 = NOVALUE;
    object _30399 = NOVALUE;
    object _30398 = NOVALUE;
    object _30397 = NOVALUE;
    object _30396 = NOVALUE;
    object _30395 = NOVALUE;
    object _30394 = NOVALUE;
    object _30393 = NOVALUE;
    object _30392 = NOVALUE;
    object _30391 = NOVALUE;
    object _30390 = NOVALUE;
    object _30389 = NOVALUE;
    object _30388 = NOVALUE;
    object _30385 = NOVALUE;
    object _30384 = NOVALUE;
    object _30383 = NOVALUE;
    object _30382 = NOVALUE;
    object _30381 = NOVALUE;
    object _30380 = NOVALUE;
    object _30379 = NOVALUE;
    object _30378 = NOVALUE;
    object _30377 = NOVALUE;
    object _30376 = NOVALUE;
    object _30375 = NOVALUE;
    object _30374 = NOVALUE;
    object _30373 = NOVALUE;
    object _30372 = NOVALUE;
    object _30371 = NOVALUE;
    object _30369 = NOVALUE;
    object _30367 = NOVALUE;
    object _30366 = NOVALUE;
    object _30361 = NOVALUE;
    object _30360 = NOVALUE;
    object _30358 = NOVALUE;
    object _30357 = NOVALUE;
    object _30356 = NOVALUE;
    object _30355 = NOVALUE;
    object _30354 = NOVALUE;
    object _30353 = NOVALUE;
    object _30352 = NOVALUE;
    object _30351 = NOVALUE;
    object _30350 = NOVALUE;
    object _30349 = NOVALUE;
    object _30347 = NOVALUE;
    object _30346 = NOVALUE;
    object _30344 = NOVALUE;
    object _30343 = NOVALUE;
    object _30342 = NOVALUE;
    object _30341 = NOVALUE;
    object _30340 = NOVALUE;
    object _30339 = NOVALUE;
    object _30338 = NOVALUE;
    object _30336 = NOVALUE;
    object _30333 = NOVALUE;
    object _30331 = NOVALUE;
    object _30329 = NOVALUE;
    object _30327 = NOVALUE;
    object _30325 = NOVALUE;
    object _30323 = NOVALUE;
    object _30321 = NOVALUE;
    object _30319 = NOVALUE;
    object _30317 = NOVALUE;
    object _30315 = NOVALUE;
    object _30314 = NOVALUE;
    object _30313 = NOVALUE;
    object _30312 = NOVALUE;
    object _30311 = NOVALUE;
    object _30310 = NOVALUE;
    object _30309 = NOVALUE;
    object _30307 = NOVALUE;
    object _30306 = NOVALUE;
    object _30304 = NOVALUE;
    object _30302 = NOVALUE;
    object _30300 = NOVALUE;
    object _30299 = NOVALUE;
    object _30296 = NOVALUE;
    object _30295 = NOVALUE;
    object _30294 = NOVALUE;
    object _30293 = NOVALUE;
    object _30292 = NOVALUE;
    object _30290 = NOVALUE;
    object _30289 = NOVALUE;
    object _30288 = NOVALUE;
    object _30287 = NOVALUE;
    object _30286 = NOVALUE;
    object _30284 = NOVALUE;
    object _30283 = NOVALUE;
    object _30282 = NOVALUE;
    object _30280 = NOVALUE;
    object _30279 = NOVALUE;
    object _30278 = NOVALUE;
    object _30277 = NOVALUE;
    object _30273 = NOVALUE;
    object _30272 = NOVALUE;
    object _30271 = NOVALUE;
    object _30269 = NOVALUE;
    object _30268 = NOVALUE;
    object _30267 = NOVALUE;
    object _30266 = NOVALUE;
    object _30265 = NOVALUE;
    object _30264 = NOVALUE;
    object _30260 = NOVALUE;
    object _30259 = NOVALUE;
    object _30258 = NOVALUE;
    object _30256 = NOVALUE;
    object _30255 = NOVALUE;
    object _30254 = NOVALUE;
    object _30252 = NOVALUE;
    object _30251 = NOVALUE;
    object _30249 = NOVALUE;
    object _30248 = NOVALUE;
    object _30247 = NOVALUE;
    object _30243 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_prog_type_61166)) {
        _1 = (object)(DBL_PTR(_prog_type_61166)->dbl);
        DeRefDS(_prog_type_61166);
        _prog_type_61166 = _1;
    }

    /** parser.e:4105		integer first_def_arg*/

    /** parser.e:4106		integer again*/

    /** parser.e:4107		integer type_enum*/

    /** parser.e:4108		object seq_sym*/

    /** parser.e:4109		object i1_sym*/

    /** parser.e:4110		sequence enum_syms = {}*/
    RefDS(_21993);
    DeRef(_enum_syms_61183);
    _enum_syms_61183 = _21993;

    /** parser.e:4111		integer type_enum_gline, real_gline*/

    /** parser.e:4113		LeaveTopLevel()*/
    _45LeaveTopLevel();

    /** parser.e:4114		prog_name = next_token()*/
    _0 = _prog_name_61177;
    _prog_name_61177 = _45next_token();
    DeRef(_0);

    /** parser.e:4115		if prog_name[T_ID] = END_OF_FILE then*/
    _2 = (object)SEQ_PTR(_prog_name_61177);
    _30243 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30243, -21LL)){
        _30243 = NOVALUE;
        goto L1; // [45] 59
    }
    _30243 = NOVALUE;

    /** parser.e:4116			CompileErr( AN_IDENTIFIER_IS_EXPECTED_HERE)*/
    RefDS(_21993);
    _50CompileErr(32LL, _21993, 0LL);
L1: 

    /** parser.e:4118		type_enum =  0*/
    _type_enum_61180 = 0LL;

    /** parser.e:4119		if prog_type = TYPE_DECL then*/
    if (_prog_type_61166 != 416LL)
    goto L2; // [68] 322

    /** parser.e:4120			object tsym = prog_name[T_SYM]*/
    DeRef(_tsym_61197);
    _2 = (object)SEQ_PTR(_prog_name_61177);
    _tsym_61197 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_tsym_61197);

    /** parser.e:4121			if equal(sym_name(prog_name[T_SYM]),"enum") then*/
    _2 = (object)SEQ_PTR(_prog_name_61177);
    _30247 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30247);
    _30248 = _54sym_name(_30247);
    _30247 = NOVALUE;
    if (_30248 == _26182)
    _30249 = 1;
    else if (IS_ATOM_INT(_30248) && IS_ATOM_INT(_26182))
    _30249 = 0;
    else
    _30249 = (compare(_30248, _26182) == 0);
    DeRef(_30248);
    _30248 = NOVALUE;
    if (_30249 == 0)
    {
        _30249 = NOVALUE;
        goto L3; // [96] 319
    }
    else{
        _30249 = NOVALUE;
    }

    /** parser.e:4125				EnterTopLevel( FALSE )*/
    _45EnterTopLevel(_13FALSE_450);

    /** parser.e:4126				type_enum_gline = gline_number*/
    _type_enum_gline_61184 = _36gline_number_21444;

    /** parser.e:4127				type_enum = 1*/
    _type_enum_61180 = 1LL;

    /** parser.e:4128				sequence seq_symbol*/

    /** parser.e:4129				prog_name = next_token()*/
    _0 = _prog_name_61177;
    _prog_name_61177 = _45next_token();
    DeRef(_0);

    /** parser.e:4130				if not find(prog_name[T_ID], ADDR_TOKS) then*/
    _2 = (object)SEQ_PTR(_prog_name_61177);
    _30251 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30252 = find_from(_30251, _38ADDR_TOKS_16049, 1LL);
    _30251 = NOVALUE;
    if (_30252 != 0)
    goto L4; // [142] 169
    _30252 = NOVALUE;

    /** parser.e:4131					CompileErr(FOUND__1__BUT_WAS_EXPECTING_AN_IDENTIFIER_NAME, {find_category(prog_name[T_ID])} )*/
    _2 = (object)SEQ_PTR(_prog_name_61177);
    _30254 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_30254);
    _30255 = _63find_category(_30254);
    _30254 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30255;
    _30256 = MAKE_SEQ(_1);
    _30255 = NOVALUE;
    _50CompileErr(25LL, _30256, 0LL);
    _30256 = NOVALUE;
L4: 

    /** parser.e:4133				enum_syms = Global_declaration(-1, scope)*/
    _0 = _enum_syms_61183;
    _enum_syms_61183 = _45Global_declaration(-1LL, _scope_61167);
    DeRef(_0);

    /** parser.e:4134				seq_symbol = enum_syms*/
    RefDS(_enum_syms_61183);
    DeRef(_seq_symbol_61208);
    _seq_symbol_61208 = _enum_syms_61183;

    /** parser.e:4135				for i = 1 to length( enum_syms ) do*/
    if (IS_SEQUENCE(_enum_syms_61183)){
            _30258 = SEQ_PTR(_enum_syms_61183)->length;
    }
    else {
        _30258 = 1;
    }
    {
        object _i_61225;
        _i_61225 = 1LL;
L5: 
        if (_i_61225 > _30258){
            goto L6; // [190] 218
        }

        /** parser.e:4136					seq_symbol[i] = sym_obj(enum_syms[i])*/
        _2 = (object)SEQ_PTR(_enum_syms_61183);
        _30259 = (object)*(((s1_ptr)_2)->base + _i_61225);
        Ref(_30259);
        _30260 = _54sym_obj(_30259);
        _30259 = NOVALUE;
        _2 = (object)SEQ_PTR(_seq_symbol_61208);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _seq_symbol_61208 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_61225);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _30260;
        if( _1 != _30260 ){
            DeRef(_1);
        }
        _30260 = NOVALUE;

        /** parser.e:4137				end for*/
        _i_61225 = _i_61225 + 1LL;
        goto L5; // [213] 197
L6: 
        ;
    }

    /** parser.e:4142				i1_sym = keyfind("i1",-1)*/
    RefDS(_30261);
    DeRef(_31678);
    _31678 = _30261;
    _31679 = _54hashfn(_31678);
    _31678 = NOVALUE;
    RefDS(_30261);
    _0 = _i1_sym_61182;
    _i1_sym_61182 = _54keyfind(_30261, -1LL, _36current_file_no_21439, 0LL, _31679);
    DeRef(_0);
    _31679 = NOVALUE;

    /** parser.e:4143				seq_sym = NewStringSym(seq_symbol)*/
    RefDS(_seq_symbol_61208);
    _0 = _seq_sym_61181;
    _seq_sym_61181 = _54NewStringSym(_seq_symbol_61208);
    DeRef(_0);

    /** parser.e:4144				putback(keyfind("return",-1))*/
    RefDS(_26256);
    DeRef(_31676);
    _31676 = _26256;
    _31677 = _54hashfn(_31676);
    _31676 = NOVALUE;
    RefDS(_26256);
    _30264 = _54keyfind(_26256, -1LL, _36current_file_no_21439, 0LL, _31677);
    _31677 = NOVALUE;
    _45putback(_30264);
    _30264 = NOVALUE;

    /** parser.e:4145				putback({RIGHT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -27LL;
    ((intptr_t *)_2)[2] = 0LL;
    _30265 = MAKE_SEQ(_1);
    _45putback(_30265);
    _30265 = NOVALUE;

    /** parser.e:4146				putback(i1_sym)*/
    Ref(_i1_sym_61182);
    _45putback(_i1_sym_61182);

    /** parser.e:4147				putback(keyfind("object",-1))*/
    RefDS(_22955);
    DeRef(_31674);
    _31674 = _22955;
    _31675 = _54hashfn(_31674);
    _31674 = NOVALUE;
    RefDS(_22955);
    _30266 = _54keyfind(_22955, -1LL, _36current_file_no_21439, 0LL, _31675);
    _31675 = NOVALUE;
    _45putback(_30266);
    _30266 = NOVALUE;

    /** parser.e:4148				putback({LEFT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -26LL;
    ((intptr_t *)_2)[2] = 0LL;
    _30267 = MAKE_SEQ(_1);
    _45putback(_30267);
    _30267 = NOVALUE;

    /** parser.e:4150				LeaveTopLevel()*/
    _45LeaveTopLevel();
L3: 
    DeRef(_seq_symbol_61208);
    _seq_symbol_61208 = NOVALUE;
L2: 
    DeRef(_tsym_61197);
    _tsym_61197 = NOVALUE;

    /** parser.e:4153		if not find(prog_name[T_ID], ADDR_TOKS) then*/
    _2 = (object)SEQ_PTR(_prog_name_61177);
    _30268 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30269 = find_from(_30268, _38ADDR_TOKS_16049, 1LL);
    _30268 = NOVALUE;
    if (_30269 != 0)
    goto L7; // [339] 366
    _30269 = NOVALUE;

    /** parser.e:4154			CompileErr(FOUND__1__BUT_WAS_EXPECTING_AN_IDENTIFIER_NAME, {find_category(prog_name[T_ID])} )*/
    _2 = (object)SEQ_PTR(_prog_name_61177);
    _30271 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_30271);
    _30272 = _63find_category(_30271);
    _30271 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30272;
    _30273 = MAKE_SEQ(_1);
    _30272 = NOVALUE;
    _50CompileErr(25LL, _30273, 0LL);
    _30273 = NOVALUE;
L7: 

    /** parser.e:4156		p = prog_name[T_SYM]*/
    _2 = (object)SEQ_PTR(_prog_name_61177);
    _p_61172 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_p_61172)){
        _p_61172 = (object)DBL_PTR(_p_61172)->dbl;
    }

    /** parser.e:4157		DefinedYet(p)*/
    _54DefinedYet(_p_61172);

    /** parser.e:4158		if prog_type = PROCEDURE then*/
    if (_prog_type_61166 != 405LL)
    goto L8; // [385] 401

    /** parser.e:4159			pt = PROC*/
    _pt_61170 = 27LL;
    goto L9; // [398] 431
L8: 

    /** parser.e:4160		elsif prog_type = FUNCTION then*/
    if (_prog_type_61166 != 406LL)
    goto LA; // [405] 421

    /** parser.e:4161			pt = FUNC*/
    _pt_61170 = 501LL;
    goto L9; // [418] 431
LA: 

    /** parser.e:4163			pt = TYPE*/
    _pt_61170 = 504LL;
L9: 

    /** parser.e:4166		clear_fwd_refs()*/
    _44clear_fwd_refs();

    /** parser.e:4167		if find(SymTab[p][S_SCOPE], {SC_PREDEF, SC_GLOBAL, SC_PUBLIC, SC_EXPORT, SC_OVERRIDE}) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30277 = (object)*(((s1_ptr)_2)->base + _p_61172);
    _2 = (object)SEQ_PTR(_30277);
    _30278 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30277 = NOVALUE;
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 7LL;
    ((intptr_t*)_2)[2] = 6LL;
    ((intptr_t*)_2)[3] = 13LL;
    ((intptr_t*)_2)[4] = 11LL;
    ((intptr_t*)_2)[5] = 12LL;
    _30279 = MAKE_SEQ(_1);
    _30280 = find_from(_30278, _30279, 1LL);
    _30278 = NOVALUE;
    DeRefDS(_30279);
    _30279 = NOVALUE;
    if (_30280 == 0)
    {
        _30280 = NOVALUE;
        goto LB; // [472] 668
    }
    else{
        _30280 = NOVALUE;
    }

    /** parser.e:4169			if scope = SC_OVERRIDE then*/
    if (_scope_61167 != 12LL)
    goto LC; // [479] 605

    /** parser.e:4170				if SymTab[p][S_SCOPE] = SC_PREDEF or SymTab[p][S_SCOPE] = SC_OVERRIDE then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30282 = (object)*(((s1_ptr)_2)->base + _p_61172);
    _2 = (object)SEQ_PTR(_30282);
    _30283 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30282 = NOVALUE;
    if (IS_ATOM_INT(_30283)) {
        _30284 = (_30283 == 7LL);
    }
    else {
        _30284 = binary_op(EQUALS, _30283, 7LL);
    }
    _30283 = NOVALUE;
    if (IS_ATOM_INT(_30284)) {
        if (_30284 != 0) {
            goto LD; // [503] 530
        }
    }
    else {
        if (DBL_PTR(_30284)->dbl != 0.0) {
            goto LD; // [503] 530
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30286 = (object)*(((s1_ptr)_2)->base + _p_61172);
    _2 = (object)SEQ_PTR(_30286);
    _30287 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30286 = NOVALUE;
    if (IS_ATOM_INT(_30287)) {
        _30288 = (_30287 == 12LL);
    }
    else {
        _30288 = binary_op(EQUALS, _30287, 12LL);
    }
    _30287 = NOVALUE;
    if (_30288 == 0) {
        DeRef(_30288);
        _30288 = NOVALUE;
        goto LE; // [526] 604
    }
    else {
        if (!IS_ATOM_INT(_30288) && DBL_PTR(_30288)->dbl == 0.0){
            DeRef(_30288);
            _30288 = NOVALUE;
            goto LE; // [526] 604
        }
        DeRef(_30288);
        _30288 = NOVALUE;
    }
    DeRef(_30288);
    _30288 = NOVALUE;
LD: 

    /** parser.e:4171						if SymTab[p][S_SCOPE] = SC_OVERRIDE then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30289 = (object)*(((s1_ptr)_2)->base + _p_61172);
    _2 = (object)SEQ_PTR(_30289);
    _30290 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30289 = NOVALUE;
    if (binary_op_a(NOTEQ, _30290, 12LL)){
        _30290 = NOVALUE;
        goto LF; // [546] 558
    }
    _30290 = NOVALUE;

    /** parser.e:4172							again = 223*/
    _again_61179 = 223LL;
    goto L10; // [555] 564
LF: 

    /** parser.e:4174							again = 222*/
    _again_61179 = 222LL;
L10: 

    /** parser.e:4176						Warning(again, override_warning_flag,*/
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _30292 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30293 = (object)*(((s1_ptr)_2)->base + _p_61172);
    _2 = (object)SEQ_PTR(_30293);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _30294 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _30294 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _30293 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_30292);
    ((intptr_t*)_2)[1] = _30292;
    ((intptr_t*)_2)[2] = _36line_number_21440;
    Ref(_30294);
    ((intptr_t*)_2)[3] = _30294;
    _30295 = MAKE_SEQ(_1);
    _30294 = NOVALUE;
    _30292 = NOVALUE;
    _50Warning(_again_61179, 4LL, _30295);
    _30295 = NOVALUE;
LE: 
LC: 

    /** parser.e:4181			h = SymTab[p][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30296 = (object)*(((s1_ptr)_2)->base + _p_61172);
    _2 = (object)SEQ_PTR(_30296);
    _h_61169 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (!IS_ATOM_INT(_h_61169)){
        _h_61169 = (object)DBL_PTR(_h_61169)->dbl;
    }
    _30296 = NOVALUE;

    /** parser.e:4182			sym = buckets[h]*/
    _2 = (object)SEQ_PTR(_54buckets_46772);
    _sym_61174 = (object)*(((s1_ptr)_2)->base + _h_61169);
    if (!IS_ATOM_INT(_sym_61174)){
        _sym_61174 = (object)DBL_PTR(_sym_61174)->dbl;
    }

    /** parser.e:4183			p = NewEntry(SymTab[p][S_NAME], 0, 0, pt, h, sym, 0)*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30299 = (object)*(((s1_ptr)_2)->base + _p_61172);
    _2 = (object)SEQ_PTR(_30299);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _30300 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _30300 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _30299 = NOVALUE;
    Ref(_30300);
    _p_61172 = _54NewEntry(_30300, 0LL, 0LL, _pt_61170, _h_61169, _sym_61174, 0LL);
    _30300 = NOVALUE;
    if (!IS_ATOM_INT(_p_61172)) {
        _1 = (object)(DBL_PTR(_p_61172)->dbl);
        DeRefDS(_p_61172);
        _p_61172 = _1;
    }

    /** parser.e:4184			buckets[h] = p*/
    _2 = (object)SEQ_PTR(_54buckets_46772);
    _2 = (object)(((s1_ptr)_2)->base + _h_61169);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _p_61172;
    DeRef(_1);
LB: 

    /** parser.e:4187		Start_block( pt, p )*/
    _65Start_block(_pt_61170, _p_61172);

    /** parser.e:4189		CurrentSub = p*/
    _36CurrentSub_21447 = _p_61172;

    /** parser.e:4190		first_def_arg = 0*/
    _first_def_arg_61178 = 0LL;

    /** parser.e:4191		temps_allocated = 0*/
    _54temps_allocated_47307 = 0LL;

    /** parser.e:4193		SymTab[p][S_SCOPE] = scope*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61172 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _scope_61167;
    DeRef(_1);
    _30302 = NOVALUE;

    /** parser.e:4195		SymTab[p][S_TOKEN] = pt*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61172 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_TOKEN_21081))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _pt_61170;
    DeRef(_1);
    _30304 = NOVALUE;

    /** parser.e:4197		if length(SymTab[p]) < SIZEOF_ROUTINE_ENTRY then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30306 = (object)*(((s1_ptr)_2)->base + _p_61172);
    if (IS_SEQUENCE(_30306)){
            _30307 = SEQ_PTR(_30306)->length;
    }
    else {
        _30307 = 1;
    }
    _30306 = NOVALUE;
    if (_30307 >= _36SIZEOF_ROUTINE_ENTRY_21202)
    goto L11; // [738] 780

    /** parser.e:4199			SymTab[p] = SymTab[p] & repeat(0, SIZEOF_ROUTINE_ENTRY -*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30309 = (object)*(((s1_ptr)_2)->base + _p_61172);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30310 = (object)*(((s1_ptr)_2)->base + _p_61172);
    if (IS_SEQUENCE(_30310)){
            _30311 = SEQ_PTR(_30310)->length;
    }
    else {
        _30311 = 1;
    }
    _30310 = NOVALUE;
    _30312 = _36SIZEOF_ROUTINE_ENTRY_21202 - _30311;
    _30311 = NOVALUE;
    _30313 = Repeat(0LL, _30312);
    _30312 = NOVALUE;
    if (IS_SEQUENCE(_30309) && IS_ATOM(_30313)) {
    }
    else if (IS_ATOM(_30309) && IS_SEQUENCE(_30313)) {
        Ref(_30309);
        Prepend(&_30314, _30313, _30309);
    }
    else {
        Concat((object_ptr)&_30314, _30309, _30313);
        _30309 = NOVALUE;
    }
    _30309 = NOVALUE;
    DeRefDS(_30313);
    _30313 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _p_61172);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30314;
    if( _1 != _30314 ){
        DeRef(_1);
    }
    _30314 = NOVALUE;
L11: 

    /** parser.e:4203		SymTab[p][S_CODE] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61172 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21088))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21088);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30315 = NOVALUE;

    /** parser.e:4204		SymTab[p][S_LINETAB] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61172 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_LINETAB_21111))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21111)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21111);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30317 = NOVALUE;

    /** parser.e:4205		SymTab[p][S_EFFECT] = E_PURE*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61172 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30319 = NOVALUE;

    /** parser.e:4206		SymTab[p][S_REFLIST] = {}*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61172 + ((s1_ptr)_2)->base);
    RefDS(_21993);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 24LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _21993;
    DeRef(_1);
    _30321 = NOVALUE;

    /** parser.e:4207		SymTab[p][S_FIRSTLINE] = gline_number*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61172 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_FIRSTLINE_21116))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FIRSTLINE_21116)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_FIRSTLINE_21116);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36gline_number_21444;
    DeRef(_1);
    _30323 = NOVALUE;

    /** parser.e:4208		SymTab[p][S_TEMPS] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61172 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_TEMPS_21121))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TEMPS_21121)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_TEMPS_21121);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30325 = NOVALUE;

    /** parser.e:4209		SymTab[p][S_RESIDENT_TASK] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61172 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30327 = NOVALUE;

    /** parser.e:4210		SymTab[p][S_SAVED_PRIVATES] = {}*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61172 + ((s1_ptr)_2)->base);
    RefDS(_21993);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 26LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _21993;
    DeRef(_1);
    _30329 = NOVALUE;

    /** parser.e:4211		SymTab[p][S_DEPRECATED] = deprecated*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61172 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _deprecated_61168;
    DeRef(_1);
    _30331 = NOVALUE;

    /** parser.e:4213		if type_enum then*/
    if (_type_enum_61180 == 0)
    {
        goto L12; // [921] 978
    }
    else{
    }

    /** parser.e:4214			SymTab[p][S_FIRSTLINE] = type_enum_gline*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61172 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_FIRSTLINE_21116))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FIRSTLINE_21116)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_FIRSTLINE_21116);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _type_enum_gline_61184;
    DeRef(_1);
    _30333 = NOVALUE;

    /** parser.e:4215			real_gline = gline_number*/
    _real_gline_61185 = _36gline_number_21444;

    /** parser.e:4216			gline_number = type_enum_gline*/
    _36gline_number_21444 = _type_enum_gline_61184;

    /** parser.e:4217			StartSourceLine( FALSE, , COVERAGE_OVERRIDE )*/
    _47StartSourceLine(_13FALSE_450, 0LL, 3LL);

    /** parser.e:4218			gline_number = real_gline*/
    _36gline_number_21444 = _real_gline_61185;
    goto L13; // [975] 990
L12: 

    /** parser.e:4220			StartSourceLine(FALSE, , COVERAGE_OVERRIDE)*/
    _47StartSourceLine(_13FALSE_450, 0LL, 3LL);
L13: 

    /** parser.e:4223		tok_match(LEFT_ROUND)*/
    _45tok_match(-26LL, 0LL);

    /** parser.e:4224		tok = next_token()*/
    _0 = _tok_61176;
    _tok_61176 = _45next_token();
    DeRef(_0);

    /** parser.e:4225		param_num = 0*/
    _45param_num_54933 = 0LL;

    /** parser.e:4228		sequence middle_def_args = {}*/
    RefDS(_21993);
    DeRef(_middle_def_args_61413);
    _middle_def_args_61413 = _21993;

    /** parser.e:4229		integer last_nda = 0, start_def = 0*/
    _last_nda_61414 = 0LL;
    _start_def_61415 = 0LL;

    /** parser.e:4230		symtab_index last_link = p*/
    _last_link_61417 = _p_61172;

    /** parser.e:4231		while tok[T_ID] != RIGHT_ROUND do*/
L14: 
    _2 = (object)SEQ_PTR(_tok_61176);
    _30336 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _30336, -27LL)){
        _30336 = NOVALUE;
        goto L15; // [1043] 1830
    }
    _30336 = NOVALUE;

    /** parser.e:4234			if tok[T_ID] != TYPE and tok[T_ID] != QUALIFIED_TYPE then*/
    _2 = (object)SEQ_PTR(_tok_61176);
    _30338 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30338)) {
        _30339 = (_30338 != 504LL);
    }
    else {
        _30339 = binary_op(NOTEQ, _30338, 504LL);
    }
    _30338 = NOVALUE;
    if (IS_ATOM_INT(_30339)) {
        if (_30339 == 0) {
            goto L16; // [1061] 1291
        }
    }
    else {
        if (DBL_PTR(_30339)->dbl == 0.0) {
            goto L16; // [1061] 1291
        }
    }
    _2 = (object)SEQ_PTR(_tok_61176);
    _30341 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30341)) {
        _30342 = (_30341 != 522LL);
    }
    else {
        _30342 = binary_op(NOTEQ, _30341, 522LL);
    }
    _30341 = NOVALUE;
    if (_30342 == 0) {
        DeRef(_30342);
        _30342 = NOVALUE;
        goto L16; // [1078] 1291
    }
    else {
        if (!IS_ATOM_INT(_30342) && DBL_PTR(_30342)->dbl == 0.0){
            DeRef(_30342);
            _30342 = NOVALUE;
            goto L16; // [1078] 1291
        }
        DeRef(_30342);
        _30342 = NOVALUE;
    }
    DeRef(_30342);
    _30342 = NOVALUE;

    /** parser.e:4235				if tok[T_ID] = VARIABLE or tok[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_61176);
    _30343 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30343)) {
        _30344 = (_30343 == -100LL);
    }
    else {
        _30344 = binary_op(EQUALS, _30343, -100LL);
    }
    _30343 = NOVALUE;
    if (IS_ATOM_INT(_30344)) {
        if (_30344 != 0) {
            goto L17; // [1095] 1116
        }
    }
    else {
        if (DBL_PTR(_30344)->dbl != 0.0) {
            goto L17; // [1095] 1116
        }
    }
    _2 = (object)SEQ_PTR(_tok_61176);
    _30346 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30346)) {
        _30347 = (_30346 == 512LL);
    }
    else {
        _30347 = binary_op(EQUALS, _30346, 512LL);
    }
    _30346 = NOVALUE;
    if (_30347 == 0) {
        DeRef(_30347);
        _30347 = NOVALUE;
        goto L18; // [1112] 1280
    }
    else {
        if (!IS_ATOM_INT(_30347) && DBL_PTR(_30347)->dbl == 0.0){
            DeRef(_30347);
            _30347 = NOVALUE;
            goto L18; // [1112] 1280
        }
        DeRef(_30347);
        _30347 = NOVALUE;
    }
    DeRef(_30347);
    _30347 = NOVALUE;
L17: 

    /** parser.e:4237					token temptok = next_token()*/
    _0 = _temptok_61444;
    _temptok_61444 = _45next_token();
    DeRef(_0);

    /** parser.e:4238					integer undef_type = 0*/
    _undef_type_61446 = 0LL;

    /** parser.e:4239					if temptok[T_ID] != TYPE and temptok[T_ID] != QUALIFIED_TYPE then*/
    _2 = (object)SEQ_PTR(_temptok_61444);
    _30349 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30349)) {
        _30350 = (_30349 != 504LL);
    }
    else {
        _30350 = binary_op(NOTEQ, _30349, 504LL);
    }
    _30349 = NOVALUE;
    if (IS_ATOM_INT(_30350)) {
        if (_30350 == 0) {
            goto L19; // [1140] 1243
        }
    }
    else {
        if (DBL_PTR(_30350)->dbl == 0.0) {
            goto L19; // [1140] 1243
        }
    }
    _2 = (object)SEQ_PTR(_temptok_61444);
    _30352 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30352)) {
        _30353 = (_30352 != 522LL);
    }
    else {
        _30353 = binary_op(NOTEQ, _30352, 522LL);
    }
    _30352 = NOVALUE;
    if (_30353 == 0) {
        DeRef(_30353);
        _30353 = NOVALUE;
        goto L19; // [1157] 1243
    }
    else {
        if (!IS_ATOM_INT(_30353) && DBL_PTR(_30353)->dbl == 0.0){
            DeRef(_30353);
            _30353 = NOVALUE;
            goto L19; // [1157] 1243
        }
        DeRef(_30353);
        _30353 = NOVALUE;
    }
    DeRef(_30353);
    _30353 = NOVALUE;

    /** parser.e:4240						if find( temptok[T_ID], FULL_ID_TOKS) then*/
    _2 = (object)SEQ_PTR(_temptok_61444);
    _30354 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30355 = find_from(_30354, _38FULL_ID_TOKS_16053, 1LL);
    _30354 = NOVALUE;
    if (_30355 == 0)
    {
        _30355 = NOVALUE;
        goto L1A; // [1175] 1242
    }
    else{
        _30355 = NOVALUE;
    }

    /** parser.e:4242							if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_tok_61176);
    _30356 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_30356)){
        _30357 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30356)->dbl));
    }
    else{
        _30357 = (object)*(((s1_ptr)_2)->base + _30356);
    }
    _2 = (object)SEQ_PTR(_30357);
    _30358 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30357 = NOVALUE;
    if (binary_op_a(NOTEQ, _30358, 9LL)){
        _30358 = NOVALUE;
        goto L1B; // [1200] 1231
    }
    _30358 = NOVALUE;

    /** parser.e:4245								undef_type = - new_forward_reference( TYPE, tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_61176);
    _30360 = (object)*(((s1_ptr)_2)->base + 2LL);
    DeRef(_31673);
    _31673 = 504LL;
    Ref(_30360);
    _30361 = _44new_forward_reference(504LL, _30360, 504LL);
    _30360 = NOVALUE;
    _31673 = NOVALUE;
    if (IS_ATOM_INT(_30361)) {
        if ((uintptr_t)_30361 == (uintptr_t)HIGH_BITS){
            _undef_type_61446 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _undef_type_61446 = - _30361;
        }
    }
    else {
        _undef_type_61446 = unary_op(UMINUS, _30361);
    }
    DeRef(_30361);
    _30361 = NOVALUE;
    if (!IS_ATOM_INT(_undef_type_61446)) {
        _1 = (object)(DBL_PTR(_undef_type_61446)->dbl);
        DeRefDS(_undef_type_61446);
        _undef_type_61446 = _1;
    }
    goto L1C; // [1228] 1241
L1B: 

    /** parser.e:4247								CompileErr(A_TYPE_IS_EXPECTED_HERE)*/
    RefDS(_21993);
    _50CompileErr(37LL, _21993, 0LL);
L1C: 
L1A: 
L19: 

    /** parser.e:4251					putback(temptok) -- Return whatever came after the name back onto the token stream.*/
    Ref(_temptok_61444);
    _45putback(_temptok_61444);

    /** parser.e:4252					if undef_type != 0 then*/
    if (_undef_type_61446 == 0LL)
    goto L1D; // [1250] 1265

    /** parser.e:4254						tok[T_SYM] = undef_type*/
    _2 = (object)SEQ_PTR(_tok_61176);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_61176 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _undef_type_61446;
    DeRef(_1);
    goto L1E; // [1262] 1275
L1D: 

    /** parser.e:4256						CompileErr(A_TYPE_IS_EXPECTED_HERE)*/
    RefDS(_21993);
    _50CompileErr(37LL, _21993, 0LL);
L1E: 
    DeRef(_temptok_61444);
    _temptok_61444 = NOVALUE;
    goto L1F; // [1277] 1290
L18: 

    /** parser.e:4259					CompileErr(A_TYPE_IS_EXPECTED_HERE)*/
    RefDS(_21993);
    _50CompileErr(37LL, _21993, 0LL);
L1F: 
L16: 

    /** parser.e:4262			type_sym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_61176);
    _type_sym_61173 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_type_sym_61173)){
        _type_sym_61173 = (object)DBL_PTR(_type_sym_61173)->dbl;
    }

    /** parser.e:4263			tok = next_token()*/
    _0 = _tok_61176;
    _tok_61176 = _45next_token();
    DeRef(_0);

    /** parser.e:4264			if not find(tok[T_ID], ID_TOKS) then*/
    _2 = (object)SEQ_PTR(_tok_61176);
    _30366 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30367 = find_from(_30366, _38ID_TOKS_16051, 1LL);
    _30366 = NOVALUE;
    if (_30367 != 0)
    goto L20; // [1321] 1439
    _30367 = NOVALUE;

    /** parser.e:4265				sequence tokcat = find_category(tok[T_ID])*/
    _2 = (object)SEQ_PTR(_tok_61176);
    _30369 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_30369);
    _0 = _tokcat_61498;
    _tokcat_61498 = _63find_category(_30369);
    DeRef(_0);
    _30369 = NOVALUE;

    /** parser.e:4266				if tok[T_SYM] != 0 and length(SymTab[tok[T_SYM]]) >= S_NAME then*/
    _2 = (object)SEQ_PTR(_tok_61176);
    _30371 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_30371)) {
        _30372 = (_30371 != 0LL);
    }
    else {
        _30372 = binary_op(NOTEQ, _30371, 0LL);
    }
    _30371 = NOVALUE;
    if (IS_ATOM_INT(_30372)) {
        if (_30372 == 0) {
            goto L21; // [1350] 1413
        }
    }
    else {
        if (DBL_PTR(_30372)->dbl == 0.0) {
            goto L21; // [1350] 1413
        }
    }
    _2 = (object)SEQ_PTR(_tok_61176);
    _30374 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_30374)){
        _30375 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30374)->dbl));
    }
    else{
        _30375 = (object)*(((s1_ptr)_2)->base + _30374);
    }
    if (IS_SEQUENCE(_30375)){
            _30376 = SEQ_PTR(_30375)->length;
    }
    else {
        _30376 = 1;
    }
    _30375 = NOVALUE;
    if (IS_ATOM_INT(_36S_NAME_21076)) {
        _30377 = (_30376 >= _36S_NAME_21076);
    }
    else {
        _30377 = binary_op(GREATEREQ, _30376, _36S_NAME_21076);
    }
    _30376 = NOVALUE;
    if (_30377 == 0) {
        DeRef(_30377);
        _30377 = NOVALUE;
        goto L21; // [1376] 1413
    }
    else {
        if (!IS_ATOM_INT(_30377) && DBL_PTR(_30377)->dbl == 0.0){
            DeRef(_30377);
            _30377 = NOVALUE;
            goto L21; // [1376] 1413
        }
        DeRef(_30377);
        _30377 = NOVALUE;
    }
    DeRef(_30377);
    _30377 = NOVALUE;

    /** parser.e:4267					CompileErr(FOUND_1_2_BUT_WAS_EXPECTING_A_PARAMETER_NAME_INSTEAD, {tokcat, SymTab[tok[T_SYM]][S_NAME]})*/
    _2 = (object)SEQ_PTR(_tok_61176);
    _30378 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_30378)){
        _30379 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30378)->dbl));
    }
    else{
        _30379 = (object)*(((s1_ptr)_2)->base + _30378);
    }
    _2 = (object)SEQ_PTR(_30379);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _30380 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _30380 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _30379 = NOVALUE;
    Ref(_30380);
    RefDS(_tokcat_61498);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _tokcat_61498;
    ((intptr_t *)_2)[2] = _30380;
    _30381 = MAKE_SEQ(_1);
    _30380 = NOVALUE;
    _50CompileErr(90LL, _30381, 0LL);
    _30381 = NOVALUE;
    goto L22; // [1410] 1438
L21: 

    /** parser.e:4269					CompileErr(FOUND_1_BUT_WAS_EXPECTING_A_PARAMETER_NAME_INSTEAD, {LexName(tok[T_ID])})*/
    _2 = (object)SEQ_PTR(_tok_61176);
    _30382 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_30382);
    RefDS(_26329);
    _30383 = _47LexName(_30382, _26329);
    _30382 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30383;
    _30384 = MAKE_SEQ(_1);
    _30383 = NOVALUE;
    _50CompileErr(92LL, _30384, 0LL);
    _30384 = NOVALUE;
L22: 
L20: 
    DeRef(_tokcat_61498);
    _tokcat_61498 = NOVALUE;

    /** parser.e:4272			sym = SetPrivateScope(tok[T_SYM], type_sym, param_num)*/
    _2 = (object)SEQ_PTR(_tok_61176);
    _30385 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30385);
    _sym_61174 = _45SetPrivateScope(_30385, _type_sym_61173, _45param_num_54933);
    _30385 = NOVALUE;
    if (!IS_ATOM_INT(_sym_61174)) {
        _1 = (object)(DBL_PTR(_sym_61174)->dbl);
        DeRefDS(_sym_61174);
        _sym_61174 = _1;
    }

    /** parser.e:4273			param_num += 1*/
    _45param_num_54933 = _45param_num_54933 + 1;

    /** parser.e:4275			if SymTab[last_link][S_NEXT] != sym*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30388 = (object)*(((s1_ptr)_2)->base + _last_link_61417);
    _2 = (object)SEQ_PTR(_30388);
    _30389 = (object)*(((s1_ptr)_2)->base + 2LL);
    _30388 = NOVALUE;
    if (IS_ATOM_INT(_30389)) {
        _30390 = (_30389 != _sym_61174);
    }
    else {
        _30390 = binary_op(NOTEQ, _30389, _sym_61174);
    }
    _30389 = NOVALUE;
    if (IS_ATOM_INT(_30390)) {
        if (_30390 == 0) {
            goto L23; // [1485] 1566
        }
    }
    else {
        if (DBL_PTR(_30390)->dbl == 0.0) {
            goto L23; // [1485] 1566
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30392 = (object)*(((s1_ptr)_2)->base + _last_link_61417);
    _2 = (object)SEQ_PTR(_30392);
    _30393 = (object)*(((s1_ptr)_2)->base + 2LL);
    _30392 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_30393)){
        _30394 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30393)->dbl));
    }
    else{
        _30394 = (object)*(((s1_ptr)_2)->base + _30393);
    }
    _2 = (object)SEQ_PTR(_30394);
    _30395 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30394 = NOVALUE;
    if (IS_ATOM_INT(_30395)) {
        _30396 = (_30395 == 9LL);
    }
    else {
        _30396 = binary_op(EQUALS, _30395, 9LL);
    }
    _30395 = NOVALUE;
    if (_30396 == 0) {
        DeRef(_30396);
        _30396 = NOVALUE;
        goto L23; // [1520] 1566
    }
    else {
        if (!IS_ATOM_INT(_30396) && DBL_PTR(_30396)->dbl == 0.0){
            DeRef(_30396);
            _30396 = NOVALUE;
            goto L23; // [1520] 1566
        }
        DeRef(_30396);
        _30396 = NOVALUE;
    }
    DeRef(_30396);
    _30396 = NOVALUE;

    /** parser.e:4278				SymTab[SymTab[last_link][S_NEXT]][S_NEXT] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30397 = (object)*(((s1_ptr)_2)->base + _last_link_61417);
    _2 = (object)SEQ_PTR(_30397);
    _30398 = (object)*(((s1_ptr)_2)->base + 2LL);
    _30397 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_30398))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_30398)->dbl));
    else
    _3 = (object)(_30398 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30399 = NOVALUE;

    /** parser.e:4279				SymTab[last_link][S_NEXT] = sym*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_last_link_61417 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_61174;
    DeRef(_1);
    _30401 = NOVALUE;
L23: 

    /** parser.e:4282			last_link = sym*/
    _last_link_61417 = _sym_61174;

    /** parser.e:4284			if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L24; // [1577] 1600
    }
    else{
    }

    /** parser.e:4285				SymTab[sym][S_GTYPE] = CompileType(type_sym)*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_61174 + ((s1_ptr)_2)->base);
    _30405 = _45CompileType(_type_sym_61173);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30405;
    if( _1 != _30405 ){
        DeRef(_1);
    }
    _30405 = NOVALUE;
    _30403 = NOVALUE;
L24: 

    /** parser.e:4289			tok = next_token()*/
    _0 = _tok_61176;
    _tok_61176 = _45next_token();
    DeRef(_0);

    /** parser.e:4290			if tok[T_ID] = EQUALS then -- defaulted parameter*/
    _2 = (object)SEQ_PTR(_tok_61176);
    _30407 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30407, 3LL)){
        _30407 = NOVALUE;
        goto L25; // [1615] 1697
    }
    _30407 = NOVALUE;

    /** parser.e:4291				start_recording()*/
    _45start_recording();

    /** parser.e:4292				Expr()*/
    _45Expr();

    /** parser.e:4293				SymTab[sym][S_CODE] = restore_parser()*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_61174 + ((s1_ptr)_2)->base);
    _30411 = _45restore_parser();
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21088))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21088);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30411;
    if( _1 != _30411 ){
        DeRef(_1);
    }
    _30411 = NOVALUE;
    _30409 = NOVALUE;

    /** parser.e:4294				if Pop() then end if -- don't leak the default argument*/
    _30412 = _47Pop();
    if (_30412 == 0) {
        DeRef(_30412);
        _30412 = NOVALUE;
        goto L26; // [1650] 1654
    }
    else {
        if (!IS_ATOM_INT(_30412) && DBL_PTR(_30412)->dbl == 0.0){
            DeRef(_30412);
            _30412 = NOVALUE;
            goto L26; // [1650] 1654
        }
        DeRef(_30412);
        _30412 = NOVALUE;
    }
    DeRef(_30412);
    _30412 = NOVALUE;
L26: 

    /** parser.e:4295				tok = next_token()*/
    _0 = _tok_61176;
    _tok_61176 = _45next_token();
    DeRef(_0);

    /** parser.e:4296				if first_def_arg = 0 then*/
    if (_first_def_arg_61178 != 0LL)
    goto L27; // [1661] 1673

    /** parser.e:4297					first_def_arg = param_num*/
    _first_def_arg_61178 = _45param_num_54933;
L27: 

    /** parser.e:4299				previous_op = -1 -- no interferences betwen defparms, or them and subsequent code*/
    _36previous_op_21541 = -1LL;

    /** parser.e:4300				if start_def = 0 then*/
    if (_start_def_61415 != 0LL)
    goto L28; // [1682] 1754

    /** parser.e:4301					start_def = param_num*/
    _start_def_61415 = _45param_num_54933;
    goto L28; // [1694] 1754
L25: 

    /** parser.e:4304				last_nda = param_num*/
    _last_nda_61414 = _45param_num_54933;

    /** parser.e:4305				if start_def then*/
    if (_start_def_61415 == 0)
    {
        goto L29; // [1706] 1753
    }
    else{
    }

    /** parser.e:4306					if start_def = param_num-1 then*/
    _30416 = _45param_num_54933 - 1LL;
    if ((object)((uintptr_t)_30416 +(uintptr_t) HIGH_BITS) >= 0){
        _30416 = NewDouble((eudouble)_30416);
    }
    if (binary_op_a(NOTEQ, _start_def_61415, _30416)){
        DeRef(_30416);
        _30416 = NOVALUE;
        goto L2A; // [1717] 1730
    }
    DeRef(_30416);
    _30416 = NOVALUE;

    /** parser.e:4307						middle_def_args &= start_def*/
    Append(&_middle_def_args_61413, _middle_def_args_61413, _start_def_61415);
    goto L2B; // [1727] 1747
L2A: 

    /** parser.e:4309						middle_def_args = append(middle_def_args, {start_def, param_num-1})*/
    _30419 = _45param_num_54933 - 1LL;
    if ((object)((uintptr_t)_30419 +(uintptr_t) HIGH_BITS) >= 0){
        _30419 = NewDouble((eudouble)_30419);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _start_def_61415;
    ((intptr_t *)_2)[2] = _30419;
    _30420 = MAKE_SEQ(_1);
    _30419 = NOVALUE;
    RefDS(_30420);
    Append(&_middle_def_args_61413, _middle_def_args_61413, _30420);
    DeRefDS(_30420);
    _30420 = NOVALUE;
L2B: 

    /** parser.e:4311					start_def = 0*/
    _start_def_61415 = 0LL;
L29: 
L28: 

    /** parser.e:4314			if tok[T_ID] = COMMA then*/
    _2 = (object)SEQ_PTR(_tok_61176);
    _30422 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30422, -30LL)){
        _30422 = NOVALUE;
        goto L2C; // [1764] 1800
    }
    _30422 = NOVALUE;

    /** parser.e:4315				tok = next_token()*/
    _0 = _tok_61176;
    _tok_61176 = _45next_token();
    DeRef(_0);

    /** parser.e:4316				if tok[T_ID] = RIGHT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok_61176);
    _30425 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30425, -27LL)){
        _30425 = NOVALUE;
        goto L14; // [1783] 1035
    }
    _30425 = NOVALUE;

    /** parser.e:4317					CompileErr(EXPECTED_TO_SEE_A_PARAMETER_DECLARATION_NOT)*/
    RefDS(_21993);
    _50CompileErr(85LL, _21993, 0LL);
    goto L14; // [1797] 1035
L2C: 

    /** parser.e:4319			elsif tok[T_ID] != RIGHT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok_61176);
    _30427 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _30427, -27LL)){
        _30427 = NOVALUE;
        goto L14; // [1810] 1035
    }
    _30427 = NOVALUE;

    /** parser.e:4320				CompileErr(BADLYFORMED_LIST_OF_PARAMETERS__EXPECTED__OR)*/
    RefDS(_21993);
    _50CompileErr(41LL, _21993, 0LL);

    /** parser.e:4322		end while*/
    goto L14; // [1827] 1035
L15: 

    /** parser.e:4323		Code = {} -- removes any spurious code emitted while recording parameters*/
    RefDS(_21993);
    DeRef(_36Code_21531);
    _36Code_21531 = _21993;

    /** parser.e:4325		SymTab[p][S_NUM_ARGS] = param_num*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61172 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21127))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _45param_num_54933;
    DeRef(_1);
    _30429 = NOVALUE;

    /** parser.e:4326		SymTab[p][S_DEF_ARGS] = {first_def_arg, last_nda, middle_def_args}*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61172 + ((s1_ptr)_2)->base);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _first_def_arg_61178;
    ((intptr_t*)_2)[2] = _last_nda_61414;
    RefDS(_middle_def_args_61413);
    ((intptr_t*)_2)[3] = _middle_def_args_61413;
    _30433 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 28LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30433;
    if( _1 != _30433 ){
        DeRef(_1);
    }
    _30433 = NOVALUE;
    _30431 = NOVALUE;

    /** parser.e:4327		if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L2D; // [1879] 1913
    }
    else{
    }

    /** parser.e:4328			if param_num > max_params then*/
    if (_45param_num_54933 <= _47max_params_50938)
    goto L2E; // [1888] 1902

    /** parser.e:4329				max_params = param_num*/
    _47max_params_50938 = _45param_num_54933;
L2E: 

    /** parser.e:4331			num_routines += 1*/
    _36num_routines_21448 = _36num_routines_21448 + 1LL;
L2D: 

    /** parser.e:4333		if SymTab[p][S_TOKEN] = TYPE and param_num != 1 then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30436 = (object)*(((s1_ptr)_2)->base + _p_61172);
    _2 = (object)SEQ_PTR(_30436);
    if (!IS_ATOM_INT(_36S_TOKEN_21081)){
        _30437 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    }
    else{
        _30437 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    }
    _30436 = NOVALUE;
    if (IS_ATOM_INT(_30437)) {
        _30438 = (_30437 == 504LL);
    }
    else {
        _30438 = binary_op(EQUALS, _30437, 504LL);
    }
    _30437 = NOVALUE;
    if (IS_ATOM_INT(_30438)) {
        if (_30438 == 0) {
            goto L2F; // [1933] 1957
        }
    }
    else {
        if (DBL_PTR(_30438)->dbl == 0.0) {
            goto L2F; // [1933] 1957
        }
    }
    _30440 = (_45param_num_54933 != 1LL);
    if (_30440 == 0)
    {
        DeRef(_30440);
        _30440 = NOVALUE;
        goto L2F; // [1944] 1957
    }
    else{
        DeRef(_30440);
        _30440 = NOVALUE;
    }

    /** parser.e:4334			CompileErr(TYPES_MUST_HAVE_EXACTLY_ONE_PARAMETER)*/
    RefDS(_21993);
    _50CompileErr(148LL, _21993, 0LL);
L2F: 

    /** parser.e:4337		include_routine()*/
    _51include_routine();

    /** parser.e:4340		sym = SymTab[p][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30441 = (object)*(((s1_ptr)_2)->base + _p_61172);
    _2 = (object)SEQ_PTR(_30441);
    _sym_61174 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_sym_61174)){
        _sym_61174 = (object)DBL_PTR(_sym_61174)->dbl;
    }
    _30441 = NOVALUE;

    /** parser.e:4341		for i = 1 to SymTab[p][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30443 = (object)*(((s1_ptr)_2)->base + _p_61172);
    _2 = (object)SEQ_PTR(_30443);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
        _30444 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
    }
    else{
        _30444 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
    }
    _30443 = NOVALUE;
    {
        object _i_61657;
        _i_61657 = 1LL;
L30: 
        if (binary_op_a(GREATER, _i_61657, _30444)){
            goto L31; // [1991] 2070
        }

        /** parser.e:4342			while SymTab[sym][S_SCOPE] != SC_PRIVATE do*/
L32: 
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _30445 = (object)*(((s1_ptr)_2)->base + _sym_61174);
        _2 = (object)SEQ_PTR(_30445);
        _30446 = (object)*(((s1_ptr)_2)->base + 4LL);
        _30445 = NOVALUE;
        if (binary_op_a(EQUALS, _30446, 3LL)){
            _30446 = NOVALUE;
            goto L33; // [2017] 2042
        }
        _30446 = NOVALUE;

        /** parser.e:4343				sym = SymTab[sym][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _30448 = (object)*(((s1_ptr)_2)->base + _sym_61174);
        _2 = (object)SEQ_PTR(_30448);
        _sym_61174 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_sym_61174)){
            _sym_61174 = (object)DBL_PTR(_sym_61174)->dbl;
        }
        _30448 = NOVALUE;

        /** parser.e:4344			end while*/
        goto L32; // [2039] 2003
L33: 

        /** parser.e:4345			TypeCheck(sym)*/
        _45TypeCheck(_sym_61174);

        /** parser.e:4346			sym = SymTab[sym][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _30450 = (object)*(((s1_ptr)_2)->base + _sym_61174);
        _2 = (object)SEQ_PTR(_30450);
        _sym_61174 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_sym_61174)){
            _sym_61174 = (object)DBL_PTR(_sym_61174)->dbl;
        }
        _30450 = NOVALUE;

        /** parser.e:4347		end for*/
        _0 = _i_61657;
        if (IS_ATOM_INT(_i_61657)) {
            _i_61657 = _i_61657 + 1LL;
            if ((object)((uintptr_t)_i_61657 +(uintptr_t) HIGH_BITS) >= 0){
                _i_61657 = NewDouble((eudouble)_i_61657);
            }
        }
        else {
            _i_61657 = binary_op_a(PLUS, _i_61657, 1LL);
        }
        DeRef(_0);
        goto L30; // [2065] 1998
L31: 
        ;
        DeRef(_i_61657);
    }

    /** parser.e:4352		tok = next_token()*/
    _0 = _tok_61176;
    _tok_61176 = _45next_token();
    DeRef(_0);

    /** parser.e:4353		while tok[T_ID] = TYPE or tok[T_ID] = QUALIFIED_TYPE do*/
L34: 
    _2 = (object)SEQ_PTR(_tok_61176);
    _30453 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30453)) {
        _30454 = (_30453 == 504LL);
    }
    else {
        _30454 = binary_op(EQUALS, _30453, 504LL);
    }
    _30453 = NOVALUE;
    if (IS_ATOM_INT(_30454)) {
        if (_30454 != 0) {
            goto L35; // [2092] 2113
        }
    }
    else {
        if (DBL_PTR(_30454)->dbl != 0.0) {
            goto L35; // [2092] 2113
        }
    }
    _2 = (object)SEQ_PTR(_tok_61176);
    _30456 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30456)) {
        _30457 = (_30456 == 522LL);
    }
    else {
        _30457 = binary_op(EQUALS, _30456, 522LL);
    }
    _30456 = NOVALUE;
    if (_30457 <= 0) {
        if (_30457 == 0) {
            DeRef(_30457);
            _30457 = NOVALUE;
            goto L36; // [2109] 2134
        }
        else {
            if (!IS_ATOM_INT(_30457) && DBL_PTR(_30457)->dbl == 0.0){
                DeRef(_30457);
                _30457 = NOVALUE;
                goto L36; // [2109] 2134
            }
            DeRef(_30457);
            _30457 = NOVALUE;
        }
    }
    DeRef(_30457);
    _30457 = NOVALUE;
L35: 

    /** parser.e:4354			Private_declaration(tok[T_SYM])*/
    _2 = (object)SEQ_PTR(_tok_61176);
    _30458 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30458);
    _45Private_declaration(_30458);
    _30458 = NOVALUE;

    /** parser.e:4355			tok = next_token()*/
    _0 = _tok_61176;
    _tok_61176 = _45next_token();
    DeRef(_0);

    /** parser.e:4356		end while*/
    goto L34; // [2131] 2080
L36: 

    /** parser.e:4358		if not TRANSLATE then*/
    if (_36TRANSLATE_21041 != 0)
    goto L37; // [2138] 2241

    /** parser.e:4359			if OpTrace then*/
    if (_36OpTrace_21512 == 0)
    {
        goto L38; // [2145] 2240
    }
    else{
    }

    /** parser.e:4361				emit_op(ERASE_PRIVATE_NAMES)*/
    _47emit_op(88LL);

    /** parser.e:4362				emit_addr(p)*/
    _47emit_addr(_p_61172);

    /** parser.e:4364				sym = SymTab[p][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30461 = (object)*(((s1_ptr)_2)->base + _p_61172);
    _2 = (object)SEQ_PTR(_30461);
    _sym_61174 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_sym_61174)){
        _sym_61174 = (object)DBL_PTR(_sym_61174)->dbl;
    }
    _30461 = NOVALUE;

    /** parser.e:4365				for i = 1 to SymTab[p][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _30463 = (object)*(((s1_ptr)_2)->base + _p_61172);
    _2 = (object)SEQ_PTR(_30463);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
        _30464 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
    }
    else{
        _30464 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
    }
    _30463 = NOVALUE;
    {
        object _i_61704;
        _i_61704 = 1LL;
L39: 
        if (binary_op_a(GREATER, _i_61704, _30464)){
            goto L3A; // [2190] 2232
        }

        /** parser.e:4366					emit_op(DISPLAY_VAR)*/
        _47emit_op(87LL);

        /** parser.e:4367					emit_addr(sym)*/
        _47emit_addr(_sym_61174);

        /** parser.e:4368					sym = SymTab[sym][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _30465 = (object)*(((s1_ptr)_2)->base + _sym_61174);
        _2 = (object)SEQ_PTR(_30465);
        _sym_61174 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_sym_61174)){
            _sym_61174 = (object)DBL_PTR(_sym_61174)->dbl;
        }
        _30465 = NOVALUE;

        /** parser.e:4369				end for*/
        _0 = _i_61704;
        if (IS_ATOM_INT(_i_61704)) {
            _i_61704 = _i_61704 + 1LL;
            if ((object)((uintptr_t)_i_61704 +(uintptr_t) HIGH_BITS) >= 0){
                _i_61704 = NewDouble((eudouble)_i_61704);
            }
        }
        else {
            _i_61704 = binary_op_a(PLUS, _i_61704, 1LL);
        }
        DeRef(_0);
        goto L39; // [2227] 2197
L3A: 
        ;
        DeRef(_i_61704);
    }

    /** parser.e:4371				emit_op(UPDATE_GLOBALS)*/
    _47emit_op(89LL);
L38: 
L37: 

    /** parser.e:4374		putback(tok)*/
    Ref(_tok_61176);
    _45putback(_tok_61176);

    /** parser.e:4377		FuncReturn = FALSE*/
    _45FuncReturn_54932 = _13FALSE_450;

    /** parser.e:4378		if type_enum then*/
    if (_type_enum_61180 == 0)
    {
        goto L3B; // [2257] 2426
    }
    else{
    }

    /** parser.e:4380			stmt_nest += 1*/
    _45stmt_nest_54956 = _45stmt_nest_54956 + 1;

    /** parser.e:4381			tok_match(RETURN)*/
    _45tok_match(413LL, 0LL);

    /** parser.e:4382			putback({RIGHT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -27LL;
    ((intptr_t *)_2)[2] = 0LL;
    _30468 = MAKE_SEQ(_1);
    _45putback(_30468);
    _30468 = NOVALUE;

    /** parser.e:4383			putback({VARIABLE,seq_sym})*/
    Ref(_seq_sym_61181);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100LL;
    ((intptr_t *)_2)[2] = _seq_sym_61181;
    _30469 = MAKE_SEQ(_1);
    _45putback(_30469);
    _30469 = NOVALUE;

    /** parser.e:4384			putback({COMMA,0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -30LL;
    ((intptr_t *)_2)[2] = 0LL;
    _30470 = MAKE_SEQ(_1);
    _45putback(_30470);
    _30470 = NOVALUE;

    /** parser.e:4385			putback(i1_sym)*/
    Ref(_i1_sym_61182);
    _45putback(_i1_sym_61182);

    /** parser.e:4386			putback({LEFT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -26LL;
    ((intptr_t *)_2)[2] = 0LL;
    _30471 = MAKE_SEQ(_1);
    _45putback(_30471);
    _30471 = NOVALUE;

    /** parser.e:4387			putback(keyfind("find",-1))*/
    RefDS(_30472);
    DeRef(_31671);
    _31671 = _30472;
    _31672 = _54hashfn(_31671);
    _31671 = NOVALUE;
    RefDS(_30472);
    _30473 = _54keyfind(_30472, -1LL, _36current_file_no_21439, 0LL, _31672);
    _31672 = NOVALUE;
    _45putback(_30473);
    _30473 = NOVALUE;

    /** parser.e:4388			if not TRANSLATE then*/
    if (_36TRANSLATE_21041 != 0)
    goto L3C; // [2355] 2381

    /** parser.e:4389				if OpTrace then*/
    if (_36OpTrace_21512 == 0)
    {
        goto L3D; // [2362] 2380
    }
    else{
    }

    /** parser.e:4390					emit_op(ERASE_PRIVATE_NAMES)*/
    _47emit_op(88LL);

    /** parser.e:4391					emit_addr(CurrentSub)*/
    _47emit_addr(_36CurrentSub_21447);
L3D: 
L3C: 

    /** parser.e:4394			Expr()*/
    _45Expr();

    /** parser.e:4395			FuncReturn = TRUE*/
    _45FuncReturn_54932 = _13TRUE_452;

    /** parser.e:4396			emit_op(RETURNF)*/
    _47emit_op(28LL);

    /** parser.e:4397			flush_temps()*/
    RefDS(_21993);
    _47flush_temps(_21993);

    /** parser.e:4398			stmt_nest -= 1*/
    _45stmt_nest_54956 = _45stmt_nest_54956 - 1LL;

    /** parser.e:4399			InitDelete()*/
    _45InitDelete();

    /** parser.e:4400			flush_temps()*/
    RefDS(_21993);
    _47flush_temps(_21993);
    goto L3E; // [2423] 2439
L3B: 

    /** parser.e:4402			Statement_list()*/
    _45Statement_list();

    /** parser.e:4404			tok_match(END)*/
    _45tok_match(402LL, 0LL);
L3E: 

    /** parser.e:4408		tok_match(prog_type, END)*/
    _45tok_match(_prog_type_61166, 402LL);

    /** parser.e:4410		if prog_type != PROCEDURE then*/
    if (_prog_type_61166 == 405LL)
    goto L3F; // [2451] 2503

    /** parser.e:4411			if not FuncReturn then*/
    if (_45FuncReturn_54932 != 0)
    goto L40; // [2459] 2493

    /** parser.e:4412				if prog_type = FUNCTION then*/
    if (_prog_type_61166 != 406LL)
    goto L41; // [2466] 2482

    /** parser.e:4413					CompileErr(NO_VALUE_RETURNED_FROM_FUNCTION)*/
    RefDS(_21993);
    _50CompileErr(120LL, _21993, 0LL);
    goto L42; // [2479] 2492
L41: 

    /** parser.e:4415					CompileErr(TYPE_MUST_RETURN_TRUE__FALSE_VALUE)*/
    RefDS(_21993);
    _50CompileErr(149LL, _21993, 0LL);
L42: 
L40: 

    /** parser.e:4418			emit_op(BADRETURNF) -- function/type shouldn't reach here*/
    _47emit_op(43LL);
    goto L43; // [2500] 2563
L3F: 

    /** parser.e:4421			StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:4422			if not TRANSLATE then*/
    if (_36TRANSLATE_21041 != 0)
    goto L44; // [2516] 2540

    /** parser.e:4423				if OpTrace then*/
    if (_36OpTrace_21512 == 0)
    {
        goto L45; // [2523] 2539
    }
    else{
    }

    /** parser.e:4424					emit_op(ERASE_PRIVATE_NAMES)*/
    _47emit_op(88LL);

    /** parser.e:4425					emit_addr(p)*/
    _47emit_addr(_p_61172);
L45: 
L44: 

    /** parser.e:4428			emit_op(RETURNP)*/
    _47emit_op(29LL);

    /** parser.e:4429			if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L46; // [2551] 2562
    }
    else{
    }

    /** parser.e:4430				emit_op(BADRETURNF) -- just to mark end of procedure*/
    _47emit_op(43LL);
L46: 
L43: 

    /** parser.e:4433		Drop_block( pt )*/
    _65Drop_block(_pt_61170);

    /** parser.e:4435		if Strict_Override > 0 then*/
    if (_36Strict_Override_21509 <= 0LL)
    goto L47; // [2572] 2587

    /** parser.e:4436			Strict_Override -= 1	-- Reset at the end of each routine.*/
    _36Strict_Override_21509 = _36Strict_Override_21509 - 1LL;
L47: 

    /** parser.e:4439		SymTab[p][S_STACK_SPACE] += temps_allocated + param_num*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61172 + ((s1_ptr)_2)->base);
    _30484 = _54temps_allocated_47307 + _45param_num_54933;
    if ((object)((uintptr_t)_30484 + (uintptr_t)HIGH_BITS) >= 0){
        _30484 = NewDouble((eudouble)_30484);
    }
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21136)){
        _30485 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21136)->dbl));
    }
    else{
        _30485 = (object)*(((s1_ptr)_2)->base + _36S_STACK_SPACE_21136);
    }
    _30482 = NOVALUE;
    if (IS_ATOM_INT(_30485) && IS_ATOM_INT(_30484)) {
        _30486 = _30485 + _30484;
        if ((object)((uintptr_t)_30486 + (uintptr_t)HIGH_BITS) >= 0){
            _30486 = NewDouble((eudouble)_30486);
        }
    }
    else {
        _30486 = binary_op(PLUS, _30485, _30484);
    }
    _30485 = NOVALUE;
    DeRef(_30484);
    _30484 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21136))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21136)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_STACK_SPACE_21136);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30486;
    if( _1 != _30486 ){
        DeRef(_1);
    }
    _30486 = NOVALUE;
    _30482 = NOVALUE;

    /** parser.e:4440		if temps_allocated + param_num > max_stack_per_call then*/
    _30487 = _54temps_allocated_47307 + _45param_num_54933;
    if ((object)((uintptr_t)_30487 + (uintptr_t)HIGH_BITS) >= 0){
        _30487 = NewDouble((eudouble)_30487);
    }
    if (binary_op_a(LESSEQ, _30487, _36max_stack_per_call_21542)){
        DeRef(_30487);
        _30487 = NOVALUE;
        goto L48; // [2630] 2647
    }
    DeRef(_30487);
    _30487 = NOVALUE;

    /** parser.e:4441			max_stack_per_call = temps_allocated + param_num*/
    _36max_stack_per_call_21542 = _54temps_allocated_47307 + _45param_num_54933;
L48: 

    /** parser.e:4443		param_num = -1*/
    _45param_num_54933 = -1LL;

    /** parser.e:4445		StraightenBranches()*/
    _45StraightenBranches();

    /** parser.e:4446		check_inline( p )*/
    _67check_inline(_p_61172);

    /** parser.e:4447		param_num = -1*/
    _45param_num_54933 = -1LL;

    /** parser.e:4448		EnterTopLevel()*/
    _45EnterTopLevel(1LL);

    /** parser.e:4451		if length( enum_syms ) then*/
    if (IS_SEQUENCE(_enum_syms_61183)){
            _30490 = SEQ_PTR(_enum_syms_61183)->length;
    }
    else {
        _30490 = 1;
    }
    if (_30490 == 0)
    {
        _30490 = NOVALUE;
        goto L49; // [2676] 2763
    }
    else{
        _30490 = NOVALUE;
    }

    /** parser.e:4452			SymTab[p][S_NEXT] = SymTab[enum_syms[$]][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61172 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_enum_syms_61183)){
            _30493 = SEQ_PTR(_enum_syms_61183)->length;
    }
    else {
        _30493 = 1;
    }
    _2 = (object)SEQ_PTR(_enum_syms_61183);
    _30494 = (object)*(((s1_ptr)_2)->base + _30493);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_30494)){
        _30495 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30494)->dbl));
    }
    else{
        _30495 = (object)*(((s1_ptr)_2)->base + _30494);
    }
    _2 = (object)SEQ_PTR(_30495);
    _30496 = (object)*(((s1_ptr)_2)->base + 2LL);
    _30495 = NOVALUE;
    Ref(_30496);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30496;
    if( _1 != _30496 ){
        DeRef(_1);
    }
    _30496 = NOVALUE;
    _30491 = NOVALUE;

    /** parser.e:4453			SymTab[last_sym][S_NEXT] = enum_syms[1]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_54last_sym_46785 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_enum_syms_61183);
    _30499 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_30499);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30499;
    if( _1 != _30499 ){
        DeRef(_1);
    }
    _30499 = NOVALUE;
    _30497 = NOVALUE;

    /** parser.e:4454			last_sym = enum_syms[$]*/
    if (IS_SEQUENCE(_enum_syms_61183)){
            _30500 = SEQ_PTR(_enum_syms_61183)->length;
    }
    else {
        _30500 = 1;
    }
    _2 = (object)SEQ_PTR(_enum_syms_61183);
    _54last_sym_46785 = (object)*(((s1_ptr)_2)->base + _30500);
    if (!IS_ATOM_INT(_54last_sym_46785)){
        _54last_sym_46785 = (object)DBL_PTR(_54last_sym_46785)->dbl;
    }

    /** parser.e:4455			SymTab[last_sym][S_NEXT] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_54last_sym_46785 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _30502 = NOVALUE;
L49: 

    /** parser.e:4457	end procedure*/
    DeRef(_tok_61176);
    DeRef(_prog_name_61177);
    DeRef(_seq_sym_61181);
    DeRef(_i1_sym_61182);
    DeRef(_enum_syms_61183);
    DeRef(_middle_def_args_61413);
    DeRef(_30284);
    _30284 = NOVALUE;
    DeRef(_30372);
    _30372 = NOVALUE;
    _30306 = NOVALUE;
    _30374 = NOVALUE;
    DeRef(_30438);
    _30438 = NOVALUE;
    _30444 = NOVALUE;
    DeRef(_30344);
    _30344 = NOVALUE;
    _30398 = NOVALUE;
    _30356 = NOVALUE;
    _30393 = NOVALUE;
    _30310 = NOVALUE;
    DeRef(_30390);
    _30390 = NOVALUE;
    _30494 = NOVALUE;
    DeRef(_30350);
    _30350 = NOVALUE;
    DeRef(_30454);
    _30454 = NOVALUE;
    DeRef(_30339);
    _30339 = NOVALUE;
    _30375 = NOVALUE;
    _30378 = NOVALUE;
    _30464 = NOVALUE;
    return;
    ;
}


void _45InitGlobals()
{
    object _30521 = NOVALUE;
    object _30519 = NOVALUE;
    object _30518 = NOVALUE;
    object _30517 = NOVALUE;
    object _30516 = NOVALUE;
    object _30515 = NOVALUE;
    object _30514 = NOVALUE;
    object _30512 = NOVALUE;
    object _30511 = NOVALUE;
    object _30510 = NOVALUE;
    object _30509 = NOVALUE;
    object _30507 = NOVALUE;
    object _30506 = NOVALUE;
    object _30505 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:4461		ResetTP()*/
    _62ResetTP();

    /** parser.e:4462		OpTypeCheck = TRUE*/
    _36OpTypeCheck_21513 = _13TRUE_452;

    /** parser.e:4464		OpDefines &= {*/
    _30505 = _33version_major();
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30505;
    _30506 = MAKE_SEQ(_1);
    _30505 = NOVALUE;
    _30507 = EPrintf(-9999999, _30504, _30506);
    DeRefDS(_30506);
    _30506 = NOVALUE;
    _30509 = _33version_major();
    _30510 = _33version_minor();
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _30509;
    ((intptr_t *)_2)[2] = _30510;
    _30511 = MAKE_SEQ(_1);
    _30510 = NOVALUE;
    _30509 = NOVALUE;
    _30512 = EPrintf(-9999999, _30508, _30511);
    DeRefDS(_30511);
    _30511 = NOVALUE;
    _30514 = _33version_major();
    _30515 = _33version_minor();
    _30516 = _33version_patch();
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30514;
    ((intptr_t*)_2)[2] = _30515;
    ((intptr_t*)_2)[3] = _30516;
    _30517 = MAKE_SEQ(_1);
    _30516 = NOVALUE;
    _30515 = NOVALUE;
    _30514 = NOVALUE;
    _30518 = EPrintf(-9999999, _30513, _30517);
    DeRefDS(_30517);
    _30517 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30507;
    ((intptr_t*)_2)[2] = _30512;
    ((intptr_t*)_2)[3] = _30518;
    _30519 = MAKE_SEQ(_1);
    _30518 = NOVALUE;
    _30512 = NOVALUE;
    _30507 = NOVALUE;
    Concat((object_ptr)&_36OpDefines_21516, _36OpDefines_21516, _30519);
    DeRefDS(_30519);
    _30519 = NOVALUE;

    /** parser.e:4470		OpDefines &= GetPlatformDefines()*/
    _30521 = _46GetPlatformDefines(0LL);
    if (IS_SEQUENCE(_36OpDefines_21516) && IS_ATOM(_30521)) {
        Ref(_30521);
        Append(&_36OpDefines_21516, _36OpDefines_21516, _30521);
    }
    else if (IS_ATOM(_36OpDefines_21516) && IS_SEQUENCE(_30521)) {
    }
    else {
        Concat((object_ptr)&_36OpDefines_21516, _36OpDefines_21516, _30521);
    }
    DeRef(_30521);
    _30521 = NOVALUE;

    /** parser.e:4472		if repl then*/

    /** parser.e:4476			OpInline = DEFAULT_INLINE*/
    _36OpInline_21517 = 30LL;

    /** parser.e:4478		OpIndirectInclude = 1*/
    _36OpIndirectInclude_21518 = 1LL;

    /** parser.e:4479	end procedure*/
    return;
    ;
}


void _45not_supported_compile(object _feature_61874)
{
    object _30523 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:4483		CompileErr(MSG_1_IS_NOT_SUPPORTED_IN_EUPHORIA_FOR_2, {feature, version_name})*/
    RefDS(_36version_name_21055);
    RefDS(_feature_61874);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _feature_61874;
    ((intptr_t *)_2)[2] = _36version_name_21055;
    _30523 = MAKE_SEQ(_1);
    _50CompileErr(5LL, _30523, 0LL);
    _30523 = NOVALUE;

    /** parser.e:4484	end procedure*/
    DeRefDSi(_feature_61874);
    return;
    ;
}


void _45SetWith(object _on_off_61881)
{
    object _option_61882 = NOVALUE;
    object _idx_61883 = NOVALUE;
    object _reset_flags_61884 = NOVALUE;
    object _tok_61936 = NOVALUE;
    object _good_sofar_61986 = NOVALUE;
    object _tok_61989 = NOVALUE;
    object _warning_extra_61991 = NOVALUE;
    object _endlist_62084 = NOVALUE;
    object _tok_62233 = NOVALUE;
    object _30670 = NOVALUE;
    object _30669 = NOVALUE;
    object _30668 = NOVALUE;
    object _30667 = NOVALUE;
    object _30666 = NOVALUE;
    object _30663 = NOVALUE;
    object _30662 = NOVALUE;
    object _30661 = NOVALUE;
    object _30659 = NOVALUE;
    object _30657 = NOVALUE;
    object _30656 = NOVALUE;
    object _30655 = NOVALUE;
    object _30652 = NOVALUE;
    object _30650 = NOVALUE;
    object _30649 = NOVALUE;
    object _30648 = NOVALUE;
    object _30647 = NOVALUE;
    object _30646 = NOVALUE;
    object _30642 = NOVALUE;
    object _30640 = NOVALUE;
    object _30638 = NOVALUE;
    object _30634 = NOVALUE;
    object _30629 = NOVALUE;
    object _30628 = NOVALUE;
    object _30623 = NOVALUE;
    object _30622 = NOVALUE;
    object _30621 = NOVALUE;
    object _30620 = NOVALUE;
    object _30619 = NOVALUE;
    object _30618 = NOVALUE;
    object _30617 = NOVALUE;
    object _30616 = NOVALUE;
    object _30615 = NOVALUE;
    object _30614 = NOVALUE;
    object _30612 = NOVALUE;
    object _30611 = NOVALUE;
    object _30609 = NOVALUE;
    object _30608 = NOVALUE;
    object _30607 = NOVALUE;
    object _30605 = NOVALUE;
    object _30604 = NOVALUE;
    object _30602 = NOVALUE;
    object _30599 = NOVALUE;
    object _30597 = NOVALUE;
    object _30594 = NOVALUE;
    object _30593 = NOVALUE;
    object _30592 = NOVALUE;
    object _30591 = NOVALUE;
    object _30584 = NOVALUE;
    object _30583 = NOVALUE;
    object _30581 = NOVALUE;
    object _30578 = NOVALUE;
    object _30577 = NOVALUE;
    object _30575 = NOVALUE;
    object _30574 = NOVALUE;
    object _30573 = NOVALUE;
    object _30572 = NOVALUE;
    object _30571 = NOVALUE;
    object _30570 = NOVALUE;
    object _30567 = NOVALUE;
    object _30566 = NOVALUE;
    object _30565 = NOVALUE;
    object _30564 = NOVALUE;
    object _30563 = NOVALUE;
    object _30562 = NOVALUE;
    object _30559 = NOVALUE;
    object _30558 = NOVALUE;
    object _30557 = NOVALUE;
    object _30555 = NOVALUE;
    object _30552 = NOVALUE;
    object _30550 = NOVALUE;
    object _30549 = NOVALUE;
    object _30547 = NOVALUE;
    object _30546 = NOVALUE;
    object _30545 = NOVALUE;
    object _30544 = NOVALUE;
    object _30543 = NOVALUE;
    object _30542 = NOVALUE;
    object _30540 = NOVALUE;
    object _30537 = NOVALUE;
    object _30536 = NOVALUE;
    object _30535 = NOVALUE;
    object _30534 = NOVALUE;
    object _30532 = NOVALUE;
    object _30531 = NOVALUE;
    object _30530 = NOVALUE;
    object _30529 = NOVALUE;
    object _30527 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:4490		integer reset_flags = 1*/
    _reset_flags_61884 = 1LL;

    /** parser.e:4493		option = StringToken("&+=")*/
    RefDS(_30524);
    _0 = _option_61882;
    _option_61882 = _62StringToken(_30524);
    DeRef(_0);

    /** parser.e:4495		if equal(option, "type_check") then*/
    if (_option_61882 == _30526)
    _30527 = 1;
    else if (IS_ATOM_INT(_option_61882) && IS_ATOM_INT(_30526))
    _30527 = 0;
    else
    _30527 = (compare(_option_61882, _30526) == 0);
    if (_30527 == 0)
    {
        _30527 = NOVALUE;
        goto L1; // [22] 35
    }
    else{
        _30527 = NOVALUE;
    }

    /** parser.e:4496			OpTypeCheck = on_off*/
    _36OpTypeCheck_21513 = _on_off_61881;
    goto L2; // [32] 1546
L1: 

    /** parser.e:4498		elsif equal(option, "profile") then*/
    if (_option_61882 == _30528)
    _30529 = 1;
    else if (IS_ATOM_INT(_option_61882) && IS_ATOM_INT(_30528))
    _30529 = 0;
    else
    _30529 = (compare(_option_61882, _30528) == 0);
    if (_30529 == 0)
    {
        _30529 = NOVALUE;
        goto L3; // [41] 121
    }
    else{
        _30529 = NOVALUE;
    }

    /** parser.e:4499			if not TRANSLATE and not BIND then*/
    _30530 = (_36TRANSLATE_21041 == 0);
    if (_30530 == 0) {
        goto L2; // [51] 1546
    }
    _30532 = (_36BIND_21044 == 0);
    if (_30532 == 0)
    {
        DeRef(_30532);
        _30532 = NOVALUE;
        goto L2; // [61] 1546
    }
    else{
        DeRef(_30532);
        _30532 = NOVALUE;
    }

    /** parser.e:4500				OpProfileStatement = on_off*/
    _36OpProfileStatement_21514 = _on_off_61881;

    /** parser.e:4501				if OpProfileStatement then*/
    if (_36OpProfileStatement_21514 == 0)
    {
        goto L2; // [75] 1546
    }
    else{
    }

    /** parser.e:4502					if AnyTimeProfile then*/
    if (_37AnyTimeProfile_15428 == 0)
    {
        goto L4; // [82] 106
    }
    else{
    }

    /** parser.e:4503						Warning(224, mixed_profile_warning_flag)*/
    RefDS(_21993);
    _50Warning(224LL, 1024LL, _21993);

    /** parser.e:4504						OpProfileStatement = FALSE*/
    _36OpProfileStatement_21514 = _13FALSE_450;
    goto L2; // [103] 1546
L4: 

    /** parser.e:4506						AnyStatementProfile = TRUE*/
    _37AnyStatementProfile_15429 = _13TRUE_452;
    goto L2; // [118] 1546
L3: 

    /** parser.e:4511		elsif equal(option, "profile_time") then*/
    if (_option_61882 == _30533)
    _30534 = 1;
    else if (IS_ATOM_INT(_option_61882) && IS_ATOM_INT(_30533))
    _30534 = 0;
    else
    _30534 = (compare(_option_61882, _30533) == 0);
    if (_30534 == 0)
    {
        _30534 = NOVALUE;
        goto L5; // [127] 364
    }
    else{
        _30534 = NOVALUE;
    }

    /** parser.e:4512			if not TRANSLATE and not BIND then*/
    _30535 = (_36TRANSLATE_21041 == 0);
    if (_30535 == 0) {
        goto L2; // [137] 1546
    }
    _30537 = (_36BIND_21044 == 0);
    if (_30537 == 0)
    {
        DeRef(_30537);
        _30537 = NOVALUE;
        goto L2; // [147] 1546
    }
    else{
        DeRef(_30537);
        _30537 = NOVALUE;
    }

    /** parser.e:4513				if not IWINDOWS then*/
    if (_46IWINDOWS_21585 != 0)
    goto L6; // [154] 169

    /** parser.e:4514					if on_off then*/
    if (_on_off_61881 == 0)
    {
        goto L7; // [159] 168
    }
    else{
    }

    /** parser.e:4515						not_supported_compile("profile_time")*/
    RefDS(_30533);
    _45not_supported_compile(_30533);
L7: 
L6: 

    /** parser.e:4518				OpProfileTime = on_off*/
    _36OpProfileTime_21515 = _on_off_61881;

    /** parser.e:4519				if OpProfileTime then*/
    if (_36OpProfileTime_21515 == 0)
    {
        goto L8; // [180] 358
    }
    else{
    }

    /** parser.e:4520					if AnyStatementProfile then*/
    if (_37AnyStatementProfile_15429 == 0)
    {
        goto L9; // [187] 209
    }
    else{
    }

    /** parser.e:4521						Warning(224,mixed_profile_warning_flag)*/
    RefDS(_21993);
    _50Warning(224LL, 1024LL, _21993);

    /** parser.e:4522						OpProfileTime = FALSE*/
    _36OpProfileTime_21515 = _13FALSE_450;
L9: 

    /** parser.e:4524					token tok = next_token()*/
    _0 = _tok_61936;
    _tok_61936 = _45next_token();
    DeRef(_0);

    /** parser.e:4525					if tok[T_ID] = ATOM then*/
    _2 = (object)SEQ_PTR(_tok_61936);
    _30540 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30540, 502LL)){
        _30540 = NOVALUE;
        goto LA; // [224] 319
    }
    _30540 = NOVALUE;

    /** parser.e:4526						if is_integer(SymTab[tok[T_SYM]][S_OBJ]) then*/
    _2 = (object)SEQ_PTR(_tok_61936);
    _30542 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_30542)){
        _30543 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30542)->dbl));
    }
    else{
        _30543 = (object)*(((s1_ptr)_2)->base + _30542);
    }
    _2 = (object)SEQ_PTR(_30543);
    _30544 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30543 = NOVALUE;
    Ref(_30544);
    _30545 = _36is_integer(_30544);
    _30544 = NOVALUE;
    if (_30545 == 0) {
        DeRef(_30545);
        _30545 = NOVALUE;
        goto LB; // [252] 280
    }
    else {
        if (!IS_ATOM_INT(_30545) && DBL_PTR(_30545)->dbl == 0.0){
            DeRef(_30545);
            _30545 = NOVALUE;
            goto LB; // [252] 280
        }
        DeRef(_30545);
        _30545 = NOVALUE;
    }
    DeRef(_30545);
    _30545 = NOVALUE;

    /** parser.e:4527							sample_size = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_tok_61936);
    _30546 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_30546)){
        _30547 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30546)->dbl));
    }
    else{
        _30547 = (object)*(((s1_ptr)_2)->base + _30546);
    }
    _2 = (object)SEQ_PTR(_30547);
    _36sample_size_21543 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_36sample_size_21543)){
        _36sample_size_21543 = (object)DBL_PTR(_36sample_size_21543)->dbl;
    }
    _30547 = NOVALUE;
    goto LC; // [277] 288
LB: 

    /** parser.e:4529							sample_size = -1*/
    _36sample_size_21543 = -1LL;
LC: 

    /** parser.e:4531						if sample_size < 1 and OpProfileTime then*/
    _30549 = (_36sample_size_21543 < 1LL);
    if (_30549 == 0) {
        goto LD; // [296] 332
    }
    if (_36OpProfileTime_21515 == 0)
    {
        goto LD; // [303] 332
    }
    else{
    }

    /** parser.e:4532							CompileErr(SAMPLE_SIZE_MUST_BE_A_POSITIVE_INTEGER)*/
    RefDS(_21993);
    _50CompileErr(136LL, _21993, 0LL);
    goto LD; // [316] 332
LA: 

    /** parser.e:4535						putback(tok)*/
    Ref(_tok_61936);
    _45putback(_tok_61936);

    /** parser.e:4536						sample_size = DEFAULT_SAMPLE_SIZE*/
    _36sample_size_21543 = 25000LL;
LD: 

    /** parser.e:4538					if OpProfileTime then*/
    if (_36OpProfileTime_21515 == 0)
    {
        goto LE; // [336] 357
    }
    else{
    }

    /** parser.e:4539						if IWINDOWS then*/
    if (_46IWINDOWS_21585 == 0)
    {
        goto LF; // [343] 356
    }
    else{
    }

    /** parser.e:4540							AnyTimeProfile = TRUE*/
    _37AnyTimeProfile_15428 = _13TRUE_452;
LF: 
LE: 
L8: 
    DeRef(_tok_61936);
    _tok_61936 = NOVALUE;
    goto L2; // [361] 1546
L5: 

    /** parser.e:4546		elsif equal(option, "trace") then*/
    if (_option_61882 == _30551)
    _30552 = 1;
    else if (IS_ATOM_INT(_option_61882) && IS_ATOM_INT(_30551))
    _30552 = 0;
    else
    _30552 = (compare(_option_61882, _30551) == 0);
    if (_30552 == 0)
    {
        _30552 = NOVALUE;
        goto L10; // [370] 391
    }
    else{
        _30552 = NOVALUE;
    }

    /** parser.e:4547			if not BIND then*/
    if (_36BIND_21044 != 0)
    goto L2; // [377] 1546

    /** parser.e:4548				OpTrace = on_off*/
    _36OpTrace_21512 = _on_off_61881;
    goto L2; // [388] 1546
L10: 

    /** parser.e:4551		elsif equal(option, "warning") then*/
    if (_option_61882 == _30554)
    _30555 = 1;
    else if (IS_ATOM_INT(_option_61882) && IS_ATOM_INT(_30554))
    _30555 = 0;
    else
    _30555 = (compare(_option_61882, _30554) == 0);
    if (_30555 == 0)
    {
        _30555 = NOVALUE;
        goto L11; // [397] 1243
    }
    else{
        _30555 = NOVALUE;
    }

    /** parser.e:4552			integer good_sofar = line_number*/
    _good_sofar_61986 = _36line_number_21440;

    /** parser.e:4553			reset_flags = 1*/
    _reset_flags_61884 = 1LL;

    /** parser.e:4554			token tok = next_token()*/
    _0 = _tok_61989;
    _tok_61989 = _45next_token();
    DeRef(_0);

    /** parser.e:4555			integer warning_extra = 1*/
    _warning_extra_61991 = 1LL;

    /** parser.e:4556			if find(tok[T_ID], {CONCAT_EQUALS, PLUS_EQUALS}) != 0 then*/
    _2 = (object)SEQ_PTR(_tok_61989);
    _30557 = (object)*(((s1_ptr)_2)->base + 1LL);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 519LL;
    ((intptr_t *)_2)[2] = 515LL;
    _30558 = MAKE_SEQ(_1);
    _30559 = find_from(_30557, _30558, 1LL);
    _30557 = NOVALUE;
    DeRefDS(_30558);
    _30558 = NOVALUE;
    if (_30559 == 0LL)
    goto L12; // [445] 506

    /** parser.e:4557				tok = next_token()*/
    _0 = _tok_61989;
    _tok_61989 = _45next_token();
    DeRef(_0);

    /** parser.e:4558				if tok[T_ID] != LEFT_BRACE and tok[T_ID] != LEFT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok_61989);
    _30562 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30562)) {
        _30563 = (_30562 != -24LL);
    }
    else {
        _30563 = binary_op(NOTEQ, _30562, -24LL);
    }
    _30562 = NOVALUE;
    if (IS_ATOM_INT(_30563)) {
        if (_30563 == 0) {
            goto L13; // [468] 498
        }
    }
    else {
        if (DBL_PTR(_30563)->dbl == 0.0) {
            goto L13; // [468] 498
        }
    }
    _2 = (object)SEQ_PTR(_tok_61989);
    _30565 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30565)) {
        _30566 = (_30565 != -26LL);
    }
    else {
        _30566 = binary_op(NOTEQ, _30565, -26LL);
    }
    _30565 = NOVALUE;
    if (_30566 == 0) {
        DeRef(_30566);
        _30566 = NOVALUE;
        goto L13; // [485] 498
    }
    else {
        if (!IS_ATOM_INT(_30566) && DBL_PTR(_30566)->dbl == 0.0){
            DeRef(_30566);
            _30566 = NOVALUE;
            goto L13; // [485] 498
        }
        DeRef(_30566);
        _30566 = NOVALUE;
    }
    DeRef(_30566);
    _30566 = NOVALUE;

    /** parser.e:4559					CompileErr(WARNING_NAMES_MUST_BE_ENCLOSED_IN)*/
    RefDS(_21993);
    _50CompileErr(160LL, _21993, 0LL);
L13: 

    /** parser.e:4561				reset_flags = 0*/
    _reset_flags_61884 = 0LL;
    goto L14; // [503] 734
L12: 

    /** parser.e:4562			elsif tok[T_ID] = EQUALS then*/
    _2 = (object)SEQ_PTR(_tok_61989);
    _30567 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30567, 3LL)){
        _30567 = NOVALUE;
        goto L15; // [516] 577
    }
    _30567 = NOVALUE;

    /** parser.e:4563				tok = next_token()*/
    _0 = _tok_61989;
    _tok_61989 = _45next_token();
    DeRef(_0);

    /** parser.e:4564				if tok[T_ID] != LEFT_BRACE and tok[T_ID] != LEFT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok_61989);
    _30570 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30570)) {
        _30571 = (_30570 != -24LL);
    }
    else {
        _30571 = binary_op(NOTEQ, _30570, -24LL);
    }
    _30570 = NOVALUE;
    if (IS_ATOM_INT(_30571)) {
        if (_30571 == 0) {
            goto L16; // [539] 569
        }
    }
    else {
        if (DBL_PTR(_30571)->dbl == 0.0) {
            goto L16; // [539] 569
        }
    }
    _2 = (object)SEQ_PTR(_tok_61989);
    _30573 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_30573)) {
        _30574 = (_30573 != -26LL);
    }
    else {
        _30574 = binary_op(NOTEQ, _30573, -26LL);
    }
    _30573 = NOVALUE;
    if (_30574 == 0) {
        DeRef(_30574);
        _30574 = NOVALUE;
        goto L16; // [556] 569
    }
    else {
        if (!IS_ATOM_INT(_30574) && DBL_PTR(_30574)->dbl == 0.0){
            DeRef(_30574);
            _30574 = NOVALUE;
            goto L16; // [556] 569
        }
        DeRef(_30574);
        _30574 = NOVALUE;
    }
    DeRef(_30574);
    _30574 = NOVALUE;

    /** parser.e:4565					CompileErr(WARNING_NAMES_MUST_BE_ENCLOSED_IN)*/
    RefDS(_21993);
    _50CompileErr(160LL, _21993, 0LL);
L16: 

    /** parser.e:4567				reset_flags = 1*/
    _reset_flags_61884 = 1LL;
    goto L14; // [574] 734
L15: 

    /** parser.e:4568			elsif tok[T_ID] = VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_61989);
    _30575 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30575, -100LL)){
        _30575 = NOVALUE;
        goto L17; // [587] 733
    }
    _30575 = NOVALUE;

    /** parser.e:4569				option = SymTab[tok[T_SYM]][S_NAME]*/
    _2 = (object)SEQ_PTR(_tok_61989);
    _30577 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_30577)){
        _30578 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30577)->dbl));
    }
    else{
        _30578 = (object)*(((s1_ptr)_2)->base + _30577);
    }
    DeRef(_option_61882);
    _2 = (object)SEQ_PTR(_30578);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _option_61882 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _option_61882 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    Ref(_option_61882);
    _30578 = NOVALUE;

    /** parser.e:4570				if equal(option, "save") then*/
    if (_option_61882 == _30580)
    _30581 = 1;
    else if (IS_ATOM_INT(_option_61882) && IS_ATOM_INT(_30580))
    _30581 = 0;
    else
    _30581 = (compare(_option_61882, _30580) == 0);
    if (_30581 == 0)
    {
        _30581 = NOVALUE;
        goto L18; // [619] 643
    }
    else{
        _30581 = NOVALUE;
    }

    /** parser.e:4571					prev_OpWarning = OpWarning*/
    _36prev_OpWarning_21511 = _36OpWarning_21510;

    /** parser.e:4572					warning_extra = FALSE*/
    _warning_extra_61991 = _13FALSE_450;
    goto L19; // [640] 732
L18: 

    /** parser.e:4574				elsif equal(option, "restore") then*/
    if (_option_61882 == _30582)
    _30583 = 1;
    else if (IS_ATOM_INT(_option_61882) && IS_ATOM_INT(_30582))
    _30583 = 0;
    else
    _30583 = (compare(_option_61882, _30582) == 0);
    if (_30583 == 0)
    {
        _30583 = NOVALUE;
        goto L1A; // [649] 673
    }
    else{
        _30583 = NOVALUE;
    }

    /** parser.e:4575					OpWarning = prev_OpWarning*/
    _36OpWarning_21510 = _36prev_OpWarning_21511;

    /** parser.e:4576					warning_extra = FALSE*/
    _warning_extra_61991 = _13FALSE_450;
    goto L19; // [670] 732
L1A: 

    /** parser.e:4578				elsif equal(option, "strict") then*/
    if (_option_61882 == _25468)
    _30584 = 1;
    else if (IS_ATOM_INT(_option_61882) && IS_ATOM_INT(_25468))
    _30584 = 0;
    else
    _30584 = (compare(_option_61882, _25468) == 0);
    if (_30584 == 0)
    {
        _30584 = NOVALUE;
        goto L1B; // [679] 731
    }
    else{
        _30584 = NOVALUE;
    }

    /** parser.e:4579					if on_off = 0 then*/
    if (_on_off_61881 != 0LL)
    goto L1C; // [684] 701

    /** parser.e:4580						Strict_Override += 1*/
    _36Strict_Override_21509 = _36Strict_Override_21509 + 1LL;
    goto L1D; // [698] 721
L1C: 

    /** parser.e:4581					elsif Strict_Override > 0 then*/
    if (_36Strict_Override_21509 <= 0LL)
    goto L1E; // [705] 720

    /** parser.e:4582						Strict_Override -= 1*/
    _36Strict_Override_21509 = _36Strict_Override_21509 - 1LL;
L1E: 
L1D: 

    /** parser.e:4584					warning_extra = FALSE*/
    _warning_extra_61991 = _13FALSE_450;
L1B: 
L19: 
L17: 
L14: 

    /** parser.e:4588			if warning_extra = TRUE then*/
    if (_warning_extra_61991 != _13TRUE_452)
    goto L1F; // [738] 1238

    /** parser.e:4589				if reset_flags then*/
    if (_reset_flags_61884 == 0)
    {
        goto L20; // [744] 776
    }
    else{
    }

    /** parser.e:4590					if on_off = 0 then*/
    if (_on_off_61881 != 0LL)
    goto L21; // [749] 765

    /** parser.e:4591						OpWarning = no_warning_flag*/
    _36OpWarning_21510 = 0LL;
    goto L22; // [762] 775
L21: 

    /** parser.e:4593						OpWarning = all_warning_flag*/
    _36OpWarning_21510 = 32767LL;
L22: 
L20: 

    /** parser.e:4597				if find(tok[T_ID], {LEFT_BRACE, LEFT_ROUND}) then*/
    _2 = (object)SEQ_PTR(_tok_61989);
    _30591 = (object)*(((s1_ptr)_2)->base + 1LL);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -24LL;
    ((intptr_t *)_2)[2] = -26LL;
    _30592 = MAKE_SEQ(_1);
    _30593 = find_from(_30591, _30592, 1LL);
    _30591 = NOVALUE;
    DeRefDS(_30592);
    _30592 = NOVALUE;
    if (_30593 == 0)
    {
        _30593 = NOVALUE;
        goto L23; // [797] 1231
    }
    else{
        _30593 = NOVALUE;
    }

    /** parser.e:4598					integer endlist*/

    /** parser.e:4599					if tok[T_ID] = LEFT_BRACE then*/
    _2 = (object)SEQ_PTR(_tok_61989);
    _30594 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30594, -24LL)){
        _30594 = NOVALUE;
        goto L24; // [812] 828
    }
    _30594 = NOVALUE;

    /** parser.e:4600						endlist = RIGHT_BRACE*/
    _endlist_62084 = -25LL;
    goto L25; // [825] 838
L24: 

    /** parser.e:4602						endlist = RIGHT_ROUND*/
    _endlist_62084 = -27LL;
L25: 

    /** parser.e:4604					tok = next_token()*/
    _0 = _tok_61989;
    _tok_61989 = _45next_token();
    DeRef(_0);

    /** parser.e:4605					while tok[T_ID] != endlist do*/
L26: 
    _2 = (object)SEQ_PTR(_tok_61989);
    _30597 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _30597, _endlist_62084)){
        _30597 = NOVALUE;
        goto L27; // [856] 1226
    }
    _30597 = NOVALUE;

    /** parser.e:4606						if tok[T_ID] = COMMA then*/
    _2 = (object)SEQ_PTR(_tok_61989);
    _30599 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30599, -30LL)){
        _30599 = NOVALUE;
        goto L28; // [870] 884
    }
    _30599 = NOVALUE;

    /** parser.e:4607							tok = next_token()*/
    _0 = _tok_61989;
    _tok_61989 = _45next_token();
    DeRef(_0);

    /** parser.e:4608							continue*/
    goto L26; // [881] 848
L28: 

    /** parser.e:4611						if tok[T_ID] = STRING then*/
    _2 = (object)SEQ_PTR(_tok_61989);
    _30602 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30602, 503LL)){
        _30602 = NOVALUE;
        goto L29; // [894] 923
    }
    _30602 = NOVALUE;

    /** parser.e:4612							option = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_tok_61989);
    _30604 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_30604)){
        _30605 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30604)->dbl));
    }
    else{
        _30605 = (object)*(((s1_ptr)_2)->base + _30604);
    }
    DeRef(_option_61882);
    _2 = (object)SEQ_PTR(_30605);
    _option_61882 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_option_61882);
    _30605 = NOVALUE;
    goto L2A; // [920] 1071
L29: 

    /** parser.e:4613						elsif length(SymTab[tok[T_SYM]]) >= S_NAME then*/
    _2 = (object)SEQ_PTR(_tok_61989);
    _30607 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_30607)){
        _30608 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30607)->dbl));
    }
    else{
        _30608 = (object)*(((s1_ptr)_2)->base + _30607);
    }
    if (IS_SEQUENCE(_30608)){
            _30609 = SEQ_PTR(_30608)->length;
    }
    else {
        _30609 = 1;
    }
    _30608 = NOVALUE;
    if (binary_op_a(LESS, _30609, _36S_NAME_21076)){
        _30609 = NOVALUE;
        goto L2B; // [942] 971
    }
    _30609 = NOVALUE;

    /** parser.e:4614							option = SymTab[tok[T_SYM]][S_NAME]*/
    _2 = (object)SEQ_PTR(_tok_61989);
    _30611 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_30611)){
        _30612 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30611)->dbl));
    }
    else{
        _30612 = (object)*(((s1_ptr)_2)->base + _30611);
    }
    DeRef(_option_61882);
    _2 = (object)SEQ_PTR(_30612);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _option_61882 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _option_61882 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    Ref(_option_61882);
    _30612 = NOVALUE;
    goto L2A; // [968] 1071
L2B: 

    /** parser.e:4616							option = ""*/
    RefDS(_21993);
    DeRef(_option_61882);
    _option_61882 = _21993;

    /** parser.e:4617							for k = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_63keylist_23115)){
            _30614 = SEQ_PTR(_63keylist_23115)->length;
    }
    else {
        _30614 = 1;
    }
    {
        object _k_62131;
        _k_62131 = 1LL;
L2C: 
        if (_k_62131 > _30614){
            goto L2D; // [985] 1070
        }

        /** parser.e:4618								if keylist[k][S_SCOPE] = SC_KEYWORD and*/
        _2 = (object)SEQ_PTR(_63keylist_23115);
        _30615 = (object)*(((s1_ptr)_2)->base + _k_62131);
        _2 = (object)SEQ_PTR(_30615);
        _30616 = (object)*(((s1_ptr)_2)->base + 4LL);
        _30615 = NOVALUE;
        if (IS_ATOM_INT(_30616)) {
            _30617 = (_30616 == 8LL);
        }
        else {
            _30617 = binary_op(EQUALS, _30616, 8LL);
        }
        _30616 = NOVALUE;
        if (IS_ATOM_INT(_30617)) {
            if (_30617 == 0) {
                goto L2E; // [1012] 1063
            }
        }
        else {
            if (DBL_PTR(_30617)->dbl == 0.0) {
                goto L2E; // [1012] 1063
            }
        }
        _2 = (object)SEQ_PTR(_63keylist_23115);
        _30619 = (object)*(((s1_ptr)_2)->base + _k_62131);
        _2 = (object)SEQ_PTR(_30619);
        if (!IS_ATOM_INT(_36S_TOKEN_21081)){
            _30620 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
        }
        else{
            _30620 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
        }
        _30619 = NOVALUE;
        _2 = (object)SEQ_PTR(_tok_61989);
        _30621 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_30620) && IS_ATOM_INT(_30621)) {
            _30622 = (_30620 == _30621);
        }
        else {
            _30622 = binary_op(EQUALS, _30620, _30621);
        }
        _30620 = NOVALUE;
        _30621 = NOVALUE;
        if (_30622 == 0) {
            DeRef(_30622);
            _30622 = NOVALUE;
            goto L2E; // [1039] 1063
        }
        else {
            if (!IS_ATOM_INT(_30622) && DBL_PTR(_30622)->dbl == 0.0){
                DeRef(_30622);
                _30622 = NOVALUE;
                goto L2E; // [1039] 1063
            }
            DeRef(_30622);
            _30622 = NOVALUE;
        }
        DeRef(_30622);
        _30622 = NOVALUE;

        /** parser.e:4621										option = keylist[k][S_NAME]*/
        _2 = (object)SEQ_PTR(_63keylist_23115);
        _30623 = (object)*(((s1_ptr)_2)->base + _k_62131);
        DeRef(_option_61882);
        _2 = (object)SEQ_PTR(_30623);
        if (!IS_ATOM_INT(_36S_NAME_21076)){
            _option_61882 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
        }
        else{
            _option_61882 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
        }
        Ref(_option_61882);
        _30623 = NOVALUE;

        /** parser.e:4622										exit*/
        goto L2D; // [1060] 1070
L2E: 

        /** parser.e:4624							end for*/
        _k_62131 = _k_62131 + 1LL;
        goto L2C; // [1065] 992
L2D: 
        ;
    }
L2A: 

    /** parser.e:4628						idx = find(option, warning_names)*/
    _idx_61883 = find_from(_option_61882, _36warning_names_21487, 1LL);

    /** parser.e:4629						if idx = 0 then*/
    if (_idx_61883 != 0LL)
    goto L2F; // [1082] 1137

    /** parser.e:4630		 					if good_sofar != line_number then*/
    if (_good_sofar_61986 == _36line_number_21440)
    goto L30; // [1090] 1104

    /** parser.e:4631	 							CompileErr(TOO_MANY_WARNING_ERRORS)*/
    RefDS(_21993);
    _50CompileErr(147LL, _21993, 0LL);
L30: 

    /** parser.e:4633							Warning(225, 0,*/
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _30628 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_30628);
    ((intptr_t*)_2)[1] = _30628;
    ((intptr_t*)_2)[2] = _36line_number_21440;
    RefDS(_option_61882);
    ((intptr_t*)_2)[3] = _option_61882;
    _30629 = MAKE_SEQ(_1);
    _30628 = NOVALUE;
    _50Warning(225LL, 0LL, _30629);
    _30629 = NOVALUE;

    /** parser.e:4635							tok = next_token()*/
    _0 = _tok_61989;
    _tok_61989 = _45next_token();
    DeRef(_0);

    /** parser.e:4636							continue*/
    goto L26; // [1134] 848
L2F: 

    /** parser.e:4639						idx = warning_flags[idx]*/
    _2 = (object)SEQ_PTR(_36warning_flags_21485);
    _idx_61883 = (object)*(((s1_ptr)_2)->base + _idx_61883);

    /** parser.e:4640						if idx = 0 then*/
    if (_idx_61883 != 0LL)
    goto L31; // [1149] 1183

    /** parser.e:4641							if on_off then*/
    if (_on_off_61881 == 0)
    {
        goto L32; // [1155] 1170
    }
    else{
    }

    /** parser.e:4642								OpWarning = no_warning_flag*/
    _36OpWarning_21510 = 0LL;
    goto L33; // [1167] 1216
L32: 

    /** parser.e:4644							    OpWarning = all_warning_flag*/
    _36OpWarning_21510 = 32767LL;
    goto L33; // [1180] 1216
L31: 

    /** parser.e:4647							if on_off then*/
    if (_on_off_61881 == 0)
    {
        goto L34; // [1185] 1201
    }
    else{
    }

    /** parser.e:4648								OpWarning = or_bits(OpWarning, idx)*/
    {uintptr_t tu;
         tu = (uintptr_t)_36OpWarning_21510 | (uintptr_t)_idx_61883;
         _36OpWarning_21510 = MAKE_UINT(tu);
    }
    if (!IS_ATOM_INT(_36OpWarning_21510)) {
        _1 = (object)(DBL_PTR(_36OpWarning_21510)->dbl);
        DeRefDS(_36OpWarning_21510);
        _36OpWarning_21510 = _1;
    }
    goto L35; // [1198] 1215
L34: 

    /** parser.e:4650							    OpWarning = and_bits(OpWarning, not_bits(idx))*/
    _30634 = not_bits(_idx_61883);
    if (IS_ATOM_INT(_30634)) {
        {uintptr_t tu;
             tu = (uintptr_t)_36OpWarning_21510 & (uintptr_t)_30634;
             _36OpWarning_21510 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (eudouble)_36OpWarning_21510;
        _36OpWarning_21510 = Dand_bits(&temp_d, DBL_PTR(_30634));
    }
    DeRef(_30634);
    _30634 = NOVALUE;
    if (!IS_ATOM_INT(_36OpWarning_21510)) {
        _1 = (object)(DBL_PTR(_36OpWarning_21510)->dbl);
        DeRefDS(_36OpWarning_21510);
        _36OpWarning_21510 = _1;
    }
L35: 
L33: 

    /** parser.e:4653						tok = next_token()*/
    _0 = _tok_61989;
    _tok_61989 = _45next_token();
    DeRef(_0);

    /** parser.e:4654					end while*/
    goto L26; // [1223] 848
L27: 
    goto L36; // [1228] 1237
L23: 

    /** parser.e:4656					putback(tok)*/
    Ref(_tok_61989);
    _45putback(_tok_61989);
L36: 
L1F: 
    DeRef(_tok_61989);
    _tok_61989 = NOVALUE;
    goto L2; // [1240] 1546
L11: 

    /** parser.e:4659		elsif equal(option, "define") then*/
    if (_option_61882 == _30637)
    _30638 = 1;
    else if (IS_ATOM_INT(_option_61882) && IS_ATOM_INT(_30637))
    _30638 = 0;
    else
    _30638 = (compare(_option_61882, _30637) == 0);
    if (_30638 == 0)
    {
        _30638 = NOVALUE;
        goto L37; // [1249] 1376
    }
    else{
        _30638 = NOVALUE;
    }

    /** parser.e:4660			option = StringToken()*/
    RefDS(_5);
    _0 = _option_61882;
    _option_61882 = _62StringToken(_5);
    DeRefDS(_0);

    /** parser.e:4661			if length(option) = 0 then*/
    if (IS_SEQUENCE(_option_61882)){
            _30640 = SEQ_PTR(_option_61882)->length;
    }
    else {
        _30640 = 1;
    }
    if (_30640 != 0LL)
    goto L38; // [1265] 1281

    /** parser.e:4662				CompileErr(EXPECTING_TO_FIND_A_WORD_TO_DEFINE_BUT_REACHED_END_OF_LINE_FIRST)*/
    RefDS(_21993);
    _50CompileErr(81LL, _21993, 0LL);
    goto L39; // [1278] 1301
L38: 

    /** parser.e:4664			elsif not t_identifier(option) then*/
    RefDS(_option_61882);
    _30642 = _13t_identifier(_option_61882);
    if (IS_ATOM_INT(_30642)) {
        if (_30642 != 0){
            DeRef(_30642);
            _30642 = NOVALUE;
            goto L3A; // [1287] 1300
        }
    }
    else {
        if (DBL_PTR(_30642)->dbl != 0.0){
            DeRef(_30642);
            _30642 = NOVALUE;
            goto L3A; // [1287] 1300
        }
    }
    DeRef(_30642);
    _30642 = NOVALUE;

    /** parser.e:4665				CompileErr(DEFINED_WORD_MUST_ONLY_HAVE_ALPHANUMERICS_AND_UNDERSCORE)*/
    RefDS(_21993);
    _50CompileErr(61LL, _21993, 0LL);
L3A: 
L39: 

    /** parser.e:4668			if on_off = 0 then*/
    if (_on_off_61881 != 0LL)
    goto L3B; // [1303] 1358

    /** parser.e:4669				idx = find(option, OpDefines)*/
    _idx_61883 = find_from(_option_61882, _36OpDefines_21516, 1LL);

    /** parser.e:4670				if idx then*/
    if (_idx_61883 == 0)
    {
        goto L2; // [1318] 1546
    }
    else{
    }

    /** parser.e:4671					OpDefines = OpDefines[1..idx-1]&OpDefines[idx+1..$]*/
    _30646 = _idx_61883 - 1LL;
    rhs_slice_target = (object_ptr)&_30647;
    RHS_Slice(_36OpDefines_21516, 1LL, _30646);
    _30648 = _idx_61883 + 1;
    if (IS_SEQUENCE(_36OpDefines_21516)){
            _30649 = SEQ_PTR(_36OpDefines_21516)->length;
    }
    else {
        _30649 = 1;
    }
    rhs_slice_target = (object_ptr)&_30650;
    RHS_Slice(_36OpDefines_21516, _30648, _30649);
    Concat((object_ptr)&_36OpDefines_21516, _30647, _30650);
    DeRefDS(_30647);
    _30647 = NOVALUE;
    DeRef(_30647);
    _30647 = NOVALUE;
    DeRefDS(_30650);
    _30650 = NOVALUE;
    goto L2; // [1355] 1546
L3B: 

    /** parser.e:4674				OpDefines &= {option}*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_option_61882);
    ((intptr_t*)_2)[1] = _option_61882;
    _30652 = MAKE_SEQ(_1);
    Concat((object_ptr)&_36OpDefines_21516, _36OpDefines_21516, _30652);
    DeRefDS(_30652);
    _30652 = NOVALUE;
    goto L2; // [1373] 1546
L37: 

    /** parser.e:4677		elsif equal(option, "inline") then*/
    if (_option_61882 == _30654)
    _30655 = 1;
    else if (IS_ATOM_INT(_option_61882) && IS_ATOM_INT(_30654))
    _30655 = 0;
    else
    _30655 = (compare(_option_61882, _30654) == 0);
    if (_30655 == 0)
    {
        _30655 = NOVALUE;
        goto L3C; // [1382] 1478
    }
    else{
        _30655 = NOVALUE;
    }

    /** parser.e:4679			if on_off and not repl then*/
    if (_on_off_61881 == 0) {
        goto L3D; // [1387] 1467
    }
    _30657 = (0LL == 0);
    if (_30657 == 0)
    {
        DeRef(_30657);
        _30657 = NOVALUE;
        goto L3D; // [1397] 1467
    }
    else{
        DeRef(_30657);
        _30657 = NOVALUE;
    }

    /** parser.e:4680				token tok = next_token()*/
    _0 = _tok_62233;
    _tok_62233 = _45next_token();
    DeRef(_0);

    /** parser.e:4681				if tok[T_ID] = ATOM then*/
    _2 = (object)SEQ_PTR(_tok_62233);
    _30659 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30659, 502LL)){
        _30659 = NOVALUE;
        goto L3E; // [1415] 1447
    }
    _30659 = NOVALUE;

    /** parser.e:4682					OpInline = floor( SymTab[tok[T_SYM]][S_OBJ] )*/
    _2 = (object)SEQ_PTR(_tok_62233);
    _30661 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_30661)){
        _30662 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30661)->dbl));
    }
    else{
        _30662 = (object)*(((s1_ptr)_2)->base + _30661);
    }
    _2 = (object)SEQ_PTR(_30662);
    _30663 = (object)*(((s1_ptr)_2)->base + 1LL);
    _30662 = NOVALUE;
    if (IS_ATOM_INT(_30663))
    _36OpInline_21517 = e_floor(_30663);
    else
    _36OpInline_21517 = unary_op(FLOOR, _30663);
    _30663 = NOVALUE;
    if (!IS_ATOM_INT(_36OpInline_21517)) {
        _1 = (object)(DBL_PTR(_36OpInline_21517)->dbl);
        DeRefDS(_36OpInline_21517);
        _36OpInline_21517 = _1;
    }
    goto L3F; // [1444] 1462
L3E: 

    /** parser.e:4684					putback(tok)*/
    Ref(_tok_62233);
    _45putback(_tok_62233);

    /** parser.e:4685					OpInline = DEFAULT_INLINE*/
    _36OpInline_21517 = 30LL;
L3F: 
    DeRef(_tok_62233);
    _tok_62233 = NOVALUE;
    goto L2; // [1464] 1546
L3D: 

    /** parser.e:4688				OpInline = 0*/
    _36OpInline_21517 = 0LL;
    goto L2; // [1475] 1546
L3C: 

    /** parser.e:4692		elsif equal( option, "indirect_includes" ) then*/
    if (_option_61882 == _30665)
    _30666 = 1;
    else if (IS_ATOM_INT(_option_61882) && IS_ATOM_INT(_30665))
    _30666 = 0;
    else
    _30666 = (compare(_option_61882, _30665) == 0);
    if (_30666 == 0)
    {
        _30666 = NOVALUE;
        goto L40; // [1484] 1497
    }
    else{
        _30666 = NOVALUE;
    }

    /** parser.e:4693			OpIndirectInclude = on_off*/
    _36OpIndirectInclude_21518 = _on_off_61881;
    goto L2; // [1494] 1546
L40: 

    /** parser.e:4695		elsif equal(option, "batch") then*/
    if (_option_61882 == _25465)
    _30667 = 1;
    else if (IS_ATOM_INT(_option_61882) && IS_ATOM_INT(_25465))
    _30667 = 0;
    else
    _30667 = (compare(_option_61882, _25465) == 0);
    if (_30667 == 0)
    {
        _30667 = NOVALUE;
        goto L41; // [1503] 1516
    }
    else{
        _30667 = NOVALUE;
    }

    /** parser.e:4696			batch_job = on_off*/
    _36batch_job_21452 = _on_off_61881;
    goto L2; // [1513] 1546
L41: 

    /** parser.e:4698		elsif integer(to_number(option, -1)) then*/
    RefDS(_option_61882);
    _30668 = _15to_number(_option_61882, -1LL);
    if (IS_ATOM_INT(_30668))
    _30669 = 1;
    else if (IS_ATOM_DBL(_30668))
    _30669 = IS_ATOM_INT(DoubleToInt(_30668));
    else
    _30669 = 0;
    DeRef(_30668);
    _30668 = NOVALUE;
    if (_30669 == 0)
    {
        _30669 = NOVALUE;
        goto L42; // [1526] 1532
    }
    else{
        _30669 = NOVALUE;
    }
    goto L2; // [1529] 1546
L42: 

    /** parser.e:4702			CompileErr(UNKNOWN_WITHWITHOUT_OPTION_1, {option})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_option_61882);
    ((intptr_t*)_2)[1] = _option_61882;
    _30670 = MAKE_SEQ(_1);
    _50CompileErr(154LL, _30670, 0LL);
    _30670 = NOVALUE;
L2: 

    /** parser.e:4705	end procedure*/
    DeRef(_option_61882);
    DeRef(_30530);
    _30530 = NOVALUE;
    _30661 = NOVALUE;
    DeRef(_30571);
    _30571 = NOVALUE;
    _30542 = NOVALUE;
    DeRef(_30617);
    _30617 = NOVALUE;
    _30604 = NOVALUE;
    DeRef(_30648);
    _30648 = NOVALUE;
    _30608 = NOVALUE;
    _30577 = NOVALUE;
    _30546 = NOVALUE;
    DeRef(_30646);
    _30646 = NOVALUE;
    DeRef(_30563);
    _30563 = NOVALUE;
    _30607 = NOVALUE;
    DeRef(_30535);
    _30535 = NOVALUE;
    _30611 = NOVALUE;
    DeRef(_30549);
    _30549 = NOVALUE;
    return;
    ;
}


void _45ExecCommand()
{
    object _0, _1, _2;
    

    /** parser.e:4709		if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L1; // [5] 16
    }
    else{
    }

    /** parser.e:4710			emit_op(RETURNT)*/
    _47emit_op(34LL);
L1: 

    /** parser.e:4712		StraightenBranches()  -- straighten top-level*/
    _45StraightenBranches();

    /** parser.e:4713	end procedure*/
    return;
    ;
}


object _45undefined_var(object _tok_62277, object _scope_62278)
{
    object _forward_62280 = NOVALUE;
    object _30676 = NOVALUE;
    object _30675 = NOVALUE;
    object _30672 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:4716		token forward = next_token()*/
    _0 = _forward_62280;
    _forward_62280 = _45next_token();
    DeRef(_0);

    /** parser.e:4717			switch forward[T_ID] do*/
    _2 = (object)SEQ_PTR(_forward_62280);
    _30672 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_30672) ){
        goto L1; // [16] 82
    }
    if(!IS_ATOM_INT(_30672)){
        if( (DBL_PTR(_30672)->dbl != (eudouble) ((object) DBL_PTR(_30672)->dbl) ) ){
            goto L1; // [16] 82
        }
        _0 = (object) DBL_PTR(_30672)->dbl;
    }
    else {
        _0 = _30672;
    };
    _30672 = NOVALUE;
    switch ( _0 ){ 

        /** parser.e:4718				case LEFT_ROUND then*/
        case -26:

        /** parser.e:4719					StartSourceLine( TRUE )*/
        _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

        /** parser.e:4720					Forward_call( tok )*/
        Ref(_tok_62277);
        _45Forward_call(_tok_62277, 195LL);

        /** parser.e:4721					return 1*/
        DeRef(_tok_62277);
        DeRef(_forward_62280);
        return 1LL;
        goto L2; // [48] 96

        /** parser.e:4723				case VARIABLE then*/
        case -100:

        /** parser.e:4724					putback( forward )*/
        Ref(_forward_62280);
        _45putback(_forward_62280);

        /** parser.e:4725					Global_declaration( tok[T_SYM], scope )*/
        _2 = (object)SEQ_PTR(_tok_62277);
        _30675 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_30675);
        _30676 = _45Global_declaration(_30675, _scope_62278);
        _30675 = NOVALUE;

        /** parser.e:4726					return 1*/
        DeRef(_tok_62277);
        DeRef(_forward_62280);
        DeRef(_30676);
        _30676 = NOVALUE;
        return 1LL;
        goto L2; // [78] 96

        /** parser.e:4728				case else*/
        default:
L1: 

        /** parser.e:4729					putback( forward )*/
        Ref(_forward_62280);
        _45putback(_forward_62280);

        /** parser.e:4730					return 0*/
        DeRef(_tok_62277);
        DeRef(_forward_62280);
        DeRef(_30676);
        _30676 = NOVALUE;
        return 0LL;
    ;}L2: 
    ;
}


void _45real_parser(object _nested_62299)
{
    object _tok_62301 = NOVALUE;
    object _id_62302 = NOVALUE;
    object _scope_62303 = NOVALUE;
    object _deprecated_62365 = NOVALUE;
    object _test_62460 = NOVALUE;
    object _30816 = NOVALUE;
    object _30814 = NOVALUE;
    object _30813 = NOVALUE;
    object _30812 = NOVALUE;
    object _30811 = NOVALUE;
    object _30810 = NOVALUE;
    object _30809 = NOVALUE;
    object _30808 = NOVALUE;
    object _30803 = NOVALUE;
    object _30802 = NOVALUE;
    object _30799 = NOVALUE;
    object _30797 = NOVALUE;
    object _30796 = NOVALUE;
    object _30793 = NOVALUE;
    object _30779 = NOVALUE;
    object _30772 = NOVALUE;
    object _30771 = NOVALUE;
    object _30769 = NOVALUE;
    object _30767 = NOVALUE;
    object _30766 = NOVALUE;
    object _30764 = NOVALUE;
    object _30762 = NOVALUE;
    object _30757 = NOVALUE;
    object _30755 = NOVALUE;
    object _30753 = NOVALUE;
    object _30752 = NOVALUE;
    object _30751 = NOVALUE;
    object _30749 = NOVALUE;
    object _30747 = NOVALUE;
    object _30745 = NOVALUE;
    object _30743 = NOVALUE;
    object _30742 = NOVALUE;
    object _30741 = NOVALUE;
    object _30740 = NOVALUE;
    object _30739 = NOVALUE;
    object _30738 = NOVALUE;
    object _30737 = NOVALUE;
    object _30736 = NOVALUE;
    object _30735 = NOVALUE;
    object _30734 = NOVALUE;
    object _30733 = NOVALUE;
    object _30732 = NOVALUE;
    object _30731 = NOVALUE;
    object _30730 = NOVALUE;
    object _30728 = NOVALUE;
    object _30727 = NOVALUE;
    object _30726 = NOVALUE;
    object _30725 = NOVALUE;
    object _30723 = NOVALUE;
    object _30721 = NOVALUE;
    object _30720 = NOVALUE;
    object _30719 = NOVALUE;
    object _30717 = NOVALUE;
    object _30706 = NOVALUE;
    object _30704 = NOVALUE;
    object _30703 = NOVALUE;
    object _30702 = NOVALUE;
    object _30701 = NOVALUE;
    object _30700 = NOVALUE;
    object _30699 = NOVALUE;
    object _30698 = NOVALUE;
    object _30697 = NOVALUE;
    object _30696 = NOVALUE;
    object _30694 = NOVALUE;
    object _30693 = NOVALUE;
    object _30692 = NOVALUE;
    object _30691 = NOVALUE;
    object _30690 = NOVALUE;
    object _30689 = NOVALUE;
    object _30688 = NOVALUE;
    object _30687 = NOVALUE;
    object _30686 = NOVALUE;
    object _30685 = NOVALUE;
    object _30683 = NOVALUE;
    object _30679 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:4737		integer id*/

    /** parser.e:4738		integer scope*/

    /** parser.e:4740		while TRUE do  -- infinite loop until scanner aborts*/
L1: 
    if (_13TRUE_452 == 0)
    {
        goto L2; // [14] 1925
    }
    else{
    }

    /** parser.e:4741			if OpInline = 25000 then*/
    if (_36OpInline_21517 != 25000LL)
    goto L3; // [21] 35

    /** parser.e:4742				CompileErr("OpInline went nuts: [1]", OpInline )*/
    RefDS(_30678);
    _50CompileErr(_30678, _36OpInline_21517, 0LL);
L3: 

    /** parser.e:4744			start_index = length(Code)+1*/
    if (IS_SEQUENCE(_36Code_21531)){
            _30679 = SEQ_PTR(_36Code_21531)->length;
    }
    else {
        _30679 = 1;
    }
    _45start_index_54930 = _30679 + 1;
    _30679 = NOVALUE;

    /** parser.e:4745			tok = next_token()*/
    _0 = _tok_62301;
    _tok_62301 = _45next_token();
    DeRef(_0);

    /** parser.e:4746			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_62301);
    _id_62302 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_62302)){
        _id_62302 = (object)DBL_PTR(_id_62302)->dbl;
    }

    /** parser.e:4747			if id = VARIABLE or id = QUALIFIED_VARIABLE then*/
    _30683 = (_id_62302 == -100LL);
    if (_30683 != 0) {
        goto L4; // [69] 84
    }
    _30685 = (_id_62302 == 512LL);
    if (_30685 == 0)
    {
        DeRef(_30685);
        _30685 = NOVALUE;
        goto L5; // [80] 151
    }
    else{
        DeRef(_30685);
        _30685 = NOVALUE;
    }
L4: 

    /** parser.e:4748				if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED*/
    _2 = (object)SEQ_PTR(_tok_62301);
    _30686 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_30686)){
        _30687 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30686)->dbl));
    }
    else{
        _30687 = (object)*(((s1_ptr)_2)->base + _30686);
    }
    _2 = (object)SEQ_PTR(_30687);
    _30688 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30687 = NOVALUE;
    if (IS_ATOM_INT(_30688)) {
        _30689 = (_30688 == 9LL);
    }
    else {
        _30689 = binary_op(EQUALS, _30688, 9LL);
    }
    _30688 = NOVALUE;
    if (IS_ATOM_INT(_30689)) {
        if (_30689 == 0) {
            goto L6; // [110] 130
        }
    }
    else {
        if (DBL_PTR(_30689)->dbl == 0.0) {
            goto L6; // [110] 130
        }
    }
    Ref(_tok_62301);
    _30691 = _45undefined_var(_tok_62301, 5LL);
    if (_30691 == 0) {
        DeRef(_30691);
        _30691 = NOVALUE;
        goto L6; // [122] 130
    }
    else {
        if (!IS_ATOM_INT(_30691) && DBL_PTR(_30691)->dbl == 0.0){
            DeRef(_30691);
            _30691 = NOVALUE;
            goto L6; // [122] 130
        }
        DeRef(_30691);
        _30691 = NOVALUE;
    }
    DeRef(_30691);
    _30691 = NOVALUE;

    /** parser.e:4750					continue*/
    goto L1; // [127] 12
L6: 

    /** parser.e:4752				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:4753				Assignment(tok)*/
    Ref(_tok_62301);
    _45Assignment(_tok_62301);

    /** parser.e:4754				ExecCommand()*/
    _45ExecCommand();
    goto L7; // [148] 1915
L5: 

    /** parser.e:4756			elsif id = PROCEDURE or id = FUNCTION or id = TYPE_DECL then*/
    _30692 = (_id_62302 == 405LL);
    if (_30692 != 0) {
        _30693 = 1;
        goto L8; // [159] 173
    }
    _30694 = (_id_62302 == 406LL);
    _30693 = (_30694 != 0);
L8: 
    if (_30693 != 0) {
        goto L9; // [173] 188
    }
    _30696 = (_id_62302 == 416LL);
    if (_30696 == 0)
    {
        DeRef(_30696);
        _30696 = NOVALUE;
        goto LA; // [184] 206
    }
    else{
        DeRef(_30696);
        _30696 = NOVALUE;
    }
L9: 

    /** parser.e:4757				SubProg(tok[T_ID], SC_LOCAL, 0)*/
    _2 = (object)SEQ_PTR(_tok_62301);
    _30697 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_30697);
    _45SubProg(_30697, 5LL, 0LL);
    _30697 = NOVALUE;
    goto L7; // [203] 1915
LA: 

    /** parser.e:4759			elsif id = GLOBAL or id = EXPORT or id = OVERRIDE or id = PUBLIC or id = DEPRECATE then*/
    _30698 = (_id_62302 == 412LL);
    if (_30698 != 0) {
        _30699 = 1;
        goto LB; // [214] 228
    }
    _30700 = (_id_62302 == 428LL);
    _30699 = (_30700 != 0);
LB: 
    if (_30699 != 0) {
        _30701 = 1;
        goto LC; // [228] 242
    }
    _30702 = (_id_62302 == 429LL);
    _30701 = (_30702 != 0);
LC: 
    if (_30701 != 0) {
        _30703 = 1;
        goto LD; // [242] 256
    }
    _30704 = (_id_62302 == 430LL);
    _30703 = (_30704 != 0);
LD: 
    if (_30703 != 0) {
        goto LE; // [256] 271
    }
    _30706 = (_id_62302 == 433LL);
    if (_30706 == 0)
    {
        DeRef(_30706);
        _30706 = NOVALUE;
        goto LF; // [267] 692
    }
    else{
        DeRef(_30706);
        _30706 = NOVALUE;
    }
LE: 

    /** parser.e:4760				integer deprecated = 0*/
    _deprecated_62365 = 0LL;

    /** parser.e:4762				if id = DEPRECATE then*/
    if (_id_62302 != 433LL)
    goto L10; // [280] 305

    /** parser.e:4763					deprecated = 1*/
    _deprecated_62365 = 1LL;

    /** parser.e:4765					tok = next_token()*/
    _0 = _tok_62301;
    _tok_62301 = _45next_token();
    DeRef(_0);

    /** parser.e:4766					id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_62301);
    _id_62302 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_62302)){
        _id_62302 = (object)DBL_PTR(_id_62302)->dbl;
    }
L10: 

    /** parser.e:4769				scope = SC_LOCAL*/
    _scope_62303 = 5LL;

    /** parser.e:4770				if id = GLOBAL then*/
    if (_id_62302 != 412LL)
    goto L11; // [318] 334

    /** parser.e:4771				    scope = SC_GLOBAL*/
    _scope_62303 = 6LL;
    goto L12; // [331] 393
L11: 

    /** parser.e:4772				elsif id = EXPORT then*/
    if (_id_62302 != 428LL)
    goto L13; // [338] 354

    /** parser.e:4773					scope = SC_EXPORT*/
    _scope_62303 = 11LL;
    goto L12; // [351] 393
L13: 

    /** parser.e:4774				elsif id = OVERRIDE then*/
    if (_id_62302 != 429LL)
    goto L14; // [358] 374

    /** parser.e:4775					scope = SC_OVERRIDE*/
    _scope_62303 = 12LL;
    goto L12; // [371] 393
L14: 

    /** parser.e:4776				elsif id = PUBLIC then*/
    if (_id_62302 != 430LL)
    goto L15; // [378] 392

    /** parser.e:4777					scope = SC_PUBLIC*/
    _scope_62303 = 13LL;
L15: 
L12: 

    /** parser.e:4781				if scope != SC_LOCAL then*/
    if (_scope_62303 == 5LL)
    goto L16; // [397] 417

    /** parser.e:4782					tok = next_token()*/
    _0 = _tok_62301;
    _tok_62301 = _45next_token();
    DeRef(_0);

    /** parser.e:4783					id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_62301);
    _id_62302 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_id_62302)){
        _id_62302 = (object)DBL_PTR(_id_62302)->dbl;
    }
L16: 

    /** parser.e:4786				if id = TYPE or id = QUALIFIED_TYPE then*/
    _30717 = (_id_62302 == 504LL);
    if (_30717 != 0) {
        goto L17; // [425] 440
    }
    _30719 = (_id_62302 == 522LL);
    if (_30719 == 0)
    {
        DeRef(_30719);
        _30719 = NOVALUE;
        goto L18; // [436] 456
    }
    else{
        DeRef(_30719);
        _30719 = NOVALUE;
    }
L17: 

    /** parser.e:4787					Global_declaration(tok[T_SYM], scope )*/
    _2 = (object)SEQ_PTR(_tok_62301);
    _30720 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30720);
    _30721 = _45Global_declaration(_30720, _scope_62303);
    _30720 = NOVALUE;
    goto L19; // [453] 687
L18: 

    /** parser.e:4789				elsif id = CONSTANT then*/
    if (_id_62302 != 417LL)
    goto L1A; // [460] 478

    /** parser.e:4790					Global_declaration(0, scope )*/
    _30723 = _45Global_declaration(0LL, _scope_62303);

    /** parser.e:4791					ExecCommand()*/
    _45ExecCommand();
    goto L19; // [475] 687
L1A: 

    /** parser.e:4793				elsif id = ENUM then*/
    if (_id_62302 != 427LL)
    goto L1B; // [482] 500

    /** parser.e:4794					Global_declaration(-1, scope )*/
    _30725 = _45Global_declaration(-1LL, _scope_62303);

    /** parser.e:4795					ExecCommand()*/
    _45ExecCommand();
    goto L19; // [497] 687
L1B: 

    /** parser.e:4797				elsif id = PROCEDURE or id = FUNCTION or id = TYPE_DECL then*/
    _30726 = (_id_62302 == 405LL);
    if (_30726 != 0) {
        _30727 = 1;
        goto L1C; // [508] 522
    }
    _30728 = (_id_62302 == 406LL);
    _30727 = (_30728 != 0);
L1C: 
    if (_30727 != 0) {
        goto L1D; // [522] 537
    }
    _30730 = (_id_62302 == 416LL);
    if (_30730 == 0)
    {
        DeRef(_30730);
        _30730 = NOVALUE;
        goto L1E; // [533] 547
    }
    else{
        DeRef(_30730);
        _30730 = NOVALUE;
    }
L1D: 

    /** parser.e:4798					SubProg(id, scope, deprecated)*/
    _45SubProg(_id_62302, _scope_62303, _deprecated_62365);
    goto L19; // [544] 687
L1E: 

    /** parser.e:4800				elsif (scope = SC_PUBLIC) and id = INCLUDE then*/
    _30731 = (_scope_62303 == 13LL);
    if (_30731 == 0) {
        goto L1F; // [555] 581
    }
    _30733 = (_id_62302 == 418LL);
    if (_30733 == 0)
    {
        DeRef(_30733);
        _30733 = NOVALUE;
        goto L1F; // [566] 581
    }
    else{
        DeRef(_30733);
        _30733 = NOVALUE;
    }

    /** parser.e:4801					IncludeScan( 1 )*/
    _62IncludeScan(1LL);

    /** parser.e:4802					PushGoto()*/
    _45PushGoto();
    goto L19; // [578] 687
L1F: 

    /** parser.e:4803				elsif (id = VARIABLE or id = QUALIFIED_VARIABLE)*/
    _30734 = (_id_62302 == -100LL);
    if (_30734 != 0) {
        _30735 = 1;
        goto L20; // [589] 603
    }
    _30736 = (_id_62302 == 512LL);
    _30735 = (_30736 != 0);
L20: 
    if (_30735 == 0) {
        _30737 = 0;
        goto L21; // [603] 635
    }
    _2 = (object)SEQ_PTR(_tok_62301);
    _30738 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_30738)){
        _30739 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30738)->dbl));
    }
    else{
        _30739 = (object)*(((s1_ptr)_2)->base + _30738);
    }
    _2 = (object)SEQ_PTR(_30739);
    _30740 = (object)*(((s1_ptr)_2)->base + 4LL);
    _30739 = NOVALUE;
    if (IS_ATOM_INT(_30740)) {
        _30741 = (_30740 == 9LL);
    }
    else {
        _30741 = binary_op(EQUALS, _30740, 9LL);
    }
    _30740 = NOVALUE;
    if (IS_ATOM_INT(_30741))
    _30737 = (_30741 != 0);
    else
    _30737 = DBL_PTR(_30741)->dbl != 0.0;
L21: 
    if (_30737 == 0) {
        goto L22; // [635] 657
    }
    Ref(_tok_62301);
    _30743 = _45undefined_var(_tok_62301, _scope_62303);
    if (_30743 == 0) {
        DeRef(_30743);
        _30743 = NOVALUE;
        goto L22; // [645] 657
    }
    else {
        if (!IS_ATOM_INT(_30743) && DBL_PTR(_30743)->dbl == 0.0){
            DeRef(_30743);
            _30743 = NOVALUE;
            goto L22; // [645] 657
        }
        DeRef(_30743);
        _30743 = NOVALUE;
    }
    DeRef(_30743);
    _30743 = NOVALUE;

    /** parser.e:4807					continue*/
    goto L1; // [652] 12
    goto L19; // [654] 687
L22: 

    /** parser.e:4809				elsif scope = SC_GLOBAL then*/
    if (_scope_62303 != 6LL)
    goto L23; // [661] 677

    /** parser.e:4810					CompileErr( MSG_GLOBAL_MUST_BE_FOLLOWED_BYA_TYPE_CONSTANT_ENUM_PROCEDURE_TYPE_OR_FUNCTION)*/
    RefDS(_21993);
    _50CompileErr(18LL, _21993, 0LL);
    goto L19; // [674] 687
L23: 

    /** parser.e:4812					CompileErr( MSG_PUBLIC_OR_EXPORT_MUST_BE_FOLLOWED_BYA_TYPE_CONSTANT_ENUM_PROCEDURE_TYPE_OR_FUNCTION)*/
    RefDS(_21993);
    _50CompileErr(16LL, _21993, 0LL);
L19: 
    goto L7; // [689] 1915
LF: 

    /** parser.e:4815			elsif id = TYPE or id = QUALIFIED_TYPE then*/
    _30745 = (_id_62302 == 504LL);
    if (_30745 != 0) {
        goto L24; // [700] 715
    }
    _30747 = (_id_62302 == 522LL);
    if (_30747 == 0)
    {
        DeRef(_30747);
        _30747 = NOVALUE;
        goto L25; // [711] 800
    }
    else{
        DeRef(_30747);
        _30747 = NOVALUE;
    }
L24: 

    /** parser.e:4816				token test = next_token()*/
    _0 = _test_62460;
    _test_62460 = _45next_token();
    DeRef(_0);

    /** parser.e:4817				putback( test )*/
    Ref(_test_62460);
    _45putback(_test_62460);

    /** parser.e:4818				if test[T_ID] = LEFT_ROUND then*/
    _2 = (object)SEQ_PTR(_test_62460);
    _30749 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _30749, -26LL)){
        _30749 = NOVALUE;
        goto L26; // [735] 773
    }
    _30749 = NOVALUE;

    /** parser.e:4819						StartSourceLine( TRUE )*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:4820						Procedure_call(tok)*/
    Ref(_tok_62301);
    _45Procedure_call(_tok_62301);

    /** parser.e:4821						clear_op()*/
    _47clear_op();

    /** parser.e:4822						if Pop() then end if*/
    _30751 = _47Pop();
    if (_30751 == 0) {
        DeRef(_30751);
        _30751 = NOVALUE;
        goto L27; // [762] 766
    }
    else {
        if (!IS_ATOM_INT(_30751) && DBL_PTR(_30751)->dbl == 0.0){
            DeRef(_30751);
            _30751 = NOVALUE;
            goto L27; // [762] 766
        }
        DeRef(_30751);
        _30751 = NOVALUE;
    }
    DeRef(_30751);
    _30751 = NOVALUE;
L27: 

    /** parser.e:4823						ExecCommand()*/
    _45ExecCommand();
    goto L28; // [770] 789
L26: 

    /** parser.e:4826					Global_declaration( tok[T_SYM], SC_LOCAL )*/
    _2 = (object)SEQ_PTR(_tok_62301);
    _30752 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30752);
    _30753 = _45Global_declaration(_30752, 5LL);
    _30752 = NOVALUE;
L28: 

    /** parser.e:4829				continue*/
    DeRef(_test_62460);
    _test_62460 = NOVALUE;
    goto L1; // [793] 12
    goto L7; // [797] 1915
L25: 

    /** parser.e:4831			elsif id = CONSTANT then*/
    if (_id_62302 != 417LL)
    goto L29; // [804] 824

    /** parser.e:4832				Global_declaration(0, SC_LOCAL)*/
    _30755 = _45Global_declaration(0LL, 5LL);

    /** parser.e:4833				ExecCommand()*/
    _45ExecCommand();
    goto L7; // [821] 1915
L29: 

    /** parser.e:4835			elsif id = ENUM then*/
    if (_id_62302 != 427LL)
    goto L2A; // [828] 848

    /** parser.e:4836				Global_declaration(-1, SC_LOCAL)*/
    _30757 = _45Global_declaration(-1LL, 5LL);

    /** parser.e:4837				ExecCommand()*/
    _45ExecCommand();
    goto L7; // [845] 1915
L2A: 

    /** parser.e:4839			elsif id = IF then*/
    if (_id_62302 != 20LL)
    goto L2B; // [852] 876

    /** parser.e:4840				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:4841				If_statement()*/
    _45If_statement();

    /** parser.e:4842				ExecCommand()*/
    _45ExecCommand();
    goto L7; // [873] 1915
L2B: 

    /** parser.e:4844			elsif id = FOR then*/
    if (_id_62302 != 21LL)
    goto L2C; // [880] 904

    /** parser.e:4845				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:4846				For_statement()*/
    _45For_statement();

    /** parser.e:4847				ExecCommand()*/
    _45ExecCommand();
    goto L7; // [901] 1915
L2C: 

    /** parser.e:4849			elsif id = WHILE then*/
    if (_id_62302 != 47LL)
    goto L2D; // [908] 932

    /** parser.e:4850				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:4851				While_statement()*/
    _45While_statement();

    /** parser.e:4852				ExecCommand()*/
    _45ExecCommand();
    goto L7; // [929] 1915
L2D: 

    /** parser.e:4854			elsif id = LOOP then*/
    if (_id_62302 != 422LL)
    goto L2E; // [936] 960

    /** parser.e:4855			    StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:4856			    Loop_statement()*/
    _45Loop_statement();

    /** parser.e:4857			    ExecCommand()*/
    _45ExecCommand();
    goto L7; // [957] 1915
L2E: 

    /** parser.e:4859			elsif id = PROC or id = QUALIFIED_PROC then*/
    _30762 = (_id_62302 == 27LL);
    if (_30762 != 0) {
        goto L2F; // [968] 983
    }
    _30764 = (_id_62302 == 521LL);
    if (_30764 == 0)
    {
        DeRef(_30764);
        _30764 = NOVALUE;
        goto L30; // [979] 1024
    }
    else{
        DeRef(_30764);
        _30764 = NOVALUE;
    }
L2F: 

    /** parser.e:4860				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:4861				if id = PROC then*/
    if (_id_62302 != 27LL)
    goto L31; // [996] 1012

    /** parser.e:4863					UndefinedVar( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_62301);
    _30766 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30766);
    _45UndefinedVar(_30766);
    _30766 = NOVALUE;
L31: 

    /** parser.e:4866				Procedure_call(tok)*/
    Ref(_tok_62301);
    _45Procedure_call(_tok_62301);

    /** parser.e:4867				ExecCommand()*/
    _45ExecCommand();
    goto L7; // [1021] 1915
L30: 

    /** parser.e:4869			elsif id = FUNC or id = QUALIFIED_FUNC then*/
    _30767 = (_id_62302 == 501LL);
    if (_30767 != 0) {
        goto L32; // [1032] 1047
    }
    _30769 = (_id_62302 == 520LL);
    if (_30769 == 0)
    {
        DeRef(_30769);
        _30769 = NOVALUE;
        goto L33; // [1043] 1101
    }
    else{
        DeRef(_30769);
        _30769 = NOVALUE;
    }
L32: 

    /** parser.e:4870				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:4871				if id = FUNC then*/
    if (_id_62302 != 501LL)
    goto L34; // [1060] 1076

    /** parser.e:4873					UndefinedVar( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_62301);
    _30771 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_30771);
    _45UndefinedVar(_30771);
    _30771 = NOVALUE;
L34: 

    /** parser.e:4876				Procedure_call(tok)*/
    Ref(_tok_62301);
    _45Procedure_call(_tok_62301);

    /** parser.e:4877				clear_op()*/
    _47clear_op();

    /** parser.e:4878				if Pop() then end if*/
    _30772 = _47Pop();
    if (_30772 == 0) {
        DeRef(_30772);
        _30772 = NOVALUE;
        goto L35; // [1090] 1094
    }
    else {
        if (!IS_ATOM_INT(_30772) && DBL_PTR(_30772)->dbl == 0.0){
            DeRef(_30772);
            _30772 = NOVALUE;
            goto L35; // [1090] 1094
        }
        DeRef(_30772);
        _30772 = NOVALUE;
    }
    DeRef(_30772);
    _30772 = NOVALUE;
L35: 

    /** parser.e:4879				ExecCommand()*/
    _45ExecCommand();
    goto L7; // [1098] 1915
L33: 

    /** parser.e:4881			elsif id = RETURN then*/
    if (_id_62302 != 413LL)
    goto L36; // [1105] 1116

    /** parser.e:4882				Return_statement() -- will fail - not allowed at top level*/
    _45Return_statement();
    goto L7; // [1113] 1915
L36: 

    /** parser.e:4884			elsif id = EXIT then*/
    if (_id_62302 != 61LL)
    goto L37; // [1120] 1158

    /** parser.e:4885				if nested then*/
    if (_nested_62299 == 0)
    {
        goto L38; // [1126] 1145
    }
    else{
    }

    /** parser.e:4886				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:4887				Exit_statement()*/
    _45Exit_statement();
    goto L7; // [1142] 1915
L38: 

    /** parser.e:4889				CompileErr(EXIT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_21993);
    _50CompileErr(89LL, _21993, 0LL);
    goto L7; // [1155] 1915
L37: 

    /** parser.e:4892			elsif id = INCLUDE then*/
    if (_id_62302 != 418LL)
    goto L39; // [1162] 1178

    /** parser.e:4893				IncludeScan( 0 )*/
    _62IncludeScan(0LL);

    /** parser.e:4894				PushGoto()*/
    _45PushGoto();
    goto L7; // [1175] 1915
L39: 

    /** parser.e:4896			elsif id = WITH then*/
    if (_id_62302 != 420LL)
    goto L3A; // [1182] 1196

    /** parser.e:4897				SetWith(TRUE)*/
    _45SetWith(_13TRUE_452);
    goto L7; // [1193] 1915
L3A: 

    /** parser.e:4899			elsif id = WITHOUT then*/
    if (_id_62302 != 421LL)
    goto L3B; // [1200] 1214

    /** parser.e:4900				SetWith(FALSE)*/
    _45SetWith(_13FALSE_450);
    goto L7; // [1211] 1915
L3B: 

    /** parser.e:4902			elsif id = END_OF_FILE then*/
    if (_id_62302 != -21LL)
    goto L3C; // [1218] 1335

    /** parser.e:4903				if IncludePop() then*/
    _30779 = _62IncludePop();
    if (_30779 == 0) {
        DeRef(_30779);
        _30779 = NOVALUE;
        goto L3D; // [1227] 1323
    }
    else {
        if (!IS_ATOM_INT(_30779) && DBL_PTR(_30779)->dbl == 0.0){
            DeRef(_30779);
            _30779 = NOVALUE;
            goto L3D; // [1227] 1323
        }
        DeRef(_30779);
        _30779 = NOVALUE;
    }
    DeRef(_30779);
    _30779 = NOVALUE;

    /** parser.e:4904					backed_up_tok = {}*/
    RefDS(_21993);
    DeRef(_45backed_up_tok_54931);
    _45backed_up_tok_54931 = _21993;

    /** parser.e:4905					PopGoto()*/
    _45PopGoto();

    /** parser.e:4906					read_line()*/
    _62read_line();

    /** parser.e:4908					last_ForwardLine     = ThisLine*/
    Ref(_50ThisLine_49234);
    DeRef(_50last_ForwardLine_49237);
    _50last_ForwardLine_49237 = _50ThisLine_49234;

    /** parser.e:4909					last_fwd_line_number = line_number*/
    _36last_fwd_line_number_21443 = _36line_number_21440;

    /** parser.e:4910					last_forward_bp      = bp*/
    _50last_forward_bp_49241 = _50bp_49238;

    /** parser.e:4912					putback_ForwardLine     = ThisLine*/
    Ref(_50ThisLine_49234);
    DeRef(_50putback_ForwardLine_49236);
    _50putback_ForwardLine_49236 = _50ThisLine_49234;

    /** parser.e:4913					putback_fwd_line_number = line_number*/
    _36putback_fwd_line_number_21442 = _36line_number_21440;

    /** parser.e:4914					putback_forward_bp      = bp*/
    _50putback_forward_bp_49240 = _50bp_49238;

    /** parser.e:4916					ForwardLine     = ThisLine*/
    Ref(_50ThisLine_49234);
    DeRef(_50ForwardLine_49235);
    _50ForwardLine_49235 = _50ThisLine_49234;

    /** parser.e:4917					fwd_line_number = line_number*/
    _36fwd_line_number_21441 = _36line_number_21440;

    /** parser.e:4918					forward_bp      = bp*/
    _50forward_bp_49239 = _50bp_49238;
    goto L7; // [1320] 1915
L3D: 

    /** parser.e:4921					CheckForUndefinedGotoLabels()*/
    _45CheckForUndefinedGotoLabels();

    /** parser.e:4922					exit -- all finished*/
    goto L2; // [1329] 1925
    goto L7; // [1332] 1915
L3C: 

    /** parser.e:4925			elsif id = QUESTION_MARK then*/
    if (_id_62302 != -31LL)
    goto L3E; // [1339] 1363

    /** parser.e:4926				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:4927				Print_statement()*/
    _45Print_statement();

    /** parser.e:4928				ExecCommand()*/
    _45ExecCommand();
    goto L7; // [1360] 1915
L3E: 

    /** parser.e:4930			elsif id = LABEL then*/
    if (_id_62302 != 419LL)
    goto L3F; // [1367] 1389

    /** parser.e:4931				StartSourceLine(TRUE, , COVERAGE_SUPPRESS)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 1LL);

    /** parser.e:4932				GLabel_statement()*/
    _45GLabel_statement();
    goto L7; // [1386] 1915
L3F: 

    /** parser.e:4934			elsif id = GOTO then*/
    if (_id_62302 != 188LL)
    goto L40; // [1393] 1413

    /** parser.e:4935				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:4936				Goto_statement()*/
    _45Goto_statement();
    goto L7; // [1410] 1915
L40: 

    /** parser.e:4938			elsif id = CONTINUE then*/
    if (_id_62302 != 426LL)
    goto L41; // [1417] 1455

    /** parser.e:4939				if nested then*/
    if (_nested_62299 == 0)
    {
        goto L42; // [1423] 1442
    }
    else{
    }

    /** parser.e:4940					StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:4941					Continue_statement()*/
    _45Continue_statement();
    goto L7; // [1439] 1915
L42: 

    /** parser.e:4943					CompileErr(CONTINUE_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_21993);
    _50CompileErr(50LL, _21993, 0LL);
    goto L7; // [1452] 1915
L41: 

    /** parser.e:4946			elsif id = RETRY then*/
    if (_id_62302 != 184LL)
    goto L43; // [1459] 1497

    /** parser.e:4947				if nested then*/
    if (_nested_62299 == 0)
    {
        goto L44; // [1465] 1484
    }
    else{
    }

    /** parser.e:4948					StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:4949					Retry_statement()*/
    _45Retry_statement();
    goto L7; // [1481] 1915
L44: 

    /** parser.e:4951					CompileErr(RETRY_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_21993);
    _50CompileErr(128LL, _21993, 0LL);
    goto L7; // [1494] 1915
L43: 

    /** parser.e:4954			elsif id = BREAK then*/
    if (_id_62302 != 425LL)
    goto L45; // [1501] 1539

    /** parser.e:4955				if nested then*/
    if (_nested_62299 == 0)
    {
        goto L46; // [1507] 1526
    }
    else{
    }

    /** parser.e:4956					StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:4957					Break_statement()*/
    _45Break_statement();
    goto L7; // [1523] 1915
L46: 

    /** parser.e:4959					CompileErr(BREAK_MUST_BE_INSIDE_AN_IF_BLOCK)*/
    RefDS(_21993);
    _50CompileErr(39LL, _21993, 0LL);
    goto L7; // [1536] 1915
L45: 

    /** parser.e:4962			elsif id = ENTRY then*/
    if (_id_62302 != 424LL)
    goto L47; // [1543] 1583

    /** parser.e:4963				if nested then*/
    if (_nested_62299 == 0)
    {
        goto L48; // [1549] 1570
    }
    else{
    }

    /** parser.e:4964				    StartSourceLine(TRUE, , COVERAGE_SUPPRESS)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 1LL);

    /** parser.e:4965				    Entry_statement()*/
    _45Entry_statement();
    goto L7; // [1567] 1915
L48: 

    /** parser.e:4967					CompileErr(ENTRY_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_21993);
    _50CompileErr(72LL, _21993, 0LL);
    goto L7; // [1580] 1915
L47: 

    /** parser.e:4970			elsif id = IFDEF then*/
    if (_id_62302 != 407LL)
    goto L49; // [1587] 1607

    /** parser.e:4971				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:4972				Ifdef_statement()*/
    _45Ifdef_statement();
    goto L7; // [1604] 1915
L49: 

    /** parser.e:4974			elsif id = CASE then*/
    if (_id_62302 != 186LL)
    goto L4A; // [1611] 1622

    /** parser.e:4975				Case_statement()*/
    _45Case_statement();
    goto L7; // [1619] 1915
L4A: 

    /** parser.e:4977			elsif id = SWITCH then*/
    if (_id_62302 != 185LL)
    goto L4B; // [1626] 1646

    /** parser.e:4978				StartSourceLine(TRUE)*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:4979				Switch_statement()*/
    _45Switch_statement();
    goto L7; // [1643] 1915
L4B: 

    /** parser.e:4981			elsif id = LEFT_BRACE then*/
    if (_id_62302 != -24LL)
    goto L4C; // [1650] 1670

    /** parser.e:4982				StartSourceLine( TRUE )*/
    _47StartSourceLine(_13TRUE_452, 0LL, 2LL);

    /** parser.e:4983				Multi_assign()*/
    _45Multi_assign();
    goto L7; // [1667] 1915
L4C: 

    /** parser.e:4985			elsif id = ILLEGAL_CHAR then*/
    if (_id_62302 != -20LL)
    goto L4D; // [1674] 1690

    /** parser.e:4986				CompileErr(ILLEGAL_CHARACTER)*/
    RefDS(_21993);
    _50CompileErr(102LL, _21993, 0LL);
    goto L7; // [1687] 1915
L4D: 

    /** parser.e:4989				if nested then*/
    if (_nested_62299 == 0)
    {
        goto L4E; // [1692] 1852
    }
    else{
    }

    /** parser.e:4990					if id = ELSE then*/
    if (_id_62302 != 23LL)
    goto L4F; // [1699] 1757

    /** parser.e:4991						if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_45if_stack_54959)){
            _30793 = SEQ_PTR(_45if_stack_54959)->length;
    }
    else {
        _30793 = 1;
    }
    if (_30793 != 0LL)
    goto L50; // [1710] 1818

    /** parser.e:4992							if live_ifdef > 0 then*/
    if (_45live_ifdef_59426 <= 0LL)
    goto L51; // [1718] 1743

    /** parser.e:4993								CompileErr(SHOULD_THIS_BE_ELSEDEF_FOR_THE_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_45ifdef_lineno_59427)){
            _30796 = SEQ_PTR(_45ifdef_lineno_59427)->length;
    }
    else {
        _30796 = 1;
    }
    _2 = (object)SEQ_PTR(_45ifdef_lineno_59427);
    _30797 = (object)*(((s1_ptr)_2)->base + _30796);
    _50CompileErr(134LL, _30797, 0LL);
    _30797 = NOVALUE;
    goto L50; // [1740] 1818
L51: 

    /** parser.e:4995								CompileErr(NOT_EXPECTING_ELSE)*/
    RefDS(_21993);
    _50CompileErr(118LL, _21993, 0LL);
    goto L50; // [1754] 1818
L4F: 

    /** parser.e:4998					elsif id = ELSIF then*/
    if (_id_62302 != 414LL)
    goto L52; // [1761] 1817

    /** parser.e:4999						if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_45if_stack_54959)){
            _30799 = SEQ_PTR(_45if_stack_54959)->length;
    }
    else {
        _30799 = 1;
    }
    if (_30799 != 0LL)
    goto L53; // [1772] 1816

    /** parser.e:5000							if live_ifdef > 0 then*/
    if (_45live_ifdef_59426 <= 0LL)
    goto L54; // [1780] 1805

    /** parser.e:5001								CompileErr(SHOULD_THIS_BE_ELSIFDEF_FOR_THE_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_45ifdef_lineno_59427)){
            _30802 = SEQ_PTR(_45ifdef_lineno_59427)->length;
    }
    else {
        _30802 = 1;
    }
    _2 = (object)SEQ_PTR(_45ifdef_lineno_59427);
    _30803 = (object)*(((s1_ptr)_2)->base + _30802);
    _50CompileErr(139LL, _30803, 0LL);
    _30803 = NOVALUE;
    goto L55; // [1802] 1815
L54: 

    /** parser.e:5003								CompileErr(NOT_EXPECTING_ELSIF)*/
    RefDS(_21993);
    _50CompileErr(119LL, _21993, 0LL);
L55: 
L53: 
L52: 
L50: 

    /** parser.e:5007					putback(tok)*/
    Ref(_tok_62301);
    _45putback(_tok_62301);

    /** parser.e:5008					if stmt_nest > 0 then*/
    if (_45stmt_nest_54956 <= 0LL)
    goto L56; // [1827] 1844

    /** parser.e:5009						stmt_nest -= 1*/
    _45stmt_nest_54956 = _45stmt_nest_54956 - 1LL;

    /** parser.e:5010						InitDelete()*/
    _45InitDelete();
L56: 

    /** parser.e:5012					return*/
    DeRef(_tok_62301);
    DeRef(_30721);
    _30721 = NOVALUE;
    DeRef(_30745);
    _30745 = NOVALUE;
    DeRef(_30723);
    _30723 = NOVALUE;
    DeRef(_30700);
    _30700 = NOVALUE;
    DeRef(_30734);
    _30734 = NOVALUE;
    DeRef(_30717);
    _30717 = NOVALUE;
    _30738 = NOVALUE;
    _30686 = NOVALUE;
    DeRef(_30692);
    _30692 = NOVALUE;
    DeRef(_30698);
    _30698 = NOVALUE;
    DeRef(_30731);
    _30731 = NOVALUE;
    DeRef(_30683);
    _30683 = NOVALUE;
    DeRef(_30728);
    _30728 = NOVALUE;
    DeRef(_30755);
    _30755 = NOVALUE;
    DeRef(_30762);
    _30762 = NOVALUE;
    DeRef(_30702);
    _30702 = NOVALUE;
    DeRef(_30736);
    _30736 = NOVALUE;
    DeRef(_30753);
    _30753 = NOVALUE;
    DeRef(_30694);
    _30694 = NOVALUE;
    DeRef(_30767);
    _30767 = NOVALUE;
    DeRef(_30689);
    _30689 = NOVALUE;
    DeRef(_30741);
    _30741 = NOVALUE;
    DeRef(_30757);
    _30757 = NOVALUE;
    DeRef(_30725);
    _30725 = NOVALUE;
    DeRef(_30704);
    _30704 = NOVALUE;
    DeRef(_30726);
    _30726 = NOVALUE;
    return;
    goto L57; // [1849] 1914
L4E: 

    /** parser.e:5014					if id = END then*/
    if (_id_62302 != 402LL)
    goto L58; // [1856] 1889

    /** parser.e:5015						tok = next_token()*/
    _0 = _tok_62301;
    _tok_62301 = _45next_token();
    DeRef(_0);

    /** parser.e:5016						CompileErr(MSG_END_HAS_NO_MATCHING_1, {find_token_text(tok[T_ID])})*/
    _2 = (object)SEQ_PTR(_tok_62301);
    _30808 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_30808);
    _30809 = _63find_token_text(_30808);
    _30808 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30809;
    _30810 = MAKE_SEQ(_1);
    _30809 = NOVALUE;
    _50CompileErr(17LL, _30810, 0LL);
    _30810 = NOVALUE;
L58: 

    /** parser.e:5019					CompileErr(NOT_EXPECTING_TO_SEE_1_HERE, { match_replace(",", find_token_text(id), "") })*/
    _30811 = _63find_token_text(_id_62302);
    RefDS(_26152);
    RefDS(_21993);
    _30812 = _16match_replace(_26152, _30811, _21993, 0LL);
    _30811 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30812;
    _30813 = MAKE_SEQ(_1);
    _30812 = NOVALUE;
    _50CompileErr(117LL, _30813, 0LL);
    _30813 = NOVALUE;
L57: 
L7: 

    /** parser.e:5024			flush_temps()*/
    RefDS(_21993);
    _47flush_temps(_21993);

    /** parser.e:5025		end while*/
    goto L1; // [1922] 12
L2: 

    /** parser.e:5026		emit_op(RETURNT)*/
    _47emit_op(34LL);

    /** parser.e:5027		clear_last()*/
    _47clear_last();

    /** parser.e:5028		StraightenBranches()*/
    _45StraightenBranches();

    /** parser.e:5029		SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21446 + ((s1_ptr)_2)->base);
    RefDS(_36Code_21531);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21088))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21088);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36Code_21531;
    DeRef(_1);
    _30814 = NOVALUE;

    /** parser.e:5030		EndLineTable()*/
    _45EndLineTable();

    /** parser.e:5031		SymTab[TopLevelSub][S_LINETAB] = LineTable*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21446 + ((s1_ptr)_2)->base);
    RefDS(_36LineTable_21532);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_LINETAB_21111))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21111)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21111);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36LineTable_21532;
    DeRef(_1);
    _30816 = NOVALUE;

    /** parser.e:5032	end procedure*/
    DeRef(_tok_62301);
    DeRef(_30721);
    _30721 = NOVALUE;
    DeRef(_30745);
    _30745 = NOVALUE;
    DeRef(_30723);
    _30723 = NOVALUE;
    DeRef(_30700);
    _30700 = NOVALUE;
    DeRef(_30734);
    _30734 = NOVALUE;
    DeRef(_30717);
    _30717 = NOVALUE;
    _30738 = NOVALUE;
    _30686 = NOVALUE;
    DeRef(_30692);
    _30692 = NOVALUE;
    DeRef(_30698);
    _30698 = NOVALUE;
    DeRef(_30731);
    _30731 = NOVALUE;
    DeRef(_30683);
    _30683 = NOVALUE;
    DeRef(_30728);
    _30728 = NOVALUE;
    DeRef(_30755);
    _30755 = NOVALUE;
    DeRef(_30762);
    _30762 = NOVALUE;
    DeRef(_30702);
    _30702 = NOVALUE;
    DeRef(_30736);
    _30736 = NOVALUE;
    DeRef(_30753);
    _30753 = NOVALUE;
    DeRef(_30694);
    _30694 = NOVALUE;
    DeRef(_30767);
    _30767 = NOVALUE;
    DeRef(_30689);
    _30689 = NOVALUE;
    DeRef(_30741);
    _30741 = NOVALUE;
    DeRef(_30757);
    _30757 = NOVALUE;
    DeRef(_30725);
    _30725 = NOVALUE;
    DeRef(_30704);
    _30704 = NOVALUE;
    DeRef(_30726);
    _30726 = NOVALUE;
    return;
    ;
}


void _45parser()
{
    object _30820 = NOVALUE;
    object _30818 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:5035		real_parser(0)*/
    _45real_parser(0LL);

    /** parser.e:5036		mark_final_targets()*/
    _54mark_final_targets();

    /** parser.e:5037		resolve_unincluded_globals( 1 )*/
    _54resolve_unincluded_globals(1LL);

    /** parser.e:5038		Resolve_forward_references( 1 )*/
    _44Resolve_forward_references(1LL);

    /** parser.e:5039		SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21446 + ((s1_ptr)_2)->base);
    RefDS(_36Code_21531);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21088))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21088);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36Code_21531;
    DeRef(_1);
    _30818 = NOVALUE;

    /** parser.e:5040		SymTab[TopLevelSub][S_LINETAB] = LineTable*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21446 + ((s1_ptr)_2)->base);
    RefDS(_36LineTable_21532);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_LINETAB_21111))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21111)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21111);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36LineTable_21532;
    DeRef(_1);
    _30820 = NOVALUE;

    /** parser.e:5041		Code = {}*/
    RefDS(_21993);
    DeRefDS(_36Code_21531);
    _36Code_21531 = _21993;

    /** parser.e:5042		LineTable = {}*/
    RefDS(_21993);
    DeRefDS(_36LineTable_21532);
    _36LineTable_21532 = _21993;

    /** parser.e:5043		inline_deferred_calls()*/
    _67inline_deferred_calls();

    /** parser.e:5044		if not repl then*/

    /** parser.e:5045		End_block( PROC )*/
    _65End_block(27LL);

    /** parser.e:5046		Code = {}*/
    RefDS(_21993);
    DeRefDS(_36Code_21531);
    _36Code_21531 = _21993;

    /** parser.e:5047		LineTable = {}*/
    RefDS(_21993);
    DeRefDS(_36LineTable_21532);
    _36LineTable_21532 = _21993;

    /** parser.e:5049	end procedure*/
    return;
    ;
}


void _45nested_parser()
{
    object _0, _1, _2;
    

    /** parser.e:5052		real_parser(1)*/
    _45real_parser(1LL);

    /** parser.e:5053	end procedure*/
    return;
    ;
}



// 0xA5C2DB29
