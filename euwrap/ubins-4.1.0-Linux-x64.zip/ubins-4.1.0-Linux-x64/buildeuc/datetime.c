// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _18isLeap(object _year_2307)
{
    object _ly_2308 = NOVALUE;
    object _1031 = NOVALUE;
    object _1030 = NOVALUE;
    object _1029 = NOVALUE;
    object _1028 = NOVALUE;
    object _1027 = NOVALUE;
    object _1026 = NOVALUE;
    object _1025 = NOVALUE;
    object _1024 = NOVALUE;
    object _1023 = NOVALUE;
    object _1020 = NOVALUE;
    object _1018 = NOVALUE;
    object _1017 = NOVALUE;
    object _0, _1, _2;
    

    /** datetime.e:89			ly = (remainder(year, {4, 100, 400, 3200, 80000})=0)*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 4LL;
    ((intptr_t*)_2)[2] = 100LL;
    ((intptr_t*)_2)[3] = 400LL;
    ((intptr_t*)_2)[4] = 3200LL;
    ((intptr_t*)_2)[5] = 80000LL;
    _1017 = MAKE_SEQ(_1);
    _1018 = binary_op(REMAINDER, _year_2307, _1017);
    DeRefDS(_1017);
    _1017 = NOVALUE;
    DeRefi(_ly_2308);
    _ly_2308 = binary_op(EQUALS, _1018, 0LL);
    DeRefDS(_1018);
    _1018 = NOVALUE;

    /** datetime.e:91			if not ly[1] then return 0 end if*/
    _2 = (object)SEQ_PTR(_ly_2308);
    _1020 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (_1020 != 0)
    goto L1; // [29] 37
    _1020 = NOVALUE;
    DeRefDSi(_ly_2308);
    return 0LL;
L1: 

    /** datetime.e:93			if year <= Gregorian_Reformation then*/
    if (_year_2307 > 1752LL)
    goto L2; // [39] 52

    /** datetime.e:94					return 1 -- ly[1] can't possibly be 0 here so set shortcut as '1'.*/
    DeRefi(_ly_2308);
    return 1LL;
    goto L3; // [49] 95
L2: 

    /** datetime.e:96					return ly[1] - ly[2] + ly[3] - ly[4] + ly[5]*/
    _2 = (object)SEQ_PTR(_ly_2308);
    _1023 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_ly_2308);
    _1024 = (object)*(((s1_ptr)_2)->base + 2LL);
    _1025 = _1023 - _1024;
    if ((object)((uintptr_t)_1025 +(uintptr_t) HIGH_BITS) >= 0){
        _1025 = NewDouble((eudouble)_1025);
    }
    _1023 = NOVALUE;
    _1024 = NOVALUE;
    _2 = (object)SEQ_PTR(_ly_2308);
    _1026 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (IS_ATOM_INT(_1025)) {
        _1027 = _1025 + _1026;
        if ((object)((uintptr_t)_1027 + (uintptr_t)HIGH_BITS) >= 0){
            _1027 = NewDouble((eudouble)_1027);
        }
    }
    else {
        _1027 = NewDouble(DBL_PTR(_1025)->dbl + (eudouble)_1026);
    }
    DeRef(_1025);
    _1025 = NOVALUE;
    _1026 = NOVALUE;
    _2 = (object)SEQ_PTR(_ly_2308);
    _1028 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_1027)) {
        _1029 = _1027 - _1028;
        if ((object)((uintptr_t)_1029 +(uintptr_t) HIGH_BITS) >= 0){
            _1029 = NewDouble((eudouble)_1029);
        }
    }
    else {
        _1029 = NewDouble(DBL_PTR(_1027)->dbl - (eudouble)_1028);
    }
    DeRef(_1027);
    _1027 = NOVALUE;
    _1028 = NOVALUE;
    _2 = (object)SEQ_PTR(_ly_2308);
    _1030 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (IS_ATOM_INT(_1029)) {
        _1031 = _1029 + _1030;
        if ((object)((uintptr_t)_1031 + (uintptr_t)HIGH_BITS) >= 0){
            _1031 = NewDouble((eudouble)_1031);
        }
    }
    else {
        _1031 = NewDouble(DBL_PTR(_1029)->dbl + (eudouble)_1030);
    }
    DeRef(_1029);
    _1029 = NOVALUE;
    _1030 = NOVALUE;
    DeRefDSi(_ly_2308);
    return _1031;
L3: 
    ;
}


object _18daysInMonth(object _year_2332, object _month_2333)
{
    object _1039 = NOVALUE;
    object _1038 = NOVALUE;
    object _1037 = NOVALUE;
    object _1036 = NOVALUE;
    object _1034 = NOVALUE;
    object _1033 = NOVALUE;
    object _1032 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_month_2333)) {
        _1 = (object)(DBL_PTR(_month_2333)->dbl);
        DeRefDS(_month_2333);
        _month_2333 = _1;
    }

    /** datetime.e:101		if year = Gregorian_Reformation and month = 9 then*/
    _1032 = (_year_2332 == 1752LL);
    if (_1032 == 0) {
        goto L1; // [11] 32
    }
    _1034 = (_month_2333 == 9LL);
    if (_1034 == 0)
    {
        DeRef(_1034);
        _1034 = NOVALUE;
        goto L1; // [20] 32
    }
    else{
        DeRef(_1034);
        _1034 = NOVALUE;
    }

    /** datetime.e:102			return 19*/
    DeRef(_1032);
    _1032 = NOVALUE;
    return 19LL;
    goto L2; // [29] 70
L1: 

    /** datetime.e:103		elsif month != 2 then*/
    if (_month_2333 == 2LL)
    goto L3; // [34] 51

    /** datetime.e:104			return DaysPerMonth[month]*/
    _2 = (object)SEQ_PTR(_18DaysPerMonth_2290);
    _1036 = (object)*(((s1_ptr)_2)->base + _month_2333);
    Ref(_1036);
    DeRef(_1032);
    _1032 = NOVALUE;
    return _1036;
    goto L2; // [48] 70
L3: 

    /** datetime.e:106			return DaysPerMonth[month] + isLeap(year)*/
    _2 = (object)SEQ_PTR(_18DaysPerMonth_2290);
    _1037 = (object)*(((s1_ptr)_2)->base + _month_2333);
    _1038 = _18isLeap(_year_2332);
    if (IS_ATOM_INT(_1037) && IS_ATOM_INT(_1038)) {
        _1039 = _1037 + _1038;
        if ((object)((uintptr_t)_1039 + (uintptr_t)HIGH_BITS) >= 0){
            _1039 = NewDouble((eudouble)_1039);
        }
    }
    else {
        _1039 = binary_op(PLUS, _1037, _1038);
    }
    _1037 = NOVALUE;
    DeRef(_1038);
    _1038 = NOVALUE;
    _1036 = NOVALUE;
    DeRef(_1032);
    _1032 = NOVALUE;
    return _1039;
L2: 
    ;
}


object _18julianDayOfYear(object _ymd_2356)
{
    object _year_2357 = NOVALUE;
    object _month_2358 = NOVALUE;
    object _day_2359 = NOVALUE;
    object _d_2360 = NOVALUE;
    object _1055 = NOVALUE;
    object _1054 = NOVALUE;
    object _1053 = NOVALUE;
    object _1050 = NOVALUE;
    object _1049 = NOVALUE;
    object _0, _1, _2;
    

    /** datetime.e:124		year = ymd[1]*/
    _2 = (object)SEQ_PTR(_ymd_2356);
    _year_2357 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_year_2357)){
        _year_2357 = (object)DBL_PTR(_year_2357)->dbl;
    }

    /** datetime.e:125		month = ymd[2]*/
    _2 = (object)SEQ_PTR(_ymd_2356);
    _month_2358 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_month_2358)){
        _month_2358 = (object)DBL_PTR(_month_2358)->dbl;
    }

    /** datetime.e:126		day = ymd[3]*/
    _2 = (object)SEQ_PTR(_ymd_2356);
    _day_2359 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_day_2359)){
        _day_2359 = (object)DBL_PTR(_day_2359)->dbl;
    }

    /** datetime.e:128		if month = 1 then return day end if*/
    if (_month_2358 != 1LL)
    goto L1; // [27] 36
    DeRef(_ymd_2356);
    return _day_2359;
L1: 

    /** datetime.e:130		d = 0*/
    _d_2360 = 0LL;

    /** datetime.e:131		for i = 1 to month - 1 do*/
    _1049 = _month_2358 - 1LL;
    if ((object)((uintptr_t)_1049 +(uintptr_t) HIGH_BITS) >= 0){
        _1049 = NewDouble((eudouble)_1049);
    }
    {
        object _i_2367;
        _i_2367 = 1LL;
L2: 
        if (binary_op_a(GREATER, _i_2367, _1049)){
            goto L3; // [47] 74
        }

        /** datetime.e:132			d += daysInMonth(year, i)*/
        Ref(_i_2367);
        _1050 = _18daysInMonth(_year_2357, _i_2367);
        if (IS_ATOM_INT(_1050)) {
            _d_2360 = _d_2360 + _1050;
        }
        else {
            _d_2360 = binary_op(PLUS, _d_2360, _1050);
        }
        DeRef(_1050);
        _1050 = NOVALUE;
        if (!IS_ATOM_INT(_d_2360)) {
            _1 = (object)(DBL_PTR(_d_2360)->dbl);
            DeRefDS(_d_2360);
            _d_2360 = _1;
        }

        /** datetime.e:133		end for*/
        _0 = _i_2367;
        if (IS_ATOM_INT(_i_2367)) {
            _i_2367 = _i_2367 + 1LL;
            if ((object)((uintptr_t)_i_2367 +(uintptr_t) HIGH_BITS) >= 0){
                _i_2367 = NewDouble((eudouble)_i_2367);
            }
        }
        else {
            _i_2367 = binary_op_a(PLUS, _i_2367, 1LL);
        }
        DeRef(_0);
        goto L2; // [69] 54
L3: 
        ;
        DeRef(_i_2367);
    }

    /** datetime.e:135		d += day*/
    _d_2360 = _d_2360 + _day_2359;

    /** datetime.e:137		if year = Gregorian_Reformation and month = 9 then*/
    _1053 = (_year_2357 == 1752LL);
    if (_1053 == 0) {
        goto L4; // [86] 128
    }
    _1055 = (_month_2358 == 9LL);
    if (_1055 == 0)
    {
        DeRef(_1055);
        _1055 = NOVALUE;
        goto L4; // [95] 128
    }
    else{
        DeRef(_1055);
        _1055 = NOVALUE;
    }

    /** datetime.e:138			if day > 13 then*/
    if (_day_2359 <= 13LL)
    goto L5; // [100] 113

    /** datetime.e:139				d -= 11*/
    _d_2360 = _d_2360 - 11LL;
    goto L6; // [110] 127
L5: 

    /** datetime.e:140			elsif day > 2 then*/
    if (_day_2359 <= 2LL)
    goto L7; // [115] 126

    /** datetime.e:141				return 0*/
    DeRef(_ymd_2356);
    DeRef(_1049);
    _1049 = NOVALUE;
    DeRef(_1053);
    _1053 = NOVALUE;
    return 0LL;
L7: 
L6: 
L4: 

    /** datetime.e:145		return d*/
    DeRef(_ymd_2356);
    DeRef(_1049);
    _1049 = NOVALUE;
    DeRef(_1053);
    _1053 = NOVALUE;
    return _d_2360;
    ;
}


object _18julianDay(object _ymd_2383)
{
    object _year_2384 = NOVALUE;
    object _j_2385 = NOVALUE;
    object _greg00_2386 = NOVALUE;
    object _1084 = NOVALUE;
    object _1081 = NOVALUE;
    object _1078 = NOVALUE;
    object _1077 = NOVALUE;
    object _1076 = NOVALUE;
    object _1075 = NOVALUE;
    object _1074 = NOVALUE;
    object _1073 = NOVALUE;
    object _1072 = NOVALUE;
    object _1071 = NOVALUE;
    object _1069 = NOVALUE;
    object _1068 = NOVALUE;
    object _1067 = NOVALUE;
    object _1066 = NOVALUE;
    object _1065 = NOVALUE;
    object _1064 = NOVALUE;
    object _1063 = NOVALUE;
    object _0, _1, _2;
    

    /** datetime.e:152		year = ymd[1]*/
    _2 = (object)SEQ_PTR(_ymd_2383);
    _year_2384 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_year_2384)){
        _year_2384 = (object)DBL_PTR(_year_2384)->dbl;
    }

    /** datetime.e:153		j = julianDayOfYear(ymd)*/
    Ref(_ymd_2383);
    _j_2385 = _18julianDayOfYear(_ymd_2383);
    if (!IS_ATOM_INT(_j_2385)) {
        _1 = (object)(DBL_PTR(_j_2385)->dbl);
        DeRefDS(_j_2385);
        _j_2385 = _1;
    }

    /** datetime.e:155		year  -= 1*/
    _year_2384 = _year_2384 - 1LL;

    /** datetime.e:156		greg00 = year - Gregorian_Reformation00*/
    _greg00_2386 = _year_2384 - 1700LL;

    /** datetime.e:158		j += (*/
    {
        int128_t p128 = (int128_t)365LL * (int128_t)_year_2384;
        if( p128 != (int128_t)(_1063 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
            _1063 = NewDouble( (eudouble)p128 );
        }
    }
    if (4LL > 0 && _year_2384 >= 0) {
        _1064 = _year_2384 / 4LL;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_year_2384 / (eudouble)4LL);
        _1064 = (object)temp_dbl;
    }
    if (IS_ATOM_INT(_1063)) {
        _1065 = _1063 + _1064;
        if ((object)((uintptr_t)_1065 + (uintptr_t)HIGH_BITS) >= 0){
            _1065 = NewDouble((eudouble)_1065);
        }
    }
    else {
        _1065 = NewDouble(DBL_PTR(_1063)->dbl + (eudouble)_1064);
    }
    DeRef(_1063);
    _1063 = NOVALUE;
    _1064 = NOVALUE;
    _1066 = (_greg00_2386 > 0LL);
    if (100LL > 0 && _greg00_2386 >= 0) {
        _1067 = _greg00_2386 / 100LL;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_greg00_2386 / (eudouble)100LL);
        _1067 = (object)temp_dbl;
    }
    _1068 = - _1067;
    _1069 = (_greg00_2386 % 400LL) ? NewDouble((eudouble)_greg00_2386 / 400LL) : (_greg00_2386 / 400LL);
    if (IS_ATOM_INT(_1069)) {
        _1071 = NewDouble((eudouble)_1069 + DBL_PTR(_1070)->dbl);
    }
    else {
        _1071 = NewDouble(DBL_PTR(_1069)->dbl + DBL_PTR(_1070)->dbl);
    }
    DeRef(_1069);
    _1069 = NOVALUE;
    _1072 = unary_op(FLOOR, _1071);
    DeRefDS(_1071);
    _1071 = NOVALUE;
    if (IS_ATOM_INT(_1072)) {
        _1073 = _1068 + _1072;
        if ((object)((uintptr_t)_1073 + (uintptr_t)HIGH_BITS) >= 0){
            _1073 = NewDouble((eudouble)_1073);
        }
    }
    else {
        _1073 = binary_op(PLUS, _1068, _1072);
    }
    _1068 = NOVALUE;
    DeRef(_1072);
    _1072 = NOVALUE;
    if (IS_ATOM_INT(_1073)) {
        {
            int128_t p128 = (int128_t)_1066 * (int128_t)_1073;
            if( p128 != (int128_t)(_1074 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _1074 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _1074 = binary_op(MULTIPLY, _1066, _1073);
    }
    _1066 = NOVALUE;
    DeRef(_1073);
    _1073 = NOVALUE;
    if (IS_ATOM_INT(_1065) && IS_ATOM_INT(_1074)) {
        _1075 = _1065 + _1074;
        if ((object)((uintptr_t)_1075 + (uintptr_t)HIGH_BITS) >= 0){
            _1075 = NewDouble((eudouble)_1075);
        }
    }
    else {
        _1075 = binary_op(PLUS, _1065, _1074);
    }
    DeRef(_1065);
    _1065 = NOVALUE;
    DeRef(_1074);
    _1074 = NOVALUE;
    _1076 = (_year_2384 >= 1752LL);
    _1077 = 11LL * _1076;
    _1076 = NOVALUE;
    if (IS_ATOM_INT(_1075)) {
        _1078 = _1075 - _1077;
        if ((object)((uintptr_t)_1078 +(uintptr_t) HIGH_BITS) >= 0){
            _1078 = NewDouble((eudouble)_1078);
        }
    }
    else {
        _1078 = binary_op(MINUS, _1075, _1077);
    }
    DeRef(_1075);
    _1075 = NOVALUE;
    _1077 = NOVALUE;
    if (IS_ATOM_INT(_1078)) {
        _j_2385 = _j_2385 + _1078;
    }
    else {
        _j_2385 = binary_op(PLUS, _j_2385, _1078);
    }
    DeRef(_1078);
    _1078 = NOVALUE;
    if (!IS_ATOM_INT(_j_2385)) {
        _1 = (object)(DBL_PTR(_j_2385)->dbl);
        DeRefDS(_j_2385);
        _j_2385 = _1;
    }

    /** datetime.e:169		if year >= 3200 then*/
    if (_year_2384 < 3200LL)
    goto L1; // [97] 133

    /** datetime.e:170			j -= floor(year/ 3200)*/
    if (3200LL > 0 && _year_2384 >= 0) {
        _1081 = _year_2384 / 3200LL;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_year_2384 / (eudouble)3200LL);
        _1081 = (object)temp_dbl;
    }
    _j_2385 = _j_2385 - _1081;
    _1081 = NOVALUE;

    /** datetime.e:171			if year >= 80000 then*/
    if (_year_2384 < 80000LL)
    goto L2; // [115] 132

    /** datetime.e:172				j += floor(year/80000)*/
    if (80000LL > 0 && _year_2384 >= 0) {
        _1084 = _year_2384 / 80000LL;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_year_2384 / (eudouble)80000LL);
        _1084 = (object)temp_dbl;
    }
    _j_2385 = _j_2385 + _1084;
    _1084 = NOVALUE;
L2: 
L1: 

    /** datetime.e:176		return j*/
    DeRef(_ymd_2383);
    DeRef(_1067);
    _1067 = NOVALUE;
    return _j_2385;
    ;
}


object _18datetimeToSeconds(object _dt_2472)
{
    object _1128 = NOVALUE;
    object _1127 = NOVALUE;
    object _1126 = NOVALUE;
    object _1125 = NOVALUE;
    object _1124 = NOVALUE;
    object _1123 = NOVALUE;
    object _1122 = NOVALUE;
    object _1120 = NOVALUE;
    object _1119 = NOVALUE;
    object _1118 = NOVALUE;
    object _0, _1, _2;
    

    /** datetime.e:226		return julianDay(dt) * DayLengthInSeconds + (dt[4] * 60 + dt[5]) * 60 + dt[6]*/
    Ref(_dt_2472);
    _1118 = _18julianDay(_dt_2472);
    if (IS_ATOM_INT(_1118)) {
        {
            int128_t p128 = (int128_t)_1118 * (int128_t)86400LL;
            if( p128 != (int128_t)(_1119 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _1119 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _1119 = binary_op(MULTIPLY, _1118, 86400LL);
    }
    DeRef(_1118);
    _1118 = NOVALUE;
    _2 = (object)SEQ_PTR(_dt_2472);
    _1120 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_1120)) {
        {
            int128_t p128 = (int128_t)_1120 * (int128_t)60LL;
            if( p128 != (int128_t)(_1122 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _1122 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _1122 = binary_op(MULTIPLY, _1120, 60LL);
    }
    _1120 = NOVALUE;
    _2 = (object)SEQ_PTR(_dt_2472);
    _1123 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (IS_ATOM_INT(_1122) && IS_ATOM_INT(_1123)) {
        _1124 = _1122 + _1123;
        if ((object)((uintptr_t)_1124 + (uintptr_t)HIGH_BITS) >= 0){
            _1124 = NewDouble((eudouble)_1124);
        }
    }
    else {
        _1124 = binary_op(PLUS, _1122, _1123);
    }
    DeRef(_1122);
    _1122 = NOVALUE;
    _1123 = NOVALUE;
    if (IS_ATOM_INT(_1124)) {
        {
            int128_t p128 = (int128_t)_1124 * (int128_t)60LL;
            if( p128 != (int128_t)(_1125 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _1125 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _1125 = binary_op(MULTIPLY, _1124, 60LL);
    }
    DeRef(_1124);
    _1124 = NOVALUE;
    if (IS_ATOM_INT(_1119) && IS_ATOM_INT(_1125)) {
        _1126 = _1119 + _1125;
        if ((object)((uintptr_t)_1126 + (uintptr_t)HIGH_BITS) >= 0){
            _1126 = NewDouble((eudouble)_1126);
        }
    }
    else {
        _1126 = binary_op(PLUS, _1119, _1125);
    }
    DeRef(_1119);
    _1119 = NOVALUE;
    DeRef(_1125);
    _1125 = NOVALUE;
    _2 = (object)SEQ_PTR(_dt_2472);
    _1127 = (object)*(((s1_ptr)_2)->base + 6LL);
    if (IS_ATOM_INT(_1126) && IS_ATOM_INT(_1127)) {
        _1128 = _1126 + _1127;
        if ((object)((uintptr_t)_1128 + (uintptr_t)HIGH_BITS) >= 0){
            _1128 = NewDouble((eudouble)_1128);
        }
    }
    else {
        _1128 = binary_op(PLUS, _1126, _1127);
    }
    DeRef(_1126);
    _1126 = NOVALUE;
    _1127 = NOVALUE;
    DeRef(_dt_2472);
    return _1128;
    ;
}


object _18from_date(object _src_2639)
{
    object _1243 = NOVALUE;
    object _1242 = NOVALUE;
    object _1241 = NOVALUE;
    object _1240 = NOVALUE;
    object _1239 = NOVALUE;
    object _1238 = NOVALUE;
    object _1237 = NOVALUE;
    object _1235 = NOVALUE;
    object _0, _1, _2;
    

    /** datetime.e:513		return {src[YEAR]+1900, src[MONTH], src[DAY], src[HOUR], src[MINUTE], src[SECOND]}*/
    _2 = (object)SEQ_PTR(_src_2639);
    _1235 = (object)*(((s1_ptr)_2)->base + 1LL);
    _1237 = _1235 + 1900LL;
    if ((object)((uintptr_t)_1237 + (uintptr_t)HIGH_BITS) >= 0){
        _1237 = NewDouble((eudouble)_1237);
    }
    _1235 = NOVALUE;
    _2 = (object)SEQ_PTR(_src_2639);
    _1238 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_src_2639);
    _1239 = (object)*(((s1_ptr)_2)->base + 3LL);
    _2 = (object)SEQ_PTR(_src_2639);
    _1240 = (object)*(((s1_ptr)_2)->base + 4LL);
    _2 = (object)SEQ_PTR(_src_2639);
    _1241 = (object)*(((s1_ptr)_2)->base + 5LL);
    _2 = (object)SEQ_PTR(_src_2639);
    _1242 = (object)*(((s1_ptr)_2)->base + 6LL);
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _1237;
    ((intptr_t*)_2)[2] = _1238;
    ((intptr_t*)_2)[3] = _1239;
    ((intptr_t*)_2)[4] = _1240;
    ((intptr_t*)_2)[5] = _1241;
    ((intptr_t*)_2)[6] = _1242;
    _1243 = MAKE_SEQ(_1);
    _1242 = NOVALUE;
    _1241 = NOVALUE;
    _1240 = NOVALUE;
    _1239 = NOVALUE;
    _1238 = NOVALUE;
    _1237 = NOVALUE;
    DeRefDSi(_src_2639);
    return _1243;
    ;
}


object _18new(object _year_2671, object _month_2672, object _day_2673, object _hour_2674, object _minute_2675, object _second_2676)
{
    object _d_2677 = NOVALUE;
    object _now_1__tmp_at41_2684 = NOVALUE;
    object _now_inlined_now_at_41_2683 = NOVALUE;
    object _1258 = NOVALUE;
    object _1257 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_year_2671)) {
        _1 = (object)(DBL_PTR(_year_2671)->dbl);
        DeRefDS(_year_2671);
        _year_2671 = _1;
    }
    if (!IS_ATOM_INT(_month_2672)) {
        _1 = (object)(DBL_PTR(_month_2672)->dbl);
        DeRefDS(_month_2672);
        _month_2672 = _1;
    }
    if (!IS_ATOM_INT(_day_2673)) {
        _1 = (object)(DBL_PTR(_day_2673)->dbl);
        DeRefDS(_day_2673);
        _day_2673 = _1;
    }
    if (!IS_ATOM_INT(_hour_2674)) {
        _1 = (object)(DBL_PTR(_hour_2674)->dbl);
        DeRefDS(_hour_2674);
        _hour_2674 = _1;
    }
    if (!IS_ATOM_INT(_minute_2675)) {
        _1 = (object)(DBL_PTR(_minute_2675)->dbl);
        DeRefDS(_minute_2675);
        _minute_2675 = _1;
    }

    /** datetime.e:587		d = {year, month, day, hour, minute, second}*/
    _0 = _d_2677;
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _year_2671;
    ((intptr_t*)_2)[2] = _month_2672;
    ((intptr_t*)_2)[3] = _day_2673;
    ((intptr_t*)_2)[4] = _hour_2674;
    ((intptr_t*)_2)[5] = _minute_2675;
    Ref(_second_2676);
    ((intptr_t*)_2)[6] = _second_2676;
    _d_2677 = MAKE_SEQ(_1);
    DeRef(_0);

    /** datetime.e:588		if equal(d, {0,0,0,0,0,0}) then*/
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0LL;
    ((intptr_t*)_2)[2] = 0LL;
    ((intptr_t*)_2)[3] = 0LL;
    ((intptr_t*)_2)[4] = 0LL;
    ((intptr_t*)_2)[5] = 0LL;
    ((intptr_t*)_2)[6] = 0LL;
    _1257 = MAKE_SEQ(_1);
    if (_d_2677 == _1257)
    _1258 = 1;
    else if (IS_ATOM_INT(_d_2677) && IS_ATOM_INT(_1257))
    _1258 = 0;
    else
    _1258 = (compare(_d_2677, _1257) == 0);
    DeRefDS(_1257);
    _1257 = NOVALUE;
    if (_1258 == 0)
    {
        _1258 = NOVALUE;
        goto L1; // [37] 60
    }
    else{
        _1258 = NOVALUE;
    }

    /** datetime.e:589			return now()*/

    /** datetime.e:533		return from_date(date())*/
    DeRefi(_now_1__tmp_at41_2684);
    _now_1__tmp_at41_2684 = Date();
    RefDS(_now_1__tmp_at41_2684);
    _0 = _now_inlined_now_at_41_2683;
    _now_inlined_now_at_41_2683 = _18from_date(_now_1__tmp_at41_2684);
    DeRef(_0);
    DeRefi(_now_1__tmp_at41_2684);
    _now_1__tmp_at41_2684 = NOVALUE;
    DeRef(_second_2676);
    DeRef(_d_2677);
    return _now_inlined_now_at_41_2683;
    goto L2; // [57] 67
L1: 

    /** datetime.e:591			return d*/
    DeRef(_second_2676);
    return _d_2677;
L2: 
    ;
}



// 0x3EA99F3D
