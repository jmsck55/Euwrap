// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _29map(object _m_12148)
{
    object _6821 = NOVALUE;
    object _6820 = NOVALUE;
    object _6819 = NOVALUE;
    object _6817 = NOVALUE;
    object _6816 = NOVALUE;
    object _6815 = NOVALUE;
    object _6813 = NOVALUE;
    object _6812 = NOVALUE;
    object _6811 = NOVALUE;
    object _6809 = NOVALUE;
    object _6808 = NOVALUE;
    object _6805 = NOVALUE;
    object _6803 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:126		if not atom( m ) then*/
    _6803 = IS_ATOM(_m_12148);
    if (_6803 != 0)
    goto L1; // [6] 16
    _6803 = NOVALUE;

    /** map.e:127			return 0*/
    DeRef(_m_12148);
    return 0LL;
L1: 

    /** map.e:129		if length( eumem:ram_space ) < m then*/
    if (IS_SEQUENCE(_30ram_space_11238)){
            _6805 = SEQ_PTR(_30ram_space_11238)->length;
    }
    else {
        _6805 = 1;
    }
    if (binary_op_a(GREATEREQ, _6805, _m_12148)){
        _6805 = NOVALUE;
        goto L2; // [23] 34
    }
    _6805 = NOVALUE;

    /** map.e:130			return 0*/
    DeRef(_m_12148);
    return 0LL;
L2: 

    /** map.e:132		if m < 1 then*/
    if (binary_op_a(GREATEREQ, _m_12148, 1LL)){
        goto L3; // [36] 47
    }

    /** map.e:133			return 0*/
    DeRef(_m_12148);
    return 0LL;
L3: 

    /** map.e:135		if length( eumem:ram_space[m] ) != MAP_MAX then*/
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!IS_ATOM_INT(_m_12148)){
        _6808 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_m_12148)->dbl));
    }
    else{
        _6808 = (object)*(((s1_ptr)_2)->base + _m_12148);
    }
    if (IS_SEQUENCE(_6808)){
            _6809 = SEQ_PTR(_6808)->length;
    }
    else {
        _6809 = 1;
    }
    _6808 = NOVALUE;
    if (_6809 == 3LL)
    goto L4; // [58] 69

    /** map.e:136			return 0*/
    DeRef(_m_12148);
    _6808 = NOVALUE;
    return 0LL;
L4: 

    /** map.e:138		if not atom( eumem:ram_space[m][MAP_SIZE] ) then*/
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!IS_ATOM_INT(_m_12148)){
        _6811 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_m_12148)->dbl));
    }
    else{
        _6811 = (object)*(((s1_ptr)_2)->base + _m_12148);
    }
    _2 = (object)SEQ_PTR(_6811);
    _6812 = (object)*(((s1_ptr)_2)->base + 1LL);
    _6811 = NOVALUE;
    _6813 = IS_ATOM(_6812);
    _6812 = NOVALUE;
    if (_6813 != 0)
    goto L5; // [84] 94
    _6813 = NOVALUE;

    /** map.e:139			return 0*/
    DeRef(_m_12148);
    _6808 = NOVALUE;
    return 0LL;
L5: 

    /** map.e:141		if not sequence( eumem:ram_space[m][MAP_SLOTS] ) then*/
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!IS_ATOM_INT(_m_12148)){
        _6815 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_m_12148)->dbl));
    }
    else{
        _6815 = (object)*(((s1_ptr)_2)->base + _m_12148);
    }
    _2 = (object)SEQ_PTR(_6815);
    _6816 = (object)*(((s1_ptr)_2)->base + 2LL);
    _6815 = NOVALUE;
    _6817 = IS_SEQUENCE(_6816);
    _6816 = NOVALUE;
    if (_6817 != 0)
    goto L6; // [109] 119
    _6817 = NOVALUE;

    /** map.e:142			return 0*/
    DeRef(_m_12148);
    _6808 = NOVALUE;
    return 0LL;
L6: 

    /** map.e:144		if not atom( eumem:ram_space[m][MAP_MAX] ) then*/
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!IS_ATOM_INT(_m_12148)){
        _6819 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_m_12148)->dbl));
    }
    else{
        _6819 = (object)*(((s1_ptr)_2)->base + _m_12148);
    }
    _2 = (object)SEQ_PTR(_6819);
    _6820 = (object)*(((s1_ptr)_2)->base + 3LL);
    _6819 = NOVALUE;
    _6821 = IS_ATOM(_6820);
    _6820 = NOVALUE;
    if (_6821 != 0)
    goto L7; // [134] 144
    _6821 = NOVALUE;

    /** map.e:145			return 0*/
    DeRef(_m_12148);
    _6808 = NOVALUE;
    return 0LL;
L7: 

    /** map.e:147		return 1*/
    DeRef(_m_12148);
    _6808 = NOVALUE;
    return 1LL;
    ;
}


object _29new_map_seq(object _size_12179)
{
    object _slots_12180 = NOVALUE;
    object _6832 = NOVALUE;
    object _6831 = NOVALUE;
    object _6830 = NOVALUE;
    object _6829 = NOVALUE;
    object _6825 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:155		integer slots = DEFAULT_SIZE * 2*/
    _slots_12180 = 16LL;

    /** map.e:156		if size <= DEFAULT_SIZE then*/
    if (_size_12179 > 8LL)
    goto L1; // [11] 23

    /** map.e:157			size = DEFAULT_SIZE*/
    _size_12179 = 8LL;
    goto L2; // [20] 55
L1: 

    /** map.e:159			size = floor( size * 1.5 )*/
    _6825 = NewDouble((eudouble)_size_12179 * DBL_PTR(_3024)->dbl);
    _size_12179 = unary_op(FLOOR, _6825);
    DeRefDS(_6825);
    _6825 = NOVALUE;
    if (!IS_ATOM_INT(_size_12179)) {
        _1 = (object)(DBL_PTR(_size_12179)->dbl);
        DeRefDS(_size_12179);
        _size_12179 = _1;
    }

    /** map.e:160			while slots < size do*/
L3: 
    if (_slots_12180 >= _size_12179)
    goto L4; // [39] 54

    /** map.e:162				slots *= 2*/
    _slots_12180 = _slots_12180 + _slots_12180;

    /** map.e:163			end while*/
    goto L3; // [51] 39
L4: 
L2: 

    /** map.e:165		return { 0, repeat( EMPTY_SLOT, slots ), floor( size * 2/3 ) }*/
    _6829 = Repeat(_29EMPTY_SLOT_12136, _slots_12180);
    _6830 = _size_12179 + _size_12179;
    if ((object)((uintptr_t)_6830 + (uintptr_t)HIGH_BITS) >= 0){
        _6830 = NewDouble((eudouble)_6830);
    }
    if (IS_ATOM_INT(_6830)) {
        if (3LL > 0 && _6830 >= 0) {
            _6831 = _6830 / 3LL;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_6830 / (eudouble)3LL);
            if (_6830 != MININT)
            _6831 = (object)temp_dbl;
            else
            _6831 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _6830, 3LL);
        _6831 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_6830);
    _6830 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0LL;
    ((intptr_t*)_2)[2] = _6829;
    ((intptr_t*)_2)[3] = _6831;
    _6832 = MAKE_SEQ(_1);
    _6831 = NOVALUE;
    _6829 = NOVALUE;
    return _6832;
    ;
}


object _29lookup(object _key_12222, object _hashval_12223, object _slots_12225)
{
    object _mask_12226 = NOVALUE;
    object _index_12229 = NOVALUE;
    object _index_hash_12232 = NOVALUE;
    object _slot_12233 = NOVALUE;
    object _perturb_12234 = NOVALUE;
    object _this_hash_12235 = NOVALUE;
    object _this_key_12236 = NOVALUE;
    object _looks_12237 = NOVALUE;
    object _removed_slot_12238 = NOVALUE;
    object _6860 = NOVALUE;
    object _6848 = NOVALUE;
    object _6847 = NOVALUE;
    object _6846 = NOVALUE;
    object _6845 = NOVALUE;
    object _6843 = NOVALUE;
    object _6841 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:275		integer mask = length( slots ) - 1*/
    if (IS_SEQUENCE(_slots_12225)){
            _6841 = SEQ_PTR(_slots_12225)->length;
    }
    else {
        _6841 = 1;
    }
    _mask_12226 = _6841 - 1LL;
    _6841 = NOVALUE;

    /** map.e:276		integer index = and_bits( hashval, mask ) + 1*/
    {uintptr_t tu;
         tu = (uintptr_t)_hashval_12223 & (uintptr_t)_mask_12226;
         _6843 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_6843)) {
        _index_12229 = _6843 + 1;
    }
    else
    { // coercing _index_12229 to an integer 1
        _index_12229 = 1+(object)(DBL_PTR(_6843)->dbl);
        if( !IS_ATOM_INT(_index_12229) ){
            _index_12229 = (object)DBL_PTR(_index_12229)->dbl;
        }
    }
    DeRef(_6843);
    _6843 = NOVALUE;

    /** map.e:277		ifdef BITS64 then*/

    /** map.e:278			integer index_hash = index*/
    _index_hash_12232 = _index_12229;

    /** map.e:282		sequence slot*/

    /** map.e:284		integer perturb = hashval*/
    _perturb_12234 = _hashval_12223;

    /** map.e:285		integer this_hash*/

    /** map.e:286		object this_key*/

    /** map.e:287		integer looks = 0*/
    _looks_12237 = 0LL;

    /** map.e:288		integer removed_slot = 0*/
    _removed_slot_12238 = 0LL;

    /** map.e:289		while this_hash != hashval or not equal( this_key, key ) with entry do*/
    goto L1; // [54] 140
L2: 
    _6845 = (_this_hash_12235 != _hashval_12223);
    if (_6845 != 0) {
        DeRef(_6846);
        _6846 = 1;
        goto L3; // [63] 80
    }
    if (_this_key_12236 == _key_12222)
    _6847 = 1;
    else if (IS_ATOM_INT(_this_key_12236) && IS_ATOM_INT(_key_12222))
    _6847 = 0;
    else
    _6847 = (compare(_this_key_12236, _key_12222) == 0);
    _6848 = (_6847 == 0);
    _6847 = NOVALUE;
    _6846 = (_6848 != 0);
L3: 
    if (_6846 == 0)
    {
        _6846 = NOVALUE;
        goto L4; // [80] 217
    }
    else{
        _6846 = NOVALUE;
    }

    /** map.e:290			index_hash *= 4*/
    _index_hash_12232 = _index_hash_12232 * 4LL;

    /** map.e:291			index_hash += index*/
    _index_hash_12232 = _index_hash_12232 + _index_12229;

    /** map.e:292			index_hash += perturb*/
    _index_hash_12232 = _index_hash_12232 + _perturb_12234;

    /** map.e:293			index_hash += 1*/
    _index_hash_12232 = _index_hash_12232 + 1;

    /** map.e:294			index_hash = and_bits( 0xffff_ffff, index_hash )*/
    {uintptr_t tu;
         tu = (uintptr_t)4294967295LL & (uintptr_t)_index_hash_12232;
         _index_hash_12232 = MAKE_UINT(tu);
    }

    /** map.e:295			index = and_bits( mask, index_hash )*/
    {uintptr_t tu;
         tu = (uintptr_t)_mask_12226 & (uintptr_t)_index_hash_12232;
         _index_12229 = MAKE_UINT(tu);
    }

    /** map.e:296			index += 1*/
    _index_12229 = _index_12229 + 1;

    /** map.e:297			perturb = floor( perturb / 32 )*/
    if (32LL > 0 && _perturb_12234 >= 0) {
        _perturb_12234 = _perturb_12234 / 32LL;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_perturb_12234 / (eudouble)32LL);
        _perturb_12234 = (object)temp_dbl;
    }

    /** map.e:298		entry*/
L1: 

    /** map.e:299			slot = slots[index]*/
    DeRef(_slot_12233);
    _2 = (object)SEQ_PTR(_slots_12225);
    _slot_12233 = (object)*(((s1_ptr)_2)->base + _index_12229);
    Ref(_slot_12233);

    /** map.e:300			this_hash = slot[SLOT_HASH]*/
    _2 = (object)SEQ_PTR(_slot_12233);
    _this_hash_12235 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_this_hash_12235))
    _this_hash_12235 = (object)DBL_PTR(_this_hash_12235)->dbl;

    /** map.e:301			if this_hash = EMPTY then*/
    if (_this_hash_12235 != -2LL)
    goto L5; // [156] 169

    /** map.e:302				return index*/
    DeRef(_key_12222);
    DeRefDS(_slots_12225);
    DeRefDS(_slot_12233);
    DeRef(_this_key_12236);
    DeRef(_6845);
    _6845 = NOVALUE;
    DeRef(_6848);
    _6848 = NOVALUE;
    return _index_12229;
    goto L6; // [166] 200
L5: 

    /** map.e:303			elsif looks > length( slots ) then*/
    if (IS_SEQUENCE(_slots_12225)){
            _6860 = SEQ_PTR(_slots_12225)->length;
    }
    else {
        _6860 = 1;
    }
    if (_looks_12237 <= _6860)
    goto L7; // [174] 187

    /** map.e:304				return removed_slot*/
    DeRef(_key_12222);
    DeRefDS(_slots_12225);
    DeRef(_slot_12233);
    DeRef(_this_key_12236);
    DeRef(_6845);
    _6845 = NOVALUE;
    DeRef(_6848);
    _6848 = NOVALUE;
    return _removed_slot_12238;
    goto L6; // [184] 200
L7: 

    /** map.e:305			elsif this_hash = REMOVED then*/
    if (_this_hash_12235 != -1LL)
    goto L8; // [189] 199

    /** map.e:306				removed_slot = index*/
    _removed_slot_12238 = _index_12229;
L8: 
L6: 

    /** map.e:308			this_key = slot[SLOT_KEY]*/
    DeRef(_this_key_12236);
    _2 = (object)SEQ_PTR(_slot_12233);
    _this_key_12236 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_this_key_12236);

    /** map.e:309			looks += 1*/
    _looks_12237 = _looks_12237 + 1;

    /** map.e:310		end while*/
    goto L2; // [214] 57
L4: 

    /** map.e:311		return index*/
    DeRef(_key_12222);
    DeRefDS(_slots_12225);
    DeRef(_slot_12233);
    DeRef(_this_key_12236);
    DeRef(_6845);
    _6845 = NOVALUE;
    DeRef(_6848);
    _6848 = NOVALUE;
    return _index_12229;
    ;
}


object _29rehash_seq(object _old_map_12265, object _size_12266)
{
    object _old_size_12267 = NOVALUE;
    object _index_12269 = NOVALUE;
    object _new_map_12282 = NOVALUE;
    object _slots_12284 = NOVALUE;
    object _old_slots_12287 = NOVALUE;
    object _old_slot_12292 = NOVALUE;
    object _old_hash_12294 = NOVALUE;
    object _6881 = NOVALUE;
    object _6877 = NOVALUE;
    object _6875 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:316		integer old_size = old_map[MAP_SIZE]*/
    _2 = (object)SEQ_PTR(_old_map_12265);
    _old_size_12267 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_old_size_12267))
    _old_size_12267 = (object)DBL_PTR(_old_size_12267)->dbl;

    /** map.e:319		if size = 0 then*/

    /** map.e:320			if old_size > 50_000 then*/
    if (_old_size_12267 <= 50000LL)
    goto L1; // [19] 32

    /** map.e:321				size = old_size * 2*/
    _size_12266 = _old_size_12267 + _old_size_12267;
    goto L2; // [29] 69
L1: 

    /** map.e:323				size = old_size * 4*/
    _size_12266 = _old_size_12267 * 4LL;
    goto L2; // [41] 69

    /** map.e:325		elsif size < old_size then*/
    if (_size_12266 >= _old_size_12267)
    goto L3; // [46] 68

    /** map.e:326			size = old_size*/
    _size_12266 = _old_size_12267;

    /** map.e:327			if size < DEFAULT_SIZE then*/
    if (_size_12266 >= 8LL)
    goto L4; // [57] 67

    /** map.e:328				size = DEFAULT_SIZE*/
    _size_12266 = 8LL;
L4: 
L3: 
L2: 

    /** map.e:332		sequence new_map = new_map_seq( size )*/
    _0 = _new_map_12282;
    _new_map_12282 = _29new_map_seq(_size_12266);
    DeRef(_0);

    /** map.e:333		sequence slots = new_map[MAP_SLOTS]*/
    DeRef(_slots_12284);
    _2 = (object)SEQ_PTR(_new_map_12282);
    _slots_12284 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_slots_12284);

    /** map.e:334		new_map[MAP_SLOTS] = 0*/
    _2 = (object)SEQ_PTR(_new_map_12282);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_map_12282 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** map.e:335		new_map[MAP_SIZE] = old_map[MAP_SIZE]*/
    _2 = (object)SEQ_PTR(_old_map_12265);
    _6875 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_6875);
    _2 = (object)SEQ_PTR(_new_map_12282);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_map_12282 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _6875;
    if( _1 != _6875 ){
        DeRef(_1);
    }
    _6875 = NOVALUE;

    /** map.e:337		sequence old_slots = old_map[MAP_SLOTS]*/
    DeRef(_old_slots_12287);
    _2 = (object)SEQ_PTR(_old_map_12265);
    _old_slots_12287 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_old_slots_12287);

    /** map.e:338		for i = 1 to length( old_slots ) do*/
    if (IS_SEQUENCE(_old_slots_12287)){
            _6877 = SEQ_PTR(_old_slots_12287)->length;
    }
    else {
        _6877 = 1;
    }
    {
        object _i_12290;
        _i_12290 = 1LL;
L5: 
        if (_i_12290 > _6877){
            goto L6; // [114] 171
        }

        /** map.e:339			sequence old_slot = old_slots[i]*/
        DeRef(_old_slot_12292);
        _2 = (object)SEQ_PTR(_old_slots_12287);
        _old_slot_12292 = (object)*(((s1_ptr)_2)->base + _i_12290);
        Ref(_old_slot_12292);

        /** map.e:340			integer old_hash = old_slot[SLOT_HASH]*/
        _2 = (object)SEQ_PTR(_old_slot_12292);
        _old_hash_12294 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (!IS_ATOM_INT(_old_hash_12294))
        _old_hash_12294 = (object)DBL_PTR(_old_hash_12294)->dbl;

        /** map.e:341			if old_hash != -1 then*/
        if (_old_hash_12294 == -1LL)
        goto L7; // [137] 162

        /** map.e:342				index = lookup( old_slot[SLOT_KEY], old_hash, slots )*/
        _2 = (object)SEQ_PTR(_old_slot_12292);
        _6881 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_6881);
        RefDS(_slots_12284);
        _index_12269 = _29lookup(_6881, _old_hash_12294, _slots_12284);
        _6881 = NOVALUE;
        if (!IS_ATOM_INT(_index_12269)) {
            _1 = (object)(DBL_PTR(_index_12269)->dbl);
            DeRefDS(_index_12269);
            _index_12269 = _1;
        }

        /** map.e:343				slots[index] = old_slot*/
        RefDS(_old_slot_12292);
        _2 = (object)SEQ_PTR(_slots_12284);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_12284 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_12269);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _old_slot_12292;
        DeRef(_1);
L7: 
        DeRef(_old_slot_12292);
        _old_slot_12292 = NOVALUE;

        /** map.e:345		end for*/
        _i_12290 = _i_12290 + 1LL;
        goto L5; // [166] 121
L6: 
        ;
    }

    /** map.e:346		new_map[MAP_SLOTS] = slots*/
    RefDS(_slots_12284);
    _2 = (object)SEQ_PTR(_new_map_12282);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_map_12282 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _slots_12284;
    DeRef(_1);

    /** map.e:347		return new_map*/
    DeRefDS(_old_map_12265);
    DeRefDS(_slots_12284);
    DeRef(_old_slots_12287);
    return _new_map_12282;
    ;
}


object _29new_extra(object _the_map_p_12302, object _initial_size_p_12303)
{
    object _new_1__tmp_at22_12309 = NOVALUE;
    object _new_inlined_new_at_22_12308 = NOVALUE;
    object _6883 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:376		if map(the_map_p) then*/
    Ref(_the_map_p_12302);
    _6883 = _29map(_the_map_p_12302);
    if (_6883 == 0) {
        DeRef(_6883);
        _6883 = NOVALUE;
        goto L1; // [9] 21
    }
    else {
        if (!IS_ATOM_INT(_6883) && DBL_PTR(_6883)->dbl == 0.0){
            DeRef(_6883);
            _6883 = NOVALUE;
            goto L1; // [9] 21
        }
        DeRef(_6883);
        _6883 = NOVALUE;
    }
    DeRef(_6883);
    _6883 = NOVALUE;

    /** map.e:377			return the_map_p*/
    return _the_map_p_12302;
    goto L2; // [18] 42
L1: 

    /** map.e:379			return new(initial_size_p)*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at22_12309;
    _new_1__tmp_at22_12309 = _29new_map_seq(_initial_size_p_12303);
    DeRef(_0);
    Ref(_new_1__tmp_at22_12309);
    _0 = _new_inlined_new_at_22_12308;
    _new_inlined_new_at_22_12308 = _30malloc(_new_1__tmp_at22_12309, 1LL);
    DeRef(_0);
    DeRef(_new_1__tmp_at22_12309);
    _new_1__tmp_at22_12309 = NOVALUE;
    DeRef(_the_map_p_12302);
    return _new_inlined_new_at_22_12308;
L2: 
    ;
}


object _29has(object _the_map_p_12344, object _key_12345)
{
    object _hashval_12346 = NOVALUE;
    object _hash_inlined_hash_at_2_12348 = NOVALUE;
    object _slots_12349 = NOVALUE;
    object _index_12352 = NOVALUE;
    object _6903 = NOVALUE;
    object _6902 = NOVALUE;
    object _6901 = NOVALUE;
    object _6898 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:464		integer hashval = hash( key )*/

    /** map.e:107		return eu:hash( x, DEFAULT_HASH )*/
    _hashval_12346 = calc_hash(_key_12345, -6LL);

    /** map.e:465		sequence slots = eumem:ram_space[the_map_p][MAP_SLOTS]*/
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!IS_ATOM_INT(_the_map_p_12344)){
        _6898 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_12344)->dbl));
    }
    else{
        _6898 = (object)*(((s1_ptr)_2)->base + _the_map_p_12344);
    }
    DeRef(_slots_12349);
    _2 = (object)SEQ_PTR(_6898);
    _slots_12349 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_slots_12349);
    _6898 = NOVALUE;

    /** map.e:466		integer index = lookup( key, hashval, slots )*/
    Ref(_key_12345);
    RefDS(_slots_12349);
    _index_12352 = _29lookup(_key_12345, _hashval_12346, _slots_12349);
    if (!IS_ATOM_INT(_index_12352)) {
        _1 = (object)(DBL_PTR(_index_12352)->dbl);
        DeRefDS(_index_12352);
        _index_12352 = _1;
    }

    /** map.e:468		return hashval = slots[index][SLOT_HASH]*/
    _2 = (object)SEQ_PTR(_slots_12349);
    _6901 = (object)*(((s1_ptr)_2)->base + _index_12352);
    _2 = (object)SEQ_PTR(_6901);
    _6902 = (object)*(((s1_ptr)_2)->base + 1LL);
    _6901 = NOVALUE;
    if (IS_ATOM_INT(_6902)) {
        _6903 = (_hashval_12346 == _6902);
    }
    else {
        _6903 = binary_op(EQUALS, _hashval_12346, _6902);
    }
    _6902 = NOVALUE;
    DeRef(_the_map_p_12344);
    DeRef(_key_12345);
    DeRefDS(_slots_12349);
    return _6903;
    ;
}


object _29get(object _the_map_p_12359, object _key_12360, object _default_12361)
{
    object _hashval_12362 = NOVALUE;
    object _hash_inlined_hash_at_2_12364 = NOVALUE;
    object _slots_12365 = NOVALUE;
    object _index_12368 = NOVALUE;
    object _slot_12370 = NOVALUE;
    object _6910 = NOVALUE;
    object _6908 = NOVALUE;
    object _6904 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:505		integer hashval = hash( key )*/

    /** map.e:107		return eu:hash( x, DEFAULT_HASH )*/
    _hashval_12362 = calc_hash(_key_12360, -6LL);

    /** map.e:506		sequence slots = eumem:ram_space[the_map_p][MAP_SLOTS]*/
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!IS_ATOM_INT(_the_map_p_12359)){
        _6904 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_12359)->dbl));
    }
    else{
        _6904 = (object)*(((s1_ptr)_2)->base + _the_map_p_12359);
    }
    DeRef(_slots_12365);
    _2 = (object)SEQ_PTR(_6904);
    _slots_12365 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_slots_12365);
    _6904 = NOVALUE;

    /** map.e:507		integer index = lookup( key, hashval, slots )*/
    Ref(_key_12360);
    RefDS(_slots_12365);
    _index_12368 = _29lookup(_key_12360, _hashval_12362, _slots_12365);
    if (!IS_ATOM_INT(_index_12368)) {
        _1 = (object)(DBL_PTR(_index_12368)->dbl);
        DeRefDS(_index_12368);
        _index_12368 = _1;
    }

    /** map.e:508		sequence slot = slots[index]*/
    DeRef(_slot_12370);
    _2 = (object)SEQ_PTR(_slots_12365);
    _slot_12370 = (object)*(((s1_ptr)_2)->base + _index_12368);
    Ref(_slot_12370);

    /** map.e:509		if hashval = slot[SLOT_HASH] then*/
    _2 = (object)SEQ_PTR(_slot_12370);
    _6908 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _hashval_12362, _6908)){
        _6908 = NOVALUE;
        goto L1; // [50] 65
    }
    _6908 = NOVALUE;

    /** map.e:510			return slot[SLOT_VALUE]*/
    _2 = (object)SEQ_PTR(_slot_12370);
    _6910 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_6910);
    DeRef(_the_map_p_12359);
    DeRef(_key_12360);
    DeRef(_default_12361);
    DeRefDS(_slots_12365);
    DeRefDS(_slot_12370);
    return _6910;
L1: 

    /** map.e:512		return default*/
    DeRef(_the_map_p_12359);
    DeRef(_key_12360);
    DeRef(_slots_12365);
    DeRef(_slot_12370);
    _6910 = NOVALUE;
    return _default_12361;
    ;
}


void _29put(object _the_map_p_12398, object _key_12399, object _val_12400, object _op_12401, object _deprecated_12402)
{
    object _hashval_12403 = NOVALUE;
    object _hash_inlined_hash_at_2_12405 = NOVALUE;
    object _the_map_seq_12406 = NOVALUE;
    object _slots_12408 = NOVALUE;
    object _index_12410 = NOVALUE;
    object _old_hash_12412 = NOVALUE;
    object _msg_inlined_crash_at_288_12455 = NOVALUE;
    object _msg_inlined_crash_at_348_12465 = NOVALUE;
    object _msg_inlined_crash_at_535_12497 = NOVALUE;
    object _6977 = NOVALUE;
    object _6975 = NOVALUE;
    object _6974 = NOVALUE;
    object _6973 = NOVALUE;
    object _6972 = NOVALUE;
    object _6971 = NOVALUE;
    object _6969 = NOVALUE;
    object _6968 = NOVALUE;
    object _6967 = NOVALUE;
    object _6966 = NOVALUE;
    object _6965 = NOVALUE;
    object _6964 = NOVALUE;
    object _6962 = NOVALUE;
    object _6961 = NOVALUE;
    object _6960 = NOVALUE;
    object _6959 = NOVALUE;
    object _6957 = NOVALUE;
    object _6956 = NOVALUE;
    object _6955 = NOVALUE;
    object _6954 = NOVALUE;
    object _6951 = NOVALUE;
    object _6950 = NOVALUE;
    object _6949 = NOVALUE;
    object _6948 = NOVALUE;
    object _6947 = NOVALUE;
    object _6945 = NOVALUE;
    object _6944 = NOVALUE;
    object _6943 = NOVALUE;
    object _6942 = NOVALUE;
    object _6941 = NOVALUE;
    object _6939 = NOVALUE;
    object _6936 = NOVALUE;
    object _6935 = NOVALUE;
    object _6933 = NOVALUE;
    object _6928 = NOVALUE;
    object _6927 = NOVALUE;
    object _6924 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:579		integer hashval = hash( key )*/

    /** map.e:107		return eu:hash( x, DEFAULT_HASH )*/
    _hashval_12403 = calc_hash(_key_12399, -6LL);

    /** map.e:580		sequence the_map_seq = eumem:ram_space[the_map_p]*/
    DeRef(_the_map_seq_12406);
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!IS_ATOM_INT(_the_map_p_12398)){
        _the_map_seq_12406 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_12398)->dbl));
    }
    else{
        _the_map_seq_12406 = (object)*(((s1_ptr)_2)->base + _the_map_p_12398);
    }
    Ref(_the_map_seq_12406);

    /** map.e:581		eumem:ram_space[the_map_p] = 0*/
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _30ram_space_11238 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_12398))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_12398)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _the_map_p_12398);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** map.e:582		sequence slots = the_map_seq[MAP_SLOTS]*/
    DeRef(_slots_12408);
    _2 = (object)SEQ_PTR(_the_map_seq_12406);
    _slots_12408 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_slots_12408);

    /** map.e:584		integer index = lookup( key, hashval, slots )*/
    Ref(_key_12399);
    RefDS(_slots_12408);
    _index_12410 = _29lookup(_key_12399, _hashval_12403, _slots_12408);
    if (!IS_ATOM_INT(_index_12410)) {
        _1 = (object)(DBL_PTR(_index_12410)->dbl);
        DeRefDS(_index_12410);
        _index_12410 = _1;
    }

    /** map.e:585		integer old_hash = slots[index][SLOT_HASH]*/
    _2 = (object)SEQ_PTR(_slots_12408);
    _6924 = (object)*(((s1_ptr)_2)->base + _index_12410);
    _2 = (object)SEQ_PTR(_6924);
    _old_hash_12412 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_old_hash_12412)){
        _old_hash_12412 = (object)DBL_PTR(_old_hash_12412)->dbl;
    }
    _6924 = NOVALUE;

    /** map.e:587		if old_hash < 0 then*/
    if (_old_hash_12412 >= 0LL)
    goto L1; // [62] 142

    /** map.e:589			if the_map_seq[MAP_SIZE] > the_map_seq[MAP_MAX] then*/
    _2 = (object)SEQ_PTR(_the_map_seq_12406);
    _6927 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_the_map_seq_12406);
    _6928 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (binary_op_a(LESSEQ, _6927, _6928)){
        _6927 = NOVALUE;
        _6928 = NOVALUE;
        goto L2; // [76] 127
    }
    _6927 = NOVALUE;
    _6928 = NOVALUE;

    /** map.e:590				slots = {}*/
    RefDS(_5);
    DeRefDS(_slots_12408);
    _slots_12408 = _5;

    /** map.e:591				the_map_seq = rehash_seq( the_map_seq )*/
    RefDS(_the_map_seq_12406);
    _0 = _the_map_seq_12406;
    _the_map_seq_12406 = _29rehash_seq(_the_map_seq_12406, 0LL);
    DeRefDS(_0);

    /** map.e:592				slots = the_map_seq[MAP_SLOTS]*/
    DeRefDS(_slots_12408);
    _2 = (object)SEQ_PTR(_the_map_seq_12406);
    _slots_12408 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_slots_12408);

    /** map.e:593				index = lookup( key, hashval, slots )*/
    Ref(_key_12399);
    RefDS(_slots_12408);
    _index_12410 = _29lookup(_key_12399, _hashval_12403, _slots_12408);
    if (!IS_ATOM_INT(_index_12410)) {
        _1 = (object)(DBL_PTR(_index_12410)->dbl);
        DeRefDS(_index_12410);
        _index_12410 = _1;
    }

    /** map.e:594				old_hash = slots[index][SLOT_HASH]*/
    _2 = (object)SEQ_PTR(_slots_12408);
    _6933 = (object)*(((s1_ptr)_2)->base + _index_12410);
    _2 = (object)SEQ_PTR(_6933);
    _old_hash_12412 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_old_hash_12412)){
        _old_hash_12412 = (object)DBL_PTR(_old_hash_12412)->dbl;
    }
    _6933 = NOVALUE;
L2: 

    /** map.e:596			the_map_seq[MAP_SIZE] += 1*/
    _2 = (object)SEQ_PTR(_the_map_seq_12406);
    _6935 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_6935)) {
        _6936 = _6935 + 1;
        if (_6936 > MAXINT){
            _6936 = NewDouble((eudouble)_6936);
        }
    }
    else
    _6936 = binary_op(PLUS, 1, _6935);
    _6935 = NOVALUE;
    _2 = (object)SEQ_PTR(_the_map_seq_12406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _the_map_seq_12406 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _6936;
    if( _1 != _6936 ){
        DeRef(_1);
    }
    _6936 = NOVALUE;
L1: 

    /** map.e:599		the_map_seq[MAP_SLOTS] = 0*/
    _2 = (object)SEQ_PTR(_the_map_seq_12406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _the_map_seq_12406 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** map.e:601		switch op do*/
    _0 = _op_12401;
    switch ( _0 ){ 

        /** map.e:602			case PUT then*/
        case 1:

        /** map.e:603				slots[index] = { hashval, key, val }*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_12403;
        Ref(_key_12399);
        ((intptr_t*)_2)[2] = _key_12399;
        Ref(_val_12400);
        ((intptr_t*)_2)[3] = _val_12400;
        _6939 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_slots_12408);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_12408 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_12410);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _6939;
        if( _1 != _6939 ){
            DeRef(_1);
        }
        _6939 = NOVALUE;
        goto L3; // [171] 555

        /** map.e:604			case ADD then*/
        case 2:

        /** map.e:605				if old_hash < 0 then*/
        if (_old_hash_12412 >= 0LL)
        goto L4; // [179] 198

        /** map.e:606					slots[index] = { hashval, key, val }*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_12403;
        Ref(_key_12399);
        ((intptr_t*)_2)[2] = _key_12399;
        Ref(_val_12400);
        ((intptr_t*)_2)[3] = _val_12400;
        _6941 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_slots_12408);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_12408 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_12410);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _6941;
        if( _1 != _6941 ){
            DeRef(_1);
        }
        _6941 = NOVALUE;
        goto L3; // [195] 555
L4: 

        /** map.e:608					slots[index] = { hashval, key, val + slots[index][SLOT_VALUE] }*/
        _2 = (object)SEQ_PTR(_slots_12408);
        _6942 = (object)*(((s1_ptr)_2)->base + _index_12410);
        _2 = (object)SEQ_PTR(_6942);
        _6943 = (object)*(((s1_ptr)_2)->base + 3LL);
        _6942 = NOVALUE;
        if (IS_ATOM_INT(_val_12400) && IS_ATOM_INT(_6943)) {
            _6944 = _val_12400 + _6943;
            if ((object)((uintptr_t)_6944 + (uintptr_t)HIGH_BITS) >= 0){
                _6944 = NewDouble((eudouble)_6944);
            }
        }
        else {
            _6944 = binary_op(PLUS, _val_12400, _6943);
        }
        _6943 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_12403;
        Ref(_key_12399);
        ((intptr_t*)_2)[2] = _key_12399;
        ((intptr_t*)_2)[3] = _6944;
        _6945 = MAKE_SEQ(_1);
        _6944 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_12408);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_12408 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_12410);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _6945;
        if( _1 != _6945 ){
            DeRef(_1);
        }
        _6945 = NOVALUE;
        goto L3; // [223] 555

        /** map.e:610			case SUBTRACT then*/
        case 3:

        /** map.e:611				if old_hash < 0 then*/
        if (_old_hash_12412 >= 0LL)
        goto L5; // [231] 250

        /** map.e:612					slots[index] = { hashval, key, val }*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_12403;
        Ref(_key_12399);
        ((intptr_t*)_2)[2] = _key_12399;
        Ref(_val_12400);
        ((intptr_t*)_2)[3] = _val_12400;
        _6947 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_slots_12408);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_12408 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_12410);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _6947;
        if( _1 != _6947 ){
            DeRef(_1);
        }
        _6947 = NOVALUE;
        goto L3; // [247] 555
L5: 

        /** map.e:614					slots[index] = { hashval, key, slots[index][SLOT_VALUE] - val }*/
        _2 = (object)SEQ_PTR(_slots_12408);
        _6948 = (object)*(((s1_ptr)_2)->base + _index_12410);
        _2 = (object)SEQ_PTR(_6948);
        _6949 = (object)*(((s1_ptr)_2)->base + 3LL);
        _6948 = NOVALUE;
        if (IS_ATOM_INT(_6949) && IS_ATOM_INT(_val_12400)) {
            _6950 = _6949 - _val_12400;
            if ((object)((uintptr_t)_6950 +(uintptr_t) HIGH_BITS) >= 0){
                _6950 = NewDouble((eudouble)_6950);
            }
        }
        else {
            _6950 = binary_op(MINUS, _6949, _val_12400);
        }
        _6949 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_12403;
        Ref(_key_12399);
        ((intptr_t*)_2)[2] = _key_12399;
        ((intptr_t*)_2)[3] = _6950;
        _6951 = MAKE_SEQ(_1);
        _6950 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_12408);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_12408 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_12410);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _6951;
        if( _1 != _6951 ){
            DeRef(_1);
        }
        _6951 = NOVALUE;
        goto L3; // [275] 555

        /** map.e:617			case MULTIPLY then*/
        case 4:

        /** map.e:618				if old_hash < 0 then*/
        if (_old_hash_12412 >= 0LL)
        goto L6; // [283] 310

        /** map.e:619					error:crash("Inappropriate initial operation given to map.e:put()")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_288_12455);
        _msg_inlined_crash_at_288_12455 = EPrintf(-9999999, _6953, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67LL, _msg_inlined_crash_at_288_12455);

        /** error.e:53	end procedure*/
        goto L7; // [302] 305
L7: 
        DeRefi(_msg_inlined_crash_at_288_12455);
        _msg_inlined_crash_at_288_12455 = NOVALUE;
        goto L3; // [307] 555
L6: 

        /** map.e:621					slots[index] = { hashval, key, val * slots[index][SLOT_VALUE] }*/
        _2 = (object)SEQ_PTR(_slots_12408);
        _6954 = (object)*(((s1_ptr)_2)->base + _index_12410);
        _2 = (object)SEQ_PTR(_6954);
        _6955 = (object)*(((s1_ptr)_2)->base + 3LL);
        _6954 = NOVALUE;
        if (IS_ATOM_INT(_val_12400) && IS_ATOM_INT(_6955)) {
            {
                int128_t p128 = (int128_t)_val_12400 * (int128_t)_6955;
                if( p128 != (int128_t)(_6956 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                    _6956 = NewDouble( (eudouble)p128 );
                }
            }
        }
        else {
            _6956 = binary_op(MULTIPLY, _val_12400, _6955);
        }
        _6955 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_12403;
        Ref(_key_12399);
        ((intptr_t*)_2)[2] = _key_12399;
        ((intptr_t*)_2)[3] = _6956;
        _6957 = MAKE_SEQ(_1);
        _6956 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_12408);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_12408 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_12410);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _6957;
        if( _1 != _6957 ){
            DeRef(_1);
        }
        _6957 = NOVALUE;
        goto L3; // [335] 555

        /** map.e:624			case DIVIDE then*/
        case 5:

        /** map.e:625				if old_hash < 0 then*/
        if (_old_hash_12412 >= 0LL)
        goto L8; // [343] 370

        /** map.e:626					error:crash("Inappropriate initial operation given to map.e:put()")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_348_12465);
        _msg_inlined_crash_at_348_12465 = EPrintf(-9999999, _6953, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67LL, _msg_inlined_crash_at_348_12465);

        /** error.e:53	end procedure*/
        goto L9; // [362] 365
L9: 
        DeRefi(_msg_inlined_crash_at_348_12465);
        _msg_inlined_crash_at_348_12465 = NOVALUE;
        goto L3; // [367] 555
L8: 

        /** map.e:628					slots[index] = { hashval, key, slots[index][SLOT_VALUE] / val }*/
        _2 = (object)SEQ_PTR(_slots_12408);
        _6959 = (object)*(((s1_ptr)_2)->base + _index_12410);
        _2 = (object)SEQ_PTR(_6959);
        _6960 = (object)*(((s1_ptr)_2)->base + 3LL);
        _6959 = NOVALUE;
        if (IS_ATOM_INT(_6960) && IS_ATOM_INT(_val_12400)) {
            _6961 = (_6960 % _val_12400) ? NewDouble((eudouble)_6960 / _val_12400) : (_6960 / _val_12400);
        }
        else {
            _6961 = binary_op(DIVIDE, _6960, _val_12400);
        }
        _6960 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_12403;
        Ref(_key_12399);
        ((intptr_t*)_2)[2] = _key_12399;
        ((intptr_t*)_2)[3] = _6961;
        _6962 = MAKE_SEQ(_1);
        _6961 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_12408);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_12408 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_12410);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _6962;
        if( _1 != _6962 ){
            DeRef(_1);
        }
        _6962 = NOVALUE;
        goto L3; // [395] 555

        /** map.e:631			case APPEND then*/
        case 6:

        /** map.e:632				if old_hash < 0 then*/
        if (_old_hash_12412 >= 0LL)
        goto LA; // [403] 426

        /** map.e:633					slots[index] = { hashval, key, {val} }*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_val_12400);
        ((intptr_t*)_2)[1] = _val_12400;
        _6964 = MAKE_SEQ(_1);
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_12403;
        Ref(_key_12399);
        ((intptr_t*)_2)[2] = _key_12399;
        ((intptr_t*)_2)[3] = _6964;
        _6965 = MAKE_SEQ(_1);
        _6964 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_12408);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_12408 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_12410);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _6965;
        if( _1 != _6965 ){
            DeRef(_1);
        }
        _6965 = NOVALUE;
        goto L3; // [423] 555
LA: 

        /** map.e:635					slots[index] = { hashval, key, append( slots[index][SLOT_VALUE], val ) }*/
        _2 = (object)SEQ_PTR(_slots_12408);
        _6966 = (object)*(((s1_ptr)_2)->base + _index_12410);
        _2 = (object)SEQ_PTR(_6966);
        _6967 = (object)*(((s1_ptr)_2)->base + 3LL);
        _6966 = NOVALUE;
        Ref(_val_12400);
        Append(&_6968, _6967, _val_12400);
        _6967 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_12403;
        Ref(_key_12399);
        ((intptr_t*)_2)[2] = _key_12399;
        ((intptr_t*)_2)[3] = _6968;
        _6969 = MAKE_SEQ(_1);
        _6968 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_12408);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_12408 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_12410);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _6969;
        if( _1 != _6969 ){
            DeRef(_1);
        }
        _6969 = NOVALUE;
        goto L3; // [451] 555

        /** map.e:638			case CONCAT then*/
        case 7:

        /** map.e:639				if old_hash < 0 then*/
        if (_old_hash_12412 >= 0LL)
        goto LB; // [459] 478

        /** map.e:640					slots[index] = { hashval, key, val }*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_12403;
        Ref(_key_12399);
        ((intptr_t*)_2)[2] = _key_12399;
        Ref(_val_12400);
        ((intptr_t*)_2)[3] = _val_12400;
        _6971 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_slots_12408);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_12408 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_12410);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _6971;
        if( _1 != _6971 ){
            DeRef(_1);
        }
        _6971 = NOVALUE;
        goto L3; // [475] 555
LB: 

        /** map.e:642					slots[index] = { hashval, key, slots[index][SLOT_VALUE] & val }*/
        _2 = (object)SEQ_PTR(_slots_12408);
        _6972 = (object)*(((s1_ptr)_2)->base + _index_12410);
        _2 = (object)SEQ_PTR(_6972);
        _6973 = (object)*(((s1_ptr)_2)->base + 3LL);
        _6972 = NOVALUE;
        if (IS_SEQUENCE(_6973) && IS_ATOM(_val_12400)) {
            Ref(_val_12400);
            Append(&_6974, _6973, _val_12400);
        }
        else if (IS_ATOM(_6973) && IS_SEQUENCE(_val_12400)) {
            Ref(_6973);
            Prepend(&_6974, _val_12400, _6973);
        }
        else {
            Concat((object_ptr)&_6974, _6973, _val_12400);
            _6973 = NOVALUE;
        }
        _6973 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_12403;
        Ref(_key_12399);
        ((intptr_t*)_2)[2] = _key_12399;
        ((intptr_t*)_2)[3] = _6974;
        _6975 = MAKE_SEQ(_1);
        _6974 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_12408);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_12408 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_12410);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _6975;
        if( _1 != _6975 ){
            DeRef(_1);
        }
        _6975 = NOVALUE;
        goto L3; // [503] 555

        /** map.e:645			case LEAVE then*/
        case 8:

        /** map.e:646				if old_hash < 0 then*/
        if (_old_hash_12412 >= 0LL)
        goto L3; // [511] 555

        /** map.e:647					slots[index] = { hashval, key, val }*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_12403;
        Ref(_key_12399);
        ((intptr_t*)_2)[2] = _key_12399;
        Ref(_val_12400);
        ((intptr_t*)_2)[3] = _val_12400;
        _6977 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_slots_12408);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_12408 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_12410);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _6977;
        if( _1 != _6977 ){
            DeRef(_1);
        }
        _6977 = NOVALUE;
        goto L3; // [528] 555

        /** map.e:649			case else*/
        default:

        /** map.e:650				error:crash("Unknown operation given to map.e:put()")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_535_12497);
        _msg_inlined_crash_at_535_12497 = EPrintf(-9999999, _6978, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67LL, _msg_inlined_crash_at_535_12497);

        /** error.e:53	end procedure*/
        goto LC; // [549] 552
LC: 
        DeRefi(_msg_inlined_crash_at_535_12497);
        _msg_inlined_crash_at_535_12497 = NOVALUE;
    ;}L3: 

    /** map.e:654		the_map_seq[MAP_SLOTS] = slots*/
    RefDS(_slots_12408);
    _2 = (object)SEQ_PTR(_the_map_seq_12406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _the_map_seq_12406 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _slots_12408;
    DeRef(_1);

    /** map.e:655		eumem:ram_space[the_map_p] = the_map_seq*/
    RefDS(_the_map_seq_12406);
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _30ram_space_11238 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_12398))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_12398)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _the_map_p_12398);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _the_map_seq_12406;
    DeRef(_1);

    /** map.e:656	end procedure*/
    DeRef(_the_map_p_12398);
    DeRef(_key_12399);
    DeRef(_val_12400);
    DeRefDS(_the_map_seq_12406);
    DeRefDS(_slots_12408);
    return;
    ;
}


void _29nested_put(object _the_map_p_12500, object _the_keys_p_12501, object _the_value_p_12502, object _operation_p_12503, object _deprecated_trigger_p_12504)
{
    object _temp_map__12505 = NOVALUE;
    object _6989 = NOVALUE;
    object _6988 = NOVALUE;
    object _6987 = NOVALUE;
    object _6986 = NOVALUE;
    object _6985 = NOVALUE;
    object _6983 = NOVALUE;
    object _6982 = NOVALUE;
    object _6981 = NOVALUE;
    object _6979 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:701		if length( the_keys_p ) = 1 then*/
    if (IS_SEQUENCE(_the_keys_p_12501)){
            _6979 = SEQ_PTR(_the_keys_p_12501)->length;
    }
    else {
        _6979 = 1;
    }
    if (_6979 != 1LL)
    goto L1; // [10] 30

    /** map.e:702			put( the_map_p, the_keys_p[1], the_value_p, operation_p )*/
    _2 = (object)SEQ_PTR(_the_keys_p_12501);
    _6981 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_the_map_p_12500);
    Ref(_6981);
    Ref(_the_value_p_12502);
    _29put(_the_map_p_12500, _6981, _the_value_p_12502, _operation_p_12503, 0LL);
    _6981 = NOVALUE;
    goto L2; // [27] 84
L1: 

    /** map.e:704			temp_map_ = new_extra( get( the_map_p, the_keys_p[1] ) )*/
    _2 = (object)SEQ_PTR(_the_keys_p_12501);
    _6982 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_the_map_p_12500);
    Ref(_6982);
    _6983 = _29get(_the_map_p_12500, _6982, 0LL);
    _6982 = NOVALUE;
    _0 = _temp_map__12505;
    _temp_map__12505 = _29new_extra(_6983, 8LL);
    DeRef(_0);
    _6983 = NOVALUE;

    /** map.e:705			nested_put( temp_map_, the_keys_p[2..$], the_value_p, operation_p )*/
    if (IS_SEQUENCE(_the_keys_p_12501)){
            _6985 = SEQ_PTR(_the_keys_p_12501)->length;
    }
    else {
        _6985 = 1;
    }
    rhs_slice_target = (object_ptr)&_6986;
    RHS_Slice(_the_keys_p_12501, 2LL, _6985);
    Ref(_the_value_p_12502);
    DeRef(_6987);
    _6987 = _the_value_p_12502;
    DeRef(_6988);
    _6988 = _operation_p_12503;
    Ref(_temp_map__12505);
    _29nested_put(_temp_map__12505, _6986, _6987, _6988, 0LL);
    _6986 = NOVALUE;
    _6987 = NOVALUE;
    _6988 = NOVALUE;

    /** map.e:706			put( the_map_p, the_keys_p[1], temp_map_, PUT )*/
    _2 = (object)SEQ_PTR(_the_keys_p_12501);
    _6989 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_the_map_p_12500);
    Ref(_6989);
    Ref(_temp_map__12505);
    _29put(_the_map_p_12500, _6989, _temp_map__12505, 1LL, 0LL);
    _6989 = NOVALUE;
L2: 

    /** map.e:708	end procedure*/
    DeRef(_the_map_p_12500);
    DeRefDS(_the_keys_p_12501);
    DeRef(_the_value_p_12502);
    DeRef(_temp_map__12505);
    return;
    ;
}


void _29remove(object _the_map_p_12521, object _key_12522)
{
    object _hashval_12523 = NOVALUE;
    object _hash_inlined_hash_at_2_12525 = NOVALUE;
    object _slots_12526 = NOVALUE;
    object _index_12529 = NOVALUE;
    object _7001 = NOVALUE;
    object _7000 = NOVALUE;
    object _6998 = NOVALUE;
    object _6996 = NOVALUE;
    object _6994 = NOVALUE;
    object _6993 = NOVALUE;
    object _6990 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** map.e:733		integer hashval = hash( key )*/

    /** map.e:107		return eu:hash( x, DEFAULT_HASH )*/
    _hashval_12523 = calc_hash(_key_12522, -6LL);

    /** map.e:734		sequence slots = eumem:ram_space[the_map_p][MAP_SLOTS]*/
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!IS_ATOM_INT(_the_map_p_12521)){
        _6990 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_12521)->dbl));
    }
    else{
        _6990 = (object)*(((s1_ptr)_2)->base + _the_map_p_12521);
    }
    DeRef(_slots_12526);
    _2 = (object)SEQ_PTR(_6990);
    _slots_12526 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_slots_12526);
    _6990 = NOVALUE;

    /** map.e:736		integer index = lookup( key, hashval, slots )*/
    Ref(_key_12522);
    RefDS(_slots_12526);
    _index_12529 = _29lookup(_key_12522, _hashval_12523, _slots_12526);
    if (!IS_ATOM_INT(_index_12529)) {
        _1 = (object)(DBL_PTR(_index_12529)->dbl);
        DeRefDS(_index_12529);
        _index_12529 = _1;
    }

    /** map.e:737		if hashval = slots[index][SLOT_HASH] then*/
    _2 = (object)SEQ_PTR(_slots_12526);
    _6993 = (object)*(((s1_ptr)_2)->base + _index_12529);
    _2 = (object)SEQ_PTR(_6993);
    _6994 = (object)*(((s1_ptr)_2)->base + 1LL);
    _6993 = NOVALUE;
    if (binary_op_a(NOTEQ, _hashval_12523, _6994)){
        _6994 = NOVALUE;
        goto L1; // [46] 99
    }
    _6994 = NOVALUE;

    /** map.e:738			slots = {}*/
    RefDS(_5);
    DeRefDS(_slots_12526);
    _slots_12526 = _5;

    /** map.e:739			eumem:ram_space[the_map_p][MAP_SLOTS][index] = REMOVED_SLOT*/
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _30ram_space_11238 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_12521))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_12521)->dbl));
    else
    _3 = (object)(_the_map_p_12521 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (object)(2LL + ((s1_ptr)_2)->base);
    _6996 = NOVALUE;
    RefDS(_29REMOVED_SLOT_12138);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _index_12529);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29REMOVED_SLOT_12138;
    DeRef(_1);
    _6996 = NOVALUE;

    /** map.e:740			eumem:ram_space[the_map_p][MAP_SIZE] -= 1*/
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _30ram_space_11238 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_12521))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_12521)->dbl));
    else
    _3 = (object)(_the_map_p_12521 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _7000 = (object)*(((s1_ptr)_2)->base + 1LL);
    _6998 = NOVALUE;
    if (IS_ATOM_INT(_7000)) {
        _7001 = _7000 - 1LL;
        if ((object)((uintptr_t)_7001 +(uintptr_t) HIGH_BITS) >= 0){
            _7001 = NewDouble((eudouble)_7001);
        }
    }
    else {
        _7001 = binary_op(MINUS, _7000, 1LL);
    }
    _7000 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _7001;
    if( _1 != _7001 ){
        DeRef(_1);
    }
    _7001 = NOVALUE;
    _6998 = NOVALUE;
L1: 

    /** map.e:742	end procedure*/
    DeRef(_the_map_p_12521);
    DeRef(_key_12522);
    DeRef(_slots_12526);
    return;
    ;
}


void _29clear(object _the_map_p_12543)
{
    object _7008 = NOVALUE;
    object _7007 = NOVALUE;
    object _7006 = NOVALUE;
    object _7005 = NOVALUE;
    object _7004 = NOVALUE;
    object _7002 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** map.e:771		eumem:ram_space[the_map_p][MAP_SLOTS] = repeat( EMPTY_SLOT, length( eumem:ram_space[the_map_p][MAP_SLOTS] ) )*/
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _30ram_space_11238 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_12543))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_12543)->dbl));
    else
    _3 = (object)(_the_map_p_12543 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!IS_ATOM_INT(_the_map_p_12543)){
        _7004 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_12543)->dbl));
    }
    else{
        _7004 = (object)*(((s1_ptr)_2)->base + _the_map_p_12543);
    }
    _2 = (object)SEQ_PTR(_7004);
    _7005 = (object)*(((s1_ptr)_2)->base + 2LL);
    _7004 = NOVALUE;
    if (IS_SEQUENCE(_7005)){
            _7006 = SEQ_PTR(_7005)->length;
    }
    else {
        _7006 = 1;
    }
    _7005 = NOVALUE;
    _7007 = Repeat(_29EMPTY_SLOT_12136, _7006);
    _7006 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _7007;
    if( _1 != _7007 ){
        DeRef(_1);
    }
    _7007 = NOVALUE;
    _7002 = NOVALUE;

    /** map.e:772		eumem:ram_space[the_map_p][MAP_SIZE]  = 0*/
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _30ram_space_11238 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_12543))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_12543)->dbl));
    else
    _3 = (object)(_the_map_p_12543 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _7008 = NOVALUE;

    /** map.e:773	end procedure*/
    DeRef(_the_map_p_12543);
    _7005 = NOVALUE;
    return;
    ;
}


object _29keys(object _the_map_p_12598, object _sorted_result_12599)
{
    object _slots_12600 = NOVALUE;
    object _keys_12603 = NOVALUE;
    object _kx_12607 = NOVALUE;
    object _7039 = NOVALUE;
    object _7037 = NOVALUE;
    object _7036 = NOVALUE;
    object _7035 = NOVALUE;
    object _7032 = NOVALUE;
    object _7031 = NOVALUE;
    object _7030 = NOVALUE;
    object _7028 = NOVALUE;
    object _7027 = NOVALUE;
    object _7025 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:901		sequence slots = eumem:ram_space[the_map_p][MAP_SLOTS]*/
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!IS_ATOM_INT(_the_map_p_12598)){
        _7025 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_12598)->dbl));
    }
    else{
        _7025 = (object)*(((s1_ptr)_2)->base + _the_map_p_12598);
    }
    DeRef(_slots_12600);
    _2 = (object)SEQ_PTR(_7025);
    _slots_12600 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_slots_12600);
    _7025 = NOVALUE;

    /** map.e:902		sequence keys = repeat( 0, eumem:ram_space[the_map_p][MAP_SIZE] )*/
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!IS_ATOM_INT(_the_map_p_12598)){
        _7027 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_12598)->dbl));
    }
    else{
        _7027 = (object)*(((s1_ptr)_2)->base + _the_map_p_12598);
    }
    _2 = (object)SEQ_PTR(_7027);
    _7028 = (object)*(((s1_ptr)_2)->base + 1LL);
    _7027 = NOVALUE;
    DeRef(_keys_12603);
    _keys_12603 = Repeat(0LL, _7028);
    _7028 = NOVALUE;

    /** map.e:903		integer kx = 0*/
    _kx_12607 = 0LL;

    /** map.e:904		for i = 1 to length( slots ) do*/
    if (IS_SEQUENCE(_slots_12600)){
            _7030 = SEQ_PTR(_slots_12600)->length;
    }
    else {
        _7030 = 1;
    }
    {
        object _i_12609;
        _i_12609 = 1LL;
L1: 
        if (_i_12609 > _7030){
            goto L2; // [43] 106
        }

        /** map.e:905			if slots[i][SLOT_HASH] >= 0 then*/
        _2 = (object)SEQ_PTR(_slots_12600);
        _7031 = (object)*(((s1_ptr)_2)->base + _i_12609);
        _2 = (object)SEQ_PTR(_7031);
        _7032 = (object)*(((s1_ptr)_2)->base + 1LL);
        _7031 = NOVALUE;
        if (binary_op_a(LESS, _7032, 0LL)){
            _7032 = NOVALUE;
            goto L3; // [60] 99
        }
        _7032 = NOVALUE;

        /** map.e:906				kx += 1*/
        _kx_12607 = _kx_12607 + 1;

        /** map.e:907				keys[kx] = slots[i][SLOT_KEY]*/
        _2 = (object)SEQ_PTR(_slots_12600);
        _7035 = (object)*(((s1_ptr)_2)->base + _i_12609);
        _2 = (object)SEQ_PTR(_7035);
        _7036 = (object)*(((s1_ptr)_2)->base + 2LL);
        _7035 = NOVALUE;
        Ref(_7036);
        _2 = (object)SEQ_PTR(_keys_12603);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _keys_12603 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _kx_12607);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _7036;
        if( _1 != _7036 ){
            DeRef(_1);
        }
        _7036 = NOVALUE;

        /** map.e:908				if kx = length( keys ) then*/
        if (IS_SEQUENCE(_keys_12603)){
                _7037 = SEQ_PTR(_keys_12603)->length;
        }
        else {
            _7037 = 1;
        }
        if (_kx_12607 != _7037)
        goto L4; // [89] 98

        /** map.e:909					exit*/
        goto L2; // [95] 106
L4: 
L3: 

        /** map.e:912		end for*/
        _i_12609 = _i_12609 + 1LL;
        goto L1; // [101] 50
L2: 
        ;
    }

    /** map.e:913		if sorted_result then*/
    if (_sorted_result_12599 == 0)
    {
        goto L5; // [108] 123
    }
    else{
    }

    /** map.e:914			return stdsort:sort( keys )*/
    RefDS(_keys_12603);
    _7039 = _24sort(_keys_12603, 1LL);
    DeRef(_the_map_p_12598);
    DeRef(_slots_12600);
    DeRefDS(_keys_12603);
    return _7039;
L5: 

    /** map.e:916		return keys*/
    DeRef(_the_map_p_12598);
    DeRef(_slots_12600);
    DeRef(_7039);
    _7039 = NOVALUE;
    return _keys_12603;
    ;
}


object _29pairs(object _the_map_12674, object _sorted_result_12675)
{
    object _slots_12676 = NOVALUE;
    object _pairs_12679 = NOVALUE;
    object _px_12683 = NOVALUE;
    object _7089 = NOVALUE;
    object _7087 = NOVALUE;
    object _7086 = NOVALUE;
    object _7085 = NOVALUE;
    object _7084 = NOVALUE;
    object _7083 = NOVALUE;
    object _7082 = NOVALUE;
    object _7079 = NOVALUE;
    object _7078 = NOVALUE;
    object _7077 = NOVALUE;
    object _7075 = NOVALUE;
    object _7074 = NOVALUE;
    object _7072 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:1045		sequence slots = eumem:ram_space[the_map][MAP_SLOTS]*/
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!IS_ATOM_INT(_the_map_12674)){
        _7072 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_12674)->dbl));
    }
    else{
        _7072 = (object)*(((s1_ptr)_2)->base + _the_map_12674);
    }
    DeRef(_slots_12676);
    _2 = (object)SEQ_PTR(_7072);
    _slots_12676 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_slots_12676);
    _7072 = NOVALUE;

    /** map.e:1046		sequence pairs = repeat( 0, eumem:ram_space[the_map][MAP_SIZE] )*/
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!IS_ATOM_INT(_the_map_12674)){
        _7074 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_12674)->dbl));
    }
    else{
        _7074 = (object)*(((s1_ptr)_2)->base + _the_map_12674);
    }
    _2 = (object)SEQ_PTR(_7074);
    _7075 = (object)*(((s1_ptr)_2)->base + 1LL);
    _7074 = NOVALUE;
    DeRef(_pairs_12679);
    _pairs_12679 = Repeat(0LL, _7075);
    _7075 = NOVALUE;

    /** map.e:1047		integer px = 0*/
    _px_12683 = 0LL;

    /** map.e:1048		for i = 1 to length( slots ) do*/
    if (IS_SEQUENCE(_slots_12676)){
            _7077 = SEQ_PTR(_slots_12676)->length;
    }
    else {
        _7077 = 1;
    }
    {
        object _i_12685;
        _i_12685 = 1LL;
L1: 
        if (_i_12685 > _7077){
            goto L2; // [43] 118
        }

        /** map.e:1049			if slots[i][SLOT_HASH] >= 0 then*/
        _2 = (object)SEQ_PTR(_slots_12676);
        _7078 = (object)*(((s1_ptr)_2)->base + _i_12685);
        _2 = (object)SEQ_PTR(_7078);
        _7079 = (object)*(((s1_ptr)_2)->base + 1LL);
        _7078 = NOVALUE;
        if (binary_op_a(LESS, _7079, 0LL)){
            _7079 = NOVALUE;
            goto L3; // [60] 111
        }
        _7079 = NOVALUE;

        /** map.e:1050				px += 1*/
        _px_12683 = _px_12683 + 1;

        /** map.e:1051				pairs[px] = { slots[i][SLOT_KEY], slots[i][SLOT_VALUE] }*/
        _2 = (object)SEQ_PTR(_slots_12676);
        _7082 = (object)*(((s1_ptr)_2)->base + _i_12685);
        _2 = (object)SEQ_PTR(_7082);
        _7083 = (object)*(((s1_ptr)_2)->base + 2LL);
        _7082 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_12676);
        _7084 = (object)*(((s1_ptr)_2)->base + _i_12685);
        _2 = (object)SEQ_PTR(_7084);
        _7085 = (object)*(((s1_ptr)_2)->base + 3LL);
        _7084 = NOVALUE;
        Ref(_7085);
        Ref(_7083);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _7083;
        ((intptr_t *)_2)[2] = _7085;
        _7086 = MAKE_SEQ(_1);
        _7085 = NOVALUE;
        _7083 = NOVALUE;
        _2 = (object)SEQ_PTR(_pairs_12679);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _pairs_12679 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _px_12683);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _7086;
        if( _1 != _7086 ){
            DeRef(_1);
        }
        _7086 = NOVALUE;

        /** map.e:1052				if px = length( pairs ) then*/
        if (IS_SEQUENCE(_pairs_12679)){
                _7087 = SEQ_PTR(_pairs_12679)->length;
        }
        else {
            _7087 = 1;
        }
        if (_px_12683 != _7087)
        goto L4; // [101] 110

        /** map.e:1053					exit*/
        goto L2; // [107] 118
L4: 
L3: 

        /** map.e:1056		end for*/
        _i_12685 = _i_12685 + 1LL;
        goto L1; // [113] 50
L2: 
        ;
    }

    /** map.e:1057		if sorted_result then*/
    if (_sorted_result_12675 == 0)
    {
        goto L5; // [120] 135
    }
    else{
    }

    /** map.e:1058			return stdsort:sort( pairs )*/
    RefDS(_pairs_12679);
    _7089 = _24sort(_pairs_12679, 1LL);
    DeRef(_the_map_12674);
    DeRef(_slots_12676);
    DeRefDS(_pairs_12679);
    return _7089;
L5: 

    /** map.e:1060		return pairs*/
    DeRef(_the_map_12674);
    DeRef(_slots_12676);
    DeRef(_7089);
    _7089 = NOVALUE;
    return _pairs_12679;
    ;
}



// 0x2A4E5182
