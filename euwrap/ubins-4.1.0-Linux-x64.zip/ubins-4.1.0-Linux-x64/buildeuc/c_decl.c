// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _58get_eucompiledir()
{
    object _x_42581 = NOVALUE;
    object _22365 = NOVALUE;
    object _22363 = NOVALUE;
    object _22360 = NOVALUE;
    object _22358 = NOVALUE;
    object _22356 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:133		object x = getenv("EUCOMPILEDIR")*/
    DeRef(_x_42581);
    _x_42581 = EGetEnv(_22354);

    /** c_decl.e:134		if is_eudir_from_cmdline() then*/
    _22356 = _37is_eudir_from_cmdline();
    if (_22356 == 0) {
        DeRef(_22356);
        _22356 = NOVALUE;
        goto L1; // [11] 20
    }
    else {
        if (!IS_ATOM_INT(_22356) && DBL_PTR(_22356)->dbl == 0.0){
            DeRef(_22356);
            _22356 = NOVALUE;
            goto L1; // [11] 20
        }
        DeRef(_22356);
        _22356 = NOVALUE;
    }
    DeRef(_22356);
    _22356 = NOVALUE;

    /** c_decl.e:135			x = get_eudir()*/
    _0 = _x_42581;
    _x_42581 = _37get_eudir();
    DeRefi(_0);
L1: 

    /** c_decl.e:138		ifdef UNIX then*/

    /** c_decl.e:139			if equal(x, -1) then*/
    if (_x_42581 == -1LL)
    _22358 = 1;
    else if (IS_ATOM_INT(_x_42581) && IS_ATOM_INT(-1LL))
    _22358 = 0;
    else
    _22358 = (compare(_x_42581, -1LL) == 0);
    if (_22358 == 0)
    {
        _22358 = NOVALUE;
        goto L2; // [28] 67
    }
    else{
        _22358 = NOVALUE;
    }

    /** c_decl.e:140				x = "/usr/local/share/euphoria"*/
    RefDS(_22359);
    DeRef(_x_42581);
    _x_42581 = _22359;

    /** c_decl.e:141				if not file_exists( x ) then*/
    RefDS(_x_42581);
    _22360 = _17file_exists(_x_42581);
    if (IS_ATOM_INT(_22360)) {
        if (_22360 != 0){
            DeRef(_22360);
            _22360 = NOVALUE;
            goto L3; // [42] 66
        }
    }
    else {
        if (DBL_PTR(_22360)->dbl != 0.0){
            DeRef(_22360);
            _22360 = NOVALUE;
            goto L3; // [42] 66
        }
    }
    DeRef(_22360);
    _22360 = NOVALUE;

    /** c_decl.e:144					x = "/usr/share/euphoria"*/
    RefDS(_22362);
    DeRefDSi(_x_42581);
    _x_42581 = _22362;

    /** c_decl.e:145					if not file_exists( x ) then*/
    RefDS(_x_42581);
    _22363 = _17file_exists(_x_42581);
    if (IS_ATOM_INT(_22363)) {
        if (_22363 != 0){
            DeRef(_22363);
            _22363 = NOVALUE;
            goto L4; // [56] 65
        }
    }
    else {
        if (DBL_PTR(_22363)->dbl != 0.0){
            DeRef(_22363);
            _22363 = NOVALUE;
            goto L4; // [56] 65
        }
    }
    DeRef(_22363);
    _22363 = NOVALUE;

    /** c_decl.e:146						x = -1*/
    DeRefDSi(_x_42581);
    _x_42581 = -1LL;
L4: 
L3: 
L2: 

    /** c_decl.e:152		if equal(x, -1) then*/
    if (_x_42581 == -1LL)
    _22365 = 1;
    else if (IS_ATOM_INT(_x_42581) && IS_ATOM_INT(-1LL))
    _22365 = 0;
    else
    _22365 = (compare(_x_42581, -1LL) == 0);
    if (_22365 == 0)
    {
        _22365 = NOVALUE;
        goto L5; // [73] 82
    }
    else{
        _22365 = NOVALUE;
    }

    /** c_decl.e:153			x = get_eudir()*/
    _0 = _x_42581;
    _x_42581 = _37get_eudir();
    DeRef(_0);
L5: 

    /** c_decl.e:156		return x*/
    return _x_42581;
    ;
}


void _58NewBB(object _a_call_42607, object _mask_42608, object _sub_42610)
{
    object _s_42612 = NOVALUE;
    object _22398 = NOVALUE;
    object _22397 = NOVALUE;
    object _22395 = NOVALUE;
    object _22394 = NOVALUE;
    object _22392 = NOVALUE;
    object _22391 = NOVALUE;
    object _22390 = NOVALUE;
    object _22389 = NOVALUE;
    object _22388 = NOVALUE;
    object _22387 = NOVALUE;
    object _22386 = NOVALUE;
    object _22385 = NOVALUE;
    object _22384 = NOVALUE;
    object _22383 = NOVALUE;
    object _22382 = NOVALUE;
    object _22381 = NOVALUE;
    object _22380 = NOVALUE;
    object _22379 = NOVALUE;
    object _22378 = NOVALUE;
    object _22377 = NOVALUE;
    object _22376 = NOVALUE;
    object _22375 = NOVALUE;
    object _22374 = NOVALUE;
    object _22373 = NOVALUE;
    object _22372 = NOVALUE;
    object _22371 = NOVALUE;
    object _22370 = NOVALUE;
    object _22368 = NOVALUE;
    object _22367 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_mask_42608)) {
        _1 = (object)(DBL_PTR(_mask_42608)->dbl);
        DeRefDS(_mask_42608);
        _mask_42608 = _1;
    }

    /** c_decl.e:166		if a_call then*/
    if (_a_call_42607 == 0)
    {
        goto L1; // [9] 252
    }
    else{
    }

    /** c_decl.e:169			for i = 1 to length(BB_info) do*/
    if (IS_SEQUENCE(_58BB_info_42559)){
            _22367 = SEQ_PTR(_58BB_info_42559)->length;
    }
    else {
        _22367 = 1;
    }
    {
        object _i_42615;
        _i_42615 = 1LL;
L2: 
        if (_i_42615 > _22367){
            goto L3; // [19] 249
        }

        /** c_decl.e:170				s = BB_info[i][BB_VAR]*/
        _2 = (object)SEQ_PTR(_58BB_info_42559);
        _22368 = (object)*(((s1_ptr)_2)->base + _i_42615);
        _2 = (object)SEQ_PTR(_22368);
        _s_42612 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (!IS_ATOM_INT(_s_42612)){
            _s_42612 = (object)DBL_PTR(_s_42612)->dbl;
        }
        _22368 = NOVALUE;

        /** c_decl.e:171				if SymTab[s][S_MODE] = M_NORMAL and*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _22370 = (object)*(((s1_ptr)_2)->base + _s_42612);
        _2 = (object)SEQ_PTR(_22370);
        _22371 = (object)*(((s1_ptr)_2)->base + 3LL);
        _22370 = NOVALUE;
        if (IS_ATOM_INT(_22371)) {
            _22372 = (_22371 == 1LL);
        }
        else {
            _22372 = binary_op(EQUALS, _22371, 1LL);
        }
        _22371 = NOVALUE;
        if (IS_ATOM_INT(_22372)) {
            if (_22372 == 0) {
                goto L4; // [60] 242
            }
        }
        else {
            if (DBL_PTR(_22372)->dbl == 0.0) {
                goto L4; // [60] 242
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _22374 = (object)*(((s1_ptr)_2)->base + _s_42612);
        _2 = (object)SEQ_PTR(_22374);
        _22375 = (object)*(((s1_ptr)_2)->base + 4LL);
        _22374 = NOVALUE;
        if (IS_ATOM_INT(_22375)) {
            _22376 = (_22375 == 6LL);
        }
        else {
            _22376 = binary_op(EQUALS, _22375, 6LL);
        }
        _22375 = NOVALUE;
        if (IS_ATOM_INT(_22376)) {
            if (_22376 != 0) {
                DeRef(_22377);
                _22377 = 1;
                goto L5; // [82] 108
            }
        }
        else {
            if (DBL_PTR(_22376)->dbl != 0.0) {
                DeRef(_22377);
                _22377 = 1;
                goto L5; // [82] 108
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _22378 = (object)*(((s1_ptr)_2)->base + _s_42612);
        _2 = (object)SEQ_PTR(_22378);
        _22379 = (object)*(((s1_ptr)_2)->base + 4LL);
        _22378 = NOVALUE;
        if (IS_ATOM_INT(_22379)) {
            _22380 = (_22379 == 5LL);
        }
        else {
            _22380 = binary_op(EQUALS, _22379, 5LL);
        }
        _22379 = NOVALUE;
        DeRef(_22377);
        if (IS_ATOM_INT(_22380))
        _22377 = (_22380 != 0);
        else
        _22377 = DBL_PTR(_22380)->dbl != 0.0;
L5: 
        if (_22377 != 0) {
            _22381 = 1;
            goto L6; // [108] 134
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _22382 = (object)*(((s1_ptr)_2)->base + _s_42612);
        _2 = (object)SEQ_PTR(_22382);
        _22383 = (object)*(((s1_ptr)_2)->base + 4LL);
        _22382 = NOVALUE;
        if (IS_ATOM_INT(_22383)) {
            _22384 = (_22383 == 11LL);
        }
        else {
            _22384 = binary_op(EQUALS, _22383, 11LL);
        }
        _22383 = NOVALUE;
        if (IS_ATOM_INT(_22384))
        _22381 = (_22384 != 0);
        else
        _22381 = DBL_PTR(_22384)->dbl != 0.0;
L6: 
        if (_22381 != 0) {
            DeRef(_22385);
            _22385 = 1;
            goto L7; // [134] 160
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _22386 = (object)*(((s1_ptr)_2)->base + _s_42612);
        _2 = (object)SEQ_PTR(_22386);
        _22387 = (object)*(((s1_ptr)_2)->base + 4LL);
        _22386 = NOVALUE;
        if (IS_ATOM_INT(_22387)) {
            _22388 = (_22387 == 13LL);
        }
        else {
            _22388 = binary_op(EQUALS, _22387, 13LL);
        }
        _22387 = NOVALUE;
        if (IS_ATOM_INT(_22388))
        _22385 = (_22388 != 0);
        else
        _22385 = DBL_PTR(_22388)->dbl != 0.0;
L7: 
        if (_22385 == 0)
        {
            _22385 = NOVALUE;
            goto L4; // [161] 242
        }
        else{
            _22385 = NOVALUE;
        }

        /** c_decl.e:176					  if and_bits(mask, power(2, remainder(s, E_SIZE))) then*/
        _22389 = (_s_42612 % 29LL);
        _22390 = power(2LL, _22389);
        _22389 = NOVALUE;
        if (IS_ATOM_INT(_22390)) {
            {uintptr_t tu;
                 tu = (uintptr_t)_mask_42608 & (uintptr_t)_22390;
                 _22391 = MAKE_UINT(tu);
            }
        }
        else {
            temp_d.dbl = (eudouble)_mask_42608;
            _22391 = Dand_bits(&temp_d, DBL_PTR(_22390));
        }
        DeRef(_22390);
        _22390 = NOVALUE;
        if (_22391 == 0) {
            DeRef(_22391);
            _22391 = NOVALUE;
            goto L8; // [180] 241
        }
        else {
            if (!IS_ATOM_INT(_22391) && DBL_PTR(_22391)->dbl == 0.0){
                DeRef(_22391);
                _22391 = NOVALUE;
                goto L8; // [180] 241
            }
            DeRef(_22391);
            _22391 = NOVALUE;
        }
        DeRef(_22391);
        _22391 = NOVALUE;

        /** c_decl.e:177						  if mask = E_ALL_EFFECT or s < sub then*/
        _22392 = (_mask_42608 == 1073741823LL);
        if (_22392 != 0) {
            goto L9; // [191] 204
        }
        _22394 = (_s_42612 < _sub_42610);
        if (_22394 == 0)
        {
            DeRef(_22394);
            _22394 = NOVALUE;
            goto LA; // [200] 240
        }
        else{
            DeRef(_22394);
            _22394 = NOVALUE;
        }
L9: 

        /** c_decl.e:178							  BB_info[i][BB_TYPE..BB_OBJ] =*/
        _2 = (object)SEQ_PTR(_58BB_info_42559);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _58BB_info_42559 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_42615 + ((s1_ptr)_2)->base);
        Ref(_36MAXINT_21262);
        Ref(_36MININT_21263);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _36MININT_21263;
        ((intptr_t *)_2)[2] = _36MAXINT_21262;
        _22397 = MAKE_SEQ(_1);
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = 0LL;
        ((intptr_t*)_2)[2] = 0LL;
        Ref(_36NOVALUE_21293);
        ((intptr_t*)_2)[3] = _36NOVALUE_21293;
        ((intptr_t*)_2)[4] = _22397;
        _22398 = MAKE_SEQ(_1);
        _22397 = NOVALUE;
        assign_slice_seq = (s1_ptr *)_3;
        AssignSlice(2LL, 5LL, _22398);
        DeRefDS(_22398);
        _22398 = NOVALUE;
LA: 
L8: 
L4: 

        /** c_decl.e:183			end for*/
        _i_42615 = _i_42615 + 1LL;
        goto L2; // [244] 26
L3: 
        ;
    }
    goto LB; // [249] 260
L1: 

    /** c_decl.e:186			BB_info = {}*/
    RefDS(_21993);
    DeRef(_58BB_info_42559);
    _58BB_info_42559 = _21993;
LB: 

    /** c_decl.e:188	end procedure*/
    DeRef(_22376);
    _22376 = NOVALUE;
    DeRef(_22392);
    _22392 = NOVALUE;
    DeRef(_22372);
    _22372 = NOVALUE;
    DeRef(_22384);
    _22384 = NOVALUE;
    DeRef(_22380);
    _22380 = NOVALUE;
    DeRef(_22388);
    _22388 = NOVALUE;
    DeRef(_22395);
    _22395 = NOVALUE;
    return;
    ;
}


object _58BB_var_obj(object _var_42680)
{
    object _bbi_42681 = NOVALUE;
    object _22409 = NOVALUE;
    object _22407 = NOVALUE;
    object _22405 = NOVALUE;
    object _22404 = NOVALUE;
    object _22402 = NOVALUE;
    object _22400 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:196		for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_58BB_info_42559)){
            _22400 = SEQ_PTR(_58BB_info_42559)->length;
    }
    else {
        _22400 = 1;
    }
    {
        object _i_42683;
        _i_42683 = _22400;
L1: 
        if (_i_42683 < 1LL){
            goto L2; // [10] 99
        }

        /** c_decl.e:197			bbi = BB_info[i]*/
        DeRef(_bbi_42681);
        _2 = (object)SEQ_PTR(_58BB_info_42559);
        _bbi_42681 = (object)*(((s1_ptr)_2)->base + _i_42683);
        Ref(_bbi_42681);

        /** c_decl.e:198			if bbi[BB_VAR] != var then*/
        _2 = (object)SEQ_PTR(_bbi_42681);
        _22402 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(EQUALS, _22402, _var_42680)){
            _22402 = NOVALUE;
            goto L3; // [31] 40
        }
        _22402 = NOVALUE;

        /** c_decl.e:199				continue*/
        goto L4; // [37] 94
L3: 

        /** c_decl.e:202			if SymTab[var][S_MODE] != M_NORMAL then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _22404 = (object)*(((s1_ptr)_2)->base + _var_42680);
        _2 = (object)SEQ_PTR(_22404);
        _22405 = (object)*(((s1_ptr)_2)->base + 3LL);
        _22404 = NOVALUE;
        if (binary_op_a(EQUALS, _22405, 1LL)){
            _22405 = NOVALUE;
            goto L5; // [56] 65
        }
        _22405 = NOVALUE;

        /** c_decl.e:203				continue*/
        goto L4; // [62] 94
L5: 

        /** c_decl.e:206			if bbi[BB_TYPE] != TYPE_INTEGER then*/
        _2 = (object)SEQ_PTR(_bbi_42681);
        _22407 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (binary_op_a(EQUALS, _22407, 1LL)){
            _22407 = NOVALUE;
            goto L6; // [73] 82
        }
        _22407 = NOVALUE;

        /** c_decl.e:207				exit*/
        goto L2; // [79] 99
L6: 

        /** c_decl.e:210			return bbi[BB_OBJ]*/
        _2 = (object)SEQ_PTR(_bbi_42681);
        _22409 = (object)*(((s1_ptr)_2)->base + 5LL);
        Ref(_22409);
        DeRef(_bbi_42681);
        return _22409;

        /** c_decl.e:211		end for*/
L4: 
        _i_42683 = _i_42683 + -1LL;
        goto L1; // [94] 17
L2: 
        ;
    }

    /** c_decl.e:212		return BB_def_values*/
    RefDS(_58BB_def_values_42674);
    DeRef(_bbi_42681);
    _22409 = NOVALUE;
    return _58BB_def_values_42674;
    ;
}


object _58BB_var_type(object _var_42703)
{
    object _22424 = NOVALUE;
    object _22423 = NOVALUE;
    object _22421 = NOVALUE;
    object _22420 = NOVALUE;
    object _22419 = NOVALUE;
    object _22418 = NOVALUE;
    object _22417 = NOVALUE;
    object _22416 = NOVALUE;
    object _22415 = NOVALUE;
    object _22414 = NOVALUE;
    object _22413 = NOVALUE;
    object _22412 = NOVALUE;
    object _22411 = NOVALUE;
    object _22410 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:218		for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_58BB_info_42559)){
            _22410 = SEQ_PTR(_58BB_info_42559)->length;
    }
    else {
        _22410 = 1;
    }
    {
        object _i_42705;
        _i_42705 = _22410;
L1: 
        if (_i_42705 < 1LL){
            goto L2; // [10] 125
        }

        /** c_decl.e:219			if BB_info[i][BB_VAR] = var and*/
        _2 = (object)SEQ_PTR(_58BB_info_42559);
        _22411 = (object)*(((s1_ptr)_2)->base + _i_42705);
        _2 = (object)SEQ_PTR(_22411);
        _22412 = (object)*(((s1_ptr)_2)->base + 1LL);
        _22411 = NOVALUE;
        if (IS_ATOM_INT(_22412)) {
            _22413 = (_22412 == _var_42703);
        }
        else {
            _22413 = binary_op(EQUALS, _22412, _var_42703);
        }
        _22412 = NOVALUE;
        if (IS_ATOM_INT(_22413)) {
            if (_22413 == 0) {
                goto L3; // [33] 118
            }
        }
        else {
            if (DBL_PTR(_22413)->dbl == 0.0) {
                goto L3; // [33] 118
            }
        }
        _2 = (object)SEQ_PTR(_58BB_info_42559);
        _22415 = (object)*(((s1_ptr)_2)->base + _i_42705);
        _2 = (object)SEQ_PTR(_22415);
        _22416 = (object)*(((s1_ptr)_2)->base + 1LL);
        _22415 = NOVALUE;
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!IS_ATOM_INT(_22416)){
            _22417 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_22416)->dbl));
        }
        else{
            _22417 = (object)*(((s1_ptr)_2)->base + _22416);
        }
        _2 = (object)SEQ_PTR(_22417);
        _22418 = (object)*(((s1_ptr)_2)->base + 3LL);
        _22417 = NOVALUE;
        if (IS_ATOM_INT(_22418)) {
            _22419 = (_22418 == 1LL);
        }
        else {
            _22419 = binary_op(EQUALS, _22418, 1LL);
        }
        _22418 = NOVALUE;
        if (_22419 == 0) {
            DeRef(_22419);
            _22419 = NOVALUE;
            goto L3; // [66] 118
        }
        else {
            if (!IS_ATOM_INT(_22419) && DBL_PTR(_22419)->dbl == 0.0){
                DeRef(_22419);
                _22419 = NOVALUE;
                goto L3; // [66] 118
            }
            DeRef(_22419);
            _22419 = NOVALUE;
        }
        DeRef(_22419);
        _22419 = NOVALUE;

        /** c_decl.e:221				ifdef DEBUG then*/

        /** c_decl.e:228				if BB_info[i][BB_TYPE] = TYPE_NULL then  -- var has only been read*/
        _2 = (object)SEQ_PTR(_58BB_info_42559);
        _22420 = (object)*(((s1_ptr)_2)->base + _i_42705);
        _2 = (object)SEQ_PTR(_22420);
        _22421 = (object)*(((s1_ptr)_2)->base + 2LL);
        _22420 = NOVALUE;
        if (binary_op_a(NOTEQ, _22421, 0LL)){
            _22421 = NOVALUE;
            goto L4; // [85] 100
        }
        _22421 = NOVALUE;

        /** c_decl.e:229					return TYPE_OBJECT*/
        DeRef(_22413);
        _22413 = NOVALUE;
        _22416 = NOVALUE;
        return 16LL;
        goto L5; // [97] 117
L4: 

        /** c_decl.e:231					return BB_info[i][BB_TYPE]*/
        _2 = (object)SEQ_PTR(_58BB_info_42559);
        _22423 = (object)*(((s1_ptr)_2)->base + _i_42705);
        _2 = (object)SEQ_PTR(_22423);
        _22424 = (object)*(((s1_ptr)_2)->base + 2LL);
        _22423 = NOVALUE;
        Ref(_22424);
        DeRef(_22413);
        _22413 = NOVALUE;
        _22416 = NOVALUE;
        return _22424;
L5: 
L3: 

        /** c_decl.e:234		end for*/
        _i_42705 = _i_42705 + -1LL;
        goto L1; // [120] 17
L2: 
        ;
    }

    /** c_decl.e:235		return TYPE_OBJECT*/
    DeRef(_22413);
    _22413 = NOVALUE;
    _22424 = NOVALUE;
    _22416 = NOVALUE;
    return 16LL;
    ;
}


object _58GType(object _s_42733)
{
    object _t_42734 = NOVALUE;
    object _local_t_42735 = NOVALUE;
    object _22428 = NOVALUE;
    object _22427 = NOVALUE;
    object _22425 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_42733)) {
        _1 = (object)(DBL_PTR(_s_42733)->dbl);
        DeRefDS(_s_42733);
        _s_42733 = _1;
    }

    /** c_decl.e:243		t = SymTab[s][S_GTYPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22425 = (object)*(((s1_ptr)_2)->base + _s_42733);
    _2 = (object)SEQ_PTR(_22425);
    _t_42734 = (object)*(((s1_ptr)_2)->base + 36LL);
    if (!IS_ATOM_INT(_t_42734)){
        _t_42734 = (object)DBL_PTR(_t_42734)->dbl;
    }
    _22425 = NOVALUE;

    /** c_decl.e:244		ifdef DEBUG then*/

    /** c_decl.e:250		if SymTab[s][S_MODE] != M_NORMAL then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22427 = (object)*(((s1_ptr)_2)->base + _s_42733);
    _2 = (object)SEQ_PTR(_22427);
    _22428 = (object)*(((s1_ptr)_2)->base + 3LL);
    _22427 = NOVALUE;
    if (binary_op_a(EQUALS, _22428, 1LL)){
        _22428 = NOVALUE;
        goto L1; // [37] 48
    }
    _22428 = NOVALUE;

    /** c_decl.e:251			return t*/
    return _t_42734;
L1: 

    /** c_decl.e:254		local_t = BB_var_type(s)*/
    _local_t_42735 = _58BB_var_type(_s_42733);
    if (!IS_ATOM_INT(_local_t_42735)) {
        _1 = (object)(DBL_PTR(_local_t_42735)->dbl);
        DeRefDS(_local_t_42735);
        _local_t_42735 = _1;
    }

    /** c_decl.e:255		if local_t = TYPE_OBJECT then*/
    if (_local_t_42735 != 16LL)
    goto L2; // [60] 71

    /** c_decl.e:256			return t*/
    return _t_42734;
L2: 

    /** c_decl.e:258		if t = TYPE_INTEGER then*/
    if (_t_42734 != 1LL)
    goto L3; // [75] 88

    /** c_decl.e:259			return TYPE_INTEGER*/
    return 1LL;
L3: 

    /** c_decl.e:261		return local_t*/
    return _local_t_42735;
    ;
}


object _58GDelete()
{
    object _0, _1, _2;
    

    /** c_decl.e:269		return g_has_delete*/
    return _58g_has_delete_42755;
    ;
}


object _58HasDelete(object _s_42762)
{
    object _22443 = NOVALUE;
    object _22442 = NOVALUE;
    object _22440 = NOVALUE;
    object _22439 = NOVALUE;
    object _22438 = NOVALUE;
    object _22437 = NOVALUE;
    object _22435 = NOVALUE;
    object _22434 = NOVALUE;
    object _22433 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_42762)) {
        _1 = (object)(DBL_PTR(_s_42762)->dbl);
        DeRefDS(_s_42762);
        _s_42762 = _1;
    }

    /** c_decl.e:274		for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_58BB_info_42559)){
            _22433 = SEQ_PTR(_58BB_info_42559)->length;
    }
    else {
        _22433 = 1;
    }
    {
        object _i_42764;
        _i_42764 = _22433;
L1: 
        if (_i_42764 < 1LL){
            goto L2; // [10] 57
        }

        /** c_decl.e:275			if BB_info[i][BB_VAR] = s then*/
        _2 = (object)SEQ_PTR(_58BB_info_42559);
        _22434 = (object)*(((s1_ptr)_2)->base + _i_42764);
        _2 = (object)SEQ_PTR(_22434);
        _22435 = (object)*(((s1_ptr)_2)->base + 1LL);
        _22434 = NOVALUE;
        if (binary_op_a(NOTEQ, _22435, _s_42762)){
            _22435 = NOVALUE;
            goto L3; // [29] 50
        }
        _22435 = NOVALUE;

        /** c_decl.e:276				return BB_info[i][BB_DELETE]*/
        _2 = (object)SEQ_PTR(_58BB_info_42559);
        _22437 = (object)*(((s1_ptr)_2)->base + _i_42764);
        _2 = (object)SEQ_PTR(_22437);
        _22438 = (object)*(((s1_ptr)_2)->base + 6LL);
        _22437 = NOVALUE;
        Ref(_22438);
        return _22438;
L3: 

        /** c_decl.e:278		end for*/
        _i_42764 = _i_42764 + -1LL;
        goto L1; // [52] 17
L2: 
        ;
    }

    /** c_decl.e:279		if length(SymTab[s]) < S_HAS_DELETE then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22439 = (object)*(((s1_ptr)_2)->base + _s_42762);
    if (IS_SEQUENCE(_22439)){
            _22440 = SEQ_PTR(_22439)->length;
    }
    else {
        _22440 = 1;
    }
    _22439 = NOVALUE;
    if (_22440 >= 54LL)
    goto L4; // [70] 81

    /** c_decl.e:280			return 0*/
    _22438 = NOVALUE;
    _22439 = NOVALUE;
    return 0LL;
L4: 

    /** c_decl.e:282		return SymTab[s][S_HAS_DELETE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22442 = (object)*(((s1_ptr)_2)->base + _s_42762);
    _2 = (object)SEQ_PTR(_22442);
    _22443 = (object)*(((s1_ptr)_2)->base + 54LL);
    _22442 = NOVALUE;
    Ref(_22443);
    _22438 = NOVALUE;
    _22439 = NOVALUE;
    return _22443;
    ;
}


object _58ObjValue(object _s_42785)
{
    object _local_t_42786 = NOVALUE;
    object _st_42787 = NOVALUE;
    object _tmin_42788 = NOVALUE;
    object _tmax_42789 = NOVALUE;
    object _22456 = NOVALUE;
    object _22454 = NOVALUE;
    object _22453 = NOVALUE;
    object _22451 = NOVALUE;
    object _22448 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_42785)) {
        _1 = (object)(DBL_PTR(_s_42785)->dbl);
        DeRefDS(_s_42785);
        _s_42785 = _1;
    }

    /** c_decl.e:293		st = SymTab[s]*/
    DeRef(_st_42787);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _st_42787 = (object)*(((s1_ptr)_2)->base + _s_42785);
    Ref(_st_42787);

    /** c_decl.e:294		tmin = st[S_OBJ_MIN]*/
    DeRef(_tmin_42788);
    _2 = (object)SEQ_PTR(_st_42787);
    _tmin_42788 = (object)*(((s1_ptr)_2)->base + 30LL);
    Ref(_tmin_42788);

    /** c_decl.e:295		tmax = st[S_OBJ_MAX]*/
    DeRef(_tmax_42789);
    _2 = (object)SEQ_PTR(_st_42787);
    _tmax_42789 = (object)*(((s1_ptr)_2)->base + 31LL);
    Ref(_tmax_42789);

    /** c_decl.e:297		if tmin != tmax then*/
    if (binary_op_a(EQUALS, _tmin_42788, _tmax_42789)){
        goto L1; // [29] 41
    }

    /** c_decl.e:298			tmin = NOVALUE*/
    Ref(_36NOVALUE_21293);
    DeRef(_tmin_42788);
    _tmin_42788 = _36NOVALUE_21293;
L1: 

    /** c_decl.e:300		if st[S_MODE] != M_NORMAL then*/
    _2 = (object)SEQ_PTR(_st_42787);
    _22448 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (binary_op_a(EQUALS, _22448, 1LL)){
        _22448 = NOVALUE;
        goto L2; // [51] 62
    }
    _22448 = NOVALUE;

    /** c_decl.e:301			return tmin*/
    DeRef(_local_t_42786);
    DeRef(_st_42787);
    DeRef(_tmax_42789);
    return _tmin_42788;
L2: 

    /** c_decl.e:305		local_t = BB_var_obj(s)*/
    _0 = _local_t_42786;
    _local_t_42786 = _58BB_var_obj(_s_42785);
    DeRef(_0);

    /** c_decl.e:306		if local_t[MIN] = NOVALUE then*/
    _2 = (object)SEQ_PTR(_local_t_42786);
    _22451 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _22451, _36NOVALUE_21293)){
        _22451 = NOVALUE;
        goto L3; // [80] 91
    }
    _22451 = NOVALUE;

    /** c_decl.e:307			return tmin*/
    DeRefDS(_local_t_42786);
    DeRef(_st_42787);
    DeRef(_tmax_42789);
    return _tmin_42788;
L3: 

    /** c_decl.e:310		if local_t[MIN] != local_t[MAX] then*/
    _2 = (object)SEQ_PTR(_local_t_42786);
    _22453 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_local_t_42786);
    _22454 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (binary_op_a(EQUALS, _22453, _22454)){
        _22453 = NOVALUE;
        _22454 = NOVALUE;
        goto L4; // [105] 116
    }
    _22453 = NOVALUE;
    _22454 = NOVALUE;

    /** c_decl.e:311			return tmin*/
    DeRefDS(_local_t_42786);
    DeRef(_st_42787);
    DeRef(_tmax_42789);
    return _tmin_42788;
L4: 

    /** c_decl.e:314		return local_t[MIN]*/
    _2 = (object)SEQ_PTR(_local_t_42786);
    _22456 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_22456);
    DeRefDS(_local_t_42786);
    DeRef(_st_42787);
    DeRef(_tmin_42788);
    DeRef(_tmax_42789);
    return _22456;
    ;
}


object _58TypeIs(object _x_42820, object _typei_42821)
{
    object _22458 = NOVALUE;
    object _22457 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_42820)) {
        _1 = (object)(DBL_PTR(_x_42820)->dbl);
        DeRefDS(_x_42820);
        _x_42820 = _1;
    }

    /** c_decl.e:319		return GType(x) = typei*/
    _22457 = _58GType(_x_42820);
    if (IS_ATOM_INT(_22457)) {
        _22458 = (_22457 == _typei_42821);
    }
    else {
        _22458 = binary_op(EQUALS, _22457, _typei_42821);
    }
    DeRef(_22457);
    _22457 = NOVALUE;
    return _22458;
    ;
}


object _58TypeIsIn(object _x_42826, object _types_42827)
{
    object _22460 = NOVALUE;
    object _22459 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_42826)) {
        _1 = (object)(DBL_PTR(_x_42826)->dbl);
        DeRefDS(_x_42826);
        _x_42826 = _1;
    }

    /** c_decl.e:323		return find(GType(x), types)*/
    _22459 = _58GType(_x_42826);
    _22460 = find_from(_22459, _types_42827, 1LL);
    DeRef(_22459);
    _22459 = NOVALUE;
    DeRefDS(_types_42827);
    return _22460;
    ;
}


object _58TypeIsNot(object _x_42832, object _typei_42833)
{
    object _22462 = NOVALUE;
    object _22461 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_42832)) {
        _1 = (object)(DBL_PTR(_x_42832)->dbl);
        DeRefDS(_x_42832);
        _x_42832 = _1;
    }

    /** c_decl.e:327		return GType(x) != typei*/
    _22461 = _58GType(_x_42832);
    if (IS_ATOM_INT(_22461)) {
        _22462 = (_22461 != _typei_42833);
    }
    else {
        _22462 = binary_op(NOTEQ, _22461, _typei_42833);
    }
    DeRef(_22461);
    _22461 = NOVALUE;
    return _22462;
    ;
}


object _58TypeIsNotIn(object _x_42838, object _types_42839)
{
    object _22465 = NOVALUE;
    object _22464 = NOVALUE;
    object _22463 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_42838)) {
        _1 = (object)(DBL_PTR(_x_42838)->dbl);
        DeRefDS(_x_42838);
        _x_42838 = _1;
    }

    /** c_decl.e:331		return not find(GType(x), types)*/
    _22463 = _58GType(_x_42838);
    _22464 = find_from(_22463, _types_42839, 1LL);
    DeRef(_22463);
    _22463 = NOVALUE;
    _22465 = (_22464 == 0);
    _22464 = NOVALUE;
    DeRefDS(_types_42839);
    return _22465;
    ;
}


object _58or_type(object _t1_42845, object _t2_42846)
{
    object _22485 = NOVALUE;
    object _22484 = NOVALUE;
    object _22483 = NOVALUE;
    object _22482 = NOVALUE;
    object _22477 = NOVALUE;
    object _22475 = NOVALUE;
    object _22470 = NOVALUE;
    object _22468 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_t1_42845)) {
        _1 = (object)(DBL_PTR(_t1_42845)->dbl);
        DeRefDS(_t1_42845);
        _t1_42845 = _1;
    }
    if (!IS_ATOM_INT(_t2_42846)) {
        _1 = (object)(DBL_PTR(_t2_42846)->dbl);
        DeRefDS(_t2_42846);
        _t2_42846 = _1;
    }

    /** c_decl.e:337		if t1 = TYPE_NULL then*/
    if (_t1_42845 != 0LL)
    goto L1; // [9] 22

    /** c_decl.e:338			return t2*/
    return _t2_42846;
    goto L2; // [19] 307
L1: 

    /** c_decl.e:340		elsif t2 = TYPE_NULL then*/
    if (_t2_42846 != 0LL)
    goto L3; // [26] 39

    /** c_decl.e:341			return t1*/
    return _t1_42845;
    goto L2; // [36] 307
L3: 

    /** c_decl.e:343		elsif t1 = TYPE_OBJECT or t2 = TYPE_OBJECT then*/
    _22468 = (_t1_42845 == 16LL);
    if (_22468 != 0) {
        goto L4; // [47] 62
    }
    _22470 = (_t2_42846 == 16LL);
    if (_22470 == 0)
    {
        DeRef(_22470);
        _22470 = NOVALUE;
        goto L5; // [58] 73
    }
    else{
        DeRef(_22470);
        _22470 = NOVALUE;
    }
L4: 

    /** c_decl.e:344			return TYPE_OBJECT*/
    DeRef(_22468);
    _22468 = NOVALUE;
    return 16LL;
    goto L2; // [70] 307
L5: 

    /** c_decl.e:346		elsif t1 = TYPE_SEQUENCE then*/
    if (_t1_42845 != 8LL)
    goto L6; // [77] 112

    /** c_decl.e:347			if t2 = TYPE_SEQUENCE then*/
    if (_t2_42846 != 8LL)
    goto L7; // [85] 100

    /** c_decl.e:348				return TYPE_SEQUENCE*/
    DeRef(_22468);
    _22468 = NOVALUE;
    return 8LL;
    goto L2; // [97] 307
L7: 

    /** c_decl.e:350				return TYPE_OBJECT*/
    DeRef(_22468);
    _22468 = NOVALUE;
    return 16LL;
    goto L2; // [109] 307
L6: 

    /** c_decl.e:353		elsif t2 = TYPE_SEQUENCE then*/
    if (_t2_42846 != 8LL)
    goto L8; // [116] 151

    /** c_decl.e:354			if t1 = TYPE_SEQUENCE then*/
    if (_t1_42845 != 8LL)
    goto L9; // [124] 139

    /** c_decl.e:355				return TYPE_SEQUENCE*/
    DeRef(_22468);
    _22468 = NOVALUE;
    return 8LL;
    goto L2; // [136] 307
L9: 

    /** c_decl.e:357				return TYPE_OBJECT*/
    DeRef(_22468);
    _22468 = NOVALUE;
    return 16LL;
    goto L2; // [148] 307
L8: 

    /** c_decl.e:360		elsif t1 = TYPE_ATOM or t2 = TYPE_ATOM then*/
    _22475 = (_t1_42845 == 4LL);
    if (_22475 != 0) {
        goto LA; // [159] 174
    }
    _22477 = (_t2_42846 == 4LL);
    if (_22477 == 0)
    {
        DeRef(_22477);
        _22477 = NOVALUE;
        goto LB; // [170] 185
    }
    else{
        DeRef(_22477);
        _22477 = NOVALUE;
    }
LA: 

    /** c_decl.e:361			return TYPE_ATOM*/
    DeRef(_22468);
    _22468 = NOVALUE;
    DeRef(_22475);
    _22475 = NOVALUE;
    return 4LL;
    goto L2; // [182] 307
LB: 

    /** c_decl.e:363		elsif t1 = TYPE_DOUBLE then*/
    if (_t1_42845 != 2LL)
    goto LC; // [189] 224

    /** c_decl.e:364			if t2 = TYPE_INTEGER then*/
    if (_t2_42846 != 1LL)
    goto LD; // [197] 212

    /** c_decl.e:365				return TYPE_ATOM*/
    DeRef(_22468);
    _22468 = NOVALUE;
    DeRef(_22475);
    _22475 = NOVALUE;
    return 4LL;
    goto L2; // [209] 307
LD: 

    /** c_decl.e:367				return TYPE_DOUBLE*/
    DeRef(_22468);
    _22468 = NOVALUE;
    DeRef(_22475);
    _22475 = NOVALUE;
    return 2LL;
    goto L2; // [221] 307
LC: 

    /** c_decl.e:370		elsif t2 = TYPE_DOUBLE then*/
    if (_t2_42846 != 2LL)
    goto LE; // [228] 263

    /** c_decl.e:371			if t1 = TYPE_INTEGER then*/
    if (_t1_42845 != 1LL)
    goto LF; // [236] 251

    /** c_decl.e:372				return TYPE_ATOM*/
    DeRef(_22468);
    _22468 = NOVALUE;
    DeRef(_22475);
    _22475 = NOVALUE;
    return 4LL;
    goto L2; // [248] 307
LF: 

    /** c_decl.e:374				return TYPE_DOUBLE*/
    DeRef(_22468);
    _22468 = NOVALUE;
    DeRef(_22475);
    _22475 = NOVALUE;
    return 2LL;
    goto L2; // [260] 307
LE: 

    /** c_decl.e:377		elsif t1 = TYPE_INTEGER and t2 = TYPE_INTEGER then*/
    _22482 = (_t1_42845 == 1LL);
    if (_22482 == 0) {
        goto L10; // [271] 296
    }
    _22484 = (_t2_42846 == 1LL);
    if (_22484 == 0)
    {
        DeRef(_22484);
        _22484 = NOVALUE;
        goto L10; // [282] 296
    }
    else{
        DeRef(_22484);
        _22484 = NOVALUE;
    }

    /** c_decl.e:378			return TYPE_INTEGER*/
    DeRef(_22468);
    _22468 = NOVALUE;
    DeRef(_22482);
    _22482 = NOVALUE;
    DeRef(_22475);
    _22475 = NOVALUE;
    return 1LL;
    goto L2; // [293] 307
L10: 

    /** c_decl.e:381			InternalErr(258, {t1, t2})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _t1_42845;
    ((intptr_t *)_2)[2] = _t2_42846;
    _22485 = MAKE_SEQ(_1);
    _50InternalErr(258LL, _22485);
    _22485 = NOVALUE;
L2: 
    ;
}


void _58RemoveFromBB(object _s_42916)
{
    object _int_42917 = NOVALUE;
    object _22487 = NOVALUE;
    object _22486 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:388		for i = 1 to length(BB_info) do*/
    if (IS_SEQUENCE(_58BB_info_42559)){
            _22486 = SEQ_PTR(_58BB_info_42559)->length;
    }
    else {
        _22486 = 1;
    }
    {
        object _i_42919;
        _i_42919 = 1LL;
L1: 
        if (_i_42919 > _22486){
            goto L2; // [10] 59
        }

        /** c_decl.e:389			int = BB_info[i][BB_VAR]*/
        _2 = (object)SEQ_PTR(_58BB_info_42559);
        _22487 = (object)*(((s1_ptr)_2)->base + _i_42919);
        _2 = (object)SEQ_PTR(_22487);
        _int_42917 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (!IS_ATOM_INT(_int_42917)){
            _int_42917 = (object)DBL_PTR(_int_42917)->dbl;
        }
        _22487 = NOVALUE;

        /** c_decl.e:390			if int = s then*/
        if (_int_42917 != _s_42916)
        goto L3; // [33] 52

        /** c_decl.e:391				BB_info = remove( BB_info, int )*/
        {
            s1_ptr assign_space = SEQ_PTR(_58BB_info_42559);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_int_42917)) ? _int_42917 : (object)(DBL_PTR(_int_42917)->dbl);
            int stop = (IS_ATOM_INT(_int_42917)) ? _int_42917 : (object)(DBL_PTR(_int_42917)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_58BB_info_42559), start, &_58BB_info_42559 );
                }
                else Tail(SEQ_PTR(_58BB_info_42559), stop+1, &_58BB_info_42559);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_58BB_info_42559), start, &_58BB_info_42559);
            }
            else {
                assign_slice_seq = &assign_space;
                _58BB_info_42559 = Remove_elements(start, stop, (SEQ_PTR(_58BB_info_42559)->ref == 1));
            }
        }

        /** c_decl.e:392				return*/
        return;
L3: 

        /** c_decl.e:394		end for*/
        _i_42919 = _i_42919 + 1LL;
        goto L1; // [54] 17
L2: 
        ;
    }

    /** c_decl.e:395	end procedure*/
    return;
    ;
}


void _58SetBBType(object _s_42937, object _t_42938, object _val_42939, object _etype_42940, object _has_delete_42941)
{
    object _found_42942 = NOVALUE;
    object _i_42943 = NOVALUE;
    object _tn_42944 = NOVALUE;
    object _int_42945 = NOVALUE;
    object _sym_42946 = NOVALUE;
    object _mode_42951 = NOVALUE;
    object _gtype_42966 = NOVALUE;
    object _new_type_43003 = NOVALUE;
    object _bbsym_43026 = NOVALUE;
    object _bbi_43162 = NOVALUE;
    object _22606 = NOVALUE;
    object _22605 = NOVALUE;
    object _22604 = NOVALUE;
    object _22602 = NOVALUE;
    object _22601 = NOVALUE;
    object _22600 = NOVALUE;
    object _22598 = NOVALUE;
    object _22597 = NOVALUE;
    object _22595 = NOVALUE;
    object _22593 = NOVALUE;
    object _22592 = NOVALUE;
    object _22590 = NOVALUE;
    object _22588 = NOVALUE;
    object _22587 = NOVALUE;
    object _22586 = NOVALUE;
    object _22585 = NOVALUE;
    object _22584 = NOVALUE;
    object _22583 = NOVALUE;
    object _22582 = NOVALUE;
    object _22581 = NOVALUE;
    object _22580 = NOVALUE;
    object _22577 = NOVALUE;
    object _22573 = NOVALUE;
    object _22568 = NOVALUE;
    object _22566 = NOVALUE;
    object _22565 = NOVALUE;
    object _22564 = NOVALUE;
    object _22562 = NOVALUE;
    object _22560 = NOVALUE;
    object _22559 = NOVALUE;
    object _22558 = NOVALUE;
    object _22556 = NOVALUE;
    object _22555 = NOVALUE;
    object _22553 = NOVALUE;
    object _22552 = NOVALUE;
    object _22551 = NOVALUE;
    object _22549 = NOVALUE;
    object _22548 = NOVALUE;
    object _22545 = NOVALUE;
    object _22544 = NOVALUE;
    object _22543 = NOVALUE;
    object _22541 = NOVALUE;
    object _22539 = NOVALUE;
    object _22538 = NOVALUE;
    object _22536 = NOVALUE;
    object _22535 = NOVALUE;
    object _22534 = NOVALUE;
    object _22532 = NOVALUE;
    object _22531 = NOVALUE;
    object _22520 = NOVALUE;
    object _22518 = NOVALUE;
    object _22515 = NOVALUE;
    object _22514 = NOVALUE;
    object _22511 = NOVALUE;
    object _22510 = NOVALUE;
    object _22509 = NOVALUE;
    object _22507 = NOVALUE;
    object _22506 = NOVALUE;
    object _22505 = NOVALUE;
    object _22503 = NOVALUE;
    object _22502 = NOVALUE;
    object _22500 = NOVALUE;
    object _22497 = NOVALUE;
    object _22495 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_42937)) {
        _1 = (object)(DBL_PTR(_s_42937)->dbl);
        DeRefDS(_s_42937);
        _s_42937 = _1;
    }
    if (!IS_ATOM_INT(_t_42938)) {
        _1 = (object)(DBL_PTR(_t_42938)->dbl);
        DeRefDS(_t_42938);
        _t_42938 = _1;
    }
    if (!IS_ATOM_INT(_etype_42940)) {
        _1 = (object)(DBL_PTR(_etype_42940)->dbl);
        DeRefDS(_etype_42940);
        _etype_42940 = _1;
    }
    if (!IS_ATOM_INT(_has_delete_42941)) {
        _1 = (object)(DBL_PTR(_has_delete_42941)->dbl);
        DeRefDS(_has_delete_42941);
        _has_delete_42941 = _1;
    }

    /** c_decl.e:416		if has_delete then*/
    if (_has_delete_42941 == 0)
    {
        goto L1; // [13] 27
    }
    else{
    }

    /** c_decl.e:417			p_has_delete = 1*/
    _58p_has_delete_42756 = 1LL;

    /** c_decl.e:418			g_has_delete = 1*/
    _58g_has_delete_42755 = 1LL;
L1: 

    /** c_decl.e:421		sym = SymTab[s]*/
    DeRef(_sym_42946);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _sym_42946 = (object)*(((s1_ptr)_2)->base + _s_42937);
    Ref(_sym_42946);

    /** c_decl.e:422		SymTab[s] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _s_42937);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** c_decl.e:424		integer mode = sym[S_MODE]*/
    _2 = (object)SEQ_PTR(_sym_42946);
    _mode_42951 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_mode_42951))
    _mode_42951 = (object)DBL_PTR(_mode_42951)->dbl;

    /** c_decl.e:425		if mode = M_NORMAL or mode = M_TEMP  then*/
    _22495 = (_mode_42951 == 1LL);
    if (_22495 != 0) {
        goto L2; // [61] 76
    }
    _22497 = (_mode_42951 == 3LL);
    if (_22497 == 0)
    {
        DeRef(_22497);
        _22497 = NOVALUE;
        goto L3; // [72] 1167
    }
    else{
        DeRef(_22497);
        _22497 = NOVALUE;
    }
L2: 

    /** c_decl.e:427			found = FALSE*/
    _found_42942 = _13FALSE_450;

    /** c_decl.e:428			if mode = M_TEMP then*/
    if (_mode_42951 != 3LL)
    goto L4; // [89] 465

    /** c_decl.e:429				sym[S_GTYPE] = t*/
    _2 = (object)SEQ_PTR(_sym_42946);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42946 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _t_42938;
    DeRef(_1);

    /** c_decl.e:430				sym[S_SEQ_ELEM] = etype*/
    _2 = (object)SEQ_PTR(_sym_42946);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42946 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _etype_42940;
    DeRef(_1);

    /** c_decl.e:431				integer gtype = sym[S_GTYPE]*/
    _2 = (object)SEQ_PTR(_sym_42946);
    _gtype_42966 = (object)*(((s1_ptr)_2)->base + 36LL);
    if (!IS_ATOM_INT(_gtype_42966))
    _gtype_42966 = (object)DBL_PTR(_gtype_42966)->dbl;

    /** c_decl.e:432				if gtype = TYPE_OBJECT*/
    _22500 = (_gtype_42966 == 16LL);
    if (_22500 != 0) {
        goto L5; // [125] 140
    }
    _22502 = (_gtype_42966 == 8LL);
    if (_22502 == 0)
    {
        DeRef(_22502);
        _22502 = NOVALUE;
        goto L6; // [136] 213
    }
    else{
        DeRef(_22502);
        _22502 = NOVALUE;
    }
L5: 

    /** c_decl.e:435					if val[MIN] < 0 then*/
    _2 = (object)SEQ_PTR(_val_42939);
    _22503 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(GREATEREQ, _22503, 0LL)){
        _22503 = NOVALUE;
        goto L7; // [148] 165
    }
    _22503 = NOVALUE;

    /** c_decl.e:436						sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21293);
    _2 = (object)SEQ_PTR(_sym_42946);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42946 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21293;
    DeRef(_1);
    goto L8; // [162] 180
L7: 

    /** c_decl.e:438						sym[S_SEQ_LEN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_42939);
    _22505 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_22505);
    _2 = (object)SEQ_PTR(_sym_42946);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42946 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22505;
    if( _1 != _22505 ){
        DeRef(_1);
    }
    _22505 = NOVALUE;
L8: 

    /** c_decl.e:440					sym[S_OBJ] = NOVALUE*/
    Ref(_36NOVALUE_21293);
    _2 = (object)SEQ_PTR(_sym_42946);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42946 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21293;
    DeRef(_1);

    /** c_decl.e:442					sym[S_OBJ_MIN] = NOVALUE*/
    Ref(_36NOVALUE_21293);
    _2 = (object)SEQ_PTR(_sym_42946);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42946 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21293;
    DeRef(_1);

    /** c_decl.e:443					sym[S_OBJ_MAX] = NOVALUE*/
    Ref(_36NOVALUE_21293);
    _2 = (object)SEQ_PTR(_sym_42946);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42946 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21293;
    DeRef(_1);
    goto L9; // [210] 252
L6: 

    /** c_decl.e:445					sym[S_OBJ_MIN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_42939);
    _22506 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_22506);
    _2 = (object)SEQ_PTR(_sym_42946);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42946 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22506;
    if( _1 != _22506 ){
        DeRef(_1);
    }
    _22506 = NOVALUE;

    /** c_decl.e:446					sym[S_OBJ_MAX] = val[MAX]*/
    _2 = (object)SEQ_PTR(_val_42939);
    _22507 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_22507);
    _2 = (object)SEQ_PTR(_sym_42946);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42946 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22507;
    if( _1 != _22507 ){
        DeRef(_1);
    }
    _22507 = NOVALUE;

    /** c_decl.e:447					sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21293);
    _2 = (object)SEQ_PTR(_sym_42946);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42946 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21293;
    DeRef(_1);
L9: 

    /** c_decl.e:449				if not Initializing then*/
    if (_36Initializing_21523 != 0)
    goto LA; // [256] 326

    /** c_decl.e:450					integer new_type = or_type(temp_name_type[sym[S_TEMP_NAME]][T_GTYPE_NEW], t)*/
    _2 = (object)SEQ_PTR(_sym_42946);
    _22509 = (object)*(((s1_ptr)_2)->base + 34LL);
    _2 = (object)SEQ_PTR(_36temp_name_type_21525);
    if (!IS_ATOM_INT(_22509)){
        _22510 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_22509)->dbl));
    }
    else{
        _22510 = (object)*(((s1_ptr)_2)->base + _22509);
    }
    _2 = (object)SEQ_PTR(_22510);
    _22511 = (object)*(((s1_ptr)_2)->base + 2LL);
    _22510 = NOVALUE;
    Ref(_22511);
    _new_type_43003 = _58or_type(_22511, _t_42938);
    _22511 = NOVALUE;
    if (!IS_ATOM_INT(_new_type_43003)) {
        _1 = (object)(DBL_PTR(_new_type_43003)->dbl);
        DeRefDS(_new_type_43003);
        _new_type_43003 = _1;
    }

    /** c_decl.e:451					if new_type = TYPE_NULL then*/
    if (_new_type_43003 != 0LL)
    goto LB; // [290] 304

    /** c_decl.e:452						new_type = TYPE_OBJECT*/
    _new_type_43003 = 16LL;
LB: 

    /** c_decl.e:454					temp_name_type[sym[S_TEMP_NAME]][T_GTYPE_NEW] = new_type*/
    _2 = (object)SEQ_PTR(_sym_42946);
    _22514 = (object)*(((s1_ptr)_2)->base + 34LL);
    _2 = (object)SEQ_PTR(_36temp_name_type_21525);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36temp_name_type_21525 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_22514))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_22514)->dbl));
    else
    _3 = (object)(_22514 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _new_type_43003;
    DeRef(_1);
    _22515 = NOVALUE;
LA: 

    /** c_decl.e:458				tn = sym[S_TEMP_NAME]*/
    _2 = (object)SEQ_PTR(_sym_42946);
    _tn_42944 = (object)*(((s1_ptr)_2)->base + 34LL);
    if (!IS_ATOM_INT(_tn_42944))
    _tn_42944 = (object)DBL_PTR(_tn_42944)->dbl;

    /** c_decl.e:459				i = 1*/
    _i_42943 = 1LL;

    /** c_decl.e:460				while i <= length(BB_info) do*/
LC: 
    if (IS_SEQUENCE(_58BB_info_42559)){
            _22518 = SEQ_PTR(_58BB_info_42559)->length;
    }
    else {
        _22518 = 1;
    }
    if (_i_42943 > _22518)
    goto LD; // [351] 460

    /** c_decl.e:461					sequence bbsym*/

    /** c_decl.e:462					int = BB_info[i][BB_VAR]*/
    _2 = (object)SEQ_PTR(_58BB_info_42559);
    _22520 = (object)*(((s1_ptr)_2)->base + _i_42943);
    _2 = (object)SEQ_PTR(_22520);
    _int_42945 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_int_42945)){
        _int_42945 = (object)DBL_PTR(_int_42945)->dbl;
    }
    _22520 = NOVALUE;

    /** c_decl.e:463					if int = s then*/
    if (_int_42945 != _s_42937)
    goto LE; // [373] 387

    /** c_decl.e:464						bbsym = sym*/
    RefDS(_sym_42946);
    DeRef(_bbsym_43026);
    _bbsym_43026 = _sym_42946;
    goto LF; // [384] 398
LE: 

    /** c_decl.e:466						bbsym = SymTab[int]*/
    DeRef(_bbsym_43026);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _bbsym_43026 = (object)*(((s1_ptr)_2)->base + _int_42945);
    Ref(_bbsym_43026);
LF: 

    /** c_decl.e:468					int = bbsym[S_MODE]*/
    _2 = (object)SEQ_PTR(_bbsym_43026);
    _int_42945 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_int_42945))
    _int_42945 = (object)DBL_PTR(_int_42945)->dbl;

    /** c_decl.e:469					if int = M_TEMP then*/
    if (_int_42945 != 3LL)
    goto L10; // [412] 447

    /** c_decl.e:470						int = bbsym[S_TEMP_NAME]*/
    _2 = (object)SEQ_PTR(_bbsym_43026);
    _int_42945 = (object)*(((s1_ptr)_2)->base + 34LL);
    if (!IS_ATOM_INT(_int_42945))
    _int_42945 = (object)DBL_PTR(_int_42945)->dbl;

    /** c_decl.e:471						if int = tn then*/
    if (_int_42945 != _tn_42944)
    goto L11; // [426] 446

    /** c_decl.e:472							found = TRUE*/
    _found_42942 = _13TRUE_452;

    /** c_decl.e:473							exit*/
    DeRefDS(_bbsym_43026);
    _bbsym_43026 = NOVALUE;
    goto LD; // [443] 460
L11: 
L10: 

    /** c_decl.e:476					i += 1*/
    _i_42943 = _i_42943 + 1;
    DeRef(_bbsym_43026);
    _bbsym_43026 = NOVALUE;

    /** c_decl.e:477				end while*/
    goto LC; // [457] 346
LD: 
    goto L12; // [462] 889
L4: 

    /** c_decl.e:479				if t != TYPE_NULL then*/
    if (_t_42938 == 0LL)
    goto L13; // [469] 824

    /** c_decl.e:480					if not Initializing then*/
    if (_36Initializing_21523 != 0)
    goto L14; // [477] 500

    /** c_decl.e:481						sym[S_GTYPE_NEW] = or_type(sym[S_GTYPE_NEW], t)*/
    _2 = (object)SEQ_PTR(_sym_42946);
    _22531 = (object)*(((s1_ptr)_2)->base + 38LL);
    Ref(_22531);
    _22532 = _58or_type(_22531, _t_42938);
    _22531 = NOVALUE;
    _2 = (object)SEQ_PTR(_sym_42946);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42946 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 38LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22532;
    if( _1 != _22532 ){
        DeRef(_1);
    }
    _22532 = NOVALUE;
L14: 

    /** c_decl.e:484					if t = TYPE_SEQUENCE then*/
    if (_t_42938 != 8LL)
    goto L15; // [504] 633

    /** c_decl.e:485						sym[S_SEQ_ELEM_NEW] =*/
    _2 = (object)SEQ_PTR(_sym_42946);
    _22534 = (object)*(((s1_ptr)_2)->base + 40LL);
    Ref(_22534);
    _22535 = _58or_type(_22534, _etype_42940);
    _22534 = NOVALUE;
    _2 = (object)SEQ_PTR(_sym_42946);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42946 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22535;
    if( _1 != _22535 ){
        DeRef(_1);
    }
    _22535 = NOVALUE;

    /** c_decl.e:488						if val[MIN] != -1 then*/
    _2 = (object)SEQ_PTR(_val_42939);
    _22536 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _22536, -1LL)){
        _22536 = NOVALUE;
        goto L16; // [535] 823
    }
    _22536 = NOVALUE;

    /** c_decl.e:489							if sym[S_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_42946);
    _22538 = (object)*(((s1_ptr)_2)->base + 39LL);
    if (IS_ATOM_INT(_36NOVALUE_21293)) {
        if ((uintptr_t)_36NOVALUE_21293 == (uintptr_t)HIGH_BITS){
            _22539 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22539 = - _36NOVALUE_21293;
        }
    }
    else {
        _22539 = unary_op(UMINUS, _36NOVALUE_21293);
    }
    if (binary_op_a(NOTEQ, _22538, _22539)){
        _22538 = NOVALUE;
        DeRef(_22539);
        _22539 = NOVALUE;
        goto L17; // [552] 599
    }
    _22538 = NOVALUE;
    DeRef(_22539);
    _22539 = NOVALUE;

    /** c_decl.e:490								if val[MIN] < 0 then*/
    _2 = (object)SEQ_PTR(_val_42939);
    _22541 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(GREATEREQ, _22541, 0LL)){
        _22541 = NOVALUE;
        goto L18; // [564] 581
    }
    _22541 = NOVALUE;

    /** c_decl.e:491									sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_36NOVALUE_21293);
    _2 = (object)SEQ_PTR(_sym_42946);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42946 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21293;
    DeRef(_1);
    goto L16; // [578] 823
L18: 

    /** c_decl.e:493									sym[S_SEQ_LEN_NEW] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_42939);
    _22543 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_22543);
    _2 = (object)SEQ_PTR(_sym_42946);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42946 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22543;
    if( _1 != _22543 ){
        DeRef(_1);
    }
    _22543 = NOVALUE;
    goto L16; // [596] 823
L17: 

    /** c_decl.e:495							elsif val[MIN] != sym[S_SEQ_LEN_NEW] then*/
    _2 = (object)SEQ_PTR(_val_42939);
    _22544 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_sym_42946);
    _22545 = (object)*(((s1_ptr)_2)->base + 39LL);
    if (binary_op_a(EQUALS, _22544, _22545)){
        _22544 = NOVALUE;
        _22545 = NOVALUE;
        goto L16; // [613] 823
    }
    _22544 = NOVALUE;
    _22545 = NOVALUE;

    /** c_decl.e:496								sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_36NOVALUE_21293);
    _2 = (object)SEQ_PTR(_sym_42946);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42946 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21293;
    DeRef(_1);
    goto L16; // [630] 823
L15: 

    /** c_decl.e:500					elsif t = TYPE_INTEGER then*/
    if (_t_42938 != 1LL)
    goto L19; // [637] 774

    /** c_decl.e:502						if sym[S_OBJ_MIN_NEW] = -NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_42946);
    _22548 = (object)*(((s1_ptr)_2)->base + 41LL);
    if (IS_ATOM_INT(_36NOVALUE_21293)) {
        if ((uintptr_t)_36NOVALUE_21293 == (uintptr_t)HIGH_BITS){
            _22549 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22549 = - _36NOVALUE_21293;
        }
    }
    else {
        _22549 = unary_op(UMINUS, _36NOVALUE_21293);
    }
    if (binary_op_a(NOTEQ, _22548, _22549)){
        _22548 = NOVALUE;
        DeRef(_22549);
        _22549 = NOVALUE;
        goto L1A; // [654] 689
    }
    _22548 = NOVALUE;
    DeRef(_22549);
    _22549 = NOVALUE;

    /** c_decl.e:504							sym[S_OBJ_MIN_NEW] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_42939);
    _22551 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_22551);
    _2 = (object)SEQ_PTR(_sym_42946);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42946 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22551;
    if( _1 != _22551 ){
        DeRef(_1);
    }
    _22551 = NOVALUE;

    /** c_decl.e:505							sym[S_OBJ_MAX_NEW] = val[MAX]*/
    _2 = (object)SEQ_PTR(_val_42939);
    _22552 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_22552);
    _2 = (object)SEQ_PTR(_sym_42946);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42946 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 42LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22552;
    if( _1 != _22552 ){
        DeRef(_1);
    }
    _22552 = NOVALUE;
    goto L16; // [686] 823
L1A: 

    /** c_decl.e:507						elsif sym[S_OBJ_MIN_NEW] != NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_42946);
    _22553 = (object)*(((s1_ptr)_2)->base + 41LL);
    if (binary_op_a(EQUALS, _22553, _36NOVALUE_21293)){
        _22553 = NOVALUE;
        goto L16; // [699] 823
    }
    _22553 = NOVALUE;

    /** c_decl.e:509							if val[MIN] < sym[S_OBJ_MIN_NEW] then*/
    _2 = (object)SEQ_PTR(_val_42939);
    _22555 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_sym_42946);
    _22556 = (object)*(((s1_ptr)_2)->base + 41LL);
    if (binary_op_a(GREATEREQ, _22555, _22556)){
        _22555 = NOVALUE;
        _22556 = NOVALUE;
        goto L1B; // [717] 736
    }
    _22555 = NOVALUE;
    _22556 = NOVALUE;

    /** c_decl.e:510								sym[S_OBJ_MIN_NEW] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_42939);
    _22558 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_22558);
    _2 = (object)SEQ_PTR(_sym_42946);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42946 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22558;
    if( _1 != _22558 ){
        DeRef(_1);
    }
    _22558 = NOVALUE;
L1B: 

    /** c_decl.e:512							if val[MAX] > sym[S_OBJ_MAX_NEW] then*/
    _2 = (object)SEQ_PTR(_val_42939);
    _22559 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_sym_42946);
    _22560 = (object)*(((s1_ptr)_2)->base + 42LL);
    if (binary_op_a(LESSEQ, _22559, _22560)){
        _22559 = NOVALUE;
        _22560 = NOVALUE;
        goto L16; // [750] 823
    }
    _22559 = NOVALUE;
    _22560 = NOVALUE;

    /** c_decl.e:513								sym[S_OBJ_MAX_NEW] = val[MAX]*/
    _2 = (object)SEQ_PTR(_val_42939);
    _22562 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_22562);
    _2 = (object)SEQ_PTR(_sym_42946);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42946 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 42LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22562;
    if( _1 != _22562 ){
        DeRef(_1);
    }
    _22562 = NOVALUE;
    goto L16; // [771] 823
L19: 

    /** c_decl.e:518						sym[S_OBJ_MIN_NEW] = NOVALUE*/
    Ref(_36NOVALUE_21293);
    _2 = (object)SEQ_PTR(_sym_42946);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42946 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21293;
    DeRef(_1);

    /** c_decl.e:519						if t = TYPE_OBJECT then*/
    if (_t_42938 != 16LL)
    goto L1C; // [788] 822

    /** c_decl.e:522							sym[S_SEQ_ELEM_NEW] =*/
    _2 = (object)SEQ_PTR(_sym_42946);
    _22564 = (object)*(((s1_ptr)_2)->base + 40LL);
    Ref(_22564);
    _22565 = _58or_type(_22564, _etype_42940);
    _22564 = NOVALUE;
    _2 = (object)SEQ_PTR(_sym_42946);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42946 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22565;
    if( _1 != _22565 ){
        DeRef(_1);
    }
    _22565 = NOVALUE;

    /** c_decl.e:524							sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_36NOVALUE_21293);
    _2 = (object)SEQ_PTR(_sym_42946);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42946 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21293;
    DeRef(_1);
L1C: 
L16: 
L13: 

    /** c_decl.e:529				i = 1*/
    _i_42943 = 1LL;

    /** c_decl.e:530				while i <= length(BB_info) do*/
L1D: 
    if (IS_SEQUENCE(_58BB_info_42559)){
            _22566 = SEQ_PTR(_58BB_info_42559)->length;
    }
    else {
        _22566 = 1;
    }
    if (_i_42943 > _22566)
    goto L1E; // [839] 888

    /** c_decl.e:531					int = BB_info[i][BB_VAR]*/
    _2 = (object)SEQ_PTR(_58BB_info_42559);
    _22568 = (object)*(((s1_ptr)_2)->base + _i_42943);
    _2 = (object)SEQ_PTR(_22568);
    _int_42945 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_int_42945)){
        _int_42945 = (object)DBL_PTR(_int_42945)->dbl;
    }
    _22568 = NOVALUE;

    /** c_decl.e:532					if int = s then*/
    if (_int_42945 != _s_42937)
    goto L1F; // [859] 877

    /** c_decl.e:533						found = TRUE*/
    _found_42942 = _13TRUE_452;

    /** c_decl.e:534						exit*/
    goto L1E; // [874] 888
L1F: 

    /** c_decl.e:536					i += 1*/
    _i_42943 = _i_42943 + 1;

    /** c_decl.e:537				end while*/
    goto L1D; // [885] 834
L1E: 
L12: 

    /** c_decl.e:541			if not found then*/
    if (_found_42942 != 0)
    goto L20; // [891] 907

    /** c_decl.e:543				BB_info = append(BB_info, repeat(0, 6))*/
    _22573 = Repeat(0LL, 6LL);
    RefDS(_22573);
    Append(&_58BB_info_42559, _58BB_info_42559, _22573);
    DeRefDS(_22573);
    _22573 = NOVALUE;
L20: 

    /** c_decl.e:546			if t = TYPE_NULL then*/
    if (_t_42938 != 0LL)
    goto L21; // [911] 949

    /** c_decl.e:547				if not found then*/
    if (_found_42942 != 0)
    goto L22; // [917] 1308

    /** c_decl.e:549					BB_info[i] = dummy_bb*/
    RefDS(_58dummy_bb_42926);
    _2 = (object)SEQ_PTR(_58BB_info_42559);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _58BB_info_42559 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _i_42943);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _58dummy_bb_42926;
    DeRef(_1);

    /** c_decl.e:550					BB_info[i][BB_VAR] = s*/
    _2 = (object)SEQ_PTR(_58BB_info_42559);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _58BB_info_42559 = MAKE_SEQ(_2);
    }
    _3 = (object)(_i_42943 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_42937;
    DeRef(_1);
    _22577 = NOVALUE;
    goto L22; // [946] 1308
L21: 

    /** c_decl.e:554				sequence bbi = BB_info[i]*/
    DeRef(_bbi_43162);
    _2 = (object)SEQ_PTR(_58BB_info_42559);
    _bbi_43162 = (object)*(((s1_ptr)_2)->base + _i_42943);
    Ref(_bbi_43162);

    /** c_decl.e:555				BB_info[i] = 0*/
    _2 = (object)SEQ_PTR(_58BB_info_42559);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _58BB_info_42559 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _i_42943);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** c_decl.e:556				bbi[BB_VAR] = s*/
    _2 = (object)SEQ_PTR(_bbi_43162);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43162 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_42937;
    DeRef(_1);

    /** c_decl.e:557				bbi[BB_TYPE] = t*/
    _2 = (object)SEQ_PTR(_bbi_43162);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43162 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _t_42938;
    DeRef(_1);

    /** c_decl.e:558				bbi[BB_DELETE] = has_delete*/
    _2 = (object)SEQ_PTR(_bbi_43162);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43162 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _has_delete_42941;
    DeRef(_1);

    /** c_decl.e:560				if t = TYPE_SEQUENCE and val[MIN] = -1 then*/
    _22580 = (_t_42938 == 8LL);
    if (_22580 == 0) {
        goto L23; // [995] 1077
    }
    _2 = (object)SEQ_PTR(_val_42939);
    _22582 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_22582)) {
        _22583 = (_22582 == -1LL);
    }
    else {
        _22583 = binary_op(EQUALS, _22582, -1LL);
    }
    _22582 = NOVALUE;
    if (_22583 == 0) {
        DeRef(_22583);
        _22583 = NOVALUE;
        goto L23; // [1010] 1077
    }
    else {
        if (!IS_ATOM_INT(_22583) && DBL_PTR(_22583)->dbl == 0.0){
            DeRef(_22583);
            _22583 = NOVALUE;
            goto L23; // [1010] 1077
        }
        DeRef(_22583);
        _22583 = NOVALUE;
    }
    DeRef(_22583);
    _22583 = NOVALUE;

    /** c_decl.e:562					if found and bbi[BB_ELEM] != TYPE_NULL then*/
    if (_found_42942 == 0) {
        goto L24; // [1015] 1051
    }
    _2 = (object)SEQ_PTR(_bbi_43162);
    _22585 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (IS_ATOM_INT(_22585)) {
        _22586 = (_22585 != 0LL);
    }
    else {
        _22586 = binary_op(NOTEQ, _22585, 0LL);
    }
    _22585 = NOVALUE;
    if (_22586 == 0) {
        DeRef(_22586);
        _22586 = NOVALUE;
        goto L24; // [1030] 1051
    }
    else {
        if (!IS_ATOM_INT(_22586) && DBL_PTR(_22586)->dbl == 0.0){
            DeRef(_22586);
            _22586 = NOVALUE;
            goto L24; // [1030] 1051
        }
        DeRef(_22586);
        _22586 = NOVALUE;
    }
    DeRef(_22586);
    _22586 = NOVALUE;

    /** c_decl.e:564						bbi[BB_ELEM] = or_type(bbi[BB_ELEM], etype)*/
    _2 = (object)SEQ_PTR(_bbi_43162);
    _22587 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_22587);
    _22588 = _58or_type(_22587, _etype_42940);
    _22587 = NOVALUE;
    _2 = (object)SEQ_PTR(_bbi_43162);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43162 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22588;
    if( _1 != _22588 ){
        DeRef(_1);
    }
    _22588 = NOVALUE;
    goto L25; // [1048] 1060
L24: 

    /** c_decl.e:566						bbi[BB_ELEM] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_bbi_43162);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43162 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
L25: 

    /** c_decl.e:568					if not found then*/
    if (_found_42942 != 0)
    goto L26; // [1062] 1153

    /** c_decl.e:569						bbi[BB_SEQLEN] = NOVALUE*/
    Ref(_36NOVALUE_21293);
    _2 = (object)SEQ_PTR(_bbi_43162);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43162 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21293;
    DeRef(_1);
    goto L26; // [1074] 1153
L23: 

    /** c_decl.e:572					bbi[BB_ELEM] = etype*/
    _2 = (object)SEQ_PTR(_bbi_43162);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43162 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _etype_42940;
    DeRef(_1);

    /** c_decl.e:573					if t = TYPE_SEQUENCE or t = TYPE_OBJECT then*/
    _22590 = (_t_42938 == 8LL);
    if (_22590 != 0) {
        goto L27; // [1091] 1106
    }
    _22592 = (_t_42938 == 16LL);
    if (_22592 == 0)
    {
        DeRef(_22592);
        _22592 = NOVALUE;
        goto L28; // [1102] 1145
    }
    else{
        DeRef(_22592);
        _22592 = NOVALUE;
    }
L27: 

    /** c_decl.e:574						if val[MIN] < 0 then*/
    _2 = (object)SEQ_PTR(_val_42939);
    _22593 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(GREATEREQ, _22593, 0LL)){
        _22593 = NOVALUE;
        goto L29; // [1114] 1129
    }
    _22593 = NOVALUE;

    /** c_decl.e:575							bbi[BB_SEQLEN] = NOVALUE*/
    Ref(_36NOVALUE_21293);
    _2 = (object)SEQ_PTR(_bbi_43162);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43162 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21293;
    DeRef(_1);
    goto L2A; // [1126] 1152
L29: 

    /** c_decl.e:577							bbi[BB_SEQLEN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_42939);
    _22595 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_22595);
    _2 = (object)SEQ_PTR(_bbi_43162);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43162 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22595;
    if( _1 != _22595 ){
        DeRef(_1);
    }
    _22595 = NOVALUE;
    goto L2A; // [1142] 1152
L28: 

    /** c_decl.e:580						bbi[BB_OBJ] = val*/
    RefDS(_val_42939);
    _2 = (object)SEQ_PTR(_bbi_43162);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43162 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _val_42939;
    DeRef(_1);
L2A: 
L26: 

    /** c_decl.e:583				BB_info[i] = bbi*/
    RefDS(_bbi_43162);
    _2 = (object)SEQ_PTR(_58BB_info_42559);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _58BB_info_42559 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _i_42943);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _bbi_43162;
    DeRef(_1);
    DeRefDS(_bbi_43162);
    _bbi_43162 = NOVALUE;
    goto L22; // [1164] 1308
L3: 

    /** c_decl.e:586		elsif mode = M_CONSTANT then*/
    if (_mode_42951 != 2LL)
    goto L2B; // [1171] 1307

    /** c_decl.e:587			sym[S_GTYPE] = t*/
    _2 = (object)SEQ_PTR(_sym_42946);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42946 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _t_42938;
    DeRef(_1);

    /** c_decl.e:588			sym[S_SEQ_ELEM] = etype*/
    _2 = (object)SEQ_PTR(_sym_42946);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42946 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _etype_42940;
    DeRef(_1);

    /** c_decl.e:589			if sym[S_GTYPE] = TYPE_SEQUENCE or*/
    _2 = (object)SEQ_PTR(_sym_42946);
    _22597 = (object)*(((s1_ptr)_2)->base + 36LL);
    if (IS_ATOM_INT(_22597)) {
        _22598 = (_22597 == 8LL);
    }
    else {
        _22598 = binary_op(EQUALS, _22597, 8LL);
    }
    _22597 = NOVALUE;
    if (IS_ATOM_INT(_22598)) {
        if (_22598 != 0) {
            goto L2C; // [1205] 1226
        }
    }
    else {
        if (DBL_PTR(_22598)->dbl != 0.0) {
            goto L2C; // [1205] 1226
        }
    }
    _2 = (object)SEQ_PTR(_sym_42946);
    _22600 = (object)*(((s1_ptr)_2)->base + 36LL);
    if (IS_ATOM_INT(_22600)) {
        _22601 = (_22600 == 16LL);
    }
    else {
        _22601 = binary_op(EQUALS, _22600, 16LL);
    }
    _22600 = NOVALUE;
    if (_22601 == 0) {
        DeRef(_22601);
        _22601 = NOVALUE;
        goto L2D; // [1222] 1269
    }
    else {
        if (!IS_ATOM_INT(_22601) && DBL_PTR(_22601)->dbl == 0.0){
            DeRef(_22601);
            _22601 = NOVALUE;
            goto L2D; // [1222] 1269
        }
        DeRef(_22601);
        _22601 = NOVALUE;
    }
    DeRef(_22601);
    _22601 = NOVALUE;
L2C: 

    /** c_decl.e:591				if val[MIN] < 0 then*/
    _2 = (object)SEQ_PTR(_val_42939);
    _22602 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(GREATEREQ, _22602, 0LL)){
        _22602 = NOVALUE;
        goto L2E; // [1234] 1251
    }
    _22602 = NOVALUE;

    /** c_decl.e:592					sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21293);
    _2 = (object)SEQ_PTR(_sym_42946);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42946 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21293;
    DeRef(_1);
    goto L2F; // [1248] 1298
L2E: 

    /** c_decl.e:594					sym[S_SEQ_LEN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_42939);
    _22604 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_22604);
    _2 = (object)SEQ_PTR(_sym_42946);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42946 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22604;
    if( _1 != _22604 ){
        DeRef(_1);
    }
    _22604 = NOVALUE;
    goto L2F; // [1266] 1298
L2D: 

    /** c_decl.e:597				sym[S_OBJ_MIN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_42939);
    _22605 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_22605);
    _2 = (object)SEQ_PTR(_sym_42946);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42946 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22605;
    if( _1 != _22605 ){
        DeRef(_1);
    }
    _22605 = NOVALUE;

    /** c_decl.e:598				sym[S_OBJ_MAX] = val[MAX]*/
    _2 = (object)SEQ_PTR(_val_42939);
    _22606 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_22606);
    _2 = (object)SEQ_PTR(_sym_42946);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42946 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22606;
    if( _1 != _22606 ){
        DeRef(_1);
    }
    _22606 = NOVALUE;
L2F: 

    /** c_decl.e:600			sym[S_HAS_DELETE] = has_delete*/
    _2 = (object)SEQ_PTR(_sym_42946);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_42946 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 54LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _has_delete_42941;
    DeRef(_1);
L2B: 
L22: 

    /** c_decl.e:603		SymTab[s] = sym*/
    RefDS(_sym_42946);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _s_42937);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_42946;
    DeRef(_1);

    /** c_decl.e:605	end procedure*/
    DeRefDS(_val_42939);
    DeRefDS(_sym_42946);
    DeRef(_22598);
    _22598 = NOVALUE;
    DeRef(_22590);
    _22590 = NOVALUE;
    DeRef(_22495);
    _22495 = NOVALUE;
    DeRef(_22580);
    _22580 = NOVALUE;
    DeRef(_22500);
    _22500 = NOVALUE;
    _22509 = NOVALUE;
    _22514 = NOVALUE;
    return;
    ;
}


void _58CName(object _s_43236)
{
    object _v_43237 = NOVALUE;
    object _mode_43239 = NOVALUE;
    object _22671 = NOVALUE;
    object _22670 = NOVALUE;
    object _22668 = NOVALUE;
    object _22667 = NOVALUE;
    object _22666 = NOVALUE;
    object _22665 = NOVALUE;
    object _22664 = NOVALUE;
    object _22663 = NOVALUE;
    object _22662 = NOVALUE;
    object _22661 = NOVALUE;
    object _22659 = NOVALUE;
    object _22657 = NOVALUE;
    object _22656 = NOVALUE;
    object _22655 = NOVALUE;
    object _22654 = NOVALUE;
    object _22653 = NOVALUE;
    object _22652 = NOVALUE;
    object _22650 = NOVALUE;
    object _22649 = NOVALUE;
    object _22648 = NOVALUE;
    object _22647 = NOVALUE;
    object _22646 = NOVALUE;
    object _22644 = NOVALUE;
    object _22643 = NOVALUE;
    object _22642 = NOVALUE;
    object _22641 = NOVALUE;
    object _22640 = NOVALUE;
    object _22639 = NOVALUE;
    object _22637 = NOVALUE;
    object _22636 = NOVALUE;
    object _22634 = NOVALUE;
    object _22633 = NOVALUE;
    object _22632 = NOVALUE;
    object _22631 = NOVALUE;
    object _22630 = NOVALUE;
    object _22629 = NOVALUE;
    object _22628 = NOVALUE;
    object _22627 = NOVALUE;
    object _22626 = NOVALUE;
    object _22625 = NOVALUE;
    object _22624 = NOVALUE;
    object _22623 = NOVALUE;
    object _22621 = NOVALUE;
    object _22620 = NOVALUE;
    object _22616 = NOVALUE;
    object _22615 = NOVALUE;
    object _22614 = NOVALUE;
    object _22613 = NOVALUE;
    object _22612 = NOVALUE;
    object _22611 = NOVALUE;
    object _22608 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_43236)) {
        _1 = (object)(DBL_PTR(_s_43236)->dbl);
        DeRefDS(_s_43236);
        _s_43236 = _1;
    }

    /** c_decl.e:612		v = ObjValue(s)*/
    _0 = _v_43237;
    _v_43237 = _58ObjValue(_s_43236);
    DeRef(_0);

    /** c_decl.e:613		integer mode = SymTab[s][S_MODE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22608 = (object)*(((s1_ptr)_2)->base + _s_43236);
    _2 = (object)SEQ_PTR(_22608);
    _mode_43239 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_mode_43239)){
        _mode_43239 = (object)DBL_PTR(_mode_43239)->dbl;
    }
    _22608 = NOVALUE;

    /** c_decl.e:614	 	if mode = M_NORMAL then*/
    if (_mode_43239 != 1LL)
    goto L1; // [29] 254

    /** c_decl.e:617			if LeftSym = FALSE and GType(s) = TYPE_INTEGER and v != NOVALUE then*/
    _22611 = (_58LeftSym_42560 == _13FALSE_450);
    if (_22611 == 0) {
        _22612 = 0;
        goto L2; // [43] 61
    }
    _22613 = _58GType(_s_43236);
    if (IS_ATOM_INT(_22613)) {
        _22614 = (_22613 == 1LL);
    }
    else {
        _22614 = binary_op(EQUALS, _22613, 1LL);
    }
    DeRef(_22613);
    _22613 = NOVALUE;
    if (IS_ATOM_INT(_22614))
    _22612 = (_22614 != 0);
    else
    _22612 = DBL_PTR(_22614)->dbl != 0.0;
L2: 
    if (_22612 == 0) {
        goto L3; // [61] 98
    }
    if (IS_ATOM_INT(_v_43237) && IS_ATOM_INT(_36NOVALUE_21293)) {
        _22616 = (_v_43237 != _36NOVALUE_21293);
    }
    else {
        _22616 = binary_op(NOTEQ, _v_43237, _36NOVALUE_21293);
    }
    if (_22616 == 0) {
        DeRef(_22616);
        _22616 = NOVALUE;
        goto L3; // [72] 98
    }
    else {
        if (!IS_ATOM_INT(_22616) && DBL_PTR(_22616)->dbl == 0.0){
            DeRef(_22616);
            _22616 = NOVALUE;
            goto L3; // [72] 98
        }
        DeRef(_22616);
        _22616 = NOVALUE;
    }
    DeRef(_22616);
    _22616 = NOVALUE;

    /** c_decl.e:618				c_printf("%d", v)*/
    RefDS(_22617);
    Ref(_v_43237);
    _55c_printf(_22617, _v_43237);

    /** c_decl.e:619				if TARGET_SIZEOF_POINTER = 8 then*/
    if (_36TARGET_SIZEOF_POINTER_21261 != 8LL)
    goto L4; // [85] 180

    /** c_decl.e:620					c_puts( "LL" )*/
    RefDS(_22619);
    _55c_puts(_22619);
    goto L4; // [95] 180
L3: 

    /** c_decl.e:623				if SymTab[s][S_SCOPE] > SC_PRIVATE then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22620 = (object)*(((s1_ptr)_2)->base + _s_43236);
    _2 = (object)SEQ_PTR(_22620);
    _22621 = (object)*(((s1_ptr)_2)->base + 4LL);
    _22620 = NOVALUE;
    if (binary_op_a(LESSEQ, _22621, 3LL)){
        _22621 = NOVALUE;
        goto L5; // [114] 156
    }
    _22621 = NOVALUE;

    /** c_decl.e:624					c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22623 = (object)*(((s1_ptr)_2)->base + _s_43236);
    _2 = (object)SEQ_PTR(_22623);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _22624 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _22624 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    _22623 = NOVALUE;
    RefDS(_22116);
    Ref(_22624);
    _55c_printf(_22116, _22624);
    _22624 = NOVALUE;

    /** c_decl.e:625					c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22625 = (object)*(((s1_ptr)_2)->base + _s_43236);
    _2 = (object)SEQ_PTR(_22625);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _22626 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _22626 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _22625 = NOVALUE;
    Ref(_22626);
    _55c_puts(_22626);
    _22626 = NOVALUE;
    goto L6; // [153] 179
L5: 

    /** c_decl.e:627					c_puts("_")*/
    RefDS(_22065);
    _55c_puts(_22065);

    /** c_decl.e:628					c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22627 = (object)*(((s1_ptr)_2)->base + _s_43236);
    _2 = (object)SEQ_PTR(_22627);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _22628 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _22628 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _22627 = NOVALUE;
    Ref(_22628);
    _55c_puts(_22628);
    _22628 = NOVALUE;
L6: 
L4: 

    /** c_decl.e:631			if s != CurrentSub and SymTab[s][S_NREFS] < 2 then*/
    _22629 = (_s_43236 != _36CurrentSub_21447);
    if (_22629 == 0) {
        goto L7; // [188] 236
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22631 = (object)*(((s1_ptr)_2)->base + _s_43236);
    _2 = (object)SEQ_PTR(_22631);
    _22632 = (object)*(((s1_ptr)_2)->base + 12LL);
    _22631 = NOVALUE;
    if (IS_ATOM_INT(_22632)) {
        _22633 = (_22632 < 2LL);
    }
    else {
        _22633 = binary_op(LESS, _22632, 2LL);
    }
    _22632 = NOVALUE;
    if (_22633 == 0) {
        DeRef(_22633);
        _22633 = NOVALUE;
        goto L7; // [209] 236
    }
    else {
        if (!IS_ATOM_INT(_22633) && DBL_PTR(_22633)->dbl == 0.0){
            DeRef(_22633);
            _22633 = NOVALUE;
            goto L7; // [209] 236
        }
        DeRef(_22633);
        _22633 = NOVALUE;
    }
    DeRef(_22633);
    _22633 = NOVALUE;

    /** c_decl.e:632				SymTab[s][S_NREFS] += 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_43236 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _22636 = (object)*(((s1_ptr)_2)->base + 12LL);
    _22634 = NOVALUE;
    if (IS_ATOM_INT(_22636)) {
        _22637 = _22636 + 1;
        if (_22637 > MAXINT){
            _22637 = NewDouble((eudouble)_22637);
        }
    }
    else
    _22637 = binary_op(PLUS, 1, _22636);
    _22636 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22637;
    if( _1 != _22637 ){
        DeRef(_1);
    }
    _22637 = NOVALUE;
    _22634 = NOVALUE;
L7: 

    /** c_decl.e:634			SetBBType(s, TYPE_NULL, novalue, TYPE_OBJECT, 0) -- record that this var was referenced in this BB*/
    RefDS(_55novalue_46627);
    _58SetBBType(_s_43236, 0LL, _55novalue_46627, 16LL, 0LL);
    goto L8; // [251] 533
L1: 

    /** c_decl.e:636	 	elsif mode = M_CONSTANT then*/
    if (_mode_43239 != 2LL)
    goto L9; // [258] 448

    /** c_decl.e:638			if (is_integer( sym_obj( s ) ) and SymTab[s][S_GTYPE] != TYPE_DOUBLE ) or (LeftSym = FALSE and TypeIs(s, TYPE_INTEGER) and v != NOVALUE) then*/
    _22639 = _54sym_obj(_s_43236);
    _22640 = _36is_integer(_22639);
    _22639 = NOVALUE;
    if (IS_ATOM_INT(_22640)) {
        if (_22640 == 0) {
            DeRef(_22641);
            _22641 = 0;
            goto LA; // [272] 298
        }
    }
    else {
        if (DBL_PTR(_22640)->dbl == 0.0) {
            DeRef(_22641);
            _22641 = 0;
            goto LA; // [272] 298
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22642 = (object)*(((s1_ptr)_2)->base + _s_43236);
    _2 = (object)SEQ_PTR(_22642);
    _22643 = (object)*(((s1_ptr)_2)->base + 36LL);
    _22642 = NOVALUE;
    if (IS_ATOM_INT(_22643)) {
        _22644 = (_22643 != 2LL);
    }
    else {
        _22644 = binary_op(NOTEQ, _22643, 2LL);
    }
    _22643 = NOVALUE;
    DeRef(_22641);
    if (IS_ATOM_INT(_22644))
    _22641 = (_22644 != 0);
    else
    _22641 = DBL_PTR(_22644)->dbl != 0.0;
LA: 
    if (_22641 != 0) {
        goto LB; // [298] 344
    }
    _22646 = (_58LeftSym_42560 == _13FALSE_450);
    if (_22646 == 0) {
        _22647 = 0;
        goto LC; // [310] 325
    }
    _22648 = _58TypeIs(_s_43236, 1LL);
    if (IS_ATOM_INT(_22648))
    _22647 = (_22648 != 0);
    else
    _22647 = DBL_PTR(_22648)->dbl != 0.0;
LC: 
    if (_22647 == 0) {
        DeRef(_22649);
        _22649 = 0;
        goto LD; // [325] 339
    }
    if (IS_ATOM_INT(_v_43237) && IS_ATOM_INT(_36NOVALUE_21293)) {
        _22650 = (_v_43237 != _36NOVALUE_21293);
    }
    else {
        _22650 = binary_op(NOTEQ, _v_43237, _36NOVALUE_21293);
    }
    if (IS_ATOM_INT(_22650))
    _22649 = (_22650 != 0);
    else
    _22649 = DBL_PTR(_22650)->dbl != 0.0;
LD: 
    if (_22649 == 0)
    {
        _22649 = NOVALUE;
        goto LE; // [340] 367
    }
    else{
        _22649 = NOVALUE;
    }
LB: 

    /** c_decl.e:641				c_printf("%d", v)*/
    RefDS(_22617);
    Ref(_v_43237);
    _55c_printf(_22617, _v_43237);

    /** c_decl.e:642				if TARGET_SIZEOF_POINTER = 8 then*/
    if (_36TARGET_SIZEOF_POINTER_21261 != 8LL)
    goto L8; // [354] 533

    /** c_decl.e:643					c_puts( "LL" )*/
    RefDS(_22619);
    _55c_puts(_22619);
    goto L8; // [364] 533
LE: 

    /** c_decl.e:647				c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22652 = (object)*(((s1_ptr)_2)->base + _s_43236);
    _2 = (object)SEQ_PTR(_22652);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _22653 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _22653 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    _22652 = NOVALUE;
    RefDS(_22116);
    Ref(_22653);
    _55c_printf(_22116, _22653);
    _22653 = NOVALUE;

    /** c_decl.e:648				c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22654 = (object)*(((s1_ptr)_2)->base + _s_43236);
    _2 = (object)SEQ_PTR(_22654);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _22655 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _22655 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _22654 = NOVALUE;
    Ref(_22655);
    _55c_puts(_22655);
    _22655 = NOVALUE;

    /** c_decl.e:649				if SymTab[s][S_NREFS] < 2 then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22656 = (object)*(((s1_ptr)_2)->base + _s_43236);
    _2 = (object)SEQ_PTR(_22656);
    _22657 = (object)*(((s1_ptr)_2)->base + 12LL);
    _22656 = NOVALUE;
    if (binary_op_a(GREATEREQ, _22657, 2LL)){
        _22657 = NOVALUE;
        goto L8; // [416] 533
    }
    _22657 = NOVALUE;

    /** c_decl.e:650					SymTab[s][S_NREFS] += 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_43236 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _22661 = (object)*(((s1_ptr)_2)->base + 12LL);
    _22659 = NOVALUE;
    if (IS_ATOM_INT(_22661)) {
        _22662 = _22661 + 1;
        if (_22662 > MAXINT){
            _22662 = NewDouble((eudouble)_22662);
        }
    }
    else
    _22662 = binary_op(PLUS, 1, _22661);
    _22661 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22662;
    if( _1 != _22662 ){
        DeRef(_1);
    }
    _22662 = NOVALUE;
    _22659 = NOVALUE;
    goto L8; // [445] 533
L9: 

    /** c_decl.e:656			if LeftSym = FALSE and GType(s) = TYPE_INTEGER and v != NOVALUE then*/
    _22663 = (_58LeftSym_42560 == _13FALSE_450);
    if (_22663 == 0) {
        _22664 = 0;
        goto LF; // [458] 476
    }
    _22665 = _58GType(_s_43236);
    if (IS_ATOM_INT(_22665)) {
        _22666 = (_22665 == 1LL);
    }
    else {
        _22666 = binary_op(EQUALS, _22665, 1LL);
    }
    DeRef(_22665);
    _22665 = NOVALUE;
    if (IS_ATOM_INT(_22666))
    _22664 = (_22666 != 0);
    else
    _22664 = DBL_PTR(_22666)->dbl != 0.0;
LF: 
    if (_22664 == 0) {
        goto L10; // [476] 513
    }
    if (IS_ATOM_INT(_v_43237) && IS_ATOM_INT(_36NOVALUE_21293)) {
        _22668 = (_v_43237 != _36NOVALUE_21293);
    }
    else {
        _22668 = binary_op(NOTEQ, _v_43237, _36NOVALUE_21293);
    }
    if (_22668 == 0) {
        DeRef(_22668);
        _22668 = NOVALUE;
        goto L10; // [487] 513
    }
    else {
        if (!IS_ATOM_INT(_22668) && DBL_PTR(_22668)->dbl == 0.0){
            DeRef(_22668);
            _22668 = NOVALUE;
            goto L10; // [487] 513
        }
        DeRef(_22668);
        _22668 = NOVALUE;
    }
    DeRef(_22668);
    _22668 = NOVALUE;

    /** c_decl.e:657				c_printf("%d", v)*/
    RefDS(_22617);
    Ref(_v_43237);
    _55c_printf(_22617, _v_43237);

    /** c_decl.e:658				if TARGET_SIZEOF_POINTER = 8 then*/
    if (_36TARGET_SIZEOF_POINTER_21261 != 8LL)
    goto L11; // [500] 532

    /** c_decl.e:659					c_puts( "LL" )*/
    RefDS(_22619);
    _55c_puts(_22619);
    goto L11; // [510] 532
L10: 

    /** c_decl.e:662				c_printf("_%d", SymTab[s][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22670 = (object)*(((s1_ptr)_2)->base + _s_43236);
    _2 = (object)SEQ_PTR(_22670);
    _22671 = (object)*(((s1_ptr)_2)->base + 34LL);
    _22670 = NOVALUE;
    RefDS(_22116);
    Ref(_22671);
    _55c_printf(_22116, _22671);
    _22671 = NOVALUE;
L11: 
L8: 

    /** c_decl.e:666		LeftSym = FALSE*/
    _58LeftSym_42560 = _13FALSE_450;

    /** c_decl.e:667	end procedure*/
    DeRef(_v_43237);
    DeRef(_22629);
    _22629 = NOVALUE;
    DeRef(_22611);
    _22611 = NOVALUE;
    DeRef(_22640);
    _22640 = NOVALUE;
    DeRef(_22666);
    _22666 = NOVALUE;
    DeRef(_22646);
    _22646 = NOVALUE;
    DeRef(_22650);
    _22650 = NOVALUE;
    DeRef(_22614);
    _22614 = NOVALUE;
    DeRef(_22663);
    _22663 = NOVALUE;
    DeRef(_22648);
    _22648 = NOVALUE;
    DeRef(_22644);
    _22644 = NOVALUE;
    return;
    ;
}


void _58c_stmt(object _stmt_43384, object _arg_43385, object _lhs_arg_43387)
{
    object _argcount_43388 = NOVALUE;
    object _i_43389 = NOVALUE;
    object _22726 = NOVALUE;
    object _22725 = NOVALUE;
    object _22724 = NOVALUE;
    object _22723 = NOVALUE;
    object _22722 = NOVALUE;
    object _22721 = NOVALUE;
    object _22720 = NOVALUE;
    object _22719 = NOVALUE;
    object _22718 = NOVALUE;
    object _22717 = NOVALUE;
    object _22716 = NOVALUE;
    object _22715 = NOVALUE;
    object _22714 = NOVALUE;
    object _22713 = NOVALUE;
    object _22712 = NOVALUE;
    object _22711 = NOVALUE;
    object _22710 = NOVALUE;
    object _22708 = NOVALUE;
    object _22706 = NOVALUE;
    object _22704 = NOVALUE;
    object _22703 = NOVALUE;
    object _22702 = NOVALUE;
    object _22701 = NOVALUE;
    object _22699 = NOVALUE;
    object _22698 = NOVALUE;
    object _22697 = NOVALUE;
    object _22696 = NOVALUE;
    object _22695 = NOVALUE;
    object _22694 = NOVALUE;
    object _22693 = NOVALUE;
    object _22692 = NOVALUE;
    object _22691 = NOVALUE;
    object _22690 = NOVALUE;
    object _22689 = NOVALUE;
    object _22688 = NOVALUE;
    object _22687 = NOVALUE;
    object _22686 = NOVALUE;
    object _22683 = NOVALUE;
    object _22682 = NOVALUE;
    object _22681 = NOVALUE;
    object _22680 = NOVALUE;
    object _22679 = NOVALUE;
    object _22678 = NOVALUE;
    object _22676 = NOVALUE;
    object _22674 = NOVALUE;
    object _22673 = NOVALUE;
    object _22672 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_lhs_arg_43387)) {
        _1 = (object)(DBL_PTR(_lhs_arg_43387)->dbl);
        DeRefDS(_lhs_arg_43387);
        _lhs_arg_43387 = _1;
    }

    /** c_decl.e:675		if LAST_PASS = TRUE and Initializing = FALSE then*/
    _22672 = (_58LAST_PASS_42550 == _13TRUE_452);
    if (_22672 == 0) {
        goto L1; // [15] 47
    }
    _22674 = (_36Initializing_21523 == _13FALSE_450);
    if (_22674 == 0)
    {
        DeRef(_22674);
        _22674 = NOVALUE;
        goto L1; // [28] 47
    }
    else{
        DeRef(_22674);
        _22674 = NOVALUE;
    }

    /** c_decl.e:676			cfile_size += 1*/
    _36cfile_size_21522 = _36cfile_size_21522 + 1LL;

    /** c_decl.e:677			update_checksum( stmt )*/
    RefDS(_stmt_43384);
    _56update_checksum(_stmt_43384);
L1: 

    /** c_decl.e:681		if emit_c_output then*/
    if (_55emit_c_output_46620 == 0)
    {
        goto L2; // [51] 60
    }
    else{
    }

    /** c_decl.e:682			adjust_indent_before(stmt)*/
    RefDS(_stmt_43384);
    _55adjust_indent_before(_stmt_43384);
L2: 

    /** c_decl.e:685		if atom(arg) then*/
    _22676 = IS_ATOM(_arg_43385);
    if (_22676 == 0)
    {
        _22676 = NOVALUE;
        goto L3; // [65] 75
    }
    else{
        _22676 = NOVALUE;
    }

    /** c_decl.e:686			arg = {arg}*/
    _0 = _arg_43385;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_arg_43385);
    ((intptr_t*)_2)[1] = _arg_43385;
    _arg_43385 = MAKE_SEQ(_1);
    DeRef(_0);
L3: 

    /** c_decl.e:689		argcount = 1*/
    _argcount_43388 = 1LL;

    /** c_decl.e:690		i = 1*/
    _i_43389 = 1LL;

    /** c_decl.e:691		while i <= length(stmt) and length(stmt) > 0 do*/
L4: 
    if (IS_SEQUENCE(_stmt_43384)){
            _22678 = SEQ_PTR(_stmt_43384)->length;
    }
    else {
        _22678 = 1;
    }
    _22679 = (_i_43389 <= _22678);
    _22678 = NOVALUE;
    if (_22679 == 0) {
        goto L5; // [97] 435
    }
    if (IS_SEQUENCE(_stmt_43384)){
            _22681 = SEQ_PTR(_stmt_43384)->length;
    }
    else {
        _22681 = 1;
    }
    _22682 = (_22681 > 0LL);
    _22681 = NOVALUE;
    if (_22682 == 0)
    {
        DeRef(_22682);
        _22682 = NOVALUE;
        goto L5; // [109] 435
    }
    else{
        DeRef(_22682);
        _22682 = NOVALUE;
    }

    /** c_decl.e:692			if stmt[i] = '@' then*/
    _2 = (object)SEQ_PTR(_stmt_43384);
    _22683 = (object)*(((s1_ptr)_2)->base + _i_43389);
    if (binary_op_a(NOTEQ, _22683, 64LL)){
        _22683 = NOVALUE;
        goto L6; // [118] 288
    }
    _22683 = NOVALUE;

    /** c_decl.e:694				if i = 1 then*/
    if (_i_43389 != 1LL)
    goto L7; // [124] 138

    /** c_decl.e:695					LeftSym = TRUE*/
    _58LeftSym_42560 = _13TRUE_452;
L7: 

    /** c_decl.e:698				if i < length(stmt) and stmt[i+1] > '0' and stmt[i+1] <= '9' then*/
    if (IS_SEQUENCE(_stmt_43384)){
            _22686 = SEQ_PTR(_stmt_43384)->length;
    }
    else {
        _22686 = 1;
    }
    _22687 = (_i_43389 < _22686);
    _22686 = NOVALUE;
    if (_22687 == 0) {
        _22688 = 0;
        goto L8; // [147] 167
    }
    _22689 = _i_43389 + 1;
    _2 = (object)SEQ_PTR(_stmt_43384);
    _22690 = (object)*(((s1_ptr)_2)->base + _22689);
    if (IS_ATOM_INT(_22690)) {
        _22691 = (_22690 > 48LL);
    }
    else {
        _22691 = binary_op(GREATER, _22690, 48LL);
    }
    _22690 = NOVALUE;
    if (IS_ATOM_INT(_22691))
    _22688 = (_22691 != 0);
    else
    _22688 = DBL_PTR(_22691)->dbl != 0.0;
L8: 
    if (_22688 == 0) {
        goto L9; // [167] 249
    }
    _22693 = _i_43389 + 1;
    _2 = (object)SEQ_PTR(_stmt_43384);
    _22694 = (object)*(((s1_ptr)_2)->base + _22693);
    if (IS_ATOM_INT(_22694)) {
        _22695 = (_22694 <= 57LL);
    }
    else {
        _22695 = binary_op(LESSEQ, _22694, 57LL);
    }
    _22694 = NOVALUE;
    if (_22695 == 0) {
        DeRef(_22695);
        _22695 = NOVALUE;
        goto L9; // [184] 249
    }
    else {
        if (!IS_ATOM_INT(_22695) && DBL_PTR(_22695)->dbl == 0.0){
            DeRef(_22695);
            _22695 = NOVALUE;
            goto L9; // [184] 249
        }
        DeRef(_22695);
        _22695 = NOVALUE;
    }
    DeRef(_22695);
    _22695 = NOVALUE;

    /** c_decl.e:700					if arg[stmt[i+1]-'0'] = lhs_arg then*/
    _22696 = _i_43389 + 1;
    _2 = (object)SEQ_PTR(_stmt_43384);
    _22697 = (object)*(((s1_ptr)_2)->base + _22696);
    if (IS_ATOM_INT(_22697)) {
        _22698 = _22697 - 48LL;
    }
    else {
        _22698 = binary_op(MINUS, _22697, 48LL);
    }
    _22697 = NOVALUE;
    _2 = (object)SEQ_PTR(_arg_43385);
    if (!IS_ATOM_INT(_22698)){
        _22699 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_22698)->dbl));
    }
    else{
        _22699 = (object)*(((s1_ptr)_2)->base + _22698);
    }
    if (binary_op_a(NOTEQ, _22699, _lhs_arg_43387)){
        _22699 = NOVALUE;
        goto LA; // [205] 219
    }
    _22699 = NOVALUE;

    /** c_decl.e:701						LeftSym = TRUE*/
    _58LeftSym_42560 = _13TRUE_452;
LA: 

    /** c_decl.e:703					CName(arg[stmt[i+1]-'0'])*/
    _22701 = _i_43389 + 1;
    _2 = (object)SEQ_PTR(_stmt_43384);
    _22702 = (object)*(((s1_ptr)_2)->base + _22701);
    if (IS_ATOM_INT(_22702)) {
        _22703 = _22702 - 48LL;
    }
    else {
        _22703 = binary_op(MINUS, _22702, 48LL);
    }
    _22702 = NOVALUE;
    _2 = (object)SEQ_PTR(_arg_43385);
    if (!IS_ATOM_INT(_22703)){
        _22704 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_22703)->dbl));
    }
    else{
        _22704 = (object)*(((s1_ptr)_2)->base + _22703);
    }
    Ref(_22704);
    _58CName(_22704);
    _22704 = NOVALUE;

    /** c_decl.e:704					i += 1*/
    _i_43389 = _i_43389 + 1;
    goto LB; // [246] 279
L9: 

    /** c_decl.e:708					if arg[argcount] = lhs_arg then*/
    _2 = (object)SEQ_PTR(_arg_43385);
    _22706 = (object)*(((s1_ptr)_2)->base + _argcount_43388);
    if (binary_op_a(NOTEQ, _22706, _lhs_arg_43387)){
        _22706 = NOVALUE;
        goto LC; // [255] 269
    }
    _22706 = NOVALUE;

    /** c_decl.e:709						LeftSym = TRUE*/
    _58LeftSym_42560 = _13TRUE_452;
LC: 

    /** c_decl.e:711					CName(arg[argcount])*/
    _2 = (object)SEQ_PTR(_arg_43385);
    _22708 = (object)*(((s1_ptr)_2)->base + _argcount_43388);
    Ref(_22708);
    _58CName(_22708);
    _22708 = NOVALUE;
LB: 

    /** c_decl.e:714				argcount += 1*/
    _argcount_43388 = _argcount_43388 + 1;
    goto LD; // [285] 353
L6: 

    /** c_decl.e:717				c_putc(stmt[i])*/
    _2 = (object)SEQ_PTR(_stmt_43384);
    _22710 = (object)*(((s1_ptr)_2)->base + _i_43389);
    Ref(_22710);
    _55c_putc(_22710);
    _22710 = NOVALUE;

    /** c_decl.e:718				if stmt[i] = '&' and i < length(stmt) and stmt[i+1] = '@' then*/
    _2 = (object)SEQ_PTR(_stmt_43384);
    _22711 = (object)*(((s1_ptr)_2)->base + _i_43389);
    if (IS_ATOM_INT(_22711)) {
        _22712 = (_22711 == 38LL);
    }
    else {
        _22712 = binary_op(EQUALS, _22711, 38LL);
    }
    _22711 = NOVALUE;
    if (IS_ATOM_INT(_22712)) {
        if (_22712 == 0) {
            DeRef(_22713);
            _22713 = 0;
            goto LE; // [307] 322
        }
    }
    else {
        if (DBL_PTR(_22712)->dbl == 0.0) {
            DeRef(_22713);
            _22713 = 0;
            goto LE; // [307] 322
        }
    }
    if (IS_SEQUENCE(_stmt_43384)){
            _22714 = SEQ_PTR(_stmt_43384)->length;
    }
    else {
        _22714 = 1;
    }
    _22715 = (_i_43389 < _22714);
    _22714 = NOVALUE;
    DeRef(_22713);
    _22713 = (_22715 != 0);
LE: 
    if (_22713 == 0) {
        goto LF; // [322] 352
    }
    _22717 = _i_43389 + 1;
    _2 = (object)SEQ_PTR(_stmt_43384);
    _22718 = (object)*(((s1_ptr)_2)->base + _22717);
    if (IS_ATOM_INT(_22718)) {
        _22719 = (_22718 == 64LL);
    }
    else {
        _22719 = binary_op(EQUALS, _22718, 64LL);
    }
    _22718 = NOVALUE;
    if (_22719 == 0) {
        DeRef(_22719);
        _22719 = NOVALUE;
        goto LF; // [339] 352
    }
    else {
        if (!IS_ATOM_INT(_22719) && DBL_PTR(_22719)->dbl == 0.0){
            DeRef(_22719);
            _22719 = NOVALUE;
            goto LF; // [339] 352
        }
        DeRef(_22719);
        _22719 = NOVALUE;
    }
    DeRef(_22719);
    _22719 = NOVALUE;

    /** c_decl.e:719					LeftSym = TRUE -- never say: x = x &y or andy - always leave space*/
    _58LeftSym_42560 = _13TRUE_452;
LF: 
LD: 

    /** c_decl.e:723			if stmt[i] = '\n' and i < length(stmt) then*/
    _2 = (object)SEQ_PTR(_stmt_43384);
    _22720 = (object)*(((s1_ptr)_2)->base + _i_43389);
    if (IS_ATOM_INT(_22720)) {
        _22721 = (_22720 == 10LL);
    }
    else {
        _22721 = binary_op(EQUALS, _22720, 10LL);
    }
    _22720 = NOVALUE;
    if (IS_ATOM_INT(_22721)) {
        if (_22721 == 0) {
            goto L10; // [363] 424
        }
    }
    else {
        if (DBL_PTR(_22721)->dbl == 0.0) {
            goto L10; // [363] 424
        }
    }
    if (IS_SEQUENCE(_stmt_43384)){
            _22723 = SEQ_PTR(_stmt_43384)->length;
    }
    else {
        _22723 = 1;
    }
    _22724 = (_i_43389 < _22723);
    _22723 = NOVALUE;
    if (_22724 == 0)
    {
        DeRef(_22724);
        _22724 = NOVALUE;
        goto L10; // [375] 424
    }
    else{
        DeRef(_22724);
        _22724 = NOVALUE;
    }

    /** c_decl.e:724				if emit_c_output then*/
    if (_55emit_c_output_46620 == 0)
    {
        goto L11; // [382] 391
    }
    else{
    }

    /** c_decl.e:725					adjust_indent_after(stmt)*/
    RefDS(_stmt_43384);
    _55adjust_indent_after(_stmt_43384);
L11: 

    /** c_decl.e:727				stmt = stmt[i+1..$]*/
    _22725 = _i_43389 + 1;
    if (_22725 > MAXINT){
        _22725 = NewDouble((eudouble)_22725);
    }
    if (IS_SEQUENCE(_stmt_43384)){
            _22726 = SEQ_PTR(_stmt_43384)->length;
    }
    else {
        _22726 = 1;
    }
    rhs_slice_target = (object_ptr)&_stmt_43384;
    RHS_Slice(_stmt_43384, _22725, _22726);

    /** c_decl.e:728				i = 0*/
    _i_43389 = 0LL;

    /** c_decl.e:729				if emit_c_output then*/
    if (_55emit_c_output_46620 == 0)
    {
        goto L12; // [414] 423
    }
    else{
    }

    /** c_decl.e:730					adjust_indent_before(stmt)*/
    RefDS(_stmt_43384);
    _55adjust_indent_before(_stmt_43384);
L12: 
L10: 

    /** c_decl.e:734			i += 1*/
    _i_43389 = _i_43389 + 1;

    /** c_decl.e:735		end while*/
    goto L4; // [432] 90
L5: 

    /** c_decl.e:737		if emit_c_output then*/
    if (_55emit_c_output_46620 == 0)
    {
        goto L13; // [439] 448
    }
    else{
    }

    /** c_decl.e:738			adjust_indent_after(stmt)*/
    RefDS(_stmt_43384);
    _55adjust_indent_after(_stmt_43384);
L13: 

    /** c_decl.e:740	end procedure*/
    DeRefDS(_stmt_43384);
    DeRef(_arg_43385);
    DeRef(_22717);
    _22717 = NOVALUE;
    DeRef(_22703);
    _22703 = NOVALUE;
    DeRef(_22696);
    _22696 = NOVALUE;
    DeRef(_22712);
    _22712 = NOVALUE;
    DeRef(_22687);
    _22687 = NOVALUE;
    DeRef(_22721);
    _22721 = NOVALUE;
    DeRef(_22715);
    _22715 = NOVALUE;
    DeRef(_22698);
    _22698 = NOVALUE;
    DeRef(_22689);
    _22689 = NOVALUE;
    DeRef(_22679);
    _22679 = NOVALUE;
    DeRef(_22725);
    _22725 = NOVALUE;
    DeRef(_22691);
    _22691 = NOVALUE;
    DeRef(_22672);
    _22672 = NOVALUE;
    DeRef(_22693);
    _22693 = NOVALUE;
    DeRef(_22701);
    _22701 = NOVALUE;
    return;
    ;
}


void _58c_stmt0(object _stmt_43483)
{
    object _0, _1, _2;
    

    /** c_decl.e:745		if emit_c_output then*/
    if (_55emit_c_output_46620 == 0)
    {
        goto L1; // [7] 18
    }
    else{
    }

    /** c_decl.e:746			c_stmt(stmt, {})*/
    RefDS(_stmt_43483);
    RefDS(_21993);
    _58c_stmt(_stmt_43483, _21993, 0LL);
L1: 

    /** c_decl.e:748	end procedure*/
    DeRefDS(_stmt_43483);
    return;
    ;
}


object _58needs_uninit(object _eentry_43488)
{
    object _22749 = NOVALUE;
    object _22748 = NOVALUE;
    object _22747 = NOVALUE;
    object _22746 = NOVALUE;
    object _22745 = NOVALUE;
    object _22744 = NOVALUE;
    object _22743 = NOVALUE;
    object _22742 = NOVALUE;
    object _22741 = NOVALUE;
    object _22740 = NOVALUE;
    object _22739 = NOVALUE;
    object _22738 = NOVALUE;
    object _22737 = NOVALUE;
    object _22736 = NOVALUE;
    object _22735 = NOVALUE;
    object _22734 = NOVALUE;
    object _22733 = NOVALUE;
    object _22732 = NOVALUE;
    object _22731 = NOVALUE;
    object _22730 = NOVALUE;
    object _22729 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:751		if eentry[S_SCOPE] >= SC_LOCAL*/
    _2 = (object)SEQ_PTR(_eentry_43488);
    _22729 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_22729)) {
        _22730 = (_22729 >= 5LL);
    }
    else {
        _22730 = binary_op(GREATEREQ, _22729, 5LL);
    }
    _22729 = NOVALUE;
    if (IS_ATOM_INT(_22730)) {
        if (_22730 == 0) {
            _22731 = 0;
            goto L1; // [17] 77
        }
    }
    else {
        if (DBL_PTR(_22730)->dbl == 0.0) {
            _22731 = 0;
            goto L1; // [17] 77
        }
    }
    _2 = (object)SEQ_PTR(_eentry_43488);
    _22732 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_22732)) {
        _22733 = (_22732 <= 6LL);
    }
    else {
        _22733 = binary_op(LESSEQ, _22732, 6LL);
    }
    _22732 = NOVALUE;
    if (IS_ATOM_INT(_22733)) {
        if (_22733 != 0) {
            _22734 = 1;
            goto L2; // [33] 53
        }
    }
    else {
        if (DBL_PTR(_22733)->dbl != 0.0) {
            _22734 = 1;
            goto L2; // [33] 53
        }
    }
    _2 = (object)SEQ_PTR(_eentry_43488);
    _22735 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_22735)) {
        _22736 = (_22735 == 11LL);
    }
    else {
        _22736 = binary_op(EQUALS, _22735, 11LL);
    }
    _22735 = NOVALUE;
    DeRef(_22734);
    if (IS_ATOM_INT(_22736))
    _22734 = (_22736 != 0);
    else
    _22734 = DBL_PTR(_22736)->dbl != 0.0;
L2: 
    if (_22734 != 0) {
        _22737 = 1;
        goto L3; // [53] 73
    }
    _2 = (object)SEQ_PTR(_eentry_43488);
    _22738 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_22738)) {
        _22739 = (_22738 == 13LL);
    }
    else {
        _22739 = binary_op(EQUALS, _22738, 13LL);
    }
    _22738 = NOVALUE;
    if (IS_ATOM_INT(_22739))
    _22737 = (_22739 != 0);
    else
    _22737 = DBL_PTR(_22739)->dbl != 0.0;
L3: 
    DeRef(_22731);
    _22731 = (_22737 != 0);
L1: 
    if (_22731 == 0) {
        _22740 = 0;
        goto L4; // [77] 97
    }
    _2 = (object)SEQ_PTR(_eentry_43488);
    _22741 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (IS_ATOM_INT(_22741)) {
        _22742 = (_22741 != 0LL);
    }
    else {
        _22742 = binary_op(NOTEQ, _22741, 0LL);
    }
    _22741 = NOVALUE;
    if (IS_ATOM_INT(_22742))
    _22740 = (_22742 != 0);
    else
    _22740 = DBL_PTR(_22742)->dbl != 0.0;
L4: 
    if (_22740 == 0) {
        _22743 = 0;
        goto L5; // [97] 117
    }
    _2 = (object)SEQ_PTR(_eentry_43488);
    _22744 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (IS_ATOM_INT(_22744)) {
        _22745 = (_22744 != 99LL);
    }
    else {
        _22745 = binary_op(NOTEQ, _22744, 99LL);
    }
    _22744 = NOVALUE;
    if (IS_ATOM_INT(_22745))
    _22743 = (_22745 != 0);
    else
    _22743 = DBL_PTR(_22745)->dbl != 0.0;
L5: 
    if (_22743 == 0) {
        goto L6; // [117] 150
    }
    _2 = (object)SEQ_PTR(_eentry_43488);
    if (!IS_ATOM_INT(_36S_TOKEN_21081)){
        _22747 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    }
    else{
        _22747 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    }
    _22748 = find_from(_22747, _38RTN_TOKS_16045, 1LL);
    _22747 = NOVALUE;
    _22749 = (_22748 == 0);
    _22748 = NOVALUE;
    if (_22749 == 0)
    {
        DeRef(_22749);
        _22749 = NOVALUE;
        goto L6; // [138] 150
    }
    else{
        DeRef(_22749);
        _22749 = NOVALUE;
    }

    /** c_decl.e:757			return 1*/
    DeRefDS(_eentry_43488);
    DeRef(_22742);
    _22742 = NOVALUE;
    DeRef(_22733);
    _22733 = NOVALUE;
    DeRef(_22745);
    _22745 = NOVALUE;
    DeRef(_22730);
    _22730 = NOVALUE;
    DeRef(_22736);
    _22736 = NOVALUE;
    DeRef(_22739);
    _22739 = NOVALUE;
    return 1LL;
    goto L7; // [147] 157
L6: 

    /** c_decl.e:759			return 0*/
    DeRefDS(_eentry_43488);
    DeRef(_22742);
    _22742 = NOVALUE;
    DeRef(_22733);
    _22733 = NOVALUE;
    DeRef(_22745);
    _22745 = NOVALUE;
    DeRef(_22730);
    _22730 = NOVALUE;
    DeRef(_22736);
    _22736 = NOVALUE;
    DeRef(_22739);
    _22739 = NOVALUE;
    return 0LL;
L7: 
    ;
}


void _58DeclareFileVars()
{
    object _s_43529 = NOVALUE;
    object _eentry_43531 = NOVALUE;
    object _cleanup_vars_43625 = NOVALUE;
    object _22832 = NOVALUE;
    object _22825 = NOVALUE;
    object _22820 = NOVALUE;
    object _22817 = NOVALUE;
    object _22816 = NOVALUE;
    object _22815 = NOVALUE;
    object _22813 = NOVALUE;
    object _22809 = NOVALUE;
    object _22805 = NOVALUE;
    object _22802 = NOVALUE;
    object _22801 = NOVALUE;
    object _22800 = NOVALUE;
    object _22798 = NOVALUE;
    object _22794 = NOVALUE;
    object _22790 = NOVALUE;
    object _22789 = NOVALUE;
    object _22788 = NOVALUE;
    object _22785 = NOVALUE;
    object _22784 = NOVALUE;
    object _22782 = NOVALUE;
    object _22781 = NOVALUE;
    object _22780 = NOVALUE;
    object _22779 = NOVALUE;
    object _22775 = NOVALUE;
    object _22774 = NOVALUE;
    object _22773 = NOVALUE;
    object _22772 = NOVALUE;
    object _22771 = NOVALUE;
    object _22770 = NOVALUE;
    object _22769 = NOVALUE;
    object _22768 = NOVALUE;
    object _22767 = NOVALUE;
    object _22766 = NOVALUE;
    object _22765 = NOVALUE;
    object _22764 = NOVALUE;
    object _22763 = NOVALUE;
    object _22762 = NOVALUE;
    object _22761 = NOVALUE;
    object _22760 = NOVALUE;
    object _22759 = NOVALUE;
    object _22758 = NOVALUE;
    object _22757 = NOVALUE;
    object _22756 = NOVALUE;
    object _22755 = NOVALUE;
    object _22754 = NOVALUE;
    object _22751 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:769		c_puts("// Declaring file vars\n")*/
    RefDS(_22750);
    _55c_puts(_22750);

    /** c_decl.e:770		s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22751 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21446);
    _2 = (object)SEQ_PTR(_22751);
    _s_43529 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_43529)){
        _s_43529 = (object)DBL_PTR(_s_43529)->dbl;
    }
    _22751 = NOVALUE;

    /** c_decl.e:772		while s do*/
L1: 
    if (_s_43529 == 0)
    {
        goto L2; // [29] 328
    }
    else{
    }

    /** c_decl.e:773			eentry = SymTab[s]*/
    DeRef(_eentry_43531);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _eentry_43531 = (object)*(((s1_ptr)_2)->base + _s_43529);
    Ref(_eentry_43531);

    /** c_decl.e:774			if eentry[S_SCOPE] >= SC_LOCAL*/
    _2 = (object)SEQ_PTR(_eentry_43531);
    _22754 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_22754)) {
        _22755 = (_22754 >= 5LL);
    }
    else {
        _22755 = binary_op(GREATEREQ, _22754, 5LL);
    }
    _22754 = NOVALUE;
    if (IS_ATOM_INT(_22755)) {
        if (_22755 == 0) {
            DeRef(_22756);
            _22756 = 0;
            goto L3; // [56] 116
        }
    }
    else {
        if (DBL_PTR(_22755)->dbl == 0.0) {
            DeRef(_22756);
            _22756 = 0;
            goto L3; // [56] 116
        }
    }
    _2 = (object)SEQ_PTR(_eentry_43531);
    _22757 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_22757)) {
        _22758 = (_22757 <= 6LL);
    }
    else {
        _22758 = binary_op(LESSEQ, _22757, 6LL);
    }
    _22757 = NOVALUE;
    if (IS_ATOM_INT(_22758)) {
        if (_22758 != 0) {
            DeRef(_22759);
            _22759 = 1;
            goto L4; // [72] 92
        }
    }
    else {
        if (DBL_PTR(_22758)->dbl != 0.0) {
            DeRef(_22759);
            _22759 = 1;
            goto L4; // [72] 92
        }
    }
    _2 = (object)SEQ_PTR(_eentry_43531);
    _22760 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_22760)) {
        _22761 = (_22760 == 11LL);
    }
    else {
        _22761 = binary_op(EQUALS, _22760, 11LL);
    }
    _22760 = NOVALUE;
    DeRef(_22759);
    if (IS_ATOM_INT(_22761))
    _22759 = (_22761 != 0);
    else
    _22759 = DBL_PTR(_22761)->dbl != 0.0;
L4: 
    if (_22759 != 0) {
        _22762 = 1;
        goto L5; // [92] 112
    }
    _2 = (object)SEQ_PTR(_eentry_43531);
    _22763 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_22763)) {
        _22764 = (_22763 == 13LL);
    }
    else {
        _22764 = binary_op(EQUALS, _22763, 13LL);
    }
    _22763 = NOVALUE;
    if (IS_ATOM_INT(_22764))
    _22762 = (_22764 != 0);
    else
    _22762 = DBL_PTR(_22764)->dbl != 0.0;
L5: 
    DeRef(_22756);
    _22756 = (_22762 != 0);
L3: 
    if (_22756 == 0) {
        _22765 = 0;
        goto L6; // [116] 136
    }
    _2 = (object)SEQ_PTR(_eentry_43531);
    _22766 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (IS_ATOM_INT(_22766)) {
        _22767 = (_22766 != 0LL);
    }
    else {
        _22767 = binary_op(NOTEQ, _22766, 0LL);
    }
    _22766 = NOVALUE;
    if (IS_ATOM_INT(_22767))
    _22765 = (_22767 != 0);
    else
    _22765 = DBL_PTR(_22767)->dbl != 0.0;
L6: 
    if (_22765 == 0) {
        _22768 = 0;
        goto L7; // [136] 156
    }
    _2 = (object)SEQ_PTR(_eentry_43531);
    _22769 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (IS_ATOM_INT(_22769)) {
        _22770 = (_22769 != 99LL);
    }
    else {
        _22770 = binary_op(NOTEQ, _22769, 99LL);
    }
    _22769 = NOVALUE;
    if (IS_ATOM_INT(_22770))
    _22768 = (_22770 != 0);
    else
    _22768 = DBL_PTR(_22770)->dbl != 0.0;
L7: 
    if (_22768 == 0) {
        goto L8; // [156] 307
    }
    _2 = (object)SEQ_PTR(_eentry_43531);
    if (!IS_ATOM_INT(_36S_TOKEN_21081)){
        _22772 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    }
    else{
        _22772 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    }
    _22773 = find_from(_22772, _38RTN_TOKS_16045, 1LL);
    _22772 = NOVALUE;
    _22774 = (_22773 == 0);
    _22773 = NOVALUE;
    if (_22774 == 0)
    {
        DeRef(_22774);
        _22774 = NOVALUE;
        goto L8; // [177] 307
    }
    else{
        DeRef(_22774);
        _22774 = NOVALUE;
    }

    /** c_decl.e:780				if eentry[S_TOKEN] = PROC then*/
    _2 = (object)SEQ_PTR(_eentry_43531);
    if (!IS_ATOM_INT(_36S_TOKEN_21081)){
        _22775 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    }
    else{
        _22775 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    }
    if (binary_op_a(NOTEQ, _22775, 27LL)){
        _22775 = NOVALUE;
        goto L9; // [190] 202
    }
    _22775 = NOVALUE;

    /** c_decl.e:781					c_puts( "void ")*/
    RefDS(_22777);
    _55c_puts(_22777);
    goto LA; // [199] 208
L9: 

    /** c_decl.e:783					c_puts("object ")*/
    RefDS(_22778);
    _55c_puts(_22778);
LA: 

    /** c_decl.e:785				c_printf("_%d", eentry[S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_eentry_43531);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _22779 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _22779 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    RefDS(_22116);
    Ref(_22779);
    _55c_printf(_22116, _22779);
    _22779 = NOVALUE;

    /** c_decl.e:786				c_puts(eentry[S_NAME])*/
    _2 = (object)SEQ_PTR(_eentry_43531);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _22780 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _22780 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    Ref(_22780);
    _55c_puts(_22780);
    _22780 = NOVALUE;

    /** c_decl.e:787				if is_integer( eentry[S_OBJ] ) then*/
    _2 = (object)SEQ_PTR(_eentry_43531);
    _22781 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_22781);
    _22782 = _36is_integer(_22781);
    _22781 = NOVALUE;
    if (_22782 == 0) {
        DeRef(_22782);
        _22782 = NOVALUE;
        goto LB; // [243] 267
    }
    else {
        if (!IS_ATOM_INT(_22782) && DBL_PTR(_22782)->dbl == 0.0){
            DeRef(_22782);
            _22782 = NOVALUE;
            goto LB; // [243] 267
        }
        DeRef(_22782);
        _22782 = NOVALUE;
    }
    DeRef(_22782);
    _22782 = NOVALUE;

    /** c_decl.e:788						c_printf(" = %d%s;\n", { eentry[S_OBJ], LL_suffix} )*/
    _2 = (object)SEQ_PTR(_eentry_43531);
    _22784 = (object)*(((s1_ptr)_2)->base + 1LL);
    RefDS(_59LL_suffix_30004);
    Ref(_22784);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _22784;
    ((intptr_t *)_2)[2] = _59LL_suffix_30004;
    _22785 = MAKE_SEQ(_1);
    _22784 = NOVALUE;
    RefDS(_22783);
    _55c_printf(_22783, _22785);
    _22785 = NOVALUE;
    goto LC; // [264] 273
LB: 

    /** c_decl.e:790					c_puts(" = NOVALUE;\n")*/
    RefDS(_22786);
    _55c_puts(_22786);
LC: 

    /** c_decl.e:793				c_hputs("extern object ")*/
    RefDS(_22787);
    _55c_hputs(_22787);

    /** c_decl.e:794				c_hprintf("_%d", eentry[S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_eentry_43531);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _22788 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _22788 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    RefDS(_22116);
    Ref(_22788);
    _55c_hprintf(_22116, _22788);
    _22788 = NOVALUE;

    /** c_decl.e:795				c_hputs(eentry[S_NAME])*/
    _2 = (object)SEQ_PTR(_eentry_43531);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _22789 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _22789 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    Ref(_22789);
    _55c_hputs(_22789);
    _22789 = NOVALUE;

    /** c_decl.e:797				c_hputs(";\n")*/
    RefDS(_22269);
    _55c_hputs(_22269);
L8: 

    /** c_decl.e:799			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22790 = (object)*(((s1_ptr)_2)->base + _s_43529);
    _2 = (object)SEQ_PTR(_22790);
    _s_43529 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_43529)){
        _s_43529 = (object)DBL_PTR(_s_43529)->dbl;
    }
    _22790 = NOVALUE;

    /** c_decl.e:800		end while*/
    goto L1; // [325] 29
L2: 

    /** c_decl.e:801		c_puts("\n")*/
    RefDS(_22188);
    _55c_puts(_22188);

    /** c_decl.e:802		c_hputs("\n")*/
    RefDS(_22188);
    _55c_hputs(_22188);

    /** c_decl.e:803		if dll_option or debug_option then*/
    if (_58dll_option_42563 != 0) {
        goto LD; // [342] 353
    }
    if (_58debug_option_42573 == 0)
    {
        goto LE; // [349] 707
    }
    else{
    }
LD: 

    /** c_decl.e:804			integer cleanup_vars = 0*/
    _cleanup_vars_43625 = 0LL;

    /** c_decl.e:805			c_puts("// Declaring var array for cleanup\n")*/
    RefDS(_22793);
    _55c_puts(_22793);

    /** c_decl.e:806			s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22794 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21446);
    _2 = (object)SEQ_PTR(_22794);
    _s_43529 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_43529)){
        _s_43529 = (object)DBL_PTR(_s_43529)->dbl;
    }
    _22794 = NOVALUE;

    /** c_decl.e:807			c_stmt0( "object_ptr _0var_cleanup[] = {\n" )*/
    RefDS(_22796);
    _58c_stmt0(_22796);

    /** c_decl.e:808			while s do*/
LF: 
    if (_s_43529 == 0)
    {
        goto L10; // [391] 473
    }
    else{
    }

    /** c_decl.e:809				eentry = SymTab[s]*/
    DeRef(_eentry_43531);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _eentry_43531 = (object)*(((s1_ptr)_2)->base + _s_43529);
    Ref(_eentry_43531);

    /** c_decl.e:810				if needs_uninit( eentry ) then*/
    RefDS(_eentry_43531);
    _22798 = _58needs_uninit(_eentry_43531);
    if (_22798 == 0) {
        DeRef(_22798);
        _22798 = NOVALUE;
        goto L11; // [410] 452
    }
    else {
        if (!IS_ATOM_INT(_22798) && DBL_PTR(_22798)->dbl == 0.0){
            DeRef(_22798);
            _22798 = NOVALUE;
            goto L11; // [410] 452
        }
        DeRef(_22798);
        _22798 = NOVALUE;
    }
    DeRef(_22798);
    _22798 = NOVALUE;

    /** c_decl.e:812					c_stmt0( sprintf("&_%d", eentry[S_FILE_NO]))*/
    _2 = (object)SEQ_PTR(_eentry_43531);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _22800 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _22800 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    _22801 = EPrintf(-9999999, _22799, _22800);
    _22800 = NOVALUE;
    _58c_stmt0(_22801);
    _22801 = NOVALUE;

    /** c_decl.e:813					c_puts(eentry[S_NAME] )*/
    _2 = (object)SEQ_PTR(_eentry_43531);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _22802 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _22802 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    Ref(_22802);
    _55c_puts(_22802);
    _22802 = NOVALUE;

    /** c_decl.e:814					c_printf(", // %d\n", cleanup_vars )*/
    RefDS(_22803);
    _55c_printf(_22803, _cleanup_vars_43625);

    /** c_decl.e:815					cleanup_vars += 1*/
    _cleanup_vars_43625 = _cleanup_vars_43625 + 1;
L11: 

    /** c_decl.e:818				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22805 = (object)*(((s1_ptr)_2)->base + _s_43529);
    _2 = (object)SEQ_PTR(_22805);
    _s_43529 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_43529)){
        _s_43529 = (object)DBL_PTR(_s_43529)->dbl;
    }
    _22805 = NOVALUE;

    /** c_decl.e:819			end while*/
    goto LF; // [470] 391
L10: 

    /** c_decl.e:820			c_stmt0( "0\n" )*/
    RefDS(_22807);
    _58c_stmt0(_22807);

    /** c_decl.e:821			c_stmt0( "};\n" )*/
    RefDS(_22808);
    _58c_stmt0(_22808);

    /** c_decl.e:822			s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22809 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21446);
    _2 = (object)SEQ_PTR(_22809);
    _s_43529 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_43529)){
        _s_43529 = (object)DBL_PTR(_s_43529)->dbl;
    }
    _22809 = NOVALUE;

    /** c_decl.e:823			c_stmt0( "char *_0var_cleanup_name[] = {\n" )*/
    RefDS(_22811);
    _58c_stmt0(_22811);

    /** c_decl.e:824			cleanup_vars = 0*/
    _cleanup_vars_43625 = 0LL;

    /** c_decl.e:825			while s do*/
L12: 
    if (_s_43529 == 0)
    {
        goto L13; // [516] 598
    }
    else{
    }

    /** c_decl.e:826				eentry = SymTab[s]*/
    DeRef(_eentry_43531);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _eentry_43531 = (object)*(((s1_ptr)_2)->base + _s_43529);
    Ref(_eentry_43531);

    /** c_decl.e:827				if needs_uninit( eentry ) then*/
    RefDS(_eentry_43531);
    _22813 = _58needs_uninit(_eentry_43531);
    if (_22813 == 0) {
        DeRef(_22813);
        _22813 = NOVALUE;
        goto L14; // [535] 577
    }
    else {
        if (!IS_ATOM_INT(_22813) && DBL_PTR(_22813)->dbl == 0.0){
            DeRef(_22813);
            _22813 = NOVALUE;
            goto L14; // [535] 577
        }
        DeRef(_22813);
        _22813 = NOVALUE;
    }
    DeRef(_22813);
    _22813 = NOVALUE;

    /** c_decl.e:828					c_stmt0( sprintf("\"_%d", eentry[S_FILE_NO]))*/
    _2 = (object)SEQ_PTR(_eentry_43531);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _22815 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _22815 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    _22816 = EPrintf(-9999999, _22814, _22815);
    _22815 = NOVALUE;
    _58c_stmt0(_22816);
    _22816 = NOVALUE;

    /** c_decl.e:829					c_puts(eentry[S_NAME] )*/
    _2 = (object)SEQ_PTR(_eentry_43531);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _22817 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _22817 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    Ref(_22817);
    _55c_puts(_22817);
    _22817 = NOVALUE;

    /** c_decl.e:830					c_printf("\", // %d\n", cleanup_vars )*/
    RefDS(_22818);
    _55c_printf(_22818, _cleanup_vars_43625);

    /** c_decl.e:831					cleanup_vars += 1*/
    _cleanup_vars_43625 = _cleanup_vars_43625 + 1;
L14: 

    /** c_decl.e:834				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22820 = (object)*(((s1_ptr)_2)->base + _s_43529);
    _2 = (object)SEQ_PTR(_22820);
    _s_43529 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_43529)){
        _s_43529 = (object)DBL_PTR(_s_43529)->dbl;
    }
    _22820 = NOVALUE;

    /** c_decl.e:835			end while*/
    goto L12; // [595] 516
L13: 

    /** c_decl.e:836			c_stmt0( "0\n" )*/
    RefDS(_22807);
    _58c_stmt0(_22807);

    /** c_decl.e:837			c_stmt0( "};\n" )*/
    RefDS(_22808);
    _58c_stmt0(_22808);

    /** c_decl.e:838			c_stmt0( "void _0cleanup_vars(){\n" )*/
    RefDS(_22822);
    _58c_stmt0(_22822);

    /** c_decl.e:839				c_stmt0( "int i;\n" )*/
    RefDS(_22077);
    _58c_stmt0(_22077);

    /** c_decl.e:840				c_stmt0( "object x;\n" )*/
    RefDS(_22823);
    _58c_stmt0(_22823);

    /** c_decl.e:841				c_stmt0( sprintf( "for( i = 0; i < %d; ++i ){\n", cleanup_vars ) )*/
    _22825 = EPrintf(-9999999, _22824, _cleanup_vars_43625);
    _58c_stmt0(_22825);
    _22825 = NOVALUE;

    /** c_decl.e:842					c_stmt0( "x = *_0var_cleanup[i];\n" )*/
    RefDS(_22826);
    _58c_stmt0(_22826);

    //c_decl.e:843					c_stmt0( "if( x >= NOVALUE ) /* do nothing */;\n" )
    RefDS(_22827);
    _58c_stmt0(_22827);

    /** c_decl.e:844					c_stmt0( "else if ( IS_ATOM_DBL( x ) && DBL_PTR( x )->cleanup != 0) {\n")*/
    RefDS(_22828);
    _58c_stmt0(_22828);

    /** c_decl.e:845						c_stmt0( "cleanup_double( DBL_PTR( x ) );\n")*/
    RefDS(_22829);
    _58c_stmt0(_22829);

    /** c_decl.e:846					c_stmt0( "}\n" )*/
    RefDS(_15971);
    _58c_stmt0(_15971);

    /** c_decl.e:847						c_stmt0( "else if (IS_SEQUENCE( x ) && SEQ_PTR( x )->cleanup != 0 ) {\n")*/
    RefDS(_22830);
    _58c_stmt0(_22830);

    /** c_decl.e:848						c_stmt0( "cleanup_sequence( SEQ_PTR( x ) );\n")*/
    RefDS(_22831);
    _58c_stmt0(_22831);

    /** c_decl.e:849					c_stmt0( "}\n" )*/
    RefDS(_15971);
    _58c_stmt0(_15971);

    /** c_decl.e:850				c_stmt0( "}\n" )*/
    RefDS(_15971);
    _58c_stmt0(_15971);

    /** c_decl.e:851				c_stmt0( sprintf( "for( i = 0; i < %d; ++i ){\n", cleanup_vars ) )*/
    _22832 = EPrintf(-9999999, _22824, _cleanup_vars_43625);
    _58c_stmt0(_22832);
    _22832 = NOVALUE;

    /** c_decl.e:852					c_stmt0( "DeRef( *_0var_cleanup[i] );\n" )*/
    RefDS(_22833);
    _58c_stmt0(_22833);

    /** c_decl.e:853					c_stmt0( "*_0var_cleanup[i] = NOVALUE;\n" )*/
    RefDS(_22834);
    _58c_stmt0(_22834);

    /** c_decl.e:854				c_stmt0( "}\n" )*/
    RefDS(_15971);
    _58c_stmt0(_15971);

    /** c_decl.e:855			c_stmt0( "}\n" )*/
    RefDS(_15971);
    _58c_stmt0(_15971);
LE: 

    /** c_decl.e:857	end procedure*/
    DeRef(_eentry_43531);
    DeRef(_22758);
    _22758 = NOVALUE;
    DeRef(_22767);
    _22767 = NOVALUE;
    DeRef(_22770);
    _22770 = NOVALUE;
    DeRef(_22755);
    _22755 = NOVALUE;
    DeRef(_22761);
    _22761 = NOVALUE;
    DeRef(_22764);
    _22764 = NOVALUE;
    return;
    ;
}


object _58PromoteTypeInfo()
{
    object _updsym_43696 = NOVALUE;
    object _s_43698 = NOVALUE;
    object _sym_43699 = NOVALUE;
    object _symo_43700 = NOVALUE;
    object _upd_43929 = NOVALUE;
    object _22933 = NOVALUE;
    object _22931 = NOVALUE;
    object _22930 = NOVALUE;
    object _22929 = NOVALUE;
    object _22928 = NOVALUE;
    object _22926 = NOVALUE;
    object _22924 = NOVALUE;
    object _22923 = NOVALUE;
    object _22922 = NOVALUE;
    object _22921 = NOVALUE;
    object _22920 = NOVALUE;
    object _22916 = NOVALUE;
    object _22913 = NOVALUE;
    object _22912 = NOVALUE;
    object _22911 = NOVALUE;
    object _22910 = NOVALUE;
    object _22909 = NOVALUE;
    object _22908 = NOVALUE;
    object _22907 = NOVALUE;
    object _22906 = NOVALUE;
    object _22905 = NOVALUE;
    object _22904 = NOVALUE;
    object _22903 = NOVALUE;
    object _22901 = NOVALUE;
    object _22900 = NOVALUE;
    object _22899 = NOVALUE;
    object _22898 = NOVALUE;
    object _22897 = NOVALUE;
    object _22896 = NOVALUE;
    object _22895 = NOVALUE;
    object _22894 = NOVALUE;
    object _22893 = NOVALUE;
    object _22892 = NOVALUE;
    object _22890 = NOVALUE;
    object _22889 = NOVALUE;
    object _22888 = NOVALUE;
    object _22886 = NOVALUE;
    object _22885 = NOVALUE;
    object _22884 = NOVALUE;
    object _22882 = NOVALUE;
    object _22881 = NOVALUE;
    object _22880 = NOVALUE;
    object _22879 = NOVALUE;
    object _22878 = NOVALUE;
    object _22877 = NOVALUE;
    object _22876 = NOVALUE;
    object _22874 = NOVALUE;
    object _22873 = NOVALUE;
    object _22872 = NOVALUE;
    object _22871 = NOVALUE;
    object _22869 = NOVALUE;
    object _22868 = NOVALUE;
    object _22866 = NOVALUE;
    object _22865 = NOVALUE;
    object _22864 = NOVALUE;
    object _22863 = NOVALUE;
    object _22862 = NOVALUE;
    object _22861 = NOVALUE;
    object _22860 = NOVALUE;
    object _22858 = NOVALUE;
    object _22857 = NOVALUE;
    object _22856 = NOVALUE;
    object _22855 = NOVALUE;
    object _22854 = NOVALUE;
    object _22853 = NOVALUE;
    object _22852 = NOVALUE;
    object _22851 = NOVALUE;
    object _22850 = NOVALUE;
    object _22849 = NOVALUE;
    object _22848 = NOVALUE;
    object _22847 = NOVALUE;
    object _22846 = NOVALUE;
    object _22845 = NOVALUE;
    object _22843 = NOVALUE;
    object _22842 = NOVALUE;
    object _22841 = NOVALUE;
    object _22839 = NOVALUE;
    object _22838 = NOVALUE;
    object _22835 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** c_decl.e:866		sequence sym, symo*/

    /** c_decl.e:868		updsym = 0*/
    _updsym_43696 = 0LL;

    /** c_decl.e:869		g_has_delete = p_has_delete*/
    _58g_has_delete_42755 = _58p_has_delete_42756;

    /** c_decl.e:870		s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22835 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21446);
    _2 = (object)SEQ_PTR(_22835);
    _s_43698 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_43698)){
        _s_43698 = (object)DBL_PTR(_s_43698)->dbl;
    }
    _22835 = NOVALUE;

    /** c_decl.e:871		while s do*/
L1: 
    if (_s_43698 == 0)
    {
        goto L2; // [38] 921
    }
    else{
    }

    /** c_decl.e:872			sym = SymTab[s]*/
    DeRef(_sym_43699);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _sym_43699 = (object)*(((s1_ptr)_2)->base + _s_43698);
    Ref(_sym_43699);

    /** c_decl.e:873			symo = sym*/
    RefDS(_sym_43699);
    DeRef(_symo_43700);
    _symo_43700 = _sym_43699;

    /** c_decl.e:874			if sym[S_TOKEN] = FUNC or sym[S_TOKEN] = TYPE then*/
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!IS_ATOM_INT(_36S_TOKEN_21081)){
        _22838 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    }
    else{
        _22838 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    }
    if (IS_ATOM_INT(_22838)) {
        _22839 = (_22838 == 501LL);
    }
    else {
        _22839 = binary_op(EQUALS, _22838, 501LL);
    }
    _22838 = NOVALUE;
    if (IS_ATOM_INT(_22839)) {
        if (_22839 != 0) {
            goto L3; // [72] 93
        }
    }
    else {
        if (DBL_PTR(_22839)->dbl != 0.0) {
            goto L3; // [72] 93
        }
    }
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!IS_ATOM_INT(_36S_TOKEN_21081)){
        _22841 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    }
    else{
        _22841 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    }
    if (IS_ATOM_INT(_22841)) {
        _22842 = (_22841 == 504LL);
    }
    else {
        _22842 = binary_op(EQUALS, _22841, 504LL);
    }
    _22841 = NOVALUE;
    if (_22842 == 0) {
        DeRef(_22842);
        _22842 = NOVALUE;
        goto L4; // [89] 138
    }
    else {
        if (!IS_ATOM_INT(_22842) && DBL_PTR(_22842)->dbl == 0.0){
            DeRef(_22842);
            _22842 = NOVALUE;
            goto L4; // [89] 138
        }
        DeRef(_22842);
        _22842 = NOVALUE;
    }
    DeRef(_22842);
    _22842 = NOVALUE;
L3: 

    /** c_decl.e:875				if sym[S_GTYPE_NEW] = TYPE_NULL then*/
    _2 = (object)SEQ_PTR(_sym_43699);
    _22843 = (object)*(((s1_ptr)_2)->base + 38LL);
    if (binary_op_a(NOTEQ, _22843, 0LL)){
        _22843 = NOVALUE;
        goto L5; // [103] 120
    }
    _22843 = NOVALUE;

    /** c_decl.e:876					sym[S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);
    goto L6; // [117] 549
L5: 

    /** c_decl.e:878					sym[S_GTYPE] = sym[S_GTYPE_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43699);
    _22845 = (object)*(((s1_ptr)_2)->base + 38LL);
    Ref(_22845);
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22845;
    if( _1 != _22845 ){
        DeRef(_1);
    }
    _22845 = NOVALUE;
    goto L6; // [135] 549
L4: 

    /** c_decl.e:883				if sym[S_GTYPE] != TYPE_INTEGER and*/
    _2 = (object)SEQ_PTR(_sym_43699);
    _22846 = (object)*(((s1_ptr)_2)->base + 36LL);
    if (IS_ATOM_INT(_22846)) {
        _22847 = (_22846 != 1LL);
    }
    else {
        _22847 = binary_op(NOTEQ, _22846, 1LL);
    }
    _22846 = NOVALUE;
    if (IS_ATOM_INT(_22847)) {
        if (_22847 == 0) {
            DeRef(_22848);
            _22848 = 0;
            goto L7; // [152] 172
        }
    }
    else {
        if (DBL_PTR(_22847)->dbl == 0.0) {
            DeRef(_22848);
            _22848 = 0;
            goto L7; // [152] 172
        }
    }
    _2 = (object)SEQ_PTR(_sym_43699);
    _22849 = (object)*(((s1_ptr)_2)->base + 38LL);
    if (IS_ATOM_INT(_22849)) {
        _22850 = (_22849 != 16LL);
    }
    else {
        _22850 = binary_op(NOTEQ, _22849, 16LL);
    }
    _22849 = NOVALUE;
    DeRef(_22848);
    if (IS_ATOM_INT(_22850))
    _22848 = (_22850 != 0);
    else
    _22848 = DBL_PTR(_22850)->dbl != 0.0;
L7: 
    if (_22848 == 0) {
        goto L8; // [172] 283
    }
    _2 = (object)SEQ_PTR(_sym_43699);
    _22852 = (object)*(((s1_ptr)_2)->base + 38LL);
    if (IS_ATOM_INT(_22852)) {
        _22853 = (_22852 != 0LL);
    }
    else {
        _22853 = binary_op(NOTEQ, _22852, 0LL);
    }
    _22852 = NOVALUE;
    if (_22853 == 0) {
        DeRef(_22853);
        _22853 = NOVALUE;
        goto L8; // [189] 283
    }
    else {
        if (!IS_ATOM_INT(_22853) && DBL_PTR(_22853)->dbl == 0.0){
            DeRef(_22853);
            _22853 = NOVALUE;
            goto L8; // [189] 283
        }
        DeRef(_22853);
        _22853 = NOVALUE;
    }
    DeRef(_22853);
    _22853 = NOVALUE;

    /** c_decl.e:886					if sym[S_GTYPE_NEW] = TYPE_INTEGER or*/
    _2 = (object)SEQ_PTR(_sym_43699);
    _22854 = (object)*(((s1_ptr)_2)->base + 38LL);
    if (IS_ATOM_INT(_22854)) {
        _22855 = (_22854 == 1LL);
    }
    else {
        _22855 = binary_op(EQUALS, _22854, 1LL);
    }
    _22854 = NOVALUE;
    if (IS_ATOM_INT(_22855)) {
        if (_22855 != 0) {
            DeRef(_22856);
            _22856 = 1;
            goto L9; // [206] 226
        }
    }
    else {
        if (DBL_PTR(_22855)->dbl != 0.0) {
            DeRef(_22856);
            _22856 = 1;
            goto L9; // [206] 226
        }
    }
    _2 = (object)SEQ_PTR(_sym_43699);
    _22857 = (object)*(((s1_ptr)_2)->base + 36LL);
    if (IS_ATOM_INT(_22857)) {
        _22858 = (_22857 == 16LL);
    }
    else {
        _22858 = binary_op(EQUALS, _22857, 16LL);
    }
    _22857 = NOVALUE;
    DeRef(_22856);
    if (IS_ATOM_INT(_22858))
    _22856 = (_22858 != 0);
    else
    _22856 = DBL_PTR(_22858)->dbl != 0.0;
L9: 
    if (_22856 != 0) {
        goto LA; // [226] 267
    }
    _2 = (object)SEQ_PTR(_sym_43699);
    _22860 = (object)*(((s1_ptr)_2)->base + 36LL);
    if (IS_ATOM_INT(_22860)) {
        _22861 = (_22860 == 4LL);
    }
    else {
        _22861 = binary_op(EQUALS, _22860, 4LL);
    }
    _22860 = NOVALUE;
    if (IS_ATOM_INT(_22861)) {
        if (_22861 == 0) {
            DeRef(_22862);
            _22862 = 0;
            goto LB; // [242] 262
        }
    }
    else {
        if (DBL_PTR(_22861)->dbl == 0.0) {
            DeRef(_22862);
            _22862 = 0;
            goto LB; // [242] 262
        }
    }
    _2 = (object)SEQ_PTR(_sym_43699);
    _22863 = (object)*(((s1_ptr)_2)->base + 38LL);
    if (IS_ATOM_INT(_22863)) {
        _22864 = (_22863 == 2LL);
    }
    else {
        _22864 = binary_op(EQUALS, _22863, 2LL);
    }
    _22863 = NOVALUE;
    DeRef(_22862);
    if (IS_ATOM_INT(_22864))
    _22862 = (_22864 != 0);
    else
    _22862 = DBL_PTR(_22864)->dbl != 0.0;
LB: 
    if (_22862 == 0)
    {
        _22862 = NOVALUE;
        goto LC; // [263] 282
    }
    else{
        _22862 = NOVALUE;
    }
LA: 

    /** c_decl.e:890							sym[S_GTYPE] = sym[S_GTYPE_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43699);
    _22865 = (object)*(((s1_ptr)_2)->base + 38LL);
    Ref(_22865);
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22865;
    if( _1 != _22865 ){
        DeRef(_1);
    }
    _22865 = NOVALUE;
LC: 
L8: 

    /** c_decl.e:893				if sym[S_ARG_TYPE_NEW] = TYPE_NULL then*/
    _2 = (object)SEQ_PTR(_sym_43699);
    _22866 = (object)*(((s1_ptr)_2)->base + 44LL);
    if (binary_op_a(NOTEQ, _22866, 0LL)){
        _22866 = NOVALUE;
        goto LD; // [293] 310
    }
    _22866 = NOVALUE;

    /** c_decl.e:894					sym[S_ARG_TYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 43LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);
    goto LE; // [307] 325
LD: 

    /** c_decl.e:896					sym[S_ARG_TYPE] = sym[S_ARG_TYPE_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43699);
    _22868 = (object)*(((s1_ptr)_2)->base + 44LL);
    Ref(_22868);
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 43LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22868;
    if( _1 != _22868 ){
        DeRef(_1);
    }
    _22868 = NOVALUE;
LE: 

    /** c_decl.e:898				sym[S_ARG_TYPE_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 44LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** c_decl.e:900				if sym[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL then*/
    _2 = (object)SEQ_PTR(_sym_43699);
    _22869 = (object)*(((s1_ptr)_2)->base + 46LL);
    if (binary_op_a(NOTEQ, _22869, 0LL)){
        _22869 = NOVALUE;
        goto LF; // [345] 362
    }
    _22869 = NOVALUE;

    /** c_decl.e:901					sym[S_ARG_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 45LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);
    goto L10; // [359] 377
LF: 

    /** c_decl.e:903					sym[S_ARG_SEQ_ELEM] = sym[S_ARG_SEQ_ELEM_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43699);
    _22871 = (object)*(((s1_ptr)_2)->base + 46LL);
    Ref(_22871);
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 45LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22871;
    if( _1 != _22871 ){
        DeRef(_1);
    }
    _22871 = NOVALUE;
L10: 

    /** c_decl.e:905				sym[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 46LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** c_decl.e:907				if sym[S_ARG_MIN_NEW] = -NOVALUE or*/
    _2 = (object)SEQ_PTR(_sym_43699);
    _22872 = (object)*(((s1_ptr)_2)->base + 49LL);
    if (IS_ATOM_INT(_36NOVALUE_21293)) {
        if ((uintptr_t)_36NOVALUE_21293 == (uintptr_t)HIGH_BITS){
            _22873 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22873 = - _36NOVALUE_21293;
        }
    }
    else {
        _22873 = unary_op(UMINUS, _36NOVALUE_21293);
    }
    if (IS_ATOM_INT(_22872) && IS_ATOM_INT(_22873)) {
        _22874 = (_22872 == _22873);
    }
    else {
        _22874 = binary_op(EQUALS, _22872, _22873);
    }
    _22872 = NOVALUE;
    DeRef(_22873);
    _22873 = NOVALUE;
    if (IS_ATOM_INT(_22874)) {
        if (_22874 != 0) {
            goto L11; // [404] 425
        }
    }
    else {
        if (DBL_PTR(_22874)->dbl != 0.0) {
            goto L11; // [404] 425
        }
    }
    _2 = (object)SEQ_PTR(_sym_43699);
    _22876 = (object)*(((s1_ptr)_2)->base + 49LL);
    if (IS_ATOM_INT(_22876) && IS_ATOM_INT(_36NOVALUE_21293)) {
        _22877 = (_22876 == _36NOVALUE_21293);
    }
    else {
        _22877 = binary_op(EQUALS, _22876, _36NOVALUE_21293);
    }
    _22876 = NOVALUE;
    if (_22877 == 0) {
        DeRef(_22877);
        _22877 = NOVALUE;
        goto L12; // [421] 448
    }
    else {
        if (!IS_ATOM_INT(_22877) && DBL_PTR(_22877)->dbl == 0.0){
            DeRef(_22877);
            _22877 = NOVALUE;
            goto L12; // [421] 448
        }
        DeRef(_22877);
        _22877 = NOVALUE;
    }
    DeRef(_22877);
    _22877 = NOVALUE;
L11: 

    /** c_decl.e:909					sym[S_ARG_MIN] = MININT*/
    Ref(_36MININT_21263);
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 47LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36MININT_21263;
    DeRef(_1);

    /** c_decl.e:910					sym[S_ARG_MAX] = MAXINT*/
    Ref(_36MAXINT_21262);
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 48LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36MAXINT_21262;
    DeRef(_1);
    goto L13; // [445] 477
L12: 

    /** c_decl.e:912					sym[S_ARG_MIN] = sym[S_ARG_MIN_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43699);
    _22878 = (object)*(((s1_ptr)_2)->base + 49LL);
    Ref(_22878);
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 47LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22878;
    if( _1 != _22878 ){
        DeRef(_1);
    }
    _22878 = NOVALUE;

    /** c_decl.e:913					sym[S_ARG_MAX] = sym[S_ARG_MAX_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43699);
    _22879 = (object)*(((s1_ptr)_2)->base + 50LL);
    Ref(_22879);
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 48LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22879;
    if( _1 != _22879 ){
        DeRef(_1);
    }
    _22879 = NOVALUE;
L13: 

    /** c_decl.e:915				sym[S_ARG_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_36NOVALUE_21293)) {
        if ((uintptr_t)_36NOVALUE_21293 == (uintptr_t)HIGH_BITS){
            _22880 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22880 = - _36NOVALUE_21293;
        }
    }
    else {
        _22880 = unary_op(UMINUS, _36NOVALUE_21293);
    }
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 49LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22880;
    if( _1 != _22880 ){
        DeRef(_1);
    }
    _22880 = NOVALUE;

    /** c_decl.e:917				if sym[S_ARG_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_43699);
    _22881 = (object)*(((s1_ptr)_2)->base + 52LL);
    if (IS_ATOM_INT(_36NOVALUE_21293)) {
        if ((uintptr_t)_36NOVALUE_21293 == (uintptr_t)HIGH_BITS){
            _22882 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22882 = - _36NOVALUE_21293;
        }
    }
    else {
        _22882 = unary_op(UMINUS, _36NOVALUE_21293);
    }
    if (binary_op_a(NOTEQ, _22881, _22882)){
        _22881 = NOVALUE;
        DeRef(_22882);
        _22882 = NOVALUE;
        goto L14; // [503] 520
    }
    _22881 = NOVALUE;
    DeRef(_22882);
    _22882 = NOVALUE;

    /** c_decl.e:918					sym[S_ARG_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21293);
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 51LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21293;
    DeRef(_1);
    goto L15; // [517] 535
L14: 

    /** c_decl.e:920					sym[S_ARG_SEQ_LEN] = sym[S_ARG_SEQ_LEN_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43699);
    _22884 = (object)*(((s1_ptr)_2)->base + 52LL);
    Ref(_22884);
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 51LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22884;
    if( _1 != _22884 ){
        DeRef(_1);
    }
    _22884 = NOVALUE;
L15: 

    /** c_decl.e:922				sym[S_ARG_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_36NOVALUE_21293)) {
        if ((uintptr_t)_36NOVALUE_21293 == (uintptr_t)HIGH_BITS){
            _22885 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22885 = - _36NOVALUE_21293;
        }
    }
    else {
        _22885 = unary_op(UMINUS, _36NOVALUE_21293);
    }
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 52LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22885;
    if( _1 != _22885 ){
        DeRef(_1);
    }
    _22885 = NOVALUE;
L6: 

    /** c_decl.e:925			sym[S_GTYPE_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 38LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** c_decl.e:927			if sym[S_SEQ_ELEM_NEW] = TYPE_NULL then*/
    _2 = (object)SEQ_PTR(_sym_43699);
    _22886 = (object)*(((s1_ptr)_2)->base + 40LL);
    if (binary_op_a(NOTEQ, _22886, 0LL)){
        _22886 = NOVALUE;
        goto L16; // [569] 586
    }
    _22886 = NOVALUE;

    /** c_decl.e:928			   sym[S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);
    goto L17; // [583] 601
L16: 

    /** c_decl.e:930				sym[S_SEQ_ELEM] = sym[S_SEQ_ELEM_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43699);
    _22888 = (object)*(((s1_ptr)_2)->base + 40LL);
    Ref(_22888);
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22888;
    if( _1 != _22888 ){
        DeRef(_1);
    }
    _22888 = NOVALUE;
L17: 

    /** c_decl.e:932			sym[S_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** c_decl.e:934			if sym[S_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_43699);
    _22889 = (object)*(((s1_ptr)_2)->base + 39LL);
    if (IS_ATOM_INT(_36NOVALUE_21293)) {
        if ((uintptr_t)_36NOVALUE_21293 == (uintptr_t)HIGH_BITS){
            _22890 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22890 = - _36NOVALUE_21293;
        }
    }
    else {
        _22890 = unary_op(UMINUS, _36NOVALUE_21293);
    }
    if (binary_op_a(NOTEQ, _22889, _22890)){
        _22889 = NOVALUE;
        DeRef(_22890);
        _22890 = NOVALUE;
        goto L18; // [624] 641
    }
    _22889 = NOVALUE;
    DeRef(_22890);
    _22890 = NOVALUE;

    /** c_decl.e:935				sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21293);
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21293;
    DeRef(_1);
    goto L19; // [638] 656
L18: 

    /** c_decl.e:937				sym[S_SEQ_LEN] = sym[S_SEQ_LEN_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43699);
    _22892 = (object)*(((s1_ptr)_2)->base + 39LL);
    Ref(_22892);
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22892;
    if( _1 != _22892 ){
        DeRef(_1);
    }
    _22892 = NOVALUE;
L19: 

    /** c_decl.e:939			sym[S_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_36NOVALUE_21293)) {
        if ((uintptr_t)_36NOVALUE_21293 == (uintptr_t)HIGH_BITS){
            _22893 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22893 = - _36NOVALUE_21293;
        }
    }
    else {
        _22893 = unary_op(UMINUS, _36NOVALUE_21293);
    }
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22893;
    if( _1 != _22893 ){
        DeRef(_1);
    }
    _22893 = NOVALUE;

    /** c_decl.e:941			if sym[S_TOKEN] != NAMESPACE*/
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!IS_ATOM_INT(_36S_TOKEN_21081)){
        _22894 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    }
    else{
        _22894 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    }
    if (IS_ATOM_INT(_22894)) {
        _22895 = (_22894 != 523LL);
    }
    else {
        _22895 = binary_op(NOTEQ, _22894, 523LL);
    }
    _22894 = NOVALUE;
    if (IS_ATOM_INT(_22895)) {
        if (_22895 == 0) {
            goto L1A; // [683] 794
        }
    }
    else {
        if (DBL_PTR(_22895)->dbl == 0.0) {
            goto L1A; // [683] 794
        }
    }
    _2 = (object)SEQ_PTR(_sym_43699);
    _22897 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (IS_ATOM_INT(_22897)) {
        _22898 = (_22897 != 2LL);
    }
    else {
        _22898 = binary_op(NOTEQ, _22897, 2LL);
    }
    _22897 = NOVALUE;
    if (_22898 == 0) {
        DeRef(_22898);
        _22898 = NOVALUE;
        goto L1A; // [700] 794
    }
    else {
        if (!IS_ATOM_INT(_22898) && DBL_PTR(_22898)->dbl == 0.0){
            DeRef(_22898);
            _22898 = NOVALUE;
            goto L1A; // [700] 794
        }
        DeRef(_22898);
        _22898 = NOVALUE;
    }
    DeRef(_22898);
    _22898 = NOVALUE;

    /** c_decl.e:944				if sym[S_OBJ_MIN_NEW] = -NOVALUE or*/
    _2 = (object)SEQ_PTR(_sym_43699);
    _22899 = (object)*(((s1_ptr)_2)->base + 41LL);
    if (IS_ATOM_INT(_36NOVALUE_21293)) {
        if ((uintptr_t)_36NOVALUE_21293 == (uintptr_t)HIGH_BITS){
            _22900 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22900 = - _36NOVALUE_21293;
        }
    }
    else {
        _22900 = unary_op(UMINUS, _36NOVALUE_21293);
    }
    if (IS_ATOM_INT(_22899) && IS_ATOM_INT(_22900)) {
        _22901 = (_22899 == _22900);
    }
    else {
        _22901 = binary_op(EQUALS, _22899, _22900);
    }
    _22899 = NOVALUE;
    DeRef(_22900);
    _22900 = NOVALUE;
    if (IS_ATOM_INT(_22901)) {
        if (_22901 != 0) {
            goto L1B; // [720] 741
        }
    }
    else {
        if (DBL_PTR(_22901)->dbl != 0.0) {
            goto L1B; // [720] 741
        }
    }
    _2 = (object)SEQ_PTR(_sym_43699);
    _22903 = (object)*(((s1_ptr)_2)->base + 41LL);
    if (IS_ATOM_INT(_22903) && IS_ATOM_INT(_36NOVALUE_21293)) {
        _22904 = (_22903 == _36NOVALUE_21293);
    }
    else {
        _22904 = binary_op(EQUALS, _22903, _36NOVALUE_21293);
    }
    _22903 = NOVALUE;
    if (_22904 == 0) {
        DeRef(_22904);
        _22904 = NOVALUE;
        goto L1C; // [737] 764
    }
    else {
        if (!IS_ATOM_INT(_22904) && DBL_PTR(_22904)->dbl == 0.0){
            DeRef(_22904);
            _22904 = NOVALUE;
            goto L1C; // [737] 764
        }
        DeRef(_22904);
        _22904 = NOVALUE;
    }
    DeRef(_22904);
    _22904 = NOVALUE;
L1B: 

    /** c_decl.e:946					sym[S_OBJ_MIN] = MININT*/
    Ref(_36MININT_21263);
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36MININT_21263;
    DeRef(_1);

    /** c_decl.e:947					sym[S_OBJ_MAX] = MAXINT*/
    Ref(_36MAXINT_21262);
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36MAXINT_21262;
    DeRef(_1);
    goto L1D; // [761] 793
L1C: 

    /** c_decl.e:949					sym[S_OBJ_MIN] = sym[S_OBJ_MIN_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43699);
    _22905 = (object)*(((s1_ptr)_2)->base + 41LL);
    Ref(_22905);
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22905;
    if( _1 != _22905 ){
        DeRef(_1);
    }
    _22905 = NOVALUE;

    /** c_decl.e:950					sym[S_OBJ_MAX] = sym[S_OBJ_MAX_NEW]*/
    _2 = (object)SEQ_PTR(_sym_43699);
    _22906 = (object)*(((s1_ptr)_2)->base + 42LL);
    Ref(_22906);
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22906;
    if( _1 != _22906 ){
        DeRef(_1);
    }
    _22906 = NOVALUE;
L1D: 
L1A: 

    /** c_decl.e:953			sym[S_OBJ_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_36NOVALUE_21293)) {
        if ((uintptr_t)_36NOVALUE_21293 == (uintptr_t)HIGH_BITS){
            _22907 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22907 = - _36NOVALUE_21293;
        }
    }
    else {
        _22907 = unary_op(UMINUS, _36NOVALUE_21293);
    }
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22907;
    if( _1 != _22907 ){
        DeRef(_1);
    }
    _22907 = NOVALUE;

    /** c_decl.e:955			if sym[S_NREFS] = 1 and*/
    _2 = (object)SEQ_PTR(_sym_43699);
    _22908 = (object)*(((s1_ptr)_2)->base + 12LL);
    if (IS_ATOM_INT(_22908)) {
        _22909 = (_22908 == 1LL);
    }
    else {
        _22909 = binary_op(EQUALS, _22908, 1LL);
    }
    _22908 = NOVALUE;
    if (IS_ATOM_INT(_22909)) {
        if (_22909 == 0) {
            goto L1E; // [819] 874
        }
    }
    else {
        if (DBL_PTR(_22909)->dbl == 0.0) {
            goto L1E; // [819] 874
        }
    }
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!IS_ATOM_INT(_36S_TOKEN_21081)){
        _22911 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    }
    else{
        _22911 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    }
    _22912 = find_from(_22911, _38RTN_TOKS_16045, 1LL);
    _22911 = NOVALUE;
    if (_22912 == 0)
    {
        _22912 = NOVALUE;
        goto L1E; // [837] 874
    }
    else{
        _22912 = NOVALUE;
    }

    /** c_decl.e:957				if sym[S_USAGE] != U_DELETED then*/
    _2 = (object)SEQ_PTR(_sym_43699);
    _22913 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (binary_op_a(EQUALS, _22913, 99LL)){
        _22913 = NOVALUE;
        goto L1F; // [850] 873
    }
    _22913 = NOVALUE;

    /** c_decl.e:958					sym[S_USAGE] = U_DELETED*/
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 99LL;
    DeRef(_1);

    /** c_decl.e:959					deleted_routines += 1*/
    _58deleted_routines_43693 = _58deleted_routines_43693 + 1;
L1F: 
L1E: 

    /** c_decl.e:962			sym[S_NREFS] = 0*/
    _2 = (object)SEQ_PTR(_sym_43699);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43699 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** c_decl.e:963			if not equal(symo, sym) then*/
    if (_symo_43700 == _sym_43699)
    _22916 = 1;
    else if (IS_ATOM_INT(_symo_43700) && IS_ATOM_INT(_sym_43699))
    _22916 = 0;
    else
    _22916 = (compare(_symo_43700, _sym_43699) == 0);
    if (_22916 != 0)
    goto L20; // [888] 906
    _22916 = NOVALUE;

    /** c_decl.e:964				SymTab[s] = sym*/
    RefDS(_sym_43699);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _s_43698);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_43699;
    DeRef(_1);

    /** c_decl.e:965				updsym += 1*/
    _updsym_43696 = _updsym_43696 + 1;
L20: 

    /** c_decl.e:967			s = sym[S_NEXT]*/
    _2 = (object)SEQ_PTR(_sym_43699);
    _s_43698 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_43698)){
        _s_43698 = (object)DBL_PTR(_s_43698)->dbl;
    }

    /** c_decl.e:968		end while*/
    goto L1; // [918] 38
L2: 

    /** c_decl.e:971		for i = 1 to length(temp_name_type) do*/
    if (IS_SEQUENCE(_36temp_name_type_21525)){
            _22920 = SEQ_PTR(_36temp_name_type_21525)->length;
    }
    else {
        _22920 = 1;
    }
    {
        object _i_43926;
        _i_43926 = 1LL;
L21: 
        if (_i_43926 > _22920){
            goto L22; // [928] 1061
        }

        /** c_decl.e:972			integer upd = 0*/
        _upd_43929 = 0LL;

        /** c_decl.e:974			if temp_name_type[i][T_GTYPE] != temp_name_type[i][T_GTYPE_NEW] then*/
        _2 = (object)SEQ_PTR(_36temp_name_type_21525);
        _22921 = (object)*(((s1_ptr)_2)->base + _i_43926);
        _2 = (object)SEQ_PTR(_22921);
        _22922 = (object)*(((s1_ptr)_2)->base + 1LL);
        _22921 = NOVALUE;
        _2 = (object)SEQ_PTR(_36temp_name_type_21525);
        _22923 = (object)*(((s1_ptr)_2)->base + _i_43926);
        _2 = (object)SEQ_PTR(_22923);
        _22924 = (object)*(((s1_ptr)_2)->base + 2LL);
        _22923 = NOVALUE;
        if (binary_op_a(EQUALS, _22922, _22924)){
            _22922 = NOVALUE;
            _22924 = NOVALUE;
            goto L23; // [966] 1003
        }
        _22922 = NOVALUE;
        _22924 = NOVALUE;

        /** c_decl.e:975				temp_name_type[i][T_GTYPE] = temp_name_type[i][T_GTYPE_NEW]*/
        _2 = (object)SEQ_PTR(_36temp_name_type_21525);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _36temp_name_type_21525 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_43926 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_36temp_name_type_21525);
        _22928 = (object)*(((s1_ptr)_2)->base + _i_43926);
        _2 = (object)SEQ_PTR(_22928);
        _22929 = (object)*(((s1_ptr)_2)->base + 2LL);
        _22928 = NOVALUE;
        Ref(_22929);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _22929;
        if( _1 != _22929 ){
            DeRef(_1);
        }
        _22929 = NOVALUE;
        _22926 = NOVALUE;

        /** c_decl.e:976				upd = 1*/
        _upd_43929 = 1LL;
L23: 

        /** c_decl.e:978			if temp_name_type[i][T_GTYPE_NEW] != TYPE_NULL then*/
        _2 = (object)SEQ_PTR(_36temp_name_type_21525);
        _22930 = (object)*(((s1_ptr)_2)->base + _i_43926);
        _2 = (object)SEQ_PTR(_22930);
        _22931 = (object)*(((s1_ptr)_2)->base + 2LL);
        _22930 = NOVALUE;
        if (binary_op_a(EQUALS, _22931, 0LL)){
            _22931 = NOVALUE;
            goto L24; // [1019] 1046
        }
        _22931 = NOVALUE;

        /** c_decl.e:979				temp_name_type[i][T_GTYPE_NEW] = TYPE_NULL*/
        _2 = (object)SEQ_PTR(_36temp_name_type_21525);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _36temp_name_type_21525 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_43926 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 2LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0LL;
        DeRef(_1);
        _22933 = NOVALUE;

        /** c_decl.e:980				upd = 1*/
        _upd_43929 = 1LL;
L24: 

        /** c_decl.e:982			updsym += upd*/
        _updsym_43696 = _updsym_43696 + _upd_43929;

        /** c_decl.e:983		end for*/
        _i_43926 = _i_43926 + 1LL;
        goto L21; // [1056] 935
L22: 
        ;
    }

    /** c_decl.e:985		return updsym*/
    DeRef(_sym_43699);
    DeRef(_symo_43700);
    DeRef(_22858);
    _22858 = NOVALUE;
    DeRef(_22855);
    _22855 = NOVALUE;
    DeRef(_22839);
    _22839 = NOVALUE;
    DeRef(_22895);
    _22895 = NOVALUE;
    DeRef(_22847);
    _22847 = NOVALUE;
    DeRef(_22874);
    _22874 = NOVALUE;
    DeRef(_22901);
    _22901 = NOVALUE;
    DeRef(_22850);
    _22850 = NOVALUE;
    DeRef(_22861);
    _22861 = NOVALUE;
    DeRef(_22909);
    _22909 = NOVALUE;
    DeRef(_22864);
    _22864 = NOVALUE;
    return _updsym_43696;
    ;
}


void _58declare_prototype(object _s_43964)
{
    object _ret_type_43965 = NOVALUE;
    object _scope_43976 = NOVALUE;
    object _22953 = NOVALUE;
    object _22952 = NOVALUE;
    object _22950 = NOVALUE;
    object _22949 = NOVALUE;
    object _22948 = NOVALUE;
    object _22947 = NOVALUE;
    object _22945 = NOVALUE;
    object _22944 = NOVALUE;
    object _22943 = NOVALUE;
    object _22942 = NOVALUE;
    object _22941 = NOVALUE;
    object _22939 = NOVALUE;
    object _22938 = NOVALUE;
    object _22936 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:990		if sym_token( s ) = PROC then*/
    _22936 = _54sym_token(_s_43964);
    if (binary_op_a(NOTEQ, _22936, 27LL)){
        DeRef(_22936);
        _22936 = NOVALUE;
        goto L1; // [11] 25
    }
    DeRef(_22936);
    _22936 = NOVALUE;

    /** c_decl.e:991			ret_type = "void "*/
    RefDS(_22777);
    DeRefi(_ret_type_43965);
    _ret_type_43965 = _22777;
    goto L2; // [22] 33
L1: 

    /** c_decl.e:993			ret_type ="object "*/
    RefDS(_22778);
    DeRefi(_ret_type_43965);
    _ret_type_43965 = _22778;
L2: 

    /** c_decl.e:996		c_hputs(ret_type)*/
    RefDS(_ret_type_43965);
    _55c_hputs(_ret_type_43965);

    /** c_decl.e:999		if dll_option and TWINDOWS  then*/
    if (_58dll_option_42563 == 0) {
        goto L3; // [44] 116
    }
    if (_46TWINDOWS_21586 == 0)
    {
        goto L3; // [51] 116
    }
    else{
    }

    /** c_decl.e:1000			integer scope = SymTab[s][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22939 = (object)*(((s1_ptr)_2)->base + _s_43964);
    _2 = (object)SEQ_PTR(_22939);
    _scope_43976 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_scope_43976)){
        _scope_43976 = (object)DBL_PTR(_scope_43976)->dbl;
    }
    _22939 = NOVALUE;

    /** c_decl.e:1001			if (scope = SC_PUBLIC*/
    _22941 = (_scope_43976 == 13LL);
    if (_22941 != 0) {
        _22942 = 1;
        goto L4; // [78] 92
    }
    _22943 = (_scope_43976 == 11LL);
    _22942 = (_22943 != 0);
L4: 
    if (_22942 != 0) {
        DeRef(_22944);
        _22944 = 1;
        goto L5; // [92] 106
    }
    _22945 = (_scope_43976 == 6LL);
    _22944 = (_22945 != 0);
L5: 
    if (_22944 == 0)
    {
        _22944 = NOVALUE;
        goto L6; // [106] 115
    }
    else{
        _22944 = NOVALUE;
    }

    /** c_decl.e:1006				c_hputs("__stdcall ")*/
    RefDS(_22946);
    _55c_hputs(_22946);
L6: 
L3: 

    /** c_decl.e:1010		c_hprintf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22947 = (object)*(((s1_ptr)_2)->base + _s_43964);
    _2 = (object)SEQ_PTR(_22947);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _22948 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _22948 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    _22947 = NOVALUE;
    RefDS(_22116);
    Ref(_22948);
    _55c_hprintf(_22116, _22948);
    _22948 = NOVALUE;

    /** c_decl.e:1011		c_hputs(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22949 = (object)*(((s1_ptr)_2)->base + _s_43964);
    _2 = (object)SEQ_PTR(_22949);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _22950 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _22950 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _22949 = NOVALUE;
    Ref(_22950);
    _55c_hputs(_22950);
    _22950 = NOVALUE;

    /** c_decl.e:1012		c_hputs("(")*/
    RefDS(_22951);
    _55c_hputs(_22951);

    /** c_decl.e:1014		for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22952 = (object)*(((s1_ptr)_2)->base + _s_43964);
    _2 = (object)SEQ_PTR(_22952);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
        _22953 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
    }
    else{
        _22953 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
    }
    _22952 = NOVALUE;
    {
        object _i_44005;
        _i_44005 = 1LL;
L7: 
        if (binary_op_a(GREATER, _i_44005, _22953)){
            goto L8; // [172] 206
        }

        /** c_decl.e:1015			if i = 1 then*/
        if (binary_op_a(NOTEQ, _i_44005, 1LL)){
            goto L9; // [181] 193
        }

        /** c_decl.e:1016				c_hputs("object")*/
        RefDS(_22955);
        _55c_hputs(_22955);
        goto LA; // [190] 199
L9: 

        /** c_decl.e:1018				c_hputs(", object")*/
        RefDS(_22956);
        _55c_hputs(_22956);
LA: 

        /** c_decl.e:1020		end for*/
        _0 = _i_44005;
        if (IS_ATOM_INT(_i_44005)) {
            _i_44005 = _i_44005 + 1LL;
            if ((object)((uintptr_t)_i_44005 +(uintptr_t) HIGH_BITS) >= 0){
                _i_44005 = NewDouble((eudouble)_i_44005);
            }
        }
        else {
            _i_44005 = binary_op_a(PLUS, _i_44005, 1LL);
        }
        DeRef(_0);
        goto L7; // [201] 179
L8: 
        ;
        DeRef(_i_44005);
    }

    /** c_decl.e:1021		c_hputs(");\n")*/
    RefDS(_22297);
    _55c_hputs(_22297);

    /** c_decl.e:1022	end procedure*/
    DeRefi(_ret_type_43965);
    DeRef(_22943);
    _22943 = NOVALUE;
    DeRef(_22941);
    _22941 = NOVALUE;
    _22953 = NOVALUE;
    DeRef(_22945);
    _22945 = NOVALUE;
    return;
    ;
}


void _58add_to_routine_list(object _s_44021, object _seq_num_44022, object _first_44023)
{
    object _p_44098 = NOVALUE;
    object _23002 = NOVALUE;
    object _23000 = NOVALUE;
    object _22998 = NOVALUE;
    object _22996 = NOVALUE;
    object _22994 = NOVALUE;
    object _22993 = NOVALUE;
    object _22992 = NOVALUE;
    object _22990 = NOVALUE;
    object _22988 = NOVALUE;
    object _22986 = NOVALUE;
    object _22985 = NOVALUE;
    object _22983 = NOVALUE;
    object _22982 = NOVALUE;
    object _22978 = NOVALUE;
    object _22977 = NOVALUE;
    object _22976 = NOVALUE;
    object _22975 = NOVALUE;
    object _22974 = NOVALUE;
    object _22973 = NOVALUE;
    object _22972 = NOVALUE;
    object _22971 = NOVALUE;
    object _22970 = NOVALUE;
    object _22969 = NOVALUE;
    object _22967 = NOVALUE;
    object _22966 = NOVALUE;
    object _22965 = NOVALUE;
    object _22964 = NOVALUE;
    object _22961 = NOVALUE;
    object _22960 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** c_decl.e:1025		if not first then*/
    if (_first_44023 != 0)
    goto L1; // [9] 18

    /** c_decl.e:1026			c_puts(",\n")*/
    RefDS(_22958);
    _55c_puts(_22958);
L1: 

    /** c_decl.e:1029		c_puts("  {\"")*/
    RefDS(_22959);
    _55c_puts(_22959);

    /** c_decl.e:1031		c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22960 = (object)*(((s1_ptr)_2)->base + _s_44021);
    _2 = (object)SEQ_PTR(_22960);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _22961 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _22961 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _22960 = NOVALUE;
    Ref(_22961);
    _55c_puts(_22961);
    _22961 = NOVALUE;

    /** c_decl.e:1032		c_puts("\", ")*/
    RefDS(_22962);
    _55c_puts(_22962);

    /** c_decl.e:1033		c_puts("(object (*)())")*/
    RefDS(_22963);
    _55c_puts(_22963);

    /** c_decl.e:1034		c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22964 = (object)*(((s1_ptr)_2)->base + _s_44021);
    _2 = (object)SEQ_PTR(_22964);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _22965 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _22965 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    _22964 = NOVALUE;
    RefDS(_22116);
    Ref(_22965);
    _55c_printf(_22116, _22965);
    _22965 = NOVALUE;

    /** c_decl.e:1035		c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22966 = (object)*(((s1_ptr)_2)->base + _s_44021);
    _2 = (object)SEQ_PTR(_22966);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _22967 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _22967 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _22966 = NOVALUE;
    Ref(_22967);
    _55c_puts(_22967);
    _22967 = NOVALUE;

    /** c_decl.e:1036		c_printf(", %d", seq_num)*/
    RefDS(_22968);
    _55c_printf(_22968, _seq_num_44022);

    /** c_decl.e:1037		c_printf(", %d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22969 = (object)*(((s1_ptr)_2)->base + _s_44021);
    _2 = (object)SEQ_PTR(_22969);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _22970 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _22970 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    _22969 = NOVALUE;
    RefDS(_22968);
    Ref(_22970);
    _55c_printf(_22968, _22970);
    _22970 = NOVALUE;

    /** c_decl.e:1038		c_printf(", %d", SymTab[s][S_NUM_ARGS])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22971 = (object)*(((s1_ptr)_2)->base + _s_44021);
    _2 = (object)SEQ_PTR(_22971);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
        _22972 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
    }
    else{
        _22972 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
    }
    _22971 = NOVALUE;
    RefDS(_22968);
    Ref(_22972);
    _55c_printf(_22968, _22972);
    _22972 = NOVALUE;

    /** c_decl.e:1040		if TWINDOWS and dll_option and find( SymTab[s][S_SCOPE], { SC_GLOBAL, SC_EXPORT, SC_PUBLIC} ) then*/
    if (_46TWINDOWS_21586 == 0) {
        _22973 = 0;
        goto L2; // [131] 141
    }
    _22973 = (_58dll_option_42563 != 0);
L2: 
    if (_22973 == 0) {
        goto L3; // [141] 186
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22975 = (object)*(((s1_ptr)_2)->base + _s_44021);
    _2 = (object)SEQ_PTR(_22975);
    _22976 = (object)*(((s1_ptr)_2)->base + 4LL);
    _22975 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 6LL;
    ((intptr_t*)_2)[2] = 11LL;
    ((intptr_t*)_2)[3] = 13LL;
    _22977 = MAKE_SEQ(_1);
    _22978 = find_from(_22976, _22977, 1LL);
    _22976 = NOVALUE;
    DeRefDS(_22977);
    _22977 = NOVALUE;
    if (_22978 == 0)
    {
        _22978 = NOVALUE;
        goto L3; // [175] 186
    }
    else{
        _22978 = NOVALUE;
    }

    /** c_decl.e:1041			c_puts(", 1")  -- must call with __stdcall convention*/
    RefDS(_22979);
    _55c_puts(_22979);
    goto L4; // [183] 192
L3: 

    /** c_decl.e:1043			c_puts(", 0")  -- default: call with normal or __cdecl convention*/
    RefDS(_22980);
    _55c_puts(_22980);
L4: 

    /** c_decl.e:1046		c_printf(", %d, 0", SymTab[s][S_SCOPE] )*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22982 = (object)*(((s1_ptr)_2)->base + _s_44021);
    _2 = (object)SEQ_PTR(_22982);
    _22983 = (object)*(((s1_ptr)_2)->base + 4LL);
    _22982 = NOVALUE;
    RefDS(_22981);
    Ref(_22983);
    _55c_printf(_22981, _22983);
    _22983 = NOVALUE;

    /** c_decl.e:1047		c_puts("}")*/
    RefDS(_22984);
    _55c_puts(_22984);

    /** c_decl.e:1049		if SymTab[s][S_NREFS] < 2 then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22985 = (object)*(((s1_ptr)_2)->base + _s_44021);
    _2 = (object)SEQ_PTR(_22985);
    _22986 = (object)*(((s1_ptr)_2)->base + 12LL);
    _22985 = NOVALUE;
    if (binary_op_a(GREATEREQ, _22986, 2LL)){
        _22986 = NOVALUE;
        goto L5; // [229] 249
    }
    _22986 = NOVALUE;

    /** c_decl.e:1050			SymTab[s][S_NREFS] = 2 --s->nrefs++*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_44021 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _22988 = NOVALUE;
L5: 

    /** c_decl.e:1055		symtab_index p = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22990 = (object)*(((s1_ptr)_2)->base + _s_44021);
    _2 = (object)SEQ_PTR(_22990);
    _p_44098 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_p_44098)){
        _p_44098 = (object)DBL_PTR(_p_44098)->dbl;
    }
    _22990 = NOVALUE;

    /** c_decl.e:1056		for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _22992 = (object)*(((s1_ptr)_2)->base + _s_44021);
    _2 = (object)SEQ_PTR(_22992);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
        _22993 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
    }
    else{
        _22993 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
    }
    _22992 = NOVALUE;
    {
        object _i_44104;
        _i_44104 = 1LL;
L6: 
        if (binary_op_a(GREATER, _i_44104, _22993)){
            goto L7; // [279] 377
        }

        /** c_decl.e:1057			SymTab[p][S_ARG_SEQ_ELEM_NEW] = TYPE_OBJECT*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_44098 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 46LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 16LL;
        DeRef(_1);
        _22994 = NOVALUE;

        /** c_decl.e:1058			SymTab[p][S_ARG_TYPE_NEW] = TYPE_OBJECT*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_44098 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 44LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 16LL;
        DeRef(_1);
        _22996 = NOVALUE;

        /** c_decl.e:1059			SymTab[p][S_ARG_MIN_NEW] = NOVALUE*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_44098 + ((s1_ptr)_2)->base);
        Ref(_36NOVALUE_21293);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 49LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _36NOVALUE_21293;
        DeRef(_1);
        _22998 = NOVALUE;

        /** c_decl.e:1060			SymTab[p][S_ARG_SEQ_LEN_NEW] = NOVALUE*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_44098 + ((s1_ptr)_2)->base);
        Ref(_36NOVALUE_21293);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 52LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _36NOVALUE_21293;
        DeRef(_1);
        _23000 = NOVALUE;

        /** c_decl.e:1061			p = SymTab[p][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _23002 = (object)*(((s1_ptr)_2)->base + _p_44098);
        _2 = (object)SEQ_PTR(_23002);
        _p_44098 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_p_44098)){
            _p_44098 = (object)DBL_PTR(_p_44098)->dbl;
        }
        _23002 = NOVALUE;

        /** c_decl.e:1062		end for*/
        _0 = _i_44104;
        if (IS_ATOM_INT(_i_44104)) {
            _i_44104 = _i_44104 + 1LL;
            if ((object)((uintptr_t)_i_44104 +(uintptr_t) HIGH_BITS) >= 0){
                _i_44104 = NewDouble((eudouble)_i_44104);
            }
        }
        else {
            _i_44104 = binary_op_a(PLUS, _i_44104, 1LL);
        }
        DeRef(_0);
        goto L6; // [372] 286
L7: 
        ;
        DeRef(_i_44104);
    }

    /** c_decl.e:1063	end procedure*/
    _22993 = NOVALUE;
    return;
    ;
}


void _58DeclareRoutineList()
{
    object _s_44136 = NOVALUE;
    object _first_44137 = NOVALUE;
    object _seq_num_44138 = NOVALUE;
    object _these_routines_44146 = NOVALUE;
    object _these_routines_44168 = NOVALUE;
    object _23018 = NOVALUE;
    object _23017 = NOVALUE;
    object _23015 = NOVALUE;
    object _23013 = NOVALUE;
    object _23010 = NOVALUE;
    object _23009 = NOVALUE;
    object _23007 = NOVALUE;
    object _23005 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1069		integer first, seq_num*/

    /** c_decl.e:1071		c_hputs("extern struct routine_list _00[];\n")*/
    RefDS(_23004);
    _55c_hputs(_23004);

    /** c_decl.e:1073		check_file_routines()*/
    _58check_file_routines();

    /** c_decl.e:1074		for f = 1 to length( file_routines ) do*/
    if (IS_SEQUENCE(_58file_routines_44725)){
            _23005 = SEQ_PTR(_58file_routines_44725)->length;
    }
    else {
        _23005 = 1;
    }
    {
        object _f_44143;
        _f_44143 = 1LL;
L1: 
        if (_f_44143 > _23005){
            goto L2; // [19] 98
        }

        /** c_decl.e:1075			sequence these_routines = file_routines[f]*/
        DeRef(_these_routines_44146);
        _2 = (object)SEQ_PTR(_58file_routines_44725);
        _these_routines_44146 = (object)*(((s1_ptr)_2)->base + _f_44143);
        Ref(_these_routines_44146);

        /** c_decl.e:1076			for r = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_44146)){
                _23007 = SEQ_PTR(_these_routines_44146)->length;
        }
        else {
            _23007 = 1;
        }
        {
            object _r_44150;
            _r_44150 = 1LL;
L3: 
            if (_r_44150 > _23007){
                goto L4; // [41] 89
            }

            /** c_decl.e:1077				s = these_routines[r]*/
            _2 = (object)SEQ_PTR(_these_routines_44146);
            _s_44136 = (object)*(((s1_ptr)_2)->base + _r_44150);
            if (!IS_ATOM_INT(_s_44136)){
                _s_44136 = (object)DBL_PTR(_s_44136)->dbl;
            }

            /** c_decl.e:1078				if SymTab[s][S_USAGE] != U_DELETED then*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23009 = (object)*(((s1_ptr)_2)->base + _s_44136);
            _2 = (object)SEQ_PTR(_23009);
            _23010 = (object)*(((s1_ptr)_2)->base + 5LL);
            _23009 = NOVALUE;
            if (binary_op_a(EQUALS, _23010, 99LL)){
                _23010 = NOVALUE;
                goto L5; // [72] 82
            }
            _23010 = NOVALUE;

            /** c_decl.e:1080					declare_prototype( s )*/
            _58declare_prototype(_s_44136);
L5: 

            /** c_decl.e:1083			end for*/
            _r_44150 = _r_44150 + 1LL;
            goto L3; // [84] 48
L4: 
            ;
        }
        DeRef(_these_routines_44146);
        _these_routines_44146 = NOVALUE;

        /** c_decl.e:1084		end for*/
        _f_44143 = _f_44143 + 1LL;
        goto L1; // [93] 26
L2: 
        ;
    }

    /** c_decl.e:1085		c_puts("\n")*/
    RefDS(_22188);
    _55c_puts(_22188);

    /** c_decl.e:1088		seq_num = 0*/
    _seq_num_44138 = 0LL;

    /** c_decl.e:1089		first = TRUE*/
    _first_44137 = _13TRUE_452;

    /** c_decl.e:1090		c_puts("struct routine_list _00[] = {\n")*/
    RefDS(_23012);
    _55c_puts(_23012);

    /** c_decl.e:1092		for f = 1 to length( file_routines ) do*/
    if (IS_SEQUENCE(_58file_routines_44725)){
            _23013 = SEQ_PTR(_58file_routines_44725)->length;
    }
    else {
        _23013 = 1;
    }
    {
        object _f_44165;
        _f_44165 = 1LL;
L6: 
        if (_f_44165 > _23013){
            goto L7; // [129] 222
        }

        /** c_decl.e:1093			sequence these_routines = file_routines[f]*/
        DeRef(_these_routines_44168);
        _2 = (object)SEQ_PTR(_58file_routines_44725);
        _these_routines_44168 = (object)*(((s1_ptr)_2)->base + _f_44165);
        Ref(_these_routines_44168);

        /** c_decl.e:1094			for r = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_44168)){
                _23015 = SEQ_PTR(_these_routines_44168)->length;
        }
        else {
            _23015 = 1;
        }
        {
            object _r_44172;
            _r_44172 = 1LL;
L8: 
            if (_r_44172 > _23015){
                goto L9; // [151] 213
            }

            /** c_decl.e:1095				s = these_routines[r]*/
            _2 = (object)SEQ_PTR(_these_routines_44168);
            _s_44136 = (object)*(((s1_ptr)_2)->base + _r_44172);
            if (!IS_ATOM_INT(_s_44136)){
                _s_44136 = (object)DBL_PTR(_s_44136)->dbl;
            }

            /** c_decl.e:1096				if SymTab[s][S_RI_TARGET] then*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23017 = (object)*(((s1_ptr)_2)->base + _s_44136);
            _2 = (object)SEQ_PTR(_23017);
            _23018 = (object)*(((s1_ptr)_2)->base + 53LL);
            _23017 = NOVALUE;
            if (_23018 == 0) {
                _23018 = NOVALUE;
                goto LA; // [180] 200
            }
            else {
                if (!IS_ATOM_INT(_23018) && DBL_PTR(_23018)->dbl == 0.0){
                    _23018 = NOVALUE;
                    goto LA; // [180] 200
                }
                _23018 = NOVALUE;
            }
            _23018 = NOVALUE;

            /** c_decl.e:1098					add_to_routine_list( s, seq_num, first )*/
            _58add_to_routine_list(_s_44136, _seq_num_44138, _first_44137);

            /** c_decl.e:1099					first = FALSE*/
            _first_44137 = _13FALSE_450;
LA: 

            /** c_decl.e:1102				seq_num += 1*/
            _seq_num_44138 = _seq_num_44138 + 1;

            /** c_decl.e:1103			end for*/
            _r_44172 = _r_44172 + 1LL;
            goto L8; // [208] 158
L9: 
            ;
        }
        DeRef(_these_routines_44168);
        _these_routines_44168 = NOVALUE;

        /** c_decl.e:1104		end for*/
        _f_44165 = _f_44165 + 1LL;
        goto L6; // [217] 136
L7: 
        ;
    }

    /** c_decl.e:1105		if not first then*/
    if (_first_44137 != 0)
    goto LB; // [224] 233

    /** c_decl.e:1106			c_puts(",\n")*/
    RefDS(_22958);
    _55c_puts(_22958);
LB: 

    /** c_decl.e:1108		c_puts("  {\"\", 0, 999999999, 0, 0, 0, 0}\n};\n\n")  -- end marker*/
    RefDS(_23021);
    _55c_puts(_23021);

    /** c_decl.e:1110		c_hputs("extern char ** _02;\n")*/
    RefDS(_23022);
    _55c_hputs(_23022);

    /** c_decl.e:1111		c_puts("char ** _02;\n")*/
    RefDS(_23023);
    _55c_puts(_23023);

    /** c_decl.e:1113		c_hputs("extern object _0switches;\n")*/
    RefDS(_23024);
    _55c_hputs(_23024);

    /** c_decl.e:1114		c_puts("object _0switches;\n")*/
    RefDS(_23025);
    _55c_puts(_23025);

    /** c_decl.e:1115	end procedure*/
    return;
    ;
}


void _58DeclareNameSpaceList()
{
    object _s_44198 = NOVALUE;
    object _first_44199 = NOVALUE;
    object _seq_num_44200 = NOVALUE;
    object _23045 = NOVALUE;
    object _23043 = NOVALUE;
    object _23042 = NOVALUE;
    object _23041 = NOVALUE;
    object _23040 = NOVALUE;
    object _23038 = NOVALUE;
    object _23037 = NOVALUE;
    object _23034 = NOVALUE;
    object _23033 = NOVALUE;
    object _23032 = NOVALUE;
    object _23031 = NOVALUE;
    object _23030 = NOVALUE;
    object _23028 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1121		integer first, seq_num*/

    /** c_decl.e:1123		c_hputs("extern struct ns_list _01[];\n")*/
    RefDS(_23026);
    _55c_hputs(_23026);

    /** c_decl.e:1124		c_puts("struct ns_list _01[] = {\n")*/
    RefDS(_23027);
    _55c_puts(_23027);

    /** c_decl.e:1126		seq_num = 0*/
    _seq_num_44200 = 0LL;

    /** c_decl.e:1127		first = TRUE*/
    _first_44199 = _13TRUE_452;

    /** c_decl.e:1129		s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _23028 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21446);
    _2 = (object)SEQ_PTR(_23028);
    _s_44198 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_44198)){
        _s_44198 = (object)DBL_PTR(_s_44198)->dbl;
    }
    _23028 = NOVALUE;

    /** c_decl.e:1130		while s do*/
L1: 
    if (_s_44198 == 0)
    {
        goto L2; // [50] 215
    }
    else{
    }

    /** c_decl.e:1131			if find(SymTab[s][S_TOKEN], NAMED_TOKS) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _23030 = (object)*(((s1_ptr)_2)->base + _s_44198);
    _2 = (object)SEQ_PTR(_23030);
    if (!IS_ATOM_INT(_36S_TOKEN_21081)){
        _23031 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    }
    else{
        _23031 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    }
    _23030 = NOVALUE;
    _23032 = find_from(_23031, _38NAMED_TOKS_16047, 1LL);
    _23031 = NOVALUE;
    if (_23032 == 0)
    {
        _23032 = NOVALUE;
        goto L3; // [74] 194
    }
    else{
        _23032 = NOVALUE;
    }

    /** c_decl.e:1132				if SymTab[s][S_TOKEN] = NAMESPACE then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _23033 = (object)*(((s1_ptr)_2)->base + _s_44198);
    _2 = (object)SEQ_PTR(_23033);
    if (!IS_ATOM_INT(_36S_TOKEN_21081)){
        _23034 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    }
    else{
        _23034 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    }
    _23033 = NOVALUE;
    if (binary_op_a(NOTEQ, _23034, 523LL)){
        _23034 = NOVALUE;
        goto L4; // [93] 187
    }
    _23034 = NOVALUE;

    /** c_decl.e:1133					if not first then*/
    if (_first_44199 != 0)
    goto L5; // [99] 108

    /** c_decl.e:1134						c_puts(",\n")*/
    RefDS(_22958);
    _55c_puts(_22958);
L5: 

    /** c_decl.e:1136					first = FALSE*/
    _first_44199 = _13FALSE_450;

    /** c_decl.e:1138					c_puts("  {\"")*/
    RefDS(_22959);
    _55c_puts(_22959);

    /** c_decl.e:1139					c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _23037 = (object)*(((s1_ptr)_2)->base + _s_44198);
    _2 = (object)SEQ_PTR(_23037);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _23038 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _23038 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _23037 = NOVALUE;
    Ref(_23038);
    _55c_puts(_23038);
    _23038 = NOVALUE;

    /** c_decl.e:1140					c_printf("\", %d", SymTab[s][S_OBJ])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _23040 = (object)*(((s1_ptr)_2)->base + _s_44198);
    _2 = (object)SEQ_PTR(_23040);
    _23041 = (object)*(((s1_ptr)_2)->base + 1LL);
    _23040 = NOVALUE;
    RefDS(_23039);
    Ref(_23041);
    _55c_printf(_23039, _23041);
    _23041 = NOVALUE;

    /** c_decl.e:1141					c_printf(", %d", seq_num)*/
    RefDS(_22968);
    _55c_printf(_22968, _seq_num_44200);

    /** c_decl.e:1142					c_printf(", %d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _23042 = (object)*(((s1_ptr)_2)->base + _s_44198);
    _2 = (object)SEQ_PTR(_23042);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _23043 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _23043 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    _23042 = NOVALUE;
    RefDS(_22968);
    Ref(_23043);
    _55c_printf(_22968, _23043);
    _23043 = NOVALUE;

    /** c_decl.e:1144					c_puts("}")*/
    RefDS(_22984);
    _55c_puts(_22984);
L4: 

    /** c_decl.e:1146				seq_num += 1*/
    _seq_num_44200 = _seq_num_44200 + 1;
L3: 

    /** c_decl.e:1148			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _23045 = (object)*(((s1_ptr)_2)->base + _s_44198);
    _2 = (object)SEQ_PTR(_23045);
    _s_44198 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_44198)){
        _s_44198 = (object)DBL_PTR(_s_44198)->dbl;
    }
    _23045 = NOVALUE;

    /** c_decl.e:1149		end while*/
    goto L1; // [212] 50
L2: 

    /** c_decl.e:1150		if not first then*/
    if (_first_44199 != 0)
    goto L6; // [217] 226

    /** c_decl.e:1151			c_puts(",\n")*/
    RefDS(_22958);
    _55c_puts(_22958);
L6: 

    /** c_decl.e:1153		c_puts("  {\"\", 0, 999999999, 0}\n};\n\n")  -- end marker*/
    RefDS(_23048);
    _55c_puts(_23048);

    /** c_decl.e:1154	end procedure*/
    return;
    ;
}


object _58is_exported(object _s_44262)
{
    object _eentry_44263 = NOVALUE;
    object _scope_44266 = NOVALUE;
    object _23063 = NOVALUE;
    object _23062 = NOVALUE;
    object _23061 = NOVALUE;
    object _23060 = NOVALUE;
    object _23059 = NOVALUE;
    object _23058 = NOVALUE;
    object _23057 = NOVALUE;
    object _23056 = NOVALUE;
    object _23055 = NOVALUE;
    object _23054 = NOVALUE;
    object _23053 = NOVALUE;
    object _23051 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_44262)) {
        _1 = (object)(DBL_PTR(_s_44262)->dbl);
        DeRefDS(_s_44262);
        _s_44262 = _1;
    }

    /** c_decl.e:1159		sequence eentry = SymTab[s]*/
    DeRef(_eentry_44263);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _eentry_44263 = (object)*(((s1_ptr)_2)->base + _s_44262);
    Ref(_eentry_44263);

    /** c_decl.e:1160		integer scope = eentry[S_SCOPE]*/
    _2 = (object)SEQ_PTR(_eentry_44263);
    _scope_44266 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_scope_44266))
    _scope_44266 = (object)DBL_PTR(_scope_44266)->dbl;

    /** c_decl.e:1162		if eentry[S_MODE] = M_NORMAL then*/
    _2 = (object)SEQ_PTR(_eentry_44263);
    _23051 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (binary_op_a(NOTEQ, _23051, 1LL)){
        _23051 = NOVALUE;
        goto L1; // [31] 125
    }
    _23051 = NOVALUE;

    /** c_decl.e:1163			if eentry[S_FILE_NO] = 1 and find(scope, { SC_EXPORT, SC_PUBLIC, SC_GLOBAL }) then*/
    _2 = (object)SEQ_PTR(_eentry_44263);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _23053 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _23053 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    if (IS_ATOM_INT(_23053)) {
        _23054 = (_23053 == 1LL);
    }
    else {
        _23054 = binary_op(EQUALS, _23053, 1LL);
    }
    _23053 = NOVALUE;
    if (IS_ATOM_INT(_23054)) {
        if (_23054 == 0) {
            goto L2; // [47] 79
        }
    }
    else {
        if (DBL_PTR(_23054)->dbl == 0.0) {
            goto L2; // [47] 79
        }
    }
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 11LL;
    ((intptr_t*)_2)[2] = 13LL;
    ((intptr_t*)_2)[3] = 6LL;
    _23056 = MAKE_SEQ(_1);
    _23057 = find_from(_scope_44266, _23056, 1LL);
    DeRefDS(_23056);
    _23056 = NOVALUE;
    if (_23057 == 0)
    {
        _23057 = NOVALUE;
        goto L2; // [69] 79
    }
    else{
        _23057 = NOVALUE;
    }

    /** c_decl.e:1164				return 1*/
    DeRef(_eentry_44263);
    DeRef(_23054);
    _23054 = NOVALUE;
    return 1LL;
L2: 

    /** c_decl.e:1167			if scope = SC_PUBLIC and*/
    _23058 = (_scope_44266 == 13LL);
    if (_23058 == 0) {
        goto L3; // [87] 124
    }
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    _23060 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_eentry_44263);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _23061 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _23061 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    _2 = (object)SEQ_PTR(_23060);
    if (!IS_ATOM_INT(_23061)){
        _23062 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_23061)->dbl));
    }
    else{
        _23062 = (object)*(((s1_ptr)_2)->base + _23061);
    }
    _23060 = NOVALUE;
    if (IS_ATOM_INT(_23062)) {
        {uintptr_t tu;
             tu = (uintptr_t)_23062 & (uintptr_t)4LL;
             _23063 = MAKE_UINT(tu);
        }
    }
    else {
        _23063 = binary_op(AND_BITS, _23062, 4LL);
    }
    _23062 = NOVALUE;
    if (_23063 == 0) {
        DeRef(_23063);
        _23063 = NOVALUE;
        goto L3; // [114] 124
    }
    else {
        if (!IS_ATOM_INT(_23063) && DBL_PTR(_23063)->dbl == 0.0){
            DeRef(_23063);
            _23063 = NOVALUE;
            goto L3; // [114] 124
        }
        DeRef(_23063);
        _23063 = NOVALUE;
    }
    DeRef(_23063);
    _23063 = NOVALUE;

    /** c_decl.e:1170				return 1*/
    DeRef(_eentry_44263);
    _23061 = NOVALUE;
    DeRef(_23058);
    _23058 = NOVALUE;
    DeRef(_23054);
    _23054 = NOVALUE;
    return 1LL;
L3: 
L1: 

    /** c_decl.e:1174		return 0*/
    DeRef(_eentry_44263);
    _23061 = NOVALUE;
    DeRef(_23058);
    _23058 = NOVALUE;
    DeRef(_23054);
    _23054 = NOVALUE;
    return 0LL;
    ;
}


void _58version()
{
    object _23097 = NOVALUE;
    object _23096 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1207		c_puts("// Euphoria To C version " & version_string() & "\n")*/
    _23096 = _33version_string(0LL);
    {
        object concat_list[3];

        concat_list[0] = _22188;
        concat_list[1] = _23096;
        concat_list[2] = _23095;
        Concat_N((object_ptr)&_23097, concat_list, 3);
    }
    DeRef(_23096);
    _23096 = NOVALUE;
    _55c_puts(_23097);
    _23097 = NOVALUE;

    /** c_decl.e:1208	end procedure*/
    return;
    ;
}


void _58new_c_file(object _name_44370)
{
    object _23100 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1213		cfile_size = 0*/
    _36cfile_size_21522 = 0LL;

    /** c_decl.e:1216		if LAST_PASS = FALSE then*/
    if (_58LAST_PASS_42550 != _13FALSE_450)
    goto L1; // [16] 26

    /** c_decl.e:1217			return*/
    DeRefDS(_name_44370);
    return;
L1: 

    /** c_decl.e:1220		write_checksum( c_code )*/
    _56write_checksum(_55c_code_46623);

    /** c_decl.e:1221		close(c_code)*/
    EClose(_55c_code_46623);

    /** c_decl.e:1223		c_code = open(output_dir & name & ".c", "w")*/
    {
        object concat_list[3];

        concat_list[0] = _23099;
        concat_list[1] = _name_44370;
        concat_list[2] = _58output_dir_42577;
        Concat_N((object_ptr)&_23100, concat_list, 3);
    }
    _55c_code_46623 = EOpen(_23100, _22129, 0LL);
    DeRefDS(_23100);
    _23100 = NOVALUE;

    /** c_decl.e:1224		if c_code = -1 then*/
    if (_55c_code_46623 != -1LL)
    goto L2; // [60] 74

    /** c_decl.e:1225			CompileErr(COULDNT_OPEN_C_FILE_FOR_OUTPUT)*/
    RefDS(_21993);
    _50CompileErr(57LL, _21993, 0LL);
L2: 

    /** c_decl.e:1228		cfile_count += 1*/
    _36cfile_count_21521 = _36cfile_count_21521 + 1LL;

    /** c_decl.e:1229		version()*/
    _58version();

    /** c_decl.e:1231		c_puts("#include \"include/euphoria.h\"\n")*/
    RefDS(_22134);
    _55c_puts(_22134);

    /** c_decl.e:1233		c_puts("#include \"main-.h\"\n\n")*/
    RefDS(_22135);
    _55c_puts(_22135);

    /** c_decl.e:1235		if not TUNIX then*/
    if (_46TUNIX_21590 != 0)
    goto L3; // [102] 114

    /** c_decl.e:1236			name = lower(name)  -- for faster compare later*/
    RefDS(_name_44370);
    _0 = _name_44370;
    _name_44370 = _14lower(_name_44370);
    DeRefDS(_0);
L3: 

    /** c_decl.e:1238	end procedure*/
    DeRefDS(_name_44370);
    return;
    ;
}


object _58unique_c_name(object _name_44400)
{
    object _i_44401 = NOVALUE;
    object _compare_name_44402 = NOVALUE;
    object _next_fc_44403 = NOVALUE;
    object _23116 = NOVALUE;
    object _23114 = NOVALUE;
    object _23113 = NOVALUE;
    object _23112 = NOVALUE;
    object _23110 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1253		compare_name = name & ".c"*/
    Concat((object_ptr)&_compare_name_44402, _name_44400, _23099);

    /** c_decl.e:1254		if not TUNIX then*/
    if (_46TUNIX_21590 != 0)
    goto L1; // [13] 25

    /** c_decl.e:1255			compare_name = lower(compare_name)*/
    RefDS(_compare_name_44402);
    _0 = _compare_name_44402;
    _compare_name_44402 = _14lower(_compare_name_44402);
    DeRefDS(_0);
L1: 

    /** c_decl.e:1258		next_fc = 1*/
    _next_fc_44403 = 1LL;

    /** c_decl.e:1259		i = 1*/
    _i_44401 = 1LL;

    /** c_decl.e:1261		while i <= length(generated_files) do*/
L2: 
    if (IS_SEQUENCE(_58generated_files_42567)){
            _23110 = SEQ_PTR(_58generated_files_42567)->length;
    }
    else {
        _23110 = 1;
    }
    if (_i_44401 > _23110)
    goto L3; // [45] 141

    /** c_decl.e:1263			if equal(generated_files[i], compare_name) then*/
    _2 = (object)SEQ_PTR(_58generated_files_42567);
    _23112 = (object)*(((s1_ptr)_2)->base + _i_44401);
    if (_23112 == _compare_name_44402)
    _23113 = 1;
    else if (IS_ATOM_INT(_23112) && IS_ATOM_INT(_compare_name_44402))
    _23113 = 0;
    else
    _23113 = (compare(_23112, _compare_name_44402) == 0);
    _23112 = NOVALUE;
    if (_23113 == 0)
    {
        _23113 = NOVALUE;
        goto L4; // [61] 129
    }
    else{
        _23113 = NOVALUE;
    }

    /** c_decl.e:1265				if next_fc > length(file_chars) then*/
    if (IS_SEQUENCE(_58file_chars_44396)){
            _23114 = SEQ_PTR(_58file_chars_44396)->length;
    }
    else {
        _23114 = 1;
    }
    if (_next_fc_44403 <= _23114)
    goto L5; // [69] 83

    /** c_decl.e:1266					CompileErr(SORRY_TOO_MANY_C_FILES_WITH_THE_SAME_BASE_NAME)*/
    RefDS(_21993);
    _50CompileErr(140LL, _21993, 0LL);
L5: 

    /** c_decl.e:1269				name[1] = file_chars[next_fc]*/
    _2 = (object)SEQ_PTR(_58file_chars_44396);
    _23116 = (object)*(((s1_ptr)_2)->base + _next_fc_44403);
    Ref(_23116);
    _2 = (object)SEQ_PTR(_name_44400);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _name_44400 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23116;
    if( _1 != _23116 ){
        DeRef(_1);
    }
    _23116 = NOVALUE;

    /** c_decl.e:1270				compare_name = name & ".c"*/
    Concat((object_ptr)&_compare_name_44402, _name_44400, _23099);

    /** c_decl.e:1271				if not TUNIX then*/
    if (_46TUNIX_21590 != 0)
    goto L6; // [103] 115

    /** c_decl.e:1272					compare_name = lower(compare_name)*/
    RefDS(_compare_name_44402);
    _0 = _compare_name_44402;
    _compare_name_44402 = _14lower(_compare_name_44402);
    DeRefDS(_0);
L6: 

    /** c_decl.e:1275				next_fc += 1*/
    _next_fc_44403 = _next_fc_44403 + 1;

    /** c_decl.e:1276				i = 1 -- start over and compare again*/
    _i_44401 = 1LL;
    goto L2; // [126] 40
L4: 

    /** c_decl.e:1279				i += 1*/
    _i_44401 = _i_44401 + 1;

    /** c_decl.e:1281		end while*/
    goto L2; // [138] 40
L3: 

    /** c_decl.e:1283		return name*/
    DeRef(_compare_name_44402);
    return _name_44400;
    ;
}


object _58is_file_newer(object _f1_44433, object _f2_44434)
{
    object _d1_44435 = NOVALUE;
    object _d2_44438 = NOVALUE;
    object _diff_2__tmp_at42_44449 = NOVALUE;
    object _diff_1__tmp_at42_44448 = NOVALUE;
    object _diff_inlined_diff_at_42_44447 = NOVALUE;
    object _23126 = NOVALUE;
    object _23124 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1287		object d1 = file_timestamp(f1)*/
    RefDS(_f1_44433);
    _0 = _d1_44435;
    _d1_44435 = _17file_timestamp(_f1_44433);
    DeRef(_0);

    /** c_decl.e:1288		object d2 = file_timestamp(f2)*/
    RefDS(_f2_44434);
    _0 = _d2_44438;
    _d2_44438 = _17file_timestamp(_f2_44434);
    DeRef(_0);

    /** c_decl.e:1290		if atom(d1) or atom(d2) then return 1 end if*/
    _23124 = IS_ATOM(_d1_44435);
    if (_23124 != 0) {
        goto L1; // [22] 34
    }
    _23126 = IS_ATOM(_d2_44438);
    if (_23126 == 0)
    {
        _23126 = NOVALUE;
        goto L2; // [30] 39
    }
    else{
        _23126 = NOVALUE;
    }
L1: 
    DeRefDS(_f1_44433);
    DeRefDS(_f2_44434);
    DeRef(_d1_44435);
    DeRef(_d2_44438);
    return 1LL;
L2: 

    /** c_decl.e:1291		if datetime:diff(d1, d2) < 0 then*/

    /** datetime.e:1253		return datetimeToSeconds(dt2) - datetimeToSeconds(dt1)*/
    Ref(_d2_44438);
    _0 = _diff_1__tmp_at42_44448;
    _diff_1__tmp_at42_44448 = _18datetimeToSeconds(_d2_44438);
    DeRef(_0);
    Ref(_d1_44435);
    _0 = _diff_2__tmp_at42_44449;
    _diff_2__tmp_at42_44449 = _18datetimeToSeconds(_d1_44435);
    DeRef(_0);
    DeRef(_diff_inlined_diff_at_42_44447);
    if (IS_ATOM_INT(_diff_1__tmp_at42_44448) && IS_ATOM_INT(_diff_2__tmp_at42_44449)) {
        _diff_inlined_diff_at_42_44447 = _diff_1__tmp_at42_44448 - _diff_2__tmp_at42_44449;
        if ((object)((uintptr_t)_diff_inlined_diff_at_42_44447 +(uintptr_t) HIGH_BITS) >= 0){
            _diff_inlined_diff_at_42_44447 = NewDouble((eudouble)_diff_inlined_diff_at_42_44447);
        }
    }
    else {
        _diff_inlined_diff_at_42_44447 = binary_op(MINUS, _diff_1__tmp_at42_44448, _diff_2__tmp_at42_44449);
    }
    DeRef(_diff_1__tmp_at42_44448);
    _diff_1__tmp_at42_44448 = NOVALUE;
    DeRef(_diff_2__tmp_at42_44449);
    _diff_2__tmp_at42_44449 = NOVALUE;
    if (binary_op_a(GREATEREQ, _diff_inlined_diff_at_42_44447, 0LL)){
        goto L3; // [58] 69
    }

    /** c_decl.e:1292			return 1*/
    DeRefDS(_f1_44433);
    DeRefDS(_f2_44434);
    DeRef(_d1_44435);
    DeRef(_d2_44438);
    return 1LL;
L3: 

    /** c_decl.e:1295		return 0*/
    DeRefDS(_f1_44433);
    DeRefDS(_f2_44434);
    DeRef(_d1_44435);
    DeRef(_d2_44438);
    return 0LL;
    ;
}


void _58add_file(object _filename_44453, object _eu_filename_44454)
{
    object _obj_fname_44474 = NOVALUE;
    object _src_fname_44475 = NOVALUE;
    object _23150 = NOVALUE;
    object _23149 = NOVALUE;
    object _23136 = NOVALUE;
    object _23135 = NOVALUE;
    object _23132 = NOVALUE;
    object _23131 = NOVALUE;
    object _23130 = NOVALUE;
    object _23129 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1303		if equal("c", fileext(filename)) then*/
    RefDS(_filename_44453);
    _23129 = _17fileext(_filename_44453);
    if (_23128 == _23129)
    _23130 = 1;
    else if (IS_ATOM_INT(_23128) && IS_ATOM_INT(_23129))
    _23130 = 0;
    else
    _23130 = (compare(_23128, _23129) == 0);
    DeRef(_23129);
    _23129 = NOVALUE;
    if (_23130 == 0)
    {
        _23130 = NOVALUE;
        goto L1; // [15] 35
    }
    else{
        _23130 = NOVALUE;
    }

    /** c_decl.e:1304			filename = filename[1..$-2]*/
    if (IS_SEQUENCE(_filename_44453)){
            _23131 = SEQ_PTR(_filename_44453)->length;
    }
    else {
        _23131 = 1;
    }
    _23132 = _23131 - 2LL;
    _23131 = NOVALUE;
    rhs_slice_target = (object_ptr)&_filename_44453;
    RHS_Slice(_filename_44453, 1LL, _23132);
    goto L2; // [32] 82
L1: 

    /** c_decl.e:1305		elsif equal("h", fileext(filename)) then*/
    RefDS(_filename_44453);
    _23135 = _17fileext(_filename_44453);
    if (_23134 == _23135)
    _23136 = 1;
    else if (IS_ATOM_INT(_23134) && IS_ATOM_INT(_23135))
    _23136 = 0;
    else
    _23136 = (compare(_23134, _23135) == 0);
    DeRef(_23135);
    _23135 = NOVALUE;
    if (_23136 == 0)
    {
        _23136 = NOVALUE;
        goto L3; // [45] 81
    }
    else{
        _23136 = NOVALUE;
    }

    /** c_decl.e:1306			generated_files = append(generated_files, filename)*/
    RefDS(_filename_44453);
    Append(&_58generated_files_42567, _58generated_files_42567, _filename_44453);

    /** c_decl.e:1307			if build_system_type = BUILD_DIRECT then*/
    if (_56build_system_type_45385 != 3LL)
    goto L4; // [62] 75

    /** c_decl.e:1308				outdated_files  = append(outdated_files, 0)*/
    Append(&_58outdated_files_42568, _58outdated_files_42568, 0LL);
L4: 

    /** c_decl.e:1311			return*/
    DeRefDS(_filename_44453);
    DeRefDS(_eu_filename_44454);
    DeRef(_obj_fname_44474);
    DeRef(_src_fname_44475);
    DeRef(_23132);
    _23132 = NOVALUE;
    return;
L3: 
L2: 

    /** c_decl.e:1314		sequence obj_fname = filename, src_fname = filename & ".c"*/
    RefDS(_filename_44453);
    DeRef(_obj_fname_44474);
    _obj_fname_44474 = _filename_44453;
    Concat((object_ptr)&_src_fname_44475, _filename_44453, _23099);

    /** c_decl.e:1316		if compiler_type = COMPILER_WATCOM then*/
    if (_56compiler_type_45389 != 2LL)
    goto L5; // [99] 112

    /** c_decl.e:1317			obj_fname &= ".obj"*/
    Concat((object_ptr)&_obj_fname_44474, _obj_fname_44474, _23142);
    goto L6; // [109] 119
L5: 

    /** c_decl.e:1319			obj_fname &= ".o"*/
    Concat((object_ptr)&_obj_fname_44474, _obj_fname_44474, _23144);
L6: 

    /** c_decl.e:1322		generated_files = append(generated_files, src_fname)*/
    RefDS(_src_fname_44475);
    Append(&_58generated_files_42567, _58generated_files_42567, _src_fname_44475);

    /** c_decl.e:1323		generated_files = append(generated_files, obj_fname)*/
    RefDS(_obj_fname_44474);
    Append(&_58generated_files_42567, _58generated_files_42567, _obj_fname_44474);

    /** c_decl.e:1324		if build_system_type = BUILD_DIRECT then*/
    if (_56build_system_type_45385 != 3LL)
    goto L7; // [141] 173

    /** c_decl.e:1325			outdated_files  = append(outdated_files, is_file_newer(eu_filename, output_dir & src_fname))*/
    Concat((object_ptr)&_23149, _58output_dir_42577, _src_fname_44475);
    RefDS(_eu_filename_44454);
    _23150 = _58is_file_newer(_eu_filename_44454, _23149);
    _23149 = NOVALUE;
    Ref(_23150);
    Append(&_58outdated_files_42568, _58outdated_files_42568, _23150);
    DeRef(_23150);
    _23150 = NOVALUE;

    /** c_decl.e:1326			outdated_files  = append(outdated_files, 0)*/
    Append(&_58outdated_files_42568, _58outdated_files_42568, 0LL);
L7: 

    /** c_decl.e:1328	end procedure*/
    DeRefDS(_filename_44453);
    DeRefDS(_eu_filename_44454);
    DeRef(_obj_fname_44474);
    DeRef(_src_fname_44475);
    DeRef(_23132);
    _23132 = NOVALUE;
    return;
    ;
}


object _58any_code(object _file_no_44498)
{
    object _these_routines_44500 = NOVALUE;
    object _s_44507 = NOVALUE;
    object _23166 = NOVALUE;
    object _23165 = NOVALUE;
    object _23164 = NOVALUE;
    object _23163 = NOVALUE;
    object _23162 = NOVALUE;
    object _23161 = NOVALUE;
    object _23160 = NOVALUE;
    object _23159 = NOVALUE;
    object _23158 = NOVALUE;
    object _23157 = NOVALUE;
    object _23156 = NOVALUE;
    object _23154 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1334		check_file_routines()*/
    _58check_file_routines();

    /** c_decl.e:1336		sequence these_routines = file_routines[file_no]*/
    DeRef(_these_routines_44500);
    _2 = (object)SEQ_PTR(_58file_routines_44725);
    _these_routines_44500 = (object)*(((s1_ptr)_2)->base + _file_no_44498);
    Ref(_these_routines_44500);

    /** c_decl.e:1337		for i = 1 to length( these_routines ) do*/
    if (IS_SEQUENCE(_these_routines_44500)){
            _23154 = SEQ_PTR(_these_routines_44500)->length;
    }
    else {
        _23154 = 1;
    }
    {
        object _i_44504;
        _i_44504 = 1LL;
L1: 
        if (_i_44504 > _23154){
            goto L2; // [22] 126
        }

        /** c_decl.e:1338			symtab_index s = these_routines[i]*/
        _2 = (object)SEQ_PTR(_these_routines_44500);
        _s_44507 = (object)*(((s1_ptr)_2)->base + _i_44504);
        if (!IS_ATOM_INT(_s_44507)){
            _s_44507 = (object)DBL_PTR(_s_44507)->dbl;
        }

        /** c_decl.e:1339			if SymTab[s][S_FILE_NO] = file_no and*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _23156 = (object)*(((s1_ptr)_2)->base + _s_44507);
        _2 = (object)SEQ_PTR(_23156);
        if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
            _23157 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
        }
        else{
            _23157 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
        }
        _23156 = NOVALUE;
        if (IS_ATOM_INT(_23157)) {
            _23158 = (_23157 == _file_no_44498);
        }
        else {
            _23158 = binary_op(EQUALS, _23157, _file_no_44498);
        }
        _23157 = NOVALUE;
        if (IS_ATOM_INT(_23158)) {
            if (_23158 == 0) {
                DeRef(_23159);
                _23159 = 0;
                goto L3; // [55] 81
            }
        }
        else {
            if (DBL_PTR(_23158)->dbl == 0.0) {
                DeRef(_23159);
                _23159 = 0;
                goto L3; // [55] 81
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _23160 = (object)*(((s1_ptr)_2)->base + _s_44507);
        _2 = (object)SEQ_PTR(_23160);
        _23161 = (object)*(((s1_ptr)_2)->base + 5LL);
        _23160 = NOVALUE;
        if (IS_ATOM_INT(_23161)) {
            _23162 = (_23161 != 99LL);
        }
        else {
            _23162 = binary_op(NOTEQ, _23161, 99LL);
        }
        _23161 = NOVALUE;
        DeRef(_23159);
        if (IS_ATOM_INT(_23162))
        _23159 = (_23162 != 0);
        else
        _23159 = DBL_PTR(_23162)->dbl != 0.0;
L3: 
        if (_23159 == 0) {
            goto L4; // [81] 117
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _23164 = (object)*(((s1_ptr)_2)->base + _s_44507);
        _2 = (object)SEQ_PTR(_23164);
        if (!IS_ATOM_INT(_36S_TOKEN_21081)){
            _23165 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
        }
        else{
            _23165 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
        }
        _23164 = NOVALUE;
        _23166 = find_from(_23165, _38RTN_TOKS_16045, 1LL);
        _23165 = NOVALUE;
        if (_23166 == 0)
        {
            _23166 = NOVALUE;
            goto L4; // [105] 117
        }
        else{
            _23166 = NOVALUE;
        }

        /** c_decl.e:1342				return TRUE -- found a non-deleted routine in this file*/
        DeRef(_these_routines_44500);
        DeRef(_23162);
        _23162 = NOVALUE;
        DeRef(_23158);
        _23158 = NOVALUE;
        return _13TRUE_452;
L4: 

        /** c_decl.e:1344		end for*/
        _i_44504 = _i_44504 + 1LL;
        goto L1; // [121] 29
L2: 
        ;
    }

    /** c_decl.e:1345		return FALSE*/
    DeRef(_these_routines_44500);
    DeRef(_23162);
    _23162 = NOVALUE;
    DeRef(_23158);
    _23158 = NOVALUE;
    return _13FALSE_450;
    ;
}


void _58check_file_routines()
{
    object _s_44734 = NOVALUE;
    object _23328 = NOVALUE;
    object _23327 = NOVALUE;
    object _23326 = NOVALUE;
    object _23325 = NOVALUE;
    object _23324 = NOVALUE;
    object _23323 = NOVALUE;
    object _23322 = NOVALUE;
    object _23321 = NOVALUE;
    object _23320 = NOVALUE;
    object _23319 = NOVALUE;
    object _23318 = NOVALUE;
    object _23317 = NOVALUE;
    object _23315 = NOVALUE;
    object _23313 = NOVALUE;
    object _23311 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1451		if not length( file_routines ) then*/
    if (IS_SEQUENCE(_58file_routines_44725)){
            _23311 = SEQ_PTR(_58file_routines_44725)->length;
    }
    else {
        _23311 = 1;
    }
    if (_23311 != 0)
    goto L1; // [8] 146
    _23311 = NOVALUE;

    /** c_decl.e:1452			file_routines = repeat( {}, length( known_files ) )*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _23313 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _23313 = 1;
    }
    DeRefDS(_58file_routines_44725);
    _58file_routines_44725 = Repeat(_21993, _23313);
    _23313 = NOVALUE;

    /** c_decl.e:1453			integer s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _23315 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21446);
    _2 = (object)SEQ_PTR(_23315);
    _s_44734 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_44734)){
        _s_44734 = (object)DBL_PTR(_s_44734)->dbl;
    }
    _23315 = NOVALUE;

    /** c_decl.e:1454			while s do*/
L2: 
    if (_s_44734 == 0)
    {
        goto L3; // [45] 145
    }
    else{
    }

    /** c_decl.e:1455				if SymTab[s][S_USAGE] != U_DELETED and*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _23317 = (object)*(((s1_ptr)_2)->base + _s_44734);
    _2 = (object)SEQ_PTR(_23317);
    _23318 = (object)*(((s1_ptr)_2)->base + 5LL);
    _23317 = NOVALUE;
    if (IS_ATOM_INT(_23318)) {
        _23319 = (_23318 != 99LL);
    }
    else {
        _23319 = binary_op(NOTEQ, _23318, 99LL);
    }
    _23318 = NOVALUE;
    if (IS_ATOM_INT(_23319)) {
        if (_23319 == 0) {
            goto L4; // [68] 124
        }
    }
    else {
        if (DBL_PTR(_23319)->dbl == 0.0) {
            goto L4; // [68] 124
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _23321 = (object)*(((s1_ptr)_2)->base + _s_44734);
    _2 = (object)SEQ_PTR(_23321);
    if (!IS_ATOM_INT(_36S_TOKEN_21081)){
        _23322 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    }
    else{
        _23322 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    }
    _23321 = NOVALUE;
    _23323 = find_from(_23322, _38RTN_TOKS_16045, 1LL);
    _23322 = NOVALUE;
    if (_23323 == 0)
    {
        _23323 = NOVALUE;
        goto L4; // [92] 124
    }
    else{
        _23323 = NOVALUE;
    }

    /** c_decl.e:1458					file_routines[SymTab[s][S_FILE_NO]] &= s*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _23324 = (object)*(((s1_ptr)_2)->base + _s_44734);
    _2 = (object)SEQ_PTR(_23324);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _23325 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _23325 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    _23324 = NOVALUE;
    _2 = (object)SEQ_PTR(_58file_routines_44725);
    if (!IS_ATOM_INT(_23325)){
        _23326 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_23325)->dbl));
    }
    else{
        _23326 = (object)*(((s1_ptr)_2)->base + _23325);
    }
    if (IS_SEQUENCE(_23326) && IS_ATOM(_s_44734)) {
        Append(&_23327, _23326, _s_44734);
    }
    else if (IS_ATOM(_23326) && IS_SEQUENCE(_s_44734)) {
    }
    else {
        Concat((object_ptr)&_23327, _23326, _s_44734);
        _23326 = NOVALUE;
    }
    _23326 = NOVALUE;
    _2 = (object)SEQ_PTR(_58file_routines_44725);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _58file_routines_44725 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_23325))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_23325)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _23325);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23327;
    if( _1 != _23327 ){
        DeRef(_1);
    }
    _23327 = NOVALUE;
L4: 

    /** c_decl.e:1460				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _23328 = (object)*(((s1_ptr)_2)->base + _s_44734);
    _2 = (object)SEQ_PTR(_23328);
    _s_44734 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_44734)){
        _s_44734 = (object)DBL_PTR(_s_44734)->dbl;
    }
    _23328 = NOVALUE;

    /** c_decl.e:1461			end while*/
    goto L2; // [142] 45
L3: 
L1: 

    /** c_decl.e:1464	end procedure*/
    DeRef(_23319);
    _23319 = NOVALUE;
    _23325 = NOVALUE;
    return;
    ;
}


void _58GenerateUserRoutines()
{
    object _s_44768 = NOVALUE;
    object _sp_44769 = NOVALUE;
    object _next_c_char_44770 = NOVALUE;
    object _q_44771 = NOVALUE;
    object _temps_44772 = NOVALUE;
    object _buff_44773 = NOVALUE;
    object _base_name_44774 = NOVALUE;
    object _long_c_file_44775 = NOVALUE;
    object _c_file_44776 = NOVALUE;
    object _these_routines_44847 = NOVALUE;
    object _ret_type_44905 = NOVALUE;
    object _s_scope_44914 = NOVALUE;
    object _s_file_44917 = NOVALUE;
    object _scope_44994 = NOVALUE;
    object _names_45028 = NOVALUE;
    object _name_45038 = NOVALUE;
    object _23564 = NOVALUE;
    object _23562 = NOVALUE;
    object _23561 = NOVALUE;
    object _23560 = NOVALUE;
    object _23559 = NOVALUE;
    object _23558 = NOVALUE;
    object _23557 = NOVALUE;
    object _23555 = NOVALUE;
    object _23553 = NOVALUE;
    object _23552 = NOVALUE;
    object _23549 = NOVALUE;
    object _23547 = NOVALUE;
    object _23546 = NOVALUE;
    object _23545 = NOVALUE;
    object _23544 = NOVALUE;
    object _23543 = NOVALUE;
    object _23542 = NOVALUE;
    object _23540 = NOVALUE;
    object _23536 = NOVALUE;
    object _23534 = NOVALUE;
    object _23533 = NOVALUE;
    object _23532 = NOVALUE;
    object _23531 = NOVALUE;
    object _23529 = NOVALUE;
    object _23528 = NOVALUE;
    object _23526 = NOVALUE;
    object _23525 = NOVALUE;
    object _23523 = NOVALUE;
    object _23522 = NOVALUE;
    object _23521 = NOVALUE;
    object _23520 = NOVALUE;
    object _23518 = NOVALUE;
    object _23516 = NOVALUE;
    object _23515 = NOVALUE;
    object _23514 = NOVALUE;
    object _23513 = NOVALUE;
    object _23512 = NOVALUE;
    object _23511 = NOVALUE;
    object _23510 = NOVALUE;
    object _23508 = NOVALUE;
    object _23507 = NOVALUE;
    object _23506 = NOVALUE;
    object _23505 = NOVALUE;
    object _23504 = NOVALUE;
    object _23503 = NOVALUE;
    object _23502 = NOVALUE;
    object _23501 = NOVALUE;
    object _23499 = NOVALUE;
    object _23498 = NOVALUE;
    object _23496 = NOVALUE;
    object _23495 = NOVALUE;
    object _23494 = NOVALUE;
    object _23493 = NOVALUE;
    object _23492 = NOVALUE;
    object _23491 = NOVALUE;
    object _23490 = NOVALUE;
    object _23489 = NOVALUE;
    object _23487 = NOVALUE;
    object _23486 = NOVALUE;
    object _23484 = NOVALUE;
    object _23483 = NOVALUE;
    object _23482 = NOVALUE;
    object _23480 = NOVALUE;
    object _23475 = NOVALUE;
    object _23474 = NOVALUE;
    object _23472 = NOVALUE;
    object _23470 = NOVALUE;
    object _23464 = NOVALUE;
    object _23463 = NOVALUE;
    object _23462 = NOVALUE;
    object _23461 = NOVALUE;
    object _23460 = NOVALUE;
    object _23459 = NOVALUE;
    object _23458 = NOVALUE;
    object _23457 = NOVALUE;
    object _23455 = NOVALUE;
    object _23454 = NOVALUE;
    object _23452 = NOVALUE;
    object _23451 = NOVALUE;
    object _23448 = NOVALUE;
    object _23446 = NOVALUE;
    object _23445 = NOVALUE;
    object _23444 = NOVALUE;
    object _23440 = NOVALUE;
    object _23437 = NOVALUE;
    object _23434 = NOVALUE;
    object _23433 = NOVALUE;
    object _23432 = NOVALUE;
    object _23431 = NOVALUE;
    object _23429 = NOVALUE;
    object _23428 = NOVALUE;
    object _23426 = NOVALUE;
    object _23425 = NOVALUE;
    object _23424 = NOVALUE;
    object _23422 = NOVALUE;
    object _23419 = NOVALUE;
    object _23418 = NOVALUE;
    object _23417 = NOVALUE;
    object _23416 = NOVALUE;
    object _23415 = NOVALUE;
    object _23414 = NOVALUE;
    object _23413 = NOVALUE;
    object _23412 = NOVALUE;
    object _23411 = NOVALUE;
    object _23410 = NOVALUE;
    object _23409 = NOVALUE;
    object _23408 = NOVALUE;
    object _23407 = NOVALUE;
    object _23406 = NOVALUE;
    object _23405 = NOVALUE;
    object _23403 = NOVALUE;
    object _23400 = NOVALUE;
    object _23399 = NOVALUE;
    object _23397 = NOVALUE;
    object _23394 = NOVALUE;
    object _23393 = NOVALUE;
    object _23389 = NOVALUE;
    object _23388 = NOVALUE;
    object _23386 = NOVALUE;
    object _23382 = NOVALUE;
    object _23381 = NOVALUE;
    object _23380 = NOVALUE;
    object _23379 = NOVALUE;
    object _23378 = NOVALUE;
    object _23377 = NOVALUE;
    object _23376 = NOVALUE;
    object _23375 = NOVALUE;
    object _23374 = NOVALUE;
    object _23373 = NOVALUE;
    object _23372 = NOVALUE;
    object _23371 = NOVALUE;
    object _23370 = NOVALUE;
    object _23369 = NOVALUE;
    object _23367 = NOVALUE;
    object _23366 = NOVALUE;
    object _23364 = NOVALUE;
    object _23361 = NOVALUE;
    object _23358 = NOVALUE;
    object _23355 = NOVALUE;
    object _23352 = NOVALUE;
    object _23351 = NOVALUE;
    object _23350 = NOVALUE;
    object _23347 = NOVALUE;
    object _23344 = NOVALUE;
    object _23342 = NOVALUE;
    object _23338 = NOVALUE;
    object _23337 = NOVALUE;
    object _23335 = NOVALUE;
    object _23334 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** c_decl.e:1468		integer next_c_char, q, temps*/

    /** c_decl.e:1469		sequence buff, base_name, long_c_file, c_file*/

    /** c_decl.e:1471		if not silent then*/
    if (_36silent_21558 != 0)
    goto L1; // [9] 68

    /** c_decl.e:1472			if Pass = 1 then*/
    if (_58Pass_42552 != 1LL)
    goto L2; // [16] 31

    /** c_decl.e:1473				ShowMsg(1, TRANSLATING_CODE_PASS,,0)*/
    RefDS(_21993);
    _39ShowMsg(1LL, 239LL, _21993, 0LL);
L2: 

    /** c_decl.e:1476			if LAST_PASS = TRUE then*/
    if (_58LAST_PASS_42550 != _13TRUE_452)
    goto L3; // [37] 54

    /** c_decl.e:1477				ShowMsg(1, MSG__GENERATING)*/
    RefDS(_21993);
    _39ShowMsg(1LL, 240LL, _21993, 1LL);
    goto L4; // [51] 67
L3: 

    /** c_decl.e:1479				ShowMsg(1, MSG_1, Pass, 0)*/
    _39ShowMsg(1LL, 241LL, _58Pass_42552, 0LL);
L4: 
L1: 

    /** c_decl.e:1483		check_file_routines()*/
    _58check_file_routines();

    /** c_decl.e:1485		c_puts("// GenerateUserRoutines\n")*/
    RefDS(_23333);
    _55c_puts(_23333);

    /** c_decl.e:1486		for file_no = 1 to length(known_files) do*/
    if (IS_SEQUENCE(_37known_files_15407)){
            _23334 = SEQ_PTR(_37known_files_15407)->length;
    }
    else {
        _23334 = 1;
    }
    {
        object _file_no_44795;
        _file_no_44795 = 1LL;
L5: 
        if (_file_no_44795 > _23334){
            goto L6; // [84] 2208
        }

        /** c_decl.e:1487			if file_no = 1 or any_code(file_no) then*/
        _23335 = (_file_no_44795 == 1LL);
        if (_23335 != 0) {
            goto L7; // [97] 110
        }
        _23337 = _58any_code(_file_no_44795);
        if (_23337 == 0) {
            DeRef(_23337);
            _23337 = NOVALUE;
            goto L8; // [106] 2199
        }
        else {
            if (!IS_ATOM_INT(_23337) && DBL_PTR(_23337)->dbl == 0.0){
                DeRef(_23337);
                _23337 = NOVALUE;
                goto L8; // [106] 2199
            }
            DeRef(_23337);
            _23337 = NOVALUE;
        }
        DeRef(_23337);
        _23337 = NOVALUE;
L7: 

        /** c_decl.e:1490				next_c_char = 1*/
        _next_c_char_44770 = 1LL;

        /** c_decl.e:1491				base_name = name_ext(known_files[file_no])*/
        _2 = (object)SEQ_PTR(_37known_files_15407);
        _23338 = (object)*(((s1_ptr)_2)->base + _file_no_44795);
        Ref(_23338);
        _0 = _base_name_44774;
        _base_name_44774 = _54name_ext(_23338);
        DeRef(_0);
        _23338 = NOVALUE;

        /** c_decl.e:1492				c_file = base_name*/
        RefDS(_base_name_44774);
        DeRef(_c_file_44776);
        _c_file_44776 = _base_name_44774;

        /** c_decl.e:1494				q = length(c_file)*/
        if (IS_SEQUENCE(_c_file_44776)){
                _q_44771 = SEQ_PTR(_c_file_44776)->length;
        }
        else {
            _q_44771 = 1;
        }

        /** c_decl.e:1495				while q >= 1 do*/
L9: 
        if (_q_44771 < 1LL)
        goto LA; // [146] 187

        /** c_decl.e:1496					if c_file[q] = '.' then*/
        _2 = (object)SEQ_PTR(_c_file_44776);
        _23342 = (object)*(((s1_ptr)_2)->base + _q_44771);
        if (binary_op_a(NOTEQ, _23342, 46LL)){
            _23342 = NOVALUE;
            goto LB; // [156] 176
        }
        _23342 = NOVALUE;

        /** c_decl.e:1497						c_file = c_file[1..q-1]*/
        _23344 = _q_44771 - 1LL;
        rhs_slice_target = (object_ptr)&_c_file_44776;
        RHS_Slice(_c_file_44776, 1LL, _23344);

        /** c_decl.e:1498						exit*/
        goto LA; // [173] 187
LB: 

        /** c_decl.e:1500					q -= 1*/
        _q_44771 = _q_44771 - 1LL;

        /** c_decl.e:1501				end while*/
        goto L9; // [184] 146
LA: 

        /** c_decl.e:1503				if find(lower(c_file), {"main-", "init-"})  then*/
        RefDS(_c_file_44776);
        _23347 = _14lower(_c_file_44776);
        RefDS(_23349);
        RefDS(_23348);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _23348;
        ((intptr_t *)_2)[2] = _23349;
        _23350 = MAKE_SEQ(_1);
        _23351 = find_from(_23347, _23350, 1LL);
        DeRef(_23347);
        _23347 = NOVALUE;
        DeRefDS(_23350);
        _23350 = NOVALUE;
        if (_23351 == 0)
        {
            _23351 = NOVALUE;
            goto LC; // [202] 219
        }
        else{
            _23351 = NOVALUE;
        }

        /** c_decl.e:1504					CompileErr(MSG_1_CONFLICTS_WITH_A_FILE_NAME_USED_INTERNALLY_BY_THE_TRANSLATOR, {base_name})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_base_name_44774);
        ((intptr_t*)_2)[1] = _base_name_44774;
        _23352 = MAKE_SEQ(_1);
        _50CompileErr(12LL, _23352, 0LL);
        _23352 = NOVALUE;
LC: 

        /** c_decl.e:1507				long_c_file = c_file*/
        RefDS(_c_file_44776);
        DeRef(_long_c_file_44775);
        _long_c_file_44775 = _c_file_44776;

        /** c_decl.e:1508				if LAST_PASS = TRUE then*/
        if (_58LAST_PASS_42550 != _13TRUE_452)
        goto LD; // [232] 257

        /** c_decl.e:1509					c_file = unique_c_name(c_file)*/
        RefDS(_c_file_44776);
        _0 = _c_file_44776;
        _c_file_44776 = _58unique_c_name(_c_file_44776);
        DeRefDS(_0);

        /** c_decl.e:1510					add_file(c_file, known_files[file_no])*/
        _2 = (object)SEQ_PTR(_37known_files_15407);
        _23355 = (object)*(((s1_ptr)_2)->base + _file_no_44795);
        RefDS(_c_file_44776);
        Ref(_23355);
        _58add_file(_c_file_44776, _23355);
        _23355 = NOVALUE;
LD: 

        /** c_decl.e:1513				if file_no = 1 then*/
        if (_file_no_44795 != 1LL)
        goto LE; // [259] 322

        /** c_decl.e:1515					if LAST_PASS = TRUE then*/
        if (_58LAST_PASS_42550 != _13TRUE_452)
        goto LF; // [269] 314

        /** c_decl.e:1516						add_file("main-")*/
        RefDS(_23348);
        RefDS(_21993);
        _58add_file(_23348, _21993);

        /** c_decl.e:1517						for i = 0 to main_name_num-1 do*/
        _23358 = _55main_name_num_46625 - 1LL;
        if ((object)((uintptr_t)_23358 +(uintptr_t) HIGH_BITS) >= 0){
            _23358 = NewDouble((eudouble)_23358);
        }
        {
            object _i_44837;
            _i_44837 = 0LL;
L10: 
            if (binary_op_a(GREATER, _i_44837, _23358)){
                goto L11; // [287] 313
            }

            /** c_decl.e:1518							buff = sprintf("main-%d", i)*/
            DeRefi(_buff_44773);
            _buff_44773 = EPrintf(-9999999, _23359, _i_44837);

            /** c_decl.e:1519							add_file(buff)*/
            RefDS(_buff_44773);
            RefDS(_21993);
            _58add_file(_buff_44773, _21993);

            /** c_decl.e:1520						end for*/
            _0 = _i_44837;
            if (IS_ATOM_INT(_i_44837)) {
                _i_44837 = _i_44837 + 1LL;
                if ((object)((uintptr_t)_i_44837 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_44837 = NewDouble((eudouble)_i_44837);
                }
            }
            else {
                _i_44837 = binary_op_a(PLUS, _i_44837, 1LL);
            }
            DeRef(_0);
            goto L10; // [308] 294
L11: 
            ;
            DeRef(_i_44837);
        }
LF: 

        /** c_decl.e:1523					file0 = long_c_file*/
        RefDS(_long_c_file_44775);
        DeRef(_58file0_44531);
        _58file0_44531 = _long_c_file_44775;
LE: 

        /** c_decl.e:1526				new_c_file(c_file)*/
        RefDS(_c_file_44776);
        _58new_c_file(_c_file_44776);

        /** c_decl.e:1528				s = SymTab[TopLevelSub][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _23361 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21446);
        _2 = (object)SEQ_PTR(_23361);
        _s_44768 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_s_44768)){
            _s_44768 = (object)DBL_PTR(_s_44768)->dbl;
        }
        _23361 = NOVALUE;

        /** c_decl.e:1530				sequence these_routines = file_routines[file_no]*/
        DeRef(_these_routines_44847);
        _2 = (object)SEQ_PTR(_58file_routines_44725);
        _these_routines_44847 = (object)*(((s1_ptr)_2)->base + _file_no_44795);
        Ref(_these_routines_44847);

        /** c_decl.e:1531				for routine_no = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_44847)){
                _23364 = SEQ_PTR(_these_routines_44847)->length;
        }
        else {
            _23364 = 1;
        }
        {
            object _routine_no_44850;
            _routine_no_44850 = 1LL;
L12: 
            if (_routine_no_44850 > _23364){
                goto L13; // [360] 2198
            }

            /** c_decl.e:1532					s = these_routines[routine_no]*/
            _2 = (object)SEQ_PTR(_these_routines_44847);
            _s_44768 = (object)*(((s1_ptr)_2)->base + _routine_no_44850);
            if (!IS_ATOM_INT(_s_44768)){
                _s_44768 = (object)DBL_PTR(_s_44768)->dbl;
            }

            /** c_decl.e:1533					if SymTab[s][S_USAGE] != U_DELETED then*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23366 = (object)*(((s1_ptr)_2)->base + _s_44768);
            _2 = (object)SEQ_PTR(_23366);
            _23367 = (object)*(((s1_ptr)_2)->base + 5LL);
            _23366 = NOVALUE;
            if (binary_op_a(EQUALS, _23367, 99LL)){
                _23367 = NOVALUE;
                goto L14; // [391] 2189
            }
            _23367 = NOVALUE;

            /** c_decl.e:1537						if LAST_PASS = TRUE and*/
            _23369 = (_58LAST_PASS_42550 == _13TRUE_452);
            if (_23369 == 0) {
                goto L15; // [405] 601
            }
            _23371 = (_36cfile_size_21522 > _56max_cfile_size_45405);
            if (_23371 != 0) {
                DeRef(_23372);
                _23372 = 1;
                goto L16; // [417] 480
            }
            _23373 = (_s_44768 != _36TopLevelSub_21446);
            if (_23373 == 0) {
                _23374 = 0;
                goto L17; // [427] 447
            }
            _23375 = (_56max_cfile_size_45405 % 4LL) ? NewDouble((eudouble)_56max_cfile_size_45405 / 4LL) : (_56max_cfile_size_45405 / 4LL);
            if (IS_ATOM_INT(_23375)) {
                _23376 = (_36cfile_size_21522 > _23375);
            }
            else {
                _23376 = ((eudouble)_36cfile_size_21522 > DBL_PTR(_23375)->dbl);
            }
            DeRef(_23375);
            _23375 = NOVALUE;
            _23374 = (_23376 != 0);
L17: 
            if (_23374 == 0) {
                _23377 = 0;
                goto L18; // [447] 476
            }
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23378 = (object)*(((s1_ptr)_2)->base + _s_44768);
            _2 = (object)SEQ_PTR(_23378);
            if (!IS_ATOM_INT(_36S_CODE_21088)){
                _23379 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
            }
            else{
                _23379 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21088);
            }
            _23378 = NOVALUE;
            if (IS_SEQUENCE(_23379)){
                    _23380 = SEQ_PTR(_23379)->length;
            }
            else {
                _23380 = 1;
            }
            _23379 = NOVALUE;
            _23381 = (_23380 > _56max_cfile_size_45405);
            _23380 = NOVALUE;
            _23377 = (_23381 != 0);
L18: 
            DeRef(_23372);
            _23372 = (_23377 != 0);
L16: 
            if (_23372 == 0)
            {
                _23372 = NOVALUE;
                goto L15; // [481] 601
            }
            else{
                _23372 = NOVALUE;
            }

            /** c_decl.e:1546							if length(c_file) = 7 then*/
            if (IS_SEQUENCE(_c_file_44776)){
                    _23382 = SEQ_PTR(_c_file_44776)->length;
            }
            else {
                _23382 = 1;
            }
            if (_23382 != 7LL)
            goto L19; // [489] 500

            /** c_decl.e:1548								c_file &= " "*/
            Concat((object_ptr)&_c_file_44776, _c_file_44776, _23384);
L19: 

            /** c_decl.e:1551							if length(c_file) >= 8 then*/
            if (IS_SEQUENCE(_c_file_44776)){
                    _23386 = SEQ_PTR(_c_file_44776)->length;
            }
            else {
                _23386 = 1;
            }
            if (_23386 < 8LL)
            goto L1A; // [505] 528

            /** c_decl.e:1552								c_file[7] = '_'*/
            _2 = (object)SEQ_PTR(_c_file_44776);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _c_file_44776 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 7LL);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 95LL;
            DeRef(_1);

            /** c_decl.e:1553								c_file[8] = file_chars[next_c_char]*/
            _2 = (object)SEQ_PTR(_58file_chars_44396);
            _23388 = (object)*(((s1_ptr)_2)->base + _next_c_char_44770);
            Ref(_23388);
            _2 = (object)SEQ_PTR(_c_file_44776);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _c_file_44776 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 8LL);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _23388;
            if( _1 != _23388 ){
                DeRef(_1);
            }
            _23388 = NOVALUE;
            goto L1B; // [525] 560
L1A: 

            /** c_decl.e:1556								if find('_', c_file) = 0 then*/
            _23389 = find_from(95LL, _c_file_44776, 1LL);
            if (_23389 != 0LL)
            goto L1C; // [535] 546

            /** c_decl.e:1557									c_file &= "_ "*/
            Concat((object_ptr)&_c_file_44776, _c_file_44776, _23391);
L1C: 

            /** c_decl.e:1560								c_file[$] = file_chars[next_c_char]*/
            if (IS_SEQUENCE(_c_file_44776)){
                    _23393 = SEQ_PTR(_c_file_44776)->length;
            }
            else {
                _23393 = 1;
            }
            _2 = (object)SEQ_PTR(_58file_chars_44396);
            _23394 = (object)*(((s1_ptr)_2)->base + _next_c_char_44770);
            Ref(_23394);
            _2 = (object)SEQ_PTR(_c_file_44776);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _c_file_44776 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _23393);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _23394;
            if( _1 != _23394 ){
                DeRef(_1);
            }
            _23394 = NOVALUE;
L1B: 

            /** c_decl.e:1564							c_file = unique_c_name(c_file)*/
            RefDS(_c_file_44776);
            _0 = _c_file_44776;
            _c_file_44776 = _58unique_c_name(_c_file_44776);
            DeRefDS(_0);

            /** c_decl.e:1565							new_c_file(c_file)*/
            RefDS(_c_file_44776);
            _58new_c_file(_c_file_44776);

            /** c_decl.e:1567							next_c_char += 1*/
            _next_c_char_44770 = _next_c_char_44770 + 1;

            /** c_decl.e:1568							if next_c_char > length(file_chars) then*/
            if (IS_SEQUENCE(_58file_chars_44396)){
                    _23397 = SEQ_PTR(_58file_chars_44396)->length;
            }
            else {
                _23397 = 1;
            }
            if (_next_c_char_44770 <= _23397)
            goto L1D; // [584] 594

            /** c_decl.e:1569								next_c_char = 1  -- (unique_c_name will resolve)*/
            _next_c_char_44770 = 1LL;
L1D: 

            /** c_decl.e:1572							add_file(c_file)*/
            RefDS(_c_file_44776);
            RefDS(_21993);
            _58add_file(_c_file_44776, _21993);
L15: 

            /** c_decl.e:1575						sequence ret_type*/

            /** c_decl.e:1576						if SymTab[s][S_TOKEN] = PROC then*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23399 = (object)*(((s1_ptr)_2)->base + _s_44768);
            _2 = (object)SEQ_PTR(_23399);
            if (!IS_ATOM_INT(_36S_TOKEN_21081)){
                _23400 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
            }
            else{
                _23400 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
            }
            _23399 = NOVALUE;
            if (binary_op_a(NOTEQ, _23400, 27LL)){
                _23400 = NOVALUE;
                goto L1E; // [619] 633
            }
            _23400 = NOVALUE;

            /** c_decl.e:1577							ret_type = "void "*/
            RefDS(_22777);
            DeRefi(_ret_type_44905);
            _ret_type_44905 = _22777;
            goto L1F; // [630] 641
L1E: 

            /** c_decl.e:1579							ret_type = "object "*/
            RefDS(_22778);
            DeRefi(_ret_type_44905);
            _ret_type_44905 = _22778;
L1F: 

            /** c_decl.e:1581						integer s_scope = sym_scope( s )*/
            _s_scope_44914 = _54sym_scope(_s_44768);
            if (!IS_ATOM_INT(_s_scope_44914)) {
                _1 = (object)(DBL_PTR(_s_scope_44914)->dbl);
                DeRefDS(_s_scope_44914);
                _s_scope_44914 = _1;
            }

            /** c_decl.e:1582						integer s_file  = SymTab[s][S_FILE_NO]*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23403 = (object)*(((s1_ptr)_2)->base + _s_44768);
            _2 = (object)SEQ_PTR(_23403);
            if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
                _s_file_44917 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
            }
            else{
                _s_file_44917 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
            }
            if (!IS_ATOM_INT(_s_file_44917)){
                _s_file_44917 = (object)DBL_PTR(_s_file_44917)->dbl;
            }
            _23403 = NOVALUE;

            /** c_decl.e:1583						if dll_option and*/
            if (_58dll_option_42563 == 0) {
                goto L20; // [669] 827
            }
            _23406 = (_s_scope_44914 == 6LL);
            if (_23406 != 0) {
                DeRef(_23407);
                _23407 = 1;
                goto L21; // [679] 757
            }
            _23408 = (_s_file_44917 == 1LL);
            if (_23408 == 0) {
                _23409 = 0;
                goto L22; // [687] 715
            }
            _23410 = (_s_scope_44914 == 13LL);
            if (_23410 != 0) {
                _23411 = 1;
                goto L23; // [697] 711
            }
            _23412 = (_s_scope_44914 == 11LL);
            _23411 = (_23412 != 0);
L23: 
            _23409 = (_23411 != 0);
L22: 
            if (_23409 != 0) {
                _23413 = 1;
                goto L24; // [715] 753
            }
            _23414 = (_s_scope_44914 == 13LL);
            if (_23414 == 0) {
                _23415 = 0;
                goto L25; // [725] 749
            }
            _2 = (object)SEQ_PTR(_37include_matrix_15413);
            _23416 = (object)*(((s1_ptr)_2)->base + 1LL);
            _2 = (object)SEQ_PTR(_23416);
            _23417 = (object)*(((s1_ptr)_2)->base + _s_file_44917);
            _23416 = NOVALUE;
            if (IS_ATOM_INT(_23417)) {
                {uintptr_t tu;
                     tu = (uintptr_t)_23417 & (uintptr_t)4LL;
                     _23418 = MAKE_UINT(tu);
                }
            }
            else {
                _23418 = binary_op(AND_BITS, _23417, 4LL);
            }
            _23417 = NOVALUE;
            if (IS_ATOM_INT(_23418))
            _23415 = (_23418 != 0);
            else
            _23415 = DBL_PTR(_23418)->dbl != 0.0;
L25: 
            _23413 = (_23415 != 0);
L24: 
            DeRef(_23407);
            _23407 = (_23413 != 0);
L21: 
            if (_23407 == 0)
            {
                _23407 = NOVALUE;
                goto L20; // [758] 827
            }
            else{
                _23407 = NOVALUE;
            }

            /** c_decl.e:1589							SymTab[s][S_RI_TARGET] = TRUE*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _37SymTab_15406 = MAKE_SEQ(_2);
            }
            _3 = (object)(_s_44768 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 53LL);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _13TRUE_452;
            DeRef(_1);
            _23419 = NOVALUE;

            /** c_decl.e:1590							LeftSym = TRUE*/
            _58LeftSym_42560 = _13TRUE_452;

            /** c_decl.e:1593							if TWINDOWS then*/
            if (_46TWINDOWS_21586 == 0)
            {
                goto L26; // [791] 810
            }
            else{
            }

            /** c_decl.e:1594								c_stmt(ret_type & " __stdcall @(", s)*/
            Concat((object_ptr)&_23422, _ret_type_44905, _23421);
            _58c_stmt(_23422, _s_44768, 0LL);
            _23422 = NOVALUE;
            goto L27; // [807] 850
L26: 

            /** c_decl.e:1596								c_stmt(ret_type & "@(", s)*/
            Concat((object_ptr)&_23424, _ret_type_44905, _23423);
            _58c_stmt(_23424, _s_44768, 0LL);
            _23424 = NOVALUE;
            goto L27; // [824] 850
L20: 

            /** c_decl.e:1600							LeftSym = TRUE*/
            _58LeftSym_42560 = _13TRUE_452;

            /** c_decl.e:1601							c_stmt( ret_type & "@(", s)*/
            Concat((object_ptr)&_23425, _ret_type_44905, _23423);
            _58c_stmt(_23425, _s_44768, 0LL);
            _23425 = NOVALUE;
L27: 

            /** c_decl.e:1605						sp = SymTab[s][S_NEXT]*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23426 = (object)*(((s1_ptr)_2)->base + _s_44768);
            _2 = (object)SEQ_PTR(_23426);
            _sp_44769 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_sp_44769)){
                _sp_44769 = (object)DBL_PTR(_sp_44769)->dbl;
            }
            _23426 = NOVALUE;

            /** c_decl.e:1606						for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23428 = (object)*(((s1_ptr)_2)->base + _s_44768);
            _2 = (object)SEQ_PTR(_23428);
            if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
                _23429 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
            }
            else{
                _23429 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
            }
            _23428 = NOVALUE;
            {
                object _p_44964;
                _p_44964 = 1LL;
L28: 
                if (binary_op_a(GREATER, _p_44964, _23429)){
                    goto L29; // [880] 956
                }

                /** c_decl.e:1607							c_puts("object _")*/
                RefDS(_23430);
                _55c_puts(_23430);

                /** c_decl.e:1608							c_puts(SymTab[sp][S_NAME])*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23431 = (object)*(((s1_ptr)_2)->base + _sp_44769);
                _2 = (object)SEQ_PTR(_23431);
                if (!IS_ATOM_INT(_36S_NAME_21076)){
                    _23432 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
                }
                else{
                    _23432 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
                }
                _23431 = NOVALUE;
                Ref(_23432);
                _55c_puts(_23432);
                _23432 = NOVALUE;

                /** c_decl.e:1609							if p != SymTab[s][S_NUM_ARGS] then*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23433 = (object)*(((s1_ptr)_2)->base + _s_44768);
                _2 = (object)SEQ_PTR(_23433);
                if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
                    _23434 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
                }
                else{
                    _23434 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
                }
                _23433 = NOVALUE;
                if (binary_op_a(EQUALS, _p_44964, _23434)){
                    _23434 = NOVALUE;
                    goto L2A; // [923] 933
                }
                _23434 = NOVALUE;

                /** c_decl.e:1610								c_puts(", ")*/
                RefDS(_23436);
                _55c_puts(_23436);
L2A: 

                /** c_decl.e:1612							sp = SymTab[sp][S_NEXT]*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23437 = (object)*(((s1_ptr)_2)->base + _sp_44769);
                _2 = (object)SEQ_PTR(_23437);
                _sp_44769 = (object)*(((s1_ptr)_2)->base + 2LL);
                if (!IS_ATOM_INT(_sp_44769)){
                    _sp_44769 = (object)DBL_PTR(_sp_44769)->dbl;
                }
                _23437 = NOVALUE;

                /** c_decl.e:1613						end for*/
                _0 = _p_44964;
                if (IS_ATOM_INT(_p_44964)) {
                    _p_44964 = _p_44964 + 1LL;
                    if ((object)((uintptr_t)_p_44964 +(uintptr_t) HIGH_BITS) >= 0){
                        _p_44964 = NewDouble((eudouble)_p_44964);
                    }
                }
                else {
                    _p_44964 = binary_op_a(PLUS, _p_44964, 1LL);
                }
                DeRef(_0);
                goto L28; // [951] 887
L29: 
                ;
                DeRef(_p_44964);
            }

            /** c_decl.e:1615						c_puts(")\n")*/
            RefDS(_23439);
            _55c_puts(_23439);

            /** c_decl.e:1616						c_stmt0("{\n")*/
            RefDS(_22097);
            _58c_stmt0(_22097);

            /** c_decl.e:1618						NewBB(0, E_ALL_EFFECT, 0)*/
            _58NewBB(0LL, 1073741823LL, 0LL);

            /** c_decl.e:1619						Initializing = TRUE*/
            _36Initializing_21523 = _13TRUE_452;

            /** c_decl.e:1622						while sp do*/
L2B: 
            if (_sp_44769 == 0)
            {
                goto L2C; // [989] 1128
            }
            else{
            }

            /** c_decl.e:1623							integer scope = SymTab[sp][S_SCOPE]*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23440 = (object)*(((s1_ptr)_2)->base + _sp_44769);
            _2 = (object)SEQ_PTR(_23440);
            _scope_44994 = (object)*(((s1_ptr)_2)->base + 4LL);
            if (!IS_ATOM_INT(_scope_44994)){
                _scope_44994 = (object)DBL_PTR(_scope_44994)->dbl;
            }
            _23440 = NOVALUE;

            /** c_decl.e:1624							switch scope with fallthru do*/
            _0 = _scope_44994;
            switch ( _0 ){ 

                /** c_decl.e:1625								case SC_LOOP_VAR, SC_UNDEFINED then*/
                case 2:
                case 9:

                /** c_decl.e:1628									break*/
                goto L2D; // [1023] 1105

                /** c_decl.e:1630								case SC_PRIVATE then*/
                case 3:

                /** c_decl.e:1631									c_stmt0("object ")*/
                RefDS(_22778);
                _58c_stmt0(_22778);

                /** c_decl.e:1632									c_puts("_")*/
                RefDS(_22065);
                _55c_puts(_22065);

                /** c_decl.e:1633									c_puts(SymTab[sp][S_NAME])*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23444 = (object)*(((s1_ptr)_2)->base + _sp_44769);
                _2 = (object)SEQ_PTR(_23444);
                if (!IS_ATOM_INT(_36S_NAME_21076)){
                    _23445 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
                }
                else{
                    _23445 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
                }
                _23444 = NOVALUE;
                Ref(_23445);
                _55c_puts(_23445);
                _23445 = NOVALUE;

                /** c_decl.e:1635									c_puts(" = NOVALUE;\n")*/
                RefDS(_22786);
                _55c_puts(_22786);

                /** c_decl.e:1636									target[MIN] = NOVALUE*/
                Ref(_36NOVALUE_21293);
                _2 = (object)SEQ_PTR(_59target_28391);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _59target_28391 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 1LL);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _36NOVALUE_21293;
                DeRef(_1);

                /** c_decl.e:1637									target[MAX] = NOVALUE*/
                Ref(_36NOVALUE_21293);
                _2 = (object)SEQ_PTR(_59target_28391);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _59target_28391 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 2LL);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _36NOVALUE_21293;
                DeRef(_1);

                /** c_decl.e:1638									RemoveFromBB( sp )*/
                _58RemoveFromBB(_sp_44769);

                /** c_decl.e:1640									break*/
                goto L2D; // [1092] 1105

                /** c_decl.e:1642								case else*/
                default:

                /** c_decl.e:1643									exit*/
                goto L2C; // [1102] 1128
            ;}L2D: 

            /** c_decl.e:1645							sp = SymTab[sp][S_NEXT]*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23446 = (object)*(((s1_ptr)_2)->base + _sp_44769);
            _2 = (object)SEQ_PTR(_23446);
            _sp_44769 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_sp_44769)){
                _sp_44769 = (object)DBL_PTR(_sp_44769)->dbl;
            }
            _23446 = NOVALUE;

            /** c_decl.e:1646						end while*/
            goto L2B; // [1125] 989
L2C: 

            /** c_decl.e:1649						temps = SymTab[s][S_TEMPS]*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23448 = (object)*(((s1_ptr)_2)->base + _s_44768);
            _2 = (object)SEQ_PTR(_23448);
            if (!IS_ATOM_INT(_36S_TEMPS_21121)){
                _temps_44772 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TEMPS_21121)->dbl));
            }
            else{
                _temps_44772 = (object)*(((s1_ptr)_2)->base + _36S_TEMPS_21121);
            }
            if (!IS_ATOM_INT(_temps_44772)){
                _temps_44772 = (object)DBL_PTR(_temps_44772)->dbl;
            }
            _23448 = NOVALUE;

            /** c_decl.e:1650						sequence names = {}*/
            RefDS(_21993);
            DeRef(_names_45028);
            _names_45028 = _21993;

            /** c_decl.e:1651						while temps != 0 do*/
L2E: 
            if (_temps_44772 == 0LL)
            goto L2F; // [1156] 1348

            /** c_decl.e:1652							if SymTab[temps][S_SCOPE] != DELETED then*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23451 = (object)*(((s1_ptr)_2)->base + _temps_44772);
            _2 = (object)SEQ_PTR(_23451);
            _23452 = (object)*(((s1_ptr)_2)->base + 4LL);
            _23451 = NOVALUE;
            if (binary_op_a(EQUALS, _23452, 2LL)){
                _23452 = NOVALUE;
                goto L30; // [1176] 1308
            }
            _23452 = NOVALUE;

            /** c_decl.e:1653								sequence name = sprintf("_%d", SymTab[temps][S_TEMP_NAME] )*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23454 = (object)*(((s1_ptr)_2)->base + _temps_44772);
            _2 = (object)SEQ_PTR(_23454);
            _23455 = (object)*(((s1_ptr)_2)->base + 34LL);
            _23454 = NOVALUE;
            DeRefi(_name_45038);
            _name_45038 = EPrintf(-9999999, _22116, _23455);
            _23455 = NOVALUE;

            /** c_decl.e:1654								if temp_name_type[SymTab[temps][S_TEMP_NAME]][T_GTYPE]*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23457 = (object)*(((s1_ptr)_2)->base + _temps_44772);
            _2 = (object)SEQ_PTR(_23457);
            _23458 = (object)*(((s1_ptr)_2)->base + 34LL);
            _23457 = NOVALUE;
            _2 = (object)SEQ_PTR(_36temp_name_type_21525);
            if (!IS_ATOM_INT(_23458)){
                _23459 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_23458)->dbl));
            }
            else{
                _23459 = (object)*(((s1_ptr)_2)->base + _23458);
            }
            _2 = (object)SEQ_PTR(_23459);
            _23460 = (object)*(((s1_ptr)_2)->base + 1LL);
            _23459 = NOVALUE;
            if (IS_ATOM_INT(_23460)) {
                _23461 = (_23460 != 0LL);
            }
            else {
                _23461 = binary_op(NOTEQ, _23460, 0LL);
            }
            _23460 = NOVALUE;
            if (IS_ATOM_INT(_23461)) {
                if (_23461 == 0) {
                    goto L31; // [1230] 1304
                }
            }
            else {
                if (DBL_PTR(_23461)->dbl == 0.0) {
                    goto L31; // [1230] 1304
                }
            }
            _23463 = find_from(_name_45038, _names_45028, 1LL);
            _23464 = (_23463 == 0);
            _23463 = NOVALUE;
            if (_23464 == 0)
            {
                DeRef(_23464);
                _23464 = NOVALUE;
                goto L31; // [1243] 1304
            }
            else{
                DeRef(_23464);
                _23464 = NOVALUE;
            }

            /** c_decl.e:1657									c_stmt0("object ")*/
            RefDS(_22778);
            _58c_stmt0(_22778);

            /** c_decl.e:1658									c_puts( name )*/
            RefDS(_name_45038);
            _55c_puts(_name_45038);

            /** c_decl.e:1659									c_puts(" = NOVALUE")*/
            RefDS(_23465);
            _55c_puts(_23465);

            /** c_decl.e:1661									target = {NOVALUE, NOVALUE}*/
            Ref(_36NOVALUE_21293);
            Ref(_36NOVALUE_21293);
            DeRef(_59target_28391);
            _1 = NewS1(2);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t *)_2)[1] = _36NOVALUE_21293;
            ((intptr_t *)_2)[2] = _36NOVALUE_21293;
            _59target_28391 = MAKE_SEQ(_1);

            /** c_decl.e:1663									SetBBType(temps, TYPE_INTEGER, target, TYPE_OBJECT, 0)*/
            RefDS(_59target_28391);
            _58SetBBType(_temps_44772, 1LL, _59target_28391, 16LL, 0LL);

            /** c_decl.e:1664									ifdef DEBUG then*/

            /** c_decl.e:1667										c_puts(";\n")*/
            RefDS(_22269);
            _55c_puts(_22269);

            /** c_decl.e:1669									names = prepend( names, name )*/
            RefDS(_name_45038);
            Prepend(&_names_45028, _names_45028, _name_45038);
            goto L32; // [1301] 1307
L31: 

            /** c_decl.e:1671									ifdef DEBUG then*/
L32: 
L30: 
            DeRefi(_name_45038);
            _name_45038 = NOVALUE;

            /** c_decl.e:1677							SymTab[temps][S_GTYPE] = TYPE_OBJECT*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _37SymTab_15406 = MAKE_SEQ(_2);
            }
            _3 = (object)(_temps_44772 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 36LL);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 16LL;
            DeRef(_1);
            _23470 = NOVALUE;

            /** c_decl.e:1678							temps = SymTab[temps][S_NEXT]*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23472 = (object)*(((s1_ptr)_2)->base + _temps_44772);
            _2 = (object)SEQ_PTR(_23472);
            _temps_44772 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_temps_44772)){
                _temps_44772 = (object)DBL_PTR(_temps_44772)->dbl;
            }
            _23472 = NOVALUE;

            /** c_decl.e:1679						end while*/
            goto L2E; // [1345] 1156
L2F: 

            /** c_decl.e:1680						Initializing = FALSE*/
            _36Initializing_21523 = _13FALSE_450;

            /** c_decl.e:1682						if SymTab[s][S_LHS_SUBS2] then*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23474 = (object)*(((s1_ptr)_2)->base + _s_44768);
            _2 = (object)SEQ_PTR(_23474);
            _23475 = (object)*(((s1_ptr)_2)->base + 37LL);
            _23474 = NOVALUE;
            if (_23475 == 0) {
                _23475 = NOVALUE;
                goto L33; // [1371] 1384
            }
            else {
                if (!IS_ATOM_INT(_23475) && DBL_PTR(_23475)->dbl == 0.0){
                    _23475 = NOVALUE;
                    goto L33; // [1371] 1384
                }
                _23475 = NOVALUE;
            }
            _23475 = NOVALUE;

            /** c_decl.e:1683							c_stmt0("object _0, _1, _2, _3;\n\n")*/
            RefDS(_23476);
            _58c_stmt0(_23476);

            /** c_decl.e:1684							ifdef DEBUG then*/
            goto L34; // [1381] 1392
L33: 

            /** c_decl.e:1688							c_stmt0("object _0, _1, _2;\n\n")*/
            RefDS(_23478);
            _58c_stmt0(_23478);

            /** c_decl.e:1689							ifdef DEBUG then*/
L34: 

            /** c_decl.e:1696						sp = SymTab[s][S_NEXT]*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23480 = (object)*(((s1_ptr)_2)->base + _s_44768);
            _2 = (object)SEQ_PTR(_23480);
            _sp_44769 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_sp_44769)){
                _sp_44769 = (object)DBL_PTR(_sp_44769)->dbl;
            }
            _23480 = NOVALUE;

            /** c_decl.e:1697						for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23482 = (object)*(((s1_ptr)_2)->base + _s_44768);
            _2 = (object)SEQ_PTR(_23482);
            if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
                _23483 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
            }
            else{
                _23483 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
            }
            _23482 = NOVALUE;
            {
                object _p_45099;
                _p_45099 = 1LL;
L35: 
                if (binary_op_a(GREATER, _p_45099, _23483)){
                    goto L36; // [1422] 1773
                }

                /** c_decl.e:1698							SymTab[sp][S_ONE_REF] = FALSE*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _37SymTab_15406 = MAKE_SEQ(_2);
                }
                _3 = (object)(_sp_44769 + ((s1_ptr)_2)->base);
                _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    *(intptr_t *)_3 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 35LL);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _13FALSE_450;
                DeRef(_1);
                _23484 = NOVALUE;

                /** c_decl.e:1699							if SymTab[sp][S_ARG_TYPE] = TYPE_SEQUENCE then*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23486 = (object)*(((s1_ptr)_2)->base + _sp_44769);
                _2 = (object)SEQ_PTR(_23486);
                _23487 = (object)*(((s1_ptr)_2)->base + 43LL);
                _23486 = NOVALUE;
                if (binary_op_a(NOTEQ, _23487, 8LL)){
                    _23487 = NOVALUE;
                    goto L37; // [1462] 1526
                }
                _23487 = NOVALUE;

                /** c_decl.e:1700								target[MIN] = SymTab[sp][S_ARG_SEQ_LEN]*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23489 = (object)*(((s1_ptr)_2)->base + _sp_44769);
                _2 = (object)SEQ_PTR(_23489);
                _23490 = (object)*(((s1_ptr)_2)->base + 51LL);
                _23489 = NOVALUE;
                Ref(_23490);
                _2 = (object)SEQ_PTR(_59target_28391);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _59target_28391 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 1LL);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _23490;
                if( _1 != _23490 ){
                    DeRef(_1);
                }
                _23490 = NOVALUE;

                /** c_decl.e:1701								SetBBType(sp, SymTab[sp][S_ARG_TYPE], target,*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23491 = (object)*(((s1_ptr)_2)->base + _sp_44769);
                _2 = (object)SEQ_PTR(_23491);
                _23492 = (object)*(((s1_ptr)_2)->base + 43LL);
                _23491 = NOVALUE;
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23493 = (object)*(((s1_ptr)_2)->base + _sp_44769);
                _2 = (object)SEQ_PTR(_23493);
                _23494 = (object)*(((s1_ptr)_2)->base + 45LL);
                _23493 = NOVALUE;
                Ref(_23492);
                RefDS(_59target_28391);
                Ref(_23494);
                _58SetBBType(_sp_44769, _23492, _59target_28391, _23494, 0LL);
                _23492 = NOVALUE;
                _23494 = NOVALUE;
                goto L38; // [1523] 1750
L37: 

                /** c_decl.e:1704							elsif SymTab[sp][S_ARG_TYPE] = TYPE_INTEGER then*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23495 = (object)*(((s1_ptr)_2)->base + _sp_44769);
                _2 = (object)SEQ_PTR(_23495);
                _23496 = (object)*(((s1_ptr)_2)->base + 43LL);
                _23495 = NOVALUE;
                if (binary_op_a(NOTEQ, _23496, 1LL)){
                    _23496 = NOVALUE;
                    goto L39; // [1542] 1666
                }
                _23496 = NOVALUE;

                /** c_decl.e:1705								if SymTab[sp][S_ARG_MIN] = NOVALUE then*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23498 = (object)*(((s1_ptr)_2)->base + _sp_44769);
                _2 = (object)SEQ_PTR(_23498);
                _23499 = (object)*(((s1_ptr)_2)->base + 47LL);
                _23498 = NOVALUE;
                if (binary_op_a(NOTEQ, _23499, _36NOVALUE_21293)){
                    _23499 = NOVALUE;
                    goto L3A; // [1562] 1593
                }
                _23499 = NOVALUE;

                /** c_decl.e:1706									target[MIN] = MININT*/
                Ref(_36MININT_21263);
                _2 = (object)SEQ_PTR(_59target_28391);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _59target_28391 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 1LL);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _36MININT_21263;
                DeRef(_1);

                /** c_decl.e:1707									target[MAX] = MAXINT*/
                Ref(_36MAXINT_21262);
                _2 = (object)SEQ_PTR(_59target_28391);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _59target_28391 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 2LL);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _36MAXINT_21262;
                DeRef(_1);
                goto L3B; // [1590] 1638
L3A: 

                /** c_decl.e:1709									target[MIN] = SymTab[sp][S_ARG_MIN]*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23501 = (object)*(((s1_ptr)_2)->base + _sp_44769);
                _2 = (object)SEQ_PTR(_23501);
                _23502 = (object)*(((s1_ptr)_2)->base + 47LL);
                _23501 = NOVALUE;
                Ref(_23502);
                _2 = (object)SEQ_PTR(_59target_28391);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _59target_28391 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 1LL);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _23502;
                if( _1 != _23502 ){
                    DeRef(_1);
                }
                _23502 = NOVALUE;

                /** c_decl.e:1710									target[MAX] = SymTab[sp][S_ARG_MAX]*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23503 = (object)*(((s1_ptr)_2)->base + _sp_44769);
                _2 = (object)SEQ_PTR(_23503);
                _23504 = (object)*(((s1_ptr)_2)->base + 48LL);
                _23503 = NOVALUE;
                Ref(_23504);
                _2 = (object)SEQ_PTR(_59target_28391);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _59target_28391 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 2LL);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _23504;
                if( _1 != _23504 ){
                    DeRef(_1);
                }
                _23504 = NOVALUE;
L3B: 

                /** c_decl.e:1712								SetBBType(sp, SymTab[sp][S_ARG_TYPE], target, TYPE_OBJECT, 0)*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23505 = (object)*(((s1_ptr)_2)->base + _sp_44769);
                _2 = (object)SEQ_PTR(_23505);
                _23506 = (object)*(((s1_ptr)_2)->base + 43LL);
                _23505 = NOVALUE;
                Ref(_23506);
                RefDS(_59target_28391);
                _58SetBBType(_sp_44769, _23506, _59target_28391, 16LL, 0LL);
                _23506 = NOVALUE;
                goto L38; // [1663] 1750
L39: 

                /** c_decl.e:1714							elsif SymTab[sp][S_ARG_TYPE] = TYPE_OBJECT then*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23507 = (object)*(((s1_ptr)_2)->base + _sp_44769);
                _2 = (object)SEQ_PTR(_23507);
                _23508 = (object)*(((s1_ptr)_2)->base + 43LL);
                _23507 = NOVALUE;
                if (binary_op_a(NOTEQ, _23508, 16LL)){
                    _23508 = NOVALUE;
                    goto L3C; // [1682] 1724
                }
                _23508 = NOVALUE;

                /** c_decl.e:1716								SetBBType(sp, SymTab[sp][S_ARG_TYPE], novalue,*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23510 = (object)*(((s1_ptr)_2)->base + _sp_44769);
                _2 = (object)SEQ_PTR(_23510);
                _23511 = (object)*(((s1_ptr)_2)->base + 43LL);
                _23510 = NOVALUE;
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23512 = (object)*(((s1_ptr)_2)->base + _sp_44769);
                _2 = (object)SEQ_PTR(_23512);
                _23513 = (object)*(((s1_ptr)_2)->base + 45LL);
                _23512 = NOVALUE;
                Ref(_23511);
                RefDS(_55novalue_46627);
                Ref(_23513);
                _58SetBBType(_sp_44769, _23511, _55novalue_46627, _23513, 0LL);
                _23511 = NOVALUE;
                _23513 = NOVALUE;
                goto L38; // [1721] 1750
L3C: 

                /** c_decl.e:1720								SetBBType(sp, SymTab[sp][S_ARG_TYPE], novalue, TYPE_OBJECT, 0)*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23514 = (object)*(((s1_ptr)_2)->base + _sp_44769);
                _2 = (object)SEQ_PTR(_23514);
                _23515 = (object)*(((s1_ptr)_2)->base + 43LL);
                _23514 = NOVALUE;
                Ref(_23515);
                RefDS(_55novalue_46627);
                _58SetBBType(_sp_44769, _23515, _55novalue_46627, 16LL, 0LL);
                _23515 = NOVALUE;
L38: 

                /** c_decl.e:1723							sp = SymTab[sp][S_NEXT]*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23516 = (object)*(((s1_ptr)_2)->base + _sp_44769);
                _2 = (object)SEQ_PTR(_23516);
                _sp_44769 = (object)*(((s1_ptr)_2)->base + 2LL);
                if (!IS_ATOM_INT(_sp_44769)){
                    _sp_44769 = (object)DBL_PTR(_sp_44769)->dbl;
                }
                _23516 = NOVALUE;

                /** c_decl.e:1724						end for*/
                _0 = _p_45099;
                if (IS_ATOM_INT(_p_45099)) {
                    _p_45099 = _p_45099 + 1LL;
                    if ((object)((uintptr_t)_p_45099 +(uintptr_t) HIGH_BITS) >= 0){
                        _p_45099 = NewDouble((eudouble)_p_45099);
                    }
                }
                else {
                    _p_45099 = binary_op_a(PLUS, _p_45099, 1LL);
                }
                DeRef(_0);
                goto L35; // [1768] 1429
L36: 
                ;
                DeRef(_p_45099);
            }

            /** c_decl.e:1727						call_proc(Execute_id, {s})*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t*)_2)[1] = _s_44768;
            _23518 = MAKE_SEQ(_1);
            _1 = (object)SEQ_PTR(_23518);
            _2 = (object)((s1_ptr)_1)->base;
            _0 = (object)_00[_36Execute_id_21530].addr;
            Ref( *(( (intptr_t*)_2) + 1) );
            (*(intptr_t (*)())_0)(
                                *( ((intptr_t *)_2) + 1)
                                 );
            DeRefDS(_23518);
            _23518 = NOVALUE;

            /** c_decl.e:1729						c_puts("    ;\n}\n")*/
            RefDS(_23519);
            _55c_puts(_23519);

            /** c_decl.e:1730						if dll_option and is_exported( s ) then*/
            if (_58dll_option_42563 == 0) {
                goto L3D; // [1793] 2183
            }
            _23521 = _58is_exported(_s_44768);
            if (_23521 == 0) {
                DeRef(_23521);
                _23521 = NOVALUE;
                goto L3D; // [1802] 2183
            }
            else {
                if (!IS_ATOM_INT(_23521) && DBL_PTR(_23521)->dbl == 0.0){
                    DeRef(_23521);
                    _23521 = NOVALUE;
                    goto L3D; // [1802] 2183
                }
                DeRef(_23521);
                _23521 = NOVALUE;
            }
            DeRef(_23521);
            _23521 = NOVALUE;

            /** c_decl.e:1732							LeftSym = TRUE*/
            _58LeftSym_42560 = _13TRUE_452;

            /** c_decl.e:1733							if TOSX then*/
            if (_46TOSX_21594 == 0)
            {
                goto L3E; // [1818] 2078
            }
            else{
            }

            /** c_decl.e:1737								c_stmt0( ret_type & SymTab[s][S_NAME] & " (" )*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23522 = (object)*(((s1_ptr)_2)->base + _s_44768);
            _2 = (object)SEQ_PTR(_23522);
            if (!IS_ATOM_INT(_36S_NAME_21076)){
                _23523 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
            }
            else{
                _23523 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
            }
            _23522 = NOVALUE;
            {
                object concat_list[3];

                concat_list[0] = _23524;
                concat_list[1] = _23523;
                concat_list[2] = _ret_type_44905;
                Concat_N((object_ptr)&_23525, concat_list, 3);
            }
            _23523 = NOVALUE;
            _58c_stmt0(_23525);
            _23525 = NOVALUE;

            /** c_decl.e:1739								sp = SymTab[s][S_NEXT]*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23526 = (object)*(((s1_ptr)_2)->base + _s_44768);
            _2 = (object)SEQ_PTR(_23526);
            _sp_44769 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_sp_44769)){
                _sp_44769 = (object)DBL_PTR(_sp_44769)->dbl;
            }
            _23526 = NOVALUE;

            /** c_decl.e:1740								for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23528 = (object)*(((s1_ptr)_2)->base + _s_44768);
            _2 = (object)SEQ_PTR(_23528);
            if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
                _23529 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
            }
            else{
                _23529 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
            }
            _23528 = NOVALUE;
            {
                object _p_45218;
                _p_45218 = 1LL;
L3F: 
                if (binary_op_a(GREATER, _p_45218, _23529)){
                    goto L40; // [1876] 1952
                }

                /** c_decl.e:1741									c_puts("int _")*/
                RefDS(_23530);
                _55c_puts(_23530);

                /** c_decl.e:1742									c_puts(SymTab[sp][S_NAME])*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23531 = (object)*(((s1_ptr)_2)->base + _sp_44769);
                _2 = (object)SEQ_PTR(_23531);
                if (!IS_ATOM_INT(_36S_NAME_21076)){
                    _23532 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
                }
                else{
                    _23532 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
                }
                _23531 = NOVALUE;
                Ref(_23532);
                _55c_puts(_23532);
                _23532 = NOVALUE;

                /** c_decl.e:1743									if p != SymTab[s][S_NUM_ARGS] then*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23533 = (object)*(((s1_ptr)_2)->base + _s_44768);
                _2 = (object)SEQ_PTR(_23533);
                if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
                    _23534 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
                }
                else{
                    _23534 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
                }
                _23533 = NOVALUE;
                if (binary_op_a(EQUALS, _p_45218, _23534)){
                    _23534 = NOVALUE;
                    goto L41; // [1919] 1929
                }
                _23534 = NOVALUE;

                /** c_decl.e:1744										c_puts(", ")*/
                RefDS(_23436);
                _55c_puts(_23436);
L41: 

                /** c_decl.e:1746									sp = SymTab[sp][S_NEXT]*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23536 = (object)*(((s1_ptr)_2)->base + _sp_44769);
                _2 = (object)SEQ_PTR(_23536);
                _sp_44769 = (object)*(((s1_ptr)_2)->base + 2LL);
                if (!IS_ATOM_INT(_sp_44769)){
                    _sp_44769 = (object)DBL_PTR(_sp_44769)->dbl;
                }
                _23536 = NOVALUE;

                /** c_decl.e:1747								end for*/
                _0 = _p_45218;
                if (IS_ATOM_INT(_p_45218)) {
                    _p_45218 = _p_45218 + 1LL;
                    if ((object)((uintptr_t)_p_45218 +(uintptr_t) HIGH_BITS) >= 0){
                        _p_45218 = NewDouble((eudouble)_p_45218);
                    }
                }
                else {
                    _p_45218 = binary_op_a(PLUS, _p_45218, 1LL);
                }
                DeRef(_0);
                goto L3F; // [1947] 1883
L40: 
                ;
                DeRef(_p_45218);
            }

            /** c_decl.e:1749								c_puts( ") {\n")*/
            RefDS(_23538);
            _55c_puts(_23538);

            /** c_decl.e:1750								c_stmt("    return @(", s)*/
            RefDS(_23539);
            _58c_stmt(_23539, _s_44768, 0LL);

            /** c_decl.e:1751								sp = SymTab[s][S_NEXT]*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23540 = (object)*(((s1_ptr)_2)->base + _s_44768);
            _2 = (object)SEQ_PTR(_23540);
            _sp_44769 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_sp_44769)){
                _sp_44769 = (object)DBL_PTR(_sp_44769)->dbl;
            }
            _23540 = NOVALUE;

            /** c_decl.e:1752								for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23542 = (object)*(((s1_ptr)_2)->base + _s_44768);
            _2 = (object)SEQ_PTR(_23542);
            if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
                _23543 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
            }
            else{
                _23543 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
            }
            _23542 = NOVALUE;
            {
                object _p_45249;
                _p_45249 = 1LL;
L42: 
                if (binary_op_a(GREATER, _p_45249, _23543)){
                    goto L43; // [1994] 2070
                }

                /** c_decl.e:1753									c_puts("_")*/
                RefDS(_22065);
                _55c_puts(_22065);

                /** c_decl.e:1754									c_puts(SymTab[sp][S_NAME])*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23544 = (object)*(((s1_ptr)_2)->base + _sp_44769);
                _2 = (object)SEQ_PTR(_23544);
                if (!IS_ATOM_INT(_36S_NAME_21076)){
                    _23545 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
                }
                else{
                    _23545 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
                }
                _23544 = NOVALUE;
                Ref(_23545);
                _55c_puts(_23545);
                _23545 = NOVALUE;

                /** c_decl.e:1755									if p != SymTab[s][S_NUM_ARGS] then*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23546 = (object)*(((s1_ptr)_2)->base + _s_44768);
                _2 = (object)SEQ_PTR(_23546);
                if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
                    _23547 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
                }
                else{
                    _23547 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
                }
                _23546 = NOVALUE;
                if (binary_op_a(EQUALS, _p_45249, _23547)){
                    _23547 = NOVALUE;
                    goto L44; // [2037] 2047
                }
                _23547 = NOVALUE;

                /** c_decl.e:1756										c_puts(", ")*/
                RefDS(_23436);
                _55c_puts(_23436);
L44: 

                /** c_decl.e:1758									sp = SymTab[sp][S_NEXT]*/
                _2 = (object)SEQ_PTR(_37SymTab_15406);
                _23549 = (object)*(((s1_ptr)_2)->base + _sp_44769);
                _2 = (object)SEQ_PTR(_23549);
                _sp_44769 = (object)*(((s1_ptr)_2)->base + 2LL);
                if (!IS_ATOM_INT(_sp_44769)){
                    _sp_44769 = (object)DBL_PTR(_sp_44769)->dbl;
                }
                _23549 = NOVALUE;

                /** c_decl.e:1759								end for*/
                _0 = _p_45249;
                if (IS_ATOM_INT(_p_45249)) {
                    _p_45249 = _p_45249 + 1LL;
                    if ((object)((uintptr_t)_p_45249 +(uintptr_t) HIGH_BITS) >= 0){
                        _p_45249 = NewDouble((eudouble)_p_45249);
                    }
                }
                else {
                    _p_45249 = binary_op_a(PLUS, _p_45249, 1LL);
                }
                DeRef(_0);
                goto L42; // [2065] 2001
L43: 
                ;
                DeRef(_p_45249);
            }

            /** c_decl.e:1761								c_puts( ");\n}\n" )*/
            RefDS(_23551);
            _55c_puts(_23551);
            goto L45; // [2075] 2173
L3E: 

            /** c_decl.e:1762							elsif TWINDOWS then*/
            if (_46TWINDOWS_21586 == 0)
            {
                goto L46; // [2082] 2145
            }
            else{
            }

            /** c_decl.e:1766								c_stmt0( ret_type & SymTab[s][S_NAME] & "() __attribute__ ((alias (\"" )*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23552 = (object)*(((s1_ptr)_2)->base + _s_44768);
            _2 = (object)SEQ_PTR(_23552);
            if (!IS_ATOM_INT(_36S_NAME_21076)){
                _23553 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
            }
            else{
                _23553 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
            }
            _23552 = NOVALUE;
            {
                object concat_list[3];

                concat_list[0] = _23554;
                concat_list[1] = _23553;
                concat_list[2] = _ret_type_44905;
                Concat_N((object_ptr)&_23555, concat_list, 3);
            }
            _23553 = NOVALUE;
            _58c_stmt0(_23555);
            _23555 = NOVALUE;

            /** c_decl.e:1767								CName( s )*/
            _58CName(_s_44768);

            /** c_decl.e:1768								c_puts( sprintf( "@%d\")));\n", SymTab[s][S_NUM_ARGS] * TARGET_SIZEOF_POINTER ) )*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23557 = (object)*(((s1_ptr)_2)->base + _s_44768);
            _2 = (object)SEQ_PTR(_23557);
            if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
                _23558 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
            }
            else{
                _23558 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
            }
            _23557 = NOVALUE;
            if (IS_ATOM_INT(_23558)) {
                {
                    int128_t p128 = (int128_t)_23558 * (int128_t)_36TARGET_SIZEOF_POINTER_21261;
                    if( p128 != (int128_t)(_23559 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                        _23559 = NewDouble( (eudouble)p128 );
                    }
                }
            }
            else {
                _23559 = binary_op(MULTIPLY, _23558, _36TARGET_SIZEOF_POINTER_21261);
            }
            _23558 = NOVALUE;
            _23560 = EPrintf(-9999999, _23556, _23559);
            DeRef(_23559);
            _23559 = NOVALUE;
            _55c_puts(_23560);
            _23560 = NOVALUE;
            goto L45; // [2142] 2173
L46: 

            /** c_decl.e:1770								c_stmt( ret_type & SymTab[s][S_NAME] & "() __attribute__ ((alias (\"@\")));\n", s )*/
            _2 = (object)SEQ_PTR(_37SymTab_15406);
            _23561 = (object)*(((s1_ptr)_2)->base + _s_44768);
            _2 = (object)SEQ_PTR(_23561);
            if (!IS_ATOM_INT(_36S_NAME_21076)){
                _23562 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
            }
            else{
                _23562 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
            }
            _23561 = NOVALUE;
            {
                object concat_list[3];

                concat_list[0] = _23563;
                concat_list[1] = _23562;
                concat_list[2] = _ret_type_44905;
                Concat_N((object_ptr)&_23564, concat_list, 3);
            }
            _23562 = NOVALUE;
            _58c_stmt(_23564, _s_44768, 0LL);
            _23564 = NOVALUE;
L45: 

            /** c_decl.e:1772							LeftSym = FALSE*/
            _58LeftSym_42560 = _13FALSE_450;
L3D: 

            /** c_decl.e:1774						c_puts("\n\n" )*/
            RefDS(_22137);
            _55c_puts(_22137);
L14: 
            DeRefi(_ret_type_44905);
            _ret_type_44905 = NOVALUE;
            DeRef(_names_45028);
            _names_45028 = NOVALUE;

            /** c_decl.e:1776				end for*/
            _routine_no_44850 = _routine_no_44850 + 1LL;
            goto L12; // [2193] 367
L13: 
            ;
        }
L8: 
        DeRef(_these_routines_44847);
        _these_routines_44847 = NOVALUE;

        /** c_decl.e:1778		end for*/
        _file_no_44795 = _file_no_44795 + 1LL;
        goto L5; // [2203] 91
L6: 
        ;
    }

    /** c_decl.e:1779	end procedure*/
    DeRefi(_buff_44773);
    DeRef(_base_name_44774);
    DeRef(_long_c_file_44775);
    DeRef(_c_file_44776);
    DeRef(_23408);
    _23408 = NOVALUE;
    DeRef(_23414);
    _23414 = NOVALUE;
    DeRef(_23406);
    _23406 = NOVALUE;
    _23483 = NOVALUE;
    _23429 = NOVALUE;
    DeRef(_23369);
    _23369 = NOVALUE;
    _23379 = NOVALUE;
    DeRef(_23461);
    _23461 = NOVALUE;
    DeRef(_23418);
    _23418 = NOVALUE;
    DeRef(_23358);
    _23358 = NOVALUE;
    DeRef(_23371);
    _23371 = NOVALUE;
    DeRef(_23410);
    _23410 = NOVALUE;
    DeRef(_23381);
    _23381 = NOVALUE;
    _23458 = NOVALUE;
    _23543 = NOVALUE;
    DeRef(_23376);
    _23376 = NOVALUE;
    DeRef(_23335);
    _23335 = NOVALUE;
    DeRef(_23412);
    _23412 = NOVALUE;
    DeRef(_23344);
    _23344 = NOVALUE;
    _23529 = NOVALUE;
    DeRef(_23373);
    _23373 = NOVALUE;
    return;
    ;
}



// 0x5B472120
